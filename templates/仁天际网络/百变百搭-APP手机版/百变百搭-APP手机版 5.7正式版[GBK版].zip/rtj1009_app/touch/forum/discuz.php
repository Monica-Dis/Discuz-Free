<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:portal.php?mod=index');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<!--{if ($rtj1009_m_config['ren_m_portal_zy'] ==1) || ($rtj1009_m_config['ren_m_portal_zy'] ==2)}-->
		<a href="search.php?mod=forum" class="z ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
		<!--{elseif $rtj1009_m_config['ren_m_portal_zy'] ==3}-->
		<div class="ren_nav_left open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
		<!--{elseif $rtj1009_m_config['ren_m_portal_zy'] ==4}-->
		<div class="ren_nav_left open-panel">
			<div class="ren-nav-avatar">
				<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}-->
				<img src="<!--{avatar($_G[uid], middle, true)}-->" />
			</div>
		</div>
		<!--{/if}-->
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['ren002']}</span>
		</div>
		<!--{if $rtj1009_m_config['ren_m_portal_zy'] ==1}-->
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
		<!--{elseif $rtj1009_m_config['ren_m_portal_zy'] ==2}-->
		<div class="ren_nav_right open-panel">
			<div class="ren-nav-avatar">
				<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}-->
				<img src="<!--{avatar($_G[uid], middle, true)}-->" />
			</div>
		</div>
		<!--{elseif ($rtj1009_m_config['ren_m_portal_zy'] ==3) || ($rtj1009_m_config['ren_m_portal_zy'] ==4)}-->
		<a href="search.php?mod=forum" class="y ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
		<!--{/if}-->
	</div>
</header>
<!-- header end -->
<!--{/if}-->

<script type="text/javascript" src="template/rtj1009_app/js/jQuery.rTabs.js"></script>
<div class="content">
<!--{hook/index_top_mobile}-->
	<div class="rtj1009_m_forum <!--{if $rtj1009_m_config['ren_m_slide'] == 2}-->ren-home-slide-e<!--{elseif $rtj1009_m_config['ren_m_slide'] == 3}-->ren-home-slide-san<!--{elseif $rtj1009_m_config['ren_m_slide'] == 4}-->ren-home-slide-si<!--{elseif $rtj1009_m_config['ren_m_slide'] == 5}-->ren-home-slide-wu<!--{/if}-->">
	<!--{if $rtj1009_m_config['ren_m_forum'] == 1}-->
	<div class="ren_fenpinglist cl">
		<!--{template forum/discuz_fenpinglist}-->
	</div>
	<!--{elseif $rtj1009_m_config['ren_m_forum'] == 2 || $rtj1009_m_config['ren_m_forum'] == 4}-->
	{$block_forum_yi}
    <!--{if $rtj1009_m_config['ren_forum_shuju']}-->
    <div class="ren-f-count cl">
        <ul class="cl">
            <li>
                <p>{$rtj1009_lang['ren036']}</p>
                <em>$todayposts</em>
            </li>
            <li>
                <p>{$rtj1009_lang['ren037']}</p>
                <em>$posts</em>
            </li>
            <li>
                <p>{$rtj1009_lang['ren038']}</p>
                <em>$_G['cache']['userstats']['totalmembers']</em>
            </li>
        </ul>
    </div>
    <!--{/if}-->

	<!--{template forum/discuz_forumlist}-->
	<!--{elseif $rtj1009_m_config['ren_m_forum'] == 3}-->
		<div id="tab2" class="tab">
            <ul class="tab-nav j-tab-nav buttons-tab cl">
                <li class="current"><a href="javascript:;" class="tab-link button">{$rtj1009_lang['ren039']}</a></li>
                <li><a href="javascript:;" class="tab-link button">{$rtj1009_lang['ren040']}</a></li>
            </ul>
            <div class="tab-con tabs cl">
                <div class="j-tab-con cl">
                    <div class="tab-con-item" style="display: block;">
                        <div class="ren_xxk_xx">
                            {$block_forum_e}
                        </div>
                    </div>
                    <div class="tab-con-item">
                        <!--{template forum/discuz_forumlist}-->
                    </div>
                </div>
            </div>
        </div>
	<!--{/if}-->
	</div>
<!--{hook/index_middle_mobile}-->
</div>

<script type="text/javascript">
    $(function() {
        $("#tab2").rTabs({
            animation : 'fadein',
            bind : 'click'
        });
    })
</script>

<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
                obj.find('h3').removeClass('ren-subforums');
				subobj.css('display', 'block');
			} else {
                obj.find('h3').addClass('ren-subforums');
				subobj.css('display', 'none');
			}
		});
	 })();
</script>
<!-- main forumlist end -->

<!--{template common/footer}-->

