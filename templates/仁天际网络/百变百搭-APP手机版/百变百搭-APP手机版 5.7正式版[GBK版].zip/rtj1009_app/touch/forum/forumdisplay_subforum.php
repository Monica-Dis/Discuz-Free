<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren-forum-rec ren-list-sub" href="#lis_sub_forum">
	<div class="ren_m_mkbt">
    	<span>{$rtj1009_lang['ren144']}</span>
        <a href="javascript:;"></a>
    </div>
	<ul id="lis_sub_forum" class="ren_fx_xx cl">
	<!--{loop $sublist $sub}-->
	<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
            <li>
				<div class="ren_bkxx" >
				<!--{if $sub[icon]}-->
						$sub[icon]
					<!--{else}-->
						<a href="$forumurl"><img src="{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg" /></a>
					<!--{/if}-->
					<p>$sub[name]</p>
				</div>
            </li>
	<!--{/loop}-->
    </ul>
</div>

<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.ren_fx_xx').css('display', 'block');
		<!--{else}-->
			$('.ren_fx_xx').css('display', 'none');
		<!--{/if}-->
		$('.ren-list-sub').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
			} else {
				subobj.css('display', 'none');
			}
		});
	 })();
</script>
