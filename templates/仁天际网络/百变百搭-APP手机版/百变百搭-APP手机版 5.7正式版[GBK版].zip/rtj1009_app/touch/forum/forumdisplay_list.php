<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle'] || !$rtj1009_m_config['ren_m_picstyle']}-->
    <ul class="ren_list cl">
    <!--{if $_G['forum_threadcount']}-->
        <!--{eval
            include_once libfile('function/post');
            include_once libfile('function/attachment');
        }-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
            <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                {eval continue;}
            <!--{/if}-->
            <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                {eval $displayorder_thread = 1;}
            <!--{/if}-->
            <!--{if $thread['moved']}-->
                <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
			<!--{if !$rtj1009_m_config['ren_m_forum_tst'] == 1}-->
			<!--{subtemplate rtj1009_core/ren_forum_list}-->
			<!--{else}-->
			<!--{if !$thread['displayorder']}-->
			<!--{subtemplate rtj1009_core/ren_forum_list}-->
			<!--{/if}-->
			<!--{/if}-->
        <!--{/loop}-->
    <!--{else}-->
    <li class="ren_ss_wu">
		<i class="icon ren-font">&#xe608;</i>
		<span>{lang forum_nothreads}</span>
	</li>
    <!--{/if}-->
	</ul>
<!--{else}-->
    <div id="ren_pbl_list" class="z ren_pbl_list cl">
        <ul id="waterfall" class="waterfall cl">
    <!--{if $_G['forum_threadcount']}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
              <!--{if $_G['hiddenexists'] && $thread['hidden']}-->
                  <!--{eval continue;}-->
              <!--{/if}-->
              <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
                  <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
                      <!--{eval $thread[tid]=$thread[closed];}-->
                  <!--{/if}-->
              <!--{/if}-->
              <!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 100; }-->
              <li>
                  <div class="ren_pbl_wk cl">
                      <div class="ren_pbl_img cl">
                          <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="$thread[subject]" class="z">
                              <!--{if $thread['cover']}-->
                                  <img src="$thread[coverpath]"/>
                              <!--{else}-->
                                  <span class="nopic"></span>
                              <!--{/if}-->
                          </a>
                      </div>
                      
                      <h3 class="ren_pbl_bt">
                          <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']}{else} onclick="atarget(this)"{/if} title="$thread[subject]">$thread[subject]</a>
                      </h3>
                      <div class="ren_tielb_zz cl">
                          <a class="ren_zz_tx z" href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a>
                          <a class="ren_zz_mc z" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                          <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y">
                              <span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
                          </a>
                      </div>
                  </div>
                  <div class="ren_pbl_no"></div>
              </li>
              <!--{/loop}-->
        <!--{else}-->
        <li class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang forum_nothreads}</span>
		</li>
        <!--{/if}-->
        </ul>
    </div>
    
    
    <div id="tmppic" style="display: none;"></div>
	<script type="text/javascript" src="template/rtj1009_app/js/redef.js?{VERHASH}"></script>
	<script type="text/javascript" reload="1">
          var wf = {};

          _attachEvent(window, "load", function () {
              if(jq("waterfall")) {
                  wf = waterfall();
              }
          });

    </script>
 <!--{/if}-->  
