<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<link href="template/rtj1009_app/css/extend_module.css" rel="stylesheet" type="text/css" />

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name">{$rtj1009_lang['ren076']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content post_forum_list">
	<div class="rtj1009_m_forum ren-home-slide-si">
		<div class="ren_fenpinglist cl">
            <div class="menu-left scrollbar-none" id="sidebar"<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> style="top: 45px;"<!--{/if}-->>
                <ul>
                    <!--{loop $_G['cache']['forums'] $forum}-->
                    <!--{if $forum[type]=='group' && $forum[status]}-->
                    <li id="#tab$forum[fid]">$forum[name]</li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
			</div>

				<!--{loop $_G['cache']['forums'] $forum}-->
				<!--{if $forum[type]=='group' && $forum[status]}-->
                <div class="menu-right padding-all j-content" style="display: none;<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> top: 45px;<!--{/if}-->">
					<ul class="cl">
						<!--{loop $_G['cache']['forums'] $forums}-->
						<!--{if $forum[fid] == $forums[fup] && $forums[status]}-->
						<li>
							<a href="forum.php?mod=post&action=newthread&fid=$forums[fid]">
                            <!--{eval
                                $post_forum_icon = DB::result(DB::query("SELECT icon FROM ".DB::table('forum_forumfield')." WHERE fid = '$forums[fid]'"));
                                $ren_forum_ico = rtj1009_ficoisurl($post_forum_icon);
                            }-->
                            <img src="<!--{if $post_forum_icon}-->$ren_forum_ico<!--{else}-->{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg<!--{/if}-->" >
							</a>
							<a href="forum.php?mod=post&action=newthread&fid=$forums[fid]" class="ren_bkbt">
								<span>{$forums[name]}</span>
							</a>
							<a href="forum.php?mod=post&action=newthread&fid=$forums[fid]" class="post-forum-btn ren_bklist_gz">{$rtj1009_lang['ren003']}</a>
						</li>
                            <!--{loop $_G['cache']['forums'] $forumsub}-->
                            <!--{if $forums[fid] == $forumsub[fup] && $forumsub[status]}-->
                            <li class="ren-post-subforums">
                                <a href="forum.php?mod=post&action=newthread&fid=$forumsub[fid]">
                                    <!--{eval
                                        $post_forum_icon = DB::result(DB::query("SELECT icon FROM ".DB::table('forum_forumfield')." WHERE fid = '$forumsub[fid]'"));
                                        $ren_forum_ico = rtj1009_ficoisurl($post_forum_icon);
                                    }-->
                                    <img src="<!--{if $post_forum_icon}-->$ren_forum_ico<!--{else}-->{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg<!--{/if}-->" >
                                </a>
                                <a href="forum.php?mod=post&action=newthread&fid=$forumsub[fid]" class="ren_bkbt">
                                    <span>{$forumsub[name]}</span>
                                </a>
                                <a href="forum.php?mod=post&action=newthread&fid=$forumsub[fid]" class="post-forum-btn ren_bklist_gz">{$rtj1009_lang['ren003']}</a>
                            </li>
                            <!--{/if}-->
                            <!--{/loop}-->
						<!--{/if}-->
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->
				<!--{/loop}-->
			</div>
		</div>
	</div>
</div>

<script type="text/javascript" src='template/rtj1009_app/js/ectouch.js'></script>

<script type="text/javascript">
    $(function($){
        $('#sidebar ul li').click(function(){
            $(this).addClass('active').siblings('li').removeClass('active');
            var index = $(this).index();
            $('.j-content').eq(index).show().siblings('.j-content').hide();
        })
    })
</script>

<script type="text/javascript">
$(function(){
  $(".menu-left li:first").addClass("active");
  $('.menu-right:first').css('display', 'block');

});
</script>


<!--{template common/footer}-->
