<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<input type="hidden" name="trade" value="yes" />
<input type="hidden" name="item_type" value="1" />
<div class="ren_fb_hd ren_fb_sp cl">
	<div class="ren_fb_hdxxs">
		<ul>
		<!--{if $_GET['action']=='newthread'}-->
			<li class="ren_hdxx_li ren_hdxx_he"><div class="ren_hdxx_lx ren-no f-s-13">{lang post_message1}</div></li>
		<!--{/if}-->
			<li class="ren_hdxx_li ren_hdxx_de">
                <div class="ren_hdxx_lx">{lang post_trade_name}<span class="rq"> *</span></div>
                <div class="ren_hdxx_lxnr">
                    <input type="text" name="item_name" id="item_name" class="px oinf" value="$trade[subject]" tabindex="1" />
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_de">
                <div class="ren_hdxx_lx">{lang post_trade_number}<span class="rq"> *</span></div>
                <div class="ren_hdxx_lxnr">
                    <input type="text" name="item_number" id="item_number" class="px" value="$trade[amount]" tabindex="1" />
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_de">
                <div class="ren_hdxx_lx">{$rtj1009_lang['ren081']}<span class="rq"> *</span></div>
                <div class="ren_hdxx_lxnr ren-webki">
                    <select id="item_quality" class="ps" name="item_quality" tabindex="1">
						<option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
						<option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
					</select>
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_de">
                <div class="ren_hdxx_lx">{lang post_trade_transport}<span class="rq"> *</span></div>
                <div class="ren_hdxx_lxnr ren-webki">
					<select name="transport" id="transport" onchange="document.getElementById('logisticssetting').style.display = (document.getElementById('transport').value == 'virtual' ? 'none' : '');" class="ps">
						<option value="virtual" {if $trade['transport'] == 3}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
						<option value="seller" {if $trade['transport'] == 1}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
						<option value="buyer" {if $trade['transport'] == 2}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
						<option value="logistics" {if $trade['transport'] == 4}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
						<option value="offline" {if $trade['transport'] == 0}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
					</select>
                </div>
            </li>
				
			<div id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
				<li class="ren_hdxx_li ren_spxx_de">
					<div class="ren_hdxx_lx">{lang post_trade_transport_mail}</div>
					<div class="ren_hdxx_lxnr">
						<input type="text" name="postage_mail" id="postage_mail" class="px" value="$trade[ordinaryfee]" tabindex="1" />
					</div>
					<div class="ren-flxx-dw">{$rtj1009_lang['ren082']}</div>
				</li>
				<li class="ren_hdxx_li ren_spxx_de">
					<div class="ren_hdxx_lx">{lang post_trade_transport_express}</div>
					<div class="ren_hdxx_lxnr">
						<input type="text" name="postage_express" id="postage_express" class="px" value="$trade[expressfee]" tabindex="1" />
					</div>
					<div class="ren-flxx-dw">{$rtj1009_lang['ren082']}</div>
				</li>
				<li class="ren_hdxx_li ren_spxx_de">
					<div class="ren_hdxx_lx">EMS</div>
					<div class="ren_hdxx_lxnr">
						<input type="text" name="postage_ems" id="postage_ems" class="px" value="$trade[emsfee]" tabindex="1" />
					</div>
					<div class="ren-flxx-dw">{$rtj1009_lang['ren082']}</div>
				</li>
			</div>
			<li class="ren_hdxx_li ren_hdxx_he">
				<div class="ren_hdxx_lx">{lang post_trade_price}<span class="rq"> *</span></div>
				<div class="ren_hdxx_sjfw">
                    <div class="ren_hdxx_sj">
                    	<div class="ren_hdsj_e ren_spxx_de">
                            <div class="ren_hdsj_bt">{lang post_current_price}</div>
                            <div class="ren_hdsj_nr">
                                <input type="text" name="item_price" id="item_price" class="px" value="$trade[price]" tabindex="1" />
                            </div>
							<div class="ren-flxx-dw">{$rtj1009_lang['ren082']}</div>
                        </div>
                    	<div class="ren_hdsj_e ren_hdsj_san ren_spxx_de">
                            <div class="ren_hdsj_bt">{lang post_original_price}</div>
                            <div class="ren_hdsj_nr">
                                <input type="text" name="item_costprice" id="item_costprice" class="px" value="$trade[costprice]" tabindex="1" />
                            </div>
							<div class="ren-flxx-dw">{$rtj1009_lang['ren082']}</div>
                        </div>
                    </div>
                   
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_he">
				<div class="ren_hdxx_lx">{$rtj1009_lang['ren083']}</div>
				<div class="ren_hdxx_sjfw">
                    <div class="ren_hdxx_sj">
                    	<div class="ren_hdsj_e ren_spxx_de">
                            <div class="ren_hdsj_bt">{lang post_current_credit}</div>
                            <div class="ren_hdsj_nr">
                                <input type="text" name="item_credit" id="item_credit" class="px" value="$trade[credit]" tabindex="1" />
                            </div>
							<div class="ren-flxx-dw">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</div>
                        </div>
                    	<div class="ren_hdsj_e ren_hdsj_san ren_spxx_de">
                            <div class="ren_hdsj_bt">{lang post_original_credit}</div>
                            <div class="ren_hdsj_nr">
                                <input type="text" name="item_costcredit" id="item_costcredit" class="px" value="$trade[costcredit]" tabindex="1" />
                            </div>
							<div class="ren-flxx-dw">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</div>
                        </div>
                    </div>
                   
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_de">
                <div class="ren_hdxx_lx">{lang post_trade_paymethod}<span class="rq"> *</span></div>
                <div class="ren_hdxx_lxnr ren-webki">
					<select name="paymethod" id="paymethod" change="display('tenpayseller')" class="ps" tabindex="1">
						<!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
						<option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
					</select>
                </div>
            </li>
			<li class="ren_hdxx_li ren_hdxx_de" style="{if !$trade[tenpayaccount]}display:none{/if}">
				<div class="ren_hdxx_lx">{lang post_trade_tenpay_seller}<span class="rq"> *</span></div>
				<div class="ren_hdxx_lxnr">
					<input type="text" name="tenpay_account" id="tenpay_account" class="px" value="$trade[tenpayaccount]" tabindex="2" />
				</div>
			</li>
			<li class="ren_hdxx_li ren_hdxx_de">
				<div class="ren_hdxx_lx">{lang post_trade_locus}<span class="rq"> *</span></div>
				<div class="ren_hdxx_lxnr">
					<input type="text" name="item_locus" id="item_locus" class="px" value="$trade[locus]" tabindex="1" />
				</div>
			</li>
			<li class="ren_hdxx_li ren_hdxx_de">
				<div class="ren_hdxx_lx">{lang valid_before}<span class="rq"> *</span></div>
				<div class="ren_hdxx_lxnr ren-webki">
					<input type="text" data-toggle='item_expiration' name="item_expiration" id="item_expiration" class="open-calendar" onfocus="this.blur();" autocomplete="off" value="" tabindex="1" />
				</div>
			</li>
			<!--{if $allowpostimg}-->
			<li class="ren_hdxx_li ren_hdxx_me">
                <div class="ren_hdxx_lx">{lang post_trade_picture}</div>
                <div class="ren_hdxx_lxnr">
                      <div class="ren_flpost_img cl">
                          <a href="javascript:;" class="ren_bl_fjy">
                              <input type="file" name="tradeaid_upload" id="tradeaid_upload"/>
                              <em>{$rtj1009_lang['ren068']}</em>
                          </a>
                      </div>
					 <input type="hidden" name="tradeaid" id="tradeaid" {if $tradeattach[attachment]}value="$tradeattach[aid]" {/if}/>
					 <input type="hidden" name="tradeaid_url" id="tradeaid_url" />
                      <div id="tradeaid_image" class="ren_flpost_pic">
                      </div>
					  <script type="text/javascript">
                          $(document).on('change', '#tradeaid_upload', function() {
                                  popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
                      
                                  uploadsuccess = function(data) {
                                      if(data == '') {
                                          popup.open('{lang uploadpicfailed}', 'alert');
                                      }
                                      var dataarr = data.split('|');
                                      if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                          popup.close();
                                              $('#tradeaid').val(dataarr[3]);
                                              $('#tradeaid_url').val(dataarr[5]);
                                              $('.ren_flpost_pic').html('<a href="{$_G[setting][attachurl]}forum/'+dataarr[5]+'"><img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a>');
                                      } else {
                                          var sizelimit = '';
                                          if(dataarr[7] == 'ban') {
                                              sizelimit = '{lang uploadpicatttypeban}';
                                          } else if(dataarr[7] == 'perday') {
                                              sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                          } else if(dataarr[7] > 0) {
                                              sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                          }
                                          popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                      }
                                  };
                      
                                  if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������
                                      
                                      $.buildfileupload({
                                          uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                                          files:this.files,
                                          uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                                          uploadinputname:'Filedata',
                                          maxfilesize:"$swfconfig[max]",
                                          success:uploadsuccess,
                                          error:function() {
                                              popup.open('{lang uploadpicfailed}', 'alert');
                                          return false;
                                          }
                                      });
                      
                                  } else {
                      
                                      $.ajaxfileupload({
                                          url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                                          data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                                          dataType:'text',
                                          fileElementId:'filedata',
                                          success:uploadsuccess,
                                          error: function() {
                                              popup.open('{lang uploadpicfailed}', 'alert');
                                          }
                                      });
                      
                                  }
                          });
                      </script>
                </div>
            </li>
			<!--{/if}-->
			<li class="ren_hdxx_he"><div class="ren_tie_ksf">{$rtj1009_lang['ren069']}</div></li>
			<!--{hook/post_trade_extra}-->
		</ul>
	</div>
</div>

<script type="text/javascript" reload="1">
function tradeaid_upload(aid, url) {
	$('tradeaid_url').value = url;
	updatetradeattach(aid, url, '{$_G['setting']['attachurl']}forum');
}
</script>
