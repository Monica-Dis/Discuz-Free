<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{lang pay_view}</span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
    <div class="ren-view-log ren-attach-view">
        <!--{if $loglist}-->
        <ul class="cl">
            <!--{loop $loglist $log}-->
            <li>
                <a href="home.php?mod=space&uid=$log[uid]&do=profile" class="ren-view-logimg">
                    <img src="<!--{avatar($log[uid], middle, true)}-->">
                    <div class="y time">{$log[$extcreditname]} {$_G[setting][extcredits][$_G[setting][creditstransextra][1]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</div>
                    <div class="ren-view-author">
                        <span>$log[username]</span>
                        <p>$log[dateline]</p>
                    </div>
                </a>
            </li>
            <!--{/loop}-->
        </ul>
        <!--{else}-->
        <div class="ren_ss_wu">
            <i class="icon ren-font">&#xe608;</i>
            <span>{lang attachment_buy_not}</span>
        </div>
        <!--{/if}-->
    </div>
</div>

<!--{template common/footer}-->
