<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->

<script type="text/javascript">
	var allowpostattach = parseInt('{$_G['group']['allowpostattach']}');
	var allowpostimg = parseInt('$allowpostimg');
	var pid = parseInt('$pid');
	var tid = parseInt('$_G[tid]');
	var extensions = '{$_G['group']['attachextensions']}';
	var imgexts = '$imgexts';
	var postminchars = parseInt('$_G['setting']['minpostsize']');
	var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
	var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
	var seccodecheck = parseInt('<!--{if $seccodecheck}-->1<!--{else}-->0<!--{/if}-->');
	var secqaacheck = parseInt('<!--{if $secqaacheck}-->1<!--{else}-->0<!--{/if}-->');
	var typerequired = parseInt('{$_G[forum][threadtypes][required]}');
	var sortrequired = parseInt('{$_G[forum][threadsorts][required]}');
	var special = parseInt('$special');
	var isfirstpost = <!--{if $isfirstpost}-->1<!--{else}-->0<!--{/if}-->;
	var allowposttrade = parseInt('{$_G['group']['allowposttrade']}');
	var allowpostreward = parseInt('{$_G['group']['allowpostreward']}');
	var allowpostactivity = parseInt('{$_G['group']['allowpostactivity']}');
	var sortid = parseInt('$sortid');
	var special = parseInt('$special');
	var fid = $_G['fid'];
	var postaction = '{$_GET['action']}';
	var ispicstyleforum = <!--{if $_G['forum']['picstyle']}-->1<!--{else}-->0<!--{/if}-->;
</script>

<!--{if $_GET[action] == 'edit'}--><!--{eval $editor[value] = $postinfo[message];}--><!--{else}--><!--{eval $editor[value] = $message;}--><!--{/if}-->

<!--{if $isfirstpost && $sortid}-->
	<script type="text/javascript">
		var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
	</script>
    <script src="template/rtj1009_app/js/threadsort.js?{VERHASH}"></script>
<!--{/if}-->
<script type="text/javascript" src="template/rtj1009_app/js/jQuery.rTabs.js"></script>
<script type="text/javascript" src="template/rtj1009_app/js/insertsome.js"></script>

<!--{if $_GET['inajax'] == 1 && $_GET[action] == 'reply'}-->
<div class="tip ren-hf-post">
	<form method="post" id="postform" 
				{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
				{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
				{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
				{/if}>
	<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
	<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
		<!--{if $_GET['action'] == 'edit'}-->
			<input type="hidden" name="delattachop" id="delattachop" value="0" />
		<!--{/if}-->
	<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
	
	<input type="hidden" name="wysiwyg" id="{$editorid}_mode" value="$editormode" />
	<!--{if $_GET[action] == 'reply'}-->
		<input type="hidden" name="noticeauthor" value="$noticeauthor" />
		<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
		<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
		<!--{if $reppid}-->
			<input type="hidden" name="reppid" value="$reppid" />
		<!--{/if}-->
		<!--{if $_GET[reppost]}-->
			<input type="hidden" name="reppost" value="$_GET[reppost]" />
		<!--{elseif $_GET[repquote]}-->
			<input type="hidden" name="reppost" value="$_GET[repquote]" />
		<!--{/if}-->
	<!--{/if}-->
	<!--{if $_GET[action] == 'edit'}-->
		<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$pid" />
		<input type="hidden" name="page" value="$_GET[page]" />
	<!--{/if}-->
	
	<!--{if $special}-->
		<input type="hidden" name="special" value="$special" />
	<!--{/if}-->
	<!--{if $specialextra}-->
		<input type="hidden" name="specialextra" value="$specialextra" />
	<!--{/if}-->
		<div class="post_from ren_kshf cl">
			<div class="cl">
			<!--{if $sortid}-->
				<input type="hidden" name="sortid" value="$sortid" />
			<!--{/if}-->
				<div class="ren-post-nav cl">
					<div class="ren-post-in z">
						<span class="info_label">{lang reply}</span>
						<span class="info_value">$thaquote['author']</span>
					</div>
					<div class="y ren_list_nav">
						<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$reppid&page=$page" class="ren_nav_fb">{lang post_advancemode}</a>
					</div>
				</div>
				<div class="ren_post_nr cl">
				<textarea class="ren_post_nrk" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" cols="80" rows="3"  placeholder="{$rtj1009_lang['ren053']}" fwin="reply">$postinfo[message]</textarea>
				</div>
			</div>
			<script type="text/javascript" src="template/rtj1009_app/js/smohan.face.js"></script>
			<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
			<!--{subtemplate common/seccheck}-->
			<!--{/if}-->
		</div>
		<dd>
			<input type="submit" name="replysubmit" id="replysubmit" value="{lang join_thread}" class="formdialog button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{else}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm"><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}-->
			</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content">
	<div class="rtj1009_post rtj1009_m_main cl">
	<!--{if $_G['forum']['threadsorts'][types] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostdebate'] || $_G['group']['allowpostactivity'] || $_G['group']['allowposttrade']}-->
		<!--{if $_GET[action] == 'newthread'}-->
		<div class="rtj1009_wz_nav">
			<ul class="cl">
			
				<!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
					<li$postspecialcheck[0]>
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a>
					</li>
				<!--{/if}-->
				
				<!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
					<li{if $sortid == $tsortid} class="a"{/if}>
					  <a href="forum.php?mod=post&action=newthread&sortid=$tsortid&fid=$_G[fid]"><!--{echo strip_tags($name);}--></a>
					</li>
				<!--{/loop}-->
				
				<!--{if $_G['group']['allowpostpoll']}-->
					<li$postspecialcheck[1]>
						 <a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['group']['allowpostreward']}-->
					<li$postspecialcheck[3]>
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['group']['allowpostdebate']}-->
					<li$postspecialcheck[5]>
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['group']['allowpostactivity']}-->
					<li$postspecialcheck[4]>
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['group']['allowposttrade']}-->
					<li$postspecialcheck[2]>
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['setting']['threadplugins']}-->
					<!--{loop $_G['forum']['threadplugin'] $tpid}-->
						<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
							<li{if $specialextra==$tpid} class="a"{/if}>
								<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a>
							</li>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
	<!--{/if}-->   
	  <!--{eval $adveditor = $isfirstpost && $special || $special == 2 && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' && $thread['special'] == 2);}--> 
	  <!--{eval $advmore = !$showthreadsorts && !$special || $_GET['action'] == 'reply' && empty($_GET['addtrade']) || $_GET['action'] == 'edit' && !$isfirstpost && ($thread['special'] == 2 && !$special || $thread['special'] != 2);}-->
	<form method="post" id="postform" 
				{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
				{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
				{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
				{/if}>
	<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
	<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
		<!--{if $_GET['action'] == 'edit'}-->
			<input type="hidden" name="delattachop" id="delattachop" value="0" />
		<!--{/if}-->
	<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
	
	<input type="hidden" name="wysiwyg" id="{$editorid}_mode" value="$editormode" />
	<!--{if $_GET[action] == 'reply'}-->
		<input type="hidden" name="noticeauthor" value="$noticeauthor" />
		<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
		<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
		<!--{if $reppid}-->
			<input type="hidden" name="reppid" value="$reppid" />
		<!--{/if}-->
		<!--{if $_GET[reppost]}-->
			<input type="hidden" name="reppost" value="$_GET[reppost]" />
		<!--{elseif $_GET[repquote]}-->
			<input type="hidden" name="reppost" value="$_GET[repquote]" />
		<!--{/if}-->
	<!--{/if}-->
	<!--{if $_GET[action] == 'edit'}-->
		<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$pid" />
		<input type="hidden" name="page" value="$_GET[page]" />
	<!--{/if}-->
	
	<!--{if $special}-->
		<input type="hidden" name="special" value="$special" />
	<!--{/if}-->
	<!--{if $specialextra}-->
		<input type="hidden" name="specialextra" value="$specialextra" />
	<!--{/if}-->
	
	

		<!--{subtemplate forum/post_editor_extra}-->
		<div id="tab3" class="tab ren-post-ebo cl">
			<ul class="tab-nav j-tab-nav cl">
				<li><a href="javascript:;" class="face"><i class="icon ren-font">&#xe615;</i><p>{$rtj1009_lang['ren058']}</p></a></li>
				<li><a href="javascript:;"><i class="icon ren-font">&#xe625;</i><p>{$rtj1009_lang['ren145']}</p></a></li>
                <!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
				<li><a href="javascript:;"><i class="icon ren-font">&#xe6ad;</i><p>{$rtj1009_lang['ren146']}</p></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowposttag']}-->
				<li><a href="javascript:;" class="qiandao"><i class="icon ren-font">&#xe6bb;</i><p>{$rtj1009_lang['ren147']}</p></a></li>
                <!--{/if}-->
				<!--{if $_G['group']['maxprice'] && !$special}-->
				<li><a href="javascript:;" class="qiandao"><i class="icon ren-font">&#xe622;</i><p>{$rtj1009_lang['ren148']}</p></a></li>
				<!--{/if}-->
				<li><a href="javascript:;" class="shezhi"><i class="icon ren-font">&#xe666;</i><p>{$rtj1009_lang['ren149']}</p></a></li>
			</ul>
			<div class="tab-con ren-post-ed cl">
			<!--{subtemplate forum/post_editor_attribute}-->
			</div>
		</div>
		<script type="text/javascript">
			$(function() {
				$("#tab3").rTabs({
					animation : 'fadein',
					bind : 'click'
				});
			})
			$(function() {
				$("#tab5").rTabs({
					animation : 'fadein',
					bind : 'click'
				});
			})
            $(function() {
                $("#tab6").rTabs({
                    btnClass : '.tabbtn',
                    conClass : '.tabcon',
                    animation : 'fadein',
                    bind : 'click'
                });
            })
		</script>
		<span class="ren_ft_anniu"><button type="submit" id="postsubmit" class="ren_ft_an" disable="false"><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></button></span>
	</form>
	</div>
</div>
<!--{/if}-->
<script type="text/javascript">
	(function() {
		var needsubject = needmessage = false;

		<!--{if $_GET[action] == 'reply'}-->
			needsubject = true;
		<!--{elseif $_GET[action] == 'edit'}-->
			needsubject = needmessage = true;
		<!--{/if}-->

		$('#needmessage').on('scroll', function() {
			var obj = $(this);
			if(obj.scrollTop() > 0) {
				obj.attr('rows', parseInt(obj.attr('rows'))+2);
			}
		}).scrollTop($(document).height());
	 })();
</script>
<script type="text/javascript" src="template/rtj1009_app/js/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="template/rtj1009_app/js/buildfileupload.js?{VERHASH}"></script>
<!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') && $rtj1009_mobilecp['wx_uploadimg']}-->
<script type="text/javascript">
    var images = {
        localId: [],
        serverId: [],
    }
    $(document).ready(function() {
        wx.ready(function(){
            $("#filedata").click(function () {
                wx.chooseImage({
                    count: 9,
                    success: function(res){
                        images.localId = res.localIds;
                        var i = 0;
                        var len = images.localId.length;
                        if(len > 0){
                            wxupload();
                        }

                        function wxupload(){
                            wx.uploadImage({
                                localId: images.localId[i],
                                success: function(res){
                                    images.serverId.push(res.serverId);
                                    i++;
                                    if (i < len) {
                                        wxupload(images.localId[i]);
                                    } else {
                                        popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
                                        $.ajax({
                                            type: "POST",
                                            url: "plugin.php?id=rtj1009_mobilecp:rtj1009_wxupload",
                                            data: {uid:"$_G[uid]", fid:"{$_G[fid]}", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->", serverId:images.serverId},
                                            dataType: "json",
                                            success: function(data){
                                                if (!data || data.length < 1) {
                                                    popup.open('{lang uploadpicfailed}', 'alert');
                                                    return false;
                                                }
                                                for (var i=0; i<data.length; i++) {
                                                    var dataarr = data[i].split('|');
                                                    if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                                        popup.close();
                                                        $('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;" onclick="ren_charu(\'[attachimg]'+dataarr[3]+'[/attachimg]\')"><img style="height:60px;width:60px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /><p class="charu">{$rtj1009_lang[ren195]}</p></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>' +
                                                        '');
                                                    } else {
                                                        var sizelimit = '';
                                                        if(dataarr[7] == 'ban') {
                                                            sizelimit = '{lang uploadpicatttypeban}';
                                                        } else if(dataarr[7] == 'perday') {
                                                            sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                                        } else if(dataarr[7] > 0) {
                                                            sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                                        }
                                                        popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                                    }
                                                    popup.open((i+1 + '{$rtj1009_lang[ren213]}'), 'alert');
                                                }
                                            }
                                        });
                                    }
                                }
                            });
                        }
                    }
                });
                return false;
            });
        });
    });

    <!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
    geo.getcurrentposition();
    <!--{/if}-->
    $('#postsubmit').on('click', function() {
        var obj = $(this);
        popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

        var postlocation = '';
        if(geo.errmsg === '' && geo.loc) {
            postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
        }

        $.ajax({
            type:'POST',
            url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
            data:form.serialize(),
            dataType:'xml'
        })
            .success(function(s) {
                popup.open(s.lastChild.firstChild.nodeValue);
            })
            .error(function() {
                popup.open('{lang networkerror}', 'alert');
            });
        return false;
    });

    $(document).on('click', '.del', function() {
        var obj = $(this);
        $.ajax({
            type:'GET',
            url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
        })
            .success(function(s) {
                obj.parent().remove();
            })
            .error(function() {
                popup.open('{lang networkerror}', 'alert');
            });
        return false;
    });
</script>
<!--{else}-->
<script type="text/javascript">
    var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
    var STATUSMSG = {
        '-1' : '{lang uploadstatusmsgnag1}',
        '0' : '{lang uploadstatusmsg0}',
        '1' : '{lang uploadstatusmsg1}',
        '2' : '{lang uploadstatusmsg2}',
        '3' : '{lang uploadstatusmsg3}',
        '4' : '{lang uploadstatusmsg4}',
        '5' : '{lang uploadstatusmsg5}',
        '6' : '{lang uploadstatusmsg6}',
        '7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
        '8' : '{lang uploadstatusmsg8}',
        '9' : '{lang uploadstatusmsg9}',
        '10' : '{lang uploadstatusmsg10}',
        '11' : '{lang uploadstatusmsg11}'
    };
    var form = $('#postform');
    $(document).on('change', '#filedata', function() {
        popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

        uploadsuccess = function(data) {
            if(data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = data.split('|');
            if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                popup.close();
                $('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;" onclick="ren_charu(\'[attachimg]'+dataarr[3]+'[/attachimg]\')"><img style="height:60px;width:60px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /><p class="charu">{$rtj1009_lang['ren195']}</p></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>' +
                '');
            } else {
                var sizelimit = '';
                if(dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if(dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                } else if(dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        };


        if(typeof FileReader != 'undefined' && this.files[0]) {//note 支持html5上传新特性

            for (var i=0;i<this.files.length;i++ ) {
                var file_data = [];
                file_data.push(this.files[i]);
                $.buildfileupload({
                    uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                    files:file_data,
                    uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                    uploadinputname:'Filedata',
                    maxfilesize:"$swfconfig[max]",
                    success:uploadsuccess,
                    error:function() {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                });
            }

        } else {

            $.ajaxfileupload({
                url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                dataType:'text',
                fileElementId:'filedata',
                success:uploadsuccess,
                error: function() {
                    popup.open('{lang uploadpicfailed}', 'alert');
                }
            });

        }
    });

    <!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
    geo.getcurrentposition();
    <!--{/if}-->
    $('#postsubmit').on('click', function() {
        var obj = $(this);
        popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

        var postlocation = '';
        if(geo.errmsg === '' && geo.loc) {
            postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
        }

        $.ajax({
            type:'POST',
            url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
            data:form.serialize(),
            dataType:'xml'
        })
            .success(function(s) {
                popup.open(s.lastChild.firstChild.nodeValue);
            })
            .error(function() {
                popup.open('{lang networkerror}', 'alert');
            });
        return false;
    });

    $(document).on('click', '.del', function() {
        var obj = $(this);
        $.ajax({
            type:'GET',
            url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
        })
            .success(function(s) {
                obj.parent().remove();
            })
            .error(function() {
                popup.open('{lang networkerror}', 'alert');
            });
        return false;
    });

</script>
<!--{/if}-->



<script type="text/javascript">
$(function (){
	$("a.face").smohanfacebox({
		Event : "click",	//触发事件
		divid : "Smohan_FaceBox", //外层DIV ID
		textid : "needmessage" //文本框 ID
	});
});

function ren_charu(value) {
    $('#needmessage').inserts(value);
}
</script>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->