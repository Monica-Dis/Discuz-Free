<?php

/**
 *      [-] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_portalcategory.inc.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}



$ren_url = 'plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_mobilecp&pmod=rtj1009_portalcategory';
$plug_url = ADMINSCRIPT . '?action='.$ren_url.'';

loadcache('portalcategory');
$portalcategory = $_G['cache']['portalcategory'];


function rtj1009_block($block) {
    foreach ($block as $value) {
        $arr .= '<!--{block/'.$value.'}-->'.PHP_EOL;
    }
    return $arr;
}

if (submitcheck('submit')) {
    $data = array();

    foreach ($_GET['rtj1009_block'] as $key => $value) {
        $data['cname'] = $key;
        $data['ctype'] = '1';
        $data['dateline'] = TIMESTAMP;
        $data['data'] = $value;
        $data['data'] = str_replace(array("\r\n", "\r", "\n"),',', str_replace(array('<!--{block/','}-->'),'', $data['data']));
        $data['data'] = explode(',', $data['data']);
        $data['data'] = array_filter($data['data']);
//        var_dump($data['cname'], $data['data']);
        savecache($data['cname'], $data['data']);
    }
    cpmsg(lang('plugin/rtj1009_mobilecp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else {
    showtips(lang('plugin/rtj1009_mobilecp', 'rtj1009_0225'),'',true,lang('plugin/rtj1009_mobilecp', 'rtj1009_0208'));
    showformheader(''.$ren_url.'', 'enctype');
    showtableheader();
    showsubtitle(array(
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0222'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0223'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0224'),
    ));

    foreach ($portalcategory as $key => $value) {
        loadcache(array('block_portalcategory_'.$value['catid']));
        if ($value['upid'] == 0) {
            $block = rtj1009_block($_G['cache']['block_portalcategory_'.$value['catid']]);
            showtablerow('', '', array(
                "$value[catid]",
                "$value[catname]",
                "<textarea rows=\"6\" onkeyup=\"textareasize(this, 0)\" onkeydown=\"textareakey(this, event)\" name=\"rtj1009_block[block_portalcategory_$value[catid]]\" id=\"rtj1009_block[block_portalcategory_$value[catid]]\" cols=\"50\" class=\"tarea\" size=\"10\">$block</textarea>",
            ));
        } else {
            $block = rtj1009_block($_G['cache']['block_portalcategory_'.$value['catid']]);
            showtablerow('', array('style="color: red"', 'style="color: red"', ''), array(
                "$value[catid]",
                "$value[catname]",
                "<textarea rows=\"6\" onkeyup=\"textareasize(this, 0)\" onkeydown=\"textareakey(this, event)\" name=\"rtj1009_block[block_portalcategory_$value[catid]]\" id=\"rtj1009_block[block_portalcategory_$value[catid]]\" cols=\"50\" class=\"tarea color\" size=\"10\">$block</textarea>",
            ));
        }
    }
    showsubmit('submit', lang('plugin/rtj1009_mobilecp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/
}
