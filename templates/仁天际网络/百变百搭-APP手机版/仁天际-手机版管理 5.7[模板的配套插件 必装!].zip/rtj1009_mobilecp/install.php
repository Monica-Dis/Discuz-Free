<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_rtj1009_m_liststyle` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bid` int(10) DEFAULT NULL,
  `style` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_rtj1009_m_menu` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `type` smallint(6) NOT NULL DEFAULT '0',
    `displayorder` smallint(6) NOT NULL DEFAULT '0', 
    `title` varchar(32) NOT NULL DEFAULT '',
    `icon` varchar(32) NOT NULL DEFAULT '',
    `icons` varchar(32) NOT NULL DEFAULT '',
    `url` varchar(255) NOT NULL Default '', 
    PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_rtj1009_m_sidebar` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `type` smallint(6) NOT NULL DEFAULT '0',
    `displayorder` smallint(6) NOT NULL DEFAULT '0', 
    `title` varchar(32) NOT NULL DEFAULT '',
    `icon` varchar(32) NOT NULL DEFAULT '',
    `color` varchar(32) NOT NULL DEFAULT '',
    `url` varchar(255) NOT NULL Default '', 
    PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_rtj1009_m_prmenu` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `type` smallint(6) NOT NULL DEFAULT '0',
    `displayorder` smallint(6) NOT NULL DEFAULT '0', 
    `title` varchar(32) NOT NULL DEFAULT '',
    `icon` varchar(32) NOT NULL DEFAULT '',
    `color` varchar(32) NOT NULL DEFAULT '',
    `url` varchar(255) NOT NULL Default '', 
    PRIMARY KEY (`id`)
)ENGINE=MyISAM;

EOF;

runquery($sql);

$menulist = C::t('#rtj1009_mobilecp#rtj1009_m_menu')->fetch_all();
$sidelist = C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->fetch_all();
$prlist = C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->fetch_all();

if (!$menulist) {
    $data = array(
        '1' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0001'),
            'icon' => '&#xe605;',
            'icons' => '&#xe616;',
            'url' => 'portal.php?mod=index',
        ),
        '2' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0002'),
            'icon' => '&#xe6ef;',
            'icons' => '&#xe6cf;',
            'url' => 'forum.php?forumlist=1',
        ),
        '3' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0003'),
            'icon' => '&#xe619;',
            'icons' => '&#xe619;',
            'url' => 'forum.php?mod=misc&action=nav',
        ),
        '4' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0004'),
            'icon' => '&#xe67d;',
            'icons' => '&#xe61b;',
            'url' => 'home.php?mod=space&do=notice',
        ),
        '5' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0005'),
            'icon' => '&#xe602;',
            'icons' => '&#xe644;',
            'url' => 'home.php?mod=space&do=profile&mycenter=1',
        ),
    );


    foreach($data as $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_menu')->insert($value);
    }
}
if (!$sidelist) {
    $sidedata = array(
        '1' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0009'),
            'icon' => '&#xe601;',
            'color' => '#73C7EF',
            'url' => 'portal.php?mod=index',
        ),
        '2' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0010'),
            'icon' => '&#xe6cf;',
            'color' => '#FFA800',
            'url' => 'forum.php?forumlist=1',
        ),
        '3' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0011'),
            'icon' => '&#xeb31;',
            'color' => '#FA7D5F',
            'url' => 'forum.php?mod=guide',
        ),
        '4' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0012'),
            'icon' => '&#xe743;',
            'color' => '#008ACB',
            'url' => 'group.php',
        ),
        '5' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0013'),
            'icon' => '&#xe763;',
            'color' => '#A4BB37',
            'url' => '#',
        ),
        '6' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0014'),
            'icon' => '&#xe68d;',
            'color' => '#FA6567',
            'url' => 'search.php?mod=forum',
        ),
        '7' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0015'),
            'icon' => '&#xe600;',
            'color' => '#45A29F',
            'url' => 'home.php?mod=space&do=profile&mycenter=1',
        ),
        '8' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0016'),
            'icon' => '&#xe61b;',
            'color' => '#F34548',
            'url' => 'home.php?mod=space&do=notice',
        ),
        '9' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0017'),
            'icon' => '&#xe619;',
            'color' => '#61CC73',
            'url' => 'home.php?mod=space&do=thread&view=me',
        ),
        '10' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0018'),
            'icon' => '&#xe843;',
            'color' => '#43A6DF',
            'url' => 'home.php?mod=task',
        ),
        '11' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0019'),
            'icon' => '&#xe679;',
            'color' => '#FA7D5F',
            'url' => 'forum.php?forumlist=1&mobile=no',
        ),
        '12' => array (
            'status' => 0,
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe679;',
            'color' => '#FA7D5F',
            'url' => '#',
        ),
        '13' => array (
            'status' => 0,
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe679;',
            'color' => '#FA7D5F',
            'url' => '#',
        ),
    );

    foreach($sidedata as $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->insert($value);
    }
}
if (!$prlist) {
    $prdata = array(
        '1' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0020'),
            'icon' => '&#xe605;',
            'color' => '#7BBF1E',
            'url' => 'home.php?mod=space&do=profile',
        ),
        '2' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0021'),
            'icon' => '&#xe62c;',
            'color' => '#008EEB',
            'url' => 'home.php?mod=space&do=thread&view=me',
        ),
        '3' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0022'),
            'icon' => '&#xe603;',
            'color' => '#FA6567',
            'url' => 'home.php?mod=space&do=favorite',
        ),
        '4' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0023'),
            'icon' => '&#xe67f;',
            'color' => '#61CC73',
            'url' => 'home.php?mod=space&do=friend',
        ),
        '5' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0024'),
            'icon' => '&#xe62f;',
            'color' => '#43A6DF',
            'url' => 'home.php?mod=space&do=blog&view=me',
        ),
        '6' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0025'),
            'icon' => '&#xe6eb;',
            'color' => '#F34548',
            'url' => 'home.php?mod=space&do=album&view=me',
        ),
        '7' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0026'),
            'icon' => '&#xe662;',
            'color' => '#FFA800',
            'url' => 'home.php?mod=space&do=doing&view=me',
        ),
        '8' => array (
            'type' => 1,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0027'),
            'icon' => '&#xe744;',
            'color' => '#FA7D5F',
            'url' => 'home.php?mod=space&do=wall',
        ),
        '9' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0030'),
            'icon' => '&#xe676;',
            'color' => '#F34548',
            'url' => 'home.php?mod=follow&do=follower',
        ),
        '10' => array (
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0031'),
            'icon' => '&#xe62a;',
            'color' => '#61CC73',
            'url' => 'home.php?mod=space&do=profile',
        ),
        '11' => array (
            'status' => 0,
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe63f;',
            'color' => '#7BBF1E',
            'url' => '#',
        ),
        '12' => array (
            'status' => 0,
            'type' => 2,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe60e;',
            'color' => '#FA6567',
            'url' => '#',
        ),
        '13' => array (
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0032'),
            'icon' => '&#xe631;',
            'color' => '#FA7D5F',
            'url' => 'home.php?mod=spacecp&ac=credit',
        ),
        '14' => array (
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0033'),
            'icon' => '&#xe843;',
            'color' => '#43A6DF',
            'url' => 'home.php?mod=task',
        ),
        '15' => array (
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0034'),
            'icon' => '&#xe61a;',
            'color' => '#45A29F',
            'url' => 'home.php?mod=spacecp&ac=profile&op=password',
        ),
        '16' => array (
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0035'),
            'icon' => '&#xe666;',
            'color' => '#FFA800',
            'url' => 'home.php?mod=spacecp',
        ),
        '17' => array (
            'status' => 0,
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe63f;',
            'color' => '#7BBF1E',
            'url' => '#',
        ),
        '18' => array (
            'status' => 0,
            'type' => 3,
            'title' => lang('plugin/rtj1009_mobilecp', 'rtj1009_0122'),
            'icon' => '&#xe60e;',
            'color' => '#FA6567',
            'url' => '#',
        ),
    );

    foreach($prdata as $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->insert($value);
    }
}



$identifier = 'rtj1009_mobilecp';
/* 删除文件 */
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
$finish = true;
?>