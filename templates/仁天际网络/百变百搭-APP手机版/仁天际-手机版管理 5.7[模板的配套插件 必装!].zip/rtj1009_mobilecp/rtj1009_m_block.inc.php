<?php

/**
 *      [-] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_m_forumdisplay.inc.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}



$ren_url = 'plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_mobilecp&pmod=rtj1009_m_block';
$plug_url = ADMINSCRIPT . '?action='.$ren_url.'';

loadcache(array('block_portal','block_faxian','block_forum_yi','block_forum_e','block_group','block_sosuo','block_topic','block_viewthread','block_forumdisplay_top','block_forumdisplay_zd','block_viewthread_top','block_viewthread_footer','block_viewthread_ratex','block_post_juhe','block_post_juhebage','block_portal_vievtop','block_portal_vievzo','block_portal_vievfoo','block_forum_si'));


function rtj1009_block($block) {
    foreach ($block as $value) {
        $arr .= '<!--{block/'.$value.'}-->'.PHP_EOL;
    }
    return $arr;
}


if (submitcheck('menulistsubmit')) {
    $data = array();
    foreach ($_GET['rtj1009_app_block'] as $key => $value) {
        $data['cname'] = $key;
        $data['ctype'] = '1';
        $data['dateline'] = TIMESTAMP;
        $data['data'] = $value;
        $data['data'] = str_replace(array("\r\n", "\r", "\n"),',', str_replace(array('<!--{block/','}-->'),'', $data['data']));
        $data['data'] = explode(',', $data['data']);
        $data['data'] = array_filter($data['data']);
        savecache($data['cname'], $data['data']);
    }
    cpmsg(lang('plugin/rtj1009_mobilecp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else {
    showtips(lang('plugin/rtj1009_mobilecp', 'rtj1009_0209'),'',true,lang('plugin/rtj1009_mobilecp', 'rtj1009_0208'));
    showformheader(''.$ren_url.'', 'enctype');
    showtableheader();

    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0200'), 'rtj1009_app_block[block_portal]', rtj1009_block($_G['cache']['block_portal']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0202'), 'rtj1009_app_block[block_forum_yi]', rtj1009_block($_G['cache']['block_forum_yi']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0203'), 'rtj1009_app_block[block_forum_e]', rtj1009_block($_G['cache']['block_forum_e']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0226'), 'rtj1009_app_block[block_forum_si]', rtj1009_block($_G['cache']['block_forum_si']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0210'), 'rtj1009_app_block[block_forumdisplay_top]', rtj1009_block($_G['cache']['block_forumdisplay_top']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0211'), 'rtj1009_app_block[block_forumdisplay_zd]', rtj1009_block($_G['cache']['block_forumdisplay_zd']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0212'), 'rtj1009_app_block[block_viewthread_top]', rtj1009_block($_G['cache']['block_viewthread_top']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0214'), 'rtj1009_app_block[block_viewthread_ratex]', rtj1009_block($_G['cache']['block_viewthread_ratex']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0207'), 'rtj1009_app_block[block_viewthread]', rtj1009_block($_G['cache']['block_viewthread']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0213'), 'rtj1009_app_block[block_viewthread_footer]', rtj1009_block($_G['cache']['block_viewthread_footer']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0201'), 'rtj1009_app_block[block_faxian]', rtj1009_block($_G['cache']['block_faxian']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0204'), 'rtj1009_app_block[block_group]', rtj1009_block($_G['cache']['block_group']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0205'), 'rtj1009_app_block[block_sosuo]', rtj1009_block($_G['cache']['block_sosuo']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0206'), 'rtj1009_app_block[block_topic]', rtj1009_block($_G['cache']['block_topic']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0216'), 'rtj1009_app_block[block_post_juhe]', rtj1009_block($_G['cache']['block_post_juhe']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0217'), 'rtj1009_app_block[block_post_juhebage]', rtj1009_block($_G['cache']['block_post_juhebage']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0218'), 'rtj1009_app_block[block_portal_vievtop]', rtj1009_block($_G['cache']['block_portal_vievtop']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0220'), 'rtj1009_app_block[block_portal_vievzo]', rtj1009_block($_G['cache']['block_portal_vievzo']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');
    showsetting(lang('plugin/rtj1009_mobilecp', 'rtj1009_0219'), 'rtj1009_app_block[block_portal_vievfoo]', rtj1009_block($_G['cache']['block_portal_vievfoo']), 'textarea','','',lang('plugin/rtj1009_mobilecp', 'rtj1009_0215'),'size="10"');

    showsubmit('menulistsubmit', lang('plugin/rtj1009_mobilecp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/
}
//From: dis'.'m.tao'.'bao.com
?>