<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


loadcache('plugin');
loadcache('ren_access_token');

$ren_access_token = $_G['cache']['ren_access_token'];
$access_token = $ren_access_token['access_token'];
$serverId = $ren_wx_updata = array();
$serverId = $_GET['serverId'];

if ($access_token) {
	require_once libfile('class/image');
	require_once libfile('function/upload');
	$upload = new discuz_upload();
	$attach['ext'] = 'jpg';
	if (!empty($serverId) && is_array($serverId)) {
		foreach ($serverId as $tempvalue) {
            $imageurl = "https://api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$tempvalue";
            $content = dfsockopen($imageurl);
			if (!$content) {
				$content = file_get_contents($imageurl);
			}

			if (!empty($content) && substr($content, 0, 11) != '{"errcode":') {
				if ($content) {
                    $patharr = explode('/', $imageurl);
                    $attach['name'] =  uniqid('wx_upload' . time());
                    $attach['thumb'] = '';

                    $attach['isimage'] = 1;
                    $attach['extension'] = $upload -> get_target_extension($attach['ext']);
                    $attach['attachdir'] = $upload -> get_target_dir('forum');
                    $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
                    $attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];

                    if(!@$fp = fopen($attach['target'], 'wb')) {
                        continue;
                    } else {
                        flock($fp, 2);
                        fwrite($fp, $content);
                        fclose($fp);
                    }

                    if(!$upload->get_image_info($attach['target'])) {
                        @unlink($attach['target']);
                        continue;
                    }
                    $attach['size'] = filesize($attach['target']);
                    $upload->attach = $attach;

                    if($_G['group']['maxattachsize'] && $upload->attach['size'] > $_G['group']['maxattachsize']) {
                        $error_sizelimit = $_G['group']['maxattachsize'];
                        wx_uploadmsg(3, 0, '', '', $error_sizelimit);
                    }

                    loadcache('attachtype');
                    if($_G['fid'] && isset($_G['cache']['attachtype'][$_G['fid']][$upload->attach['ext']])) {
                        $maxsize = $_G['cache']['attachtype'][$_G['fid']][$upload->attach['ext']];
                    } elseif(isset($_G['cache']['attachtype'][0][$upload->attach['ext']])) {
                        $maxsize = $_G['cache']['attachtype'][0][$upload->attach['ext']];
                    }
                    if(isset($maxsize)) {
                        if(!$maxsize) {
                            $error_sizelimit = 'ban';
                            wx_uploadmsg(4, 0, '', '', $error_sizelimit);
                        } elseif($upload->attach['size'] > $maxsize) {
                            $error_sizelimit = $maxsize;
                            wx_uploadmsg(5, 0, '', '', $error_sizelimit);
                        }
                    }

                    if($upload->attach['size'] && $_G['group']['maxsizeperday']) {
                        $todaysize = getuserprofile('todayattachsize') + $upload->attach['size'];
                        if($todaysize >= $_G['group']['maxsizeperday']) {
                            $this->error_sizelimit = 'perday|'.$_G['group']['maxsizeperday'];
                            @unlink($attach['target']);
                            wx_uploadmsg(11, 0, '', '', $error_sizelimit);
                        }
                    }
                    
                    $thumb = $width = 0;
                    if($upload->attach['isimage']) {
                        if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                            $width = $image->imginfo['width'];
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                        if($_G['setting']['thumbstatus']) {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                            $width = $image->imginfo['width'];
                        }
                        if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                            list($width) = @getimagesize($upload->attach['target']);
                        }
                        if($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
                            $image = new image();
                            $image->Watermark($attach['target'], '', 'forum');
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                    }

                    $aid = getattachnewaid();
                    $insert = array(
                        'aid' => $aid,
                        'dateline' => $_G['timestamp'],
                        'filename' => dhtmlspecialchars(censor($upload->attach['name'])),
                        'filesize' => $upload->attach['size'],
                        'attachment' => $upload->attach['attachment'],
                        'isimage' => $upload->attach['isimage'],
                        'uid' => $_G['uid'],
                        'thumb' => $thumb,
                        'remote' => 0,
                        'width' => $width,
                    );
                    C::t('forum_attachment_unused')->insert($insert);
                    wx_uploadmsg(0, $aid, $upload->attach['attachment'], $upload->attach['name']);
			    }
		    }
	    }
        echo json_encode($ren_wx_updata);
        exit(0);
    }
}
function wx_uploadmsg($statusid, $aid, $attachment, $name, $error_sizelimit = 0) {
    global $ren_wx_updata;
    $ren_wx_updata[] = 'DISCUZUPLOAD|1|' . $statusid . '|' . $aid . '|1|' . $attachment . '|' . $name . '|' . $error_sizelimit;
}

