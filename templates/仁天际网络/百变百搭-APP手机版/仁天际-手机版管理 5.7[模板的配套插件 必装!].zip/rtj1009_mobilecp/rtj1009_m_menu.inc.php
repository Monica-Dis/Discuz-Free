<?php

/**
 *      [仁天际-PC模板管理] (C)2001-2099 DisM.Taobao.Com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_m_menu.inc.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$ren_url = 'plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_mobilecp&pmod=rtj1009_m_menu';
$plug_url = ADMINSCRIPT . '?action='.$ren_url.'';

$menulist = C::t('#rtj1009_mobilecp#rtj1009_m_menu')->fetch_all();
$sidelist = C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->fetch_all();
$prlist = C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->fetch_all();
function cmp($a, $b) {
    return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}
if (submitcheck('menulistsubmit')) {
    foreach ($_GET['title'] as $key => $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_menu')->update($key, array(
            'icon' => $_GET['icon'][$key],
            'icons' => $_GET['icons'][$key],
            'displayorder' => $_GET['displayorder'][$key],
            'title' => $_GET['title'][$key],
            'url' => $_GET['url'][$key],
            'type' => $_GET['type'][$key],
            'status' => $_GET['status'][$key] ? 1 : 0
        ));
    }
    cpmsg(lang('plugin/rtj1009_mobilecp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else if (submitcheck('sidesubmit')) {
    foreach ($_GET['title'] as $key => $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->update($key, array(
            'icon' => $_GET['icon'][$key],
            'color' => $_GET['color'][$key],
            'displayorder' => $_GET['displayorder'][$key],
            'title' => $_GET['title'][$key],
            'url' => $_GET['url'][$key],
            'type' => $_GET['type'][$key],
            'status' => $_GET['status'][$key] ? 1 : 0
        ));
    }
    cpmsg(lang('plugin/rtj1009_mobilecp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else if (submitcheck('prsubmit')) {
    foreach ($_GET['title'] as $key => $value) {
        C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->update($key, array(
            'icon' => $_GET['icon'][$key],
            'color' => $_GET['color'][$key],
            'displayorder' => $_GET['displayorder'][$key],
            'title' => $_GET['title'][$key],
            'url' => $_GET['url'][$key],
            'type' => $_GET['type'][$key],
            'status' => $_GET['status'][$key] ? 1 : 0
        ));
    }
    cpmsg(lang('plugin/rtj1009_mobilecp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else {

    showtips(lang('plugin/rtj1009_mobilecp', 'rtj1009_0117'),'',true,lang('plugin/rtj1009_mobilecp', 'rtj1009_0116'));
    showformheader(''.$ren_url.'', 'enctype');
    showtableheader(lang('plugin/rtj1009_mobilecp', 'rtj1009_0101'), 'fixpadding');
    showsubtitle(array(
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0221'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0102'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0103'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0104'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0105'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0106'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0107'),
    ));

    usort($menulist, 'cmp');
    foreach($menulist as $key => $value) {
        $isstatu = $value['status'] ? 'checked' : '';
        $icon = htmlspecialchars($value['icon']);
        $icons = htmlspecialchars($value['icons']);
        $selecttypey = array($value['type'] => ' selected');
        showtablerow('', '', array(
            "<input class=\"txt\" type=\"text\" name=\"displayorder[$value[id]]\" value=\"$value[displayorder]\" >",
            "<input class=\"txt\" type=\"text\" name=\"icons[$value[id]]\" value=\"$icons\" >",
            "<input class=\"txt\" type=\"text\" name=\"icon[$value[id]]\" value=\"$icon\" >",
            "<input class=\"txt\" type=\"text\" name=\"title[$value[id]]\" value=\"$value[title]\" >",
            "<input class=\"txt\" type=\"text\" name=\"url[$value[id]]\" value=\"$value[url]\" >",
            "<select name=\"type[$value[id]]\">
              <option value =\"\">".lang('plugin/rtj1009_mobilecp', 'rtj1009_0006')."</option>
              <option value =\"1\" $selecttypey[1]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0007')."</option>
              <option value =\"2\" $selecttypey[2]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0008')."</option>
            </select>",
            "<input class=\"checkbox\" type=\"checkbox\" name=\"status[$value[id]]\" value=\"checkbox\" $isstatu>",
        ));
    }

    showsubmit('menulistsubmit', lang('plugin/rtj1009_mobilecp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/

    showtips(lang('plugin/rtj1009_mobilecp', 'rtj1009_0119'),'',true,lang('plugin/rtj1009_mobilecp', 'rtj1009_0118'));

    showformheader(''.$ren_url.'', 'enctype');
    showtableheader(lang('plugin/rtj1009_mobilecp', 'rtj1009_0114'), 'fixpadding');
    showsubtitle(array(
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0221'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0102'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0108'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0104'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0105'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0106'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0107'),
    ));

    usort($sidelist, 'cmp');
    foreach($sidelist as $key => $value) {
        $isstatu = $value['status'] ? 'checked' : '';
        $icon = htmlspecialchars($value['icon']);
        $color = htmlspecialchars($value['color']);
        $selecttypee = array($value['type'] => ' selected');
        showtablerow('', array('class="td25"', ''), array(
            "<input class=\"txt\" type=\"text\" name=\"displayorder[$value[id]]\" value=\"$value[displayorder]\" >",
            "<input class=\"txt\" type=\"text\" name=\"icon[$value[id]]\" value=\"$icon\" >",
            "<input class=\"txt\" type=\"text\" name=\"color[$value[id]]\" value=\"$color\" >",
            "<input class=\"txt\" type=\"text\" name=\"title[$value[id]]\" value=\"$value[title]\" >",
            "<input class=\"txt\" type=\"text\" name=\"url[$value[id]]\" value=\"$value[url]\" >",
            "<select name=\"type[$value[id]]\">
              <option value =\"\">".lang('plugin/rtj1009_mobilecp', 'rtj1009_0006')."</option>
              <option value =\"1\" $selecttypee[1]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0112')."</option>
              <option value =\"2\" $selecttypee[2]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0113')."</option>
            </select>",
            "<input class=\"checkbox\" type=\"checkbox\" name=\"status[$value[id]]\" value=\"checkbox\" $isstatu>",
        ));
    }

    showsubmit('sidesubmit', lang('plugin/rtj1009_mobilecp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/

    showtips(lang('plugin/rtj1009_mobilecp', 'rtj1009_0121'),'',true,lang('plugin/rtj1009_mobilecp', 'rtj1009_0120'));

    showformheader(''.$ren_url.'', 'enctype');
    showtableheader(lang('plugin/rtj1009_mobilecp', 'rtj1009_0115'), 'fixpadding');
    showsubtitle(array(
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0221'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0102'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0108'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0104'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0105'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0106'),
        lang('plugin/rtj1009_mobilecp', 'rtj1009_0107'),
    ));

    usort($prlist, 'cmp');
    foreach($prlist as $key => $value) {
        $isstatu = $value['status'] ? 'checked' : '';
        $icon = htmlspecialchars($value['icon']);
        $color = htmlspecialchars($value['color']);
        $selecttypes = array($value['type'] => ' selected');
        showtablerow('', array('class="td25"', ''), array(
            "<input class=\"txt\" type=\"text\" name=\"displayorder[$value[id]]\" value=\"$value[displayorder]\" >",
            "<input class=\"txt\" type=\"text\" name=\"icon[$value[id]]\" value=\"$icon\" >",
            "<input class=\"txt\" type=\"text\" name=\"color[$value[id]]\" value=\"$color\" >",
            "<input class=\"txt\" type=\"text\" name=\"title[$value[id]]\" value=\"$value[title]\" >",
            "<input class=\"txt\" type=\"text\" name=\"url[$value[id]]\" value=\"$value[url]\" >",
            "<select name=\"type[$value[id]]\">
              <option value =\"\">".lang('plugin/rtj1009_mobilecp', 'rtj1009_0006')."</option>
              <option value =\"1\" $selecttypes[1]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0109')."</option>
              <option value =\"2\" $selecttypes[2]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0110')."</option>
              <option value =\"3\" $selecttypes[3]>".lang('plugin/rtj1009_mobilecp', 'rtj1009_0111')."</option>
            </select>",
            "<input class=\"checkbox\" type=\"checkbox\" name=\"status[$value[id]]\" value=\"checkbox\" $isstatu>",
        ));
    }

    showsubmit('prsubmit', lang('plugin/rtj1009_mobilecp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/

}

