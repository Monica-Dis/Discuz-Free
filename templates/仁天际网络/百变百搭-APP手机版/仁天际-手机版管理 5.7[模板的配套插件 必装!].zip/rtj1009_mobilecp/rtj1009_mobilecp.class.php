<?php

/**
 *      [仁天际-手机版管理] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_mobilecp.class.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

require DISCUZ_ROOT.'./source/plugin/rtj1009_mobilecp/jssdk.php';

class mobileplugin_rtj1009_mobilecp {
    function global_header_mobile() {
        global $_G,$rtj1009_list_style,$rtj1009_m_config;
        loadcache('plugin');
        $rtj1009_m_config = $_G['cache']['plugin']['rtj1009_mobilecp'];
        if ($rtj1009_m_config['wx_radio'] || $rtj1009_m_config['wx_uploadimg']) {
            $jssdk = new WXJSSDK($rtj1009_m_config['wx_appId'], $rtj1009_m_config['wx_appSecret']);
            $rtj1009_m_config['signPackage'] = $jssdk->GetSignPackage();
        }
        if ($_G['fid'] && CURMODULE=='forumdisplay') {
            $rtj1009_list_style = $this->get_style_value();
        }
    }
	  
	 /* 通过 fid 返回
	  * $fid  板块ID 
	  * 返回style 值 0 默认|1 样式一|2 样式二 |3 样式二 
	  * 前端调用 if  $rtj1009_list_style['style'] ==1/2/3  执行代码  else  执行代码
	 */
	function get_style_value() {
		global $_G;	
		
		$rtj1009_list_style = DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_m_liststyle') . " WHERE bid='$_G[fid]' " );
			
		return $rtj1009_list_style;
	}
	

	function discuzcode() {
		require_once libfile('function/rtj1009_vedio','plugin/rtj1009_mobilecp');
		global $_G;
		$rtj1009_m_config = $_G['cache']['plugin']['rtj1009_mobilecp'];
		if ($rtj1009_m_config['video_radio'] && (in_array($_G['fid'], unserialize($rtj1009_m_config['ren_vedio_forums'])) || $_G['basescript']=='group')) {
			if (strstr($_G['discuzcodemessage'],'[/media]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","rtj1009_vedio",$_G['discuzcodemessage']);
			}
			if (strstr($_G['discuzcodemessage'],'[/video]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","rtj1009_vedio",$_G['discuzcodemessage']);
			}
		}
	}
}
   

?>