<?php

/**
 *      [�����-�ֻ������] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_mobilecp.class.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}



require DISCUZ_ROOT.'./source/plugin/rtj1009_mobilecp/rtj1009_avatar_imgsize.php';

$uid = $_G['uid'];
$imgdata = explode(',',$_GET["image_file"]);
preg_match('/^(data:\s*image\/(\w+);base64,)/',$_GET["image_file"],$result);
$imgformat = '.'.str_replace('jpeg','jpg',$result[2]);
$imgdata = base64_decode($imgdata[1]);
$basedir = DISCUZ_ROOT.$_G['setting']['attachurl'];
$sTempFileName = $basedir.'rtj1009_avatar'.'/'.$uid;
@dmkdir($basedir.'rtj1009_avatar');
file_put_contents($sTempFileName,$imgdata);
$dirs = sprintf("%09d",$uid);
$dir = array(
    substr($dirs,0,3),
    substr($dirs,3,2),
    substr($dirs,5,2),
    substr($dirs,7,2)
);
$avatar_dir = DISCUZ_ROOT.'uc_server/data/avatar/'.$dir[0].'/'.$dir[1].'/'.$dir[2].'/';
@dmkdir($avatar_dir);
myImageResize($sTempFileName,$avatar_dir.$dir[3].'_avatar_big'.$imgformat, 200, 200);
myImageResize($sTempFileName,$avatar_dir.$dir[3].'_avatar_middle'.$imgformat, 120, 120);
myImageResize($sTempFileName,$avatar_dir.$dir[3].'_avatar_small'.$imgformat, 48, 48);
@unlink($sTempFileName);
echo json_encode(array('status'=>1));



?>