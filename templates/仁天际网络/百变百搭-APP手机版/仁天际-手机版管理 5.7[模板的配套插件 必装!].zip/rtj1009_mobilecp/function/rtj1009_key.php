<?php
/**
 *      [�����-�ֻ������] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_key.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$rtj1009_key = array(
    'sn' => '{ADDONVAR:SN}',
    'revisionid' => '{ADDONVAR:RevisionID}',
    'siteurl' => '{ADDONVAR:SiteUrl}',
    'ClientUrl' => '{ADDONVAR:ClientUrl}',
    'siteid' => '{ADDONVAR:SiteID}',
    'qqid' => '{ADDONVAR:QQID}',
    'key' => '{{ADDONVAR:RevisionDateline},ADDONVAR:MD5({ADDONVAR:SiteUrl},{ADDONVAR:ClientUrl},{ADDONVAR:SiteID},{ADDONVAR:QQID})}',
);