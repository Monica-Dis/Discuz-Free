<?php

/**
 *      [仁天际-手机版管理] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: function.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache('plugin');
$rtj1009_m_config = $_G['cache']['plugin']['rtj1009_mobilecp'];
$plug_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_mobilecp&pmod=';

function get_forum_count() {
	
    $sult = DB::fetch_first('SELECT count(*) as count FROM ' . DB::table('forum_forum') . " WHERE type='sub'  and status='3'");
    return $sult['count'];
	
}

function get_forum_list($start, $perpage) {
	
    return DB::fetch_all('SELECT * FROM ' . DB::table('forum_forum') . " WHERE type='sub'  and status='3' order by fid asc limit " . $start .','. $perpage);
}

function get_style_bid($fid) {
	
    return DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_m_liststyle') . " WHERE bid='$fid' " );
}

function get_style_list() {
	
    return DB::fetch_all('SELECT * FROM ' . DB::table('rtj1009_m_liststyle'));
	
}

function insert( $data ){
	return DB::insert('rtj1009_m_liststyle', $data,true);
}

function update( $data,$condition ){
	return DB::update('rtj1009_m_liststyle', $data,$condition,true);
}

function delete( $condition ){
	return DB::delete('rtj1009_m_liststyle', $condition);
}
//From: dis'.'m.tao'.'bao.com
?>