<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_rtj1009_m_sidebar.php 33658 2013-07-29 06:25:15Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_rtj1009_m_sidebar extends discuz_table
{
	public function __construct() {

		$this->_table = 'rtj1009_m_sidebar';
		$this->_pk    = 'id';

		parent::__construct();
	}

    public function fetch_all() {
        return DB::fetch_all("SELECT * FROM %t", array($this->_table));
    }

    public function get_sidebar_typeyi() {
        return DB::fetch_all("SELECT * FROM %t WHERE type = '1' AND `status`='1'", array($this->_table));
    }

    public function get_sidebar_typee() {
        return DB::fetch_all("SELECT * FROM %t WHERE type = '2' AND `status`='1'", array($this->_table));
    }


}
//From: dis'.'m.tao'.'bao.com
?>