<?php

/**
 *      [�����-PCģ�����] (C)2001-2099 DisM.Taobao.Com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: morefunction.inc.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: dis'.'m.tao'.'bao.com
?>

<script type="text/javascript">location.href="http://dism.taobao.com/?@24863.developer";</script>