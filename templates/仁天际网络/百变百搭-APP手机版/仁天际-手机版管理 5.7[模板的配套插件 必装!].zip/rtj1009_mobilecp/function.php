<?php

/**
 *      [仁天际-手机版管理] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: function.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache('plugin');
$rtj1009_m_config = $_G['cache']['plugin']['rtj1009_mobilecp'];
$plug_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_mobilecp&pmod=';

/* 获取论坛板块总数  排除二级板块  群组 */
function get_forum_count() {
	
    $sult = DB::fetch_first('SELECT count(*) as count FROM ' . DB::table('forum_forum') . " WHERE (type='forum' or type='sub') and status='1'");
    return $sult['count'];
	
}

/* 获取论坛板块 */
function get_forum_list($start, $perpage) {
	
    return DB::fetch_all('SELECT * FROM ' . DB::table('forum_forum') . " WHERE (type='forum' or type='sub') and status='1' order by fid asc limit " . $start .','. $perpage);
}

/* 通过 fid 返回
 * 返回style 值 0 默认|1 样式一|2 样式二 |3 样式二 
 */
function get_style_bid($fid) {
	
    return DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_m_liststyle') . " WHERE bid='$fid' " );
}


/* 获取样式所有数据  全部*/
function get_style_list() {
	
    return DB::fetch_all('SELECT * FROM ' . DB::table('rtj1009_m_liststyle'));
	
}

/*
 * $data 插入数据
 * 插入
 */
function insert( $data ){
	return DB::insert('rtj1009_m_liststyle', $data,true);
}

/*
 * $data 数据
 * $condition 更新条件
 * 返回更新id 
 */
function update( $data,$condition ){
	return DB::update('rtj1009_m_liststyle', $data,$condition,true);
}

//DB::UPDATE('forum_poststick', $setarr, "id='$id'";);

/*
 * $condition删除条件
 */
function delete( $condition ){
	return DB::delete('rtj1009_m_liststyle', $condition);
}
//From: dis'.'m.tao'.'bao.com
?>