<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<div class="ren_zong">
	<!--{if $config['ren_ad_yi']}--><!--[diy=rtj1009_iho0]--><div id="rtj1009_iho0" class="area"></div><!--[/diy]--><!--{/if}-->
	<!--{if $config['ren_ad_e']}--><!--[diy=rtj1009_iho1]--><div id="rtj1009_iho1" class="area"></div><!--[/diy]--><!--{/if}-->
    <!--{if $config['ren_ad_san']}--><!--[diy=rtj1009_iho2]--><div id="rtj1009_iho2" class="area"></div><!--[/diy]--><!--{/if}-->
    <!--{if $config['ren_ad_si']}--><!--[diy=rtj1009_iho3]--><div id="rtj1009_iho3" class="area"></div><!--[/diy]--><!--{/if}-->
	<div class="rtj1009_yiban cl">
    	<div class="rtj1009_yi cl">
        	<div class="z ren_yiz cl">
                <div class="z ren_yiz_s cl">
                    <div class="z ren_lunbo cl">
                         <!--[diy=rtj1009_diy2]--><div id="rtj1009_diy2" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="z ren_yiz_tie cl">
                        <div class="ren_ezx_tw">
                            <div class="ren_bt">���ʵ���</div>
                            <!--[diy=rtj1009_diy111]--><div id="rtj1009_diy111" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="y ren_yiz_z cl">
                    <div class="ren_ez_tie y">
                        <!--[diy=rtj1009_diy104]--><div id="rtj1009_diy104" class="area"></div><!--[/diy]-->
                        <!--[diy=rtj1009_diy105]--><div id="rtj1009_diy105" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_ez_tie ren_ez_tiee y">
                        <!--[diy=rtj1009_diy114]--><div id="rtj1009_diy114" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_ez_tie ren_ez_tiee y">
                        <!--[diy=rtj1009_diy115]--><div id="rtj1009_diy115" class="area"></div><!--[/diy]-->
                    </div>
                </div>
            </div>
            
            <div class="ren_yiy y cl">
            	<div class="ren_yiy_s cl">
                    <div class="ren_yiys_user cl">
                        <!--{if !$_G[uid] && !$_G['connectguest']}-->
                        <div class="ren_userinfo cl">
                            <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                            <h3 class="ren_us_name">Hi �ο� ����</h3>
                            <span class="ren_us_hy">��ӭ������{$_G['setting']['bbname']}��</span>
                        </div>
                        <!--{else}-->
                        <div class="ren_userinfo cl">
                            <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                            <h3 class="ren_us_name">Hi $_G[username] ����</h3>
                            <span class="ren_us_hy">��ӭ������{$_G['setting']['bbname']}��</span>
                        </div>
                        <!--{/if}-->
                    </div>
                	<ul class="cl">
                        <li class="ren_yiy_sliz">
                        	<!--{if $_G['uid']}-->
                            <a href="home.php?mod=space&do=pm" target="_blank" class="ren_yiy_sxx">�ҵ���Ϣ</a><!--{else}-->
                            <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" class="ren_yiy_sdl">��¼</a><!--{/if}-->
                        </li>
                        <li class="ren_yiy_sliz">
                        	<!--{if $_G['uid']}-->
                            <a href="home.php?mod=space&uid=$_G[uid]&do=profile" target="_blank" class="ren_yiy_swd">�ҵ���ҳ</a><!--{else}-->
                            <a href="member.php?mod={$_G[setting][regname]}" class="ren_yiy_szc">ע��</a><!--{/if}-->
                        </li>
                        <li class="ren_yiy_sliy">
                        	<!--{if $_G['uid']}-->
                            <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sfb">��������</a><!--{else}-->
                            <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sft">����</a><!--{/if}-->
                        </li>
                    </ul>
                </div>
               
                <div class="ren_yiy_x cl">
                    <div class="ren_yiy_lunbo cl">
                         <!--[diy=rtj1009_diy102]--><div id="rtj1009_diy102" class="area"></div><!--[/diy]-->
                    </div>
                </div>
                <div class="ren_yiy_xe cl">
                    <div class="y ren_e_y cl">
                        <!--[diy=rtj1009_diy107]--><div id="rtj1009_diy107" class="area"></div><!--[/diy]-->
                    </div>
                </div>
            </div>
		<script type="text/javascript">
            jq(document).ready(function(){
                jq("#scrollDiv").Scroll({line:1,speed:600,timer:5000,up:"but_up",down:"but_down"});
		});
		</script>
        </div>
    </div>
	
	<!--{if $config['ren_portal_bm']}-->
    <div class="rtj1009_eban cl">
    	<div class="rtj1009_e cl">
        	<div class="z ren_e_z cl">
                <div class="rtj1009_yixy_bt cl">
                    <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">������Ϣ</a></h3>
                    <div class="ren_jiutab_hover y">
                        <ul class="ren_jiutab_bt">
                            <li>
                                <a href="javascript:;" class="xxk" onmouseover="switchTab('ren_jiutab',1,6,'xxk');" id="ren_jiutab_1">�ⷿ</a><em></em>
                                <a href="javascript:;" onmouseover="switchTab('ren_jiutab',2,6,'xxk');" id="ren_jiutab_2">��ְ</a><em></em>
                                <a href="javascript:;" onmouseover="switchTab('ren_jiutab',3,6,'xxk');" id="ren_jiutab_3">��Ƹ</a><em></em>
                                <a href="javascript:;" onmouseover="switchTab('ren_jiutab',4,6,'xxk');" id="ren_jiutab_4">���ֳ�</a><em></em>
                                <a href="javascript:;" onmouseover="switchTab('ren_jiutab',5,6,'xxk');" id="ren_jiutab_5">���ַ�</a><em></em>
                                <a href="javascript:;" onmouseover="switchTab('ren_jiutab',6,6,'xxk');" id="ren_jiutab_6">�����г�</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="ren_jiutab_xx cl">
                    <div class="ren_jiutab_nr z cl">
                        <div class="ren_jiutab_xx_hover_body cl">
                            <div id="ren_jiutab_c_1" class="cl">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy901]--><div id="rtj1009_diy901" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy902]--><div id="rtj1009_diy902" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy903]--><div id="rtj1009_diy903" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy905]--><div id="rtj1009_diy905" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_2" class="cl" style="display: none;">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy921]--><div id="rtj1009_diy921" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy922]--><div id="rtj1009_diy922" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy923]--><div id="rtj1009_diy923" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy907]--><div id="rtj1009_diy907" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_3" class="cl" style="display: none;">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy931]--><div id="rtj1009_diy931" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy932]--><div id="rtj1009_diy932" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy933]--><div id="rtj1009_diy933" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy909]--><div id="rtj1009_diy909" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_4" class="cl" style="display: none;">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy941]--><div id="rtj1009_diy941" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy942]--><div id="rtj1009_diy942" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy943]--><div id="rtj1009_diy943" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy911]--><div id="rtj1009_diy911" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_5" class="cl" style="display: none;">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy951]--><div id="rtj1009_diy951" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy952]--><div id="rtj1009_diy952" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy953]--><div id="rtj1009_diy953" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy913]--><div id="rtj1009_diy913" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_6" class="cl" style="display: none;">
                            	<div class="z ren_wutw cl">
                                    <div class="ren_wutw_xx1 z cl">
                                        <!--[diy=rtj1009_diy961]--><div id="rtj1009_diy961" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx2 z cl">
                                        <!--[diy=rtj1009_diy962]--><div id="rtj1009_diy962" class="area"></div><!--[/diy]-->
                                    </div>
                                    <div class="ren_wutw_xx ren_wutw_xx3 z cl">
                                        <!--[diy=rtj1009_diy963]--><div id="rtj1009_diy963" class="area"></div><!--[/diy]-->
                                    </div>
                                </div>
                                <div class="z ren_ez_tie cl">
                                	<ul class="ren_ez_xx cl">
                                        <!--[diy=rtj1009_diy915]--><div id="rtj1009_diy915" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
            	<div class="rtj1009_yixy_bt cl">
                    <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">�������</a></h3>
                </div>
            	<div class="ren_yizs cl">
                    <ul class="cl">
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx1"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx2"></span>
                            <p>�ⷿ</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx3"></span>
                            <p>װ��</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx4"></span>
                            <p>��Ƹ</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx5"></span>
                            <p>��ְ</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx6"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx7"></span>
                            <p>���</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx8"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx9"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx10"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx11"></span>
                            <p>����</p>
                        </a></li>
                        <li><a href="http://t.cn/Aiux1eta" target="_blank"><span class="ren_yizs_xx12"></span>
                            <p>��ʳ</p>
                        </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--{/if}-->
    
	<!--{if $config['ren_ad_qi']}-->
    <div class="ren_ime cl">
		<!--[diy=rtj1009_ren_imme1]--><div id="rtj1009_ren_imme1" class="area"></div><!--[/diy]-->
    </div>
	<!--{/if}-->
    
    <div class="rtj1009_sanban cl">
    	<div class="rtj1009_e cl">
			<!--{if $config['ren_portal_ms']}-->
        	<div class="ren_e_yi cl">
            	<div class="z ren_e_yiz">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">��ʳ</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��ʳ̽��</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��ʳ����</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��ʳ����</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy311]--><div id="rtj1009_diy311" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy312]--><div id="rtj1009_diy312" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy313]--><div id="rtj1009_diy313" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="ren_e_yiy y">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">����</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�μǷ���</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">���ι���</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy321]--><div id="rtj1009_diy321" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy322]--><div id="rtj1009_diy322" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy323]--><div id="rtj1009_diy323" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
			<!--{/if}-->
			
			<!--{if $config['ren_portal_fc']}-->
            <div class="ren_e_e cl">
            	<div class="z ren_e_yiz">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�·�</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�ⷿ</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">���ַ�</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">¥����̸</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy331]--><div id="rtj1009_diy331" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy332]--><div id="rtj1009_diy332" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy333]--><div id="rtj1009_diy333" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="ren_e_yiy y">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">��װ</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">Ч��ͼ</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">������װ</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">װ������</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy341]--><div id="rtj1009_diy341" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy342]--><div id="rtj1009_diy342" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy343]--><div id="rtj1009_diy343" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
			<!--{/if}-->
			
			<!--{if $config['ren_portal_qc']}-->
            <div class="ren_e_san cl">
            	<div class="z ren_e_yiz">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">���</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�������</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��ɴ��Ӱ</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">����̼�</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy351]--><div id="rtj1009_diy351" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy352]--><div id="rtj1009_diy352" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy353]--><div id="rtj1009_diy353" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="ren_e_yiy y">
                	<div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                        <div class="ren_e_pdfl y">
                        	<a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">���Ϳ�</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">���ֳ�</a><span>/</span>
                            <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">���ѽ���</a>
                        </div>
                    </div>
                    <div class="z rtj1009_yixy_nr cl">
                    	<div class="ren_e_tw">
                        	<!--[diy=rtj1009_diy361]--><div id="rtj1009_diy361" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_e_tie">
                            	<!--[diy=rtj1009_diy362]--><div id="rtj1009_diy362" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="z ren_e_twx cl">
                            <!--[diy=rtj1009_diy363]--><div id="rtj1009_diy363" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
			<!--{/if}-->
        </div>
    </div>
    
	<!--{if $config['ren_portal_sh']}-->
    <div class="rtj1009_wuban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">��������</a></h3>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��Ȥ����</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��н���</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��������</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�����μ�</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">ʱ�й���</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank"≯��˵��</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
                	<div class="ren_e_zsxx cl">
                        <div class="ren_bt">�����㳡</div>
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy510]--><div id="rtj1009_diy510" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                    <div class="ren_e_zxxx cl">
                        <div class="ren_bt">�����Ƽ�</div>
                        <div class="ren_z_dr z">
                            <!--[diy=rtj1009_diy566]--><div id="rtj1009_diy566" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="ren_sitab_xx y cl">
                    <div class="ren_sitab_nr">
                        <div class="ren_ez_tie y">
                            <div class="ren_ezx_tw">
                            	<div class="ren_bt">��ѡ</div>
                                <ul>
                       			     <!--[diy=rtj1009_diy511]--><div id="rtj1009_diy511" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                            <ul class="ren_ez_xx cl">
                            	<!--[diy=rtj1009_diy512]--><div id="rtj1009_diy512" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        <div class="ren_ez_tie ren_ptop20 y">
                            <div class="ren_ezx_tw">
                            	<div class="ren_bt">����</div>
                                <ul>
                       			     <!--[diy=rtj1009_diy513]--><div id="rtj1009_diy513" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                            <ul class="ren_ez_xx cl">
                            	<!--[diy=rtj1009_diy514]--><div id="rtj1009_diy514" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_bt">������</div>
                <div class="ren_wuytab_xx y cl">
                    <div class="ren_wuytab_hover cl">
                        <ul class="ren_wuytab_bt cl">
                            <li><a href="javascript:;" class="xxk" onmouseover="switchTab('ren_wuytab',1,4,'xxk');" id="ren_wuytab_1">�����ռ�<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',2,4,'xxk');" id="ren_wuytab_2">��ʳ����<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',3,4,'xxk');" id="ren_wuytab_3">ʱ�д���<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',4,4,'xxk');" id="ren_wuytab_4">�������<span>></span></a></li>
                        </ul>
                    </div>
                    <div class="ren_wuytab_nr">
                        <div class="ren_wuytab_xx_hover_body cl">
                        
                            <div id="ren_wuytab_c_1" class="cl">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy557]--><div id="rtj1009_diy557" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_2" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy558]--><div id="rtj1009_diy558" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_3" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy559]--><div id="rtj1009_diy559" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_4" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy560]--><div id="rtj1009_diy560" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <div class="ren_yx_sd cl">
                    <!--[diy=rtj1009_diy586]--><div id="rtj1009_diy586" class="area"></div><!--[/diy]-->
                </div>
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">����һ��</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy585]--><div id="rtj1009_diy585" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--{/if}-->
        
	<!--{if $config['ren_portal_tu']}-->
    <div class="rtj1009_baban cl">
    	<div class="rtj1009_ba cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="http://t.cn/Aiux1eta" target="_blank">������ͼ</a></h3>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">������ͼ</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">��Ӱ��Ƭ</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">�����μ�</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">ʱ������</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">������</a><span>/</span>
                    <a class="ren_e_btxx" href="http://t.cn/Aiux1eta" target="_blank">ɹ����</a>
                </div>
            </div>
        	<div class="rtj1009_ba_tw cl">
                <div class="ren_stw cl">
                    <div class="ren_stwxx z zbxxk1">
                        <!--[diy=rtj1009_diy849]--><div id="rtj1009_diy849" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk2">
                        <!--[diy=rtj1009_diy850]--><div id="rtj1009_diy850" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk3">
                        <!--[diy=rtj1009_diy851]--><div id="rtj1009_diy851" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk4">
                        <!--[diy=rtj1009_diy852]--><div id="rtj1009_diy852" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk5">
                        <!--[diy=rtj1009_diy853]--><div id="rtj1009_diy853" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk6">
                        <!--[diy=rtj1009_diy854]--><div id="rtj1009_diy854" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk7">
                        <!--[diy=rtj1009_diy855]--><div id="rtj1009_diy855" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk8">
                        <!--[diy=rtj1009_diy856]--><div id="rtj1009_diy856" class="area"></div><!--[/diy]-->
                    </div>
                </div>
          	</div>
        </div>
    </div>
	<!--{/if}-->
    
    <!--{if $config['ren_portal_yl']}-->
    <div class="rtj1009_shiban cl">
    	<p>
        	<span>��������</span>
        </p>
        <ul>
        	<!--[diy=rtj1009_diy1]--><div id="rtj1009_diy1" class="area"></div><!--[/diy]-->
        </ul>
    </div>
	<!--{/if}-->
</div>
<script type="text/javascript">
function fixed_top_nv(eleid, disbind) {
	this.nv = eleid && $(eleid) || $('nv');
	this.openflag = this.nv && BROWSER.ie != 6;
	this.nvdata = {};
	this.init = function (disattachevent) {
		if(this.openflag) {
			if(!disattachevent) {
				var obj = this;
				_attachEvent(window, 'resize', function(){obj.reset();obj.init(1);obj.run();});
				var switchwidth = $('switchwidth');
				if(switchwidth) {
					_attachEvent(switchwidth, 'click', function(){obj.reset();obj.openflag=false;});
				}
			}

			var next = this.nv;
			try {
				while((next = next.nextSibling).nodeType != 1 || next.style.display === 'none') {}
				this.nvdata.next = next;
				this.nvdata.height = parseInt(this.nv.offsetHeight, 10);
				this.nvdata.width = parseInt(this.nv.offsetWidth, 10);
				this.nvdata.left = this.nv.getBoundingClientRect().left - document.documentElement.clientLeft;
				this.nvdata.position = this.nv.style.position;
				this.nvdata.opacity = this.nv.style.opacity;
			} catch (e) {
				this.nvdata.next = null;
			}
		}
	};

	this.run = function () {
		var fixedheight = 0;
		if(this.openflag && this.nvdata.next){
			var nvnexttop = document.body.scrollTop || document.documentElement.scrollTop;
			var dofixed = nvnexttop !== 0 && document.documentElement.clientHeight >= 15 && this.nvdata.next.getBoundingClientRect().top - this.nvdata.height < 0;
			if(dofixed) {
				if(this.nv.style.position != 'fixed') {
					this.nv.style.borderLeftWidth = '0';
					this.nv.style.borderRightWidth = '0';
					this.nv.style.height = this.nvdata.height + 'px';
					this.nv.style.width = this.nvdata.width + 'px';
					this.nv.style.top = '0';
					this.nv.style.left = this.nvdata.left + 'px';
					this.nv.style.position = 'fixed';
					this.nv.style.zIndex = '199';
					this.nv.style.opacity = 0.85;
				}
			} else {
				if(this.nv.style.position != this.nvdata.position) {
					this.reset();
				}
			}
			if(this.nv.style.position == 'fixed') {
				fixedheight = this.nvdata.height;
			}
		}
		return fixedheight;
	};
	this.reset = function () {
		if(this.nv) {
			this.nv.style.position = this.nvdata.position;
			this.nv.style.borderLeftWidth = '';
			this.nv.style.borderRightWidth = '';
			this.nv.style.height = '';
			this.nv.style.width = '';
			this.nv.style.opacity = this.nvdata.opacity;
		}
	};
	if(!disbind && this.openflag) {
		this.init();
		_attachEvent(window, 'scroll', this.run);
	}
}
</script>
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->
<!--{template common/footer}-->
