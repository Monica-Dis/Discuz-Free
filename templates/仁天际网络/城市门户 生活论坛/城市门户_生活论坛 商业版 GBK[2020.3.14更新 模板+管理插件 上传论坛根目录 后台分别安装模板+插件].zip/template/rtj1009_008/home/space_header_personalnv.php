<?PHP exit('Access Denied');?>
<!--{if $_G['adminid'] == 1 && empty($space['self'])}-->
<!--{eval $personalnv['items'] = array(); $personalnv['banitems'] = array(); $personalnv['nvhidden'] = 0;}-->
<!--{/if}-->
<!--{eval $nvclass = !empty($personalnv['nvhidden']) ? ' class="mininv"' : '';}-->
<div class="rtj1009_nv_top cl">
	<ul class="z rtj1009_nv_tb cl" style="padding-left: 180px;">
		<!--{if empty($personalnv['nvhidden'])}-->
			<!--{if empty($personalnv['banitems']['follow']) && helper_access::check_module('follow')}-->
			<li{if $do=='view'} class="a"{/if}><a href="home.php?mod=follow&uid=$space[uid]&do=view"><!--{if !empty($personalnv['items']['follow'])}-->$personalnv['items']['follow']<!--{else}-->��ҳ<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if $_G['setting']['allowviewuserthread'] !== false && (empty($personalnv['banitems']['topic']))}-->
			<li{if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space"><!--{if !empty($personalnv['items']['topic'])}-->$personalnv['items']['topic']<!--{else}-->����<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['album']) && helper_access::check_module('album')}-->
			<li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space"><!--{if !empty($personalnv['items']['album'])}-->$personalnv['items']['album']<!--{else}-->{lang album}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['feed']) && helper_access::check_module('feed')}-->
			<li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space"><!--{if !empty($personalnv['items']['feed'])}-->$personalnv['items']['feed']<!--{else}-->{lang feed}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['doing']) && helper_access::check_module('doing')}-->
			<li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space"><!--{if !empty($personalnv['items']['doing'])}-->$personalnv['items']['doing']<!--{else}-->{lang doing}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['blog']) && helper_access::check_module('blog')}-->
			<li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space"><!--{if !empty($personalnv['items']['blog'])}-->$personalnv['items']['blog']<!--{else}-->{lang blog}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['share']) && helper_access::check_module('share')}-->
			<li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space"><!--{if !empty($personalnv['items']['share'])}-->$personalnv['items']['share']<!--{else}-->{lang share}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['wall']) && helper_access::check_module('wall')}-->
			<li{if $do=='wall'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall"><!--{if !empty($personalnv['items']['wall'])}-->$personalnv['items']['wall']<!--{else}-->{lang message_board}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['profile'])}-->
			<li{if $do=='profile'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile"><!--{if !empty($personalnv['items']['profile'])}-->$personalnv['items']['profile']<!--{else}-->{lang memcp_profile}<!--{/if}--></a></li>
			<!--{/if}-->
		<!--{/if}-->
	</ul>
    <div class="y rtj1009_nv_gl cl">
        <!--{if checkperm('allowbanuser') || checkperm('allowedituser') || $_G[adminid] == 1}-->
                <!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
                        <!--{if checkperm('allowbanuser')}-->
                        <a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
                        <!--{else}-->
                        <a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
                        <!--{/if}-->
                <!--{/if}-->
                
                <!--{if $_G[adminid] == 1}-->
                    <a href="forum.php?mod=modcp&action=thread&op=post&do=search&searchsubmit=1&users=$encodeusername" id="umanageli" onmouseover="showMenu(this.id)" class="showmenu">{lang content_manage}</a>
                <!--{/if}-->
        <!--{/if}-->
    </div>
</div>

