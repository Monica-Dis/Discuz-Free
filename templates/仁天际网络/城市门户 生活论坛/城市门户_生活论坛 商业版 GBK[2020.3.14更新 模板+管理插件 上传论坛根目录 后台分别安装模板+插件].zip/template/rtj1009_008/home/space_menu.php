<?PHP exit('Access Denied');?>

<!--{if $space[uid]}-->
<div id="rtj1009_uhd" class="rtj1009_menu">
<div class="rtj1009_menu_nv">
	<!--{if CURMODULE == 'follow'}-->
		<!--{subtemplate home/follow_user_header}-->
	<!--{elseif !$space[self]}-->
	<div class="ren_menu_mn">
		<ul>
        	<div class="ren_mt">
                <span>{$space[username]}</span>
            </div>
			<!--{if helper_access::check_module('follow')}-->
			<li class="ren_addflw z">
				<!--{if !ckfollow($space['uid'])}-->
					<a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><span>��ע</span></a>
				<!--{else}-->
					<a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">ȡ����ע</a>
				<!--{/if}-->
			</li>
			<!--{/if}-->
			<li class="ren_pm2 z">
				<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
			</li>
		</ul>
		<!--{if helper_access::check_module('follow')}-->
		<script type="text/javascript">
		function succeedhandle_followmod(url, msg, values) {
			var fObj = $('followmod');
			if(values['type'] == 'add') {
				fObj.innerHTML = '��ע';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
			} else if(values['type'] == 'del') {
				fObj.innerHTML = 'ȡ����ע';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
			}
		}
		</script>
		<!--{/if}-->
	</div>
	<!--{/if}-->
	<div class="z rtj1009_icn cl">
            <div class="ren_icn rtj_avt"><a href="home.php?mod=space&uid=$space[uid]"><!--{avatar($space[uid],big)}--></a></div>
            <!--{if helper_access::check_module('follow')}-->
            <ul class="ren_gb">
             	<li>
                	<a href="home.php?mod=follow&do=following&uid=$uid" target="_blank"><p>$space['following']</p><span>��ע</span></a>
                </li>
                <li>
                	<a href="home.php?mod=follow&do=follower&uid=$uid" target="_blank"><p>$space['follower']</p><span>��˿</span></a>
                </li>
            </ul>
            <!--{/if}-->
		
		
	</div>
</div>	
	<!--{hook/space_menu_extra}-->
    <div class="rtj1009_nv_top cl">
        <ul class="z rtj1009_nv_tb cl" style="padding-left: 180px;">
            <!--{if helper_access::check_module('follow')}-->
            <li{if CURMODULE == 'follow'} class="a"{/if}><a href="home.php?mod=follow&uid=$space[uid]&do=view&from=space">��ҳ</a></li>
            <!--{/if}-->
            <li{if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space">����</a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space">{lang blog}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space">{lang album}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('doing')}-->
            <li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space">{lang doing}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('home')}-->
            <li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space">{lang feed}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('share')}-->
            <li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space">{lang share}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <li{if $do==wall} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space">{lang message}</a></li>
            <!--{/if}-->
            <li{if $do==profile} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">{lang memcp_profile}</a></li>
        </ul>
        <div class="y rtj1009_nv_gl cl">
			<!--{if checkperm('allowbanuser') || checkperm('allowedituser') || $_G[adminid] == 1}-->
					<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
							<!--{if checkperm('allowbanuser')}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
							<!--{else}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
							<!--{/if}-->
					<!--{/if}-->
					
					<!--{if $_G[adminid] == 1}-->
						<a href="forum.php?mod=modcp&action=thread&op=post&do=search&searchsubmit=1&users=$encodeusername" id="umanageli" onmouseover="showMenu(this.id)" class="showmenu">{lang content_manage}</a>
					<!--{/if}-->
			<!--{/if}-->
		</div>
    </div>
	
	<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
	<ul id="usermanageli_menu" class="p_pop" style="width: 80px; display:none;">
		<!--{if checkperm('allowbanuser')}-->
			<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank">{lang user_ban}</a></li>
		<!--{/if}-->
		<!--{if checkperm('allowedituser')}-->
			<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank">{lang user_edit}</a></li>
		<!--{/if}-->
	</ul>
	<!--{/if}-->
	<!--{if $_G['adminid'] == 1}-->
		<ul id="umanageli_menu" class="p_pop" style="width: 80px; display:none;">
			<li><a href="forum.php?mod=modcp&action=thread&op=post&searchsubmit=1&do=search&users=$encodeusername" target="_blank">{lang manage_post}</a></li>
			<!--{if helper_access::check_module('doing')}-->
				<li><a href="admin.php?action=doing&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_doing}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('blog')}-->
				<li><a href="admin.php?action=blog&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_blog}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('feed')}-->
				<li><a href="admin.php?action=feed&searchsubmit=1&detail=1&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_feed}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('album')}-->
				<li><a href="admin.php?action=album&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_album}</a></li>
				<li><a href="admin.php?action=pic&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_pic}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('wall')}-->
				<li><a href="admin.php?action=comment&searchsubmit=1&detail=1&fromumanage=1&authorid=$space[uid]" target="_blank">{lang manage_comment}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('share')}-->
				<li><a href="admin.php?action=share&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_share}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('group')}-->
				<li><a href="admin.php?action=threads&operation=group&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_threads}</a></li>
				<li><a href="admin.php?action=prune&searchsubmit=1&detail=1&operation=group&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_prune}</a></li>
			<!--{/if}-->
		</ul>
	<!--{/if}-->
</div>
<!--{/if}-->
