<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_rtj1009_style` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bid` int(10) DEFAULT NULL,
  `style` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

EOF;
runquery($sql);
$identifier = 'rtj1009_democp';
/* 删除文件 */
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
$finish = TRUE;/*DISM-TAOBAO_COM*/
?>