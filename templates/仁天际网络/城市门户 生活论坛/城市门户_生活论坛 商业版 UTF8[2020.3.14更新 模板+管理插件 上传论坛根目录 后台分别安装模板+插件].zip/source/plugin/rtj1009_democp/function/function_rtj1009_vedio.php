<?php
/**
 *      [�����-�ֻ������] (C)2001-2099 1009.com.cn.
 *      ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *      $Id: function_rtj1009_vedio.php 2017-08-10 18:07:44Z rtj1009_democp $
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function rtj1009_vedio($vedio_url) {
	global $_G;
	$url = $vedio_url[2];
	$config = $_G['cache']['plugin']['rtj1009_democp'];
	$width = $config['pc_vedio_width']?$config['pc_vedio_width']:'100%';
	$height = $config['pc_vedio_height'];
	$url_array = array_filter(explode('/',$url));
	$http = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	
	if (strpos($url, 'youku.com') !== FALSE) {
		if (strpos($url_array[count($url_array)],'.html') !== FALSE) {
			$src = $http."player.youku.com/embed/".str_replace('id_','',str_replace('.html','',$url_array[count($url_array)]));
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
		} else if(strpos($url,'.swf') !== FALSE) {
			$string = end(explode('/',current(array_filter(explode('/v.swf',$url)))));
			$src = $http."player.youku.com/embed/".$string;
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
		}
	}
	
	if (strpos($url, 'tudou.com') !== FALSE) {
			$src = $http."player.youku.com/embed/".str_replace('id_','',str_replace('.html','',$url_array[count($url_array)]));
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
	}
	
	if (strpos($url, 'qq.com') !== FALSE) {
		if (strpos($url_array[count($url_array)],'.html') !== FALSE) {
			$src = $http."v.qq.com/iframe/player.html?vid=".str_replace('.html','',$url_array[count($url_array)])."&auto=0";
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
			
		} else if(strpos($url,'.swf') !== FALSE) {
			$string = current(explode('&',end(array_filter(explode('vid=',$url)))));
			$src = $http."v.qq.com/iframe/player.html?vid=".$string."&auto=0";
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
		}
	}
	
	if (strpos($url, 'iqiyi.com') !== FALSE) {
		if (strpos($url_array[count($url_array)],'.html') !== FALSE || strpos($url,'.swf') !== FALSE) {
			$string = current(explode('&accessToken',end(array_filter(explode('vid=',$url)))));
			$src = $http."open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=".$string;
			return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
		}
	}
	
}
//From: Dism��taobao��com
?>