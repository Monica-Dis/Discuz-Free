<?PHP exit('Access Denied');?>

<!--{if $rtj1009_hd_xuannav == 1}-->
<!--**** 默认样式从这里开始 *****-->

<div class="ren_nav">
    <ul class="ren_navxx">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">谈天说地</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">户外旅游</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">求职招聘</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">房产楼市</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">装修装饰</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">汽车天地</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">相亲交友</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">美食天地</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">文娱在线</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">摄影天地</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">通信数码</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">体育健身</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">时尚丽人</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">兴趣话题</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">达人秀场</a></li><span>/</span>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">网友中心</a></li>
    </ul>
</div>
<!--**** 默认样式到这里结束 *****-->


<!--{elseif $rtj1009_hd_xuannav == 2}-->
<!--**** 三栏分栏样式从这里开始 *****-->

<div class="z ren_navyi cl">
	<div class="z ren_nav_bt ren_nav_btyi cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>门户</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">房产</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">装修</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">亲子</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">婚嫁</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">美食</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">汽车</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">旅游</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">健康</a></li>
    </ul>
</div>

<div class="z ren_nave cl">
	<div class="z ren_nav_bt ren_nav_bte cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>信息</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">求职</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">租房</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">二手房</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">跳蚤市场</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">拼车</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">购物</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">二手车</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">生活服务</a></li>
    </ul>
</div>

<div class="z ren_navsan cl">
	<div class="z ren_nav_bt ren_nav_btsan cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>社区</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">城事杂谈</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">户外旅游</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">求职招聘</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">房产楼市</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">装修装饰</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">汽车天地</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">相亲交友</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">美食天地</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">情感天空</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">情感天空</a></li>
    </ul>
</div>
<!--**** 三栏分栏样式到这里结束 *****-->


<!--{elseif $rtj1009_hd_xuannav == 3}-->
<!--**** 四栏分栏样式从这里开始 *****-->

<div class="z ren_navyi cl">
	<div class="z ren_nav_bt ren_nav_btyi cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>门户</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">房产</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">装修</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">亲子</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">婚嫁</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">美食</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">汽车</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">旅游</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">健康</a></li>
    </ul>
</div>

<div class="z ren_nave cl">
	<div class="z ren_nav_bt ren_nav_bte cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>信息</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">求职</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">租房</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">二手房</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">招聘</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">拼车</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">二手车</a></li>
    </ul>
</div>

<div class="z ren_nave ren_navey cl">
	<div class="z ren_nav_bt ren_nav_bte cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>服务</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">生活服务</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">相亲交友</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">跳蚤市场</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">本地商家</a></li>
    </ul>
</div>

<div class="z ren_navsan cl">
	<div class="z ren_nav_bt ren_nav_btsan cl">
    	<a href="http://t.cn/Aiux1eta" target="_blank">
            <span class="ren_nav_bttb"></span>
            <p>社区</p>
        </a>
    </div>
    <ul class="z ren_navxx cl">
          <li><a href="http://t.cn/Aiux1eta" target="_blank">城事杂谈</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">情感天空</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">户外旅游</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">房产楼市</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">装修装饰</a></li>
          <li><a href="http://t.cn/Aiux1eta" target="_blank">美食天地</a></li>
    </ul>
</div>
<!--**** 四栏分栏样式到这里结束 *****-->
<!--{/if}-->