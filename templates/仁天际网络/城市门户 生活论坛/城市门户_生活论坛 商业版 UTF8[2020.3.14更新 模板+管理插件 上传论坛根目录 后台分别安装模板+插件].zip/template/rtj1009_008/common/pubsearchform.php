<?PHP exit('Access Denied');?>
<!--{if $_G['setting']['search']}-->
<form id="scform" method="post" autocomplete="off" action="$_G[siteurl]search.php?searchsubmit=yes" target="_blank">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="srchtype" value="title" />
    <input type="hidden" name="srhfid" value="$_G[fid]" />
    <input type="hidden" name="mod" value="forum">
    <input type="text" name="srchtxt" id="rtj_ssk_txt" onblur="if (value ==''){value='请输入你想搜索内容'}" onfocus="if (value =='请输入你想搜索内容'){value =''}" value="请输入你想搜索内容" autocomplete="off" x-webkit-speech speech />
    <button type="submit" name="searchsubmit" id="rtj_ssk_btn" sc="1" class="ren_sspn ren_sspnc" value="true"><span class="ren_sskfdj"></span></button>
</form>
<!--{/if}-->
