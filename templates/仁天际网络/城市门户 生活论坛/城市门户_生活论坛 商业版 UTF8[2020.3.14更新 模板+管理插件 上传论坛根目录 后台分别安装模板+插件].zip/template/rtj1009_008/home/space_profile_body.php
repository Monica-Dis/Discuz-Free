<?PHP exit('Access Denied');?>
<div class="ren_g_c u_profile">

	<div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>基本信息</h3>
        </div>
        <div class="ren_gxxs_xx">
        	<ul class="ren_gxxsz_xx cl">
            	<li>
                	<em class="ren_gxxx_lb">用户名</em>
                    <div class="ren_lb_mbn"><span>{$space[username]}</span></div>
                </li>
                <li>
                	<em class="ren_gxxx_lb">ID</em>
                    <div class="ren_lb_mbn">
                    	<span class="xw0">{$space[uid]}
                            <!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}-->
                            <!--{if $_G[$isfriendinfo][note]}-->
                                , <span class="xg1">$_G[$isfriendinfo][note]</span>
                            <!--{/if}-->
                        </span>
                	</div>
                </li>
                <li>
                	<em class="ren_gxxx_lb">等级</em>
                    <div class="ren_lb_mbn"><span>{$space[group][grouptitle]}</span></div>
                </li>
                <!--{loop $profiles $value}-->
                <li>
                    <em class="ren_gxxx_lb">$value[title]</em>
                    <div class="ren_lb_mbn"><span>$value[value]</span></div>
                </li>
                <!--{/loop}-->
            </ul>
            <!--{if CURMODULE == 'space'}-->
                <!--{hook/space_profile_baseinfo_top}-->
            <!--{elseif CURMODULE == 'follow'}-->
                <!--{hook/follow_profile_baseinfo_top}-->
            <!--{/if}-->
            <ul>
                <!--{if $space[spacenote]}--><li><em class="xg1">{lang spacenote}&nbsp;&nbsp;</em>$space[spacenote]</li><!--{/if}-->
                <!--{if $space[customstatus]}--><li class="xg1"><em>{lang permission_basic_status}&nbsp;&nbsp;</em>$space[customstatus]</li><!--{/if}-->
                <!--{if $space[group][maxsigsize] && $space[sightml]}--><li><em class="xg1">{lang personal_signature}&nbsp;&nbsp;</em><table><tr><td>$space[sightml]</td></tr></table></li><!--{/if}-->
            </ul>
        </div>
		
	</div>
    <div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>{lang stat_info}</h3>
        </div>
        <div class="ren_gxxs_xx">
            <div class="ren_gxxsx_xx cl">
                <!--{if $space[buyercredit]}-->
                <a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#sellcredit" target="_blank">{lang eccredit_sellerinfo}<span class="ren_gxxx_tc">$space[buyercredit]</span></a>
                <!--{/if}-->
                <!--{if $space[sellercredit]}-->
                <a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#buyercredit" target="_blank">{lang eccredit_buyerinfo}<span class="ren_gxxx_tc">$space[sellercredit]</span></a>
                <!--{/if}-->
                <a href="home.php?mod=spacecp&ac=credit" target="_blank">{lang credits}<span class="ren_gxxx_tc">$space[credits]</span></a>
                <!--{loop $_G[setting][extcredits] $key $value}-->
                <!--{if $value[title]}-->
                <a href="home.php?mod=spacecp&ac=credit" target="_blank">$value[title]<span class="ren_gxxx_tc">{$space["extcredits$key"]} $value[unit]</span></a>
                <!--{/if}-->
                <!--{/loop}-->
                <a href="home.php?mod=follow&do=following&uid=$uid" target="_blank">关注数<span class="ren_gxxx_tc">$space['following']</span></a>
                <a href="home.php?mod=follow&do=follower&uid=$uid" target="_blank">粉丝数<span class="ren_gxxx_tc">$space['follower']</span></a>
                <a href="home.php?mod=space&uid=$space[uid]&do=friend&view=me&from=space" target="_blank">{lang friends_num}<span class="ren_gxxx_tc">$space[friends]</span></a>
                <!--{if helper_access::check_module('doing')}-->
                    <a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space" target="_blank">{lang doings_num}<span class="ren_gxxx_tc">$space[doings]</span></a>
                <!--{/if}-->
                <!--{if helper_access::check_module('blog')}-->
                    <a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space" target="_blank">{lang blogs_num}<span class="ren_gxxx_tc">$space[blogs]</span></a>
                <!--{/if}-->
                <!--{if helper_access::check_module('album')}-->
                    <a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space" target="_blank">{lang albums_num}<span class="ren_gxxx_tc">$space[albums]</span></a>
                <!--{/if}-->
                <!--{if $_G['setting']['allowviewuserthread'] !== false}-->
                    <!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
                    <a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}" target="_blank">{lang replay_num}<span class="ren_gxxx_tc">$space[posts]</span></a>
                    <a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}" target="_blank">{lang threads_num}<span class="ren_gxxx_tc">$space[threads]</span></a>
                <!--{/if}-->
                <!--{if helper_access::check_module('share')}-->
                    <a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space" target="_blank">{lang shares_num}<span class="ren_gxxx_tc">$space[sharings]</span></a>
                <!--{/if}-->
                </div>
            </div>
            <!--{if CURMODULE == 'space'}-->
                <!--{hook/space_profile_baseinfo_middle}-->
            <!--{elseif CURMODULE == 'follow'}-->
                <!--{hook/follow_profile_baseinfo_middle}-->
            <!--{/if}-->
        </div>
  </div>
<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_baseinfo_bottom}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_baseinfo_bottom}-->
<!--{/if}-->
<!--{if $space['medals']}-->
    <div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>{lang medals}</h3>
        </div>
        <div class="ren_gxxs_xx">
            <div class="ren_gxxsx_xx cl">
            	<a href="home.php?mod=medal">
                <!--{loop $space['medals'] $medal}-->
                    <img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'md_{$medal[medalid]}_menu', 'pos':'12!'});" />
                <!--{/loop}-->
                </a>
            </div>
        </div>
    </div>
	<!--{loop $space['medals'] $medal}-->
		<div id="md_{$medal[medalid]}_menu" class="tip tip_4" style="display: none;">
			<div class="tip_horn"></div>
			<div class="tip_c">
				<h4>$medal[name]</h4>
				<p>$medal[description]</p>
			</div>
		</div>
	<!--{/loop}-->
<!--{/if}-->

<!--{if $count}-->
    <div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>{lang manage_forums}</h3>
        </div>
        <div class="ren_gxxs_xx">
            <div class="ren_gxxsx_xx cl">
            	<!--{loop $manage_forum $key $value}-->
                <a href="forum.php?mod=forumdisplay&fid=$key" target="_blank">$value</a> &nbsp;
                <!--{/loop}-->
            </div>
        </div>
    </div>
<!--{/if}-->
<!--{if $groupcount}-->
    <div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>{lang joined_group}</h3>
        </div>
        <div class="ren_gxxs_xx">
            <div class="ren_gxxsx_xx cl">
            	<!--{loop $usergrouplist $key $value}-->
                <a href="forum.php?mod=group&fid={$value['fid']}" target="_blank">$value['name']</a> &nbsp;
                <!--{/loop}-->
            </div>
        </div>
    </div>
<!--{/if}-->

<div class="ren_pbm ren_mbm ren_bbda cl">
    	<div class="ren_gxxs_bt">
        	<h3>{lang active_profile}</h3>
        </div>
        <div class="ren_gxxs_xx">
        	<ul class="ren_gxxsz_xx cl">
                <!--{if $space[adminid]}--><li><em class="ren_gxxx_lb">{lang management_team}</em><div class="ren_lb_mbn"><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[adminid]" target="_blank">{$space[admingroup][grouptitle]}</a></div>{$space[admingroup][icon]}</li><!--{/if}-->
                <li><em class="ren_gxxx_lb">{lang usergroup}</em><div class="ren_lb_mbn" style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[groupid]" target="_blank">{$space[group][grouptitle]}</a></div>{$space[group][icon]}<!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
                <!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
            </ul>
            <ul id="pbbs" class="ren_gxxsz_xx cl">
                <!--{if $space[oltime]}--><li><em class="ren_gxxx_lb">{lang online_time}</em><div class="ren_lb_mbn"><span>$space[oltime] {lang hours}</span></div></li><!--{/if}-->
                <li><em class="ren_gxxx_lb">{lang regdate}</em><div class="ren_lb_mbn"><span>$space[regdate]</span></div></li>
                <li><em class="ren_gxxx_lb">{lang last_visit}</em><div class="ren_lb_mbn"><span>$space[lastvisit]</span></div></li>
                <!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
                <li><em class="ren_gxxx_lb">{lang register_ip}</em><div class="ren_lb_mbn"><span>$space[regip] - $space[regip_loc]</span></div></li>
                <li><em class="ren_gxxx_lb">{lang last_visit_ip}</em><div class="ren_lb_mbn"><span>$space[lastip]:$space[port] - $space[lastip_loc]</span></div></li>
                <!--{/if}-->
                <!--{if $space[lastactivity]}--><li><em class="ren_gxxx_lb">{lang last_activity_time}</em><div class="ren_lb_mbn"><span>$space[lastactivity]</span></div></li><!--{/if}-->
                <!--{if $space[lastpost]}--><li><em class="ren_gxxx_lb">{lang last_post_time}</em><div class="ren_lb_mbn"><span>$space[lastpost]</span></div></li><!--{/if}-->
                <!--{if $space[lastsendmail]}--><li><em class="ren_gxxx_lb">{lang last_send_email}</em><div class="ren_lb_mbn"><span>$space[lastsendmail]</span></div></li><!--{/if}-->
                <li><em class="ren_gxxx_lb">{lang time_offset}</em><div class="ren_lb_mbn"><span>
                <!--{eval $timeoffset = array({lang timezone});}-->
                $timeoffset[$space[timeoffset]]</span></div></li>
            </ul>
        </div>
<!--{if $clist}-->
<div class="ren_gxxs_xx cl">
	<h2 class="mbm">{lang crime_record}</h2>
	<table id="pcr" class="ren_profile_dt dt">
		<tr>
			<th width="15%">{lang crime_action}</th>
			<th width="18%">{lang crime_dateline}</th>
			<th>{lang crime_reason}</th>
			<th width="15%">{lang crime_operator}</th>
		</tr>
		<!--{loop $clist $crime}-->
		<tr>
			<td>
				<!--{if $crime[action] == 'crime_delpost'}-->
					{lang crime_delpost}
				<!--{elseif $crime[action] == 'crime_warnpost'}-->
					{lang crime_warnpost}
				<!--{elseif $crime[action] == 'crime_banpost'}-->
					{lang crime_banpost}
				<!--{elseif $crime[action] == 'crime_banspeak'}-->
					{lang crime_banspeak}
				<!--{elseif $crime[action] == 'crime_banvisit'}-->
					{lang crime_banvisit}
				<!--{elseif $crime[action] == 'crime_banstatus'}-->
					{lang crime_banstatus}
				<!--{elseif $crime[action] == 'crime_avatar'}-->
					{lang crime_avatar}
				<!--{elseif $crime[action] == 'crime_sightml'}-->
					{lang crime_sightml}
				<!--{elseif $crime[action] == 'crime_customstatus'}-->
					{lang crime_customstatus}
				<!--{/if}-->
			</td>
			<td><!--{date($crime[dateline])}--></td>
			<td>$crime[reason]</td>
			<td><a href="home.php?mod=space&uid=$crime[operatorid]" target="_blank">$crime[operator]</a></td>
		</tr>
		<!--{/loop}-->
	</table>
</div>
<!--{/if}-->
<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_extrainfo}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_extrainfo}-->
<!--{/if}-->
</div>