<?PHP exit('Access Denied');?>
<!--{if empty($diymode)}-->
	<!--{template common/header}-->
	<!--{if $_G[setting][homestyle]}--><!--{ad/text/wp a_t}--><!--{/if}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>

	<div id="ct" class="rtj1009_ct2 cl">

		<div class="rtj1009_zcd">
				<ul class="ren_tbn">
                    <li$actives[we]><a href="home.php?mod=space&do=home&view=we">好友动态</a><span>></span></li>
                    <li$actives[me]><a href="home.php?mod=space&do=home&view=me">{lang my_feed}</a><span>></span></li>
                    <li$actives[all]><a href="home.php?mod=space&do=home&view=all">{lang view_all}</a><span>></span></li>
                    <!--{if $_G['setting']['my_app_status']}-->
                    <li$actives[app]><a href="home.php?mod=space&do=home&view=app">{lang view_app_feed}</a><span>></span></li>
                    <!--{/if}-->
                    <!--{hook/space_home_navlink}-->
                </ul>
		</div>
		<!--/sidebar-->
        <div class="rtj1009_sz_mn">
            <!--{hook/space_home_side_top}-->
			<div class="ren_sz_bm">
            	<div class="ren_sz_z">
                <!--{hook/space_home_side_bottom}-->
		<div class="mn ptm pbm">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<!--{if $space['uid'] && $space[self]}-->
			<!--{if $_G[setting][homestyle]}-->
				<div class="bm bw0">
					<table cellpadding="0" cellspacing="0" class="mi mbm">
						<tr>
							<th>
								<div class="avatar mbn cl">
									<a href="home.php?mod=spacecp&ac=avatar" title="{lang memcp_avatar}" id="edit_avt"><span id="edit_avt_tar">{lang memcp_avatar}</span><!--{avatar($_G[uid],middle)}--></a>
								</div>
								<p><a href="home.php?mod=space&uid=$space[uid]" target="_blank" class="o xi2">{lang view_my_space}</a></p>
							</th>
							<td>
								<h3 class="xs2">
									<span class="y xw0 xs1">{lang have} <em class="xi1">$space[views]</em> {lang visit_per_man}</span>
									<a href="home.php?mod=space&uid=$space[uid]"{eval g_color($space[groupid]);}>{$space[username]}</a>
									<!--{eval g_icon($space[groupid]);}-->
								</h3>
								<!--{template home/space_status}-->
							</td>
						</tr>
					</table>
					<!--[diy=diycontentmiddle]--><div id="diycontentmiddle" class="area"></div><!--[/diy]-->
					<!--{hook/space_home_top}-->

				</div>

				<!--{ad/feed/bm}-->
                <!--{hook/space_home_navlink}-->
				<!--{/if}-->
			<!--{else}-->
				<div class="bm bw0">
				<!--{eval
					$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=home&view=me\">{lang they_feed}</a>";
				}-->
				<!--{template home/space_menu}-->

			<!--{/if}-->

			<!--{if $_GET[view] == 'all'}-->
				<p class="tbmu">
					<!--{if !$_G[setting][homestyle] && $_G['setting']['magicstatus'] && $_G['setting']['magics']['thunder']}-->
					<a id="a_magic_thunder" href="home.php?mod=magic&mid=thunder" onclick="showWindow('magics', this.href, 'get', 0)" style="padding-left: 18px; background: url({STATICURL}image/magic/thunder.small.gif) no-repeat 0 50%;" class="y">{$_G[setting][magics][thunder]}</a>
					<!--{/if}-->
					<a href="home.php?mod=space&do=home&view=all&order=dateline"$orderactives[dateline]>{lang newest_feed}</a><span class="pipe">|</span>
					<a href="home.php?mod=space&do=home&view=all&order=hot"$orderactives[hot]>{lang hot_feed}</a>
				</p>
			<!--{elseif $_GET[view] == 'app' && $_G['setting']['my_app_status']}-->
				<p class="tbmu">
					<a href="home.php?mod=space&do=home&view=app&type=we"$typeactives[we]>{lang what_friend_playing}</a><span class="pipe">|</span>
					<a href="home.php?mod=space&do=home&view=app&type=me"$typeactives[me]>{lang own}</a><span class="pipe">|</span>
					<a href="home.php?mod=space&do=home&view=app&type=all"$typeactives[all]>{lang what_everybody_playing}</a>
				</p>
			<!--{elseif $groups}-->
				<p class="tbmu">
					<!--{if !$_G[setting][homestyle] && $_G['setting']['magicstatus'] && $_G['setting']['magics']['thunder']}-->
					<a id="a_magic_thunder" href="home.php?mod=magic&mid=thunder" onclick="showWindow('magics', this.href, 'get', 0)" style="padding-left: 18px; background: url({STATICURL}image/magic/thunder.small.gif) no-repeat 0 50%;" class="y">{$_G[setting][magics][thunder]}</a>
					<!--{/if}-->
					<a href="home.php?mod=space&do=home&view=we"{$gidactives[-1]}>{lang all_friends}</a><!--{loop $groups $key $value}--><span class="pipe">|</span><a href="home.php?mod=space&do=home&view=we&gid=$key"{$gidactives[$key]}>$value</a><!--{/loop}-->
				</p>
			<!--{elseif !$_G[setting][homestyle] && $_G['setting']['magicstatus'] && $_G['setting']['magics']['thunder']}-->
				<p class="tbmu cl">
					<a id="a_magic_thunder" href="home.php?mod=magic&mid=thunder" onclick="showWindow('magics', this.href, 'get', 0)" style="padding-left: 18px; background: url({STATICURL}image/magic/thunder.small.gif) no-repeat 0 50%;" class="y">{$_G[setting][magics][thunder]}</a>
				</p>
			<!--{/if}-->

<!--{else}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ren_ct" class="rtj1009_lai_ct cl">
            <div class="ren_lai_mn z">
                <div class="bm ren_ly_bm">
					<div class="ren_sz_bt">
						<h3>{lang feed}</h3>
					</div>
				<div class="ren_bm_c ren_ly_c">
	<!--{else}-->
		<!--{template common/header}-->
		
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct1 wp cl">
			<div class="mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="bm bw0">
					<div class="bm_c">
	<!--{/if}-->
<!--{/if}-->

			<div id="feed_div" class="e">
			<!--{if $hotlist}-->
				<h4 class="et"><a href="home.php?mod=space&do=home&view=all&order=hot" class="y xw0">{lang view_more_hot} <em>&rsaquo;</em></a>{lang recent_recommended_hot}</h4>
				<ul class="el">
				<!--{loop $hotlist $value}-->
				<!--{eval $value = mkfeed($value);}-->
				<!--{template home/space_feed_li}-->
				<!--{/loop}-->
				</ul>
			<!--{/if}-->

			<!--{if $list}-->
				<!--{if $_GET[view] == 'app' && $_G['setting']['my_app_status']}-->
					<!--{template home/space_home_feed_app}-->
				<!--{else}-->
					<!--{loop $list $day $values}-->
						<!--{if $_GET['view']!='hot'}-->
							<h4 class="et">
								<!--{if $day=='yesterday'}-->{lang yesterday}<!--{elseif $day=='today'}-->{lang today}<!--{else}-->$day<!--{/if}-->
							</h4>
						<!--{/if}-->

						<ul class="el">
						<!--{loop $values $value}-->
							<!--{template home/space_feed_li}-->
						<!--{/loop}-->
						</ul>
					<!--{/loop}-->
				<!--{/if}-->
			<!--{elseif $feed_users}-->
				<div class="xld xlda mtm">
				<!--{loop $feed_users $day $users}-->
				<h4 class="et">
					<!--{if $day=='yesterday'}-->{lang yesterday}<!--{elseif $day=='today'}-->{lang today}<!--{else}-->$day<!--{/if}-->
				</h4>
				<!--{loop $users $user}-->
				<!--{eval $daylist = $feed_list[$day][$user[uid]];}-->
				<!--{eval $morelist = $more_list[$day][$user[uid]];}-->
				<dl class="bbda cl">
					<dd class="m avt">
						<!--{if $user[uid]}-->
						<a href="home.php?mod=space&uid=$user[uid]" target="_blank" c="1"><!--{avatar($user[uid],small)}--></a>
						<!--{else}-->
						<img src="{IMGDIR}/systempm.png" alt="" />
						<!--{/if}-->
					</dd>
					<dd class="cl">
						<ul class="el">
						<!--{loop $daylist $value}-->
							<!--{template home/space_feed_li}-->
						<!--{/loop}-->
						</ul>

						<!--{if $morelist}-->
						<p class="xg1 cl"><span onclick="showmore('$day', '$user[uid]', this);" class="unfold">{lang open}</span></p>
						<div id="feed_more_div_{$day}_{$user[uid]}" style="display:none;">
							<ul class="el">
							<!--{loop $morelist $value}-->
								<!--{template home/space_feed_li}-->
							<!--{/loop}-->
							</ul>
						</div>
						<!--{/if}-->
					</dd>
				</dl>
				<!--{/loop}-->
				<!--{/loop}-->
				</div>
			<!--{else}-->
				<p class="emp"><!--{if $_GET[view] == 'app' && $_G['setting']['my_app_status']}-->{lang no_app_feed}<!--{else}-->{lang no_feed}<!--{/if}--></p>
			<!--{/if}-->

			<!--{if $filtercount}-->
				<div class="i" id="feed_filter_notice_{$start}">
					{lang depending_your}<a href="home.php?mod=spacecp&ac=privacy&op=filter" target="_blank" class="xi2 xw1">{lang filter_settings}</a>,{lang shield_feed_message} (<a href="javascript:;" onclick="filter_more($start);" id="a_feed_privacy_more" class="xi2">{lang click_view}</a>)
				</div>
				<div id="feed_filter_div_{$start}" style="display:none;">
					<h4 class="et">{lang following_feed_shielding}</h4>
					<ul class="el">
					<!--{loop $filter_list $value}-->
					<!--{template home/space_feed_li}-->
					<!--{/loop}-->
					<li><a href="javascript:;" onclick="filter_more($start);">&laquo; {lang pack_up}</a></li>
					</ul>
				</div>
			<!--{/if}-->

			</div>
			<!--/id=feed_div-->

<!--{if empty($diymode)}-->

			<!--{if $multi}-->
				<div class="pgs cl mtm">$multi</div>
			<!--{/if}-->

			<!--{hook/space_home_bottom}-->
			<div id="ajax_wait"></div>
		</div>
	</div></div></div>
		<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
	</div>
	<!--/content-->
</div>

<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>

<!--{else}-->

			</div>
		</div>
	<!--{if $_G[setting][homepagestyle]}-->
	</div>
	<div class="rtj1009_home_sd y">
		<!--{subtemplate home/space_userabout}-->
	<!--{/if}-->
</div>
<!--{/if}-->

<!--{eval helper_manyou::checkupdate();}-->

<script type="text/javascript">
	function filter_more(id) {
		if($('feed_filter_div_'+id).style.display == '') {
			$('feed_filter_div_'+id).style.display = 'none';
			$('feed_filter_notice_'+id).style.display = '';
		} else {
			$('feed_filter_div_'+id).style.display = '';
			$('feed_filter_notice_'+id).style.display = 'none';
		}
	}

	function close_feedbox() {
		var x = new Ajax();
		x.get('home.php?mod=spacecp&ac=common&op=closefeedbox', function(s){
			$('feed_box').style.display = 'none';
		});
	}

	function showmore(day, uid, e) {
		var obj = 'feed_more_div_'+day+'_'+uid;
		$(obj).style.display = $(obj).style.display == ''?'none':'';
		if(e.className == 'unfold'){
			e.innerHTML = '{lang pack_up}';
			e.className = 'fold';
		} else if(e.className == 'fold') {
			e.innerHTML = '{lang open}';
			e.className = 'unfold';
		}
	}

	var elems = selector('li[class~=magicthunder]', $('feed_div'));
	for(var i=0; i<elems.length; i++){
		magicColor(elems[i]);
	}

	function showEditAvt(id) {
		$(id).style.display = $(id).style.display == '' ? 'block' : '';
	}
	if($('edit_avt') && BROWSER.ie && BROWSER.ie == 6) {
		_attachEvent($('edit_avt'), 'mouseover', function () { showEditAvt('edit_avt_tar'); });
		_attachEvent($('edit_avt'), 'mouseout', function () { showEditAvt('edit_avt_tar'); });
	}
</script>

<!--{template common/footer}-->