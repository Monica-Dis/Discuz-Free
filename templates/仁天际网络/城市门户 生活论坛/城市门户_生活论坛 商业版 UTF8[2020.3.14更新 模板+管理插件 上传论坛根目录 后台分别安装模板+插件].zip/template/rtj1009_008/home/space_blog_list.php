<?PHP exit('Access Denied');?>
{eval
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=blog&view=me\">{lang they_blog}</a>";
	$friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');
}


<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ren_ct" class="rtj1009_lai_ct cl">
            <div class="ren_lai_mn z">
                <div class="bm ren_ly_bm">
                	<div class="ren_lai_xc ren_ly_c">
                        <h3>{lang blog}</h3>
                    </div>
                    <div class="ren_bm_c ren_ly_c">
	<!--{else}-->
		<!--{template common/header}-->
		
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="rtj1009_ct cl">
			<div class="ren_g_mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="ren_ly_bm">
					<div class="ren_ly_c">
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="rtj1009_ct2 cl">
			<div class="rtj1009_zcd">
                <ul class="ren_tbn">
                    <li$actives[we]><a href="home.php?mod=space&do=blog&view=we">好友日志</a><span>></span></li>
                    <li$actives[me]><a href="home.php?mod=space&do=blog&view=me">{lang my_blog}</a><span>></span></li>
                    <li$actives[all]><a href="home.php?mod=space&do=blog&view=all">{lang view_all}</a><span>></span></li>
                </ul>
			</div>
     <div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
            <div class="ren_sz_z">
			<div class="mn pbm">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
<!--{/if}-->
			<div class="tbmu cl">
					<a href="home.php?mod=spacecp&ac=blog" class="y pn pnc"><strong>{lang post_new_blog}</strong></a>

				<!--{if $_GET[view] == 'all'}-->
					<a href="home.php?mod=space&do=blog&view=all" {if !$_GET[catid]}$orderactives[dateline]{/if}>{lang newest_blog}</a><span class="pipe">|</span>
					<a href="home.php?mod=space&do=blog&view=all&order=hot" $orderactives[hot]>{lang recommend_blog}</a>
					<!--{if $category}-->
						<!--{loop $category $value}-->
							<span class="pipe">|</span>
							<a href="home.php?mod=space&do=blog&catid=$value[catid]&view=all&order=$_GET[order]"{if $_GET[catid]==$value[catid]} class="a"{/if}>$value[catname]</a>
						<!--{/loop}-->
					<!--{/if}-->
				<!--{/if}-->

				<!--{if $userlist}-->
					{lang filter_by_friend}
					<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
						<option value="">{lang all_friends}</option>
						<!--{loop $userlist $value}-->
						<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
						<!--{/loop}-->
					</select>
				<!--{/if}-->

				<!--{if $_GET[view] == 'me' && $classarr}-->
					<!--{loop $classarr $classid $classname}-->
						<a href="home.php?mod=space&uid=$space[uid]&do=blog&classid=$classid&view=me" id="classid$classid" onmouseover="showMenu(this.id);"{if $_GET[classid]==$classid} class="a"{/if}>$classname</a><span class="pipe">|</span>
						<!--{if $space[self]}-->
						<div id="classid{$classid}_menu" class="p_pop" style="display: none; zoom: 1;">
							<a href="home.php?mod=spacecp&ac=class&op=edit&classid=$classid" id="c_edit_$classid" onclick="showWindow(this.id, this.href, 'get', 0);">{lang edit}</a>
							<a href="home.php?mod=spacecp&ac=class&op=delete&classid=$classid" id="c_delete_$classid" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a>
						</div>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
			</div>

			<!--{if $searchkey}-->
				<p class="tbmu">{lang follow_search_blog} <span style="color: red; font-weight: 700;">$searchkey</span> {lang doing_record_list}</p>
			<!--{/if}-->

		<!--{if $count}-->
			<div class="xld {if empty($diymode)}xlda{/if}">
			<!--{loop $list $k $value}-->
				<dl class="bbda">
					<!--{if empty($diymode)}-->
					<dd class="m">
						<div class="avt"><a href="home.php?mod=space&uid=$value[uid]" c="1"><!--{avatar($value[uid],small)}--></a></div>
					</dd>
					<!--{/if}-->

					<dt class="xs2">
						<!--{eval $stickflag = isset($value['stickflag']) ? 0 : 1;}-->
						<!--{if !$stickflag}--><span class="xi1">{lang stick}</span> &middot;<!--{/if}-->
						<!--{if helper_access::check_module('share')}-->
						<a href="home.php?mod=spacecp&ac=share&type=blog&id=$value[blogid]&handlekey=lsbloghk_{$value[blogid]}" id="a_share_$value[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);" class="oshr xs1 xw0">{lang share}</a>
						<!--{/if}-->
						<a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]"{if $value[magiccolor]} style="color: {$_G[colorarray][$value[magiccolor]]}"{/if} target="_blank">$value[subject]</a>
						<!--{if $value[status] == 1}--> <span class="xi1">({lang pending})</span><!--{/if}-->
					</dt>
					<dd>
						<!--{if $value['friend']}-->
						<span class="y"><a href="$theurl&friend=$value[friend]" class="xg1">{$friendsname[$value[friend]]}</a></span>
						<!--{/if}-->
						<!--{if empty($diymode)}--><a href="home.php?mod=space&uid=$value[uid]">$value[username]</a> <!--{/if}--><span class="xg1">$value[dateline]</span>
					</dd>
					<dd class="cl" id="blog_article_$value[blogid]">
						<!--{if $value[pic]}--><div class="atc"><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" target="_blank"><img src="$value[pic]" alt="$value[subject]" class="tn" /></a></div><!--{/if}-->
						$value[message]
					</dd>
					<dd class="xg1">
						<!--{if $classarr[$value[classid]]}-->{lang personal_category}: <a href="home.php?mod=space&uid=$value[uid]&do=blog&classid=$value[classid]&view=me">{$classarr[$value[classid]]}</a><span class="pipe">|</span><!--{/if}-->
						<!--{if $value[viewnum]}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" target="_blank">$value[viewnum] {lang blog_read}</a><span class="pipe">|</span><!--{/if}-->
						<a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]#comment" target="_blank"><span id="replynum_$value[blogid]">$value[replynum]</span> {lang blog_replay}</a>
						<!--{hook/space_blog_list_status $k}-->
						<!--{if $_GET['view']=='me' && $space['self']}-->
							<span class="pipe">|</span><a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=edit">{lang edit}</a><span class="pipe">|</span>
							<a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=delete&handlekey=delbloghk_{$value[blogid]}" id="blog_delete_$value[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a>
							<!--{if empty($value['status'])}-->
							<span class="pipe">|</span>
							
							<a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=stick&stickflag=$stickflag&handlekey=stickbloghk_{$value[blogid]}" id="blog_stick_$value[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);"><!--{if $stickflag}-->{lang stick}<!--{else}-->{lang cancel_stick}<!--{/if}--></a>
							<!--{/if}-->
						<!--{/if}-->
						<!--{if $value['hot']}--><span class="hot">{lang hot} <em>$value[hot]</em> </span><!--{/if}-->
					</dd>
				</dl>
			<!--{/loop}-->
			<!--{if $pricount}-->
				<p class="mtm">{lang hide_blog}</p>
			<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<div class="emp">{lang no_related_blog}</div>
		<!--{/if}-->
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="rtj1009_home_sd y">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>
    </div>
</div>
</div>
<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<script type="text/javascript">
	function fuidgoto(fuid) {
		var parameter = fuid != '' ? '&fuid='+fuid : '';
		window.location.href = 'home.php?mod=space&do=blog&view=we'+parameter;
	}
</script>

<!--{template common/footer}-->