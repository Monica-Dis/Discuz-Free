<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


/**
 * 微信授权登录获取用户信息
 * @param $appid 微信应用appid
 * @param $appsecret 微信应用appsecret
 * @author codehi <admin@codehui.net> 2018-3-26
 */
class WxOauth
{
    private $appid = "";          // appid
    private $appsecret = "";      // appsecret
    public  $error = array();          // 错误信息

    public function __construct($appid, $appsecret) {
        if($appid && $appsecret){
            $this->appid = $appid;
            $this->appsecret = $appsecret;
        }
    }

    public function wxLogin($code){
        $token_info = $this->getToken($code);
        if (isset($token_info['errcode'])) {
            $this->error = $token_info;
            return false;
        }
        $user_info = $this->getUserinfo($token_info['access_token'], $token_info['openid']);
        if (isset($user_info['errcode'])) {
            $this->error = $user_info;
            return false;
        }
        return $user_info;
    }

    public function getCode($redirect_uri, $state = '', $scope = '') {
        $redirect_uri = urlencode($redirect_uri);
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->appid}&redirect_uri={$redirect_uri}&response_type=code&scope={$scope}&state={$state}#wechat_redirect";
        return $url;
    }

    public function getToken($code) {
        $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$this->appid}&secret={$this->appsecret}&code=$code&grant_type=authorization_code";
        $res = json_decode(self::httpsRequest($url), true);
        return $res;
    }

    public function refreshToken($refresh_token) {
        $url = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid={$this->appid}&grant_type=refresh_token&refresh_token=$refresh_token";
        $res = json_decode(self::httpsRequest($url), true);
        return $res;
    }

    public function getUserinfo($access_token, $openid, $lang = 'zh_CN') {
        $url = "https://api.weixin.qq.com/sns/userinfo?access_token=$access_token&openid=$openid&lang=$lang";
        $res = json_decode(self::httpsRequest($url), true);
        return $res;
    }
    /**
     * 获取服务器数据
     * @param string $url  请求的url
     * @return  unknown    请求返回的内容
     */
    public function httpsRequest($url) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}
?>