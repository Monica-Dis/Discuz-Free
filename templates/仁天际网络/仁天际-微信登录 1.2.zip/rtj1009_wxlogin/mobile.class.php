<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_rtj1009_wxlogin {

    function global_footer_mobile() {
        global $_G;
        if($_G['basescript'] == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile' && $_GET['mycenter'] == '1') {
            return '<script>$(".myinfo_list ul").append(\'<li><a href="home.php?mod=spacecp&ac=plugin&id=rtj1009_wxlogin:rtj1009_wxlogin_bind&ops=bind">'.lang('plugin/rtj1009_wxlogin', 'rtj1009_028').'</a></li>\');</script>';
        }
        if ($_G['basescript'] == 'member' && CURMODULE == 'register') {
            $rtj1009_wxlogin = $_G['cache']['plugin']['rtj1009_wxlogin'];
            $in_wechat = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
            if (!$rtj1009_wxlogin['wx_iswx_btn'] || ($rtj1009_wxlogin['wx_iswx_btn'] && $in_wechat)) {
                return '<script>$(".registerbox").append(\'<link href="./source/plugin/rtj1009_wxlogin/css/style.css" rel="stylesheet" type="text/css" /><div class="ren-login-btn ren-login-ao" style="width: 289px;"><a id="rtj1009_wxlogin" class="ren-wxlogin-btn" href="plugin.php?id=rtj1009_wxlogin&mod=wxlogin">'.lang('plugin/rtj1009_wxlogin', 'rtj1009_026').'</a></div>\');</script>';
            }
        }
    }
}

class mobileplugin_rtj1009_wxlogin_member extends mobileplugin_rtj1009_wxlogin {



    function logging_bottom_mobile() {
        global $_G;
        $rtj1009_wxlogin = $_G['cache']['plugin']['rtj1009_wxlogin'];
        $in_wechat = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
        if (!$rtj1009_wxlogin['wx_iswx_btn'] || ($rtj1009_wxlogin['wx_iswx_btn'] && $in_wechat)) {
            return '<link href="./source/plugin/rtj1009_wxlogin/css/style.css" rel="stylesheet" type="text/css" /><div class="ren-login-btn ren-login-ao" style="width: 289px;"><a id="rtj1009_wxlogin" class="ren-wxlogin-btn" href="plugin.php?id=rtj1009_wxlogin&mod=wxlogin">'.lang('plugin/rtj1009_wxlogin', 'rtj1009_026').'</a></div>';
        }

    }
}


?>