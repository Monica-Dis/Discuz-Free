<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_rtj1009_wxlogin {

    function plugin_rtj1009_wxlogin() {
        include_once template('rtj1009_wxlogin:module');
    }

    function global_login_extra() {
        global $_G;
        return rtj1009_wxlogin_login_bar();
    }

    function global_usernav_extra1() {
        global $_G;
        $rtj1009_wx_isbind = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->fetch_by_uid($_G['uid']);
        return rtj1009_wxlogin_user_bar($rtj1009_wx_isbind);
    }

    function global_login_text(){
        return rtj1009_wxlogin_logging_method();
    }
}

class plugin_rtj1009_wxlogin_member extends plugin_rtj1009_wxlogin {

	function logging_method() {
		global $_G;
        return rtj1009_wxlogin_logging_method();
	}

    function register_logging_method() {
        global $_G;
        return rtj1009_wxlogin_logging_method();
    }


}

?>