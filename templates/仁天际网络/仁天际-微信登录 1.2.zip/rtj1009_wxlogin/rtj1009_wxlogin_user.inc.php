<?php

/**
 *      [仁天际-PC模板管理] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_wxlogin_user.inc.php 2017-08-10 18:07:44Z rtj1009_wxlogin $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$ren_url = 'plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_wxlogin&pmod=rtj1009_wxlogin_user';
$plug_url = ADMINSCRIPT . '?action='.$ren_url.'';


$num = C::t('#rtj1009_wxlogin#rtj1009_wxlogin_user')->get_count();
$perpage = 20;
$curpage = empty ( $_GET['page'] ) ? 1 : intval ( $_GET['page'] );
$start = ($curpage-1)*$perpage;
$rtj1009_wxlogin_user =  C::t('#rtj1009_wxlogin#rtj1009_wxlogin_user')->fetch_all($start, $perpage);
$multipage = multi($num['count'], $perpage, $curpage, $plug_url,0, '10');

if (submitcheck('deletesubmit')) {
    foreach ($_GET['delete'] as $key => $value) {
        C::t('#rtj1009_wxlogin#rtj1009_wxlogin_user')->delete($key, array(
            'uid' => $_GET['delete'][$key],
        ));
    }
    cpmsg(lang('plugin/rtj1009_wxlogin', 'rtj1009_027'), 'action='.$ren_url.'', 'succeed');
} else if ($_GET['act'] == 'editban' &&  formhash() == $_GET['formhash']) {
    C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->update($_GET['id'], array(
        'status' => -1,
    ));
    cpmsg(lang('plugin/rtj1009_wxlogin', 'rtj1009_018'), 'action='.$ren_url.'', 'succeed');
} else if ($_GET['act'] == 'remove' &&  formhash() == $_GET['formhash']) {
    C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->update($_GET['id'], array(
        'status' => 1,
    ));
    cpmsg(lang('plugin/rtj1009_wxlogin', 'rtj1009_019'), 'action='.$ren_url.'', 'succeed');
} else {
    showformheader(''.$ren_url.'', 'enctype');
    showtableheader(lang('plugin/rtj1009_wxlogin', 'rtj1009_002'), 'fixpadding');
    showsubtitle(array(
        lang('plugin/rtj1009_wxlogin', 'rtj1009_003'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_004'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_005'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_006'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_007'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_008'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_010'),
        lang('plugin/rtj1009_wxlogin', 'rtj1009_011'),
    ));
    foreach ($rtj1009_wxlogin_user as $key => $value) {
        $rtj1009_username = C::t('#rtj1009_wxlogin#rtj1009_wxlogin_user')->getusername($value['uid']);
        $rtj1009_sex = '';
        $rtj1009_status = '';
        $rtj1009_statuslan = '';
        if ($value['sex'] == 1) {
            $rtj1009_sex = lang('plugin/rtj1009_wxlogin', 'rtj1009_012');
        } elseif ($value['sex'] == 2) {
            $rtj1009_sex = lang('plugin/rtj1009_wxlogin', 'rtj1009_013');
        } else {
            $rtj1009_sex = lang('plugin/rtj1009_wxlogin', 'rtj1009_014');
        }
        if ($value['status'] == 1) {
            $rtj1009_status = 'editban';
            $rtj1009_statuslan = lang('plugin/rtj1009_wxlogin', 'rtj1009_016');
        } else {
            $rtj1009_status = 'remove';
            $rtj1009_statuslan = lang('plugin/rtj1009_wxlogin', 'rtj1009_017');
        }
        showtablerow('', array(''), array(
            "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$value[uid]]\" value=\"checkbox\">",
            $value['uid'],
            '<a href="home.php?mod=space&uid='.$value['uid'].'" target="_blank">'.$rtj1009_username.'</a>',
            $value['nickname'],
            dgmdate($value['dateline'],"Y-m-d H:i:s"),
            $rtj1009_sex,
            $value['country']."&nbsp".$value['province']."&nbsp".$value['city'],
            '<a href="'.ADMINSCRIPT.'?action=members&operation=edit&uid='.$value['uid'].'" target="_blank" style="text-decoration: underline;">'.lang('plugin/rtj1009_wxlogin', 'rtj1009_015').'</a>'.'&nbsp&nbsp'.'<a href="'.$plug_url.'&act='.$rtj1009_status.'&formhash='.FORMHASH.'&id='.$value['uid'].'" style="color: #EE1B2E; text-decoration: underline;">'.$rtj1009_statuslan.'</a>',
        ));
    }

    showsubmit('deletesubmit', 'submit', 'del');
    showtablefooter(); //dism·taobao·com
    showformfooter(); //dism_taobao_com

$pages = ceil($num['count'] / $perpage);
echo $multipage;
}