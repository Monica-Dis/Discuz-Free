<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_rtj1009_wxlogin_user extends discuz_table
{
	public function __construct() {

		$this->_table = 'rtj1009_wxlogin_user';
		$this->_pk    = 'uid';
		parent::__construct(); //dis'.'m.t'.'ao'.'bao.com
	}

	public function fetch_by_uid($uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
	}

	public function fetch_by_openid($openid){
		return DB::fetch_first("SELECT * FROM %t WHERE openid=%s",array($this->_table , $openid));
	}

	public function delete_by_openid($openid){
		return DB::query("DELETE FROM %t WHERE openid=%s",array($this->_table , $openid));
	}

    public function get_count() {
        return DB::fetch_first('SELECT count(*) as count FROM %t', array($this->_table));

    }

    public function getusername($uid) {
        return DB::result_first("SELECT username FROM ".DB::table("common_member")." WHERE `uid` = $uid");
    }

    public function fetch_all($start, $perpage) {
        return DB::fetch_all('SELECT * FROM %t ORDER BY id DESC '.DB::limit($start, $perpage), array($this->_table));
    }
	
}

?>