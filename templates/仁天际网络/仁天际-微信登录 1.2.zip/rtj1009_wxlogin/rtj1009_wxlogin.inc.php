<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$rtj1009_wxlogin = $_G['cache']['plugin']['rtj1009_wxlogin'];
require_once DISCUZ_ROOT.'./source/plugin/rtj1009_wxlogin/function/oauth.php';
$WxOauth = new WxOauth($rtj1009_wxlogin['wx_appId'], $rtj1009_wxlogin['wx_appSecret']);
$in_wechat = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;


if ($rtj1009_wxlogin['ren_wx_scope']) {
    $snsapi = 'snsapi_base';
} else {
    $snsapi = 'snsapi_userinfo';
}

$renoperation = addslashes($_GET['renoperation']);


if ($_GET['mod'] == 'wxlogin') {
    if (!$renoperation) {
        $renoperation = 'login';
    }
    if ($_GET['authcode']) {
        $code = $_GET['authcode'];
    } else {
        $code = substr(md5($_G['uid'] . $_G['config']['security']['authkey']), 0, 8);
    }
    C::t("#rtj1009_wxlogin#rtj1009_wxlogin_authcode")->delete_history();
    $authcode = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_authcode")->fetch_by_code($code);
    if ($authcode['code']) {
        DB::update('rtj1009_wxlogin_authcode', array('uid' => $_G['uid'], 'type' => 1, 'createtime' => TIMESTAMP), DB::field('code', $authcode['code']));
    } else {
        C::t("#rtj1009_wxlogin#rtj1009_wxlogin_authcode")->insert(array('code' => $code, 'uid' => $_G['uid'], 'type' => 2, 'createtime' => TIMESTAMP));
    }
    $url = $WxOauth->getCode(redirect_uri('user', $renoperation, $snsapi, $code),'', $snsapi);

    if (defined('IN_MOBILE')) {
        dheader('Location:' . $url);
    } else {

        $dir = './data/cache/qrcode/';
        $file = $dir.'rtj1009_wxlogin_'.$code.'.jpg';
        if(!file_exists($file) || !filesize($file)) {
            dmkdir($dir);
            require_once DISCUZ_ROOT.'./source/plugin/rtj1009_wxlogin/function/phpqrcode.php';
            QRcode::png($url, $file, QR_ECLEVEL_Q, 6);
        }
        $qrcode = base64_encode(file_get_contents($file));
        file_exists($file) && @unlink($file);
        include template("rtj1009_wxlogin:module");
        include template('common/header_ajax');
        echo rtj1009_wxlogin_logging_code($qrcode, $code);
        include template('common/footer_ajax');
    }

} elseif ($_GET['mod'] == 'user') {
//    echo $rtj1009_wxlogin['wx_groupid'];
//    echo $_G['setting']['newusergroupid'];
//    exit();
    $code = addslashes($_GET['authcode']);
    $user_info = $WxOauth->wxLogin($_GET['code']);

    if ($user_info['openid']) {
        $authcode = C::t('#rtj1009_wxlogin#rtj1009_wxlogin_authcode')->fetch_by_code($code);
        $get_openid = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->fetch_by_openid($user_info['openid']);


        if (!$get_openid['openid']) {
            if (CHARSET != 'utf-8') {
                $user_info = wx_convert($user_info);
            } else {
                $user_info['nickname'] = removeEmoji($user_info['nickname']);
            }
            $username = replaceSpecialChar($user_info['nickname']);
//            $username = removeEmoji($nickname);


            C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->insert(array(
                'uid' => '',
                'openid' => $user_info['openid'],
                'nickname' => $username,
                'unionid' => $user_info['unionid'],
                'sex' => intval($user_info['sex']),
                'city' => $user_info['city'],
                'province' => $user_info['province'],
                'country' => $user_info['country'],
                'headimgurl' => $user_info['headimgurl'],
                'privilege' => serialize($user_info['privilege']),
                'dateline' => TIMESTAMP,
            ));
            DB::update('rtj1009_wxlogin_authcode', array('uid' => $_G['uid'], 'status' => 0, 'type' => 3), DB::field('code', $_GET['authcode']));


            if ($rtj1009_wxlogin['repusername']) {
                loaducenter();
                if(uc_get_user(addslashes($username)) || C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
                    $url = $_G['siteurl']."plugin.php?id=rtj1009_wxlogin&mod=mode&renopenid=".$user_info['openid']."&authcode=".$code;
                    dheader('Location:' . $url);
                }
            }
        }

        if ($_GET['renoperation'] == 'login' && $get_openid['uid']) {
            if ($get_openid['status'] == -1) {
                showmessage(lang('plugin/rtj1009_wxlogin', 'rtj1009_029'),"index.php");
            } else {
                DB::update('rtj1009_wxlogin_authcode', array('uid' => $get_openid['uid'], 'status' => 1, 'type' => 4, 'createtime' => TIMESTAMP), DB::field('code', $authcode['code']));
                include_once(libfile('function/member'));
                $member = getuserbyuid($get_openid['uid'], 1);
                setloginstatus($member, 1296000);
                dheader('Location: ' . 'index.php');
            }

        } elseif ($_GET['renoperation'] == 'unbind' && $get_openid['edit'] ==1) {
             C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->delete_by_openid($get_openid['openid']);
             DB::update('rtj1009_wxlogin_authcode', array('uid' => $_G['uid'], 'status' => 1, 'type' => 5, 'createtime' => TIMESTAMP), DB::field('code', $authcode['code']));
             showmessage(lang('plugin/rtj1009_wxlogin', 'rtj1009_020'), "index.php");

        } elseif ($_GET['renoperation'] == 'bind') {
            $uid = $authcode['uid'];
            DB::update('rtj1009_wxlogin_user', array('uid' => $uid, 'edit' => 1, 'status' => 1), DB::field('openid', $user_info['openid']));
            DB::update('rtj1009_wxlogin_authcode', array('uid' => $uid, 'status' => 1, 'type' => 6, 'createtime' => TIMESTAMP), DB::field('code', $authcode['code']));
            include_once(libfile('function/member'));
            $member = getuserbyuid($uid, 1);
            setloginstatus($member, 1296000);
            showmessage(lang('plugin/rtj1009_wxlogin', 'rtj1009_023'), "index.php");
        }

        if (!$get_openid['openid']) {
            if ($rtj1009_wxlogin['ren_wx_mode'] ==2) {
                $url = $_G['siteurl']."plugin.php?id=rtj1009_wxlogin&mod=mode&renopenid=".$user_info['openid']."&authcode=".$code;
                dheader('Location:' . $url);
            } else {
                $url = $_G['siteurl']."plugin.php?id=rtj1009_wxlogin&mod=register&renopenid=".$user_info['openid']."&authcode=".$code;
                dheader('Location:' . $url);
            }
        }

    } else {
        $url = $WxOauth->getCode(redirect_uri('user', $renoperation, 'snsapi_userinfo', $code),'', 'snsapi_userinfo');
        dheader('Location:' . $url);
    }

} elseif ($_GET['mod'] == 'mode') {
    $code = addslashes($_GET['authcode']);
    $renopenid = addslashes($_GET['renopenid']);
    $get_openid = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->fetch_by_openid($renopenid);
    $username = $get_openid['nickname'];
    require_once libfile('function/member');
    loaducenter();
    if ($username != $_G['member']['username']) {
        if(uc_get_user(addslashes($username)) || C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
            $nickname = 1;
        } else {
            $nickname = 2;
        }
    }
    $navtitle = lang('plugin/rtj1009_wxlogin', 'rtj1009_026');
    include template("rtj1009_wxlogin:mode");
    if ($_GET['renoperation'] == 'modelogin') {
        include template('common/header');
        echo rtj1009_wxlogin_ren_modelogin($get_openid, $code);
        include template('common/footer');
    } elseif ($_GET['renoperation'] == 'moderegister') {
        include template('common/header');
        echo rtj1009_wxlogin_ren_moderegister($get_openid, $code, $nickname);
        include template('common/footer');
    } else {
        include template('common/header');
        echo rtj1009_wxlogin_ren_mode($get_openid, $code, $nickname);
        include template('common/footer');
    }

} elseif ($_GET['mod'] == 'modelogin' && submitcheck('submit')) {

    require_once libfile('function/member');
    if(!($loginperm = logincheck($_GET['username']))) {
        showmessage('login_strike');
    }

    if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password'])) {
        showmessage('profile_passwd_illegal');
    }

    $result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], $_G['setting']['autoidselect'] ? 'auto' : $_GET['loginfield'], $_G['clientip']);

    if($result['status'] <= 0) {
        loginfailed($_GET['username']);
        failedip();
        showmessage('login_invalid', '', array('loginperm' => $loginperm - 1));
    }

    if($result['member']['uid']) {
        $get_openid = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->fetch_by_openid($_GET['wxopenid']);
        if($get_openid['uid']) {
            showmessage(lang('plugin/rtj1009_wxlogin', 'rtj1009_024'));
        } else {
            DB::update('rtj1009_wxlogin_user', array('uid' => $result['member']['uid'], 'edit' => 1, 'status' => 1), DB::field('openid', $_GET['wxopenid']));
            DB::update('rtj1009_wxlogin_authcode', array('uid' => $result['member']['uid'], 'status' => 1, 'type' => 7, 'createtime' => TIMESTAMP), DB::field('code', $_GET['authcode']));
            $member = getuserbyuid($result['member']['uid'], 1);
            setloginstatus($member, 1296000);
            showmessage(lang('plugin/rtj1009_wxlogin', 'rtj1009_023'),"index.php");
        }
    }
} elseif ($_GET['mod'] == 'moderegister' && submitcheck('submit')) {

    require_once libfile('function/member');
    $username = dhtmlspecialchars(trim($_GET['username']));
    $usernamelen = dstrlen($username);
    if($usernamelen < 3) {
        showmessage('profile_username_tooshort');
    } elseif($usernamelen > 15) {
        showmessage('profile_username_toolong');
    }
    loaducenter();
    if ($username != $_G['member']['username']) {
        if(uc_get_user(addslashes($username)) || C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
            showmessage('profile_username_duplicate');
        }
    }

    if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password'])) {
        showmessage('profile_passwd_illegal');
    }
    if($_G['setting']['pwlength']) {
        if(strlen($_GET['password']) < $_G['setting']['pwlength']) {
            showmessage('profile_password_tooshort', '', array('pwlength' => $_G['setting']['pwlength']));
        }
    }
    $password = addslashes($_GET['password']);
    $email = 'wechat_'.strtolower(random(10)).($rtj1009_wxlogin['ren_wx_email'] ? $rtj1009_wxlogin['ren_wx_email'] : '@qq.com');
    $groupid = $rtj1009_wxlogin['wx_groupid'] ? $rtj1009_wxlogin['wx_groupid'] : $_G['setting']['newusergroupid'];
    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if($uid <= 0) {
        if($uid == -1) {
            showmessage('profile_username_illegal');
        } elseif($uid == -2) {
            showmessage('profile_username_protect');
        } elseif($uid == -3) {
            showmessage('profile_username_duplicate');
        } elseif($uid == -4) {
            showmessage('profile_email_illegal');
        } elseif($uid == -5) {
            showmessage('profile_email_domain_illegal');
        } elseif($uid == -6) {
            showmessage('profile_email_duplicate');
        } else {
            showmessage('undefined_action');
        }
    }
    $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
    DB::update('rtj1009_wxlogin_user', array('uid' => $uid, 'edit' => 1, 'status' => 1), DB::field('openid', $_GET['wxopenid']));
    if ($_GET['wxheadimgurl']) {
        wx_syncAvatar($uid, $_GET['wxheadimgurl']);
    }
    if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }

    if($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => '',
        ), false, true);
        manage_addnotify('verifyuser');
    }

    include_once libfile('function/stat');
    updatestat('register');

    $member = getuserbyuid($uid, 1);
    setloginstatus($member, 1296000);
    dheader('Location: ' . 'index.php');

} elseif ($_GET['mod'] == 'register') {

    $code = addslashes($_GET['authcode']);
    $renopenid = addslashes($_GET['renopenid']);
    $get_openid = C::t("#rtj1009_wxlogin#rtj1009_wxlogin_user")->fetch_by_openid($renopenid);

    $username = dhtmlspecialchars(trim($get_openid['nickname']));
    $groupid = $rtj1009_wxlogin['wx_groupid'] ? $rtj1009_wxlogin['wx_groupid'] : $_G['setting']['newusergroupid'];
    $uid = wx_register($username, $groupid);
    DB::update('rtj1009_wxlogin_user', array('uid' => $uid, 'status' => 1), DB::field('openid', $get_openid['openid']));
    if ($get_openid['headimgurl']) {
        wx_syncAvatar($uid, $get_openid['headimgurl']);
    }
    DB::update('rtj1009_wxlogin_authcode', array('uid' => $uid, 'status' => 1, 'type' => 8, 'createtime' => TIMESTAMP), DB::field('code', $code));
    include_once(libfile('function/member'));
    $member = getuserbyuid($uid, 1);
    setloginstatus($member, 1296000);
    dheader('Location: ' . 'index.php');
    exit;

} elseif ($_GET['mod'] == 'check') {
    $code = addslashes($_GET['authcode']);
    if($code) {
        $authcode = C::t('#rtj1009_wxlogin#rtj1009_wxlogin_authcode')->fetch_by_code($code);
        if($authcode['status'] ==1) {
            require_once libfile('function/member');
            $member = getuserbyuid($authcode['uid'], 1);
            setloginstatus($member, 1296000);
            C::t('#rtj1009_wxlogin#rtj1009_wxlogin_authcode')->delete_by_code($authcode['code']);
            $echostr = 'done';
        } else {
            $echostr = '1';//json_encode($authcode);
        }
    } else {
        $echostr = '-1';
    }

    include template('common/header_ajax');
    echo $echostr;
    include template('common/footer_ajax');
    exit;
}


function redirect_uri($mod, $renoperation, $snsapi, $code) {
    global $_G, $rtj1009_wxlogin;
    $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' :'http://';
    return ($rtj1009_wxlogin['wx_redirect_uri'] ? $http_type.$rtj1009_wxlogin['wx_redirect_uri'].'/' : $_G['siteurl'])."plugin.php?id=rtj1009_wxlogin&mod=".$mod."&renoperation=".$renoperation."&snsapi=".$snsapi."&authcode=".$code;
}

function wx_register($username, $groupid) {
    global $_G, $rtj1009_wxlogin;
    if(!$username) {
        return;
    }

    loaducenter();

    $password = md5(random(10));
    $email = 'wechat_'.strtolower(random(10)).($rtj1009_wxlogin['ren_wx_email'] ? $rtj1009_wxlogin['ren_wx_email'] : '@qq.com');

    $usernamelen = dstrlen($username);
    if($usernamelen < 3) {
        $username = $username.mt_rand(1000, 9999);
    }
    if($usernamelen > 15) {
        $username = cutstr($username, 15, '');
    }
    if (uc_get_user($username)) {
        $username = cutstr($username, 10, '');
        $username = $username.mt_rand(1000, 9999);
    }

    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

    if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
        showmessage('profile_username_protect');
    }

    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if($uid <= 0) {
        if($uid == -1) {
            showmessage('profile_username_illegal');
        } elseif($uid == -2) {
            showmessage('profile_username_protect');
        } elseif($uid == -3) {
            showmessage('profile_username_duplicate');
        } elseif($uid == -4) {
            showmessage('profile_email_illegal');
        } elseif($uid == -5) {
            showmessage('profile_email_domain_illegal');
        } elseif($uid == -6) {
            showmessage('profile_email_duplicate');
        } else {
            showmessage('undefined_action');
        }
    }

    $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
    if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }

    if($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => '',
        ), false, true);
        manage_addnotify('verifyuser');
    }

    include_once libfile('function/stat');
    updatestat('register');

    return $uid;
}

function replaceSpecialChar($strParam){
    $str = "/\ |\/|\~|\!|\@|\#|\\$|\%|\！|\^|\&|\*|\(|\)|\（|\）|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\|/";
    return preg_replace($str,'',$strParam);
}
function removeEmoji($nickname) {

    // Match Emoticons
    $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
    $clean_text = preg_replace($regexEmoticons, '', $nickname);

    // Match Miscellaneous Symbols and Pictographs
    $regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
    $clean_text = preg_replace($regexSymbols, '', $clean_text);

    // Match Transport And Map Symbols
    $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
    $clean_text = preg_replace($regexTransport, '', $clean_text);

    // Match Miscellaneous Symbols
    $regexMisc = '/[\x{2600}-\x{26FF}]/u';
    $clean_text = preg_replace($regexMisc, '', $clean_text);

    // Match Dingbats
    $regexDingbats = '/[\x{2700}-\x{27BF}]/u';
    $clean_text = preg_replace($regexDingbats, '', $clean_text);

    return $clean_text;
}

function wx_syncAvatar($uid, $avatar) {

    if(!$uid || !$avatar) {
        return false;
    }

    if(!$content = dfsockopen($avatar)) {
        return false;
    }

    $tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
    file_put_contents($tmpFile, $content);

    if(!is_file($tmpFile)) {
        return false;
    }

    $result = wx_upload($uid, $tmpFile);
    unlink($tmpFile);

    C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

    return $result;
}

function wx_upload($uid, $localFile) {

    global $_G;
    if(!$uid || !$localFile) {
        return false;
    }

    list($width, $height, $type, $attr) = getimagesize($localFile);
    if(!$width) {
        return false;
    }

    if($width < 10 || $height < 10 || $type == 4) {
        return false;
    }

    $imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
    $fileType = $imageType[$type];
    if(!$fileType) {
        $fileType = '.jpg';
    }
    $avatarPath = $_G['setting']['attachdir'];
    $tmpAvatar = $avatarPath.'./temp/upload'.$uid.$fileType;
    file_exists($tmpAvatar) && @unlink($tmpAvatar);
    file_put_contents($tmpAvatar, file_get_contents($localFile));

    if(!is_file($tmpAvatar)) {
        return false;
    }

    $tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
    $tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
    $tmpAvatarSmall = './temp/upload'.$uid.'small'.$fileType;

    $image = new image;
    if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
        return false;
    }
    if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
        return false;
    }
    if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
        return false;
    }

    $tmpAvatarBig = $avatarPath.$tmpAvatarBig;
    $tmpAvatarMiddle = $avatarPath.$tmpAvatarMiddle;
    $tmpAvatarSmall = $avatarPath.$tmpAvatarSmall;

    $avatar1 = wx_byte2hex(file_get_contents($tmpAvatarBig));
    $avatar2 = wx_byte2hex(file_get_contents($tmpAvatarMiddle));
    $avatar3 = wx_byte2hex(file_get_contents($tmpAvatarSmall));

    $extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
    $result = wx_uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);

    @unlink($tmpAvatar);
    @unlink($tmpAvatarBig);
    @unlink($tmpAvatarMiddle);
    @unlink($tmpAvatarSmall);

    return true;
}
function wx_byte2hex($string) {
    $buffer = '';
    $value = unpack('H*', $string);
    $value = str_split($value[1], 2);
    $b = '';
    foreach($value as $k => $v) {
        $b .= strtoupper($v);
    }

    return $b;
}

function wx_uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
    $s = $sep = '';
    foreach($arg as $k => $v) {
        $k = urlencode($k);
        if(is_array($v)) {
            $s2 = $sep2 = '';
            foreach($v as $k2 => $v2) {
                $k2 = urlencode($k2);
                $s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
                $sep2 = '&';
            }
            $s .= $sep.$s2;
        } else {
            $s .= "$sep$k=".urlencode(uc_stripslashes($v));
        }
        $sep = '&';
    }
    $postdata = uc_api_requestdata($module, $action, $s, $extra);
    return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
}

function wx_convert($post) {
    foreach($post as $k => $v) {
        $post[$k] = diconv($v, 'utf-8', CHARSET);
    }
    return $post;
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>