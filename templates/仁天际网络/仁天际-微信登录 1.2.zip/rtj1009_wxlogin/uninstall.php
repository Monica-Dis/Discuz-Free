<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


if ($_G['cache']['plugin']['rtj1009_wxlogin']['ren_wx_delsql']) {
    $sql = <<<EOF
DROP TABLE IF EXISTS pre_rtj1009_wxlogin_authcode;
DROP TABLE IF EXISTS pre_rtj1009_wxlogin_user;
EOF;
    runquery($sql);
}
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/rtj1009_wxlogin/');
$finish = true;
?>