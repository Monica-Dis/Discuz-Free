<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header_p}-->
<style id="diy_style" type="text/css"></style>
<link rel="stylesheet" href="template/boluo_dy/images/css/h.css">
<link rel="stylesheet" href="template/boluo_dy/images/css/base.css">
<link rel="stylesheet" href="template/boluo_dy/images/css/index.css">

<div class="slideshow">
    <div class="slideshow-image" style="background-image: url('template/boluo_dy/images/bg/bg1.jpg')"></div>
    <div class="slideshow-image" style="background-image: url('template/boluo_dy/images/bg/bg2.jpg')"></div>
    <div class="slideshow-image" style="background-image: url('template/boluo_dy/images/bg/bg3.jpg')"></div>
    <div class="slideshow-image" style="background-image: url('template/boluo_dy/images/bg/bg4.jpg')"></div>
</div>

<div class="container">

    <div class="content">
        <header class="header claerFloat">
            <div class="header-left">
                <a href="http://t.cn/Aiux14ti"><img src="template/boluo_dy/images/logo_p.png" alt="logo"></a>
            </div>
            <div class="header-right">
                <ul class="header-links cl">
                    <!--{if empty($topic) || $topic['useheader']}-->
				        <!--{eval $mnid = getcurrentnav();}-->
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="header-links-item{if $mnid == $nav[navid]} a{/if}" {$nav[nav]}></li><!--{/if}-->
						<!--{/loop}-->
					    <!--{hook/global_nav_extra}-->
                    <!--{/if}-->
                </ul>
            </div>
        </header>
        <div class="middle clearFloat">
            <!--[diy=diy_dyp]--><div id="diy_dyp" class="area"></div><!--[/diy]-->
        </div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer_p}-->
