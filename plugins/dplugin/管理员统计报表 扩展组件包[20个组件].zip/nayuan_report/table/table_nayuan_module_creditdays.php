<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_creditdays.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-09-07 22:07:16.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_creditdays extends table_common_credit_log {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function count_all_by_stime_etime($format, $stime, $etime) {
        $sumfields = array();
        for($i = 1; $i <= 8; $i++) {
            $sumfields[] = "sum(case when extcredits$i < 0 then extcredits$i else 0 end) as c$i" . '0';
            $sumfields[] = "sum(case when extcredits$i < 0 then 0 else extcredits$i end) as c$i" . '1';
        }
        return DB::fetch_all("SELECT FROM_UNIXTIME(dateline, %s) as `time`,".implode($sumfields, ',')." FROM %t WHERE dateline >= %d and dateline < %d GROUP BY FROM_UNIXTIME(dateline, %s)", array($format, $this -> _table, $stime, $etime, $format));
    }

    public function count_by_stime_etime($stime, $etime) {
        $sumfields = array();
        for($i = 1; $i <= 8; $i++) {
            $sumfields[] = "sum(case when extcredits$i < 0 then extcredits$i else 0 end) as c$i" . '0';
            $sumfields[] = "sum(case when extcredits$i < 0 then 0 else extcredits$i end) as c$i" . '1';
        }
        return DB::fetch_first("SELECT ".implode($sumfields, ',')." FROM %t WHERE dateline >= %d and dateline < %d", array($this -> _table, $stime, $etime));
    }

    public function fetch_first_time() {
        return DB::result_first("SELECT dateline FROM %t ORDER BY `logid` LIMIT 1", array($this -> _table));
    }

    public function sum_operation_by_time($stime, $etime) {
        $sumfields = array();
        for($i = 1; $i <= 8; $i++) {
            $sumfields[] = "sum(case when extcredits$i < 0 then extcredits$i else 0 end) as c$i" . '0';
            $sumfields[] = "sum(case when extcredits$i < 0 then 0 else extcredits$i end) as c$i" . '1';
        }
        return DB::fetch_all("SELECT `operation`, ".implode($sumfields, ',')." FROM %t WHERE dateline >= %d and dateline < %d GROUP BY `operation`", array($this -> _table, $stime, $etime));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>