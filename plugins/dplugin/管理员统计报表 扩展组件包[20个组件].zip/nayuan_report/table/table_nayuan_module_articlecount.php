<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_articlecount.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2021-03-08 11:58:15.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_articlecount extends discuz_table {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function fetch_count_by_category() {
        $fields = "a.catid, b.catname, sum(a.viewnum) as viewnum, sum(a.commentnum) as commentnum, sum(a.favtimes) as favtimes, sum(a.sharetimes) as sharetimes";
        return DB::fetch_all("SELECT $fields FROM %t a, %t b where a.catid = b.catid group by a.catid order by a.viewnum", array('portal_article_count', 'portal_category'));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>