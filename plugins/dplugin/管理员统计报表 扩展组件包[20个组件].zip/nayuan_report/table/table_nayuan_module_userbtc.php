<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_userbtc.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-07-05 08:21:25.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_userbtc extends table_common_credit_log {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function count_btc_by_time($nums, $stime, $etime) {
        $sumfields = array();
        for($i = 1; $i <=8; $i++) {
            $sumfields[] = "sum(extcredits$i) as extcredits$i";
        }
        $sumfields = implode(",", $sumfields);
        return DB::fetch_all("SELECT a.*, b.username FROM (SELECT `uid`,count(*) as `nums`, $sumfields FROM %t WHERE `operation` = 'BTC' AND `dateline` >= %d AND `dateline` < %d GROUP BY `uid` ORDER BY `nums` desc LIMIT %d) a, %t b WHERE a.uid = b.uid", array($this -> _table, $stime, $etime, $nums, 'common_member'));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>