<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_userbirthyear.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_userbirthyear extends table_common_member_profile {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function count_all_by_birthyear() {
        return DB::fetch_all("SELECT `birthyear`,count(*) as `value` FROM %t GROUP BY `birthyear`", array($this -> _table));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>