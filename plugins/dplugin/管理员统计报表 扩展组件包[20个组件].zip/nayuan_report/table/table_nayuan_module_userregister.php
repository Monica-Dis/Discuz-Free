<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_userregister.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Created by IntelliJ IDEA.
 * User: DisM!Ӧ������
 * Date: 2014/11/2
 * Time: 17:31
 */

class table_nayuan_module_userregister extends table_common_member {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function fetch_first_user_regdate() {
        return DB::result_first("SELECT `regdate` FROM %t ORDER BY `uid` LIMIT 1", array($this -> _table));
    }

    public function count_by_regdate($stime, $etime) {
        return DB::result_first('SELECT COUNT(*) FROM %t WHERE `regdate` >= %d AND `regdate` < %d', array($this->_table, $stime, $etime));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>