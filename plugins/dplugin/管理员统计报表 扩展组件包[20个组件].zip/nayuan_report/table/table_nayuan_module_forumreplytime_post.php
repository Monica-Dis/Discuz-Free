<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumreplytime_post.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumreplytime_post extends table_forum_post {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function fetch_first_reply_by_stime_etime($stime, $etime) {
        return DB::fetch_all("SELECT `tid`,`dateline` FROM %t WHERE dateline >= %d and dateline < %d AND `position` = 2", array(self::get_tablename(0), $stime, $etime));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>