<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_usergroup.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Created by IntelliJ IDEA.
 * User: DisM!Ӧ������
 * Date: 2014/11/2
 * Time: 17:31
 */

class table_nayuan_module_usergroup extends table_common_member {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function count_all_by_groupid() {
        return DB::fetch_all("SELECT `groupid`,count(*) as `value` FROM %t GROUP BY `groupid`", array($this -> _table));
    }

    public function fetch_all_usergroup() {
        return DB::fetch_all("SELECT `groupid`,`type`,`grouptitle` FROM %t GROUP BY `groupid`", array('common_usergroup'));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>