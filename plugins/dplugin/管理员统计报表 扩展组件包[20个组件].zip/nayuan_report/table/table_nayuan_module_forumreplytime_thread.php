<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumreplytime_thread.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumreplytime_thread extends table_forum_thread {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function fetch_thread_dateline_by_tids($tids) {
        return DB::fetch_all("SELECT `fid`,`tid`,`dateline` FROM %t WHERE `tid` IN (%n)", array(self::get_table_name(0), $tids));
    }


}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>