<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumforumuv.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-07-06 11:03:15.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumforumuv {

    public function __construct() {

    }

    public function count_forum_by_time($stime, $etime) {
        return DB::fetch_all("SELECT `id`,count(*) as nums FROM %t WHERE `time` >= %d AND `time` < %d AND `type` = %d GROUP BY `id`", array('nayuan_data_cache', $stime, $etime, 3050001));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>