<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumthreadarea.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-07-23 11:26:02.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumthreadarea extends table_forum_thread {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function exist_newthread_now_by_uid($uid, $exclude, $time) {
        return DB::fetch_all("SELECT count(*) FROM %t WHERE `tid` <> %d AND `authorid` = %d AND `time` >= %d LIMIT 1", array($this -> _table, $exclude, $uid, $time));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>