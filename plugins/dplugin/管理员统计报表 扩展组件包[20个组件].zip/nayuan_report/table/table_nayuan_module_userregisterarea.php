<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_userregisterarea.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-07-23 11:26:02.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Created by IntelliJ IDEA.
 * User: DisM!Ӧ������
 * Date: 2014/11/2
 * Time: 17:31
 */

class table_nayuan_module_userregisterarea extends table_common_member {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function fetch_first_user_regdate() {
        return DB::result_first("SELECT `regdate` FROM %t ORDER BY `uid` LIMIT 1", array($this -> _table));
    }

    public function fetch_user_by_regdate($stime, $etime) {
        return DB::fetch_all('SELECT a.`uid`,a.`regip` FROM %t a, %t b WHERE a.uid = b.uid AND b.`regdate` >= %d AND b.`regdate` < %d', array('common_member_status', $this->_table, $stime, $etime));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>