<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumforumthreads.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumforumthreads extends table_forum_thread {

    public function __construct() {
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function count_threads_by_time($stime, $etime) {
        return DB::fetch_all("SELECT `fid`, count(*) as `nums` FROM %t WHERE dateline >= %d and dateline < %d GROUP BY `fid`", array($this -> _table, $stime, $etime));
    }

}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>