<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_forumthread.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_forumthread_loaddata($type, $s_type, &$s_stime, &$s_etime) {
    if($s_type == 2) {
        $mintime = 100001;
        $_date_format = 'Y-m';
    }else if($s_type == 3) {
        $mintime = 1000;
        $_date_format = 'Y';
    }else{
        $mintime = 10000101;
        $_date_format = 'Y-m-d';
    }
    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_one') -> fetch_first_update_time($type, $mintime);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else if(strlen($s_stime) == 8){
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }else if(strlen($s_stime) == 6) {
            $s_stime = preg_replace('/^(\d{4})(\d{2})$/', '$1-$2', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);
    $_data = C::t('#nayuan_report#nayuan_data_one') -> fetch_all_by_time($type, $_stime, $_etime);
    $_nowtime = dgmdate(time(), str_replace('-','', $_date_format));
    if($_etime >= $_nowtime) {
        $value = C::t('#nayuan_report#nayuan_module_forumthread') -> count_by_stime_etime(dmktime(dgmdate(time(), 'Y-m-d')), time());
        if(!$_data) {
            $_data[] = array('time' => $_nowtime, 'value' => $value);
        }else{
            $_last_index = count($_data) - 1;
            $_last_data = &$_data[$_last_index];
            if($_last_data['time'] == $_nowtime) {
                $_last_data['value'] = $_last_data['value'] + $value;
            }else{
                $_data[] = array('time' => $_nowtime, 'value' => $value);
            }
        }
    }

    return $_data;
}

function nayuanreport_forumthread_showchart($_title, $_data, $_lang, $_width, $_height) {
    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter(); /*dism·taobao·com*/
    if($_data) {
        $_labels = $_values = array();
        foreach ($_data as $_item) {
            $_labels[] = $_item['time'];
            $_values[] = $_item['value'];
        }
        $_labels = implode(',', $_labels);
        $_values = implode(',', $_values);
        echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        grid: {
            left: '50px',
            right: '50px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_labels]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [{
            name: '$_chart_yaxis_name',
            type: 'line',
            smooth: true,
            data: [$_values]
        }]
    });
</script>
SCRIPT;

    }
}


?>