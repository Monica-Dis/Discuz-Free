<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_forumforumuv.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-07-06 11:03:15.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_forumforumuv_loaddata($type, $s_type, &$s_stime, &$s_etime) {
    if($s_type == 2) {
        $mintime = 100001;
        $_date_format = 'Y-m';
    }else{
        $mintime = 10000101;
        $_date_format = 'Y-m-d';
    }

    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_more') -> fetch_first_update_time($type, $mintime);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else if(strlen($s_stime) == 8){
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }else if(strlen($s_stime) == 6) {
            $s_stime = preg_replace('/^(\d{4})(\d{2})$/', '$1-$2', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }

    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);
    $_result = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    $_nowtime = dgmdate(time(), str_replace('-','', $_date_format));
    if($_etime >= $_nowtime) {
        $_data = C::t('#nayuan_report#nayuan_module_forumforumuv') -> count_forum_by_time(dmktime(dgmdate(time(), 'Y-m-d')), time());

        $_last_data = &$_result[count($_result) - 1];
        if($_last_data['time'] < $_nowtime) {
            $_cache = array();
            foreach ($_data as $_item) {
                $_cache[$_item['id']] = $_item['nums'];
            }
            $_result[] = array(
                'time' => $_nowtime,
                'value' => serialize($_cache)
            );
        }else{
            $_cache = unserialize($_last_data['value']);
            foreach ($_data as $_item) {
                if($_cache[$_item['id']]) {
                    $_cache[$_item['id']] += $_item['nums'];
                }else{
                    $_cache[$_item['id']] = $_item['nums'];
                }
            }
            $_last_data['value'] = serialize($_cache);
        }
    }

    return $_result;
}

function nayuanreport_forumforumuv_showchart($_title, $_table_title, $_forums, $_data, $_lang, $_width, $_height) {
    global $_G;

    foreach ($_forums as $v) {
        if($v == '') {
            $_forums = array();
            break;
        }
    }

    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];
    showtableheader($_title . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:export_echart_data();">'.$_lang['lang_export'].'</a>');
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter(); /*dism·taobao·com*/
    if($_data) {

        $_sumdatacache = array();

        $_xaxis = $_datacache = $fids = array();
        foreach ($_data as $_item) {
            $_xaxis[] = $_item['time'];
            $_values = unserialize($_item['value']);
            foreach ($_values as $_fid => $_nums) {
                if($_sumdatacache[$_fid]) {
                    $_sumdatacache[$_fid] += $_nums;
                }else{
                    $_sumdatacache[$_fid] = $_nums;
                }

                if(in_array($_fid, $fids)) continue;
                if(!$_forums || in_array($_fid, $_forums)) {
                    $fids[] = $_fid;
                    $_datacache[$_fid] = array();
                }
            }
        }

        foreach ($_data as $_item) {
            $_values = unserialize($_item['value']);
            foreach ($fids as $fid) {
                if($_values[$fid]) {
                    $_datacache[$fid][] = $_values[$fid];
                }else{
                    $_datacache[$fid][] = 0;
                }
            }
        }

        $forumnamecache = array();
        if($fids) {
            $forumnames = C::t('forum_forum') -> fetch_all_name_by_fid($fids);
            foreach ($forumnames as $_item) {
                $forumnamecache[$_item['fid']] = $_item['name'];
            }
        }

        $_series = $_legend = array();
        foreach ($_datacache as $_fid => $values) {
            $_name = $forumnamecache[$_fid] . '(' . $_fid . ')';
            $_legend[] = "\"$_name\"";
            $_series[] = '{name:"'.$_name.'",type:"line", smooth: true, data: ['.implode(',', $values).']}';
        }

        $_series = implode(',', $_series);
        $_xaxis = implode(',', $_xaxis);
        $_legend = implode(',', $_legend);

        echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'item'},
        grid: {
            left: '100px',
            right: '150px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 20,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_xaxis]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [$_series]
    });
</script>
SCRIPT;

        nayuanreport_forumforumuv_sumtable($_table_title, $_lang, $_sumdatacache, $forumnamecache);
    }

}

function nayuanreport_forumforumuv_sumtable($_title, $_lang, $_datacache, $_forumnamecache) {

    $_table_data = array();
    foreach ($_datacache as $_fid => $_nums) {
        $_table_data[] = array(
            'fid' => $_fid,
            'nums' => $_nums,
            'name' => $_forumnamecache[$_fid],
        );
    }
    usort($_table_data, function ($a, $b) {
        if($a['nums'] > $b['nums']) return -1;
        return 1;
    });

    showtableheader($_title . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:export_table_data();">'.$_lang['lang_export'].'</a>', '', 'id="forumuv-list"');
    showsubtitle(array(
        '',
        $_lang['lang_table_header_fid'],
        $_lang['lang_table_header_forum'],
        $_lang['lang_table_header_nums'],
    ), 'header', array(
        'class="td25"',
        'style="width: 100px"',
        '',
        'style="width: 150px; text-align:right"',
    ));

    foreach ($_table_data as $_index => $_it) {
        showtablerow('', array(
            'class="td25"',
            'style="width: 100px"',
            '',
            'style="width: 150px; text-align:right"',
        ), array(
            $_index + 1,
            "<a href=\"forum.php?mod=forumdisplay&fid=$_it[fid]\" target=\"_blank\">$_it[fid]</a>",
            "<a href=\"forum.php?mod=forumdisplay&fid=$_it[fid]\" target=\"_blank\">$_it[name]</a>",
            $_it['nums'],

        ));
    }
    showtablefooter(); /*dism·taobao·com*/
}


?>