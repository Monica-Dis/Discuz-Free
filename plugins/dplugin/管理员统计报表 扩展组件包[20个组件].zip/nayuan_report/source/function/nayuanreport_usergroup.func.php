<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_usergroup.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_usergroup_loaddata($type, $s_type, $_lang, &$s_stime, &$s_etime) {
    $_date_format = 'Y-m-d';
    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_more') -> fetch_first_update_time($type);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else{
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);

    $_data = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    if($s_type == 1 && count($_data) < 2) {
        echo '<script>showDialog("' . $_lang['lang_more_days_error'] . '", "alert")</script>';
    }
    return $_data;
}

function nayuanreport_usergroup_showchart($_title, $_data, $_lang, $_width, $_height) {
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter(); /*dism·taobao·com*/
    $_filter = $_data['filter'];
    $_data = $_data['data'];
    if($_data) {
        if(count($_data) == 1) {
            nayuanreport_usergroup_showchart_pie($_title, unserialize($_data[0]['value']), $_filter, $_lang);
        }else{
            nayuanreport_usergroup_showchart_line($_title, $_data, $_filter, $_lang);
        }
    }
}

function nayuanreport_usergroup_showchart_line($_title, $_data, $_filter, $_lang) {
    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];

    $_groups = C::t('#nayuan_report#nayuan_module_usergroup') -> fetch_all_usergroup();
    foreach ($_groups as &$_group) {
        $_group['values'] = array();
    }

    $_xaxis = array();
    foreach ($_data as $_item) {
        $_xaxis[] = $_item['time'];
        $_groupdatacache = unserialize($_item['value']);
        foreach ($_groups as &$_group) {
            $_v = $_groupdatacache[$_group['groupid']];
            if($_v) {
                $_group['values'][] = $_v;
            }else{
                $_group['values'][] = 0;
            }
        }
    }

    $_series = $_legend = array();
    foreach ($_groups as $_group) {
        if(!$_filter[$_group['type']]) continue;
        $_legend[] = "\"$_group[grouptitle]\"";
        $_series[] = '{name:"'.$_group['grouptitle'].'",type:"line", smooth: true, data: ['.implode(',', $_group['values']).']}';
    }
    $_series = implode(',', $_series);
    $_xaxis = implode(',', $_xaxis);
    $_legend = implode(',', $_legend);
    echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        grid: {
            left: '50px',
            right: '170px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 10,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_xaxis]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [$_series]
    });
</script>
SCRIPT;

}

function nayuanreport_usergroup_showchart_pie($_title, $_data, $_filter, $_lang) {
    $_chart_series_name = $_lang['lang_yaxis_name'];

    $_groups = C::t('#nayuan_report#nayuan_module_usergroup') -> fetch_all_usergroup();
    foreach ($_groups as &$_group) {
        $_group['values'] = array();
    }

    $_series = $_legend = array();
    foreach ($_groups as $_group) {
        if(!$_filter[$_group['type']]) continue;
        $_v = $_data[$_group['groupid']];
        if(!$_v) {
            $_v = 0;
        }
        $_legend[] = "\"$_group[grouptitle]\"";
        $_series[] = '{name:"'.$_group['grouptitle'].'",value: '.$_v.'}';
    }
    $_series = implode(',', $_series);
    $_legend = implode(',', $_legend);
    echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        grid: {
            left: '50px',
            right: '170px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 10,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        series: [{
            name: '$_chart_series_name',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: [$_series],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    });
</script>
SCRIPT;
}




?>