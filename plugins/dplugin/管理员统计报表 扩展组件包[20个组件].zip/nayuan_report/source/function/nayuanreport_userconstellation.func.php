<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_userconstellation.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_userconstellation_loaddata($type, $s_type, $lang, &$s_stime, &$s_etime) {
    $_date_format = 'Y-m-d';
    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_more') -> fetch_first_update_time($type);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else{
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);

    $_data = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    if($s_type == 1 && count($_data) < 2) {
        echo '<script>showDialog("' . $lang['lang_more_days_error'] . '", "alert")</script>';
    }
    return $_data;
}

function nayuanreport_userconstellation_showchart($_title, $_data, $_lang, $_width, $_height) {
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter(); /*dism·taobao·com*/
    if($_data) {
        if(count($_data) == 1) {
            nayuanreport_userconstellation_showchart_pie($_title, unserialize($_data[0]['value']), $_lang);
        }else{
            nayuanreport_userconstellation_showchart_line($_title, $_data, $_lang);
        }
    }
}

function nayuanreport_userconstellation_showchart_line($_title, $_data, $_lang) {
    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];

    $_xaxis = $_cache = array();
    foreach ($_data as $_item) {
        $_xaxis[] = $_item['time'];
        $_values = unserialize($_item['value']);
        $_xn = count($_xaxis) - 1;
        foreach ($_values as $_id => &$_v) {
            if(!$_cache[$_id]) {
                $_cache[$_id] = array();
            }
            $_cn = count($_cache[$_id]);
            $_n = $_xn - $_cn;
            if($_n > 0) {
                $_cache[$_id] = array_merge($_cache[$_id], array_fill(0, $_n, 0));
            }
            $_cache[$_id][] = $_v;
        }
    }

    $_series = $_legend = array();
    ksort($_cache);
    foreach ($_cache as $_c => $_values) {
        if(!$_c) {
            $_c = $_lang['lang_unknown'];
        }
        $_legend[] = "\"$_c\"";
        $_series[] = '{name:"'.$_c.'",type:"line", smooth: true, data: ['.implode(',', $_values).']}';
    }
    $_series = implode(',', $_series);
    $_xaxis = implode(',', $_xaxis);
    $_legend = implode(',', $_legend);
    echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        grid: {
            left: '50px',
            right: '170px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 10,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_xaxis]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [$_series]
    });
</script>
SCRIPT;

}

function nayuanreport_userconstellation_showchart_pie($_title, $_data, $_lang) {
    $_chart_series_name = $_lang['lang_yaxis_name'];

    $_series = $_legend = array();
    krsort($_data);
    foreach ($_data as $_c => $_value) {
        if(!$_c) {
            $_c = $_lang['lang_unknown'];
        }
        $_legend[] = "\"$_c\"";
        $_series[] = '{name:"'.$_c.'",value: '.$_value.'}';
    }
    $_series = implode(',', $_series);
    $_legend = implode(',', $_legend);
    echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        grid: {
            left: '50px',
            right: '170px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 10,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        series: [{
            name: '$_chart_series_name',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: [$_series],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    });
</script>
SCRIPT;
}




?>