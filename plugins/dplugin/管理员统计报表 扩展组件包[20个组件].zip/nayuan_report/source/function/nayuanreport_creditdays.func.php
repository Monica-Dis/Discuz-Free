<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_creditdays.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-09-07 22:07:16.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_creditdays_loaddata($type, $s_type, &$s_stime, &$s_etime) {
    if($s_type == 2) {
        $mintime = 100001;
        $_date_format = 'Y-m';
    }else if($s_type == 3) {
        $mintime = 1000;
        $_date_format = 'Y';
    }else{
        $mintime = 10000101;
        $_date_format = 'Y-m-d';
    }
    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_more') -> fetch_first_update_time($type, $mintime);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else if(strlen($s_stime) == 8){
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }else if(strlen($s_stime) == 6) {
            $s_stime = preg_replace('/^(\d{4})(\d{2})$/', '$1-$2', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);
    $_data = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    $_nowtime = dgmdate(time(), str_replace('-','', $_date_format));
    if($_etime >= $_nowtime) {
        $value = C::t('#nayuan_report#nayuan_module_creditdays') -> count_by_stime_etime(dmktime(dgmdate(time(), 'Y-m-d')), time());
        if(!$_data) {
            $_data[] = array('time' => $_nowtime, 'value' => serialize($value));
        }else{
            $_last_index = count($_data) - 1;
            $_last_data = $_data[$_last_index];
            if($_last_data['time'] == $_nowtime) {
                $_last_data = unserialize($_last_data['value']);
                foreach ($_last_data as $name => $v) {
                    $_last_data[$name] = $v + ($value[$name] ? $value[$name] : 0);
                }
                $_data[$_last_index] = array('time' => $_nowtime, 'value' => serialize($_last_data));
            }else{
                $_data[] = array('time' => $_nowtime, 'value' => serialize($value));
            }
        }
    }

    return $_data;
}

function nayuanreport_creditdays_showchart($_title, $_data, $_lang, $_width, $_height) {
    global $_G;

    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter(); /*dism·taobao·com*/
    if($_data) {
        $_extcreditcache = array();
        for($i=1; $i<=8; $i++) {
            $extcredit = $_G['setting']['extcredits'][$i];
            if(!$extcredit) continue;
            $_extcreditcache[] = array(
                'name' => 'c' . $i . '1',
                'title' => $extcredit['title'] . "[$_lang[lang_up]]",
                'values' => array()
            );
            $_extcreditcache[] = array(
                'name' => 'c' . $i . '0',
                'title' => $extcredit['title'] . "[$_lang[lang_down]]",
                'values' => array()
            );
        }

        $_xaxis = array();
        foreach ($_data as $_item) {
            $_xaxis[] = $_item['time'];
            $_data = unserialize($_item['value']);
            foreach ($_extcreditcache as &$_credit) {
                $_credit['values'][] = $_data[$_credit['name']] ? $_data[$_credit['name']] : 0;
            }
        }

        $_series = $_legend = array();
        foreach ($_extcreditcache as $_item) {
            $_legend[] = "\"$_item[title]\"";
            $_series[] = '{name:"'.$_item['title'].'",type:"line", smooth: true, data: ['.implode(',', $_item['values']).']}';
        }

        $_series = implode(',', $_series);
        $_xaxis = implode(',', $_xaxis);
        $_legend = implode(',', $_legend);
        echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 50,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_xaxis]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [$_series]
    });
    
    nayuanDataChart.on('click', function (params) {
        console.log(params);
    });
</script>
SCRIPT;

    }
}

function nayuanreport_creditdays_showsumlist($stime, $etime, $lang) {
    global $_G, $adminurl, $m, $s;
    if(strlen($stime) == 4) {
        $stime = $stime . '-01-01';
        $etime = $etime . '-01-01';
        $etime = strtotime('+1 year', strtotime($etime));
    }else if(strlen($stime) == 7) {
        $stime = $stime . '-01';
        $etime = $etime . '-01';
        $etime = strtotime('+1 month', strtotime($etime));
    }else{
        $etime = strtotime('+1 day', strtotime($etime));
    }
    $stime = dmktime($stime);

    $list = C::t('#nayuan_report#nayuan_module_creditdays') -> sum_operation_by_time($stime, $etime);

    $index = array();
    $headers = array(cplang('type'));
    for($i=1; $i<=8; $i++) {
        $extcredit = $_G['setting']['extcredits'][$i];
        if($extcredit) {
            $headers[] = $extcredit['title'];
            $index[] = $i;
        }
    }

    showtableheader(nayuan_strreplace($lang['lang_sum_list_title'], array('stime' => dgmdate($stime, 'Y-m-d H:i'), 'etime' => dgmdate($etime - 1, 'Y-m-d H:i'))). '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:export_table_data();">'.$lang['lang_export'].'</a>');
    showtablefooter(); /*dism·taobao·com*/
    echo '<table style="width: 100%" cellpadding="20"><tr><td width="50%" style="vertical-align: top">';
    showtableheader($lang['lang_sum_plus'] ,'', 'id="plus_table_list"');
    $css = array('');
    foreach ($index as $_i) {
        $css[] = 'class="td23" style="text-align:right"';
    }
    showsubtitle($headers, 'header', $css);

    $num = 0;
    foreach ($list as $_item) {
        $ss = 0;
        foreach ($index as $_i) {
            $ss += $_item['c'.$_i.'1'];
        }
        if($ss <= 0) continue;
        $num++;
        $values = array(cplang('logs_credit_update_'.$_item['operation']));
        foreach ($index as $_i) {
            $values[] = $_item['c'.$_i.'1'] ? "<a href=\"".ADMINSCRIPT."?action=$adminurl&m=$m&s=$s&a=user&q_stime=$stime&q_etime=$etime&q_type=$_item[operation]&q_i=$_i\">".$_item['c'.$_i.'1'].'</a>' : 0;
        }
        showtablerow('', $css, $values);
    }
    if($num == 0) {
        showtablerow('', array('class="center" colspan="9"'), array($lang['lang_no_data']));
    }
    showtablefooter(); /*dism·taobao·com*/
    echo '</td><td width="50%" style="vertical-align: top">';
    showtableheader($lang['lang_sum_sub'] ,'', 'id="sub_table_list"');
    showsubtitle($headers, 'header', $css);

    $num = 0;
    foreach ($list as $_item) {
        $ss = 0;
        foreach ($index as $_i) {
            $ss += $_item['c'.$_i.'0'];
        }
        if($ss >= 0) continue;
        $num++;
        $values = array(cplang('logs_credit_update_'.$_item['operation']));
        foreach ($index as $_i) {
            $values[] = $_item['c'.$_i.'0'] ? "<a href=\"".ADMINSCRIPT."?action=$adminurl&m=$m&s=$s&a=user&q_stime=$stime&q_etime=$etime&q_type=$_item[operation]&q_i=$_i\">".$_item['c'.$_i.'0'].'</a>' : 0;
        }
        showtablerow('', $css, $values);
    }
    if($num == 0) {
        showtablerow('', array('class="center" colspan="9"'), array($lang['lang_no_data']));
    }
    showtablefooter(); /*dism·taobao·com*/
    echo '</td></tr></table>';
    echo <<<SCRIPT
<script type="text/Javascript">
    function export_table_data() {
        var excel = '';
        var plustrs = document.getElementById('plus_table_list').getElementsByTagName('tr');
        for(var i = 0; i < plustrs.length; i++) {
            var tds = plustrs[i].getElementsByTagName('td');
            if(tds.length == 0) {
                tds = plustrs[i].getElementsByTagName('th');
            }
            for(var j = 0; j < tds.length; j++) {
                excel += tds[j].innerText + ',';
            }
            excel += '\\n';
        }
        excel += '\\n\\n';
        var subtrs = document.getElementById('sub_table_list').getElementsByTagName('tr');
        for(var i = 0; i < subtrs.length; i++) {
            var tds = subtrs[i].getElementsByTagName('td');
            if(tds.length == 0) {
                tds = subtrs[i].getElementsByTagName('th');
            }
            for(var j = 0; j < tds.length; j++) {
                excel += tds[j].innerText + ',';
            }
            excel += '\\n';
        }
        
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>
SCRIPT;

}

function nayuanreport_creditdays_showuserlist($lang) {
    global $_G, $adminurl, $m, $s;
    $operationlist = array('TRC', 'RTC', 'RAC', 'MRC', 'TFR', 'RCV', 'CEC', 'ECU', 'SAC', 'BAC', 'PRC', 'RSC', 'STC', 'BTC', 'AFD', 'UGP', 'RPC', 'ACC', 'RCT', 'RCA', 'RCB', 'CDC', 'RKC', 'BME', 'RPR', 'RPZ');

    $page = max(1, nayuan_get('page'));
    $q_pagesize = max(20, intval($_GET['q_pagesize']));
    $start_limit = ($page - 1) * $q_pagesize;

    $pageadd = "m=$m&s=$s&a=user";
    $q_stime = nayuan_get('q_stime', 1);
    if($q_stime && strpos($q_stime, '-')) {
        $q_stime = dmktime($q_stime);
    }
    $q_etime = nayuan_get('q_etime', 1);
    if($q_etime && strpos($q_etime, '-')) {
        $q_etime = dmktime($q_etime);
    }

    $user = nayuan_get('q_user', 1, '');
    $q_type = nayuan_get('q_type', 1);

    if($user) {
        if(preg_match('/^\d+$/', $user)) {
            $q_uid = $user;
        }else{
            $q_uid = ($uid = C::t('common_member')->fetch_uid_by_username($user)) ? $uid : C::t('common_member_archive')->fetch_uid_by_username($user);
            if(!$q_uid) $q_uid = -1;
        }
        $pageadd .= '&q_user='.$user;
    }
    if($q_type) {
        if(in_array($q_type, $operationlist)) {
            $pageadd .= '&q_type='.$q_type;
        }
    }
    if($q_stime) {
        $pageadd .= '&q_stime='.$q_stime;
    }
    if($q_etime) {
        $pageadd .= '&q_etime='.$q_etime;
    }

    if(nayuan_get('export')) {
        $csvstr = '';
        $csvstr .= cplang('username') . ',';
        $csvstr .= cplang('time') . ',';
        $csvstr .= cplang('type') . ',';
        foreach($_G['setting']['extcredits'] as $id => $credit) {
            if(!$credit) continue;
            $csvstr .= $credit['title'] . ',';
        }
        $csvstr .= "\n";
        $page = 1;
        $q_pagesize = 10000;
        @set_time_limit(0);

        while(true) {
            $start_limit = ($page - 1) * $q_pagesize;
            $logs = C::t('common_credit_log')->fetch_all_by_search($q_uid, $q_type, $q_stime, $q_etime, 0, 0, array(), $start_limit, $q_pagesize, 0);
            if(!$logs) break;
            foreach ($logs as $log) {
                $csvstr .= $log['uid'] . ',';
                $csvstr .= dgmdate($log['dateline'], 'y-n-j H:i') . ',';
                $csvstr .= cplang('logs_credit_update_'.$log['operation']) . ',';
                foreach($_G['setting']['extcredits'] as $id => $credit) {
                    if(!$credit) continue;
                    $csvstr .= $log['extcredits'.$id] . ',';
                }
                $csvstr .= "\n";
            }
            if(count($logs) != $q_pagesize) break;
            $page++;
        }

        define('FOOTERDISABLED',1);
        $filename = 'credit_log_'.time().'.csv';
        ob_end_clean();
        header('Content-Encoding: none');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.$filename);
        header('Pragma: no-cache');
        header('Expires: 0');
        if($_G['charset'] != 'gbk') {
            $detail = diconv($csvstr, $_G['charset'], 'GBK');
        }
        echo $detail;
        exit();
    }else{
        $select_operation_html = '<select name="q_type">';
        $select_operation_html .= '<option value="">'.cplang('logs_select_operation').'</option>';
        foreach($operationlist as $row) {
            $select_operation_html .= '<option value="'.$row.'"'.($row == $q_type ? ' selected="selected"' : '').'>'.cplang('logs_credit_update_'.$row).'</option>';
        }
        $select_operation_html .= '</select>';

        showformheader($adminurl . "&m=$m&s=$s&a=user");
        showtableheader('search', 'fixpadding');
        showtablerow('', array('class="td23"', 'width="150"', 'class="td23"', ''),
            array(
                cplang('username'), '<input type="text" name="q_user" class="txt" value="'.$user.'" />',
                cplang('time'), '<input type="text" name="q_stime" class="txt" value="'.(dgmdate($q_stime, 'Y-m-d')).'" onclick="showcalendar(event, this)" />- <input type="text" name="q_etime" class="txt" value="'.(dgmdate($q_etime, 'Y-m-d')).'" onclick="showcalendar(event, this)" />',
            )
        );
        showtablerow('', array('class="td23"', 'width="150"', 'class="td23"', ''),
            array(
                cplang('logs_lpp'), '<input type="text" name="q_pagesize" class="txt" value="'.$q_pagesize.'" size="5" /></label>',
                cplang('type'), $select_operation_html . '&nbsp;&nbsp;&nbsp;<input type="submit" name="srchlogbtn" class="btn" value="'.cplang('search').'" />',
            )
        );
        showtablefooter(); /*dism·taobao·com*/
        showformfooter(); /*dism _ taobao _com*/
        echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
        showtableheader($lang['lang_user_list_title'] . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action='.$adminurl.'&'.$pageadd.'&export=1">'.$lang['lang_export'].'</a>', 'fixpadding');
        $headers = array(
            cplang('username'),
            cplang('time'),
            cplang('type'),
        );
        $css = array('class="td23"','class="td23"','');
        foreach($_G['setting']['extcredits'] as $id => $credit) {
            if(!$credit) continue;
            $headers[] = $credit['title'];
            $css[] = 'class="td25"';
        }
        showtablerow('class="header"', array(), $headers);

        $num = C::t('common_credit_log')->count_by_search($q_uid, $q_type, $q_stime, $q_etime, 0, 0, array(), 0);

        $mpurl = ADMINSCRIPT."?action=$adminurl&".$pageadd;
        $multipage = multi($num, $q_pagesize, $page, $mpurl, 0, 3);

        $logs = C::t('common_credit_log')->fetch_all_by_search($q_uid, $q_type, $q_stime, $q_etime, 0, 0, array(), $start_limit, $q_pagesize, 0);
        $luid = array();
        foreach($logs as $log) {
            $luid[$log['uid']] = $log['uid'];
        }
        $members = C::t('common_member')->fetch_all($luid);
        foreach($logs as $log) {
            $log['username'] = $members[$log['uid']]['username'];
            $log['dateline'] = dgmdate($log['dateline'], 'y-n-j H:i');

            $values = array(
                "<a href=\"home.php?mod=space&uid=$log[uid]\" target=\"_blank\">$log[username]",
                $log['dateline'],
                cplang('logs_credit_update_'.$log['operation']),
            );
            foreach($_G['setting']['extcredits'] as $id => $credit) {
                if(!$credit) continue;
                $values[] = $log['extcredits'.$id] ? $log['extcredits'.$id] : '';
            }
            showtablerow('', array('class="bold"'), $values);
        }

        showsubmit('', '', '', '', $multipage);
    }

}





?>