<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_creditdays.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-09-07 22:07:16.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 5020;
$m = 'credit';
$s = 'days';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'user') {
    nayuanreport_creditdays_showuserlist($lang_nayuan_report);
}else if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay || $_lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_type = nayuan_get('s_type', 0, 1);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);
    nayuanreport_show_search_form($s_type, $s_stime, $s_etime, "$adminurl&m=$m&s=$s");
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_creditdays_loaddata($type, $s_type, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_creditdays_showchart($_chart_title, $_data, $lang_nayuan_report, '100%', '350px');

    nayuanreport_creditdays_showsumlist($s_stime, $s_etime, $lang_nayuan_report);

}else if($a == 'init') {

    $_etime = dmktime(dgmdate(time(), 'Y-m-d'));
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay) {
        $_stime = C::t('#nayuan_report#nayuan_module_creditdays') -> fetch_first_time();
        if(!$_stime) $_stime = time();
    }else{
        $_stime = dmktime(preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $_lastUpdateDay)) + 86400;
    }

    $daycache = $months = $years = array();
    $_data = C::t('#nayuan_report#nayuan_module_creditdays') -> count_all_by_stime_etime('%Y%m%d', $_stime, $_etime);
    foreach ($_data as $_item) {
        $_time = $_item['time'];
        unset($_item['time']);
        preg_match('/^(\d{4})(\d{2})(\d{2})$/', $_time, $_matchs);
        $_year = $_matchs[1];
        $_month = $_matchs[1].$_matchs[2];
        if(!$years[$_year]) $years[$_year] = 1;
        if(!$months[$_month]) $months[$_month] = 1;
        C::t('#nayuan_report#nayuan_data_more') -> insert(array(
            'time' => $_time,
            'type' => $type,
            'value' => serialize($_item)
        ));
        $daycache[$_time] = 1;
    }

    $emptydata = array(
        'c10' => 0, 'c20' => 0, 'c30' => 0, 'c40' => 0,
        'c50' => 0, 'c60' => 0, 'c70' => 0, 'c80' => 0,
        'c11' => 0, 'c21' => 0, 'c31' => 0, 'c41' => 0,
        'c51' => 0, 'c61' => 0, 'c71' => 0, 'c81' => 0
    );
    $_emptydatavalue = serialize($emptydata);
    while($_stime < $_etime) {
        $_time = dgmdate($_stime, 'Ymd');
        if(!$daycache[$_time]) {
            preg_match('/^(\d{4})(\d{2})(\d{2})$/', $_time, $_matchs);
            $_year = $_matchs[1];
            $_month = $_matchs[1].$_matchs[2];
            if(!$years[$_year]) $years[$_year] = 1;
            if(!$months[$_month]) $months[$_month] = 1;
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $_time,
                'type' => $type,
                'value' => $_emptydatavalue
            ));
        }
        $_stime += 86400;
    }

    //// 更新月统计数据
    foreach ($months as $month => $v) {
        preg_match('/^(\d{4})(\d{2})$/', $month, $matchs);
        $time = mktime(0, 0, 0, $matchs[2], 1, $matchs[1]);
        $stime = dgmdate($time, 'Ymd');
        $etime = dgmdate(strtotime('+1 month', $time), 'Ymd');

        $emptydatac = $emptydata;
        $_list = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $stime, $etime);
        foreach ($_list as $_item) {
            $_extcredits = unserialize($_item['value']);
            foreach ($_extcredits as $_name => $_value) {
                $emptydatac[$_name] += $_value;
            }
        }

        $exist = C::t('#nayuan_report#nayuan_data_more') -> exist_by_type_time($type, $month);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_more') -> update_by_type_time($type, $month, serialize($emptydatac));
        }else{
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $month,
                'type' => $type,
                'value' => serialize($emptydatac)
            ));
        }
    }
    //// 更新年统计数据
    foreach ($years as $year => $v) {

        $emptydatac = $emptydata;
        $_list = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $year . '01', ($year + 1) . '01');
        foreach ($_list as $_item) {
            $_extcredits = unserialize($_item['value']);
            foreach ($_extcredits as $_name => $_value) {
                $emptydatac[$_name] += $_value;
            }
        }

        $exist = C::t('#nayuan_report#nayuan_data_more') -> exist_by_type_time($type, $year);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_more') -> update_by_type_time($type, $year, serialize($emptydatac));
        }else{
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $year,
                'type' => $type,
                'value' => serialize($emptydatac)
            ));
        }
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>