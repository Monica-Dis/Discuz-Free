<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_userbirthyear.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 1040;
$m = 'user';
$s = 'birthyear';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);
    $_today = dgmdate(time(), 'Ymd');
    if(!$_lastUpdateDay || $_lastUpdateDay < $_today) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_type = nayuan_get('s_type', 0, 0);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);
    if(!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = $s_etime;
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showtips($lang_nayuan_report['lang_tips']);
    showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
    echo "\n<input type=\"hidden\" id=\"search_form_type\" name=\"s_type\" value=\"$s_type\">";
    showtableheader('search');
    showtablerow('', array('width="50"', 'width="200"', 'width="170"', ''),
        array(
            lang('plugin/nayuan_report', 'type_day_title'),
            '<input type="text" class="txt" id="search_form_stime" name="s_stime" value="'.$s_stime.'" style="width: 80px; margin-right: 5px;">-<input type="text" class="txt" id="search_form_etime" name="s_etime" value="'.$s_etime.'" style="width: 80px; margin-left: 5px;">',
            '<a href="javascript:set_form_time(0);">'.$lang_nayuan_report['lang_today_title'].'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(1);">'.$lang_nayuan_report['lang_lately_30_days'].'</a>',
            "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"$lang[search]\" />"
        )
    );
    showtablerow('', array('colspan="5"'), array(lang('plugin/nayuan_report', 'format_day_tips')));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*dism _ taobao _com*/
    echo <<<SCRIPT
<script type="text/Javascript">
    function set_form_time(type) {
        document.getElementById('search_form_type').value = type;
        let today = new Date();
        if(type == 1) {
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
            today.setDate(today.getDate() - 29);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else{
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
            document.getElementById('search_form_stime').value = document.getElementById('search_form_etime').value;
        }
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
</script>
SCRIPT;

    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_userbirthyear_loaddata($type, $s_type, $lang_nayuan_report, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    if(count($_data) == 1) {
        $_chart_title = $lang_nayuan_report['lang_chart_pie_title'];
    }else{
        $_chart_title = $lang_nayuan_report['lang_chart_lie_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    }
    nayuanreport_userbirthyear_showchart($_chart_title, $_data, $lang_nayuan_report,'100%', '350px');
}else if($a == 'init') {

    $_today = dgmdate(time(), 'Ymd');
    $_data = C::t('#nayuan_report#nayuan_module_userbirthyear') -> count_all_by_birthyear();
    if(!$_data) {
        $_data = array();
    }
    $_value = array();
    foreach ($_data as $_item) {
        $_year = $_item['birthyear'];
        if($_year) {
            $_year = preg_replace('/^(\d{3})\d$/', '$1', $_year);
        }
        if($_value[$_year]) {
            $_value[$_year] += $_item['value'];
        }else{
            $_value[$_year] = $_item['value'];
        }

    }
    C::t('#nayuan_report#nayuan_data_more') -> insert(array(
        'time' => $_today,
        'type' => $type,
        'value' => serialize($_value)
    ));

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>