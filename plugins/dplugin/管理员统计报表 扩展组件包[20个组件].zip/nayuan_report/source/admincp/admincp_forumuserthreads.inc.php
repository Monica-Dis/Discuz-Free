<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_forumuserthreads.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 15:46:12.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 3080;
$m = 'forum';
$s = 'userthreads';

//// 搜索
$q_uid = nayuan_get('q_uid');
$q_fids = nayuan_get('q_fids', 3);
$q_stime = nayuan_get('q_stime', 1);
$q_etime = nayuan_get('q_etime', 1);
$q_top = max(1, nayuan_get('q_top', 0, '50'));
require_once libfile('function/forumlist');
$_forum_select_html = '<select name="q_fids[]" size="5" multiple="multiple">'.forumselect(FALSE, 0, 0, TRUE).'</select>';
foreach($q_fids as $v) {
    $_forum_select_html = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $_forum_select_html);
}

echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
showtableheader('search');
showtablerow('', array(
    'width="50"', 'width="70"', 'width="40"', 'width="120"', 'width="60"', 'width="300"', 'width="60"', 'width="150"', ''),
    array(
        $lang_nayuan_report['lang_forum'], $_forum_select_html,
        $lang_nayuan_report['lang_uid'], '<input type="number" class="txt" name="q_uid" value="' . $q_uid . '" />',
        $lang_nayuan_report['lang_thread_time'],
        '<input type="text" class="txt" onclick="showcalendar(event, this)" name="q_stime" value="'.$q_stime.'" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" onclick="showcalendar(event, this)" name="q_etime" value="'.$q_etime.'" style="width: 108px; margin-left: 5px;">',
        $lang_nayuan_report['lang_top_num'], '<input type="number" class="txt" name="q_top" value="' . $q_top . '" />',
        "<input class=\"btn\" type=\"submit\" id=\"searchformsubmit\" name=\"searchformsubmit\" value=\"$lang[search]\" />",
    )
);
showtablefooter(); /*dism·taobao·com*/
showformfooter(); /*dism _ taobao _com*/

$_top_list = C::t('#nayuan_report#nayuan_module_forumuserthreads')->fetch_list($q_fids, $q_uid, $q_stime, $q_etime, $q_top);
$_title = $lang_nayuan_report['lang_list_title'];
showtableheader($_title);
showsubtitle(array(
    $lang_nayuan_report['lang_user'],
    $lang_nayuan_report['lang_thread_num'],
), 'header', array(
    'class="td24 center"',
    'style="text-align: right"',
));

if ($_top_list) {
    foreach ($_top_list as $_item) {
        showtablerow(
            '',
            array(
                'class="td24 center"',
                'style="text-align: right"',
            ),
            array(
                "<a href=\"$_G[siteurl]home.php?mod=space&uid=$_item[uid]&do=profile\" target=\"_blank\">$_item[username]</a>",
                $_item['num'],
            )
        );
    }
} else {
    showtablerow('', array('colspan="15"'), array($lang_nayuan_report['lang_not_data']));
}

showtablefooter(); /*dism·taobao·com*/


?>