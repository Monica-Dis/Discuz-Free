<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_forumthread.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 3010;
$m = 'forum';
$s = 'thread';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_one') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay || $_lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_type = nayuan_get('s_type', 0, 1);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);
    nayuanreport_show_search_form($s_type, $s_stime, $s_etime, "$adminurl&m=$m&s=$s");
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_forumthread_loaddata($type, $s_type, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_forumthread_showchart($_chart_title, $_data, $lang_nayuan_report, '100%', '350px');
}else if($a == 'init') {

    $_etime = dmktime(dgmdate(time(), 'Y-m-d'));
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_one') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay) {
        $_stime = C::t('#nayuan_report#nayuan_module_forumthread') -> fetch_first_time();
        if(!$_stime) $_stime = time();
    }else{
        $_stime = dmktime(preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $_lastUpdateDay)) + 86400;
    }

    $daycache = $months = $years = array();
    $_data = C::t('#nayuan_report#nayuan_module_forumthread') -> count_all_by_stime_etime('%Y%m%d', $_stime, $_etime);
    foreach ($_data as $_item) {
        preg_match('/^(\d{4})(\d{2})(\d{2})$/', $_item['time'], $_matchs);
        $_year = $_matchs[1];
        $_month = $_matchs[1].$_matchs[2];
        if(!$years[$_year]) $years[$_year] = 1;
        if(!$months[$_month]) $months[$_month] = 1;
        C::t('#nayuan_report#nayuan_data_one') -> insert(array(
            'time' => $_item['time'],
            'type' => $type,
            'value' => $_item['value']
        ));
        $daycache[$_item['time']] = 1;
    }

    while($_stime < $_etime) {
        $_time = dgmdate($_stime, 'Ymd');
        if(!$daycache[$_time]) {
            preg_match('/^(\d{4})(\d{2})(\d{2})$/', $_time, $_matchs);
            $_year = $_matchs[1];
            $_month = $_matchs[1].$_matchs[2];
            if(!$years[$_year]) $years[$_year] = 1;
            if(!$months[$_month]) $months[$_month] = 1;
            C::t('#nayuan_report#nayuan_data_one') -> insert(array(
                'time' => $_time,
                'type' => $type,
                'value' => 0
            ));
        }
        $_stime += 86400;
    }

    //// 更新月统计数据
    foreach ($months as $month => $v) {
        preg_match('/^(\d{4})(\d{2})$/', $month, $matchs);
        $time = mktime(0, 0, 0, $matchs[2], 1, $matchs[1]);
        $stime = dgmdate($time, 'Ymd');
        $etime = dgmdate(strtotime('+1 month', $time), 'Ymd');
        $value = C::t('#nayuan_report#nayuan_data_one') -> sum_by_time($type, $stime, $etime);
        $exist = C::t('#nayuan_report#nayuan_data_one') -> fetch_by_type_time($type, $month);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_one') -> update_by_type_time($type, $month, $value);
        }else{
            C::t('#nayuan_report#nayuan_data_one') -> insert(array(
                'time' => $month,
                'type' => $type,
                'value' => $value
            ));
        }
    }
    //// 更新年统计数据
    foreach ($years as $year => $v) {
        $value = C::t('#nayuan_report#nayuan_data_one') -> sum_by_time($type, $year . '01', ($year + 1) . '01');
        $exist = C::t('#nayuan_report#nayuan_data_one') -> fetch_by_type_time($type, $year);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_one') -> update_by_type_time($type, $year, $value);
        }else{
            C::t('#nayuan_report#nayuan_data_one') -> insert(array(
                'time' => $year,
                'type' => $type,
                'value' => $value
            ));
        }
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>