<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_userregisterarea.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-07-23 11:26:02.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 1011;
$m = 'user';
$s = 'registerarea';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if(!file_exists(DISCUZ_ROOT . './data/ipdata/ip2region.db')) {
    cpmsg('nayuan_report:ip2regsion_error', 'action=index', 'error');
}

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);

    if(!$lastUpdateDay || $lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init&sdate=$lastUpdateDay", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_address = nayuan_get('s_address', 0, '');
    $s_type = nayuan_get('s_type', 0, 1);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);

    if(!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = dgmdate(strtotime('-30 day'), 'Y-m-d');
    }

    $districts = array();
    parse_str($lang_nayuan_report['lang_district'], $district_cache);
    foreach($district_cache as $value => $name) {
        if($s_address == $value) {
            $districts[] = "<option selected value=\"$value\">$name</option>";
        }else{
            $districts[] = "<option value=\"$value\">$name</option>";
        }
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showtips($lang_nayuan_report['lang_tips']);
    showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
    showtableheader('search');
    showtablerow('', array('width="50"', 'width="80"', 'width="80"', 'width="80"', 'width="255"', 'width="170"', ''),
        array(
            $lang_nayuan_report['lang_district_register'], '<select name="s_address"><option value="">'.cplang('all').'</option>' . implode('', $districts) . '</select>',
            lang('plugin/nayuan_report', 'type_title'), '<select id="search_form_type" name="s_type" onchange="search_type_change()">' . nayuan_show_options(lang('plugin/nayuan_report', 'type_options'), $s_type) . '</select>',
            '<input type="text" class="txt" id="search_form_stime" onclick="showcalendar(event, this)" name="s_stime" value="'.$s_stime.'" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" onclick="showcalendar(event, this)" id="search_form_etime" name="s_etime" value="'.$s_etime.'" style="width: 108px; margin-left: 5px;">',
            '<a href="javascript:set_form_time(1);">'.lang('plugin/nayuan_report', 'lately_30_days').'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(2);">'.lang('plugin/nayuan_report', 'lately_12_months').'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(3);">'.lang('plugin/nayuan_report', 'lately_6_year').'</a>',
            "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"".cplang('search')."\" />"
        )
    );
    showtablerow('', array('colspan="5"'), array(lang('plugin/nayuan_report', 'format_tips')));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*dism _ taobao _com*/
    echo <<<SCRIPT
<script type="text/Javascript">
    function search_type_change() {
        document.getElementById('search_form_stime').value = '';
        document.getElementById('search_form_etime').value = '';
    }
    
    function set_form_time(type) {
        document.getElementById('search_form_type').value = type;
        let today = new Date();
        if(type == 1) {
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
            today.setDate(today.getDate() - 29);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else if(type == 2) {
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
            today.setMonth(today.getMonth() - 11);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
        }else if(type == 3) {
            document.getElementById('search_form_etime').value = today.getFullYear();
            today.setFullYear(today.getFullYear() - 5);
            document.getElementById('search_form_stime').value = today.getFullYear();
        }
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
</script>
SCRIPT;
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_userregisterarea_loaddata($type, $s_type, $s_stime, $s_etime, $lang_nayuan_report);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    if($s_address) {
        nayuanreport_userregisterarea_showline($_chart_title, $s_address, $_data, $lang_nayuan_report, '100%', '350px');
    }else{
        nayuanreport_userregisterarea_showpie($_chart_title, $_data, $lang_nayuan_report, '100%', '350px');
    }

}else if($a == 'init') {

    $lastUpdateDay = nayuan_get('sdate'); //开始时间
    if(!$lastUpdateDay) {
        $firstUserRegDate = C::t('#nayuan_report#nayuan_module_userregisterarea') -> fetch_first_user_regdate();
        if(!$firstUserRegDate) $firstUserRegDate = time();
        $lastUpdateDay = dgmdate($firstUserRegDate - 86400, 'Ymd');
    }

    $_yestoday = dgmdate(time() - 86400, 'Ymd'); //结束时间
    preg_match('/^(\d{4})(\d{2})(\d{2})$/', $lastUpdateDay, $matchs);
    $starttime = mktime(0, 0, 0, $matchs[2], $matchs[3], $matchs[1]);
    $months = $years = array();
    //// 更新日统计数据
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/class/ip2region.class.php';
    $ip2region = new ip2region();

    parse_str($lang_nayuan_report['lang_district_short'], $district_cache);

    while($lastUpdateDay < $_yestoday) {
        $starttime += 86400;
        $lastUpdateDay = dgmdate($starttime, 'Ymd');
        preg_match('/^(\d{4})(\d{2})(\d{2})$/', $lastUpdateDay, $matchs);
        $month = $matchs[1].$matchs[2];
        if(!$months[$month]) $months[$month] = 1;
        $year = $matchs[1];
        if(!$years[$year]) $years[$year] = 1;
        $endtime = $starttime + 86400;

        $data = array();
        $list = C::t('#nayuan_report#nayuan_module_userregisterarea') -> fetch_user_by_regdate($starttime, $endtime);
        foreach ($list as $user) {
            $area = $ip2region->memorySearch($user['regip']);
            $area = explode('|', $area['region']);
            $area = mb_substr($area[2], 0, 2);
            $areav = $district_cache[$area];
            if(!$areav) {
                if($area === '0') {
                    $areav = '36';
                }else{
                    $areav = '35';
                }
            }

            if(!$data[$areav]) {
                $data[$areav] = 0;
            }
            $data[$areav]++;
        }
        C::t('#nayuan_report#nayuan_data_more') -> insert(array(
            'time' => $lastUpdateDay,
            'type' => $type,
            'value' => serialize($data)
        ));
    }

    //// 更新月统计数据
    foreach ($months as $month => $v) {
        preg_match('/^(\d{4})(\d{2})$/', $month, $matchs);
        $time = mktime(0, 0, 0, $matchs[2], 1, $matchs[1]);
        $stime = dgmdate($time, 'Ymd');
        $etime = dgmdate(strtotime('+1 month', $time), 'Ymd');
        $list = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $stime, $etime);
        $data = array();
        foreach ($list as $item) {
            $values = unserialize($item['value']);
            foreach ($values as $c => $n) {
                if(!$data[$c]) {
                    $data[$c] = $n;
                }else{
                    $data[$c] += $n;
                }
            }
        }

        $exist = C::t('#nayuan_report#nayuan_data_more') -> exist_by_type_time($type, $month);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_more') -> update_by_type_time($type, $month, serialize($data));
        }else{
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $month,
                'type' => $type,
                'value' => serialize($data)
            ));
        }
    }
    //// 更新年统计数据
    foreach ($years as $year => $v) {
        $data = array();
        $list = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $year . '01', ($year + 1) . '01');
        foreach ($list as $item) {
            $values = unserialize($item['value']);
            foreach ($values as $c => $n) {
                if(!$data[$c]) {
                    $data[$c] = $n;
                }else{
                    $data[$c] += $n;
                }
            }
        }

        $exist = C::t('#nayuan_report#nayuan_data_more') -> exist_by_type_time($type, $year);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_more') -> update_by_type_time($type, $year, serialize($data));
        }else{
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $year,
                'type' => $type,
                'value' => serialize($data)
            ));
        }
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>