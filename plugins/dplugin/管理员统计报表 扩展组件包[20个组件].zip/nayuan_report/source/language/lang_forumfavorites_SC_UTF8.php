<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_forumfavorites.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '论坛数据',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'favorites',
        'title' => '板块收藏趋势',
        'order' => 3030
    ),

    'lang_export' => '导出当前查询结果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',
    'lang_lately_12_month' => '最近12个月',

    'lang_search_time' => '日期区间',
    'lang_search_forms' => '展示版块',
    'lang_format_tips' => '',

    'lang_chart_title' => '版块日收藏趋势图',
    'lang_tips' => '<li>版块每日收藏用户数量的一个趋势图</li><li>按日期查询格式举例，按日:2020-05-20, 按月:2020-05</li>',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '收藏用户数量',

    'lang_table_title' => '版块当前时间段总新增收藏量排行',
    'lang_table_header_nums' => '新增收藏数量',
    'lang_table_header_fid' => '版块ID',
    'lang_table_header_forum' => '版块名称',


);

?>
