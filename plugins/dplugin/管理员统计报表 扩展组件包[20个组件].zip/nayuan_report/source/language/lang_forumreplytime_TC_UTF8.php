<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_forumreplytime.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '論壇數據',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'replytime',
        'title' => '平均回帖時間',
        'order' => 3020
    ),

    'lang_export' => '導出當前查詢結果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',

    'lang_search_forum' => '按板塊展示',
    'lang_search_time' => '日期區間',
    'lang_format_tips' => '按日查詢格式舉例：2020-05-20',

    'lang_chart_title' => '日平均回貼間隔趨勢圖',
    'lang_tips' => '<li>注意：假如5號發的一個貼子A，10號才有回貼，則10號之前貼子A不參與平均計算，10號才會參與平均值的計算</li>',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '平均間隔時間(小時)',

    'lang_day_average_time' => '日平均回貼間隔'


);

?>
