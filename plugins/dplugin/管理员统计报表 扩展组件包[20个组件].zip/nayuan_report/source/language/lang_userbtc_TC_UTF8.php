<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_userbtc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-07-05 08:21:25.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用戶數據',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'btc',
        'title' => '用戶購買主題量',
        'order' => 1100
    ),

    'lang_header_user' => '用戶名',
    'lang_header_nums' => '購買主題數',

    'lang_tips' => '<li>查詢某一時間範圍內，用戶購買主題數量排行榜</li>',
    'lang_search_time' => '日期區間',
    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',

    'lang_export' => '導出數據',

    'lang_table_title' => '用戶購買主題數量TOP{nums}',



);

?>
