<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_forumforumthreads.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '論壇數據',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'forumthreads',
        'title' => '版塊日發帖量趨勢',
        'order' => 3040
    ),

    'lang_export' => '導出當前查詢結果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',
    'lang_lately_12_month' => '最近12個月',

    'lang_search_time' => '日期區間',
    'lang_search_forms' => '展示版塊',
    'lang_format_tips' => '',

    'lang_chart_title' => '版塊日發帖量趨勢圖',
    'lang_tips' => '<li>版塊每日發帖數量趨勢圖</li><li>按日期查詢格式舉例，按日:2020-05-20, 按月:2020-05</li>',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '發帖數量',

    'lang_table_title' => '版塊當前時間段總發帖數量排行',
    'lang_table_header_nums' => '新增發帖量',
    'lang_table_header_fid' => '版塊ID',
    'lang_table_header_forum' => '版塊名稱',


);

?>
