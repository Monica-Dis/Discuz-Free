<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_forumthread.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '论坛数据',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'thread',
        'title' => '发贴数量统计',
        'order' => 3010
    ),

    'lang_chart_title' => '发帖数量趋势',
    'lang_tips' => '<li>数据有延迟, 今日变更的数据，明日才会更新到</li><li>查看一次才会记录一次当天的数据</li>',
    'lang_xaxis_name' => '时间',
    'lang_yaxis_name' => '贴子数',


);

?>
