<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_creditdays.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-09-07 22:07:16.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'credit',
        'title' => '積分數據',
        'order' => 5000,
    ),
    'menu' => array(
        'name' => 'days',
        'title' => '積分增長趨勢',
        'order' => 5020
    ),

    'lang_chart_title' => '積分增長趨勢',
    'lang_xaxis_name' => '時間',
    'lang_yaxis_name' => '積分',
    'lang_up' => '增',
    'lang_down' => '減',
    'lang_no_data' => '沒有找到數據',
    'lang_export' => '導出當前查詢結果',

    'lang_sum_list_title' => '{stime} - {etime} 按類型彙總列表',
    'lang_sum_plus' => '增加積分項目',
    'lang_sum_sub' => '減少積分項目',
    'lang_user_list_title' => '積分變更明細',


);

?>
