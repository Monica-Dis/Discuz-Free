<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_forumforumuv.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-07-06 11:03:15.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '論壇數據',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'forumuv',
        'title' => '板塊訪問用戶量趨勢',
        'order' => 3050
    ),
    'hooks' => array(
        'forumdisplay_forumdisplay' => 'forumforumuv',
        'viewthread_viewthread' => 'forumforumuv'
    ),

    'lang_export' => '導出當前查詢結果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',
    'lang_lately_12_month' => '最近12個月',

    'lang_search_time' => '日期區間',
    'lang_search_forms' => '展示版塊',

    'lang_chart_title' => '版塊日訪問用戶量趨勢圖',
    'lang_tips' => '<li>版塊每日訪問用戶數量趨勢圖，重複訪問只計1</li><li>按日期查詢格式舉例，按日:2020-05-20, 按月:2020-05</li>',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '用戶數',

    'lang_table_title' => '版塊當前時間段-總訪問用戶量排行',
    'lang_table_header_nums' => '用戶訪問量',
    'lang_table_header_fid' => '版塊ID',
    'lang_table_header_forum' => '版塊名稱',


);

?>
