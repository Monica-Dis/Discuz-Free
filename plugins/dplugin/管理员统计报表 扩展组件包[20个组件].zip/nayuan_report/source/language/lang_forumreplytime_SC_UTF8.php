<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_forumreplytime.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '论坛数据',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'replytime',
        'title' => '平均回帖时间',
        'order' => 3020
    ),

    'lang_export' => '导出当前查询结果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',

    'lang_search_forum' => '按板块展示',
    'lang_search_time' => '日期区间',
    'lang_format_tips' => '按日查询格式举例：2020-05-20',

    'lang_chart_title' => '日平均回贴间隔趋势图',
    'lang_tips' => '<li>注意：假如5号发的一个贴子A，10号才有回贴，则10号之前贴子A不参与平均计算，10号才会参与平均值的计算</li>',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '平均间隔时间(小时)',

    'lang_day_average_time' => '日平均回贴间隔'


);

?>
