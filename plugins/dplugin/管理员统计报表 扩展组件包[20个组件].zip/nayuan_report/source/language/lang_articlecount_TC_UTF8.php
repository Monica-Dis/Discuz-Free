<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_articlecount.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2021-03-08 11:58:15.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'article',
        'title' => '門戶文章',
        'order' => 4000,
    ),
    'menu' => array(
        'name' => 'count',
        'title' => '欄目數據彙總',
        'order' => 4010
    ),

    'lang_header_cat' => '欄目名稱',
    'lang_header_viewnum' => '瀏覽量',
    'lang_header_commentnum' => '評論量',
    'lang_header_favtimes' => '收藏量',
    'lang_header_sharetimes' => '分享量',

    'lang_list_title' => '按欄目數據彙總',

    'lang_tips' => '<li>按文章欄目統計當前欄目下的回帖量,分享量,瀏覽量等數據</li>',
    'lang_export' => '導出數據',

    'lang_no_data' => '沒有找到任何數據'




);

?>
