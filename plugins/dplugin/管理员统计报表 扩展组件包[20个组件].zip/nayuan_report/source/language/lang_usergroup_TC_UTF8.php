<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_usergroup.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用戶數據',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'group',
        'title' => '用戶組人數統計',
        'order' => 1020
    ),

    'lang_today_title' => '目前分佈情況',
    'lang_lately_30_days' => '近30天變化趨勢',
    'lang_chart_pie_title' => '用戶組人數分佈',
    'lang_chart_lie_title' => '用戶組人數變化趨勢',
    'lang_xaxis_name' => '組名',
    'lang_yaxis_name' => '人數',
    'lang_system_group' => '系統用戶組',
    'lang_member_group' => '會員用戶組',
    'lang_special_group' => '自定義用戶組',
    'lang_tips' => '<li>數據有延遲, 今日變更的數據，明日才會更新到</li><li>查看一次才會記錄一次當天的數據</li>',
    'lang_more_days_error' => '當前時間段只有少於2天的數據記錄，不支持查看趨勢圖',
);

?>
