<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_userregister.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用户数据',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'register',
        'title' => '用户注册趋势',
        'order' => 1010
    ),

    'lang_chart_title' => '用户注册趋势图',
    'lang_xaxis_name' => '日期',
    'lang_yaxis_name' => '注册人数',
);

?>
