<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_forumuserthreads.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 15:46:12.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '論壇數據',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'userthreads',
        'title' => '用戶發貼量排行',
        'order' => 3080
    ),

    "lang_top_num" => '顯示多少條',
    "lang_uid" => '用戶ID',
    "lang_forum" => '版塊',
    "lang_list_title" => '用戶發貼數量排行',
    "lang_thread_time" => '發貼時間',
    "lang_user" => '用戶',
    "lang_thread_num" => '發貼數量',
    "lang_not_data" => '未找到任何數據',


);

?>
