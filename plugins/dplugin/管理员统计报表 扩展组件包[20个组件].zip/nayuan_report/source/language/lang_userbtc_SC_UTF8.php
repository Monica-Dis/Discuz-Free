<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_userbtc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-07-05 08:21:25.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用户数据',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'btc',
        'title' => '用户购买主题量',
        'order' => 1100
    ),

    'lang_header_user' => '用户名',
    'lang_header_nums' => '购买主题数',

    'lang_tips' => '<li>查询某一时间范围内，用户购买主题数量排行榜</li>',
    'lang_search_time' => '日期区间',
    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',

    'lang_export' => '导出数据',

    'lang_table_title' => '用户购买主题数量TOP{nums}',



);

?>
