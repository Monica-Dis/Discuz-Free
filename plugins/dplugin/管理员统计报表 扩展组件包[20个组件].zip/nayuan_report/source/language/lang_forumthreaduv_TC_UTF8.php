<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_report.
 *      lang_forumthreaduv.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '論壇數據',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'threaduv',
        'title' => '帖子訪問用戶數量排行',
        'order' => 3060
    ),
    'hooks' => array(
        'viewthread_viewthread' => 'forumthreaduv'
    ),

    'lang_export' => '導出當前查詢結果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',

    'lang_search_time' => '日期區間',

    'lang_table_title' => '帖子新增用戶訪問量TOP{nums}',
    'lang_table_header_tid' => '帖子ID',
    'lang_table_header_subject' => '帖子名稱',
    'lang_table_header_favorites' => '新增用戶訪問量',
    'lang_table_header_fid' => '版塊ID',
    'lang_table_header_forum' => '版塊名稱',

    'lang_not_data' => '當前時間段沒有帖子被訪問哦',

    'lang_tips' => '<li>查詢某一時間段內，帖子訪問用戶數量TOP{nums}條數據，每日同一用戶重複訪問同一帖子，只計1次</li><li>日期格式：2020-05-20</li>'


);

?>
