<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      hook_nayuanreport_forumthreadarea.inc.php.
 *      ���²����http://t.cn/Aiux1Jx1
 *      Time 2020-07-23 11:26:02.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;

$_uid = $_G['uid'];
$_clientip = $_G['clientip'];

if(!$_uid) return;

$_date = dgmdate(time(), 'Y-m-d');
$_type = 3070001;

$_id = md5($_type . $_date . $_uid);
$_exist = C::t('#nayuan_report#nayuan_data_cache') -> exist_by_cid($_id);
if($_exist) return;

C::t('#nayuan_report#nayuan_data_cache') -> insert(array(
    'cid' => $_id,
    'type' => $_type,
    'id'    => sprintf("%u", ip2long($_clientip)),
    'value' => 1,
    'time' => time()
));

?>