<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      admin_logs.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/core.func.php';

$adminurl = 'plugins&operation=config&do=' .$do . '&pmod=admin_logs';

loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];
//// 搜索
$q_page = nayuan_get('page', 0, 1);
$q_page = $q_page < 1 ? 1 : $q_page;
$q_pagesize = nayuan_get('pagesize', 0, 20);
$q_uid = nayuan_get('q_uid');
$q_username = nayuan_get('q_username', 1, '');
$q_ip = nayuan_get('q_ip', 1, '');
$q_third = nayuan_get('q_third', 1, '');

$thirdoptions = array();
foreach ($options['thirds'] as $name => $third) {
    $thirdoptions[] = '<option value="'.$name.'" '.($name == $q_third ? 'selected' : '').' >'.$third['title'].'</option>';
    unset($name, $third);
}

showformheader("$adminurl", '', 'search_form');
echo '<input type="hidden" name="page" id="page" value="1">';
echo <<<SCRIPT
<script type="text/javascript">
    function nayuan_next_page(page) {
        $("page").value=page;
        $("search_form").submit();
    }
</script>
SCRIPT;
showtableheader('search');
$_pagesizeoptions = array();
$_pagesizeoptions[] = '<option value="20" '.($q_pagesize == 20 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_admin_login', 'search_pagesize', array('num' => 20)).'</option>';
$_pagesizeoptions[] = '<option value="50" '.($q_pagesize == 50 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_admin_login', 'search_pagesize', array('num' => 50)).'</option>';
$_pagesizeoptions[] = '<option value="100" '.($q_pagesize == 100 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_admin_login', 'search_pagesize', array('num' => 100)).'</option>';
$_pagesizeoptions[] = '<option value="500" '.($q_pagesize == 500 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_admin_login', 'search_pagesize', array('num' => 500)).'</option>';
showtablerow('', array(
    'width="50"', 'width="70"','width="40"', 'width="120"','width="40"', 'width="150"','width="50"', 'width="70"','width="70"', '', 'style="text-align:right"'),
    array(
        lang('plugin/nayuan_admin_login', 'logs_list_header_third'), '<select name="q_third"><option value="">'.cplang('all').'</option>'.implode('', $thirdoptions).'</select>',
        lang('plugin/nayuan_admin_login', 'search_uid'), '<input type="number" class="txt" name="q_uid" value="'.$q_uid.'" />',
        lang('plugin/nayuan_admin_login', 'search_user'), '<input type="text" class="txt" name="q_username" value="'.dhtmlspecialchars($q_username).'" />',
        lang('plugin/nayuan_admin_login', 'search_ip'), '<input type="text" class="txt" name="q_ip" style="width: 180px;" value="'.dhtmlspecialchars($q_ip).'" />',
        '<select name="pagesize">'.implode('', $_pagesizeoptions).'</select>',
        "<input class=\"btn\" type=\"submit\" id=\"searchformsubmit\" name=\"searchformsubmit\" value=\"$lang[search]\" />",
    )
);
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/

$_result = C::t('#nayuan_admin_login#nayuan_admin_logs') -> fetch_list($q_third, $q_uid, $q_username, $q_ip, $q_page, $q_pagesize);
$_title = lang('plugin/nayuan_admin_login', 'logs_list_title').'&nbsp;('.$_result['total'].')';
showtableheader($_title);
showsubtitle(array(
    lang('plugin/nayuan_admin_login', 'logs_list_header_third'),
    lang('plugin/nayuan_admin_login', 'logs_list_header_user'),
    lang('plugin/nayuan_admin_login', 'logs_list_header_time'),
    lang('plugin/nayuan_admin_login', 'logs_list_header_ip'),
    lang('plugin/nayuan_admin_login', 'logs_list_header_port'),
    lang('plugin/nayuan_admin_login', 'logs_list_header_area'),
), 'header', array(
    'class="td24 center"',
    'class="td23 center"',
    'class="center" style="width: 150px"',
    'class="td25" style="text-align:right"',
    'class="td25" style="text-align:left"',
    '',
));

if($_result['total']) {
    require_once libfile('function/misc');
    foreach ($_result['list'] as $_item) {
        showtablerow(
            '',
            array(
                'class="td24 center"',
                'class="td23 center"',
                'class="center" style="width: 150px"',
                'class="td25" style="text-align:right"',
                'class="td25" style="text-align:left"',
                '',
            ),
            array(
                $options['thirds'][$_item['third']]['title'],
                "<a href=\"$_G[siteurl]home.php?mod=space&uid=$_item[uid]&do=profile\" target=\"_blank\">$_item[username]</a>",
                dgmdate($_item['time'], 'Y-m-d H:i:s'),
                $_item['clientip'],
                $_item['clientport'],
                $_item['area'],
            )
        );
    }
    $v_page_html = multi($_result['total'], $q_pagesize, $q_page, 'nayuan_next_page({page})', 0, $q_pagesize, false, false, ';');
    showsubmit('', '', '', '', $v_page_html);
}else{
    showtablerow('', array('colspan="15"'), array(lang('plugin/nayuan_admin_login', 'not_data')));
}

showtablefooter(); /*Dism·taobao·com*/

?>