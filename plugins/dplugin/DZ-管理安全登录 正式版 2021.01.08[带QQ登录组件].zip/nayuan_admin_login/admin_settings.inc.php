<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      admin_settings.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/core.func.php';

$adminurl = 'plugins&operation=config&do=' .$do . '&pmod=admin_settings';

loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];

if(submitcheck('savesubmit')) {

    $setting = nayuan_get('setting', 3);
    $thirds = nayuan_get('thirds', 3);
    $isexistenablethird = false;
    if($thirds) {
        foreach ($thirds as $name => $third) {
            if(!$third['enable']) continue;
            $isexistenablethird = true;
            foreach ($third as $k => $v) {
                if(!$v) {
                    cpmsg('nayuan_admin_login:error_third_empty_input', '', 'error', array('title' => $third['title']));
                }
            }
        }
    }

    if($setting['open']) {
        if(!$isexistenablethird) {
            cpmsg('nayuan_admin_login:error_third_all_disabled', '', 'error');
        }

        // 需要判断是否已绑定账号
        $types = array();
        foreach ($options['thirds'] as $name => $third) {
            if(!$third['enable']) continue;
            $types[] = $name;
        }
        $uids = explode(',', str_replace(' ', '', $_G['config']['admincp']['founder']));
        $existbinduser = C::t('#nayuan_admin_login#nayuan_admin_login') -> exist_bind_user($types, $uids);
        if(!$existbinduser) {
            cpmsg('nayuan_admin_login:error_not_bind', '', 'error');
        }

        $admincontent = @file_get_contents(DISCUZ_ROOT . ADMINSCRIPT);
        $admincontent = str_replace('discuz_admincp', 'discuz_nayuan_admincp', $admincontent);
        $replaceto = "source/function/function_cache.php';\nrequire './source/plugin/nayuan_admin_login/source/class/discuz/discuz_nayuan_admincp.php';";
        $admincontent = str_replace('source/function/function_cache.php\';', $replaceto, $admincontent);
        if(strpos($admincontent, 'discuz_nayuan_admincp') === false) {
            cpmsg('nayuan_admin_login:error_admin_replace_fail', '', 'error', array('admin' => ADMINSCRIPT));
        }
        if(!@file_put_contents(DISCUZ_ROOT . ADMINSCRIPT . '.tmp', $admincontent)) {
            cpmsg('nayuan_admin_login:error_admin_tmp_fail', '', 'error', array('admin' => ADMINSCRIPT . '.tmp'));
        }

        if(!@rename(DISCUZ_ROOT . ADMINSCRIPT, DISCUZ_ROOT . ADMINSCRIPT . '.don-t.delete.me.dplugin')) {
            cpmsg('nayuan_admin_login:error_admin_auth', '', array('admin' => ADMINSCRIPT));
        }
        if(!@rename(DISCUZ_ROOT . ADMINSCRIPT . '.tmp', DISCUZ_ROOT . ADMINSCRIPT)) {
            cpmsg('nayuan_admin_login:error_admin_auth', '', array('admin' => ADMINSCRIPT));
        }
    }else if($options['setting']['open']){
        @unlink(DISCUZ_ROOT . ADMINSCRIPT);
        if(!@rename(DISCUZ_ROOT . ADMINSCRIPT . '.don-t.delete.me.dplugin', DISCUZ_ROOT . ADMINSCRIPT)) {
            cpmsg('nayuan_admin_login:error_admin_restore', '', array('admin' => ADMINSCRIPT, 'adminbk' => ADMINSCRIPT . '.don-t.delete.me.dplugin'));
        }
    }

    $options['setting'] = $setting;
    $options['thirds'] = $thirds;
    $options['exist_enable_third'] = $isexistenablethird;
    if($options['adminscript'] !== ADMINSCRIPT) {
        //// admin文件名被修改之后，及时更新
        $options['adminscript'] = ADMINSCRIPT;
        savecache('nayuan_admin_login', $options);
    }
    savecache('nayuan_admin_login', $options);

    cpmsg(lang('plugin/nayuan_admin_login', 'save_success'), 'action='.$adminurl, 'succeed');

} else {

    showformheader($adminurl);
    /////////////// 通用配置
    showtableheader(lang('plugin/nayuan_admin_login', 'setting_common'));
    showsetting(lang('plugin/nayuan_admin_login', 'setting_open'), 'setting[open]', $options['setting']['open'], 'radio', '', 0, lang('plugin/nayuan_admin_login', 'setting_open_tips'));
    showsetting(lang('plugin/nayuan_admin_login', 'setting_model'), 'setting[model]', $options['setting']['model'], 'radio', '', 0, lang('plugin/nayuan_admin_login', 'setting_model_tips'));
    showtablefooter(); /*Dism·taobao·com*/
    /////////////// 第三方登录配置
    showtableheader(lang('plugin/nayuan_admin_login', 'setting_third'));
    showsubtitle(array(
        lang('plugin/nayuan_admin_login', 'setting_third_enable'),
        lang('plugin/nayuan_admin_login', 'setting_third_name'),
        lang('plugin/nayuan_admin_login', 'setting_third_input'),
    ), 'header', array(
        'class="td25"',
        '',
        ''
    ));
    $dir = DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/class/third';
    $_dir_list = @opendir($dir);
    while($file = @readdir($_dir_list)) {
        if($file == '.' || $file == '..') continue;
        if(!preg_match('/^(\w+)\.class\.php$/i', $file, $matches)) continue;

        $thirdname = $matches[1];
        include DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/language/third/lang_third_' . $thirdname . '_' . currentlang() . '.php';

        $inputs = [];
        foreach ($lang_nayuan_third['inputs'] as $input) {
            $inputs[] = $input['title'] . ':&nbsp;<input type="text" name="thirds['.$thirdname.']['.$input['name'].']" value="'.$options['thirds'][$thirdname][$input['name']].'" />';
            unset($input);
        }

        showtablerow(
            '',
            array(
                'class="td25"',
                '',
                ''
            ),
            array(
                '<input class="checkbox" '.($options['thirds'][$thirdname]['enable'] ? 'checked' : '').' type="checkbox" name="thirds['.$thirdname.'][enable]" value="1"><input type="hidden" name="thirds['.$thirdname.'][title]" value="'.dhtmlspecialchars($lang_nayuan_third['title']).'" />',
                '<a href="'.$lang_nayuan_third['url'].'" target="_blank">'.$lang_nayuan_third['title'].'</a>',
                implode('&nbsp;&nbsp;&nbsp;', $inputs)
            )
        );
        showtablerow('', array('', 'colspan="2"'), array('', $lang_nayuan_third['desc']));

        unset($lang_nayuan_third, $thirdname, $inputs);
    }
    @closedir($_dir_list);
    showtablerow('', array('colspan="15"'), array(lang('plugin/nayuan_admin_login', 'setting_third_tips')));
    showtablefooter(); /*Dism·taobao·com*/

    ///////////////////// 提交
    showtableheader();
    showsubmit('savesubmit');
    showtablefooter(); /*Dism·taobao·com*/
    showformfooter(); /*Dism_taobao_com*/

}
//From: d'.'is'.'m.ta'.'obao.com
?>