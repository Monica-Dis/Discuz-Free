<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      dpluginqq.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/core.func.php';

$third = 'dpluginqq';
$mma = nayuan_get('mma', 1);
if(!in_array($mma, array('qrcode', 'status', 'bind', 'login'))) {
    exit('Access Denied');
}

loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];

if($mma === 'qrcode') { //// 获取登录二维码
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/class/third/' . $third . '.class.php';
    $thirdclass = 'third_login_' . $third;
    $thirdclass = new $thirdclass($options['thirds'][$third]);

    $uuid = md5(random(32));
    $result = $thirdclass -> qrcode($uuid, 0, array(
        'model' => $options['setting']['model'] ? 2 : 1
    ));
    if($result['code'] === '200') {
        $result = array(
            'code'  => '200',
            'url' => $result['object']['url'],
        );
    }else{
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }

    dheader('Content-Type:application/json');
    exit(json_encode($result));
}else if($mma === 'status') { //查询登录状态
    $ssid = nayuan_get('ssid', 1);
    $cache = C::t('#nayuan_admin_login#nayuan_admin_cache') -> fetch_cache_data($ssid);

    if($options['setting']['model'] && $cache && $cache['token']) {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/dpluginapi.func.php';
        $result = get_proxy_login_status($options['thirds'][$third], array('token' => $cache['token']));
        if($result['code'] === '200') {
            validate_callback_data($options['thirds'][$third], $ssid, $result['object']['openid'], $result['object']['timestamp'], $result['object']['sign'], $result['object']['nickname']);
        }
    }

    if(!$cache) {
        $result = array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_login_expire'));
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }else if(intval($cache['status']) == 0) {
        $result = array('code' => '201');
    }else if(intval($cache['status']) == 1) {
        $result = check_user_login($cache['uid']);
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> delete($ssid);
    }else{
        $result = array('code' => '500', 'message' => $cache['message']);
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }

    dheader('Content-Type:application/json');
    exit(json_encode($result));
}else if($mma === 'login') { //登录回调
    $ssid = nayuan_get('ssid', 1);
    $openid = nayuan_get('openid', 1);
    $timestamp = nayuan_get('timestamp');
    $sign = nayuan_get('sign', 1);
    if($sign) {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/dpluginapi.func.php';
        validate_callback_data($options['thirds'][$third], $ssid, $openid, $timestamp, $sign);
        exit();
    }else{
        $adminpage = $_G['siteurl'] . $options['adminscript'];
        define('IN_MOBILE', 2);
        include template('nayuan_admin_login:dpluginqq');
        exit;
    }
}else if($mma === 'bind') { //绑定回调
    $ssid = nayuan_get('ssid', 1);
    $nickname = nayuan_get('nickname', 1);
    $openid = nayuan_get('openid', 1);
    $timestamp = nayuan_get('timestamp');
    $sign = nayuan_get('sign', 1);
    if($sign) {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/dpluginapi.func.php';
        validate_callback_data($options['thirds'][$third], $ssid, $openid, $timestamp, $sign, $nickname);
        exit();
    }else{
        define('IN_MOBILE', 2);
        include template('nayuan_admin_login:dplugin_bind_success');
        exit;
    }
}

function checkfounder($user) {
    global $_G;
    $founders = str_replace(' ', '', $_G['config']['admincp']['founder']);
    if(!$user['uid'] || $user['groupid'] != 1 || $user['adminid'] != 1) {
        return false;
    } elseif(empty($founders)) {
        return true;
    } elseif(strexists(",$founders,", ",$user[uid],")) {
        return true;
    } elseif(!is_numeric($user['username']) && strexists(",$founders,", ",$user[username],")) {
        return true;
    } else {
        return FALSE;
    }
}

function check_user_login($uid) {
    global $_G;
    require_once libfile('function/member');
    //clearcookies();
    $member = getuserbyuid($uid, 1);
    $cpgroupid = C::t('common_admincp_member')->fetch($uid);
    $cpgroupid = $cpgroupid['uid'];
    if($cpgroupid || checkfounder($member)) {
        C::t('common_admincp_session')->insert(array(
            'uid' => $uid,
            'adminid' => $member['adminid'],
            'panel' => 1,
            'dateline' => TIMESTAMP,
            'ip' => $_G['clientip'],
            'errorcount' => -1
        ), false, true);

        require_once libfile('function/misc');
        C::t('#nayuan_admin_login#nayuan_admin_logs') -> insert(array(
            'uid' => $uid,
            'third' => 'dpluginqq',
            'clientip' => $_G['clientip'],
            'clientport' => $_G['remoteport'],
            'area' => convertip($_G['clientip']),
            'http_referer' => $_SERVER['HTTP_REFERER'],
            'http_user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'http_x_forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'],
            'device' => checkmobile(),
            'time' => time(),
        ));

        setloginstatus($member, 0);
        return array('code' => '200');
    } else {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_user_not_found'));
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>