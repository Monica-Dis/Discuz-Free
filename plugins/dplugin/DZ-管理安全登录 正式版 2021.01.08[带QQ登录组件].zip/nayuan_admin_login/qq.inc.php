<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      qq.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-25 21:25:04.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/core.func.php';

$third = 'qq';
$mma = nayuan_get('mma', 1);
if(!in_array($mma, array('qrcode', 'bind', 'status', 'login'))) {
    exit('Access Denied');
}

loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];

if($mma === 'qrcode') { //// 获取登录二维码
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/class/third/' . $third . '.class.php';
    $thirdclass = 'third_login_' . $third;
    $thirdclass = new $thirdclass($options['thirds'][$third]);

    $uuid = md5(random(32));
    $result = $thirdclass -> qrcode($uuid, 0);
    if($result['code'] === '200') {
        $result = array(
            'code'  => '200',
            'url' => $result['object']['url'],
        );
    }else{
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }

    dheader('Content-Type:application/json');
    exit(json_encode($result));
}else if($mma === 'status') { //查询登录状态
    $ssid = nayuan_get('ssid', 1);
    $cache = C::t('#nayuan_admin_login#nayuan_admin_cache') -> fetch_cache_data($ssid);
    if(!$cache) {
        $result = array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_login_expire'));
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }else if(intval($cache['status']) == 0) {
        $result = array('code' => '201');
    }else if(intval($cache['status']) == 1) {
        $result = check_user_login($cache['uid']);
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> delete($ssid);
    }else{
        $result = array('code' => '500', 'message' => $cache['message']);
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }
    dheader('Content-Type:application/json');
    exit(json_encode($result));
}else if($mma === 'login') { //登录回调
    $code = nayuan_get('code', 1);
    $state = nayuan_get('state', 1);

    if(!$code || !$state) {
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($state, array(
            'status' => 2,
            'message' => lang('plugin/nayuan_admin_login', 'error_bind_params')
        ));
        $error_message = lang('plugin/nayuan_admin_login', 'error_bind_params');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    $logincache = C::t('#nayuan_admin_login#nayuan_admin_cache') -> fetch_cache_data($state);
    if(!$logincache || intval($logincache['status']) !== 0) {
        $error_message = lang('plugin/nayuan_admin_login', 'error_login_expire');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    $thirdoptions = $options['thirds'][$logincache['third']];
    if(!$thirdoptions) {
        $error_message = lang('plugin/nayuan_admin_login', 'error_login_invalid_third');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/qqapi.func.php';

    $callback = $_G['siteurl'] . 'plugin.php?id=nayuan_admin_login:qq&ssid=' . $state . '&mma=bind';
    $result = get_qq_token($thirdoptions, $code, $callback);
    if(!$result['access_token']) {
        $error_message = lang('plugin/nayuan_admin_login', 'error_login_fail');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    $openiddata = get_qq_openid($result['access_token']);
    if(!$openiddata['openid']) {
        $error_message = lang('plugin/nayuan_admin_login', 'error_login_fail');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    $openid = md5('qq-' . $thirdoptions['app_id'] . $openiddata['openid']);
    $member = C::t('#nayuan_admin_login#nayuan_admin_login') -> fetch($openid);
    if(!$member) {
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($state, array(
            'status' => 2,
            'message' => lang('plugin/nayuan_admin_login', 'error_user_not_found')
        ));
        $error_message = lang('plugin/nayuan_admin_login', 'error_user_not_found');
        include template('nayuan_admin_login:qq_login_error');
        exit();
    }

    C::t('#nayuan_admin_login#nayuan_admin_cache') -> delete($state);
    $result = check_user_login($member['uid']);
    if($result['code'] === '200') {
        dheader("Location: $_G[siteurl]" . $options['adminscript']);
    }else{
        $error_message = $result['message'];
        include template('nayuan_admin_login:qq_login_error');
    }

}else if($mma === 'bind') { //绑定回调

    define('IN_MOBILE', 2);

    if(submitcheck('bindcallback')) {
        $code = nayuan_get('code', 1);
        $state = nayuan_get('state', 1);

        if(!$code || !$state) {
            C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($state, array(
                'status' => 2,
                'message' => lang('plugin/nayuan_admin_login', 'error_bind_params')
            ));
            exit("0");
        }

        $bindcache = C::t('#nayuan_admin_login#nayuan_admin_cache') -> fetch_cache_data($state);
        if(!$bindcache || intval($bindcache['status']) !== 0) {
            exit("0");
        }

        $thirdoptions = $options['thirds'][$bindcache['third']];
        if(!$thirdoptions) {
            exit("0");
        }

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/qqapi.func.php';

        $callback = $_G['siteurl'] . 'plugin.php?id=nayuan_admin_login:qq&ssid=' . $state . '&mma=bind';
        $result = get_qq_token($thirdoptions, $code, $callback);
        if(!$result['access_token']) {
            exit("0");
        }

        $openiddata = get_qq_openid($result['access_token']);
        if(!$openiddata['openid']) {
            exit("0");
        }

        $qquser = get_qq_userinfo($thirdoptions, $openiddata['openid'], $result['access_token']);
        if(intval($qquser['ret']) !== 0) {
            exit("0");
        }

        $openid = md5('qq-' . $thirdoptions['app_id'] . $openiddata['openid']);
        if(C::t('#nayuan_admin_login#nayuan_admin_login') -> fetch($openid)) {
            C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($state, array(
                'status' => 2,
                'message' => lang('plugin/nayuan_admin_login', 'error_bind_exist')
            ));
            exit("0");
        }

        $nickname = $qquser['nickname'];
        if(strtoupper($_G['charset']) !== 'UTF-8') {
            $nickname = diconv($nickname, 'UTF-8', $_G['charset']);
        }
        C::t('#nayuan_admin_login#nayuan_admin_login') -> insert(array(
            'id' => $openid,
            'uid' => $bindcache['uid'],
            'type' => $bindcache['third'],
            'nickname' => base64_encode($nickname),
            'time' => time()
        ));
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($state, array('status' => 1));
        exit("1");
    }else{
        include template('nayuan_admin_login:qq_bind');
        exit();
    }
}

function checkfounder($user) {
    global $_G;
    $founders = str_replace(' ', '', $_G['config']['admincp']['founder']);
    if(!$user['uid'] || $user['groupid'] != 1 || $user['adminid'] != 1) {
        return false;
    } elseif(empty($founders)) {
        return true;
    } elseif(strexists(",$founders,", ",$user[uid],")) {
        return true;
    } elseif(!is_numeric($user['username']) && strexists(",$founders,", ",$user[username],")) {
        return true;
    } else {
        return FALSE;
    }
}

function check_user_login($uid) {
    global $_G;
    require_once libfile('function/member');
    //clearcookies();
    $member = getuserbyuid($uid, 1);
    $cpgroupid = C::t('common_admincp_member')->fetch($uid);
    $cpgroupid = $cpgroupid['uid'];
    if($cpgroupid || checkfounder($member)) {
        C::t('common_admincp_session')->insert(array(
            'uid' => $uid,
            'adminid' => $member['adminid'],
            'panel' => 1,
            'dateline' => TIMESTAMP,
            'ip' => $_G['clientip'],
            'errorcount' => -1
        ), false, true);

        require_once libfile('function/misc');
        C::t('#nayuan_admin_login#nayuan_admin_logs') -> insert(array(
            'uid' => $uid,
            'third' => 'qq',
            'clientip' => $_G['clientip'],
            'clientport' => $_G['remoteport'],
            'area' => convertip($_G['clientip']),
            'http_referer' => $_SERVER['HTTP_REFERER'],
            'http_user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'http_x_forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'],
            'device' => checkmobile(),
            'time' => time(),
        ));

        setloginstatus($member, 0);
        return array('code' => '200');
    } else {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_user_not_found'));
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>