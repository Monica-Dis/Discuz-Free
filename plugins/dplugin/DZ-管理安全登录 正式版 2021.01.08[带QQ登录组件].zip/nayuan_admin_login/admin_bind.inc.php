<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      admin_bind.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/core.func.php';

$adminurl = 'plugins&operation=config&do=' .$do . '&pmod=admin_bind';

loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];
if(!$options['exist_enable_third']) {
    cpmsg('nayuan_admin_login:error_third_not_bind', 'action=plugins&operation=config&do=' .$do . '&pmod=admin_settings', 'error');
}

if(submitcheck('bindqrcode')) {
    $third = nayuan_get('third', 1);
    $binduid = nayuan_get('uid', 1);
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/class/third/' . $third . '.class.php';
    $thirdclass = 'third_login_' . $third;
    $thirdclass = new $thirdclass($options['thirds'][$third]);

    $uuid = md5(random(32));
    $result = $thirdclass -> qrcode($uuid, $binduid, array(
        'login' => 2,
        'model' => $options['setting']['model'] ? 2 : 1
    ));
    if($result['code'] === '200') {
        $thirdtitle = lang('plugin/nayuan_admin_login', 'bind_dialog_title', array('title' => $options['thirds'][$third]['title']));
        $binduser = getuserbyuid($binduid);
        $binduser['username'] = lang('plugin/nayuan_admin_login', 'bind_dialog_user', array('user' => $binduser['username'] . '(' . $binduid . ')'));
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $thirdtitle = diconv($thirdtitle, $_G['charset'], 'UTF-8');
            $binduser['username'] = diconv($binduser['username'], $_G['charset'], 'UTF-8');
        }

        $result = array(
            'code' => '200',
            'object' => array(
                'uuid' => $uuid,
                'user' => $binduser['username'],
                'title' => $thirdtitle,
                'url' => $result['object']['url']
            )
        );
    }else{
        if(strtoupper($_G['charset']) != 'UTF-8') {
            $result['message'] = diconv($result['message'], $_G['charset'], 'UTF-8');
        }
    }

    define('FOOTERDISABLED', 1);
    ob_end_clean();
    ob_start();

    dheader('Content-Type: application/json; charset=utf-8');
    echo json_encode($result);
    exit;

}else if($_GET['unbinduser'] && $_GET['formhash'] === formhash()) {
    $ssid = nayuan_get('ssid', 1);
    C::t('#nayuan_admin_login#nayuan_admin_login') -> delete($ssid);
    cpmsg('nayuan_admin_login:unbind_success', 'action=' . $adminurl, 'succeed');
}


$founders = $_G['config']['admincp']['founder'] !== '' ? explode(',', str_replace(' ', '', addslashes($_G['config']['admincp']['founder']))) : array();
if($founders) {
    $founderexists = true;
    $fuid = $fuser = array();
    foreach($founders as $founder) {
        if(is_numeric($founder)) {
            $fuid[] = $founder;
        } else {
            $fuser[] = $founder;
        }
    }
    $founders = array();
    if($fuid) {
        $founders = $founders + C::t('common_member')->fetch_all($fuid, false, 0);
    }
    if($fuser) {
        $founders = $founders + C::t('common_member')->fetch_all_by_username($fuser);
    }
} else {
    $founderexists = false;
    $founders = C::t('common_member')->fetch_all_by_adminid(1);
}

$groups = array();
foreach(C::t('common_admincp_group')->range() as $group) {
    $groups[$group['cpgroupid']] = $group['cpgroupname'];
}
$members = $adminmembers = array();
$adminmembers = C::t('common_admincp_member')->range();
foreach ($adminmembers as $adminmember) {
    $adminmembers[$adminmember['uid']] = $adminmember;
}
foreach($founders as $uid => $founder) {
    $members[$uid] = array('uid' => $uid, 'username' => $founder['username'], 'cpgroupname' => cplang('founder_admin'));
}
if($adminmembers) {
    foreach(C::t('common_member')->fetch_all(array_keys($adminmembers), false, 0) as $member) {
        if(isset($members[$member['uid']])) {
            C::t('common_admincp_member')->delete($member['uid']);
            continue;
        }
        $member['cpgroupname'] = !empty($adminmembers[$member['uid']]['cpgroupid']) ? $groups[$adminmembers[$member['uid']]['cpgroupid']] : cplang('founder_master');
        if(!$founderexists && in_array($member['uid'], array_keys($founders))) {
            $member['cpgroupname'] = cplang('founder_admin');
        }
        $members[$member['uid']] = $member;
    }
}

$bindmembers = array();
foreach (C::t('#nayuan_admin_login#nayuan_admin_login') -> fetch_all_member() as $member) {
    $bindmembers[$member['uid']][$member['type']] = $member;
}

showtips(lang('plugin/nayuan_admin_login', 'bind_tips', array('admin' => ADMINSCRIPT)));
showformheader($adminurl);
showtableheader(lang('plugin/nayuan_admin_login', 'bind_list_title'));

$thirdnames = array();
$tableheaders = array('founder_username', 'founder_usergname');
foreach ($options['thirds'] as $name => $third) {
    if(!$third['enable']) continue;
    $tableheaders[] = lang('plugin/nayuan_admin_login', 'bind_list_third', array('title' => $third['title']));
    $thirdnames[] = $name;
}
showsubtitle($tableheaders);
$deleteuids = array();
foreach($members as $id => $member) {
    $deleteuids[] = $member['uid'];
    $isfounder = array_key_exists($id, $founders);
    $values = array(
        "<a href=\"home.php?mod=space&uid=$member[uid]\" target=\"_blank\">$member[username]</a>",
        $member['cpgroupname'],
    );
    foreach ($thirdnames as $name) {
        $thirddata = $bindmembers[$member['uid']][$name];
        $values[] = $thirddata ?
            '<span style="color:green;">'.lang('plugin/nayuan_admin_login', 'bind_btn_is_bind').'('.base64_decode($thirddata['nickname']).')</span>&nbsp;<a href="'.(ADMINSCRIPT . '?action=' . $adminurl . '&unbinduser=1&ssid=' . $thirddata['id'] . '&formhash=' . formhash()).'">'.lang('plugin/nayuan_admin_login', 'bind_btn_un_bind').'</a>'
            : '<span style="color:red;">'.lang('plugin/nayuan_admin_login', 'bind_btn_no_bind').'</span>&nbsp;<a href="javascript:bind_third(\''.$name.'\', '.$member['uid'].')">'.lang('plugin/nayuan_admin_login', 'bind_btn_bind').'</a>';
    }
    showtablerow(
        'style="height:20px"',
        array('class="td24"', 'class="td24"'),
        $values
    );
}
C::t('#nayuan_admin_login#nayuan_admin_login') -> clear_invalid_user($deleteuids);
showsubmit('submit', 'submit');
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/

$api = ADMINSCRIPT . '?action=' . $adminurl . '&formhash=' . formhash();
$statusapi = $_GET['siteurl'] . 'plugin.php?id=nayuan_admin_login:';
$bind_dialog_tips = lang('plugin/nayuan_admin_login', 'bind_dialog_tips');
echo <<<SCRIPT
<div id="bind_qrcode_win" style="display: none;">
    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 20px;">
        <div id="bind_user" style="font-size: 14px; color: #0c5460; font-weight: bold;"></div>
        <div id="bind_qrcode" style="margin: 10px auto;"></div>
        <div>$bind_dialog_tips</div>
    </div>
</div>
<script type="text/javascript" src="/source/plugin/nayuan_admin_login/static/layui/layui.all.min.js"></script>
<script type="text/javascript">
    var layer = layui.layer;
    var djq = jQuery = layui.jquery;
</script>
<script type="text/javascript" src="/source/plugin/nayuan_admin_login/static/jquery.qrcode.min.js"></script>
<script type="text/javascript">
    
    var bindwinindex = null;
    var bindthird = null;
    var checkbindstatusuuid = null;
    var checkbindstatustimer = null;
    function check_bind_status() {
        djq.post(
            '$statusapi' + bindthird + '&mma=status', 
            { ssid: checkbindstatusuuid }, 
            function(data) {
                if(data.code === '201') {
                    return;
                }else if(data.code === '200'){
                    djq('#bind_qrcode_win').hide();
                    clearTimeout(checkbindstatustimer);
                    layer.close(window.bindwinindex);
                    window.location.reload();
                }else{
                    djq('#bind_qrcode_win').hide();
                    clearTimeout(checkbindstatustimer);
                    layer.close(window.bindwinindex);
                    layer.open({
                        content: data.message
                    });
                }
            },
            'json'
        );
    }

    function bind_third(third, uid) {
        
        djq.post(
            '$api&bindqrcode=1', 
            { third: third, uid: uid }, 
            function(data) {
                if(data.code !== '200') {
                    layer.msg(data.message);
                }else{
                    checkbindstatusuuid = data.object.uuid;
                    djq('#bind_qrcode').empty();
                    djq('#bind_qrcode').qrcode({
                        width: 200,
                        height: 200,
                        text: data.object.url
                    });
                    djq('#bind_user').text(data.object.user);
                    djq('#bind_qrcode_win').show();
                    window.bindwinindex = layer.open({
                        type: 1,
                        title: data.object.title,
                        content: djq('#bind_qrcode_win'),
                        end: function() {
                          djq('#bind_qrcode_win').hide();
                          clearTimeout(checkbindstatustimer);
                        }
                    });
                    
                    bindthird = third;
                    window.checkbindstatustimer = setInterval('check_bind_status()', 5000)
                }
            },
            'json'
        );
    }
</script>
SCRIPT;

?>