<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      install.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    CREATE TABLE IF NOT EXISTS `pre_nayuan_admin_login_member` (
        `id`        varchar(32) NOT NULL,
        `uid`       bigint(20) unsigned NOT NULL,
        `nickname`  varchar(255) NOT NULL,
        `type`      varchar(30) NOT NULL,
        `time`      int(10) NOT NULL,
        PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_admin_login_cache` (
        `id`        varchar(32) NOT NULL,
        `token`     varchar(32) DEFAULT NULL,
        `uid`       bigint(20) unsigned NOT NULL,
        `third`     varchar(50) NOT NULL,
        `status`    tinyint(1) NOT NULL,
        `message`   varchar(255) DEFAULT NULL,
        `timeout`   int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        INDEX `idx_time`(`timeout`),
        INDEX `idx_token`(`token`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_admin_login_logs` (
        `id`                    bigint(20) unsigned NOT NULL auto_increment,
        `uid`                   bigint(20) NOT NULL,
        `third`                 varchar(30),
        `clientip`              varchar(15),
        `clientport`            mediumint(5),
        `area`                  varchar(255),
        `http_referer`          varchar(255),
        `http_user_agent`       text,
        `http_x_forwarded_for`  varchar(15),
        `device`                tinyint(1) NOT NULL,
        `time`                  int(10) NOT NULL,
        PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE; /*dism·taobao·com*/

?>