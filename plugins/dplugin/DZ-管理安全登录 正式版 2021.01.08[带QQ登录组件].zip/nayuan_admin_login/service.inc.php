<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      service.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:21.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

showtableheader(lang('plugin/nayuan_admin_login', 'service_title'));
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_help_doc'),
        '<a href="'.lang('plugin/nayuan_admin_login', 'service_help_doc_url').'" target="_blank">'.lang('plugin/nayuan_admin_login', 'service_help_doc_url').'</a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_qq'),
        '<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=467783778&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:467783778:51" alt="'.lang('plugin/nayuan_admin_login', 'service_qq_tips').'" title="'.lang('plugin/nayuan_admin_login', 'service_qq_tips').'"/></a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_qq_group'),
        '<a target="_blank" href="https://jq.qq.com/?_wv=1027&k=XeAyMyn9"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="Dplugin" title="Dplugin"></a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_email'), 'dism.taobao@qq.com',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_site'), '<a href="https://dism.taobao.com" target="_blank">https://dism.taobao.com</a>',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_admin_login', 'service_addon'), '<a href="https://dism.taobao.com/?@12008.developer" target="_blank">https://dism.taobao.com/?@12008.developer</a>',
    )
);
showtablefooter(); /*Dism·taobao·com*/


?>