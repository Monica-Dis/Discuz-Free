<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      uninstall.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_admin_login_member`;
    DROP TABLE IF EXISTS `pre_nayuan_admin_login_cache`;
    DROP TABLE IF EXISTS `pre_nayuan_admin_login_logs`;

EOF;

runquery($sql);

////// 文件还原
loadcache('nayuan_admin_login');
$options = $_G['cache']['nayuan_admin_login'];
if($options['setting']['open']) {
    @unlink(DISCUZ_ROOT . $options['adminscript']);
    @rename(DISCUZ_ROOT . $options['adminscript'] . '.don-t.delete.me.dplugin', DISCUZ_ROOT . $options['adminscript']);
}

C::t('common_syscache') -> delete('nayuan_admin_login');



$finish = TRUE; /*dism·taobao·com*/

?>