<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      table_nayuan_admin_login.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_admin_login extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_admin_login_member';
        $this->_pk    = 'id';
        parent::__construct(); /*dism _ taobao _ com*/
    }

    public function fetch_all_member() {
        return DB::fetch_all("SELECT * FROM %t", array($this -> _table));
    }

    public function clear_invalid_user($ids) {
        DB::query("DELETE FROM %t WHERE `uid` NOT IN (%n)", array($this -> _table, $ids));
    }

    public function exist_bind_user($types, $uids) {
        return DB::result_first("SELECT 1 FROM %t WHERE `type` in (%n) AND `uid` in (%n) LIMIT 1", array($this -> _table, $types, $uids));
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>