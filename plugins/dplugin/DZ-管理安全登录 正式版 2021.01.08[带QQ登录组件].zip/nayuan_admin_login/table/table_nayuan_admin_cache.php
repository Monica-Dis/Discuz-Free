<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      table_nayuan_admin_cache.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_admin_cache extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_admin_login_cache';
        $this->_pk    = 'id';
        parent::__construct(); /*dism _ taobao _ com*/
    }

    public function fetch_cache_data($id) {
        DB::query("DELETE FROM %t WHERE `timeout` < %d", array($this -> _table, time()));
        return $this -> fetch($id);
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>