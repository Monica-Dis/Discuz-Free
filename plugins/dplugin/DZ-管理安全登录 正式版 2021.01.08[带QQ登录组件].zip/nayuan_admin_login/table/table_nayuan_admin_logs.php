<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      table_nayuan_admin_logs.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_admin_logs extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_admin_login_logs';
        $this->_pk    = 'id';
        parent::__construct(); /*dism _ taobao _ com*/
    }

    public function fetch_list($third, $uid, $username, $ip, $page = 1, $pagesize = 15) {
        $wherestr = $params = array();
        $wherestr[] = 'a.uid = b.uid';
        $params[] = $this -> _table;
        $params[] = 'common_member';

        if($uid) {
            $wherestr[]= 'a.`uid` = %d';
            $params[] = $uid;
        }
        if($username) {
            $wherestr[]= 'b.`username` = %s';
            $params[] = $username;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($third){
            $wherestr[]= 'a.`third` = %s';
            $params[] = $third;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }

        $_result = array();
        $_total = DB::result_first("SELECT count(*) FROM %t a, %t b $wherestr", $params);
        if(!$_total) {
            $_result['total'] = 0;
            $_result['list'] = array();
        }else{
            $_list = DB::fetch_all("SELECT a.*,b.username FROM %t a, %t b $wherestr ORDER BY a.id DESC" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
            $_result['total'] = $_total;
            $_result['list'] = $_list;
        }
        return $_result;
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>