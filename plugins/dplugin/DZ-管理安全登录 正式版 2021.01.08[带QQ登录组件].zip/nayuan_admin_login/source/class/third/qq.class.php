<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      qq.class.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-25 21:25:04.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class third_login_qq {

    var $option;

    public function third_login_qq($option) {
        $this -> option = $option;
    }

    public function qrcode($id, $uid, $extparams = array()) {
        global $_G;
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> insert(array(
            'id' => $id,
            'uid' => $uid,
            'third' => 'qq',
            'status' => 0,
            'timeout' => time() + 600
        ));

        $callback = $_G['siteurl'] . 'plugin.php?id=nayuan_admin_login:qq' . ($uid ? '&mma=bind' : '&mma=login');
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/qqapi.func.php';
        $url = get_qq_authorize_url($this -> option, $callback, 'get_user_info', $id, $extparams['login']);
        return array(
            'code' => '200',
            'object' => array(
                'url' => $url
            )
        );
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>