<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      dpluginqq.class.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class third_login_dpluginqq {

    var $option;

    public function third_login_dpluginqq($option) {
        $this -> option = $option;
    }

    public function qrcode($id, $uid, $extparams = array()) {
        global $_G;
        $data = array(
            'callback' => $_G['siteurl'] . 'plugin.php?id=nayuan_admin_login:dpluginqq&ssid=' . $id . ($uid ? '&mma=bind' : '&mma=login'),
            'login' => $extparams['login'],
            'model' => $extparams['model']
        );
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/function/dpluginapi.func.php';
        $result = get_proxy_login_qq_url($this -> option, $data);
        if($result && $result['code'] === '200') {
            C::t('#nayuan_admin_login#nayuan_admin_cache') -> insert(array(
                'id' => $id,
                'token' => $result['object']['token'],
                'uid' => $uid,
                'third' => 'dpluginqq',
                'status' => 0,
                'timeout' => time() + 600
            ));
        }

        return $result;
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>