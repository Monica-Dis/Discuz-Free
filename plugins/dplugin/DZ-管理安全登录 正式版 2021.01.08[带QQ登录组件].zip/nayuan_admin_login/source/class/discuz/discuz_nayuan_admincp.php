<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      discuz_nayuan_admincp.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class discuz_nayuan_admincp extends discuz_admincp {

    function &instance() {
        static $object;
        if(empty($object)) {
            $object = new discuz_nayuan_admincp();
        }
        return $object;
    }

    function check_cpaccess() {
        global $_G;
        $session = array();

        if(!$this->adminuser['uid']) {
            $this->cpaccess = 0;
        } else {

            if(!$this->isfounder) {
                $session = C::t('common_admincp_member')->fetch($this->adminuser['uid']);
                if($session) {
                    $session = array_merge($session, C::t('common_admincp_session')->fetch($this->adminuser['uid'], $this->panel));
                }
            } else {
                $session = C::t('common_admincp_session')->fetch($this->adminuser['uid'], $this->panel);
            }

            if(empty($session)) {
                $this->cpaccess = $this->isfounder ? 1 : -2;

            } elseif($_G['setting']['adminipaccess'] && !ipaccess($_G['clientip'], $_G['setting']['adminipaccess'])) {
                $this->do_user_login();

            } elseif ($session && empty($session['uid'])) {
                $this->cpaccess = 1;

            } elseif ($session['dateline'] < $this->sessionlimit) {
                $this->cpaccess = 1;

            } elseif ($this->cpsetting['checkip'] && ($session['ip'] != $this->core->var['clientip'])) {
                $this->cpaccess = 1;

            } elseif ($session['errorcount'] >= 0 && $session['errorcount'] <= 3) {
                $this->cpaccess = 2;

            } elseif ($session['errorcount'] == -1) {
                $this->cpaccess = 3;

            } else {
                $this->cpaccess = -1; //您的管理面板已经锁定! 请在 1791 秒以后重新访问管理中心
            }
        }

        if($this->cpaccess == 2 || $this->cpaccess == 3) {
            if(!empty($session['customperm'])) {
                $session['customperm'] = dunserialize($session['customperm']);
            }
        }

        $this->adminsession = $session;

        if($this->cpaccess == 1) {
            C::t('common_admincp_session')->delete($this->adminuser['uid'], $this->panel, $this->sessionlife);
            C::t('common_admincp_session')->insert(array(
                'uid' => $this->adminuser['uid'],
                'adminid' => $this->adminuser['adminid'],
                'panel' => $this->panel,
                'ip' => $this->core->var['clientip'],
                'dateline' => TIMESTAMP,
                'errorcount' => 0,
            ));
        } elseif ($this->cpaccess == 3) {
            $this->load_admin_perms();
            C::t('common_admincp_session')->update($this->adminuser['uid'], $this->panel, array('dateline' => TIMESTAMP, 'ip' => $this->core->var['clientip'], 'errorcount' => -1));
        }

        if($this->cpaccess != 3) {
            $this->do_user_login();
        }

    }

    function admincpfile($action) {
        if($action === 'login') {
            return './source/plugin/nayuan_admin_login/source/admincp/admincp_'.$action.'.php';
        }else{
            return './source/admincp/admincp_'.$action.'.php';
        }
    }

}
//From: d'.'is'.'m.ta'.'obao.com
?>