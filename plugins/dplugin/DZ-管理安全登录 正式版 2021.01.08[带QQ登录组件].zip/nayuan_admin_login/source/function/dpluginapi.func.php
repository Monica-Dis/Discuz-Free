<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      dpluginapi.func.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function get_proxy_login_qq_url($options, $data) {
    global $_G;
    if(!$options['access_key_id'] || !$options['access_key_secret']) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'no_set_key'));
    }
    $api = dplugin_sign_url($options, 'proxy_login_qq');
    $result = dplugin_api_request($api, json_encode($data));
    if(!$result) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_internet'));
    }
    $result = json_decode($result, true);
    if(strtoupper($_G['charset']) != 'UTF-8') {
        $result = nayuan_convert_encoding($result, $_G['charset'], 'UTF-8');
    }
    return $result;
}

function get_proxy_login_weixin_url($options, $data) {
    global $_G;
    if(!$options['access_key_id'] || !$options['access_key_secret']) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'no_set_key'));
    }
    $api = dplugin_sign_url($options, 'proxy_login_weixin');
    $result = dplugin_api_request($api, json_encode($data));
    if(!$result) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_internet'));
    }
    $result = json_decode($result, true);
    if(strtoupper($_G['charset']) != 'UTF-8') {
        $result = nayuan_convert_encoding($result, $_G['charset'], 'UTF-8');
    }
    return $result;
}

function get_proxy_login_status($options, $data) {
    global $_G;
    if(!$options['access_key_id'] || !$options['access_key_secret']) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'no_set_key'));
    }
    $api = dplugin_sign_url($options, 'proxy_login_status');
    $result = dplugin_api_request($api, json_encode($data));
    if(!$result) {
        return array('code' => '500', 'message' => lang('plugin/nayuan_admin_login', 'error_internet'));
    }
    $result = json_decode($result, true);
    if(strtoupper($_G['charset']) != 'UTF-8') {
        $result = nayuan_convert_encoding($result, $_G['charset'], 'UTF-8');
    }

    return $result;
}

function nayuan_convert_encoding($data, $to_encoding, $from_encoding) {
    switch (gettype($data)) {
        case 'array':
            foreach($data as $_k => $_v) {
                $data[$_k] = nayuan_convert_encoding($_v, $to_encoding, $from_encoding);
            }
            break;
        case 'string':
            $data = diconv($data, $from_encoding, $to_encoding);
            break;
    }
    return $data;
}

function dplugin_sign($openid, $timestamp, $secret) {
    $urlparams = 'openid=' . $openid;
    $urlparams .= '&timestamp=' . $timestamp;
    return strtoupper(md5($urlparams.$secret));
}

function dplugin_sign_url($options, $method) {
    $urlparams = 'access_key_id=' . $options['access_key_id'];
    $urlparams .= '&format=JSON';
    $urlparams .= '&method=' . $method;
    $urlparams .= '&timestamp=' . time();
    return 'https://openapi.dplugin.com/gateway.do?' . $urlparams . '&sign=' . strtoupper(md5($urlparams.$options['access_key_secret']));
}

function dplugin_api_request($api, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch,CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json; charset=utf-8',
        'Content-Length:' . strlen($data),
    ));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    $result = curl_exec($ch);
    $status = curl_getinfo($ch);
    $errno = curl_errno($ch);
    curl_close($ch);
    if($errno || $status['http_code'] != 200) {
        return '';
    } else {
        return $result;
    }
}

function validate_callback_data($thirdoptions, $ssid, $openid, $timestamp, $sign, $nickname = '') {
    global $_G;
    if(!$ssid || !$openid || !$timestamp || !$sign) {
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array(
            'status' => 2,
            'message' => lang('plugin/nayuan_admin_login', 'error_bind_params')
        ));
        return;
    }

    if($timestamp > time() + 300 || $timestamp < time() - 300) { //前台5分钟
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array(
            'status' => 2,
            'message' => lang('plugin/nayuan_admin_login', 'error_bind_time')
        ));
        return;
    }
    $bindcache = C::t('#nayuan_admin_login#nayuan_admin_cache') -> fetch_cache_data($ssid);
    if(!$bindcache || intval($bindcache['status']) !== 0) {
        return;
    }

    if(!$thirdoptions) {
        return;
    }

    $signstr = dplugin_sign($openid, $timestamp, $thirdoptions['access_key_secret']);
    if($signstr !== $sign) {
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> delete($ssid);
        return;
    }

    if($bindcache['uid']) { //绑定
        if(C::t('#nayuan_admin_login#nayuan_admin_login') -> fetch($openid)) {
            C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array(
                'status' => 2,
                'message' => lang('plugin/nayuan_admin_login', 'error_bind_exist')
            ));
            return;
        }
        if(strtoupper($_G['charset']) !== 'UTF-8') {
            $nickname = diconv($nickname, 'UTF-8', $_G['charset']);
        }
        C::t('#nayuan_admin_login#nayuan_admin_login') -> insert(array(
            'id' => $openid,
            'uid' => $bindcache['uid'],
            'type' => $bindcache['third'],
            'nickname' => base64_encode($nickname),
            'time' => time()
        ));
        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array('status' => 1));
    }else{ //登录
        $member = C::t('#nayuan_admin_login#nayuan_admin_login') -> fetch($openid);
        if(!$member) {
            C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array(
                'status' => 2,
                'message' => lang('plugin/nayuan_admin_login', 'error_user_not_found')
            ));
            return;
        }

        C::t('#nayuan_admin_login#nayuan_admin_cache') -> update($ssid, array(
            'status' => 1,
            'uid' => $member['uid']
        ));
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>