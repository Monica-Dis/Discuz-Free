<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      qqapi.func.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-25 21:25:04.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function get_qq_authorize_url($options, $callback, $scope, $state, $display = '') {
    $result = 'https://graph.qq.com/oauth2.0/authorize';
    $result .= '?client_id=' . $options['app_id'];
    $result .= '&redirect_uri=' . urlencode($callback);
    $result .= '&response_type=code';
    $result .= '&scope=' . $scope;
    $result .= '&state=' . $state;
    if($display) {
        $result .= '&display=mobile';
    }
    return $result;
}

function get_qq_token($options, $code, $callback) {
    $api = "https://graph.qq.com/oauth2.0/token";
    $api .= '?client_id=' . $options['app_id'];
    $api .= '&grant_type=authorization_code';
    $api .= '&client_secret=' . $options['app_key'];
    $api .= '&redirect_uri=' . urlencode($callback);
    $api .= '&code=' . $code;
    $api .= '&fmt=json';
    $data = dfsockopen($api);
    return json_decode($data, true);
}

function get_qq_openid($accesstoken) {
    $api = "https://graph.qq.com/oauth2.0/me?access_token=$accesstoken&fmt=json";
    $data = dfsockopen($api);
    return json_decode($data, true);
}

function get_qq_userinfo($options, $openid, $accesstoken) {
    $api = "https://graph.qq.com/user/get_user_info?access_token=$accesstoken&openid=$openid&oauth_consumer_key=$options[app_id]&fmt=json";
    $data = dfsockopen($api);
    return json_decode($data, true);
}
//From: d'.'is'.'m.ta'.'obao.com
?>