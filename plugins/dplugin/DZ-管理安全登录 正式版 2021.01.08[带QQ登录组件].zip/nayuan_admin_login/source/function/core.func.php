<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      core.func.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:21.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_get($name, $type = 0, $default = '') {
    $value = $_GET[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_post($name, $type = 0, $default = '') {
    $value = $_POST[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_strreplace($str, $vars) {
    if($vars && is_array($vars)) {
        foreach($vars as $k => $v) {
            $searchs[] = '{'.$k.'}';
            $replaces[] = $v;
        }
    }
    if(is_string($str) && strpos($str, '{_G/') !== false) {
        preg_match_all('/\{_G\/(.+?)\}/', $str, $gvar);
        foreach($gvar[0] as $k => $v) {
            $searchs[] = $v;
            $replaces[] = getglobal($gvar[1][$k]);
        }
    }
    return str_replace($searchs, $replaces, $str);
}

function nayuan_options($file, $langvar = null) {
    parse_str(lang($file, $langvar), $_list);
    return $_list;
}

function nayuan_show_options($value, $select, $exclude = array()) {
    $_options = array();
    parse_str($value, $_list);
    foreach($_list as $_value => $_title) {
        if($exclude && in_array($_value, $exclude)) continue;
        $_options[] = "<option value=\"$_value\" " . ($select === $_value ? "selected=\"selected\"" : "") . ">$_title</option>";
    }
    return implode("", $_options);
}

function nayuan_format_filesize($size, $prec = 3) {
    if($size < 1024) {
        return $size . 'B';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'K';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'M';
    }
    $size /= 1024;
    return round($size, $prec) . 'G';
}

function nayuan_filelock($id, $timeout) {
    $lock_file = DISCUZ_ROOT . 'data/nayuan_admin_login.' . $id . '.lock';
    if(file_exists($lock_file)) {
        $time = filectime($lock_file);
        if($time) {
            if($time + $timeout < time()) {
                @unlink($lock_file);
            }else{
                return false;
            }
        }
    }

    if(!($fp = @fopen($lock_file, 'a')) || !@flock($fp, LOCK_EX)) {
        return false;
    }
    return $fp;
}

function nayyuan_clear_filelock($fp, $id) {
    $lock_file = DISCUZ_ROOT . 'data/nayuan_admin_login.' . $id . '.lock';
    @flock($fp, LOCK_UN);
    @fclose($fp);
    @unlink($lock_file);
}

function nayuan_result_json($data, $code = '200', $message = '') {
    echo nayuan_json(array('code' => $code, 'message' => $message, 'result' => $data));
    exit;
}

function nayuan_dnumber($number, $precision = 2) {
    return abs($number) > 10000 ? '<span title="'.$number.'">'.round($number / 10000, $precision).'</span>'.lang('core', '10k') : $number;
}

function nayuan_admin_loading($message, $url = '', $values = array(), $extra = '', $timeout = 5000) {
    global $_G;
    $vars = explode(':', $message);
    $values['ADMINSCRIPT'] = ADMINSCRIPT;
    if(count($vars) == 2) {
        $message = lang('plugin/'.$vars[0], $vars[1], $values);
    } else {
        $message = cplang($message, $values);
    }
    $classname = 'infotitle1';
    $url = substr($url, 0, 5) == 'http:' ? $url : ADMINSCRIPT.'?'.$url;
    $message = "<h4 class=\"$classname\">$message</h4>";
    $url .= $url && !empty($_GET['scrolltop']) ? '&scrolltop='.intval($_GET['scrolltop']) : '';

    if($url) {
        $message = "<form method=\"post\" action=\"$url\" id=\"loadingform\"><input type=\"hidden\" name=\"formhash\" value=\"".FORMHASH."\"><br />$message$extra<img src=\"static/image/admincp/ajax_loader.gif\" class=\"marginbot\" /><br />".
            '<p class="marginbot"><a href="###" onclick="$(\'loadingform\').submit();" class="lightlink">'.cplang('message_redirect').'</a></p></form><br /><script type="text/JavaScript">setTimeout("$(\'loadingform\').submit();", '.$timeout.');</script>';
    }else{
        $message .= $extra.'<img src="static/image/admincp/ajax_loader.gif" class="marginbot" />';
    }


    echo '<h3>'.cplang('discuz_message').'</h3><div class="infobox">'.$message.'</div>';
    exit();
}
//From: d'.'is'.'m.ta'.'obao.com
?>