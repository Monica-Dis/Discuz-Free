<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      admincp_login.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;

loadcache('nayuan_admin_login');
$dpluginoptions = $_G['cache']['nayuan_admin_login'];
if($dpluginoptions['adminscript'] !== ADMINSCRIPT) {
    //// admin文件名被修改之后，及时更新
    $dpluginoptions['adminscript'] = ADMINSCRIPT;
    savecache('nayuan_admin_login', $dpluginoptions);
}

if($this->cpaccess == -3) {
    $error_message = lang('admincp_login', 'login_cp_noaccess');
}elseif($this->cpaccess == -1) {
	$ltime = $this->sessionlife - (TIMESTAMP - $this->adminsession['dateline']);
	$error_message = lang('admincp_login', 'login_cplock', array('ltime' => $ltime));
}elseif($this->cpaccess == -4) {
	$ltime = $this->sessionlife - (TIMESTAMP - $this->adminsession['dateline']);
	$error_message = lang('admincp_login', 'login_user_lock');
}

if(!$error_message) {
    $year = dgmdate(time(), 'Y');
    loadcache('nayuan_admin_login');
    $options = $_G['cache']['nayuan_admin_login'];

    $thirds = array();
    foreach ($options['thirds'] as $name => $third) {
        if(!$third['enable']) continue;
        include DISCUZ_ROOT . 'source/plugin/nayuan_admin_login/source/language/third/lang_third_' . $name . '_' . currentlang() . '.php';
        $thirds[] = array(
            'name' => $name,
            'title' => $lang_nayuan_third['login_title'],
            'logo' => $lang_nayuan_third['login_logo'],
        );
        unset($lang_nayuan_third);
    }
}

if(checkmobile()) {
    define('IN_MOBILE', 2);
}
$ismobile = checkmobile() ? 1 : 0;
include template('nayuan_admin_login:login');

exit();

?>