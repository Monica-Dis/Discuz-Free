<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      lang_third_dpluginweixin.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_third = array(

    'title'         => 'Dplugin代理微信登录',
    'url'           => 'https://www.dplugin.com/admin/api/proxy/login',
    'desc'          => '<a href="https://www.dplugin.com/admin/api/proxy/login" target="_blank">开通代理登录功能</a>, AccessKeyId/AccessKeySecret获取地址: <a href="https://www.dplugin.com/admin/user/ak" target="_blank">打开</a>',
    'inputs'        => array(
        array('name' => 'access_key_id', 'title' => 'AccessKeyId'),
        array('name' => 'access_key_secret', 'title' => 'AccessKeySecret'),
    ),

    "login_logo"    => 'proxy_weixin.svg',
    "login_title"   => '使用微信登录'

);

?>
