<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_admin_login.
 *      lang_third_qq.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-25 21:25:04.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_third = array(

    'title'         => '官方QQ登錄',
    'url'           => 'https://connect.qq.com/index.html',
    'desc'          => '需要添加的回調URL：' . $_G['siteurl'] . 'plugin.php',
    'inputs'        => array(
        array('name' => 'app_id', 'title' => 'AppId'),
        array('name' => 'app_key', 'title' => 'AppKey'),
    ),
    "login_logo"    => 'qq.svg',
    "login_title"   => '使用QQ登錄'

);

?>
