<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_admin_login.
 *      lang_third_dpluginqq.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_third = array(

    'title'         => 'Dplugin����QQ��¼',
    'url'           => 'https://www.dplugin.com/admin/api/proxy/login',
    'desc'          => '<a href="https://www.dplugin.com/admin/api/proxy/login" target="_blank">��ͨ������¼����</a>, AccessKeyId/AccessKeySecret��ȡ��ַ: <a href="https://www.dplugin.com/admin/user/ak" target="_blank">��</a>',
    'inputs'        => array(
        array('name' => 'access_key_id', 'title' => 'AccessKeyId'),
        array('name' => 'access_key_secret', 'title' => 'AccessKeySecret'),
    ),
    "login_logo"    => 'proxy_qq.svg',
    "login_title"   => 'ʹ��QQ��¼'

);

?>
