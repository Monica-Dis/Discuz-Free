<?php

/**
 *      Dplugin插件定製平臺 (https://www.dplugin.com/).
 *      nayuan_admin_login.
 *      lang_third_dpluginqq.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2021-01-08 11:54:20.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_third = array(

    'title'         => 'Dplugin代理QQ登錄',
    'url'           => 'https://www.dplugin.com/admin/api/proxy/login',
    'desc'          => '<a href="https://www.dplugin.com/admin/api/proxy/login" target="_blank">開通代理登錄功能</a>, AccessKeyId/AccessKeySecret獲取地址: <a href="https://www.dplugin.com/admin/user/ak" target="_blank">打開</a>',
    'inputs'        => array(
        array('name' => 'access_key_id', 'title' => 'AccessKeyId'),
        array('name' => 'access_key_secret', 'title' => 'AccessKeySecret'),
    ),
    "login_logo"    => 'proxy_qq.svg',
    "login_title"   => '使用QQ登錄'

);

?>
