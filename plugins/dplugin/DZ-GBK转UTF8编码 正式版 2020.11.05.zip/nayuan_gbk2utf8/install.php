<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      install.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    CREATE TABLE IF NOT EXISTS `pre_nayuan_gbk2utf8_file` (
        `id`		    bigint(20) unsigned NOT NULL auto_increment,
        `md5`           char(32) NOT NULL,
        `path`          varchar(255) NOT NULL,
        `name`          varchar(255) NOT NULL,
        `encode`        varchar(50) DEFAULT NULL,
        `status`        tinyint(1) NOT NULL DEFAULT 0,
        `time`          int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        UNIQUE INDEX `idx_md5`(`md5`) USING HASH,
        INDEX `idx_status`(`status`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_gbk2utf8_confirm` (
        `id`		    bigint(20) unsigned NOT NULL auto_increment,
        `fid`		    bigint(20) unsigned NOT NULL,
        `line`          int(10) NOT NULL,
        `message`       text NOT NULL,
        `status`        tinyint(1) NOT NULL DEFAULT 0,
        `time`          int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        INDEX `idx_fid`(`fid`),
        INDEX `idx_status`(`status`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_gbk2utf8_table` (
        `id`		    bigint(20) unsigned NOT NULL auto_increment,
        `table`		    varchar(50) NOT NULL,
        `volume`		int(10) unsigned NOT NULL,
        `path`          varchar(255) NOT NULL,
        `status`        tinyint(1) NOT NULL DEFAULT 0,
        `time`          int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        UNIQUE INDEX `idx_table`(`table`,`volume`) USING HASH,
        INDEX `idx_status`(`status`)
    ) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = true;

?>