<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      uninstall.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_gbk2utf8_file`;
    DROP TABLE IF EXISTS `pre_nayuan_gbk2utf8_confirm`;
    DROP TABLE IF EXISTS `pre_nayuan_gbk2utf8_table`;

EOF;

runquery($sql);

C::t('common_syscache') -> delete('nayuan_gbk2utf8');

$finish = true;

?>