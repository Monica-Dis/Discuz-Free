<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      table_nayuan_gbk2utf8.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class table_nayuan_gbk2utf8 extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_gbk2utf8_file';
        $this->_pk    = 'id';
        parent::__construct();/*Dism_taobao-com*/
    }

    public function exist($md5list) {
        return DB::fetch_all("SELECT `md5` FROM %t WHERE `md5` in (%n)", array($this -> _table, $md5list), 'md5');
    }

    public function fetch_un_exec_list($num) {
        return DB::fetch_all("SELECT `id`, `path`, `name` FROM %t WHERE `status` = 0 LIMIT %d", array($this -> _table, $num));
    }

    public function count_all() {
        return Db::result_first("SELECT count(*) FROM %t", array($this -> _table));
    }

    public function count_finish() {
        return DB::result_first('SELECT count(*) FROM %t WHERE `status` = 1', array($this -> _table));
    }

    public function batch_insert($list) {
        $sql = array();
        $time = time();
        foreach($list as $item) {
            $sql[] = "('$item[md5]', '".addslashes($item['path'])."', '".addslashes($item['name'])."', $time)";
        }
        if($sql) {
            DB::query('INSERT INTO '.DB::table($this->_table)."(`md5`, `path`, `name`, `time`) VALUES ".implode(', ', $sql));
        }
    }

}

?>