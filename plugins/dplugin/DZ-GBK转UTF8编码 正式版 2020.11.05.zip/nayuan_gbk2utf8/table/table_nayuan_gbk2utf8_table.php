<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      table_nayuan_gbk2utf8_table.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class table_nayuan_gbk2utf8_table extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_gbk2utf8_table';
        $this->_pk    = 'id';
        parent::__construct();/*Dism_taobao-com*/
    }

    public function exist($table, $volume) {
        return DB::result_first("SELECT count(*) FROM %t WHERE `table` = %s AND `volume` = %d", array($this -> _table, $table, $volume));
    }

    public function fetch_un_exec() {
        return DB::fetch_first("SELECT `id`, `table`, `volume`,`path` FROM %t WHERE `status` = 0 ORDER BY `table`,`volume` LIMIT 1", array($this -> _table));
    }

    public function count_all() {
        return Db::result_first("SELECT count(*) FROM %t", array($this -> _table));
    }

    public function count_finish() {
        return DB::result_first('SELECT count(*) FROM %t WHERE `status` = 1', array($this -> _table));
    }

    public function reset_status($table) {
        DB::query("UPDATE %t SET `status` = 0 WHERE `table` = %s", array($this -> _table, $table));
    }

}

?>