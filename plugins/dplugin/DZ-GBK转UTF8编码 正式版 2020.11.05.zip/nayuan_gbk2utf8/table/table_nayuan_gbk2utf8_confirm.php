<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      table_nayuan_gbk2utf8_confirm.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class table_nayuan_gbk2utf8_confirm extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_gbk2utf8_confirm';
        $this->_pk    = 'id';
        parent::__construct();/*Dism_taobao-com*/
    }

    public function exist_line($fid, $line) {
        return DB::result_first("SELECT count(*) FROM %t WHERE `fid` = %d AND `line` = %d", array($this -> _table, $fid, $line));
    }

    public function fetch_un_exec_list() {
        return DB::fetch_all("SELECT a.id, b.path, b.name, a.line, a.message FROM %t a, %t b WHERE a.fid = b.id AND a.status = 0 ORDER BY b.`path`, b.`name`, a.`line`", array($this -> _table, 'nayuan_gbk2utf8_file'));
    }

    public function fetch_file($id) {
        return DB::fetch_first("SELECT a.id, b.path, b.name, a.line FROM %t a, %t b WHERE a.fid = b.id AND a.id = %d AND a.status = 0", array($this -> _table, 'nayuan_gbk2utf8_file', $id));
    }

}

?>