<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      conversion.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_gbk2utf8/source/function/core.func.php';

loadcache('nayuan_gbk2utf8');
$plugincache = $_G['cache']['nayuan_gbk2utf8'];

$_steps = array('tips' => 0, 'dbbackup' => 1, 'scanfile' => 2, 'execfile' => 3, 'fileconfirm' => 4, 'success' => 5);
$_step = nayuan_get('step', 1);
if(!$_step && $plugincache['step']) {
    $_step = $plugincache['step'];
}
if(!$_step || !in_array($_step, $_steps)) {
    $_step = 'tips';
}

if($_step != 'execfile' && file_exists(DISCUZ_ROOT . 'data/nayuan_gbk2utf8.execfile.lock')) {
    $_step = 'execfile';
}

$adminurl = 'plugins&operation=config&do=' . $do . '&pmod=conversion';
////////////// 步骤
echo '<div class="floattop mytop">';
$fileconfirm = lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm');
if($_steps[$_step] > 4) {
    $fileconfirm = '<a href="'.ADMINSCRIPT.'?action='.$adminurl.'&step=fileconfirm">'.$fileconfirm.'</a>';
}
showsubmenusteps(lang('plugin/nayuan_gbk2utf8', 'title'), array(
    array(lang('plugin/nayuan_gbk2utf8', 'step_tips'), $_steps[$_step] >= 0),
    array(lang('plugin/nayuan_gbk2utf8', 'step_dbbackup'), $_steps[$_step] >= 1),
    array(lang('plugin/nayuan_gbk2utf8', 'step_scanfile'), $_steps[$_step] >= 2),
    array(lang('plugin/nayuan_gbk2utf8', 'step_execfile'), $_steps[$_step] >= 3),
    array($fileconfirm, $_steps[$_step] >= 4),
    array(lang('plugin/nayuan_gbk2utf8', 'step_success'), $_steps[$_step] >= 5),
));
echo '</div>';

showtips(lang('plugin/nayuan_gbk2utf8', 'tips'));
echo '<br/><br/><br/>';

if(!function_exists('mb_convert_encoding')) {
    cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_mbsting_error'), '', 'error');
}
if($_steps[$_step] < 3) {
    $encode = currentlang();
    if($encode === 'SC_UTF8') {
        cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_utf8_error'), '', 'error');
    }else if($encode !== 'SC_GBK') {
        cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_gbk_error'), '', 'error');
    }
    if(!is_writeable(DISCUZ_ROOT . 'template/default/common/header.htm')) {
        cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_write_error'), '', 'error');
    }
    if(currentlang() != 'SC_GBK') {
        cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_write_error'), '', 'error');
    }
}

if(!$_G['setting']['bbclosed']) {
    cpmsg(lang('plugin/nayuan_gbk2utf8', 'step_check_bbclosed_error', array('admin' => ADMINSCRIPT)), '', 'error');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_gbk2utf8/source/admincp/step_' . $_step . '.inc.php';

?>