<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_execfile.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

$filedao = C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8');
$tabledao = C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_table');

loadcache('nayuan_gbk2utf8');
$plugindata = $_G['cache']['nayuan_gbk2utf8'];
$plugindata['step'] = 'execfile';
savecache('nayuan_gbk2utf8', $plugindata);

if(submitcheck('execfile')) {

    if($plugindata['execfile_success']) {

        writelog('gbk2utf8_table', '[INFO] execfile-update-plugin-modules');
        ////插件表中的SC_GBK替换
        $_pluginlist = C::t('common_plugin') -> fetch_all_data();
        foreach ($_pluginlist as $_plugin) {
            $_plugin['modules'] = unserialize($_plugin['modules']);
            if($_plugin['modules']['extra']['installtype'] == 'SC_GBK') {
                $_plugin['modules']['extra']['installtype'] = 'SC_UTF8';
                C::t('common_plugin') -> update($_plugin['pluginid'], array('modules' => serialize($_plugin['modules'])));
            }
            unset($_plugin);
        }

        $dbname = $_G['config']['db'][1]['dbname'];
        DB::query("alter database `$dbname` character set utf8 COLLATE 'utf8_general_ci'");
        if($sqlerror = DB::error()) {
            cpmsg('database_run_query_invalid', '', 'error', array('sqlerror' => $sqlerror));
        }
        writelog('gbk2utf8_table', '[INFO] execfile-update-database');

        nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_execfile_message', array('file_prc' => '100%', 'db_prc' => '100%')), 'action=' . $adminurl . '&step=fileconfirm', array(), '', 5000);
    }

    $max_allowed_packet = DB::fetch_first("show variables like 'max_allowed_packet'");
    if($max_allowed_packet['Value'] < 20 * 1024 * 1024) {
        cpmsg('nayuan_gbk2utf8:step_maxallowedpacket_error', '', 'error');
    }

    if($fp = nayuan_filelock('execfile', time() + 604800)) {
        @ignore_user_abort(true);
        @set_time_limit(0);
        ////执行文件转换
        while(true) {
            $list = $filedao -> fetch_un_exec_list(100);
            if($list) {
                conversion_file($filedao, $list);
                unset($list);
            }else{
                break;
            }
        }
        ////执行数据库转换
        $db = & DB::object();
        $setnames = $db->version() > '4.1' ? "SET NAMES 'UTF8';\n\n" : '';

        $firsttable = 0;
        while(true) {
            $table = $tabledao -> fetch_un_exec();
            if($table) {
                if(!$firsttable) {
                    if($table['volume'] > 0) {
                        $tabledao -> reset_status($table['table']);
                        continue;
                    }else{
                        $firsttable = 1;
                    }
                }
                writelog('gbk2utf8_table', '[INFO] execfile-table-'.$table['table'] . '---' . memory_get_usage());
                conversion_db($tabledao, $table);

                if(preg_match("/^.+common_syscache$/i", $table['table'])) {
                    //避免缓存状态被盖掉
                    savecache('nayuan_gbk2utf8', $plugindata);
                }

                unset($table);
            }else{
                break;
            }
        }

        //// 清理缓存数据
        if( C::memory() -> enable ) {
            C::memory() -> clear();
        }

        nayyuan_clear_filelock($fp, 'execfile');
        $plugindata['execfile_success'] = 1;
        savecache('nayuan_gbk2utf8', $plugindata);

        nayuan_loading($filedao, $tabledao);

    }else{
        //// 清理缓存数据
        if( C::memory() -> enable ) {
            C::memory() -> clear();
        }

        nayuan_loading($filedao, $tabledao);
    }

}else{
    //// 清理缓存数据
    if( C::memory() -> enable ) {
        C::memory() -> clear();
    }

    nayuan_loading($filedao, $tabledao);
}


function nayuan_loading($filedao, $tabledao) {
    global $adminurl;
    $file_total = $filedao -> count_all();
    $db_total = $tabledao -> count_all();
    $file_finish = $filedao -> count_finish();
    $db_finish = $tabledao -> count_finish();
    nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_execfile_message', array(
        'file_prc' => ceil($file_finish / $file_total * 100) . '%',
        'db_prc' => ceil($db_finish / $db_total * 100) . '%'
    )), 'action=' . $adminurl . '&step=execfile&execfile=1', array(), '', 5000);
}

function conversion_db($tabledao, $table) {

    if(!file_exists(DISCUZ_ROOT . $table['path'])) {
        writelog('gbk2utf8_table', '[ERROR] execfile-table-not-found: ' . $table['table'] . ' ' . $table['path']);
        cpmsg('nayuan_gbk2utf8:step_dbimport_not_file', '', 'error');
    }
    $sqldump = file_get_contents(DISCUZ_ROOT . $table['path']);
    $sqlquery = splitsql($sqldump);
    unset($sqldump);

    foreach($sqlquery as $sql) {
        if($sql != '') {
            DB::query($sql, 'UNBUFFERED');
            if($sqlerror = DB::error()) {
                writelog('gbk2utf8_table', '[ERROR] execfile-table-sqlerror: ' . $table['table'] . ' ' . $sql . ' ' . $sqlerror);
                cpmsg('database_run_query_invalid', '', 'error', array('sqlerror' => $sql . "<br/>" . $sqlerror));
            }
        }
        unset($sql);
    }
    unset($sqlquery);
    $tabledao -> update($table['id'], array('status' => 1));
}

function conversion_file($filedao, $list) {
    $exclude = array(
        '/uc_server/install/lang.inc.php', '/uc_server/api/dbbak.php', '/uc_client/client.php', '/template/default/common/css_sample.htm', '/template/default/common/sendmail.htm',
        '/source/plugin/wechat/showactivity_setting.inc.php', '/source/module/misc/misc_stat.php', '/source/module/forum/forum_misc.php', '/source/module/home/home_editor.php',
        '/source/language/lang_admincp.php', '/source/language/lang_admincp_searchindex.php', '/source/function/function_core.php', '/source/function/function_misc.php', '/source/class/class_chinese.php',
        '/source/class/helper/helper_seccheck.php', '/source/class/discuz/discuz_upgrade.php', '/source/admincp/admincp_card.php', '/source/admincp/admincp_members.php', '/source/admincp/admincp_plugins.php',
        '/source/admincp/admincp_setting.php', '/source/admincp/admincp_verify.php', '/install/include/install_lang.php', '/api/trade/api_tenpay.php', '/api/db/dbbak.php', '/api/addons/channel.htm',
    );
    $autoexec = array(
        '/uc_server/install/var.inc.php', '/uc_server/data/config.inc.php', '/install/include/install_var.php', '/data/sysdata/cache_mobile.php', '/config/config_global.php',
        '/config/config_global_default.php', '/config/config_ucenter.php', '/config/config_ucenter_default.php',
    );
    $sautoexec = array(
        '/uc_server/data/config.inc.php', '/config/config_global.php', '/config/config_global_default.php', '/config/config_ucenter.php', '/config/config_ucenter_default.php',
    );

    $root = str_replace('\\', '/', DISCUZ_ROOT);
    $confirmdao = C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_confirm');
    foreach ($list as $item) {
        $file = $item['path'] . $item['name'];
        $content = file_get_contents($file);
        $fromencode = mb_detect_encoding($content, array('CP936', 'GBK', 'GB2312', 'UTF-8'), true);
        if(!$fromencode) {
            $filedao -> update($item['id'], array('status' => 9, 'encode' => $fromencode));
        }
        if(preg_match('/^<\?php\s\'\w+\';\s\'\w+\';\s\?><\?php/', $content)) { //魔方加密过的文件，无法转码
            $filedao -> update($item['id'], array('status' => 1, 'encode' => $fromencode));
            $confirmdao -> insert(array(
                'fid' => $item['id'],
                'line' => 1,
                'message' => lang('plugin/nayuan_gbk2utf8', 'step_file_mfenc'),
                'status' => 0,
                'time' => time()
            ));
            continue;
        }

        if($fromencode !== 'UTF-8') {
            if(!preg_match('/SC_(GBK|UTF8)/i', $item['name'])) {
                $content = diconv($content, $fromencode, 'UTF-8');
                replace_file_data($file, $content);
            }else{
                $utf8filename = preg_replace('/SC_(BIG5|GBK)/i', 'SC_UTF8', $item['name']);
                if(!file_exists($item['path'] . $utf8filename)) {
                    $content = diconv($content, $fromencode, 'UTF-8');
                    replace_file_data($item['path'] . $utf8filename, $content);
                    $md5 = md5($item['path'] . $utf8filename);
                    $md5list = $filedao -> exist(array($md5));
                    if(!count($md5list)) {
                        $filedao -> batch_insert(array(array('md5' => $md5, 'path' => $item['path'], 'name' => $utf8filename)));
                    }
                }
            }
        }

        $filedao -> update($item['id'], array('status' => 1, 'encode' => $fromencode));

        $file = '/' . str_replace($root,'', $file);
        if(preg_match('/\/source\/plugin\/nayuan_gbk2utf8\/|data\/plugindata\/|data\/addonmd5\//i', $file)) continue;
        if(in_array($file, $exclude)) continue;

        if(in_array($file, $autoexec)) {
            $utf8 = 'utf-8';
            $content = str_replace(array(
                'SC_GBK',
                'gbk',
                'GBK'
            ), array(
                'SC_UTF8',
                $utf8,
                'UTF-8'
            ), $content);
            if(in_array($file, $sautoexec)) {
                $content = preg_replace(array(
                    '/\'UC_DBCHARSET\'\s*,\s+\'utf-8\'/i',
                    '/\'dbcharset\']\s*=\s*\'utf-8\'/i',
                ), array(
                    '\'UC_DBCHARSET\', \'utf8\'',
                    '\'dbcharset\'] = \'utf8\''
                ), $content);
            }
            replace_file_data(DISCUZ_ROOT . substr($file, 1), $content);
        }else{
            $lines = explode("\n", $content);
            if(!$lines) continue;

            $isupdate = false;
            foreach ($lines as $num => $line) {
                if(preg_match('/[^\w](gbk|gb2312)[^\w]/i', $line)) {
                    if(preg_match('/(==\s*(\'|")(gbk)|^\/\*|^\/\/)/i', trim($line))) continue;

                    if(preg_match('/charset=("|\')?(gbk|gb2312)("|\')?/i', $content)) {
                        $content = str_replace(array(
                            'charset="gb2312"',
                            'charset="gbk"',
                            'charset="GB2312"',
                            'charset="GBK"'
                        ), array(
                            'charset="utf-8"',
                            'charset="utf-8"',
                            'charset="UTF-8"',
                            'charset="UTF-8"'
                        ), $content);
                        $isupdate = true;
                    }else{
                        if($confirmdao -> exist_line($item['id'], $num)) continue;
                        $confirmdao -> insert(array(
                            'fid' => $item['id'],
                            'line' => $num + 1,
                            'message' => trim($line),
                            'status' => 0,
                            'time' => time()
                        ));
                    }
                }
            }

            if($isupdate) {
                replace_file_data(DISCUZ_ROOT . substr($file, 1), $content);
            }
        }
    }
}

function replace_file_data($file, $data) {
    if(file_put_contents($file, $data) === FALSE) {
        $perms = substr(sprintf('%o', @fileperms($file)), -4);
        if(@chmod($file, 0777)) {
            if(file_put_contents($file, $data) === FALSE) {
                writelog('gbk2utf8_file', '[INFO] execfile-file-fail: ' . $file);
            }
            @chmod($file, $perms);
        }
    }
}

function splitsql($sql) {
    $sql = str_replace("\r", "\n", $sql);
    $ret = array();
    $num = 0;
    $queriesarray = explode(";\n", trim($sql));
    unset($sql);
    foreach($queriesarray as $query) {
        $queries = explode("\n", trim($query));
        foreach($queries as $query) {
            $ret[$num] .= $query[0] == "#" ? NULL : $query;
        }
        $num++;
    }
    return($ret);
}

?>