<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_dbbackup.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

loadcache('nayuan_gbk2utf8');
$plugindata = $_G['cache']['nayuan_gbk2utf8'];
if(!$plugindata['backupid']) {
    $plugindata['step'] = 'dbbackup';
    //$plugindata['dbencode'] = nayuan_get('dbencode', 1, 'utf8');
    $plugindata['backupid'] = random(6);
    savecache('nayuan_gbk2utf8', $plugindata);
}

$sizelimit = 10240;
$time = dgmdate(TIMESTAMP);
$dumpcharset = 'utf8';
$tablepre = $_G['config']['db'][1]['tablepre'];
$backupdir = './data/backup_' . $plugindata['backupid'];
if(!is_dir($backupdir)) {
    $plugindata['backup_success'] = 0;
    $plugindata['backup_table'] = '';
    savecache('nayuan_gbk2utf8', $plugindata);

    mkdir($backupdir, 0777);
}

if($plugindata['backup_success']) {
    cpmsg(
        '',
        'action=' . $adminurl . '&step=scanfile',
        'form',
        '',
        lang('plugin/nayuan_gbk2utf8', 'step_dbbackup_success', array('dir' => $backupdir)),
        true,
        'javascript:;'
    );
}else{
    $bktable = $plugindata['backup_table'] ? $plugindata['backup_table'] : '';

    if(submitcheck('dbbackup') && $lock = nayuan_filelock('dbbackup', time() + 604800)) {
        @ignore_user_abort(true);
        @set_time_limit(0);

        $db = & DB::object();
        if($db->version() > '4.1') {
            $dbcharset = $_G['config']['db'][1]['dbcharset'];
            if(!$dbcharset) $dbcharset = $_G['charset'];
            DB::query('SET NAMES %s', array($dbcharset));
        }

        DB::query('SET SQL_QUOTE_SHOW_CREATE=0', 'SILENT');
        $notexportdatatables = array(DB::table('common_admincp_session'), DB::table('common_session'));
        $tables = fetchtablelist($tablepre);
        foreach($tables as $name => $table) {
            if(!preg_match('/^gbk.+$/i', $table['Collation'])) continue;

            $plugindata['backup_table'] = $table['Name'];
            savecache('nayuan_gbk2utf8', $plugindata);

            if(in_array($name, array(DB::table('nayuan_gbk2utf8_file'), DB::table('nayuan_gbk2utf8_confirm'), DB::table('nayuan_gbk2utf8_table')))) continue;

            $existfile = false;
            $volume = 0;
            while(file_exists(DISCUZ_ROOT . $backupdir . '/' . $name . ($volume == 0 ? '' : ('-' . $volume)) . '.sql')) {
                writelog('gbk2utf8_db', '[INFO] dbbackup-exist-'.$name.'-'.$volume);
                $existfile = true;
                if(!C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_table') -> exist($table['Name'], $volume)) {
                    C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_table') -> insert(array(
                        'table' => $table['Name'],
                        'volume' => $volume,
                        'path' => $backupdir . '/' . $table['Name'] . ($volume > 0 ? ('-' . $volume) : '') . '.sql',
                        'status' => 0,
                        'time' => time()
                    ));
                }
                $volume++;
            }
            if($existfile) continue;

            if($table['Name'] == DB::table('ucenter_members')) {
                DB::query("UPDATE %t SET `secques` = ''", array('ucenter_members'));
            }

            nayuandumptable($table['Name'], $dumpcharset, $backupdir, $sizelimit);
        }

        $plugindata['backup_success'] = 1;
        savecache('nayuan_gbk2utf8', $plugindata);
        nayyuan_clear_filelock($lock, 'dbbackup');

        cpmsg(
            '',
            'action=' . $adminurl . '&step=scanfile',
            'form',
            '',
            lang('plugin/nayuan_gbk2utf8', 'step_dbbackup_success', array('dir' => $backupdir)),
            true,
            'javascript:;'
        );

    }else{
        nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_dbbackup_table', array('table' => $bktable)), 'action=' . $adminurl . '&step=dbbackup&dbbackup=1', array(), '', 10000);
    }
}


function nayuandumptable($table, $charset, $backupdir, $sizelimit = 10240) {
    global $db, $_G;
    writelog('gbk2utf8_db', '[INFO] start dbbackup-'.$table . '---' . memory_get_usage());

    $linemax = 100;
    $tablefields = array();
    $query = DB::query("SHOW FULL COLUMNS FROM $table", 'SILENT');
    while($fieldrow = DB::fetch($query)) {
        $tablefields[] = $fieldrow;
    }
    $numfields = count($tablefields);

    $insertdata = array();
    $volume = 0;
    $values = array();
    $sqldump = sqldumptablestruct($table, $charset);
    $rows = $db -> query("SELECT * FROM $table", 'UNBUFFERED');
    writelog('gbk2utf8_db', '[INFO] rows dbbackup-'.$table . '---' . memory_get_usage());
    while($row = $db -> fetch_row($rows)) {

        $comma = $t = '';
        for($i = 0; $i < $numfields; $i++) {
            $t .= $comma;
            if($row[$i] && preg_match('/char|text|blob/i', $tablefields[$i]['Type'])) {
                $data = dunserialize($row[$i]);
                if($data) {
                    $row[$i] = serialize(nayuan_convert_encoding($data, 'UTF-8', 'GBK'));
                    unset($data);
                }else{
                    $row[$i] = diconv($row[$i], 'GBK', 'UTF-8');
                }

                $t .= '0x'.bin2hex($row[$i]);
            }else{
                $t .= '\''.$db->escape_string($row[$i]).'\'';
            }
            $comma = ',';
        }
        $values[] = '(' . $t . ')';
        unset($comma, $t);

        if(count($values) >= $linemax) {
            $sqldump .= "\nINSERT INTO $table VALUES ".implode(',', $values).";";
            unset($values);
            $values = array();

            if(strlen($sqldump) + 500 >= $sizelimit * 1000) {
                writelog('gbk2utf8_db', '[INFO] start dbbackup-'.$table . '---' . memory_get_usage());
                @$fp = fopen($backupdir . '/' . $table . '-' . $volume . '.sql', 'wb');
                @flock($fp, 2);
                if(@!fwrite($fp, $sqldump)) {
                    @fclose($fp);
                    writelog('gbk2utf8_db', '[ERROR] write-fail. dbbackup-'.$table.'-'.$volume);
                    cpmsg('database_export_file_invalid', '', 'error');
                } else {
                    @fclose($fp);
                }
                $insertdata[] = array(
                    'table' => $table,
                    'volume' => $volume,
                    'path' => $backupdir . '/' . $table . ($volume > 0 ? '-' . $volume : '') . '.sql',
                    'status' => 0,
                    'time' => time()
                );

                unset($sqldump);
                $sqldump = '';
                $volume++;
            }
        }
        unset($row);
    }
    DB::free_result($rows);

    if(count($values)) {
        $sqldump .= "\nINSERT INTO $table VALUES ".implode(',', $values).";";
        unset($values);
    }

    if(strlen($sqldump)) {
        @$fp = fopen($backupdir . '/' . $table . '-' . $volume . '.sql', 'wb');
        @flock($fp, 2);
        if(@!fwrite($fp, $sqldump)) {
            @fclose($fp);
            writelog('gbk2utf8_db', '[ERROR] write-fail. dbbackup-'.$table.'-'.$volume);
            cpmsg('database_export_file_invalid', '', 'error');
        } else {
            @fclose($fp);
        }

        $insertdata[] = array(
            'table' => $table,
            'volume' => $volume,
            'path' => $backupdir . '/' . $table . ($volume > 0 ? '-' . $volume : '') . '.sql',
            'status' => 0,
            'time' => time()
        );

        unset($sqldump);
    }

    foreach ($insertdata as $data) {
        if(!C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_table') -> exist($data['table'], $data['volume'])) {
            C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_table') -> insert($data);
        }
    }

    rename($backupdir . '/' . $table . '-0.sql', $backupdir . '/' . $table . '.sql');
}


function fetchtablelist($tablepre = '') {
    global $db;
    $arr = explode('.', $tablepre);
    $dbname = $arr[1] ? $arr[0] : '';
    $tablepre = str_replace('_', '\_', $tablepre);
    $sqladd = $dbname ? " FROM $dbname LIKE '$arr[1]%'" : "LIKE '$tablepre%'";
    $tables = $table = array();
    $query = DB::query("SHOW TABLE STATUS $sqladd");
    while($table = DB::fetch($query)) {
        $table['Name'] = ($dbname ? "$dbname." : '').$table['Name'];
        $tables[$table['Name']] = $table;
    }
    return $tables;
}

function sqldumptablestruct($table, $dumpcharset) {
    global $_G, $db, $excepttables;

    if(in_array($table, $excepttables)) {
        return;
    }

    $createtable = DB::query("SHOW CREATE TABLE $table", 'SILENT');

    if(!DB::error()) {
        $tabledump = "DROP TABLE IF EXISTS $table;\n";
    } else {
        return '';
    }

    $create = $db->fetch_row($createtable);

    if(strpos($table, '.') !== FALSE) {
        $tablename = substr($table, strpos($table, '.') + 1);
        $create[1] = str_replace("CREATE TABLE $tablename", 'CREATE TABLE '.$table, $create[1]);
    }
    $tabledump .= $create[1];

    if($db->version() > '4.1') {
        $tabledump = preg_replace("/(DEFAULT)*\s*CHARSET=.+/", "DEFAULT CHARSET=".$dumpcharset, $tabledump);
    }

    $tabledump .= ";\n\n";
    return $tabledump;
}

function nayuan_convert_encoding($data, $to_encoding, $from_encoding) {
    switch (gettype($data)) {
        case 'array':
            foreach($data as $_k => $_v) {
                $data[$_k] = nayuan_convert_encoding($_v, $to_encoding, $from_encoding);
            }
            break;
        case 'string':
            $data = diconv($data, $from_encoding, $to_encoding);
            break;
    }
    return $data;
}

?>