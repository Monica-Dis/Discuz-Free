<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_success.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

loadcache('nayuan_gbk2utf8');
$plugindata = $_G['cache']['nayuan_gbk2utf8'];
$plugindata['step'] = 'success';
savecache('nayuan_gbk2utf8', $plugindata);

cpmsg('nayuan_gbk2utf8:step_success_message', '', 'succeed', array('dir' => $backupdir));

?>