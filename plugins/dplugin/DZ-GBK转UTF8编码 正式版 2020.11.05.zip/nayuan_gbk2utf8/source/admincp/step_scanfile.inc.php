<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_scanfile.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

if(submitcheck('scanfile')) {

    if($fp = nayuan_filelock('scanfile', time() + 3600)) {
        @set_time_limit(0);

        loadcache('nayuan_gbk2utf8');
        $_options = $_G['cache']['nayuan_gbk2utf8'];
        if(!$_options['scanfile']) {
            $queue = array(DISCUZ_ROOT);
            while($dir = array_pop($queue)) {
                nayuan_scandir(C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8'), $dir, $queue);
            }

            $_options['scanfile'] = 1;
            savecache('nayuan_gbk2utf8', $_options);
        }

        nayyuan_clear_filelock($fp, 'scanfile');

        cpmsg(
            '',
            'action=' . $adminurl . '&step=execfile',
            'form',
            '',
            lang('plugin/nayuan_gbk2utf8', 'step_scanfile_success', array('prc' => '0%')),
            true,
            'javascript:;'
        );
    }

}

nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_scanfile_message'), 'action=' . $adminurl . '&step=scanfile&scanfile=1');


function nayuan_scandir($dao, $path, &$queue) {
    $path = str_replace('\\', '/', $path);
    if(preg_match("/data\/(attachment|avatar|backup_\w+|ipdata|log|download)\/$/i", $path)) return;
    if(preg_match("/uc_server\/data\/(avatar|backup|logs|tmp)\/$/i", $path)) return;

    $md5list = $savelist = array();
    $files = new FilesystemIterator($path);
    foreach ($files as $file) {
        $filename = $file -> getFilename();
        $filepath = $path . $filename;
        if ($file -> isDir()) {
            $filepath = $filepath . '/';
            $queue[] = $filepath;
        } else {
            if(!preg_match('/\.(php|html?|xml|css|js|tpl)$/i', $filename)) continue;

            $md5 = md5($filepath);
            $md5list[] = $md5;
            $savelist[$md5] = array('md5' => $md5, 'path' => $path, 'name' => $filename);
        }
    }
    unset($files);

    if(count($md5list)) {
        $md5list = $dao -> exist($md5list);
        foreach (array_keys($md5list) as $md5) {
            unset($savelist[$md5]);
        }

        if(count($savelist)) {
            $dao -> batch_insert($savelist);
        }
    }
    unset($md5list);
    unset($savelist);

}

?>