<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_tips.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

cpmsg(
    '',
    'action=' . $adminurl . '&step=dbbackup',
    'form',
    '',
    lang('plugin/nayuan_gbk2utf8', 'step_tips_message'),
    true,
    'javascript:;'
);

?>