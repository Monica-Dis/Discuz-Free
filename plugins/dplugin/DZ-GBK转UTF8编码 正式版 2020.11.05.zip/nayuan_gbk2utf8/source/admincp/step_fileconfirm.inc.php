<?php

/**
 *      Dplugin插件定制平台 (http://t.cn/Aiux1Qh0).
 *      nayuan_gbk2utf8.
 *      step_fileconfirm.inc.php.
 *      Author nayuan.
 *      Time 2020-11-05 08:23:34.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(!isfounder()) cpmsg('noaccess_isfounder', '', 'error');

loadcache('nayuan_gbk2utf8');
$plugindata = $_G['cache']['nayuan_gbk2utf8'];
$plugindata['step'] = 'fileconfirm';
savecache('nayuan_gbk2utf8', $plugindata);

if(submitcheck('confirmsubmit')) {
    $ids = nayuan_get('delete', 3);
    if($ids) {
        foreach ($ids as $id) {
            $file = C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_confirm') -> fetch_file($id);
            print_r($file);
            if(!$file) continue;
            $content = file_get_contents($file['path'] . $file['name']);
            if(!$content) continue;

            $lines = explode("\n", $content);
            if(!$lines) continue;
            foreach ($lines as $num => $line) {
                if(($num + 1) != $file['line']) continue;
                $lines[$num] = str_replace(array(
                    'SC_GBK', 'gbk', 'GBK'
                ), array(
                    'SC_UTF8', 'utf-8', 'UTF-8'
                ), $line);
            }
            file_put_contents($file['path'] . $file['name'], implode("\n", $lines));
            C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_confirm') -> update($file['id'], array('status' => 1));
            unset($file, $content, $lines);
        }
    }

    nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_message'), 'action=' . $adminurl . '&step=success', array(), '', 500);
}

$list  = C::t('#nayuan_gbk2utf8#nayuan_gbk2utf8_confirm') -> fetch_un_exec_list();
if($list) {
    showformheader("$adminurl&step=fileconfirm", '', 'confirm_form');
    showtableheader(lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_title'));

    showsubtitle(array(
        '',
        lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_header_file'),
        lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_header_line'),
        lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_header_message'),
    ), 'header', array(
        'class="td25"',
        '',
        'class="td25 center"',
        ''
    ));

    foreach ($list as $item) {
        if(strpos($item['path'], '/data/threadcache/')) continue;

        showtablerow(
            '',
            array(
                'class="td25"',
                '',
                'class="td25 center"',
                ''
            ),
            array(
                '<input type="checkbox" class="checkbox" name="delete[]" value="'.$item['id'].'" />',
                $item['path'] . $item['name'],
                $item['line'],
                preg_replace('/(gbk|gb2312)/i','<em style="color: red; font-weight: bold">$1</em>', dhtmlspecialchars($item['message']))
            )
        );
    }

    showsubmit('confirmsubmit', lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_submit'), 'select_all', lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_tips'), '');
    showtablefooter();/*Dism·taobao·com*/
    showformfooter();/*Dism_taobao_com*/

}else{
    nayuan_admin_loading(lang('plugin/nayuan_gbk2utf8', 'step_fileconfirm_message'), 'action=' . $adminurl . '&step=success', array(), '', 500);
}

?>