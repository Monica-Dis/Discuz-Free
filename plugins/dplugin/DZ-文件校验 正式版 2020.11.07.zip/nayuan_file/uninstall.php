<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      uninstall.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_file`;

EOF;

runquery($sql);
C::t('common_syscache') -> delete('nayuan_file');

$_safe_file_lock = DISCUZ_ROOT . 'data/nayuan_file.lock';
if(file_exists($_safe_file_lock)) {
    @unlink($_safe_file_lock);
}

$finish = TRUE; /*dism·taobao·com*/

?>