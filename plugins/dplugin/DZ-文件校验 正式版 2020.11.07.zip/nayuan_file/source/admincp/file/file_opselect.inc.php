<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_opselect.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$_safecode = $cache_data['safecode'];
$latest_file_nums = C::t('#nayuan_file#nayuan_safefile') -> count_latest_file();
$invalid_file_nums = C::t('#nayuan_file#nayuan_safefile') -> count_invalid_file($_safecode);
$no_backup_file_nums = C::t('#nayuan_file#nayuan_safefile') -> count_no_backup_files($_safecode);

if($invalid_file_nums > 0) {
    if($latest_file_nums == $invalid_file_nums) {
        showtips(lang('plugin/nayuan_file', 'file_opselect_pwd_error', array('error' => $invalid_file_nums, 'total' => $latest_file_nums, 'hide' => '')));
    }else{
        showtips(lang('plugin/nayuan_file', 'file_opselect_pwd_error', array('error' => $invalid_file_nums, 'total' => $latest_file_nums, 'hide' => 'display:none')));
    }
}

showformheader($adminurl);
echo '<input type="hidden" id="post_op" name="op" value="" />';
showtableheader(lang('plugin/nayuan_file', 'file_opselect_table_title'));

showtablerow('', array(
    'class="td25"',
    'class="td23"',
    'style="width:350px"',
    ''
), array(
    '<img src="'.$_G['siteurl'].'source/plugin/nayuan_file/static/images/safe-check.png">',
    lang('plugin/nayuan_file', 'file_opselect_check_title'),
    lang('plugin/nayuan_file', 'file_opselect_check_title_desc', array('time' => dgmdate($cache_data['file_check_data']['time']))),
    $latest_file_nums == 0 ? '' : '<input type="button" class="btn" onclick="submitcheck(\'list\')" value="'.lang('plugin/nayuan_file', 'file_opselect_go_btn').'" />'
));

showtablerow('', array(
    'class="td25"',
    'class="td23"',
    'style="width:350px"',
    ''
), array(
    '<img src="'.$_G['siteurl'].'source/plugin/nayuan_file/static/images/safe-import.png">',
    lang('plugin/nayuan_file', 'file_opselect_import_title'),
    lang('plugin/nayuan_file', 'file_opselect_import_title_desc', array('time' => dgmdate($cache_data['file_check_data']['time']))),
    '<input type="button" class="btn" onclick="submitcheck(\'import\')" value="'.lang('plugin/nayuan_file', 'file_opselect_go_btn').'" />'
));

showtablerow('', array(
    'class="td25"',
    'class="td23"',
    'style="width:350px"',
    ''
), array(
    '<img src="'.$_G['siteurl'].'source/plugin/nayuan_file/static/images/safe-export.png">',
    lang('plugin/nayuan_file', 'file_opselect_export_title'),
    lang('plugin/nayuan_file', 'file_opselect_export_title_desc', array('nums' => $no_backup_file_nums)),
    $latest_file_nums == 0 || $invalid_file_nums > 0 ? '' : '<input type="button" class="btn" onclick="submitcheck(\'export\')" value="'.lang('plugin/nayuan_file', 'file_opselect_go_btn').'" />'
));

showtablefooter(); /*Dism·taobao·com*/
showtablefooter(); /*Dism·taobao·com*/

print <<<EOF
    
<script type="text/javascript">
    function submitcheck(name) {
        $('post_op').value = name;
        $('cpform').submit();
    }
</script>

EOF;

?>