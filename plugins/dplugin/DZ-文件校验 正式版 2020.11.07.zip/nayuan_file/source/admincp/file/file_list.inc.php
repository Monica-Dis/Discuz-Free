<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_list.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

///// 查询参数
$q_path = nayuan_get('q_path', 1, '');
$q_name = nayuan_get('q_name', 1, '');
$q_ext = nayuan_get('q_ext', 1, '');
$q_status = nayuan_get('q_status');

showtips(lang('plugin/nayuan_file', 'file_list_tips'));
///////////////////////////////////// diff form
showformheader("$adminurl&op=diff", '', 'diff_form');
echo '<input type="hidden" id="diff_id" name="file_id" />';
showformfooter(); /*Dism_taobao_com*/

///////////////////////////////////// check form
showformheader("$adminurl&op=check", '', 'check_form');
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/

///////////////////////////////////// pass form
showformheader("$adminurl&op=pass", '', 'pass_form');
echo '<input type="hidden" id="check_type" name="check_type" />';
echo '<input type="hidden" id="source_name" name="source" />';
echo '<input type="hidden" id="pass_file_id" name="file_id" />';
showhiddenfields(array(
    'q_path' => $q_path,
    'q_name' => $q_name,
    'q_ext' => $q_ext,
    'q_status' => $q_status
));
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/


////////////////////////////////搜索
$status_show_options = nayuan_show_options(lang('plugin/nayuan_file', 'file_status_zh_options'), $q_status);
$ext_show_options = array();
$ext_show_options[] = '<option '.($q_ext == 'php' ? 'selected' : '').' value="php">PHP</option>';
$ext_show_options[] = '<option '.($q_ext == 'html' ? 'selected' : '').' value="html">HTML</option>';
$ext_show_options[] = '<option '.($q_ext == 'css' ? 'selected' : '').' value="css">CSS</option>';
$ext_show_options[] = '<option '.($q_ext == 'js' ? 'selected' : '').' value="js">JS</option>';
$ext_show_options = implode('', $ext_show_options);
showformheader("$adminurl&op=list", '', 'search_form');
showtableheader('search');
showtablerow('', array(
    'width="50"', 'width="150"',
    'width="50"', 'width="100"',
    'width="50"', 'width="100"',
    'width="50"', 'width="100"',
    ''
    ),
    array(
        lang('plugin/nayuan_file', 'file_search_path'), '<input type="text" name="q_path" value="'.$q_path.'" class="txt" />',
        lang('plugin/nayuan_file', 'file_search_name'), '<input type="text" name="q_name" value="'.$q_name.'" class="txt" />',
        lang('plugin/nayuan_file', 'file_search_ext'), "<select name=\"q_ext\"><option value=\"\">".cplang('all')."</option>$ext_show_options</select>",
        lang('plugin/nayuan_file', 'file_search_status'), "<select name=\"q_status\"><option value=\"\">".cplang('all')."</option>$status_show_options</select>",
        "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"$lang[search]\" />",
    )
);
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/


$exist_lock = file_exists(DISCUZ_ROOT . 'data/nayuan_file.lock');
//// 列表展示
if($cache_data['file_check_data']) {
    $_before_check_time = lang('plugin/nayuan_file', 'file_before_check_time', array('time' => $exist_lock ? lang('plugin/nayuan_file', 'safe_dialog_checking_title') : dgmdate($cache_data['file_check_data']['time'])));
}else{
    $_before_check_time = lang('plugin/nayuan_file', 'file_before_check_no');
}

$_table_header_title = $_before_check_time;
if(!$exist_lock) {
    $_table_header_title .= '&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" class="btn" onclick="start_check_window()" value="'.lang('plugin/nayuan_file', 'file_search_start_check').'" />';
}
$_table_header_title .= '&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" class="btn" onclick="refresh_list_page()" value="'.lang('plugin/nayuan_file', 'safe_dialog_refresh_page').'" />';

showtableheader($_table_header_title);

showsubtitle(array(
    '',
    lang('plugin/nayuan_file', 'file_table_header_file'),
    lang('plugin/nayuan_file', 'file_table_header_size'),
    lang('plugin/nayuan_file', 'file_table_header_time'),
    lang('plugin/nayuan_file', 'file_table_header_status'),
    lang('plugin/nayuan_file', 'file_table_header_diff'),
), 'header', array(
    'class="td25"',
    '',
    'class="td23" style="text-align:right"',
    'class="center" style="width: 110px"',
    'class="td23 center"',
    'class="td25 center"',
));
echo '</tbody><tbody>';

$_data_list = C::t('#nayuan_file#nayuan_safefile') -> fetch_error_list($q_path, $q_name, $q_ext, $q_status, $cache_data['safecode']);
if(count($_data_list)) {

    parse_str(lang('plugin/nayuan_file', 'file_status_options'), $_status_cache);
    $_file_data = array();
    foreach ($_data_list as $_file) {
        $_source = $_file['source'];
        $_status = $_file['status'];
        if(!$_file_data[$_source]) {
            $_file_data[$_source] = array(
                'unknown_nums' => 0,
                'changed_nums' => 0,
                'lost_nums' => 0,
                'files' => array()
            );
        }
        $_file_data[$_source]['files'][] = $_file;
        if($_status == 51) {
            $_file_data[$_source]['unknown_nums']++;
        }else if($_status == 52) {
            $_file_data[$_source]['changed_nums']++;
        }else if($_status == 53) {
            $_file_data[$_source]['lost_nums']++;
        }
    }

    foreach ($_file_data as $_source => $_item) {
        if($_source == 'discuz') {
            $_source_title = lang('plugin/nayuan_file', 'file_source_discuz');
        }else if(preg_match('/^(\w+):(\w+)$/i', $_source, $_matchs)){
            if($_matchs[1] == 'template') {
                $_source_title = lang('plugin/nayuan_file', 'file_source_template', array(
                    'name' => C::t('#nayuan_file#nayuan_safefile') -> get_tempate_title($_matchs[2])
                ));
            }else if($_matchs[1] == 'plugin') {
                $_name = C::t('#nayuan_file#nayuan_safefile') -> get_plugin_title($_matchs[2]);
                if(!$_name) $_name = $_matchs[2];
                $_source_title = lang('plugin/nayuan_file', 'file_source_plugin', array(
                    'name' => $_name
                ));
            }else if($_matchs[1] == 'pack'){
                $_source_title = lang('plugin/nayuan_file', 'file_source_pack', array(
                    'name' => $_source
                ));
            }else{
                $_source_title = lang('plugin/nayuan_file', 'file_source_other', array(
                    'name' => $_source
                ));
            }
        }

        echo '</tbody><tbody>';
        showtablerow('', array(
            'class="td25" onclick="toggle_group(\'group_'.$_source.'\', $(\'a_group_'.$_source.'\'))"',
            '',
            'colspan="4" style="text-align:right"'
        ), array(
            '<a href="javascript:;" id="a_group_'.$_source.'">[+]</a>',
            lang('plugin/nayuan_file', 'file_check_result_sum', array("unknown_nums" => $_item['unknown_nums'], "changed_nums" => $_item['changed_nums'], "lost_nums" => $_item['lost_nums'], 'title' => $_source_title)),
            $exist_lock ? '' : ('<input class="btn" type="button" onclick="file_check_pass(\''.$_source.'\', \''.$_source_title.'\')" value="'.lang('plugin/nayuan_file', 'file_check_btn_ok').'" />&nbsp;&nbsp;&nbsp;&nbsp;<input class="btn" type="button" onclick="file_check_rollback(\''.$_source.'\', \''.$_source_title.'\')" value="' .lang('plugin/nayuan_file', 'file_check_btn_rollback').'" />')
        ));

        echo '</tbody><tbody style="display: none; border-bottom: 2px solid #0e99cc;" id="group_'.$_source.'">';
        foreach ($_item['files'] as $_file) {
            showtablerow('id="file_'.$_file['id'].'"', array(
                'class="td25"',
                $_file['diff'] ? 'style="color:red"' : '',
                'class="td25" style="text-align:right"',
                'class="center" style="width: 110px"',
                'class="td25 center"',
                'class="td25" style="text-align:right"'
            ), array(
                '',
                $_file['path'] . $_file['name'] . ($_file['diff'] ? '<span style="font-size: 10px; margin-left: 10px; color: orange">'.lang('plugin/nayuan_file', 'file_list_diff_tips').'</span>' : ''),
                nayuan_format_filesize($_file['size']),
                dgmdate($_file['time']),
                '<em class="'.$_status_cache[$_file['status']].'"></em>',
                $exist_lock ? '' : ('<a href="javascript:show_diff_window(\'' . $_file['id'] . '\');">'.lang('plugin/nayuan_file', 'file_diff_btn').'</a>')
            ));
        }
    }

}else{
    showtablerow('', array('class="center" colspan="6"'), array(lang('plugin/nayuan_file', 'safe_check_not_data')));
}

showtablefooter(); /*Dism·taobao·com*/



$_file_table_title = lang('plugin/nayuan_file', 'file_table_title');
$_file_checked_success = lang('plugin/nayuan_file', 'file_checked_success');
$_file_checked_error = lang('plugin/nayuan_file', 'file_checked_error');
$_file_checking_tips = lang('plugin/nayuan_file', 'file_checking_tips');
$_file_search_start_check = lang('plugin/nayuan_file', 'file_search_start_check');
$_file_list_check_pass_tips = lang('plugin/nayuan_file', 'file_list_check_pass_tips');
$_file_list_pass_loading_message = lang('plugin/nayuan_file', 'file_list_pass_loading_message');
$_file_list_rollback_loading_message = lang('plugin/nayuan_file', 'file_list_rollback_loading_message');
$_file_list_check_rollback_tips = lang('plugin/nayuan_file', 'file_list_check_rollback_tips');
print <<<EOF
<div id="ajax_result_data" style="display: none"></div>
<style type="text/css">
    #fwin_dialog_submit { margin-right: 10px; }
    
</style>
<script type="text/javascript">
    
    function show_loading(title, message) {
        /////显示检测窗口
        var menuid = 'fwin_safe_file_check_window';
        var menuObj = document.createElement('div');
	    menuObj.style.display = 'none';
	    menuObj.className = 'fwinmask';
	    menuObj.id = menuid;
	    $('append_parent').appendChild(menuObj);
	    var s = '<table cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c"><h3 class="flb"><em>' + title + '</em></h3>';
	    s += '<div class="pbg" id="processid" style="margin: 20px 30px; width: 500px;"><img src="/static/image/admincp/ajax_loader.gif" style="width: 500px; height: 20px;" /></div>';
	    s += '<div style="margin:0 30px 30px; width: 500px;"><b>' + message + '</b></div>';
	    s += '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
	    menuObj.innerHTML = s;
        showMenu({'mtype':'safecheck','menuid':menuid,'duration':3,'pos':'00','zindex':JSMENU['zIndex']['dialog'],'cache':0,'cover':1});
    }
    
    function start_check_window() {
        show_loading('$_file_search_start_check', '$_file_checking_tips')
        file_check();
    }
    
    function file_check() {
        /////// 开始校验文件
        ajaxpost('check_form', 'ajax_result_data', '', '', '', function() {
            hideMenu('fwin_safe_file_check_window', 'safecheck');
            var status = document.getElementById('ajax_result_data').innerText;
            if(status === '1') {
                showDialog('$_file_checked_success', 'right', '$_file_table_title', function() {
                    location.reload();
                });
            }else if(status === '2') {
                setInterval(file_check, 5000); //每5秒检测一次
            }else if(/^error:.+$/.test(status)){
                showDialog(status.replace("error:", ''), 'alert', '$_file_table_title', function() {
                    location.reload();
                });
            }else{
                showDialog('$_file_checked_error', 'alert', '$_file_table_title', function() {
                    location.reload();
                });
            }
        });
    }
    
    if (typeof disallowfloat == 'undefined' || disallowfloat === null) {
        var disallowfloat = '';
    }
    function show_diff_window(id) {
        $('diff_id').value = id;
        showWindow('diff_win', 'diff_form', 'post', 0)
    }
    
    function file_check_pass(source, title, id = '') {
        showDialog('$_file_list_check_pass_tips', 'confirm', title, function() {
            $('check_type').value = 'pass';
            $('source_name').value = source;
            $('pass_file_id').value = id;
            show_loading(title, '$_file_list_pass_loading_message');
            ajaxpost('pass_form', 'ajax_result_data', '', '', '', function() {
                hideMenu('fwin_safe_file_check_window', 'safecheck');
                var status = document.getElementById('ajax_result_data').innerText;
                if(status === '1') {
                    if(id) {
                        $('file_' + id).parentNode.removeChild($('file_' + id));
                        hideWindow('diff_win');
                    }else{
                        location.reload();                        
                    }
                }else{
                    showDialog('$_file_checked_error', 'alert', '$_file_table_title', function() {
                        if(!id) location.reload();
                    });
                }
            });
        });
    }
    
    function file_check_rollback(source, title) {
        showDialog('$_file_list_check_rollback_tips', 'confirm', title, function() {
            $('check_type').value = 'rollback';
            $('source_name').value = source;
            show_loading(title, '$_file_list_rollback_loading_message');
            ajaxpost('pass_form', 'ajax_result_data', '', '', '', function() {
                hideMenu('fwin_safe_file_check_window', 'safecheck');
                var status = document.getElementById('ajax_result_data').innerText;
                if(status === '1') {
                    location.reload();
                }else{
                    showDialog('$_file_checked_error', 'alert', '$_file_table_title', function() {
                        location.reload();
                    });
                }
            });
        });
    }
    
    function refresh_list_page() {
        location.reload();
    }
    
</script>
EOF;

?>