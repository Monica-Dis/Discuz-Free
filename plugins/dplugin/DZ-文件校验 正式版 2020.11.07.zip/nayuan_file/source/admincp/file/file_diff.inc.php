<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_diff.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_file/source/class/nayuansafediff.class.php';
if(!submitcheck("file_id")) {
    exit('Access Denied');
}
$_id = nayuan_get('file_id', 1);

$_file_data = C::t('#nayuan_file#nayuan_safefile') -> fetch($_id);
$_content = gzinflate(base64_decode($_file_data['content']));

include template('common/header_ajax');

$file_diff_pass = lang('plugin/nayuan_file', 'file_diff_pass');
if(preg_match('/(jpg|jpeg|png|gif|bmp)$/i', $_file_data['name'])) {
    if($_file_data['status'] == '51') {
        $diffdata = '<table style="min-width: 300px;max-width: 1000px;"><tr><th>'.lang('plugin/nayuan_file', 'file_diff_new').'</th></tr><tr><td><img src="' . $_file_data['path'] . $_file_data['name'] .'" style="max-width: 200px" /></td></tr></table>';
    }else if($_file_data['status'] == '52') {
        $diffdata = '<table style="min-width: 300px;max-width: 1000px;"><tr><th>'.lang('plugin/nayuan_file', 'file_diff_left').'</th><th>'.lang('plugin/nayuan_file', 'file_diff_right').'</th></tr><tr><td><img src="data:image/png;base64,'.base64_encode($_content).'" style="max-width: 200px" /></td><td><img src="' . $_file_data['path'] . $_file_data['name'] .'" style="max-width: 200px" /></td></tr></table>';
    }else if($_file_data['status'] == '53'){
        $diffdata = '<table style="min-width: 300px;max-width: 1000px;"><tr><th>'.lang('plugin/nayuan_file', 'file_diff_del').'</th></tr><tr><td><img src="data:image/png;base64,'.base64_encode($_content).'" style="max-width: 200px" /></td></tr></table>';
    }
}else{
    $_file_path = DISCUZ_ROOT . substr($_file_data['path'], 1) . $_file_data['name'];
    $fp = @fopen($_file_path, "r");
    $current_content = @fread($fp, filesize($_file_path));
    @fclose($fp);

    if($_file_data['status'] == '51') {
        $diffdata = nayuansafediff::toTable(nayuansafediff::compare('', $current_content), '', array(
            51,
            lang('plugin/nayuan_file', 'file_diff_new'),
        ));
    }else if($_file_data['status'] == '52') {
        $diffdata = nayuansafediff::toTable(nayuansafediff::compare($_content, $current_content), '', array(
            52,
            lang('plugin/nayuan_file', 'file_diff_left'),
            lang('plugin/nayuan_file', 'file_diff_right'),
        ));
    }else if($_file_data['status'] == '53'){
        $diffdata = nayuansafediff::toTable(nayuansafediff::compare($_content, ''), '', array(
            53,
            lang('plugin/nayuan_file', 'file_diff_del'),
        ));
    }
}

print <<<EOF

<div class="tm_c">
    <h3 class="flb">
        <em id="return_setnav">$_file_data[path]$_file_data[name]</em>
        <span><a href="javascript:;" class="flbc" onclick="hideWindow('diff_win')" title="{lang[close]}">{lang[close]}</a></span>
    </h3>
    <div class="code_diff_list">$diffdata</div>
    <p class="o pns">
        <input type="button" onclick="file_check_pass('$_file_data[source]', '$_file_data[path]$_file_data[name]', '$_file_data[id]')" name="funcsubmit_btn" class="btn" value="$file_diff_pass">
    </p>
</div>
<style type="text/css">
    .code_diff_list {
        min-height: 50px;
        max-height: 450px;
        min-width: 100px;
        max-width: 1000px;
        overflow: auto;
        border-top: 1px solid #CCC;
        padding: 10px 5px;
    }
    .code_diff_list .diff th {
        font-weight: bold;
        padding: 10px 0;
    }
    .code_diff_list .diff td{
      vertical-align : top;
      white-space    : pre-wrap;
      font-family    : monospace;
    }
    .code_diff_list .diff .content {
        overflow: auto;
        width: 100%;
    }
    .code_diff_list .diffInserted {
        background: rgba(0, 255, 0, 0.5);
        border: 1px solid rgba(0, 255, 0, 1);
    }
    .code_diff_list .diffDeleted {
        background: rgba(255, 0, 0, 0.5);
        border: 1px solid rgba(255, 0, 0, 1);
    }
    .code_diff_list .diffBlank {
        background: rgba(0, 0, 0, .1);
        border: 1px solid rgba(0, 0, 0, .2);
    }
    .code_diff_list .rownum {
        width: 30px;
        text-align: center;
    }
</style>

EOF;

include template('common/footer_ajax');
exit;

?>