<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_export.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('step') && nayuan_get('step') == 1) {
    cpmsg('nayuan_file:file_export_loading', 'action=' . $adminurl . '&op=export&step=2', 'loadingform');
}else if(submitcheck('step') && nayuan_get('step') == 2) {
    $_data_file = DISCUZ_ROOT . 'data/backup_safe_file_' . dgmdate(time(), 'YmdHi') . '_' . random(5) . '.data';

    $_safe_file_lock = DISCUZ_ROOT . 'data/nayuan_file.lock';
    if(!file_exists($_safe_file_lock)) {
        if($fp = @fopen($_safe_file_lock, 'w')) {
            @flock($fp, LOCK_EX);
            @fwrite($fp, 'export');

            $_file_list = C::t('#nayuan_file#nayuan_safefile') -> fetch_latest_for_export($cache_data['safecode']);

            $file = @fopen($_data_file, "w");
            foreach ($_file_list as $_item) {
                @fwrite($file, "$_item[fid]|$_item[md5]|$_item[path]|$_item[name]|$_item[size]|$_item[content]|$_item[source]|$_item[time]\n");
            }
            @fclose($file);

            C::t('#nayuan_file#nayuan_safefile') -> update_latest_export_status($cache_data['safecode']);

            @flock($fp, LOCK_UN);
            @fclose($fp);
            @unlink($_safe_file_lock);

            cpmsg('nayuan_file:file_export_success', '', 'succeed', array('path' => str_replace(DISCUZ_ROOT, '', $_data_file)));
        }else{
            cpmsg('nayuan_file:file_exec_lock', 'action=' . $adminurl, 'error');
        }
    }else{
        cpmsg('nayuan_file:file_exec_lock', 'action=' . $adminurl, 'error');
    }

}else{
    cpmsg('nayuan_file:file_export_tips', 'action=' . $adminurl . '&op=export&step=1', 'form', array(
        'version' => DISCUZ_VERSION
    ));
}
//From: d'.'is'.'m.ta'.'obao.com
?>