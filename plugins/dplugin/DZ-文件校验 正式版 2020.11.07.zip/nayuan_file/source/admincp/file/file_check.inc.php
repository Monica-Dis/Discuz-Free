<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_check.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include template('common/header_ajax');
$_safe_file_lock = DISCUZ_ROOT . 'data/nayuan_file.lock';
if(!file_exists($_safe_file_lock)) {

    if($fp = @fopen($_safe_file_lock, 'w')) {
        @flock($fp, LOCK_EX);
        @fwrite($fp, 'check');

        @set_time_limit(0);
        //// 数据库中所有文件的最新版本
        $_list = C::t('#nayuan_file#nayuan_safefile') -> fetch_latest_list();
        $_current_file_cache = array();
        foreach ($_list as $_item) {
            $_current_file_cache[$_item['fid']] = $_item;
        }
        //// pack应用文件列表
        $_addonmd5_cache = getpluginfilecache();
        ////////////////////////////////////////// check discuz file
        $_excludes = array(
            DISCUZ_ROOT . 'data',
            DISCUZ_ROOT . 'uc_server/data',
            DISCUZ_ROOT . 'uc_server/data',
        );

        $dir_queue = array();
        array_push($dir_queue, DISCUZ_ROOT);
        while(($_dir = array_pop($dir_queue))) {
            checkfiles($_dir, $_excludes, $_addonmd5_cache);
        }

        foreach ($_current_file_cache as $_fid => $_item) {
            C::t('#nayuan_file#nayuan_safefile') -> update($_item['id'], array('status' => 53)); //tag
        }

        @flock($fp, LOCK_UN);
        @fclose($fp);
        @unlink($_safe_file_lock);

        if(!$cache_data['file_check_data']) {
            $cache_data['file_check_data'] = array();
        }
        $cache_data['file_check_data']['time'] = time();
        savecache('nayuan_file', serialize($cache_data));

        echo 1;
    }else{
        echo 'error:' . lang('plugin/nayuan_file', 'file_exec_lock');
    }

}else{
    echo 'error:' . lang('plugin/nayuan_file', 'file_exec_lock');
}
include template('common/footer_ajax');
exit;

function getpluginfilecache() {
    require_once libfile('class/xml');
    $result = array();
    $dir = @opendir(DISCUZ_ROOT . 'data/addonmd5');
    while($entry = @readdir($dir)) {
        if(!preg_match('/^(\w+)\.(template|plugin|pack)\.xml$/i', $entry, $matchs)) continue;
        $xml = implode('', @file(DISCUZ_ROOT.'./data/addonmd5/'.$entry));
        $array = xml2array($xml);
        $array = $array['Data'];
        foreach ($array as $path => $md5) {
            if($matchs[2] == 'template') {
                $path = '/template/' . $matchs[1] . $path;
            }else if($matchs[2] == 'plugin') {
                $path = '/source/plugin/' . $matchs[1] . $path;
            }
            $result[$path] = $matchs[2] . ':' . $matchs[1];
        }
    }
    @closedir($dir);
    return $result;
}

function checkfiles($currentdir, $excludes, $_addonmd5_cache) {
    global $_current_file_cache, $dir_queue, $cache_data;
    if(preg_match('/\/source\/plugin\/(alj114\/images|aljbd\/js\/editor\/attached|aljbd\/images|xigua_hb\/cache|xigua_hb\/tmp|xigua_hb\/pics|xigua_tieba\/cache)/i', $currentdir)) return;
    $dir = @opendir($currentdir);
    while($entry = @readdir($dir)) {
        if($entry == '.' || $entry == '..') continue;

        $file = $currentdir . $entry;
        if(in_array($file, $excludes)) continue;
        if(is_dir($file)) {
            array_push($dir_queue, $file . '/');
            continue;
        }
        if(!preg_match('/\.(php|htm|html|js|css)$/i', $file)) continue;

        $path = '/' . str_replace(DISCUZ_ROOT, '', $currentdir);
        $fid = md5($path . $entry);
        $md5 = md5_file($file);

        $cache = $_current_file_cache[$fid];
        if($cache) {
            unset($_current_file_cache[$fid]);
            if($md5 != $cache['md5']) {
                C::t('#nayuan_file#nayuan_safefile') -> update($cache['id'], array('status' => 52)); //tag
            }
            continue;
        }

        $mtime = filemtime($file);
        $size = filesize($file);

        $fp = @fopen($file, "r");
        $content = @fread($fp, $size);
        @fclose($fp);
        $content = base64_encode(gzdeflate($content));
        if($size > 1048576) { //大于1M不存
            $content = '';
        }

        $source = $_addonmd5_cache[$path . $entry];
        if(!$source) {
            if(preg_match('/^\/source\/plugin\/(\w+)\//i', $path, $_matchs)) {
                $source = 'plugin:' . $_matchs[1];
            }else if(preg_match('/^\/template\/(\w+)\//i', $path, $_matchs)) {
                $source = 'template:' . $_matchs[1];
            }else{
                $source = 'discuz';
            }
        }

        //保存异常数据
        C::t('#nayuan_file#nayuan_safefile') -> insert(array(
            'id' => md5($fid . $md5 . $content . $mtime . $cache_data['safecode']),
            'fid' => $fid,
            'md5' => $md5,
            'path' => $path,
            'name' => $entry,
            'size' => $size,
            'content' => $content,
            'source' => $source,
            'status' => 51,
            'export' => 0,
            'time' => $mtime
        ), false, true);
    }

    @closedir($dir);
}
//From: d'.'is'.'m.ta'.'obao.com
?>