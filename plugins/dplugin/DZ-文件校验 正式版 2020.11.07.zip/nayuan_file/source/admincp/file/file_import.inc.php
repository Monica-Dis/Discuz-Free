<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_import.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('step') && nayuan_get('step') == 1) {
    $_packname = nayuan_get('packname', 1, '');

    showformheader($adminurl . '&op=import&step=2', '', 'import_form');
    showhiddenfields(array(
        'packname' => $_packname,
    ));
    showformfooter(); /*Dism_taobao_com*/

    $_file_import_title = lang('plugin/nayuan_file', 'file_import_title');
    $_file_import_success = lang('plugin/nayuan_file', 'file_import_success');
    $_file_import_loading = lang('plugin/nayuan_file', 'file_import_loading');
    $_admin = ADMINSCRIPT;

print <<<EOF
<div id="ajax_result_data" style="display: none"></div>
<script type="text/javascript">

    function show_loading(title, message) {
        /////显示检测窗口
        var menuid = 'fwin_safe_file_import_window';
        var menuObj = document.createElement('div');
	    menuObj.style.display = 'none';
	    menuObj.className = 'fwinmask';
	    menuObj.id = menuid;
	    $('append_parent').appendChild(menuObj);
	    var s = '<table cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c"><h3 class="flb"><em>' + title + '</em></h3>';
	    s += '<div class="pbg" id="processid" style="margin: 20px 30px; width: 500px;"><img src="/static/image/admincp/ajax_loader.gif" style="width: 500px; height: 20px;" /></div>';
	    s += '<div style="margin:0 30px 30px; width: 500px;"><b>' + message + '</b></div>';
	    s += '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
	    menuObj.innerHTML = s;
        showMenu({'mtype':'safeimport','menuid':menuid,'duration':3,'pos':'00','zindex':JSMENU['zIndex']['dialog'],'cache':0,'cover':1});
    }
    
    function start_import() {
        /////// 开始校验文件
        ajaxpost('import_form', 'ajax_result_data', '', '', '', function() {
            var status = document.getElementById('ajax_result_data').innerText;
            if(status === '1') {
                hideMenu('fwin_safe_file_import_window', 'safeimport');
                showDialog('$_file_import_success', 'right', '$_file_import_title', function() {
                    location.href = '{$_admin}?action=$adminurl';
                });
            }else if(status === '2') {
                setTimeout(start_import, 5000); //每5秒检测一次
            }else if(/^error:.+$/.test(status)){
                hideMenu('fwin_safe_file_import_window', 'safeimport');
                showDialog(status.replace("error:", ''), 'alert', '$_file_import_title', function() {
                    location.href = '{$_admin}?action=$adminurl&op=import';
                });
            }
        });     
    }
    
    if (typeof disallowfloat == 'undefined' || disallowfloat === null) {
        var disallowfloat = '';
    }
    _attachEvent(window, 'load', function() {
        show_loading('$_file_import_title', '$_file_import_loading');
        start_import();
    })
    
</script>
EOF;


}else if(submitcheck('packname') && nayuan_get('step') == 2) {

    include template('common/header_ajax');

    $_packname = nayuan_get('packname', 1, '');
    if(!$_packname) {
        echo 'error:' . lang('plugin/nayuan_file', 'file_import_packname_error');
        exit;
    }
    $_data_file = DISCUZ_ROOT . 'data/' . $_packname;
    if(!file_exists($_data_file)) {
        echo 'error:' . lang('plugin/nayuan_file', 'file_import_packname_not_found');
        exit;
    }

    $_safe_file_lock = DISCUZ_ROOT . 'data/nayuan_file.lock';
    if(!file_exists($_safe_file_lock)) {
        if($fp = @fopen($_safe_file_lock, 'w')) {
            @flock($fp, LOCK_EX);
            @fwrite($fp, 'import');

            $cache_data['safecode'] = random(32);
            savecache('nayuan_file', serialize($cache_data));

            @set_time_limit(0);
            C::t('#nayuan_file#nayuan_safefile') -> truncate();
            $file = @fopen($_data_file, "r");
            //输出文本中所有的行，直到文件结束为止。
            while(!@feof($file)) {
                $data = @fgets($file);
                if(!$data) continue;
                $data = explode('|', $data);
                if(count($data) != 8) continue;
                if(!preg_match('/\.(php|htm|html|js|css)$/i', trim($data[3]))) continue;
                //保存基础数据
                C::t('#nayuan_file#nayuan_safefile') -> insert(array(
                    'id' => md5($data[0] . $data[1] . $data[5] . trim($data[7]) . $cache_data['safecode']),
                    'fid' => $data[0],
                    'md5' => $data[1],
                    'path' => $data[2],
                    'name' => $data[3],
                    'size' => $data[4],
                    'content' => $data[5],
                    'source' => $data[6],
                    'export' => 1,
                    'status' => 10,
                    'time' => trim($data[7])
                ));
            }

            fclose($file);

            @flock($fp, LOCK_UN);
            @fclose($fp);
            @unlink($_safe_file_lock);

            echo 1;
        }else{
            echo 'error:' . lang('plugin/nayuan_file', 'file_data_dir_auth');
        }
    }else{
        echo 2;
    }

    include template('common/footer_ajax');
    exit;

}else{
    cpmsg('nayuan_file:file_import_tips', 'action=' . $adminurl . '&op=import&step=1', 'form', array(
        'version' => DISCUZ_VERSION
    ));
}
//From: d'.'is'.'m.ta'.'obao.com
?>