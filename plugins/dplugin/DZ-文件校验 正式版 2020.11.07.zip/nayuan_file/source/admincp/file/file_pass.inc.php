<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file_pass.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


if(!submitcheck('source')) {
    exit('Access Denied');
}

///// 查询参数
$q_path = nayuan_get('q_path', 1, '');
$q_name = nayuan_get('q_name', 1, '');
$q_ext = nayuan_get('q_ext', 1, '');
$q_status = nayuan_get('q_status');

include template('common/header_ajax');

$source = nayuan_get('source', 1);
$check_type = nayuan_get('check_type', 1);

$_safe_file_lock = DISCUZ_ROOT . 'data/nayuan_file.lock';
if(file_exists($_safe_file_lock)) {
    echo 'error:' . lang('plugin/nayuan_file', 'file_exec_lock');
}else{
    if($fp = @fopen($_safe_file_lock, 'w')) {
        @flock($fp, LOCK_EX);

        if($check_type == 'pass') {
            $_file_id = nayuan_get('file_id', 1);
            if($_file_id) {
                $_changed_file_list = array();
                $file =  C::t('#nayuan_file#nayuan_safefile') -> fetch_latest_by_id_for_pass($_file_id, $cache_data['safecode']);
                if($file) {
                    $_changed_file_list[] = $file;
                }
            }else{
                $_changed_file_list = C::t('#nayuan_file#nayuan_safefile') -> fetch_latest_by_source_status_for_pass($source, 52, $cache_data['safecode'], $q_path, $q_name, $q_ext, $q_status); //内容修改的记录
            }

            foreach ($_changed_file_list as $_item) {
                $file = DISCUZ_ROOT . substr($_item['path'], 1) . $_item['name'];
                $fid = $_item['fid'];
                $md5 = md5_file($file);
                $mtime = filemtime($file);
                $size = filesize($file);

                $fp = @fopen($file, "r");
                $content = @fread($fp, $size);
                @fclose($fp);
                $content = base64_encode(gzdeflate($content));
                if($size > 1048576) { //大于1M不存
                    $content = '';
                }

                //保存正常数据
                C::t('#nayuan_file#nayuan_safefile') -> update($_item['id'], array('status' => 11));
                C::t('#nayuan_file#nayuan_safefile') -> insert(array(
                    'id' => md5($fid . $md5 . $content . $mtime . $cache_data['safecode']),
                    'fid' => $fid,
                    'md5' => $md5,
                    'path' => $_item['path'],
                    'name' => $_item['name'],
                    'size' => $size,
                    'content' => $content,
                    'source' => $_item['source'],
                    'export' => 0,
                    'status' => 10,
                    'time' => $mtime
                ));
            }

            if($_file_id) {
                C::t('#nayuan_file#nayuan_safefile') -> update_status_by_id_for_pass($_file_id, 11, 53, $cache_data['safecode']);
                C::t('#nayuan_file#nayuan_safefile') -> update_status_by_id_for_pass($_file_id, 10, 51, $cache_data['safecode']);
            }else{
                C::t('#nayuan_file#nayuan_safefile') -> update_status_by_source_for_pass($source, 11, 53, $cache_data['safecode'], $q_path, $q_name, $q_ext, $q_status);
                C::t('#nayuan_file#nayuan_safefile') -> update_status_by_source_for_pass($source, 10, 51, $cache_data['safecode'], $q_path, $q_name, $q_ext, $q_status);
            }

            echo 1;
        }else if($check_type == 'rollback') {
            $error = false;
            $_error_file_list = C::t('#nayuan_file#nayuan_safefile') -> fetch_latest_by_source_by_rollback($source, $cache_data['safecode'], $q_path, $q_name, $q_ext, $q_status);
            foreach ($_error_file_list as $_item) {
                $_status = $_item['status'];
                $_file = DISCUZ_ROOT . substr($_item['path'], 1) . $_item['name'];
                if($_status == 51) { //新增加的文件 - 直接删除
                    if(!@unlink($_file)) {
                        $error = true;
                        echo 'error:' . lang('plugin/nayuan_file', 'file_pass_dir_not_auth', array('dir' => $_item['path']));
                        break;
                    }else{
                        C::t('#nayuan_file#nayuan_safefile') -> delete($_item['id']);
                    }
                }else if($_status == 52) {  //被修改的文件 - 直接恢复
                    $_fop = @fopen($_file, "w");
                    if(!$_fop) {
                        $error = true;
                        echo 'error:' . lang('plugin/nayuan_file', 'file_pass_dir_not_auth', array('dir' => $_item['path']));
                        break;
                    }
                    @fwrite($_fop, gzinflate(base64_decode($_item['content'])));
                    @fclose($_fop);
                    C::t('#nayuan_file#nayuan_safefile') -> update($_item['id'], array('status' => 10));
                }else if($_status == 53) { //被删除的文件 - 直接恢复
                    $_fop = @fopen($_file, "w");
                    if(!$_fop) {
                        $error = true;
                        echo 'error:' . lang('plugin/nayuan_file', 'file_pass_dir_not_auth', array('dir' => $_item['path']));
                        break;
                    }
                    @fwrite($_fop, gzinflate(base64_decode($_item['content'])));
                    @fclose($_fop);
                    C::t('#nayuan_file#nayuan_safefile') -> update($_item['id'], array('status' => 10));
                }
            }

            if(!$error) {
                echo 1;
            }
        }

        flock($fp, LOCK_UN);
        @unlink($_safe_file_lock);
        fclose($fp);
    }else{
        echo 'error:' . lang('plugin/file_data_dir_auth', 'file_exec_lock');
    }
}

include template('common/footer_ajax');
exit;

?>