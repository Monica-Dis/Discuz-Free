<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      table_nayuan_safefile.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_safefile extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_file';
        $this->_pk    = 'id';
        parent::__construct(); /*dism _ taobao _ com*/
    }

    public function exist_by_id($id) {
        return DB::result_first("SELECT count(*) FROM %t WHERE `id` = #{id}", array($this -> _table));
    }

    public function fetch_error_list($q_path, $q_name, $q_ext, $q_status, $safecode) {
        $wherestr = $params = array();
        $params[] = $safecode;
        $params[] = $this -> _table;

        if($q_path) {
            $wherestr[] = '`path` like %s';
            $params[] = $q_path . '%';
        }
        if($q_name) {
            $wherestr[] = '`name` = %s';
            $params[] = $q_name;
        }
        if($q_ext) {
            $wherestr[] = 'lower(`name`) like %s';
            if($q_ext == 'html') {
                $q_ext = 'htm%';
            }
            $params[] = '%.' . strtolower($q_ext);
        }
        if($q_status) {
            $wherestr[] = '`status` = %d';
            $params[] = $q_status;
        }else{
            $wherestr[] = '`status` > %d';
            $params[] = 50;
        }
        $wherestr = implode(' AND ', $wherestr);

        return DB::fetch_all("SELECT `id`,`path`,`name`,`size`,`source`,`status`,`time`, (`id` <> md5(concat(`fid`,`md5`,`content`,`time`,%s))) as `diff` FROM %t WHERE $wherestr ORDER BY `path`", $params);
    }

    public function fetch_latest_list() {
        return DB::fetch_all("SELECT `id`,`fid`,`md5`,`time` FROM %t WHERE `status` <> 11", array($this -> _table));
    }

    public function get_tempate_title($id) {
        return DB::result_first("SELECT `name` FROM %t WHERE `directory` = concat('./template/', %s)", array('common_template', $id));
    }

    public function get_plugin_title($id) {
        return DB::result_first("SELECT `name` FROM %t WHERE `identifier` = %s", array('common_plugin', $id));
    }

    public function count_invalid_file($safecode) {
        return DB::result_first("SELECT count(*) FROM %t WHERE `status` <> 11 AND `id` <> md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $safecode));
    }

    public function count_latest_file() {
        return DB::result_first("SELECT count(*) FROM %t WHERE `status` <> 11", array($this -> _table));
    }


    public function fetch_latest_by_source_status_for_pass($source, $status, $safecode, $q_path, $q_name, $q_ext, $q_status) {
        if($q_status && $status != $q_status) return array();

        $wherestr = $params = array();
        $params[] = $this -> _table;
        $wherestr[] = '`source` = %s';
        $params[] = $source;
        $wherestr[] = '`status` = %d';
        $params[] = $status;

        if($q_path) {
            $wherestr[] = '`path` like %s';
            $params[] = $q_path . '%';
        }
        if($q_name) {
            $wherestr[] = '`name` = %s';
            $params[] = $q_name;
        }
        if($q_ext) {
            $wherestr[] = 'lower(`name`) like %s';
            if($q_ext == 'html') {
                $q_ext = 'htm%';
            }
            $params[] = '%.' . strtolower($q_ext);
        }

        $wherestr[] = '`id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))';
        $params[] = $safecode;

        $wherestr = implode(' AND ', $wherestr);

        return DB::fetch_all("SELECT `id`,`fid`,`path`,`name`,`source` FROM %t WHERE $wherestr", $params);
    }

    public function fetch_latest_by_id_for_pass($id, $safecode) {
        return DB::fetch_first("SELECT `id`,`fid`,`path`,`name`,`source` FROM %t WHERE `id` = %s AND `status` = 52 AND `id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $id, $safecode));
    }

    public function update_status_by_id_for_pass($id, $to_status, $source_status, $safecode) {
        DB::query("UPDATE %t SET `status` = %d, `export` = 0 WHERE `id` = %s AND `status` = %d AND `id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $to_status, $id, $source_status, $safecode));
    }

    public function update_status_by_source_for_pass($source, $to_status, $source_status, $safecode, $q_path, $q_name, $q_ext, $q_status) {
        if($q_status && $source_status != $q_status) return;

        $wherestr = $params = array();
        $params[] = $this -> _table;
        $params[] = $to_status;
        $wherestr[] = '`source` = %s';
        $params[] = $source;
        $wherestr[] = '`status` = %d';
        $params[] = $source_status;

        if($q_path) {
            $wherestr[] = '`path` like %s';
            $params[] = $q_path . '%';
        }
        if($q_name) {
            $wherestr[] = '`name` = %s';
            $params[] = $q_name;
        }
        if($q_ext) {
            $wherestr[] = 'lower(`name`) like %s';
            if($q_ext == 'html') {
                $q_ext = 'htm%';
            }
            $params[] = '%.' . strtolower($q_ext);
        }

        $wherestr[] = '`id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))';
        $params[] = $safecode;

        $wherestr = implode(' AND ', $wherestr);

        DB::query("UPDATE %t SET `status` = %d, `export` = 0 WHERE $wherestr", $params);
    }

    public function fetch_latest_by_source_by_rollback($source, $safecode, $q_path, $q_name, $q_ext, $q_status) {
        $wherestr = $params = array();
        $params[] = $this -> _table;
        $wherestr[] = '`source` = %s';
        $params[] = $source;
        if($q_status) {
            $wherestr[] = '`status` = %d';
            $params[] = $q_status;
        }else{
            $wherestr[] = '`status` > %d';
            $params[] = 50;
        }

        if($q_path) {
            $wherestr[] = '`path` like %s';
            $params[] = $q_path . '%';
        }
        if($q_name) {
            $wherestr[] = '`name` = %s';
            $params[] = $q_name;
        }
        if($q_ext) {
            $wherestr[] = 'lower(`name`) like %s';
            if($q_ext == 'html') {
                $q_ext = 'htm%';
            }
            $params[] = '%.' . strtolower($q_ext);
        }

        $wherestr[] = '`id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))';
        $params[] = $safecode;

        $wherestr = implode(' AND ', $wherestr);

        return DB::fetch_all("SELECT `id`,`fid`,`path`,`name`,`source`,`content`,`status` FROM %t WHERE $wherestr", $params);
    }

    public function fetch_latest_for_export($safecode) {
        return DB::fetch_all("SELECT `fid`,`md5`,`path`,`name`,`source`,`content`,`time`,`size` FROM %t WHERE `status` in (10,52,53) AND `id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $safecode));
    }

    public function update_latest_export_status($safecode) {
        return DB::query("UPDATE %t SET `export` = 1 WHERE `status` in (10,52,53) AND `export` = 0 AND `id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $safecode));
    }

    public function count_no_backup_files($safecode) {
        return DB::result_first("SELECT count(*) FROM %t WHERE `status` in (10,52,53) AND `export` = 0 AND `id` = md5(concat(`fid`,`md5`,`content`,`time`,%s))", array($this -> _table, $safecode));
    }



}
//From: d'.'is'.'m.ta'.'obao.com
?>