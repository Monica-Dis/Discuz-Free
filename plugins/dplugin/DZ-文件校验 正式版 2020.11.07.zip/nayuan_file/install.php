<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      install.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_file` (
        `id`            char(32) NOT NULL,
        `fid`           char(32) NOT NULL,
        `md5`           char(32) NOT NULL,
        `path`          varchar(255) NOT NULL,
        `name`          varchar(255) NOT NULL,
        `size`          int(10) NOT NULL,
        `content`       MEDIUMTEXT,
        `tips`          varchar(255),
        `source`        varchar(100) NOT NULL,
        `status`        tinyint(2) NOT NULL,
        `export`        tinyint(1) NOT NULL,
        `time`          int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        KEY `idx_status`(`status`),
        KEY `idx_source`(`source`),
        KEY `idx_exp`(`export`)
    ) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE; /*dism·taobao·com*/

?>