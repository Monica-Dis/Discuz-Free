<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_file.
 *      file.inc.php.
 *      Author http://t.cn/Aiux1Jx1
 *      Time 2020-11-07 22:56:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_file/source/function/core.func.php';

$_operations = array('list', 'check', 'opselect', 'log', 'import', 'export', 'diff', 'pass');
$_op = nayuan_get('op', 1, 'opselect');
if(!in_array($_op, $_operations)) {
    exit('Access Denied');
}

$adminurl = 'plugins&operation=config&do=' . $do . '&pmod=file';

loadcache('nayuan_file');
$cache_data = $_G['cache']['nayuan_file'];
if(!$cache_data) {
    $cache_data = array();
}else{
    $cache_data = unserialize($cache_data);
}

if(!$cache_data['safecode']) {
    $cache_data['safecode'] = random(32);
    savecache('nayuan_file', $cache_data);
}

require DISCUZ_ROOT . 'source/plugin/nayuan_file/source/admincp/file/file_' . $_op . '.inc.php';

?>