<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      table_nayuan_refund.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_refund extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_pay_refund';
        $this->_pk    = 'id';
        parent::__construct(); /*dism·taobao·com*/
    }

    public function fetch_by_refund($no) {
        return DB::fetch_first("SELECT * FROM %t WHERE `refund_no` = %d", array($this -> _table, $no));
    }

    public function sum_refund_amount($oid) {
        return DB::result_first("SELECT sum(`amount`) FROM %t WHERE `oid` = %d AND `status` = 1", array($this -> _table, $oid));
    }

}

?>