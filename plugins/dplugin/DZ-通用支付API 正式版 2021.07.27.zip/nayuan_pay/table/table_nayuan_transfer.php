<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      table_nayuan_transfer.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_transfer extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_pay_transfer';
        $this->_pk    = 'id';
        parent::__construct(); /*dism·taobao·com*/
    }

    public function fetch_order_by_no($no) {
        return DB::fetch_first("SELECT * FROM %t WHERE `order_id` = %s", array($this -> _table, $no));
    }

    public function update_order_by_no($no, $data) {
        DB::update($this -> _table, $data, DB::field('order_id', $no));
    }

    public function fetch_list($uid, $type, $status, $time, $oid, $page = 1, $pagesize = 15) {
        $wherestr = $params = array();
        $params[] = $this -> _table;

        if($uid) {
            $wherestr[]= 'a.`uid` = %d';
            $params[] = $uid;
        }
        if($type) {
            $wherestr[] = 'a.type = %s';
            $params[] = $type;
        }
        if($status !== '') {
            $wherestr[]= 'a.`status` = %d';
            $params[] = $status;
        }
        if($oid){
            $wherestr[]= '(a.`order_id` = %s OR a.trade_no = %s)';
            $params[] = $oid;
            $params[] = $oid;
        }
        if($time) {
            $wherestr[]= 'a.`time` >= %d AND a.`time` < %d';
            $params[] = dmktime($time);
            $params[] = dmktime($time) + 86400;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        $_result = array();
        $_total = DB::result_first("SELECT count(*) FROM %t a $wherestr", $params);
        if(!$_total) {
            $_result['total'] = 0;
            $_result['list'] = array();
        }else{
            $_list = DB::fetch_all("SELECT a.* FROM %t a $wherestr ORDER BY a.id DESC" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
            $_result['total'] = $_total;
            $_result['list'] = $_list;
        }
        return $_result;
    }

}

?>