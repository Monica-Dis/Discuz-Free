<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      nayuan_pay.inc.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/app.class.php';
$nayuanapp = new nayuan_app();
$nayuanapp -> init();

$apiurl = $_G['siteurl'] . 'plugin.php?id=nayuan_pay';
$staticurl = $_G['siteurl'] . 'source/plugin/nayuan_pay/static/';

$nayuanapp -> request();

?>