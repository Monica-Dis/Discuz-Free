<?

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require '../../../../source/class/class_core.php';

$discuz = C::app();
$discuz->init();
$_G['siteurl'] = preg_replace('/source\/plugin\/.+$/', '', $_G['siteurl']);

$_GET['mma'] = 'alipay';
$_GET['mmo'] = 'callback';

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/app.class.php';
$nayuanapp = new nayuan_app();
$nayuanapp -> init();

$apiurl = $_G['siteurl'] . 'plugin.php?id=nayuan_pay';
$staticurl = $_G['siteurl'] . 'source/plugin/nayuan_pay/static/';

$nayuanapp -> request();

?>