<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      upgrade.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(!$fromversion) {
    $fromversion = $_GET['fromversion'];
}

if($fromversion < '2021.05.30') {

$sql = <<<EOF
    
    ALTER TABLE pre_nayuan_pay_order ADD `currency` varchar(255) DEFAULT 'CNY';
    ALTER TABLE pre_nayuan_pay_transfer ADD `currency` varchar(255) DEFAULT 'CNY';

EOF;

    runquery($sql);
}

$finish = true;

?>