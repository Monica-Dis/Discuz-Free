<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      admin.inc.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/app.class.php';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/admin.func.php';

if(!$_GET['mma']) {
    $_GET['mma'] = 'admin_order';
    $_GET['mmo'] = 'index';
}

$nayuanapp = new nayuan_app();
$nayuanapp -> init();

$pay_types = array(
    array('name' => 'admin_weixin', 'title' => lang('plugin/nayuan_pay', 'menu_type_weixin')),
    array('name' => 'admin_alipay', 'title' => lang('plugin/nayuan_pay', 'menu_type_alipay'))
);

$langdir = DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/language/pay';
$langs = scandir($langdir);
foreach ($langs as $ln) {
    if($ln == '.' || $ln == '..' || !preg_match('/^lang_(.+)_'.currentlang().'\.php$/i', $ln, $matchers)) continue;
    @include $langdir . '/' . $ln;
    $pay_types[] = array('name' => 'admin_' . $matchers[1], 'title' => $lang_pay['title']);
    unset($lang_pay);
}

show_admin_menu($plugin['name'], $nayuanapp -> action, array(
    array('name' => 'admin_setting', 'title' => lang('plugin/nayuan_pay', 'menu_setting')),
    array('title' => lang('plugin/nayuan_pay', 'menu_type'), 'submenu' => $pay_types),
    array('title' => lang('plugin/nayuan_pay', 'menu_pay_manager'), 'submenu' => array(
        array('name' => 'admin_order', 'title' => lang('plugin/nayuan_pay', 'menu_order')),
        array('name' => 'admin_test', 'title' => lang('plugin/nayuan_pay', 'menu_test')),
    )),
    array('title' => lang('plugin/nayuan_pay', 'menu_transfer_manager'), 'submenu' => array(
        array('name' => 'admin_transfer', 'title' => lang('plugin/nayuan_pay', 'menu_transfer')),
        array('name' => 'admin_testtransfer', 'title' => lang('plugin/nayuan_pay', 'menu_testtransfer')),
    )),
    array('title' => lang('plugin/nayuan_pay', 'menu_api'), 'submenu' => array(
        array('name' => 'admin_api', 'title' => lang('plugin/nayuan_pay', 'menu_api_pay')),
        array('name' => 'admin_apirefund', 'title' => lang('plugin/nayuan_pay', 'menu_api_refund')),
        array('name' => 'admin_apitransfer', 'title' => lang('plugin/nayuan_pay', 'menu_api_transfer')),
    )),
));

$adminurl = 'plugins&operation=config&do=' . $do . '&pmod=admin&mma=' . $nayuanapp -> action;

$nayuanapp -> request();

?>