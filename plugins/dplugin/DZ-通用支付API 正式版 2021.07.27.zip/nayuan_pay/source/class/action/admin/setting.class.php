<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      setting.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_setting {

    public function index() {
        global $_G, $adminurl;

        $settings = $_G['cache']['nayuan_pay']['setting'];
        if(!$settings['currencys']) {
			$settings['currencys'][] = 'CNY';
		}

        showformheader($adminurl . '&mmo=save');

        $currency_cache = nayuan_options('plugin/nayuan_pay', 'admin_setting_currency_options');
        $currency_options = array();
        foreach ($currency_cache as $name => $title) {
            $currency_options[] = array($name, $title);
        }

        showtableheader(); /*dism��taobao��com*/
        showsetting(lang('plugin/nayuan_pay', 'admin_setting_currency'), array('data[currencys][]', $currency_options), $settings['currencys'], 'mselect', '', 0, lang('plugin/nayuan_pay', 'admin_setting_currency_tips'));
        showtablefooter(); /*dism-Taobao-com*/

        showtableheader(); /*dism��taobao��com*/
        showsubmit('savesubmit');
        showtablefooter(); /*dism-Taobao-com*/

        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
    }

    public function save() {
        global $_G, $adminurl;
        if(submitcheck('savesubmit')) {
            $settings = $_G['cache']['nayuan_pay'];
            $data = nayuan_get('data', 3);
            $settings['setting'] = $data;
            savecache('nayuan_pay', $settings);
        }
        cpmsg(lang('plugin/nayuan_pay', 'save_success'), 'action=' . $adminurl, 'succeed');
    }

}

?>