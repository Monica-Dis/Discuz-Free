<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      weixin.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_weixin {

    public function index() {
        global $_G, $adminurl;
        $settings = $_G['cache']['nayuan_pay'];
        $weixinsettings = $settings['mc_list']['weixin'];
        showtips(lang('plugin/nayuan_pay', 'admin_weixin_tips'));
        showformheader($adminurl . '&mmo=save');
        $currencies = 'CNY';
        showhiddenfields(array('data[currencies]' => $currencies));
        showtableheader(); /*dism·taobao·com*/
        showtagheader('tbody', 'alipay_weixin', true);
        $is_readonly = '';
        $tips = '';
        if($settings['setting']['currency'] && !in_array($settings['setting']['currency'], explode(',', $currencies))) {
            $currency_cache = nayuan_options('plugin/nayuan_pay', 'admin_setting_currency_options');
            $is_readonly = 'readonly';
            $tips = lang('plugin/nayuan_pay', 'error_invalid_transfer_type') . $currency_cache[$settings['setting']['currency']];
            $weixinsettings['on'] = 0;
        }
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_status'), 'data[on]', $weixinsettings['on'], 'radio', $is_readonly, 0, $tips);

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';
        $check = array();
        $weixinsettings['api_version'] ? $check['true'] = "checked" : $check['false'] = "checked";
        $weixinsettings['api_version'] ? $check['false'] = '' : $check['true'] = '';
        $check['hidden1'] = ' onclick="$(\'api_version_2\').style.display = \'none\';$(\'api_version_3\').style.display = \'\';"';
        $check['hidden0'] = ' onclick="$(\'api_version_2\').style.display = \'\';$(\'api_version_3\').style.display = \'none\';"';
        $html = '<ul onmouseover="altStyle(this);"><li'.($check['false'] ? ' class="checked"' : '').'><input class="radio" type="radio" name="data[api_version]" value="0" '.$check['false'].$check['hidden0'].'>&nbsp;'.lang('plugin/nayuan_pay', 'admin_weixin_version_2').'</li>';
        if(sdk_v3_weixin_support()) {
            $html .= '<li'.($check['true'] ? ' class="checked"' : '').'><input class="radio" type="radio" name="data[api_version]" value="1" '.$check['true'].$check['hidden1'].'>&nbsp;'.lang('plugin/nayuan_pay', 'admin_weixin_version_3').'</li>';
        }else{
            $html .= '<li style="margin-left: 5px; color: red;">'.lang('plugin/nayuan_pay', 'admin_weixin_version_3').'('.lang('plugin/nayuan_pay', 'admin_weixin_php_version_low').')</li>';
        }
        $html .= '</ul>';
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_version'), '', '', $html, '', 0, lang('plugin/nayuan_pay', 'admin_weixin_version_comment'));

        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_appid'), 'data[appid]', $weixinsettings['appid'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_appid_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_appsecret'), 'data[appsecret]', $weixinsettings['appsecret'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_appid_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_mchid'), 'data[mchid]', $weixinsettings['mchid'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_mchid_tips'));
        showtagfooter('tbody');

        showtagheader('tbody', 'api_version_2', !$weixinsettings['api_version']);
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_key'), 'data[key]', $weixinsettings['key'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_key_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_cert'), 'data[p12]', $weixinsettings['p12'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_cert_tips', array('path' => 'source/plugin/nayuan_pay/data/' . random(5) . '.p12')));
        showtagfooter('tbody');

        showtagheader('tbody', 'api_version_3', $weixinsettings['api_version']);
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_v3_key'), 'data[v3_key]', $weixinsettings['v3_key'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_v3_key_comment'));
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_v3_private_key'), 'data[v3_private_key]', $weixinsettings['v3_private_key'], 'textarea', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_v3_private_key_comment'));
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_v3_serial_no'), 'data[v3_serial_no]', $weixinsettings['v3_serial_no'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_weixin_v3_serial_no_comment'));
        showtagfooter('tbody');

        showtablefooter(); /*dism-Taobao-com*/
        ///////////////////// 提交
        showtableheader(); /*dism·taobao·com*/
        showsetting(lang('plugin/nayuan_pay', 'admin_weixin_order'), 'data[order]', $weixinsettings['order'] ? $weixinsettings['order'] : 200, 'number');
        showsubmit('savesubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
    }

    public function save() {
        global $_G, $adminurl;
        if(submitcheck('savesubmit')) {
            $settings = $_G['cache']['nayuan_pay'];
            $data = nayuan_get('data', 3);
            $settings['mc_list']['weixin'] = $data;
            savecache('nayuan_pay', $settings);

            if($data['api_version'] && $data['appid'] && $data['mchid'] && $data['v3_key'] && $data['v3_private_key'] && $data['v3_serial_no']) {
                require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';
                $result = sdk_v3_weixin_certificates($data);
                if($result['code'] == 200) {
                    $data['v3_certificates'] = $result['data'];
                }
                $settings['mc_list']['weixin'] = $data;
                savecache('nayuan_pay', $settings);
                savecache('nayuan_pay', $settings);
            }
        }
        cpmsg(lang('plugin/nayuan_pay', 'save_success'), 'action=' . $adminurl, 'succeed');
    }

    public function refund() {
        global $_G, $adminurl;
        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        if($order && ($order['status'] == 1 || ($order['status'] == 2 && $order['receipt_amount'] - $order['refund_amount']))) {
            $refundamount = nayuan_get('amount') * 100;
            if($refundamount <= 0 || $refundamount > ($order['receipt_amount'] - $order['refund_amount'])) {
                cpmsg(lang('plugin/nayuan_pay', 'error_refund_invalid_amount'), 'action=' . $adminurl, 'error');
            }
        }else{
            cpmsg(lang('plugin/nayuan_pay', 'error_refund_invalid_order'), 'action=' . $adminurl, 'error');
        }
    }

}

?>