<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      transfer.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_transfer {

    public function index() {
        global $_G, $adminurl;
        ///// 查询参数
        $q_order_id = nayuan_get('q_order_id', 1);
        $q_uid = nayuan_get('q_uid');
        $q_status = nayuan_get('q_status', 0, '');
        $q_type = nayuan_get('q_type', 1);
        $q_time = nayuan_get('q_time', 1);
        $q_page = max(1, nayuan_get('page', 0, 1));
        $q_pagesize = max(1, nayuan_get('pagesize', 0, 20));

        $pay_type_options = nayuan_show_options(lang('plugin/nayuan_pay', 'admin_transfer_type_options'), $q_type);
        $status_options = nayuan_show_options(lang('plugin/nayuan_pay', 'admin_transfer_status_options'), $q_status);

        showtips(lang('plugin/nayuan_pay', 'admin_transfer_tips'));
        echo '<style type="text/css">.nayuan-green td { color: green; } .nayuan-red td { color: red; } .nayuan-blue td { color: #2366A8; } .nayuan-del td { color: #9e9d9d; text-decoration: line-through; }</style>';
        echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
        showformheader("$adminurl", '', 'search_form');
        echo '<input type="hidden" name="page" id="page" value="1">';
        showtableheader('search');
        showtablerow('', array(
            'width="50"', 'width="120"',
            'width="50"', 'width="70"',
            'width="50"', 'width="70"',
            'width="50"', 'width="70"',
            'width="50"', 'width="100"',
            ''),
            array(
                lang('plugin/nayuan_pay', 'admin_transfer_id'), '<input type="text" class="txt" name="q_order_id" value="'.dhtmlspecialchars($q_order_id).'" />',
                lang('plugin/nayuan_pay', 'admin_transfer_uid'), '<input type="number" style="width: 50px;" class="txt" name="q_uid" value="'.$q_uid.'" />',
                lang('plugin/nayuan_pay', 'admin_transfer_type'), '<select name="q_type"><option value=""></option>'.$pay_type_options.'</select>',
                lang('plugin/nayuan_pay', 'admin_transfer_status'), '<select name="q_status"><option value=""></option>'.$status_options.'</select>',
                lang('plugin/nayuan_pay', 'admin_transfer_time'), '<input type="text" style="width: 70px;" name="q_time" onclick="showcalendar(event, this)" value="'.$q_time.'" />',
                "<input class=\"btn\" type=\"submit\" name=\"searchsubmit\" value=\"".lang('admincp', 'search')."\" />",
            )
        );
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/

        //// 列表展示
        $_data_list = C::t('#nayuan_pay#nayuan_transfer') -> fetch_list($q_uid, $q_type, $q_status, $q_time, $q_order_id, $q_page, $q_pagesize);

        $tdstyle = array(
            'style="width: 200px;"',
            'style="width: 100px; text-align: center"',
            'style="width: 100px; text-align: center"',
            '',
            'style="width: 100px; text-align: right"',
            'style="width: 50px; text-align: center"',
            '',
            'style="width: 210px; text-align: center"',
            'style="width: 50px; text-align: right"',
        );
        showtableheader(lang('plugin/nayuan_pay', 'admin_transfer_list_title') . ' - ' . $_data_list['total']);
        showsubtitle(array(
            lang('plugin/nayuan_pay', 'admin_transfer_header_oid'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_user'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_type'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_desc'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_amount'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_status'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_error'),
            lang('plugin/nayuan_pay', 'admin_transfer_header_time'),
            '',
        ), 'header', $tdstyle);

        if($_data_list['total']) {

            $statuscache = nayuan_options('plugin/nayuan_pay', 'admin_transfer_status_options');
            $paytypecache = nayuan_options('plugin/nayuan_pay', 'admin_transfer_type_options');

            foreach ($_data_list['list'] as $item) {
                $trcss = '';
                if($item['status'] == 2) {
                    $trcss = 'nayuan-green';
                }else if($item['status'] == 3) {
                    $trcss = 'nayuan-red';
                }else if($item['status'] == 1) {
                    $trcss = 'nayuan-blue';
                }else{
                    $trcss = '';
                }
                $data = array();
                $ordernostr = lang('plugin/nayuan_pay', 'admin_transfer_header_oid') . ': ' . $item['order_id'];
                $data[] = $ordernostr;

                if($item['uid']) {
                    $user = getuserbyuid($item['uid']);
                    $data[] = '<a href="" target="_blank">'.$user['username'].' ('.$item['uid'].')</a>';
                }else{
                    $data[] = '';
                }

                $data[] = $paytypecache[$item['type']];
                $data[] = dhtmlspecialchars($item['subject']) . '<br/>' . dhtmlspecialchars($item['desc']);
                $data[] = ($item['amount'] / 100) . lang('plugin/nayuan_pay', 'yuan');
                $data[] = $statuscache[$item['status']];
                if($item['status'] == 3) {
                    $data[] = $item['error'];
                }else{
                    $data[] = '';
                }

                $timestr = lang('plugin/nayuan_pay', 'admin_transfer_header_submit_time') . ': ' . dgmdate($item['time'], 'Y-m-d H:i:s');
                if($item['pay_time']) {
                    $timestr .= '<br/>' . lang('plugin/nayuan_pay', 'admin_transfer_header_pay_time') . ': ' . dgmdate($item['pay_time'], 'Y-m-d H:i:s');
                }
                $data[] = $timestr;
                if($item['status'] == 1) {
                    $data[] = '<a href="'.ADMINSCRIPT.'?action='.$adminurl.'&mmo=status&oid='.$item['id'].'">'.lang('plugin/nayuan_pay', 'admin_transfer_btn_status').'</a>';
                }else{
                    $data[] = '';
                }

                showtablerow('class="'.$trcss.'"', $tdstyle, $data);
            }

            $v_page_html = multi($_data_list['total'], $q_pagesize, $q_page, 'nayuan_next_page({page})', 0, $q_pagesize, false, false, ';');
            showsubmit('', '', '', '', $v_page_html);

        }else{
            showtablerow('', array('class="center" colspan="6"'), array(lang('plugin/nayuan_pay', 'list_no_data')));
        }

        showtablefooter(); /*dism-Taobao-com*/
        echo '<script type="text/javascript">function nayuan_next_page(page) {$("page").value=page;$("search_form").submit();}</script>';
    }

    public function status() {
        global $_G, $adminurl;
        ///// 查询参数
        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_transfer') -> fetch($oid);
        if(!$order || $order['status'] != 1) {
            cpmsg('nayuan_pay:error_invalid_request', 'action=' . $adminurl . '&q_order_id=' . $order['order_id'], 'error');
        }

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/order.func.php';
        if($order['type'] == 'alipay') {
            $result = nayuan_pay_alipay_transfer_status($order['order_id']);
            if($result['code'] == '200') {
                cpmsg('nayuan_pay:admin_transfer_success', 'action=' . $adminurl . '&q_order_id=' . $order['order_id'], 'succeed');
            }else if($result['code'] == 201) {
                cpmsg('nayuan_pay:admin_transfer_handler', 'action=' . $adminurl . '&q_order_id=' . $order['order_id'], 'succeed');
            }else{
                $message = $result['message'];
                if(strpos($result['message'], ':') !== FALSE) {
                    $message = ":" . $message;
                }
                cpmsg($message, 'action=' . $adminurl . '&q_order_id=' . $order['order_id'], 'error');
            }
        }else{
            cpmsg('nayuan_pay:error_invalid_transfer_type', 'action=' . $adminurl . '&q_order_id=' . $order['order_id'], 'error');
        }

    }

}

?>