<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      more.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_more {

    public function index() {
        echo '<style type="text/css">html, body, #cpcontainer {width: 100%; height: 100%; overflow-x: hidden; overflow-y: hidden; }</style>';
        echo '<iframe src="https://dism.taobao.com?/developer-12008.html" width="100%" height="100%" frameborder="0"></iframe>';
    }

}

?>