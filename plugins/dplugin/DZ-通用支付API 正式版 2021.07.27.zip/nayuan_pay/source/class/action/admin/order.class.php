<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      order.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_order {

    public function index() {
        global $_G, $adminurl;
        $currency_cache = nayuan_options('plugin/nayuan_pay', 'admin_setting_currency_options');
        ///// 查询参数
        $q_order_id = nayuan_get('q_order_id', 1);
        $q_uid = nayuan_get('q_uid');
        $q_status = nayuan_get('q_status', 0, '');
        $q_pay_type = nayuan_get('q_pay_type', 1);
        $q_type = nayuan_get('q_type', 1);
        $q_time = nayuan_get('q_time', 1);
        $q_page = max(1, nayuan_get('page', 0, 1));
        $q_pagesize = max(1, nayuan_get('pagesize', 0, 20));

        $typeoptions = array();
        $type_list = C::t('#nayuan_pay#nayuan_type') -> fetch_all_type();
        foreach ($type_list as $type) {
            $typeoptions[] = '<option value="'.$type['code'].'" '.($q_type == $type['code'] ? 'selected' : '').'>'.$type['name'].'</option>';
        }

        $pay_type_options = nayuan_show_options(lang('plugin/nayuan_pay', 'admin_order_type_options'), $q_pay_type);
        $status_options = nayuan_show_options(lang('plugin/nayuan_pay', 'admin_order_status_options'), $q_status);

        showtips(lang('plugin/nayuan_pay', 'admin_order_tips'));
        echo '<style type="text/css">.nayuan-green td { color: green; } .nayuan-red td { color: red; } .nayuan-del td { color: #9e9d9d; text-decoration: line-through; }</style>';
        echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
        showformheader("$adminurl", '', 'search_form');
        echo '<input type="hidden" name="page" id="page" value="1">';
        showtableheader('search');
        showtablerow('', array(
            'width="50"', 'width="120"',
            'width="50"', 'width="70"',
            'width="50"', 'width="70"',
            'width="50"', 'width="70"',
            'width="50"', 'width="70"',
            'width="50"', 'width="100"',
            'width="80"', ''),
            array(
                lang('plugin/nayuan_pay', 'admin_order_id'), '<input type="text" class="txt" name="q_order_id" value="'.dhtmlspecialchars($q_order_id).'" />',
                lang('plugin/nayuan_pay', 'admin_order_uid'), '<input type="number" style="width: 50px;" class="txt" name="q_uid" value="'.$q_uid.'" />',
                lang('plugin/nayuan_pay', 'admin_order_type'), '<select name="q_type"><option value=""></option>'.implode('', $typeoptions).'</select>',
                lang('plugin/nayuan_pay', 'admin_order_pay_type'), '<select name="q_pay_type"><option value=""></option>'.$pay_type_options.'</select>',
                lang('plugin/nayuan_pay', 'admin_order_status'), '<select name="q_status"><option value=""></option>'.$status_options.'</select>',
                lang('plugin/nayuan_pay', 'admin_order_time'), '<input type="text" style="width: 70px;" name="q_time" onclick="showcalendar(event, this)" value="'.$q_time.'" />',
                "<input class=\"btn\" type=\"submit\" name=\"searchsubmit\" value=\"".lang('admincp', 'search')."\" />",
                "<input class=\"btn\" type=\"button\" onclick=\"nayuan_clean_order()\" name=\"cleansubmit\" value=\"".lang('plugin/nayuan_pay', 'admin_order_btn_clean')."\" />",
            )
        );
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/

        //// 列表展示
        $_data_list = C::t('#nayuan_pay#nayuan_order') -> fetch_list($q_uid, $q_type, $q_pay_type, $q_status, $q_time, $q_order_id, $q_page, $q_pagesize);

        showtableheader(lang('plugin/nayuan_pay', 'admin_order_list_title') . ' - ' . $_data_list['total']);
        showsubtitle(array(
            lang('plugin/nayuan_pay', 'admin_order_header_oid'),
            lang('plugin/nayuan_pay', 'admin_order_header_user'),
            lang('plugin/nayuan_pay', 'admin_order_header_type'),
            lang('plugin/nayuan_pay', 'admin_order_header_desc'),
            lang('plugin/nayuan_pay', 'admin_order_header_amount'),
            lang('plugin/nayuan_pay', 'admin_order_header_pay_type'),
            lang('plugin/nayuan_pay', 'admin_order_header_status'),
            lang('plugin/nayuan_pay', 'admin_order_header_time'),
        ), 'header', array(
            'style="width: 200px;"',
            'style="width: 100px; text-align: center"',
            'style="width: 100px; text-align: center"',
            '',
            'style="width: 100px; text-align: right"',
            'style="width: 100px; text-align: center"',
            'style="width: 50px; text-align: center"',
            'style="width: 210px; text-align: center"',
        ));

        if($_data_list['total']) {

            $typecache = array();
            $statuscache = nayuan_options('plugin/nayuan_pay', 'admin_order_status_options');
            $paytypecache = nayuan_options('plugin/nayuan_pay', 'admin_order_type_options');

            $langdir = DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/language/pay';
            $langs = scandir($langdir);
            foreach ($langs as $ln) {
                if($ln == '.' || $ln == '..' || !preg_match('/^lang_(.+)_'.currentlang().'\.php$/i', $ln, $matchers)) continue;
                @include $langdir . '/' . $ln;
                $paytypecache[$matchers[1]] = $lang_pay['title'];
                unset($lang_pay);
            }

            foreach ($_data_list['list'] as $item) {
                $trcss = '';
                if($item['status'] == 1) {
                    $trcss = 'nayuan-green';
                }else if($item['status'] == 2) {
                    $trcss = 'nayuan-red';
                }else if($item['expire_time'] < time()) {
                    $trcss = 'nayuan-del';
                }
                $data = array();
                $ordernostr = lang('plugin/nayuan_pay', 'admin_order_header_oid') . ': ' . $item['order_id'];
                $data[] = $ordernostr;

                $user = getuserbyuid($item['uid']);
                $data[] = '<a href="" target="_blank">'.$user['username'].' ('.$item['uid'].')</a>';

                if(!$typecache[$item['type']]) {
                    $typecache[$item['type']] = C::t('#nayuan_pay#nayuan_type') -> fetch_type_name($item['type']);
                }
                $data[] = $typecache[$item['type']];

                $data[] = dhtmlspecialchars($item['subject']) . '<br/>' . dhtmlspecialchars($item['desc']);

                $amount_unit = lang('plugin/nayuan_pay', 'yuan');
                if($item['currency'] != 'CNY') {
                    $amount_unit = $currency_cache[$item['currency']];
                }
                $refund_amount = C::t('#nayuan_pay#nayuan_refund') -> sum_refund_amount($item['id']);
                $amountstr = array();
                $amountstr[] = ($item['receipt_amount'] / 100) . $amount_unit;

                if($item['receipt_amount'] != $item['total_amount']) {
                    $amountstr[] = '<span>' . $item['total_amount'] . $amount_unit . '</span>';
                }
                if($refund_amount) {
                    $amountstr[] = lang('plugin/nayuan_pay', 'admin_order_header_receipt_refund_amount') . ':&nbsp;' . ($refund_amount / 100) . $amount_unit;
                }
                $data[] = implode('<br/>', $amountstr);

                if($item['pay_type']) {
                    $data[] = $paytypecache[$item['pay_type']];
                }else{
                    $data[] = '';
                }

                $data[] = $statuscache[$item['status']];

                $timestr = lang('plugin/nayuan_pay', 'admin_order_header_create_time') . ': ' . dgmdate($item['time'], 'Y-m-d H:i:s');
                if($item['pay_time']) {
                    $timestr .= '<br/>' . lang('plugin/nayuan_pay', 'admin_order_header_pay_time') . ': ' . dgmdate($item['pay_time'], 'Y-m-d H:i:s');
                }else{
                    $timestr .= '<br/>' . lang('plugin/nayuan_pay', 'admin_order_header_expire_time') . ': ' . dgmdate($item['expire_time'], 'Y-m-d H:i:s');
                }
                $data[] = $timestr;

                showtablerow('class="'.$trcss.'"', array(
                    'style="width: 200px;"',
                    'style="width: 100px; text-align: center"',
                    'style="width: 100px; text-align: center"',
                    '',
                    'style="width: 100px; text-align: right"',
                    'style="width: 100px; text-align: center"',
                    'style="width: 50px; text-align: center"',
                    'style="width: 210px; text-align: center"',
                ), $data);
            }

            $v_page_html = multi($_data_list['total'], $q_pagesize, $q_page, 'nayuan_next_page({page})', 0, $q_pagesize, false, false, ';');
            showsubmit('', '', '', '', $v_page_html);

        }else{
            showtablerow('', array('class="center" colspan="6"'), array(lang('plugin/nayuan_pay', 'list_no_data')));
        }

        showtablefooter(); /*dism-Taobao-com*/
        echo '<script type="text/javascript">function nayuan_next_page(page) {$("page").value=page;$("search_form").submit();} function nayuan_clean_order() { window.location.href = \''.ADMINSCRIPT . '?action=' . $adminurl .'&mmo=clean\'}</script>';
    }

    public function clean() {
        global $_G, $adminurl;
        C::t('#nayuan_pay#nayuan_order') -> clean_order();
        cpmsg(lang('plugin/nayuan_pay', 'admin_order_clean_success'), 'action=' . $adminurl, 'succeed');
    }

    public function refund() {
        global $_G, $adminurl;
        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        if($order && ($order['status'] == 1 || ($order['status'] == 2 && $order['receipt_amount'] - $order['refund_amount']))) {
            showtips(lang('plugin/nayuan_pay', 'admin_order_refund_tips'));
            showformheader($adminurl . '&mma=' . $order['pay_type'] . '&mmo=refund');
            showhiddenfields(array('oid' => $oid));
            showtableheader(lang('plugin/nayuan_pay', 'admin_order_refund_title'));

            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_id'), $order['order_id']));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_trade_no'), $order['trade_no']));
            $user = getuserbyuid($order['uid']);
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_user'), '<a href="" target="_blank">'.$user['username'].' ('.$order['uid'].')</a>'));
            $type_name = C::t('#nayuan_pay#nayuan_type') -> fetch_type_name($order['type']);
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_type'), $type_name));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_desc'), $order['subject'] . '<br/>' . $order['desc']));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_time'), dgmdate($order['time'], 'Y-m-d H:i:s')));
            $statuscache = nayuan_options('plugin/nayuan_pay', 'admin_order_status_options');
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_status'), $statuscache[$order['status']]));
            $paytypecache = nayuan_options('plugin/nayuan_pay', 'admin_order_type_options');
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_pay_type'), $paytypecache[$order['pay_type']]));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_amount'), ($order['receipt_amount'] / 100) . ' ' . lang('plugin/nayuan_pay', 'yuan')));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_pay_time'), dgmdate($order['pay_time'], 'Y-m-d H:i:s')));
            if($order['refund_amount']) {
                showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_refund_amount'), ($order['refund_amount'] / 100) . ' ' . lang('plugin/nayuan_pay', 'yuan')));
            }
            $refund_amount = ($order['receipt_amount'] - $order['refund_amount']) / 100;
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_receipt_refund_amount'), '<input type="number" name="amount" value="'.$refund_amount.'" style="width: 100px;" /> ' . lang('plugin/nayuan_pay', 'yuan')));
            showtablerow('', array('style="width: 100px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_order_header_refund_desc'), '<input type="text" name="refund_desc" value="" style="width: 95%;" />'));

            showtablefooter(); /*dism-Taobao-com*/
            ///////////////////// 提交
            showtableheader(); /*dism·taobao·com*/
            showsubmit('savesubmit');
            showtablefooter(); /*dism-Taobao-com*/
            showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
        }else{
            cpmsg(lang('plugin/nayuan_pay', 'error_refund_invalid_order'), 'action=' . $adminurl, 'error');
        }
    }

}

?>