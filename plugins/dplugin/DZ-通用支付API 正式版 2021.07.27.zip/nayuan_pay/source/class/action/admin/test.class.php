<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      test.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_test {

    public function index() {
        global $_G, $adminurl;
        $settings = $_G['cache']['nayuan_pay'];
        $currency = $settings['setting']['currency'];
        if(!$currency) {
            $currency = 'CNY';
        }
        $currency_cache = nayuan_options('plugin/nayuan_pay', 'admin_setting_currency_options');
        $currency_options = array();
        foreach ($currency_cache as $name => $title) {
            $currency_options[] = array($name, $title);
        }

        showtips(lang('plugin/nayuan_pay', 'admin_test_tips'));
        showformheader($adminurl . '&mmo=order', 'target="_blank"');
        showtableheader(); /*dism·taobao·com*/
        showsetting(lang('plugin/nayuan_pay', 'admin_test_currency'), array('data[currency]', $currency_options), $currency, 'select');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_amount'), 'data[amount]', '1', 'number', '', 0, $currency == 'CNY' ? lang('plugin/nayuan_pay', 'yuan') : $currency_cache[$currency]);
        showsetting(lang('plugin/nayuan_pay', 'admin_order_header_subject'), 'data[subject]', 'test', 'text');
        showsetting(lang('plugin/nayuan_pay', 'admin_order_header_desc'), 'data[desc]', 'test', 'text');
        $type_list = C::t('#nayuan_pay#nayuan_type') -> fetch_all_type();
        $type_data = array();
        foreach ($type_list as $type) {
            $type_data[] = array($type['code'], $type['name']);
        }
        showsetting(lang('plugin/nayuan_pay', 'admin_order_header_type'), array('data[type]', $type_data), '', 'select');
        showtablefooter(); /*dism-Taobao-com*/
        ///////////////////// 提交
        showtableheader(); /*dism·taobao·com*/
        showsubmit('savesubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
    }

    public function order() {
        global $_G;
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/order.func.php';

        $data = nayuan_get('data', 3);
        $data['amount'] = max(1, $data['amount']) * 100;
        $callback_path = 'source/plugin/nayuan_pay/source/function/test.func.php';
        $callback_func = 'nayuan_pay_test';
        $callback_data = array('data' => 'test');
        $pay_url = nayuan_pay_create_order('test', $data['subject'], $data['desc'], $data['amount'], $data['amount'], $_G['siteurl'], $callback_path, $callback_func, $callback_data, 1, $data['currency']);
        dheader("Location: $pay_url");
    }

}

?>