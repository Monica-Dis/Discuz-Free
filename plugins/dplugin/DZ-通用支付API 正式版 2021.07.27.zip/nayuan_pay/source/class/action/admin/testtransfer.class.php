<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      testtransfer.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_testtransfer {

    public function index() {
        global $_G, $adminurl;

        showtips(lang('plugin/nayuan_pay', 'admin_test_transfer_tips'));
        showformheader($adminurl . '&mmo=order');
        showtableheader(); /*dism·taobao·com*/
        $type_cache = nayuan_options('plugin/nayuan_pay', 'admin_test_transfer_type_options');
        $type_options = array();
        foreach ($type_cache as $name => $title) {
            $type_options[] = array($name, $title);
        }
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_amount'), 'data[amount]', '1', 'number');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_realname'), 'data[realname]', '', 'text');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_account'), 'data[account]', '', 'text');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_title'), 'data[subject]', 'test', 'text');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_desc'), 'data[desc]', 'test', 'text');
        showsetting(lang('plugin/nayuan_pay', 'admin_test_transfer_type'), array('data[type]', $type_options), 'alipay', 'select');
        showtablefooter(); /*dism-Taobao-com*/
        ///////////////////// 提交
        showtableheader(); /*dism·taobao·com*/
        showsubmit('savesubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
    }

    public function order() {
        global $_G;
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/order.func.php';

        $data = nayuan_get('data', 3);
        if($data['type'] == 'alipay') {
            $result = nayuan_pay_alipay_transfer($_G['uid'], time(), intval($data['amount']) * 100, $data['realname'], $data['account'], $data['subject'], $data['desc']);
        }
        if($result['code'] != 200) {
            cpmsg($result['message'], '', 'error');
        }else{
            cpmsg('nayuan_pay:admin_test_transfer_success', '', 'succeed');
        }

    }

}

?>