<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      alipay.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_alipay {

    public function index() {
        global $_G, $adminurl;
        $settings = $_G['cache']['nayuan_pay'];
        $alipaysettings = $settings['mc_list']['alipay'];
        showtips(lang('plugin/nayuan_pay', 'admin_alipay_tips'));
        showformheader($adminurl . '&mmo=save');
        $currencies = 'CNY';
        showhiddenfields(array('data[currencies]' => $currencies));
        showtableheader(); /*dism·taobao·com*/
        showtagheader('tbody', 'common_setting', true);
        $is_readonly = '';
        $tips = '';
        if($settings['setting']['currency'] && !in_array($settings['setting']['currency'], explode(',', $currencies))) {
            $currency_cache = nayuan_options('plugin/nayuan_pay', 'admin_setting_currency_options');
            $is_readonly = 'readonly';
            $tips = lang('plugin/nayuan_pay', 'error_invalid_transfer_type') . $currency_cache[$settings['setting']['currency']];
            $alipaysettings['on'] = 0;
        }
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_status'), 'data[on]', $alipaysettings['on'], 'radio', $is_readonly, 0, $tips);

        $check = array();
        $alipaysettings['sign_type'] ? $check['true'] = "checked" : $check['false'] = "checked";
        $alipaysettings['sign_type'] ? $check['false'] = '' : $check['true'] = '';
        $check['hidden1'] = ' onclick="$(\'sign_model_01\').style.display = \'none\';$(\'sign_model_02\').style.display = \'\';"';
        $check['hidden0'] = ' onclick="$(\'sign_model_01\').style.display = \'\';$(\'sign_model_02\').style.display = \'none\';"';
        $html = '<ul onmouseover="altStyle(this);">' .
                    '<li'.($check['false'] ? ' class="checked"' : '').'><input class="radio" type="radio" name="data[sign_type]" value="0" '.$check['false'].$check['hidden0'].'>&nbsp;'.lang('plugin/nayuan_pay', 'admin_alipay_sign_model_01').'</li>'.
                    '<li'.($check['true'] ? ' class="checked"' : '').'><input class="radio" type="radio" name="data[sign_type]" value="1" '.$check['true'].$check['hidden1'].'>&nbsp;'.lang('plugin/nayuan_pay', 'admin_alipay_sign_model_02').'</li>'.
                '</ul>';
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_sign_model'), '', '', $html, '', 0, lang('plugin/nayuan_pay', ''));
        showtagfooter('tbody');

        showtagheader('tbody', 'sign_model_01', !$alipaysettings['sign_type']);
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_appid'), 'data[appid]', $alipaysettings['appid'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_alipay_appid_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_app_private_key'), 'data[private_key]', $alipaysettings['private_key'], 'textarea');
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_alipay_public_key'), 'data[public_key]', $alipaysettings['public_key'], 'textarea');
        showtagfooter('tbody');

        showtagheader('tbody', 'sign_model_02', $alipaysettings['sign_type']);
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_appid'), 'data[cert_appid]', $alipaysettings['cert_appid'], 'text', '', 0, lang('plugin/nayuan_pay', 'admin_alipay_appid_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_app_private_key'), 'data[app_private_key]', $alipaysettings['app_private_key'], 'textarea');
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_app_cert'), 'data[app_cert]', $alipaysettings['app_cert'], 'textarea', '', 0, lang('plugin/nayuan_pay', 'admin_alipay_app_cert_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_alipay_cert'), 'data[alipay_cert]', $alipaysettings['alipay_cert'], 'textarea', '', 0, lang('plugin/nayuan_pay', 'admin_alipay_alipay_cert_tips'));
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_alipay_root_cert'), 'data[alipay_root_cert]', $alipaysettings['alipay_root_cert'], 'textarea', '', 0, lang('plugin/nayuan_pay', 'admin_alipay_alipay_root_cert_tips'));
        showtagfooter('tbody');

        showtagheader('tbody', 'common_setting_footer', true);
        showsetting(lang('plugin/nayuan_pay', 'admin_alipay_order'), 'data[order]', $alipaysettings['order'] ? $alipaysettings['order'] : 100, 'number');
        showtagfooter('tbody');
        showtablefooter(); /*dism-Taobao-com*/
        ///////////////////// 提交
        showtableheader(); /*dism·taobao·com*/
        showsubmit('savesubmit');
        showtablefooter(); /*dism-Taobao-com*/
        showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
    }

    public function save() {
        global $_G, $adminurl;
        if(submitcheck('savesubmit')) {
            $settings = $_G['cache']['nayuan_pay'];
            $data = nayuan_get('data', 3);
            $settings['mc_list']['alipay'] = $data;
            savecache('nayuan_pay', $settings);
        }
        cpmsg(lang('plugin/nayuan_pay', 'save_success'), 'action=' . $adminurl, 'succeed');
    }

}

?>