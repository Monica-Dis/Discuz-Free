<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      apirefund.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

class nayuan_action_admin_apirefund {

    public function index() {
        global $_G, $adminurl;

        showtips(lang('plugin/nayuan_pay', 'admin_api_tips'));

        showtableheader(lang('plugin/nayuan_pay', 'admin_apirefund'));
        $text = lang('plugin/nayuan_pay', 'admin_apirefund_e_text_01');
        $text .= '<br/><br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_02');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_03');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_04');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_05');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_06');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_07');
        $text .= '<br/><br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_08');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_09');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_10');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_11');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_12');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_e_text_13');
        showtablerow('', array('style="width: 120px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_apirefund_e'), $text));
        showtablefooter(); /*dism-Taobao-com*/

        $text = '';
        showtableheader(lang('plugin/nayuan_pay', 'admin_apirefund_status'));
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_01');
        $text .= '<br/><br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_02');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_03');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_04');
        $text .= '<br/><br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_05');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_06');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_07');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_08');
        $text .= '<br/>' . lang('plugin/nayuan_pay', 'admin_apirefund_status_e_text_09');

        showtablerow('', array('style="width: 120px; font-weight: bold;"', ''), array(lang('plugin/nayuan_pay', 'admin_apirefund_status_e'), $text));

        showtablefooter(); /*dism-Taobao-com*/
    }

}

?>