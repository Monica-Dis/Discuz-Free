<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      weixin.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/action/basepay.class.php';

class nayuan_action_weixin extends nayuan_action_basepay {

    public function pay() {
        global $_G, $apiurl;
        $weixinsettings = $_G['cache']['nayuan_pay']['mc_list']['weixin'];
        if(!$weixinsettings['on']) {
            $this -> error_message(1, 'error_invalid_way');
        }

        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        $this -> validate_order($order);

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';
        if($weixinsettings['api_version'] && !sdk_v3_weixin_support()) {
            $this -> error_message(1, 'admin_weixin_php_version_low', $_G['siteurl'] . 'plugin.php?id=nayuan_pay&mma=pay&oid=' . $oid);
        }

        $notify_url = $_G['siteurl'] . 'source/plugin/nayuan_pay/notify/weixinnotify.php';
        $device = nayuan_device();
        if($device) {
            if(in_array($device, array('weixin', 'miniprogram'))) {
                $redirect_uri = $_G['siteurl'] . 'plugin.php?id=nayuan_pay&mma=weixin&mmo=wxjsapi&oid=' . $oid;
                $redirect_uri = urlencode($redirect_uri);
                $state = md5(random(32));
                $pay_url = sdk_weixin_authorize($weixinsettings, $redirect_uri, $state);
            }else{
                if($weixinsettings['api_version']) {
                    $result = sdk_v3_weixin_h5_pay($weixinsettings, $order, $notify_url);
                }else{
                    $result = sdk_weixin_unifiedorder_pay($weixinsettings, $order, $notify_url, 'MWEB');
                }
                $pay_url = $result['code_url'];
            }
        }else{
            if($weixinsettings['api_version']) {
                $result = sdk_v3_weixin_native_pay($weixinsettings, $order, $notify_url);
            }else{
                $result = sdk_weixin_unifiedorder_pay($weixinsettings, $order, $notify_url, 'NATIVE');
            }
            $pay_url = $result['code_url'];
        }

        if(!$pay_url) {
            if(strtoupper($_G['charset']) != 'UTF-8') {
                $result['error_message'] = diconv($result['error_message'], 'UTF-8', $_G['charset']);
            }
            $this -> error_message(0, $result['error_message'], $order['referer_url']);
        }

        if(defined('IN_MOBILE')) {
            require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/json.func.php';
            echo nayuan_json(array('code' => 200, 'url' => $pay_url));
            exit;
        }
        include template('nayuan_pay:pay_weixin');
    }

    public function wxjsapi() {
        global $_G, $apiurl;
        $weixinsettings = $_G['cache']['nayuan_pay']['mc_list']['weixin'];
        if(!$weixinsettings['on']) {
            $this -> error_message(1, 'error_invalid_way');
        }

        $code = nayuan_get('code', 1);
        $state = nayuan_get('state', 1);
        $oid = nayuan_get('oid');
        if(!$code || !$state || !oid) {
            $this -> error_message(1, 'error_invalid_request');
        }

        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        $this -> validate_order($order);

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';

        $result = sdk_weixin_access_token_by_code($weixinsettings, $code);
        $result = json_decode($result, true);
        if(!$result['openid']) {
            if(strtoupper($_G['charset']) != 'UTF-8') {
                $result['errmsg'] = diconv($result['errmsg'], 'UTF-8', $_G['charset']);
            }
            $this -> error_message(0, $result['errmsg'], $order['referer_url']);
        }

        $notify_url = $_G['siteurl'] . 'source/plugin/nayuan_pay/notify/weixinnotify.php';
        if($weixinsettings['api_version']) {
            $result = sdk_v3_weixin_h5_jsapi($weixinsettings, $result['openid'], $order, $notify_url);
        }else{
            $result = sdk_weixin_unifiedorder_pay($weixinsettings, $order, $notify_url, 'JSAPI', $result['openid']);
        }
        if(!$result['prepay_id']) {
            if(strtoupper($_G['charset']) != 'UTF-8') {
                $result['error_message'] = diconv($result['error_message'], 'UTF-8', $_G['charset']);
            }
            $this -> error_message(0, $result['error_message'], $order['referer_url']);
        }

        $jsapidata = [
            'appId' => $weixinsettings['appid'],
            'timeStamp' => time() . '',
            'nonceStr' => sdk_weixin_nonce(),
            'package' => 'prepay_id=' . $result['prepay_id'],
            'signType' => 'MD5',
        ];
        $jsapidata['paySign'] = sdk_weixin_sign($weixinsettings, $jsapidata);
        $jsapidata = json_encode($jsapidata);

        include template('nayuan_pay:pay_weixin_jsapi');
    }

    public function status() {
        global $_G, $staticurl, $apiurl;
        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        if($order['uid'] != $_G['uid']) {
            $status = 9;
            $referer_url = $_G['siteurl'];
        }else{
            $status = $order['status'];
            $referer_url = $order['referer_url'];
        }
        if($status) {
            showmessage('nayuan_pay:pay_success', $referer_url);
        }
        exit;
    }

    public function callback() {
        global $_G;
        $weixinsettings = $_G['cache']['nayuan_pay']['mc_list']['weixin'];
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';

        if ($_SERVER['HTTP_WECHATPAY_SIGNATURE']) {
            $data = sdk_v3_weixin_sign_verify();
            if ($data) {
                $data = json_decode($data, true);
            }
            if ($data && $data['trade_state'] == 'SUCCESS') {
                $out_biz_no = $data['out_trade_no'];
                $payment_time = strtotime($data['success_time']);
                $status = $this -> exec_order($out_biz_no, 'weixin', $data['transaction_id'], $payment_time);
                if($status) {
                    exit('{"code":"SUCCESS","message":"ok"}');
                }else{
                    writelog('pay', '[ERROR] weixin-notify out_trade_no: ' . $out_biz_no . ', data: ' . json_encode($data));
                }
            }
            exit('{"code":"fail","message":"fail"}');
        }else{
            $data = sdk_weixin_sign_verify($weixinsettings);
            if($data) {
                $oid = $data['out_trade_no'];
                $pay_time = strtotime(preg_replace('/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/', '$1-$2-$3 $4:$5:$6', $data['time_end']));
                $status = $this -> exec_order($oid, 'weixin', $data['transaction_id'], $pay_time);
                if($status) {
                    echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
                }
            }else{
                echo '<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[FAIL]]></return_msg></xml>';
            }
            exit();
        }
    }

}

?>