<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      pay.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/action/basepay.class.php';

class nayuan_action_pay extends nayuan_action_basepay {

    public function index() {
        global $_G, $staticurl, $apiurl;
        $settings = $_G['cache']['nayuan_pay'];
        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        $this -> validate_order($order);

        $currency = $order['currency'];
        if(!$currency) {
            $currency = 'CNY';
        }

        $mc_list = $_G['cache']['nayuan_pay']['mc_list'];
        $pay_way_list = array();
        foreach ($mc_list as $name => $data) {
            if(!$data['on']) continue;
            if(!$data['currencies']) {
                $data['currencies'] = 'CNY';
            }

            if(!in_array($currency, explode(',', $data['currencies']))) continue;
            $pay_way_list[intval($data['order'])] = $name;
        }

        if(!$pay_way_list) {
            showmessage('nayuan_pay:error_not_found_payway');
        }
        uksort($pay_way_list, function($a, $b) { return intval($a) < intval($b);});
        foreach ($pay_way_list as $index => $name) {
            $check_index = $index;
            $check_name = $name;
            unset($index, $name);
            break;
        }

        $order['receipt_amount'] = $order['receipt_amount'] / 100;
        if($order['total_amount']) {
            $order['total_amount'] = $order['total_amount'] / 100;
        }

        $navtitle = lang('plugin/nayuan_pay', 'page_pay_title');
        $device = nayuan_device();

        include template('nayuan_pay:pay');
    }

}

?>