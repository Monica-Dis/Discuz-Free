<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      alipay.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/action/basepay.class.php';

class nayuan_action_alipay extends nayuan_action_basepay {

    public function pay() {
        global $_G, $apiurl;
        $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];
        if(!$alipaysettings['on']) {
            showmessage('nayuan_pay:error_invalid_way');
        }

        $oid = nayuan_get('oid');
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch($oid);
        $this -> validate_order($order);

        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
        $notify_url = $_G['siteurl'] . 'source/plugin/nayuan_pay/notify/alipaynotify.php';
        $return_url = $_G['siteurl'] . 'source/plugin/nayuan_pay/notify/alipayreturn.php';
        if(defined('IN_MOBILE')) {
            $result = sdk_alipay_trade_wap_pay($alipaysettings, $order, $notify_url, $return_url);
        }else{
            $result = sdk_alipay_trade_page_pay($alipaysettings, $order, $notify_url, $return_url);
        }

        if(preg_match('/^https?:\/\/.+$/', $result)) {
            $issuccess = true;
        }else{
            if(preg_match('/<div\s+class="Todo">([^<]+)<\/div>/i', $result, $matchers)) {
                $this -> error_message(0, $matchers[1], $order['referer_url']);
            }
        }

        if($issuccess && defined('IN_MOBILE')) {
            require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/json.func.php';
            echo nayuan_json(array('code' => 200, 'url' => $result));
            exit;
        }
        include template('nayuan_pay:pay_alipay');
    }

    public function status() {
        global $_G, $apiurl;
        $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];

        $oid = $_GET['out_trade_no'];
        $sign = $_GET['sign'];
        unset($_GET['sign'], $_GET['mma'], $_GET['mmo']);
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
        $isright = sdk_alipay_sign_verify($alipaysettings, $sign, $_GET);
        if($isright) {
            if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
                $pay_time = strtotime($_POST['gmt_payment']);
                $status = $this -> exec_order($oid, 'alipay', $_GET['trade_no'], $pay_time);
            }
        }
        dheader('Location: ' . $apiurl . '&mma=alipay&mmo=success&oid=' . $oid);
    }

    public function success() {
        $oid = nayuan_get('oid', 1);
        $order = C::t('#nayuan_pay#nayuan_order') -> fetch_order_by_order_id($oid);
        showmessage('nayuan_pay:pay_success', $order['referer_url'], array(), array('alert' => 'right'));
    }

    public function callback() {
        global $_G;

        $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];
        if(!$_POST['sign'] || !$_POST['sign_type']) exit('fail');

        $sign = $_POST['sign'];
        unset($_POST['sign']);
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
        $isright = sdk_alipay_sign_verify($alipaysettings, $sign, $_POST);
        if(!$isright) {
            writelog('nayuan-pay', '[ERROR] alipay notify sign error. sign: ' . $_POST['sign_type'] . ': ' . $sign . 'data: ' . json_encode($_POST));
            exit('fail');
        }

        if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
            $oid = $_POST['out_trade_no'];
            $pay_time = strtotime($_POST['gmt_payment']);
            $status = $this -> exec_order($oid, 'alipay', $_POST['trade_no'], $pay_time);
            if($status) {
                exit('success');
            }
        }
        exit('fail');
    }

}

?>