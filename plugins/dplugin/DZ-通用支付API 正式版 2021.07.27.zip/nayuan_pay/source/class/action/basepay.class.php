<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      basepay.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class nayuan_action_basepay {

    protected function validate_order($order) {
        global $_G;
        if(!$_G['uid'] && $order['login']) {
            $this -> error_message(1, 'error_no_login');
        }
        if(!$order) {
            $this -> error_message(1, 'error_not_found_order', $_G['siteurl']);
        }
        if($order['uid'] != $_G['uid']) {
            $this -> error_message(1, 'error_not_found_order', $order['referer_url']);
        }
        if($order['status']) {
            $this -> error_message(1, 'error_invalid_order_status', $order['referer_url']);
        }
        if($order['expire_time'] < time()) {
            $this -> error_message(1, 'error_order_timeout', $order['referer_url']);
        }
    }

    protected function error_message($lang, $message, $referer = '') {
        global $_G;
        if(defined('IN_MOBILE') && $_GET['inajax']) {
            require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/json.func.php';
            if($lang) {
                $message = lang('plugin/nayuan_pay', $message);
            }
            if(strtoupper($_G['charset']) != 'UTF-8') {
                $message = diconv($message, $_G['charset'], 'UTF-8');
            }
            echo nayuan_json(array('code' => 500, 'message' => $message));
            exit();
        }else{
            showmessage($lang ? 'nayuan_pay:' . $message : $message, $referer, array(), array('showdialog' => true));
        }
    }

    public function exec_order($oid, $type, $trade_no, $pay_time) {
        if(!discuz_process::islocked('nayuan_pay_' . $oid, 600)) {
            $order = C::t('#nayuan_pay#nayuan_order') -> fetch_order_by_order_id($oid);
            if(!$order) {
                discuz_process::unlock('nayuan_pay_' . $oid);
                return false;
            }
            if($order['status']) {
                discuz_process::unlock('nayuan_pay_' . $oid);
                return true;
            }

            $order['trade_no'] = $trade_no;
            $order['pay_time'] = $pay_time;
            $order['pay_type'] = $type;
            $order['status'] = 1;

            DB::query('start transaction');
            C::t('#nayuan_pay#nayuan_order') -> update($order['id'], array(
                'trade_no'  => $order['trade_no'],
                'pay_time'  => $order['pay_time'],
                'pay_type'  => $order['pay_type'],
                'status'    => $order['status']
            ));
            if($order['callback_func']) {
                try{
                    require_once DISCUZ_ROOT . $order['callback_path'];
                    $callback_func = $order['callback_func'];
                    $callback_data = dunserialize($order['callback_data']);
                    if(function_exists($callback_func)) {
                        $callback_order = array(
                            'id' => $order['order_id'],
                            'type' => $order['type'],
                            'uid' => $order['uid'],
                            'currency' => $order['currency'],
                            'amount' => $order['receipt_amount'],
                            'subject' => $order['subject'],
                            'desc' => $order['desc'],
                            'time' => $order['time'],
                            'pay_type' => $order['pay_type'],
                            'pay_time' => $order['pay_time'],
                        );
                        $callback_func($callback_data, $callback_order);
                    }
                }catch (Exception $e) {
                    writelog('nayuan-pay', '[ERROR] ' . $oid . '|' . $type . '|' . $trade_no . '|' . $e -> getMessage());
                }
            }
            DB::query('commit');
            discuz_process::unlock('nayuan_pay_' . $oid);
            return true;
        }else{
            return false;
        }
    }

}

?>