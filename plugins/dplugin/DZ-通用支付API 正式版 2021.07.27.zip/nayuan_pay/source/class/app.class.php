<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      app.class.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/front.func.php';

class nayuan_app {

    var $action = null;
    var $method = null;

    function &instance() {
        static $object;
        if(empty($object)) {
            $object = new nayuan_app();
        }
        return $object;
    }

    function __construct() {}

    function init() {
        $this -> action = nayuan_get('mma', 1, 'index');
        if(!preg_match('/^[0-9a-zA-Z_]+$/', $this -> action)) {
            exit('Access Denied');
        }
        $this -> method = nayuan_get('mmo', 1, 'index');
        if(!preg_match('/^[0-9a-zA-Z]+$/', $this -> method)) {
            exit('Access Denied');
        }
        loadcache('nayuan_pay');
    }

    function request() {
        $class = DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/class/action/' . str_replace('_', '/', $this -> action) . '.class.php';
        if(!file_exists($class)) exit('Access Denied');

        require_once $class;
        $action = 'nayuan_action_' . $this -> action;
        $nayuanaction = new $action();

        if(!method_exists($nayuanaction, $this -> method)) exit('Access Denied');
        $method = $this -> method;
        $nayuanaction -> $method();
    }

}

?>