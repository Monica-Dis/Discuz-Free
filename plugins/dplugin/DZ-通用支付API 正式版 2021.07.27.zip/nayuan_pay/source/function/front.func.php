<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      front.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_get($name, $type = 0, $default = '') {
    $value = $_GET[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_post($name, $type = 0, $default = '') {
    $value = $_POST[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_strreplace($str, $vars) {
    if($vars && is_array($vars)) {
        foreach($vars as $k => $v) {
            $searchs[] = '{'.$k.'}';
            $replaces[] = $v;
        }
    }
    if(is_string($str) && strpos($str, '{_G/') !== false) {
        preg_match_all('/\{_G\/(.+?)\}/', $str, $gvar);
        foreach($gvar[0] as $k => $v) {
            $searchs[] = $v;
            $replaces[] = getglobal($gvar[1][$k]);
        }
    }
    return str_replace($searchs, $replaces, $str);
}

function nayuan_options($file, $langvar = null) {
    parse_str(lang($file, $langvar), $_list);
    return $_list;
}

function nayuan_format_filesize($size, $prec = 3) {
    if($size < 1024) {
        return $size . 'B';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'K';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'M';
    }
    $size /= 1024;
    return round($size, $prec) . 'G';
}

function nayuan_result_json($data, $code = '200', $message = '') {
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/json.func.php';
    echo nayuan_json(array('code' => $code, 'message' => $message, 'result' => $data));
    exit;
}

function nayuan_dnumber($number, $precision = 2) {
    return abs($number) > 10000 ? '<span title="'.$number.'">'.round($number / 10000, $precision).'</span>'.lang('core', '10k') : $number;
}

function nayuan_format_days_decimal($offset) {
    $resultstr = '';
    if($offset < 1) return $resultstr;
    $days = floor($offset / 86400);
    if($days > 0) {
        $resultstr .= $days;
    }
    $offset = $offset % 86400;
    $hour = ceil($offset / 3600 * 10 / 24);
    if($hour > 0) {
        $resultstr .= '.' . $hour;
    }
    return $resultstr;
}

function nayuan_device() {
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    if(strpos($useragent, 'MAGAPPX') !== false) {
        return 'magappx';
    }else if(strpos($useragent, 'MicroMessenger') !== false) {
        return 'weixin';
    }else if(strpos($useragent, 'miniprogram') !== false) {
        return 'miniprogram';
    }else if(strpos($useragent, 'iPhone') || strpos($useragent, 'iPad')) {
        return 'ios';
    }else if(strpos($useragent, 'Android')) {
        return 'android';
    }else{
        return checkmobile();
    }
}

function nayuan_rewrite_url($mma, $mmo, $ext = '') {
    global $_G, $rewrite_rule;
    if($rewrite_rule) {
        return $_G['siteurl'] . str_replace(array('{mma}', '{mmo}'), array($mma, $mmo), $rewrite_rule) . ($ext ? '?' . $ext : '');
    }else{
        return $_G['siteurl'] . 'plugin.php?id=nayuan_pay&mma=' . $mma . '&mmo=' . $mmo . ($ext ? '&' . $ext : '');
    }
}

?>