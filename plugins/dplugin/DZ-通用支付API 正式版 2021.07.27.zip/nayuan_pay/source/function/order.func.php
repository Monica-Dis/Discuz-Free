<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      order.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_pay_currency() {
	global $_G;
	loadcache('nayuan_pay');
	$settings = $_G['cache']['nayuan_pay'];
	if(!$settings['setting']['currencys']) {
		$settings['setting']['currencys'][] = 'CNY';
	}
	foreach($settings['setting']['currencys'] as $currency) {
		return $currency;
	}
}

function nayuan_pay_currencys() {
    global $_G;
    loadcache('nayuan_pay');
    $settings = $_G['cache']['nayuan_pay'];
    if(!$settings['setting']['currencys']) {
		$settings['setting']['currencys'][] = 'CNY';
	}

    $result = array();
	parse_str(lang('plugin/nayuan_pay', 'admin_setting_currency_options'), $currency_cache);
    foreach($settings['setting']['currencys'] as $currency) {
    	$result[$currency] = $currency_cache[$currency];
	}
    return $result;
}

function nayuan_pay_currency_all() {
	parse_str(lang('plugin/nayuan_pay', 'admin_setting_currency_options'), $data);
	return $data;
}

function nayuan_pay_add_type($code, $name, $desc) {
    C::t('#nayuan_pay#nayuan_type') -> insert(array(
        'code' => $code,
        'name' => $name,
        'desc' => $desc,
        'time' => time()
    ));
    return true;
}

function nayuan_pay_create_order($type, $title, $desc, $total_amount, $receipt_amount, $referer_url, $callback_path = NULL, $callback_func = NULL, $callback_data = NULL, $login = 1, $currency = '') {
    global $_G;

    loadcache('nayuan_pay');
    $settings = $_G['cache']['nayuan_pay'];
    if(!$currency) {
        $currency = $settings['setting']['currency'];
        if(!$currency) {
            $currency = 'CNY';
        }
    }

    $exist_type = C::t('#nayuan_pay#nayuan_type') -> fetch_type_name($type);
    if(!$exist_type) {
        if(strpos($type, ':') !== TRUE) {
            $values = explode(':', $type);
            $name = lang('plugin/' . $values[0], $values[1]);
            if(!$name) {
                $name = $type;
            }
        }else{
            $name = $type;
        }
        C::t('#nayuan_pay#nayuan_type') -> insert(array(
            'code' => $type,
            'name' => $name,
            'desc' => '',
            'time' => time()
        ));
    }

    $data = array(
        'order_id' => dgmdate(time(), 'YmdHis') . rand(10000, 99999),
        'uid' => $_G['uid'],
        'type' => $type,
        'total_amount' => $total_amount,
        'receipt_amount' => $receipt_amount,
        'subject' => $title,
        'desc' => $desc,
        'currency' => $currency,
        'expire_time' => time() + 3600,
        'time' => time(),
        'referer_url' => $referer_url,
        'callback_path' => $callback_path,
        'callback_func' => $callback_func,
        'callback_data' => serialize($callback_data),
        'status' => 0,
        'login' => $login
    );
    $id = C::t('#nayuan_pay#nayuan_order') -> insert($data, true);
    return $_G['siteurl'] . 'plugin.php?id=nayuan_pay&mma=pay&oid=' . $id;
}

function nayuan_pay_refund($refund_no, $order_id, $refund_message, $amount = 0) {
    global $_G;

    if(!$refund_no) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_empty_refund_no'));
    }
    $order = C::t('#nayuan_pay#nayuan_order') -> fetch($order_id);
    if(!$order) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_not_found_order'));
    }
    if(!in_array($order['status'], array(1,2))) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_order_no_pay'));
    }else if($order['status'] == 2) {
        $refund_amount = C::t('#nayuan_pay#nayuan_refund') -> sum_refund_amount($order['id']);
        if($refund_amount && $refund_amount >= $order['receipt_amount']) {
            return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_order_amount'));
        }
    }

    if(!$amount) {
        $amount = $order['receipt_amount'];
    }

    loadcache('nayuan_pay');
    if($order['pay_type'] == 'weixin') {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';
        $weixinsettings = $_G['cache']['nayuan_pay']['mc_list']['weixin'];
        $result = sdk_weixin_refund($weixinsettings, $refund_no, $order['trade_no'], $order['receipt_amount'], $amount, $refund_message);
    }else if($order['pay_type'] == 'alipay') {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
        $amount = sprintf('%.2f', $amount / 100);
        $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];
        $result = sdk_alipay_refund($alipaysettings, $refund_no, $order['trade_no'], $amount, $refund_message);
    }

    $data = array(
        'oid' => $order['id'],
        'refund_no' => $refund_no,
        'amount' => $amount,
        'desc' => $refund_message,
    );
    if($result['code'] != 200) {
        $data['status'] = 2;
        $data['error'] = $result['message'];
    }else{
        $data['status'] = 1;
        $data['refund_time'] = $result['data']['time'];
        C::t('#nayuan_pay#nayuan_order') -> update($order['id'], array('status' => 2));
    }

    $refund_order = C::t('#nayuan_pay#nayuan_refund') -> fetch_by_refund($refund_no);
    if($refund_order) {
        C::t('#nayuan_pay#nayuan_refund') -> update($refund_order['id'], $data);
    }else{
        C::t('#nayuan_pay#nayuan_refund') -> insert($data);
    }
    return $result;
}

function nayuan_pay_refund_status($refund_no, $order_id) {
    global $_G;

    if(!$refund_no) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_empty_refund_no'));
    }
    $order = C::t('#nayuan_pay#nayuan_order') -> fetch($order_id);
    if(!$order) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_not_found_order'));
    }

    loadcache('nayuan_pay');
    if($order['pay_type'] == 'weixin') {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/weixin.func.php';
        $weixinsettings = $_G['cache']['nayuan_pay']['mc_list']['weixin'];
        $result = sdk_weixin_refund_status($weixinsettings, $refund_no);
    }else if($order['pay_type'] == 'alipay') {
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
        $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];
        $result = sdk_alipay_refund_status($alipaysettings, $order['trade_no'], $refund_no);
    }
    if($result['code'] != 200) {
        $data['status'] = 2;
        $data['error'] = $result['message'];
    }else{
        $data['status'] = 1;
        $data['refund_time'] = $result['data']['time'];
        C::t('#nayuan_pay#nayuan_order') -> update($order['id'], array('status' => 2));
    }

    $refund_order = C::t('#nayuan_pay#nayuan_refund') -> fetch_by_refund($refund_no);
    if($refund_order) {
        C::t('#nayuan_pay#nayuan_refund') -> update($refund_order['id'], $data);
    }else{
        C::t('#nayuan_pay#nayuan_refund') -> insert($refund_order['id'], $data);
    }
    return $result;
}

function nayuan_pay_alipay_transfer($touid, $no, $amount, $realname, $account, $title = '', $desc = '') {
    global $_G;
    $order = C::t('#nayuan_pay#nayuan_transfer') -> fetch_order_by_no($no);
    if($order) {
        if($order['amount'] != $amount || $order['uid'] != $touid || $realname != $order['name'] || $account != $order['account']) {
            return array(
                'code' => 500,
                'message' => lang('plugin/nayuan_pay', 'error_biz_no')
            );
        }
        C::t('#nayuan_pay#nayuan_transfer') -> update($order['id'], array(
            'status' => 1,
            'subject' => $title,
            'desc' => $desc
        ));
        $id = $order['id'];
    }else{
        $id = C::t('#nayuan_pay#nayuan_transfer') -> insert(array(
            'uid' => $touid,
            'order_id' => $no,
            'amount' => $amount,
            'currency' => 'CNY',
            'subject' => $title,
            'desc' => $desc,
            'name' => $realname,
            'account' => $account,
            'type' => 'alipay',
            'status' => 1,
            'time' => time()
        ), true);
    }

    loadcache('nayuan_pay');
    $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];
    if(!$alipaysettings['sign_type']) {
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_alipay_cert'));
    }

    require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
    $result = sdk_alipay_fund_trans_uni_transfer($alipaysettings, $no, $amount, $realname, $account, $title, $desc);
    if($result && is_array($result) && $result['alipay_fund_trans_uni_transfer_response']) {
        $result = $result['alipay_fund_trans_uni_transfer_response'];
        if($result['order_id']) {
            if($result['status'] == 'SUCCESS') {
                C::t('#nayuan_pay#nayuan_transfer') -> update($id, array(
                    'trade_no' => $result['order_id'],
                    'status' => 2,
                    'pay_time' => strtotime($result['trans_date'])
                ));
                return array('code' => 200, 'data' => array('bill_time' => strtotime($result['trans_date'])));
            }else if($result['status'] == 'FAIL') {
                C::t('#nayuan_pay#nayuan_transfer') -> update($id, array(
                    'trade_no' => $result['order_id'],
                    'status' => 3,
                    'error' => $result['fail_reason']
                ));
                return array('code' => $result['error_code'], 'message' => $result['fail_reason']);
            }else if($result['status'] == 'REFUND') {
                C::t('#nayuan_pay#nayuan_transfer') -> update($id, array(
                    'trade_no' => $result['order_id'],
                    'status' => 3,
                    'error' => 'REFUND'
                ));
                return array('code' => 500, 'message' => 'REFUND');
            }else{
                return array('code' => 201);
            }
        }else{
            if(strpos($result['sub_msg'], ':') !== false) {
                $result['sub_msg'] = ': ' . $result['sub_msg'];
            }
            C::t('#nayuan_pay#nayuan_transfer') -> update($id, array(
                'trade_no' => $result['order_id'],
                'status' => 3,
                'error' => '[' . $result['msg'] . '] ' . $result['sub_msg']
            ));
            return array('code' => $result['code'], 'message' => '[' . $result['msg'] . '] ' . $result['sub_msg']);
        }
    }else{
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_unknown'));
    }
}

function nayuan_pay_alipay_transfer_status($no) {
    global $_G;

    loadcache('nayuan_pay');
    $alipaysettings = $_G['cache']['nayuan_pay']['mc_list']['alipay'];

    require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/sdk/alipay.func.php';
    $result = sdk_alipay_fund_trans_order_query($alipaysettings, $no);
    if($result && is_array($result) && $result['alipay_fund_trans_order_query_response']) {
        $result = $result['alipay_fund_trans_order_query_response'];
        if($result['order_id']) {
            if($result['status'] == 'SUCCESS') {
                C::t('#nayuan_pay#nayuan_transfer') -> update_order_by_no($no, array(
                    'trade_no' => $result['order_id'],
                    'status' => 2,
                    'pay_time' => strtotime($result['trans_date'])
                ));
                return array('code' => 200, 'data' => array('bill_time' => strtotime($result['trans_date'])));
            }else if($result['status'] == 'FAIL') {
                C::t('#nayuan_pay#nayuan_transfer') -> update_order_by_no($no, array(
                    'trade_no' => $result['order_id'],
                    'status' => 3,
                    'error' => $result['fail_reason']
                ));
                return array('code' => $result['error_code'], 'message' => $result['fail_reason']);
            }else if($result['status'] == 'REFUND') {
                C::t('#nayuan_pay#nayuan_transfer') -> update_order_by_no($no, array(
                    'trade_no' => $result['order_id'],
                    'status' => 3,
                    'error' => 'REFUND'
                ));
                return array('code' => 500, 'message' => 'REFUND');
            }else{
                return array('code' => 201);
            }
        }else{
            if(strpos($result['sub_msg'], ':') !== false) {
                $result['sub_msg'] = ': ' . $result['sub_msg'];
            }
            C::t('#nayuan_pay#nayuan_transfer') -> update_order_by_no($no, array(
                'trade_no' => $result['order_id'],
                'status' => 3,
                'error' => '[' . $result['msg'] . '] ' . $result['sub_msg']
            ));
            return array('code' => $result['code'], 'message' => '[' . $result['msg'] . '] ' . $result['sub_msg']);
        }
    }else{
        return array('code' => 500, 'message' => lang('plugin/nayuan_pay', 'error_unknown'));
    }
}

?>