<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      json.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_json($var) {
    $var = _nayuan_json_format($var);
    return _nayuan_json($var);
}

function _nayuan_json($var) {
    global $_G;

    switch (gettype($var)) {
        case 'boolean':
            return $var ? 'true' : 'false';
        case 'NULL':
            return 'null';
        case 'integer':
            return (int) $var;
        case 'double':
        case 'float':
            return rtrim(sprintf('%.16F',$var),'0');
        case 'string':
            if(strtolower($_G['charset']) != 'utf-8') {
                $var = diconv($var, $_G['charset'], 'utf-8');
            }
            return json_encode($var);

        case 'array':
            if (is_array($var) && count($var) && (array_keys($var) !== range(0, sizeof($var) - 1))) {
                return '{' .
                    join(',', array_map('_nayuan_json_name_value',
                        array_keys($var),
                        array_values($var)))
                    . '}';
            }

            return '[' . join(',', array_map('_nayuan_json', $var)) . ']';
        case 'object':
            if ($var instanceof Traversable) {
                $vars = array();
                foreach ($var as $k=>$v)
                    $vars[$k] = $v;
            } else
                $vars = get_object_vars($var);
            return '{' .
                join(',', array_map('_nayuan_json_name_value',
                    array_keys($vars),
                    array_values($vars)))
                . '}';

        default:
            return '';
    }
}

function _nayuan_json_format($result) {
    switch (gettype($result)) {
        case 'array':
            foreach($result as $_k => $_v) {
                $result[$_k] = _nayuan_json_format($_v);
            }
            break;
        case 'boolean':
        case 'integer':
        case 'double':
        case 'float':
            $result = (string)$result;
            break;
    }
    return $result;
}

function _nayuan_json_name_value($name, $value) {
    return _nayuan_json(strval($name)) . ':' . _nayuan_json($value);
}

?>