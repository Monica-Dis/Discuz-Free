<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      admin.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

function nayuan_show_options($value, $select, $exclude = array()) {
    $_options = array();
    parse_str($value, $_list);
    foreach($_list as $_value => $_title) {
        if($exclude && in_array($_value, $exclude)) continue;
        $_options[] = "<option value=\"$_value\" " . ($select === $_value ? "selected=\"selected\"" : "") . ">$_title</option>";
    }
    return implode("", $_options);
}

function nayuan_admin_loading($message, $url = '', $values = array(), $extra = '', $timeout = 5000) {
    global $_G;
    $vars = explode(':', $message);
    $values['ADMINSCRIPT'] = ADMINSCRIPT;
    if(count($vars) == 2) {
        $message = lang('plugin/'.$vars[0], $vars[1], $values);
    } else {
        $message = cplang($message, $values);
    }
    $classname = 'infotitle1';
    $url = substr($url, 0, 5) == 'http:' ? $url : ADMINSCRIPT.'?'.$url;
    $message = "<h4 class=\"$classname\">$message</h4>";
    $url .= $url && !empty($_GET['scrolltop']) ? '&scrolltop='.intval($_GET['scrolltop']) : '';

    if($url) {
        $message = "<form method=\"post\" action=\"$url\" id=\"loadingform\"><input type=\"hidden\" name=\"formhash\" value=\"".FORMHASH."\"><br />$message$extra<img src=\"static/image/admincp/ajax_loader.gif\" class=\"marginbot\" /><br />".
            '<p class="marginbot"><a href="###" onclick="$(\'loadingform\').submit();" class="lightlink">'.cplang('message_redirect').'</a></p></form><br /><script type="text/JavaScript">setTimeout("$(\'loadingform\').submit();", '.$timeout.');</script>';
    }else{
        $message .= $extra.'<img src="static/image/admincp/ajax_loader.gif" class="marginbot" />';
    }


    echo '<h3>'.cplang('discuz_message').'</h3><div class="infobox">'.$message.'</div>';
    exit();
}

function show_admin_menu($title, $mma, $menus) {
    $menus[] = array('name' => 'admin_service', 'title' => lang('plugin/nayuan_pay', 'menu_service'));
    $menus[] = array('name' => 'admin_more', 'title' => lang('plugin/nayuan_pay', 'menu_more'));
    echo "<style>.floattop { display: none; }.floattopempty { display: none; }.mymenu { height:35px; }.mymenu .floattop { display: inline; }.mymenu .floattopempty { display: inline; }.mysubmenu .floattop { top: 45px; z-index: 100}</style>";
    $adminurl = 'plugins&operation=config&do=' . daddslashes($_GET['do']) . '&pmod=admin';
    $show_menus = array();
    foreach ($menus as $menu) {
        if($menu['submenu']) {
            $show_submenus = array();
            foreach ($menu['submenu'] as $submenu) {
                $active = $mma == $submenu['name'];
                $url = $adminurl . '&mma=' . $submenu['name'];
                if($submenu['params']) {
                    foreach ($submenu['params'] as $key => $val) {
                        $url .= '&' . $key . '=' . $val;
                        if(!isset($_GET[$key]) || $_GET[$key] != $val) {
                            $active = false;
                        }
                    }
                }
                $show_submenus[] = array($submenu['title'], $url, $active);
            }
            $show_menus[] = array(array('menu' => $menu['title'], 'submenu' => $show_submenus));
            unset($show_submenus);
        }else{
            $active = $mma == $menu['name'];
            $url = $adminurl . '&mma=' . $menu['name'];
            if($menu['params']) {
                foreach ($menu['params'] as $key => $val) {
                    $url .= '&' . $key . '=' . $val;
                    if(!isset($_GET[$key]) || $_GET[$key] != $val) {
                        $active = false;
                    }
                }
            }
            $show_menus[] = array($menu['title'], $url, $active);
        }
    }

    echo '<div class="mymenu">';
    showsubmenu($title, $show_menus);
    echo '</div>';
}

?>