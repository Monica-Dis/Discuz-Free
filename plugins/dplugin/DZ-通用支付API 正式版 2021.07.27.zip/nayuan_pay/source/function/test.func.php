<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      test.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_pay_test($data, $order) {
    require_once DISCUZ_ROOT . 'source/plugin/nayuan_pay/source/function/json.func.php';
    writelog('nayuan-pay', '[TEST] data: ' . nayuan_json($data) . ', order: ' . nayuan_json($order));
}

?>