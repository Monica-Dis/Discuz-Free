<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      alipay.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('SDK_ALIPAY_GATEWAYURL', 'https://openapi.alipay.com/gateway.do');

function sdk_alipay_trade_page_pay($settings, $order, $notify_url, $return_url) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }

    $data = array(
        'method'      => 'alipay.trade.page.pay',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'format'      => 'JSON',
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
        'notify_url'  => $notify_url,
        'return_url'  => $return_url,
        'biz_content' => json_encode(array(
            'out_trade_no'            => $order['order_id'],
            'product_code'            => 'FAST_INSTANT_TRADE_PAY',
            'total_amount'            => $order['receipt_amount'] / 100,
            'subject'                 => $order['subject'],
            'body'                    => $order['desc'],
            'timeout_express'         => '1d',
            'qr_pay_mode'             => '2',
            'integration_type'        => 'PCWEB',
        )),
    );
    if($settings['sign_type']) {
        $appid = $settings['cert_appid'];
        $private_key = $settings['app_private_key'];
        $data['app_cert_sn'] = sdk_alipay_cert_sn($settings);
        $data['alipay_root_cert_sn'] = sdk_alipay_root_cert_sn($settings);
    }else{
        $appid = $settings['appid'];
        $private_key = $settings['private_key'];
    }
    $data['app_id'] = $appid;

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($private_key, $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    if(strtoupper($_G['charset'] != 'GBK')) {
        $res = diconv($res, 'GB2312', $_G['charset']);
    }
    return $res;
}

function sdk_alipay_trade_wap_pay($settings, $order, $notify_url) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }

    $data = array(
        'method'      => 'alipay.trade.wap.pay',
        'format'      => 'JSON',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
        'notify_url'  => $notify_url,
        'biz_content' => json_encode(array(
            'out_trade_no'            => $order['order_id'],
            'product_code'            => 'FAST_INSTANT_TRADE_PAY',
            'total_amount'            => $order['receipt_amount'] / 100,
            'subject'                 => $order['subject'],
            'body'                    => $order['desc'],
            'timeout_express'         => '1d',
            'qr_pay_mode'             => '2',
            'integration_type'        => 'PCWEB',
        )),
    );
    if($settings['sign_type']) {
        $appid = $settings['cert_appid'];
        $private_key = $settings['app_private_key'];
        $data['app_cert_sn'] = sdk_alipay_cert_sn($settings);
        $data['alipay_root_cert_sn'] = sdk_alipay_root_cert_sn($settings);
    }else{
        $appid = $settings['appid'];
        $private_key = $settings['private_key'];
    }
    $data['app_id'] = $appid;

    if($order['referer_url']) {
        $data['return_url'] = $order['referer_url'];
        $data['quit_url'] = $order['referer_url'];
    }else{
        $data['quit_url'] = $_G['siteurl'];
    }

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($private_key, $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    if(!preg_match('/^https?:\/\/.+$/', $res) && strtoupper($_G['charset'] != 'GBK')) {
        $res = diconv($res, 'GB2312', $_G['charset']);
    }
    return $res;
}

/**
 * https://opendocs.alipay.com/apis/api_28/alipay.fund.trans.uni.transfer
 * @param $settings
 * @param $biz_no 业务编号
 * @param $amount 金额(分)
 * @param $realname 真实姓名
 * @param $account 支付宝账号
 * @param string $title 转账标题
 * @param string $desc 转账备注
 * @return mixed
 */
function sdk_alipay_fund_trans_uni_transfer($settings, $biz_no, $amount, $realname, $account, $title = '', $desc = '') {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $title = diconv($title, $_G['charset'], 'UTF-8');
        $desc = diconv($desc, $_G['charset'], 'UTF-8');
    }
    if(!$settings['sign_type']) {
        return;
    }
    $data = array(
        'app_id'      => $settings['cert_appid'],
        'method'      => 'alipay.fund.trans.uni.transfer',
        'format'      => 'JSON',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'app_cert_sn' => sdk_alipay_cert_sn($settings),
        'alipay_root_cert_sn' => sdk_alipay_root_cert_sn($settings),
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
    );
    $biz_content = array(
        'out_biz_no'              => $biz_no,
        'trans_amount'            => sprintf('%.2f', $amount / 100),
        'product_code'            => 'TRANS_ACCOUNT_NO_PWD',
        'biz_scene'               => 'DIRECT_TRANSFER',
        'payee_info'              => array(
            'identity'              => $account,
            'identity_type'         => 'ALIPAY_LOGON_ID',
            'name'                  => $realname
        )
    );
    if($title) {
        $biz_content['order_title'] = $title;
    }
    if($desc) {
        $biz_content['remark'] = $desc;
    }
    $data['biz_content'] = json_encode($biz_content);

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($settings['private_key'], $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    $res                 = json_decode($res, true);
    if($res['sub_msg'] && strtoupper($_G['charset'] != 'UTF-8')) {
        $res['sub_msg']             = diconv($res['sub_msg'], 'UTF-8', $_G['charset']);
    }
    return $res;
}

/**
 * https://opendocs.alipay.com/apis/api_28/alipay.fund.trans.order.query
 * @param $settings
 * @param $biz_no 业务编号
 * @return mixed
 */
function sdk_alipay_fund_trans_order_query($settings, $biz_no) {
    global $_G;
    $data = array(
        'method'      => 'alipay.fund.trans.order.query',
        'format'      => 'JSON',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
    );
    if($settings['sign_type']) {
        $appid = $settings['cert_appid'];
        $private_key = $settings['app_private_key'];
        $data['app_cert_sn'] = sdk_alipay_cert_sn($settings);
        $data['alipay_root_cert_sn'] = sdk_alipay_root_cert_sn($settings);
    }else{
        $appid = $settings['appid'];
        $private_key = $settings['private_key'];
    }
    $data['app_id'] = $appid;

    $biz_content = array(
        'out_biz_no'            => $biz_no,
    );
    $data['biz_content'] = json_encode($biz_content);

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($private_key, $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    $res                 = json_decode($res, true);
    if($res['sub_msg'] && strtoupper($_G['charset'] != 'UTF-8')) {
        $res['sub_msg']             = diconv($res['sub_msg'], 'UTF-8', $_G['charset']);
    }
    return $res;
}

/**
 * https://opendocs.alipay.com/apis/api_1/alipay.trade.refund
 * @param $settings
 * @param $refund_no 标识一次退款请求，同一笔交易多次退款需要保证唯一，如需部分退款，则此参数必传
 * @param $trade_no 支付宝交易号，和商户订单号 out_trade_no 不能同时为空
 * @param $amount 需要退款的金额，该金额不能大于订单金额,单位为元，支持两位小数
 * @param $refund_desc 退款原因说明，商家自定义
 * @return array
 */
function sdk_alipay_refund($settings, $refund_no, $trade_no, $amount, $refund_desc) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $refund_desc = diconv($refund_desc, $_G['charset'], 'UTF-8');
    }
    $data = array(
        'method'      => 'alipay.trade.refund',
        'format'      => 'JSON',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
        'biz_content' => json_encode(array(
            'trade_no'          => $trade_no,
            'refund_amount'     => $amount,
            'out_request_no'    => $refund_no,
            'refund_reason'     => $refund_desc
        )),
    );
    if($settings['sign_type']) {
        $appid = $settings['cert_appid'];
        $private_key = $settings['app_private_key'];
        $data['app_cert_sn'] = sdk_alipay_cert_sn($settings);
        $data['alipay_root_cert_sn'] = sdk_alipay_root_cert_sn($settings);
    }else{
        $appid = $settings['appid'];
        $private_key = $settings['private_key'];
    }
    $data['app_id'] = $appid;

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($private_key, $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    $res                 = json_decode($res, true);

    $res                 = $res['alipay_trade_refund_response'];
    if ($res['code'] == 10000) {
        return array('code' => 200, 'data' => array(
            'order_id' => $res['refund_settlement_id'],
            'time' => mktime($res['gmt_refund_pay'])
        ));
    } else {
        return array('code' => $res['sub_code'], 'message' => $res['sub_msg']);
    }
}

/**
 * https://opendocs.alipay.com/apis/api_1/alipay.trade.fastpay.refund.query
 * @param $settings
 * @param $trade_no 支付宝交易号，和商户订单号不能同时为空
 * @param $refund_no 请求退款接口时，传入的退款请求号，如果在退款请求时未传入，则该值为创建交易时的外部交易号
 * @return array
 */
function sdk_alipay_refund_status($settings, $trade_no, $refund_no) {
    $data = array(
        'method'      => 'alipay.trade.fastpay.refund.query',
        'format'      => 'JSON',
        'charset'     => 'utf-8',
        'sign_type'   => 'RSA2',
        'timestamp'   => dgmdate(time(), 'Y-m-d H:i:s'),
        'version'     => '1.0',
        'biz_content' => json_encode(array(
            'trade_no'           => $trade_no,
            'out_request_no'     => $refund_no,
        )),
    );
    if($settings['sign_type']) {
        $appid = $settings['cert_appid'];
        $private_key = $settings['app_private_key'];
        $data['app_cert_sn'] = sdk_alipay_cert_sn($settings);
        $data['alipay_root_cert_sn'] = sdk_alipay_root_cert_sn($settings);
    }else{
        $appid = $settings['appid'];
        $private_key = $settings['private_key'];
    }
    $data['app_id'] = $appid;

    $signstr             = sdk_alipay_make_signstr($data);
    $data['sign']        = sdk_alipay_sign($private_key, $signstr);
    $api                 = SDK_ALIPAY_GATEWAYURL . '?' . http_build_query($data);
    $res                 = sdk_alipay_request($api);
    $res                 = json_decode($res, true);

    $res                 = $res['alipay_trade_refund_response'];
    if ($res['code'] == 10000) {
        return array('code' => 200, 'data' => array(
            'order_id' => $res['refund_settlement_id'],
            'time' => mktime($res['gmt_refund_pay'])
        ));
    } else {
        return array('code' => $res['sub_code'], 'message' => $res['sub_msg']);
    }
}

function sdk_alipay_make_signstr($data) {
    ksort($data);
    $signstr = array();
    foreach ($data as $key => $value) {
        $signstr[] = $key . '=' . $value;
    }
    $signstr = implode('&', $signstr);
    return $signstr;
}

function sdk_alipay_sign($private_key, $data) {
    $private_key = "-----BEGIN RSA PRIVATE KEY-----\n" .
        wordwrap($private_key, 64, "\n", true) .
        "\n-----END RSA PRIVATE KEY-----";
    openssl_sign($data, $sign, $private_key, OPENSSL_ALGO_SHA256);
    return base64_encode($sign);
}

function sdk_alipay_make_notify_signstr($data) {
    ksort($data);
    $signstr = array();
    foreach ($data as $key => $value) {
        if(in_array($key, array('sign', 'sign_type')) || !$value) continue;
        if(is_array($value)) {
            $value = json_encode($value);
        }
        $signstr[] = $key . '=' . $value;
    }
    $signstr = implode('&', $signstr);
    return $signstr;
}

function sdk_alipay_sign_verify($settings, $sign, $data) {
    if(!$data) return false;
    if($settings['sign_type']) {
        $public_key = $settings['alipay_cert'];
    }else{
        $public_key = "-----BEGIN PUBLIC KEY-----\n" .
            wordwrap($settings['public_key'], 64, "\n", true) .
            "\n-----END PUBLIC KEY-----";
    }

    $data = sdk_alipay_make_notify_signstr($data);

    $result = (openssl_verify($data, base64_decode($sign), $public_key, OPENSSL_ALGO_SHA256) === 1);
    openssl_free_key($public_key);
    return $result;
}

function sdk_alipay_array_to_string($data) {
    $str = [];
    foreach ($data as $name => $value) {
        $str[] = $name . '=' . $value;
    }
    return implode(',', $str);
}

function sdk_alipay_hex_to_dec($hex) {
    $dec = 0;
    $size = strlen($hex);
    for ($i = 1; $i <= $size; $i++) {
        $dec = bcadd($dec, bcmul(strval(hexdec($hex[$i - 1]), bcpow('16', strval($size - $i)))));
    }
    return $dec;
}

function sdk_alipay_cert_sn($settings) {
    $ssl = openssl_x509_parse($settings['app_cert']);
    $sn = md5(sdk_alipay_array_to_string(array_reverse($ssl['issuer'])) . $ssl['serialNumber']);
    return $sn;
}

function sdk_alipay_root_cert_sn($settings) {
    $array = explode("-----END CERTIFICATE-----", $settings['alipay_root_cert']);
    $sn = array();
    for ($i = 0; $i < count($array) - 1; $i++) {
        $ssl = openssl_x509_parse($array[$i] . "-----END CERTIFICATE-----");
        if ($ssl['signatureTypeLN'] == "sha256WithRSAEncryption") {
            $sn[] = md5(sdk_alipay_array_to_string(array_reverse($ssl['issuer'])) . $ssl['serialNumber']);
        }
    }
    return implode('_', $sn);
}

function sdk_alipay_request($api, $post = '') {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    if($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $data = curl_exec($ch);
    $status = curl_getinfo($ch);
    curl_close($ch);
    if($status['http_code'] == 200)  {
        $data = substr($data, $status['header_size']);
        return $data;
    } else if(preg_match('/^30\d+$/', $status['http_code'])) {
        return $status['redirect_url'];
    }else{
        return;
    }
}

?>