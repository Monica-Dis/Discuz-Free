<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      weixin.func.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:07.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('SDK_WEIXIN_PAY_UNIFIEDORDER', 'https://api.mch.weixin.qq.com/pay/unifiedorder');
define('SDK_WEIXIN_PAY_ORDERQUERY', 'https://api.mch.weixin.qq.com/pay/orderquery');
define('SDK_WEIXIN_PAY_REFUND', 'https://api.mch.weixin.qq.com/secapi/pay/refund');
define('SDK_WEIXIN_PAY_REFUNDQUERY', 'https://api.mch.weixin.qq.com/pay/refundquery');
define('SDK_WEIXIN_AUTHORIZE', 'https://open.weixin.qq.com/connect/oauth2/authorize');
define('SDK_WEIXIN_SNS_ACCESS_TOKEN', 'https://api.weixin.qq.com/sns/oauth2/access_token');

define('SDK_WEIXIN_PAY_V3_TRANSACTIONS_NATIVE', 'https://api.mch.weixin.qq.com/v3/pay/transactions/native');
define('SDK_WEIXIN_PAY_V3_TRANSACTIONS_H5', 'https://api.mch.weixin.qq.com/v3/pay/transactions/h5');
define('SDK_WEIXIN_PAY_V3_TRANSACTIONS_JSAPI', 'https://api.mch.weixin.qq.com/v3/pay/transactions/jsapi');
define('SDK_WEIXIN_PAY_V3_TRANSACTIONS_OUTTRADENO', 'https://api.mch.weixin.qq.com/v3/pay/transactions/out-trade-no/');
define('SDK_WEIXIN_PAY_V3_REFUND_DOMESTIC_REFUNDS', 'https://api.mch.weixin.qq.com/v3/refund/domestic/refunds');
define('SDK_WEIXIN_PAY_V3_REFUND_DOMESTIC_REFUNDS_QUERY', 'https://api.mch.weixin.qq.com/v3/refund/domestic/refunds/');
define('SDK_WEIXIN_PAY_V3_CERTIFICATES', 'https://api.mch.weixin.qq.com/v3/certificates');

function sdk_weixin_authorize($settings, $redirect_uri, $state, $scope = 'snsapi_base') {
    return SDK_WEIXIN_AUTHORIZE . "?appid={$settings['appid']}&redirect_uri={$redirect_uri}&response_type=code&scope={$scope}&state={$state}#wechat_redirect";
}

function sdk_weixin_access_token_by_code($settings, $code) {
    $api = SDK_WEIXIN_SNS_ACCESS_TOKEN . "?appid={$settings['appid']}&secret={$settings['appsecret']}&code=$code&grant_type=authorization_code";
    return sdk_weixin_request($api);
}

/**
 * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_1
 * @param $settings
 * @param $order
 * @param $notify_url 异步接收微信支付结果通知的回调地址，通知url必须为外网可访问的url，不能携带参数
 * @param string $type JSAPI -JSAPI支付  NATIVE -Native支付  APP -APP支付
 * @param null $openid trade_type=JSAPI时（即JSAPI支付），此参数必传，此参数为微信用户在商户对应appid下的唯一标识
 * @return mixed
 */
function sdk_weixin_unifiedorder_pay($settings, $order, $notify_url, $type = 'NATIVE', $openid = null) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }
    $data = array(
        'appid'             => $settings['appid'],
        'mch_id'            => $settings['mchid'],
        'nonce_str'         => sdk_weixin_nonce(),
        'sign_type'         => 'MD5',
        'body'              => $order['subject'],
        'detail'            => $order['desc'],
        'out_trade_no'      => $order['order_id'],
        'total_fee'         => intval($order['receipt_amount']),
        'spbill_create_ip'  => $_G['clientip'],
        'time_expire'       => dgmdate(time() + 86400, 'YmdHis'),
        'notify_url'        => $notify_url,
        'trade_type'        => $type,
    );
    if($openid) {
        $data['openid'] = $openid;
    }
    $data['sign'] = sdk_weixin_sign($settings, $data);
    $data = sdk_weixin_o2x($data);

    $api                 = SDK_WEIXIN_PAY_UNIFIEDORDER;
    $res                 = sdk_weixin_request_xml($settings, $api, $data);
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $res = diconv($res, 'UTF-8', $_G['charset']);
    }
    $res = sdk_weixin_x2o($res);
    if ($res['return_code'] != 'SUCCESS') {
        $res['error_message'] = $res['return_msg'];
    } elseif ($res['result_code'] != 'SUCCESS') {
        $res['error_message'] = $res['err_code_des'];
    }

    return $res;
}

/**
 * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_4
 * @param $settings
 * @param $refund_no 商户系统内部的退款单号，商户系统内部唯一，只能是数字、大小写字母_-|*@ ，同一退款单号多次请求只退一笔。
 * @param $trade_no 微信生成的订单号，在支付通知中有返回
 * @param $total_amount 订单总金额，单位为分，只能为整数
 * @param $refund_amount 退款总金额，订单总金额，单位为分，只能为整数
 * @param $refund_desc 若商户传入，会在下发给用户的退款消息中体现退款原因
 * @return mixed
 */
function sdk_weixin_refund($settings, $refund_no, $trade_no, $total_amount, $refund_amount, $refund_desc) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $refund_desc = diconv($refund_desc, $_G['charset'], 'UTF-8');
    }
    $data = [
        'appid'             => $settings['appid'],
        'mch_id'            => $settings['mchid'],
        'nonce_str'         => sdk_weixin_nonce(),
        'sign_type'         => 'MD5',
        'transaction_id'    => $trade_no,
        'out_refund_no'     => $refund_no,
        'total_fee'         => $total_amount,
        'refund_fee'        => $refund_amount,
        'refund_desc'       => $refund_desc
    ];
    $data['sign']       = sdk_weixin_sign($settings, $data);
    $data               = sdk_weixin_o2x($data);
    $api                = SDK_WEIXIN_PAY_REFUND;
    $res                = sdk_weixin_request_xml($settings, $api, $data, true);

    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $res = diconv($res, 'UTF-8', $_G['charset']);
    }
    $res                = sdk_weixin_x2o($res);
    if ($res['return_code'] != 'SUCCESS') {
        return array('code' => 500, 'message' => $res['return_msg']);
    } elseif ($res['result_code'] != 'SUCCESS') {
        return array('code' => 500, 'message' => $res['err_code_des']);
    }else{
        return array('code' => 200, 'data' => array(
            'out_refund_no' => $res['out_refund_no'],
            'time' => time()
        ));
    }
}

/**
 * https://pay.weixin.qq.com/wiki/doc/api/native.php?chapter=9_5
 * @param $settings
 * @param $refund_no 微信生成的退款单号，在申请退款接口有返回
 * @return mixed
 */
function sdk_weixin_refund_status($settings, $refund_no) {
    global $_G;
    $data = [
        'appid'             => $settings['appid'],
        'mch_id'            => $settings['mchid'],
        'nonce_str'         => sdk_weixin_nonce(),
        'sign_type'         => 'MD5',
        'out_refund_no'         => $refund_no,
    ];
    $data['sign']       = sdk_weixin_sign($settings, $data);
    $data               = sdk_weixin_o2x($data);
    $api                = SDK_WEIXIN_PAY_REFUNDQUERY;
    $res                = sdk_weixin_request_xml($settings, $api, $data, true);
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $res = diconv($res, 'UTF-8', $_G['charset']);
    }
    $res                = sdk_weixin_x2o($res);
    $res = sdk_weixin_x2o($res);
    if ($res['return_code'] != 'SUCCESS') {
        return array('code' => 500, 'message' => $res['return_msg']);
    } elseif ($res['result_code'] != 'SUCCESS') {
        return array('code' => 500, 'message' => $res['d']);
    }else{
        return array('code' => 200, 'data' => array(
            'out_refund_no' => $res['out_refund_no'],
            'time' => time()
        ));
    }
}

function sdk_weixin_sign_verify($settings) {
    $xml = file_get_contents('php://input');
    $data = sdk_weixin_x2o($xml);
    $sign = sdk_weixin_sign($settings, $data, 1);
    if($sign != $data['sign']) return false;

    if ($data['return_code'] != 'SUCCESS') {
        return false;
    }
    if ($data['result_code'] != 'SUCCESS') {
        return false;
    }
    return $data;
}

function sdk_weixin_o2x($data) {
    $xml = '<xml>';
    foreach ($data as $key => $value) {
        $xml .= "\n<{$key}>{$value}</{$key}>";
    }
    $xml .= "\n</xml>";
    return $xml;
}

function sdk_weixin_x2o($xml) {
    libxml_disable_entity_loader(true);
    $data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
    return $data;
}

function sdk_weixin_sign($settings, $data, $sign = 0) {
    ksort($data);
    $signstr = '';
    foreach ($data as $key => $value) {
        if(!$value || ($sign && $key == 'sign')) continue;
        $signstr .= $key . '=' . $value . '&';
    }
    $signstr .= 'key=' . $settings['key'];
    $sign = strtoupper(md5($signstr));
    return $sign;
}

function sdk_weixin_nonce() {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < 32; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function sdk_weixin_request($api, $data = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    if($data) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $data = curl_exec($ch);
    $status = curl_getinfo($ch);
    curl_close($ch);
    $data = substr($data, $status['header_size']);
    return $data;
}

function sdk_weixin_request_xml($settings, $api, $xml, $cert = false) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    if ($cert) {
        if(!$settings['p12'] || !file_exists(DISCUZ_ROOT . $settings['p12']) || !is_file(DISCUZ_ROOT . $settings['p12'])) {
            return '<xml><return_code>400</return_code><return_msg>p12 not found.</return_msg></xml>';
        }
        curl_setopt($ch, CURLOPT_CAINFO, DISCUZ_ROOT . $settings['p12']);
    }
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $data = curl_exec($ch);
    $status = curl_getinfo($ch);
    curl_close($ch);
    if(preg_match('/^30\d+$/', $status['http_code'])) {
        return $status['redirect_url'];
    }else{
        $data = substr($data, $status['header_size']);
        return $data;
    }
}


function sdk_v3_weixin_native_pay($settings, $order, $notify_url) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }
    $data = array(
        'appid' => $settings['appid'],
        'mchid' => $settings['mchid'],
        'description' => $order['subject'] . ':' . $order['desc'],
        'out_trade_no' => $order['order_id'],
        'notify_url' => $notify_url,
        'amount' => array(
            'total' => intval($order['receipt_amount']),
            'currency' => 'CNY'
        )
    );

    $api = SDK_WEIXIN_PAY_V3_TRANSACTIONS_NATIVE;
    $res = sdk_v3_weixin_request_json($settings, $api, json_encode($data));
    $res = json_decode($res, true);
    if ($res['code_url']) {
        return array('code' => 200, 'code_url' => $res['code_url']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'error_message' => $res['message']);
    }
}

function sdk_v3_weixin_h5_pay($settings, $order, $notify_url) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }
    $data = array(
        'appid' => $settings['appid'],
        'mchid' => $settings['mchid'],
        'description' => $order['subject'] . ':' . $order['desc'],
        'out_trade_no' => $order['order_id'],
        'notify_url' => $notify_url,
        'amount' => array(
            'total' => intval($order['receipt_amount']),
            'currency' => 'CNY'
        ),
        'scene_info' => array(
            'payer_client_ip' => $_G['clientip'],
            'h5_info' => array('type' => checkmobile())
        )
    );

    $api = SDK_WEIXIN_PAY_V3_TRANSACTIONS_H5;
    $res = sdk_v3_weixin_request_json($settings, $api, json_encode($data));
    $res = json_decode($res, true);
    if ($res['h5_url']) {
        return array('code' => 200, 'code_url' => $res['h5_url']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'error_message' => $res['message']);
    }
}

function sdk_v3_weixin_h5_jsapi($settings, $openid, $order, $notify_url) {
    global $_G;
    if(strtoupper($_G['charset'] != 'UTF-8')) {
        $order['subject'] = diconv($order['subject'], $_G['charset'], 'UTF-8');
        $order['desc'] = diconv($order['desc'], $_G['charset'], 'UTF-8');
    }
    $data = array(
        'appid' => $settings['appid'],
        'mchid' => $settings['mchid'],
        'description' => $order['subject'] . ':' . $order['desc'],
        'out_trade_no' => $order['order_id'],
        'notify_url' => $notify_url,
        'amount' => array(
            'total' => intval($order['receipt_amount']),
            'currency' => 'CNY'
        ),
        'payer' => array(
            'openid' => $openid
        )
    );

    $api = SDK_WEIXIN_PAY_V3_TRANSACTIONS_H5;
    $res = sdk_v3_weixin_request_json($settings, $api, json_encode($data));
    $res = json_decode($res, true);
    if ($res['prepay_id']) {
        return array('code' => 200, 'prepay_id' => $res['prepay_id']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'error_message' => $res['message']);
    }
}

function sdk_v3_weixin_query_order($settings, $out_biz_no) {
    global $_G;
    $api = SDK_WEIXIN_PAY_V3_TRANSACTIONS_OUTTRADENO;
    $res = sdk_v3_weixin_request_json($settings, $api . $out_biz_no . '?mchid=' . $settings['mchid'], '', 'GET');
    $res = json_decode($res, true);
    if ($res['trade_state'] && $res['trade_state'] == 'SUCCESS') {
        $pay_time = strtotime($res['success_time']);
        return array('code' => 200, 'data' => array('trade_no' => $res['transaction_id'], 'payment_time' => $pay_time));
    } else if ($res['trade_state']) {
        return array('code' => $res['trade_state'], 'message' => $res['trade_state_desc']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'message' => $res['message']);
    }
}

function sdk_v3_weixin_refund($settings, $refund_no, $trade_no, $total_amount, $refund_amount, $refund_desc) {
    global $_G;
    if (strtoupper($_G['charset'] != 'UTF-8')) {
        $refund_desc = diconv($refund_desc, $_G['charset'], 'UTF-8');
    }
    $data = array('transaction_id' => $trade_no, 'out_refund_no' => $refund_no, 'reason' => $refund_desc, 'amount' => array('refund' => intval($refund_amount), 'total' => intval($total_amount), 'currency' => 'CNY'));

    $api = SDK_WEIXIN_PAY_V3_REFUND_DOMESTIC_REFUNDS;
    $res = sdk_v3_weixin_request_json($settings, $api, json_encode($data));
    $res = json_decode($res, true);
    if ($res['status'] == 'SUCCESS') {
        return array('code' => 200, 'data' => array('refund_time' => strtotime($res['success_time'])));
    } else if ($res['status']) {
        return array('code' => 201, 'message' => $res['status']);
    } else if ($res['status']) {
        return array('code' => 500, 'message' => $res['status']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'message' => $res['message']);
    }
}

function sdk_v3_weixin_refund_query($settings, $refund_no) {
    global $_G;
    $api = SDK_WEIXIN_PAY_V3_REFUND_DOMESTIC_REFUNDS_QUERY;
    $res = sdk_v3_weixin_request_json($settings, $api . $refund_no, '', 'GET');
    $res = json_decode($res, true);
    if ($res['status'] == 'SUCCESS') {
        return array('code' => 200, 'data' => array('refund_time' => strtotime($res['success_time'])));
    } else if ($res['status']) {
        return array('code' => 201, 'message' => $res['status']);
    } else if ($res['status']) {
        return array('code' => 500, 'message' => $res['status']);
    } else {
        if (strtoupper($_G['charset'] != 'UTF-8') && $res['message']) {
            $res['message'] = diconv($res['message'], 'UTF-8', $_G['charset']);
        }
        return array('code' => $res['code'], 'message' => $res['message']);
    }
}

function sdk_v3_weixin_sign_verify($settings) {
    $nonce = $_SERVER['HTTP_WECHATPAY_NONCE'];
    $timestamp = $_SERVER['HTTP_WECHATPAY_TIMESTAMP'];
    $serial = $_SERVER['HTTP_WECHATPAY_SERIAL'];
    $json = file_get_contents('php://input');
    $signature = $_SERVER['HTTP_WECHATPAY_SIGNATURE'];

    $serial = strtoupper(ltrim($serial, '0'));
    $public_key = $settings['v3_certificates'][$serial];
    if (!$public_key) {
        return false;
    }
    $signature = base64_decode($signature);
    $signstr = $timestamp . "\n" . $nonce . "\n" . $json . "\n";
    if (!openssl_verify($signstr, $signature, $public_key, 'sha256WithRSAEncryption')) {
        return false;
    }
    $resource = json_decode($json, true);
    if ($resource['event_type'] != 'TRANSACTION.SUCCESS') return false;
    $resource = $resource['resource'];
    return sdk_v3_weixin_decrypt2string($settings, $resource['associated_data'], $resource['nonce'], $resource['ciphertext']);
}

function sdk_v3_weixin_support() {
    // ext-sodium (default installed on >= PHP 7.2)
    if (function_exists('sodium_crypto_aead_aes256gcm_is_available') && sodium_crypto_aead_aes256gcm_is_available()) {
        return true;
    }
    // openssl (PHP >= 7.1 support AEAD)
    if (PHP_VERSION_ID >= 70100 && in_array('aes-256-gcm', openssl_get_cipher_methods())) {
        return true;
    }
    return false;
}

function sdk_v3_weixin_certificates($settings) {
    global $_G;
    $api = SDK_WEIXIN_PAY_V3_CERTIFICATES;
    $res = sdk_v3_weixin_request_json($settings, $api, '', 'GET');
    $res = json_decode($res, true);
    $list = array();
    if ($res['data']) {
        foreach ($res['data'] as $item) {
            $serial_no = $item['serial_no'];
            $item = $item['encrypt_certificate'];
            $data = sdk_v3_weixin_decrypt2string($settings, $item['associated_data'], $item['nonce'], $item['ciphertext']);
            $list[$serial_no] = $data;
        }
    }
    return array('code' => 200, 'data' => $list);
}

function sdk_v3_weixin_authorization($settings, $api, $method, $json) {
    $url_values = parse_url($api);
    $timestamp = time();
    $nonce = sdk_weixin_nonce();
    $message = $method . "\n" . $url_values['path'] . ($url_values['query'] ? ('?' . $url_values['query']) : '') . "\n" . $timestamp . "\n" . $nonce . "\n" . $json . "\n";
    openssl_sign($message, $sign, $settings['v3_private_key'], 'sha256WithRSAEncryption');
    $sign = base64_encode($sign);
    $token = sprintf('mchid="%s",nonce_str="%s",timestamp="%d",serial_no="%s",signature="%s"', $settings['mchid'], $nonce, $timestamp, $settings['v3_serial_no'], $sign);
    return $token;
}

function sdk_v3_weixin_decrypt2string($settings, $associateddata, $noncestr, $ciphertext) {
    $ciphertext = base64_decode($ciphertext);
    if (strlen($ciphertext) <= 16) {
        return false;
    }

    // ext-sodium (default installed on >= PHP 7.2)
    if (function_exists('sodium_crypto_aead_aes256gcm_is_available') && sodium_crypto_aead_aes256gcm_is_available()) {
        return sodium_crypto_aead_aes256gcm_decrypt($ciphertext, $associateddata, $noncestr, $settings['v3_key']);
    }
    // openssl (PHP >= 7.1 support AEAD)
    if (PHP_VERSION_ID >= 70100 && in_array('aes-256-gcm', openssl_get_cipher_methods())) {
        $ctext = substr($ciphertext, 0, -16);
        $authTag = substr($ciphertext, -16);

        return openssl_decrypt($ctext, 'aes-256-gcm', $settings['v3_key'], OPENSSL_RAW_DATA, $noncestr, $authTag, $associateddata);
    }

    return false;
}

function sdk_v3_weixin_request_json($settings, $api, $json = '', $method = 'POST') {
    $headers = array(
        'Accept: application/json',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36',
        'content-type: application/json',
        'Authorization: WECHATPAY2-SHA256-RSA2048 ' . sdk_v3_weixin_authorization($settings, $api, $method, $json)
    );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    if ($method == 'POST') {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    }
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $data = curl_exec($ch);
    $status = curl_getinfo($ch);
    curl_close($ch);
    if (preg_match('/^30\d+$/', $status['http_code'])) {
        return $status['redirect_url'];
    } else {
        $data = substr($data, $status['header_size']);
        return $data;
    }
}

?>