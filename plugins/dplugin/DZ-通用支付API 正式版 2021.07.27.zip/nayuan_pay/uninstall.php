<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      uninstall.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_pay_order`;
    DROP TABLE IF EXISTS `pre_nayuan_pay_type`;
    DROP TABLE IF EXISTS `pre_nayuan_pay_refund`;

EOF;

runquery($sql);
C::t('common_syscache') -> delete('nayuan_pay');

$finish = true;

?>