<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_pay.
 *      install.php.
 *      Author nayuan.
 *      Time 2021-07-27 23:34:06.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
    
    CREATE TABLE `pre_nayuan_pay_order`  (
      `id` bigint(20) NOT NULL AUTO_INCREMENT,
      `order_id` varchar(64)  NOT NULL,
      `login` tinyint(1) DEFAULT 1,
      `uid` bigint(20) NOT NULL,
      `type` varchar(32)  NOT NULL,
      `total_amount` int(10) NOT NULL,
      `receipt_amount` int(10) NOT NULL,
      `currency` varchar(255) DEFAULT 'CNY',
      `subject` varchar(255) NOT NULL,
      `desc` varchar(255)  NOT NULL,
      `time` int(10) NOT NULL,
      `expire_time` int(10) NOT NULL,
      `referer_url` varchar(255) DEFAULT NULL,
      `status` int(10) NOT NULL,
      `callback_path` varchar(255) DEFAULT NULL,
      `callback_func` varchar(255) DEFAULT NULL,
      `callback_data` text DEFAULT NULL,
      `trade_no` varchar(100) DEFAULT NULL,
      `pay_type` varchar(100) DEFAULT NULL,
      `pay_url`  varchar(255) DEFAULT NULL,
      `pay_time` int(10) NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE INDEX `idx_order_id`(`order_id`),
      INDEX `idx_time`(`time`),
      INDEX `idx_uid_time`(`uid`)
    ) ENGINE = InnoDB;
    
    CREATE TABLE `pre_nayuan_pay_type`  (
      `code` varchar(50) NOT NULL DEFAULT '',
      `name` varchar(100) NOT NULL,
      `desc` varchar(255) NOT NULL,
      `time` int(10) NOT NULL DEFAULT 0,
      PRIMARY KEY (`code`)
    ) ENGINE = InnoDB;
    
    CREATE TABLE `pre_nayuan_pay_refund`  (
      `id` bigint(20) NOT NULL AUTO_INCREMENT,
      `oid` bigint(20) NOT NULL,
      `refund_no` varchar(64)  NOT NULL,
      `amount` int(10) NOT NULL,
      `desc` varchar(255)  NOT NULL,
      `status` tinyint(1) NOT NULL,
      `error` varchar(255) NOT NULL,
      `refund_time` int(10) DEFAULT NULL,
      `time` int(10) NOT NULL DEFAULT 0,
      PRIMARY KEY (`id`),
      UNIQUE INDEX `idx_refund_no`(`refund_no`),
      INDEX `idx_oid`(`oid`)
    ) ENGINE = InnoDB;
    
    CREATE TABLE `pre_nayuan_pay_transfer`  (
      `id` bigint(20) NOT NULL AUTO_INCREMENT,
      `uid` bigint(20) NOT NULL,
      `order_id` varchar(64) NOT NULL,
      `amount` int(10) NOT NULL,
      `currency` varchar(255) DEFAULT 'CNY',
      `subject` varchar(255) DEFAULT NULL,
      `desc` varchar(255)  DEFAULT NULL,
      `name` varchar(255) DEFAULT NULL,
      `account` varchar(255) NOT NULL,
      `type` varchar(50) NOT NULL,
      `status` tinyint(1) NOT NULL,
      `error` varchar(255) NOT NULL,
      `trade_no` varchar(64) DEFAULT NULL,
      `extdata` text DEFAULT NULL,
      `pay_time` int(10) DEFAULT NULL,
      `time` int(10) NOT NULL DEFAULT 0,
      PRIMARY KEY (`id`),
      UNIQUE INDEX `idx_order_id`(`order_id`),
      INDEX `idx_uid`(`uid`)
    ) ENGINE = InnoDB;

EOF;

runquery($sql);

C::t('#nayuan_pay#nayuan_type') -> insert(array(
    'code' => 'test',
    'name' => $installlang['test_name'],
    'desc' => $installlang['test_desc'],
    'time' => time()
));

$finish = true;

?>