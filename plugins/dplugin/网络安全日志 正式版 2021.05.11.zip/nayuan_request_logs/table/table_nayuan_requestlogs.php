<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      table_nayuan_requestlogs.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_requestlogs extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_request_logs';
        $this->_pk    = 'id';
        parent::__construct(); //d'.'is'.'m.ta'.'obao.com
    }

    public function delete_by_time($time) {
        DB::query("DELETE FROM %t WHERE `time` < %d", array($this -> _table, $time));
    }

    public function delete_by_id($ids) {
        DB::query("DELETE FROM %t WHERE `id` in (%n)", array($this -> _table, $ids));
    }

    public function fetch_visitor_list($sid, $ip, $target, $page = 1, $pagesize = 15, $orderby) {
        $wherestr = $params = array();
        $params[] = $this -> _table;
        $wherestr[] = 'a.uid = 0';

        if($sid) {
            $wherestr[]= 'a.`sid` = %s';
            $params[] = $sid;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        $_result = array();
        $_total = DB::result_first("SELECT count(*) FROM %t a $wherestr", $params);
        if(!$_total) {
            $_result['total'] = 0;
            $_result['list'] = array();
        }else{
            $_list = DB::fetch_all("SELECT a.`id`,a.`action`,a.sid, a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target`,a.`area` FROM %t a $wherestr ORDER BY $orderby" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
            $_result['total'] = $_total;
            $_result['list'] = $_list;
        }
        return $_result;
    }

    public function fetch_list($action, $username, $ip, $target, $page = 1, $pagesize = 15, $orderby, $sid = '') {
        $wherestr = $params = array();
        $params[] = $this -> _table;
        $params[] = 'common_member';

        if($username) {
            $wherestr[]= 'b.`username` = %s';
            $params[] = $username;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($sid) {
            $wherestr[]= 'a.`sid` = %s';
            $params[] = $sid;
        }
        if($action){
            if(is_array($action)) {
                $wherestr[]= 'a.`action` in (%n)';
                $params[] = $action;
            }else{
                $wherestr[]= 'a.`action` = %s';
                $params[] = $action;
            }
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        $_result = array();
        $_total = DB::result_first("SELECT count(*) FROM %t a LEFT JOIN %t b ON a.uid = b.uid $wherestr", $params);
        if(!$_total) {
            $_result['total'] = 0;
            $_result['list'] = array();
        }else{
            $_list = DB::fetch_all("SELECT a.`id`,a.sid,a.`action`,a.`uid`,b.username,a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target`,a.`area` FROM %t a LEFT JOIN %t b ON a.uid = b.uid $wherestr ORDER BY $orderby" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
            $_result['total'] = $_total;
            $_result['list'] = $_list;
        }
        return $_result;
    }

    public function fetch_visitor_list_for_export($sid, $ip, $target, $page = 1, $pagesize = 10000) {
        $wherestr = $params = array();
        $wherestr[] = 'a.uid = 0';
        $params[] = $this -> _table;

        if($sid) {
            $wherestr[]= 'a.`sid` = %s';
            $params[] = $sid;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        return DB::fetch_all("SELECT a.sid,a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target` FROM %t a $wherestr" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
    }

    public function fetch_list_for_export($action, $username, $ip, $target, $page = 1, $pagesize = 10000, $sid = '') {
        $wherestr = $params = array();
        $params[] = $this -> _table;
        $params[] = 'common_member';

        if($username) {
            $wherestr[]= 'b.`username` = %s';
            $params[] = $username;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($sid) {
            $wherestr[]= 'a.`sid` = %s';
            $params[] = $sid;
        }
        if($action){
            if(is_array($action)) {
                $wherestr[]= 'a.`action` in (%n)';
                $params[] = $action;
            }else{
                $wherestr[]= 'a.`action` = %s';
                $params[] = $action;
            }
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        return DB::fetch_all("SELECT a.`action`,a.sid, a.`uid`,b.username,a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target` FROM %t a LEFT JOIN %t b on a.uid = b.uid $wherestr" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
    }

    public function fetch_post_subject($tids) {
        return DB::fetch_all("SELECT `tid`, `subject` FROM %t WHERE `tid` in (%n)", array('forum_thread', $tids));
    }

}
//dis'.'m.t'.'ao'.'bao.com
?>