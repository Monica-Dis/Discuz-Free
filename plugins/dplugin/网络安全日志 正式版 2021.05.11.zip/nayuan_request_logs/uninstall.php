<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      uninstall.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_request_logs`;

EOF;

runquery($sql);

$wechat = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
if(file_exists($wechat)) {
    require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::delAPIHook(array('nayuan_request_logs'));
}

$finish = true;

?>