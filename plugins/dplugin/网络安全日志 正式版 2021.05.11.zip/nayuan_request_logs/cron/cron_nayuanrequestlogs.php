<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      cron_nayuanrequestlogs.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


//cronname:cron_title
//week:-1
//day:-1
//hour:1
//minute:35

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;

loadcache('plugin');
$_options = $_G['cache']['plugin']['nayuan_request_logs'];
$_days = intval($_options['days']);
if(!$_days || $_days < 0) {
    return;
}

$_time = time() - 86400 * $_days;
C::t('#nayuan_request_logs#nayuan_requestlogs') -> delete_by_time($_time); //清理60天之前的日志记录

?>