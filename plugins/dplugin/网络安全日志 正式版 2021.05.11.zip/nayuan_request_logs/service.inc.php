<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      service.inc.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

showtableheader(lang('plugin/nayuan_request_logs', 'service_title'));
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_qq'),
        '<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=276440802&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:276440802:51" alt="'.lang('plugin/nayuan_request_logs', 'service_qq_tips').'" title="'.lang('plugin/nayuan_request_logs', 'service_qq_tips').'"/></a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_qq_group'),
        '<a target="_blank" href="https://qm.qq.com/cgi-bin/qm/qr?k=JMYal0hTnivUoJdgBLcI55EbzUyb98yS&jump_from=webapi"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="Dplugin" title="Dplugin"></a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_email'), 'nayuan@vip.qq.com',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_site'), '<a href="https://www.dplugin.com" target="_blank">https://www.dplugin.com</a>',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_addon'), '<a href="https://dism.taobao.com/?@12008.developer" target="_blank">https://dism.taobao.com/?@12008.developer</a>',
    )
);
showtablefooter(); //Dism·taobao·com


?>