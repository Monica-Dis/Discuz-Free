<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      upgrade.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(!$fromversion) {
    $fromversion = $_GET['fromversion'];
}

if($fromversion < '2020.06.06') {
    $sql = <<<EOF
    
    ALTER TABLE pre_nayuan_request_logs ADD `target` bigint(20);
    ALTER TABLE pre_nayuan_request_logs ADD `data` varchar(255);
    ALTER TABLE `pre_nayuan_request_logs` ADD INDEX `idx_ip` (`clientip`);

EOF;
    runquery($sql);

    $wechat = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    if(file_exists($wechat)) {
        require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
        WeChatHook::updateAPIHook(array(
            array('login_variables' => array(
                'plugin' => 'nayuan_request_logs',
                'include' => 'requestlogs.class.php',
                'class' => 'mobileapiplugin_nayuan_request_logs_member',
                'method' => 'login_variables',
            )),
            array('register_variables' => array(
                'plugin' => 'nayuan_request_logs',
                'include' => 'requestlogs.class.php',
                'class' => 'mobileapiplugin_nayuan_request_logs_member',
                'method' => 'register_variables',
            )),
            array('newthread_variables' => array(
                'plugin' => 'nayuan_request_logs',
                'include' => 'requestlogs.class.php',
                'class' => 'mobileapiplugin_nayuan_request_logs_member',
                'method' => 'newthread_variables',
            )),
            array('sendreply_variables' => array(
                'plugin' => 'nayuan_request_logs',
                'include' => 'requestlogs.class.php',
                'class' => 'mobileapiplugin_nayuan_request_logs_member',
                'method' => 'sendreply_variables',
            ))
        ));
    }

}

if($fromversion < '2020.06.19') {
    $sql = <<<EOF
    ALTER TABLE `pre_nayuan_request_logs` ADD `area` varchar(255);
    ALTER TABLE `pre_nayuan_request_logs` ADD INDEX `idx_area` (`area`);
EOF;
    runquery($sql);
}


$finish = true;

?>