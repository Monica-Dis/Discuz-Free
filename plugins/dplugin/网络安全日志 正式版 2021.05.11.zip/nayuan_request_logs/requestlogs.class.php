<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_request_logs.
 *      requestlogs.class.php.
 *      Author nayuan.
 *      Time 2021-05-11 16:34:44.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nayuan_request_logs {

    protected static $postReportAction = array('post_newthread_succeed', 'post_edit_succeed', 'post_reply_succeed',
        'post_newthread_mod_succeed', 'post_newthread_mod_succeed', 'post_reply_mod_succeed',
        'edit_reply_mod_succeed', 'edit_newthread_mod_succeed');
    protected static $userReportAction = array('login_succeed', 'register_succeed', 'location_login_succeed_mobile',
        'location_login_succeed', 'register_succeed_location', 'register_email_verify',
        'register_manual_verify', 'login_succeed_inactive_member');

    public function common() {
        global $_G;

        if(defined('CURSCRIPT') && CURSCRIPT == 'plugin') {
            $identifier = CURMODULE;
            if(in_array($identifier, array( 'wq_login' ))) {
                $_G['setting'][HOOKTYPE]['plugin'][$identifier] = array(
                    'module' => array( 'nayuan_request_logs' => 'nayuan_request_logs/requestlogs' ),
                    'adminid' => array( 'nayuan_request_logs' => 0 ),
                    'messagefuncs' => array(
                        'nayuan_request_logs' => array(
                            array(
                                'nayuan_request_logs',
                                $identifier . '_message'
                            )
                        )
                    ),
                );
            }
        }

        loadcache('plugin');
        $settings = $_G['cache']['plugin']['nayuan_request_logs'];
        if($settings['is_all'] && ($_G['uid'] || !$settings['close_guest'])) {
            $this -> write_request_log('other');
        }
    }

    public function deletepost($param) {
        $step = $param['step'];
        $param = $param['param'];
        $idType = $param[1];

        if ($step == 'check' && $idType == 'pid') {
            $this -> write_request_log('delete_post'); //删除贴子
        }

        return true;
    }

    public function recyclebinpostundelete ($param) {
        $pids = $param['param'][0];
        if ($pids && is_array($pids)) {
            $this -> write_request_log('recover_post'); //恢复贴子
        }
    }

    public function deletethread($param) {
        $step = $param['step'];
        $param = $param['param'];

        if ($step == 'check') {
            $this -> write_request_log('delete_thread'); //删除主题
        }

        return true;
    }

    public function undeletethreads($param) {
        $tids = $param['param'][0];
        if ($tids && is_array($tids)) {
            $this -> write_request_log('recover_thread'); //恢复主题
        }
    }

    public function deletemember($param) {
        $uids = $param['param'][0];
        $step = $param['step'];
        if ($step == 'check' && $uids && is_array($uids)) {
            $this -> write_request_log('delete_user'); //删除用户
        }
    }

    protected function write_request_log($action, $target = '', $data = '') {
        global $_G;
        if(!function_exists('convertip')) {
            require_once libfile('function/misc');
        }

        loadcache('plugin');
        $settings = $_G['cache']['plugin']['nayuan_request_logs'];
        if($settings['close_guest'] && !$_G['uid']) return;

        $log = array(
            'uid' => $_G['uid'],
            'action' => $action,
            'mobile' => defined('IN_MOBILE'),
            'sid' => $_G['sid'],
            'clientip' => $_G['clientip'],
            'clientport' => $_G['remoteport'],
            'area' => convertip($_G['clientip']),
            'request_method' => $_SERVER['REQUEST_METHOD'],
            'request_url' => $_G['siteurl'] . $_SERVER['REQUEST_URI'],
            'http_referer' => $_SERVER['HTTP_REFERER'],
            'http_user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'http_x_forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'],
            'time' => time(),
        );
        $log['id'] = md5(http_build_query($log) . random(10));
        if($data) {
            $log['data'] = $data;
        }
        if($target) {
            $log['target'] = $target;
        }

        C::t('#nayuan_request_logs#nayuan_requestlogs') -> insert($log); //记录日志
    }

}

class plugin_nayuan_request_logs_forum extends plugin_nayuan_request_logs {

    public function post_report_message($param) {
        $param['message'] = $param['param'][0];
        $value = $param['param'][2];
        if(!$value) $value = array();
        if (in_array($param['message'], self::$postReportAction)) {
            switch ($param['message']) {
                case 'post_newthread_succeed':
                case 'post_newthread_mod_succeed':
                    $this -> write_request_log('new_post', $value['tid']); //发贴日志
                    break;
                case 'post_edit_succeed':
                case 'edit_reply_mod_succeed':
                case 'edit_newthread_mod_succeed':
                    $this -> write_request_log('edit_post', $value['tid']); //编辑贴子日志
                    break;
                case 'post_reply_succeed':
                case 'post_reply_mod_succeed':
                    $this -> write_request_log('reply_post', $value['tid']); //回贴日志
                default:break;
            }
        }
    }

    public function viewthread() {
        global $_G;
        $this -> write_request_log('view_post', $_G['tid']); //浏览贴子
    }

}

class plugin_nayuan_request_logs_group extends plugin_nayuan_request_logs_forum {}
class plugin_nayuan_request_logs_home extends plugin_nayuan_request_logs_forum {

    public function spacecp_follow_report_message($param) {
        $param['message'] = $param['param'][0];
        $value = $param['param'][2];
        if(!$value) $value = array();
        if (in_array($param['message'], self::$postReportAction)) {
            switch ($param['message']) {
                case 'post_newthread_succeed':
                case 'post_newthread_mod_succeed':
                    $this -> write_request_log('new_post', $value['tid']); //发贴日志
                    break;
                case 'post_edit_succeed':
                case 'edit_reply_mod_succeed':
                case 'edit_newthread_mod_succeed':
                    $this -> write_request_log('edit_post', $value['tid']); //编辑贴子日志
                    break;
                case 'post_reply_succeed':
                case 'post_reply_mod_succeed':
                    $this -> write_request_log('reply_post', $value['tid']); //回贴日志
                default:break;
            }
        }
    }
}

class plugin_nayuan_request_logs_member extends plugin_nayuan_request_logs {

    public function logging_report_message($param) {
        global $_G;

        $param['message'] = $param['param'][0];
        if (in_array($param['message'], self::$userReportAction)) {
            $this -> write_request_log('login_user'); //登录
        }
    }

    public function register_report_message($param) {
        global $_G;
        $param['message'] = $param['param'][0];
        if (in_array($param['message'], self::$userReportAction)) {
            $this -> write_request_log('register_user');  //注册
        }
    }
    public function connect_report_message($param) {
        global $_G;
        $param['message'] = $param['param'][0];
        if (($_POST['regsubmit'] || $_POST['loginsubmit']) && $_POST['formhash']) {
            if ($_POST['loginsubmit']) {
                $this -> write_request_log('login_user');  //登录
            } else {
                $this -> write_request_log('register_user'); //注册
            }
        }
    }

}

class plugin_nayuan_request_logs_connect extends plugin_nayuan_request_logs_member {

    public function login_report_message($param) {
        $param['message'] = $param['param'][0];
        if (in_array($param['message'], self::$userReportAction)) {
            switch ($param['message']) {
                case login_succeed:
                case location_login_succeed:
                case location_login_succeed_mobile:
                    $this -> write_request_log('login_user'); //登录
                default:break;
            }
        }
    }

}

class plugin_nayuan_request_logs_plugin extends plugin_nayuan_request_logs {

    // wq_login plugin
    function wq_login_message($value) {
        $message_code = $value['param'][0];
        if($message_code == 'register_succeed') {
            $this -> write_request_log('register_user');  //注册
        }else if($message_code == 'login_succeed') {
            $this -> write_request_log('login_user');  //登录
        }

    }

}


class mobileplugin_nayuan_request_logs extends plugin_nayuan_request_logs {}

class mobileplugin_nayuan_request_logs_forum extends plugin_nayuan_request_logs_forum {}

class mobileplugin_nayuan_request_logs_member extends plugin_nayuan_request_logs_member {}

class mobileplugin_nayuan_request_logs_plugin extends plugin_nayuan_request_logs_plugin {}

class mobileapiplugin_nayuan_request_logs_member extends plugin_nayuan_request_logs_member {

    public function login_variables($params) {
        global $_G;
        if($_G['uid']) {
            $this -> write_request_log('login_user');  //登录
        }
    }

    public function register_variables($params) {
        global $_G;
        if($_G['uid']) {
            $this -> write_request_log('register_user'); //注册
        }
    }

    public function newthread_variables($params) {
        if($params['tid']) {
            $this -> write_request_log('new_post', $params['tid']); //发贴日志
        }
    }

    public function sendreply_variables($params) {
        if($params['tid'] && $_GET['replysubmit']) {
            $this -> write_request_log('reply_post', $params['tid']); //回贴日志
        }

    }

}
//dis'.'m.t'.'ao'.'bao.com
?>