<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      report.class.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nayuan_report {

    public function plugin_nayuan_report() {
        global $_G;
        loadcache('nayuan_report');
        $this -> options = $_G['cache']['nayuan_report'];
    }

    protected function run_hook($name) {
        $hooks = $this -> options['hooks'][$name];
        if($hooks) {
            foreach ($hooks as $hook) {
                require DISCUZ_ROOT . 'source/plugin/nayuan_report/source/hook/hook_nayuanreport_' . $hook . '.inc.php';
            }
        }
    }
}

class plugin_nayuan_report_forum extends plugin_nayuan_report {

    public function forumdisplay_output($params) {
        $this -> run_hook('forumdisplay_' . $params['template']);
    }

    public function viewthread_output($params) {
        $this -> run_hook('viewthread_' . $params['template']);
    }

    public function post_report_message($param) {
        $action = $param['param'][0];
        if (in_array($action, array('post_newthread_succeed', 'post_newthread_mod_succeed'))) {
            $this -> run_hook('newthread');
        }
    }

}

class plugin_nayuan_report_home extends plugin_nayuan_report_forum {

    public function spacecp_follow_report_message($param) {
        $action = $param['param'][0];
        if (in_array($action, array('post_newthread_succeed', 'post_newthread_mod_succeed'))) {
            $this -> run_hook('newthread');
        }
    }

}

class mobileplugin_nayuan_report extends plugin_nayuan_report {}

class mobileplugin_nayuan_report_forum extends plugin_nayuan_report_forum {}

class mobileapiplugin_nayuan_report_forum extends plugin_nayuan_report {

    public function forumdisplay_output($params) {
        $this -> run_hook('forumdisplay_forumdisplay');
    }

    public function viewthread_output($params) {
        $this -> run_hook('viewthread_viewthread');
    }

    public function newthread_variables($params) {
        if($params['tid']) {
            $this -> run_hook('newthread');
        }
    }

}

?>