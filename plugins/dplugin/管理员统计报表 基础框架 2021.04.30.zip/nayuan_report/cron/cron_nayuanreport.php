<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      cron_nayuanreport.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


//cronname:cron_title
//week:-1
//day:-1
//hour:-1
//minute:0

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache("nayuan_report");
$options = $_G['cache']['nayuan_report'];

if($options['crons']) {

    foreach ($options['crons'] as $name) {
        @include DISCUZ_ROOT . 'source/plugin/nayuan_report/source/cron/cron_nayuanreport_' . $name . '.php';
    }


}


?>