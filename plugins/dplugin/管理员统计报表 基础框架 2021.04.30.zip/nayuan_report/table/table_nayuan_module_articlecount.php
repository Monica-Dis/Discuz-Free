<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_articlecount.php.
 *      Author DisM.Taobao.Com.
 *      Time 2021-03-08 11:58:15.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_articlecount extends discuz_table {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function fetch_count_by_category($bm,$em) {
		if($bm && $em){
			$bm = strtotime($bm);
			$em = strtotime($em);
			$where = " where c.dateline BETWEEN $bm and $em";
		}
		
        $fields = "a.catid, b.catname, sum(a.viewnum) as viewnum, sum(a.commentnum) as commentnum, sum(a.favtimes) as favtimes, sum(a.sharetimes) as sharetimes,count(a.aid) as acount";
		$data = DB::fetch_all("SELECT $fields FROM %t as a left join %t as b on a.catid = b.catid left join %t as c on a.aid=c.aid $where  group by a.catid order by a.viewnum", array('portal_article_count', 'portal_category','portal_article_title'));
        return $data;
    }

}

?>