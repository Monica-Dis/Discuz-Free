<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_data_cache.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_data_cache extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_data_cache';
        $this->_pk    = 'cid';
        parent::__construct(); //Dism_taobao-com
    }

    public function exist_by_cid($cid) {
        return DB::result_first("SELECT 1 FROM %t WHERE `cid` = %s", array($this -> _table, $cid));
    }

    public function delete_by_time($time) {
        DB::query("DELETE FROM %t WHERE `time` < %d", array($this -> _table, $time));
    }

    public function count_data_by_type_time($type, $stime, $etime) {
        return DB::fetch_all("SELECT `id`,sum(`value`) FROM %t WHERE `time` >= %d AND `time` < %d AND `type` = %d GROUP BY `id`", array($this -> _table, $stime, $etime, $type));
    }

    public function fetch_all_by_time($type, $stime, $etime) {
        return DB::fetch_all('SELECT `id`,`value` FROM %t WHERE `type` = %d AND `time` >= %d AND `time` <= %d ORDER BY `time`', array($this -> _table, $type, $stime, $etime));
    }

}

?>