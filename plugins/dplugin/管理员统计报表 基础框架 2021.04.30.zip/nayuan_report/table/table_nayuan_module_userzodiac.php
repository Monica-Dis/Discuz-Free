<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_userzodiac.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_userzodiac extends table_common_member_profile {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function count_all_by_zodiac() {
        return DB::fetch_all("SELECT `zodiac`,count(*) as `value` FROM %t GROUP BY `zodiac`", array($this -> _table));
    }

}

?>