<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumthreadfavorites_thread.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumthreadfavorites_thread extends table_forum_thread {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function fetch_thread_data_by_tid($tids) {
        return DB::fetch_all("SELECT a.tid, a.subject, a.fid, b.name FROM %t a, %t b WHERE a.fid = b.fid AND a.tid in (%n)", array($this->get_table_name(0), 'forum_forum', $tids));
    }

}

?>