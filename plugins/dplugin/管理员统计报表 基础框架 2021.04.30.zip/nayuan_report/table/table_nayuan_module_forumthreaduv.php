<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumthreaduv.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumthreaduv extends table_home_favorite {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function count_thread_by_time($nums, $stime, $etime) {
        return DB::fetch_all("SELECT `id`,count(*) as nums FROM %t WHERE `time` >= %d AND `time` < %d AND `type` = %d GROUP BY `id` ORDER BY `nums` desc LIMIT %d", array('nayuan_data_cache', $stime, $etime, 3060001, $nums));
    }

}

?>