<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_usergender.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_usergender extends table_common_member_profile {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function count_all_by_gender() {
        return DB::fetch_all("SELECT `gender`,count(*) as `value` FROM %t GROUP BY `gender`", array($this -> _table));
    }

}

?>