<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumuserthreads.php.
 *      Author DisM.Taobao.Com.
 *      Time 2021-01-08 15:46:12.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumuserthreads extends discuz_table {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function fetch_list($fids, $uid, $stime, $etime, $num) {
        $wherestr = $params = array();
        $wherestr[] = 'a.authorid = b.uid';
        $params[] = 'forum_thread';
        $params[] = 'common_member';

        if($fids) {
            $wherestr[]= 'a.`fid` in (%n)';
            $params[] = $fids;
        }
        if($uid) {
            $wherestr[]= 'a.`authorid` = %d';
            $params[] = $uid;
        }
        if($stime) {
            $wherestr[] = 'a.`dateline` >= %d';
            $params[] = dmktime($stime);
        }
        if($etime) {
            $wherestr[] = 'a.`dateline` < %d';
            $params[] = dmktime($etime) + 86400;
        }

        $wherestr[] = 'a.`displayorder` > -1';

        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }else{
            $wherestr = '';
        }

        return DB::fetch_all("SELECT a.`authorid`, b.username, count(*) as `num` FROM %t a, %t b $wherestr GROUP BY a.`authorid` DESC ORDER BY `num` DESC LIMIT $num", $params);
    }


}

?>