<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_data_one.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_data_one extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_data_one';
        $this->_pk    = 'type';
        parent::__construct(); //Dism_taobao-com
    }

    public function fetch_last_update_time($type, $max = 99991231) {
        return DB::result_first("SELECT `time` FROM %t WHERE `type` = %d AND `time` < %d ORDER BY `time` DESC LIMIT 1", array($this -> _table, $type, $max));
    }

    public function fetch_first_update_time($type, $min = 10000101) {
        return DB::result_first("SELECT `time` FROM %t WHERE `type` = %d AND `time` > %d ORDER BY `time` LIMIT 1", array($this -> _table, $type, $min));
    }

    public function sum_by_time($type, $stime, $etime) {
        return DB::result_first("SELECT sum(`value`) FROM %t WHERE `type` = %d AND `time` >= %d AND `time` < %d", array($this -> _table, $type, $stime, $etime));
    }

    public function fetch_all_by_time($type, $stime, $etime) {
        return DB::fetch_all('SELECT `time`,`value` FROM %t WHERE `type` = %d AND `time` >= %d AND `time` <= %d ORDER BY `time`', array($this -> _table, $type, $stime, $etime));
    }

    public function update_by_type_time($type, $time,$value) {
        DB::update($this -> _table, array('value' => $value), array('type' => $type, 'time' => $time));
    }

    public function fetch_by_type_time($type, $time) {
        return DB::result_first("SELECT `value` FROM %t WHERE `type` = %d AND `time` = %d", array($this -> _table, $type, $time));
    }

}

?>