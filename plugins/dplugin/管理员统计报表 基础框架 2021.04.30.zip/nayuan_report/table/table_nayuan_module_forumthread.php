<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      table_nayuan_module_forumthread.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_module_forumthread extends table_forum_post {

    public function __construct() {
        parent::__construct(); //Dism_taobao-com
    }

    public function count_all_by_stime_etime($format, $stime, $etime) {
        return DB::fetch_all("SELECT FROM_UNIXTIME(dateline, %s) as `time`,count(*) as `value` FROM %t WHERE dateline >= %d and dateline < %d and `first` = 1 AND invisible=0 GROUP BY FROM_UNIXTIME(dateline, %s)", array($format, self::get_tablename(0), $stime, $etime, $format));
    }

    public function count_by_stime_etime($stime, $etime) {
        return DB::result_first("SELECT count(*) as `value` FROM %t WHERE dateline >= %d and dateline < %d and `first` = 1 AND invisible=0", array(self::get_tablename(0), $stime, $etime));
    }

    public function fetch_first_time() {
        return DB::result_first("SELECT dateline FROM %t ORDER BY `pid`", array(self::get_tablename(0)));
    }

}

?>