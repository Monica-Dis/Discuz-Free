<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_forumreplytime.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 3020;
$m = 'forum';
$s = 'replytime';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_one') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay || $_lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_forum = nayuan_get('s_forum', 0, 0);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);

    if(!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = dgmdate(strtotime('-6 day'), 'Y-m-d');
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
    showtableheader('search');
    showtablerow('', array('width="80"', 'width="80"', 'width="80"', 'width="255"', 'width="170"', ''),
        array(
            $lang_nayuan_report['lang_search_forum'], '<input type="checkbox" name="s_forum" value="1" '.($s_forum ? 'checked="checked"' : '').' />',
            $lang_nayuan_report['lang_search_time'], '<input type="text" class="txt" id="search_form_stime" name="s_stime" value="'.$s_stime.'" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" id="search_form_etime" name="s_etime" value="'.$s_etime.'" style="width: 108px; margin-left: 5px;">',
            '<a href="javascript:set_form_time(1);">'.$lang_nayuan_report['lang_lately_7_days'].'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(2);">'.$lang_nayuan_report['lang_lately_15_days'].'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(3);">'.lang('plugin/nayuan_report', 'lately_30_days').'</a>',
            "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"".cplang('search')."\" />&nbsp;&nbsp;&nbsp;&nbsp;<input class=\"btn\" onclick=\"export_echart_data()\" type=\"button\" value=\"".$lang_nayuan_report['lang_export']."\" />"
        )
    );

    showtablerow('', array('colspan="5"'), array($lang_nayuan_report['lang_format_tips']));
    showtablefooter();
    showformfooter();
    echo <<<SCRIPT
<script type="text/Javascript">
    function set_form_time(type) {
        let today = new Date();
        document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        if(type == 1) {
            today.setDate(today.getDate() - 6);
        }else if(type == 2) {
            today.setDate(today.getDate() - 14);
        }else if(type == 3) {
            today.setDate(today.getDate() - 29);
        }
        document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
    
    function export_echart_data() {
        var opt = nayuanDataChart.getOption();
        var legend = opt.legend[0].data;
        let xAxisData = opt.xAxis[0].data;
        var series = opt.series;
        var excel = ',';
        for(var name of legend) {
            excel += name + ',';
        }
        excel += "\\n";
        
        for (var i = 0; i < xAxisData.length; i++) {
            excel += xAxisData[i] + ',';
            for (var j = 0, l = series.length; j < l; j++) {
                excel += series[j].data[i] + ',';    
            }
            excel += "\\n";
        }
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>
SCRIPT;
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_forumreplytime_loaddata($type, $s_forum, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_forumreplytime_showchart($_chart_title, $s_forum, $_data, $lang_nayuan_report, '100%', '350px');
}else if($a == 'init') {

    $_etime = dmktime(dgmdate(time(), 'Y-m-d'));
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_one') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay) {
        $_stime = time() - 86400 * 30;
    }else{
        $_stime = dmktime(preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $_lastUpdateDay)) + 86400;
    }

    while($_stime < $_etime) {
        $_time = dgmdate($_stime, 'Ymd');

        $_cache = array();
        $_data = C::t('#nayuan_report#nayuan_module_forumreplytime_post') -> fetch_first_reply_by_stime_etime($_stime, $_stime + 86400); //首次回复的贴子和时间列表
        foreach ($_data as $_item) {
            $_cache[$_item['tid']] = $_item['dateline'];
        }

        $_sum_hour = 0;  //首次回复总耗费时间，秒
        $_fid_hour = array(); //每个板块回复总耗费时间  秒
        $_data = C::t('#nayuan_report#nayuan_module_forumreplytime_thread') -> fetch_thread_dateline_by_tids(array_keys($_cache)); //发贴时间
        foreach ($_data as $_item) {
            $_time_diff = $_cache[$_item['tid']] - $_item['dateline']; //从发贴到首次回复耗费时间
            $_sum_hour += $_time_diff;
            if(!$_fid_hour[$_item['fid']]) {
                $_fid_hour[$_item['fid']] = array('nums' => 1, 'hour' => $_time_diff);
            }else{
                $_fid_hour[$_item['fid']]['nums'] += 1;
                $_fid_hour[$_item['fid']]['hour'] += $_time_diff;
            }
        }

        $_nums = count($_data);
        if(!$_nums) $_nums = 1;
        C::t('#nayuan_report#nayuan_data_one') -> insert(array(
            'time' => $_time,
            'type' => $type,
            'value' => ceil($_sum_hour / 3600 / $_nums * 10) // 显示时需要 /10 代表 多少小时
        ));
        $_data = array();
        foreach ($_fid_hour as $k => $v) {
            if(!$v['nums']) $v['nums']= 1;
            $_data[$k] = ceil($v['hour'] / 3600 / $v['nums'] * 10); //显示时需要 /10 代表 多少小时
        }
        C::t('#nayuan_report#nayuan_data_more') -> insert(array(
            'time' => $_time,
            'type' => $type,
            'value' => serialize($_data)
        ));

        $_stime += 86400;
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>