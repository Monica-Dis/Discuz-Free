<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_forumforumuv.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-07-06 11:03:15.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 3050;
$m = 'forum';
$s = 'forumuv';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay || $_lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init", 'loading');
    }

    showtips($lang_nayuan_report['lang_tips']);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_type = nayuan_get('s_type', 0, 1);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);
    $s_forums = nayuan_get('s_forums', 3, array());

    if(!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = dgmdate(strtotime('-6 day'), 'Y-m-d');
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
    showtableheader('search');

    require_once libfile('function/forumlist');
    $_forum_select_html = '<select name="s_forums[]" size="5" multiple="multiple"><option value="">'.cplang('all').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
    foreach($s_forums as $v) {
        $_forum_select_html = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $_forum_select_html);
    }
    showtablerow('', array('width="80" rowspan="3"', 'width="150" rowspan="3"'), array(
        $lang_nayuan_report['lang_search_forms'],
        $_forum_select_html
    ));
    showtablerow('', array('width="100"', 'width="80"', 'width="80"', ''),
        array(
            lang('plugin/nayuan_report', 'type_title'), '<select id="search_form_type" name="s_type" onchange="search_type_change()">' . nayuan_show_options(lang('plugin/nayuan_report', 'type_options'), $s_type, array('3')) . '</select>',
            $lang_nayuan_report['lang_search_time'], '<input type="text" class="txt" id="search_form_stime" onclick="showcalendar(event, this)" name="s_stime" value="'.$s_stime.'" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" onclick="showcalendar(event, this)" id="search_form_etime" name="s_etime" value="'.$s_etime.'" style="width: 108px; margin-left: 5px;">',
        )
    );
    showtablerow('', array('colspan="4"'),
        array(
            '<a href="javascript:set_form_time(1);">'.$lang_nayuan_report['lang_lately_7_days'].'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(2);">'.$lang_nayuan_report['lang_lately_15_days'].'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(3);">'.lang('plugin/nayuan_report', 'lately_30_days').'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(4);">'.$lang_nayuan_report['lang_lately_12_month'].'</a>&nbsp;&nbsp; <input class="btn" type="submit" name="searchformsubmit" value="'.cplang('search').'" />',
        )
    );

    showtablefooter();
    showformfooter();
    echo <<<SCRIPT
<script type="text/Javascript">
    function search_type_change() {
        document.getElementById('search_form_stime').value = '';
        document.getElementById('search_form_etime').value = '';
    }
    
    function set_form_time(type) {
        let today = new Date();
        document.getElementById('search_form_type').value = 1;
        document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        if(type == 1) {
            today.setDate(today.getDate() - 6);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else if(type == 2) {
            today.setDate(today.getDate() - 14);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else if(type == 3) {
            today.setDate(today.getDate() - 29);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else if(type == 4) {
            document.getElementById('search_form_type').value = 2;
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
            today.setMonth(today.getMonth() - 11);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
        }
        
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
    
    function export_echart_data() {
        var opt = nayuanDataChart.getOption();
        var legend = opt.legend[0].data;
        let xAxisData = opt.xAxis[0].data;
        var series = opt.series;
        var excel = ',';
        for(var name of legend) {
            excel += name + ',';
        }
        excel += "\\n";
        
        for (var i = 0; i < xAxisData.length; i++) {
            excel += xAxisData[i] + ',';
            for (var j = 0, l = series.length; j < l; j++) {
                excel += series[j].data[i] + ',';    
            }
            excel += "\\n";
        }
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    function export_table_data() {
        var excel = '';
        var trs = document.getElementById('forumuv-list').getElementsByTagName('tr');
        for(var i = 0; i < trs.length; i++) {
            var tds = trs[i].getElementsByTagName('td');
            if(tds.length == 0) {
                tds = trs[i].getElementsByTagName('th');
            }
            for(var j = 0; j < tds.length; j++) {
                excel += tds[j].innerText + ',';
            }
            excel += '\\n';
        }
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>
SCRIPT;
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_forumforumuv_loaddata($type, $s_type, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    $_table_title = $lang_nayuan_report['lang_table_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_forumforumuv_showchart($_chart_title, $_table_title, $s_forums, $_data, $lang_nayuan_report, '100%', '350px');
}else if($a == 'init') {

    $_etime = dmktime(dgmdate(time(), 'Y-m-d'));
    $_lastUpdateDay = C::t('#nayuan_report#nayuan_data_more') -> fetch_last_update_time($type);
    if(!$_lastUpdateDay) {
        $_stime = time() - 86400 * 30;
    }else{
        $_stime = dmktime(preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $_lastUpdateDay)) + 86400;
    }

    $months = array();
    while($_stime < $_etime) {
        $_time = dgmdate($_stime, 'Ymd');

        preg_match('/^(\d{4})(\d{2})(\d{2})$/', $_time, $_matchs);
        $_month = $_matchs[1].$_matchs[2];
        if(!$months[$_month]) $months[$_month] = 1;

        $_cache = array();
        $_data = C::t('#nayuan_report#nayuan_module_forumforumuv') -> count_forum_by_time($_stime, $_stime + 86400); //日板块收藏数量
        foreach ($_data as $_item) {
            $_cache[$_item['id']] = $_item['nums'];
        }

        C::t('#nayuan_report#nayuan_data_more') -> insert(array(
            'time' => $_time,
            'type' => $type,
            'value' => serialize($_cache)
        ));

        $_stime += 86400;
    }

    //// 更新月统计数据
    foreach ($months as $month => $v) {
        preg_match('/^(\d{4})(\d{2})$/', $month, $matchs);
        $time = mktime(0, 0, 0, $matchs[2], 1, $matchs[1]);
        $etime = strtotime('+1 month', $time);

        $_data = C::t('#nayuan_report#nayuan_module_forumforumuv') -> count_forum_by_time($time, $etime);
        $_cache = array();
        foreach ($_data as $_item) {
            $_cache[$_item['id']] = $_item['nums'];
        }

        $exist = C::t('#nayuan_report#nayuan_data_more') -> exist_by_type_time($type, $month);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_more') -> update_by_type_time($type, $month, serialize($_cache));
        }else{
            C::t('#nayuan_report#nayuan_data_more') -> insert(array(
                'time' => $month,
                'type' => $type,
                'value' => serialize($_cache)
            ));
        }
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>