<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_userregister.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 1010;
$m = 'user';
$s = 'register';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////// 检测数据是否需要更新
    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    $lastUpdateDay = C::t('#nayuan_report#nayuan_data_one') -> fetch_last_update_time($type);

    if(!$lastUpdateDay || $lastUpdateDay < $_yestoday) {
        cpmsg('nayuan_report:data_loading', "action=$adminurl&m=$m&s=$s&a=init&sdate=$lastUpdateDay", 'loading');
    }
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_type = nayuan_get('s_type', 0, 1);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);
    nayuanreport_show_search_form($s_type, $s_stime, $s_etime, "$adminurl&m=$m&s=$s");
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_userregister_loaddata($type, $s_type, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_chart_title = $lang_nayuan_report['lang_chart_title'] . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_userregister_showchart($_chart_title, $_data, $lang_nayuan_report, '100%', '350px');
}else if($a == 'init') {

    $lastUpdateDay = nayuan_get('sdate');
    if(!$lastUpdateDay) {
        $firstUserRegDate = C::t('#nayuan_report#nayuan_module_userregister') -> fetch_first_user_regdate();
        if(!$firstUserRegDate) $firstUserRegDate = time();
        $lastUpdateDay = dgmdate($firstUserRegDate - 86400, 'Ymd');
    }

    $_yestoday = dgmdate(time() - 86400, 'Ymd');
    preg_match('/^(\d{4})(\d{2})(\d{2})$/', $lastUpdateDay, $matchs);
    $starttime = mktime(0, 0, 0, $matchs[2], $matchs[3], $matchs[1]);
    $months = $years = array();
    //// 更新日统计数据
    while($lastUpdateDay < $_yestoday) {
        $starttime += 86400;
        $lastUpdateDay = dgmdate($starttime, 'Ymd');
        preg_match('/^(\d{4})(\d{2})(\d{2})$/', $lastUpdateDay, $matchs);
        $month = $matchs[1].$matchs[2];
        if(!$months[$month]) $months[$month] = 1;
        $year = $matchs[1];
        if(!$years[$year]) $years[$year] = 1;
        $endtime = $starttime + 86400;
        $value = C::t('#nayuan_report#nayuan_module_userregister') -> count_by_regdate($starttime, $endtime);
        C::t('#nayuan_report#nayuan_data_one') -> insert(array(
            'time' => $lastUpdateDay,
            'type' => $type,
            'value' => $value
        ));
    }

    //// 更新月统计数据
    foreach ($months as $month => $v) {
        preg_match('/^(\d{4})(\d{2})$/', $month, $matchs);
        $time = mktime(0, 0, 0, $matchs[2], 1, $matchs[1]);
        $stime = dgmdate($time, 'Ymd');
        $etime = dgmdate(strtotime('+1 month', $time), 'Ymd');
        $value = C::t('#nayuan_report#nayuan_data_one') -> sum_by_time($type, $stime, $etime);
        $exist = C::t('#nayuan_report#nayuan_data_one') -> fetch_by_type_time($type, $month);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_one') -> update_by_type_time($type, $month, $value);
        }else{
            C::t('#nayuan_report#nayuan_data_one') -> insert(array(
                'time' => $month,
                'type' => $type,
                'value' => $value
            ));
        }
    }
    //// 更新年统计数据
    foreach ($years as $year => $v) {
        $value = C::t('#nayuan_report#nayuan_data_one') -> sum_by_time($type, $year . '01', ($year + 1) . '01');
        $exist = C::t('#nayuan_report#nayuan_data_one') -> fetch_by_type_time($type, $year);
        if(isset($exist)) {
            C::t('#nayuan_report#nayuan_data_one') -> update_by_type_time($type, $year, $value);
        }else{
            C::t('#nayuan_report#nayuan_data_one') -> insert(array(
                'time' => $year,
                'type' => $type,
                'value' => $value
            ));
        }
    }

    cpmsg('nayuan_report:data_loaded', "action=$adminurl&m=$m&s=$s&a=show", 'succeed');
}


?>