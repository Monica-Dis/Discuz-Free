<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_articlecount.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2021-03-08 11:58:15.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 4010;
$m = 'article';
$s = 'count';

/////////////////////////////////////////////////////////////
//////////////// 渲染查询表单
/////////////////////////////////////////////////////////////
$s_top = nayuan_get('s_top', 0, 100);

showtips($lang_nayuan_report['lang_tips']);

echo <<<SCRIPT
<script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.js"></script>
<script type="text/Javascript">
    
    function export_table_data() {
        var excel = '';
        var trs = document.getElementById('article-count-list').getElementsByTagName('tr');
        for(var i = 0; i < trs.length; i++) {
            var tds = trs[i].getElementsByTagName('td');
            if(tds.length == 0) {
                tds = trs[i].getElementsByTagName('th');
            }
            for(var j = 0; j < tds.length; j++) {
                excel += tds[j].innerText + ',';
            }
            excel += '\\n';
        }
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

	$(function(){
		$("#e").change(function() {
				var b = $("#b").val();
				var e = $(this).val();
				if (b.length != 0 && e.length != 0) {
					var time1 = new Date(b);
					var time2 = new Date(e);
					if (time1.getTime() > time2.getTime()) {
						alert('开始时间不能大于结束时间');
						return;
					}
					//target="main"
					window.parent.frames.location.href='admin.php?frames=yes&action=plugins&operation=config&do=58&m=article&s=count&b=' + b + '&e=' + e;
					//location.href = 'admin.php?frames=yes&action=plugins&operation=config&do=58&m=article&s=count&b=' + b + '&e=' + e;
				}
			});
			$("#b").change(function() {
				var b = $(this).val();
				var e = $("#e").val();
				if (b.length != 0 && e.length != 0) {
					var time1 = new Date(b);
					var time2 = new Date(e);
					if (time1.getTime() > time2.getTime()) {
						alert('开始时间不能大于结束时间');
						return;
					}
					window.parent.frames.location.href='admin.php?frames=yes&action=plugins&operation=config&do=58&m=article&s=count&b='+b+'&e=' + e;
				}
			});
	});
</script>
SCRIPT;
/////////////////////////////////////////////////////////////
//////////////// 渲染查询数据
/////////////////////////////////////////////////////////////

showtableheader($lang_nayuan_report['lang_list_title'] . '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="export_table_data()">'.$lang_nayuan_report['lang_export'].'</a>'."&nbsp;<input type='date' id='b' value='".$_GET['b']."' />&nbsp;<input type='date' id='e' value='".$_GET['e']."'/>", '', 'id="article-count-list"');
showsubtitle(array(
	
    $lang_nayuan_report['lang_header_cat'],
	'文章',
    $lang_nayuan_report['lang_header_viewnum'],
    $lang_nayuan_report['lang_header_commentnum'],
    $lang_nayuan_report['lang_header_favtimes'],
    $lang_nayuan_report['lang_header_sharetimes'],
	

), 'header', array(
    '',
    'class="td31" style="text-align:right"',
    'class="td31" style="text-align:right"',
    'class="td31" style="text-align:right"',
    'class="td31" style="text-align:right"',
	'class="td31" style="text-align:right"',
));

$data_list = C::t('#nayuan_report#nayuan_module_articlecount') -> fetch_count_by_category($_GET['b'],$_GET['e']);
if($data_list) {
    foreach ($data_list as $item) {
        showtablerow('',
            array(
                '',
                'class="td31" style="text-align:right"',
                'class="td31" style="text-align:right"',
                'class="td31" style="text-align:right"',
                'class="td31" style="text-align:right"',
				'class="td31" style="text-align:right"',
            ),
            array(
				
                $item['catname'],
				$item['acount'],
                $item['viewnum'],
                $item['commentnum'],
                $item['favtimes'],
                $item['sharetimes'],
				
            )
        );
    }
}else{
    showtablerow('', array('colspan="15"'), array($lang_nayuan_report['lang_no_data']));
}

showtablefooter();



?>