<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      admincp_userbtc.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-07-05 08:21:25.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$type = 1100;
$m = 'user';
$s = 'btc';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport_'.$m.$s.'.func.php';

if($a == 'show') {
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询表单
    /////////////////////////////////////////////////////////////
    $s_top = nayuan_get('s_top', 0, 50);
    $s_stime = nayuan_get('s_stime', 1);
    $s_etime = nayuan_get('s_etime', 1);

    showtips(nayuan_strreplace($lang_nayuan_report['lang_tips'], array('nums' => $s_top)));
    if (!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = dgmdate(strtotime('-6 day'), 'Y-m-d');
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showformheader("$adminurl&m=$m&s=$s", '', 'search_form');
    showtableheader('search');

    showtablerow('', array('width="50"', 'width="80"', 'width="80"', 'width="270"', 'width="220"', ''),
        array(
            'TOP', '<input type="text" class="txt" name="s_top" value="'.$s_top.'" />',
            $lang_nayuan_report['lang_search_time'], '<input type="text" class="txt" id="search_form_stime" onclick="showcalendar(event, this)" name="s_stime" value="' . $s_stime . '" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" onclick="showcalendar(event, this)" id="search_form_etime" name="s_etime" value="' . $s_etime . '" style="width: 108px; margin-left: 5px;">',
            '<a href="javascript:set_form_time(1);">' . $lang_nayuan_report['lang_lately_7_days'] . '</a>&nbsp;&nbsp;<a href="javascript:set_form_time(2);">' . $lang_nayuan_report['lang_lately_15_days'] . '</a>&nbsp;&nbsp;<a href="javascript:set_form_time(3);">' . lang('plugin/nayuan_report', 'lately_30_days') . '</a>',
            "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"" . cplang('search') . "\" />&nbsp;&nbsp;&nbsp;&nbsp;<input class=\"btn\" onclick=\"export_table_data()\" type=\"button\" value=\"" . $lang_nayuan_report['lang_export'] . "\" />"
        )
    );

    showtablefooter();
    showformfooter();
    echo <<<SCRIPT
<script type="text/Javascript">
    function search_type_change() {
        document.getElementById('search_form_stime').value = '';
        document.getElementById('search_form_etime').value = '';
    }
    
    function set_form_time(type) {
        let today = new Date();
        document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        if(type == 1) {
            today.setDate(today.getDate() - 6);
        }else if(type == 2) {
            today.setDate(today.getDate() - 14);
        }else if(type == 3) {
            today.setDate(today.getDate() - 29);
        }
        document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
    
    function export_table_data() {
        var excel = '';
        var trs = document.getElementById('btc-list').getElementsByTagName('tr');
        for(var i = 0; i < trs.length; i++) {
            var tds = trs[i].getElementsByTagName('td');
            if(tds.length == 0) {
                tds = trs[i].getElementsByTagName('th');
            }
            for(var j = 0; j < tds.length; j++) {
                excel += tds[j].innerText + ',';
            }
            excel += '\\n';
        }
        //encodeURIComponent解决中文乱码
        let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(excel);
        //通过创建a标签实现
        let link = document.createElement("a");
        link.href = uri;
        //对下载的文件命名
        link.download =  new Date().getTime() + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>
SCRIPT;
    /////////////////////////////////////////////////////////////
    //////////////// 渲染查询数据
    /////////////////////////////////////////////////////////////
    $_data = nayuanreport_userbtc_loaddata($s_top, $s_stime, $s_etime);
    /////////////////////////////////////////////////////////////
    //////////////// 渲染图表
    /////////////////////////////////////////////////////////////
    $_table_title = nayuan_strreplace($lang_nayuan_report['lang_table_title'], array("nums" => $s_top)) . ' (' . $s_stime . ' ' . lang('plugin/nayuan_report', 'unit_to') . ' ' . $s_etime . ')';
    nayuanreport_userbtc_showtable($_table_title, $_data, $lang_nayuan_report, $s_stime, $s_etime);

}


?>