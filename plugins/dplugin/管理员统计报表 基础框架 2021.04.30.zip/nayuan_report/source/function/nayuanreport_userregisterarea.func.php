<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_userregisterarea.func.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-07-23 11:26:02.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_userregisterarea_loaddata($type, $s_type, &$s_stime, &$s_etime, $lang) {
    if($s_type == 2) {
        $mintime = 100001;
        $_date_format = 'Y-m';
    }else if($s_type == 3) {
        $mintime = 1000;
        $_date_format = 'Y';
    }else{
        $mintime = 10000101;
        $_date_format = 'Y-m-d';
    }
    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_more') -> fetch_first_update_time($type, $mintime);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else if(strlen($s_stime) == 8){
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }else if(strlen($s_stime) == 6) {
            $s_stime = preg_replace('/^(\d{4})(\d{2})$/', '$1-$2', $s_stime);
        }
    }

    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);

    $_data = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    $_nowtime = dgmdate(time(), str_replace('-','', $_date_format));
    if($_etime >= $_nowtime) {
        parse_str($lang['lang_district_short'], $district_cache);
        require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/class/ip2region.class.php';
        $ip2region = new ip2region();
        $nowdata = array();
        $list = C::t('#nayuan_report#nayuan_module_userregisterarea') -> fetch_user_by_regdate(dmktime(dgmdate(time(), 'Y-m-d')), time());
        foreach ($list as $user) {
            $area = $ip2region->memorySearch($user['regip']);
            $area = explode('|', $area['region']);
            $area = mb_substr($area[2], 0, 2);
            $areav = $district_cache[$area];
            if(!$areav) {
                if($area === '0') {
                    $areav = '36';
                }else{
                    $areav = '35';
                }
            }

            if(!$nowdata[$areav]) {
                $nowdata[$areav] = 0;
            }
            $nowdata[$areav]++;
        }

        if(!$_data) {
            $_data[] = array('time' => $_nowtime, 'value' => serialize($nowdata));
        }else{
            $_last_index = count($_data) - 1;
            $_last_data = &$_data[$_last_index];
            if($_last_data['time'] == $_nowtime) {
                $_values = unserialize($_last_data['value']);
                foreach ($nowdata as $name => $value) {
                    if($_values[$name]) {
                        $_values[$name] += $value;
                    }else{
                        $_values[$name] = $value;
                    }
                }

                $_last_data['value'] = serialize($_values);
            }else{
                $_data[] = array('time' => $_nowtime, 'value' => serialize($nowdata));
            }
        }
    }

    return $_data;
}

function nayuanreport_userregisterarea_showpie($_title, $_data, $_lang, $_width, $_height) {
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter();

    $_chart_series_name = $_lang['lang_yaxis_name'];

    parse_str($_lang['lang_district'], $district_cache);

    $datacache = array();
    foreach ($_data as $_item) {
        $values = unserialize($_item['value']);
        foreach ($values as $_id => $_num) {
            if($datacache[$_id]) {
                $datacache[$_id] += $_num;
            }else{
                $datacache[$_id] = $_num;
            }
        }
    }


    $_series = $_legend = array();
    foreach ($district_cache as $_value => $_name) {
        $_v = $datacache[$_value];
        if(!$_v) {
            continue;
        }
        $_legend[] = "\"$_name\"";
        $_series[] = '{name:"'.$_name.'",value: '.$_v.'}';
    }
    $_series = implode(',', $_series);
    $_legend = implode(',', $_legend);
    echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        grid: {
            left: '50px',
            right: '170px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 10,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        series: [{
            name: '$_chart_series_name',
            type: 'pie',
            radius: '55%',
            center: ['40%', '50%'],
            data: [$_series],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }]
    });
</script>
SCRIPT;

}

function nayuanreport_userregisterarea_showline($_title, $did, $_data, $_lang, $_width, $_height) {
    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter();

    $_newdata = array();
    foreach ($_data as $_item) {
        $_values = unserialize($_item['value']);
        $_num = $_values[$did] ? $_values[$did] : 0;
        $_newdata[] = array('time' => $_item['time'], 'value' => $_num);
    }

    if($_newdata) {
        $_labels = $_values = array();
        foreach ($_newdata as $_item) {
            $_labels[] = $_item['time'];
            $_values[] = $_item['value'];
        }
        $_labels = implode(',', $_labels);
        $_values = implode(',', $_values);
        echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        grid: {
            left: '50px',
            right: '50px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_labels]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [{
            name: '$_chart_yaxis_name',
            type: 'line',
            smooth: true,
            data: [$_values]
        }]
    });
</script>
SCRIPT;

    }

}

?>