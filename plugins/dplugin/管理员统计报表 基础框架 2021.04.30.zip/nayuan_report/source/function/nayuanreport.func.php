<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport.func.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_show_search_form($s_type, &$s_stime, &$s_etime, $url) {
    if(!submitcheck('searchformsubmit') && !$s_stime && !$s_etime) {
        $s_etime = dgmdate(time(), 'Y-m-d');
        $s_stime = dgmdate(strtotime('-30 day'), 'Y-m-d');
    }

    echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
    showformheader($url, '', 'search_form');
    showtableheader('search');
    showtablerow('', array('width="80"', 'width="80"', 'width="255"', 'width="170"', ''),
        array(
            lang('plugin/nayuan_report', 'type_title'), '<select id="search_form_type" name="s_type" onchange="search_type_change()">' . nayuan_show_options(lang('plugin/nayuan_report', 'type_options'), $s_type) . '</select>',
            '<input type="text" class="txt" id="search_form_stime" onclick="showcalendar(event, this)" name="s_stime" value="'.$s_stime.'" style="width: 108px; margin-right: 5px;">-<input type="text" class="txt" onclick="showcalendar(event, this)" id="search_form_etime" name="s_etime" value="'.$s_etime.'" style="width: 108px; margin-left: 5px;">',
            '<a href="javascript:set_form_time(1);">'.lang('plugin/nayuan_report', 'lately_30_days').'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(2);">'.lang('plugin/nayuan_report', 'lately_12_months').'</a>&nbsp;&nbsp;<a href="javascript:set_form_time(3);">'.lang('plugin/nayuan_report', 'lately_6_year').'</a>',
            "<input class=\"btn\" type=\"submit\" name=\"searchformsubmit\" value=\"".cplang('search')."\" />"
        )
    );
    showtablerow('', array('colspan="5"'), array(lang('plugin/nayuan_report', 'format_tips')));
    showtablefooter();
    showformfooter();
    echo <<<SCRIPT
<script type="text/Javascript">
    function search_type_change() {
        document.getElementById('search_form_stime').value = '';
        document.getElementById('search_form_etime').value = '';
    }
    
    function set_form_time(type) {
        document.getElementById('search_form_type').value = type;
        let today = new Date();
        if(type == 1) {
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
            today.setDate(today.getDate() - 29);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1) + '-' + format_time_str(today.getDate());
        }else if(type == 2) {
            document.getElementById('search_form_etime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
            today.setMonth(today.getMonth() - 11);
            document.getElementById('search_form_stime').value = today.getFullYear() + '-' + format_time_str(today.getMonth() + 1);
        }else if(type == 3) {
            document.getElementById('search_form_etime').value = today.getFullYear();
            today.setFullYear(today.getFullYear() - 5);
            document.getElementById('search_form_stime').value = today.getFullYear();
        }
        document.getElementById('search_form').submit();
    }
    
    function format_time_str(value) {
        if(value > 9) return value;
        return '0' + value;
    }
</script>
SCRIPT;
}


?>