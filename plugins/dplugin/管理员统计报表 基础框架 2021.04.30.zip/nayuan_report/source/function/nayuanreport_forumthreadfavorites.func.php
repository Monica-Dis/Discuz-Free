<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_forumthreadfavorites.func.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_forumthreadfavorites_loaddata($nums, &$s_stime, &$s_etime) {
    $_date_format = 'Y-m-d';

    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = $s_etime;
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }

    $_stime = dmktime($s_stime);
    $_etime = dmktime($s_etime);

    $_result = C::t('#nayuan_report#nayuan_module_forumthreadfavorites') -> count_thread_by_time($nums, $_stime, $_etime);

    return $_result;
}

function nayuanreport_forumthreadfavorites_showtable($_title, $_data, $_lang) {

    showtableheader($_title, '', 'id="threadfavorites-list"');
    showsubtitle(array(
        '',
        $_lang['lang_table_header_tid'],
        $_lang['lang_table_header_subject'],
        $_lang['lang_table_header_favorites'],
        $_lang['lang_table_header_fid'],
        $_lang['lang_table_header_forum'],
    ), 'header', array(
        'class="td25"',
        'class="td25"',
        '',
        'class="td23" style="text-align:right"',
        'class="td25"',
        'class="td23 center"',
    ));
    if($_data) {
        $tids = array();
        foreach ($_data as $_item) {
            $tids[] = $_item['id'];
        }

        $_cache = array();
        $_threaddata = C::t('#nayuan_report#nayuan_module_forumthreadfavorites_thread') -> fetch_thread_data_by_tid($tids);
        foreach ($_threaddata as $_it) {
            $_cache[$_it['tid']] = $_it;
        }

        foreach ($_data as $_index => $_it) {
            $_thread = $_cache[$_it['id']];
            if(!$_thread) $_thread = array();

            showtablerow('', array(
                'class="td25"',
                'class="td25"',
                '',
                'class="td23" style="text-align:right"',
                'class="td25"',
                'class="td23 center"',
            ), array(
                $_index + 1,
                "<a href=\"forum.php?mod=viewthread&tid=$_it[id]\" target=\"_blank\">$_it[id]</a>",
                "<a href=\"forum.php?mod=viewthread&tid=$_it[id]\" target=\"_blank\">$_thread[subject]</a>",
                $_it['nums'],
                "<a href=\"forum.php?mod=forumdisplay&fid=$_thread[fid]\" target=\"_blank\">$_thread[fid]</a>",
                "<a href=\"forum.php?mod=forumdisplay&fid=$_thread[fid]\" target=\"_blank\">$_thread[name]</a>"
            ));
        }
    }else{
        showtablerow('', array("class=\"center\" colspan=\"4\""), array(
            $_lang['lang_not_data']
        ));
    }

    showtablefooter();

}


?>