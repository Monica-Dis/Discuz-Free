<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_forumreplytime.func.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-20 15:17:47.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_forumreplytime_loaddata($type, $s_forum, &$s_stime, &$s_etime) {
    $mintime = 10000101;
    $_date_format = 'Y-m-d';

    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = C::t('#nayuan_report#nayuan_data_one') -> fetch_first_update_time($type, $mintime);
        if(!$s_stime) {
            $s_stime = $s_etime;
        }else{
            $s_stime = preg_replace('/^(\d{4})(\d{2})(\d{2})$/', '$1-$2-$3', $s_stime);
        }
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }
    $_stime = str_replace('-', '', $s_stime);
    $_etime = str_replace('-', '', $s_etime);
    if($s_forum) {
        $_result = C::t('#nayuan_report#nayuan_data_more') -> fetch_all_by_time($type, $_stime, $_etime);
    }else{
        $_result = C::t('#nayuan_report#nayuan_data_one') -> fetch_all_by_time($type, $_stime, $_etime);
    }
    $_nowtime = dgmdate(time(), str_replace('-','', $_date_format));
    if($_etime >= $_nowtime) {
        $_cache = array();
        $_data = C::t('#nayuan_report#nayuan_module_forumreplytime_post') -> fetch_first_reply_by_stime_etime(dmktime(dgmdate(time(), 'Y-m-d')), time()); //首次回复的贴子和时间列表
        foreach ($_data as $_item) {
            $_cache[$_item['tid']] = $_item['dateline'];
        }

        $_sum_hour = 0;  //首次回复总耗费时间，秒
        $_fid_hour = array(); //每个板块回复总耗费时间  秒
        $_data = C::t('#nayuan_report#nayuan_module_forumreplytime_thread') -> fetch_thread_dateline_by_tids(array_keys($_cache)); //发贴时间
        foreach ($_data as $_item) {
            $_time_diff = $_cache[$_item['tid']] - $_item['dateline']; //从发贴到首次回复耗费时间
            $_sum_hour += $_time_diff;
            if(!$_fid_hour[$_item['fid']]) {
                $_fid_hour[$_item['fid']] = array('nums' => 1, 'hour' => $_time_diff);
            }else{
                $_fid_hour[$_item['fid']]['nums'] += 1;
                $_fid_hour[$_item['fid']]['hour'] += $_time_diff;
            }
        }

        if($s_forum) {
            $_data = array();
            foreach ($_fid_hour as $k => $v) {
                if(!$v['nums']) $v['nums']= 1;
                $_data[$k] = ceil($v['hour'] / 3600 / $v['nums'] * 10); //显示时需要 /10 代表 多少小时
            }
            $_result[] = array(
                'time' => $_nowtime,
                'value' => serialize($_data) // 显示时需要 /10 代表 多少小时
            );
        }else{
            $_nums = count($_data);
            if(!$_nums) $_nums = 1;
            $_result[] = array(
                'time' => $_nowtime,
                'value' => ceil($_sum_hour / 3600 / $_nums * 10) // 显示时需要 /10 代表 多少小时
            );
        }
    }

    return $_result;
}

function nayuanreport_forumreplytime_showchart($_title, $_forum, $_data, $_lang, $_width, $_height) {
    global $_G;
    $_chart_xaxis_name = $_lang['lang_xaxis_name'];
    $_chart_yaxis_name = $_lang['lang_yaxis_name'];
    showtableheader($_title);
    showtablerow('', array(''), array('<div id="nayuan_data_chart" style="width: '.$_width.';height:'.$_height.';"></div>'));
    showtablefooter();
    if($_data) {
        if($_forum) {
            $_xaxis = $_datacache = $fids = array();
            foreach ($_data as $_item) {
                $_xaxis[] = $_item['time'];
                $_values = unserialize($_item['value']);
                foreach ($_values as $_fid => $_value) {
                    if(!in_array($_fid, $fids)) {
                        $fids[] = $_fid;
                        $_datacache[$_fid] = array();
                    }
                }
            }

            foreach ($_data as $_item) {
                $_values = unserialize($_item['value']);
                  foreach ($fids as $fid) {
                    if($_values[$fid]) {
                        $_datacache[$fid][] = $_values[$fid] / 10;
                    }else{
                        $_datacache[$fid][] = 0;
                    }
                }
            }

            $forumnamecache = array();
            if($fids) {
                $forumnames = C::t('forum_forum') -> fetch_all_name_by_fid($fids);
                foreach ($forumnames as $_item) {
                    $forumnamecache[$_item['fid']] = $_item['name'];
                }
            }

            $_series = $_legend = array();
            foreach ($_datacache as $_fid => $values) {
                $_name = $forumnamecache[$_fid] . '(' . $_fid . ')';
                $_legend[] = "\"$_name\"";
                $_series[] = '{name:"'.$_name.'",type:"line", smooth: true, data: ['.implode(',', $values).']}';
            }
        }else{
            $_xaxis = $_values = array();
            foreach ($_data as $_item) {
                $_xaxis[] = $_item['time'];
                $_values[] = $_item['value'] / 10;
            }
            $_series = array('{name:"'.$_lang['lang_day_average_time'].'",type:"line", smooth: true, data: ['.implode(',', $_values).']}');
            $_legend = array('"' . $_lang['lang_day_average_time'] . '"');
        }

        $_series = implode(',', $_series);
        $_xaxis = implode(',', $_xaxis);
        $_legend = implode(',', $_legend);

        echo <<<SCRIPT
<script type="text/Javascript">
    let nayuanDataChart = echarts.init(document.getElementById('nayuan_data_chart'));
    nayuanDataChart.setOption({
        title: {
            text: '$_title',
            left: 'center'
        },
        tooltip: {trigger: 'axis'},
        grid: {
            left: '100px',
            right: '150px',
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {readOnly: true},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        legend: {
            type: 'scroll',
            orient: 'vertical',
            right: 20,
            top: 50,
            bottom: 50,
            data: [$_legend]
        },
        xAxis: {
            name: '$_chart_xaxis_name',
            type: 'category',
            data: [$_xaxis]
        },
        yAxis: {
            name: '$_chart_yaxis_name',
            type: 'value'
        },
        series: [$_series]
    });
</script>
SCRIPT;

    }

}


?>