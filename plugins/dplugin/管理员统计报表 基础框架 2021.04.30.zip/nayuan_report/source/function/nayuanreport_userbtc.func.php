<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      nayuanreport_userbtc.func.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-07-05 08:21:25.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuanreport_userbtc_loaddata($nums, &$s_stime, &$s_etime) {
    $_date_format = 'Y-m-d';

    if(!$s_etime) $s_etime = dgmdate(time(), $_date_format);
    if(!$s_stime) {
        $s_stime = $s_etime;
    }
    if(!preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_stime) || !preg_match('/^\d{4}(-\d{1,2})?(-\d{1,2})?$/', $s_etime)) {
        echo '<script>showDialog("'.lang('plugin/nayuan_report', 'validate_time_error').'", "alert")</script>';
    }else if($s_etime < $s_stime) {
        echo '<script>showDialog("' . lang('plugin/nayuan_report', 'validate_between_time_error') . '", "alert")</script>';
    }

    $_stime = dmktime($s_stime);
    $_etime = dmktime($s_etime);

    $_result = C::t('#nayuan_report#nayuan_module_userbtc') -> count_btc_by_time($nums, $_stime, $_etime);

    return $_result;
}

function nayuanreport_userbtc_showtable($_title, $_data, $_lang, $sdate, $edate) {
    global $_G;

    $header_list = array(
        '',
        $_lang['lang_header_user'],
        $_lang['lang_header_nums'],
    );
    for($i=1; $i<=8; $i++) {
        $header_list[] = isset($_G['setting']['extcredits'][$i]) ? $_G['setting']['extcredits'][$i]['title'] : 'extcredits'.$i;
    }
    $header_list[] = '';


    showtableheader($_title, '', 'id="btc-list"');
    showsubtitle($header_list, 'header', array(
        'class="td25"',
        'class="td23"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        'class="td23" style="text-align:right"',
        '',
    ));
    if($_data) {

        foreach ($_data as $_index => $_it) {
            showtablerow('', array(
                'class="td25"',
                'class="td23"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                'class="td23" style="text-align:right"',
                '',
            ), array(
                $_index + 1,
                "<a href=\"home.php?mod=space&uid=$_it[uid]\" target=\"_blank\">$_it[username]</a>",
                "<a href=\"".ADMINSCRIPT."?action=logs&operation=credit&srch_uid=$_it[uid]&srch_starttime=$sdate&srch_endtime=$edate&srch_operation=BTC&perpage=50\" target='_blank'>$_it[nums]</a>",
                $_it['extcredits1'] ? -$_it['extcredits1'] : '',
                $_it['extcredits2'] ? -$_it['extcredits2'] : '',
                $_it['extcredits3'] ? -$_it['extcredits3'] : '',
                $_it['extcredits4'] ? -$_it['extcredits4'] : '',
                $_it['extcredits5'] ? -$_it['extcredits5'] : '',
                $_it['extcredits6'] ? -$_it['extcredits6'] : '',
                $_it['extcredits7'] ? -$_it['extcredits7'] : '',
                $_it['extcredits8'] ? -$_it['extcredits8'] : '',
                ''
            ));
        }
    }else{
        showtablerow('', array("class=\"center\" colspan=\"4\""), array(
            $_lang['lang_not_data']
        ));
    }

    showtablefooter();

}

?>