<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      hook_nayuanreport_forumforumuv.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-07-06 11:03:15.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$_fid = $_G['fid'];
$_uid = $_G['uid'];
if(!$_uid || !$_fid) return;

$_date = dgmdate(time(), 'Y-m-d');
$_type = 3050001;

$_id = md5($_type . $_date . $_fid . $_uid);
$_exist = C::t('#nayuan_report#nayuan_data_cache') -> exist_by_cid($_id);
if($_exist) return;

C::t('#nayuan_report#nayuan_data_cache') -> insert(array(
    'cid' => $_id,
    'type' => $_type,
    'id'    => $_fid,
    'value' => 1,
    'time' => time()
));

?>