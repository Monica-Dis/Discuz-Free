<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      hook_nayuanreport_forumthreaduv.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$_tid = $_G['tid'];
$_uid = $_G['uid'];
if(!$_uid || !$_tid) return;

$_date = dgmdate(time(), 'Y-m-d');
$_type = 3060001;

$_id = md5($_type . $_date . $_tid . $_uid);
$_exist = C::t('#nayuan_report#nayuan_data_cache') -> exist_by_cid($_id);
if($_exist) return;

C::t('#nayuan_report#nayuan_data_cache') -> insert(array(
    'cid' => $_id,
    'type' => $_type,
    'id'    => $_tid,
    'value' => 1,
    'time' => time()
));

?>