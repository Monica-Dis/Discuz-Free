<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_forumthreaduv.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-05-28 22:14:29.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '论坛数据',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'threaduv',
        'title' => '帖子访问用户数量排行',
        'order' => 3060
    ),
    'hooks' => array(
        'viewthread_viewthread' => 'forumthreaduv'
    ),

    'lang_export' => '导出当前查询结果',

    'lang_lately_7_days' => '最近7天',
    'lang_lately_15_days' => '最近15天',
    'lang_lately_30_days' => '最近30天',

    'lang_search_time' => '日期区间',

    'lang_table_title' => '帖子新增用户访问量TOP{nums}',
    'lang_table_header_tid' => '帖子ID',
    'lang_table_header_subject' => '帖子名称',
    'lang_table_header_favorites' => '新增用户访问量',
    'lang_table_header_fid' => '版块ID',
    'lang_table_header_forum' => '版块名称',

    'lang_not_data' => '当前时间段没有帖子被访问哦',

    'lang_tips' => '<li>查询某一时间段内，帖子访问用户数量TOP{nums}条数据，每日同一用户重复访问同一帖子，只计1次</li><li>日期格式：2020-05-20</li>'


);

?>
