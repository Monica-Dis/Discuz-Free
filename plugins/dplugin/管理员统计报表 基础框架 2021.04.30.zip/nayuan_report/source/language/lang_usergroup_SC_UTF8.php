<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_usergroup.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用户数据',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'group',
        'title' => '用户组人数统计',
        'order' => 1020
    ),

    'lang_today_title' => '目前分布情况',
    'lang_lately_30_days' => '近30天变化趋势',
    'lang_chart_pie_title' => '用户组人数分布',
    'lang_chart_lie_title' => '用户组人数变化趋势',
    'lang_xaxis_name' => '组名',
    'lang_yaxis_name' => '人数',
    'lang_system_group' => '系统用户组',
    'lang_member_group' => '会员用户组',
    'lang_special_group' => '自定义用户组',
    'lang_tips' => '<li>数据有延迟, 今日变更的数据，明日才会更新到</li><li>查看一次才会记录一次当天的数据</li>',
    'lang_more_days_error' => '当前时间段只有少于2天的数据记录，不支持查看趋势图',
);

?>
