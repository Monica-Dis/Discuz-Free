<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_creditdays.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-09-07 22:07:16.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'credit',
        'title' => '积分数据',
        'order' => 5000,
    ),
    'menu' => array(
        'name' => 'days',
        'title' => '积分增长趋势',
        'order' => 5020
    ),

    'lang_chart_title' => '积分增长趋势',
    'lang_xaxis_name' => '时间',
    'lang_yaxis_name' => '积分',
    'lang_up' => '增',
    'lang_down' => '减',
    'lang_no_data' => '没有找到数据',
    'lang_export' => '导出当前查询结果',

    'lang_sum_list_title' => '{stime} - {etime} 按类型汇总列表',
    'lang_sum_plus' => '增加积分项目',
    'lang_sum_sub' => '减少积分项目',
    'lang_user_list_title' => '积分变更明细',


);

?>
