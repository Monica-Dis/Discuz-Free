<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_articlecount.php.
 *      Author DisM.Taobao.Com.
 *      Time 2021-03-08 11:58:15.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'article',
        'title' => '门户文章',
        'order' => 4000,
    ),
    'menu' => array(
        'name' => 'count',
        'title' => '栏目数据汇总',
        'order' => 4010
    ),

    'lang_header_cat' => '栏目名称',
    'lang_header_viewnum' => '浏览量',
    'lang_header_commentnum' => '评论量',
    'lang_header_favtimes' => '收藏量',
    'lang_header_sharetimes' => '分享量',

    'lang_list_title' => '按栏目数据汇总',

    'lang_tips' => '<li>按文章栏目统计当前栏目下的回帖量,分享量,浏览量,文章数等数据</li>',
    'lang_export' => '导出数据',

    'lang_no_data' => '没有找到任何数据'




);

?>
