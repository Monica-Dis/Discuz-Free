<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_forumuserthreads.php.
 *      Author DisM.Taobao.Com.
 *      Time 2021-01-08 15:46:12.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'forum',
        'title' => '论坛数据',
        'order' => 3000,
    ),
    'menu' => array(
        'name' => 'userthreads',
        'title' => '用户发贴量排行',
        'order' => 3080
    ),

    "lang_top_num" => '显示多少条',
    "lang_uid" => '用户ID',
    "lang_forum" => '版块',
    "lang_list_title" => '用户发贴数量排行',
    "lang_thread_time" => '发贴时间',
    "lang_user" => '用户',
    "lang_thread_num" => '发贴数量',
    "lang_not_data" => '未找到任何数据',


);

?>
