<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_service.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'menu' => array(
        'name' => 'service',
        'title' => '售后服务',
        'order' => 9999
    ),
);

?>
