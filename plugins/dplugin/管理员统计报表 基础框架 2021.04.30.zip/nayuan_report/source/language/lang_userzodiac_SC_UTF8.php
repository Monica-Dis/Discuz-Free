<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      lang_userzodiac.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-04-25 19:08:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$lang_nayuan_report = array(
    'group' => array(
        'name' => 'user',
        'title' => '用户数据',
        'order' => 1000,
    ),
    'menu' => array(
        'name' => 'zodiac',
        'title' => '用户生肖统计',
        'order' => 1060
    ),

    'lang_today_title' => '目前分布情况',
    'lang_lately_30_days' => '近30天变化趋势',
    'lang_tips' => '<li>数据有延迟, 今日变更的数据，明日才会更新到</li><li>查看一次才会记录一次当天的数据</li>',
    'lang_more_days_error' => '当前时间段只有少于2天的数据记录，不支持查看趋势图',
    'lang_chart_pie_title' => '用户生肖分布',
    'lang_chart_lie_title' => '用户生肖变化趋势',
    'lang_xaxis_name' => '生肖',
    'lang_yaxis_name' => '人数',
    'lang_unknown' => '未知',

);

?>
