<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      uninstall.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    DROP TABLE IF EXISTS `pre_nayuan_data_one`;
    DROP TABLE IF EXISTS `pre_nayuan_data_more`;
    DROP TABLE IF EXISTS `pre_nayuan_data_cache`;

EOF;

runquery($sql);

C::t('common_syscache')->delete('nayuan_report');

$wechat = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
if(file_exists($wechat)) {
    require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::delAPIHook(array('nayuan_report'));
}

$finish = true;

?>