<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      install.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

    CREATE TABLE IF NOT EXISTS `pre_nayuan_data_one` (
        `time`          int(8) NOT NULL,
        `type`         int(5) NOT NULL,
        `value`        bigint(20),
        PRIMARY KEY  (`time`,`type`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_data_more` (
        `time`          int(8) NOT NULL,
        `type`        int(5),
        `value`         LONGTEXT,
        PRIMARY KEY  (`time`,`type`)
    ) ENGINE=MyISAM;
    
    CREATE TABLE IF NOT EXISTS `pre_nayuan_data_cache`  (
        `cid`       char(32) NOT NULL,
        `type`      int(5) NOT NULL,
        `id`        int(10) NOT NULL,
        `value`     bigint(20) NOT NULL,
        `time`      int(10) NOT NULL,
        PRIMARY KEY (`cid`),
        KEY `idx_time`(`time`),
        KEY `idx_type_id`(`type`, `id`)
    ) ENGINE=MyISAM;


EOF;

runquery($sql);

$wechat = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
if(file_exists($wechat)) {
    require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::updateAPIHook(array(
        array('forumdisplay_variables' => array(
            'plugin' => 'nayuan_report',
            'include' => 'report.class.php',
            'class' => 'mobileapiplugin_nayuan_report_forum',
            'method' => 'forumdisplay_output',
        )),
        array('viewthread_variables' => array(
            'plugin' => 'nayuan_report',
            'include' => 'report.class.php',
            'class' => 'mobileapiplugin_nayuan_report_forum',
            'method' => 'viewthread_output',
        )),
    ));
}


$finish = true;

?>