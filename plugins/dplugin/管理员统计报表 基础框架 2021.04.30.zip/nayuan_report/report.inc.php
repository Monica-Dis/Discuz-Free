<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      nayuan_report.
 *      report.inc.php.
 *      Author DisM.Taobao.Com.
 *      Time 2020-12-02 19:21:31.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/core.func.php';
require_once DISCUZ_ROOT . 'source/plugin/nayuan_report/source/function/nayuanreport.func.php';

loadcache("nayuan_report");
$options = $_G['cache']['nayuan_report'];
if(!$options) {
    $options = array('modules' => array());
}

$m = nayuan_get('m', 1, '');
$s = nayuan_get('s', 1, 'dasbord');
$a = nayuan_get('a', 1, 'show');

$adminurl = 'plugins&operation=config&do=' .$do;
$newext = DISCUZ_ROOT . 'source/plugin/nayuan_report/new.ext';
if($s == 'loadext') {
    $dir = DISCUZ_ROOT . 'source/plugin/nayuan_report/source/language';
    if($directory = @dir($dir)) {
        $_menus = $_crons = $_hooks = $_modules = array();
        while($entry = $directory -> read()) {
            if($entry == '.' || $entry == '..') {
                continue;
            }
            if(!preg_match('/^lang_[a-z]+_'.currentlang().'\.php$/', $entry)) {
                if(preg_match('/^lang_.+/', $entry)) {
                    @unlink($dir . '/' .$entry);
                }
                continue;
            }

            @include $dir.'/'.$entry;
            if(!$lang_nayuan_report) continue;

            if($lang_nayuan_report['cron']) {
                $_crons[] = $lang_nayuan_report['group']['name'] . $lang_nayuan_report['menu']['name'];
            }
            if($lang_nayuan_report['hooks']) {
                foreach ($lang_nayuan_report['hooks'] as $_hook => $_name) {
                    if(!$_hooks[$_hook]) $_hooks[$_hook] = array();
                    $_hooks[$_hook][] = $_name;
                }
            }

            $_services[] = $lang_nayuan_report['menu']['name'];
            $menuorder = $lang_nayuan_report['menu']['order'];
            $group = $lang_nayuan_report['group'];
            if(!$group) {
                $_modules[] = $lang_nayuan_report['menu']['name'];
                $_menus[$menuorder] = array('t' => $lang_nayuan_report['menu']['title'], 's' => $lang_nayuan_report['menu']['name']);
                continue;
            }
            $_modules[] = $group['name'] . $lang_nayuan_report['menu']['name'];

            if(!$_menus[$group['order']]) {
                $_menus[$group['order']] = array('t' => $group['title'], 'm' => $group['name'], 'menus' => array());
            }

            $groupmenus = &$_menus[$group['order']];
            $groupmenus['menus'][$menuorder] = array('t' => $lang_nayuan_report['menu']['title'], 's' => $lang_nayuan_report['menu']['name'], 'm' => $group['name']);

            unset($lang_nayuan_report);
        }
        $directory->close();
        $options['menus'] = $_menus;
        $options['crons'] = $_crons;
        $options['hooks'] = $_hooks;
        $options['modules'] = $_modules;
        savecache('nayuan_report', $options);
    }
    @unlink($newext);
    cpmsg('nayuan_report:ext_loaded', "action=$adminurl", 'succeed');
}
///// 检测新的扩展功能
if(file_exists($newext)) {
    cpmsg('nayuan_report:ext_loading', "action=$adminurl&m=$m&s=loadext", 'loading');
}

if(!$options['menus']) {
    $s = 'service';
    $options['modules'] = 'service';
    $options['menus'] = array(array('t' => lang('plugin/nayuan_report', 'service'), 's' => 'service'));
}else if($s == 'dasbord' && !$options['menus']['1']){
    $s = 'service';
}

if(!in_array($m.$s, $options['modules'])) {
    cpmsg('nayuan_report:download_message', "", 'error');
}

////// 渲染菜单
$menus = array();
ksort($options['menus']);
foreach ($options['menus'] as $menu) {
    if($menu['menus']) {
        ksort($menu['menus']);
        $submenus = array();
        foreach ($menu['menus'] as $submenu) {
            $submenus[] = array($submenu['t'], $adminurl . '&m=' . $menu['m'] . '&s=' . $submenu['s'], $m == $menu['m'] && $s == $submenu['s']);
        }
        $menus[] = array(
            array('menu' => $menu['t'], 'submenu' => $submenus),
            $menu['m'] == $m
        );
    }else{
        $menus[] = array($menu['t'], $adminurl . '&s=' . $menu['s'], $s == $menu['s']);
    }
}
showsubmenu(lang('plugin/nayuan_report', 'title'), $menus);

echo '<style type="text/css">.floattopempty{height: 17px !important;}</style>';
echo '<script type="text/javascript" charset="UTF-8" src="//cdn.bootcss.com/echarts/4.7.0/echarts.min.js"></script>';
echo <<<SCRIPT
<script type="text/Javascript">
        if(typeof window.echarts == 'undefined') {
            window.document.write('<script type="text/Javascript" src="source/plugin/nayuan_report/static/js/echarts.min.js"><\/script>');
        }
</script>
SCRIPT;

require DISCUZ_ROOT . 'source/plugin/nayuan_report/source/language/lang_' . $m . $s . '_' . currentlang() . '.php';
require DISCUZ_ROOT . 'source/plugin/nayuan_report/source/admincp/admincp_' . $m . $s . '.inc.php';

?>