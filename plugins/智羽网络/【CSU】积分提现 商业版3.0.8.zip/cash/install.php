<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_cash_account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `bankname` text NOT NULL,
  `realname` text NOT NULL,
  `payaccount` text NOT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `cdb_cash_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `creditid` tinyint(1) NOT NULL,
  `credits` int(10) NOT NULL,
  `shouxu` int(10) NOT NULL,
  `allcredit` int(10) NOT NULL,
  `money` int(10) NOT NULL,
  `remaincredit` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `dateline` int(10) NOT NULL,
  `dateline1` int(10) DEFAULT NULL,
  `notes` text,
  `opuid` int(10) DEFAULT NULL,
  `bankname` text NOT NULL,
  `realname` text,
  `payaccount` text,
  `mobile` varchar(11) DEFAULT NULL,
  `out_biz_no` varchar(32) DEFAULT NULL,
  `order_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000;
CREATE TABLE IF NOT EXISTS `cdb_cash_user` (
  `uid` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  `defaultid` mediumint(6) DEFAULT NULL,
  `moneynum` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB;
EOF;
runquery($sql);
$finish = true;
?>