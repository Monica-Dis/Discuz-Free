<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
if (file_exists(DISCUZ_ROOT . './source/plugin/cash/alipay.class.php') && $var['alipay']) {
	include_once DISCUZ_ROOT . './source/plugin/cash/alipay.class.php';
}
$var = $_G['cache']['plugin']['cash'];

if (submitcheck('updatesubmit')) {
	include_once libfile('function/mail');
	foreach ($_GET['delete'] as $v) {
		$v = dintval($v);
		C::t('#cash#cash_logs')->delete($v);
		unset($_GET['credit'][$v]);
	}
	$user = array();
	foreach ($_GET['credit'] as $k => $v) {
		$d = C::t('#cash#cash_logs')->fetch(dintval($k));

		if ($d['status'] == dintval($v['status']) && daddslashes($v['notes']) == $d['notes']) {
			continue;
		}
		if ($v['status'] == 1 && $d['status'] != 1 && !$_GET['ignoreGateway']) {
			//�ж��Ƿ���֧�������ļ� �ж��Ƿ�Ϊ֧���� �ж��Ƿ������Զ�����
			if (file_exists(DISCUZ_ROOT . './source/plugin/cash/alipay.class.php') && !$d['order_id'] && $var['alipay'] && $var['alipay_title'] == $d['bankname']) {
				$alipay = new alipay($var['alipay_sandbox'], $var['alipay_appid'], $var['alipay_secret_key'], $var['alipay_public_key']);
				$do = $alipay->transfer(dgmdate(TIMESTAMP, 'YmdHis') . random(6, 1), $d['payaccount'], $d['money'] * 100);
				if ($do) {
					C::t('#cash#cash_logs')->update(dintval($k), array('order_id' => $do['order_id'], 'out_biz_no' => $do['out_biz_no']));
				} else {
					cpmsg_error(lang('plugin/cash', '249'));
				}
			}
		}

		$data = array('status' => ($v['status'] == 3 ? 2 : dintval($v['status'])), 'dateline1' => TIMESTAMP, 'notes' => daddslashes($v['notes']), 'opuid' => $_G['uid']);
		C::t('#cash#cash_logs')->update(dintval($k), $data);
		$u = C::t('#cash#cash_user')->fetch($d['uid']);
		if (!$user[$d['uid']]) {
			$user[$d['uid']] = getuserbyuid($d['uid']);
		}

		if ($v['status'] == 1) {
			$status = lang('plugin/cash', '168');
		} elseif ($v['status'] == 2 || $v['status'] == 3) {
			$status = lang('plugin/cash', '169');
		} elseif ($v['status'] == 0) {
			$status = lang('plugin/cash', '170');
		}

		if ($v['status'] == 1 && $d['status'] != 1) {
			C::t('#cash#cash_user')->update($d['uid'], array('moneynum' => $u['moneynum'] + $d['money']));
		} elseif ($d['status'] == 1 && $v['status'] != 1) {
			C::t('#cash#cash_user')->update($d['uid'], array('moneynum' => $u['moneynum'] - $d['money']));
		}

		if ($v['status'] == 2) {
			updatemembercount($d['uid'], array('extcredits' . $d['creditid'] => +$d['allcredit']), true, '', 0, '', lang('plugin/cash', '155'), lang('plugin/cash', '171'));
		}

		$message = '<table cellpadding="0" align="center" width="800" style="">
	<tbody><tr><th valign="middle" style="height:25px;color:#fff; font-size:14px;line-height:25px; font-weight:bold;text-align:left;padding:15px 35px; border-bottom:1px solid #467ec3;background:#518bcb;border-radius:5px 5px 0 0;">
	Coder Student Union
	</th></tr>
	<tr><td>
	<div style="padding:25px 35px 40px;">
	' . lang('plugin/cash', '172') . $user[$d['uid']]['username'] . lang('plugin/cash', '173') . '<br>
	<br>
	' . lang('plugin/cash', '174') . $d['money'] . $_G['cache']['plugin']['cash']['unit'] . '<br>
	<br />
	' . lang('plugin/cash', '175') . $status . '<br>
	<br />
	' . dgmdate(TIMESTAMP) . '<br />
	' . $_G['setting']['bbname'] . '
	</div>
	</td></tr>
	</tbody></table>';
		sendmail($user[$d['uid']]['email'], lang('plugin/cash', '176'), $message, '', 1);
		notification_add($user[$d['uid']]['uid'], 'system', 'system_notice', array('subject' => lang('plugin/cash', '176'), 'message' => lang('plugin/cash', '174') . $d['money'] . $_G['cache']['plugin']['cash']['unit'] . '<br>' . lang('plugin/cash', '175') . $status . '<br>', 'from_id' => 0, 'from_idtype' => 'sendnotice'), 1);
	}

	require_once libfile('function/cache');

	$data = C::t('#cash#cash_logs')->fetch_success(1, $_G['cache']['plugin']['cash']['allnum']);
	if ($data) {
		$datacode = '';
		foreach ($data as $row) {
			$username = getuserbyuid($row['uid']);
			$datacode .= '<li style="width:49%;float:left;">' . lang('plugin/cash', '142') . '&nbsp;<span class="xi1">' . $username['username'] . '</span>&nbsp;' . lang('plugin/cash', '1') . '&nbsp;' . dgmdate($row['dateline1']) . '&nbsp;' . lang('plugin/cash', '122') . '&nbsp;<span class="xi1">' . $row['money'] . $_G['cache']['plugin']['cash']['unit'] . '</span></li>';
		}
		$html = '<div id="wp" class="wp"><div class="bm">
<div class="bm_h cl">
<h2>' . lang('plugin/cash', '123') . '</h2>
</div>
<div class="bm_c cl">
<ul>
' . $datacode . '
</ul>
</div>
</div></div>';
	}

	if ($var['mobile_radio'] && $var['mobile_data']) {
		$data = C::t('#cash#cash_logs')->fetch_success(1, $_G['cache']['plugin']['cash']['mobile_data']);
		if ($data) {
			$datacode = '';
			foreach ($data as $row) {
				$username = getuserbyuid($row['uid']);
				$datacode .= '<li>' . lang('plugin/cash', '142') . '&nbsp;<span style="color:red">' . $username['username'] . '</span>&nbsp;' . lang('plugin/cash', '1') . '&nbsp;' . dgmdate($row['dateline1']) . '&nbsp;' . lang('plugin/cash', '122') . '&nbsp;<span style="color:red">' . $row['money'] . $_G['cache']['plugin']['cash']['unit'] . '</span></li>';
			}
			$htmlm = '<div class="wp wm" id="wp">
<div class="bm bmw fl">
<div class="subforumshow bm_h cl" href="#sub_forum_1">
<h2><a href="plugin.php?id=cash:cash">' . lang('plugin/cash', '141') . '</a></h2>
</div>
' . $datacode . '
</div>
</div>';
		}
	}
	writetocache('plugin_cash', getcachevars(array('html' => array('web' => $html, 'mobile' => $htmlm))));

	cpmsg(lang('plugin/cash', '195'), dreferer(), 'succeed');
}

$scripturl = 'plugins&operation=config&do=' . $do . '&identifier=' . $plugin['identifier'] . '&pmod=' . daddslashes($_GET['pmod']) . '&mod=orders';
$page = $_GET['page'] > 1 ? dintval($_GET['page']) : 1;
$num = 15;
$count = C::t('#cash#cash_logs')->count();
$multi = multi($count, $num, $page, ADMINSCRIPT . "?action=" . $scripturl);
$data = C::t('#cash#cash_logs')->fetch_by_page($page, $num);
showtableheader('');
showformheader($menuurl . $mod . ($_GET['orderid'] ? 'orderid=' . $_GET['orderid'] : ''));
showtablerow('class="header"', array(), array(lang('plugin/cash', '177'), lang('plugin/cash', '178'), lang('plugin/cash', '179') . '(' . $_G['cache']['plugin']['cash']['unit'] . ')', lang('plugin/cash', '180'), lang('plugin/cash', '181'), lang('plugin/cash', '182'), lang('plugin/cash', '183'), lang('plugin/cash', '184'), lang('plugin/cash', '185'), lang('plugin/cash', '186'), lang('plugin/cash', '187'), lang('plugin/cash', '188'), lang('plugin/cash', '189')));
foreach ($data as $d) {
	$user = getuserbyuid($d['uid']);
	showtablerow('class="noborder" onmouseover="setfaq(this, \'faqff20\')"', array(), array(
		'<input class="checkbox" type="checkbox" name="delete[]" value="' . $d[id] . '">',
		$d['id'],
		$d['money'],
		$d['credits'] . '+' . $d['shouxu'] . $_G['setting']['extcredits'][$d['creditid']]['title'],
		$d['remaincredit'],
		$user['username'],
		$d['realname'],
		$d['mobile'],
		$d['payaccount'] . '(' . $d['bankname'] . ')' . ($d['order_id'] ? '<br>' . $d['order_id'] : ''),
		dgmdate($d['dateline']),
		($d['dateline1'] ? dgmdate($d['dateline1']) : '<span style="color:red">' . lang('plugin/cash', '190') . '</span>'),
		statusselect($d['status'], $d['id']),
		'<input type="text" name="credit[' . $d['id'] . '][notes]" value="' . $d['notes'] . '" />',
	));
}
showsubmit('updatesubmit', 'submit', 'del', $var['alipay'] && file_exists(DISCUZ_ROOT . './source/plugin/cash/alipay.class.php') ? '<label><input type="checkbox" name="ignoreGateway" value="true"> ' . lang('plugin/cash', '250') . '</label>' : '');
showformfooter();
showtablefooter();
echo $multi;

function statusselect($status, $orderid) {
	$echo = '<select name="credit[' . $orderid . '][status]">';
	$echo .= '<option value="0"' . ($status == 0 ? ' selected="selected"' : '') . '>' . lang('plugin/cash', '191') . '</option>';
	$echo .= '<option value="1"' . ($status == 1 ? ' selected="selected"' : '') . '>' . lang('plugin/cash', '192') . '</option>';
	$echo .= '<option value="2"' . ($status == 2 ? ' selected="selected"' : '') . '>' . lang('plugin/cash', '193') . '</option>';
	$echo .= '<option value="3"' . ($status == 3 ? ' selected="selected"' : '') . '>' . lang('plugin/cash', '194') . '</option>';
	$echo .= '</select>';
	return $echo;
}
//From: Dism_taobao-com
?>