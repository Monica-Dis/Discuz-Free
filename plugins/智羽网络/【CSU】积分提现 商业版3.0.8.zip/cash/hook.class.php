<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
   exit('access denid');
}
class plugin_cash {
	function showcredit(){
		global $_G;
		if(!$_G['cache']['plugin']['cash']['radio']||!$_G['uid']||!in_array($_G['groupid'],dunserialize($_G['cache']['plugin']['cash']['groups']))) return '';
		return str_replace(array('{credits}','{extcredits1}','{extcredits1_title}','{extcredits2}','{extcredits2_title}','{extcredits3}','{extcredits3_title}','{extcredits4}','{extcredits4_title}','{extcredits5}','{extcredits5_title}','{extcredits6}','{extcredits6_title}','{extcredits7}','{extcredits7_title}'),array($_G['member']['credits'],getuserprofile('extcredits1'),$_G['setting']['extcredits'][1]['title'],getuserprofile('extcredits2'),$_G['setting']['extcredits'][2]['title'],getuserprofile('extcredits3'),$_G['setting']['extcredits'][3]['title'],getuserprofile('extcredits4'),$_G['setting']['extcredits'][4]['title'],getuserprofile('extcredits5'),$_G['setting']['extcredits'][5]['title'],getuserprofile('extcredits6'),$_G['setting']['extcredits'][6]['title'],getuserprofile('extcredits7'),$_G['setting']['extcredits'][7]['title']),$_G['cache']['plugin']['cash']['html']);
	}
	function global_header(){
		global $_G;
		if(!$_G['cache']['plugin']['cash']['radio']||!$_G['cache']['plugin']['cash']['allnum']) return '';
		if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_plugin_cash.php')) @include DISCUZ_ROOT.'./data/sysdata/cache_plugin_cash.php';

		return $html['web'];
	}

	function global_usernav_extra4() {
		global $_G;
		if ('global_usernav_extra4'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
	function global_usernav_extra3() {
		global $_G;
		if ('global_usernav_extra3'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
	function global_usernav_extra2() {
		global $_G;
		if ('global_usernav_extra2'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
	function global_usernav_extra1() {
		global $_G;
		if ('global_usernav_extra1'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
	function global_cpnav_extra1() {
		global $_G;
		if ('global_cpnav_extra1'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
	function global_cpnav_extra2() {
		global $_G;
		if ('global_cpnav_extra2'==$_G['cache']['plugin']['cash']['hook']) return $this->showcredit();
		else return '';
	}
}
//From: Dism��taobao��com
?>