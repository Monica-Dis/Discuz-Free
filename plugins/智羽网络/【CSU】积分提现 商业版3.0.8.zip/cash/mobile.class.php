<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_cash {

	public function global_header_mobile() {
		global $_G;
		if ($_G['cache']['plugin']['cash']['mobile_hook'] == 'header') {
			return $_G['cache']['plugin']['cash']['mobile_html'];
		}

	}

	public function global_footer_mobile() {
		global $_G;
		if ($_G['cache']['plugin']['cash']['mobile_hook'] == 'footer') {
			return $_G['cache']['plugin']['cash']['mobile_html'];
		}

	}
}
class mobileplugin_cash_forum extends mobileplugin_cash {
	function index_top_mobile() {
		global $_G;
		if ($_G['cache']['plugin']['cash']['mobile_hook'] == 'header') {
			return $_G['cache']['plugin']['cash']['mobile_html'];
		}

	}
}
//From: Dism_taobao-com
?>