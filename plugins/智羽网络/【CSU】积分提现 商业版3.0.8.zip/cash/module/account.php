<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
   exit('access denid');
}
if($var['paypasswd']&&$_G['cache']['plugin']['password']&&!C::t('#password#password')->checkexists($_G['uid'])) showmessage(lang('plugin/cash', '143'),'home.php?mod=spacecp&ac=plugin&id=password:password');
$user = C::t('#cash#cash_user')->fetch($_G['uid']);

$types = array();
foreach (explode("\r\n",$var['types']) as $v) $types[] = $v;
if(submitcheck('deletesubmit')){
	$delid = dintval($_GET['deletesubmit']);
	$account = C::t('#cash#cash_account')->fetch($delid);
	if($account['uid']!=$_G['uid']) showmessage(lang('plugin/cash', '145'));
	C::t('#cash#cash_account')->delete($delid);
	showmessage(lang('plugin/cash', '144'),dreferer(),array(), array('alert' => 'right', 'locationtime'=> true, 'msgtype' => 2, 'showdialog'=> true, 'showmsg' => true));
}
$accounts = C::t('#cash#cash_account')->fetch_by_uid($_G['uid']);
$id = '';
if(submitcheck('updatesubmit',0,1)){
	if($var['paypasswd']&&$_G['cache']['plugin']['password']&&C::t('#password#password')->check($_G['uid'],daddslashes($_GET['password']),'cash')!=1) showmessage(lang('plugin/cash', '146'));
	if($_GET['newrealname']&&$_GET['newpayaccount']&&$_GET['newmobile']&&$_GET['newbankname']){
		if(!in_array($_GET['newbankname'],$types)) showmessage(lang('plugin/cash', '147'));
		$data = array('realname'=>daddslashes($_GET['newrealname']),'payaccount'=>daddslashes($_GET['newpayaccount']),'mobile'=>daddslashes($_GET['newmobile']),'bankname'=>daddslashes($_GET['newbankname']),'uid'=>$_G['uid']);
		$id = C::t('#cash#cash_account')->insert($data,1);
	}
	if($_GET['dafaultid']=='new'&&$id) {
		if(!$user) C::t('#cash#cash_user')->insert(array('uid'=>$_G['uid'],'dateline'=>TIMESTAMP,'defaultid'=>$id));
		else C::t('#cash#cash_user')->update($_G['uid'],array('dateline'=>TIMESTAMP,'defaultid'=>$id));
	}else{
		if(!$user) C::t('#cash#cash_user')->insert(array('uid'=>$_G['uid'],'dateline'=>TIMESTAMP,'defaultid'=>dintval($_GET['dafaultid'])));
		else C::t('#cash#cash_user')->update($_G['uid'],array('dateline'=>TIMESTAMP,'defaultid'=>dintval($_GET['dafaultid'])));
	}
	showmessage(lang('plugin/cash', '148'),dreferer(),array(), array('alert' => 'right', 'locationtime'=> true, 'msgtype' => 2, 'showdialog'=> true, 'showmsg' => true));

}
$accounts = C::t('#cash#cash_account')->fetch_by_uid($_G['uid']);
$seccodecheck = true;
?>