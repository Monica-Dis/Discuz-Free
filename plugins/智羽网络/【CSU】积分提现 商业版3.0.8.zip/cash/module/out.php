<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('access denid');
}
$user = C::t('#cash#cash_user')->fetch($_G['uid']);
if (!$user['passwd'] && $_G['cache']['plugin']['password'] && !C::t('#password#password')->checkexists($_G['uid'])) {
	showmessage(lang('plugin/cash', '143'), 'home.php?mod=spacecp&ac=plugin&id=password:password');
}

if (!in_array($_G['groupid'], dunserialize($var['groups1']))) {
	showmessage(lang('plugin/cash', '130'));
}

$types = array();
foreach (explode("\r\n", $var['types']) as $v) {
	$types[] = $v;
}

if (submitcheck('updatesubmit', 0, 1)) {
	if ($var['paypasswd'] && $_G['cache']['plugin']['password'] && C::t('#password#password')->check($_G['uid'], daddslashes($_GET['password']), 'cash') != 1) {
		showmessage(lang('plugin/cash', '146'));
	}

	$money = dintval($_GET['money']);
	if ($money < $var['timin'] && $var['timin']) {
		showmessage(lang('plugin/cash', '164') . $var['timin'] . $var['unit']);
	}

	if ($money > $var['timax'] && $var['timax']) {
		showmessage(lang('plugin/cash', '165') . $var['timax'] . $var['unit']);
	}

	if ($money <= 0) {
		showmessage(lang('plugin/cash', '152'));
	}

	$accountid = dintval($_GET['accountid']);
	$account = C::t('#cash#cash_account')->fetch($accountid);
	if ($account['uid'] != $_G['uid']) {
		showmessage(lang('plugin/cash', '153'));
	}

	$credits = $money * $var['bili'];
	$shouxu = 0;
	if ($var['shou'] == 0) {
		if ($var['shoumin']) {
			$shouxu = $var['shoumin'];
		}

	} else {
		$shouxu = ceil($credits * $var['shou'] / 100);
		if ($shouxu > $var['shoumax'] && $var['shoumax']) {
			$shouxu = $var['shoumax'];
		}

		if ($shouxu < $var['shoumin']) {
			$shouxu = $var['shoumin'];
		}

	}
	$all = $credits + $shouxu;
	DB::query('START TRANSACTION');

	$remain = getuserprofile('extcredits' . $var['credit']);
	if ($remain < ($all + $var['yumin'])) {
		Db::query('rollback');
		showmessage(lang('plugin/cash', '154'));
	}
	//开始事务

	$id = C::t('#cash#cash_logs')->insert(array('uid' => $_G['uid'], 'creditid' => $var['credit'], 'credits' => $credits, 'shouxu' => $shouxu, 'allcredit' => $all, 'money' => $money, 'remaincredit' => ($remain - $all), 'dateline' => TIMESTAMP, 'bankname' => $account['bankname'], 'realname' => $account['realname'], 'payaccount' => $account['payaccount'], 'mobile' => $account['mobile']), 1);
	if ($var['lock']) {
		DB::query('UNLOCK TABLES');
	}

	updatemembercount($_G['uid'], array('extcredits' . $var['credit'] => -$all), true, '', 0, '', lang('plugin/cash', '155'), lang('plugin/cash', '156'));
	Db::query('commit');
	//判断是否为支付宝订单
	if (file_exists(DISCUZ_ROOT . './source/plugin/cash/alipay.class.php') && $var['alipay'] && $var['alipay_noexamine'] && $var['alipay_title'] == $account['bankname']) {
		include_once DISCUZ_ROOT . './source/plugin/cash/alipay.class.php';
		$alipay = new alipay($var['alipay_sandbox'], $var['alipay_appid'], $var['alipay_secret_key'], $var['alipay_public_key']);
		$do = $alipay->transfer(dgmdate(TIMESTAMP, 'YmdHis') . random(6, 1), $account['payaccount'], $money * 100);
		if ($do) {
			C::t('#cash#cash_logs')->update($id, array('order_id' => $do['order_id'], 'out_biz_no' => $do['out_biz_no'], 'status' => 1, 'dateline1' => TIMESTAMP));
			showmessage(lang('plugin/cash', '251'), dreferer(), array(), array('alert' => 'right', 'locationtime' => true, 'msgtype' => 2, 'showdialog' => true, 'showmsg' => true));
		}
	}
	//支付宝支付失败或者非支付宝
	include_once libfile('function/mail');
	$message = '<table cellpadding="0" align="center" width="800" style="">
<tbody><tr><th valign="middle" style="height:25px;color:#fff; font-size:14px;line-height:25px; font-weight:bold;text-align:left;padding:15px 35px; border-bottom:1px solid #467ec3;background:#518bcb;border-radius:5px 5px 0 0;">
Coder Student Union
</th></tr>
<tr><td>
<div style="padding:25px 35px 40px;">
' . lang('plugin/cash', '157') . '<br>
<br>
' . lang('plugin/cash', '158') . $_G['username'] . '<br>
<a href="' . $_G['siteurl'] . ADMINSCRIPT . '?frames=yes&action=plugins&operation=confi&identifier=cash&pmod=admin&mod=orders&orderid=' . $id . '" target="_blank">' . lang('plugin/cash', '162') . '</a><br>
<br />
</div>
</td></tr>
</tbody></table>';
	foreach (explode("\r\n", $var['emails']) as $emails) {
		$send = sendmail($emails, lang('plugin/cash', '160'), $message, '', 1);
	}

	foreach (explode(",", $var['uids']) as $uid) {
		notification_add($uid, 'system', 'system_notice', array('subject' => lang('plugin/cash', '160'), 'message' => lang('plugin/cash', '161') . $_G['username'] . '<br>
<a href="' . $_G['siteurl'] . ADMINSCRIPT . '?frames=yes&action=plugins&operation=confi&identifier=cash&pmod=admin&mod=orders&orderid=' . $id . '" target="_blank">' . lang('plugin/cash', '162') . '</a>', 'from_id' => 0, 'from_idtype' => 'sendnotice'), 1);

	}
	showmessage(lang('plugin/cash', '163'), dreferer(), array(), array('alert' => 'right', 'locationtime' => true, 'msgtype' => 2, 'showdialog' => true, 'showmsg' => true));

}
$html = str_replace(array('{credits}', '{extcredits1}', '{extcredits1_title}', '{extcredits2}', '{extcredits2_title}', '{extcredits3}', '{extcredits3_title}', '{extcredits4}', '{extcredits4_title}', '{extcredits5}', '{extcredits5_title}', '{extcredits6}', '{extcredits6_title}', '{extcredits7}', '{extcredits7_title}'), array($_G['member']['credits'], getuserprofile('extcredits1'), $_G['setting']['extcredits'][1]['title'], getuserprofile('extcredits2'), $_G['setting']['extcredits'][2]['title'], getuserprofile('extcredits3'), $_G['setting']['extcredits'][3]['title'], getuserprofile('extcredits4'), $_G['setting']['extcredits'][4]['title'], getuserprofile('extcredits5'), $_G['setting']['extcredits'][5]['title'], getuserprofile('extcredits6'), $_G['setting']['extcredits'][6]['title'], getuserprofile('extcredits7'), $_G['setting']['extcredits'][7]['title']), (defined(IN_MOBILE) ? $_G['cache']['plugin']['cash']['mobile_out'] : $_G['cache']['plugin']['cash']['showhtml']));
$accounts = C::t('#cash#cash_account')->fetch_by_uid($_G['uid']);
$seccodecheck = true;
?>