<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
.mymenu { height:35px; }
.mymenu .floattop { display: inline; }
.mymenu .floattopempty { display: inline; }
</style>
EOF;
$pluginroot = DISCUZ_ROOT . './source/plugin/cash/';
$export = C::t('common_syscache')->fetch_all(['pluginlanguage_script', 'pluginlanguage_template', 'pluginlanguage_install', 'pluginlanguage_system']);
$mod = str_replace(array('.', '..'), '', daddslashes($_GET['mod']));
if (!$mod) {
	$mod = 'setting';
}

echo '<div class="mymenu">';
$menuurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=admin&mod=';
showsubmenu($plugin['name'], array(
	array(array('menu' => lang('plugin/cash', '135'), 'submenu' => array(
		array(lang('plugin/cash', '136'), $menuurl . 'setting', $mod == 'setting'),
		array(lang('plugin/cash', '137'), $menuurl . 'out', $mod == 'out'),
		array(lang('plugin/cash', '138'), $menuurl . 'mobile', $mod == 'mobile'),
	)), in_array($mod, array('setting', 'out', 'market', 'index', 'mobile'))),
	array(lang('plugin/cash', '246'), $menuurl . 'alipay', $mod == 'alipay'),
	array(lang('plugin/cash', '139'), $menuurl . 'orders', $mod == 'orders'),
));
echo '</div>';

$var = array();
foreach (C::t('common_pluginvar')->fetch_all_by_pluginid($pluginid) as $vars) {
	if (!strexists($vars['type'], $plugin['identifier'] . '_')) {
		C::t('common_pluginvar')->update_by_variable($pluginid, $vars['variable'], array('type' => $plugin['identifier'] . '_' . $vars['type']));
		$vars['type'] = $plugin['identifier'] . '_' . $vars['type'];
	}
	$var[$vars['variable']] = $vars;
}
function checksubmit($array) {
	if (submitcheck('submit')) {
		global $var, $pluginid, $plugin;
		foreach ($array as $arr) {
			$updata = $var[$arr];
			$variable = $updata['variable'];
			$value = daddslashes($_GET[$arr]);
			if (is_array($value)) {
				$value = serialize($value);
			}

			if ($updata['type'] == $plugin['identifier'] . '_' . 'password' && strstr($value, '*')) {
				continue;
			}

			DB::query("UPDATE " . DB::table('common_pluginvar') . " SET value='$value' WHERE pluginid='$pluginid' AND variable='$variable'");
		}
		updatecache(array('plugin', 'setting', 'styles'));
		cleartemplatecache();
		return true;
	} else {
		return false;
	}

}

function showall($array, $showsubmit = 1) {
	foreach ($array as $data) {
		showset($data);
	}
	if ($showsubmit) {
		showsubmit('submit');
	}

}

function showset($varname, $disabled = '', $hidden = 0, $setid = '') {
	global $var, $_G, $plugin, $lang;
	$var[$varname]['type'] = substr($var[$varname]['type'], strlen($plugin['identifier']) + 1);
	$vars = $var[$varname];
	if ($vars['type'] == 'password') {
		$vars['type'] = 'text';
		$vars['password'] = 1;
		$vars['value'] = $vars['value'] ? $vars['value']{0} . '********' . substr($vars['value'], -4) : '';
	} elseif ($vars['type'] == 'number') {
		$vars['type'] = 'text';
	} elseif ($vars['type'] == 'select') {
		$vars['type'] = "<select name=\"$vars[variable]\">\n";
		foreach (explode("\n", $vars['extra']) as $key => $option) {
			$option = trim($option);
			if (strpos($option, '=') === FALSE) {
				$key = $option;
			} else {
				$item = explode('=', $option);
				$key = trim($item[0]);
				$option = trim($item[1]);
			}
			$vars['type'] .= "<option value=\"" . dhtmlspecialchars($key) . "\" " . ($vars['value'] == $key ? 'selected' : '') . ">$option</option>\n";
		}
		$vars['type'] .= "</select>\n";
		$vars['variable'] = $vars['value'] = '';
	} elseif ($vars['type'] == 'selects') {
		$vars['value'] = dunserialize($vars['value']);
		$vars['value'] = is_array($vars['value']) ? $vars['value'] : array($vars['value']);
		$vars['type'] = "<select name=\"$var[variable][]\" multiple=\"multiple\" size=\"10\">\n";
		foreach (explode("\n", $vars['extra']) as $key => $option) {
			$option = trim($option);
			if (strpos($option, '=') === FALSE) {
				$key = $option;
			} else {
				$item = explode('=', $option);
				$key = trim($item[0]);
				$option = trim($item[1]);
			}
			$vars['type'] .= "<option value=\"" . dhtmlspecialchars($key) . "\" " . (in_array($key, $vars['value']) ? 'selected' : '') . ">$option</option>\n";
		}
		$vars['type'] .= "</select>\n";
		$vars['variable'] = $vars['value'] = '';
	} elseif ($vars['type'] == 'date') {
		$vars['type'] = 'calendar';
		$extra['date'] = '<script type="text/javascript" src="static/js/calendar.js"></script>';
	} elseif ($vars['type'] == 'datetime') {
		$vars['type'] = 'calendar';
		$vars['extra'] = 1;
		$extra['date'] = '<script type="text/javascript" src="static/js/calendar.js"></script>';
	} elseif ($vars['type'] == 'forum') {
		require_once libfile('function/forumlist');
		$vars['type'] = '<select name="' . $vars['variable'] . '"><option value="">' . cplang('plugins_empty') . '</option>' . forumselect(FALSE, 0, $vars['value'], TRUE) . '</select>';
		$vars['variable'] = $vars['value'] = '';
	} elseif ($vars['type'] == 'forums') {
		$vars['description'] = ($vars['description'] ? (isset($lang[$vars['description']]) ? $lang[$vars['description']] : $vars['description']) . "\n" : '') . $lang['plugins_edit_vars_multiselect_comment'] . "\n" . $vars['comment'];
		$vars['value'] = dunserialize($vars['value']);
		$vars['value'] = is_array($vars['value']) ? $vars['value'] : array();
		require_once libfile('function/forumlist');
		$vars['type'] = '<select name="' . $vars['variable'] . '[]" size="10" multiple="multiple"><option value="">' . cplang('plugins_empty') . '</option>' . forumselect(FALSE, 0, 0, TRUE) . '</select>';
		foreach ($vars['value'] as $v) {
			$vars['type'] = str_replace('<option value="' . $v . '">', '<option value="' . $v . '" selected>', $vars['type']);
		}
		$vars['variable'] = $vars['value'] = '';
	} elseif (substr($vars['type'], 0, 5) == 'group') {
		if ($vars['type'] == 'groups') {
			$vars['description'] = ($vars['description'] ? (isset($lang[$vars['description']]) ? $lang[$vars['description']] : $vars['description']) . "\n" : '') . $lang['plugins_edit_vars_multiselect_comment'] . "\n" . $vars['comment'];
			$vars['value'] = dunserialize($vars['value']);
			$vars['type'] = '<select name="' . $vars['variable'] . '[]" size="10" multiple="multiple"><option value=""' . (@in_array('', $vars['value']) ? ' selected' : '') . '>' . cplang('plugins_empty') . '</option>';
		} else {
			$vars['type'] = '<select name="' . $vars['variable'] . '"><option value="">' . cplang('plugins_empty') . '</option>';
		}
		$vars['value'] = is_array($vars['value']) ? $vars['value'] : array($vars['value']);
		$query = C::t('common_usergroup')->range_orderby_credit();
		$groupselect = array();
		foreach ($query as $group) {
			$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
			$groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '"' . (@in_array($group['groupid'], $vars['value']) ? ' selected' : '') . '>' . $group['grouptitle'] . '</option>';
		}
		$vars['type'] .= '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' .
			($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') .
			($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') .
			'<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup></select>';
		$vars['variable'] = $vars['value'] = '';
	} elseif ($vars['type'] == 'extcredit') {
		$vars['type'] = '<select name="' . $vars['variable'] . '"><option value="">' . cplang('plugins_empty') . '</option>';
		foreach ($_G['setting']['extcredits'] as $id => $credit) {
			$vars['type'] .= '<option value="' . $id . '"' . ($vars['value'] == $id ? ' selected' : '') . '>' . $credit['title'] . '</option>';
		}
		$vars['type'] .= '</select>';
		$vars['variable'] = $vars['value'] = '';
	}
	extract($vars);
	if (is_array($value)) {
		$value = dunserialize($value);
	}

	showsetting($title, $variable, $value, $type, $disabled, $hidden, $description, '', $setid, true);
}
if (file_exists($pluginroot . '/admin/' . $mod . '.php')) {
	include_once $pluginroot . '/admin/' . $mod . '.php';
} else {
	cpmsg_error(lang('plugin/cash', '131'));
}
//From: Dism��taobao��com
?>