<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2018 by jnpar
|   http://dism.taobao.com
|   Support: QQ94526868
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Ȩ���ɳ��򣬴˳���ֻ��Ȩ��Ӧ������������վ������˽���޸��ļ���ʧȥ��ҵ�ۺ����
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_pay";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');

$sql1 = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jn_payapps` (
  `logid` int(5) NOT NULL AUTO_INCREMENT,
  `buytype` int(5) NOT NULL,
  `appid` varchar(30) NOT NULL,
  `version` varchar(10) NOT NULL,
  `installtime` int(10) NOT NULL,
  `paras` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  PRIMARY KEY (`logid`),
  UNIQUE KEY `buytype` (`buytype`,`appid`),
  KEY `version` (`version`)
) ENGINE=MyISAM;

EOF;

$sql2 = <<<EOF

alter table `pre_jn_orderlog` add `touid` int(10) NOT NULL,
alter table `pre_jn_orderlog` add `drawed` tinyint(1) NOT NULL;
alter table `pre_jn_orderlog` add   `relateid1_type` varchar(20) NOT NULL;
alter table `pre_jn_orderlog` add   `relateid2_type` varchar(20) NOT NULL;
alter table `pre_jn_orderlog` add   `relateid1` int(11) NOT NULL;
alter table `pre_jn_orderlog` add   `relateid2` int(11) NOT NULL;
alter table `pre_jn_orderlog` add   `time1` int(10) NOT NULL;
alter table `pre_jn_orderlog` add  `time2` int(10) NOT NULL;

EOF;

$sql3 = <<<EOF


ALTER TABLE `pre_jn_orderlog` ADD KEY `touid` ( `touid` );
ALTER TABLE `pre_jn_orderlog` ADD KEY `drawed` ( `drawed` );
ALTER TABLE `pre_jn_orderlog` ADD KEY `relateid1_type` ( `relateid1_type` );
ALTER TABLE `pre_jn_orderlog` ADD KEY `relateid2_type` ( `relateid2_type` );
ALTER TABLE `pre_jn_orderlog` ADD KEY `relateid1` ( `relateid1` );
ALTER TABLE `pre_jn_orderlog` ADD KEY `relateid2` ( `relateid2` );

EOF;

global $_G,$pluginid;
$pversion = preg_replace('/([\x80-\xff]*)/i','',$_G['setting']['plugins']['version'][$plugin['identifier']]);
$vernum=floatval($pversion);
if($vernum<1.31){//1.31�汾����
	runquery($sql1);
}elseif($vernum<4.0){
	runquery($sql2);
	runquery($sql3);
}
@unlink('source/plugin/'.$identify.'/upgrade.php');


$finish = true;
?>