<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
global $_G;

$siteurl = $_G['siteurl'];
$sitename = $_G['setting']['sitename'];
$username=$_G['username'];
$uid=$_G['uid']?$_G['uid']:0;
//debug($_G['clientip']);
if(empty($_G['cache']['plugin'][$identifier])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin'][$identifier];

$appid=$_GET['appid'];
if($appid){
	$para_arr=C::t('#jnpar_pay#jn_orderlog')->getparas();
	$tid=$para_arr[0];
	$has_record=$para_arr[1];
	$authorid=$para_arr[2];
	$count_need=$para_arr[3];
	$count_toauthor=$para_arr[4];
	$pid=$para_arr[5];
	$payways=$para_arr[6];
	$allow_guestpay=$para_arr[7];
	$appcheck=C::t("#$appid#$appid")->appcheck($para_arr);
}

$pay_pre=C::t('#jnpar_pay#jn_orderlog')->get_pre_creditset();
$payc=$pay_pre['payc'];
$paycr=$pay_pre['paycr'];
$paycw=$pay_pre['paycw'];

$pay_banks=C::t('#jnpar_pay#jn_orderlog')->get_pay_methods($payways);
$pay_bank1=$pay_banks['pay_bank1'];
$extc_buy=$pvar['extc_buy'];
$exc_unit=$_G['setting']['extcredits'][$extc_buy]['unit'].$count.$_G['setting']['extcredits'][$extc_buy]['title'];

$pay_credit=$pvar['pay_credit'];
$pay_unit=$_G['setting']['extcredits'][$pay_credit]['unit'].$count.$_G['setting']['extcredits'][$pay_credit]['title'];
$credit_r=$pvar['credit_r'];
$pay_extname='extcredits'.$pay_credit;
$ubalance=intval(getuserprofile($pay_extname));

$groupbuyset=C::t('#jnpar_pay#jn_orderlog')->conftoarray_vip();
$money_on=$pvar['money_on'];

$charset=strtolower(CHARSET)=='gbk'?'GBK':'UTF-8';
$in_weixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false?1:0;
$isMobile = checkmobile();

$handletype=array('1'=>lang('plugin/jnpar_pay', 't16'),'2'=>lang('plugin/jnpar_pay', 't17'),'3'=>lang('plugin/jnpar_pay', 't18'));//1会员办理 2购买邀请码 3积分充值
$handletitle=array('1'=>lang('plugin/jnpar_pay', 't19'),'2'=>lang('plugin/jnpar_pay', 't20'),'3'=>lang('plugin/jnpar_pay', 't21'));//1选择办理类型 2邀请码价格 3金额选择
$handletype[0]=$handletype[3];//默认值
$handletitle[0]=$handletitle[3];

$template_style=($pvar['template_style'] and !$isMobile)?$pvar['template_style']:'default';
$inv_mailsend=$pvar['inv_mailsend'];

$unitprice=$pvar['unitprice'];
$inviteprice=$pvar['inviteprice'];
$invitec=$inviteprice*$unitprice;
$price=C::t('#jnpar_pay#jn_orderlog')->get_price(intval($_GET['buykey']),intval($_GET['buyid']),$count_need);
$needcredits=ceil($price*$credit_r);//积分向上取整
if($ubalance<$needcredits)$cnotenough=1;
//debug($ubalance);
$get=dhtmlspecialchars($_GET);
$paytype=$get["paytype"];
$buykey=intval($get['buykey']);
$buyid=intval($get["buyid"]);
if($buykey==2)$allow_guestpay=1;

if(!submitcheck('button')){	
	
	if(!$_GET['appid'] and ($_GET["buykey"]=="" and $_GET["paytype"]=="")){
		include template("diy:index_".$template_style,0,'source/plugin/jnpar_pay/template');
	}elseif($_GET["paytype"]==""){
		//if(!$uid and $_GET["buykey"]!=2)showmessage('to_login', NULL, array(), array('login' => 1));
		$selwidth=sizeof($pay_bank1)*140;
		include(template("jnpar_pay:selectpay"));
	}
}else{
	if(!$uid and !$allow_guestpay)showmessage('&#27492;&#25805;&#20316;&#38656;&#35201;&#30331;&#24405;');//此操作需要登录
	if($paytype==3 and $cnotenough)showmessage('&#25903;&#20184;&#31215;&#20998;&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#20182;&#25903;&#20184;&#26041;&#24335;');
	if(!$buykey and !$get['appid'])showmessage(lang('plugin/jnpar_pay', 't7'));
	if(!$paytype)showmessage('&#35831;&#36873;&#25321;&#25903;&#20184;&#26041;&#24335;');
	if(!in_array($paytype,$pay_bank1))showmessage('&#25903;&#20184;&#26041;&#24335;&#38169;&#35823;&#65292;&#35831;&#37325;&#26032;&#36873;&#25321;');

	if($appid){
		$appreturn=C::t("#$appid#$appid")->genorder($para_arr,$paytype);
		$commodityName=$appreturn['commodityName'];
		$desc =$appreturn['desc'];
		$orderNum=$appreturn['orderNum'];
		$return_url=$appreturn['return_url'];
	}
		
	if($paytype==3){
		$out_trade_no = $orderNum;
		$trade_no = 'creditpay_'.$orderNum;
		$trade_status = 'success';
		$realprice= $needcredits.$pay_unit;
		updatemembercount($uid,array($pay_extname => -$needcredits),true, '', '',  $commodityName, lang('plugin/jnpar_pay', 't22'),$desc);
		C::t('#jnpar_pay#jn_orderlog')->updateorder($out_trade_no,'',$trade_no,$realprice);
		showmessage('&#36141;&#20080;&#25104;&#21151;',$return_url);
	}else{
		showmessage('&#27492;&#25903;&#20184;&#26041;&#24335;&#26410;&#25903;&#25345;&#65292;&#22914;&#26524;&#24744;&#19981;&#26159;&#31649;&#29702;&#21592;&#65292;&#35831;&#36820;&#22238;&#26356;&#25442;&#25903;&#20184;&#26041;&#24335;&#65307;&#22914;&#26524;&#24744;&#26159;&#31649;&#29702;&#21592;&#35831;&#21518;&#21488;&#20851;&#38381;&#26410;&#25903;&#25345;&#30340;&#25903;&#20184;&#26041;&#24335;&#65292;&#25110;&#32773;&#36141;&#20080;&#25903;&#25345;&#30456;&#24212;&#25903;&#20184;&#26041;&#24335;&#30340;&#29256;&#26412;&#65281;');
	}
}