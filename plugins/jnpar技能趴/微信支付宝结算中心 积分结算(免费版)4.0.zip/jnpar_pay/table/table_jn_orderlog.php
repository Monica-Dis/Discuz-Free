<?php
/*
 *	[DisM!] (C)2019-2020 DISM.Taobao.COM.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jn_orderlog extends discuz_table{
	public function __construct() {

		$this->_table = 'jn_orderlog';
		$this->_pk    = '';

		parent::__construct();
	}
	
	public function get_price($buykey,$buyid,$param=NULL){
		global $_G;
		if(empty($_G['cache']['plugin']['jnpar_pay'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pay'];
		
		if($param){
			$price= $param;
		}elseif($buykey==3){
			$pay_pre=$this->get_pre_creditset();
			$payc=$pay_pre['payc'];
			$paycr=$pay_pre['paycr'];
			$paycw=$pay_pre['paycw'];
			$unitprice=$pvar['unitprice'];

			if(in_array($buyid,$paycr)){//���ã���λ��Ԫ	
				$price=$payc[$buyid];
			}else{
				$price=$buyid/$unitprice;
			}
		}elseif($buykey==1){
			$groupbuyset=$this->conftoarray_vip();
			$price=$groupbuyset[$buyid][2];
		}elseif($buykey==2){
			$price=$pvar['inviteprice'];
		}
		
		return $price;
	}
	
	
	
	public function updateorder($ordernum,$pl_ordernum=NULL,$tradeno=NULL,$realprice=NULL){
		$status=DB::result_first("select status from %t where `order`=%s",array($this->_table,$ordernum));
		if($status)return;
		
		global $_G;
		if(empty($_G['cache']['plugin']['jnpar_pay'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pay'];
		
		$arr=explode("p",$ordernum);
		$uid=intval($arr[0]);
		$buytype=intval($arr[1]);
		$buyid=intval($arr[2]);
		
		$code='';
		
		if($buytype>=10){
			$appid=$this->getappid_by_buytype($buytype);
			C::t("#$appid#$appid")->handle_payorder($ordernum);
		}
		$conditon=" `order`='$ordernum'";
		$data=array(
			   'status'=>1,
			   'updatetime'=>time(),
			   'pl_ordernum'=>$pl_ordernum,
			   'tradeno'=>$tradeno,
			   'realprice'=>$realprice,
				'remark1'=>$code,
			   );
		DB::update('jn_orderlog',$data,$conditon);
	}
	
	public function getappid_by_buytype($buytype){
		$appid=DB::result_first('select appid from %t where buytype=%d',array('jn_payapps',$buytype));
		return $appid;
	}
	
	public function orderinfo_by_ordernum($ordernum){
		return DB::fetch_first('select * from %t where `order`=%s',array($this->_table,$ordernum));
	}
	

	
	//�������8λ������ĺ���
	public function make_coupon_card($length=NULL){
		$length=$length?$length:8;
		$chars = 'ABCDEFGHIJKLMNOQRSTUVWXYZ0123456789';//ȥ���ָ���p P��
		$str = "";
		for ( $i = 0; $i < $length; $i++ )
		{
			$str .= $chars[ mt_rand(0, strlen($chars) - 1) ];
		}
		return $str ;
	}
	
	public function createorder($uid,$buytype,$paytype,$price,$buyid,$commodityName=NULL,$commodityDesc=NULL,$remarks=NULL,$remark1=NULL){
		global $_G;
		$sysuid=$_G['uid']?$_G['uid']:0;
		$onlyid=strtoupper(base_convert(TIMESTAMP,10,36)).$this->make_coupon_card(3);
		$order=$uid."p".$buytype."p".$buyid."p".$onlyid;
		$this->saveneworder($order,$paytype,$price,$commodityName,$commodityDesc,$remarks,$remark1);
		return $order;
	}

	public function saveneworder($order,$paytype,$price,$commodityName=NULL,$commodityDesc=NULL,$remarks=NULL,$remark1=NULL){
		$arr=explode("p",$order);
		global $_G;
		$sysuid=$_G['uid']?$_G['uid']:0;
		$sysuname=$_G['username']?$_G['username']:$this->guestidentify();
		$data=array(
			   'uid'=>$arr[0],
				'uname'=>$sysuname,
				'clientip'=>$_G['clientip'],
			   'price'=>$price,
			  'type'=>$arr[1],
				'buyid'=>$arr[2],
			   'createtime'=>TIMESTAMP,
			   'order'=>$order,
			   'paytype'=>$paytype,
			   'commodityName'=>$commodityName,
			   'commodityDesc'=>$commodityDesc,
			   'remarks'=>$remarks,
			   'remark1'=>$remark1,
			   );
		DB::insert('jn_orderlog',$data);
	}
	
	//��ȡ�ο�Ψһʶ����
	function guestidentify(){
		global $_G;
		if($_G['username'])return '';
		
		$guestidentify = getcookie('guestidentify');
		if (!$guestidentify) {
			$guestidentify = $this->make_coupon_card(4).substr(TIMESTAMP,2);
			dsetcookie('guestidentify', $guestidentify, 3600*24*30);//cookie��Ч��30��
		}
		return $guestidentify;
	}
		
	//������ת��������
	function conftoarray_vip(){
		global $_G;
		if(empty($_G['cache']['plugin']['jnpar_pay'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pay'];
		$str=trim($pvar['groupbuyset']);
		if(!$str)return array();
		$array=array();
		$strarray=explode(PHP_EOL,$str);
		foreach ($strarray as $one){
			$temp=explode("|",trim($one));
			$array[$temp[0]]=$temp;
		}
		return $array;
	}
	
	public function get_pre_creditset(){
		global $_G;
		if(empty($_G['cache']['plugin']['jnpar_pay'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pay'];
		$setedcreditbuy=$pvar['setedcreditbuy'];
		$temp1=explode(PHP_EOL,$setedcreditbuy);
		$payc=$paycr=array();
		foreach($temp1 as $s){//�ó�Ԥ��Ľ�$payc����->����ң�$paycr��������
			$temp=explode('|',$s);
			$payc[trim($temp[1])]=intval($temp[0]);
			$paycr[]=intval($temp[1]);
			$paycw[trim($temp[1])]=$temp;
		}
		$return['payc']=$payc;
		$return['paycr']=$paycr;
		$return['paycw']=$paycw;
		//debug($paycw);
		return $return;
	}
	
	public function get_pay_methods($methods=NULL){
		global $_G;
		if(empty($_G['cache']['plugin']['jnpar_pay'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pay'];
		$pay_method=$methods?explode(',',$methods):unserialize($pvar['pay_method']);

		$pay_banks1=$pay_banks2=array();//Ԥ��һ��֧���ӿ�

		if(in_array(1,$pay_method)){
			$pay_banks1['alipay']=1;
		}
		if(in_array(2,$pay_method)){
			$pay_banks1['wechat']=2;
		}
		if(in_array(3,$pay_method)){
			$pay_banks1['credit']=3;
		}
		
		$credits_pay_aps=unserialize($pvar['credits_pay_aps']);
		if(in_array(max(intval($_GET['buykey']),intval($_GET['tab'])),$credits_pay_aps)){
			$pay_banks1['credit']=3;
		}
		
		$return['pay_bank1']=$pay_banks1;
		$return['pay_bank2']=$pay_banks2;
	
		return $return;
	}


	/**
	 * д��־��������ԣ�����վ����Ҳ���ԸĳɰѼ�¼�������ݿ⣩
	 * ע�⣺��������Ҫ��ͨfopen����
	 * @param $word Ҫд����־����ı����� Ĭ��ֵ����ֵ
	 */
	function logResult($word='') {
		$fp = fopen('paylog.txt',"a");
		flock($fp, LOCK_EX) ;
		fwrite($fp,'dotime'.strftime("%Y%m%d%H%M%S",time())."\r\n".$word."\r\n");
		flock($fp, LOCK_UN);
		fclose($fp);
	}
	
	/**
	 * ����������Ԫ�أ����ա�����=����ֵ����ģʽ�á�&���ַ�ƴ�ӳ��ַ���
	 * @param $para ��Ҫƴ�ӵ�����
	 * return ƴ������Ժ���ַ���
	 */
	public function createLinkstring($para) {
		$arg  = "";
		while (list ($key, $val) = each ($para)) {
				$arg.=$key."=".$val."&";
		}
		//ȥ�����һ��&�ַ�
		$arg = substr($arg,0,count($arg)-2);

		//�������ת���ַ�����ôȥ��ת��
		//if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}

		return $arg;
	}
	
	public function get_varin($var,$min,$max){
		$var=intval($var);
		$r=$var<$min?$min:($var>$max?$max:$var);
		return $r;
	}
	
	
	public function passport_encrypt($txt, $key){
		$r='';
		for($i=0;$i<=10;$i++){
			$r=$this->passport_encrypt_tp($txt, $key);
			$ra=explode('@@',$r);
			$c=sizeof($ra);
			if($c<=1){
				break;
			}
		}
		return $r;
	}

	public function passport_encrypt_tp($txt, $key) { 
		srand((double)microtime() * 1000000); 
		$encrypt_key = md5(rand(0, 32000)); 
		$ctr = 0; 
		$tmp = ''; 
		for($i = 0;$i < strlen($txt); $i++) { 
			$ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr; 
			$tmp .= $encrypt_key[$ctr].($txt[$i] ^ $encrypt_key[$ctr++]); 
		} 
		$r=base64_encode($this->passport_key($tmp, $key));
		$r=str_replace('+','@@',$r);
		return $r; 
	} 

	public function passport_decrypt($txt, $key) { 
		$txt = $this->passport_key(base64_decode($txt), $key); 
		$tmp = ''; 
		for($i = 0;$i < strlen($txt); $i++) { 
			$md5 = $txt[$i]; 
			$tmp .= $txt[++$i] ^ $md5; 
		} 
		return $tmp; 
		//return 'aaaa';
	}

	public function passport_key($txt, $encrypt_key) { 
		$encrypt_key = md5($encrypt_key); 
		$ctr = 0; 
		$tmp = ''; 
		for($i = 0; $i < strlen($txt); $i++) { 
			$ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr; 
			$tmp .= $txt[$i] ^ $encrypt_key[$ctr++]; 
		} 
		return $tmp; 
	}
	
	public function getparas(){
		global $_G;
		$para=dhtmlspecialchars($_GET['para']);
		$safekey=$_G['config']['security']['authkey']?$_G['config']['security']['authkey']:'aaaaa';
		$parastr=$this->passport_decrypt($para,$safekey);
		$para_arr=explode('|',$parastr);
		$valitime=$para_arr[8];
		if($valitime<TIMESTAMP)showmessage(lang('plugin/jnpar_pay', 't24'));
		return $para_arr;
	}

}