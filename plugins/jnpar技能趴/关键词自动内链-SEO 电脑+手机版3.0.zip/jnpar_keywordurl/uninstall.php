<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!应用中心.
|   http://dism·taobao·com
|   Support: DisM.Taobao-Com
|   Please don't change the copyright, From: DisM.taobao.Com
|   本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;
?>