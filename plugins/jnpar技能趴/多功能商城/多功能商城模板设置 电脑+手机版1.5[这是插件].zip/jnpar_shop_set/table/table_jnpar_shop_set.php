<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_shop_set extends discuz_table
{
	public function __construct() {

		$this->_table = 'jnpar_shop_set';
		$this->_pk    = '';

		parent::__construct();
	}
	
	function getmobile_nvarr(){
		global $_G;
		$gid=$_G['groupid']?$_G['groupid']:0;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_shop_set'];
		$mobile_index_nav=$pvar['mobile_index_nav'];
		
		$nvarr=array();
		$arr1=explode(PHP_EOL,$mobile_index_nav);
		foreach($arr1 as $k=>$v){
			if(!trim($v))continue;
			$temp=explode('|',trim($v));
			$nvarr[]=$temp;
		}
		return $nvarr;
	}
		
	function getlangset($langname,$from=null,$mobile=null){
		global $_G;
		$gid=$_G['groupid']?$_G['groupid']:0;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_shop_set'];
		
		if($from==1){
			return $pvar[$langname];
		}
		if(!$mobile){
			$langset=$pvar['lang_set'];
		}else{
			$langset=$pvar['mobile_lang_set'];
		}
		
		$arr1=explode(PHP_EOL,$langset);
		foreach($arr1 as $k=>$v){
			if(!$v)continue;
			$temp=explode('=>',trim($v));
			$conf[$temp[0]]=$temp[1];
		}
		$lang=$conf[$langname]?$conf[$langname]:"jnpar_lang:$langname";
		return $lang;
	}
	
	function getmobile_bottom_nav(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_shop_set'];
		$bottom_nav=$pvar['bottom_nav'];
		$arr1=explode(PHP_EOL,$bottom_nav);
		$bottom_navarr=array();
		$i=1;
		foreach($arr1 as $a){
			if(!trim($a))continue;
			$temp=explode("|",trim($a));
			$bottom_navarr[$i]=$temp;
			$i++;
		}
		return $bottom_navarr;
	}
	
	function list_massage_imgs($threadlist){
		$tids=array();
		foreach($threadlist as $t){
			$tids[]=$t['tid'];
		}
		$in=DB::field('tid',$tids);
		$postlist=DB::fetch_all('select pid,tid,message from %t where %i and first=1',array('forum_post',$in));
		$return=array();
		$pids=array();
		$picnum=array();
		$picarr=array();
		foreach($postlist as $p){
			$tid=$p['tid'];
			$message[$tid]=messagecutstr($p['message'],80);
			$pid=$p['pid'];
			$pids[]=$pid;
			$thread_aids[$tid]=DB::fetch_all("SELECT aid FROM %t WHERE pid =%d and isimage=1",array(getattachtablebytid($tid),$pid));
			$picnum[$tid]=count($thread_aids[$tid]);
			for($i=0;$i<3 && $i<$picnum[$tid];$i++){
				$aid=$thread_aids[$tid][$i]['aid'];
				$picarr[$tid][$i] = getforumimg($aid,0,114,114,'');
			}
		}
		$return['message']=$message;
		$return['picnum']=$picnum;
		$return['picarr']=$picarr;
		
		return $return;
	}
	public function getfavlist($uid){
		$r=DB::fetch_all('select * from %t where uid=%d',array('home_favorite',$uid));
		return $r;
	}
	
	public function fava_action($uid,$id,$type,$action){
		if($action==1){
			if($favid=DB::result_first('select favid from %t where id=%d and uid=%d and idtype=%s',array('home_favorite',$id,$uid,$type))){
				return true;
			}else{
				if($type=='aid'){
					DB::result_first('select title from %t where aid=%d',array('portal_article_title',$id));
				}elseif($type=='tid'){
					DB::result_first('select subject from %t where tid=%d',array('forum_thread',$id));
				}elseif($type=='fid'){
					$title=DB::result_first('select name from %t where fid=%d',array('forum_forum',$id));
				}
				
				if($title){
					$data=array(
						'id'=>$id,
						'idtype'=>$type,
						'uid'=>$uid,
						'dateline'=>TIMESTAMP,
						'title'=>$title,
					);
					DB::insert('home_favorite',$data);					
				}

				return true;
			}
		}else{
			DB::delete('home_favorite',array('id'=>$id,'idtype'=>$type,'uid'=>$uid));
			return true;
		}
		return false;
	}
	
}