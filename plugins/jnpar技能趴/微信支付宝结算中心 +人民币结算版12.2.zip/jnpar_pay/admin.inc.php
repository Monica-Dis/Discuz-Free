<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;

if(empty($_G['cache']['plugin']['jnpar_pay'])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin']['jnpar_pay'];

$get=daddslashes($_GET);

$appurl=$_G['siteurl'].ADMINSCRIPT."?action=plugins&operation=config&do={$plugin['pluginid']}&identifier={$plugin['identifier']}&pmod={$get['pmod']}";
$p=$get['p'];
$p=$p?$p:'index';
$formhash=$get['formhash'];

if(submitcheck('deletesubmit')){
	$del_c=dintval($_GET['del_c'],true);
	
	$condition=DB::field('oid',$del_c);
	DB::delete('jn_orderlog',$condition);
	cpmsg("&#21024;&#38500;&#25104;&#21151;",'action=plugins&operation=config&do={$pluginid}&identifier=jnpar_pay&pmod=admin');
}

elseif($p=='index'){
	$pagenum=20;
	$page=max(1,intval($get['page']));
	$begin=($page-1)*$pagenum;
	$where=$pageadd='';
	$order=$get['order'];
	$uid=intval($get['uid']);
	
	$wherezd=array();
	$pageadd="formhash=".FORMHASH;
	if($order and $formhash==FORMHASH){
		$wherezd[]="`order`='$order'";
		$pageadd.="&order=".$order;
	}
	if($uid and $formhash==FORMHASH){
		$wherezd[]="`uid`='$uid'";
		//$suserurl=urlencode($suser);
		$pageadd.="&uid=".$uid;
	}
	if(!empty($wherezd)){
		$where=" where ".join(" and ",$wherezd);
	}
	$manylist=array();
	$rs=DB::query("SELECT * FROM ".DB::table("jn_orderlog")." $where order by oid desc LIMIT $begin , $pagenum");
	while ($rw=DB::fetch($rs)) {
		$manylist[]=$rw;
	}
	$allnum=DB::result_first("SELECT count(*) FROM ".DB::table("jn_orderlog")." $where");
	$pagenav=multi($allnum,$pagenum,$page,$appurl."&p=$p&".$pageadd);
}elseif($p=='del' && $formhash==FORMHASH){
	DB::delete("jn_orderlog",array('oid'=>$_GET["oid"]));
	cpmsg("&#21024;&#38500;&#25104;&#21151;",'action=plugins&operation=config&do={$pluginid}&identifier=jnpar_pay&pmod=admin');
	
}

//elseif ($p==''){}
else cpmsg('&#26410;&#23450;&#20041;&#25805;&#20316;&#65281;');

include(template($plugin['identifier'].":".$_GET['pmod']."_".$p));
?>