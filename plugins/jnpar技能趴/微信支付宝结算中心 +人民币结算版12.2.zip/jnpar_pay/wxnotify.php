<?php
define('IN_API', true);
define('CURSCRIPT', 'wxnotify');
require '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->reject_robot();
$cachelist = array('plugin', 'diytemplatename');
$discuz->cachelist = $cachelist;
$discuz->init();

require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.Api.php';
require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.Notify.php';
require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.Config.php';
require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/log.php';

//��ʼ����־
$logHandler= new CLogFileHandler(date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);
class PayNotifyCallBack extends WxPayNotify
{
	//��ѯ����
	public function Queryorder($transaction_id)
	{
		$input = new WxPayOrderQuery();
		$input->SetTransaction_id($transaction_id);

		$config = new WxPayConfig();
		$result = WxPayApi::orderQuery($config, $input);
		Log::DEBUG("query:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{
			return true;
		}
		return false;
	}
	
	public function LogAfterProcess($xmlData)
	{
		Log::DEBUG("call back�� return xml:" . $xmlData);
		return;
	}
	
	public function NotifyProcess($objData, $config, &$msg)
	{
		$data = $objData->GetValues();
		//TODO 1�����в���У��
		if(!array_key_exists("return_code", $data) 
			||(array_key_exists("return_code", $data) && $data['return_code'] != "SUCCESS")) {
			$msg = lang('plugin/jnpar_pay', 't3');
			return false;
		}
		if(!array_key_exists("transaction_id", $data)){
			$msg = lang('plugin/jnpar_pay', 't4');
			return false;
		}
		
		try {
			$checkResult = $objData->CheckSign($config);
			if($checkResult == false){
				//ǩ������
				Log::ERROR(lang('plugin/jnpar_pay', 't5'));
				return false;
			}
		} catch(Exception $e) {
			Log::ERROR(json_encode($e));
		}

		//TODO 3������ҵ���߼�
		Log::DEBUG("call back:" . json_encode($data));
		$notfiyOutput = array();
		
		
		//��ѯ�������ж϶�����ʵ��
		if(!$this->Queryorder($data["transaction_id"])){
			$msg = lang('plugin/jnpar_pay', 't6');
			return false;
		}

        $trade_no = $data['transaction_id'];//΢��ƽ̨��ˮ����
		$trade_status = $data['result_code'];
		$realprice = $data['total_fee']/100;
		$out_trade_no = $data['out_trade_no'];//�̻�ƽ̨���
		
		if($trade_status == 'SUCCESS'){
			C::t('#jnpar_pay#jn_orderlog')->updateorder($out_trade_no,'',$trade_no,$realprice);
		}
		
		return true;
	}
}

$config = new WxPayConfig();
Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle($config, false);
