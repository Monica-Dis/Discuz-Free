﻿<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!应用中心.
|   http://Dism_taobao·com
|   Support: DISM.TAOBAO.COM
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：授权许可程序，此程序只授权于应用中心下载网站域名，私自修改文件将失去商业售后服务！
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_pansell";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jnpar_pansell_tlog` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `baidupan` text,
  `ciliurl` text,
  `dianlvurl` text,
  `xunleiurl` text,
  `needmoney` int(5) NOT NULL DEFAULT '0',
  `downauth` INT( 4 ) NOT NULL ,
  `bei1` INT( 10 ) NOT NULL ,
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_jnpar_pansell_buylog` (
  `buyid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `buyuid` int(10) unsigned NOT NULL,
  `buyuname` varchar(40) NOT NULL,
  `buytime` int(10) unsigned NOT NULL,
  `remarks` varchar(10) NOT NULL,
  PRIMARY KEY (`buyid`),
  KEY `buyuid` (`buyuid`),
  KEY `tid` (`tid`),
  KEY `buyuname` (`buyuname`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_jnpar_pansell_invalidlog` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL,
  `kid` smallint(2) NOT NULL,
  `title` varchar(150) NOT NULL,
  `status` smallint(2) NOT NULL,
  `logtime` int(10) NOT NULL,
  `invalidetimes` INT(10) NOT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM;

INSERT INTO `pre_jn_payapps` (`buytype`, `appid`, `version`, `installtime`, `paras`, `remarks`) VALUES
(11, 'jnpar_pansell', '19.0', 0, '', '');

EOF;

runquery($sql);

$finish = TRUE;
?>