<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!Ӧ������.
|   http://Dism_taobao��com
|   Support: DISM.TAOBAO.COM
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Ȩ���ɳ��򣬴˳���ֻ��Ȩ��Ӧ������������վ������˽���޸��ļ���ʧȥ��ҵ�ۺ����
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_pansell";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');

$sql1 = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jnpar_pansell_invalidlog` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL,
  `kid` smallint(2) NOT NULL,
  `title` varchar(150) NOT NULL,
  `status` smallint(2) NOT NULL,
  `logtime` int(10) NOT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM;

EOF;

$sql2 = <<<EOF

ALTER TABLE `pre_jnpar_pansell_invalidlog` ADD `invalidetimes` INT( 10 ) NOT NULL ;

EOF;

$sql3 = <<<EOF

ALTER TABLE `pre_jnpar_pansell_tlog` ADD `downauth` INT( 4 ) NOT NULL ,
ADD `bei1` INT( 10 ) NOT NULL ;

EOF;

$sql4 = <<<EOF

ALTER TABLE `pre_jnpar_pansell_buylog` ADD `buyuname` varchar(40) NOT NULL,
ADD INDEX `buyuid` (`buyuid`),
ADD INDEX `tid` (`tid`),
ADD INDEX `buyuname` (`buyuname`);

EOF;

$sql5 = <<<EOF

INSERT INTO `pre_jn_payapps` (`buytype`, `appid`, `version`, `installtime`, `paras`, `remarks`) VALUES
(11, 'jnpar_pansell', '19.0', 0, '', '');

EOF;



global $_G,$pluginid;
$pversion = preg_replace('/([\x80-\xff]*)/i','',$_G['setting']['plugins']['version'][$plugin['identifier']]);
$vernum=floatval($pversion);
if($vernum<3){//3.0�汾����
	runquery($sql1);
	runquery($sql2);	
	runquery($sql3);	
}elseif($vernum<8){
	runquery($sql2);
	runquery($sql3);
}elseif($vernum<11){
	runquery($sql3);	
}elseif($vernum<19){
	runquery($sql4);	
	runquery($sql5);	
}
@unlink('source/plugin/'.$identify.'/upgrade.php');


$finish = true;
?>