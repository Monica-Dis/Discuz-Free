<?php
/*
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վDism_taobao��com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}



if(submitcheck('submit')){
	global $_G;
	$tid=intval($_GET['tid']);
	$pid=intval($_GET['pid']);
	$threadinfo=DB::fetch_first("select authorid,subject from ".DB::table('forum_thread')." where tid='$tid'");
	$authorid=$threadinfo['authorid'];
	$subject=$threadinfo['subject'];
	
	if(!$_G['uid']){
		showmessage(lang('plugin/jnpar_pansell', 'hook3'));
	}
	
	$uid=$_G['uid'];
	$gid=$_G['groupid'];
	$username=$_G['username'];
	$groupname=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid='$gid'");
	
	
	if(empty($_G['cache']['plugin'])){
		loadcache('plugin');
	}
	$var=$_G['cache']['plugin']['jnpar_pansell'];
	$charge_ratio=$var['charge_ratio'];
	$creditsn='extcredits'.$var['down_credit'];
	$ex_title=$_G['setting']['extcredits'][$var['down_credit']]['title'];
	$ubalance=getuserprofile($creditsn);
	$charge_ratio=$var['charge_ratio'];
	$agent_domain=$var['agent_domain'];
	
	$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_tlog')." where tid='$tid'");
	$sellmoney=$downinfo['needmoney'];
	$needmoney=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getneedmoney($sellmoney);
	$gper=C::t('#jnpar_pansell#jnpar_pansell_buylog')->get_vip_fee_config();
	
	$needpay=$needmoney;
	$credittitle=$_G['setting']['extcredits'][$var['down_credit']]['title'];
	

	if($ubalance<$needpay){//���ֲ���
		showmessage(lang('plugin/jnpar_pansell', 'hook4'));
	}
	
	$lockid = $tid.'_'.$_G['uid'];
//	if(discuz_process::islocked($lockid)){
//		usleep(500000);
//	}
	
	//$buyid=DB::result_first('select buyid from '.DB::table('jnpar_pansell_buylog')." where buyuid='$uid' and tid='$tid'");
	$uname=$_G['username']?$_G['username']:C::t('#jnpar_pay#jn_orderlog')->guestidentify();
	$buyid=DB::result_first('select buyid from %t where buyuname=%s and tid=%d',array('jnpar_pansell_buylog',$uname,$tid));
	
	if(!$buyid and !discuz_process::islocked($lockid)){//��������ڼ�¼�������
		$data=array(
					'buyuid'=>$uid,
					'tid'=>$tid,
					'buytime'=>time(),
					'buyuname'=>$uname,
					'remarks'=>$needpay.$credittitle,
					);
		DB::insert('jnpar_pansell_buylog',$data);
		
		$toauthorpay=ceil($needpay*(1-$charge_ratio/100));
		
		$lltz=lang('plugin/jnpar_pansell', 'hook5');
		$tzbll='&#32593;&#30424;&#36164;&#28304;&#20986;&#21806;';
		if($version=='X2.5'){
			updatemembercount($uid,array($creditsn => -$needpay),true, 'BTC', $tid, lang('plugin/jnpar_pansell', 'hook5').$tid);
			updatemembercount($authorid,array($creditsn => $toauthorpay),true, 'STC', $tid, '&#20986;&#21806;&#19979;&#36733;&#22320;&#22336;');
		}else{
			updatemembercount($uid,array($creditsn => -$needpay),true, 'BTC', $tid,$lltz,$lltz, lang('plugin/jnpar_pansell', 'hook5').$tid);
			updatemembercount($authorid,array($creditsn => $toauthorpay),true, 'STC', $tid, $tzbll,$tzbll,'&#20986;&#21806;&#19979;&#36733;&#22320;&#22336;');
		}
		$buytime=date("Y-m-d H:i:s");
		$pm_content=str_replace(array('{groupname}','{username}','{subject}','{buytime}','{needmoney}','{toauthor}','{gper}'),array($groupname,$username,$subject,$buytime,$sellmoney,$toauthorpay,$gper),$var['note_template']);
		
		$sendpm=notification_add($authorid,'system',$pm_content);
		discuz_process::unlock($lockid);
		
	}else{
		showmessage(lang('plugin/jnpar_pansell', 'hook6'));
	}
	
	if($agent_domain){
		header('Location:'.$agent_domain.'/forum.php?mod=viewthread&tid='.$tid);
	}else{
		header('Location:'.dreferer());
	}
	exit();

}else{
	global $_G;

	$uid=$_G['uid']?$_G['uid']:0;
	
	if(!$uid)showmessage('to_login', NULL, array(), array('login' => 1));
	
	include template('jnpar_pansell:paytip');
}
//From: dis'.'m.t'.'ao'.'bao.com
?>