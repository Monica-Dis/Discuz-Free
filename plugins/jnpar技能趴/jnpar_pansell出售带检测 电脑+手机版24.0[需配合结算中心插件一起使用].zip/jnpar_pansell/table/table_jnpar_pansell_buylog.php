<?php
/*
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վDism_taobao��com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_pansell_buylog extends discuz_table{
	public function __construct() {

		$this->_table = 'jnpar_pansell_buylog';
		$this->_pk    = '';

		parent::__construct(); /*Dism_taobao-com*/
	}
	
	function getlangset($langname){
		global $_G;
		$gid=$_G['groupid']?$_G['groupid']:0;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pansell'];
		$langset=$pvar['lang_set'];
		
		$arr1=explode(PHP_EOL,$langset);
		foreach($arr1 as $k=>$v){
			if(!$v)continue;
			$temp=explode('=>',trim($v));
			$conf[$temp[0]]=$temp[1];
		}
		$lang=$conf[$langname]?$conf[$langname]:"jnpar_lang:$langname";
		return $lang;
		
	}
	
	function get_vip_fee_config(){
		global $_G;
		$gid=$_G['groupid']?$_G['groupid']:0;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pansell'];
		$vip_fee=trim($pvar['vip_fee']);
		if(!$vip_fee)return 100;
		$arr1=explode(PHP_EOL,$vip_fee);
		foreach($arr1 as $k=>$v){
			if(!$v)continue;
			$temp=explode('|',trim($v));
			$conf[$temp[0]]=$temp[1];
		}
		return $conf[$gid]?$conf[$gid]:100;
	}
	
	function checkpanurl($url){
		global $_G;
		$gid=$_G['groupid']?$_G['groupid']:0;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_pansell'];
		$check_mod=$pvar['check_mod'];
		if(!$check_mod){
			$return=dfsockopen($url);
		}elseif($check_mod==1){
			$return=file_get_contents($url);
		}elseif($check_mod==2){
			$ch = curl_init(); //ʹ��curl����
			$timeout = 35;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$return = curl_exec($ch);
			curl_close($ch);
		}
		if(strtolower(CHARSET) == 'gbk'){
			$return=diconv($return,'UTF-8','GBK');
		}
		return $return;
	}
	
	function getneedmoney($money){
		global $_G;
		$vip_fee_per=$this->get_vip_fee_config();
		return round($money*$vip_fee_per/100);
	}

}