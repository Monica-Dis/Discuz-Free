<?php

/*

 *	DisM!Ӧ�����ģ�dism.taobao.com

 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��

 *  ��������վDism_taobao��com �����ƹ㣬������ʻ��١�

 *	$_G['basescript'] = ģ������

 *	CURMODULE = Ϊģ���Զ��峣��

 */

 

if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}



class table_jnpar_pansell extends discuz_table

{

	public function __construct() {



		$this->_table = 'jnpar_pansell';

		$this->_pk    = '';



		parent::__construct(); /*Dism_taobao-com*/

	}



	

	public function genorder($para_arr,$paytype){

		global $_G;

		$buykey=11;//���̳��۴����	buykey(��buytype)=11



		$siteurl = $_G['siteurl'];

		$sitename = $_G['setting']['sitename'];

		$username=$_G['username'];

		$uid=$_G['uid']?$_G['uid']:0;

		$tid=$para_arr[0];

		$has_record=$para_arr[1];

		$authorid=$para_arr[2];

		$price=$count_need=$para_arr[3];

		$count_toauthor=$para_arr[4];

		$pid=$para_arr[5];

		$payways=$para_arr[6];

		$allow_guestpay=$para_arr[7];

		

		$commodityName=lang('plugin/jnpar_pay', 't23');

		$desc = lang('plugin/jnpar_pay', 't23')."-pansell:tid".$tid;

		$paras=implode('|',$para_arr);

		$orderNum=C::t('#jnpar_pay#jn_orderlog')->createorder($uid,$buykey,$paytype,$price,$tid,$commodityName,$desc,$paras);

		$appreturn['return_url']=$siteurl.'forum.php?mod=viewthread&tid='.$tid;

		$appreturn['commodityName']=$commodityName;

		$appreturn['desc']=$desc;

		$appreturn['orderNum']=$orderNum;

		

		return $appreturn;

	}

	public function appcheck($arr){

		//���޼����

		return;

	}

	

	public function handle_payorder($ordernum){

		global $_G;

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$credit_reward=$pvar['down_credit'];//�����߽����Ļ�������

		$charge_ratio=$pvar['charge_ratio'];

		$percent_give=100-$charge_ratio;//�����ߵĻ��ֽ�������

		

		$orderinfo=C::t('#jnpar_pay#jn_orderlog')->orderinfo_by_ordernum($ordernum);

		$uname=$orderinfo['uname'];

		$remarks=trim($orderinfo['remarks']);

		$para_arr=explode('|',$remarks);

		$arr=explode("p",$ordernum);

		

		$uid=intval($arr[0]);

		$tid=intval($arr[2]);

		

		$thread = C::t('forum_thread')->fetch($tid);

		$subject=$thread['subject'];

		$authorid=$thread['authorid'];

		

		$realprice=$orderinfo['price']*100;

		$toauthor=floor($realprice*$percent_give/100);

		$rewardc='extcredits'.$credit_reward;

		if($version=='X2.5'){

			updatemembercount($authorid,array($rewardc => $toauthor),true, 'STC', $tid, lang('plugin/jnpar_pansell','logadd1'));

		}else{

			updatemembercount($authorid,array($rewardc => $toauthor),true, 'STC', $tid, lang('plugin/jnpar_pansell','logadd1'),lang('plugin/jnpar_pansell','logadd2'),lang('plugin/jnpar_pansell','logadd1'));

		}

		$buytime=date("Y-m-d H:i:s");

		$buyuinfo=$this->getbuyuinfo($uid,$uname);

		$sellmoney=$para_arr[9];

		$gdiscount=$para_arr[10];

		$pm_content=str_replace(array('{groupname}','{username}','{subject}','{buytime}','{needmoney}','{toauthor}','{gper}'),array($buyuinfo['groupname'],$buyuinfo['username'],$subject,$buytime,$sellmoney,$toauthor,$gdiscount),$pvar['note_template']);

		

		$sendpm=notification_add($authorid,'system',$pm_content);

		

		$buyid=$uid?DB::result_first('select buyid from '.DB::table('jnpar_pansell_buylog')." where buyuid='$uid' and tid='$tid'"):DB::result_first('select buyid from %t where buyuname=%s and tid=%d',array('jnpar_pansell_buylog',$uname,$tid));

		

		if(!$buyid){//��������ڼ�¼�������

			$data=array(

						'buyuid'=>$uid,

						'buyuname'=>$uname,

						'tid'=>$tid,

						'buytime'=>TIMESTAMP,

						);

			DB::insert('jnpar_pansell_buylog',$data);

		}else{//����Ѵ��ڼ�¼�������

			DB::query('update %t set buyuname=%s,buytime=%d where buyid=%d',array('jnpar_pansell_buylog',$uname,TIMESTAMP,$buyid));

		}

	}

	function getbuyuinfo($uid,$uname){

		$return=array();

		if(!$uid){

			$return['groupname']=lang('plugin/jnpar_pansell','logadd3');

			$return['username']=lang('plugin/jnpar_pansell','logadd3').substr($uname,0,3).'***';

		}else{

			$uinfo=DB::fetch_first('select username,groupid from %t where uid=%d',array('common_member',$uid));

			$return['groupname']=DB::result_first("select grouptitle from %t where groupid=%d",array('common_usergroup',$uinfo['groupid']));

			$return['username']=$uinfo['username'];

		}

		return $return;

	}
	function array_column(array $array, $column_key, $index_key=null){
		$result = array();
		foreach($array as $arr) {
			if(!is_array($arr)) continue;

			if(is_null($column_key)){
				$value = $arr;
			}else{
				$value = $arr[$column_key];
			}

			if(!is_null($index_key)){
				$key = $arr[$index_key];
				$result[$key] = $value;
			}else{
				$result[] = $value;
			}
		}
		return $result; 
	}


}