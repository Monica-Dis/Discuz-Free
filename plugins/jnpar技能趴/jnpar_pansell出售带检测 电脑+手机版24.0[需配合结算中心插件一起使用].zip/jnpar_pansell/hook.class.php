<?php

/*

 *	DisM!Ӧ�����ģ�dism.taobao.com

 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��

 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�

 *	$_G['basescript'] = ģ������

 *	CURMODULE = Ϊģ���Զ��峣��

 */



if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}



require_once DISCUZ_ROOT . "./source/plugin/jnpar_pansell/base.class.php";



class plugin_jnpar_pansell extends plugin_jnpar_pansell_base{

	

}

class plugin_jnpar_pansell_forum extends plugin_jnpar_pansell{

	function post_middle_output(){

		global $_G,$postinfo;

		$var1=lang('plugin/jnpar_pansell', 'var1');

		$fid=$_G['fid'];

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$down_credit=$pvar['down_credit'];

		$pay_ext=$_G['setting']['extcredits'][$down_credit]['title'];

		$open_class=unserialize($pvar['open_class']);

		

		$$var1=$this->open_or_not();

		$gaction=dhtmlspecialchars($_GET['action']);

		if(!$flag or !($gaction=='newthread' or ($gaction=='edit' and $postinfo['first']==1)))return;

		if($gaction=='edit'){

			$tid=intval($_GET['tid']);

			$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_tlog')." where tid='$tid'");

			$logid=$downinfo['logid'];

			$baidupan=$downinfo['baidupan'];

			$downauth=$downinfo['downauth'];

			$needmoney=$downinfo['needmoney']?$downinfo['needmoney']:0;	

		}

		include template("jnpar_pansell:inputtable");

		return $htmlcode;

	}

	

	function post_bottom_output(){

		global $_G;

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$must_pan=$pvar['must_pan'];

		$flag=$this->open_or_not();

		$gaction=dhtmlspecialchars($_GET['action']);

		if(!$flag or $gaction!='newthread' or !$must_pan)return;

		include template("jnpar_pansell:js");

		return $htmlcode;

	}

	

	function post_newthread_message($para){

		global $_G,$isfirstpost;

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$must_pan=$pvar['must_pan'];

		$flag=$this->open_or_not();

		$uid=$_G['uid'];

		$get=dhtmlspecialchars($_GET);

		$baidupan=$get['baidupan'];

		$downauth=$get['downauth'];

		$needmoney=$get['needmoney'];

		$gaction=dhtmlspecialchars($_GET['action']);

		

		if($flag && $gaction=='newthread' and $get['message']){

			if(!$baidupan and $must_pan){

				showmessage(lang('plugin/jnpar_pansell', 'hook2'));

			}

		}

		

		list($message, $forwordURL, $threadValue) = $para['param'];

		

		if(($message=='post_newthread_succeed' or $message=='post_newthread_mod_succeed') && $flag){//��������ѿ�����鷢������

			$data=array(

						'tid'=>$threadValue['tid'],

						'baidupan'=>$baidupan,

						'ciliurl'=>$ciliurl,

						'dianlvurl'=>$dianlvurl,

						'xunleiurl'=>$xunleiurl,

						'needmoney'=>$needmoney,

						'downauth'=>$downauth,

						

						);

			DB::insert('jnpar_pansell_tlog',$data);

		}

		if(($message=='post_edit_succeed' or $message=='edit_newthread_mod_succeed') && $flag && $isfirstpost){//��������ѿ������༭����

			$condition=' tid='.$threadValue['tid'];

			$hasrecord=DB::result_first("select tid from ".DB::table("jnpar_pansell_tlog")." where ".$condition);

			if($hasrecord){//����Ѿ����ڼ�¼�����

				$data=array(

							'baidupan'=>$baidupan,

							'ciliurl'=>$ciliurl,

							'dianlvurl'=>$dianlvurl,

							'xunleiurl'=>$xunleiurl,

							'needmoney'=>$needmoney,

							'downauth'=>$downauth,

							);

				DB::update('jnpar_pansell_tlog',$data,$condition);

				DB::delete('jnpar_pansell_invalidlog',$condition);			

			}else{//��������ڼ�¼�����

				$data=array(

							'tid'=>$threadValue['tid'],

							'baidupan'=>$baidupan,

							'ciliurl'=>$ciliurl,

							'dianlvurl'=>$dianlvurl,

							'xunleiurl'=>$xunleiurl,

							'needmoney'=>$needmoney,

							'downauth'=>$downauth,

							);

				DB::insert('jnpar_pansell_tlog',$data);

			}

		}		

	}

	

	function viewthread_modaction_output(){

		global $_G,$thread;

		

		$uid=$_G['uid'];

		$tid=$thread['tid'];

		$pid=$thread['pid'];

		$authorid=$thread['authorid'];

		$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_tlog')." where tid='$tid'");

		$logid=$downinfo['logid'];

		$pantext=trim($downinfo['baidupan']);

		

		

		$gid=$_G['groupid'];

		

		$downauth=$downinfo['downauth'];

		

		$allow_buy=$_G['cache']['usergroups'][$gid]['readaccess']>=$downauth?1:0;

		

		$group_by_auth=C::t('#jnpar_pansell#jnpar_pansell')->array_column($_G['cache']['usergroups'],'grouptitle','readaccess');		

		$allow_buy_groupname=$group_by_auth[$downauth];

		

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$used_ext=$pvar['down_credit'];

		$dexttitle=$_G['setting']['extcredits'][$used_ext]['title'];

		

		$tcolor=$pvar['tcolor'];

		$lcolor=$pvar['lcolor'];

		

		$tipcon=$pvar['tipcon'];

		$ubtip=$pvar['ubtip'];

		

		$check_tip=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('checktip');

		$groupname=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid='$gid'");

		$notallow_blank=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('notallow_blank');

		$hadback=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('hadback');

		$backtitle=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('backtitle');

		$backtipname=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('backtipname');

		

		$sellmoney=$downinfo['needmoney'];

		$needmoney=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getneedmoney($sellmoney);

		$gper=C::t('#jnpar_pansell#jnpar_pansell_buylog')->get_vip_fee_config();

		

		if(!$pantext)return;

		

		$pantext=preg_replace("/([ \t]|^)www\./i", "\\1http://www.", $pantext);

		$preg='/(http|https):\/\/([\S]+)/';

		$panarr=explode(PHP_EOL,$pantext);

		$pants=$baidupans=$temp=array();

		foreach($panarr as $k=>$pan){

			if(!trim($pan))continue;

			$pants[]=$this->text2links($pan);

		}

		

		$showable=0;

		$uname=$_G['username']?$_G['username']:C::t('#jnpar_pay#jn_orderlog')->guestidentify();

		$buyid=DB::result_first('select buyid from %t where buyuname=%s and tid=%d',array('jnpar_pansell_buylog',$uname,$tid));

		$gid=$_G['groupid'];

		$free_gids=unserialize($pvar['free_gids']);

		$isf=in_array($gid,$free_gids);

		if($buyid or $uid==$authorid or $needmoney==0 or $isf){

			$showable=1;

		}

		

		//�˴����һ��iframe��Ϊ�ύ������Ŀ�괰�ڣ�������´���

		$iframe='<iframe frameborder=0 width="0" height="0" src="" scrolling="no" name="ifrm" id="ifrm"></iframe>';

		

		//======

		$payedlog=$showable;//�Ƿ���֧����¼

		$count_need=$needmoney/$pvar['rmb2c'];//��Ҫ֧���Ļ�����������������

		$charge_ratio=$pvar['charge_ratio'];

		$count_toauthor=round($count_need*(100-$charge_ratio)/100);//��Ҫ�ָ����ߵĻ�������

		$payway_open=unserialize($pvar['payway_open']);

		$payways=implode(',',$payway_open);//������֧����ʽ

		$allow_guestpay=1;//��Ӧ���Ƿ���������֧��

		$valitime=TIMESTAMP+300;//������Чʱ��5����

		$gdiscount=$gper/10;//�û����ۿ�

		$mdiscount=0;//ѫ���ۿ�

		$para=$tid.'|'.$payedlog.'|'.$authorid.'|'.$count_need.'|'.$count_toauthor.'|'.$pid.'|'.$payways.'|'.$allow_guestpay.'|'.$valitime.'|'.$sellmoney.'|'.$gdiscount.'|'.$mdiscount;

		$para=C::t('#jnpar_pay#jn_orderlog')->passport_encrypt($para,$_G['config']['security']['authkey']);

		

		$urlextra="";

		if($gdiscount<10 and $gdiscount>0){

			$urlextra.="&gdc={$gdiscount}";

		}elseif($mdiscount<10 and $mdiscount>0){

			$urlextra.="&mdc={$mdiscount}";

		}

		

		//ƴ�ӹ�������

		$templatevar=$allow_buy?"pay":'notip';

		if($pvar['open_newpay']){

			if($allow_buy){

				$buyurl="plugin.php?id=jnpar_pay:jn_pay&para={$para}&appid=jnpar_pansell".$urlextra;

			}else{

				$buyurl="plugin.php?id=jnpar_pansell:".$templatevar."&tid={$tid}&pid={$pid}";

			}

		}else{

			$buyurl="plugin.php?id=jnpar_pansell:".$templatevar."&tid={$tid}&pid={$pid}";

		}

		//======

		

		include template('jnpar_pansell:record');

		//debug();

		if($logid){

			include template('jnpar_pansell:outtable');

		}

		return $htmlcode;

	}

}



class mobileplugin_jnpar_pansell extends plugin_jnpar_pansell_base{

	

}

class mobileplugin_jnpar_pansell_forum extends mobileplugin_jnpar_pansell{

	function viewthread_postbottom_mobile_output(){

		global $_G,$thread,$postlist;

		$uid=$_G['uid'];

		$tid=$thread['tid'];

		$pid=$thread['pid'];

		$authorid=$thread['authorid'];

		$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_tlog')." where tid='$tid'");

		$logid=$downinfo['logid'];

		$pantext=trim($downinfo['baidupan']);

		

		if(!$pantext)return;

		

		$downauth=$downinfo['downauth'];

		$gid=$_G['groupid'];

		$allow_buy=$_G['cache']['usergroups'][$gid]['readaccess']>=$downauth?1:0;

		

		

		$group_by_auth=C::t('#jnpar_pansell#jnpar_pansell')->array_column($_G['cache']['usergroups'],'grouptitle','readaccess');		

		$allow_buy_groupname=$group_by_auth[$downauth];

		

		$pantext=preg_replace("/([ \t]|^)www\./i", "\\1http://www.", $pantext);

		$preg='/(http|https):\/\/([\S]+)/';

		$panarr=explode(PHP_EOL,$pantext);

		$pants=$baidupans=$temp=array();

		foreach($panarr as $k=>$pan){

			if(!trim($pan))continue;

			$pants[]=$this->text2links($pan);

		}

		if(empty($_G['cache']['plugin'])){

			loadcache('plugin');

		}

		$pvar=$_G['cache']['plugin']['jnpar_pansell'];

		$used_ext=$pvar['down_credit'];

		$dexttitle=$_G['setting']['extcredits'][$used_ext]['title'];

		

		$tcolor=$pvar['tcolor'];

		$lcolor=$pvar['lcolor'];

		

		$tipcon=$pvar['tipcon'];

		$ubtip=$pvar['ubtip'];

		

		

		$check_tip=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('checktip');

		$notallow_blank=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('notallow_blank');

		$hadback=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('hadback');

		$backtitle=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('backtitle');

		$backtipname=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getlangset('backtipname');

		

		

		

		

		$groupname=DB::result_first("select grouptitle from ".DB::table('common_usergroup')." where groupid='$gid'");

		$sellmoney=$downinfo['needmoney'];

		$needmoney=C::t('#jnpar_pansell#jnpar_pansell_buylog')->getneedmoney($sellmoney);

		$gper=C::t('#jnpar_pansell#jnpar_pansell_buylog')->get_vip_fee_config();

		

		$showable=0;

		$uname=$_G['username']?$_G['username']:C::t('#jnpar_pay#jn_orderlog')->guestidentify();

		$buyid=DB::result_first('select buyid from %t where buyuname=%s and tid=%d',array('jnpar_pansell_buylog',$uname,$tid));

		$gid=$_G['groupid'];

		$free_gids=unserialize($pvar['free_gids']);

		$isf=in_array($gid,$free_gids);

		if($buyid or $uid==$authorid or $needmoney==0 or $isf){

			$showable=1;

		}

		

		//�˴����һ��iframe��Ϊ�ύ������Ŀ�괰�ڣ�������´���

		$iframe='<iframe frameborder=0 width="0" height="0" src="" scrolling="no" name="ifrm" id="ifrm"></iframe>';

		

		//======

		$payedlog=$showable;//�Ƿ���֧����¼

		$count_need=$needmoney/$pvar['rmb2c'];//��Ҫ֧���Ļ�����������������

		$charge_ratio=$pvar['charge_ratio'];

		$count_toauthor=round($count_need*(100-$charge_ratio)/100);//��Ҫ�ָ����ߵĻ�������

		$payway_open=unserialize($pvar['payway_open']);

		$payways=implode(',',$payway_open);//������֧����ʽ

		$allow_guestpay=1;//��Ӧ���Ƿ���������֧��

		$valitime=TIMESTAMP+300;//������Чʱ��5����

		$gdiscount=$gper/10;//�û����ۿ�

		$mdiscount=0;//ѫ���ۿ�

		$para=$tid.'|'.$payedlog.'|'.$authorid.'|'.$count_need.'|'.$count_toauthor.'|'.$pid.'|'.$payways.'|'.$allow_guestpay.'|'.$valitime.'|'.$sellmoney.'|'.$gdiscount.'|'.$mdiscount;

		$para=C::t('#jnpar_pay#jn_orderlog')->passport_encrypt($para,$_G['config']['security']['authkey']);

		

		$urlextra="";

		if($gdiscount<10 and $gdiscount>0){

			$urlextra.="&gdc={$gdiscount}";

		}elseif($mdiscount<10 and $mdiscount>0){

			$urlextra.="&mdc={$mdiscount}";

		}

		

		//ƴ�ӹ�������

		$buyurl="plugin.php?id=jnpar_pay:jn_pay&para={$para}&appid=jnpar_pansell".$urlextra;

		//======

		

		include template('jnpar_pansell:record');

		if($logid){

			include template('jnpar_pansell:outtable');

		}

		$return=array();

		foreach($postlist as $pid => $post){

			if($post['first']){

				$return[0] = $htmlcode;

			}

		}

		

		return $return;

	}

}