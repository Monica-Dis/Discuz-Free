<?php
/*
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վDism_taobao��com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;
if(empty($_G['cache']['plugin'])){
	loadcache('plugin');
}
$var=$_G['cache']['plugin']['jnpar_pansell'];
$stip=$var['stip'];
$ftip=$var['ftip'];

$tid=intval($_GET['tid']);
$uk=intval($_GET['k']);

$max_valide=$var['max_valide'];
$gid=$_G['groupid'];
$utip=$var['utip'];
$usegids=unserialize($var['use_gids']);
if(!in_array($gid,$usegids)){//���û�м��Ȩ��
	include template('jnpar_pansell:useless');
	exit();
}

$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_tlog')." where tid='$tid'");
$logid=$downinfo['logid'];

$pantext=trim($downinfo['baidupan']);
$pantext=preg_replace("/([ \t]|^)www\./i", "\\1http://www.", $pantext);
$preg='/(http|https):\/\/([\S]+)/';
$panarr=explode(PHP_EOL,$pantext);
$pants=$baidupans=$temp=array();
foreach($panarr as $k=>$pan){
	if(!trim($pan))continue;
	preg_match($preg,$pan,$temp);
	if($temp[0]){
		$baidupans[]=$temp[0];
	}else{
		$baidupans[]=$pan;
	}
}

$panurl=$baidupans[$uk];
$maindomain=str_replace(array('http://','https://'),array('',''),$panurl);
$maindomain=substr($maindomain,0,13);

$isvalide=0;
$flagstr='name="baidu-tc-verification"';
$flagstr1='<div id="share_nofound_des">';

$loginfo=DB::fetch_first('select * from '.DB::table('jnpar_pansell_invalidlog').' where tid='.$tid.' and kid='.$uk);
$logid=$loginfo['logid'];
$invalidetimes=$loginfo['invalidetimes'];

if($maindomain=='pan.baidu.com' and $invalidetimes<$max_valide){
	$html=C::t('#jnpar_pansell#jnpar_pansell_buylog')->checkpanurl($panurl);
	$temp=explode($flagstr,$html);
	$temp1=explode($flagstr1,$html);
	$n=sizeof($temp);
	$n1=sizeof($temp1);
	if($n==2 && $n1!=2){
		$isvalide=1;
		$condition=' tid='.$tid.' and kid='.$uk;
		DB::delete('jnpar_pansell_invalidlog',$condition);
	}else{
		$threadinfo=DB::fetch_first("select authorid,subject from ".DB::table('forum_thread')." where tid='$tid'");
		$authorid=$threadinfo['authorid'];
		$threadurl='forum.php?mod=viewthread&tid='.$tid;
		$pm_content=$var['back_template1'];
		$pm_content=str_replace(array('{dateline}','{url}'),array(date('Y-m-d H:i:s'),$threadurl),$pm_content);

		$sendpm=notification_add($authorid,'system',$pm_content);
		
		if(!$logid){
			$data=array(
				'tid'=>$tid,
				'kid'=>$uk,
				'status'=>2,//��Ч��־
				'logtime'=>TIMESTAMP,
				'invalidetimes'=>1,
			);
			DB::insert('jnpar_pansell_invalidlog',$data);
		}else{
			DB::query('update '.DB::table('jnpar_pansell_invalidlog').' set invalidetimes=invalidetimes+1 where tid='.$tid.' and kid='.$uk);
		}
	}
}


include template('jnpar_pansell:check');

