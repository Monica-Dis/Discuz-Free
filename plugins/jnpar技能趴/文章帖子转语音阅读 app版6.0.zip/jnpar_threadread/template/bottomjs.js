	
var loadedflag=0;
function loaded(){
	loadedflag=1;
}
var aud = document.getElementById("myaudio");
var jnpar_playpause = document.getElementById("jnpar_playpause");
var play_status = document.getElementById("play_status");
jnpar_playpause.onclick = function() {
	//alert(loadedflag);
	if (aud.paused && loadedflag==1) {
		aud.play();
	} else if(aud.paused && loadedflag==0){
		jnpar_playpause.className="jnpar_wait";
		play_status.innerHTML="加载中";
		aud.autoplay="autoplay";
	} else {
		jnpar_playpause.className="jnpar_wait";
		aud.pause();
	}
}
aud.addEventListener("play", function (e) {
	jnpar_playpause.className="jnpar_pause";
		play_status.innerHTML="正在播放";
}, false);
aud.addEventListener("pause", function (e) {
	jnpar_playpause.className="jnpar_play";
		play_status.innerHTML="暂停播放";
}, false);
		

 