<?php 
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



class plugin_jnpar_threadread{
	function thread_handle(){
		global $postlist;
		$flag=C::t('#jnpar_threadread#threadread_log')->open_or_not();
		$autoplay=C::t('#jnpar_threadread#threadread_log')->autoplay();
		if(!$flag)return;
		$return=array();
		foreach($postlist as $p){
			if($p['first']==1){
				$txt=C::t('#jnpar_threadread#threadread_log')->get_txttoread($p['message']);
				$playtime=C::t('#jnpar_threadread#threadread_log')->num2time($txt);
				
				$audurl=$_G['siteurl'].'plugin.php?id=jnpar_threadread:conv&tid='.$p['tid'].'&pid='.$p['pid'].'&formhash='.FORMHASH;
				
				include template('jnpar_threadread:control');
				$return[]=$control;
			}else{
				$return[]='';
			}
		}
		return $return;
	}
	
	function article_handle(){
		global $content;
		$flag=C::t('#jnpar_threadread#threadread_log')->open_or_not();
		$autoplay=C::t('#jnpar_threadread#threadread_log')->autoplay();
		if(!$flag)return;
		$txt=C::t('#jnpar_threadread#threadread_log')->get_txttoread($content['content']);
		$playtime=C::t('#jnpar_threadread#threadread_log')->num2time($txt);
		
		$audurl=$_G['siteurl'].'plugin.php?id=jnpar_threadread:conv&aid='.$content['aid'].'&formhash='.FORMHASH;
		
		include template('jnpar_threadread:control');
		return $control;
	}
	
}

class  plugin_jnpar_threadread_forum extends  plugin_jnpar_threadread{
	function viewthread_posttop_output(){
		return $this->thread_handle();
	}

}

class  plugin_jnpar_threadread_portal extends plugin_jnpar_threadread{
	function view_article_top_output(){
		return $this->article_handle();
	}
}


class mobileplugin_jnpar_threadread{
		
	function discuzcode($value){
		global $_G,$post;
		$flag=C::t('#jnpar_threadread#threadread_log')->open_or_not();
		if(!$flag)return;
		
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false or strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false or strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false or strpos($_SERVER['HTTP_USER_AGENT'], 'MocuzApp') !== false){
			$inapp=1;
		}else{
			$inapp=0;
		}
		if(!$inapp)return;
		
		$tid=intval($_G['tid']);
		$pid=DB::result_first('select pid from '.DB::table('forum_post').' where first=1 and tid='.$tid);
		$audurl=$_G['siteurl'].'plugin.php?id=jnpar_threadread:conv&tid='.$tid.'&pid='.$pid;
		$control1='<div style="height:1px;background:red;"></div><audio controls><source src="'.$audurl.'"/></audio><div style="height:1px;background:red;"></div>';
		
		if($value['param'][12]==$pid){
			$_G['discuzcodemessage']=$control1.$_G['discuzcodemessage'];
		}
		
	}
}

class mobileplugin_jnpar_threadread_forum extends plugin_jnpar_threadread_forum {
	function viewthread_posttop_mobile_output(){
		return $this->thread_handle();
	}
}

class  mobileplugin_jnpar_threadread_portal extends plugin_jnpar_threadread_portal {
	function view_article_top_mobile_output(){
		return $this->article_handle();
	}
}
