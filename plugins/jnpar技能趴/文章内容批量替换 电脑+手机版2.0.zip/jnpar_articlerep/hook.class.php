<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class plugin_jnpar_articlerep{

	function open_or_not($cid){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_articlerep'];
		$uid=intval($_G['uid']);
		
		if($pvar['o2guest'] and !$uid) return 0;
		if(!$pvar['open_cids'])return 1;
		
		$opencids=explode(',',$pvar['open_cids']);
		if(in_array($cid,$opencids)){
			return 1;
		}
		return 0;
		
	}
}
class plugin_jnpar_articlerep_portal extends plugin_jnpar_articlerep{
	
	function list_output(){
//		global $_G,$list;
		return;
	}
	
	function view_article_top_output(){
		$open=$this->open_or_not();
		if(!$open)return;
		global $_G,$article,$content,$navtitle;
		$rep_arr=C::t('#jnpar_articlerep#jnpar_articlerep')->sresolve();
		
		$navtitle=str_replace($rep_arr[0],$rep_arr[1],$navtitle);
		$article['title']=str_replace($rep_arr[0],$rep_arr[1],$article['title']);
		$article['summary']=str_replace($rep_arr[0],$rep_arr[1],$article['summary']);
		$content['content']=str_replace($rep_arr[0],$rep_arr[1],$content['content']);
		
		return '';
	}
}

class mobileplugin_jnpar_articlerep  extends plugin_jnpar_articlerep{
	
}
class mobileplugin_jnpar_articlerep_portal extends plugin_jnpar_articlerep_portal{
	function view_article_top_mobile_output(){
		return $this->view_article_top_output();
	}
}
