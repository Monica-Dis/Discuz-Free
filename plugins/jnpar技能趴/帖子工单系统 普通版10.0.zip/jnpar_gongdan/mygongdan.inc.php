<?php

/*
 *	[DisM!] (C)2019-2020 DISM.Taobao.COM.
 *	Ӧ�ø���֧�֣�https://dism.taobao.com
 *  ���²����http://t.cn/Aiux1Jx1
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}


global $_G;
if(empty($_G['cache']['plugin'])){
	loadcache('plugin');
}
@extract($_G['cache']['plugin']['jnpar_gongdan']);
$ppp=15;
$page = max(1, intval($_GET['page']));
$uid=intval($_G['uid']);
$gongdan_fids=unserialize(stripslashes($gongdan_fids));

$extra="";
$count=DB::result_first("select count(*) from ".DB::table("forum_thread")." where authorid=".$uid." and ".DB::field('fid',$gongdan_fids)." and moderated=0");
$threads=C::t('forum_thread')->fetch_all_by_authorid_displayorder($uid,'','=','','',($page - 1) * $ppp, $ppp,null,$gongdan_fids,'>=','');
$pages=multi($count, $ppp, $page, "home.php?mod=spacecp&ac=plugin&id=jnpar_gongdan:mygongdan$extra");
if(checkmobile()){
	include template('jnpar_gongdan:mygongdan');
}


