﻿<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2018 by jnpar
|   http://www.jnpar.com
|   Support: QQ94526868
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：授权许可程序，此程序只授权于应用中心下载网站域名，私自修改文件将失去商业售后服务！
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_gongdan";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');
@unlink('source/plugin/'.$identify.'/upgrade.php');

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_gongdan_info`;
CREATE TABLE IF NOT EXISTS `pre_gongdan_info` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `status` tinyint(2) unsigned NOT NULL,
  `topublic` tinyint(1) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>