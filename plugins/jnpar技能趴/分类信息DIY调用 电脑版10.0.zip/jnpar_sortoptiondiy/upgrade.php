<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2018 by jnpar
|   http://www.jnpar.com
|   Support: QQ94526868
|   Please don't change the copyright, CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
|   ���棺��Ȩ���ɳ��򣬴˳���ֻ��Ȩ��Ӧ������������վ������˽���޸��ļ���ʧȥ��ҵ�ۺ����
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

EOF;


$identify="jnpar_sortoptiondiy";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');
@unlink('source/plugin/'.$identify.'/upgrade.php');
runquery($sql);

$finish = true;
?>