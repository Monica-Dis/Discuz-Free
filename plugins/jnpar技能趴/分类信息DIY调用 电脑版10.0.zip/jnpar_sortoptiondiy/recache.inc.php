<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . "./source/plugin/jnpar_sortoptiondiy/function.php";
if($_GET['does']!='recache'){
	showtableheader();
	showtitle(lang('plugin/jnpar_sortoptiondiy', 'recache1'));
	echo '<tr><td class="*">'.lang('plugin/jnpar_sortoptiondiy', 'recache2').'</td></tr>';
	showtablefooter(); /*DisM-Taobao_Com*/
	
	$html='<div style="margin-top:20px;margin-left:50px;"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jnpar_sortoptiondiy&pmod=recache&does=recache"><div name="button" class="btn" style="width:100px;text-align:center;">'.lang('plugin/jnpar_sortoptiondiy', 'recache3').'</div></a></div>';
	echo $html;
	
}else{
	recache();
	cpmsg(lang('plugin/jnpar_sortoptiondiy', 'recache4'),'action=plugins&operation=config&do='.$pluginid.'&identifier=jnpar_sortoptiondiy&pmod=recache','succeed');
}