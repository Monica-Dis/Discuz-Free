<?php
/*
 *	Copyright (c) 2020 by dism.taobao.com
 *	这不是一个免费的程序！由QQ：94526868提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站www.jnpar.com 辅助推广，敬请访问惠临。
 *	$_G['basescript'] = 模块名称
 *	CURMODULE = 为模块自定义常量
 */

$l = array(
	'error' => '您使用了盗版的应用',
);

?>