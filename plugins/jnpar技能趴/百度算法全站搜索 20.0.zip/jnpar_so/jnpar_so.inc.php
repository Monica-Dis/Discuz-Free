<?php

if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}


global $_G;	
if(empty($_G['cache']['plugin'])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin']['jnpar_so'];
$open_article=$pvar['open_article'];
$open_thread=$pvar['open_thread'];

$get=dhtmlspecialchars($_GET);
$searchtxt=$get['srchtxt'];
$maxlength=$pvar['text_maxlength'];//�����ȡ�ؼ��ʵ���󳤶�
if($get['formhash']!=FORMHASH or !$searchtxt){
	
	$thishour=date('d-H');
	loadcache('so_hour_flag');
	if(!$_G['cache']['so_hour_flag'] or $_G['cache']['so_hour_flag']!=$thishour){//ÿһ��Сʱ����һ��������ʷ���ݲ���
		$condition=' expiration <'.TIMESTAMP;
		DB::delete('so_searchlog',$condition);
		savecache('so_hour_flag',$thishour);
	}
	
}else{
	$hide_input=$pvar['hide_input'];
	$open_diy_list=$pvar['open_diy_list'];
	$pc_list_template=$pvar['pc_list_template'];
	$wap_list_template=$pvar['wap_list_template'];
	
	$inmobile=checkmobile();
	
	$word_interface=$pvar['word_interface']?$pvar['word_interface']:1;
	$exceptarr=explode('|',trim($pvar['except_wpos']));
	if($word_interface==1){
		$keywords_info = C::t('#jnpar_alicwords#jnpar_alicwords')->getcwords($searchtxt,$maxlength);
		$keywords_arr=$keywords_info['data'];
	}elseif($word_interface==2){
		$keywords_info = C::t('#jnpar_cwords#jnpar_cwords')->getcwords($searchtxt,$maxlength);
		$keywords_arr=$keywords_info['items'];
		
	}
	$keywords=C::t('#jnpar_so#so_searchlog')->validwords($keywords_arr,$exceptarr,$word_interface);
	
	$searchfrom=intval($get['searchfrom']);
	$searchtype=intval($get['searchtype']);
	
	$page=max(1,intval($_GET['page']));
	$pagesize=$pvar['pagesize'];
	$begin=($page-1)*$pagesize;
	$infid=intval($_GET['infid']);
	$sresults=C::t('#jnpar_so#so_searchlog')->getsearchresults($keywords,$searchfrom,$searchtype,$infid,$begin,$pagesize);
	$pageadd="&searchtype=".$searchtype."&searchfrom=".$searchfrom."&srchtxt=".urlencode($_GET['srchtxt'])."&infid=".$_GET['infid']."&searchsubmit=true";
	$pagenav=multi($sresults['fidnum'][$infid]['num']?$sresults['fidnum'][$infid]['num']:$sresults['listcount'],$pagesize,$page,'plugin.php?id=jnpar_so&formhash='.FORMHASH.$pageadd);
	
	
	if($open_diy_list){
		$list_template=$inmobile?$wap_list_template:$pc_list_template;
		foreach($sresults['list'] as $k=>$v){
			$cover=$v['cover'];
			$url=$v['url'];
			$fromid=$v['fid'];
			$fname=$v['fname'];
			$title=$v['title'];
			$lhtitle=C::t('#jnpar_so#so_searchlog')->hightlightwords($v['title'],$keywords);
			$author=$v['author'];
			$authorid=$v['authorid'];
			$summary=$v['summary'];
			$viewnum=$v['views'];
			$date=dgmdate($v['dateline'],'d');
			$fromurl=$v[from]==1?"forum.php?mod=forumdisplay&fid=".$fromid:"portal.php?mod=list&catid=".$fromid;
			$list[$k]=str_replace(array('{cover}','{url}','{fromid}','{fname}','{title}','{lhtitle}','{author}','{authorid}','{summary}','{date}','{fromurl}','{viewnum}'),array($cover,$url,$fromid,$fname,$title,$lhtitle,$author,$authorid,$summary,$date,$fromurl,$viewnum),$list_template);
		}
	}
	
	$searchview_open=$pvar['searchview_open'];
	if($searchview_open){
		$mod=$searchfrom=='1000'?'forum':($searchfrom=='1100'?'portal':'');
		C::t('#jnpar_searchview#searchview_log')->insertlog($searchtxt,$sresults['listcount'],$mod);
	}
	
}

include template("diy:index",0,'source/plugin/jnpar_so/template');






