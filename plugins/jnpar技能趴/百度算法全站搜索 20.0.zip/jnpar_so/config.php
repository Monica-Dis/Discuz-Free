<?php


 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

$theplugin='umcenter';
$thepath="source/plugin/".$theplugin."/";
$thestaticpath=$thepath."static/";
$theimgpath=$thestaticpath."imgs/";
$thecsspath=$thestaticpath."css/";
$thejspath=$thestaticpath."js/";
$thefuncpath=$thepath."function/";
$theclasspath=$thepath."class/";

require_once $theclasspath."basic.class.php";

global $_G;
if(empty($_G['cache']['plugin'])){
	loadcache('plugin');
}
$setvar=$_G['cache']['plugin'][$theplugin];

@extract($setvar);


$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
$uname=$_G['username'];

$vip_groups=unserialize($vip_groups);


