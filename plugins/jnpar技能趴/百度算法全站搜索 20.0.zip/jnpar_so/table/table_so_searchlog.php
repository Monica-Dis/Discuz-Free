<?php
/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism��taobao��com �����ƹ㣬������ʻ��١�
 *	���²����http://t.cn/Aiux1Jx1
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_so_searchlog extends discuz_table
{
	public function __construct() {
		$this->_table = 'so_searchlog';
		$this->_pk    = '';
		parent::__construct(); /*dism - taobao - com*/
	}
	
	public function have_chinese($str){
		if (preg_match("/[\x7f-\xff]/", $str)) {//�ж��ַ������Ƿ�������,����gb2312��utf8
			return true;
		} else {
			return false;
		}
	}
	
	public function validwords($arr,$exceptarr,$word_interface){
		$r=array();
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		$ex_word=$pvar['ex_word'];
			
		foreach($arr as $k=>$v){
			if(!$v['pos'] or ($v['pos'] && !empty($exceptarr) && in_array($v['pos'],$exceptarr)))continue;
			if($ex_word and strlen(bin2hex(trim($v['word'])))<=2 and strlen(bin2hex(trim($v['item'])))<=2)continue;
			if($ex_word==2 and ($this->have_chinese($v['word']) or $this->have_chinese($v['item'])) and strlen(bin2hex(trim($v['word'])))<=4 and strlen(bin2hex(trim($v['item'])))<=4)continue;
			$r[]=$word_interface==2?$v['item']:$v['word'];
		}
		return $r;
	}
	
	public function getsearchresults($keywords,$searchfrom,$searchtype,$infid,$begin,$length) {
		//searchfrom:1ȫ����������顢���ӺͲ������1000��̳���ӣ�1100���£�1200-1299������ݣ�2-999�����İ�����ݣ����ֶ��ڰ��ID��;1101-1199��������
		//$searchtype:1���⣻2���ߣ�3��ǩ��4���ģ����飩��0ȫ������
		
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		$openfids=unserialize($pvar['open_fids']);
		$limitnum=$pvar['limitnum'];
		if($limitnum)$limitstr=" limit ".intval($limitnum);
		
		$sgidset=$this->getsgid_fids();
		//debug($sgidset);
		if($sgidset[0]){
			$openfids=array_intersect($openfids,$sgidset[1]);
		}
		
		$open_article=$pvar['open_article'];
		$open_thread=$pvar['open_thread'];
		$allow_text=$pvar['allow_text'];
		$cover_gway=$pvar['cover_gway'];
		
		if(empty($keywords)){
			return;
		}
		asort($keywords);//�Թؼ�������
		$keywords_str=implode('+',$keywords);
		
		$searchlog=DB::fetch_first("select * from %t where expiration>=".TIMESTAMP." and keywords=%s and searchfrom=%d and searchtype=%d and sgid=%d",array($this->_table,$keywords_str,$searchfrom,$searchtype,$sgidset[0]));
		$sid=$searchlog['sid'];
		$ids=$searchlog['ids'];
		$tids=$searchlog['tids']?$searchlog['tids']:0;
		$ids1=$searchlog['ids1']?$searchlog['ids1']:0;
		
		$return=array();
		if(!$sid){
			if($allow_text){
				$alltxt1=array('t_b.subject','t_b.author','t_b.tags','t_b.message');
				$alltxt2=array('t_a.title','t_a.username','t_a.author','t_b.content');	
			}else{
				$alltxt1=array('t_b.subject','t_b.author','t_b.tags');
				$alltxt2=array('t_a.title','t_a.username','t_a.author');
			}
			
			$where1=$this->get_where($keywords,$alltxt1);
			$order1=$this->get_order($keywords,$alltxt1);
			
			
			$where2=$this->get_where($keywords,$alltxt2);
			$order2=$this->get_order($keywords,$alltxt2);
			
			$use1=($open_thread and ($searchfrom==1 or $searchfrom==1000))?1:0;
			$use2=($open_article and ($searchfrom==1 or $searchfrom==1100))?1:0;
			
			$lists1=$use1==1?DB::fetch_all("select distinct t_b.tid,t_b.dateline, ".$order1." as keyweight from  ".DB::table('forum_post')." as t_b where t_b.first=1 and t_b.invisible=0 and t_b.".DB::field('fid',$openfids)." and ".$where1." group by t_b.tid order by t_b.tid DESC".$limitstr):array();
			
			if($allow_text){//������
				$lists2=$use2==1?DB::fetch_all("select distinct t_a.aid,t_a.dateline, ".$order2." as keyweight  from ".DB::table('portal_article_title')." as t_a LEFT OUTER JOIN ".DB::table('portal_article_content')." as t_b ON t_a.aid=t_b.aid where ".$where2." group by t_a.aid  order by t_a.dateline DESC".$limitstr):array();
			}else{//��������
				$lists2=$use2==1?DB::fetch_all("select distinct t_a.aid,t_a.dateline, ".$order2." as keyweight  from ".DB::table('portal_article_title')." as t_a where ".$where2." group by t_a.aid  order by t_a.dateline DESC".$limitstr):array();
			}
			
			
			$list3=$list4=array();//Ԥ��������չ�ӿ�,������������������ݵĹ��ܣ�����ϵQQ9452-6868
			$listsinfo= $this->merge_and_order($lists1,$lists2,$lists3,$lists4);
			
			$listn=$listsinfo['list'];
			$searcharr=array($keywords_str,$searchfrom,$searchtype,$_G['clientip'],$_G['uid']);
			
			$this->insertlog($lists1,$lists2,$lists3,$lists4,$listn,$searcharr);
			dheader('Location:'."plugin.php?id=jnpar_so&formhash=".FORMHASH."&searchfrom={$_GET[searchfrom]}&srchtxt={$_GET[srchtxt]}");
		}else{
			$listcount=$searchlog['num'];
			if($cover_gway){
				$lists1=DB::fetch_all("select t_a.tid,t_a.fid,t_a.subject,t_a.author,t_a.authorid,t_a.dateline,t_a.views,t_b.message from %t as t_a LEFT OUTER JOIN %t  as t_b ON t_a.tid=t_b.tid and t_b.first=1 where t_a.tid IN (".$tids.")",array('forum_thread','forum_post'));
			}else{
				$lists1=DB::fetch_all("select t_a.tid,fid,subject,author,authorid,dateline,views,t_b.attachment from %t as t_a LEFT OUTER JOIN %t  as t_b ON t_a.tid=t_b.tid where t_a.tid IN (".$tids.")",array('forum_thread','forum_threadimage'));
			}
			$lists2=DB::fetch_all("select t_a.aid,t_a.summary, t_a.title,t_a.catid,username,t_a.uid,t_a.dateline from %t as t_a where t_a.aid IN (".$ids1.")",array('portal_article_title'));

			$list2=$list3=$list4=array();//Ԥ����չ�ӿ�,������������������ݵĹ��ܣ�����ϵQQ9452-6868
			$ids_arr=$this->ids_toarr($ids);
			
			$listsinfo=$this->merge_by_key($lists1,$lists2,$lists3,$lists4,$ids_arr);
		}
		$return['allcount']=$listsinfo['listcount'];
		$return['fidnum']=$this->getnum_fids($listsinfo['list']);
		if($infid){
			$listsinfo=$this->getlistsinfo_by_fid($listsinfo,$infid);
		}
		$return['listcount']=$listsinfo['listcount'];
		$return['list']=array_slice($listsinfo['list'],$begin,$length);
		return $return;
	}
	
	public function hightlightwords($str,$words){
		if(empty($words)){
			return $str;
		}else{
			foreach($words as $v){
				$str=str_replace($v,"<font style='color: red;background-color: #EBF936;'><b>$v</b></font>",$str);
			}
		}
		return $str;
	}
	
	public function get_order($words,$fields){
        $order_str='';
        foreach ($words as $k => $v) {
			foreach($fields as $j=>$f){
				$order_str.=" + (CASE WHEN $f like '%".$v."%' THEN ".(10-2*$j)." ELSE 0 END)";
			}
        }
        $order_str="(".substr($order_str,2).")";
 
        return $order_str;
    }
	
	public function get_where($words,$fields){
		$where='';
		$field_str='';
		if(sizeof($fields)==1){
			$field_str=$fields[0];
		}else{
			$field_str="CONCAT_WS(' ',".implode(',',$fields).")";
		}
		foreach ($words as $k => $v) {
			if(empty($where)){
				$where.=" $field_str LIKE '%".$v."%'";
			}else{
				$where.=" OR $field_str LIKE '%".$v."%'";
			}
		}
		return '('.$where.')';
	}
	
	public function getnum_fids($arr){
		$r=array();
		//debug($arr);
		$fblocks=$this->getfblocks();
		
		if(empty($fblocks)){		
			foreach($arr as $v){
				$r[$v['fid']]['num']=intval($r[$v['fid']]['num'])+1;
				$r[$v['fid']]['fname']=$v['fname'];
			}
		}else{
			foreach($arr as $v){
				foreach($fblocks as $k=>$fb){
					if(in_array($v['fid'],$fb[2])){
						$r[$fb[0]]['num']=intval($r[$fb[0]]['num'])+1;
						$r[$fb[0]]['fname']=$fb[1];
					}
				}
			}
		}
		return $r;
	}
	
	public function getfblocks(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		
		$set=trim($pvar['fblocks']);
		
		if(!$set)return array();
		
		$arr1=explode(PHP_EOL,$set);
		
		$return=array();
		foreach($arr1 as $a){
			if(!trim($a))continue;
			$temp=explode('|',trim($a));
			$temp1=explode(',',trim($temp[2]));
			$return[$temp[0]]=array($temp[0],$temp[1],$temp1);
		}
		return $return;
	}
	
	public function ids_toarr($ids){
		$arr=explode(',',$ids);
		$result=array();
		foreach($arr as $k=>$v){
			$temp1=substr($v,0,1);
			$temp2=substr($v,1);
			$result[$v]=array($temp1,$temp2);
		}
		return $result;
	}
	
	public function get_purl_text($str){
		$txt=strip_tags($str);
		$txt=preg_replace('/\[([\/a-zA-Z]+?)(.*?)\](.*?)\[\/(.+?)\]/','',$txt);
		//$txt=preg_replace('/\[([\/a-zA-Z]+?)(.*?)\]/','',$txt);//�������е�bbcode��ǩ�Լ����ܵĲ����ǩ
		
		$txt=str_replace('&nbsp;',' ',$txt);		
		return $txt;
	}
	
	public function merge_by_key($arr1,$arr2,$arr3,$arr4,$ids_arr){//arr1�������ӱ���arr2�������±����������Բ����
		
		$n1=intval(sizeof($arr1));
		$n2=intval(sizeof($arr2));
		$n3=intval(sizeof($arr3));
		$n4=intval(sizeof($arr4));
		$r=array();
		
		$tarr=$v1arr=array();
		foreach($arr1 as $k=>$v){
			$tarr[$v['tid']]=$v;//�˴�tid��Ҫ����ʵ����������
		}
		foreach($arr2 as $k=>$v){
			$v1arr[$v['aid']]=$v;//�˴�aid��Ҫ����ʵ����������
		}
		$v2arr=$v3arr=array();//Ԥ���ӿ�,������������������ݵĹ��ܣ�����ϵQQ9452-6868
		
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		$openfids=unserialize($pvar['open_fids']);
		$fnames=C::t('forum_forum')->fetch_all_name_by_fid($openfids);
		$catnames=C::t('portal_category')->range();
		$cover_gway=$pvar['cover_gway'];
		$sublength=200;
		
		$tids=$this->_array_column($arr1,'tid');
		$covers1=$this->gettcovers($tids);
			
		$aids=$this->_array_column($arr2,'aid');
		$covers2=$this->getacovers($aids);
		
		$i=0;
		foreach($ids_arr as $k=>$v){
			if($v[0]=='a'){//����
				$r[$i]['from']=1;
				$r[$i]['id']=$tarr[$v[1]]['tid'];
				$r[$i]['title']=$tarr[$v[1]]['subject'];
				$r[$i]['views']=$tarr[$v[1]]['views'];
				$r[$i]['author']=$tarr[$v[1]]['author'];
				$r[$i]['authorid']=$tarr[$v[1]]['authorid'];
				$r[$i]['dateline']=$tarr[$v[1]]['dateline'];
				$r[$i]['fid']=$tarr[$v[1]]['fid'];
				//$message=$this->get_purl_text($tarr[$v[1]]['message']);
				$message=$tarr[$v[1]]['message'];
				include_once libfile('function/post');
				$r[$i]['summary']=messagecutstr($message, $sublength);
				$r[$i]['fname']=$fnames[$tarr[$v[1]]['fid']]['name'];//�������
				if($cover_gway==1){
					$r[$i]['cover']=$this->threadcover($tarr[$v[1]]['tid']);
				}elseif($cover_gway==2){
					$r[$i]['cover']=$covers1[$tarr[$v[1]]['tid']];
				}else{
					$r[$i]['cover']=$tarr[$v[1]]['attachment']?'data/attachment/forum/'.$tarr[$v[1]]['attachment']:'source/plugin/jnpar_so/imgs/nopic.png';
				}
				$r[$i]['url']='forum.php?mod=viewthread&tid='.$tarr[$v[1]]['tid'];
				
			}elseif($v[0]=='b'){
				$r[$i]['from']=2;
				$r[$i]['id']=$v1arr[$v[1]]['aid'];
				$r[$i]['title']=$v1arr[$v[1]]['title'];
				$r[$i]['views']=$v1arr[$v[1]]['viewnum'];
				$r[$i]['author']=$v1arr[$v[1]]['username'];
				$r[$i]['authorid']=$v1arr[$v[1]]['uid'];
				$r[$i]['dateline']=$v1arr[$v[1]]['dateline'];
				$r[$i]['fid']=1100+$v1arr[$v[1]]['catid'];
				$r[$i]['summary']=$v1arr[$v[1]]['summary'];
				$r[$i]['fname']=$catnames[$v1arr[$v[1]]['catid']]['catname'];//�������
				$r[$i]['cover']=$covers2[$v1arr[$v[1]]['aid']]?'data/attachment/portal/'.$covers2[$v1arr[$v[1]]['aid']]:'source/plugin/jnpar_so/imgs/nopic.png';
				$r[$i]['url']='portal.php?mod=view&aid='.$v1arr[$v[1]]['aid'];
			}elseif($v[0]=='c'){
				//�ӿ�3��ֵ,������������������ݵĹ��ܣ�����ϵQQ9452-6868
			}elseif($v[0]=='d'){
				//�ӿ�4��ֵ,������������������ݵĹ��ܣ�����ϵQQ9452-6868
			}
			$i++;
		}
		//debug($r);
		$return['listcount']=$n1+$n2+$n3+$n4;
		$return['list']=$r;
		
		return $return;
	}
	
	public function gettcover($tid){
		$message=DB::result_first('select message from '.DB::table('forum_post').' where tid=%d and first=1',array($tid));
		$message=str_replace('[img]static/image/hrline/1.gif[/img]','',$message);
		preg_match_all('/\[img\](.*?)\[\/img\]/',$message,$imgs);
		//$n=sizeof($imgs[1])-1;
		$cover=$imgs[1][0]?$imgs[1][0]:'source/plugin/jnpar_so/imgs/nopic.png';
		return $cover;
	}
	
	public function gettcovers($tids){
		$messages=DB::fetch_all('select tid,message from %t where %i and first=1',array('forum_post',DB::field('tid',$tids)));
		foreach($messages as $v){
			$message=str_replace('[img]static/image/hrline/1.gif[/img]','',$v['message']);
			preg_match_all('/\[img\](.*?)\[\/img\]/',$message,$imgs);
			$cover=$imgs[1][0]?$imgs[1][0]:'source/plugin/jnpar_so/imgs/nopic.png';
			
			$covers[$v['tid']]=$cover;
		}
		
		return $covers;
	}
		
	public function merge_and_order($arr1,$arr2,$arr3,$arr4){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		$openfids=unserialize($pvar['open_fids']);
		$cover_gway=$pvar['cover_gway'];
		$fnames=C::t('forum_forum')->fetch_all_name_by_fid($openfids);
		$catnames=C::t('portal_category')->range();
		
		$aids=$this->_array_column($arr2,'aid');
		$covers2=$this->getacovers($aids);
		
		$narr=$narr1=$narr2=array();
		$i=0;
		foreach($arr1 as $v){//����
			$r[$i]['from']=1;
			$r[$i]['id']=$v['tid'];
			$r[$i]['weight']=$v['keyweight'];
			
			$keyweigh_arr[]=$v['keyweight'];
			$dateline_arr[]=$v['dateline'];
			$i++;
		}
		foreach($arr2 as $v){
			$r[$i]['from']=2;
			$r[$i]['id']=$v['aid'];
			
			$keyweigh_arr[]=$v['keyweight'];
			$dateline_arr[]=$v['dateline'];
			$i++;
		}
		
		foreach($arr3 as $v){
			//�ӿ�3��ֵ,������������������ݵĹ��ܣ�����ϵQQ9452-6868
		}
		
		foreach($arr4 as $v){
			//�ӿ�4��ֵ,������������������ݵĹ��ܣ�����ϵQQ9452-6868
		}
		
		array_multisort($keyweigh_arr,SORT_NUMERIC,SORT_DESC,$dateline_arr,SORT_NUMERIC,SORT_DESC,$r);
		
		$return['listcount']=sizeof($r)?sizeof($r):0;
		$return['list']=!empty($r)?$r:array();
		
		return $return;
	}
	
	public function insertlog($lists1,$lists2,$lists3,$lists4,$listn,$searcharr){
		$tids_arr=$ids1_arr=$ids_arr=array();
		foreach($lists1 as $k=>$v){
			$tids_arr[$k]=$v['tid'];//�˴�tid��Ҫ����ʵ����������
		}
		foreach($lists2 as $k=>$v){
			$ids1_arr[$k]=$v['aid'];//�˴�aid��Ҫ����ʵ����������
		}
		$ids2_arr=$ids3_arr=array();//Ԥ����������ӿ�,������������������ݵĹ��ܣ�����ϵQQ9452-6868
		foreach($listn as $k=>$v){
			if($v['from']==1){
				$ids_arr[$k]='a'.$v['id'];
			}elseif($v['from']==2){
				$ids_arr[$k]='b'.$v['id'];
			}elseif($v['from']==3){
				$ids_arr[$k]='c'.$v['id'];
			}elseif($v['from']==4){
				$ids_arr[$k]='d'.$v['id'];
			}
		}
		$tids=implode(',',$tids_arr);
		$ids1=implode(',',$ids1_arr);
		$ids2=implode(',',$ids2_arr);
		$ids3=implode(',',$ids3_arr);
		
		$ids=implode(',',$ids_arr);
		
		$sgidset=$this->getsgid_fids();
		$data=array(
			'keywords'=>$searcharr[0],
			'sgid'=>$sgidset[0],
			'searchfrom'=>$searcharr[1],
			'searchtype'=>$searcharr[2],
			'useip'=>$searcharr[3],
			'uid'=>$searcharr[4],
			'dateline'=>TIMESTAMP,
			'expiration'=>TIMESTAMP+3600,
			'num'=>sizeof($lists3),
			'ids'=>$ids,
			'tids'=>$tids,
			'ids1'=>$ids1,
			'ids2'=>$ids2,
			'ids3'=>$ids3,
		);
		DB::insert('so_searchlog',$data);
	}
	
	public function getlistsinfo_by_fid($listsinfo,$infid){
		$list=$listsinfo['list'];
		$newlist=array();
		
		$fblocks=$this->getfblocks();
		if(empty($fblocks)){
			foreach($list as $v){
				if($v['fid']!=$infid)continue;
				$newlist[]=$v;
			}			
		}else{
			foreach($list as $v){
				if(in_array($v[fid],$fblocks[$infid][2])){
					$newlist[]=$v;
				}
			}
		}
		$return['listcount']=sizeof($newlist);
		$return['list']=$newlist;
		return $return;
	}
	
	public function getacovers($aids){
		$atts=DB::fetch_all('select DISTINCT aid,attachment from '.DB::table('portal_attachment').' where isimage=1 and '.DB::field('aid',$aids));
		if(function_exists('array_column')){
			$r=array_column($atts,'attachment','aid');
		}else{
			$r=$this->_array_column($atts,'attachment','aid');
		}
		return $r;
	}
	
	public function threadcover($tid){
		//debug($tid);
		$str=md5($tid);
		$path1=substr($str,0,2);
		$path2=substr($str,2,2);
		$path='data/attachment/forum/threadcover/'.$path1.'/'.$path2.'/'.$tid.'.jpg';
		//$cover=file_exists($path)?$path:'source/plugin/jnpar_so/imgs/nopic.png';
		$cover=$path;
		return $cover;
	}
	
	public function _array_column(array $array, $column_key, $index_key=null){
		$result = array();
		foreach($array as $arr) {
			if(!is_array($arr)) continue;

			if(is_null($column_key)){
				$value = $arr;
			}else{
				$value = $arr[$column_key];
			}

			if(!is_null($index_key)){
				$key = $arr[$index_key];
				$result[$key] = $value;
			}else{
				$result[] = $value;
			}
		}
		return $result; 
	}
	
	public function getsgid_fids(){
		global $_G;
		$agidset=$this->sgidset_2_arr();
		$gid=$_G['groupid'];
		$return=array(0,0);
		if(empty($agidset))return 0;
		//debug($gid);
		foreach($agidset as $k=>$v){
			if(in_array($gid,$v[1])){
				$return[0]=$v[0];//sgid
				$return[1]=$v[2];//���ids
				break;
			}
		}
		
		return $return;
	}
	
	public function sgidset_2_arr(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_so'];
		$sgid_set=$pvar['sgid_set'];
		if(!$sgid_set)return array();
		
		$arr1=explode(PHP_EOL,$sgid_set);
		foreach($arr1 as $k=>$v){
			$arr2=explode('|',$v);
			$arr3[$k][0]=$arr2[0];
			$arr3[$k][1]=explode(',',$arr2[1]);
			$arr3[$k][2]=explode(',',$arr2[2]);
		}
		//debug($arr3);
		return $arr3;
	}
}
//From: Dism_taobao-com
?>