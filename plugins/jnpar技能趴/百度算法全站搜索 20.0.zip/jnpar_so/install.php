<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!应用中心.
|   http://dism·taobao·com
|   Support: DisM.Taobao-Com
|   Please don't change the copyright, From: DisM.taobao.Com
|   本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_so";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_so_searchlog` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sgid` tinyint(3) unsigned NOT NULL,
  `searchtype` tinyint(3) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `searchstring` varchar(100) NOT NULL,
  `useip` varchar(30) NOT NULL,
  `uid` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  `expiration` int(10) NOT NULL,
  `searchfrom` smallint(5) NOT NULL,
  `num` int(10) NOT NULL,
  `ids` text NOT NULL,
  `tids` text NOT NULL,
  `ids1` text NOT NULL,
  `ids2` text NOT NULL,
  `ids3` text NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `keywords` (`keywords`),
  KEY `searchfrom` (`searchfrom`),
  KEY `searchtype` (`searchtype`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>