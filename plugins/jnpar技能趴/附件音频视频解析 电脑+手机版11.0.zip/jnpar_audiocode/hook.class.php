<?php

/*
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����dism.taobao.com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վDISM.TAOBAO.COM �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

class plugin_jnpar_audiocode{

}

class plugin_jnpar_audiocode_forum extends plugin_jnpar_audiocode  {
	
	function viewthread_top_output(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_audiocode'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$adscrollcon=$pvar['ad_scrollcon'];
		$adscrollurl=$pvar['ad_scrollurl'];
		
		if(!in_array($fid,$openfids)){
			return;
		}
		
		include template('jnpar_audiocode:pubcode');
		return $html;
	}
	
	function viewthread_postbottom_output() {
		global $_G, $postlist;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_audiocode'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$vidio_exts=$pvar['vidio_exts'];
		$vidioexts=explode('|',$vidio_exts);
		$audio_exts=$pvar['audio_exts'];
		$audioexts=explode('|',$audio_exts);
		$vidiocover=$pvar['vidio_cover'];
		$test_secends=$pvar['test_secends'];
		$vipgids=unserialize($pvar['vip_gids']);
		$rticon=$pvar['rticon'];
		$vwidth=$pvar['vwidth'];
		$vheight=$pvar['vheight'];
		$open_h5=$pvar['open_h5'];
		$open_attach=$pvar['open_attach'];
		$open_DES=$pvar['open_DES'];
		$hide_down=$pvar['hide_down'];
		//$open_attach=$open_h5;
		
		//debug($open_attach);
		
		if(!in_array($fid,$openfids)){
			return;
		}
		$isvip=0;
		if(in_array($_G['groupid'],$vipgids)){
			$isvip=1;
		}
		foreach($postlist as $id => $p) {//����ÿ��¥��
			//$preg='/<ignore_js_op>([\s\S]+?)<a href=\"(.+?)\"([\s\S]+?)<div class=\"tip_horn\"><\/div>([\s\S]+?)<\/ignore_js_op>/';
			$preg='/<ignore_js_op>([\s\S]{1,5})<img src([\s\S]+?)<a href=\"(.+?)\"([\s\S]+?)<div class=\"tip_horn\"><\/div>([\s\S]+?)<\/ignore_js_op>/';
			$mes=$p['message'];
			preg_match_all($preg,$mes,$htmlcode);
			$attaches=$p['attachments'];
			$k=0;
			
			foreach($attaches as $ak=>$attach){//����¥���е�ÿ������
				if(in_array($attach['ext'],$vidioexts)){//��Ƶ�ļ�����
					$price=$attach['price'];
					$payed=$attach['payed'];
					if((!$payed && $price && $_G['uid']) or ($payed && $price && !$_G['uid']) or ($open_attach==1)){
						$attach_url=$_G['siteurl'].$attach['url'].$attach['attachment'];
//debug($attach_url);
					}else{
						$attach_url_preg=$_G['siteurl'].$htmlcode[3][$k];
						$attach_url=str_replace('&amp;','&',$attach_url_preg);
//debug($attach_url.'aaaa');
					}
					$deskey='ckplayerDesKey';//�˴�Ϊckplayer���ü���key����������˽�м���key�����Կ�������Ӧ�޸ġ�����˵����http://www.ckplayer.com/manualX/68.html
					if($open_DES)$attach_url=C::t('#jnpar_audiocode#jnpar_audiocode')->encryptForDES($attach_url,$deskey);

					$filename=$attach['filename'];
					$playerid=rand(100000,999999);
					include template('jnpar_audiocode:playcode');
					$mes=$hide_down?str_replace($htmlcode[0][$k],$html0,$mes):str_replace($htmlcode[0][$k],$htmlcode[0][$k].$html0,$mes);
				}elseif(in_array($attach['ext'],$audioexts)){//��Ƶ�ļ�����
					$attach_url_preg=$_G['siteurl'].$htmlcode[3][$k];
					$attach_url=str_replace('&amp;','&',$attach_url_preg);
					$filename=$attach['filename'];
					$price=$attach['price'];
					$payed=$attach['payed'];
					include template('jnpar_audiocode:playcode');
					$mes=$hide_down?str_replace($htmlcode[0][$k],$html1,$mes):str_replace($htmlcode[0][$k],$htmlcode[0][$k]."<br/>".$html1,$mes);
				}
				$k++;
			}
			$postlist[$id]['message'] = $mes;
		}
		return;
	}
}

class mobileplugin_jnpar_audiocode{

}

class mobileplugin_jnpar_audiocode_forum extends mobileplugin_jnpar_audiocode  {
	
	function viewthread_top_mobile_output(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_audiocode'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$adscrollcon=$pvar['ad_scrollcon'];
		$adscrollurl=$pvar['ad_scrollurl'];
		
		if(!in_array($fid,$openfids)){
			return;
		}
		
		include template('jnpar_audiocode:pubcode');
		return $html;
	}
	
	function viewthread_postbottom_mobile_output() {
		global $_G, $postlist;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_audiocode'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$vidio_exts=$pvar['vidio_exts'];
		$vidioexts=explode('|',$vidio_exts);
		$audio_exts=$pvar['audio_exts'];
		$audioexts=explode('|',$audio_exts);
		$vidiocover=$pvar['vidio_cover'];
		$test_secends=$pvar['test_secends'];
		$vipgids=unserialize($pvar['vip_gids']);
		$rticon=$pvar['rticon'];
		$vwidth=$pvar['vwidth'];
		$vheight=$pvar['vheight'];
		$tipcon=$pvar['tipcon'];
		$open_h5=$pvar['open_h5'];
		$open_attach=$pvar['open_attach'];
		$open_DES=$pvar['open_DES'];
		$hide_down=$pvar['hide_down'];
		
		if(!in_array($fid,$openfids)){
			return;
		}
		$isvip=0;
		if(in_array($_G['groupid'],$vipgids)){
			$isvip=1;
		}

		foreach($postlist as $id => $p) {//����ÿ��¥��
			$preg='/<div id=\"attach_([\s\S]+?)<a href=\"(.*?)\"([\s\S]+?)<\/div>/';
			$mes=$p['message'];
			preg_match_all($preg,$mes,$htmlcode);
			$attaches=$p['attachments'];
			
			$k=0;
			foreach($attaches as $ak=>$attach){//����¥���е�ÿ������
				if(in_array($attach['ext'],$vidioexts)){//��Ƶ�ļ�����
					$price=$attach['price'];
					$payed=$attach['payed'];
					if((!$payed && $price && $_G['uid']) or ($payed && $price && !$_G['uid']) or ($open_attach==1)){
						$attach_url=$_G['siteurl'].$attach['url'].$attach['attachment'];
					}else{
						$attach_url_preg=$_G['siteurl'].$htmlcode[2][$k];
						$attach_url=str_replace('&amp;','&',$attach_url_preg);
					}
					
					$filename=$attach['filename'];
					$playerid=rand(100000,999999);
					include template('jnpar_audiocode:playcode');
					$mes=$hide_down?str_replace($htmlcode[0][$k],$html0,$mes):str_replace($htmlcode[0][$k],$htmlcode[0][$k].$html0,$mes);
				}elseif(in_array($attach['ext'],$audioexts)){//��Ƶ�ļ�����
					$attach_url=$_G['siteurl'].$htmlcode[2][$k];
					$filename=$attach['filename'];
					$price=$attach['price'];
					$payed=$attach['payed'];
					include template('jnpar_audiocode:playcode');
					$mes=$hide_down?str_replace($htmlcode[0][$k],$html1,$mes):str_replace($htmlcode[0][$k],$htmlcode[0][$k]."<br/>".$html1,$mes);
				}
				$k++;
			}
			$postlist[$id]['message'] = $mes;
		}
		return;
	}
}