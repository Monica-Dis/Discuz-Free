<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_jnpar_https{
	function is_https() {
		if ( !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
			return true;
		} elseif ( isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) {
			return true;
		} elseif ( !empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) !== 'off') {
			return true;
		} elseif ($_SERVER['SERVER_PORT'] == 443){
			return true;
		}
		return false;
	}
	
	function open_or_not(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_https'];
		$open_multi=$var['open_multi'];
		$domains=explode(PHP_EOL,trim($var['domains']));
		
		$visitdomian=$_SERVER['HTTP_HOST'];
		if($open_multi && !in_array($visitdomian,$domains)){
			return 0;
		}
		return 1;
	}
	
	function global_header(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$v1=lang('plugin/jnpar_https','v1');
		$var=$_G['cache']['plugin']['jnpar_https'];
		$todomain=$var['todomain']?$var['todomain']:$_SERVER["HTTP_HOST"];
		
		$flag=$this->open_or_not();
		if(!flag)return;
		$inhttps=$this->is_https();
		if(!$inhttps){
			$url='https://'.$todomain.$_SERVER["REQUEST_URI"]; 
			header('HTTP/1.1 301 Moved Permanently');
			header('Location: '.$url);
			exit();
		}
		return;
	}
}

class mobileplugin_jnpar_https extends plugin_jnpar_https{
	function global_header_mobile(){
		return $this->global_header();
	}
}