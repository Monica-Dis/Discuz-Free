<?php

/*
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

class plugin_jnpar_viewrecord{
	function global_myitem_extra(){
		$html='<a href="home.php?mod=spacecp&ac=plugin&id=jnpar_viewrecord:myrecord" style="color:red;">'.lang('plugin/jnpar_viewrecord', 'h1').'</a>';
		return $html;
	}
	function open_or_not(){
		global $_G;
		$gid=$_G['groupid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_viewrecord'];
		$opengids=unserialize($var['open_gids']);
		if(in_array($gid,$opengids)){
			return true;
		}else{
			return false;
		}
	}
}


class plugin_jnpar_viewrecord_forum extends plugin_jnpar_viewrecord {	
	function viewthread_top_output(){
		$flag=$this->open_or_not();
		if(!$flag)return;
		global $thread,$_G;
		if(!$_G['uid'])return;
		$data=array();
		$data['type']='tid';
		$data['id']=$thread['tid'];
		$data['title']=$thread['subject'];
		$data['dateline']=TIMESTAMP;
		$data['uid']=$_G['uid'];
		$data['uname']=$_G['username'];
		C::t('#jnpar_viewrecord#viewrecord_log')->imprecord($data);
		return;
	}
	
	function viewthread_modaction_output(){
		$flag=$this->open_or_not();
		if(!$flag)return;
		global $thread,$_G;
		$data = DB::fetch_all("select uname,uid from %t where id = %d",
			array(
				"viewrecord_log",$thread['tid']
			)
	    );
		// debug($thread['tid']);
	    include template('jnpar_viewrecord:ulist');
	    return $ulist;
	   
	}
}

class plugin_jnpar_viewrecord_portal extends plugin_jnpar_viewrecord {	
	function view_article_top_output(){
		$flag=$this->open_or_not();
		if(!$flag)return;
		global $article,$_G;
		if(!$_G['uid'])return;
		$data=array();
		$data['type']='aid';
		$data['id']=$article['aid'];
		$data['title']=$article['title'];
		$data['dateline']=TIMESTAMP;
		$data['uid']=$_G['uid'];
		$data['uname']=$_G['username'];
		C::t('#jnpar_viewrecord#viewrecord_log')->imprecord($data);
		return;
	}
}

class mobileplugin_jnpar_viewrecord{
}

class mobileplugin_jnpar_viewrecord_forum extends plugin_jnpar_viewrecord_forum {
	
	function viewthread_top_mobile_output(){
		return $this->viewthread_top_output();
	}
	
	
	function viewthread_postbottom_mobile_output(){
		global $postlist;
		$flag=$this->open_or_not();
		if(!$flag)return;
		global $thread,$_G;
		$data = DB::fetch_all("select uname,uid from %t where id = %d",
			array(
				"viewrecord_log",$thread['tid']
			)
	    );
		// debug($thread['tid']);

	    include template('jnpar_viewrecord:ulist');
		$return=array();
		foreach($postlist as $k =>$v){
			if($v['first']!=1){
				$return[]='';
			}else{
				$return[]=$ulist;
			}
			
		}
		
	    return $return;
	   
	}
}

class mobileplugin_jnpar_viewrecord_portal extends plugin_jnpar_viewrecord_portal {
	
	function view_article_top_mobile_output(){
		return $this->view_article_top_output();

	}
}

