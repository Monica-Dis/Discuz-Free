<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_jnpar_downtable_base {
	
	function text2links($str='') {
		$str=str_replace(PHP_EOL,'<br/>',$str);
	  if($str=='' or !preg_match('/(http|www\.|@)/i', $str)) { return $str; }
	  $lines = explode("\n", $str); $new_text = '';
	  while (list($k,$l) = each($lines)) {
		// replace links:
		$l = preg_replace("/([ \t]|^)www\./i", "\\1http://www.", $l);
		$l = preg_replace("/([ \t]|^)ftp\./i", "\\1ftp://ftp.", $l);
		$l = preg_replace("/(http:\/\/[^ )\r\n!]+)/i",
		  "<a href=\"\\1\" target=\"_blank\">".lang('plugin/jnpar_downtable', 'hook1')."</a>", $l);
		$l = preg_replace("/(https:\/\/[^ )\r\n!]+)/i",
		  "<a href=\"\\1\" target=\"_blank\">".lang('plugin/jnpar_downtable', 'hook1')."</a>", $l);
		$l = preg_replace("/(ftp:\/\/[^ )\r\n!]+)/i",
		  "<a href=\"\\1\" target=\"_blank\">".lang('plugin/jnpar_downtable', 'hook1')."</a>", $l);
		$l = preg_replace(
		  "/([-a-z0-9_]+(\.[_a-z0-9-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)+))/i",
		  "<a href=\"mailto:\\1\" target=\"_blank\">".lang('plugin/jnpar_downtable', 'hook1')."</a>", $l);
		$new_text .= $l."\n";
	  }
	  return $new_text;
	}
	
	function get_urlnamec(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_downtable'];
		$urlnamec=$pvar['urlnamec'];
		
		$arr=explode(PHP_EOL,trim($urlnamec));
		$arr1=$arr2=array();
		foreach($arr as $s){
			if(!$s)return;
			$arr1[]=explode('|',trim($s));
		}
		return $arr1;
	}
	
}

class plugin_jnpar_downtable extends plugin_jnpar_downtable_base{
	
}
class plugin_jnpar_downtable_forum extends plugin_jnpar_downtable{
	function open_or_not(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_downtable'];
		$openfids=unserialize($var['open_fids']);
		if(in_array($fid,$openfids)){
			return true;
		}else{
			return false;
		}
	}
	function post_middle_output(){
		global $_G,$postinfo;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_downtable'];
		$down_credit=$var['down_credit'];
		$pay_ext=$_G['setting']['extcredits'][$down_credit]['title'];
		$open_class=unserialize($var['open_class']);
		$lv=lang('plugin/jnpar_downtable', 'hook7');
		$urlnameinfo=$this->get_urlnamec();
		
		$$lv=$this->open_or_not();
		$gaction=dhtmlspecialchars($_GET['action']);
		if(!$flag or !($gaction=='newthread' or ($gaction=='edit' and $postinfo['first']==1)))return;
		if($gaction=='edit'){
			$tid=intval($_GET['tid']);
			$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_downtable_tlog')." where tid='$tid'");
			$logid=$downinfo['logid'];
			$baidupan=$downinfo['baidupan'];
			$ciliurl=$downinfo['ciliurl'];
			$dianlvurl=$downinfo['dianlvurl'];
			$xunleiurl=$downinfo['xunleiurl'];
			$needmoney=$downinfo['needmoney']?$downinfo['needmoney']:0;			
		}
		include template("jnpar_downtable:inputtable");
		return $htmlcode;
	}
	function post_bottom_output(){
		$lv=lang('plugin/jnpar_downtable', 'hook7');
		$$lv=$this->open_or_not();
		$gaction=dhtmlspecialchars($_GET['action']);
		
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$isneeded=$_G['cache']['plugin']['jnpar_downtable']['isneeded'];
		
		if(!$flag or $gaction!='newthread' or $gaction!='edit' or !$isneeded)return;
		include template("jnpar_downtable:js");
		return $htmlcode;
	}
	function post_newthread_message($para){
		$lv=lang('plugin/jnpar_downtable', 'hook7');
		global $_G,$isfirstpost;
		$$lv=$this->open_or_not();
		$uid=$_G['uid'];
		$get=dhtmlspecialchars($_GET);
		$baidupan=$get['baidupan'];
		$ciliurl=$get['ciliurl'];
		$dianlvurl=$get['dianlvurl'];
		$xunleiurl=$get['xunleiurl'];
		$needmoney=$get['needmoney'];
		$gaction=dhtmlspecialchars($_GET['action']);
		
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$isneeded=$_G['cache']['plugin']['jnpar_downtable']['isneeded'];
		
		if($flag && $gaction=='newthread' and $get['message']){
			if($isneeded && !$baidupan && !$ciliurl && !$dianlvurl && !$xunleiurl){
				showmessage(lang('plugin/jnpar_downtable', 'hook2'));
			}
		}
		
		
		list($message, $forwordURL, $threadValue) = $para['param'];
		
		if($message=='post_newthread_succeed' && $flag){//��������ѿ�����鷢������
			$data=array(
						'tid'=>$threadValue['tid'],
						'baidupan'=>$baidupan,
						'ciliurl'=>$ciliurl,
						'dianlvurl'=>$dianlvurl,
						'xunleiurl'=>$xunleiurl,
						'needmoney'=>$needmoney,
						);
			DB::insert('jnpar_downtable_tlog',$data);
		}
		if($message=='post_edit_succeed' && $flag && $isfirstpost){//��������ѿ������༭����
			$condition=' tid='.$threadValue['tid'];
			$hasrecord=DB::result_first("select tid from ".DB::table("jnpar_downtable_tlog")." where ".$condition);
			if($hasrecord){//����Ѿ����ڼ�¼�����
				$data=array(
							'baidupan'=>$baidupan,
							'ciliurl'=>$ciliurl,
							'dianlvurl'=>$dianlvurl,
							'xunleiurl'=>$xunleiurl,
							'needmoney'=>$needmoney,
							);
				DB::update('jnpar_downtable_tlog',$data,$condition);
			}else{//��������ڼ�¼�����
				$data=array(
							'tid'=>$threadValue['tid'],
							'baidupan'=>$baidupan,
							'ciliurl'=>$ciliurl,
							'dianlvurl'=>$dianlvurl,
							'xunleiurl'=>$xunleiurl,
							'needmoney'=>$needmoney,
							);
				DB::insert('jnpar_downtable_tlog',$data);
			}
		}		
	}
	
	function viewthread_modaction_output(){
		global $_G,$thread;
		$uid=$_G['uid'];
		$tid=$thread['tid'];
		$pid=$thread['pid'];
		$authorid=$thread['authorid'];
		$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_downtable_tlog')." where tid='$tid'");
		$logid=$downinfo['logid'];
		
		$urlnameinfo=$this->get_urlnamec();
		
		if($urlnameinfo[0][1]){
			//debug($downinfo['baidupan']);
			$baidupan=$this->text2links($downinfo['baidupan']);
			//debug($baidupan);
		}else{
			$baidupan='<a href="'.trim($downinfo['baidupan']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[1][1]){
			$ciliurl=$this->text2links($downinfo['ciliurl']);
		}else{
			$ciliurl='<a href="'.trim($downinfo['ciliurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[2][1]){
			$dianlvurl=$this->text2links($downinfo['dianlvurl']);
		}else{
			$dianlvurl='<a href="'.trim($downinfo['dianlvurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[3][1]){
			$xunleiurl=$this->text2links($downinfo['xunleiurl']);
		}else{
			$xunleiurl='<a href="'.trim($downinfo['xunleiurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		
		$needmoney=$downinfo['needmoney'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_downtable'];
		$used_ext=$var['down_credit'];
		$dexttitle=$_G['setting']['extcredits'][$used_ext]['title'];
		
		$tcolor=$var['tcolor'];
		$tfcolor=$var['tfcolor'];
		$lcolor=$var['lcolor'];
		
		$tipcon=$var['tipcon'];
		
		$showable=0;
		$buyid=DB::result_first('select buyid from '.DB::table('jnpar_downtable_buylog')." where buyuid='$uid' and tid='$tid'");
		$gid=$_G['groupid'];
		$free_gids=unserialize($var['free_gids']);
		$isf=in_array($gid,$free_gids);
		if($buyid or $uid==$authorid or $needmoney==0 or $isf){
			$showable=1;
		}
		
		//debug($ciliurl);
		$show_style=$var['show_style'];
		if($downinfo['baidupan'] or $downinfo['ciliurl'] or $downinfo['dianlvurl'] or $downinfo['xunleiurl']){
			if($show_style==1 or !$show_style){
				include template('jnpar_downtable:outtable');
			}else{
				include template('jnpar_downtable:outtable1');
			}
			
		}
		return $htmlcode;
		
	}
}


class mobileplugin_jnpar_downtable  extends plugin_jnpar_downtable_base{
	
}
class mobileplugin_jnpar_downtable_forum extends mobileplugin_jnpar_downtable{
	function viewthread_postbottom_mobile_output(){
		global $_G,$thread;
		$uid=$_G['uid'];
		$tid=$thread['tid'];
		$pid=$thread['pid'];
		$authorid=$thread['authorid'];
		$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_downtable_tlog')." where tid='$tid'");
		$logid=$downinfo['logid'];
		$urlnameinfo=$this->get_urlnamec();
		
		if($urlnameinfo[0][1]){
			$baidupan=$this->text2links($downinfo['baidupan']);
		}else{
			$baidupan='<a href="'.trim($downinfo['baidupan']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[1][1]){
			$ciliurl=$this->text2links($downinfo['ciliurl']);
		}else{
			$ciliurl='<a href="'.trim($downinfo['ciliurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[2][1]){
			$dianlvurl=$this->text2links($downinfo['dianlvurl']);
		}else{
			$dianlvurl='<a href="'.trim($downinfo['dianlvurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		if($urlnameinfo[3][1]){
			$xunleiurl=$this->text2links($downinfo['xunleiurl']);
		}else{
			$xunleiurl='<a href="'.trim($downinfo['xunleiurl']).'" target="_blank">'.lang('plugin/jnpar_downtable', 'hook1').'</a>';
		}
		
		$needmoney=$downinfo['needmoney'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_downtable'];
		$used_ext=$var['down_credit'];
		$dexttitle=$_G['setting']['extcredits'][$used_ext]['title'];
		
		$tcolor=$var['tcolor'];
		$tfcolor=$var['tfcolor'];
		$lcolor=$var['lcolor'];
		
		$tipcon=$var['tipcon'];
		
		
		$showable=0;
		$buyid=DB::result_first('select buyid from '.DB::table('jnpar_downtable_buylog')." where buyuid='$uid' and tid='$tid'");
		$gid=$_G['groupid'];
		$free_gids=unserialize($var['free_gids']);
		$isf=in_array($gid,$free_gids);
		if($buyid or $uid==$authorid or $needmoney==0 or $isf){
			$showable=1;
		}
		
		$show_style=$var['show_style'];
		if($downinfo['baidupan'] or $downinfo['ciliurl'] or $downinfo['dianlvurl'] or $downinfo['xunleiurl']){
			if($show_style==1 or !$show_style){
				include template('jnpar_downtable:outtable');
			}else{
				include template('jnpar_downtable:outtable1');
			}
			
		}
		$return=array();
		$return[0]=$htmlcode;
		return $return;
	}
}
