<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}



if(submitcheck('submit')){
	global $_G;
	$tid=intval($_GET['tid']);
	$pid=intval($_GET['pid']);
	$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid='$tid'");
	
	if(!$_G['uid']){
		showmessage(lang('plugin/jnpar_downtable', 'hook3'));
	}
	
	$uid=$_G['uid'];
	
	if(empty($_G['cache']['plugin'])){
		loadcache('plugin');
	}
	$var=$_G['cache']['plugin']['jnpar_downtable'];
	$creditsn='extcredits'.$var['down_credit'];
	$ubalance=getuserprofile($creditsn);
	$credittitle=$_G['setting']['extcredits'][$var['down_credit']]['title'];
	
	$downinfo=DB::fetch_first('select * from '.DB::table('jnpar_downtable_tlog')." where tid='$tid'");
	$needpay=$downinfo['needmoney'];
	
	
	if($ubalance<$needpay){//���ֲ���
		showmessage(lang('plugin/jnpar_downtable', 'hook4'));
	}
	
	$buyid=DB::result_first('select buyid from '.DB::table('jnpar_downtable_buylog')." where buyuid='$uid' and tid='$tid'");
	
	if(!$buyid){//��������ڼ�¼�������
		$data=array(
					'buyuid'=>$uid,
					'tid'=>$tid,
					'buytime'=>time(),
					'remarks'=>$needpay.$credittitle,
					);
		DB::insert('jnpar_downtable_buylog',$data);
		$lltz=lang('plugin/jnpar_downtable', 'hook5');
		$tzbll='&#19979;&#36733;&#36164;&#28304;&#20986;&#21806;';
		if($version=='X2.5'){
			updatemembercount($uid,array($creditsn => -$needpay),true, 'BTC', $tid, lang('plugin/jnpar_downtable', 'hook5').$tid);
			updatemembercount($authorid,array($creditsn => $toauthorpay),true, 'STC', $tid, '&#20986;&#21806;&#19979;&#36733;&#22320;&#22336;');
		}else{
			updatemembercount($uid,array($creditsn => -$needpay),true, 'BTC', $tid,$lltz,$lltz, lang('plugin/jnpar_pansell', 'hook5').$tid);
			updatemembercount($authorid,array($creditsn => $toauthorpay),true, 'STC', $tid, $tzbll,$tzbll,'&#20986;&#21806;&#19979;&#36733;&#22320;&#22336;');
		}
	}else{
		showmessage(lang('plugin/jnpar_downtable', 'hook6'));
	}
	

	  header('Location:'.dreferer());
	  exit();

}else{
	global $_G;

	$uid=$_G['uid']?$_G['uid']:0;
	
	if(!$uid)showmessage('to_login', NULL, array(), array('login' => 1));
	
	include template('jnpar_downtable:paytip');
}
?>