<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_jnpar_threadpreg_base {
	function open_or_not(){//�Ƿ���
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_threadpreg'];
		
		$openfids=unserialize($var['open_fids']);
		if(in_array($fid,$openfids)){
			return true;
		}else{
			return false;
		}
	}
	
	function sresolve($str,$seprator1,$seprator2){
		$aa1=$arr2=array();
		if(!$str){
			return array();
		}
		$arr=explode($seprator1,trim($str));
		foreach($arr as $k=>$s){
			$aa1=explode($seprator2,trim($s));
			$arr2[$k]=$aa1;
		}
		return $arr2;
	}
	
	function getreps($str){
		$arr1=explode('(-',$str);
		if(empty($arr1))return array($str,'','');
		$matches_str1=$arr1[0];
		$arr2=explode('-)',$arr1[1]);
		//debug($arr2);
		if(!$arr2[0]){
			return array($str,'','');
		}
		$matches_num=$arr2[0];
		$matches_str2=$arr2[1];
		return array($matches_str1,$matches_num,$matches_str2);
	}
	
	function funcrep($matches){
		global $fk,$_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$setvar=$_G['cache']['plugin']['jnpar_threadpreg'];
		$open_reply=$setvar['open_reply'];
		$preg_reps=$setvar['preg_reps'];
		$pregarr=$this->sresolve($preg_reps,PHP_EOL,'|=|');

		$p1=$pregarr[$fk][1];
		$reps=$this->getreps($p1);
		if($reps[1]){
			return $reps[0].$matches[1].$reps[2];
		}else{
			return $reps[0];
		}
	}
	
}


class plugin_jnpar_threadpreg  extends plugin_jnpar_threadpreg_base{
	
}
class plugin_jnpar_threadpreg_forum extends plugin_jnpar_threadpreg{
	function viewthread_top_output(){

		global $_G,$postlist,$thread,$post;
		$flag=$this->open_or_not();
		if(!$flag)return;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$setvar=$_G['cache']['plugin']['jnpar_threadpreg'];
		$yourstyles=$setvar['yourstyles'];
		$open_reply=$setvar['open_reply'];
		$preg_reps=$setvar['preg_reps'];
		$phone_preg=$setvar['phone_preg'];
		$vx_preg=$setvar['vx_preg'];
		$pregarr=$this->sresolve($preg_reps,PHP_EOL,'|=|');
		
		foreach($postlist as $k=>$p){
			$message=$p['message'];
			foreach($pregarr as $pk=>$p){
				global $fk;
				$fk=$pk;
				$p0=str_replace(array('"',"'",'$','+','.','?','^','{','}','|','[',']','/',"\\",'(*)','(',')','*'),array('\"',"\'",'\$','\+','\.','\?','\^','\{','\}','\|','\[','\]','\/',"\\",'([\s\S]+?)','(',')','\*'),$p[0]);
				$preg="/".$p0."/";
				$message=preg_replace_callback($preg,array(&$this,'funcrep'),$message);
			}
			if($phone_preg){
				$message=preg_replace('/(0[0-9]{2,3}[\-]?[2-9])[0-9]{3,4}([0-9]{3}[\-]?[0-9]?)/i','$1****$2',$message);
				$message=preg_replace('/(1[358]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$message);
			}
			if($vx_preg){
				$message=preg_replace('/([a-zA-Z0-9]{2})[-_a-zA-Z0-9]{2,18}([-_a-zA-Z0-9]{1})/i','$1****$2',$message);
			}
			$postlist[$k]['message']=$message;
		}
		include template('jnpar_threadpreg:code');
		return $code;
	}
}

class mobileplugin_jnpar_threadpreg  extends plugin_jnpar_threadpreg{
	
}
class mobileplugin_jnpar_threadpreg_forum extends plugin_jnpar_threadpreg_forum{
	function viewthread_top_mobile_output(){
		global $_G;
		$flag=$this->open_or_not();
		if(!$flag)return;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$setvar=$_G['cache']['plugin']['jnpar_threadpreg'];
		$yourstyles=$setvar['yourstyles'];
		include template('jnpar_threadpreg:code');
		return $code;
	}
}
