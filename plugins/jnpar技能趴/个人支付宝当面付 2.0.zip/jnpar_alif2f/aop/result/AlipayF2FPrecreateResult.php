<?php
/*
 *	[DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	这不是一个免费的程序！由DISM.TAOBAO.COM提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站dism.taobao.com 辅助推广，敬请访问惠临。
 *	$_G['basescript'] = 模块名称
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class AlipayF2FPrecreateResult
{
    private $tradeStatus;
    private $response;

    public function __construct($response)
    {
        $this->response = $response;
    }

    public function AlipayF2FPrecreateResult($response)
    {
        $this->__construct($response);
    }

    public function setTradeStatus($tradeStatus)
    {
       $this->tradeStatus = $tradeStatus;
    }

    public function getTradeStatus()
    {
        return $this->tradeStatus;
    }

    public function setResponse($response)
    {
        $this->response = $response;
    }

    public function getResponse()
    {
        return $this->response;
    }
}
//From: dis'.'m.t'.'ao'.'bao.com
?>