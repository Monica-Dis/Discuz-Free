<?php
/*
 *	[DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	这不是一个免费的程序！由DISM.TAOBAO.COM提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站dism.taobao.com 辅助推广，敬请访问惠临。
 *	$_G['basescript'] = 模块名称
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class ExtendParams
{
    // 系统商编号
    private $sysServiceProviderId;

    //使用花呗分期要进行的分期数,非必填项
    private $hbFqNum;

    //使用花呗分期需要卖家承担的手续费比例的百分值
    private $hbFqSellerPercent;

    private $extendParamsArr = array();

    public function getExtendParams()
    {
        if(!empty($this->extendParamsArr)) {
            return $this->extendParamsArr;
        }
    }

    public function getSysServiceProviderId()
    {
        return $this->sysServiceProviderId;
    }

    public function setSysServiceProviderId($sysServiceProviderId)
    {
        $this->sysServiceProviderId = $sysServiceProviderId;
        $this->extendParamsArr['sys_service_provider_id'] = $sysServiceProviderId;
    }

    public function getHbFqNum()
    {
        return $this->hbFqNum;
    }

    public function setHbFqNum($hbFqNum)
    {
        $this->hbFqNum = $hbFqNum;
        $this->extendParamsArr['hb_fq_num'] = $hbFqNum;
    }

    public function getHbFqSellerPercent()
    {
        return $this->hbFqSellerPercent;
    }

    public function setHbFqSellerPercent($hbFqSellerPercent)
    {
        $this->hbFqSellerPercent = $hbFqSellerPercent;
        $this->extendParamsArr['hb_fq_seller_percent'] = $hbFqSellerPercent;
    }
}