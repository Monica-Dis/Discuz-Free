// JavaScript Document


	
$(document).on("click", ".on-number", function() {
	var qqval = $(this).siblings("input[type='text']"),
		val = parseInt(qqval.val(), 10) + parseInt($(this).data("v"));
		qqval.val((isNaN(val) || val<1) ? 1 : val);
});

	$(document).on("click", "#up", function() {
		$.ajax({
		  type: 'GET',
		  url: upurl,
		  data: {
		  	op:op,
			formhash:formhash
		  },
		  success: function(res){
			   console.log(res);
			  if(res=='2' || res=='3'){
				  	var tip='';
				  ires=parseInt(res);
				  if(ires==2){
					 tip="点赞成功"
					 }else{
						tip= "取消点赞"
					 }
				  if(op==1){
					 op=0
					 }else{
					op=1 
					 }
				   console.log(op);
					 var upcount=parseInt($('#upcount').text());
					 if(op==1){
						 $('#upicon').html('&#xe65c;');
						 $('#upcount').text(upcount-1);
					 }else{
						 $('#upicon').html('&#xe600;')
						 $('#upcount').text(upcount+1);
					 }
					 $.toast(tip,900, function() {
						 console.log(op);
					});
				 }
			  if(res=='1'){
					 $.toast("未登录，无法点赞", function() {
					  console.log('close');
					});
				 }
				
		  },
		fail:function(){
			 $.toast("网络失败，请重试", function() {
			  console.log('close');
			});
			
		}
		
		});
      })
	
	//=============
	$(document).on("click", "#dashangbtn", function() {
		var awardcount=parseInt($('#awardcount').val());
		if(awardcount<1){
			 $.toast('打赏金额不得小于1',900, function() {
				 console.log(awardcount);
				 return;
			});
		}
		if(awardcount>ubalance){
			 $.toast('余额不足，请充值！',900, function() {
				 console.log(awardcount);
				 return;
			});
		}
		
		$.ajax({
		  type: 'POST',
		  url: awurl,
		  data: {
		  	awardcount:awardcount,
			  formhash:formhash,
			  nid:nid
		  },
		  success: function(res){
			   console.log(res);
			  var ub=parseInt($('#ubalance').text());
			 var awcount=parseInt($('#awcount').text());
			  if(res=='10'){
					 $('#awicon').html('&#xe6e6;');
					 $('#awcount').text(awcount+awardcount);
				  	$('#ubalance').text(ub-awardcount);
					 $.toast('打赏成功！',900, function() {
						 console.log(op);
					});
				 }
			  if(res=='1'){
					 $.toast("请登录后打赏", function() {
					  console.log('close');
					});
				 }
			  if(res=='2'){
					 $.toast("非法参数，请刷新后重试", function() {
					  console.log('close');
					});
				 }
			  if(res=='3'){
					 $.toast("余额不足，请充值", function() {
					  console.log('close');
					});
				 }
				
		  },
		fail:function(){
			 $.toast("网络失败，请重试", function() {
			  console.log('close');
			});
			
		}
		
		});
      })