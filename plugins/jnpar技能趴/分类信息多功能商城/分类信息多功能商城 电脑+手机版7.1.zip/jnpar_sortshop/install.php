<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2018 by jnpar
|   http://dism.taobao.com
|   Support: QQ94526868
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：授权许可程序，此程序只授权于应用中心下载网站域名，私自修改文件将失去商业售后服务！
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_sortshop_records` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(35) NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `nk` int(10) unsigned NOT NULL,
  `paytime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `uid` (`uid`),
  KEY `tid` (`tid`),
  KEY `nk` (`nk`)
) ENGINE=MyISAM;

INSERT INTO `pre_jn_payapps` (`buytype`, `appid`, `version`, `installtime`, `paras`, `remarks`) VALUES
(10, 'jnpar_sortshop', '1.2', 0, '', '');

EOF;

runquery($sql);

$finish = TRUE;
?>