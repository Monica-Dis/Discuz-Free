<?php

/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

class plugin_jnpar_sortshop{
	function viewthread_posttb_handle(){
		$flag=C::t('#jnpar_sortshop#jnpar_sortshop')->open_or_not();
		if(!$flag)return;
		global $_G,$postlist,$count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_sortshop'];
		$open_toptip=$pvar['open_toptip'];
		if(!$open_toptip)return;
		$toptip_con=$pvar['toptip_con'];
		$gdiscount=$gdiscount<10?$gdiscount." &#25240;":'&#26080;';
		$mdiscount=$mdiscount<10?$mdiscount." &#25240;":'&#26080;';
		$toptip_con=str_replace(array('{count_need}','{count_toauthor}','{count_pay}','{gdiscount}','{mdiscount}'),array($count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount),$toptip_con);
		
		foreach($postlist as $pid => $post){
			if($post['first']){
				include template('jnpar_sortshop:output');
				$return[0] = $toptip;
			}
		}
		return $return;
		
	}
}


class plugin_jnpar_sortshop_forum extends plugin_jnpar_sortshop {	
	
	function viewthread_posttop_output(){
		return $this->viewthread_posttb_handle();		
	}
	
	
	function viewthread_top_output(){
		$flag=C::t('#jnpar_sortshop#jnpar_sortshop')->open_or_not();
		if(!$flag)return;
		global $postlist,$_G,$count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount;
		//debug($_G);
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_sortshop'];
		$sell_va=explode(PHP_EOL,trim($pvar['sell_v']));
		$button_template=$pvar['button_template'];
		$buyed_template=$pvar['buyed_template'];
		
		$arr=C::t('#jnpar_sortshop#jnpar_sortshop')->getcontrolinfo();
		@extract($arr);
		
		//����Ҫ���ݸ�����ҳ������ݽ��м���		
		if(!$safekey){
			$safekey='aaaaa';//�����վ�����еİ�ȫ�벻���ڣ�������һ��Ĭ���ַ���
		}
		$pid=$_G['forum_firstpid'];
		$payway_open=unserialize($pvar['payway_open']);
		$payways=implode(',',$payway_open);
		$allow_guestpay=1;
		
		$valitime=TIMESTAMP+300;//������Чʱ��5����
		
		$para=$tid.'|'.$has_record.'|'.$authorid.'|'.$count_need.'|'.$count_toauthor.'|'.$pid.'|'.$payways.'|'.$allow_guestpay.'|'.$valitime.'|'.$count_pay.'|'.$gdiscount.'|'.$mdiscount;
		//debug($count_pay);
		$para=C::t('#jnpar_pay#jn_orderlog')->passport_encrypt($para,$safekey);
		
		global $threadsortshow,$thread;
		
		if(!$needpay){//�������Ҫ֧��
			if(!$threadsortshow['typetemplate']){
				foreach($threadsortshow['optionlist'] as $k => $op){
					if(C::t('#jnpar_sortshop#jnpar_sortshop')->myin_array("$k",$sell_va)){
						$transedcode=str_replace('{{value}}',$threadsortshow['optionlist'][$k]['value'],$buyed_template);
						$threadsortshow['optionlist'][$k]['value']=$transedcode;
					}
				}
			}else{
				require_once DISCUZ_ROOT . "./source/plugin/jnpar_sortshop/threadsort.func.php";
				$threadsortshow = threadsortshow_1($thread['sortid'], $thread['tid'],$buyed_template);
			}
		}else{
			//include template("jnpar_sortshop:hidecode");
			$urlextra="";
			if($gdiscount<10 and $gdiscount>0){
				$urlextra.="&gdc={$gdiscount}";
			}elseif($mdiscount<10 and $mdiscount>0){
				$urlextra.="&mdc={$mdiscount}";
			}
			$buyurl="plugin.php?id=jnpar_pay:jn_pay&para={$para}&appid=jnpar_sortshop".$urlextra;
			$hidecode=str_replace('{{buyurl}}',$buyurl,$button_template);
			if(!$threadsortshow['typetemplate']){
				foreach($threadsortshow['optionlist'] as $k => $op){
					if(C::t('#jnpar_sortshop#jnpar_sortshop')->myin_array("$k",$sell_va)){
						$threadsortshow['optionlist'][$k]['value']=$hidecode;
					}
				}
			}else{
				require_once DISCUZ_ROOT . "./source/plugin/jnpar_sortshop/threadsort.func.php";
				$threadsortshow = threadsortshow_1($thread['sortid'], $thread['tid'],$hidecode);
			}
		}
		return $css;
	}
}

class mobileplugin_jnpar_sortshop{
}

class mobileplugin_jnpar_sortshop_forum extends plugin_jnpar_sortshop_forum {
	
	function viewthread_top_mobile_output(){
		return $this->viewthread_top_output();
	}
	
	function viewthread_posttop_mobile_output(){
		return $this->viewthread_posttb_handle();		
	}
}

