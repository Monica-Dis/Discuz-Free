<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: function_threadsort.php 36284 2016-12-12 00:47:50Z Dism_taobao-com  $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function threadsortshow_1($sortid, $tid,$hidecode) {
	

	function threadsortshow_callback_showoption_title1_($matches) {
		return showoption_($matches[1], 'title');
	}

	function threadsortshow_callback_showoption_value1_($matches) {
		return showoption_($matches[1], 'value');
	}

	function threadsortshow_callback_showoption_unit1_($matches) {
		return showoption_($matches[1], 'unit');
	}

	function showoption_($var, $type) {
		global $_G;
		if($_G['forum_option'][$var][$type] != '') {
			return $_G['forum_option'][$var][$type];
		} else {
			return '';
		}
	}

	function protectguard_($protect) {
		global $_G, $member_verifys;
		if(!isset($member_verifys) && $_G['setting']['verify']['enabled']) {
			$member_verifys = array();
			getuserprofile('verify1');
			foreach($_G['setting']['verify'] as $vid => $verify) {
				if($verify['available'] && $_G['member']['verify'.$vid] == 1) {
					$member_verifys[] = $vid;
				}
			}
		}
		$verifyflag = 0;
		if($_G['setting']['verify']['enabled'] && $protect['verify']) {
			if(array_intersect(explode("\t", $protect['verify']), $member_verifys)) {
				$verifyflag = 1;
			}
		}
		if(($protect['usergroup'] && strstr("\t".$protect['usergroup']."\t", "\t$_G[groupid]\t"))
				|| (empty($protect['usergroup']) && empty($protect['verify']))
				|| $verifyflag
				|| $_G['forum_thread']['authorid'] == $_G['uid']) {
			return false;
		} else {
			return true;
		}
	}

	
	global $_G;

	loadcache(array('threadsort_option_'.$sortid, 'threadsort_template_'.$sortid,'plugin'));
	$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
	$templatearray = $_G['cache']['threadsort_template_'.$sortid];
	
	//对于出售的分类信息字段在模板中进行一个替换
	$var=$_G['cache']['plugin']['jnpar_sortshop'];
	$sell_va=explode(PHP_EOL,trim($var['sell_v']));
	
	foreach($sortoptionarray as $soption){
		if(C::t('#jnpar_sortshop#jnpar_sortshop')->myin_array($soption['identifier'],$sell_va)){
			$hidecode=str_replace('{{value}}','{'.$soption['identifier'].'_value}',$hidecode);
			$templatearray['viewthread']=str_replace('{'.$soption['identifier'].'_value}',$hidecode,$templatearray['viewthread']);
		}
	}
	
	$threadsortshow = $optiondata = $searchtitle = $searchvalue = $searchunit = $memberinfofield = $_G['forum_option'] = array();	
	if($sortoptionarray) {

		foreach(C::t('forum_typeoptionvar')->fetch_all_by_tid_optionid($tid) as $option) {
			$optiondata[$option['optionid']]['value'] = $option['value'];
			$optiondata[$option['optionid']]['expiration'] = $option['expiration'] && $option['expiration'] <= TIMESTAMP ? 1 : 0;
			$sortdataexpiration = $option['expiration'];
		}

		foreach($sortoptionarray as $optionid => $option) {
			$_G['forum_option'][$option['identifier']]['title'] = $option['title'];
			$_G['forum_option'][$option['identifier']]['unit'] = $option['unit'];
			$_G['forum_option'][$option['identifier']]['type'] = $option['type'];

			if(($option['expiration'] && !$optiondata[$optionid]['expiration']) || empty($option['expiration'])) {
				if(!protectguard_($option['protect'])) {
					if($option['type'] == 'checkbox') {
						$_G['forum_option'][$option['identifier']]['value'] = '';
						foreach(explode("\t", $optiondata[$optionid]['value']) as $choiceid) {
							$_G['forum_option'][$option['identifier']]['value'] .= $option['choices'][$choiceid].'&nbsp;';
						}
					} elseif($option['type'] == 'radio') {
						$_G['forum_option'][$option['identifier']]['value'] = $option['choices'][$optiondata[$optionid]['value']];
					} elseif($option['type'] == 'select') {
						$tmpchoiceid = $tmpidentifiervalue = array();
						foreach(explode('.', $optiondata[$optionid]['value']) as $choiceid) {
							$tmpchoiceid[] = $choiceid;
							$tmpidentifiervalue[] = $option['choices'][implode('.', $tmpchoiceid)];
						}
						$_G['forum_option'][$option['identifier']]['value'] = implode(' &raquo; ', $tmpidentifiervalue);
						unset($tmpchoiceid, $tmpidentifiervalue);
					} elseif($option['type'] == 'image') {
						$imgoptiondata = dunserialize($optiondata[$optionid]['value']);
						$threadsortshow['sortaids'][] = $imgoptiondata['aid'];
						if(empty($templatearray['viewthread'])) {
							$maxwidth = $option['maxwidth'] ? 'width="'.$option['maxwidth'].'"' : '';
							$maxheight = $option['maxheight'] ? 'height="'.$option['maxheight'].'"' : '';
							if(!defined('IN_MOBILE')) {
								$_G['forum_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? "<img src=\"".$imgoptiondata['url']."\" onload=\"thumbImg(this)\" $maxwidth $maxheight border=\"0\">" : '';
							} else {
								$_G['forum_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? "<a href=\"".$imgoptiondata['url']."\" target=\"_blank\">".lang('forum/misc', 'click_view')."</a>" : '';
							}
						} else {
							$_G['forum_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? $imgoptiondata['url'] : './static/image/common/nophoto.gif';
						}
					} elseif($option['type'] == 'url') {
						$_G['forum_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? "<a href=\"".$optiondata[$optionid]['value']."\" target=\"_blank\">".$optiondata[$optionid]['value']."</a>" : '';
					} elseif($option['type'] == 'number') {
						$_G['forum_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'];
					} else {
						if($option['protect']['status'] && $optiondata[$optionid]['value']) {
							$optiondata[$optionid]['value'] = $option['protect']['mode'] == 1 ? '<image src="'.stringtopic($optiondata[$optionid]['value']).'">' : (!defined('IN_MOBILE') ? '<span id="sortmessage_'.$option['identifier'].'"><a href="###" onclick="ajaxget(\'forum.php?mod=misc&action=protectsort&tid='.$tid.'&optionid='.$optionid.'\', \'sortmessage_'.$option['identifier'].'\');return false;">'.lang('forum/misc', 'click_view').'</a></span>' : $optiondata[$optionid]['value']);
							$_G['forum_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? $optiondata[$optionid]['value'] : $option['defaultvalue'];
						} elseif($option['type'] == 'textarea') {
							$_G['forum_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] != '' ? nl2br($optiondata[$optionid]['value']) : '';
						} else {
							$_G['forum_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] != '' ? $optiondata[$optionid]['value'] : $option['defaultvalue'];
						}
					}
				} else {
					if(empty($option['permprompt'])) {
						$_G['forum_option'][$option['identifier']]['value'] = lang('forum/misc', 'view_noperm');
					} else {
						$_G['forum_option'][$option['identifier']]['value'] = $option['permprompt'];
					}

				}
			} else {
				$_G['forum_option'][$option['identifier']]['value'] = lang('forum/misc', 'has_expired');
			}
		}

		$typetemplate = '';
		if($templatearray['viewthread']) {
			foreach($sortoptionarray as $option) {
				$searchtitle[] = '/{('.$option['identifier'].')}/';
				$searchvalue[] = '/\[('.$option['identifier'].')value\]/';
				$searchvalue[] = '/{('.$option['identifier'].')_value}/';
				$searchunit[] = '/\[('.$option['identifier'].')unit\]/';
				$searchunit[] = '/{('.$option['identifier'].')_unit}/';
			}

			$threadexpiration = $sortdataexpiration ? dgmdate($sortdataexpiration) : lang('forum/misc', 'never_expired');
			$typetemplate = preg_replace(array("/\{expiration\}/i"), array($threadexpiration), stripslashes($templatearray['viewthread']));
			$typetemplate = preg_replace_callback($searchtitle, "threadsortshow_callback_showoption_title1_", $typetemplate);
			$typetemplate = preg_replace_callback($searchvalue, "threadsortshow_callback_showoption_value1_", $typetemplate);
			$typetemplate = preg_replace_callback($searchunit, "threadsortshow_callback_showoption_unit1_", $typetemplate);
		}
	}

	$threadsortshow['optionlist'] = !$optionexpiration ? $_G['forum_option'] : 'expire';
	$threadsortshow['typetemplate'] = $typetemplate;
	$threadsortshow['expiration'] = dgmdate($sortdataexpiration, 'd');

	return $threadsortshow;
}



?>