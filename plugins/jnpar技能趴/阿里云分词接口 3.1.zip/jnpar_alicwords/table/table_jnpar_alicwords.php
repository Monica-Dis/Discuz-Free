<?php
/*
 *	DisM!应用中心：dism.taobao.com
 *	这不是一个免费的程序！由DisM.Taobao.Com提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站Dism_taobao·com 辅助推广，敬请访问惠临。
 *	$_G['basescript'] = 模块名称
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_alicwords extends discuz_table
{
	public function __construct() {
		$this->_table = 'jnpar_alicwords';
		$this->_pk    = '';
		parent::__construct(); /*Dism_taobao-com*/
	}
	

	public function object_array($array) {  
		if(is_object($array)) {  
			$array = (array)$array;  
		 } if(is_array($array)) {  
			 foreach($array as $key=>$value) {  
				 $array[$key] = $this->object_array($value);  
			 }  
		 }  
		 return $array;  
	}
	
	function getcwords($searchtxt,$maxlength=NULL){
		$maxlength=$maxlength?$maxlength:30;
		require_once DISCUZ_ROOT . './source/plugin/jnpar_alicwords/aliyun-php-sdk-core/Config.php';
		$clientProfile = DefaultProfile::getProfile(
			"cn-shanghai",                   #目前支持持cn-shanghai
			"LTAI4FcPCbtFWQH7SxfdoDxw",               # 您的 AccessKey ID
			"CSBGgTSlkuelJwLrF4IL5Ml0NW5GJs"            # 您的 AccessKey Secret
		);
		
		if(strtolower(CHARSET) == 'gbk'){
			$text =mb_substr($searchtxt,0,$maxlength,'GBK');
			$text=iconv('GBK','UTF-8',$text);	
		}else{
			$text =mb_substr($searchtxt,0,$maxlength,'utf-8');
			//$text=iconv('GBK','UTF-8',$text);
		}
		//debug($text);
		$postdata['lang']='ZH';
		$postdata['text']=$text;

		$words_json=json_encode($postdata);
		//debug($words_json);
		$clientProfile->addEndpoint('cn-shanghai', "cn-shanghai", "Nlp", "nlp.cn-shanghai.aliyuncs.com");
		$client = new DefaultAcsClient($clientProfile);
		$request = new NlpRequest();
		$request->setContent($words_json);
		try {
			$response = $client->getAcsResponse($request);
			$response=$this->object_array($response);
			if(strtolower(CHARSET) == 'gbk')$response = eval('return '.iconv('utf-8','gb2312',var_export($response,true)).';');
			
		} catch(ServerException $e) {
			$response = "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage();
		} catch(ClientException $e) {
			$response = "Error: " . $e->getErrorCode() . " Message: " . $e->getMessage() . "\n";
		}
		return $response;
	}
	
}