<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!应用中心.
|   http://Dism_taobao·com
|   Support: DISM.TAOBAO.COM
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：授权许可程序，此程序只授权于应用中心下载网站域名，私自修改文件将失去商业售后服务！
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_alicwords";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');

$sql = <<<EOF

EOF;

runquery($sql);

$finish = TRUE;
?>