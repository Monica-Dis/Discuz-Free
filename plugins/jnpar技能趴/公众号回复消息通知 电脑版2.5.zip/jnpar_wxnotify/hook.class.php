<?php 
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {

    exit('Access Denied');

}

class plugin_jnpar_wxnotify{
	function open_or_not(){
		global $_G;
		$fid=$_G['fid'];
		$gid=$_G['groupid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_wxnotify'];
		$openfids=unserialize($pvar['open_fids']);
		$opengids=unserialize($pvar['open_gids']);
		if(!in_array($fid,$openfids) || !in_array($gid,$opengids)){
			return 0;
		}else{
			return 1;
		}
	}
}

class plugin_jnpar_wxnotify_forum extends plugin_jnpar_wxnotify{
	function post_middle_output(){
		global $isfirstpost;
		$flag=$this->open_or_not();
		if(!$flag or !$isfirstpost){
			return;
		}
		$action=$_GET['action'];
		$tid=$_GET['tid'];
		if($action=='edit'){
			$log=C::t('#jnpar_wxnotify#jnpar_wxnotify')->fetch_log_by_tid($tid);
		}
		global $_G;
		$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
		if(!$uid)return;
		$uinfo=C::t('#jnpar_wxnotify#wxnotify_uinfo')->fetch_log_by_uid($uid);
		$status=intval($uinfo['status']);
		include template("jnpar_wxnotify:select");
		return $radiosel;
	}	
	
	function post_newthread(){
		global $_G;
		$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
		if(!$uid)return;
		$flag=$this->open_or_not();
		if(!$flag){
			return;
		}
		if(submitcheck('topicsubmit') and $_GET['nflag']){
			$logid=C::t('#jnpar_wxnotify#wxnotify_uinfo')->logid_by_uid($uid);
			if(!$logid)showmessage(lang('plugin/jnpar_wxnotify', 'a1'));
		}
	}	
	
	function post_edit(){
		global $_G;
		$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
		if(!$uid)return;
		$flag=$this->open_or_not();
		if(!$flag){
			return;
		}
		
		if(submitcheck('editsubmit') and $_GET['nflag']){
			$logid=C::t('#jnpar_wxnotify#wxnotify_uinfo')->logid_by_uid($uid);
			if(!$logid)showmessage(lang('plugin/jnpar_wxnotify', 'a1'));
		}
	}
	

	function post_newthread_message($para){
		global $_G,$isfirstpost;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_wxnotify'];
		$flag=$this->open_or_not();
		if(!$flag){
			return;
		}
		$act=dhtmlspecialchars($_GET['action']);
		$nflag=intval($_GET['nflag']);
		
		//debug($para['param']);
		list($message, $forwordURL, $threadValue) = $para['param'];
		if($message=='post_newthread_succeed'){//如果是在已开启版块发布新贴
			if($nflag){
				$data=array(
							'tid'=>$threadValue['tid'],
							'nflag'=>1,
							);
				DB::insert('jnpar_wxnotify',$data);
			}
		}elseif($message=='post_edit_succeed'){
			if(!$nflag){
				$condition=" tid=".$threadValue['tid'];
				DB::delete('jnpar_wxnotify',$condition);
			}else{
				$logid=C::t('#jnpar_wxnotify#jnpar_wxnotify')->logid_by_tid($threadValue['tid']);
				$data=array(
							'tid'=>$threadValue['tid'],
							'nflag'=>1,
							);
				if($logid){
					$con=' logid='.$logid;
					DB::update('jnpar_wxnotify',$data,$con);
				}else{
					DB::insert('jnpar_wxnotify',$data);
				}
				
			}
		}
		//debug($GLOBALS);
		if($message=='post_reply_succeed' or ($message=='post_edit_succeed' and $isfirstpost!=1)){//如果是在已开启版块新回复帖子或编辑回复帖
			$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
			if(!$uid)return;
			if($_G['thread']['authorid']==$uid)return;
			if($openid=C::t('#jnpar_wxnotify#wxnotify_uinfo')->openid_by_uid($_G['thread']['authorid'])){
				$conf=C::t('#jnpar_wxnotify#jnpar_wxnotify')->sresolve($pvar['template_varset'],PHP_EOL,'|',0);
				$auth=$_G['thread']['author'];
				$t=$_G['thread']['subject'];
				$rer=$_G['username'];
				$rc=mb_substr( $_GET['message'], 0, 100, CHARSET );
				$rt=date('Y-m-d H:i',$_GET['posttime']);
				$notydata=array(
					'url'=>$_G['siteurl'].$para['param'][1],
				);
				foreach($conf as $k=>$c){
					$conf[$k][1]=str_replace(array('{auth}','{rer}','{t}','{rc}','{rt}'),array($auth,$rer,$t,$rc,$rt),$conf[$k][1]);
					$notydata[$k]['con']=$conf[$k][1];
					$notydata[$k]['color']=$conf[$k][2];
				}
				$r=C::t('#jnpar_wxnotify#jnpar_wxnotify')->sendnotify($openid,$notydata);
			}
		}
	}
}

class mobileplugin_jnpar_wxnotify extends plugin_jnpar_wxnotify{}

class mobileplugin_jnpar_wxnotify_forum extends plugin_jnpar_wxnotify_forum {
	function post_middle_output(){
		return;
	}
}