<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright 2001-2099 DisM!应用中心.
|   http://dism·taobao·com
|   Support: DisM.Taobao-Com
|   Please don't change the copyright, From: DisM.taobao.Com
|   本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jnpar_wxnotify` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL,
  `nflag` tinyint(1) NOT NULL,
  `openid` varchar(40) NOT NULL,
  `remarks` varchar(10) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_wxnotify_uinfo` (
  `logid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `openid` varchar(40) NOT NULL,
  `optime` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `uid` (`uid`),
  KEY `openid` (`openid`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>