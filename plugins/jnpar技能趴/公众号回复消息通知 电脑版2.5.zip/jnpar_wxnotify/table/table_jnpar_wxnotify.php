<?php
/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	这不是一个免费的程序！由DISM.TAOBAO.COM提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站dism·taobao·com 辅助推广，敬请访问惠临。
 *	最新插件：http://t.cn/Aiux1Jx1
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_wxnotify extends discuz_table
{
	public function __construct() {

		$this->_table = 'jnpar_wxnotify';
		$this->_pk    = '';

		parent::__construct(); /*dism - taobao - com*/
	}
	
	function sendnotify($openid,$data){
		global $_G;
		if($_G['cache']['plugin']['jnpar_wxnotify']){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_wxnotify'];
		$template_id=$pvar['template_id'];
		
		$access_token=C::t('#jnpar_wxnotify#jnpar_wxnotify')->getaccesskey();
		$url='https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.$access_token;
		$template=C::t('#jnpar_wxnotify#jnpar_wxnotify')->json_template($openid,$template_id,$data);
		
		$r=C::t('#jnpar_wxnotify#jnpar_wxnotify')->request_post($url,$template);
		$r=json_decode($r,true);
		if($r['errcode']==0){
			return 1;
		}else{
			return 0;
		}
	}
	
	function json_template($openid,$template_id,$data){
		$template=array(
			'touser'=>$openid, //用户openid
			'template_id'=>$template_id, //在公众号下配置的模板id
			'url'=>$data['url'], //点击模板消息会跳转的链接
			'topcolor'=>"#7B68EE",
		);
		$template['data']=array();
		foreach($data as $k=>$v){
			$template['data'][$k]=array(
				'value'=>$v['con'],
				'color'=>$v['color']
			);
		}
		
		$json_template=json_encode($template);
		return $json_template;
	}
	function fetch_log_by_tid($tid){
		$r=DB::fetch_first('select * from %t where tid=%d',array($this->_table,$tid));
		return $r;
	}
	
	function logid_by_tid($tid){
		$r=DB::result_first('select logid from %t where tid=%d',array($this->_table,$tid));
		return $r;
	}
	
    function getResponse()
    {
        //$xmlStr = $GLOBALS['HTTP_RAW_POST_DATA'];
        $xmlStr = file_get_contents('php://input');
        C::t('#jnpar_wxnotify#jnpar_wxnotify')->logResult($xmlStr);
        if (empty($xmlStr)) {
            return false;
        }
        libxml_disable_entity_loader(true);
        $xml = simplexml_load_string($xmlStr, 'SimpleXMLElement', LIBXML_NOCDATA);
        $data = json_decode(json_encode($xml),true);
        switch ($data['MsgType']) {
            case 'event': 
                $this->handleEvent($data);
                break;
            case 'text':
                break;
        }
    }
	
    function handleEvent($data){
		$event=strtolower($data['Event']);
		if($event=='scan'){
			$this->scan($data);
		}
		elseif($event=='subscribe'){
			$this->subscribe($data);
		}
		elseif($event=='unsubscribe'){
			$this->unsubscribe($data);
		}
	}
	
	function scan($data){
		$this->logArr($data);
		$event=strtolower($data['Event']);
		$openid=$data['FromUserName'];
		$eventkey=$data['EventKey'];
		$arr=explode('_',$eventkey);
		$n=(sizeof($arr)-1);
		$uid=$arr[$n];
		$idata=array(
			'openid'=>$openid,
			'uid'=>$uid,
			'optime'=>TIMESTAMP,
			'status'=>1,
		);
		C::t('#jnpar_wxnotify#wxnotify_uinfo')->update($idata);
	}
	function subscribe($data){
		$this->scan($data);
	}
	function unsubscribe($data){
		$event=strtolower($data['Event']);
		$openid=$data['FromUserName'];
		DB::query('update %t set status=0 where openid=%s',array('wxnotify_uinfo',$openid));
	}
	
    function getWeChatUrl($sceneValue,$type = 1){
        $access_token=C::t('#jnpar_wxnotify#jnpar_wxnotify')->getaccesskey();
        $url = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token;
        $actionName = 'QR_STR_SCENE';
        if($type==2){
            $actionName = 'QR_LIMIT_STR_SCENE';
        }
 
        $res = $this->request_post($url,json_encode([
            'expire_seconds'=>604800,
            'action_name'=>$actionName,
            'action_info'=>[
                'scene'=>[
                    'scene_id'=>$sceneValue,
                    'scene_str'=>$sceneValue
                ]
            ]
        ]));
		$res=json_decode($res,true);
		//debug($res);
        if(isset($res['errcode']) && $res['errcode']){
            echo $res['errmsg'];die();
        }
        //return 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$res['ticket']; //expire_seconds,url
		return $res['url'];
    }
	function getwebchat_uinfo(){
		$access_token=C::t('#jnpar_wxnotify#jnpar_wxnotify')->getaccesskey();
        $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=OPENID&lang=zh_CN";
		
	}
	function getaccesskey(){
		global $_G;
		if($_G['cache']['plugin']['jnpar_wxnotify']){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_wxnotify'];
		
		loadcache("jnpar_wxnotify_accesskey");
		$ak=unserialize($_G['cache']["jnpar_wxnotify_accesskey"]);
		if(empty($ak['con']) or $ak['vt']<TIMESTAMP){
			$get=dhtmlspecialchars($_GET);
			$appid=$pvar['appid'];
			$appsecret=$pvar['appsecret'];
			$token=$pvar['token'];
			$url="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
			//debug($url);
			$r=file_get_contents($url);
			$r=json_decode($r,true);
			$access_token=$r['access_token'];	
			$vt=TIMESTAMP+7100;
			$ak['con']=$access_token;
			$ak['vt']=$vt;
			$cachearr=serialize($ak);
			savecache("jnpar_wxnotify_accesskey",$cachearr);
		}else{
			$access_token=$ak['con'];
		}
		return $access_token;
	}
	
	//生成随机8位邀请码的函数
	function make_coupon_card($length=NULL){
		$length=$length?$length:8;
		$chars = 'abcdefghigklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!|.;*';
		$str = "";
		for ( $i = 0; $i < $length; $i++ )
		{
			$str .= $chars[ mt_rand(0, strlen($chars) - 1) ];
		}
		return $str ;
	}
	
	function logArr($arr){
		$str=$this->createLinkstring($arr);
		$this->logResult($str);
	}
	
	/**
	 * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
	 * 注意：服务器需要开通fopen配置
	 * @param $word 要写入日志里的文本内容 默认值：空值
	 */
	function logResult($word='') {
		$fp = fopen('testlog.txt',"a");
		flock($fp, LOCK_EX) ;
		fwrite($fp,'dotime'.strftime("%Y%m%d%H%M%S",time())."\r\n".$word."\r\n");
		flock($fp, LOCK_UN);
		fclose($fp);
	}
	
	/**
	 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
	 * @param $para 需要拼接的数组
	 * return 拼接完成以后的字符串
	 */
	function createLinkstring($para) {
		$arg  = "";
		while (list ($key, $val) = each ($para)) {
				$arg.=$key."=".$val."&";
		}
		//去掉最后一个&字符
		$arg = substr($arg,0,count($arg)-2);

		//如果存在转义字符，那么去掉转义
		//if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}

		return $arg;
	}

    function request_post($url = '', $param = '') {
        if (empty($url) || empty($param)) {
            return false;
        }
        $postUrl = $url;
        $curlPost = $param;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书下同
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        
        //debug($data);
        return $data;
    }

	
	function getglobal(){
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_wxnotify'];
		$global['banners']=$this->getbanners();
		return $global;
	}
	
	function in_app(){
		global $_G;
		$getapi=($_GET['api']);
		if($getapi)return true;
		return false;
	}
	
	function sresolve($str,$seprator1,$seprator2,$key=NULL){
		$aa1=$arr2=array();
		if(!$str){
			return array();
		}
		$arr=explode($seprator1,trim($str));
		foreach($arr as $k=>$s){
			$aa1=explode($seprator2,trim($s));
			if($key!==NULL){
				$arr2[$aa1[$key]]=$aa1;
			}else{
				$arr2[$k]=$aa1;
			}
		}
		return $arr2;
	}
	
	function echoarr($arr){
		global $_G;
		if(strtolower(CHARSET) == 'gbk'){
			$arr = eval('return '.iconv('gb2312','utf-8',var_export($arr,true)).';');
		}
		if($_GET['d']=='echoarr')debug(json_encode($arr,true));
		if($_GET['d']=='echoarr1')debug($arr);
		ob_end_clean();
		ob_start();
		echo(json_encode($arr,true));
		exit();
	}

}