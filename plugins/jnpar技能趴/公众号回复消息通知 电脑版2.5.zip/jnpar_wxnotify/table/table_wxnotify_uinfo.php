<?php
/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	这不是一个免费的程序！由DISM.TAOBAO.COM提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站dism·taobao·com 辅助推广，敬请访问惠临。
 *	最新插件：http://t.cn/Aiux1Jx1
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wxnotify_uinfo extends discuz_table
{
	public function __construct() {

		$this->_table = 'wxnotify_uinfo';
		$this->_pk    = '';

		parent::__construct(); /*dism - taobao - com*/
	}
	
	function fetch_log_by_uid($uid){
		$r=DB::fetch_first('select * from %t where uid=%d and status=1',array($this->_table,$uid));
		return $r;
	}
	function update($idata){
		$uid=$idata['uid'];
		$logid=DB::result_first('select logid from %t where uid=%d',array($this->_table,$uid));
		if($logid){
			$con=' logid='.$logid;
			DB::update($this->_table,$idata,$con);
		}else{
			DB::insert($this->_table,$idata);
		}
	}
	
	function logid_by_uid($uid){
		$r=DB::result_first('select logid from %t where uid=%d and status=1',array($this->_table,$uid));
		return $r;
	}
	
	function openid_by_uid($uid){
		$r=DB::result_first('select openid from %t where uid=%d and status=1',array($this->_table,$uid));
		return $r;
	}
}