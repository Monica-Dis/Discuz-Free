<?php

/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism��taobao��com �����ƹ㣬������ʻ��١�
 *	���²����http://t.cn/Aiux1Jx1
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}
class plugin_jnpar_serialplay{
}

class plugin_jnpar_serialplay_forum extends plugin_jnpar_serialplay  {
	
	function viewthread_output(){
		global $_G,$postlist,$post;

		$fid=$_G['fid'];
		$gid=$_G['groupid'];
		$tid=intval($_GET['tid']);
		$kid=intval($_GET['kid']);
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_serialplay'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$vidio_exts=$pvar['vidio_exts'];
		$vidioexts=explode('|',$vidio_exts);
		$vipgids=unserialize($pvar['vip_gids']);
		$rticon=$pvar['rticon'];
		$vwidth=$pvar['vwidth'];
		$vmwidth=$pvar['vmwidth'];
		$open_attach=$pvar['open_attach'];
		$noacctip=$pvar['noacctip'];

		$readset=C::t('common_usergroup_field')->fetch_all_fields($gid, array('readaccess'));
		$readaccess=$readset[0]['readaccess'];
		if(!in_array($fid,$openfids)){
			return;
		}
		$isvip=0;
		if(in_array($_G['groupid'],$vipgids)){
			$isvip=1;
		}
		
		$preg='/<ignore_js_op>([\s\S]+?)id="attach_(\d+)"([\s\S]+?)<a href=\"(.+?)\"([\s\S]+?)<div class=\"tip_horn\"><\/div>([\s\S]+?)<\/ignore_js_op>/';
		$mes=$post['message'];
		preg_match_all($preg,$mes,$htmlcode);
		$attaches=$post['attachments'];
		$k=0;
		//debug($attaches);
		$videos=array();
		foreach($htmlcode[2] as $ak){//����¥���е�ÿ������
			$attach=$attaches[$ak];
			if(in_array($attach['ext'],$vidioexts)){
				$price=$attach['price'];
				$payed=$attach['payed'];
				if((!$payed && $price && $_G['uid']) or ($payed && $price && !$_G['uid']) or ($open_attach==1)){
					$attach_url=$_G['siteurl'].$attach['url'].$attach['attachment'];
				}else{
					$attach_url_preg=$_G['siteurl'].$htmlcode[4][$k];
					$attach_url=str_replace('&amp;','&',$attach_url_preg);
				}

				$filename=$attach['filename'];
				$videos['attach_url'][]=$attach_url;
				$attach_desc=$attach['description'];
				$videos['filename'][]=$attach_desc?$attach_desc:substr($filename,0,strrpos($filename, '.'));
				$videos['payed'][]=(!$payed && $price)?0:1;
				$videos['access'][]=$readaccess>=$attach['readperm']?1:0;
				$videos['aid'][]=$attach['aid'];
				$videos['pid'][]=$post['pid'];
				$mes=str_replace($htmlcode[0][$k],'',$mes);
			}

			$k++;
		}

		if(!empty($videos['attach_url'])){
			include template('jnpar_serialplay:playcode');
		}

		$post['message'] =$html0. $mes;
		
	}
	
	function viewthread_top_output(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_serialplay'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$bgcolor1=$pvar['bgcolor1'];
		$bgcolor2=$pvar['bgcolor2'];
		$bgcolor3=$pvar['bgcolor3'];
		
		if(!in_array($fid,$openfids)){
			return;
		}
		
		include template('jnpar_serialplay:pubcode');
		return $html;
	}
	
	function viewthread_postbottom_output() {
		global $_G, $postlist;
		$fid=$_G['fid'];
		$gid=$_G['groupid'];
		$tid=intval($_GET['tid']);
		$kid=intval($_GET['kid']);
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_serialplay'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$vidio_exts=$pvar['vidio_exts'];
		$vidioexts=explode('|',$vidio_exts);
		$vipgids=unserialize($pvar['vip_gids']);
		$rticon=$pvar['rticon'];
		$vwidth=$pvar['vwidth'];
		$vmwidth=$pvar['vmwidth'];
		$open_attach=$pvar['open_attach'];
		$noacctip=$pvar['noacctip'];

		$readset=C::t('common_usergroup_field')->fetch_all_fields($gid, array('readaccess'));
		$readaccess=$readset[0]['readaccess'];
		if(!in_array($fid,$openfids)){
			return;
		}
		$isvip=0;
		if(in_array($_G['groupid'],$vipgids)){
			$isvip=1;
		}
		foreach($postlist as $id => $p) {//����ÿ��¥��
			if($p['first']!=1)continue;
			$preg='/<ignore_js_op>([\s\S]+?)id="attach_(\d+)"([\s\S]+?)<a href=\"(.+?)\"([\s\S]+?)<div class=\"tip_horn\"><\/div>([\s\S]+?)<\/ignore_js_op>/';
			$mes=$p['message'];
			preg_match_all($preg,$mes,$htmlcode);
			$attaches=$p['attachments'];
			$k=0;
			//debug($attaches);
			$videos=array();
			foreach($htmlcode[2] as $ak){//����¥���е�ÿ������
				$attach=$attaches[$ak];
				if(in_array($attach['ext'],$vidioexts)){
					$price=$attach['price'];
					$payed=$attach['payed'];
					if((!$payed && $price && $_G['uid']) or ($payed && $price && !$_G['uid']) or ($open_attach==1)){
						$attach_url=$_G['siteurl'].$attach['url'].$attach['attachment'];
					}else{
						$attach_url_preg=$_G['siteurl'].$htmlcode[4][$k];
						$attach_url=str_replace('&amp;','&',$attach_url_preg);
					}
					
					$filename=$attach['filename'];
					$videos['attach_url'][]=$attach_url;
					$attach_desc=$attach['description'];
					$videos['filename'][]=$attach_desc?$attach_desc:substr($filename,0,strrpos($filename, '.'));
					$videos['payed'][]=(!$payed && $price)?0:1;
					$videos['access'][]=$readaccess>=$attach['readperm']?1:0;
					$videos['aid'][]=$attach['aid'];
					$videos['pid'][]=$p['pid'];
					$mes=str_replace($htmlcode[0][$k],'',$mes);
				}
				
				$k++;
			}
			
			//debug($videos);
			if(!empty($videos['attach_url'])){
				include template('jnpar_serialplay:playcode');
			}
				
			$postlist[$id]['message'] =$html0. $mes;
		}
		return;
	}
}

class mobileplugin_jnpar_serialplay{

}

class mobileplugin_jnpar_serialplay_forum extends plugin_jnpar_serialplay_forum  {
	
	function viewthread_top_mobile_output(){
		return $this->viewthread_top_output();
	}
	
	function viewthread_postbottom_mobile_output() {
		global $_G, $postlist;
		$fid=$_G['fid'];
		$gid=$_G['groupid'];
		$tid=intval($_GET['tid']);
		$kid=intval($_GET['kid']);
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_serialplay'];
		$open_fids=$pvar['open_fids'];
		$openfids=unserialize($open_fids);
		$vidio_exts=$pvar['vidio_exts'];
		$vidioexts=explode('|',$vidio_exts);
		$vipgids=unserialize($pvar['vip_gids']);
		$rticon=$pvar['rticon'];
		$vwidth=$pvar['vwidth'];
		$vmwidth=$pvar['vmwidth'];
		$open_attach=$pvar['open_attach'];
		$noacctip=$pvar['noacctip'];

		$readset=C::t('common_usergroup_field')->fetch_all_fields($gid, array('readaccess'));
		$readaccess=$readset[0]['readaccess'];
		if(!in_array($fid,$openfids)){
			return;
		}
		$isvip=0;
		if(in_array($_G['groupid'],$vipgids)){
			$isvip=1;
		}
		foreach($postlist as $id => $p) {//����ÿ��¥��
			if($p['first']!=1)continue;
			$preg='/<div id=\"attach_(\d+)"([\s\S]+?)<a href=\"(.*?)\"([\s\S]+?)<\/div>/';
			$mes=$p['message'];
			preg_match_all($preg,$mes,$htmlcode);
			$attaches=$p['attachments'];
			$k=0;
			//debug($attaches);
			$videos=array();
			foreach($htmlcode[1] as $ak){//����¥���е�ÿ������
				$attach=$attaches[$ak];
				if(in_array($attach['ext'],$vidioexts)){
					$price=$attach['price'];
					$payed=$attach['payed'];
					if((!$payed && $price && $_G['uid']) or ($payed && $price && !$_G['uid']) or ($open_attach==1)){
						$attach_url=$_G['siteurl'].$attach['url'].$attach['attachment'];
					}else{
						$attach_url_preg=$_G['siteurl'].$htmlcode[3][$k];
						$attach_url=str_replace('&amp;','&',$attach_url_preg);
					}
					
					$filename=$attach['filename'];
					$videos['attach_url'][]=$attach_url;
					$attach_desc=$attach['description'];
					$videos['filename'][]=$attach_desc?$attach_desc:substr($filename,0,strrpos($filename, '.'));
					$videos['payed'][]=(!$payed && $price)?0:1;
					$videos['access'][]=$readaccess>=$attach['readperm']?1:0;
					$videos['aid'][]=$attach['aid'];
					$videos['pid'][]=$p['pid'];
					$mes=str_replace($htmlcode[0][$k],'',$mes);
				}
				
				$k++;
			}
			//debug($videos['attach_url']);
			if(!empty($videos['attach_url'])){
				include template('jnpar_serialplay:playcode');
			}
				
			$postlist[$id]['message'] =$html0. $mes;
		}
		return;
	}
}