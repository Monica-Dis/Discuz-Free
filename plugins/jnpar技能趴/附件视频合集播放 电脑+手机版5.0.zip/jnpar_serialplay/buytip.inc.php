<?php
/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism��taobao��com �����ƹ㣬������ʻ��١�
 *	���²����http://t.cn/Aiux1Jx1
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

require_once libfile('function/post');

$feed = array();
global $_G;
$tid=intval($_GET['tid']);
$aid=intval($_GET['aid']);
$pid=intval($_GET['pid']);
$kid=intval($_GET['kid']);

if(!$aid) {
	showmessage('parameters_error');
} elseif(!isset($_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]])) {
	showmessage('credits_transaction_disabled');
} elseif(!$_G['uid']) {
	showmessage('group_nopermission', NULL, array('grouptitle' => $_G['group']['grouptitle']), array('login' => 1));
} else {
	$attachtable = !empty($_GET['tid']) ? 'tid:'.dintval($_GET['tid']) : 'aid:'.$aid;
	$attach = C::t('forum_attachment_n')->fetch($attachtable, $aid);
	$attachmember = getuserbyuid($attach['uid']);
	$attach['author'] = $attachmember['username'];
	if($attach['price'] <= 0) {
		showmessage('undefined_action');
	}
}

if($attach['readperm'] && $attach['readperm'] > $_G['group']['readaccess']) {
	showmessage('attachment_forum_nopermission', NULL, array(), array('login' => 1));
}

$balance = getuserprofile('extcredits'.$_G['setting']['creditstransextra'][1]);
$status = $balance < $attach['price'] ? 1 : 0;

if($_G['adminid'] == 3) {
	$fid = C::t('forum_thread')->fetch($attach['tid']);
	$fid = $fid['fid'];
	$ismoderator = C::t('forum_moderator')->fetch_uid_by_fid_uid($fid, $_G['uid']);
} elseif(in_array($_G['adminid'], array(1, 2))) {
	$ismoderator = 1;
} else {
	$ismoderator = 0;
}
$exemptvalue = $ismoderator ? 64 : 8;
if($_G['uid'] == $attach['uid'] || $_G['group']['exempt'] & $exemptvalue) {
	$status = 2;
} else {
	$payrequired = $_G['uid'] ? !C::t('common_credit_log')->count_by_uid_operation_relatedid($_G['uid'], 'BAC', $attach['aid']) : 1;
	$status = $payrequired ? $status : 2;
}
$balance = $status != 2 ? $balance - $attach['price'] : $balance;

$sidauth = rawurlencode(authcode($_G['sid'], 'ENCODE', $_G['authkey']));

$aidencode = aidencode($aid, 0, $attach['tid']);

if(C::t('common_credit_log')->count_by_uid_operation_relatedid($_G['uid'], 'BAC', $aid)) {
	showmessage(lang('plugin/jnpar_serialplay', 'h1'), "forum.php?mod=viewthread&tid=$tid&kid=$kid");
}

$attach['netprice'] = $status != 2 ? round($attach['price'] * (1 - $_G['setting']['creditstax'])) : 0;
$lockid = 'attachpay_'.$_G['uid'];
//debug((!discuz_process::islocked($lockid)));
if(!submitcheck('paysubmit')) {
	include template('jnpar_serialplay:buytip');
} else{
	if(!empty($_GET['buyall'])) {
		$aids = $prices = array();
		$tprice = 0;
		foreach(C::t('forum_attachment_n')->fetch_all_by_id('aid:'.$aid, 'pid', $attach['pid'], '', false, true) as $tmp) {
			$aids[$tmp['aid']] = $tmp['aid'];
			$prices[$tmp['aid']] = $status != 2 ? array($tmp['price'], round($tmp['price'] * (1 - $_G['setting']['creditstax']))) : array(0, 0);
		}
		if($aids) {
			foreach(C::t('common_credit_log')->fetch_all_by_uid_operation_relatedid($_G['uid'], 'BAC', $aids) as $tmp) {
				unset($aids[$tmp['relatedid']]);
			}
		}
		foreach($aids as $aid) {
			$tprice += $prices[$aid][0];
		}
		$status = getuserprofile('extcredits'.$_G['setting']['creditstransextra'][1]) < $tprice ? 1 : 0;
	} else {
		$aids = array($aid);
		$prices[$aid] = $status != 2 ? array($attach['price'], $attach['netprice']) : array(0, 0);
	}

	if($status == 1) {
		showmessage('credits_balance_insufficient', '', array('title' => $_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title'], 'minbalance' => $attach['price']));
	}
	foreach($aids as $aid) {
		$updateauthor = 1;
		$authorEarn = $prices[$aid][1];
		if($_G['setting']['maxincperthread'] > 0) {
			$extcredit = 'extcredits'.$_G['setting']['creditstransextra'][1];
			$alog = C::t('common_credit_log')->count_credit_by_uid_operation_relatedid($attach['uid'], 'SAC', $aid, $_G['setting']['creditstransextra'][1]);
			if($alog >= $_G['setting']['maxincperthread']) {
				$updateauthor = 0;
			} else {
				$authorEarn = min($_G['setting']['maxincperthread'] - $alog['credit'], $prices[$aid][1]);
			}
		}
		if($updateauthor) {
			updatemembercount($attach['uid'], array($_G['setting']['creditstransextra'][1] => $authorEarn), 1, 'SAC', $aid);
		}
		updatemembercount($_G['uid'], array($_G['setting']['creditstransextra'][1] => -$prices[$aid][0]), 1, 'BAC', $aid);

		$aidencode = aidencode($aid, 0, $_GET['tid']);
	}
	
	if(defined('IN_MOBILE')) {
		showmessage(lang('plugin/jnpar_serialplay', 'h2'), "forum.php?mod=viewthread&tid=$tid&kid=$kid");
	}else{
		if(count($aids) > 1) {
			showmessage(lang('plugin/jnpar_serialplay', 'h3'), dreferer(),array('tid'=>$tid,'pid'=>$pid,'kid'=>$kid));
		} else {
			showmessage(lang('plugin/jnpar_serialplay', 'h4'), dreferer(),array('tid'=>$tid,'pid'=>$pid,'kid'=>$kid));
		}
	}
}