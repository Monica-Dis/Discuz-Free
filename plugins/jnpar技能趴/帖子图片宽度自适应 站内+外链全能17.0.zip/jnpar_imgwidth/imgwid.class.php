<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}


		
class plugin_jnpar_imgwidth {
	function splittoarray($str){
	  $arr=array();
	  $str=trim($str);
	  if(!empty($str)){
		 $arr=explode("|",$str);
	  }
	  return $arr;
	}
	function open_or_not(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar = $_G['cache']['plugin']['jnpar_imgwidth'];
		$open_fids=unserialize($pvar['open_fids']);
		$return=0;
		if(in_array($_G['fid'],$open_fids)){
			$return=1;
		}
		return $return;
	}
}

class plugin_jnpar_imgwidth_forum extends plugin_jnpar_imgwidth  {
	function viewthread_bottom_output() {
		$v1=lang('plugin/jnpar_imgwidth','v1');
		$$v1=$this->open_or_not();
		if(!$flag)return;
		global $_G,$postlist,$widpercent;

		if(empty($_G['cache']['plugin'])){
		  loadcache('plugin');
		}

		$config = $_G['cache']['plugin']['jnpar_imgwidth'];
		@extract($config);

		$unusedexts=$this->splittoarray($unusedext);
		$cids=array();
		foreach($postlist as $key => $v){
			if($usetoreply==0){
				if($v['first']==1){
					  $attachments=$v['attachments'];
					  $message=$v['message'];
					  $preg="/id=\"aimg_([^_ \f\n\r\t\v]+)\"/";

					  preg_match_all($preg,$message,$imgids);
					  $imgs=$imgids[1];

					  foreach($imgs as $img){
						  if(!in_array($attachments[$img]['ext'],$unusedexts)){
							  $cids[]=$img;
						  }
					  }
				}
			 }else{
				$attachments=$v['attachments'];
				$message=$v['message'];
				$preg="/id=\"aimg_([^_ \f\n\r\t\v]+)\"/";

				preg_match_all($preg,$message,$imgids);
				$imgs=$imgids[1];

				foreach($imgs as $img){
				  if(!in_array($attachments[$img]['ext'],$unusedexts)){
					  $cids[]=$img;
				  }
				}
			}
		}

		$cids=array_unique($cids);
		include template('jnpar_imgwidth:js');
		return $js;
	}
}