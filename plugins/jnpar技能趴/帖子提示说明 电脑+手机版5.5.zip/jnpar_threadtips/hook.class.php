<?php
/*
 *	[DisM!] (C)2019-2020 DISM.Taobao.COM.
 *	�ⲻ��һ����ѵĳ�����DisM.Taobao.Com�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdiscuz.jnpar.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_jnpar_threadtips{
	function open_or_not(){//�Ƿ���
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_threadtips'];
		
		$openfids=unserialize($var['open_fids']);
		if(in_array($fid,$openfids)){
			return true;
		}else{
			return false;
		}
	}	
	function tipcon($s){
		global $_G,$postlist;
		$flag=$this->open_or_not();
		if(!$flag)return;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$setvar=$_G['cache']['plugin']['jnpar_threadtips'];
		$return=array();
		if($s==1){
			$str=$setvar['top_tipcon'];
		}elseif($s==2){
			$str=$setvar['bottom_tipcon'];
		}elseif($s==3){
			$str=$setvar['mtop_tipcon'];
		}elseif($s==4){
			$str=$setvar['mbottom_tipcon'];
		}
		foreach($postlist as $k=>$post){
			if($post['first']==1){
				$return[]=$str;
			}else{
				$return[]='';
			}
		}
		return $return;
	}
	
}
class plugin_jnpar_threadtips_forum extends plugin_jnpar_threadtips{
	function viewthread_posttop_output(){
		return $this->tipcon(1);
	}
	
	function viewthread_postbottom_output(){
		return $this->tipcon(2);
	}
}


class mobileplugin_jnpar_threadtips extends plugin_jnpar_threadtips{
}
class mobileplugin_jnpar_threadtips_forum extends mobileplugin_jnpar_threadtips{
	function viewthread_posttop_mobile_output(){
		return $this->tipcon(3);
	}
	
	function viewthread_postbottom_mobile_output(){
		return $this->tipcon(4);
	}
}