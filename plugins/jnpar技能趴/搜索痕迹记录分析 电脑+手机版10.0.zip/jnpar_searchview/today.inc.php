<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$appurl=$_G['siteurl'].ADMINSCRIPT."?action=plugins&operation=config&do={$plugin['pluginid']}&identifier={$plugin['identifier']}&pmod={$_GET['pmod']}";
loadcache('plugin');
@extract($_G['cache']['plugin'][$plugin['identifier']]);

$p=dhtmlspecialchars($_GET['p']);
$p=$p?$p:1;
//debug($p);

$page=max(1,intval($_GET['page']));
$pagenum=30;
$begin=($page-1)*$pagenum;
$where=$pageadd='';
$order=dhtmlspecialchars($_GET['order'])?dhtmlspecialchars($_GET['order']):'num';
$order=daddslashes($order);

$wherezd=array();
if($order){
	$wherezd[]="`order`='$order'";
	$pageadd="&order=$order";
}

if(!empty($wherezd)){
	$where=" where ".join(" and ",$wherezd);
}

$obynum=$appurl."&p=".$p."&order=num";
$obymaxc=$appurl."&p=".$p."&order=maxc";

$nowdate=strtotime(date('Y-m-d'));
$tomdate=strtotime(date('Y-m-d'))-24*60*60;

if($p==1){
	$tabletitle=lang('plugin/jnpar_searchview', 's1');
	$listcount=DB::fetch_all('SELECT COUNT(*) FROM %t where logtime >=%d group by keywd', array('searchview_log',$nowdate));
}else{
	$listcount=DB::fetch_all('SELECT COUNT(*) FROM %t where logtime >= %d and logtime < %d group by keywd', array('searchview_log',$tomdate,$nowdate));
	$tabletitle=lang('plugin/jnpar_searchview', 's2');
}

if ($listcount) {
	
	if($p==1){
		$manylist=DB::fetch_all('select keywd,count(*) as num,logtime,max(resultcount) as maxc,searchtype from %t where logtime >=%d group by keywd order by %i desc,logtime desc limit %d,%d',array('searchview_log',$nowdate,$order,$begin,$pagenum));
	}else{
		$manylist=DB::fetch_all('select keywd,count(*) as num,logtime,max(resultcount) as maxc from %t where logtime >=%d and logtime < %d group by keywd order by %i desc,logtime desc limit %d,%d',array('searchview_log',$tomdate,$nowdate,$order,$begin,$pagenum));
	}
	
	$num=sizeof($listcount);
	$pagenav=multi($num,$pagenum,$page,$appurl."&p=$p".$pageadd);
	
}
$manylist=dhtmlspecialchars($manylist);
include template($plugin['identifier'].":admin_index");