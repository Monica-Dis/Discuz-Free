<?php
/*
 *	[jnpar] (C)2018-2023 jnpar����ſ��ҫ��Ʒ.
 *	�ⲻ��һ����ѵĳ�����QQ��94526868�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_searchview_log extends discuz_table{
	public function __construct() {

		$this->_table = 'searchview_log';
		$this->_pk    = '';

		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function merge_by_key($arr1,$arr2,$order,$begin,$length){
		$key='keywd';
		$narr=$karr=$narr1=$narr2=array();
		foreach($arr1 as $a){
			$narr1[$a[$key]]=$a;
			$karr[$a[$key]]=$a[$key];
		}
		foreach($arr2 as $a){
			$narr2[$a[$key]]=$a;
			$karr[$a[$key]]=$a[$key];
		}
		$num_arr=$maxc_arr=array();
		foreach($karr as $a){
			$narr[$a][0]=$a;
			$narr[$a][1]=intval($narr1[$a]['num']);
			$narr[$a][2]=intval($narr2[$a]['num']);
			$narr[$a][3]=$narr1[$a]['num']>$narr2[$a]['num']?lang('plugin/jnpar_searchview', 's4'):($narr1[$a]['num']<$narr2[$a]['num']?lang('plugin/jnpar_searchview', 's5'):lang('plugin/jnpar_searchview', 's6'));
			$narr[$a][4]=$narr1[$a]['maxc'];
			
			$num_arr[]=intval($narr1[$a]['num']);
			$maxc_arr[]=$narr1[$a]['maxc'];
		}
		if($order=='maxc'){
			$order_arr = $maxc_arr;
		}else{
			$order_arr = $num_arr;
		}
		
		array_multisort($order_arr,SORT_DESC,$narr);
		
		$return['listcount']=sizeof($narr);
		$return['list']=array_slice($narr,$begin,$length);
		
		return $return;
	}
	
	public function gethotwords(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_searchview'];
		$hotcount=$var['hotcount'];
		$endtime=time()-30*24*3600;
		return DB::fetch_all('select keywd,count(*) as num from '.DB::table('searchview_log').' where logtime>'.$endtime.' group by keywd order by num DESC limit '.$hotcount);
	}
	
    public function insertlog($keywd=NULL,$count=NULL,$mod=NULL){

        global $_G,$index;
		
		
        $keywd=$keywd?$keywd:$_GET['kw'];
		$resultcount=$count?$count:$index['num'];
		$mod=$mod?$mod:$_GET['mod'];
		
		if($mod=='forum'){
			$searchtype=1;
		}elseif($mod=='portal'){
			$searchtype=2;
		}
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_searchview'];
		$onlytoportal=$var['onlytoportal'];
		
		if($onlytoportal and $searchtype!=2)return;
		
		$clientip=$_G['clientip'];
		$betweentime=TIMESTAMP-600;//ͬһ����10�����ڲ��ظ���¼����ֵ
		
        if (!empty($keywd)){
            $logid=DB::result_first('SELECT logid FROM %t WHERE keywd=%s and logtime>%d and ip=%s', array($this->_table,$keywd, $betweentime,$clientip));
			
            if (!$logid){
                $data=array(
                    'keywd'=>$keywd,
                    'logtime'=> time(),
                    'resultcount'=>$resultcount,
                    'searchtype'=>$searchtype,
                    'ip'=>$_G['clientip'],
                );
                DB::insert($this->_table,$data);
            }
        }
    }
}