<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   DisM.Taobao.Com
|   http://dism.taobao.com
|   Support: DISM.TAOBAO.COM
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Ȩ���ɳ��򣬴˳���ֻ��Ȩ��Ӧ������������վ������˽���޸��ļ���ʧȥ��ҵ�ۺ����
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identify="jnpar_searchview";
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_GBK.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_SC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_BIG5.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'_TC_UTF8.xml');
@unlink('source/plugin/'.$identify.'/discuz_plugin_'.$identify.'.xml');
@unlink('source/plugin/'.$identify.'/install.php');



$finish = true;
?>