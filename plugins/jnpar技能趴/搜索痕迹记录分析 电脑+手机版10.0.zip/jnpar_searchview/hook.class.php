<?php 
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



class plugin_jnpar_searchview{
	
		
	public function addsearchwd($wd,$arr){//$wd新增搜索词，$arr原搜索词数组。函数作用：当获得用户输入的搜索词后，判断是新词还是已有的词，如果是新词，则直接添加到头部。如果是旧词，则删除原来数组中的相同词语，并将这个词加到数组头部。
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_searchview'];
		$recentcount=$var['recentcount'];
		$arr=$arr;
		foreach($arr as $k=>$v){
			if($v==$wd){
				array_splice($arr,$k,1);
			}
		}
		array_unshift($arr,$wd);
		$arr=array_slice($arr,0,$recentcount);
		return $arr;
	}
	
	public function preserve_read($keywd){
		global $_G;
		//对用户搜索历史进行记录和读取
		$recentwds=getcookie('recentwds');
		if($recentwds){
			$recentwds_arr=unserialize($recentwds);
		}
		if(is_array($recentwds_arr)){
			foreach($recentwds_arr as $k=>$v){//滤除空元素
				if($v==''){
					array_splice($recentwds_arr,$k,1);
				}
			}
		}else{
			$recentwds_arr=NULL;
		}
		if($keywd){
			if($recentwds_arr==NULL){
				$recentwds_arr=array($keywd);
			}
			$recentwds_arr=$this->addsearchwd($keywd,$recentwds_arr);
			$recentwds=serialize($recentwds_arr);//序列化存入cookie
			dsetcookie('recentwds', $recentwds, 99999999);
		}
		return $recentwds_arr;
	}

	
	function global_footer(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_searchview'];
		$keywd=$_GET['kw'];

		$recentwds_arr=$this->preserve_read($keywd);
		
		C::t('#jnpar_searchview#searchview_log')->insertlog();
		
		if(($_G['basescript']!='search' or $_GET['searchid']) and checkmobile())return;
		
		$insearch=0;
		if($_G['basescript']!='search' or $_GET['searchid'])$insearch=1;
		
		$recentstr='';
		
		$jumpto=$var['jumpto']==1?'portal':'forum';
		foreach($recentwds_arr as $v){
			$recentstr.='<a href="search.php?mod='.$jumpto.'&srchtxt='.urlencode($v).'&formhash='.FORMHASH.'&searchsubmit=true&source=hotsearch"><div class="cl recentcon"><div class="clockcon"><div class="clockbus"></div></div><div class="recentkey">'.$v.'</div></div></a>';
		}
		
		$hotwords=C::t('#jnpar_searchview#searchview_log')->gethotwords();
		$hotwords=dhtmlspecialchars($hotwords);
		
		$hotwdstr='';
		foreach($hotwords as $k=>$v){
			if($k%2==0){
				$hotwdstr.='<div class="hotwd cow1"><a href="search.php?mod='.$jumpto.'&srchtxt='.urlencode($v['keywd']).'&formhash='.FORMHASH.'&searchsubmit=true&source=hotsearch">'.$v['keywd'].'</a></div>';
			}else{
				$hotwdstr.='<div class="hotwd cow2"><a href="search.php?mod='.$jumpto.'&srchtxt='.urlencode($v['keywd']).'&formhash='.FORMHASH.'&searchsubmit=true&source=hotsearch">'.$v['keywd'].'</a></div>';
			}
		}
		
		if(sizeof($hotwords)%2==1){
			$hotwdstr.='<div class="hotwd cow2"> </div>';
		}
		
		include template('jnpar_searchview:searchadd');

		return $sadd;
	}
}


class  plugin_jnpar_searchview_search extends  plugin_jnpar_searchview{

    public  function forum_top_output(){
        C::t('#jnpar_searchview#searchview_log')->insertlog();
    }

    public  function portal_top_output(){
		C::t('#jnpar_searchview#searchview_log')->insertlog();
    }

}


class mobileplugin_jnpar_searchview extends plugin_jnpar_searchview{

	function global_footer_mobile(){//由于很多手机门户模板搜索页面不带有forum_top_mobile或portal_top_mobile嵌入点，所以使用此全局嵌入点。
		return $this->global_footer();
	}
}
