<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * From: DisM.taobao.Com
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
global $_G;

$get=dhtmlspecialchars($_GET);
$paytype=$get["paytype"];
$buykey=intval($get['buykey']);
$buyid=intval($get["buyid"]);

$siteurl = $_G['siteurl'];
$sitename = $_G['setting']['sitename'];
$username=$_G['username'];
$uid=$_G['uid']?$_G['uid']:0; /*dism_ taobao _com*/
//debug($_G['clientip']);
if(empty($_G['cache']['plugin'][$identifier])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin'][$identifier];

$payways=implode(',',unserialize($pvar['pay_method']));
$pay_banks=C::t('#jnpar_pay#jn_orderlog')->get_pay_methods($payways);
$pay_bank1=$pay_banks['pay_bank1'];

$pvar1=$_G['cache']['plugin']['jnpar_pay'];
$pay_credit=$pvar1['pay_credit'];
$pay_unit=$_G['setting']['extcredits'][$pay_credit]['unit'].$count.$_G['setting']['extcredits'][$pay_credit]['title'];
$credit_r=$pvar1['credit_r'];
$pay_extname='extcredits'.$pay_credit;
$ubalance=intval(getuserprofile($pay_extname));

$groupbuyset=C::t('#jnpar_groupbuy#jnpar_groupbuy')->conftoarray_vip();

$charset=strtolower(CHARSET)=='gbk'?'GBK':'UTF-8';
$in_weixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false?1:0;
$isMobile = checkmobile(); /*dis'.'m.tao'.'bao.com*/

$handletype=array('1'=>lang('plugin/jnpar_pay', 't16'),'2'=>lang('plugin/jnpar_pay', 't17'),'3'=>lang('plugin/jnpar_pay', 't18'));//1会员办理 2购买邀请码 3积分充值
$handletitle=array('1'=>lang('plugin/jnpar_pay', 't19'),'2'=>lang('plugin/jnpar_pay', 't20'),'3'=>lang('plugin/jnpar_pay', 't21'));//1选择办理类型 2邀请码价格 3金额选择
$handletype[0]=$handletype[3];//默认值
$handletitle[0]=$handletitle[3];

$template_style=($pvar['template_style'] and !$isMobile)?$pvar['template_style']:'default';

$price=C::t('#jnpar_pay#jn_orderlog')->get_price(intval($_GET['buykey']),intval($_GET['buyid']),$count_need);
$needcredits=ceil($price*$credit_r);//积分向上取整
if($ubalance<$needcredits)$cnotenough=1;
//debug($ubalance);

$tab=1;
if(!$_GET['appid'] and ($_GET["buykey"]=="" and $_GET["paytype"]=="")){
	include template("diy:index_".$tab."_".$template_style,0,'source/plugin/jnpar_groupbuy/template');
}elseif($_GET["paytype"]==""){
	//if(!$uid and $_GET["buykey"]!=2)showmessage('to_login', NULL, array(), array('login' => 1));
	$selwidth=sizeof($pay_bank1)*140;
	include(template("jnpar_pay:selectpay"));
}