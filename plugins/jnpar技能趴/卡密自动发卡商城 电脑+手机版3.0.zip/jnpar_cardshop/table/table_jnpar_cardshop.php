<?php
/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_cardshop extends discuz_table
{
	public function __construct() {

		$this->_table = 'jnpar_cardshop';
		$this->_pk    = '';

		parent::__construct();
	}
	
	public function getstock($tid){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cardshop'];
		
		if(empty($_G['cache']['jnpar_cardshop_stock'])){
			loadcache('jnpar_cardshop_stock');
		}
		
		if(!$_G['cache']['jnpar_cardshop_stock']['oid']){
			$_G['cache']['jnpar_cardshop_stock']['oid']=DB::result_first('select optionid from %t where identifier=%s',array('forum_typeoption',$pvar['sell_v']));
		}
		$oid=$_G['cache']['jnpar_cardshop_stock']['oid'];
		
		$cards=DB::result_first('select value from %t where tid=%d and optionid=%d',array('forum_typeoptionvar',$tid,$oid));
		$cards_arr=explode(PHP_EOL,trim($cards));
		$cards_arr_s=array();
		foreach($cards_arr as $card){
			if(!$card)continue;
			$cards_arr_s[]=$card;
		}
		$stock=sizeof($cards_arr_s);
		
		return $stock;
	}
	
	public function getcards($tid){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cardshop'];
		
		if(empty($_G['cache']['jnpar_cardshop_stock'])){
			loadcache('jnpar_cardshop_stock');
		}
		
		if(!$_G['cache']['jnpar_cardshop_stock']['oid']){
			$_G['cache']['jnpar_cardshop_stock']['oid']=DB::result_first('select optionid from %t where identifier=%s',array('forum_typeoption',$pvar['sell_v']));
		}
		$oid=$_G['cache']['jnpar_cardshop_stock']['oid'];
		
		$cards=DB::result_first('select value from %t where tid=%d and optionid=%d',array('forum_typeoptionvar',$tid,$oid));
		$cards_arr=explode(PHP_EOL,trim($cards));
		$cards_arr_s=array();
		foreach($cards_arr as $card){
			if(!$card)continue;
			$cards_arr_s[]=$card;
		}
		
		return $cards_arr_s;
	}
	
	public function get_and_set_card($tid){
		global $_G;
		$cards=$this->getcards($tid);
		$card=$cards[0];
		unset($cards[0]);
		$newcards=implode(PHP_EOL,$cards);
		
		if(empty($_G['cache']['jnpar_cardshop_stock'])){
			loadcache('jnpar_cardshop_stock');
		}
		
		if(!$_G['cache']['jnpar_cardshop_stock']['oid']){
			$_G['cache']['jnpar_cardshop_stock']['oid']=DB::result_first('select optionid from %t where identifier=%s',array('forum_typeoption',$pvar['sell_v']));
		}
		$oid=$_G['cache']['jnpar_cardshop_stock']['oid'];
		
		DB::query('update %t set value=%s where tid=%d and optionid=%d',array('forum_typeoptionvar',$newcards,$tid,$oid));
		return $card;
	}
	
	public function genorder($para_arr,$paytype){
		global $_G;
		$buykey=12;//����ƽ̨

		$siteurl = $_G['siteurl'];
		$sitename = $_G['setting']['sitename'];
		$username=$_G['username'];
		$uid=$_G['uid']?$_G['uid']:0;
		$tid=$para_arr[0];
		$has_record=$para_arr[1];
		$authorid=$para_arr[2];
		$price=$count_need=$para_arr[3];
		$count_toauthor=$para_arr[4];
		$pid=$para_arr[5];
		$payways=$para_arr[6];
		$allow_guestpay=$para_arr[7];
		
		$commodityName=lang('plugin/jnpar_pay', 't23');
		$desc = lang('plugin/jnpar_pay', 't23')."-cardshop:tid".$tid;
		$orderNum=C::t('#jnpar_pay#jn_orderlog')->createorder($uid,$buykey,$paytype,$price,$tid,$commodityName,$desc);
		$appreturn['return_url']=$siteurl.'forum.php?mod=viewthread&tid='.$tid;
		$appreturn['commodityName']=$commodityName;
		$appreturn['desc']=$desc;
		$appreturn['orderNum']=$orderNum;
		
		return $appreturn;
	}

	public function appcheck($arr){
		//������Ƿ����0
		global $_G;
		$tid=$arr[0];
		
		$remainc=C::t('#jnpar_cardshop#jnpar_cardshop')->getstock($tid);
		
		if($remainc<1){
			showmessage(lang('plugin/jnpar_cardshop','s1'));
		}
	}
	
	public function handle_payorder($ordernum){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cardshop'];
		$credit_reward=$pvar['credit_reward'];
		$percent_give=$pvar['percent_give'];
		
		$orderinfo=C::t('#jnpar_pay#jn_orderlog')->orderinfo_by_ordernum($ordernum);
		$uname=$orderinfo['uname'];
		$arr=explode("p",$ordernum);
		$paytype=$orderinfo['paytype'];
		
		$uid=intval($arr[0]);
		$tid=intval($arr[2]);
		
		$thread = C::t('forum_thread')->fetch($tid);
		$subject=$thread['subject'];
		$authorid=$thread['authorid'];
		
		$realprice=$orderinfo['price']*100;
		$toauthor=floor($realprice*$percent_give/100);
		$rewardc='extcredits'.$credit_reward;
		updatemembercount($authorid,array($rewardc => $toauthor),true, '', '',  lang('plugin/jnpar_cardshop','add1'), lang('plugin/jnpar_cardshop','add2').$tid,lang('plugin/jnpar_cardshop','add1'));
		$logs=C::t('#jnpar_cardshop#cardshop_records')->fetch_logs_by_uname_tid($uname,$tid);
		
		$card=$this->get_and_set_card($tid);
		
		if(!trim($logs)){//��������ڼ�¼�������
			$data=array(
						'uid'=>$uid,
						'uname'=>$uname,
						'tid'=>$tid,
						'paytime'=>TIMESTAMP,
						'logs'=>$card,
						);
			if($paytype==3)$data['nk']=1;
			C::t('#jnpar_cardshop#cardshop_records')->insert_cardshop_record($data);
		}else{//����Ѵ��ڼ�¼�������
			$newlogs=trim($logs).','.$card;
			if($paytype==3)$nk=1;
			C::t('#jnpar_cardshop#cardshop_records')->update_logs_by_uname_tid($uname,$tid,$newlogs,$nk);
		}
		$sales_v=explode('|',$pvar['sales_v']);
		DB::query('update %t set value=value+1 where tid=%d and sortid=%d and optionid=%d',array('forum_typeoptionvar',$tid,$sales_v[0],$sales_v[1]));
		
		$remainc=C::t('#jnpar_cardshop#jnpar_cardshop')->getstock($tid);
		
		if($remainc<5){
			$pm_content=lang('plugin/jnpar_pay', 't25');
			$sendpm=notification_add($authorid,'system',$pm_content);
		}
	}

	
	//================================================
	public function myin_array($str,$arr){
		foreach($arr as $a){
			if(strcasecmp(trim($a),trim($str))==0)return true;
		}
		return false;
	}
	
	function open_or_not(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_cardshop'];
		$openfids=unserialize($var['open_fids']);
		if(in_array($fid,$openfids)){
			return true;
		}else{
			return false;
		}
	}
	
	public function getcontrolinfo(){//��������һ����Ԫ�����飬������ҳ���һЩ������Ϣ

		//��������
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		@extract($_G['cache']['plugin']['jnpar_cardshop']);

		//��ȡ��ǰ��顢������Ϣ
		$fid=$_G['fid'];
		$tid=$_G['tid'];
		$valideplus=$validetime?$validetime*3600:0;//������Ч��
		$authorid=$_G['thread']['authorid'];//��������

		//�������
		$open_fids=unserialize(stripslashes($open_fids));
		$free_groups=unserialize(stripslashes($free_groups));
		$group_keyconf=$this->keyconf($discount_groups);
		$medal_keyconf=$this->keyconf($discount_medals);
		$return=array();
		$return['has_record']=1;//�Ƿ���֧����¼��Ԥ��Ϊ1	

		if($pay_way==1){//�Ƿ��Զ��ۻ���
			$return['autopay']=1;
		}else{
			$return['autopay']=0;
		}
		
		$uname=$_G['username']?$_G['username']:C::t('#jnpar_pay#jn_orderlog')->guestidentify();
		if(!$uname and in_array($fid,$open_fids)){//�Ƿ�Ϊ�ο�
			$return['notlogin']=1;
			$return['enough']=0;
			$return['needpay']=1;
		}else{
			$return['notlogin']=0;

			//��ȡ��ǰ��¼�û�����Ϣ
			$uid=$_G['uid'];
			$groupid=$_G['groupid'];
			$credits_having=getuserprofile('extcredits'.$credits_pay);//��ǰ�û�ʣ���֧���Ļ���
			$paytime=C::t('#jnpar_cardshop#cardshop_records')->fetch_paytime_by_uname_tid($uname,$tid);//��ȡ�ϴοۻ���ʱ��	

			if(!in_array($groupid,$free_groups)){
				$gdiscount=$this->get_group_discount($groupid,$group_keyconf);//�û����ۿ�
			}else{
				$gdiscount=1;
			}

			//ȡ��ǰ�û���ѫ������
			$ufields=C::t('common_member_field_forum')->fetch_all($uid);
			$medals_str=$ufields[$uid]['medals'];
			$medals=$this->medals_strtoarray_tp($medals_str);
			$mdiscount=$this->get_medal_discount($medals,$medal_keyconf);//ѫ���û��ۿ�
			
			$count_pay=C::t('#jnpar_cardshop#cardshop_threadcost')->fetch_cost_by_tid($tid);
			$count_need=$count_pay*$gdiscount*$mdiscount;
			$isfree=0;
			if($count_need<=0){
				$isfree=1;
			}
			$count_toauthor=round($count_need*$percent_give/100);
			if(in_array($fid,$open_fids) and !in_array($groupid,$free_groups) and $uid!=$authorid and !$isfree){//�Ƿ���Ҫ�ۻ��ֲ鿴
				//debug($paytime);
				if(!$paytime){//���û��֧����¼
					$return['needpay']=1;
					$return['has_record']=0;
				}elseif(!$valideplus){//�����֧����¼������Ч��Ϊ����
					$return['needpay']=0;
				}elseif(($paytime+$valideplus)>=time()){//��֧����¼������Ч�ڴ��ڵ�����£��������ʱ����ڵ��ڵ�ǰʱ��
					$return['needpay']=0;
				}else{//�������
					$return['needpay']=1;
				}
			}else{
				$return['needpay']=0;
			}

			if($credits_having<$count_pay){//�����Ƿ��㹻֧��
				$return['enough']=0;
			}else{
				$return['enough']=1;
			}
		}

		//����������Ϣ
		$return['gdiscount']=$gdiscount*10;
		$return['mdiscount']=$mdiscount*10;
		$return['creditsn']='extcredits'.$credits_pay;
		$return['count_pay']=$count_pay;//ԭ����Ҫ֧�����
		$return['count_need']=$count_need;//�ۿۺ�ʵ����Ҫ֧�����
		$return['count_toauthor']=$count_toauthor;
		$return['notlogin_tips']=$notlogin_tips;
		$return['notenough_tips']=$notenough_tips;
		$return['pay_unit']=$_G['setting']['extcredits'][$credits_pay]['unit'];
		$return['pay_title']=$_G['setting']['extcredits'][$credits_pay]['title'];
		$return['credits_having']=$credits_having;
		$return['validetime']=$validetime;	
		$return['tid']=$tid;
		$return['uid']=$uid;
		$return['intro']=$intro;
		$return['authorid']=$authorid;
		$return['safekey']=$_G['config']['security']['authkey'];
		return $return;
	}


	public function keyconf($str){//������ת���ɼ�ֵ����
		$arr=explode(PHP_EOL,trim($str));
		$arr1=$arr2=array();
		if($arr[0]){
			foreach($arr as $s){
				$arr1[]=explode('|',trim($s));
			}
			foreach($arr1 as $a1){
				$arr2[$a1[0]]=intval($a1[1]);
			}
		}
		return $arr2;
	}

	public function medals_strtoarray_tp($str){//ȡ�û����е�ѫ��
		$arr1=explode('	',trim($str));
		$arr2=$arr3=array();
		foreach($arr1 as $val){
			$arr2[]=explode('|',$val);
		}
		foreach($arr2 as $a){
			$arr3[]=$a[0];
		}
		return $arr3;
	}

	public function get_group_discount($groupid,$group_keyconf){//����groupid���û����Ż��ۿ۵���������
		$discount=1;
		foreach($group_keyconf as $key=>$conf){//���߸���ǰ��ԭ��
			if($groupid==$key){
				$discount=$conf/10;
			}
		}
		return $discount; //�����û����ۿ�
	}

	public function get_medal_discount($medals,$medal_keyconf){//�����û����е�ѫ�������ѫ���Ż��ۿ۵���������
		$discount=1;
		foreach($medal_keyconf as $key=>$conf){//ǰ������ߵ��ӣ���ˣ�ԭ��
			if(in_array($key,$medals)){
				$discount=$discount*$conf/10;
			}
		}
		return $discount; //����ѫ���ۿ�
	}
}