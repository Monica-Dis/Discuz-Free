<?php

/*
 *	[DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

class plugin_jnpar_cardshop{
	function global_myitem_extra(){
		$html='<a href="home.php?mod=spacecp&ac=plugin&id=jnpar_cardshop:myshop" style="color:red;">&#25105;&#30340;&#21830;&#22478;</a>';
		return $html;
	}
}


class plugin_jnpar_cardshop_forum extends plugin_jnpar_cardshop {
	
	function viewthread_top_output(){
		$flag=C::t('#jnpar_cardshop#jnpar_cardshop')->open_or_not();
		if(!$flag)return;
		global $postlist,$_G;
		global $count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount;
		//debug($_G);
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cardshop'];
		$sell_va=explode(PHP_EOL,trim($pvar['sell_v']));
		$$count_va=$pvar['$count_va'];
		$button_template=$pvar['button_template'];
		$buyed_template=$pvar['buyed_template'];
		
		$arr=C::t('#jnpar_cardshop#jnpar_cardshop')->getcontrolinfo();
		@extract($arr);
		
		//����Ҫ���ݸ�����ҳ������ݽ��м���		
		if(!$safekey){
			$safekey='aaaaa';//�����վ�����еİ�ȫ�벻���ڣ�������һ��Ĭ���ַ���
		}
		$pid=$_G['forum_firstpid'];
		$payway_open=unserialize($pvar['payway_open']);
		$cbuy_allow=$pvar['cbuy_allow'];
		$gid=$_G['groupid'];
		$cbuy_gids=unserialize($pvar['cbuy_gids']);
		
		$nk=DB::result_first('select nk from %t where uid=%d and tid=%d',array('cardshop_records',$uid,$tid));
		if(!in_array($gid,$cbuy_gids) or ($cbuy_allow and $nk>=$cbuy_allow)){
			$payway_open = array_flip($payway_open);
			unset($payway_open['3']);
			$payway_open = array_flip($payway_open);
		}
		$payways=implode(',',$payway_open);
		$allow_guestpay=1;
		
		$valitime=TIMESTAMP+300;//������Чʱ��5����
		
		$para=$tid.'|'.$has_record.'|'.$authorid.'|'.$count_need.'|'.$count_toauthor.'|'.$pid.'|'.$payways.'|'.$allow_guestpay.'|'.$valitime.'|'.$count_pay.'|'.$gdiscount.'|'.$mdiscount;
		$para=C::t('#jnpar_pay#jn_orderlog')->passport_encrypt($para,$safekey);
		
		global $threadsortshow,$thread;
		
		$urlextra="";
		if($gdiscount<10 and $gdiscount>0){
			$urlextra.="&gdc={$gdiscount}";
		}elseif($mdiscount<10 and $mdiscount>0){
			$urlextra.="&mdc={$mdiscount}";
		}
		$buyurl="plugin.php?id=jnpar_pay:jn_pay&para={$para}&appid=jnpar_cardshop".$urlextra;
		$hidecode=str_replace('{{buyurl}}',$buyurl,$button_template);
		$stock=C::t('#jnpar_cardshop#jnpar_cardshop')->getstock($tid);
		if(!$threadsortshow['typetemplate']){
			foreach($threadsortshow['optionlist'] as $k => $op){
				if(C::t('#jnpar_cardshop#jnpar_cardshop')->myin_array("$k",$sell_va)){
					$threadsortshow['optionlist'][$k]['value']=$hidecode;
				}elseif($k==$count_va){
					$threadsortshow['optionlist'][$k]['value']=$stock;
				}
			}
		}else{
			require_once DISCUZ_ROOT . "./source/plugin/jnpar_cardshop/threadsort.func.php";
			$threadsortshow = threadsortshow_($thread['sortid'], $thread['tid'],$hidecode,$stock);
		}
		
		return $css.'<iframe frameborder=0 width="0" height="0" src="" scrolling="no" name="ifrm" id="ifrm"></iframe>';//���һ��iframe��Ϊform�ύ��Ŀ�괰�ڣ������´򿪴���
	}
	
	function  viewthread_posttop_output(){
		$flag=C::t('#jnpar_cardshop#jnpar_cardshop')->open_or_not();
		if(!$flag)return;
		global $_G, $postlist,$thread;
		
		global $count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cardshop'];
		$open_toptip=$pvar['open_toptip'];
		if(!$open_toptip)return;
		$toptip_con=$pvar['toptip_con'];
		$gdiscount=$gdiscount<10?$gdiscount." &#25240;":'&#26080;';
		$mdiscount=$mdiscount<10?$mdiscount." &#25240;":'&#26080;';
		$toptip_con=str_replace(array('{count_need}','{count_toauthor}','{count_pay}','{gdiscount}','{mdiscount}'),array($count_need,$count_toauthor,$count_pay,$gdiscount,$mdiscount),$toptip_con);
		
		$return=array();
		$tid=$thread['tid'];
		$uid=intval($_G['uid']);
		$couldadmin=($uid==$thread['authorid'] or $_G['adminid']==1)?1:0;
		$uname=$_G['username']?$_G['username']:C::t('#jnpar_pay#jn_orderlog')->guestidentify();
		$logs=C::t('#jnpar_cardshop#cardshop_records')->cardlogs_by_uname($uname,$tid);
		foreach($postlist as $p){
			if($p['first']){
				include template('jnpar_cardshop:manage');
				$return[]=$manage;
			}else{
				$return[]='';
			}
		}
		return $return;
	}
}

class mobileplugin_jnpar_cardshop{
}

class mobileplugin_jnpar_cardshop_forum extends plugin_jnpar_cardshop_forum {
	
	function viewthread_top_mobile_output(){
		return $this->viewthread_top_output();
	}
	
	function  viewthread_posttop_mobile_output(){
		return $this->viewthread_posttop_output();
	}
}

