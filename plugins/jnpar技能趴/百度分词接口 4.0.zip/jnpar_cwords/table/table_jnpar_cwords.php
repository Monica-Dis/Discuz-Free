<?php
/*
 *	Copyright (c) 2021 by dism.taobao.com
 *	这不是一个免费的程序！由DISM.TAOBAO.COM提供技术支持，如需定制或者个性化修改插件，欢迎与我们联系。
 *  技术交流站dism·taobao·com 辅助推广，敬请访问惠临。
 *	最新插件：http://t.cn/Aiux1Jx1
 *	CURMODULE = 为模块自定义常量
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jnpar_cwords extends discuz_table
{
	public function __construct() {
		$this->_table = 'jnpar_cwords';
		$this->_pk    = '';
		parent::__construct(); /*dism - taobao - com*/
	}
	

	public function object_array($array) {  
		if(is_object($array)) {  
			$array = (array)$array;  
		 } if(is_array($array)) {  
			 foreach($array as $key=>$value) {  
				 $array[$key] = $this->object_array($value);  
			 }  
		 }  
		 return $array;  
	}
	
	function getcwords($searchtxt,$maxlength){
		$maxlength=$maxlength?$maxlength:30;
		require_once DISCUZ_ROOT . "./source/plugin/jnpar_cwords/AipNlp.php";
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$pvar=$_G['cache']['plugin']['jnpar_cwords'];
		
		$baidu_app_id = $pvar['baidu_app_id'];
		$baidu_api_key = $pvar['baidu_api_key'];
		$baidu_secret_key = $pvar['baidu_secret_key'];
		
		if(strtolower(CHARSET) == 'gbk'){
			$text =mb_substr($searchtxt,0,$maxlength,'GBK');
			//$text=iconv('GBK','UTF-8',$text);
			//debug($text);
		}else{
			$text =mb_substr($searchtxt,0,$maxlength,'utf-8');
			//$text=iconv('GBK','UTF-8',$text);
		}
		$chi=preg_replace('/([a-zA-Z\-]+)/i',' ',$text);//获取中文\英文
		if(strtolower(CHARSET) == 'gbk'){
			$en=preg_replace('/(['.chr(0xa1)."-".chr(0xff).'0-9])/',' ',$text);
		}else{
			$en=preg_replace('/([\x{4e00}-\x{9fa5}0-9\-])/u',' ',$text);
		}
		$chi=preg_replace("/\s(?=\s)/","\\1",trim($chi));
		$en=preg_replace("/\s(?=\s)/","\\1",trim($en));
		
		$en_arr=explode(' ',$en);
		
		foreach($en_arr as $k=>$v){
			if(!trim($v))continue;
			$en_arr[$k]=array('pos'=>'en-z','item'=>$v);
		}
		$client = new AipNlp($baidu_app_id, $baidu_api_key, $baidu_secret_key);
		// 调用词法分析
		if(strtolower(CHARSET) == 'gbk')$chi=iconv('GBK','UTF-8',$chi);
		if(trim($chi))$chi_arr=$client->lexer($chi);
		if(strtolower(CHARSET) == 'gbk'){
			$chi_arr = eval('return '.iconv('utf-8','gb2312',var_export($chi_arr,true)).';');
			//$en_arr = eval('return '.iconv('utf-8','gb2312',var_export($en_arr,true)).';');
		}
		
		if(!$chi_arr)$chi_arr['items']=array();
		$keywords_info=$chi_arr;
		$keywords_info['items']=array_merge($en_arr,$chi_arr['items']);
		return $keywords_info;
	}
	
}