<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}

class plugin_saya_pansource {
}
//脚本嵌入点类
class plugin_saya_pansource_forum extends plugin_saya_pansource {
	function post_top(){
		include template("saya_pansource:post_top");
		return $post_top;
	}
	
	function post_bottom(){
		global $_G;
		$groups = C::t( "common_usergroup" )->fetch_all_by_type( '', null, true );
		foreach($groups as $value){
			if($value['type']!='system'){
				$grouparray[$value['groupid']]=$value;
			}
		}
		$grouplevel=explode("<",$_G['cache']['plugin']['saya_pansource']['grouplevel']);
		foreach($grouplevel as $value){
			if($value==="normal"){
				$options.='<option value="alluser">'.lang("plugin/saya_pansource","pan_alluser").'</option>';
			}else{
				$options.='<option value="'.$value.'">'.$grouparray[$value]['grouptitle'].lang("plugin/saya_pansource","pan_groupand").'</option>';
			}
		}
		include template("saya_pansource:post_top");
		return $post_bottom;
	}
	function post_editorctrl_left(){
		return '<a id="e_pan" title="'.lang("plugin/saya_pansource","pansource").'" href="javascript:;">'.lang("plugin/saya_pansource","pan").'</a>';
	}
	function viewthread_postbottom_output(){
		global $_G,$postlist;
		$grouplevel=explode("<",$_G['cache']['plugin']['saya_pansource']['grouplevel']);
		$style=$_G['cache']['plugin']['saya_pansource']['style'];
		foreach($postlist as $key => $value){
			if(preg_match_all("/\[(pansource link[^\]]+)\]\[\/pansource\]/i",$value['message'],$match)){
				//print_r($value);
				foreach($match[1] as $key2 =>$value2){
					$explodetemp1=explode(" ",$value2);
					$link=explode("=",$explodetemp1[1]);
					$link='<a href="'.$link[1].'" target="_blank" rel="nofollow">'.$link[1].'</a>';
					$code=explode("=",$explodetemp1[2]);
					$code=$code[1];
					if($code=="") $code=lang("plugin/saya_pansource","nocode");
					$group=explode("=",$explodetemp1[3]);
					$group=$group[1];
					include template("saya_pansource:messagereplace");
					if($_G['adminid']>0){
						$messagereplace=$allow;
					}elseif($group=="allgroup"){
						$messagereplace=$allow;
					}elseif($value['authorid']==$_G['uid']){
						$messagereplace=$allow;
					}else{
						if($group=="alluser") $group="normal";
						$level_system=array_search($group,$grouplevel);
						$levelme=(array_search($_G['groupid'],$grouplevel)!==false)?array_search($_G['groupid'],$grouplevel):array_search("normal",$grouplevel);
						if($levelme>=$level_system){
							$messagereplace=$allow;
						}else{
							$messagereplace=$notallow;
						}
					}
					$postlist[$key]['message']=str_replace($match[0][$key2],$messagereplace,$postlist[$key]['message']);
				}
			}
		}
		return;
	}
}

class mobileplugin_saya_pansource{
}
class mobileplugin_saya_pansource_forum extends mobileplugin_saya_pansource{
	function viewthread_postbottom_monile_output(){
		global $_G,$postlist;
		$grouplevel=explode("<",$_G['cache']['plugin']['saya_pansource']['grouplevel']);
		$style=$_G['cache']['plugin']['saya_pansource']['style'];
		foreach($postlist as $key => $value){
			if(preg_match_all("/\[(pansource link[^\]]+)\]\[\/pansource\]/i",$value['message'],$match)){
				foreach($match[1] as $key2 =>$value2){
					$explodetemp1=explode(" ",$value2);
					$link=explode("=",$explodetemp1[1]);
					$link='<a href="'.$link[1].'" target="_blank" rel="nofollow">'.lang("plugin/saya_pansource","clicktojump").'</a>';
					$code=explode("=",$explodetemp1[2]);
					$code=$code[1];
					if($code=="") $code=lang("plugin/saya_pansource","nocode");
					$group=explode("=",$explodetemp1[3]);
					$group=$group[1];
					include template("saya_pansource:messagereplace");
					if($_G['adminid']>0){
						$messagereplace=$allow;
					}elseif($group=="allgroup"){
						$messagereplace=$allow;
					}elseif($value['authorid']==$_G['uid']){
						$messagereplace=$allow;
					}else{
						if($group=="alluser") $group="normal";
						$level_system=array_search($group,$grouplevel);
						$levelme=(array_search($_G['groupid'],$grouplevel)!==false)?array_search($_G['groupid'],$grouplevel):array_search("normal",$grouplevel);
						if($levelme>=$level_system){
							$messagereplace=$allow;
						}else{
							$messagereplace=$notallow;
						}
					}
					$postlist[$key]['message']=str_replace($match[0][$key2],$messagereplace,$postlist[$key]['message']);
				}
			}
		}
		return;
	}
}
//From: Dism_taobao-com
?>