<?php
/**
*
* ajax异步查询订单是否完成
* 
**/ 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderNum=$_GET['orderNum']?$_GET['orderNum']:'111';

$status=DB::result_first("select status from %t where `order`=%s",array('jn_orderlog',$orderNum));

if($status==1){
	echo 1;
}else{
	echo 0;
}