<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jn_orderlog` (
  `oid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `clientip` varchar(40) NOT NULL,
  `price` varchar(10) NOT NULL,
  `realprice` varchar(10) NOT NULL,
  `order` varchar(40) NOT NULL,
  `type` tinyint(2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL DEFAULT '0',
  `paytype` tinyint(2) NOT NULL DEFAULT '0',
  `buyid` int(10) NOT NULL,
  `pl_ordernum` varchar(40) NOT NULL DEFAULT '0',
  `tradeno` varchar(40) NOT NULL,
  `commodityName` varchar(50) NOT NULL,
  `commodityDesc` text NOT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `remark1` varchar(20) NOT NULL,
  `touid` int(10) NOT NULL,
  `drawed` tinyint(1) NOT NULL DEFAULT '0',
  `relateid1_type` varchar(20) NOT NULL,
  `relateid2_type` varchar(20) NOT NULL,
  `relateid1` int(11) NOT NULL,
  `relateid2` int(11) NOT NULL,
  `time1` int(10) NOT NULL DEFAULT '0',
  `time2` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`oid`),
  KEY `uid` (`uid`),
  KEY `uname` (`uname`),
  KEY `status` (`status`),
  KEY `type` (`type`),
  KEY `buyid` (`buyid`),
  KEY `order` (`order`),
  KEY `touid` (`touid`),
  KEY `relateid1_type` (`relateid1_type`),
  KEY `relateid2_type` (`relateid2_type`),
  KEY `relateid1` (`relateid1`),
  KEY `relateid2` (`relateid2`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jn_payapps` (
  `logid` int(5) NOT NULL AUTO_INCREMENT,
  `buytype` int(5) NOT NULL,
  `appid` varchar(30) NOT NULL,
  `version` varchar(10) NOT NULL,
  `installtime` int(10) NOT NULL,
  `paras` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  PRIMARY KEY (`logid`),
  UNIQUE KEY `buytype` (`buytype`,`appid`),
  KEY `version` (`version`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>