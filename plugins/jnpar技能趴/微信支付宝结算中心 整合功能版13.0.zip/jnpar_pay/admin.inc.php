<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;

if(empty($_G['cache']['plugin']['jnpar_pay'])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin']['jnpar_pay'];

$get=daddslashes($_GET);

$appurl=$_G['siteurl'].ADMINSCRIPT."?action=plugins&operation=config&do={$plugin['pluginid']}&identifier={$plugin['identifier']}&pmod={$get['pmod']}";
$p=$get['p'];
$p=$p?$p:'index';
$formhash=$get['formhash'];

if(submitcheck('deletesubmit')){
	$del_c=dintval($_GET['del_c'],true);
	
	$condition=DB::field('oid',$del_c);
	DB::delete('jn_orderlog',$condition);
	cpmsg("&#21024;&#38500;&#25104;&#21151;",'action=plugins&operation=config&do={$pluginid}&identifier=jnpar_pay&pmod=admin');
}

elseif($p=='index'){
	$pagenum=20;
	$page=max(1,intval($get['page']));
	$begin=($page-1)*$pagenum;
	$where=$pageadd='';
	$order=$get['order'];
	$uid=intval($get['uid']);
	
	$wherezd=array();
	$pageadd="formhash=".FORMHASH;
	if($order and $formhash==FORMHASH){
		$wherezd[]="`order`='$order'";
		$pageadd.="&order=".$order;
	}
	if($uid and $formhash==FORMHASH){
		$wherezd[]="`uid`='$uid'";
		//$suserurl=urlencode($suser);
		$pageadd="uid='$uid'";
	}
	$where=" where status<>0";
	if(!empty($wherezd)){
		$where.=" and ".join(" and ",$wherezd);
	}
	//debug($where);
	$manylist=array();

	if(empty($wherezd)){
		$manylist=DB::fetch_all('select *,count(*) as bnum from %t %i group by uid order by createtime DESC limit %d,%d',array("jn_orderlog",$where,$begin,$pagenum));	
		$allnum=DB::result_first("select count(distinct uid) as num from %t %i",array("jn_orderlog",$where));
	}else{
		$rs=DB::query("SELECT * FROM ".DB::table("jn_orderlog")." $where order by oid desc LIMIT $begin , $pagenum");
		while ($rw=DB::fetch($rs)) {
			$manylist[]=$rw;
		}
		$allnum=DB::result_first("SELECT count(*) FROM ".DB::table("jn_orderlog")." $where");
	}
	
	
	$pagenav=multi($allnum,$pagenum,$page,$appurl."&p=$p".$pageadd);

}elseif($p=='del' && $formhash==FORMHASH){
	DB::delete("jn_orderlog",array('oid'=>$_GET["oid"]));
	cpmsg("&#21024;&#38500;&#25104;&#21151;",'action=plugins&operation=config&do={$pluginid}&identifier=jnpar_pay&pmod=admin');
	
}

//elseif ($p==''){}
else cpmsg('&#26410;&#23450;&#20041;&#25805;&#20316;&#65281;');

include(template($plugin['identifier'].":".$_GET['pmod']."_".$p));
?>