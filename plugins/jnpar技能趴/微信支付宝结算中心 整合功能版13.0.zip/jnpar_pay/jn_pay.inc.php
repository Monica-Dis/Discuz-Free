<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
global $_G;

$siteurl = $_G['siteurl'];
$sitename = $_G['setting']['sitename'];
$username=$_G['username'];
$uid=$_G['uid']?$_G['uid']:0;
//debug($_G['clientip']);
if(empty($_G['cache']['plugin'][$identifier])){
	loadcache('plugin');
}
$pvar=$_G['cache']['plugin'][$identifier];

$appid=$_GET['appid'];
if($appid){
	$para_arr=C::t('#jnpar_pay#jn_orderlog')->getparas();
	$tid=$para_arr[0];
	$has_record=$para_arr[1];
	$authorid=$para_arr[2];
	$count_need=$para_arr[3];
	$count_toauthor=$para_arr[4];
	$pid=$para_arr[5];
	$payways=$para_arr[6];
	$allow_guestpay=$para_arr[7];
	$appcheck=C::t("#$appid#$appid")->appcheck($para_arr);
}

$pay_pre=C::t('#jnpar_pay#jn_orderlog')->get_pre_creditset();
$payc=$pay_pre['payc'];
$paycr=$pay_pre['paycr'];
$paycw=$pay_pre['paycw'];

$pay_banks=C::t('#jnpar_pay#jn_orderlog')->get_pay_methods($payways);
$pay_bank1=$pay_banks['pay_bank1'];
$extc_buy=$pvar['extc_buy'];
$exc_unit=$_G['setting']['extcredits'][$extc_buy]['unit'].$count.$_G['setting']['extcredits'][$extc_buy]['title'];

$pay_credit=$pvar['pay_credit'];
$pay_unit=$_G['setting']['extcredits'][$pay_credit]['unit'].$count.$_G['setting']['extcredits'][$pay_credit]['title'];
$credit_r=$pvar['credit_r'];
$pay_extname='extcredits'.$pay_credit;
$ubalance=intval(getuserprofile($pay_extname));

$groupbuyset=C::t('#jnpar_pay#jn_orderlog')->conftoarray_vip();
$money_on=$pvar['money_on'];

$payconfig=C::t('#jnpar_pay#jn_orderlog')->load_pay_config();
$alipay_config = $payconfig['alipay_config'];

$charset=strtolower(CHARSET)=='gbk'?'GBK':'UTF-8';
$in_weixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false?1:0;
$isMobile = checkmobile();

$handletype=array('1'=>lang('plugin/jnpar_pay', 't16'),'2'=>lang('plugin/jnpar_pay', 't17'),'3'=>lang('plugin/jnpar_pay', 't18'));//1会员办理 2购买邀请码 3积分充值
$handletitle=array('1'=>lang('plugin/jnpar_pay', 't19'),'2'=>lang('plugin/jnpar_pay', 't20'),'3'=>lang('plugin/jnpar_pay', 't21'));//1选择办理类型 2邀请码价格 3金额选择
$handletype[0]=$handletype[3];//默认值
$handletitle[0]=$handletitle[3];

$template_style=($pvar['template_style'] and !$isMobile)?$pvar['template_style']:'default';
$inv_mailsend=$pvar['inv_mailsend'];

$unitprice=$pvar['unitprice'];
$inviteprice=$pvar['inviteprice'];
$invitec=$inviteprice*$unitprice;
$price=C::t('#jnpar_pay#jn_orderlog')->get_price(intval($_GET['buykey']),intval($_GET['buyid']),$count_need);
$needcredits=ceil($price*$credit_r);//积分向上取整
if($ubalance<$needcredits)$cnotenough=1;
//debug($ubalance);
$get=dhtmlspecialchars($_GET);
$paytype=$get["paytype"];
$buykey=intval($get['buykey']);
$buyid=intval($get["buyid"]);
if($buykey==2)$allow_guestpay=1;

if($in_weixin){
	require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.JsApiPay.php';
	$tools = new JsApiPay();
}
if(!submitcheck('button')){	
	
	if($in_weixin){
		$openId = $tools->GetOpenid();
	}
	//根据uid和$guestidentify获取用户购买的邀请码
	$buyed_invitecodes=C::t('#jnpar_pay#jn_orderlog')->buyed_invitecodes();
	
	if(!$_GET['appid'] and ($_GET["buykey"]=="" and $_GET["paytype"]=="")){
		include template("diy:index_".$template_style,0,'source/plugin/jnpar_pay/template');
	}elseif($_GET["paytype"]==""){
		//if(!$uid and $_GET["buykey"]!=2)showmessage('to_login', NULL, array(), array('login' => 1));
		$selwidth=sizeof($pay_bank1)*140;
		include(template("jnpar_pay:selectpay"));
	}
}else{
	if(!$uid and !$allow_guestpay)showmessage('&#27492;&#25805;&#20316;&#38656;&#35201;&#30331;&#24405;');//此操作需要登录
	if($paytype==3 and $cnotenough)showmessage('&#25903;&#20184;&#31215;&#20998;&#19981;&#36275;&#65292;&#35831;&#36873;&#25321;&#20854;&#20182;&#25903;&#20184;&#26041;&#24335;');
	if(!$buykey and !$get['appid'])showmessage(lang('plugin/jnpar_pay', 't7'));
	if(!$paytype)showmessage('&#35831;&#36873;&#25321;&#25903;&#20184;&#26041;&#24335;');
	if(!in_array($paytype,$pay_bank1))showmessage('&#25903;&#20184;&#26041;&#24335;&#38169;&#35823;&#65292;&#35831;&#37325;&#26032;&#36873;&#25321;');
	
	
	if(!$get['appid']){//充值应用,appid为应用标识，方便对接【技能趴】其他应用支付
		if($buykey==3){//充值
			$ccount=$buyid;
			//判断数据合法性
			if($ccount<=0)showmessage(lang('plugin/jnpar_pay', 't8'));
			if(!$money_on and !in_array($ccount,$paycr))showmessage(lang('plugin/jnpar_pay', 't9'));
			
			//debug($price);
			$transMoney=$ccount;//积分数
			$commodityName=lang('plugin/jnpar_pay', 't10');
			$desc=$sitename.'-'.lang('plugin/jnpar_pay', 't10').'-'.$ccount.$exc_unit;
			$orderNum=C::t('#jnpar_pay#jn_orderlog')->createorder($uid,$buykey,$paytype,$price,$ccount,$commodityName,$desc);
			$return_url=$siteurl.'home.php?mod=spacecp&ac=credit&showcredit=1';
		}elseif($buykey==1){//开通vip
			if($_G['adminid']==1)showmessage(lang('plugin/jnpar_pay', 't15'));
			$vipk=$buyid;
			$commodityName=lang('plugin/jnpar_pay', 't12');
			$desc=$sitename.'-'.lang('plugin/jnpar_pay', 't11').'-'.$groupbuyset[$buyid][4];
			$orderNum=C::t('#jnpar_pay#jn_orderlog')->createorder($uid,$buykey,$paytype,$price,$vipk,$commodityName,$desc);
			$return_url=$siteurl.'home.php?mod=spacecp&ac=usergroup';
		}elseif($buykey==2){//购买邀请码
			$remarks=$get['remarks'];//邮箱
			$commodityName=lang('plugin/jnpar_pay', 't14');
			$desc=$sitename.'-'.lang('plugin/jnpar_pay', 't13');
			$orderNum=C::t('#jnpar_pay#jn_orderlog')->createorder($uid,$buykey,$paytype,$price,$buyid,$commodityName,$desc,$remarks);
			$return_url=$siteurl.'plugin.php?id=jnpar_pay:jn_pay&tab=2';
		}	
	}else{
		$appreturn=C::t("#$appid#$appid")->genorder($para_arr,$paytype);
		$commodityName=$appreturn['commodityName'];
		$desc =$appreturn['desc'];
		$orderNum=$appreturn['orderNum'];
		$return_url=$appreturn['return_url'];
	}
	
    //商户订单号，商户网站订单系统中唯一订单号，必填
    $out_trade_no = $orderNum;
    //订单名称，必填
    $subject = $commodityName;
    //付款金额，必填
    $total_amount = $price;
    //商品描述，可空
    $body = $desc;
	
	$amount = doubleval($price);
	if($paytype==1){//支付宝
		if(!$pvar['isf2f']){
			require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/alipay/pagepay/service/AlipayTradeService.php';
			require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/alipay/pagepay/buildermodel/AlipayTradePagePayContentBuilder.php';
			require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/alipay/pagepay/buildermodel/AlipayTradeWapPayContentBuilder.php';
			if(!$isMobile){
				$payRequestBuilder = new AlipayTradePagePayContentBuilder();
			}else{
				$payRequestBuilder = new AlipayTradeWapPayContentBuilder();
			}
			$payRequestBuilder->setBody($body);
			$payRequestBuilder->setSubject($subject);
			$payRequestBuilder->setTotalAmount($total_amount);
			$payRequestBuilder->setOutTradeNo($out_trade_no);

			$aop = new AlipayTradeService($alipay_config);
			if(!$isMobile){
				$response = $aop->pagePay($payRequestBuilder,$return_url,$alipay_config['notify_url']);
			}else{
				$response=$aop->wapPay($payRequestBuilder,$return_url,$alipay_config['notify_url']);
			}
			//输出表单
			var_dump($response);			
		}else{
			$url2=C::t('#jnpar_alif2f#jnpar_alif2f')->alif2furl($total_amount,$out_trade_no,$subject,$body,$alipay_config);
			if(!$isMobile){
				include template("jnpar_alif2f:alicash");
			}else{
				dheader('Location:'.$url2);
			}
			exit();
		}
	}elseif($paytype==2){
		if(!$pvar['open_payjs']){
			require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.Api.php';
			require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/lib/WxPay.NativePay.php';
			$notify = new NativePay();

			$body1 =$charset=='GBK'?iconv("GB2312","UTF-8",$desc):$desc;
			$total_fee = intval(doubleval($amount)*100);
			$product_id = $buykey."_".$buyid;
			$attach1 = $charset=='GBK'?iconv("GB2312","UTF-8",$commodityName):$commodityName;
			$out_trade_no = $orderNum;


			$input = new WxPayUnifiedOrder();
			$input->SetBody($body1);
			$input->SetAttach($attach1);
			$input->SetOut_trade_no($out_trade_no);
			$input->SetTotal_fee($total_fee);
			$input->SetTime_start(date("YmdHis"));
			$input->SetTime_expire(date("YmdHis", time() + 600));
			$input->SetGoods_tag("jnpar");
			$input->SetNotify_url($siteurl."source/plugin/jnpar_pay/wxnotify.php");
			$input->SetProduct_id($product_id);
			if($isMobile and !$in_weixin){
				$input->SetTrade_type("MWEB");
				$input->SetScene_info('{"h5_info": {"type":"Wap","wap_url": "'.$siteurl.'","wap_name": "dz"}}');
				$result = $notify->GetH5PayUrl($input);
				$url2 =$result["code_url"]?$result["code_url"]:$result["mweb_url"];
				//dheader("Location:".$url2.'&redirect_url='.urlencode($return_url));
				dheader("Location:".$url2);
			}elseif($in_weixin){
				$openId=$get['openId'];
				//debug($openId);
				$input->SetTrade_type("JSAPI");
				$input->SetOpenid($openId);
				$config = new WxPayConfig();
				$order = WxPayApi::unifiedOrder($config, $input);
				$jsApiParameters = $tools->GetJsApiParameters($order);
				//获取共享收货地址js函数参数
				$editAddress = $tools->GetEditAddressParameters();
				include template("jnpar_pay:jsapi");
			}else{
				$input->SetTrade_type("NATIVE");
				$result = $notify->GetPayUrl($input);
				$url2 = $result["code_url"];
				include template("jnpar_pay:wxcash");
			}
		}else{
			$pvar1=$_G['cache']['plugin']['jnpar_payjs'];
			if(empty($pvar1) or !file_exists(DISCUZ_ROOT.'./source/plugin/jnpar_payjs/sdk.class.php')){
				showmessage(lang('plugin/jnpar_pay', 'add26'));
			}
			include_once(DISCUZ_ROOT.'./source/plugin/jnpar_payjs/sdk.class.php');
			global $payjs;
			$payjs = array(
				'mchid'=>$pvar1['mchid'],
				'key'=>$pvar1['key'],
			);
			$payapp = new Payjs();
			$result = $payapp->pay($price,$orderNum,$siteurl."source/plugin/jnpar_payjs/payjsnotify.php",$isMobile);
			$result=json_decode($result,true);
			if($isMobile){// and !$in_weixin
				$url2 = $result["code_url"];
				dheader("Location:".$url2);
			}else{
				$url2 = $result["code_url"];
				include template("jnpar_pay:wxcash");
			}
		}
	}elseif($paytype==3){
		$out_trade_no = $orderNum;
		$trade_no = 'creditpay_'.$orderNum;
		$trade_status = 'success';
		$realprice= $needcredits.$pay_unit;
		updatemembercount($uid,array($pay_extname => -$needcredits),true, '', '',  $commodityName, lang('plugin/jnpar_pay', 't22'),$desc);
		C::t('#jnpar_pay#jn_orderlog')->updateorder($out_trade_no,'',$trade_no,$realprice);
		showmessage('&#36141;&#20080;&#25104;&#21151;',$return_url);
	}
}