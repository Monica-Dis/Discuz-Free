<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 */
$_POST['fund_bill_list']=htmlspecialchars($_POST['fund_bill_list']);
define('IN_API', true);
define('APPTYPEID', 102);
define('CURSCRIPT', 'alinotify');
define('CURMODULE', 'index');
require '../../../source/class/class_core.php';
$discuz = C::app();
//$discuz->reject_robot();
$discuz->init();

$_POST['fund_bill_list']=htmlspecialchars_decode($_POST['fund_bill_list']);

//$str=C::t('#jnpar_pay#jn_orderlog')->createLinkstring($_POST);
//C::t('#jnpar_pay#jn_orderlog')->logResult($str);

$payconfig=C::t('#jnpar_pay#jn_orderlog')->load_pay_config();
$alipay_config = $payconfig['alipay_config'];

require_once DISCUZ_ROOT.'./source/plugin/jnpar_pay/alipay/pagepay/service/AlipayTradeService.php';

$arr=$_POST;
$alipaySevice = new AlipayTradeService($alipay_config); 
$alipaySevice->writeLog(var_export($arr,true));

$result = $alipaySevice->check($arr);
if($result) {//验证成功
	
	$out_trade_no = $_POST['out_trade_no'];
	$trade_no = $_POST['trade_no'];
	$trade_status = $_POST['trade_status'];
	$realprice= $_POST['total_amount'];
	if($trade_status == 'TRADE_SUCCESS'){
		C::t('#jnpar_pay#jn_orderlog')->updateorder($out_trade_no,'',$trade_no,$realprice);
	}
    
	echo "success";	//请不要修改或删除
}else {
    //验证失败
    echo "fail";
}
