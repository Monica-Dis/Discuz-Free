<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php 24473 2011-09-21 03:53:05Z monkey $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS pre_jn_orderlog;
EOF;

runquery($sql);

$finish = TRUE;