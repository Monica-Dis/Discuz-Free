<?php

/*
 *	[DisM!] (C)2019-2020 DISM.Taobao.COM.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}


class mobileplugin_jnpar_mobilesort{
	function open_or_not(){
		global $_G;
		$fid=$_G['fid'];
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_mobilesort'];
		$openfids=unserialize($var['open_fids']);
		if(in_array($fid,$openfids)){
			return true;
		}else{
			return false;
		}
	}
}

class mobileplugin_jnpar_mobilesort_forum extends mobileplugin_jnpar_mobilesort {
	function forumdisplay_top_mobile_output(){
		$flag=$this->open_or_not();
		if(!$flag)return;
		
		global $_G,$sortoptionarray, $templatearray,$sortid, $threadids, $verify,$sorttemplate;
		if(!$sortid)return;
		
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_mobilesort'];
		$templatemod=$var['forumlistmod'];
		if($templatemod==1){//�Ƿ���pc�˹���һ��ģ��
			$templatearray=$templatearray;
		}elseif($templatemod==2 and $template=trim(C::t('#jnpar_mobilesort#mobilesort_template')->fetch_template1_by_sortid($sortid))){//ʹ���ֻ������ģ��
			$template=htmlspecialchars_decode($template);
			$templatearray=array("$sortid"=>$template);
		}
		
		require_once libfile('function/forumlist');
		$sorttemplate = showsortmodetemplate($sortid, $_G['fid'], $sortoptionarray, $templatearray, $_G['forum_threadlist'], $threadids, $verify);
		return;
		
	}
	function viewthread_bottom_mobile_output(){
		$flag=$this->open_or_not();
		if(!$flag)return;
		
		global $_G,$threadsortshow,$thread,$postlist;
		$sortid=$thread['sortid'];
		$typetitle=$_G['forum']['threadsorts']['types'][$sortid];
		$typedesc=$_G['forum']['threadsorts']['description'][$sortid];
		
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$var=$_G['cache']['plugin']['jnpar_mobilesort'];
		$templatemod=$var['templatemod'];
		
		if($templatemod==1){//�Ƿ���pc�˹���һ��ģ��
			$template=$threadsortshow['typetemplate'];
		}elseif($templatemod==2){//ʹ���ֻ������ģ��
			$template=C::t('#jnpar_mobilesort#mobilesort_template')->fetch_template_by_sortid($sortid);
		}else{//ʹ��Ĭ��ģ��
			$template='';
		}
		
		$check=intval($_GET['check']);
		if(!$template or $check){
			$sortcon='<div style="padding:5px;"><div style="background: #E5EDF2;border-top: 1px solid #C2D5E3;font-size: 14px;font-weight:700;line-height:30px; padding-left:5px;">'.$typetitle.'</div><table cellpadding="0" cellspacing="0" style="width:100%;"><tbody>';
			foreach($threadsortshow['optionlist'] as $sk=>$s){
				if($s['type']=='image'){//�ֻ���ͼƬ���ͻ�������������ʽ��ʾ���˴�ת����ͼƬ��ʽ
					$preg='/<a href="(.+?)"/';
					preg_match($preg,$s['value'],$imgarr);
					$img=$imgarr[1];
					$s['value']=str_replace(lang('plugin/jnpar_mobilesort', 'hook1'),'<img src="'.$img.'" width="96%"/>',$s['value']);
				}
				$sortcon.='<tr style="border-bottom:1px solid #C2D5E3;"><th style="text-align:right;padding-right:5px; width:80px;">'.$s['title'].':</th><td style="background:white; padding:3px;">'.$s['value'].' '.$s['unit'].'</td></tr>';
			}
			$sortcon.='</tbody></table></div>';
		}else{
			$sortcon=htmlspecialchars_decode($template);
			foreach($threadsortshow['optionlist'] as $sk=>$s){
				if($s['type']=='image'){//�ֻ���ͼƬ���ͻ�������������ʽ��ʾ���˴�ת����ͼƬ��ʽ
					$preg='/<a href="(.+?)"/';
					preg_match($preg,$s['value'],$imgarr);
					$img=$imgarr[1];
					$s['value']=str_replace(lang('plugin/jnpar_mobilesort', 'hook1'),'<img src="'.$img.'" width="96%"/>',$s['value']);
				}
				$sortcon=str_replace(array('{'.$sk.'}','{'.$sk.'_value}','{'.$sk.'_unit}'),array($s['title'],$s['value'],$s['unit']),$sortcon);
			}
		}
		foreach($postlist as $pid=>$p){
			if($p['first']!=1)return;
			$postlist[$pid]['message']=$sortcon.' '.$p['message'];
		}
	}
	
}

