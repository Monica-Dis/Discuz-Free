<?php

/*
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	�ⲻ��һ����ѵĳ�����DISM.TAOBAO.COM�ṩ����֧�֣����趨�ƻ��߸��Ի��޸Ĳ������ӭ��������ϵ��
 *  ��������վdism.taobao.com �����ƹ㣬������ʻ��١�
 *	$_G['basescript'] = ģ������
 *	CURMODULE = Ϊģ���Զ��峣��
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

global $_G;
if(!$_G['uid']){
	return;	
}
if(submitcheck('button')){
	$fid=$_G['fid'];
	$post=dhtmlspecialchars($_GET);
	if(empty($_G['cache']['plugin'])){
		loadcache('plugin');
	}
	$var_jnpar_floormessage=$_G['cache']['plugin']['jnpar_floormessage'];
	//@extract($var_jnpar_floormessage);
	$adminids=$var_jnpar_floormessage['adminids'];
	$titlecon=$var_jnpar_floormessage['titlecon'];
	//@extract($post);
	$pid=$post['pid'];
	$suber=$post['suber'];
	$suberid=$post['suberid'];
	$suberid=$post['suberid'];
	$fmessage=$post['fmessage'];
	
	$floorm='forum.php?mod=redirect&goto=findpost&ptid=0&pid='.$pid;
	$subject=lang('plugin/jnpar_floormessage', 'sm1').$suber.lang('plugin/jnpar_floormessage', 'sm2');
	$fromid=$suberid;
	$adminids=explode(',',$adminids);
	$mcon=lang('plugin/jnpar_floormessage', 'sm3')."<a href=".$floorm.">".$floorm."</a><br/>".lang('plugin/jnpar_floormessage', 'sm4')."<a href='home.php?mod=space&uid=".$fromid."&do=profile'>$suber</a><br/>".lang('plugin/jnpar_floormessage', 'sm5').$fmessage;

	foreach($adminids as $toid){
		notification_add($toid, 'system', $mcon);
	}
}else{
	$pid=intval($_GET['pid']);
	if(empty($_G['cache']['plugin'])){
		loadcache('plugin');
	}
	$suber=$_G['username'];
	$suberid=$_G['uid'];
	//debug($_G);
	$var_jnpar_floormessage=$_G['cache']['plugin']['jnpar_floormessage'];
	//@extract($var_jnpar_floormessage);
	$adminids=$var_jnpar_floormessage['adminids'];
	$titlecon=$var_jnpar_floormessage['titlecon'];
	include template('jnpar_floormessage:enter');
}
