<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_reward/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '';
		cpmsg("updatecacheing", "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':
		$sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_wq_reward_look_tids` (
        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `uid` int(10) unsigned NOT NULL,
        `tid` int(10) unsigned NOT NULL,
        `pid` int(10) unsigned NOT NULL,
        `money` decimal(8,2) NOT NULL,
        `dateline` int(10) unsigned NOT NULL,
        PRIMARY KEY (`id`),
        KEY `id` (`id`),
        KEY `tid` (`tid`),
        KEY `pid` (`pid`)
    ) ENGINE=MyISAM;
EOF;
		runquery($sql);

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_reward_cash_info'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('phone', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_reward_cash_info') . " ADD `phone` varchar(13) NOT NULL;";
			DB::query($sql);
		}
		if($_GET['fromversion'] <= 3.2) {
			$sql_record = "ALTER TABLE " . DB::table('wq_reward_record') . " ADD `pid` int(10) NOT NULL;";
			runquery($sql_record);
			$sql_rank = "ALTER TABLE " . DB::table('wq_reward_rank') . " ADD `pid` int(10) NOT NULL;";
			runquery($sql_rank);
		}
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//From: Dism_taobao-com
?>