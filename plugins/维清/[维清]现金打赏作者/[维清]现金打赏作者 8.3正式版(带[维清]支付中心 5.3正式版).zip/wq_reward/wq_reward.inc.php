<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_reward.inc.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "list";

$allowmod = array('list', 'pay', 'ajax', 'check');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_reward/' . $dirlist[$mod] . '/reward_' . $mod . '.php';

?>