<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_cashinfo.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';
if(!submitcheck('operationFom')) {
	if(!$_GET['id'] && $_GET['supop'] != 'update') {
		$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'desc';
		$audit_stutas = in_array($_GET['audit_stutas'], array('all', '1', '0', '-1')) ? (($_GET['audit_stutas'] != 'all') ? $_GET['audit_stutas'] : '') : '';
		$idcard = isset($_GET['idcard']) ? $_GET['idcard'] : '';
		$realname = isset($_GET['realname']) ? $_GET['realname'] : '';
		$alipay = isset($_GET['alipay']) ? $_GET['alipay'] : '';
		$page = max(1, $_GET['page']);
		$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 20;
		$start = ($page - 1 ) * $perpage;

		$re = C::t("#wq_reward#wq_reward_cash_info")->fetch_all_by_search($orderby, $audit_stutas, $idcard, $realname, $alipay, $start, $perpage);
		$count = C::t("#wq_reward#wq_reward_cash_info")->count_by_search($orderby, $audit_stutas, $idcard, $realname, $alipay);

		$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashinfo';

		$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashinfo';
		$mpurl .= $orderby ? "&orderby=" . $orderby : '';
		$mpurl .= $idcard ? "&idcard=" . $idcard : '';
		$mpurl .= $realname ? "&realname=" . $realname : '';
		$mpurl .= $audit_stutas !== '' ? "&audit_stutas=" . $audit_stutas : '';
		$mpurl .= $alipay ? "&alipay=" . $alipay : '';
		$url = ADMINSCRIPT . '?' . $mpurl;

		$order_by = select_html(array('asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'orderby', $orderby, false);
		$stutas = select_html(array('all' => $Plang['8dfe4b30674494c1'], '1' => $Plang['d4cd6471a700d52c'], '0' => $Plang['fcce7c30276aa190'], '-1' => $Plang['795bc6e16b0e0699']), 'audit_stutas', $audit_stutas, false);

		showformheader($fromurl, '', 'sub');
		showtableheader('', 'nobottom');
		showtablerow('', array(), array(
			$Plang['71d0ea93aeb5d451'] . $Plang['mh'] . $order_by
			. "&nbsp;&nbsp;" . $Plang['6ca3bd49d1814894'] . $Plang['mh'] . $stutas
			. "&nbsp;&nbsp;" . $Plang['9c000fc336da56e1'] . $Plang['mh'] . '<input type="text" name="alipay" value="' . dhtmlspecialchars($_GET['alipay']) . '" placeholder=' . $Plang['1cc8589f353133f6'] . '>'
			. "&nbsp;&nbsp;" . $Plang['27c46be656162c09'] . $Plang['mh'] . '<input type = "text" name = "realname" value = "' . dhtmlspecialchars($_GET['realname']) . '" placeholder = ' . $Plang['877374f5b48ce98f'] . '>'
			. "&nbsp;&nbsp;" . $Plang['4d8cc5a69fccadd5'] . $Plang['mh'] . '<input type = "text" name = "idcard" value = "' . dhtmlspecialchars($_GET['idcard']) . '" placeholder = ' . $Plang['6489123295cc01ed'] . '>'
			. "&nbsp;&nbsp;" . '<input id = "submit_forms" class = "btn" type = "submit" name = "sub" value = ' . $Plang['38224a4a6fc78c7c'] . ' title = ' . $Plang['b7bea550cb266984'] . '/>',
		));
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();

		$operation_url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashinfo';
		$status = array('0' => $Plang['fcce7c30276aa190'], '1' => $Plang['74a3053ecaf07e60'], '-1' => $Plang['7c49868ac52df584']);
		showtableheader('', 'nobottom');
		showsubtitle(array($Plang['2ea0a99c28da4028'], $Plang['9c000fc336da56e1'], $Plang['4d8cc5a69fccadd5'], $Plang['c2ae740b7eb73472'], $Plang['6ca3bd49d1814894'], $Plang['d4b99467dd5a9755'], $Plang['4e64f0e320d8b16b']));
		foreach($re as $key => $val) {
			if($val['status']) {
				$showContent = $Plang['8fe8024cd841091f'];
			} else {
				$showContent = "<a href='javascript:;' onclick='cash_operation({$val[id]});'>" . $Plang['c3e0fcd40c35eb5b'] . "</a>";
			}
			$dataline = wq_dgmdate($val["dateline"]);
			showtablerow('', array(), array(
				$val['realname'],
				$val['alipay'],
				$val['idcard'],
				$dataline,
				$status[$val['status']],
				$val['remark'],
				"<a href='" . $operation_url . "&id=" . $val['id'] . "&subop=update'>" . $Plang['update'] . "</a>&nbsp;&nbsp;&nbsp;" . $showContent
			));
		}
		$multi = multi($count, $perpage, $page, $url);
		echo "<tr><td colspan='14' align='right'>" . $multi . "</td></tr>";
		showtablefooter();/*Dism��taobao��com*/
	} else {
		$id = intval($_GET['id']);
		$data = C::t('#wq_reward#wq_reward_cash_info')->fetch($id);
		$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashinfo&act=update&id=' . $data['id'];
		showformheader($fromurl);
		showtableheader('');
		showtitle($Plang['user_cashinfo_update']);
		showsetting($Plang['2ea0a99c28da4028'], 'realname', $data['realname'], 'text');
		showsetting($Plang['9c000fc336da56e1'], 'alipay', $data['alipay'], 'text');
		showsetting($Plang['4d8cc5a69fccadd5'], 'idcard', $data['idcard'], 'text');
		showsubmit('operationFom');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	}
	$hash = FORMHASH;
	echo <<<EOF
    <style>
        #cash_operation{
            width:500px;
            height:200px;
            z-index: 201;
            background:#FFF;
            border:5px solid #CCC;
            border-radius: 8px 8px 8px 8px;
        }
        .flb {
            padding: 10px 10px 8px;
            height: 20px;
            line-height: 20px;
            border-bottom:2px solid #CCC;
        }
        .text_operation{
            text-align:center;
            margin-top:40px;
        }
        .operation_iut{
            border:1px solid #CCC;
            height:25px;
        }
        .explain_text{
            color:red;
            position: relative;
            top:35px;
            left:110px;
        }
    </style>
   <div id="cash_operation" style='display:none;
position:fixed;
left:600px;
top:200px;
' onmouseDown="mous_down(this)">
        <h3 class="flb" id="fctrl_reward_btn" style="cursor: move;">
            <em id="return_reward_btn" fwin="reward_btn">{$Plang['00c17f23d7cd0c3b']}</em>
            <span>
                <a href="javascript:;" class="flbc" onclick="cash_operation()" title={$Plang['beb08d096719774b']}>{$Plang['beb08d096719774b']}</a>
            </span>
        </h3>
        <form action='{$operation_url}' method='post'>
          <input type="hidden" name="formhash" value="{$hash}">
            <p id='explain_text' class='explain_text' style='display:none'>{$Plang['527c88da5bb0afdf']}</p>
            <p class='text_operation'>{$Plang['36603816bcb173c9']}{$Plang['mh']}<input name='explain_content' id='explain_content'type='text' placeholder={$Plang['dd46a4ebdb03f190']} class='operation_iut'>
            <input id='idVal' type='hidden' name='id'>
            <input id='pass' class='radio' type='radio' name='operation' value='1' checked><label for='editstatus_0' class = 'vmiddle' onclick='update_checked(true)'>{$Plang['74a3053ecaf07e60']}</label>
            <input id='reject' class='radio' type='radio' name='operation' value='-1'><label for='editstatus_1' class = 'vmiddle' onclick='update_checked(false)'>{$Plang['7c49868ac52df584']}</label>
            &nbsp;&nbsp;<input class='btn' type='submit' value={$Plang['6ce0cdd2f7c855aa']} name='operationFom' onclick='text_check()' title={$Plang['b7bea550cb266984']} /></p>
        </form>
   </div>
   <script type='text/javascript'>
        function cash_operation(id){
            var oDiv = document.getElementById('cash_operation');
            var idVal = document.getElementById('idVal');
            if(oDiv.style.display == 'block'){
                oDiv.style.display = 'none';
            }else{
                oDiv.style.display = 'block';
                idVal.value = id;
            }
        }

        function update_checked(t){
            var pass = document.getElementById('pass');
            var reject = document.getElementById('reject');
            var hint = document.getElementById('explain_text').style.display='none';
            if(t){
                pass.checked = 'true';
            }else{
                reject.checked = 'true';
            }
        }

        function text_check(){
            var hint = document.getElementById('explain_text');
            var conter = document.getElementById('explain_content');
            var reject = document.getElementById('reject').checked;
            if(!conter.value && reject){
                hint.style.display = 'block';
                window.event.returnValue = false;
            }
        }

        function mous_down(t){
            var obj = document.getElementById('cash_operation');
            var th = event.clientY - parseInt(obj.style.top.replace(/px/, ""));
            var tw = event.clientX - parseInt(obj.style.left.replace(/px/, ""));

            t.onmousemove = mouse_move;
            t.onmouseout = mous_out;
            t.onmouseup = mous_out;
            function mouse_move(){
                var event = window.event || t;
                var top = event.clientY - th;
                var left = event.clientX - tw;

                top = top < 0 ? 0 : top;
                top = top > document.body.offsetHeight? document.body.offsetHeight : top;

                left = left < 0 ? 0 : left;
                left = left > document.body.offsetWidth ? document.body.offsetWidth : left;

                obj.style.top = top + "px";
                obj.style.left = left + "px";
            }
            function mous_out(){
                t.onmousemove = null;
            }
        }
   </script>
EOF;
} else {
	if($_GET['act'] == 'update') {
		$data = array(
			'realname' => trim($_GET['realname']),
			'alipay' => trim($_GET['alipay']),
			'idcard' => trim($_GET['idcard'])
		);
		C::t("#wq_reward#wq_reward_cash_info")->update(intval($_GET['id']), $data);
	} else {
		$info = C::t("#wq_reward#wq_reward_cash_info")->fetch_by_id(intval($_GET['id']));
		$data = array(
			'remark' => $_GET['explain_content'],
			'status' => $_GET['operation']
		);
		if(!$data['remark'] && $data['status'] == 1) {
			$data['remark'] = $Plang['d4cd6471a700d52c'];
		}
		$msg = $data['status'] == 1 ? $Plang['74a3053ecaf07e60'] : $Plang['7c49868ac52df584'];
		send_message_admin(sprintf($Plang['0105d2fcb1616796'], $msg), $info['uid']);
		C::t("#wq_reward#wq_reward_cash_info")->update(intval($_GET['id']), $data);
	}
	cpmsg($Plang['aca2899ea8ef4a04'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashinfo', 'succeed');
}
//From: Dism_taobao-com
?>