function by_flag_get_content_url(s) {
	var start, end, cont, url, data;
	start = s.indexOf('####') + 4;
	end = s.indexOf('####', start);
	cont = s.slice(start, end);
	url = s.slice(end + 4, s.indexOf('####', end + 1));
	url = url.replace('|', ':');
	data = [cont, url];
	return data;
}

function set_Time_clear_popup(param) {
	setTimeout(function() {
		popup.close();
		if (param && param.length > 1) {
			window.location.href = param;
		}
	}, '1500');
}

function ajax_show_message(data) {
        var str = wqXml(data);
	obj = by_flag_get_content_url(str);
	var html = "<div class=\"ass_fl\"><dt id=\"messagetext\"><p>" + obj[0] + "</p></dt></div>";
	popup.open(html);
	set_Time_clear_popup(obj[1]);
}

var POPMENU = new Object;
var popup = {
	open: function(pop, type, url, noMask) {
		if (typeof pop == 'string') {
			$('#ntcmsg').remove();
			if (type == 'alert') {
				pop = '<div class="tip"><dt>' + pop + '</dt><dd><input class="button2" type="button" value="&#x786E;&#x5B9A;" onclick="popup.close();"></dd></div>'
			} else if (type == 'confirm') {
				pop = '<div class="tip"><dt>' + pop + '</dt><dd><input class="redirect button2" type="button" value="&#x786E;&#x5B9A;" href="' + url + '"><a href="javascript:;" onclick="popup.close();">&#x53D6;&#x6D88;</a></dd></div>'
			}

			$('body').append('<div id="ntcmsg" style="display:none;">' + pop + '</div>');
			pop = $('#ntcmsg');

		}
		if (POPMENU[pop.attr('id')]) {

			$('#' + pop.attr('id') + '_popmenu').html(pop.html()).css({'height': pop.height() + 'px', 'width': pop.width() + 'px'});
		} else {

			pop.parent().append('<div class="dialogbox" id="' + pop.attr('id') + '_popmenu" style="height:' + pop.height() + 'px;width:' + pop.width() + 'px;">' + pop.html() + '</div>');
		}
		var popupobj = $('#' + pop.attr('id') + '_popmenu');
		var left = (window.innerWidth - popupobj.width()) / 2;
		var top = (document.documentElement.clientHeight - popupobj.height()) / 2;
		popupobj.css({'display': 'block', 'position': 'fixed', 'left': left, 'top': top, 'z-index': 120, 'opacity': 1});
		if (!noMask) {

			$('#mask').css({'display': 'block', 'width': '100%', 'height': '100%', 'position': 'fixed', 'top': '0', 'left': '0', 'background': 'black', 'opacity': '0.2', 'z-index': '100'});
		}
		$('#ntcmsg').remove();
		POPMENU[pop.attr('id')] = pop;
	},
	close: function() {

		$('body').css('max-height', null);
		$('#mask').css('display', 'none');
		$.each(POPMENU, function(index, obj) {
			$('#' + index + '_popmenu').css('display', 'none');
		});
	}
};

var page = {
	converthtml: function() {
		var prevpage = $('div.pg .prev').prop('href');
		var nextpage = $('div.pg .nxt').prop('href');
		var lastpage = $('div.pg label span').text().replace(/[^\d]/g, '') || 0;
		var curpage = $('div.pg input').val() || 1;

		if (!lastpage) {
			prevpage = $('div.pg .pgb a').prop('href');
		}

		var prevpagehref = nextpagehref = '';
		if (prevpage == undefined) {
			prevpagehref = 'javascript:;" class="grey';
		} else {
			prevpagehref = prevpage;
		}
		if (nextpage == undefined) {
			nextpagehref = 'javascript:;" class="grey';
		} else {
			nextpagehref = nextpage;
		}

		var selector = '';
		if (lastpage) {
			selector += '<a id="select_a" style="margin:0 2px;padding:1px 0 0 0;border:0;display:inline-block;position:relative;width:100px;height:31px;line-height:27px;background:url(' + STATICURL + '/image/mobile/images/pic_select.png) no-repeat;text-align:left;text-indent:20px;">';
			selector += '<select id="dumppage" style="position:absolute;left:0;top:0;height:27px;opacity:0;width:100px;">';
			for (var i = 1; i <= lastpage; i++) {
				selector += '<option value="' + i + '" ' + (i == curpage ? 'selected' : '') + '>&#31532;' + i + '&#39029;</option>';
			}
			selector += '</select>';
			selector += '<span>&#31532;' + curpage + '&#39029;</span>';
		}

		$('div.pg').removeClass('pg').addClass('page').html('<a href="' + prevpagehref + '">&#19978;&#19968;&#39029;</a>' + selector + '<a href="' + nextpagehref + '">&#19979;&#19968;&#39029;</a>');
		$('#dumppage').on('change', function() {
			var href = (prevpage || nextpage);
			window.location.href = href.replace(/page=\d+/, 'page=' + $(this).val());
		});
	},
};
$(document).ready(function() {
	if ($('div.pg').length > 0) {
		page.converthtml();
	}
});