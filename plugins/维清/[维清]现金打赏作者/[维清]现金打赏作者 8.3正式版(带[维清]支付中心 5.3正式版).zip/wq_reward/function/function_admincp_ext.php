<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_admincp.php 2015-12-28 21:11:17Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function groups_set($type, $user) {
	global $Plang, $_G;
	loadcache('usergroups');
	$varname = array($type . '[]');
	if($type != 'group[user]') {
		foreach($_G['cache']['usergroups'] as $gid => $group) {
			$group['type'] = ($group['type'] == 'special' && $group['stars']) ? 'specialadmin' : $group['type'];

			$data['first'][$group['type']]['secondlist'][] = $gid;
		}
		$data['second'] = $_G['cache']['usergroups'];

		foreach($data['first'] as $k => $v) {
			$type = array('member' => $Plang['b79e0f3a7b215da0'], 'system' => $Plang['b77dbc3b9d34d404'], 'special' => $Plang['62a5009e9b232186'], 'specialadmin' => $Plang['43329d9fe015d2c0'],);
			$varname[1][] = array($k, $type[$k], 1);
			if($v['secondlist']) {
				foreach($v['secondlist'] as $sgid) {
					$varname[1][] = array($sgid, str_repeat('&nbsp;', 8) . $data['second'][$sgid]['grouptitle']);
				}
			}
		}
		showsetting($Plang['c082ba66d466d3e5'], $varname, $user, 'mselect');
	} else {
		$varname[1] = array(array(1, $Plang['15e00942fd322f8b']), array(2, $Plang['8234ab99d3b11df1']), array(3, $Plang['70fc4eab7c79d2f2']), array(4, $Plang['e173bf3cb407980b']));
		showsetting($Plang['5ac37add898cd310'], $varname, $user, 'mselect');
	}
}
//From: Dism_taobao-com
?>