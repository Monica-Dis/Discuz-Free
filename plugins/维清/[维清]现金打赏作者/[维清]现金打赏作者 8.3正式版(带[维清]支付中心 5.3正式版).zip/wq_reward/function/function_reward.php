<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function add_reward_order($_arg_0)
{
	global $_G;
	$_var_2 = array("infoid" => $_arg_0["tid"], "idtype" => $_arg_0["idtype"], "fromuid" => $_G["uid"], "fromusername" => $_G["username"], "touid" => $_arg_0["authorid"], "tousername" => diconv($_arg_0["author"], "utf-8", CHARSET), "isanonymity" => $_arg_0["isanonymity"], "orderno" => $_arg_0["orderid"], "money" => $_arg_0["money"], "paymethod" => $_arg_0["paymethod"], "dateline" => time());
	if ($_var_2["idtype"] == "gtid") {
		$_var_2["fid"] = $_arg_0["fid"];
	}
	if ($_arg_0["pid"]) {
		$_var_2["pid"] = $_arg_0["pid"];
	}
	return C::t("#wq_reward#wq_reward_record")->insert($_var_2, true, true);
}
function forum_portal_group($_arg_0, $_arg_1, $_arg_2 = 0, $_arg_3 = 0)
{
	global $_G;
	if ($_arg_0 == "ftid") {
		$_var_5 = forum_rbac_check($_arg_0, $_arg_1, $_arg_2);
	} elseif ($_arg_0 == "aid") {
		$_var_5 = portal_rbac_check($_arg_0, $_arg_1);
	} elseif ($_arg_0 == "gtid") {
		$_var_5 = group_rbac_check($_arg_0, $_arg_1, $_arg_2);
	} elseif ($_arg_0 == "articleid") {
		$_var_5 = wechatcollecting_rbac_check($_arg_0, $_arg_1);
	}
	if (!$_var_5) {
		return '';
	}
	$_var_6 = $_var_5["allow"];
	$_var_7 = $_var_5["template"];
	$_var_8 = $_arg_1;
	$_var_9 = $_var_5["data"];
	$_var_10 = $_var_5["num"];
	$_var_11 = $_var_5["fid"];
	if ($_var_6 == 1) {
		if ($_var_7 == 1) {
			$_var_12 = "btn_appreciation btn_appreciation_t";
			$_var_13 = "appreciate_list_wrapper_t";
			$_var_14 = "appreciate_list_t vcenter_t";
		} else {
			$_var_12 = "btn_appreciation";
			$_var_13 = "appreciate_list_wrapper";
			$_var_14 = "appreciate_list vcenter";
		}
		$_var_15 = "<style>";
		$_var_16 = common_setting();
		$_var_17 = "&#x8D5E;&#x8D4F;";
		$_var_18 = "&#x8D5E;&#x8D4F;";
		if ($_var_16["reward_button_text"]) {
			$_var_17 = $_var_16["reward_button_text"];
		}
		if ($_var_16["trade_explain"]) {
			$_var_18 = $_var_16["trade_explain"];
		}
		$_var_19 = '';
		$_var_20 = C::t("#wq_reward#wq_reward_record")->fetch_sum_money_by_infoid_idtype($_var_8, $_arg_0, $_arg_2);
		if ($_var_16["is_show_totalmoney"] && $_var_20["totalmoney"] > 0) {
			$_var_19 = "<b>&#20849;</b><i>" . $_var_20["totalmoney"] . "</i><b>&#20803;</b>";
		}
		$_var_21 = '';
		if ($_arg_2) {
			$_var_21 = "&pid=" . $_arg_2;
		}
		if ($_var_9) {
			$_var_22 = "\"javascript:;\"";
			if ($_var_16["is_show_userlist"]) {
				$_var_22 = "\"plugin.php?id=wq_reward&mod=list&infoid=" . $_var_8 . "&idtype=" . $_arg_0 . $_var_21 . "\"" . ($_G["mobile"] ? '' : " onclick=\"showWindow(this.id, this.href, 'get', 0);\"");
			}
			$_var_23 = "reward_list";
			if ($_arg_2) {
				$_var_23 = $_var_23 . ("_" . $_arg_2);
			}
			$_var_24 = '';
			if ($_var_16["mobile_viewlog"] && $_G["mobile"] && $_var_16["is_show_userlist"]) {
				$_var_25 = '';
				if ($_var_19 != '') {
					$_var_24 = $_var_24 . ("<span class=\"head_count head_count_t show\"><a id=\"" . $_var_23 . "\" href=\"plugin.php?id=wq_reward&mod=list&infoid=" . $_var_8 . "&idtype=" . $_arg_0 . $_var_21 . "\"" . ($_G["mobile"] ? '' : " onclick=\"showWindow(this.id, this.href, 'get', 0);\"") . ">" . $_var_19 . "</a></span>");
				}
				$_var_26 = $_var_26 . ("<p class='wq_app_title b_top_bottom'>" . "<span class='head_count head_count_t'>" . "<a href='javascript:;'><i> " . count($_var_9) . "</i><b>&#x4EBA;" . $_var_18 . "</b></a></span>" . "<span class='wq_app_more'> <a id='" . $_var_23 . "' href='plugin.php?id=wq_reward&mod=list&infoid=" . $_var_8 . "&idtype=" . $_arg_0 . "&pid=" . $_arg_2 . "'" . ($_G["mobile"] ? '' : " onclick='showWindow(this.id, this.href, \\'get\\', 0);'") . ">&#x67E5;&#x770B;&#x66F4;&#x591A;<img src='source/plugin/wq_reward/static/images/arrow_tz.png'></a></span>" . "</p>");
				$_var_16 = get_rewardlog_for_view($_var_8, $_arg_0, $_var_16["mobile_viewlog_num"], $_arg_2);
				$_var_15 = $_var_15 . $_var_16["style"];
				$_var_26 = $_var_26 . $_var_16["html"];
			} else {
				$_var_25 = "<span class=\"head_count head_count_t show\"><a id=\"" . $_var_23 . "\" href=" . $_var_22 . "><i> " . count($_var_9) . "</i><b>&#20154;" . $_var_18 . "</b>&nbsp;&nbsp;" . $_var_19 . "</a></span>";
				$_var_27 = array_slice($_var_9, 0, $_var_10, true);
				$_var_26 = "<div class = \"" . $_var_13 . "\"><div class = \"" . $_var_14 . "\"><a id=\"" . $_var_23 . "\" href=" . $_var_22 . ">";
				foreach ($_var_27 as $_var_28) {
					$_var_29 = avatar(0, small, true);
					if ($_var_28["uid"]) {
						$_var_30 = avatar($_var_28["uid"], small, true);
					} else {
						$_var_30 = $_var_29;
					}
					$_var_26 = $_var_26 . ("<img src=\"" . $_var_30 . "\"/>");
				}
				$_var_26 = $_var_26 . "</a></div></div>";
			}
			if ($_COOKIE["return_ok"] && $_GET["pid"] == $_arg_2) {
				if ($_var_16["is_show_userlist"]) {
					$_var_26 = $_var_26 . ("<script>document.getElementById(\"" . $_var_23 . "\").onclick();</script>");
				}
				setcookie("return_ok", '', -2952000);
			}
		}
		if ($_arg_0 == "gtid" && $_var_11) {
			$_var_11 = "&fid=" . $_var_11;
		}
		$_var_31 = '';
		$_var_32 = '';
		if ($_G["mobile"] && $_arg_2) {
			$_var_31 = "<div class='appreciation_bg'>";
			$_var_32 = "</div>";
			$_var_33 = "appreciate wqr_replies";
			$_var_15 = $_var_15 . "\r\n\r\n              .appreciation_bg{}\r\n.wqr_replies {  margin-bottom: 16px; padding-top: 20px;}\r\n.wqr_replies .btn_appreciation { display: block; width:60px; height: 30px; margin: 0px auto 0; font-size: 14px;line-height: 30px; text-align: center; vertical-align: middle; color: #fff; border-radius: 5px;background: #ff8000;}\r\n.wqr_replies .head_count{margin: 20px auto 0;}\r\n.appreciate .btn_appreciation_t{background: #dc5d4a;}\r\n </style>";
		} else {
			$_var_33 = "appreciate";
			$_var_15 = $_var_15 . ".appreciate{ margin-bottom:16px;}\r\n.appreciate .btn_appreciation { display: block; width: 110px; height: 40px; margin: 40px auto 0;font-size: 18px; line-height: 40px; text-align: center; vertical-align: middle; color: #fff; border-radius: 5px; background: #ff8000;}\r\n.appreciate .head_count.show { display: block;}\r\n.appreciate .head_count {display: none; margin: 30px auto 0; font-size: 14px;text-align: center;}\r\n.appreciate .head_count i {color: #ff8000;}\r\n.appreciate .head_count b {color: gray;}\r\n.appreciate_list_wrapper{ overflow: hidden; margin: 0 auto; width: 200px;}\r\n.appreciate_list.vcenter{ text-align: center;}\r\n.appreciate_list.vcenter a{ display:block;}\r\n.appreciate_list { max-height: 120px; overflow: hidden; margin-right: -6px; line-height: 15px;}\r\n.appreciate_list img { position: relative; width: 34px;   height: 34px; margin: 0 6px 4px 0; border-radius: 17px;max-width: 100%!important;}\r\n.appreciate .btn_appreciation_t{background: #dc5d4a;}\r\n.appreciate .head_count_t i {color: #607fa6;}\r\n.appreciate_list_wrapper_t{ overflow: hidden; margin: 0 auto; width: 250px;}\r\n.appreciate_list_t.vcenter_t { text-align: center;}\r\n.appreciate_list_t.vcenter_t a{ display:block;}\r\n.appreciate_list_t { max-height: 120px; overflow: hidden; margin-right: -6px; line-height: 15px;}\r\n.appreciate_list_t img { position: relative; width: 30px; height: 30px; margin: 0 6px 4px 0;max-width: 100%!important;}\r\n </style>";
		}
		if ($_arg_3) {
			$_var_16["tourist_is_reward"] = false;
		}
		if (!$_var_16["tourist_is_reward"] && !$_G["uid"]) {
			$_var_34 = " id=\"login\" href=member.php?mod=logging&action=login";
		} else {
			$_var_34 = " id=\"reward_btn\" href=plugin.php?id=wq_reward&mod=pay&infoid=" . $_var_8 . $_var_11 . $_var_21 . "&idtype=" . $_arg_0;
		}
		if ($_G["mobile"]) {
			$_var_35 = $_var_15 . $_var_31 . "<div class=\"" . $_var_33 . "\"><a" . $_var_34 . " class=\"" . $_var_12 . "\" >" . $_var_17 . "</a>" . $_var_25 . $_var_24 . "</div>" . $_var_26 . $_var_32;
		} else {
			$_var_35 = $_var_15 . $_var_31 . "<div class=\"" . $_var_33 . "\"><a" . $_var_34 . " onclick=\"showWindow(this.id, this.href, 'get', 0);\" class=\"" . $_var_12 . "\" >" . $_var_17 . "</a>" . $_var_25 . $_var_24 . "</div>" . $_var_26 . $_var_32;
		}
		return $_var_35;
	}
	return '';
}
function get_article_info($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = array("ftid", "aid", "gtid", "articleid");
	if (!in_array($_GET["idtype"], $_var_3)) {
		return -1;
	}
	$_var_4 = '';
	if (in_array($_GET["idtype"], array("ftid", "gtid"))) {
		if ($_arg_2) {
			$_var_5 = C::t("forum_post")->fetch("forum_post", $_arg_2);
		} else {
			$_var_5 = C::t("forum_thread")->fetch($_GET["infoid"]);
		}
		$_var_4 = $_var_5["authorid"];
	} else {
		if ($_arg_0 == "articleid") {
			$_var_6 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch($_arg_1);
			$_var_4 = $_var_6["uid"];
			$_var_5["username"] = $_var_6["username"];
			$_var_5["author"] = $_var_5["username"];
			$_var_5["subject"] = $_var_6["title"];
		} else {
			$_var_5 = C::t("portal_article_title")->fetch_all_by_sql("aid=" . $_GET["infoid"], array(), 0, 1, 0);
			$_var_4 = $_var_5[0]["uid"];
			$_var_5["uid"] = $_var_5[0]["uid"];
			$_var_5["username"] = $_var_5[0]["username"];
			$_var_5["author"] = $_var_5["username"];
			$_var_5["subject"] = $_var_5[0]["title"];
		}
	}
	if ($_var_5) {
		$_var_5["uid"] = $_var_4;
		$_var_5["idtype"] = $_arg_0;
		$_var_5["tid"] = $_arg_1;
		$_var_5["authorid"] = $_var_5["uid"];
	}
	return $_var_5;
}
function get_user_name_by_uids($_arg_0 = array())
{
	return C::t("common_member")->fetch_all_username_by_uid($_arg_0);
}
function wq_reward_check_password($_arg_0)
{
	global $_G;
	loaducenter();
	list($_var_2) = uc_user_login($_G["uid"], $_arg_0, 1, 0);
	if ($_var_2 >= 0) {
		return $_var_2;
	}
	return false;
}
function alipay_account_replace($_arg_0)
{
	$_var_1 = '';
	if ($_arg_0) {
		$_var_2 = stripos($_arg_0, "@");
		$_var_3 = stripos($_arg_0, ".");
		$_var_4 = substr($_arg_0, 2, $_var_2 - 4);
		$_var_5 = substr($_arg_0, $_var_2 + 1, $_var_3 - $_var_2 - 1);
		$_var_6 = str_repeat("*", strlen($_var_4));
		$_var_7 = str_repeat("*", strlen($_var_5));
		$_var_8 = array($_var_4, $_var_5);
		$_var_9 = array($_var_6, $_var_7);
		$_var_1 = str_replace($_var_8, $_var_9, $_arg_0);
	}
	return $_var_1;
}
function add_reward_rank($_arg_0)
{
	$_var_1 = array("money" => $_arg_0["money"], "infoid" => $_arg_0["infoid"], "idtype" => $_arg_0["idtype"], "uid" => $_arg_0["fromuid"], "dateline" => time(), "pid" => $_arg_0["pid"]);
	$_var_2 = C::t("#wq_reward#wq_reward_rank")->fetch_first_by_tid_uid_pid($_arg_0["infoid"], $_arg_0["fromuid"], $_arg_0["pid"]);
	if ($_var_2) {
		$_var_3 = array("wq_reward_rank", $_arg_0["money"], time(), $_var_2["rankid"]);
		DB::query("UPDATE %t SET `money` = `money` + %i,dateline=%d WHERE rankid = %d", $_var_3);
	} else {
		C::t("#wq_reward#wq_reward_rank")->insert($_var_1);
	}
}
function add_reward_user_info($_arg_0)
{
	$_var_1 = C::t("#wq_reward#wq_reward_userinfo")->fetch_first_by_uid($_arg_0["touid"]);
	if ($_var_1) {
		$_var_2[] = "wq_reward_userinfo";
		$_var_3[] = "`rewardcount` = `rewardcount` + 1";
		$_var_3[] = "`rewardsum` = `rewardsum` + %i";
		$_var_2[] = $_arg_0["money"];
		$_var_3[] = "`availablemoney` = `availablemoney` + %i";
		$_var_2[] = $_arg_0["money"];
		$_var_2[] = $_var_1["id"];
		$_var_4 = implode(",", $_var_3);
		DB::query("UPDATE %t SET " . $_var_4 . " WHERE id = %d", $_var_2);
	} else {
		$_var_5 = array("uid" => $_arg_0["touid"], "username" => $_arg_0["tousername"], "rewardcount" => 1, "rewardsum" => $_arg_0["money"], "availablemoney" => $_arg_0["money"]);
		C::t("#wq_reward#wq_reward_userinfo")->insert($_var_5);
	}
}
function update_reward_order_status($_arg_0)
{
	global $_G;
	$_var_2 = C::t("#wq_reward#wq_reward_record")->fetch_first_by_orderid($_arg_0);
	if ($_var_2["status"]) {
		return NULL;
	}
	$_var_3 = false;
	if ($_var_2) {
		$_var_4 = array("status" => 1, "paytime" => time());
		$_var_3 = C::t("#wq_reward#wq_reward_record")->update_status_by_orderno($_arg_0, $_var_4);
	} else {
		return false;
	}
	if ($_var_3) {
		if (!$_var_2["isanonymity"]) {
			add_reward_rank($_var_2);
		}
		add_reward_user_info($_var_2);
		if ($_var_2["idtype"] == "gtid" && $_var_2["fid"] && $_G["cache"]["plugin"]["wq_buluo"]) {
			clear_month_data();
			update_group_user_extinfo($_var_2);
		}
		loadcache("plugin");
		if ($_G["cache"]["plugin"]["wq_login"]) {
			$_var_5 = $_var_2;
			$_var_6 = $_G["cache"]["plugin"]["wq_login"];
			$_var_6["appid"] = trim($_var_6["appid"]);
			$_var_6["appsecret"] = trim($_var_6["appsecret"]);
			$_var_6["open_wechattips"] = intval($_var_6["open_wechattips"]);
			$_var_6["templateid"] = trim($_var_6["templateid"]);
			if ($_var_6["open_wechattips"] == "1" && !empty($_var_6["templateid"])) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_login/class/jssdk.class.php";
				include_once DISCUZ_ROOT . "./source/plugin/wq_login/function/function_login.php";
				$_var_7 = 12;
				if ($_var_5["idtype"] == "aid") {
					$_var_7 = 13;
				}
				sendWechatTemplateTips($_var_6, $_var_7, 4, $_var_5["infoid"], 0, $_var_5["touid"], $_var_5["tousername"]);
			}
		}
		return 1;
	}
}
function del_not_pay_order($_arg_0)
{
	return DB::delete("wq_reward_record", array("orderno" => $_arg_0));
}
function update_group_user_extinfo($_arg_0)
{
	$_var_1 = get_extinfo_by_uid_fid($_arg_0["touid"], $_arg_0["fid"]);
	if ($_var_1) {
		edit_group_user_reward(true, "rewardtime", $_var_1["rewardtime"], 1, $_arg_0["fid"], $_arg_0["touid"], $_arg_0["tousername"]);
	} else {
		edit_group_user_reward(false, "rewardtime", $_var_1["rewardtime"], 1, $_arg_0["fid"], $_arg_0["touid"], $_arg_0["tousername"]);
	}
	if (!$_arg_0["isanonymity"]) {
		$_var_2 = get_extinfo_by_uid_fid($_arg_0["fromuid"], $_arg_0["fid"]);
		if ($_var_2) {
			edit_group_user_reward(true, "spending", $_var_2["spending"], $_arg_0["money"], $_arg_0["fid"], $_arg_0["fromuid"], $_arg_0["fromusername"]);
		} else {
			edit_group_user_reward(false, "spending", $_var_2["spending"], $_arg_0["money"], $_arg_0["fid"], $_arg_0["fromuid"], $_arg_0["fromusername"]);
		}
	}
	return true;
}
function clear_month_data()
{
	$_var_0 = array("rewardtime" => 0, "spending" => 0, "endrewardtime" => strtotime(date("Y-m-01") . " 00:00:00"));
	$_var_1 = "endrewardtime < " . strtotime(date("Y-m-01") . " 00:00:00");
	return DB::update("wq_buluo_groupuser_extinfo", $_var_0, $_var_1);
}
function get_extinfo_by_uid_fid($_arg_0, $_arg_1)
{
	return C::t("#wq_buluo#wq_buluo_groupuser_extinfo")->fetch_first_by_uid_fid($_arg_0, $_arg_1);
}
function edit_group_user_reward($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4, $_arg_5, $_arg_6)
{
	if ($_arg_0) {
		$_var_7 = array($_arg_1 => $_arg_2 + $_arg_3, "endrewardtime" => time());
		return C::t("#wq_buluo#wq_buluo_groupuser_extinfo")->update_for_user($_arg_5, $_arg_4, $_var_7);
	}
	$_var_7 = array("fid" => $_arg_4, "uid" => $_arg_5, $_arg_1 => $_arg_3, "username" => $_arg_6, "endrewardtime" => time());
	return C::t("#wq_buluo#wq_buluo_groupuser_extinfo")->insert($_var_7);
}
function fetch_exec_by_id_type($_arg_0, $_arg_1, $_arg_2 = 0)
{
	return C::t("#wq_reward#wq_reward_rank")->fetch_all_by_id_type($_arg_0, $_arg_1, $_arg_2);
}
function fetch_level_by_uid_fid($_arg_0, $_arg_1)
{
	return C::t("forum_groupuser")->fetch_userinfo($_arg_0, $_arg_1);
}
function forum_rbac_check($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	if (!$_G["thread"]["authorid"]) {
		return false;
	}
	$_var_4 = fetch_exec_by_id_type($_arg_1, $_arg_0, $_arg_2);
	$_var_5 = unserialize($_G["setting"]["wq_reward_setting"]);
	$_var_6 = DB::fetch_first("SELECT * FROM " . DB::table("common_member_count") . " WHERE uid = " . $_G["thread"]["authorid"]);
	$_var_7 = DB::fetch_first("SELECT * FROM " . DB::table("common_member") . " WHERE uid = " . $_G["thread"]["authorid"]);
	if ($_var_5["forum"] && in_array($_var_7["groupid"], $_var_5["forum"]["user"]) && $_var_6["posts"] >= $_var_5["forum"]["num"] && $_var_6["digestposts"] >= $_var_5["forum"]["essence_num"]) {
		return return_rbac_data($_arg_0, $_var_4);
	}
	return false;
}
function portal_rbac_check($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = fetch_exec_by_id_type($_arg_1, $_arg_0);
	$_var_4 = unserialize($_G["setting"]["wq_reward_setting"]);
	$_var_5 = C::t("portal_article_title")->fetch($_arg_1);
	if (!$_var_5) {
		return false;
	}
	$_var_6 = DB::fetch_first("SELECT * FROM " . DB::table("common_member") . " WHERE uid = " . $_var_5["uid"]);
	if ($_var_4["portal"] && in_array($_var_6["groupid"], $_var_4["portal"]["user"])) {
		return return_rbac_data($_arg_0, $_var_3);
	}
	return false;
}
function group_rbac_check($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	if (!$_G["thread"]["authorid"]) {
		return false;
	}
	$_var_4 = fetch_exec_by_id_type($_arg_1, $_arg_0, $_arg_2);
	$_var_5 = unserialize($_G["setting"]["wq_reward_setting"]);
	$_var_6 = fetch_level_by_uid_fid($_G["thread"]["authorid"], $_G["fid"]);
	$_var_7 = DB::fetch_first("SELECT * FROM " . DB::table("common_member_count") . " WHERE uid = " . $_G["thread"]["authorid"]);
	if (!empty($_G["cache"]["plugin"]["wq_buluo"])) {
		$_var_8 = 1;
	} else {
		$_var_8 = 0;
	}
	if ($_var_8) {
		$_var_9 = DB::fetch_first("SELECT * FROM " . DB::table("wq_buluo_groupuser_extinfo") . " WHERE uid = " . $_G["thread"]["authorid"] . " AND fid = " . $_G["fid"]);
		if ($_var_5["group"] && (in_array($_var_6["level"], $_var_5["group"]["user"]) || $_var_5["group"]["iron_powder"] && $_var_9["signdays"] >= 7) && ($_var_7["posts"] >= $_var_5["group"]["num"] && $_var_7["digestposts"] >= $_var_5["group"]["essence_num"] || $_var_9["experience"] >= $_var_5["group"]["exp"])) {
			return return_rbac_data($_arg_0, $_var_4, $_G["fid"]);
		}
		return false;
	}
	if ($_var_5["group"] && in_array($_var_6["level"], $_var_5["group"]["user"]) && $_var_7["posts"] >= $_var_5["group"]["num"] && $_var_7["digestposts"] >= $_var_5["group"]["essence_num"]) {
		return return_rbac_data($_arg_0, $_var_4, $_G["fid"]);
	}
	return false;
}
function wechatcollecting_rbac_check($_arg_0, $_arg_1)
{
	$_var_2 = fetch_exec_by_id_type($_arg_1, $_arg_0);
	return return_rbac_data($_arg_0, $_var_2);
}
function common_setting()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["wq_reward"];
	$_var_1["allow_portal"] = intval($_var_1["allow_portal"]);
	$_var_1["allow_forum"] = intval($_var_1["allow_forum"]);
	$_var_1["allow_group"] = intval($_var_1["allow_group"]);
	$_var_1["allow_wechatcollecting"] = intval($_var_1["allow_wechatcollecting"]);
	$_var_1["open_wxpay"] = intval($_var_1["open_wxpay"]);
	$_var_1["browser_is_can_wechatpay"] = intval($_var_1["browser_is_can_wechatpay"]);
	$_var_1["open_alipay"] = intval($_var_1["open_alipay"]);
	$_var_1["open_tenpay"] = intval($_var_1["open_tenpay"]);
	$_var_1["reward_template"] = intval($_var_1["reward_template"]);
	$_var_1["default_num"] = trim($_var_1["default_num"]);
	$_var_1["allow_custom"] = intval($_var_1["allow_custom"]);
	$_var_1["custom_min"] = round($_var_1["custom_min"], 2);
	$_var_1["custom_max"] = round($_var_1["custom_max"], 2);
	$_var_1["pc_view_num"] = intval($_var_1["pc_view_num"]);
	$_var_1["m_view_num"] = intval($_var_1["m_view_num"]);
	$_var_1["case_min"] = intval($_var_1["case_min"]);
	$_var_1["perpage"] = intval($_var_1["perpage"]);
	$_var_1["admincp_perpage"] = intval($_var_1["admincp_perpage"]);
	$_var_1["mobile_viewlog"] = intval($_var_1["mobile_viewlog"]);
	$_var_1["mobile_viewlog_num"] = intval($_var_1["mobile_viewlog_num"]);
	$_var_1["reward_button_text"] = trim($_var_1["reward_button_text"]);
	$_var_1["trade_explain"] = trim($_var_1["trade_explain"]);
	$_var_1["tourist_is_reward"] = intval($_var_1["tourist_is_reward"]);
	$_var_1["is_show_totalmoney"] = intval($_var_1["is_show_totalmoney"]);
	$_var_1["reply_is_reward"] = intval($_var_1["reply_is_reward"]);
	$_var_1["not_reward_lookpost"] = unserialize($_var_1["not_reward_lookpost"]);
	$_var_1["reward_look_groupid"] = unserialize($_var_1["reward_look_groupid"]);
	$_var_1["reward_look_money"] = trim($_var_1["reward_look_money"]);
	$_var_2["reward_look_txt"] = trim($_var_2["reward_look_txt"]);
	$_var_2["cash_is_idcard"] = intval($_var_2["cash_is_idcard"]);
	$_var_2["cash_is_phone"] = intval($_var_2["cash_is_phone"]);
	$_var_2["is_show_userlist"] = intval($_var_2["is_show_userlist"]);
	if ($_var_1["reward_look_money"]) {
		$_var_1["reward_look_money"] = explode("~", $_var_1["reward_look_money"]);
	}
	$_var_1["reward_look_txt"] = trim($_var_1["reward_look_txt"]);
	return $_var_1;
}
function return_rbac_data($_arg_0, $_arg_1, $_arg_2 = '')
{
	$_var_3 = common_setting();
	$_var_4 = array("allow" => 1, "template" => $_var_3["reward_template"], "data" => $_arg_1, "num" => $_var_3["pc_view_num"], "fid" => $_arg_2);
	$_var_5 = 0;
	if ($_arg_0 == "ftid" && $_var_3["allow_forum"]) {
		$_var_5 = 1;
	} else {
		if ($_arg_0 == "aid" && $_var_3["allow_portal"]) {
			$_var_5 = 1;
		} else {
			if ($_arg_0 == "gtid" && $_var_3["allow_group"]) {
				$_var_5 = 1;
			} else {
				if ($_arg_0 == "articleid" && $_var_3["allow_wechatcollecting"]) {
					$_var_5 = 1;
				}
			}
		}
	}
	if (!$_var_5 || !$_var_3["reply_is_reward"] && $_GET["page"] > 1) {
		$_var_4["allow"] = 0;
	}
	return $_var_4;
}
function get_rewardlog_for_view($_arg_0, $_arg_1, $_arg_2, $_arg_3)
{
	global $_G;
	if (!$_arg_2) {
		$_arg_2 = 10;
	}
	$_var_5 = C::t("#wq_reward#wq_reward_rank")->fetch_all_by_id_type($_arg_0, $_arg_1, $_arg_3, 0, 0, $_arg_2);
	foreach ($_var_5 as $_var_6 => $_var_7) {
		$_var_8[] = $_var_7["uid"];
	}
	$_var_9 = array();
	if ($_var_8) {
		$_var_9 = get_user_name_by_uids($_var_8);
	}
	$_var_10 = '';
	if ($_G["mobile"] && $_arg_3) {
		$_var_10 = "style=\"margin-bottom:14px\"";
	}
	$_var_11 = "<div class=\"app_listwo\" " . $_var_10 . "><ul class=\"list\">";
	$_var_12 = "javascript:;";
	foreach ($_var_5 as $_var_6 => $_var_7) {
		if ($_arg_1 == "gtid" && $_G["cache"]["plugin"]["wq_buluo"]) {
			$_var_12 = "plugin.php?id=wq_buluo&mod=card&uid=" . $_var_7["uid"] . "&mobile=2";
		} else {
			$_var_12 = "home.php?mod=space&uid=" . $_var_7["uid"] . "&do=profile&mobile=2";
		}
		$_var_13 = avatar(0, small, true);
		if ($_var_7["uid"]) {
			$_var_14 = avatar($_var_7["uid"], small, true);
		} else {
			$_var_14 = $_var_13;
		}
		$_var_11 = $_var_11 . ("<a href = " . $_var_12 . "><li><div class = \"head\">");
		$_var_11 = $_var_11 . ("<img src = " . $_var_14 . ">");
		$_var_11 = $_var_11 . ("</div><p class = \"nick-name\"><span>" . $_var_9[$_var_7["uid"]] . "</span></p><div class = \"total\">" . $_var_7["money"] . "&#x5143;</div></li></a>");
	}
	$_var_11 = $_var_11 . "</ul>\r\n        </div>\r\n        <script>\r\n            if (window.devicePixelRatio && devicePixelRatio >= 2 && navigator.userAgent.toLowerCase().match(/iphone/i) == 'iphone') {\r\n                document.getElementsByTagName('html')[0].className = 'retina';\r\n            }\r\n        </script>";
	$_var_15 = ".wq_app_title{border-bottom: 1px solid #f0f0f0;  border-top: 1px solid #f0f0f0; font-size: 16px; padding-left:10px; line-height: 44px;background-color: #f9f9f9;}\r\n        .wq_app_title a{ display: inline-block;}\r\n        .wq_app_title .head_count i{ color: #ff8000;}\r\n        .wq_app_title .head_count_t i{ color: #607fa6;}\r\n        .app_listwo{ padding: 0px 10px;}\r\n        .app_listwo .list li { display: -webkit-box;height: 44px;border-bottom: 1px solid #f0f0f0;}\r\n        .app_listwo .list a{ display: block; color: #333}\r\n        .app_listwo .list li .head img { position: relative; width: 30px; height: 30px; margin: 6px 11px 0 6px;  border-radius: 20px;}\r\n        .app_listwo .list li .nick-name { padding-right: 7px; font-size: 17px;  line-height:44px;  vertical-align: middle; -webkit-box-flex: 1;}\r\n        .app_listwo .list li .nick-name span { display: block; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;}\r\n        .app_listwo .list li .total { padding-right: 10px; font-size: 17px; line-height: 42px; text-align: right; vertical-align: middle; color: #777;}\r\n        .wq_app_more{ font-size: 16px; line-height: 44px; text-align: center; float: right}\r\n        .wq_app_more img{ width: 22px;vertical-align: sub;}\r\n        .retina .b_top_bottom{ border: none !important; background-image:linear-gradient(180deg, #e5e5e5, #e5e5e5 50%, transparent 50%),linear-gradient(270deg, #e5e5e5, #e5e5e5 50%, transparent 50%), linear-gradient(0deg, #e5e5e5, #e5e5e5 50%, transparent 50%), linear-gradient(90deg, #e5e5e5, #e5e5e5 50%, transparent 50%); background-size: 100% 1px,0px 100% ,100% 1px, 0px 100%; background-repeat: no-repeat; background-position: top, right top,  bottom, left top;}\r\n        .retina .b_bottom{ border-bottom: none !important;background-image:linear-gradient(180deg, #e5e5e5, #e5e5e5 50%, transparent 50%),linear-gradient(270deg, #e5e5e5, #e5e5e5 50%, transparent 50%), linear-gradient(0deg, #e5e5e5, #e5e5e5 50%, transparent 50%), linear-gradient(90deg, #e5e5e5, #e5e5e5 50%, transparent 50%); background-size: 100% 0px,0px 100% ,100% 1px, 0px 100%; background-repeat: no-repeat; background-position: top, right top,  bottom, left top;}";
	return array("html" => $_var_11, "style" => $_var_15);
}
function clear_day_nopay_orderid()
{
	$_var_0 = "DELETE FROM %t WHERE status=%d AND dateline <=%d";
	return DB::query($_var_0, array("wq_reward_record", 0, TIMESTAMP - 86400));
}
function common_forum_viewthread_postbottom($_arg_0)
{
	global $_G;
	global $postlist;
	$_var_3 = common_setting();
	$_var_4 = array();
	if ($_var_3["reply_is_reward"]) {
		foreach ($postlist as $_var_5 => $_var_6) {
			$_var_7 = $_var_6["pid"];
			$_var_8 = check_is_reward_look($_arg_0, $_var_6["authorid"], $_var_6["tid"], $_G["uid"], $_var_7);
			if (!$_var_8) {
				$_var_4[] = forum_portal_group($_arg_0, $_G["tid"], $_var_7);
			} else {
				$_var_4[] = '';
			}
		}
	} else {
		if ($_GET["viewpid"]) {
			return array();
		}
		$_var_9 = C::t("forum_thread")->fetch($_GET["tid"]);
		$_var_8 = check_is_reward_look($_arg_0, $_var_9["authorid"], $_GET["tid"], $_G["uid"], 0);
		if (!$_var_8) {
			$_var_4 = array(forum_portal_group($_arg_0, $_G["tid"]));
		}
	}
	return $_var_4;
}
function common_add_reward_look($_arg_0)
{
	global $_G;
	$_var_2 = array("post_newthread_mod_succeed", "post_newthread_succeed", "post_edit_succeed", "edit_newthread_mod_succeed", "post_reply_succeed");
	if (in_array($_arg_0["param"][0], $_var_2)) {
		$_var_3 = C::t("#wq_reward#wq_reward_look_tids")->fetch_by_uid_tid_pid(0, 0, $_arg_0["param"][2]["pid"]);
		if ($_var_3 && $_POST["reward_look"] && $_POST["reward_look"] > 0) {
			C::t("#wq_reward#wq_reward_look_tids")->update($_var_3["id"], array("money" => $_POST["reward_look"]));
		}
		if (!$_var_3 && $_POST["reward_look"] && $_POST["reward_look"] > 0) {
			$_var_4 = array("uid" => $_G["uid"], "tid" => $_arg_0["param"][2]["tid"], "pid" => $_arg_0["param"][2]["pid"], "money" => $_POST["reward_look"], "dateline" => TIMESTAMP);
			if ($_GET["action"] && $_GET["action"] == "edit") {
				$_var_4["uid"] = $_G["thread"]["authorid"];
			}
			C::t("#wq_reward#wq_reward_look_tids")->insert($_var_4);
		}
		if ($_var_3 && (!$_POST["reward_look"] || $_POST["reward_look"] <= 0)) {
			C::t("#wq_reward#wq_reward_look_tids")->delete($_var_3["id"]);
		}
	}
}
function common_forum_reward_look_rbac_check()
{
	global $_G;
	$_var_1 = common_setting();
	$_var_2 = unserialize($_G["setting"]["wq_reward_setting"]);
	$_var_3 = DB::fetch_first("SELECT * FROM " . DB::table("common_member_count") . " WHERE uid = " . $_G["uid"]);
	$_var_4 = DB::fetch_first("SELECT * FROM " . DB::table("common_member") . " WHERE uid = " . $_G["uid"]);
	if ($_var_1["reward_look_groupid"] && in_array($_G["groupid"], $_var_1["reward_look_groupid"]) && $_var_1["allow_forum"] && $_var_2["forum"] && in_array($_G["groupid"], $_var_2["forum"]["user"]) && $_var_3["posts"] >= $_var_2["forum"]["num"] && $_var_3["digestposts"] >= $_var_2["forum"]["essence_num"]) {
		return true;
	}
	return false;
}
function common_group_reward_look_rbac_check()
{
	global $_G;
	$_var_1 = common_setting();
	$_var_2 = unserialize($_G["setting"]["wq_reward_setting"]);
	$_var_3 = fetch_level_by_uid_fid($_G["uid"], $_G["fid"]);
	$_var_4 = DB::fetch_first("SELECT * FROM " . DB::table("common_member_count") . " WHERE uid = " . $_G["uid"]);
	$_var_5 = 0;
	if (!empty($_G["cache"]["plugin"]["wq_buluo"])) {
		$_var_5 = 1;
	}
	if ($_var_5) {
		$_var_6 = DB::fetch_first("SELECT * FROM " . DB::table("wq_buluo_groupuser_extinfo") . " WHERE uid = " . $_G["uid"] . " AND fid = " . $_G["fid"]);
		if ($_var_1["reward_look_groupid"] && in_array($_G["groupid"], $_var_1["reward_look_groupid"]) && $_var_1["allow_group"] && $_var_2["group"] && (in_array($_var_3["level"], $_var_2["group"]["user"]) || $_var_2["group"]["iron_powder"] && $_var_6["signdays"] >= 7) && ($_var_4["posts"] >= $_var_2["group"]["num"] && $_var_4["digestposts"] >= $_var_2["group"]["essence_num"] || $_var_6["experience"] >= $_var_2["group"]["exp"])) {
			return true;
		}
	} else {
		if ($_var_1["reward_look_groupid"] && in_array($_G["groupid"], $_var_1["reward_look_groupid"]) && $_var_1["allow_group"] && $_var_2["group"] && in_array($_var_3["level"], $_var_2["group"]["user"]) && $_var_4["posts"] >= $_var_2["group"]["num"] && $_var_4["digestposts"] >= $_var_2["group"]["essence_num"]) {
			return true;
		}
	}
	return false;
}
function _common_viewthread_content_replace($_arg_0, $_arg_1)
{
	global $postlist;
	global $_G;
	if (!$postlist) {
		return NULL;
	}
	$_var_4 = common_setting();
	$_var_5 = $_arg_1["reward_look_txt"];
	if ($_var_4["reward_look_txt"]) {
		$_var_5 = $_var_4["reward_look_txt"];
	}
	$_var_6 = reset($postlist);
	$_var_7 = '';
	if ($_arg_0 == "gtid" && $_var_6["fid"]) {
		$_var_7 = "&fid=" . $_var_7;
	}
	$_var_8 = check_is_reward_look($_arg_0, $_var_6["authorid"], $_var_6["tid"], $_G["uid"], $_var_6["pid"]);
	if (!$_var_8) {
		return $postlist;
	}
	$_var_9 = 0;
	if ($_var_8) {
		$_var_4["tourist_is_reward"] = 0;
		$_var_9 = 1;
	}
	if (!$_var_4["tourist_is_reward"] && !$_G["uid"]) {
		$_var_10 = "member.php?mod=logging&action=login";
	} else {
		$_var_10 = "plugin.php?id=wq_reward&mod=pay&infoid=" . $_var_6["tid"] . $_var_7 . "&idtype=" . $_arg_0;
	}
	if ($_var_8) {
		if ($_G["mobile"]) {
			dheader("Location:" . $_G["siteurl"] . $_var_10);
		}
		$_var_11 = '';
		if ($_var_8["sum_m"] > 0) {
			$_var_11 = sprintf($_arg_1["add_extra_txt"], $_var_8["sum_m"], $_var_8["money"]);
		}
		$_var_12 = forum_portal_group($_arg_0, $_var_6["tid"], 0, $_var_9);
		$_var_6["message"] = str_replace("{money}", "<b style=\"color:#369;font-weight:bold;\">" . $_var_8["count_m"] . $_var_11 . "</b>", $_var_5) . $_var_12;
		$_var_6["attachments"] = '';
	}
	$postlist[$_var_6["pid"]] = $_var_6;
	return $postlist;
}
function common_viewthread_content_replace($_arg_0, $_arg_1)
{
	global $postlist;
	global $_G;
	if (!$postlist) {
		return NULL;
	}
	$_var_4 = common_setting();
	$_var_5 = $_arg_1["reward_look_txt"];
	if ($_var_4["reward_look_txt"]) {
		$_var_5 = $_var_4["reward_look_txt"];
	}
	foreach ($postlist as $_var_6 => $_var_7) {
		$_var_8 == 0;
		if (!$_var_7["first"]) {
			$_var_5 = $_arg_1["reward_look_txt_reply"];
			$_var_8 = $_var_7["pid"];
		}
		$_var_9 = '';
		if ($_arg_0 == "gtid" && $_var_7["fid"]) {
			$_var_9 = "&fid=" . $_var_9;
		}
		$_var_10 = check_is_reward_look($_arg_0, $_var_7["authorid"], $_var_7["tid"], $_G["uid"], $_var_8);
		$_var_11 = 0;
		if ($_var_10) {
			$_var_4["tourist_is_reward"] = 0;
			$_var_11 = 1;
		}
		if (!$_var_4["tourist_is_reward"] && !$_G["uid"]) {
			$_var_12 = "member.php?mod=logging&action=login";
		} else {
			$_var_12 = "plugin.php?id=wq_reward&mod=pay&infoid=" . $_var_7["tid"] . $_var_9 . "&idtype=" . $_arg_0;
			if (!$_var_7["first"]) {
				$_var_12 = $_var_12 . "&pid=" . $_var_7["pid"];
			}
		}
		if ($_var_10) {
			$_var_13 = '';
			if ($_var_10["sum_m"] > 0) {
				$_var_13 = sprintf($_arg_1["add_extra_txt"], $_var_10["sum_m"], $_var_10["money"]);
			}
			$_var_14 = forum_portal_group($_arg_0, $_var_7["tid"], $_var_8, $_var_11);
			$_var_7["message"] = str_replace("{money}", "<b style=\"color:#369;font-weight:bold;\">" . $_var_10["count_m"] . $_var_13 . "</b>", $_var_5) . $_var_14;
			$_var_7["attachments"] = '';
		}
		$postlist[$_var_7["pid"]] = $_var_7;
	}
	return $postlist;
}
function check_is_reward_look($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4)
{
	global $_G;
	$_var_6 = common_setting();
	if ($_var_6["not_reward_lookpost"] && in_array($_G["groupid"], $_var_6["not_reward_lookpost"]) || $_G["uid"] == $_arg_1) {
		return false;
	}
	$_var_7 = C::t("#wq_reward#wq_reward_look_tids")->fetch_by_uid_tid_pid($_arg_1, $_arg_2, $_arg_4);
	if ($_var_7 && !$_G["uid"]) {
		return array("money" => $_var_7["money"], "count_m" => $_var_7["money"], "sum_m" => 0);
	}
	$_var_8 = C::t("#wq_reward#wq_reward_record")->fetch_sum_money_by_infoid_idtype($_arg_2, $_arg_0, $_arg_4, $_arg_3);
	if ($_var_7 && $_var_7["money"] > $_var_8["totalmoney"]) {
		$_var_9 = $_var_7["money"] - $_var_8["totalmoney"];
		if ($_var_9 > 0 && $_var_9 < (double) "0.01") {
			$_var_9 = (double) "0.01";
		}
		$_var_10 = array("money" => $_var_9, "count_m" => $_var_7["money"], "sum_m" => $_var_8["totalmoney"]);
		return $_var_10;
	}
	return false;
}
function post_edit_check_reward_look()
{
	global $_G;
	if ($_GET["action"] == "edit" && $_GET["tid"]) {
		$_var_1 = $_GET["pid"] ? intval($_GET["pid"]) : 0;
		$_var_2 = C::t("#wq_reward#wq_reward_look_tids")->fetch_by_uid_tid_pid(0, 0, $_var_1);
		if ($_var_2) {
			return $_var_2["money"];
		}
	}
	return true;
}
function send_message_admin($_arg_0, $_arg_1 = 0)
{
	$_arg_0 = trim($_arg_0);
	if (!$_arg_0) {
		return NULL;
	}
	if ($_arg_1) {
		sendpm($_arg_1, '', $_arg_0);
		return NULL;
	}
	$_var_2 = common_setting();
	$_var_3 = reset($_var_2["send_msg_uids"]);
	array_shift($_var_2["send_msg_uids"]);
	if ($_var_3) {
		sendpm($_var_3, '', $_arg_0);
	}
	foreach ($_var_2["send_msg_uids"] as $_var_4 => $_arg_1) {
		notification_add($_arg_1, "system", $_arg_0);
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}