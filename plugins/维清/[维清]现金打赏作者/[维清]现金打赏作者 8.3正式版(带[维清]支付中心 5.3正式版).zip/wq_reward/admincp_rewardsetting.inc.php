<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_rewardsetting.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');

include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';
include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_admincp_ext.php';

if(!submitcheck('sub')) {
	$data = unserialize($_G['setting']['wq_reward_setting']);
	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_rewardsetting';

	showformheader($fromurl, '', 'sub');
	showtableheader('', 'nobottom');
	showtitle($Plang['b0f910a778b17986'] . $Plang['mh']);
	groups_set('portal[user]', $data['portal']['user']);

	showtitle($Plang['2dce0444fd3de59e'] . $Plang['mh']);
	groups_set('forum[user]', $data['forum']['user']);
	showsetting($Plang['6f73e58c05deadab'], 'forum[num]', $data['forum']['num'], 'number', '', 0);
	showsetting($Plang['22eb8a4e41dcef6d'], 'forum[essence_num]', $data['forum']['essence_num'], 'number', '', 0);

	showtitle($Plang['52f380abca9334a4'] . $Plang['mh']);
	groups_set('group[user]', $data['group']['user']);
	showsetting($Plang['6f73e58c05deadab'], 'group[num]', $data['group']['num'], 'number', '', 0);
	showsetting($Plang['22eb8a4e41dcef6d'], 'group[essence_num]', $data['group']['essence_num'], 'number', '', 0);
	showsetting($Plang['a2dafe87a6099970'], 'group[iron_powder]', $data['group']['iron_powder'], 'radio', '', 0);
	showsetting($Plang['de1e44f5572b1b85'], 'group[exp]', $data['group']['exp'], 'number', '', 0);
	showsubmit('sub', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$data['portal'] = $_GET['portal'];
	$data['forum'] = $_GET['forum'];
	$data['group'] = $_GET['group'];

	C::t('common_setting')->update('wq_reward_setting', serialize($data));
	updatecache('setting');
	cpmsg($Plang['aca2899ea8ef4a04'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_rewardsetting', 'succeed');
}
//From: Dism_taobao-com
?>