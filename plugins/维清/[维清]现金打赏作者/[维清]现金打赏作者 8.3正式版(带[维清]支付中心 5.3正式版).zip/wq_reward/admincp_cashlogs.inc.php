<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_cashlogs.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';

if(!submitcheck('operationFom')) {
	$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'desc';
	$audit_stutas = in_array($_GET['audit_stutas'], array('all', '0', '1', '2')) ? (($_GET['audit_stutas'] != 'all') ? $_GET['audit_stutas'] : '') : '';
	$date = in_array($_GET['date'], array('cashtime', 'dateline')) ? $_GET['date'] : 'cashtime';
	$starttime = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['starttime'])) ? strtotime(trim($_GET['starttime'])) : '';
	$endtime = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['endtime'])) ? strtotime(trim($_GET['endtime'])) : '';
	$username = isset($_GET['username']) ? $_GET['username'] : '';
	$adminusername = isset($_GET['adminusername']) ? $_GET['adminusername'] : '';
	$cashno = isset($_GET['cashno']) ? $_GET['cashno'] : '';
	$page = max(1, $_GET['page']);
	$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 20;
	$start = ($page - 1 ) * $perpage;

	$re = C::t("#wq_reward#wq_reward_cash_logs")->fetch_all_by_search($orderby, $audit_stutas, $date, $starttime, $endtime, $username, $adminusername, $cashno, $start, $perpage);
	$count = C::t("#wq_reward#wq_reward_cash_logs")->count_by_search($orderby, $audit_stutas, $date, $starttime, $endtime, $username, $adminusername, $cashno);

	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashlogs';

	$mpurl = 'action=plugins&operati    on=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashlogs';
	$mpurl .= $orderby ? "&orderby=" . $orderby : '';
	$mpurl .= $audit_stutas !== '' ? "&audit_stutas=" . $audit_stutas : '';
	$mpurl .= $date != 'cashtime' ? '&date=' . $date : '';
	$mpurl .= $starttime != '' ? '&starttime=' . $_GET['starttime'] : '';
	$mpurl .= $endtime != '' ? '&endtime=' . $_GET['endtime'] : '';
	$mpurl .= $cashno ? "&cashno=" . $cashno : '';
	$mpurl .= $adminusername ? "&adminusername=" . $adminusername : '';
	$mpurl .= $username ? "&username=" . $username : '';
	$url = ADMINSCRIPT . '?' . $mpurl;

	echo " <script type='text/javascript' src='static/js/calendar.js'></script>
<script>_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e,'forms'); });</script>";

	$order_by = select_html(array('asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'orderby', $orderby, false);
	$stutas = select_html(array('all' => $Plang['8dfe4b30674494c1'], '1' => $Plang['9d990bf361b31e1f'], '0' => $Plang['8ba19cd0d1cde186'], '2' => $Plang['458eae1cb6579fe2']), 'audit_stutas', $audit_stutas, false);
	$datetype = select_html(array('cashtime' => $Plang['47e240d9831e8eb8'], 'dateline' => $Plang['e50372a2086c20c6']), 'date', $date, false);
	$datehtml = text_html($_GET['starttime'], $_GET['endtime']);

	showformheader($fromurl, '', 'sub');
	showtableheader('', 'nobottom');
	showtablerow('', array(), array(
		$Plang['634322b7da234a09'] . $Plang['mh'] . $order_by
		. '&nbsp;&nbsp;' . $Plang['ca5a0d75b677d381'] . $Plang['mh'] . $stutas
		. '&nbsp;&nbsp;' . $datetype . $Plang['mh'] . $datehtml
		. '&nbsp;&nbsp;' . $Plang['95ec3054bf2f60f8'] . $Plang['mh'] . '<input type="text" name="username" value="' . dhtmlspecialchars($_GET['username']) . '" placeholder=' . $Plang['f4234cb9e4e1fdfd'] . '>'
		. '&nbsp;&nbsp;' . $Plang['96238134c0af23c0'] . $Plang['mh'] . '<input type="text" name="adminusername" value="' . dhtmlspecialchars($_GET['adminusername']) . '" placeholder=' . $Plang['9ed5de589c43e6d4'] . '>'
		. '&nbsp;&nbsp;' . $Plang['6992262ee562162c'] . $Plang['mh'] . '<input type="text" name="cashno" value="' . dhtmlspecialchars($_GET['cashno']) . '" placeholder=' . $Plang['3f1ae809167d19da'] . '>'
		. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value=' . $Plang['38224a4a6fc78c7c'] . ' title=' . $Plang['b7bea550cb266984'] . ' />',
	));
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
	$status = array($Plang['8ba19cd0d1cde186'], $Plang['9d990bf361b31e1f'], $Plang['458eae1cb6579fe2']);
	showtableheader('', 'nobottom');
	showsubtitle(array($Plang['2ea0a99c28da4028'], $Plang['9c000fc336da56e1'], $Plang['95ec3054bf2f60f8'], $Plang['6992262ee562162c'], $Plang['e50372a2086c20c6'], $Plang['92dfe870cf630e2d'], $Plang['bdc34y3grikfwe83'], $Plang['t4gr8vf089w3rci7'], $Plang['ca5a0d75b677d381'], $Plang['ec74969f7b1c1b07'], $Plang['47e240d9831e8eb8'], $Plang['96238134c0af23c0'], $Plang['4e64f0e320d8b16b']));
	$tem_userinfo = array();
	foreach($re as $key => $val) {
		if(in_array($val['uid'], $tem_userinfo['uid'])) {
			$realname = $tem_userinfo['name'][$val['uid']];
			$alipay = $tem_userinfo['alipay'][$val['uid']];
		} else {
			$temuser = C::t('#wq_reward#wq_reward_cash_info')->fetch_by_uid($val['uid']);
			$tem_userinfo['uid'][$val['uid']] = $val['uid'];
			$tem_userinfo['name'][$val['uid']] = $realname = $temuser['realname'];
			$tem_userinfo['alipay'][$val['uid']] = $alipay = $temuser['alipay'];
		}
		$cashtime = wq_dgmdate($val['cashtime']);
		$dateline = wq_dgmdate($val['dateline']);
		if($val['status']) {
			$showContent = $Plang['8fe8024cd841091f'];
		} else {
			$showContent = "<a href='javascript:;' onclick='cash_operation({$val[id]});'>" . $Plang['c3e0fcd40c35eb5b'] . "</a>";
		}
		showtablerow('', array(), array(
			$realname,
			$alipay,
			$val['username'],
			$val['cashno'],
			$dateline,
			$val['money'],
			$val['proceduresfree'],
			'<span class="green">' . $val['casemoney'] . '</span>',
			$status[$val['status']],
			$val['remark'],
			$val['adminusername'],
			$cashtime,
			$showContent
		));
	}
	$multi = multi($count, $perpage, $page, $url);
	echo "<tr><td colspan='14' align='right'>" . $multi . "</td></tr>";
	showtablefooter();/*Dism��taobao��com*/

	$operation_url = ADMINSCRIPT . '?action=plugins&operation=config&do=52&identifier=wq_reward&pmod=admincp_cashlogs';
	$hash = FORMHASH;
	echo <<<EOF
    <style>
		.green{ color:green; font-weight:bold}
        #cash_operation{
            width:500px;
            height:200px;
            background:#FFF;
            border:5px solid #CCC;
            z-index: 201;
            border-radius: 8px 8px 8px 8px;
        }
        .flb {
            padding: 10px 10px 8px;
            height: 20px;
            line-height: 20px;
            border-bottom:2px solid #CCC;
        }
        .text_operation{
            text-align:center;
            margin-top:40px;
        }
        .operation_iut{
            border:1px solid #CCC;
            height:25px;
        }
        .explain_text{
            color:red;
            position: relative;
            top:35px;
            left:110px;
        }
    </style>
   <div id="cash_operation" style='display:none;position: fixed;left: 600px;top: 200px;'>
        <h3 class="flb" id="fctrl_reward_btn" style="cursor: move;" onmouseDown="mous_down(this)">
            <em id="return_reward_btn" fwin="reward_btn">{$Plang['00c17f23d7cd0c3b']}</em>
            <span>
                <a href="javascript:;" class="flbc" onclick="cash_operation()" title={$Plang['beb08d096719774b']}>{$Plang['beb08d096719774b']}</a>
            </span>
        </h3>
        <form action='{$operation_url}' method='post'>
          <input type="hidden" name="formhash" value="{$hash}">
            <p id='explain_text' class='explain_text' style='display:none'></p>
            <p class='text_operation'>{$Plang['36603816bcb173c9']}{$Plang['mh']}<input name='explain_content' id='explain_content'type='text' placeholder={$Plang['dd46a4ebdb03f190']} class='operation_iut'>
            <input id='idVal' type='hidden' name='id'>
            <input id='test1' type='hidden' name='test1' value="{$Plang['527c88da5bb0afdf']}">
            <input id='test2' type='hidden' name='test2' value="{$Plang['b4bdb5115408c536']}">
            <input id='pass' class='radio' type='radio' name='operation' value='1' checked><label for='editstatus_0' class = 'vmiddle' onclick='update_checked(true)'>{$Plang['74a3053ecaf07e60']}</label>
            <input id='reject' class='radio' type='radio' name='operation' value='2'><label for='editstatus_1' class = 'vmiddle' onclick='update_checked(false)'>{$Plang['7c49868ac52df584']}</label>
            &nbsp;&nbsp;<input class='btn' type='submit' value={$Plang['6ce0cdd2f7c855aa']} name='operationFom' onclick='text_check()' title={$Plang['b7bea550cb266984']} /></p>
        </form>
   </div>
   <script type='text/javascript'>
        function cash_operation(id){
            var oDiv = document.getElementById('cash_operation');
            var idVal = document.getElementById('idVal');
            if(oDiv.style.display == 'block'){
                oDiv.style.display = 'none';
            }else{
                oDiv.style.display = 'block';
                idVal.value = id;
            }
        }

        function update_checked(t){
            var pass = document.getElementById('pass');
            var reject = document.getElementById('reject');
            var hint = document.getElementById('explain_text').style.display='none';
            if(t){
                pass.checked = 'true';
            }else{
                reject.checked = 'true';
            }
        }

        function text_check(){
            var hint = document.getElementById('explain_text');
            var conter = document.getElementById('explain_content');
            var reject = document.getElementById('reject').checked;
            var test1 = document.getElementById('test1').value;
            var test2 = document.getElementById('test2').value;
            if(!conter.value){
                if(reject){
                   hint.innerHTML = test1;
                }else{
                   hint.innerHTML = test2;
                }
                hint.style.display = 'block';
                window.event.returnValue = false;
            }
        }

        function mous_down(t){
            var obj = document.getElementById('cash_operation');
            var th = event.clientY - parseInt(obj.style.top.replace(/px/, ""));
            var tw = event.clientX - parseInt(obj.style.left.replace(/px/, ""));

            t.onmousemove = mouse_move;
            t.onmouseout = mous_out;
            t.onmouseup = mous_out;
            function mouse_move(){
                var event = window.event || t;
                var top = event.clientY - th;
                var left = event.clientX - tw;

                top = top < 0 ? 0 : top;
                top = top > document.body.offsetHeight? document.body.offsetHeight : top;

                left = left < 0 ? 0 : left;
                left = left > document.body.offsetWidth ? document.body.offsetWidth : left;

                obj.style.top = top + "px";
                obj.style.left = left + "px";
            }
            function mous_out(){
                t.onmousemove = null;
            }
        }
   </script>
EOF;
} else {
	$data = array(
		'remark' => $_GET['explain_content'],
		'status' => $_GET['operation'],
		'adminid' => $_G['uid'],
		'adminusername' => $_G['username'],
		'cashtime' => time()
	);
	$result = C::t("#wq_reward#wq_reward_cash_logs")->update($_GET['id'], $data);
	if($result) {
		$info = C::t("#wq_reward#wq_reward_cash_logs")->fetch(intval($_GET['id']));
		$userinfo = C::t("#wq_reward#wq_reward_userinfo")->fetch_first_by_uid(intval($info['uid']));
		$updatedata = array(
			'frozenmoney' => $userinfo['frozenmoney'] - $info['money'],
		);
		if($data['status'] == 1) {
			$msg = $Plang['74a3053ecaf07e60'];
			$updatedata['cashmoney'] = $userinfo['cashmoney'] + $info['money'];
			$updatedata['proceduresfreesum'] = $userinfo['proceduresfreesum'] + $info['proceduresfree'];
		} else {
			$msg = $Plang['7c49868ac52df584'];
			$updatedata['availablemoney'] = $userinfo['availablemoney'] + $info['money'];
		}
		send_message_admin(sprintf($Plang['658dbc8a0a1d6b5c'], $msg), $info['uid']);
		C::t("#wq_reward#wq_reward_userinfo")->update($userinfo['id'], $updatedata);
		cpmsg($Plang['aca2899ea8ef4a04'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashlogs', 'succeed');
	} else {
		cpmsg($Plang['b037c98130120ea3'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_cashlogs', 'error');
	}
}
//From: Dism_taobao-com
?>