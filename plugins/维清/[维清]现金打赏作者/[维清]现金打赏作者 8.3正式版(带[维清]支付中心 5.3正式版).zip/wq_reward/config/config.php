<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';
include_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_order.php';

$Plang = wq_loadlang('wq_reward');

$setting = wq_loadsetting('wq_reward');
$setting['trade_explain'] = trim($setting['trade_explain']) ? trim($setting['trade_explain']) : $Plang['17edcf3fe39334f9'];
$setting['send_msg_uids'] = explode(",", rtrim(str_replace($Plang['275fd2a0d026ec2a'], ',', $setting['send_msg_uids']), ','));
$backurl = wq_get_backurl();

?>