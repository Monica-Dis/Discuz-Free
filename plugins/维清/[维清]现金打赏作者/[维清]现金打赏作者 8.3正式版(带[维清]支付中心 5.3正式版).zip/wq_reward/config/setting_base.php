<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-3-30 08:57:48Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_reward'];
$setting['allow_portal'] = intval($setting['allow_portal']);
$setting['allow_forum'] = intval($setting['allow_forum']);
$setting['allow_group'] = intval($setting['allow_group']);
$setting['allow_wechatcollecting'] = intval($setting['allow_wechatcollecting']);
$setting['open_wxpay'] = intval($setting['open_wxpay']);
$setting['browser_is_can_wechatpay'] = intval($setting['browser_is_can_wechatpay']);
$setting['open_alipay'] = intval($setting['open_alipay']);
$setting['reward_template'] = trim($setting['reward_template']);
$setting['default_num'] = trim($setting['default_num']);
$setting['allow_custom'] = intval($setting['allow_custom']);
$setting['custom_min'] = intval($setting['custom_min']);
$setting['custom_max'] = intval($setting['custom_max']);
$setting['pc_view_num'] = intval($setting['pc_view_num']);
$setting['m_view_num'] = intval($setting['m_view_num']);
$setting['case_min'] = intval($setting['case_min']);
$setting['pertime_case_min'] = intval($setting['pertime_case_min']);
$setting['case_percentage'] = intval($setting['case_percentage']);
$setting['case_dealdays'] = intval($setting['case_dealdays']);
$setting['perpage'] = intval($setting['perpage']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['reward_sign'] = trim($setting['reward_sign']);
$setting['mobile_viewlog'] = intval($setting['mobile_viewlog']);
$setting['mobile_viewlog_num'] = intval($setting['mobile_viewlog_num']);
$setting['reward_button_text'] = trim($setting['reward_button_text']);
$setting['trade_explain'] = trim($setting['trade_explain']);
$setting['tourist_is_reward'] = intval($setting['tourist_is_reward']);
$setting['is_show_totalmoney'] = intval($setting['is_show_totalmoney']);
$setting['reply_is_reward'] = intval($setting['reply_is_reward']);
$setting['reward_look_groupid'] = unserialize($setting['reward_look_groupid']);
$setting['not_reward_lookpost'] = unserialize($setting['not_reward_lookpost']);
$setting['reward_look_money'] = trim($setting['reward_look_money']);
$setting['reward_look_txt'] = trim($setting['reward_look_txt']);
$setting['cash_is_idcard'] = intval($setting['cash_is_idcard']);
$setting['cash_is_phone'] = intval($setting['cash_is_phone']);
$setting['is_show_userlist'] = intval($setting['is_show_userlist']);
$setting['send_msg_uids'] = trim($setting['send_msg_uids']);

?>