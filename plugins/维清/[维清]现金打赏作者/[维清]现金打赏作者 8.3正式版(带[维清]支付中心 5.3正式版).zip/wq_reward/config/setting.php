<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_reward/config/setting_base.php';
$setting['custom_min'] = round($setting['custom_min'], 2);
$setting['custom_max'] = round($setting['custom_max'], 2);
$setting['reward_look_money'] = $setting['reward_look_money'] ? explode('~', $setting['reward_look_money']) : '';

?>