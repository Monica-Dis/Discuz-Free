<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_rank.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_userinfo extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_userinfo';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_uid($uid) {
		$array = array($this->_table, $uid);
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d", $array);
	}

	public function fetch_all_by_search($reward_num, $sum_money, $allow_money, $already_money, $freeze_money, $deduct_money, $fromusername, $start, $perpage) {
		$val[] = $this->_table;
		$where = 1;
		$order = " ORDER BY id DESC";
		if($reward_num && $reward_num != 'no') {
			$order = " ORDER BY rewardcount %i";
			$val[] = strtoupper($reward_num);
		}
		if($sum_money && $sum_money != 'no') {
			$order = " ORDER BY rewardsum %i";
			$val[] = strtoupper($sum_money);
		}
		if($allow_money && $allow_money != 'no') {
			$order = " ORDER BY availablemoney %i";
			$val[] = strtoupper($allow_money);
		}
		if($already_money && $already_money != 'no') {
			$order = " ORDER BY cashmoney %i";
			$val[] = strtoupper($already_money);
		}
		if($freeze_money && $freeze_money != 'no') {
			$order = " ORDER BY frozenmoney %i";
			$val[] = strtoupper($freeze_money);
		}
		if($deduct_money && $deduct_money != 'no') {
			$order = " ORDER BY proceduresfreesum %i";
			$val[] = strtoupper($deduct_money);
		}
		if($fromusername) {
			$where = "username=%s";
			$val[] = $fromusername;
		}
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . $order . DB::limit($start, $perpage), $val);
	}

	public function count_by_search($fromusername) {
		$where = 1;
		$val[] = $this->_table;
		if($fromusername) {
			$where = 'username=%s';
			$val[] = $fromusername;
		}
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
	}

	public function fetch_money_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

}
//From: Dism_taobao-com
?>