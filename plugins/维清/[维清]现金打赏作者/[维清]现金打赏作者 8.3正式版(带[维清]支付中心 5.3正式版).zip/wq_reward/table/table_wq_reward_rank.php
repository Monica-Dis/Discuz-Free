<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_rank.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_rank extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_rank';
		$this->_pk = 'rankid';
		parent::__construct();
	}

	function fetch_all_by_id_type($infoid, $idtype = 'ftid', $pid = 0, $lastid = 0, $money = 0, $perpage = 0) {
		$val[] = $this->_table;
		$sql[] = 'infoid=%d';
		$val[] = $infoid;
		$sql[] = 'idtype=%s';
		$val[] = $idtype;
		$sql[] = 'pid=%d';
		if($pid) {
			$val[] = $pid;
		} else {
			$val[] = 0;
		}
		if($lastid && $money) {
			$sql[] = 'money<=%f';
			$val[] = $money;
			$sql[] = 'rankid<%d';
			$val[] = $lastid;
		}
		$where = implode(' AND ', $sql);
		$order = ' ORDER BY money DESC,rankid DESC';
		if($perpage) {
			$limit = DB::limit($perpage);
		}
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . $order . $limit, $val);
	}

	function count_by_id_infoid_idtype($infoid, $idtype, $pid = 0) {
		$array = array($this->_table, $infoid, $idtype);
		$where = '';
		$where = ' AND pid=%d';
		if($pid) {
			array_push($array, $pid);
		} else {
			array_push($array, 0);
		}
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE infoid=%d AND idtype = %s" . $where, $array);
	}

	function fetch_first_by_tid_uid_pid($tid, $uid, $pid = 0) {
		$array = array($this->_table, $tid, $uid);
		$where = ' AND pid=%d';
		if($pid) {
			array_push($array, $pid);
		} else {
			array_push($array, 0);
		}
		return DB::fetch_first("SELECT * FROM %t WHERE infoid=%d AND uid=%d" . $where, $array);
	}

}
//From: Dism_taobao-com
?>