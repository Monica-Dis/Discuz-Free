<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_casn_info.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_cash_info extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_cash_info';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_all_by_search($orderby, $audit_stutas, $idcard, $realname, $alipay, $start, $limit) {
		$val[] = $this->
			_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($audit_stutas !== '' || $audit_stutas) {
			$sql[] = 'status=%d';
			$val[] = $audit_stutas;
		}

		if($idcard) {
			$sql[] = 'idcard=%s';
			$val[] = $idcard;
		}
		if($realname) {
			$sql[] = 'realname=%s';
			$val[] = $realname;
		}
		if($alipay) {
			$sql[] = 'alipay=%s';
			$val[] = $alipay;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($orderby, $audit_stutas, $idcard, $realname, $alipay) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($audit_stutas !== '' || $audit_stutas) {
			$sql[] = 'status=%d';
			$val[] = $audit_stutas;
		}

		if($idcard) {
			$sql[] = 'idcard=%s';
			$val[] = $idcard;
		}
		if($realname) {
			$sql[] = 'realname=%s';
			$val[] = $realname;
		}
		if($alipay) {
			$sql[] = 'alipay=%s';
			$val[] = $alipay;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql . $order, $val);
	}

	function fetch_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d ORDER BY id DESC", array($this->_table, $uid));
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}

}
//From: Dism_taobao-com
?>