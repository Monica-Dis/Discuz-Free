<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_sample.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_record extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_record';
		$this->_pk = 'infoid';
		parent::__construct();
	}

	public function update_status_by_orderno($orderid, $data) {
		if(!$orderid) {
			return false;
		}
		return DB::update($this->_table, $data, array('orderno' => $orderid));
	}

	public function fetch_all_by_search($orderby, $typeid, $isanon, $isstutas, $methodpay, $fromusername, $tousername, $orderno, $start, $limit) {
		$val[] = $this->
			_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($typeid) {
			$sql[] = 'idtype=%s';
			$val[] = $typeid;
		}

		if($isanon !== '' || $isanon) {
			$sql[] = 'isanonymity=%d';
			$val[] = $isanon;
		}
		if($isstutas !== '' || $isstutas) {
			$sql[] = 'status=%d';
			$val[] = $isstutas;
		}

		if($methodpay) {
			$sql[] = 'paymethod=%s';
			$val[] = $methodpay;
		}
		if($fromusername) {
			if($fromusername == 'tourist') {
				$sql[] = 'fromusername=\'\'';
			} else {
				$sql[] = 'fromusername=%s';
				$val[] = $fromusername;
			}
		}
		if($tousername) {
			$sql[] = 'tousername=%s';
			$val[] = $tousername;
		}
		if($orderno) {
			$sql[] = 'orderno=%s';
			$val[] = $orderno;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($orderby, $typeid, $isanon, $isstutas, $methodpay, $fromusername, $tousername, $orderno) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($typeid) {
			$sql[] = 'idtype=%s';
			$val[] = $typeid;
		}

		if($isanon !== '' || $isanon) {
			$sql[] = 'isanonymity=%d';
			$val[] = $isanon;
		}
		if($isstutas !== '' || $isstutas) {
			$sql[] = 'status=%d';
			$val[] = $isstutas;
		}

		if($methodpay) {
			$sql[] = 'paymethod=%s';
			$val[] = $methodpay;
		}
		if($fromusername) {
			$sql[] = 'fromusername=%s';
			$val[] = $fromusername;
		}
		if($tousername) {
			$sql[] = 'tousername=%s';
			$val[] = $tousername;
		}
		if($orderno) {
			$sql[] = 'orderno=%s';
			$val[] = $orderno;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function fetch_all_by_fromuid_or_touid($type, $uid, $start = '', $perpage = '') {
		$where = 'status=1 AND ';
		if($type && $type == 'out') {
			$where .= 'fromuid=%d';
		} else {
			$where .= 'touid=%d';
		}
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . " ORDER BY dateline DESC" . DB::limit($start, $perpage), array($this->_table, $uid));
	}

	public function count_num_by_uid($type, $flag, $uid) {
		$where = 'status=1 AND ';
		if($type && $type == 'out') {
			$where .= 'fromuid=%d';
		} else {
			$where .= 'touid=%d';
		}

		if($flag) {
			$operation = "COUNT(*)";
		} else {
			$operation = "SUM(money)";
		}
		return DB::result_first("SELECT " . $operation . " FROM %t WHERE " . $where, array($this->_table, $uid));
	}

	public function fetch_first_by_orderid($orderno) {
		return DB::fetch_first("SELECT * FROM %t WHERE orderno=%s", array($this->_table, $orderno));
	}

	public function fetch_sum_money_by_infoid_idtype($infoid, $idtype, $pid = 0, $fromuid = 0) {
		$array = array($this->_table, $infoid, $idtype);
		$where = ' AND pid=%d';
		if($pid) {
			array_push($array, $pid);
		} else {
			array_push($array, 0);
		}
		if($fromuid) {
			$where .= ' AND fromuid=%d';
			array_push($array, $fromuid);
		}
		return DB::fetch_first("SELECT SUM(money) as totalmoney FROM %t WHERE status=1 AND infoid=%d AND idtype=%s" . $where, $array);
	}

}
//From: Dism_taobao-com
?>