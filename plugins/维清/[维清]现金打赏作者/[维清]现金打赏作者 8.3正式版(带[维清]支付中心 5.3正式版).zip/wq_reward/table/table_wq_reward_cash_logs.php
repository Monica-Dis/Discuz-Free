<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_casn_infos.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_cash_logs extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_cash_logs';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_all_by_search($orderby, $audit_stutas, $date, $starttime, $endtime, $username, $adminusername, $cashno, $start, $limit) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($audit_stutas !== '' || $audit_stutas) {
			$sql[] = 'status=%d';
			$val[] = $audit_stutas;
		}
		if($date && $starttime) {
			$sql[] = $date . '>=%d';
			$val[] = $starttime;
		}
		if($date && $endtime) {
			$sql[] = $date . '<=%d';
			$val[] = $endtime;
		}

		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}
		if($adminusername) {
			$sql[] = 'adminusername=%s';
			$val[] = $adminusername;
		}
		if($cashno) {
			$sql[] = 'cashno=%s';
			$val[] = $cashno;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($orderby, $audit_stutas, $date, $starttime, $endtime, $username, $adminusername, $cashno) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}
		if($audit_stutas !== '' || $audit_stutas) {
			$sql[] = 'status=%d';
			$val[] = $audit_stutas;
		}
		if($date && $starttime) {
			$sql[] = $date . '>=%d';
			$val[] = $starttime;
		}
		if($date && $endtime) {
			$sql[] = $date . '<=%d';
			$val[] = $endtime;
		}

		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}
		if($adminusername) {
			$sql[] = 'adminusername=%s';
			$val[] = $adminusername;
		}
		if($cashno) {
			$sql[] = 'cashno=%s';
			$val[] = $cashno;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function count_by_uid($uid, $flag = false) {
		if($flag) {
			$operation = "SUM(money)";
			$where = "AND status = 1";
		} else {
			$operation = "COUNT(*)";
		}

		return DB::result_first("SELECT " . $operation . " FROM %t WHERE uid=%d " . $where, array($this->_table, $uid));
	}

	public function fetch_all_by_uid($uid, $start = '', $perpage = '') {
		return DB::fetch_all("SELECT * FROM %t  WHERE uid=%d  ORDER BY dateline DESC" . DB::limit($start, $perpage), array($this->_table, $uid));
	}

}
//From: Dism_taobao-com
?>