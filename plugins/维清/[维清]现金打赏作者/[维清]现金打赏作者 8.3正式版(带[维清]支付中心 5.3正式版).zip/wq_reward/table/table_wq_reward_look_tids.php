<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_reward_rank.php 2016-4-21 02:35:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_reward_look_tids extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_reward_look_tids';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_by_uid_tid_pid($uid = 0, $tid = 0, $pid = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($tid) {
			$sql[] = 'tid=%d';
			$val[] = $tid;
		}
		if($pid) {
			$sql[] = 'pid=%d';
			$val[] = $pid;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $where, $val);
	}

}
//From: Dism_taobao-com
?>