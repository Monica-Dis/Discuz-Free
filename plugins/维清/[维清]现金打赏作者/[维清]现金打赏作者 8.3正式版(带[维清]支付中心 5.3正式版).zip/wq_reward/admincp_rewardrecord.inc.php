<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_rewardrecord.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';

$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'desc';
$typeid = in_array($_GET['typeid'], array('all', 'ftid', 'aid', 'gtid')) ? (($_GET['typeid'] != 'all') ? $_GET['typeid'] : '') : '';
$isanon = in_array($_GET['isanon'], array('all', '1', '0')) ? (($_GET['isanon'] != 'all') ? $_GET['isanon'] : '') : '';
$isstutas = in_array($_GET['isstutas'], array('all', '1', '0')) ? (($_GET['isstutas'] != 'all') ? $_GET['isstutas'] : '') : '';
$methodpay = in_array($_GET['methodpay'], array('all', 'wechat', 'alipay', 'tenpay')) ? (($_GET['methodpay'] != 'all') ? $_GET['methodpay'] : '') : '';
$fromusername = isset($_GET['fromusername']) ? (trim($_GET['fromusername']) == $Plang['a89848wes214ccef'] ? 'tourist' : trim($_GET['fromusername'])) : '';
$tousername = isset($_GET['tousername']) ? $_GET['tousername'] : '';
$orderno = isset($_GET['orderno']) ? $_GET['orderno'] : '';
$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 10;
$start = ($page - 1 ) * $perpage;

$re = C::t("#wq_reward#wq_reward_record")->fetch_all_by_search($orderby, $typeid, $isanon, $isstutas, $methodpay, $fromusername, $tousername, $orderno, $start, $perpage);
$count = C::t("#wq_reward#wq_reward_record")->count_by_search($orderby, $typeid, $isanon, $isstutas, $methodpay, $fromusername, $tousername, $orderno);

$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_rewardrecord';

$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_rewardrecord';
$mpurl .= $orderby ? "&orderby=" . $orderby : '';
$mpurl .= $typeid ? "&typeid=" . $typeid : '';
$mpurl .= $isanon !== '' ? "&isanon=" . $isanon : '';
$mpurl .= $isstutas !== '' ? "&isstutas=" . $isstutas : '';
$mpurl .= $methodpay ? "&methodpay=" . $methodpay : '';
$mpurl .= $fromusername ? "&fromusername=" . $fromusername : '';
$mpurl .= $orderno ? "&orderno=" . $orderno : '';
$mpurl .= $tousername ? "&tousername=" . $tousername : '';
$url = ADMINSCRIPT . '?' . $mpurl;

$order_by = select_html(array('asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'orderby', $orderby, false);
$idtype = select_html(array('all' => $Plang['8dfe4b30674494c1'], 'ftid' => $Plang['8d163a68dea0ccb4'], 'aid' => $Plang['68b75fc9ab21a7ed'], 'gtid' => $Plang['20d01d716f550469']), 'typeid', $typeid, false);
$isanonymity = select_html(array('all' => $Plang['8dfe4b30674494c1'], '1' => $Plang['c7b4099dec98b579'], '0' => $Plang['5b553415507d5daf'],), 'isanon', $isanon, false);
$stutas = select_html(array('all' => $Plang['8dfe4b30674494c1'], '1' => $Plang['c7b4099dec98b579'], '0' => $Plang['5b553415507d5daf'],), 'isstutas', $isstutas, false);
$paymethod = select_html(array('all' => $Plang['8dfe4b30674494c1'], 'wechat' => $Plang['fd32f2cf594cdeb8'], 'alipay' => $Plang['115c0265d921fc45'], 'tenpay' => $Plang['63fc0fd49ad93253']), 'methodpay', $methodpay, false);

showformheader($fromurl, '', 'sub');
showtableheader('', 'nobottom');
showtablerow('', array(), array(
	$Plang['056d16337e0cdbfa'] . $Plang['mh'] . $order_by
	. "&nbsp;&nbsp;" . $Plang['4f6a428e7b9ca637'] . $Plang['mh'] . $idtype
	. "&nbsp;&nbsp;" . $Plang['51834a50e8d23da5'] . $Plang['mh'] . $isanonymity
	. "&nbsp;&nbsp;" . $Plang['4d6bf0b6c6d7d081'] . $Plang['mh'] . $stutas
	. "&nbsp;&nbsp;" . $Plang['99dca5844823748d'] . $Plang['mh'] . $paymethod
	. '&nbsp;&nbsp;' . $Plang['fc2ba7c12999eff4'] . $Plang['mh'] . '<input type="text" name="fromusername" value="' . dhtmlspecialchars($_GET['fromusername']) . '" placeholder=' . $Plang['3cb359219d82f955'] . '>'
	. '&nbsp;&nbsp;' . $Plang['d076ef137b1091a6'] . $Plang['mh'] . '<input type="text" name="tousername" value="' . dhtmlspecialchars($_GET['tousername']) . '" placeholder=' . $Plang['8caca70ee802f47e'] . '>'
	. '&nbsp;&nbsp;' . $Plang['2ab1bf253af4849c'] . $Plang['mh'] . '<input type="text" name="orderno" value="' . dhtmlspecialchars($_GET['orderno']) . '" placeholder=' . $Plang['7eb71b88f7534980'] . '>'
	. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value=' . $Plang['38224a4a6fc78c7c'] . ' title=' . $Plang['b7bea550cb266984'] . ' />',
));
showtablefooter();/*Dism��taobao��com*/
showformfooter();
$idtype = array('ftid' => $Plang['8d163a68dea0ccb4'], 'aid' => $Plang['68b75fc9ab21a7ed'], 'gtid' => $Plang['20d01d716f550469'], 'articleid' => $Plang['f3349574d937b408']);
$is_hidden = array($Plang['c7b4099dec98b579'], $Plang['5b553415507d5daf']);
$payType = array('wechat' => $Plang['fd32f2cf594cdeb8'], 'alipay' => $Plang['115c0265d921fc45'], 'tenpay' => $Plang['63fc0fd49ad93253']);
$payStatus = array($Plang['b1e3e71ea288b55f'], $Plang['903ae30e5effa5b8']);
showtableheader('', 'nobottom');
showsubtitle(array($Plang['b543f88a48c9cf72'], $Plang['4f6a428e7b9ca637'], $Plang['fc2ba7c12999eff4'], $Plang['d076ef137b1091a6'], $Plang['51834a50e8d23da5'], $Plang['2ab1bf253af4849c'], $Plang['e351cb63222c5374'], $Plang['a23e0d6af6c1f0b4'], $Plang['99dca5844823748d'], $Plang['4d6bf0b6c6d7d081'], $Plang['81acdc0b4427b1bd'], $Plang['e8c769e904ed465c']));
foreach($re as $key => $val) {
	$dataline = wq_dgmdate($val["dateline"]);
	$paytime = wq_dgmdate($val["paytime"]);
	$pr = $val['idtype'] == 'articleid' ? '' : $Plang['first_post'];
	$locurl = 'forum.php?mod=viewthread&tid=' . $val['infoid'];
	if($val['pid']) {
		$pr = $Plang['reply_post'];
		$locurl = 'forum.php?mod=redirect&goto=findpost&ptid=' . $val['infoid'] . '&pid=' . $val['pid'];
	} elseif($val['idtype'] == 'aid') {
		$locurl = 'portal.php?mod=view&aid=' . $val['infoid'];
	} elseif($val['idtype'] == 'articleid') {
		$locurl = 'plugin.php?id=wq_wechatcollecting&mod=view&articleid=' . $val['infoid'];
	}
	showtablerow('', array(), array(
		"<a href='" . $locurl . "' target=\"_blank\">" . $val['infoid'] . "</a>",
		$idtype[$val['idtype']] . $pr,
		$val['fromusername'] ? $val['fromusername'] : $Plang['a89848wes214ccef'],
		$val['tousername'],
		$is_hidden[$val['isanonymity']],
		$val['orderno'],
		$val['money'],
		$val['proceduresfree'],
		$payType[$val['paymethod']],
		$payStatus[$val['status']],
		$dataline,
		$paytime,
	));
}
$multi = multi($count, $perpage, $page, $url);
echo "<tr><td colspan='14' align='right'>" . $multi . "</td></tr>";
showtablefooter();/*Dism��taobao��com*/

?>