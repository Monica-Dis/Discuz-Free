<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_userinfo.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';

$reward_num = in_array($_GET['reward_num'], array('desc', 'asc')) ? $_GET['reward_num'] : 'no';
$sum_money = in_array($_GET['sum_money'], array('desc', 'asc')) ? $_GET['sum_money'] : 'no';
$allow_money = in_array($_GET['allow_money'], array('desc', 'asc')) ? $_GET['allow_money'] : 'no';
$already_money = in_array($_GET['already_money'], array('desc', 'asc')) ? $_GET['already_money'] : 'no';
$freeze_money = in_array($_GET['freeze_money'], array('desc', 'asc')) ? $_GET['freeze_money'] : 'no';
$deduct_money = in_array($_GET['deduct_money'], array('desc', 'asc')) ? $_GET['deduct_money'] : 'no';
$username = $_GET['username'] ? trim($_GET['username']) : '';

$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 20;
$start = ($page - 1 ) * $perpage;

$re = C::t("#wq_reward#wq_reward_userinfo")->fetch_all_by_search($reward_num, $sum_money, $allow_money, $already_money, $freeze_money, $deduct_money, $username, $start, $perpage);
$count = C::t("#wq_reward#wq_reward_userinfo")->count_by_search($username);

$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_userinfo';

$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_reward&pmod=admincp_userinfo';
$mpurl .= $reward_num ? "&reward_num=" . $reward_num : '';
$mpurl .= $sum_money ? "&sum_money=" . $sum_money : '';
$mpurl .= $allow_money ? "&allow_money=" . $allow_money : '';
$mpurl .= $already_money ? "&already_money=" . $already_money : '';
$mpurl .= $freeze_money ? "&freeze_money=" . $freeze_money : '';
$mpurl .= $deduct_money ? "&deduct_money=" . $deduct_money : '';
$mpurl .= $username ? "&username=" . $username : '';
$url = ADMINSCRIPT . '?' . $mpurl;

$rewardcount_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'reward_num', $reward_num, false);
$rewardsum_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'sum_money', $sum_money, false);
$availablemoney_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'allow_money', $allow_money, false);
$cashmoney_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'already_money', $already_money, false);
$freeze_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'freeze_money', $freeze_money, false);
$proceduresfreesum_html = select_html(array('no' => $Plang['1ff473de6cbef96f'], 'asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'deduct_money', $deduct_money, false);


showformheader($fromurl, '', 'sub');
showtableheader();
showtablerow('', array(), array(
	$Plang['6e8002ff87b1fda5'] . $Plang['mh'] . $rewardcount_html
	. "&nbsp;&nbsp;" . $Plang['a0a9cc718fed9cc6'] . $Plang['mh'] . $rewardsum_html
	. "&nbsp;&nbsp;" . $Plang['08bc22d1af4fd22c'] . $Plang['mh'] . $availablemoney_html
	. "&nbsp;&nbsp;" . $Plang['52c2b9a8a58d6b59'] . $Plang['mh'] . $cashmoney_html
	. "&nbsp;&nbsp;" . $Plang['ba0b7be9c5a72f13'] . $Plang['mh'] . $freeze_html
	. "&nbsp;&nbsp;" . $Plang['72a4594bea78bcfc'] . $Plang['mh'] . $proceduresfreesum_html
	. '&nbsp;&nbsp;' . $Plang['ef832280da56c239'] . $Plang['mh'] . '<input type="text" name="username" value="' . dhtmlspecialchars($_GET['username']) . '" placeholder=' . $Plang['8caca70ee802f47e'] . '>'
	. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value=' . $Plang['38224a4a6fc78c7c'] . ' title=' . $Plang['b7bea550cb266984'] . ' />',
));
showtablefooter();/*Dism��taobao��com*/
showformfooter();

showtableheader();
showsubtitle(array($Plang['d076ef137b1091a6'], $Plang['1f82a26cd1679939'], $Plang['8e4bcb6a887d4e17'], $Plang['2e9c1fbf65abfe34'], $Plang['b7017bef8da952de'], $Plang['5d4720626d457fff'], $Plang['7b208877a4dd4c5a']));
foreach($re as $key => $val) {
	showtablerow('', array(), array(
		$val['username'],
		$val['rewardcount'],
		$val['rewardsum'],
		$val['availablemoney'],
		$val['cashmoney'],
		$val['frozenmoney'],
		$val['proceduresfreesum']
	));
}
$multi = multi($count, $perpage, $page, $url);
echo "<tr><td colspan='7' align='right'>" . $multi . "</td></tr>";
showtablefooter();/*Dism��taobao��com*/

?>