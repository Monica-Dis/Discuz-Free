<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: spacecp_reward.inc.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/config.php';

$referer = $_SERVER["HTTP_REFERER"] ? true : false;
$allowsubop = array('apply', 'applylog', 'rewardlogs');
$subop = !in_array($_GET['subop'], $allowsubop) ? 'rewardlogs' : $_GET['subop'];

require DISCUZ_ROOT . './source/plugin/wq_reward/module/spacecp_' . $subop . '.php';

?>