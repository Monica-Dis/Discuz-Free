<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: reward_list.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$setting['is_show_userlist']) {
	showmessage($Plang['9edeac8d7428310b'], dreferer());
}
$idtype = $_GET['idtype'] ? dhtmlspecialchars($_GET['idtype']) : '';
$infoid = $_GET['infoid'] ? intval($_GET['infoid']) : '';
$pid = $_GET['pid'] ? intval($_GET['pid']) : '';

$data = get_article_info($idtype, $infoid, $pid);

$page = max(1, $_GET['page']);
$perpage = $setting['perpage'] ? $setting['perpage'] : 10;
$start = ($page - 1 ) * $perpage;
$lastid = $_GET['lastid'];
$money = $_GET['money'];

$pageUrl = 'plugin.php?id=wq_reward&mod=list';
$pageUrl .= $infoid ? '&infoid=' . $infoid : '';
$pageUrl .= $idtype ? '&idtype=' . $idtype : '';
$pageUrl .= $pid ? '&pid=' . $pid : '';
$pageUrl .= '&page=' . $page;


$list = C::t('#wq_reward#wq_reward_rank')->fetch_all_by_id_type($infoid, $idtype, $pid, $lastid, $money, $perpage);
$count = C::t('#wq_reward#wq_reward_rank')->count_by_id_infoid_idtype($infoid, $idtype, $pid);

foreach($list as $key => $val) {
	$uids[] = $val['uid'];
}

$dreferer = $backurl;
if($idtype == 'aid') {
	$dreferer = $_G['siteurl'] . 'portal.php?mod=view&aid=' . $infoid . '&pid=' . $pid;
} elseif($idtype == 'articleid') {
	$dreferer = $_G['siteurl'] . 'plugin.php?id=wq_wechatcollecting&mod=view&articleid=' . $infoid;
} else {
	$dreferer = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $infoid . '&pid=' . $pid;
}
if($uids) {
	$userlist = get_user_name_by_uids($uids);
}
$switch_buluo = false;
if($_G['cache']['plugin']['wq_buluo']) {
	$switch_buluo = true;
}

include_once template('wq_reward:tpl_reward_list');

?>