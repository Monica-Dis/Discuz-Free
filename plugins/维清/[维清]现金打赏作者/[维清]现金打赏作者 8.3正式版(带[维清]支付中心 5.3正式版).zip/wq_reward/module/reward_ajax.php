<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: reward_ajax.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_wxpayapi.php';
require_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_alipayapi.php';

$param = $_GET;
clear_day_nopay_orderid();

$param['orderid'] = wq_found_orderid('wq_reward_record', 'orderno');
if(!add_reward_order($param)) {
	echo $Plang['d424f0d5e0b94614'];
	exit;
}

if($duebug) {
	if($param['paymethod'] == 'alipay') {
		$param['money'] = $param['money'] / 100;
	}
} else {
	if($param['paymethod'] == 'wechat') {
		$param['money'] = $param['money'] * 100;
	}
}

$fun_name = '';
if($param['paymethod'] == 'alipay') {
	$fun_name = 'wq_moblie_alipay';
} elseif($param['paymethod'] == 'wechat') {
	$fun_name = $_G['mobile'] ? 'jsapi_wxpay' : 'native_wxpay';
}

if(function_exists($fun_name)) {
	$result = $fun_name($param);

	if(strtolower($param['paymethod']) == 'wechat') {
		$decode = json_decode($result, true);
		if($decode['code'] != '0') {
			del_not_pay_order($param['orderid']);
		}
		if($decode['code'] == '0' && $param['isbrowser'] == 1) {
			$decode['url'] = 'https://wx.tenpay.com/cgi-bin/mmpayweb-bin/checkmweb?' . $decode['msg']['package'] . '&package=1037687096&redirect_url=' . urlencode($param['return_url']);
			$decode = json_encode($decode);
			echo $decode;
			exit;
		}
	}
	echo $result;
	exit;
}
//From: Dism_taobao-com
?>