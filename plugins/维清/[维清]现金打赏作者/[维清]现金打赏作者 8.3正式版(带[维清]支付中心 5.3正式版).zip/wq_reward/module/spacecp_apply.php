<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: spacecp_apply.php 2016-4-23 16:48:21Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$re = C::t("#wq_reward#wq_reward_cash_info")->fetch_by_uid($_G['uid']);
$dreferer = dreferer();
if($re && $re['statsu'] != -1) {
	$alipay = alipay_account_replace($re['alipay']);

	$userinfo = C::t("#wq_reward#wq_reward_userinfo")->fetch_money_by_uid($_G['uid']);

	$availablemoney = $userinfo['availablemoney'] ? $userinfo['availablemoney'] : 0;
}

if($_G['uid'] && submitcheck('sub')) {
	$edit = $_GET['edit'];
	if(empty($_GET['name']) || (CHARSET != "utf-8" && strlen($_GET['name']) > 8) || (CHARSET == "utf-8" && strlen($_GET['name']) > 12)) {
		showmessage($Plang['77b3de4ed9f986ad']);
	}
	$phone = trim($_GET['phone']);
	if($setting['cash_is_phone'] && (!$phone || !preg_match("/^1[34578]{1}\d{9}$/", $phone))) {
		showmessage($Plang['2a5ca3cedaeab7ed']);
	}
	if(empty($_GET['alipay'])) {
		showmessage($Plang['b9bd8b27002e0541']);
	}

	$idcard = trim($_GET['idcard']);
	$idlen = strlen($idcard);
	if($setting['cash_is_idcard'] && (!$idcard || !in_array($idlen, array(15, 18)))) {
		showmessage($Plang['99b379a038cb6608']);
	}
	if(!$_GET['passwd'] || !wq_reward_check_password($_GET['passwd'])) {
		showmessage($Plang['39dd98c43e58459f']);
	}


	$data = array(
		'uid' => $_G['uid'],
		'alipay' => $_GET['alipay'],
		'realname' => $_GET['name'],
		'dateline' => time(),
		'status' => 0,
		'remark' => $Plang['75709618b86fa88a']
	);
	if($setting['cash_is_idcard']) {
		$data['idcard'] = $idcard;
	}
	if($setting['cash_is_phone']) {
		$data['phone'] = $phone;
	}

	if($edit) {
		C::t('#wq_reward#wq_reward_cash_info')->update($re['id'], $data);
		$dreferer = $_GET['dreferer'];
		send_message_admin(sprintf($Plang['ce2948feaa3d16ca'], $_G['username']));
	} else {
		C::t("#wq_reward#wq_reward_cash_info")->insert($data);
		send_message_admin(sprintf($Plang['b87f044bb2c645bd'], $_G['username']));
	}

	showmessage($Plang['cf41fa8c8a534833'], $dreferer);
} elseif($_G['uid'] && submitcheck('submit')) {
	if($_GET['money'] && is_numeric($_GET['money'])) {
		if($_GET['money'] < $setting['pertime_case_min']) {
			showmessage(sprintf($Plang['0b3c211cbaf4b8c0'], $setting['pertime_case_min']));
		}
		if($_GET['money'] > $availablemoney) {
			showmessage($Plang['9efb9c1686e71270']);
		}
		if($availablemoney < $setting['case_min']) {
			showmessage($Plang['e29610d41cd774e1']);
		}

		$order = wq_found_orderid('wq_reward_cash_logs', 'cashno');
		if(!$order) {
			showmessage($Plang['bdc4e736466c2773']);
		}
		$case_percentage = round($_GET['money'] * $setting['case_percentage'] / 100, 2);
		$casemoney = $_GET['money'] - $case_percentage;
		$data = array(
			'uid' => $re['uid'],
			'username' => $_G['username'],
			'cashno' => $order,
			'dateline' => time(),
			'money' => $_GET['money'],
			'proceduresfree' => $case_percentage,
			'casemoney' => $casemoney,
			'status' => 0,
			'remark' => sprintf($Plang['10acad6b0f9edd33'], $setting['case_dealdays']),
		);

		$flag = C::t("#wq_reward#wq_reward_cash_logs")->insert($data, true);

		if($flag) {
			send_message_admin(sprintf($Plang['65df919b98322ad3'], $_G['username']));
			$updatedata = array('wq_reward_userinfo', $data['money'], $data['money'], $_G['uid']);
			DB::query("UPDATE %t SET `availablemoney` = `availablemoney` - %f,`frozenmoney` = `frozenmoney` + %f WHERE uid = %d", $updatedata);
			showmessage($Plang['e021bb879c5187b7'], dreferer());
		} else {
			showmessage($Plang['f800f025cb4c1632']);
		}
	} else {
		showmessage($Plang['682c6dfc76291375']);
	}
}

if($_G['mobile']) {
	include_once template('wq_reward:spacecp_reward');
	exit;
}
//From: Dism_taobao-com
?>