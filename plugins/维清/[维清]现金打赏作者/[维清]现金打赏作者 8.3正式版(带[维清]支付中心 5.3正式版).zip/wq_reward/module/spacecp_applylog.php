<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: spacecp_apply.php 2016-4-23 16:48:21Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$detail = $_GET['subac'] == 'detail' ? true : false;
$status = array($Plang['8ba19cd0d1cde186'], $Plang['9d990bf361b31e1f'], $Plang['458eae1cb6579fe2']);

if($detail && $_G['mobile']) {
	$id = intval($_GET['cashid']);
	$data = C::t("#wq_reward#wq_reward_cash_logs")->fetch($id);
	if(!$data || $data['uid'] != $_G['uid']) {
		showmessage($Plang['633f708548c813ad']);
	}
	$date = $data['status'] == 0 ? date("Y-m-d H:i:s", $data['dateline']) : date("Y-m-d H:i:s", $data['cashtime']);
} else {
	$page = max(1, $_GET['page']);
	$perpage = intval($_G['cache']['plugin']['wq_reward']['perpage']);
	if(!$perpage) {
		$perpage = 10;
	}
	$start = ($page - 1 ) * $perpage;
	$mpurl = 'home.php?mod=spacecp&ac=plugin&id=wq_reward:spacecp_reward&subop=applylog';
	$re = C::t("#wq_reward#wq_reward_cash_logs")->fetch_all_by_uid($_G['uid'], $start, $perpage);
	$money = 0;
	$count = 0;
	if($re) {
		$money = C::t("#wq_reward#wq_reward_cash_logs")->count_by_uid($_G['uid'], true);
		$count = C::t("#wq_reward#wq_reward_cash_logs")->count_by_uid($_G['uid']);
		$multi = multi($count, $perpage, $page, $mpurl);
	}
}
if($_G['mobile']) {
	include_once template('wq_reward:spacecp_reward');
	exit;
}
//From: Dism_taobao-com
?>