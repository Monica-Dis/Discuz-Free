<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: reward_pay.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$setting['tourist_is_reward'] && !$_G['uid']) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$browser_can_wechatpay = $setting['browser_is_can_wechatpay'];
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
	$browser_can_wechatpay = 0;
	$wq_in_wechat = true;
}
if(!$setting['open_wxpay'] && !$setting['open_alipay']) {
	showmessage($Plang['least_select_one_paytype']);
}
if($setting['open_wxpay'] && !$wq_in_wechat && !$setting['open_alipay'] && $_G['mobile'] && !$browser_can_wechatpay) {
	showmessage($Plang['to_wechat_pay']);
}

require_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_wxpayapi.php';

$setting['default_num'] = explode('|', str_replace("\n", '|', $setting['default_num']));

$data = get_article_info($_GET['idtype'], $_GET['infoid'], $_GET['pid']);
if($data == -1 || !$data['authorid']) {
	showmessage($Plang['809fcc98c93056b5']);
}

if(!$data) {
	showmessage($Plang['8234ab5ac343329d']);
}
$wq_default_avatar = avatar(0, small, true);
if($data['uid']) {
	$wq_avatarurl = avatar($data['uid'], small, true);
} else {
	$wq_avatarurl = $wq_default_avatar;
}

$subject = $_GET['idtype'] == 'aid' ? $data[0]['title'] : $data['subject'];
if($_G['mobile'] && $wq_in_wechat && $setting['open_wxpay']) {
	if(!$_G['cookie']['openid']) {
		$data['openid'] = wq_pay_getopenid();
		dsetcookie('openid', $data['openid'], 1800);
		dheader("Location:plugin.php?id=wq_reward&mod=pay&infoid=" . $_GET['infoid'] . "&idtype=" . $_GET['idtype'] . "&pid=" . $_GET['pid']);
	} else {
		$data['openid'] = $_G['cookie']['openid'];
		dsetcookie('openid');
	}
}
$money = check_is_reward_look($_GET['idtype'], $data['authorid'], $data['tid'], $_G['uid'], $_GET['pid']);
$str = '';
if($money['sum_m'] > 0) {
	$look_post = $money['money'];
	$str = sprintf($Plang['add_extra_txt'], $money['sum_m'], $money['money']);
} else {
	$look_post = $money['count_m'];
}

if($money) {
	$post_pay_explain = $setting['reward_look_txt'] ? $setting['reward_look_txt'] : $Plang['reward_look_txt'];
	$post_pay_explain = str_replace('{money}', '<b style="color:#369;font-weight:bold">' . $money['count_m'] . $str . '</b>', $post_pay_explain);
}
if($_GET['idtype'] == 'aid') {
	$dreferer = $_G['siteurl'] . 'portal.php?mod=view&aid=' . $_GET['infoid'] . '&pid=' . $_GET['pid'];
} elseif($_GET['idtype'] == 'articleid') {
	$dreferer = $_G['siteurl'] . 'plugin.php?id=wq_wechatcollecting&mod=view&articleid=' . $_GET['infoid'];
} else {
	$dreferer = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $_GET['infoid'] . '&pid=' . $_GET['pid'];
}

if(!$setting['reward_sign']) {
	$setting['reward_sign'] = $Plang['6a198dcg20bc6545'];
}
if(!$setting['trade_explain']) {
	$setting['trade_explain'] = $Plang['reward_but_txt'];
}

include_once template('wq_reward:tpl_reward_pay');

?>