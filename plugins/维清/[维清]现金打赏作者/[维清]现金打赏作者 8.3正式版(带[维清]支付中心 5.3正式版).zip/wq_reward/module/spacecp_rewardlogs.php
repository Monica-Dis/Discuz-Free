<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: spacecp_apply.php 2016-4-23 16:48:21Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$detail = $_GET['subac'] == 'detail' ? true : false;
$idtype = array('ftid' => $Plang['8d163a68dea0ccb4'], 'aid' => $Plang['68b75fc9ab21a7ed'], 'gtid' => $Plang['20d01d716f550469'], 'articleid' => $Plang['f3349574d937b408']);
$payType = array('wechat' => $Plang['fd32f2cf594cdeb8'], 'alipay' => $Plang['115c0265d921fc45'], 'tenpay' => $Plang['63fc0fd49ad93253']);
$type = $_GET['suboperation'];
if($detail && $_G['mobile']) {
	$orderid = trim($_GET['orderid']);
	$data = C::t("#wq_reward#wq_reward_record")->fetch_first_by_orderid($orderid);
	if(!$data || ($type == 'out' && $data['fromuid'] != $_G['uid']) || ($type != 'out' && $data['touid'] != $_G['uid'])) {
		showmessage($Plang['633f708548c813ad']);
	}
} else {
	$page = max(1, $_GET['page']);
	$perpage = $setting['perpage'];
	if(!$perpage) {
		$perpage = 10;
	}
	$start = ($page - 1 ) * $perpage;
	$mpurl = 'home.php?mod=spacecp&ac=plugin&id=wq_reward:spacecp_reward';

	$str = $Plang['f7cde6f9f5452f49'];
	$param = '';
	if($type) {
		$str = $Plang['3fa4c976e5319f57'];
		$param = "&suboperation=out";
	}

	$money_list = C::t("#wq_reward#wq_reward_record")->fetch_all_by_fromuid_or_touid($type, $_G['uid'], $start, $perpage);
	$count_num = 0;
	$sum_money = 0;
	if($money_list) {
		$count_num = C::t("#wq_reward#wq_reward_record")->count_num_by_uid($type, true, $_G['uid']);
		$sum_money = C::t("#wq_reward#wq_reward_record")->count_num_by_uid($type, false, $_G['uid']);
		$multi = multi($count_num, $perpage, $page, $mpurl . $param);
	}
}
if($_G['mobile']) {
	include_once template('wq_reward:spacecp_reward');
	exit;
}
//From: Dism_taobao-com
?>