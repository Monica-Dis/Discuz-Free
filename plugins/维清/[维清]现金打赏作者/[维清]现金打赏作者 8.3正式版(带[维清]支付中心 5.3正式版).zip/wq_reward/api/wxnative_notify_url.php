<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wxnative_notify_url.php 2016-5-5 10:55:56Z $
 */
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require '../../../../source/class/class_core.php';

$discuz = C::app();
$discuz->init();
require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/wechat/WxPay.Api.php';
require_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';
loadcache('plugin');
$msg = '';
$notify = WxPayApi::notify('', $msg);
if(!$notify) {
	$return = array(
		'return_code' => 'FAIL',
		'return_msg' => $msg
	);
	WxPayApi::replyNotify(arr2xml($return));
	exit;
}
if($notify['result_code'] == 'SUCCESS') {
	$result = update_reward_order_status($notify['out_trade_no']);
	$return['return_msg'] = $msg;
	if($result && $result == 1) {
		$return['return_code'] = 'SUCCESS';
	} else {
		$return['return_code'] = 'FAIL';
	}
	echo arr2xml($return);
	exit;
}

function arr2xml($data) {
	$xml = "<xml>";
	foreach($data as $key => $val) {
		if(is_numeric($val)) {
			$xml .= "<" . $key . ">" . $val . "</" . $key . ">";
		} else {
			$xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
		}
	}
	$xml .= "</xml>";
	return $xml;
}
//From: Dism_taobao-com
?>