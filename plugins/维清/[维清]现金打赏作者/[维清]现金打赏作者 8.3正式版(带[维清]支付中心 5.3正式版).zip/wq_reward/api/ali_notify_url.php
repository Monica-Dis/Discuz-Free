<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: ali_notify_url.php 2016-5-5 10:55:56Z $
 */
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require '../../../../source/class/class_core.php';

$discuz = C::app();
$discuz->init();

if(!empty($_GET['infotype']) && !empty($_GET['infoid'])) {
	$siteurl = str_replace("source/plugin/wq_reward/", "", $_G['siteurl']);
	if($_GET['infotype'] == "aid") {
		$idtype = "aid";
		$baseurl = "portal.php?mod=view";
	} elseif($_GET['infotype'] == "articleid") {
		$idtype = "articleid";
		$baseurl = "plugin.php?id=wq_wechatcollecting&mod=view";
	} else {
		$idtype = "tid";
		$baseurl = "forum.php?mod=viewthread";
	}
	setcookie("return_ok", "1", time() + 2592000);
	dheader("location:" . $siteurl . $baseurl . '&' . $idtype . '=' . $_GET['infoid']);
}

require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/ali/alipay.config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/ali/alipay_notify.class.php';
require_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';
loadcache('plugin');
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();
if($verify_result) {
	$result = false;
	if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
		$result = update_reward_order_status($_POST['out_trade_no']);
	}
	if($result && $result == 1) {
		echo "success";
	} else {
		echo "fail";
	}
} else {
	echo "fail";
}
//From: Dism_taobao-com
?>