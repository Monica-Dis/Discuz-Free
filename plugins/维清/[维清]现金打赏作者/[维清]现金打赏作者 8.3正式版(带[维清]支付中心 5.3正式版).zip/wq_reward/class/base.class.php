<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2016-4-22 23:36:24Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_reward_base {

	public $lang;
	public $setting;

	function plugin_wq_reward_base() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_reward/config/loadfunc.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';

		$this->lang = wq_loadlang('wq_reward');

		$this->setting = wq_loadsetting('wq_reward');
	}

	function reward_look_html($money) {
		$html = <<<EOF
            <p style="margin-bottom:10px;">
                <input type="text" name="reward_look" value="{$money}" id="reward_look_put" class="px" onblur="money_check(this)" onfocus="clear_set()">{$this->lang['reward_look_input_txt']}&nbsp;&nbsp;
                <span style="color:red;display:none" id="money_error_explain">
                    ({$this->lang['error_txt_0']}{$this->setting['reward_look_money'][0]}{$this->lang['error_txt_1']}{$this->setting['reward_look_money'][1]}{$this->lang['error_txt_number']})
                </span>
            </p>
            <script type='text/javascript'>
                var money_min = {$this->setting['reward_look_money'][0]},money_max = {$this->setting['reward_look_money'][1]};
                    var error_html = document.getElementById("money_error_explain");
                    function money_check(t){
                        if(t.value.length > 0){
                            var money = (Number(t.value));
                            if((!money && isNaN(money)) || money <= 0 || (money && (money < money_min || money > money_max) )){
                                error_html.style.display="inline-block";
                                $("postsubmit").disabled=true;
                            }
                        }
                    };
                    function clear_set(){
                        error_html.style.display="none";
                        $("postsubmit").disabled=false;
                    }
            </script>
EOF;
		return $html;
	}

	function mobile_reward_look_html($money) {
		$html = <<<EOF
            <p class="wq_reward_seepost">
                <input type="text" name="reward_look" id="reward_look_put" class="px" value="{$money}" placeholder="{$this->lang['reward_look_input_txt']}"onblur="money_check(this)" onfocus="clear_set()">
                <span style="color:red;display:none ;padding:0px 0px 6px 10px; background: #fff;" id="money_error_explain">
                    ({$this->lang['error_txt_0']}{$this->setting['reward_look_money'][0]}{$this->lang['error_txt_1']}{$this->setting['reward_look_money'][1]}{$this->lang['error_txt_number']})
                </span>
            </p>
            <style>
                 .wq_reward_seepost{ border-bottom: 1px solid #f0f0f0;}
                 .wq_reward_seepost input{ border:none;line-height: 20px; width: 100% !important; text-indent: 0.7em; height: 40px;-webkit-appearance: initial;}
            </style>
            <script type='text/javascript'>
                var money_min = {$this->setting['reward_look_money'][0]},money_max = {$this->setting['reward_look_money'][1]};
                    var error_html = document.getElementById("money_error_explain");
                    function money_check(t){
                        if(t.value.length > 0){
                            var money = (Number(t.value));
                            if((!money && isNaN(money)) || money <= 0 || (money && (money < money_min || money > money_max) )){
                                error_html.style.display="block";
                                $("#postsubmit").attr('disable',true);
                                $('#postsubmit').removeClass('btn_pn_blue').addClass('btn_pn_grey');
                            }else{
                                if($('#needsubject').val() && $('#needmessage').val()){
                                    $("#postsubmit").attr('disable',false);
                                    $('#postsubmit').removeClass('btn_pn_grey').addClass('btn_pn_blue');
                                }
                            }
                        }
                    };
                    function clear_set(){
                        error_html.style.display="none";
                    }
            </script>
EOF;
		return $html;
	}

	function delete_paylook_bind($params) {
		$tids = $params['param'][0];
		$step = $params['step'];
		if($step == 'delete' && is_array($tids)) {
			foreach($tids as $tid) {
				$data = C::t('#wq_reward#wq_reward_look_tids')->fetch_by_uid_tid_pid(null, $tid);
				if($data && $data['tid'] == $tid) {
					C::t('#wq_reward#wq_reward_look_tids')->delete($data['id']);
				}
			}
		}
	}

}
//From: Dism_taobao-com
?>