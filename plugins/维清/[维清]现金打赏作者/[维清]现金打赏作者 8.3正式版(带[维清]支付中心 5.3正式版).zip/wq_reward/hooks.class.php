<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2016-4-21 01:48:05Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_reward/class/base.class.php';

class plugin_wq_reward extends plugin_wq_reward_base {

	function deletethread($params) {
		$this->delete_paylook_bind($params);
	}

}

class mobileplugin_wq_reward extends plugin_wq_reward_base {

	function deletethread($params) {
		$this->delete_paylook_bind($params);
	}

}

class plugin_wq_reward_forum extends plugin_wq_reward_base {

	function viewthread_postbottom_output() {
		return common_forum_viewthread_postbottom('ftid');
	}

	function post_top() {
		$money = post_edit_check_reward_look();

		if(common_forum_reward_look_rbac_check() && $money) {
			$money = $money === true ? '' : $money;
			return $this->reward_look_html($money);
		}
	}

	function post_wq_reward_message($redata) {
		return common_add_reward_look($redata);
	}

	function viewthread_posttop_output() {
		global $_G;
		common_viewthread_content_replace('ftid', $this->lang);
	}

	function viewthread_fastpost_content() {
		global $_G;
		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->reward_look_html('');
	}

	function post_infloat_top() {
		global $_G;

		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->reward_look_html('');
	}

}

class plugin_wq_reward_portal extends plugin_wq_reward_base {

	function view_article_content() {
		return forum_portal_group('aid', $_GET['aid']);
	}

}

class plugin_wq_reward_group extends plugin_wq_reward_base {

	function viewthread_postbottom_output() {
		return common_forum_viewthread_postbottom('gtid');
	}

	function post_top() {
		$money = post_edit_check_reward_look();
		if(common_group_reward_look_rbac_check() && $money) {
			$money = $money === true ? '' : $money;
			return $this->reward_look_html($money);
		}
	}

	function post_wq_reward_message($redata) {
		return common_add_reward_look($redata);
	}

	function viewthread_posttop_output() {
		common_viewthread_content_replace('gtid', $this->lang);
	}

	function viewthread_fastpost_content() {
		global $_G;
		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->reward_look_html('');
	}

	function post_infloat_top() {
		global $_G;

		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->reward_look_html('');
	}

}

class mobileplugin_wq_reward_forum extends plugin_wq_reward_base {

	function viewthread_postbottom_mobile_output() {
		return common_forum_viewthread_postbottom('ftid');
	}

	function post_bottom_mobile() {
		$money = post_edit_check_reward_look();
		if(common_forum_reward_look_rbac_check() && $money) {
			$money = $money === true ? '' : $money;
			return $this->mobile_reward_look_html($money);
		}
	}

	function post_wq_reward_message($redata) {
		return common_add_reward_look($redata);
	}

	function viewthread_posttop_output() {
		common_viewthread_content_replace('ftid', $this->lang);
	}

	function viewthread_reply_wq_mobile() {
		global $_G;
		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->mobile_reward_look_html('');
	}

	function post_bottom_wq_mobile() {
		global $_G;
		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->mobile_reward_look_html('');
	}

	function viewthread_fastpost_button_mobile() {
		global $_G;
		if(!$_G['uid'] || !common_forum_reward_look_rbac_check()) {
			return '';
		}
		return $this->mobile_reward_look_html('');
	}

}

class mobileplugin_wq_reward_group extends plugin_wq_reward_base {

	function viewthread_postbottom_content_mobile_output() {
		return common_forum_viewthread_postbottom('gtid');
	}

	function post_bottom_mobile() {
		$money = post_edit_check_reward_look();
		if(common_group_reward_look_rbac_check() && $money) {
			$money = $money === true ? '' : $money;
			return $this->mobile_reward_look_html($money);
		}
	}

	function post_wq_reward_message($redata) {
		return common_add_reward_look($redata);
	}

	function viewthread_posttop_output() {
		common_viewthread_content_replace('gtid', $this->lang);
	}

}

class mobileplugin_wq_reward_portal extends plugin_wq_reward_base {

	function view_portalcontent_bottom_output() {

		return forum_portal_group('aid', $_GET['aid']);
	}

}
//From: Dism_taobao-com
?>