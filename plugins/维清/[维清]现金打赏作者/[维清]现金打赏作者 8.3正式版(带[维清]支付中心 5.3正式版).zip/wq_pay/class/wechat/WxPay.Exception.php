<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_wxpayapi.php 2016-4-18 02:14:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class WxPayException extends Exception {

	public function errorMessage() {
		return $this->getMessage();
	}

}
//From: Dism_taobao-com
?>