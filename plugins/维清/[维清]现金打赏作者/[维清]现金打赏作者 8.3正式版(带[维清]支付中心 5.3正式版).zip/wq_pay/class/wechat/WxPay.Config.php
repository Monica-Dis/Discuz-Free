<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_wxpayapi.php 2016-4-18 02:14:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
if(!$_G['cookie']['wq_wxapp_pay']) {
	$wq_wxpay_appid = trim($_G['setting']['wq_wxpay_appid']);
	$wq_wxpay_appsecret = trim($_G['setting']['wq_wxpay_appsecret']);
	$wq_wxpay_mch_id = trim($_G['setting']['wq_wxpay_mch_id']);
	$wq_wxpay_key = trim($_G['setting']['wq_wxpay_key']);
} else {
	if($_GET['pluginname'] == $_G['cookie']['wq_wxapp_pay']) {
		loadcache('plugin');
		$wxapp_paysetting = $_G['cache']['plugin'][$_G['cookie']['wq_wxapp_pay']];
		$wq_wxpay_appid = trim($wxapp_paysetting['appid']);
		$wq_wxpay_appsecret = '';
		$wq_wxpay_mch_id = trim($wxapp_paysetting['wxapp_mchid']);
		$wq_wxpay_key = trim($wxapp_paysetting['wxapp_paykey']);
	} else {
		$wq_wxpay_appid = trim($_G['setting']['wq_wxappspay_appid']);
		$wq_wxpay_appsecret = '';
		$wq_wxpay_mch_id = trim($_G['setting']['wq_wxappspay_mch_id']);
		$wq_wxpay_key = trim($_G['setting']['wq_wxappspay_key']);
	}
}

define('DISCUZ_WXPAY_APPSECRET', $wq_wxpay_appsecret);
define('DISCUZ_WXPAY_APPID', $wq_wxpay_appid);
define('DISCUZ_WXPAY_MCHID', $wq_wxpay_mch_id);
define('DISCUZ_WXPAY_KEY', $wq_wxpay_key);


class WxPayConfig {

	const APPID = DISCUZ_WXPAY_APPID;
	const MCHID = DISCUZ_WXPAY_MCHID;
	const KEY = DISCUZ_WXPAY_KEY;
	const APPSECRET = DISCUZ_WXPAY_APPSECRET;
	const SSLCERT_PATH = DISCUZ_WXPAY_CERT_PATH;
	const SSLKEY_PATH = DISCUZ_WXPAY_KEY_PATH;
	const CURL_PROXY_HOST = "0.0.0.0"; //"10.152.18.220";
	const CURL_PROXY_PORT = 0; //8080;
	const NOTIFY_URL = "";
	const REPORT_LEVENL = 1;

}
//From: Dism_taobao-com
?>