<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_wxappspay.inc.php 2016-3-14 02:52:44Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_pay/config/config.php';

$settings = C::t('common_setting')->fetch_all(array('wq_wxappspay_appid', 'wq_wxappspay_mch_id', 'wq_wxappspay_key'));
$wq_wxappspay_appid = $settings['wq_wxappspay_appid'];
$wq_wxappspay_mch_id = $settings['wq_wxappspay_mch_id'];
$wq_wxappspay_key = $settings['wq_wxappspay_key'] ? $settings['wq_wxappspay_key']{0} . '********' . substr($settings['wq_wxappspay_key'], -4) : ''; //API��Կ

if($_GET['checktype']) {
}

if(!submitcheck('wxpaysubmit')) {
	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_pay&pmod=admincp_wxappspay';
	showformheader($fromurl);
	showtableheader('');
	showtitle($Plang['wq_wxappspay']);
	showsetting($Plang['wq_wxappspay_appid'], 'settingswx[wq_wxappspay_appid]', $wq_wxappspay_appid, 'text', '', 0, $Plang['wq_wxappspay_appid_comment']);
	showsetting($Plang['wq_wxappspay_mch_id'], 'settingswx[wq_wxappspay_mch_id]', $wq_wxappspay_mch_id, 'text', '', 0, $Plang['wq_wxappspay_mch_id_comment']);
	showsetting($Plang['wq_wxappspay_key'], 'settingswx[wq_wxappspay_key]', $wq_wxappspay_key, 'text', '', 0, $Plang['wq_wxappspay_key_comment']);
	showsubmit('wxpaysubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$settingswx = $_GET['settingswx'];
	C::t('common_setting')->update('wq_wxappspay_appid', $settingswx['wq_wxappspay_appid']);
	C::t('common_setting')->update('wq_wxappspay_mch_id', $settingswx['wq_wxappspay_mch_id']);

	if($wq_wxappspay_key != $settingswx['wq_wxappspay_key']) {
		C::t('common_setting')->update('wq_wxappspay_key', $settingswx['wq_wxappspay_key']);
	}
	$msg = $Plang['wq_wxpay_succeed'];
	updatecache('setting');
	cpmsg($msg, 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_pay&pmod=admincp_wxappspay', 'succeed');
}
//From: Dism_taobao-com
?>