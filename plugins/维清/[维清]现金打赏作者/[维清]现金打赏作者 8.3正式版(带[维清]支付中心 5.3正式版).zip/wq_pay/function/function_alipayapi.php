<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_moblie_alipay($_arg_0)
{
	global $alipay_config;
	if ($_arg_0["flag"]) {
		$alipay_config["input_charset"] = strtolower(CHARSET);
		$alipay_config["service"] = "create_direct_pay_by_user";
		$_arg_0["body"] = diconv($_arg_0["body"], "utf-8", CHARSET);
	}
	$_var_2 = array("service" => $alipay_config["service"], "partner" => $alipay_config["partner"], "seller_id" => $alipay_config["seller_id"], "payment_type" => $alipay_config["payment_type"], "notify_url" => $_arg_0["notify_url"], "return_url" => $_arg_0["return_url"], "_input_charset" => trim(strtolower($alipay_config["input_charset"])), "out_trade_no" => $_arg_0["orderid"], "subject" => $_arg_0["body"], "total_fee" => $_arg_0["money"], "show_url" => $_arg_0["show_url"], "body" => $_arg_0["body"], "app_pay" => "Y");
	$_var_3 = new AlipaySubmit($alipay_config);
	$_var_4 = $_var_3->buildRequestForm($_var_2, "post", "&#x786E;&#x8BA4;");
	if ($_arg_0["flag"]) {
		$_var_4["body"] = diconv($_arg_0["body"], CHARSET, "utf-8");
		$_var_4["subject"] = diconv($_arg_0["body"], CHARSET, "utf-8");
	}
	return json_encode($_var_4);
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}
	require_once DISCUZ_ROOT . "./source/plugin/wq_pay/class/ali/alipay.config.php";
	require_once DISCUZ_ROOT . "./source/plugin/wq_pay/class/ali/alipay_submit.class.php";