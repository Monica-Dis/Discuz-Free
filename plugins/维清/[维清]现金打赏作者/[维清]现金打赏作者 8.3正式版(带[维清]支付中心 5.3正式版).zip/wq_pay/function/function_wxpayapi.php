<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_wxpayapi.php 2016-4-18 02:14:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/wechat/WxPay.Api.php';
require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/wechat/WxPay.JsApiPay.php';
require_once DISCUZ_ROOT . './source/plugin/wq_pay/class/wechat/WxPay.NativePay.php';
require_once DISCUZ_ROOT . './source/plugin/wq_pay/config/setting.php';

function wq_pay_getopenid() {
	global $pay_setting;
	$tools = new JsApiPay();
	return $tools->GetOpenid($pay_setting['wx_domain']);
}

function jsapi_wxpay($param) {
	global $_G;
	date_default_timezone_set('Asia/Shanghai');
	if(!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
		ob_start();
	}
	try {
		if(!$param['body'] || !$param['orderid'] || !$param['money'] || !is_numeric($param['money']) || $param['money'] < 1 || !$param['notify_url'] || (!$param['openid'] && $_G['cookie']['wq_wxapp_pay'])) {
			throw new WxPayException('4000');
		}
		if(!$param['isbrowser']) {
			if($param['openid']) {
				$openid = $param['openid'];
			} else {
				$openid = wq_pay_getopenid();
			}
		}

		$tools = new JsApiPay();
		$input = new WxPayUnifiedOrder();
		$input->SetBody($param['body']);
		$input->SetOut_trade_no($param['orderid']);
		$input->SetTotal_fee(intval($param['money']));
		$input->SetTime_start(date("YmdHis"));
		$input->SetTime_expire(date("YmdHis", time() + 600));
		$input->SetNotify_url($param['notify_url']);
		if($param['isbrowser'] == 1) {
			$input->SetTrade_type("MWEB");
		} else {
			$input->SetTrade_type("JSAPI");
			$input->SetOpenid($openid);
		}
		$order = WxPayApi::unifiedOrder($input);
		$jsApiParameters = $tools->GetJsApiParameters($order);
		return return_data_join('0', $jsApiParameters);
	} catch(Exception $e) {
		return return_data_join($e->errorMessage(), '');
	}
}

function native_wxpay($param) {
	date_default_timezone_set('Asia/Shanghai');
	if(!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
		ob_start();
	}

	try {
		if(!$param['body'] || !$param['money'] || !is_numeric(intval($param['money'])) || $param['money'] < 1 || !$param['notify_url'] || !$param['orderid']) {
			throw new WxPayException('4000');
		}
		$input = new WxPayUnifiedOrder();
		$input->SetBody($param['body']);
		$input->SetOut_trade_no($param['orderid']);
		$input->SetTotal_fee(intval($param['money']));
		$input->SetTime_start(date("YmdHis"));
		$input->SetTime_expire(date("YmdHis", time() + 600));
		$input->SetGoods_tag($param['body']);
		$input->SetNotify_url($param['notify_url']);
		$input->SetTrade_type("NATIVE");
		$input->SetProduct_id($param['orderid']);

		$native = new NativePay();
		$result = $native->GetPayUrl($input);
		if($result['return_code'] == 'SUCCESS' && $result['code_url']) {
			return return_data_join('0', urlencode($result["code_url"]), $param['orderid']);
		} else {

			$return_msg = diconv($result['return_msg'], "utf-8", CHARSET);
			if($result['return_code'] == 'SUCCESS' && $result['return_msg'] == 'OK') {
				$return_msg = diconv($result['err_code_des'], "utf-8", CHARSET);
			}

			throw new WxPayException($return_msg);
		}
	} catch(WxPayException $e) {
		return return_data_join($e->errorMessage(), '');
	}
}

function mch_pay($param) {
	try {
		if(!$param['name'] || !$param['money'] || !is_numeric($param['money']) || $param['money'] < 1 || !$param['desc']) {
			throw new WxPayException('4008');
		}
		$input = new WxQyPay();
		$input->SetMchOrder(WxPayConfig::MCHID . date("YmdHis"));
		$input->SetOpenid(wq_pay_getopenid());
		$input->SetCheckName('NO_CHECK');
		$input->SetName($param['name']);
		$input->SetAmount(intval($param['money']));
		$input->SetDesc($param['desc']);
		$result = WxPayApi::mchPay($input);
		if($result['result_code'] != 'SUCCESS') {
			throw new WxPayException('4016');
		}
	} catch(WxPayException $e) {
		return return_data_join($e->errorMessage(), '');
	}
}

function mch_redbag($param) {
	try {
		if(!$param['name'] || !$param['wishing'] || !$param['actname'] || !$param['remark'] || !$param['money'] || !is_numeric($param['money']) || $param['money'] < 1) {
			throw new WxPayException('4008');
		}
		$input = new WxQyPay();
		$input->SetMchOrder(WxPayConfig::MCHID . date("YmdHis"), false);
		$input->SetSendName($param['name']);
		$input->SetWishing($param['wishing']);
		$input->SetActName($param['actname']);
		$input->SetRemark($param['remark']);
		$input->SetOpenid(wq_pay_getopenid(), false);
		$input->SetAmount(intval($param['money'], false));
		$input->SetTotalNum(1);
		$result = WxPayApi::mchPay($input, 6, false);
		if($result['result_code'] != 'SUCCESS') {
			throw new WxPayException('4016');
		}
	} catch(WxPayException $e) {
		return return_data_join($e->errorMessage(), '');
	}
}

function return_data_join($code, $msg, $orderid = '') {
	include DISCUZ_ROOT . './source/plugin/wq_pay/config/loadfunc.php';
	$langfile = DISCUZ_ROOT . './source/plugin/wq_pay/language/language.' . currentlang() . '.php';
	if(is_file($langfile)) {
		$includefile = $langfile;
	} else {
		$includefile = libfile('language', 'plugin/wq_pay/language');
	}
	include $includefile;
	$array = array(
		'code' => $code,
		'msg' => $msg,
		'orderid' => $orderid
	);
	$str = diconv($Plang[4041], CHARSET, "utf-8");
	if(strlen($code) == 4 && intval($code) != 0) {
		$array['msg'] = $str .= diconv($Plang[$code], CHARSET, "utf-8");
	} elseif($code !== '0') {
		$array['code'] = '-1';
		$array['msg'] = $str .= diconv($code, CHARSET, "utf-8");
	}
	return json_encode($array);
}
//From: Dism_taobao-com
?>