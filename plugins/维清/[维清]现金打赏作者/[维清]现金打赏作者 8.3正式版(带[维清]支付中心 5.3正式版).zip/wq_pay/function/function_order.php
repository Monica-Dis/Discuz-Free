<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_usergroup.php 2016-7-4 19:14:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!function_exists('wq_found_orderid')) {

	function wq_found_orderid($table, $field = 'orderno', $end_length = 6, $number = 10) {
		date_default_timezone_set('Asia/Shanghai');

		if(!$table || !$field) {
			return '';
		}
		$j = 0;
		$order = '';
		do {
			$order = date('YmdHis');
			$rand = mt_rand(100, 999);
			$con = strtoupper(md5(uniqid($rand)));
			for($i = 0; $i < intval($end_length); $i ++) {
				$key = mt_rand(0, 31);
				$order .= $con[$key];
			}
			$flag = DB::fetch_first("select * from %t WHERE %s=%s", array($table, $field, $order));
			if(!$flag) {
				break;
			}
			$j ++;
		} while($j < intval($number));
		return $order;
	}

}
//From: Dism_taobao-com
?>