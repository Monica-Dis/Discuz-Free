<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_wxpay.inc.php 2016-3-14 02:52:44Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_pay/config/config.php';
$settings = C::t('common_setting')->fetch_all(array('wq_wxpay_appid', 'wq_wxpay_appsecret', 'wq_wxpay_mch_id', 'wq_wxpay_key'));
$wq_wxpay_appid = $settings['wq_wxpay_appid'];
$wq_wxpay_appsecret = $settings['wq_wxpay_appsecret'] ? $settings['wq_wxpay_appsecret']{0} . '********' . substr($settings['wq_wxpay_appsecret'], -4) : '';
$wq_wxpay_mch_id = $settings['wq_wxpay_mch_id'];
$wq_wxpay_key = $settings['wq_wxpay_key'] ? $settings['wq_wxpay_key']{0} . '********' . substr($settings['wq_wxpay_key'], -4) : ''; //API��Կ

if($_GET['checktype']) {
	if($_GET['checktype'] == 'credit') {
		$param = array(
			'body' => 'test',
			'money' => 1,
			'tag' => 'pay_test',
			'notify_url' => $_G['siteurl'],
			'orderid' => time() . mt_rand(99, 9999)
		);
		$result = json_decode(native_wxpay($param), true);
		if($result['code'] == '0') {
			$url = $result['msg'];
			$img_url = $_G['siteurl'] . 'source/plugin/wq_pay/api/qrcode/png.php?url=' . $url;
			echo "<img src='" . $img_url . "' style='width:150px;height:160px;'>";
		} else {
			echo diconv($result['msg'], "utf-8", CHARSET);
		}
	}
	exit;
}

if(!submitcheck('wxpaysubmit')) {
	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_pay&pmod=admincp_wxpay';
	showformheader($fromurl);
	showtableheader('');
	showtitle($Plang['wq_wxpay']);
	showsetting($Plang['wq_wxpay_appid'], 'settingswx[wq_wxpay_appid]', $wq_wxpay_appid, 'text', '', 0, $Plang['wq_wxpay_appid_comment']);
	showsetting($Plang['wq_wxpay_appsecret'], 'settingswx[wq_wxpay_appsecret]', $wq_wxpay_appsecret, 'text', '', 0, $Plang['wq_wxpay_appsecret_comment']);
	showsetting($Plang['wq_wxpay_mch_id'], 'settingswx[wq_wxpay_mch_id]', $wq_wxpay_mch_id, 'text', '', 0, $Plang['wq_wxpay_mch_id_comment']);
	showsetting($Plang['wq_wxpay_key'], 'settingswx[wq_wxpay_key]', $wq_wxpay_key, 'text', '', 0, $Plang['wq_wxpay_key_comment']);
	showsetting($Plang['wq_wxpay_check'], '', '', '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_pay&pmod=admincp_wxpay&checktype=credit">' . $Plang['wq_wxpay_checklink_credit'] . '</a><br />', '', 0, $Plang['wq_wxpay_check_comment']);
	showsubmit('wxpaysubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$settingswx = $_GET['settingswx'];
	C::t('common_setting')->update('wq_wxpay_appid', $settingswx['wq_wxpay_appid']);
	if($wq_wxpay_appsecret != $settingswx['wq_wxpay_appsecret']) {
		C::t('common_setting')->update('wq_wxpay_appsecret', $settingswx['wq_wxpay_appsecret']);
	}
	C::t('common_setting')->update('wq_wxpay_mch_id', $settingswx['wq_wxpay_mch_id']);
	if($wq_wxpay_key != $settingswx['wq_wxpay_key']) {
		C::t('common_setting')->update('wq_wxpay_key', $settingswx['wq_wxpay_key']);
	}
	$msg = $Plang['wq_wxpay_succeed'];
	updatecache('setting');
	cpmsg($msg, 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_pay&pmod=admincp_wxpay', 'succeed');
}
//From: Dism_taobao-com
?>