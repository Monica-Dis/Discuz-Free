<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-4-18 02:14:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_pay/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_pay.php';
include_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_wxpayapi.php';
include_once DISCUZ_ROOT . './source/plugin/wq_pay/function/function_alipayapi.php';
$Plang = wq_loadlang('wq_pay');

$pay_setting = wq_loadsetting('wq_pay');

?>