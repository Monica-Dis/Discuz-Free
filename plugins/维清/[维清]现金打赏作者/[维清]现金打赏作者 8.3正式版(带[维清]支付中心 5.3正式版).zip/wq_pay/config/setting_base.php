<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2018-3-30 18:16:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pay_setting = $_G['cache']['plugin']['wq_pay'];
$pay_setting['wx_domain'] = trim($pay_setting['wx_domain']);
$pay_setting['domain_http'] = trim($pay_setting['domain_http']);

?>