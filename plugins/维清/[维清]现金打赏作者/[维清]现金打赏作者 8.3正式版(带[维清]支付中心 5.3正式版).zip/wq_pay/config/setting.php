<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_pay/config/setting_base.php';

$http = $pay_setting['domain_http'] && in_array($pay_setting['domain_http'], array('http://', 'https://')) ? $pay_setting['domain_http'] : (strrpos($_G['siteurl'], 'https://') === FALSE ? 'http://' : 'https://');
$pay_setting['wx_domain'] = rtrim($pay_setting['wx_domain'], "/");
$pay_setting['wx_domain'] = $http . str_replace(array('http://', 'https://'), "", $pay_setting['wx_domain']);

?>