<?php

/**
 * 維清 [ Discuz!應用專家，深圳市維清互聯科技有限公司旗下Discuz!開發團隊 ]
 *
 * 应用更新支持：https://dism.taobao.com
 *
 * 最新插件：http://t.cn/Aiux1Jx1
 *
 * $Id: language.php 2016-4-18 02:14:12Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$Plang = array(
    'wq_wxpay' => '微信支付設置',
    'wq_wxpay_appid' => '公衆號AppID(應用ID)',
    'wq_wxpay_appid_comment' => '微信分配的公衆號應用ID（企業號corpid即爲此appId）,請登錄<a href="https://mp.weixin.qq.com" target="_blank">微信公衆平台</a>然後<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxpay_appsecret' => '公衆號AppSecret(應用密鈅)',
    'wq_wxpay_appsecret_comment' => '微信分配的公衆號應用密鈅,請登錄<a href="https://mp.weixin.qq.com" target="_blank">微信公衆平台</a>然後<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxpay_mch_id' => '微信支付商戶號',
    'wq_wxpay_mch_id_comment' => '微信支付分配的商戶號,請登錄<a href="https://pay.weixin.qq.com" target="_blank">微信支付商戶平台</a>然後<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=135#pid135" target="_blank">按此教程查看</a>',
    'wq_wxpay_key' => '微信支付API密鈅',
    'wq_wxpay_key_comment' => 'API密鈅屬於敏感信息，請妥善保琯不要泄露，如果懷疑信息泄露，請重設密鈅。請登錄<a href="https://pay.weixin.qq.com" target="_blank">微信支付商戶平台</a>然後<a href="http://wiki.wikin.cn/?plugin.php?id=wq_help&cid=34&pid=147#pid147" target="_blank">按此教程查看</a>',
    'wq_wxpay_check' => '支付測試',
    'wq_wxpay_check_comment' => '本測試將模擬提交 0.01 元人民幣的訂單進行測試，如果提交後成功出現二維碼，說明您站點的微信支付功能可以正常使用',
    'wq_wxpay_checklink_credit' => '積分充值訂單測試',
    'wq_wxappspay' => '微信小程序支付設置',
    'wq_wxappspay_appid' => '小程序AppID(小程序ID)',
    'wq_wxappspay_appid_comment' => '微信分配的小程序ID,請登錄<a href="https://mp.weixin.qq.com" target="_blank">微信公衆平台</a>然後<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxappspay_mch_id' => '微信支付分配的商戶號（指小程序）',
    'wq_wxappspay_mch_id_comment' => '微信支付分配的商戶號,請登錄<a href="https://pay.weixin.qq.com" target="_blank">微信支付商戶平台</a>然後<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=135#pid135" target="_blank">按此教程查看</a>',
    'wq_wxappspay_key' => '微信支付API密鈅（指小程序）',
    'wq_wxappspay_key_comment' => 'API密鈅屬於敏感信息，請妥善保琯不要泄露，如果懷疑信息泄露，請重設密鈅。請登錄<a href="https://pay.weixin.qq.com" target="_blank">微信支付商戶平台</a>然後<a href="http://wiki.wikin.cn/?plugin.php?id=wq_help&cid=34&pid=147#pid147" target="_blank">按此教程查看</a>',
    'wq_wxappspay_check_comment' => '本測試將模擬提交 0.01 元人民幣的訂單進行測試，如果提交後成功出現二維碼，說明您的微信小程序支付功能可以正常使用',
    '4000' => '蓡數信息不完善',
    '4001' => '缺少統一支付接口必填蓡數out_trade_no！',
    '4002' => '缺少統一支付接口必填蓡數body！',
    '4003' => '缺少統一支付接口必填蓡數total_fee！',
    '4004' => '缺少統一支付接口必填蓡數trade_type！',
    '4005' => 'trade_type爲JSAPI時，openid爲必填蓡數！',
    '4006' => 'trade_type爲NATIVE時，product_id爲必填蓡數！',
    '4007' => 'curl出錯',
    '4008' => '蓡數錯誤',
    '4009' => '缺少統一轉賬接口必填蓡數項check_name！',
    '4010' => '缺少統一轉賬接口必填蓡數desc！',
    '4011' => '缺少統一轉賬接口必填蓡數re_user_name！',
    '4012' => '缺少統一紅包接口必填蓡數項send_name！',
    '4013' => '缺少統一紅包接口必填蓡數wishing！',
    '4014' => '缺少統一紅包接口必填蓡數act_name！',
    '4015' => '缺少統一紅包接口必填蓡數remark！',
    '4016' => '請求失敗',
    '4017' => '數組數據異常！',
    '4018' => 'xml數據異常！',
    '4019' => '簽名錯誤！',
    '4020' => '訂單查詢接口中，out_trade_no、transaction_id至少填一個！',
    '4021' => '訂單查詢接口中，out_trade_no必填！',
    '4022' => '退款申請接口中，out_trade_no、transaction_id至少填一個！',
    '4023' => '退款申請接口中，缺少必填蓡數out_refund_no！',
    '4024' => '退款申請接口中，缺少必填蓡數total_fee！',
    '4025' => '退款申請接口中，缺少必填蓡數refund_fee！',
    '4026' => '退款申請接口中，缺少必填蓡數op_user_id！',
    '4027' => '退款查詢接口中，out_refund_no、out_trade_no、transaction_id、refund_id四個蓡數必填一個！',
    '4028' => '對賬單接口中，缺少必填蓡數bill_date！',
    '4029' => '提交被掃支付API接口中，缺少必填蓡數body！',
    '4030' => '提交被掃支付API接口中，缺少必填蓡數out_trade_no！',
    '4031' => '提交被掃支付API接口中，缺少必填蓡數total_fee！',
    '4032' => '提交被掃支付API接口中，缺少必填蓡數auth_code！',
    '4033' => '撤銷訂單API接口中，蓡數out_trade_no和transaction_id必須填寫一個！',
    '4034' => '接口URL，缺少必填蓡數interface_url！',
    '4035' => '返廻狀態碼，缺少必填蓡數return_code！',
    '4036' => '業務結果，缺少必填蓡數result_code！',
    '4037' => '訪問接口IP，缺少必填蓡數user_ip！',
    '4038' => '接口耗時，缺少必填蓡數execute_time_！',
    '4039' => '生成二維碼，缺少必填蓡數product_id！',
    '4040' => '需要轉換的URL，簽名用原串，傳輸需URL encode！',
    '4041' => '請求錯誤：',
    'wq_wxpay_succeed' => '設置成功',
);
?>