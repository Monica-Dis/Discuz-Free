<?php

/**
 * DisM!应用中心：dism.taobao.com
 *
 * 应用更新支持：https://dism.taobao.com
 *
 * 最新插件：http://t.cn/Aiux1Jx1
 *
 * $Id: language.php 2016-4-18 02:14:12Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$Plang = array(
    'wq_wxpay' => '微信支付设置',
    'wq_wxpay_appid' => '公众号AppID(应用ID)',
    'wq_wxpay_appid_comment' => '微信分配的公众号应用ID（企业号corpid即为此appId）,请登录<a href="https://mp.weixin.qq.com" target="_blank">微信公众平台</a>然后<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxpay_appsecret' => '公众号AppSecret(应用密钥)',
    'wq_wxpay_appsecret_comment' => '微信分配的公众号应用密钥,请登录<a href="https://mp.weixin.qq.com" target="_blank">微信公众平台</a>然后<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxpay_mch_id' => '微信支付商户号',
    'wq_wxpay_mch_id_comment' => '微信支付分配的商户号,请登录<a href="https://pay.weixin.qq.com" target="_blank">微信支付商户平台</a>然后<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=135#pid135" target="_blank">按此教程查看</a>',
    'wq_wxpay_key' => '微信支付API密钥',
    'wq_wxpay_key_comment' => 'API密钥属于敏感信息，请妥善保管不要泄露，如果怀疑信息泄露，请重设密钥。请登录<a href="https://pay.weixin.qq.com" target="_blank">微信支付商户平台</a>然后<a href="http://wiki.wikin.cn/?plugin.php?id=wq_help&cid=34&pid=147#pid147" target="_blank">按此教程查看</a>',
    'wq_wxpay_check' => '支付测试',
    'wq_wxpay_check_comment' => '本测试将模拟提交 0.01 元人民币的订单进行测试，如果提交后成功出现二维码，说明您站点的微信支付功能可以正常使用',
    'wq_wxpay_checklink_credit' => '积分充值订单测试',
    'wq_wxappspay' => '微信小程序支付设置',
    'wq_wxappspay_appid' => '小程序AppID(小程序ID)',
    'wq_wxappspay_appid_comment' => '微信分配的小程序ID,请登录<a href="https://mp.weixin.qq.com" target="_blank">微信公众平台</a>然后<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=134#pid134" target="_blank">按此教程查看</a>',
    'wq_wxappspay_mch_id' => '微信支付分配的商户号（指小程序）',
    'wq_wxappspay_mch_id_comment' => '微信支付分配的商户号,请登录<a href="https://pay.weixin.qq.com" target="_blank">微信支付商户平台</a>然后<a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=34&pid=135#pid135" target="_blank">按此教程查看</a>',
    'wq_wxappspay_key' => '微信支付API密钥（指小程序）',
    'wq_wxappspay_key_comment' => 'API密钥属于敏感信息，请妥善保管不要泄露，如果怀疑信息泄露，请重设密钥。请登录<a href="https://pay.weixin.qq.com" target="_blank">微信支付商户平台</a>然后<a href="http://wiki.wikin.cn/?plugin.php?id=wq_help&cid=34&pid=147#pid147" target="_blank">按此教程查看</a>',
    'wq_wxappspay_check_comment' => '本测试将模拟提交 0.01 元人民币的订单进行测试，如果提交后成功出现二维码，说明您的微信小程序支付功能可以正常使用',
    '4000' => '参数信息不完善',
    '4001' => '缺少统一支付接口必填参数out_trade_no！',
    '4002' => '缺少统一支付接口必填参数body！',
    '4003' => '缺少统一支付接口必填参数total_fee！',
    '4004' => '缺少统一支付接口必填参数trade_type！',
    '4005' => 'trade_type为JSAPI时，openid为必填参数！',
    '4006' => 'trade_type为NATIVE时，product_id为必填参数！',
    '4007' => 'curl出错',
    '4008' => '参数错误',
    '4009' => '缺少统一转账接口必填参数项check_name！',
    '4010' => '缺少统一转账接口必填参数desc！',
    '4011' => '缺少统一转账接口必填参数re_user_name！',
    '4012' => '缺少统一红包接口必填参数项send_name！',
    '4013' => '缺少统一红包接口必填参数wishing！',
    '4014' => '缺少统一红包接口必填参数act_name！',
    '4015' => '缺少统一红包接口必填参数remark！',
    '4016' => '请求失败',
    '4017' => '数组数据异常！',
    '4018' => 'xml数据异常！',
    '4019' => '签名错误！',
    '4020' => '订单查询接口中，out_trade_no、transaction_id至少填一个！',
    '4021' => '订单查询接口中，out_trade_no必填！',
    '4022' => '退款申请接口中，out_trade_no、transaction_id至少填一个！',
    '4023' => '退款申请接口中，缺少必填参数out_refund_no！',
    '4024' => '退款申请接口中，缺少必填参数total_fee！',
    '4025' => '退款申请接口中，缺少必填参数refund_fee！',
    '4026' => '退款申请接口中，缺少必填参数op_user_id！',
    '4027' => '退款查询接口中，out_refund_no、out_trade_no、transaction_id、refund_id四个参数必填一个！',
    '4028' => '对账单接口中，缺少必填参数bill_date！',
    '4029' => '提交被扫支付API接口中，缺少必填参数body！',
    '4030' => '提交被扫支付API接口中，缺少必填参数out_trade_no！',
    '4031' => '提交被扫支付API接口中，缺少必填参数total_fee！',
    '4032' => '提交被扫支付API接口中，缺少必填参数auth_code！',
    '4033' => '撤销订单API接口中，参数out_trade_no和transaction_id必须填写一个！',
    '4034' => '接口URL，缺少必填参数interface_url！',
    '4035' => '返回状态码，缺少必填参数return_code！',
    '4036' => '业务结果，缺少必填参数result_code！',
    '4037' => '访问接口IP，缺少必填参数user_ip！',
    '4038' => '接口耗时，缺少必填参数execute_time_！',
    '4039' => '生成二维码，缺少必填参数product_id！',
    '4040' => '需要转换的URL，签名用原串，传输需URL encode！',
    '4041' => '请求错误：',
    'wq_wxpay_succeed' => '设置成功',
);
?>