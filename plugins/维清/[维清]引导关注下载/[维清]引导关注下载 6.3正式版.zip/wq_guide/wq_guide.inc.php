<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_qqlogin.inc.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_guide/config/config.php';
$dreferer = dreferer();

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "";

$allowmod = array('push', 'qrcode');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

if(empty($mod)) {
	showmessage($Plang['4a1d4a83f72d94f5'], $dreferer);
}
foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_guide/' . $dirlist[$mod] . '/guide_' . $mod . '.php';

?>