<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_guide_base {

	public $lang;
	public $setting;

	function plugin_wq_guide_base() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_guide/config/loadfunc.php';

		$this->lang = wq_loadlang('wq_guide');

		$this->setting = wq_loadsetting('wq_guide');
		$this->setting['tid_recommended'] = array_filter(explode(",", str_replace($this->lang['2f0278d0292cdf93'], ',', $this->setting['tid_recommended'])));
		$this->setting['tid_recommended'] = array_slice($this->setting['tid_recommended'], 0, $this->setting['recommended_num']);
	}

}
//From: Dism_taobao-com
?>