<?php

/**
 * DisM!应用中心：dism.taobao.com
 *
 * 应用更新支持：https://dism.taobao.com
 *
 * 最新插件：http://t.cn/Aiux1Jx1
 *
 * $Id: language.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $wq_guide_plang;
$wq_guide_plang = array(
	'07ba182b4d462337' => '推送到引导关注',
	'b355f5ee59ee2727' => '确定推送此篇文章到引导关注吗？',
	'387e9a577ee04ca3' => '确定',
	'6758dd16bcc0c9bf' => '长按上图选择识别图中二维码',
	'2c8a07313e7706bc' => '关注',
	'2f0278d0292cdf93' => '，',
);

$Plang = array(
	'07ba182b4d462337' => '推送到引导关注',
	'b355f5ee59ee2727' => '确定推送此篇文章到引导关注吗？',
	'387e9a577ee04ca3' => '确定',
	'6758dd16bcc0c9bf' => '长按上图选择识别图中二维码',
	'2c8a07313e7706bc' => '关注',
	'2f0278d0292cdf93' => '，',
	'4a1d4a83f72d94f5' => '抱歉，请求来路不正确',
	'0b03faa51ff27ba8' => '抱歉，你没有权限推荐到引导关注',
	'0c7756cd18154355' => '抱歉，请选择你要推送到引导关注的帖子',
	'398f20c553ba7c49' => '抱歉当前帖子已存在推荐帖子里',
	'1d982cfcf8428856' => '推送成功',
	'pluginname' => '插件名称',
	'25c9ae07091f3c73' => '推送到引导关注',
);

?>