var guidepop = new Object;
var guidetoast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>'
var guidePopup = {
    init: function () {
        var $this = this;
        $('.wqpopup').each(function (index, obj) {
            obj = $(obj);
            var pop = $(obj.attr('href'));
            if (pop && pop.attr('wqpopup')) {
                pop.css({'display': 'none'});
                obj.on('click', function (e) {
                    $this.open(pop);
                });
            }
        });
        this.maskinit();
    },
    maskinit: function () {
        var $this = this;
        $('.guidemask').off().on('click', function () {
            $this.close();
        });
    },
    open: function (pop) {
        this.close();
        this.maskinit();
        if (typeof pop == 'string') {
            $('#ntcmsg').remove();
            $('body').append('<div id="ntcmsg" style="display:none;">' + pop + '</div>');
            pop = $('#ntcmsg');

        }
        if (guidepop[pop.attr('id')]) {
            $('.new_dialogbox2').html(pop.html()).css({'height': pop.height() + 'px', 'width': pop.width() + 'px'});
        } else {
            pop.parent().append('<div class="dialogbox new_dialogbox2" id="' + pop.attr('id') + '_popmenu" style="height:' + pop.height() + 'px;width:' + pop.width() + 'px;">' + pop.html() + '</div>');
        }
        var popupobj = $('.new_dialogbox2');
        var left = (window.innerWidth - popupobj.width()) / 2;
        var top = (document.documentElement.clientHeight - popupobj.height()) / 2;

        popupobj.css({'display': 'block', 'position': 'fixed', 'left': left, 'top': top, 'z-index': 120, 'opacity': 1});

        $('.guidemask').css({'display': 'block', 'width': '100%', 'height': '100%', 'position': 'fixed', 'top': '0', 'left': '0', 'background': 'black', 'opacity': '0.2', 'z-index': '100'});
        $('#ntcmsg').remove();
        guidepop[pop.attr('id')] = pop;
    },
    close: function () {
        $('body').css('max-height', null);
        $('.guidemask').css('display', 'none');
        $.each(guidepop, function (index, obj) {
            $('.new_dialogbox2').css('display', 'none');
        });
    }
};

var guideDialog = {
    init: function () {
        $(document).on('click', '.wq_qrShow', function () {
            var obj = $(this);
            guidePopup.open(guidetoast)
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                dataType: 'html'
            }).success(function (s) {
                var wq = wqXml(s);
                guidePopup.open(wq);
            }).error(function () {
                guidePopup.close();
            });
            return false;
        });
    }
};
$(function () {
    guideDialog.init();
    guidePopup.init();
});


function wqXml(str) {
    var start = str.indexOf('CDATA') + 6, end = str.indexOf(']]></root>');
    var wq = str.substring(start, end);
    return wq
}