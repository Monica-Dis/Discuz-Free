<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_guide_get_plang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_guide/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_guide/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_guide/language");
	}
	include $_var_1;
	global $wq_guide_plang;
	return $wq_guide_plang;
}
function wq_gudie_get_setting()
{
	global $_G;
	$_var_1 = wq_guide_get_plang();
	$_var_2 = $_G["cache"]["plugin"]["wq_guide"];
	$_var_2["app_switch"] = intval($_var_2["app_switch"]);
	$_var_2["app_logo"] = trim($_var_2["app_logo"]);
	$_var_2["app_tilte"] = trim($_var_2["app_tilte"]);
	$_var_2["app_intro"] = trim($_var_2["app_intro"]);
	$_var_2["app_link"] = trim($_var_2["app_link"]);
	$_var_2["wechat_switch"] = intval($_var_2["wechat_switch"]);
	$_var_2["wechat_logo"] = trim($_var_2["wechat_logo"]);
	$_var_2["wechat_tilte"] = trim($_var_2["wechat_tilte"]);
	$_var_2["wechat_intro"] = trim($_var_2["wechat_intro"]);
	$_var_2["wechat_link"] = trim($_var_2["wechat_link"]);
	$_var_2["thread_switch"] = intval($_var_2["thread_switch"]);
	$_var_2["tid_recommended"] = trim($_var_2["tid_recommended"]);
	$_var_2["recommended_num"] = intval($_var_2["recommended_num"]);
	$_var_2["is_app_link"] = intval($_var_2["is_app_link"]);
	$_var_2["fixed"] = intval($_var_2["fixed"]);
	$_var_2["style_select"] = intval($_var_2["style_select"]);
	$_var_2["is_open_button"] = intval($_var_2["is_open_button"]);
	$_var_2["advertisement_time"] = intval($_var_2["advertisement_time"]);
	$_var_2["guide_z_index"] = intval($_var_2["guide_z_index"]);
	$_var_2["recommended_num"] = $_var_2["recommended_num"] <= 0 || $_var_2["recommended_num"] > 5 ? 5 : $_var_2["recommended_num"];
	$_var_2["tid_recommended"] = array_filter(explode(",", str_replace($_var_1["2f0278d0292cdf93"], ",", $_var_2["tid_recommended"])));
	$_var_2["tid_recommended"] = array_slice($_var_2["tid_recommended"], 0, $_var_2["recommended_num"]);
	$_var_2["guide_z_index"] = !$_var_2["guide_z_index"] || $_var_2["guide_z_index"] <= 0 ? 98 : $_var_2["guide_z_index"];
	return $_var_2;
}
function wq_guide_array($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4)
{
	$_var_5 = array();
	if ($_arg_0 && !empty($_arg_1) && !empty($_arg_2) && !empty($_arg_3) && !empty($_arg_4)) {
		$_var_5 = array("logo" => $_arg_1, "title" => $_arg_2, "intro" => $_arg_3, "link" => $_arg_4);
	}
	return $_var_5;
}
function wq_gudie_get_recommended_tid_list()
{
	global $_G;
	$_var_1 = wq_gudie_get_setting();
	$_var_2 = array();
	$_var_3 = $_var_1["tid_recommended"];
	if (!empty($_var_3)) {
		foreach ($_var_3 as $_var_4) {
			$_var_5 = wq_guide_readfromcache("guide_tid" . $_var_4, "wq_");
			if (!empty($_var_5)) {
				$_var_2[$_var_4] = $_var_5;
			}
		}
		if (empty($_var_2) || count($_var_2) != count($_var_3)) {
			if (is_array($_var_2) && !empty($_var_2)) {
				$_var_3 = array_diff($_var_3, array_keys($_var_2));
			}
			if (empty($_var_2)) {
				$_var_2 = array();
			}
			$_var_6 = DB::fetch_all("SELECT tid,fid,pid,subject FROM " . DB::table("forum_post") . " WHERE tid IN(%n) AND first=1", array($_var_3), "tid");
			foreach ($_var_6 as $_var_4 => $_var_7) {
				$_var_8[$_var_4] = $_var_7["pid"];
			}
			$_var_9 = wq_guide_get_tid_images($_var_8);
			foreach ($_var_6 as $_var_4 => $_var_7) {
				$_var_7["image"] = $_var_9[$_var_4] ? $_var_9[$_var_4] : '';
				$_var_7["url"] = "forum.php?mod=viewthread&tid=" . $_var_4;
				$_var_10[$_var_4] = $_var_7;
			}
			foreach ($_var_10 as $_var_4 => $_var_11) {
				$_var_2[$_var_4] = $_var_11;
				wq_guide_writetocache("guide_tid" . $_var_4, $_var_11);
			}
		}
	}
	return $_var_2;
}
function wq_guide_get_tid_images($_arg_0)
{
	foreach ($_arg_0 as $_var_1 => $_var_2) {
		$_var_3 = C::t("forum_attachment_n")->count_image_by_id("pid:" . $_var_2, "pid", $_var_2);
		if ($_var_3 > 0) {
			$_var_4[$_var_1] = wq_guide_get_image("pid:" . $_var_2, "pid", $_var_2);
		}
	}
	$_var_5 = $_var_6 = 100;
	foreach ($_var_4 as $_var_7 => $_var_8) {
		$_var_9 = $_var_8["aid"];
		$_var_10[$_var_7] = sprintf("forum.php?mod=image&aid=%s&size=%sx%s&key=%s", $_var_9, $_var_5, $_var_6, dsign($_var_9 . "|" . $_var_5 . "|" . $_var_6));
	}
	return $_var_10;
}
function wq_guide_get_image($_arg_0, $_arg_1, $_arg_2)
{
	return DB::fetch_first("SELECT * FROM %t WHERE %i AND isimage IN (1, -1) ORDER BY width DESC", array(wq_guide_get_tableid($_arg_0), DB::field($_arg_1, $_arg_2)));
}
function wq_guide_get_tableid($_arg_0)
{
	if (!is_numeric($_arg_0)) {
		list($_var_1, $_var_2) = explode(":", $_arg_0);
		$_var_3 = dintval($_var_2);
		$_arg_0 = DB::result_first("SELECT tableid FROM %t WHERE pid=%d LIMIT 1", array("forum_attachment", $_var_3));
		if ($_arg_0 >= 0 && $_arg_0 < 10) {
			$_arg_0 = intval($_arg_0);
		} else {
			$_arg_0 = "127";
		}
	}
	if ($_arg_0 >= 0 && $_arg_0 < 10) {
		return "forum_attachment_" . intval($_arg_0);
	}
	if ($_arg_0 == 127) {
		return "forum_attachment_unused";
	}
}
function wq_guide_writetocache($_arg_0, $_arg_1, $_arg_2 = "wq_")
{
	global $_G;
	$_var_4 = array("expireat" => time() + 3600, "data" => $_arg_1);
	include_once libfile("function/cache");
	$_var_5 = getcachevars(array("info" => $_var_4));
	if (memory("check")) {
		return memory("set", $_arg_2 . $_arg_0, serialize($_var_4), 3600);
	}
	global $_G;
	$_var_6 = DISCUZ_ROOT . "./data/sysdata/wq_gudie/";
	if (!is_dir($_var_6)) {
		dmkdir($_var_6, 511);
	}
	if ($_var_7 = @fopen($_var_6 . $_arg_2 . $_arg_0 . ".php", "wb")) {
		fwrite($_var_7, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($_arg_2 . $_arg_0 . ".php" . $_var_5 . $_G["config"]["security"]["authkey"]) . "\n\n" . $_var_5 . "?>");
		fclose($_var_7);
	} else {
		echo "Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .";
		return 0;
	}
}
function wq_guide_readfromcache($_arg_0, $_arg_1 = "wq_")
{
	global $_G;
	if (memory("check")) {
		$_var_3 = memory("get", $_arg_1 . $_arg_0);
		$_var_4 = unserialize($_var_3);
		return $_var_4["data"];
	}
	$_var_5 = DISCUZ_ROOT . "./data/sysdata/wq_gudie/";
	if (!is_dir($_var_5)) {
		dmkdir($_var_5, 511);
	}
	$_var_4 = array();
	if (is_file($_var_5 . $_arg_1 . $_arg_0 . ".php")) {
		@(include $_var_5 . $_arg_1 . $_arg_0 . ".php");
		if (time() < $_var_6["expireat"]) {
			$_var_4 = $_var_6["data"];
		}
	}
	return $_var_4;
}
function wq_guide_get_user_is_focus_wechat($_arg_0)
{
	global $_G;
	if (empty($_G["cache"]["plugin"]["wq_login"])) {
		loadcache(array("plugin"));
	}
	$_var_2 = !empty($_G["cache"]["plugin"]["wq_login"]) ? 1 : 0;
	$_var_3 = 0;
	if ($_var_2) {
		$_var_4 = $_G["cache"]["plugin"]["wq_login"];
		$_var_5 = trim($_var_4["appid"]);
		$_var_6 = trim($_var_4["appsecret"]);
		$_var_7 = C::t("#wq_login#wq_login_member")->fetch_first_by_uid($_arg_0);
		if (!$_var_7) {
			return $_var_3;
		}
		$_var_8 = $_var_7["openid"];
		require_once DISCUZ_ROOT . "./source/plugin/wq_login/class/jssdk.class.php";
		if (!function_exists("_get")) {
			require_once DISCUZ_ROOT . "./source/plugin/wq_login/function/function_login.php";
		}
		$_var_9 = new WQJSSDK($_var_5, $_var_6, '');
		$_var_10 = $_var_9->getAccessToken();
		$_var_11 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $_var_10 . "&openid=" . $_var_8;
		$_var_12 = json_decode(_get($_var_11), true);
		if ($_var_12["errcode"] == "40001") {
			$_var_10 = $_var_9->getAccessToken(true);
			$_var_11 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $_var_10 . "&openid=" . $_var_8;
			$_var_12 = json_decode(_get($_var_11), true);
		}
		if ($_var_12["subscribe"] == 1 || isset($_var_12["errcode"]) && !isset($_var_12["subscribe"]) && $_var_7["isfocus"]) {
			$_var_3 = 1;
		}
		if ($_var_7["isfocus"] != $_var_3) {
			C::t("#wq_login#wq_login_member")->update($_var_7["id"], array("isfocus" => $_var_3));
		}
	}
	return $_var_3;
}
function wq_guide_get_wechat_link($_arg_0)
{
	if (wq_guide_is_picurl($_arg_0)) {
		return $_arg_0;
	}
	return "./source/plugin/wq_guide/static/images/" . $_arg_0;
}
function wq_guide_is_picurl($_arg_0)
{
	return in_array(strtolower(substr($_arg_0, 0, 6)), array("http:/", "https:", "ftp://"));
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}