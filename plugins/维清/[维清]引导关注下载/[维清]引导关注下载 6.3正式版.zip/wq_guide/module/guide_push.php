<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: toedit_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$tid = $_GET['tid'] ? intval($_GET['tid']) : 0;
$extra = array('showdialog' => true, 'closetime' => true);
$extra_error = array('showdialog' => true, 'closetime' => true);

if($_G['adminid'] != 1 && $setting['thread_switch']) {
	showmessage($Plang['0b03faa51ff27ba8'], $dreferer);
}

if(!$tid) {
	showmessage($Plang['0c7756cd18154355'], "", array(), $extra_error);
}

if(submitcheck('submit')) {
	if(in_array($tid, $setting['tid_recommended'])) {
		showmessage($Plang['398f20c553ba7c49'], "", array(), $extra_error);
	}
	$num = $setting['recommended_num'] - 1;
	$tid_recommended = $tid . ',' . implode(',', array_slice($setting['tid_recommended'], 0, $num));
	$plugin = DB::fetch_first("SELECT * FROM %t WHERE identifier=%s ", array('common_plugin', 'wq_guide'));

	$where['pluginid'] = $plugin['pluginid'];
	$where['variable'] = "tid_recommended";

	DB::update('common_pluginvar', array('value' => $tid_recommended), $where);

	require_once libfile('function/cache');
	updatecache(array('plugin', 'setting'));

	showmessage($Plang['1d982cfcf8428856'], $dreferer, array(), $extra);
} else {
	include template("wq_guide:guide_push");
}
//From: Dism_taobao-com
?>