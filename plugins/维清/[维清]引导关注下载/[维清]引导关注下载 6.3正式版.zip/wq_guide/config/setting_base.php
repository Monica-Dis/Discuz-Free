<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-12-11 09:44:05Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_guide'];
$setting['app_switch'] = intval($setting['app_switch']);
$setting['app_logo'] = trim($setting['app_logo']);
$setting['app_tilte'] = trim($setting['app_tilte']);
$setting['app_intro'] = trim($setting['app_intro']);
$setting['app_link'] = trim($setting['app_link']);
$setting['wechat_switch'] = intval($setting['wechat_switch']);
$setting['wechat_logo'] = trim($setting['wechat_logo']);
$setting['wechat_tilte'] = trim($setting['wechat_tilte']);
$setting['wechat_intro'] = trim($setting['wechat_intro']);
$setting['wechat_link'] = trim($setting['wechat_link']);
$setting['thread_switch'] = intval($setting['thread_switch']);
$setting['tid_recommended'] = trim($setting['tid_recommended']);
$setting['recommended_num'] = intval($setting['recommended_num']);
$setting['is_app_link'] = intval($setting['is_app_link']);
$setting['fixed'] = intval($setting['fixed']);
$setting['style_select'] = intval($setting['style_select']);
$setting['is_open_button'] = intval($setting['is_open_button']);
$setting['advertisement_time'] = trim($setting['advertisement_time']);
$setting['guide_z_index'] = intval($setting['guide_z_index']);

?>