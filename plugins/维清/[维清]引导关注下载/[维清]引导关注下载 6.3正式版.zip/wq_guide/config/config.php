<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_guide/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_guide/function/function_guide.php';

$Plang = wq_loadlang('wq_guide');

$setting = wq_loadsetting('wq_guide');
$setting['tid_recommended'] = array_filter(explode(",", str_replace($Plang['2f0278d0292cdf93'], ',', $setting['tid_recommended'])));
$setting['tid_recommended'] = array_slice($setting['tid_recommended'], 0, $setting['recommended_num']);

?>