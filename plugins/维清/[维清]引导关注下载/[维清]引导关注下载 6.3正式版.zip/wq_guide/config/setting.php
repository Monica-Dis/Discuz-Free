<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_guide/config/setting_base.php';

$setting['recommended_num'] = $setting['recommended_num'] <= 0 || $setting['recommended_num'] > 5 ? 5 : $setting['recommended_num'];
$setting['wechat_link'] = empty($setting['wechat_link']) ? 'wq_qrcode.jpg' : $setting['wechat_link'];
$setting['guide_z_index'] = !$setting['guide_z_index'] || $setting['guide_z_index'] <= 0 ? 98 : $setting['guide_z_index'];

?>