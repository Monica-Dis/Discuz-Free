<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_guide/class/base.class.php';

class plugin_wq_guide extends plugin_wq_guide_base {

	function global_header() {

	}

}

class plugin_wq_guide_forum extends plugin_wq_guide {

	function viewthread_postfooter() {
		global $_G;
		$tid = $_GET['tid'];
		if($_G['adminid'] == 1 && $this->setting['thread_switch']) {
			$arr = array('<a class="push" href="javascript:;" onclick="showWindow(\'push\',\'plugin.php?id=wq_guide&mod=push&tid=' . $tid . '\')">' . $this->lang['25c9ae07091f3c73'] . '</a>',);
			return $arr;
		}
	}

}

class mobileplugin_wq_guide extends plugin_wq_guide {

	function global_header_mobile() {
		global $_G;

		if($this->setting['fixed'] == 1) {
			return $this->_wq_guide_tpl();
		}
		return "";
	}

	function global_footer_mobile() {
		global $_G;

		if($this->setting['fixed'] == 2) {
			return $this->_wq_guide_tpl();
		}
		return "";
	}

	function _wq_guide_tpl() {
		global $_G;

		if(($_GET['id'] == 'wq_app_setting' && CURSCRIPT == 'plugin') || ($_GET['id'] == 'tom_pintuan' && CURSCRIPT == 'plugin') || CURSCRIPT == 'home' || CURSCRIPT == 'member' || (CURSCRIPT == 'forum' && CURMODULE == 'post')) {
			return "";
		}

		$fixed = $this->setting['fixed'];
		$style_select = $this->setting['style_select'];

		include_once DISCUZ_ROOT . './source/plugin/wq_guide/function/function_guide.php';
		$lists = array();
		$app = wq_guide_array($this->setting['app_switch'], $this->setting['app_logo'], $this->setting['app_tilte'], $this->setting['app_intro'], $this->setting['app_link']);

		$wechat = wq_guide_array($this->setting['wechat_switch'], $this->setting['wechat_logo'], $this->setting['wechat_tilte'], $this->setting['wechat_intro'], $this->setting['wechat_link']);

		$isfocus_wechat = wq_guide_get_user_is_focus_wechat($_G['uid']);

		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false || $isfocus_wechat) {
			$wechat = array();
		}

		if($this->setting['thread_switch']) {
			$lists = wq_gudie_get_recommended_tid_list();
		}
		$newlists = array(
			'app' => $app,
			'wechat' => $wechat,
			'lists' => $lists,
		);
		$_G['forcemobilemessage'] = true;
		include_once template("wq_guide:guide");
		$_G['forcemobilemessage'] = false;

		if(!$app && !$wechat && !$lists) {
			return "";
		} else {
			return wq_guide_tpl($fixed, $style_select, $newlists);
		}
	}

}
//From: Dism_taobao-com
?>