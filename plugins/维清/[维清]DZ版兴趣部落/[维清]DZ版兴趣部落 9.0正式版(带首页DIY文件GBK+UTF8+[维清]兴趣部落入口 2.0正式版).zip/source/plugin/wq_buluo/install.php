<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: install.php 2016-1-15 04:24:09Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
require_once DISCUZ_ROOT . './source/plugin/wq_buluo/language/install_language.php';
$step = dhtmlspecialchars($_GET['step']);
$request_url = str_replace('&step=' . $step, '', $_SERVER['QUERY_STRING']);

switch($step) {
	default:
	case 'updatecache':
		$updatecache = '';
		cpmsg($Plang_install["updatecacheing"], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':
		require DISCUZ_ROOT . './source/plugin/wq_buluo/install/install.core.php';

		wq_buluo_levels_set();
		wq_buluo_open_follow();
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//From: Dism_taobao-com
?>