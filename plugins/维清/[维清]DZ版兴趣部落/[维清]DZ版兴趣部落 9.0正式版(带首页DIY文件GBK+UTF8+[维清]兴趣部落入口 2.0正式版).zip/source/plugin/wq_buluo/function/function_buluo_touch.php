<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function _buluo_get_tips()
{
	global $_G;
	$_var_1 = array("url" => '', "newpm" => 0);
	if (!$_G["uid"]) {
		$_var_1["url"] = "member.php?mod=logging&action=login";
	} else {
		if ($_G["member"]["newpm"] > 0) {
			$_var_1["url"] = "home.php?mod=space&do=pm";
			$_var_1["newpm"] = $_G["member"]["newpm"];
		} else {
			$_var_1["url"] = "home.php?mod=space&uid=" . $_G["uid"] . "&do=profile&mycenter=1";
		}
	}
	return $_var_1;
}
function _buluo_get_poll_has_image($_arg_0)
{
	foreach ($_arg_0 as $_var_1) {
		if (is_array($_var_1["imginfo"]) && !empty($_var_1["imginfo"])) {
			return true;
		}
	}
	return false;
}
function _buluo_get_data($_arg_0, $_arg_1 = "1", $_arg_2 = false)
{
	$_var_3 = _buluo_get_tids($_arg_0);
	$_var_4 = _buluo_get_summary_pids_by_tids($_var_3, $_arg_2);
	$_var_5["summarys"] = $_var_4["summarys"];
	$_var_5["fids"] = $_var_4["fids"];
	$_var_5["pids"] = $_var_4["pids"];
	$_var_6 = $_var_4["pids"];
	if ($_arg_1 == "3") {
		$_var_5["images"] = _buluo_get_images_by_tid_pids($_var_6, 3);
	} else {
		$_var_5["images"] = _buluo_get_images_by_tid_pids($_var_6);
	}
	return $_var_5;
}
function _buluo_get_tids($_arg_0)
{
	foreach ($_arg_0 as $_var_1) {
		$_var_2[] = $_var_1["tid"];
	}
	return $_var_2;
}
function _buluo_get_images_by_tid_pids($_arg_0, $_arg_1 = "1")
{
	global $showmodel;
	$_var_3 = array();
	foreach ($_arg_0 as $_var_4 => $_var_5) {
		$_var_6 = C::t("forum_attachment_n")->count_by_id("pid:" . $_var_5, "pid", $_var_5);
		if ($_var_6 > 0) {
			$_var_3[$_var_4]["count"] = $_var_6;
			if ($_arg_1 == "1") {
				$_var_7 = C::t("forum_attachment_n")->fetch_max_image("pid:" . $_var_5, "pid", $_var_5);
				if ($showmodel == "b") {
					$_var_8 = $_var_7["width"] > 1280 ? 1280 : $_var_7["width"];
					$_var_9 = 9999;
				} else {
					$_var_8 = 180;
					$_var_9 = 150;
				}
				if ($_var_7) {
					$_var_3[$_var_4]["image"] = sprintf("forum.php?mod=image&aid=%s&size=%sx%s&key=%s", $_var_7["aid"], $_var_8, $_var_9, dsign($_var_7["aid"] . "|" . $_var_8 . "|" . $_var_9));
				} else {
					unset($_var_3[$_var_4]);
				}
				$_var_7 = NULL;
			} else {
				if ($_var_6 > "2") {
					$_var_8 = $_var_9 = 160;
				} else {
					if ($_var_6 > "1") {
						$_var_8 = $_var_9 = 240;
					} else {
						$_var_8 = 400;
						$_var_9 = 200;
					}
				}
				$_var_10 = _buluo_fetch_max_image_three("pid:" . $_var_5, "pid", $_var_5);
				foreach ($_var_10 as $_var_11) {
					$_var_3[$_var_4]["image"][] = sprintf("forum.php?mod=image&aid=%s&size=%sx%s&key=%s", $_var_11["aid"], $_var_8, $_var_9, dsign($_var_11["aid"] . "|" . $_var_8 . "|" . $_var_9));
				}
			}
		}
	}
	return $_var_3;
}
function _buluo_fetch_max_image_three($_arg_0, $_arg_1, $_arg_2)
{
	return DB::fetch_all("SELECT * FROM %t WHERE %i AND isimage IN (1, -1) ORDER BY width DESC LIMIT 3", array(_buluo_get_tableid($_arg_0), DB::field($_arg_1, $_arg_2)));
}
function _buluo_get_tableid($_arg_0)
{
	if (!is_numeric($_arg_0)) {
		list($_var_1, $_var_2) = explode(":", $_arg_0);
		$_var_3 = dintval($_var_2);
		$_arg_0 = DB::result_first("SELECT tableid FROM %t WHERE pid=%d LIMIT 1", array("forum_attachment", $_var_3));
		if ($_arg_0 >= 0 && $_arg_0 < 10) {
			$_arg_0 = intval($_arg_0);
		} else {
			$_arg_0 = "127";
		}
	}
	if ($_arg_0 >= 0 && $_arg_0 < 10) {
		return "forum_attachment_" . intval($_arg_0);
	}
	if ($_arg_0 == 127) {
		return "forum_attachment_unused";
	}
}
function _buluo_get_summary_pids_by_tids($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = _buluo_get_wq_buluo_touch();
	if ($_arg_1) {
		$_var_4 = DB::fetch_all("SELECT pid,message,tid FROM %t WHERE tid IN(%n) AND first=1", array(DB::table("`forum_post`"), $_arg_0));
		$_var_5 = array();
		foreach ($_var_4 as $_var_6 => $_var_7) {
			$_var_5[] = $_var_7["fid"];
		}
		if ($_var_5) {
			$_var_8 = DB::fetch_all("SELECT name FROM " . DB::table("forum_forum") . " WHERE fid IN(%n)", array($_var_5));
		}
		foreach ($_var_4 as $_var_6 => $_var_7) {
			$_var_4[$_var_6]["name"] = $_var_8[$_var_7["fid"]]["name"];
		}
	} else {
		$_var_4 = DB::fetch_all("SELECT tid,pid,message FROM " . DB::table("forum_post") . " WHERE tid IN(%n) AND first=1 ", array($_arg_0));
	}
	foreach ($_var_4 as $_var_9) {
		$_var_10 = $_var_9["tid"];
		$_var_9["message"] = preg_replace("/\\[attach\\](\\d+)\\[\\/attach\\]/i", '', $_var_9["message"]);
		$_var_9["message"] = preg_replace("/\\[attachimg\\](\\d+)\\[\\/attachimg\\]/i", '', $_var_9["message"]);
		$_var_9["message"] = preg_replace("/\\[flash\\](\\w+)\\[\\/flash\\]/i", '', $_var_9["message"]);
		$_var_9["message"] = preg_replace("/\\[media\\](\\w+)\\[\\/media\\]/i", '', $_var_9["message"]);
		$_var_11[$_var_10] = wq_buluo_messagecutstr($_var_9["message"], $_var_3["group_introduction"], '');
		$_var_12[$_var_10] = $_var_9["pid"];
		$_var_13[$_var_10] = $_var_9["name"];
	}
	return array("summarys" => $_var_11, "pids" => $_var_12, "fids" => $_var_13);
}
function _buluo_get_wq_buluo_touch()
{
	global $_G;
	if (defined("IN_ADMINCP")) {
		loadcache("plugin");
	}
	$_var_1 = $_G["cache"]["plugin"]["wq_buluo"];
	$_var_1["search_keyword"] = trim($_var_1["search_keyword"]);
	$_var_1["group_top"] = intval($_var_1["group_top"]);
	$_var_1["group_number"] = intval($_var_1["group_number"]);
	$_var_1["group_introduction"] = intval($_var_1["group_introduction"]);
	$_var_1["pc_group_introduction"] = intval($_var_1["pc_group_introduction"]);
	$_var_1["group_list_show"] = intval($_var_1["group_list_show"]);
	$_var_1["view_imgnum"] = intval($_var_1["view_imgnum"]);
	$_var_1["ad_images"] = trim($_var_1["ad_images"]);
	$_var_1["ad_url"] = trim($_var_1["ad_url"]);
	$_var_1["summary_url"] = trim($_var_1["summary_url"]);
	$_var_1["help_url"] = trim($_var_1["help_url"]);
	$_var_1["data_comment"] = trim($_var_1["data_comment"]);
	$_var_1["click_num"] = intval($_var_1["click_num"]);
	$_var_1["level_comment"] = trim($_var_1["level_comment"]);
	$_var_1["page_num"] = intval($_var_1["page_num"]);
	$_var_1["logo"] = trim($_var_1["logo"]);
	$_var_1["pluginname"] = trim($_var_1["pluginname"]);
	$_var_1["subject_recommend"] = intval($_var_1["subject_recommend"]);
	$_var_1["subject_num"] = intval($_var_1["subject_num"]);
	$_var_1["logo"] = empty($_var_1["logo"]) ? "./source/plugin/wq_buluo/static/pc/images/logo_wq.png" : "./source/plugin/wq_buluo/static/pc/images/" . $_var_1["logo"];
	$_var_1["page_num"] = $_var_1["page_num"] ? $_var_1["page_num"] : 20;
	$_var_1["subject_num"] = $_var_1["subject_num"] ? $_var_1["subject_num"] > 20 ? 20 : ($_var_1["subject_num"] > 20 ? 20 : $_var_1["subject_num"]) : '';
	$_var_1["pluginname"] = empty($_var_1["pluginname"]) ? "&#37096;&#33853;" : $_var_1["pluginname"];
	$_var_1["maxwidth"] = intval($_var_1["maxwidth"]);
	$_var_1["maxheight"] = intval($_var_1["maxheight"]);
	$_var_1["listsytle"] = intval($_var_1["listsytle"]);
	$_var_1["default_index"] = intval($_var_1["default_index"]);
	return $_var_1;
}
function _buluo_get_system_smilies_from_js()
{
	$_var_0 = C::t("forum_imagetype")->fetch_all_by_type("smiley", 1);
	foreach ($_var_0 as $_var_1 => $_var_2) {
		$_var_3 = C::t("common_smiley")->fetch_all_by_type_code_typeid("smiley", $_var_2["typeid"]);
		$_var_4[$_var_1] = array();
		foreach ($_var_3 as $_var_5) {
			if ($_var_6 = @getimagesize(DISCUZ_ROOT . "./static/image/smiley/" . $_var_2["directory"] . "/" . $_var_5["url"])) {
				$_var_4[$_var_1][] = array("code" => $_var_5["code"], "image" => $_var_2["directory"] . "/" . $_var_5["url"]);
			}
		}
	}
	return $_var_4;
}
function _buluo_get_system_smilies()
{
	global $_G;
	loadcache(array("smilies", "smileytypes"));
	$_var_1 = array();
	ksort($_G["cache"]["smilies"]["replacearray"]);
	foreach ($_G["cache"]["smilies"]["replacearray"] as $_var_2 => $_var_3) {
		$_var_4 = preg_match("/smiley\\/" . $_G["cache"]["smileytypes"][$_G["cache"]["smilies"]["typearray"][$_var_2]]["directory"] . "\\/(.*)\" smilieid/iUs", $_var_3, $_var_5);
		if ($_var_4) {
			$_var_3 = $_var_5[1];
		}
		$_var_1[$_G["cache"]["smilies"]["typearray"][$_var_2]][] = array("code" => $_G["cache"]["smilies"]["searcharray"][$_var_2], "image" => $_G["cache"]["smileytypes"][$_G["cache"]["smilies"]["typearray"][$_var_2]]["directory"] . "/" . $_var_3, "id" => $_var_2);
		$_var_6 = $_var_6 + 1;
	}
	return array_values($_var_1);
}
function _buluo_wq_str_replace_message($_arg_0)
{
	$_var_1 = _buluo_wq_get_touch_Tlang();
	$_var_2 = strpos($_arg_0, "<div class=\"grey quote\"><blockquote>");
	if ($_var_2 === false) {
		return $_arg_0;
	}
	$_arg_0 = _buluo_wq_str_replace_once("<blockquote>" . $_var_1["ea1566bf6980basss2"] . ": <font color=\"#999999\">", "<font class=\"blue\">", $_arg_0);
	$_arg_0 = _buluo_wq_str_replace_once($_var_1["ea1566bf6980basss3"], "</font><font style=\"display:none\">", $_arg_0);
	$_arg_0 = _buluo_wq_str_replace_once("</font><br />", "</font>:", $_arg_0);
	$_arg_0 = _buluo_wq_str_replace_once("<blockquote>" . $_var_1["ea1566bf6980basss2"] . ": <font size=\"2\"><a", "<blockquote><font style=\"display:none\" ", $_arg_0);
	$_arg_0 = _buluo_wq_str_replace_once("target=\"_blank\"><font color=\"#999999\">", "></font><font class=\"blue\">", $_arg_0);
	$_arg_0 = _buluo_wq_str_replace_once("</font></a></font>:", "</font>:", $_arg_0);
	return $_arg_0;
}
function _buluo_wq_str_replace_once($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = strpos($_arg_2, $_arg_0);
	if ($_var_3 === false) {
		return $_arg_2;
	}
	return substr_replace($_arg_2, $_arg_1, $_var_3, strlen($_arg_0));
}
function _buluo_wq_usergroup($_arg_0)
{
	global $_G;
	if (!$_G["cache"]["usergroups"]) {
		loadcache("usergroups");
	}
	$_var_2["prefix"] = "LV.";
	foreach ($_G["cache"]["usergroups"] as $_var_3 => $_var_4) {
		$_var_2["group"][$_var_3] = array("title" => 0, "background" => 1, "style" => 1);
	}
	$_var_2["class"] = array("0" => "1");
	savecache("wq_usergroup", $_var_2);
}
function _buluo_wq_usergroup_show($_arg_0)
{
	global $_G;
	global $wq_touch_usergroup;
	if ($_arg_0 > 0 && $wq_touch_usergroup["group"][$_arg_0]) {
		$_var_3 = $wq_touch_usergroup["group"][$_arg_0];
		$_var_4 = $wq_touch_usergroup["prefix"] . $_var_3["title"];
		$_var_5 = $wq_touch_usergroup["class"][$_var_3["title"]];
		$_var_6 = '';
		if (!$_var_3["style"]) {
			if ($_var_3["bgcolor"] && $_var_3["background"]) {
				$_var_6 = $_var_6 . ("background-color:" . $_var_3["bgcolor"] . ";");
			}
			if ($_var_3["color"]) {
				$_var_6 = $_var_6 . ("color:" . $_var_3["color"] . ";");
			}
			$_var_6 = "style=\"" . $_var_6 . "\"";
		}
		if ($_var_3["background"]) {
			$_var_7 = "<i class=\"dislv" . $_var_5 . " dislv\" " . $_var_6 . ">" . $_var_4 . "</i>";
		} else {
			$_var_7 = "<i class=\"nodislv" . $_var_5 . "\" " . $_var_6 . ">" . $_var_4 . "</i>";
		}
		return $_var_7;
	}
}
function _buluo_wq_usergroup_showMenu()
{
	global $_G;
	global $do;
	$_var_2 = $_G["member"]["extgroupids"] ? explode("\t", $_G["member"]["extgroupids"]) : array();
	$_var_3["current"] = "upgrade";
	foreach ($_G["cache"]["usergroups"] as $_var_4 => $_var_5) {
		$_var_5["grouptitle"] = strip_tags($_var_5["grouptitle"]);
		if ($_var_5["type"] == "special") {
			$_var_6 = $_G["cache"]["usergroup_" . $_var_4]["radminid"] ? "admin" : "user";
		} else {
			if ($_var_5["type"] == "system") {
				$_var_6 = $_G["cache"]["usergroup_" . $_var_4]["radminid"] ? "admin" : "user";
			} else {
				if ($_var_5["type"] == "member") {
					$_var_6 = "upgrade";
				}
			}
		}
		$_var_7 = '';
		if (!empty($_G["wq_gid"]) && $_G["wq_gid"] == $_var_4) {
			$_var_7 = " class=\"xi1\"";
		}
		$_var_8 = "<li><a style=\"display: block;\" href=\"home.php?mod=spacecp&ac=usergroup&gid=" . $_var_4 . "\"" . $_var_7 . ">" . _buluo_wq_usergroup_show($_var_4) . "<i class=\"m_r5\"></i>" . $_var_5["grouptitle"] . "</a></li>";
		if (in_array($_var_4, $_var_2)) {
			$_var_3["my"] = $_var_3["my"] . $_var_8;
		}
		$_var_3[$_var_6] = $_var_3[$_var_6] . $_var_8;
		if (!empty($_G["wq_gid"]) && $_G["wq_gid"] == $_var_4) {
			$_var_3["current"] = $_var_6;
		}
	}
	$_var_7 = '';
	if (!$_G["wq_gid"] && $do == "usergroup") {
		$_var_7 = " class=\"xi1\"";
	}
	$_var_3["my"] = "<li><a style=\"display: block;\" href=\"home.php?mod=spacecp&ac=usergroup\"" . $_var_7 . ">" . _buluo_wq_usergroup_show($_G["groupid"]) . "<i class=\"m_r5\"></i>" . $_G["group"]["grouptitle"] . "</a></li>" . $_var_3["my"];
	if (!$_G["wq_gid"] && $do == "usergroup") {
		$_var_3["current"] = "my";
	}
	return $_var_3;
}
function _buluo_preg_replace_br($_arg_0)
{
	$_arg_0 = preg_replace("/(<br\\s*\\/\\s*>[\\r\\n]+\$)/i", '', $_arg_0, 1, $_var_1);
	if ($_var_1) {
		$_arg_0 = _buluo_preg_replace_br($_arg_0);
	}
	return $_arg_0;
}
function _buluo_wq_resideprovince($_arg_0)
{
	$_var_1 = _buluo_wq_get_touch_Tlang();
	return str_replace(array($_var_1["resideprovince"], $_var_1["residecity"], $_var_1["0de70f0f08a77785"], $_var_1["5446a115dc981ae7"], $_var_1["6td65830e2236719"], $_var_1["78910dffa96aba98"], $_var_1["78910dffa96tys98"]), '', $_arg_0);
}
function _buluo_wq_residecity($_arg_0)
{
	$_var_1 = _buluo_wq_get_touch_Tlang();
	return str_replace(array($_var_1["9f6b816c3fb1213b"], $_var_1["4d38f762e9188de8"], $_var_1["df11d990136ee351"], $_var_1["9114f16c4238b008"], $_var_1["a9d5652ee2f23233"], $_var_1["4a9cb04973965afd"], $_var_1["a604ec749da8055e"], $_var_1["56fe906037705ffb"], $_var_1["0f9cd68a1729547a"], $_var_1["481e3db9a01400e5"], $_var_1["2846b427366aac7c"], $_var_1["0c5136c7d35c6b9f"], $_var_1["7908585445d727ff"], $_var_1["4065f23e9378253c"], $_var_1["0de70f0f08a77785"], $_var_1["133287fc88f630f7"], $_var_1["a6462d49b06587b5"], $_var_1["b06e7ef71a49a4b7"], $_var_1["c1cd0b1a27e8acf6"], $_var_1["5cad8f156c4674b0"], $_var_1["6e5e9a457df58913"], $_var_1["f16f235804ea4170"], $_var_1["b8f79f057aad1b23"], $_var_1["5446a115dc981ae7"], $_var_1["eeafa1ba935e31ca"], $_var_1["a283d676e4e24860"], $_var_1["aca984153b17ea26"], $_var_1["82d96ad5bd23c3d4"], $_var_1["11c89b033d847a2e"], $_var_1["2dd60837e9236715"]), '', $_arg_0);
}
function _buluo_wq_get_touch_Tlang()
{
	$_var_0 = _buluo_get_wq_buluo_touch();
	$_var_1 = _buluo_wq_get_templatename();
	if (CHARSET == "gbk") {
		$_var_2 = DISCUZ_ROOT . "./template/" . $_var_1 . "/php/lang_gbk.php";
	} else {
		$_var_2 = DISCUZ_ROOT . "./template/" . $_var_1 . "/php/lang_utf8.php";
	}
	include $_var_2;
	global $Tlang;
	return $Tlang;
}
function _buluo_wq_get_templatename()
{
	global $_G;
	$_var_1 = $_G["setting"]["styleid2"];
	loadcache("style_" . $_var_1);
	$_var_2 = $_G["cache"]["style_" . $_var_1];
	$_var_3 = str_replace("./template/", '', $_var_2["tpldir"]);
	return $_var_3;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_5 = "success";