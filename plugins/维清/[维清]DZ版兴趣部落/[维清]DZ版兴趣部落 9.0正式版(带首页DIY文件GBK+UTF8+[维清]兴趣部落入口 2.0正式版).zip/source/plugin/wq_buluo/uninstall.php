<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2016-1-15 04:24:09Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_buluo/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];
$step = dhtmlspecialchars($_GET['step']);
$request_url = str_replace('&step=' . $step, '', $_SERVER['QUERY_STRING']);
switch($step) {
	case 'sql':
		$sql = <<<EOF
        DROP TABLE IF EXISTS `pre_wq_buluo_levelstyle`;
        DROP TABLE IF EXISTS `pre_wq_buluo_rewardlog`;
        DROP TABLE IF EXISTS `pre_wq_buluo_groupuser_extinfo`;
        DROP TABLE IF EXISTS `pre_wq_buluo_group_extinfo`;
        DROP TABLE IF EXISTS `pre_wq_buluo_groupthread_extinfo`;
        DROP TABLE IF EXISTS `pre_wq_buluo_signlog`;
        DROP TABLE IF EXISTS `pre_wq_buluo_forward`;
        DROP TABLE IF EXISTS `pre_wq_buluo_stat`;
        DROP TABLE IF EXISTS `pre_wq_buluo_statuser`;
EOF;
		runquery($sql);
		require_once DISCUZ_ROOT . './source/plugin/wq_buluo/config/loadfunc.php';
		wq_rmdir(DISCUZ_ROOT . './data/cache/wq_buluo/');
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_buluo.php");

		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//From: Dism_taobao-com
?>