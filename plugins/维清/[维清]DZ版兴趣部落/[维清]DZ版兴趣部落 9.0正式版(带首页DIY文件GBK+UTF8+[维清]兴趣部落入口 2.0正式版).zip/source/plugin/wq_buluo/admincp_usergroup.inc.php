<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_level.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_buluo/config/config.php';
$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_buluo&pmod=admincp_usergroup';
$href = ADMINSCRIPT . '?action=' . $url;
$msg_url = 'action=' . $url;
if(!submitcheck('form')) {

	showtips($Plang['level_tips']);
	showformheader($url, '', 'form');
	showtableheader();
	showtablerow('class="hover"', '', array(
		$Plang['prefix'] . ': <input type="text"  name="prefix"  value="' . dhtmlspecialchars($wq_buluo_level['prefix']) . '" />',
	));
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'hovers');
	showsubtitle(array($Plang['level'], $Plang['color_match'], $Plang['experience']));


	foreach($wq_buluo_level['level'] as $key => $val) {
		if($key == 0) {
			$input = '<div><input type="number" readonly style="width:150px;" name="level[val][]" value="0"/></div>';
		} else {

			$input = '<div><input type="number" style="width:150px;" min="1" name="level[val][]"  value="' . dhtmlspecialchars($val['val']) . '" /></div>';
		}
		showtablerow('', '', array(
			$wq_buluo_level['prefix'] . '<font class="wq_levels">' . $key . '</font>',
			'<input type="number" style="width:50px;" name="level[class][]"  value="' . dhtmlspecialchars($val['class']) . '" min="1" max="5" />',
			$input,
			)
		);
	}
	showsubmit('form', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$_GET = dhtmlspecialchars($_GET);

	$_GET['prefix'] = trim($_GET['prefix']);

	if($_GET['prefix']) {
		if($_GET['level']) {
			$wq_buluo_levels['prefix'] = $_GET['prefix'];
			array_multisort($_GET['level']['val'], $_GET['level']['class']);
			$k = 0;
			foreach($_GET['level']['val'] as $key => $value) {
				$value = intval($value);
				$class = in_array($_GET['level']['class'][$key], array('1', '2', '3', '4', '5')) ? $_GET['level']['class'][$key] : 1;
				if($value == 0) {
					$k ++;
					$wq_buluo_levels['level'][0] = array('val' => 0, 'class' => $class);
				} elseif($value >= 1) {
					$k ++;
					$wq_buluo_levels['level'][$k - 1] = array('val' => $value, 'class' => $class);
				}
			}
			if(!$k) {
				cpmsg($Plang['level_error'], $msg_url, 'error');
			}
			foreach(C::t('#wq_buluo#wq_buluo_levelstyle')->fetch_all() as $j => $val) {
				unset($val['lid']);
				$val['content'] = unserialize($val['content']);
				foreach($wq_buluo_levels['level'] as $key => $value) {
					$content[$key] = $val['content'][$key] ? $val['content'][$key] : $Plang['level'] . $key;
				}
				$val['content'] = serialize($content);
				C::t('#wq_buluo#wq_buluo_levelstyle')->update($j, $val);
			}
			file_put_contents('./data/cache/wq_buluo/wq_buluo_level_set.php', "<?php exit(\"Powered by www.wikin.cn\"); ?>\n" . serialize($wq_buluo_levels));
			update_level($wq_buluo_levels);
			cpmsg($Plang['setsucceed'], $msg_url, 'succeed');
		} else {
			cpmsg($Plang['level_empty'], $msg_url, 'error');
		}
	} else {
		cpmsg($Plang['prefix_no-empty'], $msg_url, 'error');
	}
}
//From: Dism_taobao-com
?>