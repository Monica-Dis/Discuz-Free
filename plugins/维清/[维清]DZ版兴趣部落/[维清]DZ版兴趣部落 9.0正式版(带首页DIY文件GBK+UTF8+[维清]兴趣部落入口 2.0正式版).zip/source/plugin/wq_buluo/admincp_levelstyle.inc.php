<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_level.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_buluo/config/config.php';
$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_buluo&pmod=admincp_levelstyle';
$href = ADMINSCRIPT . '?action=' . $url;
$msg_url = 'action=' . $url;
echo <<<EOT
<style>
    input:hover, input:focus{border-color:#09C;background:#F5F9FD none repeat scroll 0% 0%;}
</style>
EOT;
if($_GET['ac'] != 'edit') {
	$levelstyle = C::t('#wq_buluo#wq_buluo_levelstyle')->fetch_all();
	if(!submitcheck('form')) {
		showformheader($url, '', 'form');
		showtableheader($Plang['leveledit_tips'], 'nobottom');
		showsubtitle(array($Plang['del'], $Plang['order'], $Plang['stylename'], $Plang['is_use'], $Plang['operation']));
		foreach($levelstyle as $key => $val) {
			if($val['type'] == 0) {
				showtablerow('', array('class="td25"', 'width="50"'), array(
					'<input class="fs" type="checkbox" name="delete[' . $val['lid'] . ']" value="' . $val['lid'] . '"/> ',
					'<input type="number" style="width:50px;" name="displayorder[' . $val['lid'] . ']"  value="' . $val['displayorder'] . '" />',
					'<input type="text" name="name[' . $val['lid'] . '] " value ="' . dhtmlspecialchars($val['name']) . '" /> ',
					'<input class="checkbox" type="checkbox" name="status[' . $val['lid'] . ']" value="1" ' . ($val['status'] > 0 ? 'checked' : '') . '>',
					'<a href="' . $href . '&ac=edit&lid=' . $val['lid'] . '">' . $Plang['edit'] . '</a>',
					)
				);
			}
		}
		echo '<tr><td colspan="1"></td><td colspan="4"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">' . $Plang['addlevelsytle'] . '</a></div></td></tr>';
		showsubmit('form', 'submit', 'del');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		echo <<<EOT
<script type='text/JavaScript'>
	var rowtypedata = [[
                [1,''],
                [1,'<input name="insertdisplayorder[]" type="number" style="width:50px;" value="0">'],
                [1,'<div><input name="insertname[]" type="text" ><a href="javascript:;" class="deleterow" onclick="deleterow(this)">{$Plang['delete']}</a></div>'],
                [1,'<input class="checkbox" type="checkbox" name="insertstatus[]" value="1"  checked="checked">'],
                [1,'']
        ]];
</script>
EOT;
	} else {
		foreach($levelstyle as $key => $value) {
			if($value['type'] == 0) {
				if($_GET['delete'][$value['lid']] == $value['lid']) {
					C::t('#wq_buluo#wq_buluo_levelstyle')->delete($value['lid']);
				} else {
					$name = trim($_GET['name'][$value['lid']]);
					if(!empty($name)) {
						$data = array(
							'name' => $name,
							'displayorder' => intval($_GET['displayorder'][$value['lid']]),
							'status' => $_GET['status'][$value['lid']] == 1 ? 1 : 0,
						);
						C::t('#wq_buluo#wq_buluo_levelstyle')->update($value['lid'], $data);
					}
				}
			}
		}
		if($_GET['insertname']) {
			foreach($wq_buluo_level['level'] as $key => $value) {
				$content[$key] = $Plang['level'] . $key;
			}
			$content = serialize($content);
			foreach($_GET['insertname'] as $key => $value) {
				$value = trim($value);
				if(!empty($value)) {
					$data = array(
						'name' => $value,
						'displayorder' => intval($_GET['insertdisplayorder'][$key]),
						'status' => intval($_GET['insertstatus'][$key]),
						'content' => $content,
					);
					C::t('#wq_buluo#wq_buluo_levelstyle')->insert($data);
				}
			}
		}
		$wq_buluo_level['style'] = C::t('#wq_buluo#wq_buluo_levelstyle')->fetch_all();
		foreach($wq_buluo_level['style'] as $key => $value) {
			$wq_buluo_level['style'][$key]['content'] = unserialize($wq_buluo_level['style'][$key]['content']);
		}
		savecache('wq_buluo_level', $wq_buluo_level);
		cpmsg($Plang['setsucceed'], $msg_url, 'succeed');
	}
} else {

	$levelstyle = C::t('#wq_buluo#wq_buluo_levelstyle')->fetch($_GET['lid']);
	if($levelstyle && $levelstyle['type'] == 0) {
		if(!submitcheck('form')) {
			showformheader($url . '&ac=edit&lid=' . $levelstyle['lid'], '', 'form');
			showtableheader($Plang['edit'], 'nobottom');
			showsetting($Plang['stylename'], 'name', $levelstyle['name'], 'text', '', 0, $Plang['name_tips']);
			showsetting($Plang['order'], 'displayorder', $levelstyle['displayorder'], 'number');
			showsetting($Plang['is_use'], 'status', $levelstyle['status'], 'radio');
			showtableheader($Plang['levelname'], 'nobottom');
			$content = unserialize($levelstyle['content']);
			foreach($wq_buluo_level['level'] as $key => $val) {
				showtablerow('', '', array(
					$wq_buluo_level['prefix'] . $key,
					'<input type="text" style="width:150px;" name="content[' . $key . ']"  value="' . $content[$key] . '"/>',
					)
				);
			}
			showsubmit('form', 'submit');
			showtablefooter();/*Dism��taobao��com*/
			showformfooter();
		} else {
			$_GET = dhtmlspecialchars($_GET);
			$_GET['name'] = trim($_GET['name']);
			if($_GET['name']) {
				$msg_url .= '&ac=edit&lid=' . $levelstyle['lid'];
				foreach($wq_buluo_level['level'] as $key => $value) {
					$content[$key] = trim($_GET['content'][$key]) ? trim($_GET['content'][$key]) : $Plang['level'] . $key;
				}
				$data = array(
					'name' => trim($_GET['name']),
					'displayorder' => intval($_GET['displayorder']),
					'status' => $_GET['status'] ? 1 : 0,
					'content' => serialize($content),
				);
				C::t('#wq_buluo#wq_buluo_levelstyle')->update($levelstyle['lid'], $data);
				update_level($wq_buluo_level);
				cpmsg($Plang['setsucceed'], $msg_url, 'succeed');
			} else {
				cpmsg($Plang['levelstyle_empty'], $msg_url, 'error');
			}
		}
	}
}
//From: Dism_taobao-com
?>