<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-1-15 04:24:09Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('wq_buluo_level');
include_once DISCUZ_ROOT . './source/plugin/wq_buluo/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
$wq_buluo_level = $_G['cache']['wq_buluo_level'] ? $_G['cache']['wq_buluo_level'] : wq_buluo_levels();

$Plang = wq_loadlang('wq_buluo');

$setting = wq_loadsetting('wq_buluo');
$setting['pluginname'] = empty($setting['pluginname']) ? $Plang['pluginname'] : $setting['pluginname'];

if($setting['pluginname'] != $Plang['pluginname']) {
	$newPlang = $Plang;
	unset($Plang);
	foreach($newPlang as $key => $value) {
		$Plang[$key] = str_replace($newPlang['pluginname'], $setting['pluginname'], $value);
	}
}
//From: Dism_taobao-com
?>