<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-2-6 04:25:40Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_buluo'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['logo'] = trim($setting['logo']);
$setting['search_keyword'] = trim($setting['search_keyword']);
$setting['page_num'] = intval($setting['page_num']);
$setting['group_top'] = intval($setting['group_top']);
$setting['group_number'] = intval($setting['group_number']);
$setting['group_introduction'] = intval($setting['group_introduction']);
$setting['ad_images'] = trim($setting['ad_images']);
$setting['ad_url'] = trim($setting['ad_url']);
$setting['pc_group_introduction'] = intval($setting['pc_group_introduction']);
$setting['click_num'] = intval($setting['click_num']);
$setting['subject_recommend'] = intval($setting['subject_recommend']);
$setting['subject_num'] = intval($setting['subject_num']);
$setting['summary_url'] = trim($setting['summary_url']);
$setting['help_url'] = trim($setting['help_url']);
$setting['data_comment'] = trim($setting['data_comment']);
$setting['level_comment'] = trim($setting['level_comment']);
$setting['maxwidth'] = intval($setting['maxwidth']);
$setting['maxheight'] = intval($setting['maxheight']);
$setting['listsytle'] = intval($setting['listsytle']);
$setting['pc_style'] = trim($setting['pc_style']);
$setting['pc_color'] = trim($setting['pc_color']);
$setting['mobile_style'] = trim($setting['mobile_style']);
$setting['mobile_color'] = trim($setting['mobile_color']);
$setting['pc_is_headbottom'] = intval($setting['pc_is_headbottom']);
$setting['pc_is_creat'] = intval($setting['pc_is_creat']);
$setting['mobile_header'] = intval($setting['mobile_header']);
$setting['nav_index'] = intval($setting['nav_index']);
$setting['nav_indexurl'] = trim($setting['nav_indexurl']);
$setting['default_index'] = intval($setting['default_index']);

?>