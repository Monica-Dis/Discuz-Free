<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_buluo/config/setting_base.php';
$setting['logo'] = empty($setting['logo']) ? "./source/plugin/wq_buluo/static/pc/images/logo_wq.png" : "./source/plugin/wq_buluo/static/pc/images/" . $setting['logo'];
$setting['page_num'] = $setting['page_num'] ? $setting['page_num'] : 20;
$setting['subject_num'] = $setting['subject_num'] ? ($setting['subject_num'] > 20 ? 20 : $setting['subject_num']) : '';
$setting['pc_style'] = $setting['pc_style'] ? $setting['pc_style'] : '#01a9e9';
$setting['mobile_style'] = $setting['mobile_style'] ? $setting['mobile_style'] : '#01a9e9';
$setting['pc_color'] = $setting['pc_color'] ? $setting['pc_color'] : $setting['pc_style'];
$setting['mobile_color'] = $setting['mobile_color'] ? $setting['mobile_color'] : $setting['mobile_style'];

?>