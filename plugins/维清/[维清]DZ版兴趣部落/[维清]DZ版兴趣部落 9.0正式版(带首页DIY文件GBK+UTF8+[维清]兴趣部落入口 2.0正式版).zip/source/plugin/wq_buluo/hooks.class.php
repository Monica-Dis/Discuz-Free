<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-12-2 20:00:01Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_buluo/class/base.class.php';

class plugin_wq_buluo extends plugin_wq_buluo_base {

	function common() {

		global $_G, $groupuser;

		$this->init();
		$this->common_base();

		if(!$this->setting['pluginname']) {
			$this->setting['pluginname'] = $this->lang['pluginname'];
		}
		$_G['setting']['navs'][3]['navname'] = $this->setting['pluginname'];
		$_G['setting']['wqftp']['attachurl'] = $_G['setting']['ftp']['attachurl'];
		$this->_group_update_pv();

		if(empty($_POST) && (CURSCRIPT == 'search' && CURMODULE == 'group' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'group' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'post' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == "group" && !defined("IN_BULUO"))) {
			$search = '';
			if(CURSCRIPT == 'search' && CURMODULE == 'group') {
				$search = '&search=yes';
			}

			$mod = CURSCRIPT == "group" && !defined("IN_BULUO") ? "?mod=index" : "";
			$query = !empty($_SERVER['QUERY_STRING']) ? "?" . $_SERVER['QUERY_STRING'] : $mod;

			dheader("Location:buluo.php" . $query . $search);
		}

		if(CURSCRIPT == 'search' && CURMODULE == 'group') {
			$_G['adminid'] = '1';
		}

		if($_GET['mod'] == 'group' && !empty($_G['fid'])) {
			include_once './source/plugin/wq_buluo/function/function_buluo.php';
			wq_write_groupviewed($_G['fid']);
		}


		if(CURSCRIPT == 'forum' && CURMODULE == 'group' && $_GET['action'] == 'manage' && $_POST['groupmanage']) {
			if($_FILES['iconnew']['name']) {
				$this->anew_upload_icon_banner($_FILES['iconnew'], 'icon');
			}
			if($_FILES['bannernew']['name']) {
				$this->anew_upload_icon_banner($_FILES['bannernew'], 'banner');
			}
		}

	}

	function post_succeed($param) {
		$type = $param['param'][0];
		if(in_array($type, array('post_reply_succeed', 'post_newthread_succeed'))) {
			global $_G, $thread;
			$experience = 0;
			if($type == 'post_reply_succeed') {
				if($thread['tid'] == $param['param'][2]['tid']) {
					$wq_thread = $thread;
					$wq_thread['replies'] ++;
				} else {
					$thread = C::t('forum_thread')->fetch($param['param'][2]['tid']);
				}
				if($wq_thread['authorid'] == $_G['uid']) {
					return false;
				}
				$replies = intval($wq_thread['replies']);
				if($replies >= 1) {
					if($replies >= 1 && $replies <= 10) {
						$experience = 3 + intval(($replies - 1) / 9 * 3);
					} elseif($replies >= 11 && $replies <= 50) {
						$experience = 6 + intval(($replies - 11 ) / 39 * 24);
					} elseif($replies >= 51 && $replies <= 100) {
						$experience = 30 + intval(($replies - 51 ) / 49 * 30);
					} else {
						$experience = 60 + ($replies - 100);
					}
					include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
					groupuser_extinfo_update($experience, $_G['fid'], $wq_thread['authorid'], $wq_thread['author']);
				}
			}
			$groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);
			$type_array = array('post_newthread_succeed' => 'threads', 'post_reply_succeed' => 'replies');
			$num = $groupuser[$type_array[$type]];
			if($num && $groupuser) {
				if($num == 1) {
					$experience = 3;
				} elseif($num >= 2 && $num <= 5) {
					$experience = 6;
				} elseif($num >= 6 && $num <= 9) {
					$experience = 9;
				} else {
					$experience = 12;
				}
				include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
				groupuser_extinfo_update($experience, $_G['fid'], $_G['uid'], $_G['username']);
			}
		}
	}

	function _post_succeed_for_updatestat($param) {

		$type = $param['param'][0];
		if(in_array($type, array('post_reply_succeed', 'post_newthread_succeed'))) {
			if($type == 'post_newthread_succeed') {
				C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'threadnum');
			}
			$this->_group_update_activenum($_GET['fid']);
		}
	}

	function _group_forum_message($params) {

		if($params['param'] [0] == 'group_exit_succeed') {
			C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'unfollow');

			$re = C::t('forum_forumfield')->fetch($_GET['fid']);
			C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'todayfollow', $re['membernum']);

			$this->_group_update_activenum($_G['fid']);
		}

		if($params['param'] [0] == 'group_join_succeed') {

			C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'newfollow');

			$re = C::t('forum_forumfield')->fetch($_GET['fid']);
			C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'todayfollow', $re['membernum']);

			$this->_group_update_activenum($_G['fid']);
		}
	}

	function _join_succeed_route($params) {
		$type = $params['param'][0];
		$url = $_SERVER['HTTP_REFERER'];
		if(in_array($type, array('group_join_succeed'))) {
			showmessage($type, $url);
		}
	}

	function _group_update_pv() {

		global $_G;

		if(CURSCRIPT == 'forum' && in_array(CURMODULE, array('forumdisplay', 'viewthread'))) {

			if($_G['forum']['status'] == '3') {
				C::t('#wq_buluo#wq_buluo_stat')->updatestat($_G['fid'], 'pv');

				include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';

				wq_buluo_update_uv($_G['fid']);
			}
		}

		if(CURSCRIPT == 'forum' && CURMODULE == 'group' && $_GET['action'] != 'manage') {
			C::t('#wq_buluo#wq_buluo_stat')->updatestat($_GET['fid'], 'pv');
			include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';

			wq_buluo_update_uv($_G['fid']);

		}
	}

	function _group_update_activenum($fid) {
		C::t('#wq_buluo#wq_buluo_stat')->updatestat($fid, "activenum", 1, true);
	}

	function anew_upload_icon_banner($file, $type, $new_name = 0, $is_del = 0) {
		global $_G;

		$data = $_G['forum'];
		$data['extid'] = empty($data['extid']) ? $data['fid'] : $data['extid'];
		if(!$new_name) {
			if(empty($data['extid'])) {
				return '';
			}
			if($data['status'] == 3 && $_G['setting']['group_imgsizelimit'] && $file['size'] > ($_G['setting']['group_imgsizelimit'] * 1024)) {
				return false;
			}
		}
		include_once DISCUZ_ROOT . './source/plugin/wq_buluo/class/wq_buluo_upload.php';
		$upload = new wq_buluo_upload();
		$uploadtype = $data['status'] == 3 ? 'group' : 'common';

		if(!$upload->init($file, $uploadtype, $data['extid'], $type)) {
			return false;
		}
		if(!$new_name) {
			if(!$upload->save()) {
				if(!defined('IN_ADMINCP')) {
					showmessage($upload->errormessage());
				} else {
					cpmsg($upload->errormessage(), '', 'error');
				}
			}
			require_once libfile('class/image');
			$img = new image;
			if($data['status'] == 3 && $type == 'icon') {
				$img->Thumb($upload->attach['target'], './' . $uploadtype . '/' . $upload->attach['attachment'], 160, 160, 'fixwr');
			} elseif($type == 'banner') {
				$imageinfo = $upload->attach['attachment']['imageinfo'];
				if($imageinfo[0] >= 640 && $imageinfo[1] >= 250) {
					$img->Thumb($upload->attach['target'], './' . $uploadtype . '/' . $upload->attach['attachment'], 640, 250, 'fixwr');
				}
			}
			return $upload->attach['attachment'];
		} else {
			if(file_exists($upload->attach['target'])) {
				if($is_del) {
					@unlink($upload->attach['target']);
				} else {
					list($usec, $sec) = explode(" ", microtime());
					$times = str_replace('.', '', (float) $usec + (float) $sec) . '_';
					$tem_path = str_replace('./', '', str_replace('wq_buluo_', $times, $upload->attach['target']));
					$min_path = str_replace('wq_buluo_', '', $upload->attach['target']);
					$new_filename = str_replace('./', '', $min_path);
					if(file_exists($min_path)) {
						rename($min_path, $tem_path);
						$succeed = rename($upload->attach['target'], $new_filename);
						if($succeed) {
							@unlink($tem_path);
						} else {
							rename($tem_path, str_replace($times, '', $tem_path));
						}
					}
				}
			}
		}
	}

}

class plugin_wq_buluo_member extends plugin_wq_buluo {

	function logging_member_message($param) {

		if(preg_match("|buluo|is", $param['param'][1]) && $_GET['action'] == 'logout') {
			include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
			wq_buluo_showmessage($param);
		}
	}

}

class plugin_wq_buluo_misc extends plugin_wq_buluo {

	function invite_misc_message($param) {

		if($_GET['action'] == 'group') {
			include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
			wq_buluo_showmessage($param);
		}
	}

}

class plugin_wq_buluo_group extends plugin_wq_buluo {

	function group_common_message($param) {
		$allarr = array(
			'group_description_failed',
			'group_close_only_founder',
			'group_setup_succeed',
			'file_size_overflow',
			'file_upload_error_-101',
			'file_upload_error_-102',
			'file_upload_error_-103',
			'file_upload_error_-104',
		);
		if(in_array($param['param'][0], $allarr)) {

			$errarr = array_slice($allarr, 3);
			$is_del = 0;
			if(in_array($param['param'][0], $errarr)) {
				$is_del = 1;
			}
			if($_FILES['bannernew']['name']) {
				$this->anew_upload_icon_banner($_FILES['bannernew'], 'banner', 1, $is_del);
			}
			if($_FILES['iconnew']['name']) {
				$this->anew_upload_icon_banner($_FILES['iconnew'], 'icon', 1, $is_del);
			}
		}
		include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
		wq_buluo_showmessage($param);
	}

	function forumdisplay_forum_message($param) {
		global $_G;
		if(!in_array(strtolower(substr($src[1], 0, 6)), array('http:/', 'https:', 'ftp://'))) {
			$url = $_G['siteurl'] . $param['param'][1];
		} else {
			$url = $param['param'][1];
		}
		if($param['param'][0] == 'forum_group_noallowed') {
			$url = $url . '&status=2';
			dheader("Location:" . $url);
		}
		if($param['param'][0] == 'forum_group_moderated') {
			$url = $url . '&status=3';
			dheader("Location:" . $url);
		}

		include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
		$url = substr($param['param'][1], 0, strrpos($param['param'][1], "="));
		if($url == 'forum.php?mod=group&fid') {
			$param['param'][1] = 'group.php';
		}

		wq_buluo_showmessage($param);
	}

	function post_wq_buluo_message($param) {
		$this->post_succeed($param);

		$this->_post_succeed_for_updatestat($param);
	}

	function group_forum_message($params) {
		$this->_group_forum_message($params);
	}

	function post_infloat_btn_extra() {
		if(CURSCRIPT == 'forum' && CURMODULE == 'post' && defined("IN_BULUO")) {
			$return = <<<EOF
        <script>
           var formid = wqjq("form[id='postform']");
           var url = formid.attr('action');
           var new_url = url.replace('forum.php?', 'buluo.php?');
             formid.attr('action',new_url);
        </script>
EOF;
			return $return;
		}
	}

	function viewthread_top() {
	}

	function viewthread_output() {
		global $_G, $post, $postno, $modmenu, $thread;
		if((CURSCRIPT == 'forum' && $_GET['mod'] == 'viewthread')) {

			if(!empty($_GET['tid']) && !empty($_GET['viewpid']) && !empty($_GET['inajax'])) {
				include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
				$groupuser = wq_buluo_get_fid_member($post['fid']);
				include template('diy:viewthread_node', 0, 'source/plugin/wq_buluo/template/forum');
				include template('common/footer_ajax');
				exit('');
			}

		}
	}

	function viewthread_posttop_output() {
		global $_G, $postlist;
		foreach($postlist as $pkey => $post) {
			$string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array('&', '"', '<', '>'), $post['message']);


			if(CHARSET == 'gbk') {
				include DISCUZ_ROOT . './source/plugin/wq_buluo/language/emoji_lang_gbk.php';
			} else {
				include DISCUZ_ROOT . './source/plugin/wq_buluo/language/emoji_lang_utf8.php';
			}
			foreach($emoji as $key => $value) {

				$value = str_replace("\\", "", $value);
				$string = str_replace($value, '<img class="face" width="26" height="26" alt="����" src="http://pub.idqqimg.com/qqun/xiaoqu/mobile/img/face2/' . $key . '.png">', $string);
			}

			$postlist[$pkey]['message'] = $string;
		}
	}

}

class mobileplugin_wq_buluo extends plugin_wq_buluo {

	function common() {
		global $_G, $groupuser;

		if(defined('IN_MAGMOBILE_API')) {
			return;
		}

		$this->init();
		$this->common_base();
		$_G['setting']['seccodedata']['rule']['post']['allow'] = false;
		if((CURSCRIPT == 'buluo' || CURSCRIPT == 'group') && empty($_GET['mod']) && $this->setting['default_index'] == 2) {
			dheader("Location:plugin.php?id=wq_buluo");
		} elseif((CURSCRIPT == 'buluo' || CURSCRIPT == 'group') && empty($_GET['mod']) && $this->setting['default_index'] == 3) {
			dheader("Location:plugin.php?id=wq_buluo&mod=user");
		}

		if(!$this->setting['pluginname']) {
			$this->setting['pluginname'] = $this->lang['pluginname'];
		}
		$_G['setting']['navs'][3]['navname'] = $this->setting['pluginname'];
		$_G['setting']['seotitle']['group'] = $this->setting['pluginname'];
		$_G['setting']['wqftp']['attachurl'] = $_G['setting']['ftp']['attachurl'];
		if((CURSCRIPT == 'search' && CURMODULE == 'group' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'group' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'post' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && $_G['forum']['status'] == '3' && !defined("IN_BULUO")) || (CURSCRIPT == "group" && !defined("IN_BULUO"))) {
			if(!$_G['inajax']) {
				$search = '';
				if(CURSCRIPT == 'search' && CURMODULE == 'group') {
					$search = '&search=yes';
				}
				$mod = CURSCRIPT == "group" && !defined("IN_BULUO") && $this->setting['default_index'] == 1 ? "?mod=index" : "";
				$query = !empty($_SERVER['QUERY_STRING']) ? "?" . $_SERVER['QUERY_STRING'] : $mod;
				dheader("Location:buluo.php" . $query . $search);
			}
		}

		$this->_group_update_pv();


		if(CURSCRIPT == 'search' && CURMODULE == 'group') {
			$_G['adminid'] = '1';
		} elseif(CURSCRIPT == 'forum' && CURMODULE == 'group') {

			$action = dhtmlspecialchars($_GET['action']);
			$action = getgpc('action') && in_array($action, array('join', 'out', 'create', 'viewmember', 'manage', 'index', 'memberlist', 'recommend')) ? $action : 'index';
			if($action == 'index' && $_GET['doing'] != 'dynamic' && ($_G['forum']['gviewperm'] || $_G['isgroupuser'])) {
				$_GET['mod'] = 'forumdisplay';
				$_GET['action'] = 'list';

				require_once libfile('forum/' . $_GET['mod'], 'module');
				exit;
			}
		}

		if($_GET['mod'] == 'forumdisplay' && !empty($_GET['fid'])) {
			include_once './source/plugin/wq_buluo/function/function_buluo.php';
			wq_write_groupviewed($_G['fid']);
		}

		if(CURSCRIPT == 'forum' && CURMODULE == 'group' && $_GET['action'] == 'manage' && $_POST['groupmanage']) {
			if($_FILES['iconnew']['name']) {
				$this->anew_upload_icon_banner($_FILES['iconnew'], 'icon');
			}
			if($_FILES['bannernew']['name']) {
				$this->anew_upload_icon_banner($_FILES['bannernew'], 'banner');
			}
		}
	}

}

class mobileplugin_wq_buluo_group extends mobileplugin_wq_buluo {

	function forumdisplay_forum_message($param) {
		global $_G;
		if(!in_array(strtolower(substr($src[1], 0, 6)), array('http:/', 'https:', 'ftp://'))) {
			$url = $_G['siteurl'] . $param['param'][1];
		} else {
			$url = $param['param'][1];
		}
		if($param['param'][0] == 'forum_group_noallowed') {
			$url = $url . '&status=2';
			dheader("Location:" . $url);
		}
		if($param['param'][0] == 'forum_group_moderated') {
			$url = $url . '&status=3';
			dheader("Location:" . $url);
		}
	}

	function group_common_message($param) {
		$allarr = array(
			'group_description_failed',
			'group_close_only_founder',
			'group_setup_succeed',
			'file_size_overflow',
			'file_upload_error_-101',
			'file_upload_error_-102',
			'file_upload_error_-103',
			'file_upload_error_-104',
		);
		if(in_array($param['param'][0], $allarr)) {

			$errarr = array_slice($allarr, 3);
			$is_del = 0;
			if(in_array($param['param'][0], $errarr)) {
				$is_del = 1;
			}
			if($_FILES['bannernew']['name']) {
				$this->anew_upload_icon_banner($_FILES['bannernew'], 'banner', 1, $is_del);
			}
			if($_FILES['iconnew']['name']) {
				$this->anew_upload_icon_banner($_FILES['iconnew'], 'icon', 1, $is_del);
			}
		}
	}

	function post_wq_buluo_message($param) {
		$this->post_succeed($param);

		$this->_post_succeed_for_updatestat($param);
	}

	function group_forum_message($params) {
		global $_GET;
		$this->_group_forum_message($params);
		if(!empty($_GET['vtype']) && $_GET['vtype'] == 'view') {
			$this->_join_succeed_route($params);
		}
	}

	function viewthread_posttop_mobile_output() {
		global $_G, $postlist;
		foreach($postlist as $pkey => $post) {
			$string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array('&', '"', '<', '>'), $post['message']);


			if(CHARSET == 'gbk') {
				include DISCUZ_ROOT . './source/plugin/wq_buluo/language/emoji_lang_gbk.php';
			} else {
				include DISCUZ_ROOT . './source/plugin/wq_buluo/language/emoji_lang_utf8.php';
			}
			foreach($emoji as $key => $value) {

				$value = str_replace("\\", "", $value);
				$string = str_replace($value, '<img class="face" width="26" height="26" alt="' . $value . '" src="http://pub.idqqimg.com/qqun/xiaoqu/mobile/img/face2/' . $key . '.png">', $string);
			}

			$postlist[$pkey]['message'] = $string;
		}
	}

	function misc_fourm_output($params) {
		global $_G, $ratelist, $maxratetoday, $logcount, $loglist;

		if($_GET['type'] == 'wq_buluo') {
			if($params['template'] == 'rate') {
				$_G['forcemobilemessage'] = true;
				include_once template('forum/wq_buluoviewthread_rate');
				$_G['forcemobilemessage'] = false;
				exit("");
			}
			if($params['template'] == 'rate_view') {
				$_G['forcemobilemessage'] = true;
				include_once template('forum/wq_buluoviewthread_rate_view');
				$_G['forcemobilemessage'] = false;
				exit("");
			}
		}
	}

}
//From: Dism_taobao-com
?>