<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$uid = empty($_GET['uid']) ? $_G['uid'] : intval($_GET['uid']);

if($uid) {
	$space = getuserbyuid($uid, 1);
	if($space) {
		if($space['status'] == -1 && $_G['adminid'] != 1) {
			showmessage('space_has_been_locked');
		}
		$op = dhtmlspecialchars($_GET['op']);
		$op = in_array($op, array('group', 'thread', 'user')) ? $op : 'user';
		if($op == 'user') {
			space_merge($space, 'count');
			space_merge($space, 'field_forum');
			space_merge($space, 'profile');
			$age = !empty($space['birthyear']) ? ((intval(date("Y", time())) - $space['birthyear']) + 1) . '&#x5C81;' : "";


			$followforumid = getglobal('setting/followforumid');
			$forum_groupuser = DB::fetch_all("SELECT fid FROM " . DB::table('forum_groupuser') . " WHERE level>0 AND uid=%d", array($space['uid']));
			$fids = $group = array();
			foreach($forum_groupuser as $key => $value) {
				$fids[] = $value['fid'];
			}
			if($fids) {
				$group = DB::fetch_all("SELECT ff.icon,f.name,f.fid,f.commoncredits FROM " . DB::table('forum_forum') . " f LEFT JOIN "
						. DB::table('forum_forumfield') . " ff ON f.fid=ff.fid "
						. " WHERE ff.jointype!=-1 AND f.fid IN(%n) ORDER BY f.commoncredits DESC" . DB::limit(0, 6), array($fids));
			}
			$notinfid = wq_buluo_getall_jointypeiscolse_fid();
			$thread = DB::fetch_all("SELECT maxposition,subject,readperm,views,fid,tid,comments FROM " . DB::table('forum_thread')
					. " WHERE fid NOT IN(%n) AND authorid=%d AND closed=%d AND isgroup=%d AND author is not null ORDER BY tid DESC" . DB::limit(0, 4), array($notinfid, $space['uid'], 0, 1), 'tid');

			$i = 0;
			foreach($thread as $key => $value) {
				$i ++;
				if($i < 4) {
					if($value['fid'] == $followforumid) {
						$forwardids[] = $value['maxposition'];
						$thread[$key]['tid'] = $value['comments'];
					}
					$tids[] = $thread[$key]['tid'];
				}
			}
			if($tids) {
				$info = wq_buluo_get_forum_post_data($tids, true);
			}
			if($forwardids) {
				$forward_info = wq_buluo_get_forum_post_first($forwardids);
			}
		} elseif($op == 'group') {
			empty($_G['uid']) ? showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1)) : '';
			$perpage = 10;
			$page = intval(getgpc('page')) ? intval($_GET['page']) : 1;
			$start = ($page - 1) * $perpage;
			if($uid != $_G['uid']) {
				$wq_sql = $wq_count_sql = 'level>0 AND ';
			} else {
				$wq_sql = $wq_count_sql = '';
			}
			$forum_groupuser = DB::fetch_all("SELECT fid,level FROM " . DB::table('forum_groupuser') . " WHERE " . $wq_sql . "uid=%d", array($space['uid']), 'fid');
			$fids = $group = array();
			foreach($forum_groupuser as $key => $value) {
				$fids[] = $value['fid'];
			}
			if($fids) {
				$group = DB::fetch_all("SELECT ff.icon,ff.membernum,ff.jointype,f.name,f.threads,f.fid FROM " . DB::table('forum_forum') . " f LEFT JOIN "
						. DB::table('forum_forumfield') . " ff ON f.fid=ff.fid "
						. " WHERE f.fid IN(%n) ORDER BY f.commoncredits DESC" . DB::limit($start, $perpage), array($fids));
			}
			foreach($group as $key => $value) {
				$group[$key]['level'] = $forum_groupuser[$value['fid']]['level'];
			}

			$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('forum_groupuser') . "  WHERE " . $wq_count_sql . "uid=%d", array($space['uid']));
			$wq_user = $uid != $_G['uid'] ? wq_group_usered($_G['uid']) : '';
			$groupuser_extinfo = C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_all_by_uid($space['uid']);
		} elseif($op == 'thread') {
			$followforumid = getglobal('setting/followforumid');
			$perpage = 10;
			$page = intval(getgpc('page')) ? intval($_GET['page']) : 1;
			$start = ($page - 1) * $perpage;

			$notinfid = wq_buluo_getall_jointypeiscolse_fid();
			$threads = DB::fetch_all("SELECT * FROM " . DB::table('forum_thread')
					. " WHERE fid NOT IN(%n) AND authorid=%d AND author is not null AND closed=%d AND isgroup=%d ORDER BY tid DESC" . DB::limit($start, $perpage), array($notinfid, $space['uid'], 0, 1), 'tid');


			$count = DB::result_first("SELECT * FROM " . DB::table('forum_thread')
					. " WHERE fid NOT IN(%n) AND authorid=%d AND author is not null AND closed=%d AND isgroup=%d", array($notinfid, $space['uid'], 0, 1), 'tid');

			foreach($threads as $key => $value) {
				if($value['fid'] == $followforumid) {
					$forwardids[] = $value['maxposition'];
					$threads[$key]['tid'] = $value['comments'];
				}
				$tids[] = $threads[$key]['tid'];
			}
			if($tids) {
				$info = wq_buluo_get_forum_post_data($tids);
			}
			if($forwardids) {
				$forward_info = wq_buluo_get_forum_post_first($forwardids);
			}
		}

		function get_groupimg($imgname, $imgtype = '') {
			global $_G;
			$imgpath = $_G['setting']['attachurl'] . 'group/' . $imgname;
			if($imgname) {
				return $imgpath;
			} else {
				if($imgtype == 'icon') {
					return 'static/image/common/groupicon.gif';
				} else {
					return '';
				}
			}
		}

	} else {
		showmessage('space_does_not_exist');
	}

	include_once template('wq_buluo:tpl_buluo_card');
} else {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
//From: Dism_taobao-com
?>