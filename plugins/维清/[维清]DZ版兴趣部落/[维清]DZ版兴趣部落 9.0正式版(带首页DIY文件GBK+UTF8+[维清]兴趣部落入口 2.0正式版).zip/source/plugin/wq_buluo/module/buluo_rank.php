<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_card.php 2016-2-26 9:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('grouptype');
$groupsecond = $_G['cache']['grouptype']['second'];
$first = $_G['cache']['grouptype']['first'];
$forum_type = $groupsecond[$_G['forum'][($_G['forum']['type'] == 'sub' ? 'fup' : 'fid')]];
$secondtype = !empty($forum_type) ? $forum_type : array();
$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($_G['forum']['fup']) ? $_G['forum']['fup'] : $_G['forum']['fid']);
$firsttype = $first[$firstid];

$class = $firsttype['name'] . ($secondtype ? ' ' . $secondtype['name'] : '');
$groupmanagers = $_G['forum']['moderators'];
$groupmanagers_count = count($groupmanagers);
$groupids = $firsttype['secondlist'] ? $firsttype['secondlist'] : $firsttype['fid'];

$perpage = 10;
$page = intval(getgpc('page')) ? intval($_GET['page']) : 1;
$start = ($page - 1) * $perpage;
require_once libfile('function/group');

$wherrsql = is_array($groupids) ? ' IN(%n)' : '=%d';

$list = DB::fetch_all("SELECT f.commoncredits, ff.membernum, ff.icon, f.fid, f.name FROM " . DB::table('forum_forum') . " f "
		. "LEFT JOIN " . DB::table('forum_forumfield') . " ff ON ff.fid=f.fid "
		. "WHERE  f.fup{$wherrsql} AND ff.jointype!=%d  ORDER BY f.commoncredits DESC,f.fid ASC" . DB::limit($start, $perpage), array($groupids, -1));
$count = DB::result_first("SELECT count(*) FROM " . DB::table('forum_forum') . " f "
		. "LEFT JOIN " . DB::table('forum_forumfield') . " ff ON ff.fid=f.fid "
		. "WHERE  f.fup{$wherrsql}  AND ff.jointype!=%d", array($groupids, -1));

$groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);
$multi = multi($count, $perpage, $page, 'plugin.php?id=wq_buluo&mod=rank');

$order = DB::result_first("SELECT count(1) FROM " . DB::table('forum_forum') . " f "
		. "LEFT JOIN " . DB::table('forum_forumfield') . " ff ON ff.fid=f.fid "
		. "WHERE f.fup{$wherrsql} AND ff.jointype!=%d AND (f.commoncredits>%d OR (f.commoncredits=%d AND f.fid<%d)) ", array($groupids, -1, $_G['forum']['commoncredits'], $_G['forum']['commoncredits'], $_G['forum']['fid'])) + 1;

include_once template('wq_buluo:tpl_buluo_rank');

?>