<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_albums.php 2016-2-26 9:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$do = dhtmlspecialchars($_GET['do']);
$do = (!empty($_GET['do']) && in_array($do, array('follower', 'following'))) ? $do : 'follower';
$page = $_GET['page'] <= 0 ? 1 : intval($_GET['page']);
$perpage = 10;
$start = ($page - 1) * $perpage;
$uid = $_GET['uid'] ? $_GET['uid'] : $_G['uid'];
$viewself = $uid == $_G['uid'] ? true : false;
$space = $viewself ? $_G['member'] : getuserbyuid($uid, 1);

if(empty($space)) {
	showmessage('follow_visituser_not_exist');
} elseif(in_array($space['groupid'], array(4, 5, 6)) && ($_G['adminid'] != 1 && $space['uid'] != $_G['uid'])) {
	dheader("Location:home.php?mod=space&uid=$uid&do=profile");
}

if($viewself) {
	$showguide = false;
} else {
	$flag = C::t('home_follow')->fetch_status_by_uid_followuid($_G['uid'], $uid);
}
$showrecommend = true;
$archiver = $primary = 1;
$followerlist = array();
$space['bio'] = cutstr($space['bio'], 200);
$lastviewtime = 0;
if($do == 'follower') {
	$count = C::t('home_follow')->count_follow_user($uid, 1);
	if($viewself && !empty($_G['member']['newprompt_num']['follower'])) {
		$newfollower = C::t('home_notification')->fetch_all_by_uid($uid, -1, 'follower', 0, $_G['member']['newprompt_num']['follower']);
		$newfollower_list = array();
		foreach($newfollower as $val) {
			$newfollower_list[] = $val['from_id'];
		}
		C::t('home_notification')->delete_by_type('follower', $_G['uid']);
		helper_notification::update_newprompt($_G['uid'], 'follower');
	}
	if($count) {
		$list = C::t('home_follow')->fetch_all_follower_by_uid($uid, $start, $perpage);
	}
	if(helper_access::check_module('follow')) {
		$followerlist = C::t('home_follow')->fetch_all_following_by_uid($uid, 0, 9);
	}
} elseif($do == 'following') {
	$count = C::t('home_follow')->count_follow_user($uid);
	if($count) {
		$status = $_GET['status'] ? 1 : 0;
		$list = C::t('home_follow')->fetch_all_following_by_uid($uid, $status, $start, $perpage);
	}
	if(helper_access::check_module('follow')) {
		$followerlist = C::t('home_follow')->fetch_all_follower_by_uid($uid, 9);
	}
}

if(($do == 'follower' || $do == 'following') && $list) {
	$uids = array_keys($list);
	$fieldhome = C::t('common_member_field_home')->fetch_all($uids);
	foreach($fieldhome as $fuid => $val) {
		$list[$fuid]['recentnote'] = $val['recentnote'];
	}
	$memberinfo = C::t('common_member_count')->fetch_all($uids);
	$memberprofile = C::t('common_member_profile')->fetch_all($uids);

	if(!$viewself) {
		$myfollow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $uids);
		foreach($uids as $muid) {
			$list[$muid]['mutual'] = 0;
			if(!empty($myfollow[$muid])) {
				$list[$muid]['mutual'] = $myfollow[$muid]['mutual'] ? 1 : -1;
			}
		}
	}
	$specialfollow = C::t('home_follow')->fetch_all_following_by_uid($uid, 1, 10);
}

if($viewself) {
	if(!isset($_G['cache']['forums'])) {
		loadcache('forums');
	}
	$fields = C::t('forum_forumfield')->fetch_all_by_fid(array_keys($_G['cache']['forums']));
	foreach($fields as $fid => $field) {
		if(!empty($field['threadsorts'])) {
			unset($_G['cache']['forums'][$fid]);
		}
	}
	require_once libfile('function/forumlist');
	$forumlist = forumselect();
	$defaultforum = $_G['setting']['followforumid'] ? $_G['cache']['forums'][$_G['setting']['followforumid']] : array();
	require_once libfile('function/upload');
	$swfconfig = getuploadconfig($_G['uid']);
}

$navtitle = $do == "following" ? $Plang['following'] : $Plang['follower'];
$metakeywords = $navtitle;
$metadescription = $navtitle;
$navtitle = helper_seo::get_title_page($navtitle, $_G['page']);
include_once template('wq_buluo:tpl_buluo_follow');

?>