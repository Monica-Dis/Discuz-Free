<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$perpage = 10;
if($setting['page_num']) {
	$perpage = intval($setting['page_num']);
}
$tid = intval(getgpc('tid'));
$type = trim(dhtmlspecialchars($_GET['type']));
$view = intval(max(1, $setting['click_num']));

if($tid > 0) {
	$sql = ' AND tid<' . $tid;
}

if($type == 'hot') {
	$views = ' AND views >= ' . $view;
	$order = " ORDER BY views DESC";
} else {
	$order = " ORDER BY tid DESC";
}
loadcache('stamps');
$followforumid = getglobal('setting/followforumid');
if($_G['uid']) {

	$groupuser = DB::fetch_all("SELECT fid FROM " . DB::table('forum_groupuser') . " WHERE uid=%n AND level>0", array($_G['uid']));
	foreach($groupuser as $key => $value) {
		$fid[] = intval($value['fid']);
	}
	$follow = DB::fetch_all("SELECT followuid FROM " . DB::table('home_follow') . " WHERE uid=%d", array($_G['uid']));
	$uid[] = $_G['uid'];
	foreach($follow as $key => $value) {
		$uid[] = intval($value['followuid']);
	}
	if($_G['mobile']) {
		$forward = ' OR (authorid=' . $_G['uid'] . ' AND comments>0 AND isgroup=1)';
	}

	$threads = DB::fetch_all("SELECT * FROM " . DB::table('forum_thread')
			. " WHERE ((fid IN(%n) OR (authorid IN(%n) AND isgroup=%d)" . $forward . ")) AND closed=%d AND author is not null AND displayorder>=0"
			. $sql . $views . $order . " LIMIT " . $perpage, array($fid, $uid, 1, 0), 'tid');
	$fids = array();
	foreach($threads as $key => $value) {
		$fids[] = $value['fid'];
	}
	$forum_forumfield = C::t('forum_forumfield')->fetch_all($fids);
	foreach($threads as $key => $value) {
		$threads[$key]['founderuid'] = $forum_forumfield[$value['fid']]['founderuid'];
	}
} else {

	$notinfid = wq_buluo_getall_gviewperm_fid();
	$threads = DB::fetch_all("SELECT * FROM " . DB::table('forum_thread')
			. " WHERE isgroup=%d AND closed=%d AND displayorder>=0 AND fid NOT IN(%n)"
			. $sql . $views . $order . " LIMIT " . $perpage, array(1, 0, $notinfid), 'tid');
}


$forumlastvisit = 0;
$count = count($threads);
$count == $perpage ? $count ++ : '';
if($threads) {
	foreach($threads as $key => $value) {

		if($value['fid'] == $followforumid) {
			$forwardids[] = $value['maxposition'];
			$forward_tids[] = $value['comments'];
			$threads[$key]['tid'] = $value['comments'];
		}
		$tids[] = $threads[$key]['tid'];

		$value['allreplies'] = $value['replies'] + $value['comments'];
		$value['moved'] = $value['heatlevel'] = $value['new'] = 0;
		if($value['closed'] == 1) {
			$value['folder'] = 'lock';
		} else {
			$value['folder'] = 'common';
			$value['weeknew'] = TIMESTAMP - 604800 <= $value['dbdateline'];
			if($value['allreplies'] > $value['views']) {
				$value['views'] = $value['allreplies'];
			}
			if($_G['setting']['heatthread']['iconlevels']) {
				foreach($_G['setting']['heatthread']['iconlevels'] as $k => $i) {
					if($value['heats'] > $i) {
						$value['heatlevel'] = $k + 1;
						break;
					}
				}
			}
		}
		$value['dbdateline'] = $value['dateline'];
		$value['dateline'] = dgmdate($value['dateline'], 'u', '9999', getglobal('setting/dateformat'));
		$value['dblastpost'] = $value['lastpost'];
		$value['lastpost'] = dgmdate($value['lastpost'], 'u');

		if($value['folder'] == 'common' && $value['dblastpost'] >= $forumlastvisit || !$forumlastvisit) {
			$value['new'] = 1;
			$value['folder'] = 'new';
			$value['weeknew'] = TIMESTAMP - 604800 <= $value['dbdateline'];
		}
		$threads[$key] = $value;
	}
}

if($tids) {
	$info = wq_buluo_get_forum_post_data($tids, true);
}
if($forwardids) {
	if(defined('IN_MOBILE')) {

		$forward_info = wq_buluo_get_forum_post_first($forwardids);
	} else {
		$forward_info = DB::fetch_all("SELECT tid,views,replies,author FROM " . DB::table('forum_thread') . " "
				. "  WHERE tid IN(%n)", array($forward_tids), 'tid');
	}
}

$navtitle = $Plang['title_index'];
if($_G['mobile']) {
	if($setting['listsytle'] == 1) {
		include_once template('wq_buluo:tpl_buluo_index1');
	} elseif($setting['listsytle'] == 2) {
		include_once template('wq_buluo:tpl_buluo_index');
	}
} else {
	include_once template('wq_buluo:tpl_buluo_index');
}
//From: Dism_taobao-com
?>