<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['isgroupuser'] <= 0 && empty($_G['forum']['ismoderator'])) {
	showmessage($Plang['66cf5c0e101654c5']);
}
if(submitcheck('forwardsubmit')) {
	$message = isset($_GET['message']) ? dhtmlspecialchars(trim($_GET['message'])) : '';

	$fid = intval($_G['setting']['followforumid']);
	if(!($fid && C::t('forum_forum')->fetch($fid))) {
		$fid = 0;
	}
	if(!$fid) {

		$gid = C::t('forum_forum')->fetch_fid_by_name(lang('spacecp', 'follow_specified_group'));
		if(!$gid) {
			$gid = C::t('forum_forum')->insert(array('type' => 'group', 'name' => lang('spacecp', 'follow_specified_group'), 'status' => 0), true);
			C::t('forum_forumfield')->insert(array('fid' => $gid));
		}
		$forumarr = array(
			'fup' => $gid,
			'type' => 'forum',
			'name' => lang('spacecp', 'follow_specified_forum'),
			'status' => 1,
			'allowsmilies' => 1,
			'allowbbcode' => 1,
			'allowimgcode' => 1
		);
		$fid = C::t('forum_forum')->insert($forumarr, true);
		C::t('forum_forumfield')->insert(array('fid' => $fid));
		C::t('common_setting')->update('followforumid', $fid);
		include libfile('function/cache');
		updatecache('setting');
	}

	$newthread = array(
		'fid' => $fid,
		'typeid' => 0,
		'author' => $_G['username'],
		'authorid' => $_G['uid'],
		'subject' => '',
		'dateline' => intval($_G['timestamp']),
		'lastpost' => intval($_G['timestamp']),
		'lastposter' => $_G['username'],
		'displayorder' => 0,
		'isgroup' => 1,
		'comments' => $_G['tid'],
		'status' => 0,
	);
	$threadid = C::t('forum_thread')->insert($newthread, true);

	$pid = insertpost(array(
		'fid' => getglobal('setting/followforumid'),
		'tid' => $threadid,
		'first' => 1,
		'author' => $_G['username'],
		'authorid' => $_G['uid'],
		'dateline' => $_G['timestamp'],
		'message' => $message,
		'useip' => $_G['clientip'],
	));
	C::t('forum_thread')->update($threadid, array('maxposition' => $pid));

	$groupthread_extinfo = C::t('#wq_buluo#wq_buluo_groupthread_extinfo')->fetch($_G['tid']);
	$forwardnum = intval($groupthread_extinfo['forwardnum']) >= 1 ? intval($groupthread_extinfo['forwardnum']) + 1 : 1;
	if($_G['uid'] != $_G['thread']['authorid']) {
		$experience = 0;
		if($forwardnum >= 1 && $forwardnum <= 10) {
			$experience = 3 + intval(($forwardnum - 1) / 9 * 3);
		} elseif($forwardnum >= 11 && $forwardnum <= 50) {
			$experience = 6 + intval(($forwardnum - 11) / 39 * 24);
		} elseif($forwardnum >= 51 && $forwardnum <= 100) {
			$experience = 30 + intval(($forwardnum - 51) / 49 * 30);
		} else {
			$experience = 60 + ($forwardnum - 100);
		}
		groupuser_extinfo_update($experience, $_G['fid'], $_G['thread']['authorid'], $_G['thread']['author']);
	}
	$groupuser_extinfo = C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($_G['uid'], $_G['fid']);
	$num = intval($groupuser_extinfo['forwardnum']) >= 1 ? intval($groupuser_extinfo['forwardnum']) + 1 : 1;
	$experience = 0;
	if($num == 1) {
		$experience = 3;
	} elseif($num >= 2 && $num <= 5) {
		$experience = 6;
	} elseif($num >= 6 && $num <= 9) {
		$experience = 9;
	} else {
		$experience = 12;
	}
	if($groupuser_extinfo) {
		C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->update_for_user($_G['uid'], $_G['fid'], array('experience' => $groupuser_extinfo['experience'] + $experience, 'forwardnum' => $num));
	} else {
		C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->insert(array('experience' => $experience, 'uid' => $_G['uid'], 'username' => $_G['username'], 'fid' => $_G['fid'], 'forwardnum' => 1));
	}
	if($groupthread_extinfo) {
		C::t('#wq_buluo#wq_buluo_groupthread_extinfo')->update($_G['tid'], array('forwardnum' => $forwardnum));
	} else {
		C::t('#wq_buluo#wq_buluo_groupthread_extinfo')->insert(array('tid' => $_G['tid'], 'forwardnum' => 1));
	}

	C::t('#wq_buluo#wq_buluo_stat')->updatestat($_G['fid'], "activenum", 1, true);
	showmessage($Plang['f1de9403c250da11']);
} else {
	$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['tid']);
	$post['message'] = preg_replace("/\[attach\](\d+)\[\/attach\]/i", '', $post['message']);
	$post['message'] = preg_replace("/\[attachimg\](\d+)\[\/attachimg\]/i", '', $post['message']);
	$post['message'] = preg_replace("/\[flash\](\w+)\[\/flash\]/i", '', $post['message']);
	$post['message'] = preg_replace("/\[media\](\w+)\[\/media\]/i", '', $post['message']);
	$maximage = C::t('forum_attachment_n')->fetch_max_image("pid:" . $post['pid'], "pid", $post['pid']);
	$dw = 75;
	$dh = 75;
	if($maximage) {
		$image = sprintf("forum.php?mod=image&aid=%s&size=%sx%s&key=%s", $maximage['aid'], $dw, $dh, dsign($maximage['aid'] . '|' . $dw . '|' . $dh));
	}
	include_once template('wq_buluo:tpl_buluo_forward');
}
//From: Dism_taobao-com
?>