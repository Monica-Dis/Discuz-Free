<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_albums.php 2016-2-26 9:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['ac'] == 'del_forward') {
	$tid = intval($_GET['tid']);
	$thread = C::t('forum_thread')->fetch($tid);
	$followforumid = getglobal('setting/followforumid');
	if($thread['authorid'] == $_G['uid'] && $thread['fid'] == $followforumid && $thread['isgroup'] == 1) {
		C::t('forum_thread')->delete($thread['tid']);
		C::t('#wq_buluo#wq_buluo_groupthread_extinfo')->update_forwardnum_by_tid($thread['comments'], -1);
		showmessage($Plang['8987fdbb54a9953a'], 'plugin.php?id=wq_buluo', array('tid' => $tid));
	} else {
		showmessage($Plang['88e36e52da88ca7d']);
	}
} elseif($_GET['ac'] == 'deletethread') {
	$tid = intval($_GET['tid']);
	$thread = C::t('forum_thread')->fetch($tid);
	if($thread['authorid'] == $_G['uid']) {
		include_once libfile('function/delete');
		deletethread(array($tid));

		showmessage($Plang['8987fdbb54a9953a'], 'plugin.php?id=wq_buluo', array('tid' => $tid));
	} else {
		showmessage($Plang['18586857c3714026']);
	}
} elseif($_GET['ac'] == 'statlist') {


	$fid = intval($_GET['fid']);
	$num = count_group_statdata_by_fid($fid);

	$perpage = 5;
	$page = max(1, $_GET['page']);
	$start = ($page - 1) * $perpage;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 1;

	$statdatalist = get_group_statdata_by_fid_type($fid, $type, $start, $perpage);

	$mpurl = "plugin.php?id=wq_buluo&mod=ajax&ac=statlist&fid=" . $fid . "&type=" . $type . "&page=" . $page;
	$multi = multi($num, $perpage, $page, $mpurl);

	$multi = str_replace('href=', 'onclick="load_statlist(' . $type . ',this.href);return false;" href=', $multi);

	include_once template('wq_buluo:tpl_buluo_data_statlist');
} elseif($_GET['ac'] == 'recommendadd' || $_GET['ac'] == 'favorite') {
	$wqtype = dhtmlspecialchars($_GET['ac']);
	wq_buluo_cache_recommend_or_favorite_info($wqtype);
}
//From: Dism_taobao-com
?>