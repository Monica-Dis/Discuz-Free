<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_albums.php 2016-2-26 9:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$fid = intval($_GET['fid']);
$type = intval($_GET['type']);
$ac = trim($_GET['ac']);
$datetype = intval($_GET['datetype']);
$fieldval = trim($_GET['fieldval']);


if($datetype == '1') {
	$datenum = intval($_GET['datenum']);
	$start = 0 - $datenum;
	$starttime = get_date_strortime($start, 1);
	$endtime = get_date_strortime(-1, 1);
} elseif($datetype == '2') {
	$starttime = strtotime(trim($_GET['starttime']));
	$endtime = strtotime(trim($_GET['endtime']));
}

if(empty($ac)) {

	$title = $Plang[$fieldval];

	$dataforchart = get_data_by_fid_field_date($fid, $fieldval, $starttime, $endtime);

	include_once template('wq_buluo:tpl_buluo_chart');
} else {
	$dataforchart = get_group_statdata_by_fid_type_date($fid, $type, $starttime, $endtime);

	if($type == '1') {
		$list = explode(",", "date,newfollow,unfollow,todayfollow");
	} else {
		$list = explode(",", "date,pv,uv,signnum,activenum,threadnum");
	}

	$title = '';
	foreach($list as $value) {
		$title .= $Plang[$value] . ",";
	}

	$detail = '';
	foreach($dataforchart as $chart) {
		foreach($chart as $key => $value) {
			if(in_array($key, array('datefid', 'dateline'))) {
				continue;
			}
			$value = preg_replace('/\s+/', ' ', $value);
			$detail .= strlen($value) > 11 && is_numeric($value) ? '[' . $value . '],' : $value . ',';
		}
		$detail = $detail . "\n";
	}
	$detail = rtrim($title, ",") . "\n" . $detail;

	$filename = date('Ymd', TIMESTAMP) . '.csv';

	ob_end_clean();
	header('Content-Encoding: none');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename=' . $filename);
	header('Pragma: no-cache');
	header('Expires: 0');
	if($_G['charset'] != 'gbk') {
		$detail = diconv($detail, $_G['charset'], 'GBK');
	}
	echo $detail;
	exit();
}
//From: Dism_taobao-com
?>