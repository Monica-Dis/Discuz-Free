<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$space = getuserbyuid($_G['uid'], 1);
if($space) {
	if($space['status'] == -1 && $_G['adminid'] != 1) {
		showmessage('space_has_been_locked');
	}
	$groupviewed = getcookie('wqgroupviewed');
	$groupviewed = $groupviewed ? explode(',', $groupviewed) : array();
	if($_GET['aciton'] == 'del' && $_GET['fid']) {
		foreach($groupviewed as $key => $value) {
			if($value != $_GET['fid']) {
				$wq_groupviewed[] = $value;
			}
		}
		dsetcookie('wqgroupviewed', implode(',', $wq_groupviewed), 86400);
		echo $_GET['fid'];
		exit;
	} elseif($_GET['aciton'] == 'empty') {
		dsetcookie('wqgroupviewed', '', 86400);
		echo '1';
		exit;
	}
	space_merge($space, 'count');
	$groupuser_extinfo = C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_all_by_uid($_G['uid']);

	$group_count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('forum_groupuser') . "  WHERE uid=%d", array($space['uid']));
	if($groupviewed) {
		$group = DB::fetch_all("SELECT name,fid FROM " . DB::table('forum_forum') . " WHERE fid IN(%n) ", array($groupviewed), 'fid');
	}
} else {
	showmessage('space_does_not_exist');
}

$navtitle = $Plang['title_user'];
include_once template('wq_buluo:tpl_buluo_user');

?>