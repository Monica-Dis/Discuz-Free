<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['forum']['founderuid'] != $_G['uid']) {
	$groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);
	if(!$groupuser || $groupuser['level'] == 0) {
		showmessage($Plang['e9f4cf336b4f638f']);
	}
}
$groupuser_extinfo = C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($_G['uid'], $_G['fid']);
loadcache('wq_buluo_level');
$wq_buluo_level = $_G['cache']['wq_buluo_level'] ? $_G['cache']['wq_buluo_level'] : wq_buluo_levels();
$wq_buluo_group_extinfo = C::t('#wq_buluo#wq_buluo_group_extinfo')->fetch($_G['fid']);
$wq_reset = reset($wq_buluo_level['style']);
$lid = $wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] ? $wq_buluo_group_extinfo['lid'] : ($wq_reset ? $wq_reset['lid'] : 0);
$experience = $groupuser_extinfo['experience'] ? $groupuser_extinfo['experience'] : 0;
$wq_levelclass = $wq_buluo_level['level'][$wq_level]['class'] ? $wq_buluo_level['level'][$wq_level]['class'] : 1;
eval($wq_buluo_level['php']);
include_once template('wq_buluo:tpl_buluo_level');

?>