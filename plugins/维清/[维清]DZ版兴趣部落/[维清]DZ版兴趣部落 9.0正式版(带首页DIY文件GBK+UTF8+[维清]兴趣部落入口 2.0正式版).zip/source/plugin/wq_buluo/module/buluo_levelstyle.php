<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_celebrity.php 2016-2-29 00:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('wq_buluo_level');
$wq_buluo_level = $_G['cache']['wq_buluo_level'] ? $_G['cache']['wq_buluo_level'] : wq_buluo_levels();
$wq_buluo_group_extinfo = C::t('#wq_buluo#wq_buluo_group_extinfo')->fetch($_GET['fid']);
if(submitcheck('levelsubmit')) {

	if(!$_GET['lid'] || $wq_buluo_level['style'][$_GET['lid']]['type'] === '1') {
		foreach($wq_buluo_level['level'] as $key => $value) {
			$levelname = dhtmlspecialchars(trim($_GET['level'][$key]));
			$levelname ? $style['content'][$key] = $levelname : showmessage($Plang['d6adecdc4ab71ce6']);
		}
		$style['type'] = '1';
		$style['name'] = '0';
		$style['displayorder'] = '0';
		$style['status'] = '1';
		if($wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']]['type'] == 1) {
			$style['lid'] = $wq_buluo_group_extinfo['lid'];
			$wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] = $style;
			$style['content'] = serialize($style['content']);
			C::t('#wq_buluo#wq_buluo_levelstyle')->update($wq_buluo_group_extinfo['lid'], $style);
		} else {
			$addstyle = $style;
			$addstyle['content'] = serialize($addstyle['content']);
			$style['lid'] = C::t('#wq_buluo#wq_buluo_levelstyle')->insert($addstyle, true);
			if($wq_buluo_group_extinfo['fid']) {
				C::t('#wq_buluo#wq_buluo_group_extinfo')->update($wq_buluo_group_extinfo['fid'], array('lid' => $style['lid']));
			} else {
				C::t('#wq_buluo#wq_buluo_group_extinfo')->insert(array('fid' => $_GET['fid'], 'lid' => $style['lid']));
			}
			$wq_buluo_level['style'][$style['lid']] = $style;
		}
		savecache('wq_buluo_level', $wq_buluo_level);
		showmessage($Plang['45tcdffc8ac7f983'], 'forum.php?mod=group&action=manage&suboperation=levelstyle&fid=' . $_GET['fid'], array(), array('showmsg' => '1', 'closetime' => 2));
	} elseif($wq_buluo_level['style'][$_GET['lid']]['type'] === '0') {
		$k = 0;
		if($wq_buluo_group_extinfo['fid']) {
			if($wq_buluo_group_extinfo['lid'] != $_GET['lid']) {

				C::t('#wq_buluo#wq_buluo_group_extinfo')->update($wq_buluo_group_extinfo['fid'], array('lid' => $_GET['lid']));
				if($wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']]['type'] == 1) {

					unset($wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']]);
					savecache('wq_buluo_level', $wq_buluo_level);

					C::t('#wq_buluo#wq_buluo_levelstyle')->delete($wq_buluo_group_extinfo['lid']);
				}
				$k ++;
			}
		} else {
			C::t('#wq_buluo#wq_buluo_group_extinfo')->insert(array('fid' => $_GET['fid'], 'lid' => $_GET['lid']));
			$k ++;
		}

		showmessage($Plang['45tcdffc8ac7f983'], 'forum.php?mod=group&action=manage&suboperation=levelstyle&fid=' . $_GET['fid'], $k ? array('lid' => $_GET['lid']) : array(), array('showmsg' => '1', 'closetime' => 2));
	} else {
		showmessage($Plang['yuccyd5328c7f983']);
	}
} else {
	$wq_reset = reset($wq_buluo_level['style']);
	$lid = $wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] ? $wq_buluo_group_extinfo['lid'] : ($wq_reset ? $wq_reset['lid'] : 0);

	include_once template('wq_buluo:tpl_buluo_levelstyle');
}
//From: Dism_taobao-com
?>