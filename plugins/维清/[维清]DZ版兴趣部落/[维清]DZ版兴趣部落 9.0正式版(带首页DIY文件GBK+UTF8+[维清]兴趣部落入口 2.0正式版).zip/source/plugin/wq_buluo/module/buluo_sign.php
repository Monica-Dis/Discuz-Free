<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo_card.php 2016-2-26 9:26:46Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['forum']['founderuid'] != $_G['uid']) {
	$groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);
	if($groupuser) {
		if($groupuser['level'] == 0) {
			showmessage($Plang['e9f4cf336b4f638f']);
		}
	} else {
		showmessage($Plang['29a53d9cce2956b8']);
	}
}
$wq_time = strtotime(date('Y-m-d'));
$groupuser_extinfo = C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($_G['uid'], $_G['fid']);

if($groupuser_extinfo['lastsign'] != $wq_time) {

	$experience = $signdays = 1;
	if($groupuser_extinfo) {
		if($wq_time - 24 * 60 * 60 == $groupuser_extinfo['lastsign']) {
			$signdays = $groupuser_extinfo['signdays'] + $signdays;
			if($signdays >= 2 && $signdays <= 29) {
				$experience = 6;
			} elseif($signdays >= 30) {
				$experience = 8;
			}
		}
		$data = array(
			'experience' => $experience + intval($groupuser_extinfo['experience']),
			'lastsign' => $wq_time,
			'signdays' => $signdays,
		);
		C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->update_for_user($_G['uid'], $_G['fid'], $data);
	} else {
		$data = array(
			'experience' => $experience,
			'lastsign' => $wq_time,
			'signdays' => $signdays,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'fid' => $_G['fid'],
		);
		C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->insert($data);
	}
	$wq_buluo_group_extinfo = C::t('#wq_buluo#wq_buluo_group_extinfo')->fetch($_G['fid']);
	$wq_reset = reset($wq_buluo_level['style']);
	$lid = $wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] ? $wq_buluo_group_extinfo['lid'] : ($wq_reset ? $wq_reset['lid'] : 0);
	eval($wq_buluo_level['php']);
	$wq_levelclass = $wq_buluo_level['level'][$wq_level]['class'] ? $wq_buluo_level['level'][$wq_level]['class'] : 1;
	$datalog = array(
		'experience' => $experience,
		'dateline' => TIMESTAMP,
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'fid' => $_G['fid'],
	);
	C::t('#wq_buluo#wq_buluo_signlog')->insert($datalog);

	C::t('#wq_buluo#wq_buluo_stat')->updatestat($_G['fid'], 'signnum');

	C::t('#wq_buluo#wq_buluo_stat')->updatestat($_G['fid'], "activenum", 1, true);
	$wq_sign = 1;
} else {
	$signdays = $groupuser_extinfo['signdays'];
	$experience = 1;
	if($signdays >= 2 && $signdays <= 29) {
		$experience = 6;
	} elseif($signdays >= 30) {
		$experience = 8;
	}
}
if(defined('IN_MOBILE')) {

	include_once template('wq_buluo:tpl_buluo_sign');
} else {
	if($wq_sign) {
		$extrajs = '<script reload="1" type="text/javascript">wqjq("#sign_btn").html(\'<a href="javascript:;">' . $Plang['a08b091b9ce4c933'] . '</a>\');wqjq("#sign_num").text("' . $signdays . '");</script>';
		showmessage($Plang['signed'], 'forum.php?mod=group&fid=' . $_G['fid'], array('signdays' => $signdays), array('msgtype' => 2, 'showmsg' => '1', 'closetime' => '2', 'extrajs' => $extrajs, 'alert' => 'right', 'handle' => true));
	} else {

		showmessage($Plang['17a0a69deadb056e'], '', array(), array('showmsg' => '1', 'closetime' => 2));
	}
}
//From: Dism_taobao-com
?>