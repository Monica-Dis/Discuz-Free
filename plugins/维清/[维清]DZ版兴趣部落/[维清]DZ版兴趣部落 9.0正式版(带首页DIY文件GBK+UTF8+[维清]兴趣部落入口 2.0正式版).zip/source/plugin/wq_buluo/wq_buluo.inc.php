<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_buluo.inc.php 2016-1-15 04:24:09Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET['id'] = "wq_buluo:wq_buluo";
include_once DISCUZ_ROOT . './source/plugin/wq_buluo/config/config.php';

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "index";

$allowmod = array('rank', 'ajax', 'card', 'albums', 'forward', 'user', 'level', 'follow', 'celebrity', 'qrcode', 'levelstyle', 'sign', 'index', 'manage', 'chart', 'join');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

if(in_array($mod, array('sign', 'levelstyle', 'follow', 'user', 'level', 'forward', 'ajax'))) {
	empty($_G['uid']) ? showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1)) : '';
}

if(in_array($mod, array('rank', 'qrcode', 'sign', 'level', 'forward', 'chart')) || ($mod == 'ajax' && $_GET['ac'] == 'statlist')) {
	require './source/function/function_forum.php';
	loadforum();
	if($_G['forum']['status'] != 3 || $_G['forum']['type'] != 'sub') {
		showmessage('forum_not_group', 'group.php');
	} elseif($_G['forum']['level'] == -1) {
		showmessage('group_verify', '', array(), array('alert' => 'info'));
	} elseif($_G['forum']['jointype'] < 0 && !$_G['forum']['ismoderator']) {
		showmessage('forum_group_status_off', 'group.php');
	}
}

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_buluo/' . $dirlist[$mod] . '/buluo_' . $mod . '.php';

?>