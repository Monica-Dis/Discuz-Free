<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_sample.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_group_extinfo extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_group_extinfo';
		$this->_pk = 'fid';
		parent::__construct();
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ", array($this->_table), $this->_pk);
	}

}
//From: Dism_taobao-com
?>