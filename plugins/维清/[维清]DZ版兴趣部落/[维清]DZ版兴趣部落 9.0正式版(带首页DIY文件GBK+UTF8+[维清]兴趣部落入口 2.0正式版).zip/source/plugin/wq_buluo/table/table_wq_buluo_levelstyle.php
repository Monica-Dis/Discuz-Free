<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_sample.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_levelstyle extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_levelstyle';
		$this->_pk = 'lid';
		parent::__construct();
	}

	public function fetch_all_by_type($type = '') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($type !== '') {
			$sql[] = 'type=%d';
			$val[] = $type;
		}
		$order = ' ORDER BY displayorder ASC ';
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function fetch_all() {
		$order = ' ORDER BY displayorder ASC';
		return DB::fetch_all("SELECT * FROM %t " . $order, array($this->_table), $this->_pk);
	}

}
//From: Dism_taobao-com
?>