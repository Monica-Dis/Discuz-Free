<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_sample.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_groupuser_extinfo extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_groupuser_extinfo';
		$this->_pk = '';
		parent::__construct();
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ", array($this->_table));
	}

	public function fetch_all_by_uid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid), 'fid');
	}

	public function fetch_first_by_uid_fid($uid, $fid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND fid=%d", array($this->_table, $uid, $fid));
	}

	public function fetch_all_by_fid($fid) {
		return DB::fetch_all("SELECT * FROM %t WHERE fid=%d", array($this->_table, $fid), 'uid');
	}

	public function update_for_user($uid, $fid, $data) {
		DB::update($this->_table, $data, array('uid' => $uid, 'fid' => $fid));
	}

}
//From: Dism_taobao-com
?>