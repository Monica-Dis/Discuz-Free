<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_statuser.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_statuser extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_statuser';
		$this->_pk = 'datefid';
		parent::__construct();
	}

	public function check_exists($uid, $datefid, $type) {

		$setarr = array(
			'datefid' => $datefid,
			'uid' => intval($uid),
			'type' => $type,
		);
		if(DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . ' WHERE ' . DB::implode_field_value($setarr, ' AND '))) {
			return true;
		} else {
			return false;
		}
	}

	public function clear_by_date($date) {
		$date = intval($date);
		DB::delete('wq_buluo_statuser', "`date` != '$date'");
	}

}
//From: Dism_taobao-com
?>