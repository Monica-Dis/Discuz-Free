<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_sample.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_groupthread_extinfo extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_groupthread_extinfo';
		$this->_pk = 'tid';
		parent::__construct();
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ", array($this->_table), $this->_pk);
	}

	public function update_forwardnum_by_tid($tid, $forwardnum) {
		return DB::query('UPDATE %t SET forwardnum=forwardnum+\'%d\' WHERE tid=%d', array($this->_table, $forwardnum, $tid));
	}

}
//From: Dism_taobao-com
?>