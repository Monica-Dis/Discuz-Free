<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_buluo_stat.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_buluo_stat extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_buluo_stat';
		$this->_pk = 'datefid';
		parent::__construct();
	}

	public function updatestat($fid, $type, $num = 1, $primary = false) {
		global $_G;

		if(intval($fid) <= 0) {
			return;
		}
		$nowdaytime = dgmdate(TIMESTAMP, 'Ymd');
		$type = addslashes($type);
		$datefid = $nowdaytime . intval($fid);

		if($primary) {
			$setarr = array(
				'datefid' => $datefid,
				'uid' => intval($_G['uid']),
				'date' => $nowdaytime,
				'type' => $type,
			);
			if(C::t('#wq_buluo#wq_buluo_statuser')->check_exists($_G['uid'], $datefid, $type)) {
				return false;
			} else {
				C::t('#wq_buluo#wq_buluo_statuser')->insert($setarr);
			}
		}

		$num = abs(intval($num));
		if(DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . " WHERE `datefid` = '$datefid'")) {
			if($type == 'todayfollow') {
				DB::query('UPDATE ' . DB::table($this->_table) . " SET `$type`= $num WHERE `datefid` = '$datefid'");
			} else {
				DB::query('UPDATE ' . DB::table($this->_table) . " SET `$type`=`$type`+$num WHERE `datefid` = '$datefid'");
			}
		} else {
			C::t('#wq_buluo#wq_buluo_statuser')->clear_by_date($nowdaytime);
			DB::insert($this->_table, array('datefid' => $datefid, 'date' => $nowdaytime, 'dateline' => strtotime(date("Y-m-d")), 'fid' => $fid, $type => $num));
		}
	}

	public function fetch_first_by_fid_date($fid, $date) {
		return DB::fetch_first("SELECT * FROM %t WHERE fid = %d AND date = %d", array($this->_table, $fid, $date));
	}

	public function fetch_all_by_fid_type($fid, $type = 1, $start = 0, $limit = 10) {
		$dateline = strtotime(date("Y-m-d")) + 1;
		if($type == 1) {
			return DB::fetch_all('SELECT datefid,date,dateline,newfollow,unfollow,todayfollow FROM %t WHERE fid=%d AND dateline < %d ORDER BY date DESC ' . DB::limit($start, $limit), array($this->_table, $fid, $dateline));
		} else {
			return DB::fetch_all('SELECT datefid,date,dateline,pv,uv,signnum,activenum,threadnum FROM %t WHERE fid=%d AND dateline < %d ORDER BY date DESC ' . DB::limit($start, $limit), array($this->_table, $fid, $dateline));
		}
	}

	public function fetch_all_by_fid_type_date($fid, $type, $startdate, $enddate) {
		if($type == 1) {
			return DB::fetch_all('SELECT datefid,date,dateline,newfollow,unfollow,todayfollow FROM %t WHERE fid=%d AND dateline>=%d AND dateline <= %d ORDER BY dateline ASC', array($this->_table, $fid, $startdate, $enddate));
		} else {
			return DB::fetch_all('SELECT datefid,date,dateline,pv,uv,signnum,activenum,threadnum FROM %t WHERE fid=%d AND dateline>=%d AND dateline <= %d ORDER BY dateline ASC ', array($this->_table, $fid, $startdate, $enddate));
		}
	}

	public function count_by_fid($fid) {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE fid=%d', array($this->_table, $fid));
	}

	public function fetch_all_by_fid_field_date($fid, $field, $startdate, $enddate) {
		if(!in_array($field, array('newfollow', 'unfollow', 'todayfollow', 'pv', 'uv', 'signnum', 'activenum', 'threadnum'))) {
			return;
		}
		return DB::fetch_all("SELECT dateline,date," . $field . " FROM %t WHERE fid = %d AND dateline>=%d AND dateline <= %d ORDER BY dateline ASC", array($this->_table, $fid, $startdate, $enddate));
	}

}
//From: Dism_taobao-com
?>