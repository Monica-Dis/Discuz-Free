<?php exit("From: DisM.taobao.com"); ?>
<!--{if !$_GET[api]}-->
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<style>
    .bg{ background:#fff;}
</style>
<div class="qz_bg">
    <!--{/if}-->
    <!--{if $op == 'user'}-->
    <!--{eval $space['residecity'] = $space['residecity'] ? ($wq_touch ? wq_residecity($space['residecity']) : _buluo_wq_residecity($space['residecity'])) : "";}-->
    <!--{eval $num = mt_rand(1,10);$type=wq_rand_card_backgroup($num);}-->
    <div class="card_lump">
        <div class="card_scroll">
            <div class="card_head" style="background-image:url(source/plugin/wq_buluo/static/images/wq_buluobg{$num}.{$type});">
                <div class="card_cover-mask" style="width: 100%; height: 100%; opacity: 0.1; top: 0px; left: 0px; position: absolute; background-color: rgb(0, 0, 0);"></div>
                <div class="card_head-first"></div>
            </div>
            <div class="card_img">
                <div class="card_img_con" style="transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, -0.0075, 0, -45, 0, 1);">
                    <a href="javascript:;" id="head_image"><img src="{avatar($space[uid], middle, true)}"></a>
                </div>
            </div>
            <div class="card_info">
                <div class="card_in_name">
                    <span class="card_in_name_qm">$space[username]</span>
                </div>
                <!--{eval $o=0;}-->
                <!--{block base_data}-->
                <!--{if $age!=''|| $space[gender]}-->
                <span class="card_in_left">
                    <!--{if $space[gender]}-->
                    <!--{if $space[gender]==1}-->
                    <i class="wqiconfont wqicon-contacts group_boy wq_f15"> </i>
                    <!--{else}-->
                    <i class="wqiconfont wqicon-iconfontnv group_gril wq_f15"> </i>
                    <!--{/if}-->
                    <!--{/if}-->
                    {$age}
                    <!--{eval $o++;}-->
                </span>
                <!--{/if}-->
                <!--{if $space['residecity']!=''}-->
                <!--{eval $o++;}-->
                <span class="card_in_right"><i class="wqiconfont wqicon-ditu  wq_f14"></i>$space['residecity']</span>
                <!--{/if}-->
                <!--{/block}-->
                <div class="card_in_sa {if $o>1} card_in_sa_two{/if}">
                    $base_data
                </div>
                <div class="card_in_gz">
                    <div class="card_in_g"><span><a href="plugin.php?id=wq_buluo&mod=follow&do=follower&uid=$space[uid]">{$Plang['bbd702ca1f76841a']} {$space['follower']}</a></span></div>
                    <div class="card_line"></div>
                    <div class="card_in_f"><span><a href="plugin.php?id=wq_buluo&mod=follow&do=following&uid=$space[uid]">{$Plang['2c8a07313e7706bc']} {$space['following']}</a></span></div>
                </div>
                <!--{if $space['sightml']}-->
                <div class="card_in_sm"><i class="wqiconfont wqicon-pilianghuifu wq_f18"></i>$space['sightml']</div>
                <!--{/if}-->
            </div>
            <!--{if $group}-->
            <div class="card_myqz" >
                <div class="card_myqz_head">
                    <div class="card_myqz_wd">
                        <!--{if $space[uid]==$_G[uid]}-->{$Plang['4f3a250602af1e69']}<!--{else}-->{$Plang['f14e1fb7af07cdf0']}<!--{/if}-->{$Plang['d99f1dd07920adb7']}</div><div class="card_border b_bottom"></div>
                </div>
                <div class="card_myqz_items">
                    <!--{loop $group  $key $val}-->
                    <!--{if $key<5}-->
                    <!--{eval isset($val['icon']) && $val['icon'] = get_groupimg($val['icon'], 'icon'); }-->
                    <div class="card_myqz_item">
                        <a href="buluo.php?mod=group&fid=$val[fid]">
                            <div class="card_myqz_pic"><img src="$val['icon']"></div>
                            <div class="card_myqz_name">$val[name]</div>
                        </a>
                    </div>
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{if $group[5]}-->
                <div class="card_more"><a href="plugin.php?id=wq_buluo&mod=card&op=group&uid={$space[uid]}"><span class="card_more-qz">{$Plang['599588d2f03bc772']}</span></a></div>
                <!--{/if}-->
            </div>

            <!--{/if}-->
            <!--{if $thread}-->
            <div class="card_h14"></div>
            <!--{eval $wq_data = $wq_touch ? get_data($thread) : _buluo_get_data($thread);}-->
            <div class="card_myin" style="display: block;">
                <div class="card_myin_head">
                    <div class="card_myin_wd"><!--{if $space[uid]==$_G[uid]}-->{$Plang['4f3a250602af1e69']}<!--{else}-->{$Plang['f14e1fb7af07cdf0']}<!--{/if}-->{$Plang['bd7936723f3e9fdc']}</div>
                    <span class="card_border b_bottom"></span>
                </div>
                <div class="card_myin_themes">
                    <!--{eval $k=0;}-->
                    <!--{loop $thread  $key $val}-->
                    <!--{eval $k++;}-->
                    <!--{if $k<4}-->
                    <!--{eval $images=get_images_by_pid($info[pids][$val[tid]]); }-->
                    <div class="card_myin_theme"  data='$forum_post[$val[tid]][pid]'>
                        <!--{if $val[fid]==$followforumid}-->
                        <a href="buluo.php?mod=viewthread&tid=$val[comments]" >
                            <div class="card_myin_theme_left">
                                <img src="{if $images}$images{else}source/plugin/wq_buluo/static/images/feed-normal-icon.png{/if}"> <span></span>
                            </div>
                            <div class="card_myin_theme_right" style="width: 250px;">
                                <div class="card_myin_theme_right1">{$Plang['264039a24030083f']}  {$forward_info['summarys'][$val['maxposition']]}<!--{if $val[readperm]}-->[{$Plang['88cf57f8dfaa1f04']} {$val[readperm]}]<!--{/if}-->
                                </div>
                                <div class="card_myin_theme_right2"><span>{$Plang['8ea9c932f8444151']}</span><span class="line_theme">|</span><span>$info[subjects][$val[tid]]</span></div>
                            </div>
                        </a>
                        <!--{else}-->
                        <a href="buluo.php?mod=viewthread&tid=$val[tid]" >
                            <div class="card_myin_theme_left">
                                <img src="{if $images}$images{else}source/plugin/wq_buluo/static/images/feed-normal-icon.png{/if}"> <span></span>
                            </div>
                            <div class="card_myin_theme_right" style="width: 250px;">
                                <div class="card_myin_theme_right1">$val[subject]<!--{if $val[readperm]}-->[{$Plang['88cf57f8dfaa1f04']} {$val[readperm]}]<!--{/if}-->
                                </div>
                                <div class="card_myin_theme_right2"><span>$info[fids][$val[tid]]</span><span class="line_theme">|</span><span>{$Plang['a6aa5366e09f370c']}{$val[views]}</span></div>
                            </div>
                        </a>
                        <!--{/if}-->
                    </div>
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{if $k>=4}-->
                <div class="card_more" style="display: block;"><a href="plugin.php?id=wq_buluo&mod=card&op=thread&uid={$space[uid]}"><span class="card_more-tp">{$Plang['daea82445066121a']}</span></a></div>
                <!--{/if}-->
            </div>
            <!--{/if}-->
        </div>
        <!--{if $space['uid'] != $_G['uid']}-->
        <div style="height: 50px;"></div>
        <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $space['uid']);}-->
        <div class="card_footer b_top">
            <div class="card_footer_gz_bl" id="attention_user">
                <!--{if !$follow}-->
                <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid={$space[uid]}&handlekey=add_attention" class="dialog gz_bule notlogged"><i class="wqiconfont wqicon-guanzhu wq_f20"></i>{$Plang['2c8a07313e7706bc']}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid={$space[uid]}&handlekey=cancel_attention" class="dialog notlogged"><i class="wqiconfont wqicon-iconfontfollowok wq_f20"></i>{$Plang['914d2c5341afe66f']}</a>
                <!--{/if}-->
            </div>
            <div class="card_gzline"></div>
            <div class="card_footer_gz_bl">
                <a href="home.php?mod=space&do=pm&subop=view&touid={$space['uid']}#last"><i class="wqiconfont wqicon-liuyan wq_f20"></i>{$Plang['4cc652d2a2685c2d']}</a>
            </div>
        </div>
        <div id="uploading_fullscreen" class="ipagen" style="position: fixed; bottom: 0px; left: 0px; display: none; z-index:1001;">
            <div class="pic_edit top58">
                <div id="clipArea" style=" overflow: hidden; position: relative;">
                    <div class="photo-clip-view photohead_black" style="margin-top: -75px;">
                        <img class="photo-clip-moveLayer" src="{avatar($space[uid], big, true)}">
                    </div>
                </div>
            </div>
        </div>
        <script src="{$_G['style'][styleimgdir]}mobile/upload/iscroll-zoom.js"></script>
        <script>
            $(function() {
                wq_myScroll = false;
                $('#head_image').click(function() {
                    $('#uploading_fullscreen').fadeIn('800');
                    if (!wq_myScroll) {
                        var img = $('.photo-clip-moveLayer');
                        var imgWidth = img.width(), imgHeight = img.height();
                        $('.photo-clip-view').width(imgWidth * .5).height(imgHeight * .5);
                        wq_myScroll = new IScroll('div.photo-clip-view', {
                            freeScroll: true,
                            mouseWheel: true,
                            scrollX: true,
                            scrollY: true,
                            wheelAction: "zoom",
                            zoom: true,
                        });
                        var posX = (imgWidth * .5 - imgWidth) * .5, posY = (imgHeight * .5 - imgHeight) * .5;
                        wq_myScroll.scrollTo(posX, posY);
                    }
                });
                $('#uploading_fullscreen').click(function() {
                    $('#uploading_fullscreen').fadeOut('800');
                });
            })
            function succeedhandle_add_attention(url, msg, param) {
                if ($.trim(msg) == '{$Tlang[581ff9f7c750ca4a]}') {
                    clearInterval(setTimeout_location);
                    $('#attention_user').html('<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid={$space[uid]}&handlekey=cancel_attention" class="dialog"><i class="wqiconfont wqicon-guanzhu wq_f20"></i>{$Tlang[914d2c5341afe66f]}</a>');
                    setTimeout(function() {
                        popup.close();
                    }, '1000');
                }
            }
            function succeedhandle_cancel_attention(url, msg, param) {
                if ($.trim(msg) == '{$Tlang[bef022f6310db3b9]}') {
                    clearInterval(setTimeout_location);
                    $('#attention_user').html('<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid={$space[uid]}&handlekey=add_attention"  class="dialog gz_bule"><i class="wqiconfont wqicon-guanzhu wq_f20"></i>{$Tlang[2c8a07313e7706bc]}</a>');
                    setTimeout(function() {
                        popup.close();
                    }, '1000');
                }
            }
        </script>
        <!--{/if}-->
    </div>
</div>
</div>
<!--{elseif $op == 'group'}-->
<!--{block wq_groups_ul}-->
<!--{loop $group  $key $val}-->
<!--{eval isset($val['icon']) && $val['icon'] = get_groupimg($val['icon'], 'icon'); }-->
<li class="section_p">
    <a href="forum.php?mod=group&fid=$val[fid]">
        <div class="bar_icon_wrap">
            <img class="bar_icon" src="$val['icon']">
        </div>
        <div class="title"><span class="name">$val['name']</span>
            <!--{if $val[level]>0}-->
            <!--{eval $experience=$groupuser_extinfo[$val[fid]][experience]?$groupuser_extinfo[$val[fid]][experience]:0;
                    eval($wq_buluo_level[php]);
            $wq_levelclass= $wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;}-->
            <span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level}</span>
            <!--{/if}-->
        </div>
        <div class="desc f14"><span>{$Plang['cb652d7e9654f645']}{$val[membernum]} {$Plang['8ea9c932f8444151']}{$val[threads]}</span></div>
        <div>
            <!--{if  $val[jointype]==-1}-->
            <span class="btn_focus2">{$Plang['2109f37565c59a62']}</span>
            <!--{else}-->
            <!--{if $uid==$_G['uid']}-->
            <!--{if $val[level]==0}--><span class="btn_focus2">{$Plang['4feb290c5e86a4b8']}</span><!--{/if}-->
            <!--{else}-->
            <!--{if $wq_user[$val[fid]]}-->
            <span class="btn_focus2"><!--{if $wq_user[$val[fid]][level]==0}-->{$Plang['4feb290c5e86a4b8']}<!--{else}-->{$Plang['b4b0d4ba96890702']}<!--{/if}--></span>
            <!--{elseif $val[jointype]!=1}-->
            <button href="forum.php?mod=group&action=join&fid=$val[fid]&handlekey=wq_join" data='$val[fid]' jointype='$val[jointype]'  onclick="wq_join_data(this);" class="btn_focus dialog join_{$val[fid]} notlogged">{$Plang['2c8a07313e7706bc']}</button>
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <p class="group_line"></p>
    </a>
</li>
<!--{/loop}-->
<!--{/block}-->
<!--{if $_GET[api]}-->
$wq_groups_ul
<!--{eval exit;}-->
<!--{/if}-->
<div class="page_group top0">
    <div class="group_right abs">
        <div class="honor_wrapper">
            <!--{if $group}-->
            <ul class="bar_list" id="wq_group_list">$wq_groups_ul</ul>
            <div class="p_load_more" style="display: none">
                <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
                <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
                <!--{else}-->
                <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
                <!--{/if}-->
                {$Tlang['d0a97567aed382e8']}
            </div>
            <div class="loading loading_lh" {if $page * $perpage < $count}style="display: none;"{/if}>{$Plang['b3f7b411f8a25701']}</div>
            <!--{else}-->
            <p class="emp">
                <span class="no_content"><img src="{$_G['style']['styleimgdir']}mobile/images/no_content.png"></span>{$Plang['6495876d9fc179b9']}
            </p>
            <!--{/if}-->
        </div>
    </div>
</div>
<script>
    var join_data, jointype;
    function   wq_join_data(obj) {
        join_data = $(obj).attr('data')
        jointype = $(obj).attr('jointype');
    }
    function succeedhandle_wq_join(url, msg, param) {
        if ($.trim(msg) == "{$Plang['3f043f93b49a94fc']}") {
            clearInterval(setTimeout_location);
            var join_msg = jointype == 2 ? "{$Plang['4feb290c5e86a4b8']}" : "{$Plang['b4b0d4ba96890702']}";
            $('.join_' + join_data).replaceWith("<span class=\"btn_focus2\">" + join_msg + "</span>")
            setTimeout(function() {
                popup.close();
            }, '1000');
        }
    }
    $(function() {
        wq_touch_ajax_scroll('$page', '$count', '$perpage', 'plugin.php?id=wq_buluo&mod=card&op=group&uid={$space[uid]}', 'wq_group_list');
    });
</script>
<!--{elseif $op == 'thread'}-->
<!--{block wq_threads_ul}-->
<!--{loop $threads $key $thread}-->
<!--{eval $thread['dateline'] = dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'));}-->
<!--{if $thread['highlight']}-->
<!--{eval $string = sprintf('%02d', $thread['highlight']);
        $stylestr = sprintf('%03b', $string[0]);
        $thread['highlight'] = ' style="';
        $thread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
        $thread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
        $thread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
        $thread['highlight'] .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]].';' : '';
        $thread['bgcolor']?$thread['highlight'] .= "background-color: $thread[bgcolor];":'';
        $thread['highlight'] .= '"';}-->
<!--{/if}-->
<li data='$thread[tid]'>
    <div class="interest_head" >
        <div class="in_img">
            <!--{if $thread['authorid'] && $thread['author']}-->
            <a href="plugin.php?id=wq_buluo&mod=card&uid={$thread[authorid]}">
                <!--{eval $thread_avatar=avatar($thread[authorid], small, true);}-->
                <img class="wq_js_delayload" data="$thread_avatar"/>
            </a>
            <!--{else}-->
            <a href="javascript:;"><img src="$_G['style'][styleimgdir]/mobile/images/hidden.jpg"/></a>
            <!--{/if}-->
        </div>
        <span class="interest_head_text">
            <span class="interest_head_name">
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a href="plugin.php?id=wq_buluo&mod=card&uid={$thread[authorid]}&do=profile">
                    <font {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if} >{$thread[author]}</font></a>
                <!--{else}-->
                <a href="javascript:;">{$_G[setting][anonymoustext]}</a>
                <!--{/if}-->
            </span>
            <!--{if $info[fids][$thread[tid]]&&$thread[fid]!=$followforumid}-->
            <i class="wqiconfont wqicon-youyou interest_head_icon f12"></i>
            <span class="interest_head_barname"><a href="forum.php?mod=group&fid=$thread[fid]">$info[fids][$thread[tid]]</a></span>
            <!--{/if}-->
        </span>
        <span class="interest_head_time">$thread['dateline']</span>


    </div>
    <!--{if $thread[fid]==$followforumid}-->
    <a href="{if $info[subjects][$thread[tid]]}forum.php?mod=viewthread&tid=$thread[tid]{else}javascript:;{/if}">
        <!--{if $forward_info['summarys'][$thread['maxposition']]}-->
        <div class="interest_content">
            <p>{$forward_info['summarys'][$thread['maxposition']]}</p>
        </div>
        <!--{/if}-->
        <div class="forward_wrap">
            <!--{eval $image=get_images_by_pid($info[pids][$thread[tid]]);}-->
            <!--{if $image}-->
            <div class="forward_img">
                <img style="width:50px; height:50px;margin-left:0px;" src="$image">
            </div>
            <!--{/if}-->
            <div class="forward_title_v2 feed_one_line">
                <!--{if $info[subjects][$thread[tid]]}-->
                $info[subjects][$thread[tid]]
                <!--{else}-->
                &#x8BDD;&#x9898;&#x5DF2;&#x5220;&#x9664;
                <!--{/if}-->
            </div>
        </div>
    </a>
    <!--{else}-->
    <div class="interest_con">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]">
            <div class="interest_content">
                <h3><font $thread[highlight]>{$thread[subject]}</font></h3>
                <p>{$info['summarys'][$thread['tid']]}</p>
            </div>
            <!--{eval $wq_data=wq_buluo_get_images_by_tid_pids($info[pids][$thread[tid]],3,'',$thread['tid']);
                       $wq_data_num=count($wq_data);
            }-->
            <!--{if $wq_data}-->
            <div class="{if $wq_data_num > '2'}interest_img3{elseif $wq_data_num > '1'}interest_img2{else}interest_img1{/if}">
                <!--{loop $wq_data $k $v}-->
                    <div class="img-box wqc_img_box" id="wqc_card_css_{$thread[tid]}_{$k}" num="{$wq_data_num}" datatid="{$thread[tid]}" data="{$k}" dataurl="{$v['image']}">
                       <img data="{$v[image]}" class="wq_js_delayload" id="wqc_css_{$thread[tid]}_{$k}">
                    </div>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
            <div class="interest_info">
                <div class="interest_info_icon" style="line-height: 24px;"><i class="wqiconfont wqicon-liuyan f13"></i>{$thread[replies]}</div>
                <div class="interest_info_icon b_l_border">|</div>
                <div class="interest_info_icon"><i class="wqiconfont wqicon-liulan f14"></i>$thread[views]</div>
            </div>
        </a>
    </div>
    <!--{/if}-->
</li>
<!--{/loop}-->
<!--{/block}-->
<!--{if $_GET[api]}-->
$wq_threads_ul
<!--{eval exit;}-->
<!--{/if}-->
<div id="threadlist" class="tl theme_card" style="position: relative;">
    <div class="forum_dis">
        <!--{if $threads}-->
        <ul id="wq_thread_list">$wq_threads_ul</ul>
        <div class="p_load_more" style="display: none">
            <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
            <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
            <!--{else}-->
            <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
            <!--{/if}-->
            {$Tlang['d0a97567aed382e8']}
        </div>
        <div class="loading" {if $page * $perpage < $count}style="display: none;"{/if}>{$Plang['b3f7b411f8a25701']}</div>
        <!--{else}-->
        <p class="emp">
            <span class="no_content"><img src="{$_G['style']['styleimgdir']}mobile/images/no_content.png"></span>{$Plang['6495876d9fc179b9']}
        </p>
        <!--{/if}-->
    </div>
</div>
<script>
    $(function() {
        wq_touch_ajax_scroll('$page', '$count', '$perpage', 'plugin.php?id=wq_buluo&mod=card&op=thread&uid={$space[uid]}', 'wq_thread_list');
    });
</script>
<!--{/if}-->
</div>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->