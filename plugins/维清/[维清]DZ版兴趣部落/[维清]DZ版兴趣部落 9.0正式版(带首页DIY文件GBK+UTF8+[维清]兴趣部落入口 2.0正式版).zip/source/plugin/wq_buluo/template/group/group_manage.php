<?php exit("From: DisM.taobao.com"); ?>
<style>
    #wp, .wp{ width: 1200px !important;}
</style>
<div id="append_parent"></div><div id="ajaxwaitid"></div>
<!--{eval cache_wq_buluo_last_operating($_G['fid']);}-->
<div class="mod_main cover_warp">
    <!--{eval $wq_groupall = wq_buluo_get_user_group_info();}-->
    <div class="wqpc_switch_aaaaaaaaaa" style="display: none;">
        <h3>{$Tlang[5rtedfgb34grevfd]}<span class="y iconfont wqicon-guanbi wq_grey" id="wqpc_switch_close"></span></h3>
        <div class="wqpc_switch_warp">
            <ul>
                <!--{loop $wq_groupall $key $val}-->
                <li>
                    <a href="buluo.php?mod=group&action=manage&fid=$val[fid]">

                        <img src="<!--{eval echo get_groupimg($val[icon],'icon');}-->" />
                      <div class="wqpc_title">$val[name]</div>
                      <div class="wqpc_tribework">{$Tlang[grkj6wpovds58tr3]}</div>
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <div class="mod_sidebar z">
        <div class="tribename">
            <a href="buluo.php?mod=group&fid=$_G[fid]"><img src="$_G[forum][icon]" />
                <div class="tribe">$_G[forum][name]</div>
            </a>

            <!--{if count($wq_groupall)>1}-->
                <div class="wqpc_switch" id="wqpc_switch_open"><a href="javascript:;">{$Tlang[246grvbhjwoei3r3]}</a></div>
            <!--{/if}-->

            <script>
                wqjq("#wqpc_switch_open").click(function(){
                    if(wqjq(".wqpc_switch_aaaaaaaaaa").css("display")=="none"){
                        wqjq(".wqpc_switch_aaaaaaaaaa").show();
                    }else{
                        wqjq(".wqpc_switch_aaaaaaaaaa").hide();
                    }
                });
                wqjq("#wqpc_switch_close").click(function(){
                    wqjq(".wqpc_switch_aaaaaaaaaa").hide();
                });
            </script>

            <div class="tribework">{$Tlang[11ae101e121a39d0]}
                <!--{if $groupuser[level]==1}-->
                {$Tlang[15e00942fd322f8b]}
                <!--{elseif $groupuser[level]==2}-->
                {$Tlang[8234ab99d3b11df1]}
                <!--{else}-->
                {$Tlang[de762c42e41a7b16]}
                <!--{/if}-->
            </div>
        </div>

        <div class="mod_info">
            <h1 class="wq_grey">{$Tlang[15b8ee3f35fd6477]}</h1>
        </div>

        <div class="mod_info">
            <h3><i class="iconfont wq_f20 wqm_r5">&#xe625;</i><em class="wq_grey">{$Tlang[c1ae0e287c9cf97d]}</em></h3>
            <ul>
                <li {if $_GET['op'] == 'group' && empty($_GET['suboperation'])} class="on"{/if}><a href="buluo.php?mod=group&action=manage&op=group&fid=$_G[fid]">{lang group_setup}</a></li>
                <!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
                    <li {if $_GET['op'] == 'checkuser'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]">{lang group_member_moderate}</a></li>
                    <li {if $_GET['op'] == 'manageuser'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]">{lang group_member_management}</a></li>
                <!--{/if}-->
                <!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
                    <li {if $_GET['op'] == 'threadtype'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]">{lang group_threadtype}</a></li>
                    <li {if $_GET['op'] == 'demise'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&op=demise&fid=$_G[fid]">{lang group_demise}</a></li>
                <!--{/if}-->
            </ul>
        </div>
        <div class="mod_info">
            <h3><i class="iconfont wq_f20 wqm_r5">&#xe61b;</i><em class="wq_grey">{$Tlang[20d01d716f550469]}</em></h3>
            <ul>
                <li{if $_GET['op'] == 'group' && $_GET['suboperation'] == 'data'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&fid=$_G[fid]&suboperation=data">{$Tlang[f5e1dcb6f691ed99]}</a></li>
                <li{if $_GET['op'] == 'group' && $_GET['suboperation'] == 'levelstyle'} class="on"{/if}><a href="buluo.php?mod=group&action=manage&fid=$_G[fid]&suboperation=levelstyle">{$Tlang[72975de6ac99de8b]}</a></li>
            </ul>
        </div>
    </div>
    <div class="mod_content y">
        <!--{if $_GET['op'] == 'group'}-->
            <!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_buluo/config/config.php';}-->
            <!--{eval $filename = wq_buluo_pc_load_manage();}-->
            <!--{if $filename}-->
                <!--{eval include_once $filename;}-->
            <!--{else}-->
                <div class="wrap">
                    <h3 class="page_title">{$Tlang[4a660bf977226088]}</h3>
                    <form enctype="multipart/form-data" action="buluo.php?mod=group&action=manage&op=group&fid=$_G[fid]" name="manage" method="post" autocomplete="off">
                        <input type="hidden" value="{FORMHASH}" name="formhash" />
                        <div class="establish_group_con wq_p0">
                            <table cellspacing="0" cellpadding="0" class="tfm vt establish_table" summary="{lang group_admin_panel}">
                                <tbody>
                                    <tr>
                                        <th>&nbsp;</th>
                                        <td><strong class="rq"><em id="returnmessage4"></em></strong></td>
                                    </tr>

                                    <!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
                                        <tr>
                                            <th><span class="rq">*</span>{lang group_name}:</th>
                                            <td><input type="text" id="name" name="name" class="g_input" size="36" tabindex="1" value="$_G[forum][name]" autocomplete="off" tabindex="1" /></td>
                                        </tr>
                                    <!--{/if}-->

                                    <!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
                                        <tr>
                                            <th><span class="rq">*</span>{lang group_category}:</th>
                                            <td>
                                                <select name="parentid" tabindex="2" class="ps" onchange="ajaxget('forum.php?mod=ajax&action=secondgroup&fupid=' + this.value, 'secondgroup');">
                                                    <!--{if !strpos($groupselect['first'],'selected="selected"')}-->
                                                        <!--{eval
                                                            $search = 'value="'.$_G['forum']['fup'].'"';
                                                            $groupselect['first'] = str_replace($search,$search.' selected="selected"',$groupselect['first']);
                                                        }-->
                                                    <!--{/if}-->
                                                    $groupselect[first]
                                                </select>
                                                <em id="secondgroup"><!--{if $groupselect['second']}--><select id="fup" name="fup" class="ps" >$groupselect[second]</select><!--{/if}--></em>
                                            </td>
                                        </tr>
                                    <!--{/if}-->

                                    <tr>
                                        <th>{lang group_description}</th>
                                        <td>
                                            <script type="text/javascript">
                                                var allowbbcode = allowimgcode = parsetype = 1;
                                                var allowhtml = forumallowhtml = allowsmilies = 0;
                                            </script>
                                            <script type="text/javascript" src="{$_G[setting][jspath]}bbcode.js?{VERHASH}"></script>
                                            <div id="descriptionpreview"></div>
                                            <div class="tedt">
                                                <div class="bar">
                                                    <div class="y"><a href="javascript:;" onclick="$('descriptionpreview').innerHTML = bbcode2html($('descriptionmessage').value)">{lang group_description_preview}</a></div>
                                                    <!--{eval $seditor = array('description', array('bold', 'color', 'img', 'link'));}-->
                                                    <!--{subtemplate common/seditor}-->
                                                </div>
                                                <div class="area">
                                                    <textarea id="descriptionmessage" name="descriptionnew" class="pt" rows="8">$_G[forum][descriptionnew]</textarea>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>{lang group_perm_visit}</th>
                                        <td>
                                            <input type="radio" name="gviewpermnew" class="pr weui_check" id="gviewpermnew1"  value="1" $gviewpermselect[1] />
                                            <label class="lb weui_check_label" for="gviewpermnew1"><i class="iconfont weui_icon_checked"></i>{lang group_perm_all_user}</label>
                                            <input type="radio" name="gviewpermnew" class="pr weui_check" id="gviewpermnew2" value="0" $gviewpermselect[0] />
                                             <label class="lb weui_check_label" for="gviewpermnew2"><i class="iconfont weui_icon_checked"></i>{lang group_perm_member_only}</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>{lang group_join_type}</th>
                                        <td>

                                             <input type="radio" name="jointypenew" class="pr weui_check" id="jointypenew1" value="0" $jointypeselect[0] >
                                             <label class="lb weui_check_label" for="jointypenew1"><i class="iconfont weui_icon_checked"></i>{lang group_join_type_free}</label>

                                             <input type="radio" name="jointypenew" class="pr weui_check" id="jointypenew2" value="2" $jointypeselect[2] />
                                             <label class="lb weui_check_label" for="jointypenew2"><i class="iconfont weui_icon_checked"></i>{lang group_join_type_moderate}</label>
                                              <input type="radio" name="jointypenew" class="pr weui_check" id="jointypenew3" value="1" $jointypeselect[1] />
                                              <label class="lb weui_check_label" for="jointypenew3"><i class="iconfont weui_icon_checked"></i>{lang group_join_type_invite}</label>
                                            <!--{if !empty($specialswitch['allowclosegroup'])}-->
                                                <input type="radio" name="jointypenew" class="pr weui_check"id="jointypenew4" value="-1" $jointypeselect[-1] />
                                                <label class="lb weui_check_label" for="jointypenew4"><i class="iconfont weui_icon_checked"></i>{lang close}</label>
                                                <span class="d">{lang group_close_notice}</span>
                                            <!--{/if}-->
                                        </td>
                                    </tr>

                                    <!--{if $_G['setting']['allowgroupdomain'] && !empty($_G['setting']['domain']['root']['group']) && $domainlength}-->
                                        <tr>
                                            <th>{lang subdomain}</th>
                                            <td>
                                                http://<input type="text" name="domain" class="px g_input" value="$_G[forum][domain]" style="width: 640px;" />.{$_G['setting']['domain']['root']['group']}
                                                <p class="d">
                                                    {lang group_domain_message}<br/>
                                                    <!--{if $_G[forum][domain] && $consume}-->{lang group_edit_domain_message}<!--{/if}-->
                                                </p>
                                            </td>
                                        </tr>
                                    <!--{/if}-->

                                    <!--{if !empty($_G['group']['allowupbanner']) || $_G['adminid'] == 1}-->
                                        <tr>
                                            <th>{lang group_image}</th>
                                            <td>
                                                <div class="choice_file_btn"><span>{$Tlang[98ba9e14c806fe96]}</span><em></em><input type="file" name="bannernew" id="bannernew" class="pf" size="25" /></div>
                                                <!--{if $_G['forum']['banner']}-->
                                                     <input type="checkbox" class="pr weui_check_z" name="deletebanner" id="deletebanner" value="1">
                                                     <label class="lb weui_check_label_z" for="deletebanner"><i class="iconfont weui_icon_checked_z"></i> {lang group_no_image}</label>
                                                    <p class="d">{lang group_no_image_comment}</p>
                                                    <p><img onload="thumbImg(this, 1)" _width="1000" _height="180" src="$_G[forum][banner]?{TIMESTAMP}" /></p>
                                                <!--{/if}-->
                                                <p class="d">
                                                    <!--{if $_G[setting][group_imgsizelimit]}-->
                                                        {lang group_image_filesize_limit} &nbsp;
                                                    <!--{/if}-->
                                                    {lang wq_group_image_filesize_advise}
                                                </p>
                                            </td>
                                        </tr>
                                    <!--{/if}-->
                                    <tr>
                                        <th>{lang group_icon}</th>
                                        <td>
                                            <div class="choice_file_btn"><span>{$Tlang[98ba9e14c806fe96]}</span><em></em><input type="file" id="iconnew" class="pf vm" size="25" name="iconnew"/></div>
                                            <p class="wqm_t10"><!--{if $_G['forum']['icon']}-->
                                                <img width="160" height="160" alt="" class="vm" style="margin-right: 1em;" src="$_G[forum][icon]?{TIMESTAMP}" />
                                                <!--{/if}--><span class="d">
                                                    {lang wq_group_icon_resize} &nbsp;
                                                    <!--{if $_G[setting][group_imgsizelimit]}-->
                                                    {lang group_image_filesize_limit}
                                                    <!--{/if}--></span>
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>&nbsp;</th>
                                        <td><button type="submit" name="groupmanage" class="pnc btn_primary wqm_t10" value="1">{lang submit}</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
                <script>
                    wqjq(function(){
                        wqjq(".choice_file_btn").on("change","input[type='file']",function(){
                            var filepath=wqjq(this).val();
                            var filename = filepath.substring(filepath.lastIndexOf("\\") + 1, filepath .length);
                            wqjq(this).prev().html(filename)
                        })
                    });
                </script>
            <!--{/if}-->
        <!--{elseif $_GET['op'] == 'checkuser'}-->
            <div class="wrap">
                <h3 class="page_title">{$Tlang[94618bf3edab187a]}</h3>
                <!--{if $checkusers}-->
                    <p class="tbmu cl">
                        <span class="y">
                            <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=1" class="btn_primary wqm_t0 wqm_r10">{lang pass_all}</a>
                            <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=2" class="btn_default wqm_t0">{lang ignore_all}</a>
                        </span>
                    </p>

                    <div class="xld member_audit">
                        <!--{loop $checkusers $uid $user}-->
                            <dl class="bbda cl">
                                <dd class="m avt"><!--{echo avatar($user[uid], 'small')}--></dd>
                                <dt><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a> <span class="xw0">($user['joindateline'])</span></dt>
                                <dd class="pns"><button type="submit" name="checkusertrue" class="pn pnc" value="true" onclick="location.href = 'forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1'">{lang pass}</button> &nbsp; <button type="submit" name="checkuserfalse" class="pn pnd" value="true" onclick="location.href = 'forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2'">{lang ignore}</button></dd>
                            </dl>
                        <!--{/loop}-->
                    </div>

                    <!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
                <!--{else}-->
                    <p class="emp">{lang group_no_member_moderated}</p>
                <!--{/if}-->
            </div>
        <!--{elseif $_GET['op'] == 'manageuser'}-->
            <script type="text/javascript">
                function groupManageUser(targetlevel_val) {
                    $('targetlevel').value = targetlevel_val;
                    $('manageuser').submit();
                }
            </script>

            <!--{if $_G['forum']['membernum'] > 2}-->
                <div class="bm_c pns wqpcbuluo_search_member manage_operate_btn">
                    <!--{eval $srchuser = dhtmlspecialchars($_GET[srchuser]);}-->
                    <form action="buluo.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]" method="post">
                        <input type="text" {if empty($srchuser)}onclick="$('groupsearch').value=''"{/if} placeholder="{lang enter_member_user}" value="{if $srchuser}{$srchuser}{/if}" size="15" class="px p_fre vm" id="groupsearch" name="srchuser">&nbsp;
                               <button class="pn vm" type="submit">{lang search}</button>
                    </form>
                </div>
            <!--{/if}-->

            <div class="wrap">
                <h3 class="page_title">{$Tlang[58a3c14ba8053335]}</h3>
                <form action="buluo.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true" name="manageuser" id="manageuser" method="post" autocomplete="off" class="ptm">
                    <input type="hidden" value="{FORMHASH}" name="formhash" />
                    <input type="hidden" value="0" name="targetlevel" id="targetlevel" />
                    <!--{if $adminuserlist}-->
                        <div class="wqb_b1"></div>
                        <div class="member_admin">
                            <h2 class="wq_f16 wqm_b10"><strong>{lang group_admin_member}</strong></h2>
                            <div class="bm_c">
                                <ul class="ml mls cl">
                                    <!--{loop $adminuserlist $user}-->
                                        <li>
                                            <a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt">
                                                <!--{if $user['level'] == 1}-->
                                                    <em class="gm"></em>
                                                <!--{elseif $user['level'] == 2}-->
                                                    <em class="gm" style="filter: alpha(opacity=50); opacity: 0.5"></em>
                                                <!--{/if}-->

                                                <!--{if $user['online']}-->
                                                    <em class="gol"></em>
                                                <!--{/if}-->
                                                <!--{echo avatar($user[uid], 'small')}-->
                                            </a>
                                            <p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></p>
                                            <!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}-->
                                                <p>
                                                     <input type="checkbox" class="pc weui_check_z" name="muid[{$user[uid]}]" id="muid[{$user[uid]}]" value="$user[level]" />
                                                    <label class="weui_check_label_z" for="muid[{$user[uid]}]"><i class="iconfont weui_icon_checked_z"></i></label>

                                                </p>
                                            <!--{/if}-->
                                        </li>
                                    <!--{/loop}-->
                                </ul>
                            </div>
                        </div>
                    <!--{/if}-->

                    <!--{if $staruserlist || $userlist}-->
                        <div class="member_admin">
                            <div class="cl">
                                <h2 class="wq_f16 wqm_b10"><strong>{lang member}</strong></h2>
                            </div>

                            <div class="bm_c">
                                <!--{if $staruserlist}-->
                                    <ul class="ml mls cl">
                                        <!--{loop $staruserlist $user}-->
                                        <li>
                                            <a href="home.php?mod=space&uid=$user[uid]" title="{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}" class="avt">
                                                <em class="gs"></em>
                                                <!--{if $user['online']}-->
                                                    <em class="gol"{if $user['level'] <= 3} style="margin-top: 15px;"{/if}></em>
                                                <!--{/if}-->
                                                <!--{echo avatar($user[uid], 'small')}-->
                                            </a>
                                            <p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></p>

                                            <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
                                                <p>
                                                    <input type="checkbox" class="pc weui_check_z" name="muid[{$user[uid]}]" id="muid[{$user[uid]}]" value="$user[level]" />
                                                    <label class="weui_check_label_z" for="muid[{$user[uid]}]"><i class="iconfont weui_icon_checked_z"></i></label>
                                                </p>
                                            <!--{/if}-->
                                        </li>
                                        <!--{/loop}-->
                                    </ul>
                                <!--{/if}-->

                                <!--{if $userlist}-->
                                    <ul class="ml mls cl">
                                        <!--{loop $userlist $user}-->
                                        <li>
                                            <a href="home.php?mod=space&uid=$user[uid]" class="avt"><!--{echo avatar($user[uid], 'small')}--></a>
                                            <p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></p>
                                            <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
                                                <p>
                                                    <input type="checkbox" class="pc weui_check_z" name="muid[{$user[uid]}]" id="muid[{$user[uid]}]" value="$user[level]"/>
                                                    <label class="weui_check_label_z" for="muid[{$user[uid]}]"><i class="iconfont weui_icon_checked_z"></i></label>

                                                </p>
                                            <!--{/if}-->
                                        </li>
                                        <!--{/loop}-->
                                    </ul>
                                <!--{/if}-->
                            </div>
                        </div>
                    <!--{/if}-->

                    <!--{if $multipage}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
                    <div class="cl manage_operate_btn">
                        <!--{loop $mtype $key $name}-->
                            <!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
                                <button type="button" name="manageuser" value="true" class="pn" onclick="groupManageUser('{$key}')"><span>$name</span></button>
                            <!--{/if}-->
                        <!--{/loop}-->
                    </div>
                </form>
            </div>
        <!--{elseif $_GET['op'] == 'threadtype'}-->
            <div class="wrap">
                <h3 class="page_title">{$Tlang[e2c10536ad973ce3]}</h3>
                <div class="wqb_b1 wqm_t10"></div>
                <div class="bm bw0">
                    <!--{if empty($specialswitch['allowthreadtype'])}-->
                        {lang group_level_cannot_do}
                    <!--{else}-->
                        <!--{eval $newenable = '<input type="checkbox" class="pc weui_check_z"  id="newenable[\'+addrowkey+\']" name="newenable[\'+addrowkey+\']" value="1"/> <label class="weui_check_label_z" for="newenable[\'+addrowkey+\']">';}-->
                        <script type="text/JavaScript">
                            var addrowdirect = 0;
                            var addrowkey = 0;
                            var typenumlimit = $typenumlimit;
                            function wq_addrow(obj, type,flag) {
                                if(flag == 2){
                                    addrowkey--;
                                }else{
                                    var table = obj.parentNode.parentNode.parentNode.parentNode;
                                    if(typenumlimit <= obj.parentNode.parentNode.parentNode.rowIndex - 1) {
                                        alert('{lang group_threadtype_limit_1}'+typenumlimit+'{lang group_threadtype_limit_2}');
                                        return false;
                                    }
                                    if(!addrowdirect) {
                                        var row = table.insertRow(obj.parentNode.parentNode.rowIndex);
                                    } else {
                                        var row = table.insertRow(obj.parentNode.parentNode.rowIndex + 1);
                                    }
                                    var rowtypedata = [
                                                        [
                                                        [1,'<input type="checkbox" class="pc weui_check_z"id="category1"disabled="disabled"/><label class="weui_check_label_z" for="category1"><i class="iconfont weui_icon_checked_z"></i></label>', ''],
                                                        [1,'$newenable <i class="iconfont weui_icon_checked_z"></i></label>', ''],
                                                        [1,'<input class="px" type="text" size="2" name="newdisplayorder[]" value="0" />'],
                                                        [1,'<input class="px" type="text" name="newname[]" />']
                                                        ],
                                                    ];
                                    var typedata = rowtypedata[type];
                                    for(var i = 0; i <= typedata.length - 1; i++) {
                                        var cell = row.insertCell(i);
                                        cell.colSpan = typedata[i][0];
                                        var tmp = typedata[i][1];
                                        if(typedata[i][2]) {
                                            cell.className = typedata[i][2];
                                        }
                                        tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                                        tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
                                        cell.innerHTML = tmp;
                                    }
                                    addrowkey ++;
                                    addrowdirect = 0;
                                }
                            }
                        </script>

                        <div id="threadtypes">
                            <form id="threadtypeform" action="buluo.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" autocomplete="off" method="post" name="threadtypeform">
                                <input type="hidden" value="{FORMHASH}" name="formhash" />
                                <table cellspacing="0" cellpadding="0" class="tfm vt">
                                    <tr>
                                        <th>{lang threadtype_turn_on}:</th>
                                        <td>
                                            <input type="radio" name="threadtypesnew[status]" class="pr weui_check" value="1"id="threadtypesnew1" onclick="$('threadtypes_config').style.display = '';$('threadtypes_manage').style.display = '';" $checkeds[status][1] />
                                            <label class="lb weui_check_label" for="threadtypesnew1"><i class="iconfont weui_icon_checked"></i>{lang yes}</label>


                                                <input type="radio" name="threadtypesnew[status]" class="pr weui_check" value="0"id="threadtypesnew2" onclick="$('threadtypes_config').style.display = 'none';$('threadtypes_manage').style.display = 'none';"  $checkeds[status][0] />
                                             <label class="lb weui_check_label" for="threadtypesnew2"><i class="iconfont weui_icon_checked"></i>{lang no}</label>
                                            <p class="d">{lang threadtype_turn_on_comment}</p>
                                        </td>
                                    </tr>
                                    <tbody id="threadtypes_config" style="display: $display">
                                        <tr>
                                            <th>{lang threadtype_required}:</th>
                                            <td>
                                                <input type="radio" name="threadtypesnew[required]" class="pr weui_check"id="threadtypesnew3"  value="1" $checkeds[required][1] />
                                                <label class="lb weui_check_label" for="threadtypesnew3"><i class="iconfont weui_icon_checked"></i>{lang yes}</label>
                                                <input type="radio" name="threadtypesnew[required]" class="pr weui_check"id="threadtypesnew4"  value="0" $checkeds[required][0] />
                                                <label class="lb weui_check_label" for="threadtypesnew4"><i class="iconfont weui_icon_checked"></i>{lang no}</label>
                                                <p class="d">{lang threadtype_required_force}</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>{lang threadtype_prefix}:</th>
                                            <td>
                                                <input type="radio" name="threadtypesnew[prefix]" class="pr weui_check"id="threadtypesnew5"  value="0" $checkeds[prefix][0] />
                                                <label class="lb weui_check_label" for="threadtypesnew5"><i class="iconfont weui_icon_checked"></i>{lang threadtype_prefix_off}</label>

                                                <input type="radio" name="threadtypesnew[prefix]" class="pr weui_check"id="threadtypesnew6"  value="1" $checkeds[prefix][1] />
                                               <label class="lb weui_check_label" for="threadtypesnew6"><i class="iconfont weui_icon_checked"></i>{lang threadtype_prefix_on}</label>
                                                <p class="d">{lang threadtype_prefix_comment}</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div id="threadtypes_manage" class="threadtypes_manage" style="display: $display">
                                    <h2 class="ptm pbm wq_f16 wqm_b10">{$Tlang[b7d63548f8406158]}{lang threadtype}</h2>
                                    <table cellspacing="0" cellpadding="0" border="1">
                                        <thead>
                                            <tr>
                                                <th width="85">{lang delete}</th>
                                                <th width="100">{lang enable}</th>
                                                <th width="100">{lang displayorder}</th>
                                                <th width="200">{lang threadtype_name}</th>
                                            </tr>
                                        </thead>
                                        <!--{if $threadtypes}-->
                                            <!--{loop $threadtypes $val}-->
                                                <tbody>
                                                    <tr>
                                                        <td><input type="checkbox" class="pc weui_check_z"id="{$val[typeid]}" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" />
                                                            <label class="weui_check_label_z" for="{$val[typeid]}"><i class="iconfont weui_icon_checked_z"></i></label>
                                                        </td>
                                                        <td>
                                                            <input type="checkbox" class="pc weui_check_z"  id="threadtypesnew[options][enable][{$val[typeid]}]"name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" $val[enablechecked] />
                                                            <label class="weui_check_label_z" for="threadtypesnew[options][enable][{$val[typeid]}]"><i class="iconfont weui_icon_checked_z"></i></label>
                                                        </td>
                                                        <td><input type="text" name="threadtypesnew[options][displayorder][{$val[typeid]}]" class="px" size="2" value="$val[displayorder]" /></td>
                                                        <td><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" class="px" value="$val[name]" /></td>
                                                    </tr>
                                                </tbody>
                                            <!--{/loop}-->
                                        <!--{/if}-->
                                        <tr>
                                            <td colspan="4"><img class="vm" src="{IMGDIR}/addicn.gif" /> <a href="javascript:;" onclick="wq_addrow(this, 0, 1)">{lang threadtype_add}</a></td>
                                        </tr>
                                    </table>
                                </div>
                                <button type="submit" class="pnc btn_primary y" name="groupthreadtype" value="1">{lang submit}</button>
                            </form>
                        </div>
                    <!--{/if}-->
                </div>
            </div>
        <!--{elseif $_GET['op'] == 'demise'}-->
            <div class="wrap">
                <h3 class="page_title">{$Tlang[b775459bef2c2de8]}</h3>
                <div class="bm bw0 group_transfer ">
                    <!--{if $groupmanagers}-->
                    <div class="tbmu">
                        {lang group_demise_comment}
                        <div class="mtm">{lang group_demise_notice}</div>
                    </div>
                    <form action="buluo.php?mod=group&action=manage&op=demise&fid=$_G[fid]" name="groupdemise" method="post" class="exfm">
                        <input type="hidden" value="{FORMHASH}" name="formhash" />
                        <table cellspacing="0" cellpadding="0" class="tfm vt wqm_t10">
                            <tr>
                                <th>{lang transfer_group_to}:</th>
                                <td>
                                    <ul class="ml mls cl">
                                        <!--{loop $groupmanagers $user}-->
                                            <li>
                                                <a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator}{elseif $user['level'] == 2}{lang group_moderator_vice}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt">
                                                    <!--{echo avatar($user[uid], 'small')}-->
                                                </a>
                                                <p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a></p>
                                                <!--{if $user['uid'] != $_G['uid']}-->
                                                    <p>
                                                        <input type="radio" class="pr weui_check_z" name="suid" id="$user[uid]"  value="$user[uid]">
                                                        <label class="weui_check_label_z" for="$user[uid]"><i class="iconfont weui_icon_checked_z"></i></label>
                                                    </p>
                                                <!--{/if}-->
                                            </li>
                                        <!--{/loop}-->
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th>{lang group_input_password}</th>
                                <td><input type="password" name="grouppwd" class="px group_transfer_password" /></td>
                            </tr>
                            <tr>
                                <th>&nbsp;</th>
                                <td>
                                    <button type="submit" name="groupdemise" class="pnc btn_primary wqm_t0" value="1">{lang submit}</button>
                                </td>
                            </tr>
                        </table>
                    </form>
                    <!--{else}-->
                        <p class="emp">{lang group_no_admin_member}</p>
                    <!--{/if}-->
                </div>
            </div>
        <!--{/if}-->
    </div>
</div>