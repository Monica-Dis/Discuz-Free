<?php exit("From: DisM.taobao.com"); ?>
<!--{if !$_GET[api]}-->
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<div class="groupfans_list b_bottom">
    <ul>
        <li>
            <a href="plugin.php?id=wq_buluo&mod=follow&do=follower&uid={$space[uid]}"<!--{if $do == 'follower'}--> class="on"<!--{/if}-->>{$Tlang['bbd702ca1f76841a']}</a>
        </li>
        <li>
            <a href="plugin.php?id=wq_buluo&mod=follow&do=following&uid={$space[uid]}"<!--{if $do == 'following'}--> class="on"<!--{/if}-->>{$Tlang['2c8a07313e7706bc']}</a>
        </li>
    </ul>
</div>
<!--{else}-->
    <!--{eval $plugin_wq_touch_setting = !empty($_G['cache']['plugin']['wq_touch_setting']) ? 1 : 0;}-->
    <!--{if $plugin_wq_touch_setting}-->
        <!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_touch_setting/function/function_wq_touch.php';}-->
    <!--{else}-->
        <!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_touch.php';}-->
    <!--{/if}-->
<!--{/if}-->

<!--{if $list}-->
<!--{if !$_GET[api]}-->
<div class="fans" >
    <ul id="wq_fuser_list">
<!--{/if}-->

        <!--{loop $list $fuid $fuser}-->
        <!--{block userprofile}-->
        <p style="padding-left: 80px;">
            <!--{eval
                $wq_id = $do == 'following' ? 'followuid' : 'uid';
                $age = !empty($memberprofile[$fuser[$wq_id]]['birthyear']) ? (intval(date("Y", time())) - $memberprofile[$fuser[$wq_id]]['birthyear']) + 1 : "";
            }-->

            <!--{if $memberprofile[$fuser[$wq_id]]['gender']}-->
                <!--{if $memberprofile[$fuser[$wq_id]][gender]==1}-->
                    <span class="male_age"><i class="wqiconfont wqicon-nan f12 m_r2"></i>$age</span>
                <!--{else}-->
                    <span class="male_age bg_nv"><i class="wqiconfont wqicon-nv f12 m_r2"></i>$age</span>
                <!--{/if}-->
            <!--{else}-->
                {$Plang['a948ddf6cbae92e7']}
            <!--{/if}-->

            <!--{if $memberprofile[$fuser[$wq_id]]['resideprovince']}-->
                <!--{eval $wq_touch ? wq_resideprovince($memberprofile[$fuser[$wq_id]]['resideprovince']) : _buluo_wq_resideprovince($memberprofile[$fuser[$wq_id]]['resideprovince']);}-->
                <span class="location">$resideprovince</span>
            <!--{/if}-->
        </p>
        <!--{/block}-->
        <li class="cl<!--{if in_array($fuser['uid'], $newfollower_list)}--> unread<!--{/if}--> b_bottom" id="follow_li_{$fuser['followuid']}">
            <!--{if $do=='following'}-->
            <div class="fans_img"><a href="plugin.php?id=wq_buluo&mod=card&uid=$fuser['followuid']">{avatar($fuser['followuid'],middle)}</a></div>
            <h2 class="name m_b4">
                <a href="plugin.php?id=wq_buluo&mod=card&uid=$fuser['followuid']" class="width160">$fuser['fusername']</a>
                <!--{if $fuser['bkname']}--><span id="followbkame_{$fuser['followuid']}" class="xg1 xs1 xw0">$fuser[bkname]</span><!--{/if}-->
                <em class="y">
                    <!--{if $viewself}-->
                    <span id="a_followmod_{$fuser['followuid']}">
                        <button href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']&handlekey=cancel_attention" class="dialog btn_focus clo_b wqtop30 notlogged"><i class="wqiconfont wqicon-iconfontfollowok wq_f22"></i></button>
                    </span>
                    <!--{elseif $fuser[followuid] != $_G[uid]}-->
                    <!--{if $fuser['mutual']}-->
                    <!--{if $fuser['mutual'] > 0}--><span class="z flw_status_2"><i class="wqiconfont wqicon-cuban3huchuan f20"></i></span><!--{/if}-->
                    <span id="a_followmod_{$fuser['followuid']}">
                        <button href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']&handlekey=cancel_attention" class="dialog btn_focus clo_b wqtop30 notlogged"><i class="wqiconfont wqicon-iconfontfollowok wq_f22"></i></button>
                    </span>
                    <!--{elseif helper_access::check_module('follow')}-->
                    <span id="a_followmod_{$fuser['followuid']}"><button href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['followuid']&handlekey=add_attention"  class="dialog btn_focus wqtop30 notlogged"><i class="wqiconfont wqicon-guanzhu wq_f18"></i></button>
                    </span>
                    <!--{/if}-->
                    <!--{/if}-->
                </em>
            </h2>
            $userprofile
            <p class="fans_in_con">
              {$Tlang['bbd702ca1f76841a']}<a href="plugin.php?id=wq_buluo&mod=follow&do=follower&uid=$fuser['followuid']"><strong class="xi2" id="followernum_$fuser['followuid']">$memberinfo[$fuid]['follower']</strong></a>
                <span class="fans_co m_l10">{$Tlang['2c8a07313e7706bc']}<a href="plugin.php?id=wq_buluo&mod=follow&do=following&uid=$fuser['followuid']"><strong class="xi2">$memberinfo[$fuid]['following']</strong></a></span>
                <!--{if $viewself && $fuser[followuid] != $_G[uid]}-->
                <!--{if helper_access::check_module('follow')}-->
                <span id="a_specialfollow_{$fuser['followuid']}">
                    <!--{if $fuser['status'] == 1}-->
                    <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special=2&fuid=$fuser['followuid']&handlekey=cancel_specialfollow" class="dialog notlogged">
                        {$Tlang['2e820feb5f8e011c']}
                    </a>
                    <!--{else}-->
                    <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special=1&fuid=$fuser['followuid']&handlekey=add_specialfollow" class="dialog notlogged">
                        {$Tlang['6f7e2051b79df1c1']}
                    </a>
                    <!--{/if}-->
                </span>
                <!--{/if}-->
                <!--{/if}-->
            </p>
            <!--{else}-->
            <div class="fans_img"><span><a href="plugin.php?id=wq_buluo&mod=card&uid=$fuser['uid']">{avatar($fuser['uid'],middle)}</a></span></div>
            <h2 class="name m_b4">
                <a href="plugin.php?id=wq_buluo&mod=card&uid=$fuser['uid']">$fuser['username']</a>
                <em class="y">
                    <!--{if $fuser[uid] != $_G[uid]}-->
                    <!--{if $fuser['mutual']}-->
                    <!--{if $fuser['mutual'] > 0}--><span class="z flw_status_2" id="mutual_{$fuser['uid']}"><i class="wqiconfont wqicon-cuban3huchuan f20"></i></span><!--{/if}-->
                    <span id="a_followmod_{$fuser['uid']}">
                        <button href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['uid']&handlekey=cancel_attention" class="dialog btn_focus clo_b wqtop30 notlogged"><i class="wqiconfont wqicon-iconfontfollowok wq_f22"></i></button>
                    </span>
                    <!--{elseif helper_access::check_module('follow')}-->
                    <span id="a_followmod_{$fuser['uid']}"">
                        <button href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['uid']&handlekey=add_attention"  class="dialog btn_focus wqtop30 notlogged"><i class="wqiconfont wqicon-guanzhu wq_f18"></i></button></span>
                    <!--{/if}-->
                    <!--{/if}-->
                </em>
            </h2>
            $userprofile
            <p class="fans_in_con">
                {$Tlang['2c8a07313e7706bc']}<a href="plugin.php?id=wq_buluo&mod=follow&do=follower&uid=$fuser['uid']"><strong class="xi2">$memberinfo[$fuid]['follower']</strong></a>
                <span class="fans_co m_l10">
                    {$Tlang['bbd702ca1f76841a']}<a href="plugin.php?id=wq_buluo&mod=follow&do=following&uid=$fuser['uid']"><strong class="xi2">$memberinfo[$fuid]['following']</strong></a></span>
            </p>
            <!--{/if}-->
        </li>
        <!--{/loop}-->
<!--{if !$_GET[api]}-->
    </ul>
</div>
<div class="p_load_more" style="display: none">
    <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
    <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
    <!--{else}-->
    <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
    <!--{/if}-->
    {$Tlang['d0a97567aed382e8']}
</div>
<div class="loading loading_lh" {if $page * $perpage < $count}style="display: none;"{/if}>{$Plang['b3f7b411f8a25701']}</div>

<script>
    function succeedhandle_add_attention(url, msg, param) {
        if ($.trim(msg) == '{$Tlang[581ff9f7c750ca4a]}') {
            wq_setTimeout();
            $('#a_followmod_' + param.fuid).html('<button href="home.php?mod=spacecp&ac=follow&op=del&fuid=' + param.fuid + '&handlekey=cancel_attention" class="dialog btn_focus clo_b wqtop30"><i class="wqiconfont wqicon-iconfontfollowok wq_f22"></i></button>');
        }
    }
    function succeedhandle_cancel_attention(url, msg, param) {
        if ($.trim(msg) == '{$Tlang[bef022f6310db3b9]}') {
            wq_setTimeout();
            if ('$do' == 'following' && '$_G[uid]' == '$_GET[uid]') {
                $('#follow_li_' + param.fuid).remove();
            } else {
                $('#a_followmod_' + param.fuid).html('<button href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + param.fuid + '&handlekey=add_attention"  class="dialog btn_focus wqtop30"><i class="wqiconfont wqicon-guanzhu wq_f18"></i></button>');
                $('#mutual_' + param.fuid).remove();
            }
        }
    }
    function succeedhandle_add_specialfollow(url, msg, param) {
        if ($.trim(msg) == "{$Plang['581ff9f7c750ca4a']}") {
            wq_setTimeout();
            $('#a_specialfollow_' + param.fuid).html('<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special=2&fuid=' + param.fuid + '&handlekey=cancel_specialfollow" class="dialog">{$Tlang[2e820feb5f8e011c]}</a>');
        }
    }
    function succeedhandle_cancel_specialfollow(url, msg, param) {
        if ($.trim(msg) == "{$Plang['581ff9f7c750ca4a']}") {
            popup.open('<div class="ass_fl"><dt><p>{$Plang['58394913af1d8f26']}</p></dt></div>');
            wq_setTimeout();
            $('#a_specialfollow_' + param.fuid).html('<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special=1&fuid=' + param.fuid + '&handlekey=add_specialfollow" class="dialog">{$Tlang[6f7e2051b79df1c1]}</a>');
        }
    }
    $(function () {
        wq_touch_ajax_scroll('$page', '$count', '$perpage', 'plugin.php?id=wq_buluo&mod=follow&do=$do&uid={$space[uid]}', 'wq_fuser_list');
    });
</script>
<!--{/if}-->
<!--{elseif !$_GET[api]}-->
<div id="nofollowmsg">
    <div class="flw_thread">
        <p class="emp">
            <span class="no_content"><img src="{$_G['style']['styleimgdir']}mobile/images/no_content.png"></span>
            <!--{if $viewself}-->
            <!--{if $do=='following'}-->{$Plang['e476bf0d6e3364c5']}<!--{else}-->{$Plang['9fbbf2196ef85700']}<!--{/if}-->
            <!--{else}-->
            <!--{if $do=='following'}-->{$Plang['e485d9f31de7bc4f']}<!--{else}-->{$Plang['afc3a57b911c05a9']}<!--{/if}-->
            <!--{/if}-->
        </p>
    </div>
</div>
<!--{/if}-->
<!--{if !$_GET[api]}-->
    <!--{if $wq_touch}-->
        <!--{eval $wq_footer_hide='1';}-->
        <!--{template common/footer}-->
    <!--{else}-->
        <!--{template common/wq_buluo_tpl_footer}-->
    <!--{/if}-->
<!--{/if}-->