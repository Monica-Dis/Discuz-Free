<?php exit("From: DisM.taobao.com"); ?>
<!--{eval
    $modthreadkey = dhtmlspecialchars($_GET['modthreadkey']);
    $from = dhtmlspecialchars($_GET['from']);
}-->
<table cellspacing="0" cellpadding="0"><tr><td class="t_f" id="postmessage_$post[pid]">
	<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0)))}--><div class="ptw pbm cl"><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($modthreadkey)}&modthreadkey={$modthreadkey}{/if}&page=$page" class="z pn_2"><span class="z">{lang post_add_aboutcounter}</span></a></div><div class="pbw xs1 f14">{lang viewthread_trade_message1}<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&firstpid=$post[pid]&addtrade=yes{if !empty($from)}&from={$from|{/if}"">{lang viewthread_trade_message2}</a>,{lang viewthread_trade_message3} "<strong>{lang viewthread_trade_message4}</strong>"</div><!--{else}-->$post[message]<!--{/if}-->
</td></tr></table>

<!--{if count($trades) > 1 || ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
	<div class="trdc xs1">
		<em>{lang post_trade_totalnumber}: $tradenum</em>
		<!--{if !$_G['forum_thread']['is_archived'] && ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
			<a href="forum.php?mod=misc&action=tradeorder&tid=$_G[tid]{if !empty($from)}&from={$from}{/if}" onclick="showWindow('tradeorder', this.href)">{lang trade_displayorder}</a>
			<!--{if $_G['uid'] == $_G['forum_thread']['authorid']}-->
				<!--{if $_G['group']['allowposttrade']}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&firstpid=$post[pid]&addtrade=yes{if !empty($from)}&from={$from}{/if}">+ {lang trade_add_post}</a>
				<!--{/if}-->
				<span class="pipe">|</span>
				<a href="javascript:;" onclick="window.open('home.php?mod=space&uid=$_G[uid]&do=trade&view=tradelog','','');return false;">{lang my_trade_stat}</a>
			<!--{/if}-->
		<!--{/if}-->
	</div>
<!--{/if}-->
<!--{if $tradenum}-->
	<!--{if $trades}-->
		<div class="xs1 cl">
			<!--{loop $trades $key $trade}-->
			<!--{if $tradepostlist[$trade[pid]]['invisible'] != 0}-->
				<div class="trdb">{lang post_trade_removed}</div>
			<!--{else}-->
            	<!--{eval $modthreadkey = dhtmlspecialchars($_GET[modthreadkey]);}-->
				<div class="trdb">
					<div id="trade$trade[pid]" class="trdl cl">
						<div class="tt" onclick="display('trade$trade[pid]');ajaxget('forum.php?mod=viewthread&do=tradeinfo&tid=$_G[tid]&pid=$trade[pid]{if !empty($modthreadkey)}&modthreadkey={$modthreadkey}{/if}','tradeinfo$trade[pid]','tradeinfo$trade[pid]')">
							<!--{if $trade['displayorder'] > 0}--><em class="hot">{lang post_trade_sticklist}</em><!--{/if}-->
							<!--{if $trade['thumb']}-->
								<img src="$trade[thumb]" onclick="zoom(this, '$trade[attachurl]')" width="{if $trade[width] > 90}90{else}$trade[width]{/if}" _width="90" _height="90" alt="$trade[subject]" />
							<!--{else}-->
								<img src="{IMGDIR}/nophotosmall.gif" width="90" height="90" alt="$trade[subject]" />
							<!--{/if}-->
						</div>
						<div class="ta spi">
							<span class="y"><a href="javascript:;" onclick="display('trade$trade[pid]');ajaxget('forum.php?mod=viewthread&do=tradeinfo&tid=$_G[tid]&pid=$trade[pid]{if !empty($modthreadkey)}&modthreadkey={$modthreadkey}{/if}','tradeinfo$trade[pid]','tradeinfo$trade[pid]')" title="{lang open}"><img src="{STATICURL}image/common/collapsed_yes.gif" alt="" class="vm" /> {lang open}</a></span>
							<h4><a href="forum.php?mod=viewthread&do=tradeinfo&tid=$_G[tid]&pid=$trade[pid]{if !empty($modthreadkey)}&modthreadkey={$modthreadkey}{/if}" target="_blank">$trade[subject]</a></h4>

							<dl class="z">
								<dt>{lang trade_type_viewthread}:</dt>
								<dd>
									<!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}-->
									<!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->
									{lang trade_type_buy}
								</dd>
								<dt>{lang trade_remaindays}:</dt>
								<dd>
								<!--{if $trade[closed]}-->
									<em>{lang trade_timeout}</em>
								<!--{elseif $trade[expiration] > 0}-->
									{$trade[expiration]}{lang days}{$trade[expirationhour]}{lang trade_hour}
								<!--{elseif $trade[expiration] == -1}-->
									<em>{lang trade_timeout}</em>
								<!--{else}-->
									&nbsp;
								<!--{/if}-->
								</dd>
								<!--{hook/viewthread_trade_extra $key}-->
							</dl>
							<div class="z mtn">
								<!--{if $trade[price] > 0}-->
									<strong>$trade[price]</strong>&nbsp;{lang payment_unit}&nbsp;&nbsp;
								<!--{/if}-->
								<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
									<!--{if $trade['price'] > 0}-->{lang trade_additional} <!--{/if}--><strong>$trade[credit]</strong>&nbsp;{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}
								<!--{/if}-->
								<p class="xg1">
									<!--{if $trade['costprice'] > 0}-->
										<del>$trade[costprice] {lang payment_unit}</del>
									<!--{/if}-->
									<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}-->
										<del><!--{if $trade['costprice'] > 0}-->{lang trade_additional} <!--{/if}-->$trade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</del>
									<!--{/if}-->
								</p>
							</div>
						</div>
					</div>
					<div id="tradeinfo$trade[pid]"></div>
				</div>
			<!--{/if}-->
			<!--{if count($trades) == 1}-->
            	<!--{eval $modthreadkey = dhtmlspecialchars($_GET[modthreadkey]);}-->
				<script type="text/javascript" onload="1">display('trade$trade[pid]');ajaxget('forum.php?mod=viewthread&do=tradeinfo&tid=$_G[tid]&pid=$trade[pid]<!--{if !empty($modthreadkey)}-->&modthreadkey={$modthreadkey}<!--{/if}-->','tradeinfo$trade[pid]','tradeinfo$trade[pid]')</script>
			<!--{/if}-->
			<!--{/loop}-->
		</div>
	<!--{/if}-->

<div id="postmessage_$post[pid]">$post[counterdesc]</div>
<!--{else}-->
	<div class="locked">{lang trade_nogoods}</div>
<!--{/if}-->