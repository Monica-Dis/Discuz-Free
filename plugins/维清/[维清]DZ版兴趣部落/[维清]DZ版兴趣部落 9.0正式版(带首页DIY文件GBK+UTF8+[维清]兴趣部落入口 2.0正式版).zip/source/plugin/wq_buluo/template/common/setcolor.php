<?php exit("From: DisM.taobao.com"); ?>
<style>
a:hover, .link:hover, .link a:hover, a:hover.link,.group_bg .p_pop a:hover, .p_pop a.a,.group_header .links .personal_list a:hover,.topic_title li.on a,.group_category .focus_join span,.per_con .btn_post,.per_con .btn_post a,.pg_sort .pg_sort_list li:hover, .pg_sort .pg_sort_list li.active,.wq_typehtml,.g_text_top .ttp .a a,.g_text_top .ttp a:hover,.view_praise a,.view_praise a,.title_right span a:hover,.barinfo_category .focus span,.more_bar_button,.more_bar_button a,.wqpc_mygroup_title .a a,.wqpc_group_ass a:hover,#wqbuluo_scrolltop a:hover,.mod_sidebar .wqpc_switch a,.group_topic .ttp a:hover{ color:$set_color;}
.wqpc_down_menu .dkdiy a:hover,.down_menu .grsz a:hover,.down_menu .ypt a:hover,.down_menu .glzx a:hover,.down_menu .mhgl a:hover,.down_menu .yhtc a:hover,.looking_posts .p_btn,.group_add_btn a,.group_ass_list a span.active, .group_ass_list a span:hover,.group_ass_list a span.a,.per_focus, .per_sign ,.sign_btn,.view_praise a.on,.button_reply .btn_submit,.my_reply .btn_submit,.member_audit .pns .pnc,.manage_operate_btn .pn,.group_header .g_search_box div.g_search_btn button{background-color:$set_color}
.looking_posts .p_btn,.group_add_btn a,.pnpost .pn,.group_bg .pn_2,.per_con .btn_post,.pg_menu a:hover i,.wq_typehtml,.g_text_top .ttp .a a,.g_text_top .ttp a:hover,.view_content .pcb_group .pns .pn,.view_praise a,.member_audit .pns .pnc,.manage_operate_btn .pn,.wqpcgroup_post.tb li.a a,.wqpc_group_ass a:hover,.wqpc_group_ass .on a,.group_header .g_search_box div.g_search_btn button{ border: 1px solid $set_color;}
.application_group,.topic_title .line_b,.pnpost .pn,.pnpost .pnc,.fwinmask .pnc,.group_bg .pn_2,.publish_botton,.view_content .trdc,.view_content .pcb_group .pns .pn,.wqpcgroup_post.tb li.a a,.wqpc_group_ass .on a,.group_header .links a.wqbuluo_establish{ background: $set_color;}
.topic_title li.on,.group_menu li.a,.wqpc_mygroup_title .a a{border-bottom: 2px solid $set_color;}
.pnpost .pnc,.fwinmask .pnc,#newspecial_menu.p_pop{border-color: $set_color;}
.group_topic .ttp .a a{border-color: $set_color !important;  color: #fff}
.panel_wrapper .more_bar:hover{ color: $set_color !important;}

.group_topic .ttp .a a{ background:$set_color !important;}

input[type="text"]:focus{border-color: $set_color}
a:hover,a.wqcolor,a.wqcolor:hover,.weui_check:checked +label .weui_icon_checked:before,.weui_check_z:checked +label .weui_icon_checked_z:before,.td_content .ap_operation a:hover {color: $set_color;}
.mod_info ul li.on,.page_btn_search,.chart_day_nav_item.active,.btn_data,.btn_primary{background:$set_color;}
.tabcontainer .tab_hd li.select,.chart_title ul li.active { border-top: 2px solid $set_color;}
.pg strong { background-color: $set_color;border-color: $set_color;}
.btn_primary{border: 1px solid $set_color;background:$set_color; opacity: 0.8}
.btn_primary:hover{background:$set_color !important; opacity: 1}
.member_audit .pns .pnc{border: 1px solid $set_color;background:$set_color; opacity: 0.8}
.member_audit .pns .pnc:hover{background:$set_color !important; opacity: 1}
</style>