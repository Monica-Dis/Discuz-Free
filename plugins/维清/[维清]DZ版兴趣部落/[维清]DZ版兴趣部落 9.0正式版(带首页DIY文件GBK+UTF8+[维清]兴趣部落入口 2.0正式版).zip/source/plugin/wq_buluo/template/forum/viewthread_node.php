<?php exit("From: DisM.taobao.com"); ?>
<div class="g_text_top">
    <!--{eval
        $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);
        $postshowavatars = !($_G['setting']['bannedmessages'] & 2 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)));
        $modthreadkey =dhtmlspecialchars($_GET['modthreadkey']);
        $extra =dhtmlspecialchars($_GET['extra']);
    }-->

    <!--{if CHARSET == 'gbk'}-->
        <!--{eval include DISCUZ_ROOT . './source/plugin/wq_buluo/language/lang_template_gbk.php';}-->
    <!--{else}-->
        <!--{eval include DISCUZ_ROOT . './source/plugin/wq_buluo/language/lang_template_utf8.php';}-->
    <!--{/if}-->

    <!--{block authorverifys}-->
        <!--{loop $post['verifyicon'] $vid}-->
            <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
        <!--{/loop}-->

        <!--{loop $post['unverifyicon'] $vid}-->
            <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
        <!--{/loop}-->
    <!--{/block}-->

    <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
        <div id="threadstamp"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
    <!--{/if}-->

    <!--{if empty($post['deleted'])}-->
        <!--{if $post[first]}-->
            <div class="title_in">
                <h3>$_G[forum_thread][subject]</h3>
                    <!--{if $modmenu['thread']}-->
                        <em style=" float: right;margin-left: 20px;margin-top: 3px;">
                            <input type="checkbox" onclick="viewclick(this)"  class="pr weui_check_z" name="moderate[]" id="moderate{$_G[tid]}" value="$thread[tid]">
                            <label class="weui_check_label_z" for="moderate{$_G[tid]}"><i class="iconfont weui_icon_checked_z wq_ff14 wqm_r5"></i>{$Tlang['4fb732ea043a312d']}</label>
                            <!--<a href="javascript:;"><i class="iconfont wqicon-fatie wqm_r5"></i>{$Tlang['4fb732ea043a312d']}</a>-->
                        </em>
                        <script>
                            function viewclick(obj) {
                                if(obj.checked) {
                                    $('wqbuluo-modmenu').style.display = '';
                                } else {
                                    $('wqbuluo-modmenu').style.display = 'none';
                                }
                            }
                        </script>
                        <div id="wqbuluo-modmenu" class="wqbuluo_modmenu_warp" style="display:none;">
                            <table cellspacing="0" cellpadding="0" class="fwin">
                                <tbody>
                                    <tr>
                                        <td class="t_l"></td>
                                        <td class="t_c"></td>
                                        <td class="t_r"></td>
                                    </tr>
                                    <tr>
                                        <td class="m_l">&nbsp;&nbsp;</td>
                                        <td class="m_c">
                                            <div class="f_c">
                                                <div class="c">
                                                    <!--{eval $modopt=0;}-->
                                                    <!--{if $_G['forum']['ismoderator']}-->
                                                        <!--{if $_G['group']['allowdelpost']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(3, 'delete')">{$Tlang['9ae0804e786988fa']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(3, 'bump')">{$Tlang['f612a99b216128b5']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(1, 'stick')">{$Tlang['01ff72df2ca84800']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('live')">{$Tlang['b8e79f61c30e1e3a']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(1, 'highlight')">{$Tlang['0933269d57ffe644']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(1, 'digest')">{$Tlang['46d1ecf7cc55b12f']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(1, 'recommend')">{$Tlang['db11cdebc2eb37bd']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('stamp')">{$Tlang['6e07edb2393a4070']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('stamplist')">{$Tlang['91a544ece9363e4f']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
                                                            <!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(4)"><!--{if !$_G['forum_thread']['closed']}-->{$Tlang['beb08d096719774b']}<!--{else}-->{$Tlang['491897baba35e060']}<!--{/if}--></a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
                                                            <!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(2, 'move')">{$Tlang['ef882d2e4330c3d5']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modthreads(2, 'type')">{$Tlang['968265252bbb1364']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
                                                            <!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}-->
                                                                <a href="javascript:;" onclick="modaction('copy')">{$Tlang['092029f19dbfdfde']}</a><span class="pipe">|</span>
                                                            <!--{/if}-->
                                                            <!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}-->
                                                                <a href="javascript:;" onclick="modaction('merge')">{$Tlang['ef104b4e641cdfaa']}</a><span class="pipe">|</span>
                                                            <!--{/if}-->
                                                            <!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++}-->
                                                                <a href="javascript:;" onclick="modaction('refund')">{$Tlang['484e67dab35b3277']}</a><span class="pipe">|</span>
                                                            <!--{/if}-->
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
                                                            <!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('split')">{$Tlang['261b7429db84bc68']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('repair')">{$Tlang['908f026deeb498b9']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('restore', '', 'archiveid={$_G[forum_thread][archiveid]}')">{$Tlang['d7891d6451046fda']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['forum_firstpid']}-->
                                                            <!--{if $_G['group']['allowwarnpost']}--><!--{eval $modopt++}-->
                                                                <a href="javascript:;" onclick="modaction('warn', '$_G[forum_firstpid]')">{$Tlang['a8d4b15dd720dbfc']}</a><span class="pipe">|</span>
                                                            <!--{/if}-->
                                                            <!--{if $_G['group']['allowbanpost']}--><!--{eval $modopt++}-->
                                                                <a href="javascript:;" onclick="modaction('banpost', '$_G[forum_firstpid]')">{$Tlang['5b1cbfcad581bfea']}</a><span class="pipe">|</span>
                                                            <!--{/if}-->
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}-->
                                                            <!--{eval $modopt++}-->
                                                            <a href="javascript:;" onclick="modaction('removereward')">{$Tlang['bcefd87cce77ce00']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}-->
                                                            <a href="javascript:;" onclick="modthreads(5, 'recommend_group');return false;">{$Tlang['15edbb47dd8bc56b']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['allowmanagetag']}-->
                                                            <a href="javascript:;" onclick="showWindow('mods', 'forum.php?mod=tag&op=manage&tid=$_G[tid]', 'get', 0)">{$Tlang['6586eca1f3a782c3']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                        <!--{if $_G['group']['alloweditusertag']}-->
                                                            <a href="javascript:;" onclick="showWindow('usertag', 'forum.php?mod=misc&action=usertag&tid=$_G[tid]', 'get', 0)">{$Tlang['8fc3bce8fa573801']}</a><span class="pipe">|</span>
                                                        <!--{/if}-->
                                                    <!--{/if}-->

                                                    <!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++}-->
                                                        <a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id=$_G['tid']">{$Tlang['cf65fa8ea7af58d9']}</a>
                                                    <!--{/if}-->
                                                    <!--{hook/viewthread_modoption}-->
                                                </div>
                                            </div>
                                        </td>
                                        <td class="m_r"></td>
                                    </tr>
                                    <tr>
                                        <td class="b_l"></td>
                                        <td class="b_c"></td>
                                        <td class="b_r"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <!--{/if}-->

                    <em style=" float: right">
                        <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
                            <a class="" href="buluo.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey={$modthreadkey}{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{$lang['post_add_aboutcounter']}<!--{else}--><i class="iconfont wqicon-fatie wqm_r5"></i>{$lang['edit']}<!--{/if}--></a>
                        <!--{/if}-->
                    </em>
                <p>
                    <!--{if $thread[folder] == 'lock'}-->
                        <!--<img src="{IMGDIR}/folder_lock.gif" />-->
                    <!--{elseif $thread['special'] == 1}-->
                        <span class="icon_vote">{$lang['thread_poll']}</span>
                    <!--{elseif $thread['special'] == 2}-->
                        <span class="icon_sell">{$lang['thread_trade']}</span>
                    <!--{elseif $thread['special'] == 3}-->
                        <span class="icon_reward">{$lang['thread_reward']}</span>
                    <!--{elseif $thread['special'] == 4}-->
                        <span class="icon_activity">{$lang['thread_activity']}</span>
                    <!--{elseif $thread['special'] == 5}-->
                        <span class="icon_debate">{$lang['thread_debate']}</span>
                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                        <img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
                    <!--{else}-->
                        <!--        <img src="{IMGDIR}/folder_common.gif" />-->
                    <!--{/if}-->

                    <span id="authorposton$post[pid]" class="wqm_r10">$post[dateline]</span><span>{$lang['views']}</span><span  class="wqm_r10">$_G[forum_thread][views]</span><span>{$lang['reply']}</span><span>$_G[forum_thread][allreplies]</span>
                </p>
            </div>
        <!--{/if}-->

        <div class="view_head">
            <a href="home.php?mod=space&uid=$post[authorid]">$post[avatar]</a>
        </div>

        <div class="view_con">
            <div class="head_in">
                <!--{if $_G['setting']['authoronleft']}-->$post[author]<!--{/if}-->
                <!--{if $post['gender']==2}-->
                    <span class="female"><i class="iconfont wqicon-nv f12"></i></span>
                <!--{elseif $post['gender']==1}-->
                    <span class="male"><i class="iconfont wqicon-nan f12"></i></span>
                <!--{/if}-->

                <!--{loop $groupuser $key $val}-->
                    <!--{if $val['uid'] == $post['uid']}-->
                        <!--{if  $val['level']==1}-->
                            <span class="chief">{$lang['group_moderator_title']}</span>
                        <!--{elseif  $val['level']==2}-->
                            <span class="chief">{$lang['group_moderator_vice_title']}</span>
                        <!--{elseif  $val['level']==3}-->
                            <span class="chief">{$lang['group_star_member_title']}</span>
                        <!--{elseif  $val['level']==4}-->
                            <span class="chief">{$lang['member']}</span>
                        <!--{else}-->
                            <span class="chief">{$lang['group_wait_mod']}</span>
                        <!--{/if}-->
                    <!--{/if}-->
                <!--{/loop}-->

                <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                <!--{if $_self }-->
                    <span class="wqlandlord">{$lang['thread_author']}</span>
                <!--{/if}-->

                <!--{hook/viewthread_postheader $postcount}-->
                <div class="y">
                    <div class="pti">
                        <div class="pdbt">
                            <!--{if !$post['first'] && $post['rewardfloor']}-->
                                <label class="pdbts pdbts_1">
                                    <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" title="{$lang[rushreply_hit_title]}" class="v">{$lang['prosit']}</a>
                                    <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" title="{$lang['rushreply_hit_title']}" class="b">{$lang['rushreply_hit']}</a>
                                </label>
                            <!--{/if}-->

                            <!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
                                <label class="pdbts pdbts_{echo intval($post[stand])}">
                                        <!--{if $post[stand] == 1}-->
                                            <a class="v" href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&filter=debate&stand=1" title="{$lang[debate_view_square]}">
                                                {$lang['debate_square']}
                                            </a>
                                        <!--{elseif $post[stand] == 2}-->
                                            <a class="v" href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&filter=debate&stand=2" title="{$lang[debate_view_opponent]}">
                                                {$lang['debate_opponent']}
                                            </a>
                                        <!--{else}-->
                                            <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&filter=debate&stand=0" title="{$Tlang['c12693971d702ebf']}">
                                                {$Tlang['c12693971d702ebf']}
                                            </a>
                                        <!--{/if}-->
                                        <!--{if $post[stand]}-->
                                            <a class="b" href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" id="voterdebate_$post[pid]" onclick="ajaxmenu(this);doane(event);">{$lang['debate_support']} $post[voters]</a>
                                        <!--{/if}-->
                                </label>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="view_content">
                <div class="plc">
                     <!--{ad ad_a_pr/thread/a_pr/3/$postcount}-->
                    <div class="pct">
                        <!--{ad/thread/a_pt/2/$postcount}-->
                        <!--{if empty($ad_a_pr_css)}-->
                            <style type="text/css">.pcb{margin-right:0}</style>
                            <!--{eval $ad_a_pr_css=1;}-->
                        <!--{/if}-->

                        <!--{if !$post['first'] && $post['replycredit'] > 0}-->
                            <div class="cm">
                                <h3 class="psth xs1"><span class="icon_ring vm"></span>
                                    {$lang['replycredit']} <span class="xw1 xs2 xi1">+{$post['replycredit']}</span> {$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}
                                </h3>
                            </div>
                        <!--{/if}-->

                        <!--{template wq_buluo:forum/viewthread_node_body}-->
                        <!--{if helper_access::check_module('collection') && !$_G['forum']['disablecollect']}-->
                            <!--{if $post['relatecollection']}-->
                                <div class="cm">
                                    <h3 class="psth xs1"><span class="icon_ring vm"></span>{$lang['collection_related']}</h3>
                                    <ul class="mbw xl xl2 cl">
                                        <!--{loop $post['relatecollection'] $var}-->
                                            <li>&middot; <a href="forum.php?mod=collection&action=view&ctid=$var[ctid]" title="$var[name]" target="_blank" class="xi2 xw1">$var[name]</a><span class="pipe">|</span><span class="xg1">{$lang['collection_threadnum']}: $var[threadnum], {$lang['collection_follow']}: $var[follownum]</span></li>
                                        <!--{/loop}-->
                                        <!--{if $post['releatcollectionmore']}-->
                                            <li>&middot; <a href="forum.php?mod=collection&tid=$_G[tid]" target="_blank" class="xi2 xw1">{$lang['more']}</a></li>
                                        <!--{/if}-->
                                    </ul>
                                </div>

                                <!--{if $post['sourcecollection']['ctid']}-->
                                    {$lang['collection_fromctid']}
                                    <form action="buluo.php?mod=collection&action=comment&ctid={$ctid}&tid={$_G[tid]}" method="POST" class="ptm pbm cl">
                                        <input type="hidden" name="ratescore" id="ratescore" />
                                        <span class="clct_ratestar">
                                            <span class="btn">
                                                <a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star', 1)" onmouseout="rateStarHover('clct_ratestar_star', 0)" onclick="rateStarSet('clct_ratestar_star', 1, 'ratescore')">1</a>
                                                <a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star', 2)" onmouseout="rateStarHover('clct_ratestar_star', 0)" onclick="rateStarSet('clct_ratestar_star', 2, 'ratescore')">2</a>
                                                <a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star', 3)" onmouseout="rateStarHover('clct_ratestar_star', 0)" onclick="rateStarSet('clct_ratestar_star', 3, 'ratescore')">3</a>
                                                <a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star', 4)" onmouseout="rateStarHover('clct_ratestar_star', 0)" onclick="rateStarSet('clct_ratestar_star', 4, 'ratescore')">4</a>
                                                <a href="javascript:;" onmouseover="rateStarHover('clct_ratestar_star', 5)" onmouseout="rateStarHover('clct_ratestar_star', 0)" onclick="rateStarSet('clct_ratestar_star', 5, 'ratescore')">5</a>
                                            </span>
                                            <span id="clct_ratestar_star" class="star star$memberrate"></span>
                                        </span>
                                        &nbsp;<button type="submit" value="submit" class="pn"><span>{$lang['collection_rate']}</span></button>
                                    </form>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                    </div>
                </div>
            </div>

            <!--{if $post[first]}-->
                <div class="view_praise">
                    <!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
                        <!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
                            <a id="recommend_add"{if $_G[forum_thread][recommend_add]}class="on"{/if} href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} title="{$lang['maketoponce']}"><i>&#x8D5E;(&nbsp;<span id="recommendv_add">{$_G[forum_thread][recommend_add]}</span>&nbsp;)</i></a>
                        <!--{/if}-->
                    <!--{/if}-->

                    <!--{if $post['invisible'] == 0}-->
                        <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                            <a class="cmmnt" href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra={$extra}&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" onclick="showWindow('comment', this.href, 'get', 0)">{$lang['comments']}</a>
                        <!--{/if}-->

                        <!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->
                            <a href="buluo.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra={$extra}&page=$page" onclick="showWindow('reply', this.href)">{$lang['reply']}(&nbsp;{$_G[forum_thread][allreplies]}&nbsp;)</a>
                        <!--{/if}-->
                    <!--{/if}-->
                </div>
            <!--{/if}-->
        </div>

        <div id="_postposition$post['pid']"></div>
        <div class="ad">
            <!--{if $post['first'] && $_G[forum_thread][special] == 5 && $_G[forum_thread][displayorder] >= 0}-->
                <ul class="ttp cl">
                    <li style="display:inline;margin-left:12px"><strong class="bw0 bg0_all">{$lang['debate_filter']}&nbsp;:</strong></li>
                    <li{if !isset($_GET['stand'])} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}" hidefocus="true">{$lang['all']}</a></li>
                    <li{if $_GET['stand'] == 1} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&stand=1" hidefocus="true">{$lang['debate_square']}</a></li>
                    <li{if $_GET['stand'] == 2} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&stand=2" hidefocus="true">{$lang['debate_opponent']}</a></li>
                    <li{if isset($_GET['stand']) && $_GET['stand'] == 0} class="xw1 a"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&stand=0" hidefocus="true">{$lang['debate_neutral']}</a></li>
                </ul>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['replies']}--><!--{ad/interthread/a_p/$postcount}--><!--{/if}-->
        </div>

        <!--{if $post[first]}-->
            <!--{if $_G[forum_thread][allreplies]!=0}-->
                <div class="wqpc_separate"></div>
                <h3 class="comment_title">{$Tlang['4bc7b967c326c87e']}
                    <em class="title_right">
                        <!--{if $post['invisible'] == 0}-->
                            <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                                <span><a href="buluo.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$post[authorid]" rel="nofollow"><i class="iconfont wqicon-filter f20"></i>{$Tlang['8e7eb1fb11788b3b']}</a></span>
                            <!--{elseif !$_G['forum_thread']['archiveid']}-->
                                <span><a href="buluo.php?mod=viewthread&tid=$post[tid]&page=$page" rel="nofollow"><i class="iconfont wqicon-filter f20"></i>{$Tlang['b9bb85e83ae7ddaa']}</a></span>
                            <!--{/if}-->
                        <!--{/if}-->

                        <!--{if !$rushreply}-->
                            <!--{if $ordertype != 1}-->
                                <span><a href="buluo.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&ordertype=1{if $_GET[authorid]}&authorid=$post[authorid]{/if}"  class="show"><i class="iconfont wqicon-desc"></i>{$lang['post_descview']}</a></span>
                            <!--{else}-->
                                <span><a href="buluo.php?mod=viewthread&tid=$_G[tid]&extra={$extra}&ordertype=2{if $_GET[authorid]}&authorid=$post[authorid]{/if}"  class="show"><i class="iconfont wqicon-ttpodicon wq_f20"></i>{$lang['post_ascview']}</a></span>
                            <!--{/if}-->
                        <!--{/if}-->
                    </em>
                </h3>
            <!--{/if}-->
        <!--{/if}-->

        <!--{if !empty($aimgs[$post[pid]])}-->
            <script type="text/javascript" reload="1">
                aimgcount[{$post[pid]}] = [<!--{echo dimplode($aimgs[$post[pid]]);}-->];
                attachimggroup($post['pid']);
                <!--{if empty($_G['setting']['lazyload'])}-->
                <!--{if !$post['imagelistthumb']}-->
                    attachimgshow($post[pid]);
                <!--{else}-->
                    attachimgshow($post[pid], 1);
                <!--{/if}-->
                <!--{/if}-->
                    var aimgfid = 0;
                <!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
                    aimgfid = $_G[fid];
                <!--{/if}-->
                <!--{if $post['imagelistthumb']}-->
                    attachimglstshow($post['pid'], <!--{echo intval($_G['setting']['lazyload'])}-->, aimgfid, '{$_G[setting][showexif]}');
                <!--{/if}-->
            </script>
        <!--{/if}-->
    <!--{else}-->
        <table id="pid$post[pid]" summary="pid$post[pid]" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td class="pls"></td>
                    <td class="plc">
                        <div class="pi">
                            <strong><a><!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}--><em>{$post[number]}</em>{$postno[0]}<!--{/if}--></a></strong>
                        </div>
                        <div class="pct">{$lang['post_deleted']}</div>
                    </td>
                </tr>
                <tr class="ad">
                    <td class="pls"></td>
                    <td class="plc"></td>
                </tr>
            </tbody>
        </table>
    <!--{/if}-->
</div>
<!--{hook/viewthread_endline $postcount}-->