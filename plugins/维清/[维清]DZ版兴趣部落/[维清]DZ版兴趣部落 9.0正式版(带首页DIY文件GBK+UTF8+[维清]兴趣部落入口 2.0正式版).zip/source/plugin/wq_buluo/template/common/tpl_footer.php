<?php exit("From: DisM.taobao.com"); ?>
<!--{if $_GET[inajax]}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{if $pc_is_headbottom}-->
        <!--{template common/footer}-->
    <!--{else}-->
        <!--{template wq_buluo:common/footer}-->
    <!--{/if}-->
<!--{/if}-->