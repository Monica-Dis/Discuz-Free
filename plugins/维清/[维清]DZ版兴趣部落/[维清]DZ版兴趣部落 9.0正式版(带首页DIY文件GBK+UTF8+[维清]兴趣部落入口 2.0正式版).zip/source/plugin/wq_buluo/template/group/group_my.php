<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_buluo:common/tpl_header}-->
    <!--{hook/my_header}-->
    <div class="wp">
        <!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    </div>

    <div id="ct" class="wp wqpc_mygroup" style="width: 1000px;">
        <div class="mn">
            <!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
            <div class="cl wqpc_mygroup_title" style="margin-top: 0;">
                <ul>
                    <li $actives[mythread]><a href="buluo.php?mod=my&view=mythread">{lang my_thread}</a></li>
                    <li $actives[join]><a href="buluo.php?mod=my&view=join">{lang my_add_group}</a></li>
                </ul>
            </div>

            <!--{if $view == 'groupthread' || $view == 'mythread'}-->
                <ul class="ttp wqpc_group_ass">
                        <li id="ttp_all"{if empty($typeid)} class="on"{/if}><a href="buluo.php?mod=my&view=$view">{lang all}</a></li>
                        <!--{loop $usergroups['grouptype'] $type}-->
                            <li{if $typeid == $type['fid']} class="on"{/if}><a href="buluo.php?mod=my&view=$view{if $typeid != $type['fid']}&typeid=$type[fid]{/if}">$type[name]</a></li>
                        <!--{/loop}-->
                </ul>

                <div class="tl wqpc_group_table">
                    <div class="th">
                        <table cellpadding="0" cellspacing="0">
                            <tr>
                                <td colspan="2">
                                        <!--{if $view == 'groupthread'}-->{lang last_topic_in_group}<!--{else}-->{lang my_last_topic_in_group}<!--{/if}-->
                                </td>
                                <td class="by">{lang group}</td>
                                <td class="num">{lang replies}</td>
                                <td class="by">{lang last_post}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="bm_c">
                        <table cellspacing="0" cellpadding="0">
                                <!--{if $groupthreadlist}-->
                                    <!--{loop $groupthreadlist $tid $thread}-->
                                        <tr>
                                            <td class="icn">
                                                <a href="buluo.php?mod=viewthread&tid=$tid" title="{lang open_new_window}" target="_blank">
                                                    <!--{if $thread[folder] == 'lock'}-->
                                                        <img src="{IMGDIR}/folder_lock.gif" />
                                                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                                        <img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
                                                    <!--{else}-->
                                                        <img src="{IMGDIR}/folder_$thread[folder].gif" />
                                                    <!--{/if}-->
                                                </a>
                                            </td>
                                            <td><a href="buluo.php?mod=viewthread&tid=$tid" target="_blank">$thread[subject]</a></td>
                                            <td class="by"><a href="buluo.php?mod=group&fid=$thread[fid]" target="_blank" class="xg1">$thread[groupname]</a></td>
                                            <td class="num">
                                                <a href="buluo.php?mod=viewthread&tid=$tid" class="xi2">$thread[replies]</a>
                                                <em>$thread[views]</em>
                                            </td>
                                            <td class="by">
                                                <cite><!--{if $thread['lastposter']}--><a href="home.php?mod=space&username=$thread[lastposter]">$thread[lastposter]</a><!--{else}-->{lang anonymous}<!--{/if}--></cite>
                                                <em><a href="buluo.php?mod=viewthread&tid=$tid&page={echo max(1, $thread[pages]);}">$thread[lastpost]</a></em>
                                            </td>
                                        </tr>
                                    <!--{/loop}-->
                                <!--{else}-->
                                    <tr><td colspan="4"><div class="emp">{lang no_related_posts}</div></td></tr>
                                <!--{/if}-->
                        </table>
                    </div>
                </div>
                <!--{if $multipage}--><div class="pgs cl wqpc_page">$multipage</div><!--{/if}-->
            <!--{elseif $view == 'manager' || $view == 'join'}-->
                <!--{if $grouplist}-->
                    <div class="bm bml bw0">
                        <div class="bm_h cl" style="margin-left: 10px;">
                            {lang my_join_group}
                        </div>
                        <div class="bm_c">
                            <ul class="ml mls cl wqpc_groupjoin">
                                <!--{loop $grouplist $groupid $group}-->
                                    <li>
                                        <a href="buluo.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a>
                                        <p><!--{if $group['flevel'] == '-1'}-->({lang group_wait_mod})<!--{/if}--><a href="buluo.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></p>
                                    </li>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>
                    <!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->
                <!--{else}-->
                    <div class="emp"><!--{if $view == 'manager'}-->{lang no_group_create_now} <!--{elseif $view == 'join'}-->{lang no_group_join} <!--{/if}--></div>
                <!--{/if}-->
            <!--{/if}-->
            <!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
            <!--{hook/my_bottom}-->
        </div>
    </div>

    <div class="wp mtn">
        <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
    </div>
<!--{template wq_buluo:common/tpl_footer}-->