<?php exit("From: DisM.taobao.com"); ?>
<!--{template common/header}-->
<!--{if $threads}-->

<!--{loop $threads $thread}-->
<!--{eval $thread['dateline'] = dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'));}-->
<!--{if $info['summarys'][$thread['tid']]}-->
<li class="post" data="$thread[tid]" >
   <a href="buluo.php?mod=group&fid={$thread[fid]}" class="post_bar" target="_blank">{$info[fids][$thread[tid]]}</a>
    <a href="buluo.php?mod=viewthread&tid={$thread[tid]}" class="post_con"  target="_blank">
        <div class="title">
            <!--{if $thread[icon] >= 0}-->
                <span class="wqicon_all_14 wqtop_post_span"><img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" /></span>
        <!--{/if}-->
                <!--{eval $thread_status = wq_thread_status($thread);}-->
                $thread_status
                <!--{if $thread[fid]==$followforumid}-->
                $info[subjects][$thread[tid]]
                <!--{else}-->
                {$thread[subject]}
                <!--{/if}-->
        </div>
        <div>
            <div class="content">
                <!--{eval
                require_once libfile('function/discuzcode');
                $info[summarys][$thread[tid]] = discuzcode($info[summarys][$thread[tid]], 0,-1,0, 1, 1, 0, 0, 0, 1, $info[pids][$thread[tid]], 0, $thread['dbdateline'], 1);
                }-->
                <div class="desc">{$info['summarys'][$thread['tid']]}</div>
                <!--{eval
                    $wq_data=wq_buluo_get_images_by_tid_pids($info[pids][$thread[tid]],3,'',$thread['tid']);
                }-->
                <!--{if $wq_data}-->
                <div class="imglist_wrap" >
                    <!--{loop $wq_data $k $v}-->
                        <div class="img-box small disable-cusor" >
                            <img data="{$k}" data-tid="{$thread[tid]}" data-src="{$v[image]}" src="{$v[image]}" id="wqc_pc_css_{$thread[tid]}_{$k}" data-loaded="false" />
                        </div>
                    <!--{/loop}-->
                </div>
                <!--{/if}-->
            </div>
            <!--{eval $dateline=$thread[dbdateline]?date("Y-m-d",$thread[dbdateline]):"--"}-->
            <div class="time">{$dateline}</div>
        </div>
    </a>
    <!--{if $thread[fid]==$followforumid}-->
    <!--{eval $thread[views]=$forward_info[$thread[comments]][views];
    $thread[author]=$forward_info[$thread[comments]][author];
    $thread[replies]=$forward_info[$thread[comments]][replies];}-->
    <!--{/if}-->
    <div class="post_right">
        <div class="post-user ov_hd"><i class="iconfont wqicon-ren m_r5"></i>{$thread[author]}</div>
        <div class="view-num ov_hd"><i class="iconfont wqicon-view m_r5"></i>$thread[views]</div>
        <div class="comment-num ov_hd"><i class="iconfont wqicon-massage m_r5"></i>{$thread[replies]}</div>
    </div>

</li>
 <!--{else}-->
<!--{/if}-->
<!--{/loop}-->
<!--{/if}-->
<!--{template common/footer}-->