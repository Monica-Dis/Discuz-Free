<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<form method="post" action="plugin.php?id=wq_buluo&mod=forward">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="tid" value="$_G[tid]"/>
    <input type="hidden" name="forwardsubmit" value="yes"/>
    <div class="wq_frame">
        <h3 class="split_title">{$Plang['c649752f90c8ff27']}</h3>
        <div class="a_edit_wrapper">
            <div class="a_edit_border">
                <textarea spellcheck="false" name="message" class="edit" placeholder="{$Plang['9122f66afb50e417']}"></textarea>
            </div>
        </div>
        <div class="thumbnail">
            <!--{if $image}-->
            <div class="th_cover">
                <img src="$image">
            </div>
            <!--{/if}-->
            <div class="th_text">
                <h4>$_G['thread'][subject]</h4>
                <p>$post[message]</p>
            </div>
        </div>
        <div class="btn_group">
            <button class="btn" type="button"  onclick="popup.close()">{$Plang['9c825be7149e5b97']}</button>
            <button class="btn btn_import formdialog">{$Plang['ee1ff405bf671550']}</button>
        </div>
    </div>
</form>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->