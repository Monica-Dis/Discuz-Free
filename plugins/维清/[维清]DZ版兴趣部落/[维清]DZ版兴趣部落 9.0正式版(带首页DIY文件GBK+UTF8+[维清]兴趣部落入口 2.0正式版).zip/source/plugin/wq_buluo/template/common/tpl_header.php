<?php exit("From: DisM.taobao.com"); ?>
<!--{eval
    $config_url= DISCUZ_ROOT . './source/plugin/wq_buluo/template/config/config.php';
    include $config_url;
    $pc_is_headbottom = $wq_buluo['pc_is_headbottom'];
    $header_width = $wq_buluo['header_width'];
    $set_color = $wq_buluo['pc_color'];
}-->

<!--{if $_GET[inajax]}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{if $pc_is_headbottom}-->
	<!--{template common/header}-->
        <style type="text/css">
            .ct2_a .mn{ width:1040px;}
            .wqsysfixed {position: fixed;width: 1000px;top: 0;z-index: 10;}

        </style>
        <!--{if $header_width}-->
            <style type="text/css">
                .wp, #wp{ width:1000px !important;}
            </style>
        <!--{/if}-->

        <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/css/group.css?{VERHASH}" />
        <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/css/operate_buluo.css?{VERHASH}" />
        <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/font/iconfont.css?{VERHASH}" />
        <script src="./source/plugin/wq_buluo/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
    <!--{else}-->
        <!--{template wq_buluo:common/header}-->
    <!--{/if}-->
<!--{/if}-->

<!--{if $set_color}-->
    <!--{template wq_buluo:common/setcolor}-->
<!--{/if}-->