<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_buluo:common/tpl_header}-->
        <!--{if $action == 'manage'}-->
            <style type="text/css">
                .ct2_a .mn{ width:1040px;}
                .wqsysfixed {position: fixed;width: 1200px;top: 0;z-index: 10;}
                .per_bar,.group_menu{display:none !important;}
                #diycontentmiddle,#gorup1{display:none !important;}
            </style>
            <!--{if $wq_buluo['pc_is_headbottom'] && $wq_buluo['header_width']}-->
                <style type="text/css">
                    .wp,#wp{ width:1200px!important;}
                </style>
            <!--{/if}-->
        <!--{/if}-->
        <!--{ad/text/wp a_t}-->
    </div>

    <style id="diy_style" type="text/css"></style>
    <div class="wp wqwidth1000 <!--{if $action == 'manage'}-->wqwidth1200<!--{/if}-->" <!--{if !$pc_is_headbottom}--> style="width:1000px;"<!--{/if}-->>
        <!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->
        <!--{if $action != 'create'}-->
            <div class="per_bar">
                <div class="bg_img bg2" style="background-image: url(<!--{if $_G['forum']['banner']}-->{$_G['forum']['banner']}<!--{else}-->source/plugin/wq_buluo/static/pc/images/bg_<!--{eval echo mt_rand(0,3);}-->.jpg<!--{/if}-->);">
                     <div class="mask" ></div>
                </div>

                <div class="intro"><div class="per_logo"><img src="$_G[forum][icon]" alt="$_G[forum][name]"/></div>
                    <div class="per_info">
                        <div class="title">$_G[forum][name]</div>
                        <div class="desc ov_hd"><!--{if $_G[forum][description]}-->$_G[forum][description]<!--{/if}--></div>
                        <div class="per_data" >
                            <span class="y">
                                <a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang favorite}" class="fa_fav">{lang favorite}</a>
                                <span class="pipe">|</span>
                                <!--{if $_G[setting][rssstatus] && !$_GET['archiveid']}-->
                                <a href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" title="RSS" class="fa_rss">RSS</a><!--{/if}-->
                                <!--{if $status == 'isgroupuser' && helper_access::check_module('group')}--><span class="pipe">|</span>
                                <a href="javascript:;" onclick="showWindow('invite', 'misc.php?mod=invite&action=group&id=$_G[fid]')" class="fa_ivt">{lang my_buddylist_invite}</a><!--{/if}--></span>
                            <span><!--{if $_G['current_grouplevel']['icon']}--><img src="$_G[current_grouplevel][icon]" title="{lang group_level}: $_G[current_grouplevel][leveltitle]" class="vm">
                                <!--{/if}-->{lang credits}</span><span class="num">$_G[forum][commoncredits]</span>
                                <span>{$Tlang[e8ec099d6d4c2548]}{lang group_moderator_title}</span><span class="num"><!--{eval $i = 1;}-->
								<!--{loop $groupmanagers $manage}-->
									<!--{if $i > 10}-->
										<!--{eval continue;}-->
									<!--{/if}-->
									<!--{if $i > 1}-->, <!--{/if}--><a href="home.php?mod=space&uid=$manage[uid]" target="_blank" class="xi2">$manage[username]</a>
									<!--{eval $i++;}-->
								<!--{/loop}-->
                            </span>
                        </div>
                    </div>

                    <!--{if $action=='list'}-->
                        <!--{eval  $groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);}-->
                    <!--{/if}-->

                    <!--{if $_G['uid']}-->
                        <!--{eval $groupuser_extinfo=C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($_G[uid], $_G[fid]);}-->
                    <!--{/if}-->

                    <!--{eval
                        $wq_time = strtotime(date('Y-m-d'));
                        $yesterday=$wq_time- 24 * 60 * 60;$days=$groupuser_extinfo[lastsign]>=$yesterday?$groupuser_extinfo[signdays]:0;
                    }-->

                    <!--{if $_G['forum'][founderuid]!=$_G[uid]}-->
                        <!--{if $groupuser}-->
                            <!--{if $groupuser[level]==0}-->
                                <div class="per_focus"><a href="forum.php?mod=group&action=out&fid=$_G[fid]"  onclick="showWindow('wq_out', this.href)">{$Tlang[fcce7c30276aa190]}</a></div>
                            <!--{elseif $groupuser[level]>0}-->
                                <div class="continuity_sign">
                                    <div class="sign_info">
                                        <div>{$Tlang[23e67427ebb7a31f]}</div>
                                        <div>
                                            <span class="sign_num" id="sign_num">$days</span>
                                            <span>{$Tlang[007bd5bdbc31a995]}</span>
                                        </div>
                                    </div>
                                    <div class="sign_btn" id="sign_btn" >
                                        <!--{if $groupuser_extinfo[lastsign]!=strtotime(date('Y-m-d'))}-->
                                        <a  href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" onclick="showWindow('sign', this.href)">{$Tlang[f64c30e837e3267a]}</a>
                                        <!--{else}-->
                                        <a href="javascript:;">{$Tlang[a08b091b9ce4c933]}</a>
                                        <!--{/if}-->
                                    </div>
                                </div>
                            <!--{/if}-->
                        <!--{elseif helper_access::check_module('group') && $_G['forum'][jointype]!=1}-->
                            <!--{if !$groupuser_extinfo}-->
                            <!--{/if}-->
                            <div class="per_focus">
                                <a href="forum.php?mod=group&action=join&fid=$_G[fid]" onclick="showWindow('wq_join', this.href)">{$Tlang[876bb8031df32628]}</a>
                            </div>
                        <!--{/if}-->
                    <!--{else}-->
                        <div class="continuity_sign">
                            <div class="sign_info">
                                <div>{$Tlang[23e67427ebb7a31f]}</div>
                                <div>
                                    <span class="sign_num" id="sign_num">$days</span>
                                    <span>{$Tlang[007bd5bdbc31a995]}</span>
                                </div>
                            </div>

                            <div class="sign_btn" id="sign_btn">
                                <!--{if $groupuser_extinfo[lastsign]!=strtotime(date('Y-m-d'))}-->
                                <a  href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" onclick="showWindow('sign', this.href)">{$Tlang[f64c30e837e3267a]}</a>
                                <!--{else}-->
                                <a href="javascript:;">{$Tlang[a08b091b9ce4c933]}</a>
                                <!--{/if}-->
                            </div>
                        </div>
                    <!--{/if}-->
                </div>
            </div>

            <!--[diy=diycontentmiddle]--><div id="diycontentmiddle" class="area"></div><!--[/diy]-->
            <!--diyarea_1000px-->

            <!--{if CURMODULE == 'group'}--><!--{hook/group_top}--><!--{else}--><!--{hook/forumdisplay_top}--><!--{/if}-->
                <!--{if $status != 2 && $status != 3}-->
                    <div class="group_menu">
                        <!--{if $action != 'index' && ($status != 2 || $status != 3)}-->
                            <div class="y">
                                <div class="pns looking_posts">
                                    <form method="post" action="buluo.php?mod=group&search=yes&srchfid=$_G[fid]&searchsubmit=1"  onsubmit="if (!wqjq.trim(wqjq('#groupsearch').val()))
                                                return false;"  >
                                        <input type="text" name="srchtxt" id="groupsearch" class="px p_fre vm" size="15" value="{lang input_search_key_words}" onclick="$('groupsearch').value = ''" />&nbsp;
                                        <button type="submit" class="vm p_btn">{lang search}</button>
                                    </form>
                                </div>
                            </div>
                        <!--{/if}-->

                        <ul id="groupnav">
                            <li {if $action == 'list'}class="a"{/if}><a href="buluo.php?mod=forumdisplay&action=list&fid=$_G[fid]"target="_blank" title="">{lang group_discuss_area}</a></li>
                            <li {if $action == 'memberlist' || $action == 'invite'}class="a"{/if}><a href="buluo.php?mod=group&action=memberlist&fid=$_G[fid]"target="_blank" title="">{lang group_member_list}</a></li>
                            <!--{if $_G['forum']['ismoderator']}--><li {if $action == 'manage'}class="a"{/if}><a href="buluo.php?mod=group&action=manage&fid=$_G[fid]"target="_blank" >{lang group_admin}</a></li><!--{/if}-->
                            <!--{if CURMODULE == 'group'}--><!--{hook/group_nav_extra}--><!--{else}--><!--{hook/forumdisplay_nav_extra}--><!--{/if}-->
                        </ul>
                    </div>

                    <!--[diy=gorup1]--><div id="gorup1" class="area"></div><!--[/diy]-->
                    <!--diyarea_1000px-->
                <!--{else}-->
                    <div class="group_menu">{$Tlang[5ed76286893d421b]}</div>
                <!--{/if}-->
            <!--{/if}-->

        <!--{if $action == 'index' && $status != 2 && $status != 3}-->
            <!--{subtemplate wq_buluo:group/group_index}-->
        <!--{elseif $action == 'list'}-->
            <!--{if $_G['forum']['ismoderator']}-->
                <script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
            <!--{/if}-->

            <!--{if $_G['forum']['threadtypes']}-->
                <div class="group_topic">
                    <ul class="ttp bm">
                        <li id="ttp_all"{if !$_GET['typeid']} class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
                        <!--{if $_G['forum']['threadtypes']}-->
                            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
                            <li {if $_GET['typeid'] == $id} class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a></li>
                            <!--{/loop}-->
                        <!--{/if}-->
                            <!--{hook/forumdisplay_filter_extra}-->
                    </ul>
                </div>
            <!--{/if}-->

            <div class="ct2 cl">
                <!--right start-->
                <div class="sd">
                    <div class="drag">
                        <!--[diy=diysidetop]--><div id="diysidetop" class="area"></div><!--[/diy]-->
                        <!--diyarea_280px-->
                    </div>

                    <!--{subtemplate wq_buluo:common/common_module}-->

                    <!--{eval echo wq_buluo_right_qrcode();}-->
                    <!--[diy=gorup6]--><div id="gorup6" class="area"></div><!--[/diy]-->
                    <!--diyarea_280px-->

                    <!--{eval echo wq_buluo_right_url_copy($status);}-->
                    <!--[diy=gorup7]--><div id="gorup7" class="area"></div><!--[/diy]-->
                    <!--diyarea_280px-->

                    <!--{eval echo wq_buluo_hot_topic($groupcache,$status,$newuserlist,$activityuserlist,$groupviewed_list,$action);}-->
                    <!--{if CURMODULE == 'group'}--><!--{hook/group_side_top}--><!--{else}--><!--{hook/forumdisplay_side_top}--><!--{/if}-->
                    <!--[diy=gorup8]--><div id="gorup8" class="area"></div><!--[/diy]-->
                    <!--diyarea_280px-->

                    <!--{if CURMODULE == 'group'}--><!--{hook/group_side_bottom}--><!--{else}--><!--{hook/forumdisplay_side_bottom}--><!--{/if}-->
                </div>
                <!--right end-->

                <!--left start-->
                <div  class="group_in">
                    <div class="per_con">
                        <!--[diy=gorup2]--><div id="gorup2" class="area"></div><!--[/diy]-->
                        <!--diyarea_710px-->

                        <!--{subtemplate wq_buluo:group/group_list}-->
                        <!--[diy=gorup3]--><div id="gorup3" class="area"></div><!--[/diy]-->
                        <!--diyarea_710px-->

                        <!--{hook/forumdisplay_postbutton_bottom}-->

                        <!--{if $html}-->
                            {$html}
                            <div class="wqpc_separate"></div>
                            <!--[diy=gorup5]--><div id="gorup5" class="area"></div><!--[/diy]-->
                            <!--diyarea_710px-->
                        <!--{/if}-->

                        <!--{if $_G['setting']['fastpost']}-->
                            <!--{template wq_buluo:group/forumdisplay_fastpost}-->
                            <!--[diy=gorup4]--><div id="gorup4" class="area"></div><!--[/diy]-->
                            <!--diyarea_710px-->
                        <!--{/if}-->
                    </div>
                </div>
                <!--left end-->
            </div>
        <!--{elseif $action == 'memberlist'}-->
            <!--{subtemplate wq_buluo:group/group_memberlist}-->
        <!--{elseif $action == 'create'}-->
            <!--{subtemplate wq_buluo:group/group_create}-->
        <!--{elseif $action == 'invite'}-->
            <!--{subtemplate wq_buluo:group/group_invite}-->
        <!--{elseif $action == 'manage'}-->
            <!--{subtemplate wq_buluo:group/group_manage}-->
        <!--{/if}-->

        <!--{if CURMODULE == 'group'}--><!--{hook/group_bottom}--><!--{else}--><!--{hook/forumdisplay_bottom}--><!--{/if}-->
    </div>

    <script>
        function succeedhandle_wq_join(url, msg, param) {
            hideWindow('wq_join');
            var fun = '';
            if (wqjq.trim(msg) == '{$Tlang[3f043f93b49a94fc]}') {
                fun = function () {
                    location.href = url;
                }
            }
            showDialog(msg, 'right', '', fun, 0,'', '', '', '','', '2');
        }
    </script>

    <div class="wp wqwidth1000 <!--{if $action == 'manage'}-->wqwidth1200<!--{/if}--> mtn"<!--{if !$pc_is_headbottom}--> style="width:1000px;"<!--{/if}-->>
        <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->
    </div>

<!--{template wq_buluo:common/tpl_footer}-->