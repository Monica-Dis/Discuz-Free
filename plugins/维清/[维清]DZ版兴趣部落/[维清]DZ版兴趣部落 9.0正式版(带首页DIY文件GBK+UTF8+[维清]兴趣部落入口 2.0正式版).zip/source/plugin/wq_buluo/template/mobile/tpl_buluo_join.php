<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<form method="post" id='wqv_join' action="buluo.php?mod=group&action=join">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="fid" value="{$fid}"/>
    <input type="hidden" name="vtype" value="view"/>
    <div class="wq_frame">
        <h3 class="split_title">&#x662F;&#x5426;&#x52A0;&#x5165;&#x90E8;&#x843D;</h3>
        <div class="btn_group">
            <button class="btn" type="button"  onclick="popup.close()">{$Plang['9c825be7149e5b97']}</button>
            <button class="btn btn_import formdialog">{$Plang['387e9a577ee04ca3']}</button>
        </div>
    </div>
</form>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->