<?php exit("From: DisM.taobao.com"); ?>
{eval
    function wq_buluo_right_qrcode(){
        global $_G;
        $url=$_G['siteurl'] . 'forum.php?mod=group&fid='.$_G[fid];
	$img_url = wq_buluo_qrcode_generate($url, 'qrcode', $_G[fid]);
}
        <div>
            <div class="code_div">
                    <h3>{lang scan_code_tribe}</h3>
                    <p class="phone_bg"><img class="code_ewm" src="{$img_url}"><span class="code_logo"><img src="$_G[forum][icon]"></span></p>
            </div>
        </div>
{eval
    }
    function wq_buluo_right_url_copy($status){
        global $_G;
}
        <div class="bm wqpc_groupright">
            <div class="bm_h cl bm_h_right">
                    <h2>{lang group_url}</h2>
            </div>
            <div class="bm_c">
                <p>
                    <!--{if $_G['setting']['allowgroupdomain'] && !empty($_G['setting']['domain']['root']['group']) && !empty($_G['forum']['domain'])}-->
                    <a href="http://{$_G[forum][domain]}.{$_G['setting']['domain']['root']['group']}" id="group_link"></a>
                    <!--{else}-->
                    <a href="buluo.php?mod=group&fid={$_G[fid]}" id="group_link"></a>
                    <!--{/if}-->
                    [<a href="javascript:;" onclick="setCopy($('group_link').href, '{lang group_url_copy_finished}')" class="xi2">{lang copy}</a>]
                </p>
                <script type="text/javascript">$('group_link').innerHTML = $('group_link').href</script>
                <p class="ptn xg1">$_G[forum][foundername] {lang create_on} $_G[forum][dateline]</p>
                <!--{if $status == 'isgroupuser'&&$_G[uid]!=$_G[forum][founderuid]}-->
                    <p class="ptn group_add_btn">
                        <a onclick="showDialog('{lang group_exit_confirm}', 'confirm', '', function () {
                            showWindow('wq_out', 'forum.php?mod=group&action=out&fid=$_G[fid]')
                        })" href="javascript:;" class="xi2">{lang group_exit}</a>
                    <p>
                    <script>
                        function succeedhandle_wq_out(url, msg, param) {
                            hideWindow('wq_out');
                            var fun = '';
                            if (wqjq.trim(msg) == '{$Tlang[0d2e2419a4e975f4]}') {
                                    fun = function() {
                                            location.href = url;
                                    }
                            }
                            showDialog(msg, 'right', '', fun, 0, '', '', '', '', '', '2');

                        }
                    </script>
                <!--{/if}-->
            </div>
        </div>
{eval
    }
    function wq_buluo_hot_topic($groupcache,$status,$newuserlist,$activityuserlist,$groupviewed_list,$action){
        global $_G;
}
        <!--{if $action == 'index'}-->
        <div class="bm bml tns">
                <table cellpadding="4" cellspacing="0" border="0">
                    <tr>
                        <th><p>$_G[forum][posts]</p>{lang posts}</th>
                        <th><p>$_G[forum][membernum]</p>{lang member}</th>
                        <td><p>$groupcache[ranking][data][today]</p>{lang group_member_rank}</td>
                    </tr>
                </table>
            </div>
            <!--{hook/group_index_side}-->
            <!--{if $status != 2 && $status != 3}-->
                <div class="bm">
                    <ul class="tb tb_h cl">
                        <li class="a" id="new" onmouseover="this.className = 'a';
                                $('top').className = '';
                                $('newuserlist').style.display = 'block';
                                $('topuserlist').style.display = 'none';"><a href="javascript:;">{lang group_member_new}</a></li>
                        <li id="top" onmouseover="this.className = 'a';
                                $('new').className = '';
                                $('topuserlist').style.display = 'block';
                                $('newuserlist').style.display = 'none';"><a href="javascript:;">{lang group_member_active}</a></li>
                    </ul>
                    <div class="bm_c">
                        <ul class="ml mls cl" id="newuserlist" style="display:block;">
                            <!--{loop $newuserlist $user}-->
                            <li>
                                <a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{elseif $user['level'] == 3}{lang group_star_member_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt" c="1">
                                    <!--{if $user['level'] == 1}-->
                                    <em class="gm"></em>
                                    <!--{elseif $user['level'] == 2}-->
                                    <em class="gm" style="filter: alpha(opacity=50); opacity: 0.5"></em>
                                    <!--{elseif $user['level'] == 3}-->
                                    <em class="gs"></em>
                                    <!--{/if}-->
                                    <!--{if $user['online']}-->
                                    <em class="gol"{if $user['level'] <= 3} style="margin-top: 15px;"{/if}></em>
                                    <!--{/if}-->
                                    <!--{echo avatar($user[uid], 'small')}-->
                                </a>
                                <p>
                                    <a href="home.php?mod=space&uid=$user[uid]">$user[username]</a>
                                </p>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <ul class="ml mls cl" id="topuserlist" style="display:none;">
                            <!--{loop $activityuserlist $user}-->
                            <li>
                                <a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{elseif $user['level'] == 3}{lang group_star_member_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt" c="1">
                                    <!--{if $user['level'] == 1}-->
                                    <em class="gm"></em>
                                    <!--{elseif $user['level'] == 2}-->
                                    <em class="gm" style="filter: alpha(opacity=50); opacity: 0.5"></em>
                                    <!--{elseif $user['level'] == 3}-->
                                    <em class="gs"></em>
                                    <!--{/if}-->
                                    <!--{if $user['online']}-->
                                    <em class="gol"{if $user['level'] <= 3} style="margin-top: 15px;"{/if}></em>
                                    <!--{/if}-->
                                    <!--{echo avatar($user[uid], 'small')}-->
                                </a>
                                <p>
                                    <a href="home.php?mod=space&uid=$user[uid]">$user[username]</a>
                                </p>
                            </li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>

                <!--{if $groupviewed_list}-->
                    <div class="bm wqpc_groupright">
                        <div class="bm_h cl bm_h_right">
                            <h2>{lang group_visited}</h2>
                        </div>
                        <div class="bm_c">
                            <ul class="ml mls cl">
                                <!--{loop $groupviewed_list $groupid $group}-->
                                <li>
                                    <a href="forum.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a>
                                    <p><a href="forum.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></p>
                                    <span>$group[membernum]</span>
                                </li>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>
                <!--{/if}-->
            <!--{/if}-->
        <!--{elseif $action == 'list'}-->
                <!--{if $groupcache['replies']['data']}-->
                    <div class="bm wqpc_groupright">
                        <div class="bm_h cl bm_h_right">
                            <h2>{lang group_hot_topics_today}</h2>
                        </div>
                        <div class="discuss_topic">
                            <ul class="xl xl1">
                                <!--{loop $groupcache['replies']['data'] $tid $thread}-->
                                <li><a href="buluo.php?mod=viewthread&tid=$tid">$thread[subject]</a></li>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>
                <!--{/if}-->
                <!--{if $groupcache['digest']['data']}-->
                    <div class="bm wqpc_groupright">
                        <div class="bm_h cl bm_h_right">
                            <h2>{lang group_digest_recommend}</h2>
                        </div>
                        <div class="bm_c">
                            <ul class="xl xl1">
                                <!--{loop $groupcache['digest']['data'] $tid $thread}-->
                                <li><a href="forum.php?mod=viewthread&tid=$tid">$thread[subject]</a></li>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>
                <!--{/if}-->
        <!--{/if}-->
{eval
    }
}