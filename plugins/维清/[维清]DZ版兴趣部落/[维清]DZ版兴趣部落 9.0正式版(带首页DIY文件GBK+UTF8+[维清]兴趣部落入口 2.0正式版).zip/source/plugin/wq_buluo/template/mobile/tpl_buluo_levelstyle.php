<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_slide=1;$my_group_tag='my_group_tag';}-->

<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{template common/slide}-->
<!--{else}-->
    <!--{template common/wq_buluoslide}-->
<!--{/if}-->
<div class="sign_grade" id="wq_levelstyle_list">
    <ul>
        <!--{loop $wq_buluo_level[style]  $key $val}-->
        <!--{if $val[type]==0}-->
        <!--{eval $wqstyle[$key]=$val;}-->
        <li {if $key==$lid}class="a"{/if} data="$key">$val[name]</li>
        <!--{/if}-->
        <!--{/loop}-->
        <li data="0" {if !$lid||($lid && $wq_buluo_level[style][$lid][type]==1)}class="a"{/if}>&#x81EA;&#x5B9A;&#x4E49;</li>
    </ul>
</div>
<form id="wq_levelstyle_sets" action="buluo.php?mod=group&action=manage&fid=$_G[fid]&suboperation=levelstyle" method="POST">
    <input type="hidden" name="formhash" value="{FORMHASH}"/>
    <input type="hidden" name="fid" value="{$_G[fid]}"/>
    <input type="hidden" name="levelsubmit" value="yes"/>
    <input type="hidden" id="wq_lid" name="lid" value="$lid"/>
    <div class="grade_right">
        <div class="scrol_wrapper" id="group_index">
            <table class="edit_name_list wq_level_list " id="wq_levelstyle_0" {if $wq_buluo_level[style][$lid][type]==='0'}style="display: none;"{/if}>
                   <!--{loop $wq_buluo_level[level]  $key $val}-->
                <tr>
                    <td><span class="prevent_default buluo-dislv{$wq_buluo_level[level][$key][class]} f14">{$wq_buluo_level[prefix]}{$key}</span></td>
                    <td><input type="text" name="level[$key]" class="edit_name f16" value="{$wq_buluo_level[style][$lid][content][$key]}"/></td>
                </tr>
                <!--{/loop}-->
            </table>
            <!--{loop  $wqstyle $key $val}-->
            <table class="sign_grade_list wq_level_list" id="wq_levelstyle_{$key}" {if $key!=$lid}style="display: none;"{/if}>
                   <!--{loop $val[content]  $key $val}-->
                   <tr>
                    <td><span class="prevent_default buluo-dislv{$wq_buluo_level[level][$key][class]} f14">{$wq_buluo_level[prefix]}{$key}</span></td>
                    <td class="signon">{$val}</td>
                </tr>
                <!--{/loop}-->
            </table>
            <!--{/loop}-->
        </div>
    </div>
    <div class="group_h44"></div>

    <div class="sign_grade_btn"><button class="pn pnc formdialog">&#x4FDD;&#x5B58;</button></div>
</form>
<script>
    function succeedhandle_wq_levelstyle_sets(url, msg, param) {
        if ($.trim(msg) == "{$Tlang['45tcdffc8ac7f983']}") {
            clearInterval(setTimeout_location)
            if (param['lid']) {
                var tds = $('#wq_levelstyle_' + param['lid'] + ' .signon');
                var inputs = $('#wq_levelstyle_0 input');
                inputs.each(function(i) {
                    $(this).val(tds.eq(i).text());
                });
            }
            setTimeout(function() {
                popup.close();
            }, '1000');
        }
    }
    $('#wq_levelstyle_list li').click(function() {
        var data = $(this).attr('data');
        $('#wq_levelstyle_list li').removeClass('a');
        $(this).addClass('a');
        $('.wq_level_list').hide();
        $('#wq_levelstyle_' + data).show();
        $('#wq_lid').val(data);
    });
</script>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->