<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_buluo:common/tpl_header}-->
    <script src="source/plugin/wq_buluo/static/js/wqxml.js?{VERHASH}" type="text/javascript"></script>
    <!--{ad/text/wp a_t}-->
    <style id="diy_style" type="text/css"></style>
    <div class="group_in_con wqwidth1000">
        <!--[diy=diy20]--><div id="diy20" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->

        <div class="group_in_left">
            <!--{eval
                $last_fid = 'wq_cache_buluo_last_fid_' . $_G['uid'];
                loadcache(array($last_fid));
                $wq_my_group = wq_buluo_get_user_group_info(true);
                $group_fid =  $wq_my_group ? $wq_my_group[0] : '';
                $manage_fid = !empty($_G['cache'][$last_fid]) ? $_G['cache'][$last_fid] : $group_fid;
            }-->

            <!--{if !$_G['uid'] || $wq_my_group || $wq_buluo[pc_is_creat] || $wq_buluo[pc_is_headbottom]}-->
                <div class="wqgroup_in_btn">
                    <ul>
                        <!--{if $wq_buluo[pc_is_creat] || $wq_buluo[pc_is_headbottom]}-->
                            <li class="wqgroup_in_li"  <!--{if !$wq_my_group && $_G['uid']}-->style="width:280px;"<!--{/if}-->>
                                <a href="buluo.php?mod=group&action=create"target="_blank">{$Tlang[ee7ab986b2f592ce]}</a>
                            </li>
                        <!--{/if}-->

                        <!--{if ($wq_my_group && $_G['uid']) || !$_G['uid']}-->
                            <li class="wqgroup_in_li wqbg" <!--{if !$wq_buluo[pc_is_creat] && !$wq_buluo[pc_is_headbottom]}-->style="width:280px; margin-left: 0px;"<!--{/if}-->>
                                <a href="buluo.php?mod=group&action=manage&fid=$manage_fid"target="_blank" >{$Tlang[bb28101a9c2926bf]}</a>
                            </li>
                        <!--{/if}-->
                    </ul>
                </div>
            <!--{/if}-->

            <!--{if $_G['uid']}-->
                <!--[diy=diy5]--><div id="diy5" class="area"></div><!--[/diy]-->
                <!--diyarea_280px-->

                <!--{eval $group = get_data_for_index($_G['uid']);}-->
                <!--{eval $groupuser_extinfo =  C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_all_by_uid($_G['uid']);}-->
                <div class="mine">
                    <div class="clearfix">
                        <div class="profile">
                            <div class="bg"></div>
                            <div class="avatar">
                              <a href="buluo.php?mod=my&view=mythread"><img src="{avatar($_G[uid], small, true)}"></a>
                            </div>
                            <div class="name"> <a href="buluo.php?mod=my&view=mythread">$_G[username]</a></div>
                            <div class="tribes">
                                <span>{$Tlang[fc19491b91ee8f68]}</span>
                                <span><!--{if $group}--><!--{eval echo count($group)}--><!--{else}--> 0<!--{/if}--></span>
                            </div>
                        </div>
                    </div>
                    <!--{if $group}-->
                        <!--{eval $wq_time = strtotime(date('Y-m-d')); $yesterday=$wq_time- 24 * 60 * 60;}-->
                        <!--{eval $group_one = array_slice($group,0,8);}-->
                        <ul class="my_bar_list">
                            <!--{loop $group_one $val}-->
                                <li class="bar_item">
                                    <a href="buluo.php?mod=group&fid=$val[fid]" target="_blank">
                                        <div class="bar_wrap">
                                            <span class="bar_name" title="{$val[name]}">{$val['name']}</span>
                                            <!--{if $groupuser_extinfo[$val[fid]][lastsign]==$wq_time||$groupuser_extinfo[$val[fid]][lastsign]==$yesterday}-->
                                                <span class="continue_wrap{if $groupuser_extinfo[$val[fid]][lastsign] != $wq_time}2{/if}">{$groupuser_extinfo[$val[fid]][signdays]}</span>
                                            <!--{/if}-->
                                        </div>
                                    </a>
                                </li>
                            <!--{/loop}-->
                        </ul>

                        <!--{if  count($group) > 8 && $group }-->
                            <!--{eval $group_all = array_slice($group,8);}-->
                            <div class="panel_wrapper" >
                                <div class="more_bar" id="more_bar">{$Tlang[db9c470ab0853172]}<i class="iconfont f12">&#xe626;</i>
                                    <div class="panel" id="idfollow" style="display:none;"><div class="panel_title">{$Tlang[bd46376eb1d9acda]}</div>
                                        <ul>
                                            <!--{loop $group_all $val}-->
                                                <li class="bar_item">
                                                    <a target="_blank" href="buluo.php?mod=group&fid=$val[fid]">
                                                        <div class="bar_wrap">
                                                            <span class="bar_name" title="{$val[name]}">{$val['name']}</span>
                                                            <!--{if $groupuser_extinfo[$val[fid]][lastsign]==$wq_time||$groupuser_extinfo[$val[fid]][lastsign]==$yesterday}-->
                                                                <span class="continue_wrap{if $groupuser_extinfo[$val[fid]][lastsign] != $wq_time}2{/if}">{$groupuser_extinfo[$val[fid]][signdays]}</span>
                                                            <!--{/if}-->
                                                        </div>
                                                    </a>
                                                </li>
                                            <!--{/loop}-->
                                        </ul>
                                    </div>
                                    <div class="bottom-shadow">
                                    </div>
                                </div>
                            </div>

                            <script language="javascript">
                                document.getElementById("more_bar").onmouseout = function() {
                                    document.getElementById("idfollow").style.display = "none";
                                    document.getElementById("more_bar").style.color = "#888";
                                }
                                document.getElementById("more_bar").onmouseover = function() {
                                    document.getElementById("idfollow").style.display = "block";
                                    document.getElementById("more_bar").style.color = "#01a9e9";
                                }
                                document.getElementById("wqrecent_visit").onmouseout = function() {
                                    document.getElementById("wqrecent_visit_menu").style.display = "none";
                                }
                                document.getElementById("wqrecent_visit").onmouseover = function() {
                                    document.getElementById("wqrecent_visit_menu").style.display = "block";
                                }
                            </script>
                        <!--{/if}-->
                    <!--{/if}-->
                </div>
            <!--{/if}-->

            <!--[diy=diy6]--><div id="diy6" class="area"></div><!--[/diy]-->
            <!--diyarea_280px-->
            <div class="group_ass_list">
                <h3>{$Tlang[d5c3dbd657f094ac]}</h3>
                <!--{loop $first $groupid $group}-->
                <a href="buluo.php?gid=$groupid" target="_blank"><em>$group[name]</em></a>
                <!--{/loop}-->
            </div>
            <!--[diy=diy7]--><div id="diy7" class="area"></div><!--[/diy]-->
            <!--diyarea_280px-->

            <!--{eval
                $groupviewed = getcookie('groupviewed');
                $groupviewed = $groupviewed ? explode(',', $groupviewed) : '';
                $groupview = wq_buluo_forum(array('name','fid'),$groupviewed,'');
            }-->
            <!--{if $groupviewed}-->
                <div class="mine wq_recent_visit">
                    <h3>{$Tlang[259ea89a0f51960a]}</h3>
                    <ul class="my_bar_list">
                        <!--{loop $groupview $key $val}-->
                            <li class="bar_item">
                                <a href="buluo.php?mod=group&fid=$val[fid]" target="_blank">
                                    <div class="bar_wrap">
                                        <span class="bar_name" title="$val[name]">$val[name]</span>
                                    </div>
                                </a>
                            </li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <!--[diy=diy10]--><div id="diy10" class="area"></div><!--[/diy]-->
            <!--{/if}-->
              <!--diyarea_280px-->
        </div>

        <div class="group_in_right">
            <script type="text/javascript" src="source/plugin/wq_buluo/static/js/lrtk.js?{VERHASH}"></script>

            <div id="playBox">
                <!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
            </div>

            <div class="groom_tj">
                <div class="groom">
                    <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
                </div>
                <div class="groom m_t10">
                    <!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->
                </div>
            </div>

            <!--[diy=diy8]--><div id="diy8" class="area"></div><!--[/diy]-->
            <!--diyarea_710px-->

            <div class="group_hot_topic">
                <div class="topic_title">
                    <ul>
                        <li class="on" id="newtab"><a href="javascript:;">{$Tlang[c9c4451c3d8bf33e]}</a></li>
                        <li id="hottab"><a href="javascript:;">{$Tlang[045dff303a1b3516]}</a></li>
                        <span style="display: none" id="datatype" data-id="new"></span>
                    </ul>
                </div>
                <div class="topic_con">
                    <ul id="topic_con">
                    </ul>
                    <!--//main-->
                </div>
                <div class="p_load_more" style="display: none;" >{$Tlang[aa105da17bab6f6c]}</div>
            </div>

            <!--[diy=diy9]--><div id="diy9" class="area"></div><!--[/diy]-->
            <!--diyarea_710px-->
        </div>
    </div>

    <script>
        var scroll_locked = true;
        var obj = wqjq('#topic_con');

        wq_window_height = wqjq(window).height();
        wqjq(window).bind('scroll', function() {
            var count = obj.attr('count');
            var perpage = obj.attr('perpage');
            var page = obj.attr('page');
            if (scroll_locked && wqjq(document).scrollTop() + wq_window_height > wqjq(document).height() - 200) {
                scroll_locked = false;
                var data = wqjq('#topic_con li:last').attr('data');
                var type = wqjq('#datatype').attr('data-id');
                if (data) {
                    loadthread(data, type, 0);
                }
            }
        });

        wqjq("#hottab").bind('click', function() {
            wqjq("#newtab").removeClass("on");
            wqjq("#hottab").addClass("on");
            wqjq("#datatype").attr("data-id", "hot");
            scroll_locked = false;
            wqjq(".p_load_more").hide();
            loadthread('', 'hot', '1');
        });

        wqjq("#newtab").bind('click', function() {
            wqjq("#hottab").removeClass("on");
            wqjq("#newtab").addClass("on");
            wqjq("#datatype").attr("data-id", "new");
            scroll_locked = false;
            wqjq(".p_load_more").hide();
            loadthread('', 'new', '1');
        });

        function loadthread(tid, type, isreplace) {
            tid = tid ? tid : 0;
            var url = "plugin.php"
            url = url.replace('page=', '');
            wqjq.ajax({
                url: url,
                data: {id: "wq_buluo", tid: tid, type: type, inajax: 1},
                dataType: 'html',
                success: function(s) {
                    s = wqXml(s);
                    if (wqjq.trim(s)) {
                        if (isreplace == '1') {
                            $("topic_con").innerHTML = s;
                            scroll_locked = true;
                            imgSize()
                        } else {
                            obj.append(s);
                            scroll_locked = true;
                            imgSize()
                        }
                    } else {
                        if (isreplace == '1') {
                            $("topic_con").innerHTML = "<li style='text-align:center;min-height:170px;line-height:60px;'>{$Tlang[1834341b7446b23b]}</li>";
                            scroll_locked = false;
                        } else {
                            wqjq(".p_load_more").show();
                        }
                    }
                }
            });
        }
        loadthread('', 'new', 1);

        function wqc_buluo_index_get_img_width_and_height(imgurl,datatid,data){
            var img = new Image();
            img.src = imgurl;
            img.onload = function(){
                var imgwidth = img.width;
                var imgheight = img.height;
                var divh = 130;
                var divw = 130;
                if (imgwidth > imgheight) {
                    var dataheight = divh;
                    var datawidth = (divh * imgwidth) / imgheight;
                    var dataleft = -(datawidth - divw) / 2;
                    var datatop = 0;
                } else if (imgheight > imgwidth) {
                    var datawidth = divw;
                    var dataheight = (divw * imgheight) / imgwidth;
                    var datatop = -(dataheight - divh) / 2;
                    var dataleft = 0;
                } else {
                    var datawidth = divh;
                    var dataheight = divh;
                    var datatop = 0;
                    var dataleft = 0;
                }
                wqjq("#wqc_pc_css_"+datatid+"_"+data).css("height",dataheight+"px");
                wqjq("#wqc_pc_css_"+datatid+"_"+data).css("margin-top",datatop+"px");
                wqjq("#wqc_pc_css_"+datatid+"_"+data).css("width",datawidth+"px");
                wqjq("#wqc_pc_css_"+datatid+"_"+data).css("margin-left",dataleft+"px");
            };
        }
        function imgSize() {
            var arr = wqjq('.img-box.small.disable-cusor img')
            var imgurl, datatid, data
            for (var i = 0; i < arr.length; i++) {
                if (arr.eq(i).attr('data-loaded') === 'false') {
                    imgurl = arr.eq(i).data('src')
                    datatid = arr.eq(i).data('tid')
                    data = arr.eq(i).attr('data')
                    wqc_buluo_index_get_img_width_and_height(imgurl,datatid,data)
                }
            }
        }
    </script>
<!--{template wq_buluo:common/tpl_footer}-->