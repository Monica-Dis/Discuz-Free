<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $setting[mobile_header]==0}--> <!--{eval $header_nav = $header_nav_app = 'null';}--> <!--{/if}-->
<!--{if $wq_touch}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->

<!--{template group/index_nav}-->
<div class="page_user">
    <div class="my_in_head">
        <div class="head_img">
            <a href="plugin.php?id=wq_buluo&mod=card"><img src="{avatar($_G['uid'], small, true)}"></a>
        </div>
        <div class="follow_head">
            <ul>
                <a href="plugin.php?id=wq_buluo&mod=follow&do=following&uid=$space[uid]">
                    <li class="number">{$space['following']}</li>
                    <li class="desc">{$Plang['2c8a07313e7706bc']}</li>
                </a>
            </ul>
            <div class="follow_line"></div>
            <ul>
                <a href="plugin.php?id=wq_buluo&mod=follow&do=follower&uid=$space[uid]">
                    <li class="number">{$space['follower']}
                        <!--<span class="groupbg_red">+1</span>-->
                    </li>
                    <li class="desc">{$Plang['bbd702ca1f76841a']}</li>
                </a>
            </ul>
            <div class="follow_line"></div>
            <ul>
                <a href="plugin.php?id=wq_buluo&mod=card&op=group&uid=$space[uid]">
                    <li class="number">$group_count</li><li class="desc">{$Plang['e32dd69276b0752d']}</li>
                </a>
            </ul>
        </div>
    </div>
</div>
<div class="my_notice_lump b_top">
    <div class="my_notice"><a href="home.php?mod=space&do=notice"><i class="wqiconfont wqicon-xinfeng1 wq_f24"></i>{$Plang['25b64d46f3b70703']}<span class="wqiconfont wqicon-youyou"></span></a></div>
</div>
<div class="recent_visit">
    <h3 id="wq_recent_visit" class="b_bottom">{$Plang['259ea89a0f51960a']}
        <!--{if $group}-->
        <span><a onclick='wq_del_recent_visit()' href="javascript:;"><i class="wqiconfont wqicon-shanchu"></i></a></span>
        <!--{/if}-->
    </h3>
    <h3 id="wq_del_log" style="display: none;">{$Plang['8a0b8aed30be2adf']}<em><a onclick='wq_del_recent_visit()'  href="javascript:;">{$Plang['3280829519230622']}</a></em><em><a id="wq_empty" href="#">{$Plang['4dfa120403767a13']}</a></em></h3>
    <!--{if $group}-->
    <ul id="wq_group_log">
        <!--{eval $wq_time = strtotime(date('Y-m-d'));
          $yesterday=$wq_time- 24 * 60 * 60;}-->
        <!--{loop $groupviewed  $key $val}-->
        <!--{if $group[$val]}-->
        <li id="wq_group_{$val}">
            <div class="label" data='$val'>
                <a href="buluo.php?mod=group&fid=$group[$val][fid]">
                    <p class="calendar_width">$group[$val][name]</p>
                    <!--{if $groupuser_extinfo[$group[$val][fid]][lastsign]==$wq_time||$groupuser_extinfo[$group[$val][fid]][lastsign]==$yesterday}-->
                    <div class="sign wq_sign_js"><span class="continue-oneday{if $groupuser_extinfo[$group[$val][fid]][lastsign]!=$wq_time}2{/if}"><span>$groupuser_extinfo[$group[$val][fid]][signdays]</span></span></div>
                    <!--{/if}-->
                    <span class="close_width wq_delbutton_js" style='display: none'><i class="wqiconfont wqicon-icon32"></i></span>
                </a>
            </div>
        </li>
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <!--{else}-->
    <p class="emp"><span class="no_content"><img src="{$_G['style']['styleimgdir']}mobile/images/no_content.png"></span>{$Plang['8056defffb7153f4']}</p>
    <!--{/if}-->
</div>
<script>
    function wq_del_recent_visit() {
        $('#wq_recent_visit,#wq_del_log,.wq_delbutton_js,.wq_sign_js').toggle();
        $('#wq_group_log .label').toggleClass('wq_label');
    }
    $('#wq_group_log').on('click', '.wq_label', function() {
        var fid = $(this).attr('data');
        $.post('plugin.php?id=wq_buluo&mod=user&aciton=del&fid=' + fid, {}, function(s) {
            if (s) {
                $('#wq_group_' + fid).remove();
            }
            if (!$('#wq_group_log li').length) {
                wq_del_recent_visit();
                $('#wq_group_log').replaceWith('<p class="emp"><span class="no_content"><img src="{$_G[style][styleimgdir]}mobile/images/no_content.png"></span>{$Plang[8056defffb7153f4]}</p>');
                $('#wq_recent_visit span').remove();
            }
        }, 'text');
        return false;
    });
    $('#wq_empty').on('click', function() {
        $.post('plugin.php?id=wq_buluo&mod=user&aciton=empty', {}, function(s) {
            if (s) {
                wq_del_recent_visit();
                $('#wq_group_log').replaceWith('<p class="emp"><span class="no_content"><img src="{$_G[style][styleimgdir]}mobile/images/no_content.png"></span>{$Plang[8056defffb7153f4]}</p>');
                $('#wq_recent_visit span').remove();
            }
        }, 'text');
        return false;
    });
</script>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->