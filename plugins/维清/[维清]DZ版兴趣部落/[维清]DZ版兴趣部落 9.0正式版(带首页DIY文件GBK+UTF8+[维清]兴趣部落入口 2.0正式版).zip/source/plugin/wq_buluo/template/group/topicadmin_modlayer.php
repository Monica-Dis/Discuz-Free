<?php exit("From: DisM.taobao.com"); ?>
<div id="mdly" style="display: none;{if $_G['forum']['picstyle']} margin-top: 20px;{/if}">
    <input type="hidden" name="optgroup" />
    <input type="hidden" name="operation" />
    <a class="cp" href="javascript:;" title="{lang minimize}" onclick="$('mdly').className = 'cpd'">{$Tlang[d80761bb8e27398f]}</a>
    <input type="checkbox" name="chkall" class="pc weui_check_z" id="chkall" onclick="if (!($('mdct').innerHTML = modclickcount = checkall(this.form, 'moderate'))) {
                    $('mdly').style.display = 'none';
                }" />
    <label class="weui_check_label_z" for="chkall"><i class="iconfont weui_icon_checked_z"></i> {$Tlang[677aa98daaedbce5]}</label>
    <h6><span>{$Tlang[e817a63de5732cff]}</span><strong onclick="$('mdly').className = '';" onmouseover="this.title = '{lang maximize}'" id="mdct"></strong><span>{$Tlang[321fe3143368f345]} </span></h6>
    <p>
        <!--{if $_G['group']['allowdelpost']}-->
        <strong><a href="javascript:;" onclick="tmodthreads(3, 'delete');return false;">{$Tlang[0d9efacf5089d88c]}</a></strong>
        <span class="pipe">|</span>
        <!--{/if}-->
        <!--{if $_G['group']['allowmovethread'] && $_G['forum']['status'] != 3}-->
        <strong><a href="javascript:;" onclick="tmodthreads(2, 'move'); return false;">{$Tlang[ef882d2e4330c3d5]}</a></strong>
        <span class="pipe">|</span>
        <!--{/if}-->
        <!--{if $_G['group']['allowedittypethread']}-->
        <strong><a href="javascript:;" onclick="tmodthreads(2, 'type');return false;">{$Tlang[968265252bbb1364]}</a></strong>
        <!--{/if}-->
        <!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2'))}-->
        <span class="pipe">|</span>
        <strong><a href="javascript:;" onclick="tmodthreads(5, 'recommend_group');return false;">{$Tlang[dd761761184a8e5a]}</a></strong>
        <!--{/if}-->
        <!--{if CURMODULE == 'forumdisplay'}-->
        <!--{hook/forumdisplay_modlayer}-->
        <!--{elseif CURMODULE == 'modcp'}-->
        <!--{hook/modcp_modlayer}-->
        <!--{/if}-->
    </p>
    <p>
        <!--{if $_G['group']['allowstickthread']}-->
        <a href="javascript:;" onclick="tmodthreads(1, 'stick');return false;">{$Tlang[01ff72df2ca84800]}</a>
        <!--{/if}-->
        <!--{if $_G['group']['allowdigestthread']}-->
        <a href="javascript:;" onclick="tmodthreads(1, 'digest'); return false;">{$Tlang[46d1ecf7cc55b12f]}</a>
        <!--{/if}-->
        <!--{if $_G['group']['allowhighlightthread']}-->
        <a href="javascript:;" onclick="tmodthreads(1, 'highlight');return false;">{$Tlang[0933269d57ffe644]}</a>
        <!--{/if}-->
        <!--{if $_G['group']['allowrecommendthread'] && $_G['forum']['modrecommend']['open'] && $_G['forum']['modrecommend']['sort'] != 1}-->
        <a href="javascript:;" onclick="tmodthreads(1, 'recommend');return false;">{$Tlang[db11cdebc2eb37bd]}</a>
        <!--{/if}-->
        <!--{if $_G['group']['allowbumpthread'] || $_G['group']['allowclosethread']}-->
        <span class="pipe">|</span>
        <!--{/if}-->
        <!--{if $_G['group']['allowbumpthread']}-->
        <a href="javascript:;" onclick="tmodthreads(3, 'bump');return false;">{$Tlang[d6c2a3a462639fd9]}</a>
        <!--{/if}-->
        <!--{if $_G['forum']['status'] != 3 && $_G['group']['allowclosethread']}-->
        <a href="javascript:;" onclick="tmodthreads(4);return false;">{$Tlang[98aee07dec3510a5]}</a>
        <!--{/if}-->
    </p>
</div>