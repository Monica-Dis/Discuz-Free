<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<div style=" background: #000; position: fixed; top:0px; left:0px; opacity: 0.8; height: 100%; width: 100%;" onclick="popup.close();"></div>
{$Plang[f64c30e837e3267a]}
<div class="sign_wrap" style="display: block;" onclick="popup.close();">
    <div class="sign_wrap_con">
        <ul>
            <li <!--{if $signdays>=1}-->class="active"<!--{/if}--> style="transform: translate3d(0px, -100px, 0px);">1</li>
            <li <!--{if $signdays>=2}-->class="active"<!--{/if}--> style="transform: translate3d(78.1831px, -62.349px, 0px);">2</li>
            <li <!--{if $signdays>=3}-->class="active"<!--{/if}--> style="transform: translate3d(97.4928px, 22.2521px, 0px);">3</li>
            <li <!--{if $signdays>=4}-->class="active"<!--{/if}--> style="transform: translate3d(43.3884px, 90.0969px, 0px);">4</li>
            <li <!--{if $signdays>=5}-->class="active"<!--{/if}--> style="transform: translate3d(-43.3884px, 90.0969px, 0px);">5</li>
            <li <!--{if $signdays>=6}-->class="active"<!--{/if}--> style="transform: translate3d(-97.4928px, 22.2521px, 0px);">6</li>
            <li <!--{if $signdays>=7}-->class="active"<!--{/if}--> style="transform: translate3d(-78.1831px, -62.349px, 0px);">7</li>
        </ul>
        <div class="sign_tips">
            <p class="f20 m_b15">{$Plang[6d0195f24d06e7fc]}&nbsp;<span class="wq_orange">$signdays</span>&nbsp;{$Plang[007bd5bdbc31a995]}</p>
            <small class="f14">{$Plang[a69c62edba3c5dc1]}</small>
            <p class="m_t5">{$Plang[de1e44f5572b1b85]}<span class="m_l5 wq_orange">+<span class="m_l5 wq_orange">$experience</span></span></p>
        </div>
    </div>
    <i class="close_icon wqiconfont wqicon-guanbi2 wq_f44"></i>
</div>

<!--{if $groupuser_extinfo['lastsign'] != $wq_time}-->
<!--{block actiontitle}--><a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]"><div class="group_info_wrap"><span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level} {$wq_buluo_level[style][$lid][content][$wq_level]}</span><!--{if $wq_buluo_level[level][$wq_level+1][val]}--><!--{eval $width=intval($experience)/intval($wq_buluo_level[level][$wq_level+1][val])*100;}--><div class="group_infobar m_t5"><span style="width:{$width}%;"></span></div><!--{/if}--></div></a><!--{/block}-->
<script>
    $('#wq_sign_level').replaceWith('$actiontitle');
    $('.group_pay a').attr('class', 'btn_focus group_signed dialog').html('<i class="wqiconfont wqicon-yes"></i>{$Plang[a08b091b9ce4c933]}');
</script>
<!--{/if}-->
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->