<?php exit("From: DisM.taobao.com"); ?>
<!--{if !$_GET[api]}-->
    <!--{template wq_buluo:common/tpl_header}-->
<!--{else}-->
    <!--{eval $config_url= DISCUZ_ROOT.'./source/plugin/wq_buluo/template/config/config.php';include $config_url;}-->
<!--{/if}-->
<!--{eval $tids=wq_buluo_tids($threadlist);}-->
<!--{if $tids}-->
<!--{eval $forum_post = DB::fetch_all('SELECT tid,pid FROM ' . DB::table('forum_post') . ' WHERE tid IN(%n) AND first=1 ', array($tids),'tid');}-->
<!--{/if}-->
<!--{block threadlist_lis}-->
<!--{if $threadlist}-->
    <!--{eval  loadcache('stamps');}-->
    <!--{loop $threadlist $thread}-->
        <li class="post">
            <a href="buluo.php?mod=group&fid=$thread[fid]"  class="post_bar" target="_blank">$thread[forumname]</a>
            <a href="buluo.php?mod=viewthread&tid=$thread[tid]" target="_blank">
                <div class="title">
                    <span>
                        <!--{if $thread[icon]!=='' && $thread[icon] >= 0}-->
                            <span class="wqicon_all_14 wqtop_post_span"><img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" /></span>
                        <!--{/if}-->
                        <font  $thread[highlight]>$thread[subject]</font>
                    </span>
                </div>
                <div>
                    <div class="content">
                        <div class="desc" data='$forum_post[$thread[tid]][pid]'>$thread[message]</div>
                        <!--{eval  $images=wq_pc_get_images_by_tid_pids($forum_post[$thread[tid]][pid]);}-->
                        <!--{if $images}-->
                            <div class="imglist_wrap">
                                <!--{loop $images  $key $val}-->
                                    <div class="small"> <img src="$val"></div>
                                <!--{/loop}-->
                            </div>
                        <!--{/if}-->
                    </div>
                    <div class="time">$thread[dateline]</div>
                </div>
            </a>
            <div class="post_right">
                <div class="view-num ov_hd"><i class="iconfont m_r5">&#xe604;</i>$thread[views]</div>
                <div class="comment-num ov_hd"><i class="iconfont m_r5">&#xe603;</i>$thread[replies]</div>
            </div>
        </li>
    <!--{/loop}-->
<!--{/if}-->

<!--{/block}-->
<!--{block grouplist_show}-->
    <!--{if $grouplist}-->
        <!--{if $_G[uid]}-->
            <!--{eval $groupuser=wq_buluo_forum_groupuser(array('fid','level'),$_G[uid]);}-->
        <!--{/if}-->
        <!--{eval $forum_forumfield = DB::fetch_all("SELECT description,jointype,founderuid,fid FROM " . DB::table('forum_forumfield') . " WHERE fid IN(%n)", array(explode(',', $index['ids']['group'])), 'fid');}-->
        <!--{loop $grouplist $group}-->
            <li>
                <div class="barinfo_category">
                    <a href="buluo.php?mod=group&fid=$group[fid]" class="barinfo_category_left" target="_blank"> <img src="$group[icon]"></a>
                    <div class="barinfo_category_right">
                        <a href="buluo.php?mod=group&fid=$group[fid]" class="name ellipsis" target="_blank"> $group[name]</a>
                        <div><span class="pids">{lang member} $group[membernum]</span><span class="fans">{$Tlang[8ea9c932f8444151]} $group[threads]</span></div>
                        <div class="desc">$forum_forumfield[$group[fid]][description]</div>
                    </div>
                    <div class="focus follow" id="join_{$group[fid]}" data="$forum_forumfield[$group[fid]][founderuid]">
                        <!--{if $forum_forumfield[$group[fid]][founderuid]!=$_G[uid]}-->
                        <!--{if $groupuser[$group[fid]][level]===null}-->
                        <a href="forum.php?mod=group&action=join&fid=$group[fid]" data='$group[fid]' jointype='$forum_forumfield[$group[fid]][jointype]' onclick="wq_join_data(this), showWindow('wq_join', this.href)"><span>+</span><em>{$Tlang[876bb8031df32628]}</em></a>
                        <!--{elseif $groupuser[$group[fid]][level]==='0'}-->
                        <a href="forum.php?mod=group&action=out&fid=$group[fid]" data='$group[fid]' onclick="showWindow('wq_out', this.href)"><em class="already_join">{$Tlang[fcce7c30276aa190]}</em></a>
                        <!--{else}-->
                        <a href="javascript:;"><em class="already_join">{$Tlang[b4b0d4ba96890702]}</em></a>
                        <!--{/if}-->
                        <!--{else}-->
                        <a href="javascript:;"><em class="already_join">{$Tlang[b4b0d4ba96890702]}</em></a>
                        <!--{/if}-->
                    </div>
                </div>
            </li>
        <!--{/loop}-->
    <!--{/if}-->
<!--{/block}-->

<!--{if $_GET[api]}-->
    $threadlist_lis
    $grouplist_show
    <!--{eval exit;}-->
<!--{/if}-->

<script>
    var join_data, jointype;
    function  wq_join_data(obj) {
        join_data = wqjq(obj).attr('data')
        jointype = wqjq(obj).attr('jointype');
    }
    function succeedhandle_wq_join(url, msg, param) {
        hideWindow('wq_join');
        if (wqjq.trim(msg) == '{$Tlang[3f043f93b49a94fc]}') {
            var join_msg = jointype == 2 && !'$_G[ismoderator]' ? '{$Tlang[4feb290c5e86a4b8]}' : '{$Tlang[b4b0d4ba96890702]}';
            wqjq('#join_' + join_data).html("<a href=\"javascript:;\"><em class=\"already_join\">" + join_msg + "</em>")
        }
        showDialog(msg, 'alert', '', '', 0, '', '', '', '', '2');
    }
    var wq_window_height = wqjq(window).width();
    function wq_touch_ajax_scroll(page, count, perpage, url, id, botton, successfun) {
        var wq_scroll_locked = true;
        botton = botton ? botton : 0;
        count = parseInt(count);
        perpage = parseInt(perpage);
        page = parseInt(page);
        wqjq(window).bind('scroll', function () {
            if (wq_scroll_locked && count / perpage > page && wqjq(this).scrollTop() + wq_window_height >= wqjq(document).height() - botton) {
                wq_scroll_locked = false;
                wqjq(".p_load_more").show();
                page++;
                wqjq.ajax({
                    type: 'GET',
                    url: url,
                    data: {api: 1, page: page},
                    dataType: 'html',
                    success: function (data) {
                        wqjq('#' + id).append(data);
                        wqjq(".p_load_more").hide();
                        wq_scroll_locked = true;
                        if (typeof successfun == 'function') {
                            eval(successfun(page));
                        }
                        if (perpage * page >= count) {
                            wqjq('.loading').show();
                        }
                    }
                })
            }
        });
    }
</script>

<div class="wpbar_search">
    <div class="bars">
        <!--{ad/search/mtw}-->
        <!--{if !$srchfid}-->
            <div class="search_con">
                <h3>{$Tlang[a07f987252e220fa]}</h3>
                <ul class="search_con_list" id="grouplist_show">
                    <!--{if $grouplist}-->
                        $grouplist_show
                    <!--{else}-->
                        <p class="relevant_group">{$Tlang[7f2f3980c2253291]}</p>
                    <!--{/if}-->
                </ul>
                <!--{if !$viewgroup && $groupnum>count($grouplist)}-->
                    <div class="more_bar_button"><a href="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&viewgroup=1" >{$Tlang[8e930e83fb2c2012]}</a></div>
                <!--{/if}-->
            </div>
        <!--{/if}-->

        <!--{if !$viewgroup}-->
        <div class="group_hot_topic m_t10 postlist_wrap">
            <h3>
                <!--{if $srchfid}-->
                    <!--{eval $forum=$forums[$srchfid]?$forums[$srchfid]:C::t('forum_forum')->fetch($srchfid);}-->
                    <a href="buluo.php?mod=group&fid=$forum[fid]">$forum[name]</a> >
                <!--{/if}-->
                {$Tlang[81d83ffd96c8efbf]}
            </h3>
            <div class="topic_con">
                <ul id="threadlist_lis">
                    <!--{if $threadlist}-->
                        $threadlist_lis
                    <!--{else}-->
                        <li><p class="relevant_group">{$Tlang[85e78cfa80d45672]}</p> </li>
                    <!--{/if}-->
                </ul>
            </div>
        </div>

        <script>
            wq_touch_ajax_scroll('$page', "$index['num']", "$_G['tpp']", 'search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&srchfid=$srchfid', 'threadlist_lis', 186)
        </script>
        <!--{/if}-->
    </div>
</div>

<!--{if $_GET[inajax]}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{if $viewgroup}-->
        <script>
            wq_touch_ajax_scroll('$page', "$groupnum", "$_G['tpp']", 'search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&viewgroup=1', 'grouplist_show', 186)
        </script>
    <!--{/if}-->
    <!--{template wq_buluo:common/tpl_footer}-->
<!--{/if}-->