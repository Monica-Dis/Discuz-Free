<?php exit("From: DisM.taobao.com"); ?>
<!--{eval  loadcache('stamps');}-->
<div id="threadlist" style="position: relative;" class="per_content">
    <div class="post_top">
        <!--{if helper_access::check_module('group')}-->
            <div class="btn_post">
                <a href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid': this.id})" onclick="showWindow('newthread', 'buluo.php?mod=post&action=newthread&fid=$_G[fid]')" title="{lang send_posts}"><i class="iconfont f22">&#xe605;</i>{$Tlang[c0e5b55d87a9643f]}</a>
            </div>
        <!--{/if}-->

        <!--{hook/forumdisplay_postbutton_top}-->
        <!--{eval $html=  wq_buluo_multi($_G['forum_threadcount'], $_G['tpp'], $page, "buluo.php?mod=forumdisplay&fid=$_G[fid]".$forumdisplayadd['page'].($multiadd ? '&'.implode('&', $multiadd) : '').$multipage_archive);}-->
        $html
    </div>
    <form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="listextra" value="$extra" />
        <!--{if $_G['forum_threadcount']}-->
            <!--{eval $toplist = wq_buluo_get_toplist($_G['forum_threadlist']);}-->
            <!--{if $toplist}-->
                <div class="per_top">
                    <ul>
                        <!--{loop $toplist $key $topthread}-->
                        <!--{hook/forumdisplay_thread_mobile $key}-->
                        <li  class="title">
                            <!--{if $_G['forum']['ismoderator']}-->
                            <!--{if $topthread['fid'] == $_G[fid]}-->
                            <!--{if $topthread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
                            <input onclick="tmodclick(this)" type="checkbox" name="moderate[]" id="$topthread[tid]" class="pc weui_check_z" value="$topthread[tid]" />
                            <label class="weui_check_label_z" for="$topthread[tid]"><i class="iconfont weui_icon_checked_z"></i></label>
                            <!--{else}-->
                            <input type="checkbox" disabled="disabled" />
                            <!--{/if}-->
                            <!--{else}-->
                            <input type="checkbox" disabled="disabled" />
                            <!--{/if}-->
                            <!--{/if}-->
                            <a href="buluo.php?mod=viewthread&tid=$topthread[tid]&extra=$extra">
                                <!--{eval $thread_status = wq_thread_status($topthread);}-->
                                $thread_status
                                <!--{eval $wq_top_typehtml = str_replace(array('[', ']','<a','</a>'), array('<span class="wq_typehtml" ', '</span>'), array($topthread[typehtml],$topthread[sorthtml]));;}-->
                                {$wq_top_typehtml[0]}{$wq_top_typehtml[1]}
                                <font $topthread[highlight]>{$topthread[subject]}</font>
                            </a>
                        </li>
                        <!--{/loop}-->
                    </ul>
                </div>
            <!--{/if}-->
        <!--{/if}-->

        <div class="topic_con">
            <ul>
                <!--{if $_G['forum_threadcount']}-->
                    <!--{eval $tids = wq_buluo_tids($threadlist); $info=wq_pc_get_forum_post_data($tids);}-->
                    <!--{loop $_G['forum_threadlist'] $key $thread}-->
                        <!--{ad/threadlist}-->
                        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                            <li id="$thread[id]" class="post">

                                <a href="buluo.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank" title="{lang target_blank}">
                                    <div class="title">
                                        <!--{if $_G['forum']['ismoderator']}-->
                                            <!--{if $thread['fid'] == $_G[fid]}-->
                                                <!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
                                                    <span class="post_input">
                                                        <input type="checkbox" onclick="tmodclick(this)"  class="pr weui_check_z" name="moderate[]" id="moderate$thread[tid]" value="$thread[tid]">
                                                        <label class="weui_check_label_z" for="moderate$thread[tid]"><i class="iconfont weui_icon_checked_z wq_ff14"></i></label>


                                                    </span>
                                                <!--{else}-->
                                                    <span class="post_input"><input type="checkbox" disabled="disabled" /></span>
                                                <!--{/if}-->
                                            <!--{else}-->
                                                <span class="post_input"><input type="checkbox" disabled="disabled" /></span>
                                            <!--{/if}-->
                                        <!--{/if}-->

                                        <!--{if $thread[icon]!=='' && $thread[icon] >= 0}-->
                                            <span class="wqicon_all_14 wqtop_post_span"><img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" /></span>
                                        <!--{/if}-->

                                        <!--{eval $thread_status = wq_thread_status($thread);}-->
                                        $thread_status
                                        <span><font $thread[highlight]>$thread[subject]</font></span>

                                        <!--{if $thread['readperm']}-->
                                            - [{lang readperm} <span class="xw1">$thread[readperm]</span>]
                                        <!--{/if}-->

                                        <!--{if $thread['price'] > 0}-->
                                            <!--{if $thread['special'] == '3'}-->
                                                - <span style="color: #ff4e00">[{lang thread_reward}<span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span>
                                            <!--{else}-->
                                                - [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
                                            <!--{/if}-->
                                        <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
                                            - <span style="color: #269F11">[{lang reward_solved}]</span>
                                        <!--{/if}-->

                                        <!--{if $thread['displayorder'] == 0}-->
                                            <!--{if $thread[recommendicon]}-->
                                                <img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
                                            <!--{/if}-->

                                            <!--{if $thread['rate'] > 0}-->
                                                <img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
                                            <!--{/if}-->
                                        <!--{/if}-->
                                    </div>

                                    <div>
                                        <!--{eval
                                            require_once libfile('function/discuzcode');
                                            $info[summarys][$thread[tid]] = discuzcode($info[summarys][$thread[tid]], 0,-1,0, 1, 1, 0, 0, 0, 1, $info[pids][$thread[tid]], 0, $thread['dbdateline'], 1);
                                        }-->
                                        <div class="content">
                                            <div class="desc">
                                                $info[summarys][$thread[tid]]
                                            </div>
                                            <!--{eval $images=wq_buluo_get_images_by_tid_pids($info[pids][$thread[tid]],3,'',$thread[tid]);}-->
                                            <!--{if $images}-->
                                                <div class="imglist_wrap" >
                                                    <!--{loop $images $k $v}-->
                                                    <!--{eval //$data = wqc_calculate_image_size($v);}-->
                                                        <div class="img-box small disable-cusor">
                                                            <img data="{$k}" data-tid="{$thread[tid]}" data-src="{$v[image]}" src="{$v[image]}" id="wqc_pc_css_{$thread[tid]}_{$k}" data-loaded="false" />
                                                        </div>
                                                    <!--{/loop}-->
                                                </div>
                                            <!--{/if}-->
                                        </div>
                                        <div class="time">$thread[dateline]</div>
                                    </div>
                                </a>

                                <div class="post_right">
                                    <div class="post_user ov_hd"><i class="iconfont m_r5">&#xe602;</i>
                                        <!--{if $thread['authorid'] && $thread['author']}-->
                                            <a href="home.php?mod=space&uid=$thread[authorid]">$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}-->$verify[$thread[authorid]]<!--{/if}-->
                                        <!--{else}-->
                                            <!--{if $_G['forum']['ismoderator']}-->
                                                <a href="home.php?mod=space&uid=$thread[authorid]">{lang anonymous}</a>
                                            <!--{else}-->
                                                {lang anonymous}
                                            <!--{/if}-->
                                        <!--{/if}-->
                                    </div>

                                    <div class="view_user ov_hd"><i class="iconfont m_r5">&#xe604;</i>$thread[views]</div>
                                    <div class="comment_user ov_hd"><i class="iconfont m_r5">&#xe603;</i>$thread[replies]</div>
                                </div>
                            </li>
                            <!--{hook/forumdisplay_thread $key}-->
                        <!--{/if}-->
                    <!--{/loop}-->
                <!--{else}-->
                    <tbody><tr><th colspan="6"><p class="emp">{lang forum_nothreads}</p></th></tr></tbody>
                <!--{/if}-->
            </ul>

            <!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
                <!--{template wq_buluo:group/topicadmin_modlayer}-->
            <!--{/if}-->
        </div>
    </form>
</div>

<!--{eval
    $html=wq_buluo_multi($_G['forum_threadcount'], $_G['tpp'], $page, "buluo.php?mod=forumdisplay&fid=$_G[fid]".$forumdisplayadd['page'].($multiadd ? '&'.implode('&', $multiadd) : '').$multipage_archive,1);
}-->

<script>
   wqjq(function () {
        wqjq(".page_list_js").off().hover(function () {
              wqjq(this).children('div').show();
          }, function () {
              wqjq(this).children('div').hide();
          });
      })
</script>

<!--{if helper_access::check_module('group')}-->
    <!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
        <ul class="p_pop" id="newspecial_menu" style="display: none">
            <!--{if !$_G['forum']['allowspecialonly']}-->
                <li><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]" onclick="showWindow('newthread', this.href);doane(event)">{lang post_newthread}</a></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowpostpoll']}-->
                <li class="poll"><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowpostreward']}-->
                <li class="reward"><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowpostdebate']}-->
                <li class="debate"><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowpostactivity']}-->
                <li class="activity"><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowposttrade']}-->
                <li class="trade"><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li>
            <!--{/if}-->

            <!--{if $_G['setting']['threadplugins']}-->
                <!--{loop $_G['forum']['threadplugin'] $tpid}-->
                    <!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
                        <li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url($_G[setting][threadplugins][$tpid][icon])"{/if}><a href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
            <!--{/if}-->
        </ul>
    <!--{/if}-->
<!--{/if}-->

<script>
    function wqc_buluo_index_get_img_width_and_height(imgurl,datatid,data){
        var img = new Image();
        img.src = imgurl;
        img.onload = function(){
            var imgwidth = img.width;
            var imgheight = img.height;
            var divh = 130;
            var divw = 130;
            if (imgwidth > imgheight) {
                var dataheight = divh;
                var datawidth = (divh * imgwidth) / imgheight;
                var dataleft = -(datawidth - divw) / 2;
                var datatop = 0;
            } else if (imgheight > imgwidth) {
                var datawidth = divw;
                var dataheight = (divw * imgheight) / imgwidth;
                var datatop = -(dataheight - divh) / 2;
                var dataleft = 0;
            } else {
                var datawidth = divh;
                var dataheight = divh;
                var datatop = 0;
                var dataleft = 0;
            }
            wqjq("#wqc_pc_css_"+datatid+"_"+data).css("height",dataheight+"px");
            wqjq("#wqc_pc_css_"+datatid+"_"+data).css("margin-top",datatop+"px");
            wqjq("#wqc_pc_css_"+datatid+"_"+data).css("width",datawidth+"px");
            wqjq("#wqc_pc_css_"+datatid+"_"+data).css("margin-left",dataleft+"px");
        };
    }
    var arr = wqjq('.img-box.small.disable-cusor img')
    var imgurl, datatid, data
    for (var i = 0; i < arr.length; i++) {
        if (arr.eq(i).attr('data-loaded') === 'false') {
            imgurl = arr.eq(i).data('src')
            datatid = arr.eq(i).data('tid')
            data = arr.eq(i).attr('data')
            wqc_buluo_index_get_img_width_and_height(imgurl,datatid,data)
        }
    }
</script>