<?php exit("From: DisM.taobao.com"); ?>
<!--{subtemplate common/header_common}-->
    <meta name="application-name" content="$_G['setting']['bbname']" />
    <meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />

    <!--{if $_G['setting']['portalstatus']}-->
        <meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" />
    <!--{/if}-->

    <meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />

    <!--{if $_G['setting']['groupstatus']}-->
        <meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" />
    <!--{/if}-->

    <!--{if helper_access::check_module('feed')}-->
        <meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" />
    <!--{/if}-->

    <script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>

    <!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
        <link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
    <!--{/if}-->

    <!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->

    <!--{if widthauto()}-->
        <link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
        <script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
    <!--{/if}-->

    <!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
    <script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
    <!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
    <script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
    <!--{elseif $_G['basescript'] == 'portal'}-->
    <script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
    <!--{/if}-->

    <!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
        <script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
    <!--{/if}-->

    <script src="./source/plugin/wq_buluo/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>

    <!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
        <link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
    <!--{/if}-->

    <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/css/group.css?{VERHASH}" />
    <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/css/operate_buluo.css?{VERHASH}" />
    <link rel="stylesheet" type="text/css" href="./source/plugin/wq_buluo/static/pc/font/iconfont.css?{VERHASH}" />
</head>

<body class="group_bg">

    <div id="append_parent"></div>
    <div id="ajaxwaitid"></div>

    <!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
        <!--{template common/header_diy}-->
    <!--{/if}-->

    <!--{if check_diy_perm($topic)}-->
        <!--{template common/header_diynav}-->
    <!--{/if}-->

    <!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
        $diynav
    <!--{/if}-->

    <!--{if empty($topic) || $topic['useheader']}-->
        <!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
            <div class="xi1 bm bm_c">{lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a> </div>
        <!--{/if}-->

        <!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
            <div id="shortcut"> <span><a href="group.php" id="shortcutcloseid" title="{lang close}">{lang close}</a></span> {lang shortcut_notice} <a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a> </div>
        <!--{/if}-->

        <!--{if $action == 'manage' && $_G[uid]}-->
            <!--{eval $menutype='a';}-->
            <header>
                <div class="manage_banner manage_header">
                    <div class="manage_warp">
                        <div class="manage_nlogo">
                            <ul>
                                <li>
                                    <a href="group.php" class="bar show"><img src="{$wq_buluo[logo]}"></a>
                                </li>
                                <li><span class="sperator"></span></li><li><span class="bar-tab">{$Tlang[bb28101a9c2926bf]}</span></li>
                            </ul>
                        </div>
                        <div class="manage_ninfo" id="a" onMouseOver="showMenu({'ctrlid': 'a', 'ctrlclass': 'hover', 'duration': 2});">
                            <a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}" class="personalinfo">
                                <div class="slide_down_container user_container"> <!--title_span-->
                                    <div class="headtitle showmenu">
                                        <img  src="{avatar($_G[uid], small, true)}">
                                        <span class="title_span">$_G[username]</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <div class="wqwidth1200">
        <!--{else}-->
            <!--{eval $menutype='m'}-->
            <header >
                <script>
                    wqjq(function() {
                        var nv = wqjq('#buluo_nv').offset().top;
                        wqjq(window).scroll(function() {
                            var m_st = Math.max(document.body.scrollTop || document.documentElement.scrollTop);
                            if (m_st > 90) {
                                wqjq('#buluo_nv').addClass('headfixed');
                            } else {
                                wqjq('#buluo_nv').removeClass('headfixed');
                            }
                        });
                    })
                </script>

                <div class="group_header" id="buluo_nv">
                    <div class="group_wrapper">
                        <!--{eval $mnid = getcurrentnav();}-->
                        <!--{if !isset($_G['setting']['navlogos'][$mnid])}-->
                            <a class="g_logo" href="buluo.php?mod=index" title="$_G['setting']['bbname']"><img src="{$wq_buluo[logo]}"></a>
                        <!--{else}-->
                            $_G['setting']['navlogos'][$mnid]
                        <!--{/if}-->

                        <div class="g_search_box">
                            <form id="searchform" method="post" autocomplete="off" action="buluo.php?mod=group&search=yes" onsubmit="if (!wqjq('#scform_srchtxt').val())
                return false;">
                                <input type="hidden" name="formhash" value="{FORMHASH}"/>
                                <input type="hidden" name="srchfid" value="$srchfid"/>
                                <input type="hidden" name="searchsubmit" value="yes" />
                                <!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
                                <input type="text" id="scform_srchtxt" name="srchtxt" size="65" maxlength="40" value="$keyword" tabindex="1" />
                                <div class="g_search_btn"><button type="submit"  class="iconfont" value="true">&#xe615;</button></div>
                            </form>

                            <!--{eval $search_keyword = $wq_buluo['search_keyword']?explode("\n", str_replace("\r\n", "\n", $wq_buluo['search_keyword'])):'';}-->
                            <!--{if $search_keyword}-->
                                <div id="wq_search_keyword" class="hot_words">
                                    <!--{loop $search_keyword  $key $val}-->
                                        <!--{eval $val= trim($val);}-->
                                        <!--{if $val}-->
                                            <a href="javascript:;">$val</a>
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                </div>

                                <script>
                                    wqjq(function() {
                                        wqjq('#wq_search_keyword a').click(function() {
                                            var keyword = wqjq(this).text();
                                            wqjq('#scform_srchtxt').val(keyword);
                                            wqjq('#searchform').submit();
                                        });
                                    });
                                </script>
                            <!--{/if}-->
                        </div>

                        <div class="links">
                            <!--{if $_G['uid']}-->
                                <a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}" class="personalinfo" id="m" onMouseOver="showMenu({'ctrlid': 'm', 'pos': '34!', 'ctrlclass': 'hover', 'duration': 2});">
                                    <div class="slide_down_container user_container"> <!--title_span-->
                                        <div class="headtitle showmenu">
                                            <img  src="{avatar($_G[uid], small, true)}">
                                            <span class="title_span">$_G[username]</span>
                                        </div>
                                    </div>
                                </a>

                                <!--{eval
                                    $groupviewed = getcookie('groupviewed');
                                    $groupviewed = $groupviewed ? explode(',', $groupviewed) : '';
                                    $groupview =array();
                                }-->

                                <!--{if $groupviewed !=''}-->
                                    <!--{eval $groupview = wq_buluo_forum(array('name','fid'),$groupviewed,'');}-->
                                <!--{/if}-->
								<!--{if $groupview}-->
									<a id="visit" href="javascript:;" class="showmenu" onmouseover="showMenu({'ctrlid': 'visit'})" initialized="true">{$Tlang[259ea89a0f51960a]}</a>
								<!--{/if}-->

                                <!--{if $_G['adminid']!=1&&$_G['adminid']!=2}-->
                                    <!--{eval $manage_groupuser=wq_buluo_groupuser('fid',$_G[uid],array(1,2));}-->
                                    <!--{if $manage_groupuser}-->
                                        <!--{loop  $manage_groupuser   $key $val}-->
                                            <!--{eval $manage_groupid[]=$val[fid];}-->
                                        <!--{/loop}-->

                                        <!--{eval $manage_group = wq_buluo_forum(array('name','fid'),$manage_groupid);}-->
                                        <!--{if $manage_group}-->
                                            <a id="manage" href="javascript:;" class="showmenu" onmouseover="showMenu({'ctrlid': 'manage'})" initialized="true">{$Tlang[75437cdebe66044f]}</a>
                                        <!--{/if}-->
                                    <!--{/if}-->
                                <!--{/if}-->

                            <!--{elseif !empty($_G['cookie']['loginuser'])}-->
                                <ul class="personal_center personal_part">
                                    <li class="personal_list"><a id="loginpersonal" class="personal_link"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
                                    <li class="personal_list"><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)" class="personal_link">{lang activation}</a></li>
                                    <li class="personal_list"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="personal_link" >{lang logout}</a></li>
                                </ul>

                            <!--{elseif !$_G[connectguest]}-->
                                <style type="text/css">
                                    .fastlg_fm{display: none; height: 30px; width:134px; overflow: hidden;margin-right:0px!important; padding-right: 0px!important; border-right: none; margin-top: 6px; float: left}
                                    .fastlg_fm a{ padding-right: 5px;}
                                </style>

                                <!--{hook/global_login_extra}-->
                                <div style="display:none"><!--{template member/login_simple}--></div>

                                <ul class="personal_center personal_part">
                                    <li class="personal_list"><a href="javascript:;" onClick="showWindow('login', 'member.php?mod=logging&action=login');" class="personal_link login">{lang login}</a></li>
                                    <li class="personal_list"><a href="member.php?mod={$_G[setting][regname]}" class="personal_link register">{$Tlang['reg']}</a></li>
                                    <li class="personal_list"><a href="member.php?mod=logging&action=login&viewlostpw=1" onclick="showWindow('login', this.href)" title="{lang forgotpw}">{lang forgotpw}</a></li>
                                </ul>

                            <!--{else}-->
                                <ul class="personal_center personal_part">
                                    <li class="personal_list"><a href="home.php?mod=spacecp&ac=usergroup" class="personal_link">{$_G[member][username]}</a></li>
                                    <li class="personal_list"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="personal_link">{lang logout}</a></li>
                                </ul>

                            <!--{/if}-->

                            <!--{if $wq_buluo[summary_url] || $wq_buluo[help_url]}-->
                                <a id="help" href="javascript:;" class="showmenu group_help" onmouseover="showMenu({'ctrlid': 'help'})" initialized="true">{$Tlang[51730c5350f1b2ba]}</a>
                            <!--{/if}-->

                            <!--{if helper_access::check_module('group') && (!$wq_buluo['pc_is_creat'] || ($wq_buluo['pc_is_creat'] && $mod!='index')) }-->
                                <a class="wqbuluo_establish"  href="buluo.php?mod=group&action=create">{$Tlang[ee7ab986b2f592ce]}</a>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>

                <!--{if $groupview}-->
                <ul id="visit_menu" class="p_pop help_menuvisit" style="display: none;">
                    <!--{loop $groupview $key $val}-->
                    <li><a href="buluo.php?mod=group&fid=$val[fid]">$val[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/if}-->
                <!--{if $manage_group}-->
                <ul id="manage_menu" class="p_pop" style="display: none;">
                    <!--{loop $manage_group  $key $val}-->
                    <li><a href="buluo.php?mod=group&fid=$val[fid]">$val[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/if}-->
                <ul id="help_menu" class="p_pop" style="display: none;">
                    <!--{if $wq_buluo[summary_url]}-->
                    <li><a target="_blank" href=" $wq_buluo[summary_url]">{$Tlang[9f1ff188e37f3ac1]}</a></li>
                    <!--{/if}-->
                    <!--{if $wq_buluo[help_url]}-->
                    <li><a target="_blank" href=" $wq_buluo[help_url]">{$Tlang[55cef60631601f60]}</a></li>
                    <!--{/if}-->

                </ul>
            </header>
            <div class="width1000">
                <style>.wp{width: 1000px;}.nfl .f_c{ width: 1000px; padding: 0px;}.loginbox .loginright{ text-align: left;}</style>
        <!--{/if}-->
            <ul class="down_menu wqpc_down_menu" id="{$menutype}_menu" style="display: none;">
                <li><!--{hook/global_usernav_extra1}--></li>
                <li><!--{hook/global_usernav_extra2}--></li>

                <!--{if check_diy_perm($topic)}-->
                    <li class="dkdiy"><a href="javascript:openDiy();" title="{lang open_diy}">{$Tlang['opendiy']}</a></li>
                <!--{/if}-->

                <!--{loop $_G['setting']['mynavs'] $nav}-->
                <!--{/loop}-->

                <!--{hook/global_usernav_extra3}-->
                <li class="grsz"><a href="home.php?mod=spacecp">{lang setup}</a></li>

                <!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
                    <li class="ypt"><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank">{lang cloudcp}</a></li>
                <!--{/if}-->

                <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
                    <li class="glzx"><a href="admin.php" target="_blank">{lang admincp}</a></li>
                <!--{/if}-->

                <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
                    <li class="mhgl">
                        <a href="portal.php?mod=portalcp">
                            <!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}-->
                        </a>
                    </li>
                <!--{/if}-->

                <!--{hook/global_usernav_extra4}-->
                <li class="yhtc"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
            </ul>
    <!--{/if}-->