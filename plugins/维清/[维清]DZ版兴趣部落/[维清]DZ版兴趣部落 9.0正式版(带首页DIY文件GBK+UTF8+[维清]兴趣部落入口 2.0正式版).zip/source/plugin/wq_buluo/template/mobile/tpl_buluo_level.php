<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<div class="grade_page">
    <div class="grade_top">
        <div class="grade_head"><img src="$wq_my_avatar"><span>$_G[username]</span></div>
        <div class="grade_description">
            <span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level} {$wq_buluo_level[style][$lid][content][$wq_level]}</span><span class="grade_name"></span>
            <!--{if $wq_buluo_level[level][$wq_level+1][val]}-->
            <!--{eval  $upgrade= intval($wq_buluo_level[level][$wq_level+1][val]);
            $width=intval($experience)/$upgrade*100;}-->
            <div class="grade_bar"><span class="grade_inner_bar" style="width:{$width}%;"></span></div>
            <span class="grade_exp">{$experience}/{$upgrade}</span>
            <!--{/if}-->
        </div>
    </div>
    <div class="grade_rank">
        <h3 class="b_bottom">{$Plang['be6a5833055e6b85']}</h3>
        <ul class="grade_list">
            <li class="grade_title">
                <div class="grade_box">{$Plang['d8c79993411048d5']}</div>
                <div class="grade_box">{$Plang['106bf7fb1635bc9d']}</div>
                <div class="grade_box">{$Plang['474dee92fa59519e']}</div>
            </li>
            <!--{loop $wq_buluo_level[level]  $key $val}-->
            <li>

                <!--{eval $wq_levelclass= $wq_buluo_level['level'][$key]['class']?$wq_buluo_level['level'][$key]['class']:1;}-->
                <div class="grade_box"><span class="prevent_default buluo-dislv{$wq_levelclass}"> $wq_buluo_level[prefix]{$key} </span></div>
                <div class="grade_box">{$wq_buluo_level[style][$lid][content][$key]}</div>
                <div class="grade_box">$val[val]</div>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <div class="grade_rank">
        <h2>{$Plang['e7a9c1583f3eee24']}<span></span></h2>
        <ul class="grade_rules_list">
            <li class="b_bottom">
                <div class="grade_box2 grade_rlue"> <span>{$Plang['23e67427ebb7a31f']}</span></div>
                <div class="grade_box3">
                    <ul class="grade_desc_list">
                        <li>1{$Plang['007bd5bdbc31a995']}<span>+ 4</span></li>
                        <li>2-29{$Plang['007bd5bdbc31a995']}<span>+ 6</span></li>
                        <li>30{$Plang['a3a831f91da9eed1']}<span>+ 8</span></li>
                    </ul>
                </div>
            </li>
            <li class="b_bottom">
                <div class="grade_box2 grade_rlue">
                    <p>{$Plang['5c560f703b3738ff']}</p>
                </div>
                <div class="grade_box3">
                    <ul class="grade_desc_list">
                        <li>1{$Plang['6092e15fd6f787ca']}<span>+ 3</span></li>
                        <li>2-5{$Plang['6092e15fd6f787ca']}<span>+ 6</span></li>
                        <li>6-9{$Plang['6092e15fd6f787ca']}<span>+ 9</span></li>
                        <li>10{$Plang['3182236cd8d8e4cd']}<span>+ 12</span></li>
                    </ul>
                </div>
            </li>
            <li class="b_bottom">
                <div class="grade_box2 grade_rlue">
                    <p>{$Plang['ebbb6ab8ff1a4dc7']}</p>
                </div>
                <div class="grade_box3">
                    <ul class="grade_desc_list">
                        <li>{$Plang['1_10']} <span>+ 3-6</span></li>
                        <li>{$Plang['11_50']} <span>+ 6-30</span></li>
                        <li>{$Plang['50_100']} <span>+ 30-60</span></li>
                        <li>{$Plang['100_1000']} <span>{$Plang['974811faaecc9984']}</span></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</div>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->