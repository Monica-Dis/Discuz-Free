<?php exit("From: DisM.taobao.com"); ?>
<style>.ct2{margin-right: 0px;}</style>
<div class="bm bml establish_group_div" id="main_messaqge">
    <div class="establish_group">
        <h1>{lang group_create_new}
            <span class="wq_f14"><!--{if $_G['setting']['groupmod']}-->({lang group_create_mod})<!--{/if}--></span>
            <span class="wqpc_prompt">{lang group_you_have}</span>
        </h1>
    </div>

    <div class="establish_group_con">
        <form method="post" autocomplete="off" name="groupform" id="groupform" class="s_clear" onsubmit="checkCategory();ajaxpost('groupform', 'returnmessage4', 'returnmessage4', 'onerror');return false;" action="buluo.php?mod=group&action=create">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="referer" value="{echo dreferer()}" />
            <input type="hidden" name="handlekey" value="creategroup" />
            <table cellspacing="0" cellpadding="0" class="tfm establish_table" summary="{lang group_create}">
                <tbody>
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <style type="text/css">
                                    #returnmessage4 { display: none; color: {NOTICETEXT}; font-weight: bold; }
                                    #returnmessage4.onerror { display: block; }
                            </style>
                            <p id="returnmessage4"></p>
                        </td>
                    </tr>
                    <tr>
                        <th><strong class="rq y">*</strong>{lang group_name}:</th>
                        <td>
                            <input type="text" name="name" id="name" class="g_input" size="36" tabindex="1" value="" autocomplete="off" onBlur="checkgroupname()" tabindex="1" />
                            <p id="groupnamecheck" class="xi1"></p>
                        </td>
                    </tr>
                    <tr>
                        <th><strong class="rq y">*</strong>{lang group_category}:</th>
                        <td>
                            <select name="parentid" tabindex="2" class="ps" onchange="ajaxget('forum.php?mod=ajax&action=secondgroup&fupid='+ this.value, 'secondgroup');">
                                <option value="0">{lang choose_please}</option>
                                $groupselect[first]
                            </select>
                            <em id="secondgroup"></em>
                            <span id="groupcategorycheck" class="xi1"></span>
                        </td>
                    </tr>
                    <tr>
                        <th>{lang group_description}:</th>
                        <td>
                            <script type="text/javascript">
                                    var allowbbcode = allowimgcode = parsetype = 1;
                                    var allowhtml = forumallowhtml = allowsmilies = 0;
                            </script>
                            <script type="text/javascript" src="{$_G[setting][jspath]}bbcode.js?{VERHASH}"></script>
                            <div id="descriptionpreview" class="m_b10"></div>
                            <div class="tedt">
                                    <div class="bar">
                                            <div class="y"><a href="javascript:;" onclick="$('descriptionpreview').innerHTML = bbcode2html($('descriptionmessage').value)">{lang group_description_preview}</a></div>
                                            <!--{eval $seditor = array('description', array('bold', 'color', 'img', 'link'));}-->
                                            <!--{subtemplate common/seditor}-->
                                    </div>
                                    <div class="area">
                                            <textarea id="descriptionmessage" name="descriptionnew" tabindex="3" class="pt" rows="8"></textarea>
                                    </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th><strong class="rq y">*</strong>{lang group_perm_visit}:</th>
                        <td>
                            <input type="radio" name="gviewperm" class="pr weui_check"  id="gviewperm1"tabindex="4" value="1" checked="checked" />
                            <label class="lb weui_check_label" for="gviewperm1"><i class="iconfont weui_icon_checked"></i> {lang group_perm_all_user}</label>
                            <input type="radio" name="gviewperm" id="gviewperm2" class="pr weui_check" value="0" />
                            <label class="lb weui_check_label" for="gviewperm2"><i class="iconfont weui_icon_checked"></i> {lang group_perm_member_only}</label>
                        </td>
                    </tr>
                    <tr>
                        <th><strong class="rq y">*</strong>{lang group_join_type}:</th>
                        <td>
                            <input type="radio" name="jointype" id="jointype1" class="pr weui_check" tabindex="5" value="0" checked="checked" />
                            <label class="lb weui_check_label" for="jointype1"><i class="iconfont weui_icon_checked"></i> {lang group_join_type_free}</label>
                            <input type="radio" name="jointype" class="pr weui_check" id="jointype2"  value="2" />
                            <label class="lb weui_check_label" for="jointype2"><i class="iconfont weui_icon_checked"></i> {lang group_join_type_moderate}</label>
                            <input type="radio" name="jointype" class="pr weui_check" id="jointype3"  value="1" />
                            <label class="lb weui_check_label" for="jointype3"><i class="iconfont weui_icon_checked"></i> {lang group_join_type_invite}</label>
                        </td>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <input type="hidden" name="createsubmit" value="true"><button type="submit" class="pnc publish_botton" tabindex="6">{lang create}</button>
                            <!--{if $_G['group']['buildgroupcredits']}-->&nbsp;&nbsp;&nbsp;(<strong class="rq">{lang group_create_buildcredits} $_G['group']['buildgroupcredits'] $_G['setting']['extcredits'][$creditstransextra]['unit']{$_G['setting']['extcredits'][$creditstransextra]['title']}</strong>)<!--{/if}-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>
    </div>
</div>

<script type="text/javascript">
	function checkgroupname() {
            var groupname = trim($('name').value);
            ajaxget('forum.php?mod=ajax&forumcheck=1&infloat=creategroup&handlekey=creategroup&action=checkgroupname&groupname=' + (BROWSER.ie && document.charset == 'utf-8' ? encodeURIComponent(groupname) : groupname), 'groupnamecheck');
	}

	function checkCategory(){
            var groupcategory = trim($('fup').value);
            if(groupcategory == ''){
                $('groupcategorycheck').innerHTML = '{lang group_create_selete_categroy}';
                return false;
            } else {
                $('groupcategorycheck').innerHTML = '';
            }
	}

	<!--{if $_GET['fupid']}-->
            <!--{eval $groupid = dhtmlspecialchars($_GET[groupid]);}-->
            ajaxget('forum.php?mod=ajax&action=secondgroup&fupid=$_GET[fupid]<!--{if $groupid}-->&groupid={$groupid}<!--{/if}-->', 'secondgroup');
	<!--{/if}-->

	if($('name')) {
            $('name').focus();
	}
</script>