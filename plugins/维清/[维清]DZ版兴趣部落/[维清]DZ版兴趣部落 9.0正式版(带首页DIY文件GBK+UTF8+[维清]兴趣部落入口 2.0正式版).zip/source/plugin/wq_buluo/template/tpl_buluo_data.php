<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $fid =dhtmlspecialchars($_GET['fid']); }-->
<div class="mod_content y">
	<div class="wrap">
            <h3 class="page_title">{$Plang[f5e1dcb6f691ed99]}</h3>
            <p class="page_desc">{$Plang[5d93e4ff8ecfeb9e]}
                <!--{if $setting[data_comment]}-->
                <a href="$setting[data_comment]" target="_blank"  class="wqcolor">{$Plang[ef9b85f046885019]}</a>
                <!--{/if}-->
            </p>
		<div class="tabcontainer">
			<div class="tab_hd">
                            <h4><strong>{$Plang[f5e1dcb6f691ed99]}</strong></h4>
                <ul>
                    <li<!--{if empty($_GET['type']) || $_GET['type'] == '1'}--> class="select"<!--{/if}-->><a href="forum.php?mod=group&action=manage&fid={$_G['fid']}&suboperation=data">{$Plang['0adcb1a8a3a8a564']}</a></li>
					<li<!--{if $_GET['type'] == '2'}--> class="select"<!--{/if}-->><a href="forum.php?mod=group&action=manage&fid={$_G['fid']}&suboperation=data&type=2">{$Plang['128df84de9e968e0']}</a></li>
                </ul>
			</div>
			<!--{if empty($_GET['type']) || $_GET['type'] == '1'}-->
			<div class="tab_bd">
				<div class="follow_data">
                                    <div class="follow_title"><span>{$Plang[5d1fdd62e4c7c0ec]}</span></div>
					<ul>
						<li>
                                                    <p>{$Plang[b8c14f86b53946dd]}</p>
							<div class="summary_num">{$yestoday_statdata['newfollow']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[5e5ee560a7cce5d7]}</p>
							<div class="summary_num">{$yestoday_statdata['unfollow']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[c0226e8c4f24b0f5]}</p>
							<div class="summary_num">{$yestoday_statdata['todayfollow']}</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="chart_analysis">
				<div class="chart_title">
                                    <span>{$Plang[d5b6c1b7a4613953]}</span>
					<ul id="field_type">
                                            <li data-id="newfollow" class="active">{$Plang[b8c14f86b53946dd]}</li>
                                            <li data-id="unfollow">{$Plang[5e5ee560a7cce5d7]}</li>
                                            <li data-id="todayfollow">{$Plang[c0226e8c4f24b0f5]}</li>
					</ul>
					<span id="fieldval" data-val="newfollow" style="display:none"></span>
					<span id="datenum" data-val="7" style="display:none"></span>
					<span id="datetype" data-val="1" style="display:none"></span>
                                        <a class="export_data wqcolor" href="javascript:;" id="export_data">{$Plang[fe912e45376e9f0e]}</a>
				</div>
				<div class="chart_day_nav">
					<ul id="chart_day">
                                            <li class="chart_day_nav_item active" data-id="7">{$Plang[e49de1e8248c1d11]}</li>
                                            <li class="chart_day_nav_item" data-id="14">{$Plang[9a44193d58cf7876]}</li>
                                            <li class="chart_day_nav_item" data-id="30">{$Plang[0b85d3d1bfa1a28e]}</li>
					</ul>
					<!--<div class="chart-select-day select-start active wqm_l20">2015-02-06<i class="iconfont wqicon-control-arr"></i></div>-->

					<span class="chart_day_nav_data"><input type="text" name="starttime" id="starttime" onclick="showcalendar(event, this, false)" value="{$starttime}" tabindex="1"><i class="iconfont" onclick="showdate('starttime')">&#xe613;</i></span>
					<span class="mod_till">{$Plang[00d02f0c3df8709e]}</span>
					<!--<div class="chart-select-day select-start active">2015-02-06<i class="iconfont wqicon-control-arr"></i></div>-->
					<span class="chart_day_nav_data"><input type="text" name="endtime" id="endtime" onclick="showcalendar(event, this, false)" value="{$endtime}" tabindex="2"><i class="iconfont" onclick="showdate('endtime')">&#xe613;</i></span>
                                        <button type="submit" id="datesubmit" class="pn pnc btn_data" value="true" name="datesubmit"><span>{$Plang[387e9a577ee04ca3]}</span>
</button>
				</div>
				<div class="chart_day_nav" id="chart_day_nav"></div>
			</div>
			<div class="chart_record" id="chart_record_type1"></div>
			<!--{elseif $_GET['type'] == '2'}-->
			<div class="tab_bd">
				<div class="follow_data">
                                    <div class="follow_title"><span>{$Plang[03f11a2cf0e615af]}</span></div>
					<ul class="type2">
						<li>
                                                    <p>{$Plang[b73b4fcbe9ad2811]}(PV)</p>
							<div class="summary_num">{$yestoday_statdata['pv']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[d3e61519cbd5b573]}(UV)</p>
							<div class="summary_num">{$yestoday_statdata['uv']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[d331302dd80c5713]}</p>
							<div class="summary_num">{$yestoday_statdata['signnum']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[ca5381012ad03b83]}</p>
							<div class="summary_num">{$yestoday_statdata['activenum']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                                <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
						<li>
                                                    <p>{$Plang[d9b592b92d0694c6]}</p>
							<div class="summary_num">{$yestoday_statdata['threadnum']}</div>
							<div class="alain_start">
                                                            <!--<p>{$Plang[0db07997ccf566f3]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
                                                            <!--<p>{$Plang[8703ad0cc00b15a7]}<i class="iconfont wqicon-xs-jiantou wq_f12" ></i>--</p>-->
							</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="chart_analysis">
				<div class="chart_title">
                                    <span>{$Plang[07517f51e30a7d3f]}</span>
					<ul id="field_type">
                                            <li data-id="pv" class="active">{$Plang[b73b4fcbe9ad2811]}(PV)</li>
                                            <li data-id="uv">{$Plang[d3e61519cbd5b573]}(UV)</li>
                                            <li data-id="signnum">{$Plang[d331302dd80c5713]}</li>
                                            <li data-id="activenum">{$Plang[ca5381012ad03b83]}</li>
                                            <li data-id="threadnum">{$Plang[d9b592b92d0694c6]}</li>
					</ul>
					<span id="fieldval" data-val="pv" style="display:none"></span>
					<span id="datenum" data-val="7" style="display:none"></span>
					<span id="datetype" data-val="1" style="display:none"></span>
                                        <a class="export_data wqcolor" href="javascript:;" id="export_data">{$Plang[fe912e45376e9f0e]}</a>
				</div>
				<div class="chart_day_nav">
					<ul id="chart_day">
                                            <li class="chart_day_nav_item active" data-id="7">{$Plang[e49de1e8248c1d11]}</li>
                                            <li class="chart_day_nav_item" data-id="14">{$Plang[9a44193d58cf7876]}</li>
                                            <li class="chart_day_nav_item" data-id="30">{$Plang[0b85d3d1bfa1a28e]}</li>
					</ul>
					<!--<div class="chart-select-day select-start active wqm_l20">2015-02-06<i class="iconfont wqicon-control-arr"></i></div>-->

                                        <span class="chart_day_nav_data"><input type="text" name="starttime" id="starttime" onclick="showcalendar(event, this, false)" value="{$starttime}" tabindex="1"><i class="iconfont" onclick="showdate('starttime')">&#xe613;</i></span>
                                        <div class="mod_till">{$Plang[00d02f0c3df8709e]}</div>
					<!--<div class="chart-select-day select-start active">2015-02-06<i class="iconfont wqicon-control-arr"></i></div>-->
					<span class="chart_day_nav_data"><input type="text" name="endtime" id="endtime" onclick="showcalendar(event, this, false)" value="{$endtime}" tabindex="2"><i class="iconfont" onclick="showdate('endtime')">&#xe613;</i></span>
                                        <button type="submit" id="datesubmit" class="pn pnc btn_data" value="true" name="datesubmit"><span>{$Plang[387e9a577ee04ca3]}</span>
</button>
				</div>
				<div class="chart_day_nav" id="chart_day_nav"></div>
			</div>
			<div class="chart_record type2" id="chart_record_type2"></div>
			<!--{/if}-->
		</div>
	</div>
</div>

<script src="./static/js/calendar.js?{VERHASH}" type="text/javascript"></script>
<script src="./source/plugin/wq_buluo/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
<script type="text/javascript">
	wqjq(document).ready(function() {

		var datetype = wqjq("#datetype").attr("data-val");
		chagechart(datetype);

		load_statlist('{$type}','{$url}');

		wqjq("#chart_day > li").bind("click", function() {

			wqjq(this).addClass("active").siblings().removeClass("active");

			var datenum = wqjq(this).attr("data-id");
			wqjq("#datenum").attr("data-val",datenum);

			wqjq("#datetype").attr("data-val","1");

			var datetype = wqjq("#datetype").attr("data-val");
			chagechart(datetype);
		});

		wqjq("#field_type > li").bind("click", function() {

			wqjq(this).addClass("active").siblings().removeClass("active");

			var fieldval = wqjq(this).attr("data-id");
			wqjq("#fieldval").attr("data-val",fieldval);

			var datetype = wqjq("#datetype").attr("data-val");
			chagechart(datetype);
		});

		wqjq("#datesubmit").bind("click", function() {

			wqjq("#chart_day > li").removeClass("active");

			wqjq("#datetype").attr("data-val","2");
			var datetype = wqjq("#datetype").attr("data-val");
			chagechart(datetype);
		});

		wqjq("#export_data").bind("click", function() {
			var datetype = wqjq("#datetype").attr("data-val");
			downloaddata(datetype,'{$type}');
		});

	});

	function chagechart(datetype){

		var field = wqjq("#fieldval").attr("data-val");

		if(datetype=='1'){
			var datenum = wqjq("#datenum").attr("data-val");
			var url = 'plugin.php?id=wq_buluo&mod=chart&datetype=1&fieldval='+ field + '&datenum=' + datenum +'&fid={$fid}';
		}else{
			var starttime = wqjq("#starttime").val();
			var endtime = wqjq("#endtime").val()
			var url = 'plugin.php?id=wq_buluo&mod=chart&datetype=2&fieldval='+ field + '&starttime=' + starttime +'&endtime=' + endtime +'&fid={$fid}';
		}

		var str = '<div class="chart_day_nav" id="chart_day_nav"><iframe src="' + url + '" width="100%" height="450" frameborder="0" ></iframe></div>';
		$("chart_day_nav").outerHTML = str;

	}

	function downloaddata(datetype,type){
		var field = wqjq("#fieldval").attr("data-val");

		if(datetype=='1'){
			var datenum = wqjq("#datenum").attr("data-val");
			var url = 'plugin.php?id=wq_buluo&mod=chart&datetype=1&ac=export&type=' + type + '&datenum=' + datenum +'&fid={$fid}';
		}else{
			var starttime = wqjq("#starttime").val();
			var endtime = wqjq("#endtime").val()
			var url = 'plugin.php?id=wq_buluo&mod=chart&datetype=2&ac=export&type=' + type + '&starttime=' + starttime +'&endtime=' + endtime +'&fid={$fid}';
		}

		location.href=url;
	}

	function load_statlist(type,url){
            wqjq.ajax({
                    url: url,
                    dataType: 'html',
                    success: function (data) {
                        $("chart_record_type"+type).outerHTML = data;
                    }
            });
	}
        function showdate(id){
            document.getElementById(id).onclick();
        }
</script>