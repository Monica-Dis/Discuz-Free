<?php exit("From: DisM.taobao.com"); ?>
<!--{eval
    loadcache('wq_buluo_favorite_'  . $_G['uid']);
    loadcache('wq_buluo_recommendadd_'  . $_G['uid']);
    $favorites=$_G['cache']['wq_buluo_favorite_'  . $_G['uid']];
    $recommendadd = $_G['cache']['wq_buluo_recommendadd_'  . $_G['uid']];

}-->
<!--{if $_GET[api]}-->
    <!--{eval $plugin_wq_touch_setting = !empty($_G['cache']['plugin']['wq_touch_setting']) ? 1 : 0;}-->
    <!--{if $plugin_wq_touch_setting}-->
        <!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_touch_setting/function/function_wq_touch.php';}-->
    <!--{else}-->
        <!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_touch.php';}-->
    <!--{/if}-->
<!--{else}-->

<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $setting[mobile_header]==0}--> <!--{eval $header_nav = $header_nav_app = 'null';}--> <!--{/if}-->
<!--{if $wq_touch}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<!--{template group/index_nav}-->

<div class="interest_circle interest_circle2">
    <ul id="wq_group_list">
        <!--{/if}-->
        <!--{if $threads}-->
        <!--{loop $threads $key $thread}-->
        <!--{if $thread['highlight']}-->
        <!--{eval $string = sprintf('%02d', $thread['highlight']);
                $stylestr = sprintf('%03b', $string[0]);
                $thread['highlight'] = ' style="';
                $thread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
                $thread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
                $thread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
                $thread['highlight'] .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]].';' : '';
                $thread['bgcolor']?$thread['highlight'] .= "background-color: $thread[bgcolor];":'';
                $thread['highlight'] .= '"';}-->
        <!--{/if}-->
        <li data='$thread[tid]' class="dynamic_thread_js" id="wq_dynamic_$key" {if in_array($thread[fid],$fid)&&$thread[founderuid]!=$_G[uid]&&$thread[authorid]!=$_G[uid]}fid="$thread[fid]"{/if} {if in_array($thread[authorid],$uid)&&$thread[authorid]!=$_G[uid]} authorid="$thread[authorid]"{/if} {if $thread[founderuid]==$_G[uid]}founderuid="$thread[fid]"{/if}>
            <div class="interest_head" >
                <div class="in_img">
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <a href="plugin.php?id=wq_buluo&mod=card&uid={$thread[authorid]}">
                        <img class="wq_js_delayload" data="{avatar($thread[authorid], small, true)}"/>
                    </a>
                    <!--{else}-->
                    <a href="javascript:;"><img src="$_G['style'][styleimgdir]/mobile/images/hidden.jpg"/></a>
                    <!--{/if}-->
                </div>
                <span class="interest_head_text">
                    <span class="interest_head_name">
                        <!--{if $thread['authorid'] && $thread['author']}-->
                        <a href="plugin.php?id=wq_buluo&mod=card&uid={$thread[authorid]}&do=profile">
                            <font {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if} >{$thread[author]}</font></a>
                        <!--{else}-->
                        <a href="javascript:;">{$_G[setting][anonymoustext]}</a>
                        <!--{/if}-->
                    </span>
                    <!--{if $info[fids][$thread[tid]]&&$thread[fid]!=$followforumid}-->
                    <i class="wqiconfont wqicon-youyou interest_head_icon f12"></i>
                    <span class="interest_head_barname"><a href="buluo.php?mod=group&fid=$thread[fid]">$info[fids][$thread[tid]]</a></span>
                    <!--{/if}-->
                </span>
                <span class="interest_head_time">$thread['dateline']</span>
                <div class="wqgroup_browse"><span class="wqiconfont wqicon-liulan f14"></span>$thread[views]</div>
            </div>
            <!--{if $thread[fid]==$followforumid}-->
            <a href="{if $info[subjects][$thread[comments]]}forum.php?mod=viewthread&tid=$thread[comments]{else}javascript:;{/if}">
                <!--{if $forward_info['summarys'][$thread['maxposition']]}-->
                <div class="interest_content">
                    <p style="color:#333; font-size:16px;">{$forward_info['summarys'][$thread['maxposition']]}</p>
                </div>
                <!--{/if}-->
                <div class="forward_wrap">
                    <!--{eval $image=get_images_by_pid($info[pids][$thread[comments]],$thread[comments]);}-->
                    <!--{if $image}-->
                    <div class="forward_img">
                        <img style="width:50px; height:50px;margin-left:0px;" src="$image">
                    </div>
                    <!--{/if}-->
                    <div class="forward_title_v2 feed_one_line">
                        <!--{if $info[subjects][$thread[comments]]}-->
                        $info[subjects][$thread[comments]]
                        <!--{else}-->
                        &#x8BDD;&#x9898;&#x5DF2;&#x5220;&#x9664;
                        <!--{/if}-->
                    </div>
                </div>
            </a>
            <!--{else}-->
            <div class="interest_con">
                <a href="buluo.php?mod=viewthread&tid=$thread[tid]">
                    <div class="interest_content">
                        <h3><font $thread[highlight]>{$thread[subject]}</font></h3>
                        <p>{$info['summarys'][$thread['tid']]}</p>
                    </div>
                    <!--{eval
                    $wq_data=wq_buluo_get_images_by_tid_pids($info[pids][$thread[tid]],3,'',$thread['tid']);
                    $wq_data_num=count($wq_data);
                   $wq_img_num= wq_buluo_get_images_by_tid_pids($info[pids][$thread[tid]],100,'',$thread['tid'],1);
                    }-->
                    <!--{if $wq_data}-->
                    <div class="{if $wq_data_num > '2'}interest_img3{elseif $wq_data_num > '1'}interest_img2{else}interest_img1{/if}">
                        <!--{loop $wq_data $k $v}-->
                    <div class="img-box wqc_img_box" id="wqc_index_css_{$thread[tid]}_{$k}" num="{$wq_data_num}" datatid="{$thread[tid]}" data="{$k}" dataurl="{$v['image']}">
                        <img data="{$v[image]}" class="wq_js_delayload" id="wqc_css_{$thread[tid]}_{$k}">
                        <!--{if $wq_img_num > 3}-->
                           <span class="total_img"><i class="wqiconfont wqicon-tuxiang f13"></i>{$wq_img_num}</span></span>
                        <!--{/if}-->
                    </div>

                        <!--{/loop}-->
                    </div>
                    <!--{/if}-->
<!--                    <div class="interest_info">
                        <div class="interest_info_icon" style="line-height: 24px;"><i class="wqiconfont wqicon-liuyan f13"></i>{$thread[replies]}</div>
                        <div class="interest_info_icon b_l_border">|</div>
                        <div class="interest_info_icon"><i class="wqiconfont wqicon-liulan f14"></i>$thread[views]</div>
                    </div>-->
                </a>
                <div class="wqdynamic_info">
                    <div class="wqdynamic_info_div"><a href="buluo.php?mod=viewthread&tid=$thread[tid]&extra=$extra"  onclick=" setcookie('wq_buluo_crad_replay_tid', 'replay'); "><i class="wqiconfont wqicon-liuyan f13"></i>{$thread[replies]}</a></div>
                    <div class="wqdynamic_info_div">
                        <a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&handlekey=recommendadd&hash={FORMHASH}" class="dialog notlogged recommendadd_zan" data="$thread[tid]">
                            <!--{if $recommendadd[$thread[tid]]}-->
                                <i class="wqiconfont wqicon-gzan2 f14 wqdianzan2"></i>
                            <!--{else}-->
                                <i class="wqiconfont wqicon-gzan f14" id="i_recommendadd_{$thread[tid]}"></i>
                            <!--{/if}-->
                            <span id="recommendadd_{$thread[tid]}">{$thread[recommend_add]}</span>
                            <span class="wqgroup_line"></span>
                        </a>
                    </div>
                    <div class="wqdynamic_info_div"><a href="javascript:;" class="newspecial2"><i class="wqiconfont wqicon-sandianheng f18"></i><span class="wqgroup_line"></span></a></div>
                </div>
            </div>
            <!--{/if}-->
                    <div class="action-sheet action-sheet_js" id="newspecial_menu2" style="display: none;">
                        <div id="wq_post_newthread_ul2">
                       <!--{if $thread[authorid]==$_G[uid]}-->
                        <!--{if $thread[fid]==$followforumid}-->
                         <div class="sheet-item  del_forward_js" tid="$key"><a href="plugin.php?id=wq_buluo&mod=ajax&ac=del_forward&handlekey=del_forward&tid=$key" class="dialog notlogged sheet-item-text" before="$('#masking').click()"><div class="">{$Plang['341e25b49335965e']}</div></a></div>
                        <!--{else}-->
                        <div class="sheet-item  del_show_js" tid="$key"> <div class="sheet-item-text">{$Plang['341e25b49335965e']}</div></div>
                        <!--{/if}-->
                        <!--{/if}-->
                        <!--{if in_array($thread[fid],$fid)&&$thread[founderuid]!=$_G[uid]}-->
                        <div class="sheet-item  out_{$thread[fid]}_js"><a href="buluo.php?mod=group&action=out&fid=$thread[fid]&handlekey=wq_out" class="dialog notlogged sheet-item-text" before="$('#masking').click()" successfun="cancelGroup=$thread[fid]">{$Plang['c2ad808457acf5d2']}</a> </div>
                         <!--{/if}-->
                          <!--{if in_array($thread[authorid],$uid)&&$thread[authorid]!=$_G[uid]}-->
                        <div class="sheet-item  cancelUser_{$thread[authorid]}_js"><a href="home.php?mod=spacecp&ac=follow&op=del&handlekey=cancel_attention&fuid=$thread[authorid]" class="dialog notlogged sheet-item-text" before="$('#masking').click()" successfun="cancelUser=$thread[fid]">{$Plang['7ab2a039928e05a8']}</a></div>
                        <!--{/if}-->
                          <!--{if $thread[authorid]!=$_G[uid]}-->
                        <!--{eval $wq_pid=$thread[fid]==$followforumid?$value['maxposition']:$info[pids][$key];}-->
                        <div class="sheet-item"><a href="misc.php?mod=report&rtype=post&rid={$wq_pid}&tid={$key}&fid={$thread[fid]}" class="dialog notlogged sheet-item-text" before="$('#masking').click()">{$Plang['f8874221706a4ccc']}</a>  </div>
                        <!--{/if}-->
                        <div class="sheet-item sheet-cancle"><a href="javascript:;" id="wq_g_cancel2" class="sheet-item-text"><div>{$Plang['9c825be7149e5b97']}</a></div>
                        </div>
                     </div>
        </li>
        <!--{/loop}-->

        <!--{eval $wq_tid=$thread[tid];}-->
        <!--{elseif !$_GET[api]}-->
        <p class="emp">
            <span class="no_content"><img src="{$_G['style'][styleimgdir]}mobile/images/no_content.png"></span>
            {$Plang['aa728ca993d67b3d']}
        </p>
        <!--{/if}-->
        <!--{if !$_GET[api]}-->
    </ul>
    <div class="p_load_more" style="display: none">
        <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
        <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
        <!--{else}-->
        <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
        <!--{/if}-->
        {$Tlang['d0a97567aed382e8']}
    </div>
    <div class="loading" {if $page * $perpage < $count}style="display: none;"{/if}>{$Plang['b3f7b411f8a25701']}</div>
    <div style="height:49px;width:100%;"></div>
</div>
          <script type="text/javascript">
            $(function() {
                $('.newspecial2').click(function() {
                    $('#masking').fadeIn()
                    $(this).parents('.interest_con').next().slideToggle()
                    return false
                });
                $('#masking, #wq_g_cancel2').on('click',function() {
                    $('#masking').fadeOut()
                    $('.action-sheet_js').slideUp()
                })
            });

        </script>
<script>
    var cancelGroup;
    function succeedhandle_wq_out(url, msg) {
        if ($.trim(msg) == '{$Plang[0d2e2419a4e975f4]}') {
            wq_setTimeout();
            var group = $('.dynamic_thread_js[fid="' + cancelGroup + '"]');
            var p = 1;
            group.each(function() {
                if ($(this).attr('authorid')) {
                    $(this).attr('fid', null);
                } else {
                    p++
                    $(this).remove();
                }
            });
            if (p) {
                delayload();
                wqc_img_box()

            }
            $('.out_' + cancelGroup + "_js").remove();
        }
    }
    function succeedhandle_cancel_attention(url, msg, param) {
        if ($.trim(msg) == '{$Plang[bef022f6310db3b9]}') {
            wq_setTimeout();
            var group = $('.dynamic_thread_js[authorid="' + param['fuid'] + '"]');
            var p = 1;
            group.each(function() {
                if ($(this).attr('fid')) {
                    $(this).attr('authorid', null);
                } else if (!$(this).attr('founderuid')) {
                    p++
                    $(this).remove();
                }
            });
            if (p) {
                delayload();
                wqc_img_box()
            }
            $('.cancelUser_' + param['fuid'] + "_js").remove();
        }
    }
    function succeedhandle_del_forward(url, msg, param) {
        if ($.trim(msg) == '{$Plang[8987fdbb54a9953a]}') {
            wq_setTimeout();
            $('#wq_dynamic_' + param['tid']).remove();
            delayload();
            wqc_img_box()
        }
    }
    function succeedhandle_deletethread(url, msg, param) {
        if ($.trim(msg) == '{$Plang[8987fdbb54a9953a]}') {
            wq_setTimeout();
            $('#wq_dynamic_' + param['tid']).remove();
            delayload();
            wqc_img_box()
        }
    }
    function dynamicOperation(obj) {
        $(obj).parent().next().show();
        $('#masking').show();
    }

    function errorhandle_recommendadd(msg, param){
            wq_buluo_cache_user_favorite_or_recommend_info('recommendadd');
       if ($.trim(msg) =="{$Tlang[fffeda57bpingjia]}"+param.recommendc+' +1') {
            var tid = getcookie('wq_buluo_recommend_tid');
            setcookie('wq_buluo_recommend_tid','',-1)
            clearInterval(setTimeout_location);
            $('#i_recommendadd_'+tid).attr('class','wqiconfont wqicon-gzan2 f14 wqdianzan2');
            $('#recommendadd_'+tid).text(parseInt($('#recommendadd_'+tid).text()) + 1);
            setTimeout(function () {
                popup.close();
            }, '1000');
        }
    }
    function wq_buluo_cache_user_favorite_or_recommend_info(wqtype){
        $.ajax({
                type: 'POST',
                url: 'plugin.php?id=wq_buluo&mod=ajax&ac='+wqtype,
                data: {formhash: '{FORMHASH}'},
                dataType: 'html',
            }).success(function () {
            }).error(function () {
            });
    }

    $(function() {

        $(document).on('click', '.recommendadd_zan', function () {
            var obj = $(this);
            var data = obj.attr('data')
            setcookie('wq_buluo_recommend_tid', data);
        });

        $('#wq_group_list').on('click', '.del_show_js', function() {
            var tid = $(this).attr('tid');
            $('#masking').click();
            popup.open('<div class="shield_notice">\n\
<div class="c ignore_ts">{$Plang[aa0e31f2040bbd4e]}</div>\n\
                              <p class="o pns">\n\
                                    <a href="plugin.php?id=wq_buluo&mod=ajax&ac=deletethread&handlekey=deletethread&tid=' + tid + '" class="dialog notlogged"><button type="button"  class="pn pnc">{$Plang[387e9a577ee04ca3]}</button></a>\n\
                                     <a href="javascript:;" onclick="popup.close();" class="eject_cancel">{$Plang[9c825be7149e5b97]}</a>\n\
                    </p>\n\
                </div>');
        });
        $('#masking').click(function() {
            $('.wq_dynamicOperation_js').hide();
            $(this).hide();
        });
    });
    wq_touch_ajax_scroll('1', '$count', '$perpage', 'plugin.php?id=wq_buluo&mod=index&tid={$wq_tid}', 'wq_group_list', 0, function(page) {
        var wq_lis = $('#wq_group_list li[data]');
        var num = page * '$perpage';

        if (wq_lis.length == num) {
            var data = wq_lis.last().attr('data');
            return 'count+=$perpage;url=\'plugin.php?id=wq_buluo&mod=index&tid=' + data + '\';';
        } else {

        }

    });
</script>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
    <!--{if $wq_touch}-->
        <!--{eval $wq_footer_hide='1';}-->
        <!--{template common/footer}-->
    <!--{else}-->
        <!--{template common/wq_buluo_tpl_footer}-->
    <!--{/if}-->
<!--{/if}-->