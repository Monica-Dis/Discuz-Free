<?php exit("From: DisM.taobao.com"); ?>
<div class="exfm cl">
	<div class="sinf sppoll z">
		<dl>
			<dt><span class="rq">*</span>{lang post_event_time}:</dt>
			<dd>
				<div id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}>
					<input type="text" name="starttimefrom[0]" id="starttimefrom_0" class="px_post" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" />
				</div>
				<div id="uncertainstarttime" {if !$activity['starttimeto']}style="display: none"{/if}>
					<input type="text" name="starttimefrom[1]" id="starttimefrom_1" class="px_post" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" /><span> ~ </span><input onclick="showcalendar(event, this, true)" type="text" autocomplete="off" id="starttimeto" name="starttimeto" class="px" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" />
				</div>
				<div class="spmf cl">

                                            <input type="checkbox" id="activitytime" name="activitytime" class="pc weui_check_z" onclick="if(this.checked) {$('certainstarttime').style.display='none';$('uncertainstarttime').style.display='';} else {$('certainstarttime').style.display='';$('uncertainstarttime').style.display='none';}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" />
                                             <label class="weui_check_label_z" for="activitytime"><i class="iconfont weui_icon_checked_z "></i> {lang activity_starttime_endtime}</label>
				</div>
			</dd>
			<dt><span class="rq">*</span><label for="activityplace">{lang activity_space}:</label></dt>
			<dd>
				<input type="text" name="activityplace" id="activityplace" class="px_post oinf" value="$activity[place]" tabindex="1" />
			</dd>
			<!--{if $_GET[action] == 'newthread'}-->
			<dt><label for="activitycity">{lang activity_city}:</label></dt>
			<dd><input name="activitycity" id="activitycity" class="px_post" type="text" tabindex="1" /></dd>
			<!--{/if}-->
			<dt><span class="rq">*</span><label for="activityclass">{lang activiy_sort}:</label></dt>
			<dd class="hasd cl">
				<!--{if $activitytypelist}-->
					<ul id="activitytypelist" style="display: none">
					<!--{loop $activitytypelist $type}-->
						<li>$type</li>
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				<span><input type="text" id="activityclass" name="activityclass" class="px_post" value="$activity[class]" tabindex="1" /></span>
				<!--{if $activitytypelist}-->
					<a href="javascript:;" class="dpbtn iconfont" onclick="showselect(this, 'activityclass', 'activitytypelist')">&#xe613;</a>
				<!--{/if}-->
			</dd>
			<dt><label for="activitynumber">{lang activity_need_member}:</label></dt>
			<dd>
				<input type="text" name="activitynumber" id="activitynumber" class="px_post z" style="width:55px;" onkeyup="checkvalue(this.value, 'activitynumbermessage')" value="$activity[number]" tabindex="1" />
				<span class="ftid">
					<select name="gender" id="gender" width="38" class="ps">
						<option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
						<option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
						<option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
					</select>
				</span>
				<span id="activitynumbermessage"></span>
			</dd>
			<!--{if $_G['setting']['activityfield']}-->
			<dt>{lang optional_data}:</dt>
			<dd>
				<ul class="xl2 cl">
				<!--{loop $_G['setting']['activityfield'] $key $val}-->
				<li>
                                        <input type="checkbox" name="userfield[]" id="userfield_$key" class="pc weui_check_z" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />
                                            <label class="weui_check_label_z" for="userfield_$key"><i class="iconfont weui_icon_checked_z"></i> $val</label>
                                </li>
				<!--{/loop}-->
				</ul>
			</dd>
			<!--{/if}-->
			<!--{if $_G['setting']['activityextnum']}-->
			<dt><label for="extfield">{lang other_data}:</label></dt>
			<dd>
				<textarea name="extfield" id="extfield" class="pt" cols="50" style="width: 270px;"><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea><br />{lang post_activity_message} $_G['setting']['activityextnum'] {lang post_option}
			</dd>
			<!--{/if}-->
		</dl>
	</div>
	<div class="sadd z">
		<dl>
			<!--{if $_G['setting']['activitycredit']}-->
			<dt><label for="activitycredit">{lang consumption_credit}:</label></dt>
			<dd>
				<input type="text" name="activitycredit" id="activitycredit" class="px_post" value="$activity[credit]" />{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}
				<p class="xg1">{lang user_consumption_money}</p>
			</dd>
			<!--{/if}-->
			<dt><label for="cost">{lang activity_payment}:</label></dt>
			<dd>
				<input type="text" name="cost" id="cost" class="px_post" onkeyup="checkvalue(this.value, 'costmessage')" value="$activity[cost]" tabindex="1" />{lang payment_unit}
				<span id="costmessage"></span>
			</dd>
			<dt><label for="activityexpiration">{lang post_closing}:</label></dt>
			<dd class="hasd cl">
				<span>
					<input type="text" name="activityexpiration" id="activityexpiration" class="px_post" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[expiration]" tabindex="1" />
				</span>
				<a href="javascript:;" class="dpbtn iconfont" onclick="showselect(this, 'activityexpiration')">&#xe613;</a>
			</dd>
			<!--{if $allowpostimg}-->
				<dt>{lang post_topic_image}:</dt>
				<dd class="pns">
					<p><button type="button" class="pn_2" onclick="uploadWindow(function (aid, url){activityaid_upload(aid, url)})"><span><!--{if $activityattach[attachment]}-->{lang update}<!--{else}-->{lang upload}<!--{/if}--></span></button></p>
					<input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
					<input type="hidden" name="activityaid_url" id="activityaid_url" />
					<span class="xg1">
					<!--{if $activityattach[attachment]}-->
						{lang post_click_message_1}
					<!--{else}-->
						{lang post_click_message_2}
					<!--{/if}-->
					</span>
					<div id="activityattach_image">
					<!--{if $activityattach[attachment]}-->
						<a href="$activityattach[url]/$activityattach[attachment]" target="_blank"><img class="spimg" src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}" alt="" /></a>
					<!--{/if}-->
					</div>
				</dd>
			<!--{/if}-->
			<!--{hook/post_activity_extra}-->
		</dl>
	</div>
</div>
<script type="text/javascript" reload="1">
simulateSelect('gender');
function checkvalue(value, message){
	if(!value.search(/^\d+$/)) {
		$(message).innerHTML = '';
	} else {
		$(message).innerHTML = '<b>{lang input_invalid}</b>';
	}
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if($('postform').starttimefrom_0.value == '' && $('postform').starttimefrom_1.value == '') {
		showDialog('{lang post_error_message_1}', 'alert', '', function () { if($('activitytime').checked) {$('postform').starttimefrom_1.focus();} else {$('postform').starttimefrom_0.focus();} });
		return false;
	}
	if($('postform').activityplace.value == '') {
		showDialog('{lang post_error_message_2}', 'alert', '', function () { $('postform').activityplace.focus() });
		return false;
	}
	if($('postform').activityclass.value == '') {
		showDialog('{lang post_error_message_3}', 'alert', '', function () { $('postform').activityclass.focus() });
		return false;
	}
	return true;
}
function activityaid_upload(aid, url) {
	$('activityaid_url').value = url;
	updateactivityattach(aid, url, '{$_G['setting']['attachurl']}forum');
}
</script>