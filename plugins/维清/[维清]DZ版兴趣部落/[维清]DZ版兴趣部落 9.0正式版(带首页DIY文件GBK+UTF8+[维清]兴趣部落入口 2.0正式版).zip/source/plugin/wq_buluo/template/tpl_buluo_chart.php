<?php exit("From: DisM.taobao.com"); ?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=GBK">
		<script src="./source/plugin/wq_buluo/static/js/charts/jquery.min.js?{VERHASH}" type="text/javascript"></script>
		<script type="text/javascript">
		$(function () {
		$('#container').highcharts({
		chart: { type: 'line' },
		xAxis: { categories: [{$dataforchart['datestr']}]},
		yAxis: { min: 0, title: { text: '' }, plotLines: [{ value: 0, width: 1, color: '#808080'}] },
		tooltip: { enabled: true },
		plotOptions: { line: { dataLabels: { enabled: true }, enableMouseTracking: true } },
		series: [{name:"{$title}",data:[{$dataforchart['numstr']}]}]
		});
		});
		</script>
	</head>
	<body>
            <script src="./source/plugin/wq_buluo/static/js/charts/highcharts.js?{VERHASH}" type="text/javascript"></script>
		<div id="container" style="margin: 0 auto"></div>
	</body>
</html>