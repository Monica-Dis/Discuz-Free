<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
 <div class="qz_bg">
     <div class="qrcode_wrap">
         <div class="qrcode_container">
             <img class="qrcode_img" src="$qrcode_url"><span><img src="$_G[forum][icon]"></span>
         </div>
         <div class="qrcode_code">
             <span><img src="$_G[forum][icon]"></span>
             <div class="qrcode_head">
                 <h3>$_G['forum'][name]</h3>
                 <p>{$Plang['984d2eca29337ffd']}</p>
             </div>
         </div>
     </div>
</div>
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->