<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_buluo:common/tpl_header}-->
    <!--{ad/text/wp a_t}-->
    <style id="diy_style" type="text/css"></style>
    <div class="wp">
        <!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->
    </div>
    <div class="wpbar">
        <div class="group_in_left">
            <!--[diy=type1]--><div id="type1" class="area"></div><!--[/diy]-->
            <div class="group_ass_list"><h3>{$Tlang[d5c3dbd657f094ac]}</h3>
                <!--{loop $first $groupid $group}-->
                    <a href="buluo.php?gid=$groupid"><span <!--{if $_GET['gid']==$groupid}-->class="a"<!--{/if}-->>$group[name]</span></a>
                <!--{/loop}-->
            </div>

            <!--{if helper_access::check_module('group')}-->
                <!--{if empty($gid) && empty($sgid)}-->
                    <h3>{lang create_group_step}</h3>
                    <ul id="g_guide" class="mbm">
                        <li><label><strong class="xi1">{lang group_create}</strong><span class="xg1">{lang create_group_message1}</span></label></li>
                        <li><label><strong class="xi1">{lang personality_setting}</strong><span class="xg1">{lang create_group_message2}</span></label></li>
                        <li><label><strong class="xi1">{lang invite_friend}</strong><span class="xg1">{lang create_group_message3}</span></label></li>
                        <li><label><strong class="xi1">{lang group_upgrade}</strong><span class="xg1">{lang create_group_message4}</span></label></li>
                    </ul>
                    <div class="application_group">
                        <a href="buluo.php?mod=group&action=create" id="create_group_btn"><img src="{IMGDIR}/create_group.png" alt="{lang group_create}" /></a>
                    </div>
                <!--{else}-->
                    <!--        <div class="application_group">
                                <a href="forum.php?mod=group&action=create&fupid=$fup&groupid=$sgid" id="create_group_btn">{$Tlang[0e85dffc8ac8f983]}</a>
                            </div>  -->
                <!--{/if}-->
            <!--{/if}-->

            <!--[diy=type2]--><div id="type2" class="area"></div><!--[/diy]-->
            <!--diyarea_280px-->
            <div class="group_ranking">
                <!--{hook/index_side_top}-->
                        <!--{if $topgrouplist}-->
                        <div id="g_top" class="group_hot">
                            <h3>{lang group_hot}</h3>
                            <ol class="xl">
                                <!--{loop $topgrouplist $fid $group}-->
                                    <li class="top1"><span class="y xi2 xg1"> $group[commoncredits]</span><a href="buluo.php?mod=group&fid=$group[fid]" title="$group[name]">$group[name]</a></li>
                                <!--{/loop}-->
                            </ol>
                        </div>
                    <!--{/if}-->
                <!--{hook/index_side_bottom}-->
            </div>
            <!--[diy=type3]--><div id="type3" class="area"></div><!--[/diy]-->
            <!--diyarea_280px-->
        </div>

        <div class="group_in_right">
            <!--[diy=type4]--><div id="type4" class="area"></div><!--[/diy]-->
            <!--diyarea_710px-->

            <div class="group_ass">
                <h3>$curtype[name]<span>{lang group_total_numbers}</span>
                    <span class="y">
                        <select title="{lang orderby}" onchange="location.href = this.value" class="ps">
                            <option value="$url" $selectorder[default]>{lang orderby_default}</option>
                            <option value="$url&orderby=thread" $selectorder[thread]>{lang stats_main_threads_count}</option>
                            <option value="$url&orderby=membernum" $selectorder[membernum]>{lang group_member_count}</option>
                            <option value="$url&orderby=dateline" $selectorder[dateline]>{lang group_create_time}</option>
                            <option value="$url&orderby=activity" $selectorder[activity]>{lang group_activities}</option>
                        </select>
                    </span>
                </h3>

                <!--{if $typelist}-->
                    <div class="bbs">
                        <p><!--{loop $typelist $fid $type}--><a href="buluo.php?sgid=$fid">$type[name]</a><!--{if $type[groupnum]}--><span class="xg1">($type[groupnum])</span><!--{/if}--> &nbsp; <!--{/loop}--></p>
                    </div>
                <!--{else}-->
                    <div class="bbs"></div>
                <!--{/if}-->

                <!--{hook/index_top}-->
                <!--{if $list}-->
                    <!--{if $curtype['forumcolumns'] > 1}-->
                        <table class="fl_tb">
                            <tr class="fl_row">
                                <!--{loop $list $fid $val}-->
                                    <!--{if $val['orderid'] && ($val['orderid'] % $curtype['forumcolumns'] == 0)}-->
                                        </tr>

                                        <tr class="fl_row">
                                    <!--{/if}-->
                                    <td class="fl_g" style="width: $curtype[forumcolwidth]">
                                        <div class="fl_icn_g"><a href="buluo.php?mod=group&fid=$fid" title="$val[name]"><img width="48" height="48" src="$val[icon]" alt="$val[name]" /></a></div>
                                        <dl>
                                            <dt><a href="buluo.php?mod=group&fid=$fid" title="$val[name]">$val[name]</a></dt>
                                            <dd>{lang group_total_members_threads}</dd>
                                            <dd><a href=""><a href="buluo.php?mod=group&fid=$fid">{lang group_founded_in}: $val[dateline]</a></dd>
                                        </dl>
                                    </td>
                                <!--{/loop}-->
                                $endrows
                            </tr>
                        </table>
                    <!--{else}-->
                        <!--{if $_G[uid]}-->
                            <!--{eval $groupuser=wq_buluo_forum_groupuser(array('fid','level'),$_G[uid]);}-->
                        <!--{/if}-->
                        <ul class="fl_tb">
                            <!--{loop $list $fid $val}-->
                                <li class="fl_row">
                                    <div class="group_category">
                                        <a href="buluo.php?mod=group&fid=$fid" class="group_category_left" title="$val[name]" target="_blank"><img width="48" height="48" src="$val[icon]" alt="$val[name]" /></a>
                                        <div class="group_category_right">
                                            <!--{hook/index_grouplist $fid}-->
                                            <a href="buluo.php?mod=group&fid=$fid" title="$val[name]" class="name ov_hd" target="_blank">$val[name]</a><div><span class="pids">{$val[membernum]} {lang group_member}</span><span class="fans">{$val[threads]}{lang threads}</span></div>
                                            <div class="desc">$val[description]</div>
                                        </div>

                                        <div class="focus_join" id="join_{$fid}">
                                            <!--{if $val[founderuid]!=$_G[uid]}-->
                                                <!--{if $groupuser[$val[fid]][level]===null}-->
                                                    <a href="buluo.php?mod=group&action=join&fid=$val[fid]" data='$val[fid]' jointype='$val[jointype]' onclick="wq_join_data(this), showWindow('wq_join', this.href)"><span>+</span><em>{$Tlang[876bb8031df32628]}</em></a>
                                                <!--{elseif $groupuser[$val[fid]][level]==='0'}-->
                                                    <a href="buluo.php?mod=group&action=out&fid=$val[fid]" data='$val[fid]' onclick="showWindow('wq_out', this.href)"><em class="already_join">{$Tlang[fcce7c30276aa190]}</em></a>
                                                <!--{else}-->
                                                    <a href="javascript:;"><em class="already_join">{$Tlang[b4b0d4ba96890702]}</em></a>
                                                <!--{/if}-->
                                            <!--{else}-->
                                                <a href="javascript:;"><em class="already_join">{$Tlang[b4b0d4ba96890702]}</em></a>
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </li>
                            <!--{/loop}-->
                        </ul>
                        <script>
                            var join_data, jointype;
                            function  wq_join_data(obj) {
                                join_data = wqjq(obj).attr('data')
                                jointype = wqjq(obj).attr('jointype');
                            }
                            function succeedhandle_wq_join(url, msg, param) {
                                hideWindow('wq_join');
                                if (wqjq.trim(msg) == '{$Tlang[3f043f93b49a94fc]}') {
                                    var join_msg = jointype == 2 && !'$_G[ismoderator]' ? '{$Tlang[4feb290c5e86a4b8]}' : '{$Tlang[b4b0d4ba96890702]}';
                                    wqjq('#join_' + join_data).html("<a href=\"javascript:;\"><em class=\"already_join\">" + join_msg + "</em>")
                                }
                                showDialog(msg, 'alert', '', '', 0, '', '', '', '', '2');
                            }
                        </script>
                    <!--{/if}-->
                    <!--{hook/index_bottom}-->
                <!--{else}-->
                    <div class="emp">
                        <h2>{lang group_category_no_groups}</h2>
                        <p>{lang group_category_no_groups_detail}</p>
                    </div>
                <!--{/if}-->
            </div>

            <!--[diy=type5]--><div id="type5" class="area"></div><!--[/diy]-->
            <!--diyarea_710px-->
            <!--{if $list}-->
                <!--{if $multipage}-->
                    <!--{eval
                        $multipage=str_replace('group.php','buluo.php',$multipage);
                    }-->
                    <div class="group_page">
                        <div class="pgs cl">
                            $multipage
                            <span class="pgb y"><a href="buluo.php">{lang return_index}</a></span>
                        </div>
                    </div>
                <!--{/if}-->
            <!--{/if}-->
            <!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
            <!--diyarea_710px-->
        </div>
    </div>
<!--{template wq_buluo:common/tpl_footer}-->