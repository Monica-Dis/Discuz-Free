<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $wq_touch = wq_buluo_is_wq_touch();}-->
<!--{if $wq_touch}-->
    <!--{eval $header_nav = $header_nav_app = 'null';}-->
    <!--{template common/header}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_header}-->
<!--{/if}-->
<script src="source/plugin/wq_buluo/static/js/wqxml.js?{VERHASH}" type="text/javascript"></script>
<!--{if !$_GET[inajax]}-->
<div class="qz_bg">
    <div class="group_data">
        <div class="data_wrap">
            <div class="data_item b_bottom">
                <span class="data_text">{$Plang['144505e1822c5051']}</span>
                <span class="data_content">$_G['forum'][name]</span>
            </div>
            <div class="data_item b_bottom">
                <a href="plugin.php?id=wq_buluo&mod=qrcode&fid=$_G[forum][fid]">
                    <span class="data_text">{$Plang['51eb554fa18cb1cc']}</span>
                    <span class="data_content"><i class="wqiconfont wqicon-erweima f26 ewm"></i><i class="wqiconfont wqicon-youyou"></i></span>
                </a>
            </div>
            <div class="data_item b_bottom">
                <span class="data_text">{$Plang['b2d61ab957262de4']}</span> <span class="data_content">$class</span>
            </div>
            <div class="data_item b_bottom">
                <span class="data_text">{$Plang['8e236e519f73ce3c']}</span> <span class="data_content data_intro">$_G['forum'][description]</span>
            </div>

            <div class="data_item p_juli b_bottom">
				<!--{eval $i = 0;}-->
				<!--{loop $groupmanagers $manage}-->
					<!--{if $i == 0}-->
						<a href="plugin.php?id=wq_buluo&mod=card&uid={$manage['uid']}"><span class="data_text">{$Plang['091ee70332c0c298']}</span><span class="data_content data_intro head_name">{$manage['username']}</span><span class="data_content data_intro">{avatar($manage['uid'], 'small')}</span></a>
					<!--{/if}-->
					<!--{eval $i++;}-->
				<!--{/loop}-->
            </div>
        </div>
    </div>
    <div class="group_qz_info">
        <div class="group_qz">
            <a href="forum.php?mod=group&action=memberlist&fid=$_G['forum'][fid]"><h4>{$Plang['1de89db88bbf34c7']}</h4>
            <span class="qz_count">{$_G['forum'][membernum]}{$Plang['person']}<i class="wqiconfont wqicon-youyou f18"></i></span> </a>
        </div>
    </div>
    <!--{if $_G['forum'][founderuid]!=$_G[uid]&&$groupuser[level]>0}-->
    <div class="exit_group"><a href="buluo.php?mod=group&action=out&fid=$_G[fid]&handlekey=wq_out" class="dialog notlogged">{$Plang['7dd79b3c3de7fb49']}</a></div>
    <!--{/if}-->
    <div class="rank_info">
        <h3>{$Plang['50a0e54bc1854342']}<span class="rank-info-text">{$Plang['ac9cf0d04e9ac052']}{$order}{$Plang['0c27f9fc234c0b86']}</span><span class="rank-info-text">{$firsttype['name']}{$Plang['8632f0dd76016cbc']}</span>  </h3>
        <div class="fans_list rank_info_white">
            <ul id="mainlist">
                <!--{/if}-->
                <!--{loop  $list $key $val}-->
                <!--{eval $start++;isset($val['icon']) && $val['icon'] = get_groupimg($val['icon'], 'icon');}-->
                <li>
                    <a href="buluo.php?mod=group&fid=$val[fid]">
                        <div class="rank_icon"><i class="f22 {if $start<=3}wqiconfont wqicon-rongyutang  c_ry{$start}{/if}"><!--{if $start>3}-->$start<!--{/if}--> </i></div>
                        <div class="fans_avatar"><img src="$val[icon]"></div>
                        <div class="content">
                            <div class="nick"><span class="nick_name{if $_G['forum']['fid']==$val[fid]} group_color{/if}">$val[name]</span></div>
                            <p class="text">{$Plang['a86acd545cc0a2fd']}{$val[commoncredits]} {$Plang['cb652d7e9654f645']}{$val[membernum]} </p>
                        </div>
                    </a>
                </li>
                <!--{/loop}-->
                <!--{if !$_GET[inajax]}-->
            </ul>
            <div class="p_load_more" style="display: none">
                <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
                <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
                <!--{else}-->
                <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
                <!--{/if}-->
                {$Tlang['d0a97567aed382e8']}
            </div>
        </div>
    </div>
    <!--{if helper_access::check_module('group')&&$_G['forum'][jointype]!=-1}-->
    <!--{eval $i=0;}-->
    <!--{block wq_group_operation}-->
    <div class="h50"></div>
    <div class="gz_group b_top">
        <!--{if $groupuser[level]>0}-->
        <!--{eval $i++;}-->
        <a href="misc.php?mod=invite&action=group&id=$_G['forum'][fid]&handlekey=invite" class="dialog notlogged">{$Plang['96cbaaa50da04a11']}</a>
        <!--{elseif $groupuser[level]==='0'}-->
        <!--{eval $i++;}-->
        <a href="buluo.php?mod=group&action=out&fid=$_G[fid]&handlekey=wq_out" class="dialog notlogged">{$Plang['fcce7c30276aa190']}</a>
        <!--{elseif $_G['forum'][jointype]!=1}-->
        <!--{eval $i++;}-->
        <a href="buluo.php?mod=group&action=join&fid=$_G[fid]&handlekey=wq_join" class="dialog notlogged">{$Plang['876bb8031df32628']}</a>
        <!--{/if}-->
    </div>
    <!--{/block}-->
    <!--{if $i}-->
    $wq_group_operation
    <!--{/if}-->
    <!--{/if}-->
</div>
<script>
    function succeedhandle_friendForm(url,msg){
        if ($.trim(msg) == '{$Plang['bf65ea752affb32e']}') {
            wq_setTimeout();
        }
    }
    $(function () {
        var scroll_locked = true, page = '$page', count = "$count", perpage = "$perpage";
        $(window).bind('scroll', function () {
            if (scroll_locked && count / perpage > page && $(document).scrollTop() + wq_window_height > $(document).height() - 500) {
                scroll_locked = false;
                loadthread();
            }
        });
        function loadthread() {
            $(".p_load_more").show();
            page++;
            $.ajax({
                type: 'POST',
                url: "plugin.php?",
                data: {fid: "$_G['forum']['fid']", id: 'wq_buluo', mod: 'rank', inajax: '1', page: page},
                dataType: 'html',
            }).success(function (s) {
                $('#mainlist').append(wqXml(s));
                $(".p_load_more").hide();
                scroll_locked = true;
            })
        }
    });
</script>
<!--{/if}-->
<!--{if $wq_touch}-->
    <!--{eval $wq_footer_hide='1';}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->