<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $style = $wq_buluo_level[style][$lid][content];}-->
<div class="mod_content y" id="mod_content">
    <div class="wrap">
        <h3 class="page_title">{$Plang[72975de6ac99de8b]}</h3>
        <p class="page_desc">{$Plang[878e045e0814fe54]}
            <!--{if $setting[level_comment]}-->
            <a href="$setting[level_comment]" target="_blank"  class="wqcolor">{$Plang[6f2f07b81cc255b2]}</a>
            <!--{/if}-->
        <div class="mod_rank_title">
            <p><a href="javascript:;" class="wqcolor y wqcolorY">{$Plang[3603f96b5a1b4eee]}</a></p>
            <div id="show_tab">
                <div style="padding:10px 0;"></div>
                <table  border="1" cellspacing="0" cellpadding="0">
                    <!--{loop $style $key $val}-->
                    <tr>
                        <td><span class="rank_logo logo_color_{$key}">LV.<!--{eval echo $key;}--></span><span id="lv{$key}" class="ranklist_item_shower" >{$val}</span></td>
                        <!--{if ($key+10) < count( $style)}-->
                        <td><span  class="rank_logo logo_color_<!--{eval echo $key+10;}-->">LV.<!--{eval echo $key+10;}--></span><span id="lv<!--{eval echo $key+10;}-->" class="ranklist_item_shower" ><!--{eval echo $style[$key+10];}--></span></td>
                        <!--{else}-->
                        <td><span></span><span></span></td>
                        <!--{/if}-->
                        <!--{if $key >= floor(count($style)/2)}-->
                        <!--{eval break;}-->
                        <!--{/if}-->
                    </tr>
                    <!--{/loop}-->
                </table>
                <div class="y edit_title" ><span class="btn_primary"><a href="javascript:;">{$Plang[cd8d544238abb5d5]}</a></span></div>
            </div>
            <div id="fastpostreturn" style="margin:-5px 0 5px"></div>
            <div id="cancel_tab" style="display:none">
                <p class="mod_rank_info">{$Plang[6aa96833c7b725dd]}</p>
                <form style="padding:0; margin:0;" onsubmit="ajaxpost('levelForm', 'fastpostreturn', 'fastpostreturn', 'onerror');
                        return false;" id="levelForm" action="plugin.php?id=wq_buluo&mod=levelstyle" method="post">
                    <input type="hidden" name="formhash" value="{FORMHASH}"/>
                    <input type="hidden" name="handlekey" value="level"/>
                    <input type="hidden" name="fid" value="{$_G[fid]}"/>
                    <input type="hidden" name="levelsubmit" value="yes"/>
                    <table border="1" cellspacing="0" cellpadding="0" >
                        <!--{loop $style $key $val}-->
                        <tr>
                            <td><span class="rank_logo logo_color_{$key}">LV.<!--{eval echo $key;}--></span><input name="level[$key]" data="{$key}" type="text" class="ranklist_item_tab" id="alv{$key}" value="{$val}"/></td>
                            <!--{if ($key+10) < count( $style)}-->
                            <td><span class="rank_logo logo_color_<!--{eval echo $key+10;}-->">LV.<!--{eval echo $key+10;}--></span><input data="<!--{eval echo $key+10;}-->" name="level[<!--{eval echo $key+10;}-->]" type="text" id="alv<!--{eval echo $key+10;}-->" class="ranklist_item_tab" value="<!--{eval echo $style[$key+10];}-->"/></td>
                            <!--{else}-->
                            <td><span></span><span></span></td>
                            <!--{/if}-->
                            <!--{if $key >= floor(count($style)/2)}-->
                            <!--{eval break;}-->
                            <!--{/if}-->
                        </tr>
                        <!--{/loop}-->
                    </table>
                    <div class="y" id="cancel"><input type="reset" class="btn_default wqm_r5" value="{$Plang[9c825be7149e5b97]}"><button class="btn_primary">{$Plang[dd312dbd997b0758]}</button></div>
                </form>
            </div>
        </div>
        <div id="fastpostretur" style="margin:-5px 0 5px"></div>
        <div class="d_mask" style="display: none;"></div>
        <div class="dialog_div" style="display: none;">
            <h3>{$Plang[ae0c79fa6bd7b9ff]}<span class="y iconfont wqicon-guanbi wq_grey" ></span></h3>
            <div class="dialog_section" id="wq_levelstyle_list1">
                <ul>
                    <!--{loop $wq_buluo_level[style] $key $val}-->
                    <!--{if $val[type]==0}-->
                    <!--{eval $wqstyle[$key] = $val;}-->
                    <li {if $key == $lid} class="rank_title_active" {/if} data="{$key}">$val[name]</li>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <li data="0" id="rank_title" {if !$lid ||($lid && $wq_buluo_level[style][$lid][type]==1)} class="rank_title_active " {/if}>{$Plang[a8785c3dbc5f1798]}<i class="iconfont wqicon-202 wq_f12"></i></li>
                </ul>
                <div class="rank_title_arrow" style="left: 67px; "><i class="iconfont">&#xe628;</i></div>
            </div>
            <div class="dialog_border"></div>
            <div class="dialog_section" >
                <table  class="wq_level_list" id="wq_levelstyle1_0"  border="0" cellspacing="0" cellpadding="0" width="100%" <!--{if $wq_buluo_level[style][$lid][type]==='0'}-->style="display: none;"<!--{/if}-->>
                        <!--{loop $style $k $v}-->
                        <tr>
                        <td><span class="rank_logo wqm_l0 logo_color_{$k}">LV.{$k}</span><span class="rank_name">{$v}</span></td>
                        <!--{if ($k+13) < count($style)}-->
                        <td><span class="rank_logo wqm_l0 logo_color_<!--{eval echo ($k+7)}-->">LV.<!--{eval echo ($k+7)}--></span><span class="rank_name"><!--{eval echo $style[$k+7];}--></span></td>
                        <td><span class="rank_logo wqm_l0 logo_color_<!--{eval echo ($k+13)}-->">LV.<!--{eval echo ($k+13)}--></span><span class="rank_name"><!--{eval echo $style[$k+13];}--></span></td>
                        <!--{else}-->
                        <td><span ></span><span></span></td>
                        <td><span></span><span></span></td>
                        <!--{/if}-->
                        <!--{if $k >= floor(count($style)/3)}-->
                        <!--{eval break;}-->
                        <!--{/if}-->
                    </tr>
                    <!--{/loop}-->
                </table>
                <form onsubmit="ajaxpost('styleForm', 'fastpostretur', 'fastpostretur', 'onerror');
                        return false;" id="styleForm" action="plugin.php?id=wq_buluo&mod=levelstyle" method="post">
                    <input type="hidden" name="handlekey" value="leveltab"/>
                    <input type="hidden" name="formhash" value="{FORMHASH}"/>
                    <input type="hidden" name="fid" value="{$_G[fid]}"/>
                    <input type="hidden" name="levelsubmit" value="yes"/>
                    <input type="hidden" id="wq_lid" name="lid" value="$lid"/>
                    <!--{loop $wqstyle $key $val}-->
                    <table class="wq_level_list" id="wq_levelstyle1_{$key}" border="0" cellspacing="0" cellpadding="0" width="100%" <!--{if $key!=$lid}-->style="display: none;"<!--{/if}-->>
                           <!--{loop $val[content] $k $v}--><tr>
                            <td><span class="rank_logo wqm_l0 logo_color_{$k}">LV.{$k}</span><span class="rank_name" data="{$k}">{$v}</span></td>
                            <!--{if ($k+13) < count( $val[content])}-->
                            <td><span class="rank_logo wqm_l0 logo_color_<!--{eval echo ($k+7)}-->">LV.<!--{eval echo ($k+7)}--></span>
                                <span class="rank_name" data="<!--{eval echo ($k+7)}-->"><!--{eval echo $val[content][$k+7];}--></span></td>
                            <td><span class="rank_logo wqm_l0 logo_color_<!--{eval echo ($k+13)}-->">LV.<!--{eval echo ($k+13)}--></span><span class="rank_name" data="<!--{eval echo ($k+13)}-->"><!--{eval echo $val[content][$k+13];}--></span></td>
                            <!--{else}-->
                            <td><span></span><span></span></td>
                            <td><span></span><span></span></td>
                            <!--{/if}-->
                            <!--{if $k >= floor(count($val[content])/3)}-->
                            <!--{eval break;}-->
                            <!--{/if}-->
                        </tr>
                        <!--{/loop}-->
                    </table>
                    <!--{/loop}-->
                    <div class="y btn_wrap"><button class="btn_primary">{$Plang[a8cbddffef156dba]}</button></div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    wqjq(document).ready(function () {
        wqjq('#wq_levelstyle_list1 li').click(function () {
            var data = wqjq(this).attr('data');
            wqjq('#wq_levelstyle_list1 li').removeClass('rank_title_active');
            wqjq(this).addClass('rank_title_active');
            wqjq('.wq_level_list').hide();
            wqjq('#wq_levelstyle1_' + data).show();
            wqjq('#wq_lid').val(data);
        });

        wqjq('#levelForm tr input').focus(function () {
            wqjq(this).addClass(' ranklist_item_tab_on');

        });
        wqjq('#levelForm tr input').blur(function () {
            wqjq(this).removeClass(' ranklist_item_tab_on');
        });

        wqjq('.wqcolorY').click(function () {
            show_cancel(4)
        });
        wqjq('.wq_grey').click(function () {
            show_cancel(3)
        });
        wqjq('.edit_title').click(function () {
            show_cancel(2);
        });
        wqjq('.btn_default').click(function () {
            show_cancel(1);
        });
    });
    function  succeedhandle_level(url, msg, val) {
        var levelInput = wqjq('#levelForm input:text');
        var succ = levelInput.each(function (n) {
            var value = wqjq(this).val();
            var data = wqjq(this).attr('data');
            wqjq('#lv' + data).text(value);
        });
        if (succ) {
            show_cancel(1);
        }
    }

    function  succeedhandle_leveltab(url, msg, val) {
        if (val['lid']) {
            var levelTab = wqjq('#wq_levelstyle1_' + val['lid'] + ' .rank_name');
            levelTab.each(function (n) {
                var values = wqjq(this).text();
                var datas = wqjq(this).attr('data');
                wqjq('#lv' + datas).text(values);
                wqjq('#alv' + datas).val(values);
            });
        }
        show_cancel(3);
        if (wqjq('#cancel_tab').show()) {
            show_cancel(1);
        }
    }

    wqjq('#rank_title').click(function () {
        show_cancel(3);
        show_cancel(2);
    });
    function show_cancel(falg) {
        switch (falg) {
            case 1:
                wqjq('#cancel_tab').hide();
                wqjq('#show_tab').show();
                break;
            case 2:
                wqjq('#cancel_tab').show();
                wqjq('#show_tab').hide();
                break;
            case 3:
                wqjq('.d_mask').hide();
                wqjq('.dialog_div').hide();
                break;
            case 4:
                wqjq('.d_mask').show();
                wqjq('.dialog_div').show();
                break;
        }
    }
    for(var i = 0;i < 4;i++){
        document.querySelectorAll("#wq_levelstyle_list1 li")[i].onclick = function(e){
        var number = e.target.getAttribute("data");

        switch(number){
            case "0":
                wqjq(".rank_title_arrow").css("left","530px");
                break;
            case "1":
                wqjq(".rank_title_arrow").css("left","65px");
                break;
            case "2":
                wqjq(".rank_title_arrow").css("left","215px");
                break;
            case "3":
                wqjq(".rank_title_arrow").css("left","375px");
                break;
        }
    }
    }

</script>