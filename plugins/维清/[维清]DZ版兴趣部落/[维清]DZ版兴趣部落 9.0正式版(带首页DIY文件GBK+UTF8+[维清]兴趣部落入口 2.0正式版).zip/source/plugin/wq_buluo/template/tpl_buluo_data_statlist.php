<?php exit("From: DisM.taobao.com"); ?>

<!--{if $type == '1'}-->
	<div class="chart_record" id="chart_record_type1">
		<table border="1">
			<tr>
                            <th>{$Plang[43ff346f5d181d35]}</th>
                            <th>{$Plang[b8c14f86b53946dd]}</th>
                            <th>{$Plang[5e5ee560a7cce5d7]}</th>
                            <th>{$Plang[c0226e8c4f24b0f5]}</th>
			</tr>
			<!--{loop $statdatalist $value}-->
			<tr>
				<td><!--{eval echo date("Y-m-d",$value['dateline']);}--></td>
				<td>{$value['newfollow']}</td>
				<td>{$value['unfollow']}</td>
				<td>{$value['todayfollow']}</td>
			</tr>
			<!--{/loop}-->
		</table>
		{$multi}
	</div>
<!--{elseif $type == '2'}-->
	<div class="chart_record type2" id="chart_record_type2">
			<table border="1">
				<tr>
                                    <th>{$Plang[43ff346f5d181d35]}</th>
                                    <th>{$Plang[b73b4fcbe9ad2811]}(PV)</th>
                                    <th>{$Plang[d3e61519cbd5b573]}(UV)</th>
                                    <th>{$Plang[d331302dd80c5713]}</th>
                                    <th>{$Plang[ca5381012ad03b83]}</th>
                                    <th>{$Plang[d9b592b92d0694c6]}</th>
				</tr>
				<!--{loop $statdatalist $value}-->
				<tr>
					<td><!--{eval echo date("Y-m-d",$value['dateline']);}--></td>
					<td>{$value['pv']}</td>
					<td>{$value['uv']}</td>
					<td>{$value['signnum']}</td>
					<td>{$value['activenum']}</td>
					<td>{$value['threadnum']}</td>
				</tr>
				<!--{/loop}-->
			</table>
			{$multi}
		</div>
<!--{/if}-->