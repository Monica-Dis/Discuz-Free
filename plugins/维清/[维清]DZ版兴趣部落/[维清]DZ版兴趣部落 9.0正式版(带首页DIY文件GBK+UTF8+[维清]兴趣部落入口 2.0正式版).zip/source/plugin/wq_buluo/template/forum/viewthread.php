<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_buluo:common/tpl_header}-->

    <script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
    <!--{if $modmenu['thread'] || $modmenu['post']}-->
        <script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
    <!--{/if}-->
    <script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
    <script type="text/javascript">
        zoomstatus = parseInt($_G['setting']['zoomstatus']); var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}'; var aimgcount = new Array();
    </script>


    <!--{hook/viewthread_top}-->
    <!--{ad/text/wp a_t}-->
    <style id="diy_style" type="text/css"></style>
    <div class="wp">
        <!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->
    </div>

     <!--{if $modmenu['post']}-->
        <div class="fwinmask_warp">
           <div id="mdly" class="fwinmask" style="display:none;z-index:350; background: none;">
               <table cellspacing="0" cellpadding="0" class="fwin">
                   <tr>
                       <td class="t_l"></td>
                       <td class="t_c"></td>
                       <td class="t_r"></td>
                   </tr>
                   <tr>
                       <td class="m_l">&nbsp;&nbsp;</td>
                       <td class="m_c">
                           <div class="f_c">
                               <div class="c">
                                    <h3>{$Tlang[e817a63de5732cff]}<strong id="mdct" class="xi1"></strong>&nbsp;{$Tlang[gvvsdt23rdyd7823]}</h3>
                                    <!--{if $_G['forum']['ismoderator']}-->
                                        <!--{if $_G['group']['allowwarnpost']}-->
                                           <a href="javascript:;" onclick="modaction('warn')">{$Tlang[b2gwvid234vc34e4]}</a><span class="pipe">|</span>
                                        <!--{/if}-->
                                        <!--{if $_G['group']['allowbanpost']}-->
                                           <a href="javascript:;" onclick="modaction('banpost')">{$Tlang[t478grvhfibrnjek]}</a><span class="pipe">|</span>
                                        <!--{/if}-->
                                        <!--{if $_G['group']['allowdelpost'] && !$rushreply}-->
                                           <a href="javascript:;" onclick="modaction('delpost')">{$Tlang[0d9efacf5089d88c]}</a><span class="pipe">|</span>
                                        <!--{/if}-->
                                    <!--{/if}-->

                                    <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}-->
                                        <a href="javascript:;" onclick="modaction('stickreply')">{$Tlang[01ff72df2ca84800]}</a><span class="pipe">|</span>
                                    <!--{/if}-->

                                    <!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}-->
                                        <a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span>
                                    <!--{/if}-->
                               </div>
                           </div>
                       </td>
                       <td class="m_r"></td>
                   </tr>
                   <tr>
                       <td class="b_l"></td>
                       <td class="b_c"></td>
                       <td class="b_r"></td>
                   </tr>
               </table>
           </div>
       </div>
    <!--{/if}-->


    <div class="<!--{if $pc_is_headbottom}-->wp <!--{/if}--> cl">
        <!--{hook/viewthread_beginline}-->
        <!--{eval
            $_G[forum][icon] = get_groupimg($_G['forum']['icon'], 'icon');
            $threadlist = wq_buluo_get_group_fid_for_tidinfo($_G['forum']['fid']);
        }-->
        <div id="postlist" class="pl group_in_con">
            <div class="gv_right">
                <!--[diy=viewthread1]--><div id="viewthread1" class="area"></div><!--[/diy]-->
                <!--diyarea_280px-->
                <div class="qz_in_con">
                   <a href="buluo.php?mod=group&fid=$_G[fid]">
                        <span class="qz_head"><img src="$_G[forum][icon]" alt="$_G[forum][name]"/></span>
                        <div class="qz_head_r">
                            <h3>$_G[forum][name]</h3>
                             <p> {$Tlang[8ea9c932f8444151]} $_G[forum][posts] {$Tlang[72843rfi2398ofic]} $_G[forum][membernum]</p>
                        </div>
                    </a>
                </div>
                <!--[diy=diywqc]--><div id="diywqc" class="area"></div><!--[/diy]-->
                <!--diyarea_280px-->

                <!--{if $threadlist}-->
                    <div class="recommend">
                        <h3><i class="iconfont wqicon-huo c_orange"></i>{$Tlang[fgew78fviud32r4t]}</h3>
                        <ul>
                            <!--{loop $threadlist $key $val}-->
                            <li><a href="buluo.php?mod=viewthread&tid={$val[tid]}&extra=">$val[subject]</a></li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                    <!--[diy=viewthread2]--><div id="viewthread2" class="area"></div><!--[/diy]-->
                    <!--diyarea_280px-->
                <!--{/if}-->
            </div>

            <!--{hook/viewthread_title_row}-->
            <!--{eval $postcount = 0;}-->
            <div class="g_text_con">
                <!--[diy=viewthread3]--><div id="viewthread3" class="area"></div><!--[/diy]-->
                <!--diyarea_710px-->
                <!--{eval $groupuser=wq_buluo_get_fid_member($_G['fid']);}-->

                <!--{loop $postlist $post}-->
                    <!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
                        <!--{eval continue;}-->
                    <!--{/if}-->
                    <div class="" id="post_$post[pid]" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>
                         <!--{subtemplate wq_buluo:forum/viewthread_node}-->
                    </div>
                    <!--{eval $postcount++;}-->
                <!--{/loop}-->
                <div id="postlistreply" class="pl">
                    <div id="post_new" class="viewthread_table" style="display: none"></div>
                </div>

				<!--{if $_G['blockedpids']}-->
					<div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>
					<div id="hiddenposts"></div>
				<!--{/if}-->

                <div class="wqpc_separate"></div>
                <!--{eval $replylist = wq_buluo_get_tid_reply_list($ordertype,$_GET[authorid],$_G['forum_thread']['replies'] + 1, $_G['ppp'], $page,$_G['tid']);}-->
                <!--{if $replylist}-->
                    <!--[diy=viewthread7]--><div id="viewthread7" class="area"></div><!--[/diy]-->
                    $replylist
                <!--{/if}-->

                <script>
                    wqjq(".page_list_js").hover(function () {
                        wqjq(this).children('div').show();
                    }, function () {
                        wqjq(this).children('div').hide();
                    });
                </script>

                <!--{if $replylist}--><div class="wqpc_separate"></div> <!--{/if}-->
                <!--[diy=viewthread6]--><div id="viewthread6" class="area"></div><!--[/diy]-->
                <!--diyarea_710px-->
                <!--{template wq_buluo:forum/viewthread_fastpost}-->
                <!--[diy=viewthread5]--><div id="viewthread5" class="area"></div><!--[/diy]-->
                <!--diyarea_710px-->
            </div>
        </div>
    </div>

    <!--{eval $extra =dhtmlspecialchars($_GET['extra']); }-->
    <form method="post" autocomplete="off" name="modactions" id="modactions">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="optgroup" />
        <input type="hidden" name="operation" />
        <input type="hidden" name="listextra" value="<!--{eval echo dhtmlspecialchars($extra);}-->" />
        <input type="hidden" name="page" value="$page" />
    </form>
    $_G['forum_tagscript']
    <!--{hook/viewthread_middle}-->
    <!--{hook/viewthread_bottom}-->

    <!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->
        <div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
            <table cellspacing="0" cellpadding="0">
                <tr>
                    <td id="v_forums">
                        <h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
                        <ul class="xl xl1">
                            $_G['setting']['visitedforums']
                        </ul>
                    </td>
                </tr>
            </table>
        </div>
    <!--{/if}-->

    <!--{if $_G['medal_list']}-->
        <!--{loop $_G['medal_list'] $medalid $medal}-->
            <div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">
                <div class="tip_horn"></div>
                <div class="tip_c">
                    <h4>$medal[name]</h4>
                    <p>$medal[description]</p>
                </div>
            </div>
        <!--{/loop}-->
    <!--{/if}-->

    <!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
        <script type="text/javascript">new lazyload();</script>
    <!--{/if}-->

    <!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->
        <!--{eval $authorid =dhtmlspecialchars($_GET['authorid']); }-->
        <script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid={$authorid}<!--{/if}-->', $page);}</script>
    <!--{/if}-->

    <div class="wp mtn">
        <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
        <!--diyarea_1000px-->
    </div>

    <!--{if $_G['relatedlinks'] || $_GET['highlight']}-->
        <script type="text/javascript">
            var relatedlink = [];
            <!--{loop $_G['relatedlinks'] $key $link}-->
                relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
            <!--{/loop}-->
            {eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight']))); }

            <!--{loop $highlights $word}-->
                {eval $key++; }
                relatedlink[$key] = {'sname':'$word', 'surl':''};
            <!--{/loop}-->
            relatedlinks('postmessage_$_G[forum_firstpid]');
        </script>
    <!--{/if}-->

    <!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->
        <script type="text/javascript">saveUserdata('forum_' + discuz_uid, '')</script>
    <!--{/if}-->

    <script type="text/javascript">
        <!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
            function showsetcover(obj) {
                if (obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {
                    var defheight = $_G['setting']['forumpicstyle']['thumbheight'];
                    var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];
                    var newimgid = 'showcoverimg';
                    var imgsrc = obj.src ? obj.src : obj.file;

                    if (!imgsrc) return;

                    var tempimg = new Image();
                    tempimg.src = imgsrc;

                    if (tempimg.complete) {
                        if (tempimg.width < defwidth || tempimg.height < defheight) return;
                    } else {
                        return;
                    }

                    if ($(newimgid) && obj.id != newimgid) {
                        $(newimgid).id = 'img' + Math.random();
                    }

                    if ($(newimgid + '_menu')) {
                        var menudiv = $(newimgid + '_menu');
                    } else {
                        var menudiv = document.createElement('div');
                        menudiv.className = 'tip tip_4 aimg_tip';
                        menudiv.id = newimgid + '_menu';
                        menudiv.style.position = 'absolute';
                        menudiv.style.display = 'none';
                        obj.parentNode.appendChild(menudiv);
                    }
                    menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_' + newimgid + '\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl=' + imgsrc + '">{lang set_cover} < /a></div > ';
                    obj.id = newimgid;
                    showMenu({'ctrlid':newimgid, 'pos':'12'});
                }
                return;
            }
        < !--{/if}-->

        function succeedhandle_followmod(url, msg, values) {
            var fObj = $('followmod_' + values['fuid']);
            if (values['type'] == 'add') {
                fObj.innerHTML = '{lang nofollow}';
                fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid=' + values['fuid'];
            } else if (values['type'] == 'del') {
                fObj.innerHTML = '{lang follow}';
                fObj.href = 'home.php?mod = spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + values['fuid'];
            }
        }

        <!--{if $_G['blockedpids']}-->
            var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];
        <!--{/if}-->
        <!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->
            fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});
        <!--{elseif empty($_G['setting']['disfixednv_viewthread'])}-->
            fixed_top_nv();
        <!--{/if}-->
    </script>
<!--{template wq_buluo:common/tpl_footer}-->