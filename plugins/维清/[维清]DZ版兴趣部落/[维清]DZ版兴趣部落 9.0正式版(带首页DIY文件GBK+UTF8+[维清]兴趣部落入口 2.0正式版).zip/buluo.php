<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: buluo.php 2016-8-12 15:18:31Z $
 */
define("IN_BULUO", TRUE);
$_WQ = wq_checkmobile();

$_mod = !empty($_GET['mod']) ? trim($_GET['mod']) : "";
$action = $mod = '';
$status = isset($_GET['status']) ? intval($_GET['status']) : 0;

if (in_array($_mod, array('group', 'post', 'forumdisplay', 'viewthread'))) {

    $_action = !empty($_GET['action']) ? trim($_GET['action']) : "";
    $search = !empty($_GET['search']) ? trim($_GET['search']) : "";
    if ($_mod == 'group' && $_action == '' && $search == '' && !in_array($status, array(2, 3))) {
        $_GET['mod'] = 'forumdisplay';
        $_GET['action'] = 'list';
    }
    if ($_mod == 'group' && $search == 'yes') {

        require './search.php';
        if (!$_G['mobile']) {
            ob_end_clean();
            $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();

            include template('group', 0, 'source/plugin/wq_buluo/template/search');
        }
    } else {
        require './forum.php';
        include_once libfile('function/home');
        if (!$_G['mobile']) {
            ob_end_clean();
            $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
            $_G['uploadjs'] = '';
            $_G['style']['tplfile'] = '';
            if ($mod == 'group') {
                $_G['cache']['diytemplatenamegroup'] = array('group' => 1);
                if (in_array($action, array('index', 'memberlist', 'create', 'manage'))) {
                    include template('diy:group', 0, 'source/plugin/wq_buluo/template/group');
                } elseif ($action == 'recommend') {
                    include_once template("wq_buluo:group/group_recommend");
                }
            } elseif ($mod == 'post') {
                getgpc('infloat') ? include template('wq_buluo:forum/post_infloat') : include template('wq_buluo:forum/post');
            } elseif ($mod == 'forumdisplay') {
                $_G['cache']['diytemplatenameforum'] = array('group_' . $_G['fid'] => 1);
                include template('diy:group:' . $_G['fid'], 0, 'source/plugin/wq_buluo/template/group');
            } elseif ($mod == 'viewthread') {
                $_G['cache']['diytemplatenameforum'] = array('viewthread' . $sufix . '_' . $_G['fid'] => 1);
                include template('diy:viewthread' . $sufix . ':' . $_G['fid'], 0, 'source/plugin/wq_buluo/template/forum');
            }
        }
    }
} else {
    require './group.php';
    include_once libfile('function/home');
    if (!$_G['mobile']) {
        ob_end_clean();
        $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
        $_G['uploadjs'] = '';
        $_G['style'] ['tplfile'] = '';
        if ($mod == 'index') {

            if (empty($curtype)) {
                $_G['cache']['diytemplatenamegroup'] = array('index' => 1);
                include template('diy:index', 0, 'source/plugin/wq_buluo/template/group');
            } else {
                if (empty($sgid)) {
                    $_G['cache']['diytemplatenamegroup'] = array('type_' . $gid => 1);
                    include template('diy:type:' . $gid, 0, 'source/plugin/wq_buluo/template/group');
                } else {
                    $_G['cache']['diytemplatenamegroup'] = array('type_' . $fup => 1);
                    include template('diy:type:' . $fup, 0, 'source/plugin/wq_buluo/template/group');
                }
            }
        } elseif ($mod == 'my') {
            $_G['cache']['diytemplatenamegroup'] = array('group_my' => 1);
            include template('diy:group_my', 0, 'source/plugin/wq_buluo/template/group');
        } elseif ($mod == 'attentiongroup') {
            include template('diy:group_attentiongroup', 0, 'source/plugin/wq_buluo/template/group');
        }
    }
}

if (!$_G['mobile']) {
    $content = ob_get_contents();
    ob_end_clean();
    $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
    $content = buluo_output($content);
    preg_match_all('/{+\$+[_a-z]([a-z]||[+[+a-z+]+])+}/', $content, $arr);

    foreach ($arr[0] as $key => $val) {
        $_search[$key] = $val;
        $replace = trim(str_replace(array('{', "}"), array("", ""), $val));
        eval("\$replace = \"$replace\";");
        $_replace[] = $replace;
    }
    $content = str_replace($_search, $_replace, $content);
    echo $content;
}

function buluo_output($content) {
    global $_G;
    if (CHARSET == 'gbk') {
        include DISCUZ_ROOT . './source/plugin/wq_buluo/language/lang_template_gbk.php';
    } else {
        include DISCUZ_ROOT . './source/plugin/wq_buluo/language/lang_template_utf8.php';
    }
    include_once DISCUZ_ROOT . './source/discuz_version.php';

    preg_match_all("/!+[a-z_]+!/", $content, $arr);
    foreach ($arr[0] as $key => $lang_key) {
        $_search[$key] = $lang_key;
        $_replace[$key] = $lang[str_replace("!", "", $lang_key)];
    }

    $content = str_replace($_search, $_replace, $content);


    $content = str_replace(array('forum.php?mod=group&fid', 'forum.php?mod=viewthread&tid='), array('buluo.php?mod=group&fid', 'buluo.php?mod=viewthread&tid='), $content);

    $content = str_replace($lang['index_qunzu'], $lang['index_buluo'], $content);

    loadcache("plugin");
    $pluginname = trim($_G['cache']['plugin']['wq_buluo']['pluginname']);

    if ($pluginname != $lang['index_buluo']) {
        $content = str_replace($lang['index_buluo'], $pluginname, $content);
    }

    if (defined('IN_MODCP') || defined('IN_ADMINCP')) {
        return $content;
    }
    if (!empty($_G['setting']['output']['preg']['search']) && (empty($_G['setting']['rewriteguest']) || empty($_G['uid']))) {
        if (empty($_G['setting']['domain']['app']['default'])) {
            $_G['setting']['output']['preg']['search'] = str_replace('\{CURHOST\}', preg_quote($_G['siteurl'], '/'), $_G['setting']['output']['preg']['search']);
            $_G['setting']['output']['preg']['replace'] = str_replace('{CURHOST}', $_G['siteurl'], $_G['setting']['output']['preg']['replace']);
        }

        if (DISCUZ_VERSION < 'X3.3' && DISCUZ_VERSION != 'F1.0') {
            $content = preg_replace($_G['setting']['output']['preg']['search'], $_G['setting']['output']['preg']['replace'], $content);
        } else {
            foreach ($_G['setting']['output']['preg']['search'] as $key => $value) {
                $content = preg_replace_callback($value, create_function('$matches', 'return ' . $_G['setting']['output']['preg']['replace'][$key] . ';'), $content);
            }
        }
    }

    return $content;
}

function wq_checkmobile() {
    static $touchbrowser_list = array('iphone', 'android', 'phone', 'mobile', 'wap', 'netfront', 'java', 'opera mobi', 'opera mini',
        'ucweb', 'windows ce', 'symbian', 'series', 'webos', 'sony', 'blackberry', 'dopod', 'nokia', 'samsung',
        'palmsource', 'xda', 'pieplus', 'meizu', 'midp', 'cldc', 'motorola', 'foma', 'docomo', 'up.browser',
        'up.link', 'blazer', 'helio', 'hosin', 'huawei', 'novarra', 'coolpad', 'webos', 'techfaith', 'palmsource',
        'alcatel', 'amoi', 'ktouch', 'nexian', 'ericsson', 'philips', 'sagem', 'wellcom', 'bunjalloo', 'maui', 'smartphone',
        'iemobile', 'spice', 'bird', 'zte-', 'longcos', 'pantech', 'gionee', 'portalmmm', 'jig browser', 'hiptop',
        'benq', 'haier', '^lct', '320x320', '240x320', '176x220', 'windows phone');

    $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);

    if (($v = wqstrpos($useragent, $touchbrowser_list, true))) {
        $_WQ['mobile'] = $v;
        return $_WQ;
    }

    return false;
}

function wqstrpos($string, $arr, $returnvalue = false) {
    if (empty($string))
        return false;
    foreach ((array) $arr as $v
    ) {
        if (strpos($string, $v) !== false) {
            $return = $returnvalue ? $v : true;

            return $return;
        }
    }
    return false;
}
//From: Dism_taobao-com
?>