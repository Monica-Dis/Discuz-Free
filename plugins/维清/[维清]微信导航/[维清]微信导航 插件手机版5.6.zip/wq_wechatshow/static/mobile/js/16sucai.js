$(document).ready(function()
{
	$("#firstpane p.menu_head").click(function()
    {
		$(this).css({backgroundImage:"url(images/down.png)"}).next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
       	$(this).siblings().css({backgroundImage:"url(images/left.png)"});
	});
	$("#secondpane p.menu_head").mouseover(function()
    {
	     $(this).css({backgroundImage:"url(images/down.png)"}).next("div.menu_body").slideDown(500).siblings("div.menu_body").slideUp("slow");
         $(this).siblings().css({backgroundImage:"url(images/left.png)"});
	});
});

$(document).ready(function()
{
	$("#firstpane2 p.menu_head2").click(function()
    {
		$(this).css({backgroundImage:"url(images/down.png)"}).next("div.menu_body2").slideToggle(300).siblings("div.menu_body2").slideUp("slow");
       	$(this).siblings().css({backgroundImage:"url(images/left.png)"});
	});
	$("#secondpane p.menu_head2").mouseover(function()
    {
	     $(this).css({backgroundImage:"url(images/down.png)"}).next("div.menu_body2").slideDown(500).siblings("div.menu_body2").slideUp("slow");
         $(this).siblings().css({backgroundImage:"url(images/left.png)"});
	});
});