<?php exit("Powered by www.wikin.cn"); ?>
<form name="post" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add&wechat=serve" method="post" enctype="multipart/form-data" id="image_upload">
    <input type="hidden" value="true" name="servesubmit"/>
    <input type="hidden" value="{FORMHASH}" name="formhash"/>
    <input type="hidden" name="portrait_img" id="portrait_img"/>
    <input type="hidden" name="qrcode_img" id="qrcode_img"/>
    <div class="wq_wechat_apply_list">
        <ul>
            <li class="wqwechat_bottom"><span>{$Plang['4b3b548154549518']}</span><input type="text" name="wechatusers" placeholder="{$Plang['573f73db7ab9b013']}"></li>
            <li class="wqwechat_bottom"><span>{$Plang['3982634cd20768c9']}</span><input type="text" name="name" placeholder="{$Plang['ed5b5720f28ff9cf']}"></li>
            <li class="wqwechat_bottom"><span>{$Plang['7963064a1954b8aa']}</span><input type="text" name="verify" placeholder="{$Plang['0f6e2fe33a4f8bb1']}"></li>
            <li class="wqwechat_bottom"><span>{$Plang['093288bbe08517a5']}</span><input type="text" name="summary" placeholder="{$Plang['0f9d6955ed754904']}"></li>
            <li class="wqpadding wqwechat_bottom">
               {$classselect}
            </li>
             <li class="wqhead wqwechat_bottom">
                 <div class="wqpersonal_secrecy_right wqm_left0">{$Plang['639bca6a6958faac']}
                    <input type="file" name="portrait" class="wq_head" id="portrait" />
                    <em class="wqy wq_arrow">
                        <i class="wqwechat wqwechat-jiantou-copy"></i>
                    </em>
                </div>
            </li>
             <li class="wqhead wqwechat_bottom">
                 <div class="wqpersonal_secrecy_right wqm_left0">{$Plang['ddd826aa11868c7d']}
                    <input type="file" name="qrcode" class="wq_head" id="qrcode" />
                    <em class="wqy wq_arrow">
                        <i class="wqwechat wqwechat-jiantou-copy"></i>
                    </em>
                </div>
            </li>
        </ul>
    </div>
    <div class="wqheight49"></div>
    <div class="wqwechat_num_view_follow wqwechat_top"><div class="wqwechat_num_view_follow_div"><button type="submit" class="wqformdialog">{lang submit}</button></div></div>
</form>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script>
    var url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add&wechat=serve&servesubmit=true&formhash={FORMHASH}';
    $(document).on('change', '#portrait,#qrcode', function () {
        picture(uploadsuccess_forum, $(this).prop('id'), $(this).prop('name'), typeof (url) == 'undefined' ? '' : url);
    });
    function picture(uploadsuccess, id, name, url) {
        var uploadurl = url ? url : 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve&servesubmit=true&formhash={FORMHASH}';
        var files = $('#'+id)[0].files;
        if (typeof FileReader != 'undefined' && files[0]) {
            $.buildfileupload({
                uploadurl:uploadurl,
                files:files,
                uploadformdata:{upload:1},
                uploadinputname:name,
                success:uploadsuccess,
                error:function() {
                    showDialog('{$Plang['38123cc536ee6760']}');
                }
            });
        } else {
            $.ajaxfileupload({
                    url:uploadurl,
                    data:{upload:1},
                    dataType:'json',
                    fileElementId:id,
                    success:uploadsuccess
            });
        }
    }
    var uploadsuccess_forum = function(data) {
        var newdata = JSON.parse(data);
        if(newdata['status'] != '0') {
            showDialog(newdata['msg']);
        }else{
            $('#' + newdata.name+'_img').val(newdata.msg);
            $('#' + newdata.name).next().html('<img src="' + newdata.msgurl + '" class="wqsethead"/>');
        }
    };
    $('body').on('click', '.wqsethead', function () {
        $('#portrait').click();
    });

    function errorhandle_image_upload(msg){
        if(wq_wechat_trim(msg)=="{$Plang['e021bb879c5187b7']}"){
            $('input[name="wechatusers"]').val('');
            $("input[name='name']").val('');
            $("input[name='verify']").val('');
            $("input[name='summary']").val('');
            $("input[name='portrait_img']").val('');
            $('#classid option').eq(0).attr('selected', 'selected')
            $('#portrait').next().html('<i class="wqwechat wqwechat-jiantou-copy"></i>');
            $('#qrcode').next().html('<i class="wqwechat wqwechat-jiantou-copy"></i>');
        }
    }
</script>