<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval echo wq_get_wq_ad_info('wq_wechatshow_header');}-->
<!--{template wq_wechatcollecting:common/header}-->
    <div class="wqwechat_groom">
        <div class="tag_list">
            <ul>
                <!--{if $top_recommedlist}-->
                    <!--{loop $top_recommedlist $key $val}-->
                        <!--{eval
                            $recommedlist = array(); $recommedlist[id] = 'wq_wechatshow'; $recommedlist[mod] = 'view'; $recommedlist[wid] = $val[wechatid]; $recommedlist['displayorder'] = 'index';
                            $recommedurl = 'plugin.php?'.url_implode($recommedlist);
                        }-->
                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <li>
                            <div class="wq_img"><a href="{$recommedurl}"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home"> </a></div>
                            <div class="wq_name"><a href="{$recommedurl}">{$val['name']}</a></div>
                            <!--{if $plugin_wechatreader}-->
                                <!--{if !in_array($val['id'],$subscription)}-->
                                    <div class="wq_btn">
                                        <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}&handlekey=attention" class="wqattention_{$val[id]}">
                                            <span>+</span> {$Plang['2c8a07313e7706bc']}
                                        </a>
                                    </div>
                                <!--{else}-->
                                    <div class="wq_btn">
                                        <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}&handlekey=attention" class="wqdialog wqattention_{$val[id]}">
                                             <span>-</span> {$Plang['2c8a07313e7706bc']}
                                        </a>
                                    </div>
                                <!--{/if}-->
                            <!--{/if}-->
                        </li>
                    <!--{/loop}-->
                <!--{/if}-->
                <!--{if $adarr}-->
                    <!--{loop $adarr $val}-->
                        <li class="wq_xwyd">
                            <a href="{$setting[top_help_url]}">
                             <img src="./source/plugin/wq_wechatcollecting/static/mobile/images/wq_ad_zhaozu.png">
                             <br><span class="wq_settled">{$Plang['84e2c8cruzhu9d']}</span>
                            </a>
                        </li>
                    <!--{/loop}-->
                <!--{/if}-->
            </ul>
         </div>
    </div>
    <div class="wqwechat_separate"></div>
       <!--{subtemplate wq_wechatshow:classlist}-->
    <div class="wqwechat_numfollow_one">
        <!--{if $list}-->
            <ul>
                <!--{eval $adinfo = wq_get_wq_ad_info('wq_wechatshow_list_n');$i=1;}-->
                <!--{loop $list $key $val}-->
                    <!--{if $adinfo}-->
                        <!--{loop $adinfo $k $v}-->
                            <!--{if in_array($i,$v['perpage'])}-->
                                    <!--{eval echo $v['adinfo'];}-->
                            <!--{/if}-->
                        <!--{/loop}-->
                    <!--{/if}-->
                    <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
                    <li class="wqwechat_bottom_right">
                        <div class="wq_warp">
                         <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <div class="wq_img">
                            <a href="{$url}"><img  src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home"></a>
                        <!--{if $plugin_wechatreader}-->
                                    <!--{if !in_array($val['id'],$subscription)}-->
                                        <p>
                                            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}&handlekey=attention" class="wqattention_{$val[id]}">
                                                <span>+</span> {$Plang['2c8a07313e7706bc']}
                                            </a>
                                        </p>
                                    <!--{else}-->
                                        <p>
                                            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}&handlekey=attention" class="wqdialog wqon wqattention_{$val[id]}">
                                                <span>-</span> {$Plang['2c8a07313e7706bc']}
                                            </a>
                                        </p>
                                    <!--{/if}-->
                                <!--{/if}-->
                        </div>
                            <div class="wq_con">
                                <a href="{$url}">
                                <h3>{$val[name]}</h3>
                                <p class="wq_weixin">{$val[wechatid]}</p>
                                   <!--{if !empty({$val[intro]})}-->
                                <p class="wq_jieshao">{$val[intro]}</p>
                                 <!--{/if}-->
                                </a>
                            </div>
                        </div>
                    </li>
                <!--{eval $i++;}-->
                <!--{/loop}-->
            </ul>
        <!--{else}-->
        <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['555cc518cd42d2d4']}</p>
        <!--{/if}-->
    </div>
    <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
    <script>
        function errorhandle_attention(msg,param){
            if(wq_wechat_trim(msg)=="{$Plang['bef022f6310db3b9']}"){
                $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid='+param.wid+'&handlekey=attention');
                $(".wqattention_"+param.wid+" span:first-child").html("+");
                $(".wqattention_"+param.wid).removeClass('wqon').removeClass("wqdialog");
            }
        }
    </script>
<!--{eval echo wq_get_wq_ad_info('wq_wechatshow_footer');}-->
<!--{template wq_wechatcollecting:common/footer}-->