<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/header}-->
    <!--{template wq_wechatcollecting:common/search}-->
    <!--{eval //echo "<pre>"; print_r($list);exit;}-->
        <!--{if $keyword}-->
            <!--{if $a_searchset['status'] && $w_searchset['status']}-->
                <div class="wq_wechat_seaech_menu wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatcollecting&mod=search&keyword={$keyword}"><span class="wqwechat_bottom_bule"></span>{$Plang['815a1f2328d92c06']}</a>
                    <a href="plugin.php?id=wq_wechatshow&mod=search&keyword={$keyword}&searchid={$searchid}" class="on"><span class="wqwechat_bottom_bule"></span>{$Plang['29c5793e392feabe']}</a>
                </div>
            <!--{/if}-->
            <div class="wqwechat_public">
                <!--{if $list}-->
                    <ul>
                        <!--{loop $list $key $val}-->
                            <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
                            <li class="wqwechat_bottom">
                                <a href="{$url}">
                                    <div class="wq_img">
                                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                                        <img  src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home">
                                        <span class="wqattestation"></span>
                                    </div>
                                    <div class="wq_con">
                                        <h3>{$val['name']}</h3>
                                        <p class="wqweixin">{$val['wechatid']}</p>
                                        <!--{if !empty({$val[intro]})}-->
                                            <p class="wqintroduce">{$val[intro]}</p>
                                        <!--{/if}-->
                                    </div>
                                </a>
                            </li>
                        <!--{/loop}-->
                    </ul>
                <!--{else}-->
                <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['a828d144460e33ce']}</p>
                <!--{/if}-->
            </div>
            <div class="wqheight40"></div>
            <div class="wqwechat_subscribe_btn wqwechat_top">
                <a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve">{$Plang['de712b148b45a704']}</a>
            </div>
        <!--{/if}-->
<!--{template wq_wechatcollecting:common/footer}-->