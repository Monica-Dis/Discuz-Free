<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval echo wq_get_wq_ad_info('wq_wechatshow_header');}-->
<!--{template wq_wechatcollecting:common/header}-->
    <div class="wqwechat_num_view">
        <div class="wqwechat_num_head">
            <!--{eval $logourl=$wechat['headimage'] ? $wechat['headimage'] : $wechat['qrcode'];}-->
            <div class="wq_img" >
                <img  src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home">
                <!--{if $isajax}-->
                    <p class="wqsynchro">
                        <a href="javascript:;"><i class="wqwechat wqwechat-tongbu-copy"></i>{$Plang['tongbuef298846ea']}</a>
                    </p>
                <!--{/if}-->
            </div>
            <div class="wq_con">
                <h3>{$wechat[name]}</h3>
                <p>{$Plang['e48060802398bf7f']}&nbsp;{$wechat[wechatid]}</p>
                <p>{$Plang['0efliulanli846ea']}&nbsp;{$wechat['views']} <span>{$Plang['0ef1guanzhu846ea']}&nbsp;<i id="favnum">{$wechat['favorites']}</i></span></p>
                <p>{$Plang['a5473c7550a44ed1']}&nbsp;<!--{eval echo dgmdate($wechat[collecttime],'d');}--></p>
            </div>

        </div>
        <!--{if !empty({$wechat[intro]})}-->
            <div class="wqwechat_function_warp wqwechat_bottom">
                <div class="wqwechat_function">
                        <span>{$Plang[intro]}</span>{$wechat[intro]}
                </div>
            </div>
        <!--{/if}-->
        <!--{if !empty({$wechat[verify]})}-->
            <div class="wqwechat_function_warp wqwechat_bottom">
                <div class="wqwechat_function">
                    <span>{$Plang['7963064a1954b8aa']}</span><img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png"><em>{$wechat[verify]}</em>
                </div>
            </div>
        <!--{/if}-->
    </div>
    <div class="wqwechat_separate"></div>
    <div class="wqwechat_num_view_menu wqwechat_bottom">
        <ul>
            <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $wechat[wechatid]; $getlist[displayorder] = 3;$url = 'plugin.php?'.url_implode($getlist);}-->
            <!--{if $wechat['recommend_num']}-->
                <li><a href="{$url}"<!--{if $ordernum == 3}--> class="on wqwechat_bottom_bule<!--{/if}-->">{$Plang['db11cdebc2eb37bd']}</a></li>
            <!--{/if}-->
            <!--{if $wechat['first_num']}-->
                <!--{eval $getlist[displayorder]=4; $url = 'plugin.php?'.url_implode($getlist);}-->
                <li><a href="{$url}"<!--{if $ordernum == 4}--> class="on wqwechat_bottom_bule"<!--{/if}-->>{$Plang['0ef1d1c8298846ea']}</a></li>
             <!--{/if}-->
            <li>
                <!--{eval $getlist[displayorder]=1; $url = 'plugin.php?'.url_implode($getlist);}-->
                <a href="{$url}" <!--{if $ordernum == 1}--> class="on wqwechat_bottom_bule"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a>
            </li>
            <li>
                <!--{eval $getlist[displayorder]=2; $url = 'plugin.php?'.url_implode($getlist);}-->
                <a href="{$url}" <!--{if $ordernum == 2}--> class="on wqwechat_bottom_bule"<!--{/if}-->>{$Plang['8f0491c8e569b3df']}</a>
            </li>
        </ul>
    </div>

    <div class="wqwechat_list pulldown_load_js" page="$page" count="$count" perpage="$perpage">
        <!--{if $list}-->
            <ul class="wqchatlist">
                <!--{subtemplate wq_wechatcollecting:common/list}-->
            </ul>
            <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
            <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;" >{$Plang['b3f7b411f8a25701']}</p>
        <!--{else}-->
            <p class="wqloaded_all">
                <span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['is_not_article']}
            </p>
        <!--{/if}-->
    </div>
    <!--{eval echo wq_get_wq_ad_info('wq_wechatshow_footer');}-->
    <div class="wqheight40"></div>
    <div class="wqwechat_num_view_btn">
         <!--{eval $referer = dreferer();}-->
        <!--{eval preg_match("/plugin.php/i", $referer, $matches)}-->
        <!--{if $matches}-->
           <!--{eval $backurl="javascript:history.go(-1);";}-->
        <!--{else}-->
            <!--{eval $backurl="plugin.php?id=wq_wechatcollecting";}-->
        <!--{/if}-->
        <a href="javascript:" class="wq_fanhui"><i class="wqwechat wqwechat-fanhui-copy wq_24"></i><span class="wq_line"></span></a>
        <!--{if $plugin_wechatreader}-->
            <!--{if in_array($wechat['id'],$subscription)}-->
                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$wechat[id]}&handlekey=attention" class="wqdialog wqattention_{$wechat[id]}" ><span>- </span>{$Plang['2c8a07313e7706bc']}<span class="wq_line"></span></a>
            <!--{else}-->
                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$wechat[id]}&handlekey=attention" class="wqattention_{$wechat[id]}"><span>+ </span>{$Plang['2c8a07313e7706bc']}<span class="wq_line"></span></a>
            <!--{/if}-->
         <!--{/if}-->
        <a href="javascript:;" onclick="wq_wechatcollecting_cancel('.wqfollow_code','.wqfollow_code_guan')">{$Plang['0b8a086e7cfb0be8']}<!--{if $plugin_wechatreader}--><span class="wq_line"></span><!--{/if}--></a>
        <!--{if $plugin_wechatreader}-->
            <a href="javascript:;" class="wqyellow" onclick="wq_wechatcollecting_cancel('.wqwechat_mask_zan','.wqon_the_top_zan')">{$Plang['37371b0d2d900d7c']}</a>
         <!--{/if}-->
    </div>
    <!--{if $plugin_wechatreader}-->
    <div class="wqwechat_mask wqwechat_mask_zan" style='display: none;' onclick="wq_wechatcollecting_cancel('.wqwechat_mask_zan','.wqon_the_top_zan')"></div>
    <div class="wqon_the_top wqon_the_top_zan" style='display: none;' >
        <div class="sheet_item wqwechat_bottom">
            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatsupport&wid={$wechat[id]}&handlekey=wq_polltype" class="wqtop wqdialog">
                <i class="wqwechat wqwechat-zan2"></i>{$Plang['4d3aee3cefdbf4b8']}(<i id='wechatsupport_num'>{$wechat['support']}</i>)
            </a>
        </div>
        <div class="sheet_item wqwechat_bottom">
            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatagainst&wid={$wechat[id]}&handlekey=wq_polltype" class="wqdialog">
                <i class="wqwechat wqwechat-cai"></i>{$Plang['44df76f6b567d500']}(<i id='wechatagainst_num'>{$wechat['against']}</i>)
            </a>
        </div>
        <div class="wq_wechat_cancel"></div>
        <div class="sheet_item wqwechat_bottom">
            <div onclick="wq_wechatcollecting_cancel('.wqwechat_mask_zan','.wqon_the_top_zan')"><a href="javascript:;" class="sheet-item-text">{$Plang['9c825be7149e5b97']}</a></div>
        </div>
    </div>
    <!--{/if}-->
    <div class="wqwechat_mask  wqfollow_code_guan" style='display: none;' onclick="wq_wechatcollecting_cancel('.wqfollow_code','.wqfollow_code_guan')"></div>
    <div class="wqfollow_code" style='display: none;'>
        <div class="wqfollow_code_div">
        <p><img src="{$wechat['qrcode']}"></p>
        <p>
            <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false}-->
            {$Plang['c2f77tgyjtrytry5']}
            <!--{/if}-->
            {$Plang['c2f77284c686cc65']}<span>{$wechat[name]}</span>"
        </p>
        </div>
    </div>
<script>
    var height = $('.wqwechat_num_view_menu').offset().top;
    $(document).on('scroll', function () {
        if ($(document).scrollTop() > height){
            $('.wqwechat_num_view_menu').addClass('wqwechat_warp_fixed');
            $('.wqwechat_list').css('margin-top', $('.wqwechat_num_view_menu').height() + 'px');
        } else {
            $('.wqwechat_num_view_menu').removeClass('wqwechat_warp_fixed');
            $('.wqwechat_list').css('margin-top', '0');
        }
    })
    $('.wq_fanhui').on('click', function () {
        document.referrer === '' ? location.href = 'plugin.php?id=wq_wechatshow' : history.go(-1);
    });

    if('{$isajax}' != 0){
        var tims = parseInt((parseInt($setting['collect_interval_date']) /60));
        var data = {
            searchsubmit: true,
            formhash: '{FORMHASH}',
            wechatid: '{$wechat[wechatid]}',
            classid: parseInt('{$wechat[classid]}'),
            article_classid: parseInt('{$wechat[article_classid]}'),
            collectpage: parseInt('{$setting[view_collectpage]}'),
            release_type: 1,
            inajax: 1
        }
        if ('{$ordernum}' == 4) {
            data.first = '1';
        }
        if ('{$isajax}' == 1) {
            cai_ji();
        }
        $('.wqsynchro').on('click', function () {
            if ($('.wqsynchro a span').hasClass('caiji_ing')) {
                return
            }
            var isClick = true;
            cai_ji(isClick);
        })
        function cai_ji(isClick) {
            $('.wqsynchro a').html('{$Plang[a811b58c4f73ea70]}').addClass('caiji_ing');
            $.ajax({
                url: 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=collect&handlekey=collect',
                data: data,
                type: 'POST',
                dataType: 'html'
            }).success(function (res) {
                var htmlstart, htmlend;
                if (res.indexOf('succeedhandle_collect(') != -1 || res.indexOf('errorhandle_collect(') != -1) {
                    var wq = wqXml(res);
                    var wq2 = wq_wechat_replace_js(wq);
                    popup.open(wq2);
                    evalscript(wq);
                    $('.wqsynchro a').html('<span><i class="wqwechat wqwechat-tongbu-copy"></i></span>{$Plang[tongbuef298846ea]}');
                    $('.wqsynchro a').removeClass('caiji_ing');
                    return;
                }

                htmlstart = res.indexOf('<li'), htmlend = res.lastIndexOf('</li>');
                htmlend = htmlend == -1 ? -1 : htmlend + 5;
                var numberend = res.lastIndexOf('|'), numberstart = res.lastIndexOf('|', numberend - 1);
                var html = res.slice(htmlstart, htmlend);
                if (data.first) {
                    var number = res.slice(numberend + 1);
                } else {
                    var number = res.slice(numberstart + 1, numberend);
                }
                $('.wqsynchro a').html('<span><i class="wqwechat wqwechat-tongbu-copy"></i></span>{$Plang[tongbuef298846ea]}');
                $('.wqsynchro a').removeClass('caiji_ing');
                if (number > 0 && ('{$ordernum}' == 1 || data.first || '{$ordernum}' == 2)) {
                    if ($('.wqchatlist').length) {
                        if('{$ordernum}' == 1){
                            $('.wqchatlist').prepend(html);
                        }else{
                            $('.wqchatlist').append(html);
                        }
                    } else {
                        $('.wqwechat_list').html('<ul>' + html + '</ul><p class="wqwechat_more" style="display: none;"><a href="javascript:;">'
                                +'<img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang[ccfb539ba66bbe7d]}</a></p>'
                                +'<p class="wqloading_all wqloaded_all wqpadding0" style="">{$Plang[b3f7b411f8a25701]}</p>');
                    }
                }
                if (number > 0) {
                    popup.open('<div class="wqwechat_dialog" style="line-height:40px">{$Plang[bbaf61e989f997e6]}' + number + '{$Plang[b14fd84c16549b0f]}</div>');
                    setTimeout(function (){
                        popup.close();
                    }, 1000)
                } else if (number == 0 && isClick) {
                    popup.open('<div class="wqwechat_dialog" style="line-height:40px">{$Plang[4dd04f1a1dda5ba5]}'+tims+'{$Plang[d02e4d6fccf56113]}</div>');
                    setTimeout(function (){
                        popup.close();
                    }, 1000);
                    $('.wqsynchro').remove();
                }
                delayload();
            });
        }
    }

    function errorhandle_attention(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['bef022f6310db3b9']}"){
            $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid='+param.wid+'&handlekey=attention');
            $(".wqattention_"+param.wid+" span:first-child").html("+");
            var fav_num = parseInt($("#favnum").html())-1;
            $("#favnum").html(fav_num);
        }
        if(wq_wechat_trim(msg)=="{$Plang['61d615dc397796b8']}"){
            $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid='+param.wid+'&handlekey=attention');
            $(".wqattention_"+param.wid+" span:first-child").html("-");
            var fav_num = parseInt($("#favnum").html())+1;
            $("#favnum").html(fav_num);
        }
    }

    function errorhandle_wq_polltype(msg,param){
        if(param.type==1){
            var support_num = parseInt($("#wechatsupport_num").html())+1;
            $("#wechatsupport_num").html(support_num);
        }else if(param.type==0){
            var against_num = parseInt($("#wechatagainst_num").html())+1;
            $("#wechatagainst_num").html(against_num);
        }
        setTimeout(function () {
            popup.close();
            wq_wechatcollecting_cancel('.wqwechat_mask_zan','.wqon_the_top_zan');
        }, 1500);
    }
    function succeedhandle_collect() {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function (){
            popup.close();
        }, 1500);
    }
    function errorhandle_collect() {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function (){
            popup.close();
        }, 1500);
    }
</script>
<!--{template wq_wechatcollecting:common/footer}-->