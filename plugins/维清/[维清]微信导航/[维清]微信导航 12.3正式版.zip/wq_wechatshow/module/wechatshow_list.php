<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
$webpagename = $Plang['wechatlist'];

$allorder[1] = $allorder[3] = 'collecttime';
$allorder[2] = 'views';
$ordernum = intval($_GET['displayorder']) < 1 || intval($_GET['displayorder']) > 3 ? $setting['wechatlist_displayorder'] : $_GET['displayorder'];

$perpage = intval($setting['list_perpage']) < 1 ? 1 : intval($setting['list_perpage']);
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
wq_check_page($start, $perpage, $setting['maxpage']);

$classid = $wechatclass[$_GET['classid']]['status'] == 1 ? intval($_GET['classid']) : '';
$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->count_by_where(array(1), $keyword, $classid);
$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_wehere(array(1), $start, $perpage, $keyword, $allorder[$ordernum], $classid);

$mpurl = 'plugin.php?id=wq_wechatshow&mod=list';

$right_list = wq_wechatshow_get_right_hot_new_article($setting, $classid);
$right_collect = $right_list['right_collect'];
$right_new = $right_list['right_new'];
$right_hot = $right_list['right_hot'];

if(empty($ad_setting)) {
	$recommed_links = "<a href=\"{$setting['top_help_url']}\" target=\"_blank\">";
	$recommed_links_mobile_top = $setting['top_help_url'];

	$top_recommend_num = $setting['top_recommend_num'];
	$left_recommend_num = $setting['index_wechat_num'];

	$recommed_date = "";
} else {
	if($classid) {
		$recommed_links = "<a href=\"plugin.php?id=wq_wechatad&mod=buy&handlekey=buy&classid={$classid}&pid=6\" onclick=\"showWindow('buy', this.href, 'get', 0);\">";
		$recommed_links_mobile_top = "plugin.php?id=wq_wechatad&mod=buy&handlekey=buy&classid={$classid}&pid=6";
	} else {
		$recommed_links = "<a href=\"plugin.php?id=wq_wechatad&mod=buy&handlekey=buy&pid=10\" onclick=\"showWindow('buy', this.href, 'get', 0);\">";
		$recommed_links_mobile_top = "plugin.php?id=wq_wechatad&mod=buy&handlekey=buy&pid=10";
	}

	$recommed_date = time();

	loadcache("wq_wechatad_positions_setting");
	$recommend_num = unserialize($_G['setting']['wq_wechatad_positions_setting']);
}

if($classid) {
	$top_recommend_num = $recommend_num[6] ? $recommend_num[6] : $setting['top_recommend_num'];
	$top_recommedlist = get_recommed_wechat_list(6, $classid, $top_recommend_num, "", $recommed_date);
} else {
	$top_recommend_num = $recommend_num[10] ? $recommend_num[10] : $setting['top_recommend_num'];
	$top_recommedlist = get_recommed_wechat_list(10, 0, $top_recommend_num, "", $recommed_date);
}

if($classid) {
	$left_recommend_num = $recommend_num[8] ? $recommend_num[8] : $setting['index_wechat_num'];
	$list_recommedlist = get_recommed_wechat_list(8, $classid, $left_recommend_num, "", $recommed_date);
} else {
	$left_recommend_num = $recommend_num[5] ? $recommend_num[5] : $setting['index_wechat_num'];
	$list_recommedlist = get_recommed_wechat_list(5, 0, $left_recommend_num, "", $recommed_date);
}

if($_G['mobile']) {
	$topheight = ceil($top_recommend_num / 4) * 124 + (ceil($top_recommend_num / 4) - 1) * 10;
	$topheight_css = "";
	if($topheight > 0) {
		$topheight_css = <<<EOT
<style type="text/css">.wqwechat_groom,.wqwechat_groom .tag_list,.wqwechat_groom .wq_xwyd{max-height: {$topheight}px}</style>
EOT;
	}
}

$adarr = null;
if(count($top_recommedlist) < $top_recommend_num) {
	for($i = count($top_recommedlist); $i < $top_recommend_num; $i ++) {
		$adarr[] = $i;
	}
}

if(!$list_recommedlist && $ordernum == 3) {
	$ordernum = 1;
}

if($classid) {
	$right_recommedlist = get_recommed_wechat_list(7, $classid, $setting['right_wechat_num']);
} else {
	$right_recommedlist = get_recommed_wechat_list(11, 0, $setting['right_wechat_num']);
}


if(intval($_GET['classid'])) {
	$mpurl .= '&classid=' . intval($_GET['classid']);
}
if(intval($_GET['displayorder'])) {
	$mpurl .= '&displayorder=' . intval($_GET['displayorder']);
}
if($ordernum == 3 && $list_recommedlist) {
	$list = $list_recommedlist;
	$multi = null;
} else {
	$multi = multi($count, $perpage, $page, $mpurl, $setting['maxpage']);
}

foreach($list as $key => $val) {
	$list[$key]['qrcode'] = wq_get_qrcode_by_wechatid($val['wechatid']);
	$list[$key]['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($val['headimage']);
	$list[$key]['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($val['wechatbgimg']);
}

$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $wechatclass[$classid]['classname'], 'page' => sprintf($Plang['5e56dc395b16cbf3'], $page));
list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechatshow_seo['list'], $page);

if($_GET['selectid']) {
	$onearr[$_GET['selectid']] = ($nav_classlist[$_GET['selectid']]);
	unset($nav_classlist[$_GET['selectid']]);
	$nav_classlist = $onearr + $nav_classlist;
}

if($_G['mobile']) {
	$webpagename = $wechatclass[$classid]['classname'] ? $wechatclass[$classid]['classname'] : $Plang['wechatshow'];
	include template('wq_wechatshow:wechatshow_list');
} else {
	include template('diy:wechatshow_list:' . $classid, 0, 'source/plugin/wq_wechatshow/template');
}
//From: Dism_taobao-com
?>