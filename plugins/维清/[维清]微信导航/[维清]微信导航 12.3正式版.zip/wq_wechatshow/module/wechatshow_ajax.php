<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
if($_GET['ac'] == 'renling') {
	$wid = $_GET['wid'];

	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($wid);

	if(empty($wechat) || $wechat['status'] != 1) {
		showmessage($Plang['tips_no_wechat']);
	}
	if($wechat['maintain_uid']) {
		showmessage($Plang['sorry_renling_isset']);
	}

	if(submitcheck('submitrenling')) {
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wq_wechatapi.php';
		if(stripos($_GET['material_url'], 'http://mp.weixin.qq.com/s?__biz') === false && stripos($_GET['material_url'], 'https://mp.weixin.qq.com/s?__biz') === false) {
			showmessage($Plang['sorry_material_url_error']);
		}
		$data = wqWechatApigetArticleContentByUrl($_GET['material_url'], true);

		if($data['title'] == $wechat['name'] . '-' . $wechat['wechatid'] && $wechat['wechatid'] == $data['wechatid']) {
			C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, array('maintain_uid' => $_G['uid']));
			$extrajs = '<script type="text/javascript" reload="1">'
				. 'renling_success();'
				. '</script>';
			showmessage($Plang['renling_success'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
		} else {
			showmessage($Plang['sorry_not_material']);
		}
	} else {
		include_once template('wq_wechatshow:wechatshow_renling');
	}
}
//From: Dism_taobao-com
?>