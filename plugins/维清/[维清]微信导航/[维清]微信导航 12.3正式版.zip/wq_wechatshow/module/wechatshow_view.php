<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$wechatid = $_GET['wid'];
$orderkey = in_array($_GET['displayorder'], array(1, 2, 3, 4)) ? intval($_GET['displayorder']) : $setting['view_articlelist_displayorder'];
$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
$ordertype = array(1 => 'date', 2 => 'views');
$displayorder = $orderkey < 1 || $orderkey > 2 ? $ordertype[1] : $ordertype[$orderkey];
$classname = $wechatclass[$wechat['classid']]['classname'] ? $wechatclass[$wechat['classid']]['classname'] : $Plang['8dfe4b30674494c1'];
$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $wechatclass[$wechat['classid']]['classname'], 'nickname' => $wechat['name']);
list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechatshow_seo['view']);
if(!empty($wechat) && $wechat['status'] == 1) {
	$intervaldate = intval(TIMESTAMP - $wechat['viewendcollectdate']);
	$isajax = 0;
	if($_G['uid'] && (in_array($_G['uid'], $setting['adminuids']) || $_G['uid'] == $wechat['maintain_uid'] || in_array($_G['groupid'], $setting['admingroups']) || in_array($_G['groupid'], $setting['allow_groups']))) {
		if($wechat['collectnewdate'] < strtotime(date('Y-m-d') . ' 00:00:00')) {
			if($setting['view_update_type'] == 1 && $intervaldate >= $setting['collect_interval_date']) {
				$isajax = 1;
			} else {
				$isajax = 2;
			}
		}
	}

	$perpage = intval($setting['article_perpage']) < 1 ? 1 : intval($setting['article_perpage']);
	$page = max(1, intval($_GET['page']));
	$start = ($page - 1) * $perpage;
	$mpurl = 'plugin.php?id=wq_wechatshow&mod=view&wid=' . $wechatid;

	if(in_array($orderkey, array(1, 2)) && !$ordernum) {
		$ordernum = $orderkey;
	}
	$recommend = '';
	$first = 0;
	if($orderkey == 3 && $wechat['recommend_num']) {
		$recommend = 1;
		$ordernum = 3;
	}
	if($orderkey == 4 && $wechat['first_num']) {
		$first = 1;
		$ordernum = 4;
	}


	$ordernum = $ordernum ? $ordernum : 1;
	$mpurl .= '&displayorder=' . $ordernum;
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wid($wechat['id'], array(1), $recommend, $first);
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_wid($wechat['id'], array(1), $start, $perpage, $displayorder, 'DESC', $recommend, $first);
	foreach($list as $key => $val) {
		$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
	}

	$addviews = 0;
	if($collect_setting['optimizeviews']) {
		$row = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat_addviews')->fetch($wechat['id']);
		if($row) {
			$addviews = $row['addviews'];
		}
	}

	wq_wechatcollecting_viewthread_updateviews($wechat['id'], 'wechat', $addviews, 'wq_wechatcollecting_wechat', 'wq_wechatcollecting_wechat_addviews', $collect_setting, $wechat);

	$classid = $wechat['classid'] ? $wechat['classid'] : '';

	$right_list = wq_wechatshow_get_right_hot_new_article($setting, $classid);
	$right_collect = $right_list['right_collect'];
	$right_new = $right_list['right_new'];
	$right_hot = $right_list['right_hot'];

	$right_recommedlist = get_recommed_wechat_list(9, $classid, $setting['right_wechat_num']);

	$multi = multi($count, $perpage, $page, $mpurl);
	$Plang['count_article'] = sprintf($Plang['count_article'], intval($count));
	$Plang['2dc3f83a42b3a77f'] = $Plang['no_article'];
	$wechat['qrcode'] = wq_get_qrcode_by_wechatid($wechat['wechatid']);
	$wechat['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($wechat['headimage']);
	$wechat['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($wechat['wechatbgimg']);
	if($_G['mobile']) {
		$webpagename = $wechat['name'];
		$multi = multi($count, $perpage, $page, $mpurl, 0, 10, FALSE, TRUE);

		include template('wq_wechatshow:wechatshow_view');
	} else {
		include template('diy:wechatshow_view:' . $wechatid, 0, 'source/plugin/wq_wechatshow/template');
	}
} else {
	showmessage($Plang['tips_no_wechat'], 'plugin.php?id=wq_wechatshow');
}
//From: Dism_taobao-com
?>