<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
$searchset = unserialize($_G['setting']['wechatsearch']);
if(!$searchset['status']) {
	showmessage('search_portal_closed');
}
$webpagename = $Plang['wechatlist'];
if($_G['mobile']) {
	$_GET['keyword'] = diconv($_GET['keyword'], "UTF-8", CHARSET);
}
$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);

$plugin = 'wq_wechatshow';
$searchid = isset($_GET['searchid']) ? intval($_GET['searchid']) : 0;
if(!empty($searchid)) {
	$navtitle = $keyword . $Plang['cewtwtgv34a9fd4e'];
	$perpage = intval($setting['list_perpage']) < 1 ? 1 : intval($setting['list_perpage']);
	$page = max(1, intval($_GET['page']));
	$start = ($page - 1) * $perpage;

	$index = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->fetch_by_searchid_srchmod($searchid, 2);
	if(!$index) {
		showmessage('search_id_invalid');
	}
	$keyword = $index['keywords'];
	$ids = array_slice(explode(',', $index['ids']), $start, $perpage, true);
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all($ids);

	$count = $index['num'];
	if(!$list) {
		$Plang['class_no_wechat'] = $Plang['search_no_wechat'];
	}
	$list = wq_two_array_orderby($list, 'collecttime', 'DESC');
	$mpurl = "plugin.php?id=wq_wechatshow&mod=search&keyword=$keyword&searchid=$searchid&page=$page";
	$multi = multi($count, $perpage, $page, $mpurl);
	foreach($list as $key => $val) {
		$list[$key]['qrcode'] = wq_get_qrcode_by_wechatid($val['wechatid']);
		$list[$key]['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($val['headimage']);
		$list[$key]['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($val['wechatbgimg']);
		$list[$key]['name'] = str_ireplace($keyword
			, '<em style="color:#F00;">' . $keyword
			. '</em>', $val['name']);
	}


	$right_list = wq_wechatshow_get_right_hot_new_article($setting, '', $keyword);
	$right_collect = $right_list['right_collect'];
	$right_new = $right_list['right_new'];
	$right_hot = $right_list['right_hot'];
	$right_recommedlist = get_recommed_wechat_list(1, 0, 2, $keyword);
	$Plang['19e0f4ed6e51dc49'] = sprintf($Plang['19e0f4ed6e51dc49'], $count, $keyword);
	if($_G['mobile']) {
		$webpagename = $keyword;
		$multi = multi($count, $perpage, $page, $mpurl, 0, 10, FALSE, TRUE);
		include template('wq_wechatshow:wechatshow_search');
	} else {
		include template('diy:wechatshow_search', 0, 'source/plugin/wq_wechatshow/template');
	}
} else {
	if($keyword) {
		$searchdata = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->fetch_all_search($searchset['searchctrl'], $_G['clientip'], $_G['uid'], $_G['timestamp'], $keyword, 2);

		$searchid = 0;
		foreach($searchdata as $index) {
			if($index['indexvalid'] && $index['dateline'] > 0) {
				$searchid = $index['searchid'];
				break;
			} elseif($_G['adminid'] != '1' && $index['flood']) {
				showmessage('search_ctrl', 'plugin.php?id=wq_wechatshow&mod=search', array('searchctrl' => $searchset['searchctrl']));
			}
		}
		if(!$searchid) {
			if($_G['adminid'] != '1' && $searchset['maxspm']) {
				if(C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->count_by_dateline($_G['timestamp'], 2) >= $searchset['maxspm']) {
					showmessage('search_toomany', 'plugin.php?id=wq_wechatcollecting&mod=search', array('maxspm' => $searchset['maxspm']));
				}
			}
			$dataid = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_search(array(1), 0, $searchset['maxsearchresults'], $keyword);
			$num = $ids = 0;
			foreach($dataid as $key => $val) {
				$num ++;
				$ids .= ',' . $val['id'];
			}
			$ids = ltrim($ids, '0,');
			$expiration = TIMESTAMP + $searchset['result_expiration'];
			$data = array(
				'srchmod' => 2,
				'keywords' => $keyword,
				'useip' => $_G['clientip'],
				'uid' => $_G['uid'],
				'expiration' => $expiration,
				'num' => $num,
				'ids' => $ids,
				'dateline' => $_G['timestamp'],
			);
			$searchid = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->insert($data, true);
		}
		dheader("location: plugin.php?id=wq_wechatshow&mod=search&searchid=$searchid&keyword=$keyword");
	} else {
		if(trim($_GET['act'] == 'alt')) {
			include_once template('wq_wechatcollecting:common_search');
		} else {
			if($_G['mobile']) {
				include template('wq_wechatshow:wechatshow_search');
			} else {
				include template('diy:wechatshow_search', 0, 'source/plugin/wq_wechatshow/template');
			}
		}
	}
}
//From: Dism_taobao-com
?>