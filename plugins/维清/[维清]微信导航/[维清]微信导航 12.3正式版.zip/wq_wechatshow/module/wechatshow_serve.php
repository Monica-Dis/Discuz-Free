<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_wechatshow'];
if($_GET['upload'] == '1') {
	$headimage_size = intval($setting['headimage_size']);
	$qrcode_size = intval($setting['qrcode_size']);
	if($_FILES['portrait']) {
		$result = upload_images('portrait', $headimage_size, $Plang['noimgsize'], $Plang['noimg']);
	} elseif($_FILES['qrcode']) {
		$result = upload_images('qrcode', $qrcode_size, $Plang['noimgsize'], $Plang['noimg']);
	}
	echo json_encode($result);
	exit;
} else {
	$url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve';
	if(!$_GET['portrait_img']) {
		$_G['mobile'] ? showmessage($Plang['c15084f3dfa9114e']) : showmessage($Plang['c15084f3dfa9114e'], $url);
	}
	if(!$_GET['qrcode_img']) {
		$_G['mobile'] ? showmessage($Plang['4b1a6c466ccd39d5']) : showmessage($Plang['4b1a6c466ccd39d5'], $url);
	}
	$setting_coll = $_G['cache']['plugin']['wq_wechatcollecting'];
	$adminuids = explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting_coll['adminuids']), ','));
	$setting_coll['admingroups'] = unserialize($setting_coll['admingroups']);
	include_once libfile('function/home');
	if(!in_array($_G['uid'], $adminuids) && !in_array($_G['groupid'], $setting_coll['admingroups'])) {
		$status = $setting_coll['wechat_status'] == '1' ? 0 : 1;
	} else {
		$status = 1;
	}
	if(!$_GET['name'] || !$_GET['wechatusers']) {
		$_G['mobile'] ? showmessage($Plang['234c3458a9f273d1']) : showmessage($Plang['234c3458a9f273d1'], $url);
	}
	$data = array(
		'collecttime' => TIMESTAMP,
		'uid' => intval($_G['uid']),
		'username' => $_G['username'],
		'headimage' => $_GET['portrait_img'],
		'qrcode' => $_GET['qrcode_img'],
		'status' => $status,
		'name' => dhtmlspecialchars($_GET['name']),
		'wechatid' => dhtmlspecialchars($_GET['wechatusers']),
		'intro' => dhtmlspecialchars($_GET['summary']),
		'verify' => dhtmlspecialchars($_GET['verify']),
		'type' => 1,
		'classid' => $_GET['classid'],
	);
	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($data['wechatid']);
	if(empty($wechat)) {
		$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->insert($data);
	} else {
		$_G['mobile'] ? showmessage($Plang['c5d3a9136320ba98']) : showmessage($Plang['c5d3a9136320ba98'], $url);
	}
	$_G['mobile'] ? showmessage($Plang['e021bb879c5187b7']) : showmessage($Plang['e021bb879c5187b7'], $url);
}
//From: Dism_taobao-com
?>