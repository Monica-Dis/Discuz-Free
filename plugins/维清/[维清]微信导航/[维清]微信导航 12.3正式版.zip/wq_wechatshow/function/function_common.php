<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_common.php 2015-7-7 08:28:20Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!function_exists('wq_loadfile')) {


	function wq_loadfile($identifier, $filename, $type = 'path', $extendid = "") {
		global $_G;

		switch($type) {
			case 'fun':
				$path = "function/function_{$filename}";
				break;
			case 'cpfun':
				$path = "function/admincp/function_{$filename}";
				break;
			case 'tool':
				$path = "function/tool/tool_{$filename}";
				break;
			case 'cls':
				$path = "class/class_{$filename}";
				break;
			case 'mod':
				list($mod, $ac) = explode("_", $filename);
				$path = "module/{$mod}/{$mod}_{$ac}";
				break;
			case 'conf':
				$path = "config/{$filename}";
				break;

			case 'path':
				$path = $filename;
				break;
		}

		if(!empty($extendid)) {
			$filename = DISCUZ_ROOT . "./source/plugin/{$identifier}/pluginextend/{$extendid}/{$path}.php";
			if(is_file($filename)) {
				return $filename;
			}
		}

		$filename = DISCUZ_ROOT . "./source/plugin/wq_wechatshow/{$path}.php";
		return is_file($filename) ? $filename : DISCUZ_ROOT . "./source/plugin/{$identifier}/{$path}.php";
	}

}

if(!function_exists('wq_parse_params')) {

	function wq_parse_params($field, $default = "", $fromget = true) {

		if($fromget) {
			$field = isset($_GET[$field]) ? $_GET[$field] : "";
		}

		if(is_array($field)) {
			foreach($field as $key => $val) {
				$data[$key] = wq_parse_params($val, "", false);
			}
		} elseif(is_numeric($field)) {
			$data = $field;
		} else {
			$field = trim($field);
			$data = !empty($field) ? dhtmlspecialchars($field) : $default;
		}

		return $data;
	}

}

if(!function_exists('wq_parse_url')) {

	function wq_parse_url($_route) {

		if(strpos($_route, ":") === false) {
			return $_route;
		}
		list($identifier, $route) = explode(":", $_route);

		list($mod, $ac, $op) = explode("/", $route);

		$url = sprintf("plugin.php?id=%s&mod=%s&ac=%s", $identifier, $mod, $ac);

		if($op) {
			$url = $url . "&op=" . $op;
		}

		return $url;
	}

}

if(!function_exists("wq_get_backurl")) {

	function wq_get_backurl($url = "", $flag = true) {
		global $_G;

		$backurl = !empty($url) ? $url : $_G['siteurl'];

		if($flag && $_SERVER["HTTP_REFERER"]) {
			$backurl = "javascript:history.back();";
		}
		return $backurl;
	}

}

if(!function_exists('wq_loadsetting')) {

	function wq_loadsetting($identifier) {
		global $_G;
		if(defined('IN_ADMINCP')) {
			loadcache("plugin");
		}
		$path = DISCUZ_ROOT . './source/plugin/' . $identifier . '/config/setting.php';
		if(!file_exists($path)) {
			return;
		}
		include $path;
		return $setting;
	}

}

if(!function_exists('wq_loadlang')) {

	function wq_loadlang($identifier, $isgetcache = true) {
		global $_G;

		$langfile = DISCUZ_ROOT . './source/plugin/' . $identifier . '/language/language.' . currentlang() . '.php';

		$path = is_file($langfile) ? $langfile : libfile('language', 'plugin/' . $identifier . '/language');

		include $path;

		if($isgetcache) {
			loadcache(array('lang_' . $identifier));
			if(!empty($_G['cache']['lang_' . $identifier]['lang'])) {
				$Plang = $_G['cache']['lang_' . $identifier]['lang'];
			}
		}
		return $Plang;
	}

}

if(!function_exists('wq_clear_htmtpl')) {

	function wq_clear_htmtpl($identifier) {
		$entrydir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/template/touch/';
		if(is_dir($entrydir)) {
			$d = @dir($entrydir);
			while($f = $d->read()) {
				if(preg_match('/(\w+)?\.htm$/', $f)) {
					@unlink($entrydir . '/' . $f);
				}
			}
		}

		$entrydir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/template/mobile/';
		if(is_dir($entrydir)) {
			$d = @dir($entrydir);
			while($f = $d->read()) {
				if(preg_match('/(\w+)?\.htm$/', $f)) {
					@unlink($entrydir . '/' . $f);
				}
			}
		}

		$entrydir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/template/';

		if(is_dir($entrydir)) {
			$d = @dir($entrydir);
			while($f = $d->read()) {
				if(preg_match('/(\w+)?\.htm$/', $f)) {
					@unlink($entrydir . '/' . $f);
				}
			}
		}
	}

}

if(!function_exists('currentlang')) {

	function currentlang() {
		$charset = strtoupper(CHARSET);
		if($charset == 'GBK') {
			return 'SC_GBK';
		} elseif($charset == 'BIG5') {
			return 'TC_BIG5';
		} elseif($charset == 'UTF-8') {
			global $_G;
			if($_G['config']['output']['language'] == 'zh_cn') {
				return 'SC_UTF8';
			} elseif($_G['config']['output']['language'] == 'zh_tw') {
				return 'TC_UTF8';
			}
		} else {
			return '';
		}
	}

}

if(!function_exists('wq_diconv')) {

	function wq_diconv($arr, $incharset = CHARSET, $outcharset = "UTF-8") {


		$incharset = strtoupper($incharset);
		$outcharset = strtoupper($outcharset);

		if($incharset == $outcharset) {
			return $arr;
		}

		if(!is_array($arr)) {
			if(!preg_match("/[\xA0-\xFF]+[\xA0-\xFFa-zA-Z0-9,\.\s]*[\xA0-\xFF]+/e", $arr)) {
				return $arr;
			}
			return diconv($arr, $incharset, $outcharset);
		}

		foreach($arr as $key => $val) {
			if(is_array($val)) {
				$arr[$key] = wq_diconv($val, $incharset, $outcharset);
			} else {
				if(!preg_match("/[\xA0-\xFF]+[\xA0-\xFFa-zA-Z0-9,\.\s]*[\xA0-\xFF]+/e", $val)) {
					$arr[$key] = $val;
				} else {
					$arr[$key] = diconv($val, $incharset, $outcharset);
				}
			}
		}
		return $arr;
	}

}

if(!function_exists('wq_dgmdate')) {

	function wq_dgmdate($timestamp, $format = 'Y-m-d H:i:s', $timeoffset = '9999', $uformat = '', $msg = '--') {
		if(empty($timestamp)) {
			return $msg;
		}
		return dgmdate($timestamp, $format, $timeoffset, $uformat);
	}

}

if(!function_exists('wq_showmessage')) {

	function wq_showmessage() {
		global $_G;
		list($message, $url_forward, $values, $extraparam, $custom) = func_get_args();
		$startflag = '';
		$endflag = '';
		$replace = '';
		if($_G['mobile'] && $_G['inajax']) {
			$startflag = '####';
			$endflag = '####';
			$replace = str_replace(':', '|', $url_forward);
		}
		$message = $startflag . $message . $endflag . $replace . $endflag;
		showmessage($message, $url_forward, $values, $extraparam, $custom);
	}

}

if(!function_exists('wq_cron_create')) {

	function wq_cron_create($identifier) {
		global $Plang;

		if(preg_match("/^[a-z]+[a-z0-9_]*$/i", $key)) {
			return false;
		}

		$dir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/cron';

		if(!file_exists($dir)) {
			return false;
		}
		$crondir = dir($dir);

		while($filename = $crondir->read()) {
			if(!in_array($filename, array('.', '..')) && preg_match("/^cron\_[\w\.]+$/", $filename)) {
				$content = file_get_contents($dir . '/' . $filename);
				preg_match("/cronname\:(.+?)\n/", $content, $r);
				$name = $Plang[trim($r[1])];
				preg_match("/week\:(.+?)\n/", $content, $r);
				$weekday = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/day\:(.+?)\n/", $content, $r);
				$day = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/hour\:(.+?)\n/", $content, $r);
				$hour = trim($r[1]) ? intval($r[1]) : -1;
				preg_match("/minute\:(.+?)\n/", $content, $r);
				$minute = trim($r[1]) ? trim($r[1]) : 0;
				$minutenew = explode(',', $minute);
				foreach($minutenew as $key => $val) {
					$minutenew[$key] = $val = intval($val);
					if($val < 0 || $var > 59) {
						unset($minutenew[$key]);
					}
				}
				$minutenew = array_slice(array_unique($minutenew), 0, 12);
				$minutenew = implode("\t", $minutenew);
				$filename = $identifier . ':' . $filename;
				$cronid = C::t('common_cron')->get_cronid_by_filename($filename);
				if(!$cronid) {
					C::t('common_cron')->insert(array(
						'available' => 1,
						'type' => 'plugin',
						'name' => $name,
						'filename' => $filename,
						'weekday' => $weekday,
						'day' => $day,
						'hour' => $hour,
						'minute' => $minutenew,
					));
				} else {
					C::t('common_cron')->update($cronid, array(
						'name' => $name,
						'weekday' => $weekday,
						'day' => $day,
						'hour' => $hour,
						'minute' => $minutenew,
					));
				}
			}
		}
	}

}

if(!function_exists('wq_get_seosetting')) {

	function wq_get_seosetting($data = array(), $defset = array(), $page = 0) {
		global $_G;

		$seotitle = $seodescription = $seokeywords = '';
		$titletext = $defset['seotitle'] ? $defset['seotitle'] : "";
		$descriptiontext = $defset['seodescription'] ? $defset['seodescription'] : "";
		$keywordstext = $defset['seokeywords'] ? $defset['seokeywords'] : "";
		preg_match_all("/\{([a-z0-9_-]+?)\}/", $titletext . $descriptiontext . $keywordstext, $pageparams);

		if($pageparams) {
			foreach($pageparams[1] as $var) {
				$searchs[] = '{' . $var . '}';
				if($var == 'page') {
					$data['page'] = $page > 1 ? strip_tags($data[$var]) : '';
				}
				$replaces[] = $data[$var] ? strip_tags($data[$var]) : '';
			}
			if($titletext) {
				$seotitle = wq_strreplace_strip_split($searchs, $replaces, $titletext);
			}
			if($descriptiontext) {
				$seodescription = wq_strreplace_strip_split($searchs, $replaces, $descriptiontext);
			}
			if($keywordstext) {
				$seokeywords = wq_strreplace_strip_split($searchs, $replaces, $keywordstext);
			}
		}
		return array($seotitle, $seodescription, $seokeywords);
	}

}

if(!function_exists('wq_strreplace_strip_split')) {

	function wq_strreplace_strip_split($searchs, $replaces, $str) {
		$searchspace = array('((\s*\-\s*)+)', '((\s*\,\s*)+)', '((\s*\|\s*)+)', '((\s*\t\s*)+)', '((\s*_\s*)+)');
		$replacespace = array('-', ',', '|', ' ', '_');
		return trim(preg_replace($searchspace, $replacespace, str_replace($searchs, $replaces, $str)), ' ,-|_');
	}

}

if(!function_exists('wq_dfsockopen')) {

	function wq_dfsockopen($url, $limit = 0, $post = '', $cookie = '', $bysocket = FALSE, $ip = '', $timeout = 15, $block = TRUE, $encodetype = 'URLENCODE', $allowcurl = TRUE, $position = 0, $files = array()) {
		require_once wq_loadfile('wq_wechatshow', 'filesock', 'fun');
		return _wq_dfsockopen($url, $limit, $post, $cookie, $bysocket, $ip, $timeout, $block, $encodetype, $allowcurl, $position, $files);
	}

}

if(!function_exists('wq_preg_match')) {

	function wq_preg_match($preg, $data, $returnall = false) {
		preg_match($preg, $data, $content);
		return $returnall ? $content : $content[1];
	}

}

if(!function_exists('wq_preg_match_all')) {

	function wq_preg_match_all($preg, $data, $returnall = false) {
		preg_match_all($preg, $data, $content);
		return $returnall ? $content : $content[1];
	}

}

if(!function_exists('wq_jsonencode')) {

	function wq_jsonencode($data) {

		$data = wq_diconv($data);
		$json = json_encode($data);

		if(version_compare(PHP_VERSION, '5.3.0', '>')) {
			$errcode = json_last_error();
			if($errcode > 0) {
				$msg = array(
					0 => 'JSON_ERROR_NONE',
					1 => 'JSON_ERROR_DEPTH',
					2 => 'JSON_ERROR_STATE_MISMATCH',
					3 => 'JSON_ERROR_CTRL_CHAR',
					4 => 'JSON_ERROR_SYNTAX',
					5 => 'JSON_ERROR_UTF8',
				);
				return $msg[$errcode];
			}
		} else {
			if($json === "") {
				return "JSON_ERROR_WIKIN";
			}
		}
		return $json;
	}

}

if(!function_exists('wq_jsondecode')) {

	function wq_jsondecode($json, $toarray = true) {
		return json_decode($json, $toarray);
	}

}

if(!function_exists('wq_rmdir')) {

	function wq_rmdir($dir) {
		if($dir === '.' || $dir === '..' || strpos($dir, '..') !== false) {
			return false;
		}
		if(substr($dir, -1) === "/") {
			$dir = substr($dir, 0, -1);
		}
		if(!file_exists($dir) || !is_dir($dir)) {
			return false;
		} elseif(!is_readable($dir)) {
			return false;
		} else {
			if(($dirobj = dir($dir))) {
				while(false !== ($file = $dirobj->read())) {
					if($file != "." && $file != "..") {
						$path = $dirobj->path . "/" . $file;
						if(is_dir($path)) {
							wq_rmdir($path);
						} else {
							@unlink($path);
						}
					}
				}
				$dirobj->close();
			}
			@rmdir($dir);
			return true;
		}
		return false;
	}

}

if(!function_exists('wq_explode')) {

	function wq_explode($str, $separator = ',', $replace_separator = '', $is_array_filter = true, $limit = '') {
		$arr = array();

		if(!empty($replace_separator)) {
			$str = str_replace($replace_separator, $separator, $str);
		}
		if($limit === '') {
			$arr = explode($separator, rtrim($str, $separator));
		} else {
			$arr = explode($separator, rtrim($str, $separator), $limit);
		}



		if($is_array_filter) {
			$arr = array_values(array_filter($arr));
		}

		return $arr;
	}

}

if(!function_exists('wq_get_extendid')) {

	function wq_get_extendid($map, $route, $type = "module") {

		list($mod, $ac, $op) = explode("_", $route);

		$map[$route] = wq_parse_params($map[$route], "", false);
		$map["{$mod}_{$ac}"] = wq_parse_params($map["{$mod}_{$ac}"], "", false);
		$map[$mod] = wq_parse_params($map[$mod], "", false);

		if($map[$route]) {
			return $map[$route];
		}

		if($type == 'module') {
			if($map["{$mod}_{$ac}"]) {
				return $map["{$mod}_{$ac}"];
			}

			if($map[$mod]) {
				return $map[$mod];
			}
		}

		return "";
	}

}

if(!function_exists('wq_get_extend_tpl')) {

	function wq_get_extend_tpl($identifier, $route, $extendid, $type = 'module') {
		global $_G;

		extract($_G['cache'][$identifier . "_extendinfos"]);

		if($type == 'home') {
			$mod = $type;
			list($ac, $op) = explode("_", $route);
			$index = $ac;
		} else {
			list($mod, $ac, $op) = explode("_", $route);
			$index = "{$mod}_{$ac}";
		}

		if($tplmap[$type][$route]) {
			$parenttpldir = "pluginextend/{$tplmap[$type][$route]}/";

			$tplpath = "{$identifier}:pluginextend/{$tplmap[$type][$route]}/module/{$mod}/{$ac}_{$op}";
		} elseif(!empty($extendid) && !in_array($op, $rewriteop[$type][$index])) {
			$parenttpldir = "pluginextend/{$extendid}/";
			$tplpath = "{$identifier}:pluginextend/{$extendid}/module/{$mod}/{$ac}_{$op}";
		} else {
			$parenttpldir = "";
			$tplpath = "{$identifier}:module/{$mod}/{$ac}_{$op}";
		}

		return array('tplpath' => $tplpath, 'parenttpldir' => $parenttpldir);
	}

}

if(!function_exists('wq_get_extend_maps')) {

	function wq_get_extend_maps($identifier = "wq_framework") {
		$filelist = $map = $tplmap = $addmod = $rewriteop = $menu = $allconfig = array();

		$filelist = wq_get_allextend_configs($identifier);

		foreach($filelist as $file) {

			include_once $file;

			$extendid = $pconfig['info']['extendid'];
			if(empty($pconfig) || empty($extendid)) {
				continue;
			}

			foreach($pconfig as $type => $config) {
				foreach($pconfig[$type] as $subtype => $subconfig) {
					if($type == "module") {
						if($subtype == "defaultmod") {
							$map[$type]['defaultmod'] = $subconfig;
						}

						foreach($subconfig as $key => $val) {
							if($subtype == "addmod") {
								$map[$type][$key] = $extendid;

								$addmod = array_merge($addmod, $subconfig);
							}
							if(in_array($subtype, array("addac", "addop", "rewriteop"))) {
								foreach($val as $k => $v) {
									$map[$type][$key . '_' . $v] = $extendid;
									if($subtype == "rewriteop") {
										$rewriteop[$type][$key][] = $v;
									}
								}
							}
							if($subtype == "rewritetpl") {
								$tplmap[$type][$val] = $extendid;
							}
						}
					}
					if($type == "admincp") {
						foreach($subconfig as $key => $val) {
							foreach($val as $k => $v) {
								$map[$type][$key . '_' . $v] = $extendid;
							}
						}
					}
					if($type == "home") {
						foreach($subconfig as $key => $val) {

							if($subtype == 'rewritetpl') {
								$tplmap[$type][$val] = $extendid;
							} else {
								foreach($val as $k => $v) {
									$map[$type][$key . '_' . $v] = $extendid;
									if($subtype == "rewritesubop") {
										$rewriteop[$type][$key][] = $v;
									}
								}
							}
						}
					}

					if(in_array($type, array("pchooks", "mhooks"))) {
						foreach($subconfig as $key => $val) {
							foreach($val as $k => $v) {
								$map[$type][$key][$v] = $extendid;
							}
						}
					}
					if(in_array($type, array("special"))) {
						foreach($subconfig as $key => $val) {
							$map[$type][$val] = $extendid;
						}
					}

					if(in_array($type, array("menu"))) {
						foreach($subconfig as $key => $val) {
							foreach($val as $k => $v) {
								$menu[$subtype][$key][$k] = array($k, $v);
							}
						}
					}
				}
			}
			$allconfig[$extendid] = $pconfig;
		}

		return array("map" => $map, "tplmap" => $tplmap, "addmod" => $addmod, "menu" => $menu, "rewriteop" => $rewriteop, "allconfig" => $allconfig);
	}

}

if(!function_exists('wq_get_allextend_configs')) {

	function wq_get_allextend_configs($identifier) {

		$path = DISCUZ_ROOT . "./source/plugin/{$identifier}/pluginextend/";

		foreach(scandir($path) as $file) {
			if($file == '.' || $file == '..') {
				continue;
			}

			$filename = $path . '/' . $file . "/config/config.php";

			if(is_dir($path . '/' . $file) && is_file($filename)) {
				$list[] = $filename;
			}
		}
		return $list;
	}

}

if(!function_exists('wq_hookscript')) {

	function wq_hookscript($identifier, $funName, $param = array()) {
		$path = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
		$pconfig = array();
		wq_get_pluginextend_loadconfig($path, $pconfig);
		foreach($pconfig['class'] as $dirname => $className) {
			@include_once DISCUZ_ROOT . "./source/plugin/{$identifier}/pluginextend/{$dirname}/class/{$className}.class.php";
			if(!class_exists($className, false)) {
				continue;
			}
			$wqpluginextendobj = new $className;
			if(!method_exists($wqpluginextendobj, $funName)) {
				continue;
			}
			$wqpluginextendobj->$funName($param);
		}
	}

}

if(!function_exists('wq_get_pluginextend_loadconfig')) {

	function wq_get_pluginextend_loadconfig($path, &$pconfig) {
		foreach(scandir($path) as $file) {
			if($file == '.' || $file == '..') {
				continue;
			}
			if(is_dir($path . '/' . $file)) {
				wq_get_pluginextend_loadconfig($path . '/' . $file, $pconfig);
			} elseif($file == 'config.php') {
				@include $path . '/' . $file;
			}
		}
		return $pconfig;
	}

}
//From: Dism_taobao-com
?>