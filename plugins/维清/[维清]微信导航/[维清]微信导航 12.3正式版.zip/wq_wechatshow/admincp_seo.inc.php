<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_seo.inc.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include DISCUZ_ROOT . './source/plugin/wq_wechatshow/config/config.php';
if(!submitcheck('seosubmit')) {
	echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';
	$wechatshow_seo = dunserialize($_G['setting']['wechatshow_seo']);
	$page = array(
		'list' => array('bbname', 'pluginname', 'classname', 'page'),
		'view' => array('bbname', 'pluginname', 'classname', 'nickname'),
	);
	showformheader('plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatshow&pmod=admincp_seo');
	showtableheader();
	foreach($page as $key => $value) {
		$code = $Plang['code'];
		foreach($value as $v) {
			$code .= '<a onclick="insertContent(this, \'{' . $v . '}\');return false;" href="javascript:;" title="' . $Plang[$v] . '">{' . $Plang[$v] . '}</a>';
		}
		showtitle($Plang['wechat_' . $key]);
		showsetting($Plang['seotitle'], 'wechatshow_seo[' . $key . '][seotitle]', $wechatshow_seo[$key]['seotitle'], 'text', '', 0, $code);
		showsetting($Plang['seokeywords'], 'wechatshow_seo[' . $key . '][seokeywords]', $wechatshow_seo[$key]['seokeywords'], 'text', '', 0, $code);
		showsetting($Plang['seodescription'], 'wechatshow_seo[' . $key . '][seodescription]', $wechatshow_seo[$key]['seodescription'], 'text', '', 0, $code);
	}
	showsubmit('seosubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$wechatshow_seo = serialize($_GET['wechatshow_seo']);
	C::t('common_setting')->update('wechatshow_seo', $wechatshow_seo);
	updatecache('setting');
	cpmsg($Plang['setsucceed'], 'action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatshow&pmod=admincp_seo', 'succeed');
}
//From: Dism_taobao-com
?>