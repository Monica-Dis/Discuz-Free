<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-4-22 11:41:38Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_wechatshow/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatshow/function/function_wechatshow.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';

$Plang = wq_loadlang('wq_wechatshow');

$setting = wq_loadsetting('wq_wechatshow');
$collect_setting = wq_loadsetting('wq_wechatcollecting');
$collect_setting['topnav'] = get_nav_urlinfo($collect_setting['topnav']);

$ad_setting = $_G['cache']['plugin']['wq_wechatad'];

$array = array(
	'wq_wechatcollecting_wechatclass',
	'wq_wechatcollecting_class',
	'wq_cache_subscription_' . $_G['uid'],
	'wq_cache_favorites_' . $_G['uid'],
	'wq_cache_pollsupport_' . $_G['uid'],
	'wq_cache_pollagainst_' . $_G['uid']
);
loadcache($array);

$setting['admingroups'] = unserialize($_G['cache']['plugin']['wq_wechatcollecting']['admingroups']);
$setting['adminuids'] = explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $_G['cache']['plugin']['wq_wechatcollecting']['adminuids']), ','));
$setting['allow_groups'] = unserialize($_G['cache']['plugin']['wq_wechatcollecting']['allow_groups']);
$setting['pluginname'] = trim($setting['pluginname']) ? trim($setting['pluginname']) : $Plang['wechatnavigation'];
$setting['view_mode'] = $_G['cache']['plugin']['wq_wechatcollecting']['view_mode'];
$setting['use_common_header'] = $_G['cache']['plugin']['wq_wechatcollecting']['usesystemheader'];

$subscription = $_G['cache']['wq_cache_subscription_' . $_G['uid']];
$favorites = $_G['cache']['wq_cache_favorites_' . $_G['uid']];
$pollsupport = $_G['cache']['wq_cache_pollsupport_' . $_G['uid']];
$pollagainst = $_G['cache']['wq_cache_pollagainst_' . $_G['uid']];

$wechatclass = $_G['cache']['wq_wechatcollecting_wechatclass'];
$wechatclass_article = $_G['cache']['wq_wechatcollecting_class'];
$wechatshow_seo = dunserialize($_G['setting']['wechatshow_seo']);
$wechatarticle = trim($_G['cache']['plugin']['wq_wechatcollecting']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatcollecting']['pluginname']) : $Plang['wechatarticle'];
$replacekeyword = str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['home_keyword']);
$setkeyword = explode(",", rtrim($replacekeyword, ','));
$setting['right_hot_article_num'] = $setting['right_hot_article_num'] < 1 ? 1 : $setting['right_hot_article_num'];
$setting['right_new_article_num'] = $setting['right_new_article_num'] < 1 ? 1 : $setting['right_new_article_num'];

$nav_classlist = $wechatclass;
$right_classtitle = $Plang['wechatclass'];

$sqlcache = unserialize($_G['setting']['wechatcollecting_cache_setting']);
$a_searchset = unserialize($_G['setting']['articlesearch']);
$w_searchset = unserialize($_G['setting']['wechatsearch']);

?>