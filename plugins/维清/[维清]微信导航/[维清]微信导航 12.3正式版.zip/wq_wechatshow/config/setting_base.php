<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2019-4-13 18:41:21Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$setting = $_G['cache']['plugin']['wq_wechatshow'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['headimage_size'] = intval($setting['headimage_size']);
$setting['qrcode_size'] = intval($setting['qrcode_size']);
$setting['home_keyword'] = trim($setting['home_keyword']);
$setting['home_navigation'] = intval($setting['home_navigation']);
$setting['top_recommend_num'] = intval($setting['top_recommend_num']);
$setting['top_help_url'] = trim($setting['top_help_url']);
$setting['wechatlist_displayorder'] = intval($setting['wechatlist_displayorder']);
$setting['view_articlelist_displayorder'] = intval($setting['view_articlelist_displayorder']);
$setting['view_update_type'] = intval($setting['view_update_type']);
$setting['view_collectpage'] = intval($setting['view_collectpage']);
$setting['collect_interval_date'] = intval($setting['collect_interval_date']);
$setting['index_wechat_num'] = intval($setting['index_wechat_num']);
$setting['maxpage'] = intval($setting['maxpage']);
$setting['list_perpage'] = intval($setting['list_perpage']);
$setting['article_perpage'] = intval($setting['article_perpage']);
$setting['right_wechat_num'] = intval($setting['right_wechat_num']);
$setting['right_new_article_num'] = intval($setting['right_new_article_num']);
$setting['right_hot_article_num'] = intval($setting['right_hot_article_num']);
$setting['right_hot_collect'] = intval($setting['right_hot_collect']);

?>