<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatshow/config/setting_base.php';

$setting['home_navigation'] = !$setting['home_navigation'] ? '2' : $setting['home_navigation'];
$setting['top_recommend_num'] = !$setting['top_recommend_num'] ? 4 : $setting['top_recommend_num'];
$setting['view_articlelist_displayorder'] = intval($setting['view_articlelist_displayorder']) < 1 || intval($setting['view_articlelist_displayorder']) > 4 ? 3 : intval($setting['view_articlelist_displayorder']);
$setting['view_collectpage'] = intval($setting['view_collectpage']) < 1 ? 5 : intval($setting['view_collectpage']);
$setting['collect_interval_date'] = intval($setting['collect_interval_date']) < 600 ? 600 : intval($setting['collect_interval_date']);
$setting['index_wechat_num'] = intval($setting['index_wechat_num']) < 1 ? 45 : intval($setting['index_wechat_num']);
$setting['maxpage'] = $setting['maxpage'] <= 0 ? 0 : $setting['maxpage'];
$setting['list_perpage'] = $setting['list_perpage'] < 1 ? 45 : $setting['list_perpage'];
$setting['article_perpage'] = $setting['article_perpage'] < 1 ? 10 : $setting['article_perpage'];
$setting['right_wechat_num'] = intval($setting['right_wechat_num']) < 1 ? 5 : intval($setting['right_wechat_num']);
$setting['right_new_article_num'] = $setting['right_new_article_num'] < 1 ? 5 : $setting['right_new_article_num'];
$setting['right_hot_article_num'] = $setting['right_hot_article_num'] < 1 ? 5 : $setting['right_hot_article_num'];
$setting['right_hot_collect'] = intval($setting['right_hot_collect']) < 1 ? 5 : intval($setting['right_hot_collect']);

?>