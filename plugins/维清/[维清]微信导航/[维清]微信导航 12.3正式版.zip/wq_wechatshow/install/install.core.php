<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}