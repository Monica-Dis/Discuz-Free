<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2015-4-22 11:41:38Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatshow/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'stat':
		$cache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $cache));
		break;
	case 'sql':
		if(is_file($filepath = DISCUZ_ROOT . './source/plugin/wq_addon_client/function/admincp/function_wikinaddons.php')) {
			require_once $filepath;
			wikinaddons_installlog('wq_wechatshow.plugin', 0, 'upgrade');
		}

		$sql = <<<EOF

EOF;
		runquery($sql);
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
	clear_old_tpl("wq_wechatshow");
	wq_clear("wq_wechatshow");
		$finish = TRUE;
		break;
}

function wq_clear($id) {

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id;

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/^discuz\_plugin\_' . $id . '(\_\w+)?\.xml$/', $f) || in_array($f, array("install.php", "upgrade.php"))) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}

function clear_old_tpl($id) {
	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/touch/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/mobile/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/';

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}
//From: Dism_taobao-com
?>