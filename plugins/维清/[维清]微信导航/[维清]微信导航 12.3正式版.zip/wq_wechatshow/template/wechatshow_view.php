<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<!--{eval //echo "<pre>"; print_r($nav_classlist);exit;}-->
<style id="diy_style" type="text/css"></style>
<div class="wqcrumbs_menu">
    <a href="{$_G['siteurl']}"><span class="wqwechat wqwechat-shouye2"></span></a>
    <i class="wqwechat wqwechat-jiantou-copy"></i>
    <a href="plugin.php?id=wq_wechatshow:wq_wechatshow">{$Plang['f26af91aa5eb531a']}</a>
    <i class="wqwechat wqwechat-jiantou-copy"></i>
     <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'list'; $getlist[classid] = $wechat['classid'];  $url = 'plugin.php?'.url_implode($getlist);}-->
    <a href="{$url}">{$classname}</a>
    <i class="wqwechat wqwechat-jiantou-copy"></i>{$Plang['6119ebedfebaad4b']}
</div>
<div class="wqpc_wechat_index wqm_top0">
    <!--[diy=showview]--><div id="showview" class="area"></div><!--[/diy]-->
    <!--diyarea_1200px-->
    <div class="wqpc_wechat_index_left">
        <!--[diy=showview2]--><div id="showview2" class="area"></div><!--[/diy]-->
        <!--diyarea_860px-->
        <div class="wqpc_wechat_public_number">
            <div class="wqpc_head">
                <!--{eval $logourl=$wechat['headimage'] ? $wechat['headimage'] : $wechat['qrcode'];}-->
                <img class="wqpc_img" src="{$logourl}"/>
                <!--{if $plugin_wechatreader}-->
                    <!--{if !$_G['uid']}-->
                        <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                    <!--{/if}-->
                    <!--{if in_array($wechat['id'],$subscription)}-->
                        <p>
                            <a<!--{if !$logininfo}--> id="attention_{$wechat[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$wechat[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>-</span>{$Plang['2c8a07313e7706bc']}</a>
                        </p>
                    <!--{else}-->
                        <p>
                            <a class="wqon"<!--{if !$logininfo}--> id="attention_{$wechat[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$wechat[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>+</span>{$Plang['2c8a07313e7706bc']}</a>
                        </p>
                    <!--{/if}-->
                <!--{/if}-->
            </div>
            <div class="wqpc_con">
                <h3>{$wechat[name]}<em class="y">{$Plang['hot']}<i>{$wechat[views]}</i></em><em class="y">{$Plang['attention']}<i id="attention_num">{$wechat[favorites]}</i></em></h3>
                <p><span>$Plang['wechat_user']</span>{$wechat[wechatid]}  <em class="y">{$Plang[collecttime]} <!--{eval echo date('Y-m-d h:m',$wechat[collecttime])}--></em> </p>
                <!--{if !empty({$wechat[intro]})}-->
                    <p><span>{$Plang[intro]}</span>{$wechat[intro]}</p>
                <!--{/if}-->
                <!--{if !empty({$wechat[verify]})}-->
                    <p><span>{$Plang[wechat_verify]} </span><img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png"/><em>{$wechat[verify]}</em></p>
                <!--{/if}-->
            </div>
            <div class="wqpc_code">
                <p> <img class="wqpc_ewm" src="{$wechat[qrcode]}"/></p>
                <p>{$Plang['f217e6d153b32095']}</p>
            </div>
        </div>
        <div class="wqon_the_top">
            <div class="wqon_the_top_warp">
            <ul>
                <!--{if !$_G['uid']}-->
                    <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                <!--{/if}-->
                <!--{if !$wechat['maintain_uid']}-->
                <li><a<!--{if !$logininfo}--> id="wechat_renling" href="plugin.php?id=wq_wechatshow&mod=ajax&ac=renling&wid={$wechat[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);" class="wqrenling"><i class="wqwechat wqwechat-renling"></i>{$Plang['3aa1955f6955d28d']}</a></li>
                <!--{/if}-->
                <li class="wpingbi"><a<!--{if !$logininfo}--> id="del" href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=del&wechatid={$wechat[wechatid]}"<!--{else}-->{$logininfo} onclick="showWindow(this.id, this.href, 'get', 0);"<!--{/if}--> class="wqrenling"><i class="wqwechat wqwechat-pingbi1"></i>{$Plang['5b1cbfcad581bfea']}</a></li>
                <!--{if $plugin_wechatreader}-->
                    <!--{if in_array($wechat['id'],$pollsupport) || in_array($wechat['id'],$pollagainst)}-->
                        <!--{if in_array($wechat['id'],$pollsupport)}-->
                            <!--{eval $wechatsupport_cls=' wqwechat-zan2'; $wechatagainst_cls=' wqwechat-diancai';}-->
                        <!--{else}-->
                            <!--{eval $wechatsupport_cls=' wqwechat-zan1'; $wechatagainst_cls=' wqwechat-cai';}-->
                        <!--{/if}-->
                    <!--{else}-->
                        <!--{eval $wechatsupport_cls=' wqwechat-zan1'; $wechatagainst_cls=' wqwechat-diancai';}-->
                    <!--{/if}-->
                    <li><a class="wqpc_ding"<!--{if !$logininfo}--> id="support_{$wechat[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatsupport&wid={$wechat[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wq_f16{$wechatsupport_cls}"></i>{$Plang['4d3aee3cefdbf4b8']}(<i class='wechatsupport_num'>{$wechat['support']}</i>)</a></li>
                    <li><a<!--{if !$logininfo}--> id="against_{$wechat[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatagainst&wid={$wechat[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);" class="wqother"><i class="wqwechat wq_f16{$wechatagainst_cls}"></i>{$Plang['44df76f6b567d500']}(<i class='wechatagainst_num'>{$wechat['against']}</i>)</a></li>
                <!--{/if}-->
                <li>
                    <a href="javascript:;" class="wqpc_fenxiang"><i class="wqwechat wqwechat-fenxiang2"></i>{$Plang['share']}</a>
                    <div class="article wqbdsharebuttonbox bdsharebuttonbox wqpc_gxh_topshare showShare" data-tag="share_1" style="display: none;">
                    <a class="bds_tsina" data-cmd="tsina"></a>
                    <a class="bds_qzone" data-cmd="qzone" href="#"></a>
                    <a class="bds_weixin" data-cmd="weixin"></a>
                    <a class="bds_sqq" data-cmd="sqq"></a>
                    <a class="bds_tieba" data-cmd="tieba"></a>
                    <a class="bds_more"  data-cmd="more"></a>
                </div>
                </li>

            </ul>

            </div>
        </div>
         <!--[diy=showview3]--><div id="showview3" class="area"></div><!--[/diy]-->
         <!--diyarea_860px-->
        <div class="wqpc_wechat_titlelist">
            <div class="wqpc_wechat_ass wqm_t0">
                <div class="wqpc_wechat_ul">
                    <div class="wqpc_wechat_ul_left wqpc_wechat_ul_auto">
                        <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $wechat[wechatid]; $getlist[displayorder] = 3;$url = 'plugin.php?'.url_implode($getlist);}-->
                        <!--{if $wechat['recommend_num']}-->
                            <a href="{$url}"<!--{if $ordernum == 3}--> class="a"<!--{/if}-->>{$Plang['db11cdebc2eb37bd']}</a>
                        <!--{/if}-->
                        <!--{if $wechat['first_num']}-->
                            <!--{eval $getlist[displayorder]=4; $url = 'plugin.php?'.url_implode($getlist);}-->
                            <a href="{$url}"<!--{if $ordernum == 4}--> class="a"<!--{/if}-->>{$Plang['0ef1d1c8298846ea']}</a>
                        <!--{/if}-->
                        <!--{eval $getlist[displayorder]=1; $url = 'plugin.php?'.url_implode($getlist);}-->
                        <a href="{$url}"<!--{if $ordernum == 1}--> class="a"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a>
                        <!--{eval $getlist[displayorder]=2; $url = 'plugin.php?'.url_implode($getlist);}-->
                        <a href="{$url}"<!--{if $ordernum == 2}--> class="a"<!--{/if}-->>{$Plang['8f0491c8e569b3df']}</a>
                    </div>
                    <!--{eval $collurl = " href='javascript:;' style='display:none'";}-->
                    <!--{if in_array($wechat['id'], $subscription) || $wechat['maintain_uid'] == $_G['uid']}-->
                        <!--{eval $collurl = " href=plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=collect&page=1&wechatid=".$wechat['wechatid'];}-->
                    <!--{/if}-->
                    <!--{if $isajax}-->
                        <a href="javascript:" class="y wqpc_caiji">{$Plang['c1056219639f3494']}</a>
                    <!--{/if}-->
                    <span class="y wq_f14 wq_grey">{$Plang['count_article']}</span>
                </div>
            </div>
        </div>
        <!--{template wq_wechatcollecting:common_list}-->
        <!--[diy=showview5]--><div id="showview5" class="area"></div><!--[/diy]-->
        <!--diyarea_860px-->
    </div>
        <div class="wqpc_wechat_index_right">
            <!--{if $setting['is_system_headbottom']==1}-->
                <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
                <!--diyarea_320px-->
                <!--{eval echo common_right_searchoradd();}-->
            <!--{/if}-->

            <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
             <!--diyarea_320px-->
            <!--{eval echo common_right_keyword_hot();}-->


            <!--{if $right_recommedlist}-->
                <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
                <!--{eval echo common_right_wechat_recommed();}-->
            <!--{/if}-->

            <!--{if $right_collect}-->
                <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
                <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
            <!--{/if}-->

            <!--{if $right_hot}-->
                <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
                <!--{eval echo common_right_article_minimg($right_hot,$Plang['cd28d8e22cbacebe']);}-->
            <!--{/if}-->

            <!--{if $right_new}-->
                <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
                <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
            <!--{/if}-->
        </div>
</div>
<script type="text/javascript">


        if('{$isajax}' != 0){
            var tims = parseInt((parseInt($setting['collect_interval_date']) /60));
            var data = {
                searchsubmit: true,
                formhash: '{FORMHASH}',
                wechatid: '{$wechat[wechatid]}',
                classid: parseInt('{$wechat[classid]}'),
                article_classid: parseInt('{$wechat[article_classid]}'),
                collectpage: parseInt('{$setting[view_collectpage]}'),
                release_type: 1,
                inajax: 1
            }

            if ('{$ordernum}' == 4) {
                data.first = '1';
            }

            if ('{$isajax}' == 1) {
                cai_ji();
            }

            wqjq(document).on('click', '.wqpc_caiji', function () {
                if(wqjq('.wqpc_caiji').hasClass('caiji_ing')) {
                    return;
                }
                var isClick = true;
                cai_ji(isClick);
            })

            function cai_ji(isClick) {
                wqjq('.wqpc_caiji').html('{$Plang[e896ba6ba187e209]}').addClass('caiji_ing');
                wqjq.ajax({
                    url: 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=collect&handlekey=collect',
                    data: data,
                    type: 'POST',
                    dataType: 'html'
                }).success(function (res) {
                    var htmlstart, htmlend;
                    if (res.indexOf('succeedhandle_collect(') != -1) {
                        htmlstart = res.indexOf('(', res.indexOf('succeedhandle_collect(')) + 1;
                        htmlend = res.indexOf(')', htmlstart);
                        showDialog(res.slice(htmlstart, htmlend).split(',')[1].replace(/\'/g, ''), null, null, null, null, null, null, null, null, 2, null);
                        setTimeout(function () {
                            wqjq('.wqpc_caiji').removeClass('caiji_ing');
                        }, 2000);
                        wqjq('.wqpc_caiji').html('{$Plang[c1056219639f3494]}');
                        return;
                    } else if (res.indexOf('errorhandle_collect(') != -1) {
                        htmlstart = res.indexOf('(', res.indexOf('errorhandle_collect(')) + 1;
                        htmlend = res.indexOf(')', htmlstart);
                        showDialog(res.slice(htmlstart, htmlend).split(',')[0].replace(/\'/g, ''), null, null, null, null, null, null, null, null, 2, null);
                        setTimeout(function () {
                            wqjq('.wqpc_caiji').removeClass('caiji_ing');
                        }, 2000);
                        wqjq('.wqpc_caiji').html('{$Plang[c1056219639f3494]}');
                        return;
                    }
                    htmlstart = res.indexOf('<li>'), htmlend = res.lastIndexOf('</li>');
                    htmlend = htmlend == -1 ? -1 : htmlend + 5;
                    var numberend = res.lastIndexOf('|'), numberstart = res.lastIndexOf('|', numberend - 1);
                    var html = res.slice(htmlstart, htmlend);
                    if (data.first) {
                        var number = res.slice(numberend + 1);
                    } else {
                        var number = res.slice(numberstart + 1, numberend);
                    }
                    wqjq('.wqpc_caiji').html('{$Plang[c1056219639f3494]}');
                    if (!isClick) {
                        wqjq('.wqpc_caiji').removeClass('caiji_ing');
                    } else {
                        setTimeout(function () {
                            wqjq('.wqpc_caiji').removeClass('caiji_ing');
                        }, 2000);
                    }
                    if (number > 0 && ('{$ordernum}' == 1 || data.first || '{$ordernum}' == 2)) {
                        if (wqjq('.wqpc_wechat_list ul').length) {
                            if('{$ordernum}' == 1){
                                wqjq('.wqpc_wechat_list ul').prepend(html);
                            }else{
                                wqjq('.wqpc_wechat_list ul').append(html);
                            }
                        } else {
                            wqjq('.wqpc_wechat_list').html('<ul>' + html + '</ul>');
                        }
                        wqjq('.wqpc_wechat_ul span span').html(Number(wqjq('.wqpc_wechat_ul span span').html()) + Number(number));
                    }
                    if (number > 0) {
                        showDialog('{$Plang[bbaf61e989f997e6]}' + number + '{$Plang[b14fd84c16549b0f]}', null, null, null, null, null, null, null, null, 2, null);

                    } else if (number == 0 && isClick) {
                        showDialog('{$Plang[4dd04f1a1dda5ba5]}'+tims+'{$Plang[d02e4d6fccf56113]}', null, null, null, null, null, null, null, null, 2, null);
                        wqjq('.wqpc_caiji').remove();
                    }
                    delayload();
                }).error(function (res) {
                    showDialog('{$Plang[f52095ded8cb1deb]}', null, null, null, null, null, null, null, null, 2, null);
                    wqjq('.wqpc_caiji').html('{$Plang[c1056219639f3494]}');
                });
            }


        }
        var attention_num = parseInt(wqjq("#attention_num").html())

        var protocol = location.protocol
        wqjq(document).on('click','#del',function(){
            if (confirm('$Plang[Is_recycle_bin]')) {
                return true;
            } else {
                return false;
            }
        })
        wqjq('.wqpc_fenxiang').parents('li').on('mouseenter', function () {
            wqjq(this).find('.wqpc_fenxiang').addClass('wqshare');
        })
        wqjq('.wqpc_fenxiang').parents('li').on('mouseleave', function () {
             if (wqjq('.showShare').is(':hidden')) {
                 wqjq(this).find('.wqpc_fenxiang').removeClass('wqshare');
             }
        })
        wqjq('.wqpc_fenxiang').on('click', function () {
            if (wqjq('.showShare').is(':hidden')) {
                wqjq('.showShare').show();
                sharebd.id = '';
                sharebd.bdPic = "{$_G['siteurl']}{$logourl}";
                sharebd.bdText = '';
                sharebd.bdDesc = '';
                sharebd.url = location.href;
                if (sharebd.url.match(/^(http)/)) {
                    sharebd.bdUrl = sharebd.url;
                } else {
                    sharebd.bdUrl = "{$_G['siteurl']}" + sharebd.url;
                }
                window._bd_share_config = {
                    common: {
                        bdText: sharebd.bdText,
                        bdDesc: sharebd.bdDesc,
                        bdUrl: sharebd.bdUrl,
                        bdPic: sharebd.bdPic,
                        onBeforeClick: function (cmd, config) {
                            return{
                                bdText: sharebd.bdText,
                                bdDesc: sharebd.bdDesc,
                                bdUrl: sharebd.bdUrl,
                                bdPic: sharebd.bdPic
                            }
                        }
                    },
                    share: [{
                        "bdSize": 16
                    }]
                }
                if (protocol == 'https:') {
                    wqjq('#sharebd').prop('src', './source/plugin/wq_wechatcollecting/static/js/bdshare.js?{VERHASH}');
                } else {
                    wqjq('#sharebd').prop('src', 'http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5));
                }
            } else {
                wqjq('.showShare').hide();
            }
        })

    function canclewechatattention(wid) {
        wqjq("#attention_"+wid).addClass('wqon').attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid=' + wid);
        wqjq("#attention_"+wid+" span:first-child").html("+ ");
        attention_num = attention_num-1;
        wqjq("#attention_num").html(attention_num);
    }

    function wechatsupport(wid){
        wqjq("#support_"+wid+" i:first-child").attr('class','wqwechat wq_f16 wqwechat-zan2');
        var support_num = parseInt(wqjq(".wechatsupport_num").html())+1;
        wqjq(".wechatsupport_num").html(support_num);
    }

    function wechatagainst(wid){
        wqjq("#against_"+wid+" i:first-child").attr('class','wqwechat wq_f16 wqwechat-cai');
        var against_num = parseInt(wqjq(".wechatagainst_num").html())+1;
        wqjq(".wechatagainst_num").html(against_num);
    }
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->