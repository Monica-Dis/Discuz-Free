<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<style id="diy_style" type="text/css"></style>
<div class="wqpc_wechat_index">
            <!--[diy=showlist]--><div id="showlist" class="area"></div><!--[/diy]-->
            <!--diyarea_1200px-->
            <div class="wqpc_wechat_index_left">
                <!--[diy=showlist1]--><div id="showlist1" class="area"></div><!--[/diy]-->
                <!--diyarea_860px-->
                <div class="wqpc_wechat_follow_recommend">
                    <ul>
                        <!--{loop $top_recommedlist $key $val}-->
                        <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid];$getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <li style="<!--{if $key != 0 && ($key+1) % 4 == 0}-->margin-right: 0px;<!--{/if}--><!--{if $key>3}-->margin-top: 12px;<!--{/if}-->">
                            <div class="wqpc_wechat_num">
                                <a href="{$url}" target="_blank">
                                    <img class="wqpc_img" src="{$logourl}"/>
                                <!--{if $val[verify]}-->
                                    <span class="wqwechat_rz">
                                        <img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png"/>
                                    </span>
                                <!--{/if}-->
                                </a>
                            </div>
                            <div class="wqpc_wechat_name"><a href="{$url}" target="_blank">{$val['name']}</a></div>
                            <div class="wqpc_wechat_con">{$val['intro']}</div>
                            <!--{if $plugin_wechatreader}-->
                                <!--{if !$_G['uid']}-->
                                    <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                                <!--{/if}-->
                                <!--{if in_array($val['id'],$subscription)}-->
                                    <p class="wqwechat_follow_btn">
                                        <div class="wqpc_wechat_follow_btn">
                                            <a<!--{if !$logininfo}--> id="top_attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>-</span>{$Plang['2c8a07313e7706bc']}</a>
                                        </div>
                                    </p>
                                <!--{else}-->
                                    <p class="wqwechat_follow_btn">
                                        <div class="wqpc_wechat_follow_btn">
                                            <a<!--{if !$logininfo}--> id="top_attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>+</span>{$Plang['2c8a07313e7706bc']}</a>
                                        </div>
                                    </p>
                                <!--{/if}-->
                            <!--{/if}-->
                        </li>
                        <!--{/loop}-->
                        <!--{if $adarr}-->
						<!--{eval $count = count($top_recommedlist);}-->
                            <!--{loop $adarr $key $val}-->
                                <li style="<!--{if ($key+$count+1) % 4 == 0}-->margin-right: 0px;<!--{/if}--><!--{if $count>4}-->margin-top: 12px;<!--{/if}-->">
                                    {$recommed_links}
                                     <img src="./source/plugin/wq_wechatcollecting/static/images/wq_ad_zhaozu.png"/>
                                     <br/><span class="wq_settled">&#x6211;&#x8981;&#x63A8;&#x8350;</span>
                                    </a>
                                </li>
                            <!--{/loop}-->
                        <!--{/if}-->
                    </ul>
                </div>
                <!--[diy=showlist2]--><div id="showlist2" class="area"></div><!--[/diy]-->
                <!--diyarea_860px-->
                <!--{if $setting[home_navigation]=='2'}-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{else}-->
                    <div class="wqpc_wechat_titlelist">
                        <div class="wqpc_wechat_ass">
                            <div class="wqpc_wechat_ul">
                                <div class="wqpc_wechat_ul_left">
                                    <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'list'; $getlist[classid] = $classid; $getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <!--{if $list_recommedlist}-->
                                    <!--{eval $getlist[classid] = $classid ? $classid : ''; $getlist[displayorder]=3; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <a href="{$url}"<!--{if $ordernum == 3}--> class="a"<!--{/if}-->>{$Plang['db11cdebc2eb37bd']}</a>
                                    <!--{/if}-->
                                     <!--{eval $getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <a href="{$url}"<!--{if $ordernum == 1}--> class="a"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a>
                                    <!--{eval $getlist[displayorder] = 2; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <a href="{$url}"<!--{if $ordernum == 2}--> class="a"<!--{/if}-->>{$Plang['6959da5d2e80c069']}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <!--{/if}-->
                <!--{template wq_wechatshow:common_list}-->
                <!--[diy=showlist4]--><div id="showlist4" class="area"></div><!--[/diy]-->
                <!--diyarea_860px-->
            </div>
                <div class="wqpc_wechat_index_right">

                <!--{if $setting['is_system_headbottom']==1}-->
                    <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_searchoradd();}-->
                <!--{/if}-->

                <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
                  <!--diyarea_320px-->
                <!--{eval echo common_right_keyword_hot();}-->

                <!--{if $setting[home_navigation]=='3' && $_GET['mod']!='view'}-->
                  <!--diyarea_320px-->
                    <!--[diy=right2]--><div id="right2" class="area"></div><!--[/diy]-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{/if}-->

                <!--{if $right_recommedlist}-->
                    <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                    <!--{eval echo common_right_wechat_recommed();}-->
                <!--{/if}-->

                <!--{if $right_collect}-->
                    <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
                <!--{/if}-->

                <!--{if $right_hot}-->
                    <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_hot,$Plang['cd28d8e22cbacebe']);}-->
                <!--{/if}-->

                <!--{if $right_new}-->
                    <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                    <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                <!--{/if}-->
            </div>

        </div>
<!--{template wq_wechatcollecting:common/tpl_footer}-->