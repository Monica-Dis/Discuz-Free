<?php exit("From: DisM.taobao.com"); ?>
<div class="wqpc_wechat_follow">
    <!--{if !$list}-->
        <div class="wqpc_emp">$Plang['class_no_wechat']</div>
    <!--{else}-->
        <ul>
            <!--{loop $list $key $val}-->
            <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
            <li>
                <div class="wqpc_wechat_follow_img">
                    <a href="{$url}" target="_blank">
                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <div class="wqpc_img wqlazydiv"><img wqdata-src="{$logourl}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                        <!--{if $val[verify]}-->
                        <span class="wqwechat_rz"><img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png"/></span>
                        <!--{/if}-->
                    </a>
                    <!--{if $plugin_wechatreader}-->
                        <!--{if !$_G['uid']}-->
                            <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                        <!--{/if}-->
                        <!--{if in_array($val['id'],$subscription)}-->
                            <p class="wqwechat_follow_btn">
                                <a<!--{if !$logininfo}--> id="attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>- </span>{$Plang['2c8a07313e7706bc']}</a>
                            </p>
                        <!--{else}-->
                            <p class="wqwechat_follow_btn">
                                <a class="wqon"<!--{if !$logininfo}--> id="attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>+ </span>{$Plang['2c8a07313e7706bc']}</a>
                            </p>
                        <!--{/if}-->
                    <!--{/if}-->

                </div>
                <div class="wqpc_wechat_follow_con">
                    <h3><a href="{$url}" target="_blank">{$val[name]}</a></h3>
                    <p class="wqwechat_weixinhao">{$Plang['wechat_user']}{$Plang['mh']}<i>{$val[wechatid]}</i></p>
                    <div class="wqpc_wechat_con">{$val[intro]}</div>
                </div>
            </li>
            <!--{/loop}-->

			<!--{if !in_array($_GET['displayorder'],array(1,2)) && !empty($ad_setting)}-->
			<!--{eval $pid = empty($classid) ? 5 : 8;}-->
			<li class="buyposition">
				<a href="plugin.php?id=wq_wechatad&mod=buy&handlekey=buy&classid={$classid}&pid={$pid}" onclick="showWindow('buy', this.href, 'get', 0);">
					<img src="./source/plugin/wq_wechatcollecting/static/images/wq_ad_zhaozu_min.png"/>
					<span class="wq_settled">&#x6211;&#x8981;&#x63A8;&#x8350;</span>
				</a>
			</li>
			<!--{/if}-->
        </ul>
        <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
    <!--{/if}-->
</div>
<script type="text/javascript">
    function canclewechatattention(wid) {

        wqjq("#attention_"+wid).addClass('wqon').attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid=' + wid);
        wqjq("#attention_"+wid+" span:first-child").html("+ ");

        wqjq("#top_attention_"+wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid=' + wid);
        wqjq("#top_attention_"+wid+" span:first-child").html("+ ");

    }
</script>