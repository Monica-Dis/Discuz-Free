<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<style id="diy_style" type="text/css"></style>
<div class="wqpc_wechat_index">
            <!--[diy=search1]--><div id="search1" class="area"></div><!--[/diy]-->
             <!--diyarea_1200px-->
            <div class="wqpc_wechat_index_left">
               <!--[diy=search2]--><div id="search2" class="area"></div><!--[/diy]-->
               <!--diyarea_860px-->
                <div class="wqpc_wechat_search_input">
                     <form method="get" action="plugin.php" id="searchform">
                        <input type="hidden" name="formhash" value="{FORMHASH}">
                        <input type="hidden" name="id" value="wq_wechatcollecting" id="pluginid">
                        <input type="hidden" name="mod" value="search">
                        <input type="hidden" name="searchform" value="true">
                        <input type="text" class="wqpc_input" placeholder="{$Plang['509ae8eac3b2e5cd']}" value="{$keyword}" name="keyword" maxlength="400"/>
                        <a class="wqpc_close" href="javascript:;">
                            <i class="wqwechat wqwechat-x wq_f20"></i>
                        </a>
                        <!--{if $a_searchset['status']}-->
                            <button type="button" onclick="check_search_keyword('wq_wechatcollecting')" class="wqpc_btn_ba">{$Plang['4cb9e8721e550eb0']}</button>
                        <!--{/if}-->
                        <button type="button" onclick="check_search_keyword('wq_wechatshow')" class="wqpc_btn_la" id="wechatwearch">{$Plang['c9bc3705598eff5c']}</button>
                    </form>
                </div>
                <!--[diy=search3]--><div id="search3" class="area"></div><!--[/diy]-->
                <!--diyarea_860px-->
                <!--{if $keyword}-->
                    <div class="wqpc_wechat_search_result">
                        <span class="wqtext">{$Plang['19e0f4ed6e51dc49']}</span>
                    </div>
                    <!--{template wq_wechatshow:common_list}-->
                <!--{/if}-->
                <!--[diy=search4]--><div id="search4" class="area"></div><!--[/diy]-->
                <!--diyarea_860px-->
            </div>
            <div class="wqpc_wechat_index_right">

                <!--{if $setting['is_system_headbottom']==1}-->
                    <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_searchoradd();}-->
                <!--{/if}-->

                <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
                <!--diyarea_320px-->
                <!--{eval echo common_right_keyword_hot();}-->

                <!--{if $setting[home_navigation]=='3' && $_GET['mod']!='view'}-->
                    <!--[diy=right2]--><div id="right2" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{/if}-->

                <!--{if $right_recommedlist}-->
                    <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_wechat_recommed();}-->
                <!--{/if}-->

                <!--{if $right_collect}-->
                    <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
                <!--{/if}-->

                <!--{if $right_hot}-->
                    <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_hot,$Plang['cd28d8e22cbacebe']);}-->
                <!--{/if}-->

                <!--{if $right_new}-->
                    <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                    <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
                <!--{/if}-->
            </div>
        </div>
<script type="text/javascript">

    function check_search_keyword(identifier){
        var keyword = wqjq(".wqpc_input").val();;
        if(!keyword){
            showDialog('&#35831;&#36755;&#20837;&#20851;&#38190;&#23383;', null, null, null, null, null, null, null, null, 2, null)
            return;
        }
        if(identifier){
            wqjq("#pluginid").val(identifier);
        }
        wqjq("#searchform").submit();
    }
    wqjq('.wqpc_wechat_search_input').on('click','.wqpc_close',function(){
        wqjq('.wqpc_input').val('');
    });
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->