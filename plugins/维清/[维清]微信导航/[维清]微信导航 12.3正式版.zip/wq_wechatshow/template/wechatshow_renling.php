<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<div class="wqpc_ejectbg_warp">
     <h3 class="wqpc_title">{$Plang['c993f6676269bfb3']}<span class="y" onclick="hideWindow('$_GET['handlekey']')"><i class="close_favorites wqwechat wqwechat-close wq_f18"></i></span></h3>
     <div class="wq_claim_input">
         <form id="check_material" action="plugin.php?id=wq_wechatshow&mod=ajax&ac=renling" method="post" onsubmit="ajaxpost('check_material', 'return_material', 'return_material', 'onerror');return false;">
             <input type="hidden" name="formhash" value="{FORMHASH}" />
             <input type="hidden" name="handlekey" value="checkmaterial" />
             <input type='hidden' name='wid' value="{$wid}">
             <input type='hidden' name='submitrenling' value="true">
             <p>{$Plang['b42eab16e759a91d']}<input readonly="readonly" style="width:62%" onclick="setCopy(this.value);" id='material' value="{$wechat[name]}-{$wechat[wechatid]}">
                 <span onclick="setCopy(wqjq('#material').val());">{$Plang['1645a515ab4eac7a']}</span>
             </p>
             <p>{$Plang['df0d8aa4dfb4d325']}<input type='text' name='material_url' placeholder="{$Plang['ab450ab99bdcb29a']}"></p>
         </form>
     </div>
     <div class="wq_claim_explain">
         <span>{$Plang['e3db8157c144061b']}</span>
         <p>
            {$Plang['fbcrenligongzac6']}
         </p>
     </div>
     <div class="wqpc_ejectbg_btn">
         <button id="sub_check">{$Plang['387e9a577ee04ca3']}</button>
         <a href="javascript:;" onclick="hideWindow('$_GET['handlekey']')">{$Plang['9c825be7149e5b97']}</a>
     </div>

 </div>
<script type="text/javascript" reload="1">
    wqjq('#sub_check').on('click',function(){
        wqjq('#check_material').submit();
    });

    function renling_success(){
        window.setTimeout(function() {
            window.location.href = location.href;
	}, '2000');

    }
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->