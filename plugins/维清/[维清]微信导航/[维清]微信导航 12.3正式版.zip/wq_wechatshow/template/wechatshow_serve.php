<?php exit("From: DisM.taobao.com"); ?>
<form name="post" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add&wechat=serve" method="post" enctype="multipart/form-data">
    <input type="hidden" value="true" name="servesubmit"/>
    <input type="hidden" value="{FORMHASH}" name="formhash"/>
    <input type="hidden" value="{FORMHASH}" name="formhash"/>
    <input type="hidden" name="portrait_img" id="portrait_img"/>
    <input type="hidden" name="qrcode_img" id="qrcode_img"/>
    <table cellspacing="0" cellpadding="0" class="wq_tfm">
        <tbody>
            <tr>
                <td class="wqpc_con_title">{$Plang['4b3b548154549518']}</td>
                <td class="wqpc_con_collect"><input type="text" name="wechatusers"/></td>
            </tr>
            <tr>
                <td class="wqpc_con_title">{$Plang['3982634cd20768c9']}</td>
                <td class="wqpc_con_collect"><input type="text" name="name"/></td>
            </tr>
            <tr>
                <td class="wqpc_con_title">{$Plang['7963064a1954b8aa']}</td>
                <td class="wqpc_con_collect"><input type="text" name="verify" /></td>
            </tr>
            <tr>
                <td class="wqpc_con_title">{$Plang['093288bbe08517a5']}</td>
                <td class="wqpc_con_collect"><textarea type="text" name="summary" style= "height: 60px;"></textarea></td>
            </tr>
            <tr>
                <td class="wqpc_con_title">{$Plang['639bca6a6958faac']}</td>
                <td class="wqpc_con_collect img_uplod">
                    <input type="file" name="portrait" class="wqpc_head" id="portrait"/>
                    <span class="wqpc_head_pic"><i class="wqwechat wqwechat-increase"></i></span>
                    <em class="wq_code_name">{$Plang['ddd826aa11868c7d']}</em>
                    <input type="file" name="qrcode" class="wqpc_head wqpc_qrcode" id="qrcode"/>
                    <span class="wqpc_head_pic"><i class="wqwechat wqwechat-increase"></i></span>

               </td>
             </tr>
            <tr>
                <td class="wqpc_con_title">{$Plang['57dca09a1285209b']}</td>
                <td class="wqpc_con_collect">{$classselect}</td>
            </tr>
            <tr>
               <td></td>
               <td class="wqpc_btn">
                <button type="submit" class="">{lang submit}</button>
               </td>
            </tr>
        </tbody>
    </table>
</form>
<script src="./source/plugin/wq_wechatshow/static/js/wq_ajaxfileupload1.js?{VERHASH}" type="text/javascript"></script>
<script src="./source/plugin/wq_wechatshow/static/js/wq_buildfileupload1.js?{VERHASH}" type="text/javascript"></script>
<script>
    var url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add&wechat=serve&servesubmit=true&formhash={FORMHASH}';
    wqjq(document).on('change', '#portrait,#qrcode', function () {
        picture(uploadsuccess_forum, wqjq(this).prop('id'), wqjq(this).prop('name'), typeof (url) == 'undefined' ? '' : url);
    });
    function picture(uploadsuccess, id, name, url) {
        var uploadurl = url ? url : 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve&servesubmit=true&formhash={FORMHASH}';
        var files = wqjq('#'+id)[0].files;
        if (typeof FileReader != 'undefined' && files[0]) {
            wqjq.buildfileupload({
                uploadurl:uploadurl,
                files:files,
                uploadformdata:{upload:1},
                uploadinputname:name,
                success:uploadsuccess,
                error:function() {
                    showDialog('{$Plang['38123cc536ee6760']}');
                }
            });
        } else {
            wqjq.ajaxfileupload({
                url:uploadurl,
                data:{upload:1},
                dataType:'json',
                fileElementId:id,
                success:uploadsuccess
            });
        }
    }
    var uploadsuccess_forum = function(data) {
        var newdata = JSON.parse(data);
        if(newdata['status'] != '0') {
            showDialog(newdata['msg']);
        }else{
            wqjq('#' + newdata.name+'_img').val(newdata.msg);
            wqjq('#' + newdata.name).next().html('<img src="' + newdata.msgurl + '" wqdata-src="' + newdata.msgurl + '" onload="feed_img(wqjq(this).parent())"/>');
        }

    };
</script>