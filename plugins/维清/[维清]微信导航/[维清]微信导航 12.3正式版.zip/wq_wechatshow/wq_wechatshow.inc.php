<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_wechatshow.inc.php 2015-4-22 11:41:38Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET['id'] = "wq_wechatshow:wq_wechatshow";
include_once DISCUZ_ROOT . './source/plugin/wq_wechatshow/config/config.php';
include_once libfile('function/home');

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "list";

$allowmod = array('list', 'view', 'search', 'ajax');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

$plugin_wechatcollecting = !empty($_G['cache']['plugin']['wq_wechatcollecting']) ? 1 : 0;
$plugin_wechatreader = !empty($_G['cache']['plugin']['wq_wechatreader']) ? 1 : 0;
$plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;
require DISCUZ_ROOT . './source/plugin/wq_wechatshow/' . $dirlist[$mod] . '/wechatshow_' . $mod . '.php';

?>