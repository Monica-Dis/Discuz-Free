wqjq.extend({
	createuploadiframe: function(id, url) {
		var iframeid = 'uploadiframe' + id;
		var iframe = '<iframe id="' + iframeid + '" name="' + iframeid + '"';
		if(window.ActiveXObject) {
			if(typeof url == 'boolean') {
				iframe += ' src="' + 'javascript:false' + '"';
			} else if(typeof url == 'string') {
				iframe += ' src="' + url + '"';
			}
		}
		iframe += ' />';
		wqjq(iframe).css({'position':'absolute', 'top':'-1200px', 'left':'-1200px'}).appendTo(document.body);
		return wqjq('#' + iframeid).get(0);
    },
	createuploadform: function(id, fileobjid, data) {
		var formid = 'uploadform' + id;
		var fileid = 'uploadfile' + id;
		var form = wqjq('<form method="post" name="' + formid + '" id="' + formid + '" enctype="multipart/form-data"></form>');
		if(data) {
			for(var i in data) {
				wqjq('<input type="hidden" name="' + i + '" value="' + data[i] + '" />').appendTo(form);
			}
		}
		var oldobj = wqjq('#' + fileobjid);
		var newobj = wqjq(oldobj).clone();
		wqjq(oldobj).attr('id', fileid).before(newobj).appendTo(form);
		wqjq(form).css({'position':'absolute', 'top':'-1200px', 'left':'-1200px'}).appendTo(document.body);
		return form;
	},
	ajaxfileupload: function(s) {
		s = wqjq.extend({}, wqjq.ajaxSettings, s);
		var id = new Date().getTime();
		var form = wqjq.createuploadform(id, s.fileElementId, (typeof(s.data)=='undefined'?false:s.data));
		var io = wqjq.createuploadiframe(id, s.secureuri);
		var iframeid = 'uploadiframe' + id;
		var formid = 'uploadform' + id;

		if(s.global && ! wqjq.active++) {
			wqjq.event.trigger("ajaxStart");
		}
		var requestDone = false;
        var xml = {};
        if(s.global) {
			wqjq.event.trigger("ajaxSend", [xml, s]);
		}
		var uploadcallback = function(istimeout) {
			var io = document.getElementById(iframeid);
			try {
				if(io.contentWindow) {
					xml.responseText = io.contentWindow.document.body?io.contentWindow.document.body.innerHTML:null;
					xml.responseXML = io.contentWindow.document.XMLDocument?io.contentWindow.document.XMLDocument:io.contentWindow.document;
				} else if(io.contentDocument) {
					xml.responseText = io.contentDocument.document.body?io.contentDocument.document.body.innerHTML:null;
					xml.responseXML = io.contentDocument.document.XMLDocument?io.contentDocument.document.XMLDocument:io.contentDocument.document;
				}
			} catch(e) {
				wqjq.handleerror(s, xml, null, e);
			}
			if(xml||istimeout == 'timeout') {
				requestdone = true;
				var status;
				try {
					status = istimeout != 'timeout' ? 'success' : 'error';
					if(status != 'error') {
						var data = wqjq.uploadhttpdata(xml, s.dataType);
						if(s.success) {
							s.success( data, status );
						}
						if(s.global) {
							wqjq.event.trigger("ajaxSuccess", [xml, s]);
						}
					} else {
                        wqjq.handleerror(s, xml, status);
					}
				} catch(e) {
					status = 'error';
					wqjq.handleerror(s, xml, status, e);
				}
				if(s.global) {
					wqjq.event.trigger("ajaxComplete", [xml, s]);
				}

				if(s.global && ! --wqjq.active) {
					wqjq.event.trigger("ajaxStop");
				}

				if (s.complete) {
					s.complete(xml, status);
				}

				wqjq(io).off();

				setTimeout(function() {
					try {
						wqjq(io).remove();
						wqjq(form).remove();
					} catch(e) {
						wqjq.handleerror(s, xml, null, e);
					}
				}, 100);

				xml = null;
			}
		}
		if(s.timeout > 0) {
			setTimeout(function() {
				if(!requestdone) {
					uploadcallback('timeout');
				}
			}, s.timeout);
		}
		try {
			var form = wqjq('#' + formid);
			wqjq(form).attr('action', s.url).attr('method', 'post').attr('target', iframeid);
			if(form.encoding) {
				wqjq(form).attr('encoding', 'multipart/form-data');
			} else {
				wqjq(form).attr('enctype', 'multipart/form-data');
			}
			wqjq(form).submit();
		} catch(e) {
			wqjq.handleerror(s, xml, null, e);
		}

		wqjq('#' + iframeid).load(uploadcallback);
		return {abort: function () {}};
    },
	uploadhttpdata: function(r, type) {
		var data = !type;
		data = type == 'xml' || data ? r.responseXML : r.responseText;
		if(type == 'script') {
			wqjq.globalEval(data);
		}
		if(type == "json") {
			eval("data = " + data);
		}
		if(type == "html") {
			wqjq("<div>").html(data);
		}
		return data;
	},
	handleerror: function(s, xhr, status, e) {
		if(s.error) {
			s.error.call(s.context || s, xhr, status, e);
		}
		if(s.global) {
			(s.context ? wqjq(s.context) : wqjq.event).trigger("ajaxError", [xhr, s, e]);
		}
	}
});