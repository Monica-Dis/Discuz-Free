<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function get_insertsql_by_tablename($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = array(), $_arg_4 = array(), $_arg_5 = array(), $_arg_6 = false, $_arg_7 = array())
{
	$_var_8 = get_allfield_by_tablename($_arg_0);
	foreach ($_var_8 as $_var_9 => $_var_10) {
		if (in_array($_var_10, $_arg_2)) {
			if ($_arg_6) {
				$_var_11 = "utf8";
			} else {
				$_var_11 = "gbk";
			}
			$_var_8[$_var_9] = "hex(CONVERT(`" . $_var_10 . "` USING " . $_var_11 . " )) as " . $_var_10;
		}
	}
	$_var_12 = implode(",", $_var_8);
	$_var_13[] = $_var_12;
	$_var_13[] = $_arg_0;
	$_var_14[] = "1";
	if ($_arg_7) {
		$_var_14[] = $_arg_7[0];
		$_var_13[] = $_arg_7[1];
	}
	$_var_15 = implode(" AND ", $_var_14);
	$_var_16 = DB::fetch_first("SELECT %i FROM %t WHERE " . $_var_15, $_var_13);
	if ($_var_16) {
		foreach ($_var_16 as $_var_12 => $_var_17) {
			if (in_array($_var_12, $_arg_2)) {
				if (!empty($_var_17)) {
					$_var_18[$_var_12] = "0x" . strtolower($_var_17);
				} else {
					$_var_18[$_var_12] = "''";
				}
			} else {
				if (in_array($_var_12, $_arg_3)) {
					$_var_18[$_var_12] = "'{\$" . $_var_12 . "}'";
				} else {
					if (in_array($_var_12, $_arg_4)) {
						$_var_18[$_var_12] = "'0'";
					} else {
						if ($_var_12 == $_arg_1) {
							$_var_18[$_var_12] = "''";
						} else {
							$_var_18[$_var_12] = "'" . $_var_17 . "'";
						}
					}
				}
				if (in_array($_var_12, $_arg_5)) {
					$_var_19[$_var_12] = $_var_17;
				}
			}
		}
		$_var_19["sql"] = "INSERT INTO {\$" . $_arg_0 . "} VALUES (" . implode(",", $_var_18) . ");";
		return $_var_19;
	}
}
function get_allfield_by_tablename($_arg_0)
{
	$_var_1 = DB::query("SHOW COLUMNS FROM " . DB::table($_arg_0));
	while ($_var_2 = DB::fetch($_var_1)) {
		$_var_3[] = $_var_2["Field"];
	}
	return $_var_3;
}
function getSubDirs($_arg_0, $_arg_1 = false)
{
	global $Plang;
	$_var_3 = array();
	if (!($_var_4 = opendir($_arg_0))) {
		return $_var_3;
	}
	$_var_5 = 0;
	while ($_var_6 = readdir($_var_4)) {
		if ($_var_6 == "." || $_var_6 == ".." || $_var_6 == "index.html") {
			continue;
		}
		$_var_7 = $_var_6;
		if ($_arg_1) {
			$_var_3[] = array($_var_7, $Plang["module_" . $_var_7]);
		} else {
			$_var_3[] = $_var_7;
		}
		$_var_5 = $_var_5 + 1;
	}
	return $_var_3;
}
function wq_space_save($_arg_0)
{
	global $_G;
	$_var_2 = date("Ym") . "/" . date("d") . "/";
	$_var_3 = DISCUZ_ROOT . "/data/attachment/wq_space/" . $_var_2;
	dmkdir($_var_3);
	$_var_4 = $_G["uid"] . date("His") . strtolower(random(16)) . ".jpg";
	if (preg_match("/^(data:\\s*image\\/(\\w+);base64,)/", $_arg_0, $_var_5)) {
		file_put_contents($_var_3 . $_var_4, base64_decode(str_replace($_var_5[1], '', $_arg_0)));
		return $_var_2 . $_var_4;
	}
}
function deldir($_arg_0)
{
	$_var_1 = opendir($_arg_0);
	while ($_var_2 = readdir($_var_1)) {
		if ($_var_2 != "." && $_var_2 != "..") {
			$_var_3 = $_arg_0 . "/" . $_var_2;
			if (!is_dir($_var_3)) {
				unlink($_var_3);
			} else {
				deldir($_var_3);
			}
		}
	}
	closedir($_var_1);
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}