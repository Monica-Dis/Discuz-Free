<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_admincp.php 2015-12-28 21:11:17Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function upload_admin($filesname, $type_errortips, $type = 'portal') {
	$upload = new discuz_upload();
	$upload->init($filesname, $type);
	$attach = $upload->attach;
	if(!$attach['isimage']) {
		cpmsg($type_errortips, '', 'error');
	}
	$upload->save();
	return $imgurl = $attach['attachment'];
}

function get_class_select($selectname, $name, $options, $selectedid, $extstr = '', $onchangesubmit = false, $upid = true, $option = true) {
	if($onchangesubmit) {
		$onchangesubmit_str = 'onchange="this.form.submit();"';
	}
	$str = '<select name="' . $selectname . '" id="' . $selectname . '"' . $onchangesubmit_str . '>';
	if($option == true) {
		$str .= '<option value="">' . $extstr . '</option>';
	}
	foreach($options as $key => $value) {
		if($value['status'] != 1) {
			continue;
		}
		if($upid == true) {
			if($value['upid'] !== '0' && $options[$value['upid']]['status'] != 1) {
				continue;
			}
			if($value['upid'] !== '0') {
				$addstr = '--';
			}
		}
		if($selectedid == $key) {
			$selected = ' selected="selected"';
		}
		$str .= '<option value="' . $key . '"  ' . $selected . '  >' . $addstr . $value[$name] . '</option>';
	}
	$str .= '</select>';
	return $str;
}
//From: Dism_taobao-com
?>