<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 == "success") {
		$_var_1 = "CREATE TABLE IF NOT EXISTS `pre_wq_space_class` (\n" . "  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `classname` varchar(30) NOT NULL,\n" . "  `cname` varchar(30) NOT NULL,\n" . "  `status` tinyint(1) NOT NULL,\n" . "  `displayorder` tinyint(4) NOT NULL,\n" . "  `number` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`cid`),\n" . "  KEY `displayorder` (`displayorder`)\n" . ") ENGINE=MyISAM ;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_space_background` (\n" . " `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `uid` int(10) unsigned NOT NULL,\n" . " `username` varchar(60) NOT NULL,\n" . " `classid` int(10) unsigned NOT NULL,\n" . " `displayorder` int(10) NOT NULL,\n" . " `background` varchar(255) NOT NULL,\n" . " `name` varchar(150) NOT NULL,\n" . " `description` varchar(255) NOT NULL,\n" . " `remote` tinyint(1) unsigned NOT NULL,\n" . " `uses` int(10) unsigned NOT NULL,\n" . " `score` int(10) unsigned NOT NULL,\n" . " `free` tinyint(1) unsigned NOT NULL,\n" . " `status` tinyint(1) unsigned NOT NULL,\n" . " `home` tinyint(1) unsigned NOT NULL,\n" . " `carousel` varchar(255) NOT NULL,\n" . " `dateline` int(10) unsigned NOT NULL,\n" . " PRIMARY KEY (`bid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_space_log` (\n" . " `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `uid` int(10) unsigned NOT NULL,\n" . " `background` varchar(255) NOT NULL,\n" . " `bid` int(10) unsigned NOT NULL,\n" . " `dateline` int(10) unsigned NOT NULL,\n" . " `status` tinyint(1) unsigned NOT NULL,\n" . " PRIMARY KEY (`lid`)\n" . ") ENGINE=MyISAM;\n";
		runquery($_var_1);
	} else {
		echo "Access Denied Weiqing";
		return 0;
	}