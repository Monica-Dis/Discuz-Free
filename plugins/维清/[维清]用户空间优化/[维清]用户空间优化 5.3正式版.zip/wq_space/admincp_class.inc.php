<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_class.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_space/config/config.php';
if(!submitcheck('form')) {
	echo <<<EOT
<style>
     .upid{margin-left:13px;}
     .sonid{margin-left:28px;}
     .txt{font-weight: 700;}
     input:hover, input:focus,select:hover,select:focus{border-color:#09C;background: #F5F9FD none repeat scroll 0% 0%;}
</style>
EOT;
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_class', '', 'form');
	showtableheader('', 'nobottom');
	showsubtitle(array($Plang['delete_class'], $Plang['order'], $Plang['classname'], $Plang['number'], $Plang['is_use']));
	foreach($wq_space_class as $key => $val) {
		showtablerow('', array('class="td25"', 'width="50"'), array(
			'<a name="class_' . $val['cid'] . '"><input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['cid'] . '\' /></a> ',
			'<input type="number" style="width:50px;" name="displayorder[' . $val['cid'] . ']"  value="' . $val['displayorder'] . '" />',
			'<input  type="text" ' . ($val['upid'] === '0' ? 'class="txt"' : '') . ' name="classname[' . $val['cid'] . '] " value ="' . $val['classname'] . '" /> ',
			$val['number'],
			'<input class="checkbox" type="checkbox" name="status[' . $val['cid'] . ']" value="1" ' . ($val['status'] == 1 ? 'checked' : '') . '><a name="class_' . $val['cid'] . '" class="class_' . $val['cid'] . '" style="display:none;">' . $val['classname'] . '</a>',
			)
		);
	}
	echo '<tr><td colspan="1"></td><td colspan="4"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">' . $Plang['addclass'] . '</a></div></td></tr>';
	showsubmit('form', 'submit', 'del');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
	echo <<<EOT
<script type='text/JavaScript'>
	var rowtypedata = [[[1,''], [1, '<input name="insertdisplayorder[]" type="number" size="3" style="width:50px;" value="0"> '],[1, '<div><input name="insertclassname[]" class="txt" type="text" ><a href="javascript:;" class="deleterow" onclick="deleterow(this)">{$Plang['delete']}</a></div>'],[1,''],[1,'<input class="checkbox" type="checkbox" name="insertstatus[]" value="1" checked="checked">']],
	];
</script>
EOT;
} else {
	foreach($_GET['classname'] as $key => $value) {
		$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $key, '');
		$data = array('classname' => $value, 'displayorder' => $_GET['displayorder'][$key], 'status' => intval($_GET['status'][$key]), 'number' => $count);
		C::t('#wq_space#wq_space_class')->update(intval($key), $data);
	}
	foreach($_GET['delete'] as $value) {
		C::t('#wq_space#wq_space_class')->delete($value);
	}
	foreach($_GET['insertclassname'] as $key => $value) {
		if(!empty($value)) {
			$data = array('classname' => $value, 'displayorder' => $_GET['insertdisplayorder'][$key], 'status' => intval($_GET['insertstatus'][$key]));
			C::t('#wq_space#wq_space_class')->insert($data);
		}
	}
	savecache('wq_space_class', C::t('#wq_space#wq_space_class')->fetch_all());
	cpmsg($Plang['setsucceed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_class', 'succeed');
}
//From: Dism_taobao-com
?>