<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_space/config/config.php';
if(!submitcheck('form')) {
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_import', '', 'form');
	showtableheader($Plang['importmodule'], 'nobottom');
	$arr = getSubDirs("./source/plugin/wq_space/static/background/", true);
	$option[] = array('0', $Plang['19f06d79f645f9f3s']);
	foreach($wq_space_class as $key => $value) {
		$option[] = array($key, $value['classname']);
	}
	showsetting($Plang['optionmodule'], array('module[]', $arr), '', 'mselect');
	showsetting($Plang['importclass'], array('classid', $option), '', 'select');
	showsetting($Plang['is_free_nosetting'], 'free', 0, 'radio', '', 1);
	showsetting($Plang['free_no_nosetting'], 'score', 1, 'number', '', 0);
	showtagfooter('tbody');
	showsetting($Plang['is_use'], 'status', 1, 'radio');
	showsubmit('form', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$uid = $_G['uid'];
	$status = $_GET['status'] == 1 ? 1 : 0;
	$username = dhtmlspecialchars($_G['username']);
	$free = $_GET['free'] == 1 ? 1 : 0;
	$score = $free == 1 ? max(1, intval($_GET['score'])) : 0;
	$wq_space_background = DB::table('wq_space_background');
	$dateline = TIMESTAMP;
	foreach($_GET['module'] as $key => $value) {
		if($Plang['module_' . $value]) {
			if($wq_space_class[$_GET['classid']]['status'] != 1) {
				$class_first = C::t('#wq_space#wq_space_class')->fetch_first_by_classname($Plang['module_' . $value]);
				if(!$class_first) {
					$class_first['cid'] = C::t('#wq_space#wq_space_class')->insert(array('classname' => $Plang['module_' . $value], 'status' => 1), true);
				}
				$classid = $class_first['cid'];
			} else {
				$classid = $_GET['classid'];
			}
			$arr = getSubDirs("./source/plugin/wq_space/static/background/" . $value . '/images/');
			foreach($arr as $k => $val) {
				$background = "source/plugin/wq_space/static/background/" . $value . '/images/' . $val;
				$background_first = C::t('#wq_space#wq_space_background')->fetch_first_by_background($background);
				if(!$background_first) {
					$filename = substr($val, 0, strripos($val, '.'));
					$carousel = "source/plugin/wq_space/static/background/" . $value . '/carousel/' . $val;
					$carousel = file_exists($carousel) ? $carousel : '';
					if(file_exists("./source/plugin/wq_space/static/background/{$value}/sql/" . CHARSET . "_{$filename}.php")) {
						include_once DISCUZ_ROOT . "./source/plugin/wq_space/static/background/{$value}/sql/" . CHARSET . "_{$filename}.php";
						$background_sql = "background_{$value}_{$filename}";
						runquery($$background_sql);
					} else {
						$data = array(
							'name' => $filename,
							'uid' => $_G['uid'],
							'username' => $_G['username'],
							'background' => $background,
							'carousel' => $carousel,
							'classid' => $classid,
							'status' => $status,
							'free' => $free,
							'score' => $score,
							'dateline' => $dateline,
							'remote' => 1,
						);

						C::t('#wq_space#wq_space_background')->insert($data);
					}
				}
			}
		}
		if($wq_space_class[$_GET['classid']]['status'] != 1) {
			$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $classid, '');
			C::t('#wq_space#wq_space_class')->update($classid, array('number' => $count));
		}
	}
	if($wq_space_class[$_GET['classid']]['status'] == 1) {
		$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $_GET['classid'], '');
		C::t('#wq_space#wq_space_class')->update($_GET['classid'], array('number' => $count));
	}
	savecache('wq_space_class', C::t('#wq_space#wq_space_class')->fetch_all());
	cpmsg($Plang['setsucceed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_import', 'succeed');
}
//From: Dism_taobao-com
?>