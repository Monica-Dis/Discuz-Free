<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($wq_space_class[$_GET['classid']]['status'] == 1) {
	$classid = $_GET['classid'];
	$perpage = intval($setting['perpage']) < 1 ? 1 : intval($setting['perpage']);
	$start = ($page - 1) * $perpage;
	$getview['id'] = 'wq_space';
	$background = C::t('#wq_space#wq_space_background')->fetch_all_by_search(1, '', $_GET['classid'], '', '', '', $start, $perpage, 'displayorder', 'asc');
	if($background) {
		$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $_GET['classid'], '');
		$mpurl = 'plugin.php?id=wq_space&mod=list&classid=' . $_GET['classid'];
		$multi = multi($count, $perpage, $page, $mpurl);
		include template('wq_space:tpl_space_' . $mod);
	} else {
		showmessage($Plang['no_background'], 'plugin.php?id=wq_space');
	}
} else {
	showmessage($Plang['no_class'], 'plugin.php?id=wq_space');
}
//From: Dism_taobao-com
?>