<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['formhash'] == FORMHASH) {
	if($_G['uid']) {
		if($_GET['ac'] == 'uploading' && in_array($_G["groupid"], $setting["use_groups"])) {
			$image = wq_space_save($_GET['image']);
			if($image) {
				C::t('#wq_space#wq_space_log')->insert(array('uid' => $_G['uid'], 'background' => $image, 'dateline' => TIMESTAMP));
				echo "1";
			}
		}
	}
}
//From: Dism_taobao-com
?>