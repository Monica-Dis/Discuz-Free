<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($setting['index_home'] == 1) {
	$home = C::t('#wq_space#wq_space_background')->fetch_all_by_home(1, 1);
}

$touch_tplid = $_G['setting']['styleid2'];
loadcache('style_' . $touch_tplid);
$touch_tpl = $_G['cache']['style_' . $touch_tplid];

include template('wq_space:tpl_space_' . $mod);

?>