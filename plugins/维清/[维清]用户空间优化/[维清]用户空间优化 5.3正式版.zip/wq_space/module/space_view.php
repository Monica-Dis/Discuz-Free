<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$background = C::t('#wq_space#wq_space_background')->fetch($_GET['bid']);
if($background['status'] == 1) {
	if($background['free'] == 1 && $background['score'] > 0 && $setting['extcredit_type']) {
		$extcredit_type = 'extcredits' . $setting['extcredit_type'];
		$use = C::t('#wq_space#wq_space_log')->fetch_first_by_bid($_G['uid'], $background['bid']);
		$member = C::t('common_member_count')->fetch($_G['uid']);
		$score = $member[$extcredit_type] - $background['score'];
	}
	if(submitcheck('usesubmit')) {
		if($log['bid'] != $background['bid']) {
			if($extcredit_type && !$use && $score >= 0) {
				DB::query("UPDATE %t SET `%i`=`%i`-%d WHERE uid=%d LIMIT 1", array('common_member_count', $extcredit_type, $extcredit_type, $background['score'], $_G['uid']));
				updatemembercount($_G['uid'], $extcredit_type);
			}
			$log ? C::t('#wq_space#wq_space_background')->update_incrcase($log['bid'], array('uses' => 1), false) : '';
			C::t('#wq_space#wq_space_log')->insert(array('uid' => $_G['uid'], 'bid' => $background['bid'], 'dateline' => TIMESTAMP));
			C::t('#wq_space#wq_space_background')->update_incrcase($background['bid'], array('uses' => 1));
			header("Location:home.php?mod=space&uid=" . $_G['uid'] . "&do=profile&mycenter=1");
		} else {
			showmessage($Plang['becf3c63082cc5d0'], 'plugin.php?id=wq_space&mod=view&bid=' . $background['bid']);
		}
	} else {
		$background['remote'] == 0 ? $background['background'] = 'data/attachment/portal/' . $background['background'] : '';
		include template('wq_space:tpl_space_' . $mod);
	}
} else {
	showmessage($Plang['on_images'], 'plugin.php?id=wq_space');
}
//From: Dism_taobao-com
?>