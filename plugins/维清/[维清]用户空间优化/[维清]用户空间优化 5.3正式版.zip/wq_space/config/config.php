<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-10-23 14:37:26Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache(array('plugin', 'wq_space_class',));
include_once libfile('function/home');
include_once DISCUZ_ROOT . './source/plugin/wq_space/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_space/function/function_space.php';

$wq_space_class = $_G['cache']['wq_space_class'];
$page = max(1, intval($_GET['page']));
$log = C::t('#wq_space#wq_space_log')->fetch_first($_G['uid']);

$Plang = wq_loadlang('wq_space');

$setting = wq_loadsetting('wq_space');

?>