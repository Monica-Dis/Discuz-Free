<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_space/config/setting_base.php';

$setting['home_speed'] = intval($setting['home_speed']) > 0 ? intval($setting['home_speed']) : 3000;

?>