<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2016-9-27 15:49:39Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_space'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['perpage'] = intval($setting['perpage']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['extcredit_type'] = intval($setting['extcredit_type']);
$setting['class_nav'] = intval($setting['class_nav']);
$setting['index_name'] = trim($setting['index_name']);
$setting['customize'] = intval($setting['customize']);
$setting['use_groups'] = unserialize($setting['use_groups']);

?>