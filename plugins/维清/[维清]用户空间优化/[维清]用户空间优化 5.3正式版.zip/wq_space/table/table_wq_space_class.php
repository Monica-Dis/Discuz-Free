<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_space_class extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_space_class';
		$this->_pk = 'cid';
		parent::__construct();
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ORDER BY `displayorder` ASC", array($this->_table), $this->_pk);
	}

	public function fetch_first_by_classname($classname) {
		return DB::fetch_first("SELECT * FROM %t WHERE classname=%s", array($this->_table, $classname));
	}

	public function update_incrcase($cid, $setarr, $operation = true) {
		foreach($setarr as $key => $val) {
			$sql[] = "`$key`=`$key`" . ($operation ? '+' : '-') . " $val";
		}
		return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), DB::field('cid', $cid)));
	}

}
//From: Dism_taobao-com
?>