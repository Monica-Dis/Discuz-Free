<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_space_background extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_space_background';
		$this->_pk = 'bid';
		parent::__construct();
	}

	public function fetch_all_by_bid($bid) {
		return DB::fetch_all("SELECT * FROM %t WHERE bid IN(%n)", array($this->_table, $bid), $this->_pk);
	}

	public function delete_by_background($background) {
		return DB::delete($this->_table, array('background' => $background));
	}

	public function fetch_first_by_background($background) {
		return DB::fetch_first("SELECT * FROM %t WHERE  background=%s", array($this->_table, $background));
	}

	public function fetch_all_by_home($status, $home) {
		return DB::fetch_all("SELECT * FROM %t WHERE status=%d AND home=%d ORDER BY `displayorder` ASC", array($this->_table, $status, $home));
	}

	public function fetch_all_by_search($status = '', $home = '', $classid = 0, $free = 0, $keyword = '', $search = '', $start = 0, $limit = 20, $displayorder = '', $type = '', $date = 0, $dateline1 = 0, $dateline2 = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder && $type) {
			$order = ' ORDER BY `' . $displayorder . '` ' . $type . ' ';
		}
		if($status !== '') {
			$sql[] = 'status=%d';
			$val[] = $status;
		}
		if($home !== '') {
			$sql[] = 'home=%d';
			$val[] = $home;
		}
		if($free !== '') {
			$sql[] = 'free=%d';
			$val[] = $free;
		}
		if($classid) {
			$sql[] = 'classid=%d';
			$val[] = $classid;
		}
		if($date && $dateline1) {
			$sql[] = $date . '>=%d';
			$val[] = $dateline1;
		}
		if($date && $dateline2) {
			$sql[] = '%d>=' . $date;
			$val[] = $dateline2;
		}
		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($status = '', $home = '', $classid = 0, $free = 0, $keyword = '', $search = '', $date = 0, $dateline1 = 0, $dateline2 = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($status !== '') {
			$sql[] = 'status=%d';
			$val[] = $status;
		}
		if($home !== '') {
			$sql[] = 'home=%d';
			$val[] = $home;
		}
		if($classid) {
			$sql[] = 'classid=%d';
			$val[] = $classid;
		}
		if($free !== '') {
			$sql[] = 'free=%d';
			$val[] = $free;
		}
		if($date && $dateline1) {
			$sql[] = $date . '>=%d ';
			$val[] = $dateline1;
		}
		if($date && $dateline2) {
			$sql[] = '%d>=' . $date;
			$val[] = $dateline2;
		}
		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function update_incrcase($cid, $setarr, $operation = true) {
		foreach($setarr as $key => $val) {
			$sql[] = "`$key`=`$key`" . ($operation ? '+' : '-') . " $val";
		}
		return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), DB::field($this->_pk, $cid)));
	}

}
//From: Dism_taobao-com
?>