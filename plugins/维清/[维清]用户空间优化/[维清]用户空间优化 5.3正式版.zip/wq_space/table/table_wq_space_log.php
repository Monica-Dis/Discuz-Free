<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_space_log extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_space_log';
		$this->_pk = 'lid';
		parent::__construct();
	}

	public function fetch_first($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d ORDER BY `dateline` DESC", array($this->_table, $uid));
	}

	public function fetch_first_by_bid($uid, $bid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND bid=%d", array($this->_table, $uid, $bid));
	}

}
//From: Dism_taobao-com
?>