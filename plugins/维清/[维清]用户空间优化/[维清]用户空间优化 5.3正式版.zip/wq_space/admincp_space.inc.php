<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_space.inc.php 2015-6-15 14:33:23Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_space/config/config.php';
include DISCUZ_ROOT . './source/plugin/wq_space/function/function_admincp_ext.php';
if($_GET['ac'] != 'edit') {
	if(!submitcheck('form')) {
		$status = in_array($_GET['status'], array('0', '1')) ? intval($_GET['status']) : 1;
		$free = in_array($_GET['free'], array('0', '1')) ? intval($_GET['free']) : '';
		$home = in_array($_GET['home'], array('0', '1')) ? intval($_GET['home']) : '';
		$date = in_array($_GET['date'], array('dateline')) ? dhtmlspecialchars($_GET['date']) : 'dateline';
		$search = in_array($_GET['search'], array('name', 'username',)) ? dhtmlspecialchars($_GET['search']) : 'name';
		$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? dhtmlspecialchars($_GET['ordertype']) : 'desc';
		$dateline1 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['dateline1'])) ? strtotime(trim(dhtmlspecialchars($_GET['dateline1']))) : '';
		$dateline2 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['dateline2'])) ? strtotime(trim(dhtmlspecialchars($_GET['dateline2']))) : '';
		$displayorder = in_array($_GET['displayorder'], array('use', 'dateline', 'displayorder')) ? $_GET['displayorder'] : 'displayorder';
		$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
		$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
		$limit = $_GET['perpage'] < 1 ? $setting['admincp_perpage'] : intval($_GET['perpage']);
		$start = ($page - 1) * $limit;
		$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_space';
		if($wq_space_class[$_GET['classid']]['status'] == 1) {
			$classid = $_GET['classid'];
			$mpurl .= '&classid=' . $_GET['classid'];
		}
		$background = C::t('#wq_space#wq_space_background')->fetch_all_by_search($status, $home, $classid, $free, $keyword, $search, $start, $limit, $displayorder, $ordertype, $date, $dateline1, $dateline2);
		$count = C::t('#wq_space#wq_space_background')->count_by_search($status, $home, $classid, $free, $keyword, $search, $date, $dateline1, $dateline2);
		$mpurl .= $free != '' ? '&free=' . $free : '';
		$mpurl .= $home != '' ? '&home=' . $home : '';
		$mpurl .= $date != 'dateline' ? '&date=' . $date : '';
		$mpurl .= $search != 'name' ? '&search=' . $search : '';
		$mpurl .= $ordertype != 'desc' ? '&ordertype=' . $ordertype : '';
		$mpurl .= $dateline1 != '' ? '&dateline1=' . $_GET['dateline1'] : '';
		$mpurl .= $dateline2 != '' ? '&dateline2=' . $_GET['dateline2'] : '';
		$mpurl .= $displayorder != 'displayorder' ? '&displayorder=' . $_GET['displayorder'] : '';
		$mpurl .= !empty($keyword) ? '&keyword=' . $_GET['keyword'] : '';
		$mpurl .= $limit != $setting['admincp_perpage'] ? '&perpage=' . $limit : '';
		$url = $mpurl;
		$mpurl .= $status !== '1' ? '&status=' . $status : '';
		$href = $mpurl . '&page=' . $_GET['page'];
		$url = ADMINSCRIPT . '?' . $url;
		$mpurl = ADMINSCRIPT . '?' . $mpurl;
		echo"<style tpye='text/css'>
   .hover div:hover,.status{background-color: #666666 !important;}
    .hover div{width:55px;height;text-align:center;line-height:18px;border-radius:4px;}
    .hover div:hover a,.status a{color:#FFF !important;}
       li{float:left;}
     .mradio_html li{line-height:25px;}
       input:hover, input:focus,select:hover,select:focus{border-color:#09C;background: #F5F9FD none repeat scroll 0% 0%;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    td span{color:red;}
    .addtr {background: transparent url('static/image/admincp/bg_repno.gif') no-repeat scroll 2px 3px;line-height: 30px;}
    </style>
    <script type='text/javascript' src='static/js/calendar.js'></script>
<script>_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e,'forms'); });</script>";
		$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_space';
		showformheader($fromurl, '', 'forms');
		showtableheader();
		$perpage_html = perpage_html($limit);
		$typehtml = radio_html(array('desc' => $Plang['desc'], 'asc' => $Plang['asc']), 'ordertype', $ordertype);
		$timetpye = array('dateline' => $Plang['addtime'], 'use' => $Plang['uses'], 'displayorder' => $Plang['order']);
		$datetype = select_html(array('dateline' => $Plang['addtime']), 'date', $date, false);
		$orderhtml = select_html($timetpye, 'displayorder', $displayorder, false);
		$datehtml = text_html($_GET['dateline1'], $_GET['dateline2']);
		$free_html = select_html(array('0' => $Plang['free_yes'], '1' => $Plang['free_no']), 'free', $free);
		showtablerow('', array('width="40"', 'width="40"', /* 'width="40"',  'width="40"', */ 'width="60"', 'width="40"', 'width="40"', 'width="40"', 'width="100"', 'width="60"'), array(
			$Plang['class'], get_class_select('classid', 'classname', $wq_space_class, $_GET['classid'], $Plang['all'], true, false),
			$Plang['free'], $free_html,
			$Plang['order'], $orderhtml, $typehtml,
			$Plang['perpage'], $perpage_html,
		));
		showtablefooter();/*Dism��taobao��com*/
		$keywordtype = array('name' => $Plang['subject'], 'username' => $Plang['username'],);
		$options = select_html($keywordtype, 'search', $search, false, false);
		showtableheader();
		showtablerow('', array('width="100"', 'nowrap="nowrap" width="280"', 'nowrap="nowrap" width="70"', 'width="50"', 'width="60"', 'width="60"', 'width="60"',), array(
			$datetype, $datehtml,
			$Plang['search'], $options, "<input size = \"25\" name=\"keyword\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['keyword']) . "\" placeholder='" . $Plang['search_tips'] . "' />" .
			"<input name=\"status\" type=\"hidden\" value=\"" . dhtmlspecialchars($_GET['status']) . "\" />",
			"<input id='submit_forms' class=\"btn\" type=\"submit\" value=\"$lang[search]\" name='forms'/>",
			"<div " . ($status === 1 ? 'class="status"><a' : "><a style='color:green;'") . " href=\"" . $url . "&status=1\">" . $Plang['use'] . "</a></div>",
			"<div " . ($status === 0 ? 'class="status"><a' : "><a style='color:red;'") . " href=\"" . $url . "&status=0\">" . $Plang['no_use'] . "</a></div>",
		));
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		showformheader($fromurl, '', 'form');
		showtableheader($Plang['news_manage'], 'nobottom');
		for($i = 0; $i < 11; $i ++) {
			$style[] = 'nowrap="nowrap"';
		}
		showsubtitle(array('', $Plang['order'], /* $Plang['is_home'], */ $Plang['subject'], $Plang['author'], $Plang['images'], $Plang['class'], $Plang['free_no_nosetting'], $Plang['addtime'], $Plang['used'], $Plang['option']), 'header', $style);
		foreach($background as $val) {
			$val[$search] = !empty($keyword) ? str_replace($keyword, '<span>' . $keyword . '</span>', $val[$search]) : $val[$search];
			$val['remote'] == 0 ? $val['background'] = 'data/attachment/portal/' . $val['background'] : '';
			showtablerow('class="tr"', array('width="10"', 'width="50"', '', /* '', */ 'width="100"', '', '', 'width="72"', '', 'width="50"'), array(
				'<input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['bid'] . '\'/>'
				. '<input type=\'hidden\' name=\'bid[] \' value=\'' . $val['bid'] . '\'/> ',
				'<input type="number" style="width:50px;" name="displayorder[' . $val['bid'] . ']"  value="' . $val['displayorder'] . '" />',
				'<input  type="text" size="10"  name="name[' . $val['bid'] . '] " value ="' . $val['name'] . '" /> ',
				"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
				"<a href='" . $val['background'] . "' target='_blank'><img style='width:160px; height:110px;' src='" . $val['background'] . "' /></a>",
				$wq_space_class[$val['classid']]['status'] == 1 ? $wq_space_class[$val['classid']]['classname'] : '--',
				$val['free'] == 1 ? $val['score'] : $Plang['free_yes'],
				date('Y-m-d H:i:s', $val['dateline']),
				$val['uses'],
				"<a href='" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=wq_space&pmod=admincp_space&ac=edit&bid=" . $val['bid'] . "'>" . $Plang['edit'] . "</a>",
				)
			);
		}
		$use_status = $status == 1 ? 0 : 1;
		$operation = mradio_html(array(
			'3' => array('lang' => $Plang['delete_class']),
			$use_status => array('lang' => $status == 1 ? $Plang['no_use'] : $Plang['use']),
			'4' => array('lang' => $Plang['put_in_class'], 'html' => get_class_select('classid', 'classname', $wq_space_class, $_GET['classid'], '', false, false, false)),
			), 'editstatus', $use_status, $href);

		$multi = multi($count, $limit, $page, $mpurl);
		showsubmit('form', 'submit', $operation, '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_space&ac=edit" class="addtr">' . $Plang['addimage'] . '</a></ul>', $multi, false);
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	} else {
		if(in_array($_GET['editstatus'], array('3', '0', '1', '4'))) {
			$background = C::t('#wq_space#wq_space_background')->fetch_all_by_bid($_GET['delete']);
			foreach($_GET['bid'] as $value) {
				if($background[$value] && $_GET['editstatus'] == '3') {
					C::t('#wq_space#wq_space_background')->delete($value);
					$background[$value]['remote'] == 0 ? pic_delete($background[$value]['background'], 'portal', 0, 0) : '';
					$update_class[$background[$value]['classid']] = $background[$value]['classid'];
				} else {
					$data = array(
						'displayorder' => intval($_GET['displayorder'][$value]),
						'name' => $_GET['name'][$value],
						'home' => $_GET['home'][$value],
					);
					if($background[$value]) {
						if($_GET['editstatus'] == '1' || $_GET['editstatus'] == '0') {
							$_GET['editstatus'] != $background[$value]['status'] ? $update_class[$background[$value]['classid']] = $background[$value]['classid'] : '';
							$data['status'] = $_GET['editstatus'];
						} elseif($wq_space_class[$_GET['classid']]['status'] == 1 && $_GET['editstatus'] == '4') {
							if($_GET['classid'] != $background[$value]['classid']) {
								if($background[$value]['status'] == 1) {
									$update_class[$_GET['classid']] = $_GET['classid'];
									$update_class[$background[$value]['classid']] = $background[$value]['classid'];
								}
							}
							$data['classid'] = $_GET['classid'];
						}
					}
					C::t('#wq_space#wq_space_background')->update($value, $data);
				}
			}
			if($update_class) {
				foreach($update_class as $key => $value) {
					$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $value, '');
					C::t('#wq_space#wq_space_class')->update($value, array('number' => $count));
				}
				savecache('wq_space_class', C::t('#wq_space#wq_space_class')->fetch_all());
			}
			cpmsg($Plang['setsucceed'], $_GET['url'], 'succeed');
		} else {
			cpmsg($Plang['please_select_images'], $_GET['url'], 'error');
		}
	}
} else {
	$background = C::t('#wq_space#wq_space_background')->fetch($_GET['bid']);
	if(!submitcheck('form')) {
		showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_space&ac=edit&' . ($background ? 'bid=' . $background['bid'] : ''), 'enctype', 'form');
		showtableheader($Plang['iamge_set'], 'nobottom');
		showsetting($Plang['subject'], 'name', $background['name'], 'text', '', 0, $Plang['name_tips']);
		showsetting($Plang['summary'], 'description', $background['description'], 'textarea');
		showsetting($Plang['order'], 'displayorder', intval($background['displayorder']), 'number');
		showsetting($Plang['background'] . '(640*440)', 'background', $background['remote'] == 1 ? $background['background'] : '', 'filetext', '', 0, $Plang['background_tips']);
		if($background['background']) {
			$background['remote'] == 0 ? $background['background'] = "data/attachment/portal/" . $background['background'] : '';
			showsetting($Plang['preview'], '', '', "<a href='" . $background['background'] . "' target='_blank'>" . '<img style="width:160px; height:110px;" src="' . $background['background'] . '" /> </a>');
		}
		foreach($wq_space_class as $key => $value) {
			$option[] = array($key, $value['classname']);
		}

		$is_free = $setting['extcredit_type'] ? sprintf($Plang['is_free'], $_G['setting']['extcredits'][$setting['extcredit_type']]['title']) : $Plang['is_free_nosetting'];
		$free_no = $setting['extcredit_type'] ? sprintf($Plang['free_no'], $_G['setting']['extcredits'][$setting['extcredit_type']]['title']) : $Plang['free_no_nosetting'];

		showsetting($Plang['class'], array('classid', $option), $background['classid'], 'select', '', 0);
		showsetting($is_free, 'free', $background ? $background['free'] : 0, 'radio', '', 1);
		showsetting($free_no, 'score', $background ? $background['score'] : 1, 'number', '', 0);
		showtagfooter('tbody');
		showsetting($Plang['is_use'], 'status', $background ? $background['status'] : 1, 'radio');
		if($background['carousel']) {
			showsetting($Plang['is_home'], 'home', $background['home'], 'radio');
		}
		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	} else {
		$url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_space&pmod=admincp_space';
		$name = trim($_GET['name']);
		if(!empty($name)) {
			$data = array(
				'name' => $name,
				'displayorder' => intval($_GET['displayorder']),
				'description' => trim($_GET['description']),
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'classid' => $wq_space_class[$_GET['classid']]['status'] == 1 ? $_GET['classid'] : 0,
				'status' => $_GET['status'] == 1 ? 1 : 0,
				'home' => $_GET['home'] == 1 && $background['carousel'] ? 1 : 0,
				'free' => $_GET['free'] == 1 ? 1 : 0,
				'score' => $_GET['free'] == 1 ? max(1, intval($_GET['score'])) : 0,
			);
			$image = trim($_GET['background']);
			if(!empty($_FILES['background']['name'])) {
				$data['background'] = upload_admin($_FILES['background'], $Plang['noimg']);
				$data['remote'] = 0;
				$data['carousel'] = '';
			} elseif(!empty($image)) {
				$data['background'] = $image;
				$data['remote'] = 1;
				$carousel = str_replace('images', 'carousel', $data['background']);
				$data['carousel'] = strpos($carousel, '/carousel/') && file_exists($carousel) ? $carousel : '';
			}
			if($background) {
				$data['background'] && $background['remote'] == 0 ? pic_delete($background['background'], 'portal', 0, 0) : '';
				if($data['classid'] != $background['classid']) {
					$data['status'] == 1 ? $update_class[$data['classid']] = $data['classid'] : '';
					$background['status'] == 1 ? $update_class[$background['classid']] = $background['classid'] : '';
				} elseif($data['status'] != $background['status']) {
					$update_class[$data['classid']] = $data['classid'];
				}
				C::t('#wq_space#wq_space_background')->update($background['bid'], $data);
				foreach($update_class as $key => $value) {
					$count = C::t('#wq_space#wq_space_background')->count_by_search(1, '', $value, '');
					C::t('#wq_space#wq_space_class')->update($value, array('number' => $count));
				}
				$bid = $background['bid'];
			} else {
				if($data['background']) {
					$data['dateline'] = TIMESTAMP;
					$data['status'] == 1 ? C::t('#wq_space#wq_space_class')->update_incrcase($data['classid'], array('number' => 1)) : '';
					$bid = C::t('#wq_space#wq_space_background')->insert($data, true);
				} else {
					cpmsg($Plang['upload_image'], $url . '&ac=edit', 'error');
				}
			}
			savecache('wq_space_class', C::t('#wq_space#wq_space_class')->fetch_all());
			cpmsg($Plang['setsucceed'], $url . '&ac=edit&bid=' . $bid, 'succeed');
		} else {
			cpmsg($Plang['fill_name'], '', 'error');
		}
	}
}
//From: Dism_taobao-com
?>