<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $nohead_color=1;}-->
<!--{template common/header}-->
<link type="text/css" rel="stylesheet" href="./source/plugin/wq_space/static/css/index.css" />
<link type="text/css" rel="stylesheet" href="./source/plugin/wq_space/static/font/iconfont.css" />
<div class="wq_lump_top b_bottom_sub">
    <a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="wq_return"><i class="wqiconfont wqicon-return f20"></i>{$Plang['697de294260844df']}</a>
    <!--{if $mod=='index'}-->$setting['pluginname']<!--{else}-->$wq_space_class[$classid][classname]<!--{/if}-->
    <a href="./" class="return_in"><i class="wqiconfont wqicon-index_1 f22"></i></a>
</div>
<!--{if  $setting[class_nav]}-->
<!--{eval $getview['mod']='list';}-->
<style>.my_space_tag .tag_list{width:2000px;}</style>
<div class="my_space_tag space_mt1" id="my_space_tag" style="overflow: hidden;">
    <div class="tag_list b_b0">
        <ul>
            <!--{loop array_reverse($wq_space_class)  $key $val}-->
            <!--{if $val[status]==1 && $val[number]>0}-->
            <li<!--{if $mod=='list'&& $classid==$val[cid]}--> class="n" <!--{/if}-->>
                <!--{eval $getview['classid']=$val[cid];$viewurl='plugin.php?'.url_implode($getview);}-->
                <a href="$viewurl">$val[classname]</a>
                <span<!--{if $mod=='list'&& $classid==$val[cid]}--> class="a" <!--{/if}-->></span>
            </li>
            <!--{/if}-->
            <!--{/loop}-->
            <!--{if $setting[index_name]}-->
            <li<!--{if $mod=='index'}--> class="n"<!--{/if}-->><a href="plugin.php?id=wq_space">$setting[index_name]</a><span<!--{if $mod=='index'}--> class="a"<!--{/if}-->></span></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
<script type="text/javascript" src="./source/plugin/wq_space/static/js/isScroll.min.js?{VERHASH}"></script>
<script>
    var wq_window_width = $(window).width();
    var post_selection_w_width = $('.my_space_tag ul').width();
    $('.tag_list').css('width', post_selection_w_width + (wq_window_width / 10));
    myscroll = new iScroll("my_space_tag", {
        hScrollbar: false,
        vScroll: false,
        bounce: true,
    });
    var my_space_tag = $('#my_space_tag .a').offset().left;
    if (my_space_tag > wq_window_width / 2) {
        var scrollTo_right = my_space_tag - (wq_window_width / 2);
        myscroll.scrollTo(-scrollTo_right, 0, 1500);
    }
    var scale = 640 / 440;
    $(function() {
        delayload();
        $(window).scroll(function() {
            delayload();
        });
    })
    function delayload() {
        var document_top = $(document).scrollTop();
        var window_height = $(window).height();
        $(".delayload").each(function() {
            var img = $(this).attr("data");
            var img_top = $(this).offset().top;
            if (img_top >= document_top && img_top <= document_top + window_height) {
                var img_width = $(this).width();
                $(this).attr("src", img).css("height", img_width / scale).attr("class", null);
            }
        })
    }
</script>
<!--{/if}-->