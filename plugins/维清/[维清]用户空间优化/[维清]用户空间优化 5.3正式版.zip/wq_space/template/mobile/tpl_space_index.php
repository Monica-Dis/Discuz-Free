<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $header_nav_app=$header_nav='null';$getview['id']='wq_space';$getview['mod']='list';}-->
<!--{template wq_space:tpl_nav}-->
<!--{if $home}-->
<!--{eval $getview['mod']='view';}-->
<div class="wq_limp_g">
    <div id="wqspace_scroll" class="spacescroll_lb" style="visibility: visible;">
        <div class="spacescroll_lump">
            <!--{loop $home  $key $val}-->
            <!--{if $val[carousel]}-->
            <!--{eval $getview['bid']=$val[bid];$viewurl='plugin.php?'.url_implode($getview);}-->
            <div class="image">
                <a href="$viewurl">
                    <div class="space_img" style="background-image:url({$val[carousel]});width: 100%;height: 300px" ></div>
                </a>
            </div>
            <!--{eval $home_li.='<li'.($key==0?' class="on"':'').'></li>';}-->
            <!--{/if}-->
            <!--{/loop}-->
        </div>
        <ul id="spacescroll_con" class="spacespace_ta">$home_li</ul>
    </div>
</div>
<script src="{$_G['style'][styleimgdir]}mobile/thirdparty/swipe.js"></script>
<script>
    var elem = document.getElementById('wqspace_scroll');
    window.wqscroll = Swipe(elem, {
        auto: $setting[home_speed],
        continuous: true,
        callback: function(pos) {
            var i = bullets.length;
            if (i == 2 && pos > 1) {
                pos = pos - 2
            }
            while (i--) {
                bullets[i].className = ' ';
            }
            bullets[pos].className = 'on';
        }
    });
    var bullets = document.getElementById('spacescroll_con').getElementsByTagName('li');
</script>
<!--{/if}-->
<div class="personality_sz">
    <!--{if in_array($_G["groupid"], $setting["use_groups"]) && $setting["customize"] && $touch_tpl['tpldir'] == './template/wq_touch'}-->
    <div class="personality_list head_portrait">
        <a href="javascript:;">&#x81EA;&#x5B9A;&#x4E49;&#x56FE;&#x7247;<i class="wqiconfont wqicon-youyou y"></i></a>
    </div>
    <script>
        var photoClip_width = wq_window_width;
        var photoClip_height = 220;
        var uploading_url = 'plugin.php?id=wq_space';
        function uploading_return(img_data) {
            location.href = 'home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1';
        }
    </script>
    <!--{template common/uploading}-->
    <!--{/if}-->

    <!--{loop $wq_space_class  $key $val}-->
    <!--{if $val[status]==1&&$val[number]>0}-->
    <!--{eval $background = C::t('#wq_space#wq_space_background')->fetch_all_by_search(1,0, $key, '', '', '', 0, 6, 'displayorder', 'asc');}-->
    <!--{if $background}-->
    <!--{eval $count = C::t('#wq_space#wq_space_background')->count_by_search(1,'', $key,'');}-->
    <div class="personality_groom">
        <h3>$val[classname]</h3>
        <ul>
            <!--{loop $background $k $v}-->
            <!--{eval $v[remote]==0?$v[background]='data/attachment/portal/'.$v[background]:'';}-->
            <li>
                <!--{if $count>6 && $k==5}-->
                <!--{eval $getview['mod']='list';$getview['classid']=$key;$viewurl='plugin.php?'.url_implode($getview);}-->
                <a href="$viewurl"><img class="delayload" src="./source/plugin/wq_space/static/images/grey_bg.gif" data="$v[background]"><span class="groom_all"><i>{$Plang[all]}($count)</i></span></a>
                <!--{else}-->
                <!--{eval $getview['mod']='view';$getview['bid']=$v[bid];$viewurl='plugin.php?'.url_implode($getview);}-->
                <a href="$viewurl"><img class="delayload" src="./source/plugin/wq_space/static/images/grey_bg.gif" data="$v[background]">
                    <p>$v[name]</p><!--{if $v[free]==1&&$setting[extcredit_type]}--><i class="jf">{$v[score]}</i><!--{/if}-->
                    <!--{if $log[bid]==$v[bid]}--><span class="iconfont_dui"><img src="./source/plugin/wq_space/static/images/iconfont_dui.png"/></span><!--{/if}-->
                </a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <!--{/loop}-->
</div>