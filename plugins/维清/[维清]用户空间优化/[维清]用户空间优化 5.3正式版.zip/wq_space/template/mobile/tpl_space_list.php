<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $header_nav_app=$header_nav='null';$getview['id']='wq_space';}-->
<!--{template wq_space:tpl_nav}-->
<!--{eval $getview['mod']='view';}-->
<div class="personality_bg">
    <div class="personality_groom spacing15">
        <h3></h3>
        <ul>
            <!--{loop $background $k $v}-->
            <!--{eval $getview['bid']=$v[bid];$viewurl='plugin.php?'.url_implode($getview);
            $v[remote]==0?$v[background]='data/attachment/portal/'.$v[background]:'';}-->
            <li>
                <a href="$viewurl">
                    <img class="delayload" src="./source/plugin/wq_space/static/images/grey_bg.gif" data="$v[background]"><p>$v[name]</p>
                    <!--{if $v[free]==1&&$setting[extcredit_type]}--><i class="jf">{$v[score]}</i><!--{/if}-->
                    <!--{if $log[bid]==$v[bid]}--><span class="iconfont_dui"><img src="./source/plugin/wq_space/static/images/iconfont_dui.png" /></span><!--{/if}-->
                </a>
            </li>
            <!--{/loop}-->
    </div>
    <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
</div>