<?php exit("From: DisM.taobao.com"); ?>
<!--{eval $header_nav_app=$header_nav='null';}-->
<!--{template common/header}-->
<link type="text/css" rel="stylesheet" href="./source/plugin/wq_space/static/css/view.css"/>
<link type="text/css" rel="stylesheet" href="./source/plugin/wq_space/static/font/iconfont.css" />
<div class="return_data space_dara">
    <span><a href="javascript:history.go(-1);"><i class="wqiconfont wqicon-return f18"></i>{$Plang['697de294260844df']}</a></span>
    <em class="y"><a href="./"><i class="wqiconfont wqicon-index_2 f22"></i></a></em>
</div>
<div class="personality_bg">
    <div class="personality_view"><img id="background_iamges" src="$background['background']"/></div>
    <script>
        var scale = 640 / 440;
        var img_width = $(window).width();
        $('#background_iamges').css("height", img_width / scale);
    </script>
    <div class="personality_view_title">$background['name']</div>
    <!--{if $background['description']}-->
    <div class="personality_view_con">$background['description']</div>
    <!--{/if}-->
    <!--{if $extcredit_type && !$use}-->
    <!--{eval $extcredit_title = $_G['setting']['extcredits'][$setting['extcredit_type']]['title'];}-->
    <div class="integral"><i class="jf">{$Plang['74b674b3da161c5f']}{$background[score]}{$extcredit_title}</i><br/>{$Plang['84e304063eebedbc']}{$member[$extcredit_type]}{$extcredit_title}</div>
    <!--{/if}-->
    <!--{if $log[bid]==$background[bid]}-->
    <div class="personality_view_button p_open">{$Plang['331395026a267212']}</div>
    <!--{else}-->
    <!--{if $extcredit_type && !$use && $score < 0}-->
    <div class="personality_view_button p_open" >{$extcredit_title}{$Plang['f7fdf07cf57c0333']}</div>
    <!--{else}-->
    <div class="personality_view_button" onclick="$('#useform').submit();"><a href="javascript:;">{$Plang['19f06d79f645f9f3']}</a></div>
    <form action="plugin.php?" method="post" id="useform">
        <input type="hidden" value="wq_space" name="id"/>
        <input type="hidden" value="view" name="mod"/>
        <input type="hidden" value="true" name="usesubmit"/>
        <input type="hidden" value="$background[bid]" name="bid"/>
        <input type="hidden" value="{FORMHASH}" name="formhash"/>
    </form>
    <!--{/if}-->
    <!--{/if}-->
</div>