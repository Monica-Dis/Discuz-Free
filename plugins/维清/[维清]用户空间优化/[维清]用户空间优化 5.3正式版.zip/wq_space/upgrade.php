<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2015-10-23 14:37:26Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_space/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '';
		cpmsg($Plang_install["updatecacheing"], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':

		$sql = <<<EOF

EOF;
		runquery($sql);
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//From: Dism_taobao-com
?>