<?php

$background_6_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/6/images/1.jpg',0xb0d7d1a9b9abd6f7,0xcbadb4f8ced2bbd8b5bdd6bbd3d0cdafbbb0b5c4c8d5d7d3c0ef,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>