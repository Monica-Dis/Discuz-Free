<?php

$background_6_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/6/images/6.jpg',0xe7be8ee4babae9b1bc,0xe68891e79a84e788b1e5a682e6b3a1e6b2abe888ace594afe7be8ee38082e58db4e4b99fe5a682e6b3a1e6b2abe888ace88486e5bcb1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>