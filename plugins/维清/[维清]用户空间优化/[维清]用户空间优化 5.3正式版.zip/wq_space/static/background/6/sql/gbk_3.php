<?php

$background_6_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/6/images/3.jpg',0xbbd2b9c3c4ef,0xd0c4d6d0b6bcd3d0d2bbd6bbcbaebea7d0aca1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>