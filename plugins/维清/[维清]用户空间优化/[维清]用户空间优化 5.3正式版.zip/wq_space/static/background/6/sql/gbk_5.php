<?php

$background_6_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/6/images/5.jpg',0xd0a1cdf5d7d3,0xcbf9d3d0b5c4b4f3c8cbb6bcd4f8beadcac7d0a1baa2a3accbe4c8bba3acd6bbd3d0c9d9cafdb5c4c8cbbcc7b5c3a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>