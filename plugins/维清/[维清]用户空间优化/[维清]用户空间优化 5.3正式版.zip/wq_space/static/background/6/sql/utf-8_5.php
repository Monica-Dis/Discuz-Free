<?php

$background_6_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/6/images/5.jpg',0xe5b08fe78e8be5ad90,0xe68980e69c89e79a84e5a4a7e4babae983bde69bbee7bb8fe698afe5b08fe5ada9efbc8ce899bde784b6efbc8ce58faae69c89e5b091e695b0e79a84e4babae8aeb0e5be97e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>