<?php

$background_6_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/6/images/1.jpg',0xe799bde99baae585ace4b8bb,0xe8b081e5b8a6e68891e59b9ee588b0e58faae69c89e7aba5e8af9de79a84e697a5e5ad90e9878c,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>