<?php

$background_6_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/6/images/2.jpg',0xe5bdbce5be97e6bd98,0xe58db3e4bdbfe995bfe5a4a7e5908ee79a84e4b896e7958ce6b2a1e982a3e6a0b7e7be8ee5a5bdefbc8ce4b99fe8a681e58b87e695a2e99da2e5afb9e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>