<?php

$background_6_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/6/images/2.jpg',0xb1cbb5c3c5cb,0xbcb4cab9b3a4b4f3baf3b5c4cac0bde7c3bbc4c7d1f9c3c0bac3a3acd2b2d2aad3c2b8d2c3e6b6d4a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>