<?php

$background_6_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/6/images/6.jpg',0xc3c0c8cbd3e3,0xced2b5c4b0aec8e7c5ddc4adb0e3cea8c3c0a1a3c8b4d2b2c8e7c5ddc4adb0e3b4e0c8f5,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>