<?php

$background_6_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/6/images/4.jpg',0xe58cb9e8afbae69bb9,0xe69bbee4b8bae4b880e4b8aae4babae8b08ee8a880e4b99fe4bfa1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>