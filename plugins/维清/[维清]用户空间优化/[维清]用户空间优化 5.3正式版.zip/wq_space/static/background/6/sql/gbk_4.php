<?php

$background_6_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/6/images/4.jpg',0xc6a5c5b5b2dc,0xd4f8ceaad2bbb8f6c8cbbbd1d1d4d2b2d0c5,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>