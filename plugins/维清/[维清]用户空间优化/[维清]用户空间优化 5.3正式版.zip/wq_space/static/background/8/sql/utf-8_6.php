<?php

$background_8_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/8/images/6.jpg',0xe99ba8e4b88be695b4e5a49c,0xe99ba8e4b88be695b4e5a49cefbc8ce68891e79a84e788b1e6baa2e587bae5b0b1e5838fe99ba8e6b0b4e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>