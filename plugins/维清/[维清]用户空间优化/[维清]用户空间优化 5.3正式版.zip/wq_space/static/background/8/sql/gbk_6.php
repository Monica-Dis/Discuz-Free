<?php

$background_8_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/8/images/6.jpg',0xd3eacfc2d5fbd2b9,0xd3eacfc2d5fbd2b9a3acced2b5c4b0aed2e7b3f6becdcff1d3eacbaea1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>