<?php

$background_8_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/8/images/2.jpg',0xc7e9b2bbd6aacbf9c6f0,0xc7e9b2bbd6aacbf9c6f0a3acd2bbcdf9b6f8c9eea1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>