<?php

$background_8_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/8/images/2.jpg',0xe68385e4b88de79fa5e68980e8b5b7,0xe68385e4b88de79fa5e68980e8b5b7efbc8ce4b880e5be80e8808ce6b7b1e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>