<?php

$background_8_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/8/images/4.jpg',0xe4bda0e698afe68891e79a84e6b8a9e69a96,0xe4bda0e7ab99e79a84e59cb0e696b9efbc8ce8bf9ee590b9e8bf87e69da5e79a84e9a38ee983bde698afe69a96e79a84e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>