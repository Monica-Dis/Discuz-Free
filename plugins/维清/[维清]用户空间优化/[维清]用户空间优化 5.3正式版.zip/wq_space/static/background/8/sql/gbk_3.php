<?php

$background_8_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/8/images/3.jpg',0xd3f6bcfbc4e3,0xd3f6bcfbc4e3a3acc8bbbaf3d3f6bcfbced2d7d4bcbaa1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>