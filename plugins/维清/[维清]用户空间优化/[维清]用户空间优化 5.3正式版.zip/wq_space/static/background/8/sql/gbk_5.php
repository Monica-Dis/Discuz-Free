<?php

$background_8_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/8/images/5.jpg',0xc8a5b0aeb0c9,0xc8a5b0aeb0c9a3acbecdcff1b2bbd4f8cadcc9cbd2bbd1f9a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>