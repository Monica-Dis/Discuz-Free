<?php

$background_8_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/8/images/1.jpg',0xcab1bce4d7d4d3fad2bbc7d0,0xcab1bce4d7d4d3fad2bbc7d0a3acb5abced2b2a2b2bbcfebd2bbc7d0b6bcb1bbd7d4d3faa1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>