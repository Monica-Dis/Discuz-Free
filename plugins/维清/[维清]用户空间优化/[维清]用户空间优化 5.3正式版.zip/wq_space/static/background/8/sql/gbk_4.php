<?php

$background_8_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/8/images/4.jpg',0xc4e3cac7ced2b5c4cec2c5af,0xc4e3d5beb5c4b5d8b7bda3acc1acb4b5b9fdc0b4b5c4b7e7b6bccac7c5afb5c4a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>