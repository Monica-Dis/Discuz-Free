<?php

$background_8_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/8/images/1.jpg',0xe697b6e997b4e887aae68488e4b880e58887,0xe697b6e997b4e887aae68488e4b880e58887efbc8ce4bd86e68891e5b9b6e4b88de683b3e4b880e58887e983bde8a2abe887aae68488e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>