<?php

$background_8_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/8/images/5.jpg',0xe58ebbe788b1e590a7,0xe58ebbe788b1e590a7efbc8ce5b0b1e5838fe4b88de69bbee58f97e4bca4e4b880e6a0b7e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>