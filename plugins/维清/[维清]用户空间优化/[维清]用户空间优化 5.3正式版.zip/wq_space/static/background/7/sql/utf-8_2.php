<?php

$background_7_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/7/images/2.jpg',0xe985b7e8b791e58f8ce591a8e5b9b432,0xe985b7e8b791e58f8ce591a8e5b9b4efbc8ce58faae4b8bae7bb99e4bda0e69c80e5a5bde79a84e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>