<?php

$background_7_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/7/images/1.jpg',0xbfe1c5dccbabd6dcc4ea31,0xbfe1c5dccbabd6dcc4eaa3acd6bbceaab8f8c4e3d7eebac3b5c4a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>