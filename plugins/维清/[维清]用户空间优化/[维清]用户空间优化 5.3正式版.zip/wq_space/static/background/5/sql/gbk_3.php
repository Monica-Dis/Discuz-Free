<?php

$background_5_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/5/images/3.jpg',0xc4a7bbc3bcd1c8cb,0xced2ccfdb5c4bcfbc4e3d0c4d6d0b5c4c4a4b0dd,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>