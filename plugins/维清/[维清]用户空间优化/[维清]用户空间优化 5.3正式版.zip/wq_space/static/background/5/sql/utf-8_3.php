<?php

$background_5_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/5/images/3.jpg',0xe9ad94e5b9bbe4bdb3e4baba,0xe68891e590ace79a84e8a781e4bda0e5bf83e4b8ade79a84e8869ce68b9c,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>