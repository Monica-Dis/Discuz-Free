<?php

$background_5_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/5/images/5.jpg',0xd2b9d6aec9f1c6f7,0xd2b9d6aec9f1c6f7a3acbfe1ecc5b0b5badaa3a1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>