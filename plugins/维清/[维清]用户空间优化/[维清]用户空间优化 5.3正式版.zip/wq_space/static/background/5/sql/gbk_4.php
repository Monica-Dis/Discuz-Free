<?php

$background_5_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/5/images/4.jpg',0xf7c8bbf3d6c1b1a6,0xf7c8bbf3d6c1b1a6a3acd6fac4e3d5f7b7fed0c4d6d0b5c45441a3a1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>