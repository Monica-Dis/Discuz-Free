<?php

$background_5_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/5/images/1.jpg',0xe69a97e5a49ce9aa91e5a3ab,0xe5a4b1e8b4a5e698afe4bd95e6bb8be591b3efbc8ce68891e4bb8ee4b88de79fa5e98193e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>