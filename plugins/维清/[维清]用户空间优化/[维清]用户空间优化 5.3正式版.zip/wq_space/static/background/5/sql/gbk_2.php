<?php

$background_5_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/5/images/2.jpg',0xbadaf7c8c5aecdf5,0xbfecc0b4cff2c5aecdf5b4f3c8cbc7ebb0b2,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>