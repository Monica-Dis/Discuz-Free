<?php

$background_5_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/5/images/1.jpg',0xb0b5d2b9c6efcabf,0xcaa7b0dccac7baced7ccceb6a3acced2b4d3b2bbd6aab5c0a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>