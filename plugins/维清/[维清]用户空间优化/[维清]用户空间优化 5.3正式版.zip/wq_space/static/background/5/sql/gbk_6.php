<?php

$background_5_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/5/images/6.jpg',0xd3c4b0b5cab9d5df,0xd3c4b0b5cab9d5dfa3acbadaf7c8c5aecdf5b5c4c4a7b7a8cab9a3a1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>