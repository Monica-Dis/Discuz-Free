<?php

$background_5_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/5/images/2.jpg',0xe9bb91e9ad85e5a5b3e78e8b,0xe5bfabe69da5e59091e5a5b3e78e8be5a4a7e4babae8afb7e5ae89,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>