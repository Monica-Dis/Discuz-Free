<?php

$background_5_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/5/images/4.jpg',0xe9ad85e68391e887b3e5ae9d,0xe9ad85e68391e887b3e5ae9defbc8ce58aa9e4bda0e5be81e69c8de5bf83e4b8ade79a845441efbc81,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>