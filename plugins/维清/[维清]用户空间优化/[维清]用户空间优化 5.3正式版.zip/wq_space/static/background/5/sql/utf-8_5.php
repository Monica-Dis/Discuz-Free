<?php

$background_5_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/5/images/5.jpg',0xe5a49ce4b98be7a59ee599a8,0xe5a49ce4b98be7a59ee599a8efbc8ce985b7e782abe69a97e9bb91efbc81,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>