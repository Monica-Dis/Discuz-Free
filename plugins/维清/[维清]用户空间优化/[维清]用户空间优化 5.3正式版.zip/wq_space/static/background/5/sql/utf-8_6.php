<?php

$background_5_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/5/images/6.jpg',0xe5b9bde69a97e4bdbfe88085,0xe5b9bde69a97e4bdbfe88085efbc8ce9bb91e9ad85e5a5b3e78e8be79a84e9ad94e6b395e4bdbfefbc81,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>