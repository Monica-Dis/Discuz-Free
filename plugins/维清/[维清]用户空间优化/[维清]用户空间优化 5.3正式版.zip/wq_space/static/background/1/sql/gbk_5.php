<?php

$background_1_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/1/images/5.jpg',0xc3c0c3eecab1bce4,0xcab1bce4dcf3dcdba3acd6bbceaab5c8b5bdd7eebac3b5c4c4e3a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>