<?php

$background_1_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/1/images/6.jpg',0xb5c8b4fdd7c5c4e3,0xcda3cfc2bdc5b2bdcfedcadcd5e2d2bbbfcca3acb7c2b7f0cac0bde7d6bbcaf4d3dac4e3d2bbc8cba1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>