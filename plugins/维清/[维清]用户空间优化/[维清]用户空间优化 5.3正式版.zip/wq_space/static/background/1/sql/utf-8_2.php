<?php

$background_1_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/1/images/2.jpg',0xe88892e98082e79a84e7a78be697a5,0xe7a78be5a4a9e79a84e998b3e58589efbc8ce781bfe78382e8808ce6b8a9e69f94e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>