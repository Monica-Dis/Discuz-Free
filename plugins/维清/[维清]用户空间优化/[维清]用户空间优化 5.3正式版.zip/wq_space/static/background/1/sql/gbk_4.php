<?php

$background_1_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/1/images/4.jpg',0xc2e4d2b6e7cdb7d7,0xb7c9cee8b5c4c2e4d2b6a3acc7efccecb5c4bafbb5fba1a3a1b6c2e4d2b6e7cdb7d7a1b7bcc4cdd0b6d4c4e3b5c4cbbcc4eea1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>