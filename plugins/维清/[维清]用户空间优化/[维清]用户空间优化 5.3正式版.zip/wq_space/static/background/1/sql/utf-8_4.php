<?php

$background_1_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/1/images/4.jpg',0xe890bde58fb6e7bca4e7bab7,0xe9a39ee8889ee79a84e890bde58fb6efbc8ce7a78be5a4a9e79a84e89db4e89db6e38082e3808ae890bde58fb6e7bca4e7bab7e3808be5af84e68998e5afb9e4bda0e79a84e6809de5bfb5e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>