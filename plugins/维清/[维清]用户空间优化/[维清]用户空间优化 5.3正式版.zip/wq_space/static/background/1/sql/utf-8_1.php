<?php

$background_1_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/1/images/1.jpg',0xe7a78be99ba8,0xe7a78be5a4a9e79a84e5b08fe99ba8e6b785e6b785e6b2a5e6b2a5efbc8ce68ea9e79b96e4bd8fe4ba86e68891e79a84e6b3aae6b0b4e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>