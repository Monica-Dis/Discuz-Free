<?php

$background_1_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/1/images/1.jpg',0xc7efd3ea,0xc7efccecb5c4d0a1d3eae4c0e4c0c1a4c1a4a3acd1dab8c7d7a1c1cbced2b5c4c0e1cbaea1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>