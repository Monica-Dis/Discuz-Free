<?php

$background_1_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/1/images/3.jpg',0xc4e3bac3c7efccec,0xb7e3d2b6d2bbc6acc1bdc6acc4e3bac3c7efcceca1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>