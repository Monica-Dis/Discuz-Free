<?php

$background_1_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/1/images/3.jpg',0xe4bda0e5a5bde7a78be5a4a9,0xe69eabe58fb6e4b880e78987e4b8a4e78987e4bda0e5a5bde7a78be5a4a9e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>