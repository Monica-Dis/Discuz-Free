<?php

$background_1_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/1/images/2.jpg',0xcae6cacab5c4c7efc8d5,0xc7efccecb5c4d1f4b9e2a3acb2d3c0c3b6f8cec2c8e1a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>