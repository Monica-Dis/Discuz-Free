<?php

$background_n1_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/n1/images/1.jpg',0x475358,0xe697b6e9809fe99da9e591bde79a87e88085e7958ce5ae9a,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>