<?php

$background_n1_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/n1/images/4.jpg',0xe6818be5aeb6,0xe788b1e4b88ae6898ee58da1e9a38eefbc8ce6818be4b88ae4b880e4b8aae5aeb6efbc8ce68da2e4b88ae3808ae6818be5aeb6e3808be6849fe58f97e4b88be590a7e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>