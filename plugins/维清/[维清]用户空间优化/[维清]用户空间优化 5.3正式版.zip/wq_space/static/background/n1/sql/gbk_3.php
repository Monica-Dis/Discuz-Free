<?php

$background_n1_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/n1/images/3.jpg',0xc3d8c3dcc9adc1d6,0xd5e2c0efd3d0cec2bacdb5c4d1f4b9e2bacdc3afc3dcb5c4c1d6c4bea3acb2bbb7c0b1d5c9cfd1dbbea6c8a5b8d0cadcd5e2c6aca1b6c3d8c3dcc9adc1d6a1b7b0c9a1a32d2dc0b4d4b4a3bac9eedbdacad0d2bbbacfc0f1c9e8bcc6d3d0cfdeb9abcbbe,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>