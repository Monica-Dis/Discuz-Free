<?php

$background_n1_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/n1/images/1.jpg',0x475358,0xcab1cbd9b8efc3fcbbcad5dfbde7b6a8,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>