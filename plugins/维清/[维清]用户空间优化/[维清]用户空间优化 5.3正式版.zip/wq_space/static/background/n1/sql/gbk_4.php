<?php

$background_n1_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/n1/images/4.jpg',0xc1b5bcd2,0xb0aec9cfd4fabfa8b7e7a3acc1b5c9cfd2bbb8f6bcd2a3acbbbbc9cfa1b6c1b5bcd2a1b7b8d0cadccfc2b0c9a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>