<?php

$background_n1_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/n1/images/2.jpg',0xe788b1e4b88ae5af82e5af9e,0xe6b182e6b182e4bda0e4b88de8a681e5868de997aae8bab2efbc8ce6898de6988ee799bdefbc8ce788b1e4b88ae4bda0efbc8ce7ad89e4ba8ee3808ae788b1e4b88ae5af82e5af9ee3808be380822d2de69da5e6ba90efbc9ae58d97e4baace889bae58aa8e5be8b,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>