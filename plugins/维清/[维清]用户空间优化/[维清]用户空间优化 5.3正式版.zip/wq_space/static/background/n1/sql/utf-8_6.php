<?php

$background_n1_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/n1/images/6.jpg',0xe6a183e88ab1e69cb5e69cb5e5bc80,0x32303135e5b9b4e698a5efbc8ce5a5bde8bf90e8b5b0e8b5b7efbc8ce5b88ce69c9be3808ae6a183e88ab1e69cb5e69cb5e5bc80e3808be38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>