<?php

$background_n1_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/n1/images/5.jpg',0xb7c9b5c4cbbcc4ee,0xd4dac4c7d4b6b7bdb5c4c4e3a3acced2b7c5b7c9c1cbced2b5c4cbbcc4eea3acc4e3c4dcb8d0cadcb5bdc2f0a3bf2d2dc0b4d4b4a3bad6d8c7ecc9eebaecc9e7,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>