<?php

$background_n1_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/n1/images/6.jpg',0xccd2bba8b6e4b6e4bfaa,0x32303135c4eab4baa3acbac3d4cbd7dfc6f0a3accfa3cdfba1b6ccd2bba8b6e4b6e4bfaaa1b7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>