<?php

$background_n1_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/n1/images/2.jpg',0xb0aec9cfbcc5c4af,0xc7f3c7f3c4e3b2bbd2aad4d9c9c1b6e3a3acb2c5c3f7b0d7a3acb0aec9cfc4e3a3acb5c8d3daa1b6b0aec9cfbcc5c4afa1b7a1a32d2dc0b4d4b4a3bac4cfbea9d2d5b6afc2c9,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>