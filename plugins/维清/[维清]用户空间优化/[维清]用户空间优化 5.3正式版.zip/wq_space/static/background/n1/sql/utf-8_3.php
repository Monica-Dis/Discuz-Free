<?php

$background_n1_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/n1/images/3.jpg',0xe7a798e5af86e6a3aee69e97,0xe8bf99e9878ce69c89e6b8a9e5928ce79a84e998b3e58589e5928ce88c82e5af86e79a84e69e97e69ca8efbc8ce4b88de998b2e997ade4b88ae79cbce79d9be58ebbe6849fe58f97e8bf99e78987e3808ae7a798e5af86e6a3aee69e97e3808be590a7e380822d2de69da5e6ba90efbc9ae6b7b1e59cb3e5b882e4b880e59088e7a4bce8aebee8aea1e69c89e99990e585ace58fb8,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>