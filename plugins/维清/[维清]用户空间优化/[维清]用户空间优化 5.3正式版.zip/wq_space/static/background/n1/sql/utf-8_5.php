<?php

$background_n1_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/n1/images/5.jpg',0xe9a39ee79a84e6809de5bfb5,0xe59ca8e982a3e8bf9ce696b9e79a84e4bda0efbc8ce68891e694bee9a39ee4ba86e68891e79a84e6809de5bfb5efbc8ce4bda0e883bde6849fe58f97e588b0e59097efbc9f2d2de69da5e6ba90efbc9ae9878de5ba86e6b7b1e7baa2e7a4be,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>