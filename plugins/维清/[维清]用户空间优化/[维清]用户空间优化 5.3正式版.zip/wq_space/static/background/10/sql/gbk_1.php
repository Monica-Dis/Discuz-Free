<?php

$background_10_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/10/images/1.jpg',0xcef0cdfcb3f5d0c4,0xcef0cdfcb3f5d0c4a3acb7bdb5c3cabcd6d5a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>