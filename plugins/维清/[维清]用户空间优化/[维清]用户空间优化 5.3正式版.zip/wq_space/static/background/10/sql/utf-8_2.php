<?php

$background_10_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/10/images/2.jpg',0xe7bbbfe889b2e58e9fe9878e,0xe4b99fe8aeb8e4b896e7958ce4b88ae4b99fe69c89e4ba94e58d83e69cb5e5928ce4bda0e4b880e6a8a1e4b880e6a0b7e79a84e88ab1efbc8ce4bd86e58faae69c89e4bda0e698afe68891e78bace4b880e697a0e4ba8ce79a84e78eabe791b0e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>