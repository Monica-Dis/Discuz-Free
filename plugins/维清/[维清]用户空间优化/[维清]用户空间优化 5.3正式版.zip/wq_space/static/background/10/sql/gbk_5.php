<?php

$background_10_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/10/images/5.jpg',0xcfa6d1f4cbc6ced2,0xc3bfb5b1c7e9d0f7b5cdc2e4b5c4cab1baf2a3acb8f1cde2cfb2bbb6bfb4cfa6d1f4a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>