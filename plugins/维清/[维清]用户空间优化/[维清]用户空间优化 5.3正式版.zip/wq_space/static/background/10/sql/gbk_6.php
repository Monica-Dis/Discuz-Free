<?php

$background_10_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/10/images/6.jpg',0xd0c7d0c7d3ebced2,0xc3bfb8f6c8cbb6bcd3d0caf4d3dad7d4bcbab5c4d0c7d0c7a3accbfcbeb2beb2b5d8d4dad2b9bfd5d6d0cad8bba4d7c5c4e3a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>