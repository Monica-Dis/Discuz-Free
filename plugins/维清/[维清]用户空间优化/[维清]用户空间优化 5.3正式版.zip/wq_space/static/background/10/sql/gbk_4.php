<?php

$background_10_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/10/images/4.jpg',0xc5aeb7c9d0d0d4b1,0xc8e7b9fbb2bbc8a5b1e9c0facac0bce4a3acced2c3c7becdb2bbd6aab5c0cab2c3b4cac7ced2c3c7beabc9f1bacdc7e9b8d0b5c4bcc4cdd0a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>