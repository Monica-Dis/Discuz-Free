<?php

$background_10_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/10/images/6.jpg',0xe6989fe6989fe4b88ee68891,0xe6af8fe4b8aae4babae983bde69c89e5b19ee4ba8ee887aae5b7b1e79a84e6989fe6989fefbc8ce5ae83e99d99e99d99e59cb0e59ca8e5a49ce7a9bae4b8ade5ae88e68aa4e79d80e4bda0e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>