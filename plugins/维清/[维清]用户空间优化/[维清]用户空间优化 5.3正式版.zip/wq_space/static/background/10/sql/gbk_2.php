<?php

$background_10_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/10/images/2.jpg',0xc2ccc9abd4add2b0,0xd2b2d0edcac0bde7c9cfd2b2d3d0cee5c7a7b6e4bacdc4e3d2bbc4a3d2bbd1f9b5c4bba8a3acb5abd6bbd3d0c4e3cac7ced2b6c0d2bbcedeb6feb5c4c3b5b9e5a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>