<?php

$background_10_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/10/images/3.jpg',0xc3b5b9e5d4b0,0xc2feb2bdd4dac3b5b9e5d4b0d6d0a3acb1bbcfcabba8bacdb7d2b7bcd3b5b1a7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>