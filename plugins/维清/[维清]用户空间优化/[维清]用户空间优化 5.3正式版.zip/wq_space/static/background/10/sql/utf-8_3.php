<?php

$background_10_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/10/images/3.jpg',0xe78eabe791b0e59bad,0xe6bcabe6ada5e59ca8e78eabe791b0e59bade4b8adefbc8ce8a2abe9b29ce88ab1e5928ce88aace88ab3e68ba5e68ab1e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>