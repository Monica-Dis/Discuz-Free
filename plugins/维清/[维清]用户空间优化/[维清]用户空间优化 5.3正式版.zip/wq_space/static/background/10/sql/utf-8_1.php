<?php

$background_10_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/10/images/1.jpg',0xe58bbfe5bf98e5889de5bf83,0xe58bbfe5bf98e5889de5bf83efbc8ce696b9e5be97e5a78be7bb88e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>