<?php
   $background_10_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/10/images/4.jpg',0xe5a5b3e9a39ee8a18ce59198,0xe5a682e69e9ce4b88de58ebbe9818de58e86e4b896e997b4efbc8ce68891e4bbace5b0b1e4b88de79fa5e98193e4bb80e4b988e698afe68891e4bbace7b2bee7a59ee5928ce68385e6849fe79a84e5af84e68998e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;