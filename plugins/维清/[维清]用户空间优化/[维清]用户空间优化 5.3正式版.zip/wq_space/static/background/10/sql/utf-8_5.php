<?php

$background_10_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/10/images/5.jpg',0xe5a495e998b3e4bcbce68891,0xe6af8fe5bd93e68385e7bbaae4bd8ee890bde79a84e697b6e58099efbc8ce6a0bce5a496e5969ce6aca2e79c8be5a495e998b3e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>