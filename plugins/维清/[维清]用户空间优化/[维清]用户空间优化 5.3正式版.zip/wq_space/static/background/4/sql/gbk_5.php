<?php

$background_4_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/4/images/5.jpg',0xced2c3c7bde1bbe9b0c9,0xd3d0c4e3b2c5cdead5fba3aca1b6ced2c3c7bde1bbe9b0c9a1b7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>