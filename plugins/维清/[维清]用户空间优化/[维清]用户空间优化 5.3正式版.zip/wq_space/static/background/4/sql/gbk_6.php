<?php

$background_4_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/4/images/6.jpg',0xb0aed4dabdf8d0d0cab1,0xb0aed2bbd6b1b6bcd4daa3aca1b6b0aed4dabdf8d0d0cab1a1b7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>