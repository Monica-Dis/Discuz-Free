<?php

$background_4_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/4/images/3.jpg',0xe69599e5a082e59ca3e59cb0,0xe788b1efbc8ce4bb8ee8bf99e9878ce5bc80e5a78befbc8ce3808ae69599e5a082e59ca3e59cb0e3808be8a781e8af81e68891e4bbace79a84e788b1e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>