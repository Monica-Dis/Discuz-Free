<?php

$background_4_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/4/images/1.jpg',0xd0afcad6,0xbac3cfebd3ebc4e3b1bccff2d7eed2a3d4b6ccecbccaa3aca1b6d0afcad6a1b7d2bbc9fad2bbcac0a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>