<?php

$background_4_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/4/images/5.jpg',0xe68891e4bbace7bb93e5a99ae590a7,0xe69c89e4bda0e6898de5ae8ce695b4efbc8ce3808ae68891e4bbace7bb93e5a99ae590a7e3808be38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>