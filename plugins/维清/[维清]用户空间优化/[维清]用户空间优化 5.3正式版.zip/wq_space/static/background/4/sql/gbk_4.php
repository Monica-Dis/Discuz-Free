<?php

$background_4_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/4/images/4.jpg',0xd7eec3c0d4b8cdfb,0xb5c8b4fdc4e3ceaaced2b4a9c9cfbbe9c9b4b5c4c4c7d2bbcbb2bce4a3acd5e2cac7ced2b5c4a1b6d7eec3c0d4b8cdfba1b7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>