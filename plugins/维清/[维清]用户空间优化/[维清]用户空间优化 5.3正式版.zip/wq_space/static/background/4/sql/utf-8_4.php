<?php

$background_4_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/4/images/4.jpg',0xe69c80e7be8ee684bfe69c9b,0xe7ad89e5be85e4bda0e4b8bae68891e7a9bfe4b88ae5a99ae7bab1e79a84e982a3e4b880e79eace997b4efbc8ce8bf99e698afe68891e79a84e3808ae69c80e7be8ee684bfe69c9be3808be38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>