<?php

$background_4_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/4/images/1.jpg',0xe690bae6898b,0xe5a5bde683b3e4b88ee4bda0e5a594e59091e69c80e981a5e8bf9ce5a4a9e99985efbc8ce3808ae690bae6898be3808be4b880e7949fe4b880e4b896e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>