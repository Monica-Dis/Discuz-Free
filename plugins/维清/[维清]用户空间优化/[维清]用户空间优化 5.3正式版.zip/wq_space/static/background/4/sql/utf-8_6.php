<?php

$background_4_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/4/images/6.jpg',0xe788b1e59ca8e8bf9be8a18ce697b6,0xe788b1e4b880e79bb4e983bde59ca8efbc8ce3808ae788b1e59ca8e8bf9be8a18ce697b6e3808be38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>