<?php

$background_4_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/4/images/3.jpg',0xbdccccc3caa5b5d8,0xb0aea3acb4d3d5e2c0efbfaacabca3aca1b6bdccccc3caa5b5d8a1b7bcfbd6a4ced2c3c7b5c4b0aea1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>