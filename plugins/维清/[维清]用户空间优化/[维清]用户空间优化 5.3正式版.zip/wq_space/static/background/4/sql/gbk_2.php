<?php

$background_4_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/4/images/2.jpg',0xb4fdc4e3c8a1ced2,0xb2bbb9dcc4e3d4dac4c4a3acced2b6bcd4dad5e2a1b6b4fdc4e3c8a1ced2a1b7a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>