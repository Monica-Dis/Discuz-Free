<?php

$background_9_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/9/images/4.jpg',0xe68ea2e7b4a2e69caae79fa5,0xe8a681e4b988e8afbbe4b9a6efbc8ce8a681e4b988e69785e8a18cefbc8ce781b5e9ad82e5928ce8baabe4bd93efbc8ce5bf85e9a1bbe69c89e4b880e4b8aae59ca8e8b7afe4b88ae38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>