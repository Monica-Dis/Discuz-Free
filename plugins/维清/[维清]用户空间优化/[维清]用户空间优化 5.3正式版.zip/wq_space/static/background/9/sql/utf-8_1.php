<?php

$background_9_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/9/images/1.jpg',0xe8aea4e8af86e887aae5b7b1,0xe4b880e8be88e5ad90e983bde698afe59cbae4bfaee8a18cefbc8ce79fade79a84e698afe8b7afe98094efbc8ce995bfe79a84e698afe4babae7949fefbc81,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>