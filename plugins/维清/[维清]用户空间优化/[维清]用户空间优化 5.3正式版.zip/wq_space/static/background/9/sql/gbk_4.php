<?php

$background_9_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/9/images/4.jpg',0xccbdcbf7ceb4d6aa,0xd2aac3b4b6c1cae9a3acd2aac3b4c2c3d0d0a3acc1e9bbeabacdc9edcce5a3acb1d8d0ebd3d0d2bbb8f6d4dac2b7c9cfa1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>