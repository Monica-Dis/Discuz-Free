<?php

$background_9_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/9/images/1.jpg',0xc8cfcab6d7d4bcba,0xd2bbb1b2d7d3b6bccac7b3a1d0ded0d0a3acb6ccb5c4cac7c2b7cdbea3acb3a4b5c4cac7c8cbc9faa3a1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>