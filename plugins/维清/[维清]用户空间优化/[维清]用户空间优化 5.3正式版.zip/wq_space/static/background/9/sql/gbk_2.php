<?php

$background_9_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/9/images/2.jpg',0xd1b0c3d9b7bdcff2,0xc9eec9eeb5c4bbb0d2aac7b3c7b3b5c4cbb5a3acb3a4b3a4b5c4c2b7d2aabbd3bbf4b5d8d7dfa1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>