<?php

$background_9_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/9/images/2.jpg',0xe5afbbe8a785e696b9e59091,0xe6b7b1e6b7b1e79a84e8af9de8a681e6b585e6b585e79a84e8afb4efbc8ce995bfe995bfe79a84e8b7afe8a681e68ca5e99c8de59cb0e8b5b0e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>