<?php

$background_9_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/9/images/5.jpg',0xe694bee9a39ee887aae794b1,0xe697a0e99990e887aae794b1e4b8ade5818fe788b1e79a84e4b880e7a78de7baa6e69d9fefbc8ce5b0b1e698afe6a2a6e683b3e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>