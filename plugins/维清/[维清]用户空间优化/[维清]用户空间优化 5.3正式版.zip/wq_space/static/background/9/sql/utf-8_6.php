<?php

$background_9_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/9/images/6.jpg',0xe98083e981bfe7949fe6b4bb,0xe5afbbe4b880e69785e98094e5bf83e58aa8efbc8ce68bbee4b880e99d92e698a5e99d9ee587a1e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>