<?php

$background_9_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/9/images/3.jpg',0xe6849fe58f97e887aae784b6,0xe58ebbe69785e8a18ce590a7efbc8ce4b88de784b6e8bf99e4b8aae4b896e7958ce7be8ee5be97e5a4aae5af82e5af9ee38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>