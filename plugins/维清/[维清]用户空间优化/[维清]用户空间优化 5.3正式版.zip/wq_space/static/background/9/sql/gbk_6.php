<?php

$background_9_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/9/images/6.jpg',0xccd3b1dcc9fabbee,0xd1b0d2bbc2c3cdbed0c4b6afa3accab0d2bbc7e0b4bab7c7b7b2a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>