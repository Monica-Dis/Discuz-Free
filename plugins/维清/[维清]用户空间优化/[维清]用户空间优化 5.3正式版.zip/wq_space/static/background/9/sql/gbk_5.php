<?php

$background_9_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/9/images/5.jpg',0xb7c5b7c9d7d4d3c9,0xcedecfded7d4d3c9d6d0c6abb0aeb5c4d2bbd6d6d4bccaf8a3acbecdcac7c3cecfeba1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>