<?php

$background_9_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/9/images/3.jpg',0xb8d0cadcd7d4c8bb,0xc8a5c2c3d0d0b0c9a3acb2bbc8bbd5e2b8f6cac0bde7c3c0b5c3ccabbcc5c4afa1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>