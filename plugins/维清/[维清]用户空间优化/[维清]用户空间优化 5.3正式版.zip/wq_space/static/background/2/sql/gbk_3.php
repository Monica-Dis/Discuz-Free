<?php

$background_2_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/2/images/3.jpg',0xbce1b3d6,0xd7eec0a7c4d1b5c4cab1baf2a3acbecdcac7d7eebdd3bdfcb3c9b9a6b5c4cab1baf2a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>