<?php

$background_2_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/2/images/4.jpg',0xd0d0b6af,0xcfebd2bbc7a7b4ceb2bbc8e7c8a5d7f6d2bbb4cea3acbbaac0f6b5c4b5f8b5b9a3accaa4b9fdcedecebdc5c7bbb2a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>