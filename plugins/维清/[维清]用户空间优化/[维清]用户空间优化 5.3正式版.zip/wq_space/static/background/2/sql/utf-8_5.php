<?php

$background_2_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/2/images/5.jpg',0xe887aae4bfa1,0xe4b88de5bf85e4bbb0e69c9be588abe4babaefbc8ce887aae5b7b1e4baa6e698afe9a38ee699afe38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>