<?php

$background_2_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/2/images/3.jpg',0xe59d9ae68c81,0xe69c80e59bb0e99abee79a84e697b6e58099efbc8ce5b0b1e698afe69c80e68ea5e8bf91e68890e58a9fe79a84e697b6e58099e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>