<?php

$background_2_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/2/images/1.jpg',0xe4b990e8a782,0xe4bda0e694b9e58f98e4b88de4ba86e4ba8be5ae9eefbc8ce4bd86e698afe58fafe4bba5e694b9e58f98e68081e5baa6e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>