<?php

$background_2_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/2/images/5.jpg',0xd7d4d0c5,0xb2bbb1d8d1f6cdfbb1f0c8cba3acd7d4bcbad2e0cac7b7e7beb0a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>