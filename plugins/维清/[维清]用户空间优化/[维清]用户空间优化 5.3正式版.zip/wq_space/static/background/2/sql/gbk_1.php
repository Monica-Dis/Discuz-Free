<?php

$background_2_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/2/images/1.jpg',0xc0d6b9db,0xc4e3b8c4b1e4b2bbc1cbcac2cab5a3acb5abcac7bfc9d2d4b8c4b1e4ccacb6c8a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>