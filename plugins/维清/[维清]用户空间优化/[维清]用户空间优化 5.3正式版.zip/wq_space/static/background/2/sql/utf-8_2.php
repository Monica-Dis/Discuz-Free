<?php

$background_2_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/2/images/2.jpg',0xe998b3e58589,0xe5bd93e68891e4bbace99da2e5afb9e998b3e58589e697b6efbc8ce5b0b1e79c8be4b88de588b0e998b4e5bdb1e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>