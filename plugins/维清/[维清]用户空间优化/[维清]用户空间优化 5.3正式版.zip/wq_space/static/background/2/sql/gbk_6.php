<?php

$background_2_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/2/images/6.jpg',0xd3c2b8d2,0xd3c2b8d2a3acb2bbcac7b2bbbaa6c5c2a1a3b6f8cac7cbabcfa5b2fcb6b6c8b4d2c0c8bbc7b0d0d0a3a1,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>