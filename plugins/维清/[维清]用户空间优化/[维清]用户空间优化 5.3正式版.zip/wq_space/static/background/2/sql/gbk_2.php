<?php

$background_2_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/2/images/2.jpg',0xd1f4b9e2,0xb5b1ced2c3c7c3e6b6d4d1f4b9e2cab1a3acbecdbfb4b2bbb5bdd2f5d3b0a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>