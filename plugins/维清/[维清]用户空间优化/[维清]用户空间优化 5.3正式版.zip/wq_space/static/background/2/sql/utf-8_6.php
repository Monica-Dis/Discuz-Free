<?php

$background_2_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/2/images/6.jpg',0xe58b87e695a2,0xe58b87e695a2efbc8ce4b88de698afe4b88de5aeb3e68095e38082e8808ce698afe58f8ce8869de9a2a4e68a96e58db4e4be9de784b6e5898de8a18cefbc81,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>