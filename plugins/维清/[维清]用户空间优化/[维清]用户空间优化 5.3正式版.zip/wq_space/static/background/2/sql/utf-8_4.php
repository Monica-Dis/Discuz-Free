<?php

$background_2_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/2/images/4.jpg',0xe8a18ce58aa8,0xe683b3e4b880e58d83e6aca1e4b88de5a682e58ebbe5819ae4b880e6aca1efbc8ce58d8ee4b8bde79a84e8b78ce58092efbc8ce8839ce8bf87e697a0e8b093e5be98e5be8ae38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>