<?php

$background_3_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/3/images/5.jpg',0xe88ab1e5898de69c88e4b88b,0xe4bb8ae7949fe8aeb8e4bda0e88ab1e5898de69c88e4b88befbc8ce6b5a9e7809ae4babae6b5b7efbc8ce4b88ee4bda0e79bb8e98187e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>