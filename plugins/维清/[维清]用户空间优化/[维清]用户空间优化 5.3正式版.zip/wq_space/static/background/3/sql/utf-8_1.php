<?php

$background_3_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/3/images/1.jpg',0xe7ad89e5be85,0xe5ada6e4bc9ae7ad89e5be85efbc8ce7ad89e5be85e5b9b8e7a68fe79a84e588b0e69da5e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>