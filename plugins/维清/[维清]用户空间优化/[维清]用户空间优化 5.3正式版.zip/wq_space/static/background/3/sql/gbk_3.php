<?php

$background_3_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/3/images/3.jpg',0xd0c4d2d1d4b6d0d0,0xcac0bde7d6aecde2a3acd0c4d2d1d4b6d0d0a3acd2bbc7d0cfebc4eeb6bccac7cdbdc0cda1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>