<?php

$background_3_4 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','4','source/plugin/wq_space/static/background/3/images/4.jpg',0xd3d0c4e3d5e6bac3,0xd3d0c4e3b5c4cac0bde7d5e6c3c0bac3a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>