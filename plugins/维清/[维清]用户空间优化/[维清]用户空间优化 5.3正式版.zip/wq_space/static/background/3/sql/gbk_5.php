<?php

$background_3_5 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','5','source/plugin/wq_space/static/background/3/images/5.jpg',0xbba8c7b0d4c2cfc2,0xbdf1c9fad0edc4e3bba8c7b0d4c2cfc2a3acbac6e5abc8cbbaa3a3acd3ebc4e3cfe0d3f6a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>