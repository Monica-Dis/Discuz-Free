<?php

$background_3_3 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','3','source/plugin/wq_space/static/background/3/images/3.jpg',0xe5bf83e5b7b2e8bf9ce8a18c,0xe4b896e7958ce4b98be5a496efbc8ce5bf83e5b7b2e8bf9ce8a18cefbc8ce4b880e58887e683b3e5bfb5e983bde698afe5be92e58ab3e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>