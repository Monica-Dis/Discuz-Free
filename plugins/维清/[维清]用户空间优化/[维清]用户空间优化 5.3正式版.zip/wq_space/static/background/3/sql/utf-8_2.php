<?php

$background_3_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/3/images/2.jpg',0xe5afbbe4bda0,0xe8b79fe79d80e69c88e4baaee5afbbe689bee4bda0efbc8ce68891e79fa5e98193e4bda0e59ca8e7ad89e68891e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>