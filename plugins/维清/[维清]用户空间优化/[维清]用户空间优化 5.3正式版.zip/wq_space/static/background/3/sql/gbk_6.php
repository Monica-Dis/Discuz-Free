<?php

$background_3_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/3/images/6.jpg',0xcfa7c7e9cfa7d4b5,0xd4dac3cebbc3d3ebcfd6cab5d6d0d3ebc4e3cfe0d3f6a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>