<?php

$background_3_6 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','6','source/plugin/wq_space/static/background/3/images/6.jpg',0xe6839ce68385e6839ce7bc98,0xe59ca8e6a2a6e5b9bbe4b88ee78eb0e5ae9ee4b8ade4b88ee4bda0e79bb8e98187e38082,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>