<?php

$background_3_1 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','1','source/plugin/wq_space/static/background/3/images/1.jpg',0xb5c8b4fd,0xd1a7bbe1b5c8b4fda3acb5c8b4fdd0d2b8a3b5c4b5bdc0b4a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>