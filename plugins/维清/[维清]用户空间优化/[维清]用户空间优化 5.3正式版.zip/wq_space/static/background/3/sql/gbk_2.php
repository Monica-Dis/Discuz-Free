<?php

$background_3_2 = <<<EOF
INSERT INTO {$wq_space_background} VALUES ('','{$uid}','{$username}','{$classid}','2','source/plugin/wq_space/static/background/3/images/2.jpg',0xd1b0c4e3,0xb8fad7c5d4c2c1c1d1b0d5d2c4e3a3acced2d6aab5c0c4e3d4dab5c8ced2a1a3,'1','0','{$score}','{$free}','1','0','{$carousel}','{$dateline}');
EOF;
?>