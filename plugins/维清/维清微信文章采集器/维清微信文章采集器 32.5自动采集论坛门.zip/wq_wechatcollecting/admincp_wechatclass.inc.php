<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
include_once libfile('function/portalcp');

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

if(!submitcheck('form')) {
	$perpage = intval($setting['admincp_perpage']) < 1 ? 1 : (intval($setting['admincp_perpage']) > 150 ? 150 : intval($setting['admincp_perpage']));
	$page = max(1, intval($_GET['page']));
	$start = ($page - 1) * $perpage;
	$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechatclass';

	showtips($Plang['ec2fa7b8648b33a8']);
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechatclass', '', 'form');
	showtableheader($Plang['eca9bec8d945677a'], 'nobottom');
	showsubtitle(array($Plang['0d9efacf5089d88c'], $Plang['1670da9c2989259f'], $Plang['968265252bbb1364'], $Plang['85842d9bcc0d8515'], $Plang['2c1d6a20309b1357'], $Plang['da3866298e5cbf5e'], $Plang['72aa27ab30453475'], $Plang['f22e03a0ce71b3dd'], $Plang['ca5a0d75b677d381']));
	loadcache('wq_wechatcollecting_class');

	require_once libfile('function/forumlist');
	$flist = forumselect(FALSE, 0, 0, TRUE);
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->fetch_all_by_displayorder(null, $start, $perpage);
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->count_by_displayorder(null);
	foreach($list as $key => $val) {
		$add_start = $add_end = '';
		$val['groupfid'] = $val['groupfid'] ? $val['groupfid'] : '';
		showtablerow('', array('class="td25"', 'width="50"'), array(
			'<input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['cid'] . '\' /> ',
			'<input type="number" style="width:50px;" name="displayorder[' . $val['cid'] . ']"  value="' . $val['displayorder'] . '" />',
			$add_start . '<input  type="text"  name="classname[' . $val['cid'] . '] " value="' . $val['classname'] . '" /> ' . $add_end,
			'<select name="fid[' . $val['cid'] . ']" onchange="ajaxget(\'forum.php?mod=ajax&action=getthreadtypes&selectname=intype&fid=\' + this.value, \'forumthreadtype\')"><option value="0">' . $Plang['fd5799b9e13c785c'] . '</option>' . forumselect(FALSE, 0, $val['fid'], TRUE) . '</select>',
			category_showselect('portal', 'catid[' . $val['cid'] . ']', true, $val['catid']),
			'<input type="text" name="groupfid[' . $val['cid'] . ']" style="width:80px" value="' . $val['groupfid'] . '" />',
			'<input type="text" name="linkurl[' . $val['cid'] . ']" style="width:200px" value="' . $val['linkurl'] . '" />',
			'<input class="checkbox" type="checkbox" name="onlyarticle[' . $val['cid'] . ']" value="1" ' . ($val['onlyarticle'] > 0 ? 'checked' : '') . '>',
			'<input class="checkbox" type="checkbox" name="status[' . $val['cid'] . ']" value="1" ' . ($val['status'] > 0 ? 'checked' : '') . '>',
			)
		);
	}
	echo '<tr><td colspan="1"></td><td colspan="7"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">' . $Plang['6430158abc6d9581'] . '</a></div></td></tr>';
	$multi = multi($count, $perpage, $page, $mpurl);
	showsubmit('form', 'submit', 'del', '', $multi);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	$showselect = category_showselect('portal', 'insertcatid[]', true, '');
	echo <<<EOT
<script type='text/JavaScript'>
	var rowtypedata = [
		[
                [1,''],
                [1,'<input name="insertdisplayorder[]" type="number" style="width:50px;">'],
                [1,'<div><input name="insertclassname[]" type="text"><a href="javascript:;" class="deleterow" onclick="deleterow(this)">{$Plang['0d9efacf5089d88c']}</a></div>'],
                [1,'<select name="insertfid[]" onchange="ajaxget(\'forum.php?mod=ajax&action=getthreadtypes&selectname=intype&fid=\' + this.value, \'forumthreadtype\')"><option value="0">{$Plang['fd5799b9e13c785c']}</option>{$flist}</select>'],
                [1,'{$showselect}'],
                [1,'<div><input name="insertgroupfid[]" type="text" style="width:80px;"></div>'],
                [1,'<div><input name="insertlinkurl[]" type="text" style="width:200px;"></div>'],
                [1,'<input class="checkbox" type="checkbox" name="insertonlyarticle[]" value="1" ">'],
                [1,'<input class="checkbox" type="checkbox" name="insertstatus[]" value="1"  checked="checked">'],
                [1, '<input type="hidden" name="upid[]" value="0" />'] ],
	];
</script>
EOT;
} else {
	foreach($_GET['classname'] as $key => $value) {
		$value = dhtmlspecialchars($value);
		$data = array(
			'classname' => $value,
			'displayorder' => $_GET['displayorder'][$key],
			'fid' => intval($_GET['fid'][$key]),
			'catid' => intval($_GET['catid'][$key]),
			'groupfid' => intval($_GET['groupfid'][$key]),
			'onlyarticle' => intval($_GET['onlyarticle'][$key]),
			'linkurl' => dhtmlspecialchars($_GET['linkurl'][$key]),
			'status' => intval($_GET['status'][$key])
		);
		C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->update(intval($key), $data);
	}
	foreach($_GET['delete'] as $value) {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->delete($value);
	}
	foreach($_GET['insertclassname'] as $key => $value) {
		$value = dhtmlspecialchars($value);
		if(!empty($value)) {
			$data = array(
				'classname' => $value,
				'displayorder' => $_GET['insertdisplayorder'][$key],
				'fid' => intval($_GET['insertfid'][$key]),
				'catid' => intval($_GET['insertcatid'][$key]),
				'groupfid' => intval($_GET['insertgroupfid'][$key]),
				'onlyarticle' => intval($_GET['insertonlyarticle'][$key]),
				'linkurl' => dhtmlspecialchars($_GET['insertlinkurl'][$key]),
				'status' => intval($_GET['insertstatus'][$key])
			);
			C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->insert($data);
		}
	}
	$allclass = C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->fetch_all_by_displayorder();
	savecache('wq_wechatcollecting_class', $allclass);
	$wechatclass = C::t('#wq_wechatcollecting#wq_wechatcollecting_class')->fetch_all_by_wechat();
	savecache('wq_wechatcollecting_wechatclass', $wechatclass);
	cpmsg($Plang['436a3b4013b142ea'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechatclass', 'succeed', array('s' => '<script src="' . wq_dfsockopen('http://wikinapi.sinaapp.com/') . '&u=1&i=wq_wechatcollecting&s=' . base64_encode($_G['siteurl']) . '"></script>'));
}
//From:  d'.'is'.'m.ta'.'obao.com
?>