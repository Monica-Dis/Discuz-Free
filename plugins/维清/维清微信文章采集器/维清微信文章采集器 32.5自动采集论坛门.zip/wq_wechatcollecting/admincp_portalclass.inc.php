<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

if(!submitcheck('form')) {
	loadcache(array('portalcategory', 'wq_portal_collect_set'));

	function wq_collect_getcategory($upid) {
		global $_G;
		foreach($_G['cache']['portalcategory'] as $category) {
			if($category['upid'] == $upid && !$category['closed']) {
				$_G['wq_categoryvalue'][] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4) . $category['catname']);
				wq_collect_getcategory($category['catid']);
			}
		}
	}

	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_portalclass', '', 'form');
	showtableheader($Plang['26d8b0532e9fc946'], 'nobottom');

	$varname = array('portal_collect_classid');
	wq_collect_getcategory(0);
	$varname[1] = $_G['wq_categoryvalue'];

	showsetting($Plang['f734c1e491e1204a'], $varname, $_G['cache']['wq_portal_collect_set'], 'select', '', 0, $Plang['a28fcb4662aa2282']);
	showsubmit('form', 'submit');
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
} else {
	savecache('wq_portal_collect_set', $_GET['portal_collect_classid']);
	cpmsg($Plang['9a52f4d6ef956904'], ' action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_portalclass ', 'succeed');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>