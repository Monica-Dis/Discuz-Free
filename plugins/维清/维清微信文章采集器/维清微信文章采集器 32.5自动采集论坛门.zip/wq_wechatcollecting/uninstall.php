<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		$wechatlist = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_type(1);
		foreach($wechatlist as $key => $value) {
			@unlink(DISCUZ_ROOT . $value['headimage']);
		}

		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_article`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_article_addviews`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_article_content`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_attachment`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_class`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_log`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_poll`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_recommend_list`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_searchcache`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_seccodelog`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_temparticle`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_wechat`;
DROP TABLE IF EXISTS `pre_wq_wechatcollecting_wechat_addviews`;
EOF;
		runquery($sql);

		require_once libfile("function/cache");
		if(is_file(DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')) {
			require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';

			$hook = WeChatHook::getAPIHook('wq_wechatcollecting');

			$data = array(
				array('viewthread_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => '',
						'method' => ''
					)),
				array('sendreply_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => '',
						'method' => ''
					)),
			);
			WeChatHook::updateAPIHook($data);
		}
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_wechatcollecting.php");
		require_once 'config/loadfunc.php';
		wq_rmdir(DISCUZ_ROOT . "/data/attachment/wq_wechatcollecting/");
		wqdelsetting();
		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}

function wqdelsetting() {
	$memory = C::t('common_setting')->fetch('memory', true);
	if($memory) {
		unset($memory['wq_wechatcollecting_article'], $memory['wq_wechatcollecting_wechat']);
	}
	$skey = array('articlesearch', 'wechatsearch', 'wechatcollecting_cache_setting');

	if(is_array($memory) && count($memory) < 1) {
		array_unshift($skey, 'memory');
	} else {
		C::t('common_setting')->update('memory', $memory['memory']);
	}
	foreach($skey as $value) {
		DB::delete('common_setting', array('skey' => $value));
	}
	require_once libfile("function/cache");
	updatecache('setting');
	return true;
}

function wq_drop_content_splittable() {
	foreach(C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table() as $table) {
		list($tempkey, $tablename) = each($table);
		$tableid = substr($tablename, strrpos($tablename, '_') + 1);
		if(!preg_match('/^\d+$/', $tableid)) {
			continue;
		}
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->drop_table($tableid);
	}
	return true;
}
//From:  d'.'is'.'m.ta'.'obao.com
?>