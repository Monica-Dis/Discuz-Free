<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_sync.php 2016-8-15 18:24:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function sync_to_portal($title, $pic, $summary, $contents, $catid, $author, $username = '', $uid = '', $status = 0, $forbidcomment = '1') {
	global $_G;
	if($username == '') {
		$username = $_G['username'];
	}
	if($uid == '') {
		$uid = $_G['uid'];
	}

	$setarr = array(
		'title' => $title,
		'uid' => $uid,
		'pic' => $pic,
		'username' => $username,
		'htmlname' => 0,
		'idtype' => '0',
		'author' => $author,
		'dateline' => TIMESTAMP,
		'allowcomment' => $forbidcomment,
		'summary' => $summary,
		'catid' => intval($catid),
		'status' => $status,
		'highlight' => 0,
	);

	$aid = C::t('portal_article_title')->insert($setarr, 1);
	C::t('portal_article_content')->insert(array('aid' => $aid, 'idtype' => $setarr['idtype'], 'title' => '', 'content' => $contents, 'dateline' => TIMESTAMP));
	C::t('common_member_status')->update($uid, array('lastpost' => TIMESTAMP), 'UNBUFFERED');
	C::t('portal_category')->increase($setarr['catid'], array('articles' => 1));
	C::t('portal_category')->update($setarr['catid'], array('lastpublish' => TIMESTAMP));
	C::t('portal_article_count')->insert(array('aid' => $aid, 'catid' => $setarr['catid'], 'viewnum' => 1));
	return $aid;
}

function sync_to_forum($subject, $fid, $message, $addwechatname = 0, $isgroup = 0, $username = '', $uid = '', $status = 1, $setting = array()) {
	global $_G;
	$Plang = get_wq_wechatcollecting_setting_lang();

	include_once libfile('function/forum');
	include_once libfile('function/post');
	include_once libfile('function/stat');
	include_once libfile('function/cache');
	loadcache('forums');
	if(!empty($addwechatname)) {
		$subject = $Plang['160e734657c57a0e'] . $addwechatname . $Plang['62019e0d6ba657cd'] . $subject;
	}
	if($username == '') {
		$username = $_G['username'];
	}
	if($uid == '') {
		$uid = $_G['uid'];
	}
	$newthread = array(
		'fid' => $fid,
		'typeid' => 0,
		'author' => $username,
		'authorid' => $uid,
		'subject' => $subject,
		'isgroup' => $isgroup,
		'dateline' => $_G['timestamp'],
		'lastpost' => $_G['timestamp'],
		'lastposter' => $username,
		'status' => 192,
		'special' => intval($setting['special'])
	);
	if(!$status) {
		$newthread['displayorder'] = '-2';
	}
	$tid = C::t('forum_thread')->insert($newthread, true);
	useractionlog($_G['uid'], 'tid');
	C::t('common_member_field_home')->update($_G['uid'], array('recentnote' => $subject));

	$usesig = $status = 0;
	if($_G['group']['maxsigsize']) {
		$usesig = 1;
	}
	if(defined('IN_MOBILE')) {
		$status = 8;
	}

	$pid = insertpost(array(
		'fid' => $fid,
		'tid' => $tid,
		'first' => '1',
		'author' => $username,
		'authorid' => $uid,
		'subject' => $subject,
		'dateline' => $_G['timestamp'],
		'message' => $message,
		'usesig' => $usesig,
		'htmlon' => '1',
		'useip' => $_G['clientip'],
		'status' => $status,
	));

	updatestat('thread');
	updatepostcredits('+', $uid, 'post', $fid);
	$subject = str_replace("\t", ' ', $subject);
	$lastpost = "$tid\t" . $subject . "\t$_G[timestamp]\t" . $username;
	C::t('forum_forum')->update($fid, array('lastpost' => $lastpost));
	C::t('forum_forum')->update_forum_counter($fid, 1, 1, 1);
	$_G['forum'] = $_G['cache']['forums'][$fid];
	if($_G['forum']['type'] == 'sub') {
		C::t('forum_forum')->update($_G['forum']['fup'], array('lastpost' => $lastpost));
	}
	if($isgroup) {
		$today = date('Ymd', TIMESTAMP);
		$status = C::t('forum_groupcreditslog')->check_logdate($fid, $uid, $today);
		if(empty($status)) {
			C::t('forum_forum')->update_commoncredits($fid);
			C::t('forum_groupcreditslog')->insert(array('fid' => $fid, 'uid' => $uid, 'logdate' => $today), false, true);
		}
		$groupuser = C::t('forum_groupuser')->fetch_userinfo($uid, $fid);
		$num = intval($groupuser[$type]) + 1;
		C::t('forum_groupuser')->update_for_user($uid, $fid, $num, null, null);
	}
	return $tid;
}

function save_code_for_weixin($url) {
	$content = file_get_contents($url);
	update_cookie_for_weixin_by_http_response_header($http_response_header);
	file_put_contents("./data/cache/wq_weixin_code.png", $content);
}

function get_right_hot_new_article($limit, $title = '', $displayorder = 'date', $classid = '', $admrecommend = '', $isfirst = false, $wid = 0) {
	$right_list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, $limit, $title, $displayorder, $classid, $admrecommend, '', $isfirst, $wid, true);

	foreach($right_list as $key => $val) {
		$right_list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
	}

	return $right_list ? $right_list : null;
}

function get_recommed_wechat_list($siteid, $classid = 0, $limit = 2, $keyword = '', $date = "") {
	$recommed_wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_all_left_join_wechat($siteid, $classid, $limit, $keyword, $date);
	foreach($recommed_wechat as $key => $val) {
		$val['qrcode'] = wq_get_qrcode_by_wechatid($val['wechatid']);
		$val['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($val['headimage']);
		$val['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($val['wechatbgimg']);
		$recommed_wechat[$key] = $val;
	}
	return $recommed_wechat ? $recommed_wechat : null;
}

function get_nav_urlinfo($navinfo) {
	$id = 'id=' . $_GET['id'];
	$extid = '';
	if(strpos($id, ':') !== false) {
		$extid = explode(':', $id);
		$extid = $extid[0];
	}
	foreach($navinfo as $key => $value) {
		$temarr = null;
		$temarr = parse_url($value[1]);
		$temarr = explode('&', $temarr['query']);
		if(in_array($id, $temarr) || ($extid && in_array($extid, $temarr))) {
			$navinfo[$key]['ison'] = true;
			break;
		}
	}
	return $navinfo;
}

function wq_wechatcollecting_viewthread_updateviews($id, $type, $addviews, $table, $table_addveiws, $setting, &$dataobj = array()) {
	global $_G;
	if($table == 'wq_wechatcollecting_wechat' && $setting['wechatcollect_randomnum'] && $dataobj['favorites'] < $setting['wechatcollect_randomnum'][0]) {
		$dataobj['favorites'] = $favorites = mt_rand($setting['wechatcollect_randomnum'][0], $setting['wechatcollect_randomnum'][1]);
		C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($id, array('favorites' => $favorites));
	}
	if(!$setting['preventrefresh'] || $_G['cookie']['wq_' . $type] != 'wqid_' . $id) {
		if($setting['optimizeviews']) {
			if($addviews) {
				if($addviews < 100) {
					C::t('#wq_wechatcollecting#' . $table_addveiws)->update_by_tid($id);
				} else {
					if(!discuz_process::islocked('wqcollceting_update_view')) {
						$row = C::t('#wq_wechatcollecting#' . $table_addveiws)->fetch($id);
						C::t('#wq_wechatcollecting#' . $table_addveiws)->update($id, array('addviews' => 0));
						C::t('#wq_wechatcollecting#' . $table)->update_incrcase($id, array('views' => $row['addviews'] + 1));
						discuz_process::unlock('wqcollceting_update_view');
					}
				}
			} else {
				wq_wechatcollecting_updateviews_is_randomnum($id, $table, $setting, $dataobj);
				C::t('#wq_wechatcollecting#' . $table_addveiws)->insert(array('id' => $id, 'addviews' => 1), false, true);
			}
		} else {
			wq_wechatcollecting_updateviews_is_randomnum($id, $table, $setting, $dataobj);
			C::t('#wq_wechatcollecting#' . $table)->update_incrcase($id, array('views' => 1));
		}
	}
	dsetcookie('wq_' . $type, 'wqid_' . $id);
}

function wq_wechatcollecting_updateviews_is_randomnum($id, $table, $setting, &$dataobj) {
	$key = $table == 'wq_wechatcollecting_wechat' ? 'wechatviews_randomnum' : 'articleviews_randomnum';
	if($setting[$key] && $dataobj['views'] < $setting[$key][0]) {
		$dataobj['views'] = $views = mt_rand($setting[$key][0], $setting[$key][1]);
		C::t('#wq_wechatcollecting#' . $table)->update($id, array('views' => $views));
	}
}

function wq_mobcent_app_get_article_content($msg = '', $tid = 0, $aid = 0) {
	global $_G;
	$verhash = VERHASH;
	if(!$tid && !$aid) {
		return $msg;
	}
	$article = array();
	if($tid) {
		$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_tid($tid);
	} elseif($aid) {
		$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_aid($aid);
	}
	if($article) {
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/mhooks.class.php';
		$mhooks = new mobileplugin_wq_wechatcollecting();
		$msg = $mhooks->_article_content($article);

		$start = strpos($msg, 'wqwechat_articleview_con">');
		$msg = substr($msg, $start, -6);

		$msg = str_replace(array("\r\n", "\r", "\n", "wqwechat_articleview_con\">"), "", $msg);
		$msg = trim($msg);
		$html = <<<EOT
<script type="text/javascript" src="{$_G['siteurl']}source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{$verhash}"></script>
<script type="text/javascript" src="{$_G['siteurl']}source/plugin/wq_wechatcollecting/static/js/video.js?{$verhash}"></script>
EOT;
		$msg = $html . $msg;
	}
	return $msg;
}

function wq_check_page($start, $perpage, $maxpage = 0) {
	$maxpage = intval($maxpage);
	if($maxpage <= 0) {
		return;
	}
	$maxstart = $perpage * $maxpage;
	if($start < 0 || ($maxstart > 0 && $start >= $maxstart)) {
		showmessage('length_is_not_within_the_scope_of');
	}
}

function wq_two_array_orderby($array, $field, $order) {
	if(!$array || !$field) {
		return array();
	}
	$order = strtoupper($order);
	if(!in_array($order, array('ASC', 'DESC'))) {
		$order = 'DESC';
	}
	$sort = array(
		'direction' => 'SORT_' . $order,
		'field' => $field,
	);
	$arrSort = array();

	foreach($array AS $uniqid => $row) {
		foreach($row AS $key => $value) {
			$arrSort[$key][$uniqid] = $value;
		}
	}
	if($sort['direction']) {
		array_multisort($arrSort[$sort['field']], constant($sort['direction']), $array);
	}
	return $array;
}

function wq_get_wechat_qrcode_new($content) {
	$sg_qr_code = wqWechatApi_preg_match('/window.sg_qr_code="(.*)"/iUs', $content);
	if($sg_qr_code) {
		return 'https://mp.weixin.qq.com' . str_replace('&amp;', '&', wqWechatApiHtmlDecode($sg_qr_code));
	}

	$msg_link = wqWechatApi_preg_match('/var msg_link = "http:\/\/mp.weixin.qq.com\/s\?(.*)chksm=/iUs', $content);
	$tem_qrcode = 'https://mp.weixin.qq.com/mp/qrcode?scene=%s' . '&size=430&' . str_replace('&amp;', '&', wqWechatApiHtmlDecode($msg_link));
	$scene = 10000001;
	$qrcode = '';
	do {
		$qrcode = rtrim(sprintf($tem_qrcode, $scene), '&');
		$data = wq_dfsockopen($qrcode);
		$result = json_decode($data, true);
		if(!$result) {
			break;
		}
		$scene ++;
	} while($scene < 10000008);
	return $qrcode;
}

function wq_wechatcollecting_image_url_replace($content) {
	global $_G;

	if(strpos($content, "src=\"data/attachment/") !== FALSE || strpos($content, "src='data/attachment/") !== FALSE || strpos($content, "url(data/attachment/") !== FALSE) {
		$imgurlpre = strpos($_G['setting']['attachurl'], "http:") !== FALSE || strpos($_G['setting']['attachurl'], "https:") !== FALSE ? '' : $_G['siteurl'];
		if($_G['setting']['attachurl'] != "data/attachment/") {
			$content = str_replace(array("src=\"data/attachment/", "src='data/attachment/", "url(data/attachment/"), array("src=\"" . $imgurlpre . $_G['setting']['attachurl'], "src='" . $imgurlpre . $_G['setting']['attachurl'], "url(" . $imgurlpre . $_G['setting']['attachurl']), $content);
		} else {
			$content = str_replace(array("src=\"data/attachment/", "src='data/attachment/", "url(data/attachment/"), array("src=\"" . $imgurlpre . "data/attachment/", "src='" . $imgurlpre . "data/attachment/", "url(" . $imgurlpre . "data/attachment/"), $content);
		}
	}
	if(strpos($content, "src=\"wq_wechatcollecting/") !== FALSE || strpos($content, "src='wq_wechatcollecting/") !== FALSE || strpos($content, "url(wq_wechatcollecting/") !== FALSE) {
		$attachurl = wq_wechatcollecting_get_attachurl();
		$content = str_replace(array("src=\"wq_wechatcollecting/", "src='wq_wechatcollecting/", "url(wq_wechatcollecting/"), array("src=\"" . $attachurl . "wq_wechatcollecting/", "src='" . $attachurl . "wq_wechatcollecting/", "url(" . $attachurl . "wq_wechatcollecting/"), $content);
	}

	return $content;
}

function wq_wechatcollecting_edit_content_imgurl_replace($content, $setting, $flag = true) {
	global $_G;
	if(empty($content)) {
		return $content;
	}
	$imglist = wq_wechatcollecting_get_content_imgurl($content);
	$_replace = $_search = array();
	foreach($imglist as $value) {
		$value[2] = str_replace(array("'", "\""), "", $value[2]);
		if(strlen(trim($value[2])) && substr(trim($value[2]), 0, strlen($setting['qiniu_domain'])) == $setting['qiniu_domain']) {
			continue;
		}
		$_search[] = $value[2];
		if($flag) {
			$_replace[] = wq_wechatcollecting_headimg_and_bgimg_url($value[2]);
		} else {
			$_replace[] = str_replace(wq_wechatcollecting_get_attachurl(), '', $value[2]);
		}
	}
	$content = str_replace($_search, $_replace, $content);
	return $content;
}

function wq_wechatcollecting_get_pc_tpldir() {
	global $_G;

	$status = false;
	$tplid = $_G['setting']['styleid'];
	loadcache('style_' . $tplid);
	$tpl = $_G['cache']['style_' . $tplid];

	return $tpl['tpldir'];
}

function wq_parse_video($message = "") {



    $message = str_replace("&amp;","&",$message);

    $infos = wq_preg_match_all("/<iframe class=\"video_iframe rich_pages\"(.*)<\/iframe>/iUs", $message);


    if(!empty($infos)){

        $ifr = $newifrcode = array();

        foreach ($infos as $key =>  $info){

            $ifr[$key] = "<iframe class=\"video_iframe rich_pages\"{$info}</iframe>";

            $vid = wq_preg_match("/&vid=(.*)\">/iUs", $info);

            $ratio = wq_preg_match("/data-ratio=\"(.*)\"/iUs", $info);

            $json = wq_dfsockopen("https://mp.weixin.qq.com/mp/videoplayer?action=get_mp_video_play_url&vid={$vid}&x5=0&f=json");
            $arr = wq_jsondecode($json);

            $info = $arr['url_info'][0];

            $newifrcode[$key] = <<<EOT
		<div class="wq_video_layout"><iframe class="wq_video_iframe" src="{$info['url']}" data-ratio="{$ratio}" width="100%"></iframe></div>
EOT;
        }

        $message = str_replace($ifr, $newifrcode, $message);
    }

    return $message;
}
//From: dis'.'m.tao'.'bao.com
?>