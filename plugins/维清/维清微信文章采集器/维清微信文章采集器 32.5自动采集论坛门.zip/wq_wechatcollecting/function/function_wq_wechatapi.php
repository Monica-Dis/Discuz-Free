<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function wqWechatApiget_lang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_wechatcollecting/language");
	}
	include $_var_1;
	global $apilang;
	return $apilang;
}
function wqWechatApi_dfsockopen($_arg_0, $_arg_1 = array(), $_arg_2 = array(), $_arg_3 = '')
{
	global $_G;
	$_var_5 = wqWechatApiget_lang();
	$_arg_0 = $_arg_0 . http_build_query($_arg_1);
	if (strpos($_arg_0, "sogou.com")) {
		$_var_6 = wq_curl_for_sougou($_arg_0, '', false, $_arg_3);
		if (preg_match("/The URL has moved/iUs", $_var_6)) {
			$_var_7 = wqWechatApi_preg_match("/<a href=\"(.*)\">/iUs", $_var_6);
			$_var_7 = str_replace("http://", "https://", $_var_7);
			$_var_6 = wq_curl_for_sougou($_var_7);
		}
		if (preg_match("/302 Found/iUs", $_var_6)) {
			$_var_6 = wq_dfsockopen($_arg_0);
		}
		if (preg_match("/<img id=\"seccodeImage\"/iUs", $_var_6)) {
			$_var_8 = wq_preg_match("/<input type=\"hidden\" name=\"r\" id=\"from\" value=\"(.*)\" >/iUs", $_var_6);
			$_var_9 = wq_auto_input_seccode(true, $_var_8);
			if ($_var_9[0] == 1) {
				$_var_10 = urldecode(wqWechatApi_preg_match("/id=\"from\" value=\"(.*)\" >/iUs", $_var_6));
				$_var_10 = str_replace("http://weixin.sogou.com", "https://weixin.sogou.com", $_var_10);
				if (strpos($_var_10, "https://weixin.sogou.com") === false) {
					$_var_10 = "https://weixin.sogou.com" . $_var_10;
				}
				$_arg_3 = "https://weixin.sogou.com/antispider/?from=" . $_var_8 . '';
				$_var_6 = wq_curl_for_sougou($_var_10, '', false, $_arg_3);
			} else {
				$_var_11 = $_var_5["wq_sogou_seccode_" . $_var_9];
				if (!defined("IN_ADMINCP")) {
					showmessage($_var_11);
				} else {
					cpmsg($_var_11);
				}
			}
		}
		return $_var_6;
	}
	//d'.'is'.'m.ta'.'obao.com
	if (strpos($_arg_0, "mp.weixin.qq.com/profile")) {
		$_var_6 = wq_curl_for_weixin($_arg_0);
		if (preg_match("/<input class=\"weui_input frm_input\" id=\"input\"/iUs", $_var_6)) {
			$_var_9 = wq_auto_input_seccode(false);
			if ($_var_9 == 1) {
				$_var_6 = wq_dfsockopen($_arg_0, 0, $_arg_2, '', false);
			} else {
				if ($_var_9 == "-4") {
					$_var_9 = "-3";
				}
				$_var_11 = $_var_5["wq_sogou_seccode_" . $_var_9];
				if (!defined("IN_ADMINCP")) {
					showmessage($_var_11);
				} else {
					cpmsg($_var_11);
				}
			}
		}
		return $_var_6;
	}
	return wq_dfsockopen($_arg_0, 0, $_arg_2, '', false);
}
function proxy_dfsockopen($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = curl_init();
	curl_setopt($_var_3, CURLOPT_URL, $_arg_2);
	curl_setopt($_var_3, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_3, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($_var_3, CURLOPT_TIMEOUT, 3);
	curl_setopt($_var_3, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_arg_0, "CLIENT-IP:" . $_arg_0));
	curl_setopt($_var_3, CURLOPT_REFERER, "http://weixin.sogou.com/");
	curl_setopt($_var_3, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11");
	curl_setopt($_var_3, CURLOPT_PROXYAUTH, CURLAUTH_BASIC);
	curl_setopt($_var_3, CURLOPT_PROXY, $_arg_0);
	curl_setopt($_var_3, CURLOPT_PROXYPORT, $_arg_1);
	curl_setopt($_var_3, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
	$_var_4 = curl_exec($_var_3);
	curl_close($_var_3);
	return $_var_4;
}
//di'.'sm.t'.'aoba'.'o.com
function wqWechatApi_convert($_arg_0)
{
	if (is_array($_arg_0)) {
		foreach ($_arg_0 as $_var_1 => $_var_2) {
			$_arg_0[$_var_1] = diconv($_var_2, "UTF-8", CHARSET);
		}
	} else {
		$_arg_0 = diconv($_arg_0, "UTF-8", CHARSET);
	}
	return $_arg_0;
}
function wqWechatApi_preg_match($_arg_0, $_arg_1)
{
	preg_match($_arg_0, $_arg_1, $_var_2);
	return $_var_2[1];
}
function wqWechatApi_preg_match_all($_arg_0, $_arg_1)
{
	preg_match_all($_arg_0, $_arg_1, $_var_2);
	return $_var_2[1];
}
function wqWechatApi_filterScriptTag($_arg_0)
{
	return preg_replace("/(\\<[^\\<]*\\>|\r|\n|\\s|\\[.+?\\])/is", '', $_arg_0);
}
function wqWechatApi_filterLinkTag($_arg_0)
{
	$_var_1 = wqWechatApi_preg_match_all("/\\<link(.*)\\>/iUs", $_arg_0);
	foreach ($_var_1 as $_var_2) {
		$_var_3[] = "<link" . $_var_2 . ">";
	}
	return str_replace($_var_3, '', $_arg_0);
}
//dis'.'m.tao'.'bao.com
function wqWechatApigetInfoByKeywordType($_arg_0, $_arg_1 = "1", $_arg_2 = "1")
{
	$_var_3 = array("type" => $_arg_1, "query" => trim($_arg_0));
	if ($_arg_2 > 1) {
		$_var_3["page"] = $_arg_2;
	}
	$_var_4 = wqWechatApi_dfsockopen(WQWECHAT_SEARCH_API, $_var_3);
	$_var_4 = wqWechatApi_preg_match("/<body>(.*)<\\/body>/iUs", $_var_4);
	return wqWechatApi_convert($_var_4);
}
function wqWechatApigetListByKeywordType($_arg_0, $_arg_1 = "1", $_arg_2 = "1")
{
	$_var_3 = $_var_4 = wqWechatApigetInfoByKeywordType($_arg_0, $_arg_1, $_arg_2);
	if ($_arg_1 == "1") {
		$_var_5 = wqWechatApi_preg_match_all("/<!-- a -->(.*)<!-- z -->/iUs", $_var_3);
		foreach ($_var_5 as $_var_6) {
			$_var_7[] = wqWechatApigetWechatByStrForSearch($_var_6);
		}
	} elseif ($_arg_1 == "2") {
		$_var_5 = wqWechatApi_preg_match_all("/<!-- a -->(.*)<!-- z -->/iUs", $_var_3);
		foreach ($_var_5 as $_var_6) {
			$_var_7[] = wqWechatApigetArticleByStrForSearch($_var_6);
		}
	}
	return $_var_7;
}
//dis'.'m.t'.'ao'.'bao.com
function wqWechatApigetWechatByStrForSearch($_arg_0)
{
	$_var_1 = wqWechatApiget_lang();
	$_arg_0 = wqWechatApiHtmlDecode($_arg_0);
	$_var_2 = array("name" => "<p class=\"tit\">(.*)<\\/p>", "username" => "<label name=\"em_weixinhao\">(.*)<\\/label>", "intro" => "<dt>" . $_var_1["api_intro"] . "<\\/dt>(.*<\\/dl>)", "verify" => $_var_1["api_verify"] . "<\\/dt>(.*)<\\/dl>", "tmpurl" => "href=\"(.*)\"><span><\\/span><img", "openid" => "data-id=\"(.*)\"", "logo" => "class=\"shot-img\" src=\"(.*)\" onerror=", "dynamicinfo" => "class=\"line-s\"><\\/span>(.*)<\\/p>");
	foreach ($_var_2 as $_var_3 => $_var_4) {
		$_var_5 = wqWechatApi_preg_match("#" . $_var_4 . "#iUs", $_arg_0);
		$_var_6[$_var_3] = wqWechatApi_filterScriptTag($_var_5);
	}
	$_var_6["qrcode"] = wq_get_qrcode_by_wechatid($_var_6["username"]);
	$_var_6["tmpurl"] = str_replace("&amp;", "&", $_var_6["tmpurl"]);
	return $_var_6;
}
function wqWechatApiHtmlDecode($_arg_0)
{
	$_var_1 = 127;
	while ($_var_1 >= 0) {
		$_var_2[] = "\\x" . dechex($_var_1);
		$_var_3[] = chr($_var_1);
		$_var_1 = $_var_1 - 1;
	}
	return str_replace($_var_2, $_var_3, $_arg_0);
}
//d'.'i'.'sm.ta'.'o'.'bao.com
function wqWechatApiGetArticleListByWechatName($_arg_0, $_arg_1 = "2", $_arg_2 = "1")
{
	$_var_3 = urlencode(wq_diconv($_arg_0["name"]));
	$_var_4 = "https://weixin.sogou.com/weixin?type=2&s_from=input&query=" . $_var_3 . "&ie=utf8&_sug_=n&_sug_type_=";
	$_var_5 = "https://weixin.sogou.com/weixin?type=2&ie=utf8&query=" . $_arg_0["wechatid"] . '';
	if ($_arg_2 > 1) {
		$_var_5 = $_var_5 . ("&page=" . $_arg_2 . '');
	}
	$_var_6 = wqWechatApi_dfsockopen($_var_5, array(), array(), $_var_4);
	$_var_6 = wq_diconv($_var_6, "UTF-8", CHARSET);
	$_var_7 = wqWechatApi_preg_match_all("/<!-- a -->(.*)<!-- z -->/iUs", $_var_6);
	$_var_8 = $_var_9 = $_var_10 = array();
	foreach ($_var_7 as $_var_11) {
		$_var_12 = wqWechatApigetArticleByStrForSearch($_var_11);
		if ($_var_12["title"] && $_var_12["url"]) {
			$_var_12["cover"] = substr($_var_12["images"], strpos($_var_12["images"], "url=") + 4);
			$_var_12["datetime"] = $_var_12["dateline"];
			$_var_12["content_url"] = $_var_12["url"];
			$_var_8[$_var_12["dateline"]][] = $_var_12;
			$_var_10[] = $_var_12["dateline"];
		}
	}
	$_var_13 = array_unique($_var_10);
	krsort($_var_13);
	foreach ($_var_13 as $_var_14) {
		$_var_15 = $_var_8[$_var_14];
		$_var_16 = count($_var_8[$_var_14]) - 1;
		$_var_17 = $_var_16;
		while ($_var_17 >= 0) {
			$_var_9[] = $_var_15[$_var_17];
			$_var_17 = $_var_17 - 1;
		}
	}
	$_var_18 = array($_var_9, $_var_10);
	return $_var_18;
}
//d'.'is'.'m.tao'.'ba'.'o.com
function wqWechatApiGetArticleListByTmpUrl($_arg_0, $_arg_1 = false, $_arg_2 = false, $_arg_3 = 2, $_arg_4 = 1)
{
	if (empty($_arg_0["openid"])) {
		$_var_5 = wq_diconv($_arg_0["name"]);
		$_var_6 = "https://weixin.sogou.com/weixin?zhnss=1&type=1&ie=utf8&query=" . urlencode($_var_5);
		$_var_7 = wq_diconv(wq_jsondecode(wqWechatApi_dfsockopen($_var_6)), "UTF-8", CHARSET);
		if ($_var_7["weixinhao"] == $_arg_0["wechatid"]) {
			$_arg_0["openid"] = $_var_7["openid"];
		} else {
			$_var_8 = wqWechatApigetListByKeywordType($_arg_0["name"], "1", "1");
			foreach ($_var_8 as $_var_9 => $_var_10) {
				if ($_var_10["username"] == $_arg_0["wechatid"]) {
					$_arg_0["openid"] = $_var_10["username"];
				}
			}
		}
		if (!empty($_arg_0["id"]) && !empty($_arg_0["openid"])) {
			C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->update($_arg_0["id"], array("openid" => $_var_7["openid"]));
		}
	}
	if (empty($_arg_0["openid"])) {
		return array();
	}
	$_var_7 = wq_jsondecode(dfsockopen("https://weixin.sogou.com/websearch/weixin/pc/profile_url.jsp?openids=" . $_arg_0["openid"] . ''));
	$_var_11 = $_var_7["profile"][$_arg_0["openid"]];
	$_var_12 = wqWechatApi_dfsockopen($_var_11);
	$_var_13 = wqWechatApi_preg_match("#<img class=\"icon_verify success\"(.*)iv>#iUs", $_var_12);
	$_var_13 = wqWechatApi_convert(wqWechatApi_preg_match("#\">(.*)<\\/d#iUs", $_var_13));
	list($_var_14, $_var_15) = wqWechatApiGetArticleListByWechatName($_arg_0, $_arg_3, $_arg_4);
	$_var_16["articlelist"] = $_var_14;
	$_var_16["masstime"] = $_var_15;
	$_var_16["keyword_verify"] = $_var_13;
	if ($_arg_1) {
		$_var_16["wechatinfo"] = wqWechatApiGetWechatInfoByTmpUrlOrPageData($_var_11, $_var_12);
	}
	return $_var_16;
}
function wqWechatApiGetWechatInfoByTmpUrlOrPageData($_arg_0, $_arg_1 = '')
{
	if ($_arg_1 == '') {
		$_arg_1 = wqWechatApi_dfsockopen($_arg_0);
	}
	$_arg_1 = wqWechatApi_convert($_arg_1);
	$_var_2 = wqWechatApiget_lang();
	$_var_3 = array("name" => "<strong class=\"profile_nickname\">(.*)<\\/strong>", "username" => "<p class=\"profile_account\">" . $_var_2["api_wechatno_en"] . "(.*)<\\/p>", "intro" => "<div class=\"profile_desc_value\" title=\"(.*)\">", "verify" => "<div class=\"profile_desc_value\">(.*)<\\/div>");
	foreach ($_var_3 as $_var_4 => $_var_5) {
		$_var_6 = wqWechatApi_preg_match("#" . $_var_5 . "#iUs", $_arg_1);
		$_var_7[$_var_4] = wqWechatApi_filterScriptTag($_var_6);
	}
	$_var_7["qrcode"] = wq_get_qrcode_by_wechatid($_var_7["username"]);
	$_var_7["tmpurl"] = str_replace("&amp;", "&", $_arg_0);
	return $_var_7;
}
function wqWechatApiFormatArticleInfo($_arg_0, $_arg_1)
{
	$_var_2 = array("\\", "&amp;");
	$_var_3 = array('', "&");
	$_var_4 = str_replace($_var_2, $_var_3, $_arg_0["content_url"]);
	if (strpos($_var_4, "https://mp.weixin.qq.com") === false) {
		$_var_4 = "https://mp.weixin.qq.com" . $_var_4;
	}
	if ($_arg_1) {
		$_arg_0["content_url"] = wqWechatApigetArticleSourceUrlByTmpUrl($_var_4);
	} else {
		$_arg_0["content_url"] = $_var_4;
	}
	$_arg_0["source_url"] = str_replace($_var_2, $_var_3, $_arg_0["source_url"]);
	$_arg_0["cover"] = str_replace($_var_2, $_var_3, $_arg_0["cover"]);
	$_arg_0["title"] = wqWechatApi_convert($_arg_0["title"]);
	$_arg_0["digest"] = wqWechatApi_convert($_arg_0["digest"]);
	$_arg_0["content"] = wqWechatApi_convert($_arg_0["content"]);
	$_arg_0["author"] = wqWechatApi_convert($_arg_0["author"]);
	return $_arg_0;
}
function wqWechatApigetArticleSourceUrlByTmpUrl($_arg_0)
{
	$_var_1 = wqWechatApi_dfsockopen($_arg_0);
	$_var_2 = wqWechatApi_preg_match("/var msg_link = \"(.*)#rd\";/iUs", $_var_1) . "#rd";
	$_var_2 = wqWechatApiHtmlDecode($_var_2);
	if ($_var_2 == "#rd") {
		return $_arg_0;
	}
	return str_replace("&amp;", "&", $_var_2);
}
function wqWechatApigetArticleByStrForSearch($_arg_0)
{
	$_var_1 = strpos($_arg_0, "<li class=\"js-li\"");
	$_var_2 = array("url" => "<a target=\"_blank\" href=\"(.*)\"", "title" => "<h3>(.*)<\\/h3>", "summary" => "<\\/h3>(.*)<\\/p>", "openid" => "i=\"(.*)\"", "sourcename" => "\"s-p\" t=\"(.*)span", "images" => "<img src=\"(.*)\" onload=\"", "dateline" => "\"s-p\" t=\"(.*)\">", "logo" => "data-headimage=\"(.*)0\"");
	foreach ($_var_2 as $_var_3 => $_var_4) {
		$_var_5 = wqWechatApi_preg_match("#" . $_var_4 . "#iUs", $_arg_0);
		$_var_6[$_var_3] = str_replace("&amp;", "&", wqWechatApi_filterScriptTag($_var_5));
	}
	if ($_var_1 !== false) {
		$_var_6["summary"] = '';
	}
	$_var_6["sourcename"] = substr($_var_6["sourcename"], strpos($_var_6["sourcename"], ">") + 1, -1);
	$_var_6["wechatinfo"] = array("openid" => $_var_6["openid"]);
	$_var_6["url"] = "https://weixin.sogou.com" . $_var_6["url"];
	return $_var_6;
}
//http://t.cn/Aiux1Jx1
function wqWechatApigetArticleByOpenidPage($_arg_0, $_arg_1)
{
	$_var_2 = array("openid" => trim($_arg_0), "page" => intval($_arg_1));
	return WQWECHAT_ARTICLE_API . http_build_query($_var_2);
}
function wqWechatApigetArticleByOpenidPageEnc($_arg_0, $_arg_1)
{
	list($_var_2, $_var_3) = wqWechatApicurlGetContentByUrl($_arg_0 . "&page=" . intval($_arg_1));
	$_var_3 = wqWechatApi_json_decode($_var_3);
	$_var_3["filename"] = $_var_2;
	$_var_3 = wqWechatApi_xmlToArray($_var_3);
	return $_var_3;
}
function wqWechatApicurlGetContentByUrl($_arg_0)
{
	$_var_1 = tempnam("./data", "wqcoofile");
	$_var_2 = curl_init($_arg_0);
	curl_setopt($_var_2, CURLOPT_HEADER, 0);
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_COOKIEJAR, $_var_1);
	$_var_3 = curl_exec($_var_2);
	curl_close($_var_2);
	return array($_var_1, $_var_3);
}
function wqWechatApi_json_decode($_arg_0)
{
	$_var_1 = json_decode(str_replace("\n", '', $_arg_0), true);
	$_var_1["items"] = wqWechatApi_convert($_var_1["items"]);
	return $_var_1;
}
function wqWechatApi_xmlToArray($_arg_0)
{
	foreach ($_arg_0["items"] as $_var_1 => $_var_2) {
		$_var_3 = array("title", "title1", "url", "imglink", "headimage", "sourcename", "openid", "content", "content168", "date", "lastModified", "pagesize");
		foreach ($_var_3 as $_var_4) {
			$_var_5 = wqWechatApi_preg_match("#<" . $_var_4 . ">(.*)<\\/" . $_var_4 . ">#iUs", $_var_2);
			$_var_6[$_var_4] = str_replace(array("<![CDATA[", "]]>"), '', $_var_5);
		}
		$_arg_0["items"][$_var_1] = $_var_6;
	}
	return $_arg_0;
}
//http://t.cn/Aiux1012
function wqWechatApigetWechatByOpenid($_arg_0)
{
	$_var_1 = array("openid" => trim($_arg_0));
	$_var_2 = wqWechatApi_dfsockopen(WQWECHAT_WECHAT_API, $_var_1);
	$_var_3 = wqWechatApigetWechatByStr(wqWechatApi_convert($_var_2));
	$_var_3["openid"] = trim($_arg_0);
	return $_var_3;
}
function wqWechatApigetWechatByStr($_arg_0)
{
	$_var_1 = wqWechatApiget_lang();
	$_var_2 = array("name" => "<h3 id=\"weixinname\">(.*)<\\/h3>", "username" => "<span>" . $_var_1["api_wechatno"] . "(.*)<\\/span>", "intro" => $_var_1["api_intro_en"] . "<\\/span><span class=\"sp-txt\">(.*)<\\/span>", "verify" => $_var_1["api_verify"] . "<\\/span><span class=\"sp-txt\">(.*)<\\/span>", "openid" => '', "logo" => "<img style=\"width:34px;height:34px\" src=\"(.*)\" onerror=\"vrImgErr", "qrcode" => "140\" alt=\"\" src=\"(.*)\"><span class=\"_phoneimg\"><\\/span>");
	foreach ($_var_2 as $_var_3 => $_var_4) {
		$_var_5 = wqWechatApi_preg_match("#" . $_var_4 . "#iUs", $_arg_0);
		$_var_6[$_var_3] = wqWechatApi_filterScriptTag($_var_5);
	}
	return $_var_6;
}
function wq_get_proxy($_arg_0)
{
	global $_G;
	dsetcookie("wq_collect_proxy", '');
	dsetcookie("wq_collect_proxyport", '');
	$_var_2 = "http://192.168.0.101/dzutf/plugin.php?id=wq_ipshare&mod=api&fun=wq_get_proxy&url=" . urlencode($_arg_0);
	$_var_3 = wq_dfsockopen($_var_2, 0, '', '', false, '', 300);
	$_var_3 = json_decode($_var_3, true);
	if ($_var_3["errcode"] == "-1" || $_var_3["errcode"] == "-2" || $_var_3["errcode"] == "3") {
		return false;
	}
	$_var_4 = $_var_3["data"]["proxy"];
	$_var_5 = $_var_3["data"]["proxyport"];
	dsetcookie("wq_collect_proxy", $_var_4);
	dsetcookie("wq_collect_proxyport", $_var_5);
	if (empty($_var_4) || empty($_var_5)) {
		return false;
	}
	$_var_6 = proxy_dfsockopen($_var_4, $_var_5, $_arg_0);
	return $_var_6;
}
function wq_geturl_forsogou($_arg_0)
{
	$_var_1 = strpos($_arg_0, "/link?");
	if ($_var_1 === false) {
		return $_arg_0;
	}
	$_var_2 = substr($_arg_0, 0, $_var_1);
	$_arg_0 = substr($_arg_0, $_var_1);
	$_var_3 = strpos($_arg_0, "url=");
	$_var_4 = rand(0, 101);
	$_var_5 = strpos($_arg_0, "&k=");
	if (-1 !== $_var_3 && false === $_var_5) {
		$_var_3 = substr($_arg_0, $_var_3 + 4 + 21 + $_var_4, 1);
		$_arg_0 = $_arg_0 . "&k=" . $_var_4 . "&h=" . $_var_3;
	}
	return $_var_2 . $_arg_0;
}
function get_articleurl($_arg_0)
{
	$_var_1 = wq_preg_match_all("#url \\+= '(.*)';#iUs", $_arg_0);
	$_var_2 = implode($_var_1, '');
	return str_replace("@", '', $_var_2);
}
function wqWechatApigetArticleContentByUrl($_arg_0, $_arg_1 = false, $_arg_2 = false, $_arg_3 = true, $_arg_4 = '')
{
	global $_G;
	global $setting;
	$_arg_0 = wqWechatApiHtmlDecode($_arg_0);
	$_arg_0 = wq_geturl_forsogou($_arg_0);
	$_arg_4 = urlencode(wq_diconv($_arg_4));
	$_var_7 = "https://weixin.sogou.com/weixin?type=2&query=" . $_arg_4 . "&ie=utf8&s_from=input&_sug_=n&_sug_type_=1";
	$_var_8 = $_var_9 = wqWechatApi_dfsockopen($_arg_0, array(), array(), $_var_7);
	if (strpos($_var_8, "window.location.replace(url)") !== false) {
		$_arg_0 = get_articleurl($_var_8);
		$_var_8 = wqWechatApi_dfsockopen($_arg_0);
	}
	$_var_10 = wqWechatApi_preg_match("/<span id=\"copyright_logo\"(.*)<\\/span>/iUs", $_var_8) ? 1 : 0;
	$_var_11 = str_replace("||\"", '', wqWechatApi_preg_match("/var biz = \"\"(.*)\";/iUs", $_var_8));
	$_var_12 = wqWechatApi_preg_match("/var msg_link = \"(.*)#rd\";/iUs", $_var_8) . "#rd";
	$_var_8 = str_replace("data-src", "src", $_var_8);
	if (version_compare(PHP_VERSION, "7.0.0") >= 0 || $setting["transcoding_format"] == 2) {
		$_var_8 = diconv($_var_8, "utf-8");
	} else {
		$_var_13 = new Chinese("UTF-8", CHARSET, true);
		$_var_8 = $_var_13->Convert($_var_8);
	}
	if ($setting["keyword_filtration"] && $_arg_3) {
		preg_match("/(" . implode("|", $setting["keyword_filtration"]) . ")/i", $_var_8, $_var_14);
		if ($_var_14) {
			return "-1";
		}
	}
	//http://t.cn/Aiux1Qh0
	$_var_15 = wqWechatApiget_lang();
	$_var_16 = "/class=\"profile_meta_label\">" . $_var_15["api_wechat"] . "<\\/label>(.*)<\\/span>/iUs";
	$_var_17 = wqWechatApi_preg_match($_var_16, $_var_8);
	$_var_17 = trim(strip_tags(str_replace(" ", '', $_var_17)));
	if (!$_var_17 || strlen($_var_17) <= 2) {
		$_var_17 = wqWechatApi_preg_match("/var user_name = \"(.*)\";/iUs", $_var_8);
	}
	$_var_18 = wqWechatApi_preg_match_all("/<span class=\"profile_meta_value\">(.*)<\\/span>/iUs", $_var_8);
	$_var_19 = '';
	if ($_arg_1) {
		$_var_19 = wqWechatApi_preg_match("/<h2 class=\"rich_media_title\" id=\"activity-name\">(.*)<\\/h2>/iUs", $_var_8);
		$_var_20 = wqWechatApi_preg_match("/document.write\\(\"(.*)\"\\);/iUs", $_var_19);
		if ($_var_20 !== NULL) {
			$_var_19 = $_var_20;
		}
		$_var_19 = trim(strip_tags($_var_19));
	}
	if ($_arg_2) {
		$_var_21 = wqWechatApi_preg_match("/var ori_head_img_url = \"(.*)\"/iUs", $_var_8);
		$_var_22 = wqWechatApi_preg_match("/<strong class=\"profile_nickname\">(.*)<\\/strong>/iUs", $_var_8);
		$_var_23 = wqWechatApi_preg_match("/var msg_desc = \"(.*)\";/iUs", $_var_8);
		$_var_24 = wqWechatApi_preg_match("/var ct = \"(.*)\";/iUs", $_var_8);
		$_var_25 = wqWechatApi_preg_match("/var msg_cdn_url = \"(.*)\";/iUs", $_var_8);
	}
	$_var_26 = '';
	if (file_exists(DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/config/wq_read_original.php")) {
		$_var_27 = wqWechatApi_preg_match("#id=\"js_sg_bar\">(.*)</a>#iUs", $_var_8);
		if (strpos($_var_27, "http") !== false || strpos($_var_27, "https") !== false) {
			$_var_26 = trim($_var_27) . "</a>";
			$_var_26 = str_replace("&amp;", "&", $_var_26);
		}
	}
	$_var_8 = wqWechatApi_preg_match("#id=\"js_content\" style=\"visibility: hidden;\">(.*)<script#iUs", $_var_8);
	$_var_8 = wqWechatApi_filterLinkTag($_var_8);
	if ($_var_12 == "#rd") {
		$_var_12 = $_arg_0;
	}
	//http://t.cn/Aiux1ug8
	if ($setting["content_is_filtration_a"]) {
		$_var_8 = preg_replace("/<a [^>]*>/", '', $_var_8);
		$_var_8 = preg_replace("/<\\/a>/", '', $_var_8);
	}
	$_var_8 = wq_wechatcollecting_content_music_manage($_var_8);
	$_var_8 = substr($_var_8, 0, strripos($_var_8, "</div>"));
	$_var_8 = $_var_8 . $_var_26;
	$_var_12 = wqWechatApiHtmlDecode($_var_12);
	wq_hookscript("wq_wechatcollecting", "wqWechatApigetArticleContentByUrl", array("message" => $_var_8, "isreplace" => 1, "ac" => "replaceimgpre"));
	if ($_G["wq_wechatcollecting"]["pluginextend"]["wqWechatApigetArticleContentByUrl"]["replaceimgpre"]) {
		$_var_8 = $_G["wq_wechatcollecting"]["pluginextend"]["wqWechatApigetArticleContentByUrl"]["replaceimgpre"];
	}
	if ($setting["search_keyword"] && $setting["replace_keyword"]) {
		$_var_8 = str_replace($setting["search_keyword"], $setting["replace_keyword"], $_var_8);
	}
	$_var_8 = str_replace(array("Powered-by-", "Powered-by", "Powered by"), '', $_var_8);
	$_var_28 = array("content" => $_var_8, "url" => str_replace("&amp;", "&", $_var_12), "wechatid" => $_var_17, "intro" => $_var_18[1], "title" => trim($_var_19), "isoriginal" => $_var_10, "wechatbiz" => $_var_11);
	if ($_arg_2) {
		$_var_28["wechatlogo"] = $_var_21;
		$_var_28["wechatname"] = $_var_22;
		$_var_28["articleintro"] = $_var_23;
		$_var_28["articledate"] = $_var_24;
		$_var_28["articleimglink"] = $_var_25;
	}
	if (strpos($_var_9, "var idx = \"\" || \"\" || \"1\";") !== false) {
		$_var_28["isfirst"] = 1;
	} else {
		$_var_28["isfirst"] = 0;
	}
	return $_var_28;
}
function updateTmpurlAndGetThisUrlByWechatid($_arg_0, $_arg_1, $_arg_2 = false, $_arg_3 = false)
{
	$_var_4 = '';
	foreach ($_arg_1 as $_var_5 => $_var_6) {
		$_var_7 = C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->fetch_first_by_wechatid($_var_6["username"]);
		if ($_var_7) {
			C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->update($_var_7["id"], array("tmpurl" => $_var_6["tmpurl"]));
		}
		if (!$_arg_2 && $_var_6["username"] == $_arg_0) {
			$_var_4 = $_var_6["tmpurl"];
		}
		$_var_8[$_var_6["username"]] = $_var_6["tmpurl"];
	}
	if ($_arg_2) {
		return $_var_8;
	}
	if (empty($_var_4) && !$_arg_3) {
		$_var_9 = wqWechatApigetListByKeywordType($_arg_0, "1", 1);
		$_var_4 = updateTmpurlAndGetThisUrlByWechatid($_arg_0, $_var_9, false, true);
	}
	return $_var_4;
}
//http://t.cn/Aiux1eta
function updata_cron_available($_arg_0 = 0)
{
	$_var_1 = array("wq_wechatcollecting:cron_wq_collection.php", "wq_wechatcollecting:cron_wq_release_temp.php");
	foreach ($_var_1 as $_var_2) {
		$_var_3 = C::t("common_cron")->get_cronid_by_filename($_var_2);
		C::t("common_cron")->update($_var_3, array("available" => intval($_arg_0)));
	}
	C::t("common_setting")->update("wq_cron_available_status", $_arg_0);
	include_once libfile("function/cache");
	updatecache("setting");
	return true;
}
function update_sogou_newcontent($_arg_0, $_arg_1, $_arg_2 = 0)
{
	$_var_3 = trim(base64_decode($_arg_1));
	$_var_3 = substr($_var_3, 0, strpos($_var_3, "</div>"));
	if ($_var_3) {
		$_var_4["content"] = $_arg_1 = base64_encode($_var_3);
		C::t("#wq_wechatcollecting#wq_wechatcollecting_article_content")->update($_arg_2, $_arg_0, $_var_4);
	}
	return $_arg_1;
}
function wq_wechatcollecting_content_music_manage($_arg_0)
{
	$_var_1 = wqWechatApi_preg_match_all("#<audio style=\\\"width:100%\\\" src=\\\"(.*)\\\" controls=\\\"controls\\\"></audio>#iUs", $_arg_0);
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_1[$_var_2] = "<audio style=\"width:100%\" src=\"" . $_var_3 . "\" controls=\"controls\"></audio>";
	}
	$_arg_0 = str_replace($_var_1, '', $_arg_0);
	$_var_4 = wqWechatApi_preg_match_all("#<mpvoice(.*)</mpvoice>#iUs", $_arg_0);
	foreach ($_var_4 as $_var_2 => $_var_5) {
		$_var_6 = wqWechatApi_preg_match("#voice_encode_fileid=\"(.*)\"#iUs", $_var_5);
		$_var_7 = '';
		if ($_var_6) {
			$_var_7 = "<audio style=\"width:100%\" src=\"https://res.wx.qq.com/voice/getvoice?mediaid=" . $_var_6 . "\" controls=\"controls\"></audio>";
		}
		$_arg_0 = str_replace("<mpvoice" . $_var_5 . "</mpvoice>", "<mpvoice" . $_var_5 . "</mpvoice>" . $_var_7, $_arg_0);
	}
	$_var_8 = wqWechatApi_preg_match_all("#<qqmusic(.*)</qqmusic>#iUs", $_arg_0);
	foreach ($_var_8 as $_var_2 => $_var_5) {
		$_var_9 = wqWechatApi_preg_match("#audiourl=\"(.*)\"#iUs", $_var_5);
		if ($_var_9) {
			if (strpos($_var_9, "qqmusic.qq.com") !== false) {
				$_var_10 = wqWechatApi_preg_match("#mid=\"(.*)\"#iUs", $_var_5);
				$_var_11 = wqWechatApi_preg_match("#musicid=\"(.*)\"#iUs", $_var_5);
				$_var_12 = uniqid();
				$_var_13 = wq_dfsockopen("https://open.music.qq.com/fcgi-bin/fcg_music_get_song_info_weixin.fcg?song_id=" . $_var_11 . "&mid=" . $_var_10 . "&format=json&app_id=1034002693&app_key=cjjDaueOyPYRJFeTqG&device_id=weixin&file_type=mp3&qqmusic_fromtag=50&callback=get_song_info_back&t=" . $_var_12 . '');
				$_var_9 = wqWechatApi_preg_match("#\"play_url\": \"(.*)\",#iUs", $_var_13);
				$_var_14 = "<audio style=\"width:100%\" src=\"" . $_var_9 . "\" controls=\"controls\"></audio>";
				$_arg_0 = str_replace("<qqmusic" . $_var_5 . "</qqmusic>", "<qqmusic" . $_var_5 . "</qqmusic>" . $_var_14, $_arg_0);
			}
			if (strpos($_var_9, "kugou.com") !== false && ($_var_15 = wqWechatApi_preg_match("#otherid=\"(.*)\"#iUs", $_var_5))) {
				$_var_16 = wq_dfsockopen("https://mp.weixin.qq.com/mp/getkugousong?params=[{\"akey\":\"" . $_var_15 . "\"}]");
				$_var_16 = json_decode($_var_16, true);
				if ($_var_16["status"] == "1" && $_var_16["data"][0]["url"]) {
					$_var_17 = "<audio style=\"width:100%\" src=\"" . $_var_16["data"][0]["url"] . "\" controls=\"controls\"></audio>";
					$_arg_0 = str_replace("<qqmusic" . $_var_5 . "</qqmusic>", "<qqmusic" . $_var_5 . "</qqmusic>" . $_var_17, $_arg_0);
				}
			}
		}
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	ini_set("pcre.backtrack_limit", 9999999);
	$_var_0 = "success";
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}
	define("WQWECHAT_SEARCH_API", "https://weixin.sogou.com/weixin?");
	define("WQWECHAT_ARTICLE_API", "https://weixin.sogou.com/gzhjs?");
	define("WQWECHAT_WECHAT_API", "https://weixin.sogou.com/gzh?");
	define("WQWECHAT_HOT_ARTICLE_API", "https://weixin.sogou.com/pcindex/pc/pc_");
