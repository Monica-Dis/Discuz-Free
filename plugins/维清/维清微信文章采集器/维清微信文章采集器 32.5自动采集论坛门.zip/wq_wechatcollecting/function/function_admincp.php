<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_admincp.php 2015-12-28 21:11:17Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!function_exists('select_html')) {

	function select_html($array, $name, $selected, $all = true, $onchange = true) {
		if($onchange) {
			$onchange_html = 'onchange = "this.form.submit();"';
		}
		$html = '<select name = "' . $name . '" ' . $onchange_html . '>';
		if($all) {
			$html .= '<option value = "">&#20840;&#37096;</option>';
		}
		foreach($array as $key => $value) {
			if($selected === $key . '') {
				$selected_html = ' selected = "selected"';
			} else {
				$selected_html = '';
			}
			$html .= '<option value = "' . $key . '" ' . $selected_html . '>' . $value . '</option>';
		}

		return $html .= '</select>';
	}

}

if(!function_exists('radio_html')) {

	function radio_html($array, $name, $checked) {
		$html = '<ul>';

		foreach($array as $key => $value) {
			if($checked == $key) {
				$checked_html = 'checked';
			} else {
				$checked_html = '';
			}
			$html .= '<li class = "' . $checked_html . '"><input type = "radio" name = "' . $name . '" value = "' . $key . '" class = "radio" onchange = "this.form.submit();" id = "' . $key . '" ' . $checked_html . '/><label for = "' . $key . '" class = "vmiddle">' . $value . '</label>'
				. '</li>';
		}
		return $html .= '</ul>';
	}

}
if(!function_exists('text_html')) {

	function text_html($starttime, $endtime) {
		$html = "<input type=\"text\" id='starttime' name=\"starttime\" value=\"" . $starttime . "\" size=\"15\" onclick=\"showcalendar(event,this,true)\" readonly placeholder='&#24320;&#22987;&#26102;&#38388;'> ~
             <input type=\"text\" id='endtime' name=\"endtime\" value=\"" . $endtime . "\" size=\"15\" onclick=\"showcalendar(event,this,true)\" readonly placeholder='&#32467;&#26463;&#26102;&#38388;'> ";
		return $html;
	}

}
if(!function_exists('perpage_html')) {

	function perpage_html($perpage) {
		global $setting;
		$html = '<select name = "perpage" onchange = "this.form.submit();">'
			. '<option value = "' . $setting['admincp_perpage'] . '">' . $setting['admincp_perpage'] . '</option>';
		for($i = 1; $i < 10; $i ++) {
			$val = $i * 5;
			if($perpage == $val) {
				$selected_html = ' selected = "selected"';
			} else {
				$selected_html = '';
			}
			$html .= '<option value = "' . $val . '"' . $selected_html . '>' . $val . '</option>';
		}
		return $html .= '</select>';
	}

}
if(!function_exists('mradio_html')) {

	function mradio_html($array, $name, $checked, $href) {
		$html = '<input type="hidden" name="url" value="' . $href . '"/>'
			. '<ul onmouseover="altStyle(this);" class="mradio_html"><li  style="cursor:pointer"><input type="checkbox" name="chkall" class="checkbox"   onclick="checkAll(\'prefix\', this.form, \'delete\')"/>' . cplang('select_all') . ''
			. '</li></ul><ul class="mradio_html"     onmouseover="altStyle(this);">';
		foreach($array as $key => $value) {
			if($checked == $key) {
				$checked_html = 'checked';
			} else {
				$checked_html = '';
			}
			$html .= '<li class="' . $checked_html . '"><input type="radio" name="' . $name . '"  value="' . $key . '" class="radio" " id="' . $name . '_' . $key . '" ' . $checked_html . '/><label for="' . $name . '_' . $key . '" class="vmiddle">' . $value['lang'] . '</label>'
				. $value['html'] . '</li>';
		}
		return $html;
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>