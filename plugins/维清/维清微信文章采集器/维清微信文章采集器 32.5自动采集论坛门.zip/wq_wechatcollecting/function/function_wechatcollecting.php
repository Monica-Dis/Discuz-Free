<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function save_images($_arg_0, $_arg_1, $_arg_2 = "logo")
{
	global $_G;
	wq_hookscript("wq_wechatcollecting", "save_images", array("url" => $_arg_0, "type" => $_arg_2, "isreplace" => 1, "ac" => "returnimg"));
	if ($_G["wq_wechatcollecting"]["pluginextend"]["save_images"]["returnimg"]) {
		return $_G["wq_wechatcollecting"]["pluginextend"]["save_images"]["returnimg"];
	}
	$_var_4 = wq_wechatcollecting_get_attachdir();
	$_var_5 = $_var_4 . "wq_wechatcollecting/";
	$_var_6 = date("Ym");
	$_var_7 = date("d");
	$_var_5 = $_var_5 . $_arg_2 . "/" . $_var_6 . "/" . $_var_7;
	dmkdir($_var_5);
	$_var_8 = $_var_5 . "/" . $_arg_1 . ".jpg";
	$_arg_0 = substr($_arg_0, 0, 2) == "//" ? "http:" . $_arg_0 : $_arg_0;
	$_var_9 = dfsockopen($_arg_0, 0, array(), '', false);
	if (!$_var_9) {
		return NULL;
	}
	file_put_contents($_var_8, $_var_9);
	return str_replace($_var_4, '', $_var_8);
}
//http://t.cn/AiuxBLQV
function get_wechat_status($_arg_0)
{
	global $Plang;
	if ($_arg_0 == "0") {
		$_arg_0 = $Plang["fcce7c30276aa190"];
	} elseif ($_arg_0 == "1") {
		$_arg_0 = $Plang["be26c1af13da3cf9"];
	} elseif ($_arg_0 == "-1") {
		$_arg_0 = $Plang["b5d0d1b6c49b2665"];
	} else {
		$_arg_0 = $Plang["4930bcc2615700e9"];
	}
	return $_arg_0;
}
function get_select_options($_arg_0, $_arg_1 = '')
{
	$_var_2 = '';
	foreach ($_arg_0 as $_var_3 => $_var_4) {
		$_var_5 = '';
		if ($_arg_1 == $_var_3) {
			$_var_5 = " selected=\"selected\"";
		}
		$_var_2 = $_var_2 . ("<option value=\"" . $_var_3 . "\"  " . $_var_5 . "  >" . $_var_4 . "</option>");
	}
	return $_var_2;
}
function get_class_select($_arg_0, $_arg_1, $_arg_2, $_arg_3 = '', $_arg_4 = false, $_arg_5 = false)
{
	$_var_6 = '';
	if ($_arg_4) {
		$_var_6 = "onchange=\"this.form.submit();\"";
	}
	$_var_7 = $_arg_5 ? " style=\"display:none\"" : '';
	$_var_8 = "<select name=\"" . $_arg_0 . "\" id=\"" . $_arg_0 . "\"" . $_var_6 . $_var_7 . "><option value=\"\">" . $_arg_3 . "</option>";
	if (is_array($_arg_1)) {
		foreach ($_arg_1 as $_var_9 => $_var_10) {
			if (empty($_var_10["linkurl"])) {
				$_var_11 = '';
				if ($_arg_2 == $_var_9) {
					$_var_11 = " selected=\"selected\"";
				}
				$_var_8 = $_var_8 . ("<option value=\"" . $_var_9 . "\"  " . $_var_11 . "  >" . $_var_12 . $_var_10["classname"] . "</option>");
			}
		}
	}
	$_var_8 = $_var_8 . "</select>";
	return $_var_8;
}
//http://t.cn/AiuxBtT0
function get_class_select_article($_arg_0, $_arg_1, $_arg_2, $_arg_3 = '', $_arg_4 = false, $_arg_5 = false, $_arg_6 = false)
{
	global $_G;
	global $setting;
	loadcache("forums");
	$_var_9 = $_G["cache"]["forums"];
	$_var_10 = '';
	if ($_arg_4) {
		$_var_10 = "onchange=\"this.form.submit();\"";
	}
	$_var_11 = $_arg_6 ? " style=\"display:none\"" : '';
	$_var_12 = "<select name=\"" . $_arg_0 . "\" id=\"" . $_arg_0 . "\"" . $_var_10 . $_var_11 . "><option value=\"\" class=\"keywordcollect_html\">" . $_arg_3 . "</option>";
	if (is_array($_arg_1)) {
		foreach ($_arg_1 as $_var_13 => $_var_14) {
			if (empty($_var_14["linkurl"])) {
				$_var_15 = '';
				if ($_arg_5 && $setting["view_mode"] == "2") {
					if (!$_var_9[$_var_14["fid"]]["name"]) {
						$_var_15 = "(" . $_var_9[$setting["default_fid"]]["name"] . ")";
					} else {
						$_var_15 = "(" . $_var_9[$_var_14["fid"]]["name"] . ")";
					}
				}
				$_var_16 = '';
				if ($_arg_2 == $_var_13) {
					$_var_16 = " selected=\"selected\"";
				}
				$_var_12 = $_var_12 . ("<option value=\"" . $_var_13 . "\"  " . $_var_16 . "  >" . $_var_17 . $_var_14["classname"] . $_var_15 . "</option>");
			}
		}
	}
	$_var_12 = $_var_12 . "</select>";
	return $_var_12;
}
//http://t.cn/AiuxBMCp
function upload_images($_arg_0, $_arg_1, $_arg_2, $_arg_3)
{
	$_var_4 = new discuz_upload();
	$_var_4->init($_FILES[$_arg_0], "portal");
	$_var_5 = $_var_4->attach;
	$_var_6 = wq_wechatcollecting_get_attachurl();
	$_var_7 = array("status" => 0, "msgurl" => $_var_6 . "portal/" . $_var_5["attachment"], "msg" => "portal/" . $_var_5["attachment"], "name" => $_arg_0);
	if ($_var_5["size"] > $_arg_1 * 1024) {
		$_arg_2 = diconv($_arg_2, CHARSET, "UTF-8");
		$_var_7["msg"] = $_arg_2;
		$_var_7["status"] = "-1";
	}
	if (!$_var_5["isimage"]) {
		$_arg_3 = diconv($_arg_3, CHARSET, "UTF-8");
		$_var_7["msg"] = $_arg_3;
		$_var_7["status"] = "-1";
	}
	$_var_4->save();
	return $_var_7;
}
function save_article_images($_arg_0, $_arg_1, $_arg_2 = "article")
{
	$_var_3 = DISCUZ_ROOT . "/data/attachment/wq_wechatcollecting/";
	$_var_4 = date("Ym");
	$_var_5 = date("d");
	$_var_3 = $_var_3 . $_arg_2 . "/" . $_var_4 . "/" . $_var_5 . "/" . $_arg_1;
	dmkdir($_var_3);
	$_var_6 = $_var_3 . "/" . date("His") . strtolower(random(16)) . ".jpg";
	$_var_7 = wq_dfsockopen($_arg_0, 0, array(), '', false);
	file_put_contents($_var_6, $_var_7);
	return str_replace(DISCUZ_ROOT . "/", '', $_var_6);
}
//http://t.cn/AiuxBSZq
function wq_wechatcollecting_get_attachdir()
{
	global $_G;
	$_var_1 = !$_G["setting"]["attachdir"] ? DISCUZ_ROOT . "./data/attachment/" : $_G["setting"]["attachdir"];
	return $_var_1;
}
function wq_wechatcollecting_get_attachurl()
{
	global $_G;
	$_var_1 = !$_G["setting"]["attachurl"] ? "data/attachment/" : $_G["setting"]["attachurl"];
	$_var_2 = parse_url($_var_1);
	$_var_1 = !isset($_var_2["host"]) ? $_G["siteurl"] . $_var_1 : $_var_1;
	return $_var_1;
}
function save_article_images_new($_arg_0, $_arg_1, $_arg_2 = "article")
{
	global $_G;
	$_var_4 = wq_wechatcollecting_get_attachdir();
	$_var_5 = $_var_4 . "wq_wechatcollecting/";
	$_var_6 = date("Ym");
	$_var_7 = date("d");
	$_var_5 = $_var_5 . $_arg_2 . "/" . $_var_6 . "/" . $_var_7 . "/" . $_arg_1;
	dmkdir($_var_5);
	$_var_8 = $_var_5 . "/" . md5($_arg_0) . ".jpg";
	if (!is_file($_var_8)) {
		$_var_9 = wq_dfsockopen($_arg_0, 0, array(), '', false);
		if (!$_var_9) {
			return save_article_images_new($_arg_0, $_arg_1, $_arg_2);
		}
		file_put_contents($_var_8, $_var_9);
	}
	$_var_8 = str_replace($_var_4, '', $_var_8);
	return $_var_8;
}
//http://t.cn/AiuxBNHJ
function download_remote_images($_arg_0, $_arg_1, $_arg_2, $_arg_3 = 4)
{
	global $_G;
	wq_hookscript("wq_wechatcollecting", "download_remote_images", array("message" => $_arg_0, "isreplace" => 1, "ac" => "returnmsg"));
	if ($_G["wq_wechatcollecting"]["pluginextend"]["download_remote_images"]["returnmsg"]) {
		return $_G["wq_wechatcollecting"]["pluginextend"]["download_remote_images"]["returnmsg"];
	}
	set_time_limit(1800);
	$_arg_0 = download_background_image($_arg_0, $_arg_1, $_arg_2);
	$_var_5 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch_by_imgdownloaded($_arg_1);
	if ($_var_5["imgdownloaded"] == "3") {
		return $_arg_0;
	}
	if ($_var_5["imgdownloaded"] == "2") {
		$_var_6 = wq_wechatcollecting_get_content_imgurl($_arg_0);
		if (is_array($_var_6) && !empty($_var_6)) {
			$_var_7 = 0;
			foreach ($_var_6 as $_var_8) {
				$_var_8[2] = str_replace(array("'", "\""), '', $_var_8[2]);
				if (strlen(trim($_var_8[2])) && substr(trim($_var_8[2]), 0, strlen($_arg_2["qiniu_domain"])) == $_arg_2["qiniu_domain"]) {
					$_var_9 = trim(str_replace($_arg_2["qiniu_domain"] . "/", '', trim($_var_8[2])));
					if (strpos($_var_9, "wq_wechatcollecting") === 0) {
						$_var_10 = wq_wechatcollecting_get_attachdir();
						$_var_9 = $_var_10 . $_var_9;
					}
					if (file_exists($_var_9)) {
						@unlink($_var_9);
					} else {
						continue;
					}
					$_var_7 = $_var_7 + 1;
				}
			}
			if ($_var_7 == "0") {
				C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->update($_arg_1, array("imgdownloaded" => 1));
			} else {
				C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->update($_arg_1, array("imgdownloaded" => 3));
			}
		}
		return $_arg_0;
	}
	if ($_var_5["imgdownloaded"] == "0" && !discuz_process::islocked("download_remote_images_" . $_arg_1)) {
		$_var_11 = wq_wechatcollecting_get_content_imgurl($_arg_0);
		if (is_array($_var_11) && !empty($_var_11)) {
			foreach ($_var_11 as $_var_8) {
				if (strpos($_var_8[2], "wq_wechatcollecting") === false) {
					$_var_8[2] = str_replace(array("'", "\""), '', $_var_8[2]);
					$_var_12[] = array("0" => $_var_8[0], "1" => trim($_var_8[2]), "2" => trim($_var_8[3]));
				}
			}
		}
		if (empty($_var_12)) {
			C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->update($_arg_1, array("imgdownloaded" => 3));
			return $_arg_0;
		}
		foreach ($_var_12 as $_var_13) {
			if (strlen($_var_13[1]) && substr($_var_13[1], 0, 4) == "http") {
				$_var_14[] = $_var_13[1];
				$_var_15 = save_article_images_new($_var_13[1], $_arg_1);
				$_var_16[] = $_var_15;
			}
			preg_match_all("/src=[\\'|\"](.*?(?:[gif|jpg|jpeg|bmp|png]))[\\'|\"]/ism", $_var_13[2], $_var_17, PREG_SET_ORDER);
			if ($_var_17) {
				$_var_14[] = $_var_17[0][1];
				$_var_16[] = $_var_15;
			}
		}
		$_var_18 = $_arg_1;
		$_var_19 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch($_arg_1);
		if ($_arg_1 == $_var_19["tid"]) {
			$_var_18 = $_arg_1 + $_var_19["tid"];
		}
		foreach ($_var_14 as $_var_20 => $_var_8) {
			$_var_21[] = $_var_8 . "\"";
			$_var_22 = $_var_8;
			if (strpos($_var_8, "mmbiz.qpic.cn") !== false) {
				$_var_22 = substr($_var_8, 0, strripos($_var_8, "/") + 1);
			}
			$_var_23 = "\" articleid=\"%s\" data_ysrc=\"%s\" zoomfile=\"%s\" file=\"%s\"";
			$_var_24[] = $_var_8 . sprintf($_var_23, $_var_18, $_var_22, $_var_22, $_var_22);
		}
		$_arg_0 = str_replace($_var_21, $_var_24, $_arg_0);
		$_arg_0 = str_replace($_var_14, $_var_16, $_arg_0);
		$_var_25 = array_unique($_var_16);
		foreach ($_var_25 as $_var_20 => $_var_13) {
			$_var_26 = array("articleid" => $_arg_1, "type" => 1, "imageurl" => $_var_13);
			C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->insert($_var_26);
		}
		C::t("#wq_wechatcollecting#wq_wechatcollecting_article_content")->update_content_by_articleid($_arg_1, base64_encode($_arg_0), wq_wechatcollecting_get_article_contenttableid($_arg_1));
		C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->update($_arg_1, array("imgdownloaded" => 1));
		discuz_process::unlock("download_remote_images_" . $_arg_1);
		return $_arg_0;
	}
	$_var_27 = C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->fetch_all_imageurl_by_articleid($_arg_1);
	if ($_var_5["imgdownloaded"] == "1") {
		if (!discuz_process::islocked("save_article_images_wechat_qiniu_" . $_arg_1) && $_arg_2["is_use_qiniu"] == 1 && !empty($_arg_2["qiniu_sk"]) && !empty($_arg_2["qiniu_domain"]) && !empty($_arg_2["qiniu_ak"]) && !empty($_arg_2["qiniu_bucket"])) {
			$_var_28 = 0;
			$_var_29 = 0;
			foreach ($_var_27 as $_var_20 => $_var_13) {
				if ($_var_13["type"] == "1") {
					$_var_28 = $_var_28 + $_var_13["type"];
					if ($_var_28 >= $_arg_3) {
						$_var_29 = 1;
					} else {
						$_var_14[] = $_var_13["imageurl"];
						$_var_16[] = wqQqApi_save_article_images_wechat_qiniu($_var_13["imageurl"], $_arg_1, $_arg_2, $_var_13["id"]);
					}
				}
			}
			$_arg_0 = str_replace($_var_14, $_var_16, $_arg_0);
			C::t("#wq_wechatcollecting#wq_wechatcollecting_article_content")->update_content_by_articleid($_arg_1, base64_encode($_arg_0), wq_wechatcollecting_get_article_contenttableid($_arg_1));
			if ($_var_29 == "0") {
				C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->update($_arg_1, array("imgdownloaded" => 2));
			}
			discuz_process::unlock("save_article_images_wechat_qiniu_" . $_arg_1);
			return $_arg_0;
		}
		return $_arg_0;
	}
	return $_arg_0;
}
//https://c.tb.cn/c.0LzFam
function wqQqApi_save_article_images_wechat_qiniu($_arg_0, $_arg_1, $_arg_2, $_arg_3)
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/functions.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Auth.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Zone.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Storage/UploadManager.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Processing/ImageUrlBuilder.php";
	$_var_4 = $_arg_2["qiniu_ak"];
	$_var_5 = $_arg_2["qiniu_sk"];
	$_var_6 = new wqAuth($_var_4, $_var_5);
	$_var_7 = $_arg_2["qiniu_bucket"];
	$_var_8 = $_var_6->uploadToken($_var_7);
	C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->update($_arg_3, array("type" => 3));
	$_var_9 = $_arg_0;
	if (strpos($_arg_0, "wq_wechatcollecting") === 0) {
		$_var_10 = wq_wechatcollecting_get_attachdir();
		$_var_9 = $_var_10 . $_arg_0;
	}
	$_var_11 = fopen($_var_9, "rb");
	if ($_var_11 === false) {
		return $_arg_0;
	}
	$_var_12 = fstat($_var_11);
	$_var_13 = fread($_var_11, $_var_12["size"]);
	fclose($_var_11);
	if ($_var_13 === false) {
		return $_arg_0;
	}
	$_var_14 = $_var_9;
	$_var_15 = $_arg_0;
	$_var_16 = new wqUploadManager();
	list($_var_17, $_var_18) = $_var_16->putFile($_var_8, $_var_15, $_var_14);
	if ($_var_18 !== NULL) {
		return $_arg_0;
	}
	return $_arg_2["qiniu_domain"] . "/" . $_var_17["key"];
}
function wq_wechatcollecting_replace_src_add_datasrc($_arg_0)
{
	preg_match_all("/( src)=([\"|']?)([^\"'>]+.(jpg|JPG|jpeg|JPEG|gif|GIF|png|PNG)[\"'])/i", $_arg_0, $_var_1, PREG_SET_ORDER);
	if (is_array($_var_1) && !empty($_var_1)) {
		foreach ($_var_1 as $_var_2) {
			$_var_3[] = array("0" => trim($_var_2[0]), "1" => trim($_var_2[3]));
		}
	}
	$_var_4 = array("class=\"", "class='");
	$_var_5 = array("class=\"lazyload-home ", "class='lazyload-home ");
	foreach ($_var_3 as $_var_6) {
		$_var_4[] = $_var_6[0];
		$_var_5[] = str_replace("src", "src=\"./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg\" class=\"lazyload-home\" wqdata-src", $_var_6[0]);
	}
	$_var_4 = array_unique($_var_4);
	$_var_5 = array_unique($_var_5);
	$_var_7 = str_replace($_var_4, $_var_5, $_arg_0);
	$_var_7 = str_replace("lazyload-home video_iframe", "video_iframe", $_var_7);
	return $_var_7;
}
function upload_images_to_attachment_by_path($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	require_once libfile("class/image");
	require_once libfile("function/post");
	if (is_array($_arg_0) && !empty($_arg_0)) {
		$_var_4 = new discuz_upload();
		$_var_5 = array();
		foreach ($_arg_0 as $_var_6) {
			$_var_7 = md5($_var_6);
			if (strlen($_var_6)) {
				if (!isset($_var_8[$_var_7])) {
					$_var_8[$_var_7] = $_var_6;
					$_var_9["ext"] = "jpg";
					$_var_10 = '';
					$_var_10 = file_get_contents($_var_6);
					if (empty($_var_10)) {
						continue;
					}
					$_var_11 = explode("/", $_var_6);
					$_var_9["name"] = trim($_var_11[count($_var_11) - 1]);
					$_var_9["thumb"] = '';
					$_var_9["isimage"] = $_var_4->is_image_ext($_var_9["ext"]);
					$_var_9["extension"] = $_var_4->get_target_extension($_var_9["ext"]);
					$_var_9["attachdir"] = $_var_4->get_target_dir("forum");
					$_var_9["attachment"] = $_var_9["attachdir"] . $_var_4->get_target_filename("forum") . "." . $_var_9["extension"];
					$_var_9["target"] = getglobal("setting/attachdir") . "./forum/" . $_var_9["attachment"];
					if (!@($_var_12 = fopen($_var_9["target"], "wb"))) {
						continue;
					}
					flock($_var_12, 2);
					fwrite($_var_12, $_var_10);
					fclose($_var_12);
					if (!$_var_4->get_image_info($_var_9["target"])) {
						@unlink($_var_9["target"]);
						continue;
					}
					$_var_9["size"] = filesize($_var_9["target"]);
					$_var_4->attach = $_var_9;
					$_var_13 = $_var_14 = 0;
					if ($_var_4->attach["isimage"]) {
						if ($_G["setting"]["thumbsource"] && $_G["setting"]["sourcewidth"] && $_G["setting"]["sourceheight"]) {
							$_var_15 = new image();
							$_var_13 = $_var_15->Thumb($_var_4->attach["target"], '', $_G["setting"]["sourcewidth"], $_G["setting"]["sourceheight"], 1, 1);
							if ($_var_13) {
								$_var_13 = 1;
							} else {
								$_var_13 = 0;
							}
							$_var_14 = $_var_15->imginfo["width"];
							$_var_4->attach["size"] = $_var_15->imginfo["size"];
						}
						if ($_G["setting"]["thumbstatus"]) {
							$_var_15 = new image();
							$_var_13 = $_var_15->Thumb($_var_4->attach["target"], '', $_G["setting"]["thumbwidth"], $_G["setting"]["thumbheight"], $_G["setting"]["thumbstatus"], 0);
							if ($_var_13) {
								$_var_13 = 1;
							} else {
								$_var_13 = 0;
							}
							$_var_14 = $_var_15->imginfo["width"];
						}
						if ($_G["setting"]["thumbsource"] || !$_G["setting"]["thumbstatus"]) {
							list($_var_14) = @getimagesize($_var_4->attach["target"]);
						}
						if ($_G["setting"]["watermarkstatus"] && empty($_G["forum"]["disablewatermark"])) {
							$_var_15 = new image();
							$_var_15->Watermark($_var_9["target"], '', "forum");
							$_var_4->attach["size"] = $_var_15->imginfo["size"];
						}
					}
					//https://c.tb.cn/c.0LN6GB
					$_var_16 = getattachnewaid();
					$_var_5[$_var_16] = array();
					$_var_17 = array("aid" => $_var_16, "dateline" => $_G["timestamp"], "filename" => $_var_4->attach["name"], "filesize" => $_var_4->attach["size"], "attachment" => $_var_4->attach["attachment"], "isimage" => $_var_4->attach["isimage"], "uid" => $_G["uid"], "thumb" => $_var_13, "remote" => "0", "width" => $_var_14);
					C::t("forum_attachment_unused")->insert($_var_17);
				}
			}
		}
	}
	if (is_array($_var_5) && !empty($_var_5)) {
		updateattach(false, $_arg_1, $_arg_2, $_var_5);
		foreach ($_var_5 as $_var_18 => $_var_19) {
			$_var_20 = $_var_18;
			$_var_21 = C::t("forum_attachment_n")->fetch("tid:" . $_arg_1, $_var_20);
			$_var_21 = daddslashes($_var_21);
			C::t("forum_threadimage")->insert(array("tid" => $_arg_1, "attachment" => $_var_21["attachment"], "remote" => $_var_21["remote"]));
			wq_setthreadcover($_arg_2, $_arg_1, $_var_20);
		}
	}
}
function upload_images_to_attachment_by_portal($_arg_0, $_arg_1)
{
	global $_G;
	require_once libfile("class/image");
	require_once libfile("function/post");
	if (is_array($_arg_0) && !empty($_arg_0)) {
		$_var_3 = new discuz_upload();
		foreach ($_arg_0 as $_var_4) {
			$_var_5 = md5($_var_4);
			if (strlen($_var_4)) {
				if (!isset($_var_6[$_var_5])) {
					$_var_6[$_var_5] = $_var_4;
					$_var_7["ext"] = "jpg";
					$_var_8 = '';
					$_var_8 = file_get_contents($_var_4);
					if (empty($_var_8)) {
						continue;
					}
					$_var_9 = explode("/", $_var_4);
					$_var_7["name"] = trim($_var_9[count($_var_9) - 1]);
					$_var_7["thumb"] = '';
					$_var_7["isimage"] = $_var_3->is_image_ext($_var_7["ext"]);
					$_var_7["extension"] = $_var_3->get_target_extension($_var_7["ext"]);
					$_var_7["attachdir"] = $_var_3->get_target_dir("portal");
					$_var_7["attachment"] = $_var_7["attachdir"] . $_var_3->get_target_filename("portal") . "." . $_var_7["extension"];
					$_var_7["target"] = getglobal("setting/attachdir") . "./portal/" . $_var_7["attachment"];
					if (!@($_var_10 = fopen($_var_7["target"], "wb"))) {
						continue;
					}
					flock($_var_10, 2);
					fwrite($_var_10, $_var_8);
					fclose($_var_10);
					if (!$_var_3->get_image_info($_var_7["target"])) {
						@unlink($_var_7["target"]);
						continue;
					}
					$_var_7["size"] = filesize($_var_7["target"]);
					$_var_3->attach = $_var_7;
					$_var_11 = 0;
					if ($_var_3->attach["isimage"]) {
						if ($_G["setting"]["thumbsource"] && $_G["setting"]["sourcewidth"] && $_G["setting"]["sourceheight"]) {
							$_var_12 = new image();
							$_var_11 = $_var_12->Thumb($_var_3->attach["target"], '', $_G["setting"]["sourcewidth"], $_G["setting"]["sourceheight"], 1, 1);
							if ($_var_11) {
								$_var_11 = 1;
							} else {
								$_var_11 = 0;
							}
							$_var_3->attach["size"] = $_var_12->imginfo["size"];
						}
						if ($_G["setting"]["thumbstatus"]) {
							$_var_12 = new image();
							$_var_11 = $_var_12->Thumb($_var_3->attach["target"], '', $_G["setting"]["thumbwidth"], $_G["setting"]["thumbheight"], $_G["setting"]["thumbstatus"], 0);
							if ($_var_11) {
								$_var_11 = 1;
							} else {
								$_var_11 = 0;
							}
						}
						if ($_G["setting"]["watermarkstatus"] && empty($_G["portal"]["disablewatermark"])) {
							$_var_12 = new image();
							$_var_12->Watermark($_var_7["target"], '', "portal");
							$_var_3->attach["size"] = $_var_12->imginfo["size"];
						}
					}
					$_var_13 = array("aid" => $_arg_1, "dateline" => $_G["timestamp"], "filename" => $_var_3->attach["name"], "filesize" => $_var_3->attach["size"], "attachment" => $_var_3->attach["attachment"], "isimage" => $_var_3->attach["isimage"], "uid" => $_G["uid"], "thumb" => $_var_11, "remote" => "0", "filetype" => "jpg");
					C::t("portal_attachment")->insert($_var_13);
				}
			}
		}
	}
}
//https://c.tb.cn/c.0Lzkgo
function wq_setthreadcover($_arg_0, $_arg_1 = 0, $_arg_2 = 0, $_arg_3 = 0, $_arg_4 = '')
{
	global $_G;
	$_var_6 = 0;
	$_G["setting"]["forumpicstyle"] = unserialize($_G["setting"]["forumpicstyle"]);
	if (!intval($_G["setting"]["forumpicstyle"]["thumbwidth"])) {
		$_G["setting"]["forumpicstyle"]["thumbwidth"] = 200;
	} else {
		$_G["setting"]["forumpicstyle"]["thumbheight"] = intval($_G["setting"]["forumpicstyle"]["thumbheight"]);
	}
	if (!intval($_G["setting"]["forumpicstyle"]["thumbheight"])) {
		$_G["setting"]["forumpicstyle"]["thumbheight"] = 0;
	} else {
		$_G["setting"]["forumpicstyle"]["thumbheight"] = intval($_G["setting"]["forumpicstyle"]["thumbheight"]);
	}
	if (empty($_G["uid"])) {
		return false;
	}
	if (($_arg_0 || $_arg_2) && empty($_arg_3)) {
		if (empty($_arg_4)) {
			if ($_arg_2) {
				$_var_7 = "aid:" . $_arg_2;
				$_var_8 = C::t("forum_attachment_n")->fetch("aid:" . $_arg_2, $_arg_2, array(1, -1));
			} else {
				$_var_7 = "pid:" . $_arg_0;
				$_var_8 = C::t("forum_attachment_n")->fetch_max_image("pid:" . $_arg_0, "pid", $_arg_0);
			}
			if (!$_var_8) {
				return false;
			}
			if (empty($_G["forum"]["ismoderator"]) && $_G["uid"] != $_var_8["uid"]) {
				return false;
			}
			if (empty($_arg_0)) {
				$_arg_0 = $_var_8["pid"];
			}
			if (empty($_arg_1)) {
				$_arg_1 = $_var_8["tid"];
			}
			if ($_var_8["remote"]) {
				$_var_9 = $_G["setting"]["ftp"]["attachurl"] . "forum/" . $_var_8["attachment"];
			} else {
				$_var_9 = $_G["setting"]["attachurl"] . "forum/" . $_var_8["attachment"];
			}
		} else {
			$_var_7 = "pid:" . $_arg_0;
			$_var_9 = $_arg_4;
		}
		if (!$_G["setting"]["attachdir"]) {
			$_var_10 = DISCUZ_ROOT . "./data/attachment/";
		} else {
			$_var_10 = $_G["setting"]["attachdir"];
		}
		$_var_11 = "threadcover/" . substr(md5($_arg_1), 0, 2) . "/" . substr(md5($_arg_1), 2, 2) . "/";
		dmkdir($_var_10 . "./forum/" . $_var_11);
		require_once libfile("class/image");
		$_var_12 = new image();
		if ($_var_12->Thumb($_var_9, "forum/" . $_var_11 . $_arg_1 . ".jpg", $_G["setting"]["forumpicstyle"]["thumbwidth"], $_G["setting"]["forumpicstyle"]["thumbheight"], 2)) {
			$_var_13 = '';
			if (getglobal("setting/ftp/on")) {
				if (ftpcmd("upload", "forum/" . $_var_11 . $_arg_1 . ".jpg")) {
					$_var_13 = "-";
				}
			}
			$_var_6 = C::t("forum_attachment_n")->count_image_by_id($_var_7, "pid", $_arg_0);
			if ($_arg_4 && empty($_var_6)) {
				$_var_6 = 1;
			}
			$_var_6 = $_var_13 . $_var_6;
		} else {
			return false;
		}
	}
	if ($_arg_3) {
		if (empty($_var_6)) {
			$_var_14 = C::t("forum_thread")->fetch($_arg_1);
			$_var_15 = $_var_14["cover"];
			$_var_6 = C::t("forum_attachment_n")->count_image_by_id("tid:" . $_arg_1, "pid", $_arg_0);
			if ($_var_6) {
				if ($_var_15 < 0) {
					$_var_6 = "-" . $_var_6;
				}
			}
		}
	}
	if ($_var_6) {
		C::t("forum_thread")->update($_arg_1, array("cover" => $_var_6));
		return true;
	}
}
function fileter_header($_arg_0)
{
	$_var_1 = "<h2" . wq_preg_match("#<h2(.*)</h2>#iUs", $_arg_0) . "</h2>";
	$_var_2 = wq_preg_match("#<div class=\"rich_media_meta_list\">(.*)<div class=\"rich_media_content\" id=\"js_content\">#iUs", $_arg_0);
	if ($_var_2) {
		$_var_2 = $_var_2 . "<div class=\"rich_media_meta_list\">";
	} else {
		$_var_2 = wq_preg_match("#<div id=\"page-content\">(.*)<div class=\"rich_media_content \" id=\"js_content\">#iUs", $_arg_0);
	}
	$_arg_0 = str_replace(array($_var_2, $_var_1), '', $_arg_0);
	return $_arg_0;
}
function add_content_ent_label($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = substr_count($_arg_0, $_arg_1);
	$_var_4 = substr_count($_arg_0, $_arg_2);
	$_var_5 = $_var_4;
	while ($_var_5 < $_var_3) {
		$_arg_0 = $_arg_0 . $_arg_2;
		$_var_5 = $_var_5 + 1;
	}
	return $_arg_0;
}
function curl_getlocation_url($_arg_0, $_arg_1)
{
	$_var_2 = curl_init($_arg_0);
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($_var_2, CURLOPT_COOKIEFILE, $_arg_1);
	$_var_3 = curl_exec($_var_2);
	$_var_4 = curl_getinfo($_var_2);
	curl_close($_var_2);
	if ($_var_3 != $_var_4) {
		if (strpos($_var_4["url"], "http://mp.weixin.qq.com/s?__biz=") === false) {
			return wq_preg_match("#href=\"(.*)\">#iUs", $_var_3);
		}
		return $_var_4["url"];
	}
	return false;
}
function del_article($_arg_0, $_arg_1 = true, $_arg_2 = '')
{
	global $_G;
	$_var_4 = C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->fetch_all_imageurl_by_articleid($_arg_0["articleid"]);
	foreach ($_var_4 as $_var_5) {
		if ($_var_5["type"] == "1") {
			if (file_exists($_var_5["imageurl"])) {
				@unlink(wq_wechatcollecting_headimg_and_bgimg_url($_var_5["imageurl"], true));
			}
		}
		if ($_var_5["type"] == "3") {
			@unlink($_var_5["imageurl"]);
			delete_wechat_qiniu_images($_var_5["imageurl"], $_arg_2);
		}
		C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->delete($_var_5["id"]);
	}
	unlink($_arg_0["imglink"]);
	C::t("#wq_wechatcollecting#wq_wechatcollecting_article_content")->delete_by_articleid($_arg_0["articleid"], wq_wechatcollecting_get_article_contenttableid($_arg_0["articleid"]));
	C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->delete($_arg_0["articleid"]);
	if ($_arg_1) {
		update_wechat_field_by_wechatid($_arg_0["wid"], array("articlenum", "recommend_num", "first_num"));
	}
	if ($_G["cache"]["plugin"]["wq_wechatreader"]) {
		$_var_6 = C::t("#wq_wechatreader#wq_wechatreader_favorites")->fetch_all_by_where($_arg_0["articleid"]);
		C::t("#wq_wechatreader#wq_wechatreader_favorites")->delete_by_aid($_arg_0["articleid"]);
		if ($_var_6) {
			include_once DISCUZ_ROOT . "./source/plugin/wq_wechatreader/function/function_wechatreader.php";
			foreach ($_var_6 as $_var_7 => $_arg_0) {
				if ($_arg_0["favoritesid"]) {
					C::t("#wq_wechatreader#wq_wechatreader_favoritesname")->update_incrcase($_arg_0["favoritesid"], $_arg_0["uid"], false);
				}
				cache_wq_wechatreader_favorites($_arg_0["uid"]);
			}
		}
	}
}
function delete_wechat_qiniu_images($_arg_0, $_arg_1)
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/functions.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Auth.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Storage/BucketManager.php";
	$_var_2 = $_arg_1["qiniu_ak"];
	$_var_3 = $_arg_1["qiniu_sk"];
	$_var_4 = new wqAuth($_var_2, $_var_3);
	$_var_5 = new wqBucketManager($_var_4);
	$_var_6 = $_arg_1["qiniu_bucket"];
	$_var_7 = $_arg_0;
	$_var_8 = $_var_5->delete($_var_6, $_var_7);
}
function wq_auto_input_seccode($_arg_0 = true, $_arg_1 = '')
{
	$_var_2 = 1;
	do {
		if ($_arg_0) {
			$_var_3 = _wq_auto_input_seccode($_arg_1);
		} else {
			$_var_3 = _wq_auto_input_seccode_for_weixin();
		}
		$_var_2 = $_var_2 + 1;
	} while ($_var_2 <= 3 && ($_var_3 == "-3" || $_var_3 == "-4"));
	return $_var_3;
}
function _wq_auto_input_seccode($_arg_0)
{
	$_var_1 = check_jsdati_info_is_isset();
	if ($_var_1 != "0") {
		return $_var_1;
	}
	$_var_2 = time();
	$_var_3 = "https://weixin.sogou.com/antispider/?from=" . $_arg_0;
	wq_curl_for_sougou("https://weixin.sogou.com/antispider/util/seccode.php?tc=" . $_var_2, '', 1, $_var_3);
	$_var_4 = jsdati_upload("./data/cache/wq_sogou_code.png");
	if ($_var_4["result"] == "1") {
		$_var_5 = $_var_4["data"]["val"];
		$_var_6 = "https://weixin.sogou.com/antispider/thank.php";
		$_var_7 = "c=" . $_var_5 . "&r=" . $_arg_0 . "&v=5";
		$_var_8 = wq_curl_for_sougou($_var_6, $_var_7, false, $_var_3);
		$_var_9 = json_decode($_var_8, true);
		$_var_9 = wq_diconv($_var_9, "UTF-8", CHARSET);
		if ($_var_9["code"] == "0") {
			write_seccodelog("1");
			$_var_10 = array("SNUID", "refresh", "seccodeRight", "successCount");
			$_var_11 = array("SNUID" => $_var_9["id"], "seccodeRight" => "success", "successCount" => "1|" . gmdate("D, d M Y H:i:s T", time() + 300), "refresh" => "1");
			wq_update_cookie($_var_10, $_var_11);
			return array("1", $_var_2);
		}
		if ($_var_9["code"] == "3") {
			$_var_4 = jsdati_error($_var_4["data"]["id"]);
		}
		write_seccodelog($_var_9["code"]);
		return "-3";
	}
	write_seccodelog("-2", $_var_4["data"]);
	return "-2";
}
function _wq_auto_input_seccode_for_weixin()
{
	$_var_0 = check_jsdati_info_is_isset();
	if ($_var_0 != "0") {
		return $_var_0;
	}
	$_var_1 = random("13") . "." . random("4");
	save_code_for_weixin("http://mp.weixin.qq.com/mp/verifycode?cert=" . $_var_1);
	$_var_2 = jsdati_upload("./data/cache/wq_weixin_code.png");
	if ($_var_2["result"] == "1") {
		$_var_3 = $_var_2["data"]["val"];
		$_var_4 = "http://mp.weixin.qq.com/mp/verifycode";
		$_var_5 = "cert=" . $_var_1 . "&input=" . $_var_3 . '';
		$_var_6 = wq_curl_for_weixin($_var_4, $_var_5);
		$_var_7 = json_decode($_var_6, true);
		if ($_var_7["ret"] == "0") {
			write_seccodelog("1", '', "weixin");
			return 1;
		}
		if ($_var_7["ret"] == "501") {
			$_var_2 = jsdati_error($_var_2["data"]["id"]);
		}
		write_seccodelog($_var_7["ret"], '', "weixin");
		return "-4";
	}
	write_seccodelog("-2", $_var_2["data"]);
	return "-2";
}
//https://c.tb.cn/c.0LtBX
function write_seccodelog($_arg_0, $_arg_1 = '', $_arg_2 = "sogou")
{
	$_var_3 = get_wq_wechatcollecting_setting_lang();
	C::t("#wq_wechatcollecting#wq_wechatcollecting_seccodelog")->clear_by_dateline();
	if (!$_arg_1 && $_arg_0 != "-2") {
		if (!in_array($_arg_0, array("1", "-1"))) {
			$_var_4 = $_arg_0;
			$_arg_0 = $_arg_2 == "sogou" ? "-3" : "-4";
			$_var_5 = sprintf($_var_3["seccode_" . $_arg_0], $_var_4);
		} else {
			$_var_5 = $_arg_0 == "-1" ? $_var_3["seccode_-1"] : sprintf($_var_3["seccode_" . $_arg_0], $_var_3[$_arg_2]);
		}
	} else {
		$_var_5 = sprintf($_var_3["seccode_" . $_arg_0], $_arg_1);
	}
	if (in_array($_arg_0, array("-1", "-2")) && C::t("#wq_wechatcollecting#wq_wechatcollecting_seccodelog")->fetch_by_code($_arg_0)) {
		return '';
	}
	$_var_6 = array("errcode" => $_arg_0, "errtips" => $_var_5, "dateline" => time());
	C::t("#wq_wechatcollecting#wq_wechatcollecting_seccodelog")->insert($_var_6);
}
function wq_curl_for_sougou($_arg_0, $_arg_1 = '', $_arg_2 = false, $_arg_3 = '')
{
	$_var_4 = curl_init($_arg_0);
	curl_setopt($_var_4, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
	curl_setopt($_var_4, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($_var_4, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($_var_4, CURLOPT_HEADER, 0);
	curl_setopt($_var_4, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_4, CURLOPT_FOLLOWLOCATION, 1);
	if (!empty($_arg_1)) {
		curl_setopt($_var_4, CURLOPT_POST, 1);
		curl_setopt($_var_4, CURLOPT_POSTFIELDS, $_arg_1);
	}
	if (!empty($_arg_3)) {
		curl_setopt($_var_4, CURLOPT_REFERER, $_arg_3);
	}
	$_var_5 = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36";
	curl_setopt($_var_4, CURLOPT_USERAGENT, $_var_5);
	$_var_6 = get_cookie_for_sogou();
	curl_setopt($_var_4, CURLOPT_COOKIE, $_var_6);
	$_var_7 = curl_exec($_var_4);
	$_var_8 = curl_getinfo($_var_4);
	$_var_9 = curl_errno($_var_4);
	curl_close($_var_4);
	if ($_arg_2 == true) {
		file_put_contents("./data/cache/wq_sogou_code.png", $_var_7);
	} else {
		return $_var_7;
	}
}
function get_cookie_for_sogou()
{
	global $_G;
	return wq_get_cookie();
}
function get_token_wq_wechatcollecting()
{
	$_var_0 = get_wq_wechatcollecting_params();
	$_var_1 = substr(md5($_var_0["i_SN"]), 8, 16);
	return $_var_1;
}
function encode_data_get_cookie_wq_wechatcollecting($_arg_0)
{
	$_var_1 = get_token_wq_wechatcollecting();
	$_arg_0["key"] = $_var_1;
	$_arg_0["source"] = "wechatcollecting";
	ksort($_arg_0);
	$_var_2 = '';
	foreach ($_arg_0 as $_var_3 => $_var_4) {
		$_var_2 = $_var_2 . ("&" . $_var_3 . "=" . rawurlencode($_var_4));
	}
	$_arg_0["md5hash"] = md5(substr($_var_2, 1) . $_var_1);
	$_var_5 = "http://wikin.cn/plugin.php?id=wq_cookies&mod=api&" . http_build_query($_arg_0);
	return wq_dfsockopen($_var_5);
}
//Dism_taobao_com
function get_wq_wechatcollecting_setting()
{
	global $_G;
	loadcache("plugin");
	$_var_1 = $_G["cache"]["plugin"]["wq_wechatcollecting"];
	$_var_1["usesystemheader"] = intval($_var_1["usesystemheader"]);
	$_var_1["admingroups"] = unserialize($_var_1["admingroups"]);
	$_var_1["allow_groups"] = unserialize($_var_1["allow_groups"]);
	$_var_1["maxrestrict"] = intval($_var_1["maxrestrict"]);
	$_var_1["wechat_status"] = intval($_var_1["wechat_status"]);
	$_var_1["article_status"] = intval($_var_1["article_status"]);
	$_var_1["home_keyword"] = trim($_var_1["home_keyword"]);
	$_var_1["home_article_perpage"] = intval($_var_1["home_article_perpage"]);
	$_var_1["home_wechat_perpage"] = intval($_var_1["home_wechat_perpage"]);
	$_var_1["admincp_perpage"] = intval($_var_1["admincp_perpage"]);
	$_var_1["home_article_list_perpage"] = intval($_var_1["home_article_list_perpage"]);
	$_var_1["home_article_search_perpage"] = intval($_var_1["home_article_search_perpage"]);
	$_var_1["is_saveimages"] = $_var_1["view_issaveimg"] = 1;
	$_var_1["is_use_qiniu"] = intval($_var_1["is_use_qiniu"]);
	$_var_1["qiniu_ak"] = trim($_var_1["qiniu_ak"]);
	$_var_1["qiniu_sk"] = trim($_var_1["qiniu_sk"]);
	$_var_1["qiniu_bucket"] = trim($_var_1["qiniu_bucket"]);
	$_var_1["qiniu_domain"] = trim($_var_1["qiniu_domain"]);
	$_var_1["qiniu_domain"] = in_array(strtolower(substr($_var_1["qiniu_domain"], 0, 6)), array("http:/", "https:")) ? $_var_1["qiniu_domain"] : "//" . $_var_1["qiniu_domain"];
	$_var_1["view_mode"] = intval($_var_1["view_mode"]);
	$_var_1["default_fid"] = intval($_var_1["default_fid"]);
	$_var_1["mainnvid"] = trim($_var_1["mainnvid"]);
	$_var_1["is_setthreadcover"] = intval($_var_1["is_setthreadcover"]);
	$_var_1["jsdati_username"] = trim($_var_1["jsdati_username"]);
	$_var_1["jsdati_password"] = trim($_var_1["jsdati_password"]);
	$_var_1["timing_release_num"] = intval($_var_1["timing_release_num"]);
	$_var_1["home_navigation_width"] = !$_var_1["home_navigation_width"] ? 1320 : $_var_1["home_navigation_width"];
	$_var_1["home_navigation"] = !$_var_1["home_navigation"] ? "1" : $_var_1["home_navigation"];
	$_var_1["default_catid"] = !(intval($_var_1["default_catid"]) < 1) ? intval($_var_1["default_catid"]) : 1;
	$_var_1["use_common_header"] = $_var_1["usesystemheader"];
	return $_var_1;
}
function get_wq_wechatcollecting_setting_lang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_wechatcollecting/language");
	}
	include $_var_1;
	global $apilang;
	return $apilang;
}
function get_wq_wechatcollecting_params()
{
	include DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/config/check.php";
	global $params;
	return $params;
}
function jsdati_upload($_arg_0, $_arg_1 = 26, $_arg_2 = NULL, $_arg_3 = NULL)
{
	set_time_limit(0);
	if (class_exists("CURLFile")) {
		$_var_4["upload"] = new CURLFile(realpath($_arg_0));
	} else {
		$_var_4["upload"] = "@" . realpath($_arg_0);
	}
	$_var_4["yzm_minlen"] = $_arg_2;
	$_var_4["yzm_maxlen"] = $_arg_3;
	$_var_4["yzmtype_mark"] = $_arg_1;
	$_var_5 = jsdati_post("upload", $_var_4);
	$_var_6 = json_decode($_var_5, true);
	if ($_var_6["data"] && $_var_6["result"] != 1 && function_exists("mb_detect_encoding")) {
		$_var_7 = mb_detect_encoding($_var_6["data"]);
		$_var_6["data"] = diconv($_var_6["data"], $_var_7, CHARSET);
	}
	return $_var_6;
}
function jsdati_error($_arg_0)
{
	$_var_1 = jsdati_post("error", array("yzm_id" => $_arg_0));
	return json_decode($_var_1, true);
}
function jsdati_point()
{
	$_var_0 = jsdati_post("point");
	$_var_1 = json_decode($_var_0, true);
	if ($_var_1["result"] == true) {
		return $_var_1["data"];
	}
	return "-1";
}
function jsdati_post($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = get_wq_wechatcollecting_setting();
	$_var_4["user_name"] = $_var_3["jsdati_username"];
	$_var_4["user_pw"] = $_var_3["jsdati_password"];
	$_var_4["zztool_token"] = "weiqing";
	if (is_array($_arg_1)) {
		$_var_4 = $_var_4 + $_arg_1;
	}
	$_var_5 = curl_init("http://v1-http-api.jsdama.com/api.php?mod=php&act=" . $_arg_0 . '');
	curl_setopt($_var_5, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_5, CURLOPT_POST, 1);
	curl_setopt($_var_5, CURLOPT_POSTFIELDS, $_var_4);
	$_var_6 = curl_exec($_var_5);
	curl_close($_var_5);
	return $_var_6;
}
function check_jsdati_info_is_isset()
{
	$_var_0 = get_wq_wechatcollecting_setting();
	if (empty($_var_0["jsdati_username"]) || empty($_var_0["jsdati_password"])) {
		write_seccodelog("-1");
		return "-1";
	}
	return "0";
}
function update_cookie_for_weixin_by_http_response_header($_arg_0)
{
	$_var_1 = array();
	preg_match("/Set-Cookie: (.*); Path=/iUs", implode('', $_arg_0), $_var_1);
	C::t("common_setting")->update("wq_cookie_for_weixin", $_var_1["1"]);
	require_once libfile("function/cache");
	updatecache("setting");
}
function wq_curl_for_weixin($_arg_0, $_arg_1 = '', $_arg_2 = '')
{
	$_var_3 = curl_init($_arg_0);
	curl_setopt($_var_3, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
	curl_setopt($_var_3, CURLOPT_HEADER, 0);
	curl_setopt($_var_3, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_3, CURLOPT_FOLLOWLOCATION, 1);
	if (!empty($_arg_1)) {
		curl_setopt($_var_3, CURLOPT_POST, 1);
		curl_setopt($_var_3, CURLOPT_POSTFIELDS, $_arg_1);
	}
	$_var_4 = get_cookie_for_weixin();
	curl_setopt($_var_3, CURLOPT_COOKIE, $_var_4);
	if ($_arg_2) {
		curl_setopt($_var_3, CURLOPT_REFERER, $_arg_2);
	} else {
		curl_setopt($_var_3, CURLOPT_REFERER, "http://weixin.sogou.com/");
	}
	$_var_5 = curl_exec($_var_3);
	curl_close($_var_3);
	return $_var_5;
}
function get_cookie_for_weixin()
{
	global $_G;
	return $_G["setting"]["wq_cookie_for_weixin"];
}
function cache_wq_wechatcollecting_poll($_arg_0, $_arg_1)
{
	require_once libfile("function/cache");
	$_var_2 = C::t("#wq_wechatcollecting#wq_wechatcollecting_poll")->fetch_all_by_aid_uid_polltype('', $_arg_0, $_arg_1);
	foreach ($_var_2 as $_var_3) {
		$_var_4[] = $_var_3["articleid"];
	}
	if ($_arg_1) {
		savecache("wq_cache_articlepollsupport_" . $_arg_0, $_var_4);
	} else {
		savecache("wq_cache_articlepollagainst_" . $_arg_0, $_var_4);
	}
}
function update_wechat_field_by_wechatid($_arg_0, $_arg_1)
{
	$_arg_0 = intval($_arg_0);
	if (!$_arg_0 || !is_array($_arg_1)) {
		return NULL;
	}
	$_var_2 = NULL;
	if (in_array("articlenum", $_arg_1)) {
		$_var_2["articlenum"] = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->count_by_wid($_arg_0, array(1));
	}
	if (in_array("recommend_num", $_arg_1)) {
		$_var_2["recommend_num"] = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->count_by_wid_recommend_isfirst($_arg_0, 1);
	}
	if (in_array("first_num", $_arg_1)) {
		$_var_2["first_num"] = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->count_by_wid_recommend_isfirst($_arg_0, 0, 1);
	}
	if ($_var_2) {
		return C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->update($_arg_0, $_var_2);
	}
	return '';
}
function download_background_image($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_arg_0 = str_replace(array("image: url(&quot;", "image:url(&quot;", "image:url("), "image: url(", $_arg_0);
	$_arg_0 = str_replace("&quot;)", ")", $_arg_0);
	preg_match_all("/image: url\\((.*)\\)/ismU", $_arg_0, $_var_4, PREG_SET_ORDER);
	if (is_array($_var_4) && !empty($_var_4)) {
		$_var_5 = $_var_6 = $_var_7 = NULL;
		foreach ($_var_4 as $_var_8) {
			if (strpos($_var_8[1], "wq_wechatcollecting") === false) {
				if (strlen($_var_8[1]) && substr($_var_8[1], 0, 4) == "http") {
					$_var_5[] = $_var_8[1];
					$_var_9 = save_article_images_new($_var_8[1], $_arg_1);
					$_var_6[] = $_var_9;
				}
			}
		}
		if ($_var_6) {
			$_arg_0 = str_replace($_var_5, $_var_6, $_arg_0);
			$_var_6 = array_unique($_var_6);
			foreach ($_var_6 as $_var_10 => $_var_11) {
				$_var_12 = array("articleid" => $_arg_1, "type" => 1, "imageurl" => $_var_11);
				$_var_13 = C::t("#wq_wechatcollecting#wq_wechatcollecting_attachment")->insert($_var_12);
				if ($_arg_2["is_use_qiniu"] == 1 && !empty($_arg_2["qiniu_sk"]) && !empty($_arg_2["qiniu_domain"]) && !empty($_arg_2["qiniu_ak"]) && !empty($_arg_2["qiniu_bucket"])) {
					$_var_14 = wqQqApi_save_article_images_wechat_qiniu($_var_11, $_arg_1, $_arg_2, $_var_13);
					$_var_7[] = $_var_14;
					if (strlen(trim($_var_14)) && substr(trim($_var_14), 0, strlen($_arg_2["qiniu_domain"])) == $_arg_2["qiniu_domain"]) {
						$_var_15 = trim(str_replace($_arg_2["qiniu_domain"] . "/", '', trim($_var_14)));
						if (file_exists($_var_15)) {
							@unlink($_var_15);
						}
					}
				}
			}
		}
		if ($_var_7) {
			$_arg_0 = str_replace($_var_6, $_var_7, $_arg_0);
		}
		C::t("#wq_wechatcollecting#wq_wechatcollecting_article_content")->update_content_by_articleid($_arg_1, base64_encode($_arg_0), wq_wechatcollecting_get_article_contenttableid($_arg_1));
	}
	return $_arg_0;
}
function wq_update_fid_or_aid_by_wid_articleid($_arg_0 = 0, $_arg_1 = 0)
{
	if (!$_arg_0 && !$_arg_1) {
		return NULL;
	}
	if ($_arg_1) {
		$_var_2 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch_first_by_articleid($_arg_1);
		return update_thread_or_article_by_tid_aid($_var_2["classid"], $_var_2["tid"], $_var_2["aid"], $_var_2["isgroup"]);
	}
	$_var_3 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch_by_wid($_arg_0);
	foreach ($_var_3 as $_var_4 => $_var_5) {
		$_var_6 = $_var_7 = 0;
		$_var_6 = $_var_5["tid"] ? $_var_5["tid"] : $_var_6;
		$_var_7 = $_var_5["aid"] ? $_var_5["aid"] : $_var_7;
		update_thread_or_article_by_tid_aid($_var_5["classid"], $_var_6, $_var_7, $_var_5["isgroup"]);
	}
}
function update_thread_or_article_by_tid_aid($_arg_0, $_arg_1 = 0, $_arg_2 = 0, $_arg_3 = 0)
{
	global $wechatclass_article;
	global $_G;
	if (!$wechatclass_article) {
		loadcache("wq_wechatcollecting_class");
		$wechatclass_article = $_G["cache"]["wq_wechatcollecting_class"];
	}
	if (!$_arg_0 || !$_arg_1 && !$_arg_2) {
		return NULL;
	}
	if ($_arg_1 && (!$_arg_3 && $wechatclass_article[$_arg_0]["fid"] || $_arg_3 && $wechatclass_article[$_arg_0]["groupfid"])) {
		include_once libfile("function/post");
		$_var_6 = C::t("forum_thread")->fetch($_arg_1);
		$_var_7 = $_arg_3 ? $wechatclass_article[$_arg_0]["groupfid"] : $wechatclass_article[$_arg_0]["fid"];
		C::t("forum_thread")->update($_arg_1, array("fid" => $_var_7));
		updateforumcount($_var_6["fid"]);
		updateforumcount($_var_7);
	}
	if ($_arg_2 && $wechatclass_article[$_arg_0]["catid"]) {
		C::t("portal_article_title")->update($_arg_2, array("catid" => $wechatclass_article[$_arg_0]["catid"]));
	}
}
function wq_get_wq_ad_info($_arg_0)
{
	global $_G;
	$_var_2 = '';
	if ($_G["cache"]["plugin"]["wq_ad"]) {
		if (!function_exists("wq_other_plugin_get_adinfo")) {
			include_once DISCUZ_ROOT . "./source/plugin/function/function_ad.php";
		}
		return wq_other_plugin_get_adinfo($_arg_0);
	}
	return $_var_2;
}
function wq_wechatcollecting_get_article_contenttableid($_arg_0)
{
	$_var_1 = 0;
	if ($_arg_0) {
		$_var_2 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch($_arg_0);
		$_var_1 = dintval($_var_2["contenttableid"]);
	}
	return $_var_1;
}
function wq_common_post_forum_or_portal($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4, $_arg_5, $_arg_6 = 0)
{
	$_var_7 = $_var_8 = 0;
	$_arg_4["imglink"] = wq_wechatcollecting_headimg_and_bgimg_url($_arg_4["imglink"], true);
	$_arg_0["view_mode"] = $_arg_3["view_mode"] ? $_arg_3["view_mode"] : $_arg_0["view_mode"];
	$_var_9 = !empty($_arg_5[$_arg_1]["fid"]) ? $_arg_5[$_arg_1]["fid"] : $_arg_0["default_fid"];
	if ($_var_9 && in_array($_arg_0["view_mode"], array("2", "4"))) {
		$_var_7 = sync_to_forum($_arg_4["title"], $_var_9, $_arg_2, 0, 0, $_arg_3["username"], $_arg_3["uid"], $_arg_6, $_arg_0);
		$_var_10 = C::t("forum_post")->fetch_pid_by_tid_authorid($_var_7, $_arg_3["uid"]);
		if ($_arg_0["is_setthreadcover"]) {
			upload_images_to_attachment_by_path(array($_arg_4["imglink"]), $_var_7, $_var_10);
		}
	}
	if ($_arg_5[$_arg_1]["catid"]) {
		$_var_11 = $_arg_5[$_arg_1]["catid"];
	} else {
		$_var_11 = C::t("common_syscache")->fetch("wq_portal_collect_set");
	}
	if ($_var_11 && in_array($_arg_0["view_mode"], array("3", "4"))) {
		$_var_12 = $_arg_6 ? 0 : 1;
		$_var_8 = sync_to_portal($_arg_4["title"], $_arg_0["is_showimage"] ? str_replace(wq_wechatcollecting_get_attachdir(), '', $_arg_4["imglink"]) : '', $_arg_2, '', $_var_11, $_arg_3["name"], $_arg_3["username"], $_arg_3["uid"], $_var_12);
		if ($_arg_0["is_showimage"]) {
			upload_images_to_attachment_by_portal(array($_arg_4["imglink"]), $_var_8);
		}
	}
	$_var_9 = !empty($_arg_5[$_arg_1]["groupfid"]) ? $_arg_5[$_arg_1]["groupfid"] : (count($_arg_0["default_groupfid"]) > 1 ? $_arg_0["default_groupfid"][array_rand($_arg_0["default_groupfid"])] : $_arg_0["default_groupfid"][0]);
	if ($_var_9 && $_arg_0["view_mode"] == "5") {
		$_var_7 = sync_to_forum($_arg_4["title"], $_var_9, $_arg_2, 0, 1, $_arg_3["username"], $_arg_3["uid"], $_arg_6, $_arg_0);
		$_var_10 = C::t("forum_post")->fetch_pid_by_tid_authorid($_var_7, $_arg_3["uid"]);
		if ($_arg_0["is_setthreadcover"]) {
			upload_images_to_attachment_by_path(array($_arg_4["imglink"]), $_var_7, $_var_10);
		}
	}
	return array("tid" => $_var_7, "aid" => $_var_8);
}
function wq_common_article_view_url($_arg_0, $_arg_1 = 0, $_arg_2 = 0, $_arg_3 = 0)
{
	$_var_4 = array();
	$_var_5 = '';
	if ($_arg_2 && !$_arg_3 || $_arg_2 && $_arg_3 && !$_arg_0["default_url"]) {
		$_var_4["mod"] = "viewthread";
		$_var_4["tid"] = $_arg_2;
		$_var_5 = "forum.php?" . url_implode($_var_4);
	} else {
		if ($_arg_3 && !$_arg_2 || $_arg_2 && $_arg_3 && $_arg_0["default_url"]) {
			$_var_4["mod"] = "view";
			$_var_4["aid"] = $_arg_3;
			$_var_5 = "portal.php?" . url_implode($_var_4);
		} else {
			$_var_4["id"] = "wq_wechatcollecting";
			$_var_4["mod"] = "view";
			$_var_4["articleid"] = $_arg_1;
			$_var_5 = "plugin.php?" . url_implode($_var_4);
		}
	}
	return $_var_5;
}
function wq_common_article_view_url_($_arg_0, $_arg_1 = 0, $_arg_2 = 0, $_arg_3 = 0)
{
	$_var_4 = array();
	$_var_5 = '';
	if ($_arg_2 && ($_arg_0["view_mode"] == "2" || $_arg_0["view_mode"] == "5" || $_arg_0["view_mode"] == "4" && !$_arg_0["default_url"] || $_arg_0["view_mode"] == "4" && $_arg_0["default_url"] && !$_arg_3)) {
		$_var_4["mod"] = "viewthread";
		$_var_4["tid"] = $_arg_2;
		$_var_5 = "forum.php?" . url_implode($_var_4);
	} else {
		if ($_arg_3 && ($_arg_0["view_mode"] == "3" || $_arg_0["view_mode"] == "4" && $_arg_0["default_url"] || $_arg_0["view_mode"] == "4" && !$_arg_0["default_url"] && !$_arg_2)) {
			$_var_4["mod"] = "view";
			$_var_4["aid"] = $_arg_3;
			$_var_5 = "portal.php?" . url_implode($_var_4);
		} else {
			$_var_4["id"] = "wq_wechatcollecting";
			$_var_4["mod"] = "view";
			$_var_4["articleid"] = $_arg_1;
			$_var_5 = "plugin.php?" . url_implode($_var_4);
		}
	}
	return $_var_5;
}
function wq_get_qrcode_by_wechatid($_arg_0, $_arg_1 = 1)
{
	if ($_arg_1) {
		return "https://open.weixin.qq.com/qr/code?username=" . $_arg_0;
	}
	$_var_2 = C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->fetch_first_by_wechatid($_arg_0);
	$_var_2["qrcode"] = wq_wechatcollecting_headimg_and_bgimg_url($_var_2["qrcode"]);
	return $_var_2["qrcode"];
}
function wq_wechatcollecting_get_content_imgurl($_arg_0)
{
	preg_match_all("/<img [^>]*>/ismU", $_arg_0, $_var_1, PREG_SET_ORDER);
	$_var_2 = array();
	foreach ($_var_1 as $_var_3 => $_var_4) {
		preg_match("/\\<img.+src=('|\"|)?(.*)([\\s].*)?\\>/ismU", $_var_4[0], $_var_5);
		if ($_var_5) {
			$_var_2[] = $_var_5;
		}
	}
	return $_var_2;
}
function wq_wechatcollecting_register_newuser($_arg_0, $_arg_1, $_arg_2 = 1)
{
	global $_G;
	if ($_arg_1["wechatname_isregister"] && !intval(C::t("common_member")->fetch_uid_by_username($_arg_0["name"]))) {
		loaducenter();
		$_var_4 = wq_wechatcollecting_register_by_wechatname($_arg_0["name"], $_arg_2, $_arg_1["register_pwd"]);
		if ($_var_4 && is_array($_var_4)) {
			$_arg_0["uid"] = $_var_4[0];
			$_arg_0["username"] = $_var_4[1];
			wq_wechatcollecting_uploadAvatar($_arg_0["uid"], wq_wechatcollecting_headimg_and_bgimg_url($_arg_0["headimage"]));
		}
	}
	return $_arg_0;
}
function wq_wechatcollecting_register_by_wechatname($_arg_0, $_arg_1 = 0, $_arg_2 = '')
{
	global $_G;
	if (!$_arg_0) {
		return NULL;
	}
	include_once UC_ROOT . "./model/base.php";
	$_var_4 = new base();
	$_var_5 = $_var_4->get_setting(array("accessemail"));
	$_var_6 = $_var_5["accessemail"];
	$_var_7 = explode("\n", str_replace("\r\n", "\n", $_var_6));
	$_var_8 = $_G["cache"]["plugin"]["wq_login"];
	$_var_9 = $_var_8["newusergroupid"] ? $_var_8["newusergroupid"] : $_G["setting"]["newusergroupid"];
	if ($_arg_2) {
		$_var_10 = $_arg_2;
	} else {
		$_var_10 = md5(random(10));
	}
	if ($_var_7[0] == '') {
		$_var_11 = "wechat_" . strtolower(random(10)) . "@null.null";
	} else {
		$_var_11 = "wechat_" . strtolower(random(10)) . "@" . trim(trim(strtolower($_var_7[0])));
		$_var_11 = str_replace(array("@@", "@"), "@", $_var_11);
	}
	if (!$_var_8["disableregrule"]) {
		loadcache("ipctrl");
		if ($_G["cache"]["ipctrl"]["ipregctrl"]) {
			foreach (explode("\n", $_G["cache"]["ipctrl"]["ipregctrl"]) as $_var_12) {
				if (preg_match("/^(" . preg_quote($_var_12 = trim($_var_12), "/") . ")/", $_G["clientip"])) {
					$_var_12 = $_var_12 . "%";
					$_G["setting"]["regctrl"] = $_G["setting"]["ipregctrltime"];
					break;
				}
				$_var_12 = $_G["clientip"];
			}
		} else {
			$_var_12 = $_G["clientip"];
		}
		if ($_G["setting"]["regctrl"]) {
			if (C::t("common_regip")->count_by_ip_dateline($_var_12, $_G["timestamp"] - $_G["setting"]["regctrl"] * 3600)) {
				if (!$_arg_1) {
					showmessage("register_ctrl", NULL, array("regctrl" => $_G["setting"]["regctrl"]));
				} else {
					return NULL;
				}
			}
		}
		$_var_13 = NULL;
		if ($_G["setting"]["regfloodctrl"]) {
			$_var_14 = C::t("common_regip")->fetch_by_ip_dateline($_G["clientip"], $_G["timestamp"] - 86400);
			if ($_var_14) {
				if ($_var_14["count"] >= $_G["setting"]["regfloodctrl"]) {
					if (!$_arg_1) {
						showmessage("register_flood_ctrl", NULL, array("regfloodctrl" => $_G["setting"]["regfloodctrl"]));
					} else {
						return NULL;
					}
				} else {
					$_var_13 = 1;
				}
			} else {
				$_var_13 = 2;
			}
		}
		if ($_var_13 !== NULL) {
			if ($_var_13 == 1) {
				C::t("common_regip")->update_count_by_ip($_G["clientip"]);
			} else {
				C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => 1, "dateline" => $_G["timestamp"]));
			}
		}
	}
	$_var_15 = uc_user_register(addslashes($_arg_0), $_var_10, $_var_11, '', '', $_G["clientip"]);
	if ($_var_15 <= 0) {
		return $_var_15;
	}
	$_var_16 = array("credits" => explode(",", $_G["setting"]["initcredits"]));
	C::t("common_member")->insert($_var_15, $_arg_0, $_var_10, $_var_11, $_G["clientip"], $_var_9, $_var_16);
	if ($_G["setting"]["regctrl"] || $_G["setting"]["regfloodctrl"]) {
		C::t("common_regip")->delete_by_dateline($_G["timestamp"] - ($_G["setting"]["regctrl"] > 72 ? $_G["setting"]["regctrl"] : 72) * 3600);
		if ($_G["setting"]["regctrl"]) {
			C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => -1, "dateline" => $_G["timestamp"]));
		}
	}
	if ($_G["setting"]["regverify"] == 2) {
		C::t("common_member_validate")->insert(array("uid" => $_var_15, "submitdate" => $_G["timestamp"], "moddate" => 0, "admin" => '', "submittimes" => 1, "status" => 0, "message" => '', "remark" => ''), false, true);
		manage_addnotify("verifyuser");
	}
	require_once libfile("function/member");
	include_once libfile("function/stat");
	updatestat("register");
	include_once libfile("cache/userstats", "function");
	build_cache_userstats();
	return array($_var_15, $_arg_0);
}
function wq_wechatcollecting_uploadAvatar($_arg_0, $_arg_1)
{
	global $_G;
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	$_arg_1 = wq_wechatcollecting_save_avatar($_arg_1);
	list($_var_3, $_var_4, $_var_5, $_var_6) = getimagesize($_arg_1);
	if (!$_var_3) {
		return false;
	}
	if ($_var_3 < 10 || $_var_4 < 10 || $_var_5 == 4) {
		return false;
	}
	$_var_7 = array(1 => ".gif", 2 => ".jpg", 3 => ".png");
	$_var_8 = $_var_7[$_var_5];
	if (!$_var_8) {
		$_var_8 = ".jpg";
	}
	$_var_9 = $_G["setting"]["attachdir"];
	$_var_10 = $_var_9 . "./temp/upload" . $_arg_0 . $_var_8;
	file_exists($_var_10) && @unlink($_var_10);
	file_put_contents($_var_10, file_get_contents($_arg_1));
	if (!is_file($_var_10)) {
		return false;
	}
	$_var_11 = "./temp/upload" . $_arg_0 . "big" . $_var_8;
	$_var_12 = "./temp/upload" . $_arg_0 . "middle" . $_var_8;
	$_var_13 = "./temp/upload" . $_arg_0 . "small" . $_var_8;
	$_var_14 = new image();
	if ($_var_14->Thumb($_var_10, $_var_11, 200, 250, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_12, 120, 120, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_13, 48, 48, 2) <= 0) {
		return false;
	}
	$_var_11 = $_var_9 . $_var_11;
	$_var_12 = $_var_9 . $_var_12;
	$_var_13 = $_var_9 . $_var_13;
	$_var_15 = wq_wechatcollecting_byte2hex(file_get_contents($_var_11));
	$_var_16 = wq_wechatcollecting_byte2hex(file_get_contents($_var_12));
	$_var_17 = wq_wechatcollecting_byte2hex(file_get_contents($_var_13));
	$_var_18 = "&avatar1=" . $_var_15 . "&avatar2=" . $_var_16 . "&avatar3=" . $_var_17;
	$_var_19 = wq_wechatcollecting_uc_api_post_ex("user", "rectavatar", array("uid" => $_arg_0), $_var_18);
	@unlink($_var_10);
	@unlink($_var_11);
	@unlink($_var_12);
	@unlink($_var_13);
	@unlink($_arg_1);
	if ($_var_19 == "<?xml version=\"1.0\" ?><root><face success=\"1\"/></root>") {
		C::t("common_member")->update($_arg_0, array("avatarstatus" => "1"));
		updatecreditbyaction("setavatar");
		return true;
	}
	return false;
}
function wq_wechatcollecting_save_avatar($_arg_0)
{
	$_var_1 = DISCUZ_ROOT . "/data/cache/avatarTmp/";
	dmkdir($_var_1);
	$_var_2 = $_var_1 . "/" . date("His") . strtolower(random(16)) . ".jpg";
	$_var_3 = wq_dfsockopen($_arg_0, 0, array(), '', false);
	file_put_contents($_var_2, $_var_3);
	return $_var_2;
}
function wq_wechatcollecting_byte2hex($_arg_0)
{
	$_var_1 = '';
	$_var_2 = unpack("H*", $_arg_0);
	$_var_2 = str_split($_var_2[1], 2);
	$_var_3 = '';
	foreach ($_var_2 as $_var_4 => $_var_5) {
		$_var_3 = $_var_3 . strtoupper($_var_5);
	}
	return $_var_3;
}
function wq_wechatcollecting_uc_api_post_ex($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = '')
{
	$_var_4 = $_var_5 = '';
	foreach ($_arg_2 as $_var_6 => $_var_7) {
		$_var_6 = urlencode($_var_6);
		if (is_array($_var_7)) {
			$_var_8 = $_var_9 = '';
			foreach ($_var_7 as $_var_10 => $_var_11) {
				$_var_10 = urlencode($_var_10);
				$_var_8 = $_var_8 . ('' . $_var_9 . '' . $_var_6 . "[" . $_var_10 . "]=" . urlencode(uc_stripslashes($_var_11)));
				$_var_9 = "&";
			}
			$_var_4 = $_var_4 . ($_var_5 . $_var_8);
		} else {
			$_var_4 = $_var_4 . ('' . $_var_5 . '' . $_var_6 . "=" . urlencode(uc_stripslashes($_var_7)));
		}
		$_var_5 = "&";
	}
	$_var_12 = uc_api_requestdata($_arg_0, $_arg_1, $_var_4, $_arg_3);
	return uc_fopen2(UC_API . "/index.php", 500000, $_var_12, '', true, UC_IP, 20);
}
function wq_wechatcollecting_check_isset_default_fid($_arg_0, $_arg_1)
{
	if (($_arg_0["view_mode"] == "2" || $_arg_0["view_mode"] == "4") && empty($_arg_0["default_fid"])) {
		$_var_2 = C::t("common_plugin")->fetch_by_identifier("wq_wechatcollecting");
		$_var_3 = "admin.php?action=plugins&operation=config&do=" . $_var_2["pluginid"];
		showmessage($_arg_1["1f9d4c427b1d3f3b"], $_var_3);
	} else {
		if ($_arg_0["view_mode"] == "3" || $_arg_0["view_mode"] == "4") {
			$_var_4 = C::t("common_syscache")->fetch("wq_portal_collect_set");
			if (!$_var_4) {
				$_var_3 = "admin.php?action=plugins&operation=config&identifier=wq_wechatcollecting&pmod=admincp_portalclass";
				showmessage($_arg_1["b7d054dcc06c52c3"], $_var_3);
			}
		} else {
			if ($_arg_0["view_mode"] == "5" && empty($_arg_0["default_groupfid"])) {
				$_var_2 = C::t("common_plugin")->fetch_by_identifier("wq_wechatcollecting");
				$_var_3 = "admin.php?action=plugins&operation=config&do=" . $_var_2["pluginid"];
				showmessage($_arg_1["a23b201b7ca55023"], $_var_3);
			}
		}
	}
}
function wq_wechatcollecting_get_view_mode($_arg_0, $_arg_1)
{
	$_var_2 = array(0 => $_arg_1["c829719e878ed2b3"], 1 => $_arg_1["7d0adf4f4f9e5b8f"]);
	if (!empty($_arg_0["default_fid"])) {
		$_var_2[2] = $_arg_1["81230097fd642a73"];
	}
	$_var_3 = C::t("common_syscache")->fetch("wq_portal_collect_set");
	if (!empty($_var_3)) {
		$_var_2[3] = $_arg_1["0414f03e2a28169e"];
	}
	if (!empty($_arg_0["default_fid"]) && !empty($_var_3)) {
		$_var_2[4] = $_arg_1["9a0533fd5c0b7150"];
	}
	if (!empty($_arg_0["default_groupfid"])) {
		$_var_2[5] = $_arg_1["c774c870eddc4cc1"];
	}
	return $_var_2;
}
function wq_wechatcollecting_headimg_and_bgimg_url($_arg_0, $_arg_1 = false)
{
	if (empty($_arg_0)) {
		return $_arg_0;
	}
	$_var_2 = $_arg_0;
	if (strpos($_arg_0, "wq_wechatcollecting/") === 0 || strpos($_arg_0, "portal/") === 0) {
		if ($_arg_1) {
			$_var_3 = wq_wechatcollecting_get_attachdir();
			$_var_2 = $_var_3 . $_arg_0;
		} else {
			$_var_4 = wq_wechatcollecting_get_attachurl();
			$_var_2 = $_var_4 . $_arg_0;
		}
	}
	return $_var_2;
}
function wq_wechatcollecting_wechatarticle_exists($_arg_0, $_arg_1, $_arg_2 = 0, $_arg_3 = 0)
{
	if ($_arg_3) {
		$_arg_0 = '';
	}
	if ($_arg_2 == 2) {
		$_var_4 = C::t("#wq_wechatcollecting#wq_wechatcollecting_temparticle")->fetch_first_by_wechatid($_arg_0, $_arg_1);
	} else {
		$_var_4 = C::t("#wq_wechatcollecting#wq_wechatcollecting_article")->fetch_first_by_wechatid($_arg_0, $_arg_1);
	}
	return $_var_4;
}
function wq_get_cookie($_arg_0 = false)
{
	global $_G;
	if (empty($_G["setting"]["wq_wechatcollecting_cookie_new"])) {
		$_var_2 = "SUV=00E75AA0778854565864F194B85BB533; ssuid=6244362540; dt_ssuid=1957577222; pgv_pvi=9353369600; wuid=AAEtI/6qHAAAAAqLE2NSTwsAIAY=; SUID=565488773120910A000000005864F192; IPLOC=CN4403; weixinIndexVisited=1; ABTEST=4|1556984538|v1; SNUID=1DC065691E1B95234655E7F51E3FBCFA; sct=12";
		wq_set_cookie($_var_2);
	}
	$_var_3 = $_G["setting"]["wq_wechatcollecting_cookie_new"];
	$_var_3 = unserialize($_var_3);
	if ($_arg_0) {
		return $_var_3;
	}
	$_var_4 = array();
	foreach ($_var_3 as $_var_5 => $_var_6) {
		$_var_4[] = '' . $_var_5 . "=" . $_var_6 . '';
	}
	$_var_7 = implode("; ", $_var_4);
	return $_var_7;
}
function wq_set_cookie($_arg_0)
{
	$_var_1 = explode("; ", $_arg_0);
	$_var_2 = array();
	foreach ($_var_1 as $_var_3 => $_var_4) {
		$_var_5 = explode("=", $_var_4);
		$_var_2[$_var_5[0]] = $_var_5[1];
	}
	C::t("common_setting")->update("wq_wechatcollecting_cookie_new", $_var_2);
	require_once libfile("function/cache");
	updatecache("setting");
	return true;
}
function wq_update_cookie($_arg_0 = array(), $_arg_1 = array())
{
	$_var_2 = $_var_3 = array();
	$_var_2 = wq_get_cookie(1);
	if (!empty($_arg_0)) {
		foreach ($_arg_0 as $_var_4 => $_var_5) {
			unset($_var_2[$_var_5]);
		}
	}
	if (!empty($_arg_0)) {
		foreach ($_arg_1 as $_var_4 => $_var_5) {
			$_var_3[$_var_4] = $_var_5;
		}
	}
	$_var_6 = array_merge($_var_2, $_var_3);
	C::t("common_setting")->update("wq_wechatcollecting_cookie_new", $_var_6);
	require_once libfile("function/cache");
	updatecache("setting");
	return true;
}
function check_is_get_article($_arg_0, $_arg_1 = 0)
{
	if ($_arg_1 > 0) {
		$_var_2 = time() - $_arg_1 * 86400;
		if ($_arg_0 < $_var_2) {
			return false;
		}
	}
	return true;
}
function get_page_arr($_arg_0)
{
	$_var_1 = 10;
	$_var_2 = '';
	$_var_3 = 1;
	while ($_var_3 <= $_var_1) {
		$_var_2 = $_var_2 . ("<option value='" . $_var_3 . "'>" . $_arg_0["no"] . '' . $_var_3 . '' . $_arg_0["pages"] . "</option>");
		$_var_3 = $_var_3 + 1;
	}
	return $_var_2;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	ini_set("pcre.backtrack_limit", 9999999);
	$_var_0 = "success";
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}