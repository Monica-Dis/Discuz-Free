<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-7-5 20:09:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_wechatcollecting_base {

	public $lang;
	public $setting;

	function init() {
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/loadfunc.php';

		$this->lang = wq_loadlang('wq_wechatcollecting');
	}

	function common() {
		if(CURSCRIPT == 'portal' && CURMODULE == 'portalcp' && $_GET['ac'] == 'article' && $_GET['op'] == 'delete' && $_GET['aid'] && submitcheck('deletesubmit')) {
			$article = $this->fetch_article_by_aid($_GET['aid']);
			include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
			if($_GET['optype'] == '1') {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($article['articleid'], array('status' => '-2'));
				update_wechat_field_by_wechatid($article['wid'], array('articlenum', 'recommend_num', 'first_num'));
			} else {
				del_article($article, true, $this->setting);
				if($article['tid']) {
					include_once libfile('function/delete');
					deletethread(array($article['tid']));
				}
			}
		}
        include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
	}

	function common_base() {
		global $_G;
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/loadfunc.php';
		$this->setting = wq_loadsetting('wq_wechatcollecting');
	}

	function fetch_article_by_tid($tid) {
		return C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_tid($tid);
	}

	function fetch_article_by_aid($aid) {
		return C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_aid($aid);
	}

	function get_wechat_info_by_articleid($articleid, $tableid = 0) {
		return C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_first_by_articleid($articleid, array('1', '-2'), $tableid);
	}

	function wq_preg_match($preg, $data) {
		preg_match($preg, $data, $content);
		return $content[1];
	}

	function get_thread_message($message) {
		return $message = base64_decode($message);
	}

	function _article_content($apparticle = array()) {
		global $_G, $aid;
		if($apparticle) {
			$article = $apparticle;
		} elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread') {
			$article = $this->fetch_article_by_tid($_G['tid']);
		} elseif(CURSCRIPT == 'portal' && CURMODULE == 'view') {
			$article = $this->fetch_article_by_aid($aid);
		}
		if(empty($article)) {
			return '1';
		}
		if($_G['mobile'] || $apparticle) {
			$wechatinfo_html = $this->get_wechatinfo_html_for_mobile($article['articleid'], false, $article['contenttableid']);
		} else {
			$wechatinfo_html = $this->get_wechatinfo_html($article['articleid'], $article['contenttableid']);
		}

		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatapi.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
		$contentarr = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_first_by_articleid($article['articleid'], array('1', '-2'), $article['contenttableid']);

		$contentarr['content'] = update_sogou_newcontent($contentarr['id'], $contentarr['content'], $article['contenttableid']);
		$length = strlen($contentarr['content']);
		if(!$contentarr['fileterheader'] && $length == 65535) {
			if($contentarr['url'] == '#rd') {
				$temcontent['content'] = null;
			} else {
				$temcontent = wqWechatApigetArticleContentByUrl($contentarr['url'], false, false, false);
			}

			if($temcontent['content']) {
				$updatedata['fileterheader'] = $contentarr['fileterheader'] = 1;
				$updatedata['content'] = $contentarr['content'] = base64_encode($temcontent['content']);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->update($article['contenttableid'], $contentarr['id'], $updatedata);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($contentarr['articleid'], array('url' => $contentarr['url']));
			}
		}
		$content = $contentarr['content'];
		$content = str_replace(array("jpg&", "#wechat_redirect"), array("jpg?", ""), base64_decode($content));

		if(!$contentarr['fileterheader'] && $length < 65535) {
			$content = fileter_header($content);
			if((substr_count($content, '"') % 2) != 0) {
				$content .= '"';
			}
		}
		if($this->setting['view_is_filtration_a']) {
			$content = preg_replace("/<a [^>]*>/", "", $content);
			$content = preg_replace("/<\/a>/", "", $content);
		}
		$content = add_content_ent_label($content, '<', '>');

		$content = add_content_ent_label($content, '<div', '</div>');

		if($this->setting['is_saveimages'] && $this->setting['view_issaveimg']) {
			$content = download_remote_images($content, $article['articleid'], $this->setting);
		}


		$content = wq_wechatcollecting_image_url_replace($content);

		if($_G['mobile']) {
			$content = $this->setting['mobile_content_add_top'] . $content . $this->setting['mobile_content_add_bottom'];
		} else {
			$content = $this->setting['pc_content_add_top'] . $content . $this->setting['pc_content_add_bottom'];
		}

		$addviews = 0;
		if($this->setting['optimizeviews']) {
			$row = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_addviews')->fetch($article['articleid']);
			if($row) {
				$addviews = $row['addviews'];
			}
		}
		wq_wechatcollecting_viewthread_updateviews($article['articleid'], 'article', $addviews, 'wq_wechatcollecting_article', 'wq_wechatcollecting_article_addviews', $this->setting, $article);

		$content = wq_wechatcollecting_content_music_manage($content);

		if($_G['mobile'] || $apparticle) {
			$content = ltrim(str_replace(array('zoomfile="', 'file="'), array('zoomfile_wq="', 'file_wq="'), $content));
			if($apparticle) {
				return str_replace("{content_html}", $content, $wechatinfo_html);
			}
			return array(str_replace("{content_html}", $content, $wechatinfo_html), $article['articleid'], $content);
		} else {
			$data_artid = $article['articleid'] == $_GET['tid'] ? $article['articleid'] + $_GET['tid'] : $article['articleid'];
			return array("<style>.wqpc_wechat_view *{max-width: 100%!important;box-sizing: border-box!important;-webkit-box-sizing: border-box!important; word-wrap: break-word!important;}</style><div class=\"wqpc_con wqpc_wechat_view\" data-artid=\"{$data_artid}\">" . $wechatinfo_html . $content . "</div>", $article['articleid'], $content);
		}
	}

	function get_wechatinfo_html($articleid, $tableid = 0) {
		if($this->setting['view_mode'] == 1 || !$this->setting['show_my_attention']) {
			$attention = '<span id="post-users" class="show">';
		} else {
			$info = $this->get_wechat_info_by_articleid($articleid, $tableid);
			$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($info['wid']);
			if(empty($info) || empty($wechat)) {
				return '';
			}

			$info['date'] = date("Y-m-d", $info['date']);
			$info = array_merge($info, $wechat);
			$attention = '<em id="post-date" class="rich_media_meta rich_media_meta_text">' . $info['date'] . '</em>'
				. '<a href="plugin.php?id=wq_wechatshow&mod=view&wid=' . $info['wechatid'] . '&displayorder=index" class="rich_media_meta rich_media_meta_link rich_media_meta_nickname">' . $info['name'] . '</a>'
				. '<span id="post-users" class="show"><a href="javascript:void(0);" id="post-user" class="view_pay">' . $this->lang['8ef952fcecabe5b4'] . '</a>';
		}

		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
		$info['qrcode'] = wq_get_qrcode_by_wechatid($info['wechatid']);
		$html = <<<EOT
            <div class="rich_media_meta_list" style="color:#fa1aca;">
                    {$attention}
                    <div id="js_profile_qrcode" class="profile_container" style="display:none;">
                            <div class="profile_inner" style="color:#333333"> <strong class="profile_nickname">{$info['name']}</strong>
                                    <img class="profile_avatar" id="js_profile_qrcode_img" src="{$info['qrcode']}">
                                    <p class="profile_meta">
                                            <label class="profile_meta_label">{$this->lang['4b3b548154549518']}</label>
                                            <span class="profile_meta_value">{$info['wechatid']}</span>
                                    </p>
                                    <p class="profile_meta">
                                            <label class="profile_meta_label">{$this->lang['a19085767b52c6d7']}</label>
                                            <span class="profile_meta_value">{$info['intro']}</span>
                                    </p>
                            </div>
                            <span class="profile_arrow_wrp" id="js_profile_arrow_wrp"> <i class="profile_arrow arrow_out"></i> <i class="profile_arrow arrow_in"></i> </span>
                    </div>
                </span>
            </div>
EOT;
		return $html;
	}

	function get_wechatinfo_html_for_mobile($articleid, $iswsq = false, $tableid = 0) {
		global $_G;
		$verhash = VERHASH;
		if($this->setting['view_mode'] == 1 || !$this->setting['show_my_attention']) {
			$attention = '';
		} else {
			$info = $this->get_wechat_info_by_articleid($articleid, $tableid);

			$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($info['wid']);
			if(empty($info) || empty($wechat)) {
				return '';
			}

			$info['date'] = date("Y-m-d", $info['date']);
			$info = array_merge($info, $wechat);
			$wechaturl = $iswsq ? $_G['siteurl'] . "plugin.php?id=wq_wechatshow&mod=view&wid=" : "plugin.php?id=wq_wechatshow&mod=view&wid=";
			$attention = '<em id="post-date" class="rich_media_meta rich_media_meta_text" style="font-style:normal;">' . $info['date'] . '</em>'
				. '<a href="' . $wechaturl . $info['wechatid'] . '&displayorder=index" class="rich_media_meta rich_media_meta_link rich_media_meta_nickname" style="color: #69ABD8; font-size:14px;">' . $info['name'] . '</a>';
		}

		$touch_tplid = $_G['setting']['styleid2'];
		loadcache('style_' . $touch_tplid);
		$touch_tpl = $_G['cache']['style_' . $touch_tplid];

		if($touch_tpl['tpldir'] == './template/comiis_app') {
			$viewstyle = '<link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/mobile/css/view.css?{$verhash}" type="text/css">  ';
		} else {
			$viewstyle = <<<EOF
        <style>
            .wqwechat_articleview_con{overflow: hidden;}
            .wqwechat_articleview_con * {max-width: 100% !important;box-sizing: border-box!important;-webkit-box-sizing: border-box!important; word-wrap: break-word!important;}
            .wqwechat_articleview_con h1 { text-indent: 0 !important; }
            .wqwechat_articleview_con pre { white-space: normal !important; }
            .wqwechat_articleview_con table {margin-bottom: 10px;border-collapse: collapse;display: table;width: 100%!important;}
            .wqwechat_articleview_con img{ margin-top:5px !important;left:0 !important;position: static !important;}
        </style>
EOF;
		}

		$jscode = <<<EOT
<script type="text/javascript" src="./source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{$verhash}"></script>
<script type="text/javascript" src="./source/plugin/wq_wechatcollecting/static/js/video.js?{$verhash}"></script>
EOT;
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false) {
			$jscode = "";
		}

		$html = <<<EOT
{$jscode}
{$viewstyle}
<div class="rich_media_meta_list">
        {$attention}
</div>
<div class="wqwechat_articleview_con" id="wqwechat_articleview_con">
	{content_html}
</div>
EOT;
		return $html;
	}

	function wq_wechatcollecting_move_topic($params) {
		global $operation, $toforumallowspecial;
		if($operation == 'move' && $toforumallowspecial && $params['param'][0] == 'admin_moderate_invalid') {
			global $_G, $tidsarr, $stampaction, $stampstatus, $toforum, $threadlist, $moveto, $updatemodlog, $expiration, $reason, $modpostsnum, $sendreasonpm;
			foreach($threadlist as $tid => $thread) {
				if(!C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_tid($tid)) {
					continue;
				}
				$moderate[] = $tid;
				if(in_array($thread['displayorder'], array(2, 3))) {
					$stickmodify = 1;
				}
				if($_GET['type'] == 'redirect') {
					$insertdata = array(
						'fid' => $thread['fid'],
						'readperm' => $thread['readperm'],
						'author' => $thread['author'],
						'authorid' => $thread['authorid'],
						'subject' => $thread['subject'],
						'dateline' => $thread['dateline'],
						'lastpost' => $thread['dblastpost'],
						'lastposter' => $thread['lastposter'],
						'views' => 0,
						'replies' => 0,
						'displayorder' => 0,
						'digest' => 0,
						'closed' => $thread['tid'],
						'special' => 0,
						'attachment' => 0,
						'typeid' => $_GET['threadtypeid']
					);
					$newtid = C::t('forum_thread')->insert($insertdata, true);
					if($newtid) {
						C::t('forum_threadclosed')->insert(array('tid' => $thread['tid'], 'redirect' => $newtid), true, true);
					}
				}
			}
			if(!$moderatetids = implode(',', $moderate)) {
				showmessage('admin_moderate_invalid');
			}
			$fieldarr = array(
				'fid' => $moveto,
				'isgroup' => 0,
				'typeid' => $_GET['threadtypeid'],
				'moderated' => 1
			);
			if($_G['adminid'] == 3) {
				$fieldarr['displayorder'] = 0;
			}

			C::t('forum_thread')->update($tidsarr, $fieldarr, true);
			C::t('forum_forumrecommend')->update($tidsarr, array('fid' => $moveto));
			loadcache('posttableids');
			$posttableids = $_G['cache']['posttableids'] ? $_G['cache']['posttableids'] : array('0');
			foreach($posttableids as $id) {
				C::t('forum_post')->update_by_tid($id, $tidsarr, array('fid' => $moveto));
			}
			$typeoptionvars = C::t('forum_typeoptionvar')->fetch_all_by_tid_optionid($tidsarr);
			foreach($typeoptionvars as $typeoptionvar) {
				C::t('forum_typeoptionvar')->update_by_tid($typeoptionvar['tid'], array('fid' => $moveto));
				C::t('forum_optionvalue')->update($typeoptionvar['sortid'], $typeoptionvar['tid'], $_G['fid'], "fid='$moveto'");
			}

			if($_G['setting']['globalstick'] && $stickmodify) {
				require_once libfile('function/cache');
				updatecache('globalstick');
			}
			$modaction = 'MOV';
			$_G['toforum'] = $toforum;

			updateforumcount($moveto);
			updateforumcount($_G['fid']);
			if($updatemodlog) {
				if($operation != 'delete') {
					updatemodlog($moderatetids, $modaction, $expiration);
				} else {
					updatemodlog($moderatetids, $modaction, $expiration, 0, $reason);
				}
			}

			updatemodworks($modaction, $modpostsnum);
			foreach($threadlist as $thread) {
				modlog($thread, $modaction);
			}

			if($sendreasonpm) {
				$modactioncode = lang('forum/modaction');
				$modtype = $modaction;
				$modaction = $modactioncode[$modaction];
				foreach($threadlist as $thread) {
					if($operation == 'move') {
						sendreasonpm($thread, 'reason_move', array('tid' => $thread['tid'], 'subject' => $thread['subject'], 'modaction' => $modaction, 'reason' => $reason, 'tofid' => $toforum['fid'], 'toname' => $toforum['name'], 'from_id' => 0, 'from_idtype' => 'movethread'), 'post');
					} else {
						sendreasonpm($thread, 'reason_moderate', array('tid' => $thread['tid'], 'subject' => $thread['subject'], 'modaction' => $modaction, 'reason' => $reason, 'from_id' => 0, 'from_idtype' => 'moderate_' . $modtype), 'post');
					}
				}
			}

			if($stampstatus) {
				set_stamp($stampstatus, $stampaction, $threadlist, $expiration);
			}
			showmessage('admin_succeed', $_G['referer']);
		}
	}

	public function _get_portal_summary($content) {
		$summary = preg_replace("/(\s|\<strong\>##########NextPage(\[title=.*?\])?##########\<\/strong\>)+/", ' ', $content);
		$summary = preg_replace(array("/\[attach\].*?\[\/attach\]/", "/\&[a-z]+\;/i", "/\<script.*?\<\/script\>/"), '', $summary);
		$summary = preg_replace("/\[.*?\]/", '', $summary);
		$summary = getstr(strip_tags($summary), 200);
		$summary = censor($summary);
		return $summary;
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>