<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

$classselect = get_class_select('classid', $wechatclass, 0, $Plang['916aa54a0b19dc05'], false, true);
$attachdir = wq_wechatcollecting_get_attachdir();
$attachurl = wq_wechatcollecting_get_attachurl();
$classselect .= '<span id=\'movearticle\' style=\'display:none\'><input class=\'fs\' id=\'movearticle_input\' type=\'checkbox\' name=\'movearticle\' value=\'1\' /><label for="movearticle_input">' . $Plang['e960c405ce0881e2'] . '</label></span>';
$classselect_article = get_class_select_article('article_classid', $wechatclass_article, 0, $Plang['916aa54a0b19dc05'], false, true, true);
$sitearr = array(
	1 => $Plang['18279e4e36db62a0'],
	2 => $Plang['2fadb15b8c0770ef'],
	3 => $Plang['4ef01a4662b08f70'],
	4 => $Plang['d6f3e2af5b8dd92f'],
	10 => $Plang['ad0cdf3197d6077d'],
	5 => $Plang['20a8dcddb53500c7'],
	11 => $Plang['a3d338b462605ddb'],
	6 => $Plang['65d8232ec37a7643'],
	8 => $Plang['a90a8e99b52d21c7'],
	7 => $Plang['a3d338b462605dda'],
	9 => $Plang['39c570266a0a1dd4'],
);
$siteselect = "<select id='adsiteselect' name='adsite[]' multiple='multiple' size='11' style='width: 220px;display:none;margin-left:5px;'>";
$searchkeyword = "<span id='searchkeyword' style='margin-right:10px;display:none;'>" . $Plang['a8bb59254f860e95'] . $Plang['3aba14be242cdfaf'] . "<input type='text' name='searchkeyword' style='width:120px;' placeholder='" . $Plang['371d94ee15decb1f'] . "'></span>";
foreach($sitearr as $key => $value) {
	$siteselect .= "<option style='width: 220px;' value='" . $key . "'>" . $value . "</option>";
}
$siteselect .= "</select>";

$classname[0] = $Plang['a1e5d76323a1fd8d'];
$classname[-1] = $Plang['e5dd6c90447db4c8'];
foreach($nav_classlist as $nvakey => $navval) {
	$classname[$navval['cid']] = $navval['classname'];
	$cids[] = $a_cids[] = intval($navval['cid']);
}
array_unshift($cids, '-1');
$status = in_array($_GET['status'], array('0', '1', '-1', '-2')) ? array(intval($_GET['status'])) : array(0, 1, -1);
$wechatname = trim($_GET['wechatname']);
$perpage = intval($setting['admincp_perpage']) < 1 ? 1 : intval($setting['admincp_perpage']);
$cid = in_array($_GET['cid'], $cids) ? trim($_GET['cid']) : '';
$article_classid = in_array($_GET['a_cid'], $a_cids) ? trim($_GET['a_cid']) : '';
$viewmod = in_array($_GET['viewmode'], array('0', '1', '2', '3', '4', '5')) ? intval($_GET['viewmode']) : '';
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechat';
$mpurl = !empty($wechatname) ? $mpurl . '&wechatname=' . $wechatname : $mpurl;
$mpurl = $_GET['status'] !== null ? $mpurl . '&status=' . $_GET['status'] : $mpurl;
$mpurl = $cid ? $mpurl . '&cid=' . $cid : $mpurl;
$mpurl = $article_classid ? $mpurl . '&a_cid=' . $article_classid : $mpurl;
$mpurl = $viewmod !== '' ? $mpurl . '&viewmod=' . $viewmod : $mpurl;
$url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechat';
$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechat';
$editstatus = array('0' => $Plang['05df925dd69b4333'], '1' => $Plang['d4cd6471a700d52c'], '-1' => $Plang['b5d0d1b6c49b2665'], '-2' => $Plang['4930bcc2615700e9']);
$recommendstatus = array('0' => $Plang['77b41af77fe3ce13'], '1' => $Plang['b4b0d4ba96890702']);
if(!$_GET['ac']) {
	if(!submitcheck('form')) {
		echo "<style tpye='text/css'>
     .status{background-color: #666666;width:65px;height:20px;text-align:center;line-height:18px;border-radius:4px;}
    .status a{  color:#FFF;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    .wqcode_logo{ position: relative;width:100px; height:100px; margin: auto;}
    .wqcode_logo span{ position: absolute; width: 22%; left: 50%; margin-left: -11%; margin-top: -11%; top:50%; overflow: hidden; height: 22%; border-radius: 4px;border:1px solid #fff;}
    .wqcode_logo span img{ width: 100% !important; height: 100% !important;}
    </style>";

		$classcid = select_html($classname, 'cid', $cid, false);
		$articlecid = select_html($classname, 'a_cid', $article_classid, false);
		$viewmod_sel = select_html($view_mode, 'viewmode', "{$viewmod}", true);
		showformheader($fromurl, '', 'forms');
		showtableheader('', 'nobottom');
		$searchwidth = array('width="190"', 'width="190"', 'width="290"', 'width="50"', 'width="50"', 'width="50"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"');
		$searchlist = array(
			$Plang['f8497259f9b3f761'] . $Plang['4e8be287d687966d'] . ':&nbsp;&nbsp;' . $classcid,
			$Plang['0da4aa79f9ad198b'] . $Plang['38224a4a6fc78c7c'] . ':&nbsp;&nbsp;' . $articlecid,
			$Plang['55267a8b3501fb3d'] . ':&nbsp;&nbsp;' . $viewmod_sel,
			$Plang['f8497259f9b3f761'],
			"<input size = \"25\" name=\"wechatname\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['wechatname']) . "\" />" .
			"<input size = \"25\" name=\"status\" type=\"hidden\" value=\"" . dhtmlspecialchars($_GET['status']) . "\" />",
			"<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />",
			"<div " . ($_GET['status'] == '' ? 'class="status"><a' : "><a style='color:#000;'") . " href=\"" . $url . "\">" . $Plang['e8af971c6963983d'] . "</a></div>",
			"<div " . ($_GET['status'] == '0' ? 'class="status"><a' : "><a style='color:#FF9300;'") . " href=\"" . $url . "&status=0\">" . $Plang['05df925dd69b4333'] . "</a></div>",
			"<div " . ($_GET['status'] == '1' ? 'class="status"><a' : "><a style='color:green;'") . " href=\"" . $url . "&status=1\">" . $Plang['d4cd6471a700d52c'] . "</a></div>",
			"<div " . ($_GET['status'] == '-1' ? 'class="status"><a' : "><a style='color:red;'") . " href=\"" . $url . "&status=-1\">" . $Plang['b5d0d1b6c49b2665'] . "</a></div>",
			"<div " . ($_GET['status'] == '-6' ? 'class="status"><a' : "><a style='color:blue;'") . " href=\"" . $url . "&status=-6\">" . $Plang['c3d5675f60d2048e'] . "</a></div>",
			"<div " . ($_GET['status'] == '-2' ? 'class="status"><a' : "><a style='color:#0099CC;'") . " href=\"" . $url . "&status=-2\">&nbsp;" . $Plang['4930bcc2615700e9'] . "&nbsp;</a></div>"
		);

		showtablerow('', $searchwidth, $searchlist);
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/

		showformheader($fromurl, '', 'form');
		showtableheader($Plang['70a45e7a6f4a9f3a'], 'nobottom');
		$tabletitle = array('', $Plang['ddd826aa11868c7d'], $Plang['97af7ca7730595cd'], $Plang['18ad271b7e118fe7'], $Plang['db11cdebc2eb37bd'], $Plang['b5bd9e232e51e294'], $Plang['4a835bf07cd239b1'], $Plang['daae790c0bbfcb03'], $Plang['7de4775a64db4b43'], $Plang['24dbae32d67e23d7'], $Plang['75d24f054db77fd2'], $Plang['a7869dc83e527f4d'], $Plang['ca5a0d75b677d381']);
		if(file_exists(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php')) {
			array_push($tabletitle, $Plang['background']);
		}
		array_push($tabletitle, $Plang['93f5ca01b006206c']);
		showsubtitle($tabletitle);
		$recommend_wids = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_all_by_siteid_keyword_group_by_wid();
		$wids = array();
		foreach($recommend_wids as $key => $value) {
			$wids[] = $value['wid'];
		}
		$recommend = $_GET['status'] == '-6' ? $wids : '';
		$cid = $cid == -1 ? 0 : $cid;
		$article_classid = $article_classid == -1 ? 0 : $article_classid;
		$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->count_by_search($status, $wechatname, $recommend, 0, 0, false, $cid, $article_classid, $viewmod);
		$mainclass = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_search($status, $start, $perpage, $wechatname, 'collecttime', $recommend, 0, 0, false, $cid, $article_classid, $viewmod);
		foreach($mainclass as $val) {
			$val['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($val['headimage']);
			$val['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($val['wechatbgimg']);

			$val['qrcode'] = wq_get_qrcode_by_wechatid($val['wechatid']);
			$row_width = array('width="10"', 'width="50"', 'width="80"', 'width="200"', 'width="80"', 'width="165"', 'width="100"', 'width="100"', 'width="30"', 'width="50"', 'width="50"', 'width="60"', 'width="50"');
			$rowlist = array(
				'<input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['id'] . '\' /> ',
				'<img style="width:100px; height:100px;" src="' . $val['qrcode'] . '" /> ',
				"<a href='plugin.php?id=wq_wechatshow&mod=view&wid=" . $val['wechatid'] . "&displayorder=index' target='_blank'>" . $val['name'] . '<br>(' . $val['wechatid'] . ")</a>",
				$val['intro'],
				$recommendstatus[$isrecommend],
				select_html($view_mode, 'view_mode[' . $val['id'] . ']', $val['view_mode'], false, false),
				$class = $wechatclass[$val['classid']]['classname'] ? $wechatclass[$val['classid']]['classname'] : $Plang['e5dd6c90447db4c8'],
				$article_class = $wechatclass_article[$val['article_classid']]['classname'] ? $wechatclass_article[$val['article_classid']]['classname'] : $Plang['e5dd6c90447db4c8'],
				date("Y-m-d H:i:s", $val['collecttime']),
				"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
				$val['articlenum'],
				$val['totalarticle'],
				$editstatus[$val['status']] . '<input  type=\'hidden\' name=\'hiddenstatus\' value=\'' . $_GET['status'] . '\' /> ',
			);

			if(file_exists(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php')) {
				array_push($row_width, 'width="100"');
				array_push($rowlist, '<img style="max-width:300px;max-height:300px;" src="' . $val['wechatbgimg'] . '" />');
			}
			array_push($row_width, 'width="100"');
			array_push($rowlist, "<a href='" . ADMINSCRIPT . "?action=plugins&operation=config&do={$pluginid}&identifier=wq_wechatcollecting&pmod=admincp_wechat&ac=update&wid={$val['id']}'>{$Plang['c09a4ec2fe473b0a']}</a>");
			showtablerow('class="tr"' . $val['id'] . '"', $row_width, $rowlist);
		}
		$multi = multi($count, $perpage, $page, $mpurl);
		if($status == array(-2)) {
			$recycle = '<input type="radio" name="editstatus" id="recycle_bin" value="5" class="radio" /><label for="recycle_bin" class="vmiddle">' . $Plang['2e2908c705dfac38'] . '</label>';
		} else {
			$recycle = '<input type="radio" name="editstatus" checked id="edit" value="1" class="radio" /><label for="edit" class="vmiddle">' . $Plang['d4cd6471a700d52c'] . '</label>'
				. '<input type="radio" name="editstatus" id="moderate" value="-1" class="radio" /><label for="moderate" class="vmiddle">' . $Plang['b5d0d1b6c49b2665'] . '</label>'
				. '<input type="radio" name="editstatus" id="recommend" value="6" class="radio" /><label for="recommend" class="vmiddle">' . $Plang['760cc2882ad1210a'] . '</label>'
				. $siteselect . $searchkeyword
				. '<input type="radio" name="editstatus" id="recycle_bin" value="-2" class="radio" /><label for="recycle_bin" class="vmiddle">' . $Plang['8815e67ded9ed035'] . '</label>';
		}

		$operation = '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkall">' . cplang('select_all') . '</label>'
			. '<input type="radio" name="editstatus"  value="3" class="radio" id="del" /><label for="del" class="vmiddle">' . $Plang['0d9efacf5089d88c'] . '</label>'
			. $recycle
			. '<input type="radio" name="editstatus" id="article_class" value="7" class="radio" /><label for="article_class" class="vmiddle">' . $Plang['4135f6cd31b1a169'] . '</label>'
			. $classselect_article
			. '<input type="radio" name="editstatus" id="put_in_class" value="4" class="radio" /><label for="put_in_class" class="vmiddle">' . $Plang['57dca09a1285209b'] . '</label>'
			. $classselect;



		showsubmit('form', 'submit', $operation, '', $multi);
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
		echo <<<EOF
    <script>
        window.onload =function () {
            var checkbox = document.getElementsByName('editstatus');
            for (var i = 0; i < checkbox.length; i++) {
                checkbox[i].onclick = function (e) {
                    if (e.target.id == 'recommend') {
                        document.getElementById('classid').style.display = 'none';
                        document.getElementById('article_classid').style.display = 'none';
                        document.getElementById('adsiteselect').style.display = 'inline';
                    } else if (e.target.id == 'put_in_class') {
                        document.getElementById('adsiteselect').style.display = 'none';
                        document.getElementById('searchkeyword').style.display = 'none';
                        document.getElementById('classid').style.display = 'inline';
                        document.getElementById('movearticle').style.display = 'inline';
                        document.getElementById('article_classid').style.display = 'none';
                    } else if (e.target.id == 'article_class') {
                        document.getElementById('adsiteselect').style.display = 'none';
                        document.getElementById('searchkeyword').style.display = 'none';
                        document.getElementById('classid').style.display = 'none';
                        document.getElementById('movearticle').style.display = 'none';
                        document.getElementById('article_classid').style.display = 'inline';
                    }else {
                        document.getElementById('adsiteselect').style.display = 'none';
                        document.getElementById('searchkeyword').style.display = 'none';
                        document.getElementById('classid').style.display = 'none';
                        document.getElementById('movearticle').style.display = 'none';
                        document.getElementById('article_classid').style.display = 'none';
                    }
                }
            }
            document.getElementById('adsiteselect').onchange = function () {
                if (document.getElementById('adsiteselect').children[0].selected) {
                    document.getElementById('searchkeyword').style.display = 'inline';
                } else {
                    document.getElementById('searchkeyword').style.display = 'none';
                }

            }
        }
    </script>
EOF;
	} else {
		$i = $j = $k = $l = 0;
		foreach($_GET['delete'] as $value) {

			$data = array(
				'status' => intval($_GET['editstatus'])
			);
			$data_class = array();
			if(intval($_GET['classid'] && $_GET['editstatus'] == '4')) {
				$data_class['classid'] = intval($_GET['classid']);
			}
			if(intval($_GET['article_classid']) && $_GET['editstatus'] == '7') {
				$data_class['article_classid'] = intval($_GET['article_classid']);
			}

			if($_GET['editstatus'] == '-2') {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($value);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($value), array('status' => -2));
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_wid(array('status' => -2), $value);
			} else if($_GET['editstatus'] == '5') {
				$wechat_status = $setting['wechat_status'] == '1' ? 0 : 1;
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($value);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($value), array('status' => $wechat_status));
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_wid(array('status' => $wechat_status), $value);
			} elseif($_GET['editstatus'] == '3') {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($value);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->delete(array($value));
				C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->del_by_wid($value);
				$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_by_wid($value);
				foreach($article as $val) {
					del_article($val, false, $setting);
					$val['tid'] ? $tid[] = $val['tid'] : '';
					$val['aid'] ? $aid[] = $val['aid'] : '';
				}
				$plugin_wechatreader == 1 ? C::t('#wq_wechatreader#wq_wechatreader_subscription')->delete_by_wid($value) : '';
			} elseif($_GET['editstatus'] == '4') {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($value), $data_class);

				if($_GET['movearticle'] == '1') {
					DB::update('wq_wechatcollecting_article', $data_class, array('wid' => intval($value)));
					wq_update_fid_or_aid_by_wid_articleid(intval($value));
				}
			} elseif($_GET['editstatus'] == '7') {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($value), $data_class);
			} elseif($_GET['editstatus'] == '6') {
				$i ++;
				if(is_array($_GET['adsite']) && count($_GET['adsite']) > 0) {
					foreach($_GET['adsite'] as $key => $val) {
						if($val == '1' && !trim($_GET['searchkeyword'])) {
							$l ++;
							continue;
						}
						$flag = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_by_wid_siteid(intval($value), intval($val));
						if($flag) {
							$k ++;
							continue;
						}
						$data = array(
							'wid' => intval($value),
							'siteid' => intval($val),
							'type' => 2,
							'keyword' => intval($val) == 1 ? trim($_GET['searchkeyword']) : ''
						);
						C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->insert($data);
						$j ++;
					}
				}
			} else {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($value);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($value), $data);
			}
		}

		if(!empty($_GET['view_mode'])) {
			$ids = array_keys($_GET['view_mode']);
			$wechats = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_id($ids);
			foreach($_GET['view_mode'] as $key => $val) {
				if($val != $wechats[$key]['view_mode']) {
					C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($key);
					C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update(intval($key), array('view_mode' => $val));
				}
			}
		}

		include_once libfile('function/delete');
		$tid ? deletethread($tid) : '';
		$aid ? deletearticle($aid) : '';
		$url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechat&';
		$url .= $_GET['hiddenstatus'] ? 'status=' . $_GET['hiddenstatus'] : '';
		if($_GET['editstatus'] != '6') {
			cpmsg($Plang['aca2899ea8ef4a04'], $url, 'succeed');
		} else {
			cpmsg(sprintf($Plang['20d01961f060a043'], $i, $j, $k, $l), $url, 'succeed');
		}
	}
} else {
	$wid = $_GET['wid'];
	$url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_wechat';
	if(!$wid) {
		cpmsg($Plang['please_select_set_wechat'], $url, 'error');
	}
	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch($wid);
	if(!$wechat) {
		cpmsg($Plang['select_wechat_empty'], $url, 'error');
	}
	$target_headimage = wq_wechatcollecting_headimg_and_bgimg_url($wechat['headimage'], true);
	$target_wechatbgimg = wq_wechatcollecting_headimg_and_bgimg_url($wechat['wechatbgimg'], true);
	$headimage = wq_wechatcollecting_headimg_and_bgimg_url($wechat['headimage']);
	$wechatbgimg = wq_wechatcollecting_headimg_and_bgimg_url($wechat['wechatbgimg']);

	if(!submitcheck('form')) {
		showformheader($fromurl . '&ac=update&wid=' . $wid, 'enctype', 'forms');
		showtableheader(sprintf($Plang['1e67709c5769edb0'], $wechat['name']), 'nobottom');
		showsetting($Plang['4b3b548154549518'], 'wechatid', $wechat['wechatid'], 'text');
		showsetting($Plang['3982634cd20768c9'], 'name', $wechat['name'], 'text');
		showsetting($Plang['7963064a1954b8aa'], 'verify', $wechat['verify'], 'text');
		showsetting($Plang['093288bbe08517a5'], 'intro', $wechat['intro'], 'textarea');
		showsetting($Plang['639bca6a6958faac'], 'headimage', '', 'file', '', 0, $Plang['ad032d6421d82862']);

		if($wechat['headimage'] && file_exists($target_headimage)) {

			showsetting($Plang['66dd354e622ee6f3'], '', '', "<a href='" . $headimage . "' target='_blank'>" . '<img style="max-width:300px;max-height:300px;" src="' . $headimage . '" /> </a>');
		}
		if(file_exists(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php')) {
			showsetting($Plang['set_background'], 'wechatbgimg', '', 'file', '', 0, $Plang['recommend_background_size']);
			if($wechat['wechatbgimg'] && file_exists($target_wechatbgimg)) {

				showsetting($Plang['background_preview'], '', '', "<a href='" . $wechatbgimg . "' target='_blank'>" . '<img style="max-width:300px;max-height:300px;" src="' . $wechatbgimg . '" /> </a>');
			}
		}
		showsubmit('form', 'submit');
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	} else {
		$update = array();
		$wechat['wechatid'] != trim($_GET['wechatid']) && trim($_GET['wechatid']) ? $update['wechatid'] = trim($_GET['wechatid']) : '';
		$wechat['name'] != trim($_GET['name']) && trim($_GET['name']) ? $update['name'] = trim($_GET['name']) : '';
		$wechat['verify'] != trim($_GET['verify']) && trim($_GET['verify']) ? $update['verify'] = trim($_GET['verify']) : '';
		$wechat['intro'] != trim($_GET['intro']) && trim($_GET['intro']) ? $update['intro'] = trim($_GET['intro']) : '';
		$wechatbgimg = $wechatbgimg_url = '';
		if($_FILES['headimage']) {
			$upload = new discuz_upload();
			$upload->init($_FILES['headimage'], 'portal');
			$attach = $upload->attach;
			if($attach['isimage']) {
				$wechatbgimg = 'portal/' . $attach['attachment'];
				$wechatbgimg_url = $attachdir . 'portal/' . $attach['attachment'];
				$upload->save();
			}
		}
		file_exists($wechatbgimg_url) ? $update['headimage'] = $wechatbgimg : '';
		if(file_exists(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php')) {
			$wechatbgimg = $wechatbgimg_url = '';
			if($_FILES['wechatbgimg']) {
				$upload = new discuz_upload();
				$upload->init($_FILES['wechatbgimg'], 'portal');
				$attach = $upload->attach;
				if($attach['isimage']) {
					$wechatbgimg = 'portal/' . $attach['attachment'];
					$wechatbgimg_url = $attachdir . 'portal/' . $attach['attachment'];
					$upload->save();
				}
			}
			file_exists($wechatbgimg_url) ? $update['wechatbgimg'] = $wechatbgimg : '';
		}

		if($update) {
			$flag = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, $update);
			if($flag) {
				$update['headimage'] ? @unlink($target_headimage) : '';
				$update['wechatbgimg'] ? @unlink($target_wechatbgimg) : '';
			}
		}
		if($flag && ($update['wechatid'] || $update['name'] || $update['intro'])) {
			$common_update = $log_update = array();
			if($update['wechatid']) {
				$common_update['wechatid'] = $log_update['wechatuser'] = $update['wechatid'];
			}
			if($update['name']) {
				$common_update['name'] = $log_update['wechatname'] = $update['name'];
			}

			if($common_update) {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_wid($wid, $common_update);
				$update['intro'] ? $common_update['summary'] = $update['intro'] : '';
				DB::update('wq_wechatcollecting_temparticle', $common_update, array('wid' => $wid));
			}
			if($log_update) {
				DB::update('wq_wechatcollecting_log', $log_update, array('wid' => $wid));
			}
		}

		C::memory()->clear();
		cpmsg('groups_setting_succeed', $url, 'succeed');
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>