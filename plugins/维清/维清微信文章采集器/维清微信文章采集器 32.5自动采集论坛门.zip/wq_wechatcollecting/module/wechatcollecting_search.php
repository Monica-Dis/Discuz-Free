<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_list.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$a_searchset['status']) {
	showmessage('search_portal_closed');
}

if($_G['mobile']) {
	$_GET['keyword'] = diconv($_GET['keyword'], "UTF-8", CHARSET);
}
$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);

$plugin = 'wq_wechatcollecting';
$searchid = isset($_GET['searchid']) ? intval($_GET['searchid']) : 0;
if(!empty($searchid)) {
	$webpagename = $Plang['7879e08bed9e4448'];
	$perpage = intval($setting['home_article_search_perpage']) < 1 ? 1 : intval($setting['home_article_search_perpage']);
	$page = max(1, intval($_GET['page']));
	$navtitle = $keyword . $Plang['cewtwtgv34a9fd4e'];
	$start = ($page - 1) * $perpage;

	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname']);
	$wechat_seo['index']['seotitle'] = $navtitle . '-' . $wechat_seo['index']['seotitle'];
	list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechat_seo['index']);
	$index = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->fetch_by_searchid_srchmod($searchid, 1);
	if(!$index) {
		showmessage('search_id_invalid');
	}
	$keyword = $index['keywords'];
	$articleids = array_slice(explode(',', $index['ids']), $start, $perpage, true);
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all($articleids);

	$count = $index['num'];
	if(!$list) {
		$Plang['2dc3f83a42b3a77f'] = $Plang['cd7f01e498878fec'];
	}
	$list = wq_two_array_orderby($list, 'date', 'DESC');
	$preg = '/' . $keyword . '/i';
	foreach($list as $key => $val) {
		$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
		preg_match_all($preg, $val['title'], $title_result);
		foreach(array_unique($title_result[0]) as $value) {
			$list[$key]['title'] = str_replace($value, '<span style="color:#F00;">' . $value . '</span>', $val['title']);
		}
		preg_match_all($preg, $val['summary'], $summary_result);
		foreach(array_unique($summary_result[0]) as $value) {
			$list[$key]['summary'] = str_replace($value, '<span>' . $value . '</span>', $val['summary']);
		}
	}
	$right_collect = get_right_hot_new_article($setting['right_hot_collect'], $keyword, 'favorites');
	$right_new = get_right_hot_new_article($setting['right_new_article_num'], $keyword);
	$right_hot = get_right_hot_new_article($setting['right_hot_article_num'], $keyword, 'views');
	$right_recommedlist = get_recommed_wechat_list(1, 0, 2, $keyword);
	$mpurl = "plugin.php?id=wq_wechatcollecting&mod=search&keyword=$keyword&searchid=$searchid&page=$page";
	$multi = multi($count, $perpage, $page, $mpurl);
	if(!empty($_G['uid'])) {
		loadcache('wq_cache_keywords_' . $_G['uid']);
		$cache = $_G['cache']['wq_cache_keywords_' . $_G['uid']];
		if(in_array($keyword, $cache)) {
			$status = 1;
		}
	}

	if($_G['mobile']) {
		$webpagename = $keyword;
		$multi = multi($count, $perpage, $page, $mpurl, 0, 10, false, false);
		include template('wq_wechatcollecting:wechatcollecting_search');
	} else {
		include template('diy:wechatcollecting_search', 0, 'source/plugin/wq_wechatcollecting/template');
	}
} else {
	if($keyword) {
		$searchdata = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->fetch_all_search($a_searchset['searchctrl'], $_G['clientip'], $_G['uid'], $_G['timestamp'], $keyword, 1);
		$searchid = 0;
		foreach($searchdata as $index) {
			if($index['indexvalid'] && $index['dateline'] > 0) {
				$searchid = $index['searchid'];
				break;
			} elseif($index['flood']) {
				showmessage('search_ctrl', 'plugin.php?id=wq_wechatcollecting&mod=search', array('searchctrl' => $a_searchset['searchctrl']));
			}
		}
		if(!$searchid) {
			if($_G['adminid'] != '1' && $a_searchset['maxspm']) {
				if(C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->count_by_dateline($_G['timestamp'], 1) >= $a_searchset['maxspm']) {
					showmessage('search_toomany', 'plugin.php?id=wq_wechatcollecting&mod=search', array('maxspm' => $a_searchset['maxspm']));
				}
			}
			$articleids = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, $a_searchset['maxsearchresults'], $keyword, 'date', '', '', '', false, 0, false, true);

			$num = $ids = 0;
			foreach($articleids as $key => $val) {
				$num++;
				$ids .= ',' . $val['articleid'];
			}
			$ids = ltrim($ids, '0,');
			$expiration = TIMESTAMP + $a_searchset['result_expiration'];
			$data = array(
				'srchmod' => 1,
				'keywords' => $keyword,
				'useip' => $_G['clientip'],
				'uid' => $_G['uid'],
				'expiration' => $expiration,
				'num' => $num,
				'ids' => $ids,
				'dateline' => $_G['timestamp'],
			);
			$searchid = C::t('#wq_wechatcollecting#wq_wechatcollecting_searchcache')->insert($data, true);
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=search&searchid=$searchid&keyword=$keyword");
	} else {
		if(trim($_GET['act'] == 'alt')) {
			include_once template('wq_wechatcollecting:common_search');
		} else {
			if($_G['mobile']) {
				include template('wq_wechatcollecting:wechatcollecting_search');
			} else {
				include template('diy:wechatcollecting_search', 0, 'source/plugin/wq_wechatcollecting/template');
			}
		}
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>