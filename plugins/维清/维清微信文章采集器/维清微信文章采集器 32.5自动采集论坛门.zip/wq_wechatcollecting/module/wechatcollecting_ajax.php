<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$time = time();
if(empty($_G['uid'])) {
	if($_G['mobile']) {
		dheader("Location:member.php?mod=logging&action=login&mobile=2");
	}
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
if(in_array(trim($_GET['ac']), array('articlesupport', 'articleagainst'))) {
	$ac = trim($_GET['ac']);
	$aid = intval($_GET['aid']);
	$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($aid);
	if(empty($article) || $article['status'] != 1) {
		showmessage($Plang['e3cf2fe807bf8b26']);
	}
	$polltype = $ac == 'articlesupport' ? 1 : 0;
	$update_field = $polltype ? 'support' : 'against';
	$articlepoll = C::t('#wq_wechatcollecting#wq_wechatcollecting_poll')->fetch_first_by_aid_uid($aid, $_G['uid']);
	if(!$articlepoll) {
		$data = array(
			'articleid' => $aid,
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'polltype' => $polltype,
			'dateline' => TIMESTAMP
		);
		$subscription = C::t('#wq_wechatcollecting#wq_wechatcollecting_poll')->insert($data);

		$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_poll')->count_by_aid_polltype($aid, $polltype);
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, array($update_field => $count));
		cache_wq_wechatcollecting_poll($_G['uid'], $polltype);
		$extrajs = '<script type="text/javascript" reload="1">'
			. $ac . '(' . $aid . ');'
			. '</script>';
		if($_G['mobile']) {
			showmessage($Plang['289f61f54d327553'], '', array('aid' => $aid, 'ac' => $ac));
		}
		showmessage($Plang['289f61f54d327553'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
	} else {
		showmessage($Plang['ebc0b14e9f8a90df']);
	}
} elseif(in_array(trim($_GET['ac']), array('recommend', 'cancelrecommend'))) {
	$aid = intval($_GET['aid']);
	if(!$aid) {
		showmessage($Plang['e3cf2fe807bf8b26']);
	}
	$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($aid);
	if(!$article) {
		showmessage($Plang['e3cf2fe807bf8b26']);
	}

	$view_red_update = array();
	if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
		$view_red_update['recommend'] = 0;
		$view_red_update['rectime'] = 0;
		if($_GET['ac'] == 'recommend') {
			$view_red_update['recommend'] = 1;
			$view_red_update['rectime'] = TIMESTAMP;
		}
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, $view_red_update);
		$extrajs = '<script type="text/javascript" reload="1">'
			. 'maintain_recommend_set(' . $aid . ');'
			. '</script>';
		update_wechat_field_by_wechatid($article['wid'], array('recommend_num'));
		showmessage($Plang['9a52f4d6ef956904'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
	}
	if(submitcheck('recommendsub')) {
		$list_red_update['admrecommend'] = $list_red_update['adminrectime'] = $list_red_update['recommend'] = $list_red_update['rectime'] = 0;
		if($_GET['list_recommend']) {
			$list_red_update['admrecommend'] = 1;
			$list_red_update['adminrectime'] = TIMESTAMP;
		}
		if($_GET['view_recommend']) {
			$list_red_update['recommend'] = 1;
			$list_red_update['rectime'] = TIMESTAMP;
		}

		C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, $list_red_update);
		update_wechat_field_by_wechatid($article['wid'], array('recommend_num'));
		showmessage($Plang['9a52f4d6ef956904']);
	} else {
		$recommendinfo = array(
			'list' => array(
				'name' => $Plang['e9c4785300ab2b93'],
				'isrecommen' => $article['admrecommend']
			),
			'view' => array(
				'name' => $Plang['dc15f4249b92e57a'],
				'isrecommen' => $article['recommend']
			),
		);
		include template('wq_wechatcollecting:common_recommend');
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>