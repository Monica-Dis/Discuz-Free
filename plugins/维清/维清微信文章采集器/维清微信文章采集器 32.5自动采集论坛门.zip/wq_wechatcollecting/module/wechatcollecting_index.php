<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_index.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$webpagename = $Plang['83f1e7a6a15f1d8a'];

$ordernum = in_array($setting['article_list_displayorder'], array(1, 2, 3, 4)) ? $setting['article_list_displayorder'] : 1;
$allorder[1] = $allorder[4] = 'date';
$allorder[2] = 'views';
$allorder[3] = 'adminrectime';
$perpage = intval($setting['home_article_list_perpage']) < 1 ? 1 : intval($setting['home_article_list_perpage']);
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
$mpurl = 'plugin.php?id=wq_wechatcollecting';
wq_check_page($start, $perpage, $setting['home_maxpage']);

$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname']);
list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechat_seo['index']);


$list_recommedlist = $list_firstlist = true;
$recommend = '';
$first = $count = 0;

$recommedflag = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, 1, '', 'date', '', 1);
if(!is_array($recommedflag) || count($recommedflag) < 1) {
	$list_recommedlist = false;
} elseif($ordernum == 3) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '', '', 1);
	$recommend = 1;
	$displayorder = 'adminrectime';
}

$firstflag = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, 1, '', 'date', '', '', '', 1);
if(!is_array($firstflag) || count($firstflag) < 1) {
	$list_firstlist = false;
} elseif($ordernum == 4) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '', '', 0, '', 1);
	$first = 1;
}

if(in_array($ordernum, array(1, 2)) || !$count) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '');
	if(!in_array($ordernum, array(1, 2))) {
		$ordernum = 1;
	}
}

$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), $start, $perpage, '', $allorder[$ordernum], '', $recommend, '', $first);
foreach($list as $key => $val) {
	$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
}

$right_collect = get_right_hot_new_article($setting['right_hot_collect'], '', 'favorites');
$right_new = get_right_hot_new_article($setting['right_new_article_num']);
$right_hot = get_right_hot_new_article($setting['right_hot_article_num'], '', 'views');
$right_recommedlist = get_recommed_wechat_list(2, 0, $setting['right_wechat_num']);
if($_G['mobile']) {
	$multi = multi($count, $perpage, $page, $mpurl, $setting['home_maxpage'], 10, false, false);
	$webpagename = $Plang['e113a2946ba4875f'];
	include template('wq_wechatcollecting:wechatcollecting_index');
} else {
	$mpurl = $mpurl . "&mod=list&displayorder=" . $ordernum;
	$multi = multi($count, $perpage, $page, $mpurl, $setting['home_maxpage']);
	include template('diy:wechatcollecting_index', 0, 'source/plugin/wq_wechatcollecting/template');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>