<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_list.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$webpagename = $Plang['7879e08bed9e4448'];

$ordernum = in_array($_GET['displayorder'], array(1, 2, 3, 4)) ? $_GET['displayorder'] : $setting['article_list_displayorder'];
$allorder[1] = $allorder[4] = 'date';
$allorder[2] = 'views';
$allorder[3] = 'adminrectime';

$classid = $wechatclass_article[$_GET['classid']]['status'] == 1 ? intval($_GET['classid']) : 0;
$classid = $classid === 0 ? "" : $classid;

$perpage = intval($setting['home_article_list_perpage']) < 1 ? 1 : intval($setting['home_article_list_perpage']);
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
$mpurl = 'plugin.php?id=wq_wechatcollecting&mod=list';
wq_check_page($start, $perpage, $setting['home_maxpage']);

if($classid) {
	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $wechatclass_article[$_GET['classid']]['classname'], 'page' => sprintf($Plang['5e56dc395b16cbf3'], $page));
	list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechat_seo['list'], $page);
} else {
	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname']);
	list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechat_seo['index']);
}

$right_collect = get_right_hot_new_article($setting['right_hot_collect'], '', 'favorites', $classid);
$right_new = get_right_hot_new_article($setting['right_new_article_num'], '', 'date', $classid);
$right_hot = get_right_hot_new_article($setting['right_hot_article_num'], '', 'views', $classid);
$right_recommedlist = get_recommed_wechat_list(3, $classid, $setting['right_wechat_num']);

$list_recommedlist = $list_firstlist = true;
$recommend = '';
$first = $count = 0;

$recommedflag = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, 1, '', 'date', $classid, 1);
if(!is_array($recommedflag) || count($recommedflag) < 1) {
	$list_recommedlist = false;
} elseif($ordernum == 3) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '', $classid, 1);
	$recommend = 1;
	$displayorder = 'adminrectime';
}

$firstflag = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, 1, '', 'date', $classid, '', '', 1);
if(!is_array($firstflag) || count($firstflag) < 1) {
	$list_firstlist = false;
} elseif($ordernum == 4) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '', $classid, 0, '', 1);
	$first = 1;
}

if(in_array($ordernum, array(1, 2)) || !$count) {
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), '', $classid);
	if(!in_array($ordernum, array(1, 2))) {
		$ordernum = 1;
	}
}

$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), $start, $perpage, '', $allorder[$ordernum], $classid, $recommend, '', $first);

foreach($list as $key => $val) {
	$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
}

if($classid) {
	$mpurl .= '&classid=' . $classid;
}


if($_GET['displayorder'] != null) {
	$mpurl .= '&displayorder=' . intval($_GET['displayorder']);
}
if($_GET['selectid']) {
	$onearr[$_GET['selectid']] = ($nav_classlist[$_GET['selectid']]);
	unset($nav_classlist[$_GET['selectid']]);
	$nav_classlist = $onearr + $nav_classlist;
}
if($_G['mobile']) {
	$webpagename = $wechatclass_article[$classid]['classname'];
	$multi = multi($count, $perpage, $page, $mpurl, $setting['home_maxpage'], 10, false, false);
	include template('wq_wechatcollecting:wechatcollecting_list');
} else {
	$multi = multi($count, $perpage, $page, $mpurl, $setting['home_maxpage']);
	include template('diy:wechatcollecting_list', 0, 'source/plugin/wq_wechatcollecting/template');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>