<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_cp.php 2015-4-11 20:55:41Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
$allowac = $navlist = array('my_renling', 'my_submit', 'wechatmanage', 'articlemanage', 'tempissuelist', 'keywordcollect', 'urlcollect'); //'collectmanage'
$my_center = array('focus' => 'my_attention', 'read' => 'my_subscription', 'fav' => 'my_favorites');

$show_renling = true;
$flag = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_by_maintain_uid($_G['uid']);
if((!$plugin_wechatshow || !$flag) && !in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
	$show_renling = false;
}
$ac = !in_array($_GET['ac'], $allowac) && !in_array($_GET['ac'], $my_center) ? 'wechatmanage' : $_GET['ac'];
$_GET['op'] = in_array($_GET['op'], array('list', 'add', 'automaticcollect', 'restore', 'del', 'autoswitch', 'collect')) ? $_GET['op'] : 'list';
$classselect = get_class_select('classid', $wechatclass, $_GET['classid'], $Plang['916aa54a0b19dc05']);
$classselect_article = get_class_select_article('article_classid', $wechatclass_article, $_GET['articleid'], $Plang['ee6444320a2666bb'], false, true);
$classselect_article_collect = get_class_select_article('article_classid_thistime', $wechatclass_article, $_GET['articleid'], $Plang['088fe9c76f077b1d'], false, true);
$view_mode_select = get_select_options($view_mode);
require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/include/cp_' . $ac . '.php';

?>