<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_view.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
set_time_limit(1800);
if($plugin_wq_editor == 1) {
	if(empty($_G['uid'])) {
		showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
	}
	$articleid = max(1, intval($_GET['articleid']));
	$tableid = wq_wechatcollecting_get_article_contenttableid($articleid);
	$contents = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_first_by_articleid($articleid, array(0, -1, 1, -2), $tableid);

	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($contents['wid']);
	if(!empty($contents)) {
		if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $wechat['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
			showmessage($Plang['66ef666b87236e94']);
		}
		$lookurl = "plugin.php?id=wq_wechatcollecting&mod=lookoriginal&articleid=" . $contents['articleid'];
		if($contents['url'] != '#rd' && stripos($contents['url'], 'timestamp') === false && $contents['url']) {
			$lookurl = $contents['url'];
		}
		if(!submitcheck('edit_submit') && !submitcheck('release_edit_submit')) {
			$contents['content'] = str_replace(array("jpg&", "#wechat_redirect"), array("jpg?", ""), base64_decode($contents['content']));

			$contents['content'] = wq_wechatcollecting_edit_content_imgurl_replace($contents['content'], $setting);

			$webpagename = $Plang['ad0c50e74f8c6175'];
			$config_url = DISCUZ_ROOT . 'source/plugin/wq_editor/ue/';
			include template('wq_wechatcollecting:wechatcollecting_edit');
		} else {
			$title = dhtmlspecialchars(trim($_GET['title']));
			$content = $_GET['content'];

			$content = wq_wechatcollecting_edit_content_imgurl_replace($content, $setting, false);

			if(!empty($title) && !empty($content)) {
				$imageurl = C::t('#wq_wechatcollecting#wq_wechatcollecting_attachment')->fetch_all_imageurl_by_articleid($articleid);
				foreach($imageurl as $val) {
					if(strpos($content, $val['imageurl'])) {
						continue;
					} else {
						if($val['type'] == '1') {
							@unlink(wq_wechatcollecting_headimg_and_bgimg_url($val['imageurl'], true));
						}
						if($val['type'] == '3') {
							@unlink($val['imageurl']);
							delete_wechat_qiniu_images($val['imageurl'], $setting);
						}
						C::t('#wq_wechatcollecting#wq_wechatcollecting_attachment')->delete($val['id']);
					}
				}

				$content = base64_encode($content);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->update_content_by_articleid($contents['articleid'], $content, $tableid);
				$articleinfo['title'] = $title;
				if($_GET['release_edit_submit']) {
					$articleinfo['status'] = 1;
				}
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($contents['articleid'], $articleinfo);
				$url = 'plugin.php?id=wq_wechatcollecting&mod=view&articleid=' . $articleid;
				if(!empty($contents['tid'])) {
					$tid = $contents['tid'];
					$forum_article = C::t('forum_thread')->fetch($tid);
					if($forum_article) {
						$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
						$update_thread['subject'] = $title;
						if($_GET['release_edit_submit']) {
							$update_thread['displayorder'] = 0;
						}
						C::t('forum_thread')->update($tid, $update_thread);
						$setting['view_mode'] == '2' ? $url = 'forum.php?mod=viewthread&tid=' . $tid : '';
					}
				}
				if(!empty($contents['aid'])) {
					$aid = $contents['aid'];
					$portal_article = C::t('portal_article_title')->fetch($aid);
					if($portal_article) {
						$update_article['title'] = $title;
						if($_GET['release_edit_submit']) {
							$update_article['status'] = 0;
						}
						C::t('portal_article_title')->update($aid, $update_article);
						$setting['view_mode'] == '3' ? $url = 'portal.php?mod=view&aid=' . $aid : '';
					}
				}
				showmessage($Plang['3cd720ff8905412d'], $url);
			} else {
				showmessage($Plang['f0b109c243a9b33a']);
			}
		}
	} else {
		showmessage($Plang['e3cf2fe807bf8b26'], 'plugin.php?id=wq_wechatcollecting');
	}
} else {
	header('Location:plugin.php?id=wq_wechatcollecting&mod=index');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>