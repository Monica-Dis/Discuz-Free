<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_view.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$articleid = max(1, intval($_GET['articleid']));
$tableid = wq_wechatcollecting_get_article_contenttableid($articleid);
$content = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_first_by_articleid($articleid, array(1), $tableid);

if(!empty($content)) {
	$content['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($content['imglink']);
	$content['content'] = update_sogou_newcontent($content['id'], $content['content'], $tableid);
	$length = strlen($content['content']);
	$wechatinfo = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($content['wid']);
	if(!$content['fileterheader'] && $length == 65535 && !$_GET['wxapp']) {
		if($content['url'] == '#rd') {
			$temcontent['content'] = null;
		} else {
			$temcontent = wqWechatApigetArticleContentByUrl($content['url'], false, false, false);
		}
		if($temcontent['content']) {

			$updatedata['fileterheader'] = $content['fileterheader'] = 1;
			$updatedata['content'] = $content['content'] = base64_encode($temcontent['content']);
			C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->update($tableid, $content['id'], $updatedata);
			C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($content['articleid'], array('url' => $content['url']));
		}
	}
	if(!$_GET['wxapp']) {
		if($setting['view_mode'] == '2' && !empty($content['tid'])) {
			dheader("location:forum.php?mod=viewthread&tid=" . $content['tid']);
		}
		if($setting['view_mode'] == '3' && !empty($content['aid'])) {
			dheader("location:portal.php?mod=view&aid=" . $content['aid']);
		}
		$content['content'] = str_replace(array("jpg&", "#wechat_redirect"), array("jpg?", ""), base64_decode($content['content']));

		if($setting['is_saveimages'] && $setting['view_issaveimg']) {
			$content['content'] = download_remote_images($content['content'], $content['articleid'], $setting);
		}
	} else {
		$content['content'] = trim(base64_decode($content['content']));
	}

	$content['content'] = wq_wechatcollecting_image_url_replace($content['content']);

	$classname = $wechatclass[$content['classid']]['classname'] ? $wechatclass[$content['classid']]['classname'] : $Plang['8dfe4b30674494c1'];
	$webpagename = $Plang['80eee6922f1fff8a'];


	$addviews = 0;
	if($setting['optimizeviews']) {
		$row = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_addviews')->fetch($articleid);
		if($row) {
			$addviews = $row['addviews'];
		}
	}
	wq_wechatcollecting_viewthread_updateviews($articleid, 'article', $addviews, 'wq_wechatcollecting_article', 'wq_wechatcollecting_article_addviews', $setting, $content);

	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($content['wid']);
	$wechat['qrcode'] = wq_get_qrcode_by_wechatid($wechat['wechatid']);
	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $wechatclass[$content['classid']]['classname'], 'subject' => $content['title']);
	list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $wechat_seo['view']);

	if(!$content['fileterheader'] && $length < 65535) {
		$content['content'] = fileter_header($content['content']);
	}

	if((substr_count($content['content'], '"') % 2) != 0) {
		$content['content'] .= '"';
	}

	if($setting['view_is_filtration_a']) {
		$content['content'] = preg_replace("/<a [^>]*>/", "", $content['content']);
		$content['content'] = preg_replace("/<\/a>/", "", $content['content']);
	}
	$content['content'] = add_content_ent_label($content['content'], '<', '>');
	$content['content'] = add_content_ent_label($content['content'], '<div', '</div>');
	$content['content'] = wq_wechatcollecting_replace_src_add_datasrc($content['content']);

    $content['content'] = wq_parse_video($content['content']);

	if($_G['mobile']) {
		$content['content'] = $setting['mobile_content_add_top'] . $content['content'] . $setting['mobile_content_add_bottom'];
	} else {
		$content['content'] = $setting['pc_content_add_top'] . $content['content'] . $setting['pc_content_add_bottom'];
	}


	$date = date('Y-m-d', $content['date']);
	$right_first = get_right_hot_new_article($setting['view_first_article_num'], '', 'date', '', '', true, $wechatinfo['id']);
	$right_collect = get_right_hot_new_article($setting['right_hot_collect'], '', 'favorites', '', '', false, $wechatinfo['id']);
	$right_new = get_right_hot_new_article($setting['right_new_article_num'], '', 'date', '', '', false, $wechatinfo['id']);
	$right_hot = get_right_hot_new_article($setting['right_hot_article_num'], '', 'views', '', '', false, $wechatinfo['id']);
	$right_recommedlist = get_recommed_wechat_list(4, $wechatinfo['classid'], $setting['right_wechat_num']);
	$join_list = get_right_hot_new_article($setting['view_correlation_article_num'], '', 'date', '', '', false, $wechatinfo['id']);
	$you_recommedlist = get_right_hot_new_article($setting['view_bottom_recommend_num'], '', 'date', $wechatinfo['classid'], 1);

	$lastaid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_aid_by_aid_wid_type($articleid, $content['wid'], '<');
	$nextaid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_aid_by_aid_wid_type($articleid, $content['wid'], '>');
	$wqreward_but = '';
	if($_G['cache']['plugin']['wq_reward']) {
		include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';
		$wqreward_but = forum_portal_group('articleid', $articleid);
	}

	if($_G['mobile']) {
		$webpagename = $content['title'];
		include template('wq_wechatcollecting:wechatcollecting_view');
	} else {
		include template('diy:wechatcollecting_view', 0, 'source/plugin/wq_wechatcollecting/template');
	}
} else {
	showmessage($Plang['e3cf2fe807bf8b26'], 'plugin.php?id=wq_wechatcollecting');
}


?>