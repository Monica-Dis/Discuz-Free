<?php

/**
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *
 * From: DisM.taobao.Com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_contentsplit.inc.inc.php 2017-09-14 ����02:38:10Z DisM��Taobao��Com $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
@set_time_limit(0);
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
$setting = C::t('common_setting')->fetch_all(array('wq_content_table_info', 'wq_content_tableids'), true);

if($setting['wq_content_table_info']) {
	$wq_content_table_info = $setting['wq_content_table_info'];
} else {
	$wq_content_table_info = array();
	$wq_content_table_info[0]['type'] = 'primary';
}
$wq_content_tableids = $setting['wq_content_tableids'] ? $setting['wq_content_tableids'] : array();

$sub = $_GET['sub'] ? trim($_GET['sub']) : 'manage';
$cpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit';
if($sub == 'manage') {
	if(!submitcheck('contentsplit_manage')) {
		showtips($Plang['article_content_split_manage_tips']);
		showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit');
		showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
		showsubtitle(array('postsplit_manage_tablename', 'postsplit_manage_datalength', 'postsplit_manage_table_memo', ''));
		$tablename = wq_get_article_content_table(0, true);
		$tableid = 0;
		$tablestatus = helper_dbtool::gettablestatus($tablename);

		$contentcount = $tablestatus['Rows'];
		$data_length = $tablestatus['Data_length'];
		$index_length = $tablestatus['Index_length'];


		$spliturl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=split';
		$opstr = '<a href="' . $spliturl . '&tableid=0">' . cplang('postsplit_name') . '</a>';
		showtablerow('', array('', '', '', 'class="td25"'), array($tablename, $data_length, "<input type=\"text\" class=\"txt\" name=\"memo[0]\" value=\"{$wq_content_table_info[0]['memo']}\" />", $opstr));
		foreach(C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table() as $table) {
			list($tempkey, $tablename) = each($table);
			$tableid = wq_get_article_content_gettableid($tablename);
			if(!preg_match('/^\d+$/', $tableid)) {
				continue;
			}
			$tablestatus = helper_dbtool::gettablestatus($tablename);

			$opstr = '<a href="' . $spliturl . '&tableid=' . $tableid . '">' . cplang('postsplit_name') . '</a>';
			showtablerow('', array('', '', '', 'class="td25"'), array($tablename, $tablestatus['Data_length'], "<input type=\"text\" class=\"txt\" name=\"memo[$tableid]\" value=\"{$wq_content_table_info[$tableid]['memo']}\" />", $opstr));
		}
		showsubmit('contentsplit_manage', 'postsplit_manage_update_memo_submit');
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	} else {
		$wq_content_table_info = array();
		foreach($_GET['memo'] as $key => $value) {
			$key = intval($key);
			$wq_content_table_info[$key]['memo'] = dhtmlspecialchars($value);
		}
		C::t('common_setting')->update('wq_content_table_info', $wq_content_table_info);
		savecache('wq_content_table_info', $wq_content_table_info);

		wq_update_content_tableids();
		updatecache('setting');

		cpmsg('postsplit_table_memo_update_succeed', $cpurl, 'succeed');
	}
} elseif($sub == 'split') {

	if(!$_G['setting']['bbclosed']) {
		cpmsg($Plang['article_content_split_forum_must_be_closed'], $cpurl, 'error');
	}

	$tableid = intval($_GET['tableid']);
	$tablename = wq_get_article_content_table($tableid);
	if($tableid && $tablename != 'wq_wechatcollecting_article_content' || !$tableid) {
		$status = helper_dbtool::gettablestatus(wq_get_article_content_table($tableid, true), false);

		if($status && ((!$tableid && $status['Data_length'] > 100 * 1048576) || ($tableid && $status['Data_length']))) {

			if(!submitcheck('splitsubmit')) {
				showtips($Plang['article_content_split_manage_tips']);
				showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=split&tableid=' . $tableid);
				showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
				showsetting('postsplit_from', '', '', wq_get_article_content_table($tableid, true) . (!empty($wq_content_table_info[$tableid]['memo']) ? '(' . $wq_content_table_info[$tableid]['memo'] . ')' : ''));
				$tablelist = '<option value="-1">' . cplang('postsplit_create') . '</option>';
				foreach($wq_content_table_info as $contenttableid => $info) {
					if($tableid != $contenttableid) {
						$tablestatus = helper_dbtool::gettablestatus(wq_get_article_content_table($contenttableid, true));
						$tablelist .= '<option value="' . $contenttableid . '">' . ($info['memo'] ? $info['memo'] : 'wq_wechatcollecting_article_content' . ($contenttableid ? '_' . $contenttableid : '')) . '(' . $tablestatus['Data_length'] . ')' . '</option>';
					}
				}

				showsetting('postsplit_to', '', '', '<select onchange="if(this.value >= 0) {$(\'tableinfo\').style.display = \'none\';} else {$(\'tableinfo\').style.display = \'\';}" name="targettable">' . $tablelist . '</select>');
				showtagheader('tbody', 'tableinfo', true, 'sub');
				showsetting('postsplit_manage_table_memo', "memo", '', 'text');
				showtagfooter('tbody');

				$datasize = round($status['Data_length'] / 1048576);
				$maxsize = round(($datasize - ($tableid ? 0 : 100)) / 100);
				$maxi = $maxsize > 10 ? 10 : ($maxsize < 1 ? 1 : $maxsize);
				for($i = 1; $i <= $maxi; $i++) {
					$movesize = $i == 10 ? 1024 : $i * 100;
					$maxsizestr .= '<option value="' . $movesize . '">' . ($i == 10 ? sizecount($movesize * 1048576) : $movesize . 'MB') . '</option>';
				}
				showsetting('postsplit_move_size', '', '', '<select name="movesize">' . $maxsizestr . '</select>');
				showsetting($Plang['article_content_split_every_movenum'], "movenum", 300, 'text', '', 0, $Plang['article_content_split_every_movenum_tips']);

				showsubmit('splitsubmit', 'postsplit_manage_submit');
				showtablefooter(); /*dis'.'m.tao'.'bao.com*/
				showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
			} else {

				$targettable = intval($_GET['targettable']);
				$createtable = false;
				if($targettable == -1) {
					$maxtableid = wq_get_max_article_content_tableid();
					DB::query('SET SQL_QUOTE_SHOW_CREATE=0', 'SILENT');
					$tableinfo = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table_by_tableid(0);
					$createsql = $tableinfo['Create Table'];
					$targettable = $maxtableid + 1;
					$newtable = 'wq_wechatcollecting_article_content_' . $targettable;
					$createsql = str_replace($tablename, $newtable, $createsql);
					DB::query($createsql);

					$wq_content_table_info[$targettable]['memo'] = $_GET['memo'];
					C::t('common_setting')->update('wq_content_table_info', $wq_content_table_info);
					savecache('wq_content_table_info', $wq_content_table_info);
					wq_update_content_tableids();
					$createtable = true;
				}
				$sourcetablearr = wq_get_content_table_fields($tablename);
				$new_tableid = wq_get_article_content_table($targettable);
				$targettablearr = wq_get_content_table_fields($new_tableid);
				$fields = array_diff(array_keys($sourcetablearr), array_keys($targettablearr));
				if(!empty($fields)) {
					cpmsg('postsplit_do_error', '', '', array('tableid' => wq_get_article_content_table($targettable, true), 'fields' => implode(',', $fields)));
				}

				$movesize = intval($_GET['movesize']);
				$movesize = $movesize >= 100 && $movesize <= 1024 ? $movesize : 100;
				$targetstatus = helper_dbtool::gettablestatus(wq_get_article_content_table($targettable, true), false);

				$movenum = dintval($_GET['movenum']);
				$movenum = $movenum < 1 ? 300 : ($movenum > 500 ? 500 : $movenum);

				$hash = urlencode(authcode("$tableid\t$movesize\t$targettable\t$targetstatus[Data_length]\t$movenum", 'ENCODE'));
				if($createtable) {
					cpmsg($Plang['article_content_table_create_succeed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=movecontent&fromtable=' . $tableid . '&movesize=' . $movesize . '&targettable=' . $targettable . '&hash=' . $hash, 'loadingform');
				} else {
					cpmsg('postsplit_finish', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=movecontent&fromtable=' . $tableid . '&movesize=' . $movesize . '&targettable=' . $targettable . '&hash=' . $hash, 'loadingform');
				}
			}
		} else {
			cpmsg('postsplit_unallow', $cpurl);
		}
	}
} elseif($sub == 'movecontent') {
	if(!$_G['setting']['bbclosed']) {
		cpmsg($Plang['article_content_split_forum_must_be_closed'], $cpurl, 'error');
	}
	list($tableid, $movesize, $targettableid, $sourcesize, $movenum) = explode("\t", urldecode(authcode($_GET['hash'])));
	$hash = urlencode($_GET['hash']);
	if($tableid == $_GET['fromtable'] && $movesize == $_GET['movesize'] && $targettableid == $_GET['targettable']) {
		$fromtableid = intval($_GET['fromtable']);
		$movesize = intval($_GET['movesize']);
		$targettableid = intval($_GET['targettable']);

		$targettable = wq_get_content_table_fields(wq_get_article_content_table($targettableid));

		$fieldstr = '`' . implode('`, `', array_keys($targettable)) . '`';

		$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->count_table($fromtableid);
		if($count) {
			$articleids = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_all_articleid($fromtableid, 0, $movenum);
			$aids = array();
			foreach($articleids as $key => $value) {
				$aids[] = $value['articleid'];
			}
			wq_article_content_movedata($aids);
		} else {
			cpmsg($Plang['article_content_split_done'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=optimize&tableid=' . $fromtableid, 'form');
		}
	} else {
		cpmsg($Plang['article_content_abnormal'], $cpurl, 'error');
	}
} elseif($sub == 'optimize') {
	if(!$_G['setting']['bbclosed']) {
		cpmsg($Plang['article_content_split_forum_must_be_closed'], $cpurl, 'error');
	}

	$fromtableid = intval($_GET['tableid']);
	$optimize = true;
	$tablename = wq_get_article_content_table($fromtableid);
	if($fromtableid && $tablename != 'wq_wechatcollecting_article_content') {
		$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->count_table($fromtableid);
		if(!$count) {
			C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->drop_table($fromtableid);

			unset($wq_content_table_info[$fromtableid]);
			C::t('common_setting')->update('wq_content_table_info', $wq_content_table_info);
			savecache('wq_content_table_info', $wq_content_table_info);
			wq_update_content_tableids();
			$optimize = false;
		}
	}
	if($optimize) {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->optimize_table($fromtableid);
	}
	cpmsg($Plang['article_content_split_do_succeed'], $cpurl, 'succeed');
}

function wq_get_article_content_gettableid($tablename) {
	$tableid = substr($tablename, strrpos($tablename, '_') + 1);
	return $tableid;
}

function wq_get_max_article_content_tableid() {
	$maxtableid = 0;
	foreach(C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table() as $table) {
		list($tempkey, $tablename) = each($table);
		$tableid = intval(wq_get_article_content_gettableid($tablename));
		if($tableid > $maxtableid) {
			$maxtableid = $tableid;
		}
	}
	return $maxtableid;
}

function wq_update_content_tableids() {
	$tableids = wq_get_content_tableids();
	C::t('common_setting')->update('wq_content_tableids', $tableids);
	savecache('wq_content_tableids', $tableids);
}

function wq_get_content_tableids() {
	$tableids = array(0);
	foreach(C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table() as $table) {
		list($tempkey, $tablename) = each($table);
		$tableid = wq_get_article_content_gettableid($tablename);
		if(!preg_match('/^\d+$/', $tableid)) {
			continue;
		}
		$tableid = intval($tableid);
		if(!$tableid) {
			continue;
		}
		$tableids[] = $tableid;
	}
	return $tableids;
}

function wq_get_content_table_fields($table) {
	static $tables = array();

	if(!isset($tables[$table])) {
		$tables[$table] = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->show_table_columns($table);
	}
	return $tables[$table];
}

function wq_article_content_movedata($articleids) {
	global $Plang, $sourcesize, $movesize, $targettableid, $hash, $fieldstr, $fromtableid, $wq_content_table_info;

	$fromtable = wq_get_article_content_table($fromtableid, true);
	C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->move_table($targettableid, $fieldstr, $fromtable, $articleids);
	if(DB::errno()) {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->delete_by_articleids($targettableid, $articleids);
	} else {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_contenttableid($articleids, array('contenttableid' => $targettableid));
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->delete_by_articleids($fromtableid, $articleids);
	}
	$status = helper_dbtool::gettablestatus(wq_get_article_content_table($targettableid, true), false);
	$targetsize = $sourcesize + $movesize * 1048576;
	$nowdatasize = $targetsize - $status['Data_length'];
	if($status['Data_length'] >= $targetsize) {
		cpmsg($Plang['article_content_split_done'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=optimize&tableid=' . $fromtableid, 'form');
	}
	cpmsg('postsplit_doing', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_contentsplit&sub=movecontent&fromtable=' . $fromtableid . '&movesize=' . $movesize . '&targettable=' . $targettableid . '&hash=' . $hash, 'loadingform', array('datalength' => sizecount($status['Data_length']), 'nowdatalength' => sizecount($nowdatasize)));
}

function wq_get_article_content_table($tableid = 0, $prefix = false) {
	return C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->get_wq_wechatcollecting_article_content_table($tableid, $prefix);
}
//From:  d'.'is'.'m.ta'.'obao.com
?>