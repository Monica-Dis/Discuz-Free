<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
$url = 'plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatcollecting&pmod=admincp_cachesetting';
if(!submitcheck('form')) {
	$tips = '<li>' . $Plang['e9d8cdcec8a98043'] . '</li>';
	$tips .= '<li>' . $Plang['bff5c277f6abcd08'] . '</li>';
	$tips .= '<li>' . $Plang['8a8956a78d691fe2'] . '</li>';
	showtips($tips, 'tips', true, $Plang['d88e9159a1321204']);
	$cachearr = array(
		'wechatcollecting' => array('article_list', 'right_bottom', 'article_info'),
		'wechatshow' => array('recommend_list', 'wechat_list', 'wechat_info', 'wechat_view_articlelist')
	);
	$searcharr = array('article', 'wechat');
	$loadcache = array('articlesearch', 'wechatsearch', 'wechatcollecting_cache_setting');
	$sqlcache = C::t('common_setting')->fetch_all($loadcache, 'true');

	showformheader($url);
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtitle($Plang['search_memory_set']);
	showsubtitle(array($Plang['26b778c542262927'], $Plang['fae15338272b5d63'], $Plang['2f46987922f61119'], $Plang['0fa0f55906330969'], $Plang['0a6da9b6dede3f17'], $Plang['fc554f12d8734681']));
	foreach($searcharr as $v) {
		$key = $v . 'search';
		showtablerow('', array(), array(
			$Plang[$v . '_search'],
			'<input type = "number" style = "width:100px;" name = "' . $v . 'search[searchctrl]" value = "' . $sqlcache[$key]['searchctrl'] . '" />',
			'<input type = "number" style = "width:100px;" name = "' . $v . 'search[maxspm]" value = "' . $sqlcache[$key]['maxspm'] . '" />',
			'<input type = "number" style = "width:100px;" name = "' . $v . 'search[result_expiration]" value = "' . $sqlcache[$key]['result_expiration'] . '" />',
			'<input type = "number" style = "width:100px;" name = "' . $v . 'search[maxsearchresults]" value = "' . $sqlcache[$key]['maxsearchresults'] . '" />',
			'<input class = "checkbox" type = "checkbox" name = "' . $v . 'search[status]" value = "1" ' . ($sqlcache[$key]['status'] > 0 ? 'checked' : '') . '>',
		));
	}
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$memory_link = '<a href="' . ADMINSCRIPT . '?action=setting&operation=memory" target="_blank"><font color="#2366A8">' . $Plang['0a6da9b6dede3f16'] . '</font></a>';
	$tips = '<li>' . $Plang['bc5440371fc2bc36'] . $memory_link . '</li>';
	$tips .= '<li>' . $Plang['ac567fe28a7359cb'] . '</li>';
	$tips .= '<li>' . $Plang['f22c06f0f3dc3f8d'] . '</li>';
	showtips($tips, 'tips', true, $Plang['136e70dea4128ec2']);
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	$sqlcache = $sqlcache['wechatcollecting_cache_setting'];
	foreach($cachearr as $key => $value) {
		showtitle($Plang[$key . '_tips']);
		showsubtitle(array($Plang['a31d511ee81868c5'], $Plang['1d301a223f01a966'], $Plang['fc554f12d8734681']));
		foreach($value as $v) {
			showtablerow('', array(), array(
				$Plang[$v],
				'<input type = "number" style = "width:100px;" name = "setting[' . $v . '][time]" value = "' . $sqlcache[$v]['time'] . '" />',
				'<input class = "checkbox" type = "checkbox" name = "setting[' . $v . '][status]" value = "1" ' . ($sqlcache[$v]['status'] > 0 ? 'checked' : '') . '>',
				$Plang[$v . '_tips'],
			));
		}
	}
	showsubmit('form');
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
} else {
	foreach($_GET['setting'] as $key => $value) {
		$_GET['setting'][$key]['status'] = $value['status'] ? 1 : 0;
		if($value['time'] && $value['time'] < 1) {
			$_GET['setting'][$key]['time'] = 0;
		}
	}
	$settings = array();
	if($_GET['setting']) {
		$settings['wechatcollecting_cache_setting'] = $_GET['setting'];
	}
	$article = $_GET['articlesearch'];
	$article['status'] = $article['searchctrl'] < 1 || !$article['maxspm'] ? 0 : $article['status'];
	if($article) {
		$article['maxsearchresults'] = $article['maxsearchresults'] < 1 ? 1 : $article['maxsearchresults'];
		$article['result_expiration'] = $article['result_expiration'] < 0 ? 0 : $article['result_expiration'];
		$settings['articlesearch'] = $article;
		$settings['memory']['wq_wechatcollecting_article'] = $_GET['setting']['article_info']['status'] ? $_GET['setting']['article_info']['time'] : $article['result_expiration'];
	}
	$wechat = $_GET['wechatsearch'];
	$wechat['status'] = $wechat['searchctrl'] < 1 || !$wechat['maxspm'] ? 0 : $wechat['status'];
	if($wechat) {
		$wechat['maxsearchresults'] = $wechat['maxsearchresults'] < 1 ? 1 : $wechat['maxsearchresults'];
		$wechat['result_expiration'] = $wechat['result_expiration'] < 0 ? 0 : $wechat['result_expiration'];
		$settings['wechatsearch'] = $wechat;
		$settings['memory']['wq_wechatcollecting_wechat'] = $_GET['setting']['wechat_info']['status'] ? $_GET['setting']['wechat_info']['time'] : $wechat['result_expiration'];
	}

	if($settings) {
		C::t('common_setting')->update_batch($settings);
		updatecache('setting');
	}
	cpmsg($Plang['9a52f4d6ef956904'], 'action=' . $url, 'succeed');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>