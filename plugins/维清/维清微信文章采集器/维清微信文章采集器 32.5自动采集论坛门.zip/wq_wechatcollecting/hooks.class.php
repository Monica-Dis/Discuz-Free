<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-7-5 20:09:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/class/base.class.php';

class plugin_wq_wechatcollecting extends plugin_wq_wechatcollecting_base {

	function plugin_wq_wechatcollecting() {
		$this->init();
		$this->common_base();
	}

	function global_header() {
		global $_G, $aid;
		if((CURSCRIPT != "forum" || CURMODULE != 'viewthread' || empty($_G['tid'])) && (CURSCRIPT != 'portal' || CURMODULE != 'view' || empty($aid))) {
			return '';
		}
		if(CURSCRIPT == "forum" && CURMODULE == 'viewthread' && $this->fetch_article_by_tid($_GET['tid'])) {
			$_G['setting']['lazyload'] = false;
		}
		$wqverhash = VERHASH;
		$js = <<<EOT
			<script type="text/javascript" src="./source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{$wqverhash}"></script>
			<script src="./source/plugin/wq_wechatcollecting/static/js/video.pc.js?{$wqverhash}" type="text/javascript"></script>
			<script src="{$_G['setting']['jspath']}common_extra.js?{$wqverhash}"></script>
			<script type="text/javascript">
	wqjq(function() {

		wqjq('#js_profile_qrcode').click(function() {
			wqjq('#js_profile_qrcode').show();
		});
		wqjq('*').click(function(event) {
			var target = wqjq(event.target);
			if (target.attr("class") == 'profile_meta_label' || target.attr("class") == 'profile_meta_value' || target.attr("class") == 'profile_nickname' || target.attr("class") == 'profile_meta' || target.attr("class") == 'profile_inner' || target.attr("class") == 'profile_avatar') {
				wqjq("#js_profile_qrcode").show();
			}
			else {
				if (target.attr("id") == 'post-user') {
					wqjq("#js_profile_qrcode").show();
				} else {
					wqjq("#js_profile_qrcode").hide();
				}
			}
		});
		wqjq(".del").click(function() {
			if (confirm()) {
				return true;
			} else {
				return false;
			}
		});
	});
		</script>
EOT;

		return $js;
	}

	function deletethread($params) {
		include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';

		$tids = $params['param'][0];
		$step = $params['step'];
		if($step == 'delete' && is_array($tids)) {
			$articles = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_tid($tids);
			foreach($articles as $value) {
				del_article($value, true, $this->setting);
				$value['aid'] ? $aid[] = $value['aid'] : '';
			}
			if($aid) {
				include_once libfile('function/delete');
				$aid ? deletearticle($aid) : '';
			}
		}
	}

}

class plugin_wq_wechatcollecting_forum extends plugin_wq_wechatcollecting {

	function viewthread_posttop_output() {
		global $postlist;
		$content = $this->_article_content();

		if($content != '1') {
			include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
			foreach($postlist as $post) {
				if($post['first'] == '1') {
					$post['message'] = wq_wechatcollecting_replace_src_add_datasrc($content[0]);

					$post['message'] = wq_parse_video($post['message']);

					$postlist[$post['pid']]['message'] = $post['message'];
				} else {
					continue;
				}
			}
		}
	}

	function post_wq_wechatcollecting() {
		$article = $this->fetch_article_by_tid($_GET['tid']);
		$threadinfo = C::t('forum_thread')->fetch($_GET['tid']);
		$postinfo = C::t('forum_post')->fetch($threadinfo['posttableid'], $_GET['pid'], false);
		if($_GET['action'] != 'edit' || empty($article) || empty($postinfo['first'])) {
			return '';
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=edit&articleid=" . $article['articleid']);
	}

	function topicadmin_wq_wechatcollecting_message($params) {
		$this->wq_wechatcollecting_move_topic($params);
	}

}

class plugin_wq_wechatcollecting_group extends plugin_wq_wechatcollecting {

	function viewthread_posttop_output() {
		global $postlist;
		$content = $this->_article_content();
		if($content != '1') {
			foreach($postlist as $post) {
				if($post['first'] == '1') {
					$post['message'] = $content[0];
					$postlist[$post['pid']]['message'] = $post['message'];
				} else {
					continue;
				}
			}
		}
	}

	function post_wq_wechatcollecting() {
		$article = $this->fetch_article_by_tid($_GET['tid']);
		$threadinfo = C::t('forum_thread')->fetch($_GET['tid']);
		$postinfo = C::t('forum_post')->fetch($threadinfo['posttableid'], $_GET['pid'], false);
		if($_GET['action'] != 'edit' || empty($article) || empty($postinfo['first'])) {
			return '';
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=edit&articleid=" . $article['articleid']);
	}

	function topicadmin_wq_wechatcollecting_message($params) {
		$this->wq_wechatcollecting_move_topic($params);
	}

}

class plugin_wq_wechatcollecting_portal extends plugin_wq_wechatcollecting {

	function view_portal_output() {
		global $_G, $content, $article;

		$article_content = $this->_article_content();

		if($article_content != '1') {
			$content['content'] = $article_content[0];
			if(empty($article['summary'])) {
				$article['summary'] = $this->_get_portal_summary($article_content[2]);
			}
		}
	}

	function portalcp_article_wq_wechatcollecting() {
		$article = $this->fetch_article_by_aid($_GET['aid']);
		if($_GET['op'] != 'edit' || empty($article)) {
			return '';
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=edit&articleid=" . $article['articleid']);
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>