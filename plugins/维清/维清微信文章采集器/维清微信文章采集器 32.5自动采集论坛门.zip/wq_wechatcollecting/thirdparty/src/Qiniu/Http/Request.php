<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


final class wqRequest {

	public $url;
	public $headers;
	public $body;
	public $method;

	public function __construct($method, $url, array $headers = array(), $body = null) {
		$this->method = strtoupper($method);
		$this->url = $url;
		$this->headers = $headers;
		$this->body = $body;
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>