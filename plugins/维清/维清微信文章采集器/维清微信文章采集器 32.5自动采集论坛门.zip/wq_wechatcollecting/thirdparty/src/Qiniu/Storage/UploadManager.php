<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Http/Client.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Storage/FormUploader.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Storage/ResumeUploader.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Config.php';


final class wqUploadManager {

	private $config;

	public function __construct(wqConfig $config = null) {
		if($config === null) {
			$config = new wqConfig();
		}
		$this->config = $config;
	}

	public function put(
	$upToken, $key, $data, $params = null, $mime = 'application/octet-stream', $checkCrc = false
	) {
		$params = self::trimParams($params);
		return wqFormUploader::put(
				$upToken, $key, $data, $this->config, $params, $mime, $checkCrc
		);
	}

	public function putFile(
	$upToken, $key, $filePath, $params = null, $mime = 'application/octet-stream', $checkCrc = false
	) {
		$file = fopen($filePath, 'rb');
		if($file === false) {
			throw new \Exception("file can not open", 1);
		}
		$params = self::trimParams($params);
		$stat = fstat($file);
		$size = $stat['size'];
		if($size <= wqConfig::BLOCK_SIZE) {
			$data = fread($file, $size);
			fclose($file);
			if($data === false) {
				throw new \Exception("file can not read", 1);
			}
			return wqFormUploader::put(
					$upToken, $key, $data, $this->config, $params, $mime, $checkCrc
			);
		}
		$up = new wqResumeUploader(
			$upToken, $key, $file, $size, $params, $mime, $this->config
		);
		$ret = $up->upload();
		fclose($file);
		return $ret;
	}

	public static function trimParams($params) {
		if($params === null) {
			return null;
		}
		$ret = array();
		foreach($params as $k => $v) {
			$pos = strpos($k, 'x:');
			if($pos === 0 && !empty($v)) {
				$ret[$k] = $v;
			}
		}
		return $ret;
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>