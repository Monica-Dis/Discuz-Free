<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


final class Wqerror {

	private $url;
	private $response;

	public function __construct($url, $response) {
		$this->url = $url;
		$this->response = $response;
	}

	public function code() {
		return $this->response->statusCode;
	}

	public function getResponse() {
		return $this->response;
	}

	public function message() {
		return $this->response->error;
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>