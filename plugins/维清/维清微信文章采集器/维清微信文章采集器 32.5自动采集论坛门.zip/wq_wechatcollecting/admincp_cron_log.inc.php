<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
if(!$_GET['step']) {
	$status = in_array($_GET['status'], array('0', '-1', '-2', '-3')) ? $_GET['status'] : '';
	$time = in_array($_GET['time'], array('time')) ? $_GET['time'] : 'time';
	$search = in_array($_GET['search'], array('wechatuser', 'wechatname', 'username')) ? $_GET['search'] : 'wechatuser';
	$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? $_GET['ordertype'] : 'desc';
	$starttime = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['starttime'])) ? strtotime(trim($_GET['starttime'])) : '';
	$endtime = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['endtime'])) ? strtotime(trim($_GET['endtime'])) : '';
	$displayorder = in_array($_GET['displayorder'], array('uid', 'time')) ? $_GET['displayorder'] : 'time';
	$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
	$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
	$limit = $_GET['perpage'] < 1 ? $setting['admincp_perpage'] : intval($_GET['perpage']);
	$page = max(1, intval($_GET['page']));
	$start = ($page - 1) * $limit;
	$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_cron_log';

	$all = C::t('#wq_wechatcollecting#wq_wechatcollecting_log')->fetch_all_by_search($status, $keyword, $search, $time, $starttime, $endtime, $displayorder, $ordertype, $start, $limit);
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_log')->count_by_search($status, $keyword, $search, $time, $starttime, $endtime);

	$mpurl .= $time != 'time' ? '&time=' . $time : '';
	$mpurl .= $search != 'wechatuser' ? '&search=' . $search : '';
	$mpurl .= $ordertype != 'desc' ? '&ordertype=' . $ordertype : '';
	$mpurl .= $starttime != '' ? '&starttime=' . $_GET['starttime'] : '';
	$mpurl .= $endtime != '' ? '&endtime=' . $_GET['endtime'] : '';
	$mpurl .= $displayorder != 'time' ? '&displayorder=' . $_GET['displayorder'] : '';
	$mpurl .= !empty($keyword) ? '&keyword=' . $_GET['keyword'] : '';
	$mpurl .= $limit != $setting['admincp_perpage'] ? '&perpage=' . $limit : '';
	$url = $mpurl;
	$mpurl .= $status !== '' ? '&status=' . $status : '';
	$href = $mpurl . '&page=' . $_GET['page'];
	$url = ADMINSCRIPT . '?' . $url;
	$mpurl = ADMINSCRIPT . '?' . $mpurl;

	include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

	echo"<style tpye='text/css'>
   .hover div:hover,.status{background-color: #666666 !important;}
    .hover div{width:55px;height;text-align:center;line-height:18px;border-radius:4px;}
    .hover div:hover a,.status a{color:#FFF !important;}
       li{float:left;}
     .mradio_html li{line-height:25px;}
       input:hover, input:focus,select:hover,select:focus{border-color:#09C;background: #F5F9FD none repeat scroll 0% 0%;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    td span{color:red;}
    .addtr {background: transparent url('static/image/admincp/bg_repno.gif') no-repeat scroll 2px 3px;line-height: 30px;}
    </style>
    <script type='text/javascript' src='static/js/calendar.js'></script>
<script>_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e,'forms'); });</script>";

	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_cron_log';

	showformheader($fromurl, '', 'forms');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	$perpage_html = perpage_html($limit);
	$typehtml = radio_html(array('desc' => $Plang['5bee37fbebf639d9'], 'asc' => $Plang['d85de5630e53b00f']), 'ordertype', $ordertype);
	$timetpye = array('time' => $Plang['535e5fdefa04f246'], 'uid' => $Plang['6956f8dff39c54e1']);
	$orderhtml = select_html($timetpye, 'displayorder', $displayorder, false);
	$datetype = select_html(array('time' => $Plang['535e5fdefa04f246']), 'time', $time, false);
	$datehtml = text_html($_GET['starttime'], $_GET['endtime']);

	showtablerow('', array('width="25"', 'width="50"', 'width="100"', 'width="50"'), array(
		$Plang['1670da9c2989259f'], $orderhtml, $typehtml,
		$Plang['d4036b1fd175e0f9'], $perpage_html,
	));
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$keywordtype = array('wechatuser' => $Plang['4b3b548154549518'], 'wechatname' => $Plang['3982634cd20768c9'], $Plang['24dbae32d67e23d7']);
	$options = select_html($keywordtype, 'search', $search, false, false);
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablerow('', array('width="50"', 'width="270"', 'width="55"', 'width="50"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="80"'), array(
		$datetype, $datehtml,
		$Plang['62fa857dd698b74d'] . ":", $options, "<input size = \"25\" name=\"keyword\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['keyword']) . "\" placeholder='" . $Plang['f5d7c38c95fd323a'] . "' />" .
		"<input name=\"status\" type=\"hidden\" value=\"" . $status . "\" />",
		"<input id='submit_forms' class=\"btn\" type=\"submit\" value=\"$lang[search]\" name='forms'/>",
		"<div " . ($status === '' ? 'class="status"' : "") . "><a style='color:#000;' href=\"" . $url . "\">" . $Plang['e8af971c6963983d'] . "</a></div>",
		"<div " . ($status === 0 ? 'class="status"' : "") . "><a style = 'color:green;' href = \"" . $url . "&status=0\">" . $Plang['a8288be58d8e0123'] . "</a></div>",
		"<div " . ($status === -1 ? 'class="status"' : "") . "><a style='color:red;' href=\"" . $url . "&status=-1\">" . $Plang['7e44678fb3f94bdb'] . "</a></div>",
		"<div style='width:80px;' " . ($status === -2 ? 'class="status"' : "") . "><a style='color:blue;' href=\"" . $url . "&status=-2\">" . $Plang['622179c5f173dd5b'] . "</a></div>",
		"<div style='width:320px;' " . ($status === -3 ? 'class="status"' : "") . "><a style='color:#f60;' href=\"" . $url . "&status=-3\">" . $Plang['net_set_default'] . "</a></div>",
		'',
	));
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	$delUrl .= $fromurl . '&step=del';
	showformheader($delUrl, '', 'delForm');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablerow('', '', array(
		"<label style='float:left;line-height:25px;'>" . $Plang['72f56d63fc3ea1ea'] . $Plang['3aba14be242cdfaf'] . "</label><ul onmouseover='altStyle(this);' style='margin-top:5px;'>"
		. "<li><input class='radio' type='radio' name='delVal' value='0'><label for='editstatus_0' class = 'vmiddle'> " . $Plang['67bf12d4ac096b71'] . "</label></li>"
		. "<li><input class='radio' type='radio' name='delVal' value='1'><label for='editstatus_1' class = 'vmiddle'> " . $Plang['d92e5ee1ce7cdcb9'] . "</label></li>"
		. "<li><input class='radio' type='radio' name='delVal' value='2'><label for='editstatus_2' class = 'vmiddle'> " . $Plang['0599c58f2f54bb1c'] . "</label></li>"
		. "<li><input class='radio' type='radio' name='delVal' value='3'><label for='editstatus_3' class = 'vmiddle'> " . $Plang['0693b403cf5c1697'] . "</label></li>"
		. "<li'>&nbsp;&nbsp;<input class='btn' style='margin-top:0px;' type='submit' value='" . $lang['submit'] . "' name='delForm' onclick='adelete(this)' /></li></ul>"
	));
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	echo <<<EOG
<script type="text/javascript">
    function adelete(a) {
        if (!confirm("{$Plang['645279fde5e34abd']}")){
            window.event.returnValue = false;
        }
    }
</script>
EOG;


	showtableheader($Plang['4a83ec796d90ade8'], 'nobottom');
	$show_status = array('0' => $Plang['a8288be58d8e0123'], '-1' => $Plang['7e44678fb3f94bdb'], '-2' => $Plang['622179c5f173dd5b'], '-3' => $Plang['net_set_default']);
	$status_color = array('0' => "green", '-1' => "red", '-2' => 'blue', '-3' => '#f60');

	showsubtitle(array($Plang['4b3b548154549518'], $Plang['3982634cd20768c9'], $Plang['24dbae32d67e23d7'], $Plang['75d24f054db77fd2'], $Plang['535e5fdefa04f246'], $Plang['ca5a0d75b677d381']));
	foreach($all as $val) {
		$val[$search] = !empty($keyword) ? str_replace($keyword, '<span>' . $keyword . '</span>', $val[$search]) : $val[$search];
		showtablerow('class="tr"' . $val['id'] . '"', array('class="td25"'), array(
			$val['wechatuser'],
			"<a href='plugin.php?id=wq_wechatshow&mod=view&wid=" . $val['wechatuser'] . "' target='_blank'>" . $val['wechatname'] . "</a>",
			"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
			$val['collectnum'],
			date("Y-m-d H:i:s", $val['time']),
			'<font style="color:' . $status_color[$val['status']] . '">' . $show_status[$val['status']] . '</font>',
			)
		);
	}
	$multi = multi($count, $limit, $page, $mpurl);
	showtablerow('class="tr"', array('class="td25"'), array($multi));
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
} else {
	switch($_GET['delVal']) {
		case 0:
			$time = strtotime(date('Y-m-d H:i:s', strtotime('-3 day')));
			break;
		case 1:
			$time = strtotime(date('Y-m-d H:i:s', strtotime('-7 day')));
			break;
		case 2:
			$time = strtotime(date('Y-m-d H:i:s', strtotime('-15 day')));
			break;
		case 3:
			$time = strtotime(date('Y-m-d H:i:s', strtotime('-1 month')));
			break;
	}
	$flag = DB::delete('wq_wechatcollecting_log', 'time <' . $time);
	cpmsg($Plang['ba7e3b3a3eb84abd'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_cron_log', 'loadingform');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>