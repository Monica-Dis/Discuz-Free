<?php

/**
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *
 * From: DisM.taobao.Com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: import_ariable_ariable.inc.php 2013-5-18 ����02:38:10Z DisM��Taobao��Com $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
set_time_limit(1800);
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

if(!submitcheck('update_submit')) {
	showtips('<li>' . $Plang['b122b07dd9b2c7c9'] . '</li><li>' . $Plang['836576351f937365'] . '</li>');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_update_wechatlogo', 'update_submit');
	showsubmit('update_submit', 'submit');
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
} else {
	$url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_update_wechatlogo';
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_headimage_is_empty();

	$count = count($list);
	$tips = $Plang['aca2899ea8ef4a04'];
	if($count) {
		$tips = $Plang['09e3ed0ecce94404'];
		$url .= $temstr = '&update_submit=yes&oneflag=yes';
	}
	if($count && !$_GET['oneflag']) {
		$tips = $Plang['9d2ea3350319cde1'];
		cpmsg(sprintf($tips, $count), $url, 'loadingform');
	}
	$wechatid = $introc = $name = array();
	foreach($list as $key => $value) {
		$wechatid[$value['wechatid']] = $value['wechatid'];
		$introc[] = $value['intro'];
		$name[] = $value['name'];
	}
	$s = $e = 0;

	foreach($list as $key => $value) {
		$data = array();
		$s_num = $e_num = 0;
		if(!in_array($value['wechatid'], $wechatid)) {
			$s++;
			continue;
		}
		if($key) {
			sleep(3);
		}

		if(strpos($value['wechatid'], 'gh_') !== false) {
			$logolist = wqWechatApigetListByKeywordType($value['name'], '1', 1);

			if(count($logolist) == 1) {
				if($logolist[0]['name'] == $value['name'] || $logolist[0]['username'] == $value['wechatid']) {
					$logo = save_images($logolist[0]['logo'], $logolist[0]['username']);
					if($logo) {
						$data['headimage'] = $logo;
						$data['logoflag'] = 0;
					} else {
						$data['logoflag'] = 3;
						$data['headimage'] = '';
					}
					$s_num = 1;
					$data['wechatid'] = $logolist[0]['username'];
				} else {
					$data['logoflag'] = 2;
					$e_num = 1;
					$data['headimage'] = '';
				}

				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($value['id'], $data);
				unset($wechatid[$value['wechatid']]);
				$s = $s + $s_num;
				$e = $e + $e_num;
			} else {
				foreach($logolist as $k => $v) {
					if((in_array($v['username'], $wechatid))) {
						$logo = save_images($v['logo'], $v['username']);
						if($logo) {
							$data['headimage'] = $logo;
							$data['logoflag'] = 0;
						} else {
							$data['logoflag'] = 3;
							$data['headimage'] = '';
						}
						$s_num = 1;
						C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($value['id'], $data);
						$s = $s + $s_num;
						unset($wechatid[$v['wechatid']]);
					}
				}
				if(in_array($value['wechatid'], $wechatid)) {
					$data['headimage'] = '';
					$data['logoflag'] = 2;
					C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($value['id'], $data);
					$e++;
					unset($wechatid[$value['wechatid']]);
				}
			}
		} else {
			$logolist = wqWechatApigetListByKeywordType($value['wechatid'], '1', 1);

			$data = array();
			if($logolist[0]) {
				$logo = save_images($logolist[0]['logo'], $value['wechatid']);

				if($logo) {
					$data['headimage'] = $logo;
					$data['logoflag'] = 0;
				} else {
					$data['logoflag'] = 3;
					$data['headimage'] = '';
				}
				$s_num = 1;
			} else {
				$data['logoflag'] = 1;
				$e_num = 1;
				$data['headimage'] = '';
			}
			C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($value['id'], $data);
			$s = $s + $s_num;
			$e = $e + $e_num;
			unset($wechatid[$value['wechatid']]);
		}
		if($s > 5) {
			break;
		}
	}

	if($count - $s - $e) {
		cpmsg(sprintf($tips, $s, $e, $count - $s - $e), $url, 'loadingform');
	} else {
		cpmsg($Plang['aca2899ea8ef4a04'], str_replace($temstr, '', $url), 'succeed');
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>