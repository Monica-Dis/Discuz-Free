<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'stat':
		$cache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $cache));
		break;
	case 'sql':
		$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(10) unsigned NOT NULL,
  `wechatuser` varchar(100) NOT NULL,
  `wechatname` varchar(120) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `username` varchar(120) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `date` int(8) unsigned NOT NULL,
  `collectnum` int(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;
		runquery($sql);

		$upgradesql80 = "CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_seccodelog` (\n" .
			"`id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"`errcode` tinyint(1) NOT NULL,\n" .
			"`errtips` varchar(100) NOT NULL,\n" .
			"`dateline` int(10) unsigned NOT NULL,\n" .
			"PRIMARY KEY (`id`),\n" .
			"KEY `errcode` (`errcode`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_temparticle` (\n" .
			"`id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"`title` varchar(100) NOT NULL,\n" .
			"`url` varchar(255) NOT NULL,\n" .
			"`imglink` varchar(255) NOT NULL,\n" .
			"`date` int(10) unsigned NOT NULL,\n" .
			"`status` tinyint(3) NOT NULL DEFAULT '0',\n" .
			"`name` varchar(50) NOT NULL,\n" .
			"`wechatid` varchar(40) NOT NULL,\n" .
			"`summary` varchar(255) NOT NULL,\n" .
			"`uid` int(10) unsigned NOT NULL,\n" .
			"`username` varchar(50) NOT NULL,\n" .
			"`wid` int(10) unsigned NOT NULL,\n" .
			"`classid` int(10) unsigned NOT NULL,\n" .
			"`collecttime` int(10) NOT NULL,\n" .
			"PRIMARY KEY (`id`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_attachment` (\n" .
			" `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			" `articleid` int(10) unsigned NOT NULL,\n" .
			" `type` tinyint(1) unsigned NOT NULL,\n" .
			" `imageurl` varchar(255) NOT NULL,\n" .
			" PRIMARY KEY (`id`),\n" .
			" KEY `articleid` (`articleid`),\n" .
			" KEY `type` (`type`),\n" .
			" KEY `imageurl` (`imageurl`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_poll` (\n" .
			"`id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"`uid` int(10) unsigned NOT NULL,\n" .
			"`username` varchar(60) NOT NULL,\n" .
			"`articleid` int(10) unsigned NOT NULL,\n" .
			"`polltype` tinyint(3) NOT NULL DEFAULT '0',\n" .
			"`dateline` int(10) unsigned NOT NULL,\n" .
			" PRIMARY KEY (`id`),\n" .
			" KEY (`uid`),\n" .
			" KEY (`articleid`),\n" .
			" KEY (`polltype`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_recommend_list` (\n" .
			" `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			" `wid` int(10) unsigned NOT NULL,\n" .
			" `siteid` tinyint(3) unsigned NOT NULL,\n" .
			" `date` int(10) unsigned NOT NULL,\n" .
			" `type` tinyint(1) unsigned NOT NULL,\n" .
			" `displayorder` int(10) unsigned NOT NULL,\n" .
			" `keyword` varchar(60) NOT NULL,\n" .
			" PRIMARY KEY (`id`),\n" .
			" KEY `wid` (`wid`),\n" .
			" KEY `siteid` (`siteid`),\n" .
			" KEY `displayorder` (`displayorder`),\n" .
			" KEY `keyword` (`keyword`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_article_addviews` (\n" .
			"  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',\n" .
			"  `addviews` int(10) unsigned NOT NULL DEFAULT '0',\n" .
			"  PRIMARY KEY (`id`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_wechat_addviews` (\n" .
			"  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',\n" .
			"  `addviews` int(10) unsigned NOT NULL DEFAULT '0',\n" .
			"  PRIMARY KEY (`id`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatcollecting_searchcache` (\n" .
			" `searchid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			" `srchmod` int(10) unsigned NOT NULL DEFAULT '1',\n" .
			" `keywords` varchar(255) NOT NULL,\n" .
			" `useip` varchar(15) NOT NULL,\n" .
			" `uid` mediumint(10) unsigned NOT NULL,\n" .
			" `expiration` int(10) unsigned NOT NULL,\n" .
			" `num` mediumint(6) unsigned NOT NULL,\n" .
			" `ids` text NOT NULL,\n" .
			" `dateline` int(10) unsigned NOT NULL,\n" .
			" PRIMARY KEY (`searchid`),\n" .
			" KEY `srchmod` (`srchmod`),\n" .
			" KEY `keywords` (`keywords`),\n" .
			" KEY `useip` (`useip`),\n" .
			" KEY `uid` (`uid`),\n" .
			" KEY `expiration` (`expiration`),\n" .
			" KEY `dateline` (`dateline`)\n" .
			") ENGINE=MyISAM;\n";

		runquery($upgradesql80);

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_wechat'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('maintain_uid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `maintain_uid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('support', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `support` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('against', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `against` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('viewendcollectdate', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `viewendcollectdate` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('logoflag', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `logoflag` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}
		if(!in_array('wechatbiz', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `wechatbiz` varchar(100) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('collectnewdate', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `collectnewdate` int(10) unsigned NOT NULL";
			DB::query($sql);
		}
		if(!in_array('type', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `type` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('collectfinish', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `collectfinish` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('collectnumber', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `collectnumber` tinyint(2) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('article_classid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `article_classid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('collectdate', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `collectdate` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('endcollectdate', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `endcollectdate` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('endtime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `endtime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('tmpurl', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `tmpurl` varchar(255) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('recommend_num', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `recommend_num` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('first_num', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `first_num` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}

		if(!in_array('wechatbgimg', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `wechatbgimg` varchar(255) NOT NULL;";
			DB::query($sql);
		}

		if(!in_array('common_view', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `common_view` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('newqrcode', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `newqrcode` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('view_mode', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD `view_mode` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatcollecting_wechat'));
		$col_index_wechat = array();
		while($row = DB::fetch($query)) {
			$col_index_wechat[] = $row['Key_name'];
		}
		if(!in_array('maintain_uid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD INDEX `maintain_uid` (`maintain_uid`);";
			DB::query($sql);
		}
		if(!in_array('common_view', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD INDEX `common_view` (`common_view`);";
			DB::query($sql);
		}

		if(!in_array('newqrcode', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD INDEX `newqrcode` (`newqrcode`);";
			DB::query($sql);
		}
		if(!in_array('view_mode', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " ADD INDEX `view_mode` (`view_mode`);";
			DB::query($sql);
		}
		$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " CHANGE `classid` `classid` INT(10) UNSIGNED NOT NULL";
		DB::query($sql);
		$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_wechat') . " CHANGE `article_classid` `article_classid` INT(10) UNSIGNED NOT NULL";
		DB::query($sql);

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_temparticle'));
		$col_field_temparticle = array();
		while($row = DB::fetch($query)) {
			$col_field_temparticle[] = $row['Field'];
		}
		if(!in_array('isfirst', $col_field_temparticle)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_temparticle') . " ADD `isfirst` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}
		if(!in_array('isoriginal', $col_field_temparticle)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_temparticle') . " ADD `isoriginal` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}

		$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_temparticle') . " CHANGE `classid` `classid` INT(10) UNSIGNED NOT NULL";
		DB::query($sql);

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_article_content'));
		$col_field_article_content = array();
		while($row = DB::fetch($query)) {
			$col_field_article_content[] = $row['Field'];
		}
		if(!in_array('fileterheader', $col_field_article_content)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article_content') . " ADD `fileterheader` tinyint(3) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}



		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_article'));
		$col_field_article = array();
		while($row = DB::fetch($query)) {
			$col_field_article[] = $row['Field'];
		}
		if(in_array('collectfinish', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " DROP `collectfinish`;";
			DB::query($sql);
		}
		if(in_array('collectnumber', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " DROP `collectnumber`;";
			DB::query($sql);
		}
		if(!in_array('imgdownloaded', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `imgdownloaded` tinyint(1) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('isfirst', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `isfirst` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}
		if(!in_array('recommend', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `recommend` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}
		if(!in_array('admrecommend', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `admrecommend` tinyint(3) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}
		if(!in_array('support', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `support` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('against', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `against` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('rectime', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `rectime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('adminrectime', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `adminrectime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('isoriginal', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `isoriginal` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}

		if(!in_array('contenttableid', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `contenttableid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('isgroup', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `isgroup` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}

		if(!in_array('isstick', $col_field_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD `isstick` tinyint(1) unsigned NOT NULL DEFAULT 0;";
			DB::query($sql);
		}


		$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " CHANGE `classid` `classid` INT(10) UNSIGNED NOT NULL";
		DB::query($sql);

		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatcollecting_article'));
		$col_index_article = array();
		while($row = DB::fetch($query)) {
			$col_index_article[] = $row['Key_name'];
		}
		if(!in_array('tid', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `tid` (`tid`);";
			DB::query($sql);
		}
		if(!in_array('aid', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `aid` (`aid`);";
			DB::query($sql);
		}
		if(!in_array('rectime', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `rectime` (`rectime`);";
			DB::query($sql);
		}
		if(!in_array('adminrectime', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `adminrectime` (`adminrectime`);";
			DB::query($sql);
		}
		if(!in_array('isgroup', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `isgroup` (`isgroup`);";
			DB::query($sql);
		}

		if(!in_array('isstick', $col_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX `isstick` (`isstick`);";
			DB::query($sql);
		}

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_class'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('onlyarticle', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_class') . " ADD `onlyarticle` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('fid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_class') . " ADD `fid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('linkurl', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_class') . " ADD `linkurl` varchar(150) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('catid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_class') . " ADD `catid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('groupfid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_class') . " ADD `groupfid` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatcollecting_log'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}

		if(!in_array('status', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_log') . " ADD `status` tinyint(1) NOT NULL;";
			DB::query($sql);
		}
		if($_GET['fromversion'] > 5.8 && $_GET['fromversion'] <= 8.8) {
			$wechat_list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_group_wechatid();
			foreach($wechat_list as $key => $val) {
				$article_num = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wechatid($val['wechatid'], false);
				$value = array('wq_wechatcollecting_wechat', $val['wechatid'], $val['id']);
				$del = DB::query('DELETE FROM %t WHERE wechatid = %s AND id != %d', $value);
				$update_art_num = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($val['id'], array('articlenum' => $article_num));
				$art_data = array('wq_wechatcollecting_article', $val['id'], $val['wechatid']);
				$update_art_wid = DB::query('UPDATE %t SET wid = %d WHERE wechatid = %s', $art_data);
				$tempart_data = array('wq_wechatcollecting_temparticle', $val['id'], $val['wechatid']);
				$update_art_wid = DB::query('UPDATE %t SET wid = %d WHERE wechatid = %s', $tempart_data);
			}
		}

		if($_GET['fromversion'] < 11.9) {
			$update_type = "ALTER TABLE " . DB::table('wq_wechatcollecting_article_content') . " MODIFY COLUMN `content` mediumtext NOT NULL;";
			DB::query($update_type);
		}

		if($_GET['fromversion'] < 11.8) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_temparticle') . " ADD INDEX title ( `title` )";
			DB::query($sql);
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_temparticle') . " ADD INDEX wechatid ( `wechatid` )";
			DB::query($sql);
		}
		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatcollecting_attachment'));
		$attachment = array();

		while($row = DB::fetch($query)) {
			$attachment[] = $row['Key_name'];
		}
		if(!in_array('type', $attachment)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_attachment') . " ADD INDEX type ( `type` )";
			DB::query($sql);
		}
		if(!in_array('imageurl', $attachment)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_attachment') . " CHANGE `imageurl` `imageurl` VARCHAR( 255 ) NOT NULL";
			DB::query($sql);

			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_attachment') . " ADD INDEX imageurl ( `imageurl` )";
			DB::query($sql);
		}

		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatcollecting_article'));
		$key_index_article = array();
		while($row = DB::fetch($query)) {
			$key_index_article[] = $row['Key_name'];
		}
		if(!in_array('views', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX views ( `views` )";
			DB::query($sql);
		}


		if(!in_array('status', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX status ( `status` )";
			DB::query($sql);
		}
		if(!in_array('wid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX wid ( `wid` )";
			DB::query($sql);
		}
		if(!in_array('tid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX tid ( `tid` )";
			DB::query($sql);
		}
		if(!in_array('aid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX aid ( `aid` )";
			DB::query($sql);
		}
		if(!in_array('classid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX classid ( `classid` )";
			DB::query($sql);
		}
		if(!in_array('wechatid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX wechatid ( `wechatid` )";
			DB::query($sql);
		}
		if(!in_array('favorites', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX favorites ( `favorites` )";
			DB::query($sql);
		}
		if(!in_array('title', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX title ( `title` )";
			DB::query($sql);
		}
		if(!in_array('collecttime', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX collecttime ( `collecttime` )";
			DB::query($sql);
		}
		if(!in_array('date', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX date ( `date` )";
			DB::query($sql);
		}
		if(!in_array('isfirst', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX isfirst ( `isfirst` )";
			DB::query($sql);
		}
		if(!in_array('admrecommend', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX admrecommend ( `admrecommend` )";
			DB::query($sql);
		}
		if(!in_array('recommend', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX recommend ( `recommend` )";
			DB::query($sql);
		}
		if(!in_array('contenttableid', $key_index_article)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " ADD INDEX contenttableid ( `contenttableid` )";
			DB::query($sql);
		}

		$sql = "ALTER TABLE " . DB::table('wq_wechatcollecting_article') . " CHANGE `url` `url` VARCHAR( 600 )";
		DB::query($sql);

		require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/install/wqcache_init.php';
		if($_GET['fromversion'] < 17.0) {
			wq_wechatcollecting_update_cron_time('wq_wechatcollecting', 'cron_wq_checkip_iscollect');
		}
		if(!file_exists(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php')) {
			wq_rmdir(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend');
		} else {
			require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/needdir_config.php';
			wq_wechatcollecting_deldir(DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/pluginextend/', $need_dir);
		}

		if($_GET['fromversion'] < 24.2) {
			if(!function_exists('deletethread') || !function_exists('deletearticle')) {
				include_once libfile('function/delete');
			}
			if(!function_exists('getthreadcover')) {
				include_once libfile('function/forum');
			}
			if(!function_exists('updatepostcredits')) {
				include_once libfile('function/post');
			}
			$re = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search('', 0, 100, "iPhone|iPad|iPod|iO");
			$aids = $tids = array();
			foreach($re as $value) {
				$value['aid'] ? $aids[] = $value['aid'] : '';
				$value['tid'] ? $tids[] = $value['tid'] : '';
			}
			if(!empty($aids)) {
				$aids ? deletearticle($aids) : '';
			}
			if(!empty($tids)) {
				$tids ? deletethread($tids) : '';
			}
		}

		if($_GET['fromversion'] <= 24.8) {
			$wechats = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_commonview(1);
			foreach($wechats as $wechat) {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wechat['id'], array('view_mode' => 4));
			}
		}



		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		require_once libfile("function/cache");
		if(is_file(DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')) {
			require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';

			$hook = WeChatHook::getAPIHook('wq_wechatcollecting');

			$data = array(
				array('viewthread_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => 'WQ_WSQAPI',
						'method' => 'viewthread_variables'
					)),
				array('sendreply_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => '',
						'method' => ''
					)),
			);
			WeChatHook::updateAPIHook($data);
		}
		wq_cron_create('wq_wechatcollecting');
		clear_old_tpl("wq_wechatcollecting");
		clear_old_tpl("wq_wechatshow");
		clear_old_tpl("wq_wechatreader");
		wq_clear("wq_wechatcollecting");
		$finish = TRUE;
		break;
}

function wq_clear($id) {

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id;

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/^discuz\_plugin\_' . $id . '(\_\w+)?\.xml$/', $f) || in_array($f, array("install.php", "upgrade.php"))) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}

function clear_old_tpl($id) {
	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/touch/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/mobile/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/';

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}

function wq_wechatcollecting_update_cron_time($pluginid, $filename) {
	$dir = DISCUZ_ROOT . './source/plugin/' . $pluginid . '/cron';
	$filename .= '.php';
	$content = file_get_contents($dir . '/' . $filename);
	preg_match("/cronname\:(.+?)\n/", $content, $r);
	$name = $Plang[trim($r[1])];
	preg_match("/week\:(.+?)\n/", $content, $r);
	$weekday = trim($r[1]) ? intval($r[1]) : -1;
	preg_match("/day\:(.+?)\n/", $content, $r);
	$day = trim($r[1]) ? intval($r[1]) : -1;
	preg_match("/hour\:(.+?)\n/", $content, $r);
	$hour = trim($r[1]) ? intval($r[1]) : -1;
	preg_match("/minute\:(.+?)\n/", $content, $r);
	$minute = trim($r[1]) ? trim($r[1]) : 0;
	$minutenew = explode(',', $minute);
	foreach($minutenew as $key => $val) {
		$minutenew[$key] = $val = intval($val);
		if($val < 0 || $var > 59) {
			unset($minutenew[$key]);
		}
	}
	$minutenew = array_slice(array_unique($minutenew), 0, 12);
	$minutenew = implode("\t", $minutenew);
	$filename = $pluginid . ':' . $filename;
	$cronid = C::t('common_cron')->get_cronid_by_filename($filename);
	if($cronid) {
		C::t('common_cron')->update($cronid, array(
			'name' => $name,
			'weekday' => $weekday,
			'day' => $day,
			'hour' => $hour,
			'minute' => $minutenew,
		));
	}
}

function wq_wechatcollecting_deldir($dir, $need_dir = array(), $isdeldirname = false) {
	if($dir === '.' || $dir === '..' || strpos($dir, '..') !== false) {
		return false;
	}
	if(substr($dir, -1) === "/") {
		$dir = substr($dir, 0, -1);
	}
	if(!file_exists($dir) || !is_dir($dir)) {
		return false;
	} elseif(!is_readable($dir)) {
		return false;
	} else {
		if(($dirobj = dir($dir))) {
			while(false !== ($file = $dirobj->read())) {
				if($file != "." && $file != ".." && $file != 'needdir_config.php' && !in_array($file, $need_dir)) {
					$path = $dirobj->path . "/" . $file;
					if(is_dir($path)) {
						wq_rmdir($path);
					} else {
						unlink($path);
					}
				}
			}
			$dirobj->close();
		}
		if($isdeldirname) {
			rmdir($dir);
		}
		return true;
	}
	return false;
}
//From:  d'.'is'.'m.ta'.'obao.com
?>