<?php

/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: wsqapi.class.php 34924 2014-08-27 06:33:08Z DISM.TAOBAO.COM $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/class/base.class.php';

class WQ_WSQAPI extends plugin_wq_wechatcollecting_base {

	public function WQ_WSQAPI() {
		$this->init();
		$this->common_base();
	}

	function viewthread_variables(&$variables) {
		global $_G;
		$article = $this->fetch_article_by_tid($_GET['tid']);
		if(empty($article)) {
			return '';
		}
		$wechatinfo_html = $this->get_wechatinfo_html_for_mobile($article['articleid'], true);
		if(!function_exists('wq_wechatcollecting_get_article_contenttableid')) {
			include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
		}
		$content = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->result_first_by_articleid($article['articleid'], wq_wechatcollecting_get_article_contenttableid($article['articleid']));
		$content = str_replace(array("jpg&", "#wechat_redirect"), array("jpg?", ""), base64_decode($content));

		include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php";
		$content = fileter_header($content);

		if($this->setting['is_saveimages'] && $this->setting['view_issaveimg']) {
			$content = download_remote_images($content, $article['articleid'], $this->setting);
		}

		foreach($variables['postlist'] as $key => $post) {

			if($post['first'] == '1') {
				$message = $wechatinfo_html . $content;
				$find = array(
					"data/attachment/",
				);
				$replace = array(
					$_G['siteurl'] . "data/attachment/",
				);
				$message = str_replace($find, $replace, $message);
				$variables['postlist'][$key]['message'] = $message;
			} else {
				continue;
			}
		}
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>