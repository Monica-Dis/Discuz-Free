wqjq(document).ready(function() {
	wqjq(document).on("click", ".wechatlist li", function() {
		module = wqjq(this).find("[name ^= usernames]:checkbox");
		module.attr("checked", !module.attr("checked"));
		if (wqjq(this).hasClass("on")) {
			wqjq(this).removeClass("on");
		} else {
			wqjq(this).addClass("on");
		}

	});
	wqjq("#checkAll").bind("click", function() {
		module = wqjq(".wechatlist>li");
		module.each(function() {
			inp = wqjq(this).find("[name ^= usernames]:checkbox")
			inp.attr("checked", "checked");
			wqjq(this).addClass("on");

		});
	});
	wqjq("#cancleAll").bind("click", function() {
		module = wqjq(".wechatlist>li");
		module.each(function() {
			inp = wqjq(this).find("[name ^= usernames]:checkbox")
			inp.attr("checked", false);
			wqjq(this).removeClass("on");

		});
	});
	wqjq("#Inverse").bind("click", function() {

		module = wqjq(".wechatlist>li");
		module.each(function() {
			inp = wqjq(this).find("[name ^= usernames]:checkbox")
			inp.attr("checked", !inp.attr("checked"));
			if (!inp.attr("checked")) {
				wqjq(this).removeClass("on");
			} else {
				wqjq(this).addClass("on");
			}
		});
	});
	wqjq(".del").bind("click", function() {
		if (confirm(Is_recycle_bin)) {
			return true;
		} else {
			return false;
		}
	});

        wqjq("#load_next_page a").bind("click",function(){
            var formobj = wqjq('#subscription_collect');
            wqjq.ajax({
                type: 'POST',
                url: formobj.attr('action') + '&inajax=1',
                data: formobj.serialize(),
                dataType: 'html'
            }).success(function (data) {
                wqjq(".wechatlist").append(data);
                var begin = data.indexOf('listcode')
                var start = data.lastIndexOf('<input', begin)
                var end = emtypeflag = data.indexOf('<li>')
                if (end == -1) {
                    end = data.length
                }
                var formReplace1 = data.slice(0, start)
                var formReplace2 = data.slice(start, end)
                wqjq('#subscription_collect .totalPages').remove()
                wqjq('#subscription_collect .listcode').remove()
                wqjq('#subscription_collect').prepend(formReplace1)
                wqjq('#subscription_collect').prepend(formReplace2)
                if (emtypeflag == -1) {
                    showDialog('��ȫ������');
                }
            }).error(function () {
                showDialog('����ʧ��');
            });
            return false;
        });

        wqjq(".wqmanage_search button").bind("click",function(){
            var search_txt = wqjq(".wqmanage_search input").val();
            var start = location.href.indexOf('keyword');
            if(start == -1){
                location.href = location.href + '&keyword=' + search_txt;
            }else{
                location.href = location.href.slice(0, start) + 'keyword=' + search_txt;
            }
        });
});

function collecting_selectall() {
    var checkall = wqjq('#coll_checkall');
    var list = wqjq('.checks');
    if (checkall.attr('checked')) {
        checkall.attr('checked', false);
        list.attr('checked', false);
    } else {
        checkall.attr('checked', true);
        list.attr('checked', true);
    }
}

function show_hint() {
    wqjq('#collect_hint').show();
    wqjq('#collect_text').text(collect_text);
    wqjq('#collect_form').submit();
    wqjq("#collect_submit").attr("disabled", "disabled");
}