var wqimglists = new Array();
wqjq(function() {

    if (wqjq(".wq_video_iframe").length) {

        for (var i = 0; i < wqjq(".wq_video_iframe").length; i++) {
            var obj = wqjq(".wq_video_iframe").eq(i);
            var width = obj.width();
            var ratio = obj.attr('data-ratio');
            var height = width / ratio

            obj.attr('width', width).attr('height', height);
        }
    }

    if(wqjq('iframe').length) {
        wqjq('iframe').each(function(){
            if ((wqjq(this).attr('src') && wqjq(this).attr('src').indexOf('v.qq.com') != -1) || (wqjq(this).attr('data-src') && wqjq(this).attr('data-src').indexOf('v.qq.com') != -1)) {
                wqjq(this).addClass('video_iframe');
            }
        })
    }

    if (wqjq(".video_iframe").length) {
        var yw, yh, w = wqjq(window).width() - 20, h, xsrc;
        wqjq('.video_iframe').each(function(){
            yw = wqjq(this).attr("width");
            yh = wqjq(this).attr("height");
            h = w * yh / yw;

            xsrc = wqjq(this).attr("src") || wqjq(this).attr("data-src");
            xsrc = xsrc.replace("width=", "width=" + w + "&width=").replace("height=", "height=" + h + "&height=");
            xsrc  = xsrc + "&width=" + w + "&height=" + h;
            xsrc = xsrc.replace("preview", "player");

            wqjq(this).attr("src", xsrc);

            if(wqjq(this).attr("data-src")){
                    wqjq(this).attr("data-src", xsrc);
            }

            wqjq(this).css('cssText', 'width: '+ w + 'px!important');
            wqjq(this).height(h);
            wqjq(this).prop('scrolling', 'no');
        })

    }

    if (wqjq('.wqwechat_articleview_con img').length) {
        for (var i = 0; i < wqjq('.wqwechat_articleview_con img').length; i++) {
            if (wqjq('.wqwechat_articleview_con img').eq(i).prop('src').indexOf('wq_wechatcollecting') != -1) {
                wqjq('.wqwechat_articleview_con img').eq(i).attr('height', '');
                var imgwidths = document.getElementById('wqwechat_articleview_con');
                if(imgwidths != null){
                    var imgwidth = imgwidths.getElementsByTagName('img')[i].style.width;
                    wqjq('.wqwechat_articleview_con img').eq(i).css('withd', '100% ').css('z-index', '0').css('height', '').css('max-height',3000);
                    var allstyle = wqjq('.wqwechat_articleview_con img').eq(i).attr('style');

                    var stylewidth = '';
                    if(imgwidth){
                        stylewidth = "width:"+imgwidth +" !important;";
                    }
                    wqjq('.wqwechat_articleview_con img').eq(i).css("cssText", allstyle + stylewidth + "max-width:100% !important;");
                }
            }
        }
    }

});