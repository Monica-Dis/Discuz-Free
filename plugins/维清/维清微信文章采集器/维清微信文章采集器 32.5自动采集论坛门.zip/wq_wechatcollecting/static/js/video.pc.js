var zoomgroup = new Array(), aimgcount = new Array();
wqjq(function() {

	if (wqjq(".wq_video_iframe").length) {

		for (var i = 0; i < wqjq(".wq_video_iframe").length; i++) {
			var obj = wqjq(".wq_video_iframe").eq(i);
			var width = obj.width();
			var ratio = obj.attr('data-ratio');
			var height = width / ratio

			obj.attr('width', width).attr('height', height);
		}
	}

	if (wqjq('iframe').length) {
		for (var i = 0; i < wqjq('iframe').length; i++) {
			if (wqjq('iframe').eq(i).prop('src').indexOf('v.qq.com') != -1) {
				wqjq('iframe').eq(i).addClass('video_iframe');
			}
		}
	}

	if (wqjq(".video_iframe").length) {
		for (var j = 0; j < wqjq(".video_iframe").length; j++) {



			var new_w = 500, ratio_ = wqjq(".video_iframe").eq(j).attr('data-ratio') * 1 || (16 / 9);
                        var new_h = '';
                            if(ratio_ >= 1){
                                new_h = new_w /ratio_;
                            }else{
                                new_h = new_w * ratio_;
                            }
			var src = wqjq(".video_iframe").eq(j).attr('src');

			if (new_w && new_h) {
				wqjq(".video_iframe").eq(j).attr('width', new_w);
				wqjq(".video_iframe").eq(j).attr('height', new_h);
				var yw = src.match(/(width=)([0-9]+)/)[2], yh = src.match(/(height=)([0-9]+)/)[2];
				var new_src = src.replace('width=' + yw, 'width=' + new_w), new_src = new_src.replace('height=' + yh, 'height=' + new_h);
				wqjq(".video_iframe").eq(j).attr('src', new_src);
			} else {

				var w = src.match(/(width=)([0-9]+)/)[2], h = src.match(/(height=)([0-9]+)/)[2];
				if (w && h) {
					wqjq(".video_iframe").eq(j).attr('width', w);
					wqjq(".video_iframe").eq(j).attr('height', h);
				}
			}
		}
	}

	if (wqjq('.wqpc_con img').length) {
		for (var i = 0; i < wqjq('.wqpc_con img').length; i++) {
			if (wqjq('.wqpc_con img').eq(i).prop('src').indexOf('wq_wechatcollecting') != -1) {
				var idval = i + 1;

                                var data_src = wqjq('.wqpc_con img').eq(i).attr('src');
                                if (wqjq('.wqpc_con img').eq(i).attr('wqdata-src')) {
                                    var data_src = wqjq('.wqpc_con img').eq(i).attr('wqdata-src');
				}


				var attrset = {
					'height': '',
					'id': 'aimg_' + idval,
					'aimgid': idval,
					'data_ysrc': data_src,
					'zoomfile': data_src,
					'file': data_src,
					'articleid': wqjq('.wqpc_con img').eq(i).attr('articleid') ? wqjq('.wqpc_con img').eq(i).attr('articleid') : wqjq('.wqpc_con').attr('data-artid')
				};
				wqjq('.wqpc_con img').eq(i).attr(attrset).css('height', '').css('z-index', '0');
			}

		}
	}

	if (wqjq('.wqpc_con img').length) {
		var temarr = new Array();
		var articleid = '';
		for (var i = 0; i < wqjq('.wqpc_con img').length; i++) {
			if (wqjq('.wqpc_con img').eq(i).parents('a').length || wqjq('.wqpc_con img').eq(i).hasClass('wq_smilieimg')) {
				continue;
			}
			if (wqjq('.wqpc_con img').eq(i).prop('src').indexOf('wq_wechatcollecting') != -1 && wqjq('.wqpc_con img').eq(i).attr('aimgid')) {
				zoomgroup['aimg_' + wqjq('.wqpc_con img').eq(i).attr('aimgid')] = wqjq('.wqpc_con img').eq(i).attr('articleid');
				temarr.push(wqjq('.wqpc_con img').eq(i).attr('aimgid'))
				if (!articleid) {
					articleid = wqjq('.wqpc_con img').eq(i).attr('articleid');
				}
			}
		}
		aimgcount[articleid] = temarr
	}

	wqjq(".wqpc_con img").click(function() {
		if (wqjq(wqjq(this)[0]).parents('a').length || wqjq(wqjq(this)[0]).hasClass('wq_smilieimg'))
			return;

		if (wqjq(this)[0].src.indexOf('wq_wechatcollecting') != -1 && wqjq(wqjq(this)[0]).attr('aimgid')) {
			if (wqjq(wqjq(this)[0]).attr('data_ysrc')) {
				var srcurl = wqjq(wqjq(this)[0]).attr('data_ysrc');
			} else if (wqjq(wqjq(this)[0]).attr('wqdata-src')) {
				var srcurl = wqjq(wqjq(this)[0]).attr('wqdata-src');
			} else {
				var srcurl = wqjq(wqjq(this)[0]).attr('src');
			}
			_zoom(wqjq(this)[0], srcurl, 0, 0, 0);
		}
	});

        wqjq(document).on('scroll', function () {
            delayload()
        })
	wqjq(".wqpc_wechat_view .lazyload-home").each(function() {
            var imgwidth = wqjq(this).attr('data-w') > wqjq('.wqpc_wechat_view').width() ? wqjq('.wqpc_wechat_view').width() : wqjq(this).attr('data-w')
            wqjq(this).css({'max-width': imgwidth + 'px'})
        })
        delayload()
});

function delayload() {
        var document_top = wqjq(document).scrollTop()
        wqjq(".lazyload-home").each(function() {
            var img_top = wqjq(this).offset().top;
            if (img_top >= document_top && img_top <= document_top + wqjq(window).height()) {
                wqjq(this).prop('src', wqjq(this).attr('wqdata-src') ).removeClass("lazyload-home")

                this.onload = function () {
                    if (wqjq(this).parents('.wqlazydiv').length) {
                        feed_img(wqjq(this).parents('.wqlazydiv'));
                    }
                };
            }
        });
    }
    function feed_img(obj) {
        var img = new Image();
        img.src = obj.find('img').attr('wqdata-src');
        img.onload = function () {
            var img_width = img.width, img_height = img.height;
            if (obj.css('max-height')) {
                if (img_height < obj.css('max-height')) {
                    return;
                } else {
                    obj.height(obj.css('max-height'));
                }
            }
            if (img_width / obj.width() > img_height / obj.height()) {
                obj.find('img').height(obj.height());
                obj.find('img').width(obj.height() * img_width / img_height);
                var marginLeft = (obj.width() - obj.find('img').width()) / 2;
                obj.find('img').css('margin-left', marginLeft);
            } else {
                obj.find('img').width(obj.width());
                obj.find('img').height(obj.width() * img_height / img_width);
                var marginTop = (obj.height() - obj.find('img').height()) / 2;
                obj.find('img').css('margin-top', marginTop);
            }
        }
    }