<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_wechatcollecting.inc.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_GET['id'] = "wq_wechatcollecting:wq_wechatcollecting";
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
include_once libfile('function/home');


$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "index";

$allowmod = array('index', 'list', 'view', 'cp', 'api', 'ajax', 'search', 'edit', 'lookoriginal');

if(is_array($pconfig['addmodule'])) {
	foreach($pconfig['addmodule'] as $k => $v) {
		$allowmod = array_merge($allowmod, array($k));
		$dirlist[$k] = $v;
	}
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

if(is_array($pconfig['rewritemodule'])) {
	foreach($pconfig['rewritemodule'] as $k => $v) {
		if($k == $mod) {
			$dirlist[$k] = $v;
		}
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/' . $dirlist[$mod] . '/wechatcollecting_' . $mod . '.php';

?>