<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$navtitle = $navname = $Plang['0f16a714bd240ef6'];
if($_GET['step'] == 'del') {
	$articleid = $_GET['articleid'];
	if($_GET['type'] && $_GET['type'] == 'templist') {
		$del = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->fetch_first_by_id($articleid);
	} else {
		$del = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($articleid);
	}

	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($del['wid']);
	if(empty($del)) {
		showmessage($Plang['ce69b4426afcfc0f']);
	}
	if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $wechat['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['66ef666b87236e94']);
	}
	$type = '';
	if($_GET['type'] && $_GET['type'] == 'templist') {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->delete($articleid);
		$type = '&type=' . $_GET['type'];
	} else {
		del_article($del, true, $setting);
		include_once libfile('function/delete');
		include_once libfile('function/forum');
		$del['tid'] ? deletethread(array($del['tid'])) : '';
		$del['aid'] ? deletearticle(array($del['aid'])) : '';
	}

	showmessage($Plang['8987fdbb54a9953a'], 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage' . $type);
} elseif($_GET['step'] == 'recommend') {
	$page = $_GET['page'];
	$articleid = $_GET['aid'];

	$result = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($articleid);
	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($result['wid']);
	if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $wechat['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['66ef666b87236e94']);
	}
	if($result['status'] != '1') {
		showmessage($Plang['c39018d61c9aa7d1']);
	}
	if(!$result) {
		showmessage($Plang['ce69b4426afcfc0f']);
	}
	$data['recommend'] = $result['recommend'] == 0 ? 1 : 0;
	$data['rectime'] = time();
	$hint = $data['recommend'] ? $Plang['9a52f4d6ef956904'] : $Plang['bef022f6310db3b9'];
	C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, $data);
	update_wechat_field_by_wechatid($wechat['id'], array('recommend_num'));
	showmessage($hint, 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=' . $_GET['status'] . "&page=" . $page);
} elseif($_GET['step'] == 'switchrecommend') {
	$aids = $_GET['articleids'];
	$i = $j = $k = 0;

	$recommend = intval($_GET['recommend']);
	if(is_array($aids) && count($aids) > 0) {
		$wechat = array();
		foreach($aids as $key => $val) {
			$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid(intval($key));

			if($wechat['id'] != $data['wid']) {
				$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($data['wid']);
			}
			if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $wechat['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
				$j ++;
				continue;
			}
			if($data['status'] == '1') {
				$flag = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($key, array('recommend' => $recommend, 'rectime' => time()));
				if($flag) {
					$i ++;
					$wechatnum[$data['wid']] = $wechatnum[$data['wid']] + 1;
				} else {
					$j ++;
				}
			} else {
				$k ++;
			}
		}
	}
	foreach($wechatnum as $key => $value) {
		update_wechat_field_by_wechatid($key, array('recommend_num'));
	}
	$hint = $recommend ? $Plang['876bb8031df32628'] : $Plang['9c825be7149e5b97'];
	$url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=' . $_GET['status'] . '&page=' . $_GET['page'];
	showmessage(sprintf($Plang['2125e0624f1a1fb6'], $hint, $i, $j, $hint, $k), $url);
} else {
	$status = in_array($_GET['status'], array('0', '1', '-1')) ? array(intval($_GET['status'])) : array();
	$perpage = intval($setting['home_article_perpage']) < 1 ? 1 : intval($setting['home_wechat_perpage']);
	$page = max(1, $_GET['page']);
	$start = ($page - 1) * $perpage;
	$mpurl = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=' . $_GET['status'];
	$isset_uid = false;
	if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
		$isset_uid = $_G['uid'];
	}
	$wids = null;

	if($isset_uid) {
		$wechatlist = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_maintain_uid($_G['uid']);
		foreach($wechatlist as $key => $value) {
			$wids[] = $value['id'];
		}
	}

	if($_GET['type'] && $_GET['type'] == 'templist') {
		$navname = $Plang['41849363f272ef62'];
		$navtitle = $Plang['60e3d2ff55f0dca3'];
		$mpurl .= '&type=templist';
		$count = $isset_uid && !$wids ? 0 : C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->count_by_status($status, $wids);
		$list = $isset_uid && !$wids ? null : C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->fetch_all_by_status($status, $start, $perpage, $wids);
	} else {
		$count = $isset_uid && !$wids ? 0 : C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_status($status, $wids);
		$list = $isset_uid && !$wids ? null : C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_status($status, $start, $perpage, $wids);
	}

	foreach($list as $key => $val) {
		$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
	}

	$multi = multi($count, $perpage, $page, $mpurl);
	include template('wq_wechatcollecting:cp_articlemanage');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>