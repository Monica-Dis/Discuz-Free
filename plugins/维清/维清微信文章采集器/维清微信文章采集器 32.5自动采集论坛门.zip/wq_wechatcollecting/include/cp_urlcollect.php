<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$navtitle = $navname = $Plang['3e1083c0ed42484a'];
set_time_limit(1800);
if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
	showmessage($Plang['66ef666b87236e94']);
}
wq_wechatcollecting_check_isset_default_fid($setting, $Plang);
if(submitcheck('urlcollect')) {
	if(!$_GET['collect_url']) {
		showmessage($Plang['d364a2586584e2e4']);
	}
	$classid = intval($_GET['classid']);
	$article_classid = $_GET['article_classid'] ? intval($_GET['article_classid']) : $classid;
	$article_classid_thistime = $_GET['article_classid_thistime'] ? intval($_GET['article_classid_thistime']) : $article_classid;
	$_GET['collect_url'] = explode("\n", str_replace("\r\n", "\n", $_GET['collect_url']));

	$as = $ai = $ws = $wi = $kf = 0;
	$tem_wechatids = array();
	$portal_classid = C::t('common_syscache')->fetch('wq_portal_collect_set');
	foreach($_GET['collect_url'] as $key => $url) {
		$info = array();
		$info = wqWechatApigetArticleContentByUrl($url, true, true);
		if(!$info || $info == '-1') {
			$info == '-1' ? $kf++ : '';
			continue;
		}
		$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($info['wechatid']);
		$wid = 0;
		if(!$wechat) {
			$qrcode = save_images(wq_get_qrcode_by_wechatid($info['wechatid']), $info['wechatid'], 'qrcode');
			$headimage = save_images($info['wechatlogo'], $info['wechatid']);
			$wechat = array(
				'collecttime' => TIMESTAMP,
				'uid' => intval($_G['uid']),
				'username' => $_G['username'],
				'status' => 1,
				'classid' => $classid,
				'article_classid' => $article_classid,
				'name' => dhtmlspecialchars($info['wechatname']),
				'wechatid' => $info['wechatid'],
				'intro' => dhtmlspecialchars($info['intro']),
				'qrcode' => $qrcode,
				'headimage' => $headimage,
				'wechatbiz' => $info['wechatbiz']
			);
			$wechat = wq_wechatcollecting_register_newuser($wechat, $setting);
			$wid = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->insert($wechat, true);
			$ws ++;
		} else {
			$wid = $wechat['id'];
			if(!in_array($wechat['wechatid'], $tem_wechatids)) {
				$wi ++;
			}
		}
		$tem_wechatids[] = $wechat['wechatid'];
		$tem_wechatids = array_unique($tem_wechatids);

		$article = wq_wechatcollecting_wechatarticle_exists($info['wechatid'], $info['title'], 0, $setting['only_title_judge']);

		if($article) {
			$ai ++;
			continue;
		}
		if($wid) {
			$articledata = array(
				'url' => $info['url'],
				'title' => $info['title'],
				'classid' => $classid,
				'collecttime' => TIMESTAMP,
				'name' => $info['wechatname'],
				'status' => 1,
				'wechatid' => $info['wechatid'],
				'summary' => $info['articleintro'],
				'imglink' => $info['articleimglink'],
				'date' => $info['articledate'],
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'wid' => $wid,
				'isoriginal' => $info['isoriginal']
			);
			$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->insert($articledata, true);
			if(!$articleid) {
				continue;
			}
			$as ++;
			$contentdata = array(
				'articleid' => $articleid,
				'content' => base64_encode($info['content']),
				'collecttime' => TIMESTAMP,
				'wid' => $wid,
				'fileterheader' => 1
			);
			C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->insert($contentdata);
			$imglink = save_images($articledata['imglink'], $articleid, 'article');
			$summary = $articledata['summary'];

			$wechat['uid'] = $_G['uid'];
			$wechat['username'] = $_G['username'];

			$postresult = wq_common_post_forum_or_portal($setting, $classid, $summary, $wechat, array('imglink' => $imglink, 'title' => $articledata['title']), $wechatclass_article, 1);
			$tid = $postresult['tid'];
			$aid = $postresult['aid'];

			$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, array('imglink' => $imglink, 'tid' => $tid, 'aid' => $aid));
			update_wechat_field_by_wechatid($wid, array('articlenum'));

			$addrecord = array();
			if(empty($wechat['collectnewdate']) || $wechat['collectnewdate'] < $info['articledate']) {
				$addrecord['collectnewdate'] = $info['articledate'];
			}
			if(!empty($addrecord)) {
				$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, $addrecord);
			}
		}
	}
	$locaturl = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=urlcollect';
	showmessage(sprintf($Plang['ae98f8010943a7fd'], $as, $ai, $kf, $ws, $wi), $locaturl);
} else {
	include template('wq_wechatcollecting:cp_urlcollect');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>