<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: cp_wechat.php 2015-4-11 21:19:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
set_time_limit(3800);

$navtitle = 'wechat';
$op = $_GET['op'];
if($op == 'list') {
	$recommend_wids = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_all_by_siteid_keyword_group_by_wid();
	$wids = array();
	foreach($recommend_wids as $key => $value) {
		$wids[] = $value['wid'];
	}

	$navtitle = $navname = $Plang['a2963175c4f5a0ca'];
	$meun = $_GET['meun'];
	$perpage = intval($setting['home_wechat_perpage']) < 1 ? 1 : intval($setting['home_wechat_perpage']);
	$page = max(1, $_GET['page']);
	$start = ($page - 1) * $perpage;
	$mpurl = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=' . $op . '&status=' . $_GET['status'];
	$mpurl .= $meun ? '&meun=' . $meun : '';
	$statusarr = array('0', '1', '-1', '-2', '6', 'auto-1', 'auto-0');
	$status = in_array($_GET['status'], $statusarr) ? (in_array($_GET['status'], array('auto-1', 'auto-0')) ? $_GET['status'] : array(intval($_GET['status'])) ) : array(0, 1, -1);

	$recommend = $_GET['status'] == '6' ? true : false;
	$m_uid = $uid = 0;
	if($meun == 'my_renling') {
		$navtitle = $Plang['f774901d17cae8f1'] . $Plang['f8497259f9b3f761'];
		$m_uid = $_G['uid'];
	} elseif($meun == 'my_submit') {
		$navtitle = $Plang['dde343556ea0716c'] . $Plang['f8497259f9b3f761'];
		$uid = $_G['uid'];
	} elseif(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['66ef666b87236e94']);
	}
	$status = $recommend ? null : $status;
	$wechatname = trim($_GET['keyword']) ? trim($_GET['keyword']) : '';
	$mpurl = $wechatname ? $mpurl . '&keyword=' . $wechatname : $mpurl;
	if($recommend) {
		if(count($wids) < 1) {
			$count = 0;
			$list = null;
		} else {
			$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->count_by_search($status, $wechatname, $wids, $uid, $m_uid, true);
			$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_search($status, $start, $perpage, $wechatname, 'collecttime', $wids, $uid, $m_uid, true);
		}
	} else {
		$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_by_uid_status($uid, $m_uid, $status, $start, $perpage, '', $wechatname);
		$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->count_by_status($status, $uid, $m_uid, '', $wechatname);
	}


	foreach($list as $key => $value) {
		$list[$key]['recommend'] = in_array($value['id'], $wids) ? 1 : 0;
		$list[$key]['qrcode'] = wq_get_qrcode_by_wechatid($value['wechatid']);
		$list[$key]['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($value['headimage']);
		$list[$key]['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($value['wechatbgimg']);
	}
	$multi = multi($count, $perpage, $page, $mpurl);
} elseif($op == 'del') {
	$wechatid = $_GET['wechatid'];
	$del = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
	if(!$del || $del['status'] == -2) {
		showmessage($Plang['af00610f043790a1']);
	}
	if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $del['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
		if($plugin_wechatshow) {
			showmessage($Plang['8c71dff239b8c7eb'], 'plugin.php?id=wq_wechatshow&mod=view&wid=' . $del['wechatid']);
		} else {
			showmessage($Plang['66ef666b87236e94']);
		}
	}

	$data['status'] = -2;
	$data['automaticcollect'] = 0;
	$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($del['id'], $data);
	C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->clear_cache_by_id($del['id']);
	C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_wechatid(array('status' => -2), $wechatid);
	showmessage($Plang['c3a123f89d6d5ab2'], 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&status=' . $_GET['status'] . "&page=" . $page . "&meun=" . $_GET['meun']);
} elseif($op == 'restore') {
	$wechatid = $_GET['wechatid'];
	$restore = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
	if($restore['status'] != -2) {
		showmessage($Plang['af00610f043790a1']);
	}
	if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $restore['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['66ef666b87236e94']);
	}
	$status = $setting['wechat_status'] == '1' ? 0 : 1;
	$data['status'] = $status;
	C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($restore['id'], $data);
	C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update_wechatid(array('status' => $status), $wechatid);
	showmessage($Plang['d7b6bbbb7b604f31'], 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&&meun=' . $_GET['meun']);
} elseif($op == 'automaticcollect') {
	$page = max(1, $_GET['page']);
	$wechatid = $_GET['wechatid'];
	$automaticcollect = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
	if(!$automaticcollect) {
		showmessage($Plang['af00610f043790a1']);
	}
	if($automaticcollect['status'] != '1') {
		showmessage($Plang['08ee8a6ed5c33746']);
	}
	if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $automaticcollect['uid'] && $_G['uid'] != $automaticcollect['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['66ef666b87236e94']);
	}
	$data['automaticcollect'] = $automaticcollect['automaticcollect'] == 0 ? 1 : 0;
	$hint = $automaticcollect['automaticcollect'] == 0 ? $Plang['4ce613778009f964'] : $Plang['9a4f10b3d0863cbe'];

	C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($automaticcollect['id'], $data);

	showmessage($hint, 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&status=' . $_GET['status'] . "&page=" . $page . "&meun=" . $_GET['meun']);
} elseif($op == 'autoswitch') {
	$ids = $_POST['wid'];

	$i = $j = $k = 0;
	$status = 'auto-0';

	if(is_array($ids) && count($ids) > 0) {
		foreach($ids as $key => $val) {
			$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($key);
			if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $data['uid'] && $_G['uid'] != $data['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups'])) {
				$j ++;
				continue;
			}
			if($data['status'] == '1') {
				$updateData = array();
				if($_GET['autocollecting'][$key] !== null) {
					$updateData['automaticcollect'] = $_GET['autocollecting'][$key] ? 0 : 1;
				}
				if($_GET['displayorder']) {
					$updateData['displayorder'] = $_GET['displayorder'][$key];
				}

				$flag = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($key, $updateData);
				if($updateData) {
					$i ++;
				}
				if($_GET['displayorder']) {
					$status = 'auto-1';
				}
			} else {
				$k ++;
			}
		}
	}

	$url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&status=' . $status . '&meun=' . $_GET['meun'];
	showmessage(sprintf($Plang['3fbaf959084df881'], $i, $j, $k), $url);
} elseif($op == 'add') {
	$navtitle = $Plang['ab6b2e0930f61299'];
	if(!in_array($_G['groupid'], $setting['allow_groups']) && !in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
		showmessage($Plang['f094c962e0ff46ba'], 'plugin.php?id=wq_wechatcollecting');
	}

	$navname = $Plang['de712b148b45a704'];
	$step = 1;
	$plugin = $_G['cache']['plugin']['wq_wechatshow'];
	if($_GET['wechat'] == 'serve' && !empty($plugin)) {
		if(submitcheck('servesubmit')) {
			require DISCUZ_ROOT . './source/plugin/wq_wechatshow/module/wechatshow_serve.php';
		}
	} else {
		wq_wechatcollecting_check_isset_default_fid($setting, $Plang);
		if(submitcheck('searchsubmit')) {

			$step = 2;
			$pages = $_GET['totalPages'];
			$next_page = $pages + 1;
			if($_GET['inajax'] == "1") {
				$_GET['keyword'] = urldecode($_GET['keyword']);
			}
			$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
			$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
			if(!$keyword) {
				showmessage($Plang['20887174bd9497ad']);
			}
			$list = wqWechatApigetListByKeywordType($keyword, '1', $pages);
			$postlist = array();
			if($_GET['inajax'] == "1") {
				$postlist = unserialize(base64_decode($_GET['listcode']));
				foreach($list as $key => $value) {
					foreach($postlist as $k => $v) {
						if($v['name'] == $value['name'] && $v['username'] == $value['username']) {
							unset($list[$key]);
						}
					}
				}
				$temarr = array_merge($postlist, $list);
				$listcode = base64_encode(serialize($temarr));
			} else {
				$listcode = base64_encode(serialize($list));
			}

			$preg = '/' . $keyword . '/i';
			foreach($list as $key => $value) {
				preg_match_all($preg, $value['name'], $title_result);
				foreach(array_unique($title_result[0]) as $val) {
					$list[$key]['name'] = str_replace($val, '<span style="color:#F00;">' . $val . '</span>', $value['name']);
				}
			}
		}

		if(submitcheck('addsubmit')) {
			$step = 3;
			$usernames = $_GET['usernames'];


			$keyword = trim($_GET['keyword']);
			$list = unserialize(base64_decode($_GET['listcode']));

			$_GET['article_classid'] = !empty($_GET['article_classid']) ? $_GET['article_classid'] : $_GET['classid'];
			$b = $i = $j = 0;

			foreach($list as $value) {
				if(in_array($value['username'], $usernames)) {
					$maxrestrict = intval($setting['maxrestrict']);
					if(in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])) {
						$maxrestrict = 0;
					}
					if($maxrestrict > 0) {
						$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->count_by_uid($_G['uid']);
						if($maxrestrict <= intval($count)) {
							$b ++;
							break;
						}
					}

					$urlinfo = parse_url($value['logo']);
					$value['logo'] = isset($urlinfo['scheme']) ? $value['logo'] : 'https:' . $value['logo'];
					$value['logo'] = save_images($value['logo'], $value['username']);
					$value['qrcode'] = save_images($value['qrcode'], $value['username'], 'qrcode');
					if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
						$status = $setting ['wechat_status'] == '1' ? 0 : 1;
					} else {
						$status = 1;
					}

					$data = array(
						'collecttime' => TIMESTAMP,
						'uid' => intval($_G['uid']),
						'username' => $_G['username'],
						'status' => $status,
						'classid' => $_GET['classid'],
						'article_classid' => $_GET['article_classid'],
						'name' => dhtmlspecialchars($value['name']),
						'wechatid' => $value['username'],
						'intro' => dhtmlspecialchars($value['intro']),
						'verify' => dhtmlspecialchars($value['verify']),
						'openid' => $value['openid'],
						'tmpurl' => $value['tmpurl'],
						'qrcode' => $value['qrcode'],
						'headimage' => $value['logo'],
						'view_mode' => intval($_GET['view_mode']),
						'newqrcode' => 1,
					);

					$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($value['username']);
					if(empty($wechat)) {
						$data = wq_wechatcollecting_register_newuser($data, $setting);
						$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->insert($data, true);

						$i ++;
					} else {
						$j ++;
					}
				}
			}
			$url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add';
			if($b != 0) {
				if($_G['mobile']) {
					showmessage(sprintf($Plang['532c70e40b71c199'], $i, $maxrestrict), $url);
				}
				showmessage(sprintf($Plang['bc1ce3ae31c8694e'], $i, $maxrestrict));
			}
			if($_G['mobile']) {
				showmessage(sprintf($Plang['47e36fa591ea2c58'], $i, $j), $url);
			}
			showmessage(sprintf($Plang['710e9c909776dd5c'], $i, $j), $url);
		}
	}
} elseif($op == 'collect') {
	set_time_limit(1800);
	wq_wechatcollecting_check_isset_default_fid($setting, $Plang);
	if(submitcheck('searchsubmit') && !empty($_GET['collectpage'])) {


		$release_type = $_POST['release_type'];
		$status = wq_parse_params('status');
		$wechatid = wq_parse_params('wechatid');

		$collectpage = wq_parse_params('collectpage');

		$collect = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);

		if(!$collect) {
			showmessage($Plang['af00610f043790a1']);
		}
		$tem_date = strtotime(date('Y-m-d') . ' 00:00:00');
		if($_GET['inajax'] && ((TIMESTAMP - $collect['viewendcollectdate']) <= $setting['collect_interval_date'] || $collect['collectnewdate'] > $tem_date)) {
			echo '|0|';
			exit;
		}
		if($collect['status'] != '1') {
			showmessage($Plang['08ee8a6ed5c33746']);
		}
		if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $collect['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups']) && !in_array($_G['groupid'], $setting['allow_groups'])) {
			showmessage($Plang['66ef666b87236e94']);
		}


		$article = wqWechatApiGetArticleListByTmpUrl($collect, false, true, $collectpage);

		$max_date = max($article['masstime']);

		$sum = max(0, $_GET['sum']);
		if(intval($_GET['classid']) > 0) {
			$classid = intval($_GET['classid']);


			$_GET['article_classid'] = !empty($_GET['article_classid']) ? $_GET['article_classid'] : $classid;

			$data = array('classid' => $classid, 'article_classid' => $_GET['article_classid']);

			C::t("#wq_wechatcollecting#wq_wechatcollecting_wechat")->update($collect['id'], $data);
			$collect = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
		}

		if(!empty($_GET['article_classid_thistime'])) {
			$classid = intval($_GET['article_classid_thistime']);
		} else {
			$classid = intval($collect['article_classid']);
		}

		$inajaxhtml = $wechatbiz = '';
		$inajaxnum = $inajaxfirst = $cot = $sum = $kf = $firstnum = $need_check = 0;
        $passnum = 0;
		foreach($article['articlelist'] as $key => $val) {
			if(!$val['title']) {
				continue;
			}
            if(!check_is_get_article($val['dateline'],$setting['aiticle_pubishdate'])){
                $passnum++;
                continue;
            }

			$articleid = null;
			if($release_type == 2) {
				$wechatarticle = wq_wechatcollecting_wechatarticle_exists($wechatid, $val['title'], $release_type, $setting['only_title_judge']);
				if(!$wechatarticle && in_array($val['datetime'], $article['masstime'])) {
					$data = array(
						'title' => $val['title'],
						'wechatid' => $collect['wechatid']
					);
					$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->insert($data, true);
					if(CHARSET == 'gkb') {
						$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->fetch_first_by_id($articleid);
						if(!$data['title']) {
							C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->delete($articleid);
							continue;
						}
					}
				}
			} else {
				$wechatarticle = wq_wechatcollecting_wechatarticle_exists($wechatid, $val['title'], 0, $setting['only_title_judge']);
				if(!$wechatarticle && in_array($val['datetime'], $article['masstime'])) {

					$data = array(
						'title' => $val['title'],
						'wechatid' => $collect['wechatid'],
					);
					$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->insert($data, true);
					if(CHARSET == 'gkb') {
						$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($articleid);
						if(!$data['title']) {
							C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
							continue;
						}
					}
				}
			}

			if($articleid) {
				if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
					$status = $setting['article_status'] == '1' ? 0 : 1;
				} else {
					$status = 1;
				}
				if($release_type == 2) {
					$data = array(
						'url' => $val['content_url'],
						'classid' => $classid,
						'name' => $collect['name'],
						'status' => $status,
						'summary' => $val['digest'],
						'imglink' => $val['cover'],
						'date' => $val['datetime'],
						'uid' => intval($collect['uid']),
						'username' => $collect['username'],
						'wid' => $collect['id'],
						'collecttime' => TIMESTAMP
					);

					C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->update($articleid, $data);
					$imglink = save_images($val['cover'], $articleid, 'temparticle');
					$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->update($articleid, array('imglink' => $imglink));
				} else {
					$article_content = wqWechatApigetArticleContentByUrl($val['content_url'], false, false, true, $collect['wechatid']);

					if(!$article_content['content'] || $article_content == '-1') {
						C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
						$article_content == '-1' ? $kf++ : '';
						continue;
					}

					$content = $article_content['content'];

					$wechatbiz = $wechatbiz ? $wechatbiz : $article_content['wechatbiz'];
					$data = array(
						'url' => $val['content_url'],
						'classid' => $classid,
						'collecttime' => TIMESTAMP,
						'name' => $collect['name'],
						'status' => $status,
						'isfirst' => intval($article_content['isfirst']),
						'summary' => $val['digest'],
						'imglink' => $val['cover'],
						'date' => $val['datetime'],
						'uid' => intval($collect['uid']),
						'username' => $collect['username'],
						'wid' => $collect['id'],
						'isoriginal' => $article_content['isoriginal']
					);

					C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, $data);
					$firstnum = $data['status'] && $data['isfirst'] ? $firstnum + 1 : $firstnum;
					$contentdata = array(
						'articleid' => $articleid,
						'content' => base64_encode($content),
						'collecttime' => TIMESTAMP,
						'wid' => $collect['id'],
						'fileterheader' => 1
					);
					$addcontent = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->insert($contentdata);
					$val['imglink'] = save_images($val['cover'], $articleid, 'article');
					$summary = $val['digest'];

					$postresult = wq_common_post_forum_or_portal($setting, $classid, $summary, $collect, $val, $wechatclass_article, $status);
					$tid = $postresult['tid'];
					$aid = $postresult['aid'];

					$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, array('imglink' => $val['imglink'], 'tid' => $tid, 'aid' => $aid));
					if($_GET['inajax'] && $articleid && $data) {
						$data['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
						$inajaxnum ++;
						if(!$status) {
							$need_check ++;
							continue;
						}
						$temlist = $data;
						$temlist['articleid'] = $articleid;
						$temlist['aid'] = $aid;
						$temlist['tid'] = $tid;
						$temlist['title'] = $val['title'];
						$temlist['wechatid'] = $collect['wechatid'];
						include_once template('wq_wechatcollecting:common/common_module');
						if($_GET['first']) {
							if($data['isfirst']) {
								$inajaxfirst ++;
								$inajaxhtml .= $_G['mobile'] ? mobile_wechat_view_ajax_collect_returnhtml($temlist) : wechat_view_ajax_collect_returnhtml($temlist);
							}
						} else {
							$inajaxhtml .= $_G['mobile'] ? mobile_wechat_view_ajax_collect_returnhtml($temlist) : wechat_view_ajax_collect_returnhtml($temlist);
						}
					}
				}
				$sum ++;
			} else {
				if(in_array($val['datetime'], $article['masstime'])) {
					$cot ++;
				}
				continue;
			}
		}
		if($release_type != 2) {
			$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wid($collect['id'], array(1));
			$addrecord = array(
				'articlenum' => $count,
				'endcollectdate' => TIMESTAMP
			);
			if($_GET['inajax']) {
				$addrecord['viewendcollectdate'] = TIMESTAMP;
			}
			if(!$collect['wechatbiz']) {
				$addrecord['wechatbiz'] = $wechatbiz;
			}
			if($collect['collectnewdate'] < $max_date) {
				$addrecord['collectnewdate'] = $max_date;
			}
			if($max_date >= $tem_date) {
				$addrecord['collectfinish'] = 1;
			}
			$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($collect['id'], $addrecord);
			if($firstnum > 0) {
				update_wechat_field_by_wechatid($collect['id'], array('first_num'));
			}
		}

		if($_GET['inajax']) {
			if($need_check) {
				showmessage(sprintf($Plang['28f877eef9737cc6'], $inajaxnum, $need_check));
			}
			echo $inajaxhtml . '|' . $inajaxnum . '|' . $inajaxfirst;
			exit;
		} else {
			showmessage(sprintf($Plang['803a34aff5cfb2b3'], $sum, $cot, $passnum, $kf), $_G['cookie']['collect_referer']);
		}
	} else {

		$wechatid = $_GET['wechatid'];
		$collect = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($wechatid);
		if(!$collect) {
			showmessage($Plang['af00610f043790a1']);
		}
		if($collect['status'] != '1') {
			showmessage($Plang['08ee8a6ed5c33746']);
		}
		if(!in_array($_G['uid'], $setting['adminuids']) && $_G['uid'] != $collect['maintain_uid'] && !in_array($_G['groupid'], $setting['admingroups']) && !in_array($_G['groupid'], $setting['allow_groups'])) {
			showmessage($Plang['66ef666b87236e94']);
		}

		$option = get_page_arr($Plang);

		$referer = dreferer();
		dsetcookie("collect_referer", $referer);
	}
}

include template('wq_wechatcollecting:cp_wechatmanage');

?>