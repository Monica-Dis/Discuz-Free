<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
set_time_limit(1800);
if(!in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])) {
	showmessage($Plang['66ef666b87236e94']);
}
wq_wechatcollecting_check_isset_default_fid($setting, $Plang);
$navtitle = $navname = $Plang['710a638fcce90598'];
if(submitcheck('keywordcollect')) {
	$step = 2;
	$release_type = $_POST['release_type'];
	$collect_all = $_POST['collect_all'];

	$keyword = $_POST['search_keyword'] ? dhtmlspecialchars(trim($_POST['search_keyword'])) : null;
	if(!$keyword) {
		showmessage($Plang['20887174bd9497ad']);
	}

	$classid = intval($_POST['classid']);
	$article_classid = $_POST['article_classid'] ? intval($_POST['article_classid']) : $classid;
	$article_classid_thistime = $_POST['article_classid_thistime'] ? intval($_POST['article_classid_thistime']) : $article_classid;

	$pages = max(1, intval($_POST['collectpage']));
	$list = wqWechatApigetListByKeywordType($keyword, 2, $pages);

	$preg = '/' . $keyword . '/i';

	foreach($list as $key => $val) {
		preg_match_all($preg, $val['title'], $title_result);
		foreach(array_unique($title_result[0]) as $value) {
			$list[$key]['title'] = str_replace($value, '<span style="color:#f60">' . $value . '</span>', $val['title']);
		}
		preg_match_all($preg, $val['summary'], $summary_result);
		foreach(array_unique($summary_result[0]) as $value) {
			$list[$key]['summary'] = str_replace($value, '<span style="color:#f60">' . $value . '</span>', $val['summary']);
		}
	}

	$listcode = base64_encode(serialize($list));
} elseif(submitcheck('selectarticle')) {
	$release_type = $_POST['release_type'];
	$collect_all = $_POST['collect_all'];

	$list = unserialize(base64_decode($_POST['listcode']));
	$keyword = wq_parse_params('keyword');

	$select_arr = array();
	$all_article = array();
	foreach($list as $key => $val) {
		if(in_array($key, $_POST['usernames'])) {
			$list[$key]['verify'] = '';
			if($collect_all) {
				$wechatlist = wqWechatApiGetArticleListByTmpUrl($val['wechatinfo'], false, true);
				$list[$key]['verify'] = $wechatlist['keyword_verify'];
				foreach($wechatlist['articlelist'] as $k => $v) {
					if($val['title'] != $v['title']) {
						$all_article[$k]['url'] = $v['content_url'];
						$all_article[$k]['title'] = $v['title'];
						$all_article[$k]['summary'] = $v['digest'];
						$all_article[$k]['openid'] = '';
						$all_article[$k]['sourcename'] = $val['sourcename'];
						$all_article[$k]['images'] = $v['cover'];
						$all_article[$k]['dateline'] = $v['datetime'];
						$all_article[$k]['wechatinfo'] = $val['wechatinfo'];
						$all_article[$k]['verify'] = $wechatlist['keyword_verify'];
					}
				}
			}
			$select_arr[] = $list[$key];
		}
	}
	$newlist = array_merge($select_arr, $all_article);
	$classid = intval($_POST['classid']);
	$article_classid = $_POST['article_classid'] ? intval($_POST['article_classid']) : $classid;
	$article_classid_thistime = $_POST['article_classid_thistime'] ? intval($_POST['article_classid_thistime']) : $article_classid;

	$wechat_status = $setting['keyword_wechat_status'] == '1' ? 0 : 1;
	$article_status = $setting['keyword_article_status'] == '1' ? 0 : 1;

    $w = $i = $j = $k = $kf = $passnum = 0;

	foreach($newlist as $key => $val) {
		$masstime[$key] = $val['dateline'];
		$info = wqWechatApigetArticleContentByUrl($val['url'], true, false, true, $keyword);
		$val['title'] = preg_replace("/<span[^>]*>/", "", $val['title']);
		$val['title'] = preg_replace("/<\/span>/", "", $val['title']);
		$val['title'] = $info['title'] ? $info['title'] : $val['title'];
		$val['summary'] = preg_replace("/<span[^>]*>/", "", $val['summary']);
		$val['summary'] = preg_replace("/<\/span>/", "", $val['summary']);
		if(!$info['content'] || $info == '-1') {
			$info == '-1' ? $kf++ : $k ++;
			continue;
		}

        if(!check_is_get_article($val['dateline'],$setting['aiticle_pubishdate'])){
            $passnum++;
            continue;
        }

		$yurl = $info['url'];
		if($release_type == 2) {
			$wechatarticle = wq_wechatcollecting_wechatarticle_exists($info['wechatid'], $val['title'], $release_type, $setting['only_title_judge']);
			if(!$wechatarticle) {
				$data = array(
					'title' => $val['title'],
					'wechatid' => $info['wechatid']
				);
				$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->insert($data, true);
				if(CHARSET == 'gbk') {
					$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->fetch_first_by_id($articleid);
					if(!$data['title']) {
						C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->delete($articleid);
						continue;
					}
				}
			}
		} else {
			$wechatarticle = wq_wechatcollecting_wechatarticle_exists($info['wechatid'], $val['title'], 0, $setting['only_title_judge']);
			if(!$wechatarticle) {
				$data = array(
					'title' => $val['title'],
					'wechatid' => $info['wechatid']
				);
				$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->insert($data, true);
				if(CHARSET == 'gkb') {
					$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($articleid);
					if(!$data['title']) {
						C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
						continue;
					}
				}
			}
		}

		$wid = 0;
		$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($info['wechatid']);
		if(!$wechat) {
			$qrcode = save_images(wq_get_qrcode_by_wechatid($info['wechatid']), $info['wechatid'], 'qrcode');
			$headimage = save_images($val['logo'], $info['wechatid']);
			$wechatData = array(
				'collecttime' => TIMESTAMP,
				'uid' => intval($_G['uid']),
				'username' => $_G['username'],
				'status' => $wechat_status,
				'classid' => $classid,
				'article_classid' => $article_classid,
				'name' => dhtmlspecialchars($val['sourcename']),
				'wechatid' => $info['wechatid'],
				'intro' => dhtmlspecialchars($info['intro']),
				'verify' => $val['verify'],
				'openid' => $val['openid'],
				'qrcode' => $qrcode,
				'headimage' => $headimage,
				'wechatbiz' => $info['wechatbiz']
			);
			$wechatData = wq_wechatcollecting_register_newuser($wechatData, $setting);
			$wid = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->insert($wechatData, true);
			$wechat = $wechatData;
			$w ++;
		} else {
			$wid = $wechat['id'];
		}
		if($articleid) {
			$data = array(
				'url' => $yurl,
				'classid' => $article_classid_thistime,
				'name' => $val['sourcename'],
				'status' => $article_status,
				'summary' => $val['summary'],
				'imglink' => $val['images'],
				'date' => $val['dateline'],
				'uid' => intval($wechat['uid']),
				'username' => $wechat['username'],
				'wid' => $wid,
				'collecttime' => TIMESTAMP
			);
			if($release_type == 2) {
				$data['imglink'] = save_images($val['images'], $articleid, 'temparticle');
				C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->update($articleid, $data);
			} else {
				$data['isoriginal'] = $info['isoriginal'];
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, $data);
				$contentdata = array(
					'articleid' => $articleid,
					'content' => base64_encode($info['content']),
					'collecttime' => TIMESTAMP,
					'wid' => $wid,
				);

				$addcontent = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->insert($contentdata);
				$val['images'] = save_images($val['images'], $articleid, 'article');
				$val['imglink'] = $val['images'];
				$summary = $val['summary'];

				$postresult = wq_common_post_forum_or_portal($setting, $classid, $summary, $wechat, $val, $wechatclass_article, $article_status);
				$tid = $postresult['tid'];
				$aid = $postresult['aid'];

				$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, array('imglink' => $val['images'], 'tid' => $tid, 'aid' => $aid));
			}
			$i ++;
		} else {
			$j ++;
		}
		if($wid && $release_type != 2) {
			$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wid($wid);
			$addrecord = array(
				'articlenum' => $count,
			);
			if($wechat && !$wechat['wechatbiz']) {
				$addrecord['wechatbiz'] = $info['wechatbiz'];
			}
			if($collect_all) {
				$addrecord['collectnewdate'] = max($masstime);
				$tem_date = strtotime(date('Y-m-d') . ' 00:00:00');
				if($addrecord['collectnewdate'] >= $tem_date) {
					$addrecord['collectfinish'] = 1;
				}
			} elseif(empty($wechat['collectnewdate']) || $wechat['collectnewdate'] < $val['dateline']) {
				$addrecord['collectnewdate'] = $val['dateline'];
			}
			update_wechat_field_by_wechatid($wid, array('first_num'));
			$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, $addrecord);
		}
	}
	$locaturl = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=keywordcollect&';
	showmessage(sprintf($Plang['97b81554a99f5a5c'], $i, $j, $passnum, $k, $kf, $w), $locaturl);
} else {
	$step = 1;

    $option = get_page_arr($Plang);
}
include template('wq_wechatcollecting:cp_keywordcollect');

?>