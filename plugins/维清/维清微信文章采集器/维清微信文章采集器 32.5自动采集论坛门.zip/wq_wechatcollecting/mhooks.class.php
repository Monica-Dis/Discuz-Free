<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: mhooks.class.php 2015-7-7 08:28:20Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/class/base.class.php';

class mobileplugin_wq_wechatcollecting extends plugin_wq_wechatcollecting_base {

	function mobileplugin_wq_wechatcollecting() {
		$this->init();
		$this->common_base();
	}

}

class mobileplugin_wq_wechatcollecting_forum extends mobileplugin_wq_wechatcollecting {

	function viewthread_posttop_output() {
		global $postlist;
		$content = $this->_article_content();
		if($content != '1') {
			foreach($postlist as $post) {
				if($post['first'] == '1') {
					$post['message'] = $content[0];
                    $post['message'] = wq_parse_video($post['message']);
					$postlist[$post['pid']]['message'] = $post['message'];
				} else {
					continue;
				}
			}
		}
	}

	function post_wq_wechatcollecting() {
		$article = $this->fetch_article_by_tid($_GET['tid']);
		$threadinfo = C::t('forum_thread')->fetch($_GET['tid']);
		$postinfo = C::t('forum_post')->fetch($threadinfo['posttableid'], $_GET['pid'], false);
		if($_GET['action'] != 'edit' || empty($article) || empty($postinfo['first'])) {
			return '';
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=edit&articleid=" . $article['articleid']);
	}

	function topicadmin_wq_wechatcollecting_message($params) {
		$this->wq_wechatcollecting_move_topic($params);
	}

}

class mobileplugin_wq_wechatcollecting_group extends mobileplugin_wq_wechatcollecting {

	function viewthread_posttop_output() {
		global $postlist;
		$content = $this->_article_content();
		if($content != '1') {
			foreach($postlist as $post) {
				if($post['first'] == '1') {
					$post['message'] = $content[0];
					$postlist[$post['pid']]['message'] = $post['message'];
				} else {
					continue;
				}
			}
		}
	}

	function post_wq_wechatcollecting() {
		$article = $this->fetch_article_by_tid($_GET['tid']);
		$threadinfo = C::t('forum_thread')->fetch($_GET['tid']);
		$postinfo = C::t('forum_post')->fetch($threadinfo['posttableid'], $_GET['pid'], false);
		if($_GET['action'] != 'edit' || empty($article) || empty($postinfo['first'])) {
			return '';
		}
		dheader("location: plugin.php?id=wq_wechatcollecting&mod=edit&articleid=" . $article['articleid']);
	}

	function topicadmin_wq_wechatcollecting_message($params) {
		$this->wq_wechatcollecting_move_topic($params);
	}

}

class mobileplugin_wq_wechatcollecting_portal extends mobileplugin_wq_wechatcollecting {

	function view_portal_output() {
		global $_G, $content, $article;

		$article_content = $this->_article_content();

		if($article_content != '1') {
			$content['content'] = $article_content[0];
			if(empty($article['summary'])) {
				$article['summary'] = $this->_get_portal_summary($article_content[2]);
			}
		}
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>