<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

$classselect = get_class_select_article('classid', $wechatclass_article, $_GET['classid'], $Plang['1a757dd19f8883e6']);
$classselect .= '<span id=\'movearticle\' style=\'display:none\'><input class=\'fs\' id=\'movearticle_input\' type=\'checkbox\' name=\'movearticle\' value=\'1\' /><label for="movearticle_input">' . $Plang['375e4fb15a16c045'] . '</label></span>';
$classname[0] = $Plang['a1e5d76323a1fd8d'];
$classname[-1] = $Plang['e5dd6c90447db4c8'];

$recommend_arr = array('list_recommend' => $Plang['e9c4785300ab2b93'], 'view_recommend' => $Plang['dc15f4249b92e57a']);
$recommend = "<select id='recommend' name='recommend[]' multiple='multiple' size='2' style='width: 220px;display:none;margin-left:5px;'>";
$cancel = "<select id='cancel_recommend' name='cancel_recommend[]' multiple='multiple' size='2' style='width: 220px;display:none;margin-left:5px;'>";
foreach($recommend_arr as $key => $value) {
	$recommend .= "<option style='width: 220px;' value='" . $key . "'>" . $value . "</option>";
	$cancel .= "<option style='width: 220px;' value='" . $key . "'>" . $value . "</option>";
}
$siteselect .= "</select>";
$cancel .= "</select>";

foreach($nav_classlist as $nvakey => $navval) {
	$classname[$navval['cid']] = $navval['classname'];
	$cids[] = intval($navval['cid']);
}
array_unshift($cids, '-1');

$cid = in_array($_GET['cid'], $cids) ? trim($_GET['cid']) : '';
$status = in_array($_GET['status'], array('0', '1', '-1')) ? array(intval($_GET['status'])) : array(0, 1, -1);
$list_recommend = $_GET['status'] == '6' ? 1 : '';
$view_recommend = $_GET['status'] == '7' ? 1 : '';
$title = trim($_GET['title']);
$name = trim($_GET['name']);
$perpage = intval($setting['admincp_perpage']) < 1 ? 1 : intval($setting['admincp_perpage']);
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;

$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_article';
$mpurl = !empty($title) ? $mpurl . '&title=' . $title : $mpurl;
$mpurl = !empty($name) ? $mpurl . '&name=' . $name : $mpurl;
$mpurl = $_GET['status'] !== null ? $mpurl . '&status=' . $_GET['status'] : $mpurl;
$mpurl = $cid ? $mpurl . '&cid=' . $cid : $mpurl;
$url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_article';
$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_article';
$editstatus = array('0' => $Plang['05df925dd69b4333'], '1' => $Plang['d4cd6471a700d52c'], '-1' => $Plang['b5d0d1b6c49b2665'], '-2' => $Plang['4930bcc2615700e9']);
$admrecommendstatus = array('0' => $Plang['77b41af77fe3ce13'], '1' => $Plang['b4b0d4ba96890702']);

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

if(!submitcheck('form')) {
	echo
	"<style tpye='text/css'>
    .status{background-color: #666666;height:20px;text-align:center;line-height:18px;border-radius:4px;}
    .status a{color:#FFF;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    </style>";
	$classcid = select_html($classname, 'cid', $cid, false);

	showformheader($fromurl, '', 'forms');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablerow('', array('width="200"', 'width="210"', 'width="230"', 'width="50"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="140"', 'width="140"'), array(
		$Plang['4e8be287d687966d'] . ':&nbsp;&nbsp;' . $classcid,
		$Plang['77346c32a4a5ad66'] . ": <input size = \"25\" style='width:140px;' name=\"title\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['title']) . "\" />",
		$Plang['d14e8a191586055a'] . ": <input size = \"25\" style='width:140px;' name=\"name\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['name']) . "\" />",
		"<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />",
		"<div " . ($_GET['status'] == '' ? 'class="status"><a' : "><a style='color:#000;'") . " href=\"" . $url . "\">" . $Plang['660396e5d283970b'] . "</a></div>",
		"<div " . ($_GET['status'] == '0' ? 'class="status"><a' : "><a style='color:#FF9300;'") . " href=\"" . $url . "&status=0\">" . $Plang['05df925dd69b4333'] . "</a></div>",
		"<div " . ($_GET['status'] == '1' ? 'class="status"><a' : "><a style='color:green;'") . " href=\"" . $url . "&status=1\">" . $Plang['be26c1af13da3cf9'] . "</a></div>",
		"<div " . ($_GET['status'] == '-1' ? 'class="status"><a' : "><a style='color:red;'") . " href=\"" . $url . "&status=-1\">" . $Plang['b5d0d1b6c49b2665'] . "</a></div>",
		"<div " . ($_GET['status'] == '6' ? 'class="status"><a' : "><a style='color:blue;'") . " href=\"" . $url . "&status=6\">" . $Plang['e9c4785300ab2b93'] . "</a></div>",
		"<div " . ($_GET['status'] == '7' ? 'class="status"><a' : "><a style='color:blue;'") . " href=\"" . $url . "&status=7\">" . $Plang['dc15f4249b92e57a'] . "</a></div>",
		"<div></div>",
	));
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/

	showformheader($fromurl, '', 'form');
	showtableheader($Plang['70a45e7a6f4a9f3a'], 'nobottom');
	for($i = 0; $i < 11; $i ++) {
		$style[$i] = 'nowrap="nowrap"';
	}
	showsubtitle(array('', $Plang['d14e8a191586055a'], $Plang['279448f0857a2b24'], $Plang['0b3d6ba0ad26e11e'], $Plang['18ad271b7e118fe7'], $Plang['e9c4785300ab2b93'], $Plang['dc15f4249b92e57a'], $Plang['968265252bbb1364'], $Plang['34e4ed991f716a4e'], $Plang['7de4775a64db4b43'], $Plang['e5d945ff5448fd01'], $Plang['a030bd174e9753e7'], $Plang['5285f748adb71fb2'], $Plang['ca5a0d75b677d381']), 'header', $style);
	$cid = $cid == -1 ? 0 : $cid;
	$mainclass = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search($status, $start, $perpage, $title, 'collecttime', $cid, $list_recommend, $name, false, 0, false, false, $view_recommend);
	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search($status, $title, $cid, $list_recommend, $name, 0, $view_recommend);

	include_once libfile('function/home');
	foreach($mainclass as $val) {
		$val['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
		$url = wq_common_article_view_url($setting, $val['articleid'], $val['tid'], $val['aid']);
		showtablerow('class="tr"' . $val['id'] . '"', array('width="10"', 'width="100"', 'width="100"', 'width="200"', '', 'width="100"', 'width="100"', 'width="80"', 'width="80"', 'width="90"', 'width="50"', 'width="60"', 'width="50"', 'width="50"'), array(
			'<input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['articleid'] . '\' /> ',
			'<a target="_blank" href="plugin.php?id=wq_wechatshow&mod=view&wid=' . $val['wechatid'] . '&displayorder=index">' . $val['name'] . '<br/>(' . $val['wechatid'] . ')</a> ',
			'<a target="_blank" href="' . $url . '"><img style="width:100px; height:100px;" src ="' . $val['imglink'] . '" /></a> ',
			'<a target="_blank" href="' . $url . '">' . $val['title'] . '</a> ',
			$val['summary'],
			$admrecommendstatus[$val['admrecommend']],
			$admrecommendstatus[$val['recommend']],
			$wechatclass_article[$val['classid']]['status'] == 1 ? $wechatclass_article[$val['classid']]['classname'] : $Plang['e5dd6c90447db4c8'],
			"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
			date("Y-m-d H:i:s", $val['collecttime']),
			date("Y-m-d H:i:s", $val['date']),
			$val['views'],
			$val['favorites'],
			'<a target="_blank" href="plugin.php?id=wq_wechatcollecting&mod=edit&articleid=' . $val['articleid'] . '" >' . $Plang['9a150d4af72d7358'] . '</a> <br>' .
			$editstatus[$val['status']] . '<input class=\'fs\' type=\'hidden\' name=\'hiddenstatus\' value=\'' . $_GET['status'] . '\' /> ',
			)
		);
	}
	$multi = multi($count, $perpage, $page, $mpurl);
	$operation = '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkall">' . cplang('select_all') . '</label>'
		. '<input type="radio" name="editstatus"  value="3" class="radio" id="del"  /><label for="del" class="vmiddle">' . $Plang['0d9efacf5089d88c'] . '</label>'
		. '<input type="radio" name="editstatus" checked id="edit" value="1" class="radio" /><label for="edit" class="vmiddle">' . $Plang['d4cd6471a700d52c'] . '</label>'
		. '<input type="radio" name="editstatus" id="moderate" value="-1" class="radio" /><label for="moderate" class="vmiddle">' . $Plang['b5d0d1b6c49b2665'] . '</label>'
		. '<input type="radio" name="editstatus" id="admrecommend" value="6" class="radio" /><label for="admrecommend" class="vmiddle">' . $Plang['95b79c57699744a7'] . '</label>'
		. $recommend
		. '<input type="radio" name="editstatus" id="unadmrecommend" value="-6" class="radio" /><label for="unadmrecommend" class="vmiddle">' . $Plang['dd21ec1b2d3f0949'] . '</label>'
		. $cancel
		. '<input type="radio" name="editstatus" id="put_in_class" value="4" class="radio" /><label for="put_in_class" class="vmiddle">' . $Plang['c3b3ed10c6a602f6'] . '</label>'
		. $classselect;
	showsubmit('form', 'submit', $operation, '', $multi);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	$recommend_select = select_html($recommend_arr, 'ecommend', '', false);
	$recommend = '<span id=\'recommend\' style=\'display:none\'>' . $recommend . '</span>';
	$cancel_recommend = select_html($recommend_arr, 'cancel_recommend', '', false);
	$cancel = '<span id=\'cancel_recommend\' style=\'display:none\'>' . $cancel_recommend . '</span>';
	echo <<<EOF
    <script>
        window.onload =function () {
            var checkbox = document.getElementsByName('editstatus');
            for (var i = 0; i < checkbox.length; i++) {
                checkbox[i].onclick = function (e) {
                    if (e.target.id == 'put_in_class') {
                        document.getElementById('movearticle').style.display = 'inline';
                        document.getElementById('recommend').style.display = 'none';
                        document.getElementById('cancel_recommend').style.display = 'none';
                    } else if(e.target.id == 'admrecommend') {
                        document.getElementById('movearticle').style.display = 'none';
                        document.getElementById('recommend').style.display = 'inline';
                        document.getElementById('cancel_recommend').style.display = 'none';
                    }else if(e.target.id == 'unadmrecommend') {
                        document.getElementById('movearticle').style.display = 'none';
                        document.getElementById('recommend').style.display = 'none';
                        document.getElementById('cancel_recommend').style.display = 'inline';
                    }else{
                        document.getElementById('movearticle').style.display = 'none';
                        document.getElementById('recommend').style.display = 'none';
                        document.getElementById('cancel_recommend').style.display = 'none';
                    }
                }
            }
        }
    </script>
EOF;
} else {

	include_once libfile('function/delete');
	if($_GET['delete'] && $_GET['editstatus']) {
		$articles = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_articleid($_GET['delete']);

		foreach($articles as $value) {
			if($_GET['editstatus'] == '3') {
				del_article($value, true, $setting);
				$value['tid'] ? $tid[] = $value['tid'] : '';
				$value['aid'] ? $aid[] = $value['aid'] : '';
			} elseif($_GET['editstatus'] == '4' && $wechatclass_article[$_GET['classid']]['status'] == 1) {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($value['articleid'], array('classid' => $_GET['classid']));
				if($_GET['movearticle'] == '1') {
					wq_update_fid_or_aid_by_wid_articleid(null, intval($value['articleid']));
				}
			} elseif(in_array($_GET['editstatus'], array('6', '-6'))) {
				$data = array();
				if($_GET['editstatus'] == '6') {
					if(in_array('list_recommend', $_GET['recommend'])) {
						$data['admrecommend'] = 1;
						$data['adminrectime'] = TIMESTAMP;
					}
					if(in_array('view_recommend', $_GET['recommend'])) {
						$data['recommend'] = 1;
						$data['rectime'] = TIMESTAMP;
					}
				}
				if($_GET['editstatus'] == '-6') {
					if(in_array('list_recommend', $_GET['cancel_recommend'])) {
						$data['admrecommend'] = 0;
						$data['adminrectime'] = 0;
					}
					if(in_array('view_recommend', $_GET['cancel_recommend'])) {
						$data['recommend'] = 0;
						$data['rectime'] = 0;
					}
				}
				if($data) {
					C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($value['articleid'], $data);
					if(in_array('view_recommend', $_GET['recommend']) || in_array('view_recommend', $_GET['cancel_recommend'])) {
						update_wechat_field_by_wechatid($value['wid'], array('recommend_num'));
					}
				}
			} else {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($value['articleid'], array('status' => $_GET['editstatus']));

				update_wechat_field_by_wechatid($value['wid'], array('articlenum', 'recommend_num', 'first_num'));

				if($_GET['editstatus'] == 1) {
					if($setting['view_mode'] == '2') {
						C::t('forum_thread')->update($value['tid'], array('displayorder' => 0));
					} elseif($setting['view_mode'] == '3') {
						C::t('portal_article_title')->update($value['aid'], array('status' => 0));
					}
				}
			}
		}
		$tid ? deletethread($tid) : '';
		$aid ? deletearticle($aid) : '';
	}

	cpmsg($Plang['9a52f4d6ef956904'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_article&status=' . $_GET['hiddenstatus'], 'succeed');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>