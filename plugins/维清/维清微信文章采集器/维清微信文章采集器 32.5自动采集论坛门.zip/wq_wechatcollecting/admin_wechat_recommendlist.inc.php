<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

$sitearr = array(
	1 => $Plang['18279e4e36db62a0'],
	2 => $Plang['2fadb15b8c0770ef'],
	3 => $Plang['4ef01a4662b08f70'],
	4 => $Plang['d6f3e2af5b8dd92f'],
	10 => $Plang['ad0cdf3197d6077d'],
	5 => $Plang['20a8dcddb53500c7'],
	11 => $Plang['a3d338b462605ddb'],
	6 => $Plang['65d8232ec37a7643'],
	8 => $Plang['a90a8e99b52d21c7'],
	7 => $Plang['a3d338b462605dda'],
	9 => $Plang['39c570266a0a1dd4'],
);

$siteid = in_array($_GET['siteid'], array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) ? intval($_GET['siteid']) : null;
$wechatname = trim($_GET['wechatname']);
$perpage = intval($setting['admincp_perpage']) < 1 ? 1 : intval($setting['admincp_perpage']);
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
$mpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admin_wechat_recommendlist';
$mpurl = !empty($wechatname) ? $mpurl . '&wechatname=' . $wechatname : $mpurl;
$mpurl = $_GET['siteid'] !== null ? $mpurl . '&siteid=' . $_GET['siteid'] : $mpurl;
$url = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admin_wechat_recommendlist';
$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admin_wechat_recommendlist';
$fromurl = $_GET['siteid'] !== null ? $fromurl . '&siteid=' . $_GET['siteid'] : $fromurl;
$showsite = array(1 => $Plang['ca5c1c0f8acecaae'], 2 => $Plang['ecef5c6af70e8d30']);
$editstatus = array('0' => $Plang['05df925dd69b4333'], '1' => $Plang['d4cd6471a700d52c'], '-1' => $Plang['b5d0d1b6c49b2665'], '-2' => $Plang['4930bcc2615700e9']);
$search_toplist = array(
	$Plang['f8497259f9b3f761'],
	"<input size = \"25\" name=\"wechatname\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['wechatname']) . "\" />",
	"<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />",
	"<div " . ($_GET['siteid'] == '' ? 'class="allstatus"><a' : "><a style='color:#000;'") . " href=\"" . $url . "\">" . $Plang['e8af971c6963983d'] . "</a></div>"
);
$siteselect = "<select id='adsiteselect' name='adsite[]' multiple='multiple' size='11' style='width:220px;display:none;margin-left:5px;'>";
$searchkeyword = "<span id='searchkeyword' style='margin-right:10px;display:none;'>" . $Plang['a8bb59254f860e95'] . $Plang['3aba14be242cdfaf'] . "<input type='text' name='searchkeyword' style='width:120px;' placeholder='" . $Plang['371d94ee15decb1f'] . "'></span>";
foreach($sitearr as $key => $value) {
	$siteselect .= "<option style='width: 220px;' value='" . $key . "'>" . $value . "</option>";
	$value = substr($value, 0, strpos($value, $Plang['f7ac9becb8d864cb']));
	$search_toplist[count($search_toplist)] = "<div " . ($_GET['siteid'] == $key ? 'class="status"><a' : "><a style='color:green;'") . " href=\"" . $url . "&siteid=" . $key . "\">" . $value . "</a></div>";
}
$siteselect .= "</select>";
if(!submitcheck('form')) {
	echo "<style tpye='text/css'>
     .status{background-color: #666666;height:20px;width:110px;text-align:center;line-height:18px;border-radius:4px;}
     .allstatus{background-color: #666666;height:20px;width:55pxtext-align:center;line-height:18px;border-radius:4px;}
    .allstatus a,.status a{  color:#FFF;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    </style>";
	showformheader($fromurl, '', 'forms');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablerow('', array('width="50"', 'width="50"', 'width="50"', 'width="50"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"', 'width="100"'), $search_toplist);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/

	showformheader($fromurl, '', 'form');
	showtableheader($Plang['70a45e7a6f4a9f3a'], 'nobottom');
	showsubtitle(array('', $Plang['1670da9c2989259f'], $Plang['ddd826aa11868c7d'], $Plang['97af7ca7730595cd'], $Plang['9bd740f9fb972fc9'], $Plang['8011a11b7ec89d3c'], $Plang['d1d5561228aa89db'], $Plang['968265252bbb1364'], $Plang['a83a2e366221e5d3'], $Plang['75d24f054db77fd2'], $Plang['a7869dc83e527f4d'], $Plang['ca5a0d75b677d381']));
	$recommend_wids = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_all_by_siteid_keyword_group_by_wid();
	$wechatinfo = array();
	foreach($recommend_wids as $key => $value) {
		$wechatinfo[$value['wid']] = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($value['wid']);
		$wechatinfo[$value['wid']]['qrcode'] = wq_get_qrcode_by_wechatid($wechatinfo[$value['wid']]['wechatid']);
		$wechatinfo[$value['wid']]['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($wechatinfo[$value['wid']]['headimage']);
		$wechatinfo[$value['wid']]['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($wechatinfo[$value['wid']]['wechatbgimg']);
	}

	$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->count_by_search($wechatname, $siteid);
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->fetch_all_by_search($start, $perpage, $wechatname, $siteid);

	foreach($list as $key => $val) {

		showtablerow('class="tr"' . $val['id'] . '"', array('width="50"', 'width="50"', 'width="200"', 'width="200"', 'width="200"', 'width="150"', 'width="150"', 'width="100"', 'width="50"', 'width="50"', 'width="60"'), array(
			'<input class=\'fs\' type=\'checkbox\' name=\'delete[] \' value=\'' . $val['id'] . '\' /> ',
			'<input type="number" style="width:50px;" name="displayorder[' . $val['id'] . ']"  value="' . $val['displayorder'] . '" />',
			'<img style="width:100px; height:100px;" src="' . $wechatinfo[$val['wid']]['qrcode'] . '" /> ',
			"<a href='plugin.php?id=wq_wechatshow&mod=view&wid=" . $wechatinfo[$val['wid']]['wechatid'] . "&displayorder=index' target='_blank'>" . $wechatinfo[$val['wid']]['name'] . '<br>' . $wechatinfo[$val['wid']]['wechatid'] . "</a>",
			$sitearr[$val['siteid']],
			$val['keyword'] ? $val['keyword'] : '--',
			$showsite[$val['type']],
			$class = $wechatclass[$wechatinfo[$val['wid']]['classid']] ? $wechatclass[$wechatinfo[$val['wid']]['classid']]['classname'] : $Plang['e5dd6c90447db4c8'],
			$val['date'] ? date("Y-m-d H:i:s", $val['date']) : '--',
			$wechatinfo[$val['wid']]['articlenum'],
			$wechatinfo[$val['wid']]['totalarticle'],
			$editstatus[$wechatinfo[$val['wid']]['status']],
			)
		);
	}
	$multi = multi($count, $perpage, $page, $mpurl);
	$operation = '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" /><label for="chkall">' . cplang('select_all') . '</label>'
		. '<input type="radio" name="editstatus" id="del" value="1" class="radio" /><label for="del" class="vmiddle">' . $Plang['dd21ec1b2d3f0949'] . '</label>'
		. '<input type="radio" name="editstatus" id="update" value="2" class="radio" /><label for="update" class="vmiddle">' . $Plang['c3b3ed10c6a602f6'] . '</label>'
		. $siteselect . $searchkeyword;


	showsubmit('form', 'submit', $operation, '', $multi);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
	echo <<<EOF
    <script>
        window.onload =function () {
            var checkbox = document.getElementsByName('editstatus');
            for (var i = 0; i < checkbox.length; i++) {
                checkbox[i].onclick = function (e) {
                    if (e.target.id == 'update') {
                        document.getElementById('adsiteselect').style.display = 'inline';
                    } else {
                        document.getElementById('adsiteselect').style.display = 'none';
                        document.getElementById('searchkeyword').style.display = 'none';
                    }
                }
            }
            document.getElementById('adsiteselect').onchange = function () {
                if (document.getElementById('adsiteselect').children[0].selected) {
                    document.getElementById('searchkeyword').style.display = 'inline';
                } else {
                    document.getElementById('searchkeyword').style.display = 'none';
                }

            }
        }
    </script>
EOF;
} else {
	foreach($_GET['displayorder'] as $key => $value) {
		C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->update(intval($key), array('displayorder' => $value));
	}
	$j = $k = 0;
	foreach($_GET['delete'] as $value) {
		if($_GET['editstatus'] == '1') {
			C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->delete(intval($value));
		} else {
			foreach($_GET['adsite'] as $key => $val) {
				if($val == '1' && !trim($_GET['searchkeyword'])) {
					$k ++;
					continue;
				}
				$data = array(
					'siteid' => intval($val),
					'keyword' => intval($val) == 1 ? trim($_GET['searchkeyword']) : ''
				);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_recommend_list')->update(intval($value), $data);
				$j ++;
			}
		}
	}

	$url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admin_wechat_recommendlist';
	$url = $_GET['siteid'] ? $url . '&siteid=' . $_GET['siteid'] : $url;

	if($_GET['editstatus'] != '2') {
		cpmsg($Plang['aca2899ea8ef4a04'], $url, 'succeed');
	} else {
		cpmsg(sprintf($Plang['1840ddc7c7fed8b1'], $j, $k), $url, 'succeed');
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>