<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: install.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'stat':
		$cache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $cache));
		break;
	case 'sql':
		require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/install/install.core.php';

		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		require DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/install/wqcache_init.php';
		require_once libfile("function/cache");
		if(is_file(DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')) {
			require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';

			$hook = WeChatHook::getAPIHook('wq_wechatcollecting');

			$data = array(
				array('viewthread_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => 'WQ_WSQAPI',
						'method' => 'viewthread_variables'
					)),
				array('sendreply_variables' => array(
						'plugin' => 'wq_wechatcollecting',
						'include' => 'wsqapi.class.php',
						'class' => '',
						'method' => ''
					)),
			);

			WeChatHook::updateAPIHook($data);
		}

		wq_cron_create('wq_wechatcollecting');
	clear_old_tpl("wq_wechatcollecting");
	clear_old_tpl("wq_wechatshow");
	clear_old_tpl("wq_wechatreader");
	wq_clear("wq_wechatcollecting");

		$finish = TRUE;
		break;
}

function wq_clear($id) {

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id;

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/^discuz\_plugin\_' . $id . '(\_\w+)?\.xml$/', $f) || in_array($f, array("install.php", "upgrade.php"))) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}

function clear_old_tpl($id) {
	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/touch/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/mobile/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/';

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>