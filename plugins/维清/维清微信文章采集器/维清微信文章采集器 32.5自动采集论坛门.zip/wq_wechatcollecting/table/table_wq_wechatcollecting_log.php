<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_log extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_log';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_all_by_search($status, $keyword, $search, $date, $starttime, $endtime, $displayorder, $ordertype, $start, $limit) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' ' . $ordertype . ' ';
		}
		if($status != '') {
			$sql[] = 'status=%d';
			$val[] = $status;
		}
		if($date && $starttime) {
			$sql[] = $date . '>=%d';
			$val[] = $starttime;
		}
		if($date && $endtime) {
			$sql[] = '%d>=' . $date;
			$val[] = $endtime;
		}

		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($status, $keyword, $search, $date, $starttime, $endtime) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($status != '') {
			$sql[] = 'status=%d';
			$val[] = $status;
		}
		if($date && $starttime) {
			$sql[] = $date . '>=%d';
			$val[] = $starttime;
		}
		if($date && $endtime) {
			$sql[] = '%d>=' . $date;
			$val[] = $endtime;
		}
		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>