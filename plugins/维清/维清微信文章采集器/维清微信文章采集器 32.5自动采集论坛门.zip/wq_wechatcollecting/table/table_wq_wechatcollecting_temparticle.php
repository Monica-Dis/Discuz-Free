<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_temparticle extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_temparticle';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_first_by_wechatid($wechatid = '', $title = '') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($wechatid) {
			$sql[] = 'wechatid=%s';
			$val[] = $wechatid;
		}
		if($title) {
			$sql[] = 'title=%s';
			$val[] = $title;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function count_by_status($status, $wids = array(), $uid = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if(!empty($status)) {
			$sql[] = ' status in(%n)';
			$val[] = $status;
		}
		if($uid) {
			$sql[] = ' uid=%s ';
			$val[] = $uid;
		}
		if(is_array($wids) && count($wids) > 0) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wids;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_status($status, $start, $limit, $wids = array(), $uid = 0) {

		$val[] = $this->_table;
		$sql[] = '1';
		if($status) {
			$sql[] = ' status IN(%n)';
			$val[] = $status;
		}
		if($uid) {
			$sql[] = ' uid=%s ';
			$val[] = $uid;
		}
		if(is_array($wids) && count($wids) > 0) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wids;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . " ORDER BY collecttime DESC " . DB::limit($start, $limit), $val);
	}

	public function fetch_first_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_all($limit) {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 ORDER BY collecttime DESC " . DB::limit(0, $limit), array($this->_table));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>