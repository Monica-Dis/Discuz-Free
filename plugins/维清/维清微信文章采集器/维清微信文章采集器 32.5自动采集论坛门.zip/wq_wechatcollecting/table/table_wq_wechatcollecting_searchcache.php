<?php

/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_searchindex.php 28041 2012-02-21 07:33:55Z chenmengshu $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_searchcache extends discuz_table {

	public function __construct() {

		$this->_table = 'wq_wechatcollecting_searchcache';
		$this->_pk = 'searchid';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_by_searchid_srchmod($searchid, $srchmod) {
		return DB::fetch_first('SELECT * FROM %t WHERE searchid=%d AND srchmod=%d', array($this->_table, $searchid, $srchmod));
	}

	public function count_by_dateline($timestamp, $srchmod = '') {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE ' . ($srchmod ? 'srchmod=' . dintval($srchmod) . ' AND ' : '') . 'dateline>%d-60', array($this->_table, $timestamp));
	}

	public function fetch_all_search($searchctrl, $useip, $uid, $timestamp, $keywords, $srchmod) {
		if(!$searchctrl || !$timestamp || !$srchmod) {
			return null;
		}
		$timestamp = dintval($timestamp);
		$uid = dintval($uid);
		$srchmod = dintval($srchmod);
		$useip = daddslashes($useip);
		$searchctrl = dintval($searchctrl);
		$keywords = daddslashes($keywords);
		$this->delete_by_expiration();
		return DB::fetch_all("SELECT searchid, dateline,
			('" . $searchctrl . "'<>'0' AND " . (empty($uid) ? "useip='$useip'" : "uid='$uid'") . " AND $timestamp-dateline<'" . $searchctrl . "') AS flood,
			(srchmod=$srchmod AND keywords='$keywords' AND expiration>'$timestamp') AS indexvalid
			FROM " . DB::table($this->_table) . "
			WHERE srchmod=$srchmod AND ('" . $searchctrl . "'<>'0' AND " . (empty($uid) ? "useip='$useip'" : "uid='$uid'") . " AND $timestamp-dateline<" . $searchctrl . ") OR (srchmod=$srchmod AND keywords='$keywords' AND expiration>'$timestamp')
			ORDER BY flood");
	}

	public function delete_by_expiration($time = TIMESTAMP) {
		if(!$time || $time < 1) {
			$time = TIMESTAMP;
		}
		return DB::query("DELETE FROM %t WHERE expiration < %d", array($this->_table, $time));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>