<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_article extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_article';
		$this->_pre_cache_key = 'wq_wechatcollecting_article_';
		$this->_cache_ttl = 60;
		$this->_pk = 'articleid';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_all_by_search($status, $start, $limit, $title, $displayorder = 'date', $classid = '', $admrecommend = '', $name = '', $isfirst = false, $wid = 0, $isright = false, $isgetarticleid = false, $view_recommend = '') {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = $_GET['mod'] . '_limit_' . $start . $limit;
		if($displayorder == 'favorites') {
			$sql[] = 'favorites>0';
		}
		if($title) {
			$sql[] = 'title LIKE %s ';
			$val[] = '%' . $title . '%';
		}
		if($status) {
			if(count($status) == 1 && $status == array(1)) {
				$sql[] = 'status=%d';
				$val[] = 1;
			} else {
				$sql[] = 'status IN(%n)';
				$val[] = $status;
			}
		}
		if($admrecommend != '') {
			$sql[] = 'admrecommend=%d';
			$val[] = $admrecommend;
			$cachekey .= '_admrecommend';
		}
		if($view_recommend != '') {
			$sql[] = 'recommend=%d';
			$val[] = $view_recommend;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = 1;
			$cachekey .= '_isfirst';
		}
		if($classid !== '') {
			$sql[] = 'classid=%d';
			$val[] = $classid;
			$cachekey .= '_cid' . $classid;
		}
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = intval($wid);
		}

		if($name) {
			$sql[] = 'name=%s';
			$val[] = $name;
		}
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' DESC ';
			$cachekey .= '_' . $displayorder;
		}
		$wheresql = implode(' AND ', $sql);

		$url = $_SERVER['PHP_SELF'];
		$scriptname = end(explode('/', $url));
		$scriptname = reset(explode('.', $scriptname));
		$list_flag = !$isright && !$sqlcache['article_list']['status'];
		$right_flag = $isright && !$sqlcache['right_bottom']['status'];
		if($scriptname == 'admin' || $list_flag || $right_flag) {
			$cachekey = '';
		} else {
			$ttl = $isright ? $sqlcache['right_bottom']['time'] : $sqlcache['article_list']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		}


		$list = array();
		if(!$cachekey || $isgetarticleid) {
			$field = $isgetarticleid ? 'articleid' : '*';
			return DB::fetch_all("SELECT " . $field . " FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
		}
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($list = $this->fetch_cache($cachekey)) === false) {
			$list = DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
			if($list) {
				$this->store_cache($cachekey, $list, $ttl);
			}
		}
		return $list;
	}

	public function update_incrcase($id, $setarr, $operation = true) {
		$sql = array();
		$allowkey = array('views');
		foreach($setarr as $key => $val) {
			if(($val = intval($val) && in_array($key, $allowkey))) {
				if($operation == true) {
					$sql[] = "`$key`=`$key`+$val";
				} else {
					$sql[] = "`$key`=`$key`-$val";
				}
			}
		}
		$where = DB::field('articleid', $id);
		if(!empty($sql)) {
			return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $where));
		}
	}

	public function count_by_search($status, $title, $classid = '', $admrecommend = '', $name = '', $first = 0, $view_recommend = '') {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = $_GET['mod'] . '_count';
		if($title) {
			$sql[] = 'title LIKE %s ';
			$val[] = '%' . $title . '%';
		}
		if($name) {
			$sql[] = 'name=%s';
			$val[] = $name;
		}

		if($status) {
			if(count($status) == 1 && $status == array(1)) {
				$sql[] = 'status=%d';
				$val[] = 1;
			} else {
				$sql[] = 'status IN(%n)';
				$val[] = $status;
			}
		}
		if($admrecommend != '') {
			$sql[] = 'admrecommend=%d';
			$val[] = $admrecommend;
			$cachekey .= '_admrecommend';
		}
		if($view_recommend != '') {
			$sql[] = 'recommend=%d';
			$val[] = $view_recommend;
		}
		if($first == 1) {
			$sql[] = 'isfirst=%d';
			$val[] = $first;
			$cachekey .= '_isfirst';
		}
		if($classid !== '') {
			$sql[] = 'classid=%d';
			$val[] = $classid;
			$cachekey .= '_cid' . $classid;
		}
		$url = $_SERVER['PHP_SELF'];
		$scriptname = end(explode('/', $url));
		$scriptname = reset(explode('.', $scriptname));

		if($scriptname == 'admin' || $title || !$sqlcache['article_list']['status']) {
			$cachekey = '';
		} else {
			$ttl = $sqlcache['article_list']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		}
		$wheresql = implode(' AND ', $sql);
		if(!$cachekey) {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
		}
		$count = 0;
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($count = $this->fetch_cache($cachekey)) === false) {
			$count = DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
			if($count) {
				$this->store_cache($cachekey, $count, $ttl);
			}
		}
		return $count;
	}

	public function fetch_all_by_status($status, $start, $limit, $wids = array(), $uid = 0) {

		$val[] = $this->_table;
		$sql[] = '1';
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}
		if($uid) {
			$sql[] = 'uid=%s';
			$val[] = $uid;
		}
		if(is_array($wids) && count($wids) > 0) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wids;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . " ORDER BY collecttime DESC " . DB::limit($start, $limit), $val);
	}

	public function count_by_status($status, $wids = array(), $uid = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if(!empty($status)) {
			$sql[] = ' status in(%n)';
			$val[] = $status;
		}
		if($uid) {
			$sql[] = ' uid=%s ';
			$val[] = $uid;
		}
		if(is_array($wids) && count($wids) > 0) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wids;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_first_by_articleid($articleid) {
		if(dintval($articleid) < 1) {
			return array();
		}
		return DB::fetch_first("SELECT * FROM %t WHERE articleid=%d", array($this->_table, $articleid));
	}

	public function fetch_all_by_articleid($articleid) {
		if(!is_array($articleid) || count($articleid) < 1) {
			return array();
		}
		return DB::fetch_all("SELECT * FROM %t WHERE articleid IN(%n)", array($this->_table, $articleid));
	}

	public function fetch_all_by_tid($tid) {
		if(!is_array($tid) || count($tid) < 1) {
			return array();
		}
		return DB::fetch_all("SELECT * FROM %t WHERE tid IN(%n)", array($this->_table, $tid));
	}

	public function fetch_all_by_aid($aid) {
		if(!is_array($aid) || count($aid) < 1) {
			return array();
		}
		return DB::fetch_all("SELECT * FROM %t WHERE aid IN(%n)", array($this->_table, $aid));
	}

	public function fetch_by_wid($wid) {
		if(dintval($wid) < 1) {
			return array();
		}
		return DB::fetch_all("SELECT * FROM %t WHERE wid=%d", array($this->_table, $wid));
	}

	public function fetch_first_by_tid($tid) {
		if(dintval($tid) < 1) {
			return array();
		}
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array($this->_table, $tid));
	}

	public function fetch_first_by_aid($aid) {
		if(dintval($aid) < 1) {
			return array();
		}
		return DB::fetch_first("SELECT * FROM %t WHERE aid=%d", array($this->_table, $aid));
	}

	public function fetch_all_by_title($title) {
		if(!$title) {
			return array();
		}
		return DB::fetch_all("SELECT * FROM %t WHERE title=%s", array($this->_table, $title));
	}

	public function update_wechatid($data, $wechatid) {
		$conditions = array(
			'wechatid' => $wechatid
		);
		return DB::update($this->_table, $data, $conditions);
	}

	public function update_wid($data, $wid) {
		$conditions = array(
			'wid' => $wid
		);
		return DB::update($this->_table, $data, $conditions);
	}

	public function fetch_first_by_wechatid($wechatid = '', $title = '') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($wechatid) {
			$sql[] = 'wechatid=%s';
			$val[] = $wechatid;
		}
		if($title) {
			$sql[] = 'title=%s';
			$val[] = $title;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_wid($wid, $status, $start, $limit, $displayorder, $ordertype = "DESC", $recommend = '', $isfirst = 0) {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = '';
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
			$cachekey .= '_wid' . $wid;
		}
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}

		if($recommend != '') {
			$sql[] = 'recommend=%d';
			$val[] = $recommend;
			$cachekey .= '_recommend' . $recommend;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = $isfirst;
			$cachekey .= '_isfirst' . $isfirst;
		}
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' ' . $ordertype;
			$cachekey .= '_' . $displayorder . '_' . $ordertype;
		}
		$wheresql = implode(' AND ', $sql);


		if($cachekey && $start < 1 && $sqlcache['wechat_view_articlelist']['status']) {
			$cachekey = $_GET['mod'] . $cachekey;
			$ttl = $sqlcache['wechat_view_articlelist']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		} else {
			return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
		}
		$list = array();
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($list = $this->fetch_cache($cachekey)) === false) {
			$list = DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
			if($list) {
				$this->store_cache($cachekey, $list, $ttl);
			}
		}
		return $list;
	}

	public function count_by_wid($wid, $status = array(), $recommend = '', $isfirst = 0) {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = '';
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
			$cachekey .= '_wid' . $wid;
		}
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}

		if($recommend != '') {
			$sql[] = 'recommend=%d';
			$val[] = $recommend;
			$cachekey .= '_recommend' . $recommend;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = $isfirst;
			$cachekey .= '_isfirst' . $isfirst;
		}

		$wheresql = implode(' AND ', $sql);
		if($cachekey && $sqlcache['wechat_view_articlelist']['status']) {
			$cachekey = $_GET['mod'] . '_count' . $cachekey;
			$ttl = $sqlcache['wechat_view_articlelist']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		} else {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
		}
		$count = 0;
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($count = $this->fetch_cache($cachekey)) === false) {
			$count = DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
			if($count) {
				$this->store_cache($cachekey, $count, $ttl);
			}
		}
		return $count;
	}

	public function count_by_wechatid($wechatid, $status = '1') {
		if($status === false) {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE wechatid = %s", array($this->_table, $wechatid));
		} else {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE wechatid = %s AND status=%d", array($this->_table, $wechatid, $status));
		}
	}

	public function fetch_by_imgdownloaded($articleid) {
		return DB::fetch_first("SELECT imgdownloaded FROM %t WHERE articleid = %s", array($this->_table, $articleid));
	}

	public function fetch_all_by_in_wid_isfirst($wid, $start, $limit, $isfirst = 0) {
		if(!is_array($wid) || count($wid) < 1) {
			return null;
		}
		$val[] = $this->_table;
		$sql[] = '1';
		if($wid) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wid;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = $isfirst;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . " ORDER BY date DESC " . DB::limit($start, $limit), $val);
	}

	public function count_by_in_wid_isfirst($wid, $isfirst = 0) {
		if(!is_array($wid) || count($wid) < 1) {
			return 0;
		}
		$val[] = $this->_table;
		$sql[] = '1';
		if($wid) {
			$sql[] = 'wid IN(%n)';
			$val[] = $wid;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = $isfirst;
		}
		$where = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
	}

	public function count_by_wid_recommend_isfirst($wid = 0, $recommend = 0, $isfirst = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		$sql[] = 'status=%d';
		$val[] = 1;
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($recommend) {
			$sql[] = 'recommend=%d';
			$val[] = $recommend;
		}
		if($isfirst) {
			$sql[] = 'isfirst=%d';
			$val[] = $isfirst;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function update_contenttableid($articleid, $data, $unbuffered = false, $low_priority = false, $realdata = false) {
		$articleid = dintval($articleid, true);
		if($data && is_array($data) && $articleid) {
			if(!$realdata) {
				$num = DB::update($this->_table, $data, DB::field('articleid', $articleid), $unbuffered, $low_priority);
				$this->update_batch_cache((array) $articleid, $data);
			} else {
				$num = DB::query('UPDATE ' . $this->_table . " SET " . implode(',', $data) . " WHERE " . DB::field('articleid', $articleid), 'UNBUFFERED');
				$this->clear_cache($articleid);
			}
			return $num;
		}
		return !$unbuffered ? 0 : false;
	}

	public function fetch_all_by_imgdownloaded($field, $status, $start = 0, $limit = 20, $displayorder = 'imgdownloaded', $ordertype = "DESC") {
		$order = ' ORDER BY ' . $displayorder . ' ' . $ordertype;
		$val[] = $this->_table;
		$sql[] = '1';

		if($status) {
			$status = is_array($status) ? $status : (array) $status;
			$sql[] = 'imgdownloaded IN(%n)';
			$val[] = $status;
		}

		$field = empty($field) ? '*' : $field;

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT " . $field . " FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function fetch_aid_by_aid_wid_type($aid, $wid, $type = '>') {
		$type = in_array($type, array('>', '<')) ? $type : '>';
		$sort = $type == '>' ? 'ASC' : 'DESC';
		return DB::fetch_first("SELECT articleid,title FROM %t WHERE wid=%d AND articleid " . $type . " %d ORDER BY " . DB::order('articleid', $sort) . DB::limit(1), array($this->_table, $wid, $aid));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>