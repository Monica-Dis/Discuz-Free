<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_attachment.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_attachment extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_attachment';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function delete_by_attachment_articleid($articleid) {
		return DB::delete($this->_table, array('articleid' => $articleid), 1);
	}

	function fetch_by_articleid($articleid) {
		return DB::fetch_first("SELECT * FROM %t WHERE articleid=%d", array($this->_table, $articleid));
	}

	function fetch_all_imageurl_by_articleid($articleid) {
		return DB::fetch_all("SELECT * FROM %t WHERE articleid=%d", array($this->_table, $articleid));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>