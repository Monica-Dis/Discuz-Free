<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_wechat extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_wechat';
		$this->_pk = 'id';
		$this->_pre_cache_key = 'wq_wechatcollecting_wechat_';
		$this->_cache_ttl = 60;
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_all_by_search($status, $start, $limit, $wechatname, $orderby = 'collecttime', $recommend = '', $uid = 0, $m_uid = 0, $idin = false, $cid = '', $acid = '', $view_mode = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}
		if($wechatname) {
			$sql[] = 'name LIKE %s ';
			$val[] = '%' . $wechatname . '%';
		}
		if(is_array($recommend) && count($recommend) > 1) {
			$sql[] = $idin ? 'id IN(%n)' : 'id NOT IN(%n)';
			$val[] = $recommend;
		}
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($m_uid) {
			$sql[] = 'maintain_uid=%d';
			$val[] = $m_uid;
		}
		if($cid !== '') {
			$sql[] = 'classid=%d';
			$val[] = $cid;
		}
		if($acid !== '') {
			$sql[] = 'article_classid=%d';
			$val[] = $acid;
		}
		if($view_mode !== '' || $view_mode) {
			$sql[] = 'view_mode=%d';
			$val[] = $view_mode;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . " ORDER BY `" . $orderby . "` DESC " . DB::limit($start, $limit), $val, 'id');
	}

	public function count_by_search($status, $wechatname, $recommend = '', $uid = 0, $m_uid = 0, $idin = false, $cid = '', $acid = '', $view_mode = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if(!empty($status)) {
			$sql[] = 'status in(%n)';
			$val[] = $status;
		}
		if($wechatname) {
			$sql[] = 'name LIKE %s ';
			$val[] = '%' . $wechatname . '%';
		}
		if(is_array($recommend) && count($recommend) > 1) {
			$sql[] = $idin ? 'id IN(%n)' : 'id NOT IN(%n)';
			$val[] = $recommend;
		}
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($m_uid) {
			$sql[] = 'maintain_uid=%d';
			$val[] = $m_uid;
		}

		if($cid !== '') {
			$sql[] = 'classid=%d';
			$val[] = $cid;
		}
		if($acid !== '') {
			$sql[] = 'article_classid=%d';
			$val[] = $acid;
		}
		if($view_mode !== '' || $view_mode) {
			$sql[] = 'view_mode=%d';
			$val[] = $view_mode;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_first_by_wechatid($wechatid) {
		global $sqlcache;
		if($sqlcache['wechat_info']['status']) {
			$cachekey = 'wechatinfo_wid_' . $wechatid;
			$ttl = $sqlcache['wechat_info']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		} else {
			return DB::fetch_first("SELECT * FROM %t WHERE wechatid=%s", array($this->_table, $wechatid));
		}

		$data = array();
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($data = $this->fetch_cache($cachekey)) === false) {
			$data = DB::fetch_first("SELECT * FROM %t WHERE wechatid=%s", array($this->_table, $wechatid));
			if($data) {
				$this->store_cache($cachekey, $data, $ttl);
			}
		}
		return $data;
	}

	public function fetch_first_by_username($username) {
		return DB::fetch_first("SELECT * FROM %t WHERE username=%s", array($this->_table, $username));
	}

	public function fetch_first_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_all_by_uid_status($uid, $maintainuid, $status, $start, $limit, $recommend = '', $wechatname = '', $displayorder = 'collecttime', $order = 'DESC') {

		if(in_array($status, array('auto-1', 'auto-0'))) {
			$bool = $status == 'auto-0' ? false : true;
			if($bool) {
				$displayorder = 'displayorder';
				$order = 'ASC,collecttime DESC';
			}
			$wheresql = DB::field('automaticcollect', $bool, '=');
		} else {
			$wheresql = DB::field('status', $status, 'in');
		}

		$array = array($this->_table);
		if($recommend != '') {
			$wheresql = $wheresql . ' AND recommend=%d';
			array_push($array, $recommend);
		}
		if($uid) {
			$wheresql = $wheresql . ' AND uid=%d';
			array_push($array, $uid);
		}
		if($maintainuid) {
			$wheresql = $wheresql . ' AND maintain_uid=%d';
			array_push($array, $maintainuid);
		}
		if($wechatname) {
			$wheresql = $wheresql . ' AND name LIKE %s';
			array_push($array, '%' . $wechatname . '%');
		}
		$orderby = ' ORDER BY ' . $displayorder . ' ' . $order;
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $orderby . DB::limit($start, $limit), $array);
	}

	public function count_by_uid($uid) {
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

	public function count_by_status($status, $uid, $maintainuid, $recommend = '', $wechatname = '') {
		if(in_array($status, array('auto-1', 'auto-0'))) {
			$bool = $status == 'auto-0' ? false : true;
			$wheresql = DB::field('automaticcollect', $bool, '=');
		} else {
			$wheresql = DB::field('status', $status, 'in');
		}
		$array = array($this->_table);
		if($recommend != '') {
			$wheresql = $wheresql . ' AND recommend=%d';
			array_push($array, $recommend);
		}
		if($uid) {
			$wheresql = $wheresql . ' AND uid=%d';
			array_push($array, $uid);
		}
		if($maintainuid) {
			$wheresql = $wheresql . ' AND maintain_uid=%d';
			array_push($array, $maintainuid);
		}
		if($wechatname) {
			$wheresql = $wheresql . ' AND name LIKE %s';
			array_push($array, '%' . $wechatname . '%');
		}
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $array);
	}

	public function update_incrcase($id, $setarr, $operation = true) {
		$sql = array();
		$allowkey = array('views', 'articlenum');
		foreach($setarr as $key => $val) {
			if(intval($val) && in_array($key, $allowkey)) {
				$val = intval($val);
				if($operation == true) {
					$sql[] = "`$key`=`$key`+$val";
				} else {

					$sql[] = "`$key`=`$key`-$val";
				}
			}
		}

		$where = DB::field($this->_pk, $id);
		if(!empty($sql)) {
			DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $where));
			C::memory()->clear();
		}
	}

	public function fetch_all_wehere($status, $start, $limit, $wechatname, $displayorder = '', $classid = 0, $isgetid = false) {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = $_GET['mod'] . '_limit' . $limit;
		if($classid) {
			$sql[] = 'classid=%d';
			$val[] = $classid;
			$cachekey .= '_cid' . $classid;
		}
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}

		if($wechatname) {
			$sql[] = 'name LIKE %s ';
			$val[] = '%' . $wechatname . '%';
		}
		if($displayorder) {
			$order = ' ORDER BY `' . $displayorder . '` DESC ';
			$cachekey .= '_' . $displayorder;
		}
		$wheresql = implode(' AND ', $sql);
		$url = $_SERVER['PHP_SELF'];
		$scriptname = end(explode('/', $url));
		$scriptname = reset(explode('.', $scriptname));
		if($scriptname == 'admin' || $wechatname || $start > 0 || !$sqlcache['wechat_list']['status']) {
			$cachekey = '';
		} else {
			$ttl = $sqlcache['wechat_list']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		}

		if(!$cachekey || $isgetid) {
			$field = $isgetid ? 'id' : '*';
			return DB::fetch_all("SELECT " . $field . " FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
		}
		$list = array();
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($list = $this->fetch_cache($cachekey)) === false) {
			$list = DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
			if($list) {
				$this->store_cache($cachekey, $list, $ttl);
			}
		}
		return $list;
	}

	public function count_by_where($status, $wechatname, $classid = 0) {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$cachekey = $_GET['mod'] . '_count';

		if($classid) {
			$sql[] = 'classid=%d';
			$val[] = $classid;
			$cachekey .= '_cid' . $classid;
		}
		if($status) {
			$sql[] = 'status IN(%n)';
			$val[] = $status;
		}
		if($wechatname) {
			$sql[] = 'name LIKE %s ';
			$val[] = '%' . $wechatname . '%';
		}
		$wheresql = implode(' AND ', $sql);
		$url = $_SERVER['PHP_SELF'];
		$scriptname = end(explode('/', $url));
		$scriptname = reset(explode('.', $scriptname));
		if($scriptname == 'admin' || $wechatname || !$sqlcache['wechat_list']['status']) {
			$cachekey = '';
		} else {
			$ttl = $sqlcache['wechat_list']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		}

		if(!$cachekey) {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
		}
		$count = 0;
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($count = $this->fetch_cache($cachekey)) === false) {
			$count = DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
			if($count) {
				$this->store_cache($cachekey, $count, $ttl);
			}
		}
		return $count;
	}

	public function fetch_all_automaticcollect($status, $automaticcollect, $collectfinish, $displayorder, $start, $limit) {
		if($displayorder) {
			$order = ' ORDER BY `' . $displayorder . '` ASC,displayorder ASC';
		}

		$val = array($this->_table, $status, $automaticcollect, $collectfinish);
		return DB::fetch_all("SELECT * FROM %t WHERE status=%d AND automaticcollect=%d AND collectfinish=%d " . $order . DB::limit($start, $limit), $val);
	}

	public function update_all_zeroization($status) {
		return DB::query("UPDATE %t SET collectnumber=%d,collectfinish=%d WHERE status=%d AND collectnumber>='0'", array($this->_table, 0, 0, $status));
	}

	public function update_airticelnum_by_wechatid($airticelnum, $wechatid) {
		return DB::update($this->_table, array('articlenum' => $airticelnum), array('wechatid' => $wechatid));
	}

	public function fetch_all_group_wechatid() {
		return DB::fetch_all("SELECT COUNT(wechatid) as cou_num,id,wechatid FROM %t GROUP BY wechatid HAVING cou_num > 1 ORDER BY id", array($this->_table));
	}

	public function fetch_all_headimage_is_empty() {
		return DB::fetch_all("SELECT * FROM %t WHERE ((headimage='' AND logoflag=0) OR (headimage!='' AND logoflag!=0))", array($this->_table));
	}

	public function fetch_all_by_maintain_uid($maintain_uid) {
		$sql[] = 1;
		$val[] = $this->_table;
		if(!intval($maintain_uid)) {
			return null;
		} else {
			$sql[] = 'maintain_uid=%d';
			$val[] = intval($maintain_uid);
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function fetch_by_maintain_uid($maintain_uid) {
		$sql[] = 1;
		$val[] = $this->_table;
		if(!intval($maintain_uid)) {
			return null;
		} else {
			$sql[] = 'maintain_uid=%d';
			$val[] = intval($maintain_uid);
		}

		$where = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function fetch_all_type($type) {
		$sql[] = 1;
		$val[] = $this->_table;
		if(intval($type)) {
			$sql[] = 'type=%d';
			$val[] = intval($type);
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function clear_cache_by_id($id) {
		$wechat = $this->fetch_first_by_id($id);
		$cachekey = $this->_pre_cache_key . 'wechatinfo_wid_' . $wechat['wechatid'];
		$this->clear_cache('', $cachekey);
	}

	public function fetch_all_by_id($id) {
		$id = is_array($id) ? $id : (array) $id;
		return DB::fetch_all("SELECT * FROM %t WHERE id IN(%n)", array($this->_table, $id), 'id');
	}

	public function fetch_all_by_commonview($commonview) {
		return DB::fetch_all("SELECT * FROM %t WHERE common_view=%d", array($this->_table, $commonview));
	}

	public function fetch_first_for_loop($lastid) {
		if(empty($lastid)) {
			$lastid = 0;
		}
		return DB::fetch_first("SELECT * FROM %t WHERE wechatbiz<>'' AND id > %d ORDER BY id ASC", array($this->_table, $lastid));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>