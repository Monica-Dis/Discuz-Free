<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_article_content extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_article_content';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function update($tableid, $id, $data) {
		$where = array();
		$where[] = DB::field('id', $id);
		$return = DB::update(self::get_wq_wechatcollecting_article_content_table($tableid), $data, implode(' AND ', $where));
		return $return;
	}

	public function fetch_first_by_articleid($articleid, $status = array(1), $tableid = 0) {
		return DB::fetch_first("SELECT ac.*, at.* FROM " . DB::table('wq_wechatcollecting_article') . " at LEFT JOIN %t ac ON at.articleid=ac.articleid WHERE at.articleid=%d AND at.status IN(%n)", array(self::get_wq_wechatcollecting_article_content_table($tableid), $articleid, $status));
	}

	public function result_first_by_articleid($articleid, $tableid = 0) {
		return DB::result_first("SELECT content FROM %t WHERE articleid=%d", array(self::get_wq_wechatcollecting_article_content_table($tableid), $articleid));
	}

	public function update_content_by_articleid($articleid, $content, $tableid = 0) {
		return DB::update(self::get_wq_wechatcollecting_article_content_table($tableid), array('content' => $content), array('articleid' => $articleid));
	}

	public function delete_by_articleid($articleid, $tableid = 0) {
		return DB::delete(self::get_wq_wechatcollecting_article_content_table($tableid), array('articleid' => $articleid), 1);
	}

	public static function get_wq_wechatcollecting_article_content_table($tableid = 0, $prefix = false) {
		global $_G;
		$tableid = intval($tableid);
		if($tableid) {
			loadcache('wq_content_tableids');
			$tableid = $_G['cache']['wq_content_tableids'] && in_array($tableid, $_G['cache']['wq_content_tableids']) ? $tableid : 0;
			$tablename = 'wq_wechatcollecting_article_content' . ($tableid ? "_$tableid" : '');
		} else {
			$tablename = 'wq_wechatcollecting_article_content';
		}
		if($prefix) {
			$tablename = DB::table($tablename);
		}
		return $tablename;
	}

	public function show_table() {
		return DB::fetch_all("SHOW TABLES LIKE '" . DB::table('wq_wechatcollecting_article_content') . "\_%'");
	}

	public function show_table_by_tableid($tableid) {
		return DB::fetch_first('SHOW CREATE TABLE %t', array(self::get_wq_wechatcollecting_article_content_table($tableid)));
	}

	public function show_table_columns($table) {
		$data = array();
		$db = &DB::object();
		if($db->version() > '4.1') {
			$query = $db->query("SHOW FULL COLUMNS FROM " . DB::table($table), 'SILENT');
		} else {
			$query = $db->query("SHOW COLUMNS FROM " . DB::table($table), 'SILENT');
		}
		while($field = @DB::fetch($query)) {
			$data[$field['Field']] = $field;
		}
		return $data;
	}

	public function count_table($tableid) {
		return DB::result_first('SELECT COUNT(*) FROM %t', array(self::get_wq_wechatcollecting_article_content_table($tableid)));
	}

	public function fetch_all_articleid($tableid, $start = 0, $limit = 0) {
		return DB::fetch_all('SELECT articleid FROM %t WHERE 1' . DB::limit($start, $limit), array(self::get_wq_wechatcollecting_article_content_table($tableid)));
	}

	public function move_table($tableid, $fieldstr, $fromtable, $articleid) {
		$articleidsql = is_array($articleid) ? 'articleid IN(%n)' : 'articleid=%d';
		return DB::query("INSERT INTO %t ($fieldstr) SELECT $fieldstr FROM $fromtable WHERE $articleidsql", array(self::get_wq_wechatcollecting_article_content_table($tableid), $articleid), true);
	}

	public function delete_by_articleids($tableid, $articleids, $unbuffered = false) {
		$return = DB::delete(self::get_wq_wechatcollecting_article_content_table($tableid), DB::field('articleid', $articleids), 0, $unbuffered);
		return $return;
	}

	public function drop_table($tableid) {
		return ($tableid = dintval($tableid)) ? DB::query('DROP TABLE %t', array(self::get_wq_wechatcollecting_article_content_table($tableid))) : false;
	}

	public function optimize_table($tableid) {
		return DB::query('OPTIMIZE TABLE %t', array(self::get_wq_wechatcollecting_article_content_table($tableid)), true);
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>