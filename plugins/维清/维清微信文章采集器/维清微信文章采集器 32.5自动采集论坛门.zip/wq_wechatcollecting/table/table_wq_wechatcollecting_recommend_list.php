<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_recommend_list extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_recommend_list';
		$this->_pk = 'id';
		$this->_pre_cache_key = 'wq_wechatcollecting_recommend_list_';
		$this->_cache_ttl = 60;
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_by_wid_siteid($wid, $siteid) {
		$val[] = $this->_table;
		$sql[] = 1;
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function fetch_all_by_siteid_keyword_group_by_wid($siteid = 0, $keyword = '') {
		$val[] = $this->_table;
		$sql[] = 1;
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		if($keyword) {
			$sql[] = 'keyword=%s';
			$val[] = $keyword;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . " GROUP BY wid", $val);
	}

	public function fetch_all_by_search($start, $limit, $wechatname, $siteid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		$where = implode(' AND ', $sql) . ' ';

		if($wechatname) {
			$where .= 'AND name LIKE %s';
			$val[] = '%' . $wechatname . '%';
			return DB::fetch_all("SELECT r.* FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where . ' ORDER BY r.displayorder ASC,r.id DESC' . DB::limit($start, $limit), $val);
		} else {
			return DB::fetch_all("SELECT * FROM %t WHERE " . $where . ' ORDER BY displayorder ASC,id DESC' . DB::limit($start, $limit), $val);
		}
	}

	public function fetch_all_left_join_wechat($siteid, $classid, $limit, $keyword, $date = "") {
		global $sqlcache;
		$val[] = $this->_table;
		$sql[] = '1';
		$sql[] = 'status=%d';
		$val[] = 1;
		$cachekey = $_GET['mod'] . '_limit' . $limit;
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
			$cachekey .= '_siteid';
		}
		if($classid) {
			$sql[] = 'classid=%d';
			$val[] = $classid;
			$cachekey .= '_classid' . $classid;
		}
		if($keyword) {
			$sql[] = 'keyword=%s';
			$val[] = $keyword;
		}
		if($date) {
			$sql[] = 'date>=%s';
			$val[] = $date;
		}
		$where = implode(' AND ', $sql);
		$url = $_SERVER['PHP_SELF'];
		$scriptname = end(explode('/', $url));
		$scriptname = reset(explode('.', $scriptname));
		if($scriptname == 'admin' || $keyword || !$sqlcache['recommend_list']['status']) {
			$cachekey = '';
		} else {
			$ttl = $sqlcache['recommend_list']['time'];
			$ttl = $ttl >= 0 ? $ttl : $this->_cache_ttl;
		}

		if(!$cachekey) {
			return DB::fetch_all("SELECT w.* FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where . " ORDER BY r.displayorder DESC,r.id DESC " . DB::limit($limit), $val);
		}
		$list = array();
		$cachekey = str_replace('__', '_', ltrim($cachekey, '_'));
		if(($list = $this->fetch_cache($cachekey)) === false) {
			$list = DB::fetch_all("SELECT w.* FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where . " ORDER BY r.displayorder DESC,r.id DESC " . DB::limit($limit), $val);
			if($list) {
				$this->store_cache($cachekey, $list, $ttl);
			}
		}
		return $list;
	}

	public function count_by_search($wechatname, $siteid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		$where = implode(' AND ', $sql);

		if($wechatname) {
			$where .= ' AND name LIKE %s';
			$val[] = '%' . $wechatname . '%';
			return DB::result_first("SELECT COUNT(*) FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where, $val);
		} else {
			return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
		}
	}

	public function count_by_siteid_date($siteid = "", $date = "") {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		if($date) {
			$sql[] = 'date>=%d';
			$val[] = $date;
		}
		$where = implode(' AND ', $sql);

		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
	}

	public function count_by_siteid_date_classid($siteid = "", $date = "", $classid = "") {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'r.siteid=%d';
			$val[] = $siteid;
		}
		if($date) {
			$sql[] = 'r.date>=%d';
			$val[] = $date;
		}
		if($classid) {
			$sql[] = 'w.classid=%d';
			$val[] = $classid;
		}
		$where = implode(' AND ', $sql);

		return DB::result_first("SELECT COUNT(*) FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where, $val);
	}

	public function fetch_by_siteid_date($siteid = "", $date = "") {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'siteid=%d';
			$val[] = $siteid;
		}
		if($date) {
			$sql[] = 'date>=%d';
			$val[] = $date;
		}
		$where = implode(' AND ', $sql);

		return DB::result_first("SELECT date FROM %t WHERE " . $where . " ORDER BY date ASC", $val);
	}

	public function fetch_by_siteid_date_classid($siteid = "", $date = "", $classid = "") {
		$val[] = $this->_table;
		$sql[] = '1';
		if($siteid) {
			$sql[] = 'r.siteid=%d';
			$val[] = $siteid;
		}
		if($date) {
			$sql[] = 'r.date>=%d';
			$val[] = $date;
		}
		if($classid) {
			$sql[] = 'w.classid=%d';
			$val[] = $classid;
		}
		$where = implode(' AND ', $sql);

		return DB::result_first("SELECT date FROM %t r LEFT JOIN " . DB::table('wq_wechatcollecting_wechat') . " w ON r.wid=w.id WHERE " . $where . " ORDER BY date ASC", $val);
	}

	public function del_by_wid($wid) {
		$wid = intval($wid);
		if(!$wid) {
			return 0;
		}
		return DB::delete($this->_table, array('wid' => $wid));
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>