<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatcollecting_poll extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatcollecting_poll';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_first_by_aid_uid($aid, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($aid) {
			$sql[] = 'articleid=%d';
			$val[] = $aid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_aid_uid_polltype($aid, $uid, $polltype) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($aid) {
			$sql[] = 'articleid=%d';
			$val[] = $aid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		if(in_array($polltype, array(0, 1))) {
			$sql[] = 'polltype=%d ';
			$val[] = $polltype;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function count_by_aid_polltype($aid, $polltype) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($aid) {
			$sql[] = 'articleid=%d';
			$val[] = $aid;
		}

		if(in_array($polltype, array(0, 1))) {
			$sql[] = 'polltype=%d ';
			$val[] = $polltype;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From:  d'.'is'.'m.ta'.'obao.com
?>