<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<script type="text/javascript" src="./source/plugin/wq_wechatcollecting/static/js/ueditor.config.js?{VERHASH}"></script>
<script>
	window.UEDITOR_CONFIG.serverUrl = window.UEDITOR_CONFIG.serverUrl + "&idtype=article&idvalue={$contents['articleid']}"
</script>
<script type="text/javascript" src="./source/plugin/wq_editor/ue/ueditor.all.min.js?{VERHASH}"></script>
<script type="text/javascript" src="./source/plugin/wq_editor/ue/lang/zh-cn/zh-cn.js?{VERHASH}"></script>
<style>
    .original_link{ margin-left:10px; line-height:22px; color:#0093dd;}
    .save_changes{ margin:10px 0px; background:#0ba3e9; border:1px solid #0ba3e9; color:#fff; padding:5px 10px; border-radius:3px; cursor:pointer;}
</style>
<div id="wp" class="wp time_wp" style='margin-top:20px;'>
    <form name="post" action='plugin.php?id=wq_wechatcollecting&mod=edit' method="post">
        <div class="pbt cl">
            <a href="$lookurl" target="_blank" class="original_link">{$Plang['1c46ec2684e2dbd8']}</a>
            <div class="z">
                <input name="content" id="content" type="hidden" value="" />
                <input name="articleid" type="hidden" value="$contents['articleid']"/>
                <input type="hidden" value="{FORMHASH}" name="formhash"/>
                <span><input name="title" id="subject" class="px" value="$contents['title']" onkeyup="strLenCalc(this, 'checklen', 80);" style="width: 30em" tabindex="1" type="text" maxlength="80"></span>
                <span id="subjectchk">{$Plang['8bfa2ef6d47e6fff']} <strong id="checklen"></strong> {$Plang['fe7998a68e0e5398']}</span>
                <script type="text/javascript">strLenCalc($('subject'), 'checklen', 80)</script>
            </div>
        </div>
        <textarea  id="editor_content" class="pt" style="display:none;">$contents[content]</textarea>
        <script id="editor" type="text/plain" class="wp" style="height:500px;"></script>
        <input name="edit_submit" id="edit_submit" type="submit" value="{$Plang['11cacc7842212fb0']}" class="save_changes" style="font-size:15px;"/>
        <input name="release_edit_submit" id="release_edit" type="submit" value="{$Plang['b76986eca32920f4']}" class="save_changes" style="font-size:15px;"/>
    </form>
</div>
<script type="text/javascript">

	var ue = UE.getEditor('editor');
	(function() {
		ue.ready(function() {
			ue.setHeight(500);
			ue.setContent(wqjq('#editor_content').val());
			wqjq('#edui1').css('z-index', '500');
		});
		wqjq('#edit_submit,#release_edit').click(function() {
			var content = ue.getContent();
			var subject = wqjq.trim(wqjq('#subject').val());
			if (subject == '') {
				showDialog('{$Plang['4ea318cd30bca9a2']}', '', '', '', '', '', '', '', '', 4);
				return false;
			} else if (content == '') {
				showDialog('{$Plang['d886d664b0c8a264']}>', '', '', '', '', '', '', '', '', 4);
				return false;
			} else {
				wqjq("#content").val(content);
				return true;
			}
		});
	})(wqjq);
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->