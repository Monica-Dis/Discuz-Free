<?php exit("Powered by www.wikin.cn"); ?>
<div class="wqpc_wechat_list">
	<!--{if !$list || count($list)<1}-->
	<div class="wqpc_emp">{$Plang['2dc3f83a42b3a77f']}</div>
	<!--{else}-->
    <ul>
        <!--{if $favorites_checkbox}-->
        <form method="post" action="plugin.php?id=wq_wechatreader&mod=ajax&ac=delarticle">
			<!--{/if}-->
			<!--{loop $list $key $val}-->
			<!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
            <li <!--{if $favorites_checkbox}-->class="wqpc_delfavorites"<!--{/if}-->>
                <!--{if $favorites_checkbox}-->
				<!--<input class="wqpc_input checks " type="checkbox" name="aids[]" value='{$val[articleid]}'>-->
				<span class="wqpc_input"><input type="checkbox" class="checks weui_check_z" name="aids[]" value='{$val[articleid]}' id="articleids[{$val[articleid]}]">
                    <label for="articleids[{$val[articleid]}]"><i class="wqwechat weui_icon_checked_z wq_f14"></i></label></span>
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="submitdel" value="true">
                <!--{/if}-->
                <a href="{$url}" id="articleurl_{$val[articleid]}" target="_blank">
                    <div class="wqpc_img wqlazydiv"><img id="imglink_{$val[articleid]}" wqdata-src="{$val[imglink]}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                    <div class="wqpc_con">
                        <h3 id="articletitle_{$val[articleid]}">{$val['title']}</h3>
                        <p class="wqpc_sum" id="summary_{$val[articleid]}">{$val['summary']}</p>
                    </div>
                </a>
                <div class="wqpc_info<!--{if (($_GET['id'] == 'wq_wechatreader' || $_GET['id'] == 'wq_wechatreader:wq_wechatreader') && ($_GET['ac'] == 'focus' || !$_GET['ac'])) }--> wqpc_info_xq<!--{/if}-->">
                    <!--{if !in_array($_GET['id'],array('wq_wechatshow','wq_wechatshow:wq_wechatshow')) && $_GET['mod'] != 'view'}-->
					<!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val['wechatid']; $getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
					<span class="wqpc_num_name"><a href="{$url}" target="_blank">{$val['name']}</a></span>
                    <!--{/if}-->
                    <span><!--{eval echo date('Y-m-d',$val[date])}--></span>
                    <span class="y wqpc_share article_share" id="$val[articleid]">
                        <a href="javascript:;"><i class="wqwechat wqwechat-fenxiang"></i>{$Plang['dae251a4f8687b1c']}
							<div class="article wqbdsharebuttonbox bdsharebuttonbox articleshared_{$val[articleid]} wqpc_share_warp" data-tag="share_1" style="display: none;" id="articleshared_29599">
								<a class="bds_tsina " data-cmd="tsina"></a>
								<a class="bds_qzone " data-cmd="qzone"></a>
								<a class="bds_weixin " data-cmd="weixin"></a>
								<a class="bds_sqq " data-cmd="sqq"></a>
								<a class="bds_tieba " data-cmd="tieba"></a>
								<a class="bds_more "  data-cmd="more"></a>
							</div>
                        </a>
                    </span>

                    <!--{if $plugin_wechatreader}-->
					<!--{if !$_G['uid']}-->
					<!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
					<!--{/if}-->
					<!--{if !in_array($val[articleid],$favorites)}-->
                            <span class="y wqpc_collection" id="aid_{$val[articleid]}">
						<a<!--{if !$logininfo}--> id="reader_favorites_{$val[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$val[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-favorite"></i>{$Plang['23393395a9152c6f']}</a>
					</span>
					<!--{else}-->
					<span class="y wqpc_collection" id="aid_{$val[articleid]}">
						<a<!--{if !$logininfo}--> id="reader_favorites_{$val[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid={$val[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-shoucang wqpc_yellow"></i>{$Plang['328bb3a07f442672']}</a>
					</span>
					<!--{/if}-->
                    <!--{/if}-->
                </div>
            </li>
			<!--{/loop}-->
			<!--{if $favorites_checkbox}-->
            <p class="wqpc_allinput" style="padding:10px;">
                <input type="checkbox" class="checks weui_check_z"  onclick="collecting_selectall()" id="coll_checkall"style='cursor:pointer;'>
                <label for="coll_checkall" onclick="collecting_selectall()"><i class="wqwechat weui_icon_checked_z wq_f14"></i>{$Plang['eeedad1838be051a']}</label>
                <button type="submit">{$Plang['387e9a577ee04ca3']}</button>
            </p>
		</form>
        <!--{/if}-->

    </ul>

	<!--{/if}-->
    <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
</div>
<script src="./source/plugin/wq_wechatcollecting/static/js/common.js?{VERHASH}" charset="{CHARSET}" type="text/javascript"></script>
<script id="sharebd"></script>
<script>
					var tem_plang = '{$Plang['328bb3a07f442672']}';
					var protocol = location.protocol
					var sharebd = {
						id: '',
						bdPic: '',
						bdText: '',
						bdDesc: '',
						url: '',
						bdUrl: ''
					}

					wqjq(document).on('mouseenter', ".article_share", function () {
						sharebd.id = wqjq(this).attr('id')
						sharebd.bdPic = "{$_G['siteurl']}" + wqjq("#imglink_" + sharebd.id).attr('src')
						sharebd.bdText = wqjq("#articletitle_" + sharebd.id).text()
						sharebd.bdDesc = wqjq("#summary_" + sharebd.id).text()
						sharebd.url = wqjq("#articleurl_" + sharebd.id).attr('href')
						if(sharebd.url.match(/^(http)/)) {
							sharebd.bdUrl = sharebd.url
						} else {
							sharebd.bdUrl = "{$_G['siteurl']}" + sharebd.url
						}
						window._bd_share_config = {
							common: {
								bdText: sharebd.bdText,
								bdDesc: sharebd.bdDesc,
								bdUrl: sharebd.bdUrl,
								bdPic: sharebd.bdPic,
								onBeforeClick: function (cmd, config) {
									return{
										bdText: sharebd.bdText,
										bdDesc: sharebd.bdDesc,
										bdUrl: sharebd.bdUrl,
										bdPic: sharebd.bdPic
									}
								}
							},
							share: [{
									"bdSize": 16
								}]
						}

						if(protocol == 'https:') {
							wqjq('#sharebd').prop('src', './source/plugin/wq_wechatcollecting/static/js/bdshare.js?{VERHASH}')
						} else {
							wqjq('#sharebd').prop('src', 'http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5))
						}
						for(var i = 0; i < wqjq(".articleshared_" + sharebd.id + " a").length; i++) {
							if(!wqjq(".articleshared_" + sharebd.id + " a").eq(i).prop('class')) {
								wqjq(".articleshared_" + sharebd.id + " a").eq(i).hide()
							}
						}
						wqjq(".articleshared_" + sharebd.id).show()
					});

					wqjq(document).on('mouseleave', '.article_share', function () {
						wqjq(".bdsharebuttonbox").hide()
					})

					function canclecollect(aid) {
						wqjq("#aid_" + aid + " a").replaceWith("<a id='reader_favorites_" + aid + "' href='plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid=" + aid + "' onclick='showWindow(this.id, this.href, \"get\", 0);'><i class='wqwechat wqwechat-favorite'></i>{$Plang['23393395a9152c6f']}</a>");
						if(typeof (del_articlelist_li) == 'function') {
							del_articlelist_li(aid);
						}
					}



</script>