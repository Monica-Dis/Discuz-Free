<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<script src="./source/plugin/wq_wechatcollecting/static/js/common.js?{VERHASH}" charset="{CHARSET}" type="text/javascript"></script>
<style>
    .wqpc_con_collect select{margin-left:20px; line-height: 30px;}
    .wqpc_con_collect textarea{margin-left:20px;}
</style>

<div class="wq_wechat_per">
    <div class="wq_wechat_per_list">
		<!--{template wq_wechatcollecting:cp_nav}-->
    </div>
    <div class="wq_wechat_per_con">
        <div class="wqpc_wechat_apply">
            <div class="wqpc_con">
                <form name="post" id="collect_form" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac" method="post">
                    <input type="hidden" value="true" name="urlcollect"/>
                    <input type="hidden" value="{FORMHASH}"name="formhash"/>
                    <table cellspacing="0" cellpadding="0" class="wq_tfm">
                        <tr>
                            <td class="wqpc_con_title">{$Plang['2406e61dbd843190']}:</td>
                            <td  class="wqpc_con_collect">
                                <textarea rows="5" name="collect_url" cols="60" class="tarea"></textarea>
                                <p class="wqpc_con_prompt">({$Plang['5e4571a5c7f2c14f']})</p>
                            </td>
                        </tr>
                        <tr class="wechat_class">
                            <td class="wqpc_con_title">{$Plang['57dca09a1285209b']}:</td>
                            <td  class="wqpc_con_collect">{$classselect}</td>
                        </tr>
                        <tr class="wechat_class">
                            <td class="wqpc_con_title">{$Plang['4135f6cd31b1a169']}:</td>
                            <td  class="wqpc_con_collect">
                                {$classselect_article}
								<p class="wqpc_con_prompt">({$Plang['16633f12625e7756']})</p>
                            </td>

                        </tr>
                        <tr>
                            <td class="wqpc_con_title">{$Plang['47094f52069c9b3e']}:</td>
                            <td  class="wqpc_con_collect">{$classselect_article_collect}</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <button type="submit" class="wqpc_wechat_tj wqm_left20" onclick="show_hint()" id="collect_submit"><strong id="collect_text">{lang submit}</strong></button>
                            </td>
                        </tr>
                    </table>
                    <div>
                        <b style="color:red;display:none;" id="collect_hint">{$Plang['d8a5be2f27f33ed5']}</b>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
	function show_hint() {
	wqjq('#collect_submit').parents('tr').before('<tr><th></th><td>{$Plang['0a8ebb3ac62ca372']}</td></tr>');
	wqjq('#collect_hint').show();
	wqjq('#collect_text').text('{$Plang['a3a1ebc1b1c71998']}');
	wqjq('#collect_form').submit();
	wqjq("#collect_submit").attr("disabled", "disabled");
	}
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->