<?php exit("Powered by www.wikin.cn"); ?>
<form style="display:none" id="subscription_collect" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add" method="post">
    <input type="hidden" value="true" name="searchsubmit"/>
    <input type="hidden" value="{FORMHASH}" name="formhash"/>
    <input type="hidden" name="keyword" value="{$keyword}"/>
    <input type="hidden" name="totalPages" value="{$next_page}" class="totalPages" />
    <input type="hidden" value="{$listcode}" name="listcode" class="listcode" />
</form>

<form  id="subscription_collect" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add" method="get">
    <input type="hidden" value="true" name="addsubmit"/>
    <input type="hidden" value="{$mymaintain}" name="mymaintain"/>
    <input type="hidden" value="{FORMHASH}" name="formhash"/>
    <input type="hidden" value="{$listcode}" name="listcode"/>
    <input type="hidden" value="{$keyword}" name="keyword"/>
     <!--{if $list}-->
    <div class="wq_wechat_apply_choice ">
            <ul class="wechatlist">
                <!--{loop $list $key $wechat}-->
                    <li class="wqwechat_bottom">
                        <div class="wqchoice_icon">
                            <input type="checkbox"  name="usernames[]" value="{$wechat['username']}" id="wqapply_choice{$key}" class="weui_check">
                            <label class="weui_check_label" for="wqapply_choice{$key}"><i class="weui_icon_checked"></i></label>
                        </div>
                        <div class="wq_img"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$wechat['qrcode']}" class="lazyload-home">
                            <!--{if $wechat['verify']}-->
                                <span class="wqattestation"></span>
                            <!--{/if}-->
                        </div>
                        <div class="wq_con">
                            <h3>{$wechat['name']}</h3>
                            <p class="wqweixin">{$wechat['username']}</p>
                            <!--{if $wechat['intro']}-->
                            <p class="wqintroduce">{$wechat['intro']}</p>
                            <!--{/if}-->
                        </div>
                    </li>
                <!--{/loop}-->
            </ul>
            <p class="wqwechat_more wqwechat_submit wqwechat_load" id="load_next_page">
                <a href="javascript:;"><!--{eval echo sprintf($Plang['98cf0d593c9a3348'],$keyword);}--></a>
            </p>
            <p class="wqwechat_more wqwechat_submit wqwechat_loading" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
            <p class="wqwechat_more wqwechat_submit wqwechat_end" style="display: none;"> <a href="javascript:;">{$Plang['b3f7b411f8a25701']}</a></p>
    </div>
     <div class="wqheight49"></div>
    <div class="wqwechat_num_subscription wqwechat_top">
        <div class="wq_subscription_warp">
         <span class="wq_subscription_select">
           <input type="checkbox" name="wqnumber_select" id="wqnumber_select" class="weui_check">
           <label class="weui_check_label" for="wqnumber_select"><i class=" weui_icon_checked"></i>{$Plang['677aa98daaedbce5']}</label>
           </span>
             <span class="wq_subscription_select_span">
                {$classselect}
            </span>
        </div>
        <div class="wqwechat_subscription_button"><button type="submit" class="wqformdialog" id="addsubmit" >{$Plang['2e53326577b64980']}</button></div>
    </div>
      <!--{else}-->
            <div class="wq_emp">
                {$Plang['eaab1b41e8a5809e']}
                {$Plang['a73dbebd08315850']}<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve">{$Plang['05ebc20b0cdd1c38']}</a>
            </div>
      <!--{/if}-->

 </form>