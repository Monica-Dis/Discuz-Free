<?php exit("Powered by www.wikin.cn"); ?>
{eval
function mobile_wechat_view_ajax_collect_returnhtml($list) {
    global $setting,$_G,$Plang,$plugin_wechatreader;
}
    <!--{if !$list}-->
    <!--{eval return '';}-->
    <!--{/if}-->
    <!--{block return}-->
        <li class="wqwechat_bottom">
            <!--{if $setting['view_mode'] == '2' && !empty($list['tid'])}-->
                <!--{eval $url="forum.php?mod=viewthread&tid=$list[tid]";}-->
            <!--{else}-->
                 <!--{eval $url="plugin.php?id=wq_wechatcollecting&mod=view&articleid=$list[articleid]";}-->
            <!--{/if}-->
            <!--{eval  $plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;}-->
            <!--{if $plugin_wechatshow}-->
                <!--{eval
                    $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $list['wechatid'];
                    $wechaturl = 'plugin.php?'.url_implode($getlist);
                }-->
            <!--{else}-->
                <!--{eval $wechaturl = 'javascript:;'; }-->
            <!--{/if}-->
            <div class="wq_img wqlazydiv">
                <a href="{$url}"><img wqdata-src="{$list[imglink]}" class="lazyload-home" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg"></a>
            </div>
            <div class="wq_con">
                <h3><a href="{$url}">{$list['title']}</a></h3>
                <p class="wq_f12">
                    <a href="{$wechaturl}" class="wq_num wqellipsis">{$list['name']}</a>
                        <a href="javascript:;" class="wqy wqwoperation" data="{$list[articleid]}">
                            <img src="./source/plugin/wq_wechatcollecting/static/images/wq_down.png">
                        </a>
                        <span class="wqy wqtime">$date</span>
                        <span class="wqwoperation_down wqwoperation_down_show_hide" id="wqwoperation_down_{$list[articleid]}" style="display: none">
                            <span></span>
                             <!--{if $plugin_wechatshow}-->
                                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$list['articleid']}">
                                    <i class="wqwechat wqwechat-favorite"></i>{$Plang['23393395a9152c6f']}
                                </a>
                            <!--{/if}-->
                             <a href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articlesupport&aid={$list[articleid]}&handlekey=wqc_listsupport" class="wq_line wqwechat_left_black wqdialog">
                                 <i class="wqwechat wqwechat-comiiszan"></i>
                                 {$Plang['4d3aee3cefdbf4b8']}
                             </a>
                        </span>
                </p>
            </div>
        </li>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
}