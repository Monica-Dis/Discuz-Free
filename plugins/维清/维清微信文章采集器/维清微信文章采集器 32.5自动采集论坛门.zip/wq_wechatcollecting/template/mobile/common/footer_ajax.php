<?php exit("Powered by www.wikin.cn"); ?>
<!--{echo output_ajax()}-->]]></root><!--{eval exit;}-->