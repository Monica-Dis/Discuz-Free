<?php exit("Powered by www.wikin.cn"); ?>
<!--{hook/global_footer_mobile}-->
<div class="wqwechat_mask wqc_wqwechat_mask" style="top: 0; display: none; cursor:pointer; -webkit-tap-highlight-color:transparent;"></div>
<div class="wqwechat_dialog wqc_wqwechat_dialog" style="top: 36%;display:none;">
    <h3 class="wqwechat_dialogh3">{$Plang['5010aeb9fc65e2a6']}</h3>
    <div class="wqwechat_dialog_btn wqwechat_top">
        <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask",".wqc_wqwechat_dialog")'>{$Plang['9c825be7149e5b97']}</a>

        <a href="javascript:history.go(-1);" class="wqwechat_determine" >{$Plang['387e9a577ee04ca3']}</a>
    </div>
</div>
<div style="display: none;"><!--{if $_G['setting']['statcode']}-->{$_G['setting']['statcode']}<!--{/if}--></div>
<div id="mask" style="display:none;"></div>
        <!--{if (($_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting') && ($_GET['mod']=='index' || $_GET['mod']=='list' || !$_GET['mod'])) || (($_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow') && ($_GET['mod']=='list' || !$_GET['mod'])) || (($_GET['id']=='wq_wechatreader' || $_GET['id']=='wq_wechatreader:wq_wechatreader') && ($_GET['mod']=='index'|| !$_GET['mod']) && ($_GET['ac']=='focus' || !$_GET['ac'] || $_GET['ac']==''))}-->
        <!--<div class="wqheight49"></div>-->
        <!--{if !$plugin_wechatreader && !$plugin_wechatshow}-->
            <!--{eval $class_footer ="wqwechat_footer_two"}-->
        <!--{elseif $plugin_wechatreader && $plugin_wechatshow}-->
            <!--{eval $class_footer =""}-->
        <!--{elseif $plugin_wechatreader || $plugin_wechatshow}-->
            <!--{eval $class_footer ="wqwechat_footer_san"}-->
        <!--{/if}-->

        <footer class="wq_wechat_footer wqwechat_top wq_f12 {$class_footer}">
            <ul>
                <!--{eval $shouye=($_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting') && ($_GET['mod']=='index'|| !$_GET['mod'] || $_GET['mod']='list');}-->
                <li><a href="./plugin.php?id=wq_wechatcollecting" <!--{if $shouye}--> class="on"<!--{/if}-->><i class="wqwechat wqwechat-shouye<!--{if $shouye}-->2<!--{/if}--> wq_f22"></i><br/>{$Plang['83f1e7a6a15f1d8a']}</a></li>
            <!--{if $plugin_wechatshow}-->
                <!--{eval $gongzhonghao=($_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow') && ($_GET['mod']=='list'|| !$_GET['mod']);}-->
                <li><a href="./plugin.php?id=wq_wechatshow:wq_wechatshow" <!--{if $gongzhonghao}--> class="on"<!--{/if}-->><i class="wqwechat wqwechat-gongzhonghao<!--{if $gongzhonghao}-->2<!--{/if}--> wq_f24"></i><br/>{$Plang['f8497259f9b3f761']}</a></li>
            <!--{/if}-->
                <!--{eval $fjiahao=($_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting') && $_GET['mod']=='cp';}-->
                <li><a href="./plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add"><i class="wqwechat wqwechat-fjiahao<!--{if $fjiahao}-->2<!--{/if}--> wq_f22"></i><br/>{$Plang['2e53326577b64980']}</a></li>
            <!--{if $plugin_wechatreader && $plugin_wechatshow}-->
                <!--{eval $xingquaihao=($_GET['id']=='wq_wechatreader' || $_GET['id']=='wq_wechatreader:wq_wechatreader') && ($_GET['mod']=='index'|| !$_GET['mod']) && $_GET['ac']=='focus';}-->
                <li><a href="./plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first" <!--{if $xingquaihao}--> class="on"<!--{/if}-->><i class="wqwechat wqwechat-xingquaihao<!--{if $xingquaihao}-->2<!--{/if}--> wq_f22"></i><br/>{$Plang['2c8a07313e7706bc']}</a></li>
            <!--{/if}-->
            <!--{if $plugin_wechatreader}-->
                <!--{eval $wode=($_GET['id']=='wq_wechatreader' || $_GET['id']=='wq_wechatreader:wq_wechatreader') && ($_GET['mod']=='index'|| !$_GET['mod']) && (!$_GET['ac'] || $_GET['ac']=='');}-->
                <li><a href="./plugin.php?id=wq_wechatreader&mod=index" <!--{if $wode}--> class="on"<!--{/if}-->><i class="wqwechat wqwechat-wode<!--{if $wode}-->2<!--{/if}--> wq_f22"></i><br/>{$Plang['ca286fd27b769665']}</a></li>
            <!--{/if}-->
            </ul>
        </footer>
        <!--{/if}-->
        <script>
            if (window.devicePixelRatio && devicePixelRatio >= 2 && navigator.userAgent.toLowerCase().match(/iphone/i) == "iphone") {
                document.getElementsByTagName('html')[0].className = 'retina';
            }
            var formhash = "{FORMHASH}";
        </script>
    </body>
        <script src="./source/plugin/wq_wechatcollecting/static/js/video.js?{VERHASH}" type="text/javascript"></script>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
<!--{eval output();}-->
<!--{else}-->
<!--{eval output_preview();}-->
<!--{/if}-->