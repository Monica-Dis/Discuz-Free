<?php exit("Powered by www.wikin.cn"); ?>
<div class="wqwechat_warp">
    <div class="my_wechat_roll" id="my_post_roll">
       <div class="tag_list" id="tag_list">
           <ul>
                <li>
                    <a href="plugin.php?id=wq_wechatcollecting"<!--{if !$classid}--> class="on"<!--{/if}-->>
                       {$Plang['8dfe4b30674494c1']}
                    </a>
                </li>
                <!--{loop $wechatclass_article $key $val}-->
                    <!--{eval
                        $classlist = array(); $classlist[id] = 'wq_wechatcollecting'; $classlist[mod] = 'list'; $classlist[classid] = $key;
                        $classurl = 'plugin.php?'.url_implode($classlist);
                    }-->
                    <!--{if $val['linkurl']}-->
                        <li><a href={$val['linkurl']}}>{$val['classname']}</a></li>
                    <!--{else}-->
                        <li><a <!--{if $classid==$key}--> class="on"<!--{/if}--> href="{$classurl}">{$val['classname']}</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
           </ul>
       </div>
        <span></span>
   </div>
    <span class="wq_arrow">
        <a href="javascript:;">
            <i class="wqwechat wqwechat-jiantou01 wq_f20"></i>
        </a>
    </span>


    <div class="wqwechat_drop_down" style=" display: none;" id='wqwechat_drop_down'>
        <ul>
            <li>
                <a href="plugin.php?id=wq_wechatcollecting"<!--{if !$classid}--> class="on"<!--{/if}-->>
                   {$Plang['8dfe4b30674494c1']}
                </a>
            </li>
            <!--{loop $wechatclass_article $key $val}-->
                <!--{eval
                    $classlist = array(); $classlist[id] = 'wq_wechatcollecting'; $classlist[mod] = 'list'; $classlist[classid] = $key;
                    $classurl = 'plugin.php?'.url_implode($classlist);
                }-->
                <!--{if $val['linkurl']}-->
                    <li><a href={$val['linkurl']}}>{$val['classname']}</a></li>
                <!--{else}-->
                    <li><a <!--{if $classid==$key}--> class="on"<!--{/if}--> href="{$classurl}">{$val['classname']}</a></li>
                <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
 <!--{eval
    $getlist = array(); $getlist[id] = "wq_wechatcollecting";
    $getlist[mod] = 'list'; $getlist[classid] = $classid;$getlist[displayorder] = 1;
    $url = 'plugin.php?'.url_implode($getlist);
 }-->

<div class="wqwechat_warp_er wqwechat_bottom">
    <ul>
        <!--{if $list_recommedlist}-->
            <!--{eval $getlist[displayorder]=3; $url = 'plugin.php?'.url_implode($getlist);}-->
            <li><a href="{$url}" <!--{if $ordernum == 3}--> class="on"<!--{/if}-->>{$Plang['db11cdebc2eb37bd']}</a><span>/</span></li>
        <!--{/if}-->
        <!--{if  $list_firstlist}-->
        <!--{eval $firsturl = "plugin.php?id=wq_wechatcollecting&mod=list&displayorder=4";$firsturl .= $classid ? '&classid='.$classid : '';}-->
            <li><a href="{$firsturl}" <!--{if $ordernum == 4}--> class="on"<!--{/if}-->>{$Plang['0ef1d1c8298846ea']}</a><span>/</span></li>
        <!--{/if}-->
        <!--{eval $getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
        <li><a href="{$url}" <!--{if $ordernum == 1}--> class="on"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a><span>/</span></li>
        <!--{eval $getlist[displayorder] = 2; $url = 'plugin.php?'.url_implode($getlist);}-->
        <li><a href="{$url}" <!--{if $ordernum == 2}--> class="on"<!--{/if}-->>{$Plang['6959da5d2e80c069']}</a></li>
    </ul>
</div>
<script>
    $(".wqwechat_warp .wq_arrow a").click(function(){
        if($("#wqwechat_drop_down").is(":hidden")){
            $("#wqwechat_drop_down").show();
            $(".wqwechat_warp .wq_arrow a i").attr('class','wqwechat wqwechat-shangjiantou wq_f20');
            $('.wqwechat_warp_er').css('visibility', 'hidden');
        }else{
            $("#wqwechat_drop_down").hide();
            $(".wqwechat_warp .wq_arrow a i").attr('class','wqwechat wqwechat-jiantou01 wq_f20');
            $('.wqwechat_warp_er').show();
            $('.wqwechat_warp_er').css('visibility', 'visible');
        }
    });
    var wq_window_width = $(window).width();
    var tag_width = 1;
    for (var i = 0; i < $('#tag_list li').length; i++) {
        tag_width += $('#tag_list li').eq(i).width() + 10;
    }
    $('#tag_list').width(tag_width);
    $('#my_post_roll').css('width', wq_window_width - 44);
    if (tag_width > wq_window_width - 44) {
        var myscroll_my_post_roll= new iScroll('my_post_roll', {
            hScrollbar: false,
            vScroll: false,
            bounce: true
        });
        var wq_my_post_roll = $('#my_post_roll .on').offset().left
        if (wq_my_post_roll > (wq_window_width - 44) / 2) {
            var scrollTo_left = wq_my_post_roll - ((wq_window_width - 44) / 2)
            var wq_left = tag_width - (wq_window_width - 44)
            var scrollleft = wq_left < scrollTo_left ? wq_left : scrollTo_left
            myscroll_my_post_roll.scrollTo(-scrollleft, 0, 1500)
        }
    }
    $(document).on('scroll', function () {
        if ($(document).scrollTop() > 44) {
            $('.wqwechat_warp').addClass('wqwechat_warp_fixed')
            $('.wqwechat_warp_er').addClass('wqwechat_warp_er_fixed')
            $('.wqscroll_lb').css('margin-top', '80px')
        } else {
            $('.wqwechat_warp').removeClass('wqwechat_warp_fixed')
            $('.wqwechat_warp_er').removeClass('wqwechat_warp_er_fixed')
            $('.wqscroll_lb').css('margin-top', '0')
        }
    })
</script>