<?php exit("Powered by www.wikin.cn"); ?>
<style>
    body{ background: #f9f9f9;}
</style>
<div class="wq_wechat_seaech wqwechat_bottom">
    <div class="wq_wechat_seaech_warp wqwechat_all">
          <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
          <i class="wqwechat wqwechat-iconfontsousuo1 wqsearch_icon"></i>
          <form method="get">
              <input type="hidden" name="id" value="{$plugin}">
              <input type="hidden" name="mod" value="search">
              <input type="hidden" name="formhash" value="{FORMHASH}">
              <input type="text" name="keyword" value='$keyword' placeholder="{$Plang['7e28a207fdf6c483']}">
              <button>{$Plang['38224a4a6fc78c7c']}</button>
          </form>
    </div>
</div>
<div class="wqheight44"></div>
<!--{if empty($keyword) && ($a_searchset['status'] || $w_searchset['status'])}-->
    <div class="wqwechat_hotwords">
        <!--{if $setkeyword}-->
        <h3>{$Plang['6043b7672fed8033']}</h3>
            <ul>
                <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
                <!--{loop $setkeyword $key $val}-->
                <li><a href="plugin.php?id=$identifier&mod=search&keyword={$val}">{$val}</a></li>
                <!--{/loop}-->
            </ul>
        <!--{/if}-->
    </div>
<!--{/if}-->