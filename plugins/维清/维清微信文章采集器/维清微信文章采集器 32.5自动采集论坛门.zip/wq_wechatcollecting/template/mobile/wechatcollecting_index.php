<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval echo wq_get_wq_ad_info('wq_wechatcollecting_header');}-->
<!--{template wq_wechatcollecting:common/header}-->
        <!--{subtemplate wq_wechatcollecting:common/classlist}-->
    <div id="wqscroll" class="wqscroll_lb" style="visibility: visible;">
        <!--{block/1n}-->
    </div>
    <div class="wqwechat_list pulldown_load_js" page="$page" count="$count" perpage="$perpage"  maxpage="$setting[home_maxpage]">
        <!--{if $list}-->
            <ul class="wqchatlist">
                <!--{subtemplate wq_wechatcollecting:common/list}-->
            </ul>
        <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
        <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;">{$Plang['b3f7b411f8a25701']}</p>
        <!--{else}-->
        <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['2dc3f83a42b3a77f']}</p>
        <!--{/if}-->
    </div>
    <script>
        var elem = document.getElementById('wqscroll');
        window.wqscroll = Swipe(elem, {
            auto: 3000,
            continuous: true,
            callback: function (pos) {
                var i = bullets.length;
                if (i == 2 && pos > 1) {
                    pos = pos - 2
                }
                while (i--) {
                    bullets[i].className = ' ';
                }
                bullets[pos].className = 'on';
            }
        });
        var bullets = document.getElementById('wqscroll_con').getElementsByTagName('li');
    </script>
<!--{eval echo wq_get_wq_ad_info('wq_wechatcollecting_footer');}-->
<!--{template wq_wechatcollecting:common/footer}-->