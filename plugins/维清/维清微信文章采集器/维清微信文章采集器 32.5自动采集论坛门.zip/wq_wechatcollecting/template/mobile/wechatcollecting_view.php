<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval echo wq_get_wq_ad_info('wq_wechatcollectint_view_header');}-->
<!--{template wq_wechatcollecting:common/header}-->
        <div class="wqwechat_articleview">
            <h3 class="wq_title">{$webpagename}</h3>
            <!--{if $plugin_wechatshow}-->
                <!--{eval
                    $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $content['wechatid']; $getlist[displayorder] = 'index';
                    $wechaturl = 'plugin.php?'.url_implode($getlist);
                }-->
            <!--{else}-->
                <!--{eval  $wechaturl = 'javascript:;'; }-->
            <!--{/if}-->
            <p class="wq_info">{$date}
                <a href="{$wechaturl}">{$content['name']}</a>
                <!--{if $setting['show_my_attention']}-->
                    <a href="javascript:;"class="wqfollow" onclick="wq_wechatcollecting_cancel('.wqfollow_code','.wqfollow_code_guan')">{$Plang['0b8a086e7cfb0be8']}</a>
                <!--{/if}-->
            </p>
            <div class="wqwechat_articleview_con">
                {$content['content']}
            </div>
            {$wqreward_but}
            <div class="wq_see" id="wqc_support_num">{$Plang['a6aa5366e09f370c']}{$content['views']}
                <a href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articlesupport&aid={$content[articleid]}&handlekey=wqc_support" id="a_support" class="wqdialog <!--{if in_array($content[articleid],$articlesupport)}-->on<!--{/if}-->">
                   <i class="wqwechat wqwechat-comiiszan" ></i><span id="wqc_support_num">{$content[support]}</span>
                </a>
                <a href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articleagainst&aid={$content[articleid]}&handlekey=wqc_support" id="a_against" class="wqdialog <!--{if in_array($content[articleid],$articleagainst)}-->on<!--{/if}-->">
                   <i class="wqwechat wqwechat-diancai wq_f15"></i><span id="wqc_against_num">{$content[against]}</span>
                </a>
            </div>
            <div class="view_up_down">
                <!--{if $lastaid}-->
                <p><a href="plugin.php?id=wq_wechatcollecting&mod=view&articleid={$lastaid[articleid]}">{$Plang['8dccd8233557b4aa']}{$lastaid['title']}</a></p>
                <!--{/if}-->
                <!--{if $nextaid}-->
                <p><a href="plugin.php?id=wq_wechatcollecting&mod=view&articleid={$nextaid[articleid]}">{$Plang['7e2890e74680b8e9']}{$nextaid['title']}</a></p>
                <!--{/if}-->
            </div>
        </div>
        <!--{eval echo wq_get_wq_ad_info('wq_wechatcollectint_view_footer');}-->
        <!--{if $right_recommedlist}-->
            <div class="wqwechat_separate"></div>
            <div class="wqwechat_recommend">
                <h3 class="wq_title">{$Plang['ebdb17b9fa566a2d']}</h3>
                <ul>
                    <!--{loop $right_recommedlist $key $val}-->
                        <!--{eval
                            $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid];
                            $url = 'plugin.php?'.url_implode($getlist);
                        }-->
                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <li class="wqwechat_bottom">
                            <a href="{$url}">
                                <div class="wq_img"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home"></div>
                                <div class="wq_con">
                                    <h3>{$val[name]}</h3>
                                    <p>{$val[intro]}</p>
                                </div>
                            </a>
                        </li>
                    <!--{/loop}-->
                </ul>
            </div>
        <!--{/if}-->

        <!--{if $right_hot}-->
            <div class="wqwechat_separate"></div>
            <div class="wqwechat_hot">
                <h3 class="wq_title">{$Plang['cd28d8e22cbacebe']}</h3>
                <ul>
                    <!--{loop $right_hot $key $val}-->
                        <li class="wqwechat_bottom">
                            <a href="plugin.php?id=wq_wechatcollecting&mod=view&articleid={$val[articleid]}">
                                <p class="wq_img wqlazydiv"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$val[imglink]}" class="lazyload-home"></p>
                                <p class="wq_con">{$val[title]}</p>
                            </a>
                        </li>
                    <!--{/loop}-->
                </ul>
            </div>
        <!--{/if}-->

        <div class="wqheight49"></div>
        <div class="wqwechat_viewoperation <!--{if !$plugin_wechatreader}-->wqwechat_viewoperation_33<!--{/if}--> wqwechat_top">
            <ul>
                <li>
                    <!--{eval $referer = dreferer();}-->
                    <!--{eval preg_match("/plugin.php/i", $referer, $matches)}-->
                    <!--{if $matches}-->
                       <!--{eval $backurl="javascript:history.go(-1);";}-->
                    <!--{else}-->
                        <!--{eval $backurl="plugin.php?id=wq_wechatcollecting";}-->
                    <!--{/if}-->
                    <a href="javascript:">
                        <i class="wqwechat wqwechat-fanhui-copy" style="vertical-align: text-top;"></i>
                    </a>
                </li>
                <li>
                    <a href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articlesupport&aid={$content[articleid]}&handlekey=wqc_support" id="wqc_support" class="wqdialog" >
                        <i class="wqwechat wqwechat-comiiszan wq_f20 <!--{if in_array($content[articleid],$articlesupport)}-->wqyellow wqwechat-zan2<!--{elseif in_array($content[articleid],$articleagainst)}-->wqyellow  wqwechat-cai<!--{/if}-->"></i>
                    </a>
                </li>
                <!--{if $plugin_wechatreader}-->
                    <!--{if !in_array($content[articleid],$favorites)}-->
                        <li>
                            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$content['articleid']}">
                                <i class="wqwechat wqwechat-favorite wq_f20"></i>
                            </a>
                        </li>
                    <!--{else}-->
                        <li>
                            <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid={$content[articleid]}&handlekey=wqcanclecollect" id="wqcanclecollect" class="wqdialog">
                                <i class="wqwechat wqwechat-shoucang wq_f20 wqyellow"></i>
                            </a>
                        </li>
                    <!--{/if}-->
                <!--{/if}-->
                <li><a href="javascript:;"><i class="wqwechat wqwechat-picfenxiang wq_f20"></i></a></li>
            </ul>
        </div>
        <div class="wqpc_wechat_share" style="display:none;">
            <div id="nativeShare"></div>
            <div class="wqsharecancel">{$Plang['9c825be7149e5b97']}</div>
        </div>
        <div class="wqshare_qq"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/share_bg.png" /></div>
        <div class="wqshare_2345"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/share_browser_z.png" /></div>
        <div class="wqshare_baidu"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/share_browser_y.png" /></div>
        <div class="wqshare_baiduBox"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/share_browser_zy.png" /></div>
         <div class="wqwechat_mask  wqfollow_code_guan" style='display: none;' onclick="wq_wechatcollecting_cancel('.wqfollow_code','.wqfollow_code_guan')"></div>
    <!--{if $setting['show_my_attention']}-->
        <div class="wqfollow_code" style='display: none;'>
            <div class="wqfollow_code_div">
            <p><img src="{$wechat['qrcode']}"></p>

            <p> <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false}-->
                {$Plang['c2f77tgyjtrytry5']}
                <!--{/if}-->
                {$Plang['c2f77284c686cc65']}<span>{$wechat[name]}</span>"
            </p>
            </div>
        </div>
    <!--{/if}-->
<style>
    .wqwechat_articleview_con * { max-width: 100% !important; padding: 0 !important;overflow: hidden;}
    .wqwechat_articleview_con pre { white-space: normal !important; }
</style>
<script src="./source/plugin/wq_wechatcollecting/static/mobile/js/nativeShare.js" charset="gbk" ></script>
<script type="text/javascript">
    $(function(){
        $(".wqwechat_articleview_con *").css("margin-top",0).css("margin-bottom",0)
    })
    function errorhandle_wqc_support(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['289f61f54d327553']}"){
            if(param.ac =='articlesupport'){
                $("#wqc_support i").addClass('wqyellow wqwechat-zan2');
                $("#a_support").addClass('on');
                var support_num = parseInt($("#a_support span").html())+1;
                $("#a_support span").html(support_num);
            }
            if(param.ac =='articleagainst'){
                $("#wqc_support i").addClass('wqyellow  wqwechat-cai');
                $("#a_against").addClass('on');
                var support_num = parseInt($("#a_against span").html())+1;
                $("#a_against span").html(support_num);
            }
        }
    }

    function errorhandle_wqcanclecollect(msg,param){
        if(msg=="{$Plang['bef022f6310db3b9']}"){
            $("#wqcanclecollect").replaceWith("<a href=\"plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid="+ param.aid+"\"><i class=\"wqwechat wqwechat-favorite wq_f20\"></i></a>");
        }
    }
    var m_ua = navigator.appVersion;
    var mbrowser = {
        isUC: /UCBrowser/.test(m_ua),
        isBaiduBox: /baiduboxapp\//.test(m_ua),
        isBaiduBrowser: /baidubrowser\//.test(m_ua),
        isQQ: /QQ\//.test(m_ua),
        isQQBrowser: ! /QQ\//.test(m_ua) && /MQQBrowser/.test(m_ua),
        isWX: /MicroMessenger/.test(m_ua),
        isLieBao: /LieBaoFast/.test(m_ua),
        is2345: /Mb2345Browser/.test(m_ua),
        isSogou: /SogouMobileBrowser/.test(m_ua),
        isOpera: /OPR\//.test(m_ua)
    };
    if (mbrowser.isUC) {
        var config = {
            url: location.href,
            title:'',
            desc:'',
            img:'',
            img_title:'',
            from:''
        };
        var share_obj = new nativeShare('nativeShare',config);
        $('body').on('click', '#mask', function () {
            $('.wqshare').slideUp(200);
            $('.wqc_wqwechat_mask').hide();
        })
        $('.wqsharecancel').click(function () {
            $('.wqpc_wechat_share').slideUp(200);
            $('.wqc_wqwechat_mask').hide();
        });
    }
    $('.wqwechat.wqwechat-picfenxiang.wq_f20').on('click', function () {
        if (mbrowser.isUC) {
            $('.wqpc_wechat_share').slideToggle(200);
            $('.wqc_wqwechat_mask').show();
        } else if (mbrowser.isQQ || mbrowser.isWX) {
            $('.wqwechat_mask').css({'opacity': '0.95'});
            $('.wqc_wqwechat_mask, .wqshare_qq').show();
        } else if (mbrowser.isQQBrowser || mbrowser.is2345) {
            $('.wqwechat_mask').css({ 'opacity': '0.95'});
            $('.wqc_wqwechat_mask, .wqshare_2345').show();
        } else if (mbrowser.isBaiduBrowser || mbrowser.isLieBao) {
            $('.wqwechat_mask').css({ 'opacity': '0.95'});
            $('.wqc_wqwechat_mask, .wqshare_baidu').show();
        } else if (mbrowser.isBaiduBox || mbrowser.isSogou || mbrowser.isOpera) {
            $('.wqwechat_mask').css({'opacity': '0.95'});
            $('.wqc_wqwechat_mask, .wqshare_baiduBox').show();
        } else {
            alert('{$Plang[ed9ab9e34961b014]}');
        }
    });
    $('body').on('click', '.wqc_wqwechat_mask, .wqshare_qq, .wqshare_2345, .wqshare_baidu, .wqshare_baiduBox', function () {
        $('.wqc_wqwechat_mask, .wqshare_qq, .wqshare_2345, .wqshare_baidu,  .wqshare_baiduBox, .wqpc_wechat_share').hide();
        $('.wqwechat_mask').css({ 'opacity': '0.4'});
    });
    $('body').on('touchmove', '.wqc_wqwechat_mask, .wqshare_qq, .wqshare_2345, .wqshare_baidu, .wqshare_baiduBox', function (e) {
        e.preventDefault();
    });
    $('.wqwechat_articleview_con img').css({'width': 'auto', 'height': 'auto'});
    $('.wqwechat-fanhui-copy').parent().on('click', function () {
        document.referrer === '' ? location.href = 'plugin.php?id=wq_wechatcollecting&mod=index' : history.go(-1);
    });
</script>
<!--{template wq_wechatcollecting:common/footer}-->