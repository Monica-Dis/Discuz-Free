<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['inajax']}-->
<input type="hidden" name="totalPages" value="{$next_page}" class="totalPages" />
<input type="hidden" value="{$listcode}" name="listcode" class="listcode" />
    <!--{loop $list $key $wechat}-->
        <li class="wqwechat_bottom">
            <div class="wqchoice_icon">
                <input type="checkbox"  name="usernames[]" value="{$wechat['username']}" id="wqapply_choice{$key}" class="weui_check">
                <label class="weui_check_label" for="wqapply_choice{$key}"><i class="weui_icon_checked"></i></label>
            </div>
            <div class="wq_img"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$wechat['qrcode']}" class="lazyload-home">
                <!--{if $wechat['verify']}-->
                    <span class="wqattestation"></span>
                <!--{/if}-->
            </div>
            <div class="wq_con">
                <h3>{$wechat['name']}</h3>
                <p class="wqweixin">{$wechat['username']}</p>
                <!--{if $wechat['intro']}-->
                <p class="wqintroduce">{$wechat['intro']}</p>
                <!--{/if}-->
            </div>
        </li>
    <!--{/loop}-->
    <!--{eval exit();}-->
<!--{/if}-->


<!--{template wq_wechatcollecting:common/header}-->
 <!--{if $_GET['meun'] != 'my_submit'}-->
    <div class="wq_wechat_apply wqwechat_bottom">
        <div class="wq_wechat_apply_warp ">
            <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
            <ul>

                    <li><a href="./plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add" <!--{if $_GET['op']='add'&& $_GET['wechat']!== 'serve'}-->class="on"<!--{/if}-->>{$Plang['3a26e95308b35535']}</a></li>
                    <!--{if !empty($plugin)}-->
                    <li><a href="./plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add&wechat=serve" <!--{if $_GET['op']='add'&& $_GET['wechat'] == 'serve'}-->class="on"<!--{/if}-->>{$Plang['dbca9db832d7d5f4']}</a></li>
                <!--{/if}-->
            </ul>
        </div>
    </div>
 <!--{else}-->
 <div class="wqwechat_perheader wqwechat_bottom">
            <div class="wqwechat_perheader_warp">
                <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
                <a href="javascript:;">{$Plang['dde343556ea0716c']}</a>
          </div>

        </div>
<!--   <a href="javascript:;" class="on"></a>-->
 <!--{/if}-->
    <div class="wqheight44"></div>
    <!--{eval $classselect = get_class_select('classid', $wechatclass, $_GET['classid'], $Plang['57dca09a1285209b']);}-->
    <!--{if $step == '1'}-->
        <!--{if $_GET['wechat'] == 'serve' && !empty($plugin)}-->
            <!--{template wq_wechatshow:cp_wechatmanage_serve}-->
        <!--{else}-->
            <form method="post" autocomplete="off" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add">
                <div><input type="hidden" name="searchsubmit" value="yes">
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <div class="wq_wechat_apply_list">
                    <ul>
                        <li class="wqwechat_bottom"><span>{$Plang['29c5793e392feabe']}</span><input autocomplete="off" type="text" value="" name='keyword' placeholder="{$Plang['6ecfb4f5d9bd1af3']}"></li>
                        <li class="wqwechat_bottom">
                            <span>{$Plang['8236ff6b5203e4f5']}</span>
                            <select name="totalPages" class="wqpost_select">
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4" >4</option>
                                  <option value="5" >5</option>
                                  <option value="6" >6</option>
                                  <option value="7" >7</option>
                                  <option value="8" >8</option>
                                  <option value="9" >9</option>
                                  <option value="10" >10</option>
                            </select>
                        </li>
                    </ul>
                </div>
                <div class="wqheight49"></div>
                <div class="wqwechat_num_view_follow wqwechat_top"><div class="wqwechat_num_view_follow_div"><button type="submit">{$Plang['38224a4a6fc78c7c']}</button></div></div>
            </form>
        <!--{/if}-->
    <!--{elseif $step == '2'}-->
        <!--{template wq_wechatcollecting:cp_wechatmanage_result}-->
    <!--{elseif $_GET['meun'] == 'my_submit'}-->
        <div class="wqwechat_numfollow">
            <!--{if $list}-->
                <ul>
                    <!--{loop $list $key $val}-->
                        <!--{eval
                            $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist['displayorder'] = 'index';
                            $url = 'plugin.php?'.url_implode($getlist);
                        }-->
                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                        <li class="wqwechat_bottom_right">
                            <div class="wq_warp">
                            <div class="wq_img"><a href="{$url}"><img src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home"></a></div>
                            <div class="wq_con">
                                <h3><a href="{$url}">{$val['name']}</a></h3>
                                <!--{if in_array($val['id'],$subscription)}-->
                                    <p>
                                        <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}&handlekey=attention" class="wqdialog wqattention_{$val[id]}">
                                            <span>-</span> {$Plang['2c8a07313e7706bc']}
                                        </a>
                                    </p>
                                <!--{else}-->
                                    <p>
                                        <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}&handlekey=attention" class="wqdialog wqattention_{$val[id]}">
                                            <span>+</span> {$Plang['2c8a07313e7706bc']}
                                        </a>
                                    </p>
                                <!--{/if}-->
                            </div>
                            </div>
                        </li>
                    <!--{/loop}-->
                </ul>
            <!--{else}-->
            <p class="wq_emp"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['3cey354g65tg4668']}<br /><span><a href="./plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add" >{$Plang['tgergvfdgterergg']}</a></span></p>
            <!--{/if}-->
        </div>
        <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
        <script>
            function errorhandle_attention(msg,param){
                if(wq_wechat_trim(msg)=="{$Plang['bef022f6310db3b9']}"){
                    $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid='+param.wid+'&handlekey=attention');
                    $(".wqattention_"+param.wid+" span:first-child").html("+");
                }
                if(wq_wechat_trim(msg)=="{$Plang['61d615dc397796b8']}"){
                    $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid='+param.wid+'&handlekey=attention');
                    $(".wqattention_"+param.wid+" span:first-child").html("-");
                }
            }
        </script>
    <!--{/if}-->
<!--{template wq_wechatcollecting:common/footer}-->