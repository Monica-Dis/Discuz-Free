<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/header}-->
    <!--{template wq_wechatcollecting:common/search}-->
    <!--{if $keyword}-->
        <!--{if $a_searchset['status'] && $w_searchset['status']}-->
            <div class="wq_wechat_seaech_menu wqwechat_bottom">
                <a href="plugin.php?id=wq_wechatcollecting&mod=search&keyword={$keyword}&searchid={$searchid}" class="on"><span class="wqwechat_bottom_bule"></span>{$Plang['815a1f2328d92c06']}({$count})</a>
                <a href="plugin.php?id=wq_wechatshow&mod=search&keyword={$keyword}">{$Plang['29c5793e392feabe']}</a>
            </div>
        <!--{/if}-->
        <div class="wqwechat_list pulldown_load_js" page="$page" count="$count" perpage="$perpage">
            <!--{if $list}-->
                <ul class="wqchatlist">
                    <!--{subtemplate wq_wechatcollecting:common/list}-->
                </ul>
            <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
            <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;">{$Plang['b3f7b411f8a25701']}</p>
            <!--{else}-->
            <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['2dc3f83a42b3a77f']}</p>
            <!--{/if}-->
        </div>

        <div class="wqheight49"></div>
        <!--{if !empty($list) && $plugin_wechatreader==1}-->
            <!--{if $status==1}-->
            <div class="wqwechat_subscribe_btn wqwechat_top"><a href="javascript:;">{$Plang['dbb4e378b0511ad5']}</a></div>
            <!--{else}-->
                <div class="wqwechat_subscribe_btn wqwechat_top">
                    <a href="plugin.php?id=wq_wechatreader&mod=ajax&keyword={$keyword}&ac=subscription" class="dialog">{$Plang['a9eb91eeba4fef41']}</a>
                </div>
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->
<!--{template wq_wechatcollecting:common/footer}-->