<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<h3 class="flb">
    <span>
        <a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a>
    </span>
</h3>
<div class="wqpc_search_warp">
    <div class="wqpc_search_warp_input">
        <form id="show_formsearch" method="get" action="plugin.php">
            <input type="text" id="searchkw" placeholder="{$Plang['509ae8eac3b2e5cd']}" name="keyword" maxlength="400"/>
            <input type="hidden" name="formhash" value="{FORMHASH}">
            <input type="hidden" name="id" value="wq_wechatcollecting" id="show_pluginid">
            <input type="hidden" name="mod" value="search">
            <input type="hidden" name="searchform" value="true">
            <!--{if $a_searchset['status']}-->
                <button type="button" class="wqpc_btn_la" onclick="check_search_keyword('wq_wechatcollecting')">{$Plang['4cb9e8721e550eb0']}</button>
            <!--{/if}-->
            <!--{if $plugin_wechatshow && $w_searchset['status']}-->
            <button type="button" class="<!--{if !$a_searchset['status']}-->wqpc_btn_la<!--{else}-->wqpc_btn_ba<!--{/if}-->" onclick="check_search_keyword('wq_wechatshow')">{$Plang['c9bc3705598eff5c']}</button>
            <!--{/if}-->
        </form>
    </div>
     <!--{if $a_searchset['status'] || $w_searchset['status']}-->
        <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
        <div class="wqpc_hot_search">
            <h3>{$Plang['e25abc09de8e8390']}</h3>
            <ul>
                <!--{loop $setkeyword $key $val}-->
                <li><a href="plugin.php?id=$identifier&mod=search&keyword=$val">$val</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    <!--{/if}-->
</div>
<script type="text/javascript" reload='1'>

    function check_search_keyword(identifier){
        var keyword = wqjq("#searchkw").val();;
        if(!keyword){
            showDialog('&#35831;&#36755;&#20837;&#20851;&#38190;&#23383;', null, null, null, null, null, null, null, null, 2, null)
            return;
        }
        if(identifier){
            wqjq('#show_pluginid').val(identifier);
        }
        wqjq('#show_formsearch').submit();
    }
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->