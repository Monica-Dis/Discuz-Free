<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['inajax']}-->
<input type="hidden" name="totalPages" value="{$next_page}" class="totalPages" />
<input type="hidden" value="{$listcode}" name="listcode" class="listcode" />
<!--{loop $list $wechat}-->
<li>
	<a href="javascript:;">
		<div class="wqpc_img"><img src="{$wechat['qrcode']}"/></div>
		<div class="wqpc_con">
			<h3 class="">
				$wechat['name']
				<!--{if $wechat['verify']}-->
				<img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png">
				<!--{/if}-->
			</h3>
			<div class="wq_weixinhao">{$Plang['4b3b548154549518']}:{$wechat['username']}</div>
			<p><span>{$Plang['a19085767b52c6d7']}:</span>{$wechat['intro']}</p>
		</div>
	</a>
	<input type="checkbox" class="openids" name="usernames[]" value="{$wechat['username']}" />
</li>
<!--{/loop}-->
<!--{/if}-->
<!--{if !$_GET['inajax']}-->
<!--{template wq_wechatcollecting:common/tpl_header}-->
<script src="./source/plugin/wq_wechatcollecting/static/js/common.js?{VERHASH}" charset="gbk" type="text/javascript"></script>
<!--{if $op == 'add' && $step == '2' && $setting['view_mode'] == '4'}-->
<style>
    .wqpc_wechat_pubscribe_result .wqpc_wechat_result_list ul li{ float: left;height: 120px; display: block; margin: 10px; padding:10px; width: 437px; position: relative; border: 1px dashed #ccc; cursor: pointer;}
    .wqpc_wechat_pubscribe_result .wqpc_wechat_result_list .wqpc_con p{ line-height: 24px; position: relative; width: 240px;}
    .wqpc_wechat_operation .wqpc_directional{ margin-right: 10px;}
    .wqpc_wechat_operation .wqpc_wechat_btn{ background: #01a9e9; color: #fff; cursor: pointer; width:80px; height: 34px; border-radius: 3px; font-size: 14px; margin-left: 10px;}
    .wq_wechat_per .wq_wechat_per_list{ width: 200px; line-height: 60px; text-align: center; font-size: 16px; float: left;}
    .wq_wechat_per .wq_wechat_per_con{ background: #fff; float: left; width: 1000px; min-height:700px;}
</style>
<!--{/if}-->
<style>
    .addwechat_title, addwechat_input { height: 30px; line-height: 30px; text-align: right }
    .collectwechat_title{ height: 30px; line-height: 20px; text-align: right }
    addwechat_input { text-align: left }
    .addwechat_input input{margin-left: 10px;}
    .addwechat_input select{margin-left: 10px;}
    .openids{ display: none}
    .bottom{ text-align: right; margin: 15px;}
    .wechat_img{width:130px; height:130px;position:relative;border:1px dashed #ccc;clear:both;}
    .wechat_img .qrcode{position:absolute; margin:5px 0 0 5px;clear:both; top:0; left: 0}
    .wechat_img .headimage{position:absolute; top:48px; left:48px;}
    .dt th{text-align: center;white-space:nowrap;}
    .collectrecord{float:right; position: absolute;bottom:10px;right:0;color:#0099CC;}
    .dt td{ position: relative;}
    .wechat_collect_td{position:relative;height: 20px; line-height: 30px;}
    #weixinname{position:absolute;left: 150px; font-size: 16px;}
    .wechatid_collect{line-height: 30px;position: relative;}
    .wechatid_collect span{padding-left: 20px;}
    .wechatid_collect select, .wechatid_collect input{margin-left:20px; line-height: 30px;}
    .wechatid_collect textarea{margin-left: 20px;}
    #portrait{margin-left: 20px;}
    .wechatid_collect div{padding-left: 20px;overflow: hidden; }
    #sum{position:absolute;left:80px;line-height: 20px;}
    .pn{margin-left: 20px;}
    .release_type{cursor: pointer;}
    .release_type input{cursor: pointer;}
    .bottom {width: auto;}
    .wqintro{max-height: 86px; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 4; -webkit-box-flex: 1; }
</style>
<div class="wq_wechat_per">
    <div class="wq_wechat_per_list">
		<!--{template wq_wechatcollecting:cp_nav}-->
    </div>
    <div class="wq_wechat_per_con">
        <div class="wqpc_wechat_apply">
            <div class="wqpc_title">
                <ul>
					<!--{if $op == 'add'}-->
                    <li <!--{if $_GET['wechat']!== 'serve'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add">{$Plang['3a26e95308b35535']}</a></li>
                    <!--{if !empty($plugin)}-->
                    <li <!--{if $_GET['wechat']== 'serve'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add&wechat=serve">{$Plang['dbca9db832d7d5f4']}</a></li>
                    <!--{/if}-->
                    <!--{eval $span_url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&meun=my_submit';}-->
                    <!--{if in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
					<!--{eval $span_url = 'plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage';}-->
                    <!--{/if}-->
                    <span class="o y wqpc_managebtn"><a href="{$span_url}">{$Plang['a2963175c4f5a0ca']}</a></span>
					<!--{else}-->
					<li <!--{if $status==array(0, 1, -1)}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&meun=$meun">{$Plang['e8af971c6963983d']}</a></li>
                    <li <!--{if $_GET['status']=='1'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=1&meun=$meun">{$Plang['d4cd6471a700d52c']}</a></li>
                    <li <!--{if $_GET['status']=='0'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=0&meun=$meun">{$Plang['05df925dd69b4333']}</a></li>
                    <li <!--{if $_GET['status']=='-1'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=-1&meun=$meun">{$Plang['b5d0d1b6c49b2665']}</a></li>
                    <li <!--{if $_GET['status']=='6'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=6&meun=$meun">{$Plang['6b188101f97fd44a']}</a></li>
                    <li <!--{if $_GET['status']=='-2'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=-2&meun=$meun">{$Plang['4930bcc2615700e9']}</a></li>
                    <li <!--{if $_GET['status']=='auto-1'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=auto-1&meun=$meun">{$Plang['a0e585f031c497a6']}</a></li>
                    <li <!--{if $_GET['status']=='auto-0'}--> class="a" <!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=$op&status=auto-0&meun=$meun">{$Plang['27236a2d713d9970']}</a></li>
                    <!--{if in_array($_G['groupid'], $setting['allow_groups']) || in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
					<span  class="o y wqpc_managebtn"><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add">{$Plang['ab6b2e0930f61299']}</a></span>
                    <!--{/if}-->
					<!--{/if}-->
                </ul>
            </div>
            <!--{if $_GET['op'] != 'add'}-->
			<div class="wqmanage_search"><input type="text" placeholder="{$Plang['ae6845c0ef4a4fab']}" value="{$wechatname}"><button type="button">{$Plang['38224a4a6fc78c7c']}</button></div>
            <!--{/if}-->
			<div class="wqpc_con wqpc_con_yygl">
				<!--{if $op == 'add'}-->
				<!--{if $step == '1'}-->
				<!--{if $_GET['wechat'] == 'serve' && !empty($plugin)}-->
				<!--{template wq_wechatshow:wechatshow_serve}-->
				<!--{else}-->
				<form id="subscription_collect" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add" method="post" onsubmit="return checkSubmit(this);">
					<input type="hidden" id="totalPages" value="true" name="searchsubmit"/>
					<input type="hidden" value="{FORMHASH}" name="formhash"/>
					<table cellspacing="0" cellpadding="0" class="wq_tfm" style="width: 600px;">
						<tbody>
							<tr>
								<td class="wqpc_con_title">{$Plang['f8497259f9b3f761']} :</td>
								<td class="wqpc_con_collect"><input type="text" name="keyword"/></td>
							</tr>
							<tr>
								<td class="wqpc_con_title">{$Plang['beeabe7dbacad174']} :</td>
								<td class="wqpc_con_collect">
									<select name="totalPages" id="totalPages">
										<option value="1" >1</option>
										<option value="2" >2</option>
										<option value="3" >3</option>
										<option value="4" >4</option>
										<option value="5" >5</option>
										<option value="6" >6</option>
										<option value="7" >7</option>
										<option value="8" >8</option>
										<option value="9" >9</option>
										<option value="10" >10</option>
									</select>
								</td>
							</tr>
							<tr>
								<td></td>
								<td class="wqpc_btn">
									<button type="submit" class="">{lang submit}</button>
								</td>
							</tr>
						</tbody>
					</table>
				</form>
				<!--{/if}-->
				<!--{elseif $step == '2'}-->
				<div class="wqpc_wechat_pubscribe_result">
					<div class="wqpc_wechat_result_list">
						<!--{if $list}-->
						<form style="display:none" id="subscription_collect" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add" method="post">
							<input type="hidden" value="true" name="searchsubmit"/>
							<input type="hidden" value="{FORMHASH}" name="formhash"/>
							<!--<input type="hidden" name="keyword" value="$keyword">-->
							<input type="hidden" name="keyword" value=<!--{eval echo urlencode($keyword);}-->>
								   <input type="hidden" name="totalPages" value="{$next_page}" class="totalPages" />
							<input type="hidden" value="{$listcode}" name="listcode" class="listcode" />
						</form>
						<form name="post" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=add" method="post">
							<input type="hidden" value="true" name="addsubmit"/>
							<input type="hidden" value="{FORMHASH}" name="formhash"/>
							<input type="hidden" value="{$listcode}" name="listcode"/>
							<input type="hidden" value="{$keyword}" name="keyword"/>
							<ul class="wechatlist">
								<!--{loop $list $wechat}-->
								<li>
									<a href="javascript:;" >
										<div class="wqpc_img wqlazydiv"><img wqdata-src="{$wechat['qrcode']}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
										<!--<div class="wqpc_img"><img src="{$wechat['qrcode']}"/></div>-->
										<div class="wqpc_con">
											<h3 class="">
												$wechat['name']
												<!--{if $wechat['verify']}-->
												<img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png">
												<!--{/if}-->
											</h3>
											<!--{if $wechat['dynamicinfo']}-->
											<p><span>{$Plang['f7ac9becb8d864cd']}</span>{$wechat['dynamicinfo']}</p>
											<!--{/if}-->
											<div class="wq_weixinhao">{$Plang['4b3b548154549518']}:{$wechat['username']}</div>
											<p><span>{$Plang['a19085767b52c6d7']}:</span>{$wechat['intro']}</p>

										</div>
									</a>
									<input type="checkbox" class="openids" name="usernames[]" value="{$wechat['username']}" />
								</li>
								<!--{/loop}-->
							</ul>
							<p class="wqpc_wechat_more" id="load_next_page">
								<a href="javascript:;">
									<!--{eval echo sprintf($Plang['98cf0d593c9a3348'],$keyword);}-->
								</a>
							</p>

							<div class="y wqpc_wechat_operation">
								<a href="javascript:;" id="checkAll">{$Plang['all_select']}<span class="wq_line"></span></a>
								<a href="javascript:;" id="cancleAll">{$Plang['282663df65932b31']}<span class="wq_line"></span></a>
								<a href="javascript:;" id="Inverse" class="wqpc_directional">{$Plang['111ced0c39e06d7b']}</a>
							</div>
							<div class="y wqpc_wechat_operation">
								{$Plang['57dca09a1285209b']}:{$classselect}&nbsp;&nbsp;
								{$Plang['4135f6cd31b1a169']}:{$classselect_article}&nbsp;&nbsp;
								{$Plang['b5bd9e232e51e294']}:<select name="view_mode">{$view_mode_select}</select>
								<button type="submit" class="wqpc_wechat_btn">{lang submit}</button>
							</div>
						</form>
						<!--{else}-->
						<div class="wqpc_emp">
							{$Plang['eaab1b41e8a5809e']}
							{$Plang['d1a203f5cfe80d0e']}
						</div>
						<!--{/if}-->
					</div>
				</div>
				<!--{/if}-->
				<!--{elseif $op == 'collect'}-->
				<form name="post" id="collect_form" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=collect" method="post">
					<input type="hidden" value="true" name="searchsubmit"/>
					<input type="hidden" value="{FORMHASH}" name="formhash"/>
					<input type="hidden" value="{$collect['wechatid']}" name="wechatid" />

					<table cellspacing="0" cellpadding="0" class="wq_tfm">
						<tr>
							<td class="wechat_collect_td" colspan="2"><h2 class="wq_title" id="weixinname">{$collect['name']}</h2></td>
						</tr>
						<tr>
							<td class="wqpc_con_title">{$Plang['4b3b548154549518']}:</td>
							<td class="wqpc_con_collect" ><span>{$collect['wechatid']}</span></td>
						</tr>

						<tr>
							<td class="wqpc_con_title">{$Plang['a19085767b52c6d7']}:</td>
							<td class="wqpc_con_collect" ><div>{$collect['intro']}</div></td>
						</tr>

						<!--{if empty($collect['classid']) || empty($collect['article_classid'])}-->
						<tr>
							<td class="wqpc_con_title">{$Plang['57dca09a1285209b']}:</td>
							<!--{eval $classselect = get_class_select('classid', $wechatclass, $collect['classid'], $Plang['1a757dd19f8883e6']);}-->
							<td  class="wqpc_con_collect">{$classselect}</td>
						</tr>
						<tr>
							<td class="wqpc_con_title">{$Plang['4135f6cd31b1a169']}:</td>
							<td  class="wqpc_con_collect">{$classselect_article}</td>
						</tr>
						<!--{/if}-->
						<tr>
							<td class="wqpc_con_title">{$Plang['47094f52069c9b3e']}:</td>
							<td  class="wqpc_con_collect">{$classselect_article_collect}</td>
						</tr>
						<tr>
							<td class="wqpc_con_title">{$Plang['collectpage']}:</td>
							<td class="wqpc_con_collect"><select name="collectpage">{$option}</select></td>
						</tr>
						<tr>
							<td class="wqpc_con_title">{$Plang['e10bd504290a69a2']}:</td>
							<td class="wqpc_con_collect">
								<span class='release_type'>
									<input type="radio" name="release_type" class="pr weui_check"  id="release_type_1"  value="1"checked/>
									<label class="weui_check_label" for="release_type_1"><i class="wqwechat weui_icon_checked"></i>{$Plang['f8eca3a3d99ac5fc']}</label>
								</span>
								<span class='release_type'>
									<input type="radio" name="release_type" class="pr weui_check"  id="release_type_2"  value="2"/>
									<label class="weui_check_label" for="release_type_2"><i class="wqwechat weui_icon_checked" style="margin-left:20px;"></i>{$Plang['76ebdc0024db7a5b']}</label>
								</span>
							</td>
						</tr>
						<tr>
							<th></th>
							<td><div id="foraid" style="display: none"></div>
								<input type="hidden" name="page" value="{$_GET['page']}"/>
								<input type="hidden" name="status" value="{$_GET['status']}"/>
								<button type="submit" class="wqpc_wechat_tj" onclick="show_hint()" id="collect_submit"><strong id="collect_text">{lang submit}</strong></button></td>
						</tr>
					</table>
				</form>
				<!--{else}-->
				<form name="post" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac&op=autoswitch&meun=$meun" method="post">
					<table class="dt" style="text-align: center;" >
						<tr>
							<!--{if $_GET['status'] == 'auto-1' || $_GET['status'] == 'auto-0'}-->
							<th></th>
							<!--{if $_GET['status'] == 'auto-1'}-->
							<th width="80">{$Plang['43b4a1fb48e2248e']}</th>
							<!--{/if}-->
							<!--{/if}-->
							<th>{$Plang['ddd826aa11868c7d']}</th>
							<th width="120">{$Plang['f8497259f9b3f761']}</th>
							<th>{$Plang['18ad271b7e118fe7']}</th>
							<th width="100">{$Plang['db11cdebc2eb37bd']}</th>
							<th>{$Plang['35c503d59b64ffda']}</th>
							<th width="100">{$Plang['c8b66064ce323401']}</th>
							<th width="100" >{$Plang['ca5a0d75b677d381']}</th>
						</tr>
						<!--{if $list}-->
						<!--{loop $list $key $value}-->
						<tr class="trstyle" >
							<!--{if $_GET['status'] == 'auto-1' || $_GET['status'] == 'auto-0'}-->
							<td width="40px"><input type="hidden" name="wid[{$value[id]}]" value="{$value[id]}"><input class="checks" type='checkbox' name='autocollecting[{$value[id]}]' value='{$value[automaticcollect]}' style='cursor:pointer;'></td>
							<!--{if $_GET['status'] == 'auto-1'}-->
							<td><input class="checks" type='number' name='displayorder[{$value[id]}]' value='{$value[displayorder]}' style='width:50px;'></td>
							<!--{/if}-->
							<!--{/if}-->
							<td width="140px"><div class="wechat_img wqlazydiv" style="width:120px; height:120px;">
									<img wqdata-src="{$value['qrcode']}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/>
								</div>
							</td>
							<td>
								<a target="_blank" href="plugin.php?id=wq_wechatshow&mod=view&wid=$value[wechatid]&displayorder=index">{$value[name]}<br>{$value[wechatid]}</a>
							</td>
							<td>
								<a class="wqintro" target="_blank" href="plugin.php?id=wq_wechatshow&mod=view&wid=$value[wechatid]&displayorder=index">{$value['intro']}</a>
								<br>
								<a class="collectrecord" href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=collect&wechatid={$value[wechatid]}&status=$_GET['status']&page=$page">{$Plang['fbc185337b415ac6']}</a>
							</td>
							<td>
								<!--{if $value['recommend']}-->
								{$Plang['b4b0d4ba96890702']}
								<!--{else}-->
								{$Plang['77b41af77fe3ce13']}
								<!--{/if}-->
							</td>
							<td>
								<!--{if $_GET['status']!='-2'}-->
								<!--{if $value['automaticcollect']=='0'}-->
								{$Plang['2109f37565c59a62']}<br />
								(<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=automaticcollect&meun=$meun&wechatid={$value[wechatid]}&page={$_GET['page']}&status={$_GET['status']}"><font color="#FF9300" >{$Plang['a28baeaf9e585cb1']}</font></a>)
								<!--{else}-->
								{$Plang['34b7358cfea586f3']}<br />
								(<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=automaticcollect&meun=$meun&wechatid={$value[wechatid]}&page={$_GET['page']}&status={$_GET['status']}"><font color="#0099CC">{$Plang['beb08d096719774b']}</font></a>)
								<!--{/if}-->
								<!--{else}-->
								{$Plang['283533d6c074b612']}
								<!--{/if}-->
							</td>
							<td>
								<!--{eval echo $collecttime=date("Y-m-d H:i:s", $value['collecttime']);}-->
							</td>
							<td>
								<!--{eval echo get_wechat_status($value[status])}--><br/>
								<!--{if $_GET['status']=='-2'}-->
								<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=restore&meun=$meun&wechatid={$value[wechatid]}">{$Plang['2e2908c705dfac38']}</a>
								<!--{else}-->
								<a class="del" href='plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=del&meun=$meun&wechatid={$value[wechatid]}&meun=$meun'  >{$Plang['d181a2dabec27469']}</a>
								<!--{/if}-->
							</td>
						</tr>
						<!--{/loop}-->
						<!--{else}-->
						<!--{if ($_GET['status'] == 1 || !in_array($_GET['status'],$statusarr)) && $meun == 'my_renling'}-->
						<tr><td colspan="7">
								<!--{if !$plugin_wechatshow}-->
								{$Plang['95c9636a5b0a8cfe']}
								<!--{else}-->
								{$Plang['1dc495d39156a4d5']}
								<!--{/if}-->
							</td></tr>
						<!--{/if}-->
						<!--{/if}-->
						<!--{if $list && ($_GET['status'] == 'auto-1' || $_GET['status'] == 'auto-0')}-->
						<tr>
							<td colspan="7" align='left'>
								<div style='cursor:pointer;float:left;' onclick="collecting_selectall(this)">
									<input type='checkbox' name='checkall'  id="coll_checkall" style='cursor:pointer;' onclick="collecting_selectall(this)">
									<!--{if $_GET['status'] == 'auto-1'}-->
									{$Plang['e5307fa39e11797c']}
									<!--{else}-->
									{$Plang['2fb0d4f83fa0a422']}
									<!--{/if}-->
								</div>
								<button type="submit" class="pn pnp"><strong>{lang submit}</strong></button>
							</td>
						</tr>
						<!--{/if}-->
					</table>
					<div>

					</div>
				</form>
				<!--{if $multi}--><div class="pgs mtn cl wqpage">$multi</div><!--{/if}-->
				<!--{/if}-->
			</div>
		</div>
    </div>
</div>
<script type="text/javascript">
	var Is_recycle_bin = '{$Plang['c35a4638b561fece']}',
		collect_text = '{$Plang['a3a1ebc1b1c71998']}';</script>
<script type="text/javascript">
	function show_hint() {
	wqjq('#collect_submit').parents('tr').before('<tr><th></th><td>{$Plang['0a8ebb3ac62ca372']}</td></tr>')
		wqjq('#collect_hint').show();
	wqjq('#collect_text').text('{$Plang['a3a1ebc1b1c71998']}');
	wqjq('#collect_form').submit();
	wqjq("#collect_submit").attr("disabled", "disabled");
	}

</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->
<!--{/if}-->