<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<script src="./source/plugin/wq_wechatcollecting/static/js/common.js?{VERHASH}" charset="{CHARSET}" type="text/javascript"></script>
<style>
    .collectwechat_title{ height: 30px; line-height: 20px; text-align: right }
    .wechatlist {height:1%; overflow:hidden; margin-top:10px; margin-left: 20px;}
    .wechatlist .look_text{color: #369;position: absolute;top: 120px;left: 3px;}
    .wechatlist li { width:418px; height:140px; float:left; margin:5px; border:1px dashed #ccc; padding:10px 10px 2px 10px; position:relative;overflow:hidden }
    .wechatlist li .wechat_txt { width:415px; float:left; }
    .wechatlist li .wechat_txt h3{ height:25px; line-height:25px; font-size:16px;overflow: hidden;white-space: nowrap; display: block; -o-text-overflow: ellipsis; text-overflow: ellipsis;}
    .wechatlist li .wechat_txt p{ color:#333; line-height:22px;font-size:14px;overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2; -webkit-box-flex: 1;}
    .wechatlist li .wechat_txt p.username{ color:#999}
    .wechatlist li:hover{ border:1px solid #f60}
    .wechatlist li.on{ border:1px solid #f60}
    .openids{ display: none}
    .bottom{ text-align: right; margin: 15px;}
    .wqpc_con_collect span{padding-left: 0px;}
    .wqpc_con_collect select, .wqpc_con_collect input{margin-left:20px; line-height: 30px;}
    .pn{margin-left: 20px;}
    .release_type{cursor: pointer;}
    .release_type input{cursor: pointer;}
    .bottom {width: auto;}
</style>

<div class="wq_wechat_per">
    <div class="wq_wechat_per_list">
		<!--{template wq_wechatcollecting:cp_nav}-->
    </div>
    <div class="wq_wechat_per_con">
        <div class="wqpc_wechat_apply">

            <!--{if $step == 1}-->
			<div class="wqpc_con">
                <form name="post" id="collect_form" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac" method="post">
                    <input type="hidden" value="true" name="keywordcollect"/>
                    <input type="hidden" value="{FORMHASH}"name="formhash"/>
                    <table cellspacing="0" cellpadding="0" class="wq_tfm">
                        <tr>
                            <td class="wqpc_con_title">{$Plang['468ea4248fb9c2d5']}:</td>
                            <td  class="wqpc_con_collect">
                                <input type="text" class="search_keyword" name="search_keyword">
                            </td>
                        </tr>
                        <tr>
                            <td class="collectwechat_title">{$Plang['beeabe7dbacad174']}:</td>
                            <td class="wqpc_con_collect"><select name="collectpage">{$option}</select></td>
                        </tr>
                        <tr class="wechat_class">
                            <td class="wqpc_con_title">{$Plang['57dca09a1285209b']}:</td>
                            <td  class="wqpc_con_collect">{$classselect}</td>
                        </tr>
                        <tr class="wechat_class">
                            <td class="wqpc_con_title">{$Plang['4135f6cd31b1a169']}:</td>
                            <td  class="wqpc_con_collect">{$classselect_article}</td>
                        </tr>
                        <tr>
                            <td class="wqpc_con_title">{$Plang['47094f52069c9b3e']}:</td>
                            <td  class="wqpc_con_collect">{$classselect_article_collect}</td>
                        </tr>
                        <tr>
                            <td class="collectwechat_title">{$Plang['e10bd504290a69a2']}:</td>
                            <td class="wqpc_con_collect">
                                <span class='release_type'>
                                    <input type="radio" name="release_type" class="pr weui_check"  id="release_type_1"  value="1"checked/>
                                    <label class="weui_check_label" for="release_type_1"><i class="wqwechat weui_icon_checked" style="margin-left:20px;"></i>{$Plang['f8eca3a3d99ac5fc']}</label>
                                </span>
                                <span class='release_type'>
									<input type="radio" name="release_type" class="pr weui_check"  id="release_type_2"  value="2"/>
									<label class="weui_check_label" for="release_type_2"><i class="wqwechat weui_icon_checked" style="margin-left:20px;"></i>{$Plang['76ebdc0024db7a5b']}</label>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td class="collectwechat_title">{$Plang['9dc5f15d84e334bc']}:</td>
                            <td class="wqpc_con_collect">
                                <span class='release_type' onclick="show_wechat_select(true)">
                                    <input type="radio" name="collect_all" class="weui_check"  id="add_wechat_1"  value="1"/>
                                    <label class="weui_check_label" for="add_wechat_1"><i class="wqwechat weui_icon_checked" style="margin-left:20px;"></i>{$Plang['c7b4099dec98b579']}</label>
                                </span>
                                <span class='release_type' onclick="show_wechat_select(false)">
                                    <input type="radio" name="collect_all" class="weui_check"  id="add_wechat_0"  value="0"checked/>
                                    <label class="weui_check_label" for="add_wechat_0"><i class="wqwechat weui_icon_checked" style="margin-left:20px;"></i>{$Plang['5b553415507d5daf']}</label>
                                </span>
                            </td>
                        </tr>

                        <tr>
                            <td></td>
                            <td>
                                <button type="submit" class="wqpc_wechat_tj wqm_left20" onclick="show_hint()" id="collect_submit"><strong id="collect_text">{lang submit}</strong></button>
                            </td>
                        </tr>
                    </table>
                </form>
			</div>
            <!--{elseif $step == 2}-->
            <form name="post" id="collect_form" action="plugin.php?id=wq_wechatcollecting&mod=cp&ac=$ac" method="post">
                <input type="hidden" value="true" name="selectarticle"/>
                <input type="hidden" value="{FORMHASH}" name="formhash"/>
                <input type="hidden" value="{$keyword}" name="keyword"/>
                <input type="hidden" value="{$listcode}" name="listcode"/>
                <input type="hidden" value="{$release_type}" name="release_type"/>
                <input type="hidden" value="{$collect_all}" name="collect_all"/>
                <!--{if $classid}-->
                <input type="hidden" value="{$classid}" name="classid"/>
                <input type="hidden" value="{$article_classid}" name="article_classid"/>
                <input type="hidden" value="{$article_classid_thistime}" name="article_classid_thistime"/>
                <!--{/if}-->
                <ul class="wechatlist">
                    <!--{loop $list $key $article}-->
                    <li>
                        <div class="wechat_txt">
                            <h3>
                                {$article['title']}
                            </h3>
                            <p class="username">{$Plang['3982634cd20768c9']}{$Plang['3aba14be242cdfaf']}{$article['sourcename']}</p>
                            <p>
                                {$article['summary']}
                            </p>
                            <a href="{$article['url']}" class="look_text" target="_blank">{$Plang['1c46ec2684e2dbd8']}</a>
                        </div>
                        <input type="checkbox" class="openids" name="usernames[]" value="{$key}" />
                    </li>

                    <!--{/loop}-->
                </ul>
                <div>
                    <b style="color:red;display:none;" id="collect_hint">{$Plang['d8a5be2f27f33ed5']}</b>
                </div>
                <div class="bottom wqpc_allinput" style="font-size:13px;">
                    <a href="javascript:;" id="checkAll">{$Plang['1a757dd19f8883e6']}</a>
                    <a href="javascript:;" id="cancleAll">{$Plang['282663df65932b31']}</a>
                    <a href="javascript:;" id="Inverse">{$Plang['111ced0c39e06d7b']}</a>
                    <!--{if !$classid}-->
                    {$Plang['57dca09a1285209b']}:&nbsp;{$classselect}&nbsp;
                    {$Plang['4135f6cd31b1a169']}:&nbsp;{$classselect_article}&nbsp;
                    {$Plang['47094f52069c9b3e']}:&nbsp;{$classselect_article_collect}
                    <!--{/if}-->
                    <button type="submit" onclick="show_hint()" id="collect_submit"><strong id="collect_text">{lang submit}</strong></button>
                </div>
            </form>
            <!--{/if}-->
        </div>
    </div>
</div>
<script type="text/javascript">
	function show_hint() {
	wqjq('#collect_submit').parents('tr').before('<tr><th></th><td>{$Plang['0a8ebb3ac62ca372']}</td></tr>')
		wqjq('#collect_hint').show();
	wqjq('#collect_text').text('{$Plang['a3a1ebc1b1c71998']}');
	wqjq('#collect_form').submit();
	wqjq("#collect_submit").attr("disabled", "disabled");
	}

	function show_wechat_select(bool) {
	if(bool) {
	wqjq('#add_wechat_1').attr('checked', true);
	} else {
	wqjq('#add_wechat_0').attr('checked', true);
	}
	}



</script>

<!--{template wq_wechatcollecting:common/tpl_footer}-->