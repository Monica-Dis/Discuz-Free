<?php exit("Powered by www.wikin.cn"); ?>
{eval
function common_right_searchoradd() {
    global $Plang,$_G,$setting,$a_searchset,$w_searchset;
}
    <!--{block return}-->

        <div class="wqpc_search_shenqing">
            <!--{if $a_searchset['status'] || $w_searchset['status']}-->
                <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
                <a id="common_search_right" href="plugin.php?id=$identifier&mod=search&act=alt" onclick="showWindow(this.id, this.href, 'get', 0);" class="wqpc_search">{$Plang['38224a4a6fc78c7c']}</a>
            <!--{/if}-->
            <!--{if in_array($_G['groupid'], $setting['allow_groups']) || in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
                <a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add"<!--{if !$a_searchset['status'] && !$w_searchset['status']}--> style="width: 100%;"<!--{/if}-->>{$Plang['9de5414139ecbfb4']}</a>
            <!--{else}-->
                <a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list&meun=my_submit"<!--{if !$a_searchset['status'] && !$w_searchset['status']}--> style="width: 100%;"<!--{/if}-->>{$Plang['3c93ac86c02f7668']}</a>
            <!--{/if}-->
        </div>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function common_right_keyword_hot(){
    global $setkeyword,$Plang,$a_searchset,$w_searchset;

}
    <!--{block return}-->
        <!--{if $a_searchset['status'] || $w_searchset['status']}-->
            <div class="wqpc_subscribe">
                <h3>{$Plang['6043b7672fed8033']}</h3>
                <div class="wqpc_subscribe_box">
                    <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
                    <div style="left:0;top:0">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[0]" class="wqpc_la">
                            <span style="padding-top: 17px; ">$setkeyword[0]</span>
                        </a>
                    </div>
                    <div style="left:95px;top:0">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[1]" class="wqpc_lv">
                            <span style="padding-top: 17px;">$setkeyword[1]</span>
                        </a>
                    </div>
                    <div style="height:118px;left:190px;top:0">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[2]" class="wqpc_la f16">
                            <span style="padding-top: 45px;">$setkeyword[2]</span>
                        </a>
                    </div>
                    <div style="height:118px;left:0;top:60px">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[3]" class="wqpc_red f16">
                            <span style="padding-top: 45px;">$setkeyword[3]</span>
                        </a>
                    </div>
                    <div style="left:95px;top:60px">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[4]" class="wqpc_la">
                            <span style="padding-top: 17px;">$setkeyword[4]</span>
                        </a>
                    </div>
                    <div style="left:95px;top:120px">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[5]" class="wqpc_red">
                            <span style="padding-top: 17px">$setkeyword[5]</span>
                        </a>
                    </div>
                    <div style=" left:190px; top:120px">
                        <a href="plugin.php?id=$identifier&mod=search&keyword=$setkeyword[6]" class="wqpc_lv">
                            <span style="padding-top: 17px">$setkeyword[6]</span>
                        </a>
                    </div>

                </div>
            </div>
        <!--{/if}-->
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function common_right_wechat_recommed(){
    global $right_recommedlist,$Plang;
}
    <!--{block return}-->
        <div class="wq_wechat_numrecommend">
            <h3><a href="javascript:;" >{$Plang['ebdb17b9fa566a2d']}</a></h3>
            <ul>
                <!--{loop $right_recommedlist $key $val}-->
                <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist[displayorder] = 'index';  $url = 'plugin.php?'.url_implode($getlist);}-->
                <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode'];}-->
                <li>
                    <a href="{$url}" target="_blank" >
                    <div class="wq_code wqlazydiv"><img wqdata-src="{$logourl}"src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg"class="lazyload-home" /></div>
                    <div class="wq_codeinfo">
                        <h4>{$val[name]}</h4>
                        <p>{$val[intro]}</p>
                    </div>
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function common_right_first_article(){
    global $right_first,$Plang,$setting;
}
    <!--{block return}-->
        <div class="wq_wechat_headlines">
        <h3><a href="javascript:;" >{$Plang['1eabc61bba212dd6']}</a></h3>
        <ul>
            <!--{loop $right_first $key $val}-->
            <!--{eval $data = date('Y-m-d H:i',$val['date']);}-->
            <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
            <li>
                <em></em>
                <span></span>
                <a href="{$url}" target="_blank" >
                <div class="wq_title">$val['title']</div>
                <div class="wq_time">$data</div>
                </a>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function common_right_article_maximg(){
    global $right_hot,$Plang,$setting;
}
    <!--{block return}-->
        <div class="wq_wechat_hotarticle">
                <h3><a href="javascript:;" >{$Plang['cd28d8e22cbacebe']}</a></h3>
                <ul>
                    <!--{loop $right_hot $key $val}-->
                    <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
                    <li>
                        <a href="{$url}" target="_blank">
                        <div class="wqpc_img wqlazydiv"><img wqdata-src="{$val[imglink]}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                        <div class="wqpc_title">{$val[title]}</div>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function common_right_article_minimg($list,$title,$is_collect = false){
    global $Plang,$setting;
}
    <!--{block return}-->
    <div class="wq_wechat_hotcollection">
        <h3><a href="javascript:;" >{$title}</a></h3>
        <ul>
            <!--{loop $list $key $val}-->
            <!--{eval $data = date('Y-m-d H:i',$val['date']);}-->
            <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
            <li>
                <a href="{$url}" target="_blank">
                <div class="wq_code wqlazydiv"><img wqdata-src="{$val[imglink]}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                <div class="wq_codeinfo">
                    <h4>{$val[title]}</h4>
                    <!--{if $is_collect}-->
                        <p>{$val[favorites]} {$Plang['94212090797ff211']}</p>
                    <!--{else}-->
                        <p>$data</p>
                    <!--{/if}-->
                </div>
                </a>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
function wechat_view_ajax_collect_returnhtml($list) {
    global $setting,$_G,$Plang,$plugin_wechatreader;
    $date = date('Y-m-d',$list['date']);
}
    <!--{if !$list}-->
    <!--{eval return '';}-->
    <!--{/if}-->
    <!--{block return}-->
        <!--{eval $url = wq_common_article_view_url($setting,$list['articleid'],$list['tid'],$list['aid']);}-->
        <li>
            <a href="{$url}" id="articleurl_{$list[articleid]}" target="_blank">
                <div class="wqpc_img wqlazydiv"><img id="imglink_{$list[articleid]}" wqdata-src="{$list[imglink]}"src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                <div class="wqpc_con">
                    <h3 id="articletitle_{$list[articleid]}">{$list['title']}</h3>
                    <p class="wqpc_sum" id="summary_{$list[articleid]}">{$list['summary']}</p>
                </div>
            </a>
            <div class="wqpc_info">
                <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $list['wechatid']; $url = 'plugin.php?'.url_implode($getlist);}-->
                <span class="wqpc_num_name"><a href="{$url}" target="_blank">{$list['name']}</a></span>
                <span>$date</span>
                <span class="y wqpc_share article_share" id="$list[articleid]">
                    <a href="javascript:;"><i class="wqwechat wqwechat-fenxiang"></i>{$Plang['dae251a4f8687b1c']}
                    <div class="article wqbdsharebuttonbox bdsharebuttonbox articleshared_{$list[articleid]} wqpc_share_warp" data-tag="share_1" style="display: none;" id="articleshared_29599">
                        <a class="bds_tsina " data-cmd="tsina"></a>
                        <a class="bds_qzone " data-cmd="qzone"></a>
                        <a class="bds_weixin " data-cmd="weixin"></a>
                        <a class="bds_sqq " data-cmd="sqq"></a>
                        <a class="bds_tieba " data-cmd="tieba"></a>
                         <a class="bds_more "  data-cmd="more"></a>
                    </div>
                    </a>
                </span>

                <!--{if $plugin_wechatreader}-->
                    <!--{if !$_G['uid']}-->
                        <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                    <!--{/if}-->
                    <span class="y wqpc_collection" id="aid_{$list[articleid]}">
                        <a<!--{if !$logininfo}--> id="reader_favorites_{$list[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$list[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-favorite"></i>{$Plang['23393395a9152c6f']}</a>
                    </span>
                <!--{/if}-->
            </div>

        </li>
    <!--{/block}-->
    <!--{eval return $return;}-->
{eval
}
}