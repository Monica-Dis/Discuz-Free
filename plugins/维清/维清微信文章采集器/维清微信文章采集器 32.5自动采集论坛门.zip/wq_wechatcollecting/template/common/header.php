<?php exit("Powered by www.wikin.cn"); ?>
<!--{subtemplate wq_wechatcollecting:common/header_common}-->
<meta name="application-name" content="$_G['setting']['bbname']" />
<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
<!--{/if}-->
<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
<!--{if widthauto()}-->
<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
<!--{/if}-->
<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
<!--{elseif $_G['basescript'] == 'portal'}-->
<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
<!--{/if}-->
<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
<!--{/if}-->
<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
<!--{/if}-->
<link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/css/wqpc_wechat.css?{VERHASH}" type="text/css"/>
<link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/font/iconfont.css?{VERHASH}" type="text/css"/>
<script src="./source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
<script src="./source/plugin/wq_wechatcollecting/static/js/koala.min.1.5.js?{VERHASH}" type="text/javascript"></script>
<script src="./source/plugin/wq_wechatcollecting/static/js/terminator2.2.min.js?{VERHASH}" type="text/javascript"></script>
<script src="./source/plugin/wq_wechatcollecting/static/js/video.pc.js?{VERHASH}" type="text/javascript"></script>
<script src="{$_G[setting][jspath]}common_extra.js?{VERHASH}"></script>
</head>
    <body>
        <div id="append_parent"></div><div id="ajaxwaitid"></div>
        <!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
        <!--{template common/header_diy}-->
        <!--{/if}-->
        <!--{if check_diy_perm($topic)}-->
        <!--{template common/header_diynav}-->
        <!--{/if}-->
        <!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
        $diynav
        <!--{/if}-->
        <!--{if empty($topic) || $topic['useheader']}-->
        <!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
        <div class="xi1 bm bm_c"> {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a> </div>
        <!--{/if}-->
        <!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
        <div id="shortcut"> <span><a href="group.php" id="shortcutcloseid" title="{lang close}">{lang close}</a></span> {lang shortcut_notice} <a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a> </div>
        <!--{/if}-->
        <!--{/if}-->
        <header class="wqpc_wechat_warp">
            <div class="wqpc_wechat_header">
                <div class="wqpc_wechat_logo">
                    <!--{eval $mnid = getcurrentnav();}-->
                    <!--{if !isset($_G['setting']['navlogos'][$mnid])}-->
                        <a href="{$_G['siteurl']}"><img class="wqpc_img" src="./source/plugin/wq_wechatcollecting/static/images/{$logoname}"/></a>
                    <!--{else}-->
                    $_G['setting']['navlogos'][$mnid]
                    <!--{/if}-->
                </div>
                <div class="wqpc_wechat_menu">
                    <ul>
                        <!--{eval $wqpc_all = count($topnav) > 3 ? 'wqpc_all' : '';}-->
                        <!--{loop $topnav $key $val}-->
                                <!--{eval $clsval = '';$clsval=$val['ison'] ? ($wqpc_all ? $wqpc_all.' a' : 'a'): $wqpc_all;}-->
                        <li class="{$clsval}"><a href="{$val[1]}">$val[0]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="y wqpc_wechat_per">
                    <ul>
                        <!--{if $a_searchset['status'] || $w_searchset['status']}-->
                            <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
                            <li><a href="plugin.php?id=$identifier&mod=search&act=alt" id="common_search" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-iconfontsousuo1 wq_f20"></i>{$Plang['38224a4a6fc78c7c']}</a></li>
                        <!--{/if}-->
                        <!--{if $_G['uid']}-->
                            <li class="wqpc_head_info">
                                <a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}" id="m" onMouseOver="showMenu({'ctrlid': 'm',  'ctrlclass': 'hover'});">
                                    <img class="wqpc_head" src="{avatar($_G[uid], small, true)}"/>
                                    <span>$_G[username]</span>
                                    <i class="wqwechat wqwechat-control-arr"></i>
                                </a>
                            </li>
                        <!--{elseif !empty($_G['cookie']['loginuser'])}-->
                            <li><a href="javascript:;"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
                            <!--{if $_G['setting']['seccodedata']['rule']['login']['allow'] == 0 || ($_G['setting']['seccodedata']['rule']['login']['allow'] > 0 && $_GET['mod']!='view')}-->
                                <li><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a></li>
                            <!--{else}-->
                                <li><a href="member.php?mod=logging&action=login" >{lang activation}</a></li>
                            <!--{/if}-->
                            <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
                        <!--{elseif !$_G[connectguest]}-->
                            <style type="text/css">
                                .fastlg_fm{display: none; height: 30px; width:134px; overflow: hidden;margin-right:0px!important; padding-right: 0px!important; border-right: none; margin-top: 6px; float: left}
                                .fastlg_fm a{ padding-right: 5px;}
                            </style>
                            <div style="display:none"><!--{template member/login_simple}--></div>
                            <!--{if $_G['setting']['seccodedata']['rule']['login']['allow']== 0 || ($_G['setting']['seccodedata']['rule']['login']['allow'] > 0 && $_GET['mod']!='view')}-->
                                <li><a href="javascript:;" onClick="showWindow('login', 'member.php?mod=logging&action=login');">{lang login}</a></li>
                            <!--{else}-->
                                <li><a href="member.php?mod=logging&action=login" >{lang login}</a></li>
                            <!--{/if}-->
                            <li><a href="member.php?mod={$_G[setting][regname]}">{$Plang['07f81880af8c9cc4']}</a></li>
                            <li><a href="member.php?mod=logging&action=login&viewlostpw=1" onclick="showWindow('login', this.href)" title="{lang forgotpw}">{lang forgotpw}</a></li>
                        <!--{else}-->
                            <li><a href="home.php?mod=spacecp&ac=usergroup">{$_G[member][username]}</a></li>
                            <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
                        <!--{/if}-->
                        <!--{if in_array($_G['groupid'], $setting['allow_groups']) || in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
                            <li class="wqapply"><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add">{$Plang['9de5414139ecbfb4']}</a></li>
                        <!--{else}-->
                            <li class="wqapply"><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&meun=my_submit">{$Plang['3c93ac86c02f7668']}</a></li>
                        <!--{/if}-->

                    </ul>
                </div>

            </div>
        </header>
        <ul class="down_menu wqpc_down_menu" id="m_menu" style="display: none;">
            <li><!--{hook/global_usernav_extra2}--></li>
            <li><!--{hook/global_usernav_extra3}--></li>
            <!--{if check_diy_perm($topic)}-->
            <li class="dkdiy"><a href="javascript:openDiy();" title="{lang open_diy}">{lang open_diy}</a></li>
            <!--{/if}-->
            <!--{loop $_G['setting']['mynavs'] $nav}-->
            <!--{/loop}-->
            <!--{hook/global_usernav_extra3}-->
            <li class="grsz"><a href="home.php?mod=spacecp">{lang setup}</a></li>
            <!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
            <li class="ypt"><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank">{lang cloudcp}</a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
            <li class="glzx"><a href="admin.php" target="_blank">{lang admincp}</a></li>
            <!--{/if}-->
            <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
            <li class="mhgl"><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
            <!--{/if}-->
            <!--{hook/global_usernav_extra4}-->
            <li class="yhtc"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
        </ul>
        <div class="wqpc_header_height" style="display:none;"></div>
        <script>
            <!--{if $_GET['diy'] == 'yes'}-->
                wqjq(function () {
                    var oh = wqjq('header').offset().top
                    wqjq(document).on('scroll', function () {
                        var st = wqjq(document).scrollTop()
                        if (st >= oh) {
                            wqjq('header').addClass('wqfixed')
                            wqjq('.wqpc_header_height').show()
                        } else {
                            wqjq('header').removeClass('wqfixed')
                            wqjq('.wqpc_header_height').hide()
                        }
                    })
                })
            <!--{else}-->
                wqjq(function () {
                    wqjq('header').addClass('wqfixed')
                    wqjq('.wqpc_header_height').show()
                })
            <!--{/if}-->
        </script>