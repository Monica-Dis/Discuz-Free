<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['id']=='wq_wechatreader' || $_GET['id']=='wq_wechatreader:wq_wechatreader'}-->
    <!--{eval
        $is_system_headbottom = $collecting_setting['is_system_headbottom'];
        $logoname = $collecting_setting['logoname'];
        $topnav = $collecting_setting['topnav'];
        $set_color = $collecting_setting['pc_color'];
	$mainnvid = $collecting_setting['mainnvid'];
        $setting['admingroups'] = $collecting_setting['admingroups'];
        $setting['adminuids'] = $collecting_setting['adminuids'];
        $setting['allow_groups'] = $collecting_setting['allow_groups'];

    }-->
<!--{elseif $_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow'}-->
    <!--{eval
        $is_system_headbottom = $collect_setting['is_system_headbottom'];
        $logoname = $collect_setting['logoname'];
        $topnav = $collect_setting['topnav'];
        $set_color = $collect_setting['pc_color'];
	$mainnvid = $collect_setting['mainnvid'];
        $setting['is_system_headbottom'] = $collect_setting['is_system_headbottom'];
    }-->
<!--{elseif $_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting'}-->
    <!--{eval
        $is_system_headbottom = $setting['is_system_headbottom'];
        $logoname = $setting['logoname'];
        $topnav = $setting['topnav'];
        $set_color = $setting['pc_color'];
	$mainnvid = $setting['mainnvid'];
    }-->
<!--{/if}-->

<!--{if $is_system_headbottom}-->
<!--{template common/header}-->
    <style type="text/css">
        .wp,#wp{ width:1200px!important;}
        .ct2_a .mn{ width:1040px;}
        .wqsysfixed {position: fixed;width: 1200px !important;top: 0;z-index: 10;}
    </style>
    <link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/css/wqpc_wechat.css?{VERHASH}" type="text/css"/>
    <link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/font/iconfont.css" type="text/css"/>
    <script src="./source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
    <script src="./source/plugin/wq_wechatcollecting/static/js/koala.min.1.5.js?{VERHASH}" type="text/javascript"></script>
    <script src="./source/plugin/wq_wechatcollecting/static/js/terminator2.2.min.js?{VERHASH}" type="text/javascript"></script>
    <script src="./source/plugin/wq_wechatcollecting/static/js/video.pc.js?{VERHASH}" type="text/javascript" charset="GBK"></script>
	<!--{if !empty($mainnvid)}-->
    <script>
        var navid = "{$mainnvid}"
        var html = wqjq("#" + navid)
        if (html) {
            var oh = wqjq('#' + navid).offset().top
            wqjq(document).on('scroll', function () {
                var st = Math.max(wqjq(document).scrollTop(), wqjq('body').scrollTop())
                if (st >= oh) {
                    wqjq('#' + navid).addClass('wqsysfixed').prev().css('margin-bottom', '33px')
                } else {
                    wqjq('#' + navid).removeClass('wqsysfixed').prev().css('margin-bottom', '')
                }
            })
        }

    </script>
	<!--{/if}-->
<!--{else}-->
<!--{template wq_wechatcollecting:common/header}-->

<!--{/if}-->

<!--{if $set_color}-->
<!--{template wq_wechatcollecting:common/setcolor}-->
<!--{/if}-->


<!--{template wq_wechatcollecting:common/common_module}-->