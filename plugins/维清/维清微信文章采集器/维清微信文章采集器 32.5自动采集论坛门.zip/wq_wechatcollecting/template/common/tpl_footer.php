<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $is_system_headbottom}-->
    <!--{template common/footer}-->
<!--{else}-->
    <!--{template wq_wechatcollecting:common/footer}-->
<!--{/if}-->
<div class="wqpc_ejectbg" style="display: none;"></div>