<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<style id="diy_style" type="text/css"></style>
<div class="wqpc_wechat_index">
            <!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
			<!--diyarea_1200px-->
            <div class="wqpc_wechat_index_left">
                <!--[diy=diy5]--><div id="diy5" class="area"></div><!--[/diy]-->
				<!--diyarea_860px-->
                <div class="wqpc_wechat_index_banner">
                    <div class="wqpc_wechat_banner_roll">
                        <!--[diy=slideindex]--><div id="slideindex" class="area"></div><!--[/diy]-->
                        <script type="text/javascript">
                            Qfast.add('widgets', {path: "./source/plugin/wq_wechatcollecting/static/js/terminator2.2.min.js", type: "js", requires: ['fx']});
                            Qfast(false, 'widgets', function () {
                                K.tabs({
                                    id: 'wqfsd1',
                                    conId: "wqd1pic1",
                                    tabId: "wqd1fbt",
                                    tabTn: "a",
                                    conCn: '.fcon',
                                    auto: 1,
                                    effect: 'fade',
                                    eType: 'click',
                                    pageBt: true,
                                    bns: ['.prev', '.next'],
                                    interval: 3000
                                })
                            })
                        </script>
                    </div>
                    <div class="wqpc_wechat_banner_pic">
                         <!--[diy=imgindex]--><div id="imgindex" class="area"></div><!--[/diy]-->
                    </div>
                </div>
                <!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
				<!--diyarea_860px-->

                <!--{if $setting[home_navigation]=='2'}-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{else}-->
                    <div class="wqpc_wechat_titlelist">
                        <div class="wqpc_wechat_ass">
                            <div class="wqpc_wechat_ul">
                               <div class="wqpc_wechat_ul_left">
                                    <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatcollecting'; $getlist[mod] = 'list'; $getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <!--{if $list_recommedlist}-->
                                        <!--{eval $recurl = "plugin.php?id=".$_GET['id'];$recurl .= $classid ? '&mod=list&classid='.$classid : '';}-->
                                        <a href="{$recurl}"<!--{if $ordernum == 3}--> class="a"<!--{/if}-->>{$Plang['db11cdebc2eb37bd']}</a>
                                    <!--{/if}-->
                                    <!--{if $list_firstlist}-->
                                        <!--{eval $firsturl = "plugin.php?id=".$_GET['id']."&mod=list&displayorder=4";$firsturl .= $classid ? '&classid='.$classid : '';}-->
                                        <a href="{$firsturl}"<!--{if $ordernum == 4}--> class="a"<!--{/if}-->>{$Plang['0ef1d1c8298846ea']}</a>
                                    <!--{/if}-->
                                    <a href="{$url}"<!--{if $ordernum == 1}--> class="a"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a>
                                    <!--{eval $getlist[displayorder] = 2; $url = 'plugin.php?'.url_implode($getlist);}-->
                                    <a href="{$url}"<!--{if $ordernum == 2}--> class="a"<!--{/if}-->>{$Plang['6959da5d2e80c069']}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <!--{/if}-->
                <!--{template wq_wechatcollecting:common_list}-->
                <!--[diy=diy6]--><div id="diy6" class="area"></div><!--[/diy]-->
				<!--diyarea_860px-->
            </div>
            <div class="wqpc_wechat_index_right">

                <!--{if $setting['is_system_headbottom']==1}-->
                    <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{eval echo common_right_searchoradd();}-->
                <!--{/if}-->

                <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
				<!--diyarea_320px-->
                <!--{eval echo common_right_keyword_hot();}-->

                <!--{if $setting[home_navigation]=='3' && $_GET['mod']!='view'}-->
                    <!--[diy=right2]--><div id="right2" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{/if}-->

                <!--{if $right_recommedlist}-->
                    <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{eval echo common_right_wechat_recommed();}-->
                <!--{/if}-->

                <!--{if $right_collect}-->
                    <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
                <!--{/if}-->

                <!--{if $right_hot}-->
                    <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_hot,$Plang['cd28d8e22cbacebe']);}-->
                <!--{/if}-->

                <!--{if $right_new}-->
                    <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                    <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
					<!--diyarea_320px-->
                <!--{/if}-->
            </div>
        </div>
<!--{template wq_wechatcollecting:common/tpl_footer}-->