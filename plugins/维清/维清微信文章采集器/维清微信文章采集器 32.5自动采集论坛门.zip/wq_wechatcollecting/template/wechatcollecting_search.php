<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<div class="wqpc_wechat_index">
            <!--[diy=search1]--><div id="search1" class="area"></div><!--[/diy]-->
              <!--diyarea_1200px-->
            <div class="wqpc_wechat_index_left">
                <!--[diy=search2]--><div id="search2" class="area"></div><!--[/diy]-->
                  <!--diyarea_860px-->
                <div class="wqpc_wechat_search_input">
                    <form method="get" action="plugin.php" id="searchform">
                        <input type="hidden" name="formhash" value="{FORMHASH}">
                        <input type="hidden" name="id" value="wq_wechatcollecting" id="pluginid">
                        <input type="hidden" name="mod" value="search">
                        <input type="hidden" name="searchform" value="true">
                        <input type="text" class="wqpc_input" placeholder="{$Plang['509ae8eac3b2e5cd']}" value="{$keyword}" name="keyword" maxlength="400"/>
                        <a class="wqpc_close" href="javascript:;">
                            <i class="wqwechat wqwechat-x wq_f20"></i>
                        </a>
                        <button type="button" onclick="check_search_keyword('wq_wechatcollecting')" class="wqpc_btn_la">{$Plang['4cb9e8721e550eb0']}</button>
                        <!--{if $plugin_wechatshow && $w_searchset['status']}-->
                        <button type="button" onclick="check_search_keyword('wq_wechatshow')" class="wqpc_btn_ba" id="wechatwearch">{$Plang['c9bc3705598eff5c']}</button>
                        <!--{/if}-->
                    </form>
                </div>
                <!--[diy=search3]--><div id="search3" class="area"></div><!--[/diy]-->
                  <!--diyarea_860px-->
                <!--{if $keyword}-->
                    <div class="wqpc_wechat_search_result">
                        <span class="wqtext">{$Plang['df810dc4a0373d06']}{$count}{$Plang['f720a4ea76074255']}"<i>{$keyword}</i>"{$Plang['334a2a91112df0b4']}</span>
                        <!--{if !empty($list) && $plugin_wechatreader==1}-->
                        <span class="y wqpc_see_term"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=read">{$Plang['cb0451b01484e7ef']}</a></span>
                            <!--{if $status==1}-->
                            <span class="y wqpc_search_term2"><i class="wqwechat wqwechat-o3 wq_f12"></i> {$Plang['dbb4e378b0511ad5']}</span>
                            <!--{else}-->
                            <span class="y wqpc_search_term" id='search_keyword_subscription'><a onclick="showWindow(this.id, this.href, 'get', 0);" id="subscription" href="plugin.php?id=wq_wechatreader&mod=ajax&keyword=$keyword&ac=subscription">{$Plang['2f1819d9cd1d2ddf']}</a></span>
                            <!--{/if}-->
                        <!--{/if}-->
                    </div>
                    <!--{template wq_wechatcollecting:common_list}-->
                <!--{/if}-->
               <!--[diy=search4]--><div id="search4" class="area"></div><!--[/diy]-->
                 <!--diyarea_860px-->
            </div>
             <div class="wqpc_wechat_index_right">

                <!--{if $setting['is_system_headbottom']==1}-->
                    <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
                      <!--diyarea_320px-->
                    <!--{eval echo common_right_searchoradd();}-->
                <!--{/if}-->

                <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
                 <!--diyarea_320px-->
                <!--{eval echo common_right_keyword_hot();}-->

                <!--{if $setting[home_navigation]=='3' && $_GET['mod']!='view'}-->
                    <!--[diy=right2]--><div id="right2" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{template wq_wechatcollecting:common_classnav}-->
                <!--{/if}-->

                <!--{if $right_recommedlist}-->
                    <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{eval echo common_right_wechat_recommed();}-->
                <!--{/if}-->

                <!--{if $right_collect}-->
                    <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
                <!--{/if}-->

                <!--{if $right_hot}-->
                    <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_hot,$Plang['cd28d8e22cbacebe']);}-->
                <!--{/if}-->

                <!--{if $right_new}-->
                    <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                    <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                <!--{/if}-->
            </div>
        </div>

    <script type="text/javascript">
        var subslang = '{$Plang[dbb4e378b0511ad5]}';

        function check_search_keyword(identifier){
            identifier = identifier ? identifier : 'wq_wechatcollecting';
            var keyword = wqjq(".wqpc_input").val();;
            if(!keyword){
                showDialog('&#35831;&#36755;&#20837;&#20851;&#38190;&#23383;', null, null, null, null, null, null, null, null, 2, null)
                return;
            }
            if(identifier){
                wqjq("#pluginid").val(identifier);
            }
            wqjq("#searchform").submit();
        }
        wqjq('.wqpc_wechat_search_input').on('click','.wqpc_close',function(){
            wqjq('.wqpc_input').val('');
        });

        function subscription_keyword(){
            wqjq("#search_keyword_subscription").attr('class','y wqpc_search_term2').html('<i class="wqwechat wqwechat-o3 wq_f12"></i> '+subslang);
        }

    </script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->