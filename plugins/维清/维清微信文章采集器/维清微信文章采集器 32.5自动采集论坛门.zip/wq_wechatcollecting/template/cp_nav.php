<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval $tpldir = wq_wechatcollecting_get_pc_tpldir();}-->
<!--{if $tpldir == './template/dzapp2017'}-->
    <style>#hd{ background-color: #fff;}</style>
<!--{/if}-->
<style>body{background-color: #f0f4fb;}</style>

<h2 class="wqpc_managezx">{$Plang['255937b93818f362']}</h2>
<ul>
     <!--{if in_array($_G['groupid'], $setting['allow_groups']) || in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
    <li<!--{if $_GET['op'] == 'add'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=add">{$Plang['ab6b2e0930f61299']}</a></li>
    <!--{/if}-->
    <li<!--{if $_GET['meun'] == 'my_renling'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list&meun=my_renling">{$Plang['f774901d17cae8f1']}</a></li>
    <li<!--{if $_GET['meun'] == 'my_submit'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list&meun=my_submit">{$Plang['dde343556ea0716c']}</a></li>
    <!--{if in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
    <li<!--{if !$_GET['meun'] && $_GET['op'] == 'list' && $ac != 'articlemanage' && $ac != 'keywordcollect' && $ac != 'urlcollect'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list">{$Plang['a2963175c4f5a0ca']}</a></li>
    <!--{/if}-->
    <!--{if $show_renling}-->
    <li<!--{if $ac == 'articlemanage' && !$_GET['type']}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage">{$Plang['0f16a714bd240ef6']}</a></li>
    <li<!--{if $ac == 'articlemanage' && $_GET['type']}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&type=templist">{$Plang['60e3d2ff55f0dca3']}</a></li>
    <!--{/if}-->
    <!--{if in_array($_G['uid'], $setting['adminuids']) || in_array($_G['groupid'], $setting['admingroups'])}-->
    <li<!--{if $ac == 'keywordcollect'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=keywordcollect">{$Plang['710a638fcce90598']}</a></li>
    <li<!--{if $ac == 'urlcollect'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=urlcollect">{$Plang['3e1083c0ed42484a']}</a></li>
    <!--{/if}-->
    <!--{if $plugin_wechatreader}-->
        <!--{loop $my_center $key $nav}-->
            <!--{if $key=='focus'}-->
                <!--{eval $wechatreaderac='&op=article&type=first';}-->
            <!--{/if}-->
        <li><a href="plugin.php?id=wq_wechatreader&mod=index&ac={$key}{$wechatreaderac}">{$Plang[$nav]}</a></li>
        <!--{/loop}-->
    <!--{/if}-->
</ul>