<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<style id="diy_style" type="text/css"></style>
<style>
    .wqpc_con img {
        margin-bottom: 8px;
    }
    .wqpc_con pre {
        white-space: normal;
    }
</style>
<div class="wqcrumbs_menu">
    <a href="{$_G['siteurl']}"><span class="wqwechat wqwechat-shouye2"></span></a><i class="wqwechat wqwechat-jiantou-copy"></i>
      <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatcollecting'; $getlist[mod] = 'list'; $getlist[classid] = $content['classid'];  $url = 'plugin.php?'.url_implode($getlist);}-->
    <a href="{$url}">{$classname}</a><i class="wqwechat wqwechat-jiantou-copy"></i>{$Plang['97fc27d389949b94']}
</div>
<div class="wqpc_wechat_index wqm_top0">
    <!--[diy=view1]--><div id="view1" class="area"></div><!--[/diy]-->
    <!--diyarea_1200px-->
    <div class="wqpc_wechat_index_left">
        <!--[diy=view2]--><div id="view2" class="area"></div><!--[/diy]-->
        <!--diyarea_860px-->
        <div class="wqpc_wechat_view_suspension">
            <ul>

				<!--{if $content[uid] == $_G['uid'] || in_array($_G['groupid'],$setting['admingroups']) || in_array($_G['uid'],$setting['adminuids'])}-->
					<!--{if $plugin_wq_editor == '1'}-->
						<li class="wqpc_edit"><a target="_blank" href="plugin.php?id=wq_wechatcollecting&mod=edit&articleid=$content[articleid]" class='edit_article'><i class="wqwechat wqwechat-bianji wq_f24"></i><br>{$Plang['9a150d4af72d7358']}</a></li>
					<!--{/if}-->
					<li class="wqpc_edit"><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&step=del&articleid=$content[articleid]" class='del'><i class="wqwechat wqwechat-shanchu wq_f26"></i><br>{$Plang['0d9efacf5089d88c']}</a></li>
				<!--{/if}-->

                <!--{if $plugin_wechatreader}-->
                    <!--{if !$_G['uid']}-->
                        <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                    <!--{/if}-->

                    <!--{eval $liclass = 'wqpc_collection2'; $ac='canclecollect'; $isview='';}-->
                    <!--{if !in_array($content[articleid],$favorites)}-->
                        <!--{eval $liclass = 'wqpc_collection'; $ac='collect'; $isview=1;}-->
                    <!--{/if}-->
                    <li class="{$liclass}" id='viwetop_favorites'>
                        <a<!--{if !$logininfo}--> id="hem_reader_favorites_{$content[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac={$ac}&aid={$content[articleid]}&isview={$isview}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-shoucang wq_f28"></i><br/>{$Plang['23393395a9152c6f']}</a>
                    </li>
                <!--{/if}-->

                <!--{if $_G['uid'] && (in_array($_G['uid'], $setting['adminuids']) || $_G['uid'] == $wechatinfo['maintain_uid'] || in_array($_G['groupid'], $setting['admingroups']))}-->
                    <!--{if !$content['recommend'] && !$content['admrecommend']}-->
                        <li class="wqpc_recommendline <!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_recommend2<!--{else}-->wqpc_recommend<!--{/if}-->">
                            <a id="articled_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=recommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian2 wq_f28"></i><br/>{$Plang['db11cdebc2eb37bd']}</a>
                        </li>
                    <!--{elseif $content['recommend'] && $content['admrecommend']}-->
                        <li class="wqpc_recommendline<!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_cancelrecommend<!--{/if}-->">
                            <a id="cancel_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=cancelrecommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian wq_f28"></i><br/>{$Plang['dd21ec1b2d3f0949']}</a>
                        </li>
                    <!--{else}-->
                        <!--{if !in_array($_G['uid'], $setting['adminuids']) && !in_array($_G['groupid'], $setting['admingroups'])}-->
                            <!--{if !$content['recommend']}-->
                                <li class="wqpc_recommendline<!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_recommend2<!--{else}-->wqpc_recommend<!--{/if}-->">
                                    <a id="articled_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=recommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian2 wq_f28"></i><br/>{$Plang['db11cdebc2eb37bd']}</a>
                                </li>
                            <!--{else}-->
                                <li class="wqpc_recommendline<!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_cancelrecommend<!--{/if}-->">
                                    <a id="cancel_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=cancelrecommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian wq_f28"></i><br/>{$Plang['dd21ec1b2d3f0949']}</a>
                                </li>
                            <!--{/if}-->
                        <!--{else}-->
                            <li class="wqpc_recommendline<!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_recommend2<!--{else}-->wqpc_recommend<!--{/if}-->">
                                <a id="articled_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=recommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian2 wq_f28"></i><br/>{$Plang['db11cdebc2eb37bd']}</a>
                            </li>
                            <li class="wqpc_recommendline<!--{if $content['admrecommend'] || $content['recommend']}--> wqpc_cancelrecommend<!--{/if}-->">
                                <a id="cancel_recommend" href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=cancelrecommend&aid={$content[articleid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqwechat wqwechat-tuijian wq_f28"></i><br/>{$Plang['dd21ec1b2d3f0949']}</a>
                            </li>
                        <!--{/if}-->
                    <!--{/if}-->
                <!--{/if}-->
                <li class='article_share'><a href="javascript:;"><i class="wqwechat wqwechat-fenxiang2 wq_f24"></i><br/>{$Plang['dae251a4f8687b1c']}</a>
                    <div class="article wqbdsharebuttonbox bdsharebuttonbox articleshared_{$content[articleid]} wqpc_xq_topshare" data-tag="share_1" style="display: none;">
                       <a class="bds_tsina " data-cmd="tsina"></a>
                       <a class="bds_qzone " data-cmd="qzone" href="#"></a>
                       <a class="bds_weixin " data-cmd="weixin"></a>
                       <a class="bds_sqq " data-cmd="sqq"></a>
                       <a class="bds_tieba " data-cmd="tieba"></a>
                       <a class="bds_more "  data-cmd="more"></a>
                    </div>
                </li>
            </ul>
        </div>
        <div class="wqpc_wechat_view">
            <h3 class="wqpc_title">{$content['title']}</h3>
            <p class="wqpc_info">{$date}<span style="margin-left: 20px;">{$Plang['a6aa5366e09f370c']} {$content['views']}  </span>
                <span>
                    <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $content['wechatid'];  $getlist[displayorder] = 'index';  $url = 'plugin.php?'.url_implode($getlist);}-->
                    <a href="{$url}" target="_blank">{$content['name']}</a>
                </span>

                <!--{if $setting['show_my_attention']}-->
                    <span class="wqfollow">
                        <a id="post-user" href="javascript:;">{$Plang['8ef952fcecabe5b4']}</a>
                        <div class="profile_container" style="display: none;">
                            <div class="profile_inner"><strong class="profile_nickname">{$content['name']}</strong>
                                <img class="profile_avatar" id="js_profile_qrcode_img" src="{$wechat['qrcode']}"/>
                                <p class="profile_meta">
                                    <label class="profile_meta_label">{$Plang['4b3b548154549518']}</label>
                                    <span class="profile_meta_value">{$content['wechatid']}</span>
                                </p>
                                <p class="profile_meta">
                                    <label class="profile_meta_label">{$Plang['a19085767b52c6d7']}</label>
                                    <span class="profile_meta_value">{$wechat['intro']}</span>
                                </p>
                            </div>
                        </div>
                    </span>
                <!--{/if}-->
            </p>
            <div class="wqpc_con" data-artid="{$content[articleid]}">
                {$content['content']}
            </div>
            <!--[diy=view3]--><div id="view3" class="area"></div><!--[/diy]-->
            <!--diyarea_860px-->
            <!--{if !$_G['uid']}-->
                <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
            <!--{/if}-->
            {$wqreward_but}
            <div class="wqpc_dianzan">
                <ul>
                    <!--{if !in_array($content[articleid],$favorites)}-->
                        <li id="aid_{$content[articleid]}">
                            <a <!--{if !$logininfo}-->id="reader_favorites_{$content[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$content[articleid]}&isview=1"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);">
                                <i class="wqwechat wqwechat-favorite"></i>
                                {$Plang['23393395a9152c6f']}
                            </a>
                        </li><!-- �ղ�ǰ-->
                    <!--{else}-->
                        <li id="aid_{$content[articleid]}">
                            <a <!--{if !$logininfo}-->id="reader_favorites_{$content[articleid]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid={$content[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);">
                                <i class="wqwechat wqwechat-shoucang"></i>
                                {$Plang['23393395a9152c6f']}
                            </a>
                        </li><!-- �ղغ�-->
                    <!--{/if}-->

                    <li>
                        <a <!--{if !$logininfo}-->href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articlesupport&aid={$content[articleid]}" id="articlesupport_{$content[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);">
                            <i class="wqwechat  <!--{if !in_array($content[articleid],$articlesupport)}-->wqwechat-zan1<!--{else}--> wqwechat-zan2<!--{/if}-->"></i>
                            {$Plang['4d3aee3cefdbf4b8']}(<span id="supportnum_{$content[articleid]}">{$content[support]}</span>)
                        </a>
                    </li>
                    <li>
                        <a <!--{if !$logininfo}-->href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articleagainst&aid={$content[articleid]}" id="articleagainst_{$content[articleid]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);" class="wqother">
                           <i class="wqwechat <!--{if !in_array($content[articleid],$articleagainst)}-->wqwechat-diancai<!--{else}-->wqwechat-cai<!--{/if}-->"></i>
                            {$Plang['44df76f6b567d500']}(<span id="againstnum_{$content[articleid]}">{$content[against]}</span>)
                        </a>
                    </li>
                </ul>
            </div>
            <!--{if $lastaid}-->
            <p><a href="plugin.php?id=wq_wechatcollecting&mod=view&articleid={$lastaid[articleid]}">{$Plang['8dccd8233557b4aa']}{$lastaid['title']}</a></p>
            <!--{/if}-->
            <!--{if $nextaid}-->
            <p><a href="plugin.php?id=wq_wechatcollecting&mod=view&articleid={$nextaid[articleid]}">{$Plang['7e2890e74680b8e9']}{$nextaid['title']}</a></p>
            <!--{/if}-->
            <div class="wqpc_operation">
                <span class="wqpc_share article_share"><em class="wqpc_share_xq">{$Plang['4d3ba91835492030']}:</em>
                   <span class="article wqbdsharebuttonbox bdsharebuttonbox articleshared_{$content[articleid]} wqpc_share_warp2" data-tag="share_1">
                        <a class="bds_tsina " data-cmd="tsina"></a>
                        <a class="bds_qzone " data-cmd="qzone" href="#"></a>
                        <a class="bds_weixin " data-cmd="weixin"></a>
                        <a class="bds_sqq " data-cmd="sqq"></a>
                        <a class="bds_tieba " data-cmd="tieba"></a>
                        <a class="bds_more "  data-cmd="more"></a>
                     </span>

                </span>
            </div>
            <!--[diy=view5]--><div id="view5" class="area"></div><!--[/diy]-->
             <!--diyarea_860px-->
            <!--{if $join_list}-->
            <div class="wqpc_wechat_relevant_article">
                <h3>{$Plang['815a1f2328d92c06']}</h3>
                <ul>
                    <!--{loop $join_list $key $val}-->
                    <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
                    <li><em></em><a href="{$url}" target="_blank">{$val['title']}</a><span><!--{eval echo date('Y-m-d',$val['date']);}--></span></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <!--[diy=view6]--><div id="view6" class="area"></div><!--[/diy]-->
            <!--diyarea_860px-->
            <!--{/if}-->
            <!--{if $you_recommedlist}-->
             <div class="wqpc_wechat_recommend">
                 <h3>{$Plang['c2a0bd1f089ab8ed']}</h3>
                <ul>
                    <!--{loop $you_recommedlist $key $val}-->
                    <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->
                    <li>
                        <a href="{$url}" target="_blank">
                        <div class="wq_img wqlazydiv"><img wqdata-src="{$val[imglink]}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                        <div class="wqtext">
                            <h4>{$val['title']}</h4>
                            <p class="wqjianjie">{$val['summary']}</p>
                            <p class="wqtime"><!--{eval echo date('Y-m-d',$val['date']);}--></p>
                           </div>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
            <!--[diy=view7]--><div id="view7" class="area"></div><!--[/diy]-->
             <!--diyarea_860px-->
            <!--{/if}-->
        </div>
    </div>
     <div class="wqpc_wechat_index_right">

                <!--{if $setting['is_system_headbottom']==1}-->
                    <!--[diy=right1]--><div id="right1" class="area"></div><!--[/diy]-->
                     <!--diyarea_320px-->
                    <!--{eval echo common_right_searchoradd();}-->
                <!--{/if}-->

                <!--[diy=right8]--><div id="right8" class="area"></div><!--[/diy]-->
                <!--diyarea_320px-->
                <!--{eval echo common_right_keyword_hot();}-->


                <!--{if $right_recommedlist}-->
                    <!--[diy=right3]--><div id="right3" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_wechat_recommed();}-->
                <!--{/if}-->

                <!--{if $right_first}-->
                    <!--[diy=right4]--><div id="right4" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_first_article();}-->
                <!--{/if}-->

                <!--{if $right_collect}-->
                    <!--[diy=showright9]--><div id="showright9" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_collect,$Plang['de00fb3db3329cbe'],true);}-->
                <!--{/if}-->

                <!--{if $right_hot}-->
                    <!--[diy=right5]--><div id="right5" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_maximg();}-->
                <!--{/if}-->

                <!--{if $right_new}-->
                    <!--[diy=right6]--><div id="right6" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                    <!--{eval echo common_right_article_minimg($right_new,$Plang['06ea5714cc8523ae']);}-->
                    <!--[diy=right7]--><div id="right7" class="area"></div><!--[/diy]-->
                    <!--diyarea_320px-->
                <!--{/if}-->
            </div>
</div>
<div class="bdselect"></div>
<div class="bdshare_title" style="display:none">{$content['title']}</div>
<div class="bdshare_desc" style="display:none">{$content['summary']}</div>
<script id="sharebd"></script>

<script type="text/javascript">
    var tem_plang ="{$Plang['23393395a9152c6f']}";
    <!--{if $setting['show_my_attention']}-->
        wqjq('#post-user').click(function () {
            wqjq('.profile_container').show();
        });
        wqjq('*').click(function (event) {
            var target = wqjq(event.target);
            if (target.attr("class") == 'profile_meta_label' || target.attr("class") == 'profile_meta_value' || target.attr("class") == 'profile_nickname' || target.attr("class") == 'profile_meta' || target.attr("class") == 'profile_inner' || target.attr("class") == 'profile_avatar') {
                wqjq(".profile_container").show();
            } else {
                if (target.attr("id") == 'post-user') {
                    wqjq(".profile_container").show();
                } else {
                    wqjq(".profile_container").hide();
                }
            }
        });
    <!--{/if}-->
    wqjq(function() {
        wqjq(".wqpc_con *").css("margin-top",0).css("margin-bottom",0);

        var protocol = location.protocol
        var sharebd = {
            id: '',
            bdPic: '',
            bdText: '',
            bdDesc: '',
            url: '',
            bdUrl: ''
        }
        sharebd.id = '{$content[articleid]}'
        sharebd.bdPic = "{$content['imglink']}"
        sharebd.bdText = wqjq(".bdshare_title").text()
        sharebd.bdDesc = wqjq(".bdshare_desc").text()
        sharebd.url = window.location.href
        if (sharebd.url.match(/^(http)/)) {
            sharebd.bdUrl = sharebd.url
        } else {
            sharebd.bdUrl = "{$_G['siteurl']}" + sharebd.url
        }
        window._bd_share_config = {
            common: {
                bdText: sharebd.bdText,
                bdDesc: sharebd.bdDesc,
                bdUrl: sharebd.bdUrl,
                bdPic: sharebd.bdPic,
            },
        share: [{
            "bdSize": 16
        }],
        selectShare: [{
            "bdSelectMiniList": ['tsina', 'qzone', 'weixin', 'sqq', 'tieba'],
            "bdContainerClass": null
        }]
        }
        if (protocol == 'https:') {
            wqjq('#sharebd').prop('src', './source/plugin/wq_wechatcollecting/static/js/bdshare.js?{VERHASH}')
        } else {
            wqjq('#sharebd').prop('src', 'http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5))
        }

        wqjq('.wqpc_wechat_view_suspension .article_share').on('mouseenter', function () {
            wqjq('.wqpc_wechat_view_suspension .article_share').addClass('wqopen')
        })

        wqjq('.wqpc_wechat_view_suspension .article_share').on('mouseleave', function () {
            if (wqjq(".wqpc_wechat_view_suspension .articleshared_" + sharebd.id).is(':hidden')) {
                wqjq('.wqpc_wechat_view_suspension .article_share').removeClass('wqopen')
            }
        })

        wqjq('.wqpc_wechat_view_suspension .article_share').on('click', function () {
            if (wqjq(".wqpc_wechat_view_suspension .articleshared_" + sharebd.id).is(':hidden')) {
                for (var i = 0; i < wqjq(".articleshared_" + sharebd.id + " a").length; i++) {
                    if (!wqjq(".articleshared_" + sharebd.id + " a").eq(i).prop('class')) {
                        wqjq(".articleshared_" + sharebd.id + " a").eq(i).hide()
                    }
                }
                wqjq(".wqpc_wechat_view_suspension .articleshared_" + sharebd.id).show()
            } else {
                wqjq(".wqpc_wechat_view_suspension .articleshared_" + sharebd.id).hide()
                wqjq('.wqpc_wechat_view_suspension .article_share').removeClass('wqopen')
            }
        })

        wqjq(".del").click(function () {
            if (confirm('{$Plang['645279fde5e34abd']}')) {
                return true
            } else {
                return false
            }
        })
    })

    function canclecollect(aid) {
        wqjq("#viwetop_favorites").attr('class','wqpc_collection')
        wqjq("#viwetop_favorites a").attr('href','plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&isview=1&aid=' + aid)
        wqjq("#aid_" + aid + " a").replaceWith("<a id='reader_favorites_" + aid + "' href='plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&isview=1&aid=" + aid + "' onclick='showWindow(this.id, this.href, \"get\", 0);'><i class='wqwechat wqwechat-favorite'></i>{$Plang['23393395a9152c6f']}</a>");
    }

    function articlesupport(aid){
        wqjq("#articlesupport_" + aid + " i:first-child").attr('class','wqwechat wqwechat-zan2')
        var support_num = parseInt(wqjq("#supportnum_" + aid).html()) + 1
        wqjq("#supportnum_"+aid).html(support_num)
    }

    function articleagainst(aid){
       wqjq("#articleagainst_" + aid + " i:first-child").attr('class','wqwechat wqwechat-cai')
       var against_num = parseInt(wqjq("#againstnum_"+aid).html()) + 1
       wqjq("#againstnum_" + aid).html(against_num)
    }
    function maintain_recommend_set(msg){
        setTimeout(function() {
            window.location.href = location.href;
	}, '1500');
    }
</script>

<!--{template wq_wechatcollecting:common/tpl_footer}-->