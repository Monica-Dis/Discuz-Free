<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/header}-->
<div class="wqpc_ejectbg_warp" id="new_favorites">
    <h3 class="wqpc_title"><!--{if $_GET['ac'] == 'recommend'}-->{$Plang['d784ce603f23776b']}<!--{else}-->{$Plang['c9f2f5ffdfb3c36a']}<!--{/if}--><span class="y" onclick="hide_window('$_GET['handlekey']')"><i class="close_favorites wqwechat wqwechat-close wq_f18"></i></span></h3>
    <form method="post" id="recommendset" action="plugin.php?id=wq_wechatcollecting&mod=ajax&ac={$_GET[ac]}" onsubmit="ajaxpost('recommendset', 'return_favorites', 'return_favorites', 'onerror');return false;">
        <input type="hidden" name="recommendsub" value="true">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="aid" value="{$aid}" />
        <input type="hidden" name="handlekey" value="recommendset" />
        <input type="hidden" id="list_recommend" name="list_recommend" value="{$article['admrecommend']}" />
        <input type="hidden" id="view_recommend" name="view_recommend" value="{$article['recommend']}" />
        <ul class="wqpc_ejectbg_ul wqpc_ejectbg_icon">
            <!--{loop $recommendinfo $key $val}-->
            <li recommendsite="{$key}">
                <!--{if $val['isrecommen']}-->
                <i class="wqwechat wqwechat-o3"></i>
                <!--{/if}-->
                <h3>{$val['name']}</h3>
            </li>
            <!--{/loop}-->
        </ul>
        <div class="wqpc_ejectbg_btn">
            <button type="submit">{$Plang['6ce0cdd2f7c855aa']}</button>
            <a href="javascript:;" class="close_favorites" onclick="hide_window('$_GET['handlekey']')">{$Plang['9c825be7149e5b97']}</a>
        </div>
    </form>
</div>
<script type="text/javascript" reload="1">
    wqjq(document).ready(function() {
        wqjq("body").addClass("body_overflow");
        wqjq(".wqpc_ejectbg_ul > li").bind('click',function(){
            var flag = wqjq(this).find("i").get(0);
            var key = wqjq(this).attr('recommendsite');
            if(flag){
                wqjq(this).find("i").get(0).remove();
                wqjq("#"+key+"_recommend").val(0);
            }else{
                wqjq("#"+key+"_recommend").val(1);
                wqjq(this).prepend("<i class='wqwechat wqwechat-o3'></i>");
            }
            wqjq("#favoritesid").val(parseInt(wqjq(this).attr("favoritesid")));
        });
    });

    function hide_window(id){
        hideWindow(id);
        wqjq("body").removeClass("body_overflow");
    }

    function errorhandle_recommendset(){
        setTimeout(function() {
            window.location.href = location.href;
	}, '1500');
    }

</script>
<!--{template wq_wechatcollecting:common/footer}-->