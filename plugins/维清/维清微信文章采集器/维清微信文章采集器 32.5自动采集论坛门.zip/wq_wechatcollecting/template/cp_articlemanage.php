<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<script src="./source/plugin/wq_wechatcollecting/static/js/common.js?{VERHASH}" charset="{CHARSET}" type="text/javascript"></script>
<style>

    .dt th{ text-align: center;}
    .pn{margin-left: 20px;}
    .oneredio{margin-left: 10px;}
    .radio{cursor: pointer;vertical-align:sub;}
</style>

<div class="wq_wechat_per">
    <div class="wq_wechat_per_list">
       <!--{template wq_wechatcollecting:cp_nav}-->
    </div>
    <div class="wq_wechat_per_con">
        <div class="wqpc_wechat_apply">
            <div class="wqpc_title">
                <ul>
                    <li <!--{if $status==array()}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&type={$_GET[type]}">{$Plang['660396e5d283970b']}</a></li>
                    <li <!--{if $_GET['status']=='1'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=1&type={$_GET[type]}">{$Plang['d4cd6471a700d52c']}</a></li>
                    <li <!--{if $_GET['status']=='0'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=0&type={$_GET[type]}">{$Plang['05df925dd69b4333']}</a></li>
                    <li <!--{if $_GET['status']=='-1'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&status=-1&type={$_GET[type]}">{$Plang['b5d0d1b6c49b2665']}</a></li>
                </ul>
            </div>
            <div class="wqpc_con wqpc_con_padding">
            <form name="post" action="plugin.php?id=wq_wechatcollecting" method="post">
                <input type='hidden' name='mod' value="cp">
                <input type='hidden' name='ac' value="articlemanage">
                <input type='hidden' name='step' value="switchrecommend">
                <input type='hidden' name='status' value="{$_GET[status]}">
                <input type='hidden' name='page' value="{$_GET[page]}">
                <table class="dt mtm" style="text-align: center;">
                    <tr>
                        <!--{if !$_GET['type'] || $_GET['type'] !='templist'}-->
                        <th width="30"></th>
                        <!--{/if}-->
                        <th width="100">{$Plang['97af7ca7730595cd']}</th>
                        <th width="100">{$Plang['279448f0857a2b24']}</th>
                        <th>{$Plang['0b3d6ba0ad26e11e']}</th>
                        <!--{if !$_GET['type'] || $_GET['type'] !='templist'}-->
                        <th width="140">{$Plang['1dbc210f8b66dfd2']}</th>
                        <!--{/if}-->
                        <th width="80">{$Plang['e5d945ff5448fd01']}</th>
                        <th width="80">{$Plang['c8b66064ce323401']}</th>
                        <th width="80" >{$Plang['ca5a0d75b677d381']}</th>
                    </tr>
                    <!--{loop $list $key $value}-->
                    <!--{if $_GET['type'] && $_GET['type'] == 'templist'}-->
                    <!--{eval $html=" href='javasrcipt:;'"}-->
                    <!--{else}-->
                    <!--{eval $html=" target='_blank' href='".wq_common_article_view_url($setting,$value['articleid'],$value['tid'],$value['aid'])."'";}-->
                    <!--{/if}-->
                    <tr class="trstyle">
                        <!--{if !$_GET['type'] || $_GET['type'] !='templist'}-->
                            <td>
<!--                                <input class="checks" type='checkbox' name='articleids[{$value[articleid]}]' value='1' style='cursor:pointer;'>-->
                                    <input type="checkbox" class="checks weui_check_z" name="articleids[{$value[articleid]}]" id="articleids[{$value[articleid]}]" value='1' style='cursor:pointer;'>
                                <label class="weui_check_label_z" for="articleids[{$value[articleid]}]"><i class="wqwechat weui_icon_checked_z wq_f14"></i></label>
                            </td>
                        <!--{/if}-->
                        <td>
                            <a target="_blank" href="plugin.php?id=wq_wechatshow&mod=view&wid={$value[wechatid]}&displayorder=index">{$value[name]}<br>{$value[wechatid]}</a>
                        </td>
                        <td>
                            <!--<a target="_blank" href="$url"><img src="{$value['imglink']}" style="width:80px; height:80px;" /></a>-->
                            <a<!--{eval echo $html;}-->  class="wqlazydiv" style="width:80px; height:80px; display:block;" >
                                <img wqdata-src="{$value['imglink']}" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/>
                            </a>
                        </td>
                        <td>
                            <a<!--{eval echo $html;}--> title="$value[title]">{$value['title']}</a>
                        </td>
                        <!--{if !$_GET['type'] || $_GET['type'] !='templist'}-->
                        <td>
                            <!--{if $value['recommend']}-->
                            {$Plang['b4b0d4ba96890702']}<br />
                            (<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&aid={$value['articleid']}&step=recommend&status={$_GET[status]}&page={$_GET[page]}"><font color="#0099CC">{$Plang['9c825be7149e5b97']}</font></a>)
                            <!--{else}-->
                            {$Plang['77b41af77fe3ce13']}<br />
                            (<a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&aid={$value['articleid']}&step=recommend&status={$_GET[status]}&page={$_GET[page]}"><font color="#FF9300">{$Plang['876bb8031df32628']}</font></a>)
                            <!--{/if}-->

                        </td>
                        <!--{/if}-->
                        <td>
                            <!--{eval echo $date=date("Y-m-d H:i:s", $value['date']);}-->
                        </td>
                        <td>
                            <!--{eval echo $collecttime=date("Y-m-d H:i:s", $value['collecttime']);}-->
                        </td>
                        <td>
                            <!--{eval echo get_wechat_status($value[status])}--><br/>
                            <!--<a href="">{lang edit}</a>|-->
                            <a class="del" href='plugin.php?id=wq_wechatcollecting&mod=cp&ac=articlemanage&step=del&articleid={if $_GET[type] == templist}{$value[id]}{else}{$value[articleid]}{/if}&type={$_GET[type]}'  >{$Plang['0d9efacf5089d88c']}</a>
                        </td>
                    </tr>
                    <!--{/loop}-->
                    <!--{if $list && (!$_GET['type'] || $_GET['type'] !='templist')}-->
                        <tr>
                            <td colspan="8" align='left'>
                                <span style='cursor:pointer;' onclick="collecting_selectall(this)">
                                    <!--<input type='checkbox' name='checkall'  id="coll_checkall" style='cursor:pointer;' onclick="collecting_selectall(this)">-->
                                 <input type="checkbox" class="checks weui_check_z" name="checkall" id="coll_checkall" onclick="collecting_selectall(this)"style='cursor:pointer;'>
                                <label class="coll_checkall" for="articleids[{$value[articleid]}]"><i class="wqwechat weui_icon_checked_z wq_f14"></i></label>
                                {$Plang['8dfe4b30674494c1']}
                                </span>

                                <input type="radio" name="recommend" class="pr weui_check" id="join" value="1"/>
                                <label class="weui_check_label" for="join"><i class="wqwechat weui_icon_checked" style='margin-left:20px;'></i>{$Plang['95b79c57699744a7']}</label>

                                <input type="radio" name="recommend" class="pr weui_check" id="cancel" value="0" />
                                <label class="weui_check_label" for="cancel"><i class="wqwechat weui_icon_checked" style='margin-left:20px;'></i>{$Plang['dd21ec1b2d3f0949']}</label>
                                <span class="wqpc_allinput"><button type="submit"><strong>{lang submit}</strong></button></span>
                            </td>
                        </tr>
                    <!--{/if}-->
                </table>
            </form>
                </div>
            <!--{if $multi}--><div class="wqwechat_page pgs mtn cl wqpage">$multi</div><!--{/if}-->

        </div>
    </div>
</div>
<script type="text/javascript">
    var Is_recycle_bin = '{$Plang['645279fde5e34abd']}';
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->