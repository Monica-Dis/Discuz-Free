<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval $_GET['id'] = explode(':', $_GET['id']);$_GET['id'] = $_GET['id'][0];}-->
<!--{if $setting[home_navigation]=='2'}-->
    <div class="wqpc_wechat_titlelist">
        <div class="wqpc_wechat_ass">
            <div class="wqpc_wechat_ul">
                <div class="wqpc_wechat_ul_left">
                    <a href="plugin.php?id={$_GET['id']}:{$_GET['id']}"<!--{if !$classid}--> class="a"<!--{/if}-->>{$Plang['8dfe4b30674494c1']}</a>
                    <!--{loop $nav_classlist $key $val}-->
                        <!--{if $val['status']==1}-->
                            <!--{eval $getlist = array(); $getlist[id] = $_GET['id']; $getlist[mod] = 'list'; $getlist[classid] = $key; $url = 'plugin.php?'.url_implode($getlist);}-->
                            <!--{if $val['linkurl']}-->
                               <a href="{$val['linkurl']}" target="_blank">{$val['classname']}</a>
                            <!--{else}-->
                               <a href="{$url}"<!--{if $classid==$key}--> class="a"<!--{/if}-->>{$val['classname']}</a>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/loop}-->
                </div>

            </div>
        </div>
         <div class="wqpc_wechat_ass_er">
            <!--{eval $getlist = array(); $getlist[id] = $_GET['id']; $getlist[mod] = 'list'; $getlist[classid] = $classid;$getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
            <!--{if $list_recommedlist}-->
                <!--{eval $getlist[classid] = $classid ? $classid : ''; $getlist[displayorder]=3; $url = 'plugin.php?'.url_implode($getlist);}-->
                <a href="{$url}"<!--{if $ordernum == 3}--> class="wqon"<!--{/if}-->>{$Plang['db11cdebc2eb37bd']}</a>
            <!--{/if}-->
            <!--{if ($_GET['id']=="wq_wechatcollecting" || $_GET['id']=="wq_wechatcollecting:wq_wechatcollecting") && $list_firstlist}-->
                <!--{eval $getlist[classid] = $classid ? $classid : ''; $getlist[displayorder]=4; $url = 'plugin.php?'.url_implode($getlist);}-->
                <a href="{$url}"<!--{if $ordernum == 4}--> class="wqon"<!--{/if}-->>{$Plang['0ef1d1c8298846ea']}</a>
            <!--{/if}-->
            <!--{eval $getlist[displayorder] = 1; $url = 'plugin.php?'.url_implode($getlist);}-->
            <a href="{$url}"<!--{if $ordernum == 1}--> class="wqon"<!--{/if}-->>{$Plang['13097feed87cf6ee']}</a>
            <!--{eval $getlist[displayorder] = 2; $url = 'plugin.php?'.url_implode($getlist);}-->
            <a href="{$url}"<!--{if $ordernum == 2}--> class="wqon"<!--{/if}-->>{$Plang['6959da5d2e80c069']}</a>
        </div>
        <div class="wqmore wqpc_wechat_ul_right">
            <a href="javascript:;">{$Plang['db9c470ab0853172']}<i class="wqwechat wqwechat-jiantou01 wqarrow"></i></a>
            <div class="wqeject" style="display: none;">
                <ul>
                    <!--{loop $nav_classlist $key $val}-->
                        <!--{if $val['status']==1}-->
                            <!--{eval $getlist = array(); $getlist[id] = $_GET['id']; $getlist[mod] = 'list'; $getlist[classid] = $key; $url = 'plugin.php?'.url_implode($getlist);}-->
                            <!--{if $val['linkurl']}-->
                                <li<!--{if $classid==$key}--> class="a"<!--{/if}-->><a href="{$val['linkurl']}" target="_blank" data-classid="{$key}">{$val['classname']}</a></li>
                            <!--{else}-->
                                <li<!--{if $classid==$key}--> class="a"<!--{/if}-->><a href="{$url}" data-classid="{$key}">{$val['classname']}</a></li>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>
<script>
    wqjq('.wqmore').on('mouseenter', function () {
        wqjq('.wqeject').show();
        wqjq('.wqmore i').addClass('wqwechat-shangjiantou').removeClass('wqwechat-jiantou01');
    });
    wqjq('.wqmore').on('mouseleave', function () {
        wqjq('.wqeject').hide();
        wqjq('.wqmore i').removeClass('wqwechat-shangjiantou').addClass('wqwechat-jiantou01');
    });
    function navHide() {
        var hasMove = false
        var widthLeft = wqjq('.wqpc_wechat_ul_left').width(), sum = wqjq('.wqpc_wechat_ul_left a').eq(0).width() + 40;
        wqjq('.wqpc_wechat_ul_right li').attr({'data-hide': ''});
        for (var i = 1; i < wqjq('.wqpc_wechat_ul_left a').length; i++) {
            sum += wqjq('.wqpc_wechat_ul_left a').eq(i).width() + 40;
            if (sum > widthLeft) {
                wqjq('.wqpc_wechat_ul_right li').eq(i - 1).attr('data-hide', i);
            } else {
                wqjq('.wqpc_wechat_ul_right li').eq(i - 1).hide();
                var hasMore = true;
            }
        }
        if (!hasMore) {
            wqjq('.wqmore').hide();
        }
    }
    navHide();
    wqjq(document).on('click', '.wqpc_wechat_ul_right li', function () {
        if (wqjq(this).attr('data-hide')) {
            var href = wqjq(this).find('a').prop('href');
            var selectid = wqjq(this).find('a').attr('data-classid');
                if(href.indexOf('.php') == -1){
                    var sign = "?";
                }else{
                    var sign = "&";
                }

            wqjq(this).find('a').prop('href', href + sign + 'selectid=' + selectid);
            wqjq('.wqpc_wechat_ul_left a').eq(wqjq(this).attr('data-hide')).addClass('a').siblings().removeClass('a');
        }
        navHide();
    });

	wqjq(document).on('click', '.pg a , .wqpc_wechat_ass_er a', function () {
		var selectid = '{$_GET['selectid']}';
		if(selectid){
			var href = wqjq(this).attr('href');
			if(href.indexOf('.php') == -1){
				var sign = "?";
			}else{
				var sign = "&";
			}
			wqjq(this).attr('href', href + sign + 'selectid=' + selectid);
		}
	});
</script>
<!--{elseif $setting[home_navigation]=='3'}-->
    <div class="wq_wechat_articles">
        <h3><a href="javascript:;" >{$right_classtitle}</a></h3>
        <ul>
            <!--{if $nav_classlist}-->
                <li<!--{if !$classid}--> class="a"<!--{/if}-->><a href="plugin.php?id={$_GET['id']}">{$Plang['a1e5d76323a1fd8d']}</a></li>
            <!--{/if}-->
            <!--{loop $nav_classlist $key $val}-->
            <!--{if $val['status']==1}-->
                <!--{eval $getlist = array(); $getlist[id] = $_GET['id']; $getlist[mod] = 'list'; $getlist[classid] = $key; $url = 'plugin.php?'.url_implode($getlist);}-->
                <!--{if $val['linkurl']}-->
                    <li><a href="{$val['linkurl']}" target="_blank">{$val['classname']}</a></li>
                <!--{else}-->
                    <li<!--{if $classid==$key}--> class="a"<!--{/if}-->><a href="{$url}">{$val['classname']}</a></li>
                <!--{/if}-->
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
<!--{/if}-->