<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

if(!submitcheck('seosubmit')) {
	echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';
	$wechat_seo = dunserialize($_G['setting']['wechat_seo']);
	$page = array(
		'index' => array('bbname', 'pluginname'),
		'list' => array('bbname', 'pluginname', 'classname', 'page'),
		'view' => array('bbname', 'pluginname', 'subject', 'classname'),
	);
	showformheader('plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatcollecting&pmod=admincp_seo');
	showtableheader(); /*di'.'sm.t'.'aoba'.'o.com*/
	foreach($page as $key => $value) {
		$code = $Plang['3bc832bd0cf768e4'];
		foreach($value as $v) {
			$code .= '<a onclick="insertContent(this, \'{' . $v . '}\');return false;" href="javascript:;" title="' . $Plang[$v] . '">{' . $Plang[$v] . '}</a>';
		}
		showtitle($Plang['wechatseo_' . $key]);
		showsetting($Plang['f7ae0f5162e383ed'], 'wechat_seo[' . $key . '][seotitle]', $wechat_seo[$key]['seotitle'], 'text', '', 0, $code);
		showsetting($Plang['534903eeef4b3b40'], 'wechat_seo[' . $key . '][seokeywords]', $wechat_seo[$key]['seokeywords'], 'text', '', 0, $code);
		showsetting($Plang['59d72389b36e3022'], 'wechat_seo[' . $key . '][seodescription]', $wechat_seo[$key]['seodescription'], 'text', '', 0, $code);
	}
	showsubmit('seosubmit');
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/
} else {
	$wechat_seo = serialize($_GET['wechat_seo']);
	C::t('common_setting')->update('wechat_seo', $wechat_seo);
	updatecache('setting');
	cpmsg($Plang['9a52f4d6ef956904'], 'action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatcollecting&pmod=admincp_seo', 'succeed');
}
//From:  d'.'is'.'m.ta'.'obao.com
?>