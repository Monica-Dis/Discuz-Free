<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: cron_wq_collection.php 2015-6-20 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//cronname:wq_collection
//minute:0,10,20,30,40,50

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatapi.php';

$Plang = wq_loadlang('wq_wechatcollecting');

$setting = wq_loadsetting('wq_wechatcollecting');
$setting['topnav'] = get_nav_urlinfo($setting['topnav']);
$setting['pluginname'] = trim($setting['pluginname']) ? trim($setting['pluginname']) : $Plang['e113a2946ba4875f'];
$setting['adminuids'] = explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['adminuids']), ','));
$setting['default_groupfid'] = $setting['default_groupfid'] ? explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['default_groupfid']), ',')) : array();
$setting['collect_interval_date'] = intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) ? intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) : 0;

loadcache(array('plugin', 'wq_wechatcollecting_class', 'wq_wechatcollecting_wechatclass', 'wq_cache_favorites_' . $_G['uid']));
$wechatnavigation = trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) : $Plang['f26af91aa5eb531a'];
$wechat_seo = dunserialize($_G['setting']['wechat_seo']);
$wechatclass = $_G['cache']['wq_wechatcollecting_wechatclass'];
$wechatclass_article = $_G['cache']['wq_wechatcollecting_class'];
$replacekeyword = str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['home_keyword']);
$setkeyword = explode(",", rtrim($replacekeyword, ','));
$favorites = $_G['cache']['wq_cache_favorites_' . $_G['uid']];
$plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;
$plugin_wechatreader = !empty($_G['cache']['plugin']['wq_wechatreader']) ? 1 : 0;
$plugin_wq_editor = !empty($_G['cache']['plugin']['wq_editor']) ? 1 : 0;

set_time_limit(1800);
if(end(explode('/', $_SERVER['PHP_SELF'])) != 'controller.php') {

	$wechatlist = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_all_automaticcollect(1, 1, 0, 'collectnumber', 0, $setting['automaticcollect_num']);

	$tmpurlarr = array();
	$isset_article = false;
	$new_article = 0;
	$error_article = 0;
	$not_set_class = 0;

	foreach($wechatlist as $key => $wechat) {
		$log = array(
			'time' => TIMESTAMP,
			'date' => date('Ymd', TIMESTAMP),
			'wid' => $wechat['id'],
			'uid' => $wechat['uid'],
			'username' => $wechat['username'],
			'wechatuser' => $wechat['wechatid'],
			'wechatname' => $wechat['name'],
			'status' => -1,
		);

		if($not_set_class || (in_array($setting['view_mode'], array('2', '4')) && empty($setting['default_fid'])) || (in_array($setting['view_mode'], array('3', '4')) && !C::t('common_syscache')->fetch('wq_portal_collect_set'))) {
			$log['status'] = -3;
			$not_set_class = 1;
		}
		$logid = C::t('#wq_wechatcollecting#wq_wechatcollecting_log')->insert($log, true);

		if($not_set_class) {
			continue;
		}

		$wechatbiz = '';
		$j = 0;


		$article = wqWechatApiGetArticleListByTmpUrl($wechat, false, true);


		$addrecord = array(
			'collectfinish' => 0,
			'collectnumber' => $wechat['collectnumber'] + 1,
		);
		$max_date = max($article['masstime']);
		if(!empty($article)) {
			$isset_article = true;
			foreach($article['articlelist'] as $key => $val) {

                if(!check_is_get_article($val['dateline'],$setting['aiticle_pubishdate'])){
                    continue;
                }

				$wechatarticle = wq_wechatcollecting_wechatarticle_exists($wechat['wechatid'], $val['title'], 0, $setting['only_title_judge']);


				if(!$wechatarticle && in_array($val['datetime'], $article['masstime'])) {
					$data = array(
						'title' => $val['title'],
						'wechatid' => $wechat['wechatid']
					);

					$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->insert($data, true);
					if(CHARSET == 'gkb') {
						$data = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_id($articleid);
						if(!$data['title']) {
							C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
							continue;
						}
					}
					$userinfo = C::t('common_member')->fetch($wechat['uid']);
					if(!in_array($wechat['uid'], $adminuids) && !in_array($userinfo['groupid'], $setting['admingroups'])) {
						$status = $setting['article_status'] == '1' ? 0 : 1;
					} else {
						$status = 1;
					}
					$new_article++;
					$article_content = wqWechatApigetArticleContentByUrl($val['content_url'], false, false, true, $wechat['wechatid']);
					$content = $article_content == '-1' ? null : $article_content['content'];
					$wechatbiz = $wechatbiz ? $wechatbiz : $article_content['wechatbiz'];
					if($content) {
						$data = array(
							'url' => $article_content['url'],
							'classid' => $wechat['classid'],
							'collecttime' => TIMESTAMP,
							'name' => $wechat['name'],
							'status' => $status,
							'isfirst' => intval($article_content['isfirst']),
							'summary' => $val['digest'],
							'imglink' => $val['cover'],
							'date' => $val['datetime'],
							'uid' => $wechat['uid'],
							'username' => $wechat['username'],
							'wid' => $wechat['id'],
							'isoriginal' => $article_content['isoriginal']
						);

						C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, $data);

						$j ++;
						$contentdata = array(
							'articleid' => $articleid,
							'content' => base64_encode($content),
							'collecttime' => TIMESTAMP,
							'wid' => $wechat['id'],
						);
						$addcontent = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->insert($contentdata);
						$val['imglink'] = save_images($val['cover'], $articleid, 'article');
						$summary = $val['digest'];

						$postresult = wq_common_post_forum_or_portal($setting, $wechat['classid'], $summary, $wechat, $val, $wechatclass_article, $status);
						$tid = $postresult['tid'];
						$aid = $postresult['aid'];

						$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, array('imglink' => $val['imglink'], 'tid' => $tid, 'aid' => $aid));
					} else {
						C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
						$error_article++;
					}
				}
			}
			if($j > 0) {
				$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wid($wechat['id']);
				$addrecord['articlenum'] = $count;
				$addrecord['collectfinish'] = 1;
				$addrecord['collectnumber'] = 0;
				$addrecord['endcollectdate'] = time();
				C::t('#wq_wechatcollecting#wq_wechatcollecting_log')->update($logid, array('status' => 0, 'collectnum' => $j));
			} else {
				C::t('#wq_wechatcollecting#wq_wechatcollecting_log')->update($logid, array('status' => -2));
			}
		}
		if(!$wechat['wechatbiz']) {
			$addrecord['wechatbiz'] = $wechatbiz;
		}
		if($wechat['collectnewdate'] < $max_date) {
			$addrecord['collectnewdate'] = $max_date;
		}
		$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wechat['id'], $addrecord);
		update_wechat_field_by_wechatid($wechat['id'], array('first_num'));
	}

	if($isset_article && $new_article > 0 && $new_article == $error_article) {
		updata_cron_available();
	}
}
//From:  d'.'is'.'m.ta'.'obao.com
?>