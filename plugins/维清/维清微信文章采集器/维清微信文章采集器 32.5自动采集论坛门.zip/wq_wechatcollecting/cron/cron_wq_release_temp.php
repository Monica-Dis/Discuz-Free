<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: cron_wq_collection.php 2015-6-20 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//cronname:wq_release_temp
//minute:5,10,15,20,25,30,35,40,45,50,55

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatapi.php';

$Plang = wq_loadlang('wq_wechatcollecting');
$setting = wq_loadsetting('wq_wechatcollecting');
$setting['topnav'] = get_nav_urlinfo($setting['topnav']);
$setting['pluginname'] = trim($setting['pluginname']) ? trim($setting['pluginname']) : $Plang['e113a2946ba4875f'];
$setting['adminuids'] = explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['adminuids']), ','));
$setting['default_groupfid'] = $setting['default_groupfid'] ? explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['default_groupfid']), ',')) : array();
$setting['collect_interval_date'] = intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) ? intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) : 0;

loadcache(array('plugin', 'wq_wechatcollecting_class', 'wq_wechatcollecting_wechatclass', 'wq_cache_favorites_' . $_G['uid']));
$wechatnavigation = trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) : $Plang['f26af91aa5eb531a'];
$wechat_seo = dunserialize($_G['setting']['wechat_seo']);
$wechatclass = $_G['cache']['wq_wechatcollecting_wechatclass'];
$wechatclass_article = $_G['cache']['wq_wechatcollecting_class'];
$replacekeyword = str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['home_keyword']);
$setkeyword = explode(",", rtrim($replacekeyword, ','));
$favorites = $_G['cache']['wq_cache_favorites_' . $_G['uid']];
$plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;
$plugin_wechatreader = !empty($_G['cache']['plugin']['wq_wechatreader']) ? 1 : 0;
$plugin_wq_editor = !empty($_G['cache']['plugin']['wq_editor']) ? 1 : 0;

$not_set_class = 0;

if((in_array($setting['view_mode'], array('2', '4')) && empty($setting['default_fid'])) || (in_array($setting['view_mode'], array('3', '4')) && !C::t('common_syscache')->fetch('wq_portal_collect_set'))) {
	$not_set_class = 1;
}

if(end(explode('/', $_SERVER['PHP_SELF'])) != 'controller.php' && !$not_set_class) {
	$limit = 2;
	if($setting['timing_release_num']) {
		$limit = $setting['timing_release_num'];
	}
	$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->fetch_all($limit);

	if($list) {
		$collectnewdate = 0;
		$new_article = 0;
		$error_article = 0;
		foreach($list as $key => $val) {
			$collectnewdate = $collectnewdate < $val['date'] ? $val['date'] : $collectnewdate;
			$wechatarticle = wq_wechatcollecting_wechatarticle_exists($val['wechatid'], $val['title'], 0, $setting['only_title_judge']);
			if(!$wechatarticle) {
				$new_article++;
				$data = array(
					'title' => $val['title'],
					'wechatid' => $val['wechatid']
				);
				$articleid = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->insert($data, true);
				$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_wechatid($val['wechatid']);
				$article_content = wqWechatApigetArticleContentByUrl($val['url']);

				$content = $article_content == '-1' ? null : $article_content['content'];
				$id = $val['id'];
				if($content) {
					unset($list[$key]['id'], $list[$key]['title'], $list[$key]['wechatid']);
					$list[$key]['collecttime'] = time();
					$list[$key]['isoriginal'] = $article_content['isoriginal'];
					$list[$key]['isfirst'] = $article_content['isfirst'];
					C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, $list[$key]);

					$contentdata = array(
						'articleid' => $articleid,
						'content' => base64_encode($content),
						'collecttime' => TIMESTAMP,
						'wid' => $val['id'],
					);
					$addcontent = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->insert($contentdata);
					$summary = $val['summary'];

					$postresult = wq_common_post_forum_or_portal($setting, $val['classid'], $summary, $wechat, $val, $wechatclass_article, $val['status']);
					$tid = $postresult['tid'];
					$aid = $postresult['aid'];

					$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_wid($wechat['id']);
					$addrecord['articlenum'] = $count;
					if(!$wechat['wechatbiz']) {
						$addrecord['wechatbiz'] = $article_content['wechatbiz'];
					}
					if($wechat['collectnewdate'] < $collectnewdate) {
						$addrecord['collectnewdate'] = $collectnewdate;
					}
					C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wechat['id'], $addrecord);
					$update = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($articleid, array('tid' => $tid, 'aid' => $aid));
					update_wechat_field_by_wechatid($wechat['id'], array('first_num'));
					del_isset_article($id);
				} else {
					C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->delete($articleid);
					$error_article++;
					del_isset_article($id);
				}
			} else {
				del_isset_article($val['id']);
			}
		}

		if($new_article > 0 && $new_article == $error_article) {
			updata_cron_available();
		}
	}
}

function del_isset_article($id) {
	C::t('#wq_wechatcollecting#wq_wechatcollecting_temparticle')->delete($id);
}
//From:  d'.'is'.'m.ta'.'obao.com
?>