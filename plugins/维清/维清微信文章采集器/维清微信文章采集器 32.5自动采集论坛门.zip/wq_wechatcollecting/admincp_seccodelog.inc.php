<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/config.php';

include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/admincpjs.php';

$setting = wq_loadsetting('wq_wechatcollecting');
$Plang = wq_loadlang('wq_wechatcollecting');
$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'desc';
$isstatus = in_array($_GET['isstatus'], array('10', '1', '-1', '-2', '-3')) ? (($_GET['isstatus'] != '10') ? $_GET['isstatus'] : '') : '';
$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 5;
$start = ($page - 1 ) * $perpage;

$list = C::t("#wq_wechatcollecting#wq_wechatcollecting_seccodelog")->fetch_all_by_search($orderby, $isstatus, $start, $perpage);
$count = C::t("#wq_wechatcollecting#wq_wechatcollecting_seccodelog")->count_by_search($orderby, $isstatus);

$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_seccodelog';
$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_wechatcollecting&pmod=admincp_seccodelog';
$mpurl .= $orderby ? "&orderby=" . $orderby : '';
$mpurl .= $isstatus !== '' ? "&isstatus=" . $isstatus : '';
$url = ADMINSCRIPT . '?' . $mpurl;

$order_by = select_html(array('desc' => $Plang['5bee37fbebf639d9'], 'asc' => $Plang['d85de5630e53b00f']), 'orderby', $orderby, false);
$status = select_html(array('10' => $Plang['8dfe4b30674494c1'], '1' => $Plang['8c5d9a385bf10556'], '-1' => $Plang['bc6fd1ca766e00af'], '-2' => $Plang['6c50bfa97d8d501c'], '-3' => $Plang['94e0795cf4567b40']), 'isstatus', $isstatus, false);

showformheader($fromurl, '', 'sub');
showtableheader('', 'nobottom');
showtablerow('', array(), array(
	$Plang['af2765b5331fc588'] . ':&nbsp;' . $order_by
	. '&nbsp;&nbsp;' . $Plang['ad1fd85e511497b1'] . ':&nbsp;' . $status
	. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value="' . $Plang['38224a4a6fc78c7c'] . '" title="' . $Plang['b7bea550cb266984'] . '" />',
));
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
showformfooter(); /*dis'.'m.t'.'ao'.'bao.com*/

showtableheader('', 'nobottom');
showsubtitle(array($Plang['ad1fd85e511497b1'], $Plang['19e080639407882e'], $Plang['af2765b5331fc588']));
foreach($list as $key => $val) {
	if($val['dateline'] > 0) {
		$time = date('Y-m-d H:i:s', $val['dateline']);
	} else {
		$time = '--';
	}
	showtablerow('', array('width=220px', '', 'width=300px'), array(
		$Plang['errcode_' . $val['errcode']],
		$val['errtips'],
		$time,
	));
}
$multi = multi($count, $perpage, $page, $url);
echo "<tr><td colspan='3' align='right'>" . $multi . "</td></tr>";
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>