<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatapi.php';

$Plang = wq_loadlang('wq_wechatcollecting');

$setting = wq_loadsetting('wq_wechatcollecting');
$setting['topnav'] = get_nav_urlinfo($setting['topnav']);
$setting['pluginname'] = trim($setting['pluginname']) ? trim($setting['pluginname']) : $Plang['e113a2946ba4875f'];
$setting['adminuids'] = explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['adminuids']), ','));
$setting['default_groupfid'] = $setting['default_groupfid'] ? explode(",", rtrim(str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['default_groupfid']), ',')) : array();
$array = array(
	'plugin',
	'wq_wechatcollecting_class',
	'wq_wechatcollecting_wechatclass',
	'wq_cache_subscription_' . $_G['uid'],
	'wq_cache_favorites_' . $_G['uid'],
	'wq_cache_articlepollsupport_' . $_G['uid'],
	'wq_cache_articlepollagainst_' . $_G['uid'],
);

loadcache($array);
$wechatnavigation = trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) : $Plang['f26af91aa5eb531a'];
$setting['collect_interval_date'] = intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) ? intval($_G['cache']['plugin']['wq_wechatshow']['collect_interval_date']) : 0;

$wechat_seo = dunserialize($_G['setting']['wechat_seo']);
$wechatclass = $_G['cache']['wq_wechatcollecting_wechatclass'];
$wechatclass_article = $_G['cache']['wq_wechatcollecting_class'];

$replacekeyword = str_replace($Plang['f7ac9becb8d864cc'], ',', $setting['home_keyword']);
$setkeyword = explode(",", rtrim($replacekeyword, ','));

$subscription = $_G['cache']['wq_cache_subscription_' . $_G['uid']];
$favorites = $_G['cache']['wq_cache_favorites_' . $_G['uid']];
$favorites = is_array($favorites) ? $favorites : array();

$articlesupport = $_G['cache']['wq_cache_articlepollsupport_' . $_G['uid']];
$articleagainst = $_G['cache']['wq_cache_articlepollagainst_' . $_G['uid']];
$plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;
$plugin_wechatreader = !empty($_G['cache']['plugin']['wq_wechatreader']) ? 1 : 0;
$plugin_wq_editor = !empty($_G['cache']['plugin']['wq_editor']) ? 1 : 0;

$nav_classlist = $wechatclass_article;
$right_classtitle = $Plang['0da4aa79f9ad198b'];

$sqlcache = unserialize($_G['setting']['wechatcollecting_cache_setting']);
$a_searchset = unserialize($_G['setting']['articlesearch']);
$w_searchset = unserialize($_G['setting']['wechatsearch']);
$view_mode = wq_wechatcollecting_get_view_mode($setting, $Plang);

?>