<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/config/setting_base.php';

$setting['home_navigation'] = !$setting['home_navigation'] ? '1' : $setting['home_navigation'];
$setting['special'] = in_array($setting['special'], array(0, 127)) ? $setting['special'] : 0;
$setting['use_common_header'] = $setting['usesystemheader'];
$setting['home_maxpage'] = intval($setting['home_maxpage']) <= 0 ? 0 : intval($setting['home_maxpage']);
$setting['home_article_list_perpage'] = intval($setting['home_article_list_perpage']) < 1 ? 10 : intval($setting['home_article_list_perpage']);
$setting['home_article_search_perpage'] = intval($setting['home_article_search_perpage']) < 1 ? 10 : intval($setting['home_article_search_perpage']);
$setting['home_article_perpage'] = intval($setting['home_article_perpage']) < 1 ? 10 : intval($setting['home_article_perpage']);
$setting['home_wechat_perpage'] = intval($setting['home_wechat_perpage']) < 1 ? 10 : intval($setting['home_wechat_perpage']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']) < 1 ? 10 : intval($setting['admincp_perpage']);
$setting['article_list_displayorder'] = intval($setting['article_list_displayorder']) < 1 || intval($setting['article_list_displayorder']) > 4 ? 3 : intval($setting['article_list_displayorder']);
$setting['right_hot_article_num'] = intval($setting['right_hot_article_num']) < 1 ? 5 : intval($setting['right_hot_article_num']);
$setting['right_new_article_num'] = intval($setting['right_new_article_num']) < 1 ? 5 : intval($setting['right_new_article_num']);
$setting['view_correlation_article_num'] = intval($setting['view_correlation_article_num']) < 1 ? 10 : intval($setting['view_correlation_article_num']);
$setting['view_bottom_recommend_num'] = intval($setting['view_bottom_recommend_num']) < 1 ? 10 : intval($setting['view_bottom_recommend_num']);
$setting['view_first_article_num'] = intval($setting['view_first_article_num']) < 1 ? 5 : intval($setting['view_first_article_num']);
$setting['right_wechat_num'] = intval($setting['right_wechat_num']) < 1 ? 5 : intval($setting['right_wechat_num']);
$setting['automaticcollect_num'] = intval($setting['automaticcollect_num']) < 1 ? 1 : intval($setting['automaticcollect_num']);
$setting['automaticcollect_num'] = intval($setting['automaticcollect_num']) > 4 ? 4 : intval($setting['automaticcollect_num']);
$setting['right_hot_collect'] = intval($setting['right_hot_collect']) < 1 ? 5 : intval($setting['right_hot_collect']);
$setting['pc_style'] = trim($setting['pc_style']) ? trim($setting['pc_style']) : '#f25242';
$setting['mobile_style'] = trim($setting['mobile_style']) ? trim($setting['mobile_style']) : '#f25242';
$setting['pc_color'] = !empty($setting['pc_color']) ? $setting['pc_color'] : $setting['pc_style'];
$setting['mobile_color'] = !empty($setting['mobile_color']) ? $setting['mobile_color'] : $setting['mobile_style'];
$mainnav = explode("\n", str_replace("\r\n", "\n", $setting['mainnav']));
$setting['topnav'] = array();
$setting['logoname'] = $setting['logoname'] ? trim($setting['logoname']) : 'pc_wq_logo.png';
$setting['mobile_logoname'] = $setting['mobile_logoname'] ? trim($setting['mobile_logoname']) : 'wq_logo.png';
$setting['maxrestrict'] = intval($setting['maxrestrict']) < 1 ? 1 : (intval($setting['maxrestrict']) > 100 ? 100 : intval($setting['maxrestrict']));
$setting['is_saveimages'] = $setting['view_issaveimg'] = 1;
$setting['mainnvid'] = empty($setting['mainnvid']) ? "" : $setting['mainnvid'];
foreach($mainnav as $key => $nav) {
	$setting['topnav'][$key] = explode("|", str_replace(" ", "", $nav));
}
$setting['qiniu_domain'] = in_array(strtolower(substr($setting['qiniu_domain'], 0, 6)), array('http:/', 'https:')) ? $setting['qiniu_domain'] : '//' . $setting['qiniu_domain'];
$setting['wechatcollect_randomnum'] = $setting['wechatcollect_randomnum'] ? explode("-", $setting['wechatcollect_randomnum']) : array();
sort($setting['wechatcollect_randomnum']);
$setting['wechatviews_randomnum'] = $setting['wechatviews_randomnum'] ? explode("-", $setting['wechatviews_randomnum']) : array();
sort($setting['wechatviews_randomnum']);
$setting['articleviews_randomnum'] = $setting['articleviews_randomnum'] ? explode("-", $setting['articleviews_randomnum']) : array();
sort($setting['articleviews_randomnum']);
$setting['register_pwd'] = $setting['register_pwd'] ? $setting['register_pwd'] : md5(random(10));
$setting['keyword_filtration'] = $setting['keyword_filtration'] ? explode("\n", str_replace("\r\n", "\n", $setting['keyword_filtration'])) : array();
$setting['keyword_replace'] = $setting['keyword_replace'] ? explode("\n", str_replace("\r\n", "\n", $setting['keyword_replace'])) : array();
$setting['search_keyword'] = $setting['replace_keyword'] = array();
foreach($setting['keyword_replace'] as $key => $value) {
	list($setting['search_keyword'][], $setting['replace_keyword'][]) = explode('|', $value);
}

$setting['admingroups'] = is_array($setting['admingroups']) ? $setting['admingroups'] : array();
$setting['allow_groups'] = is_array($setting['allow_groups']) ? $setting['allow_groups'] : array();

?>