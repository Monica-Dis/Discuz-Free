<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2019-10-21 00:53:09Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$setting = $_G['cache']['plugin']['wq_wechatcollecting'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['aiticle_pubishdate'] = intval($setting['aiticle_pubishdate']);
$setting['jsdati_username'] = trim($setting['jsdati_username']);
$setting['jsdati_password'] = trim($setting['jsdati_password']);
$setting['adminuids'] = trim($setting['adminuids']);
$setting['admingroups'] = unserialize($setting['admingroups']);
$setting['allow_groups'] = unserialize($setting['allow_groups']);
$setting['wechatcollect_randomnum'] = trim($setting['wechatcollect_randomnum']);
$setting['wechatviews_randomnum'] = trim($setting['wechatviews_randomnum']);
$setting['wechatname_isregister'] = intval($setting['wechatname_isregister']);
$setting['register_pwd'] = trim($setting['register_pwd']);
$setting['maxrestrict'] = intval($setting['maxrestrict']);
$setting['wechat_status'] = intval($setting['wechat_status']);
$setting['article_status'] = intval($setting['article_status']);
$setting['articleviews_randomnum'] = trim($setting['articleviews_randomnum']);
$setting['home_keyword'] = trim($setting['home_keyword']);
$setting['home_navigation'] = intval($setting['home_navigation']);
$setting['view_mode'] = intval($setting['view_mode']);
$setting['default_fid'] = intval($setting['default_fid']);
$setting['default_groupfid'] = trim($setting['default_groupfid']);
$setting['special'] = intval($setting['special']);
$setting['default_url'] = intval($setting['default_url']);
$setting['show_my_attention'] = intval($setting['show_my_attention']);
$setting['automaticcollect_num'] = intval($setting['automaticcollect_num']);
$setting['mainnvid'] = trim($setting['mainnvid']);
$setting['mobile_logoname'] = trim($setting['mobile_logoname']);
$setting['mobile_head_webname'] = trim($setting['mobile_head_webname']);
$setting['mobile_style'] = trim($setting['mobile_style']);
$setting['mobile_color'] = trim($setting['mobile_color']);
$setting['is_system_headbottom'] = intval($setting['is_system_headbottom']);
$setting['logoname'] = trim($setting['logoname']);
$setting['mainnav'] = trim($setting['mainnav']);
$setting['pc_style'] = trim($setting['pc_style']);
$setting['pc_color'] = trim($setting['pc_color']);
$setting['right_hot_article_num'] = intval($setting['right_hot_article_num']);
$setting['right_new_article_num'] = intval($setting['right_new_article_num']);
$setting['right_wechat_num'] = intval($setting['right_wechat_num']);
$setting['right_hot_collect'] = intval($setting['right_hot_collect']);
$setting['view_correlation_article_num'] = intval($setting['view_correlation_article_num']);
$setting['view_bottom_recommend_num'] = intval($setting['view_bottom_recommend_num']);
$setting['view_first_article_num'] = intval($setting['view_first_article_num']);
$setting['home_maxpage'] = intval($setting['home_maxpage']);
$setting['home_article_list_perpage'] = intval($setting['home_article_list_perpage']);
$setting['home_article_search_perpage'] = intval($setting['home_article_search_perpage']);
$setting['home_article_perpage'] = intval($setting['home_article_perpage']);
$setting['home_wechat_perpage'] = intval($setting['home_wechat_perpage']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['article_list_displayorder'] = intval($setting['article_list_displayorder']);
$setting['is_use_qiniu'] = intval($setting['is_use_qiniu']);
$setting['qiniu_ak'] = trim($setting['qiniu_ak']);
$setting['qiniu_sk'] = trim($setting['qiniu_sk']);
$setting['qiniu_bucket'] = trim($setting['qiniu_bucket']);
$setting['qiniu_domain'] = trim($setting['qiniu_domain']);
$setting['isselsave'] = intval($setting['isselsave']);
$setting['is_setthreadcover'] = intval($setting['is_setthreadcover']);
$setting['is_showimage'] = intval($setting['is_showimage']);
$setting['timing_release_num'] = intval($setting['timing_release_num']);
$setting['keyword_article_status'] = intval($setting['keyword_article_status']);
$setting['keyword_wechat_status'] = intval($setting['keyword_wechat_status']);
$setting['optimizeviews'] = intval($setting['optimizeviews']);
$setting['preventrefresh'] = intval($setting['preventrefresh']);
$setting['content_is_filtration_a'] = intval($setting['content_is_filtration_a']);
$setting['view_is_filtration_a'] = intval($setting['view_is_filtration_a']);
$setting['keyword_filtration'] = trim($setting['keyword_filtration']);
$setting['keyword_replace'] = trim($setting['keyword_replace']);
$setting['transcoding_format'] = intval($setting['transcoding_format']);
$setting['only_title_judge'] = intval($setting['only_title_judge']);
$setting['pc_content_add_top'] = trim($setting['pc_content_add_top']);
$setting['pc_content_add_bottom'] = trim($setting['pc_content_add_bottom']);
$setting['mobile_content_add_top'] = trim($setting['mobile_content_add_top']);
$setting['mobile_content_add_bottom'] = trim($setting['mobile_content_add_bottom']);


?>