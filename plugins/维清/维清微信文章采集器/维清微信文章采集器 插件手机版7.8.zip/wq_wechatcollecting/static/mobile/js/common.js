$(function() {
	$(document).on('click', '.wqwoperation', function(e) {
		var id = $(this).attr('data');
		if ($("#wqwoperation_down_" + id).is(":hidden")) {
			if ($(".wqwoperation_down_show_hide").is(":visible")) {
				$(".wqwoperation_down_show_hide").hide();
			}
			$("#wqwoperation_down_" + id).show();
		} else {
			$("#wqwoperation_down_" + id).hide();
		}
		e.stopPropagation()
	})
	$(document).on('click', function() {
		$(".wqwoperation_down:visible").hide()
	})
	$(document).on('click', '.wqwoperation_down a', function() {
		if ($(".wqwoperation_down:visible").length) {
			$(".wqwoperation_down:visible").hide()
		}
	})
	$(document).on('scroll', function() {
		if ($(".wqwoperation_down:visible").length) {
			$(".wqwoperation_down:visible").hide()
		}
	})
	var toast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>';
	$(document).on('click', '.wqformdialog', function() {
		popup.open(toast);
		var obj = $(this);
		var formobj = $(this.form);
		$.ajax({
			type: 'POST',
			url: formobj.attr('action') + '&handlekey=' + formobj.attr('id') + '&inajax=1',
			data: formobj.serialize(),
			dataType: 'html'
		}).success(function(s) {
			if (s.indexOf('id="loginform"') == -1) {
				var wq = wqXml(s);
				var wq2 = wq_wechat_replace_js(wq);
				popup.open(wq2);
				evalscript(wq);
			} else {
				window.location.href = "member.php?mod=logging&action=login&mobile=2";
			}
		}).error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$(document).on('click', '.wqdialog', function() {
		var obj = $(this);
		popup.open(toast);
		$.ajax({
			type: 'GET',
			url: obj.attr('href') + '&inajax=1',
			dataType: 'html'
		})
				.success(function(s) {
					if (s.indexOf('id="loginform"') == -1) {
						var wq = wqXml(s);
						var wq2 = wq_wechat_replace_js(wq);
						popup.open(wq2);
						evalscript(wq);
					} else {
						window.location.href = "member.php?mod=logging&action=login&mobile=2";
					}
				})
				.error(function() {
					window.location.href = obj.attr('href');
					popup.close();
				});
		return false;
	});

	$(function() {
		$("#wqnumber_select").on("click", function() {
			if ($('#wqnumber_select').is(':checked')) {
				$('.weui_check').prop('checked', 'checked')
			} else {

				$('.weui_check').prop('checked', false)
			}
		});

		$("#load_next_page a").bind("click", function() {
			var formobj = $('#subscription_collect');
			$(".wqwechat_loading").show()
			$(".wqwechat_load").hide()
			$.ajax({
				type: 'POST',
				url: formobj.attr('action') + '&inajax=1',
				data: formobj.serialize(),
				dataType: 'html'
			}).success(function(data) {
				$(".wqwechat_load").show()
				$(".wqwechat_loading").hide()
				$(".wechatlist").append(data);
				var begin = data.indexOf('listcode')
				var start = data.lastIndexOf('<input', begin)
				var end = emtypeflag = data.indexOf('<li')
				if (end == -1) {
					end = data.length
				}
				var formReplace1 = data.slice(0, start)
				var formReplace2 = data.slice(start, end)
				$('#subscription_collect .totalPages').remove()
				$('#subscription_collect .listcode').remove()
				$('#subscription_collect').prepend(formReplace1)
				$('#subscription_collect').prepend(formReplace2)
				if (emtypeflag == -1) {
					$(".wqwechat_load").hide()
					$(".wqwechat_loading").hide()
					$(".wqwechat_end").show()
				}
			}).error(function() {
				$(".wqwechat_load").show()
				$(".wqwechat_loading").hide()
			});
			return false;
		});

	});

	var pulldown_load = true;
	$(document).on('scroll', function() {
		delayload()
		var obj = $('.pulldown_load_js')
		if (obj.length && pulldown_load) {
			botton = obj.attr('botton') ? obj.attr('botton') : 0
			count = parseInt(obj.attr('count'))
			perpage = parseInt(obj.attr('perpage'))
			page = parseInt(obj.attr('page'))
			maxpage = parseInt(obj.attr('maxpage'))
			var tempage = page <= 0 ? 1 : page - 1;
			$(".wqwechat_more").show()
			if (count / perpage > page && $(this).scrollTop() + $(window).height() >= $(document).height() - botton - 93 * page) {
				pulldown_load = false
				page++
				var tempage = page <= 0 ? 1 : page - 1;
				if (maxpage > 0 && (tempage * perpage >= perpage * maxpage)) {
					$(".wqloaded_all").show()
					$(".wqwechat_more").hide()
					pulldown_load = false
					return;
				}
				var url = location.href
				$.ajax({
					type: 'GET',
					url: url,
					data: {page: page},
					dataType: 'html',
					success: function(data) {
						var first = data.indexOf('<li', data.indexOf('wqchatlist')), final = data.indexOf('</ul>', first), list = data.substring(first, final)
						list = list.replace(/<li--/g, "");
						$('.wqchatlist').append(list)
						obj.attr('page', page)
						$(".wqwechat_more").hide()
						pulldown_load = true
						$('img').each(function() {
							if ($(this).attr('smilieid')) {
								$(this).addClass('wq_smilieimg')
							}
						});
					}
				})
			} else if (count / perpage <= page) {
				$(".wqloaded_all").show()
				$(".wqwechat_more").hide()
				pulldown_load = false
			}
		}
	});
	if ($('footer.wq_wechat_footer').length) {
		var windowTop = 0
		$(window).on('scroll', function() {
			var scrolls = $(this).scrollTop()
			if (scrolls > windowTop) {
				$('.wq_wechat_footer').css({'transition': '0.5s', 'transform': 'translate(0,48px)'})
				windowTop = scrolls
			} else {
				$('.wq_wechat_footer').css({'transition': '0.8s', 'transform': 'translate(0,0px)'})
				windowTop = scrolls
			}
		})
	}
	$(".wqwechat_articleview_con .lazyload-home").each(function() {
		var imgwidth = $(this).attr('data-w') > $('.wqwechat_articleview_con').width() ? $('.wqwechat_articleview_con').width() : $(this).attr('data-w');
		imgwidth = imgwidth > $(this).parent().width() ? $(this).parent().width() : imgwidth;
		$(this).css({'width': imgwidth + 'px', 'height': imgwidth * $(this).attr('data-ratio') + 'px'});
	});
	delayload();
});
function delayload() {
	var document_top = $(document).scrollTop()
	$(".lazyload-home").each(function() {
		var img_top = $(this).offset().top
		if (img_top >= document_top && img_top <= document_top + $(window).height()) {
			$(this).prop('src', $(this).attr('wqdata-src')).removeClass("lazyload-home")

			this.onload = function() {
				if ($(this).parents('.wqlazydiv').length) {
					feed_img($(this).parents('.wqlazydiv'));
				}
			};
		}
	});
}
function feed_img(obj) {
	var img = new Image();
	img.src = obj.find('img').attr('wqdata-src') || obj.find('img').attr('data-src');
	img.onload = function() {
		var img_width = img.width, img_height = img.height
		if (obj.css('max-height')) {
			if (img_height < obj.css('max-height')) {
				return
			} else {
				obj.height(obj.css('max-height'))
			}
		}
		if (img_width / obj.width() > img_height / obj.height()) {
			obj.find('img').height(obj.height())
			obj.find('img').width(obj.height() * img_width / img_height)
			var marginLeft = (obj.width() - obj.find('img').width()) / 2
			obj.find('img').css('margin-left', marginLeft)
		} else {
			obj.find('img').width(obj.width())
			obj.find('img').height(obj.width() * img_height / img_width)
			var marginTop = (obj.height() - obj.find('img').height()) / 2
			obj.find('img').css('margin-top', marginTop)
		}
	}
}

function errorhandle_canclecollect(msg, param) {
	if (msg == "ȡ���ɹ�") {
		$("#wqwoperation_down_" + param.aid + " a:first").replaceWith("<a href=\"plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid=" + param.aid + "\"><i class=\"wqwechat wqwechat-favorite\"></i>�ղ�</a>");
	}
}
function errorhandle_wqc_listsupport(msg, param) {
	if (msg == "ͶƱ�ɹ�") {
		$("#wqwoperation_down_" + param.aid + " .wqwechat_left_black i").attr('class', 'wqwechat wqwechat-zan2 wqyellow');
	}
}
function wq_wechat_replace_js(s) {
	if (s.indexOf('<script') == -1)
		return s;
	var p = /<script[^\>]*?>([^\x00]*?)<\/script>/ig;
	s = s.replace(p, '');
	return s;
}

function wq_wechatcollecting_cancel(classone, classtwo) {
	if ($(classone).is(":hidden")) {
		$(classone).show();
		$(classtwo).show();
	} else {
		$(classone).hide();
		$(classtwo).hide();
	}
}

function wq_clear_Selected() {
	$(".wqwechat_group_warp").find("i").each(function() {
		$(this).remove();
	});
	$("#favoritesid").val(0);
}

function wq_wechat_trim(str) {
	return str.replace(/^(\s|\u00A0)+/, '').replace(/(\s|\u00A0)+$/, '');
}

function wq_wechat_setTimeout(waittime) {
	setTimeout(function() {
		popup.close()
	}, waittime);
}

function wqXml(str) {
	var start = str.indexOf('CDATA') + 6, end = str.indexOf(']]></root>');
	var wq = str.substring(start, end);
	return wq
}