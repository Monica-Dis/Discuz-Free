<?php exit("Powered by www.wikin.cn"); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
            <meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
                <meta name="format-detection" content="telephone=no" />
                <meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
                <meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)}{/if}" />
        <base href="{$_G['siteurl']}" />
        <title><!--{if !empty($navtitle)}-->$navtitle<!--{/if}--></title>
        <link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/mobile/css/wq_wechat.css?{VERHASH}" type="text/css">
        <link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/font/iconfont.css?{VERHASH}" type="text/css">
        <link rel="stylesheet" href="./source/plugin/wq_wechatcollecting/static/mobile/css/nativeShare.css?{VERHASH}" type="text/css">
        <script src="./source/plugin/wq_wechatcollecting/static/mobile/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
        <script src="./source/plugin/wq_wechatcollecting/static/js/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript"></script>
        <script src="./source/plugin/wq_wechatcollecting/static/mobile/js/swipe.js" type="text/javascript"></script>
        <script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
        <script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
        <script src="./source/plugin/wq_wechatcollecting/static/mobile/js/common.js?{VERHASH}" charset="{CHARSET}" type="text/javascript"></script>
        <script src="./source/plugin/wq_wechatcollecting/static/mobile/js/isScroll.min.js?{VERHASH}" type="text/javascript"></script>
    </head>
    <!--{if $_GET['id']=='wq_wechatreader' || $_GET['id']=='wq_wechatreader:wq_wechatreader'}-->
        <!--{eval
            $logoname = $collecting_setting['mobile_logoname'];
            $set_color = $collecting_setting['mobile_color'];
            $mobile_head_webname = $collecting_setting['mobile_head_webname'];
        }-->
    <!--{elseif $_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow'}-->
        <!--{eval
            $logoname = $collect_setting['mobile_logoname'];
            $set_color = $collect_setting['mobile_color'];
            $mobile_head_webname = $collect_setting['mobile_head_webname'];
        }-->
    <!--{elseif $_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting'}-->
        <!--{eval
            $logoname = $setting['mobile_logoname'];
            $set_color = $setting['mobile_color'];
            $mobile_head_webname = $setting['mobile_head_webname'];
        }-->
    <!--{/if}-->
    <body>
        <!--{hook/global_header_mobile}-->
        <!--{if $set_color}-->
            <!--{template wq_wechatcollecting:common/setcolor}-->
        <!--{/if}-->
    <!--header start-->
    <!--{if (($_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting')&&($_GET['mod']=='index' || $_GET['mod']=='list' || !$_GET['mod'])) || (($_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow')&&($_GET['mod']=='list'|| !$_GET['mod']))}-->
        <header class="wq_wechat_header">
            <div class="wq_wechat_header_warp">
                <div class="wq_img">
                    <a href="./"><img src="./source/plugin/wq_wechatcollecting/static/images/{$logoname}"></a>
                </div>
                <!--{if $mobile_head_webname}-->
                <div class="wq_text"><span></span>{$mobile_head_webname}</div>
                <!--{/if}-->
                <!--{if $a_searchset['status'] || $w_searchset['status']}-->
                    <!--{eval $identifier = $a_searchset['status'] ? 'wq_wechatcollecting':'wq_wechatshow';}-->
                    <div class="wq_search">
                        <a href="plugin.php?id=$identifier&mod=search">
                            <i class="wqwechat wqwechat-iconfontsousuo1 wq_f24"></i>
                        </a>
                    </div>
                <!--{/if}-->
            </div>
        </header>
    <!--{/if}-->
    <!--header end-->
<!--{if $_G['cache']['plugin']['wq_login'] && ($_GET['id']=='wq_wechatshow' || $_GET['id']=='wq_wechatshow:wq_wechatshow' || $_GET['id']=='wq_wechatcollecting' || $_GET['id']=='wq_wechatcollecting:wq_wechatcollecting')}-->
<!--{if $_GET['mod'] == 'view' && $_GET['articleid']}-->
    <!--{eval $sharetitle = $content['title'];$imgbase = $content['imglink'];$description = $content['summary'];$wxclassname='wqwechat_articleview_con';}-->
<!--{elseif $_GET['mod'] == 'view' && $_GET['wid']}-->
    <!--{eval $sharetitle = $wechat['name'];$imgbase = $wechat['headimage'];$description = $wechat['intro'];}-->
<!--{else}-->
    <!--{eval $sharetitle = !empty($navtitle) ? $navtitle : "";$imgbase = '';}-->
    <!--{eval $sharetitle = empty($nobbname) ? $sharetitle."-".$_G['setting']['bbname'] : $sharetitle}-->
    <!--{eval $description = !empty($metadescription) ? dhtmlspecialchars($metadescription)."-".$_G['setting']['bbname'] : $_G['setting']['bbname']}-->
<!--{/if}-->
<!--{template wq_login:WX_SharePreview}-->
<!--{/if}-->