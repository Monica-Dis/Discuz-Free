<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['id']!='wq_wechatreader' && $_GET['id']!='wq_wechatreader:wq_wechatreader'}-->
    <!--{eval $adinfo = wq_get_wq_ad_info('wq_wechatcollectint_list_n');$i=1;}-->
<!--{/if}-->
<!--{loop $list $key $val}-->
    <!--{if $adinfo}-->
        <!--{loop $adinfo $k $v}-->
            <!--{if in_array($i,$v['perpage'])}-->
                <!--{if $page > 1}-->
                    <!--{eval echo '<li--'.$v['adinfo'];}-->
                <!--{else}-->
                    <!--{eval echo $v['adinfo'];}-->
                <!--{/if}-->
            <!--{/if}-->
        <!--{/loop}-->
    <!--{/if}-->
    <li class="wqwechat_bottom">
        <!--{if $plugin_wechatshow && $ac=fav && $_GET['op']=='edit'}-->
        <div class="wq_choice">
            <input type="checkbox" name="wqwechat_move" id="wqwechat_move_{$val[articleid]}" class="weui_check" value="{$val[articleid]}">
            <label class="weui_check_label" for="wqwechat_move_{$val[articleid]}"><i class="weui_icon_checked"></i></label>
        </div>
        <!--{/if}-->
        <!--{eval $url = wq_common_article_view_url($setting,$val['articleid'],$val['tid'],$val['aid']);}-->

        <!--{eval  $plugin_wechatshow = !empty($_G['cache']['plugin']['wq_wechatshow']) ? 1 : 0;}-->
        <!--{if $plugin_wechatshow}-->
            <!--{eval
                $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val['wechatid']; $getlist['displayorder'] = 'index';
                $wechaturl = 'plugin.php?'.url_implode($getlist);
            }-->
        <!--{else}-->
            <!--{eval $wechaturl = 'javascript:;'; }-->
        <!--{/if}-->
        <div class="wq_img wqlazydiv">
            <a href="{$url}"><img wqdata-src="{$val[imglink]}" class="lazyload-home" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg"></a>
        </div>
        <div class="wq_con">
            <h3><a href="{$url}">{$val['title']}</a></h3>
            <p class="wq_f12">
                <a href="{$wechaturl}" class="wq_num wqellipsis"><!--{if !in_array($_GET['id'],array('wq_wechatshow','wq_wechatshow:wq_wechatshow')) && $_GET['mod'] != 'view'}-->{$val['name']}<!--{/if}--></a>
                <!--{if $plugin_wechatshow && $ac=fav && $_GET['op']=='edit'}-->
                    <span class="wqy wqtime">
                        <a href="plugin.php?id=wq_wechatreader&mod=index&step=3&favoritesid={$val[favoritesid]}">{$val['favoritesname']}</a>
                    </span>
                <!--{else}-->
                    <a href="javascript:;" class="wqy wqwoperation" data="{$val[articleid]}">
                        <img src="./source/plugin/wq_wechatcollecting/static/images/wq_down.png">
                    </a>
                    <span class="wqy wqtime"><!--{eval echo dgmdate($val[date],'d');}--></span>
                    <span class="wqwoperation_down wqwoperation_down_show_hide" id="wqwoperation_down_{$val[articleid]}" style="display: none">
                        <span></span>
                         <!--{if $plugin_wechatreader}-->
                            <!--{if !in_array($val[articleid],$favorites)}-->
                                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=collect&aid={$val['articleid']}">
                                    <i class="wqwechat wqwechat-favorite"></i>{$Plang['23393395a9152c6f']}
                                </a>
                            <!--{else}-->
                                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid={$val[articleid]}&handlekey=canclecollect" class="wqdialog">
                                    <i class="wqwechat wqwechat-shoucang wqyellow"></i>{$Plang['328bb3a07f442672']}
                                </a>
                            <!--{/if}-->
                        <!--{/if}-->
                         <a href="plugin.php?id=wq_wechatcollecting&mod=ajax&ac=articlesupport&aid={$val[articleid]}&handlekey=wqc_listsupport" class="wq_line wqwechat_left_black wqdialog">

                             <i class="wqwechat <!--{if in_array($val[articleid],$articlesupport)}-->wqwechat-zan2 wqyellow<!--{elseif in_array($val[articleid],$articleagainst)}-->wqwechat-cai wqyellow<!--{else}-->wqwechat-comiiszan<!--{/if}-->"></i>
                             <!--{if !in_array($val[articleid],$articleagainst)}-->{$Plang['4d3aee3cefdbf4b8']}<!--{else}-->{$Plang['44df76f6b567d500']}<!--{/if}-->
                         </a>

                    </span>
                <!--{/if}-->
            </p>
        </div>
    </li>
<!--{eval $i++;}-->
<!--{/loop}-->