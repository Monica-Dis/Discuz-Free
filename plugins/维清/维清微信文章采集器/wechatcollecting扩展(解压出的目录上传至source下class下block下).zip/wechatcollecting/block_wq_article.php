<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_wq_article extends discuz_block {

    var $setting = array();
    var $lang = array();

    function name() {
        return $this->lang['9882793618bd4605'];
    }

    function blockclass() {
        return array('wqarticle', $this->lang['63c14fb6b00cc96e']);
    }

    function block_wq_article() {

        include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_common.php';
        $langfile = DISCUZ_ROOT . './source/language/wechatcollecting/language_diy.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wechatcollecting');
        include $includefile;
        $this->lang = $Plang;

        $this->setting = array(
            'title' => array(
                'title' => $this->lang['e1a80565979a8a9f'],
                'type' => 'text',
            ),
            'articleid' => array(
                'title' => $this->lang['5f1d923dc1852460'],
                'type' => 'text',
            ),
            'wechatid' => array(
                'title' => $this->lang['1efdb5422684ca8c'],
                'type' => 'text',
            ),
            'name' => array(
                'title' => $this->lang['82c0a75068c0c652'],
                'type' => 'text',
            ),
            'classid' => array(
                'title' => $this->lang['3539c5e5dfc35990'],
                'type' => 'mselect',
                'value' => array(array(0, $this->lang['e827d05367f8e2cc'])),
                'default' => array(0),
            ),
            'displayorder' => array(
                'title' => $this->lang['ad28fc1bade220cb'],
                'type' => 'mradio',
                'value' => array(
                    array('collecttime', $this->lang['e74bdffa1086f6bd']),
                    array('views', $this->lang['7ca51a584352b5e1']),
                    array('date', $this->lang['c08ae95391fa3c06']),
                    array('favorites', $this->lang['ee8c67da02da6a4a']),
                ),
                'default' => 'collecttime',
            ),
            'maximum' => array(
                'title' => $this->lang['84e18af260e7570d'],
                'type' => 'text',
                'default' => 50
            ),
            'maximum_summary' => array(
                'title' => $this->lang['e4f5ec4bbb0f16d7'],
                'type' => 'text',
                'default' => 150
            ),
            'start' => array(
                'title' => $this->lang['1dcae891bc1a4507'],
                'type' => 'number',
                'default' => 0
            ),
        );
    }

    function fields() {
        return array(
            'title' => array('name' => $this->lang['dfb5ffafc191a673'], 'formtype' => 'title', 'datatype' => 'title'),
            'id' => array('name' => 'ID', 'formtype' => 'text', 'datatype' => 'int'),
            'url' => array('name' => $this->lang['7afd47d146c9888e'], 'formtype' => 'text', 'datatype' => 'string'),
            'pic' => array('name' => $this->lang['8bab8fc8360e1261'], 'formtype' => 'pic', 'datatype' => 'pic'),
            'collecttime' => array('name' => $this->lang['181ddde8c4dccfef'], 'formtype' => 'text', 'datatype' => 'string'),
            'classname' => array('name' => $this->lang['772b1a1ea4453642'], 'formtype' => 'text', 'datatype' => 'string'),
            'date' => array('name' => $this->lang['2e77414490960696'], 'formtype' => 'text', 'datatype' => 'string'),
            'wechatid' => array('name' => $this->lang['337736b180cd27b2'], 'formtype' => 'text', 'datatype' => 'string'),
            'summary' => array('name' => $this->lang['0eb6287692c555ee'], 'formtype' => 'summary', 'datatype' => 'summary'),
            'openid' => array('name' => 'openid', 'formtype' => 'text', 'datatype' => 'string'),
            'classid' => array('name' => $this->lang['8916e94f1bb47bd2'], 'formtype' => 'text', 'datatype' => 'int'),
            'uid' => array('name' => $this->lang['bb613590ae73ed9b'], 'formtype' => 'text', 'datatype' => 'int'),
            'username' => array('name' => $this->lang['67e516c6434d60d7'], 'formtype' => 'text', 'datatype' => 'string'),
            'displayorder' => array('name' => $this->lang['7147c6a65ed97fda'], 'formtype' => 'text', 'datatype' => 'int'),
            'views' => array('name' => $this->lang['2b26ad735a10edf7'], 'formtype' => 'text', 'datatype' => 'int'),
            'date_year' => array('name' => $this->lang['7b73d8d9fcf82603'], 'formtype' => 'text', 'datatype' => 'string'),
            'date_month' => array('name' => $this->lang['a8120f77688bfc24'], 'formtype' => 'text', 'datatype' => 'string'),
            'date_day' => array('name' => $this->lang['615c69a0a797910c'], 'formtype' => 'text', 'datatype' => 'string'),
            'date_hour' => array('name' => $this->lang['047b3e2f68275f79'], 'formtype' => 'text', 'datatype' => 'string'),
            'date_i' => array('name' => $this->lang['c2daf40fe3e22b9b'], 'formtype' => 'text', 'datatype' => 'string'),
            'date_s' => array('name' => $this->lang['1e25d264fe6c1471'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_year' => array('name' => $this->lang['34a9b0714c13a895'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_month' => array('name' => $this->lang['cc287a942dfb92f9'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_day' => array('name' => $this->lang['7ce6fa8c56132849'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_hour' => array('name' => $this->lang['ef59828a8672d1d0'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_i' => array('name' => $this->lang['71873a895f878dcb'], 'formtype' => 'text', 'datatype' => 'string'),
            'collecttime_s' => array('name' => $this->lang['9c044c568a66d265'], 'formtype' => 'text', 'datatype' => 'string'),
            'wechatname' => array('name' => $this->lang['6ea4e4a60964d568'], 'formtype' => 'text', 'datatype' => 'string'),
            'wechat_url' => array('name' => $this->lang['1d11cec880876d57'], 'formtype' => 'text', 'datatype' => 'string'),
            'source_url' => array('name' => $this->lang['6f228e0e7a10bdea'], 'formtype' => 'text', 'datatype' => 'string'),
        );
    }

    function getsetting() {
        global $_G;
        $setting = $this->setting;
        loadcache('wq_wechatcollecting_class');
        foreach ($_G['cache']['wq_wechatcollecting_class'] as $key => $value) {

            $setting['classid']['value'][] = array($key, $value['classname']);
        }
        return $setting;
    }

    function getdata($style, $parameter) {
        loadcache('wq_wechatcollecting_class');
        global $_G;


        if (strpos($data['imglink'], "wq_wechatcollecting/") === 0 || strpos($data['imglink'], "portal/") === 0) {
            $attachurl = !$_G['setting']['attachurl'] ? 'data/attachment/' : $_G['setting']['attachurl'];
            $parse = parse_url($attachurl);
            $attachurl = !isset($parse['host']) ? $_G['siteurl'] . $attachurl : $attachurl;
            $data['imglink'] = $attachurl . $data['imglink'];
        }

        $parameter = $this->cookparameter($parameter);
        $articleid = !empty($parameter['articleid']) ? explode(',', str_replace('��', ',', $parameter['articleid'])) : array();
        $wechatid = !empty($parameter['wechatid']) ? explode(',', str_replace('��', ',', $parameter['wechatid'])) : array();
        $name = isset($parameter['name']) ? $parameter['name'] : '';
        $title = isset($parameter['title']) ? $parameter['title'] : '';
        $displayorder = isset($parameter['displayorder']) ? $parameter['displayorder'] : '';
        $start = isset($parameter['start']) ? intval($parameter['start']) : 0;
        $maximum = isset($parameter['maximum']) ? intval($parameter['maximum']) : 10;
        $maximum_summary = isset($parameter['maximum_summary']) ? intval($parameter['maximum_summary']) : 20;
        $items = !empty($parameter['items']) ? intval($parameter['items']) : 10;

        $classid = array();
        if (!empty($parameter['classid'])) {
            if (isset($parameter['classid'][0]) && $parameter['classid'][0] == '0') {
                unset($parameter['classid'][0]);
            }
            $classid = $parameter['classid'];
        }

        $wheres = array();
        if ($articleid) {
            $wheres[] = ' `articleid` IN (' . dimplode($articleid) . ')';
        }
        if ($wechatid) {
            $wheres[] = ' `wechatid` IN (' . dimplode($wechatid) . ')';
        }
        if ($name) {
            $wheres[] = ' `name` like \'%' . $name . '%\'';
        }
        if ($title) {
            $wheres[] = ' `title` like \'%' . $title . '%\'';
        }
        if ($classid) {
            $wheres[] = ' `classid` IN (' . dimplode($classid) . ')';
        }

        $wheresql = implode(' AND ', $wheres);

        $sql = $wheresql ? ' AND ' . $wheresql : '';

        $query = DB::query("SELECT *
			FROM `" . DB::table('wq_wechatcollecting_article') . "`  $ffadd2
                        WHERE status=1 $sql  ORDER BY $displayorder   DESC
		        LIMIT $start, $items"
        );

        $datalist = $list = array();
        while ($data = DB::fetch($query)) {
            $data['imglink'] = $this->article_headimg_and_bgimg_url($data['imglink']);

            $title = cutstr(str_replace('\\\'', '&#39;', addslashes($data['title'])), $maximum, '');
            $summary = cutstr($data['summary'], $maximum_summary, '');
            $list[] = array(
                'id' => $data['articleid'],
                'idtype' => 'id',
                'title' => $title,
                'url' => ($_G['cache']['plugin']['wq_wechatcollecting']['view_mode'] == '2' && !empty($data['tid'])) ? 'forum.php?mod=viewthread&tid=' . $data['tid'] : 'plugin.php?id=wq_wechatcollecting&mod=view&articleid=' . $data['articleid'],
                'pic' => $data['imglink'],
                'fields' => array(
                    'fulltitle' => str_replace('\\\'', '&#39;', addslashes($data['title'])),
                    'date' => date('Y-m-d H:i:s', $data['date']),
                    'date_year' => date('Y', $data['date']),
                    'date_month' => date('m', $data['date']),
                    'date_day' => date('d', $data['date']),
                    'date_hour' => date('H', $data['date']),
                    'date_i' => date('i', $data['date']),
                    'date_s' => date('s', $data['date']),
                    'collecttime' => date('Y-m-d H:i:s', intval($data['collecttime'])),
                    'collecttime_year' => date('Y', $data['collecttime']),
                    'collecttime_month' => date('m', $data['collecttime']),
                    'collecttime_day' => date('d', $data['collecttime']),
                    'collecttime_hour' => date('H', $data['collecttime']),
                    'collecttime_i' => date('i', $data['collecttime']),
                    'collecttime_s' => date('s', $data['collecttime']),
                    'classid' => intval($data['classid']),
                    'classname' => $_G['cache']['wq_wechatcollecting_class'][$data['classid']]['classname'],
                    'wechatid' => $data['wechatid'],
                    'wechat_url' => 'plugin.php?id=wq_wechatshow&mod=view&wid=' . $data['wechatid'],
                    'wechatname' => $data['name'],
                    'summary' => $summary,
                    'openid' => $data['openid'],
                    'uid' => intval($data['uid']),
                    'username' => $data['username'],
                    'displayorder' => intval($data['displayorder']),
                    'views' => intval($data['views']),
                    'source_url' => $data['url'],
                )
            );
        }


        return array('html' => '', 'data' => $list);
    }

    function article_headimg_and_bgimg_url($imgurl) {
        global $_G;
        if (empty($imgurl)) {
            return $imgurl;
        }

        $new_imgurl = $imgurl;
        if (strpos($imgurl, "wq_wechatcollecting/") === 0 || strpos($imgurl, "portal/") === 0) {
            $attachurl = !$_G['setting']['attachurl'] ? 'data/attachment/' : $_G['setting']['attachurl'];
            $parse = parse_url($attachurl);
            $attachurl = !isset($parse['host']) ? $_G['siteurl'] . $attachurl : $attachurl;

            $new_imgurl = $attachurl . $imgurl;
        }
        return $new_imgurl;
    }

}

?>
