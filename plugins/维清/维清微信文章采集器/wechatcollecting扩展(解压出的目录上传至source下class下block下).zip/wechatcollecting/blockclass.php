<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_common.php';
$langfile = DISCUZ_ROOT . './source/language/wechatcollecting/language_diy.' . currentlang() . '.php';
$includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wechatcollecting');
include $includefile;

$blockclass = array(
	'name' => $Plang['66bef5f215c8d682'],
);
