<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_wq_wechat extends discuz_block {

    var $setting = array();

    function name() {
        return $this->lang['9882793618bd4605'];
    }

    function blockclass() {
        return array('wqwechat', $this->lang['6b5f1c9024ca93ed']);
    }

    function block_wq_wechat() {

        include DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_common.php';
        $langfile = DISCUZ_ROOT . './source/language/wechatcollecting/language_diy.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wechatcollecting');
        include $includefile;
        $this->lang = $Plang;

        $this->setting = array(
            'id' => array(
                'title' => $this->lang['bfe18c428479227d'],
                'type' => 'text',
            ),
            'wechatid' => array(
                'title' => $this->lang['9845b4dff22b734d'],
                'type' => 'text',
            ),
            'name' => array(
                'title' => $this->lang['06aa76dda2b26ab4'],
                'type' => 'text',
            ),
            'classid' => array(
                'title' => $this->lang['917dab32b6b6d29d'],
                'type' => 'mselect',
                'value' => array(array(0, $this->lang['d2d44c0a062c579b'])),
                'default' => array(0),
            ),
            'displayorder' => array(
                'title' => $this->lang['b4ae459efe0eb1e2'],
                'type' => 'mradio',
                'value' => array(
                    array('collecttime', $this->lang['0c6dad2d9c8ed5ca']),
                    array('views', $this->lang['1a3c44f8c9323fb4']),
                    array('articlenum', $this->lang['696e134b32df519c']),
                    array('favorites', $this->lang['9aeb2a5540926c39']),
                ),
                'default' => 'collecttime',
            ),
            'maximum' => array(
                'title' => $this->lang['15c9bee0f78b5f7c'],
                'type' => 'text',
                'default' => 50
            ),
            'maximum_summary' => array(
                'title' => $this->lang['3eae1810a3fa864b'],
                'type' => 'text',
                'default' => 100
            ),
            'start' => array(
                'title' => $this->lang['dc6c20500f7d6df9'],
                'type' => 'number',
                'default' => 0
            ),
        );
    }

    function fields() {
        return array(
            'title' => array('name' => $this->lang['6ea4e4a60964d568'], 'formtype' => 'title', 'datatype' => 'title'),
            'id' => array('name' => 'ID', 'formtype' => 'text', 'datatype' => 'int'),
            'url' => array('name' => $this->lang['7afd47d146c9888e'], 'formtype' => 'text', 'datatype' => 'string'),
            'pic' => array('name' => $this->lang['8bab8fc8360e1261'], 'formtype' => 'pic', 'datatype' => 'pic'),
            'collecttim' => array('name' => $this->lang['3d32e8e71b532637'], 'formtype' => 'text', 'datatype' => 'string'),
            'classname' => array('name' => $this->lang['772b1a1ea4453642'], 'formtype' => 'text', 'datatype' => 'string'),
            'classid' => array('name' => $this->lang['8916e94f1bb47bd2'], 'formtype' => 'text', 'datatype' => 'int'),
            'articlenum' => array('name' => $this->lang['e9e182c83f767400'], 'formtype' => 'text', 'datatype' => 'int'),
            'wechatid' => array('name' => $this->lang['337736b180cd27b2'], 'formtype' => 'text', 'datatype' => 'string'),
            'totalarticle' => array('name' => $this->lang['24070f91761505c7'], 'formtype' => 'text', 'datatype' => 'int'),
            'intro' => array('name' => $this->lang['df1a3b78e2f220ed'], 'formtype' => 'text', 'datatype' => 'string'),
            'openid' => array('name' => 'openid', 'formtype' => 'text', 'datatype' => 'string'),
            'qrcode' => array('name' => $this->lang['9651ffd026561977'], 'formtype' => 'text', 'datatype' => 'string'),
            'verify' => array('name' => $this->lang['d73db292e50d3379'], 'formtype' => 'text', 'datatype' => 'string'),
            'uid' => array('name' => $this->lang['bb613590ae73ed9b'], 'formtype' => 'text', 'datatype' => 'int'),
            'username' => array('name' => $this->lang['67e516c6434d60d7'], 'formtype' => 'text', 'datatype' => 'string'),
            'displayorder' => array('name' => $this->lang['7147c6a65ed97fda'], 'formtype' => 'text', 'datatype' => 'int'),
            'views' => array('name' => $this->lang['2b26ad735a10edf7'], 'formtype' => 'text', 'datatype' => 'int'),
        );
    }

    function getsetting() {
        global $_G;
        $setting = $this->setting;
        loadcache('wq_wechatcollecting_class');
        foreach ($_G['cache']['wq_wechatcollecting_class'] as $key => $value) {
            $setting['classid']['value'][] = array($key, $value['classname']);
        }
        return $setting;
    }

    function getdata($style, $parameter) {
        loadcache('wq_wechatcollecting_class');
        global $_G;
        $parameter = $this->cookparameter($parameter);

        $id = !empty($parameter['id']) ? explode(',', str_replace('��', ',', $parameter['id'])) : array();
        $wechatid = !empty($parameter['wechatid']) ? explode(',', str_replace('��', ',', $parameter['wechatid'])) : array();
        $name = isset($parameter['name']) ? $parameter['name'] : '';
        $displayorder = isset($parameter['displayorder']) ? $parameter['displayorder'] : '';
        $start = isset($parameter['start']) ? intval($parameter['start']) : 0;
        $maximum = isset($parameter['maximum']) ? intval($parameter['maximum']) : 10;
        $maximum_summary = isset($parameter['maximum_summary']) ? intval($parameter['maximum_summary']) : 20;
        $items = !empty($parameter['items']) ? intval($parameter['items']) : 10;

        $classid = array();
        if (!empty($parameter['classid'])) {
            if (isset($parameter['classid'][0]) && $parameter['classid'][0] == '0') {
                unset($parameter['classid'][0]);
            }
            $classid = $parameter['classid'];
        }

        $wheres = array();
        if ($id) {
            $wheres[] = ' `id` IN (' . dimplode($id) . ')';
        }
        if ($wechatid) {
            $wheres[] = '`wechatid` IN (' . dimplode($wechatid) . ')';
        }
        if ($name) {
            $wheres[] = '`name` like \'%' . $name . '%\'';
        }
        if ($classid) {
            $wheres[] = '`classid` IN (' . dimplode($classid) . ')';
        }

        $wheresql = implode(' AND ', $wheres);
        $sql = $wheresql ? ' AND ' . $wheresql : '';

        $query = DB::query("SELECT *
			FROM `" . DB::table('wq_wechatcollecting_wechat') . "`  $ffadd2
                        WHERE status=1 $sql  ORDER BY " . $displayorder . " DESC
		        LIMIT $start, $items"
        );

        $datalist = $list = array();
        while ($data = DB::fetch($query)) {
            $data['headimage'] = $this->wechat_headimg_and_bgimg_url($data['headimage']);
            $data['qrcode'] = $this->wechat_headimg_and_bgimg_url($data['qrcode']);

            $name = cutstr(str_replace('\\\'', '&#39;', addslashes($data['name'])), $maximum, '');
            $intro = cutstr($data['intro'], $maximum_summary, '');
            $list[] = array(
                'id' => $data['id'],
                'idtype' => 'id',
                'title' => $name,
                'url' => 'plugin.php?id=wq_wechatshow&mod=view&wid=' . $data['wechatid'],
                'pic' => $data['headimage'],
                'fields' => array(
                    'fulltitle' => str_replace('\\\'', '&#39;', addslashes($data['name'])),
                    'collecttim' => date('Y-m-d H:i:s', intval($data['collecttim'])),
                    'classid' => intval($data['classid']),
                    'classname' => $_G['cache']['wq_wechatcollecting_class'][$data['classid']]['classname'],
                    'articlenum' => intval($data['articlenum']),
                    'wechatid' => $data['wechatid'],
                    'totalarticle' => intval($data['totalarticle']),
                    'intro' => $intro,
                    'openid' => $data['openid'],
                    'qrcode' => $data['qrcode'],
                    'verify' => intval($data['verify']),
                    'automaticcollect' => intval($data['automaticcollect']),
                    'uid' => intval($data['uid']),
                    'username' => $data['username'],
                    'displayorder' => intval($data['displayorder']),
                    'views' => intval($data['views']),
                )
            );
        }

        return array('html' => '', 'data' => $list);
    }

    function wechat_headimg_and_bgimg_url($imgurl) {
        global $_G;

        if (empty($imgurl)) {
            return $imgurl;
        }

        $new_imgurl = $imgurl;
        if (strpos($imgurl, "wq_wechatcollecting/") === 0 || strpos($imgurl, "portal/") === 0) {
            $attachurl = !$_G['setting']['attachurl'] ? 'data/attachment/' : $_G['setting']['attachurl'];
            $parse = parse_url($attachurl);
            $attachurl = !isset($parse['host']) ? $_G['siteurl'] . $attachurl : $attachurl;

            $new_imgurl = $attachurl . $imgurl;
        }
        return $new_imgurl;
    }

}

?>