<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_rule.inc.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_rewrite/config/config.php';

$rule = array();
$wq_rewrite_setting = dunserialize($_G['setting']['wq_rewrite_setting']);
$rewritedata = array();

$rewritedata['rulesearch']['help_list'] = $wq_rewrite_setting['help_list']['rule'];
$rewritedata['rulereplace']['help_list'] = 'plugin.php?id=wq_help&cid={class_id}';
$rewritedata['rulevars']['help_list']['{class_id}'] = '(\w+)';


$rewritedata['rulesearch']['article_list'] = $wq_rewrite_setting['article_list']['rule'];
$rewritedata['rulereplace']['article_list'] = 'plugin.php?id=wq_wechatcollecting&mod=list&classid={class_id}&displayorder={displayorder}&page={page}';
$rewritedata['rulevars']['article_list']['{class_id}'] = '([0-9]+)';
$rewritedata['rulevars']['article_list']['{displayorder}'] = '([0-9]+)';
$rewritedata['rulevars']['article_list']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['article_view'] = $wq_rewrite_setting['article_view']['rule'];
$rewritedata['rulereplace']['article_view'] = 'plugin.php?id=wq_wechatcollecting&mod=view&articleid={article_id}';
$rewritedata['rulevars']['article_view']['{article_id}'] = '([0-9]+)';


$rewritedata['rulesearch']['wechat_list'] = $wq_rewrite_setting['wechat_list']['rule'];
$rewritedata['rulereplace']['wechat_list'] = 'plugin.php?id=wq_wechatshow&mod=list&classid={class_id}&displayorder={displayorder}&page={page}';
$rewritedata['rulevars']['wechat_list']['{class_id}'] = '([0-9]+)';
$rewritedata['rulevars']['wechat_list']['{displayorder}'] = '([0-9]+)';
$rewritedata['rulevars']['wechat_list']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['wechat_view'] = $wq_rewrite_setting['wechat_view']['rule'];
$rewritedata['rulereplace']['wechat_view'] = 'plugin.php?id=wq_wechatshow&mod=view&wid={wechat_no}&page={page}';
$rewritedata['rulevars']['wechat_view']['{wechat_no}'] = '(\w+)';
$rewritedata['rulevars']['wechat_view']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['wechat_view_new'] = $wq_rewrite_setting['wechat_view_new']['rule'];
$rewritedata['rulereplace']['wechat_view_new'] = 'plugin.php?id=wq_wechatshow&mod=view&wid={wechat_no}&displayorder={displayorder}&page={page}';
$rewritedata['rulevars']['wechat_view_new']['{wechat_no}'] = '(\w+)';
$rewritedata['rulevars']['wechat_view_new']['{displayorder}'] = '(\w+)';
$rewritedata['rulevars']['wechat_view_new']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['channel_index'] = $wq_rewrite_setting['channel_index']['rule'];
$rewritedata['rulereplace']['channel_index'] = 'plugin.php?id=wq_channel&mod=index&pageid={pageid}';
$rewritedata['rulevars']['channel_index']['{pageid}'] = '(\w+)';

$rewritedata['rulesearch']['buluo_list'] = $wq_rewrite_setting['buluo_list']['rule'];
$rewritedata['rulereplace']['buluo_list'] = 'buluo.php?mod=group&fid={fid}&page={page}';
$rewritedata['rulevars']['buluo_list']['{fid}'] = '([0-9]+)';
$rewritedata['rulevars']['buluo_list']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['buluo_view'] = $wq_rewrite_setting['buluo_view']['rule'];
$rewritedata['rulereplace']['buluo_view'] = 'buluo.php?mod=viewthread&tid={tid}&extra=page\%3D{prevpage}&page={page}';
$rewritedata['rulevars']['buluo_view']['{tid}'] = '([0-9]+)';
$rewritedata['rulevars']['buluo_view']['{page}'] = '([0-9]+)';
$rewritedata['rulevars']['buluo_view']['{prevpage}'] = '([0-9]+)';

$rewritedata['rulesearch']['buluo_class'] = $wq_rewrite_setting['buluo_class']['rule'];
$rewritedata['rulereplace']['buluo_class'] = 'buluo.php?gid={gid}&orderby={displayorder}&page={page}';
$rewritedata['rulevars']['buluo_class']['{gid}'] = '([0-9]+)';
$rewritedata['rulevars']['buluo_class']['{displayorder}'] = '(\w+)';
$rewritedata['rulevars']['buluo_class']['{page}'] = '([0-9]+)';

$rewritedata['rulesearch']['photo_list'] = $wq_rewrite_setting['photo_list']['rule'];
$rewritedata['rulereplace']['photo_list'] = 'plugin.php?id=wq_photo&mod=list&cid={cid}&displayorder={displayorder}&page={page}';
$rewritedata['rulevars']['photo_list']['{cid}'] = '([0-9]+)';
$rewritedata['rulevars']['photo_list']['{displayorder}'] = '(\w+)';
$rewritedata['rulevars']['photo_list']['{page}'] = '([0-9]+)';

$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';

foreach($rewritedata['rulesearch'] as $k => $v) {
	if(!$wq_rewrite_setting[$k]['available']) {
		continue;
	}

	$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
	$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
	$vkeys = array_keys($rewritedata['rulevars'][$k]);
	$rewritedata['rulereplace'][$k] = wq_rewrite_pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
	$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
	$rule['{apache1}'] .= "\t" . 'RewriteCond %{QUERY_STRING} ^(.*)$' . "\n\t" . 'RewriteRule ^(.*)/' . $v . '$ $1/' . wq_rewrite_pvadd($rewritedata['rulereplace'][$k]) . "&%1\n";
	if($k != 'forum_archiver') {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$' . "\n" . 'RewriteRule ^' . $v . '$ ' . $rewritedata['rulereplace'][$k] . "&%1\n";
	} else {
		$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$' . "\n" . 'RewriteRule ^archiver/' . $v . '$ archiver/' . $rewritedata['rulereplace'][$k] . "&%1\n";
	}
	$rule['{iis}'] .= 'RewriteRule ^(.*)/' . $v . '(\?(.*))*$ $1/' . addcslashes(wq_rewrite_pvadd($rewritedata['rulereplace'][$k]) . '&$' . ($pvmaxv + 1), '.?') . "\n";
	$rule['{iis7}'] .= "\t\t" . '&lt;rule name="' . $k . '"&gt;' . "\n\t\t\t" . '&lt;match url="^(.*/)*' . str_replace('\.', '.', $v) . '\?*(.*)$" /&gt;' . "\n\t\t\t" . '&lt;action type="Rewrite" url="{R:1}/' . str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(wq_rewrite_pvadd($rewritedata['rulereplace'][$k], 1) . '&{R:' . $pvmaxv . '}', '?')) . '" /&gt;' . "\n\t\t" . '&lt;/rule&gt;' . "\n";
	$rule['{zeus}'] .= 'match URL into $ with ^(.*)/' . $v . '\?*(.*)$' . "\n" . 'if matched then' . "\n\t" . 'set URL = $1/' . wq_rewrite_pvadd($rewritedata['rulereplace'][$k]) . '&$' . $pvmaxv . "\nendif\n";
	$rule['{nginx}'] .= 'rewrite ^([^\.]*)/' . $v . '$ $1/' . stripslashes(wq_rewrite_pvadd($rewritedata['rulereplace'][$k])) . " last;\n";
}
$rule['{nginx}'] .= "if (!-e \$request_filename) {\n\treturn 404;\n}";
echo str_replace(array_keys($rule), $rule, $Plang['rewrite_message']);

?>