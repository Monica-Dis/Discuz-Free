<?php

/**
 * DisM!应用中心：dism.taobao.com
 *
 * 应用更新支持：https://dism.taobao.com
 *
 * 最新插件：http://t.cn/Aiux1Jx1
 *
 * $Id: language.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$Plang = array(
	'pluginname' => '',
	'plugin' => '插件',
	'page' => '页面',
	'replace' => '标记',
	'rule' => '格式',
	'available' => '启用',
	'plugin' => '插件',
	'tips' => '<li>URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。</li>'
	. '<li>您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置</li>'
	. '<li>本插件可以为【维清】所有支持伪静态的插件设置伪静态规则。</li>',
	'update_setting_succeed' => '伪静态格式更新成功',
	'reset' => '恢复默认设置',
	'reset_setting_succeed' => '恢复默认设置成功，请直接勾选要开启的项目，然后点击提交',
	'wq_help' => '[维清]万能帮助中心',
	'help_list' => '问题列表页',
	'wq_wechatcollecting' => '[维清]微信文章采集器',
	'article_list' => '文章列表页',
	'article_view' => '文章详情页',
	'wq_wechatshow' => '[维清]微信导航',
	'wechat_list' => '微信列表页',
	'wechat_view' => '微信详情页（微信导航4.x版本规则，保留只为了兼容已收录页面，启用即可）',
	'wechat_view_new' => '微信详情页（微信导航5.0以上版本启用本规则）',
	'wq_channel' => '[维清]手机门户频道',
	'channel_index' => '频道列表页',
	'buluo_list' => '部落列表页',
	'buluo_view' => '部落详情页',
	'buluo_class' => '部落分类',
	'wq_buluo' => '[维清]DZ版兴趣部落',
	'photo_list' => '图集列表页',
	'wq_photo' => '[维清]超级图集',
	'rewrite_message' => '<h1>Apache Web Server(独立主机用户)</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
{apache1}&lt;/IfModule&gt;
</pre>

<h1>Apache Web Server(虚拟主机用户)</h1>
<pre class="colorbox">
# 将 RewriteEngine 模式打开
RewriteEngine On

# 修改以下语句中的 /discuz 为您的论坛目录地址，如果程序放在根目录中，请将 /discuz 修改为 /
RewriteBase /discuz

# Rewrite 维清插件伪静态规则，请务必放在伪静态规则文件的最前面
{apache2}
</pre>

<h1>IIS Web Server(独立主机用户)</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
{iis}
</pre>

<h1>IIS7 Web Server(独立主机用户)</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
{iis7}	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
{zeus}
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
{nginx}
</pre>',
);

?>