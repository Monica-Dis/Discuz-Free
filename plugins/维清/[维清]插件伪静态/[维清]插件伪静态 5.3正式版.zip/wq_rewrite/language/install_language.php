<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: install_language.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Plang_install = array(
	'isagreestat' => '&#x662F;&#x5426;&#x53D1;&#x9001;&#x5E94;&#x7528;&#x53CD;&#x9988;&#x4FE1;&#x606F;&#xFF0C;&#x4EE5;&#x4FBF;&#x5E2E;&#x52A9;&#x63D2;&#x4EF6;&#x6539;&#x8FDB;&#xFF0C;&#x83B7;&#x5F97;&#x66F4;&#x591A;&#x6280;&#x672F;&#x652F;&#x6301;&#xFF1F;&#x53CD;&#x9988;&#x4FE1;&#x606F;&#x5305;&#x62EC;&#x7F51;&#x5740;&#x3001;&#x7F51;&#x7AD9;&#x7248;&#x672C;&#x7B49;&#x4FE1;&#x606F;&#x3002;',
	'agreestat' => '&#x6B63;&#x5728;&#x53D1;&#x9001;&#x53CD;&#x9988;&#x4FE1;&#x606F;&#x2026;{stat_code}',
	'unagreestat' => '&#x8DF3;&#x8FC7;&#x53D1;&#x9001;&#x53CD;&#x9988;&#x4FE1;&#x606F;&#x6B65;&#x9AA4;&#xFF0C;&#x7EE7;&#x7EED;&#x5B8C;&#x6210;{operation}&#x64CD;&#x4F5C;&#x2026;}',
	'updatecacheing' => '&#x66F4;&#x65B0;&#x7F13;&#x5B58;&#x6570;&#x636E;...{cache}',
	'plugininstall' => '&#x5B89;&#x88C5;',
	'pluginupgrade' => '&#x5347;&#x7EA7;',
	'pluginuninstall' => '&#x5378;&#x8F7D;',
	'finish' => '&#x6570;&#x636E;&#x5E93;&#x66F4;&#x65B0;&#x5B8C;&#x6210;,&#x6B63;&#x5728;&#x5B8C;&#x6210;{operation}',
	'ok' => '&#x4FDD;&#x7559;&#x63D2;&#x4EF6;&#x6570;&#x636E;',
	'cancel' => '&#x5220;&#x9664;&#x63D2;&#x4EF6;&#x6570;&#x636E;',
	'tips' => '<img src="./source/plugin/wq_rewrite/static/images/tips.png" /><br /><br /><b>&#x8BF7;&#x9009;&#x62E9;&#x662F;&#x5426;&#x4FDD;&#x7559;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#xFF1F;</b><br /><br />&#x5982;&#x679C;&#x60A8;&#x5E0C;&#x671B;&#x63D2;&#x4EF6;&#x91CD;&#x88C5;&#x540E;&#xFF0C;&#x63D2;&#x4EF6;&#x539F;&#x6709;&#x6570;&#x636E;&#x4E0D;&#x53D7;&#x5F71;&#x54CD;&#xFF0C;&#x8BF7;&#x9009;&#x62E9;&#x201C;&#x4FDD;&#x7559;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#x201D;&#xFF01;<br /><br />&#x5982;&#x679C;&#x60A8;&#x9009;&#x62E9;&#x4E86;&#x201C;&#x5220;&#x9664;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#x201D;&#x5219;&#x4F1A;&#x5220;&#x9664;&#x6240;&#x6709;&#x63D2;&#x4EF6;&#x76F8;&#x5173;&#x7684;&#x6570;&#x636E;&#x8868;&#xFF0C;&#x4E14;&#x4E0D;&#x53EF;&#x6062;&#x590D;&#xFF01;<br /><br />&#x6CE8;&#x610F;&#xFF1A;&#x8FD9;&#x91CC;&#x8BF4;&#x7684;&#x53EA;&#x662F;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#xFF0C;&#x9009;&#x62E9;&#x201C;&#x5220;&#x9664;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#x201D;&#x4E5F;&#x4E0D;&#x4F1A;&#x5F71;&#x54CD;&#x7CFB;&#x7EDF;&#x5176;&#x4ED6;&#x529F;&#x80FD;&#xFF01;&#x8BF7;&#x6309;&#x5B9E;&#x9645;&#x9700;&#x6C42;&#x9009;&#x62E9;&#xFF01;',
);

?>