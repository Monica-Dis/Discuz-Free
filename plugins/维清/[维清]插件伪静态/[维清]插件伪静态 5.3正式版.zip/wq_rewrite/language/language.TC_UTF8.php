<?php

/**
 * 維清 [ Discuz!應用專家，深圳市維清互聯科技有限公司旗下Discuz!開發團隊 ]
 *
 * 应用更新支持：https://dism.taobao.com
 *
 * 最新插件：http://t.cn/Aiux1Jx1
 *
 * $Id: language.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$Plang = array(
	'pluginname' => '',
	'plugin' => '插件',
	'page' => '頁面',
	'replace' => '標記',
	'rule' => '格式',
	'available' => '啟用',
	'plugin' => '插件',
	'tips' => '<li>URL 靜態化可以提高搜索引擎抓取，開啟本功能需要對 Web 服務器增加相應的 Rewrite 支持，且會輕微增加服務器負擔。</li>'
	. '<li>您還可以調整每個頁面的靜態格式，但不得刪除其中的標記，重置靜態格式請留空。注意，修改靜態格式後您需要修改服務器的 Rewrite 規則設置</li>'
	. '<li>本插件可以為【維清】所有支持偽靜態的插件設置偽靜態規則。</li>',
	'update_setting_succeed' => '偽靜態格式更新成功',
	'reset' => '恢復默認設置',
	'reset_setting_succeed' => '恢復默認設置成功，請直接勾選要開啟的項目，然後點擊提交',
	'wq_help' => '[維清]萬能幫助中心',
	'help_list' => '問題列表頁',
	'wq_wechatcollecting' => '[維清]微信文章採集器',
	'article_list' => '文章列表頁',
	'article_view' => '文章詳情頁',
	'wq_wechatshow' => '[維清]微信導航',
	'wechat_list' => '微信列表頁',
	'wechat_view' => '微信詳情頁（微信導航4.x版本規則，保留只為了兼容已收錄頁面，啟用即可）',
	'wechat_view_new' => '微信詳情頁（微信導航5.0以上版本啟用本規則）',
	'wq_channel' => '[維清]手機門戶頻道',
	'channel_index' => '頻道列表頁',
	'buluo_list' => '部落列表頁',
	'buluo_view' => '部落詳情頁',
	'buluo_class' => '部落分類',
	'wq_buluo' => '[維清]DZ版興趣部落',
	'photo_list' => '圖集列表頁',
	'wq_photo' => '[維清]超級圖集',
	'rewrite_message' => '<h1>Apache Web Server(獨立主機用戶)</h1>
<pre class="colorbox">
&lt;IfModule mod_rewrite.c&gt;
	RewriteEngine On
{apache1}&lt;/IfModule&gt;
</pre>

<h1>Apache Web Server(虛擬主機用戶)</h1>
<pre class="colorbox">
# 將 RewriteEngine 模式打開
RewriteEngine On

# 修改以下語句中的 /discuz 為您的論壇目錄地址，如果程序放在根目錄中，請將 /discuz 修改為 /
RewriteBase /discuz

# Rewrite 維清插件偽靜態規則，請務必放在偽靜態規則文件的最前面
{apache2}
</pre>

<h1>IIS Web Server(獨立主機用戶)</h1>
<pre class="colorbox">
[ISAPI_Rewrite]

# 3600 = 1 hour
CacheClockRate 3600

RepeatLimit 32

# Protect httpd.ini and httpd.parse.errors files
# from accessing through HTTP
{iis}
</pre>

<h1>IIS7 Web Server(獨立主機用戶)</h1>
<pre class="colorbox">
&lt;rewrite&gt;
	&lt;rules&gt;
{iis7}	&lt;/rules&gt;
&lt;/rewrite&gt;
</pre>

<h1>Zeus Web Server</h1>
<pre class="colorbox">
{zeus}
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">
{nginx}
</pre>',
);

?>