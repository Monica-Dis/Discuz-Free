<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_rewrite.inc.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_rewrite/config/config.php';
if($_GET['mod'] == 'reset') {
	DB::query("DELETE FROM " . DB::table('common_setting') . " WHERE skey = 'wq_rewrite_setting'");
	updatecache('setting');
	cpmsg($Plang['reset_setting_succeed'], 'action=plugins&operation=config&do=' . $plugin_id . '&identifier=wq_rewrite&pmod=admincp_rewrite', 'succeed');
}
if(!submitcheck('settingsubmit')) {

	showtips($Plang['tips']);
	showformheader('plugins&operation=config&identifier=wq_rewrite&pmod=admincp_rewrite');
	showtableheader();
	showtitle($Plang['setting']);
	showsubtitle(array($Plang['plugin'], $Plang['page'], $Plang['replace'], $Plang['rule'], $Plang['available']));
	wq_rewrite_get_html();
	showsubmit('settingsubmit', 'submit', '', '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin_id . '&identifier=wq_rewrite&pmod=admincp_rewrite&mod=reset">' . $Plang['reset'] . '</a>');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {

	wq_rewrite_update_setting(serialize($_GET['wq_rewrite_setting']));

	cpmsg($Plang['update_setting_succeed'], 'action=plugins&operation=config&do=' . $plugin_id . '&identifier=wq_rewrite&pmod=admincp_rewrite', 'succeed');
}
//From: Dism_taobao-com
?>