<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_rewrite_get_html()
{
	global $_G;
	global $Plang;
	$_var_2 = array("help_list" => array("wq_help", "list-{class_id}.html", "{class_id}"), "article_list" => array("wq_wechatcollecting", "articlelist-{class_id}-{displayorder}-{page}.html", "{class_id},{displayorder},{page}"), "article_view" => array("wq_wechatcollecting", "wechatarticle-{article_id}.html", "{article_id}"), "wechat_list" => array("wq_wechatshow", "wechatlist-{class_id}-{displayorder}-{page}.html", "{class_id},{displayorder},{page}"), "wechat_view" => array("wq_wechatshow", "wechat-{wechat_no}-{page}.html", "{wechat_no},{page}"), "wechat_view_new" => array("wq_wechatshow", "wechat-{wechat_no}-{displayorder}-{page}.html", "{wechat_no},{displayorder},{page}"), "channel_index" => array("wq_channel", "channel-{pageid}.html", "{pageid}"), "buluo_view" => array("wq_buluo", "buluo-{tid}-{page}-{prevpage}.html", "{tid},{page},{prevpage}"), "buluo_list" => array("wq_buluo", "buluo-{fid}-{page}.html", "{fid},{page}"), "buluo_class" => array("wq_buluo", "buluo-{gid}-{displayorder}-{page}.html", "{fid},{displayorder},{page}"), "photo_list" => array("wq_photo", "list-{cid}-{displayorder}-{page}.html", "{cid},{displayorder},{page}"));
	$_var_3 = dunserialize($_G["setting"]["wq_rewrite_setting"]);
	foreach ($_var_2 as $_var_4 => $_var_5) {
		if ($_var_3[$_var_4]["rule"]) {
			$_var_6 = $_var_3[$_var_4]["rule"];
		} else {
			$_var_6 = $_var_5[1];
		}
		$_var_7 = '';
		if ($_var_3[$_var_4]["available"]) {
			$_var_7 = " checked=\"checked\"";
		}
		showtablerow('', array("width=\"200\"", "width=\"300\"", "width=\"300\"", "class=\"longtxt\"", "class=\"td25\""), array($Plang[$_var_5[0]], $Plang[$_var_4], $_var_5[2], "<input type=\"text\" name=\"wq_rewrite_setting[" . $_var_4 . "][rule]\" class=\"txt\" value=\"" . $_var_6 . "\" />", "<input type=\"checkbox\" name=\"wq_rewrite_setting[" . $_var_4 . "][available]\" class=\"checkbox\" value=\"1\"" . $_var_7 . " />"));
	}
}
function wq_rewrite_update_setting($_arg_0)
{
	C::t("common_setting")->update("wq_rewrite_setting", $_arg_0);
	updatecache("setting");
}
function wq_rewrite_pvsort($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = "/";
	$_var_4 = '';
	foreach ($_arg_0 as $_var_5) {
		$_var_3 = $_var_3 . ($_var_4 . preg_quote($_var_5));
		$_var_4 = "|";
	}
	$_var_3 = $_var_3 . "/";
	preg_match_all($_var_3, $_arg_1, $_var_6);
	$_var_6 = $_var_6[0];
	$_var_6 = array_flip($_var_6);
	foreach ($_var_6 as $_arg_0 => $_var_7) {
		$_arg_2 = str_replace($_arg_0, "\$" . ($_var_7 + 1), $_arg_2);
	}
	return $_arg_2;
}
function wq_rewrite_pvadd($_arg_0, $_arg_1 = 0)
{
	$_arg_0 = str_replace(array("\$3", "\$2", "\$1"), array("~4", "~3", "~2"), $_arg_0);
	if (!$_arg_1) {
		return str_replace(array("~4", "~3", "~2"), array("\$4", "\$3", "\$2"), $_arg_0);
	}
	return str_replace(array("~4", "~3", "~2"), array("{R:4}", "{R:3}", "{R:2}"), $_arg_0);
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}