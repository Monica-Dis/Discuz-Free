<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_rewrite/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		if(is_file($filepath = DISCUZ_ROOT . './source/plugin/wq_addon_client/function/admincp/function_wikinaddons.php')) {
			require_once $filepath;
			wikinaddons_removelog('wq_rewrite.plugin');
		}
		$sql = <<<EOF

EOF;
		runquery($sql);
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_rewrite.php");
		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//From: Dism_taobao-com
?>