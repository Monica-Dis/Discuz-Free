<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_rewrite/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_rewrite/function/function_rewrite.php';
$Plang = wq_loadlang('wq_rewrite');

$setting = wq_loadsetting('wq_rewrite');

?>