<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-4-17 14:26:31Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_rewrite/class/base.class.php';
include_once DISCUZ_ROOT . './source/discuz_version.php';

class plugin_wq_rewrite extends plugin_wq_rewrite_base {

	function plugin_wq_rewrite() {
		global $_G;
		$wq_rewrite_setting = dunserialize($_G['setting']['wq_rewrite_setting']);
		$plugindomain = self::get_domain_list();

		$_G['domain']['pregxprw']['wq_help'] = $plugindomain['wq_help'] ? preg_quote('//' . $plugindomain['wq_help'] . '/', '/') : '';
		$_G['domain']['pregxprw']['wq_wechatcollecting'] = $plugindomain['wq_wechatcollecting'] ? preg_quote('http://' . $plugindomain['wq_wechatcollecting'] . '/', '/') : '';
		$_G['domain']['pregxprw']['wq_wechatshow'] = $plugindomain['wq_wechatshow'] ? preg_quote('//' . $plugindomain['wq_wechatshow'] . '/', '/') : '';
		$_G['domain']['pregxprw']['wq_channel'] = $plugindomain['wq_channel'] ? preg_quote('//' . $plugindomain['wq_channel'] . '/', '/') : '';
		$_G['domain']['pregxprw']['buluo'] = $plugindomain['buluo'] ? preg_quote('//' . $plugindomain['buluo'] . '/', '/') : '';
		$_G['domain']['pregxprw']['photo'] = $plugindomain['photo'] ? preg_quote('//' . $plugindomain['photo'] . '/', '/') : '';
		if(DISCUZ_VERSION < 'X3.3' && DISCUZ_VERSION != 'F1.0') {
			if($wq_rewrite_setting['help_list']['available']) {
				$_G['setting']['output']['preg']['search'] ['help_list'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['wq_help'] . ")plugin.php\?id\=wq_help&(amp;)?cid\=(\w+)\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['help_list'] = "plugin_wq_rewrite::rewriteoutput('help_list', 0, '\\1', '\\3', '\\4')";
			}
			if($wq_rewrite_setting['article_list']['available']) {
				$_G['setting']['output']['preg']['search']['article_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw'] ['wq_wechatcollecting'] . ")plugin.php\?id\=wq_wechatcollecting&mod\=list(&classid\=(\d+))?(&displayorder\=(\d+))?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['article_list'] = "plugin_wq_rewrite::rewriteoutput('article_list', 0, '\\1', '\\3','\\5','\\7', '\\8')";
			}

			if($wq_rewrite_setting['article_view']['available']) {
				$_G['setting']['output']['preg']['search']['article_view'] = "/<a href\=\"(" . $_G['domain']['pregxprw'] ['wq_wechatcollecting'] . ")plugin.php\?id\=wq_wechatcollecting&(amp;)?mod\=view&(amp;)?articleid\=(\d+)\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['article_view'] = "plugin_wq_rewrite::rewriteoutput('article_view', 0, '\\1', '\\4', '\\5')";
			}

			if($wq_rewrite_setting['wechat_list']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_list'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=list(&classid\=(\d+))?(&displayorder\=(\d+))?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['wechat_list'] = "plugin_wq_rewrite::rewriteoutput('wechat_list', 0, '\\1', '\\3', '\\5', '\\7', '\\8')";
			}

			if($wq_rewrite_setting['wechat_view_new']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_view_new'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=view&wid\=(\w+)?(&displayorder\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['wechat_view_new'] = "plugin_wq_rewrite::rewriteoutput('wechat_view_new', 0, '\\1', '\\2', '\\4', '\\6', '\\7')";
			}

			if($wq_rewrite_setting['wechat_view']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_view'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=view&wid\=(\w+)?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['wechat_view'] = "plugin_wq_rewrite::rewriteoutput('wechat_view', 0, '\\1', '\\2', '\\4', '\\5')";
			}
			if($wq_rewrite_setting['channel_index']['available']) {
				$_G['setting']['output']['preg']['search']['channel_index'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_channel'] . ")plugin.php\?id\=wq_channel&(amp;)?mod\=index&(amp;)?pageid\=(\w+)\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['channel_index'] = "plugin_wq_rewrite::rewriteoutput('channel_index', 0, '\\1', '\\4', '\\5')";
			}
			if($wq_rewrite_setting['buluo_view']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_view'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['buluo'] . ")buluo.php\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['buluo_view'] = "plugin_wq_rewrite::rewriteoutput('buluo_view',0, '\\1', '\\3', '\\8', '\\6', '\\9')";
			}
			if($wq_rewrite_setting['buluo_list']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['buluo'] . ")buluo.php\?mod\=group&(amp;)?fid\=(\d+)(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['buluo_list'] = "plugin_wq_rewrite::rewriteoutput('buluo_list', 0, '\\1', '\\3', '\\5', '\\6')";
			}

			if($wq_rewrite_setting['buluo_class']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_class'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['buluo'] . ")buluo.php\?gid\=(\d+)?(&orderby\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['buluo_class'] = "plugin_wq_rewrite::rewriteoutput('buluo_class', 0, '\\1', '\\2', '\\4', '\\6')";
			}

			if($wq_rewrite_setting['photo_list']['available']) {
				$_G['setting']['output']['preg']['search']['photo_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['photo'] . ")plugin.php\?id\=wq_photo&mod\=list(&cid\=(\d+))?(&displayorder\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['photo_list'] = "plugin_wq_rewrite::rewriteoutput('photo_list', 0, '\\1', '\\3', '\\5', '\\7', '\\8')";
			}
		} else {
			if($wq_rewrite_setting['help_list']['available']) {
				$_G['setting']['output']['preg']['search']['help_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_help'] . ")plugin.php\?id\=wq_help&(amp;)?cid\=(\w+)\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['help_list'] = 'plugin_wq_rewrite::rewriteoutput(\'help_list\', 0,$matches[1], $matches[3], $matches[4])';
			}
			if($wq_rewrite_setting['article_list']['available']) {
				$_G['setting']['output']['preg']['search']['article_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_wechatcollecting'] . ")plugin.php\?id\=wq_wechatcollecting&mod\=list(&classid\=(\d+))?(&displayorder\=(\d+))?(&amp;page\=(\d+))?\"([^\>]*)\>/";

				$_G['setting']['output']['preg']['replace']['article_list'] = 'plugin_wq_rewrite::rewriteoutput(\'article_list\', 0, $matches[1], $matches[3], $matches[5], $matches[7], $matches[8])';
			}

			if($wq_rewrite_setting['article_view']['available']) {
				$_G['setting']['output']['preg']['search']['article_view'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_wechatcollecting'] . ")plugin.php\?id\=wq_wechatcollecting&(amp;)?mod\=view&(amp;)?articleid\=(\d+)\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['article_view'] = 'plugin_wq_rewrite::rewriteoutput(\'article_view\', 0, $matches[1], $matches[4], $matches[5])';
			}

			if($wq_rewrite_setting['wechat_list']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=list(&classid\=(\d+))?(&displayorder\=(\d+))?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['wechat_list'] = 'plugin_wq_rewrite::rewriteoutput(\'wechat_list\', 0,$matches[1], $matches[3], $matches[5], $matches[7], $matches[8])';
			}

			if($wq_rewrite_setting['wechat_view_new']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_view_new'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=view&wid\=(\w+)?(&displayorder\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['wechat_view_new'] = 'plugin_wq_rewrite::rewriteoutput(\'wechat_view_new\', 0,$matches[1], $matches[2], $matches[4], $matches[6], $matches[7])';
			}

			if($wq_rewrite_setting['wechat_view']['available']) {
				$_G['setting']['output']['preg']['search']['wechat_view'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['wq_wechatshow'] . ")plugin.php\?id\=wq_wechatshow&mod\=view&wid\=(\w+)?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['wechat_view'] = 'plugin_wq_rewrite::rewriteoutput(\'wechat_view\', 0, $matches[1], $matches[2], $matches[4], $matches[5])';
			}
			if($wq_rewrite_setting['channel_index']['available']) {
				$_G['setting']['output']['preg']['search']['channel_index'] = "/<a href\=\"(" . $_G['domain']['pregxprw'] ['wq_channel'] . ")plugin.php\?id\=wq_channel&(amp;)?mod\=index&(amp;)?pageid\=(\w+)\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['channel_index'] = 'plugin_wq_rewrite::rewriteoutput(\'channel_index\', 0, $matches[1], $matches[4], $matches[5])';
			}

			if($wq_rewrite_setting['buluo_view']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_view'] = "/<a href\=\"(" . $_G['domain'] ['pregxprw']['buluo'] . ")buluo.php\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['buluo_view'] = 'plugin_wq_rewrite::rewriteoutput(\'buluo_view\',0, $matches[1], $matches[3], $matches[8], $matches[6], $matches[9])';
			}
			if($wq_rewrite_setting['buluo_list']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['buluo'] . ")buluo.php\?mod\=group&(amp;)?fid\=(\d+)(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['buluo_list'] = 'plugin_wq_rewrite::rewriteoutput(\'buluo_list\', 0, $matches[1], $matches[3], $matches[5], $matches[6])';
			}
			if($wq_rewrite_setting['buluo_class']['available']) {
				$_G['setting']['output']['preg']['search']['buluo_class'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['buluo'] . ")buluo.php\?gid\=(\d+)?(&orderby\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['buluo_class'] = 'plugin_wq_rewrite::rewriteoutput(\'buluo_class\', 0, $matches[1], $matches[2], $matches[4], $matches[6])';
			}

			if($wq_rewrite_setting['photo_list']['available']) {
				$_G['setting']['output']['preg']['search']['photo_list'] = "/<a href\=\"(" . $_G['domain']['pregxprw']['photo'] . ")plugin.php\?id\=wq_photo&mod\=list(&cid\=(\d+))?(&displayorder\=(\w+))?(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['photo_list'] = 'plugin_wq_rewrite::rewriteoutput(\'photo_list\', 0, $matches[1], $matches[3], $matches[5], $matches[7], $matches[8])';
			}
		}
		foreach($plugindomain as $key => $value) {
			if($value) {
				$_G['setting']['output']['str']['search'][$key] = '"plugin.php?id=' . $key;
				$_G['setting']['output']['str']['replace'][$key] = '"http://' . $value . '/plugin.php?id=' . $key;
				if(DISCUZ_VERSION < 'X3.3' && DISCUZ_VERSION != 'F1.0') {
					$_G['setting']['output']['preg'] ['search'] [$key] = '/\/plugin.php\?id=' . $key . ':' . $key . '\"/';
					$_G['setting']['output']['preg']['replace'][$key] = '"';
				} else {
					$_G['setting']['output']['preg'] ['search'] [$key] = '/\/plugin.php\?id=' . $key . ':' . $key . '\"/';
					$_G['setting']['output']['preg']['replace'][$key] = '\'"\'';
				}
			}
		}
	}

	function get_domain_list() {
		global $_G;
		$list = array();
		if(!empty($_G['setting']['domain']['wikin_domain']['plugin'])) {
			foreach($_G['setting']['domain']['wikin_domain']['plugin'] as $key => $value) {
				if($value['idtype'] == 'plugin') {
					$plugin_id = substr($value['id'], 0, strpos(":", $value['id']));
					$list[$plugin_id] = $key;
				}
			}
		} else {
			foreach($_G['setting']['domain']['list'] as $key => $value) {
				if($value['idtype'] == 'plugin') {
					$list[$value['id']] = $key;
				}
			}
		}

		return $list;
	}

	function global_footer() {
		global $_G;



		return '<!-- rewrite_replace -->';
	}

	function rewriteoutput($page, $returntype, $host) {
		global $_G;

		$fextra = '';
		switch($page) {
			case 'help_list':
				list(,,, $class_id, $extra) = func_get_args();
				$r = array(
					'{class_id}' => $class_id ? $class_id : 0,
				);
				break;
			case 'article_list':
				list(,,, $re_class_id, $re_displayorder, $re_page, $extra) = func_get_args();
				$r = array(
					'{class_id}' => $re_class_id ? $re_class_id : 0,
					'{displayorder}' => $re_displayorder ? $re_displayorder : 0,
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'article_view':
				list(,,, $article_id, $extra) = func_get_args();
				$r = array(
					'{article_id}' => $article_id ? $article_id : 0,
				);
				break;
			case 'wechat_list':
				list(,,, $re_class_id, $re_displayorder, $re_page, $extra) = func_get_args();
				$r = array(
					'{class_id}' => $re_class_id ? $re_class_id : 0,
					'{displayorder}' => $re_displayorder ? $re_displayorder : 0,
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'wechat_view_new':
				list(,,, $re_wechat_no, $re_displayorder, $re_page, $extra) = func_get_args();
				$r = array(
					'{wechat_no}' => $re_wechat_no ? $re_wechat_no : 0,
					'{displayorder}' => $re_displayorder ? $re_displayorder : 'index',
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'wechat_view':
				list(,,, $re_wechat_no, $re_page, $extra) = func_get_args();
				$r = array(
					'{wechat_no}' => $re_wechat_no ? $re_wechat_no : 0,
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'channel_index':
				list(,,, $pageid, $extra) = func_get_args();
				$r = array(
					'{pageid}' => $pageid ? $pageid : 0,
				);
				break;
			case 'buluo_list':
				list(,,, $re_fid, $re_page, $extra) = func_get_args();
				$r = array(
					'{fid}' => $re_fid ? $re_fid : 0,
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'buluo_view':
				list(,,, $re_tid, $re_page, $re_prevpage, $extra) = func_get_args();
				$r = array(
					'{tid}' => $re_tid ? $re_tid : 0,
					'{page}' => $re_page ? $re_page : 1,
					'{prevpage}' => $re_prevpage && !IS_ROBOT ? $re_prevpage : 1,
				);
				break;
			case 'buluo_class':
				list(,,, $re_gid, $re_displayorder, $re_page, $extra) = func_get_args();
				$r = array(
					'{gid}' => $re_gid ? $re_gid : 0,
					'{displayorder}' => $re_displayorder ? $re_displayorder : 'displayorder',
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
			case 'photo_list':
				list(,,, $re_cid, $re_displayorder, $re_page, $extra) = func_get_args();
				$r = array(
					'{cid}' => $re_cid ? $re_cid : 0,
					'{displayorder}' => $re_displayorder ? $re_displayorder : 'lastpost',
					'{page}' => $re_page ? $re_page : 1,
				);
				break;
		}
		$wq_rewrite_setting = dunserialize($_G['setting']['wq_rewrite_setting']);
		$href = str_replace(array_keys($r), $r, $wq_rewrite_setting[$page]['rule']) . $fextra;

		if(!$returntype) {
			return '<a href="' . $host . $href . '"' . (!empty($extra) ? stripslashes($extra) : '') . '>';
		} else {
			return $host . $href;
		}
	}

}

class mobileplugin_wq_rewrite extends plugin_wq_rewrite {
}
//From: Dism_taobao-com
?>