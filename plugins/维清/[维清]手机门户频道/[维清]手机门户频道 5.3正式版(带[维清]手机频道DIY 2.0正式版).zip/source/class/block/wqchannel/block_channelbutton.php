<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: block_channelbutton.php 2015-4-9 21:49:52Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_channelbutton extends discuz_block {

    var $setting = array();
    var $lang = array();

    function block_channelbutton() {
        include DISCUZ_ROOT . './source/plugin/wq_channel/function/function_common.php';
        $langfile = DISCUZ_ROOT . './source/language/wqchannel/language_diy.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wqchannel');
        include $includefile;
        $this->lang = $Plang;

        $this->setting = array(
            'bids' => array(
                'title' => $this->lang['5933c6e20675cf57'],
                'type' => 'mselect',
                'value' => array(array(0, $this->lang['16853bda54120bf1'])),
                'default' => array(0),
            ),
            'orderby' => array(
                'title' => $this->lang['42abc1e524ae69dd'],
                'type' => 'mradio',
                'value' => array(
                    array('displayorder', $this->lang['5eaf6225b48732e2']),
                    array('dateline', $this->lang['fb19c1a3861f7dfa']),
                ),
                'default' => 'displayorder'
            ),
            'issilde' => array(
                'title' => $this->lang['6f0c42969e7c7214'],
                'type' => 'radio',
                'default' => '0'
            ),
            'rows' => array(
                'title' => $this->lang["9e64157c09d98a32"],
                'type' => 'mradio',
                'value' => array(
                    array('1', $this->lang['846ca2e676896080']),
                    array('2', $this->lang['9295d34efe0267cc']),
                    array('3', $this->lang['58e85a1772fcd41e']),
                ),
                'default' => 1
            ),
            'cols' => array(
                'title' => $this->lang["b766a2a97efa4eba"],
                'type' => 'mradio',
                'value' => array(
                    array('2', $this->lang['ab759890e22ce3cd']),
                    array('3', $this->lang['f4a527ca5dbeee26']),
                    array('4', $this->lang['b93241c4c7c7eaa4']),
                    array('5', $this->lang['43f37498096ce8e4']),
                ),
                'default' => 5
            ),
            'titlelength' => array(
                'title' => $this->lang['76c725fd2cfc32e2'],
                'type' => 'text',
                'default' => 40
            ),
            'startrow' => array(
                'title' => 'threadlist_startrow',
                'type' => 'text',
                'default' => 0
            ),
        );
    }

    function fields() {
        return array(
            'did' => array('name' => $this->lang['ec757a02ee255e7b'], 'formtype' => 'text', 'datatype' => 'int'),
            'title' => array('name' => $this->lang['7431e76029678ec7'], 'formtype' => 'title', 'datatype' => 'title'),
            'url' => array('name' => $this->lang['44f8e54602760e18'], 'formtype' => 'text', 'datatype' => 'string'),
            'icon' => array('name' => $this->lang['dc668c1a3e68b51c'], 'formtype' => 'text', 'datatype' => 'string'),
            'color' => array('name' => $this->lang['5c09108379a54a1e'], 'formtype' => 'text', 'datatype' => 'string'),
            'backgroupcolor' => array('name' => $this->lang['03e7724664b15858'], 'formtype' => 'text', 'datatype' => 'string'),
            'dateline' => array('name' => $this->lang['2594059036dfede5'], 'formtype' => 'date', 'datatype' => 'date'),
            'wqclass' => array('name' => $this->lang["d1d700d5bd97bf1e"], 'formtype' => 'text', 'datatype' => 'string'),
        );
    }

    function name() {
        return $this->lang['5b2569b835a070cb'];
    }

    function blockclass() {
        return array('channelbutton', $this->lang['5b2569b835a070cb']);
    }

    function fieldsconvert() {
        return array(
            'wqchannel_channelslide' => array(
                'name' => $this->lang['c97694bd1d2b905f'],
                'script' => 'channelslide',
                'searchkeys' => array(),
                'replacekeys' => array(),
            ),
            'wqchannel_channellink' => array(
                'name' => $this->lang['e71755b523c8c8ca'],
                'script' => 'channellink',
                'searchkeys' => array(),
                'replacekeys' => array(),
            ),
            'wqchannel_channelad' => array(
                'name' => $this->lang['fe1022ac844b144d'],
                'script' => 'channelad',
                'searchkeys' => array(),
                'replacekeys' => array(),
            ),
            'wqchannel_channelclass' => array(
                'name' => $this->lang['40a0bc66ef317efa'],
                'script' => 'channelclass',
                'searchkeys' => array(),
                'replacekeys' => array(),
            ),
            'wqchannel_channeladwrit' => array(
                'name' => $this->lang['fe1022ac85rgtdhr'],
                'script' => 'channeladwrit',
                'searchkeys' => array(),
                'replacekeys' => array(),
            ),
        );
    }

    function getsetting() {
        global $_G;
        $setting = $this->setting;
        $reuslts = C::t("#wq_channel#wq_channel_block")->fetch_all_by_type(1);
        foreach ($reuslts as $key => $reuslt) {
            $setting['bids']['value'][] = array($reuslt['bid'], $reuslt['blockname']);
        }
        return $setting;
    }

    function getdata($style, $parameter) {
        $parameter = $this->cookparameter($parameter);

        $displayorder = isset($parameter['orderby']) ? (in_array($parameter['orderby'], array('displayorder', 'dateline')) ? $parameter['orderby'] : 'displayorder') : 'displayorder';
        $titlelength = !empty($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
        $startrow = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
        $items = !empty($parameter['items']) ? intval($parameter['items']) : 10;
        $rows = $parameter['rows'] ? intval($parameter['rows']) : 1;
        $cols = $parameter['cols'] ? intval($parameter['cols']) : 5;
        $issilde = $parameter['issilde'] ? intval($parameter['issilde']) : 0;
        $class = '';
        $num = $rows * $cols;
        if (!$issilde) {
            $items = $num;
        }

        switch ($cols) {
            case 2:
                $class = "wqplateli_two";
                break;
            case 3:
                $class = "wqplateli_three";
                break;
            case 5:
                $class = "wqplateli_five";
                break;
        }

        $bids = array();
        if (!empty($parameter['bids'])) {
            if (isset($parameter['bids'][0]) && $parameter['bids'][0] == '0') {
                unset($parameter['bids'][0]);
            }
            $bids = $parameter['bids'];
        }
        $orderby = $displayorder == "displayorder" ? 'ASC' : "DESC";

        $wheres = array();
        if ($bids) {
            $wheres[] = ' d.bid IN (' . dimplode($bids) . ')';
        }

        $wheresql = implode(' AND ', $wheres);

        $sql = $wheresql ? ' AND ' . $wheresql : '';

        $query = DB::query("SELECT d.*
			FROM `" . DB::table('wq_channel_block_data') . "` d
                        LEFT JOIN `" . DB::table('wq_channel_block') . "` b
                        ON d.bid=b.bid
                        WHERE b.type=1 AND b.status=1 AND d.status=1 $sql  ORDER BY d.$displayorder  $orderby
		        LIMIT $startrow, $items"
        );
        $data = $list = array();
        while ($data = DB::fetch($query)) {
            $data['data'] = unserialize($data['data']);
            $title = cutstr(str_replace('\\\'', '&#39;', addslashes($data['data']['title'])), $titlelength, '');
            $url = str_replace("&amp;", "&", $data['data']['url']);
            $color = $data['data']['color'] ? addslashes($data['data']['color']) : '#FF00CC';
            $backgroupcolor = $data['data']['backgroupcolor'] ? addslashes($data['data']['backgroupcolor']) : '#FF00CC';
            $list[] = array(
                'did' => $data['did'],
                'title' => $title,
                'url' => $url,
                'fields' => array(
                    'icon' => addslashes($data['data']['icon']),
                    'color' => $color,
                    'backgroupcolor' => $backgroupcolor,
                    'dateline' => $data['dateline'],
                    'script' => $data['data']['script'],
                    'mod' => $data['data']['mod'],
                    'idtype' => $data['data']['idtype'],
                    'id' => $data['data']['id'],
                    'wqclass' => $class,
                ),
            );
        }
//        echo "<pre>";
//        print_r($list);
//        exit();
        return array('html' => '', 'data' => $list);
    }

}
