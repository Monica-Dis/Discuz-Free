<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: block_wqdata.php 2015-4-9 21:49:52Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_wqdata extends discuz_block {

    var $setting = array();
    var $lang = array();

    function block_wqdata() {
        include DISCUZ_ROOT . './source/plugin/wq_channel/function/function_common.php';
        $langfile = DISCUZ_ROOT . './source/language/wqchannel/language_diy.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wqchannel');
        include $includefile;
        $this->lang = $Plang;

        $this->setting = array(
            'data_top' => array(
                'title' => 'blank_content',
                'type' => 'mtextarea',
                'default' => '<div class="wqseparate" data-type="divide"></div>',
            ),
            'wqstatic1' => array(
                'title' => $this->lang['e1a80565979a8a9f'],
                'type' => '<img src="./source/plugin/wq_channel/static/images/20161028184642.png">',
            )
        );
    }

    function fields() {
        return array();
    }

    function name() {
        return $this->lang['a8120f77688bfc24'];
    }

    function blockclass() {
        return array('data', $this->lang['a8120f77688bfc24']);
    }

    function getsetting() {
        global $_G;
        $settings = $this->setting;
        return $settings;
    }

    function getdata($style, $parameter) {
        require_once libfile('function/home');

        $arr = array('data_top', 'data_bottom');
        foreach ($parameter as $key => $val) {
            if (in_array($key, $arr)) {
                $content = $parameter[$key];
            }
        }
        $return = getstr($content, '', 1, 0, 0, 1);
        return array('html' => $return, 'data' => null);
    }

}
