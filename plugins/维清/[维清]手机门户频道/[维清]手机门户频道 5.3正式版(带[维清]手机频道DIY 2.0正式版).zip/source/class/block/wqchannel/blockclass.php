<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: blockclass.php 2015-4-9 21:49:52Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_channel/function/function_common.php';
$langfile = DISCUZ_ROOT . './source/language/wqchannel/language_diy.' . currentlang() . '.php';
$includefile = is_file($langfile) ? $langfile : libfile('language_diy', 'language/wqchannel');
include $includefile;

$blockclass = array(
    'name' => $Plang['66bef5f215c8d682'],
);
?>