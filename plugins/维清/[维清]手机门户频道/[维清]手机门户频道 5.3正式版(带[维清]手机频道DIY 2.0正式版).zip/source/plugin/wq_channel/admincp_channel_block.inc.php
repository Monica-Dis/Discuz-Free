<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * Author: Xiaoan <577169944@qq.com>
 *
 * $Id: admincp_channel_list.inc.php 2016-03-17 16:00:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/config.php';

$verhash = $_G['style']['verhash'];

echo <<<EOF
    <link rel="stylesheet" id="css_extstyle" type="text/css" href="source/plugin/wq_channel/static/font/iconfont.css?{$verhash}" />
    <link rel="stylesheet" type="text/css" href="{$setting['iconfont_url']}?{$verhash}" />
    <style tpye='text/css'>
        #tipslis li{color:#F00;}
        .hover td ul li{float:left;}
    </style>
EOF;

$ac = in_array($_GET['ac'], array('manage', 'del', 'adddata')) ? dhtmlspecialchars($_GET['ac']) : 'manage';
$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 10;
$start = ($page - 1 ) * $perpage;

$type = !empty($_GET['type']) ? intval($_GET['type']) : 0;
$bid = !empty($_GET['bid']) ? intval($_GET['bid']) : 0;
$blockname = !empty($_GET['blockname']) ? dhtmlspecialchars($_GET['blockname']) : '';

$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_channel&pmod=admincp_channel_block';
$formurl = $url . '&ac=' . $ac;
$cpurl = 'action=' . $url;
$dcpurl = 'action=' . $formurl . "&type=" . $type . "&bid=" . $bid . "&blockname=" . $blockname;
$hrefurl = ADMINSCRIPT . '?action=' . $url;
$mpurl = ADMINSCRIPT . '?action=' . $formurl;

$types = array(
	'0' => $Plang['6db0bae39f173ea7'],
	'1' => $Plang['4f56a1a0762d0470'],
	'2' => $Plang['1f1226b92667dce4'],
	'3' => $Plang['01d80d78c9bb438e'],
	'4' => $Plang['fddfe7bde987e202'],
	'5' => $Plang['40a0bc66ef317efa'],
	'6' => $Plang['e03d38583cc27da7'],
	'7' => $Plang['video_assembly'],
);

$types_4 = array(
	'1' => array(
		'title' => array($Plang['91a544ece9363e4f'], $Plang['a44acd00edee8947'], $Plang['501701a70e223fb2']),
		'js' => array(
			array(
				'id' => 'block_icon_',
				'name' => 'inserticon',
				"type" => 'icon',
			),
			array(
				'id' => 'block_color_',
				'name' => 'insertcolor',
				"type" => 'color',
			),
			array(
				'id' => 'block_backgroup_color_',
				'name' => 'insertbackgroupcolor',
				"type" => 'color',
			),
		),
	),
	'2' => array(
		'title' => array(),
		'js' => array(),
	),
	'3' => array(
		'title' => array($Plang['5ab31302b49e348f']),
		'js' => array(
			array(
				'id' => '',
				'name' => 'insertupimg',
				"type" => 'file',
				"style" => 'style="border:none;background:none;"',
			),
		),
	),
	'4' => array(
		'title' => array($Plang['5ab31302b49e348f']),
		'js' => array(
			array(
				'id' => '',
				'name' => 'insertupimg',
				"type" => 'file',
				"style" => 'style="border:none;background:none;"',
			),
		),
	),
	'5' => array(
		'title' => array($Plang["e5129785b9f31697"], $Plang['91a544ece9363e4f'], $Plang["46bb695ac39dbb49"], $Plang['3b6e3006ed7e1e0a']),
		'js' => array(
			array(
				'id' => '',
				'name' => 'insertsummary',
				"type" => 'textarea',
				'placeholder' => '',
				'rows' => 3,
				"cols" => 20,
			),
			array(
				'id' => 'block_icon_',
				'name' => 'inserticon',
				"type" => 'icon',
			),
			array(
				'id' => 'block_color_',
				'name' => 'insertcolor',
				"type" => 'color',
			),
			array(
				'id' => 'block_backgroup_color_',
				'name' => 'insertbackgroupcolor',
				"type" => 'color',
			),
		),
	),
	'6' => array(
		'title' => array($Plang['5ab31302b49e348f']),
		'js' => array(
			array(
				'id' => '',
				'name' => 'insertupimg',
				"type" => 'file',
				"style" => 'style="border:none;background:none;"',
			),
		),
	),
	'7' => array(
		'title' => array(),
		'js' => array(),
	),
);

if($ac == "manage") {
	if(!submitcheck('managesubmit')) {
		$tips = $Plang['72b4514ebcdbcca4'];
		showtips($tips);
		$displayorder = in_array($_GET['displayorder'], array('dateline', 'displayorder')) ? $_GET['displayorder'] : 'displayorder';
		$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? $_GET['ordertype'] : 'asc';
		$blockname = $_GET['blockname'] ? dhtmlspecialchars($_GET['blockname']) : "";
		$username = $_GET['username'] ? dhtmlspecialchars($_GET['username']) : "";

		$lists = C::t("#wq_channel#wq_channel_block")->fetch_all_by_search($blockname, $type, $username, $start, $perpage, $displayorder, $ordertype);
		$count = C::t("#wq_channel#wq_channel_block")->count_by_search($blockname, $type, $username);

		$mpurl .= $type ? '&type=' . $type : '';
		$mpurl .= !empty($blockname) ? '&blockname=' . $blockname : '';
		$mpurl .= !empty($username) ? '&username=' . $username : '';
		$mpurl .= !empty($ordertype) ? '&orderby=' . $ordertype : '';
		$mpurl .= !empty($displayorder) ? '&displayorder=' . $displayorder : '';

		$typehtml = select_html($types, 'type', "$type", false);
		$displayorder = select_html(array('displayorder' => $Plang['bd940fc8596f83d8'], 'dateline' => $Plang['7de4775a64db4b43'],), 'displayorder', $displayorder, false);
		$ordertypehtml = radio_html(array('desc' => $Plang['5bee37fbebf639d9'], 'asc' => $Plang['60f4919063d76ce2']), 'ordertype', $ordertype);

		showformheader($formurl, '', 'forms');
		showtableheader('', 'nobottom');
		showtablerow('', array('width="120px"', 'width="100px"', 'width="200px"', 'width="270px"', 'width="270px"', 'width="270px"', ''), array(
			$Plang['1670da9c2989259f'] . ':&nbsp;&nbsp;' . $displayorder,
			$ordertypehtml,
			$Plang['edfd5343724db141'] . ':&nbsp;&nbsp;' . $typehtml,
			$Plang['8b60e40e592a397d'] . ":&nbsp;&nbsp;<input size = \"25\" name=\"blockname\" type=\"text\" value=\"" . $blockname . "\"  placeholder=\"{$Plang['7ceb33359b50c8d9']}\"/>",
			$Plang['8e6d149c79dd0eda'] . ":&nbsp;&nbsp;<input size = \"25\" name=\"username\" type=\"text\" value=\"" . $username . "\" placeholder=\"{$Plang['33802af1819538fc']}\" />",
			"<input class=\"btn\" type=\"submit\" value=\"{$Plang['38224a4a6fc78c7c']}\" />", '',
		));
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();

		showformheader($formurl, '', 'managesubmit');
		showtableheader($Plang['fb1342101ca5a1ec'], 'nobottom');
		showsubtitle(array('', $Plang['bd940fc8596f83d8'], $Plang['8b60e40e592a397d'], $Plang['edfd5343724db141'], $Plang['04eb04651aeb0d87'], $Plang['a945e96fed6a07aa'], $Plang['7de4775a64db4b43'], $Plang['4e64f0e320d8b16b']));
		foreach($lists as $key => $val) {
			$status = $val['status'] ? 'checked' : '';
			showtablerow('', array("width='60px'", "width='80px'", "width='200px'", "width='120px'", "width='90px'", "width='170px'", "width='170px'", "width='260px'", ""), array(
				'<a name = "class_' . $val['bid'] . '"><input class = "fs" type = "checkbox" name = "delete[' . $val['bid'] . ']" value = "' . $val['bid'] . '" /></a> ',
				'<input style="width:40px;" type="number" name="displayorder[' . $val['bid'] . ']" value="' . $val['displayorder'] . '" >',
				'<input  type="text" name="blockname[' . $val['bid'] . ']" value="' . $val['blockname'] . '" >',
				$types[$val['type']],
				'<input class = "fs" type = "checkbox" name = "status[' . $val['bid'] . ']" value = "1" ' . $status . ' />',
				$val['username'] . "(" . $val['uid'] . ")",
				date("Y-m-d H:i:s", $val['dateline']) . '<input type="hidden" name="bid[' . $val['bid'] . ']" value="' . $val['bid'] . '" >',
				'<a onclick="_del_confirm()" href="' . $hrefurl . '&ac=del&formhash=' . FORMHASH . '&bid=' . $val['bid'] . '&type=' . $val['type'] . '">' . $Plang['0f65e168abc3b4e9'] . '</a>'
				. '<a href="' . $hrefurl . '&ac=adddata&bid=' . $val['bid'] . '&type=' . $val['type'] . '&blockname=' . rawurlencode($val['blockname']) . '">&nbsp;&nbsp;' . $Plang['887324cc946dac3b'] . '</a>',
				"",
				)
			);
		}

		$multi = multi($count, $perpage, $page, $mpurl);
		echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "javascript:;" onclick = "wq_addrow(this, 0, 0)" class = "addtr">' . $Plang['b7d63548f8406158'] . '</a></div></td></tr>';
		showsubmit('managesubmit', 'submit', 'del', '', $multi);
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		$insertstatus = '<input name="insertstatus[\'+addrowkey+\']" value="1"  type="checkbox" checked="checked">';
		$inserttype = select_html($types, 'inserttype[\'+addrowkey+\']', "", false, false);
		echo <<<EOF
    <script type='text/JavaScript'>
        var addrowdirect = 0;
    var addrowkey = 0;
    function wq_addrow(obj, type,flag) {
        if(flag == 2){
            addrowkey--;
        }else{
            var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
            if(!addrowdirect) {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
            } else {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
            }
          var rowtypedata = [[[1,''],[1,'<input name = "insertdisplayorder[]" style="width:40px"  value="0" type = "number">'],[1,'<input name = "insertblockname[]"  value="" type = "text">'],[1, '{$inserttype}'],[1,'<div>{$insertstatus}&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this),wq_addrow(this, 0,2)">{$Plang['0d9efacf5089d88c']}</a></div>']],];

            var typedata = rowtypedata[type];
            for(var i = 0; i <= typedata.length - 1; i++) {
                    var cell = row.insertCell(i);
                    cell.colSpan = typedata[i][0];
                    var tmp = typedata[i][1];
                    if(typedata[i][2]) {
                            cell.className = typedata[i][2];
                    }
                    tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                    tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return wq_addrow.arguments[parseInt($2) + 1];});
                    cell.innerHTML = tmp;
            }
            addrowkey ++;
            addrowdirect = 0;
        }
    }
        function _del_confirm() {
            if (!confirm("{$Plang['97abeb5464e370fe']}")) {
                window.event.returnValue = false;
            }
        }
    </script>
EOF;
	} else {

		$n = $m = 0;

		foreach($_GET['bid'] as $key => $bid) {
			if($bid == $_GET['delete'][$bid]) {
				wq_channel_delete_block_by_bid($bid);
			} else {
				$blockname = dhtmlspecialchars($_GET['blockname'][$bid]);
				if(empty($blockname)) {
					$n ++;
					continue;
				}

				$data = array(
					'blockname' => $_GET['blockname'][$bid],
					'displayorder' => $_GET['displayorder'][$bid],
					'status' => $_GET['status'][$bid],
				);
				C::t("#wq_channel#wq_channel_block")->update($bid, $data);
			}
		}

		foreach($_GET['insertblockname'] as $key => $val) {
			$blockname = dhtmlspecialchars($val);
			$type = intval($_GET['inserttype'][$key]);

			if(empty($blockname) || !$type) {
				$m ++;
				continue;
			}
			$data = array(
				'blockname' => $blockname,
				'type' => $type,
				'displayorder' => $_GET['insertdisplayorder'][$key],
				'status' => $_GET['insertstatus'][$key],
			);
			$data['uid'] = $_G['uid'];
			$data['username'] = $_G['username'];
			$data['dateline'] = TIMESTAMP;

			C::t("#wq_channel#wq_channel_block")->insert($data);
		}

		if($n > 0 || $m > 0) {
			$msg = sprintf($Plang['adb7a7422b9fa10f'], $n, $m);
			cpmsg($msg, $cpurl, 'error');
		} else {
			cpmsg($Plang['8ee460c51dbd9dee'], $cpurl, 'succeed');
		}
	}
}

if($ac == 'del' && FORMHASH == $_GET['formhash']) {
	wq_channel_delete_block_by_bid($bid);
	cpmsg($Plang['8987fdbb54a9953a'], $cpurl, "succeed");
}
if($ac == 'adddata') {

	if(!submitcheck('adddatasubmit')) {

		$tips = $Plang['09b022b80f7c3ea8'];
		showtips($tips);
		$mpurl .= $type ? '&type=' . $type : '';
		$mpurl .= $bid ? '&bid=' . $bid : '';

		$lists = C::t("#wq_channel#wq_channel_block_data")->fetch_all_by_search($bid, $start, $perpage);
		$count = C::t("#wq_channel#wq_channel_block_data")->count_by_search($bid);

		showformheader($formurl, 'enctype', 'adddatasubmit');
		showtableheader($Plang['c5f5d8ac1a0f487d'] . "&nbsp;&nbsp;-&nbsp;&nbsp;" . $_GET['blockname'], 'nobottom');
		wq_channel_by_type_show_data_title($types_4[$type]['title']);
		foreach($lists as $key => $val) {
			$arrs = wq_channel_by_type_show_data($val, $type);
			showtablerow('', $arrs['width'], $arrs['data']);
		}

		echo '<input type="hidden" name="bid" value="' . $bid . '" ><input type="hidden" name="type" value="' . $type . '" ><input type="hidden" name="blockname" value="' . $_GET['blockname'] . '" >';
		echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "javascript:;" onclick = "wq_addrow(this, 0, 0,' . $type . ')" class = "addtr">' . $Plang['b7d63548f8406158'] . '</a></div></td></tr>';
		$multi = multi($count, $perpage, $page, $mpurl);
		showsubmit('adddatasubmit', 'submit', 'del', "", $multi);
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();

		$insertstatus = '<input name="insertstatus[\'+addrowkey+\']" value="1"  type="checkbox" checked="checked">';
		$insert = '';
		foreach($types_4[$type]['js'] as $js) {
			if(!empty($js)) {
				$insert .= wq_channel_set_form($js);
			}
		}

		echo <<<EOF
    <script type='text/JavaScript'>
        var addrowdirect = 0;
        var addrowkey = 0;
        function wq_addrow(obj, k,flag,type) {
            if(flag == 2){
                addrowkey--;
            }else{
                var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
                if(!addrowdirect) {
                        var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
                } else {
                        var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
                }

                var rowtypedata = [[[1,''],[1,'<input name = "insertdisplayorder[]" style="width:40px"  value="0" type = "number">'],[1,'<input name = "inserttitle[]"  value="" type = "text">'],[1,'<input name = "inserturl[]" style="width:330px"  value="" type = "text">'],{$insert}[1,'<div>{$insertstatus}&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this),wq_addrow(this, 0,2)">{$Plang['0d9efacf5089d88c']}</a></div>']],];

                var typedata = rowtypedata[k];
                for(var i = 0; i <= typedata.length - 1; i++) {
                        var cell = row.insertCell(i);
                        cell.colSpan = typedata[i][0];
                        var tmp = typedata[i][1];
                        if(typedata[i][2]) {
                                cell.className = typedata[i][2];
                        }
                        tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                        tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return wq_addrow.arguments[parseInt($2) + 1];});
                        cell.innerHTML = tmp;
                }
                addrowkey ++;
                addrowdirect = 0;
            }
        }
    </script>
EOF;
	} else {

		$n = $m = 0;
		if($_GET['did']) {
			$all = C::t("#wq_channel#wq_channel_block_data")->fetch_by_dids($_GET['did']);
			foreach($all as $key => $value) {
				$value['data'] = unserialize($value['data']);
				if($_GET['delete'][$value['did']] == $value['did']) {
					if(isset($value['data']['imgurl'])) {
						@unlink(($_G['setting']['attachurl'] ? $_G['setting']['attachurl'] . "wq_channel/" : 'data/attachment/wq_channel/') . $value['data']['imgurl']);
					}
					C::t("#wq_channel#wq_channel_block_data")->delete($value['did']);
				} else {
					if(empty($_GET['url'][$value['did']]) || empty($_GET['title'][$value['did']])) {
						$n ++;
						continue;
					}
					$durl = str_replace("&amp;", "&", dhtmlspecialchars($_GET['url'][$value['did']]));
					$res = wq_channel_preg_block_data_url($durl);

					$data = array(
						'data' => array(
							'title' => dhtmlspecialchars($_GET['title'][$value['did']]),
							'url' => $durl,
							'script' => $res['script'],
							"mod" => $res['mod'],
							"idtype" => $res['idtype'],
							'id' => $res['id'],
						),
						'bid' => $bid,
						'displayorder' => intval($_GET['displayorder'][$value['did']]),
						'status' => intval($_GET['status'][$value['did']]),
					);
					if(isset($_GET['icon'])) {
						if(empty($_GET['icon'][$value['did']])) {
							$n ++;
							continue;
						}
						$data['data']['icon'] = dhtmlspecialchars($_GET['icon'][$value['did']]);
					}
					if(isset($_GET['color'])) {
						$data['data']['color'] = dhtmlspecialchars($_GET['color'][$value['did']]);
					}
					if(isset($_GET['summary'])) {
						$data['data']['summary'] = dhtmlspecialchars($_GET['summary'][$value['did']]);
					}
					if(isset($_GET['backgroupcolor'])) {
						$data['data']['backgroupcolor'] = dhtmlspecialchars($_GET['backgroupcolor'][$value['did']]);
					}

					if(isset($_GET['imgurl'])) {
						$data['data']['imgurl'] = dhtmlspecialchars($_GET['imgurl'][$value['did']]);
						if(!empty($_FILES['upimg']['name'][$value['did']])) {
							$data['data']['imgurl'] = wq_channel_upload_img_data($_FILES['upimg'], $value['did']);
							if(!$data['data']['imgurl']) {
								$m ++;
								continue;
							}
							@unlink(($_G['setting']['attachurl'] ? $_G['setting']['attachurl'] . "wq_channel/" : 'data/attachment/wq_channel/') . $_GET['imgurl'][$value['did']]);
						}
					}

					$data['data'] = serialize($data['data']);

					C::t("#wq_channel#wq_channel_block_data")->update($value['did'], $data);
				}
			}
		}
		foreach($_GET['inserturl'] as $key => $val) {

			$val = str_replace("&amp;", "&", dhtmlspecialchars($val));
			$title = dhtmlspecialchars($_GET['inserttitle'][$key]);
			$displayorder = intval($_GET['insertdisplayorder'][$key]);
			if(empty($val) || empty($title)) {
				$m ++;
				continue;
			}
			$res = wq_channel_preg_block_data_url($val);

			$data = array(
				'data' => array(
					'title' => $title,
					'url' => $val,
					'script' => $res['script'],
					"mod" => $res['mod'],
					"idtype" => $res['idtype'],
					'id' => $res['id'],
				),
				'bid' => $bid,
				'displayorder' => $displayorder,
				'status' => intval($_GET['insertstatus'][$key]),
				'dateline' => TIMESTAMP,
			);

			if(isset($_GET['inserticon'])) {
				if(empty($_GET['inserticon'][$key])) {
					$m ++;
					continue;
				}
				$data['data']['icon'] = dhtmlspecialchars($_GET['inserticon'][$key]);
			}
			if(isset($_GET['insertsummary'])) {
				$data['data']['summary'] = dhtmlspecialchars($_GET['insertsummary'][$key]);
			}
			if(isset($_GET['insertcolor'])) {
				$data['data']['color'] = dhtmlspecialchars($_GET['insertcolor'][$key]);
			}
			if(isset($_GET['insertbackgroupcolor'])) {
				$data['data']['backgroupcolor'] = dhtmlspecialchars($_GET['insertbackgroupcolor'][$key]);
			}
			if($_FILES['insertupimg']['name']) {
				$data['data']['imgurl'] = wq_channel_upload_img_data($_FILES['insertupimg'], $key);
				if(!$data['data']['imgurl']) {
					$m ++;
					continue;
				}
			}

			$data['data'] = serialize($data['data']);
			C::t("#wq_channel#wq_channel_block_data")->insert($data);
		}

		if($n > 0 || $m > 0) {
			$msg = sprintf($Plang['b092c81b94e7931f'], $n, $m);
			cpmsg($msg, $dcpurl, 'error');
		} else {
			cpmsg($Plang['8ee460c51dbd9dee'], $dcpurl, 'succeed');
		}
	}
}

function wq_channel_delete_block_by_bid($bid) {
	$reuslts = C::t("#wq_channel#wq_channel_block_data")->fetch_by_bid($bid);

	foreach($reuslts as $key => $val) {
		$val['data'] = unserialize($val['data']);
		if(isset($val['data']['imgurl'])) {
			@unlink(($_G['setting']['attachurl'] ? $_G['setting']['attachurl'] . "wq_channel/" : 'data/attachment/wq_channel/') . $val['data']['imgurl']);
		}
	}
	DB::delete('wq_channel_block_data', array('bid' => $bid));

	C::t("#wq_channel#wq_channel_block")->delete($bid);
}

function wq_channel_by_type_show_data_title($titles) {
	global $Plang;
	$arr[] = "";
	$arr[] = $Plang['bd940fc8596f83d8'];
	$arr[] = $Plang['0b3d6ba0ad26e11e'];
	$arr[] = $Plang['b20bfb5c5308eb71'];
	foreach($titles as $title) {
		$arr[] = $title;
	}
	$arr[] = $Plang['04eb04651aeb0d87'];
	$arr[] = $Plang['7de4775a64db4b43'];
	echo showsubtitle($arr);
}

function wq_channel_by_type_show_data($val, $type) {
	$status = $val['status'] ? 'checked' : '';
	$arr = unserialize($val['data']);

	$attachurl = $_G['setting']['attachurl'] ? $_G['setting']['attachurl'] . "wq_channel/" : 'data/attachment/wq_channel/';

	$data[] = '<a name = "class_' . $val['did'] . '"><input class = "fs" type = "checkbox" name = "delete[' . $val['did'] . ']" value = "' . $val['did'] . '" /></a> ';
	$width[] = "width='60px'";

	$data[] = '<input style="width:40px;" type="number" name="displayorder[' . $val['did'] . ']" value="' . $val['displayorder'] . '" >';
	$width[] = "width='80px'";

	$data[] = '<input  type="text" name="title[' . $val['did'] . ']" value="' . $arr['title'] . '" >';
	$width[] = "width='200px'";

	$data[] = '<input style="width:330px" type="text" name="url[' . $val['did'] . ']" value="' . $arr['url'] . '" >';
	$width[] = "width='340px'";

	if(isset($arr['summary'])) {
		$data[] = '<textarea name="summary[' . $val['did'] . ']" cols="20" rows="3">' . $arr['summary'] . '</textarea>';
		$width[] = "width='200x'";
	}
	if(isset($arr['icon'])) {
		$data[] = wq_channel_icon_or_color_select("block_icon_" . $val['did'], "icon[" . $val['did'] . "]", $arr['icon'], 'icon');
		$width[] = "width='260x'";
	}
	if(isset($arr['color'])) {
		$data[] = wq_channel_icon_or_color_select("block_color_" . $val['did'], "color[" . $val['did'] . "]", $arr['color'], 'color');
		$width[] = "width='200px'";
	}
	if(isset($arr['backgroupcolor'])) {
		$data[] = wq_channel_icon_or_color_select("block_backgroup_color_" . $val['did'], "backgroupcolor[" . $val['did'] . "]", $arr['backgroupcolor'], 'color');
		$width[] = "width='200px'";
	}

	if(isset($arr['imgurl'])) {
		$imgurl = $attachurl . $arr['imgurl'];
		if(strpos($arr['imgurl'], 'source/plugin/wq_channel') !== false) {
			$imgurl = $arr['imgurl'];
		}
		switch($type) {
			case 6:
				$imgwidth = 'width:100px';
				break;
			default:
				$imgwidth = 'width:300px';
		}
		$data[] = '<img style="' . $imgwidth . '" src = "' . $imgurl . '"><input type="hidden" name="imgurl[' . $val['did'] . ']" value="' . $arr['imgurl'] . '" ><br><input name="upimg[' . $val['did'] . ']" style="border:none;background:none;width:200px;margin-left:5px;" type="file">';
		$width[] = "width='320px'";
	}

	$data[] = '<input class = "fs" type = "checkbox" name = "status[' . $val['did'] . ']" value = "1" ' . $status . ' />';
	$width[] = "width='80px'";

	$data[] = date("Y-m-d H:i:s", $val['dateline']) . '<input type="hidden" name="did[' . $val['did'] . ']" value="' . $val['did'] . '" >';
	$width[] = "width='150px'";

	$data[] = "";
	$width[] = "";

	return array('width' => $width, 'data' => $data);
}

function wq_channel_set_form($js) {
	$id = !empty($js['id']) ? $js['id'] : "";
	$name = !empty($js['name']) ? $js['name'] : "";
	$type = !empty($js['type']) ? $js['type'] : "";
	$style = !empty($js['style']) ? $js['style'] : "";
	$selects = is_array($js['selects']) ? (!empty($js['selects']) ? $js['selects'] : array()) : array($js['selects']);
	$placeholder = !empty($js['placeholder']) ? $js['placeholder'] : "";
	$rows = !empty($js['rows']) ? intval($js['rows']) : 3;
	$cols = !empty($js['cols']) ? intval($js['cols']) : 15;

	$html = "[1,'";
	if($type == 'color') {
		$html .= wq_channel_icon_or_color_select($id, $name, '', 'color', true);
	} elseif($type == 'icon') {
		$html .= wq_channel_icon_or_color_select($js['id'], $js['name'], '', 'icon', true);
	} elseif($type == 'select') {
		$html .= select_html($selects, $name . '[\'+addrowkey+\']', "", false, false);
	} elseif($type == "textarea") {
		$html .= '<textarea name="' . $name . '[]" cols="' . $cols . '" rows="' . $rows . '" placeholder="' . $placeholder . '"></textarea>';
	} else {
		$html .= '<input ' . $style . ' name = "' . $name . '[]" class="user" type="' . $type . '" placeholder="' . $placeholder . '">';
	}
	$html .= "'],";

	return $html;
}

function wq_channel_upload_img_data($insertupimg, $key) {
	if(empty($insertupimg['name'][$key])) {
		return false;
	}
	$insertupimg = array(
		'name' => $insertupimg['name'][$key],
		'type' => $insertupimg['type'][$key],
		'tmp_name' => $insertupimg['tmp_name'][$key],
		'error' => $insertupimg['error'][$key],
		'size' => $insertupimg['size'][$key],
	);
	$img = wq_channel_upload_images($insertupimg);
	if(!$img) {
		return false;
	}

	return $img;
}
//From: Dism_taobao-com
?>