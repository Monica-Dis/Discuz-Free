<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_channel.inc.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_channel_get_Tlang() {

	include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/loadfunc.php';
	$langfile = DISCUZ_ROOT . './source/plugin/wq_channel/language/language.' . currentlang() . '.php';

	if(is_file($langfile)) {
		$includefile = $langfile;
	} else {
		$includefile = libfile('language', 'plugin/wq_channel/language');
	}
	include $includefile;
	global $Tlang;

	return $Tlang;
}

function wq_channel_get_style() {

	$Tlang = wq_channel_get_Tlang();

	return $styles = array(
		array(
			'blockclass' => array("wqchannel_channelimgbut"),
			'name' => $Tlang["channel_img_button"],
			'template' => '<div class="wq_menu_warp <!--{sildeclass}-->" data-type="imgButton">
            <ul>
                [loop]
                <li class="{wqclass}"><a href="{url}" {target}><img src="{pic}"></a></li>
                [/loop]
            </ul>
        </div>
        <!--{silde}-->',
		),
		array(
			'blockclass' => array("wqchannel_channelimgbut"),
			'name' => $Tlang["channel_img_button_font"],
			'template' => '<div class="wq_icon_warp  <!--{sildeclass}-->" data-type="imgButtonFont">
            <ul>
                [loop]
                <li class="{wqclass}"><a href="{url}" {target}><img src="{pic}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
        <!--{silde}-->',
		),
		array(
			'blockclass' => array("wqchannel_channelbutton"),
			'name' => $Tlang["channel_button_icon_background"],
			'template' => '<div class="wqplate_warp <!--{sildeclass}-->" data-type="BackGroundMod">
            <ul>
                [loop]
                <li class="{wqclass}"><a href="{url}" {target}><div class="wqplate_rem_color" style=" background:{backgroupcolor};"><i class="{icon}"></i></div><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
      <!--{silde}-->',
		),
		array(
			'blockclass' => array("wqchannel_channelbutton"),
			'name' => $Tlang["channel_button_icon_not_background"],
			'template' => '<div class="wqplate_warp  <!--{sildeclass}-->" data-type="notBackGroundMod">
            <ul>
                [loop]
                <li class="{wqclass}"><a href="{url}" {target}><div class="wqplate_rem_color wqno_bgcolor" style="color: {color};"><i class="{icon}"></i></div><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
       <!--{silde}-->',
		),
		array(
			'blockclass' => array("wqchannel_channellink"),
			'name' => $Tlang["channel_link_title"],
			'template' => '<div class="wqchannel_menu_single_row  <!--{sildeclass}-->" data-type="linkMod">
            <ul>
                [loop]
                <li class="{wqclass}"><a href="{url}" {target}>{title}</a></li>
                [/loop]
            </ul>
        </div>
       <!--{silde}-->',
		),
		array(
			'blockclass' => array("wqchannel_channelad"),
			'name' => $Tlang["channel_ad_img"],
			'template' => '<div class="wqpicture_ad" data-type="adImg">
            <ul>
                [loop]
                <li class="{wqclass}">
                    <a href="{url}" {target}>
                        <div>
                           <p><img src="{pic}" alt="{title}"></p>
                        </div>
                    </a>
                    <span class="wqchannel_line"></span>
                </li>
                [/loop]
             </ul>
      </div>',
		),
		array(
			'blockclass' => array("wqchannel_channeladwrit"),
			'name' => $Tlang["channel_ad_title_img"],
			'template' => '<div class="wq_extension_ad"  data-type="adTitleImg">
            [loop]
            <a href="{url}" {target}>
                <h3><span class="wqname">' . $Tlang["channel_ad"] . '</span>{title}</h3>
                <p ><img src="{pic}" alt="{title}" ></p>
            </a>
           [/loop]
       </div>',
		),
		array(
			'blockclass' => array("wqchannel_channelclass"),
			'name' => $Tlang["channel_icon_right_title_summary"],
			'template' => '<div class="wqsection_synopsis"  data-type="iconTitleSumR">
           <ul>
               [loop]
               <li>
                    <a href="{url}" {target}>
                        <div class="wqplate_rem_color wqplate_rem_left" style=" background: {backgroupcolor};"><i class="{icon} wqimg"></i></div>
                        <h3 style="color:{color}">{title}</h3>
                        <span class="wqsynopsis">{summary}</span>
                    </a>
               </li>
               [/loop]
           </ul>
       </div>',
		),
		array(
			'blockclass' => array("wqchannel_channelclass"),
			'name' => $Tlang["channel_icon_left_title_summary"],
			'template' => '<div class="wqsection_synopsis" data-type="iconTitleSumL">
           <ul>
               [loop]
               <li>
                   <a href="{url}" {target}>
                        <div class="wqplate_rem_color" style=" background: {backgroupcolor};"><i class="{icon} wqimg"></i></div>
                        <h3 style="color:{color}">{title}</h3>
                        <span class="wqsynopsis">{summary}</span>
                    </a>
               </li>
               [/loop]
           </ul>
       </div>',
		),
		array(
			'blockclass' => array("wqchannel_channelclass"),
			'name' => $Tlang["channel_title_summary"],
			'template' => '<div class="wqspecial_link" data-type="titleSum">
                <ul>
                    [loop]
                    <li>
                        <a href="{url}" {target}>
                            <h3 style="color: {color}">{title}</h3>
                            <p>{summary}</p>
                        </a>
                    </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_right"],
			'template' => '<div class="wq_limp_g" data-type="swipeImg-2_2">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                    <div class="wqtopimage wq-lazyload-container">
                        <a href="{url}" {target}>
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </a>
                    </div>
                    [/loop]
                </div>
                <ul class="wqscroll_icon2"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_center"],
			'template' => '<div class="wq_limp_g" data-type="swipeImg-1">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                    <div class="wqtopimage wq-lazyload-container">
                        <a href="{url}" {target}>
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </a>
                    </div>
                    [/loop]
                </div>
                  <ul class="wqscroll_icon1"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_ellipse_right"],
			'template' => '<div class = "wq_limp_g" data-type="swipeImg-6_6">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                        <div class="wqtopimage wq-lazyload-container" >
                            <a href="{url}" {target}>
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </a>
                         </div>
                     [/loop]
                </div>
                <ul class="wqscroll_icon6"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_ellipse_center"],
			'template' => '<div class = "wq_limp_g" data-type="swipeImg-5">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                        <div class="wqtopimage wq-lazyload-container" >
                            <a href="{url}" {target}>
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </a>
                         </div>
                     [/loop]
                </div>
                <ul class="wqscroll_icon5"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_number"],
			'template' => '<div class = "wq_limp_g" data-type="swipeImg-3">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                        <div class="wqtopimage wq-lazyload-container" >
                            <a href="{url}" {target}>
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                               <p class="wqscroll_title"><span>{title}</span></p>
                            </a>
                         </div>
                     [/loop]
                </div>
                <ul class="wqscroll_icon3"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_title_left"],
			'template' => '<div class = "wq_limp_g" data-type="swipeImg-2">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                        <div class="wqtopimage wq-lazyload-container">
                            <a href="{url}" {target}>
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                               <p class="wqscroll_title"><span>{title}</span></p>
                            </a>
                         </div>
                     [/loop]
                </div>
                <ul class="wqscroll_icon2"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread", "wqchannel_channelslide"),
			'name' => $Tlang["channel_swipe_title_ellipse_right"],
			'template' => '<div class = "wq_limp_g" data-type="swipeImg-6">
            <div class="wqtopscroll_lb" style="visibility: visible;">
                <div class="wqscroll_lump">
                    [loop]
                        <div class="wqtopimage wq-lazyload-container" >
                            <a href="{url}" {target}>
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                               <p class="wqscroll_title"><span>{title}</span></p>
                            </a>
                         </div>
                     [/loop]
                </div>
                <ul class="wqscroll_icon6"></ul>
            </div>
        </div>
        <script>
           imgSlide();
        </script>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_three"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImgThree">
            <ul>
                [loop]
                    <li class="wqplate_three"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_four"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImg">
            <ul>
                [loop]
                    <li><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_five"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImgFive">
            <ul>
                [loop]
                    <li  class="wqplate_five"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_three_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgThreeMore">
            <ul>
                [loop]
                    <li class="wqplate_three"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
         <script>itemSlide(2,3, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_four_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgMore">
            <ul>
                [loop]
                    <li><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
         <script>itemSlide(2,4, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_five_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgFiveMore">
            <ul>
                [loop]
                    <li class="wqplate_five"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
            </ul>
        </div>
        <script>itemSlide(2,5, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_three_all"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImgThreeAll">
            <ul>
                [loop]
                    <li class="wqplate_three"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li class="wqplate_three"><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_four_all"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImgAll">
            <ul>
                [loop]
                    <li><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_five_all"],
			'template' => '<div class="wqplate_rem"  data-type="modtitleImgFiveAll">
            <ul>
                [loop]
                    <li class="wqplate_five"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li class="wqplate_five"><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_three_all_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgThreeAllMore">
            <ul>
                [loop]
                    <li class="wqplate_three"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li class="wqplate_three"><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>
         <script>itemSlide(2,3, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_four_all_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgAllMore">
            <ul>
                [loop]
                    <li><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>
         <script>itemSlide(2,4, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_five_all_more"],
			'template' => '<div class="wqplate_rem !wqforum_more!"  data-type="modtitleImgFiveAllMore">
            <ul>
                [loop]
                    <li class="wqplate_five"><a href="{url}" title="{title}" {target}><img src="{icon}"><p>{title}</p></a></li>
                [/loop]
                    <li class="wqplate_five"><a href="forum.php?forumlist=1" title="' . $Tlang["channel_forum"] . '" target="_blank"><img src="./source/plugin/wq_channel/static/images/wq_allsection.png"><p>' . $Tlang["channel_forum"] . '</p></a></li>
            </ul>
        </div>
        <script>itemSlide(2,5, \'.!wqforum_more!\');</script>
        ',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_left"],
			'template' => '<div class="wqsection_synopsis" data-type="modImgSumL">
           <ul>
                [loop]
                <li>
                   <a href="{url}" {target}>
                        <div class="wqplate_rem_color"><img src="{icon}"></div>
                        <h3>{title}</h3>
                        <span class="wqsynopsis">{summary}</span>
                    </a>
                </li>
                [/loop]
           </ul>
       </div>',
		),
		array(
			'blockclass' => array("forum_forum", "group_group"),
			'name' => $Tlang["channel_forum_right"],
			'template' => '<div class="wqsection_synopsis"  data-type="modImgSumR">
           <ul>
               [loop]
               <li>
                    <a href="{url}" {target}>
                        <div class="wqplate_rem_color wqplate_rem_left" ><img src="{icon}"></div>
                        <h3>{title}</h3>
                        <span class="wqsynopsis">{summary}</span>
                    </a>
               </li>
               [/loop]
           </ul>
       </div>',
		),
		array(
			'blockclass' => array("forum_thread"),
			'name' => $Tlang["channel_title_forum1"],
			'template' => '<div class="wqplate_list" data-type="titleForum">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name1">[{forumname}]</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_forum1"],
			'template' => '<div class="wqplate_list" data-type="titleForum">
            <ul>
                [loop]
                    <li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name1">{catname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread"),
			'name' => $Tlang["channel_title_forum1"],
			'template' => '<div class="wqplate_list" data-type="titleForum">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name1">[{groupname}]</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_thread"),
			'name' => $Tlang["channel_title_forum2"],
			'template' => '<div class="wqplate_list" data-type="titleForum2">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name2">[{forumname}]</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_forum2"],
			'template' => '<div class="wqplate_list" data-type="titleForum2">
            <ul>
                [loop]
                    <li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name2">{catname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread"),
			'name' => $Tlang["channel_title_forum2"],
			'template' => '<div class="wqplate_list" data-type="titleForum2">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name2">{groupname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_thread"),
			'name' => $Tlang["channel_title_forum3"],
			'template' => '<div class="wqplate_list" data-type="titleForum3">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name3">{forumname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_forum3"],
			'template' => '<div class="wqplate_list" data-type="titleForum3">
            <ul>
                [loop]
                    <li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name3">[{catname}]</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread"),
			'name' => $Tlang["channel_title_forum3"],
			'template' => '<div class="wqplate_list" data-type="titleForum3">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name3">{groupname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("forum_thread"),
			'name' => $Tlang["channel_title_forum4"],
			'template' => '<div class="wqplate_list" data-type="titleForum4">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name4">{forumname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_forum4"],
			'template' => '<div class="wqplate_list" data-type="titleForum4">
            <ul>
                [loop]
                    <li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name4">[{catname}]</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread"),
			'name' => $Tlang["channel_title_forum4"],
			'template' => '<div class="wqplate_list" data-type="titleForum4">
            <ul>
                [loop]
			<li><a href="{url}" class="wqellipsis" {target}><span class="wqplate_name4">{groupname}</span>{title}</a></li>
		[/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_rank_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking1">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_rank_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking1">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread",),
			'name' => $Tlang["channel_rank_square_title_date"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking2">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_rank_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking3">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_rank_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking3">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread",),
			'name' => $Tlang["channel_rank_circle_title_date"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking4">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_color1">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_color2">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_color3">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_rank_i_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking5">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_rank_i_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking5">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread",),
			'name' => $Tlang["channel_rank_i_square_title_date"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking6">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_rank_i_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking8">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqround wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_rank_i_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking8">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqround wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread",),
			'name' => $Tlang["channel_rank_i_circle_title_date"],
			'template' => '<div class="wqchanneltitle_author"  data-type="ranking7">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_italic wq_italiccolor">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqround wq_italic wq_italiccolor_all">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_rank_i_not_backgroup_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking9">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqnum wqnum_f15 wq_italic wq_ccolorgrey">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_rank_i_not_backgroup_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking9">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqnum wqnum_f15 wq_italic wq_ccolorgrey">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
       </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread",),
			'name' => $Tlang["channel_rank_i_not_backgroup_title_date"],
			'template' => '<div class="wqchanneltitle_author" data-type="ranking10">
            <ul>
                [index=1]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=2]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [index=3]
                   <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqnum_f15 wq_italic">{currentorder}</i>{title}</a></li>
                [/index]
                [loop]
                    <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqnum wqnum_f15 wq_italic wq_ccolorgrey">{currentorder}</i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_img"],
			'template' => '<div class="wqgateway_img" data-type="Img">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_img_silde"],
			'template' => '<div class="wqgateway_img wqgateway_scroll" data-type="ImgS">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <script>$(".wqgateway_scroll").scrollnav(2);</script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_img_more"],
			'template' => '<div class="wqgateway_img" data-type="ImgMore">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_img_down"],
			'template' => '<div class="wqgateway_img load-scroll" data-type="ImgDown" data-ac="!type!" data-op="">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img"],
			'template' => '<div class="wqgateway_img" data-type="titleImg">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                            <div class="wq_img wq-lazyload-container">
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                            </div>
                            <span class="wqellipsis">{title}</span>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_silde"],
			'template' => '<div class="wqgateway_img wqgateway_scroll" data-type="titleImgS">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                            <div class="wq_img wq-lazyload-container">
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                            </div>
                            <span class="wqellipsis">{title}</span>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <script>$(".wqgateway_scroll").scrollnav(2);</script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_more"],
			'template' => '<div class="wqgateway_img" data-type="titleImgMore">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                            <div class="wq_img wq-lazyload-container">
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                            </div>
                            <span class="wqellipsis">{title}</span>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_down"],
			'template' => '<div class="wqgateway_img load-scroll" data-type="titleImgDown" data-ac="!type!" data-op="">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                            <div class="wq_img wq-lazyload-container">
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                            </div>
                            <span class="wqellipsis">{title}</span>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_out"],
			'template' => '<div class="wqgateway_img" data-type="titleImgOut">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        <p class="wqellipsis">{title}</p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_out_silde"],
			'template' => '<div class="wqgateway_img wqgateway_scroll" data-type="titleImgOutS">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        <p class="wqellipsis">{title}</p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <script>$(".wqgateway_scroll").scrollnav(2);</script>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_out_more"],
			'template' => '<div class="wqgateway_img" data-type="titleImgOutMore">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        <p class="wqellipsis">{title}</p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_img_out_down"],
			'template' => '<div class="wqgateway_img load-scroll" data-type="titleImgOutDown" data-ac="!type!" data-op="">
            <ul>
                [loop]
                    <li>
                        <a href="{url}" {target}>
                        <div class="wq_img wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}" alt="{title}" >
                        </div>
                        <p class="wqellipsis">{title}</p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_more"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_more"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1 wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2 wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_hidden50">
                                <h3 class="wqtitle_list">{title}</h3>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgMsgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgMsgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgMsgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_reply_summary_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgMsgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_reply_summary_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgMsgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                               <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgL">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                               <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgLMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateMsgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                               <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateMsgLDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist1_con wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary_r"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgR">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary_r_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateMsgRMore">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_author_date_summary_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateMsgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{author}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{replies}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_author_date_summary_r_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateMsgRDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                    <li>
                        <a href="{url}"class="wqblock" {target}>
                            <div class="wqlist2_con wq_listright wq-lazyload-container" >
                                <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                            </div>
                            <div class="wqlist_height70">
                                <h3 class="wqtitle_list">{title}</h3>
                                <div class="wqtitle_con">{summary}</div>
                            </div>
                            <p class="list_info"><span class="width70">{username}</span>
                                <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f12"></i>{commentnum}</span>
                                <span class="y wqm_right10 width80">{dateline}</span>
                            </p>
                        </a>
                    </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date_more"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date_more"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleImgDateViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleImgDateViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date_summary"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date_summary"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleImgDateViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_img_reply_view_date_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleImgDateViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_img_reply_view_date_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleImgDateViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}">
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}">
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date_more"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}">
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date_more"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}" {target}>
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date_down"],
			'template' => ' <div class="wqindex_list load-scroll" data-type="titleAuImgDateViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}">
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date_down"],
			'template' => ' <div class="wqindex_list load-scroll" data-type="titleAuImgDateViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}" {target}>
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}" {target}>
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}">
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary_more"],
			'template' => ' <div class="wqindex_list" data-type="titleAuImgDateViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}">
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuImgDateViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}" {target}>
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary_down"],
			'template' => ' <div class="wqindex_list load-scroll" data-type="titleAuImgDateViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={authorid}">
                            <img src="{avatar}" >
                            <font class="width100">{author}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_title_author_img_reply_view_date_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuImgDateViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <div class="wquser_pane">
                        <a href="home.php?mod=space&uid={uid}" {target}>
                            <img src="{avatar}" >
                            <font class="width100">{username}</font>
                        </a>
                    </div>
                    <a href="{url}"class="wqblock" {target}>
                        <div class="max_wqlisthidden">
                            <h3 class="wqtitle_list">{title}</h3>
                             <div class="wqcon">{summary}</div>
                        </div>
                        <div class="wqlist_pane1 wq-lazyload-container">
                            <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload" width="{picwidth}" height="{picheight}">
                        </div>
                        <p class="list_info wqm_top10">
                            {dateline}
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title"],
			'template' => ' <div class="wqgateway" data-type="title">
            [index=1]
                <h3 class="wq_f18"><a href="{url}" {target} class="wqellipsis wqcolor">{title}</a></h3>
            [/index]
            [loop]
                <p><a href="{url}" {target} class="wqellipsis">{title}</a></p>
            [/loop]
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "portal_article", "forum_thread"),
			'name' => $Tlang["channel_title_more"],
			'template' => '<div class="wqmulti_roll" data-type="titleMore">
            <div class="wqtit-roll-loop">
                <ul id="!wqreplaceloop!">
                    [loop]
                    <li><a href="{url}" {target}>{title}</a></li>
                    [/loop]
                </ul>
            </div>
       </div>
       <script>loop(30, 500, 2000, "#!wqreplaceloop!");</script>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_reply"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDate">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_reply"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDate">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_reply_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_reply_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_reply_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViDateDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_reply_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViDateDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRep">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
         <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViRepDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden50">
                            <h3 class="wqtitle_list">{title}</h3>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_view_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_view_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_view_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_view_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViDateMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_date_view_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViDateMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_date_view_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViDateMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10 width80">{dateline}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view_summary"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMsg">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view_summary_more"],
			'template' => '<div class="wqindex_list" data-type="titleAuViRepMsgMore">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread",),
			'name' => $Tlang["channel_title_author_reply_view_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{author}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{replies}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{views}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["channel_title_author_reply_view_summary_down"],
			'template' => '<div class="wqindex_list load-scroll" data-type="titleAuViRepMsgDown" data-ac="!type!" data-op="">
            <ul class="wqindex_list_ul">
                [loop]
                <li>
                    <a href="{url}" {target} class="wqblock">
                        <div class="wqlist_maxhidden70">
                            <h3 class="wqtitle_list">{title}</h3>
                            <div class="wqtitle_con">{summary}</div>
                        </div>
                        <p class="list_info"><span class="width70">{username}</span>
                            <span class="y"><i class="wqchannel wqchannel-tubiao05 wq_f14"></i>{commentnum}</span>
                            <span class="y wqm_right10"><i class="wqchannel wqchannel-yulan wqyulan"></i>{viewnum}</span>
                        </p>
                    </a>
                </li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu1">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqdian"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_circle_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu1">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqdian"></i>{title}</a></li>
                [/loop]
            </ul>
        </div> ',
		),
		array(
			'blockclass' => array("portal_article", "group_thread", "forum_thread"),
			'name' => $Tlang["channel_circle_title_date"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleDate1">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqdian"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu2">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqsquare"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_square_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu2">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqsquare"></i>{title}</a></li>
                [/loop]
            </ul>
        </div> ',
		),
		array(
			'blockclass' => array("portal_article", "group_thread", "forum_thread"),
			'name' => $Tlang["channel_square_title_date"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleDate2">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqsquare"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>  ',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["channel_arrow_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu3">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{author}</span><i class="wqchannel_arrow"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>',
		),
		array(
			'blockclass' => array("portal_article",),
			'name' => $Tlang["channel_arrow_title_author"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleAu3">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqname">{username}</span><i class="wqchannel_arrow"></i>{title}</a></li>
                [/loop]
            </ul>
        </div> ',
		),
		array(
			'blockclass' => array("portal_article", "group_thread", "forum_thread"),
			'name' => $Tlang["channel_arrow_circle_title_date"],
			'template' => '<div class="wqchanneltitle_author" data-type="titleDate3">
            <ul>
                [loop]
                <li><a href="{url}" {target}><span class="wqtime">{dateline}</span><i class="wqchannel_arrow"></i>{title}</a></li>
                [/loop]
            </ul>
        </div>  ',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["waterfall"],
			'template' => '<div class="wqwaterfall_warp"  data-type="waterfall">
            <div class="wqwaterfall_con pulldown_load_js">
                <ul class="waterfall wqwaterfall masonry">
                    [loop]
                     <li>
                        <div class="two_box">
                            <a href="{url}" {target}>
                                <img src="{pic}">
                                <h3 class="xw0 wqwaterfall_title">
                                   {title}
                                </h3>
                                <div class="wqwaterfall_info">
                                    <span class="width80">
                                        {author}
                                    </span>
                                    <span class="y">
                                        <i class="wqchannel wqchannel-tubiao05"></i>{replies}</span>
                                </div>
                            </a>
                        </div>
                    </li>
                    [/loop]
                </ul>
            </div>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\',\'waterfall\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p> ',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["waterfall"],
			'template' => '<div class="wqwaterfall_warp" data-type="waterfall">
            <div class="wqwaterfall_con pulldown_load_js">
                <ul class="waterfall wqwaterfall masonry">
                    [loop]
                     <li>
                        <div class="two_box">
                            <a href="{url}" {target}>
                                <img src="{pic}">
                                <h3 class="xw0 wqwaterfall_title">
                                   {title}
                                </h3>
                                <div class="wqwaterfall_info">
                                    <span class="width80">
                                        {username}
                                    </span>
                                    <span class="y">
                                        <i class="wqchannel wqchannel-tubiao05"></i>{commentnum}</span>
                                </div>
                            </a>
                        </div>
                    </li>
                    [/loop]
                </ul>
            </div>
        </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\',\'waterfall\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p> ',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["waterfalldown"],
			'template' => '<div class="wqwaterfall_warp load-scroll" data-type="waterfallDown" data-ac="!type!" data-op="waterfall">
            <div class="wqwaterfall_con pulldown_load_js">
                <ul class="waterfall wqwaterfall masonry">
                    [loop]
                     <li>
                        <div class="two_box">
                            <a href="{url}" {target}>
                                <img src="{pic}">
                                <h3 class="xw0 wqwaterfall_title">
                                   {title}
                                </h3>
                                <div class="wqwaterfall_info">
                                    <span class="width80">
                                        {author}
                                    </span>
                                    <span class="y">
                                        <i class="wqchannel wqchannel-tubiao05"></i>{replies}</span>
                                </div>
                            </a>
                        </div>
                    </li>
                    [/loop]
                </ul>
            </div>
        </div>',
		),
		array(
			'blockclass' => array("portal_article"),
			'name' => $Tlang["waterfalldown"],
			'template' => '<div class="wqwaterfall_warp load-scroll" data-type="waterfallDown" data-ac="!type!" data-op="waterfall">
            <div class="wqwaterfall_con pulldown_load_js">
                <ul class="waterfall wqwaterfall masonry">
                    [loop]
                     <li>
                        <div class="two_box">
                            <a href="{url}" {target}>
                                <img src="{pic}">
                                <h3 class="xw0 wqwaterfall_title">
                                   {title}
                                </h3>
                                <div class="wqwaterfall_info">
                                    <span class="width80">
                                        {username}
                                    </span>
                                    <span class="y">
                                        <i class="wqchannel wqchannel-tubiao05"></i>{commentnum}</span>
                                </div>
                            </a>
                        </div>
                    </li>
                    [/loop]
                </ul>
            </div>
        </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["mart_by_mixed"],
			'template' => '<div class="wqnew_list_warp" data-type="martByMixed" data-ac="!type!">
                <ul class="wqnew_list_ul">
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["mart_by_mixed_more"],
			'template' => '<div class="wqnew_list_warp" data-type="martByMixedMore" data-ac="!type!">
                <ul class="wqnew_list_ul">
                </ul>
            </div>
        <p class = "wqchannel_more"><a href="javascript:;" class = "wqblock" onclick="_ajax_post(this,\'!type!\',\'mixed\')">' . $Tlang["load_more"] . '<i class="wqchannel wqchannel-jiantou_down-copy"></i></a></p>',
		),
		array(
			'blockclass' => array("group_thread", "forum_thread"),
			'name' => $Tlang["mart_by_mixed_down"],
			'template' => '<div class="wqnew_list_warp load-scroll" data-type="martByMixedDown" data-ac="!type!" data-op="mixed">
                <ul class="wqnew_list_ul">
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_avatar_silde"],
			'template' => '<div class="wqchannel_vipdaghead <!--{sildeclass}-->" data-type="avatarSilde">
                <ul>
                    [loop]
                        <li><a href="{url}" itle="{title}" {target}><img src="{avatar}"></a></li>
                    [/loop]
                </ul>
            </div>
            <!--{silde}-->',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_avatar_user_silde"],
			'template' => '<div class="wqchannel_vipdaghead wqchannel_height70 <!--{sildeclass}-->" data-type="avatarUserSilde">
                    <ul>
                    [loop]
                        <li><a href="{url}" itle="{title}" {target}><img src="{avatar}"><br/>{title}</a></li>
                    [/loop]
                    </ul>
            </div>
            <!--{silde}-->',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num" data-type="avatarUserCredits">
                <ul>
                [loop]
                    <li>
                        <a href="{url}" title="{title}" {target}><img src="{avatar}">
                            <span class="wqchannel_name">{title}</span>
                            <span class="wqchannel_num">
                                <i class="wqchannel wqchannel-jifen"></i>{credits}
                            </span>
                        </a>
                    </li>
                [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num" data-type="avatarUserPosts">
                <ul>
                [loop]
                    <li>
                        <a href="{url}" title="{title}" {target}><img src="{avatar}">
                            <span class="wqchannel_name">{title}</span>
                            <span class="wqchannel_num">
                                <i class="wqchannel wqchannel-wodetiezi"></i>{posts}
                            </span>
                        </a>
                    </li>
                [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_square_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser1">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color1">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_circle_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser2">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color1 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_square_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser3">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_circle_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser4">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_not_backgroup_avatar_user_credits"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser5">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_grey wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-jifen"></i>{credits}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_square_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser6">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color1">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_circle_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser7">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color1 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_color3 wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_square_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser8">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_circle_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser9">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round wq_italiccolor">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wq_italic wqchannel_round">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("member_member"),
			'name' => $Tlang["channel_rank_i_not_backgroup_avatar_user_posts"],
			'template' => '<div class="wqchannel_viphead_name_num"  data-type="rankUser10">
                <ul>
                    [index=1]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=2]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [index=3]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_red wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                    [/index]
                    [loop]
                        <li><a href="{url}" {target}><span class="wqchannel_ranking wqnum_f15 wqno_bgcolor_grey wq_italic">{currentorder}</span><img src="{avatar}"><span class="wqchannel_name">{title}</span><span class="wqchannel_num"><i class="wqchannel wqchannel-wodetiezi"></i>{posts}</span></a></li>
                     [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqvideo_video"),
			'name' => $Tlang["channel_video_small"],
			'template' => '<div class="wq_video_warp_two" data-type="videoSmall">
                <ul>
                    [loop]
                        <li>
                            <a href="{url}" {target}>
                                <div class="wq_img wq-lazyload-container">
                                    <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload">
                                    <span class="wq_time">{timestr}</span>
                                </div>
                                <div class="wq_con">{title}</div>
                            </a>
                        </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqvideo_video"),
			'name' => $Tlang["channel_video_big"],
			'template' => '<div class="wq_video_warp_three" data-type="videoBig">
                <ul>
                    [loop]
                        <li>
                            <a href="{url}" {target}>
                                <div class="wq_img_warp">
                                    <div class="wq_img  wq-lazyload-container">
                                        <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload">
                                    </div>
                                    <div class="wqvideo_mask">
                                        <div class="wq_play"><i class="wqchannel wqchannel-jiantou2"></i></div>
                                        <div class="wq_title">{title}</div>
                                        <div class="wq_detail">
                                            <span class="wq_name">{author}</span>
                                            <span class="wq_time">{timestr}</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqvideo_video"),
			'name' => $Tlang["channel_video_big_two"],
			'template' => ' <div data-type="videoBig2">
                [loop]
                    <div class="wq_video_warp" data-type="videoBig2">
                        <div class="wq_img_warp">
                            <a href="{url}" {target}>
                                <div class="wq_img">
                                    <img src="./source/plugin/wq_channel/static/images/wq_dian.jpg" data-src="{pic}" class="wq-lazyload">
                                </div>
                                <p class="wqvideo_title">{title}</p>
                                <span class="wq_video_play"><i class="wqchannel wqchannel-bofang"></i></span>
                                <span class="wq_video_time">{timestr}</span>
                            </a>
                            </div>
                            <div class="wq_video_name">
                                <span class="wq_video_name_info">{views}' . $Plang['87526d329e4f1e5d'] . '</span>
                                <span class="wq_video_info">
                                      <i class="wqchannel wqchannel-zan1" ></i><span>{likes}</span>
                                </span>
                            </div>
                            <p class="wq_video_line"></p>
                        </div>
                [/loop]
            </div>',
		),
		array(
			'blockclass' => array("wqchannel_video"),
			'name' => $Tlang["channel_video_mobile_one"],
			'template' => ' <div data-type="videoPc1">
                [loop]
					<div class="{wqclass}">
						<video src="{url}"  width="{picwidth}" height="{picheight}"controls="controls" playsinline></video>
					</div>
					<style>
						.wqvideo video{ width:100%;}
					</style>
					<script src="./source/plugin/wq_channel/static/js/html5media.min.js"></script>
				[/loop]
            </div>',
		),
		array(
			'blockclass' => array("wqchannel_video"),
			'name' => $Tlang["channel_video_pc_one"],
			'template' => ' <div data-type="videoMobile1">
                [loop]
					<div class="{wqclass}" data-type="video-sub">
						<video src="{url}"  width="{picwidth}" height="{picheight}"controls="controls" playsinline></video>
					</div>
				[/loop]
            </div>',
		),
	);
}
//From: Dism_taobao-com
?>