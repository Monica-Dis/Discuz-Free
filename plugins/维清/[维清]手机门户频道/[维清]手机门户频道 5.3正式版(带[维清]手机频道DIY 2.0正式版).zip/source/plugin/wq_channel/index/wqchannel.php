<?php

$wqdomain = array();
@include_once './data/sysdata/cache_wqchannel.php';
if(!is_numeric($_SERVER['QUERY_STRING'])) {

	$mobile = wq_checkmobile();
	if($mobile) {
		$curl = '';
		if(!empty($wqdomain['defaultmobileindex'])) {
			$curl = $wqdomain['defaultmobileindex'];
		}

		if(!empty($curl)) {
			header("HTTP/1.1 301 Moved Permanently");
			header("location: $curl");
			exit();
		}
	}
}

function wq_checkmobile() {
	$touchbrowser_list = array('iphone', 'android', 'phone', 'mobile', 'wap', 'netfront', 'java', 'opera mobi', 'opera mini',
		'ucweb', 'windows ce', 'symbian', 'series', 'webos', 'sony', 'blackberry', 'dopod', 'nokia', 'samsung',
		'palmsource', 'xda', 'pieplus', 'meizu', 'midp', 'cldc', 'motorola', 'foma', 'docomo', 'up.browser',
		'up.link', 'blazer', 'helio', 'hosin', 'huawei', 'novarra', 'coolpad', 'webos', 'techfaith', 'palmsource',
		'alcatel', 'amoi', 'ktouch', 'nexian', 'ericsson', 'philips', 'sagem', 'wellcom', 'bunjalloo', 'maui', 'smartphone',
		'iemobile', 'spice', 'bird', 'zte-', 'longcos', 'pantech', 'gionee', 'portalmmm', 'jig browser', 'hiptop',
		'benq', 'haier', '^lct', '320x320', '240x320', '176x220', 'windows phone');

	$wmlbrowser_list = array('cect', 'compal', 'ctl', 'lg', 'nec', 'tcl', 'alcatel', 'ericsson', 'bird', 'daxian', 'dbtel', 'eastcom',
		'pantech', 'dopod', 'philips', 'haier', 'konka', 'kejian', 'lenovo', 'benq', 'mot', 'soutec', 'nokia', 'sagem', 'sgh',
		'sed', 'capitel', 'panasonic', 'sonyericsson', 'sharp', 'amoi', 'panda', 'zte');

	$pad_list = array('ipad');

	$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);

	if(wqstrpos($useragent, $pad_list)) {
		return false;
	}

	if(($v = wqstrpos($useragent, $touchbrowser_list, true)) || ($v = wqstrpos($useragent, $wmlbrowser_list))) {
		$mobile = $v;
		return $mobile;
	}

	return false;
}

function wqstrpos($string, $arr, $returnvalue = false) {
	if(empty($string))
		return false;
	foreach((array) $arr as $v) {
		if(strpos($string, $v) !== false) {
			$return = $returnvalue ? $v : true;
			return $return;
		}
	}
	return false;
}
//From: Dism_taobao-com
?>