<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_channel_get_Plang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_channel/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_channel/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_channel/language");
	}
	include $_var_1;
	global $wq_channel_plang;
	return $wq_channel_plang;
}
function wq_channel_get_setting()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["wq_channel"];
	$_var_1["allowaddchannel"] = unserialize($_var_1["allowaddchannel"]);
	$_var_1["admincp_perpage"] = intval($_var_1["admincp_perpage"]);
	$_var_1["admincp_perpage"] = !($_var_1["admincp_perpage"] > 0) ? 10 : $_var_1["admincp_perpage"];
	$_var_1["iconfont_url"] = trim($_var_1["iconfont_url"]);
	$_var_1["upload_maxsize"] = intval($_var_1["upload_maxsize"]);
	$_var_1["upload_maxsize"] = $_var_1["upload_maxsize"] ? $_var_1["upload_maxsize"] : 2;
	return $_var_1;
}
function wq_channel_get_block_data_by_bid($_arg_0 = 0, $_arg_1 = false)
{
	global $_G;
	include_once libfile("function/block");
	loadcache("blockclass");
	$_arg_0 = intval($_arg_0);
	block_get_batch($_arg_0);
	$_var_3 = block_fetch_content($_arg_0, $_arg_1);
	if ($_G["mobile"]) {
		$_var_3 = str_replace("target=\"_blank\"", '', $_var_3);
	}
	return $_var_3;
}
function wq_channel_getframeblock($_arg_0)
{
	global $_G;
	include_once libfile("function/portalcp");
	foreach ($_arg_0["layoutdata"] as $_var_2 => $_var_3) {
		if (!empty($_var_3)) {
			getframeblock($_var_3);
		}
	}
}
function wq_channel_import_diy($_arg_0, $_arg_1 = false)
{
	global $_G;
	include_once libfile("function/portalcp");
	wq_channel_getframeblock($_arg_0);
	$_arg_0["blockdata"] = block_export($_G["curtplbid"]);
	$_var_3 = array();
	foreach ($_G["curtplframe"] as $_var_4) {
		$_var_3[] = $_var_4["type"] . random(6);
	}
	foreach ($_arg_0["layoutdata"] as $_var_5 => $_var_4) {
		if ($_arg_1) {
			$_var_6 = wq_channel_getframearray($_var_4);
		} else {
			$_var_6 = wq_channel_getframehtml($_var_4);
		}
	}
	return $_var_6;
}
function wq_channel_getframearray($_arg_0 = array(), $_arg_1 = '')
{
	$_var_2 = array();
	$_var_3 = 1;
	foreach ((array) $_arg_0 as $_var_4 => $_var_5) {
		$_var_4 = wq_channel_trimdxtpllang($_var_4);
		$_var_6 = $_var_7 = '';
		list($_var_6, $_var_7) = explode("`", $_var_4);
		if ($_var_6 == "frame") {
			foreach ((array) $_var_5 as $_var_8 => $_var_9) {
				list($_var_10, $_var_11) = explode("`", $_var_8);
				if ($_var_10 == "column") {
					$_var_2[] = wq_channel_getframearray($_var_9, "frame");
				}
			}
		} else {
			if ($_var_6 == "tab") {
				foreach ((array) $_var_5 as $_var_8 => $_var_9) {
					list($_var_10, $_var_11) = explode("`", $_var_8);
					if ($_var_10 == "column") {
						$_var_2[] = wq_channel_getframearray($_var_9, "tab");
					}
				}
			} else {
				if ($_var_6 == "block") {
					$_var_12 = $_var_5["attr"];
					$_var_13 = intval(str_replace("portal_block_", '', $_var_12["name"]));
					if ($_var_3 == 1) {
						$_var_2["type"] = $_arg_1;
					}
					$_var_2[] = wq_channel_array_by_bid($_var_13);
					$_var_3 = $_var_3 + 1;
				}
			}
		}
	}
	return $_var_2;
}
function wq_channel_array_by_bid($_arg_0)
{
	global $_G;
	$_var_2 = wq_channel_get_Plang();
	include_once libfile("function/block");
	loadcache("blockclass");
	block_get_batch($_arg_0);
	$_var_3 = $_G["block"][$_arg_0];
	$_var_4 = $_var_3["param"];
	$_var_5 = $_var_3["blockclass"];
	$_var_6 = $_var_4["issilde"] ? intval($_var_4["issilde"]) : 0;
	$_var_7 = $_var_4["rows"] ? intval($_var_4["rows"]) : 1;
	$_var_8 = $_var_4["cols"] ? intval($_var_4["cols"]) : 1;
	$_var_9 = block_fetch_content($_arg_0, true);
	preg_match("/data-type=\"(.*)\"/iU", $_var_9, $_var_10);
	list($_var_11, $_var_12) = explode("-", $_var_10[1]);
	if (in_array($_var_5, array("group_thread", "group_group", "group_activity", "group_trade", "member_member"))) {
	}
	$_var_13[$_arg_0] = array("id" => "threadList", "bid" => $_arg_0, "blockclass" => $_var_5, "title" => array(), "templatetype" => trim($_var_11), "templateid" => intval($_var_12), "rows" => 0, "cols" => 0, "startrow" => intval($_var_4["startrow"]), "items" => intval($_var_4["items"]));
	preg_match_all("/<span class=\".+\\>(.*)<\\/span>/iU", $_var_3["title"], $_var_14);
	if ($_var_14[0] && !empty($_var_14[0])) {
		foreach ($_var_14[0] as $_var_15 => $_var_16) {
			$_var_13[$_arg_0]["title"][$_var_15]["title"] = strip_tags($_var_16);
			$_var_13[$_arg_0]["title"][$_var_15]["url"] = '';
			$_var_13[$_arg_0]["title"][$_var_15]["src"] = '';
			if (strpos($_var_16, "<a href=") !== false) {
				preg_match("/href\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\"'>\\s]+))/i", $_var_16, $_var_17);
				$_var_17[1] = str_replace("&amp;", "&", $_var_17[1]);
				$_var_18 = wq_channel_preg_block_data_url($_var_17[1]);
				if (!in_array(strtolower(substr($_var_17[1], 0, 6)), array("http:/", "https:", "ftp://"))) {
					$_var_17[1] = $_G["siteurl"] . ($_var_17[1] == "./" ? '' : $_var_17[1]);
				}
				$_var_13[$_arg_0]["title"][$_var_15]["url"] = $_var_17[1];
				if (in_array($_var_18["script"], array("forum", "group", "portal", "plugin")) && !empty($_var_18["mod"]) && !empty($_var_18["idtype"]) && !empty($_var_18["id"])) {
					$_var_13[$_arg_0]["title"][$_var_15]["url"] = $_var_18["script"] . "/" . $_var_18["mod"] . "/" . $_var_18["mod"] . "?" . $_var_18["idtype"] . "=" . $_var_18["id"];
				}
			}
			if (strpos($_var_16, "<img class=\"vm\"") !== false) {
				preg_match("/img class=\"vm\" src=\"(.*)\" alt/i", $_var_16, $_var_19);
				if (!in_array(strtolower(substr($_var_19[1], 0, 6)), array("http:/", "https:", "ftp://"))) {
					$_var_19[1] = $_G["siteurl"] . $_var_19[1];
				}
				$_var_13[$_arg_0]["title"][$_var_15]["src"] = $_var_19[1];
			}
		}
	}
	if ($_var_11 == "swipeImg") {
		$_var_13[$_arg_0]["id"] = "swipe";
	}
	$_var_20 = 0;
	$_var_13[$_arg_0]["list"][$_var_20] = array();
	foreach ($_var_3["itemlist"] as $_var_15 => $_var_21) {
		$_var_22 = unserialize($_var_21["fields"]);
		$_var_23 = $_var_21["picflag"] == "1" ? $_G["setting"]["attachurl"] : ($_var_21["picflag"] == "2" ? $_G["setting"]["ftp"]["attachurl"] : '');
		$_var_23 = wq_channel_image_pre($_var_23);
		$_var_23 = !$_var_23 ? $_G["siteurl"] : $_var_23;
		$_var_21["title"] = stripslashes($_var_21["title"]);
		$_var_13[$_arg_0]["list"][$_var_20] = array("title" => str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_21["title"])), "dateline" => date($_var_3["dateformat"], $_var_22["dateline"]));
		if (strpos($_var_5, "wqchannel_channel") !== false) {
			$_var_22["script"] = $_var_22["script"] == "forum" ? "article" : $_var_22["script"];
			$_var_22["mod"] = $_var_22["mod"] == "viewthread" ? "article_details" : $_var_22["mod"];
			$_var_22["mod"] = $_var_22["mod"] == "forumdisplay" ? "article_list" : $_var_22["mod"];
			if (!in_array(strtolower(substr($_var_21["url"], 0, 6)), array("http:/", "https:", "ftp://"))) {
				$_var_21["url"] = $_G["siteurl"] . ($_var_21["url"] == "./" ? '' : $_var_21["url"]);
			}
			$_var_13[$_arg_0]["list"][$_var_20]["url"] = $_var_21["url"];
			if (in_array($_var_22["script"], array("forum", "group", "portal", "plugin")) && !empty($_var_22["mod"]) && !empty($_var_22["idtype"]) && !empty($_var_22["id"])) {
				$_var_13[$_arg_0]["list"][$_var_20]["url"] = $_var_22["script"] . "/" . $_var_22["mod"] . "/" . $_var_22["mod"] . "?" . $_var_22["idtype"] . "=" . $_var_22["id"];
			}
			if (isset($_var_21["pic"])) {
				$_var_13[$_arg_0]["list"][$_var_20]["pic"] = $_var_23 . $_var_21["pic"];
				if (strpos($_var_21["pic"], "source/plugin/wq_channel") !== false) {
					$_var_13[$_arg_0]["list"][$_var_20]["pic"] = $_G["siteurl"] . $_var_21["pic"];
				}
			}
			if (isset($_var_21["summary"])) {
				$_var_21["summary"] = stripslashes($_var_21["summary"]);
				$_var_13[$_arg_0]["list"][$_var_20]["summary"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_21["summary"]));
			}
			if (isset($_var_22["backgroupcolor"])) {
				$_var_13[$_arg_0]["list"][$_var_20]["backgroupcolor"] = $_var_22["backgroupcolor"];
			}
			if (isset($_var_22["color"])) {
				$_var_13[$_arg_0]["list"][$_var_20]["color"] = $_var_22["color"];
			}
			if (isset($_var_22["icon"])) {
				$_var_13[$_arg_0]["list"][$_var_20]["icon"] = $_var_22["icon"];
			}
		}
		if (in_array($_var_5, array("forum_thread", "group_thread", "portal_article"))) {
			$_var_24 = $_var_25 = '';
			if ($_var_21["idtype"] == "tid") {
				$_var_13[$_arg_0]["list"][$_var_20]["url"] = "article/article_details/article_details?tid=" . $_var_21["id"];
				$_var_26 = C::t("forum_thread")->fetch($_var_21["id"]);
				if (in_array($_var_26["special"], array(1, 2, 3, 4, 5))) {
					$_var_21["summary"] = '';
				}
			}
			if ($_var_21["idtype"] == "aid") {
				$_var_13[$_arg_0]["list"][$_var_20]["url"] = "portal/view/view?aid=" . $_var_21["id"];
			}
			list($_var_24, $_var_25) = explode("_", $_var_5);
			$_var_13[$_arg_0]["type"] = $_var_24;
			$_var_13[$_arg_0]["list"][$_var_20]["pic"] = $_var_23 . $_var_21["pic"];
			$_var_13[$_arg_0]["list"][$_var_20]["summary"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_21["summary"]));
			$_var_13[$_arg_0]["list"][$_var_20]["forumname"] = isset($_var_22["forumname"]) ? $_var_22["forumname"] : ($_var_22["groupname"] ? $_var_22["groupname"] : $_var_22["catname"]);
			if (!empty($_var_21["thumbpath"])) {
				$_var_21["thumbpath"] = $_var_23 . $_var_21["thumbpath"];
			}
			$_var_13[$_arg_0]["list"][$_var_20]["thumbpath"] = $_var_21["thumbpath"];
			$_var_13[$_arg_0]["list"][$_var_20]["views"] = isset($_var_22["views"]) ? $_var_22["views"] : $_var_22["viewnum"];
			$_var_13[$_arg_0]["list"][$_var_20]["replies"] = isset($_var_22["replies"]) ? $_var_22["replies"] : $_var_22["commentnum"];
			$_var_13[$_arg_0]["list"][$_var_20]["author"] = isset($_var_22["author"]) ? $_var_22["author"] : $_var_22["username"];
			$_var_13[$_arg_0]["list"][$_var_20]["authorid"] = isset($_var_22["authorid"]) ? $_var_22["authorid"] : $_var_22["uid"];
			$_var_13[$_arg_0]["list"][$_var_20]["avatar"] = $_var_22["avatar"];
		}
		if (in_array($_var_5, array("forum_forum", "group_group", "portal_category"))) {
			$_var_13[$_arg_0]["list"][$_var_20]["threads"] = isset($_var_22["threads"]) ? $_var_22["threads"] : $_var_22["articles"];
			$_var_13[$_arg_0]["list"][$_var_20]["summary"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_21["summary"]));
			if (!in_array(strtolower(substr($_var_22["icon"], 0, 6)), array("http:/", "https:", "ftp://"))) {
				$_var_22["icon"] = $_G["siteurl"] . $_var_22["icon"];
			}
			$_var_13[$_arg_0]["list"][$_var_20]["icon"] = $_var_22["icon"];
			$_var_13[$_arg_0]["list"][$_var_20]["posts"] = $_var_22["posts"];
			$_var_13[$_arg_0]["list"][$_var_20]["todayposts"] = $_var_22["todayposts"];
			if ($_var_5 == "forum_forum") {
				$_var_13[$_arg_0]["list"][$_var_20]["url"] = "article/article_list/article_list?fid=" . $_var_21["id"];
			}
			if ($_var_5 == "group_group") {
				$_var_13[$_arg_0]["list"][$_var_20]["url"] = "forum/group/group?fid=" . $_var_21["id"];
				$_var_13[$_arg_0]["list"][$_var_20]["level"] = $_var_22["level"];
				$_var_13[$_arg_0]["list"][$_var_20]["founderuid"] = $_var_22["founderuid"];
				$_var_13[$_arg_0]["list"][$_var_20]["foundername"] = $_var_22["foundername"];
				$_var_13[$_arg_0]["list"][$_var_20]["membernum"] = $_var_22["membernum"];
				$_var_13[$_arg_0]["list"][$_var_20]["activity"] = $_var_22["activity"];
			}
		}
		$_var_20 = $_var_20 + 1;
	}
	$_var_13[$_arg_0]["total"] = count($_var_13[$_arg_0]["list"]);
	$_var_13[$_arg_0]["swiper"] = 1;
	if (empty($_var_13[$_arg_0]["list"])) {
	}
	if (in_array($_var_5, array("wqchannel_channellink", "wqchannel_channelbutton"))) {
		$_var_27 = $_var_7 * $_var_8;
		$_var_13[$_arg_0]["rows"] = $_var_7;
		$_var_13[$_arg_0]["cols"] = $_var_8;
		if ($_var_5 == "wqchannel_channellink" && $_var_7 > 1) {
			$_var_6 = 0;
		}
		if ($_var_6) {
			$_var_13[$_arg_0]["issilde"] = $_var_6;
			$_var_13[$_arg_0]["id"] = "swipe";
		}
		$_var_13[$_arg_0]["list"] = array_chunk($_var_13[$_arg_0]["list"], $_var_27);
	}
	if ($_var_5 == "wqchannel_channelvideo") {
		$_var_13[$_arg_0]["id"] = "video";
	}
	if (in_array($_var_11, array("modtitleImgThreeAll", "modtitleImgFiveAll", "modtitleImgAll", "modtitleImgThreeAllMore", "modtitleImgAllMore", "modtitleImgFiveAllMore"))) {
		$_var_28 = array(array("title" => $_var_2["quanbubankuai"], "icon" => $_G["siteurl"] . "./source/plugin/wq_channel/static/images/wq_allsection.png", "url" => "article/article_category/article_category"));
		$_var_13[$_arg_0]["list"] = array_merge($_var_13[$_arg_0]["list"], $_var_28);
	}
	if (in_array($_var_11, array("modtitleImgThreeAllMore", "modtitleImgAllMore", "modtitleImgFiveAllMore", "modtitleImgThreeMore", "modtitleImgMore", "modtitleImgFiveMore"))) {
		switch ($_var_11) {
			case "modtitleImgThreeMore":
			case "modtitleImgThreeAllMore":
				$_var_27 = 6;
				break;
			case "modtitleImgMore":
			case "modtitleImgAllMore":
				$_var_27 = 8;
				break;
			case "modtitleImgFiveMore":
			case "modtitleImgFiveAllMore":
				$_var_27 = 10;
				break;
		}
		$_var_13[$_arg_0]["list"] = array_chunk($_var_13[$_arg_0]["list"], $_var_27);
		$_var_13[$_arg_0]["id"] = "swipe";
	}
	return $_var_13[$_arg_0];
}
function wq_channel_getframehtml($_arg_0 = array(), $_arg_1 = '')
{
	global $_G;
	$_var_3 = $_var_4 = '';
	foreach ((array) $_arg_0 as $_var_5 => $_var_6) {
		$_var_5 = wq_channel_trimdxtpllang($_var_5);
		$_var_7 = $_var_8 = '';
		list($_var_7, $_var_8) = explode("`", $_var_5);
		if ($_var_7 == "frame") {
			$_var_9 = $_var_6["attr"];
			$_var_9["name"] = wq_channel_trimdxtpllang($_var_9["name"]);
			$_var_9["className"] = wq_channel_trimdxtpllang($_var_9["className"]);
			$_var_10 = $_var_9["moveable"] == "true" ? " move-span" : '';
			$_var_3 = $_var_3 . ("<div id=\"" . $_var_9["name"] . "\" class=\"" . $_var_9["className"] . "\">");
			if (checkhastitle($_var_9["titles"])) {
				$_var_4 = wq_gettitlestyle($_var_9["titles"]);
				$_var_11 = wq_channel_trimdxtpllang(implode(" ", $_var_9["titles"]["className"]));
				$_var_3 = $_var_3 . ("<div class=\"" . $_var_11 . "\"" . $_var_4 . ">" . wq_channel_gettitlehtml($_var_9["titles"], "frame") . "</div>");
			}
			foreach ((array) $_var_6 as $_var_12 => $_var_13) {
				list($_var_14, $_var_15) = explode("`", $_var_12);
				$_var_15 = wq_channel_trimdxtpllang($_var_15);
				$_var_11 = wq_channel_trimdxtpllang($_var_13["attr"]["className"]);
				if ($_var_14 == "column") {
					$_var_3 = $_var_3 . ("<div id=\"" . $_var_15 . "\" class=\"" . $_var_11 . "\">");
					$_var_3 = $_var_3 . ("<div id=\"" . $_var_15 . "_temp\" class=\"move-span temp\"></div>");
					$_var_3 = $_var_3 . wq_channel_getframehtml($_var_13, $_var_7);
					$_var_3 = $_var_3 . "</div>";
				}
			}
			$_var_3 = $_var_3 . "</div>";
		} else {
			if ($_var_7 == "tab") {
				$_var_9 = $_var_6["attr"];
				$_var_9["name"] = wq_channel_trimdxtpllang($_var_9["name"]);
				$_var_9["className"] = wq_channel_trimdxtpllang($_var_9["className"]);
				$_var_10 = $_var_9["moveable"] == "true" ? " move-span" : '';
				$_var_3 = $_var_3 . ("<div id=\"" . $_var_9["name"] . "\" class=\"" . $_var_9["className"] . "\">");
				$_var_16 = "click";
				foreach ((array) $_var_6 as $_var_12 => $_var_13) {
					list($_var_14, $_var_15) = explode("`", $_var_12);
					$_var_15 = wq_channel_trimdxtpllang($_var_15);
					$_var_11 = wq_channel_trimdxtpllang($_var_13["attr"]["className"]);
					if ($_var_14 == "column") {
						if (checkhastitle($_var_9["titles"])) {
							$_var_4 = wq_gettitlestyle($_var_9["titles"]);
							$_var_17 = wq_channel_gettitlehtml($_var_9["titles"], "tab");
						}
						$_var_16 = is_array($_var_9["titles"]["switchType"]) && !empty($_var_9["titles"]["switchType"][0]) ? $_var_9["titles"]["switchType"][0] : "click";
						$_var_16 = in_array(strtolower($_var_16), array("click", "mouseover")) ? $_var_16 : "click";
						$_var_3 = $_var_3 . ("<div id=\"" . $_var_15 . "\" class=\"" . $_var_11 . "\"" . $_var_4 . " switchtype=\"" . $_var_16 . "\">" . $_var_17);
						$_var_3 = $_var_3 . wq_channel_getframehtml($_var_13, $_var_7);
						$_var_3 = $_var_3 . "</div>";
					}
				}
				$_var_3 = $_var_3 . ("<div id=\"" . $_var_9["name"] . "_content\" class=\"tb-c\"></div>");
				$_var_3 = $_var_3 . ("<script type=\"text/javascript\">mobile_initTab(\"" . $_var_9["name"] . "\");</script>");
				$_var_3 = $_var_3 . "</div>";
			} else {
				if ($_var_7 == "block") {
					$_var_18 = $_var_6["attr"];
					$_var_19 = intval(str_replace("portal_block_", '', $_var_18["name"]));
					if (!empty($_var_19)) {
						$_var_20 = wq_channel_get_block_data_by_bid($_var_19);
						if ($_arg_1 == "tab") {
							$_var_20 = str_replace(array("!important"), array(''), $_var_20);
						}
						if ($_arg_1 == "frame" && strpos($_var_20, "class=\"blocktitle title\"") !== false) {
							$_var_4 = '';
							$_var_21 = trim(substr($_var_20, strpos($_var_20, ";color") + 7, 8));
							if (!empty($_var_21) && $_var_21 != "!import") {
								if ($_G["wqchannel"]["modstyle"] == 1) {
									$_var_4 = "border-bottom: 1px solid " . $_var_21 . ";";
								}
								if ($_G["wqchannel"]["modstyle"] == 3) {
									$_var_4 = "style=\"background-color: " . $_var_21 . " !important;\"";
								}
							}
							if ($_G["wqchannel"]["modstyle"] == 1) {
								$_var_20 = str_replace(array("div class=\"blocktitle title\"", "span class=\"titletext\" style=\""), array("div class=\"blocktitle title wqchannel_title_one\"", "span class=\"titletext wqborder_bottom title_border_bottom\" style=\"" . $_var_4), $_var_20);
							} elseif ($_G["wqchannel"]["modstyle"] == 2) {
								$_var_20 = str_replace(array("div class=\"blocktitle title\"", "span class=\"titletext\""), array("div class=\"blocktitle title wqchannel_title_one\"", "span class=\"titletext title_border_bottom\""), $_var_20);
							} elseif ($_G["wqchannel"]["modstyle"] == 3) {
								$_var_20 = str_replace(array("div class=\"blocktitle title\"", "span class=\"titletext\"", "important;\">"), array("div class=\"blocktitle title wqchannel_title_one\"", "span class=\"titletext title_border_bottom\"", "important;\"><em class=\"wqborder_channelleft\" " . $_var_4 . "></em>"), $_var_20);
							}
						}
						$_var_22 = $_var_23 = '';
						$_var_24 = $_G["block"][$_var_19];
						$_var_25 = $_var_24["param"];
						$_var_26 = $_var_24["blockclass"];
						$_var_27 = $_var_25["issilde"];
						if ($_var_26 == "wqchannel_channelimgbut" || $_var_26 == "wqchannel_channelbutton" || $_var_26 == "wqchannel_channellink" || $_var_26 == "member_member") {
							if ($_var_27 || $_var_26 == "member_member") {
								$_var_28 = intval($_var_25["rows"]);
								$_var_29 = intval($_var_25["cols"]);
								$_var_23 = "wq_" . TIMESTAMP . "_a" . rand(0, 99);
								$_var_22 = "<script> itemSlide(" . $_var_28 . "," . $_var_29 . ", '." . $_var_23 . "');</script>";
								if ($_var_28 == 1 && $_var_26 == "wqchannel_channellink" || $_var_26 == "member_member") {
									$_var_22 = " <script> \$('." . $_var_23 . "').scrollnav(" . $_var_29 . ");</script>";
									if (!$_G["mobile"]) {
										$_var_22 = " <script>wqjq('." . $_var_23 . "').scrollnav(" . $_var_29 . ");</script>";
									}
								}
							}
							$_var_20 = str_replace(array("<!--{silde}-->", "<!--{sildeclass}-->"), array($_var_22, $_var_23), $_var_20);
						}
						if (in_array($_var_26, array("forum_forum", "group_group"))) {
							$_var_30 = "wq_" . TIMESTAMP . "_a" . rand(0, 99);
							$_var_20 = str_replace("!wqforum_more!", $_var_30, $_var_20);
						}
						if (in_array($_var_26, array("group_thread", "portal_article", "forum_thread"))) {
							$_var_31 = "wq_" . TIMESTAMP . "_a" . rand(0, 99);
							$_var_20 = str_replace("!wqreplaceloop!", $_var_31, $_var_20);
							if (strpos($_var_20, "data-type=\"titleMore\"") !== false) {
								$_var_20 = str_replace("div class=\"blocktitle title wqchannel_title_one\"", "div class=\"blocktitle title wqchannel_title_ad\"", $_var_20);
							}
						}
						if (!$_G["mobile"]) {
							$_var_20 = str_replace(array("<script>\$", "<script> \$"), "<script>wqjq", $_var_20);
						}
						$_var_3 = $_var_3 . $_var_20;
						$_G["curtplbid"][$_var_19] = $_var_19;
					}
				}
			}
		}
	}
	return $_var_3;
}
function wq_channel_gettitlehtml($_arg_0, $_arg_1)
{
	global $_G;
	if (!is_array($_arg_0)) {
		return '';
	}
	$_var_3 = $_var_4 = $_var_5 = $_var_6 = '';
	foreach ($_arg_0 as $_var_7 => $_var_8) {
		if (!in_array(strval($_var_7), array("className", "style"))) {
			if (!empty($_var_8["src"]) || !empty($_var_8["text"])) {
				$_var_8["className"] = wq_channel_trimdxtpllang($_var_8["className"]);
				$_var_8["font-size"] = intval($_var_8["font-size"]);
				$_var_8["margin"] = intval($_var_8["margin"]);
				$_var_8["float"] = wq_channel_trimdxtpllang($_var_8["float"]);
				$_var_8["color"] = wq_channel_trimdxtpllang($_var_8["color"]);
				$_var_8["src"] = wq_channel_trimdxtpllang($_var_8["src"]);
				$_var_8["href"] = wq_channel_trimdxtpllang($_var_8["href"]);
				$_var_8["text"] = dhtmlspecialchars(str_replace(array("{", "\$"), array("{ ", "\$ "), $_var_8["text"]));
				$_var_4 = "<span class=\"" . $_var_8["className"] . "\" ";
				$_var_5 = $_var_6 = '';
				$_var_5 = $_var_5 . (empty($_var_8["font-size"]) ? '' : "font-size:{" . $_var_8 . "['font-size']}px;");
				$_var_5 = $_var_5 . (empty($_var_8["float"]) ? '' : "float:" . $_var_8["float"] . ";");
				$_var_9 = empty($_var_8["float"]) ? "left" : $_var_8["float"];
				$_var_5 = $_var_5 . (empty($_var_8["margin"]) ? '' : "margin-" . $_var_9 . ":" . $_var_8["margin"] . "px;");
				$_var_6 = empty($_var_8["color"]) ? '' : "color:" . $_var_8["color"] . ";";
				$_var_10 = !empty($_var_8["src"]) ? "<img src=\"" . $_var_8["src"] . "\" class=\"vm\" alt=\"" . $_var_8["text"] . "\"/>" : '';
				if (empty($_var_8["href"])) {
					$_var_5 = empty($_var_5) && empty($_var_6) ? '' : " style=\"" . $_var_5 . $_var_6 . "\"";
					$_var_4 = $_var_4 . ($_var_5 . ">" . $_var_10 . '' . $_var_8["text"] . '');
				} else {
					$_var_5 = empty($_var_5) ? '' : " style=\"" . $_var_5 . "\"";
					$_var_11 = empty($_var_6) ? '' : " style=\"" . $_var_6 . "\"";
					$_var_4 = $_var_4 . ($_var_5 . "><a href=\"" . $_var_8["href"] . "\" target=\"_blank\"" . $_var_11 . ">" . $_var_10 . $_var_8["text"] . "</a>");
				}
				$_var_4 = $_var_4 . "</span>";
				$_var_12 = str_replace(array("/", "."), array("\\/", "\\."), $_G["siteurl"]);
				$_var_4 = preg_replace("/\\\"" . $_var_12 . "(.*?)\\\"/", "\"\$1\"", $_var_4);
				$_var_3 = $_var_7 === "first" ? $_var_4 . $_var_3 : $_var_3 . $_var_4;
			}
		}
	}
	return $_var_3;
}
function wq_channel_trimdxtpllang($_arg_0)
{
	return str_replace(array("{", "\$", "<", ">"), array("{ ", "\$ ", '', ''), $_arg_0);
}
function wq_gettitlestyle($_arg_0)
{
	$_var_1 = '';
	if (is_array($_arg_0["style"]) && count($_arg_0["style"])) {
		foreach ($_arg_0["style"] as $_var_2 => $_var_3) {
			$_var_1 = $_var_1 . (wq_channel_trimdxtpllang($_var_2) . ":" . wq_channel_trimdxtpllang($_var_3) . ";");
		}
	}
	$_var_1 = $_var_1 ? " style='" . $_var_1 . "'" : '';
	return $_var_1;
}
function wq_channel_get_html_by_targettplname($_arg_0)
{
	global $_G;
	$_var_2 = wq_channel_get_diycontent_by_targettplname($_arg_0);
	$_var_3 = wq_channel_import_diy($_var_2);
	return array("html" => $_var_3, "spacecss" => $_var_2["spacecss"]);
}
function wq_channel_get_diycontent_by_targettplname($_arg_0)
{
	global $_G;
	$_var_2 = DB::fetch_first("SELECT diycontent FROM %t WHERE targettplname=%s", array("common_diy_data", $_arg_0));
	$_var_2 = dunserialize($_var_2["diycontent"]);
	return $_var_2;
}
function wq_channel_updatechannel($_arg_0 = '', $_arg_1 = array())
{
	global $_G;
	$_var_3 = wq_channel_get_Plang();
	if (!empty($_arg_1)) {
		$_POST = $_arg_1;
	}
	loadcache("wq_channel_create_pages");
	$_var_4 = $_G["cache"]["wq_channel_create_pages"];
	$_var_5 = empty($_arg_0) ? '' : $_arg_0["pageid"];
	include_once libfile("function/home");
	$_var_6 = getstr(trim($_POST["title"]), 255);
	$_var_7 = getstr(trim($_POST["name"]), 255);
	$_var_8 = getstr(trim($_POST["foldername"]), 50);
	$_var_9 = empty($_arg_0) ? '' : $_arg_0["pagename"];
	if (isset($_POST["pagename"]) && preg_match("/^\\w*\$/", $_POST["pagename"]) && !preg_match("/^\\d+\$/", $_POST["pagename"]) && strlen($_POST["pagename"]) <= 30) {
		$_var_9 = getstr(trim($_POST["pagename"]), 30);
	}
	if ($_var_5) {
		$_var_10 = getstr(trim($_POST["primaltplname"]), 255);
		$_var_11 = $_var_10;
	} else {
		$_var_12 = getstr(trim($_POST["primaltplname"]), 255);
		$_var_11 = $_var_12;
	}
	if (empty($_var_6)) {
		return $_var_3["19db953111a47146"];
	}
	if (empty($_var_7)) {
		return $_var_3["41f926b22d6f9de8"];
	}
	if (!$_var_5 || $_var_7 != $_arg_0["name"]) {
		if ($_var_13 = C::t("#wq_channel#wq_channel_pages")->fetch_by_name($_var_7)) {
			return $_var_3["2e4a14c5cfcf31d9"];
		}
	}
	if ($_var_9 && (!$_var_5 || $_var_9 != $_arg_0["pagename"])) {
		if ($_var_13 = C::t("#wq_channel#wq_channel_pages")->fetch_by_pagename($_var_9)) {
			return $_var_3["2e4a14biemif31d9"];
		}
	}
	if (!empty($_var_8)) {
		$_var_14 = empty($_var_5) ? '' : $_arg_0["foldername"];
		preg_match_all("/[^\\w\\d\\_]/", $_var_8, $_var_15);
		if (!empty($_var_15[0])) {
			return $_var_3["9b045b986e53ab80"];
		}
		if ($_var_8 == $_var_14) {
			$_var_16 = $_var_8;
		} else {
			if (is_dir(DISCUZ_ROOT . "./" . $_var_8)) {
				return $_var_3["e44b1e76d125ae2c"];
			}
			if ($_var_14) {
				if (is_dir(DISCUZ_ROOT . "./" . $_var_14)) {
					$_var_17 = rename(DISCUZ_ROOT . "./" . $_var_14, DISCUZ_ROOT . "./" . $_var_8);
					if (!$_var_17) {
						return $_var_3["9b045b986e53ab80"];
					}
				}
				$_var_16 = $_var_8;
			} else {
				if (empty($_var_14)) {
					$_var_16 = $_var_8;
				}
			}
		}
	} else {
		if (empty($_var_8) && !empty($_arg_0["foldername"])) {
			wq_channel_del_secondary_directory($_arg_0["foldername"]);
		}
	}
	if (!isset($_POST["signs"][dsign($_var_11)])) {
		return $_var_3["98317bfe7aec1884"];
	}
	$_var_18 = array("title" => $_var_6, "name" => $_var_7, "pagename" => $_var_9, "foldername" => $_var_8, "keywords" => getstr($_POST["keywords"]), "description" => getstr($_POST["description"]), "useheader" => $_POST["useheader"] ? "1" : "0", "usefooter" => $_POST["useheader"] ? "1" : "0", "closed" => $_POST["closed"] ? 0 : 1, "color" => $_POST["color"] ? trim($_POST["color"]) : "#EB413D", "setcolor" => $_POST["setcolor"] ? trim($_POST["setcolor"]) : '', "modstyle" => $_POST["modstyle"] ? intval($_POST["modstyle"]) : 1);
	if ($_var_5) {
		C::t("#wq_channel#wq_channel_pages")->update($_var_5, $_var_18);
		C::t("common_diy_data")->update("channel_index_" . $_var_5, wq_channel_get_diy_directory($_var_10), array("name" => $_var_7));
	} else {
		$_var_18["uid"] = $_G["uid"];
		$_var_18["username"] = $_G["username"];
		$_var_18["dateline"] = $_G["timestamp"];
		$_var_5 = wq_channel_addpages($_var_18);
		if (!$_var_5) {
			return $_var_3["bac70b9d34b6c997"];
		}
	}
	if ($_var_16) {
		if (!wq_channel_create_secondary_directory($_var_16, $_var_5)) {
			C::t("#wq_channel#wq_channel_pages")->update($_var_5, array("foldername" => ''));
			return $_var_3["ce543c432a49ddcd"];
		}
	}
	$_var_19 = '';
	if ($_var_12 && $_var_12 != '') {
		$_var_20 = "channel_index_" . $_var_5;
		if (strpos($_var_12, ":") !== false) {
			list($_var_19, $_var_12) = explode(":", $_var_12);
		}
		C::t("common_diy_data")->update($_var_20, wq_channel_get_diy_directory($_var_12), array("primaltplname" => $_var_12, "tpldirectory" => $_var_19));
		updatediytemplate($_var_20);
	}
	if ($_var_12 && $_var_12 != '') {
		$_var_21 = file_get_contents(DISCUZ_ROOT . $_var_19 . "/" . $_var_12 . ".htm");
		$_var_22 = DISCUZ_ROOT . "./data/diy/" . $_var_19 . "/" . $_var_12 . "_" . $_var_5 . ".htm";
		$_var_23 = dirname($_var_22);
		if (!is_dir($_var_23)) {
			dmkdir($_var_23);
		}
		file_put_contents($_var_22, $_var_21);
	}
	include_once libfile("function/cache");
	updatecache(array("diytemplatename", "setting"));
	wq_channel_save_pages();
	return $_var_5;
}
function wq_channel_save_pages()
{
	$_var_0 = wq_channel_pages_fetch_all();
	foreach ($_var_0 as $_var_1 => $_var_2) {
		$_var_3[$_var_2["pageid"]] = $_var_2;
	}
	savecache("wq_channel_create_pages", $_var_3);
}
function wq_channel_pages_fetch_all()
{
	$_var_0 = C::t("#wq_channel#wq_channel_pages")->fetch_all();
	return $_var_0;
}
function wq_channel_addpages($_arg_0)
{
	global $_G;
	$_var_2 = '';
	if ($_arg_0 && is_array($_arg_0)) {
		$_var_2 = C::t("#wq_channel#wq_channel_pages")->insert($_arg_0, true);
		if (!empty($_var_2)) {
			$_var_3 = array("targettplname" => "channel_index_" . $_var_2, "name" => $_arg_0["title"], "uid" => $_G["uid"], "username" => $_G["username"], "dateline" => TIMESTAMP);
			C::t("common_diy_data")->insert($_var_3);
		}
	}
	return $_var_2;
}
function wq_channel_create_secondary_directory($_arg_0, $_arg_1)
{
	dmkdir(DISCUZ_ROOT . "./" . $_arg_0, 511, false);
	$_var_2 = $_arg_0;
	if ($_var_2) {
		$_var_2 = substr($_var_2, -1, 1) == "/" ? "/" . $_var_2 : "/" . $_var_2 . "/";
	}
	$_var_3 = "<?php\r\n            chdir('../');\r\n            define('SUB_DIR', '" . $_var_2 . "');\r\n            \$_GET['id'] = 'wq_channel';\r\n            \$_GET['mod'] = 'channel_index';\r\n            \$_GET['pageid'] = '" . $_arg_1 . "';\r\n            require_once './plugin.php';\r\n            ?>";
	$_var_4 = file_put_contents($_arg_0 . "/index.php", $_var_3);
	return $_var_4;
}
function wq_channel_del_secondary_directory($_arg_0)
{
	if (!empty($_arg_0)) {
		unlink(DISCUZ_ROOT . $_arg_0 . "/index.html");
		unlink(DISCUZ_ROOT . $_arg_0 . "/index.php");
		rmdir(DISCUZ_ROOT . $_arg_0);
	}
}
function wq_channel_get_diy_directory($_arg_0)
{
	$_var_1 = '';
	if ($_arg_0 && strpos($_arg_0, ":") !== false) {
		list($_var_1) = explode(":", $_arg_0);
	}
	return $_var_1;
}
function wq_channel_create_template()
{
	include DISCUZ_ROOT . "./source/plugin/wq_channel/data/diy_style.php";
	$_var_0 = wq_channel_get_style();
	foreach ($_var_0 as $_var_1) {
		$_var_2 = $_var_1["blockclass"];
		$_var_3 = $_var_1["name"];
		if (is_array($_var_2)) {
			foreach ($_var_2 as $_var_4 => $_var_5) {
				$_var_6 = array("name" => $_var_3, "blockclass" => $_var_5);
				list($_var_7, $_var_8) = explode("_", $_var_5);
				$_var_9 = str_replace("!type!", $_var_7, $_var_1["template"]);
				$_var_10 = DB::fetch_first("SELECT * FROM " . DB::table("common_block_style") . " WHERE name=%s AND blockclass=%s", array($_var_3, $_var_5));
				include_once libfile("function/block");
				block_parse_template($_var_9, $_var_6);
				if ($_var_10["styleid"]) {
					C::t("common_block_style")->update($_var_10["styleid"], $_var_6);
				} else {
					$_var_11 = C::t("common_block_style")->insert($_var_6, true);
				}
				require_once libfile("function/cache");
				updatecache("blockclass");
			}
		}
	}
}
function wq_channel_delete_template()
{
	include DISCUZ_ROOT . "./source/plugin/wq_channel/data/diy_style.php";
	$_var_0 = wq_channel_get_style();
	foreach ($_var_0 as $_var_1) {
		DB::delete("common_block_style", array("name" => $_var_1["name"]));
	}
}
function wq_channeldelete_cookies($_arg_0)
{
	global $_G;
	$_var_2 = wq_channel_get_diycontent_by_targettplname($_arg_0);
	wq_channel_getframeblock($_var_2);
	$_var_3 = $_G["curtplbid"];
	foreach ($_var_3 as $_var_4) {
		dsetcookie("startrow_" . $_var_4, 0);
	}
}
function wq_channel_setcookie($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = $_G["cookie"]["startrow_" . $_arg_0] ? intval($_G["cookie"]["startrow_" . $_arg_0] + $_arg_1["items"]) : intval($_arg_1["startrow"] + $_arg_1["items"]);
	dsetcookie("startrow_" . $_arg_0, $_var_3);
	return $_var_3;
}
function wq_channel_upload_images($_arg_0, $_arg_1 = 2, $_arg_2 = "wq_channel")
{
	global $_G;
	$_var_4 = wq_channel_get_setting();
	$_arg_1 = $_var_4["upload_maxsize"] ? $_var_4["upload_maxsize"] : $_arg_1;
	include_once DISCUZ_ROOT . "./source/plugin/wq_channel/class/upload.class.php";
	$_var_5 = new wq_channel_discuz_upload();
	$_var_5->init($_arg_0, $_arg_2);
	$_var_6 = $_var_5->attach;
	if ($_var_6["size"] > $_arg_1 * 1024 * 1024) {
		if (!defined("IN_ADMINCP")) {
			return "-105";
		}
		return false;
	}
	if (!$_var_6["isimage"]) {
		if (!defined("IN_ADMINCP")) {
			return "-102";
		}
		return false;
	}
	$_var_5->save();
	$_var_7 = intval($_var_5->errorcode);
	if ($_var_7 < 0) {
		if (!defined("IN_ADMINCP")) {
			return $_var_7;
		}
		return false;
	}
	return $_var_6["attachment"];
}
function wq_channel_diconv($_arg_0, $_arg_1 = CHARSET, $_arg_2 = CHARSET, $_arg_3 = false)
{
	if (!is_array($_arg_0)) {
		$_var_4 = diconv($_arg_0, $_arg_1, $_arg_2, $_arg_3);
		return $_var_4;
	}
	$_var_4 = array();
	foreach ($_arg_0 as $_var_5 => $_var_6) {
		if (!is_array($_var_6)) {
			$_var_4[$_var_5] = diconv($_var_6, $_arg_1, $_arg_2, $_arg_3);
		}
		$_var_4[$_var_5] = wq_channel_diconv($_var_6, $_arg_1, $_arg_2, $_arg_3);
	}
	return $_var_4;
}
function wq_channel_preg_block_data_url($_arg_0)
{
	global $_G;
	$_var_2 = substr($_arg_0, strpos($_arg_0, "?") + 1);
	parse_str($_var_2, $_var_3);
	$_var_4 = array("script" => '', "mod" => '', "idtype" => '', "id" => '');
	$_var_5 = array("forumdisplay" => array("forumdisplay", "fid"), "viewthread" => array("viewthread", "tid"), "group" => array("group", "fid"));
	if (strpos($_arg_0, "forum.php") !== false) {
		$_var_4["script"] = "forum";
		foreach ($_var_5 as $_var_6 => $_var_7) {
			if ($_var_7[0] == $_var_3["mod"] || isset($_var_3[$_var_7[1]])) {
				$_var_4["mod"] = $_var_7[0];
				$_var_4["idtype"] = $_var_7[1];
				$_var_4["id"] = $_var_3[$_var_7[1]];
				break;
			}
		}
	}
	$_var_8 = array("view" => array("view", "aid"));
	if (strpos($_arg_0, "portal.php") !== false) {
		$_var_4["script"] = "portal";
		foreach ($_var_8 as $_var_6 => $_var_9) {
			if ($_var_9[0] == $_var_3["mod"] || $_var_3[$_var_9[1]]) {
				$_var_4["mod"] = $_var_9[0];
				$_var_4["idtype"] = $_var_9[1];
				$_var_4["id"] = $_var_3[$_var_9[1]];
				break;
			}
		}
	}
	$_var_10 = array("gid" => array("gid"));
	if (strpos($_arg_0, "group.php") !== false) {
		$_var_4["script"] = "group";
		foreach ($_var_10 as $_var_6 => $_var_11) {
			if (isset($_var_3[$_var_11[1]])) {
				$_var_4["idtype"] = $_var_11[1];
				$_var_4["id"] = $_var_3[$_var_11[1]];
				break;
			}
		}
	}
	$_var_12 = array("wq_channel" => array("wq_channel", "pageid"));
	if (strpos($_arg_0, "plugin.php") !== false) {
		foreach ($_var_12 as $_var_6 => $_var_13) {
			if ($_var_13[0] == $_var_3["id"] || $_var_3[$_var_13[1]]) {
				$_var_4["script"] = "plugin";
				$_var_4["mod"] = $_var_13[0];
				$_var_4["idtype"] = $_var_13[1];
				$_var_4["id"] = $_var_3[$_var_13[1]];
			}
		}
	}
	return $_var_4;
}
function wq_channel_wxapp_get_channelinfo_by_targettplname($_arg_0, $_arg_1 = array())
{
	$_var_2 = array();
	if (!$_arg_0) {
		return $_var_2;
	}
	$_var_3 = wq_channel_get_diycontent_by_targettplname($_arg_0);
	$_var_4 = wq_channel_import_diy($_var_3, true);
	$_var_5 = $_arg_1["setcolor"] ? $_arg_1["setcolor"] : $_arg_1["color"];
	$_var_6 = $_arg_1["modstyle"];
	$_var_2["color"] = $_var_5;
	$_var_2["modstyle"] = $_var_6;
	$_var_7 = 0;
	foreach ($_var_4 as $_var_8 => $_var_9) {
		if ($_var_9["type"] == "frame") {
			unset($_var_9["type"]);
			foreach ($_var_9 as $_var_10 => $_var_11) {
				if (!empty($_var_11)) {
					$_var_2["wq" . $_var_7] = $_var_11;
					$_var_2["wq" . $_var_7]["page"] = "wq" . $_var_7;
				}
				$_var_7 = $_var_7 + 1;
			}
		}
		if ($_var_9["type"] == "tab") {
			unset($_var_9["type"]);
			foreach ($_var_9 as $_var_8 => $_var_11) {
				if (!empty($_var_11["title"])) {
					$_var_9[$_var_8]["title"] = array($_var_11["title"][0]);
				}
			}
			$_var_2["wq" . $_var_7]["id"] = "threadList";
			$_var_2["wq" . $_var_7]["list"] = $_var_9;
			$_var_2["wq" . $_var_7]["page"] = "wq" . $_var_7;
			$_var_2["wq" . $_var_7]["templatetype"] = "tags";
			$_var_2["wq" . $_var_7]["selTag"] = 0;
			$_var_7 = $_var_7 + 1;
		}
	}
	return $_var_2;
}
function wq_channel_icon_or_color_select($_arg_0, $_arg_1, $_arg_2 = '', $_arg_3 = "color", $_arg_4 = false)
{
	if ($_arg_3 == "icon") {
		$_var_5 = "<i class=\"" . $_arg_2 . " left\"></i><input style=\"width:160px\" type = \"text\" id=\"" . $_arg_0 . "_v\" class=\"left txt\"  name=\"" . $_arg_1 . "\"  value=\"" . $_arg_2 . "\" onchange=\"updatecolorpreview('" . $_arg_0 . "')\"><input type=\"button\" value=\"&#x56FE;&#x6807;\"  id=\"" . $_arg_0 . "\"  class=\"colorwd\" onclick=\"" . $_arg_0 . "_frame.location='plugin.php?id=wq_channel&mod=icon&ac=" . $_arg_0 . "|" . $_arg_0 . "_v';showMenu({'ctrlid':'" . $_arg_0 . "'})\" /><span id=\"" . $_arg_0 . "_menu\" style=\"display: none\"><iframe name=\"" . $_arg_0 . "_frame\" src=\"\" frameborder=\"0\" width=\"458\" height=\"260\" style=\" border: 1px solid #dedede;\" ></iframe></span>";
		if ($_arg_4) {
			$_var_5 = "<input style=\"width:160px\" type = \"text\" id=\"" . $_arg_0 . "' + addrowkey + '_v\" class=\"left txt\"  name=\"" . $_arg_1 . "['+addrowkey+']\" value=\"" . $_arg_2 . "\" onchange=\"updatecolorpreview(\\'" . $_arg_0 . "'+addrowkey+'\\')\"><input type=\"button\" value=\"&#x56FE;&#x6807;\" id=\\'" . $_arg_0 . "'+addrowkey+'\\'  class=\"colorwd\" onclick=\"" . $_arg_0 . "'+addrowkey+'_frame.location=\\'plugin.php?id=wq_channel&mod=icon&ac=" . $_arg_0 . "'+addrowkey+'|" . $_arg_0 . "'+addrowkey+'_v\\';showMenu({\\'ctrlid\\':\\'" . $_arg_0 . "'+addrowkey+'\\'})\" /><span id=\"" . $_arg_0 . "'+addrowkey+'_menu\" style=\"display: none\"><iframe name=\"" . $_arg_0 . "'+addrowkey+'_frame\" src=\"\" frameborder=\"0\" width=\"458\" height=\"260\"  style=\" border: 1px solid #dedede;\"  ></iframe></span>";
		}
	} else {
		if ($_arg_3 == "color") {
			$_var_5 = "<input type = \"text\" id=\"" . $_arg_0 . "_v\" class=\"left txt\" size=\"6\" name=\"" . $_arg_1 . "\"  value=\"" . $_arg_2 . "\" onchange=\"updatecolorpreview('" . $_arg_0 . "')\"><input type=\"button\" style=\"background-color:" . $_arg_2 . "\" id=\"" . $_arg_0 . "\"  class=\"colorwd\" onclick=\"" . $_arg_0 . "_frame.location='plugin.php?id=wq_channel&mod=getcolor&ac=" . $_arg_0 . "|" . $_arg_0 . "_v';showMenu({'ctrlid':'" . $_arg_0 . "'})\" /><span id=\"" . $_arg_0 . "_menu\" style=\"display: none\"><iframe name=\"" . $_arg_0 . "_frame\" src=\"\" frameborder=\"0\" width=\"196\" height=\"220\" scrolling=\"no\"></iframe></span>";
			if ($_arg_4) {
				$_var_5 = "<input type = \"text\" id=\"" . $_arg_0 . "' + addrowkey + '_v\" class=\"left txt\" size=\"6\" name=\"" . $_arg_1 . "['+addrowkey+']\" value=\"" . $_arg_2 . "\" onchange=\"updatecolorpreview(\\'" . $_arg_0 . "'+addrowkey+'\\')\"><input type=\"button\" id=\\'" . $_arg_0 . "'+addrowkey+'\\'  class=\"colorwd\" onclick=\"" . $_arg_0 . "'+addrowkey+'_frame.location=\\'plugin.php?id=wq_channel&mod=getcolor&ac=" . $_arg_0 . "'+addrowkey+'|" . $_arg_0 . "'+addrowkey+'_v\\';showMenu({\\'ctrlid\\':\\'" . $_arg_0 . "'+addrowkey+'\\'})\" /><span id=\"" . $_arg_0 . "'+addrowkey+'_menu\" style=\"display: none\"><iframe name=\"" . $_arg_0 . "'+addrowkey+'_frame\" src=\"\" frameborder=\"0\" width=\"196\" height=\"220\" scrolling=\"no\"></iframe></span>";
			}
		}
	}
	return $_var_5;
}
function wq_channel_qrcode_generate($_arg_0)
{
	global $_G;
	$_var_2 = $_G["siteurl"] . "plugin.php?id=wq_channel&mod=index&pageid=" . $_arg_0;
	$_var_3 = DISCUZ_ROOT . "./data/cache/wq_channel/";
	$_var_4 = "pageid_" . $_arg_0;
	$_var_5 = $_var_3 . $_var_4 . ".png";
	if (!file_exists($_var_5) || !filesize($_var_5)) {
		require_once DISCUZ_ROOT . "source/plugin/wq_channel/class/qrcode.class.php";
		dmkdir($_var_3);
		QRcode::png($_var_2, $_var_5, QR_ECLEVEL_Q, 4);
	}
	return "data/cache/wq_channel/" . $_var_4 . ".png";
}
function wq_channel_get_img_url_num($_arg_0)
{
	global $_G;
	foreach ($_arg_0 as $_var_2) {
		$_var_3[] = $_var_2["id"];
	}
	$_var_3 = array_unique($_var_3);
	$_var_4 = DB::fetch_all("SELECT tid,pid,message FROM " . DB::table("forum_post") . " WHERE tid IN(%n) AND first=1 ", array($_var_3));
	foreach ($_var_4 as $_var_5) {
		$_var_6[$_var_5["tid"]] = $_var_5["pid"];
		$_var_7[$_var_5["tid"]] = $_var_5["message"];
	}
	$_var_8 = $_var_9 = array();
	foreach ($_var_6 as $_var_10 => $_var_11) {
		$_var_9 = C::t("forum_attachment_n")->count_image_by_id("pid:" . $_var_11, "pid", $_var_11);
		if ($_var_9 > 0) {
			$_var_12 = DB::fetch_all("SELECT * FROM %t WHERE %i AND isimage IN (1, -1) ORDER BY width DESC LIMIT 3", array(wq_channel_get_tableid("pid:" . $_var_11), DB::field("pid", $_var_11)));
			$_var_13 = array();
			$_var_14 = 220;
			$_var_15 = 99999;
			foreach ($_var_12 as $_var_16 => $_var_17) {
				$_var_13[] = sprintf("%sforum.php?mod=image&aid=%s&size=%sx%s&key=%s", $_G["siteurl"], $_var_17["aid"], $_var_14, $_var_15, dsign($_var_17["aid"] . "|" . $_var_14 . "|" . $_var_15));
			}
			$_var_8[$_var_10] = $_var_13;
		}
		preg_match_all("/\\[img(.*)](.*)\\[\\/img\\]/ismUe", $_var_7[$_var_10], $_var_18, PREG_SET_ORDER);
		$_var_19 = 0;
		if (is_array($_var_18) && !empty($_var_18)) {
			$_var_19 = count($_var_18);
		}
		$_var_20[$_var_10] = $_var_9 + $_var_19;
		if ($_var_9 < 3) {
			$_var_21 = array();
			if ($_var_19 > 0) {
				foreach ($_var_18 as $_var_16 => $_var_22) {
					if ($_var_9 < 3) {
						$_var_21[] = $_var_22[2];
						$_var_9 = $_var_9 + 1;
					}
				}
				if (!empty($_var_8[$_var_10])) {
					$_var_8[$_var_10] = array_merge($_var_8[$_var_10], $_var_21);
				} else {
					$_var_8[$_var_10] = $_var_21;
				}
			}
		}
	}
	return array($_var_20, $_var_8);
}
function wq_channel_get_tableid($_arg_0)
{
	if (!is_numeric($_arg_0)) {
		list($_var_1, $_var_2) = explode(":", $_arg_0);
		$_var_3 = dintval($_var_2);
		$_arg_0 = DB::result_first("SELECT tableid FROM %t WHERE pid=%d LIMIT 1", array("forum_attachment", $_var_3));
		if ($_arg_0 >= 0 && $_arg_0 < 10) {
			$_arg_0 = intval($_arg_0);
		} else {
			$_arg_0 = "127";
		}
	}
	if ($_arg_0 >= 0 && $_arg_0 < 10) {
		return "forum_attachment_" . intval($_arg_0);
	}
	if ($_arg_0 == 127) {
		return "forum_attachment_unused";
	}
}
function wq_channel_get_html($_arg_0)
{
	if ($_arg_0["picnum"] >= 3) {
		$_var_1 = $_arg_0["picnum"] > 3 ? "<span class=\"wqlisttu2\"><i class=\"wqchannel wqchannel-xiangce\"></i>" . $_arg_0["picnum"] . "</span>" : '';
		$_var_2 = "<li>\r\n            <a href=\"" . $_arg_0["url"] . "\"class=\"wqblock\" " . $_arg_0["target"] . ">\r\n                <div class=\"wqlist_maxhidden50\">\r\n                    <h3 class=\"wqtitle_list\">" . $_arg_0["title"] . "</h3>\r\n                </div>\r\n                <div class=\"list_pane3\">\r\n                    <span class=\"wq_img wq-lazyload-container\"><img src=\"./source/plugin/wq_channel/static/images/wq_dian.jpg\" data-src=\" " . $_arg_0["pic"][0] . "\" class=\"wq-lazyload\"></span>\r\n                    <span class=\"wq_img wq-lazyload-container\"><img src=\"./source/plugin/wq_channel/static/images/wq_dian.jpg\" data-src=\" " . $_arg_0["pic"][1] . "\" class=\"wq-lazyload\"></span>\r\n                    <span class=\"wq_img wq-lazyload-container\"><img src=\"./source/plugin/wq_channel/static/images/wq_dian.jpg\" data-src=\" " . $_arg_0["pic"][2] . "\" class=\"wq-lazyload\"></span>" . $_var_1 . "\r\n                </div>\r\n                <p class=\"list_info\">\r\n                    " . $_arg_0["author"] . "\r\n                    <span class=\"y\"><i class=\"wqchannel wqchannel-tubiao05 wq_f12\"></i>" . $_arg_0["replies"] . "</span>\r\n                    <span class=\"y wqm_right10\"><i class=\"wqchannel wqchannel-yulan\"></i>" . $_arg_0["views"] . "</span>\r\n                </p>\r\n            </a>\r\n        </li>  ";
	} else {
		if ($_arg_0["picnum"] > 0 && $_arg_0["picnum"] <= 2) {
			$_var_2 = "<li>\r\n            <a href=\"" . $_arg_0["url"] . "\"class=\"wqblock\" " . $_arg_0["target"] . ">\r\n                <div class=\"wqlist1 wq-lazyload-container\">\r\n                    <img src=\"./source/plugin/wq_channel/static/images/wq_dian.jpg\" data-src=\" " . $_arg_0["pic"][0] . "\" class=\"wq-lazyload\">\r\n                </div>\r\n                <div class=\"wqlist_hidden50\">\r\n                    <h3 class=\"wqtitle_list\">" . $_arg_0["title"] . "</h3>\r\n                </div>\r\n                <p class=\"list_info\">\r\n                    " . $_arg_0["author"] . "\r\n                    <span class=\"y\"><i class=\"wqchannel wqchannel-tubiao05 wq_f12\"></i>" . $_arg_0["replies"] . "</span>\r\n                    <span class=\"y wqm_right10\"><i class=\"wqchannel wqchannel-yulan wqyulan\"></i>" . $_arg_0["views"] . "</span>\r\n                </p>\r\n            </a>\r\n        </li>";
		} else {
			$_var_2 = "<li>\r\n            <a href=\"" . $_arg_0["url"] . "\"class=\"wqblock\" " . $_arg_0["target"] . ">\r\n                <div class=\"wqlist_maxhidden50\">\r\n                    <h3 class=\"wqtitle_list\">" . $_arg_0["title"] . "</h3>\r\n                </div>\r\n                <p class=\"list_info\">\r\n                    " . $_arg_0["author"] . "\r\n                    <span class=\"y\"><i class=\"wqchannel wqchannel-tubiao05 wq_f12\"></i>" . $_arg_0["replies"] . "</span>\r\n                    <span class=\"y wqm_right10\"><i class=\"wqchannel wqchannel-yulan\"></i>" . $_arg_0["views"] . "</span>\r\n                </p>\r\n            </a>\r\n        </li>";
		}
	}
	return $_var_2;
}
function wq_channel_ajax_get_data($_arg_0, $_arg_1, $_arg_2 = '', $_arg_3 = '', $_arg_4 = array(), $_arg_5 = array(), $_arg_6 = array(), $_arg_7 = array())
{
	global $_G;
	foreach ($_arg_0 as $_var_9 => $_var_10) {
		$_var_10 = $_var_10["fields"] + $_var_10;
		$_var_10["picwidth"] = !empty($_arg_1["picwidth"]) ? intval($_arg_1["picwidth"]) : "auto";
		$_var_10["picheight"] = !empty($_arg_1["picheight"]) ? intval($_arg_1["picheight"]) : "auto";
		$_var_10["target"] = !empty($_arg_1["target"]) ? " target=\"_" . $_arg_1["target"] . "\"" : '';
		$_var_10["dateformat"] = !empty($_arg_1["dateformat"]) ? $_arg_1["dateformat"] : "Y-m-d";
		$_var_10["lastpost"] = date($_var_10["dateformat"], $_var_10["lastpost"]);
		$_var_10["dateline"] = date($_var_10["dateformat"], $_var_10["dateline"]);
		if ($_arg_2 == "mixed") {
			$_var_10["picnum"] = $_arg_6[$_var_10["id"]];
			$_var_10["pic"] = array();
			if ($_var_10["picnum"] > 0) {
				$_var_10["pic"] = $_arg_7[$_var_10["id"]];
			}
			$_var_11 = $_var_11 . wq_channel_get_html($_var_10);
		} else {
			if ($_var_10["picflag"] == "1") {
				$_var_10["pic"] = $_G["setting"]["attachurl"] . $_var_10["pic"];
			} else {
				if ($_var_10["picflag"] == "2") {
					$_var_10["pic"] = $_G["setting"]["ftp"]["attachurl"] . $_var_10["pic"];
				}
			}
			$_var_12 = array();
			foreach ($_arg_5[1] as $_var_13 => $_var_14) {
				$_var_12[] = $_var_10[$_var_14];
			}
			$_var_11 = $_var_11 . str_replace($_arg_4, $_var_12, $_arg_3);
		}
	}
	return $_var_11;
}
function wq_channel_set_setting_defaultmobileindex($_arg_0 = '')
{
	global $_G;
	C::t("common_setting")->update("defaultmobileindex", $_arg_0);
	updatecache("setting");
	$_var_2["defaultmobileindex"] = $_G["setting"]["defaultmobileindex"];
	writetocache("wqchannel", getcachevars(array("wqdomain" => $_var_2)));
}
function wq_channel_is_wq_touch($_arg_0 = true, $_arg_1 = true)
{
	global $_G;
	$_var_3 = false;
	$_var_4 = $_G["setting"]["styleid2"];
	loadcache("style_" . $_var_4);
	$_var_5 = $_G["cache"]["style_" . $_var_4];
	if ($_var_5["tpldir"] == "./template/wq_touch" && $_arg_0) {
		$_var_3 = true;
	}
	if ($_var_5["tpldir"] == "./template/wq_app" && $_arg_1) {
		$_var_3 = true;
	}
	return $_var_3;
}
function wq_channel_set_footer_menulist($_arg_0 = "wq_touch_setting", $_arg_1 = "wq_touch_setting_menumanage", $_arg_2 = "wq_touch_footer_menulist")
{
	$_var_3 = C::t("#" . $_arg_0 . "#" . $_arg_1 . '')->fetch_all_by_search();
	foreach ($_var_3 as $_var_4 => $_var_5) {
		$_var_6[$_var_5["id"]] = $_var_5;
	}
	savecache($_arg_2, $_var_6);
	return $_var_6;
}
function wq_channel_insert_footer_menu($_arg_0 = "wq_touch_setting", $_arg_1 = "wq_touch_setting_menumanage", $_arg_2 = "wq_touch_footer_menulist")
{
	if ($_arg_0 == "wq_touch_setting") {
		$_var_3 = array(array("menuname" => "&#x9996;&#x9875;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=1", "menuicon" => "wqtopic wqtopic-index_2", "type" => "1", "dateline" => time()), array("menuname" => "&#x793E;&#x533A;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=2", "menuicon" => "wqtopic wqtopic-footer_bk1", "type" => "1", "dateline" => time()), array("menuname" => "&#x53D1;&#x73B0;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=5", "menuicon" => "wqtopic wqtopic-weizhi2", "type" => "1", "dateline" => time()));
	} else {
		$_var_3 = array(array("menuname" => "&#x9996;&#x9875;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=1", "type" => "1", "notmenuicon" => "wqiconfont2 wqicon2-shouye", "menuicon" => "wqiconfont2 wqicon2-shouye2"), array("menuname" => "&#x793E;&#x533A;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=2", "type" => "1", "notmenuicon" => "wqiconfont2 wqicon2-bankuai", "menuicon" => "wqiconfont2 wqicon2-bankuai2"), array("menuname" => "&#x53D1;&#x73B0;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=5", "type" => "1", "notmenuicon" => "wqiconfont2 wqicon2-faxian", "menuicon" => "wqiconfont2 wqicon2-faxian2"));
	}
	foreach ($_var_3 as $_var_4 => $_var_5) {
		if ($_arg_0 == "wq_app_setting") {
			$_var_5["menutype"] = 1;
		}
		C::t("#" . $_arg_0 . "#" . $_arg_1 . '')->insert($_var_5);
	}
	wq_channel_set_footer_menulist($_arg_0, $_arg_1, $_arg_2);
}
function wq_channel_wechat_api($_arg_0, $_arg_1, $_arg_2 = '', $_arg_3 = array(), $_arg_4 = array())
{
	global $_G;
	foreach ($_arg_0 as $_var_6 => $_var_7) {
		$_var_7 = $_var_7["fields"] + $_var_7;
		$_var_7["title"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_7["title"]));
		$_var_7["summary"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_7["summary"]));
		if ($_var_7["idtype"] == "tid") {
			$_var_7["url"] = "article/article_details/article_details?tid=" . $_var_7["id"];
			$_var_8 = array();
			parse_str(substr($_var_7["forumurl"], strpos($_var_7["forumurl"], "?") + 1), $_var_8);
			$_var_7["forumurl"] = "article/article_list/article_list?fid=" . $_var_8["fid"];
			$_var_9 = C::t("forum_thread")->fetch($_var_7["id"]);
			if (in_array($_var_9["special"], array(1, 2, 3, 4, 5))) {
				$_var_7["summary"] = '';
			}
		}
		if ($_var_7["idtype"] == "aid") {
			$_var_7["url"] = "portal/view/view?aid=" . $_var_7["id"];
			$_var_8 = array();
			parse_str(substr($_var_7["forumurl"], strpos($_var_7["forumurl"], "?") + 1), $_var_8);
			$_var_7["forumurl"] = "page/portal/list/list?catid=" . $_var_8["catid"];
		}
		$_var_7["forumname"] = isset($_var_7["forumname"]) ? $_var_7["forumname"] : (isset($_var_7["groupname"]) ? $_var_7["groupname"] : $_var_7["catname"]);
		$_var_7["views"] = isset($_var_7["views"]) ? intval($_var_7["views"]) : intval($_var_7["viewnum"]);
		$_var_7["replies"] = isset($_var_7["replies"]) ? intval($_var_7["replies"]) : intval($_var_10["commentnum"]);
		$_var_7["author"] = isset($_var_7["author"]) ? $_var_7["author"] : $_var_7["username"];
		$_var_7["authorid"] = isset($_var_7["authorid"]) ? intval($_var_7["authorid"]) : intval($_var_7["uid"]);
		$_var_7["picwidth"] = !empty($_arg_1["picwidth"]) ? intval($_arg_1["picwidth"]) : "auto";
		$_var_7["picheight"] = !empty($_arg_1["picheight"]) ? intval($_arg_1["picheight"]) : "auto";
		$_var_7["target"] = !empty($_arg_1["target"]) ? " target=\"_" . $_arg_1["target"] . "\"" : '';
		$_var_7["dateformat"] = !empty($_arg_1["dateformat"]) ? $_arg_1["dateformat"] : "Y-m-d";
		$_var_7["lastpost"] = date($_var_7["dateformat"], $_var_7["lastpost"]);
		$_var_7["dateline"] = date($_var_7["dateformat"], $_var_7["dateline"]);
		$_var_7["picnum"] = 1;
		if ($_var_7["picflag"] == "1") {
			$_var_7["pic"] = array($_G["siteurl"] . $_G["setting"]["attachurl"] . $_var_7["pic"]);
		} else {
			if ($_var_7["picflag"] == "2") {
				$_var_7["pic"] = array($_G["setting"]["ftp"]["attachurl"] . $_var_7["pic"]);
			} else {
				$_var_7["pic"] = array($_G["siteurl"] . $_var_7["pic"]);
			}
		}
		if ($_arg_2 == "mixed") {
			$_var_7["picnum"] = $_arg_3[$_var_7["id"]];
			$_var_7["pic"] = array();
			if ($_var_7["picnum"] > 0) {
				$_var_7["pic"] = $_arg_4[$_var_7["id"]];
			}
		}
		unset($_var_7["fields"]);
		$_var_11[$_var_6] = $_var_7;
	}
	return $_var_11;
}
function wq_channel_get_pages_url($_arg_0, $_arg_1)
{
	global $_G;
	include_once libfile("function/home");
	$_var_3 = isset($_POST["foldername"]) ? getstr(trim($_POST["foldername"]), 50) : $_arg_0["foldername"];
	$_var_4 = isset($_POST["pagename"]) ? getstr(trim($_POST["pagename"]), 30) : $_arg_0["pagename"];
	$_arg_1 = !empty($_var_4) ? $_var_4 : $_arg_1;
	$_var_5 = "plugin.php?id=wq_channel&mod=index&pageid=" . $_arg_1;
	$_var_5 = str_replace("&amp;", "&", $_var_5);
	$_var_6 = dunserialize($_G["setting"]["wq_rewrite_setting"]);
	if ($_var_6 && $_var_6["channel_index"]["available"] == 1) {
		$_var_5 = str_replace("{pageid}", $_arg_1, $_var_6["channel_index"]["rule"]);
	}
	if (!empty($_var_3)) {
		$_var_5 = $_var_3 . "/";
	}
	return $_var_5;
}
function wq_channel_image_pre($_arg_0)
{
	global $_G;
	if (!$_arg_0) {
		return '';
	}
	$_var_2 = strpos($_arg_0, "http:") !== false || strpos($_arg_0, "https:") !== false ? '' : $_G["siteurl"];
	return $_var_2 . $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}