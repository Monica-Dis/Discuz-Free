<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_common.php 2015-12-2 20:00:01Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!function_exists('wq_channel_delete_pages')) {

	function wq_channel_delete_pages($dels) {
		global $_G;

		if(empty($dels)) {
			return false;
		}
		loadcache('wq_channel_create_pages');
		$category = $_G['cache']['wq_channel_create_pages'];
		$targettplname = $foldernames = array();

		foreach((array) $dels as $key => $value) {
			$targettplname[] = 'channel_index_' . $value;
			$foldernames[] = $category[$value]['foldername'];
		}
		C::t('common_diy_data')->delete($targettplname, null);

		require_once libfile('class/blockpermission');
		$tplpermission = & template_permission::instance();
		$templates = array();
		$tplpermission->delete_allperm_by_tplname($targettplname);

		C::t('common_template_block')->delete_by_targettplname($targettplname);
		C::t("#wq_channel#wq_channel_pages")->delete($dels);

		foreach($foldernames as $foldername) {
			if(!empty($foldername)) {
				wq_channel_del_secondary_directory($foldername);
			}
		}

		wq_channel_save_pages();

		include_once libfile('function/block');
		block_clear();

		include_once libfile('function/cache');
		updatecache('diytemplatename');
	}

}
//From: Dism_taobao-com
?>