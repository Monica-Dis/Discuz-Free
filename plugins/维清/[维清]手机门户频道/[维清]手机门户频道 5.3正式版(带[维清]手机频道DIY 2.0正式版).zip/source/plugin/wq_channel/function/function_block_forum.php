<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_channel.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function getdata($style, $parameter) {
	global $_G;
	loadcache('forums');

	$parameter = daddslashes($parameter);
	$tids = !empty($parameter['tids']) ? explode(',', $parameter['tids']) : array();
	$uids = !empty($parameter['uids']) ? explode(',', $parameter['uids']) : array();
	$startrow = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
	$items = !empty($parameter['items']) ? intval($parameter['items']) : 10;
	$digest = isset($parameter['digest']) ? $parameter['digest'] : 0;
	$stick = isset($parameter['stick']) ? $parameter['stick'] : 0;
	$orderby = isset($parameter['orderby']) ? (in_array($parameter['orderby'], array('lastpost', 'dateline', 'replies', 'views', 'heats', 'recommends')) ? $parameter['orderby'] : 'lastpost') : 'lastpost';
	$lastpost = isset($parameter['lastpost']) ? intval($parameter['lastpost']) : 0;
	$postdateline = isset($parameter['postdateline']) ? intval($parameter['postdateline']) : 0;
	$titlelength = !empty($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
	$summarylength = !empty($parameter['summarylength']) ? intval($parameter['summarylength']) : 80;
	$recommend = !empty($parameter['recommend']) ? 1 : 0;
	$keyword = !empty($parameter['keyword']) ? $parameter['keyword'] : '';
	$tagkeyword = !empty($parameter['tagkeyword']) ? $parameter['tagkeyword'] : '';
	$typeids = !empty($parameter['typeids']) ? explode(',', $parameter['typeids']) : array();
	$sortids = !empty($parameter['sortids']) && !in_array(0, (array) $parameter['sortids']) ? $parameter['sortids'] : array();
	$special = !empty($parameter['special']) ? $parameter['special'] : array();
	$rewardstatus = !empty($parameter['rewardstatus']) ? intval($parameter['rewardstatus']) : 0;
	$picrequired = !empty($parameter['picrequired']) ? 1 : 0;
	$viewmod = !empty($parameter['viewmod']) ? 1 : 0;
	$highlight = !empty($parameter['highlight']) ? 1 : 0;

	$fids = array();
	if(!empty($parameter['fids'])) {
		if(isset($parameter['fids'][0]) && $parameter['fids'][0] == '0') {
			unset($parameter['fids'][0]);
		}
		$fids = $parameter['fids'];
	}

	$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();

	require_once libfile('function/post');
	require_once libfile('function/search');

	$datalist = $list = $listtids = $pictids = $pics = $threadtids = $threadtypeids = $tagids = array();
	$keyword = $keyword ? searchkey($keyword, "t.subject LIKE '%{text}%'") : '';
	if($tagkeyword) {
		if(!($tagids = DB::fetch_all('SELECT tagid FROM ' . DB::table('common_tag') . ' WHERE 1' . searchkey($tagkeyword, "tagname LIKE '%{text}%'"), '', 'tagid'))) {
			return array('data' => '');
		}
	}

	$threadsorts = $threadtypes = array();
	$querytmp = DB::query("SELECT typeid, name, special FROM " . DB::table('forum_threadtype') . " WHERE special>'0'");
	while($value = DB::fetch($querytmp)) {
		$threadsorts[$value['typeid']] = $value;
	}
	$querytmp = DB::query("SELECT * FROM " . DB::table('forum_threadclass'));
	foreach(C::t('forum_threadclass')->range() as $value) {
		$threadtypes[$value['typeid']] = $value;
	}

	$sql = ($fids ? ' AND t.fid IN (' . dimplode($fids) . ')' : '')
		. ($tids ? ' AND t.tid IN (' . dimplode($tids) . ')' : '')
		. ($uids ? ' AND t.authorid IN (' . dimplode($uids) . ')' : '')
		. ($typeids ? ' AND t.typeid IN (' . dimplode($typeids) . ')' : '')
		. ($sortids ? ' AND t.sortid IN (' . dimplode($sortids) . ')' : '')
		. ($special ? ' AND t.special IN (' . dimplode($special) . ')' : '')
		. ((in_array(3, $special) && $rewardstatus) ? ($rewardstatus == 1 ? ' AND t.price < 0' : ' AND t.price > 0') : '')
		. ($digest ? ' AND t.digest IN (' . dimplode($digest) . ')' : '')
		. ($stick ? ' AND t.displayorder IN (' . dimplode($stick) . ')' : '')
		. ($bannedids ? ' AND t.tid NOT IN (' . dimplode($bannedids) . ')' : '')
		. $keyword
		. " AND t.isgroup='0'";

	if($postdateline) {
		$time = TIMESTAMP - $postdateline;
		$sql .= " AND t.dateline >= '$time'";
	}
	if($lastpost) {
		$time = TIMESTAMP - $lastpost;
		$sql .= " AND t.lastpost >= '$time'";
	}
	if($orderby == 'heats') {
		$sql .= " AND t.heats>'0'";
	}
	$sqlfrom = $sqlfield = $joinmethodpic = '';

	if($picrequired) {
		$joinmethodpic = 'INNER';
	} else if($style['getpic']) {
		$joinmethodpic = 'LEFT';
	}
	if($joinmethodpic) {
		$sqlfrom .= " $joinmethodpic JOIN `" . DB::table('forum_threadimage') . "` ti ON t.tid=ti.tid";
		$sqlfield = ', ti.attachment as attachmenturl, ti.remote';
	}

	$joinmethod = empty($tids) ? 'INNER' : 'LEFT';
	if($recommend) {
		$sqlfrom .= " $joinmethod JOIN `" . DB::table('forum_forumrecommend') . "` fc ON fc.tid=t.tid";
	}

	if($tagids) {
		$sqlfrom .= " $joinmethod JOIN `" . DB::table('common_tagitem') . "` tim ON tim.tagid IN (" . dimplode(array_keys($tagids)) . ") AND tim.itemid=t.tid AND tim.idtype='tid' ";
	}

	$maxwhere = '';
	if(!$tids && !$fids && !$digest && !$stick && $_G['setting']['blockmaxaggregationitem']) {
		$maxwhere = ($maxid = getmaxid() - $_G['setting']['blockmaxaggregationitem']) > 0 ? 't.tid > ' . $maxid . ' AND ' : '';
	}

	$query = DB::query("SELECT DISTINCT t.*$sqlfield
			FROM `" . DB::table('forum_thread') . "` t
			$sqlfrom WHERE {$maxwhere}t.readperm='0'
			$sql
			AND t.displayorder>='0'
			ORDER BY t.$orderby DESC
			LIMIT $startrow,$items;"
	);

	while($data = DB::fetch($query)) {
		$_G['block_thread'][$data['tid']] = $data;
		if($style['getsummary']) {
			$threadtids[$data['posttableid']][] = $data['tid'];
		}
		$listtids[$data['tid']] = $data['tid'];
		$list[$data['tid']] = array(
			'id' => $data['tid'],
			'idtype' => 'tid',
			'title' => cutstr(str_replace('\\\'', '&#39;', addslashes($data['subject'])), $titlelength, ''),
			'url' => 'forum.php?mod=viewthread&tid=' . $data['tid'] . ($viewmod ? '&from=portal' : ''),
			'pic' => $data['attachmenturl'] ? 'forum/' . $data['attachmenturl'] : STATICURL . 'image/common/nophoto.gif',
			'picflag' => $data['attachmenturl'] ? ($data['remote'] ? '2' : '1') : '0',
			'fields' => array(
				'fulltitle' => str_replace('\\\'', '&#39;', addslashes($data['subject'])),
				'threads' => $data['threads'],
				'author' => $data['author'] ? $data['author'] : $_G['setting']['anonymoustext'],
				'authorid' => $data['author'] ? $data['authorid'] : 0,
				'avatar' => avatar(($data['author'] ? $data['authorid'] : 0), 'small', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_middle' => avatar(($data['author'] ? $data['authorid'] : 0), 'middle', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_big' => avatar(($data['author'] ? $data['authorid'] : 0), 'big', true, false, false, $_G['setting']['ucenterurl']),
				'posts' => $data['posts'],
				'todayposts' => $data['todayposts'],
				'lastpost' => $data['lastpost'],
				'dateline' => $data['dateline'],
				'replies' => $data['replies'],
				'forumurl' => 'forum.php?mod=forumdisplay&fid=' . $data['fid'],
				'forumname' => $_G['cache']['forums'][$data['fid']]['name'],
				'typename' => $threadtypes[$data['typeid']]['name'],
				'typeicon' => $threadtypes[$data['typeid']]['icon'],
				'typeurl' => 'forum.php?mod=forumdisplay&fid=' . $data['fid'] . '&filter=typeid&typeid=' . $data['typeid'],
				'sortname' => $threadsorts[$data['sortid']]['name'],
				'sorturl' => 'forum.php?mod=forumdisplay&fid=' . $data['fid'] . '&filter=sortid&sortid=' . $data['sortid'],
				'views' => $data['views'],
				'heats' => $data['heats'],
				'recommends' => $data['recommends'],
				'hourviews' => $data['views'],
				'todayviews' => $data['views'],
				'weekviews' => $data['views'],
				'monthviews' => $data['views']
			)
		);
		if($highlight && $data['highlight']) {
			$list[$data['tid']]['fields']['showstyle'] = getthreadstyle($data['highlight']);
		}
	}

	if($listtids) {
		$threads = getthread($threadtids, $summarylength);
		if($threads) {
			foreach($threads as $tid => $var) {
				$list[$tid]['summary'] = $var;
			}
		}

		foreach($listtids as $key => $value) {
			$datalist[] = $list[$value];
		}
	}

	return $datalist;
}
//From: Dism_taobao-com
?>