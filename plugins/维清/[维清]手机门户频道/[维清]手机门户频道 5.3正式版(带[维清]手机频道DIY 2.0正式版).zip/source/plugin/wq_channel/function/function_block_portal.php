<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_channel.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function getdata($style, $parameter) {
	global $_G;
	require_once libfile('function/portal');

	$parameter = daddslashes($parameter);
	$aids = !empty($parameter['aids']) ? explode(',', $parameter['aids']) : array();
	$uids = !empty($parameter['uids']) ? explode(',', $parameter['uids']) : array();
	$keyword = !empty($parameter['keyword']) ? $parameter['keyword'] : '';
	$tag = !empty($parameter['tag']) ? $parameter['tag'] : array();
	$starttime = !empty($parameter['starttime']) ? strtotime($parameter['starttime']) : 0;
	$endtime = !empty($parameter['endtime']) ? strtotime($parameter['endtime']) : 0;
	$publishdateline = isset($parameter['publishdateline']) ? intval($parameter['publishdateline']) : 0;
	$startrow = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
	$items = isset($parameter['items']) ? intval($parameter['items']) : 10;
	$titlelength = isset($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
	$summarylength = isset($parameter['summarylength']) ? intval($parameter['summarylength']) : 80;
	$clickarr = array('click1', 'click2', 'click3', 'click4', 'click5', 'click6', 'click7', 'click8');
	$orderby = in_array($parameter['orderby'], array_merge(array('dateline', 'viewnum', 'commentnum'), $clickarr)) ? $parameter['orderby'] : 'dateline';
	$catid = array();
	if(!empty($parameter['catid'])) {
		if($parameter['catid'][0] == '0') {
			unset($parameter['catid'][0]);
		}
		$catid = $parameter['catid'];
	}

	$picrequired = !empty($parameter['picrequired']) ? 1 : 0;

	$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();

	loadcache('portalcategory');

	$list = array();
	$wheres = array();

	if($aids) {
		$wheres[] = 'at.aid IN (' . dimplode($aids) . ')';
	}
	if($uids) {
		$wheres[] = 'at.uid IN (' . dimplode($uids) . ')';
	}
	if($catid) {
		include_once libfile('function/portalcp');
		$childids = array();
		foreach($catid as $id) {
			if($_G['cache']['portalcategory'][$id]['disallowpublish']) {
				$childids = array_merge($childids, category_get_childids('portal', $id));
			}
		}
		$catid = array_merge($catid, $childids);
		$catid = array_unique($catid);
		$wheres[] = 'at.catid IN (' . dimplode($catid) . ')';
	}
	if(!$aids && !$catid && $_G['setting']['blockmaxaggregationitem']) {
		if(($maxid = getmaxid() - $_G['setting']['blockmaxaggregationitem'] ) > 0) {
			$wheres[] = 'at.aid > ' . $maxid;
		}
	}
	if(empty($aids) && ($picrequired)) {
		$wheres[] = "at.pic != ''";
	}
	if($publishdateline) {
		$time = TIMESTAMP - $publishdateline;
		$wheres[] = "at.dateline >= '$time'";
	}
	if($starttime) {
		$wheres[] = "at.dateline >= '$starttime'";
	}
	if($endtime) {
		$wheres[] = "at.dateline <= '$endtime'";
	}
	if($bannedids) {
		$wheres[] = 'at.aid NOT IN (' . dimplode($bannedids) . ')';
	}
	$wheres[] = "at.status='0'";
	if(is_array($tag)) {
		$article_tags = array();
		foreach($tag as $k) {
			$article_tags[$k] = 1;
		}
		include_once libfile('function/portalcp');
		$v = article_make_tag($article_tags);
		if($v > 0) {
			$wheres[] = "(at.tag & $v) = $v";
		}
	}
	if($keyword) {
		require_once libfile('function/search');
		$keyword = searchkey($keyword, "at.title LIKE '%{text}%'");
	}

	$wheresql = $wheres ? implode(' AND ', $wheres) : '1';
	if(in_array($orderby, $clickarr)) {
		$orderby = "at.$orderby DESC,at.dateline DESC";
	} else {
		$orderby = ($orderby == 'dateline') ? 'at.dateline DESC ' : "ac.$orderby DESC";
	}
	$query = DB::query("SELECT at.*, ac.viewnum, ac.commentnum FROM " . DB::table('portal_article_title') . " at LEFT JOIN " . DB::table('portal_article_count') . " ac ON at.aid=ac.aid WHERE $wheresql$keyword ORDER BY $orderby LIMIT $startrow, $items");
	while($data = DB::fetch($query)) {
		if(empty($data['pic'])) {
			$data['pic'] = STATICURL . 'image/common/nophoto.gif';
			$data['picflag'] = '0';
		} else {
			$data['pic'] = $data['pic'];
			$data['picflag'] = $data['remote'] == '1' ? '2' : '1';
		}
		$list[] = array(
			'id' => $data['aid'],
			'idtype' => 'aid',
			'title' => cutstr($data['title'], $titlelength, ''),
			'url' => fetch_article_url($data),
			'pic' => $data['pic'],
			'picflag' => $data['picflag'],
			'summary' => cutstr(strip_tags($data['summary']), $summarylength, ''),
			'fields' => array(
				'uid' => $data['uid'],
				'username' => $data['username'],
				'avatar' => avatar($data['uid'], 'small', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_middle' => avatar($data['uid'], 'middle', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_big' => avatar($data['uid'], 'big', true, false, false, $_G['setting']['ucenterurl']),
				'fulltitle' => $data['title'],
				'dateline' => $data['dateline'],
				'caturl' => $_G['cache']['portalcategory'][$data['catid']]['caturl'],
				'catname' => $_G['cache']['portalcategory'][$data['catid']]['catname'],
				'articles' => $_G['cache']['portalcategory'][$data['catid']]['articles'],
				'viewnum' => intval($data['viewnum']),
				'commentnum' => intval($data['commentnum'])
			)
		);
	}
	return $list;
}

function getmaxid() {
	loadcache('databasemaxid');
	$data = getglobal('cache/databasemaxid');
	if(!isset($data['article']) || TIMESTAMP - $data['article']['dateline'] >= 86400) {
		$data['article']['dateline'] = TIMESTAMP;
		$data['article']['id'] = DB::result_first('SELECT MAX(aid) FROM ' . DB::table('portal_article_title'));
		savecache('databasemaxid', $data);
	}
	return $data['article']['id'];
}
//From: Dism_taobao-com
?>