<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_channel.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function getthread($tidarray, $messagelength = 80, $nospecial = false) {
	global $_G;
	if(!$tidarray) {
		return '';
	}
	$notexists = $messagearr = $returnarr = array();
	foreach($tidarray as $var) {
		foreach($var as $v) {
			if(empty($_G['block_thread'][$v])) {
				$notexists[] = $v;
			}
		}
	}
	if($notexists) {
		$query = DB::query("SELECT tid, fid, subject, posttableid, price, special FROM " . DB::table('forum_thread') . " WHERE tid IN (" . dimplode($notexists) . ")");
		while($result = DB::fetch($query)) {
			$_G['block_thread'][$result['tid']] = $result;
		}
	}
	foreach($tidarray as $key => $var) {
		if($key == 0) {
			$posttable = 'forum_post';
		} else {
			$posttable = "forum_post_{$key}";
		}
		$query = DB::query("SELECT tid, message FROM " . DB::table($posttable) . " WHERE tid IN  (" . dimplode($var) . ") AND first=1");
		while($result = DB::fetch($query)) {
			$messagearr[$result['tid']] = $result['message'];
		}
	}
	require_once libfile('function/post');
	require_once libfile('function/discuzcode');
	if($messagearr) {
		foreach($messagearr as $tid => $var) {
			$thread = $_G['block_thread'][$tid];
			if($nospecial) {
				$thread['special'] = 0;
			}
			if(in_array($thread['special'], array(1, 2, 3, 4, 5))) {
				$message = '';
			} else {
				$message = messagecutstr($var, $messagelength, '');
			}
			$returnarr[$tid] = $message;
		}
	}

	return $returnarr;
}

function getpic($tid) {
	global $_G;
	if(!$tid) {
		return '';
	}
	$pic = DB::fetch_first("SELECT attachment, remote FROM " . DB::table(getattachtablebytid($tid)) . " WHERE tid='$tid' AND isimage IN (1, -1) ORDER BY dateline DESC LIMIT 0,1");
	return $pic;
}

function getpics($tids) {
	$data = array();
	$tids = !empty($tids) && is_array($tids) ? $tids : array($tids);
	$tids = array_map('intval', $tids);
	$tids = array_filter($tids);
	if(!empty($tids)) {
		$query = DB::query('SELECT * FROM ' . DB::table('forum_threadimage') . ' WHERE tid IN (' . dimplode($tids) . ')');
		while($value = DB::fetch($query)) {
			$data[$value['tid']] = $value;
		}
	}
	return $data;
}

function getthreadstyle($highlight) {
	$rt = array();
	if($highlight) {
		$color = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
		$string = sprintf('%02d', $highlight);
		$stylestr = sprintf('%03b', $string[0]);
		$rt = array(
			'title_b' => $stylestr[0] ? '1' : '',
			'title_i' => $stylestr[1] ? '1' : '',
			'title_u' => $stylestr[2] ? '1' : '',
			'title_c' => $string[1] ? $color[$string[1]] : '',
		);
	}
	return $rt;
}

function getmaxid() {
	loadcache('databasemaxid');
	$data = getglobal('cache/databasemaxid');
	if(!isset($data['thread']) || TIMESTAMP - $data['thread']['dateline'] >= 86400) {
		$data['thread']['dateline'] = TIMESTAMP;
		$data['thread']['id'] = DB::result_first('SELECT MAX(tid) FROM ' . DB::table('forum_thread'));
		savecache('databasemaxid', $data);
	}
	return $data['thread']['id'];
}
//From: Dism_taobao-com
?>