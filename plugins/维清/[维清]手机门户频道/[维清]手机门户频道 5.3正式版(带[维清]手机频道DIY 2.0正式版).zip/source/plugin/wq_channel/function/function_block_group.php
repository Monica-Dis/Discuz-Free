<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_channel.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function getdata($style, $parameter) {
	global $_G;

	$parameter = daddslashes($parameter);

	loadcache('grouptype');
	$typeids = array();
	if(!empty($parameter['gtids'])) {
		if(isset($parameter['gtids'][0]) && $parameter['gtids'][0] == '0') {
			unset($parameter['gtids'][0]);
		}
		$typeids = $parameter['gtids'];
	}
	$tids = !empty($parameter['tids']) ? explode(',', $parameter['tids']) : array();
	$fids = !empty($parameter['fids']) ? explode(',', $parameter['fids']) : array();
	$uids = !empty($parameter['uids']) ? explode(',', $parameter['uids']) : array();
	$keyword = !empty($parameter['keyword']) ? $parameter['keyword'] : '';
	$startrow = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
	$items = isset($parameter['items']) ? intval($parameter['items']) : 10;
	$digest = isset($parameter['digest']) ? $parameter['digest'] : 0;
	$stick = isset($parameter['stick']) ? $parameter['stick'] : 0;
	$special = isset($parameter['special']) ? $parameter['special'] : array();
	$lastpost = isset($parameter['lastpost']) ? intval($parameter['lastpost']) : 0;
	$postdateline = isset($parameter['postdateline']) ? intval($parameter['postdateline']) : 0;
	$rewardstatus = isset($parameter['rewardstatus']) ? intval($parameter['rewardstatus']) : 0;
	$titlelength = !empty($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
	$summarylength = !empty($parameter['summarylength']) ? intval($parameter['summarylength']) : 80;
	$orderby = in_array($parameter['orderby'], array('dateline', 'replies', 'views', 'threads', 'heats', 'recommends')) ? $parameter['orderby'] : 'lastpost';
	$picrequired = !empty($parameter['picrequired']) ? 1 : 0;
	$gviewperm = isset($parameter['gviewperm']) ? intval($parameter['gviewperm']) : -1;
	$highlight = !empty($parameter['highlight']) ? 1 : 0;

	$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();

	$gviewwhere = $gviewperm == -1 ? '' : " AND ff.gviewperm='$gviewperm'";

	$groups = array();
	if(empty($fids) && $typeids) {
		$query = DB::query('SELECT f.fid, f.name, ff.description FROM ' . DB::table('forum_forum') . " f LEFT JOIN " . DB::table('forum_forumfield') . " ff ON f.fid = ff.fid WHERE f.fup IN (" . dimplode($typeids) . ") AND threads > 0$gviewwhere");
		while($value = DB::fetch($query)) {
			$groups[$value['fid']] = $value;
			$fids[] = intval($value['fid']);
		}
		if(empty($fids)) {
			return array('html' => '', 'data' => '');
		}
	}

	require_once libfile('function/post');
	require_once libfile('function/search');

	$datalist = $list = $listtids = $pictids = $pics = $threadtids = $threads = array();
	$threadtypeids = array();
	$keyword = $keyword ? searchkey($keyword, "t.subject LIKE '%{text}%'") : '';

	$sql = ($fids ? ' AND t.fid IN (' . dimplode($fids) . ')' : '')
		. ($tids ? ' AND t.tid IN (' . dimplode($tids) . ')' : '')
		. ($bannedids ? ' AND t.tid NOT IN (' . dimplode($bannedids) . ')' : '')
		. ($uids ? ' AND t.authorid IN (' . dimplode($uids) . ')' : '')
		. ($special ? ' AND t.special IN (' . dimplode($special) . ')' : '')
		. ((in_array(3, $special) && $rewardstatus) ? ($rewardstatus == 1 ? ' AND t.price < 0' : ' AND t.price > 0') : '')
		. ($digest ? ' AND t.digest IN (' . dimplode($digest) . ')' : '')
		. ($stick ? ' AND t.displayorder IN (' . dimplode($stick) . ')' : '')
		. $keyword;

	if(empty($fids)) {
		$sql .= " AND t.isgroup='1'";
		if($gviewwhere) {
			$sql .= $gviewwhere;
		}
	}
	if($postdateline) {
		$time = TIMESTAMP - $postdateline;
		$sql .= " AND t.dateline >= '$time'";
	}
	if($lastpost) {
		$time = TIMESTAMP - $lastpost;
		$sql .= " AND t.lastpost >= '$time'";
	}
	if($orderby == 'heats') {
		$sql .= " AND t.heats>'0'";
	}
	$sqlfrom = $sqlfield = $joinmethodpic = '';

	if($picrequired) {
		$joinmethodpic = 'INNER';
	} else if($style['getpic']) {
		$joinmethodpic = 'LEFT';
	}
	if($joinmethodpic) {
		$sqlfrom .= " $joinmethodpic JOIN `" . DB::table('forum_threadimage') . "` ti ON t.tid=ti.tid AND ti.tid>0";
		$sqlfield = ', ti.attachment as attachmenturl, ti.remote';
	}
	if(empty($fids)) {
		$sqlfield .= ', f.name groupname';
		$sqlfrom .= ' LEFT JOIN ' . DB::table('forum_forum') . ' f ON t.fid=f.fid LEFT JOIN ' . DB::table('forum_forumfield') . ' ff ON f.fid = ff.fid';
	}

	$query = DB::query("SELECT t.* $sqlfield
			FROM `" . DB::table('forum_thread') . "` t
			$sqlfrom WHERE t.readperm='0'
			$sql
			AND t.displayorder>='0'
			ORDER BY t.$orderby DESC
			LIMIT $startrow,$items;"
	);

	require_once libfile('block_thread', 'class/block/forum');

	while($data = DB::fetch($query)) {
		if($data['closed'] > 1 && $data['closed'] < $data['tid'])
			continue;
		$_G['block_thread'][$data['tid']] = $data;
		if($style['getsummary']) {
			$threadtids[$data['posttableid']][] = $data['tid'];
		}
		$listtids[] = $data['tid'];
		$list[$data['tid']] = array(
			'id' => $data['tid'],
			'idtype' => 'tid',
			'title' => cutstr(str_replace('\\\'', '&#39;', $data['subject']), $titlelength, ''),
			'url' => 'forum.php?mod=viewthread&tid=' . $data['tid'],
			'pic' => $data['attachmenturl'] ? 'forum/' . $data['attachmenturl'] : STATICURL . 'image/common/nophoto.gif',
			'picflag' => $data['attachmenturl'] ? ($data['remote'] ? '2' : '1') : '0',
			'fields' => array(
				'fulltitle' => str_replace('\\\'', '&#39;', addslashes($data['subject'])),
				'icon' => 'forum/' . $data['icon'],
				'author' => $data['author'] ? $data['author'] : $_G['setting']['anonymoustext'],
				'authorid' => $data['author'] ? $data['authorid'] : 0,
				'avatar' => avatar(($data['author'] ? $data['authorid'] : 0), 'small', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_middle' => avatar(($data['author'] ? $data['authorid'] : 0), 'middle', true, false, false, $_G['setting']['ucenterurl']),
				'avatar_big' => avatar(($data['author'] ? $data['authorid'] : 0), 'big', true, false, false, $_G['setting']['ucenterurl']),
				'dateline' => $data['dateline'],
				'lastpost' => $data['lastpost'],
				'posts' => $data['posts'],
				'todayposts' => $data['todayposts'],
				'replies' => $data['replies'],
				'views' => $data['views'],
				'heats' => $data['heats'],
				'recommends' => $data['recommends'],
				'groupname' => empty($groups[$data['fid']]['name']) ? $data['groupname'] : $groups[$data['fid']]['name'],
				'groupurl' => 'forum.php?mod=group&fid=' . $data['fid'],
			)
		);
		if($highlight && $data['highlight']) {
			$list[$data['tid']]['fields']['showstyle'] = getthreadstyle($data['highlight']);
		}
	}
	$threads = getthread($threadtids, $summarylength);
	if($threads) {
		foreach($threads as $tid => $var) {
			$list[$tid]['summary'] = $var;
		}
	}

	if($listtids) {
		foreach($listtids as $key => $value) {
			$datalist[] = $list[$value];
		}
	}

	return $datalist;
}
//From: Dism_taobao-com
?>