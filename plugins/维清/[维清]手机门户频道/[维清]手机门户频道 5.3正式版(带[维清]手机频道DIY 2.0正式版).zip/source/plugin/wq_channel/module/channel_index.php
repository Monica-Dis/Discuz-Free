<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: channel_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['diy'] == 'yes' && !$_G['group']['allowmanagetopic']) {
	$_GET['diy'] = '';
	showmessage($Plang['a5ec37ccfca90b08']);
}

if(is_numeric($_GET['pageid'])) {
	$pageid = intval($_GET['pageid']);

	if($pageid) {
		$channel = C::t("#wq_channel#wq_channel_pages")->fetch_by_pageid($pageid);
	}
} elseif(isset($_GET['pageid']) && !empty($_GET['pageid']) && !is_numeric($_GET['pageid'])) {
	$channel = C::t("#wq_channel#wq_channel_pages")->fetch_by_pagename($_GET['pageid']);

	$pageid = $channel['pageid'];
}

if(empty($channel)) {
	showmessage($Plang['09344575eb5fcf1b']);
}

if($channel['closed'] && !$_G['group']['allowmanagetopic'] && !($topic['uid'] == $_G['uid'] && $_G['group']['allowaddtopic'])) {
	showmessage($Plang['503c1b33cced6230']);
}

if($_GET['diy'] == 'yes' && $channel['uid'] != $_G['uid'] && !$_G['group']['allowmanagetopic']) {
	$_GET['diy'] = '';
	showmessage($Plang['a5ec37ccfca90b08']);
}

$pageid = $channel['channelid'] = intval($channel['pageid']);
if(!$_GET['diy'] && $_GET['ac']) {
	header("Location:{$_G['siteurl']}plugin.php?id=wq_channel&mod=index&pageid=" . $pageid);
}
C::t("#wq_channel#wq_channel_pages")->increase($pageid, array('viewnum' => 1));

$navtitle = $channel['title'];
$metadescription = empty($channel['description']) ? $channel['title'] : $channel['description'];
$metakeywords = empty($channel['keywords']) ? $channel['title'] : $channel['keywords'];
$color = !empty($channel['setcolor']) ? $channel['setcolor'] : $channel['color'];

if($_G['mobile']) {
	$_G['forcemobilemessage'] = true;
}

$channel_not_showheader = false;
$targettplname = 'channel_' . $mod . "_" . $pageid;
wq_channeldelete_cookies($targettplname);
$modulelist = wq_channel_wxapp_get_channelinfo_by_targettplname($targettplname, $channel);
$seturl = wq_channel_get_pages_url($channel, $pageid);
$referer = $_G['siteurl'];
if($_SERVER["HTTP_REFERER"]) {
	$referer = "javascript:history.back();";
}

if($_GET['ac'] != 'diy' || $_G['mobile']) {
	$_G['wqchannel'] = $channel;
	$htmlarr = wq_channel_get_html_by_targettplname($targettplname);
	$html = $htmlarr['html'];
	$spacecss = $htmlarr['spacecss'];
}

if($_GET['portal'] == '1') {
	$htmlarr['html'] == diconv($htmlarr['html'], CHARSET, "UTF-8");
	$htmlarr['setting'] = $setting['iconfont_url'];
	echo json_encode($htmlarr);
	exit();
}


if($_G['mobile']) {
	$wq_touch = wq_channel_is_wq_touch();

	include template("wq_channel:channel_index");
} else {
	$qrcode_url = wq_channel_qrcode_generate($pageid);

	include template('diy:channel_index:' . $pageid, 0, 'source/plugin/wq_channel/template');
}
//From: Dism_taobao-com
?>