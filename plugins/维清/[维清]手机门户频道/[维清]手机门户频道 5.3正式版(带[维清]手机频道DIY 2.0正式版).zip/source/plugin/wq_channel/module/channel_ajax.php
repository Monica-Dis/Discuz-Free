<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: channel_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = in_array($_GET['ac'], array('forum', 'group', 'portal')) ? $_GET['ac'] : '';
$bid = $_GET['bid'] ? intval($_GET['bid']) : '0';
$soucre = $_GET['soucre'] ? dhtmlspecialchars($_GET['soucre']) : '';
$op = in_array($_GET['op'], array('mixed')) ? dhtmlspecialchars($_GET['op']) : '';
$page = $_GET['page'] ? intval($_GET['page']) : 0;
$gethtml = '';
$imagescount = $images = $_search = $arr = array();

if(!$bid || !$ac) {
	$return['error'] = -1;
	if($soucre == 'wechat') {
		$return['html'] = $Plang['13418931fb040f85'];
		include template("wq_channel:channel_ajax");
		exit;
	} else {
		$return['html'] = wq_channel_diconv($Plang['13418931fb040f85'], CHARSET, 'UTF-8');
		echo json_encode($return);
		exit;
	}
}

include_once libfile('function/portalcp');
include_once libfile('function/block');

loadcache('blockclass');
block_get_batch($bid);
$block = $_G['block'][$bid];
$parameter = $block['param'];
$theclass = block_getclass($block['blockclass'], false);
$thestyle = !empty($block['styleid']) ? block_getstyle($block['styleid']) : dunserialize($block['blockstyle']);
$template = block_build_template($thestyle['template']);
$gethtml = substr($template, strpos($template, '[loop]') + 6, strpos($template, '[/loop]') - (strpos($template, '[loop]') + 6));
preg_match_all('/{(.*)}/iU', $gethtml, $arr);
$_search = $arr[0];

if($ac != 'portal') {
	include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_block_common.php';
}

if($ac == 'forum') {
	include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_block_forum.php';
}

if($ac == 'group') {
	include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_block_group.php';
}

if($ac == 'portal') {
	include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_block_portal.php';
}

if($page != 1) {
	$parameter['startrow'] = wq_channel_setcookie($bid, $parameter);
}

if($soucre == 'wechat') {
	$parameter['startrow'] = $_GET['startrow'] ? intval($_GET['startrow']) : 0;
}

$reuslts = $threadlist = getdata($thestyle, $parameter);

if(empty($reuslts)) {
	$return['error'] = -2;
	if($soucre == 'wechat') {
		$return['html'] = $Plang['13418931fb040f85'];
		include template("wq_channel:channel_ajax");
		exit;
	} else {
		$return['html'] = wq_channel_diconv($Plang['b3f7b411f8a25701'], CHARSET, 'UTF-8');
		echo json_encode($return);
		exit;
	}
}

if($op == 'mixed' && $ac != 'portal') {
	list($imagescount, $images) = wq_channel_get_img_url_num($threadlist);
}

if($soucre == 'wechat') {
	$return['error'] = 0;
	$return['html'] = wq_channel_wechat_api($reuslts, $block, $op, $imagescount, $images);

	include template("wq_channel:channel_ajax");
	exit;
}
$html = wq_channel_ajax_get_data($reuslts, $block, $op, $gethtml, $_search, $arr, $imagescount, $images);
$html = output_replace($html);

if($_G['mobile']) {
	$html = str_replace('target="_blank"', '', $html);
}

$return['error'] = 0;
$return['html'] = wq_channel_diconv($html, CHARSET, 'UTF-8');
echo json_encode($return);
exit;

?>