<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_channel.inc.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/config.php';
$ac = in_array($_GET['ac'], array('getallpages', 'getpagesdata')) ? dhtmlspecialchars($_GET['ac']) : "";

$data = array('error' => 10001, 'msg' => $Plang['13418931fb040f85']);
if(empty($ac)) {
	echo json_encode(wq_channel_diconv($data, CHARSET, 'utf-8'));
}
if($ac == 'getallpages') {
	$data['error'] = 0;
	$data['msg'] = $category;

	echo json_encode(wq_channel_diconv($data, CHARSET, 'utf-8'));
}
if($ac == 'getpagesdata') {
	$pageid = $_GET['pageid'] ? $_GET['pageid'] : 1;
	$targettplname = 'channel_index_' . $pageid;
	$diycontent = wq_channel_get_diycontent_by_targettplname($targettplname);
	$res = wq_channel_import_diy($diycontent, true);

	$n = 0;
	foreach($res as $key => $re) {
		if($re['type'] == 'frame') {
			unset($re['type']);
			foreach($re as $k => $val) {
				if(!empty($val)) {
					$newres['wq' . $n] = $val;
					$newres['wq' . $n]['page'] = 'wq' . $n;
				}
				$n ++;
			}
		}
		if($re['type'] == 'tab') {
			unset($re['type']);
			$newres['wq' . $n]['list'] = $re;
			$newres['wq' . $n]['page'] = 'wq' . $n;
			$newres['wq' . $n]['templatetype'] = 'tags';
			$newres['wq' . $n]['selTag'] = 0;
			$n ++;
		}
	}

	echo json_encode(wq_channel_diconv($newres, CHARSET, 'utf-8'));
}
//From: Dism_taobao-com
?>