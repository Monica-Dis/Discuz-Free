<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: channel_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['groupid'] != '1' && !in_array($_G['groupid'], $setting['allowaddchannel'])) {
	showmessage($Plang['a5ec37ccfca90b08']);
}

$pageid = $_GET['pageid'] ? intval($_GET['pageid']) : 0;
$pages = '';
$setindex = false;

if($pageid) {
	$pages = C::t("#wq_channel#wq_channel_pages")->fetch($pageid);
	if(empty($pages)) {
		showmessage($Plang['bb36c1ccfb3f1989']);
	}

	$seturl = wq_channel_get_pages_url($pages, $pageid);
	$setindex = true;
}

if(submitcheck('editsubmit')) {
	if(is_numeric($pageid = wq_channel_updatechannel($pages))) {
		if($setindex) {
			$oldsetindex = !empty($_G['setting']['defaultmobileindex']) && $_G['setting']['defaultmobileindex'] == $seturl ? 1 : 0;
			if($_GET['setindex']) {
				wq_channel_set_setting_defaultmobileindex($seturl);
			} elseif($oldsetindex) {
				wq_channel_set_setting_defaultmobileindex();
			}
		}
		showmessage($Plang['357c80f9fe7dbb3f'], 'plugin.php?id=wq_channel&mod=index&pageid=' . $pageid . '&ac=diy');
	} else {
		showmessage($pageid);
	}
}

$colors = array(
	"#EB413D" => $Plang['29a0667edf66ee56'],
	"#1aad16" => $Plang['3f12b1292794a44e'],
	"#01a9e9" => $Plang['66b72f84eda30532'],
	"#3d95d5" => $Plang['e45b1f6d08454bda'],
	"#2bb8aa" => $Plang['7f604c0c4998a7b0'],
	"#8fc21d" => $Plang['dcaf50e0aeb6ca45'],
	"#ff4466" => $Plang['93add4070f25712b'],
	"#ff8400" => $Plang['9eb42dcbb1a3be39'],
	"#26282d" => $Plang['37e4fb65066df9f7'],
);

include template('wq_channel:channel_create');

?>