<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_channel/language/install_language.php';
require_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_channel.php';
require_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_channel_ext.php';
require_once DISCUZ_ROOT . './source/plugin/wq_channel/config/loadfunc.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		loadcache('wq_channel_create_pages');
		$category = $_G['cache']['wq_channel_create_pages'];
		foreach($category as $key => $val) {
			$dels[] = $val['pageid'];
		}
		wq_channel_delete_pages($dels);
		C::t("common_syscache")->delete('wq_channel_create_pages');

		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_channel_pages`;
DROP TABLE IF EXISTS `pre_wq_channel_block`;
DROP TABLE IF EXISTS `pre_wq_channel_block_data`;
DROP TABLE IF EXISTS `pre_wq_channel_sorttemp`;
EOF;
		runquery($sql);

		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_channel.php");
		@unlink(DISCUZ_ROOT . "./data/sysdata/cache_wqchannel.php");
		@unlink(DISCUZ_ROOT . "./data/channel_import.lock");

		wq_rmdir(DISCUZ_ROOT . './data/cache/wq_channel/');
		wq_channel_delete_template();

		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//From: Dism_taobao-com
?>