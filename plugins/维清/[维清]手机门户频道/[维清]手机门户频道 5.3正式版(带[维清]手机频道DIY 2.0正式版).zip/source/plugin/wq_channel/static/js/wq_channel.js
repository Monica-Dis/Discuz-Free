function imgSlide() {
    var elem =  document.getElementsByClassName('wqtopscroll_lb');
    var $ = window.jQuery || wqjq
    for (var i = 0; i < elem.length; i++) {
        if (elem[i].className.indexOf('addslide') == -1) {
            $(elem[i]).addClass('slide-stop');
            elem[i].className = elem[i].className + ' addslide'
            var pageContain = elem[i].getElementsByTagName('ul')[0];
            if (pageContain && pageContain.className == 'wqscroll_icon3') {
                var count = elem[i].firstElementChild.children.length;
                var page = document.createElement('span');
                var pageTotal = document.createElement('span');
                var spl = document.createTextNode('/');
                page.className = 'on';
                page.innerHTML = '1';
                pageTotal.innerHTML = count;
                pageContain.appendChild(page);
                pageContain.appendChild(spl);
                pageContain.appendChild(pageTotal);

            } else if(pageContain) {
                var count = elem[i].firstElementChild.children.length;
                for (var index1 = 0; index1 < count; index1++) {
                    var page =  document.createElement('li');
                    page.setAttribute('data-tab', index1);
                    attachEvent(page, 'click', function (e) {
                        swipe.slide(parseInt(e.currentTarget.getAttribute('data-tab')), 500);
                    });
                    pageContain.appendChild(page);
                }
                pageContain.children[0].className = 'on';
            }
            var swipe = new Swipe(elem[i], {
                auto: 3000,
                continuous: true,
                callback: (function (count, pageContain) {
                    if (pageContain) {
                        return function (index) {
                            var pageCount;
                            pageCount = count == 2 && index > 1 ? index - 2 : index;

                            if (pageContain.className == 'wqscroll_icon3') {
                                pageContain.firstElementChild.innerHTML = pageCount + 1;

                            } else {
                                for (var j = 0; j < pageContain.children.length; j++) {
                                    pageContain.children[j].className = '';
                                }

                                pageContain.children[pageCount].className = 'on';
                            }
                        };
                    }
                })(count, pageContain)
            });
        }
    }
}
function itemSlide(row, col, selector) {
    var $ = window.jQuery || wqjq
    var number = row * col;
    var itemlist = $(selector);
    itemlist = [].slice.call(itemlist, 0);
    if (!Array.prototype.forEach) {
        Array.prototype.forEach = function(fun) {
            var len = this.length;
            if (typeof fun != "function") throw new TypeError();
            var thisp = arguments[1];
            for (var i = 0; i < len; i++) {
            if (i in this)
               fun.call(thisp, this[i], i, this);
            }
        };
    }
    itemlist.forEach(function (item) {
        if (item.className.indexOf('addslide') == -1) {
            item.className = item.className + ' addslide';

            if (item.firstElementChild.children.length > number) {
                var elem = item.firstElementChild.children;
                var swiperContain = document.createElement('div');
                swiperContain.className = 'swiperContain';
                var swiperWrap = document.createElement('ul');
                var html = '';
                var count = 1;
                var i = 0;
                var pageContain = document.createElement('p');
                pageContain.className = 'wqplate_rem_origin';
                item.appendChild(pageContain);
                var pagination = document.createElement('span');
                pagination.className = 'wq_origin wqon';
                pageContain.appendChild(pagination);
                pagination.setAttribute('data-tab', 0);
                pagination.onclick = function (e) {
                    swipe.slide(parseInt(e.currentTarget.getAttribute('data-tab')), 500);
               }
                while (elem.length != 0) {
                    if (i < number * count) {
                        swiperWrap.appendChild(elem[0]);

                    } else {
                        swiperContain.appendChild(swiperWrap);
                        pagination = document.createElement('span');
                        pagination.className = "wq_origin";
                        pagination.setAttribute('data-tab', count);
                        pagination.onclick = function (e) {
                            swipe.slide(parseInt(e.currentTarget.getAttribute('data-tab')), 500);
                        };
                        item.children[1].appendChild(pagination);
                        swiperWrap = document.createElement('ul');
                        swiperWrap.appendChild(elem[0]);
                        count++;
                    }

                    i++;
                }
                swiperContain.appendChild(swiperWrap);
                item.removeChild(item.firstElementChild);
                item.insertBefore(swiperContain, item.firstElementChild);
                $(item).addClass('slide-stop');
                var swipe = new Swipe(item, {
                    continuous: true,
                    callback: function (index) {
                        var page = item.children[1].getElementsByTagName('span');
                        for (var k = 0; k < page.length; k++) {
                            page[k].className = page[k].className.replace(' wqon', '');
                        }

                        var pageCount;
                        pageCount = page.length == 2 && index > 1 ? index - 2 : index;
                        page[pageCount].className = page[pageCount].className + ' wqon';
                    }
                });
            }
        }
    });
}

function _ajax_post(obj,type,op){
    var $ = window.jQuery || wqjq;
    op = typeof op == 'undefined' || op === null ? '' : op;
    var id = $(obj).parents('.dxb_bc').prop('id');
    var bid = id.match(/\d+/g)[0];
    $(obj).html("<img src='source/plugin/wq_channel/static/images/icon_load.gif'>������...");

    $.ajax({
        url: "plugin.php?id=wq_channel&mod=ajax",
        data: {ac:type,op:op,bid: bid},
        type: "POST",
        dataType: 'JSON',
        success: function(s) {
            if(s.error == '-1'){
                $(obj).html(s.html);
            }else if(s.error == '-2'){
                $(obj).attr('onclick','');
                $(obj).html(s.html);
            }else{
                $(obj).html("���ظ���<i class='wqchannel wqchannel-jiantou_down-copy'></i>");
                $(obj).parent('p').siblings('div').find("ul").append(s.html);

                wqlazyload.load();

                if(op=="waterfall" || op=='mixed'){
                    if ($(obj).parent().prev().hasClass('wqwaterfall_warp')) {
                        $('.wqwaterfall_con').imagesLoaded(function () {
                            $('.wqwaterfall').masonry('reload');
                        });
                    }
                }
            }
        }
    });
}

function mobile_initTab(frameId) {
    var tabs = document.getElementById(frameId+'_title').childNodes;
    var arrTab = [];
    for(var i in tabs) {
        if (tabs[i]['nodeType'] == 1 && tabs[i]['className'].indexOf('move-span') > -1) {
            arrTab.push(tabs[i]);
        }
    }
    var counter = 0;
    var tab = document.createElement('ul');
    tab.className = 'tb cl';
    var len = arrTab.length;

    for(var i = 0;i < len; i++) {
        var tabId = arrTab[i].id;
        if (hasClass(arrTab[i],'frame') || hasClass(arrTab[i],'tab')) {
            var arrColumn = [];
            for (var j in arrTab[i].childNodes) {
                if (typeof arrTab[i].childNodes[j] == 'object' && !hasClass(arrTab[i].childNodes[j],'title')) arrColumn.push(arrTab[i].childNodes[j]);
            }
            var frameContent = document.createElement('div');
            frameContent.id = tabId+'_content';
            frameContent.className = hasClass(arrTab[i],'frame') ? 'content cl '+arrTab[i].className.substr(arrTab[i].className.lastIndexOf(' ')+1) : 'content cl';
            var colLen = arrColumn.length;
            for (var k = 0; k < colLen; k++) {
                frameContent.appendChild(arrColumn[k]);
            }
        } else {
            var frameContent = document.getElementById(tabId+'_content');
            frameContent = frameContent || document.createElement('div');
        }
        frameContent.style.display = counter ? 'none' : '';
        document.getElementById(frameId+'_content').appendChild(frameContent);

        var li = document.createElement('li');
        li.id = tabId;
        li.className = counter ? '' : 'a';
        var reg = new RegExp('style=\"(.*?)\"', 'gi');
        var matchs = '', style = '', imgs = '';

        while((matchs = reg.exec(arrTab[i].innerHTML))) {
            if(matchs[1].substr(matchs[1].length,1) != ';') {
                matchs[1] += ';';
            }

            style += matchs[1];
        }

        style = style ? ' style="'+style+'"' : '';
        reg = new RegExp('(<img.*?>)', 'gi');

        while((matchs = reg.exec(arrTab[i].innerHTML))) {
            imgs += matchs[1];
        }

        li.innerHTML = arrTab[i]['innerText'] ? arrTab[i]['innerText'] : arrTab[i]['textContent'];
        var a = arrTab[i].getElementsByTagName('a');
        var href = a && a[0] ? a[0].href : 'javascript:;';
        var onclick =  ' onclick="return false;"';
        li.innerHTML = '<a href="' + href + '"' + onclick + ' onfocus="this.blur();" ' + style + '>' + imgs + li.innerHTML + '</a>';
        attachEvent(li, 'click', switchTabUl);
        tab.appendChild(li);
        document.getElementById(frameId+'_title').removeChild(arrTab[i]);
        counter++;
    }
    document.getElementById(frameId+'_title').appendChild(tab);
}

function hasClass(elem, className) {
    return elem.className && (" " + elem.className + " ").indexOf(" " + className + " ") != -1;
}

function attachEvent(obj, evt, func, eventobj) {
    eventobj = !eventobj ? obj : eventobj;

    if(obj.addEventListener) {
        obj.addEventListener(evt, func, false);
    } else if(eventobj.attachEvent) {
        obj.attachEvent('on' + evt, func);
    }
}

function switchTabUl (e) {
    e = e || window.event;
    var aim = e.target || e.srcElement;
    var tabId = aim.id;
    var parent = aim.parentNode;

    while(parent['nodeName'] != 'UL' && parent['nodeName'] != 'BODY') {
        tabId = parent.id;
        parent = parent.parentNode;
    }

    if(parent['nodeName'] == 'BODY') return false;

    var tabs = parent.childNodes;
    var len2 = tabs.length;

    var $ = window.jQuery || wqjq;
    for(var j = 0; j < len2; j++) {
        tabs[j].className = (tabs[j].id == tabId) ? 'a' : '';
        var content = document.getElementById(tabs[j].id+'_content');
        if (content) content.style.display = tabs[j].id == tabId ? '' : 'none';
    }
    wqlazyload.load();
    if (content.getElementsByClassName('wqwaterfall_warp').length) {
        $('#' + tabId + '_content .wqwaterfall_con').imagesLoaded(function () {
            $('#' + tabId + '_content .wqwaterfall').masonry('reload');
        });
    }
}

function isPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
}

(function ($) {
    var navWidth = $(window).width();
    var isPc = isPC();

    $.fn.scrollnav = function (col) {
        var clientWidth = 0;
        this.css({overflow: 'hidden'});
        this.each(function () {
            if ($(this).hasClass('addScroll')) {
                return;
            } else {
                $(this).addClass('addScroll slide-stop');
            }

            if ($(this).find('ul').css('display') == 'flex') {
                clientWidth = isPc ? Math.ceil(640 * (1 / col - 0.05)) + 1 : Math.ceil($(window).width() * (1 / col - 0.05)) + 1;

                if (isPc) {
                    $(this).width(640);
                } else {
                    $(this).css({width: navWidth});
                }

                $(this).find('li').css({flex: 'none', width: clientWidth});
                var tagWidth = $(this).find('li').length * clientWidth;
                $(this).find('ul').width(tagWidth + 5);
            } else {
                var eleWidth = $(this).find('ul').width() *  (1 / col - 0.05) ;
                $(this).find('li').css({width: eleWidth});
                $(this).find('ul').parent().width(3000);
                $(this).find('ul').css('display', 'inline-block');
                var tagWidth = $(this).find('ul').width();
                $(this).find('ul').width(tagWidth);
                $(this).find('ul').parent().css({width: 'auto'});
            }

            if (tagWidth > navWidth) {
                var myscroll= new IScroll($(this)[0], {click: true, bounce: true, scrollX: true});
            }
        });
    };
})(window.jQuery || wqjq);

var wqlazyload = (function ($) {
    $(function () {
        $(document).on('scroll', throttle(delayload, 300, 600));
        delayload();
    });
    var throttle = function (fun, delay, limit) {
        var time = null;
        var startTime = new Date();
        return function () {
            var lastTime = new Date();
            clearTimeout(time);
            if (lastTime - startTime >= limit) {
                startTime = lastTime;
                fun();
            } else {
                time = setTimeout(fun, delay);
            }
        };
    };
    var delayload = function () {
        var document_top = $(document).scrollTop();
        $(".wq-lazyload").each(function() {
            if ($(this).parent().is(':hidden')) return true;
            var img_top = $(this).offset().top;
            if (img_top >= document_top && img_top <= document_top + $(window).height()) {
                $(this).prop('src', $(this).attr('data-src')).removeClass("wq-lazyload");
                this.onload = function () {
                    if ($(this).parents('.wq-lazyload-container').length) {
                        resetImage($(this).parents('.wq-lazyload-container'));
                    }
                }
            }
        });
    };
    var resetImage = function (obj) {
        var img = new Image();
        obj.css('overflow', 'hidden');
        img.src = obj.find('img').attr('data-src');
        img.onload = function () {
            var img_width = img.width, img_height = img.height;
            if (img_width / obj.width() > img_height / obj.height()) {
                obj.find('img').height(obj.height());
                obj.find('img').width(obj.height() * img_width / img_height);
                var marginLeft = (obj.width() - obj.find('img').width()) / 2;
                obj.find('img').css('margin-left', marginLeft);
            } else {
                obj.find('img').width(obj.width());
                obj.find('img').height(obj.width() * img_height / img_width);
                var marginTop = (obj.height() - obj.find('img').height()) / 2;
                obj.find('img').css('margin-top', marginTop);
            }
        };
    };
    return {
        load: delayload,
        reset: resetImage
    };
})(window.jQuery || wqjq);

function loop(h, speed, delay, sid) {
    var $ = window.jQuery || wqjq;
    var o = $(sid);
    if (o.children().length <= 1) return;
    var first = o.children().first().clone();
    o.append(first);
    o.css({transform: 'translateY(0)', transition: '0s'});
    o.attr('data-y', '0');

    var scroll = function () {
        var c = parseInt(o.attr('data-y')) + 1;
        o.css({transform: 'translateY(-' + c * h + 'px)', transition: '0.5s'});
        setTimeout(function () {
            o.css({transition: '0s'});
            if (c == o.children().length - 1) {
                o.css({transform: 'translateY(0)'});
                c = 0;
            }
            o.attr('data-y', c);
            setTimeout(scroll, delay);
        }, speed);
    };

    setTimeout(scroll, delay);
}

function set_scroll() {
    var $ = window.jQuery || wqjq;
    var last = $('.load-scroll').eq($('.load-scroll').length - 1);
    var lastframe, lastmodule;
    var isLastframe = function(ele) {
        var parent = ele.parent();
        if (parent.hasClass('wqchannel_warp') || parent.hasClass('wqpc_warp')) {
            lastframe = 1;
        } else {
            if (parent.hasClass('frame') || parent.hasClass('frame-tab')) {
                if (parent.next().length) {
                    var next = parent.next();
                    while (next.length) {
                        if (next.hasClass('frame') && next.height() != 0) {
                            lastframe = 0;
                            break;
                        }
                        next = next.next();
                    }
                    if (typeof lastframe == 'undefined') {
                        isLastframe(parent);
                    }
                } else {
                    isLastframe(parent);
                }
            } else {
                isLastframe(parent);
            }
        }
    };

    var isLastModule = function(ele) {
        var parent = ele.parent();
        if (parent.hasClass('frame') || parent.hasClass('frame-tab')) {
            if (parent.hasClass('frame-tab')) {
                lastmodule = 1;
            } else {
                if (!ele.find('.load-scroll').parents('.dxb_bc').parent().next().length) {
                    lastmodule = 1;
                } else {
                    var next = ele.find('.load-scroll').parents('.dxb_bc').parent().next();
                    while (next.length) {
                        if (next.height() != 0) {
                            lastmodule = 0;
                            break;
                        }
                        next = next.next();
                    }
                    if (typeof lastmodule == 'undefined') {
                        lastmodule = 1;
                    }
                }
            }
        } else {
            isLastModule(parent);
        }
    };
    isLastframe(last);
    isLastModule(last);
    if (lastframe && lastmodule) {
        var isLoading = false;
        var windowHeight = $(window).height();
        return function () {
            if (isLoading) return;
            if (windowHeight + $(document).scrollTop() >= $(document).height() - 88) {
                isLoading = true;
                var module, obj;
                if (last.parents('.frame-tab').hasClass('frame-tab')) {
                    last.parents('.frame-tab').find('.load-scroll').each(function () {
                        if ($(this).is(':visible')) {
                            module = $(this);
                        }
                    });
                } else {
                    module = last;
                }
                if (!module) {
                    isLoading = false;
                    return;
                };
                var ac = module.attr('data-ac'), val = module.attr('data-op');
                var obj = module.siblings('.wqchannel_more').find('a');
                var val = typeof val == 'undefined' || val === null ? '' : val;
                var bid = module.parents('.dxb_bc').prop('id').match(/\d+/g)[0];
                if (obj.length) {
                    obj.html("<img src='source/plugin/wq_channel/static/images/icon_load.gif'>������...");
                    obj[0].onclick = null;
                }
                $.ajax({
                    url: "plugin.php?id=wq_channel&mod=ajax",
                    data: {ac: ac, op: val, bid: bid},
                    type: "POST",
                    dataType: 'JSON',
                    success: function(s) {
                        isLoading = false;
                        if((s.error == '-1' || s.error == '-2')){
                            if (obj.length) {
                                obj.html(s.html);
                            }
                        } else {
                            obj.html("���ظ���<i class='wqchannel wqchannel-jiantou_down-copy'></i>");
                            module.find("ul").append(s.html);
                            wqlazyload.load();
                            if(val == "waterfall" || val == 'mixed'){
                                if (module.hasClass('wqwaterfall_warp')) {
                                    module.find('.wqwaterfall_con').imagesLoaded(function () {
                                        module.find('.wqwaterfall').masonry('reload');
                                    });
                                }
                            }
                        }
                    }
                });
            }
        };
    }
}

(function ($) {
    $(function () {
        $('.wqwaterfall_con').imagesLoaded(function () {
            $('.wqwaterfall').masonry({
                itemSelector: '.waterfall > li'
            });
        });
        $('.wqnew_list_warp').each(function () {
            if ($(this).hasClass('hasloaded')) {
                return true;
            } else {
                $('<p class="wqload-wait"><a href="javascript:;" class="wqblock"><img style="margin-top: 10px;" src="source/plugin/wq_channel/static/images/icon_load.gif"><br>���ڼ��أ����Ե�...</a></p>').insertAfter(this);
                var bid = $(this).parents('.dxb_bc').prop('id').match(/\d+/g)[0]
                    ,ac = $(this).attr('data-ac');
                var obj = $(this).siblings('.wqchannel_more').find('a');
                var that = $(this);
                obj.parent().hide();
                $.ajax({
                    url: "plugin.php?id=wq_channel&mod=ajax",
                    data: {ac: ac, op: 'mixed',bid: bid, page: 1},
                    type: "POST",
                    dataType: 'JSON',
                    success: function(s) {
                        $('.wqload-wait').remove();
                        obj.parent().show();
                        if(s.error == '-1' || s.error == '-2'){
                            obj.html(s.html);
                        } else {
                            that.addClass('hasloaded').find(".wqnew_list_ul").append(s.html);
                            wqlazyload.load();
                        }
                    }
                });
            }
        });
        if ($('.load-scroll').length) $(document).on('scroll', set_scroll());
    });
})(window.jQuery || wqjq);