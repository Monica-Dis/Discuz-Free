(function ($) {
    $(function () {
        var m_ua = navigator.appVersion;
        var mbrowser = {
            isUC: /UCBrowser/.test(m_ua),
            isBaiduBox: /baiduboxapp\//.test(m_ua),
            isBaiduBrowser: /baidubrowser\//.test(m_ua),
            isQQ: /QQ\//.test(m_ua),
            isQQBrowser: ! /QQ\//.test(m_ua) && /MQQBrowser/.test(m_ua),
            isWX: /MicroMessenger/.test(m_ua),
            isLieBao: /LieBaoFast/.test(m_ua),
            is2345: /Mb2345Browser/.test(m_ua),
            isSogou: /SogouMobileBrowser/.test(m_ua),
            isOpera: /OPR\//.test(m_ua)
        };
        if (mbrowser.isUC) {
            var config = {
                url: location.href,
                title:'',
                desc:'',
                img:'',
                img_title:'',
                from:''
            };
            var share_obj = new nativeShare('nativeShare', config);
            $('body').on('click', '.wq-share-mask', function () {
                $('.wq-ucshare').slideUp(200);
                $('.wq-share-mask').hide();
            });
            $('.wqsharecancel').on('click', function () {
                $('.wq-ucshare').slideUp(200);
                $('.wq-share-mask').hide();
            });
        }
        $('.wq-appshare').on('click', function () {
            if (mbrowser.isUC) {
                $('.wq-share-mask').css({'opacity': '0.4'});
                $('.wq-ucshare').slideToggle(200);
                $('.wq-share-mask').show();
            } else if (mbrowser.isQQ || mbrowser.isWX) {
                $('.wq-share-mask').css({'opacity': '0.95'});
                $('.wq-share-mask, .wq-qqshare').show();
            } else if (mbrowser.isQQBrowser || mbrowser.is2345) {
                $('.wq-share-mask').css({ 'opacity': '0.95'});
                $('.wq-share-mask, .wq-2345share').show();
            } else if (mbrowser.isBaiduBrowser || mbrowser.isLieBao) {
                $('.wq-share-mask').css({ 'opacity': '0.95'});
                $('.wq-share-mask, .wq-baidushare').show();
            } else if (mbrowser.isBaiduBox || mbrowser.isSogou || mbrowser.isOpera) {
                $('.wq-share-mask').css({'opacity': '0.95'});
                $('.wq-share-mask, .wq-baiduBoxshare').show();
            } else {
                alert('�����������������з���');
            }
        });
        $('body').on('click', '.wq-share-mask, .wq-share', function () {
            $('.wq-share-mask, .wq-share').hide();
        });
        $('body').on('touchmove', '.wq-share-mask, wq-share', function (e) {
            e.preventDefault();
        });
    });
})($)