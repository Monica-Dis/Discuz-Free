<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_channel/config/setting_base.php';

$setting['admincp_perpage'] = $setting['admincp_perpage'] <= 0 ? 20 : $setting['admincp_perpage'];
$setting['upload_maxsize'] = $setting['upload_maxsize'] ? $setting['upload_maxsize'] : 2;

?>