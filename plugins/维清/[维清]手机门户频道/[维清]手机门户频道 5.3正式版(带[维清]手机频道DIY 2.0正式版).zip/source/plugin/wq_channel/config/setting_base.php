<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-3-17 16:44:51Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_channel'];
$setting['allowaddchannel'] = unserialize($setting['allowaddchannel']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['iconfont_url'] = trim($setting['iconfont_url']);
$setting['upload_maxsize'] = intval($setting['upload_maxsize']);

?>