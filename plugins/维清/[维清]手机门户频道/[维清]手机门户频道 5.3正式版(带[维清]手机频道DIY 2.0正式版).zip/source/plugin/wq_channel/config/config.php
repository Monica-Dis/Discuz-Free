<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_channel.php';
include_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_channel_ext.php';

$Plang = wq_loadlang('wq_channel');
loadcache('wq_channel_create_pages');
$category = $_G['cache']['wq_channel_create_pages'] ? $_G['cache']['wq_channel_create_pages'] : wq_channel_pages_fetch_all();

$setting = wq_loadsetting('wq_channel');

?>