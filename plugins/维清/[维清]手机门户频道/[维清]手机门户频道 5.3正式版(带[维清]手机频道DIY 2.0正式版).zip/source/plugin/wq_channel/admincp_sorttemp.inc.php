<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_sorttemp.inc.php 2017-12-8 17:08:50Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/config.php';
$url = $mpurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=&pmod=admincp_sorttemp';
$formurl = $url;
$mpurl = ADMINSCRIPT . '?action=' . $mpurl;

$sortid = isset($_GET['sortid']) ? intval($_GET['sortid']) : 0;
$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 10;
$start = ($page - 1 ) * $perpage;

$cpmsgurl = 'action=' . $url;
$cpmsgurl .= $sortid ? '&sortid=' . $sortid : '';

if(!submitcheck('submitform')) {
	$sorts = C::t('forum_threadtype')->fetch_all_for_order();
	$li = '<li><a href=" ' . ADMINSCRIPT . '?action=threadtypes" target="_blank">' . $Plang['1dcb34e33019392b'] . '</a></li>';
	foreach($sorts as $key => $sort) {
		if(!$sortid) {
			$sortid = $sort['typeid'];
		}
		if($sortid == $sort['typeid']) {
			$sortname = $sort['name'];
		}
		$wq_a = array($sortid => ' class="wq_a"');
		$li .= '<li' . $wq_a[$sort['typeid']] . '><a href="' . $mpurl . '&sortid=' . $sort['typeid'] . '">' . $sort['name'] . '</a></li>';
	}


	echo <<<EOF
    <style>
        .wq_mn {display: inline; margin-right: 10px; padding-top: 10px; overflow: hidden;}
        .wq_tb{line-height: 30px; border-bottom: 1px solid #CDCDCD;  margin-top: 5px; height: 31px; }
        .wq_bm{margin-bottom: 10px; }
        .wq_.bw0{background: transparent; border: none !important;}
        .wq_tb li{float: left; margin: 0 3px 0 0; list-style: none; display: list-item; text-align: -webkit-match-parent;}
        .wq_tb a{display: block; padding: 0 10px; border: 1px solid #CDCDCD; color: #333; text-decoration: none; background: #E5EDF2;}
        .wq_tb .wq_a a{border-bottom-color: #FFF; background: #FFF; font-weight: 700;}
        #btype button{margin:2px 0;}
    </style>
    <div class="wq_mn">
        <div class="wq_bm wq_bw0">
            <ul class="wq_tb wq_cl">{$li}</ul>
        </div>
    </div>
EOF;
	if(!empty($sorts)) {
		$threadtype = C::t('forum_threadtype')->fetch($sortid);
		$showoption = '';
		$typevararr = C::t('forum_typevar')->fetch_all_by_sortid($sortid, 'ASC');
		$typeoptionarr = C::t('forum_typeoption')->fetch_all(array_keys($typevararr));
		foreach($typevararr as $option) {
			$option['title'] = $typeoptionarr[$option['optionid']]['title'];
			$option['type'] = $typeoptionarr[$option['optionid']]['type'];
			$option['identifier'] = $typeoptionarr[$option['optionid']]['identifier'];
			$showoption .= '<button onclick="settip(this, \'' . $option['identifier'] . '\')" type="button">' . $option['title'] . '</button>&nbsp;&nbsp;';
		}
		unset($typevararr, $typeoptionarr);

		echo '<div id="btype">' .
		'<button onclick="settip(this, \'subject\', \'subject/' . $lang['threadtype_template_threadtitle'] . '|subject_url/' . $lang['threadtype_template_threadurl'] . '|tid/' . $lang['threadtype_template_threadid'] . '\')" type="button">' . $lang['threadtype_template_threadtitle'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'\', \'dateline/' . $lang['threadtype_template_dateline'] . '\')" type="button">' . $lang['threadtype_template_dateline'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'author\', \'author/' . $lang['threadtype_template_author'] . '|authorid/' . $lang['threadtype_template_authorid'] . '|author_url/' . $lang['threadtype_template_authorurl'] . '|avatar_small/' . $lang['threadtype_template_authoravatar'] . '|author_verify/' . $lang['threadtype_template_authorverify'] . '\')" type="button">' . $lang['threadtype_template_threadauthor'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'\', \'views/' . $lang['threadtype_template_threadviews'] . '\')" type="button">' . $lang['threadtype_template_threadviews'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'\', \'replies/' . $lang['threadtype_template_threadreplies'] . '\')" type="button">' . $lang['threadtype_template_threadreplies'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'lastpost\', \'lastpost/' . $lang['threadtype_template_lastpostdateline'] . '|lastpost_url/' . $lang['threadtype_template_lastposturl'] . '|lastposter/' . $lang['threadtype_template_lastpostuser'] . '|lastposter_url/' . $lang['threadtype_template_lastpostuserurl'] . '\')" type="button">' . $lang['threadtype_template_lastpost'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'typename\', \'typename/' . $lang['threadtype_template_threadtypename'] . '|typename_url/' . $lang['threadtype_template_threadtypeurl'] . '\')" type="button">' . $lang['threadtype_template_threadtype'] . '</button>&nbsp;&nbsp;' .
		'<button onclick="settip(this, \'\', \'attachment/' . $lang['threadtype_template_attachmentexist'] . '\')" type="button">' . $lang['threadtype_template_attachment'] . '</button>&nbsp;&nbsp' .
		'<button onclick="settip(this, \'loop\', \'/' . $lang['threadtype_template_loop'] . '\')" type="button">[loop]...[/loop]</button>&nbsp;&nbsp;' .
		'<br />' .
		$showoption .
		'<div id="btype_tip"></div></div>';

		echo '<script>
		function settip(obj, id, tips) {
			var tips = !tips ? 0 : tips.split(\'|\');
			var tipid = obj.parentNode.id + \'_tip\', s1 = \'\', s2 = \'\', s3 = \'\';
			if(!tips) {
				s1 += \'<td>{\' + id + \'}</td>\';
				s2 += \'<td>' . $lang['threadtype_template_varname'] . '(\' + obj.innerHTML + \')</td>\';
				s1 += \'<td>{\' + id + \'_value}</td>\';
				s2 += \'<td>' . $lang['threadtype_template_varvalue'] . '</td>\';
				s1 += \'<td>{\' + id + \'_unit}</td>\';
				s2 += \'<td>' . $lang['threadtype_template_varunit'] . '</td>\';
				if(obj.parentNode.id == \'ptype\') {
					s1 += \'<td>{\' + id + \'_required}</td>\';
					s2 += \'<td>' . $lang['threadtype_template_requiredflag'] . '</td>\';
					s1 += \'<td>{\' + id + \'_tips}</td>\';
					s2 += \'<td>' . $lang['threadtype_template_tipflag'] . '</td>\';
					s1 += \'<td>{\' + id + \'_description}</td>\';
					s2 += \'<td>' . $lang['threadtype_template_briefdes'] . '</td>\';
				}
				if(obj.parentNode.id == \'ptype\') {
					s3 = \'<dt><strong class="rq">{\' + id + \'_required}</strong>{\' + id + \'}</dt><dd>{\' + id + \'_value} {\' + id + \'_unit} {\' + id + \'_tips} {\' + id + \'_description}</dd>\r\n\';
				} else {
					s3 = obj.parentNode.id == \'ttype\' ? \'<dt>{\' + id + \'}:</dt><dd>{\' + id + \'_value} {\' + id + \'_unit}</dd>\r\n\' : \'<p><em>{\' + id + \'}:</em>{\' + id + \'_value} {\' + id + \'_unit}</p>\r\n\';
				}
			} else {
				for(i = 0;i < tips.length;i++) {
					var i0 = tips[i].substr(0, tips[i].indexOf(\'/\'));
					var i1 = tips[i].substr(tips[i].indexOf(\'/\') + 1);
					if(i0) {
						s1 += \'<td>{\' + i0 + \'}</td>\';
					}
					s2 += \'<td>\' + i1 + \'</td>\';
				}
				if($(id + \'_sample\')) {
					s3 = $(id + \'_sample\').innerHTML;
				}
			}
			$(tipid).innerHTML = \'<table class="tb tb2">\' +
				(s1 ? \'<tr><td class="bold" width="50">' . $lang['threadtype_template_tag'] . '</td>\' + s1 + \'</tr>\' : \'\') +
				\'<tr><td class="bold" width="50">' . $lang['threadtype_template_intro'] . '</td>\' + s2 + \'</tr></table>\';
			if(s3) {
				$(tipid).innerHTML += \'<table class="tb tb2"><tr><td class="bold" width="50">' . $lang['threadtype_template_example'] . '</td><td colspan="6"><textarea style="width: 95%;" rows="2" readonly onclick="this.select()" id="\' + obj.parentNode.id + \'_sample">\' + s3 + \'</textarea></td></tr></table>\';
			}
		}
		</script>';


		$lists = C::t('#wq_channel#wq_channel_sorttemp')->fetch_all_by_search($sortid);

		showformheader($formurl, '', 'submitform');
		showtableheader($sortname . $Plang['21723768a256e613']);
		showsubtitle(array('', $Plang['05800a6554b8cf28'], $Plang['a9535af55ae38707']), 'header', array("width='60px'", "width='320px'"));
		showhiddenfields(array('sortid' => $sortid, 'sortname' => $sortname));
		foreach($lists as $key => $list) {
			showhiddenfields(array('tempid[]' => $list['tempid']));
			showtablerow('', array("width='60px'", "width='320px'"), array(
				'<a name = "class_' . $list['tempid'] . '"><input class = "fs" type = "checkbox" name = "delete[' . $list['tempid'] . ']" value = "' . $list['tempid'] . '" /></a> ',
				"<input type=\"text\" name=\"tempname[$list[tempid]]\" value=\"{$list['tempname']}\" style=\"width:300px;\">",
				"<textarea name=\"temp[$list[tempid]]\" rows=\"15\" cols=\"100\">{$list['temp']}</textarea>",
			));
		}
		echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "javascript:;" onclick = "wq_addrow(this, 0, 0)" class = "addtr">' . $Plang['b7d63548f8406158'] . '</a></div></td></tr>';
		showsubmit('submitform', 'submit', 'del');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();

		echo <<<EOF
    <script type='text/JavaScript'>
        var addrowdirect = 0;
    var addrowkey = 0;
    function wq_addrow(obj, type,flag) {
        if(flag == 2){
            addrowkey--;
        }else{
            var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
            if(!addrowdirect) {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
            } else {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
            }
          var rowtypedata = [[[1,''],[1,'<input name = "inserttempname[]"  value="" type = "text" style="width:300px;">'],[1,'<div><textarea name = "inserttemp[]" rows="15" cols="100"></textarea>&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this),wq_addrow(this, 0,2)">{$Plang['0d9efacf5089d88c']}</a></div>']],];

            var typedata = rowtypedata[type];
            for(var i = 0; i <= typedata.length - 1; i++) {
                    var cell = row.insertCell(i);
                    cell.colSpan = typedata[i][0];
                    var tmp = typedata[i][1];
                    if(typedata[i][2]) {
                            cell.className = typedata[i][2];
                    }
                    tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                    tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return wq_addrow.arguments[parseInt($2) + 1];});
                    cell.innerHTML = tmp;
            }
            addrowkey ++;
            addrowdirect = 0;
        }
    }
        function _del_confirm() {
            if (!confirm("{$Plang['97abeb5464e370fe']}")) {
                window.event.returnValue = false;
            }
        }
    </script>
EOF;
	} else {
		showtableheader();
		echo '<tr><td style="border:none;"><a href="' . ADMINSCRIPT . '?action=threadtypes" target="_blank">' . $Plang['c8e2a3592f725ae5'] . '</a></td></tr>';
		showtablefooter();/*Dism��taobao��com*/
	}
} else {

	$sortid = isset($_GET['sortid']) ? intval($_GET['sortid']) : 0;
	$sortname = isset($_GET['sortname']) ? intval($_GET['sortname']) : 0;

	$n = $m = 0;
	foreach($_GET['tempid'] as $key => $tempid) {
		if($tempid == $_GET['delete'][$tempid]) {
			C::t('#wq_channel#wq_channel_sorttemp')->delete($tempid);
		} else {
			$tempname = dhtmlspecialchars($_GET['tempname'][$tempid]);
			if(empty($tempname) || empty($_GET['tempname'][$tempid])) {
				$n ++;
				continue;
			}
			$data = array(
				'tempname' => $tempname,
				'temp' => $_GET['temp'][$tempid],
			);

			C::t('#wq_channel#wq_channel_sorttemp')->update($tempid, $data);
		}
	}
	foreach($_GET['inserttempname'] as $key => $val) {

		$tempname = dhtmlspecialchars($val);
		if(empty($tempname) || empty($_GET['inserttemp'][$key])) {
			$m ++;
			continue;
		}

		$data = array(
			'tempname' => $tempname,
			'temp' => $_GET['inserttemp'][$key],
		);
		$data['sortid'] = $sortid;
		$data['dateline'] = TIMESTAMP;

		C::t('#wq_channel#wq_channel_sorttemp')->insert($data);
	}

	if($n > 0 || $m > 0) {
		$msg = sprintf($Plang['61a06803c72ce433'], $n, $m);
		cpmsg($msg, $cpmsgurl, 'error');
	} else {
		cpmsg($Plang['8ee460c51dbd9dee'], $cpmsgurl, 'succeed');
	}
}
//From: Dism_taobao-com
?>