<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * Author: Xiaoan <577169944@qq.com>
 *
 * $Id: admincp_channel_list.inc.php 2016-03-17 16:00:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/config.php';
$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_channel&pmod=admincp_channel_block_import';
$cpurl = 'action=' . $url;
$ac = $_GET['ac'] ? dhtmlspecialchars($_GET['ac']) : '';
if($ac == "import") {
	DB::query("DELETE FROM " . DB::table('wq_channel_block'));
	DB::query("DELETE FROM " . DB::table('wq_channel_block_data'));

	loadcache('wq_channel_create_pages');
	$category = $_G['cache']['wq_channel_create_pages'];
	foreach($category as $key => $val) {
		$dels[] = $val['pageid'];
	}

	wq_channel_delete_pages($dels);
	C::t("common_syscache")->delete('wq_channel_create_pages');
	DB::query("truncate " . DB::table('wq_channel_pages'));
	DB::query("truncate " . DB::table('wq_channel_block'));
	DB::query("truncate " . DB::table('wq_channel_block_data'));

	if($_GET['type'] == 'wq_touch') {
		if(CHARSET == 'gbk') {
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_gbk.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_gbk.php";
				runquery($block_sql);
			}
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_gbk.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_gbk.php";
				foreach($arr as $key => $val) {
					wq_channel_updatechannel('', $val);
				}
			}
		} else {
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_utf8.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_utf8.php";
				runquery($block_sql);
			}
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_utf8.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_utf8.php";
				foreach($arr as $key => $val) {
					wq_channel_updatechannel('', $val);
				}
			}
		}
	}

	if($_GET['type'] == 'wq_app') {
		if(CHARSET == 'gbk') {
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_app_gbk.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_app_gbk.php";
				runquery($block_sql);
			}
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_app_gbk.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_app_gbk.php";
				foreach($arr as $key => $val) {
					wq_channel_updatechannel('', $val);
				}
			}
		} else {
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_app_utf8.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/block_data_app_utf8.php";
				runquery($block_sql);
			}
			if(file_exists(DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_app_utf8.php")) {
				include_once DISCUZ_ROOT . "./source/plugin/wq_channel/data/pages_app_utf8.php";
				foreach($arr as $key => $val) {
					wq_channel_updatechannel('', $val);
				}
			}
		}
	}
	@fopen('./data/channel_import.lock', 'wb ');
	cpmsg($Plang['99bc918c20c2b989'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_channel&pmod=admincp_channel_list', 'succeed');
}

if(!submitcheck('import_submit')) {
	showtips('<li>' . $Plang['c38e1fd1e2448d08'] . '</li><li>' . $Plang['06f0787769e1d2bb'] . '</li>');
	showtableheader();
	showformheader($url);
	showsubmit('import_submit', $Plang['cbc31093acd372cd']);
	showformfooter();
	showtablefooter();/*Dism��taobao��com*/
} else {
	if(file_exists("./data/channel_import.lock")) {
		cpmsg($Plang['a16e0ee669d287ac'], '', 'error', array(), $Plang['11754d531931de0f']);
	}

	$extra = <<<EOF
        <br/>
        <label class="lb" for="wq_touch"><input type="radio" id="wq_touch" name="type" value="wq_touch" checked/>{$Plang['4c0b83753488aba9']}</label><span style="margin-left:100px;">{$Plang['30bc04b216020826']}</span>
        <br />
        <label class="lb" for="wq_app"><input type="radio" id="wq_app" name="type" value="wq_app"/>{$Plang['c830954737f0ea08']}</label><span style="margin-left:100px;">{$Plang['d00b3d4833752987']}</span>
        <br/>
EOF;
	cpmsg($Plang['0ed298ebc335084a'], $cpurl . "&ac=import", 'form', array(), $extra);
}
//From: Dism_taobao-com
?>