<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_channel/class/base.class.php';

class plugin_wq_channel extends plugin_wq_channel_base {

	function common() {
		global $_G;
		if(CURSCRIPT == 'plugin' && ($_GET['id'] == 'wq_channel:wq_channel' || $_GET['id'] == 'wq_channel')) {
			$allowmod = array('index');
			$mod = !in_array($_GET['mod'], $allowmod) ? 'index' : $_GET['mod'];
			dsetcookie("wq_channel_template", $mod, 3600);
		}

		if(!empty($_G['cookie']['wq_channel_template'])) {
			if(CURSCRIPT == 'portal' && $_GET['mod'] == 'portalcp' && $_GET['ac'] == 'diy' && submitcheck('diysubmit')) {
				dsetcookie('wq_channel_template', '');
				$_POST['savemod'] = 1;
			}
		}
	}

}

class plugin_wq_channel_portal extends plugin_wq_channel {

	function portalcp_portal_common() {
		$wq_type = array('wqchannel_data', 'wqchannel_channellink', 'wqchannel_channelslide', 'wqchannel_channelbutton', 'wqchannel_channelad', 'wqchannel_channelclass');
		if($_GET['op'] == 'data' && $_GET['bid']) {
			$block = C::t('common_block')->fetch($_GET['bid']);
			if($block['blockclass'] == "wqchannel_data" || $block['blockclass'] == 'wqchannel_channelsort') {
				$_GET['op'] = 'block';
			}
		}
		if($_GET['op'] == 'block' && $_GET['blocksubmit']) {
			$wq_type = array('wqchannel_channellink', 'wqchannel_channelbutton', 'wqchannel_channelimgbut');
			if(in_array($_GET['toblockclass'], $wq_type)) {
				$issilde = $_GET['parameter']['issilde'] ? intval($_GET['parameter']['issilde']) : 0;
				$rows = $_GET['parameter']['rows'] ? intval($_GET['parameter']['rows']) : 1;
				$cols = $_GET['parameter']['cols'] ? intval($_GET['parameter']['cols']) : 2;

				if($_GET['toblockclass'] == 'wqchannel_channellink' && $rows > 1) {
					$issilde = $_POST['parameter']['issilde'] = 0;
				}
				$num = $rows * $cols;
				$_POST['shownum'] = $rows * $cols;
				if($issilde) {
					$num = $rows * $cols * 2;
					$_POST['shownum'] = $_GET['shownum'] > $num ? $_GET['shownum'] : $num;
				}
			}
			if($_GET['toblockclass'] == "wqchannel_channeladwrit") {
				$_POST['shownum'] = 1;
			}
		}
	}

	function portalcp_portal_output() {

		$wq_type = array('wqchannel_data', 'wqchannel_channelsort');
		if(in_array($_GET['classname'], $wq_type)) {
			global $is_htmlblock;
			$is_htmlblock = 1;
		}

		$wq_type2 = array('wqchannel_data');
		if($_GET['op'] == 'block' && $_GET['bid']) {
			$block = C::t('common_block')->fetch($_GET['bid']);
			if(in_array($block['blockclass'], $wq_type2)) {
				global $nocachetime, $showhtmltip;
				$nocachetime = true;
				$showhtmltip = true;
			}
		}
	}

}
//From: Dism_taobao-com
?>