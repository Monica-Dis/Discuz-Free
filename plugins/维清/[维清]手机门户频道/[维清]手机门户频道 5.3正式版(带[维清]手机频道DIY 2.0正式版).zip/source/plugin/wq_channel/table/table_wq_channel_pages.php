<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_channel_pages.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_channel_pages extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_channel_pages';
		$this->_pk = 'pageid';
		parent::__construct();
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t ", array($this->_table), $this->_pk);
	}

	public function fetch_by_name($name) {
		return DB::fetch_first("SELECT * FROM %t WHERE name=%s", array($this->_table, $name));
	}

	public function fetch_by_pageid($pageid) {
		return DB::fetch_first("SELECT * FROM %t WHERE pageid=%d", array($this->_table, $pageid));
	}

	public function fetch_by_pagename($pagename) {
		return DB::fetch_first("SELECT * FROM %t WHERE pagename=%s", array($this->_table, $pagename));
	}

	public function increase($ids, $data) {
		$ids = array_map('intval', (array) $ids);
		$sql = array();
		$allowkey = array('viewnum');
		foreach($data as $key => $value) {
			if(($value = intval($value)) && in_array($key, $allowkey)) {
				$sql[] = "`$key`=`$key`+'$value'";
			}
		}
		if(!empty($sql)) {
			DB::query('UPDATE ' . DB::table($this->_table) . ' SET ' . implode(',', $sql) . ' WHERE pageid IN (' . dimplode($ids) . ')', 'UNBUFFERED');
		}
	}

	public function fetch_all_by_search($orderby, $status, $username, $name, $start, $limit) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}

		if($status || $status !== '') {
			$sql[] = 'closed=%s';
			$val[] = $status;
		}

		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}

		if($name) {
			$sql[] = 'name LIKE %s';
			$val[] = '%' . $name . '%';
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($orderby, $status, $username, $name) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($orderby) {
			$order = ' ORDER BY `dateline` ' . $orderby . ' ';
		}

		if($status || $status !== '') {
			$sql[] = 'closed=%s';
			$val[] = $status;
		}

		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}

		if($name) {
			$sql[] = 'name LIKE %s';
			$val[] = '%' . $name . '%';
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>