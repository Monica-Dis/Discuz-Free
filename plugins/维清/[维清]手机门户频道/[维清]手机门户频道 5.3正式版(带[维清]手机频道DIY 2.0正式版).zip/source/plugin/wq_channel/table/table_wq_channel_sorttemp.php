<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_channel_sorttemp.php 2017-12-8 19:05:07Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_channel_sorttemp extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_channel_sorttemp';
		$this->_pk = 'tempid';
		parent::__construct();
	}

	public function fetch_all_by_search($sortid = 0, $tempid = 0, $start = 0, $limit = 0, $displayorder = 'dateline', $orderby = 'DESC') {
		$val[] = $this->_table;
		$sql[] = '1';

		if($orderby && $displayorder) {
			$order = ' ORDER BY `' . $displayorder . '` ' . $orderby . ' ';
		}

		if($sortid) {
			$sql[] = 'sortid=%d';
			$val[] = $sortid;
		}
		if($tempid) {
			$sql[] = 'tempid=%d';
			$val[] = $tempid;
		}


		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($sortid = 0, $tempid = 0) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($sortid) {
			$sql[] = 'sortid=%d';
			$val[] = $sortid;
		}
		if($tempid) {
			$sql[] = 'tempid=%d';
			$val[] = $tempid;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>