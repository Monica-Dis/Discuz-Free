<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_channel_pages.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_channel_block extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_channel_block';
		$this->_pk = 'bid';
		parent::__construct();
	}

	public function fetch_all_by_type($type) {
		return DB::fetch_all("SELECT * FROM %t WHERE status=1 AND type=%d ORDER BY displayorder ASC ", array($this->_table, $type));
	}

	public function fetch_all_by_search($blockname, $type, $username, $start, $limit, $displayorder = "displayorder", $orderby = "ASC") {
		$val[] = $this->_table;
		$sql[] = '1';

		if($orderby) {
			$order = ' ORDER BY ' . $displayorder . " " . $orderby . ' ';
		}

		if($type) {
			$sql[] = 'type=%d';
			$val[] = $type;
		}
		if($blockname) {
			$sql[] = 'blockname=%s';
			$val[] = $blockname;
		}
		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($blockname, $type, $username) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($type) {
			$sql[] = 'type=%d';
			$val[] = $type;
		}
		if($blockname) {
			$sql[] = 'blockname=%s';
			$val[] = $blockname;
		}
		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>