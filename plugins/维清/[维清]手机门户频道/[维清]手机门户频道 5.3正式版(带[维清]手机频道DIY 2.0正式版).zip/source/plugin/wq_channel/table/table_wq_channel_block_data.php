<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_channel_pages.php 2016-1-15 04:24:10Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_channel_block_data extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_channel_block_data';
		$this->_pk = 'did';
		parent::__construct();
	}

	public function fetch_all_by_search($bid, $start = 0, $limit = 0, $displayorder = "displayorder", $orderby = "ASC") {
		$val[] = $this->_table;
		$sql[] = '1';

		if($orderby) {
			$order = ' ORDER BY ' . $displayorder . " " . $orderby . ' ';
		}
		if($bid) {
			$sql[] = 'bid=%d';
			$val[] = $bid;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($bid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($bid) {
			$sql[] = 'bid=%d';
			$val[] = $bid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_by_dids($dids) {
		return DB::fetch_all("SELECT * FROM %t WHERE did IN(%n) ", array($this->_table, $dids), $this->_pk);
	}

	public function fetch_by_bid($bid) {
		return DB::fetch_all("SELECT * FROM %t WHERE bid=%d ", array($this->_table, $bid), $this->_pk);
	}

}
//From: Dism_taobao-com
?>