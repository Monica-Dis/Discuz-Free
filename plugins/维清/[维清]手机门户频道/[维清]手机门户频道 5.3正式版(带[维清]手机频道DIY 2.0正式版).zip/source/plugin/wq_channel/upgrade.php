<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_channel/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':

		$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_wq_channel_sorttemp` (
    `tempid` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `sortid` int(10) unsigned NOT NULL,
    `tempname` varchar(255) NOT NULL,
    `temp` text NOT NULL,
    `dateline` int(10) unsigned NOT NULL,
    PRIMARY KEY (`tempid`),
    KEY `sortid` (`sortid`),
    KEY `tempname` (`tempname`),
    KEY `dateline` (`dateline`)
) ENGINE=MyISAM;
EOF;
		runquery($sql);
		require_once DISCUZ_ROOT . './source/plugin/wq_channel/function/function_channel.php';
		wq_channel_create_template();

		if($_GET['fromversion'] <= 1.0) {
			loadcache('plugin');
			if($_G['cache']['plugin']['wq_app_setting']) {
				wq_channel_insert_footer_menu("wq_app_setting", "wq_app_setting_menumanage", "wq_app_menulist");
			}
		}
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//From: Dism_taobao-com
?>