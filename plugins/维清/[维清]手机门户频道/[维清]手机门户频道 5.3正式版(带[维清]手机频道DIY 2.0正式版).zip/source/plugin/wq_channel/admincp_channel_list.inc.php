<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * Author: Xiaoan <577169944@qq.com>
 *
 * $Id: admincp_channel_list.inc.php 2016-03-17 16:00:31Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_channel/config/config.php';
$wq_rewrite_setting = dunserialize($_G['setting']['wq_rewrite_setting']);

if(!submitcheck('submitform')) {
	$orderby = in_array($_GET['orderby'], array('asc', 'desc')) ? $_GET['orderby'] : 'asc';
	$status = in_array($_GET['status'], array('all', '1', '0')) ? (($_GET['status'] != 'all') ? $_GET['status'] : '') : '';
	$username = isset($_GET['username']) ? trim($_GET['username']) : '';
	$name = isset($_GET['name']) ? trim($_GET['name']) : '';
	$page = max(1, $_GET['page']);
	$perpage = $setting['admincp_perpage'];
	$start = ($page - 1 ) * $perpage;

	$list = C::t("#wq_channel#wq_channel_pages")->fetch_all_by_search($orderby, $status, $username, $name, $start, $perpage);
	$count = C::t("#wq_channel#wq_channel_pages")->count_by_search($orderby, $status, $username, $name);

	$formurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_channel&pmod=admincp_channel_list';
	$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_channel&pmod=admincp_channel_list';
	$mpurl .= $orderby ? "&orderby=" . $orderby : '';
	$mpurl .= $status !== '' ? "&status=" . $status : '';
	$mpurl .= $username ? "&username=" . $username : '';
	$mpurl .= $name ? "&name=" . $name : '';
	$url = ADMINSCRIPT . '?' . $mpurl;

	$order_by = select_html(array('asc' => $Plang['60f4919063d76ce2'], 'desc' => $Plang['5bee37fbebf639d9']), 'orderby', $orderby, false);
	$_status = select_html(array('all' => $Plang['8dfe4b30674494c1'], '1' => $Plang['closed_1'], '0' => $Plang['closed_0']), 'status', $status, false);
	showformheader($formurl, '', 'form');
	showtableheader('', 'nobottom');
	showtablerow('', array(), array(
		$Plang['b39184ab74d5ee28'] . '&nbsp;&nbsp;' . $order_by
		. '&nbsp;&nbsp;' . $Plang['b8286c23351e4cd4'] . '&nbsp;&nbsp;' . $_status
		. '&nbsp;&nbsp;' . $Plang['ec2a06a29ed01d3f'] . '&nbsp;&nbsp;<input type="text" name="username" value="' . dhtmlspecialchars($_GET['username']) . '" placeholder=' . $Plang['b32cac8b17b85523'] . '>'
		. '&nbsp;&nbsp;' . $Plang['1508bb7d28053617'] . '&nbsp;&nbsp;<input type="text" name="name" value="' . dhtmlspecialchars($_GET['name']) . '"  placeholder=' . $Plang['35f9f8eccdb95686'] . '>'
		. $Plang['f67ed51610562480']
		. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="form" value=' . $Plang['38224a4a6fc78c7c'] . '>',
	));
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();

	showformheader($formurl, '', 'submitform');
	showtableheader($Plang['e520adedb1c39b6c'], 'nobottom');
	showsubtitle(array('', $Plang['803ed14idididsdk'], $Plang['803ed140ac3387ac'], $Plang['12e961826e8b8a59'], $Plang['jgkjhgkguuuhghkg'], $Plang['352f28971b7f66d3'], $Plang['61c132480296f914'], $Plang['486f9c6b76207a86'], $Plang['83f1e7a6a15f1d8a'], $Plang['ca5a0d75b677d381'], $Plang['4e64f0e320d8b16b']));
	foreach($list as $key => $val) {
		$seturl = wq_channel_get_pages_url($val, $val['pageid']);
		showtablerow('', array('width="40px"', 'width="60px"'), array(
			'<input type="checkbox" class="checkbox" name="pageids[]" value="' . $val['pageid'] . '" />',
			"<a href=\"$seturl\" target=\"_blank\">" . $val['pageid'] . "</a>",
			"<a href=\"$seturl\" target=\"_blank\">" . $val['title'] . "</a>",
			$val['name'],
			$val['pagename'],
			$val['foldername'],
			"<a href=\"home.php?mod=space&uid=$val[uid]&do=profile\" target=\"_blank\">$val[username]</a>",
			dgmdate($val[dateline]),
			"<input name=\"setindex\" class=\"radio\" type=\"radio\" value=\"$val[pageid]\"" . ($_G['setting']['defaultmobileindex'] == $seturl ? ' checked="checked"' : '') . " />",
			"[" . $Plang['closed_' . $val['closed']] . "]",
			" <a href=\"plugin.php?id=wq_channel&mod=create&pageid=$val[pageid]\" target=\"_blank\">" . $Plang['9a150d4af72d7358'] . "</a>&nbsp;" .
			" <a href=\"plugin.php?id=wq_channel&mod=index&pageid=$val[pageid]&ac=diy&diy=yes\" target=\"_blank\">DIY</a>&nbsp;",
		));
	}

	$ops = $Plang['4e64f0e320d8b16b'] . ': '
		. "<input type='radio' class='radio' name='optype' value='open' id='op_close' /><label for='op_close'>" . $Plang['closed_0'] . "</label>&nbsp;&nbsp;"
		. "<input type='radio' class='radio' name='optype' value='close' id='op_open' /><label for='op_open'>" . $Plang['closed_1'] . "</label>&nbsp;&nbsp;"
		. "<input type='radio' class='radio' name='optype' value='delete' id='op_delete' /><label for='op_delete'>" . $Plang['0d9efacf5089d88c'] . "</label>&nbsp;&nbsp;";

	echo '<tr><td colspan = "1"></td><td colspan = "15"><div><a class = "addtr" target="_blank" href="plugin.php?id=wq_channel&mod=create">' . $Plang['090925949ef128d9'] . '</a></div></td></tr>';
	$multi = multi($count, $perpage, $page, $url);
	showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'pageids\')" /><label for="chkall">' . $Plang['8dfe4b30674494c1'] . '</label>&nbsp;&nbsp;' . $ops . '<input type="submit" class="btn" name="submitform" value="' . $Plang['2e53326577b64980'] . '" />', $multi);
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$url = "action=plugins&operation=config&do=" . $pluginid . "&identifier=wq_channel&pmod=admincp_channel_list";

	if($_GET['setindex']) {
		$setindex = C::t("#wq_channel#wq_channel_pages")->fetch_by_pageid($_GET['setindex']);
		$setindexid = isset($_GET['setindex']) ? intval($_GET['setindex']) : 0;
		$seturl = wq_channel_get_pages_url($setindex, $setindexid);
		wq_channel_set_setting_defaultmobileindex($seturl);
	}

	if($_POST['optype'] == 'delete') {
		wq_channel_delete_pages($_POST['pageids']);
		cpmsg($Plang['1cd784366a335e8a'], $url, 'succeed');
	} elseif($_POST['optype'] == 'close') {
		C::t("#wq_channel#wq_channel_pages")->update($_POST['pageids'], array('closed' => 1));
		wq_channel_save_pages();
		cpmsg($Plang['1170410ae399142c'], $url, 'succeed');
	} elseif($_POST['optype'] == 'open') {
		C::t("#wq_channel#wq_channel_pages")->update($_POST['pageids'], array('closed' => 0));
		wq_channel_save_pages();
		cpmsg($Plang['ddf8228f9d37836b'], $url, 'succeed');
	} else {
		cpmsg($Plang['8ee460c51dbd9dee'], $url, 'succeed');
	}
}
//From: Dism_taobao-com
?>