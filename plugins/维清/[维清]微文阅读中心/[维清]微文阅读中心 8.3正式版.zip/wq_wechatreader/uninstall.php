<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatreader/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		if(is_file($filepath = DISCUZ_ROOT . './source/plugin/wq_addon_client/function/admincp/function_wikinaddons.php')) {
			require_once $filepath;
			wikinaddons_removelog('wq_wechatreader.plugin');
		}
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_wechatreader_classname`;
DROP TABLE IF EXISTS `pre_wq_wechatreader_favorites`;
DROP TABLE IF EXISTS `pre_wq_wechatreader_favoritesname`;
DROP TABLE IF EXISTS `pre_wq_wechatreader_keyword`;
DROP TABLE IF EXISTS `pre_wq_wechatreader_poll`;
DROP TABLE IF EXISTS `pre_wq_wechatreader_subscription`;
EOF;
		runquery($sql);
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_wechatreader.php");
		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//From: Dism_taobao-com
?>