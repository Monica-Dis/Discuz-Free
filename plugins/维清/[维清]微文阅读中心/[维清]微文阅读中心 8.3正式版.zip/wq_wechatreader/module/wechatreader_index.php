<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_index.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$ac = in_array($_GET['ac'], array('read', 'fav', 'focus')) ? $_GET['ac'] : '';
$op = in_array($_GET['op'], array('public', 'article', 'edit', 'move', 'create', 'rename', 'del', 'manage', 'search', 'first')) ? $_GET['op'] : '';

if(!$_G['mobile'] && $ac == '') {
	$ac = "focus";
	$op = "article";
}

$referer = dreferer();
$referer = urlencode($referer);

$navtitle = $Plang['wechatreader'];
if($ac == 'read') {
	$webpagename = $Plang['my_subscriptions'];
	$cache = $keywords;
	$list = array();
	if(!empty($cache)) {
		$perpage = $setting['home_keywrod_perpage'];
		$page = max(1, $_GET['page']);
		$start = ($page - 1) * $perpage;
		$maxperpage = $start + $perpage;
		$mpurl = 'plugin.php?id=wq_wechatreader&mod=index&ac=read';
		$count = count($cache);
		for($j = $start; $j < $maxperpage; $j ++) {
			if(empty($cache[$j])) {
				continue;
			}
			$preg = '/' . $cache[$j] . '/i';
			$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_search(array(1), 0, 3, $cache[$j], 'collecttime', '');
			if(!empty($article)) {
				foreach($article as $key => $value) {
					$article[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($value['imglink']);
					preg_match_all($preg, $value['title'], $title_result);
					foreach(array_unique($title_result[0]) as $val) {
						$article[$key]['title'] = str_replace($val, '<span>' . $val . '</span>', $value['title']);
					}
					if($key == 0) {
						preg_match_all($preg, $value['summary'], $summary_result);
						foreach(array_unique($summary_result[0]) as $val) {
							$article[$key]['summary'] = str_replace($val, '<span>' . $val . '</span>', $value['summary']);
						}
					}
				}
				$list[$cache[$j]] = $article;
			}
		}
	}

	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'pagename' => $webpagename);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $wechatreader_seo['list_keyword']);
} elseif($ac == 'focus') {
	if($op == "public") {
		$webpagename = $Plang['focus_wechat'];
		$perpage = $setting['home_focus_perpage'];
		$page = max(1, $_GET['page']);
		$start = ($page - 1) * $perpage;
		$maxperpage = $start + $perpage;
		$favoritesid = $cid = $_GET['cid'] || $_GET['cid'] === '0' ? intval($_GET['cid']) : '';
		$mpurl = 'plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid=' . $cid;
		$default_num = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_default_num_by_uid($_G['uid']);
		$default_num = $default_num > 0 ? $default_num : '';
		$classlist = C::t('#wq_wechatreader#wq_wechatreader_classname')->fetch_all_by_uid($_G['uid']);
		$Plang['2dc3f83a42b3a77f'] = $Plang['f6fa27d3fe7c0c6d'];
		$favname = $cid === "" ? $Plang['a1e5d76323a1fd8d'] : ($cid === 0 ? $Plang['045ee7924f2db654'] : $classlist[$cid]['classname']);
		if(($_GET['sub'] == 'manage' || $_GET['sub'] == 'move') && $_G['mobile']) {
			$default_font = $Plang['045ee7924f2db654'];
			$favoriteslist = $classlist;
			$_key = 'classname';
		}
		if(in_array($_GET['sub'], array('manage', 'edit', 'move')) && $_G['mobile']) {
			$_GET['ac'] = 'temvar';
		}

		$wids = C::t('#wq_wechatreader#wq_wechatreader_subscription')->fetch_all_wid_by_uid_cid($_G['uid'], $cid);
		$list = $subscription = $fav = array();
		foreach($wids as $key => $value) {
			$subscription[] = $value['wid'];
			$fav[$value['wid']] = $value['cid'];
		}
		if($subscription) {
			$count = count($subscription);
			for($i = $start; $i < $maxperpage; $i ++) {
				if(!empty($subscription[$i])) {
					$cache_subscription[] = $subscription[$i];
				}
			}
			foreach($cache_subscription as $key => $val) {
				$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($val);
				if(!empty($wechat)) {
					$wechat['qrcode'] = wq_get_qrcode_by_wechatid($wechat['wechatid']);
					$wechat['headimage'] = wq_wechatcollecting_headimg_and_bgimg_url($wechat['headimage']);
					$wechat['wechatbgimg'] = wq_wechatcollecting_headimg_and_bgimg_url($wechat['wechatbgimg']);
					$list[] = $wechat;
				}
			}
		}

		foreach($list as $key => $val) {
			$list[$key]['cid'] = $fav[$val['id']];
			$classname = $fav[$val['id']] == 0 ? $Plang['045ee7924f2db654'] : $classlist[$fav[$val['id']]]['classname'];
			$list[$key]['classname'] = $classname;
		}
	} elseif($op == "article") {
		$list = array();
		$type = in_array($_GET['type'], array("first", "all")) ? trim($_GET['type']) : "first";
		if($subscription) {
			$plugin_wechatreader = 1;
			$webpagename = $Plang['focus_wechat_article_' . $type];
			$perpage = $setting['home_focus_article_perpage'];
			$page = max(1, $_GET['page']);
			$start = ($page - 1) * $perpage;
			$isfirst = $type == 'first' ? 1 : 0;
			$mpurl = 'plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=' . $type;
			$list = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_in_wid_isfirst($subscription, $start, $perpage, $isfirst);
			foreach($list as $key => $val) {
				$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
			}
			$count = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_in_wid_isfirst($subscription, $isfirst);
		}
		$Plang['2dc3f83a42b3a77f'] = $Plang['879dcbc7097db534'];
	}
	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'pagename' => $webpagename);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $wechatreader_seo['list_wechat']);
} elseif($ac == 'fav') {
	$plugin_wechatreader = 1;
	$webpagename = $Plang['my_favorite'];
	$list = array();
	$favoritesid = $_GET['favoritesid'] || $_GET['favoritesid'] === '0' ? intval($_GET['favoritesid']) : '';
	if($_G['mobile']) {
		$_GET['keyword'] = diconv($_GET['keyword'], "UTF-8", CHARSET);
	}

	$keyword = isset($_GET['keyword']) ? dhtmlspecialchars($_GET['keyword']) : '';
	$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);

	$Plang['2dc3f83a42b3a77f'] = $Plang['favoritesname_no_article'];
	$perpage = $setting['home_favorites_perpage'];
	$page = max(1, $_GET['page']);
	$start = ($page - 1) * $perpage;
	$mpurl = 'plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid=' . $favoritesid;
	$default_num = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_default_num_by_uid($_G['uid']);
	$default_num = $default_num > 0 ? $default_num : '';
	$favoriteslist = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->fetch_all_by_uid($_G['uid']);

	$_key = 'favoritesname';
	$default_font = $Plang['f11bb8f10ab80417'];

	$favname = $favoritesid === "" ? $Plang['fa18659e0a4166c6'] : ($favoritesid === 0 ? $Plang['f11bb8f10ab80417'] : $favoriteslist[$favoritesid]['favoritesname']);
	$aids = C::t('#wq_wechatreader#wq_wechatreader_favorites')->fetch_all_aid_by_uid_favoritesid($_G['uid'], $favoritesid);

	$fav = array();
	foreach($aids as $key => $value) {
		$aidarr[] = $value['articleid'];
		$fav[$value['articleid']] = $value['favoritesid'];
	}

	if(count($aidarr) > 0) {
		$temlist = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_all_by_articleid($aidarr);
	}

	if($op == 'search' && $keyword == '') {
		$preg = '/' . $keyword . '/i';
		foreach($temlist as $key => $val) {
			preg_match_all($preg, $val['title'], $title_result);
			foreach(array_unique($title_result[0]) as $value) {
				$val['title'] = str_replace($value, '<span style="color:#F00;">' . $value . '</span>', $val['title']);
				$newlist[] = $val;
			}
		}
	} else {
		$newlist = $temlist;
	}

	$count = count($newlist);
	$list = array_slice($newlist, $start, $perpage);

	foreach($list as $key => $val) {
		$list[$key]['imglink'] = wq_wechatcollecting_headimg_and_bgimg_url($val['imglink']);
		$list[$key]['favoritesid'] = $fav[$val['articleid']];
		$favoritesname = $fav[$val['articleid']] == 0 ? $Plang['f11bb8f10ab80417'] : $favoriteslist[$fav[$val['articleid']]]['favoritesname'];
		$list[$key]['favoritesname'] = $favoritesname;
	}

	if($favoritesid === '' && !$list) {
		$Plang['2dc3f83a42b3a77f'] = $Plang['sorry_no_collectarticle'];
	}
	$_GET['newac'] = $_GET['iswechat'] ? 'wechatcollect' : 'collect';
	$create_font = $_GET['iswechat'] ? $Plang['18b99e1fb0b3bc15'] : $Plang['ea339c4a9b8d0bb0'];
	$delfolder_font = $_GET['iswechat'] ? $Plang['ad4da92a313a68fb'] : $Plang['47d382b5410ff5b3'];
	$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'pagename' => $webpagename);
	list($navtitle, $metadescription, $metakeywords) = get_seosetting('', $seodata, $wechatreader_seo['list_article']);
}

$multi = multi($count, $perpage, $page, $mpurl);
if($_G['mobile']) {
	include template('wq_wechatreader:wechatreader_index');
} else {
	include template('diy:wechatreader_index', 0, 'source/plugin/wq_wechatreader/template');
}
//From: Dism_taobao-com
?>