<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatcollecting_index.php 2015-4-15 14:25:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_G['uid'])) {
	if($_G['mobile']) {
		dheader("Location:member.php?mod=logging&action=login&mobile=2");
	}
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
if($_GET['ac'] == 'collect') {
	if(submitcheck('newfavoritesname')) {
		$aid = intval($_GET['aid']);
		$yid = intval($_GET['yid']);
		$isview = $_GET['isview'] == 1 ? 1 : 0;
		$favoritesname = trim($_GET['newname']);
		$favoritesid = intval($_GET['favoritesid']) > 0 ? intval($_GET['favoritesid']) : 0;
		if(($_GET['operationtype'] == 'create' || $_GET['operationtype'] == 'rename') && !$favoritesname) {
			showmessage($Plang['765b270e45e3c931']);
		}
		if($_GET['operationtype'] == 'rename') {
			$result = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->update($favoritesid, array('favoritesname' => $favoritesname));
			$result ? showmessage($Plang['43f86renamed4ff'], '', array('id' => $favoritesid, 'name' => $favoritesname)) : showmessage($Plang['b037c98130120ea3']);
		}
		if(!$_GET['del'] && !$yid) {
			$article = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_articleid($aid);
			if(empty($article) || $article['status'] != 1) {
				showmessage($Plang['sorry_no_article']);
			}
			$favorites = C::t('#wq_wechatreader#wq_wechatreader_favorites')->fetch_first_by_where($aid, $_G['uid']);
			if($favorites) {
				showmessage($Plang['sorry_you_collect']);
			}
		}
		if($favoritesname) {
			$add = array(
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'favoritesname' => $favoritesname,
				'dateline' => TIMESTAMP
			);
			$favoritesid = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->insert($add, true);

			if($_G['mobile']) {
				$favoritesid ? showmessage($Plang['43f8689c027bd4ff'], '', array('id' => $favoritesid, 'name' => $favoritesname)) : showmessage($Plang['8ba6275415742397']);
			}
		}
		if(!$_GET['del'] && !$yid) {
			$data = array(
				'favoritesid' => $favoritesid,
				'articleid' => $aid,
				'username' => $_G['username'],
				'time' => TIMESTAMP,
				'uid' => $_G['uid'],
			);
			$collect = C::t('#wq_wechatreader#wq_wechatreader_favorites')->insert($data, true);
			if($collect) {
				$art_fav_count = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_by_aid($aid);
				C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, array('favorites' => $art_fav_count));
			}
			if($favoritesid && $collect) {
				$favname_count = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_default_num_by_uid($_G['uid'], $favoritesid);
				C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->update($favoritesid, array('favoritesnum' => $favname_count));
			}
			cache_wq_wechatreader_favorites($_G['uid']);
			if($_G['mobile']) {
				showmessage($Plang['50434686adcc5824']);
			} else {
				$extrajs = '<script type="text/javascript" reload="1">'
					. 'collect(' . $aid . ',' . $isview . ');'
					. '</script>';
				showmessage('favorite_do_success', '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
			}
		} else {
			$y_favorites = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->fetch_by_uid_id($_G['uid'], $yid);
			if($y_favorites) {
				$new_data = null;
				if($favoritesid) {
					$val = array("wq_wechatreader_favoritesname", "`favoritesnum`=`favoritesnum`+" . $y_favorites['favoritesnum'], $favoritesid, $_G['uid']);
					DB::query('UPDATE %t SET %i WHERE id=%d AND uid=%d', $val);
					$new_data = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->fetch_by_uid_id($_G['uid'], $favoritesid);
				}
				$val = array("wq_wechatreader_favorites", "`favoritesid`=" . $favoritesid, $yid, $_G['uid']);
				DB::query('UPDATE %t SET %i WHERE favoritesid=%d AND uid=%d', $val);
				C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->delete($yid);
				cache_wq_wechatreader_favorites($_G['uid']);

				if($new_data) {
					$countnum = $new_data['favoritesnum'];
					$newname = $new_data['favoritesname'];
				} else {
					$countnum = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_default_num_by_uid($_G['uid']);
					$newname = $Plang['f11bb8f10ab80417'];
				}
				$re_data = array(
					'yid' => $yid,
					'newid' => $favoritesid,
					'num' => $countnum,
					'newname' => diconv($newname, CHARSET, 'utf-8'),
					'wechat' => 0
				);

				$re_data = json_encode($re_data);
				$extrajs = '<script type="text/javascript" reload="1">'
					. 'del_favorites_name(' . $re_data . ');'
					. '</script>';
				showmessage($Plang['del_succeed'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
			} else {
				showmessage($Plang['del_favorite_empty']);
			}
		}
	} else {
		$list = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->fetch_all_by_uid($_G['uid']);
		$default_num = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_default_num_by_uid($_G['uid']);
		$add_arr = array(
			'id' => 0,
			'favoritesname' => $Plang['f11bb8f10ab80417'],
			'favoritesnum' => intval($default_num)
		);
		$h3_title = $Plang['0c9e285b4d5083fb'];
		if($_GET['del']) {
			$tem_name = $list[$_GET['favoritesid']]['favoritesname'];
			unset($list[$_GET['favoritesid']]);
			$h3_title = sprintf($Plang['del_favorite_tps'], $tem_name);
		}
		$add_font = $_G['mobile'] ? $Plang['4debf7dc8c9fd7c0'] : $Plang['af0bb59861c631a7'];
		array_unshift($list, $add_arr);
		$unit_font = $Plang['0c8cdbbecad45954'];
		$ac = $newac = 'collect';
		$_key = 'favoritesname';
		$iswechat = 0;
		include_once template('wq_wechatreader:wq_wechatreader_favorites');
	}
} else if($_GET['ac'] == 'canclecollect') {
	$aid = $_GET['aid'];
	if($aid <= 0) {
		showmessage($Plang['sorry_no_article']);
	}
	$favorites = C::t('#wq_wechatreader#wq_wechatreader_favorites')->fetch_first_by_where($aid, $_G['uid']);
	if(!empty($favorites)) {
		$delete = C::t('#wq_wechatreader#wq_wechatreader_favorites')->delete(intval($favorites['id']));
		$art_fav_count = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_by_aid($aid);
		C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, array('favorites' => $art_fav_count));
		if($favorites['favoritesid']) {
			$favname_count = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_default_num_by_uid($_G['uid'], $favorites['favoritesid']);
			C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->update($favorites['favoritesid'], array('favoritesnum' => $favname_count));
		}
		$url = $_GET['step'] == '1' ? 'plugin.php?id=wq_wechatreader&mod=index&step=1' : '/';
		$extrajs = '<script type="text/javascript" reload="1">'
			. 'canclecollect(' . $aid . ');'
			. '</script>';
		cache_wq_wechatreader_favorites($_G['uid']);

		if($_G['mobile']) {
			showmessage($Plang['bef022f6310db3b9'], '', array('aid' => $aid));
		}
		showmessage($Plang['cancel_successful'], $url, array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
	} else {
		showmessage($Plang['sorry_no_collectarticle']);
	}
} elseif($_GET['ac'] == 'subscription') {
	$referer = '';


	if($_G['mobile']) {
		$referer = dreferer();
		$_GET['keyword'] = diconv($_GET['keyword'], "UTF-8", CHARSET);
	}
	$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
	$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);

	if(empty($keyword)) {
		showmessage($Plang['sorry_no_keyword']);
	}

	$articlenum = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->count_by_search(array(1), $keyword);
	if($articlenum <= 0) {
		showmessage($Plang['sorry_keyword_no_article']);
	}

	$subscription = C::t('#wq_wechatreader#wq_wechatreader_keyword')->fetch_first_by_where($keyword, $_G['uid']);

	if(empty($subscription)) {
		$data = array(
			'keyword' => $keyword,
			'username' => $_G['username'],
			'time' => time(),
			'uid' => $_G['uid'],
		);
		$subscription_keyword = C::t('#wq_wechatreader#wq_wechatreader_keyword')->insert($data);
		cache_wq_wechatreader_keywords($_G['uid']);
		$extrajs = '<script type="text/javascript">'
			. 'subscription_keyword();'
			. '</script>';
		showmessage($Plang['subscription_successfully'], $referer, array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
	} else {
		showmessage($Plang['sorry_you_subscription']);
	}
} elseif($_GET['ac'] == 'unsubscribe') {
	if($_G['mobile']) {
		$_GET['keyword'] = diconv($_GET['keyword'], 'utf-8', CHARSET);
	}
	$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
	$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
	if(empty($keyword)) {
		$result = array('code' => -1, 'msg' => diconv($Plang['sorry_no_keyword'], CHARSET, 'utf-8'));
		echo json_encode($result);
		exit;
	}
	$subscription = C::t('#wq_wechatreader#wq_wechatreader_keyword')->fetch_first_by_where($keyword, $_G['uid']);

	if(!empty($subscription)) {
		$delete = C::t('#wq_wechatreader#wq_wechatreader_keyword')->delete(intval($subscription['id']));
		cache_wq_wechatreader_keywords($_G['uid']);
		$result = array('code' => 0, 'msg' => diconv($Plang['cancel_successful'], CHARSET, 'utf-8'));
		echo json_encode($result);
		exit;
	} else {
		$result = array('code' => -1, 'msg' => diconv($Plang['sorry_you_keyword'], CHARSET, 'utf-8'));
		echo json_encode($result);
		exit;
	}
} elseif($_GET['ac'] == 'wechatcollect') {
	if(submitcheck('newfavoritesname')) {
		$yid = intval($_GET['yid']);
		$wid = $_GET['aid'];
		$classname = trim($_GET['newname']);
		$cid = intval($_GET['favoritesid']) > 0 ? intval($_GET['favoritesid']) : 0;
		if(($_GET['operationtype'] == 'create' || $_GET['operationtype'] == 'rename') && !$classname) {
			showmessage($Plang['60ae12f2cc7b7836']);
		}
		if($_GET['operationtype'] == 'rename') {
			$result = C::t('#wq_wechatreader#wq_wechatreader_classname')->update($cid, array('classname' => $classname));
			$result ? showmessage($Plang['43f86renamed4ff'], '', array('id' => $cid, 'name' => $classname)) : showmessage($Plang['b037c98130120ea3']);
		}
		if(!$_GET['del'] && !$yid) {
			$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($wid);
			if(empty($wechat) || $wechat['status'] != 1) {
				showmessage($Plang['sorry_no_wechat']);
			}

			$wechatcollect = C::t('#wq_wechatreader#wq_wechatreader_subscription')->fetch_first_by_where($wid, $_G['uid']);
			if(!empty($wechatcollect)) {
				showmessage($Plang['sorry_you_attention']);
			}
		}
		if($classname) {
			$add = array(
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'classname' => $classname,
				'dateline' => TIMESTAMP
			);
			$cid = C::t('#wq_wechatreader#wq_wechatreader_classname')->insert($add, true);
			if($_G['mobile']) {
				$cid ? showmessage($Plang['43f8689c027bd4ff'], '', array('id' => $cid, 'name' => $classname)) : showmessage($Plang['8ba6275415742397']);
			}
		}
		if(!$_GET['del'] && !$yid) {
			$data = array(
				'wid' => $wid,
				'cid' => $cid,
				'username' => $_G['username'],
				'time' => time(),
				'uid' => $_G['uid'],
			);
			$subscription = C::t('#wq_wechatreader#wq_wechatreader_subscription')->insert($data);
			if($collecting_setting['wechatcollect_randomnum']) {
				$count = $wechat['favorites'] + 1;
			} else {
				$count = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_by_wid($wid);
			}
			C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, array('favorites' => $count));
			if($cid && $subscription) {
				$classname_count = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_default_num_by_uid($_G['uid'], $cid);
				C::t('#wq_wechatreader#wq_wechatreader_classname')->update($cid, array('favoritesnum' => $classname_count));
			}
			C::memory()->clear();
			cache_wq_wechatreader_subscription($_G['uid']);
			$extrajs = '<script type="text/javascript" reload="1">'
				. 'wechatattention(' . $wid . ');'
				. '</script>';
			if($_G['mobile']) {
				showmessage($Plang['attention_do_success']);
			} else {
				showmessage($Plang['attention_do_success'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
			}
		} else {
			$y_class = C::t('#wq_wechatreader#wq_wechatreader_classname')->fetch_by_uid_id($_G['uid'], $yid);
			if($y_class) {
				$new_data = null;
				if($cid) {
					$val = array("wq_wechatreader_classname", "`favoritesnum`=`favoritesnum`+" . $y_class['favoritesnum'], $cid, $_G['uid']);
					DB::query('UPDATE %t SET %i WHERE id=%d AND uid=%d', $val);
					$new_data = C::t('#wq_wechatreader#wq_wechatreader_classname')->fetch_by_uid_id($_G['uid'], $cid);
				}
				$val = array("wq_wechatreader_subscription", "`cid`=" . $cid, $yid, $_G['uid']);
				DB::query('UPDATE %t SET %i WHERE cid=%d AND uid=%d', $val);
				C::t('#wq_wechatreader#wq_wechatreader_classname')->delete($yid);
				cache_wq_wechatreader_subscription($_G['uid']);

				if($new_data) {
					$countnum = $new_data['favoritesnum'];
					$newname = $new_data['classname'];
				} else {
					$countnum = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_default_num_by_uid($_G['uid']);
					$newname = $Plang['045ee7924f2db654'];
				}
				$re_data = array(
					'yid' => $yid,
					'newid' => $cid,
					'num' => $countnum,
					'newname' => diconv($newname, CHARSET, 'utf-8'),
					'wechat' => 1
				);
				$re_data = json_encode($re_data);
				$extrajs = '<script type="text/javascript" reload="1">'
					. 'del_favorites_name(' . $re_data . ');'
					. '</script>';
				showmessage($Plang['del_succeed'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
			} else {
				showmessage($Plang['f24a49d3695feb19']);
			}
		}
	} else {
		$list = C::t('#wq_wechatreader#wq_wechatreader_classname')->fetch_all_by_uid($_G['uid']);
		$default_num = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_default_num_by_uid($_G['uid']);
		$add_arr = array(
			'id' => 0,
			'classname' => $Plang['045ee7924f2db654'],
			'favoritesnum' => intval($default_num)
		);
		$h3_title = $Plang['779fc459ce121b4e'];
		if($_GET['del']) {
			$tem_name = $list[$_GET['favoritesid']]['classname'];
			unset($list[$_GET['favoritesid']]);
			$h3_title = sprintf($Plang['d25c3f2dfc3069d8'], $tem_name);
		}
		$add_font = $Plang['39e2173c238f8410'];
		array_unshift($list, $add_arr);
		$unit_font = $Plang['b79f06441a6aa34a'];
		$ac = $newac = 'wechatcollect';
		$_GET['aid'] = $_GET['wid'];
		$_key = 'classname';
		$iswechat = 1;
		include_once template('wq_wechatreader:wq_wechatreader_favorites');
	}
} elseif($_GET['ac'] == 'canclecowechat') {
	$wid = $_GET['wid'];
	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($wid);
	if(empty($wechat)) {
		showmessage($Plang['sorry_no_wechat']);
	}

	$wechatcollect = C::t('#wq_wechatreader#wq_wechatreader_subscription')->fetch_first_by_where($wid, $_G['uid']);
	if(!empty($wechatcollect)) {
		$delete = C::t('#wq_wechatreader#wq_wechatreader_subscription')->delete(intval($wechatcollect['id']));
		if($collecting_setting['wechatcollect_randomnum']) {
			$count = $wechat['favorites'] - 1;
		} else {
			$count = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_by_wid($wid);
		}
		C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, array('favorites' => $count));

		if($wechatcollect['cid']) {
			$favname_count = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_default_num_by_uid($_G['uid'], $wechatcollect['cid']);
			C::t('#wq_wechatreader#wq_wechatreader_classname')->update($wechatcollect['cid'], array('favoritesnum' => $favname_count));
		}
		C::memory()->clear();
		$extrajs = '<script type="text/javascript" reload="1">'
			. 'canclewechatattention(' . $wid . ')'
			. '</script>';
		cache_wq_wechatreader_subscription($_G['uid']);
		$url = $_GET['step'] == '1' ? 'plugin.php?id=wq_wechatreader&mod=index&step=2' : '/';
		if($_G['mobile']) {
			showmessage($Plang['cancel_successful'], '', array('wid' => $wid));
		} else {
			showmessage($Plang['cancel_successful'], $url, array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
		}
	} else {
		showmessage($Plang['sorry_no_attention']);
	}
} elseif(in_array(trim($_GET['ac']), array('wechatsupport', 'wechatagainst'))) {
	$ac = trim($_GET['ac']);
	$wid = intval($_GET['wid']);
	$wechat = C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->fetch_first_by_id($wid);
	if(empty($wechat) || $wechat['status'] != 1) {
		showmessage($Plang['sorry_no_wechat']);
	}
	$polltype = $ac == 'wechatsupport' ? 1 : 0;
	$update_field = $polltype ? 'support' : 'against';
	$wechatpoll = C::t('#wq_wechatreader#wq_wechatreader_poll')->fetch_first_by_wid_uid($wid, $_G['uid']);
	if(!$wechatpoll) {
		$data = array(
			'wid' => $wid,
			'username' => $_G['username'],
			'polltype' => $polltype,
			'time' => TIMESTAMP,
			'uid' => $_G['uid'],
		);
		$subscription = C::t('#wq_wechatreader#wq_wechatreader_poll')->insert($data);
		$count = C::t('#wq_wechatreader#wq_wechatreader_poll')->count_by_wid_polltype($wid, $polltype);
		C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($wid, array($update_field => $count));
		C::memory()->clear();

		cache_wq_wechatreader_poll($_G['uid'], $polltype);
		$extrajs = '<script type="text/javascript" reload="1">'
			. $ac . '(' . $wid . ');'
			. '</script>';
		if($_G['mobile']) {
			showmessage($Plang['poll_do_success'], '', array('type' => $polltype));
		}
		showmessage($Plang['poll_do_success'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
	} else {
		showmessage($Plang['sorry_you_poll']);
	}
} elseif($_GET['ac'] == 'delfavoritesname') {
	$favoritesid = intval($_GET['favoritesid']);
	if($_GET['delclass']) {
		$msg = $Plang['f24a49d3695feb19'];
		$favorites = C::t('#wq_wechatreader#wq_wechatreader_classname')->fetch_by_uid_id($_G['uid'], $favoritesid);
	} else {
		$msg = $Plang['del_favorite_empty'];
		$favorites = C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->fetch_by_uid_id($_G['uid'], $favoritesid);
	}
	if(!$favorites) {
		showmessage($msg);
	}
	if($_GET['delclass']) {
		C::t('#wq_wechatreader#wq_wechatreader_classname')->delete($favoritesid);
	} else {
		C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->delete($favoritesid);
	}
	$extrajs = '<script type="text/javascript" reload="1">'
		. 'del_favorites_succeed(' . $favoritesid . ');'
		. '</script>';
	showmessage($Plang['del_succeed'], '/', array(), array('showdialog' => true, 'closetime' => true, 'extrajs' => $extrajs));
} elseif($_GET['ac'] == 'movearticle') {
	$url = urldecode(dreferer());
	$url = str_replace($_G['siteurl'], '', $url);

	if(submitcheck('submitmove')) {
		$aids = $_GET['aids'] ? $_GET['aids'] : array();
		$favoritesid = intval($_GET['favoritesid']);
		$tablename = 'wq_wechatreader_favorites';
		$_tablename = 'wq_wechatreader_favoritesname';
		$filed = 'favoritesid';
		$_filedkey = 'articleid';
		$id = 'favoritesid';
		if($_GET['iswechat']) {
			$tablename = 'wq_wechatreader_subscription';
			$_tablename = 'wq_wechatreader_classname';
			$filed = 'cid';
			$_filedkey = 'wid';
			$id = 'cid';
			$result = C::t('#wq_wechatreader#' . $tablename)->fetch_all_by_wids($aids, $_G['uid']);
		} else {
			$result = C::t('#wq_wechatreader#' . $tablename)->fetch_all_by_aids($aids, $_G['uid']);
		}

		if(count($result) <= 0) {
			showmessage($_GET['iswechat'] ? $Plang['e25b51fcfa19e122'] : $Plang['81f47d74ca04dc7c']);
		}

		foreach($result as $key => $val) {
			$data = array($tablename, "`" . $filed . "`=" . $favoritesid, $val[$_filedkey], $val['uid']);
			DB::query('UPDATE %t SET %i WHERE ' . $_filedkey . '=%d AND uid=%d', $data);

			$data = array($_tablename, "`favoritesnum`=`favoritesnum`+1", $favoritesid, $val['uid']);
			DB::query('UPDATE %t SET %i WHERE id=%d AND uid=%d', $data);

			$folder = C::t('#wq_wechatreader#' . $_tablename)->fetch_by_id($val[$id]);

			if($folder) {
				$data = array($_tablename, "`favoritesnum`=`favoritesnum`-1", $val[$filed], $val['uid']);
				DB::query('UPDATE %t SET %i WHERE id=%d AND uid=%d', $data);
			}
		}
		$_GET['iswechat'] ? cache_wq_wechatreader_subscription($_G['uid']) : cache_wq_wechatreader_favorites($_G['uid']);
		showmessage($Plang['4f35fb1b99271f92'], $url);
	} else {
		showmessage($Plang['b292ae26631b44dd'], $url);
	}
} elseif($_GET['ac'] == 'delarticle') {
	$url = urldecode(dreferer());
	$url = str_replace($_G['siteurl'], '', $url);

	if(submitcheck('submitdel')) {
		$aids = $_GET['aids'] ? $_GET['aids'] : array();

		if(count($aids) <= 0) {
			showmessage($Plang['6de7f34c3e8306ae']);
		}
		$tablename = $_GET['iswechat'] ? 'wq_wechatreader_subscription' : 'wq_wechatreader_favorites';
		foreach($aids as $key => $aid) {
			$favorites = C::t('#wq_wechatreader#' . $tablename)->fetch_first_by_where($aid, $_G['uid']);
			if(!empty($favorites)) {
				$delete = C::t('#wq_wechatreader#' . $tablename)->delete(intval($favorites['id']));
				if($_GET['iswechat']) {
					$art_fav_count = C::t('#wq_wechatreader#wq_wechatreader_subscription')->count_by_wid($aid);
					C::t('#wq_wechatcollecting#wq_wechatcollecting_wechat')->update($aid, array('favorites' => $art_fav_count));
				} else {
					$art_fav_count = C::t('#wq_wechatreader#wq_wechatreader_favorites')->count_by_aid($aid);
					C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->update($aid, array('favorites' => $art_fav_count));
				}
				if($favorites['favoritesid']) {
					$favname_count = C::t('#wq_wechatreader#' . $tablename)->count_default_num_by_uid($_G['uid'], $_GET['iswechat'] ? $favorites['cid'] : $favorites['favoritesid']);
					if($_GET['iswechat']) {
						C::t('#wq_wechatreader#wq_wechatreader_classname')->update($favorites['cid'], array('favoritesnum' => $favname_count));
					} else {
						C::t('#wq_wechatreader#wq_wechatreader_favoritesname')->update($favorites['favoritesid'], array('favoritesnum' => $favname_count));
					}
				}
				$_GET['iswechat'] ? cache_wq_wechatreader_subscription($_G['uid']) : cache_wq_wechatreader_favorites($_G['uid']);
			}
		}
		showmessage($Plang['del_succeed'], $url);
	} else {
		showmessage($Plang['e10ee1199b75e2ef'], $url);
	}
} elseif($_GET['ac'] == 'delfolder') {
	if(submitcheck('submitdelfolder')) {
		$favoritesids = $_GET['favoritesids'] ? $_GET['favoritesids'] : array();
		if(count($favoritesids) <= 0) {
			showmessage($Plang['c3d2d4a7b33901f8']);
		}
		$num = 0;
		$tablename = $_GET['iswechat'] ? 'wq_wechatreader_classname' : 'wq_wechatreader_favoritesname';
		foreach($favoritesids as $key => $favoritesid) {
			$folder = C::t('#wq_wechatreader#' . $tablename)->fetch_by_id($favoritesid);
			if(!$folder) {
				continue;
			}

			if($folder['favoritesnum'] > 0) {
				if($_GET['iswechat']) {
					$val = array("wq_wechatreader_subscription", "`cid`=0", $favoritesid, $_G['uid']);
					DB::query('UPDATE %t SET %i WHERE cid=%d AND uid=%d', $val);
				} else {
					$val = array("wq_wechatreader_favorites", "`favoritesid`=0", $favoritesid, $_G['uid']);
					DB::query('UPDATE %t SET %i WHERE favoritesid=%d AND uid=%d', $val);
				}

				$num = $num + intval($folder['favoritesnum']);
			}
			C::t('#wq_wechatreader#' . $tablename)->delete($favoritesid);
			$_GET['iswechat'] ? cache_wq_wechatreader_subscription($_G['uid']) : cache_wq_wechatreader_favorites($_G['uid']);
		}
		showmessage($Plang['del_succeed'], '', array('num' => $num, 'ids' => $favoritesids));
	} else {
		showmessage($Plang['e10ee1199b75e2ef']);
	}
}
//From: Dism_taobao-com
?>