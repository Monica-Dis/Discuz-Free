<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function cache_wq_wechatreader_keywords($_arg_0)
{
	require_once libfile("function/cache");
	$_var_1 = C::t("#wq_wechatreader#wq_wechatreader_keyword")->fetch_all_by_where('', $_arg_0);
	foreach ($_var_1 as $_var_2) {
		$_var_3[] = $_var_2["keyword"];
	}
	savecache("wq_cache_keywords_" . $_arg_0, $_var_3);
}
function cache_wq_wechatreader_subscription($_arg_0)
{
	require_once libfile("function/cache");
	$_var_1 = C::t("#wq_wechatreader#wq_wechatreader_subscription")->fetch_all_by_where('', $_arg_0);
	foreach ($_var_1 as $_var_2) {
		$_var_3[] = $_var_2["wid"];
	}
	savecache("wq_cache_subscription_" . $_arg_0, $_var_3);
}
function cache_wq_wechatreader_favorites($_arg_0)
{
	require_once libfile("function/cache");
	$_var_1 = C::t("#wq_wechatreader#wq_wechatreader_favorites")->fetch_all_by_where('', $_arg_0);
	foreach ($_var_1 as $_var_2) {
		$_var_3[] = $_var_2["articleid"];
	}
	savecache("wq_cache_favorites_" . $_arg_0, $_var_3);
}
function cache_wq_wechatreader_poll($_arg_0, $_arg_1)
{
	require_once libfile("function/cache");
	$_var_2 = C::t("#wq_wechatreader#wq_wechatreader_poll")->fetch_all_by_wid_uid_polltype('', $_arg_0, $_arg_1);
	foreach ($_var_2 as $_var_3) {
		$_var_4[] = $_var_3["wid"];
	}
	if ($_arg_1) {
		savecache("wq_cache_pollsupport_" . $_arg_0, $_var_4);
	} else {
		savecache("wq_cache_pollagainst_" . $_arg_0, $_var_4);
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}