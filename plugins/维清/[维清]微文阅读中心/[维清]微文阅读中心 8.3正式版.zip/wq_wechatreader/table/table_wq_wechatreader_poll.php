<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatreader_poll extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatreader_poll';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_wid_uid($wid, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_wid_uid_polltype($wid, $uid, $polltype) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		if($polltype != '' || $polltype != null) {
			$sql[] = 'polltype=%d ';
			$val[] = $polltype;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function count_by_wid_polltype($wid, $polltype = 0) {
		$val[] = $this->_table;
		$sql[] = '1';

		$wid = intval($wid);
		$polltype = intval($polltype);

		if(in_array($polltype, array(0, 1))) {
			$val[] = $polltype;
			$sql[] = 'polltype=%d';
		}
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>