<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatreader_classname extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatreader_classname';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_all_by_uid($uid) {
		$uid = intval($uid);
		if(!$uid) {
			return false;
		}
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY favoritesnum desc ", array($this->_table, $uid), 'id');
	}

	public function update_incrcase($id, $uid, $operation = true) {
		$id = intval($id);
		$uid = intval($uid);
		if(!$id || !$uid) {
			return false;
		}
		if($operation == true) {
			$sql = "`favoritesnum`=`favoritesnum`+1";
		} else {
			$sql = "`favoritesnum`=`favoritesnum`-1";
		}
		$val = array($this->_table, $sql, $id, $uid);
		if(!empty($sql)) {
			return DB::query('UPDATE %t SET %i WHERE id=%d AND uid=%d', $val);
		}
	}

	public function fetch_by_uid_id($uid, $id) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($id) {
			$sql[] = 'id=%d';
			$val[] = $id;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table, $id));
	}

}
//From: Dism_taobao-com
?>