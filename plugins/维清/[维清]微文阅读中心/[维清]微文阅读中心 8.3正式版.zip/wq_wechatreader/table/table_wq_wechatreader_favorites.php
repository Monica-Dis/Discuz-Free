<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatreader_favorites extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatreader_favorites';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_where($aid = 0, $uid = 0) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($aid) {
			$sql[] = 'articleid=%d';
			$val[] = $aid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_where($aid = 0, $uid = 0, $displayorder = 'time') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' DESC ';
		}
		if($aid) {
			$sql[] = 'articleid=%d';
			$val[] = $aid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function delete_by_aid($aid) {
		$condition = array('articleid' => $aid);
		return DB::delete($this->_table, $condition);
	}

	public function count_default_num_by_uid($uid, $favoritesid = 0) {
		$uid = intval($uid);
		if(!$uid) {
			return 0;
		}
		$favoritesid = intval($favoritesid);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE uid=%d AND favoritesid=%d", array($this->_table, $uid, $favoritesid));
	}

	public function fetch_all_aid_by_uid_favoritesid($uid, $favoritesid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($favoritesid !== '') {
			$sql[] = 'favoritesid=%d';
			$val[] = $favoritesid;
		}

		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT articleid,favoritesid FROM %t WHERE " . $where . " ORDER BY time DESC ", $val);
	}

	public function fetch_all_by_aids($aids, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';

		if(is_array($aids)) {
			$sql[] = 'articleid IN (%n)';
			$val[] = $aids;
		}
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where, $val);
	}

	public function count_by_aid($aid) {
		$aid = intval($aid);
		if(!$aid) {
			return 0;
		}
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE articleid=%d", array($this->_table, $aid));
	}

}
//From: Dism_taobao-com
?>