<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatreader_subscription extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatreader_subscription';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_where($wid, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_where($wid, $uid, $displayorder = 'time') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' DESC ';
		}
		if($wid) {
			$sql[] = 'wid=%d';
			$val[] = $wid;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function delete_by_wid($wid) {
		$condition = array('wid' => $wid);
		return DB::delete($this->_table, $condition);
	}

	public function count_by_wid($wid) {
		$val[] = $this->_table;
		$sql[] = '1';
		$wid = intval($wid);
		if(!$wid) {
			return 0;
		}
		$sql[] = 'wid=%d';
		$val[] = $wid;
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function count_default_num_by_uid($uid, $cid = 0) {
		$uid = intval($uid);
		if(!$uid) {
			return 0;
		}
		$cid = intval($cid);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE uid=%d AND cid=%d", array($this->_table, $uid, $cid));
	}

	public function fetch_all_wid_by_uid_cid($uid, $cid) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		if($cid !== '') {
			$sql[] = 'cid=%d';
			$val[] = $cid;
		}

		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT wid,cid FROM %t WHERE " . $where . " ORDER BY time DESC ", $val);
	}

	public function fetch_all_by_wids($wids, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';

		if(is_array($wids)) {
			$sql[] = 'wid IN (%n)';
			$val[] = $wids;
		}
		if($uid) {
			$sql[] = 'uid=%d';
			$val[] = $uid;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where, $val);
	}

}
//From: Dism_taobao-com
?>