<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_wechatcollecting_sample.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_wechatreader_keyword extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_wechatreader_keyword';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_where($keyword, $uid) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($keyword) {
			$sql[] = 'keyword=%s';
			$val[] = $keyword;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_first("SELECT * FROM %t WHERE " . $wheresql, $val);
	}

	public function fetch_all_by_where($keyword, $uid, $displayorder = 'time') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' DESC ';
		}
		if($keyword) {
			$sql[] = 'keyword=%s';
			$val[] = $keyword;
		}
		if($uid) {
			$sql[] = 'uid=%d ';
			$val[] = $uid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

}
//From: Dism_taobao-com
?>