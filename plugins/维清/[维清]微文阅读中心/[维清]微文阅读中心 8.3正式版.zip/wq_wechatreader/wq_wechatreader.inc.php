<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_wechatreader.inc.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET['id'] = "wq_wechatreader:wq_wechatreader";
include_once DISCUZ_ROOT . './source/plugin/wq_wechatreader/config/config.php';
include_once libfile('function/home');
$wq_wechatcollecting = $_G['cache']['plugin']['wq_wechatcollecting'];
$wq_wechatshow = $_G['cache']['plugin']['wq_wechatshow'];
$plugin_wechatcollecting = !empty($wq_wechatcollecting) ? 1 : 0;
$plugin_wechatshow = !empty($wq_wechatshow) ? 1 : 0;
$plugin_wechatreader = !empty($_G['cache']['plugin']['wq_wechatreader']) ? 1 : 0;

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "index";

$allowmod = array('index', 'ajax');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_wechatreader/' . $dirlist[$mod] . '/wechatreader_' . $mod . '.php';

?>