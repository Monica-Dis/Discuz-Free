<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_seo.inc.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include DISCUZ_ROOT . './source/plugin/wq_wechatreader/config/config.php';
if(!submitcheck('seosubmit')) {
	echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';
	$page = array(
		'list_keyword' => array('bbname', 'pluginname', 'pagename'),
		'list_article' => array('bbname', 'pluginname', 'pagename'),
		'list_wechat' => array('bbname', 'pluginname', 'pagename'),
	);
	showformheader('plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatreader&pmod=admincp_seo');
	showtableheader();
	foreach($page as $key => $value) {
		$code = $Plang['code'];
		foreach($value as $v) {
			$code .= '<a onclick="insertContent(this, \'{' . $v . '}\');return false;" href="javascript:;" title="' . $Plang[$v] . '">{' . $Plang[$v] . '}</a>';
		}
		showtitle($Plang[$key]);
		showsetting($Plang['seotitle'], 'wechatreader_seo[' . $key . '][seotitle]', $wechatreader_seo[$key]['seotitle'], 'text', '', 0, $code);
		showsetting($Plang['seokeywords'], 'wechatreader_seo[' . $key . '][seokeywords]', $wechatreader_seo[$key]['seokeywords'], 'text', '', 0, $code);
		showsetting($Plang['seodescription'], 'wechatreader_seo[' . $key . '][seodescription]', $wechatreader_seo[$key]['seodescription'], 'text', '', 0, $code);
	}
	showsubmit('seosubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$wechatreader_seo = serialize($_GET['wechatreader_seo']);
	C::t('common_setting')->update('wechatreader_seo', $wechatreader_seo);
	updatecache('setting');
	cpmsg($Plang['setsucceed'], 'action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_wechatreader&pmod=admincp_seo', 'succeed');
}
//From: Dism_taobao-com
?>