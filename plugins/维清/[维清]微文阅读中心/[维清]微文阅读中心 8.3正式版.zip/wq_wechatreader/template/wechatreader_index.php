<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/tpl_header}-->
<style>
    body{ background: #f0f4fb;} #hd{ background-color: #fff;}
</style>
<style id="diy_style" type="text/css"></style>
<div class="wq_wechat_per">
    <div class="wq_wechat_per_list">
        <ul>
            <li<!--{if $ac=='focus'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first">{$Plang['8fe539a549ff6e77']}</a></li>
            <li<!--{if $ac=='read'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=read">{$Plang['8a63516eeb150d9e']}</a></li>
            <li<!--{if $ac=='fav'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav">{$Plang['e17c06793e315f8a']}</a></li>
            <li><a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list&meun=my_submit">{$Plang['dde343556ea0716c']}</a></li>
        </ul>
    </div>
    <!--{if $ac=='read'}-->
        <div class="wq_wechat_per_con">
            <!--{if $list}-->
                <div class="wq_wechat_per_subscribe">
                    <ul>
                        <li class="a"><a href="javascript:;">{$Plang['all']}</a></li>
                        <!--{loop $cache $key $val}-->
                            <li class='keywordslist' key="{$key}"><a href="plugin.php?id=wq_wechatcollecting&mod=search&keyword={$val}">{$val}</a></li>
                        <!--{/loop}-->
                    </ul>
                    <span class="wqsubscribe_edit"><a href="javascript:;"><i class="wqwechat wqwechat-bianji"></i>{$Plang['edit']}</a></span>
                </div>

                <!--{loop $list $key $val}-->
                <div class="wq_results wqpc_per_coll">
                        <h3 keyword="{$key}">{$key}</h3>
                        <ul keyword="{$key}">
                            <!--{loop $val $k $v}-->
                                <!--{if $k==0}-->
                                <!--{eval $url = wq_common_article_view_url($setting,$v['articleid'],$v['tid'],$v['aid']);}-->
                                <li class="wq_results_con">
                                    <h4><a href="{$url}" target="_blank">{$v[title]}</a></h4>
                                    <p class="wq_results_text">{$v[summary]}<!--{eval echo date("H:i", $v['date']);}--></p>
                                    <a class="wq_img wqlazydiv" href="{$url}" target="_blank">
                                       <img wqdata-src="{$v[imglink]}"src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/>
                                       <!--<img src="{$v[imglink]}"/>-->
                                    </a>
                                </li>
                                <!--{else}-->
                                    <li><a href=<!--{if $setting['view_mode'] == '2' && !empty($v['tid'])}-->forum.php?mod=viewthread&tid=$v['tid']<!--{else}-->plugin.php?id=wq_wechatcollecting&mod=view&articleid=$v['articleid']<!--{/if}--> target="_blank">{$v[title]}</a> <em><!--{eval echo date("H:i", $v['date']);}--></em></li>
                                <!--{/if}-->
                            <!--{/loop}-->
                        </ul>
                </div>
                <!--{/loop}-->
                <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
            <!--{else}-->
                <div class="wqpc_emp">$Plang['no_data']</div>
            <!--{/if}-->

        </div>
    <!--{elseif $ac=='focus'}-->
        <div class="wq_wechat_circle wq_wechat_per_con">
            <!--{if !$subscription && $op=='article'}-->
                <div class="wqpc_emp">$Plang['sorry_no_attention']<!--{if $plugin_wechatshow}--><br /><a href="plugin.php?id=wq_wechatshow:wq_wechatshow" >{$Plang['522d4f8f3d5d6d97']}</a><!--{/if}--></div>
            <!--{else}-->
                <div class="wqpc_title">
                    <ul>
                        <li<!--{if $op=='article'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first">{$Plang['ad4a637929cd4720']}</a></li>
                        <li<!--{if $op=='public'}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public">{$Plang['f8497259f9b3f761']}</a></li>
                    </ul>
                </div>
                <!--{if $op=='article'}-->
                    <div class="wqswitch">
                        <ul>
                            <li><a href="plugin.php?id=wq_wechatreader&mod=index&type=first"<!--{if $isfirst}--> class="a"<!--{/if}-->>{$Plang['460cbb509887c2b8']}</a></li>
                            <li><a href="plugin.php?id=wq_wechatreader&mod=index&type=all"<!--{if !$isfirst}--> class="a"<!--{/if}-->>{$Plang['9ef5e89f8d0893a5']}</a></li>
                        </ul>
                    </div>
                    <!--{template wq_wechatcollecting:common_list}-->
                <!--{else}-->
                    <div class="wq_wechat_per_collection">
                        <ul>
                            <li<!--{if $cid === ''}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public">{$Plang['all']}</a></li>
                            <li<!--{if $cid === 0}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid=0">{$Plang['045ee7924f2db654']}<em>{$default_num}</em></a></li>
                            <!--{loop $classlist $k_cid $value}-->
                                <li class="keywordslist<!--{if $k_cid == $cid}--> a<!--{/if}-->" key="{$k_cid}" id="{$k_cid}" val="{$value[favoritesnum]}"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid={$k_cid}">{$value['classname']}<em><!--{eval echo $value['favoritesnum'] > 0 ? $value['favoritesnum'] : '';}--></em></a></li>
                            <!--{/loop}-->
                        </ul>
                        <span class="wqsubscribe_edit"><a href="javascript:;"><i class="wqwechat wqwechat-bianji"></i>{$Plang['edit']}</a></span>
                    </div>
                    <!--{if !$list || count($list)<1}-->
                        <div class="wqpc_emp">{$Plang['f6fa27d3fe7c0c6d']}</div>
                    <!--{else}-->
                        <div class="wq_wechat_per_follow">
                            <div class="wqpc_wechat_follow">
                                <ul>
                                    <!--{loop $list $key $val}-->
                                        <!--{eval $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist[displayorder] = 'index'; $url = 'plugin.php?'.url_implode($getlist);}-->
                                        <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                                    <li id="wechatlist_id{$val[id]}">
                                        <div class="wqpc_wechat_follow_img">
                                            <a href="{$url}" target="_blank">
                                                <div class="wqpc_img wqlazydiv"><img wqdata-src="{$logourl}"src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" class="lazyload-home"/></div>
                                                <!--<img class="wqpc_img" src="{$logourl}"/>-->
                                                <!--{if $val[verify]}-->
                                                <span class="wqwechat_rz"><img src="./source/plugin/wq_wechatcollecting/static/images/wqattestation.png"/></span>
                                                <!--{/if}-->
                                            </a>
                                            <!--{if !$_G['uid']}-->
                                                <!--{eval $logininfo = " id='login' href='member.php?mod=logging&action=login'";}-->
                                            <!--{/if}-->
                                            <!--{if in_array($val['id'],$subscription)}-->
                                                <p class="wqwechat_follow_btn">
                                                    <a<!--{if !$logininfo}--> id="attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>- </span>{$Plang['2c8a07313e7706bc']}</a>
                                                </p>
                                            <!--{else}-->
                                                <p class="wqwechat_follow_btn">
                                                    <a<!--{if !$logininfo}--> id="attention_{$val[id]}" href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}"<!--{else}-->{$logininfo}<!--{/if}--> onclick="showWindow(this.id, this.href, 'get', 0);"><span>+ </span>{$Plang['2c8a07313e7706bc']}</a>
                                                </p>
                                            <!--{/if}-->
                                        </div>
                                        <div class="wqpc_wechat_follow_con">
                                            <h3><a href="{$url}" target="_blank">{$val[name]}</a></h3>
                                            <p class="wqwechat_weixinhao">{$Plang['wechat_user']}{$Plang['mh']}<i>{$val[wechatid]}</i></p>
                                            <div class="wqpc_wechat_con">{$val[intro]}</div>
                                        </div>
                                    </li>
                                    <!--{/loop}-->
                                </ul>
                                <!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
                            </div>
                        </div>
                    <!--{/if}-->
                <!--{/if}-->
            <!--{/if}-->
        </div>
    <!--{elseif $ac=='fav'}-->
    <div class="wq_wechat_per_con">
        <div class="wq_wechat_per_collection">
            <ul>
                <li<!--{if $favoritesid === ''}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav">{$Plang['all']}</a></li>
                <li<!--{if $favoritesid === 0}--> class="a"<!--{/if}-->><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid=0">{$Plang['f11bb8f10ab80417']}<em>{$default_num}</em></a></li>
                <!--{loop $favoriteslist $key $val}-->
                <li<!--{if $val['id'] == $favoritesid}--> class="a keywordslist"<!--{else}--> class='keywordslist'<!--{/if}--> key="{$key}" id="{$val[id]}" val="{$val[favoritesnum]}"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid={$val[id]}">{$val['favoritesname']}<em><!--{eval echo $val['favoritesnum'] > 0 ? $val['favoritesnum'] : '';}--></em></a></li>
                <!--{/loop}-->
            </ul>
            <span class="wqsubscribe_edit"><a href="javascript:;"><i class="wqwechat wqwechat-bianji"></i>{$Plang['edit']}</a></span>
        </div>
        <!--{eval $favorites_checkbox = 1;}-->
        <!--{template wq_wechatcollecting:common_list}-->
    </div>
    <!--{/if}-->
</div>
<script type="text/javascript">
    var flag = false;
    var ac = "{$ac}";

    var favoritesid = '{$favoritesid}';

    wqjq("body").on('click', '.wqsubscribe_edit', function(){
        var lastkey = wqjq('.keywordslist:last').attr('key');
        wqjq('.keywordslist').each(function(){
            var txt = wqjq(this).find("a").text();
            if(flag === false){
                wqjq(this).find("a").html(txt+"<span class=\"wqpc_close\"><i class=\"wqwechat wqwechat-x\"></i></span>");
                if(wqjq(this).attr('key') == lastkey){
                    flag = true;
                    wqjq(".wqsubscribe_edit").find("a").html('<i class="wqwechat wqwechat-bianji"></i>{$Plang[3280829519230622]}');
                }
            }else{
                wqjq(this).find("a").html('').text(txt);
                if(wqjq(this).attr('key') == lastkey){
                    flag = false;
                    wqjq(".wqsubscribe_edit").find("a").html('<i class="wqwechat wqwechat-bianji"></i>{$Plang[9a150d4af72d7358]}');
                }
            }
        });
    });

    wqjq("body").on('click', '.wqwechat-x', function(){
        if(ac == 'fav' || ac == 'focus'){
            var obj = wqjq(this).parent().parent().parent();
            var thisid = parseInt(obj.attr('id'));
            var countnum = parseInt(obj.attr('val'));
            var newac = 'collect';
            var delclass = '0';

            if(ac == 'focus'){
                newac = 'wechatcollect';
                delclass = 1;
            }
            if(countnum > 0){
                var url = 'plugin.php?id=wq_wechatreader&mod=ajax&ac=' +newac+ '&del=1&favoritesid='+thisid;
            }else{
                var url = 'plugin.php?id=wq_wechatreader&mod=ajax&ac=delfavoritesname&favoritesid='+thisid+'&delclass='+delclass;
            }
            showWindow(thisid, url, 'get', 0);
            return false;
        }else{
            if (confirm('{$Plang[IsDelete]}')) {
                var keyword = wqjq(this).parent().parent().text();
                var key = wqjq(this).parent().parent().parent().attr('key');
                wqjq.ajax({
                    type: 'GET',
                    url:'plugin.php?id=wq_wechatreader&mod=ajax&ac=unsubscribe&keyword='+keyword,
                    dataType: 'json'
                }).success(function (data) {
                    if(data['code'] == 0){
                       wqjq(".wq_wechat_per_subscribe li[key='"+key+"']").remove();
                       if(wqjq(".wq_results h3[keyword='"+keyword+"']").attr('keyword') == keyword){
                           wqjq(".wq_results h3[keyword='"+keyword+"']").remove();
                           wqjq(".wq_results ul[keyword='"+keyword+"']").remove();
                       }
                       if(wqjq('.keywordslist').length <1){
                            window.location.href = location.href;
                        }
                    }else{
                        showDialog(data['msg']);
                    }
                });
            }
            return false;
        }
    });


    function wechatattention(wid) {
        wqjq("#attention_"+wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid=' + wid);
        wqjq("#attention_"+wid+" span:first-child").html("- ");
    }

    function canclewechatattention(wid) {
        window.location.href = 'plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid={$cid}';
    }

    if(ac == 'fav'){
        function del_articlelist_li(aid){
            window.location.href = 'plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid='+favoritesid;
        }
    }


    function del_favorites_name(data){
        wqjq('.wqpc_ejectbg_btn a').trigger('click');
        if(data['newid'] == favoritesid || data['yid'] == favoritesid || data['newid'] == '{$cid}' || data['yid'] == '{$cid}'){
            var t_url = 'plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid='+data['newid'];
            if(data['wechat'] == '1'){
                t_url = 'plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid='+data['newid'];
            }
            window.location.href = t_url;
        }else{
            if(data['newid'] == '0'){
                wqjq("#"+data['newid'] ).find("a").text(data['newname']+data['num']);
            }else{
                var tem_html = "<span class=\"wqpc_close\"><i class=\"wqwechat wqwechat-x\"></i></span>";
                wqjq("#"+data['newid'] ).find("a").html(data['newname']+data['num']+tem_html);
            }
            wqjq("#"+data['yid'] ).remove();
        }

    }

    function del_favorites_succeed(delid){
        if(delid == favoritesid || delid == '{$cid}'){
            var t_url = 'plugin.php?id=wq_wechatreader&mod=index&ac=fav';
            if(delid == '{$cid}'){
                t_url = 'plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public';
            }
            window.location.href = t_url;
        }else{
            wqjq("#"+delid).remove();
        }
    }
</script>
<!--{template wq_wechatcollecting:common/tpl_footer}-->