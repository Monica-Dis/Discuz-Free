<?php exit("From: DisM.taobao.com"); ?>
<!--{template wq_wechatcollecting:common/header}-->
<div class="wqpc_ejectbg_warp" id="new_favorites">
    <h3 class="wqpc_title">$h3_title<span class="y" onclick="hide_window('$_GET['handlekey']')"><i class="close_favorites wqwechat wqwechat-close wq_f18"></i></span></h3>
    <form method="post" id="add_favorites" action="plugin.php?id=wq_wechatreader&mod=ajax&ac={$ac}" onsubmit="ajaxpost('add_favorites', 'return_favorites', 'return_favorites', 'onerror');return false;">
        <input type="hidden" name="newfavoritesname" value="true">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="aid" value="{$_GET[aid]}" />
        <input type="hidden" name="del" value="{$_GET[del]}" />
        <input type="hidden" name="yid" value="{$_GET[favoritesid]}" />
        <input type="hidden" name="handlekey" value="addfavorites" />
        <input type="hidden" name="isview" value="{$_GET[isview]}" />
        <input type="hidden" name="favoritesid" value="{$list[0][id]}" id="favoritesid">
        <ul class="wqpc_ejectbg_ul">
            <!--{loop $list $key $val}-->
            <li favoritesid="{$val[id]}">
                <!--{if $key==0}-->
                <i class="wqwechat wqwechat-o3"></i>
                <!--{/if}-->
                <h3>{$val[$_key]}</h3>
                <p>{$val[favoritesnum]}{$unit_font}</p>
            </li>
            <!--{/loop}-->
        </ul>
        <div class="wq_establish_favorites"><a href="javascript:;" onclick="show_found_html(this)"><span>+</span>$add_font</a></div>
        <div class="wq_establish_favorites_input" style="display: none;">
            <input type="text" name="newname" onfocus="clear_Selected()" maxlength="20" placeholder="{$Plang['e831eb20bd740f73']}" id="new_favorites_name"/>
        </div>
        <div class="wqpc_ejectbg_btn">
            <button type="submit">{$Plang['6ce0cdd2f7c855aa']}</button>
            <a href="javascript:;" class="close_favorites" onclick="hide_window('$_GET['handlekey']')">{$Plang['9c825be7149e5b97']}</a>
        </div>
    </form>
</div>
<script type="text/javascript" reload="1">
    wqjq(document).ready(function() {
        wqjq(".wqpc_ejectbg").show();
        wqjq("body").addClass("body_overflow");
        wqjq(".wqpc_ejectbg_ul > li").bind('click',function(){
            clear_Selected();
            wqjq(this).prepend("<i class='wqwechat wqwechat-o3'></i>");
            wqjq("#favoritesid").val(parseInt(wqjq(this).attr("favoritesid")));
        });
    });

    function hide_window(id){
        hideWindow(id);
        wqjq(".wqpc_ejectbg").hide();
        wqjq("body").removeClass("body_overflow");
    }

    function show_found_html(t){
        wqjq(".wq_establish_favorites_input").show();
        wqjq(t).parent().remove();
        clear_Selected();
        wqjq('#new_favorites_name').focus();
        wqjq("#favoritesid").val(0);
    }


    function clear_Selected(){
        wqjq(".wqpc_ejectbg_ul").find("i").each(function(){
            wqjq(this).remove();
        });
        wqjq("#favoritesid").val(0);
    }

    function collect(aid,flag) {
       if(flag==1){
           wqjq("#viwetop_favorites").attr('class','wqpc_collection2');
           wqjq("#viwetop_favorites a").attr('href','plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid='+aid);
           wqjq("#aid_" + aid + " a").replaceWith("<a id='reader_favorites_"+aid+"' href='plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid="+aid+"' onclick='showWindow(this.id, this.href, \"get\", 0);'><i class='wqwechat wqwechat-shoucang'></i>"+tem_plang+"</a>");

       }else{
            wqjq("#aid_" + aid + " a").replaceWith("<a id='reader_favorites_"+aid+"' href='plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecollect&aid="+aid+"' onclick='showWindow(this.id, this.href, \"get\", 0);'><i class='wqwechat wqwechat-shoucang wqpc_yellow'></i>"+tem_plang+"</a>");
       }
       wqjq('.wqpc_ejectbg_btn a').trigger('click');
    }

    function wechatattention(wid) {
        wqjq("#attention_"+wid).removeClass().attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid=' + wid);
        wqjq("#attention_"+wid+" span:first-child").html("- ");

        wqjq("#top_attention_"+wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid=' + wid);
        wqjq("#top_attention_"+wid+" span:first-child").html("- ");
        if(wqjq("#attention_num")){
            var attention_num = parseInt(wqjq("#attention_num").html());
            attention_num = attention_num+1;
            wqjq("#attention_num").html(attention_num);
        }
        wqjq('.wqpc_ejectbg_btn a').trigger('click');
    }


</script>
<!--{template wq_wechatcollecting:common/footer}-->