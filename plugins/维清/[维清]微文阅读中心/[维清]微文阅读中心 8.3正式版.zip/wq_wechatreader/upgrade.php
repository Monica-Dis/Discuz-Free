<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_wechatreader/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'stat':
		$cache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $cache));
		break;
	case 'sql':
		if(is_file($filepath = DISCUZ_ROOT . './source/plugin/wq_addon_client/function/admincp/function_wikinaddons.php')) {
			require_once $filepath;
			wikinaddons_installlog('wq_wechatreader.plugin', 0, 'upgrade');
		}
		$sql = "CREATE TABLE IF NOT EXISTS `pre_wq_wechatreader_favoritesname` (\n" .
			"  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"  `uid` int(10) unsigned NOT NULL,\n" .
			"  `username` varchar(60) NOT NULL,\n" .
			"  `favoritesname` varchar(60) NOT NULL,\n" .
			"  `favoritesnum` int(10) unsigned NOT NULL,\n" .
			"  `dateline` int(10) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`id`),\n" .
			"  KEY `uid` (`uid`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatreader_poll` (\n" .
			"  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"  `uid` int(10) unsigned NOT NULL,\n" .
			"  `username` varchar(60) NOT NULL,\n" .
			"  `wid` int(10) unsigned NOT NULL,\n" .
			"  `polltype` tinyint(3) NOT NULL DEFAULT '0',\n" .
			"  `time` int(10) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`id`),\n" .
			"  KEY `uid` (`uid`),\n" .
			"  KEY `wid` (`wid`),\n" .
			"  KEY `polltype` (`polltype`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_wechatreader_classname` (\n" .
			"  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			"  `username` varchar(60) NOT NULL,\n" .
			"  `uid` int(10) unsigned NOT NULL,\n" .
			"  `classname` varchar(60) NOT NULL,\n" .
			"  `favoritesnum` int(10) unsigned NOT NULL,\n" .
			"  `dateline` int(10) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`id`),\n" .
			"  KEY `uid` (`uid`)\n" .
			") ENGINE=MyISAM;\n";

		runquery($sql);
		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatreader_favorites'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('favoritesid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_favorites') . " ADD `favoritesid` INT(10) unsigned NOT NULL;";
			DB::query($sql);
		}

		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatreader_favorites'));
		$col_index_wechat = array();
		while($row = DB::fetch($query)) {
			$col_index_wechat[] = $row['Key_name'];
		}
		if(!in_array('favoritesid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_favorites') . " ADD INDEX `favoritesid` (`favoritesid`);";
			DB::query($sql);
		}
		if(!in_array('articleid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_favorites') . " ADD INDEX `articleid` (`articleid`);";
			DB::query($sql);
		}
		if(!in_array('uid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_favorites') . " ADD INDEX `uid` (`uid`);";
			DB::query($sql);
		}

		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatreader_keyword'));
		$col_index_wechat = array();
		while($row = DB::fetch($query)) {
			$col_index_wechat[] = $row['Key_name'];
		}
		if(!in_array('uid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_keyword') . " ADD INDEX `uid` (`uid`);";
			DB::query($sql);
		}
		if(!in_array('keyword', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_keyword') . " ADD INDEX `keyword` (`keyword`);";
			DB::query($sql);
		}

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_wechatreader_subscription'));
		$col_field = array();
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('cid', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_subscription') . " ADD `cid` INT(10) unsigned NOT NULL;";
			DB::query($sql);
		}

		$query = DB::query("SHOW INDEX FROM " . DB::table('wq_wechatreader_subscription'));
		$col_index_wechat = array();
		while($row = DB::fetch($query)) {
			$col_index_wechat[] = $row['Key_name'];
		}
		if(!in_array('cid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_subscription') . " ADD INDEX `cid` (`cid`);";
			DB::query($sql);
		}
		if(!in_array('uid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_subscription') . " ADD INDEX `uid` (`uid`);";
			DB::query($sql);
		}
		if(!in_array('wid', $col_index_wechat)) {
			$sql = "ALTER TABLE " . DB::table('wq_wechatreader_subscription') . " ADD INDEX `wid` (`wid`);";
			DB::query($sql);
		}
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
	wq_clear("wq_wechatreader");
		$finish = TRUE;
		break;
}

function wq_clear($id) {

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id;

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/^discuz\_plugin\_' . $id . '(\_\w+)?\.xml$/', $f) || in_array($f, array("install.php", "upgrade.php"))) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}

function clear_old_tpl($id) {
	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/touch/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/mobile/';
	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}

	$entrydir = DISCUZ_ROOT . './source/plugin/' . $id . '/template/';

	if(is_dir($entrydir)) {
		$d = @dir($entrydir);
		while($f = $d->read()) {
			if(preg_match('/(\w+)?\.htm$/', $f)) {
				@unlink($entrydir . '/' . $f);
			}
		}
	}
}
//From: Dism_taobao-com
?>