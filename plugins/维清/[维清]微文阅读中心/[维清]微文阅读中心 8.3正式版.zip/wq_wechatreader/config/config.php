<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-4-22 11:41:42Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_wechatreader/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatreader/function/function_wechatreader.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_wechatcollecting.php';
include_once DISCUZ_ROOT . './source/plugin/wq_wechatcollecting/function/function_sync.php';

$Plang = wq_loadlang('wq_wechatreader');

$setting = wq_loadsetting('wq_wechatreader');
$collecting_setting = wq_loadsetting('wq_wechatcollecting');
$collecting_setting['topnav'] = get_nav_urlinfo($collecting_setting['topnav']);
$array = array(
	'wq_wechatcollecting_class',
	'wq_cache_subscription_' . $_G['uid'],
	'wq_cache_favorites_' . $_G['uid'],
	'wq_cache_keywords_' . $_G['uid'],
	'wq_cache_articlepollsupport_' . $_G['uid'],
	'wq_cache_articlepollagainst_' . $_G['uid'],
);
loadcache($array);
$wechatclass_article = $_G['cache']['wq_wechatcollecting_class'];
$subscription = $_G['cache']['wq_cache_subscription_' . $_G['uid']];
$favorites = $_G['cache']['wq_cache_favorites_' . $_G['uid']];
$keywords = $_G['cache']['wq_cache_keywords_' . $_G['uid']];
$articlesupport = $_G['cache']['wq_cache_articlepollsupport_' . $_G['uid']];
$articleagainst = $_G['cache']['wq_cache_articlepollagainst_' . $_G['uid']];

$wechatarticle = trim($_G['cache']['plugin']['wq_wechatcollecting']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatcollecting']['pluginname']) : $Plang['wechatarticle'];
$wechatnavigation = trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) ? trim($_G['cache']['plugin']['wq_wechatshow']['pluginname']) : $Plang['wechatnavigation'];

$replacekeyword = str_replace('��', ',', $setting['home_keyword']);
$wechatreader_seo = dunserialize($_G['setting']['wechatreader_seo']);
$setkeyword = explode(",", rtrim($replacekeyword, ','));

$setting['pluginname'] = $setting['pluginname'] ? trim($setting['pluginname']) : $Plang['personalcenter'];

$setting['view_mode'] = $_G['cache']['plugin']['wq_wechatcollecting']['view_mode'];
$setting['use_common_header'] = $_G['cache']['plugin']['wq_wechatcollecting']['usesystemheader'];

$sqlcache = unserialize($_G['setting']['wechatcollecting_cache_setting']);
$a_searchset = unserialize($_G['setting']['articlesearch']);
$w_searchset = unserialize($_G['setting']['wechatsearch']);

?>