<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_wechatreader/config/setting_base.php';
$setting['home_focus_perpage'] = $setting['home_focus_perpage'] < 1 ? 15 : $setting['home_focus_perpage'];
$setting['home_focus_article_perpage'] = $setting['home_focus_article_perpage'] < 1 ? 10 : $setting['home_focus_article_perpage'];
$setting['home_keywrod_perpage'] = $setting['home_keywrod_perpage'] < 1 ? 10 : $setting['home_keywrod_perpage'];
$setting['home_favorites_perpage'] = $setting['home_favorites_perpage'] < 1 ? 10 : $setting['home_favorites_perpage'];

?>