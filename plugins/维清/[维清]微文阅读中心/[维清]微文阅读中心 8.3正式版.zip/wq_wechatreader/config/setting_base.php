<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2016-11-23 02:55:04Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_wechatreader'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['home_focus_perpage'] = intval($setting['home_focus_perpage']);
$setting['home_focus_article_perpage'] = intval($setting['home_focus_article_perpage']);
$setting['home_keywrod_perpage'] = intval($setting['home_keywrod_perpage']);
$setting['home_favorites_perpage'] = intval($setting['home_favorites_perpage']);

?>