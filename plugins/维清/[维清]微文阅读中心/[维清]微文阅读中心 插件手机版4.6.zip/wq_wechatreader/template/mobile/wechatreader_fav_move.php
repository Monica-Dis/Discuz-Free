<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['type']=='remove'}-->
    <form action="plugin.php?id=wq_wechatreader&mod=ajax&ac=movearticle&iswechat={$_GET[iswechat]}" method="get" id="move_article">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="submitmove" value="true">
        <!--{eval  $aids = strpos(trim($_GET['aids']), ',') ? explode(',', trim($_GET['aids'])) : array(intval($_GET['aids']));}-->
        <!--{loop $aids $key $aid}-->
        <input type="hidden" name="aids[]" value="{$aid}" />
        <!--{/loop}-->
        <input type="hidden" name="favoritesid" value="{$favoritesid}">
        <input type="hidden" name="referer" value="{$referer}">
        <div class="wqwechat_dialog" style="top: 36%;">
            <h3 class="wqwechat_dialogh3">{$Plang['1422fa01fdf4e733']}</h3>
            <p class="wqwechat_dialogp wq_f14">{$favname}</p>
            <div class="wqwechat_dialog_btn wqwechat_top">
                <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick="popup.close();">{$Plang['9c825be7149e5b97']}</a>
                <input type="submit" name="" value="{$Plang['387e9a577ee04ca3']}" class="wqwechat_determine wqformdialog">
            </div>
        </div>
    </form>
<!--{else}-->
<div class="wqwechat_perheader wqwechat_bottom">
    <div class="wqwechat_perheader_warp">
        <a href="javascript:history.go(-1)" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
        {$Plang['1422fa01fdf4e733']}
    </div>
</div>
<div class="wqheight44"></div>

<div class="wqwechat_group_warp wqwechat_padding">
    <ul>
        <li class="wqwechat_bottom">
            <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=move&type=remove&favoritesid=0&aids={$_GET['aids']}&referer={$referer}&iswechat={$_GET[iswechat]}" class="wqdialog">
                <span class="wq_title">{$default_font}</span>
                <span class="wq_num">({$default_num})</span>
            </a>
        </li>
        <!--{loop $favoriteslist $key $val}-->
            <li class="wqwechat_bottom">
                <!--{if $_GET[iswechat]}-->
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&sub=move&type=remove&cid={$val['id']}&aids={$_GET['aids']}&referer={$referer}&iswechat=1" class="wqdialog">
                <!--{else}-->
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=move&type=remove&favoritesid={$val['id']}&aids={$_GET['aids']}&referer={$referer}" class="wqdialog">
                <!--{/if}-->
                    <span class="wq_title">{$val[$_key]}</span>
                    <span class="wq_num">(<!--{eval echo $val['favoritesnum'] > 0 ? $val['favoritesnum'] : 0;}-->)</span>
                </a>
            </li>
        <!--{/loop}-->
    </ul>
</div>
<div class="wqheight40"></div>
<div class="wqmanage_operation wqwechat_top wqwechat_widtn100">
    <ul>
        <li>
            <a href='plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=create&iswechat={$_GET[iswechat]}' class="wqwechat_bule wqdialog" id="wqwechat_create">
               {$Plang['4debf7dc8c9fd7c0']}
            </a>
        </li>
    </ul>
</div>
<script type="text/javascript" reload="1">

    function errorhandle_create_folder(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['43f8689c027bd4ff']}"){
            $('.wqwechat_padding ul').append('<li class="wqwechat_bottom wqc_wqwechat_bottom" favoritesid="'+param.id+'"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=move&type=remove&favoritesid='+param.id+'&aids={$_GET[aids]}&referer={$referer}" class="wqdialog"><span class="wq_title">'+param.name+'</span><span class="wq_num">(0)</span></a></li>')
        }
    }

 </script>
 <!--{/if}-->