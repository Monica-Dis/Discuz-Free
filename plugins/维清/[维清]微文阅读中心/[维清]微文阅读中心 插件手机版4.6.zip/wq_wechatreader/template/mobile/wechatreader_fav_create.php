<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['op']=='create'}-->
<form  method="get"  action = "plugin.php?id=wq_wechatreader&mod=ajax&ac={$_GET[newac]}" id="create_folder">
    <input type="hidden" name="newfavoritesname" value="true">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="operationtype" value="create" />
    <!--<input type="hidden" name="aid" value="1" />-->
    <input type="hidden" name="yid" value="1" />
    <input type="hidden" name="referer" value="{$referer}">
    <div class="wqwechat_dialog">
        <h3 class="wqwechat_dialogh3">{$Plang['14531590ff6e464a']}</h3>
        <p class="wqwechat_dialogp wq_f14">{$create_font}</p>
        <div class="wqwechat_dialog_wqinput wqwechat_all">
            <input type="text" name="newname" value="" class="wqinput"  placeholder="{$Plang['6ac12c1b31f08c37']}"/>
        </div>
        <div class="wqwechat_dialog_btn wqwechat_top">
            <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick="popup.close()">{$Plang['9c825be7149e5b97']}</a>
            <input type="submit" class="wqformdialog wqwechat_determine" name="" value="{$Plang['387e9a577ee04ca3']}">
        </div>
    </div>
</form>
<!--{elseif $_GET['op']=='rename'}-->
    <form  method="get"  action = "plugin.php?id=wq_wechatreader&mod=ajax&ac={$_GET[newac]}" id="rename_folder">
        <input type="hidden" name="newfavoritesname" value="true">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="operationtype" value="rename" />
        <input type="hidden" name="aid" value="1" />
        <input type="hidden" name="yid" value="1" />
         <!--{eval $referer=dreferer();}-->
        <input type="hidden" name="referer" value="{$referer}">
        <div class="wqwechat_dialog">
            <h3 class="wqwechat_dialogh3">{$Plang['c68f8922b10cf34b']}</h3>
            <p class="wqwechat_dialogp wq_f14">{$create_font}</p>
            <div class="wqwechat_dialog_wqinput wqwechat_all">
                <!--{eval
                    $_GET['newname'] = diconv($_GET['newname'], "UTF-8", CHARSET);
                    $newname = isset($_GET['newname']) ? dhtmlspecialchars(trim($_GET['newname'])) : '';
                    $newname = str_replace(array("%", "'", "\\", "_"), "", $newname);
                    $favoritesid=intval($_GET['favoritesid']);
                }-->
                <input type="hidden" name="favoritesid" value="{$favoritesid}"/>
                <input type="text" name="newname" value="{$newname}" class="wqinput"  placeholder="{$Plang['6ac12c1b31f08c37']}"/>
            </div>
            <div class="wqwechat_dialog_btn wqwechat_top">
                <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick="popup.close()">{$Plang['9c825be7149e5b97']}</a>
                <input type="submit" class="wqformdialog wqwechat_determine" name="" value="{$Plang['387e9a577ee04ca3']}">
            </div>
        </div>
    </form>
<!--{/if}-->