<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/header}-->
    <!--{if $ac=='read'}-->
        <!--{template wq_wechatreader:wechatreader_read}-->
    <!--{elseif $ac=='fav'}-->
        <!--{template wq_wechatreader:wechatreader_fav}-->
    <!--{elseif $ac=='focus'}-->
        <!--{if $_GET['sub'] == 'manage'}-->
            <!--{template wq_wechatreader:wechatreader_fav_manage}-->
        <!--{elseif $_GET['sub']=='edit'}-->
            <!--{template wq_wechatreader:wechatreader_fav_edit}-->
        <!--{elseif $_GET['sub']=='move'}-->
            <!--{template wq_wechatreader:wechatreader_fav_move}-->
        <!--{else}-->
            <!--{if $op=='article'}-->
                <!--{template wq_wechatreader:wechatreader_article}-->
            <!--{elseif $op=='public'}-->
                <!--{template wq_wechatreader:wechatreader_public}-->
            <!--{/if}-->
        <!--{/if}-->

    <!--{else}-->
        <div class="wqwechat_per_head">
            <a href="home.php?mod=space&do=profile&uid={$_G['uid']}&mobile=2">
            <p><img src="{avatar($_G[uid], small, true)}"></p>
            <p>{$_G['username']}</p>
            </a>
        </div>
        <div class="wqwechat_per_list">
            <ul>
				<!--{if $plugin_wechatshow}-->
                <li class="wqwechat_bottom">
                    <a href="./plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first">
                        <i class="wqwechat wqwechat-xingquaihao wq_f18"></i>{$Plang['8fe539a549ff6e77']}<span class="wqy wqwechat wqwechat-jiantou-copy"></span>
                    </a>
                </li>
                <!--{/if}-->
                <li class="wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=read">
                        <i class="wqwechat wqwechat-iconfontzhizuobiaozhun13 wq_f18"></i>{$Plang['8a63516eeb150d9e']}<span class="wqy wqwechat wqwechat-jiantou-copy"></span>
                    </a>
                </li>
                <li class="wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav">
                        <i class="wqwechat wqwechat-favorite wq_f18"></i>{$Plang['e17c06793e315f8a']}<span class="wqy wqwechat wqwechat-jiantou-copy"></span>
                    </a>
                </li>
                <li class="wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatcollecting&mod=cp&ac=wechatmanage&op=list&meun=my_submit">
                        <i class="wqwechat wqwechat-tijiaoshenhe wq_f18"></i>{$Plang['dde343556ea0716c']}<span class="wqy wqwechat wqwechat-jiantou-copy"></span>
                    </a>
                </li>
            </ul>
        </div>
    <p class="wqwechat_outlogin"><a href="member.php?mod=logging&action=logout&referer=plugin.php?id=wq_wechatcollecting&formhash={FORMHASH}&handlekey=logout&mobile=2" class='wqdialog'>{$Plang['85a9775b96baa3b4']}</a></p>
    <!--{/if}-->
<!--{template wq_wechatcollecting:common/footer}-->