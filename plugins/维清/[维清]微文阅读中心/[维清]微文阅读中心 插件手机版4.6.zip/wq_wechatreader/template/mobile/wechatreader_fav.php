<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['op']=='edit'}-->
    <!--{template wq_wechatreader:wechatreader_fav_edit}-->
<!--{elseif $_GET['op']=='move'}-->
    <!--{template wq_wechatreader:wechatreader_fav_move}-->
<!--{elseif $_GET['op']=='create'|| $_GET['op']=='rename'}-->
    <!--{template wq_wechatreader:wechatreader_fav_create}-->
<!--{elseif $_GET['op']=='del'}-->
    <!--{template wq_wechatreader:wechatreader_fav_del}-->
<!--{elseif $_GET['op']=='manage'}-->
    <!--{template wq_wechatreader:wechatreader_fav_manage}-->
<!--{else}-->

    <!--{if $op!="search"}-->
        <div class="wqwechat_mask wqc_wqwechat_mask_fav" style="display: none ;" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask_fav",".wqc_wqwechat_dialog_fav")'></div>
        <div class="wqwechat_perheader wqwechat_bottom" style="z-index: 100">
            <div class="wqwechat_perheader_warp">
                <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
                <a href="javascript:;" class="wqwechat_collection" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask_fav",".wqc_wqwechat_dialog_fav")'>
                    {$favname}
                    <!--<i class="wqwechat wqwechat-jiantou01"></i>-->
                    <i class="wqwechat wqwechat-jiantou01"></i>
                </a>
                <!--{if $list}-->
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=edit&favoritesid={$favoritesid}" class="wqwechat wqwechat-bianji wqy wqedit" style="color:#fa1757;"></a>
                <!--{else}-->
                    <a href="javascript:;" class="wqwechat wqwechat-bianji wqy wqedit"></a>
                <!--{/if}-->
            </div>

            <div class="wqmanage_eject wqc_wqwechat_dialog_fav" style="display: none;">
                <div class="wqmanage_eject_warp">
                    <ul>
                        <li class="wqwechat_bottom">
                            <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav">
                                <span class="wq_title">{$Plang['fa18659e0a4166c6']}</span><!--{if $favoritesid === ""}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                            </a>
                        </li>
                        <li class="wqwechat_bottom">
                            <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid=0">
                                <span class="wq_title">{$Plang['f11bb8f10ab80417']}</span><!--{if $favoritesid===0}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                            </a>
                        </li>
                        <!--{loop $favoriteslist $key $val}-->
                            <li class="wqwechat_bottom">
                                <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&favoritesid={$val[id]}">
                                    <span class="wq_title">$val['favoritesname']</span><!--{if $val['id'] == $favoritesid}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                                </a>
                            </li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <p class="wqmanage_group"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=manage">{$Plang['6fa229d592349f6f']}</a></p>
            </div>
        </div>
        <div class="wqheight44"></div>
        <div class="wqwechat_collection_search">
            <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=search&favoritesid=all"><i class="wqwechat wqwechat-sousuo"></i>{$Plang['38224a4a6fc78c7c']}</a>
        </div>
        <script>
            $('.wqwechat_collection, .wqc_wqwechat_mask_fav').on('click', function () {
                $('.wqwechat_collection i').toggleClass('wqwechat-jiantou01').toggleClass('wqwechat-shangjiantou')
            })
        </script>
    <!--{else}-->
        <div class="wq_wechat_seaech wqwechat_bottom" >
            <div class="wq_wechat_seaech_warp wqwechat_all">
                  <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
                  <i class="wqwechat wqwechat-iconfontsousuo1 wqsearch_icon"></i>
                  <form method="get">
                      <input type="hidden" name="formhash" value="{FORMHASH}">
                      <input type="hidden" name="id" value="wq_wechatreader">
                      <input type="hidden" name="mod" value="index">
                      <input type="hidden" name="ac" value="fav">
                      <input type="hidden" name="op" value="search">
                      <input type="hidden" name="favoritesid" value="all">
                      <input type="text" name="keyword" value='{$keyword}' placeholder="{$Plang['7e28a207fdf6c483']}">
                      <button type="submit">{$Plang['38224a4a6fc78c7c']}</button>
                  </form>
            </div>
        </div>
        <div class="wqheight44"></div>
    <!--{/if}-->
    <div class="wqwechat_list pulldown_load_js" page="$page" count="$count" perpage="$perpage">
        <!--{if $list}-->
            <ul class="wqchatlist">
                <!--{subtemplate wq_wechatcollecting:common/list}-->
            </ul>
            <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
            <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;">{$Plang['b3f7b411f8a25701']}</p>
        <!--{else}-->
            <!--{if $favoritesid === "all" && $op!="search"}-->
            <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['6f1c315f450aaf00']}</p>
            <!--{elseif $op=="search"}-->
                <!--{if $keyword}-->
                     <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['995029f96a5fb86a']}</p>
                <!--{/if}-->
            <!--{else}-->
                <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['6f1c315f450aaf00']}</p>
            <!--{/if}-->
        <!--{/if}-->
    </div>

<!--{/if}-->