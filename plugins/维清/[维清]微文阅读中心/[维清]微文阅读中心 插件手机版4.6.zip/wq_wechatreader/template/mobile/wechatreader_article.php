<?php exit("Powered by www.wikin.cn"); ?>
<div class="wq_wechat_apply wqwechat_bottom">
        <div class="wq_wechat_apply_warp ">
            <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
            <ul>
                <li><a href="./plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first" <!--{if $type=='first'}--> class="on"<!--{/if}-->>{$Plang['7e2d04f7a3fe6587']}</a></li>
                <li><a href="./plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=all" <!--{if $type=='all'}--> class="on"<!--{/if}-->>{$Plang['660396e5d283970b']}</a></li>
                <li><a href="./plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public" <!--{if $op=='public'}--> class="on"<!--{/if}-->>{$Plang['f8497259f9b3f761']}</a></li>
            </ul>
        </div>
</div>
<div class="wqheight44"></div>
<div class="wqwechat_list pulldown_load_js" page="$page" count="$count" perpage="$perpage">
    <!--{if $list}-->
        <ul class="wqchatlist">
            <!--{subtemplate wq_wechatcollecting:common/list}-->
        </ul>
        <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
        <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;">{$Plang['b3f7b411f8a25701']}</p>
    <!--{else}-->
    <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>$Plang['sorry_no_article']</p>
    <!--{/if}-->
</div>
