<?php exit("Powered by www.wikin.cn"); ?>
<div class="wqwechat_perheader wqwechat_bottom">
    <div class="wqwechat_perheader_warp">
        <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>{$Plang['8a63516eeb150d9e']}
        <a href="javascript:;" class="wqwechat wqwechat-bianji wqy wqedit"></a>
    </div>
</div>
<div class="wqheight44"></div>
<div class="wqwechat_persubscribe">
    <!--{if $cache}-->
        <ul>
            <!--{loop $cache $key $val}-->
                <li><a href="plugin.php?id=wq_wechatcollecting&mod=search&keyword={$val}" data-keyword="{$val}">{$val}<i class="wqwechat wqwechat-close wq_f14" style="display: none;"></i></a></li>
            <!--{/loop}-->
        </ul>
    <!--{else}-->
    <p class="wqloaded_all"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['44c66cb466497c65']}</p>
    <!--{/if}-->
</div>
<script>
    var edit = false

    $('.wqwechat-bianji').on('click', function () {
        if ($('.wqwechat-close').length) {
            if (!edit) {
                edit = true
                $('.wqwechat-close').show()
                $(this).css('color', '#fa1757')
            } else {
                edit = false
                $('.wqwechat-close').hide()
                $(this).css('color', '#888')
            }
        }
    })

    $('.wqwechat-close').on('click', function (e) {
        var keyword = $(this).parent().data('keyword'), that = $(this)
        $.ajax({
            url: 'plugin.php?id=wq_wechatreader&mod=ajax&ac=unsubscribe&keyword=' + keyword,
            type: 'GET',
            dataType: 'JSON'
        }).success(function (res) {
            if (res.code === 0) {
                that.parents('li').remove()
                if(!$('.wqwechat-close').length) {
                    edit = false
                    $('.wqwechat-bianji').css('color', '#888')
                }
            }
        })
        return false
    })
</script>