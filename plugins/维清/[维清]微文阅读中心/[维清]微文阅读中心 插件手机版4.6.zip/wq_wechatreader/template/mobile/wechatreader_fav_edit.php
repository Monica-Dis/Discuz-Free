<?php exit("Powered by www.wikin.cn"); ?>
<div class="wqwechat_perheader wqwechat_bottom">
    <div class="wqwechat_perheader_warp">
        <span>
            <!--{if $favname}-->
                {$favname}
            <!--{else}-->
                {$Plang['fa18659e0a4166c6']}
            <!--{/if}-->
        </span>
        <a href="javascript:;" class="wqy wqnew_grouping"  onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask",".wqc_wqwechat_dialog")'>{$Plang['9c825be7149e5b97']}</a>
    </div>
</div>
<div class="wqheight44"></div>
<div class="wqwechat_move pulldown_load_js" page="$page" count="$count" perpage="$perpage">
        <!--{if $list}-->
            <ul class="wqchatlist">
                <!--{if $_GET['sub'] == 'edit'}-->
                    <!--{loop $list $key $val}-->
                        <li class="wqwechat_bottom">
                            <div class="wq_choice">
                                <input type="checkbox" name="wqwechat_move" id="wqwechat_move_{$val[id]}" class="weui_check" value="{$val[id]}">
                                <label class="weui_check_label" for="wqwechat_move_{$val[id]}"><i class="weui_icon_checked"></i></label>
                            </div>
                            <!--{eval
                                $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val['wechatid']; $getlist['displayorder'] = 'index';
                                $wechaturl = 'plugin.php?'.url_implode($getlist);
                            }-->
                            <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                            <div class="wq_img wqlazydiv">
                                <a href="{$wechaturl}"><img wqdata-src="{$logourl}" class="lazyload-home" src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg"></a>
                            </div>
                            <div class="wq_con">
                                <h3><a href="{$url}">{$val['name']}</a></h3>
                                <p class="wq_f12">
                                    <a href="javascript" class="wq_num wqellipsis"></a>
                                    <span class="wqy wqtime">
                                        <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid={$val[cid]}">{$val['classname']}</a>
                                    </span>
                                </p>
                            </div>
                        </li>
                    <!--{/loop}-->
                <!--{else}-->
                    <!--{subtemplate wq_wechatcollecting:common/list}-->
                <!--{/if}-->
            </ul>
            <p class="wqwechat_more" style="display: none;"><a href="javascript:;"><img src="./source/plugin/wq_wechatcollecting/static/images/icon_load.gif">{$Plang['ccfb539ba66bbe7d']}</a></p>
            <p class="wqloading_all wqloaded_all wqpadding0" style="display: none;">{$Plang['b3f7b411f8a25701']}</p>
        <!--{else}-->
            <p class="wqloaded_all">
                <span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['2dc3f83a42b3a77f']}
            </p>
        <!--{/if}-->
    </div>
<div class="wqheight40"></div>
<div class="wqmanage_operation wqwechat_top">
    <ul>
        <li><a href="javascript:;">{$Plang['d226b4053ebd4f34']}</a></li>
        <li><a href="javascript:;">{$Plang['0d9efacf5089d88c']}</a></li>
    </ul>
</div>
<!--{eval $Plang['9be04e9ce63fbbea'] = sprintf($Plang['9be04e9ce63fbbea'],$count);}-->
<script>
    var iswechat = '0';
    var ac = 'fav';
    var op = 'move';
    if('{$_GET[sub]}' == 'edit'){
        iswechat = '1';
        ac = 'focus';
        op = 'public&sub=move';

    }
    function edit() {
        if ($('.weui_check:checked').length > 20) {
            $(this).prop('checked', false)
            alert('{$Plang[22f5938d00cfb62d]}');
            return
        }

        if (!$('.weui_check:checked').length) {
            $('.wqmanage_operation a').eq(0).removeClass('wqwechat_bule')
            $('.wqmanage_operation a').eq(1).removeClass('wqwechat_red  wqdialog')
             $('.wqmanage_operation a').eq(0).attr('href','javascript:;');
            $('.wqmanage_operation a').eq(1).attr('href','javascript:;');
        } else if ($('.weui_check:checked').length <= 20) {
            $('.wqwechat_perheader_warp span').html("{$Plang['15ceb390db51b148']}" + $('.weui_check:checked').length + "{$Plang['9be04e9ce63fbbea']}")
            $('.wqmanage_operation a').eq(0).addClass('wqwechat_bule')
            $('.wqmanage_operation a').eq(1).addClass('wqwechat_red wqdialog')

            var aid = [];
            for(var i = 0; i < $('.weui_check:checked').length; i++) {
                aid.push($('.weui_check:checked').eq(i).val());
            }
            aid= aid.join();

            $('.wqmanage_operation a').eq(0).attr('href','plugin.php?id=wq_wechatreader&mod=index&ac='+ac+'&op='+op+'&aids='+aid+'&referer={$referer}&iswechat='+iswechat);
            $('.wqmanage_operation a').eq(1).attr('href','plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=del&type=article&aids='+aid+'&referer={$referer}&iswechat='+iswechat);
        }
    }
    $(function () {
        $(document).on('click', '.weui_check', edit)
        edit()
    })


</script>