<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_GET['type']=='folder'}-->
    <form action="plugin.php?id=wq_wechatreader&mod=ajax&ac=delfolder&iswechat={$_GET[iswechat]}" method="post" id="del_folder">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="submitdelfolder" value="true">
        <!--{eval  $favoritesids = strpos(trim($_GET['favoritesids']), ',') ? explode(',', trim($_GET['favoritesids'])) : array(intval($_GET['favoritesids']));}-->
        <!--{loop $favoritesids $key $favoritesid}-->
        <input type="hidden" name="favoritesids[]" value="{$favoritesid}" />
        <!--{/loop}-->
       <div class="wqwechat_dialog" style="top: 36%;">
           <h3 class="wqwechat_dialogh3">{$Plang['af3deb10eb1774a5']}</h3>
           <p class="wqwechat_dialogp wq_f14">{$delfolder_font}</p>
           <div class="wqwechat_dialog_btn wqwechat_top">
               <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick="popup.close();">{$Plang['9c825be7149e5b97']}</a>
               <input type="submit" name="" value="{$Plang['0d9efacf5089d88c']}" class="wqwechat_determine wqformdialog">
           </div>
       </div>
    </form>
<!--{else}-->
     <form action="plugin.php?id=wq_wechatreader&mod=ajax&ac=delarticle&iswechat={$_GET[iswechat]}" method="get" id="del_article">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="submitdel" value="true">
        <!--{eval  $aids = strpos(trim($_GET['aids']), ',') ? explode(',', trim($_GET['aids'])) : array(intval($_GET['aids']));}-->
        <!--{loop $aids $key $aid}-->
        <input type="hidden" name="aids[]" value="{$aid}" />
        <!--{/loop}-->
        <input type="hidden" name="referer" value="{$referer}">
       <div class="wqwechat_dialog" style="top: 36%;">
           <h3 class="wqwechat_dialogh3">{$Plang['d4302fdsgre48d8f']}</h3>
           <p class="wqwechat_dialogp wq_f14">{$Plang['6cbde21d55baa898']}</p>
           <div class="wqwechat_dialog_btn wqwechat_top">
               <a href="javascript:;" class="wqwechat_cancel wqwechat_right" onclick="popup.close();">{$Plang['9c825be7149e5b97']}</a>
               <input type="submit" name="" value="{$Plang['0d9efacf5089d88c']}" class="wqwechat_determine wqformdialog">
           </div>
       </div>
    </form>
<!--{/if}-->