<?php exit("Powered by www.wikin.cn"); ?>
<style>
    .wq_wechat_apply_warp ul li a {padding: 0px 4px;}
</style>
<div class="wqwechat_mask wqc_wqwechat_mask_fav" style="display: none ;" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask_fav",".wqc_wqwechat_dialog_fav")'></div>
<div class="wq_wechat_apply wqwechat_bottom">
    <div class="wq_wechat_apply_warp wqwechat_perheader_warp" style="padding: 0px 0px;">
        <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
        <ul>
            <li><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=first" <!--{if $type=='first'}--> class="on"<!--{/if}-->>{$Plang['7e2d04f7a3fe6587']}</a></li>
            <li><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=article&type=all" <!--{if $type=='all'}--> class="on"<!--{/if}-->>{$Plang['660396e5d283970b']}</a></li>
            <li>
                <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public" <!--{if $op=='public'}--> class="on"<!--{/if}-->>{$Plang['f8497259f9b3f761']}</a><i class="wqwechat wqwechat-jiantou01" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask_fav",".wqc_wqwechat_dialog_fav")'></i>
                <!--{if $list}-->
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&sub=edit&cid={$cid}" class="wqwechat wqwechat-bianji wqy wqedit" style="color:#fa1757;"></a>
                <!--{else}-->
                    <a href="javascript:;" class="wqwechat wqwechat-bianji wqy wqedit"></a>
                <!--{/if}-->
            </li>

        </ul>
    </div>
    <div class="wqmanage_eject wqc_wqwechat_dialog_fav" style="display: none;">
        <div class="wqmanage_eject_warp">
            <ul>
                <li class="wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public">
                        <span class="wq_title">{$Plang['a1e5d76323a1fd8d']}</span><!--{if $cid === ""}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                    </a>
                </li>
                <li class="wqwechat_bottom">
                    <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid=0">
                        <span class="wq_title">{$Plang['045ee7924f2db654']}</span><!--{if $cid===0}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                    </a>
                </li>
                <!--{loop $classlist $k_cid $val}-->
                    <li class="wqwechat_bottom">
                        <a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&cid={$k_cid}">
                            <span class="wq_title">$val['classname']</span><!--{if $k_cid == $cid}--><i class="wqwechat wqwechat-o3 wqy wqdui"></i><!--{/if}-->
                        </a>
                    </li>
                <!--{/loop}-->
            </ul>
        </div>
        <p class="wqmanage_group"><a href="plugin.php?id=wq_wechatreader&mod=index&ac=focus&op=public&sub=manage">{$Plang['6fa229d592349f6f']}</a></p>
    </div>
</div>

<div class="wqheight44"></div>
<div class="wqwechat_numfollow">
    <!--{if $list}-->
        <ul>
            <!--{loop $list $key $val}-->
                <!--{eval
                    $getlist = array(); $getlist[id] = 'wq_wechatshow'; $getlist[mod] = 'view'; $getlist[wid] = $val[wechatid]; $getlist['displayorder'] = 'index';
                    $url = 'plugin.php?'.url_implode($getlist);
                }-->
                <!--{eval $logourl=$val['headimage'] ? $val['headimage'] : $val['qrcode']}-->
                <li class="wqwechat_bottom_right">
                    <div class="wq_warp">
                    <div class="wq_img"><a href="{$url}"><img  src="./source/plugin/wq_wechatcollecting/static/images/wq_dian.jpg" wqdata-src="{$logourl}" class="lazyload-home"></a></div>
                    <div class="wq_con">
                        <h3><a href="{$url}">{$val['name']}</a></h3>
                        <!--{if in_array($val['id'],$subscription)}-->
                            <p>
                                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid={$val[id]}&handlekey=attention" class="wqdialog wqattention_{$val[id]}">
                                    <span>-</span> {$Plang['2c8a07313e7706bc']}
                                </a>
                            </p>
                        <!--{else}-->
                            <p>
                                <a href="plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid={$val[id]}&handlekey=attention" class="wqdialog wqattention_{$val[id]}">
                                    <span>+</span> {$Plang['2c8a07313e7706bc']}
                                </a>
                            </p>
                        <!--{/if}-->
                    </div>
                    </div>
                </li>
            <!--{/loop}-->
        </ul>
    <!--{else}-->
        <!--{if !$subscription && $op=='article'}-->
            <p class="wq_emp"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['58bef35dedb0517a']}<!--{if $plugin_wechatshow}--><br /><span><a href="plugin.php?id=wq_wechatshow" >{$Plang['522d4f8f3d5d6d97']}</a></span><!--{/if}--></p>
        <!--{else}-->
            <p class="wq_emp"><span class="wqno_content"><img src="./source/plugin/wq_wechatcollecting/static/mobile/images/no_content.png"></span>{$Plang['f6fa27d3fe7c0c6d']}</p>
        <!--{/if}-->
    <!--{/if}-->
</div>
<!--{if $multi}--><div class="wqpage">$multi</div><!--{/if}-->
<div class="wqheight44"></div>
<script>
    function errorhandle_attention(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['bef022f6310db3b9']}"){
            $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=wechatcollect&wid='+param.wid+'&handlekey=attention');
            $(".wqattention_"+param.wid+" span:first-child").html("+");
        }
        if(wq_wechat_trim(msg)=="{$Plang['61d615dc397796b8']}"){
            $(".wqattention_"+param.wid).attr("href",'plugin.php?id=wq_wechatreader&mod=ajax&ac=canclecowechat&wid='+param.wid+'&handlekey=attention');
            $(".wqattention_"+param.wid+" span:first-child").html("-");
        }
    }
</script>