<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_wechatcollecting:common/header}-->
<div class="wqwechat_perheader wqcollection_eject wqwechat_bottom">
    <div class="wqwechat_perheader_warp">
        <a href="javascript:;" class="wqreturn wq_f16" onclick='wq_wechatcollecting_cancel(".wqc_wqwechat_mask",".wqc_wqwechat_dialog")'>{$Plang['9c825be7149e5b97']}</a>
        {$h3_title}
        <div  class="wqedit wq_f16 wq_btn" onclick="$('#wqformdialog').click()">{$Plang['387e9a577ee04ca3']}</div>
    </div>
</div>
<div class="wqheight44"></div>
<form method="post" id="add_favorites" action='plugin.php?id=wq_wechatreader&mod=ajax&ac={$ac}' >
    <input type="hidden" name="newfavoritesname" value="true">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="aid" value="{$_GET[aid]}" />
    <input type="hidden" name="del" value="{$_GET[del]}" />
    <input type="hidden" name="yid" value="{$_GET[favoritesid]}" />
    <input type="hidden" name="isview" value="{$_GET[isview]}" />
    <input type="hidden" name="favoritesid" value="{$list[0][id]}" id="favoritesid">
    <div class="wqwechat_group_warp wqwechat_padding">
        <ul>
            <!--{loop $list $key $val}-->
                <li class="wqwechat_bottom wqc_wqwechat_bottom" favoritesid="{$val[id]}">
                    <a href="javascript:;">
                        <span class="wq_title">{$val[$_key]}</span>
                        <span class="wq_num">({$val['favoritesnum']})</span>
                        <!--{if $key==0}-->
                           <i class="wqwechat wqwechat-o3 wq_dui"></i>
                        <!--{/if}-->
                    </a>
                </li>
            <!--{/loop}-->
        </ul>
    </div>
    <button type="submit" style="display:none" id='wqformdialog' class='wqformdialog' >{$Plang['387e9a577ee04ca3']}</button>
</form>
<div class="wqheight40"></div>
<div class="wqmanage_operation wqwechat_top wqwechat_widtn100">
    <ul>
        <li>
            <a href='plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=create&iswechat={$iswechat}&newac={$newac}' class="wqwechat_bule wqdialog" id="wqwechat_create">
                {$add_font}
            </a>
        </li>
    </ul>
</div>

<script type="text/javascript" reload="1">
    $(function() {
        $(document).on('click', '.wqc_wqwechat_bottom', function () {
            var id=$(this).attr('favoritesid');
            wq_clear_Selected();
            $("#favoritesid").val(id);
            wqjq(this).prepend('<i class="wqwechat wqwechat-o3 wq_dui"></i>');
        });
    });

    function errorhandle_create_folder(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['43f8689c027bd4ff']}"){
            $('.wqwechat_padding ul').append('<li class="wqwechat_bottom wqc_wqwechat_bottom" favoritesid="'+param.id+'"><a href="javascript:;"><span class="wq_title">'+param.name+'</span><span class="wq_num">(0)</span></a></li>')
        }
    }

    function errorhandle_add_favorites(msg){
        var success_msg = wq_wechat_trim(msg);
        if(success_msg == "{$Plang[50434686adcc5824]}" || success_msg == "{$Plang['attention_do_success']}"){
            setTimeout(function () {
                self.location=document.referrer;
            }, 1000)
        }
    }
 </script>
<!--{template wq_wechatcollecting:common/footer}-->