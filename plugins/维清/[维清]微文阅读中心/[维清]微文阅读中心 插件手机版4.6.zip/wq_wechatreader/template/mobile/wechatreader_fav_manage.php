<?php exit("Powered by www.wikin.cn"); ?>
<div class="wqwechat_perheader wqwechat_bottom">
    <div class="wqwechat_perheader_warp">
        <a href="javascript:history.go(-1);" class="wqwechat wqwechat-fanhui-copy wqreturn"></a>
        {$Plang['6fa229d592349f6f']}
        <a href="plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=create<!--{if $_GET['sub'] == 'manage'}-->&iswechat=1<!--{/if}-->" class="wqy wqnew_grouping wqdialog">{$Plang['14531590ff6e464a']}</a>
    </div>
</div>
<div class="wqheight44"></div>

<div class="wqwechat_group_warp">
    <ul>
        <li class="wqwechat_bottom" style="padding:0px 12px;">
            <a href="javascript:;">
                <span class="wq_title">{$default_font}</span>
                <span class="wq_num">(<i id="default_num_0">{$default_num}</i>)</span>
            </a>
        </li>
        <!--{loop $favoriteslist $key $val}-->
            <li class="wqwechat_bottom"  id='foldername_{$val[id]}'>
                <a href="javascript:;">
                    <span class="wqchoice">
                        <input type="checkbox" name="deletes[]" id="wqmanage_group_{$val[id]}" class="weui_check" value="{$val[id]}">
                        <label class="weui_check_label" for="wqmanage_group_{$val[id]}"><i class="weui_icon_checked"></i></label>
                    </span>
                    <span class="wq_title" >{$val[$_key]}</span>
                    <span class="wq_num">({$val['favoritesnum']})</span>
                </a>
            </li>
        <!--{/loop}-->
    </ul>
</div>
<div class="wqheight40"></div>
<div class="wqmanage_operation wqwechat_top">
    <ul>
        <li><a href="javascript:;">{$Plang['c68f8922b10cf34b']}</a></li>
        <li><a href="javascript:;">{$Plang['16fec35056f3de2b']}</a></li>
    </ul>
</div>

<script type="text/javascript" reload="1">
    var iswechat = '{$_GET[sub]}' == 'manage' ? '1' : '0';
    function errorhandle_create_folder(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['43f8689c027bd4ff']}"){
            $('.wqwechat_group_warp ul').append('<li class="wqwechat_bottom" id="foldername_'+param.id+'"><a href="javascript:;"><span class="wqchoice"><input type="checkbox" name="wqmanage_group" id="wqmanage_group_'+param.id+'" class="weui_check" value="'+param.id+'"><label class="weui_check_label" for="wqmanage_group_'+param.id+'"><i class="weui_icon_checked"></i></label></span><span class="wq_title">'+param.name+'</span><span class="wq_num">(0)</span></a></li>')
        }

    }

    function errorhandle_del_folder(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['del_succeed']}"){
            $.each(param.ids,function(i,n){
                $("#foldername_"+n).remove();
            });
            var num = parseInt($("#default_num_0").html())+parseInt(param.num);
            $("#default_num_0").html(num);
        }
    }

    function errorhandle_rename_folder(msg,param){
        if(wq_wechat_trim(msg)=="{$Plang['43f86renamed4ff']}"){
            $("#foldername_"+param.id+" .wq_title" ).html(param.name);
        }
    }

    $(document).on('click', '.weui_check', function () {
        if (!$('.weui_check:checked').length) {
            $('.wqmanage_operation a').eq(0).removeClass('wqwechat_bule wqdialog');
            $('.wqmanage_operation a').eq(0).attr('href','javascript:;');
            $('.wqmanage_operation a').eq(1).removeClass('wqwechat_red wqdialog');
            $('.wqmanage_operation a').eq(1).attr('href','javascript:;');
        } else if ($('.weui_check:checked').length == 1) {
            $('.wqmanage_operation a').eq(0).addClass('wqwechat_bule wqdialog');
            var newname=$('.weui_check:checked').parent().siblings('.wq_title').html();
            var favoritesid=$('.weui_check:checked').val();
            $('.wqmanage_operation a').eq(0).attr('href','plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=rename&newname='+newname+'&favoritesid='+favoritesid+'&iswechat='+iswechat);

            $('.wqmanage_operation a').eq(1).addClass('wqwechat_red wqdialog');
            var folderid=$('.weui_check:checked').val();
            $('.wqmanage_operation a').eq(1).attr('href','plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=del&type=folder&favoritesids='+folderid+'&iswechat='+iswechat);

        } else if ($('.weui_check:checked').length > 1) {
            $('.wqmanage_operation a').eq(0).removeClass('wqwechat_bule wqdialog');
            $('.wqmanage_operation a').eq(0).attr('href','javascript:;');

            var folderid = [];
            for(var i = 0; i < $('.weui_check:checked').length; i++) {
                folderid.push($('.weui_check:checked').eq(i).val());
            }
            folderid= folderid.join();

            $('.wqmanage_operation a').eq(1).attr('href','plugin.php?id=wq_wechatreader&mod=index&ac=fav&op=del&type=folder&favoritesids='+folderid+'&iswechat='+iswechat);
        }
    })
</script>