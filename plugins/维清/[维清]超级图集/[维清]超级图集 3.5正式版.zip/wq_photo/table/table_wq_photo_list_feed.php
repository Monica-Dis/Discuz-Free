<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_appstore_sample.php 2017-2-14 09:07:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_photo_list_feed extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_photo_list_feed';
		$this->_pk = 'feedid';
		parent::__construct();
	}

	public function fetch_all_by_cid($cid) {
		return DB::fetch_all("SELECT * FROM %t WHERE cid=%d", array($this->_table, $cid));
	}

	public function fetch_by_tid($tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array($this->_table, $tid));
	}

	public function fetch_all_by_search($cid, $keyword = "", $start = 0, $limit = 10, $displayorder = 'dateline', $orderby = 'DESC', $rand = false) {
		$val[] = $this->_table;
		$val[] = 'forum_thread';
		$sql[] = '1';


		if($displayorder && $orderby) {
			if($rand) {
				$rand = ',rand()';
			}
			$order = ' ORDER BY f.' . $displayorder . ' ' . $orderby . $rand . ' ';
		}

		if($cid) {
			$sql[] = 'f.cid=%d';
			$val[] = $cid;
		}

		if($keyword) {
			$sql[] = 't.subject LIKE %s';
			$val[] = '%' . $keyword . '%';
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT f.*,f.cover wqcover,t.* FROM %t f LEFT JOIN %t t ON f.tid=t.tid WHERE " . $wheresql . $order . DB::limit($start, $limit), $val, 'tid');
	}

	public function count_by_search($cid) {
		$val[] = $this->_table;
		$sql[] = '1';

		if($cid) {
			$sql[] = 'cid=%d';
			$val[] = $cid;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function count_by_keyword_search($keyword) {
		$val[] = $this->_table;
		$val[] = 'forum_thread';
		$sql[] = '1';

		if($keyword) {
			$sql[] = 't.subject LIKE %s';
			$val[] = '%' . $keyword . '%';
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t f LEFT JOIN %t t ON f.tid=t.tid  WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>