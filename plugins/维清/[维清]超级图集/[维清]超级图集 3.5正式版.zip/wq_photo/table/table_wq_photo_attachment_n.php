<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_appstore_sample.php 2017-2-14 09:07:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_photo_attachment_n extends discuz_table {

	public function __construct() {
		$this->_table = '';
		$this->_pk = '';
		parent::__construct();
	}

	private function _get_table($tid) {
		$this->_table = $tableid = substr($tid, -1);
		if($tableid >= 0 && $tableid < 10) {
			return 'wq_photo_attachment_' . intval($tableid);
		} else {
			throw new DbException('Table wq_photo_attachment_' . $this->_table . ' has not exists');
		}
	}

	public function insert($tableid, $data) {
		if(!$data) {
			return;
		}
		return DB::insert($this->_get_table($tableid), $data);
	}

	public function update($tableid, $newdata, $data) {
		if(!$data || !$newdata) {
			return;
		}
		return DB::update($this->_get_table($tableid), $newdata, $data);
	}

	public function delete_by_tid($tid) {
		return DB::delete($this->_get_table($tid), array('tid' => $tid));
	}

	public function delete_by_tid_aid($tid, $aid) {
		return DB::delete($this->_get_table($tid), array('tid' => $tid, 'aid' => $aid));
	}

	public function fetch_all_by_tableid($tid) {
		if(!$tid) {
			return;
		}

		return DB::fetch_all("SELECT * FROM %t WHERE tid=%d ORDER BY displayorder ASC ", array($this->_get_table($tid), $tid));
	}

	public function fetch_by_tid_aid($tid, $aid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d AND aid=%d", array($this->_get_table($tid), $tid, $aid));
	}

	public function fetch_end_displayorder_by_tid($tid) {
		if(!$tid) {
			return 0;
		}
		return DB::fetch_first("SELECT displayorder FROM %t WHERE tid=%d ORDER BY displayorder DESC", array($this->_get_table($tid), $tid));
	}

}
//From: Dism_taobao-com
?>