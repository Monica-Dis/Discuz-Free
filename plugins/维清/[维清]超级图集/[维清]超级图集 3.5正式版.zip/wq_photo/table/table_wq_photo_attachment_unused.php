<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_appstore_sample.php 2017-2-14 09:07:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_photo_attachment_unused extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_photo_attachment_unused';
		parent::__construct();
	}

	public function fetch_by_aid($aid) {
		return DB::fetch_first("SELECT * FROM %t WHERE aid=%d", array($this->_table, $aid));
	}

	public function fetch_all_by_aids($aids) {
		return DB::fetch_all("SELECT * FROM %t WHERE aid IN(%n) ORDER BY dateline DESC", array($this->_table, $aids), 'aid');
	}

	public function delete($aid) {
		return DB::delete($this->_table, array('aid' => $aid));
	}

}
//From: Dism_taobao-com
?>