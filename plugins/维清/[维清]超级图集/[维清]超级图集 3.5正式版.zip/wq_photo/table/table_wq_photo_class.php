<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_video_class.php 2017-4-14 22:35:59Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_photo_class extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_photo_class';
		$this->_pk = 'cid';
		parent::__construct();
	}

	public function update_incrcase($cid, $setarr, $operation = true) {
		$sql = array();
		$allowkey = array('threads');
		foreach($setarr as $key => $val) {
			if(($val = intval($val) && in_array($key, $allowkey))) {
				if($operation == true) {
					$sql[] = "`$key`=`$key`+$val";
				} else {
					$sql[] = "`$key`=`$key`-$val";
				}
			}
		}
		$where = DB::field('cid', $cid);
		if(!empty($sql)) {
			return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $where));
		}
	}

	public function fetch_all_by_search($status = "", $displayorder = 'displayorder', $order = 'ASC') {
		$val[] = $this->_table;
		$sql[] = '1';
		if(!empty($displayorder) && !empty($order)) {
			$order = ' ORDER BY `' . $displayorder . '` ' . $order;
		}
		if($status !== "") {
			$sql[] = 'status=%d';
			$val[] = $status;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $wheresql . $order, $val);
	}

	public function count_by_search($status = "") {
		$val[] = $this->_table;
		$sql[] = '1';

		if($status !== "") {
			$sql[] = 'status=%d';
			$val[] = $status;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

}
//From: Dism_taobao-com
?>