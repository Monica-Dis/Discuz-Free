<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_appstore_sample.php 2017-2-14 09:07:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_photo_attachment extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_photo_attachment';
		$this->_pk = 'aid';
		parent::__construct();
	}

	public function fetch_by_cid($cid) {
		return DB::fetch_first("SELECT * FROM %t WHERE cid=%d", array($this->_table, $cid));
	}

	public function fetch_by_aid_uid($aid, $uid, $unused = false) {

		return DB::fetch_first("SELECT * FROM %t WHERE aid=%d AND uid=%d", array($this->_table, $aid, $uid));
	}

	public function fetch_by_tid($tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array($this->_table, $tid));
	}

	public function delete_by_tid($tid) {
		return DB::delete($this->_table, array('tid' => $tid));
	}

	public function fetch_all_unused_aid_by_uid($uid) {
		return DB::fetch_all("SELECT aid FROM %t WHERE uid=%d AND tableid<1", array($this->_table, $uid));
	}

}
//From: Dism_taobao-com
?>