<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_special.inc.php 2017-2-15 10:13:48Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/config.php';
if(!submitcheck('seosubmit')) {
	echo <<<EOT
    <script src="source/plugin/wq_photo/static/js/jquery-1.8.3.pc.js"></script>
	<script>
		function setHeight() {
			var tab = wqjq('.floattop')[0]
			var fill = wqjq('.floattopempty')[0]
			fill.style.marginTop = (tab.clientHeight - 35 -16) + 'px'
		}
		wqjq(window).resize(setHeight)
		setHeight()
	</script>
EOT;


	echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';
	$photo_seo = dunserialize($_G['setting']['photo_seo']);
	$page = array(
		'list' => array('bbname', 'pluginname', 'classname'),
		'view' => array('bbname', 'pluginname', 'classname', 'title'),
	);
	showformheader('plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_photo&pmod=admincp_seo');
	showtableheader();
	foreach($page as $key => $value) {
		$code = $Plang['3bc832bd0cf768e4'];
		foreach($value as $v) {
			$code .= '<a onclick="insertContent(this, \'{' . $v . '}\');return false;" href="javascript:;" title="' . $Plang[$v] . '">{' . $Plang[$v] . '}</a>';
		}
		showtitle($Plang['photo_' . $key]);
		showsetting($Plang['f7ae0f5162e383ed'], 'photo_seo[' . $key . '][seotitle]', $photo_seo[$key]['seotitle'], 'text', '', 0, $code);
		showsetting($Plang['534903eeef4b3b40'], 'photo_seo[' . $key . '][seokeywords]', $photo_seo[$key]['seokeywords'], 'text', '', 0, $code);
		showsetting($Plang['59d72389b36e3022'], 'photo_seo[' . $key . '][seodescription]', $photo_seo[$key]['seodescription'], 'text', '', 0, $code);
	}
	showsubmit('seosubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$photo_seo = serialize($_GET['photo_seo']);
	C::t('common_setting')->update('photo_seo', $photo_seo);
	updatecache('setting');
	cleartemplatecache();
	cpmsg($Plang['9a52f4d6ef956904'], 'action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=wq_photo&pmod=admincp_seo', 'succeed');
}
//From: Dism_taobao-com
?>