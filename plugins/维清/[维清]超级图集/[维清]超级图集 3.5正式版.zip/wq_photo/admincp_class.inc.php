<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_class.inc.php 2017-7-4 18:07:37Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/config.php';

$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_photo&pmod=admincp_class';
$cpurl = 'action=' . $url;
$mpurl = ADMINSCRIPT . '?action=' . $url;
$ac = in_array($_GET['ac'], array('del', 'move')) ? dhtmlspecialchars($_GET['ac']) : "";
$cid = $_GET['cid'] ? intval($_GET['cid']) : 0;

if($ac == "del") {
	$data = C::t("#wq_photo#wq_photo_attachment")->fetch_by_cid($cid);
	if(!$data) {
		C::t("#wq_photo#wq_photo_class")->delete($cid);
		wq_photo_cache_all_class();
		cpmsg($Plang['8987fdbb54a9953a'], $cpurl, 'succeed');
	}

	$select = wq_photo_admincp_get_select_class($cid);
	cpmsg($Plang['2b1dfc41a622f468'], $cpurl . '&ac=move&cid=' . $cid, 'form', array(), $select, TRUE, ADMINSCRIPT . '?' . $cpurl);
}

if($ac == "move") {
	$newcid = $_GET['newcid'] ? intval($_GET['newcid']) : 0;
	if(!$newcid) {
		cpmsg($Plang['91a4d02f4f0f6ba9'], $cpurl . '&ac=del&cid=' . $cid, 'error');
	}
	if($cid) {
		DB::update('wq_photo_attachment', array('cid' => $newcid), array('cid' => $cid));
		C::t("#wq_photo#wq_photo_class")->delete($cid);
		wq_photo_cache_all_class();
	}
	cpmsg($Plang['8987fdbb54a9953a'], $cpurl, 'succeed');
}

if(!submitcheck('editsubmit')) {
	showtips($Plang['lif6ge3w43t434li'], 'tips', true, $Plang['711ee2d6c46bc5a3']);

	$status = in_array($_GET['status'], array('0', '1')) ? $_GET['status'] : '';
	$displayorder = in_array($_GET['displayorder'], array('displayorder', 'dateline')) ? $_GET['displayorder'] : 'displayorder';
	$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? $_GET['ordertype'] : 'asc';

	$lists = C::t("#wq_photo#wq_photo_class")->fetch_all_by_search($status, $displayorder, $ordertype);
	$count = C::t("#wq_photo#wq_photo_class")->count_by_search($status);

	$typehtml = radio_html(array('desc' => $Plang['5bee37fbebf639d9'], 'asc' => $Plang['d85de5630e53b00f']), 'ordertype', $ordertype);
	$orderhtml = select_html(array('displayorder' => $Plang['1670da9c2989259f'], 'dateline' => $Plang['7de4775a64db4b43']), 'displayorder', $displayorder, false);
	$statushtml = select_html(array('1' => $Plang['a28baeaf9e585cb1'], '0' => $Plang['beb08d096719774b']), 'status', $status);

	echo"<style tpye='text/css'>
        li{float:left;}
        .mradio_html li{line-height:25px;}
    </style>";
	showformheader($url, '', 'submitform');
	showtableheader('', 'nobottom');
	showtablerow('', array('width="60px"', 'width="80px"', 'width="100px"', 'width="60px"', 'width="100px"', ''), array(
		$Plang['4b8fa55183fc5158'] . ":", $orderhtml, $typehtml, $Plang['466c256bd250f7d1'] . ":", $statushtml, ''
	));
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();

	showformheader($url);
	showtableheader($Plang['afa250ab27ef1230'], 'nobottom');
	showsubtitle(array($Plang['dbcffdf31e86d2d8'], $Plang['bfc2d2077df31158'], $Plang['466c256bd250f7d1'], $Plang['7fbda538f60ca50f'], $Plang['7de4775a64db4b43'], $Plang['93f5ca01b006206c'], ""), 'header', array('width="70px"', 'width="260px"', 'width="70px"', 'width="100px"', 'width="200px"', 'width="120px"', ''));
	foreach($lists as $key => $val) {
		$status = $val['status'] ? 'checked' : '';
		showtablerow('', array('width="70px"', 'width="260px"', 'width="70px"', 'width="100px"', 'width="200px"', 'width="120px"', ''), array(
			'<input name = "displayorder[' . $val['cid'] . ']" style="width:50px"  value="' . $val['displayorder'] . '" type = "number">',
			'<input name = "name[' . $val['cid'] . ']" value="' . $val['cname'] . '" type = "text">(cid:' . $val['cid'] .
			')<input name = "cid[' . $val['cid'] . ']" value="' . $val['cid'] . '" type = "hidden">',
			'<input class = "fs" type = "checkbox" name = "status[' . $val['cid'] . ']" value = "1" ' . $status . ' />',
			intval($val['videos']),
			$val['dateline'] ? date("Y-m-d H:i:s", $val['dateline']) : " --",
			'<a onclick="del_confirm()" href="' . ADMINSCRIPT . '?' . $cpurl . '&ac=del&cid=' . $val['cid'] . '">' . $Plang['0d9efacf5089d88c'] . '</a>',
			'',
			)
		);
	}

	echo '<tr><td colspan = "6"><div><a href = "javascript:;
    " onclick = "wq_addrow(this, 0, 0)" class = "addtr">' . $Plang['b7d63548f8406158'] . '</a></div></td></tr>';
	showsubmit('editsubmit', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
	$insertstatus = '<input name="insertstatus[\'+addrowkey+\']" value="1"  type="checkbox" checked="checked">';
	echo <<<EOF
    <script type='text/JavaScript'>
        var addrowdirect = 0;
    var addrowkey = 0;
    function wq_addrow(obj, type,flag) {
        if(flag == 2){
            addrowkey--;
        }else{
            var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
            if(!addrowdirect) {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
            } else {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
            }
          var rowtypedata = [[[1,'<input name = "insertdisplayorder[]" style="width:50px"  value="0" type = "number">'],[1,'<input name = "insertname[]"  value="" type = "text">'],[1,'<div>{$insertstatus}&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this),wq_addrow(this, 0,2)">{$Plang['0d9efacf5089d88c']}</a></div>']],];

            var typedata = rowtypedata[type];
            for(var i = 0; i <= typedata.length - 1; i++) {
                    var cell = row.insertCell(i);
                    cell.colSpan = typedata[i][0];
                    var tmp = typedata[i][1];
                    if(typedata[i][2]) {
                            cell.className = typedata[i][2];
                    }
                    tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                    tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return wq_addrow.arguments[parseInt($2) + 1];});
                    cell.innerHTML = tmp;
            }
            addrowkey ++;
            addrowdirect = 0;
        }
    }
    function del_confirm(){
        if (!confirm("{$Plang['8e3a2fd25fc4d79d']}")){
            window.event.returnValue = false;
        }
    }
    </script>
EOF;
} else {
	$m = $n = 0;
	foreach($_GET['cid'] as $key => $cid) {
		$name = $_GET['name'][$cid] && !empty($_GET['name'][$cid]) ? dhtmlspecialchars($_GET['name'][$cid]) : "";
		$status = $_GET['status'][$cid] ? intval($_GET['status'][$cid]) : 0;
		$displayorder = $_GET['displayorder'][$cid] ? intval($_GET['displayorder'][$cid]) : 0;

		if(empty($name)) {
			$n ++;
			continue;
		}

		$data = array(
			'cname' => $name,
			'displayorder' => $displayorder,
			'status' => $status,
		);
		C::t("#wq_photo#wq_photo_class")->update($cid, $data);
	}
	foreach($_GET['insertname'] as $key => $val) {
		$insertname = $val && !empty($val) ? dhtmlspecialchars($val) : "";
		$insertstatus = $_GET['insertstatus'][$key] ? intval($_GET['insertstatus'][$key]) : 0;
		$insertdisplayorder = $_GET['insertdisplayorder'][$key] ? intval($_GET['insertdisplayorder'][$key]) : 0;
		if(empty($insertname)) {
			$m ++;
			continue;
		}
		$data = array(
			'cname' => $insertname,
			'displayorder' => $insertdisplayorder,
			'status' => $insertstatus,
			'dateline' => TIMESTAMP,
		);
		C::t("#wq_photo#wq_photo_class")->insert($data);
	}
	wq_photo_cache_all_class();

	if($m > 0 || $n > 0) {
		$msg = sprintf($Plang['2b7d6f5d837e6457'], $m, $n);
		cpmsg($msg, $cpurl, 'error');
	} else {
		cpmsg($Plang['9a52f4d6ef956904'], $cpurl, 'succeed');
	}
}
//From: Dism_taobao-com
?>