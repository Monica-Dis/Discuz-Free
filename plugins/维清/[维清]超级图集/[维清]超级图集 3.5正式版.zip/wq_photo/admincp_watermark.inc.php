<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_special.inc.php 2017-2-15 10:13:48Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/config.php';

if(!submitcheck('form')) {

	$formurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_photo&pmod=admincp_watermark';

	$watermarks = is_array($_G['setting']['wq_photo_imgwater']) ? $_G['setting']['wq_photo_imgwater'] : dunserialize($_G['setting']['wq_photo_imgwater']);
	$watermarkstatus = $watermarks['watermarkstatus'];
	$watermarktype = $watermarks['watermarktype'];
	$watermarkquality = $watermarks['watermarkquality'];
	$watermarktrans = $watermarks['watermarktrans'];
	$watermarkminheight = $watermarks['watermarkminheight'];
	$watermarkminwidth = $watermarks['watermarkminwidth'];

	$checkwm = array($watermarkstatus => 'checked');
	showformheader($formurl, '', 'form');
	showtableheader($Plang['8ad7977118720608'], 'nobottom');
	showsetting($Plang['ae81aecc77d84d10'], '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td colspan="2"><input class="radio" type="radio" name="watermarkstatus" value="0" ' . $checkwm[0] . '>' . $Plang['0b4a5bc9727b7878'] . '</td></tr><tr><td><input class="radio" type="radio" name="watermarkstatus" value="1" ' . $checkwm[1] . '> #1</td><td><input class="radio" type="radio" name="watermarkstatus" value="2" ' . $checkwm[2] . '> #2</td><td><input class="radio" type="radio" name="watermarkstatus" value="3" ' . $checkwm[3] . '> #3</td></tr><tr><td><input class="radio" type="radio" name="watermarkstatus" value="4" ' . $checkwm[4] . '> #4</td><td><input class="radio" type="radio" name="watermarkstatus" value="5" ' . $checkwm[5] . '> #5</td><td><input class="radio" type="radio" name="watermarkstatus" value="6" ' . $checkwm[6] . '> #6</td></tr><tr><td><input class="radio" type="radio" name="watermarkstatus" value="7" ' . $checkwm[7] . '> #7</td><td><input class="radio" type="radio" name="watermarkstatus" value="8" ' . $checkwm[8] . '> #8</td><td><input class="radio" type="radio" name="watermarkstatus" value="9" ' . $checkwm[9] . '> #9</td></tr></table>', '', '', $Plang['f57d73b619132b2f']);

	showsetting($Plang['30c18279c14ca3aa'], array('watermarkminwidth', 'watermarkminheight'), array(intval($watermarkminwidth), intval($watermarkminheight)), 'multiply', '', '', $Plang['8ddbd8d4adf01aec']);
	showsetting($Plang['e229ed7f08dbf1dc'], array('watermarktype', array(
			array('gif', $Plang['fa96cd724ccbd514']),
			array('png', $Plang['0707cfcdb6a4f52f']),
		)), $watermarktype, 'mradio', '', '', $Plang['9fea4f63ca1a8ea1']);
	showsetting($Plang['0c210418dccc135a'], 'watermarktrans', $watermarktrans, 'text', '', '', $Plang['1c6b9bc53aecc277']);
	showsetting($Plang['92d38183353fe795'], 'watermarkquality', $watermarkquality, 'text', '', '', $Plang['3ad1cf4910882f1d']);
	showsubmit("form", "submit");
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {

	$data = array(
		'watermarkstatus' => intval($_GET['watermarkstatus']),
		'watermarktrans' => intval($_GET['watermarktrans']),
		'watermarkquality' => intval($_GET['watermarkquality']),
		'watermarktype' => dhtmlspecialchars($_GET['watermarktype']),
		'watermarkminheight' => intval($_GET['watermarkminheight']),
		'watermarkminwidth' => intval($_GET['watermarkminwidth']),
	);

	C::t('common_setting')->update('wq_photo_imgwater', $data);
	updatecache('setting');
	cpmsg($Plang['9a52f4d6ef956904'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_photo&pmod=admincp_watermark', 'succeed');
}
//From: Dism_taobao-com
?>