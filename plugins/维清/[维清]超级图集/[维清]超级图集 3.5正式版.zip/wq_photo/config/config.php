<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2017-7-4 18:07:37Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache(array('wq_photo_class', 'plugin'));

if($_G['cache']['plugin']['wq_base']) {
	include_once DISCUZ_ROOT . './source/plugin/wq_base/config/config.php';
}
include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_photo/function/function_photo.php';

$wq_photo_class = $_G['cache']['wq_photo_class'] ? $_G['cache']['wq_photo_class'] : wq_photo_cache_all_class();

$wq_photo_imgwater = wq_photo_imgwater_default_value();
$wq_photo_imgwater = $_G['setting']['wq_photo_imgwater'] ? unserialize($_G['setting']['wq_photo_imgwater']) : $wq_photo_imgwater;

$imageUrl = "./source/plugin/wq_photo/static/images/";
$wqfid = intval($_G['setting']['wqphotofollowforumid']);

$Plang = wq_loadlang('wq_photo');

$setting = wq_loadsetting('wq_photo');
if($_G['cache']['plugin']['wq_base']) {
	$setting['pc_color'] = $setting['pc_color'] ? $setting['pc_color'] : $baseSetting['pc_color'];
	$setting['mobile_color'] = $setting['mobile_color'] ? $setting['mobile_color'] : $baseSetting['mobile_color'];
	$setting = array_merge(array_merge($baseSetting, $setting));
}
$photo_nav = array(
	array('0' => $Plang['8c02197cf9016cd5'], '1' => 'plugin.php?id=wq_photo&mod=list'),
	array('0' => $Plang['501d640c506bc6c4'], '1' => 'forum.php?mod=post&action=newthread&fid=' . $wqfid . '&specialextra=wq_photo'),
);
if(!empty($setting['topnav'])) {
	foreach($setting['topnav'] as $key => $value) {
		$photo_nav[] = $value;
	}
}

$setting['topnav'] = wq_photo_get_nav_urlinfo($photo_nav);

$setting['pc_color'] = !empty($setting['pc_color']) ? $setting['pc_color'] : $setting['pc_style'];
$setting['mobile_color'] = !empty($setting['mobile_color']) ? $setting['mobile_color'] : $setting['mobile_style'];


if($_SERVER["HTTP_REFERER"]) {
	$wqphotoreferer = "javascript:history.back();";
} else {
	if($setting['mobile_back_url'] == 1) {
		$wqphotoreferer = $_G['siteurl'];
	} else {
		$wqphotoreferer = "plugin.php?id=wq_photo";
	}
}

$wq_login = $_G['cache']['plugin']['wq_login'];
$searchurl = 'plugin.php?id=wq_photo&mod=search';
$is_system_headbottom = $setting['is_system_headbottom'];
$topnav = $setting['topnav'];
$set_color = $setting['pc_color'];
$mobileset_color = $setting['mobile_color'];
$photo_seo = dunserialize($_G['setting']['photo_seo']);

?>