<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-8-2 16:13:20Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_photo'];
$setting['pluginname'] = trim($setting['pluginname']);
$setting['is_system_headbottom'] = intval($setting['is_system_headbottom']);
$setting['mainnav'] = trim($setting['mainnav']);
$setting['pc_color'] = trim($setting['pc_color']);
$setting['pc_union_ad'] = trim($setting['pc_union_ad']);
$setting['mobile_logoname'] = trim($setting['mobile_logoname']);
$setting['mobile_color'] = trim($setting['mobile_color']);
$setting['mobile_list_style'] = intval($setting['mobile_list_style']);
$setting['mobile_hotsearch'] = trim($setting['mobile_hotsearch']);
$setting['list_perpage'] = intval($setting['list_perpage']);
$setting['upload_maxsize'] = intval($setting['upload_maxsize']);
$setting['is_use_qiniu'] = intval($setting['is_use_qiniu']);
$setting['qiniu_ak'] = trim($setting['qiniu_ak']);
$setting['qiniu_sk'] = trim($setting['qiniu_sk']);
$setting['qiniu_bucket'] = trim($setting['qiniu_bucket']);
$setting['qiniu_domain'] = trim($setting['qiniu_domain']);
$setting['is_image_make_thumb'] = intval($setting['is_image_make_thumb']);
$setting['icon_thumb_minwidth'] = intval($setting['icon_thumb_minwidth']);
$setting['is_image_make_watermark'] = intval($setting['is_image_make_watermark']);

?>