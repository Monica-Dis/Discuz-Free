<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2017-7-4 18:07:37Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_photo/config/setting_base.php';

$setting['upload_maxsize'] = $setting['upload_maxsize'] < 1 ? 1 : $setting['upload_maxsize'];
$setting['icon_thumb_minwidth'] = $setting['icon_thumb_minwidth'] ? $setting['icon_thumb_minwidth'] : 640;
$setting['mobile_logoname'] = $setting['mobile_logoname'] ? $setting['mobile_logoname'] : 'wq_logo.png';
$setting['topnav'] = array();
if(!empty($setting['mainnav'])) {
	$mainnav = explode("\n", str_replace("\r\n", "\n", $setting['mainnav']));
	foreach($mainnav as $key => $nav) {
		$setting['topnav'][] = explode("|", str_replace(" ", "", $nav));
	}
}
$setting['mobile_hotsearch'] = !empty($setting['mobile_hotsearch']) ? explode("\n", str_replace("\r\n", "\n", $setting['mobile_hotsearch'])) : array();
array_filter($setting['mobile_hotsearch']);

?>