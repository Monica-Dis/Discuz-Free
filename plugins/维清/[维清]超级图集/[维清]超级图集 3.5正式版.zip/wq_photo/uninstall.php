<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2017-7-4 18:07:37Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_photo/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_photo_class`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_unused`;
DROP TABLE IF EXISTS `pre_wq_photo_list_feed`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_0`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_1`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_2`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_3`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_4`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_5`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_6`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_7`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_8`;
DROP TABLE IF EXISTS `pre_wq_photo_attachment_9`;
EOF;
		runquery($sql);

		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_photo.php");

		require_once DISCUZ_ROOT . './source/plugin/wq_photo/config/loadfunc.php';
		wq_rmdir(DISCUZ_ROOT . './data/cache/wq_photo/');

		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//From: Dism_taobao-com
?>