<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_photo.inc.php 2016-10-19 02:51:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_photo_get_Tlang() {

	include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/loadfunc.php';
	$langfile = DISCUZ_ROOT . './source/plugin/wq_photo/language/language.' . currentlang() . '.php';

	if(is_file($langfile)) {
		$includefile = $langfile;
	} else {
		$includefile = libfile('language', 'plugin/wq_photo/language');
	}
	include $includefile;
	global $Tlang;

	return $Tlang;
}

function wq_photo_get_style() {

	$Tlang = wq_photo_get_Tlang();

	return $styles = array(
		array(
			'blockclass' => array("wqphoto_photo"),
			'name' => $Tlang['11213791c39c402b'],
			'template' => '<div class="wq_photo_ranking">
                <h3 class="wqbig_title">' . $Tlang['616e8e58517dc308'] . '</h3>
                <ul>
                    [index=1]
                    <li>
                        <b class="wqnum1">{currentorder}</b>
                        <a href="{url}" {target}>{title}</a>
                    </li>
                    [/index]
                    [index=2]
                    <li>
                        <b class="wqnum2">{currentorder}</b>
                        <a href="{url}" {target}>{title}</a>
                    </li>
                    [/index]
                    [index=3]
                    <li>
                        <b class="wqnum3">{currentorder}</b>
                        <a href="{url}" {target}>{title}</a>
                    </li>
                    [/index]
                    [loop]
                    <li>
                        <b>{currentorder}</b>
                        <a href="{url}" {target}>{title}</a>
                    </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqphoto_photo"),
			'name' => $Tlang['c6c94e4e6dceb6a6'],
			'template' => '<div class="wq_photo_ranking2">
                <h3 class="wqbig_title">' . $Tlang['899b1022d820bd44'] . '</h3>
                <ul>
                    [loop]
                    <li>
                        <a href="{url}" {target}>
                            <div class="wq_img wqlazydiv"><img class="lazyload" data-src="{pic}" src="source/plugin/wq_photo/static/images/wq_dian.jpg"/></div>
                            <div class="wq_con">
                                <h3>{title}</h3>
                                <p><span class="wq_name">{author}</span><span class="y">{dateline}</span></p>
                            </div>
                        </a>
                    </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqphoto_photo"),
			'name' => $Tlang['b9b3ac107fcadfe8'],
			'template' => '<div class="wq_photo_more_wonderful">
                <h3>' . $Tlang['b04088f37992c87e'] . '</h3>
                <ul>
                    [loop]
                     <li class="wq_line">
                        <a href="{url}" {target}>
                            <div class="wq_title">{title}</div>
                            <div class="wq_img">{attachment}</div>
                              </a>
                            <div class="wq_info">
                                <a class="wq_head" target="_blank">
                                    <img alt="" src="{avatar}"/>
                                </a>
                                <a class="wq_name" href="javascript:;" target="_blank">{author}</a>
                                <a class="wq_comment" href="javascript:;" target="_blank">{replies}' . $Tlang['243cbee29176a641'] . '</a>
                                <span class="wq_time">{dateline}</span>
                            </div>
                    </li>
                    [/loop]
                </ul>
            </div>',
		),
		array(
			'blockclass' => array("wqphoto_photo"),
			'name' => $Tlang['7868933876981ffe'],
			'template' => '<div class="wqphoto_recommend">
                <div class="wq_imginfo_warp">
                    <a href="javascript:;" class="wq_prev"><img src="./source/plugin/wq_photo/static/images/wqphoto_prev.png"/></a>
                    <a href="javascript:;" class="wq_next"><img src="./source/plugin/wq_photo/static/images/wqphoto_next.png"/></a>
                    <ul>
                    [loop]
                        <li>
                            <a target="_blank"  href="{url}" {target} style="display: block;">
                                <div class="wq_img wqlazydiv"><img class="lazyload" data-src="{pic}" src="source/plugin/wq_photo/static/images/wq_dian.jpg"/></div>
                                <div class="wq_text">{title}</div>
                            </a>
                        </li>
                    [/loop]
                    </ul>
                </div>
                <div class="wq_switch_dot">
                </div>
            </div>',
		),
	);
}
//From: Dism_taobao-com
?>