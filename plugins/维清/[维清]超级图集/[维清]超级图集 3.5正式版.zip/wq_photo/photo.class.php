<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: addonindex.inc.php 2017-7-5 02:48:25Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class threadplugin_wq_photo {

	public $name;
	public $iconfile;
	public $buttontext;
	public $setting;
	public $plang;
	public $fid;

	public function __construct() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/config.php';
		$this->plang = wq_loadlang('wq_photo');
		$this->name = $this->plang['501d640c506bc6c4'];
		$this->iconfile = 'static/images/pictures.png';
		$this->buttontext = $this->plang['fb77085372414290'];
		$this->setting = $setting;
		$this->fid = wq_photo_get_photo_forumid();
	}

	public function newthread($fid) {
		global $_G;

		require_once libfile('function/upload');
		return $this->_photo_template($fid);
	}

	function newthread_submit($fid) {
		global $_G;
		$this->_post_check();
	}

	function newthread_submit_end($fid, $tid) {
		global $_G;

		$this->_newthread_post_check_end($fid, $tid);
	}

	function editpost($fid, $tid) {
		global $_G;
		return $this->_photo_template($fid, $tid);
	}

	function editpost_submit($fid, $tid) {
		global $_G;
		$this->_post_check();
	}

	function editpost_submit_end($fid, $tid) {
		global $_G;
		$this->_newthread_post_check_end($fid, $tid);
	}

	function newreply_submit_end($fid, $tid) {

	}

	function viewthread($tid) {
		global $_G, $postlist, $savepostposition, $rushreply, $ordertype, $threadsortshow, $skipaids, $mod, $allowpostreply, $fastpost, $seccodecheck, $seccodecheck, $page;
		$setting = $this->setting;
		$Plang = $this->plang;

		if(empty($_GET['authorid']) && empty($postlist)) {
			if($rushreply) {
				dheader("Location: forum.php?mod=redirect&tid=$_G[tid]&goto=lastpost");
			} else {
				$replies = C::t('forum_post')->count_visiblepost_by_tid($_G['tid']);
				$replies = intval($replies) - 1;
				if($_G['forum_thread']['replies'] != $replies && $replies > 0) {
					C::t('forum_thread')->update($_G['tid'], array('replies' => $replies), false, false, $archiveid);
					dheader("Location: forum.php?mod=redirect&tid=$_G[tid]&goto=lastpost");
				}
			}
		}

		if($_G['forum_pagebydesc'] && (!$savepostposition || $_GET['ordertype'] == 1)) {
			$postlist = array_reverse($postlist, TRUE);
		}

		if(!empty($_G['setting']['sessionclose'])) {
			$_G['setting']['vtonlinestatus'] = 1;
		}

		if($_G['setting']['vtonlinestatus'] == 2 && $_G['forum_onlineauthors']) {
			foreach(C::app()->session->fetch_all_by_uid(array_keys($_G['forum_onlineauthors'])) as $author) {
				if(!$author['invisible']) {
					$_G['forum_onlineauthors'][$author['uid']] = 1;
				}
			}
		} else {
			$_G['forum_onlineauthors'] = array();
		}
		$ratelogs = $comments = $commentcount = $totalcomment = array();
		if($_G['forum_cachepid']) {
			foreach(C::t('forum_postcache')->fetch_all($_G['forum_cachepid']) as $postcache) {
				if($postcache['rate']) {
					$postcache['rate'] = dunserialize($postcache['rate']);
					$postlist[$postcache['pid']]['ratelog'] = $postcache['rate']['ratelogs'];
					$postlist[$postcache['pid']]['ratelogextcredits'] = $postcache['rate']['extcredits'];
					$postlist[$postcache['pid']]['totalrate'] = $postcache['rate']['totalrate'];
				}
				if($postcache['comment']) {
					$postcache['comment'] = dunserialize($postcache['comment']);
					$commentcount[$postcache['pid']] = $postcache['comment']['count'];
					$comments[$postcache['pid']] = $postcache['comment']['data'];
					$totalcomment[$postcache['pid']] = $postcache['comment']['totalcomment'];
				}
				unset($_G['forum_cachepid'][$postcache['pid']]);
			}
			$postcache = $ratelogs = array();
			if($_G['forum_cachepid']) {
				list($ratelogs, $postlist, $postcache) = C::t('forum_ratelog')->fetch_postrate_by_pid($_G['forum_cachepid'], $postlist, $postcache, $_G['setting']['ratelogrecord']);
			}
			foreach($postlist as $key => $val) {
				if(!empty($val['ratelogextcredits'])) {
					ksort($postlist[$key]['ratelogextcredits']);
				}
			}

			if($_G['forum_cachepid'] && $_G['setting']['commentnumber']) {
				list($comments, $postcache, $commentcount, $totalcomment) = C::t('forum_postcomment')->fetch_postcomment_by_pid($_G['forum_cachepid'], $postcache, $commentcount, $totalcomment, $_G['setting']['commentnumber']);
			}

			foreach($postcache as $pid => $data) {
				C::t('forum_postcache')->insert(array('pid' => $pid, 'rate' => serialize($data['rate']), 'comment' => serialize($data['comment']), 'dateline' => TIMESTAMP), false, true);
			}
		}

		if($_G['forum_attachpids'] && !defined('IN_ARCHIVER')) {
			require_once libfile('function/attachment');
			if(is_array($threadsortshow) && !empty($threadsortshow['sortaids'])) {
				$skipaids = $threadsortshow['sortaids'];
			}
			parseattach($_G['forum_attachpids'], $_G['forum_attachtags'], $postlist, $skipaids);
		}

		if(empty($postlist)) {
			showmessage('post_not_found');
		} elseif(!defined('IN_MOBILE_API')) {
			foreach($postlist as $pid => $post) {
				$postlist[$pid]['message'] = preg_replace("/\[attach\]\d+\[\/attach\]/i", '', $postlist[$pid]['message']);
			}
		}

		if(defined('IN_ARCHIVER')) {
			include loadarchiver('forum/viewthread');
			exit();
		}

		$_G['forum_thread']['heatlevel'] = $_G['forum_thread']['recommendlevel'] = 0;
		if($_G['setting']['heatthread']['iconlevels']) {
			foreach($_G['setting']['heatthread']['iconlevels'] as $k => $i) {
				if($_G['forum_thread']['heats'] > $i) {
					$_G['forum_thread']['heatlevel'] = $k + 1;
					break;
				}
			}
		}

		if(!empty($_G['setting']['recommendthread']['status']) && $_G['forum_thread']['recommends']) {
			foreach($_G['setting']['recommendthread']['iconlevels'] as $k => $i) {
				if($_G['forum_thread']['recommends'] > $i) {
					$_G['forum_thread']['recommendlevel'] = $k + 1;
					break;
				}
			}
		}

		$allowblockrecommend = $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 5) || getstatus($_G['member']['allowadmincp'], 6);
		if($_G['setting']['portalstatus']) {
			$allowpostarticle = $_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3);
			$allowpusharticle = empty($_G['forum_thread']['special']) && empty($_G['forum_thread']['sortid']) && !$_G['forum_thread']['pushedaid'];
		} else {
			$allowpostarticle = $allowpusharticle = false;
		}
		if($_G['forum_thread']['displayorder'] != -4) {
			$modmenu = array(
				'thread' => $_G['forum']['ismoderator'] || $allowblockrecommend || $allowpusharticle && $allowpostarticle,
				'post' => $_G['forum']['ismoderator'] && ($_G['group']['allowwarnpost'] || $_G['group']['allowbanpost'] || $_G['group']['allowdelpost'] || $_G['group']['allowstickreply']) || $_G['forum_thread']['pushedaid'] && $allowpostarticle || $_G['forum_thread']['authorid'] == $_G['uid']
			);
		} else {
			$modmenu = array();
		}

		if($_G['forum']['alloweditpost'] && $_G['uid']) {
			$alloweditpost_status = getstatus($_G['setting']['alloweditpost'], $_G['forum_thread']['special'] + 1);
			if(!$alloweditpost_status) {
				$edittimelimit = $_G['group']['edittimelimit'] * 60;
			}
		}

		if($_G['forum_thread']['replies'] > $_G['forum_thread']['views']) {
			$_G['forum_thread']['views'] = $_G['forum_thread']['replies'];
		}

		$imageUrl = "source/plugin/wq_photo/static/images/";
		$photoinfo = C::t('#wq_photo#wq_photo_list_feed')->fetch_by_tid($tid);
		$attachments = $this->_get_photo_attachment($tid);

		C::t('#wq_photo#wq_photo_list_feed')->update($photoinfo['feedid'], array('views' => $_G['forum_thread']['views']));


		$wqhot = wq_photo_get_photo_listinfo($photoinfo['cid'], "", 0, 10, 'views', 'DESC', true);
		$wqfid = $this->fid;
		$myfav = C::t('home_favorite')->fetch_by_id_idtype($tid, "tid", $_G['uid']);
		$myadd = C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $tid);
		$nextoldset = wq_photo_get_last_thread_and_next_photo($fid);
		$nextnewset = wq_photo_get_last_thread_and_next_photo($fid, 'nextnewset');
		$searchurl = 'plugin.php?id=wq_photo&mod=search';
		$is_system_headbottom = $setting['is_system_headbottom'];
		$topnav = $setting['topnav'];
		$set_color = $setting['pc_color'];
		$mainnvid = $setting['mainnvid'];

		$photo_seo = dunserialize($_G['setting']['photo_seo']);
		$wq_photo_class = wq_photo_cache_all_class();
		$line = $cid ? $wq_photo_class[$photoinfo['cid']]['cname'] : $Plang['8dfe4b30674494c1'];
		$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $line, 'title' => $_G['forum_thread']['subject']);
		list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $photo_seo['view']);

		loadcache("plugin");
		$wq_login = $_G['cache']['plugin']['wq_login'];
		if($_G['mobile']) {
			if($_GET['photo'] == 'reply') {
				include_once template('wq_photo:photo_reply');
			} else {
				include_once template('wq_photo:photo_view');
			}
			exit;
		}

		$_G['mod'] = 'wq_photo';
		$_G['photo_viewthread'] = 'viewthread';
		$_G['basescript'] = 'plugin';
		include_once template('diy:photo_view', 0, 'source/plugin/wq_photo/template');
		$_G['mod'] = $mod;
		$_G['basescript'] = CURSCRIPT;
		exit();
	}

	private function _photo_template($fid, $tid = 0) {
		global $_G;

		$setting = $this->setting;
		$Plang = $this->plang;
		if($_GET['action'] == 'newthread') {
			$photofid = $this->fid;
			if($_GET['mod'] == 'post' && $_GET['action'] == 'newthread' && $_GET['specialextra'] == 'wq_photo' && $fid != $photofid) {
				header("Location: forum.php?mod=post&action=newthread&fid=$photofid&specialextra=wq_photo");
			}
		}

		$cid = 0;
		if($_GET['action'] == 'edit') {
			$photoinfo = C::t('#wq_photo#wq_photo_list_feed')->fetch_by_tid($tid);
			$attachments = $this->_get_photo_attachment($tid);
			$cid = $photoinfo['cid'];
		}

		loadcache(array('wq_photo_class'));
		$wq_photo_class = $_G['cache']['wq_photo_class'] ? $_G['cache']['wq_photo_class'] : wq_photo_cache_all_class();
		foreach($wq_photo_class as $key => $val) {
			$class[$val['cid']] = $val['cname'];
		}
		$sel_class = wq_photo_select_class_html($class, 'cid', $cid, 'wqcid', true);

		$maxsize = $setting['upload_maxsize'] * 1024;
		$hash = md5(substr(md5($_G['config']['security']['authkey']), 8) . $_G['uid']);
		if($_G['mobile']) {
			$wqhash = md5(substr(md5($_G['config']['security']['authkey']), 8) . $_G['uid']);
		}
		$unuset_attachment = C::t('#wq_photo#wq_photo_attachment')->fetch_all_unused_aid_by_uid($_G['uid']);
		$unsedimg = $unusedaids = array();
		foreach($unuset_attachment as $key => $val) {
			$unusedaids[] = $val['aid'];
		}
		if($unusedaids) {
			$unsedimg = C::t('#wq_photo#wq_photo_attachment_unused')->fetch_all_by_aids($unusedaids);
			if($unsedimg) {
				foreach($unsedimg as $key => $value) {
					$unsedimg[$key]['showattachment'] = wq_photo_get_image($value['attachment'], $value['thumb'], $value['remote']);
				}
			}
			$countunsedimg = count($unsedimg);
			$unusedtip = sprintf($Plang['fad450343fd0af0a'], $countunsedimg);
		}
		include template('wq_photo:post');

		return $return;
	}

	private function _get_photo_attachment($tid) {
		global $_G;

		$wq_rows = C::t('#wq_photo#wq_photo_attachment_n')->fetch_all_by_tableid($tid);
		foreach($wq_rows as $rkey => $rval) {
			$rval['attachment_url'] = wq_photo_get_image($rval['attachment'], $rval['thumb'], $rval['remote']);
			$rval['attachment_url_small'] = wq_photo_get_image($rval['attachment'], 1, 0, '.small.jpg');
			$rval['description'] = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array('&', '"', '<', '>'), trim($rval['description']));
			$attachments[$rkey] = $rval;
		}
		return $attachments;
	}

	private function _post_check() {
		global $_G;

		if($_GET['cid'] == "") {
			showmessage($this->plang['ade9a9f69dd9a952']);
		}

		if(empty($_GET['wqaid'])) {
			showmessage($this->plang['c99a721f44fffa63']);
		}

		if(empty($_GET['wqcover'])) {
			showmessage($this->plang['18036b418f3f611e']);
		}
	}

	private function _newthread_post_check_end($fid, $tid) {
		global $_G;

		$cid = intval($_GET['cid']);
		$aids = $_GET['wqaid'];
		$urls = $_GET['wqurl'];
		$msgs = $_GET['wqmsg'];
		$tableid = substr($tid, -1);
		$cover = intval($_GET['wqcover']);
		$imgnum = count($aids);

		$delaids = $_GET['delwqaid'] ? $_GET['delwqaid'] : array();
		if($_G['mobile']) {
			$delaids = trim($_GET['delwqaid']) ? explode(',', trim($_GET['delwqaid'])) : array();
		}

		if($delaids) {
			wq_photo_del_edit_image($delaids, $tid);
		}
		$attachment_unused = C::t('#wq_photo#wq_photo_attachment_unused')->fetch_all_by_aids($aids);
		$data = array('tid' => $tid, 'cid' => $cid);
		foreach($aids as $key => $aid) {
			$attachment = C::t('#wq_photo#wq_photo_attachment')->fetch_by_aid_uid($aid, $_G['uid']);
			if($attachment && $attachment['uid'] == $_G['uid']) {
				$data['tableid'] = $tableid;
				C::t("#wq_photo#wq_photo_attachment")->update($aid, $data);
			}
			if($_GET['displayorder'][$aid] !== null) {
				$displayorder = intval($_GET['displayorder'][$aid]);
			} else {
				$enddisplayorder = C::t('#wq_photo#wq_photo_attachment_n')->fetch_end_displayorder_by_tid($tid);
				$displayorder = intval($enddisplayorder['displayorder']) + 1;
			}
			if($attachment_unused[$aid]) {
				$newdata = $attachment_unused[$aid];
				$newdata['tid'] = $tid;
				$newdata['description'] = $msgs[$key];
				$newdata['displayorder'] = $displayorder;
				C::t('#wq_photo#wq_photo_attachment_n')->insert($tableid, $newdata);
				C::t('#wq_photo#wq_photo_attachment_unused')->delete($aid);
			} else {
				C::t('#wq_photo#wq_photo_attachment_n')->update($tid, array('description' => $msgs[$aid], 'displayorder' => $displayorder), array('aid' => $aid, 'tid' => $tid));
			}
		}

		$feedinfo = C::t('#wq_photo#wq_photo_list_feed')->fetch_by_tid($tid);

		if(!$feedinfo || $feedinfo['aid'] != $cover) {
			if($feedinfo) {
				wq_photo_pic_delete($feedinfo['cover'], 'wq_photo', 0, $feedinfo['remote']);
			}

			$coverinfo = C::t('#wq_photo#wq_photo_attachment_n')->fetch_by_tid_aid($tid, $cover);
			$imgurl = wq_photo_get_image($coverinfo['attachment'], 0, $coverinfo['remote']);
			$imgurl = wq_photo_imgurl_is_be_http($imgurl) ? $imgurl : DISCUZ_ROOT . './' . $imgurl;

			$data['attachment'] = 'cover/' . md5($tid) . '.jpg';
			$target = 'wq_photo/cover/' . md5($tid) . '.jpg';
			$data['remote'] = 0;
			include_once DISCUZ_ROOT . './source/plugin/wq_photo/class/class_image.php';
			$image = new wq_image();
			$image->Thumb($imgurl, $target, 640, 360);
			$data = wq_photo_upload_images_ftpremote_or_qiniu($data, 'wq_photo');
		}

		$data['uid'] = $_G['forum_thread']['authorid'] ? $_G['forum_thread']['authorid'] : $_G['uid'];
		$data['username'] = $_G['forum_thread']['author'] ? $_G['forum_thread']['author'] : $_G['username'];
		$data['imgnum'] = $imgnum;
		$data['aid'] = $cover;
		$data['cover'] = $data['attachment'];
		$data['dateline'] = TIMESTAMP;

		if($_GET['action'] == "edit") {
			$data['remote'] = $data['remote'] ? $data['remote'] : $feedinfo['remote'];
			$data['cover'] = $data['attachment'] ? $data['attachment'] : $feedinfo['cover'];
		}

		unset($data['tableid'], $data['attachment'], $data['thumb']);
		if($feedinfo) {
			C::t('#wq_photo#wq_photo_list_feed')->update($feedinfo['feedid'], $data);
		} else {
			C::t('#wq_photo#wq_photo_class')->update_incrcase($cid, array('threads' => 1));
			C::t('#wq_photo#wq_photo_list_feed')->insert($data);
		}
	}

}
//From: Dism_taobao-com
?>