<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_photo/class/base.class.php';

class plugin_wq_photo extends plugin_wq_photo_base {

	function global_header() {
		global $_G;
		$photojs = "";
		$wqforumfid = $_G['setting']['wqphotofollowforumid'];
		if(($_GET['id'] != 'wq_photo' && $_G['fid'] != $wqforumfid) || ($_G['fid'] == $wqforumfid && $_GET['mod'] == 'post' && in_array($_GET['action'], array('edit', 'newthread')))) {

			$photojs = <<<EOF
                <script src="./source/plugin/wq_photo/static/js/jquery-1.8.3.pc.js?{$_G[style][verhash]}" charset="gbk">
                </script><script src="./source/plugin/wq_photo/static/js/jquery.SuperSlide.2.1.1.source.js?{$_G[style][verhash]}"  charset="{$_G[charset]}"></script>
                <script src="./source/plugin/wq_photo/static/js/wq_utils.js?{$_G[style][verhash]}" charset="gbk"></script>
                <script src="./source/plugin/wq_photo/static/js/wq_photo_detail.js?{$_G[style][verhash]}" charset="gbk"></script>
EOF;
		}
		return $photojs;
	}

	function deletethread($params) {
		global $_G;
		$this->_deletethread($params);
	}

}

class plugin_wq_photo_forum extends plugin_wq_photo {

	function viewthread_output() {
		global $_G, $post, $postno, $modmenu, $thread, $allowpostreply, $needhiddenreply, $postlist;
		$this->_viewthread_output();
	}

}

class mobileplugin_wq_photo extends plugin_wq_photo_base {

	function common() {
		$_G['setting']['seccodedata']['rule']['post']['allow'] = false;
	}

	function deletethread($params) {
		global $_G;
		$this->_deletethread($params);
	}

}

class mobileplugin_wq_photo_forum extends mobileplugin_wq_photo {

	function viewthread_output() {
		global $_G, $post, $postno, $modmenu, $thread, $allowpostreply, $needhiddenreply, $postlist;
		$this->_viewthread_output();
	}

}
//From: Dism_taobao-com
?>