<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Config.php';
include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Processing/ImageUrlBuilder.php';


if(!defined('WQQINIU_FUNCTIONS_VERSION')) {
	define('WQQINIU_FUNCTIONS_VERSION', wqConfig::SDK_VER);

	function wqcrc32_file($file) {
		$hash = hash_file('crc32b', $file);
		$array = unpack('N', pack('H*', $hash));
		return sprintf('%u', $array[1]);
	}

	function wqcrc32_data($data) {
		$hash = hash('crc32b', $data);
		$array = unpack('N', pack('H*', $hash));
		return sprintf('%u', $array[1]);
	}

	function wqbase64_urlSafeEncode($data) {
		$find = array('+', '/');
		$replace = array('-', '_');
		return str_replace($find, $replace, base64_encode($data));
	}

	function wqbase64_urlSafeDecode($str) {
		$find = array('-', '_');
		$replace = array('+', '/');
		return base64_decode(str_replace($find, $replace, $str));
	}

	function json_decode_a($json, $assoc = false, $depth = 512) {
		static $jsonErrors = array(
			JSON_ERROR_DEPTH => 'JSON_ERROR_DEPTH - Maximum stack depth exceeded',
			JSON_ERROR_STATE_MISMATCH => 'JSON_ERROR_STATE_MISMATCH - Underflow or the modes mismatch',
			JSON_ERROR_CTRL_CHAR => 'JSON_ERROR_CTRL_CHAR - Unexpected control character found',
			JSON_ERROR_SYNTAX => 'JSON_ERROR_SYNTAX - Syntax error, malformed JSON',
			JSON_ERROR_UTF8 => 'JSON_ERROR_UTF8 - Malformed UTF-8 characters, possibly incorrectly encoded'
		);

		if(empty($json)) {
			return null;
		}
		$data = json_decode($json, $assoc);
		if(PHP_VERSION >= "5.3.0") {
			if(JSON_ERROR_NONE !== json_last_error()) {
				$last = json_last_error();
				throw new \InvalidArgumentException(
				'Unable to parse JSON data: '
				. (isset($jsonErrors[$last]) ? $jsonErrors[$last] : 'Unknown error')
				);
			}
		}
		return $data;
	}

	function wqentry($bucket, $key) {
		$en = $bucket;
		if(!empty($key)) {
			$en = $bucket . ':' . $key;
		}
		return wqbase64_urlSafeEncode($en);
	}

	function wqsetWithoutEmpty(&$array, $key, $value) {
		if(!empty($value)) {
			$array[$key] = $value;
		}
		return $array;
	}

	function wqthumbnail(
	$url, $mode, $width, $height, $format = null, $quality = null, $interlace = null, $ignoreError = 1
	) {
		static $imageUrlBuilder = null;
		if(is_null($imageUrlBuilder)) {
			$imageUrlBuilder = new wqImageUrlBuilder;
		}

		return call_user_func_array(array($imageUrlBuilder, 'wqthumbnail'), func_get_args());
	}

	function wqwaterImg(
	$url, $image, $dissolve = 100, $gravity = 'SouthEast', $dx = null, $dy = null, $watermarkScale = null
	) {
		static $imageUrlBuilder = null;
		if(is_null($imageUrlBuilder)) {
			$imageUrlBuilder = new wqImageUrlBuilder;
		}

		return call_user_func_array(array($imageUrlBuilder, 'wqwaterImg'), func_get_args());
	}

	function wqwaterText(
	$url, $text, $font = '&#40657;&#20307;', $fontSize = 0, $fontColor = null, $dissolve = 100, $gravity = 'SouthEast', $dx = null, $dy = null
	) {
		static $imageUrlBuilder = null;
		if(is_null($imageUrlBuilder)) {
			$imageUrlBuilder = new wqImageUrlBuilder;
		}

		return call_user_func_array(array($imageUrlBuilder, 'wqwaterText'), func_get_args());
	}

}
//From: Dism_taobao-com
?>