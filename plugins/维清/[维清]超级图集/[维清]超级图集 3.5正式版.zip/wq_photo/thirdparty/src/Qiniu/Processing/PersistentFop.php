<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Config.php';
include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Http/Error.php';
include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Http/Client.php';
include_once DISCUZ_ROOT . './source/plugin/wq_photo/thirdparty/src/Qiniu/Processing/Operation.php';


final class wqPersistentFop {

	private $auth;

	private $bucket;

	private $pipeline;

	private $notify_url;

	private $force;

	public function __construct($auth, $bucket, $pipeline = null, $notify_url = null, $force = false) {
		$this->auth = $auth;
		$this->bucket = $bucket;
		$this->pipeline = $pipeline;
		$this->notify_url = $notify_url;
		$this->force = $force;
	}

	public function execute($key, $fops) {
		if(is_array($fops)) {
			$fops = implode(';', $fops);
		}
		$params = array('bucket' => $this->bucket, 'key' => $key, 'fops' => $fops);
		wqsetWithoutEmpty($params, 'pipeline', $this->pipeline);
		wqsetWithoutEmpty($params, 'notifyURL', $this->notify_url);
		if($this->force) {
			$params['force'] = 1;
		}
		$data = http_build_query($params);
		$url = wqConfig::API_HOST . '/pfop/';
		$headers = $this->auth->authorization($url, $data, 'application/x-www-form-urlencoded');
		$headers['Content-Type'] = 'application/x-www-form-urlencoded';
		$response = wqClient::post($url, $data, $headers);
		if(!$response->ok()) {
			return array(null, new Wqerror($url, $response));
		}
		$r = $response->json();
		$id = $r['persistentId'];
		return array($id, null);
	}

	public static function status($id) {
		$url = wqConfig::API_HOST . "/status/get/prefop?id=$id";
		$response = wqClient::get($url);
		if(!$response->ok()) {
			return array(null, new Wqerror($url, $response));
		}
		return array($response->json(), null);
	}

}
//From: Dism_taobao-com
?>