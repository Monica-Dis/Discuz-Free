<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_photo_get_setting()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["wq_photo"];
	$_var_1["mobile_list_style"] = intval($_var_1["mobile_list_style"]);
	$_var_1["list_perpage"] = intval($_var_1["list_perpage"]);
	$_var_1["is_system_headbottom"] = intval($_var_1["is_system_headbottom"]);
	$_var_1["pc_style"] = trim($_var_1["pc_style"]);
	$_var_1["pc_color"] = trim($_var_1["pc_color"]);
	$_var_1["union_ad"] = trim($_var_1["union_ad"]);
	$_var_1["mobile_logoname"] = trim($_var_1["mobile_logoname"]);
	$_var_1["mobile_style"] = trim($_var_1["mobile_style"]);
	$_var_1["mobile_color"] = trim($_var_1["mobile_color"]);
	$_var_1["upload_maxsize"] = intval($_var_1["upload_maxsize"]);
	$_var_1["is_use_qiniu"] = intval($_var_1["is_use_qiniu"]);
	$_var_1["qiniu_ak"] = trim($_var_1["qiniu_ak"]);
	$_var_1["qiniu_sk"] = trim($_var_1["qiniu_sk"]);
	$_var_1["qiniu_bucket"] = trim($_var_1["qiniu_bucket"]);
	$_var_1["qiniu_domain"] = trim($_var_1["qiniu_domain"]);
	$_var_1["is_image_make_thumb"] = intval($_var_1["is_image_make_thumb"]);
	$_var_1["icon_thumb_minwidth"] = intval($_var_1["icon_thumb_minwidth"]);
	$_var_1["is_image_make_watermark"] = intval($_var_1["is_image_make_watermark"]);
	$_var_1["upload_maxsize"] = $_var_1["upload_maxsize"] < 1 ? 1 : $_var_1["upload_maxsize"];
	$_var_1["icon_thumb_minwidth"] = $_var_1["icon_thumb_minwidth"] ? $_var_1["icon_thumb_minwidth"] : 640;
	$_var_1["mobile_logoname"] = $_var_1["mobile_logoname"] ? $_var_1["mobile_logoname"] : "wq_logo.png";
	$_var_1["pc_style"] = trim($_var_1["pc_style"]) ? trim($_var_1["pc_style"]) : "#1aad16";
	$_var_1["mobile_style"] = trim($_var_1["mobile_style"]) ? trim($_var_1["mobile_style"]) : "#1aad16";
	$_var_1["pc_color"] = !empty($_var_1["pc_color"]) ? $_var_1["pc_color"] : $_var_1["pc_style"];
	$_var_1["mobile_color"] = !empty($_var_1["mobile_color"]) ? $_var_1["mobile_color"] : $_var_1["mobile_style"];
	return $_var_1;
}
function wq_photo_get_plang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_photo/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_photo/language");
	}
	include $_var_1;
	global $wp_photo_plang;
	return $wp_photo_plang;
}
function wq_photo_get_photo_forumid()
{
	global $_G;
	$_var_1 = wq_photo_get_plang();
	$_var_2 = intval($_G["setting"]["wqphotofollowforumid"]);
	if (!$_var_2 || !C::t("forum_forum")->fetch($_var_2)) {
		$_var_2 = 0;
	}
	if ($_var_2) {
		return $_var_2;
	}
	$_var_3 = C::t("forum_forum")->fetch_fid_by_name($_var_1["7239a4042dda8a48"]);
	if (!$_var_3) {
		$_var_3 = C::t("forum_forum")->insert(array("type" => "group", "name" => $_var_1["7239a4042dda8a48"], "status" => 0, "displayorder" => 999), true);
		C::t("forum_forumfield")->insert(array("fid" => $_var_3));
	}
	$_var_4 = array("fup" => $_var_3, "type" => "forum", "name" => $_var_1["15a57b3d07111832"], "status" => 1, "allowsmilies" => 1, "allowbbcode" => 1, "allowimgcode" => 1, "allowspecialonly" => 1);
	$_var_2 = C::t("forum_forum")->insert($_var_4, true);
	$_var_5 = serialize(array("wq_photo"));
	C::t("forum_forumfield")->insert(array("fid" => $_var_2, "threadplugin" => $_var_5));
	C::t("common_setting")->update("wqphotofollowforumid", $_var_2);
	if (!function_exists("updatecache")) {
		include libfile("function/cache");
	}
	updatecache(array("setting", "forums"));
	return $_var_2;
}
function wq_photo_get_all_class()
{
	return C::t("#wq_photo#wq_photo_class")->fetch_all_by_search();
}
function wq_photo_cache_all_class()
{
	require_once libfile("function/cache");
	$_var_0 = wq_photo_get_all_class();
	foreach ($_var_0 as $_var_1 => $_var_2) {
		$_var_3[$_var_2["cid"]] = $_var_2;
	}
	savecache("wq_photo_class", $_var_3);
	return $_var_3;
}
function wq_photo_admincp_get_select_class($_arg_0)
{
	global $_G;
	loadcache("wq_photo_class");
	$_var_2 = $_G["cache"]["wq_photo_class"];
	$_var_3 = "<select name=\"newcid\">";
	foreach ($_var_2 as $_var_4 => $_var_5) {
		if ($_var_5["status"] && $_var_5["cid"] != $_arg_0) {
			$_var_3 = $_var_3 . ("<option value=\"" . $_var_5["cid"] . "\">" . $_var_5["cname"] . "</option>");
		}
	}
	$_var_3 = $_var_3 . "</select>";
	return $_var_3;
}
function wq_photo_imgwater_default_value()
{
	$_var_0 = array("watermarkstatus" => 0, "watermarktype" => "gif", "watermarktrans" => 50, "watermarkquality" => 90, "watermarkminheight" => 0, "watermarkminwidth" => 0);
	return $_var_0;
}
function wq_photo_upload_images($_arg_0, $_arg_1 = false, $_arg_2 = '', $_arg_3 = '', $_arg_4 = 2, $_arg_5 = false, $_arg_6 = "wq_photo")
{
	global $_G;
	$_var_8 = wq_photo_get_setting();
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/class/upload.class.php";
	$_var_9 = new wq_discuz_upload();
	$_var_9->init($_arg_0, $_arg_6);
	$_var_10 = $_var_9->attach;
	if ($_var_10["size"] > $_arg_4 * 1024 * 1024) {
		return "-105";
	}
	if (!$_var_10["isimage"]) {
		return "-102";
	}
	$_var_9->save();
	if ($_var_9->errorcode < 0) {
		return $_var_9->errorcode;
	}
	$_var_11 = @getimagesize($_var_10["target"]);
	if ($_var_11 !== false) {
		$_var_10["width"] = $_var_11[0];
	}
	$_var_10 = wq_photo_images_isthumb_or_iswatermark($_var_10, $_arg_1, $_arg_2, $_arg_3, $_arg_5);
	$_var_10["remote"] = 0;
	if ($_var_12) {
		return $_var_10;
	}
	$_var_10 = wq_photo_upload_images_ftpremote_or_qiniu($_var_10, $_arg_6);
	return $_var_10;
}
function wq_photo_images_isthumb_or_iswatermark($_arg_0, $_arg_1 = 0, $_arg_2 = '', $_arg_3 = '', $_arg_4 = false)
{
	global $_G;
	$_var_6 = wq_photo_get_setting();
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/class/class_image.php";
	$_var_7 = new wq_image();
	if ($_var_6["is_image_make_watermark"]) {
		$_var_7->Watermark($_arg_0["target"]);
	}
	$_arg_0["thumb"] = 0;
	if ($_arg_1 && $_arg_0["width"] > $_arg_2) {
		$_arg_0["thumb"] = $_var_7->Thumb($_arg_0["target"], '', $_arg_2, $_arg_3, 2);
	}
	if ($_arg_4) {
		$_arg_0["small_attachment"] = "wq_photo/" . $_arg_0["attachment"] . ".small.jpg";
		$_var_7->Thumb($_arg_0["target"], $_arg_0["small_attachment"], 100, 75, 2);
	}
	return $_arg_0;
}
function wq_photo_upload_images_ftpremote_or_qiniu($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = wq_photo_get_setting();
	if ($_var_3 && $_var_3["is_use_qiniu"] == 1 && !empty($_var_3["qiniu_sk"]) && !empty($_var_3["qiniu_domain"]) && !empty($_var_3["qiniu_ak"]) && !empty($_var_3["qiniu_bucket"])) {
		$_var_4 = $_G["setting"]["attachdir"] . $_arg_1 . "/" . $_arg_0["attachment"];
		$_var_5 = $_arg_1 . "/" . $_arg_0["attachment"];
		$_var_6 = $_G["setting"]["attachdir"] . $_arg_1 . "/" . getimgthumbname($_arg_0["attachment"]);
		$_var_7 = $_arg_1 . "/" . getimgthumbname($_arg_0["attachment"]);
		if (wqQqApi_save_article_images_photo_qiniu($_var_4, $_var_5) && (!$_arg_0["thumb"] || wqQqApi_save_article_images_photo_qiniu($_var_6, $_var_7))) {
			$_arg_0["remote"] = 2;
			@unlink($_G["setting"]["attachdir"] . $_arg_1 . "/" . $_arg_0["attachment"]);
			@unlink($_G["setting"]["attachdir"] . $_arg_1 . "/" . getimgthumbname($_arg_0["attachment"]));
		}
	}
	if (getglobal("setting/ftp/on") && (!$_G["setting"]["ftp"]["allowedexts"] && !$_G["setting"]["ftp"]["disallowedexts"] || $_G["setting"]["ftp"]["allowedexts"] && in_array($_arg_0["ext"], $_G["setting"]["ftp"]["allowedexts"]) || $_G["setting"]["ftp"]["disallowedexts"] && !in_array($_arg_0["ext"], $_G["setting"]["ftp"]["disallowedexts"])) && (!$_G["setting"]["ftp"]["minsize"] || $_arg_0["size"] >= $_G["setting"]["ftp"]["minsize"] * 1024)) {
		if (ftpcmd("upload", $_arg_1 . "/" . $_arg_0["attachment"]) && (!$_arg_0["thumb"] || ftpcmd("upload", $_arg_1 . "/" . getimgthumbname($_arg_0["attachment"])))) {
			@unlink($_G["setting"]["attachdir"] . $_arg_1 . "/" . $_arg_0["attachment"]);
			@unlink($_G["setting"]["attachdir"] . $_arg_1 . "/" . getimgthumbname($_arg_0["attachment"]));
			$_arg_0["remote"] = 1;
		} else {
			if (getglobal("setting/ftp/mirror")) {
				@unlink($_arg_0["target"]);
				@unlink(getimgthumbname($_arg_0["target"]));
			}
		}
	}
	return $_arg_0;
}
function wqQqApi_save_article_images_photo_qiniu($_arg_0, $_arg_1)
{
	$_var_2 = wq_photo_get_setting();
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/thirdparty/src/Qiniu/functions.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/thirdparty/src/Qiniu/Auth.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/thirdparty/src/Qiniu/Zone.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/thirdparty/src/Qiniu/Storage/UploadManager.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_photo/thirdparty/src/Qiniu/Processing/ImageUrlBuilder.php";
	$_var_3 = $_var_2["qiniu_ak"];
	$_var_4 = $_var_2["qiniu_sk"];
	$_var_5 = new Auth($_var_3, $_var_4);
	$_var_6 = $_var_2["qiniu_bucket"];
	$_var_7 = $_var_5->uploadToken($_var_6);
	$_var_8 = fopen($_arg_0, "rb");
	if ($_var_8 === false) {
		return false;
	}
	$_var_9 = fstat($_var_8);
	$_var_10 = fread($_var_8, $_var_9["size"]);
	fclose($_var_8);
	if ($_var_10 === false) {
		return false;
	}
	$_var_11 = $_arg_0;
	$_var_12 = $_arg_1;
	$_var_13 = new UploadManager();
	list($_var_14, $_var_15) = $_var_13->putFile($_var_7, $_var_12, $_var_11);
	if ($_var_15 !== NULL) {
		return false;
	}
	return true;
}
function wq_photo_pic_delete($_arg_0, $_arg_1, $_arg_2 = 0, $_arg_3 = 0, $_arg_4 = false)
{
	global $_G;
	$_var_6 = wq_photo_get_setting();
	if ($_arg_4) {
		@unlink($_G["setting"]["attachdir"] . "/" . $_arg_1 . "/" . getimgthumbname($_arg_0, ".small.jpg"));
	}
	if ($_arg_3 == 1) {
		ftpcmd("delete", $_arg_1 . "/" . $_arg_0);
		if ($_arg_2) {
			ftpcmd("delete", $_arg_1 . "/" . getimgthumbname($_arg_0));
		}
		ftpcmd("close");
	} else {
		if ($_arg_3 == 2) {
			delete_photo_qiniu_images($_arg_1 . "/" . $_arg_0, $_var_6);
			if ($_arg_2) {
				delete_photo_qiniu_images($_arg_1 . "/" . getimgthumbname($_arg_0), $_var_6);
			}
		} else {
			@unlink($_G["setting"]["attachdir"] . "/" . $_arg_1 . "/" . $_arg_0);
			if ($_arg_2) {
				@unlink($_G["setting"]["attachdir"] . "/" . $_arg_1 . "/" . getimgthumbname($_arg_0));
			}
		}
	}
	return true;
}
function delete_photo_qiniu_images($_arg_0, $_arg_1)
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/functions.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Auth.php";
	include_once DISCUZ_ROOT . "./source/plugin/wq_wechatcollecting/thirdparty/src/Qiniu/Storage/BucketManager.php";
	$_var_2 = $_arg_1["qiniu_ak"];
	$_var_3 = $_arg_1["qiniu_sk"];
	$_var_4 = new Auth($_var_2, $_var_3);
	$_var_5 = new BucketManager($_var_4);
	$_var_6 = $_arg_1["qiniu_bucket"];
	$_var_7 = $_arg_0;
	$_var_8 = $_var_5->delete($_var_6, $_var_7);
}
function wq_photo_get_image($_arg_0, $_arg_1 = 0, $_arg_2 = 0, $_arg_3 = ".thumb.jpg")
{
	global $_G;
	$_var_5 = wq_photo_get_setting();
	if (empty($_arg_0)) {
		return '';
	}
	$_var_6 = $_arg_0;
	if ($_arg_1) {
		$_var_6 = getimgthumbname($_var_6, $_arg_3);
	}
	if ($_arg_2 == 1) {
		$_var_7 = $_G["setting"]["ftp"]["attachurl"] . "wq_photo/" . $_var_6;
	} else {
		if ($_arg_2 == 2) {
			$_var_7 = $_var_5["qiniu_domain"] . "/wq_photo/" . $_var_6;
		} else {
			$_var_7 = ($_G["setting"]["attachurl"] ? $_G["setting"]["attachurl"] . "wq_photo/" : "data/attachment/wq_photo/") . $_var_6;
		}
	}
	return $_var_7;
}
function wq_photo_imgurl_is_be_http($_arg_0)
{
	return in_array(strtolower(substr($_arg_0, 0, 6)), array("http:/", "https:", "ftp://"));
}
function wq_photo_select_class_html($_arg_0, $_arg_1, $_arg_2 = '', $_arg_3 = '', $_arg_4 = true)
{
	$_var_5 = wq_photo_get_plang();
	$_var_6 = "<select name = \"" . $_arg_1 . "\" id=\"" . $_arg_3 . "\"  width=\"108\" class=\"ps\">";
	if ($_arg_4) {
		$_var_6 = $_var_6 . ("<option value = \"\">" . $_var_5["d5a012fd18fff1d2"] . "</option>");
	}
	foreach ($_arg_0 as $_var_7 => $_var_8) {
		if ($_arg_2 == $_var_7) {
			$_var_9 = " selected = \"selected\"";
		} else {
			$_var_9 = '';
		}
		$_var_6 = $_var_6 . ("<option value = \"" . $_var_7 . "\" " . $_var_9 . ">" . $_var_8 . "</option>");
	}
	return $_var_6 = $_var_6 . "</select>";
}
function wq_photo_get_last_thread_and_next_photo($_arg_0, $_arg_1 = "nextoldset")
{
	global $_G;
	$_var_3 = $_G["thread"]["lastpost"];
	$_arg_0 = $_arg_0 ? $_arg_0 : $_G["fid"];
	$_var_4 = "<";
	$_var_5 = "DESC";
	if ($_arg_1 == "nextnewset") {
		$_var_4 = ">";
		$_var_5 = "ASC";
	}
	$_var_6 = DB::fetch_first("SELECT p.*,f.subject FROM %t p LEFT JOIN %t f ON p.tid=f.tid WHERE f.fid=%d AND f.displayorder>=0 AND f.closed=0 AND f.lastpost" . $_var_4 . "%d  ORDER BY " . DB::order("lastpost", $_var_5) . DB::limit(1), array("wq_photo_list_feed", "forum_thread ", $_arg_0, $_var_3));
	if (!$_var_6) {
		$_var_5 = "DESC";
		if ($_arg_1 == "nextnewset") {
			$_var_5 = "ASC";
		}
		$_var_6 = DB::fetch_first("SELECT p.*,f.subject FROM %t p LEFT JOIN %t f ON p.tid=f.tid WHERE f.fid=%d AND f.displayorder>=0 AND f.closed=0 ORDER BY " . DB::order("lastpost", $_var_5) . DB::limit(1), array("wq_photo_list_feed", "forum_thread ", $_arg_0, $_var_3));
	}
	if ($_var_6 && is_array($_var_6)) {
		$_var_6["cover"] = wq_photo_get_image($_var_6["cover"], 0, $_var_6["remote"]);
		$_var_6["subject"] = str_replace(array("&amp;", "&quot;", "&lt;", "&gt;"), array("&", "\"", "<", ">"), trim($_var_6["subject"]));
	}
	return $_var_6;
}
function wq_photo_format_date($_arg_0, $_arg_1 = "Y-m-d H:i")
{
	return date($_arg_1, $_arg_0);
}
function wq_photo_get_photo_listinfo($_arg_0, $_arg_1 = '', $_arg_2 = 0, $_arg_3 = 10, $_arg_4 = "dateline", $_arg_5 = "DESC", $_arg_6 = '')
{
	global $_G;
	$_var_8 = C::t("#wq_photo#wq_photo_list_feed")->fetch_all_by_search($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4, $_arg_5, $_arg_6);
	foreach ($_var_8 as $_var_9 => $_var_10) {
		$_var_10["allreplies"] = $_var_10["replies"] + $_var_10["comments"];
		if ($_G["mobile"]) {
			$_var_10["dateline"] = wq_photo_format_date($_var_10["dateline"]);
		} else {
			$_var_10["dateline"] = date("m/d H:i", $_var_10["dateline"]);
		}
		if (!empty($_arg_1)) {
			$_var_10["subject"] = str_replace($_arg_1, "<span style=\"color:#F00;font-weight:bold;\">" . $_arg_1 . "</span>", $_var_10["subject"]);
		}
		$_var_10["lastpost"] = date("m/d H:i", $_var_10["lastpost"]);
		$_var_10["wqcover"] = wq_photo_get_image($_var_10["wqcover"], 0, $_var_10["remote"]);
		$_var_10["views"] = $_var_10["replies"] > $_var_10["views"] ? $_var_10["replies"] : $_var_10["views"];
		$_var_11[$_var_10["tid"]] = $_var_10;
	}
	return $_var_11;
}
function wq_photo_create_template()
{
	include DISCUZ_ROOT . "./source/plugin/wq_photo/data/diy_style.php";
	$_var_0 = wq_photo_get_style();
	foreach ($_var_0 as $_var_1) {
		$_var_2 = $_var_1["blockclass"];
		$_var_3 = $_var_1["name"];
		if (is_array($_var_2)) {
			foreach ($_var_2 as $_var_4 => $_var_5) {
				$_var_6 = array("name" => $_var_3, "blockclass" => $_var_5);
				$_var_7 = $_var_1["template"];
				$_var_8 = DB::fetch_first("SELECT * FROM " . DB::table("common_block_style") . " WHERE name=%s AND blockclass=%s", array($_var_3, $_var_5));
				include_once libfile("function/block");
				block_parse_template($_var_7, $_var_6);
				if ($_var_8["styleid"]) {
					C::t("common_block_style")->update($_var_8["styleid"], $_var_6);
				} else {
					$_var_9 = C::t("common_block_style")->insert($_var_6, true);
				}
				require_once libfile("function/cache");
				updatecache("blockclass");
			}
		}
	}
}
function wq_photo_delete_photo($_arg_0)
{
	global $_G;
	$_var_2 = wq_photo_get_setting();
	foreach ($_arg_0 as $_var_3 => $_var_4) {
		$_var_5 = C::t("#wq_photo#wq_photo_list_feed")->fetch_by_tid($_var_4);
		wq_photo_pic_delete($_var_5["cover"], "wq_photo", 0, $_var_5["remote"]);
		C::t("#wq_photo#wq_photo_list_feed")->delete($_var_5["feedid"]);
		C::t("#wq_photo#wq_photo_attachment")->delete_by_tid($_var_4);
		$_var_6 = C::t("#wq_photo#wq_photo_attachment_n")->fetch_all_by_tableid($_var_4);
		foreach ($_var_6 as $_var_3 => $_var_7) {
			wq_photo_pic_delete($_var_7["attachment"], "wq_photo", $_var_7["thumb"], $_var_7["remote"], true);
		}
		C::t("#wq_photo#wq_photo_attachment_n")->delete_by_tid($_var_4);
	}
}
function wq_photo_del_edit_image($_arg_0, $_arg_1)
{
	$_arg_1 = intval($_arg_1);
	if (!is_array($_arg_0) || !$_arg_1) {
		return NULL;
	}
	$_var_2 = C::t("#wq_photo#wq_photo_list_feed")->fetch_by_tid($_arg_1);
	if (!$_var_2) {
		return NULL;
	}
	foreach ($_arg_0 as $_var_3) {
		if ($_var_3) {
			wq_photo_del_attachment_or_unused($_var_3);
			if ($_var_2["aid"] == $_var_3) {
				wq_photo_pic_delete($_var_2["cover"], "wq_photo", 0, $_var_2["remote"]);
			}
			$_var_4 = C::t("#wq_photo#wq_photo_attachment_n")->fetch_by_tid_aid($_arg_1, $_var_3);
			if ($_var_4) {
				wq_photo_pic_delete($_var_4["attachment"], "wq_photo", $_var_4["thumb"], $_var_4["remote"], true);
				C::t("#wq_photo#wq_photo_attachment_n")->delete_by_tid_aid($_arg_1, $_var_3);
			}
		}
	}
	return true;
}
function wq_photo_del_attachment_or_unused($_arg_0)
{
	if (!$_arg_0) {
		return NULL;
	}
	$_var_1 = C::t("#wq_photo#wq_photo_attachment_unused")->fetch_by_aid($_arg_0);
	if ($_var_1) {
		C::t("#wq_photo#wq_photo_attachment_unused")->delete($_arg_0);
		wq_photo_pic_delete($_var_1["attachment"], "wq_photo", $_var_1["thumb"], $_var_1["remote"], true);
	}
	C::t("#wq_photo#wq_photo_attachment")->delete($_arg_0);
	return true;
}
function wq_photo_get_nav_urlinfo($_arg_0)
{
	$_var_1 = "id=" . $_GET["id"];
	$_var_2 = '';
	if (strpos($_var_1, ":") !== false) {
		$_var_2 = explode(":", $_var_1);
		$_var_2 = $_var_2[0];
	}
	foreach ($_arg_0 as $_var_3 => $_var_4) {
		$_var_5 = NULL;
		$_var_5 = parse_url($_var_4[1]);
		$_var_5 = explode("&", $_var_5["query"]);
		if (in_array($_var_1, $_var_5) || $_var_2 && in_array($_var_2, $_var_5)) {
			$_arg_0[$_var_3]["ison"] = true;
			break;
		}
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}