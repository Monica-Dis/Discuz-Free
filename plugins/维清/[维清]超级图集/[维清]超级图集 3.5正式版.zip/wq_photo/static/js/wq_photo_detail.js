(function (global, $, _, doc) {
    'use strict';

    var wq_photo = function (options) {
        options = options || {};
        this.url = location.href;
        this.slides = {
            '.wq_photo_con_left': {
                titCell: '.wqsmallImg li',
                mainCell: '.wq-scrollimg',
                delayTime: 300,
                effect: 'fade',
                prevCell: '.wq_photo_img .wq-prev',
                nextCell: '.wq_photo_img .wq-next',
                trigger: 'click',
                pnLoop: false
            },
            '.wqphoto_page': {
                mainCell: 'ul',
                delayTime: 200,
                autoPage:true,
                vis: 4,
                effect: 'left',
                prevCell: '.wqphoto_prev',
                nextCell: '.wqphoto_next',
                pnLoop: false,
                scroll: 1
            },
            '.wqphoto_recommend': {
                titCell: '.wq_switch_dot',
                mainCell: 'ul',
                delayTime: 500,
                autoPage:true,
                vis: 5,
                effect: 'left',
                prevCell: '.wq_prev',
                nextCell: '.wq_next',
                pnLoop: false,
                titOnClassName: 'wqon',
                scroll: 5
            }
        };
        this.initializeElements();
        this.initialization();
    };

    wq_photo.Eles = {
        'photoArea': '.wq_photo_img',
        'shareList': '.wq_applet_share',
        'lastPage': '.wqrecommend_atlas_warp',
        'previewArea': '.wq_photo_con_warp',
        'prevPhoto': '.wq-prev',
        'nextPhoto': '.wq-next'
    };

    var tools = {

    };
    function a(t, e) {
        var i, n, o, a, r, h, d = s(function() {
            r = a = !1
        }, e);
        return function() {
            i = this, n = arguments;
            var s = function() {
                o = null, r && (h = t.apply(i, n)), d()
            };
            return o || (o = setTimeout(s, e)), a ? r = !0 : (a = !0, h = t.apply(i, n)), d(), h
        }
    }

    function s(t, e, i) {
        var n, o;
        return function() {
            var a = this,
                s = arguments,
                r = function() {
                        n = null, i || (o = t.apply(a, arguments))
                },
                h = i && !n;
            return clearTimeout(n), n = setTimeout(r, e), h && (o = t.apply(a, arguments)), o
        }
    }
    wq_photo.prototype = {
        constructor: wq_photo,

        initSwitchAround: function () {
            var photoArea = this.photoArea,
                position = function(t) {
                    var left = Math.round(t.pageX - photoArea.offset().left),
                        width = photoArea.width();
                    return width / 2 > left ? 'left' : left >= width - 25 ? 'default' : 'right';
                };
                var that = this;
            photoArea.on('mousemove', a(function(e) {
                var direct = position(e),
                    cursor = $(this).data('cursor');
                ('undefined' == typeof cursor || cursor != direct) && $(this).data('cursor', direct).removeClass('wqcursor_' + cursor).addClass('wqcursor_' + direct);
            }, 100));
            photoArea.find('.wq-scrollimg').on('click', function (e) {
                var direct = position(e),
                    cursor = $(this).data('cursor');
                if (direct == 'left') {
                    that.prevPhoto.click();
                } else if (direct == 'right') {
                    that._toNextPage();
                };
            });
        },

        initShare: function () {
            wq_utils.share({
                src: $('.wq-scrollimg img').eq(0).prop('src'),
                text: $('.wq_photo_con_right h3').text().trim(),
                desc: $('.wqphoto_text').text().trim(),
                url: window.location.href
            });
        },

        initSlide: function () {
            var that = this;

            for (var keys in this.slides) {
                if (this.slides.hasOwnProperty(keys)) {
                    $(keys).slide(this.slides[keys]);
                }
            }

            $('.wqimg_size').each(function (i) {
                wq_utils.resetPhotoWarpSize($(this));
            });


            doc.on('keydown', function (e) {
                if (e.keyCode == '37') {
                    that.prevPhoto.click();
                }
                if (e.keyCode == '39') {
                    that._toNextPage();
                }
            });

            $('.wqagain_preview').on('click', function () {
                that.lastPage.hide();
                that.previewArea.show();
                $('.wqphoto_page img:eq(0)').click();
            });
            $('.wq_picinfo_wrap').on('mouseenter', this.showTextOverflow).on('mouseleave', this.hideTextOverflow)
        },

        _toNextPage: function () {
            if (this.nextPhoto.hasClass('nextStop')) {
                this.previewArea.hide();
                this.lastPage.show();
            } else {
                this.nextPhoto.click();
            }
        },

        showTextOverflow: function (e) {
            var height = $(this).find('.wqpicinfo_text p').height();
            if (height > 40) $(e.target).find('.wqpicinfo_text').height(height);
        },
        hideTextOverflow: function (e) {
            $(e.target).find('.wqpicinfo_text').height(40);
        },
        initialization: function () {
            this.bindEvent(this.eventsMap);
        },
        initializeElements: function() {
            var eles = wq_photo.Eles;
            for (var name in eles) {
                if (eles.hasOwnProperty(name)) {
                    this[name] = $(eles[name]);
                }
            }
        },
        _scanEventsMap: function(maps, isOn) {
            var delegateEventSplitter = /^(\S+)\s*(.*)$/;
            var bind = isOn ? this._delegate : this._undelegate;
            for (var keys in maps) {
                if (maps.hasOwnProperty(keys)) {
                    var matchs = keys.match(delegateEventSplitter);
                    bind(matchs[1], matchs[2], this[maps[keys]]);
                }
            }
        },
        initializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps, true);
        },
        uninitializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps);
        },
        _delegate: function(name, selector, func) {
            doc.on(name, selector, func);
        },
        _undelegate: function(name, selector, func) {
            doc.off(name, selector, func);
        },
        bindEvent: function(maps) {
            if (this.photoArea.length) {
                this.initSwitchAround();
            }
            this.initSlide();
            wq_utils.initScrollLoad();
            if (this.shareList.length) this.initShare();
            this.initializeOrdinaryEvents(maps);
        },
        unbindEvent: function(maps) {
            this.uninitializeOrdinaryEvents(maps);
        }
    };

    $(function () {
        global.wq_photo = new wq_photo();
    });
})(this, this.wqjq, this._, this.wqjq(document));