(function (global, $, _, doc) {
    'use strict';

    var wq_utils = function (options) {
        options = options || {};
        this.url = location.href;
        this.setDelayLoad = true;
        this.initializeElements();
        this.initialization();
    };

    wq_utils.Eles = {
        'sharebd': '#sharebd'
    };

    wq_utils.prototype = {
        constructor: wq_utils,
        share: function (obj) {
            var sharebd = {
                bdPic: obj.src || '',
                bdText: obj.text || '',
                bdDesc: obj.desc || '',
                bdUrl: obj.url || window.location.href
            };
            var jspath = location.protocol == 'https:' ? 'js/bdshare.js?{VERHASH}' : 'http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5);
            global._bd_share_config = {
                common: sharebd,
                share: [{
                    'bdSize': 16
                }]
            };
            this.sharebd.prop('src', jspath);
        },
        initReadMore: function (sel, type) {
            var readMoreButton = $(sel);
            type = type || 'click';
            if (type == 'click') {
                readMoreButton.on('click', this._readMore);
                if (this.setDelayLoad) {
                    readMoreButton[0].delayLoad = this.delayLoad.bind(this);
                }
            } else if (type == 'scroll') {
                doc.on('scroll', this._readMore.bind(readMoreButton));
            }
        },
        _readMore: function () {
            var ele = $(this);
            var page = Number(ele.data('page')),
                perpage = ele.data('perpage'),
                count = ele.data('count');
            if (page * perpage < count) {
                var more = ele.children().eq(0),
                    loading = ele.children().eq(1);
                more.hide();
                loading.show();
                page++;
                $.get(ele.data('url'), {page: page}, function (res) {
                    $("#ajax_list").append(res);
                    more.show();
                    loading.hide();
                    ele.data('page', page);

                    if (page * perpage >= count) {
                        $('.wqphoto_more').html('�Ѽ���ȫ��').css('cursor', 'default');
                    }

                    if (ele[0].delayLoad) {
                        ele[0].delayLoad();
                    }
                });
            }
        },
        initScrollLoad: function () {
            doc.on('scroll', this.throttle(this.delayLoad.bind(this), 300));
            this.delayLoad();
        },
        delayLoad: function () {
            var document_top = doc.scrollTop();
            var that = this;
            $(".lazyload").each(function() {
                var img_top = $(this).offset().top;

                if (img_top >= document_top && img_top <= document_top + $(global).height()) {
                    $(this).removeClass("lazyload");
                        var lazydiv = $(this).parents('.wqlazydiv');

                        if (lazydiv.length) {
                            if (lazydiv.hasClass('wqlazywarp')) {
                                that.resetPhotoWrapSize(lazydiv);
                            } else {
                                that.resetPhotoSize(lazydiv);
                            }
                        }
                }
            });
        },
        resetPhotoSize: function (obj) {
            var img = new Image(), image = obj.find('img');
            obj.css('overflow', 'hidden');
            img.src = obj.find('img').attr('data-src');
            img.onload = function () {
                var img_width = img.width, img_height = img.height;
                if (img_width / obj.width() > img_height / obj.height()) {
                    image.height(obj.height());
                    image.width(obj.height() * img_width / img_height);
                    var marginLeft = (obj.width() - obj.find('img').width()) / 2;
                    image.css('margin-left', marginLeft);
                } else {
                    image.width(obj.width());
                    image.height(obj.width() * img_height / img_width);
                    var marginTop = (obj.height() - obj.find('img').height()) / 2;
                    image.css('margin-top', marginTop);
                }
                image.prop('src',image.attr('data-src'));
            };
        },
        resetPhotoWarpSize: function (obj) {
            var img = new Image(), parent = obj.parent();
            img.src = obj.find('img').attr('data-src');
            img.onload = function () {
                if (img.width / parent.width() > img.height / parent.height()) {
                    obj.width(parent.attr('data-w'));
                    obj.height(obj.width() * img.height / img.width);
                    var marginTop = (parent.attr('data-h') - obj.height()) / 2;
                    obj.css('margin-top', marginTop);
                } else {
                    obj.height(parent.attr('data-h'));
                    obj.width(obj.height() * img.width / img.height);
                    var marginLeft = (parent.attr('data-w') - obj.width()) / 2;
                    obj.css('margin-left', marginLeft);
                }
                obj.show();
            };
        },
        throttle: function (fun, delay) {
            var could = true;
            return function () {
                if (!could) return;
                setTimeout(function () {
                    fun();
                    could = true;
                }, delay);
                could = false;
            };
        },

        initialization: function () {
            this.bindEvent(this.eventsMap);
        },
        initializeElements: function() {
            var eles = wq_utils.Eles;
            for (var name in eles) {
                if (eles.hasOwnProperty(name)) {
                    this[name] = $(eles[name]);
                }
            }
        },
        _scanEventsMap: function(maps, isOn) {
            var delegateEventSplitter = /^(\S+)\s*(.*)$/;
            var bind = isOn ? this._delegate : this._undelegate;
            for (var keys in maps) {
                if (maps.hasOwnProperty(keys)) {
                    var matchs = keys.match(delegateEventSplitter);
                    bind(matchs[1], matchs[2], this[maps[keys]]);
                }
            }
        },
        initializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps, true);
        },
        uninitializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps);
        },
        _delegate: function(name, selector, func) {
            doc.on(name, selector, func);
        },
        _undelegate: function(name, selector, func) {
            doc.off(name, selector, func);
        },
        bindEvent: function(maps) {
            if ($('.wqphoto_more').length) this.initReadMore('.wqphoto_more');
            this.initializeOrdinaryEvents(maps);
        },
        unbindEvent: function(maps) {
            this.uninitializeOrdinaryEvents(maps);
        }
    };


    $(function () {
        global.wq_utils = new wq_utils();
    });
})(this, this.wqjq, this._, this.wqjq(document));