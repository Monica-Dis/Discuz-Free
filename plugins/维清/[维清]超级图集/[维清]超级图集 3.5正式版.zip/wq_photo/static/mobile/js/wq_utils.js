(function (global, $, _, doc) {
    'use strict';

    var wq_utils = function (options) {
        options = options || {};
        this.url = location.href;
        this.global = $(global);
        this.doc = doc[0];
        this.m_ua = navigator.appVersion;
        this.u = navigator.userAgent;
        this.hideClass = 'wq_hide';
        this.mbrowser = {
            m_ua: navigator.appVersion,
            u: navigator.userAgent,
            isUC: /UCBrowser/.test(this.m_ua),
            isBaiduBox: /baiduboxapp\//.test(this.m_ua),
            isBaiduBrowser: /baidubrowser\//.test(this.m_ua),
            isQQ: /QQ\//.test(this.m_ua),
            isQQBrowser: ! /QQ\//.test(this.m_ua) && /MQQBrowser/.test(this.m_ua)  && !/MicroMessenger/.test(this.m_ua),
            isWX: /MicroMessenger/.test(this.m_ua),
            isLieBao: /LieBaoFast/.test(this.m_ua),
            is2345: /Mb2345Browser/.test(this.m_ua),
            isSogou: /SogouMobileBrowser/.test(this.m_ua),
            isOpera: /OPR\//.test(this.u) && !/version/i.test(this.u),
            isOupeng: /OPR\//.test(this.u) && /version/i.test(this.u),
            isSafari: /applewebkit\/\d+(\.\d+)*\d*\s*\(KHTML,\s*like\s*Gecko\)\s*version\/\d+(\.\d+)*\.\d+\s*mobile\/\d+\w\d+\s*safari\/\d+(\.\d+)*\.\d+$/i.test(this.u),
            isChrome: /chrome\/\d+(\.\d+)*\s*mobile\s*safari\/\d+(\.\d+)*$/i.test(this.u),
            isFirefox: /firefox/i.test(this.u),
            isWXIos: /iPhone/.test(this.m_ua)
        };
        this.eventsMap = {
            'touchmove .wq-share-mask, .wq-share': 'preventDefault'
        };
        this.initializeElements();
        this.initialization();
    };

    wq_utils.Eles = {
        'shareButton': '.wqshare',
        'hide': '.wq-share-mask, .wqsharecancel, .wq-share',
        shareMask: '.wq-share-mask',
        UCshare: '.wq-ucshare',
        scrollmenu: '.wq-scrollmenu',
        tagList: '.wq-scrollmenu .tag_list',
        waterfallCon: '.wqwaterfall_warp',
        waterfall: '.wqwaterfall',
        newHide: '.new_hide'
    };
    var tools = {
        fixed: 'wq_warp_fixed',
        space: '.wq_tag_space',
        menuFixed: function (ele) {
            ele.addClass(this.fixed);
            ele.next(this.space).show();
        },
        menuUnFixed: function (ele) {
            ele.removeClass(this.fixed);
            ele.next(this.space).hide();
        },
        menuIsFixed: function (ele) {
            return ele.hasClass(this.fixed);
        },
        menuSticky: function (ele) {
            ele.addClass('wq_warp_sticky');
        }
    };
    wq_utils.prototype = {
        constructor: wq_utils,
        initShare: function () {
            if (this.mbrowser.isUC) {
                new nativeShare('nativeShare', {
                    url: this.url,
                    title:'',
                    desc:'',
                    img:'',
                    img_title:'',
                    from:''
                });
            }
            this.shareButton.on('click', this.share.bind(this));
            this.hide.on('click', this.shareHide.bind(this));
        },
        share: function () {
            if (this._checkBrowser(['isUC'])) {
                this._shareMaskShow(0.4);
                $('.wq-ucshare').slideToggle(200);
            } else if (this._checkBrowser(['isQQBrowser', 'is2345'])) {
                this._shareMaskShow(0.9);
                $('.wq-2345share').show();
            } else if (this._checkBrowser(['isBaiduBrowser', 'isLieBao'])) {
                this._shareMaskShow(0.9);
                $('.wq-baidushare').show();
            } else if (this._checkBrowser(['isBaiduBox', 'isSogou', 'isOupeng'])) {
                this._shareMaskShow(0.9);
                $('.wq-baiduBoxshare').show();
            } else if (this._checkBrowser(['isSafari'])) {
                this._shareMaskShow(0.9);
                $('.wqshare_iphone').show();
            } else if (this._checkBrowser(['isQQ', 'isWX', 'isChrome', 'isOpera', 'isFirefox'])) {
                this._shareMaskShow(0.9);
                $('.wq-qqshare').show();
            } else {
                alert('�����������������з���');
            }
        },
        _shareMaskShow: function(opa) {
            this.shareMask.css({ 'opacity': '' + opa}).show();
        },
        _checkBrowser: function (arr) {
            for (var i = 0, b = false; i < arr.length; i++) {
                if (this.mbrowser[arr[i]]) {
                    b = true;
                }
            }
            return b;
        },
        shareHide: function () {
            if (this.UCshare.length) this.UCshare.slideUp(200);
            this.shareMask.hide();
            $('.wq-share').hide();
        },
        initScrollMenu: function (pos, types) {
            if (!this.scrollmenu.length) return;
            var windowWidth = this.global.width(),
                tagWidth = 0,
                buttonWidth = $('.wq_arrow').length ? $('.wq_arrow')[0].clientWidth : 0,
                navWidth = windowWidth - buttonWidth;
            this.tagList.width(3000);
            tagWidth = this.tagList.children('ul').width() + 1;
            this.tagList.css({'overflow': 'hidden', 'width': tagWidth});
            $('.wq_roll').css('width', navWidth);

            if (tagWidth > navWidth) {
                this.scrollItem= new IScroll('.wq_roll', {click: true, bounce: true, scrollX: true, scrollY: false});
                if (types == 'tag') {
                    this.setScrolllocation();
                }
            }
            var that = this;
            if (pos) {
                this._setSticky();
            }
        },
        setScrolllocation: function () {
            var navWidth = $('.wq_roll').width(),
                tagWidth = this.tagList.width();
            var site = $('.wq_roll .wqon').offset().left + Math.abs(this.scrollItem.x);
            if (site > navWidth / 2) {
                var scrollLeft = site - (navWidth / 2), screenLeft = tagWidth - navWidth;
                var left = screenLeft < scrollLeft ? screenLeft : scrollLeft;
                this.scrollItem.scrollTo(-left, 0, 1500);
            }
        },
        _setSticky: function () {
            var menu = this.scrollmenu;
            if (menu.length) {
                if (this._isSupportSticky()) {
                    tools.menuSticky(menu);
                } else {
                    var offsetTop = menu.offset().top, that = this;
                    doc.on('scroll', function () {
                        if (that.global.scrollTop() > offsetTop && !tools.menuIsFixed(menu)) {
                            tools.menuFixed(menu);
                        } else if (that.global.scrollTop() <= offsetTop && tools.menuIsFixed(menu)) {
                            tools.menuUnFixed(menu);
                        }
                    });
                }
            }
        },
        _isSupportSticky: function() {
            for (var e = ["", "-webkit-", "-ms-", "-moz-", "-o-"], t = "", n = 0; n < e.length; n++) t += "position:" + e[n] + "sticky;";
            var a = doc[0].createElement("div")
              , i = doc[0].body;
            a.style.cssText = "display:none;" + t,
            i.appendChild(a);
            var r = /sticky/i.test(global.getComputedStyle(a).position);
            return i.removeChild(a),
            a = null ,
            r;
        },
        initScrollLoad: function () {
            doc.on('scroll', this.throttle(this.delayLoad.bind(this), 300));
            this.delayLoad();
        },
        delayLoad: function () {
            var document_top = doc.scrollTop();
            var that = this;
            $(".lazyload").each(function() {
                var img_top = $(this).offset().top;
                if (img_top >= document_top && img_top <= document_top + $(global).height()) {
                    $(this).removeClass("lazyload");
                        if ($(this).parents('.wqlazydiv').length) {
                            that.resetPhotoSize($(this).parents('.wqlazydiv'));
                        }
                }
            });
        },
        resetPhotoSize: function (obj) {
            var img = new Image(), image = obj.find('img');
            obj.css('overflow', 'hidden');
            img.src = image.attr('data-src');
            img.onload = function () {
                var img_width = img.width, img_height = img.height;
                if (img_width / obj.width() > img_height / obj.height()) {
                    image.height(obj.height());
                    image.width(obj.height() * img_width / img_height);
                    var marginLeft = (obj.width() - obj.find('img').width()) / 2;
                    image.css('margin-left', marginLeft);
                } else {
                    image.width(obj.width());
                    image.height(obj.width() * img_height / img_width);
                    var marginTop = (obj.height() - obj.find('img').height()) / 2;
                    image.css('margin-top', marginTop);
                }
                image.prop('src',image.attr('data-src'));
            };

        },
        initReadMore: function (sel, type) {
            var readMoreButton = $(sel);
            type = type || 'click';
            if (type == 'click') {
                readMoreButton.on('click', this._readMore);
            } else if (type == 'scroll') {
                global.loadSwitch = false;
                doc.on('scroll', this.throttle(this._readMore.bind(readMoreButton)));
            }
        },
        _readMore: function () {
            var ele = $(this);
            var page = Number(ele.data('page')),
                perpage = ele.data('perpage'),
                count = ele.data('count');
            if (page * perpage < count && doc.scrollTop() + $(global).height() > doc.height() - ele.height() * 2 && !global.loadSwitch) {
                var more = ele.children().eq(0),
                    loading = ele.children().eq(1);
                global.loadSwitch = true;
                more.hide();
                loading.show();
                page++;
                $.get(ele.data('url'), {page: page}, function (res) {
                    var waterfallCon = $('.wqwaterfall_warp'), waterfall = $('.wqwaterfall');
                    $("#ajax_list").append(res);
                    more.show();
                    loading.hide();
                    ele.data('page', page);
                    if (page * perpage >= count) more.html(more.data('complete'));
                    global.loadSwitch = false;
                    if (waterfallCon.length) {
                        waterfallCon.imagesLoaded(function(){
                            waterfall.masonry('reload');
                        });
                    }
                });
            }
        },
        setMasonry: function () {
            var waterfallCon = this.waterfallCon, waterfall = this.waterfall;
            waterfallCon.imagesLoaded(function(){
                waterfall.masonry({
                    itemSelector: '.wqwaterfall li'
                });
            });
        },
        initMenu: function (trigger, selector) {
            var self = this;
            doc.on('click', trigger, function () {
                self.openMenu($(this).parents(selector));
            });
        },
        openMenu: function (ele) {
            var hideClass = this.hideClass, hide = this.newHide, newMenu = ele.siblings('.new_menu');
            hide.css({"height": $(global).height() + 'px'}).removeClass(hideClass);
            newMenu.removeClass(hideClass);
            this.closeMenu(hide);
            this.closeMenu(newMenu);

        },
        closeMenu: function (ele) {
            var hideClass = this.hideClass, hide = this.newHide;
            ele.on('click', function () {
                hide.addClass(hideClass);
                $('.new_menu').addClass(hideClass);
                $(this).off();
            });
        },
        setcookie: function (cookieName, cookieValue, seconds) {
            if (cookieValue == '' || seconds < 0) {
                cookieValue = '';
                seconds = -2592000;
            }
            if (seconds) {
                var expires = new Date();
                expires.setTime(expires.getTime() + seconds * 1000);
            }
            this.doc.cookie = escape(cookieName) + '=' + escape(cookieValue) + (expires ? '; expires=' + expires.toGMTString() : '');
        },
        getcookie: function (name, nounescape) {
            var cookie_start = this.doc.cookie.indexOf(name);
            var cookie_end = this.doc.cookie.indexOf(";", cookie_start);

            if (cookie_start == -1) {
                return '';
            } else {
                var v = this.doc.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : this.doc.cookie.length));
                return !nounescape ? unescape(v) : v;
            }
        },
        preventDefault: function (e) {
            e.preventDefault();
        },
        throttle: function (fun, delay) {
            var could = true;
            return function () {
                if (!could) return;
                setTimeout(function () {
                    fun();
                    could = true;
                }, delay);
                could = false;
            };
        },

        initialization: function () {
            this.bindEvent(this.eventsMap);
        },
        initializeElements: function() {
            var eles = wq_utils.Eles;
            for (var name in eles) {
                if (eles.hasOwnProperty(name)) {
                    this[name] = $(eles[name]);
                }
            }
        },
        _scanEventsMap: function(maps, isOn) {
            var delegateEventSplitter = /^(\S+)\s*(.*)$/;
            var bind = isOn ? this._delegate : this._undelegate;
            for (var keys in maps) {
                if (maps.hasOwnProperty(keys)) {
                    var matchs = keys.match(delegateEventSplitter);
                    bind(matchs[1], matchs[2], this[maps[keys]]);
                }
            }
        },
        initializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps, true);
        },
        uninitializeOrdinaryEvents: function(maps) {
            this._scanEventsMap(maps);
        },
        _delegate: function(name, selector, func) {
            doc.on(name, selector, func);
        },
        _undelegate: function(name, selector, func) {
            doc.off(name, selector, func);
        },
        bindEvent: function(maps) {
            this.initShare();
            if ($('.wqphoto_more').length) this.initReadMore('.wqphoto_more', 'scroll');
            this.initializeOrdinaryEvents(maps);
        },
        unbindEvent: function(maps) {
            this.uninitializeOrdinaryEvents(maps);
        }
    };

    $(function () {
        global.wq_utils = new wq_utils();
    });
})(this, this.jQuery, this._, this.jQuery(document));