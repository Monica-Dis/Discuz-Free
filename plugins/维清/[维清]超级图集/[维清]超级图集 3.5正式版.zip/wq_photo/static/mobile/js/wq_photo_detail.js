(function (global, $, _, doc) {
    'use strict';

    var wq_photo = function (options) {
        options = options || {};
        this.url = location.href;
        this.promptName = 'wqphotoPrompt',
        this.promptInterval = 86400,
        this.slide = '.swiper-container',
        this.initializeElements();
        this.initialization();
    };

    wq_photo.Eles = {
        prompt: '.wqphoto_prompt_next',
        wqCon: '.wqphoto_view_con .wq_con',
        wqConSpan: '.wqphoto_view_con .wq_con span',
        headerText: '.wqphoto_header span',
        needToggle: '.wqheader_right, .wqphoto_view_text'
    };

    wq_photo.prototype = {
        constructor: wq_photo,
        initSlide: function () {
            var tr = 0, self = this;
            new Swiper (this.slide, {
                onTransitionStart: function (e) {
                    if (e.activeIndex == e.slides.length - 1) {
                        self.headerText.text('ͼ���Ƽ�');
                        self.needToggle.hide();
                        self._setLinkPrompt(1);
                    } else {
                        $('.wqphoto_view_con .wq_current').text(e.activeIndex + 1);
                        self.wqConSpan.text($('.wqslide_note').eq(e.activeIndex).text().trim());
                        self.headerText.text('ͼ��');
                        self.needToggle.show();
                        self.wqCon.css({
                            height: 0.8 * parseInt(doc[0].documentElement.style.fontSize) + "px"
                        });
                        if (self.wqCon.hasClass('open')) {
                            var topdelt = self.wqConSpan.height()
                            self.wqCon.css({
                                height: topdelt + "px",
                                "-webkit-transition-duration": "0ms"
                            });
                        }
                        self._setLinkPrompt(2);
                    }
                },
                onTouchStart: function (e) {
                    if (e.activeIndex == e.slides.length - 1) {
                        tr = e.translate;
                    } else {
                        tr = null;
                    }
                },
                onTouchEnd: function (e) {
                    if (tr !== null && tr > e.translate) {
                        setTimeout(function () {
                            global.location.href =$('.wqphoto_recommend_list').data('next');
                        }, 300);
                    }
                }
            });
            this._toggleOverflowText();
            this._toggleHeaderArea();
        },
        _toggleOverflowText: function () {
            var wqCon = this.wqCon, wqConSpan = this.wqConSpan, textContain = $(".wqphoto_view_text")[0];
            var fontsize = parseInt(doc[0].documentElement.style.fontSize),
                bottomdelt = fontsize * 0.8;

            this.fontsize = fontsize;
            this.bottomdelt = bottomdelt;
            wqCon.height(fontsize * 0.8);
            textContain.addEventListener("touchstart", function(t) {
                t.preventDefault();
                var e = t.touches ? t.touches[0] : t;
                this.y = e.pageY,
                this.dire = 0,
                this.variable =  wqCon.height(),
                this.fontsize = parseInt(doc[0].documentElement.style.fontSize),
                this.bottomdelt = 0.8 * this.fontsize,
                this.topdelt = wqConSpan.height() > this.bottomdelt ? wqConSpan.height() : this.bottomdelt,
                this.distY = 0;
            }),
            textContain.addEventListener("touchmove", function(t) {
                t.preventDefault();
                var e = t.touches ? t.touches[0] : t
                  , n = e.pageY - this.y;
                this.distY += n;
                var r = Math.abs(this.distY);
                if (r > 10) {
                    if (this.dire = n > 0 ? 1 : -1,
                    this.bottomdelt == this.topdelt)
                        return;
                    var i = wqCon.height();
                    if (i <= this.bottomdelt && 1 == this.dire)
                        return;
                    if (i >= this.topdelt && this.dire == -1)
                        return;
                    i = this.variable - n,
                    wqCon.css({
                        height: i + "px"
                    });
                }
            }),
            textContain.addEventListener("touchend", function(t) {
                var e = wqCon.height()
                  , n = Math.abs(e - this.bottomdelt)
                  , r = Math.abs(e - this.topdelt);
                1 == this.dire && wqCon.css({
                    height: this.bottomdelt + "px",
                    "-webkit-transition-duration": "600ms"
                }).removeClass('open'),
                this.dire == -1 && wqCon.css({
                    height: this.topdelt + "px",
                    "-webkit-transition-duration": "600ms"
                }).addClass('open');
            }),
            textContain.addEventListener("touchcancel", function(t) {
                var e = wqCon.height()
                  , n = Math.abs(e - this.bottomdelt)
                  , r = Math.abs(e - this.topdelt);
                1 == this.dire && wqCon.css({
                    height: this.bottomdelt + "px",
                    "-webkit-transition-duration": "600ms"
                }).removeClass('open'),
                this.dire == -1 && wqCon.css({
                    height: this.topdelt + "px",
                    "-webkit-transition-duration": "600ms"
                }).addClass('open');
            });
            wqCon[0].addEventListener("webkitTransitionEnd", function(e) {
                $(this).css({
                    "-webkit-transition-duration": "0ms"
                });
            });
        },

        _toggleHeaderArea: function () {
            $('.wqphoto_view_img').on('click', function () {
                $('body').toggleClass('active');
            });
        },

        _setLinkPrompt: function (type) {
            var prompt = this.prompt;
            if (type == 1) {
                if (!wq_utils.getcookie(this.promptName)) {
                    prompt.show();
                    wq_utils.setcookie(this.promptName, '1', this.promptInterval);
                    this.timeout = setTimeout(function () {
                        prompt.hide();
                    }, 4000);
                }
            } else if (type == 2) {
                if (prompt.is(':visible')) {
                    prompt.hide();
                    clearTimeout(this.timeout);
                }
            }
        },
        initMenu: function () {
            wq_utils.initMenu('.new_button', '.new_div');
        },

        initialization: function () {
            this.bindEvent();
        },
        initializeElements: function() {
            var eles = wq_photo.Eles;
            for (var name in eles) {
                if (eles.hasOwnProperty(name)) {
                    this[name] = $(eles[name]);
                }
            }
        },
        bindEvent: function() {
            this.initSlide();
            this.initMenu();
            wq_utils.initScrollLoad(true);
        }
    };

    $(function () {
        global.wq_photo = new wq_photo();
    });
})(this, this.jQuery, this._, this.jQuery(document));