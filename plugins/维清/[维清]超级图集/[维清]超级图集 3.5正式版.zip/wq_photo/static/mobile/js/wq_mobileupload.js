/**�ϴ�ͼƬ
 * @param {string} left   �ɹ��ص�����
 * @param {string} id  �ļ���id
 * @param {string} name  �ļ���name
 * @param {string} url  �ϴ���ַ
 * @returns {undefined}
 */
function wqpicture(uploadsuccess, id, name, url) {
    var uploadurl = url ? url : 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2';
    photoPopup.open(phototoast);
    if(typeof FileReader != 'undefined') {
        var wq_file = new Array();
        $.each(document.getElementById(id).files, function (i, n) {
            wq_file[0] = n;
            $.buildfileupload({
                uploadurl: uploadurl,
                files: wq_file,
                uploadformdata:{uid:wquid, hash: wqhash},
                uploadinputname: name,
                maxfilesize: maxfilesize,
                success: uploadsuccess,
                error: function () {
                    photoPopup.open('�ϴ�ʧ�ܣ����Ժ�����', 'alert');
                }
            });
        });
    } else {
        $.ajaxfileupload({
            url:uploadurl,
            data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
            dataType:'text',
            fileElementId:id,
            success:uploadsuccess,
            error: function() {
                photoPopup.open('�ϴ�ʧ�ܣ����Ժ�����', 'alert');
            }
        });

    }
}


function wqphotoupload_image(data) {
    if(data == '') {
        photoPopup.open('�ϴ�ʧ�ܣ����Ժ�����', 'alert');
    }
    var data = eval('('+data+')');
    if(parseInt(data.aid)>0 && data.url) {
        if(temaid){
            wqphoto_replace_img(temaid,data.aid,data.url,data.bigimg);
        }else{
            wqphoto_append_img_html(data);
        }
         photoPopup.open();
    } else {
        photoPopup.open(wqphotoerror[data.error], 'alert');
    }
};

function wqphoto_replace_img(replaceaid,newaid,imgurl,bigimg) {
    if(parseInt(replaceaid) < 0 || newaid < 0 || !imgurl || !bigimg){
        return;
    }
    $("#photoli_"+replaceaid).attr('id','photoli_'+newaid);
    var imgaidObj = {
        class: 'wqfile_button imgaid_'+newaid,
        'data-aid': newaid,
        src: imgurl
    }
    $(".imgaid_"+replaceaid).attr(imgaidObj);
    var valueaidObj = {
        class: 'wquploadaid valueaid_'+newaid,
        name: 'wqaid['+newaid+']',
        value: newaid
    }
    $(".valueaid_"+replaceaid).attr(valueaidObj);
    var wqurlaidObj = {
        class: 'wqurlaid_'+newaid,
        name: 'wqurl['+newaid+']',
        value: bigimg
    }
    $(".wqurlaid_"+replaceaid).attr(wqurlaidObj);
    if($(".displayorderaid_"+replaceaid).length>0){
        var displayorderaidObj = {
            class: 'displayorderaid_'+newaid,
            name: 'displayorder['+newaid+']'
        }
        $(".displayorderaid_"+replaceaid).attr(displayorderaidObj);
    }
    var wqcoveraidObj = {
        class: 'pc weui_check wqcoveraid_'+newaid,
        id: 'operations_'+newaid,
        value: newaid
    }
    $(".wqcoveraid_"+replaceaid).attr(wqcoveraidObj);
    var wqcoverlabelaidObj = {
        'for': 'operations_'+newaid,
        class: 'labeltxt weui_check_label wqcoverlabelaid_'+newaid
    }
    var textareaaidObj = {
        class: 'textareaaid_'+newaid,
        name: 'wqmsg['+newaid+']'
    }
    $(".textareaaid_"+replaceaid).attr(textareaaidObj);
    var delphotoaidObj = {
        class: 'wqdelphoto_btn delphoto delphotoaid_'+newaid,
        'data-aid': newaid
    };
    $(".delphotoaid_"+replaceaid).attr(delphotoaidObj);
    wqphoto_append_delaid(replaceaid);
    temaid = 0;
    return true;
}

function wqphoto_append_delaid(aid) {
    if(aid < 0 ){
        return false;
    }
    if($("#delwqaid").length>0){
        $("#delwqaid").val($("#delwqaid").val()+','+aid);
    }else{
        $('.wq_img_list ul').append('<input type="hidden" id="delwqaid" name="delwqaid" value="'+aid+'">');
    }
    return true;

}

function wqphoto_append_img_html(data) {
    if(!data || typeof(data) != 'object'){
        return '';
    }
    var imagecontent;
    imagecontent = '<li id="photoli_'+data.aid+'"><div class="wq_img"><img class="wqfile_button imgaid_'+data.aid+'" data-aid="'+data.aid+'" src="'+ data.url +'">';
    imagecontent += '<input type="hidden" class="wquploadaid valueaid_'+data.aid+'" name="wqaid['+data.aid+']" value="'+data.aid+'">'
    imagecontent += '<input type="hidden" class="wqurlaid_'+data.aid+'" name="wqurl['+data.aid+']" value="'+data.bigimg+'">';
    imagecontent += '<div class="wq_set_cover"><input type="radio" name="wqcover" class="pc weui_check wqcoveraid_'+data.aid+'" id="wq_cover_'+data.aid+'" value="'+data.aid+'">';
    imagecontent += '<label for="wq_cover_'+data.aid+'" class="labeltxt weui_check_label wqcoverlabelaid_'+data.aid+'"><i class="weui_icon_checked"></i>��Ϊ����</label>';
    imagecontent += '</div></div><div class="wq_text"><textarea class="textareaaid_'+data.aid+'" name="wqmsg['+data.aid+']" placeholder="����������" ></textarea></div>';
    imagecontent += '<div class="wqdelphoto_btn delphoto delphotoaid_'+data.aid+'" data-aid="'+data.aid+'" style="cursor: pointer;"><i class="wqphoto wqphoto-jianhao"></i></div></li>';
    $('.wq_img_list ul').append(imagecontent);
    if($("#wq_photounusedimg").length > 0){
        $("#wq_photounusedimg").attr("class","wqpost_no_picimg_list");
    }
    var wqcover = document.getElementsByName('wqcover');
    if(wqcover.length == 1){
        $('#wq_cover_'+data.aid).attr("checked",true);
    }
}

function wqphoto_del_once_img(delaid){
    if(delaid <1){
        return false;
    }
    $.get('plugin.php?id=wq_photo&mod=upload&ac=del&aid=' + delaid);
}

function wqphoto_update_unused_tps(updatenumid) {
    if(updatenumid){
        var num = parseInt($("#"+updatenumid).html());
        $("#"+updatenumid).html(num-1);
        if(num-1 < 1){
            $("#wq_photounusedimg").remove();
        }
    }
}