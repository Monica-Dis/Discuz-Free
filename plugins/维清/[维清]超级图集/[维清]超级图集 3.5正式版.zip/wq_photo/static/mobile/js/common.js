var POPMENU = new Object;
var phototoast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>'
var photoPopup = {
    init: function () {
        var $this = this;
        $('.popup').each(function (index, obj) {
            obj = $(obj);
            var pop = $(obj.attr('href'));
            if (pop && pop.attr('popup')) {
                pop.css({'display': 'none'});
                obj.on('click', function (e) {
                    $this.open(pop);
                });
            }
        });
        this.maskinit();
    },
    maskinit: function () {
        var $this = this;
        $('.guidemask').off().on('click', function () {
            $this.close();
        });
    },
    open: function (pop, type) {
        this.close();
        this.maskinit();
        if(typeof pop == 'string') {
            $('#ntcmsg').remove();
            if(type == 'alert') {
                pop = '<div class="tip"><dt>'+ pop +'</dt><dd><input class="button2" type="button" value="ȷ��" onclick="photoPopup.close();"></dd></div>'
            } else if(type == 'confirm') {
                pop = '<div class="tip"><dt>'+ pop +'</dt><dd><input class="redirect button2" type="button" value="ȷ��" href="'+ url +'"><a href="javascript:;" onclick="photoPopup.close();">ȡ��</a></dd></div>'
            }
            $('body').append('<div id="ntcmsg" style="display:none;">'+ pop +'</div>');
            pop = $('#ntcmsg');
        }
        if(POPMENU[pop.attr('id')]) {
            $('#' + pop.attr('id') + '_popmenu').html(pop.html()).css({'height':pop.height()+'px', 'width':pop.width()+'px'});
        } else {
            pop.parent().append('<div class="dialogbox" id="'+ pop.attr('id') +'_popmenu" style="height:'+ pop.height() +'px;width:'+ pop.width() +'px;">'+ pop.html() +'</div>');
        }
        var popupobj = $('#' + pop.attr('id') + '_popmenu');
        var left = (window.innerWidth - popupobj.width()) / 2;
        var top = (document.documentElement.clientHeight - popupobj.height()) / 2;
        popupobj.css({'display':'block','position':'fixed','left':left,'top':top,'z-index':120,'opacity':1});
        $('.photomask').css({'display':'block','width':'100%','height':'100%','position':'fixed','top':'0','left':'0','background':'black','opacity':'0.2','z-index':'100'});
        POPMENU[pop.attr('id')] = pop;
    },
    close: function () {
        $('.photomask').css('display', 'none');
        $.each(POPMENU, function (index, obj) {
            $('#' + index + '_popmenu').css('display','none');
        });
    }
};
$(function () {
    popup.init();
    $(document).on('click', '.wqdialog', function() {
        var obj = $(this);
        $.ajax({
            type: 'GET',
            url: obj.attr('href') + '&inajax=1',
            dataType: 'html'
        })
        .success(function(s) {
            if (s.indexOf('id="loginform"') == -1) {
                var wq = wqXml(s);
                var wq2 = wq_wechat_replace_js(wq);
                popup.open(wq2);
                evalscript(wq);
            } else {
                window.location.href = "member.php?mod=logging&action=login&mobile=2";
            }
        })
        .error(function() {
            window.location.href = obj.attr('href');
            popup.close();
        });
        return false;
    });

    $(document).on('click', '.wqformdialog', function () {
        var obj = $(this);
        var formobj = $(this.form);
        $.ajax({
            type: 'POST',
            url: formobj.attr('action') + '&handlekey=' + formobj.attr('id') + '&inajax=1',
            data: formobj.serialize(),
            dataType: 'html'
        }).success(function (s) {
            var wq = wqXml(s);
            popup.open(wq_wechat_replace_js(wq));
            evalscript(wq);
        }).error(function (s) {
            popup.close();
        });
        return false;
    });
});
function wq_wechat_replace_js(s) {
    if (s.indexOf('<script') == -1)
        return s;
    var p = /<script[^\>]*?>([^\x00]*?)<\/script>/ig;
    s = s.replace(p, '');
    return s;
}

function wqXml(str) {
    var start = str.indexOf('CDATA') + 6, end = str.indexOf(']]></root>');
    var wq = str.substring(start, end);
    return wq
}