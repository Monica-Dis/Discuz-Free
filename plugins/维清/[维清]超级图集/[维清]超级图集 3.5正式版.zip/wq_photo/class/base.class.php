<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-6-26 09:52:12Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_photo_base {

	public $lang;
	public $setting;

	function plugin_wq_photo_base() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_photo/config/loadfunc.php';

		$this->lang = wq_loadlang('wq_photo');

		$this->setting = wq_loadsetting('wq_photo');
	}

	function _viewthread_output() {
		global $_G, $post, $postno, $modmenu, $thread, $allowpostreply, $needhiddenreply, $postlist;
		include_once DISCUZ_ROOT . './source/plugin/wq_photo/function/function_photo.php';
		$photo_fid = intval($_G['setting']['wqphotofollowforumid']);

		if(CURSCRIPT == 'forum' && $_GET['mod'] == 'viewthread' && $_G['fid'] == $photo_fid) {
			if(!empty($_GET['tid']) && !empty($_GET['viewpid']) && !empty($_GET['inajax'])) {
				include template('wq_photo:photo_view_node');
				include template('common/footer_ajax');
				exit();
			}

			if(!empty($_GET['tid']) && $_GET['ajax'] == 'yes') {

				foreach($postlist as $key => $post) {
					if($post['first']) {
						continue;
					}
					include template('wq_photo:photo_view_node');
				}
				exit();
			}
		}
	}

	function _deletethread($params) {
		global $_G;
		$tids = $params['param'][0];
		$step = $params['step'];
		if($step == 'delete' && is_array($tids) && $_G['fid'] == $_G['setting']['wqphotofollowforumid']) {
			include_once DISCUZ_ROOT . './source/plugin/wq_photo/function/function_photo.php';
			wq_photo_delete_photo($tids);
			showmessage($this->lang[' $this->lang'], 'plugin.php?id=wq_photo&mod=list');
		}
	}

}
//From: Dism_taobao-com
?>