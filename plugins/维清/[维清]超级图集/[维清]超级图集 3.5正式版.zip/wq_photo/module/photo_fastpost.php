<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: smslogin_login.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once libfile('function/post');

if(!$_G['uid']) {
	showmessage('replyperm_login_nopermission', NULL, array(), array('login' => 1));
}

$tid = intval($_GET['tid']);
$fid = intval($_GET['fid']);
$postinfo = array('subject' => '');
$thread = array('readperm' => '', 'pricedisplay' => '', 'hiddenreplies' => '');
$thread = C::t('forum_thread')->fetch($tid);

if(!$_G['forum_auditstatuson'] && !($thread['displayorder'] >= 0 || (in_array($thread['displayorder'], array(-4, -2)) && $thread['authorid'] == $_G['uid']))) {
	$thread = array();
}
if(!empty($thread)) {

	if($thread['readperm'] && $thread['readperm'] > $_G['group']['readaccess'] && !$_G['forum']['ismoderator'] && $thread['authorid'] != $_G['uid']) {
		showmessage('thread_nopermission', NULL, array('readperm' => $thread['readperm']), array('login' => 1));
	}

	$_G['fid'] = $thread['fid'];
	$special = $thread['special'];
} else {
	showmessage('thread_nonexistence');
}

if($thread['closed'] == 1 && !$_G['forum']['ismoderator']) {
	showmessage('post_thread_closed');
}


$isfirstpost = 0;
$_G['group']['allowimgcontent'] = 0;
$showthreadsorts = 0;
$quotemessage = '';

if($special == 127) {
	$postinfo = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['tid']);
	$sppos = strrpos($postinfo['message'], chr(0) . chr(0) . chr(0));
	$specialextra = substr($postinfo['message'], $sppos + 3);
}

$language = lang('forum/misc');
$noticeauthor = $noticetrimstr = '';
if(isset($_GET['repquote']) && $_GET['repquote'] = intval($_GET['repquote'])) {
	$thaquote = C::t('forum_post')->fetch('tid:' . $tid, $_GET['repquote']);
	if(!($thaquote && ($thaquote['invisible'] == 0 || $thaquote['authorid'] == $_G['uid'] && $thaquote['invisible'] == -2))) {
		$thaquote = array();
	}
	if($thaquote['tid'] != $tid) {
		showmessage('reply_quotepost_error', NULL);
	}

	if(getstatus($thread['status'], 2) && $thaquote['authorid'] != $_G['uid'] && $_G['uid'] != $thread['authorid'] && $thaquote['first'] != 1 && !$_G['forum']['ismoderator']) {
		showmessage('reply_quotepost_error', NULL);
	}

	if(!($thread['price'] && !$thread['special'] && $thaquote['first'])) {
		$quotefid = $thaquote['fid'];
		$message = $thaquote['message'];

		if(strpos($message, '[/password]') !== FALSE) {
			$message = '';
		}

		if($_G['setting']['bannedmessages'] && $thaquote['authorid']) {
			$author = getuserbyuid($thaquote['authorid']);
			if(!$author['groupid'] || $author['groupid'] == 4 || $author['groupid'] == 5) {
				$message = $language['post_banned'];
			} elseif($thaquote['status'] & 1) {
				$message = $language['post_single_banned'];
			}
		}

		$time = dgmdate($thaquote['dateline']);
		$message = messagecutstr($message, 100);
		$message = implode("\n", array_slice(explode("\n", $message), 0, 3));

		$thaquote['useip'] = substr($thaquote['useip'], 0, strrpos($thaquote['useip'], '.')) . '.x';
		if($thaquote['author'] && $thaquote['anonymous']) {
			$thaquote['author'] = lang('forum/misc', 'anonymoususer');
		} elseif(!$thaquote['author']) {
			$thaquote['author'] = lang('forum/misc', 'guestuser') . ' ' . $thaquote['useip'];
		} else {
			$thaquote['author'] = $thaquote['author'];
		}

		$post_reply_quote = lang('forum/misc', 'post_reply_quote', array('author' => $thaquote['author'], 'time' => $time));
		$noticeauthormsg = dhtmlspecialchars($message);
		if(!defined('IN_MOBILE')) {
			$message = "[quote][size=2][url=forum.php?mod=redirect&goto=findpost&pid=$_GET[repquote]&ptid={$_G['tid']}][color=#999999]{$post_reply_quote}[/color][/url][/size]\n{$message}[/quote]";
		} else {
			$message = "[quote][color=#999999]{$post_reply_quote}[/color]\n[color=#999999]{$message}[/color][/quote]";
		}

		$quotemessage = discuzcode($message, 0, 0);
		$noticeauthor = dhtmlspecialchars(authcode('q|' . $thaquote['authorid'], 'ENCODE'));
		$noticetrimstr = dhtmlspecialchars($message);
		$message = '';
	}
	$reppid = $_GET['repquote'];
}

include template('wq_photo:photo_fastpost');

?>