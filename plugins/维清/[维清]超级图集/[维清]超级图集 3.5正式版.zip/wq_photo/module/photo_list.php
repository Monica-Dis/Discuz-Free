<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: smslogin_login.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/forum');

$cid = $_GET['cid'] ? intval($_GET['cid']) : 0;
$page = max(1, $_GET['page']);
$perpage = $setting['list_perpage'] ? $setting['list_perpage'] : 10;
$start = ($page - 1 ) * $perpage;

$displayorder = $_GET['displayorder'] == 'lastpost' ? 'dateline' : ($_GET['displayorder'] == 'hot' ? 'views' : 'dateline');
$orderby = in_array($_GET['orderby'], array('ASC', 'DESC')) ? dhtmlspecialchars($_GET['orderby']) : 'DESC';
$fid = wq_photo_get_photo_forumid();

$feedcount = C::t("#wq_photo#wq_photo_list_feed")->count_by_search($cid);
$lists = wq_photo_get_photo_listinfo($cid, "", $start, $perpage, $displayorder, $orderby);

$line = $cid ? $wq_photo_class[$cid]['cname'] : $Plang['8dfe4b30674494c1'];
$seodata = array('pluginname' => $setting['pluginname'], 'bbname' => $_G['setting']['bbname'], 'classname' => $line);
list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $photo_seo['list']);

if($_GET['ajax'] == "yes") {
	include template('wq_photo:common/list');
} else {
	if($_G['mobile']) {
		include template('wq_photo:photo_list');
	} else {
		include template('diy:photo_list', 0, 'source/plugin/wq_photo/template');
	}
}
//From: Dism_taobao-com
?>