<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: smslogin_login.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = in_array($_GET['ac'], array('del')) ? $_GET['ac'] : "upload";
if($ac == 'upload') {
	if(empty($_G['uid']) || $_POST['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8) . $_G['uid'])) {
		echo "{\"error\":\"-106\",\"aid\":\"0\", \"url\":\"0\", \"bigimg\":\"0\"}";
		exit();
	}

	$keyname = empty($_G['mobile']) || $_G['mobile'] == 'unknown' ? 'Filedata' : 'wqphototfiledata';
	$upimg = array(
		'name' => addslashes(diconv(urldecode($_FILES[$keyname]['name']), 'UTF-8')),
		'type' => $_FILES[$keyname]['type'],
		'tmp_name' => $_FILES[$keyname]['tmp_name'],
		'error' => $_FILES[$keyname]['error'],
		'size' => $_FILES[$keyname]['size'],
	);
	$maxsize = $setting['upload_maxsize'];
	$isthumb = $setting['is_image_make_thumb'];
	$thumbimgwidth = $setting['icon_thumb_minwidth'];
	$thumbimgheight = 99999;

	$attach = wq_photo_upload_images($upimg, $isthumb, $thumbimgwidth, $thumbimgheight, $maxsize, true);

	if(empty($attach) || !is_array($attach)) {
		echo "{\"error\":\"$attach\",\"aid\":\"0\", \"url\":\"0\", \"bigimg\":\"0\"}";
		exit;
	}

	$userinfo = getuserbyuid($_G['uid']);

	$aid = C::t("#wq_photo#wq_photo_attachment")->insert(array('tid' => 0, 'cid' => 0, 'uid' => $_G['uid'], 'username' => $userinfo['username'], 'tableid' => 0), true);

	$insert = array(
		'aid' => $aid,
		'filename' => dhtmlspecialchars(censor($attach['name'])),
		'filesize' => $attach['size'],
		'attachment' => $attach['attachment'],
		'thumb' => $attach['thumb'],
		'remote' => $attach['remote'],
		'width' => $attach['width'],
		'dateline' => TIMESTAMP,
	);
	C::t("#wq_photo#wq_photo_attachment_unused")->insert($insert);

	$basedir = wq_photo_get_image($attach['attachment'], $attach['thumb'], $attach['remote']);
	echo "{\"error\":\"$attach[errorcode]\",\"aid\":\"$aid\", \"url\":\"$basedir\", \"bigimg\":\"$attach[attachment]\"}";
	exit;
}

if($ac == 'del') {
	$aids = rtrim($_GET['aid'], '|');
	$aids = explode('|', $aids);
	foreach($aids as $key => $aid) {
		$aid = intval($aid);
		wq_photo_del_attachment_or_unused($aid);
	}
}
//From: Dism_taobao-com
?>