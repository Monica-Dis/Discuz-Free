var toast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>';

$(function(){
    $(document).on('click', '.qqformdialog', function() {
            popup.open(toast);
            var obj = $(this);
            var formobj = $(this.form);
            $.ajax({
                    type:'POST',
                    url:formobj.attr('action') +'&inajax=1',
                    data:formobj.serialize(),
                    dataType:'html'
            }).success(function(s) {
                    qq_ajax_show_message(s);
            }).error(function() {
                    window.location.href = formobj.attr('action');
                    popup.close();
            });
            return false;
    });

    $(document).on('click', '.qqdialog', function() {
            popup.open(toast);
            var obj = $(this);
            var url = obj.attr('href');
            $.ajax({
                    type:'GET',
                    url:url + '&handlekey='+ obj.attr('id') +'&inajax=1',
                    dataType:'html'
            }).success(function(s) {
                    var str = wqXml(s);
                    popup.open(str);
                    evalscript(str);
            }).error(function() {
                    window.location.href = url;
                    popup.close();
            });
            return false;
    });

});