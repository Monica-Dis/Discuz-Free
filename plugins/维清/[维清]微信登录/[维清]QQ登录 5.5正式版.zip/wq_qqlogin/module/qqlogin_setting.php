<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loaducenter();

$user = C::t('#wq_qqlogin#wq_qqlogin_member')->fetch_first_by_uid($_G['uid']);

if($_GET['ac'] == 'username') {
	if($user['chgusername']) {
		wq_showmessage($Plang['e7f7423a8825b50f']);
	}

	if($_G['uid'] && submitcheck('confirmsubmit')) {
		$newusername = addslashes(dhtmlspecialchars(trim($_GET['newusername'])));

		if(empty($newusername)) {
			wq_showmessage($Plang['be91a21ec09cb236']);
		}

		if(strlen($newusername) < 3 || strlen($newusername) > 15) {
			wq_showmessage($Plang['4618efae97fc33f9']);
		}

		$check = uc_user_checkname($newusername);
		if($check != 1) {
			$code = str_replace("-", "", $check);
			wq_showmessage($Plang['username_' . $code]);
		}

		wq_qqlogin_changeusername($_G['username'], $newusername);
		wq_qqlogin_changename_for_uc($_G['username'], $newusername);

		$re = C::t('#wq_qqlogin#wq_qqlogin_member')->update_by_uid($_G['uid'], $newusername);

		wq_showmessage($Plang['78b1255b087df664'], defined('IN_MOBILE') ? 'plugin.php?id=wq_qqlogin&mod=qqset' : dreferer());
	}
} elseif($_GET['ac'] == 'password') {
	if($user['chgpassword']) {
		wq_showmessage($Plang['0b00660886376523']);
	}
	if($_G['uid'] && submitcheck('confirmsubmit')) {
		if(!$_GET['newpassword']) {
			wq_showmessage($Plang['7cdd702917562488']);
		}

		if(strlen($_GET['newpassword']) < $setting['pwd_strlen']) {
			wq_showmessage(sprintf($Plang['b36dcdeaac6b00a5'], $setting['pwd_strlen']));
		}
		if(!$setting['pwd_is_numeric'] && is_numeric($_GET['newpassword'])) {
			wq_showmessage($Plang['a9e19d6d6b587830']);
		}
		if(!$setting['pwd_is_english'] && preg_match("/[a-z]+/i", $_GET['newpassword']) && !preg_match("/[0-9]+/i", $_GET['newpassword'])) {
			wq_showmessage($Plang['b9b81451d3a70378']);
		}

		if($_GET['newpassword'] != $_GET['confirmpassword']) {
			wq_showmessage($Plang['5a04f36409b58f7a']);
		}

		$re = wq_qqlogin_changepassword($_GET['newpassword']);

		wq_showmessage($Plang['668259cd833b1be4'], defined('IN_MOBILE') ? 'plugin.php?id=wq_qqlogin&mod=qqset' : dreferer());
	}
}
include_once template('wq_qqlogin:qqlogin_setting');

?>