<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$dreferer = dreferer();

if(!$_G['uid']) {
	wq_showmessage($Plang['69e41ab05666e96c'], null, array(), array('showmsg' => true, 'login' => 1));
}
$ac = !in_array($_GET['ac'], array('unbind', 'bind')) ? "" : $_GET['ac'];

if(submitcheck('confirmsubmit')) {
	$password = dhtmlspecialchars($_GET['password']);
	if(empty($password) && $setting['bind_is_write_password'] == 1) {
		wq_showmessage($Plang['bda5051be3094609']);
	}

	$extra = array(
		'showdialog' => true,
		'locationtime' => true,
	);

	if(!$setting['bind_is_write_password'] || wq_qqlogin_check_password($password)) {
		if($ac == 'unbind') {
			if(!$setting['is_open_unbind']) {
				wq_showmessage($Plang['f6e493f366c4bcb3'], $showurl, array(), $extra);
			}

			C::t("#wq_qqlogin#wq_qqlogin_member")->delete_by_uid($_G['uid']);
			$showurl = $_G['mobile'] ? 'home.php?mod=space&do=profile&mycenter=1' : $dreferer;
			wq_showmessage($Plang['16f7a468fd1793a9'], $showurl, array(), $extra);
		}
		if($ac == 'bind') {
			wq_showmessage($Plang['e1f071a5c0d2bac4'], "plugin.php?id=wq_qqlogin&mod=access&ac=bind&op=init", array(), array('location' => true));
		}
	} else {
		wq_showmessage($Plang['426845aac6e98fde']);
	}
} else {
	if($_G['mobile']) {
		$user = C::t("#wq_qqlogin#wq_qqlogin_member")->fetch_first_by_uid($_G['uid'], true);
		if(empty($user) && $ac == "") {
			showmessage($Plang['d63968fb4578bb01'], $dreferer);
		}
		if(!empty($user)) {
			$user['dateline'] = date("Y-m-d H:i:s", $user['dateline']);
			$user['gender'] = in_array($user['gender'], array('1', '2')) ? $Plang['gender_' . $user['gender']] : $Plang['gender_0'];
		}
	}

	include_once template("wq_qqlogin:qqlogin_qqset");
}
//dis'.'m.t'.'ao'.'bao.com
?>