<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$allowop = array('init', 'callback');
$op = $_GET['op'];

if(!in_array($op, $allowop)) {
	$op = 'init';
}

$referer = dreferer();

$callback_url = $setting['qq_domain'] . '?id=wq_qqlogin&mod=access&op=callback';

if($_GET['ac'] == 'bind') {
	$callback_url .= "&ac=bind";
}

if($_G['uid'] && $_GET['ac'] != 'bind') {
	dheader("Location:" . $referer);
}

try {
	$Oauth = new Oauth();
} catch (Exception $e) {
	wq_showmessage($Plang['ceda908c76212f9d'], $referer, array('Message' => $e->getmessage()));
}


if($op == 'init') {
	$callback = $callback_url . '&referer=' . (urldecode($referer) == $referer ? urlencode($referer) : $referer) . ($codeenc ? "&codeenc=" . $codeenc : "");
	$callback = $callback . "&siteurl=" . urlencode($_G['siteurl']);
	dsetcookie('wq_qqlogin_referer', $referer);
	dsetcookie('wq_qqlogin_request_uri', $callback);

	$redirect = $Oauth->getOAuthAuthorizeURL($callback);

	dheader('Location:' . $redirect);
} elseif($op == 'callback') {
	loaducenter();
	$params = $_GET;

	if($params['state'] != md5(FORMHASH)) {
		wq_showmessage("The state does not match. You may be a victim of CSRF", $_G['cookie']['wq_qqlogin_referer']);
	}

	try {
		$access_token = $Oauth->getAccessToken($_G['cookie']['wq_qqlogin_request_uri'], $params['code']);
	} catch (Exception $e) {
		wq_showmessage($Plang['8ee4c54774a89b08'], $_G['cookie']['wq_qqlogin_referer'], array('Message' => $e->getmessage()));
	}

	try {
		$openid = $Oauth->getOpenid($access_token);
	} catch (Exception $e) {
		wq_showmessage($Plang['8ee4c54774a89b08'], $_G['cookie']['wq_qqlogin_referer'], array('Message' => $e->getmessage()));
	}

	$user = C::t('#wq_qqlogin#wq_qqlogin_member')->fetch_first_by_openid($openid);

	if($_G['uid']) {
		if($user && $user['uid'] != $_G['uid']) {
			wq_showmessage($Plang['ca60fe5280022380'], $_G['cookie']['wq_qqlogin_referer']);
		}
		$binduser = C::t("#wq_qqlogin#wq_qqlogin_member")->fetch_first_by_uid($_G['uid']);
		if($binduser) {
			wq_showmessage($Plang['3f4487fdd2ef303b'], $_G['cookie']['wq_qqlogin_referer']);
		}
	}

	if(!$user) {
		$guest = C::t("#wq_qqlogin#wq_qqlogin_guest")->fetch_first_by_openid($openid);
		if($guest) {
			$figureurl = $guest['figureurl_qq'];
			$nickname = $guest['nickname'];

			$guest['openid'] = $openid;
			$guest['access_token'] = $access_token;
			C::t("#wq_qqlogin#wq_qqlogin_guest")->update($guest['id'], $guest);
		} else {
			try {
				$qq_userinfo = $Oauth->getUserInfo($openid, $access_token);
			} catch (Exception $e) {
				wq_showmessage($Plang['8ee4c54774a89b08'], $_G['cookie']['wq_qqlogin_referer'], array('Message' => $e->getmessage()));
			}
			$userinfo = wq_qqlogin_dispose_qq_userinof($qq_userinfo);

			$nickname = trim($userinfo['nickname']);
			$figureurl = !empty($userinfo['figureurl_qq_2']) ? $userinfo['figureurl_qq_2'] : $userinfo['figureurl_qq_1'];
			$guest = array(
				'nickname' => $nickname,
				'gender' => $userinfo['gender'],
				'figureurl_qq' => $figureurl,
				'province' => $userinfo['province'],
				'city' => $userinfo['city'],
				'openid' => $openid,
				'access_token' => $access_token,
			);
			C::t("#wq_qqlogin#wq_qqlogin_guest")->insert($guest);
		}
	}

	if($_G['uid']) {
		if($setting['is_update_userinfo']) {
			wq_qqlogin_update_userinfo_by_uid($_G['uid'], $guest);

			wq_qqlogin_uploadAvatar($_G['uid'], $figureurl);
		}
		wq_qqlogin_bind_or_register_credit_reward($_G['uid'], 'bind');

		wq_qqlogin_binduser_write_table($_G['uid'], $_G['username'], $openid, $access_token);

		wq_showmessage($Plang['7228b4fb015cd19d'], $_G['cookie']['wq_qqlogin_referer']);
	} else {
		if($user) {
			if($setting['is_update_userinfo']) {
				try {
					$qq_userinfo = $Oauth->getUserInfo($openid, $access_token);
				} catch (Exception $e) {
					wq_showmessage($Plang['8ee4c54774a89b08'], $_G['cookie']['wq_qqlogin_referer'], array('Message' => $e->getmessage()));
				}

				$userinfo = wq_qqlogin_dispose_qq_userinof($qq_userinfo);

				$nickname = trim($userinfo['nickname']);

				$data = array(
					'gender' => $userinfo['gender'],
					'province' => $userinfo['province'],
					'city' => $userinfo['city'],
				);

				wq_qqlogin_update_userinfo_by_uid($user['uid'], $data);

				$data['nickname'] = $nickname;
				DB::update("wq_qqlogin_guest", $data, array('openid' => $openid));

				$figureurl = !empty($userinfo['figureurl_qq_2']) ? $userinfo['figureurl_qq_2'] : $userinfo['figureurl_qq_1'];
				wq_qqlogin_uploadAvatar($user['uid'], $figureurl);
			}

			$login = wq_qqlogin_login($user);
			if(!$login) {
				wq_showmessage($Plang['4c047d111d8e597a'], $_G['cookie']['wq_qqlogin_referer']);
			}

			$ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
			C::t('common_member_status')->update($guest['uid'], array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
			$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);
			$extra = array(
				'showdialog' => true,
				'locationtime' => true,
				'extrajs' => $ucsynlogin
			);

			wq_showmessage($Plang['4fc03f7f596651c2'], $_G['cookie']['wq_qqlogin_referer'], $param, $extra);
		} else {
			if(!$setting['is_bind_exist_user']) {
				$username = wq_qqlogin_process_username($nickname);

				if(empty($username)) {
					wq_showmessage($Plang['b34e2e1f5db7cd40'], $_G['cookie']['wq_qqlogin_referer']);
				}
				$register_success = wq_qqlogin_register($username, '');

				if(!$register_success['uid']) {
					showmessage($Plang['9418c5870db6450f'], $_G['cookie']['wq_qqlogin_referer']);
				}

				wq_qqlogin_uploadAvatar($register_success['uid'], $figureurl);

				wq_qqlogin_update_userinfo_by_uid($register_success['uid'], $guest);

				wq_qqlogin_bind_or_register_credit_reward($register_success['uid']);

				wq_qqlogin_binduser_write_table($register_success['uid'], $register_success['username'], $openid, $access_token, 0, 0);

				$login = wq_qqlogin_login($register_success);
				$param = array('bbname' => $_G['setting']['bbname'], 'username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);

				$extra = array(
					'showdialog' => true,
					'locationtime' => true,
				);
				if(!$login) {
					wq_showmessage($Plang['cc7e167bb6f65028'], $_G['cookie']['wq_qqlogin_referer'], $param, $extra);
				}
				dsetcookie('wq_qqlogin_auth_hash');
				wq_showmessage($Plang['5b6b4fc05d88e11c'], $_G['cookie']['wq_qqlogin_referer'], $param, $extra);
			}

			if($nickname) {
				dsetcookie('wq_qqlogin_nickname', $nickname, 86400);
			}

			dsetcookie('wq_qqlogin_isbind', 0, 86400);

			$auth_hash = authcode($openid, 'ENCODE');
			dsetcookie('wq_qqlogin_auth_hash', $auth_hash, 86400);

			if($figureurl) {
				dsetcookie('wq_qqlogin_figureurl', $figureurl, 86400);
			}
			dheader("Location:plugin.php?id=wq_qqlogin&mod=login&referer=" . urlencode($_G['cookie']['wq_qqlogin_referer']));
		}
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>