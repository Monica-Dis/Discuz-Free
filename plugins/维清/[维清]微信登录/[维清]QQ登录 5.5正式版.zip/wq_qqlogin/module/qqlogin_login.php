<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = in_array($_GET['ac'], array('login', 'bind')) ? dhtmlspecialchars($_GET['ac']) : "";
$dreferer = dreferer();
$param = array('bbname' => $_G['setting']['bbname'], 'url' => $dreferer);


$seccodecheck = $_G['setting']['seccodedata']['rule']['register']['allow'];
$auth_hash = $_GET['$auth_hash'] ? $_GET['auth_hash'] : $_G['cookie']['wq_qqlogin_auth_hash'];
$openid = authcode($auth_hash);

if(!$openid) {
	dheader('Location:./');
}

if($ac == 'bind') {
	if(submitcheck('loginsubmit')) {
		$username = addslashes(dhtmlspecialchars(trim($_GET['username'])));
		$uid = intval(C::t('common_member')->fetch_uid_by_username($username));
		if(!$uid) {
			wq_showmessage($Plang['4e9e29b53046838c']);
		}

		list($result) = uc_user_login($username, trim($_GET['password']), 0, 1, $_GET['questionid'], $_GET['answer']);
		if($result < 0) {
			$rmsg = $result == '-3' ? (!$_GET['questionid'] || !$_GET['answer'] ? $Plang['login_question_empty'] : $Plang['login_question_invalid']) : $Plang['426845aac6e98fde'];
			wq_showmessage($rmsg);
		}
		$user = C::t("#wq_qqlogin#wq_qqlogin_member")->fetch_first_by_uid($uid);
		if($user) {
			wq_showmessage($Plang['3f4487fdd2ef303b']);
		}

		wq_qqlogin_bind_or_register_credit_reward($uid, 'bind');

		if($setting['is_update_userinfo']) {
			wq_qqlogin_update_userinfo_by_uid($uid, $guset);
		}

		$guset = C::t("#wq_qqlogin#wq_qqlogin_guest")->fetch_first_by_openid($openid);
		wq_qqlogin_binduser_write_table($uid, $username, $guset['openid'], $guset['access_token']);

		$data = array(
			'uid' => $uid,
			'username' => $username,
		);

		$login = wq_qqlogin_login($data);

		$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);
		$extra = array(
			'showdialog' => true,
			'locationtime' => true,
		);

		dsetcookie('wq_qqlogin_auth_hash');

		if(!$login) {
			wq_showmessage($Plang['4c047d111d8e597a'], $dreferer, $param, $extra);
		}
		C::t('common_member_status')->update($uid, array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

		wq_showmessage($Plang['4fc03f7f596651c2'], $dreferer, $param, $extra);
	}
} else {
	if(submitcheck('registersubmit', 0, $seccodecheck)) {
		$username = addslashes(dhtmlspecialchars(trim($_GET['username'])));
		$password = $_GET['password'];
		$password2 = $_GET['password2'];

		if(empty($username)) {
			wq_showmessage($Plang['358b2ff635949030']);
		}

		if(strlen($username) < 3 || strlen($username) > 15) {
			wq_showmessage($Plang['4618efae97fc33f9']);
		}

		if(empty($password)) {
			wq_showmessage($Plang['bda5051be3094609']);
		}
		if(strlen($password) < $setting['pwd_strlen']) {
			wq_showmessage(sprintf($Plang['722b290f3dfcade7'], $setting['pwd_strlen']));
		}

		if(is_numeric($password) && !$setting['pwd_is_numeric']) {
			wq_showmessage($Plang['a9e19d6d6b587830']);
		}
		if(!$setting['pwd_is_english'] && preg_match("/[a-z]+/i", $password) && !preg_match("/[0-9]+/i", $password)) {
			wq_showmessage($Plang['b9b81451d3a70378']);
		}
		if($password != $password2) {
			wq_showmessage($Plang['5a04f36409b58f7a']);
		}

		if($setting['register_email'] && $setting['is_bind_exist_user']) {
			$email = strtolower(trim($_GET['email']));
			wq_qqlogin_checkemail($email);
		}

		$bindinfo = C::t("#wq_qqlogin#wq_qqlogin_member")->fetch_first_by_openid($openid);
		if(!empty($bindinfo)) {
			wq_showmessage($Plang['ca60fe5280022380']);
		}

		$username = wq_qqlogin_process_username($username);
		if(empty($username)) {
			wq_showmessage($Plang['b34e2e1f5db7cd40']);
		}

		$register_success = wq_qqlogin_register($username, $password, 0, $email);

		$extra = array(
			'showdialog' => true,
			'locationtime' => true,
		);

		if(!$register_success['uid']) {
			wq_showmessage($Plang['9418c5870db6450f'], $dreferer, array(), $extra);
		}

		wq_qqlogin_uploadAvatar($register_success['uid'], $_G['cookie']['wq_qqlogin_figureurl']);

		$guset = C::t("#wq_qqlogin#wq_qqlogin_guest")->fetch_first_by_openid($openid);
		wq_qqlogin_binduser_write_table($register_success['uid'], $register_success['username'], $guset['openid'], $guset['access_token']);

		wq_qqlogin_bind_or_register_credit_reward($register_success['uid']);

		if($setting['is_update_userinfo']) {
			wq_qqlogin_update_userinfo_by_uid($register_success['uid'], $guset);
		}

		$login = wq_qqlogin_login($register_success);
		$param = array('bbname' => $_G['setting']['bbname'], 'username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);

		dsetcookie('wq_qqlogin_auth_hash');
		if(!$login) {
			wq_showmessage($Plang['4c047d111d8e597a'], $dreferer, $param, $extra);
		}
		wq_showmessage($Plang['5b6b4fc05d88e11c'], $dreferer, $param, $extra);
	}
}
include_once template("wq_qqlogin:qqlogin_login");

?>