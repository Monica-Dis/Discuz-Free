<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_qqlogin_guest extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_qqlogin_guest';
		$this->_pk = 'id';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function fetch_first_by_openid($openid) {
		return DB::fetch_first("SELECT * FROM %t WHERE openid=%s", array($this->_table, $openid));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>