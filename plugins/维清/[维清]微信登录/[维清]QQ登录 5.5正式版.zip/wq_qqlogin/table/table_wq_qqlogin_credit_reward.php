<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_qqlogin_credit_reward extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_qqlogin_credit_reward';
		$this->_pk = 'bid';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	function fetch_first_by_uid($uid) {
		return DB::fetch_first('SELECT * FROM %t WHERE uid=%d ', array($this->_table, $uid));
	}

	public function fetch_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid = %d ", array($this->_table, $uid));
	}

	public function fetch_by_status($status) {
		return DB::fetch_first("SELECT * FROM %t WHERE status = %d ", array($this->_table, $status));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>