<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_qqlogin_member extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_qqlogin_member';
		$this->_pk = 'bid';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function fetch_first_by_uid($uid, $flag = false) {
		if($flag) {
			return DB::fetch_first("SELECT m.*,g.nickname,g.gender FROM %t m left join %t g ON m.openid=g.openid WHERE m.uid=%d", array($this->_table, "wq_qqlogin_guest", $uid));
		} else {
			return DB::fetch_first("SELECT * FROM %t WHERE uid=%s", array($this->_table, $uid));
		}
	}

	public function fetch_first_by_openid($openid) {
		return DB::fetch_first("SELECT * FROM %t WHERE openid=%s", array($this->_table, $openid));
	}

	public function delete_by_uid($uid) {
		return DB::delete($this->_table, array('uid' => $uid));
	}

	public function update_by_uid($uid, $newusername = "", $chgpassword = false) {
		if($chgpassword) {
			$data = array('chgpassword' => '1');
		} else {
			$data = array('chgusername' => '1', 'username' => $newusername);
		}
		return DB::update($this->_table, $data, array('uid' => $uid));
	}

	public function fetch_all_by_search($gender, $chgusername, $chgpassword, $keyword, $search, $dateline, $dateline1, $dateline2, $displayorder, $ordertype, $start, $limit) {
		$val[] = $this->_table;
		$val[] = "wq_qqlogin_guest";
		$sql[] = '1';

		if($displayorder) {
			$order = ' ORDER BY m.' . $displayorder . ' ' . $ordertype . ' ';
		}
		if($gender != '') {
			$sql[] = 'g.gender=%d';
			$val[] = $gender;
		}
		if($chgusername != '') {
			$sql[] = 'm.chgusername=%d';
			$val[] = $chgusername;
		}
		if($chgpassword != '') {
			$sql[] = 'm.chgpassword=%d';
			$val[] = $chgpassword;
		}
		if($dateline && $dateline1) {
			$sql[] = 'm.' . $dateline . '>=%d';
			$val[] = $dateline1;
		}
		if($dateline && $dateline2) {
			$sql[] = '%d>=' . 'm.' . $dateline;
			$val[] = $dateline2;
		}

		if($keyword && $search) {
			$search == 'username' ? $search = "m.username" : $search = "g.nickname";
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t m left join %t g ON m.openid=g.openid WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($gender, $chgusername, $chgpassword, $keyword, $search, $dateline, $dateline1, $dateline2) {
		$val[] = $this->_table;
		$val[] = "wq_qqlogin_guest";
		$sql[] = '1';
		if($gender != '') {
			$sql[] = 'g.gender=%d';
			$val[] = $gender;
		}

		if($chgusername != '') {
			$sql[] = 'm.chgusername=%d';
			$val[] = $chgusername;
		}
		if($chgpassword != '') {
			$sql[] = 'm.chgpassword=%d';
			$val[] = $chgpassword;
		}
		if($dateline && $dateline1) {
			$sql[] = 'm.' . $dateline . '>=%d';
			$val[] = $dateline1;
		}
		if($dateline && $dateline2) {
			$sql[] = '%d>=' . 'm.' . $dateline;
			$val[] = $dateline2;
		}
		if($keyword && $search) {
			search == 'username' ? $search = "m.username" : $search = "g.nickname";
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t m left join %t g ON m.openid=g.openid WHERE " . $wheresql, $val);
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>