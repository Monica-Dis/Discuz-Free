<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache("plugin");
include './source/plugin/wq_qqlogin/config/config.php';
$gender = in_array($_GET['gender'], array('0', '1', '2')) ? $_GET['gender'] : '';
$chgusername = in_array($_GET['chgusername'], array('0', '1')) ? $_GET['chgusername'] : '';
$chgpassword = in_array($_GET['chgpassword'], array('0', '1')) ? $_GET['chgpassword'] : '';
$dateline = in_array($_GET['dateline'], array('dateline')) ? $_GET['dateline'] : 'dateline';
$search = in_array($_GET['search'], array('nickname', 'username')) ? $_GET['search'] : 'username';
$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? $_GET['ordertype'] : 'desc';
$dateline1 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['starttime'])) ? strtotime(trim($_GET['starttime'])) : '';
$dateline2 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['endtime'])) ? strtotime(trim($_GET['endtime'])) : '';
$displayorder = in_array($_GET['displayorder'], array('dateline')) ? $_GET['displayorder'] : 'dateline';
$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
$limit = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 20;
$ac = in_array($_GET['ac'], array('unbind')) ? dhtmlspecialchars($_GET['ac']) : "";

$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $limit;
$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs';
$curl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs';

$all = C::t('#wq_qqlogin#wq_qqlogin_member')->fetch_all_by_search($gender, $chgusername, $chgpassword, $keyword, $search, $dateline, $dateline1, $dateline2, $displayorder, $ordertype, $start, $limit);
$count = C::t('#wq_qqlogin#wq_qqlogin_member')->count_by_search($gender, $chgusername, $chgpassword, $keyword, $search, $dateline, $dateline1, $dateline2);

$mpurl .= $dateline != 'dateline' ? '&dateline=' . $dateline : '';
$mpurl .= $search != 'username' ? '&search=' . $search : '';
$mpurl .= $ordertype != 'desc' ? '&ordertype=' . $ordertype : '';
$mpurl .= $dateline1 != '' ? '&starttime=' . $_GET['starttime'] : '';
$mpurl .= $dateline2 != '' ? '&endtime=' . $_GET['endtime'] : '';
$mpurl .= $displayorder != 'dateline' ? '&displayorder=' . $displayorder : '';
$mpurl .=!empty($keyword) ? '&keyword=' . $_GET['keyword'] : '';
$mpurl .= $chgusername !== '' ? '&chgusername=' . $chgusername : '';
$mpurl .= $chgpassword !== '' ? '&chgpassword=' . $chgpassword : '';
$url = $mpurl;
$mpurl .= $gender !== '' ? '&gender=' . $gender : '';
$href = $mpurl . '&page=' . $_GET['page'];
$url = ADMINSCRIPT . '?' . $url;
$mpurl = ADMINSCRIPT . '?' . $mpurl;

echo"<style tpye='text/css'>
   .hover div:hover,.sex{background-color: #666666 !important;}
    .hover div{width:55px;height;text-align:center;line-height:18px;border-radius:4px;}
    .hover div:hover a,.sex a{color:#FFF !important;}
       li{float:left;}
     .mradio_html li{line-height:25px;}
       input:hover, input:focus,select:hover,select:focus{border-color:#09C;background: #F5F9FD none repeat scroll 0% 0%;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    td span{color:red;}
    .addtr {background: transparent url('static/image/admincp/bg_repno.gif') no-repeat scroll 2px 3px;line-height: 30px;}
    </style>
    <script type='text/javascript' src='static/js/calendar.js'></script>
<script>_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e,'forms'); });</script>";
if($ac == 'unbind') {
	$uid = $_GET['uid'] ? intval($_GET['uid']) : 0;
	if(!$uid) {
		cpmsg($Plang['80ca179ddfd1c735'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs', 'error');
	}
	if(!submitcheck('unbindsubmit')) {
		$extra = "<input type=\"hidden\" name=\"unbindsubmit\" value=\"yes\">\n<input type=\"hidden\" name=\"uid\" value=\"$uid\">";
		cpmsg($Plang['99372c387fd718f8'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs&ac=unbind', 'form', array(), $extra);
	} else {
		C::t("#wq_qqlogin#wq_qqlogin_member")->delete_by_uid($uid);
		cpmsg($Plang['2bd6214a2c3c840a'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs', 'succeed');
	}
} else {

	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_qqlogin&pmod=admincp_bindlogs';
	showformheader($fromurl, '', 'forms');
	showtableheader(); //dism��taobao��com
	$perpage_html = perpage_html($limit);
	$typehtml = radio_html(array('desc' => $Plang['5bee37fbebf639d9'], 'asc' => $Plang['60f4919063d76ce2']), 'ordertype', $ordertype);
	$timetpye = array('dateline' => $Plang['60ee78ec85f40105']);
	$chgusername_html = select_html(array('0' => $Plang['userstatus_0'], '1' => $Plang['userstatus_1']), 'chgusername', $chgusername);
	$datetype = select_html(array('dateline' => $Plang['60ee78ec85f40105']), 'dateline', $dateline, false);
	$orderhtml = select_html($timetpye, 'displayorder', $displayorder, false);
	$datehtml = text_html($_GET['starttime'], $_GET['endtime']);
	$chgpassword_html = select_html(array('0' => $Plang['userstatus_0'], '1' => $Plang['userstatus_1']), 'chgpassword', $chgpassword);
	showtablerow('', array('width="65"', 'width="65"', 'width="55"', 'width="65"', 'width="30"', 'width="60"'), array(
		$Plang['ee2cddb152497b7a'], $chgusername_html,
		$Plang['2e341d9c625f4c06'], $chgpassword_html,
		$Plang['c815888e8e62acd1'], $orderhtml, $typehtml,
	));
	showtablefooter(); //Dism��taobao��com

	$keywordtype = array('nickname' => $Plang['9e81522ad5be1af7'], 'username' => $Plang['20271ac60b472d14']);
	$options = select_html($keywordtype, 'search', $search, false, false);
	showtableheader(); //dism��taobao��com
	showtablerow('', array('width="60"', 'width="270"', 'width="50"', 'width="50"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"'), array(
		$datetype, $datehtml,
		$Plang['62fa857dd698b74d'], $options, "<input size = \"25\" name=\"keyword\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['keyword']) . "\" placeholder='" . $Plang['f5d7c38c95fd323a'] . "' />" .
		"<input name=\"sex\" type=\"hidden\" value=\"" . $gender . "\" />",
		"<input id='submit_forms' class=\"btn\" type=\"submit\" value=\"$Plang[search]\" name='forms'/>",
		"<div " . ($gender === '' ? 'class="sex"' : "") . "><a style='color:#000;' href=\"" . $url . "\">" . $Plang['all'] . "</a></div>",
		"<div " . ($gender === '0' ? 'class="sex"' : "") . "><a style='color:green;' href=\"" . $url . "&gender=0\">" . $Plang['gender_0'] . "</a></div>",
		"<div " . ($gender === '1' ? 'class="sex"' : "") . "><a style='color:blue;' href=\"" . $url . "&gender=1\">" . $Plang['gender_1'] . "</a></div>",
		"<div " . ($gender === '2' ? 'class="sex"' : "") . "><a style='color:red;' href=\"" . $url . "&gender=2\">" . $Plang['gender_2'] . "</a></div>",
		'',
	));
	showtablefooter(); //Dism��taobao��com
	showformfooter(); //Dism_taobao_com

	showtableheader($Plang['02b1f6bfa5de4fbf'], 'nobottom');
	$gender_color = array('0' => "green", '2' => "red", '1' => "blue");
	showsubtitle(array($Plang['20271ac60b472d14'], $Plang['9e81522ad5be1af7'], $Plang['3b5f619dcf8c953e'], $Plang['caaca00ec47f729b'], $Plang['9f1a68900c690d4a'], $Plang['a341595f9b916135'], $Plang['b5a23b9026d5ac0d'], $Plang['60ee78ec85f40105'], $Plang['manage']));
	foreach($all as $val) {
		showtablerow('class="tr""', array('width="200"', 'width="200"',), array(
			"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
			$val['nickname'] ? $val['nickname'] : $Plang['d8ea50028797d588'],
			$val['openid'],
			$val['province'] || $val['city'] ? $val['province'] . $val['city'] : $Plang['d8ea50028797d588'],
			'<font style="color:' . $gender_color[$val['gender']] . '">' . $Plang['gender_' . $val['gender']] . '</font>',
			$val['chgusername'] == 1 ? $Plang['c7b4099dec98b579'] : $Plang['5b553415507d5daf'],
			$val['chgpassword'] == 1 ? $Plang['c7b4099dec98b579'] : $Plang['5b553415507d5daf'],
			$val['dateline'] ? date("Y-m-d H:i:s", $val['dateline']) : $Plang['d8ea50028797d588'],
			'<a href="' . $curl . '&ac=unbind&uid=' . $val['uid'] . '">' . $Plang['4e97e74f8958eab5'] . '</a>',
		));
	}
	$multi = multi($count, $limit, $page, $mpurl);
	showtablefooter(); //Dism��taobao��com

	showtableheader(); //dism��taobao��com
	showtablerow('', '', array($multi));
	showtablefooter(); //Dism��taobao��com
}
//dis'.'m.t'.'ao'.'bao.com
?>