<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_qqlogin/class/base.class.php';

class plugin_wq_qqlogin extends plugin_wq_qqlogin_base {

	function global_header() {

	}

	function common() {
		global $_G;
		$this->common_base();
		$_G['qq_lang'] = $this->lang;
		$_G['member']['qqbind'] = false;
		if($this->wq_qqlogin_get_uid_isbind()) {
			$_G['member']['qqbind'] = true;
		}

		if($_G['uid']) {
			$_G['wq_qqlogin'] = C::t('#wq_qqlogin#wq_qqlogin_member')->fetch_first_by_uid($_G['uid']);
		}
	}

	function global_login_extra() {
		global $_G;

		if(!$this->allow || $_G['inshowmessage']) {
			return;
		}
		return wq_qqlogin_global_login_extra();
	}

	function global_usernav_extra1() {
		global $_G;

		if(!$this->allow) {
			return;
		}

		if(!$_G['uid'] && !$_G['connectguest']) {
			return;
		}

		return wq_qqlogin_global_usernav_extra1();
	}

	function global_footer() {
		global $_G;

		if($_G['uid'] && $this->setting['bind_is_site'] == 1) {
			return wq_qqlogin_global_usernav_extra1_menu();
		}
	}

	function deletemember($param) {
		$uids = $param['param'][0];
		$step = $param['step'];
		if($step == 'check' && $uids && is_array($uids)) {
			foreach($uids as $uid) {
				C::t('#wq_qqlogin#wq_qqlogin_member')->delete_by_uid($uid);
			}
		}
	}

}

class plugin_wq_qqlogin_member extends plugin_wq_qqlogin {

	function logging_method() {
		if(!$this->allow) {
			return;
		}
		return wq_qqlogin_login_bar();
	}

	function register_logging_method() {
		if(!$this->allow) {
			return;
		}
		return wq_qqlogin_login_bar();
	}

	function logging_member() {
		global $_G;
		if($this->allow && $_G['connectguest'] && $_GET['action'] == 'login') {
			if($_G['inajax']) {
				showmessage($this->lang['77caaef99f50e8b2']);
			} else {
				dheader('location: ' . $_G['siteurl'] . 'plugin.php?id=wq_qqlogin&mod=login&ac=bind');
			}
		}
	}

	function register_member() {
		global $_G;
		if($this->allow && $_G['connectguest']) {
			if($_G['inajax']) {
				showmessage($this->lang['77caaef99f50e8b2']);
			} else {
				dheader('location: ' . $_G['siteurl'] . 'plugin.php?id=wq_qqlogin&mod=login');
			}
		}
	}

}

class plugin_wq_qqlogin_home extends plugin_wq_qqlogin {

	function spacecp_plugin_home_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

}

class mobileplugin_wq_qqlogin extends plugin_wq_qqlogin_base {

	function common() {
		global $_G;
		$this->common_base();
		$_G['qq_lang'] = $this->lang;
		$_G['member']['qqbind'] = false;
		if($this->wq_qqlogin_get_uid_isbind()) {
			$_G['member']['qqbind'] = true;
		}
	}

	function global_footer_mobile() {
		global $_G;
		if(!$this->is_wq_touch()) {

			if($_G['uid'] && CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile' && $_GET['mycenter'] == 1) {
				include_once template('wq_qqlogin:module');
				return _tpl_qqlogin_profile();
			}
		}
	}

	function is_wq_touch($touch = true, $app = true) {
		global $_G;
		$status = false;
		$touch_tplid = $_G['setting']['styleid2'];
		loadcache('style_' . $touch_tplid);
		$touch_tpl = $_G['cache']['style_' . $touch_tplid];
		if($touch_tpl['tpldir'] == './template/wq_touch' && $touch) {
			$status = true;
		}
		if($touch_tpl['tpldir'] == './template/wq_app' && $app) {
			$status = true;
		}
		return $status;
	}

}

class mobileplugin_wq_qqlogin_member extends mobileplugin_wq_qqlogin {

	function logging_member() {
		global $_G;
		if($this->allow && $_G['connectguest'] && $_GET['action'] == 'login') {
			if($_G['inajax']) {
				showmessage($this->lang['77caaef99f50e8b2']);
			} else {
				dheader('location: ' . $_G['siteurl'] . 'plugin.php?id=wq_qqlogin&mod=login&ac=bind');
			}
		}
	}

	function register_member() {
		global $_G;
		if($this->allow && $_G['connectguest']) {
			if($_G['inajax']) {
				showmessage($this->lang['77caaef99f50e8b2']);
			} else {
				dheader('location: ' . $_G['siteurl'] . 'plugin.php?id=wq_qqlogin&mod=login');
			}
		}
	}

	function logging_bottom_mobile() {
		global $_G;

		if($this->is_wq_touch(false, true)) {
			return '';
		}

		$referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
		$referer = urlencode($referer);

		$str = <<<EOT
<style>
.btn_qqlogin .qqlogin{ margin-top: 10px; background:#1cbaf6; border-radius: 3px; width:100%; height:40px; display:block; line-height:40px; overflow:hidden; color:#FFF; font-size:16px;text-align:center;border:0; }
.btn_qqlogin .qqlogin:hover{ background:#01a9e9; color:#fff; }
</style>
<div class="btn_qqlogin"><a href="plugin.php?id=wq_qqlogin&mod=access&op=init&referer={$referer}" class="qqlogin"><span>{$this->lang['3e26f6afb8a86a49']}</span></a></div>
EOT;
		return $str;
	}

}

class mobileplugin_wq_qqlogin_home extends mobileplugin_wq_qqlogin {

	function follow_home_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

	function space_profile_home_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

	function spacecp_favorite_home_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

}

class mobileplugin_wq_qqlogin_forum extends mobileplugin_wq_qqlogin {

	function post_wq_qqlogin_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

	function misc_wq_qqlogin_message($params) {
		global $_G;

		$this->wq_qqlogin_login_msg($params);
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>