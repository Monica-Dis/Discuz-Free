<?php

function wq_qqlogin_get_plang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_qqlogin/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_qqlogin/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_qqlogin/language");
	}
	include $_var_1;
	global $wq_qqlogin_plang;
	return $wq_qqlogin_plang;
}
function wq_qqlogin_process_username($_arg_0, $_arg_1 = 0)
{
	global $_G;
	$_arg_0 = trim($_arg_0);
	$_var_3 = dstrlen($_arg_0);
	if ($_var_3 < 3) {
		$_arg_0 = $_arg_0 . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90));
	} else {
		if ($_var_3 > 15) {
			$_arg_0 = cutstr($_arg_0, 15, '');
		}
	}
	loaducenter();
	$_var_4 = uc_user_checkname($_arg_0);
	if ($_var_4 == -1) {
		wq_qqlogin_checkname_error($_var_4, $_arg_1);
		$_arg_0 = str_replace(array(", ", " ", "%", "<", ">", "*", "\""), '', $_arg_0);
		$_arg_0 = wq_qqlogin_process_username($_arg_0);
	} else {
		if ($_var_4 == -2) {
			wq_qqlogin_checkname_error($_var_4, $_arg_1);
			$_var_5 = 0;
			while ($_var_5 < 5) {
				$_var_6 = $_var_6 . chr(rand(65, 90));
				$_var_5;
			}
			$_arg_0 = wq_qqlogin_process_username($_var_6);
		} else {
			if ($_var_4 == -3) {
				wq_qqlogin_checkname_error($_var_4, $_arg_1);
				$_arg_0 = cutstr($_arg_0, 10, '') . "_" . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90));
				$_arg_0 = wq_qqlogin_process_username($_arg_0);
			}
		}
	}
	$_var_7 = "/^(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_G["setting"]["censoruser"] = trim($_G["setting"]["censoruser"]), "/")) . ")\$/i";
	if ($_G["setting"]["censoruser"] && @preg_match($_var_7, $_arg_0)) {
		wq_qqlogin_checkname_error($_var_4, $_arg_1);
		$_var_8 = explode("\n", $_G["setting"]["censoruser"]);
		foreach ($_var_8 as $_var_9 => $_var_10) {
			$_var_6[] = trim($_var_10);
		}
		$_arg_0 = str_replace($_var_6, '', $_arg_0);
		$_arg_0 = wq_qqlogin_process_username($_arg_0);
	}
	return $_arg_0;
}
function wq_qqlogin_checkname_error($_arg_0, $_arg_1 = 0)
{
	if ($_arg_1 > 3) {
		$_var_2 = wq_qqlogin_get_plang();
		if ($_arg_0 == -1) {
			$_var_3 = $_var_2["username_error_1"];
			goto label_13154;
		}
		if ($_arg_0 == -2) {
			$_var_3 = $_var_2["username_error_2"];
			goto label_13154;
		}
		if ($_arg_0 == -3) {
			$_var_3 = $_var_2["username_error_3"];
			goto label_13154;
		}
		$_var_3 = $_var_2["username_error"];
		label_13154:
		showmessage($_var_3);
	}
}
function wq_qqlogin_checkemail($_arg_0)
{
	global $_G;
	$_var_2 = wq_qqlogin_get_plang();
	if (strlen($_arg_0) > 32) {
		wq_showmessage($_var_2["cdcb74f95825c560"]);
	}
	if ($_G["setting"]["regmaildomain"]) {
		$_var_3 = "/(" . str_replace("\r\n", "|", preg_quote(trim($_G["setting"]["maildomainlist"]), "/")) . ")\$/i";
		if ($_G["setting"]["regmaildomain"] == 1 && !preg_match($_var_3, $_arg_0)) {
			wq_showmessage($_var_2["531832f391e7ff80"]);
		} else {
			if ($_G["setting"]["regmaildomain"] == 2 && preg_match($_var_3, $_arg_0)) {
				wq_showmessage($_var_2["531832f391e7ff80"]);
			}
		}
	}
	loaducenter();
	$_var_4 = uc_user_checkemail($_arg_0);
	if ($_var_4 == -4) {
		wq_showmessage($_var_2["cdcb74f95825c560"]);
	} else {
		if ($_var_4 == -5) {
			wq_showmessage($_var_2["531832f391e7ff80"]);
		} else {
			if ($_var_4 == -6) {
				wq_showmessage($_var_2["ec11bb56a1f6e5fc"]);
			}
		}
	}
}
function wq_qqlogin_register($_arg_0, $_arg_1 = '', $_arg_2 = 0, $_arg_3 = '')
{
	global $_G;
	$_var_5 = dunserialize($_G["setting"]["wq_qqlogin"]);
	if (!$_arg_0) {
		return '';
	}
	include_once UC_ROOT . "./model/base.php";
	$_var_6 = new base();
	$_var_7 = $_var_6->get_setting(array("accessemail"));
	$_var_8 = $_var_7["accessemail"];
	$_var_9 = explode("\n", str_replace("\r\n", "\n", $_var_8));
	$_var_10 = $_var_5["newusergroupid"] ? $_var_5["newusergroupid"] : $_G["setting"]["newusergroupid"];
	if (!$_arg_1) {
		$_arg_1 = md5(random(10));
	}
	if (empty($_arg_3)) {
		if ($_var_9[0] == '') {
			$_arg_3 = "qqlogin_" . strtolower(random(10)) . "@null.null";
		} else {
			$_arg_3 = "qqlogin_" . strtolower(random(10)) . "@" . trim(trim(strtolower($_var_9[0])));
			$_arg_3 = str_replace(array("@@", "@"), "@", $_arg_3);
		}
	}
	if (!$_var_5["disableregrule"]) {
		loadcache("ipctrl");
		if ($_G["cache"]["ipctrl"]["ipregctrl"]) {
			foreach (explode("\n", $_G["cache"]["ipctrl"]["ipregctrl"]) as $_var_11) {
				if (preg_match("/^(" . preg_quote($_var_11 = trim($_var_11), "/") . ")/", $_G["clientip"])) {
					$_var_11 = $_var_11 . "%";
					$_G["setting"]["regctrl"] = $_G["setting"]["ipregctrltime"];
					break;
				}
				$_var_11 = $_G["clientip"];
			}
		} else {
			$_var_11 = $_G["clientip"];
		}
		if ($_G["setting"]["regctrl"]) {
			if (C::t("common_regip")->count_by_ip_dateline($_var_11, $_G["timestamp"] - $_G["setting"]["regctrl"] * 3600)) {
				if (!$_arg_2) {
					showmessage("register_ctrl", NULL, array("regctrl" => $_G["setting"]["regctrl"]));
				} else {
					return NULL;
				}
			}
		}
		$_var_12 = NULL;
		if ($_G["setting"]["regfloodctrl"]) {
			$_var_13 = C::t("common_regip")->fetch_by_ip_dateline($_G["clientip"], $_G["timestamp"] - 86400);
			if ($_var_13) {
				if ($_var_13["count"] >= $_G["setting"]["regfloodctrl"]) {
					if (!$_arg_2) {
						showmessage("register_flood_ctrl", NULL, array("regfloodctrl" => $_G["setting"]["regfloodctrl"]));
					} else {
						return NULL;
					}
				} else {
					$_var_12 = 1;
				}
			} else {
				$_var_12 = 2;
			}
		}
		if ($_var_12 !== NULL) {
			if ($_var_12 == 1) {
				C::t("common_regip")->update_count_by_ip($_G["clientip"]);
			} else {
				C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => 1, "dateline" => $_G["timestamp"]));
			}
		}
	}
	$_var_14 = wq_qqlogin_system_register($_arg_0, $_arg_1, $_arg_3);
	$_var_15 = $_var_14[0];
	$_arg_0 = $_var_14[1];
	$_var_16 = array("credits" => explode(",", $_G["setting"]["initcredits"]));
	C::t("common_member")->insert($_var_15, $_arg_0, $_arg_1, $_arg_3, $_G["clientip"], $_var_10, $_var_16);
	if ($_G["setting"]["regctrl"] || $_G["setting"]["regfloodctrl"]) {
		C::t("common_regip")->delete_by_dateline($_G["timestamp"] - ($_G["setting"]["regctrl"] > 72 ? $_G["setting"]["regctrl"] : 72) * 3600);
		if ($_G["setting"]["regctrl"]) {
			C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => -1, "dateline" => $_G["timestamp"]));
		}
	}
	if ($_G["setting"]["regverify"] == 2) {
		C::t("common_member_validate")->insert(array("uid" => $_var_15, "submitdate" => $_G["timestamp"], "moddate" => 0, "admin" => '', "submittimes" => 1, "status" => 0, "message" => '', "remark" => ''), false, true);
		manage_addnotify("verifyuser");
	}
	require_once libfile("function/member");
	$_var_17 = 1296000;
	setloginstatus(array("uid" => $_var_15, "username" => $_arg_0, "password" => $_arg_1, "groupid" => $_var_10), $_var_17);
	dsetcookie("isqquser", 1, $_var_17);
	include_once libfile("function/stat");
	updatestat("register");
	include_once libfile("cache/userstats", "function");
	build_cache_userstats();
	return array("uid" => $_var_15, "username" => $_arg_0);
}
function wq_qqlogin_system_register($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_var_4 = uc_user_register(addslashes($_arg_0), $_arg_1, $_arg_2, '', '', $_G["clientip"]);
	$_var_5 = wq_qqlogin_get_plang();
	if ($_var_4 <= 0) {
		if (!$_var_6) {
			if ($_var_4 == -1) {
				showmessage($_var_5["0d8261e867fea2a0"]);
			} else {
				if ($_var_4 == -2) {
					showmessage($_var_5["c6cbbb7e85ac64c1"]);
				} else {
					if ($_var_4 == -3) {
						showmessage($_var_5["8921f84837506189"]);
					} else {
						if ($_var_4 == -4) {
							showmessage($_var_5["cdcb74f95825c560"]);
						} else {
							if ($_var_4 == -5) {
								showmessage($_var_5["531832f391e7ff80"]);
							} else {
								if ($_var_4 == -6) {
									showmessage($_var_5["ec11bb56a1f6e5fc"]);
								}
							}
						}
					}
				}
			}
		} else {
			return NULL;
		}
	} else {
		return array($_var_4, $_arg_0);
	}
}
function wq_qqlogin_login($_arg_0)
{
	global $_G;
	if (!($_arg_0 = getuserbyuid($_arg_0["uid"], 1))) {
		return false;
	}
	if (isset($_arg_0["_inarchive"])) {
		C::t("common_member_archive")->move_to_master($_arg_0["uid"]);
	}
	require_once libfile("function/member");
	$_var_2 = 1296000;
	setloginstatus($_arg_0, $_var_2);
	dsetcookie("isqquser", 1, $_var_2);
	return true;
}
function wq_qqlogin_changeusername($_arg_0, $_arg_1)
{
	$_var_2 = DB::fetch_first("SELECT * FROM " . DB::table("common_member") . " WHERE username='" . $_arg_0 . "'");
	if ($_var_2) {
		DB::query("UPDATE " . DB::table("common_adminnote") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block_item") . " SET title='" . $_arg_1 . "' WHERE title='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block_item_data") . " SET title='" . $_arg_1 . "' WHERE title='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_card_log") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_failedlogin") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_grouppm") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_invite") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_security") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_validate") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_verify_info") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_security") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_mytask") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_report") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_session") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_word") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_activityapply") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_announcement") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collection") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectioncomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionfollow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionteamworker") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_forumrecommend") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_groupuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_imagetype") . " SET name='" . $_arg_1 . "' WHERE name='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_order") . " SET buyer='" . $_arg_1 . "' WHERE buyer='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_order") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_pollvoter") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_post") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_postcomment") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_promotion") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_ratelog") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_rsscache") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_thread") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_threadmod") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_trade") . " SET seller='" . $_arg_1 . "' WHERE seller='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_tradelog") . " SET seller='" . $_arg_1 . "' WHERE seller='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_tradelog") . " SET buyer='" . $_arg_1 . "' WHERE buyer='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_warning") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_album") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_blog") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_clickuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_comment") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_docomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_doing") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_feed_app") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed_archiver") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_friend") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_friend_request") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_notification") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_pic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_poke") . " SET fromusername='" . $_arg_1 . "' WHERE fromusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_share") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_show") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_specialuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_visitor") . " SET vusername='" . $_arg_1 . "' WHERE vusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_specialuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_article_title") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_comment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_rsscache") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_topic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_topic_pic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collection") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectioncomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionfollow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionteamworker") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_var_3 . "' WHERE username='" . $_var_3 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed_archiver") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	}
	C::memory()->clear();
	return $_var_2;
}
function wq_qqlogin_changename_for_uc($_arg_0, $_arg_1)
{
	DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	C::memory()->clear();
}
function wq_qqlogin_changepassword($_arg_0)
{
	global $_G;
	loaducenter();
	uc_user_edit($_G["username"], '', $_arg_0, '', 1);
	$_var_2 = C::t("#wq_qqlogin#wq_qqlogin_member")->update_by_uid($_G["uid"], '', true);
	if ($_var_2) {
		C::memory()->clear();
		return true;
	}
}
function wq_qqlogin_uploadAvatar($_arg_0, $_arg_1)
{
	global $_G;
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	$_arg_1 = wq_qqlogin_save_avatar($_arg_1);
	list($_var_3, $_var_4, $_var_5, $_var_6) = getimagesize($_arg_1);
	if (!$_var_3) {
		return false;
	}
	if ($_var_3 < 10 || $_var_4 < 10 || $_var_5 == 4) {
		return false;
	}
	$_var_7 = array(1 => ".gif", 2 => ".jpg", 3 => ".png");
	$_var_8 = $_var_7[$_var_5];
	if (!$_var_8) {
		$_var_8 = ".jpg";
	}
	$_var_9 = $_G["setting"]["attachdir"];
	$_var_10 = $_var_9 . "./temp/upload" . $_arg_0 . $_var_8;
	file_exists($_var_10) && @unlink($_var_10);
	file_put_contents($_var_10, file_get_contents($_arg_1));
	if (!is_file($_var_10)) {
		return false;
	}
	$_var_11 = "./temp/upload" . $_arg_0 . "big" . $_var_8;
	$_var_12 = "./temp/upload" . $_arg_0 . "middle" . $_var_8;
	$_var_13 = "./temp/upload" . $_arg_0 . "small" . $_var_8;
	$_var_14 = new image();
	if ($_var_14->Thumb($_var_10, $_var_11, 200, 250, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_12, 120, 120, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_13, 48, 48, 2) <= 0) {
		return false;
	}
	$_var_11 = $_var_9 . $_var_11;
	$_var_12 = $_var_9 . $_var_12;
	$_var_13 = $_var_9 . $_var_13;
	$_var_15 = wq_qqlogin_byte2hex(file_get_contents($_var_11));
	$_var_16 = wq_qqlogin_byte2hex(file_get_contents($_var_12));
	$_var_17 = wq_qqlogin_byte2hex(file_get_contents($_var_13));
	$_var_18 = "&avatar1=" . $_var_15 . "&avatar2=" . $_var_16 . "&avatar3=" . $_var_17;
	$_var_19 = wq_qqlogin_uc_api_post_ex("user", "rectavatar", array("uid" => $_arg_0), $_var_18);
	@unlink($_var_10);
	@unlink($_var_11);
	@unlink($_var_12);
	@unlink($_var_13);
	@unlink($_arg_1);
	if ($_var_19 == "<?xml version=\"1.0\" ?><root><face success=\"1\"/></root>") {
		C::t("common_member")->update($_arg_0, array("avatarstatus" => "1"));
		updatecreditbyaction("setavatar");
		return true;
	}
	return false;
}
function wq_qqlogin_save_avatar($_arg_0)
{
	global $_G;
	$_var_2 = DISCUZ_ROOT . "/data/cache/avatarTmp";
	dmkdir($_var_2);
	$_var_3 = $_var_2 . "/" . date("His") . strtolower(random(16)) . ".jpg";
	if ($_G["cache"]["plugin"]["wq_qqlogin"]["function_type"] == "2") {
		$_var_4 = file_get_contents($_arg_0);
	} else {
		$_var_4 = dfsockopen($_arg_0, 0, array(), '', false);
	}
	file_put_contents($_var_3, $_var_4);
	return $_var_3;
}
function wq_qqlogin_byte2hex($_arg_0)
{
	$_var_1 = '';
	$_var_2 = unpack("H*", $_arg_0);
	$_var_2 = str_split($_var_2[1], 2);
	$_var_3 = '';
	foreach ($_var_2 as $_var_4 => $_var_5) {
		$_var_3 = $_var_3 . strtoupper($_var_5);
	}
	return $_var_3;
}
function wq_qqlogin_uc_api_post_ex($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = '')
{
	$_var_4 = $_var_5 = '';
	foreach ($_arg_2 as $_var_6 => $_var_7) {
		$_var_6 = urlencode($_var_6);
		if (is_array($_var_7)) {
			$_var_8 = $_var_9 = '';
			foreach ($_var_7 as $_var_10 => $_var_11) {
				$_var_10 = urlencode($_var_10);
				$_var_8 = $_var_8 . ('' . $_var_9 . '' . $_var_6 . "[" . $_var_10 . "]=" . urlencode(uc_stripslashes($_var_11)));
				$_var_9 = "&";
			}
			$_var_4 = $_var_4 . ($_var_5 . $_var_8);
		} else {
			$_var_4 = $_var_4 . ('' . $_var_5 . '' . $_var_6 . "=" . urlencode(uc_stripslashes($_var_7)));
		}
		$_var_5 = "&";
	}
	$_var_12 = uc_api_requestdata($_arg_0, $_arg_1, $_var_4, $_arg_3);
	return uc_fopen2(UC_API . "/index.php", 500000, $_var_12, '', true, UC_IP, 20);
}
function wq_qqlogin_bind_or_register_credit_reward($_arg_0 = 0, $_arg_1 = "register")
{
	global $_G;
	$_var_3 = wq_qqlogin_get_plang();
	$_var_4 = dunserialize($_G["setting"]["wq_qqlogin"]);
	if ($_var_4["credittype"] && $_var_4["creditnum"] >= 1 && $_arg_0) {
		$_var_5 = C::t("#wq_qqlogin#wq_qqlogin_credit_reward")->fetch_first_by_uid($_arg_0);
		if ($_var_5) {
			return false;
		}
		if ($_arg_1 == "bind") {
			$_var_6 = $_var_3["c071b968308a1763"];
			$_var_7 = $_var_4["bind_creditnum"];
			$_var_8 = $_var_3["abce4d3d516e001e"];
		}
		if ($_arg_1 == "register") {
			$_var_6 = $_var_3["88126841b12579c8"];
			$_var_7 = $_var_4["creditnum"];
			$_var_8 = $_var_3["68907f692fb6eaaa"];
		}
		$_var_9 = array("uid" => $_arg_0, "status" => 1);
		C::t("#wq_qqlogin#wq_qqlogin_credit_reward")->insert($_var_9, false, true);
		$_var_10 = $_G["setting"]["extcredits"][$_var_4["credittype"]]["title"];
		$_var_11 = $_var_6 . $_var_10 . "+" . $_var_7;
		updatemembercount($_arg_0, array($_var_4["credittype"] => $_var_7), 1, '', $_arg_0, '', $_var_8, $_var_11);
	}
}
function wq_qqlogin_get_did_by_name_level($_arg_0, $_arg_1 = "1")
{
	$_var_2 = wq_qqlogin_get_plang();
	if ($_arg_1 == "1") {
		$_var_3[] = $_arg_0 . $_var_2["5197cff968c4abff"];
		$_var_3[] = $_arg_0 . '';
	} else {
		$_var_3[] = $_arg_0 . $_var_2["11c89b033d847a2e"];
		$_var_3[] = $_arg_0 . $_var_2["2dd60837e9236715"];
	}
	return DB::result_first("SELECT name FROM %t WHERE level = %d AND name IN(%n)", array("common_district", $_arg_1, $_var_3));
}
function wq_qqlogin_update_userinfo_by_uid($_arg_0, $_arg_1)
{
	$_var_2 = wq_qqlogin_get_plang();
	$_var_3 = wq_qqlogin_get_did_by_name_level($_arg_1["province"], 1);
	$_var_4 = wq_qqlogin_get_did_by_name_level($_arg_1["city"], 2);
	$_var_5 = $_arg_1["gender"] == $_var_2["ab3948269942da32"] ? 1 : ($_arg_1["gender"] == $_var_2["6a4f3c4c50f40ce1"] ? 2 : 0);
	$_var_6 = array("resideprovince" => $_var_3, "residecity" => $_var_4, "gender" => $_var_5);
	C::t("common_member_profile")->update($_arg_0, $_var_6);
}
function wq_qqlogin_dispose_qq_userinof($_arg_0)
{
	global $_G;
	$_var_2 = wq_qqlogin_get_plang();
	$_arg_0["nickname"] = wq_qqlogin_clear($_arg_0["nickname"]);
	if (strtoupper(CHARSET) == "GBK") {
		foreach ($_arg_0 as $_var_3 => $_var_4) {
			$_arg_0[$_var_3] = diconv($_var_4, "UTF-8");
		}
	}
	$_arg_0["gender"] = $_arg_0["gender"] == $_var_2["ab3948269942da32"] ? 1 : ($_arg_0["gender"] == $_var_2["6a4f3c4c50f40ce1"] ? 2 : 0);
	return $_arg_0;
}
function wq_qqlogin_check_password($_arg_0)
{
	global $_G;
	loaducenter();
	list($_var_2) = uc_user_login($_G["uid"], $_arg_0, 1, 0);
	if ($_var_2 >= 0) {
		return $_var_2;
	}
	return false;
}
function wq_qqlogin_binduser_write_table($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4 = 1, $_arg_5 = 1)
{
	$_var_6 = array("uid" => $_arg_0, "username" => $_arg_1, "chgusername" => $_arg_4, "chgpassword" => $_arg_5, "openid" => $_arg_2, "access_token" => $_arg_3, "dateline" => time());
	C::t("#wq_qqlogin#wq_qqlogin_member")->insert($_var_6);
}
function wq_qqlogin_set_setting($_arg_0)
{
	C::t("common_setting")->update("wq_qqlogin", $_arg_0);
	require_once libfile("function/cache");
	updatecache("setting");
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success";
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}