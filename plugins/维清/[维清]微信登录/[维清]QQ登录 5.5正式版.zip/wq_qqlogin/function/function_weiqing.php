<?php

function get_apptype_v5($_arg_0)
{
}
function get_siteuniqueid_v5()
{
}
function get_key_for_authcode_by_identifier_suid_type_v5($_arg_0, $_arg_1 = '', $_arg_2 = "p")
{
}
function get_key_for_authcode_by_random_v5($_arg_0 = '')
{
}
function wq_validate_v5($_arg_0, $_arg_1 = "p", $_arg_2 = true)
{
	return "success";
}
function get_check_filecontent_by_identifier_type_v5($_arg_0, $_arg_1 = "p")
{
}
function get_siteinfo_by_identifier_type_v5($_arg_0, $_arg_1 = "p", $_arg_2 = true)
{
}
function read_cert_by_identifier_tpye_v5($_arg_0, $_arg_1 = "p")
{
}
function save_cert_by_identifier_content_type_v5($_arg_0, $_arg_1, $_arg_2 = "p")
{
}
function send_error_log_by_siteinfo_v5($_arg_0)
{
}
function send_error_log_by_identifier_type_v5($_arg_0, $_arg_1, $_arg_2)
{
}
function get_cert_content_by_siteinfo_v5($_arg_0)
{
}
function update_cert_content_by_oldcert_v5($_arg_0)
{
}
function validate_check_content($_arg_0, $_arg_1)
{
}
function validate_check_lockfile($_arg_0)
{
	$_var_1 = DISCUZ_ROOT . "./data/sysdata/wq_lock_" . $_arg_0 . ".php";
	validate_check_dir_and_file_writeable($_var_1);
	if (file_exists($_var_1)) {
		$_var_2 = explode("|", file_get_contents($_var_1));
		if (is_array($_var_2) && count($_var_2) == 3 && in_array($_var_2[1], array(30003, 30008)) && $_var_2[2] > time()) {
			validate_showmessage_v5($_var_2[1] . "-0", $_arg_0);
		} else {
			@unlink($_var_1);
		}
	}
}
function validate_write_lockfile($_arg_0, $_arg_1, $_arg_2 = 120)
{
	if (in_array($_arg_0, array(30003, 30008))) {
		$_var_3 = DISCUZ_ROOT . "./data/sysdata/wq_lock_" . $_arg_1 . ".php";
		$_var_4 = time() + $_arg_2;
		$_var_5 = "<?php exit();?>|" . $_arg_0 . "|" . $_var_4 . '';
		file_put_contents($_var_3, $_var_5);
	}
}
function validate_showmessage_v5($_arg_0, $_arg_1, $_arg_2 = '')
{
}
function wq_validate_addcondition_v5($_arg_0)
{
}
function validate_check_dir_and_file_writeable($_arg_0 = '')
{
	$_var_1 = DISCUZ_ROOT . "./data/sysdata";
	if (!is_dir($_var_1) && !dmkdir($_var_1)) {
		validate_showmessage_v5(0, '', "dir");
	}
	$_var_2 = validate_check_dir_writeable($_var_1);
	if (!$_var_2) {
		validate_showmessage_v5(0, '', "dir");
	}
	if ($_arg_0 !== '') {
		clearstatcache();
		if (file_exists($_arg_0) && !is_writable($_arg_0)) {
			validate_showmessage_v5(0, '', "file");
		}
	}
}
function validate_check_dir_writeable($_arg_0)
{
	$_var_1 = false;
	if (!is_dir($_arg_0)) {
		@mkdir($_arg_0, 511);
	}
	if (is_dir($_arg_0)) {
		if ($_var_2 = @fopen('' . $_arg_0 . "/wqtest.txt", "w")) {
			@fclose($_var_2);
			@unlink('' . $_arg_0 . "/wqtest.txt");
			$_var_1 = true;
		} else {
			$_var_1 = false;
		}
	}
	return $_var_1;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
