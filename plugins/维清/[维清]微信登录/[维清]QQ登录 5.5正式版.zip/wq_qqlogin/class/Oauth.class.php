<?php

/** PHP SDK
 * @version 2.0.0
 * @author connect@qq.com
 * @copyright ? 2013, Tencent Corporation. All rights reserved.
 */
class Oauth {

	const VERSION = "2.0";
	const GET_AUTH_CODE_URL = "https://graph.qq.com/oauth2.0/authorize";
	const GET_ACCESS_TOKEN_URL = "https://graph.qq.com/oauth2.0/token";
	const GET_OPENID_URL = "https://graph.qq.com/oauth2.0/me";
	const GET_USER_INFO_URL = "https://graph.qq.com/user/get_user_info";
	const QQ_REDIRECT = "#qq_redirect";

	function __construct($appId = '', $appKey = '') {
		global $_G;

		$appId = !empty($appId) ? $appId : $_G['cache']['plugin']['wq_qqlogin']['appid'];
		$appKey = !empty($appKey) ? $appKey : $_G['cache']['plugin']['wq_qqlogin']['appkey'];

		$this->setAppkey($appId, $appKey);

		if(!$this->_appid || !$this->_appKey) {
			throw new Exception('AppId/AppKey Invalid', __LINE__);
		}
	}

	protected function setAppKey($appId, $appKey) {
		$this->_appid = $appId;
		$this->_appKey = $appKey;
	}

	public function getOAuthAuthorizeURL($redirect_uri) {
		$state = md5(FORMHASH);

		$params = array(
			"response_type" => "code",
			"client_id" => $this->_appid,
			"redirect_uri" => $redirect_uri,
			"state" => $state,
			"scope" => get_user_info,
		);

		return self::GET_AUTH_CODE_URL . '?' . http_build_query($params) . self::QQ_REDIRECT;
	}

	public function getAccessToken($redirect_uri, $code) {
		global $_G;

		$params = array(
			"grant_type" => "authorization_code",
			"client_id" => $this->_appid,
			"redirect_uri" => $redirect_uri,
			"client_secret" => $this->_appKey,
			"code" => $code
		);


		$response = $this->_dfsockopen(self::GET_ACCESS_TOKEN_URL . '?', $params) . self::QQ_REDIRECT;
		$response = $this->rtrim_response($response);


		if(strpos($response, "callback") !== false) {

			$lpos = strpos($response, "(");
			$rpos = strrpos($response, ")");
			$response = substr($response, $lpos + 1, $rpos - $lpos - 1);
			$result = json_decode($response, true);

			if(isset($result['error'])) {
				throw new Exception($result['error'], $result['error_description']);
			}
		}

		$result = array();
		parse_str($response, $result);

		return $result['access_token'];
	}

	private static function _dfsockopen($api, $get = array(), $post = array()) {
		global $_G;
		if($_G['cache']['plugin']['wq_qqlogin']['function_type'] == '2') {
			return file_get_contents($api . http_build_query($get));
		} else {
			return dfsockopen($api . http_build_query($get), 0, $post, '', false);
		}
	}

	public function getOpenid($access_token) {

		$params = array(
			"access_token" => $access_token
		);

		$response = $this->_dfsockopen(self::GET_OPENID_URL . '?', $params) . self::QQ_REDIRECT;
		$response = $this->rtrim_response($response);

		if(strpos($response, "callback") !== false) {

			$lpos = strpos($response, "(");
			$rpos = strrpos($response, ")");
			$response = substr($response, $lpos + 1, $rpos - $lpos - 1);
		}

		$result = json_decode($response, true);

		if(isset($result['error'])) {
			throw new Exception($result['error'], $result['error_description']);
		}

		return $result['openid'];
	}

	function getUserInfo($openid, $access_token) {
		$params = array(
			"oauth_consumer_key" => $this->_appid,
			"openid" => $openid,
			"access_token" => $access_token
		);

		$response = $this->_dfsockopen(self::GET_USER_INFO_URL . '?', $params) . self::QQ_REDIRECT;
		$response = $this->rtrim_response($response);

		$result = json_decode($response, true);

		if(isset($result['ret']) && $result['ret'] == 0) {
			return $result;
		} else {
			throw new Exception($result['ret'], $result['msg']);
		}
	}

	function rtrim_response($response) {
		return rtrim($response, "#qq_redirect");
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>