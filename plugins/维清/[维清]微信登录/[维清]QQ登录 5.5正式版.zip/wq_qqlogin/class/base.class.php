<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_qqlogin_base {

	public $lang;
	public $setting;

	function __construct() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_qqlogin/config/loadfunc.php';

		$this->lang = wq_loadlang('wq_qqlogin');
		$this->setting = wq_loadsetting('wq_qqlogin');

		include_once template('wq_qqlogin:module');
		if($_G['setting']['bbclosed']) {
			return;
		}
		$this->allow = true;
	}

	function common_base() {
		global $_G;

		if(!$_G['uid'] && !empty($_G['cookie']['wq_qqlogin_auth_hash'])) {
			$openid = authcode($_G['cookie']['wq_qqlogin_auth_hash']);
			$user = C::t("#wq_qqlogin#wq_qqlogin_guest")->fetch_first_by_openid($openid);
			if($user) {
				$_G['connectguest'] = 1;
				$username = !empty($user['nickname']) ? $user['nickname'] : 'QQ_' . substr($openid, -6);
				$_G['setting']['cacheindexlife'] = 0;
				$_G['setting']['cachethreadlife'] = 0;

				$groupid = $this->setting['guest_groupid'] ? $this->setting['guest_groupid'] : $_G['setting']['newusergroupid'];
			}
			setglobal('member', array('uid' => 0, 'username' => $username, 'adminid' => 0, 'groupid' => $groupid, 'credits' => 0, 'timeoffset' => 9999));
			setglobal('groupid', getglobal('groupid', 'member'));
			loadcache('usergroup_' . $_G['member']['groupid']);
		}

		if($this->allow && !$_G['uid'] && !defined('IN_MOBILE')) {
			$_G['setting']['pluginhooks']['global_login_text'] = wq_qqlogin_login_bar();
		}
	}

	function wq_qqlogin_get_uid_isbind() {
		global $_G;
		$isbind = false;
		if($_G['uid']) {
			$user = C::t("#wq_qqlogin#wq_qqlogin_member")->fetch_first_by_uid($_G['uid']);
			if($user) {
				$isbind = true;
			}
		}
		return $isbind;
	}

	function wq_qqlogin_login_msg($params) {
		global $_G;

		if($_G['connectguest'] && $params['param'][3]['login'] == 1) {
			if($_G['inajax']) {
				showmessage($this->lang['a9f575cd4011fa31']);
			} else {
				dheader('location: ' . $_G['siteurl'] . 'plugin.php?id=wq_qqlogin&mod=login&ac=bind');
			}
		}
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>