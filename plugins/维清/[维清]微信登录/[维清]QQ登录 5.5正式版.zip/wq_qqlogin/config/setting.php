<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_qqlogin/config/setting_base.php';
$setting['creditnum'] = $setting['creditnum'] < 0 ? 0 : $setting['creditnum'];
$setting['bind_creditnum'] = $setting['bind_creditnum'] < 0 ? 0 : $setting['bind_creditnum'];
$setting['admincp_perpage'] = $setting['admincp_perpage'] < 0 || $setting['admincp_perpage'] > 20 ? 20 : $setting['admincp_perpage'];
$setting['admincp_perpage'] = $setting['admincp_perpage'] < 0 || $setting['admincp_perpage'] > 20 ? 20 : $setting['admincp_perpage'];

?>