<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: loadfunc.php 2018-7-30 23:49:48Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile("function_common", "plugin/wq_qqlogin/function");

if(defined('IN_ADMINCP')) {
	require_once libfile("function_admincp", "plugin/wq_qqlogin/function");
}
//dis'.'m.t'.'ao'.'bao.com
?>