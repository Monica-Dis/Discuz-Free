<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$setting = $_G['cache']['plugin']['wq_qqlogin'];
$setting['appid'] = trim($setting['appid']);
$setting['appkey'] = trim($setting['appkey']);
$setting['qq_domain'] = trim($setting['qq_domain']);
$setting['guest_groupid'] = intval($setting['guest_groupid']);
$setting['is_update_userinfo'] = intval($setting['is_update_userinfo']);
$setting['function_type'] = intval($setting['function_type']);
$setting['is_bind_exist_user'] = intval($setting['is_bind_exist_user']);
$setting['register_email'] = intval($setting['register_email']);
$setting['newusergroupid'] = intval($setting['newusergroupid']);
$setting['bind_is_site'] = intval($setting['bind_is_site']);
$setting['disableregrule'] = intval($setting['disableregrule']);
$setting['pwd_strlen'] = intval($setting['pwd_strlen']);
$setting['pwd_is_numeric'] = intval($setting['pwd_is_numeric']);
$setting['pwd_is_english'] = intval($setting['pwd_is_english']);
$setting['credittype'] = intval($setting['credittype']);
$setting['creditnum'] = intval($setting['creditnum']);
$setting['bind_creditnum'] = intval($setting['bind_creditnum']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['bind_is_write_password'] = intval($setting['bind_is_write_password']);
$setting['is_open_unbind'] = intval($setting['is_open_unbind']);

?>