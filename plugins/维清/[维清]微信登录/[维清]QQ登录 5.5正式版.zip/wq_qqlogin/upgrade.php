<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_qqlogin/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '<script src="' . STATURL . '&action=' . str_replace('plugin', '', $operation) . '&params=' . $paramsbase . '&md5hash=' . $md5hash . '" type="text/javascript"></script>';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':

		$sql = <<<EOF

EOF;
		runquery($sql);
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//dis'.'m.t'.'ao'.'bao.com
?>