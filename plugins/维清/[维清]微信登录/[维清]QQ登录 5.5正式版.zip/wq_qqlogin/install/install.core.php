<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success";
	if ($_var_0 == "success") {
		$_var_1 = "CREATE TABLE IF NOT EXISTS `pre_wq_qqlogin_guest` (\n" . " `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `nickname` varchar(100) NOT NULL,\n" . " `gender` tinyint(1) unsigned NOT NULL,\n" . " `figureurl_qq` text NOT NULL,\n" . " `province` varchar(10) NOT NULL,\n" . " `city` varchar(10) NOT NULL,\n" . " `openid` varchar(32) NOT NULL,\n" . " `access_token` varchar(32) NOT NULL,\n" . " PRIMARY KEY (`id`),\n" . " KEY `nickname` (`nickname`),\n" . " KEY `gender` (`gender`),\n" . " KEY `openid` (`openid`),\n" . " KEY `access_token` (`access_token`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_qqlogin_member` (\n" . " `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `uid` int(10) unsigned NOT NULL,\n" . " `username` varchar(40) NOT NULL,\n" . " `chgusername` tinyint(1) unsigned NOT NULL,\n" . " `chgpassword` tinyint(1) unsigned NOT NULL,\n" . " `openid` varchar(40) NOT NULL,\n" . " `access_token` varchar(32) NOT NULL,\n" . " `dateline` int(10) unsigned NOT NULL,\n" . " PRIMARY KEY (`bid`),\n" . " KEY `uid` (`uid`),\n" . " KEY `username` (`username`),\n" . " KEY `chgusername` (`chgusername`),\n" . " KEY `chgpassword` (`chgpassword`),\n" . " KEY `openid` (`openid`),\n" . " KEY `access_token` (`access_token`),\n" . " KEY `dateline` (`dateline`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_qqlogin_credit_reward` (\n" . " `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `status` tinyint(1) unsigned NOT NULL,\n" . " PRIMARY KEY (`uid`),\n" . " KEY `status` (`status`)\n" . ") ENGINE=MyISAM;\n";
		runquery($_var_1);
	} else {
		echo "Access Denied Weiqing";
		return 0;
	}
