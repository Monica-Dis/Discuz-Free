<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: close.inc.php 2017-8-28 19:28:41Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
DB::update('common_plugin', array("available" => 0), array("identifier" => "qqconnect"));
require_once libfile("function/cache");
updatecache('setting');
$message = "&#x7CFB;&#x7EDF;QQ&#x4E92;&#x8054;&#x63D2;&#x4EF6;&#x5173;&#x95ED;&#x6210;&#x529F;&#xFF01;";
cpmsg($message, 'action=plugins', 'succeed');

?>