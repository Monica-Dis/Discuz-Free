<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2017-4-27 20:47:16Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/wq_qqlogin/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_qqlogin_member`;
DROP TABLE IF EXISTS `pre_wq_qqlogin_guest`;
DROP TABLE IF EXISTS `pre_wq_qqlogin_credit_reward`;
EOF;
		runquery($sql);

		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_qqlogin.php");

		require_once DISCUZ_ROOT . './source/plugin/wq_qqlogin/config/loadfunc.php';
		wq_rmdir(DISCUZ_ROOT . './data/cache/wq_qqlogin/');
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_qqlogin.php");
		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//dis'.'m.t'.'ao'.'bao.com
?>