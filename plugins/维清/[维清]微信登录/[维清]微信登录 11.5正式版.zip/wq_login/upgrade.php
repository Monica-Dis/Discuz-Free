<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_login/config/config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_login/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '<script src="' . STATURL . '&action=' . str_replace('plugin', '', $operation) . '&params=' . $paramsbase . '&md5hash=' . $md5hash . '" type="text/javascript"></script>';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':
		$sql = "CREATE TABLE IF NOT EXISTS `pre_wq_login_posts_temporary` (\n" .
			" `tid` int(10) unsigned NOT NULL,\n" .
			" `dateline` int(10) unsigned NOT NULL,\n" .
			" PRIMARY KEY (`tid`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_login_posts_temporary1` (\n" .
			"  `pid` int(10) unsigned NOT NULL,\n" .
			"  `dateline` int(10) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`pid`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_login_credit_reward` (\n" .
			"  `uid` int(10) unsigned NOT NULL,\n" .
			"  `status` tinyint(1) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`uid`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_login_code_cache` (\n" .
			"  `code` char(32) NOT NULL,\n" .
			"  `info` text NOT NULL,\n" .
			"  `dateline` int(10) unsigned NOT NULL,\n" .
			"  PRIMARY KEY (`code`)\n" .
			") ENGINE=MyISAM;\n" .
			"CREATE TABLE IF NOT EXISTS `pre_wq_login_templatemsg_log` (\n" .
			" `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" .
			" `uid` int(10) unsigned NOT NULL,\n" .
			" `openid` varchar(32) NOT NULL,\n" .
			" `errcode` int(10) unsigned NOT NULL,\n" .
			" `dateline` int(10) unsigned NOT NULL,\n" .
			" `type` tinyint(1) unsigned NOT NULL,\n" .
			" PRIMARY KEY (`id`)\n" .
			") ENGINE=MyISAM;\n";
		runquery($sql);

		$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_login_member'));
		while($row = DB::fetch($query)) {
			$col_field[] = $row['Field'];
		}
		if(!in_array('username', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `username` varchar(60) NOT NULL;";
			DB::query($sql);
		}

		if(!in_array('isfocus', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `isfocus` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}

		if(!in_array('weixinname', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `weixinname` varchar(150) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('sex', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `sex` tinyint(1) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('authorizetime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `authorizetime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('dateline', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `dateline` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('area', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `area` varchar(150) NOT NULL;";
			DB::query($sql);
		}

		if(!in_array('notietime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `notietime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('pmlasttime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `pmlasttime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('pmtime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `pmtime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('sendtime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `sendtime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('app_id', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `app_id` varchar(100) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('app_token', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `app_token` varchar(100) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('tokentime', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `tokentime` int(10) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('session_key', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `session_key` varchar(100) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('wxavatar', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `wxavatar` varchar(255) NOT NULL;";
			DB::query($sql);
		}
		if(!in_array('logoutstatus', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `logoutstatus` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if(in_array('notauto', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " DROP COLUMN `notauto`";
			DB::query($sql);
		}

		if(!in_array('notauth', $col_field)) {
			$sql = "ALTER TABLE " . DB::table('wq_login_member') . " ADD `notauth` tinyint(1) unsigned NOT NULL;";
			DB::query($sql);
		}
		if($_GET['fromversion'] < 6.8) {
			wq_login_cron_create('wq_login');
		}
		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		wq_clear_htmtpl("wq_login");
		$finish = TRUE;
		break;
}
//dis'.'m.t'.'ao'.'bao.com
?>