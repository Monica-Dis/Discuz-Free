<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: weiqingini.php 2015-11-4 23:00:57Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$systemfile = array(
	wq_libfile('function/cache'),
	wq_libfile('function/member'),
	wq_libfile('function/stat'),
	wq_libfile('cache/userstats', 'function'),
);

function wq_libfile($libname, $folder = '') {
	$libpath = '/source/' . $folder;
	if(strstr($libname, '/')) {
		list($pre, $name) = explode('/', $libname);
		$path = "{$libpath}/{$pre}/{$pre}_{$name}";
	} else {
		$path = "{$libpath}/{$libname}";
	}
	return preg_match('/^[\w\d\/_]+$/i', $path) ? DISCUZ_ROOT . $path . '.php' : false;
}
//dis'.'m.t'.'ao'.'bao.com
?>