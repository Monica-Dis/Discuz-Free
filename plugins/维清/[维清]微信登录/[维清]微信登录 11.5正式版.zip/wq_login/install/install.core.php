<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success";
	if ($_var_0 == "success") {
		$_var_1 = "CREATE TABLE IF NOT EXISTS `pre_wq_login_authcode` (\n" . "  `sid` char(6) NOT NULL,\n" . "  `code` int(10) unsigned NOT NULL,\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',\n" . "  `createtime` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`sid`),\n" . "  KEY `code` (`code`),\n" . "  KEY `createtime` (`createtime`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_code_cache` (\n" . "  `code` char(32) NOT NULL,\n" . "  `info` text NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`code`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_credit_reward` (\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `status` tinyint(1) unsigned NOT NULL,\n" . "  KEY `uid` (`uid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_member` (\n" . "  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `openid` varchar(32) NOT NULL,\n" . "  `unionid` varchar(32) NOT NULL,\n" . "  `access_token` text NOT NULL,\n" . "  `chgusername` tinyint(1) unsigned NOT NULL,\n" . "  `chgpassword` tinyint(1) unsigned NOT NULL,\n" . "  `username` varchar(60) NOT NULL,\n" . "  `weixinname` varchar(150) NOT NULL,\n" . "  `sex` tinyint(1) unsigned NOT NULL,\n" . "  `authorizetime` int(10) unsigned NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  `area` varchar(150) NOT NULL,\n" . "  `isfocus` tinyint(1) unsigned NOT NULL,\n" . "  `sendtime` int(10) unsigned NOT NULL,\n" . "  `notietime` int(10) unsigned NOT NULL,\n" . "  `pmtime` int(10) unsigned NOT NULL,\n" . "  `pmlasttime` int(10) unsigned NOT NULL,\n" . "  `app_id` varchar(100) NOT NULL,\n" . "  `app_token` varchar(100) NOT NULL,\n" . "  `tokentime` int(10) unsigned NOT NULL,\n" . "  `session_key` varchar(100) NOT NULL,\n" . "  `wxavatar` varchar(255) NOT NULL,\n" . "  `logoutstatus` tinyint(1) unsigned NOT NULL,\n" . "  `notauth` tinyint(1) unsigned NOT NULL,\n" . "  PRIMARY KEY (`id`),\n" . "  KEY `uid` (`uid`),\n" . "  KEY `openid` (`openid`),\n" . "  KEY `unionid` (`unionid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_posts_temporary` (\n" . "  `tid` int(10) unsigned NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  KEY `tid` (`tid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_posts_temporary1` (\n" . "  `pid` int(10) unsigned NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`pid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_login_templatemsg_log` (\n" . "  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `openid` varchar(32) NOT NULL,\n" . "  `errcode` int(10) unsigned NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  `type` tinyint(1) unsigned NOT NULL,\n" . "  PRIMARY KEY (`id`)\n" . ") ENGINE=MyISAM;\n";
		runquery($_var_1);
	} else {
		echo "Access Denied Weiqing";
		return 0;
	}
