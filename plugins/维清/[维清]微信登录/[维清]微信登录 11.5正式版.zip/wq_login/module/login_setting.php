<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loaducenter();

$user = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);

if($_GET['ac'] == 'username') {
	if($user['chgusername']) {
		showmessage($Plang['e7f7423a8825b50f']);
	}

	if($_G['uid'] && submitcheck('confirmsubmit')) {
		$newusername = addslashes(dhtmlspecialchars(trim($_GET['newusername'])));

		if(empty($newusername)) {
			showmessage($Plang['be91a21ec09cb236']);
		} elseif(strlen($newusername) < 3) {
			showmessage($Plang['b5396a0e74d0f722']);
		} elseif(strlen($newusername) > 15) {
			showmessage($Plang['ebdc287145a7906f']);
		}

		$check = uc_user_checkname($newusername);
		if($check != 1) {
			$code = str_replace("-", "", $check);
			showmessage($Plang['username_' . $code]);
		}

		wq_wechat_changeusername($_G['username'], $newusername);
		wq_wechat_changename_for_uc($_G['username'], $newusername);

		$re = C::t('#wq_login#wq_login_member')->update_by_uid($_G['uid']);

		if($re) {
			sendWechatTemplateTips($setting, 4);
		}
		showmessage($Plang['78b1255b087df664'], defined('IN_MOBILE') ? 'plugin.php?id=wq_login&mod=user' : dreferer());
	}
} elseif($_GET['ac'] == 'password') {

	if($user['chgpassword']) {
		showmessage($Plang['0b00660886376523']);
	}
	if($_G['uid'] && submitcheck('confirmsubmit')) {
		if(!$_GET['newpassword']) {
			showmessage($Plang['7cdd702917562488']);
		}

		if(strlen($_GET['newpassword']) < $setting['pwd_strlen']) {
			showmessage(sprintf($Plang['7d48c06ad19ca737'], $setting['pwd_strlen']));
		}
		if(!$setting['pwd_is_numeric'] && is_numeric($_GET['newpassword'])) {
			showmessage($Plang['a9e19d6d6b587830']);
		}
		if(!$setting['pwd_is_english'] && preg_match("/[a-z]+/i", $_GET['newpassword']) && !preg_match("/[0-9]+/i", $_GET['newpassword'])) {
			showmessage($Plang['b9b81451d3a70378']);
		}

		if($_GET['newpassword'] != $_GET['confirmpassword']) {
			showmessage($Plang['5a04f36409b58f7a']);
		}

		$re = wq_wechat_changepassword($_GET['newpassword']);

		if($re) {
			sendWechatTemplateTips($setting, 5);
		}
		showmessage($Plang['668259cd833b1be4'], defined('IN_MOBILE') ? 'plugin.php?id=wq_login&mod=user' : dreferer());
	}
}
include_once template('wq_login:setting');

?>