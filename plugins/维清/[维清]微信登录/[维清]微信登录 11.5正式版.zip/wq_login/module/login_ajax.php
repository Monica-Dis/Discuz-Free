<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_login/config/filter_biaoqing.php';

$allowop = array('applogin');
$op = $_GET['op'];

if(!in_array($op, $allowop)) {
	$op = 'applogin';
}

$referer = dreferer();
if($op == 'applogin') {

	loaducenter();
	$userinfo = $_GET;

	if($_GET['state'] != FORMHASH) {
		showmessage($Plang['login_get_access_token_failed'], $referer);
	}


	$openid = trim($userinfo['openid']);
	$unionid = trim($userinfo['unionid']);

	$user = '';
	if($unionid) {
		$tem_user = C::t('#wq_login#wq_login_member')->fetch_first_by_unionid($unionid);
	}

	if(!$tem_user) {
		$user = C::t('#wq_login#wq_login_member')->fetch_first_by_openid($openid);
	} else {
		$user = $tem_user;
	}

	if($user && !$user['unionid'] && $unionid) {
		C::t('#wq_login#wq_login_member')->update($user['id'], array('unionid' => $unionid));
	}


	if(empty($user)) {
		$userinfo['nickname'] = wq_login_clear($userinfo['nickname']);
		if(CHARSET == 'gbk') {
			foreach($userinfo as $key => $value) {
				$userinfo[$key] = diconv($value, 'UTF-8');
			}
		}
		$weixinname = trim($userinfo['nickname']);

		$userinfo['nickname'] = wq_wechat_process_username($userinfo['nickname']);

		if($setting['open_register']) {
			$wechat_register = wq_wechat_register($userinfo['nickname']);
			$uid = $wechat_register[0];
			$username = $wechat_register[1];

			if(!$uid) {
				showmessage($Plang['register_error'], $referer);
			}

			wq_wechat_uploadAvatar($uid, $userinfo['headimgurl']);

			$param = array('bbname' => $_G['setting']['bbname'], 'usergroup' => $_G['group']['grouptitle']);

			C::t('#wq_login#wq_login_member')->insert(array('uid' => $uid, 'username' => $username, 'openid' => $openid, 'unionid' => $unionid, 'access_token' => $access_token, 'app_id' => $setting['appid'], 'weixinname' => $weixinname, 'sex' => $userinfo['sex'], 'authorizetime' => TIMESTAMP, 'dateline' => TIMESTAMP, 'area' => $userinfo['province'] . $userinfo['city']));


			wq_login_bind_or_register_credit_reward($uid, $setting);

			wq_wechat_update_userinfo_by_uid($uid, $userinfo);


			showmessage('register_succeed', $referer, $param);
		} else {
			$register_tips = $setting['open_oneself_username'] ? $Plang['register'] : $Plang['one_key_register'];
			$tml_param = array(
				'referer' => $referer,
				'nickname' => $userinfo['nickname'],
				'sex' => $userinfo['sex'],
				'province' => $userinfo['province'],
				'city' => $userinfo['city'],
				'headimgurl' => $userinfo['headimgurl'],
				'openid' => $openid,
				'unionid' => $unionid,
				'access_token' => $access_token,
				'weixinname' => $weixinname,
				'checkcode' => $checkcode
			);
			include_once template('wq_login:wechat_login_bindorregister');
		}
	} else {
		$data = array('dateline' => TIMESTAMP, 'access_token' => $access_token);

		if($setting['update_userinfo']) {
			wq_wechat_update_userinfo_by_uid($user['uid'], $userinfo);

			$data['sex'] = $userinfo['sex'];
			$data['weixinname'] = $userinfo['nickname'];
			$data['area'] = $userinfo['province'] . $userinfo['city'];
		}

		C::t('#wq_login#wq_login_member')->update($user['id'], $data);

		$login = wq_wechat_login($user);

		if(!$login) {
			showmessage($Plang['login_error'], $referer);
		}

		$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);
		C::t('common_member_status')->update($user['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

		$ucsynlogin = '';
		if($_G['setting']['allowsynlogin']) {
			$ucsynlogin = uc_user_synlogin($_G['uid']);
		}


		showmessage($setting['login_hint'] ? $setting['login_hint'] : 'login_succeed', $referer, $param, array('extrajs' => $ucsynlogin));
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>