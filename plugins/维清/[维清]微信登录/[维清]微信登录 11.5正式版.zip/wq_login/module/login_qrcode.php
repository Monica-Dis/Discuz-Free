<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

wq_show_qrcode();

?>