<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
$user = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);
if(!$user['chgpassword']) {
	showmessage($Plang['06e6604c412b1f39']);
}
if(submitcheck('confirmsubmit')) {

	if(!$setting['is_open_unbind']) {
		showmessage($Plang['0ab0a3c08e9ad0ab']);
	}

	if(!$_GET['passwordconfirm'] && $setting['bind_is_write_password'] == 1) {
		showmessage($Plang['bda5051be3094609']);
	}
	if(!$setting['bind_is_write_password'] || wq_login_check_password($_GET['passwordconfirm'])) {
		sendWechatTemplateTips($setting, 3);
		wq_wechat_unbind_user();
		showmessage($Plang['16f7a468fd1793a9'], './');
	} else {
		showmessage('login_password_invalid');
	}
} else {
	include_once template('wq_login:tpl_login_unbind');
}
//dis'.'m.t'.'ao'.'bao.com
?>