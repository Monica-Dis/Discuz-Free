<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$param = $_GET;
if(!submitcheck('confirmsubmit') || !in_array($param['ac'], array('register', 'bind'))) {
	exit('Access Denied');
}

$register_tips = $setting['open_oneself_username'] ? $Plang['register'] : $Plang['one_key_register'];

loaducenter();
if($param['ac'] == 'register') {
	if(!$setting['open_oneself_username'] || $param['oneselfsubmit']) {
		$user = C::t('#wq_login#wq_login_member')->fetch_first_by_openid($param['openid']);
		if($user) {
			showmessage($Plang['username_in_bind']);
		}

		if($param['oneselfsubmit']) {
			$username = $param['nickname'];
			$pwd = $param['pwd'];
			if(intval(C::t('common_member')->fetch_uid_by_username(trim($param['nickname'])))) {
				showmessage('profile_username_duplicate');
			}
			if($pwd && strlen($pwd) < $setting['pwd_strlen']) {
				showmessage(sprintf($Plang['7d48c06ad19ca737'], $setting['pwd_strlen']));
			}
			if(!$setting['pwd_is_numeric'] && $pwd && is_numeric($pwd)) {
				showmessage($Plang['a9e19d6d6b587830']);
			}

			if(!$setting['pwd_is_english'] && $pwd && preg_match("/[a-z]+/i", $pwd) && !preg_match("/[0-9]+/i", $pwd)) {
				showmessage($Plang['b9b81451d3a70378']);
			}
		} else {
			$username = wq_wechat_process_username($param['weixinname']);
			$pwd = '';
		}

		$email = '';
		if($setting['register_email']) {
			$email = strtolower(trim($param['email']));
			wq_wechat_checkemail($email);
		}

		$wechat_register = wq_wechat_register($username, 0, $pwd, $email);
		$uid = $wechat_register[0];
		$username = $wechat_register[1];

		if(!$uid) {
			showmessage($Plang['register_error'], $param['referer']);
		}

		wq_wechat_uploadAvatar($uid, $param['headimgurl']);

		$tem_param = array('bbname' => $_G['setting']['bbname'], 'usergroup' => $_G['group']['grouptitle']);
		$data = array(
			'uid' => $uid,
			'username' => $username,
			'openid' => $param['openid'],
			'unionid' => $param['unionid'],
			'access_token' => $param['access_token'],
			'weixinname' => $param['weixinname'],
			'sex' => $param['sex'],
			'authorizetime' => TIMESTAMP,
			'dateline' => TIMESTAMP,
			'area' => $param['province'] . $param['city'],
			'chgusername' => '1'
		);
		if($pwd) {
			$data['chgpassword'] = '1';
		}
		C::t('#wq_login#wq_login_member')->insert($data);

		if($appbyme_app) {
			wq_login_common_check_app($uid, $param['unionid']);
		}
		if($magapp) {
			wq_login_common_check_app($uid, $param['unionid'], 'magapp', $setting['appid']);
		}
		if($qianfan_app) {
			wq_login_common_check_app($uid, $param['unionid'], 'qianfanapp', '', $username);
		}



		wq_wechat_update_code_status($param['checkcode']);
		$userinfo = array(
			'province' => $param['province'],
			'city' => $param['city'],
			'sex' => $param['sex']
		);
		wq_wechat_update_userinfo_by_uid($uid, $userinfo);

		wq_login_bind_or_register_credit_reward($uid, $setting);

		$json = sendWechatTemplateTips($setting, 0);
		goto_subscribe($json, $_G['cookie']['wq_login_referer']);

		showmessage('register_succeed', $_G['cookie']['wq_login_referer'], $tem_param);
	} else {
		$select = 'oneself';
		include_once template('wq_login:wechat_login_bindorregister');
	}
} else {
	if($param['bindsubmit']) {
		$username = trim($param['username']);
		$uid = intval(C::t('common_member')->fetch_uid_by_username($username));
		if(!$uid) {
			showmessage($Plang['username_empty']);
		}

		list($result) = uc_user_login($username, trim($param['pwd']), 0, 1, $param['questionid'], $param['answer']);
		if($result < 0) {
			$rmsg = $result == '-3' ? (!$param['questionid'] || !$param['answer'] ? 'login_question_empty' : 'login_question_invalid') : 'login_password_invalid';
			showmessage($rmsg);
		}
		$user = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($uid);
		if($user) {
			showmessage($Plang['username_in_bind']);
		}
		$data = array(
			'uid' => $uid,
			'username' => $username,
			'openid' => $param['openid'],
			'access_token' => $param['access_token'],
			'unionid' => $param['unionid'],
			'weixinname' => $param['weixinname'],
			'sex' => $param['sex'],
			'authorizetime' => TIMESTAMP,
			'dateline' => TIMESTAMP,
			'area' => $param['area'] . $param['city'],
			'chgusername' => '1',
			'chgpassword' => '1',
		);
		C::t('#wq_login#wq_login_member')->insert($data);

		if($appbyme_app) {
			wq_login_common_check_app($uid, $param['unionid']);
		}
		if($magapp) {
			wq_login_common_check_app($uid, $param['unionid'], 'magapp', $setting['appid']);
		}
		if($qianfan_app) {
			wq_login_common_check_app($uid, $param['unionid'], 'qianfanapp', '', $username);
		}


		if($setting['update_userinfo']) {
			$userinfo = array(
				'province' => $param['area'],
				'city' => $param['city'],
				'sex' => $param['sex']
			);
			wq_wechat_update_userinfo_by_uid($uid, $userinfo);
		}

		$login = wq_wechat_login($data);

		if(!$login) {
			showmessage($Plang['login_error'], $param['referer']);
		}

		$tem_param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);
		C::t('common_member_status')->update($uid, array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

		$ucsynlogin = '';
		if($_G['setting']['allowsynlogin']) {
			$ucsynlogin = uc_user_synlogin($uid);
		}

		wq_login_bind_or_register_credit_reward($uid, $setting, 'bind');

		$json = sendWechatTemplateTips($setting, 2);
		goto_subscribe($json, $_G['cookie']['wq_login_referer']);


		$json = sendWechatTemplateTips($setting, 1);
		goto_subscribe($json, $_G['cookie']['wq_login_referer']);

		wq_wechat_update_code_status($param['checkcode']);

		showmessage($setting['login_hint'] ? $setting['login_hint'] : 'login_succeed', $_G['cookie']['wq_login_referer'], $tem_param, array('extrajs' => $ucsynlogin));
	} else {
		$select = 'bind';
		include_once template('wq_login:wechat_login_bindorregister');
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>