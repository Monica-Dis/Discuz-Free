<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: lightapp_api.php 2015-1-30 12:52:33Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(submitcheck("jssignsubmit")) {
	include_once DISCUZ_ROOT . './source/plugin/wq_login/config/config.php';
	include_once DISCUZ_ROOT . './source/plugin/wq_login/class/jssdk.class.php';

	$url = trim($_GET['pageurl']);

	$jssdk = new WQJSSDK($setting['appid'], $setting['appsecret'], $url);
	$signPackage = $jssdk->GetSignPackage();

	$data = array('errcode' => '-1');

	if($signPackage['Ticket']) {

		$data = get_data_for_jssdk($signPackage);

		echo json_encode($data);
		exit();
	}
} else {
	exit('Access Denied');
}
//dis'.'m.t'.'ao'.'bao.com
?>