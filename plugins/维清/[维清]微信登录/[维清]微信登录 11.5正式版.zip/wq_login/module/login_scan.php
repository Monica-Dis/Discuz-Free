<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(isset($_GET['check'])) {
	$code = authcode(base64_decode($_GET['check']), 'DECODE', $_G['config']['security']['authkey']);
	$echostr = wq_wechat_check_code_status($code);
	if(!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
		ob_start();
	}
	if($echostr === 'done') {
		C::t('#wq_login#wq_login_authcode')->delete($authcode['sid']);
	}
	include template('common/header_ajax');
	echo $echostr;
	include template('common/footer_ajax');
	exit;
} else {
	if(defined('IN_MOBILE') && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false) {
		showmessage($Plang['711d306f542920c5']);
	}

	if($_G['uid'] && submitcheck('confirmsubmit')) {
		if(!$_GET['passwordconfirm'] && $setting['bind_is_write_password'] == 1) {
			showmessage($Plang['bda5051be3094609']);
		}

		if(!$setting['bind_is_write_password'] || $result = wq_login_check_password($_GET['passwordconfirm'])) {
			dsetcookie('qrauth', base64_encode(authcode($result, 'ENCODE', $_G['config']['security']['authkey'], 300)));
			if(defined('IN_MOBILE')) {
				showmessage($Plang['d435da16958babcc'], "plugin.php?id=wq_login&mod=access&ac=bind");
			} else {
				showmessage($Plang['d435da16958babcc'], dreferer());
			}
		} else {
			showmessage('login_password_invalid');
		}
	}

	if($_G['cookie']['qrauth']) {
		$qrauth = authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $_G['config']['security']['authkey']);
		if(!$setting['bind_is_write_password']) {
			$qrauth = true;
		}
	}


	if(!$_G['uid'] || $_G['uid'] && $qrauth) {
		$qrcodeurl = $_G['siteurl'] . 'plugin.php?id=wq_login&mod=qrcode';
		list($code, $codeenc, $qrcodeurl) = get_qrcode_code();
	}

	if($_G['uid'] && !$qrauth && $_GET['ac'] != 'unbind') {
		$user = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);
		if($user) {
			$dreferer = $_GET['id'] == 'wq_login' && $_GET['mod'] == 'scan' ? $_G['siteurl'] : dreferer();
			showmessage($Plang['username_in_bind'], $dreferer, array(), array('header' => true));
		}
	}

	include_once template('wq_login:wechat_login');
}
//dis'.'m.t'.'ao'.'bao.com
?>