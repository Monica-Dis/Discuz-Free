<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$wq_wechatuser = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);
if($wq_wechatuser) {
	include_once template('wq_login:tpl_login_user');
} else {
	showmessage($Plang['d6eb3969824550ff']);
}
//dis'.'m.t'.'ao'.'bao.com
?>