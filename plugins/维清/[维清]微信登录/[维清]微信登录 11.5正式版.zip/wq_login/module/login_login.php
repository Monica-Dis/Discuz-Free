<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$referer = dreferer();
$backurl = rawurlencode($referer);

if($_G['uid']) {
	$ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
	$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['member']['uid']);
	showmessage('login_succeed', $referer ? $referer : './', $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin));
}

if(!$setting['is_wechat_login']) {
	dheader("location:member.php?mod=logging&action=login");
}

list($seccodecheck) = seccheck('login');


if($referer == $_G['siteurl'] . './') {
	$back = "forum.php?mobile=2";
} else {
	$back = "javascript:history.back();";
}

$fileUrl = 'source/plugin/wq_login/static/mobile/';
$plugin_wq_smslogin = !empty($_G['cache']['plugin']['wq_smslogin']) ? 1 : 0;
if($plugin_wq_smslogin) {
	$wq_smslogin_setting = $_G['cache']['plugin']['wq_smslogin'];
}
$ac = $_GET['ac'] && $plugin_wq_smslogin ? dhtmlspecialchars($_GET['ac']) : "";

include_once template('wq_login:tpl_login_login');

?>