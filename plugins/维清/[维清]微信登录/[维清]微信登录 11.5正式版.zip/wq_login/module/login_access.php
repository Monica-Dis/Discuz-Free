<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wechatlogin_login.php 2015-5-24 18:45:50Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_login/config/filter_biaoqing.php';

$allowop = array('init', 'callback');
$op = $_GET['op'];

if(!in_array($op, $allowop)) {
	$op = 'init';
}

$referer = dreferer();

$callback_url = $setting['wx_domain'] . $setting['domain_file'] . '?id=wq_login&mod=access&op=callback';
if($_GET['ac'] == 'bind') {
	$callback_url .= "&ac=bind";
}

$codeenc = $_GET['codeenc'] ? $_GET['codeenc'] : '';

if($codeenc == '' && $_G['uid'] && $_GET['ac'] != 'bind') {
	dheader("Location:" . $referer);
}

try {
	$OAuth = new OAuth();
} catch(Exception $e) {
	showmessage($Plang['init_oauth_error'], $referer, array('Message' => $e->getmessage()));
}

if($setting['wx_domain'] == 'http:///') {
	showmessage($Plang['set_wx_domain'], $referer);
}

if($op == 'init') {
	$callback = $callback_url . '&referer=' . (urldecode($referer) == $referer ? urlencode($referer) : $referer) . ($codeenc ? "&codeenc=" . $codeenc : "");
	$callback = $callback . "&siteurl=" . urlencode($_G['siteurl']);
	dsetcookie('wq_login_referer', $referer);
	dsetcookie('request_uri', $callback);

	$redirect = $OAuth->getOAuthAuthorizeURL($callback);

	dheader('Location:' . $redirect);
} elseif($op == 'callback') {

	loaducenter();
	$params = $_GET;

	if($params['state'] != md5(FORMHASH)) {
		showmessage($Plang['login_get_access_token_failed'], $referer);
	}


	C::t('#wq_login#wq_login_code_cache')->delete_by_dateline(TIMESTAMP - 300);


	$code_cache = C::t('#wq_login#wq_login_code_cache')->result_info_by_code($params['code']);
	if(!empty($code_cache)) {
		$info = unserialize(base64_decode(authcode($code_cache)));
		$openid = $info['0'];
		$access_token = $info['1'];
		$_G['code_cache'] = $code_cache;
	} else {
		try {
			$response = $OAuth->GetOpenId($_G['cookie']['request_uri'], $params['code']);

			$info = base64_encode(serialize(array($response['openid'], $response['access_token'])));
			$info = authcode($info, "ENCODE");
			C::t('#wq_login#wq_login_code_cache')->insert(array('code' => $params['code'], 'info' => $info, 'dateline' => TIMESTAMP));

			$openid = $response['openid'];
			$access_token = $response['access_token'];
		} catch(Exception $e) {
			showmessage($Plang['login_get_openid_failed'], $referer, array('Message' => $e->getmessage()));
		}
	}

	$wechat_userinfo = $OAuth->getUserInfo($openid, $access_token);

	$user = '';
	if($wechat_userinfo['unionid']) {
		$tem_user = C::t('#wq_login#wq_login_member')->fetch_first_by_unionid($wechat_userinfo['unionid']);
	}

	if(!$tem_user) {
		$user = C::t('#wq_login#wq_login_member')->fetch_first_by_openid($openid);
	} else {
		$user = $tem_user;
	}

	if($user && !$user['unionid'] && $wechat_userinfo['unionid']) {
		C::t('#wq_login#wq_login_member')->update($user['id'], array('unionid' => $wechat_userinfo['unionid']));
	}

	if($params['ac'] == 'bind' && $_G['uid']) {
		if(!empty($user)) {
			showmessage($Plang['2e338ce1528e663d'], "./");
		} else {
			try {
				$userinfo = $OAuth->getUserInfo($openid, $access_token);
			} catch(Exception $e) {
				showmessage($Plang['login_get_userinfo_failed'], $referer, array('Message' => $e->getmessage()));
			}

			$userinfo['nickname'] = wq_login_clear($userinfo['nickname']);
			if(CHARSET == 'gbk') {
				foreach($userinfo as $key => $value) {
					$userinfo[$key] = diconv($value, 'UTF-8');
				}
			}

			C::t('#wq_login#wq_login_member')->insert(array('uid' => $_G['uid'], 'openid' => $openid, 'unionid' => $userinfo['unionid'], 'access_token' => $access_token, 'chgusername' => '1', 'chgpassword' => '1', 'username' => $_G['username'], 'weixinname' => $userinfo['nickname'], 'sex' => $userinfo['sex'], 'authorizetime' => TIMESTAMP, 'dateline' => TIMESTAMP, 'area' => $userinfo['province'] . $userinfo['city']));
			if($appbyme_app) {
				wq_login_common_check_app($_G['uid'], $userinfo['unionid']);
			}
			if($magapp) {
				wq_login_common_check_app($_G['uid'], $userinfo['unionid'], 'magapp', $setting['appid']);
			}
			if($qianfan_app) {
				wq_login_common_check_app($_G['uid'], $userinfo['unionid'], 'qianfanapp', '', $userinfo['nickname']);
			}

			wq_login_bind_or_register_credit_reward($_G['uid'], $setting, 'bind');

			$json = sendWechatTemplateTips($setting, 2);

			goto_subscribe($json, $_G['cookie']['wq_login_referer']);

			if($setting['is_header'] == "1") {
				dheader("Location:" . $_G['cookie']['wq_login_referer']);
			} else {
				showmessage($Plang['f64ff3e5e720c1dd'], $_G['cookie']['wq_login_referer'], $param, array('extrajs' => $ucsynlogin));
			}
		}
	}
	$checkcode = false;


	if($params['codeenc']) {
		$checkcode = authcode(base64_decode($params['codeenc']), 'DECODE', $_G['config']['security']['authkey']);
		$authcode = C::t('#wq_login#wq_login_authcode')->fetch_by_code($checkcode);

		if(discuz_process::islocked($checkcode)) {
			$authcode['uid'] = 0;
			discuz_process::unlock($checkcode);
		} else {
			if($authcode['uid']) {
				discuz_process::unlock($checkcode);
			}
		}

		if($authcode['uid']) {
			if(!empty($user)) {
				showmessage($Plang['2e338ce1528e663d'], "./");
			} else {
				try {
					$userinfo = $OAuth->getUserInfo($openid, $access_token);
				} catch(Exception $e) {
					showmessage($Plang['login_get_userinfo_failed'], $referer, array('Message' => $e->getmessage()));
				}

				$userinfo['nickname'] = wq_login_clear($userinfo['nickname']);

				if(CHARSET == 'gbk') {
					foreach($userinfo as $key => $value) {
						$userinfo[$key] = diconv($value, 'UTF-8');
					}
				}

				wq_wechat_update_userinfo_by_uid($authcode['uid'], $userinfo);
				$username = wq_wechat_get_username_by_uid($authcode['uid']);

				C::t('#wq_login#wq_login_member')->insert(array('uid' => $authcode['uid'], 'openid' => $openid, 'unionid' => $userinfo['unionid'], 'access_token' => $access_token, 'chgusername' => '1', 'chgpassword' => '1', 'username' => $username, 'weixinname' => $userinfo['nickname'], 'sex' => $userinfo['sex'], 'authorizetime' => TIMESTAMP, 'dateline' => TIMESTAMP, 'area' => $userinfo['province'] . $userinfo['city']));

				if($appbyme_app) {
					wq_login_common_check_app($_G['uid'], $userinfo['unionid']);
				}
				if($magapp) {
					wq_login_common_check_app($_G['uid'], $userinfo['unionid'], 'magapp', $setting['appid']);
				}
				if($qianfan_app) {
					wq_login_common_check_app($_G['uid'], $userinfo['unionid'], 'qianfanapp', '', $userinfo['nickname']);
				}

				C::t('#wq_login#wq_login_authcode')->update($authcode['sid'], array('status' => 1));
				$login = wq_wechat_login($authcode);

				if(!$login) {
					showmessage($Plang['login_error']);
				}

				C::t('common_member_status')->update($user['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

				$ucsynlogin = '';
				if($_G['setting']['allowsynlogin']) {
					$ucsynlogin = uc_user_synlogin($_G['uid']);
				}

				wq_login_bind_or_register_credit_reward($_G['uid'], $setting, 'bind');

				$json = sendWechatTemplateTips($setting, 2);

				goto_subscribe($json, "./");

				if($setting['is_header'] == "1") {
					dheader("Location:./");
				} else {
					showmessage($Plang['f64ff3e5e720c1dd'], "./");
				}
			}
		}
	}


	if(empty($user)) {
		try {
			$userinfo = $OAuth->getUserInfo($openid, $access_token);
		} catch(Exception $e) {
			showmessage($Plang['login_get_userinfo_failed'], $referer, array('Message' => $e->getmessage()));
		}
		$userinfo['nickname'] = wq_login_clear($userinfo['nickname']);

		if(CHARSET == 'gbk') {
			foreach($userinfo as $key => $value) {
				$userinfo[$key] = diconv($value, 'UTF-8');
			}
		}

		$weixinname = trim($userinfo['nickname']);
		if($userinfo['unionid'] && ($magapp || $appbyme_app || $qianfan_app)) {
			$appuserinfo = array();
			if($appbyme_app) {
				$appuserinfo = C::t('#wq_login#appbyme_connection')->fetch_by_unionid($userinfo['unionid']);
			} elseif($qianfan_app) {
				$appuserinfo = C::t('#wq_login#thirdbind')->fetch_by_unionid($userinfo['unionid']);
			} elseif($magapp) {
				$appuserinfo = wq_login_get_magappuserinfo_by_unionid($userinfo['unionid']);
			}
			$dzuserinfo = getuserbyuid($appuserinfo['uid'], 1);
			if($dzuserinfo) {
				$user = array(
					'uid' => $dzuserinfo['uid'],
					'username' => $dzuserinfo['username'],
					'openid' => $openid,
					'unionid' => $userinfo['unionid'],
					'access_token' => $access_token,
					'app_id' => $setting['appid'],
					'weixinname' => $weixinname,
					'sex' => $userinfo['sex'],
					'authorizetime' => TIMESTAMP,
					'dateline' => TIMESTAMP,
					'area' => $userinfo['province'] . $userinfo['city']
				);
				C::t('#wq_login#wq_login_member')->insert($user);
			}
		}
	}

	if(empty($user)) {
		$userinfo['nickname'] = wq_wechat_process_username($userinfo['nickname']);

		if($setting['open_register']) {
			$param = array('bbname' => $_G['setting']['bbname'], 'usergroup' => $_G['group']['grouptitle']);

			if(!discuz_process::islocked($openid)) {
				$wechat_register = wq_wechat_register($userinfo['nickname']);
				$uid = $wechat_register[0];
				$username = $wechat_register[1];

				if(!$uid) {
					showmessage($Plang['register_error'], $referer);
				}

				wq_wechat_uploadAvatar($uid, $userinfo['headimgurl']);
				C::t('#wq_login#wq_login_member')->insert(array('uid' => $uid, 'username' => $username, 'openid' => $openid, 'unionid' => $userinfo['unionid'], 'access_token' => $access_token, 'app_id' => $setting['appid'], 'weixinname' => $weixinname, 'sex' => $userinfo['sex'], 'authorizetime' => TIMESTAMP, 'dateline' => TIMESTAMP, 'area' => $userinfo['province'] . $userinfo['city']));
				if($appbyme_app) {
					wq_login_common_check_app($uid, $userinfo['unionid']);
				}
				if($magapp) {
					wq_login_common_check_app($uid, $userinfo['unionid'], 'magapp', $setting['appid']);
				}
				if($qianfan_app) {
					wq_login_common_check_app($uid, $userinfo['unionid'], 'qianfanapp', '', $userinfo['nickname']);
				}


				wq_wechat_update_code_status($checkcode);

				wq_login_bind_or_register_credit_reward($uid, $setting);

				wq_wechat_update_userinfo_by_uid($uid, $userinfo);

				$json = sendWechatTemplateTips($setting, 0);

				goto_subscribe($json, $_G['cookie']['wq_login_referer']);
				discuz_process::unlock($openid);
			}


			if($setting['is_header'] == "1") {
				dheader("Location:" . $_G['cookie']['wq_login_referer']);
			} else {
				showmessage('register_succeed', $_G['cookie']['wq_login_referer'], $param);
			}
		} else {
			$register_tips = $setting['open_oneself_username'] ? $Plang['register'] : $Plang['one_key_register'];
			$tml_param = array(
				'referer' => $referer,
				'nickname' => $userinfo['nickname'],
				'sex' => $userinfo['sex'],
				'province' => $userinfo['province'],
				'city' => $userinfo['city'],
				'headimgurl' => $userinfo['headimgurl'],
				'openid' => $openid,
				'unionid' => $userinfo['unionid'],
				'access_token' => $access_token,
				'weixinname' => $weixinname,
				'checkcode' => $checkcode
			);
			include_once template('wq_login:wechat_login_bindorregister');
		}
	} else {
		$data = array('dateline' => TIMESTAMP, 'access_token' => $access_token);

		if($setting['update_userinfo']) {
			wq_wechat_update_userinfo_by_uid($user['uid'], $userinfo);

			$data['sex'] = $userinfo['sex'];
			$data['weixinname'] = $userinfo['nickname'];
			$data['area'] = $userinfo['province'] . $userinfo['city'];
		}

		C::t('#wq_login#wq_login_member')->update($user['id'], $data);

		$login = wq_wechat_login($user);

		if(!$login) {
			showmessage($Plang['login_error'], $referer);
		}

		$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle']);
		C::t('common_member_status')->update($user['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

		$ucsynlogin = '';
		if($_G['setting']['allowsynlogin']) {
			$ucsynlogin = uc_user_synlogin($_G['uid']);
		}

		wq_wechat_update_code_status($checkcode);

		$json = sendWechatTemplateTips($setting, 1);
		goto_subscribe($json, $_G['cookie']['wq_login_referer']);

		if($setting['is_header'] == "1") {
			dheader("Location:" . $_G['cookie']['wq_login_referer']);
		} else {

			showmessage($setting['login_hint'] ? $setting['login_hint'] : 'login_succeed', $_G['cookie']['wq_login_referer'], $param, array('extrajs' => $ucsynlogin));
		}
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>