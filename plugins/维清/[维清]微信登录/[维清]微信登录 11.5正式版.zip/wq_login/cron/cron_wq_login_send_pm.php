<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 * ���²����http://t.cn/Aiux1Jx1
 * $Id: wq_login_send_pm.php 2016-12-1 10:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//cronname:send_pm
//minute:0,5,10,15,20,25,30,35,40,45,50,55

include_once DISCUZ_ROOT . './source/plugin/wq_login/class/jssdk.class.php';
include_once DISCUZ_ROOT . './source/plugin/wq_login/function/function_login.php';
loadcache("plugin");
$setting = $_G['cache']['plugin']['wq_login'];
$setting['appid'] = trim($setting['appid']);
$setting['appsecret'] = trim($setting['appsecret']);
$setting['open_wechattips'] = intval($setting['open_wechattips']);
$setting['templateid'] = trim($setting['templateid']);
$setting['pmnum'] = max(0, $setting['pmnum']);
$setting['pmnum'] = $setting['pmnum'] <= 5 ? intval($setting['pmnum']) : 5;

if(!empty($setting['templateid']) && $setting['pmnum'] > 0) {

	$uids = DB::fetch_all("SELECT uid,pmlasttime FROM %t WHERE uid>0 AND openid<>'' ORDER BY pmtime ASC limit %d", array('wq_login_member', $setting['pmnum']));
	loaducenter();

	foreach($uids as $uid) {
		if($uid) {
			$time = TIMESTAMP;
			$newpm = uc_pm_checknew($uid['uid'], 3);
			$user = getuserbyuid($uid['uid']);
			DB::query('UPDATE %t SET pmtime=%d,pmlasttime=%d WHERE uid=%d', array('wq_login_member', $time, $newpm['lastdate'], $uid['uid']));

			if(intval($newpm['newpm']) > 0 && $newpm['lastdate'] > $uid['pmlasttime']) {
				$result = sendWechatTemplateTips($setting, 11, 3, 0, 0, $user['uid'], $user['username']);
			}
		}
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>