<?php

function get_did_by_name_level($_arg_0, $_arg_1 = "1")
{
	include libfile("config", "plugin/wq_login/config/");
	if ($_arg_1 == "1") {
		$_var_2[] = $_arg_0 . $_var_3["level_1"];
		$_var_2[] = $_arg_0 . $_var_3["level_2"];
	} else {
		$_var_2[] = $_arg_0 . $_var_3["level_2"];
		$_var_2[] = $_arg_0 . $_var_3["level_22"];
	}
	return DB::result_first("SELECT name FROM %t WHERE level = %d AND name IN(%n)", array("common_district", $_arg_1, $_var_2));
}
function wq_wechat_update_userinfo_by_uid($_arg_0, $_arg_1)
{
	$_var_2 = get_did_by_name_level($_arg_1["province"], 1);
	$_var_3 = get_did_by_name_level($_arg_1["city"], 2);
	$_var_4 = array("resideprovince" => $_var_2, "residecity" => $_var_3, "gender" => $_arg_1["sex"]);
	DB::update("common_member_profile", $_var_4, array("uid" => $_arg_0));
}
function wq_wechat_get_username_by_uid($_arg_0)
{
	return DB::result_first("SELECT username FROM %t WHERE uid = %d", array("common_member", $_arg_0));
}
function get_qrcode_code()
{
	global $_G;
	$_var_1 = 0;
	$_var_2 = 0;
	do {
		$_var_1 = rand(100000, 999999);
		$_var_3 = C::t("#wq_login#wq_login_authcode")->fetch_by_code($_var_1);
		$_var_2 = $_var_2 + 1;
	} while ($_var_3 && $_var_2 < 10);
	if ($_var_3) {
		showmessage("wq_login:wechat_message_codefull");
	}
	$_var_4 = urlencode(base64_encode(authcode($_var_1, "ENCODE", $_G["config"]["security"]["authkey"])));
	C::t("#wq_login#wq_login_authcode")->insert(array("sid" => $_G["cookie"]["saltkey"], "uid" => $_G["uid"], "code" => $_var_1, "createtime" => TIMESTAMP), 0, 1);
	if (!discuz_process::islocked("clear_wechat_authcode")) {
		C::t("#wq_login#wq_login_authcode")->delete_history();
		discuz_process::unlock("clear_wechat_authcode");
	}
	dsetcookie("wq_login_ticket", authcode($_var_4 . "\t" . $_var_1, "ENCODE"), 1800);
	$_var_5 = $_G["siteurl"] . "plugin.php?id=wq_login&mod=qrcode&rand=" . random(5);
	return array($_var_1, $_var_4, $_var_5);
}
function wq_show_qrcode()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["wq_login"];
	$_var_1["qrcode_type"] = intval($_var_1["qrcode_type"]);
	list($_var_2, $_var_3) = explode("\t", authcode($_G["cookie"]["wq_login_ticket"], "DECODE"));
	$_var_4 = $_G["siteurl"] . "plugin.php?id=wq_login&mod=access&codeenc=" . $_var_2;
	require_once DISCUZ_ROOT . "source/plugin/wq_login/class/qrcode.class.php";
	$_var_5 = $_GET["size"] ? intval($_GET["size"]) : "5";
	if ($_var_1["qrcode_type"] == 1) {
		ob_clean();
	}
	echo QRcode::png($_var_4, false, 5, $_var_5);
}
function wq_wechat_changeusername($_arg_0, $_arg_1)
{
	$_var_2 = DB::fetch_first("SELECT * FROM " . DB::table("common_member") . " WHERE username='" . $_arg_0 . "'");
	if ($_var_2) {
		DB::query("UPDATE " . DB::table("common_adminnote") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block_item") . " SET title='" . $_arg_1 . "' WHERE title='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_block_item_data") . " SET title='" . $_arg_1 . "' WHERE title='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_card_log") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_failedlogin") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_grouppm") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_invite") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_security") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_validate") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_verify_info") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_member_security") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_mytask") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_report") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_session") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("common_word") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_activityapply") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_announcement") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collection") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectioncomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionfollow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionteamworker") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_forumrecommend") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_groupuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_imagetype") . " SET name='" . $_arg_1 . "' WHERE name='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_order") . " SET buyer='" . $_arg_1 . "' WHERE buyer='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_order") . " SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_pollvoter") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_post") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_postcomment") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_promotion") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_ratelog") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_rsscache") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_thread") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_threadmod") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_trade") . " SET seller='" . $_arg_1 . "' WHERE seller='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_tradelog") . " SET seller='" . $_arg_1 . "' WHERE seller='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_tradelog") . " SET buyer='" . $_arg_1 . "' WHERE buyer='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_warning") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_album") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_blog") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_clickuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_comment") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_docomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_doing") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_feed_app") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed_archiver") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_friend") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_friend_request") . " SET fusername='" . $_arg_1 . "' WHERE fusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_notification") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_pic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_poke") . " SET fromusername='" . $_arg_1 . "' WHERE fromusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_share") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_show") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_specialuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_visitor") . " SET vusername='" . $_arg_1 . "' WHERE vusername='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_specialuser") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_article_title") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_comment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_rsscache") . " SET author='" . $_arg_1 . "' WHERE author='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_topic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("portal_topic_pic") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collection") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectioncomment") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionfollow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("forum_collectionteamworker") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow") . " SET username='" . $_var_3 . "' WHERE username='" . $_var_3 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
		DB::query("UPDATE " . DB::table("home_follow_feed_archiver") . " SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	}
	C::memory()->clear();
	return $_var_2;
}
function wq_wechat_changename_for_uc($_arg_0, $_arg_1)
{
	DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='" . $_arg_1 . "' WHERE admin='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='" . $_arg_1 . "' WHERE username='" . $_arg_0 . "'");
	C::memory()->clear();
}
function wq_wechat_changepassword($_arg_0)
{
	global $_G;
	loaducenter();
	uc_user_edit($_G["username"], '', $_arg_0, '', 1);
	$_var_2 = C::t("#wq_login#wq_login_member")->update_by_uid($_G["uid"], true);
	if ($_var_2) {
		C::memory()->clear();
		return true;
	}
}
function wq_wechat_unbind_user()
{
	global $_G;
	require_once libfile("function/member");
	C::t("#wq_login#wq_login_member")->delete_by_uid($_G["uid"]);
}
function wq_wechat_check_code_status($_arg_0)
{
	if ($_arg_0) {
		$_var_1 = C::t("#wq_login#wq_login_authcode")->fetch_by_code($_arg_0);
		if ($_var_1["status"]) {
			require_once libfile("function/member");
			$_var_2 = getuserbyuid($_var_1["uid"], 1);
			setloginstatus($_var_2, 1296000);
			dsetcookie("wq_login_ticket", '', -1);
			$_var_3 = "done";
		} else {
			$_var_3 = "1";
		}
	} else {
		$_var_3 = "-1";
	}
	return $_var_3;
}
function wq_login_check_password($_arg_0)
{
	global $_G;
	loaducenter();
	list($_var_2) = uc_user_login($_G["uid"], $_arg_0, 1, 0);
	if ($_var_2 >= 0) {
		return $_var_2;
	}
	return false;
}
function wq_wechat_update_code_status($_arg_0)
{
	global $_G;
	if ($_arg_0 && $_G["uid"]) {
		$_var_2 = C::t("#wq_login#wq_login_authcode")->fetch_by_code($_arg_0);
		C::t("#wq_login#wq_login_authcode")->update($_var_2["sid"], array("uid" => $_G["uid"], "status" => 1));
	}
}
function wq_wechat_save_avatar($_arg_0)
{
	global $_G;
	$_var_2 = DISCUZ_ROOT . "/data/cache/avatarTmp/";
	dmkdir($_var_2);
	$_var_3 = $_var_2 . "/" . date("His") . strtolower(random(16)) . ".jpg";
	if ($_G["cache"]["plugin"]["wq_login"]["function_type"] == "2") {
		$_var_4 = file_get_contents($_arg_0);
	} else {
		$_var_4 = dfsockopen($_arg_0, 0, array(), '', false);
	}
	file_put_contents($_var_3, $_var_4);
	return $_var_3;
}
function wq_wechat_process_username($_arg_0, $_arg_1 = 0)
{
	global $_G;
	$_arg_1 = $_arg_1 + 1;
	$_arg_0 = trim($_arg_0);
	$_var_3 = dstrlen($_arg_0);
	if ($_var_3 < 3) {
		$_arg_0 = $_arg_0 . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90) . chr(rand(65, 90)));
	} else {
		if ($_var_3 > 15) {
			$_arg_0 = cutstr($_arg_0, 15, '');
		}
	}
	loaducenter();
	$_var_4 = uc_user_checkname($_arg_0);
	if ($_var_4 == -1) {
		wq_wechat_checkname_error($_var_4, $_arg_1);
		$_arg_0 = str_replace(array(",", " ", "%", "<", ">", "*", "\""), '', $_arg_0);
		$_arg_0 = wq_wechat_process_username($_arg_0, $_arg_1);
	} else {
		if ($_var_4 == -2) {
			wq_wechat_checkname_error($_var_4, $_arg_1);
			$_var_5 = 0;
			while ($_var_5 < 5) {
				$_var_6 = $_var_6 . chr(rand(65, 90));
				$_var_5;
			}
			$_arg_0 = wq_wechat_process_username($_var_6, $_arg_1);
		} else {
			if ($_var_4 == -3) {
				wq_wechat_checkname_error($_var_4, $_arg_1);
				$_arg_0 = cutstr($_arg_0, 10, '') . "_" . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90));
				$_arg_0 = wq_wechat_process_username($_arg_0, $_arg_1);
			}
		}
	}
	$_var_7 = "/^(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_G["setting"]["censoruser"] = trim($_G["setting"]["censoruser"]), "/")) . ")\$/i";
	if ($_G["setting"]["censoruser"] && @preg_match($_var_7, $_arg_0)) {
		wq_wechat_checkname_error(-2, $_arg_1);
		$_var_8 = explode("\n", $_G["setting"]["censoruser"]);
		foreach ($_var_8 as $_var_9 => $_var_10) {
			$_var_6[] = trim($_var_10);
		}
		$_arg_0 = str_replace($_var_6, '', $_arg_0);
		$_arg_0 = wq_wechat_process_username($_arg_0, $_arg_1);
	}
	return $_arg_0;
}
function wq_wechat_checkname_error($_arg_0, $_arg_1 = 0)
{
	if ($_arg_1 > 3) {
		$_var_2 = getWqLoginPlang();
		if ($_arg_0 == -1) {
			$_var_3 = $_var_2["username_error_1"];
		} elseif ($_arg_0 == -2) {
			$_var_3 = $_var_2["username_error_2"];
		} elseif ($_arg_0 == -3) {
			$_var_3 = $_var_2["username_error_3"];
		} else {
			$_var_3 = $_var_2["username_error"];
		}
		showmessage($_var_3);
	}
}
function wq_wechat_checkemail($_arg_0)
{
	global $_G;
	$_var_2 = getWqLoginPlang();
	if (strlen($_arg_0) > 32) {
		showmessage($_var_2["profile_email_illegal"]);
	}
	if ($_G["setting"]["regmaildomain"]) {
		$_var_3 = "/(" . str_replace("\r\n", "|", preg_quote(trim($_G["setting"]["maildomainlist"]), "/")) . ")\$/i";
		if ($_G["setting"]["regmaildomain"] == 1 && !preg_match($_var_3, $_arg_0)) {
			showmessage($_var_2["profile_email_domain_illegal"]);
		} else {
			if ($_G["setting"]["regmaildomain"] == 2 && preg_match($_var_3, $_arg_0)) {
				showmessage($_var_2["profile_email_domain_illegal"]);
			}
		}
	}
	loaducenter();
	$_var_4 = uc_user_checkemail($_arg_0);
	if ($_var_4 == -4) {
		showmessage($_var_2["profile_email_illegal"]);
	} else {
		if ($_var_4 == -5) {
			showmessage($_var_2["profile_email_domain_illegal"]);
		} else {
			if ($_var_4 == -6) {
				showmessage($_var_2["profile_email_duplicate"]);
			}
		}
	}
}
function wq_wechat_register($_arg_0, $_arg_1 = 0, $_arg_2 = '', $_arg_3 = '')
{
	global $_G;
	if (!$_arg_0) {
		return NULL;
	}
	include_once UC_ROOT . "./model/base.php";
	$_var_5 = new base();
	$_var_6 = $_var_5->get_setting(array("accessemail"));
	$_var_7 = $_var_6["accessemail"];
	$_var_8 = explode("\n", str_replace("\r\n", "\n", $_var_7));
	$_var_9 = $_G["cache"]["plugin"]["wq_login"];
	$_var_10 = $_var_9["newusergroupid"] ? $_var_9["newusergroupid"] : $_G["setting"]["newusergroupid"];
	if ($_arg_2) {
		$_var_11 = $_arg_2;
	} else {
		$_var_11 = md5(random(10));
	}
	if (empty($_arg_3)) {
		if ($_var_8[0] == '') {
			$_arg_3 = "wechat_" . strtolower(random(10)) . "@null.null";
		} else {
			$_arg_3 = "wechat_" . strtolower(random(10)) . "@" . trim(trim(strtolower($_var_8[0])));
			$_arg_3 = str_replace(array("@@", "@"), "@", $_arg_3);
		}
	}
	if (!$_var_9["disableregrule"]) {
		loadcache("ipctrl");
		if ($_G["cache"]["ipctrl"]["ipregctrl"]) {
			foreach (explode("\n", $_G["cache"]["ipctrl"]["ipregctrl"]) as $_var_12) {
				if (preg_match("/^(" . preg_quote($_var_12 = trim($_var_12), "/") . ")/", $_G["clientip"])) {
					$_var_12 = $_var_12 . "%";
					$_G["setting"]["regctrl"] = $_G["setting"]["ipregctrltime"];
					break;
				}
				$_var_12 = $_G["clientip"];
			}
		} else {
			$_var_12 = $_G["clientip"];
		}
		if ($_G["setting"]["regctrl"]) {
			if (C::t("common_regip")->count_by_ip_dateline($_var_12, $_G["timestamp"] - $_G["setting"]["regctrl"] * 3600)) {
				if (!$_arg_1) {
					showmessage("register_ctrl", NULL, array("regctrl" => $_G["setting"]["regctrl"]));
				} else {
					return NULL;
				}
			}
		}
		$_var_13 = NULL;
		if ($_G["setting"]["regfloodctrl"]) {
			$_var_14 = C::t("common_regip")->fetch_by_ip_dateline($_G["clientip"], $_G["timestamp"] - 86400);
			if ($_var_14) {
				if ($_var_14["count"] >= $_G["setting"]["regfloodctrl"]) {
					if (!$_arg_1) {
						showmessage("register_flood_ctrl", NULL, array("regfloodctrl" => $_G["setting"]["regfloodctrl"]));
					} else {
						return NULL;
					}
				} else {
					$_var_13 = 1;
				}
			} else {
				$_var_13 = 2;
			}
		}
		if ($_var_13 !== NULL) {
			if ($_var_13 == 1) {
				C::t("common_regip")->update_count_by_ip($_G["clientip"]);
			} else {
				C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => 1, "dateline" => $_G["timestamp"]));
			}
		}
	}
	$_var_15 = wq_wechat_system_register($_arg_0, $_var_11, $_arg_3);
	$_var_16 = $_var_15[0];
	$_arg_0 = $_var_15[1];
	$_var_17 = array("credits" => explode(",", $_G["setting"]["initcredits"]));
	C::t("common_member")->insert($_var_16, $_arg_0, $_var_11, $_arg_3, $_G["clientip"], $_var_10, $_var_17);
	if ($_G["setting"]["regctrl"] || $_G["setting"]["regfloodctrl"]) {
		C::t("common_regip")->delete_by_dateline($_G["timestamp"] - ($_G["setting"]["regctrl"] > 72 ? $_G["setting"]["regctrl"] : 72) * 3600);
		if ($_G["setting"]["regctrl"]) {
			C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => -1, "dateline" => $_G["timestamp"]));
		}
	}
	if ($_G["setting"]["regverify"] == 2) {
		C::t("common_member_validate")->insert(array("uid" => $_var_16, "submitdate" => $_G["timestamp"], "moddate" => 0, "admin" => '', "submittimes" => 1, "status" => 0, "message" => '', "remark" => ''), false, true);
		manage_addnotify("verifyuser");
	}
	require_once libfile("function/member");
	$_var_18 = 1296000;
	setloginstatus(array("uid" => $_var_16, "username" => $_arg_0, "password" => $_var_11, "groupid" => $_var_10), $_var_18);
	dsetcookie("isqquser", 1, $_var_18);
	include_once libfile("function/stat");
	updatestat("register");
	include_once libfile("cache/userstats", "function");
	build_cache_userstats();
	return array($_var_16, $_arg_0);
}
function wq_wechat_system_register($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_var_4 = uc_user_register(addslashes($_arg_0), $_arg_1, $_arg_2, '', '', $_G["clientip"]);
	if ($_var_4 <= 0) {
		if (!$_var_5) {
			if ($_var_4 == -1) {
				$_var_6 = "profile_username_tooshort";
				if (strlen($_arg_0) > 3) {
					$_var_6 = "profile_username_toolong";
				}
				showmessage($_var_6);
			} else {
				if ($_var_4 == -2) {
					showmessage("profile_username_protect");
				} else {
					if ($_var_4 == -3) {
						return $_var_4 = wq_wechat_system_register(cutstr($_arg_0, 11, '') . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)), $_arg_1, $_arg_2);
					}
					if ($_var_4 == -4) {
						showmessage("profile_email_illegal");
					} else {
						if ($_var_4 == -5) {
							showmessage("profile_email_domain_illegal");
						} else {
							if ($_var_4 == -6) {
								showmessage("profile_email_duplicate");
							} else {
								showmessage("undefined_action");
							}
						}
					}
				}
			}
		} else {
			return NULL;
		}
	} else {
		return array($_var_4, $_arg_0);
	}
}
function wq_wechat_login($_arg_0)
{
	global $_G;
	if (!($_arg_0 = getuserbyuid($_arg_0["uid"], 1))) {
		return false;
	}
	if (isset($_arg_0["_inarchive"])) {
		C::t("common_member_archive")->move_to_master($_arg_0["uid"]);
	}
	require_once libfile("function/member");
	$_var_2 = 1296000;
	setloginstatus($_arg_0, $_var_2);
	dsetcookie("isqquser", 1, $_var_2);
	return true;
}
function wq_wechat_uploadAvatar($_arg_0, $_arg_1)
{
	global $_G;
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	$_arg_1 = wq_wechat_save_avatar($_arg_1);
	list($_var_3, $_var_4, $_var_5, $_var_6) = getimagesize($_arg_1);
	if (!$_var_3) {
		return false;
	}
	if ($_var_3 < 10 || $_var_4 < 10 || $_var_5 == 4) {
		return false;
	}
	$_var_7 = array(1 => ".gif", 2 => ".jpg", 3 => ".png");
	$_var_8 = $_var_7[$_var_5];
	if (!$_var_8) {
		$_var_8 = ".jpg";
	}
	$_var_9 = $_G["setting"]["attachdir"];
	$_var_10 = $_var_9 . "./temp/upload" . $_arg_0 . $_var_8;
	file_exists($_var_10) && @unlink($_var_10);
	file_put_contents($_var_10, file_get_contents($_arg_1));
	if (!is_file($_var_10)) {
		return false;
	}
	$_var_11 = "./temp/upload" . $_arg_0 . "big" . $_var_8;
	$_var_12 = "./temp/upload" . $_arg_0 . "middle" . $_var_8;
	$_var_13 = "./temp/upload" . $_arg_0 . "small" . $_var_8;
	$_var_14 = new image();
	if ($_var_14->Thumb($_var_10, $_var_11, 200, 250, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_12, 120, 120, 1) <= 0) {
		return false;
	}
	if ($_var_14->Thumb($_var_10, $_var_13, 48, 48, 2) <= 0) {
		return false;
	}
	$_var_11 = $_var_9 . $_var_11;
	$_var_12 = $_var_9 . $_var_12;
	$_var_13 = $_var_9 . $_var_13;
	$_var_15 = wq_wechat_byte2hex(file_get_contents($_var_11));
	$_var_16 = wq_wechat_byte2hex(file_get_contents($_var_12));
	$_var_17 = wq_wechat_byte2hex(file_get_contents($_var_13));
	$_var_18 = "&avatar1=" . $_var_15 . "&avatar2=" . $_var_16 . "&avatar3=" . $_var_17;
	$_var_19 = wq_wechat_uc_api_post_ex("user", "rectavatar", array("uid" => $_arg_0), $_var_18);
	@unlink($_var_10);
	@unlink($_var_11);
	@unlink($_var_12);
	@unlink($_var_13);
	@unlink($_arg_1);
	if ($_var_19 == "<?xml version=\"1.0\" ?><root><face success=\"1\"/></root>") {
		C::t("common_member")->update($_arg_0, array("avatarstatus" => "1"));
		updatecreditbyaction("setavatar");
		return true;
	}
	return false;
}
function wq_wechat_byte2hex($_arg_0)
{
	$_var_1 = '';
	$_var_2 = unpack("H*", $_arg_0);
	$_var_2 = str_split($_var_2[1], 2);
	$_var_3 = '';
	foreach ($_var_2 as $_var_4 => $_var_5) {
		$_var_3 = $_var_3 . strtoupper($_var_5);
	}
	return $_var_3;
}
function wq_wechat_uc_api_post_ex($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = '')
{
	$_var_4 = $_var_5 = '';
	foreach ($_arg_2 as $_var_6 => $_var_7) {
		$_var_6 = urlencode($_var_6);
		if (is_array($_var_7)) {
			$_var_8 = $_var_9 = '';
			foreach ($_var_7 as $_var_10 => $_var_11) {
				$_var_10 = urlencode($_var_10);
				$_var_8 = $_var_8 . ('' . $_var_9 . '' . $_var_6 . "[" . $_var_10 . "]=" . urlencode(uc_stripslashes($_var_11)));
				$_var_9 = "&";
			}
			$_var_4 = $_var_4 . ($_var_5 . $_var_8);
		} else {
			$_var_4 = $_var_4 . ('' . $_var_5 . '' . $_var_6 . "=" . urlencode(uc_stripslashes($_var_7)));
		}
		$_var_5 = "&";
	}
	$_var_12 = uc_api_requestdata($_arg_0, $_arg_1, $_var_4, $_arg_3);
	return uc_fopen2(UC_API . "/index.php", 500000, $_var_12, '', true, UC_IP, 20);
}
function get_data_for_jssdk($_arg_0)
{
	$_var_1 = array();
	$_var_1["errcode"] = "0";
	foreach (array("appId", "nonceStr", "timestamp", "signature") as $_var_2) {
		$_var_1[$_var_2] = $_arg_0[$_var_2];
	}
	return $_var_1;
}
function _get($_arg_0)
{
	$_var_1 = curl_init();
	curl_setopt($_var_1, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_1, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_1, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($_var_1, CURLOPT_SSL_VERIFYHOST, false);
	if (!curl_exec($_var_1)) {
		error_log(curl_error($_var_1));
		$_var_2 = '';
	} else {
		$_var_2 = curl_multi_getcontent($_var_1);
	}
	curl_close($_var_1);
	return $_var_2;
}
function _post($_arg_0, $_arg_1)
{
	if (!function_exists("curl_init")) {
		return '';
	}
	$_var_2 = curl_init();
	curl_setopt($_var_2, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($_var_2, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($_var_2, CURLOPT_POST, 1);
	curl_setopt($_var_2, CURLOPT_POSTFIELDS, $_arg_1);
	$_arg_1 = curl_exec($_var_2);
	if (!$_arg_1) {
		error_log(curl_error($_var_2));
	}
	curl_close($_var_2);
	return $_arg_1;
}
function convertCharset($_arg_0)
{
	if (is_array($_arg_0)) {
		foreach ($_arg_0 as $_var_1 => $_var_2) {
			$_arg_0[$_var_1] = diconv($_var_2, CHARSET, "UTF-8");
		}
	} else {
		$_arg_0 = diconv($_arg_0, CHARSET, "UTF-8");
	}
	return $_arg_0;
}
function checkIsSuc($_arg_0)
{
	$_var_1 = true;
	if (is_string($_arg_0)) {
		$_arg_0 = json_decode($_arg_0, true);
	}
	if (isset($_arg_0["errcode"]) && 0 !== (int) $_arg_0["errcode"]) {
		$_var_1 = false;
	}
	return $_var_1;
}
function sendWechatTemplateTips($_arg_0, $_arg_1, $_arg_2 = "1", $_arg_3 = 0, $_arg_4 = 0, $_arg_5 = 0, $_arg_6 = '')
{
	global $_G;
	if ($_arg_0["open_wechattips"] == "0" || empty($_arg_0["templateid"]) || !empty($_G["code_cache"])) {
		return false;
	}
	$_var_8 = getWqLoginPlang();
	if ($_arg_2 == "1") {
		$_var_9 = $_G["uid"];
		$_var_10 = $_G["username"];
		$_var_11 = $_G["siteurl"];
		$_var_12 = sprintf($_var_8["wechattips_info_1"], $_G["setting"]["bbname"]);
	} else {
		if ($_arg_2 == "3") {
			$_var_9 = $_arg_5;
			$_var_10 = $_arg_6;
			if ($_arg_1 == "11") {
				$_var_11 = $_G["siteurl"] . "home.php?mod=space&do=pm";
			} else {
				$_var_13 = array(9 => "interactive", 10 => "system");
				$_var_11 = $_G["siteurl"] . "home.php?mod=space&do=notice&view=" . $_var_13[$_arg_1];
			}
			$_var_12 = sprintf($_var_8["wechattips_info_4"], $_var_8["wechattips_info_4_" . $_arg_1]);
		} else {
			if ($_arg_2 == "4") {
				$_var_9 = $_arg_5;
				$_var_10 = $_arg_6;
				$_var_14 = $_G["siteurl"];
				if (strpos($_var_14, "source/plugin/wq_reward/") !== false) {
					$_var_14 = str_replace("source/plugin/wq_reward/", '', $_var_14);
				}
				if ($_arg_1 == "12") {
					$_var_11 = $_var_14 . "forum.php?mod=viewthread&tid=" . $_arg_3;
				} else {
					$_var_11 = $_var_14 . "portal.php?mod=view&aid=" . $_arg_3;
				}
				$_arg_1 = 12;
				$_var_12 = $_var_8["wechattips_info_5"];
			} else {
				if ($_arg_2 == "5") {
					$_var_9 = $_arg_5;
					$_var_10 = $_arg_6;
					$_var_11 = $_arg_3 ? $_G["siteurl"] . "plugin.php?id=wq_accidentlog&mod=view&infoid=" . $_arg_3 : '';
					$_var_12 = $_arg_3 ? $_var_8["wechattips_info_6"] : $_var_8["wechattips_info_7"];
				} else {
					if ($_arg_4) {
						$_var_15 = C::t("forum_post")->fetch("forum_post", $_arg_4, false);
					} else {
						$_var_15 = C::t("forum_post")->fetch_threadpost_by_tid_invisible($_arg_3);
					}
					if ($_var_15["authorid"] == $_G["uid"]) {
						return false;
					}
					$_var_9 = $_var_15["authorid"];
					$_var_10 = $_var_15["author"];
					$_var_11 = $_G["siteurl"] . "forum.php?mod=viewthread&tid=" . $_arg_3;
					if ($_arg_1 == "8") {
						$_var_12 = $_var_8["wechattips_info_3"];
					} else {
						$_var_12 = $_var_8["wechattips_info_2"];
					}
				}
			}
		}
	}
	$_var_16 = C::t("#wq_login#wq_login_member")->fetch_first_by_uid($_var_9);
	if (!$_var_16) {
		return false;
	}
	$_var_17 = $_var_16["openid"];
	$_var_18 = new WQJSSDK($_arg_0["appid"], $_arg_0["appsecret"], $_var_14);
	$_var_19 = $_var_18->getAccessToken();
	$_var_14 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $_var_19 . "&openid=" . $_var_17;
	$_var_20 = json_decode(_get($_var_14), true);
	if ($_var_20["errcode"] == "40001") {
		$_var_19 = $_var_18->getAccessToken(true);
		$_var_14 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $_var_19 . "&openid=" . $_var_17;
		$_var_20 = json_decode(_get($_var_14), true);
	}
	if (!$_var_20["subscribe"]) {
		$_var_21["errcode"] = 43004;
		return $_var_21;
	}
	$_var_22 = trim($_arg_0["templateid"]);
	$_var_23 = getTemplateID();
	$_var_24 = $_var_8["siteusername"] . $_var_10;
	$_var_25 = $_var_8["wechattips_title_" . $_arg_1];
	date_default_timezone_set("Etc/GMT-8");
	$_var_26 = date("Y----m--d-H:i", time());
	$_var_26 = str_replace(array("----", "--", "-"), array($_var_8["year"], $_var_8["month"], $_var_8["day"]), $_var_26);
	$_var_27 = array("{openid}", "{templateid}", "{siteurl}", "{title}", "{eventtype}", "{datetime}", "{remark}");
	$_var_28 = array($_var_17, $_var_22, $_var_11, $_var_24, $_var_25, $_var_26, $_var_12);
	$_var_16 = str_replace($_var_27, convertCharset($_var_28), $_var_23);
	$_var_14 = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $_var_19;
	$_var_29 = json_decode(_post($_var_14, $_var_16), true);
	if ($_var_29["errcode"] == "40001") {
		$_var_19 = $_var_18->getAccessToken(true);
		$_var_14 = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $_var_19;
		$_var_29 = json_decode(_post($_var_14, $_var_16), true);
	}
	if ($_arg_2 == "2" && $_var_29["errcode"] == "0") {
		if ($_arg_4) {
			$_var_16 = array("pid" => $_arg_4, "dateline" => time());
			C::t("#wq_login#wq_login_posts_temporary1")->insert($_var_16, false, true);
		} else {
			$_var_16 = array("tid" => $_arg_3, "dateline" => time());
			C::t("#wq_login#wq_login_posts_temporary")->insert($_var_16, false, true);
		}
	}
	if ($_var_29["errcode"] == "0") {
		DB::query("UPDATE %t SET `isfocus`= 1 WHERE uid=%d", array("wq_login_member", $_var_9));
	} else {
		DB::query("UPDATE %t SET `isfocus`= 0 WHERE uid=%d", array("wq_login_member", $_var_9));
	}
	$_var_30 = array("uid" => $_var_9, "openid" => $_var_17, "dateline" => time(), "errcode" => $_var_29["errcode"], "type" => $_arg_1);
	C::t("#wq_login#wq_login_templatemsg_log")->insert($_var_30);
	return $_var_29;
}
function getWqLoginPlang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_login/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_login/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_login/language");
	}
	include $_var_1;
	global $Plang;
	return $Plang;
}
function getTemplateID()
{
	include DISCUZ_ROOT . "./source/plugin/wq_login/config/jsontpl.php";
	global $json_tpl;
	return $json_tpl;
}
function goto_subscribe($_arg_0, $_arg_1, $_arg_2 = false)
{
	global $_G;
	$_var_4 = $_G["cache"]["plugin"]["wq_login"];
	if ($_arg_2) {
		if ($_arg_0["errcode"] === 43004 && strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") !== false && $_var_4["is_openweixin"] == 1 && $_var_4["jump_weixin_link"]) {
			dsetcookie("wq_jump_weixin_referer", $_arg_1);
			if ($_var_4["login_hint"]) {
				$_var_5 = $_var_4["login_hint"];
			} else {
				$_var_5 = $_G["Plang"]["login_success"];
			}
			return array($_var_5, $_var_4["jump_weixin_link"]);
		}
		return false;
	}
	if ($_arg_0["errcode"] === 43004 && $_var_4["is_openweixin"] == 1 && $_var_4["jump_weixin_link"]) {
		dsetcookie("wq_jump_weixin_referer", $_arg_1);
		dheader("Location:" . $_var_4["jump_weixin_link"]);
	}
}
function wq_login_bind_or_register_credit_reward($_arg_0 = 0, $_arg_1 = array(), $_arg_2 = "register")
{
	global $_G;
	$_var_4 = getWqLoginPlang();
	if ($_arg_1["credittype"] && $_arg_1["creditnum"] >= 1 && $_arg_0) {
		$_var_5 = C::t("#wq_login#wq_login_credit_reward")->fetch_first_by_uid($_arg_0);
		if ($_var_5) {
			return false;
		}
		if ($_arg_2 == "bind") {
			$_var_6 = $_var_4["bind_success_reward"];
			$_var_7 = $_arg_1["bind_creditnum"];
			$_var_8 = $_var_4["bind_reward"];
		}
		if ($_arg_2 == "register") {
			$_var_6 = $_var_4["register_success_reward"];
			$_var_7 = $_arg_1["creditnum"];
			$_var_8 = $_var_4["register_reward"];
		}
		$_var_9 = array("uid" => $_arg_0, "status" => 1);
		C::t("#wq_login#wq_login_credit_reward")->insert($_var_9, false, true);
		$_var_10 = $_G["setting"]["extcredits"][$_arg_1["credittype"]]["title"];
		$_var_11 = $_var_6 . $_var_10 . "+" . $_var_7;
		updatemembercount($_arg_0, array($_arg_1["credittype"] => $_var_7), 1, '', $_arg_0, '', $_var_8, $_var_11);
	}
}
function wq_login_cron_create($_arg_0)
{
	$_var_1 = getWqLoginPlang();
	if (preg_match("/^[a-z]+[a-z0-9_]*\$/i", $_var_2)) {
		return false;
	}
	$_var_3 = DISCUZ_ROOT . "./source/plugin/" . $_arg_0 . "/cron";
	if (!file_exists($_var_3)) {
		return false;
	}
	$_var_4 = dir($_var_3);
	while ($_var_5 = $_var_4->read()) {
		if (!in_array($_var_5, array(".", "..")) && preg_match("/^cron\\_[\\w\\.]+\$/", $_var_5)) {
			$_var_6 = file_get_contents($_var_3 . "/" . $_var_5);
			preg_match("/cronname\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_8 = $_var_1[trim($_var_7[1])];
			preg_match("/week\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_9 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/day\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_10 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/hour\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_11 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/minute\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_12 = trim($_var_7[1]) ? trim($_var_7[1]) : 0;
			$_var_13 = explode(",", $_var_12);
			foreach ($_var_13 as $_var_2 => $_var_14) {
				$_var_13[$_var_2] = $_var_14 = intval($_var_14);
				if ($_var_14 < 0 || $_var_15 > 59) {
					unset($_var_13[$_var_2]);
				}
			}
			$_var_13 = array_slice(array_unique($_var_13), 0, 12);
			$_var_13 = implode("\t", $_var_13);
			$_var_5 = $_arg_0 . ":" . $_var_5;
			$_var_16 = C::t("common_cron")->get_cronid_by_filename($_var_5);
			if (!$_var_16) {
				C::t("common_cron")->insert(array("available" => 1, "type" => "plugin", "name" => $_var_8, "filename" => $_var_5, "weekday" => $_var_9, "day" => $_var_10, "hour" => $_var_11, "minute" => $_var_13));
			} else {
				C::t("common_cron")->update($_var_16, array("name" => $_var_8, "weekday" => $_var_9, "day" => $_var_10, "hour" => $_var_11, "minute" => $_var_13));
			}
		}
	}
}
function wq_login_common_check_app($_arg_0, $_arg_1, $_arg_2 = "appbyme", $_arg_3 = '', $_arg_4 = '')
{
	if ($_arg_2 == "appbyme" && $_arg_1 && !C::t("#wq_login#appbyme_connection")->fetch_by_unionid($_arg_1)) {
		return wq_login_add_magapp_or_bymeapp_user($_arg_0, $_arg_1);
	}
	if ($_arg_2 == "magapp" && $_arg_1 && !wq_login_get_magappuserinfo_by_unionid($_arg_1)) {
		return wq_login_add_magapp_or_bymeapp_user($_arg_0, $_arg_1, false, $_arg_3);
	}
	if ($_arg_2 == "qianfanapp" && $_arg_1 && $_arg_4 && !C::t("#wq_login#thirdbind")->fetch_by_unionid($_arg_1)) {
		$_var_5 = array();
		$_var_5["uid"] = $_arg_0;
		$_var_5["weibotype"] = "wechat";
		$_var_5["unionid"] = $_arg_1;
		$_var_5["nickname"] = $_arg_4;
		$_var_5["dateline"] = TIMESTAMP;
		return C::t("#wq_login#thirdbind")->insert($_var_5);
	}
}
function wq_login_add_magapp_or_bymeapp_user($_arg_0, $_arg_1, $_arg_2 = true, $_arg_3 = '')
{
	$_arg_0 = dintval($_arg_0);
	if (!$_arg_0 || !$_arg_1) {
		return NULL;
	}
	if ($_arg_2) {
		$_var_4 = array("uid" => $_arg_0, "status" => 1, "type" => 1, "param" => $_arg_1);
		return C::t("#wq_login#appbyme_connection")->insert($_var_4);
	}
	$_var_5 = array("uid" => $_arg_0, "appid" => $_arg_3, "unionid" => $_arg_1);
	return wq_login_mag_adduser($_var_5);
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success";
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}
