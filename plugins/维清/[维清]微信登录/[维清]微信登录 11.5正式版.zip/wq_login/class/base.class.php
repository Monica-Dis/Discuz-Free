<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_login_base {

	public $lang;
	public $setting;

	function plugin_wq_login_base() {
		global $_G;
		include_once DISCUZ_ROOT . './source/plugin/wq_login/config/loadfunc.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_login/function/function_login.php';
		$this->lang = wq_loadlang('wq_login');

		$this->setting = wq_loadsetting('wq_login');
	}

	function qrcode_generate($url, $directory, $filename) {
		$dir = DISCUZ_ROOT . './data/cache/wq_login/' . $directory . '/';
		$file = $dir . $filename . '.png';
		if(!file_exists($file) || !filesize($file)) {
			require_once DISCUZ_ROOT . 'source/plugin/wq_login/class/qrcode.class.php';
			dmkdir($dir);
			QRcode::png($url, $file, QR_ECLEVEL_Q, 4);
		}
		return 'data/cache/wq_login/' . $directory . '/' . $filename . '.png';
	}

	function fetch_data_by_uid($uid) {
		return C::t('#wq_login#wq_login_member')->fetch_first_by_uid($uid);
	}

	function fetch_data_by_tid($tid = 0, $pid = 0) {
		if($pid) {
			return C::t("#wq_login#wq_login_posts_temporary1")->fetch_by_pid($pid);
		} else {
			return C::t("#wq_login#wq_login_posts_temporary")->fetch_by_tid($tid);
		}
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>