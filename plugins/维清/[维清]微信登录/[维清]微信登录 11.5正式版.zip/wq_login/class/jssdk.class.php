<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class WQJSSDK {
	private $appId;
	private $appSecret;
	private $url;

	public function __construct($appId, $appSecret, $url) {
		$this->appId = $appId;
		$this->appSecret = $appSecret;
		$this->url = $url;
	}

	public function getSignPackage() {
		$jsapiTicket = $this->getJsApiTicket();

		$timestamp = time();
		$nonceStr = $this->createNonceStr();

		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$this->url";

		$signature = sha1($string);

		$signPackage = array(
			"appId" => $this->appId,
			"nonceStr" => $nonceStr,
			"timestamp" => $timestamp,
			"url" => $this->url,
			"signature" => $signature,
			"rawString" => $string,
			"Ticket" => $jsapiTicket
		);

		return $signPackage;
	}

	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for($i = 0; $i < $length; $i ++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}

	private function getJsApiTicket() {
		global $_G;

		$data = unserialize($_G['setting']['wq_jsticket_' . $this->appId]);
		if($data->expire_time < time()) {
			$accessToken = $this->getAccessToken();

			$url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
			$res = json_decode($this->httpGet($url));

			$ticket = $res->ticket;
			if($ticket) {
				$data->expire_time = time() + 7000;
				$data->jsapi_ticket = $ticket;

				$settings = array('wq_jsticket_' . $this->appId => serialize($data));
				C::t('common_setting')->update_batch($settings);
				include_once libfile('function/cache');
				updatecache('setting');
			}
		} else {
			$ticket = $data->jsapi_ticket;
		}

		return $ticket;
	}

	public function getAccessToken($refresh = false) {
		global $_G;

		$data = unserialize($_G['setting']['wq_accesstoken_' . $this->appId]);

		if($data->expire_time < time() || $refresh) {
			$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";

			if($_G['cache']['plugin']['wq_login']['function_type'] == '2') {
				$content = file_get_contents($url);
			} else {
				$content = $this->httpGet($url);
			}
			$res = json_decode($content);
			if(!function_exists('savecache')) {
				require_once libfile('function/cache');
			}

			$getTokenLogs = array();
			$getTokenLogs[] = array(
				'dateline' => date('Y-m-d H:i:s', time()),
				'msg' => json_decode($content, true),
			);

			loadcache('getTokenLogs');
			$getCacheTokenLogs = getglobal('cache/getTokenLogs');
			if(!empty($getCacheTokenLogs)) {
				foreach($getCacheTokenLogs as $lkey => $lval) {
					$getTokenLogs[] = $lval;
				}
			}
			$getTokenLogs = array_slice($getTokenLogs, 0, 20);
			savecache('getTokenLogs', $getTokenLogs);


			$access_token = $res->access_token;
			if($access_token) {
				$data->expire_time = time() + 7000;
				$data->access_token = $access_token;

				$settings = array('wq_accesstoken_' . $this->appId => serialize($data));
				C::t('common_setting')->update_batch($settings);
				if(!function_exists('updatecache')) {
					require_once libfile('function/cache');
				}
				updatecache('setting');
			}
		} else {
			$access_token = $data->access_token;
		}
		return $access_token;
	}

	private function httpGet($url) {
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_URL, $url);

		$res = curl_exec($curl);
		curl_close($curl);

		return $res;
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>