<?php

/**
 * (C) dism-Taobao-com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: OAuth.class.php 2015-5-13 15:29:16Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class OAuth {

	private $_oAuthAuthorizeURL = 'https://open.weixin.qq.com/connect/oauth2/authorize';
	private $_accessTokenURL = 'https://api.weixin.qq.com/sns/oauth2/access_token';
	private $_getUserInfoURL = 'https://api.weixin.qq.com/sns/userinfo';

	const RESPONSE_ERROR = 999;
	const WECHAT_REDIRECT = "#wechat_redirect";

	public function __construct($AppId = '', $AppKey = '', $isapi = false) {
		global $_G;

		$AppId = !empty($AppId) ? $AppId : $_G['cache']['plugin']['wq_login']['appid'];
		$AppKey = !empty($AppKey) ? $AppKey : $_G['cache']['plugin']['wq_login']['appsecret'];

		$this->setAppkey($AppId, $AppKey);
		if(!$isapi) {
			if(!$this->_appKey || !$this->_appSecret) {
				throw new Exception('AppId Or AppSecret Invalid', __LINE__);
			}
		}
	}

	protected function setAppKey($appKey, $appSecret) {
		$this->_appKey = $appKey;
		$this->_appSecret = $appSecret;
	}

	private static function _dfsockopen($api, $get = array(), $post = array()) {
		global $_G;
		if($_G['cache']['plugin']['wq_login']['function_type'] == '2') {
			return file_get_contents($api . http_build_query($get));
		} else {
			return dfsockopen($api . http_build_query($get), 0, $post, '', false);
		}
	}

	private static function _convert($post) {
		if(is_array($post)) {
			foreach($post as $k => $v) {
				$post[$k] = diconv($v, 'UTF-8', CHARSET);
			}
		} else {
			$post = diconv($post, 'UTF-8', CHARSET);
		}

		return $post;
	}

	public function getOAuthAuthorizeURL($redirect_uri) {
		$params = array(
			'appid' => $this->_appKey,
			'redirect_uri' => $redirect_uri,
			'response_type' => 'code',
			'scope' => 'snsapi_userinfo',
			'state' => md5(FORMHASH),
		);

		return $this->_oAuthAuthorizeURL . '?' . http_build_query($params) . self::WECHAT_REDIRECT;
	}

	public function getOpenId($redirect_uri, $code) {
		$params = array(
			'appid' => $this->_appKey,
			'secret' => $this->_appSecret,
			'code' => $code,
			'grant_type' => 'authorization_code',
		);

		$response = $this->_dfsockopen($this->_accessTokenURL . '?', $params) . self::WECHAT_REDIRECT;
		$response = $this->rtrim_response($response);

		$result = json_decode($response, true);

		if($result['access_token'] && $result['refresh_token']) {
			return $result;
		} else {
			throw new Exception($result['errmsg'], $result['errcode']);
		}
	}

	public function getUserInfo($openId, $accessToken) {

		$params = array(
			'access_token' => $accessToken,
			'openid' => $openId,
			'lang' => 'zh_CN'
		);

		$response = $this->_dfsockopen($this->_getUserInfoURL . '?', $params);

		$result = json_decode($response, true);

		if(isset($result['openid']) && $result['nickname']) {
			return $result;
		} else {
			throw new Exception($result['errmsg'], $result['errcode']);
		}
	}

	function rtrim_response($response) {
		return rtrim($response, "#wechat_redirect");
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>