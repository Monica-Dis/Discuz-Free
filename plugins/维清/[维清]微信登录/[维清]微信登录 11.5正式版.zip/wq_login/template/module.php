<?php exit("Powered by www.wikin.cn"); ?>
{eval
function wq_login_tpl_login_extra_bar() {
global $_G;
}
	<!--{block return}-->
		<div class="fastlg_fm y" style="margin-right: 10px; padding-right: 10px">
			<p><a href="javascript:;" onclick="showWindow('wq_login_qrcode', 'plugin.php?id=wq_login&mod=scan')"><img src="source/plugin/wq_login/static/images/wechat_login.png" class="vm" /></a></p>
			<p class="hm xg1" style="padding-top: 2px;">{$_G['Plang']['scan_tips']}</p>
		</div>
	<!--{/block}-->
	<!--{eval return $return;}-->
{eval
}

function wq_login_tpl_user_bar() {
global $_G;
}
	<!--{block return}-->
		<span class="pipe">|</span><a href="javascript:;" onclick="showWindow('wq_login_qrcode', 'plugin.php?id=wq_login&mod=scan')"><img src="source/plugin/wq_login/static/images/wechat_bind.png" class="qq_bind" align="absmiddle" /></a>
	<!--{/block}-->
	<!--{eval return $return;}-->

{eval
}

function wq_login_tpl_login_bar() {
global $_G;
}
	<!--{block return}-->
		<a href="javascript:;" onclick="showWindow('wq_login_qrcode', 'plugin.php?id=wq_login&mod=scan')"><img src="source/plugin/wq_login/static/images/wechat_login.png" class="vm" /></a>
	<!--{/block}-->
	<!--{eval return $return;}-->
{eval
}

function wq_login_tpl_setting() {
global $_G;
}
	<!--{block return}-->
	<!--{if $_G['wq_login']['setting']['bind_place_site'] == 1}-->

		<!--{if $_G['wq_login']['setting']['is_open_unbind'] == 1 || !$_G['wq_wechatuser']['chgusername'] || !$_G['wq_wechatuser']['chgpassword']}-->
			<style type="text/css">
				#wq_login_menu li{clear:both}
				#wq_login_menu li a{ line-height: 18px; padding: 3px 5px;}
			</style>
			<span class="pipe">|</span>

			<a id="wq_login" href="javascript:;" class="showmenu" onmouseover="showMenu({'ctrlid': 'wq_login'})">{$_G['Plang']['fd32f2cf594cdeb8']}</a>
		<!--{/if}-->
	<!--{else}-->
		<!--{if !$_G['wq_wechatuser']}-->
			<span class="pipe">|</span>
			<a href="javascript:;" onclick="showWindow('bind', 'plugin.php?id=wq_login&mod=scan')">{$_G['Plang']['b9ba8c460766fdbd']}</a>
		<!--{else}-->
			<!--{if $_G['wq_login']['setting']['is_open_unbind'] == 1}-->
				<span class="pipe">|</span>
				<a href="javascript:;" onclick="showWindow('unbind', 'plugin.php?id=wq_login&mod=unbind')">{$_G['Plang']['3dd91b1eb846803e']}</a>
			<!--{/if}-->
			<!--{if !$_G['wq_wechatuser']['chgusername']}-->
				<span class="pipe">|</span>
				<a href="javascript:;" onclick="showWindow('changeusername', 'plugin.php?id=wq_login&mod=setting&ac=username')">{$_G['Plang']['c150fedb114eefa7']}</a>
			<!--{/if}-->
			<!--{if !$_G['wq_wechatuser']['chgpassword']}-->
				<span class="pipe">|</span>
				<a href="javascript:;" onclick="showWindow('changepassword', 'plugin.php?id=wq_login&mod=setting&ac=password')">{$_G['Plang']['d2d6d7bc7468d2b0']}</a>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
	<!--{/block}-->
	<!--{eval return $return;}-->

{eval
}
function wq_login_tpl_setting_menu() {
global $_G;
}
	<!--{block return}-->
		<ul id="wq_login_menu" class="p_pop" style="display: none;">
			<!--{if !$_G['wq_wechatuser']}-->
				<li><a href="javascript:;" onclick="showWindow('bind', 'plugin.php?id=wq_login&mod=scan')">{$_G['Plang']['b9ba8c460766fdbd']}</a></li>
			<!--{else}-->
			<!--{if $_G['wq_login']['setting']['is_open_unbind'] == 1}-->
				<li><a href="javascript:;" onclick="showWindow('unbind', 'plugin.php?id=wq_login&mod=unbind')">{$_G['Plang']['3dd91b1eb846803e']}</a></li>
			<!--{/if}-->
			<!--{if !$_G['wq_wechatuser']['chgusername']}-->
				<li><a href="javascript:;" onclick="showWindow('changeusername', 'plugin.php?id=wq_login&mod=setting&ac=username')">{$_G['Plang']['c150fedb114eefa7']}</a></li>
			<!--{/if}-->
			<!--{if !$_G['wq_wechatuser']['chgpassword']}-->
				<li><a href="javascript:;" onclick="showWindow('changepassword', 'plugin.php?id=wq_login&mod=setting&ac=password')">{$_G['Plang']['d2d6d7bc7468d2b0']}</a></li>
			<!--{/if}-->
			<!--{/if}-->
		</ul>
	<!--{/block}-->
	<!--{eval return $return;}-->

{eval
}

function wq_login_tpl_float_qrcode($idstr = '') {
global $_G;
}
	<!--{block return}-->
	<!--{if $_G['basescript'] != 'userapp' && empty($_G['cookie']['wq_login'])}-->
		<div id="wq_login_float_qrcode" class="p_pop xg1" style="display:none;text-align:center;float:left;position:fixed;top:220px;z-index:100;margin-left: 2px;width:110px">
			<p class="cl"><img class="y" style="cursor:pointer" onclick="display('wq_login_float_qrcode');
					setcookie('wq_login', 1, '$_G[wq_login][setting][qrcode_time]')" src="{STATICURL}image/common/ad_close.gif"></p>
			<img src="$idstr" width="98" />
			<p>
				<!--{if $_G['wq_login']['setting']['login_float_text']}-->
				{$_G[wq_login][setting][login_float_text]}
				<!--{else}-->
				{$_G['Plang']['fdb7da7ccc901dab']}<br/>{$_G['Plang']['0b8ce274bdbf8054']}
				<!--{/if}-->
			</p>
		</div>
		<script>
			function wq_login_qrcode(type) {
				if (type && $('wq_login_float_qrcode').style.display == 'none') {
					return;
				}
				var qrleft = parseInt($('ft').clientWidth + parseInt(fetchOffset($('ft'))['left']));
				$('wq_login_float_qrcode').style.display = '';
				if (qrleft + $('wq_login_float_qrcode').clientWidth > document.documentElement.clientWidth) {
					$('wq_login_float_qrcode').style.cssFloat = 'right';
					$('wq_login_float_qrcode').style.left = 'auto';
					$('wq_login_float_qrcode').style.right = 0;
				} else {
					$('wq_login_float_qrcode').style.cssFloat = 'left';
					$('wq_login_float_qrcode').style.left = (qrleft) + 'px';
					$('wq_login_float_qrcode').style.right = 'auto';
				}
			}
			_attachEvent(window, 'scroll', function () {
				wq_login_qrcode(1);
			})
			_attachEvent(window, 'load', function () {
				wq_login_qrcode(0);
			}, document);
		</script>
	<!--{/if}-->
	<!--{/block}-->
	<!--{eval return $return;}-->
{eval
}
}