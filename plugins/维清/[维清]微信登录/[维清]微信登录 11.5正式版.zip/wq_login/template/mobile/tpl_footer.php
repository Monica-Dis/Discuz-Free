<?php exit("Powered by www.wikin.cn"); ?>
<!--{if !empty($_G['inajax'])}-->
<!--{template wq_login:footer_ajax}-->
<!--{else}-->
<!--{template wq_login:footer}-->
<!--{/if}-->