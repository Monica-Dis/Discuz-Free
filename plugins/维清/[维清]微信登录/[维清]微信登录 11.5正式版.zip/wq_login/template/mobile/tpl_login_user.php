<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval $header_nav='null';}-->
<!--{eval $nohead_color=1;}-->
<!--{template common/header}-->
<link rel="stylesheet" href="source/plugin/wq_login/static/css/wq_login.css" type="text/css" media="all">
<link rel="stylesheet" href="source/plugin/wq_login/font/iconfont.css" type="text/css" media="all">
<script type="text/javascript" src="./source/plugin/wq_login/static/js/wqxml.js" reload="1"></script>
<script>
    if (window.devicePixelRatio && devicePixelRatio >= 2 && navigator.userAgent.toLowerCase().match(/iphone/i) == "iphone") {
        document.getElementsByTagName('html')[0].className = 'retina';
    }

    var _w, _fsize;
    orientationChange = function() {
        var html = document.documentElement;
        _w = html.clientWidth || document.body.clientWidth,
                _fsize = _w / 320 * 20;
        html.setAttribute('style', 'font-size:' + _fsize + 'px');
    }
    orientationChange();
    window.addEventListener("resize", orientationChange, !1);</script>
<div class="weixin_data wx_m_t20">
    <dl class="b_bottom">
        <dd>{$Plang['20271ac60b472d14']}</dd>
        <dt>$_G[username]</dt>
    </dl>
    <dl class="b_bottom">
        <dd>{$Plang['3982634cd20768c9']}</dd>
        <dt>$wq_wechatuser[weixinname]</dt>
    </dl>
    <dl class="b_bottom">
        <dd>{$Plang['residearea']}</dd>
        <dt><!--{echo $wq_wechatuser['area'] ? $wq_wechatuser['area'] : $Plang['nodata'] ;}--></dt>
    </dl>
    <dl class="b_bottom">
        <dd>{$Plang['sex']}</dd>
        <dt>$Plang['sex_'.$wq_wechatuser[sex]]</dt>
    </dl>

    <dl class="b_bottom">
        <dd>{$Plang['60ee78ec85f40105']}</dd>
        <dt><!--{echo $wq_wechatuser['authorizetime'] ? date("Y-m-d H:i:s", $wq_wechatuser['authorizetime']) : $Plang['nodata'] ;}--></dt>
    </dl>
    <dl class="b_bottom">
        <dd>{$Plang['df00113d3deebc8e']}</dd>
        <dt><!--{echo $wq_wechatuser['dateline'] ? date("Y-m-d H:i:s", $wq_wechatuser['dateline']) : $Plang['nodata'] ;}--></dt>
    </dl>
</div>
<div class="weixin_data wq_login_ajax">
	<!--{if $setting['is_open_unbind'] == 1}-->
    <dl class="b_bottom">
        <a href="plugin.php?id=wq_login&mod=unbind&handlekey=unbind" id="unbind">
            <dd>{$Plang['274484284a6db94f']}</dd>
            <dt><em class="wqiconfont wqicon-youyou c_jt"></em></dt>
        </a>
    </dl>
	<!--{/if}-->
    <!--{if !$wq_wechatuser['chgusername']}-->
    <dl class="b_bottom">
        <a href="plugin.php?id=wq_login&mod=setting&ac=username&handlekey=changeusername" id="changeusername">
            <dd>{$Plang['c150fedb114eefa7']}</dd>
            <dt><em class="wqiconfont wqicon-youyou c_jt"></em></dt>
        </a>
    </dl>
    <!--{/if}-->
    <!--{if !$wq_wechatuser['chgpassword']}-->
    <dl class="b_bottom">
        <a href="plugin.php?id=wq_login&mod=setting&ac=password&handlekey=changepassword" id="changepassword">
            <dd>{$Plang['d2d6d7bc7468d2b0']}</dd>
            <dt><em class="wqiconfont wqicon-youyou c_jt"></em></dt>
        </a>
    </dl>
    <!--{/if}-->
</div>
<!--{eval $wq_smslogin_password = 0;}-->
<!--{if $_G['cookie']['wq_smslogin_password']}-->
<!--{eval $wq_smslogin_password = $_G['cookie']['wq_smslogin_password']}-->
<!--{/if}-->
<script>
    var myArray = new Array(), wq_focus = popmenu_top = post_submit = false;
    var wq_smslogin_password = {$wq_smslogin_password};
    $(function() {
        $('.wq_login_ajax a').click(function() {
            var wq_id = $(this).attr('id');
            if (myArray[wq_id]) {
                popup.open(myArray[wq_id]);
            } else {
                $.post(
                        $(this).attr('href'),
                        {inajax: '1'},
                function(s) {
                    popup.open(wqXml(s));
                    myArray[wq_id] = wqXml(s);
                }, 'html');
            }
            post_submit = false;
            return false;
        });
        $('body').on('focus', '#ntcmsg_popmenu input:password,#ntcmsg_popmenu input:text', function(i) {
            popmenu_top = $('#ntcmsg_popmenu').css('top');
            $('#ntcmsg_popmenu').css({top: "auto", bottom: "0"});
            if (!$('#ntcmsg_popmenu button:submit').attr('data')) {
                $('#ntcmsg_popmenu button:submit').on('tap', function() {
                    $('#ntcmsg_popmenu input:text,#ntcmsg_popmenu input:password').each(function(s) {
                        if ($(this).is(':focus')) {
                            wq_focus = true;
                            return true;
                        }
                    });
                    $('#ntcmsg_popmenu form').submit();
                });
                $('#ntcmsg_popmenu button:submit').attr('data', 1);
            }
        }).on('blur', '#ntcmsg_popmenu input:password,#ntcmsg_popmenu input:text', function(i) {
            $('#ntcmsg_popmenu').css({top: popmenu_top, bottom: "auto"});
        });
    });
    function wq_popup_closes(odj, handlekey) {
        $.post(odj.attr('action'), odj.serialize(), function(s) {
            post_submit = handlekey;
            popup.open(wqXml(s));
            $('#mask,[onclick="popup.close();"]').on('tap', function() {
                if (post_submit) {
                    popup.open(myArray[post_submit]);
                    if (wq_focus) {
                        $('#ntcmsg_popmenu input:text,#ntcmsg_popmenu input:password').each(function(s) {
                            $(this).focus();
                            return false;
                        });
                        wq_focus = false;
                    }
                    post_submit = false;
                }
            });
        }, 'html');
    }

    if (wq_smslogin_password == 1) {
        setTimeout(function() {
            $('#changepassword').click();
        }, '800');
    }

    function succeedhandle_changepassword(url, msg) {
        if ($.trim(msg) == "{$Plang['668259cd833b1be4']}") {
            post_submit = false;
            $('#changepassword').parent().remove();
            myArray['unbind'] = '';
            setTimeout(function() {
                if (wq_smslogin_password == 1) {
                    window.location.href = 'home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1';
                } else {
                    popup.close();
                }
            }, '1000');
        }
    }
    function succeedhandle_changeusername(url, msg) {
        if ($.trim(msg) == "{$Plang['78b1255b087df664']}") {
            post_submit = false;
            $('#changeusername').parent().remove();
            setTimeout(function() {
                popup.close();
            }, '1000');
        }
    }

    function succeedhandle_unbind(url, msg) {
        if ($.trim(msg) == "{$Plang['16f7a468fd1793a9']}") {
            post_submit = false;
            setTimeout(function() {
                location.href = 'home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1'
            }, '800');
        }
    }


</script>
<!--{eval $wq_footer_hide='1';}-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->