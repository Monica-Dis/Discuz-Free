<?php exit("Powered by www.wikin.cn"); ?>
<style>
/*��ɫ��ʽ*/
.wqheader_login_one,.wqname_info_one .wqbtn_login button{background: {$this->setting['loginpage_color']};}
.wqswitch_page_one a.wqon{border-bottom: 2px solid {$this->setting['loginpage_color']};}
.wqname_info_one ul li.wqiphone .wqobtain_code{ border:1px solid {$this->setting['loginpage_color']}; }
.wqregister_back_one a,.wqname_info_one ul li.wqiphone .wqobtain_code,.wqswitch_page_one a.wqon{ color: {$this->setting['loginpage_color']};}

.wqphone_login_two .wqbtn_login button,.wqphone_login_two .wqinput_warp .wqiphone .wqobtain_code{  background: {$this->setting['loginpage_color']};}
.wqregister_back_two a,.wqphone_login_two .wqbtn_iphone a{ color: {$this->setting['loginpage_color']};}

.wqphone_login_three .wqinput .wqiphone .wqobtain_code,.wqphone_login_three .wqbtn_login button{  background: {$this->setting['loginpage_color']};}
.wqphone_login_three .wqbtn_register a{border: 1px solid {$this->setting['loginpage_color']}; }
.wqphone_login_three .wqforget_password a,.wqphone_login_three .wqbtn_register a{color: {$this->setting['loginpage_color']};}

.wqswitch_four .wqtitle a.wqon{  border-bottom: 1px solid {$this->setting['loginpage_color']};}
.wqbtn_login_four button{background: {$this->setting['loginpage_color']};}
.wqregister_back_four a,.wqswitch_four .wqtitle a.wqon,.wqname_info_four ul li.wqiphone .wqobtain_code{ color: {$this->setting['loginpage_color']};}
.wqname_info_four ul li.wqiphone .wqobtain_code{border:1px solid {$this->setting['loginpage_color']};}

</style>