<?php exit("Powered by www.wikin.cn"); ?>
<!--{eval $wq_login = $_G['cache']['plugin']['wq_login'];}-->

<if if="!defined('WQ_IN_WECHAT') && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false">
	<!--{eval define("WQ_IN_WECHAT", true);}-->
</if>

<if if="CURSCRIPT == 'forum' && CURMODULE == 'viewthread'">
	<ifif>
		<!--{eval $sharetitle = $_G[forum_thread][subject];}-->
	</ifif>
	<else>
		<!--{eval $sharetitle = !empty($navtitle) ? $navtitle : $_G['setting']['bbname'];}-->
	</else>
</if>
<!--{eval
	$description = !empty($metadescription) ? dhtmlspecialchars($metadescription) : $_G['setting']['bbname'];
	$imgbase=null;
}-->

<if if="$wq_login['appid'] && defined('WQ_IN_WECHAT')">
	<script src="//res.wx.qq.com/open/js/jweixin-1.0.0.js?{VERHASH}" type="text/javascript"></script>
	<script type="text/javascript">
		$(function () {
			var sharetitle = "{$sharetitle}";
			var wxclassname = "{$wxclassname}";
			var siteurl = "{$_G['siteurl']}";
			var formhash = "{FORMHASH}";
			var bbname = "{$_G['setting']['bbname']}";

			if(sharetitle) {
				common_wxShare('{$sharetitle}', '{$imgbase}', '{$description}');
			}

			if(wxclassname) {
				common_wxImagePreview('{$wxclassname}');
			}
		})

		function common_wxShare(title, imgbase, description) {
			$.ajax({
				url: siteurl + "/plugin.php?id=wq_login",
				type: 'post',
				dataType: 'json',
				data: {
					mod: "jssign",
					jssignsubmit: "true",
					pageurl: document.location.href,
					formhash: formhash,
				}
			}).success(function (sign) {
				if(sign['errcode'] == '0') {
					wx.config({
						debug: false,
						appId: sign['appId'],
						timestamp: sign['timestamp'],
						nonceStr: sign['nonceStr'],
						signature: sign['signature'],
						jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareQZone', 'previewImage', 'openLocation', 'getLocation']
					});
				}
			});

			var description = description ? description : $('meta[name="description"]').attr('content');
			var imgbase = imgbase ? imgbase : ($('.wqshare_wx img:eq(0)').prop('src') ? $('.wqshare_wx img:eq(0)').prop('src') : '$wq_login[share_logo]');
			var title = title ? title : bbname;

			var imgUrl = imgbase;
			if(imgUrl.indexOf('http') == -1) {
				imgUrl = siteurl + imgUrl;
			}
			imgUrl = imgUrl.replace('https','http');
			wx.ready(function () {
				var wx_share_data = {
					title: title,
					desc: description,
					link: window.location.href,
					imgUrl: imgUrl,
				}
				wx.onMenuShareAppMessage(wx_share_data);
				wx.onMenuShareQQ(wx_share_data);
				wx.onMenuShareQZone(wx_share_data);
				wx.onMenuShareWeibo(wx_share_data);
				wx.onMenuShareTimeline(wx_share_data);
			});
		}

		function common_wxImagePreview(classname) {
			var i = 0, obj_img = new Array();
			if(!classname) {
				return;
			}
			$('.' + classname + ' img').each(function (i) {
				if($(this).parents('a').length || $(this).hasClass('wq_smilieimg'))
					return;
				var src = $(this).attr('wqdata-src');
				obj_img[i] = src ? src : $(this).attr('src');
				if(obj_img[i].indexOf('http') == "-1") {
					obj_img[i] = siteurl + obj_img[i];
				}
				i++;
			});
			$('.' + classname + ' img').click(function () {
				if($(this).parents('a').length || $(this).hasClass('wq_smilieimg'))
					return;
				var img = $(this).attr('wqdata-src');
				img = img ? img : $(this).attr('src');
				if(img.indexOf('http') == "-1") {
					img = siteurl + img;
				}
				wx.previewImage({
					current: img,
					urls: obj_img
				});
				return false;
			});
		}
	</script>
</if>