<?php exit("Powered by www.wikin.cn"); ?>
<!--{template wq_login:tpl_header}-->
<link rel="stylesheet" href="{$fileUrl}css/wq_phonelogin.css" type="text/css">
<!--{if !empty($_GET['inajax'])}-->
    <div class="wqcustomer_tanchu {if $this->setting[wechat_login_style]=='3'}wqcustomer_tanchu_f0{/if}">
    <!--{if $this->setting[wechat_login_style]=='3' || $this->setting[wechat_login_style]=='4'}-->
        <div class="wqclose_bardian">
            <a href="javascript:;popup.close();"><img src="./source/plugin/wq_login/static/mobile/images/wqclose_bardian.png"></a>
        </div>
    <!--{/if}-->
 <!--{/if}-->
    <!--{if $ac=='sms' && $plugin_wq_smslogin }-->
        <script reload="1">
            var InterValObj;
            var count = "{$wq_smslogin_setting['waiting_time']}";
            var curcount;
            var new_send = "{$_G['Plang'][4tdfg345gt4r5y46]}";
            var seconds = "{$_G['Plang'][4tryg5hb89o89646]}";
            var formhash = "{FORMHASH}";
            var wq_btn = "#get_verify";
            var wq_input = "#mobile_num1";
            var module = "login";
            var is_seccode = "{$wq_smslogin_setting[is_seccode]}";
            var mobile_password_lgoin = "{$wq_smslogin_setting['mobile_password_lgoin']}";
            var referer="{$backurl}";
        </script>
        <script type="text/javascript" src="./source/plugin/wq_login/static/js/wqxml.js" reload="1"></script>
        <link rel="stylesheet" href="source/plugin/wq_smslogin/static/css/common_message.css" type="text/css" >
        <script type="text/javascript" src="./source/plugin/wq_smslogin/static/js/common_message.js" reload="1"></script>
        <script src="source/plugin/wq_smslogin/static/js/verify.js?{VERHASH}" type="text/javascript" reload="1"></script>
    <!--{else}-->
        <script type="text/javascript" reload="1">
            $(function() {
                function wq_getcookie(name) {
                    var cookie_start = document.cookie.indexOf(name);
                    var cookie_end = document.cookie.indexOf(";", cookie_start);
                    if(cookie_start == -1) {
                            return '';
                    } else {
                            var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
                            return unescape(v) ;
                    }
                }

                $(document).on('change', '.wq_sel_list', function() {
                    var obj = $(this);
                    if (obj.val() == 0) {
                            $('.wq_answerli').hide();
                    } else {
                            $('.wq_answerli').show();
                    }
                });
            });
        </script>
    <!--{/if}-->

	<!--{template wq_login:setcolor}-->

    <!--{if $this->setting['wechat_login_style']=='1'}-->
        <!--{template wq_login:tpl_login_login_m}-->
    <!--{elseif $this->setting['wechat_login_style']=='2'}-->
        <!--{template wq_login:tpl_login_login_g}-->
    <!--{elseif $this->setting['wechat_login_style']=='3'}-->
        <!--{template wq_login:tpl_login_login_a}-->
    <!--{elseif $this->setting['wechat_login_style']=='4'}-->
        <!--{template wq_login:tpl_login_login_c}-->
    <!--{/if}-->

    <!--{if !empty($_GET['inajax'])}-->
        </div>
    <!--{/if}-->
<!--{eval $nofooter='1';}-->
<!--{template wq_login:tpl_footer}-->