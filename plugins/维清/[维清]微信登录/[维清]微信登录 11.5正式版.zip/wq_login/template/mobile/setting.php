<?php exit("Powered by www.wikin.cn"); ?>
<!--{template common/header}-->
<div class="f_c bd_weinxin">
    <!--{if $_G['uid'] && $_GET['ac'] == 'username'}-->
    <h3 class="flb b_bottom">
        <em id="return_$_GET['handlekey']">{$Plang['c150fedb114eefa7']}</em>
        <span><i class="wqiconfont wqicon-icon32 weixin_close f18" onclick="popup.close()"></i></span>
    </h3>
    <form method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=setting&ac=username&inajax=yes"onsubmit="wq_popup_closes($(this), '$_GET[handlekey]'); return false;">
        <div class="c cl">
            <input type="hidden" name="handlekey" value="$_GET['handlekey']"/>
            <input type="hidden" name="formhash" value="{FORMHASH}"/>
            <input type="hidden" name="confirmsubmit" value="true"/>
            <div class="rfm mtn">
                <p>{$_G['username']}</p>
                <p><input type="text" id="newusername" name="newusername" class="px p_fre b_all" placeholder="{$Plang['00604ba66eee492b']}" /></p>
            </div>
            <div class="rfm mbw bw0">
                <div><button class="pn pnc wx_button" type="submit">{lang submit}</button></div>
            </div>
        </div>
    </form>
    <!--{elseif $_G['uid'] && $_GET['ac'] == 'password'}-->
    <h3 class="flb b_bottom">
        <em id="return_$_GET['handlekey']">{$Plang['d2d6d7bc7468d2b0']}</em>
        <span><i class="wqiconfont wqicon-icon32 weixin_close f18" onclick="popup.close()"></i></span>
    </h3>
    <form  method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=setting&ac=password&inajax=yes" onsubmit="wq_popup_closes($(this), '$_GET[handlekey]'); return false;">
        <input type="hidden" name="handlekey" value="$_GET['handlekey']"/>
        <input type="hidden" name="formhash" value="{FORMHASH}"/>
        <input type="hidden" name="confirmsubmit" value="true"/>
        <div class="c cl">
            <div class="rfm mtn">
                <p><input type="password"  name="newpassword" placeholder="{$Plang['248be805e4c69add']}"  class="px p_fre b_all"/></p>
                <p class="wx_m_t20"><input id="inppassword" type="password" name="confirmpassword" placeholder="{$Plang['6d652abb35b3994a']}" class="px p_fre"/></p>
            </div>
            <div class="rfm mbw bw0">
                <div>
                    <button class="pn pnc wx_button" type="submit">{lang submit}</button>
                </div>
            </div>
        </div>
    </form>
    <!--{/if}-->
</div>
<!--{template common/footer}-->