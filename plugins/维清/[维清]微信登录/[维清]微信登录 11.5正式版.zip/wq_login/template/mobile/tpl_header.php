<?php exit("Powered by www.wikin.cn"); ?>
<!--{if !empty($_G['inajax'])}-->
<!--{template wq_login:header_ajax}-->
<!--{else}-->
<!--{template wq_login:header}-->
<!--{/if}-->