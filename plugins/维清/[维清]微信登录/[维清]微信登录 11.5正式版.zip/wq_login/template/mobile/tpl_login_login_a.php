<?php exit("Powered by www.wikin.cn"); ?>
<style>body{ background-color: #f0f0f0 !important;}</style>
<div class="wq_logo_two"><a href="javascript:;"><img src="{$fileUrl}images/{$this->setting['mobile_wechat_logo']}"></a></div>
<!--{if $ac=='sms' && $plugin_wq_smslogin }-->
<div class="wqphone_login_two">
    <form method="post" autocomplete="off">
            <div class="wqinput_warp">
                <ul>
                    <li class="{if $wq_smslogin_setting['mobile_password_lgoin'] == 0}wqiphone{/if} wqiphone_bottom">
                        <input id="mobile_num1" name="mobile" type="text" maxlength="11" placeholder="{$_G['Plang']['df431c61a82e97fb']}">
                        <!--{if $wq_smslogin_setting['mobile_password_lgoin'] == 0}-->
                            <button  id="get_verify" type="button" disabled="disabled"  class="wqobtain_code"  data-url="plugin.php?id=wq_smslogin&mod=sendcode&loginsubmit=yes">{$_G['Plang']['7cacbc7cb1040b8a']}</button>
                        <!--{/if}-->
                    </li>

                    <!--{if $wq_smslogin_setting['mobile_password_lgoin'] == 0}-->
                        <li class="wqiphone_bottom"><input id="verify1" type="text" name="verfiy" placeholder="{$_G['Plang']['404c9038b656cb7a']}"></li>
                    <!--{else}-->
                        <li class="wqiphone_bottom"><input id="phone_password" type="password" name="avBu4z" placeholder="{$_G['Plang']['bda5051be3094609']}"></li>
                    <!--{/if}-->
                </ul>
            </div>
            <div class="wqbtn_iphone"><a href="member.php?mod=logging&action=login&referer={$backurl}">{$_G['Plang']['a6064854d035e59c']}</a></div>
            <div class="wqbtn_login"><button id="loginsubmit" value="true" name="submit" type="submit">{$_G['Plang']['e0ebc819d8ccd251']}</button></div>
    </form>
    <div class="wqregister_back_two">
        <a href="plugin.php?id=wq_smslogin&mobile=2" class="wqregister">{$_G['Plang']['a6b898a1b07cb9ff']}</a><span class="wqline"></span>
        <a href="plugin.php?id=wq_smslogin&mod=password" class="wqback">{$_G['Plang']['8891d1684ab9453f']}</a>
    </div>
</div>
<!--{else}-->
    <div class="wqphone_login_two">
        <form id="loginform" method="post" autocomplete="off"   action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
            <input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
            <input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
            <input type="hidden"  name="cookietime"  value="2592000"/>
            <input type="hidden" name="fastloginfield" value="username">
            <input type="hidden" name="cookietime" value="2592000">
            <div class="wqinput_warp">
                <ul>
                    <li class="wqiphone_bottom"><input type="text" name="username" placeholder="{lang inputyourname}"></li>
                    <li class="wqiphone_bottom"><input type="password"  name="password" placeholder="{lang login_password}"></li>
                    <li class="wqiphone_bottom">
                        <select name="questionid" class='wq_sel_list'>
                            <option value="0" selected="selected">{lang security_question}</option>
                            <option value="1">{lang security_question_1}</option>
                            <option value="2">{lang security_question_2}</option>
                            <option value="3">{lang security_question_3}</option>
                            <option value="4">{lang security_question_4}</option>
                            <option value="5">{lang security_question_5}</option>
                            <option value="6">{lang security_question_6}</option>
                            <option value="7">{lang security_question_7}</option>
                        </select>
                    </li>
                    <li style="display:none;" class="wq_answerli wqiphone_bottom">
                        <input  type="text" name="answer" placeholder="{lang security_a}">
                    </li>
                    <!--{if $seccodecheck}-->
                        <li class="wqiphone_bottom">
                            <!--{subtemplate common/seccheck}-->
                        </li>
                    <!--{/if}-->
                </ul>
            </div>
            <!--{if $plugin_wq_smslogin }-->
                <div class="wqbtn_iphone"><a href="plugin.php?id=wq_smslogin&mod=login&referer={$backurl}">{$_G['Plang']['c650c87f95fb485a']}</a></div>
			<!--{else}-->
			<div class="wqbtn_iphone_none"></div>
            <!--{/if}-->
            <div class="wqbtn_login"><button  class='formdialog' type="submit" name="submit" value="true" >{$_G['Plang']['e0ebc819d8ccd251']}</button></div>
        </form>
        <div class="wqregister_back_two">
            <a href="member.php?mod={$_G['setting']['regname']}&mobile=2" class="wqregister">{$_G['Plang']['a6b898a1b07cb9ff']}</a><span class="wqline"></span>
            <a href="member.php?mod=logging&action=login&viewlostpw=1" class="wqback">{$_G['Plang']['8891d1684ab9453f']}</a>
        </div>
    </div>
<!--{/if}-->
<div class="wqother_login_two" style="margin-top: 25px;">
    <div class="wqtitle">{$_G['Plang']['2221387b71e0393a']}</div>
    <div class="wqicon_warp">
        <div class="wqicon">
            <a href="plugin.php?id=wq_login&mod=access&referer={$backurl}"><span><img src="{$fileUrl}images/wqwhite_weixin.png"></span></a>
            <!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
            <a href="{$_G[connect][login_url]}&statfrom=login_simple&referer={$backurl}"><span class="wqqq"><img src="{$fileUrl}images/wqwhite_qq.png"></span></a>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['wq_qqlogin']}-->
            <a href="plugin.php?id=wq_qqlogin&mod=access&op=init&referer={$backurl}"><span class="wqqq"><img src="{$fileUrl}images/wqwhite_qq.png"></span></a>
            <!--{/if}-->
        </div>
    </div>
</div>