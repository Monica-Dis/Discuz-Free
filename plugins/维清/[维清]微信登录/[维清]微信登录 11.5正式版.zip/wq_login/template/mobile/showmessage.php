<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $param['login']}-->
<!--{if $_G['inajax']}-->
<!--{eval dheader('Location:member.php?mod=logging&action=login&inajax=1&infloat=1');exit;}-->
<!--{else}-->
<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{/if}-->
<!--{eval $showmessage='1';}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="ass_fl">
    <dt id="messagetext">
    <!--{if $url_forward && !$_GET['loc']}-->
    <script type="text/javascript"  reload="1">
        setTimeout_location = setTimeout(function () {
            window.location.href = '$url_forward';
        }, '1000');
    </script>
    <!--{/if}-->
    <p>$show_message</p>
    <!--{if $_G['forcemobilemessage']}-->
    <p>
        <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br/>
        <a href="javascript:history.back();">{lang goback}</a>
    </p>
    <!--{/if}-->
    <!--{if $url_forward && !$_GET['loc']}-->
    <!--<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>-->
    <!--{elseif $allowreturn}-->
    <script type="text/javascript"  reload="1">
        setTimeout_location =setTimeout(function () {
            popup.close();
        }, '1500');
    </script>
    <!--{/if}-->
    </dt>
</div>
<!--{else}-->
<!-- main jump start -->
<div class="jump_c">
    <p>$show_message</p>
    <!--{if $_G['forcemobilemessage']}-->
    <p>
        <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
        <a href="javascript:history.back();">{lang goback}</a>
    </p>
    <!--{/if}-->
    <!--{if $url_forward}-->
	<!--{if $url_forward && !$_GET['loc']}-->
    <script type="text/javascript"  reload="1">
        setTimeout_location = setTimeout(function () {
            window.location.href = '$url_forward';
        }, '1000');
    </script>
    <!--{/if}-->
    <p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>
    <!--{elseif $allowreturn}-->
    <p><a class="grey" href="javascript:history.back();">{lang message_go_back}</a></p>
    <!--{/if}-->
</div>
<!-- main jump end -->
<!--{/if}-->
<!--{template common/footer}-->