<?php exit("Powered by www.wikin.cn"); ?>
{eval
function tpl_login_profile($_G) {
}
<!--{block return}-->
<script type="text/javascript" src="./source/plugin/wq_login/static/js/wqxml.js" reload="1"></script>
<link rel="stylesheet" href="source/plugin/wq_login/font/iconfont.css" type="text/css" media="all">
<div class="dz_wx_bind">
    <!--{if !$_G['wq_wechatuser']}-->
    <a id="wq_login_bind" href="plugin.php?id=wq_login&mod=scan&handlekey=wq_login_bind&&mobile=2"><span></span>&#x7ED1;&#x5B9A;&#x5FAE;&#x4FE1;<em class="wqiconfont wqicon-youyou c_jt"></em></a>
    <script type="text/javascript" reload="1">
        var myArray = new Array(), wq_focus = popmenu_top = wq_resize = post_submit = false;
        $(function() {
            $('#wq_login_bind').click(function() {
                var wq_id = $(this).attr('id');
                if (myArray[wq_id]) {
                    popup.open(myArray[wq_id]);
                } else {
                    $.post($(this).attr('href'), {inajax: 1}, function(s) {
                        popup.open(wqXml(s));
                        myArray[wq_id] = wqXml(s);
                    }, 'html');
                }
                post_submit = false;
                return false;
            });
        });
        function wq_popup_closes(obj, handlekey) {
            $.post(obj.attr('action'), obj.serialize(), function(s) {
                post_submit = handlekey;
                popup.open(wqXml(s));
                $('#mask,[onclick="popup.close();"]').on('tap', function() {
                    if (post_submit) {
                        popup.open(myArray[post_submit]);
                        if (wq_focus) {
                            $('#ntcmsg_popmenu input:text,#ntcmsg_popmenu input:password').each(function(s) {
                                $(this).focus();
                                return false;
                            });
                            wq_focus = false;
                        }
                        post_submit = false;
                    }
                });
            }, 'html');
        }
        $('body').on('focus', '#ntcmsg_popmenu #wq_login_passwordconfirm', function(i) {
            popmenu_top = $('#ntcmsg_popmenu').css('top');
            $('#ntcmsg_popmenu').css({top: "auto", bottom: "0"});
            if (!$('#ntcmsg_popmenu button:submit').attr('data')) {
                $('#ntcmsg_popmenu button:submit').on('tap', function() {
                    $('#ntcmsg_popmenu input:text,#ntcmsg_popmenu input:password').each(function(s) {
                        if ($(this).is(':focus')) {
                            wq_focus = true;
                            return true;
                        }
                    });
                    $('#ntcmsg_popmenu form').submit();
                });
                $('#ntcmsg_popmenu button:submit').attr('data', 1);
            }
        }).on('blur', '#ntcmsg_popmenu input:password', function(i) {
            $('#ntcmsg_popmenu').css({top: popmenu_top, bottom: "auto"});
        });
    </script>
    <!--{else}-->
    <a href="plugin.php?id=wq_login&mod=user"><span></span>&#x6211;&#x7684;&#x5FAE;&#x4FE1;<em class="wqiconfont wqicon-youyou c_jt"></em></a>
    <!--{/if}-->
</div>

<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

}