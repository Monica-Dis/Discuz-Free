<?php exit("Powered by www.wikin.cn"); ?>
<!--{if $_G['uid']}-->
<!--{template common/header}-->
<div class="f_c bd_weinxin" style="position: relative;">
    <h3 class="flb bottom">
        <em id="return_$_GET['handlekey']">{$Plang['b9ba8c460766fdbd']}</em>
        <span><i class="wqiconfont wqicon-icon32 weixin_close f18" onclick="popup.close()"></i></span>
    </h3>
    <form method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=scan&inajax=yes&ac=bind" onsubmit="wq_popup_closes($(this), '$_GET[handlekey]');
			return false;">
        <input type="hidden" name="formhash" value="{FORMHASH}"/>
        <input type="hidden" name="handlekey" value="<!--{eval echo dhtmlspecialchars($_GET['handlekey']);}-->"/>
        <input type="hidden" name="confirmsubmit" value="true"/>
        <div class="c cl">
			<!--{if !$setting['bind_is_write_password']}-->
				<p>{$Plang['928e3b830545ca23']}</p>
			<!--{else}-->
				<div class="rfm mtn">
					<p>{$Plang['d64d8600d92b67e8']}</p>
					<p><input type="password" id="passwordconfirm" name="passwordconfirm" placeholder="{$Plang['dcaf7337b45e0aca']}" class="px p_fre b_all"/></p>
				</div>
			<!--{/if}-->
            <div class="rfm mbw bw0">
                <p><button class="pn pnc wx_button" type="submit">{lang submit}</button></p>
            </div>
        </div>
    </form>
</div>
<!--{template common/footer}-->
<!--{/if}-->