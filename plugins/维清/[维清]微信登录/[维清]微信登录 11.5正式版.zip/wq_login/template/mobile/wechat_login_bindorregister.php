<?php exit("Powered by www.wikin.cn"); ?>
<!--{template common/header}-->
<link rel="stylesheet" href="source/plugin/wq_login/static/css/wq_login.css" type="text/css">
<link rel="stylesheet" href="source/plugin/wq_login/static/font/iconfont.css" type="text/css">
<link rel="stylesheet" href="source/plugin/wq_login/static/css/common_message.css" type="text/css">
<script type="text/javascript" src="./source/plugin/wq_login/static/js/wqxml.js"></script>
<script type="text/javascript" src="./source/plugin/wq_login/static/js/common_message.js"></script>
<style>
    body{ background: #f0f0f0;}
    #big_div{position: absolute;top:0px;left: 0px;width: 100%;height: 100%;z-index: 20;background: #fff; font-size: 16px;font-family: Microsoft YaHei;}
    .wq_login_close{ text-align: center; margin-top: 50px; padding:0px 20px;}
    .wq_login_close input{ text-decoration: none; display: block; width: 100%;color: #fff; line-height: 44px; background: #04be01; border: 1px solid #04be01; font-size: 16px; margin-bottom: 10px ; border-radius: 5px;}
    .wq_login_close .zc_yj { margin-top: 50px; }
    .wq_login_close .zc_newname input{ color: #fff; background: #4e97e1;border: 1px solid #4e97e1;}
    .wq_login_dui{ width: 80px; height: 80px; background: #04be01; border-radius: 50px; color: #fff; line-height: 80px;margin: auto;}
    .wq_login_close .wq_login_dui i{ font-size: 34px;}
    .wq_login_close .wq_login_ts{ margin-top: 20px; line-height: 30px;}

    .wq_login_bd{ padding:0px 20px;}
    .wq_login_bd h3{ font-weight: normal; line-height: 64px;}
    .wq_login_bd ul{ border-bottom: 1px solid #dedede}
    .wq_login_bd ul li{ border: 1px solid #dedede;border-bottom: none;}
    .wq_login_bd input,.wq_login_bd select{ width: 98%; line-height: 40px;font-weight: normal; border: none;padding-left: 2%;height: 40px;}
    .wq_login_bd select{ width: 100%; color: #888;}
    .wq_login_bd .wqlogin_determine input{ width: 100%; font-size: 16px; background: #04be01; border: none; margin-top:20px; line-height: 44px; border-radius: 5px; color: #fff;}
    .wq_login_bd .zc_newname input{  width: 100%;text-align: center; line-height: 40px; background: #fff; border-radius: 3px; margin-top: 10px; border: 1px solid #e5e5e5; border-radius: 5px;}
    .wq_login_bd .zc_newname input{ color:#333; display: block;}
</style>
<div id="big_div">
    <!--{if !$select}-->
    <!--{eval $param = $tml_param;}-->
    <!--{/if}-->
    <form id="oauth_succeed_form" method="post" autocomplete="off">
        <input type="hidden" name="formhash" value="{FORMHASH}"/>
        <input id="local_url" type="hidden" name="referer" value="$param[referer]"/>
        <input type="hidden" name="confirmsubmit" value="true"/>
        <input type="hidden" name="sex" value="$param[sex]"/>
        <input type="hidden" name="province" value="$param[province]"/>
        <input type="hidden" name="city" value="$param[city]"/>
        <input type="hidden" name="headimgurl" value="$param[headimgurl]"/>
        <input type="hidden" name="unionid" value="$param[unionid]"/>
        <input type="hidden" name="openid" value="$param[openid]"/>
        <input type="hidden" name="access_token" value="$param[access_token]"/>
        <input type="hidden" name="checkcode" value="$param[checkcode]"/>
        <input type="hidden" name="weixinname" value="$param[weixinname]"/>
        <!--{if !$select}-->
        <div class="wq_login_close">
            <p class="wq_login_dui"><i class="wqiconfont wqicon-o3"></i></p>
            <input type="hidden" name="nickname" value="$param[nickname]"/>
            <p class="wq_login_ts">{$Plang['oauth_success_select']}</p>
            <p class="zc_yj"><input type="submit" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=register" value="{$register_tips}"></p>
            <p class="zc_newname"><input type="submit" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=bind" value="$Plang[bind_isset_forum_user]"></p>
        </div>
        <!--{elseif $select == 'oneself'}-->
        <div class="wq_login_bd">
            <h3>{$Plang['register_new_user']}</h3>
            <ul>
                <input type="hidden" name="oneselfsubmit" value="true"/>
                <li style=""><input type="text" name="nickname" value="$param[weixinname]" placeholder="$Plang[please_import_username]"/></li>
                <li><input type="password"  name="pwd" placeholder="$Plang[please_import_pwd]"/></li>
				<!--{if $setting['register_email']}-->
                <li><input type="text"  name="email" placeholder="Email"/></li>
				<!--{/if}-->
            </ul>
            <p class="wqlogin_determine"><input id="ajax_submit" type='submit' value="$Plang[confirm]" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=register"></p>
            <p class="zc_newname"><input type='submit' value="$Plang[bind_isset_forum_user]" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=bind"></p>
        </div>
        <!--{elseif $select == 'bind'}-->
        <div class="wq_login_bd">
            <h3>{$Plang['bind_isset_user']}</h3>
            <input type="hidden" name="bindsubmit" value="true"/>
            <ul>
                <li style=""><input type="text"  name="username" placeholder="$Plang[please_import_username]"/></li>
                <li><input type="password" name="pwd" placeholder="$Plang[please_import_pwd]"/></li>
                <li>
                    <select id="questionid_LHGcX" name="questionid" class="sel_list">
                        <option value="0" selected="selected">{lang security_question}</option>
                        <option value="1">{lang security_question_1}</option>
                        <option value="2">{lang security_question_2}</option>
                        <option value="3">{lang security_question_3}</option>
                        <option value="4">{lang security_question_4}</option>
                        <option value="5">{lang security_question_5}</option>
                        <option value="6">{lang security_question_6}</option>
                        <option value="7">{lang security_question_7}</option>
                    </select>
                </li>
                <li><input type="text"  name="answer" placeholder="$Plang[please_import_answer]"/></li>
            </ul>
            <p class="wqlogin_determine"><input id="ajax_submit" type='submit' value="$Plang[confirm]" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=bind"></p>
            <p class="zc_newname"><input type='submit' value="{$register_tips}" formaction="plugin.php?id=wq_login&mod=bindorregister&ac=register"></p>
        </div>
        <!--{/if}-->
    </form>
</div>
<script type="text/javascript" reload="1">
    var msg_type = $setting['is_header'];
    var wq_formdialog = {init: function () {
            $(document).on('click', '#ajax_submit', function () {
                popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
                var obj = $(this);
                var formobj = $(this.form);
                $.ajax({
                    type: 'POST',
                    url: obj.attr('formaction') + '&handlekey=' + formobj.attr('id') + '&inajax=1',
                    data: formobj.serialize(),
                    dataType: 'html'
                }).success(function (s) {
                    evalscript(wqXml(s));
                }).error(function () {
                    popup.close();
                    window.location.href = $('#local_url').val();
                });
                return false;
            });
        }};
    $(document).ready(function () {
        wq_formdialog.init();
    });

    function succeedhandle_oauth_succeed_form(url, msg) {
        if (msg_type == 1) {
            popup.close();
            window.location.href = url;
        } else {
            var html = "<div class=\"ass_fl\"><dt id=\"messagetext\"><p>" + msg + "</p></dt></div>";
            popup.open(html);
            set_Time_clear_popup(url);
        }
        $(":submit", this).removeAttr("disabled");
    }

    function errorhandle_oauth_succeed_form(msg) {
        var html = "<div class=\"ass_fl\"><dt id=\"messagetext\"><p>" + msg + "</p></dt></div>";
        popup.open(html);
        set_Time_clear_popup(null);
        $(":submit", this).removeAttr("disabled");
    }

    $("form").submit(function () {
        $(":submit", this).attr("disabled", "disabled");
    });
</script>
<!--{template common/footer}-->