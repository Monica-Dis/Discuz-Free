<?php exit("Powered by www.wikin.cn"); ?>
<!--{template common/header}-->
<div class="f_c">
    <!--{if $_G['uid'] && !$qrauth}-->
    <h3 class="flb">
        <em id="return_$_GET['handlekey']"><!--{if $_G['uid']}--><!--{if $_GET['ac'] == 'unbind'}-->{$Plang['6772eb6a630cb9fb']}<!--{else}-->{$Plang['e6c6c71662e91be5']}<!--{/if}--><!--{else}-->{$Plang['b538cb99837a7aff']}<!--{/if}--></em>
        <span>
            <a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a>
        </span>
    </h3>
    <form id="confirmform" method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=scan&infloat=yes&confirmsubmit=yes" onsubmit="ajaxpost('confirmform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror'); return false;">
        <div class="c cl">
            <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="<!--{eval echo dhtmlspecialchars($_GET['handlekey']);}-->" /><!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if !$setting['bind_is_write_password']}-->
				{$Plang['928e3b830545ca23']}
			<!--{else}-->
            {$Plang['b7ec2686ca55b6fa']}
				<div class="rfm mtn">
					<table>
						<tr>
							<th><label for="passwordconfirm">{$Plang['dcaf7337b45e0aca']}</label></th>
							<td><input type="password" id="passwordconfirm" name="passwordconfirm" size="30" class="px p_fre" tabindex="1" /></td>
							<td class="tipcol"></td>
						</tr>
					</table>
				</div>
			<!--{/if}-->
            <div class="rfm mbw bw0">
                <table width="100%">
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <button class="pn pnc" type="submit" name="confirmsubmit" value="true" tabindex="1"><strong>{lang submit}</strong></button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </form>
    <!--{elseif !$_G['uid'] || $_G['uid'] && $qrauth}-->
    <h3 class="flb">
        <em id="return_$_GET['handlekey']"><!--{if $_G['uid']}-->{$Plang['e6c6c71662e91be5']}<!--{else}-->{$Plang['b538cb99837a7aff']}<!--{/if}--></em>
        <span>
            <a href="javascript:;" class="flbc" onclick="clearTimeout(wechat_checkST); hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a>
        </span>
    </h3>
    <div class="c" align='center'>
        <img src="$qrcodeurl" width="200" height="200"/>
        <br/>
        {$Plang['fca1eba229b9c748']}
    </div>
    <!--{/if}-->
</div>
<script type="text/javascript">
<!--{if !$_G['uid'] || $_G['uid'] && $qrauth}-->
	var wechat_checkST = null, wechat_checkCount = 0;
	function wechat_checkstart() {
		wechat_checkST = setTimeout(function () {wechat_check()}, 5000);
	}
	function wechat_check() {
		var x = new Ajax();
		x.get('plugin.php?id=wq_login&mod=scan&check=$codeenc', function(s, x) {
			s = trim(s);
			if (s != 'done') {
				if (s == '1') {
					wechat_checkstart();
				}
				wechat_checkCount++;
				if (wechat_checkCount >= 12) {
					clearTimeout(wechat_checkST);
					hideWindow('$_GET[handlekey]');
				}
			} else {
				clearTimeout(wechat_checkST);
                                    location.href = location.href;
			}
		});
	}
	wechat_checkstart();
<!--{/if}-->

<!--{if $_G['uid'] && !$qrauth}-->
	function succeedhandle_$_GET['handlekey']() {
		hideWindow('$_GET[handlekey]');
		showWindow('wechat_bind', 'plugin.php?id=wq_login&mod=scan');
	}
<!--{/if}-->



</script>

<!--{template common/footer}-->