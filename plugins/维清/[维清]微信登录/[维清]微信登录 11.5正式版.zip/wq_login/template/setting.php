<?php exit("Powered by www.wikin.cn"); ?>
<!--{template common/header}-->
<div class="f_c">
    <!--{if $_G['uid'] && $_GET['ac'] == 'username'}-->
    <h3 class="flb">
        <em id="return_$_GET['handlekey']">{$Plang['c150fedb114eefa7']}</em>
        <span>
            <a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a>
        </span>
    </h3>
    <form id="confirmform" method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=setting&ac=username&infloat=yes&confirmsubmit=yes" onsubmit="ajaxpost('confirmform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror'); return false;">
        <div class="c cl">
            <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <div class="rfm mtn" style="width:360px">
                <table>
                    <tr>
                        <th style="width: 8em;">{$Plang['7531eb7740ebe147']}</th>
                        <td>{$_G['username']}</td>
                        <td class="tipcol"></td>
                    </tr>
                    <tr>
                        <th><label for="newusername">{$Plang['00604ba66eee492b']}</label></th>
                        <td><input type="text" id="newusername" name="newusername" size="30" class="px p_fre" tabindex="1" /></td>
                        <td class="tipcol"></td>
                    </tr>
                </table>
            </div>
            <div class="rfm mbw bw0" style="width:360px">
                <table width="100%">
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <button class="pn pnc" type="submit" name="confirmsubmit" value="true" tabindex="1"><strong>{lang submit}</strong></button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </form>
    <!--{/if}-->
    <!--{if $_G['uid'] && $_GET['ac'] == 'password'}-->
    <h3 class="flb">
        <em id="return_$_GET['handlekey']">{$Plang['d2d6d7bc7468d2b0']}</em>
        <span>
            <a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a>
        </span>
    </h3>
    <form id="confirmform" method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=setting&ac=password&infloat=yes&confirmsubmit=yes" onsubmit="ajaxpost('confirmform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror'); return false;">
        <div class="c cl">
            <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <div class="rfm mtn" style="width:360px">
                <table>
                    <tr>
                        <th style="width: 8em;"><label for="newpassword">{$Plang['248be805e4c69add']}</label></th>
                        <td><input type="password" id="newpassword" name="newpassword" size="30" class="px p_fre" tabindex="1" /></td>
                        <td class="tipcol"></td>
                    </tr>
                    <tr>
                        <th><label for="confirmpassword">{$Plang['6d652abb35b3994a']}</label></th>
                        <td><input type="password" id="confirmpassword" name="confirmpassword" size="30" class="px p_fre" tabindex="2" /></td>
                        <td class="tipcol"></td>
                    </tr>
                </table>
            </div>
            <div class="rfm mbw bw0" style="width:360px">
                <table width="100%">
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <button class="pn pnc" type="submit" name="confirmsubmit" value="true" tabindex="3"><strong>{lang submit}</strong></button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </form>
    <!--{/if}-->
</div>
<script type="text/javascript">
<!--{if $_G['uid']}-->
            function succeedhandle_$_GET['handlekey']() {
            hideWindow('$_GET['handlekey']');
                    location.href = location.href;
            }
<!--{/if}-->
</script>
<!--{template common/footer}-->