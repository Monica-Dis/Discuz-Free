<?php exit("Powered by www.wikin.cn"); ?>
<!--{template common/header}-->
<div class="f_c">
    <h3 class="flb">
        <em id="return_$_GET['handlekey']"><!--{if $_G['uid']}--><!--{if $_GET['mod'] == 'unbind'}-->{$Plang['6772eb6a630cb9fb']}<!--{else}-->{$Plang['e6c6c71662e91be5']}<!--{/if}--><!--{else}-->{$Plang['b538cb99837a7aff']}<!--{/if}--></em>
        <span>
            <a href="javascript:;" class="flbc" onclick="hideWindow('$_GET[handlekey]')" title="{lang close}">{lang close}</a>
        </span>
    </h3>
    <form id="confirmform" method="post" autocomplete="off" action="plugin.php?id=wq_login&mod=unbind&infloat=yes&confirmsubmit=yes" onsubmit="ajaxpost('confirmform', 'return_{$_GET[handlekey]}', 'return_{$_GET[handlekey]}', 'onerror');
            return false;">
        <div class="c cl">
            <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="<!--{eval echo dhtmlspecialchars($_GET['handlekey']);}-->" /><!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if !$setting['bind_is_write_password']}-->
				{$Plang['980e158a45859b7a']}
			<!--{else}-->
				{$Plang['b7ec2686ca55b6fa']}
				<div class="rfm mtn">
					<table>
						<tr>
							<th><label for="passwordconfirm">{$Plang['dcaf7337b45e0aca']}</label></th>
							<td><input type="password" id="passwordconfirm" name="passwordconfirm" size="30" autocomplete="off" class="px p_fre" tabindex="1" /></td>
							<td class="tipcol"></td>
						</tr>
					</table>
				</div>
			<!--{/if}-->
            <div class="rfm mbw bw0">
                <table width="100%">
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <button class="pn pnc" type="submit" name="confirmsubmit" value="true" tabindex="1"><strong>{lang submit}</strong></button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    function wq_trim(str) {
        return str.replace(/^(\s|\u00A0)+/, '').replace(/(\s|\u00A0)+$/, '');
    }
    function succeedhandle_$_GET['handlekey'](url, msg) {
		hideWindow('$_GET[handlekey]');
        if (wq_trim(msg) == "$Plang['16f7a468fd1793a9']") {
			showDialog(msg, null, null, null, null, null, null, null, null, 2)
            setTimeout(function() {
                location.href = location.href;
            }, '1000');
        }
    }
</script>
<!--{template common/footer}-->