<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: uninstall.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/wq_login/language/install_language.php';

$_G['lang']['admincp']['ok'] = $Plang_install['ok'];
$_G['lang']['admincp']['cancel'] = $Plang_install['cancel'];

$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	case 'sql':
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_login_authcode`;
DROP TABLE IF EXISTS `pre_wq_login_code_cache`;
DROP TABLE IF EXISTS `pre_wq_login_credit_reward`;
DROP TABLE IF EXISTS `pre_wq_login_member`;
DROP TABLE IF EXISTS `pre_wq_login_posts_temporary`;
DROP TABLE IF EXISTS `pre_wq_login_posts_temporary1`;
DROP TABLE IF EXISTS `pre_wq_login_templatemsg_log`;
EOF;
		runquery($sql);
		if(!$_G['cache']['plugin']['wq_wechatapi']) {
			$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wq_login_member`;
EOF;
			runquery($sql);
		}
		require_once DISCUZ_ROOT . './source/plugin/wq_login/config/loadfunc.php';
		wq_rmdir(DISCUZ_ROOT . './data/cache/wq_login/');
		wq_rmdir(DISCUZ_ROOT . './data/cache/avatarTmp/');
		@unlink(DISCUZ_ROOT . "./data/sysdata/cert_p_wq_login.php");
		$finish = TRUE;
		break;

	case 'ok':
		$finish = TRUE;
		break;

	default:
		if(empty($_GET['deletedb'])) {

			if($_GET['operation'] == 'delete') {
				$plugin_exists = C::t('common_plugin')->fetch($pluginid);
				if(empty($plugin_exists)) {
					C::t('common_plugin')->insert($plugin);
				}
			}

			cpmsg($Plang_install['tips'], "{$request_url}&step=ok", 'form', array(), '', TRUE, ADMINSCRIPT . "?{$request_url}&step=sql");
		}
		break;
}
//dis'.'m.t'.'ao'.'bao.com
?>