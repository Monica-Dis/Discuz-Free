<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * Author: wikin
 *
 * $Id: table_wq_login_code_cache.php 2018-11-24 17:49:11Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_login_code_cache extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_login_code_cache';
		$this->_pk = '';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function result_info_by_code($code) {
		if(empty($code)) {
			return '';
		}

		return DB::result_first("SELECT info FROM %t WHERE code=%s", array($this->_table, $code));
	}

	function delete_by_dateline($time) {
		DB::delete($this->_table, 'dateline <' . $time);
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>