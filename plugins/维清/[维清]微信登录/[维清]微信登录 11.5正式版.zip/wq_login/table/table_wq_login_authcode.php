<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_mobile_wechat_authcode.php 34479 2014-05-07 00:40:10Z Dism_taobao-com $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_login_authcode extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_login_authcode';
		$this->_pk = 'sid';

		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function fetch_by_code($code) {
		return DB::fetch_first('SELECT * FROM %t WHERE code=%d', array($this->_table, $code));
	}

	public function delete_history() {
		$time = TIMESTAMP - 100;
		return DB::delete($this->_table, "createtime<$time");
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>