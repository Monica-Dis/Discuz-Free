<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_login_posts_temporary1 extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_login_posts_temporary1';
		$this->_pk = 'tid';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	function fetch_by_pid($pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE pid=%d ORDER BY dateline DESC", array($this->_table, $pid));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>