<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_user_weixin_relations extends discuz_table {

	public function __construct() {
		$this->_table = 'user_weixin_relations';
		$this->_pk = 'id';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function fetch_by_unionid($unionid) {
		return DB::fetch_first("SELECT * FROM %t WHERE unionid=%s", array($this->_table, $unionid));
	}

	public function fetch_by_userid($userid) {
		return DB::fetch_first("SELECT * FROM %t WHERE userid=%s", array($this->_table, $userid));
	}

	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t WHERE 1", array($this->_table));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>