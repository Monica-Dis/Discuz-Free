<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_login_sample.php 2015-5-24 16:24:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_login_member extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_login_member';
		$this->_pk = 'id';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function fetch_first_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%s", array($this->_table, $uid));
	}

	public function fetch_first_by_openid($openid) {
		return DB::fetch_first("SELECT * FROM %t WHERE openid=%s", array($this->_table, $openid));
	}

	public function fetch_first_by_unionid($unionid) {
		return DB::fetch_first("SELECT * FROM %t WHERE unionid=%s", array($this->_table, $unionid));
	}

	public function fetch_first_by_apptoken($apptoken) {
		return DB::fetch_first("SELECT * FROM %t WHERE app_token=%s", array($this->_table, $apptoken));
	}

	public function delete_by_uid($uid) {
		return DB::delete($this->_table, array('uid' => $uid));
	}

	public function update_by_uid($uid, $chgpassword = false) {
		if($chgpassword) {
			$data = array('chgpassword' => '1');
		} else {
			$data = array('chgusername' => '1');
		}
		return DB::update($this->_table, $data, array('uid' => $uid));
	}

	public function fetch_all_by_search($sex, $chgusername, $chgpassword, $keyword, $search, $date, $dateline1, $dateline2, $displayorder, $ordertype, $start, $limit) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' ' . $ordertype . ' ';
		}
		if($sex != '') {
			$sql[] = 'sex=%d';
			$val[] = $sex;
		}
		if($chgusername != '') {
			$sql[] = 'chgusername=%d';
			$val[] = $chgusername;
		}
		if($chgpassword != '') {
			$sql[] = 'chgpassword=%d';
			$val[] = $chgpassword;
		}
		if($date && $dateline1) {
			$sql[] = $date . '>=%d';
			$val[] = $dateline1;
		}
		if($date && $dateline2) {
			$sql[] = '%d>=' . $date;
			$val[] = $dateline2;
		}

		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order . DB::limit($start, $limit), $val);
	}

	public function count_by_search($sex, $chgusername, $chgpassword, $keyword, $search, $date, $dateline1, $dateline2) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($sex != '') {
			$sql[] = 'sex=%d';
			$val[] = $sex;
		}
		if($chgusername != '') {
			$sql[] = 'chgusername=%d';
			$val[] = $chgusername;
		}
		if($chgpassword != '') {
			$sql[] = 'chgpassword=%d';
			$val[] = $chgpassword;
		}
		if($date && $dateline1) {
			$sql[] = $date . '>=%d';
			$val[] = $dateline1;
		}
		if($date && $dateline2) {
			$sql[] = '%d>=' . $date;
			$val[] = $dateline2;
		}
		if($keyword && $search) {
			$sql[] = $search . ' LIKE %s ';
			$val[] = '%' . $keyword . '%';
		}
		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql, $val);
	}

	public function update_userinfo_by_apptoken($apptoken, $data) {
		return DB::update($this->_table, $data, array('app_token' => $apptoken));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>