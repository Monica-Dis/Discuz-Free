<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_login/config/config.php';
$sex = in_array($_GET['sex'], array('0', '1', '2')) ? $_GET['sex'] : '';
$chgusername = in_array($_GET['chgusername'], array('0', '1')) ? $_GET['chgusername'] : '';
$chgpassword = in_array($_GET['chgpassword'], array('0', '1')) ? $_GET['chgpassword'] : '';
$date = in_array($_GET['date'], array('authorizetime')) ? $_GET['date'] : 'authorizetime';
$search = in_array($_GET['search'], array('weixinname', 'username')) ? $_GET['search'] : 'username';
$ordertype = in_array($_GET['ordertype'], array('desc', 'asc')) ? $_GET['ordertype'] : 'desc';
$dateline1 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['dateline1'])) ? strtotime(trim($_GET['dateline1'])) : '';
$dateline2 = preg_match('/^\d{4}-[0-1]\d-[0-3]\d\s[0-2]\d:[0-5]\d$/i', trim($_GET['dateline2'])) ? strtotime(trim($_GET['dateline2'])) : '';
$displayorder = in_array($_GET['displayorder'], array('authorizetime')) ? $_GET['displayorder'] : 'authorizetime';
$keyword = isset($_GET['keyword']) ? dhtmlspecialchars(trim($_GET['keyword'])) : '';
$keyword = str_replace(array("%", "'", "\\", "_"), "", $keyword);
$limit = $_GET['perpage'] < 1 ? $setting['admincp_perpage'] : intval($_GET['perpage']);
$ac = in_array($_GET['ac'], array('unbind')) ? dhtmlspecialchars($_GET['ac']) : "";

$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $limit;
$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs';
$all = C::t('#wq_login#wq_login_member')->fetch_all_by_search($sex, $chgusername, $chgpassword, $keyword, $search, $date, $dateline1, $dateline2, $displayorder, $ordertype, $start, $limit);
$count = C::t('#wq_login#wq_login_member')->count_by_search($sex, $chgusername, $chgpassword, $keyword, $search, $date, $dateline1, $dateline2);
$mpurl .= $date != 'authorizetime' ? '&date=' . $date : '';
$mpurl .= $search != 'username' ? '&search=' . $search : '';
$mpurl .= $ordertype != 'desc' ? '&ordertype=' . $ordertype : '';
$mpurl .= $dateline1 != '' ? '&dateline1=' . $_GET['dateline1'] : '';
$mpurl .= $dateline2 != '' ? '&dateline2=' . $_GET['dateline2'] : '';
$mpurl .= $displayorder != 'authorizetime' ? '&displayorder=' . $displayorder : '';
$mpurl .=!empty($keyword) ? '&keyword=' . $_GET['keyword'] : '';
$mpurl .= $limit != $setting['admincp_perpage'] ? '&perpage=' . $limit : '';
$mpurl .= $chgusername !== '' ? '&chgusername=' . $chgusername : '';
$mpurl .= $chgpassword !== '' ? '&chgpassword=' . $chgpassword : '';
$url = $mpurl;
$mpurl .= $sex !== '' ? '&sex=' . $sex : '';
$href = $mpurl . '&page=' . $_GET['page'];
$url = ADMINSCRIPT . '?' . $url;
$mpurl = ADMINSCRIPT . '?' . $mpurl;
echo"<style tpye='text/css'>
   .hover div:hover,.sex{background-color: #666666 !important;}
    .hover div{width:55px;height;text-align:center;line-height:18px;border-radius:4px;}
    .hover div:hover a,.sex a{color:#FFF !important;}
       li{float:left;}
     .mradio_html li{line-height:25px;}
       input:hover, input:focus,select:hover,select:focus{border-color:#09C;background: #F5F9FD none repeat scroll 0% 0%;}
    .header th{text-align:center;}
    .tr{text-align:center;}
    td span{color:red;}
    .addtr {background: transparent url('static/image/admincp/bg_repno.gif') no-repeat scroll 2px 3px;line-height: 30px;}
    </style>
    <script type='text/javascript' src='static/js/calendar.js'></script>
<script>_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e,'forms'); });</script>";


if($ac == 'unbind') {
	$uid = $_GET['uid'] ? intval($_GET['uid']) : 0;
	if(!$uid) {
		cpmsg($Plang['80ca179ddfd1c735'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs', 'error');
	}
	if(!submitcheck('unbindsubmit')) {
		$extra = "<input type=\"hidden\" name=\"unbindsubmit\" value=\"yes\">\n<input type=\"hidden\" name=\"uid\" value=\"$uid\">";
		cpmsg($Plang['34639ebcbfe71790'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs&ac=unbind', 'form', array(), $extra);
	} else {
		C::t("#wq_login#wq_login_member")->delete_by_uid($uid);
		cpmsg($Plang['2bd6214a2c3c840a'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs', 'succeed');
	}
} else {
	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs';
	showformheader($fromurl, '', 'forms');
	showtableheader(); //dism��taobao��com
	$perpage_html = perpage_html($limit);
	$typehtml = radio_html(array('desc' => $Plang['desc'], 'asc' => $Plang['asc']), 'ordertype', $ordertype);
	$timetpye = array('authorizetime' => $Plang['authorizetime']);
	$chgusername_html = select_html(array('0' => $Plang['userstatus_0'], '1' => $Plang['userstatus_1']), 'chgusername', $chgusername);
	$datetype = select_html(array('authorizetime' => $Plang['authorizetime']), 'date', $date, false);
	$orderhtml = select_html($timetpye, 'displayorder', $displayorder, false);
	$datehtml = text_html($_GET['dateline1'], $_GET['dateline2']);
	$chgpassword_html = select_html(array('0' => $Plang['userstatus_0'], '1' => $Plang['userstatus_1']), 'chgpassword', $chgpassword);

	showtablerow('', array('width="60"', 'width="50"', 'width="50"', 'width="50"', 'width="25"', 'width="50"', 'width="100"', 'width="50"'), array(
		$Plang['userstatus'], $chgusername_html,
		$Plang['passwordstatus'], $chgpassword_html,
		$Plang['displayorder'], $orderhtml, $typehtml,
		$Plang['perpage'], $perpage_html,
	));
	showtablefooter(); //Dism��taobao��com
	$keywordtype = array('weixinname' => $Plang['weixinname'], 'username' => $Plang['username']);
	$options = select_html($keywordtype, 'search', $search, false, false);
	showtableheader(); //dism��taobao��com
	showtablerow('', array('width="50"', 'width="270"', 'width="55"', 'width="50"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"', 'width="60"'), array(
		$datetype, $datehtml,
		$Plang['search'], $options, "<input size = \"25\" name=\"keyword\" type=\"text\" value=\"" . dhtmlspecialchars($_GET['keyword']) . "\" placeholder='" . $Plang['search_tips'] . "' />" .
		"<input name=\"sex\" type=\"hidden\" value=\"" . $sex . "\" />",
		"<input id='submit_forms' class=\"btn\" type=\"submit\" value=\"$lang[search]\" name='forms'/>",
		"<div " . ($sex === '' ? 'class="sex"' : "") . "><a style='color:#000;' href=\"" . $url . "\">" . $Plang['all'] . "</a></div>",
		"<div " . ($sex === '0' ? 'class="sex"' : "") . "><a style='color:green;' href=\"" . $url . "&sex=0\">" . $Plang['sex_0'] . "</a></div>",
		"<div " . ($sex === '1' ? 'class="sex"' : "") . "><a style='color:blur;' href=\"" . $url . "&sex=1\">" . $Plang['sex_1'] . "</a></div>",
		"<div " . ($sex === '2' ? 'class="sex"' : "") . "><a style='color:red;' href=\"" . $url . "&sex=2\">" . $Plang['sex_2'] . "</a></div>",
		'',
	));
	showtablefooter(); //Dism��taobao��com
	showformfooter(); //Dism_taobao_com
	showtableheader($Plang['cron_log'], 'nobottom');
	$show_sex = array('0' => $Plang['sex_0'], '1' => $Plang['sex_1'], '2' => $Plang['sex_2']);
	$sex_color = array('0' => "green", '2' => "red", '1' => "blur");

	showsubtitle(array($Plang['username'], $Plang['weixinname'], "OpenId", "UnionId", $Plang['residearea'], $Plang['sex'], $Plang['is_chgusername'], $Plang['is_chgpassword'], $Plang['authorizetime'], $Plang['dateline'], $Plang['4e64f0e320d8b16b']));
	foreach($all as $val) {
		$val[$search] = !empty($keyword) ? str_replace($keyword, '<span>' . $keyword . '</span>', $val[$search]) : $val[$search];
		$val['username'] = $val['username'] ? $val['username'] : wq_wechat_get_username_by_uid($val['uid']);
		showtablerow('class="tr""', array('width="200"', 'width="200"',), array(
			"<a href='home.php?mod=space&do=profile&uid=" . $val['uid'] . "' target='_blank'>" . $val['username'] . "</a>",
			$val['weixinname'] ? $val['weixinname'] : $Plang['nodata'],
			$val['openid'],
			$val['unionid'],
			$val['area'] ? $val['area'] : $Plang['nodata'],
			'<font style="color:' . $sex_color[$val['sex']] . '">' . $show_sex[$val['sex']] . '</font>',
			$val['chgusername'] == 1 ? $Plang['yes'] : $Plang['no'],
			$val['chgpassword'] == 1 ? $Plang['yes'] : $Plang['no'],
			$val['authorizetime'] ? date("Y-m-d H:i:s", $val['authorizetime']) : $Plang['nodata'],
			$val['dateline'] ? date("Y-m-d H:i:s", $val['dateline']) : $Plang['nodata'],
			'<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_login&pmod=admincp_logs&ac=unbind&uid=' . $val['uid'] . '">' . $Plang['274484284a6db94f'] . '</a>',
			)
		);
	}
	$multi = multi($count, $limit, $page, $mpurl);
	showtablefooter(); //Dism��taobao��com
	showtableheader(); //dism��taobao��com
	showtablerow('', '', array($multi));
	showtablefooter(); //Dism��taobao��com
}
//dis'.'m.t'.'ao'.'bao.com
?>