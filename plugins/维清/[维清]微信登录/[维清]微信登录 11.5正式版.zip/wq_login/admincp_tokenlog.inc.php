<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_login/config/config.php';
if(!function_exists('savecache')) {
	require_once libfile('function/cache');
}
loadcache('getTokenLogs');
$getCacheTokenLogs = getglobal('cache/getTokenLogs');
showtableheader(); //dism��taobao��com
showsubtitle(array($Plang['get_time'], $Plang['get_result']));
foreach($getCacheTokenLogs as $key => $val) {
	$msg = "";
	foreach($val['msg'] as $k => $v) {
		$msg .= $k . " :  " . $v . '<br>';
	}
	showtablerow('', array(), array(
		$val['dateline'],
		$msg
	));
}
showtablefooter(); //Dism��taobao��com

?>