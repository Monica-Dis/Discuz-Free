<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$setting = $_G['cache']['plugin']['wq_login'];
$setting['appid'] = trim($setting['appid']);
$setting['appsecret'] = trim($setting['appsecret']);
$setting['is_appbyme_wxlogin'] = intval($setting['is_appbyme_wxlogin']);
$setting['is_magapp_wxlogin'] = intval($setting['is_magapp_wxlogin']);
$setting['is_qianfan_wxlogin'] = intval($setting['is_qianfan_wxlogin']);
$setting['share_logo'] = trim($setting['share_logo']);
$setting['wx_domain'] = trim($setting['wx_domain']);
$setting['domain_file'] = trim($setting['domain_file']);
$setting['domain_http'] = trim($setting['domain_http']);
$setting['newusergroupid'] = intval($setting['newusergroupid']);
$setting['disableregrule'] = intval($setting['disableregrule']);
$setting['is_header'] = intval($setting['is_header']);
$setting['update_userinfo'] = intval($setting['update_userinfo']);
$setting['login_hint'] = trim($setting['login_hint']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['view_qrcode'] = intval($setting['view_qrcode']);
$setting['show_qrcode'] = unserialize($setting['show_qrcode']);
$setting['login_float_text'] = trim($setting['login_float_text']);
$setting['qrcode_time'] = trim($setting['qrcode_time']);
$setting['automatic_login'] = intval($setting['automatic_login']);
$setting['allow_mobile_setting'] = intval($setting['allow_mobile_setting']);
$setting['function_type'] = intval($setting['function_type']);
$setting['open_wechattips'] = intval($setting['open_wechattips']);
$setting['templateid'] = trim($setting['templateid']);
$setting['post_tips_time'] = trim($setting['post_tips_time']);
$setting['is_openweixin'] = intval($setting['is_openweixin']);
$setting['jump_weixin_link'] = trim($setting['jump_weixin_link']);
$setting['bind_place_site'] = intval($setting['bind_place_site']);
$setting['open_register'] = intval($setting['open_register']);
$setting['open_oneself_username'] = intval($setting['open_oneself_username']);
$setting['register_email'] = intval($setting['register_email']);
$setting['pwd_strlen'] = intval($setting['pwd_strlen']);
$setting['pwd_is_numeric'] = intval($setting['pwd_is_numeric']);
$setting['pwd_is_english'] = intval($setting['pwd_is_english']);
$setting['credittype'] = intval($setting['credittype']);
$setting['creditnum'] = intval($setting['creditnum']);
$setting['bind_creditnum'] = intval($setting['bind_creditnum']);
$setting['pmnum'] = intval($setting['pmnum']);
$setting['is_wechat_login'] = intval($setting['is_wechat_login']);
$setting['wechat_login_style'] = intval($setting['wechat_login_style']);
$setting['mobile_wechat_logo'] = trim($setting['mobile_wechat_logo']);
$setting['loginpage_style'] = trim($setting['loginpage_style']);
$setting['loginpage_color'] = trim($setting['loginpage_color']);
$setting['qrcode_type'] = intval($setting['qrcode_type']);
$setting['bind_is_write_password'] = intval($setting['bind_is_write_password']);
$setting['is_open_unbind'] = intval($setting['is_open_unbind']);

?>