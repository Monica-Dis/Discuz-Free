<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache(array('plugin'));

include_once DISCUZ_ROOT . './source/plugin/wq_login/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_login/function/function_login.php';

$Plang = wq_loadlang('wq_login');

$setting = wq_loadsetting('wq_login');

$magapp = false;
if(file_exists(DISCUZ_ROOT . './source/plugin/wq_login/function/function_magapp.php')) {
	include_once DISCUZ_ROOT . './source/plugin/wq_login/function/function_magapp.php';
	$magapp = $setting['is_magapp_wxlogin'];
}

$has_qianfan = $has_appbyme = false;

if(C::t('common_plugin')->fetch_by_identifier('qianfan')) {
	$has_qianfan = true;
}
if(C::t('common_plugin')->fetch_by_identifier('appbyme_app')) {
	$has_appbyme = true;
}
$appbyme_app = $has_appbyme && $setting['is_appbyme_wxlogin'];
$qianfan_app = $has_qianfan && $setting['is_qianfan_wxlogin'];

?>