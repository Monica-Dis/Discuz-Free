<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_login/config/setting_base.php';

$defaulthttp = strrpos($_G['siteurl'], 'https://') === FALSE ? 'http://' : 'https://';
$https = array(
	'http' => 'http://',
	'https' => 'https://',
	'default' => $defaulthttp
);
$setting['domain_http'] = in_array($setting['domain_http'], array('http', 'https')) ? $setting['domain_http'] : 'default';
$http = $https[$setting['domain_http']];
$setting['wx_domain'] = rtrim($setting['wx_domain'], "/");
$setting['wx_domain'] = $http . str_replace(array('http://', 'https://'), "", $setting['wx_domain']) . "/";
$setting['qrcode_time'] = intval($setting['qrcode_time']) > 1 ? intval($setting['qrcode_time']) : 1;
$setting['prompt_time'] = intval($setting['prompt_time']) > 1 ? intval($setting['prompt_time']) : 1;
$setting['pwd_strlen'] = intval($setting['pwd_strlen']) > 1 ? intval($setting['pwd_strlen']) : 8;
$setting['pmnum'] = $setting['pmnum'] > 0 ? intval($setting['pmnum']) : 1;
$setting['pmnum'] = $setting['pmnum'] <= 10 ? intval($setting['pmnum']) : 10;
$setting['loginpage_color'] = $setting['loginpage_color'] ? $setting['loginpage_color'] : $setting['loginpage_style'];
$setting['mobile_wechat_logo'] = $setting['mobile_wechat_logo'] ? $setting['mobile_wechat_logo'] : "wq_logo.png";

?>