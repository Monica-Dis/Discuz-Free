<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $json_tpl;
$json_tpl = <<<EOT
		{
           "touser":"{openid}",
           "template_id":"{templateid}",
           "url":"{siteurl}",
           "topcolor":"#f60",
           "data":{
                   "first": {
                       "value":"{title}",
                       "color":"#000"
                   },
                   "keyword1":{
                       "value":"{eventtype}",
                       "color":"#F60"
                   },
                   "keyword2": {
                       "value":"{datetime}",
                       "color":"#000"
                   },
                  "remark":{
                       "value":"{remark}",
                       "color":"#000"
                   }
           }
       }
EOT;

?>