<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_login/class/base.class.php';
include_once DISCUZ_ROOT . './source/plugin/wq_login/class/jssdk.class.php';

class plugin_wq_login extends plugin_wq_login_base {

	function plugin_wq_login() {
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com

		!defined('MOBILE_API_OUTPUT') && define('MOBILE_API_OUTPUT', 1);

		include_once template('wq_login:module');
	}

	function common() {
		global $_G;

		if(!$_G['wq_login']['setting']) {
			$_G['wq_login']['setting'] = $this->setting;
		}

		$_G['Plang'] = $this->lang;

		if(!$_G['uid'] && !defined('IN_MOBILE')) {
			$_G['setting']['pluginhooks']['global_login_text'] .= wq_login_tpl_login_bar();
		}

		if($_G['uid']) {
			$_G['wq_wechatuser'] = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);
		}
	}

	function global_login_extra() {
		global $_G;

		if(!$_G['Plang'] || $_G['inshowmessage']) {
			return;
		}
		return wq_login_tpl_login_extra_bar();
	}

	function global_usernav_extra1() {
		global $_G;

		if(!$_G['Plang'] || !$_G['uid'] || $_G['inshowmessage']) {
			return '';
		}

		return wq_login_tpl_setting();
	}

	function global_footer() {
		global $_G, $curtype;

		if(!$_G['Plang'] || $_G['inshowmessage']) {
			return '';
		}
		$plugin_wq_buluo = !empty($_G['cache']['plugin']['wq_buluo']) ? 1 : 0;
		if($this->setting['view_qrcode'] && in_array(CURSCRIPT . '_' . CURMODULE, $this->setting['show_qrcode']) && ($plugin_wq_buluo == 0 || ($plugin_wq_buluo == 1 && $_GET['action'] != 'manage' && !in_array($_GET['op'], array('group', 'checkuser', 'manageuser', 'threadtype', 'demise'))))) {
			$url = $_G['siteurl'];

			$file_array = array(
				'forum' => array(
					'index' => array(
						'url' => '',
						'directory' => 'index',
						'filename' => '',
					),
					'forumdisplay' => array(
						'url' => '&fid=' . $_GET['fid'],
						'directory' => 'list',
						'filename' => $_GET['fid'],
					),
					'viewthread' => array(
						'url' => '&tid=' . $_GET['tid'],
						'directory' => 'view',
						'filename' => $_GET['tid'],
					),
					'group' => array(
						'url' => '&fid=' . $_GET['fid'],
						'directory' => 'group',
						'filename' => $_GET['fid'],
					),
				),
				'portal' => array(
					'index' => array(
						'url' => '',
						'directory' => 'index',
						'filename' => '',
					),
					'list' => array(
						'url' => '&catid=' . $_GET['catid'],
						'directory' => 'list',
						'filename' => $_GET['catid'],
					),
					'view' => array(
						'url' => '&aid=' . $_GET['aid'],
						'directory' => 'view',
						'filename' => $_GET['aid'],
					),
				),
				'group' => array(
					'index' => array(
						'url' => empty($curtype) ? '' : '&gid=' . $_GET['gid'],
						'directory' => empty($curtype) ? 'index' : 'list',
						'filename' => empty($curtype) ? '' : $_GET['gid'],
					),
				),
			);
			$url .= CURSCRIPT . '.php?mod=' . CURMODULE . $file_array[CURSCRIPT][CURMODULE]['url'];

			$directory = $file_array[CURSCRIPT][CURMODULE]['directory'];

			$filename = CURSCRIPT . ($file_array[CURSCRIPT][CURMODULE]['filename'] ? '_' . $file_array[CURSCRIPT][CURMODULE]['filename'] : '');

			$qrcode_url = $this->qrcode_generate($url, $directory, $filename);
			$return = wq_login_tpl_float_qrcode($qrcode_url);
		}
		if($_G['uid'] && $_G['wq_login']['setting']['bind_place_site'] == 1) {
			$return .= wq_login_tpl_setting_menu();
		}
		return $return;
	}

	function deletemember($param) {
		$uids = $param['param'][0];
		$step = $param['step'];
		if($step == 'check' && $uids && is_array($uids)) {
			foreach($uids as $uid) {
				C::t('#wq_login#wq_login_member')->delete_by_uid($uid);
			}
		}
	}

}

class plugin_wq_login_forum extends plugin_wq_login {

	function post_wq_login_message($params) {
		global $_G, $_GET;
		$tid = $params['param'][2]['tid'];
		$reppid = $_GET['reppid'] ? intval($_GET['reppid']) : "";

		if($params['param'][0] == 'post_reply_succeed') {
			if($reppid) {
				$post = $this->fetch_data_by_tid(0, $reppid);
			} else {
				$post = $this->fetch_data_by_tid($tid);
			}
			if(!$post || ($post && (time() - $post['dateline']) > $this->setting['post_tips_time'])) {
				sendWechatTemplateTips($this->setting, 7, 2, $tid, $reppid);
			}
		}
	}

	function misc_wq_login_message($params) {
		global $_G, $_GET;

		$tid = $_GET['tid'] ? intval($_GET['tid']) : 0;
		$pid = $_GET['pid'] ? intval($_GET['pid']) : "";

		if(($params['param'][0] == 'recommend_succeed' && $params['param'][2]['recommendv'] = "+1") || ($params['param'][0] == 'thread_poll_succeed' && $_GET['do'] == 'support')) {
			if($pid) {
				$post = $this->fetch_data_by_tid(0, $reppid);
			} else {
				$post = $this->fetch_data_by_tid($tid);
			}
			if(!$post || ($post && (time() - $post['dateline']) > $this->setting['post_tips_time'])) {
				sendWechatTemplateTips($this->setting, 8, 2, $tid, $pid);
			}
		}
	}

}

class plugin_wq_login_member extends plugin_wq_login {

	function logging_method() {
		global $_G;
		if(!$_G['Plang'] || $_G['inshowmessage']) {
			return;
		}
		return wq_login_tpl_login_bar();
	}

	function logging_member_message() {
		global $_G;

		if($_G['uid'] && !defined('IN_MOBILE')) {
			sendWechatTemplateTips($this->setting, 1);
		}
	}

	function register_logging_method() {
		global $_G;
		if(!$_G['Plang'] || $_G['inshowmessage']) {
			return;
		}
		return wq_login_tpl_login_bar();
	}

}

class plugin_wq_login_home extends plugin_wq_login {

	function spacecp_profile_home_message($a) {
		$param = $a['param'];
		if($param[0] == 'profile_succeed' && strpos($param[1], 'password') !== false) {
			sendWechatTemplateTips($this->setting, 6);
		}
	}

}

class plugin_wq_login_misc extends plugin_wq_login {
}


class mobileplugin_wq_login extends plugin_wq_login_base {

	public $style;
	public $wq_login;

	function common() {
		global $_G;
		if($_G['uid'] && defined('IN_MOBILE') && $_G['cookie']['wq_jump_weixin_referer']) {
			$url = $_G['cookie']['wq_jump_weixin_referer'];
			dsetcookie('wq_jump_weixin_referer', '');
			dheader('Location:' . $url);
		}

		if($_GET['mod'] == 'logging' && $_GET['action'] == 'logout') {
			setcookie('wq_login_ignore_automatic_login', "1", TIMESTAMP + 1800);
		}

		if($_G['uid'] && CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile' && $_GET['mycenter'] == 1 && $_G['cache']['plugin']['wq_login']['allow_mobile_setting']) {
			$_G['wq_wechatuser'] = C::t('#wq_login#wq_login_member')->fetch_first_by_uid($_G['uid']);
			if(!$_G['wq_wechatuser']) {

				$this->style = '<link rel="stylesheet" href="source/plugin/wq_login/static/css/wq_login.css" type="text/css">';
			}

			if(!$this->is_wq_touch()) {
				$this->style .= '<link rel="stylesheet" href="source/plugin/wq_login/static/css/wq_discuz.css" type="text/css">'
					. '<link rel="stylesheet" href="source/plugin/wq_login/font/iconfont.css" type="text/css">';
				$this->wq_login = true;
			}
		}

		if(CURMODULE != 'image' && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $this->setting['automatic_login'] == 1 && !$_G['uid'] && !$_G['cookie']['wq_login_automatic_login'] && !$_COOKIE['wq_login_ignore_automatic_login']) {
			dsetcookie("wq_login_automatic_login", 1, 1800);
			$referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
			$referer = urlencode($referer);
			dheader('Location:' . $_G['siteurl'] . 'plugin.php?id=wq_login&mod=access&referer=' . $referer);
		}

		$_G['Plang'] = $this->lang;

		$plugin_wq_smslogin = !empty($_G['cache']['plugin']['wq_smslogin']) ? 1 : 0;
		if($this->setting['is_wechat_login'] && $plugin_wq_smslogin && $_GET['id'] == 'wq_smslogin' && $_GET['mod'] == 'login' && !submitcheck('allsubmit')) {

			ob_end_clean();
			$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
			list($seccodecheck) = seccheck('login');
			$referer = dreferer();
			$backurl = rawurlencode($referer);
			if($referer == $_G['siteurl'] . './') {
				$back = "forum.php?mobile=2";
			} elseif(!empty($_GET['inajax'])) {
				$back = "javascript:popup.close();";
			} else {
				$back = "javascript:history.back();";
			}

			$fileUrl = 'source/plugin/wq_login/static/mobile/';
			$plugin_wq_smslogin = !empty($_G['cache']['plugin']['wq_smslogin']) ? 1 : 0;
			if($plugin_wq_smslogin) {
				$wq_smslogin_setting = $_G['cache']['plugin']['wq_smslogin'];
			}

			$ac = "sms";

			include_once template('tpl_login_login', 0, 'source/plugin/wq_login/template');
		}
	}

	function is_wq_touch() {
		global $_G;
		$touch_tplid = $_G['setting']['styleid2'];
		loadcache('style_' . $touch_tplid);
		$touch_tpl = $_G['cache']['style_' . $touch_tplid];
		if($touch_tpl['tpldir'] == './template/wq_touch' || $touch_tpl['tpldir'] == './template/wq_app') {
			return true;
		}
		return false;
	}

	function global_header_mobile() {
		if($this->style) {
			return $this->style;
		}
	}

	function global_footer_mobile() {

		if($this->wq_login) {
			global $_G;
			include_once template('wq_login:tpl_login_profile');
			return tpl_login_profile($_G);
		}
	}

}

class mobileplugin_wq_login_home extends mobileplugin_wq_login {

	function spacecp_profile_home_message($a) {
		$param = $a['param'];
		if($param[0] == 'profile_succeed' && strpos($param[1], 'password') !== false) {
			sendWechatTemplateTips($this->setting, 6);
		}
	}

}

class mobileplugin_wq_login_member extends mobileplugin_wq_login {

	function logging_wq_login_output() {
		global $_G;

		if($this->setting['is_wechat_login'] && CURSCRIPT == 'member' && CURMODULE == 'logging' && $_GET['action'] == 'login' && empty($_GET['viewlostpw']) && empty($_GET['loginsubmit'])) {
			ob_end_clean();
			$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
			list($seccodecheck) = seccheck('login');

			$referer = dreferer();
			$backurl = rawurlencode($referer);
			if($referer == $_G['siteurl'] . './') {
				$back = "forum.php?mobile=2";
			} elseif(!empty($_GET['inajax'])) {
				$back = "javascript:popup.close();";
				$dialog = "dialog";
			} else {
				$back = "javascript:history.back();";
			}

			$fileUrl = 'source/plugin/wq_login/static/mobile/';
			$plugin_wq_smslogin = !empty($_G['cache']['plugin']['wq_smslogin']) ? 1 : 0;
			if($plugin_wq_smslogin) {
				$wq_smslogin_setting = $_G['cache']['plugin']['wq_smslogin'];
			}

			$ac = "";
			include_once template('tpl_login_login', 0, 'source/plugin/wq_login/template');
		}
	}

	function logging_bottom_mobile() {
		global $_G;

		if($this->is_wq_touch()) {
			return '';
		}

		$referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
		$referer = urlencode($referer);

		$str = <<<EOT
<style>
.btn_login .pn,.btn_register .pn {  background:#01a9e9;border-radius: 3px; width:100%; height:40px; display:block; line-height:40px; overflow:hidden; color:#FFF; font-size:16px;text-align:center;border:0; }
.btn_login .pn:hover,.btn_register .pn:hover { color:#fff; background:#01a9e9; }
.btn_login .wechat{ margin-top: 10px; background:#6fd52b; border-radius: 3px; width:100%; height:40px; display:block; line-height:40px; overflow:hidden; color:#FFF; font-size:16px;text-align:center;border:0; }
.btn_login .wechat:hover{ background:#54c10b; color:#fff; }
.btn_login .qq{ margin-top: 10px; border-radbius: 3px; background:#00abec; width:100%; height:40px; display:block; line-height:40px; overflow:hidden; color:#FFF; font-size:16px;text-align:center;border:0; }
.btn_login .qq:hover{ color:#fff;  background:#009fdc;}
</style>
<div class="btn_login"><a href="plugin.php?id=wq_login&mod=access&referer={$referer}" class="wechat"><span>{$_G['Plang']['a0715e6db5c02756']}</span></a></div>
EOT;
		return $str;
	}

	function logging_member_message($param) {
		global $_G;

		if($this->setting['is_wechat_login'] && $_GET['action'] == 'login' && empty($_GET['viewlostpw'])) {
			include_once DISCUZ_ROOT . './source/plugin/wq_login/function/function_login_ext.php';
			wq_login_showmessage($param);
		}

		$referer = dreferer();
		if($_G['uid'] && $_GET['action'] != 'logout') {
			$json = sendWechatTemplateTips($this->setting, 1);

			include_once DISCUZ_ROOT . "./source/plugin/wq_login/function/function_login.php";
			$result = goto_subscribe($json, $referer, true);
			if($result) {
				showmessage($result[0], $result[1]);
			}
		}
	}

}

class mobileplugin_wq_login_forum extends mobileplugin_wq_login {

	function post_wq_login_message($params) {
		global $_G, $_GET;

		$tid = $params['param'][2]['tid'];
		$reppid = $_GET['reppid'] ? intval($_GET['reppid']) : "";
		if($params['param'][0] == 'post_reply_succeed') {
			if($reppid) {
				$post = $this->fetch_data_by_tid(0, $reppid);
			} else {
				$post = $this->fetch_data_by_tid($tid);
			}
			if(!$post || ($post && (time() - $post['dateline']) > $this->setting['post_tips_time'])) {
				sendWechatTemplateTips($this->setting, 7, 2, $tid, $reppid);
			}
		}
	}

	function misc_wq_login_message($params) {
		global $_G, $_GET;
		$tid = $_GET['tid'] ? intval($_GET['tid']) : 0;
		$pid = $_GET['pid'] ? intval($_GET['pid']) : "";

		if(($params['param'][0] == 'recommend_succeed' && $params['param'][2]['recommendv'] = "+1") || ($params['param'][0] == 'thread_poll_succeed' && $_GET['do'] == 'support')) {
			if($pid) {
				$post = $this->fetch_data_by_tid(0, $reppid);
			} else {
				$post = $this->fetch_data_by_tid($tid);
			}
			if(!$post || ($post && (time() - $post['dateline']) > $this->setting['post_tips_time'])) {
				sendWechatTemplateTips($this->setting, 8, 2, $tid, $pid);
			}
		}
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>