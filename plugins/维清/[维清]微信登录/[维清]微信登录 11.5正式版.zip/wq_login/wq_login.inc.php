<?php

/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_login.inc.php 2015-8-16 00:00:00Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_login/config/config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_login/class/OAuth.class.php';
include_once DISCUZ_ROOT . './source/plugin/wq_login/class/jssdk.class.php';

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "access";

$allowmod = array('scan', 'qrcode', 'access', 'jssign', 'ajax', 'setting', 'user', 'unbind', 'bindorregister', 'login');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_login/' . $dirlist[$mod] . '/login_' . $mod . '.php';

?>