<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2016-7-19 12:30:06Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_sign/class/base.class.php';

class plugin_wq_sign extends plugin_wq_sign_base {

	function common() {
		global $_G;
		if($_G['uid'] && $this->setting['forc_sign'] == 1 && !C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid'], false) && !in_array($_G['groupid'], $this->setting['usergroups'])) {
			if(!in_array($_GET['id'], array('wq_sign', 'wq_sign:wq_sign', 'wq_login', 'wq_login:wq_login')) && CURSCRIPT != 'member') {
				dheader("Location:" . $_G['siteurl'] . "./plugin.php?id=wq_sign");
			}
		}
	}

	function global_header() {
		return '<script src="source/plugin/wq_sign/static/js/common/jquery-1.8.3.min.js?{VERHASH}" type="text/javascript" reload="1"></script>';
	}

	function global_footer() {
		global $_G;
		if(CURSCRIPT == 'forum' && CURMODULE == 'viewthread') {
			$data = C::t("#wq_sign#wq_sign_snyc_tid")->fetch_by_tid($_G['tid']);
			$val = 0;
			if($data) {
				$val = 1;
			}
			$replyjs = <<<EOF
<script>
	var val = $val;
	wqjq("#fastpostmessage").click(function(){
		if(val==1){
			window.location.href ="plugin.php?id=wq_sign:wq_sign";
		}
});
</script>
EOF;
			return $replyjs;
		}
	}

	function discuzcode($params) {
		global $msglower, $_G;
		if($params['caller'] == 'discuzcode') {
			$url = 'source/plugin/wq_sign/static/images';
			$durl = './source/plugin/wq_sign/static/images';
			if(strpos($_G['discuzcodemessage'], $url) !== false) {
				$_G['discuzcodemessage'] = str_replace($durl, $url, $_G['discuzcodemessage']);
				$_G['discuzcodemessage'] = str_replace($url, $_G['siteurl'] . $url, $_G['discuzcodemessage']);
			}
		}
	}

}

class plugin_wq_sign_forum extends plugin_wq_sign_base {

	function viewthread_posttop_output() {
		global $postlist;
		foreach($postlist as $key => $value) {
			$postlist[$key]['message'] = str_replace("http://source/", 'source/', $value['message']);
		}
	}

}

class mobileplugin_wq_sign extends plugin_wq_sign_base {

	function common() {
		global $_G;
		if($_G['uid'] && $this->setting['forc_sign'] == 1 && !C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid'], false) && !in_array($_G['groupid'], $this->setting['usergroups'])) {
			if(!in_array($_GET['id'], array('wq_sign', 'wq_sign:wq_sign', 'wq_login', 'wq_login:wq_login')) && CURSCRIPT != 'member') {
				dheader("Location:" . $_G['siteurl'] . "./plugin.php?id=wq_sign");
			}
		}
	}

	function global_header_mobile() {
		global $_G;
		if(CURSCRIPT == 'forum' && CURMODULE == 'viewthread') {
			$data = C::t("#wq_sign#wq_sign_snyc_tid")->fetch_by_tid($_G['tid']);
			$val = 0;
			if($data) {
				$val = 1;
			}
			$replyjs = <<<EOF
<script>
	var val = $val;
		$("body").on("click","#fastpostmessage",function(){
			   if(val==1){
				   window.location.href ="plugin.php?id=wq_sign:wq_sign";
				}
		});
		$("body").on("click","#wq_reply_click",function(){
			   if(val==1){
				   window.location.href ="plugin.php?id=wq_sign:wq_sign";
				}
		});
</script>
EOF;

			return $replyjs;
		}
	}

	function global_footer_mobile() {
		global $_G;

		$re = C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid'], false);
		if($this->setting['sign_icon_isshow'] && !$re && CURSCRIPT != 'member' && CURMODULE != 'logging' && $_GET['action'] != 'login' && !preg_match("|buluo|is", $_SERVER['REQUEST_URI'])) {
			if(!in_array($_GET['id'], array('wq_sign', 'wq_sign:wq_sign'))) {
				$sign = <<<EOT
                        <style>
                            .wq_sign_img{z-index: 99; bottom:120px;position: fixed; right: 10px; text-align: center;visibility: visible; background:#fa5800;border-radius: 50px; color: #fff ;width: 50px; height: 50px;line-height: 50px; font-size: 26px;}
                            .wq_sign_img a{ display: block; color: #fff !important;font-family: Arial, Microsof YaHei;}
                            .wq_sign_img img{ width: 36px; height: 36px;}
                        </style>
                        <div id = "wq_sign_img" class = "wq_sign_img">
                        <a href = "plugin.php?id=wq_sign">&#x7B7E;</a>
                    </div>
EOT;
				return $sign;
			}
		}
	}

}

class mobileplugin_wq_sign_forum extends plugin_wq_sign_base {

	function viewthread_posttop_output() {
		global $postlist;
		foreach($postlist as $key => $value) {
			$postlist[$key]['message'] = str_replace("http://source/", 'source/', $value['message']);
		}
	}

}
//From: Dism_taobao-com
?>