<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: weiqingini.php 2015-11-4 23:00:57Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$imgarr = array(
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign1.png', 'msg' => $Plang['wq_sign1']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign2.png', 'msg' => $Plang['wq_sign3']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign3.png', 'msg' => $Plang['wq_sign3']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign4.png', 'msg' => $Plang['wq_sign4']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign5.png', 'msg' => $Plang['wq_sign5']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign6.png', 'msg' => $Plang['wq_sign6']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign7.png', 'msg' => $Plang['wq_sign7']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign8.png', 'msg' => $Plang['wq_sign8']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign9.png', 'msg' => $Plang['wq_sign9']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign10.png', 'msg' => $Plang['wq_sign10']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign11.png', 'msg' => $Plang['wq_sign11']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign12.png', 'msg' => $Plang['wq_sign12']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign13.png', 'msg' => $Plang['wq_sign13']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign14.png', 'msg' => $Plang['wq_sign14']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign15.png', 'msg' => $Plang['wq_sign15']),
	array('image' => 'source/plugin/wq_sign/static/images/wq_sign16.png', 'msg' => $Plang['wq_sign16']),
);

?>