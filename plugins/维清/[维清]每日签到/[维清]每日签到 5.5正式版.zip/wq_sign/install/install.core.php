<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 == "success") {
		$_var_1 = "CREATE TABLE IF NOT EXISTS `pre_wq_sign_icon` (\n" . " `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . " `classid` int(10) unsigned NOT NULL,\n" . " `image` varchar(255) NOT NULL,\n" . " `message` text NOT NULL,\n" . " `displayorder` tinyint(2) unsigned NOT NULL,\n" . " `available` tinyint(1) unsigned NOT NULL,\n" . " PRIMARY KEY (`id`),\n" . " KEY `classid` (`classid`),\n" . " KEY `image` (`image`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_sign_logs` (\n" . "  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `tid` mediumint(8) unsigned NOT NULL,\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `username` varchar(15) NOT NULL,\n" . "  `image` varchar(255) NOT NULL,\n" . "  `message` text NOT NULL,\n" . "  `randreward` int(10) unsigned NOT NULL DEFAULT '0',\n" . "  `continuousreward` int(10) unsigned NOT NULL DEFAULT '0',\n" . "  `rewardnum` int(10) unsigned NOT NULL DEFAULT '0',\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`id`),\n" . "  KEY `tid` (`tid`),\n" . "  KEY `uid` (`uid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_sign_snyc_tid` (\n" . "  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `day` varchar(8) NOT NULL,\n" . "  `tid` mediumint(8) unsigned NOT NULL,\n" . "  PRIMARY KEY (`id`),\n" . "  KEY `day` (`day`),\n" . "  KEY `tid` (`tid`)\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_sign_stat` (\n" . "  `count` int(10) unsigned NOT NULL,\n" . "  `daycount` int(10) unsigned NOT NULL,\n" . "  `monthcount` int(10) unsigned NOT NULL\n" . ") ENGINE=MyISAM;\n" . "CREATE TABLE IF NOT EXISTS `pre_wq_sign_userinfo` (\n" . "  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,\n" . "  `month` varchar(6) NOT NULL,\n" . "  `uid` int(10) unsigned NOT NULL,\n" . "  `username` varchar(15) NOT NULL,\n" . "  `continuoussigntimes` smallint(5) unsigned NOT NULL,\n" . "  `monthsign` tinyint(2) unsigned NOT NULL,\n" . "  `totalsign` smallint(5) unsigned NOT NULL,\n" . "  `totalreward` int(10) unsigned NOT NULL,\n" . "  `dateline` int(10) unsigned NOT NULL,\n" . "  PRIMARY KEY (`id`),\n" . "  KEY `uid` (`uid`)\n" . ") ENGINE=MyISAM;\n";
		runquery($_var_1);
	} else {
		echo "Access Denied Weiqing";
		return 0;
	}