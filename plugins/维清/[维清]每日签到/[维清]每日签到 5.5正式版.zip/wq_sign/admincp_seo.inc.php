<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_seo.inc.php 2018-6-19 14:24:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/config.php';

$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_seo';
$cpmsgurl = 'action=' . $url;

if(!submitcheck('seosubmit')) {
	echo <<<EOT
	<script src="source/plugin/wq_sign/static/js/common/jquery-1.8.3.min.js"></script>
	<script>
		function setHeight() {
			var tab = wqjq('.floattop')[0]
			var fill = wqjq('.floattopempty')[0]
			fill.style.marginTop = (tab.clientHeight - 35 -16) + 'px'
		}
		wqjq(window).resize(setHeight)
		setHeight()
	</script>
EOT;


	echo '<script type="text/javascript">
		function insertContent(obj, text) {
			var obj = obj.parentNode.parentNode.firstChild.lastChild;
			selection = document.selection;
			obj.focus();
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart(\'character\', -strlen(text));
			} else {
				obj.value += text;
			}
		}
		</script>';
	$sign_seo = dunserialize($_G['setting']['sign_seo']);
	$page = array(
		'info' => array('bbname'),
		'view' => array('bbname'),
	);

	showformheader($url, 'seosubmit');
	showtableheader();
	foreach($page as $key => $value) {
		$code = $Plang['3bc832bd0cf768e4'];
		foreach($value as $v) {
			$code .= '<a onclick="insertContent(this, \'{' . $v . '}\');return false;" href="javascript:;" title="' . $Plang[$v] . '">{' . $Plang[$v] . '}</a>';
		}
		showtitle($Plang[$key]);
		showsetting($Plang['f7ae0f5162e383ed'], 'sign_seo[' . $key . '][seotitle]', $sign_seo[$key]['seotitle'], 'text', '', 0, $code);
		showsetting($Plang['534903eeef4b3b40'], 'sign_seo[' . $key . '][seokeywords]', $sign_seo[$key]['seokeywords'], 'text', '', 0, $code);
		showsetting($Plang['59d72389b36e3022'], 'sign_seo[' . $key . '][seodescription]', $sign_seo[$key]['seodescription'], 'text', '', 0, $code);
	}
	showsubmit('seosubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	$sign_seo = serialize($_GET['sign_seo']);
	C::t('common_setting')->update('sign_seo', $sign_seo);
	updatecache('setting');
	cleartemplatecache();
	cpmsg($Plang['succeed_tips'], $cpmsgurl, 'succeed');
}
//From: Dism_taobao-com
?>