<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2016-7-19 12:30:06Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_sign_base {

	public $lang;
	public $setting;

	function plugin_wq_sign_base() {
		global $_G;

		include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/loadfunc.php';

		$today = C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid'], false);
		if(!$today) {
			$yesterday = C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid']);
			if(!$yesterday) {
				DB::update('wq_sign_userinfo', array('continuoussigntimes' => 0), array('uid' => $_G['uid']));
			}
		}
		$this->lang = wq_loadlang('wq_sign');

		$this->setting = wq_loadsetting('wq_sign');
	}

}
//From: Dism_taobao-com
?>