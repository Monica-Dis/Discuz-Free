wqjq(function(){
    var spanWidth = wqjq(".wq_date li span").width();
    if(spanWidth < 32){
        wqjq(".wqpc_sign_btn_calendar ul li .wqsign_dot_white").css('bottom','1px');
    }
    wqjq(".wq_date li span").css('height',spanWidth+'px');
    wqjq(".wq_date li span").css('line-height',spanWidth+'px');
});