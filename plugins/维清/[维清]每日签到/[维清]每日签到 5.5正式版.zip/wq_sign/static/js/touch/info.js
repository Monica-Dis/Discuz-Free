$(function() {
	window.addEventListener("popstate", function() {
		var stateinfo = history.state;
		if (stateinfo.url) {
			window.location.href = stateinfo.url;
		} else {
			window.location.href = 'plugin.php?id=wq_sign';
		}
	});
	localStorage.removeItem("init_sign_window");
	localStorage.removeItem("init_welfare_window");
	wq_sign_initwindow('wqsign_sign', 'plugin.php?id=wq_sign&mod=mood&mobile=2&flag=1&formhash=' + formhash, 'POST');
	wq_sign_initwindow('wqsign_welfare', 'plugin.php?id=wq_sign&mod=welfare&mobile=2&formhash=' + formhash, 'POST');
	if (localStorage.getItem('temreplymessage')) {
		$("#sign_marquee").html(localStorage.getItem('temreplymessage'));
		$("#sign_succeed_notify").show();
		setTimeout(function() {
			$("#sign_succeed_notify").remove();
			localStorage.removeItem("temreplymessage");
		}, 10000);
	}
	var spanWidth = $(".wq_sign .wq_date li span").width();
	$(".wq_sign .wq_date li span").css('height', spanWidth + "px");
	$(".wq_sign .wq_date li span").css('line-height', spanWidth + "px");

});
function info_wqsign_sign() {
	if (localStorage.getItem('init_sign_window')) {
		var param = location.href.split("?");
		var state = {
			url: 'plugin.php?' + param[1],
			isloadtouchjs: 1
		};
		history.replaceState(state, '', location.href);
		var temurl = 'plugin.php?id=wq_sign&mod=mood';
		history.pushState({url: temurl, isloadtouchjs: 1}, '', temurl);

		$('#wquser_big').html(localStorage.getItem('init_sign_window'));
		evalscript(localStorage.getItem('init_sign_window'));
	}
	return false;
}
function info_wqsign_welfare() {
	if (localStorage.getItem('init_sign_window')) {
		popup.open(localStorage.getItem('init_welfare_window'));
	} else {
		wq_sign_showwindow('wq_sign', 'plugin.php?id=wq_sign&mod=welfare&mobile=2&formhash=' + formhash, 'POST');
	}
	return false;
}

$("#wqsign_expression_but").click(function() {
	var msg = $(".wq_textarea").val();
	var imgurl = $(".wq_imageurl").attr('value');
	if (!msg || msg.length < 1) {
		popup.open("<div class=\"ass_fl\"><dt id=\"messagetext\"><p>&#35828;&#28857;&#20160;&#20040;&#21543;</p></dt></div>");
		wq_sign_setTimeout(2000);
		return false;
	}
	$("#wqsign_expression_but").unbind("click")
	$('.wqsign_expression_btn').html('&#31614;&#21040;&#20013;');
	$.ajax({
		type: "POST",
		url: "plugin.php?id=wq_sign&mod=mood&inajax=1&handlekey=sign_view&confirmsubmit=yes",
		data: "&message=" + msg + "&imageurl=" + imgurl + "&formhash=" + formhash,
		dataType: 'html',
	}).success(function(s) {
		popup.close()
		var wq = wqXml(s);
		wq = wq_sign_replace_js(wq);
		wq = get_p_msg(wq);
		if (wq.substr(0, 1) == 1) {
			popup.open("<div class=\"ass_fl\"><dt id=\"messagetext\"><p>" + wq.substr(1) + "</p></dt></div>");
			wq_sign_setTimeout(2000);
		} else {
			localStorage.setItem("temreplymessage", wq);
			location.href = 'plugin.php?id=wq_sign';
		}
	})
});

function wq_sign_showwindow(id, url, type) {
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	type = type ? type : 'GET';
	$.ajax({
		type: type,
		url: url,
		data: {inajax: 1, handlekey: id},
		dataType: 'html',
	}).success(function(s) {
		popup.close()
		var wq = wqXml(s);
		wq2 = wq_sign_replace_js(wq);
		popup.open(wq2);
		evalscript(wq);
	}).error(function(s, s1) {
		window.location.href = url;
		popup.close();
	});
	return false;
}
function wq_sign_initwindow(id, url, type) {
	type = type ? type : 'GET';
	$.ajax({
		type: type,
		url: url,
		data: {inajax: 1},
		dataType: 'html',
	}).success(function(s) {
		var wq = wqXml(s);
		if (id == 'wqsign_sign') {
			localStorage.setItem("init_sign_window", wq);
		} else {
			localStorage.setItem("init_welfare_window", wq);
		}
	});
}