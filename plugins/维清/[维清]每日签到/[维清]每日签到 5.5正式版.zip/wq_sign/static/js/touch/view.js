$(function() {
    var init = $("img[class='wqimage']:first");
    $(".wq_textarea").val(init.attr('alt'));
    $(".wq_imageurl").val(init.attr('src'));
    init.css("border","1px solid #F00");
    $(".wqimage").click(function() {
        var obj = $(this);
        var message = obj.attr('alt');
        var imageurl = obj.attr('src');
        $("img[class='wqimage']").css('border-color','#fff');
        obj.css("border","1px solid #F00");
        $(".wq_textarea").val(message);
        $(".wq_imageurl").val(imageurl);
    });
});