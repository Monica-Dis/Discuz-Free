function wq_sign_replace_js(s) {
	if (s.indexOf('<script') == -1)
		return s;
	var p = /<script[^\>]*?>([^\x00]*?)<\/script>/ig;
	s = s.replace(p, '');
	return s;
}

function get_p_msg(str) {
    if(str.indexOf('####') == "-1"){
        str = str.replace(/<\/?[^>]*>/g, '');
	str = str.replace(/\s+/g, "");
	str = str.replace(/[ | ]*\n/g, '\n');
	str = str.replace(/&nbsp;/ig, '');
	str = str.replace(/\n[\s| | ]*\r/g, '\n');
	str = str.replace(/#/g, '');
	return str;
    }else{
        var start,end,cont;
        start = str.indexOf('####')+4;
        end = str.indexOf('####',start);
        cont = str.slice(start,end);
        return cont;
    }
}

function wq_sign_setTimeout(waittime){
    setTimeout(function(){
        popup.close()
    },waittime);
}