wqjq(function() {
    var init = wqjq("img[class='wqimage']:first");
    wqjq(".wqpc_textarea").val(init.attr('alt'));
    wqjq(".wq_imageurl").val(init.attr('src'));
    init.css("border","1px solid #F00");
    wqjq(".wqimage").click(function() {
        var obj = wqjq(this);
        var message = obj.attr('alt');
        var imageurl = obj.attr('src');
        wqjq("img[class='wqimage']").css('border-color','#fff');
        obj.css("border","1px solid #F00");
        wqjq(".wqpc_textarea").val(message);
        wqjq(".wq_imageurl").val(imageurl);
    });

});

function wqsign_bansubmit(){
    wqjq('.wqpc_button').attr("disabled","disabled");
    wqjq('.wqpc_button').html('&#31614;&#21040;&#20013;');
}