<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_monthsignlog.inc.php 2016-8-15 17:12:14Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/config.php';
$y = date('Y');
for($i = 1; $i <= 12; $i++) {
	$temp = $i < 10 ? $y . '0' . $i : $y . $i;
	$marr[$temp] = $temp;
}

$orderfield = in_array($_GET['orderfield'], array('continuoussigntimes', 'monthsign', 'totalsign', 'totalreward', 'dateline')) ? $_GET['orderfield'] : 'dateline';
$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'desc';
$username = isset($_GET['username']) ? trim($_GET['username']) : '';

$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'];
$start = ($page - 1 ) * $perpage;

$re = C::t("#wq_sign#wq_sign_userinfo")->fetch_all_by_search($orderfield, $orderby, $username, $start, $perpage);
$count = C::t("#wq_sign#wq_sign_userinfo")->count_by_search($username);

$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_monthsignlog';

$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_monthsignlog';
$mpurl .= $orderby ? "&orderby=" . $orderby : '';
$mpurl .= $orderfield ? "&orderfield=" . $orderfield : '';
$mpurl .= $username ? "&username=" . $username : '';
$url = ADMINSCRIPT . '?' . $mpurl;

$field = array(
	'continuoussigntimes' => $Plang['2740a9f232e4361d'],
	'monthsign' => $Plang['d5e7d98993f6b62f'],
	'totalsign' => $Plang['3622e45e23a23552'],
	'totalreward' => $Plang['0f1bf031a542b53f'],
	'dateline' => $Plang['d399dc2a2f95583c'],
);

$orderfield = select_html($field, 'orderfield', $orderfield, false, false);
$orderby = select_html(array('asc' => $Plang['d85de5630e53b00f'], 'desc' => $Plang['9195e1ea77c2b0f0']), 'orderby', $orderby, false);


showformheader($fromurl, '', 'sub');
showtableheader('', 'nobottom');
showtablerow('', array(), array(
	$Plang['db580a3abbfd183e'] . $orderfield
	. "&nbsp;&nbsp;" . $Plang['0c8d7e9cb0e4ad33'] . $orderby
	. '&nbsp;&nbsp;' . $Plang['451d404a6e89197b'] . '<input type="text" name="username" value="' . dhtmlspecialchars($_GET['username']) . '" placeholder="' . $Plang['2aef1a750edcec42'] . '">'
	. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value="' . $Plang['38224a4a6fc78c7c'] . '" title="' . $Plang['f5d7c38c95fd323a'] . '" />',
));
showtablefooter();/*Dism��taobao��com*/
showformfooter();
showtableheader('', 'nobottom');
showsubtitle(array($Plang['bf37a9fc8db5ead8'], $Plang['20271ac60b472d14'], $Plang['5dd4d7316bb3e778'], $Plang['82be091a4020053d'], $Plang['bfff9496cac2ba8a'], $Plang['0f1bf031a542b53f'], $Plang['2f3a62a9e7aca6f6']));
foreach($re as $key => $val) {
	$dataline = wq_dgmdate($val["dateline"], 'Y-m-d H:i:s');
	showtablerow('', array(), array(
		$val['month'],
		$val['username'],
		intval($val['continuoussigntimes']),
		intval($val['monthsign']),
		intval($val['totalsign']),
		intval($val['totalreward']),
		$dataline
	));
}
$multi = multi($count, $perpage, $page, $url);
echo "<tr><td colspan = '7' align = 'right'>" . $multi . "</td></tr>";
showtablefooter();/*Dism��taobao��com*/

?>