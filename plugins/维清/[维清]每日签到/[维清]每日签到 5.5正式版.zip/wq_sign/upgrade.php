<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: upgrade.php 2016-8-10 09:37:22Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/wq_sign/config/config.php';
require_once DISCUZ_ROOT . './source/plugin/wq_sign/language/install_language.php';
$request_url = str_replace('&step=' . $_GET['step'], '', $_SERVER['QUERY_STRING']);

switch($_GET['step']) {
	default:
	case 'updatecache':
		$updatecache = '';
		cpmsg($Plang_install['updatecacheing'], "{$request_url}&step=sql", 'loading', array('cache' => $updatecache));
		break;
	case 'sql':
		if($_GET['fromversion'] <= 1.4) {
			$sql = "ALTER TABLE  `pre_wq_sign_logs` ADD  `tid` MEDIUMINT( 8 ) UNSIGNED NOT NULL;\n" .
				"ALTER TABLE  `pre_wq_sign_logs` ADD INDEX (  `tid` );\n" .
				"ALTER TABLE  `pre_wq_sign_logs` ADD  `continuousreward` INT( 10 ) UNSIGNED NOT NULL;\n" .
				"ALTER TABLE  `pre_wq_sign_logs` ADD  `randreward` INT( 10 ) UNSIGNED NOT NULL;\n" .
				"ALTER TABLE  `pre_wq_sign_snyc_tid` ADD  `id` INT( 10 ) UNSIGNED NOT NULL FIRST;\n" .
				"ALTER TABLE  `pre_wq_sign_snyc_tid` ADD PRIMARY KEY (  `id` );\n" .
				"ALTER TABLE  `pre_wq_sign_snyc_tid` ADD  `day` VARCHAR( 8 ) NOT NULL;\n" .
				"ALTER TABLE  `pre_wq_sign_snyc_tid` ADD INDEX (  `tid` );\n" .
				"ALTER TABLE  `pre_wq_sign_snyc_tid` ADD INDEX (  `day` );";
			runquery($sql);

			$sql = "DELETE FROM `pre_wq_sign_snyc_tid` LIMIT 1;";
			runquery($sql);
		}
		if($_GET['fromversion'] < 2.5) {
			wq_sign_cron_create('wq_sign');
		}


		if($_GET['fromversion'] <= 2.6) {
			$query = DB::query("SHOW COLUMNS FROM " . DB::table('wq_sign_icon'));
			$icon_field = array();
			while($row = DB::fetch($query)) {
				$icon_field[] = $row['Field'];
			}
			$icon_query = DB::query("SHOW INDEX FROM " . DB::table('wq_sign_icon'));
			$icon_index = array();
			while($row = DB::fetch($icon_query)) {
				$icon_index[] = $row['Key_name'];
			}

			if(in_array('image', $icon_field) && !in_array('image', $icon_index)) {
				$sql = "ALTER TABLE " . DB::table('wq_sign_icon') . " ADD INDEX `image` (`image`);";
				DB::query($sql);
			}
		}


		cpmsg($Plang_install['finish'], "{$request_url}&step=ok", 'loading', array('operation' => $Plang_install[$operation]));
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
//From: Dism_taobao-com
?>