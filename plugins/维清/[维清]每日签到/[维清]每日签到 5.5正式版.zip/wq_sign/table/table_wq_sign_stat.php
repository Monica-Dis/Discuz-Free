<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_smslogin_sample.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_sign_stat extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_sign_stat';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first() {
		return DB::fetch_first("SELECT * FROM %t", array($this->_table));
	}

}
//From: Dism_taobao-com
?>