<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_smslogin_sample.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_sign_userinfo extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_sign_userinfo';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_first_by_uid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
	}

	public function count_by_all_and_moth($_month = '') {
		$arr = array($this->_table);
		if($_month) {
			$monthcount = "AND month=%s";
			$arr = array($this->_table, $_month);
		}
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE 1 " . $monthcount, $arr);
	}

	public function fetch_all_by_search($orderfield, $orderby, $username, $start, $perpage) {
		$val[] = $this->_table;
		$sql[] = 1;
		$order = '';
		if($orderfield && $orderby) {
			$order = ' ORDER BY ' . $orderfield . ' ' . $orderby . ' ';
		}

		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . $order . DB::limit($start, $perpage), $val);
	}

	public function count_by_search($username) {
		$val[] = $this->_table;
		$sql[] = 1;
		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}
		$where = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
	}

}
//From: Dism_taobao-com
?>