<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_smslogin_sample.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_sign_snyc_tid extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_sign_snyc_tid';
		$this->_pk = 'tid';
		parent::__construct();
	}

	public function fetch_first($day) {
		return DB::fetch_first("SELECT * FROM %t WHERE day=%s", array($this->_table, $day));
	}

	public function fetch_by_tid($tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array($this->_table, $tid));
	}

}
//From: Dism_taobao-com
?>