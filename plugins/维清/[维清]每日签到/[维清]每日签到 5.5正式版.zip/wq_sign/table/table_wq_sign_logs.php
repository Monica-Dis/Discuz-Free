<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_smslogin_sample.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_sign_logs extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_sign_logs';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_yesterday_by_uid($uid, $flag = true) {
		if($flag) {
			$startdate = strtotime(date("Y-m-d", strtotime("-1 day")) . ' 00:00:00');
			$enddate = strtotime(date("Y-m-d", strtotime("-1 day")) . ' 23:59:59');
		} else {
			$startdate = strtotime(date('Y-m-d') . ' 00:00:00');
			$enddate = TIMESTAMP;
		}

		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND dateline between %d AND %d", array($this->_table, $uid, $startdate, $enddate));
	}

	public function fetch_all_by_uid($uid) {
		$startdate = strtotime(date('Y-m-01') . ' 00:00:00');
		$enddate = TIMESTAMP;
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d AND dateline between %d AND %d", array($this->_table, $uid, $startdate, $enddate));
	}

	public function fetch_day_all($start, $limit, $orderby = '', $username = '') {
		$val[] = $this->_table;
		$sql[] = 1;
		$sql[] = 'dateline between %d AND %d';
		$val[] = strtotime(date('Y-m-d') . ' 00:00:00');
		$val[] = TIMESTAMP;
		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}

		$where = implode(' AND ', $sql);
		$orderby = $orderby ? ' ORDER BY dateline ' . $orderby : ' ORDER BY dateline ASC';
		return DB::fetch_all("SELECT * FROM %t WHERE " . $where . $orderby . DB::limit($start, $limit), $val
		);
	}

	public function count($username = '', $flag = false) {
		$val[] = $this->_table;
		$sql[] = 1;
		$sql[] = 'dateline between %d AND %d';
		if($flag) {
			$val[] = strtotime(date("Y-m-d", strtotime("-1 day")) . ' 00:00:00');
			$val[] = strtotime(date("Y-m-d", strtotime("-1 day")) . ' 23:59:59');
		} else {
			$val[] = strtotime(date('Y-m-d') . ' 00:00:00');
			$val[] = TIMESTAMP;
		}
		if($username) {
			$sql[] = 'username=%s';
			$val[] = $username;
		}
		$where = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $where, $val);
	}

}
//From: Dism_taobao-com
?>