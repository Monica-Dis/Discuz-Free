<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_smslogin_sample.php 2016-6-6 03:29:49Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_sign_icon extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_sign_icon';
		$this->_pk = 'id';
		parent::__construct();
	}

	public function fetch_all($start, $limit, $ids = array(), $flag = false) {
		$val[] = $this->_table;
		$sql[] = '1';
		if($ids) {
			$sql[] = 'id in(%n)';
			$val[] = $ids;
		}
		if($flag) {
			$sql[] = 'available=%d';
			$val[] = 1;
		}
		if(intval($limit)) {
			$page = DB::limit($start, $limit);
		} else {
			$page = '';
		}
		$where = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t  WHERE " . $where . " ORDER BY displayorder ASC" . $page, $val);
	}

	public function count() {
		return DB::result_first("SELECT COUNT(*) FROM %t", array($this->_table));
	}

	public function fetch_by_image($image) {
		return DB::fetch_first("SELECT * FROM %t WHERE image=%s", array($this->_table, $image));
	}

}
//From: Dism_taobao-com
?>