<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_img_manage.inc.php 2016-8-11 17:12:14Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/config.php';
include_once DISCUZ_ROOT . './source/plugin/wq_sign/function/function_admincp_ext.php';

$tips = <<<EOT
<li>{$Plang['c603809aa9b71bad']}</li>
<li>{$Plang['8dd59fdf0fadf17a']}</li>
EOT;
showtips($tips, 'tips', TRUE, $Plang['711ee2d6c46bc5a3']);
if($_GET['mod'] == 'import') {
	include_once DISCUZ_ROOT . './source/plugin/wq_sign/install/img_array.php';
	$insertdata = array(
		'displayorder' => 0,
		'available' => 1,
	);
	$s = 0;
	$e = 0;
	foreach($imgarr as $key => $value) {
		$list = C::t('#wq_sign#wq_sign_icon')->fetch_by_image($value['image']);
		$insertdata['image'] = $value['image'];
		$insertdata['message'] = $value['msg'];
		if(!$list) {
			$result = C::t('#wq_sign#wq_sign_icon')->insert($insertdata);
			$s = $result ? $s + 1 : $s;
		} else {
			$e++;
		}
	}
	cpmsg(sprintf($Plang['01105c16edda78fb'], $s, $e), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_img_manage', 'succeed');
}
if(!submitcheck('form')) {
	$page = max(1, $_GET['page']);
	$perpage = $setting['admincp_perpage'] ? $setting['admincp_perpage'] : 10;
	$start = ($page - 1 ) * $perpage;

	$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_img_manage';
	$list = C::t('#wq_sign#wq_sign_icon')->fetch_all($start, $perpage);
	$count = C::t('#wq_sign#wq_sign_icon')->count();

	$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_img_manage';
	$mpurl = ADMINSCRIPT . '?' . $mpurl;
	showformheader($fromurl, 'enctype', 'form');
	showtableheader('', 'nobottom');
	showsubtitle(array('', $Plang['bd940fc8596f83d8'], $Plang['5ab31302b49e348f'], $Plang['2250d0b210048d79'], $Plang['04eb04651aeb0d87']));
	foreach($list as $key => $val) {
		$checkavailable = $val['available'] ? 'checked' : '';
		showtablerow('', array(), array(
			'<a name = "class_' . $val['id'] . '"><input class = "fs" type = "checkbox" name = "delete[]" value = "' . $val['id'] . '" /></a> ',
			'<input style="width:30px;" type = "number" name="displayorder[' . $val ['id'] . ']" value = "' . $val['displayorder'] . '" />',
			'<img src="' . $val['image'] . '" alt="' . $val['message'] . '" width="60px">',
			'<textarea  name="message[' . $val ['id'] . ']" cols="20" rows="3">' . $val['message'] . '</textarea>',
			'<input class = "fs" type = "checkbox" name="available[' . $val ['id'] . ']" value = "1" ' . $checkavailable . ' />',
		));
	}
	$multi = multi($count, $perpage, $page, $mpurl);
	echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "javascripe:;" onclick = "wq_addrow(this, 0, 1)" class = "addtr">' . $Plang['b7d63548f8406158'] . '</a></div></td></tr>';
	showsubmit('form', 'submit', 'del', '&nbsp;&nbsp;<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_img_manage&mod=import">' . $Plang['a8cfef32208f1115'] . '</a>', $multi, false);
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();


	$insertavailable = '<input name="insertavailable[\'+addrowkey+\']" value="1" class="user" type="checkbox" checked="checked" >';
	echo <<<EOF
<script type='text/JavaScript'>
    var rowtypedata = [[[1,''],[1,'<input name = "insertdisplayorder[]" style="width:30px;" type = "number" >'],[1, '<input style="border:none;background:none;" name = "insertimage[]" " class="user" type="file" >'],[1, '<textarea name="insertmessage[]" cols="20" rows="3" ></textarea>'],[1,'<div><input name = "insertdisplayorder[]" class="user" type="checkbox" value=1>&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this)">{$Plang['0d9efacf5089d88c']}</a></div>']],];
    var addrowdirect = 0;
    var addrowkey = 0;
    function wq_addrow(obj, type,flag) {
        if(flag == 2){
            addrowkey--;
        }else{
            var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
            if(!addrowdirect) {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
            } else {
                    var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
            }
          var rowtypedata = [[[1,''],[1,'<input name = "insertdisplayorder[]" style="width:30px;" type = "number" >'],[1, '<input style="border:none;background:none;" name = "insertimage[]" " class="user" type="file" >'],[1, '<textarea name="insertmessage[]" cols="20" rows="3" ></textarea>'],[1,'<div>$insertavailable&nbsp;<a href="javascript:;" class="deleterow" onclick="deleterow(this),wq_addrow(this, 0,2)">{$Plang['0d9efacf5089d88c']}</a></div>']],];

            var typedata = rowtypedata[type];
            for(var i = 0; i <= typedata.length - 1; i++) {
                    var cell = row.insertCell(i);
                    cell.colSpan = typedata[i][0];
                    var tmp = typedata[i][1];
                    if(typedata[i][2]) {
                            cell.className = typedata[i][2];
                    }
                    tmp = tmp.replace(/\{(n)\}/g, function($1) {return addrowkey;});
                    tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
                    cell.innerHTML = tmp;
            }
            addrowkey ++;
            addrowdirect = 0;
        }
    }
</script>
EOF;
} else {
	if($_GET['message']) {
		foreach($_GET['message'] as $key => $val) {
			$message = $val ? $val : '';
			$displayorder = $_GET['displayorder'][$key] ? $_GET['displayorder'][$key] : '';
			$available = $_GET['available'][$key] ? $_GET['available'][$key] : '0';
			$data = array('message' => $message, 'displayorder' => $displayorder, 'available' => $available);
			C::t('#wq_sign#wq_sign_icon')->update(intval($key), $data);
		}
	}
	if($_GET['delete']) {
		$re = C::t("#wq_sign#wq_sign_icon")->fetch_all(0, 0, $_GET['delete']);
		foreach($re as $key => $val) {
			$expl = explode('/', $val['image']);
			if($expl[0] == 'data' && $expl[1] == 'attachment') {
				unlink($val['image']);
			}
			C::t('#wq_sign#wq_sign_icon')->delete($val['id']);
		}
	}
	if($_FILES["insertimage"]) {
		$insertdisplayorder = $_GET['insertdisplayorder'];
		$insertmessage = $_GET['insertmessage'];
		$insertavailable = $_GET['insertavailable'];
		$ph_size = wq_sign_formatBytes($setting['imagesize']);
		$upload_image = wq_sign_get_upload_images($_FILES["insertimage"]);
		$succee = wq_sign_save_article_images($upload_image, $insertdisplayorder, $insertmessage, $insertavailable, $ph_size);
	}

	cpmsg($Plang['357c80f9fe7dbb3f'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_img_manage', 'succeed');
}
//From: Dism_taobao-com
?>