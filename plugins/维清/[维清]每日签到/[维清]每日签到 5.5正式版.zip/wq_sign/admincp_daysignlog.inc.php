<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_daysignlog.inc.php 2016-08-15 16:20:10Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/config.php';

$orderby = in_array($_GET['orderby'], array('desc', 'asc')) ? $_GET['orderby'] : 'asc';
$username = isset($_GET['username']) ? trim($_GET['username']) : '';

$page = max(1, $_GET['page']);
$perpage = $setting['admincp_perpage'];
$start = ($page - 1 ) * $perpage;

$re = C::t("#wq_sign#wq_sign_logs")->fetch_day_all($start, $perpage, $orderby, $username);
$count = C::t("#wq_sign#wq_sign_logs")->count($username);


$fromurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_daysignlog';

$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_sign&pmod=admincp_daysignlog';
$mpurl .= $orderby ? "&orderby=" . $orderby : '';
$mpurl .= $username ? "&username=" . $username : '';
$url = ADMINSCRIPT . '?' . $mpurl;

$orderby = select_html(array('asc' => $Plang['d85de5630e53b00f'], 'desc' => $Plang['9195e1ea77c2b0f0']), 'orderby', $orderby, false);


showformheader($fromurl, '', 'sub');
showtableheader('', 'nobottom');
showtablerow('', array(), array(
	$Plang['9fc2d0015be31e21'] . $orderby
	. '&nbsp;&nbsp;' . $Plang['451d404a6e89197b'] . '<input type="text" name="username" value="' . dhtmlspecialchars($_GET['username']) . '" placeholder="' . $Plang['2aef1a750edcec42'] . '">'
	. '&nbsp;&nbsp;<input id="submit_forms"  class="btn" type="submit" name="sub" value="' . $Plang['38224a4a6fc78c7c'] . '" title="' . $Plang['f5d7c38c95fd323a'] . '" />',
));
showtablefooter();/*Dism��taobao��com*/
showformfooter();
showtableheader('', 'nobottom');
showsubtitle(array($Plang['20271ac60b472d14'], $Plang['1e5ba7942f3e4b27'], $Plang['70ad0bcbf2229f1d'], $Plang['79c4ed2003e478f0'], $Plang['271ab4f02e8ae0f5']));
foreach($re as $key => $val) {
	$dataline = wq_dgmdate($val["dateline"], 'Y-m-d H:i:s');
	showtablerow('', array(), array(
		$val['username'],
		"<img src=" . $val['image'] . " width='90px' height='80px'>",
		$val['message'],
		intval($val['rewardnum']),
		$dataline
	));
}
$multi = multi($count, $perpage, $page, $url);
echo "<tr><td colspan = '5' align = 'right'>" . $multi . "</td></tr>";
showtablefooter();/*Dism��taobao��com*/

?>