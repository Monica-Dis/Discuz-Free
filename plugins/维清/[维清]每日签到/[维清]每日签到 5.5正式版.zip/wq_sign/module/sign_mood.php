<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: toedit_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}
$dayissign = C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid'], false);

if($dayissign) {
	showmessage($Plang['355a63725ba5e0d5'], "./");
}

if(submitcheck("confirmsubmit")) {

	$credittype = $_G['setting']['extcredits'][$setting['credittype']]['title'];

	if($_GET['message'] == '') {
		showmessage(wqadd_f($Plang['e14de1657f3234tg']));
	}

	$userinfo = C::t('#wq_sign#wq_sign_userinfo')->fetch_first_by_uid($_G['uid']);

	$daycount = C::t('#wq_sign#wq_sign_logs')->count();

	$id = 0;
	if($userinfo) {
		$id = $userinfo['id'];
	}

	$str = $Plang['7d73fd61bdc4224b'];
	$countreward = $continuousreward = $reward = 0;
	$time = date("Y-m-d H:i:s", time());
	$num = intval($daycount) + 1;
	$forum_message_sign = $forum_message_rand = $forum_message_continuousreward = '';
	if($setting['credittype'] != '') {
		$countreward = $setting['rewardnum'];
		$str = $Plang['f017955706260eda'] . $credittype . "+<span>" . $countreward . "</span>";

		if($setting['sync_to_fourm'] == 1) {
			$forum_message_sign = sprintf($Plang['forum_message_sign'], $setting['rewardnum'], $credittype);
		}
	}

	if($daycount <= 0) {
		wq_sing_update_daycount_or_monthcount();
		if(intval(date("d")) == 1) {
			wq_sing_update_daycount_or_monthcount(false);
		}
	}

	if($setting['credittype'] != '') {
		if($setting['is_rand_reward'] == 1) {
			if(intval($daycount) < $setting['rand_no']) {
				$reward = intval(mt_rand($setting['min_reward'], $setting['max_reward']));
				$str = $str . $Plang['c6c90efa9c86ad48'] . $setting['rand_no'] . $Plang['4dce781cedf2674c'] . $credittype . "+<span>" . $reward . "</span>";
				$countreward = $countreward + $reward;
				if($setting['sync_to_fourm'] == 1) {
					$forum_message_rand = sprintf($Plang['forum_message_rand'], $setting['rand_no'], $reward, $credittype);
				}
			}
		}
	}

	$message = $_GET['message'];
	$imageurl = '';
	if($_GET['imageurl'] != '') {
		$imageurl = $_GET['imageurl'];
		if(!$setting['signmsg_isedit']) {
			$list = C::t('#wq_sign#wq_sign_icon')->fetch_by_image($imageurl);
			if($list && $message != $list['message']) {
				$message = '';
			}
		}
	}

	$continuoussigntimes = intval($userinfo['continuoussigntimes']) + 1;
	$totalsign = intval($userinfo['totalsign']) + 1;
	$monthsign = intval($userinfo['monthsign']) + 1;
	$_month = intval(date('Y') . date("m"));

	if($_month != $userinfo['month']) {
		$monthsign = 1;
	}

	$yesterday = C::t('#wq_sign#wq_sign_logs')->fetch_yesterday_by_uid($_G['uid']);
	if(!$yesterday) {
		$continuoussigntimes = 1;
	}

	if($setting['credittype'] != '') {
		if($setting['is_continuousreward'] == 1) {
			foreach($continuousrewardnums as $key => $val) {
				if($val[0] != $continuoussigntimes) {
					continue;
				}
				$str = $str . $Plang['ffea94836635bd47'] . $continuoussigntimes . $Plang['b75c8fd344c82628'] . $credittype . "+<span>" . intval($val[1]) . "</span>";
				$countreward = intval($countreward) + intval($val[1]);
				$continuousreward = intval($val[1]);
				if($setting['sync_to_fourm'] == 1) {
					$forum_message_continuousreward = sprintf($Plang['forum_message_continuousreward'], $continuoussigntimes, $continuousreward, $credittype);
				}
			}
		}
	}

	$totalreward = intval($userinfo['totalreward']) + intval($countreward);

	if($continuoussigntimes == $continuous_sign_max_num[0]) {
		$continuoussigntimes = 0;
	}

	$tid = '';
	if($setting['sync_to_fourm'] == 1) {
		if($setting['sync_fid'] != '') {
			$day = trim(date("Y") . date("m") . date("d"));
			$title = sprintf($Plang['forum_title'], date("Y"), date("m"), date("d"));
			$forum_message = sprintf($Plang['forum_message'], $time, $num, intval($countreward), $credittype, $credittype);
			$forum_message = str_replace("{detail}", $forum_message_sign . $forum_message_rand . $forum_message_continuousreward, $forum_message);
			$forum_message .= "\n" . $message;
			$forum_message .= "\n" . "[img]" . $imageurl . "[/img]";
			$retid = C::t("#wq_sign#wq_sign_snyc_tid")->fetch_first($day);
			if(!$retid) {
				$tid = wq_sign_sync_to_forum($title, $setting['sync_fid'], $forum_message, 0, 0, $_G['username'], $_G['uid']);
				C::t("#wq_sign#wq_sign_snyc_tid")->insert(array("day" => $day, "tid" => $tid));
			} else {
				$tid = wq_sing_reply_to_forum($forum_message, $retid['tid'], $setting['sync_fid']);
			}
		}
	}
	wq_sign_save_wq_sign_userinfo($_month, $continuoussigntimes, $monthsign, $totalsign, $totalreward, $id);
	wq_sign_save_wq_sign_logs($countreward, $message, $imageurl, $tid, $continuousreward, $reward);
	wq_sign_save_wq_sign_stat($_month);

	if($setting['credittype'] != '') {
		wq_sign_update_user_credit_operation($countreward, $str);
	}
	if($_G['mobile']) {
		showmessage(wqadd_f($str));
	}

	showmessage($str, 'plugin.php?id=wq_sign');
} else {

	$re = C::t("#wq_sign#wq_sign_icon")->fetch_all(0, 0, '', true);
	$maxk = max(array_keys($re));

	$str1 = '';
	$str2 = '';
	if($maxk <= 3) {
		foreach($re as $key => $val) {
			$str1 .= "<td><a href=\"javascript:;\"><img src='" . $val['image'] . "' alt='" . $val['message'] . "' data=" . $val['id'] . " class='wqimage'></a></td>";
		}
	} elseif($maxk <= 7) {
		foreach($re as $key => $val) {
			if($key < 4) {
				$str1 .= "<td><a href=\"javascript:;\"><img src='" . $val['image'] . "' alt='" . $val['message'] . "' data='" . $val['id'] . "' class='wqimage'></a></td>";
			} else {
				$str2 .= "<td><a href=\"javascript:;\"><img src='" . $val['image'] . "' alt='" . $val['message'] . "' data='" . $val['id'] . "' class='wqimage'></a></td>";
			}
		}
	} else {
		foreach($re as $key => $val) {
			if($key % 2 == 0) {
				$str1 .= "<td><a href=\"javascript:;\"><img src='" . $val['image'] . "' alt='" . $val['message'] . "' data='" . $val['id'] . "' class='wqimage'></a></td>";
			} else {
				$str2 .= "<td><a href=\"javascript:;\"><img src='" . $val['image'] . "' alt='" . $val['message'] . "' data='" . $val['id'] . "' class='wqimage'></a></td>";
			}
		}
	}
	include_once template('wq_sign:tpl_sign_mood');
}
//From: Dism_taobao-com
?>