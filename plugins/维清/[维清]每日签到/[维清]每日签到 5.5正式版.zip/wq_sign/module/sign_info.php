<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: toedit_index.php 2016-2-15 10:55:56Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_year = date("Y");
$_month = date("m");
$day = intval(date('d'));
$date = trim(date("Y") . date("m") . date('d'));
$_currentDate = $_year . $Plang['d259bfc81a7b2bf4'] . $_month . $Plang['bf37a9fc8db5ead8'];
$_days = date("t", mktime(0, 0, 0, $_month, 1, $_year));
$_dayofweek = date("w", mktime(0, 0, 0, $_month, 1, $_year));
$monthsignlist = C::t('#wq_sign#wq_sign_logs')->fetch_all_by_uid($_G['uid']);
foreach($monthsignlist as $key => $value) {
	$dayarr[] = intval(date('d', $value['dateline']));
}

$calendar = wq_sign_get_calendar($_dayofweek, $_days, $dayarr);

$statdata = C::t('#wq_sign#wq_sign_userinfo')->fetch_first_by_uid($_G['uid']);

if(!$statdata['totalreward']) {
	$statdata['totalreward'] = 0;
}
if(!$statdata['totalsign']) {
	$statdata['totalsign'] = 0;
}
if(!$statdata['continuoussigntimes']) {
	$statdata['continuoussigntimes'] = 0;
}

$countnum = C::t('#wq_sign#wq_sign_stat')->fetch_first();
if(!$countnum['count']) {
	$countnum['count'] = 0;
}
if(!$countnum['daycount']) {
	$countnum['daycount'] = 0;
}
if(!$countnum['monthcount']) {
	$countnum['monthcount'] = 0;
}

if(!$_G['mobile']) {
	$page = $_G['page'] ? intval($_G['page']) : 1;
	$ac = $_GET['ac'] ? trim($_GET['ac']) : 'daysign';
	$redata = wq_sign_get_daysign_and_totaldays_and_totalreward($page, $ac);
	$multi = $redata['pagestyle'];
	$list = $redata['list'];
	$style[$ac] = 'class="wqpc_on"';
}

$sign_btn_grey = wq_sign_get_tom_reward($statdata, $countnum, $continuous_sign_max_num, $continuousrewardnums);

$title = str_replace(array('${rnum}', '${pnum}'), array($setting['rewardnum'], $countnum['count']), $setting['title']);
$yestercount = C::t('#wq_sign#wq_sign_logs')->count('', true);

$seodata = array('bbname' => $_G['setting']['bbname']);
$sign_seo['info']['seotitle'] = $navtitle . '-' . $sign_seo['info']['seotitle'];
list($navtitle, $metadescription, $metakeywords) = wq_get_seosetting($seodata, $sign_seo['info']);

include_once template('wq_sign:tpl_sign_info');

?>