<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base.php 2017-12-28 11:16:01Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setting = $_G['cache']['plugin']['wq_sign'];
$setting['forc_sign'] = intval($setting['forc_sign']);
$setting['usergroups'] = unserialize($setting['usergroups']);
$setting['signmsg_isedit'] = intval($setting['signmsg_isedit']);
$setting['credittype'] = intval($setting['credittype']);
$setting['rewardnum'] = intval($setting['rewardnum']);
$setting['is_continuousreward'] = intval($setting['is_continuousreward']);
$setting['continuousrewardnum'] = trim($setting['continuousrewardnum']);
$setting['is_rand_reward'] = intval($setting['is_rand_reward']);
$setting['rand_no'] = intval($setting['rand_no']);
$setting['min_reward'] = intval($setting['min_reward']);
$setting['max_reward'] = intval($setting['max_reward']);
$setting['reward_rule'] = trim($setting['reward_rule']);
$setting['sync_to_fourm'] = intval($setting['sync_to_fourm']);
$setting['sync_fid'] = intval($setting['sync_fid']);
$setting['perpage'] = intval($setting['perpage']);
$setting['admincp_perpage'] = intval($setting['admincp_perpage']);
$setting['imagesize'] = intval($setting['imagesize']);
$setting['style'] = trim($setting['style']);
$setting['right_width'] = intval($setting['right_width']);
$setting['color'] = trim($setting['color']);
$setting['title'] = trim($setting['title']);

?>