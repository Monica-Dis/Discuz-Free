<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-8-10 09:37:22Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_sign/config/setting_base.php';

$setting['perpage'] = $setting['perpage'] ? intval($setting['perpage']) : 10;
$setting['admincp_perpage'] = $setting['admincp_perpage'] ? intval($setting['admincp_perpage']) : 20;
$setting['imagesize'] = $setting['imagesize'] ? $setting['imagesize'] : 1;
$setting['min_reward'] = $setting['min_reward'] < 1 ? 1 : intval($setting['min_reward']);
$setting['max_reward'] = $setting['max_reward'] < $setting['min_reward'] ? $setting['min_reward'] * 2 : intval($setting['max_reward']);
$setting['color'] = $setting['color'] ? $setting['color'] : $setting['style'];

?>