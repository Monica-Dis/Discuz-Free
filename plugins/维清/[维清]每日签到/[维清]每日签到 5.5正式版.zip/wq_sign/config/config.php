<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2016-8-10 09:37:22Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_sign/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_sign/function/function_sign.php';
$Plang = wq_loadlang('wq_sign');
$setting = wq_loadsetting('wq_sign');
$sign_seo = dunserialize($_G['setting']['sign_seo']);
$continuousrewardnum = explode("\n", str_replace("\r\n", "\n", $setting['continuousrewardnum']));
foreach($continuousrewardnum as $key => $val) {
	$continuousrewardnums[$key] = explode("=", $val);
	$continuous_sign_max_num[$key] = substr($val, 0, strrpos($val, '='));
}
arsort($continuous_sign_max_num);
$continuous_sign_max_num = array_values($continuous_sign_max_num);

?>