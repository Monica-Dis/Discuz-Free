<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_admincp.php 2015-12-28 21:11:17Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_sign_save_article_images($upload_image, $insertdisplayorder, $insertmessage, $insertavailable, $ph_size) {
	foreach($upload_image as $key => $val) {
		if($val['error'] > 0) {
			continue;
		}
		switch($val['type']) {
			case'image/pjpeg':
				$filetype = '.jpg';
				break;
			case'image/jpeg':
				$filetype = '.jpg';
				break;
			case'image/gif':
				$filetype = '.gif';
				break;
			case'image/png':
				$filetype = '.png';
				break;
			default:
				continue;
		}
		if($val['size'] > $ph_size) {
			continue;
		}
		if($val['name'] == '') {
			continue;
		}
		$dir = DISCUZ_ROOT . "data/attachment/wq_sign/biaoqing/";
		if(!file_exists($dir)) {
			dmkdir($dir, 0777);
		}

		$file_server_address = $dir . md5($val['name']) . $filetype;
		if(file_exists($file_server_address)) {
			continue;
		}

		$result = move_uploaded_file($val["tmp_name"], $file_server_address);
		if(!$result) {
			continue;
		}

		$filename = 'data/attachment/wq_sign/biaoqing/' . md5($val['name']) . $filetype;
		$message = $insertmessage[$key] ? $insertmessage[$key] : '';
		$displayorder = $insertdisplayorder[$key] ? intval($insertdisplayorder[$key]) : '';
		$available = $insertavailable[$key] ? $insertavailable[$key] : '0';
		wq_sign_icon_save_table($filename, $message, $displayorder, $available);
		$n++;
	}
	return $n;
}

function wq_sign_icon_save_table($filename, $message, $displayorder, $available) {
	$insertdata = array(
		'classid' => '',
		'image' => $filename,
		'message' => $message,
		'displayorder' => $displayorder,
		'available' => $available,
	);

	C::t('#wq_sign#wq_sign_icon')->insert($insertdata);
}

function wq_sign_get_upload_images($insertimage) {
	foreach($insertimage['name'] as $key => $val) {
		$upload_image[$key]['name'] = $val;
	}
	foreach($insertimage['type'] as $key => $val) {
		$upload_image[$key]['type'] = $val;
	}
	foreach($insertimage['tmp_name'] as $key => $val) {
		$upload_image[$key]['tmp_name'] = $val;
	}
	foreach($insertimage['error'] as $key => $val) {
		$upload_image[$key]['error'] = $val;
	}
	foreach($insertimage['size'] as $key => $val) {
		$upload_image[$key]['size'] = $val;
	}
	return $upload_image;
}

function wq_sign_formatBytes($mb) {
	$bytes = ($mb * 1024) * 1024;
	return $bytes;
}
//From: Dism_taobao-com
?>