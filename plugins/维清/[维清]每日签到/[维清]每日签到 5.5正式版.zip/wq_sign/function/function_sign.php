<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_sign_get_calendar($_arg_0, $_arg_1, $_arg_2 = array())
{
	$_var_3 = wq_loadlang("wq_sign");
	$_var_4 = $_var_4 . "<ul class=\"wq_week\">";
	$_var_5 = array($_var_3["0db07997ccf566f3"], $_var_3["e99a9f5b8f195a05"], $_var_3["66f7b33d60427836"], $_var_3["0fc992a59c8425bd"], $_var_3["b3516f3813d73bfa"], $_var_3["1da5f65caaf138d7"], $_var_3["f7aac943e0432764"]);
	foreach ($_var_5 as $_var_6 => $_var_7) {
		if ($_var_7 == $_var_3["0db07997ccf566f3"]) {
			$_var_4 = $_var_4 . ("<li style='color:red;margin-left:1%;'>" . $_var_7 . "</li>");
		} else {
			if ($_var_7 == $_var_3["f7aac943e0432764"]) {
				$_var_4 = $_var_4 . ("<li style='color:red;'>" . $_var_7 . "</li>");
			} else {
				$_var_4 = $_var_4 . ("<li>" . $_var_7 . "</li>");
			}
		}
	}
	$_var_4 = $_var_4 . "</ul><ul class='wq_date'>";
	$_var_8 = 1;
	while ($_var_8 <= $_arg_0) {
		$_var_9 = '';
		if ($_var_8 == 1) {
			$_var_9 = "style='margin-left:1%;'";
		}
		$_var_4 = $_var_4 . ("<li " . $_var_9 . "><span></span></li>");
		$_var_8 = $_var_8 + 1;
	}
	$_var_10 = $_arg_0 + 1;
	$_var_8 = 1;
	while ($_var_8 <= $_arg_1) {
		$_var_9 = '';
		if ($_var_10 % 7 == 1) {
			$_var_9 = "style='margin-left:1%;'";
		}
		if ($_var_8 <= max($_arg_2) && in_array($_var_8, $_arg_2)) {
			if (intval(date("d") == $_var_8)) {
				$_var_4 = $_var_4 . ("<li " . $_var_9 . "><span class='wq_sign_today'>" . $_var_8 . "<br/><i class='wqsign_dot_white'></i></span></li>");
			} else {
				$_var_4 = $_var_4 . ("<li " . $_var_9 . "><span >" . $_var_8 . "<br/><i class='wqsign_dot_red'></i></span></li>");
			}
		} else {
			if (intval(date("d") == $_var_8)) {
				$_var_4 = $_var_4 . ("<li " . $_var_9 . "><span class='wq_sign_notoday'>" . $_var_8 . "<br/><i class='wqsign_dot_white'></i></span></li>");
			} else {
				$_var_4 = $_var_4 . ("<li " . $_var_9 . "><span>" . $_var_8 . "</span></li>");
			}
		}
		$_var_10 = $_var_10 + 1;
		$_var_8 = $_var_8 + 1;
	}
	$_var_11 = 35;
	if ($_arg_1 + $_arg_0 > 35) {
		$_var_11 = 42;
	}
	$_var_12 = (int) $_var_11 - ($_arg_1 + $_arg_0);
	$_var_8 = 1;
	while ($_var_8 <= $_var_12) {
		$_var_4 = $_var_4 . "<li><span></span></li>";
		$_var_8 = $_var_8 + 1;
	}
	$_var_4 = $_var_4 . "</ul>";
	return $_var_4;
}
function wq_sign_save_wq_sign_logs($_arg_0 = '', $_arg_1 = '', $_arg_2 = '', $_arg_3 = '', $_arg_4 = '', $_arg_5 = '')
{
	global $_G;
	$_var_7 = array("tid" => $_arg_3, "uid" => $_G["uid"], "username" => $_G["username"], "image" => $_arg_2, "message" => $_arg_1, "rewardnum" => $_arg_0, "continuousreward" => $_arg_4, "randreward" => $_arg_5, "dateline" => TIMESTAMP);
	C::t("#wq_sign#wq_sign_logs")->insert($_var_7);
}
function wq_sign_save_wq_sign_userinfo($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4, $_arg_5 = 0)
{
	global $_G;
	$_var_7 = array("month" => $_arg_0, "uid" => $_G["uid"], "username" => $_G["username"], "continuoussigntimes" => $_arg_1, "monthsign" => $_arg_2, "totalsign" => $_arg_3, "totalreward" => $_arg_4, "dateline" => TIMESTAMP);
	if ($_arg_5 == 0) {
		C::t("#wq_sign#wq_sign_userinfo")->insert($_var_7);
	} else {
		C::t("#wq_sign#wq_sign_userinfo")->update($_arg_5, $_var_7);
	}
}
function wq_sign_save_wq_sign_stat($_arg_0)
{
	$_var_1 = C::t("#wq_sign#wq_sign_logs")->count();
	$_var_2 = C::t("#wq_sign#wq_sign_userinfo")->count_by_all_and_moth();
	$_var_3 = C::t("#wq_sign#wq_sign_userinfo")->count_by_all_and_moth($_arg_0);
	$_var_4 = array("count" => $_var_2, "daycount" => $_var_1, "monthcount" => $_var_3);
	$_var_5 = C::t("#wq_sign#wq_sign_stat")->fetch_first();
	if (!$_var_5) {
		C::t("#wq_sign#wq_sign_stat")->insert($_var_4);
	} else {
		DB::update("wq_sign_stat", $_var_4, $_var_5);
	}
}
function getTimeDis($_arg_0)
{
	$_var_1 = wq_loadlang("wq_sign");
	$_var_2 = TIMESTAMP - $_arg_0;
	if ($_var_2 <= 0) {
		return $_var_1["d5b838060748e529"];
	}
	if ($_var_2 <= 60) {
		return $_var_2 . $_var_1["bfb0166b10d0a848"];
	}
	if ($_var_2 > 60 && $_var_2 <= 3600) {
		return round($_var_2 / 60) . $_var_1["c50a1af883e12b11"];
	}
	if ($_var_2 > 3600 && $_var_2 <= 86400) {
		return round($_var_2 / 3600) . $_var_1["51cf2b889880be11"];
	}
}
function wq_sign_update_user_credit_operation($_arg_0, $_arg_1)
{
	global $_G;
	global $setting;
	$_var_4 = wq_loadlang("wq_sign");
	$_var_5 = '';
	$_var_6 = $_var_4["26fae20bb4b973b7"];
	updatemembercount($_G["uid"], array($setting["credittype"] => $_arg_0), 1, $_var_5, $_G["uid"], '', $_var_6, $_arg_1);
}
function wq_sign_sync_to_forum($_arg_0, $_arg_1, $_arg_2, $_arg_3 = 0, $_arg_4 = 0, $_arg_5 = '', $_arg_6 = '')
{
	global $_G;
	include_once libfile("function/forum");
	include_once libfile("function/post");
	include_once libfile("function/stat");
	include_once libfile("function/cache");
	loadcache("forums");
	$_var_8 = wq_loadlang("wq_sign");
	if (!empty($_arg_3)) {
		$_arg_0 = $_var_8["160e734657c57a0e"] . $_arg_3 . $_var_8["62019e0d6ba657cd"] . $_arg_0;
	}
	if ($_arg_5 == '') {
		$_arg_5 = $_G["username"];
	}
	if ($_arg_6 == '') {
		$_arg_6 = $_G["uid"];
	}
	$_G["forum"] = C::t("forum_forum")->fetch($_arg_1);
	list($_var_9, $_var_10) = threadmodstatus($_arg_0 . "\t" . $_arg_5);
	$_var_11 = 0;
	$_var_12 = array("fid" => $_arg_1, "typeid" => $_arg_4, "author" => $_arg_5, "lastposter" => $_arg_5, "authorid" => $_arg_6, "displayorder" => $_var_11, "subject" => $_arg_0, "dateline" => $_G["timestamp"], "lastpost" => $_G["timestamp"], "lastposter" => $_arg_5, "status" => 192);
	$_var_13 = C::t("forum_thread")->insert($_var_12, true);
	useractionlog($_G["uid"], "tid");
	C::t("common_member_field_home")->update($_G["uid"], array("recentnote" => $_arg_0));
	$_var_14 = $_var_15 = 0;
	if ($_G["group"]["maxsigsize"]) {
		$_var_14 = 1;
	}
	if (defined("IN_MOBILE")) {
		$_var_15 = setstatus(4, 1, 0);
	}
	$_var_16 = 0;
	$_var_17 = insertpost(array("fid" => $_arg_1, "tid" => $_var_13, "first" => "1", "author" => $_arg_5, "authorid" => $_arg_6, "subject" => $_arg_0, "dateline" => $_G["timestamp"], "message" => $_arg_2, "invisible" => $_var_16, "usesig" => $_var_14, "htmlon" => "1", "useip" => $_G["clientip"], "status" => $_var_15));
	if ($_var_16) {
		updatemoderate("tid", $_var_13);
		C::t("forum_forum")->update_forum_counter($_arg_1, 0, 0, 1);
		manage_addnotify("verifythread");
	} else {
		updatestat("thread");
		updatepostcredits("+", $_arg_6, "post", $_arg_1);
		$_arg_0 = str_replace("\t", " ", $_arg_0);
		$_var_18 = '' . $_var_13 . "\t" . $_arg_0 . "\t" . $_G["timestamp"] . "\t" . $_arg_5;
		C::t("forum_forum")->update($_arg_1, array("lastpost" => $_var_18));
		C::t("forum_forum")->update_forum_counter($_arg_1, 1, 1, 1);
		$_G["forum"] = $_G["cache"]["forums"][$_arg_1];
		if ($_G["forum"]["type"] == "sub") {
			C::t("forum_forum")->update($_G["forum"]["fup"], array("lastpost" => $_var_18));
		}
	}
	return $_var_13;
}
function wq_sing_update_daycount_or_monthcount($_arg_0 = true)
{
	if ($_arg_0) {
		$_var_1 = "daycount=%d";
	} else {
		$_var_1 = "monthcount=%d";
	}
	DB::query("UPDATE %t SET " . $_var_1, array("wq_sign_stat", 0));
}
function wq_sing_reply_to_forum($_arg_0, $_arg_1, $_arg_2 = 0)
{
	global $_G;
	include_once libfile("function/forum");
	include_once libfile("function/post");
	include_once libfile("function/stat");
	include_once libfile("function/cache");
	loadcache("forums");
	$_G["forum"] = C::t("forum_forum")->fetch($_arg_2);
	list($_var_6, $_var_7) = threadmodstatus($_var_4 . "\t" . $_var_5);
	$_var_8 = DB::fetch_first("SELECT * FROM " . DB::table("forum_thread") . " WHERE tid='" . $_arg_1 . "'");
	$_var_9 = defined("IN_MOBILE") ? 8 : 0;
	$_var_10 = 0;
	$_var_11 = insertpost(array("fid" => $_var_8["fid"], "tid" => $_arg_1, "first" => "0", "author" => $_G["username"], "authorid" => $_G["uid"], "subject" => '', "dateline" => $_G["timestamp"], "message" => $_arg_0, "useip" => $_G["clientip"], "port" => getglobal("remoteport"), "invisible" => $_var_10, "anonymous" => "0", "usesig" => "0", "htmlon" => "0", "bbcodeoff" => "0", "smileyoff" => "0", "parseurloff" => "0", "attachment" => "0", "status" => $_var_9));
	$_var_12 = update_threadpartake($_arg_1, true);
	$_var_13 = $_var_12 ? $_var_12 : array();
	$_var_14 = C::t("forum_post")->fetch_maxposition_by_tid($_var_8["posttableid"], $_var_8["tid"]);
	$_var_13[] = DB::field("maxposition", $_var_14);
	useractionlog($_G["uid"], "pid");
	if ($_var_10) {
		updatemoderate("pid", $_var_11);
		if ($_var_13) {
			C::t("forum_thread")->update($_arg_1, $_var_13, false, false, 0, true);
		}
		C::t("forum_forum")->update_forum_counter($_arg_2, 0, 0, 1, 1);
		manage_addnotify("verifypost");
	} else {
		$_var_15 = array("lastposter" => array($_G["username"]), "replies" => 1);
		if ($_var_8["lastpost"] < getglobal("timestamp")) {
			$_var_15["lastpost"] = array(getglobal("timestamp"));
		}
		$_var_16 = C::t("forum_threadaddviews")->fetch($_var_8["tid"]);
		if (!empty($_var_16)) {
			C::t("forum_threadaddviews")->update($_var_8["tid"], array("addviews" => 0));
			$_var_15["views"] = $_var_16["addviews"];
		}
		$_var_13 = array_merge($_var_13, C::t("forum_thread")->increase($_var_8["tid"], $_var_15, false, 0, true));
		updatepostcredits("+", $_G["uid"], "reply", $_var_8["fid"]);
		$_var_17 = '' . $_var_8["tid"] . "\t" . addslashes($_var_8["subject"]) . "\t" . $_G["timestamp"] . "\t" . $_G["username"] . '';
		C::t("forum_forum")->update($_var_8["fid"], array("lastpost" => $_var_17));
		C::t("forum_forum")->update_forum_counter($_var_8["fid"], 0, 1, 1);
		if ($_G["forum"]["type"] == "sub") {
			C::t("forum_forum")->update($_G["forum"]["fup"], array("lastpost" => $_var_17));
		}
		if ($_var_13) {
			C::t("forum_thread")->update($_var_8["tid"], $_var_13, false, false, 0, true);
		}
	}
	return $_arg_1;
}
function wqadd_f($_arg_0)
{
	global $_G;
	$_var_2 = substr($_arg_0, 1);
	if ($_G["mobile"]) {
		$_var_2 = "####" . $_arg_0 . "####";
	}
	return $_var_2;
}
function wq_sign_get_daysign_and_totaldays_and_totalreward($_arg_0, $_arg_1)
{
	global $setting;
	$_var_3 = max(1, $_arg_0);
	$_var_4 = $setting["perpage"];
	$_var_5 = ($_var_3 - 1) * $_var_4;
	$_var_6 = "plugin.php?id=wq_sign&mod=info&ac=" . $_arg_1;
	if ($_arg_1 == "daysign") {
		$_var_7 = C::t("#wq_sign#wq_sign_logs")->fetch_day_all($_var_5, $_var_4);
		$_var_8 = C::t("#wq_sign#wq_sign_logs")->count();
	} else {
		$_var_8 = C::t("#wq_sign#wq_sign_userinfo")->count_by_all_and_moth();
	}
	if ($_arg_1 == "totaldays") {
		$_var_7 = C::t("#wq_sign#wq_sign_userinfo")->fetch_all_by_search("totalsign", "DESC", '', $_var_5, $_var_4);
	}
	if ($_arg_1 == "totalreward") {
		$_var_7 = C::t("#wq_sign#wq_sign_userinfo")->fetch_all_by_search("totalreward", "DESC", '', $_var_5, $_var_4);
	}
	$_var_9 = multi($_var_8, $_var_4, $_var_3, $_var_6);
	return array("list" => $_var_7, "pagestyle" => $_var_9);
}
function wq_sign_get_tom_reward($_arg_0, $_arg_1, $_arg_2, $_arg_3)
{
	global $_G;
	global $setting;
	$_var_6 = wq_loadlang("wq_sign");
	$_var_7 = $_var_6["355a63725ba5e0d5"];
	if ($setting["credittype"] != '') {
		$_var_8 = $setting["rewardnum"];
		$_var_9 = $_arg_0["continuoussigntimes"] + 1;
		if ($_arg_0["continuoussigntimes"] == $_arg_2[0]) {
			$_var_9 = 1;
		}
		if ($setting["is_continuousreward"] == 1) {
			foreach ($_arg_3 as $_var_10 => $_var_11) {
				if ($_var_11[0] == $_var_9) {
					$_var_8 = $_var_8 + intval($_var_11[1]);
				}
			}
		}
		if ($setting["is_rand_reward"] == 1) {
			$_var_12 = intval(mt_rand($setting["min_reward"], $setting["max_reward"]));
			$_var_8 = $_var_8 . "+";
		}
		$_var_13 = $_G["setting"]["extcredits"][$setting["credittype"]]["title"];
		$_var_7 = sprintf($_var_6["sign_btn_grey"], $_arg_0["continuoussigntimes"], $_var_8, $_var_13);
	}
	return $_var_7;
}
function wq_sign_cron_create($_arg_0)
{
	$_var_1 = wq_loadlang("wq_sign");
	if (preg_match("/^[a-z]+[a-z0-9_]*\$/i", $_var_2)) {
		return false;
	}
	$_var_3 = DISCUZ_ROOT . "./source/plugin/" . $_arg_0 . "/cron";
	if (!file_exists($_var_3)) {
		return false;
	}
	$_var_4 = dir($_var_3);
	while ($_var_5 = $_var_4->read()) {
		if (!in_array($_var_5, array(".", "..")) && preg_match("/^cron\\_[\\w\\.]+\$/", $_var_5)) {
			$_var_6 = file_get_contents($_var_3 . "/" . $_var_5);
			preg_match("/cronname\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_8 = $_var_1[trim($_var_7[1])];
			preg_match("/week\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_9 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/day\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_10 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/hour\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_11 = trim($_var_7[1]) ? intval($_var_7[1]) : -1;
			preg_match("/minute\\:(.+?)\n/", $_var_6, $_var_7);
			$_var_12 = trim($_var_7[1]) ? trim($_var_7[1]) : 0;
			$_var_13 = explode(",", $_var_12);
			foreach ($_var_13 as $_var_2 => $_var_14) {
				$_var_13[$_var_2] = $_var_14 = intval($_var_14);
				if ($_var_14 < 0 || $_var_15 > 59) {
					unset($_var_13[$_var_2]);
				}
			}
			$_var_13 = array_slice(array_unique($_var_13), 0, 12);
			$_var_13 = implode("\t", $_var_13);
			$_var_5 = $_arg_0 . ":" . $_var_5;
			$_var_16 = C::t("common_cron")->get_cronid_by_filename($_var_5);
			if (!$_var_16) {
				C::t("common_cron")->insert(array("available" => 1, "type" => "plugin", "name" => $_var_8, "filename" => $_var_5, "weekday" => $_var_9, "day" => $_var_10, "hour" => $_var_11, "minute" => $_var_13));
			} else {
				C::t("common_cron")->update($_var_16, array("name" => $_var_8, "weekday" => $_var_9, "day" => $_var_10, "hour" => $_var_11, "minute" => $_var_13));
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}