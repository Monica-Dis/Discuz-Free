<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-15 21:22:41
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class mobileplugin_replyreward_7ree{

			function viewthread_bottom_mobile(){
				global $_G;
				$return = "";
				$vars_7ree = $_G['cache']['plugin']['replyreward_7ree'];

				if(!$vars_7ree['view_delay_7ree'] || !$vars_7ree['display_dely_7ree']){
					return $return;
				}

				include template('replyreward_7ree:view_countdown_7ree'); 
				return $return;
			}


			function cookielife($format_7ree){
				global $_G;
				$return_7ree = array();
				
				switch ($format_7ree){
				case 1://����cookie��Ч
				  	$return_7ree[0] = mktime(0,0,0,gmdate("m",strtotime("+1 day")),gmdate("d",strtotime("+1 day")),gmdate("Y",strtotime("+1 day")));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
				  	break;
				case 2://����cookie��Ч
				  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("next Monday")),date("d",strtotime("next Monday")),date("Y",strtotime("next Monday")));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benzhou_7ree');
				  	break;
				case 3://����cookie��Ч
		  			$return_7ree[0] = mktime(0,0,0,gmdate("m",strtotime('+1 month')),1,gmdate("Y",strtotime('+1 month')));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benyue_7ree');
		  			break;
				default:
				  	$return_7ree[0] = mktime(0,0,0,gmdate("m",strtotime("+1 day")),gmdate("d",strtotime("+1 day")),gmdate("Y",strtotime("+1 day")));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
				}
				
				return $return_7ree;
		}
		
		function gettime_7ree($format_7ree){
				global $_G;
				$return_7ree = array();

				switch ($format_7ree){
				case 1://����
				  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
				  	break;
				case 2://����
				  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("d",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("Y",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benzhou_7ree');
				  	break;
				case 3://����
		  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benyue_7ree');
		  			break;
				case 4://������
					$season = ceil((gmdate("n",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600))/3);
					$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benji_7ree');
				  	break;
				case 5://�����
				  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_bennian_7ree');
		 		 	break;
				default:
		 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
				  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
				}

				return $return_7ree;

		}
		
		
		function viewthread_bottom_mobile_output() {
			global $_G;
			$vars_7ree = $_G['cache']['plugin']['replyreward_7ree'];
			$return = '';
			
			$fid_7ree = $vars_7ree['fid_7ree'] ? unserialize($vars_7ree['fid_7ree']) : array();
			$group_7ree = $vars_7ree['gid_7ree'] ? unserialize($vars_7ree['gid_7ree']) : array();

			if(!$vars_7ree['agreement_7ree'] || in_array($_G['fid'],$fid_7ree) || !in_array($_G['groupid'] , $group_7ree)){
				return;
			}


			//���㿴�������������ڣ�
			if($_G['uid']){
				$btime3_7ree= $this->gettime_7ree($vars_7ree['cycle3_7ree']);
				$isgot3_7ree = DB::result_first("SELECT id_7ree FROM  ".DB::table('replyreward_log_7ree')." 
													WHERE time_7ree > {$btime3_7ree[0]} AND uid_7ree = {$_G[uid]} AND type_7ree = 3 LIMIT 1");
				if($isgot3_7ree) return;
				$cookiename_7ree = 'vnm7ree_'.$_G['uid'];
				$readvalue_7ree = json_decode(getcookie($cookiename_7ree),true);
				
				if(!$readvalue_7ree['tid'] || $_G['tid']<>$readvalue_7ree['tid']){

					$viewnum_7ree = $readvalue_7ree['num']+1;
					$viewvalue_7ree = array('tid'=>$_G['tid'],'num'=>$viewnum_7ree);
					$time_7ree = $this->cookielife($vars_7ree['cycle3_7ree']);

					$cvalue_7ree=json_encode($viewvalue_7ree);
					
					$extime_7ree= $time_7ree[0]-$_G['timestamp'];

					if($viewnum_7ree <= $vars_7ree['viewnum_7ree']){
						include template('replyreward_7ree:cookiedelay_7ree');
					}

					//dsetcookie($cookiename_7ree,serialize($viewvalue_7ree),$time_7ree[0]-$_G['timestamp']);

				}else{
					$viewnum_7ree = $readvalue_7ree['num'];
				}
				

				if($vars_7ree['pcviewpop_7ree']){
					if($viewnum_7ree > $vars_7ree['viewnum_7ree']){
					$viewext_name_7ree = "extcredits".$vars_7ree['viewext_7ree'];
					$viewext_title_7ree = $_G['setting']['extcredits'][$vars_7ree['viewext_7ree']]['title'];
					$viewreward_7ree = explode(',',$vars_7ree['viewreward_7ree']);
					include template('replyreward_7ree:hongbao_7ree');
					}
				}

			}


			return $return;
		}		
		
	
		
}
		
		
		

class mobileplugin_replyreward_7ree_forum extends mobileplugin_replyreward_7ree{
}

class mobileplugin_replyreward_7ree_group extends mobileplugin_replyreward_7ree{
}
//From: Dism��taobao��com
?>