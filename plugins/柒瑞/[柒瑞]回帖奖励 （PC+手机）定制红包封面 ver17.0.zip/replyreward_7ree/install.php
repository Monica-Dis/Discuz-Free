<?php
/*
	ID: replyreward_7ree 
	(C)2007-2021 [dism.taobao.com]
	This is NOT a freeware, use is subject to license terms
	update 2021/3/17 11:53
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ') || !IN_ADMIN)  exit('Access Denied');

$sql = <<<EOF


CREATE TABLE IF NOT EXISTS `pre_replyreward_log_7ree` (
  `id_7ree` int(10) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(20) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `ip_7ree` varchar(20) NOT NULL,
  `type_7ree` tinyint(1) NOT NULL,
  `extnum_7ree` mediumint(8) NOT NULL,
  `exttitle_7ree` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM ;



EOF;

runquery($sql);

$finish = TRUE;