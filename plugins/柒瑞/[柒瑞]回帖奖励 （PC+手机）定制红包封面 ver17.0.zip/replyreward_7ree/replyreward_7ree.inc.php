<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-01 18:15:19
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$vars_7ree = $_G['cache']['plugin']['replyreward_7ree'];
		
if(!$vars_7ree['agreement_7ree']) showmessage('replyreward_7ree:php_lang_agree_7ree');

		
$_GET['code'] = intval($_GET['code']);
$_GET['page'] = intval($_GET['page']);

$navtitle = lang('plugin/replyreward_7ree', 'php_lang_replyreward_7ree');

if(in_array( $_GET['code'], array("3") ) && $_G['adminid'] != 1 ) showmessage( "Permission denied. @7ree" );

$pagemax_7ree = 20;
$myzhuti_7ree = 0;
$myhuifu_7ree = 0;
$myview_7ree = 0;
$i_7ree = 1;
$get_zhuti_7ree = FALSE;
$get_huifu_7ree = FALSE;
		
$postext_name_7ree = "extcredits".$vars_7ree['postext_7ree'];
$postext_title_7ree = $_G['setting']['extcredits'][$vars_7ree['postext_7ree']]['title'];
$replyext_name_7ree = "extcredits".$vars_7ree['replyext_7ree'];
$replyext_title_7ree = $_G['setting']['extcredits'][$vars_7ree['replyext_7ree']]['title'];
$viewext_name_7ree = "extcredits".$vars_7ree['viewext_7ree'];
$viewext_title_7ree = $_G['setting']['extcredits'][$vars_7ree['viewext_7ree']]['title'];



$remain_zhuti_7ree = $vars_7ree['postnum_7ree'];
$remain_huifu_7ree = $vars_7ree['replynum_7ree'];
$remain_view_7ree = $vars_7ree['viewnum_7ree'];
//�������ֲ��
$postreward_7ree = explode(',',$vars_7ree['postreward_7ree']);
$replyreward_7ree = explode(',',$vars_7ree['replyreward_7ree']);
$viewreward_7ree = explode(',',$vars_7ree['viewreward_7ree']);

$btime1_7ree = gettime_7ree($vars_7ree['cycle1_7ree']);
$btime2_7ree = gettime_7ree($vars_7ree['cycle2_7ree']);
$btime3_7ree = gettime_7ree($vars_7ree['cycle3_7ree']);

$group_7ree = $vars_7ree['gid_7ree'] ? unserialize($vars_7ree['gid_7ree']) : array();
$allowgroup_7ree = in_array($_G['groupid'] , $group_7ree);


if($_G['uid']){
		//��ȡ�ҵĽ�����Ϣ��������Ϣ
		$myinfo_zhuti_7ree = DB::fetch_first("SELECT COUNT(*) AS num_7ree, SUM(extnum_7ree) AS ext_7ree 
												FROM ".DB::table('replyreward_log_7ree')." 
												WHERE uid_7ree = {$_G['uid']} AND type_7ree = 1");
		$myinfo_huifu_7ree = DB::fetch_first("SELECT COUNT(*) AS num_7ree, SUM(extnum_7ree) AS ext_7ree 
												FROM ".DB::table('replyreward_log_7ree')." 
												WHERE uid_7ree = {$_G['uid']} AND type_7ree = 2");
		// type_7ree = 3 ������⽱������
		$myinfo_view_7ree = DB::fetch_first("SELECT COUNT(*) AS num_7ree, SUM(extnum_7ree) AS ext_7ree 
												FROM ".DB::table('replyreward_log_7ree')." 
												WHERE uid_7ree = {$_G['uid']} AND type_7ree = 3");
}
if(!$_GET['code']){
		if($_G['uid']){
				//�鿴�Ƿ������μӵ��û���
		
		
				//�ж��콱������������콱�����ȷ���Ƿ���Ҫ�ٴβ�ѯ����������
				if($allowgroup_7ree){

						$query = DB::query("SELECT type_7ree FROM  ".DB::table('replyreward_log_7ree')." 
											WHERE time_7ree > {$btime1_7ree[0]} AND uid_7ree = {$_G['uid']} AND extnum_7ree>0 LIMIT 3");
						while($table_7ree = DB::fetch($query)){
								if($table_7ree['type_7ree']==1) $get_zhuti_7ree = TRUE;
						}
						$query = DB::query("SELECT type_7ree FROM  ".DB::table('replyreward_log_7ree')." 
											WHERE time_7ree > {$btime2_7ree[0]} AND uid_7ree = {$_G['uid']} AND extnum_7ree>0 LIMIT 3");
						while($table_7ree = DB::fetch($query)){
								if($table_7ree['type_7ree']==2) $get_huifu_7ree = TRUE;
						}

						$query = DB::query("SELECT type_7ree FROM  ".DB::table('replyreward_log_7ree')." 
											WHERE time_7ree > {$btime3_7ree[0]} AND uid_7ree = {$_G['uid']} AND extnum_7ree>0 LIMIT 3");
						while($table_7ree = DB::fetch($query)){
								if($table_7ree['type_7ree']==3) $get_view_7ree = TRUE;
						}

						//��ȡ�ҵĽ�����Ϣ��������Ϣ
						$myzhuti_7ree = getpostnum_7ree($_G['uid'],1,$btime1_7ree[0]);
						$myhuifu_7ree = getpostnum_7ree($_G['uid'],2,$btime2_7ree[0]);

						$cookiename_7ree='vnm7ree_'.$_G['uid'];
						//$readvalue_7ree=unserialize(getcookie($cookiename_7ree));
						$readvalue_7ree=json_decode(getcookie($cookiename_7ree),true);
						$myview_7ree = $readvalue_7ree['num'];

						
						$myzhuti_percent_7ree = min(sprintf("%.2f",$myzhuti_7ree/$vars_7ree['postnum_7ree']) * 100,100);
						$myhuifu_percent_7ree = min(sprintf("%.2f",$myhuifu_7ree/$vars_7ree['replynum_7ree']) * 100,100);
						$myview_percent_7ree = min(sprintf("%.2f",$myview_7ree/$vars_7ree['viewnum_7ree']) * 100,100);
						
						$myzhuti_width_7ree = 305 * sprintf("%.2f",$myzhuti_7ree/$vars_7ree['postnum_7ree']);
						$myhuifu_width_7ree = 305 * sprintf("%.2f",$myhuifu_7ree/$vars_7ree['replynum_7ree']);
						$myview_width_7ree = 305 * sprintf("%.2f",$myview_7ree/$vars_7ree['viewnum_7ree']);
						
						$myzhuti_width_7ree = min(max($myzhuti_width_7ree,40),305);
						$myhuifu_width_7ree = min(max($myhuifu_width_7ree,40),305);
						$myview_width_7ree = min(max($myview_width_7ree,40),305);
						

						$myzhuti_bgcolor_7ree = $myzhuti_width_7ree>40 ? '#CDCDCD':'#FFF';
						$myzhuti_bgcolor_act = $myzhuti_width_7ree>40 ? '#FFEC82':'#FFFDE6';
						$myhuifu_bgcolor_7ree = $myhuifu_width_7ree>40 ? '#CDCDCD':'#FFF';
						$myhuifu_bgcolor_act = $myhuifu_width_7ree>40 ? '#B9DBF9':'#ECFFF6';
						$myview_bgcolor_7ree = $myview_width_7ree>40 ? '#CDCDCD':'#FFF';
						$myview_bgcolor_act = $myview_width_7ree>40 ? '#77C12E':'#ECFFF6';
							
						//�ж�����������
						if(!$get_zhuti_7ree) $remain_zhuti_7ree = $vars_7ree['postnum_7ree']-$myzhuti_7ree ;
						if(!$get_huifu_7ree) $remain_huifu_7ree = $vars_7ree['replynum_7ree']-$myhuifu_7ree ;
						if(!$get_view_7ree) $remain_view_7ree = $vars_7ree['viewnum_7ree']-$myview_7ree ;

				}
		}
}elseif($_GET['code']==1){ //�ҵĽ�����ʷ

		if($_G['uid']){
				$page = max(1, intval($_GET['page']));
				$startpage = ($page - 1) * $pagemax_7ree;
				$querynum = DB::result_first("SELECT Count(*) FROM ".DB::table('replyreward_log_7ree')." WHERE uid_7ree = {$_G['uid']}");
				$query = DB::query("SELECT * FROM  ".DB::table('replyreward_log_7ree')." WHERE uid_7ree = {$_G['uid']} LIMIT {$startpage}, {$pagemax_7ree}");
					while($table_7ree = DB::fetch($query)){
						$table_7ree['time_7ree'] = dgmdate($table_7ree['time_7ree']);
						if($table_7ree['type_7ree']==1){
							$table_7ree['bgcolor_7ree'] = '#FFFDE6';
							$table_7ree['color_7ree'] = '#FF6600';
						}elseif($table_7ree['type_7ree']==2){
							$table_7ree['bgcolor_7ree'] = '#ECFFF6';
							$table_7ree['color_7ree'] = '#006699';
						}else{
							$table_7ree['bgcolor_7ree'] = '#F3FFDC';
							$table_7ree['color_7ree'] = '#174809';
						}
						$list_7ree[] = $table_7ree;
					}
				$multipage = multi($querynum, $pagemax_7ree, $page, "plugin.php?id=replyreward_7ree&code=1");
		}

}elseif($_GET['code']==2){//RANK
	
				$page = max(1, intval($_GET['page']));
				$startpage = ($page - 1) * $pagemax_7ree;
				$querynum = DB::result_first("SELECT count(distinct uid_7ree) FROM ".DB::table('replyreward_log_7ree'));
				$query = DB::query("SELECT *,COUNT(id_7ree) AS nums_7ree FROM  ".DB::table('replyreward_log_7ree')." 
									GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT {$startpage}, {$pagemax_7ree}");
					while($table_7ree = DB::fetch($query)){
					$table_7ree['rankid_7ree'] = $startpage + $i_7ree;
					$table_7ree['rankcss_7ree']='big_7ree';
					if($table_7ree['rankid_7ree']==1) $table_7ree['rankcss_7ree']='bigred_7ree';
					if($table_7ree['rankid_7ree']==2 || $table_7ree['rankid_7ree']==3) $table_7ree['rankcss_7ree']='bigorange_7ree';
						
					$rank_7ree[] = $table_7ree;
					$i_7ree++;
					}
				$multipage = multi($querynum, $pagemax_7ree, $page, "plugin.php?id=replyreward_7ree&code=2");

}elseif($_GET['code']==3){

		if($_GET['formhash']==FORMHASH){
		        DB::query("DELETE FROM ".DB::table('replyreward_log_7ree')." WHERE time_7ree < ".$_G['timestamp']." - 2678400");
				showmessage('replyreward_7ree:php_lang_qingkong3yue_7ree',"plugin.php?id=replyreward_7ree&code=3");

		}else{
				$page = max(1, intval($_GET['page']));
				$startpage = ($page - 1) * $pagemax_7ree;
				$querynum = DB::result_first("SELECT Count(*) FROM ".DB::table('replyreward_log_7ree'));
				$query = DB::query("SELECT * FROM  ".DB::table('replyreward_log_7ree')." 
									ORDER BY id_7ree DESC LIMIT {$startpage}, {$pagemax_7ree}");
					while($table_7ree = DB::fetch($query)){
						$table_7ree['time_7ree'] = dgmdate($table_7ree['time_7ree']);
						if($table_7ree['type_7ree']==1){
							$table_7ree['bgcolor_7ree'] = '#FFFDE6';
							$table_7ree['color_7ree'] = '#FF6600';
						}elseif($table_7ree['type_7ree']==2){
							$table_7ree['bgcolor_7ree'] = '#ECFFF6';
							$table_7ree['color_7ree'] = '#006699';
						}else{
							$table_7ree['bgcolor_7ree'] = '#F3FFDC';
							$table_7ree['color_7ree'] = '#174809';
						}
						$list_7ree[] = $table_7ree;
					}
				$multipage = multi($querynum, $pagemax_7ree, $page, "plugin.php?id=replyreward_7ree&code=3");
		}		
	

}elseif($_GET['code']==4){//��ȡ����
		$_GET['type_7ree'] = intval($_GET['type_7ree']);
		
		if(!$allowgroup_7ree || !$_G['uid']) showmessage('replyreward_7ree:php_lang_bangid_7ree');
		
		
		if(!$_GET['type_7ree']) showmessage("ERROR, Missing required parameter. @7ree");
		//�����Ƿ��Ѿ���ȡ�����ͽ�����
		

		
		
		if($_GET['type_7ree'] == 1){  //type=1 ���ⱻ�ظ���
			
		$isgot1_7ree = DB::result_first("SELECT id_7ree FROM  ".DB::table('replyreward_log_7ree')." 
										WHERE time_7ree > {$btime1_7ree[0]} AND uid_7ree = {$_G['uid']} AND type_7ree = {$_GET['type_7ree']} LIMIT 1");
		if($isgot1_7ree) showmessage('replyreward_7ree:php_lang_chongfulingjiang_7ree');
			
			
			
			$remain_zhuti_7ree = $vars_7ree['postnum_7ree'] - getpostnum_7ree($_G['uid'],1,$btime1_7ree[0]);
			if($remain_zhuti_7ree>0){
				showmessage('replyreward_7ree:php_lang_tiaojianbuhe_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
			}else{

				$extnum_7ree = rand($postreward_7ree[0],$postreward_7ree[1]);
				$insertvalue_7ree = array(
									'uid_7ree' => $_G['uid'],
									'user_7ree' => $_G['username'],
									'time_7ree' => $_G['timestamp'],
									'ip_7ree' => $_G['clientip'],
									'type_7ree' => $_GET['type_7ree'],
									'extnum_7ree' => $extnum_7ree,
									'exttitle_7ree' => $postext_title_7ree,
					
									);
				DB::insert('replyreward_log_7ree', $insertvalue_7ree);
				//���⽱������
				updatemembercount($_G['uid'], array($postext_name_7ree => $extnum_7ree),false,'RWT',7);
				
				showmessage('replyreward_7ree:php_lang_zhutichenggong_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
			}

		}elseif($_GET['type_7ree'] == 2){ //type=2 �ظ�����������
			
		$isgot2_7ree = DB::result_first("SELECT id_7ree FROM  ".DB::table('replyreward_log_7ree')." 
										WHERE time_7ree > {$btime2_7ree[0]} AND uid_7ree = {$_G['uid']} AND type_7ree = {$_GET[type_7ree]} LIMIT 1");
		if($isgot2_7ree) showmessage('replyreward_7ree:php_lang_chongfulingjiang_7ree');
			
				
			$remain_huifu_7ree = $vars_7ree['replynum_7ree'] - getpostnum_7ree($_G['uid'],2,$btime2_7ree[0]);
			if($remain_huifu_7ree>0){
				showmessage('replyreward_7ree:php_lang_tiaojianbuhe_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
			}else{
			
				$extnum_7ree = rand($replyreward_7ree[0],$replyreward_7ree[1]);
				$insertvalue_7ree = array(
									'uid_7ree' => $_G['uid'],
									'user_7ree' => $_G['username'],
									'time_7ree' => $_G['timestamp'],
									'ip_7ree' => $_G['clientip'],
									'type_7ree' => $_GET['type_7ree'],
									'extnum_7ree' => $extnum_7ree,
									'exttitle_7ree' => $replyext_title_7ree,
					
									);
				DB::insert('replyreward_log_7ree', $insertvalue_7ree);
				//�ظ���������
				updatemembercount($_G['uid'], array($replyext_name_7ree => $extnum_7ree),false,'RWR',7);
			
				showmessage('replyreward_7ree:php_lang_huifuchenggong_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
			}

		}elseif($_GET['type_7ree'] == 3){ //type=3 ���������
				$isgot3_7ree = DB::result_first("SELECT id_7ree FROM  ".DB::table('replyreward_log_7ree')." 
												WHERE time_7ree > {$btime3_7ree[0]} AND uid_7ree = {$_G['uid']} AND type_7ree = {$_GET['type_7ree']} LIMIT 1");
				if($isgot3_7ree) showmessage('replyreward_7ree:php_lang_chongfulingjiang_7ree');
				
				
				$cookiename_7ree='vnm7ree_'.$_G['uid'];
				//$readvalue_7ree=unserialize(getcookie($cookiename_7ree));
				$readvalue_7ree=json_decode(getcookie($cookiename_7ree),true);
				$myview_7ree = $readvalue_7ree['num'];
				$remain_view_7ree = $vars_7ree['viewnum_7ree']-$myview_7ree ;
				if($remain_view_7ree>0){
					showmessage('replyreward_7ree:php_lang_tiaojianbuhe_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
				}else{
					$extnum_7ree = rand($viewreward_7ree[0],$viewreward_7ree[1]);
					$insertvalue_7ree = array(
										'uid_7ree' => $_G['uid'],
										'user_7ree' => $_G['username'],
										'time_7ree' => $_G['timestamp'],
										'ip_7ree' => $_G['clientip'],
										'type_7ree' => $_GET['type_7ree'],
										'extnum_7ree' => $extnum_7ree,
										'exttitle_7ree' => $viewext_title_7ree ,
										);
					

					
					DB::insert('replyreward_log_7ree', $insertvalue_7ree);
					//������������
					updatemembercount($_G['uid'], array($viewext_name_7ree => $extnum_7ree),false,'RWV',7);
				
					showmessage('replyreward_7ree:php_lang_viewchenggong_7ree',"plugin.php?id=replyreward_7ree:replyreward_7ree");
				}
		}
	

}elseif($_GET['code']==5){//�ֻ�����֪ҳ��


}else{	
		showmessage("Undefined Operation @ 7ree");
}


	include template('replyreward_7ree:replyreward_7ree');
	
///////////////////////////////////////////////////////////////
//////////////////////������/////////////////////////////////
//////////////////////////////////////////////////////////////

function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("d",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("Y",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/replyreward_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}

		function getpostnum_7ree($uid_7ree,$type_7ree,$btime_7ree){  //��ȡ������������ type=1 ���ⱻ�ظ��� type=2 �ظ�����������
			global $_G;
			$vars_7ree = $_G['cache']['plugin']['replyreward_7ree'];
			$fid_7ree = $vars_7ree['fid_7ree'] ? unserialize($vars_7ree['fid_7ree']) : array();
			$banfid_7ree =  COUNT($fid_7ree) ? " AND p.fid NOT IN (".dimplode($fid_7ree).") ":"";
			
			
			
			$uid_7ree = $uid_7ree ? $uid_7ree : $_G['uid'];
			$type_7ree = $type_7ree ? $type_7ree : 1;
			if(!$btime_7ree) return 'error';
			$return_7ree = 0;
				
			if($vars_7ree['oldthread_7ree']){//���ⱻ�ظ�, �������޷��콱
				$where_tdateline_7ree="AND t.dateline>{$btime_7ree}";
			}else{
				$where_tdateline_7ree='';
			}
			
			if($vars_7ree['newreply_7ree']){//�ظ���������, �ظ�������ſ��콱
				$where_pdateline_7ree="AND t.dateline>{$btime_7ree}";
			}else{
				$where_pdateline_7ree='';
			}
			
			
			$db_query_7ree = "";
			if($type_7ree == 1){  //type=1 ���ⱻ�ظ���
				$db_query_7ree = "SELECT COUNT(distinct CONCAT_WS('-',p.tid,p.authorid)) FROM ".DB::table('forum_post')." p 
									LEFT JOIN ".DB::table('forum_thread')." t ON t.tid = p.tid
									WHERE t.authorid={$uid_7ree}
									{$where_tdateline_7ree}
									AND p.dateline>{$btime_7ree}
									AND p.authorid<>{$uid_7ree}
									{$banfid_7ree}";

			}elseif($type_7ree == 2){ //type=2 �ظ�����������
				if($vars_7ree['replyone_7ree']){
					$db_query_7ree = "SELECT COUNT(p.pid) FROM ".DB::table('forum_post')." p 
										LEFT JOIN ".DB::table('forum_thread')." t ON t.tid = p.tid
										WHERE  t.authorid<>{$uid_7ree}
										{$where_pdateline_7ree}
										AND p.dateline>{$btime_7ree}
										AND p.authorid={$uid_7ree}
										{$banfid_7ree}
										GROUP BY p.tid";
				}else{
					$db_query_7ree = "SELECT COUNT(distinct p.tid) FROM ".DB::table('forum_post')." p 
										LEFT JOIN ".DB::table('forum_thread')." t ON t.tid = p.tid
										WHERE t.authorid<>{$uid_7ree}
										{$where_pdateline_7ree}
										AND p.dateline>{$btime_7ree}
										AND p.authorid={$uid_7ree}
										{$banfid_7ree}";
				}
			}
			
			$return_7ree = DB::result_first($db_query_7ree);
			$return_7ree = $return_7ree ? $return_7ree : 0;
			return $return_7ree;
		}
//From: dis'.'m.tao'.'bao.com
?>