<?php

/*
	ID: toplist_7ree 
	(C)2006-2020 [dism.taobao.com]
	Update: 2021/5/7 11:14
	This is NOT a freeware, use is subject to license terms
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/developer-7.html
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/plugins/replyreward_7ree.replyreward_7ree_faq.html';</script>";


?>