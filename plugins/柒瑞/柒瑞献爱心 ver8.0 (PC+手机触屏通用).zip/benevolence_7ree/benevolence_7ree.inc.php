<?php

/*
 * [dism.taobao.com] (C)2006-2021 7ree.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@7ree.com
 * QQ: 860618629
 * WeiXin: www_7ree_com
 * Update: 2021-06-18 17:31:22
*/

if(!defined('IN_DISCUZ'))  Exit('Access Deined');

$vars_7ree = $_G['cache']['plugin']['benevolence_7ree'];

$agreement_7ree = $vars_7ree['agreement_7ree'];
$time_7ree = $vars_7ree['time_7ree'];
$money_7ree =$vars_7ree['money_7ree'];
$title_7ree = $_G['setting']['extcredits'][$money_7ree]['title'];
$money_7ree = "extcredits".$money_7ree;
$showmessage_7ree = $vars_7ree['showmessage_7ree'];
$pray_7ree = $vars_7ree['pray_7ree'];
$img_7ree = $vars_7ree['img_7ree'];
$url_7ree = $vars_7ree['url_7ree'];
$ranknum_7ree = $vars_7ree['ranknum_7ree'];
$paynum_7ree = $vars_7ree['paynum_7ree'];
$payarray_7ree = explode(',',$paynum_7ree);

$navtitle = lang('plugin/benevolence_7ree', 'php_lang_navtitle_7ree');


$ac = intval($_GET['ac']);



if (!$agreement_7ree) showmessage('benevolence_7ree:php_lang_agree_7ree');

$querylist = DB::query("select b.uid_7ree,
            SUM(b.num_7ree) as sum_num_7ree, m.username
			from ".DB::table('benevolence_7ree')." b
			LEFT JOIN ".DB::table('common_member')." m ON m.uid=b.uid_7ree
			group by b.uid_7ree
			order by sum_num_7ree desc LIMIT {$ranknum_7ree}");
while($toplovetable = DB::fetch($querylist)) {
        $toplovelist[] = $toplovetable;
}
if($_G['uid']) {
	$fduser = DB::result_first("SELECT {$money_7ree} FROM ".DB::table('common_member_count')." WHERE uid='{$_G[uid]}' LIMIT 1");
}
	$querynum = DB::result_first("SELECT Count(id_7ree) FROM ".DB::table('benevolence_7ree'));
	$praynum = DB::result_first("SELECT SUM(num_7ree) FROM ".DB::table('benevolence_7ree'));


if (!$ac){
	
}elseif($ac=="1"){
// �ж��Ƿ��Ѿ���½
if(!$_G['uid']) showmessage('not_loggedin', NULL, array(), array('login' => 1));
if(!submitcheck('submit_7ree')) showmessage("Access Deined");


if($vars_7ree['bangid_7ree']){
				$bangid_7ree = $vars_7ree['bangid_7ree'] ? unserialize($vars_7ree['bangid_7ree']) : array();
				if(in_array($_G['groupid'],$bangid_7ree)){
						showmessage('benevolence_7ree:php_lang_msg_bangid_7ree',"plugin.php?id=benevolence_7ree:benevolence_7ree");
				}
}



// �ж��Ƿ�����Ϊ��
$lovetext = dhtmlspecialchars(trim($_GET['lovetext']));
if (!$lovetext) showmessage('benevolence_7ree:php_lang_inputtip_7ree');
//�жϷ���ʱ����
       if ($time_7ree > 0 && $_G['adminid'] != 1) {
			$logtime_7ree = DB::result_first("SELECT logtime_7ree FROM ".DB::table('benevolence_7ree')." WHERE uid_7ree='{$_G[uid]}' ORDER BY logtime_7ree DESC LIMIT 1");
      		if (($_G[timestamp] - $logtime_7ree < $time_7ree) && $logtime_7ree) showmessage('benevolence_7ree:php_lang_slowtip_7ree') ;

	   }


//�жϻ����Ƿ��㹻����
$num_7ree = intval($_GET['num_7ree']);

	if($fduser < $num_7ree) {
       showmessage('benevolence_7ree:php_lang_credittip_7ree');
	}
	$query = DB::query("UPDATE ".DB::table('common_member_count')." SET {$money_7ree} = {$money_7ree} - {$num_7ree} WHERE  uid = '{$_G[uid]}'");



//�ύ��ϸ
DB::query("INSERT INTO ".DB::table('benevolence_7ree')." 
	(logtime_7ree, uid_7ree, num_7ree, detail_7ree) VALUES (
	'{$_G[timestamp]}','{$_G[uid]}','{$num_7ree}','{$lovetext}')");
	showmessage('benevolence_7ree:php_lang_successtip_7ree',"plugin.php?id=benevolence_7ree:benevolence_7ree");
	
}elseif($ac=="2"){	
    if ($_G['adminid'] != 1 || $_GET['formhash'] <> FORMHASH) showmessage("Access Deined @7ree.com");    
    $_GET['id_7ree'] = intval($_GET['id_7ree']); 
	$query = DB::query("DELETE FROM ".DB::table('benevolence_7ree')."  WHERE `id_7ree`=$_GET[id_7ree]");
	showmessage('benevolence_7ree:php_lang_deltip_7ree',"plugin.php?id=benevolence_7ree:benevolence_7ree"); 

}elseif($ac=="3"){
if ($_G['adminid'] != 1) showmessage("Access Deined @7ree.com");

}elseif($ac=="4"){
    if ($_G['adminid'] != 1 || $_GET['formhash'] <> FORMHASH) showmessage("Access Deined @7ree.com");
 	$query = DB::query("TRUNCATE TABLE ".DB::table('benevolence_7ree')."");   	
 	showmessage('benevolence_7ree:php_lang_emptytip_7ree','plugin.php?id=benevolence_7ree:benevolence_7ree');
 	

}elseif($ac=="5"){
 	
$page = max(1, intval($_GET['page']));
$startpage = ($page - 1) * 10;  


$query = DB::query("SELECT b.*, m.username FROM ".DB::table('benevolence_7ree')." b LEFT JOIN  ".DB::table('common_member')." m ON m.uid = b.uid_7ree ORDER BY id_7ree DESC LIMIT {$startpage}, 10");
while($benevolence_7ree_table = DB::fetch($query)) {
	    $benevolence_7ree_table['logtime_7ree'] = gmdate("Y-m-d H:i:m", $benevolence_7ree_table['logtime_7ree'] + $_G['setting']['timeoffset'] * 3600);
        $benevolence_7ree_list[] = $benevolence_7ree_table;
}

		$multipage = multi($querynum, 10, $page, "plugin.php?id=benevolence_7ree:benevolence_7ree&ac=5");
		$mymultipage_7ree = $multipage; 
}


include template('benevolence_7ree:benevolence_7ree');


?>