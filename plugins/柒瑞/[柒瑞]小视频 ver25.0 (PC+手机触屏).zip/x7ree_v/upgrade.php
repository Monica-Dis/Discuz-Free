<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


function testfield_7ree($dbfield_7ree, $dbtable_7ree) {
	$field_7ree=array();
	$query=DB::query('SHOW COLUMNS FROM '.DB::table($dbtable_7ree));
	while ($row = DB::fetch($query)) {
		$field_7ree[]=$row['Field'];
	}
	return in_array($dbfield_7ree,$field_7ree) ? TRUE:FALSE;
}


$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_main` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `name_7ree` varchar(255) NOT NULL,
  `url_7ree` varchar(500) NOT NULL,
  `pic_7ree` varchar(255) NOT NULL,
  `fenlei_7ree` varchar(100) NOT NULL,
  `detail_7ree` text NOT NULL,
  `status_7ree` tinyint(1) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `view_7ree` mediumint(8) NOT NULL,
  `zan_7ree` mediumint(8) NOT NULL,
  `fav_7ree` mediumint(8) NOT NULL,
  `discuss_7ree` mediumint(8) NOT NULL,
  `cost_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_discuss` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `vid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `zan_7ree` mediumint(8) NOT NULL,
  `message_7ree` text NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_buylog` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `vid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `cost_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_qiniu` (
  `id_7ree` int(8) NOT NULL AUTO_INCREMENT,
  `uid_7ree` int(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `file_7ree` varchar(100) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_zan` (
  `id_7ree` mediumint(8) NOT NULL,
  `uid_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;


EOF;

runquery($sql);


if(!testfield_7ree('view_7ree','x7ree_v_main')) {
	$sql="ALTER TABLE  `pre_x7ree_v_main` ADD  `view_7ree` MEDIUMINT( 8 ) NOT NULL ,
ADD  `zan_7ree` MEDIUMINT( 8 ) NOT NULL ,
ADD  `fav_7ree` MEDIUMINT( 8 ) NOT NULL";
	runquery($sql);
}

if(!testfield_7ree('discuss_7ree','x7ree_v_main')) {
	$sql="ALTER TABLE  `pre_x7ree_v_main` ADD  `discuss_7ree` MEDIUMINT( 8 ) NOT NULL ,
ADD  `cost_7ree` MEDIUMINT( 8 ) NOT NULL";
	runquery($sql);
}





$finish = TRUE;




?>