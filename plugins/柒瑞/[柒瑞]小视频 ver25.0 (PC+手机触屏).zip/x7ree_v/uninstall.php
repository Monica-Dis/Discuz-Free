<?php






if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF

DROP TABLE IF EXISTS `pre_x7ree_v_main`;
DROP TABLE IF EXISTS `pre_x7ree_v_discuss`;
DROP TABLE IF EXISTS `pre_x7ree_v_buylog`;
DROP TABLE IF EXISTS `pre_x7ree_v_qiniu`;
EOF;


runquery($sql);

$

$finish = TRUE;



?>