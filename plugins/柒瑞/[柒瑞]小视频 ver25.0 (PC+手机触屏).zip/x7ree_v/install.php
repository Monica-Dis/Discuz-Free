<?php






if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}




$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_main` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `name_7ree` varchar(255) NOT NULL,
  `url_7ree` varchar(500) NOT NULL,
  `pic_7ree` varchar(255) NOT NULL,
  `fenlei_7ree` varchar(100) NOT NULL,
  `detail_7ree` text NOT NULL,
  `status_7ree` tinyint(1) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `view_7ree` mediumint(8) NOT NULL,
  `zan_7ree` mediumint(8) NOT NULL,
  `fav_7ree` mediumint(8) NOT NULL,
  `discuss_7ree` mediumint(8) NOT NULL,
  `cost_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_discuss` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `vid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `zan_7ree` mediumint(8) NOT NULL,
  `message_7ree` text NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_buylog` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(50) NOT NULL,
  `vid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `cost_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_qiniu` (
  `id_7ree` int(8) NOT NULL AUTO_INCREMENT,
  `uid_7ree` int(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `file_7ree` varchar(100) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_x7ree_v_zan` (
  `id_7ree` mediumint(8) NOT NULL,
  `uid_7ree` mediumint(8) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;


EOF;


runquery($sql);




$finish = TRUE;




?>