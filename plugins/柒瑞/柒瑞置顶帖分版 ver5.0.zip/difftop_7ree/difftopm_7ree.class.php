<?php

/*
	(C)2007-2021 [DisM.Taobao.Com]
	Update: 2021/2/3 9:59
	This is NOT a freeware, use is subject to license terms
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/?developer-7.html
*/	
	
 if(!defined('IN_DISCUZ')) exit('Access Denied');

class mobileplugin_difftop_7ree{


		function forumdisplay_thread_mobile_output() {

				global $_G,$separatepos;
				$vars_7ree = $_G['cache']['plugin']['difftop_7ree'];

				$opgroup_7ree = $vars_7ree['opgroup_7ree'] ? unserialize($vars_7ree['opgroup_7ree']) : array();
 				$ungroup_7ree = $vars_7ree['ungroup_7ree'] ? unserialize($vars_7ree['ungroup_7ree']) : array();
				
				$op_gid_7ree = in_array($_G['groupid'],$opgroup_7ree) ? 1 : 0 ;
				$un_gid_7ree = in_array($_G['groupid'],$ungroup_7ree) ? 1 : 0 ;

				$return = array();

				if(!$vars_7ree['agreement_7ree'] || intval($_GET['page'])>1) return;

				$separate = FALSE;
				$query = DB::query("SELECT tid_7ree FROM ".DB::table('difftop_7ree')." WHERE fid_7ree = '{$_G[fid]}'");
       			while($table_7ree = DB::fetch($query)){
		   			$difflist_7ree[] = $table_7ree['tid_7ree'];
				} 
				foreach($_G['forum_threadlist'] as $key=>$topthread_7ree) {
					
					
					
					
	            		if($topthread_7ree['displayorder'] > 0) {
								if(in_array($topthread_7ree['tid'],$difflist_7ree) && !$un_gid_7ree)  {
									unset($_G['forum_threadlist'][$key]);
									$separatepos = MAX(0, $separatepos - 1);
								}else{
									$separate = TRUE;
								}
								if($op_gid_7ree && $_G['uid'] && $vars_7ree['isoption_7ree']){
									$opstring_7ree="<a style='display:inline-block;background-color:{$vars_7ree[bgcolor_7ree]};padding:3px;margin:0px 5px;border-radius:5px; cursor:pointer;-moz-box-shadow:1px 1px 2px #8F8F8F; -webkit-box-shadow:1px 1px 2px #8F8F8F; box-shadow:1px 1px 2px #8F8F8F;
' href='plugin.php?id=difftop_7ree&tid_7ree={$topthread_7ree[tid]}&thisfid={$_G[fid]}'>".lang('plugin/difftop_7ree', 'php_lang_navtitle_7ree')."</a>";
									$_G['forum_threadlist'][$key]['subject']=$opstring_7ree.$_G['forum_threadlist'][$key]['subject'];
								}


	                		}
				}

				$separatepos = $separate ? $separatepos : 0;

				return $return;
		

		}


}

class mobileplugin_difftop_7ree_forum extends mobileplugin_difftop_7ree{
}
//From: Dism_taobao-com
?>