<?php

/*
ID: difftop_7ree
[DisM.Taobao.Com] (C)2007-2016 dism.taobao.com.
This is NOT a freeware, use is subject to license terms
Update: 2016/9/17 9:03
Agreement: http://DisM.Taobao.Com/agreement.html
More Plugins: http://DisM.Taobao.Com/?thread-7407-1-1.html
*/




if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF
DROP TABLE IF EXISTS `pre_difftop_7ree`;

EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/




?>