<?php

/*
ID: difftop_7ree
[DisM.Taobao.Com] (C)2007-2020 dism.taobao.com.
This is NOT a freeware, use is subject to license terms
Update: 2020/8/16 21:41
Agreement: http://DisM.Taobao.Com/agreement.html
More Plugins: http://DisM.Taobao.Com/?thread-7407-1-1.html
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	loadcache('plugin');
	$vars_7ree = $_G['cache']['plugin']['difftop_7ree'];
	if(!$vars_7ree['agreement_7ree']) cpmsg('difftop_7ree:php_lang_agree_7ree', "",'error');

	$id_7ree = intval($_GET['id_7ree']);
	$tid_7ree = intval($_GET['tid_7ree']);


	if($_GET[formhash] == FORMHASH){

		if($id_7ree){
			DB::query("DELETE FROM ".DB::table('difftop_7ree')." WHERE id_7ree= '$id_7ree'");
			cpmsg('difftop_7ree:php_lang_clearmsg_7ree',"action=plugins&operation=config&do=$pluginid&identifier=difftop_7ree&pmod=difftop_list_7ree$extra","succeed");
		}
		if($tid_7ree){
			DB::query("DELETE FROM ".DB::table('difftop_7ree')." WHERE tid_7ree= '$tid_7ree'");
			cpmsg('difftop_7ree:php_lang_clearmsg2_7ree',"action=plugins&operation=config&do=$pluginid&identifier=difftop_7ree&pmod=difftop_list_7ree$extra","succeed");
		}
	
	}else{
	$pagemax_7ree = $vars_7ree['pagemax_7ree'];
	$page = max(1, intval($_G['gp_page']));
	$startpage = ($page - 1) * $pagemax_7ree;

	$querynum = DB::result_first("SELECT Count(*) FROM ".DB::table('difftop_7ree'));
	
	$query = DB::query("SELECT d.*, t.*, f.name FROM ".DB::table('difftop_7ree')." d
						LEFT JOIN ".DB::table('forum_thread')." t ON t.tid = d.tid_7ree
						LEFT JOIN ".DB::table('forum_forum')." f ON f.fid = d.fid_7ree
						ORDER BY d.id_7ree DESC LIMIT {$startpage}, {$pagemax_7ree}");
       			while($table_7ree = DB::fetch($query)){
		   			$threadlist_7ree[] = $table_7ree;
				} 

	$multipage = multi($querynum, $pagemax_7ree, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=difftop_7ree&pmod=difftop_list_7ree$extra");

	include template('difftop_7ree:difftop_list_7ree');

	}


//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>