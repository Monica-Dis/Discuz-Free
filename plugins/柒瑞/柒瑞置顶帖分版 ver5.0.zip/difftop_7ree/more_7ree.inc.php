<?php

/*
	(C)2007-2016 [DisM.Taobao.Com]
	This is NOT a freeware, use is subject to license terms
	Ӧ�ø���֧�֣�https://dism.taobao.com
	���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/?@7.developer';</script>";


?>