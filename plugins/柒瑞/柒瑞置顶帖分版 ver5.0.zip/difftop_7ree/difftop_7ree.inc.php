<?php

/*
	[DisM.Taobao.Com] (C)2007-2021 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2021/2/3 11:09
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/?developer-7.html
*/



if(!defined('IN_DISCUZ') ) {
	exit('Access Denied');
}
		$vars_7ree = $_G['cache']['plugin']['difftop_7ree'];
		if(!$vars_7ree['agreement_7ree']) showmessage('difftop_7ree:php_lang_agree_7ree');

		if(!$_G['uid']) showmessage('not_loggedin', NULL, array(), array('login' => 1));
		
 		$group_7ree = $vars_7ree['opgroup_7ree'] ? unserialize($vars_7ree['opgroup_7ree']) : array();
		$op_gid_7ree = in_array($_G['groupid'],$group_7ree) ? 1 : 0 ;

		if(!$op_gid_7ree) showmessage('Access Deined @ difftop_7ree');


		$tid_7ree = intval($_GET['tid_7ree']);
		if(!$tid_7ree) showmessage('error @ difftop_7ree');

if(submitcheck('submit_7ree')){

			DB::query("DELETE FROM ".DB::table('difftop_7ree')." WHERE tid_7ree = '{$tid_7ree}'");


		if(is_array($_GET['fid_7ree'])){
		
				foreach ($_GET['fid_7ree'] as $fid_value){
					$fid_value = intval($fid_value);
					if($fid_value) $insert_value[] = "'{$tid_7ree}','{$fid_value}'";
				}
		}

		if(is_array($insert_value)){

			$insert_7ree = "(".implode($insert_value,"),(").")";
			DB::query("INSERT INTO ".DB::table('difftop_7ree')." (tid_7ree, fid_7ree) VALUES {$insert_7ree}");
			showmessage('difftop_7ree:php_lang_opokmsg_7ree',"forum.php?mod=forumdisplay&fid={$_GET[thisfid]}");

		}else{

			showmessage('difftop_7ree:php_lang_clearmsg_7ree',"forum.php?mod=forumdisplay&fid={$_GET[thisfid]}");

		}

}else{
	
		$query = DB::query("SELECT fid_7ree FROM ".DB::table('difftop_7ree')." WHERE tid_7ree = '{$_GET[tid_7ree]}'");
       	while($table_7ree = DB::fetch($query)){
		   	$difflist_7ree[] = $table_7ree[fid_7ree];
		} 	
			
		$unlimit_7ree = !count($difflist_7ree) ? 1 : 0;

	require_once libfile('function/forumlist');
	$forumlist = forumselect(FALSE, 0, $difflist_7ree);



	include template('difftop_7ree:difftop_op_7ree');
		
}

	
?>