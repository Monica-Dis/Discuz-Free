<?php

/*
	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
	This is NOT a freeware, use is subject to license terms
	Ӧ�ø���֧�֣�https://dism.taobao.com
	���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html';</script>";


?>