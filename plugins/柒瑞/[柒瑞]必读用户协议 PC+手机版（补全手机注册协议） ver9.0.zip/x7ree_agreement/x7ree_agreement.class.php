<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-07 11:52:36
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_x7ree_agreement_forum {
		function forumdisplay_top(){
				global $_G;
				$return_7ree ='';
				loadcache('plugin');
				$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];
				if(!$vars_7ree['agreement_7ree']){
					return $return_7ree;
				}

				if($vars_7ree['login_7ree']){
					if(!$_G['uid']){
						showmessage('not_loggedin', NULL, array(), array('login' => 1));
					}
				}

				
				$gid_7ree = $vars_7ree['gid_7ree'] ? unserialize($vars_7ree['gid_7ree']) : array();

				if(in_array($_G['groupid'],$gid_7ree)) return $return_7ree;


				if($_G['fid']){

					$forums_7ree = DB::fetch_first("SELECT * FROM ".DB::table('x7ree_agreement')." WHERE forums_7ree LIKE '%-{$_G[fid]}-%'");

					if($forums_7ree['guest_7ree']){
						if(!$_G['uid']){
							showmessage('not_loggedin', NULL, array(), array('login' => 1));
						}
					}

					if($forums_7ree['forums_7ree']){
						$cookie_7ree = 'agreement_7ree_'.$_G['fid'];
						if(!getcookie($cookie_7ree)){
							dheader('Location: plugin.php?id=x7ree_agreement:x7ree_read&fid='.$_G['fid']);
						}
					}
				}

		}
		function viewthread_top(){
				global $_G;
				if($_G['fid']){
						$this->forumdisplay_top();
				}
		}
	
}

class mobileplugin_x7ree_agreement_forum {
	
		function forumdisplay_top_mobile(){
				global $_G;
				$return_7ree ='';
				loadcache('plugin');
				$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];
				
				if(!$vars_7ree['agreement_7ree']){
					return $return_7ree;
				}
				

				if($vars_7ree['login_7ree']){
					if(!$_G['uid']){
						showmessage('not_loggedin', NULL, array(), array('login' => 1));
					}
				}
				
				$gid_7ree = $vars_7ree['gid_7ree'] ? unserialize($vars_7ree['gid_7ree']) : array();

				if(in_array($_G['groupid'],$gid_7ree)) return $return_7ree;
				
				if($_G['fid'] && $vars_7ree['agreement_7ree']){

					$forums_7ree = DB::fetch_first("SELECT * FROM ".DB::table('x7ree_agreement')." WHERE forums_7ree LIKE '%-{$_G[fid]}-%'");

					if($forums_7ree['guest_7ree']){
						if(!$_G['uid']){
							showmessage('not_loggedin', NULL, array(), array('login' => 1));
						}
					}

					if($forums_7ree['forums_7ree']){
						$cookie_7ree = 'agreement_7ree_'.$_G['fid'];
						if(!getcookie($cookie_7ree)){
							dheader('Location: plugin.php?id=x7ree_agreement:x7ree_read&fid='.$_G['fid']);
						}
					}
					
				}
		}
		
		
		function viewthread_top_mobile(){
				global $_G;
				if($_G['fid']){
						$this->forumdisplay_top_mobile();
				}
		}
}


class mobileplugin_x7ree_agreement {
		function global_footer_mobile(){
				global $_G,$bbrulehash;
				$return ='';
				
				if($_GET['mod']<>'register'){
					return $return;
				}
				
				loadcache('plugin');
				$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];	
				
				if(!$vars_7ree['agreement_7ree'] || !$vars_7ree['mobreg_rule_7ree']){
					return $return;
				}

				//$bbrulehash = $bbrules ? substr(md5(FORMHASH), 0, 8) : '';
				
				$rulemessage_7ree = lang('member/template','rulemessage');
				$agree_7ree =  lang('member/template','agree');
				$disagree_7ree =  lang('member/template','disagree');

				$bbrulestxt = nl2br($_G['setting']['bbrulestxt']);

				include template('x7ree_agreement:reg_rule_7ree');
				
				return $return;
		}
}

class mobileplugin_x7ree_agreement_member extends mobileplugin_x7ree_agreement{
}
//From: dis'.'m.tao'.'bao.com
?>