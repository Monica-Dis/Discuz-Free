<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-06-22 11:45:02
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];

$agree_7ree = intval($_GET['agree_7ree']);
$fid = intval($_GET['fid']);

if(!$agree_7ree){
		if($fid){
				$language = lang('forum/misc');  
				$username_7ree = $_G['uid'] ? $_G['username'] : $language['guestuser'];

				$fname_7ree = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid='{$fid}'");
				$message_7ree = DB::fetch_first("SELECT * FROM ".DB::table('x7ree_agreement')." WHERE forums_7ree LIKE '%-{$fid}-%'");
				$message_7ree['title_7ree'] = $message_7ree['title_7ree'] ? $message_7ree['title_7ree'] : $vars_7ree['title_7ree'];
				$message_7ree['message_7ree'] = $message_7ree['message_7ree'] ? $message_7ree['message_7ree'] :  $vars_7ree['message_7ree'];
				require_once libfile('function/discuzcode');
				$message_7ree['title_7ree'] = discuzcode($message_7ree['title_7ree']);
				$message_7ree['message_7ree'] = discuzcode($message_7ree['message_7ree']);
				$message_7ree['message_7ree'] = str_replace("{username}",$username_7ree,$message_7ree['message_7ree']);
				$message_7ree['icon_7ree']=$vars_7ree['icon_7ree'];
				include template('x7ree_agreement:x7ree_agreement');
		}
}elseif($agree_7ree==1){//ͬ�⣬����
    	if(submitcheck('iagree_7ree')){
    			$cookie_7ree = 'agreement_7ree_'.$fid;
				dsetcookie($cookie_7ree,'-'.$fid.'-',$vars_7ree['cookielife_7ree']*3600);
				dheader('Location: forum.php?mod=forumdisplay&fid='.$fid);
		}else{
				showmessage('Error#7ree @ Access Denied.');
		}
}elseif($agree_7ree==2){//��ͬ�⣬����
		dheader('Location: index.php');
}else{
		showmessage('Error#7ree @ Undefined Operation.');
}





?>