<?php
/*
	ID: popad_7ree
	[dism.taobao.com] (C)2007-2016 dism.taobao.com.
	Update: 2016/1/26 19:23
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF


DROP TABLE IF EXISTS `pre_popad_7ree`;

EOF;

runquery($sql);

$finish = TRUE;

?>