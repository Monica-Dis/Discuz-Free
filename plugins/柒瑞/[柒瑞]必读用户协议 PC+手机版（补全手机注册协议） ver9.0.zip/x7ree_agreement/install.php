<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-07 11:29:36
*/	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF


CREATE TABLE IF NOT EXISTS `pre_x7ree_agreement` (
	`id_7ree` int(8) NOT NULL AUTO_INCREMENT,
	`title_7ree` varchar(255) NOT NULL,
	`message_7ree` text NOT NULL,
	`forums_7ree` text NOT NULL,
	`guest_7ree` tinyint(1) NOT NULL,
	PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM ;



EOF;

runquery($sql);

$finish = TRUE;