<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-07 11:34:44
*/	
	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied.');
}
	$pluginid_7ree = 'x7ree_agreement';

	loadcache('plugin');
	$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];
	if(!$vars_7ree[agreement_7ree]) cpmsg('x7ree_agreement:lang_agree_7ree', "",'error');
	
 	$op_7ree = intval($_GET['op_7ree']);
 	
	require_once libfile('function/forumlist');
	$forumselect = forumselect(FALSE, 0, $_G['forum']['recommend']);
	
	$id_7ree = intval($_GET['id_7ree']);
	$messagetip_7ree = cplang('tips_textarea');

 	
   	if($id_7ree){//�򿪱༭ҳ��	
			$thisx7ree_agreement = DB::fetch_first("SELECT * FROM ".DB::table('x7ree_agreement')." WHERE id_7ree='$id_7ree' ");
			$forums_array = explode('-',substr($thisx7ree_agreement['forums_7ree'], 1, strlen($thisx7ree_agreement['forums_7ree'])-1)); 
 	}else{//������ҳ��
 	
 	
 	
 	}
	
	
	require_once libfile('function/forumlist');
	$forumselect = forumselect(FALSE, 0, $forums_array);
	$adforumselect = '<select name="forumselect[]" size="10" multiple="multiple">'.$forumselect.'</select>';


	if(submitcheck('submit_7ree')){
			$title_7ree = daddslashes(dhtmlspecialchars(trim($_GET['title_7ree'])));
			$message_7ree = daddslashes(dhtmlspecialchars(trim($_GET['message_7ree'])));
			$forums_7ree = '-'.daddslashes(dhtmlspecialchars(implode('-',$_GET['forumselect']))).'-';
			$guest_7ree = intval($_GET['guest_7ree']);
			
			if(!COUNT($_GET['forumselect'])) cpmsg('x7ree_agreement:php_lang_adderror_7ree',"",'error');

			
			if($id_7ree){//�༭���λ�ύ
					DB::query("UPDATE ".DB::table('x7ree_agreement')." SET 
								title_7ree='$title_7ree', 
								message_7ree='$message_7ree', 
								forums_7ree='$forums_7ree',
								guest_7ree = $guest_7ree
								WHERE id_7ree='$id_7ree' LIMIT 1");
			}else{//�������λ�ύ
					DB::query("INSERT INTO ".DB::table('x7ree_agreement')." SET 
								title_7ree='$title_7ree', 
								message_7ree='$message_7ree', 
								forums_7ree='$forums_7ree', 
								guest_7ree = $guest_7ree
								");
			}
		
			cpmsg('x7ree_agreement:php_lang_addok_7ree',"action=plugins&operation=config&do={$pluginid}&identifier={$pluginid_7ree}&pmod=x7ree_op",'succeed');
	
	}
	
	
 	
 	if(!$op_7ree) include template('x7ree_agreement:x7ree_add');
?>