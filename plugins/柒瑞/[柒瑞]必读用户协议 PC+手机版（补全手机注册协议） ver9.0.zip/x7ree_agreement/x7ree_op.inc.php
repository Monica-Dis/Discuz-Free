<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/05/20 11:26
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/developer-7.html
*/	
	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied.');
}
	$pluginid_7ree = 'x7ree_agreement';
	$langdir_7ree = 'plugin/'.$pluginid_7ree;

	loadcache('plugin');
	$vars_7ree = $_G['cache']['plugin']['x7ree_agreement'];	
	if(!$vars_7ree['agreement_7ree']) cpmsg('x7ree_agreement:lang_agree_7ree', "",'error');
	
 	$op_7ree = intval($_GET['op_7ree']);
 	
	if($op_7ree==1){
		if($_GET['formhash']==FORMHASH){
			$id_7ree = intval($_GET['id_7ree']);
			if($id_7ree){
					DB::query("DELETE FROM ".DB::table('x7ree_agreement')." WHERE id_7ree='$id_7ree'");
					cpmsg('x7ree_agreement:php_lang_delok_7ree',"action=plugins&operation=config&do={$pluginid}&identifier={$pluginid_7ree}&pmod=x7ree_op",'succeed');
			}else{
					cpmsg("x7ree_agreement:php_lang_missid_7ree",'error');
			}

		}
	
	
	}else{
	
		$page = max(1, intval($_GET['page']));
		$startpage = ( $page - 1 ) * 20;
		$querynum = DB::result_first( "SELECT Count(*) FROM ".DB::table('x7ree_agreement') );
		$query = DB::query( "SELECT * FROM ".DB::table('x7ree_agreement')." ORDER BY id_7ree DESC LIMIT {$startpage},20" );
		while ($agree_table = DB::fetch($query)){
				$agreelist_7ree[]=$agree_table;
		}	
	    $multipage = multi($querynum, 20, $page, "{ADMINSCRIPT}?action=plugins&operation=config&do={$pluginid}&identifier={$pluginid_7ree}&pmod=x7ree_op$extra" );
	    
	}




 	if(!$op_7ree) include template('x7ree_agreement:x7ree_op');
?>