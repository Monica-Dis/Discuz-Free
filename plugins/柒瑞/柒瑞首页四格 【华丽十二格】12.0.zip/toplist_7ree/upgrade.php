<?php

/*
	ID: toplist_7ree 
	[DisM!] (C)2019-2020 DISM.Taobao.COM.
	This is NOT a freeware, use is subject to license terms
	update:2017/2/4 12:41
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function testfield_7ree($dbfield_7ree, $dbtable_7ree) {
	$field_7ree=array();
	$query=DB::query('SHOW COLUMNS FROM '.DB::table($dbtable_7ree));
	while ($row = mysql_fetch_array($query,MYSQL_ASSOC)) {
		$field_7ree[]=$row['Field'];
	}
	return in_array($dbfield_7ree,$field_7ree) ? TRUE:FALSE;
}



$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_toplist_push_7ree` (
  `id_7ree` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_7ree` mediumint(8) unsigned NOT NULL,
  `tid_7ree` mediumint(8) unsigned NOT NULL,
  `fid_7ree` mediumint(8) unsigned NOT NULL,
  `subject_7ree` char(80) NOT NULL,
  `fname_7ree` char(80) NOT NULL,
  `author_7ree` char(15) NOT NULL,
  `uid_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `highlight_7ree` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_7ree`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;


?>