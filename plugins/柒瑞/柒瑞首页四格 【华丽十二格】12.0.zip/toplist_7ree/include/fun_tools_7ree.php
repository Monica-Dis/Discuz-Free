<?php

/*
	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
	Update: 2019/2/1 21:28
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = 0;

		switch ($format_7ree){
		case 1://����
		  	$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		  	break;
		case 2://����
		  	$return_7ree = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("d",strtotime("last Monday") + $_G[setting][timeoffset] * 3600),date("Y",strtotime("last Monday") + $_G[setting][timeoffset] * 3600));
		  	break;
		case 3://����
  			$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G[timestamp] + $_G[setting][timeoffset] * 3600))/3);
			$return_7ree = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	break;
		case 5://�����
		  	$return_7ree = mktime(0,0,0,1,1,gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
 		 	break;
		default:
 		 	$return_7ree = mktime(0,0,0,gmdate("m",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("d",$_G[timestamp] + $_G[setting][timeoffset] * 3600),gmdate("Y",$_G[timestamp] + $_G[setting][timeoffset] * 3600));
		}

		return $return_7ree;

}


function getthumb_7ree($imgname_7ree){
	
	$thumb_name_array = array();
	$thumb_name_num = 0;
	$return_7ree = '';
	$thumb_name_array = explode('.',$imgname_7ree);
    $thumb_name = ".thumb.jpg";
	$return_7ree = is_readable($imgname_7ree.$thumb_name) ? $imgname_7ree.$thumb_name : $imgname_7ree;
	return $return_7ree;

}

function getforum_7ree(){
	$return_7ree = array();
	global $_G;
	if(!isset($_G['cache']['forums'])) {
		loadcache('forums');
    }
	if(!isset($_G['cache']['groupindex'])){
		loadcache('groupindex');
    } 
    $allfid_7ree = $_G['cache']['forums'] + $_G['cache']['groupindex']['randgroupdata'];
    foreach($allfid_7ree as $fid => $forum) {
		$return_7ree[$fid]=$forum['name'];
	}
 	return $return_7ree;
}

function imgexist_7ree($url){
	global $_G;
	$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
    $found = FALSE;
    if ($vars_7ree['avaexit_7ree']){
		$url = str_replace($_G['setting']['siteurl'],'./',$url);
		$found = file_exists($url);     
    }else{
		$found = TRUE;
    }
    return $found;
}     

/**/
function getgurl_7ree($ggid_7ree,$gtype_7ree){
	global $_G;
	$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
	$return_7ree = '';
	
	if($gtype_7ree==1){//ʮ����ͼƬ��Ŀ
				if($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newpic_url_7ree'];
				}elseif($ggid_7ree=='dig'){
						$return_7ree = $vars_7ree['digpic_url_7ree'];
				}elseif($ggid_7ree=='ads'){
						$return_7ree = $vars_7ree['adspic_url_7ree'];
				}else{
						$return_7ree = '';
				}
	}elseif($gtype_7ree==2){//ʮ����������Ŀ
				if($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newpost_url_7ree'];
				}elseif($ggid_7ree=='rep'){
						$return_7ree = $vars_7ree['newreply_url_7ree'];
				}elseif($ggid_7ree=='dig'){
						$return_7ree = $vars_7ree['digpost_url_7ree'];
				}elseif($ggid_7ree=='hot'){
						$return_7ree = $vars_7ree['hotpost_url_7ree'];
				}elseif($ggid_7ree=='diy1'){
						$return_7ree = $vars_7ree['diy1_url_7ree'];
				}elseif($ggid_7ree=='diy2'){
						$return_7ree = $vars_7ree['diy2_url_7ree'];
				}elseif($ggid_7ree=='tui'){
						$return_7ree = $vars_7ree['tuijian_url_7ree'];
				}else{
						$return_7ree = $vars_7ree[''];
				}
	}elseif($gtype_7ree==3){//ʮ�����Ա��Ŀ
				if($ggid_7ree=='acv'){
						$return_7ree = $vars_7ree['huoyue_url_7ree'];
				}elseif($ggid_7ree=='ext'){
						$return_7ree = $vars_7ree['jifen_url_7ree'];
				}elseif($ggid_7ree=='new'){
						$return_7ree = $vars_7ree['newbie_url_7ree'];
				}else{
						$return_7ree = '';
				}
	}elseif($gtype_7ree==4){//�ĸ�ģ��
				if($ggid_7ree=='xt'){
						$return_7ree = $vars_7ree['newpic_url_7ree'];
				}elseif($ggid_7ree=='jt'){
						$return_7ree = $vars_7ree['digpic_url_7ree'];
				}elseif($ggid_7ree=='gt'){
						$return_7ree = $vars_7ree['adspic_url_7ree'];
				}elseif($ggid_7ree=='xz'){
						$return_7ree = $vars_7ree['newpost_url_7ree'];
				}elseif($ggid_7ree=='xh'){
						$return_7ree = $vars_7ree['newreply_url_7ree'];
				}elseif($ggid_7ree=='jz'){
						$return_7ree = $vars_7ree['digpost_url_7ree'];
				}elseif($ggid_7ree=='rz'){
						$return_7ree = $vars_7ree['hotpost_url_7ree'];
				}elseif($ggid_7ree=='d1'){
						$return_7ree = $vars_7ree['diy1_url_7ree'];
				}elseif($ggid_7ree=='d2'){
						$return_7ree = $vars_7ree['diy2_url_7ree'];
				}elseif($ggid_7ree=='tj'){
						$return_7ree = $vars_7ree['tuijian_url_7ree'];
				}elseif($ggid_7ree=='hy'){
						$return_7ree = $vars_7ree['huoyue_url_7ree'];
				}elseif($ggid_7ree=='jf'){
						$return_7ree = $vars_7ree['jifen_url_7ree'];
				}elseif($ggid_7ree=='xm'){
						$return_7ree = $vars_7ree['newbie_url_7ree'];
				}else{
						$return_7ree = '';
				}
	
	}
	$return_7ree = trim($return_7ree) ? trim($return_7ree) : "javascript:void(0);";
	

 	return $return_7ree;
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>