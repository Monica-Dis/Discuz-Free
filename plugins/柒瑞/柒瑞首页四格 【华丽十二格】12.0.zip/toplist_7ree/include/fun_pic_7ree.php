<?php

/*
	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
	Update: 2019/2/1 21:22
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
///////////////////////////////�õ�ͼ///////////////
//�õ�ͼ��ȡ
//---����---start
$shownums	= min(intval($vars_7ree[picnum_7ree]) ? intval($vars_7ree[picnum_7ree]) : 5 , 20);
$searchnums	= $shownums;//��������.
$pic_cachename	= 'showpic_7ree';//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

//---����---end
@include($cahcedir_7ree.$pic_cachename.'.php');

if($_G['uid'] && (!$cachetime_7ree || $_G['timestamp'] - $cachetime_7ree > $cachecycle_7ree * 60)) {

	$datapic = array();
	
	$cacheArray .= "\$cachetime_7ree=".$_G['timestamp'].";\n";

if($vars_7ree[newpic_title_7ree]){ //�Ƿ�������ͼƬ��Ŀ

		$pic_cacheprocess_7ree='pic_cache_7ree_refresh';
		if(!discuz_process::islocked($pic_cacheprocess_7ree, 600)) {
	
			$query = DB::query("SELECT a.attachment,t.tid, t.fid, t.subject FROM ".DB::table('forum_threadimage')." a, ".DB::table('forum_thread')." t  WHERE t.tid=a.tid AND t.isgroup=0 AND t.displayorder>=0 AND t.dateline<{$_G[timestamp]} $not_fid_7ree GROUP BY a.tid ORDER BY a.tid DESC LIMIT $searchnums");
		 				while($pic = DB::fetch($query)) {
							$pics['picpics'] = $_G['setting']['attachurl'].'forum/'.$pic['attachment'];
							$pics['attachment'] =$pic['attachment'];
							$pics['piclinks'] = 'forum.php?mod=viewthread%26tid='.$pic['tid'];
							$pics['pictexts'] = str_replace('\'', ' ',$pic['subject']);
							$pics['pictexts'] = cutstr($pics['pictexts'],$vars_7ree['piccutstr_7ree'],'');
							$pics['tid'] = $pic['tid'];
							$datapic[] = $pics;
						}
						$cacheArray .= "\$pic_7ree=".arrayeval($datapic).";\n";
			DB::free_result($query);
		}

			if($vars_7ree[digpic_title_7ree]){ //�Ƿ����þ���ͼƬ��Ŀ
				$query = DB::query("SELECT a.attachment,t.tid, t.fid, t.subject FROM ".DB::table('forum_threadimage')." a, ".DB::table('forum_thread')." t WHERE t.tid=a.tid AND t.digest>0 AND t.isgroup=0 AND t.displayorder>=0 AND t.dateline<{$_G[timestamp]} $not_fid_7ree GROUP BY a.tid ORDER BY a.tid DESC LIMIT $searchnums");
							 

							while($pic = DB::fetch($query)) {
								$pics['picpics'] = $_G['setting']['attachurl'].'forum/'.$pic['attachment'];
								$pics['attachment'] = $pic['attachment'];
								$pics['piclinks'] = 'forum.php?mod=viewthread%26tid='.$pic['tid'];
								$pics['pictexts'] = str_replace('\'', ' ',$pic['subject']);
								$pics['pictexts'] = cutstr($pics['pictexts'],$vars_7ree['piccutstr_7ree'],'');
								$pics['tid'] = $pic['tid'];
								$digdatapic[] = $pics;
							}
							$cacheArray .= "\$digpic_7ree=".arrayeval($digdatapic).";\n";
				DB::free_result($query);
			}


			writetocache($pic_cachename, $cacheArray);
			discuz_process::unlock($pic_cacheprocess_7ree);
		}

	@include(DISCUZ_ROOT.$cahcedir_7ree.$pic_cachename.'.php');

}


if(is_array($pic_7ree) && PHP_VERSION > 4.3 && $vars_7ree['picsorder_7ree']) shuffle($pic_7ree);
if(is_array($digpic_7ree) && PHP_VERSION > 4.3 && $vars_7ree['picsorder_7ree']) shuffle($digpic_7ree);

$i = 0;
$j = 0;
while ($j < $shownums && isset($pic_7ree[$i])) {
	if(is_readable($pic_7ree[$i]['picpics'])) {
		if($vars_7ree['thumbimg_7ree']) $pic_7ree[$i]['picpics'] = getthumb_7ree($pic_7ree[$i]['picpics']);
		$showpicpics .= $comma.$pic_7ree[$i]['picpics'];
		$showpiclinks .= $comma.$pic_7ree[$i]['piclinks'];
		$showpictexts .= $comma.$pic_7ree[$i]['pictexts'];
		$comma = '|';
		$j++;
	}elseif($_G['setting']['ftp']['on']){
		if($vars_7ree['thumbimg_7ree']) $pic_7ree[$i]['attachment'] = getthumb_7ree($pic_7ree[$i]['attachment']);
		$pic_7ree[$i]['picpics'] = $_G['setting']['ftp']['attachurl']."forum/".$pic_7ree[$i]['attachment'];
		$showpicpics .= $comma.$_G['setting']['ftp']['attachurl']."forum/".$pic_7ree[$i]['attachment'];
		$showpiclinks .= $comma.$pic_7ree[$i]['piclinks'];
		$showpictexts .= $comma.$pic_7ree[$i]['pictexts'];
		$j++;
	}
		$comma = '|';
		$i++;

	}
	
	
$i = 0;
$j = 0;
$comma = "";
while ($j < $shownums && isset($digpic_7ree[$i])) {
	if(is_readable($digpic_7ree[$i]['picpics'])) {
		if($vars_7ree['thumbimg_7ree']) $digpic_7ree[$i]['picpics'] = getthumb_7ree($digpic_7ree[$i]['picpics']);
		$showdigpics .= $comma.$digpic_7ree[$i]['picpics'];
		$showdiglinks .= $comma.$digpic_7ree[$i]['piclinks'];
		$showdigtexts .= $comma.$digpic_7ree[$i]['pictexts'];
		$comma = '|';
		$j++;
	}elseif($_G['setting']['ftp']['on']){
		if($vars_7ree['thumbimg_7ree']) $digpic_7ree[$i]['attachment'] = getthumb_7ree($digpic_7ree[$i]['attachment']);
	  	$digpic_7ree[$i]['picpics'] = $_G['setting']['ftp']['attachurl']."forum/".$digpic_7ree[$i]['attachment'];

	  	$showdigpics .= $comma.$_G['setting']['ftp']['attachurl']."forum/".$digpic_7ree[$i]['attachment'];
	    $showdiglinks .= $comma.$digpic_7ree[$i]['piclinks'];
	    $showdigtexts .= $comma.$digpic_7ree[$i]['pictexts'];
		$j++;
	}
	    $comma = '|';
	    $i++;

}

//From: dis'.'m.tao'.'bao.com
?>