<?php

/*
	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
	Update: 2019/2/1 22:05
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$cachename_ranklist	= "ranklist_7ree";//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_ranklist.'.php';

if($_G['uid'] && (!$cachetime3_7ree || $_G['timestamp'] - $cachetime3_7ree > $cachecycle3_7ree * 60)) {

		$ranklist_cacheprocess_7ree='ranklist_cache_7ree_refresh';
		if(!discuz_process::islocked($ranklist_cacheprocess_7ree, 600)) {

			$curdata = "\$cachetime3_7ree=".$_G['timestamp'].";\n\n";

				
			//��Ա��Ծ��
			$ranktime_7ree = gettime_7ree($membercycle_7ree);

			if($vars_7ree[acvrank_title_7ree]){ //�Ƿ����û�Ծ����Ŀ

			$query = DB::query("SELECT author, authorid, COUNT(*) AS postnum_7ree FROM ".DB::table('forum_post')." WHERE dateline > {$ranktime_7ree} AND authorid>0 GROUP BY authorid ORDER BY postnum_7ree DESC LIMIT $newbienum_7ree");
					while($postmember_7ree = DB::fetch($query)) {
					   		if($vars_7ree['onoffavatar_7ree']){
								$postmember_7ree[avatar_7ree] = avatar($postmember_7ree[authorid], small, TRUE, FALSE, TRUE);
					 	     	if(imgexist_7ree($postmember_7ree[avatar_7ree])){		      	
									$postmember_7ree[avatar_7ree] = $postmember_7ree[avatar_7ree];
								}else{
									$postmember_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';;
								}
							}
							$post_memberlist_7ree[] = $postmember_7ree;
					}
					
					$curdata .= "\$postmember_list_7ree = ".arrayeval($post_memberlist_7ree).";\n\n";
					DB::free_result($query);
			}   

			//�»�Ա

			if($vars_7ree[newrank_title_7ree]){ //�Ƿ������»�Ա��Ŀ
					$query = DB::query("SELECT username, uid, regdate FROM ".DB::table('common_member')." WHERE uid>0  ORDER BY uid DESC LIMIT $newbienum_7ree");
					while($member_7ree = DB::fetch($query)) {
					   		$member_7ree['regdate'] = gmdate("m-d H:i", $member_7ree[regdate] + ($_G[setting][timeoffset] * 3600));
					   		if($vars_7ree['onoffavatar_7ree']){
					   		    $member_7ree[avatar_7ree] = avatar($member_7ree[uid], small, TRUE, FALSE, TRUE);
								if(imgexist_7ree($member_7ree[avatar_7ree])){
									$member_7ree[avatar_7ree] = $member_7ree[avatar_7ree];
								}else{
									$member_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';;
								}
							}
							$newbielist_7ree[] = $member_7ree;
					}      	
					
					$curdata .= "\$newbie_list_7ree = ".arrayeval($newbielist_7ree).";\n\n";
					DB::free_result($query);
			}   


			//���ְ�
			if($vars_7ree[extrank_title_7ree]){ //�Ƿ����û��ְ���Ŀ

					if(!$vars_7ree['rankext_7ree']){
						$ranktitle_7ree = lang('plugin/toplist_7ree','php_lang_fen_7ree');
						$member_query_7ree = "SELECT username, uid, credits FROM ".DB::table('common_member')." WHERE uid>0 ORDER BY credits DESC LIMIT $newbienum_7ree";		    
					}else{
						$ranktitle_7ree = $_G['setting']['extcredits'][$vars_7ree['rankext_7ree']]['title'];
						$thisextcredits_7ree = 'extcredits'.$vars_7ree['rankext_7ree'];
					    $member_query_7ree = "SELECT uid, $thisextcredits_7ree AS credits FROM ".DB::table('common_member_count')." WHERE uid >0 ORDER BY {$thisextcredits_7ree} DESC LIMIT $newbienum_7ree";
					}
				
					$query = DB::query($member_query_7ree);

					while($creditarray_7ree = DB::fetch($query)) {
							if(!$creditarray_7ree['username']) $creditarray_7ree['username'] = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '$creditarray_7ree[uid]'");
							if($vars_7ree['onoffavatar_7ree']){
								$creditarray_7ree[avatar_7ree] = avatar($creditarray_7ree[uid], small, TRUE, FALSE, TRUE);
								if(imgexist_7ree($creditarray_7ree[avatar_7ree])){
									$creditarray_7ree[avatar_7ree] = $creditarray_7ree[avatar_7ree];
								}else{
									$creditarray_7ree[avatar_7ree] = $_G['setting']['ucenterurl'].'/images/noavatar_small.gif';
								}
							}
							$creditarray_7ree['credits']=$creditarray_7ree['credits'].$ranktitle_7ree;
							$credit_7ree[] = $creditarray_7ree;
					}      	
					$curdata .= "\$credit_list_7ree = ".arrayeval($credit_7ree).";\n\n";
					DB::free_result($query);
			}  

			writetocache("$cachename_ranklist", $curdata);
			discuz_process::unlock($ranklist_cacheprocess_7ree);
		}

			@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_ranklist.'.php';
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>