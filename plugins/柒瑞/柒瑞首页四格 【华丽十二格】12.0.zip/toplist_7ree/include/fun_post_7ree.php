<?php

/*
	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
	Update: 2019/2/1 22:05
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	//��ȡ�������ֶ��趨
	$thread_column_7ree = "tid, fid, author, authorid, subject, dateline, lastpost, lastposter, views, replies, highlight";

	$cachename_toplist	= "toplist_7ree";//������.����β����ͻ���޸�,ֻҪ����ͻ����Ӱ��ʹ��.

	@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';

if($_G['uid'] && (!$cachetime2_7ree || $_G['timestamp'] - $cachetime2_7ree > $cachecycle2_7ree * 60)) {

	$colorarray = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
	$curdata = "\$cachetime2_7ree=".$_G['timestamp'].";\n\n";

	
	if(!$vars_7ree['showgroup_7ree']){
			$query = DB::query("SELECT fid FROM ".DB::table('forum_forum')." WHERE status = 3");
			while($querylist = DB::fetch($query)) {
			      $groupid_7ree[] = $querylist[fid];
			}
			$banfid_7ree = array_merge($groupid_7ree,$forums2_7ree);
			$not_fid2_7ree = count($banfid_7ree) ? "AND t.fid NOT IN (".implode($banfid_7ree,",").")" : "";
	}



	if($vars_7ree['showfidname_7ree']){
				$forumlist_7ree = getforum_7ree();
	}

	$toplist_cacheprocess_7ree='toplist_cache_7ree_refresh';
	if(!discuz_process::islocked($toplist_cacheprocess_7ree, 600)) {

			//����
			if($vars_7ree[new_title_7ree]){ //�Ƿ�����������Ŀ
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$new_post_threadlist = array();
					$nthread = array();
					$query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND dateline + $newtime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");
					
					while($nthread = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $nthread['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$nthread[fid]]);
					$nthread['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($nthread['subject'],$hack_cut_str));
					$nthread['view_author'] = cutstr($nthread['author'],$hack_cut_strauthor);
					$nthread['date']= gmdate("Y-m-d H:i:s", $nthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread['date2']= gmdate("m-d H:i", $nthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($nthread['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $nthread['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$nthread['highlight'] = 'style="';
							$nthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$nthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$nthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$nthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$nthread['highlight'] .= '"';
					} else {
							$nthread['highlight'] = '';
					}
					$newpost_threadlist[] = $nthread;
			}
					$curdata .= "\$new_post_threadlist = ".arrayeval($newpost_threadlist).";\n\n";
			       	DB::free_result($query);
			}       
					//�»ظ�
			if($vars_7ree[rep_title_7ree]){ //�Ƿ�����������Ŀ
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$new_reply_threadlist = array();
					$rthread = array();
					
					$query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND replies !=0 AND dateline + $reptime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY lastpost DESC LIMIT 0, $shownum_7ree");
					
					while($rthread = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $rthread['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$rthread[fid]]);
					$rthread['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($rthread['subject'],$hack_cut_str));
					$rthread['view_lastposter'] = cutstr($rthread['lastposter'],$hack_cut_strauthor);
					$rthread['date']= gmdate("Y-m-d H:i:s", $rthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$rthread['date2']= gmdate("m-d H:i", $rthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$rthread['lastreplytime']= gmdate("Y-m-d H:i:s", $rthread[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($rthread['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $rthread['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$rthread['highlight'] = 'style="';
							$rthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$rthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$rthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$rthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$rthread['highlight'] .= '"';
					} else {
							$rthread['highlight'] = '';
					}
					$replypost_threadlist[] = $rthread;
			}
			$curdata .= "\$reply_post_threadlist = ".arrayeval($replypost_threadlist).";\n\n";
					DB::free_result($query);
			}
					
					//������
			if($vars_7ree[dig_title_7ree]){ //�Ƿ����þ�������Ŀ   
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$new_digest_threadlist = array();
					$dthread = array();
					
					$query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND digest in (1,2,3) AND displayorder >=0 AND dateline + $digtime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} ORDER BY dateline DESC LIMIT $shownum_7ree");
					
					while($dthread = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $dthread['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$dthread[fid]]);
					$dthread['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($dthread['subject'],$hack_cut_str));
					$dthread['view_lastposter'] = cutstr($dthread['lastposter'],$hack_cut_strauthor);
					$dthread['date']= gmdate("Y-m-d H:i:s", $dthread['dateline'] + $_G[setting][timeoffset] * 3600);
				    $dthread['date2']= gmdate("m-d H:i", $dthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$dthread['lastreplytime']= gmdate("Y-m-d H:i:s", $dthread[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($dthread['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $dthread['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$dthread['highlight'] = 'style="';
							$dthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$dthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$dthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$dthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$dthread['highlight'] .= '"';
					} else {
							$dthread['highlight'] = '';
					}
					$digestpost_threadlist[] = $dthread;
			}
			$curdata .= "\$digest_post_threadlist = ".arrayeval($digestpost_threadlist).";\n\n";
					DB::free_result($query);
			}

			//����
			if($vars_7ree[hot_title_7ree]){ //�Ƿ����þ�������Ŀ
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$hot_post_threadlist = array();
					$hthread = array();
					
					if($vars_7ree['hotorder_7ree']=='view'){
						$hotorderby_7ree = ' ORDER BY views ';
					}elseif($vars_7ree['hotorder_7ree']=='reply'){
					    $hotorderby_7ree = ' ORDER BY replies ';
					}else{
						$hotorderby_7ree = ' ORDER BY views ';
					}
					
					$query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE closed NOT LIKE 'moved|%' AND displayorder >=0 AND dateline + $hottime_7ree * 86400 > $_G[timestamp] AND dateline<{$_G[timestamp]} {$not_fid2_7ree} {$hotorderby_7ree} DESC LIMIT 0, $shownum_7ree");
					
					while($hthread = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $hthread['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$hthread[fid]]);
					$hthread['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($hthread['subject'],$hack_cut_str));
					$hthread['view_author'] = cutstr($hthread['author'],$hack_cut_strauthor);
					$hthread['date']= gmdate("Y-m-d H:i:s", $hthread['dateline'] + $_G[setting][timeoffset] * 3600);
					$hthread['lastreplytime']= gmdate("Y-m-d H:i:s", $hthread[lastpost] + ($_G[setting][timeoffset] * 3600));
					$hthread['date2']= gmdate("m-d H:i", $hthread['lastpost'] + $_G[setting][timeoffset] * 3600);
					if($hthread['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $hthread['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$hthread['highlight'] = 'style="';
							$hthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$hthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$hthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$hthread['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$hthread['highlight'] .= '"';
					} else {
							$hthread['highlight'] = '';
					}
					$hotpost_threadlist[] = $hthread;
			}
					$curdata .= "\$hot_post_threadlist = ".arrayeval($hotpost_threadlist).";\n\n";
					
						DB::free_result($query);
			}   
					
					
					//����fid1
			if($vars_7ree[diy1_title_7ree]){ //�Ƿ�����DIY1����Ŀ
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$new_post1_threadlist = array();
					$nthread1 = array();
					 $query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE displayorder >=0 AND dateline<{$_G[timestamp]} {$fid1_where_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");
					
					while($nthread1 = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $nthread1['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$nthread1[fid]]);
					$nthread1['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($nthread1['subject'],$hack_cut_str));
					$nthread1['view_author'] = cutstr($nthread1['author'],$hack_cut_strauthor);
					$nthread1['date']= gmdate("Y-m-d H:i:s", $nthread1['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread1['date2']= gmdate("m-d H:i", $nthread1['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread1['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread1[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($nthread1['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $nthread1['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$nthread1['highlight'] = 'style="';
							$nthread1['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$nthread1['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$nthread1['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$nthread1['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$nthread1['highlight'] .= '"';
					} else {
							$nthread1['highlight'] = '';
					}
					$newpost1_threadlist[] = $nthread1;
			}
					$curdata .= "\$new_post1_threadlist = ".arrayeval($newpost1_threadlist).";\n\n";
					
					DB::free_result($query);
			}


			//����fid2
			if($vars_7ree[diy2_title_7ree]){ //�Ƿ�����DIY2����Ŀ
					$hack_cut_str = $cutstr_7ree; //��������
					$hack_cut_strauthor = 9;
					$new_post2_threadlist = array();
					$nthread2 = array();
					
					$query = DB::query("SELECT {$thread_column_7ree} FROM ".DB::table('forum_thread')." t WHERE displayorder >=0 AND dateline<{$_G[timestamp]} {$fid2_where_7ree} ORDER BY dateline DESC LIMIT 0, $shownum_7ree");
					while($nthread2 = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $nthread2['forumname'] = preg_replace('/<[^>]*>/','',$forumlist_7ree[$nthread2[fid]]);
					$nthread2['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($nthread2['subject'],$hack_cut_str));
					$nthread2['view_author'] = cutstr($nthread2['author'],$hack_cut_strauthor);
					$nthread2['date']= gmdate("Y-m-d H:i:s", $nthread2['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread2['date2']= gmdate("m-d H:i", $nthread2['dateline'] + $_G[setting][timeoffset] * 3600);
					$nthread2['lastreplytime']= gmdate("Y-m-d H:i:s", $nthread2[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($nthread2['highlight'] && $highlight_7ree) {
							$string = sprintf('%02d', $nthread2['highlight']);
							$stylestr = sprintf('%03b', $string[0]);
							$nthread2['highlight'] = 'style="';
							$nthread2['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$nthread2['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$nthread2['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$nthread2['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$nthread2['highlight'] .= '"';
					} else {
							$nthread2['highlight'] = '';
					}
					$newpost2_threadlist[] = $nthread2;
					}
					$curdata .= "\$new_post2_threadlist = ".arrayeval($newpost2_threadlist).";\n\n";
					DB::free_result($query);
			}   

			if($vars_7ree['tui_title_7ree']){ //�Ƿ������Ƽ���Ŀ

					$tuijian = array();
					
					$query = DB::query("SELECT * FROM ".DB::table('toplist_push_7ree')." ORDER BY id_7ree DESC LIMIT 0, $shownum_7ree");		
					while($tuijian = DB::fetch($query)) {
					if($vars_7ree['showfidname_7ree']) $tuijian['forumname'] = preg_replace('/<[^>]*>/','',$tuijian['fname_7ree']);
					$tuijian['view_subject'] = preg_replace('/&lt;|&gt;|<|>|\'/','',cutstr($tuijian['subject_7ree'],$hack_cut_str));
					$tuijian['view_author'] = cutstr($tuijian['author_7ree'],$hack_cut_strauthor);
					$tuijian['date']= gmdate("Y-m-d H:i:s", $tuijian['time_7ree'] + $_G[setting][timeoffset] * 3600);
					$tuijian['date2']= gmdate("m-d H:i", $tuijian['time_7ree'] + $_G[setting][timeoffset] * 3600);
					$tuijian['lastreplytime']= gmdate("Y-m-d H:i:s", $tuijian[lastpost] + ($_G[setting][timeoffset] * 3600));
					if($tuijian['highlight_7ree'] && $highlight_7ree) {
							$string = sprintf('%02d', $tuijian['highlight_7ree']);
							$stylestr = sprintf('%03b', $string[0]);
							$tuijian['highlight'] = 'style="';
							$tuijian['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
							$tuijian['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
							$tuijian['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
							$tuijian['highlight'] .= $string[1] ? 'color: '.$colorarray[$string[1]] : '';
							$tuijian['highlight'] .= '"';
					} else {
							$tuijian['highlight'] = '';
					}
					$tuijian_7ree_threadlist[] = $tuijian;
					}
					$curdata .= "\$tuijian_threadlist_7ree = ".arrayeval($tuijian_7ree_threadlist).";\n\n";
					DB::free_result($query);

			}

			writetocache("$cachename_toplist", $curdata);
			discuz_process::unlock($toplist_cacheprocess_7ree);

	}

	@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';


}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>