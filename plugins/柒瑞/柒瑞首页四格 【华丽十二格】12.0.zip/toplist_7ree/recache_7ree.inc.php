<?php

/*
	ID: toplist_7ree 
	DisM!Ӧ�����ģ�dism.taobao.com
	Update: 2017/7/18 15:20
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$pluginid_7ree = 'toplist_7ree';
	$langdir_7ree = 'plugin/'.$pluginid_7ree;
	$pic_cachename	= 'showpic_7ree';
	$cachename_toplist	= "toplist_7ree";
	$cachename_ranklist	= "ranklist_7ree";

	$vars_7ree = $_G['cache']['plugin'][$pluginid_7ree];
	$_GET['op_7ree'] = intval($_GET['op_7ree']);//����״̬����
	$_GET['how_7ree'] = intval($_GET['how_7ree']);//�����������

	@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
	$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';

	
	$picfile_path = DISCUZ_ROOT.$cahcedir_7ree.$pic_cachename.'.php';
	$postfile_path = DISCUZ_ROOT.$cahcedir_7ree.$cachename_toplist.'.php';
	$rankfile_path = DISCUZ_ROOT.$cahcedir_7ree.$cachename_ranklist.'.php';
	
	if(!$_GET['op_7ree']){
		//@include $picfile_path ;
		//@include $postfile_path;
	     $cachetime_7ree = filemtime($picfile_path);
	     $cachetime2_7ree = filemtime($postfile_path);
	     $cachetime3_7ree = filemtime($rankfile_path);
		if($cachetime_7ree){
				$cachestring_7ree = gmdate("Y-m-d H:i:s", $cachetime_7ree + ($_G[setting][timeoffset] * 3600));
		}else{
				$cachestring_7ree = lang($langdir_7ree,"php_lang_nocache_7ree");
		}
	
		if($cachetime2_7ree){
				$cachestring2_7ree = gmdate("Y-m-d H:i:s", $cachetime2_7ree + ($_G[setting][timeoffset] * 3600));
		}else{
				$cachestring2_7ree = lang($langdir_7ree,"php_lang_nocache_7ree");
				
		}
			
		if($cachetime3_7ree){
				$cachestring3_7ree = gmdate("Y-m-d H:i:s", $cachetime3_7ree + ($_G[setting][timeoffset] * 3600));
		}else{
				$cachestring3_7ree = lang($langdir_7ree,"php_lang_nocache_7ree");
				
		}
		
		include template($pluginid_7ree.':recache_7ree');
		
	}elseif($_GET['op_7ree']==1){
		if($_GET['formhash'] != FORMHASH)	cpmsg("Access Denied.", "",'error');

		if($_GET['how_7ree']==1){
			
			if(file_exists($picfile_path)) unlink($picfile_path);


		cpmsg("toplist_7ree:php_lang_delpiccache_7ree", "action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=recache_7ree$extra",'succeed');
			
		}elseif($_GET['how_7ree']==2){
			
			if(file_exists($postfile_path)) unlink($postfile_path);
		
		cpmsg("toplist_7ree:php_lang_delpostcache_7ree", "action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=recache_7ree$extra",'succeed');
		
		}elseif($_GET['how_7ree']==3){
			
			if(file_exists($rankfile_path)) unlink($rankfile_path);
		
		cpmsg("toplist_7ree:php_lang_delrankcache_7ree", "action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=recache_7ree$extra",'succeed');
		
		}

		

	
	}else{//Undefined Option
		
	 	cpmsg("Undefined Option.", "",'error');
	 
	}



?>