<?php

/*
	���²����http://t.cn/Aiux1Jx1
	Update: 2020/8/13 16:26
	This is NOT a freeware, use is subject to license terms
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/developer-7.html
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_toplist_7ree_forum {

	function viewthread_useraction() {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
		$adminuid_7ree = explode(',',$vars_7ree['adminuid_7ree']);
		$isadmin_7ree = ($_G['uid'] && in_array($_G['uid'],$adminuid_7ree)) || $_G['adminid']==1;
		if($isadmin_7ree && $vars_7ree['tui_title_7ree']){
			
		if($_G['tid']) $already_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('toplist_push_7ree')." WHERE tid_7ree = ".$_G['tid']);
	
		if($already_7ree){
			$return_7ree = "<a href='javascript:;'><i><img src='static/image/common/push.png'>".lang('plugin/toplist_7ree', 'php_lang_tuisong2_7ree')."</i></a>";
		}else{
			$return_7ree = "<a href='javascript:;' onclick='showWindow(&quot;pushwin_7ree&quot;, &quot;plugin.php?id=toplist_7ree:push_action_7ree&tid_7ree={$_G[tid]}&quot;)'><i><img src='static/image/common/push.png'>".lang('plugin/toplist_7ree', 'php_lang_tuisong_7ree')."</i></a>";
		}
		return $return_7ree;
		}else{
		return '';
		}	
	}
	
	function index_top() {
		global $_G;
		require_once libfile('function/cache');
		
		@include DISCUZ_ROOT.'source/plugin/toplist_7ree/include/fun_tools_7ree.php';
		
		$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
		$attachurl = $_G['setting']['attachurl'];
		$agreement_7ree = $vars_7ree['agreement_7ree'];
		$onoff_7ree = $vars_7ree['onoff_7ree'];
		$width_7ree = $vars_7ree['width_7ree'];
		$height_7ree = $vars_7ree['height_7ree'];
		$cell_height_7ree = $height_7ree + 7;
		$highlight_7ree = $vars_7ree['highlight_7ree'];
		$cutstr_7ree = $vars_7ree['cutstr_7ree']; 
		$blank_7ree = $vars_7ree['blank_7ree']; 
		
		$forums_7ree = array_filter(unserialize($vars_7ree['forums_7ree']));
		$fid_7ree = implode($forums_7ree,",");
		$not_fid_7ree = $fid_7ree ? "AND t.fid NOT IN ($fid_7ree)" : "";

		$forums2_7ree = array_filter(unserialize($vars_7ree['forums2_7ree']));
		$fid2_7ree = implode($forums2_7ree,",");
		$not_fid2_7ree = $fid2_7ree ? "AND t.fid NOT IN ($fid2_7ree)" : "";

		$blank_7ree = $blank_7ree ? "target='_blank'" : "target='_self'";
		$hottime_7ree = $vars_7ree['hottime_7ree'];
		$newtime_7ree = $vars_7ree['newtime_7ree'];
		$reptime_7ree = $vars_7ree['reptime_7ree'];
		$digtime_7ree = $vars_7ree['digtime_7ree'];
		$right_show_7ree = $vars_7ree['right_show_7ree'];
		$headertitleshow_7ree = $vars_7ree['headertitleshow_7ree']; 
		$linetitle_style_7ree =  $vars_7ree['linetitle_style_7ree'];
		$tiptime_7ree = $vars_7ree['tiptime_7ree'] * 1000;
		$shownum_7ree = min(intval($vars_7ree[shownum_7ree]) ? intval($vars_7ree[shownum_7ree]) : 9, 50);
		$newbienum_7ree = min(intval($vars_7ree[newbienum_7ree]),100);
		$membercycle_7ree = max(intval($vars_7ree[membercycle_7ree]),1);
		$cachecycle_7ree = intval($vars_7ree[cachecycle_7ree]);
		$cachecycle2_7ree = intval($vars_7ree[cachecycle2_7ree]);
		$cachecycle3_7ree = intval($vars_7ree[cachecycle3_7ree]);
		$vars_7ree['fid1title_7ree'] = trim($vars_7ree['fid1title_7ree']);
		$vars_7ree['fid2title_7ree'] = trim($vars_7ree['fid2title_7ree']);

		$fotobtnbg_7ree = $vars_7ree['fotobtnbg_7ree'] ? str_replace("#","0x",$vars_7ree['fotobtnbg_7ree']) : "0x0099ff";


		$fid1_7ree = $vars_7ree['fid1_7ree'] ? array_filter(unserialize($vars_7ree['fid1_7ree'])) : array();
 		$fid2_7ree = $vars_7ree['fid2_7ree'] ? array_filter(unserialize($vars_7ree['fid2_7ree'])) : array(); 
 		$fid1_where_7ree =  COUNT($fid1_7ree) ? "AND t.fid IN (".implode($fid1_7ree,",").")" : "";
 		$fid2_where_7ree =  COUNT($fid2_7ree) ? "AND t.fid IN (".implode($fid2_7ree,",").")" : "";
 		
 		$vars_7ree['tplmode_7ree'] = $vars_7ree['tplmode_7ree'] ? $vars_7ree['tplmode_7ree']: 1;
 			
 		$tpl_4ge_title_7ree =  array(
	 							    'xt'=>trim($vars_7ree['newpic_title_7ree']),
	 							    'jt'=>trim($vars_7ree['digpic_title_7ree']),
	 							    'gt'=>trim($vars_7ree['adspic_title_7ree']),
	 							    'xz'=>trim($vars_7ree['new_title_7ree']),
	 							    'xh'=>trim($vars_7ree['rep_title_7ree']),
	 							    'jz'=>trim($vars_7ree['dig_title_7ree']),
	 							    'rz'=>trim($vars_7ree['hot_title_7ree']),
	 							    'd1'=>trim($vars_7ree['diy1_title_7ree']),
	 							    'd2'=>trim($vars_7ree['diy2_title_7ree']),
	 							    'tj'=>trim($vars_7ree['tui_title_7ree']),
	 							    'hy'=>trim($vars_7ree['acvrank_title_7ree']),
	 							    'jf'=>trim($vars_7ree['extrank_title_7ree']),
	 							    'xm'=>trim($vars_7ree['newrank_title_7ree']),
	 								);

 
		$thread_tagnum_7ree = 7;
		$pic_tagnum_7ree = 3;
		$pic_order_7ree = explode("-",trim($vars_7ree[pic_order_7ree]));
		$thread_order_7ree = explode("-",trim($vars_7ree[thread_order_7ree]));
		$rank_order_7ree = explode("-",trim($vars_7ree[rank_order_7ree]));	
		$toplist_4georder_7ree = explode("-",trim($vars_7ree[toplist_4georder_7ree]));

		$ranknum_7ree = $threadnum_7ree = 0;
		foreach($toplist_4georder_7ree as $gevalue_7ree){
		   $toplist_4ge_url_7ree[$gevalue_7ree] = getgurl_7ree($gevalue_7ree,4);
		   if(in_array($gevalue_7ree,array('hy','jf','xm'))){
		   	$ranknum_7ree += 1;
		   }else{
		   	$threadnum_7ree += 1;
		   }
		}
		
		$gz2_width_7ree = 100/($ranknum_7ree+$threadnum_7ree*1.5);
		$gz_width_7ree = $gz2_width_7ree*1.5;	
	
		$pic_title1_7ree = $pic_title2_7ree = $pic_title3_7ree = '';  
		$thread_title1_7ree = $thread_title2_7ree = $thread_title3_7ree = $thread_title5_7ree =  $thread_title5_7ree =  $thread_title6_7ree =  $thread_title7_7ree = '';		
		$rank_title1_7ree = $rank_title2_7ree = $rank_title3_7ree = '';
		
		$pickey_7ree = array('1','2','3');
		$threadkey_7ree = array('1','2','3','4','5','6','7');
		$rankkey_7ree = array('1','2','3');
		
		for($i1_7ree=0;$i1_7ree<3;$i1_7ree++){
			$pic_title_var[$i1_7ree] = $pic_order_7ree[$i1_7ree]."pic_title_7ree";
			$pic_title_7ree[$i1_7ree] = $vars_7ree[$pic_title_var[$i1_7ree]];
			$pic_url_7ree[$i1_7ree] = getgurl_7ree($pic_order_7ree[$i1_7ree],1);
		}
		
		for($i2_7ree=0;$i2_7ree<7;$i2_7ree++){
			$thread_title_var[$i2_7ree] = $thread_order_7ree[$i2_7ree]."_title_7ree";
			$thread_title_7ree[$i2_7ree] = $vars_7ree[$thread_title_var[$i2_7ree]];
			$thread_url_7ree[$i2_7ree] = getgurl_7ree($thread_order_7ree[$i2_7ree],2);
		}
		
		for($i3_7ree=0;$i3_7ree<3;$i3_7ree++){
			$rank_title_var[$i3_7ree] = $rank_order_7ree[$i3_7ree]."rank_title_7ree";
			$rank_title_7ree[$i3_7ree] = $vars_7ree[$rank_title_var[$i3_7ree]];
			$rank_url_7ree[$i3_7ree] = getgurl_7ree($rank_order_7ree[$i3_7ree],3);
		}		
		
		if (!$agreement_7ree) return "<div class='tbms mtm mbm'>".lang('plugin/toplist_7ree', 'php_lang_agree_7ree')."</div>";
		
		$bangid_7ree = $vars_7ree['bangid_7ree'] ? unserialize($vars_7ree['bangid_7ree']) : array();
		if(in_array($_G['groupid'] , $bangid_7ree)) return '';
		
		
		if (!$onoff_7ree ||(!$vars_7ree[gidshow_7ree] && $_GET[gid])) return "";

		$weekarray=array(lang('plugin/toplist_7ree', 'php_lang_week0_7ree'),
						lang('plugin/toplist_7ree', 'php_lang_week1_7ree'),
						lang('plugin/toplist_7ree', 'php_lang_week2_7ree'),
						lang('plugin/toplist_7ree', 'php_lang_week3_7ree'),
						lang('plugin/toplist_7ree', 'php_lang_week4_7ree'),
				 		lang('plugin/toplist_7ree', 'php_lang_week5_7ree'),
						lang('plugin/toplist_7ree', 'php_lang_week6_7ree')
		);
		$date_7ree = gmdate(lang('plugin/toplist_7ree', 'php_lang_date_7ree'), $_G[timestamp] + $_G[setting][timeoffset] * 3600);
		$week_7ree = $weekarray[gmdate("w", $_G[timestamp] + $_G[setting][timeoffset] * 3600)]; 
		$time_7ree = gmdate(lang('plugin/toplist_7ree', 'php_lang_time_7ree'), $_G[timestamp] + $_G[setting][timeoffset] * 3600);



		@include DISCUZ_ROOT.'source/plugin/toplist_7ree/include/fun_pic_7ree.php';

		@include DISCUZ_ROOT.'source/plugin/toplist_7ree/include/fun_post_7ree.php';

		@include DISCUZ_ROOT.'source/plugin/toplist_7ree/include/fun_rank_7ree.php';


		include template('toplist_7ree:toplist_7ree');

		return $return;
	}





}




?>