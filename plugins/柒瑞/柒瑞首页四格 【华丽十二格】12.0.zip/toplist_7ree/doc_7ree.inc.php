<?php

/*
	ID: toplist_7ree 
	���²����http://t.cn/Aiux1Jx1
	Update: 2020/8/13 16:26
	This is NOT a freeware, use is subject to license terms
	Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: https://dism.taobao.com/developer-7.html
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/plugins/toplist_7ree.FAQ_toplist_7ree.html';</script>";


?>