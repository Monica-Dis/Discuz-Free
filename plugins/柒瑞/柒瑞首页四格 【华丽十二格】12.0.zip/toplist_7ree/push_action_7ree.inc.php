<?php

/*
	ID: toplist_7ree 
	DisM!Ӧ�����ģ�dism.taobao.com
	Update: 2017/2/4 12:21
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		$vars_7ree = $_G['cache']['plugin']['toplist_7ree'];
		$adminuid_7ree = explode(',',$vars_7ree['adminuid_7ree']);
		$isadmin_7ree = ($_G['uid'] && in_array($_G['uid'],$adminuid_7ree)) || $_G['adminid']==1;
if(!$isadmin_7ree) {
	showmessage("Error_7ree#Access Deined.");
}
$_GET['tid_7ree'] = intval($_GET['tid_7ree']);
if(!$_GET['tid_7ree']) showmessage('7ree ERROR Tips # Miss Tid.');
if(submitcheck('submit_7ree')){//�ύ����
//�����Ƿ��Ѿ����͹�
$already_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('toplist_push_7ree')." WHERE tid_7ree = ".$_GET['tid_7ree']);

$threadinfo_7ree = DB::fetch_first("SELECT * FROM ".DB::table('forum_thread')." WHERE tid = ".$_GET['tid_7ree']);

if($already_7ree){
	showmessage('toplist_7ree:php_more_lang_push_error_7ree');
}else{

     $threadinfo_7ree['fname_7ree'] = DB::result_first("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = ".$threadinfo_7ree['fid']);
     	 
	 if($threadinfo_7ree['tid']){
			$datavalue_7ree = array(
		             				'tid_7ree' => $threadinfo_7ree['tid'],		
		             				'fid_7ree' => $threadinfo_7ree['fid'],
				     				'subject_7ree' => $threadinfo_7ree['subject'],
				     				'fname_7ree' => $threadinfo_7ree['fname_7ree'],
				     				'author_7ree' => $threadinfo_7ree['author'],
				     				'uid_7ree' => $threadinfo_7ree['authorid'],
				     				'time_7ree' => $threadinfo_7ree['dateline'],
				     				'highlight_7ree' => $threadinfo_7ree['highlight'],			
					   				);	
		    DB::insert('toplist_push_7ree', $datavalue_7ree);	
showmessage('toplist_7ree:php_more_lang_push_success_7ree','forum.php?mod=viewthread&tid='.$threadinfo_7ree['tid']);   //showmessage('toplist_7ree:php_more_lang_push_success_7ree','forum.php?mod=viewthread&tid='.$_GET['tid_7ree'],array(),array('showmsg' => 1, 'showdialog' => 1, 'locationtime' => 3));
	 
	 }else{
	 	showmessage('7ree ERROR Tips # Miss Thread.');
	 }	


}
   
}else{
	include template('toplist_7ree:push_action_7ree');
}
//From: Dism��taobao��com
?>