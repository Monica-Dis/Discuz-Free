<?php

/*
	ID: toplist_7ree 
	DisM!Ӧ�����ģ�dism.taobao.com
	Update: 2017/2/4 12:21
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
   	loadcache('plugin');
	$pluginid_7ree = 'toplist_7ree';   	
 	$vars_7ree = $_G['cache']['plugin'][$pluginid_7ree];
	$op_7ree = intval($_GET[op_7ree]);//����״̬����  	

if(!$op_7ree){
	$pagemax_7ree = 20;
	$page = max(1, intval($_G['gp_page']));
	$startpage = ($page - 1) * $pagemax_7ree;

	$querynum = DB::result_first("SELECT Count(*) FROM ".DB::table('toplist_push_7ree'));
	
	if($querynum){
	
		$query = DB::query("SELECT * FROM ".DB::table('toplist_push_7ree')." 
						ORDER BY id_7ree DESC LIMIT {$startpage}, {$pagemax_7ree}");
       	while($table_7ree = DB::fetch($query)){       				
       				$table_7ree['subject'] = cutstr($table_7ree['subject'],80);
       				$table_7ree['time_7ree'] = gmdate("Y-m-d H:i", $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600);
		   			$list_7ree[] = $table_7ree;
		} 

		$multipage = multi($querynum, $pagemax_7ree, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=pushlist_7ree$extra");
    }		
	include template($pluginid_7ree.':pushlist_7ree');
	
}elseif($op_7ree==1){
		if($_GET[formhash] != FORMHASH)	cpmsg("Access Denied.", "",'error');
		
		$_GET[id_7ree] = intval($_GET[id_7ree]);
		if($_GET[id_7ree]) DB::query("DELETE FROM ".DB::table('toplist_push_7ree')." WHERE id_7ree = '{$_GET[id_7ree]}'");

		cpmsg('toplist_7ree:php_more_lang_unpush_success_7ree',"action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=pushlist_7ree$extra","succeed");
		
	
}elseif($op_7ree==2){
		if(!submitcheck(submit_7ree)) cpmsg("Access Denied.", "",'error');
		if(count($_GET['mod_7ree'])){
			$_GET['mod_7ree'] = dintval((array)$_GET['mod_7ree'], true);
			DB::query("DELETE FROM ".DB::table('toplist_push_7ree')." WHERE tid_7ree IN (".dimplode($_GET['mod_7ree']).")");
			cpmsg('toplist_7ree:php_more_lang_unpush_success_7ree',"action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=pushlist_7ree$extra","succeed");
		}else{
			cpmsg('toplist_7ree:php_lang_pushadmin_error_7ree', "",'error');
		}
		cpmsg('toplist_7ree:php_more_lang_unpush_success_7ree',"action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=pushlist_7ree$extra","succeed");
}else{//Undefined Option
		
	 	cpmsg("Undefined Option.", "",'error');
	 
	}



?>