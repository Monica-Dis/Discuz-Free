<?php 
/*
	ID: toplist_7ree 
	DisM!Ӧ�����ģ�dism.taobao.com
	Update: 2017/2/4 12:21
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/ 


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
 
 	
$Shortcut = "[InternetShortcut] 
URL=".$_G['setting']['siteurl']."
IDList= 
[{000214A0-0000-0000-C000-000000000046}] 
Prop3=19,2 
"; 

Header("Content-type: application/octet-stream"); 


	if(strpos($_SERVER['HTTP_USER_AGENT'],"MSIE")){
		header("Content-Disposition: attachment; filename=".urlencode($_G['setting']['bbname']).".url;"); 
	}else{
		header("Content-Disposition: attachment; filename=".$_G['setting']['bbname'].".url;"); 
	}


echo $Shortcut;

?>