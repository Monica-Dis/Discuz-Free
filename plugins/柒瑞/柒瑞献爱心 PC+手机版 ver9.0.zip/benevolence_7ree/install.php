<?php
/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/11 11:33
	Agreement: http://Dism.Taobao.Com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://Dism.Taobao.Com/?@7ree
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_benevolence_7ree`;
CREATE TABLE IF NOT EXISTS `pre_benevolence_7ree` (
  `id_7ree` mediumint(8) unsigned NOT NULL auto_increment,
  `logtime_7ree` int(10) unsigned NOT NULL,
  `uid_7ree` mediumint(8) unsigned NOT NULL,
  `num_7ree` mediumint(8) NOT NULL,
  `detail_7ree` varchar(255) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;


EOF;

runquery($sql);

$finish = TRUE;