<?php
/*
	[www.7ree.com] (C)2007-2018 7ree.com.
	Ӧ�ø���֧�֣�https://dism.taobao.com
	Update: 2018/12/16 0:45
	���²����http://t.cn/Aiux1Jx1
	�����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



$folder_7ree ='source/plugin/x7ree_portal/upload';
$pagenum_7ree=20;

$pluginid_7ree = 'x7ree_portal';
$langdir_7ree = 'plugin/'.$pluginid_7ree;
loadcache('plugin');

$vars_7ree = $_G['cache']['plugin']['x7ree_portal'];

if(!$vars_7ree['agreement_7ree']) showmessage($identifier.':php_lang_agree_7ree');


$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']][title];

$navtitle = $vars_7ree['navtitle_7ree'];


$code_7ree = intval($_GET['code_7ree']);
$id_7ree = intval($_GET['id_7ree']);

if(!$_G['uid']) showmessage('not_loggedin', NULL, array(), array('login' => 1));

if($_G['adminid']<>1) showmessage( "Access Deined @7ree" );

if(in_array($code_7ree,array("2")) && !submitcheck('submit_7ree')) showmessage("Access Deined @7ree");

if(in_array($code_7ree,array("3")) && $_GET['formhash']<>FORMHASH) showmessage('Access Deined @7ree');

if(in_array($code_7ree,array("3")) && !$id_7ree) showmessage( "ERROR,Missing required parameter.@7ree" );





?>