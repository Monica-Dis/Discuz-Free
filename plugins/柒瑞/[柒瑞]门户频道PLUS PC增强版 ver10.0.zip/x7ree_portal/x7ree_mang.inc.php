<?php
/*
	Copyright 2001-2099 DisM!Ӧ������.
	Ӧ�ø���֧�֣�https://dism.taobao.com
	Update: 2018/12/12 3:46
	���²����http://t.cn/Aiux1Jx1
	�����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied.');
}



require_once DISCUZ_ROOT.'./source/plugin/x7ree_portal/include/access_7ree.php';

require_once DISCUZ_ROOT.'./source/plugin/x7ree_portal/include/function_7ree.php';

$thismodule_7ree = $module;





if(!$code_7ree){//�����б�

	$startpage = ( $page - 1 ) * $pagenum_7ree;
	$querynum = DB::result_first( "SELECT Count(*) FROM ".DB::table('x7ree_portal'));
	$query = DB::query( "SELECT * FROM ".DB::table('x7ree_portal')." LIMIT {$startpage},{$pagenum_7ree}" );

	while ($list_table = DB::fetch($query)){
			if($_G['uid']){//catname��ѯ
				$list_table['catname'] = DB::result_first("SELECT catname FROM ".DB::table('portal_category')." WHERE catid='$list_table[catid_7ree]'");
			}
			$list_7ree[]=$list_table;
	}


	$multipage = multi($querynum, $pagenum_7ree, $page, "action=plugins&operation=config&do=$pluginid&identifier=$pluginid_7ree&pmod=x7ree_mang" );


}elseif($code_7ree==1){//�������༭��Ƶ������ҳ��

//��ȡƵ������upid=0

	$query = DB::query( "SELECT * FROM ".DB::table('portal_category')." WHERE upid=0 LIMIT 100" );
	while ($list_table = DB::fetch($query)){
			$list_7ree[]=$list_table;
	}
	
	if($id_7ree){
		$this_7ree = DB::fetch_first( "SELECT * FROM ".DB::table('x7ree_portal')." WHERE id_7ree='$id_7ree'" );
	}


}elseif($code_7ree==2){//�ύ�������༭Ƶ������

	$catid_7ree = intval($_GET['catid_7ree']);
	$nav1_7ree = dhtmlspecialchars(trim($_GET['nav1_7ree']));
	$nav2_7ree = dhtmlspecialchars(trim($_GET['nav2_7ree']));
	$css_7ree = dhtmlspecialchars(trim($_GET['css_7ree']));
	
	if(!$id_7ree){
		if(!$_FILES['logo_7ree']['size'] || !$_FILES['banner_7ree']['size'] ){
			cpmsg('x7ree_portal:php_lang_post_err1_7ree', '','error');
		}
	}

	if(!$catid_7ree){
		cpmsg('x7ree_portal:php_lang_post_err2_7ree', '','error');
	}
	
	if(!$nav1_7ree || !$nav2_7ree){
		cpmsg('x7ree_portal:php_lang_post_err3_7ree', '','error');
	}
	
	$valuearray_7ree=array(
								'catid_7ree'=>$catid_7ree,
								'nav1_7ree'=>$nav1_7ree,
								'nav2_7ree'=>$nav2_7ree,
								'css_7ree'=>$css_7ree,
							);


	if($_FILES['logo_7ree']['size']){
		$imagearray_7ree['logo_7ree'] = $_FILES['logo_7ree'];
	}
	if($_FILES['banner_7ree']['size']){
		$imagearray_7ree['banner_7ree'] = $_FILES['banner_7ree'];
	}


	if($id_7ree){
		$wherearray_7ree=array('id_7ree'=>$id_7ree);
	}else{
		$wherevalue_7ree=array();
	}
	
	data_update_7ree('x7ree_portal',$valuearray_7ree,$wherearray_7ree,$imagearray_7ree,$folder_7ree);
	
	cpmsg('x7ree_portal:php_lang_post_ok_7ree','action=plugins&operation=config&do='.$pluginid.'&identifier='.$pluginid_7ree.'&pmod=x7ree_mang','succeed');

}elseif($code_7ree==3){

	$wherearray_7ree = array('id_7ree'=>$id_7ree);
	$imagearray_7ree = array('logo_7ree','banner_7ree');
	data_delete_7ree('x7ree_portal',$wherearray_7ree,$imagearray_7ree,$folder_7ree);

	cpmsg('x7ree_portal:php_lang_del_ok_7ree','action=plugins&operation=config&do='.$pluginid.'&identifier='.$pluginid_7ree.'&pmod=x7ree_mang','succeed');

}else{

	cpmsg("Undefined Operation @ 7ree.com", '','error');
}



include template('x7ree_portal:x7ree_mang');

?>
