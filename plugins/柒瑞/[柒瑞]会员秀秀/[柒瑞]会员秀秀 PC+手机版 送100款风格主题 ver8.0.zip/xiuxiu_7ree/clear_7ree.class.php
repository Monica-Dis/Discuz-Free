<?php
	
/*
	ID: xiuxiu_7ree
	[dism.taobao.com] (C)2007-2018 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2018/9/11 22:53
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/	
	
	
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_xiuxiu_7ree {
	function deletethread($param) {
		if($param['step'] == 'delete') {
			$tid = $param['param'][0][0];
			if($tid) {
				$thread = get_thread_by_tid($tid, 'tid');
				if(empty($thread)) {
					$deltid_7ree = DB::result_first("SELECT tid_7ree FROM ".DB::table('xiuxiu_member_7ree')." WHERE tid_7ree='{$tid}'");
					DB::query("DELETE FROM ".DB::table('xiuxiu_member_7ree')." WHERE tid_7ree='{$deltid_7ree}'");
				}
			}
		}	
	}
}

class mobileplugin_xiuxiu_7ree {
	function global_footer_mobile(){
			global $_G,$postinfo;
			$return = "";
			if($_GET['action']=='reply'){
				$postinfo[message]='';
			}
			//include template('xiuxiu_7ree:xiuxiu_7ree');
			return $return;
	}
}
class mobileplugin_xiuxiu_7ree_forum extends mobileplugin_xiuxiu_7ree{
}
//From: dis'.'m.tao'.'bao.com
?>