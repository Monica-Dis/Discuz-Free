<?php
/*
	ID: xiuxiu_7ree
	[dism.taobao.com] (C)2007-2018 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2018/9/11 22:56
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF


CREATE TABLE IF NOT EXISTS `pre_xiuxiu_member_7ree` (
  `id_7ree` int(10) NOT NULL auto_increment,
  `tid_7ree` mediumint(8) NOT NULL,
  `aid_7ree` int(10) NOT NULL,
  `suit_7ree` varchar(20) NOT NULL,
  `count_7ree` mediumint(8) NOT NULL,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(20) NOT NULL,
  `name_7ree` varchar(200) NOT NULL,
  `gender_7ree` tinyint(1) NOT NULL,
  `xingzuo_7ree` varchar(20) NOT NULL,
  `string1_7ree` varchar(250) NOT NULL,
  `string2_7ree` varchar(250) NOT NULL,
  `string3_7ree` varchar(250) NOT NULL,
  `string4_7ree` varchar(250) NOT NULL,
  `string5_7ree` varchar(250) NOT NULL,
  `string6_7ree` varchar(250) NOT NULL,
  `text1_7ree` text NOT NULL,
  `text2_7ree` text NOT NULL,
  `text3_7ree` text NOT NULL,
  `text4_7ree` text NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;




EOF;

runquery($sql);

$finish = TRUE;