<?php
/*
	ID: xiuxiu_7ree
	[dism.taobao.com] (C)2007-2018 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2018/9/11 22:56
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/	

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF

DROP TABLE IF EXISTS `pre_xiuxiu_member_7ree`;

EOF;

runquery($sql);

$finish = TRUE;

?>