<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-09 20:54:58
*/	
	
	
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
if($vars_7ree['typename_7ree']){
	define('TNAME_XIUXIU_7REE', $vars_7ree['typename_7ree']);
}else{
	define('TNAME_XIUXIU_7REE', lang('plugin/xiuxiu_7ree', 'php_lang_threadname_7ree'));
}
if($vars_7ree['btn_text_7ree']){
	define('BTNNAME_XIUXIU_7REE', $vars_7ree['btn_text_7ree']);
}else{
	define('BTNNAME_XIUXIU_7REE', lang('plugin/xiuxiu_7ree', 'php_lang_btnname_7ree'));
}



class threadplugin_xiuxiu_7ree {

	var $name = TNAME_XIUXIU_7REE;	//������������
	var $buttontext = BTNNAME_XIUXIU_7REE;//����ʱ��ť����
	var $iconfile = 'template/images/xiu_7ree.png';
	
	function newthread() {
		global $_G;
		$return = '';
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
		
		if(!$vars_7ree['agreement_7ree']){
				showmessage('xiuxiu_7ree:php_lang_agree_7ree');
		}
		
		if($vars_7ree['avatar_7ree'] && empty($_G['member']['avatarstatus'])){
				showmessage('xiuxiu_7ree:php_lang_needavatar_7ree','home.php?mod=spacecp&ac=avatar');
		}
		
		@require_once libfile('function/core');
		$zoom_7ree = dintval((array)explode('*',$vars_7ree['zoom_7ree']), true);
		$prewidth_7ree = round((250/$zoom_7ree[1])*$zoom_7ree[0]);
		
		$suit_7ree = $this->scansuit_7ree();
		$suit_jsarray_7ree = dimplode($suit_7ree);

		include template('xiuxiu_7ree:xiuxiu_input_7ree');

		return $return;
	}

	function newthread_submit($fid) {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];	

		if (!trim($_GET[gender_7ree])) showmessage('xiuxiu_7ree:php_lang_inputxingbie_7ree','');
		if (!trim($_GET[xingzuo_7ree])) showmessage('xiuxiu_7ree:php_lang_inputxingzuo_7ree','');
		if (!trim($_GET[name_7ree])) showmessage('xiuxiu_7ree:php_lang_inputxingming_7ree','');
		if (!trim($_GET[string1_7ree]) && $vars_7ree['string1_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string1_name_7ree],'');
		if (!trim($_GET[string2_7ree]) && $vars_7ree['string2_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string2_name_7ree],'');
		if (!trim($_GET[string3_7ree]) && $vars_7ree['string3_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string3_name_7ree],'');
		if (!trim($_GET[string4_7ree]) && $vars_7ree['string4_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string4_name_7ree],'');
		if (!trim($_GET[string5_7ree]) && $vars_7ree['string5_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string5_name_7ree],'');
		if (!trim($_GET[string6_7ree]) && $vars_7ree['string6_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[string6_name_7ree],'');
		
	
		if (!trim($_GET[text1_7ree]) && $vars_7ree['text1_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[text1_name_7ree],'');
		if (!trim($_GET[text2_7ree]) && $vars_7ree['text2_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[text2_name_7ree],'');
		if (!trim($_GET[text3_7ree]) && $vars_7ree['text3_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[text3_name_7ree],'');
		if (!trim($_GET[text4_7ree]) && $vars_7ree['text4_req_7ree']) showmessage(lang('plugin/xiuxiu_7ree', 'php_lang_inputinput_7ree').$vars_7ree[text4_name_7ree],'');
		if(empty($_GET[coverid_7ree]) && $vars_7ree['cover_7ree']) showmessage('xiuxiu_7ree:php_lang_inputcover_7ree','');
	
	}
	
	function newthread_submit_end($fid, $tid){
		global $_G,$tid,$pid;
		$insertvalue_7ree = array();
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
		// ��ȫ����
		$tid = intval($tid);
		$_GET['gender_7ree'] = intval($_GET['gender_7ree']);
		$_GET['xingzuo_7ree'] = daddslashes(dhtmlspecialchars($_GET['xingzuo_7ree']));
		$_GET['name_7ree'] = daddslashes(dhtmlspecialchars($_GET['name_7ree']));
		$_GET['user_7ree'] = daddslashes(dhtmlspecialchars($_GET['user_7ree']));
		$_GET['string1_7ree'] = daddslashes(dhtmlspecialchars($_GET['string1_7ree']));
		$_GET['string2_7ree'] = daddslashes(dhtmlspecialchars($_GET['string2_7ree']));
		$_GET['string3_7ree'] = daddslashes(dhtmlspecialchars($_GET['string3_7ree']));
		$_GET['string4_7ree'] = daddslashes(dhtmlspecialchars($_GET['string4_7ree']));
		$_GET['string5_7ree'] = daddslashes(dhtmlspecialchars($_GET['string5_7ree']));
		$_GET['string6_7ree'] = daddslashes(dhtmlspecialchars($_GET['string6_7ree']));

		$_GET['text1_7ree'] = daddslashes(dhtmlspecialchars($_GET['text1_7ree']));
		$_GET['text2_7ree'] = daddslashes(dhtmlspecialchars($_GET['text2_7ree']));
		$_GET['text3_7ree'] = daddslashes(dhtmlspecialchars($_GET['text3_7ree']));
		$_GET['text4_7ree'] = daddslashes(dhtmlspecialchars($_GET['text4_7ree']));
		$_GET['coverid_7ree'] = intval($_GET['coverid_7ree']);
		$_GET['suit_7ree'] = daddslashes(dhtmlspecialchars($_GET['suit_7ree']));
		$_GET['suit_7ree'] = preg_replace('/[^0-9a-zA-Z_]/','',$_GET['suit_7ree']);

		
		if(empty($_GET[coverid_7ree]) && $vars_7ree['cover_7ree']){
			showmessage('xiuxiu_7ree:php_lang_inputcover_7ree','');
		}else{
			if($_GET[coverid_7ree]){
					$attachtable = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$_GET[coverid_7ree]'");
					!$attachtable && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_unused')." WHERE aid='$_GET[coverid_7ree]' AND uid='$_G[uid]' AND isimage='1'");
					$attachtable = $attachtable == 127 ? 'unused' : $attachtable;
					($attachtable && empty($attachment)) && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_'.$attachtable)." WHERE aid='$_GET[coverid_7ree]' AND uid='$_G[uid]' AND isimage='1'");
					if(empty($attachment)) {
						showmessage('ERROR, No Cover Photo. @7ree');
					}
					if($attachtable == 'unused') {
						convertunusedattach($_GET['coverid_7ree'], $tid, $pid);
					}
					$tableid = DB::result_first("SELECT posttableid FROM ".DB::table('forum_thread')." WHERE tid='$tid'");
					if(!$tableid) {
						$tablename = 'forum_post';
					} else {
						$tablename = "forum_post_$tableid";
					}

					DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
					DB::query("UPDATE ".DB::table($tablename)." SET attachment=2 WHERE pid='$pid'");

					$threadimage = DB::fetch_first("SELECT tid, pid, attachment, remote FROM ".DB::table(getattachtablebyaid($_GET['coverid_7ree']))." WHERE aid='{$_GET[coverid_7ree]}'");
				
					if(setthreadcover(0, 0, $_GET['coverid_7ree'])) {
						$threadimage = daddslashes($threadimage);
						DB::delete('forum_threadimage', "tid='$threadimage[tid]'");
						DB::insert('forum_threadimage', array(
							'tid' => $threadimage['tid'],
							'attachment' => $threadimage['attachment'],
							'remote' => $threadimage['remote'],
						));
					}
			}
		}
		
		
		
						
		//������� 
		$insertvalue_7ree = array(
									'uid_7ree' => $_G['uid'],
									'tid_7ree' => $tid,
									'aid_7ree'=> $_GET['coverid_7ree'],
									'suit_7ree' => $_GET['suit_7ree'],
									'user_7ree' => $_GET['user_7ree'],
									'name_7ree'=> $_GET['name_7ree'],
									'gender_7ree'=> $_GET['gender_7ree'],
									'xingzuo_7ree'=> $_GET['xingzuo_7ree'],
									'string1_7ree'=> $_GET['string1_7ree'],
									'string2_7ree'=> $_GET['string2_7ree'],
									'string3_7ree'=> $_GET['string3_7ree'],
									'string4_7ree'=> $_GET['string4_7ree'],
									'string5_7ree'=> $_GET['string5_7ree'],
									'string6_7ree'=> $_GET['string6_7ree'],
									'text1_7ree'=> $_GET['text1_7ree'],	
									'text2_7ree'=> $_GET['text2_7ree'],	
									'text3_7ree'=> $_GET['text3_7ree'],	
									'text4_7ree'=> $_GET['text4_7ree'],
									);
		DB::insert('xiuxiu_member_7ree', $insertvalue_7ree);


	}
	

	

	function viewthread() {
		global $_G,$skipaids;
		$return = '';
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
		@require_once libfile('function/core');
		$zoom_7ree = dintval((array)explode('*',$vars_7ree['zoom_7ree']), true);
		$prewidth_7ree = round((250/$zoom_7ree[1])*$zoom_7ree[0]);
		$post_xiuxiu_7ree = DB::fetch_first("SELECT * FROM ".DB::table('xiuxiu_member_7ree')." WHERE tid_7ree='{$_G[tid]}' LIMIT 1");
			$limit_7ree = FALSE;
			if($vars_7ree['zhichilimit_7ree']){
				$cookiename_7ree = 'xiuxiu_7ree_'.$post_xiuxiu_7ree['id_7ree'];
				$todaycount_7ree = $_G['cookie'][$cookiename_7ree];
				$limit_7ree = $todaycount_7ree >= $vars_7ree['zhichilimit_7ree'] ? TRUE : FALSE;
			}
				$post_xiuxiu_7ree['text1_7ree'] = nl2br($post_xiuxiu_7ree['text1_7ree']);
				$post_xiuxiu_7ree['text2_7ree'] = nl2br($post_xiuxiu_7ree['text2_7ree']);
				$post_xiuxiu_7ree['text3_7ree'] = nl2br($post_xiuxiu_7ree['text3_7ree']);
				$post_xiuxiu_7ree['text4_7ree'] = nl2br($post_xiuxiu_7ree['text4_7ree']);
				if($post_xiuxiu_7ree['aid_7ree']){
					$post_xiuxiu_7ree['attachment'] = getforumimg($post_xiuxiu_7ree['aid_7ree'], 0, $zoom_7ree[0], $zoom_7ree[1]);
					$post_xiuxiu_7ree['encodeaid'] = aidencode($post_xiuxiu_7ree['aid_7ree']);
					$skipaids[] = $post_xiuxiu_7ree['aid_7ree'];
				}
				$post_xiuxiu_7ree['suit_7ree'] = preg_replace('/[^0-9a-zA-Z_]/','',$post_xiuxiu_7ree['suit_7ree']);

					if(!$post_xiuxiu_7ree['suit_7ree']){
							@include template('xiuxiu_7ree:xiuxiu_view_7ree');
					}else{
							@include(DISCUZ_ROOT.'source/plugin/xiuxiu_7ree/template/suit_7ree/'.$post_xiuxiu_7ree[suit_7ree].'/tpl_7ree/xiuxiu_'.$post_xiuxiu_7ree[suit_7ree].'_7ree.cfg.php');
							@include template('xiuxiu_'.$post_xiuxiu_7ree[suit_7ree].'_7ree', null, 'source/plugin/xiuxiu_7ree/template/suit_7ree/'.$post_xiuxiu_7ree[suit_7ree].'/tpl_7ree');
					}


		if($vars_7ree['closetext_7ree']){
            $return = str_replace('class="bottom_7ree bottomcolor_7ree"', 'class="7ree bottomcolor_7ree" style="display:none;"',$return);
        }

		if(defined('IN_MOBILE')){
			if($vars_7ree['css_mo_7ree']){
				$return.='<style>'.$vars_7ree['css_mo_7ree'].'</style>';
			}
		}else{
			if($vars_7ree['css_pc_7ree']){
				$return.='<style>'.$vars_7ree['css_pc_7ree'].'</style>';
			}
		}

		return $return;
	}
	


	function editpost($fid, $tid) {

		global $_G;
		$return = '';
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
		@require_once libfile('function/core');
		$zoom_7ree = dintval((array)explode('*',$vars_7ree['zoom_7ree']), true);
		$prewidth_7ree = round((250/$zoom_7ree[1])*$zoom_7ree[0]);
		$suit_7ree = $this->scansuit_7ree();
		$suit_jsarray_7ree = dimplode($suit_7ree);
		
		
		$post_xiuxiu_7ree = DB::fetch_first("SELECT * FROM ".DB::table('xiuxiu_member_7ree')." WHERE tid_7ree='{$_G[tid]}' LIMIT 1");
		
		if($post_xiuxiu_7ree){
			$xiuxiucover_7ree = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$post_xiuxiu_7ree[aid_7ree]}'");
				if($xiuxiucover_7ree['remote']) {
					$xiuxiucover_7ree['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$xiuxiucover_7ree['attachment'];
					$xiuxiucover_7ree['attachment'] = substr($auctionatt['attachment'], 0, 7) != 'http://' ? 'http://'.$auctionatt['attachment'] : $auctionatt['attachment'];
				} else {
					$xiuxiucover_7ree['attachment'] = $_G['setting']['attachurl'].'forum/'.$xiuxiucover_7ree['attachment'];
				}
		}
		
		
		
		
                            if($_GET['mobile']){
                                $return='No mobile template support.#7ree';  
                            }else{
                                include template('xiuxiu_7ree:xiuxiu_input_7ree');
                            }
		return $return;
	}
	
		
	function editpost_submit($fid, $tid){
		global $_G;
		$this->newthread_submit($fid);
	}

	function editpost_submit_end($fid, $tid){
		global $_G,$tid;
		$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];

		// ��ȫ����
		$_GET['gender_7ree'] = intval($_GET['gender_7ree']);
		$_GET['xingzuo_7ree'] = daddslashes(dhtmlspecialchars($_GET['xingzuo_7ree']));
		$_GET['name_7ree'] = daddslashes(dhtmlspecialchars($_GET['name_7ree']));
		$_GET['user_7ree'] = daddslashes(dhtmlspecialchars($_GET['user_7ree']));
		$_GET['string1_7ree'] = daddslashes(dhtmlspecialchars($_GET['string1_7ree']));
		$_GET['string2_7ree'] = daddslashes(dhtmlspecialchars($_GET['string2_7ree']));
		$_GET['string3_7ree'] = daddslashes(dhtmlspecialchars($_GET['string3_7ree']));
		$_GET['string4_7ree'] = daddslashes(dhtmlspecialchars($_GET['string4_7ree']));
		$_GET['string5_7ree'] = daddslashes(dhtmlspecialchars($_GET['string5_7ree']));
		$_GET['string6_7ree'] = daddslashes(dhtmlspecialchars($_GET['string6_7ree']));
			
		$_GET['text1_7ree'] = daddslashes(dhtmlspecialchars($_GET['text1_7ree']));
		$_GET['text2_7ree'] = daddslashes(dhtmlspecialchars($_GET['text2_7ree']));
		$_GET['text3_7ree'] = daddslashes(dhtmlspecialchars($_GET['text3_7ree']));
		$_GET['text4_7ree'] = daddslashes(dhtmlspecialchars($_GET['text4_7ree']));
		$_GET['coverid_7ree'] = intval($_GET['coverid_7ree']);
		$_GET['suit_7ree'] = daddslashes(dhtmlspecialchars($_GET['suit_7ree']));
		$_GET['suit_7ree'] = preg_replace('/[^0-9a-zA-Z_]/','',$_GET['suit_7ree']);

		
		
		if($_GET['coverid_7ree'] && DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_attachment_unused')." WHERE aid='{$_GET[coverid_7ree]}' AND uid='{$_G[uid]}'")) {
				$aid = DB::result_first("SELECT aid_7ree FROM ".DB::table('xiuxiu_member_7ree')." WHERE tid_7ree='{$_G[tid]}'");
				
				
				if($aid) {
				
				
					$att = DB::fetch_first("SELECT aid,tid,tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
					if($att['tableid']) {
						$attach = DB::fetch_first("SELECT tid, pid, attachment, thumb, remote, aid FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
						dunlink($attach);
						DB::query("DELETE FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
						DB::query("DELETE FROM ".DB::table('forum_attachment_'.$att['tableid'])." WHERE aid='$aid'");
					}

				}
				DB::query("UPDATE ".DB::table('xiuxiu_member_7ree')." SET aid_7ree='{$_GET['coverid_7ree']}' WHERE tid_7ree='{$_G[tid]}'");
				DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='{$_G[tid]}'");
				convertunusedattach($_GET['coverid_7ree'], $_G[tid], $_GET['pid']);	
				
				$threadimage = DB::fetch_first("SELECT tid, pid, attachment, remote FROM ".DB::table(getattachtablebyaid($_GET['coverid_7ree']))." WHERE aid='{$_GET[coverid_7ree]}'");
		
			if(setthreadcover(0, 0, $_GET['coverid_7ree'])) {
				$threadimage = daddslashes($threadimage);
				DB::delete('forum_threadimage', "tid='$threadimage[tid]'");
				DB::insert('forum_threadimage', array(
					'tid' => $threadimage['tid'],
					'attachment' => $threadimage['attachment'],
					'remote' => $threadimage['remote'],
				));
			}
				
				
				
		
		}		
		

		$updatevalue_7ree = array(
									'suit_7ree' => $_GET['suit_7ree'],
									'user_7ree' => $_GET['user_7ree'],
									'name_7ree'=> $_GET['name_7ree'],
									'gender_7ree'=> $_GET['gender_7ree'],
									'xingzuo_7ree'=> $_GET['xingzuo_7ree'],
									'string1_7ree'=> $_GET['string1_7ree'],
									'string2_7ree'=> $_GET['string2_7ree'],
									'string3_7ree'=> $_GET['string3_7ree'],
									'string4_7ree'=> $_GET['string4_7ree'],
									'string5_7ree'=> $_GET['string5_7ree'],
									'string6_7ree'=> $_GET['string6_7ree'],
									'text1_7ree'=> $_GET['text1_7ree'],
									'text2_7ree'=> $_GET['text2_7ree'],
									'text3_7ree'=> $_GET['text3_7ree'],
									'text4_7ree'=> $_GET['text4_7ree'],
									);
		$wherevalue_7ree = array('tid_7ree' => $_G[tid]);
		DB::update('xiuxiu_member_7ree', $updatevalue_7ree, $wherevalue_7ree);

	}	


	function scansuit_7ree($pathname = './source/plugin/xiuxiu_7ree/template/suit_7ree/*'){
		$return_7ree = array();
		foreach( glob($pathname) as $filename ){
			if(is_dir($filename)){
					$suitname_7ree = explode("/",$filename);
					$thisnum_7ree = count($suitname_7ree)-1;
					$return_7ree[] = $suitname_7ree[$thisnum_7ree];

			}
		}
		return $return_7ree;
	}


}
//From: dis'.'m.tao'.'bao.com
?>