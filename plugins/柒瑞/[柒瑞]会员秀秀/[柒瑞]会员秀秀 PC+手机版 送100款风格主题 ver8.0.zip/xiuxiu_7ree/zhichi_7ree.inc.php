<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-09 20:55:04
*/	


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if ($_GET[formhash] <> FORMHASH) showmessage("Access Deined.");

if(!$_GET['id_7ree']) showmessage('ERROR, Missing Required Parameter! @7ree');


$vars_7ree = $_G['cache']['plugin']['xiuxiu_7ree'];
$_GET['id_7ree']=intval($_GET['id_7ree']);

$limit_7ree = FALSE;

if($vars_7ree['zhichilimit_7ree']){
	
	$cookiename_7ree = 'xiuxiu_7ree_'.$_GET['id_7ree'];
	$todaycount_7ree = $_G['cookie'][$cookiename_7ree];
//cookie �ж�
	$limit_7ree = $todaycount_7ree >= $vars_7ree['zhichilimit_7ree'] ? TRUE : FALSE;
//cookie д��
	$cookie_expires = 86400;
	dsetcookie($cookiename_7ree, $todaycount_7ree+1, $cookie_expires);
}

//sqlд���ȡ
if(!$limit_7ree){
		DB::query("UPDATE ".DB::table('xiuxiu_member_7ree')." SET count_7ree = count_7ree +1 WHERE id_7ree = '{$_GET['id_7ree']}' LIMIT 1");
		$count_7ree = DB::result_first("SELECT count_7ree FROM ".DB::table('xiuxiu_member_7ree')." WHERE id_7ree = '{$_GET['id_7ree']}' LIMIT 1");
}else{
		$count_7ree = lang('plugin/xiuxiu_7ree', 'php_lang_yizhichi_7ree');
}

include template('xiuxiu_7ree:ajax_7ree');

?>