<?php
/*
	[www.7ree.com] (C)2006-2020 7ree.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2020/8/19 21:23
	���²����http://t.cn/Aiux1Jx1
	������ҵ���/ģ������ ����DisM!Ӧ������
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class plugin_guestview_7ree{

		function global_footerlink() {
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['guestview_7ree'];
			
			if(!in_array($vars_7ree['pcmobile_7ree'],array('1','3'))){
				return $return;
			}
			
			if($vars_7ree['btime_7ree'] && $vars_7ree['etime_7ree']){
					$btime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['btime_7ree']));
					$etime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['etime_7ree']));
					if($_G['timestamp']<$btime_7ree || $_G['timestamp']>$etime_7ree){
							return $return;
					}
			}
			
			$enddateline_7ree = $_G[timestamp]+3600*$vars_7ree[time_7ree];
			
			$leftright_7ree = $vars_7ree['leftright_7ree'] ? $vars_7ree['leftright_7ree'].":10px;" : "";
			$height_7ree = $vars_7ree['height_7ree'] ? "top:".$vars_7ree['height_7ree']."px;" : "";
			$guestview_num = $_COOKIE["guestview_7ree"] ? $_COOKIE["guestview_7ree"] : 0;
			$remain_7ree = max($vars_7ree[posts_7ree] - $guestview_num,0);
			
			
			$vars_7ree[tip1_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span id='readnum_7ree'>".$remain_7ree."</span>"), $vars_7ree[tip1_7ree]);
			$vars_7ree[tip2_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span>".$vars_7ree[posts_7ree]."</span>"), $vars_7ree[tip2_7ree]);
			
			
			if($vars_7ree['agreement_7ree'] && !$_G[uid] && !$_G[tid] && !IS_ROBOT && $vars_7ree['siteshow_7ree']) include template('guestview_7ree:guesttip_7ree');
			return $return;
	
		}
		
		function viewthread_top() {
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['guestview_7ree'];
			
			if(!in_array($vars_7ree['pcmobile_7ree'],array('1','3'))){
				return $return;
			}
			
			if($vars_7ree['btime_7ree'] && $vars_7ree['etime_7ree']){
					$btime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['btime_7ree']));
					$etime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['etime_7ree']));
					if($_G['timestamp']<$btime_7ree || $_G['timestamp']>$etime_7ree){
							return $return;
					}
			}
			
			$leftright_7ree = $vars_7ree['leftright_7ree'] ? $vars_7ree['leftright_7ree'].":10px;" : "";
			$height_7ree = $vars_7ree['height_7ree'] ? "top:".$vars_7ree['height_7ree']."px;" : "";
			$unlimitfid_7ree = $vars_7ree['unlimitfid_7ree'] ? unserialize($vars_7ree['unlimitfid_7ree']) : array();
			$show_fid_7ree = in_array($_G['fid'],$unlimitfid_7ree) ? 0 : 1 ;
			
			if(!$vars_7ree['agreement_7ree'] || IS_ROBOT) return "";
				
			if(!$_G[uid] && $_G[tid] && $show_fid_7ree) {
				$guestview_num = $_COOKIE["guestview_7ree"] ? $_COOKIE["guestview_7ree"] + 1 : 1;
				
				$enddateline_7ree = $_G[timestamp]+3600*$vars_7ree[time_7ree];
				setcookie("guestview_7ree",$guestview_num,$enddateline_7ree);

				
				$remain_7ree = max($vars_7ree[posts_7ree] - $guestview_num,0);

				if ($guestview_num > $vars_7ree[posts_7ree]){
						$gourl_7ree = "member.php?mod=logging&action=login";
						dheader("location:$gourl_7ree");
						
						
						$vars_7ree[tip1_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span id='readnum_7ree'>".$remain_7ree."</span>"), $vars_7ree[tip1_7ree]);
						$vars_7ree[tip2_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span>".$vars_7ree[posts_7ree]."</span>"), $vars_7ree[tip2_7ree]);
						include template('guestview_7ree:guesttip_7ree');
				}else{
					
				$vars_7ree[tip1_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span id='readnum_7ree'>".$remain_7ree."</span>"), $vars_7ree[tip1_7ree]);
				$vars_7ree[tip2_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span>".$vars_7ree[posts_7ree]."</span>"), $vars_7ree[tip2_7ree]);
					
					
				 include template('guestview_7ree:guesttip_7ree');
				}
			}

			return $return;
		}
		
		
}


class plugin_guestview_7ree_forum extends plugin_guestview_7ree{
}

class plugin_guestview_7ree_group extends plugin_guestview_7ree{
}



class mobileplugin_guestview_7ree_forum{
		function global_footer_mobile(){
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['guestview_7ree'];
			
			if(!in_array($vars_7ree['pcmobile_7ree'],array('2','3'))){
				return $return;
			}
			
			if($vars_7ree['btime_7ree'] && $vars_7ree['etime_7ree']){
					$btime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['btime_7ree']));
					$etime_7ree = strtotime(gmdate("Y-m-d ", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600).trim($vars_7ree['etime_7ree']));
					if($_G['timestamp']<$btime_7ree || $_G['timestamp']>$etime_7ree){
							return $return;
					}
			}
			
			$leftright_7ree = $vars_7ree['leftright_7ree'] ? $vars_7ree['leftright_7ree'].":10px;" : "";
			$height_7ree = $vars_7ree['height_7ree'] ? "top:".$vars_7ree['height_7ree']."px;" : "";
			$guestview_num = $_COOKIE["guestview_7ree"] ? $_COOKIE["guestview_7ree"] + 1 : 1;
			$remain_7ree = max($vars_7ree[posts_7ree] - $guestview_num,0);
			
			$vars_7ree[tip1_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span id='readnum_7ree'>".$remain_7ree."</span>"), $vars_7ree[tip1_7ree]);
			$vars_7ree[tip2_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span>".$vars_7ree[posts_7ree]."</span>"), $vars_7ree[tip2_7ree]);
	
			if($vars_7ree['agreement_7ree'] && !$_G[uid] && !$_G[tid] && !IS_ROBOT && $vars_7ree['siteshow_7ree']) include template('guestview_7ree:guesttip_7ree');

			return $return;
		}
		
		function viewthread_top_mobile(){
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['guestview_7ree'];
			
			if(!in_array($vars_7ree['pcmobile_7ree'],array('2','3'))){
				return $return;
			}
			
			$leftright_7ree = $vars_7ree['leftright_7ree'] ? $vars_7ree['leftright_7ree'].":10px;" : "";
			$height_7ree = $vars_7ree['height_7ree'] ? "top:".$vars_7ree['height_7ree']."px;" : "";
			$unlimitfid_7ree = $vars_7ree['unlimitfid_7ree'] ? unserialize($vars_7ree['unlimitfid_7ree']) : array();
			$show_fid_7ree = in_array($_G['fid'],$unlimitfid_7ree) ? 0 : 1 ;
			
			if(!$vars_7ree['agreement_7ree'] || IS_ROBOT) return "";
				
			if(!$_G[uid] && $_G[tid] && $show_fid_7ree) {
				$guestview_num = $_COOKIE["guestview_7ree"] ? $_COOKIE["guestview_7ree"] + 1 : 1;
				setcookie("guestview_7ree",$guestview_num,$_G[timestamp]+3600*$vars_7ree[time_7ree]);
				
				$remain_7ree = max($vars_7ree[posts_7ree] - $guestview_num,0);
				
				if ($guestview_num > $vars_7ree[posts_7ree]){
						$gourl_7ree = "member.php?mod=logging&action=login";
						dheader("location:$gourl_7ree");
				}else{
					
				$vars_7ree[tip1_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span id='readnum_7ree'>".$remain_7ree."</span>"), $vars_7ree[tip1_7ree]);
			$vars_7ree[tip2_7ree] = str_replace(array('#time#','#post#'), array("<strong>".$vars_7ree[time_7ree]."</strong>","<span>".$vars_7ree[posts_7ree]."</span>"), $vars_7ree[tip2_7ree]);
					
					
				 include template('guestview_7ree:guesttip_7ree');
				}
			}

			return $return;
		}

}
//From: Dism_taobao_com
?>