<?php

/*
	DisM!Ӧ�����ģ�dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	���²����http://t.cn/Aiux1Jx1
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/?@7.developer';</script>";


?>