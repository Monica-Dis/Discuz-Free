<?php
/*
    ID: olgift_7ree
	[dism.taobao.com] (C)2006-2013 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 10:50 2013/7/25
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ') || !IN_ADMIN)  exit('Access Denied');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_olgift_log_7ree` (
  `id_7ree` int(10) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `user_7ree` varchar(20) NOT NULL,
  `btime_7ree` int(10) NOT NULL,
  `etime_7ree` int(10) NOT NULL,
  `ip_7ree` varchar(20) NOT NULL,
  `type_7ree` tinyint(1) NOT NULL,
  `extnum_7ree` mediumint(8) NOT NULL,
  `exttitle_7ree` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM ;

CREATE TABLE IF NOT EXISTS `pre_olgift_rank_7ree` (
  `id_7ree` int(10) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `num_7ree` int(10) NOT NULL,
  `rank_7ree` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM ;

EOF;

runquery($sql);

$finish = TRUE;