<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-06-28 18:57:29
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


		function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("d",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("Y",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}


		function getdegree_7ree($count_7ree){//�ȼ����㺯��
			global $_G;
			$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
          	$count_7ree = intval($count_7ree);
          	$degreeinfo_7ree = '';
            if($count_7ree){  
		            $rank_array=explode("\n",str_replace("\r","",$vars_7ree['rank_7ree']));

					foreach ($rank_array as $rank_vars){
						$rank_array_7ree=explode(",",$rank_vars);
						if($count_7ree>=$rank_array_7ree[1] && $count_7ree<=$rank_array_7ree[2]){
						    $degreeinfo_7ree = $rank_array_7ree[0];
						    break;
						    
						}
					}
            }
			return $return_7ree = $degreeinfo_7ree;
		}


		function putdegree_7ree($uid_7ree){
			global $_G;
        	$uid_7ree = intval($uid_7ree);
        	$rankinfo_7ree = array();
        	if($uid_7ree){
        		$count_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '$uid_7ree' AND  extnum_7ree > 0");
        		if($count_7ree>0){//�������Ч��ȡ�������жϵȼ�����д��rank��
        			$mydegree_7ree = getdegree_7ree($count_7ree);
        		 	$olddegree_7ree = DB::result_first("SELECT num_7ree FROM ".DB::table('olgift_rank_7ree')." WHERE uid_7ree = '{$_G[uid]}'");
                 	if(!$olddegree_7ree){
							DB::query("INSERT INTO ".DB::table('olgift_rank_7ree')." SET num_7ree = '{$count_7ree}', rank_7ree = '{$mydegree_7ree}' , uid_7ree = '{$_G[uid]}'");
					}else{
							if($olddegree_7ree != $count_7ree) DB::query("UPDATE ".DB::table('olgift_rank_7ree')." SET num_7ree = '{$count_7ree}', rank_7ree = '{$mydegree_7ree}' WHERE uid_7ree = '{$_G[uid]}'");			
					}
        		}
        	}
        	$rankinfo_7ree = array($count_7ree,$mydegree_7ree);
        	 
        	return $return_7ree = $rankinfo_7ree;
		}
		
		
		function readdegree_7ree($uid_7ree){//�ȼ���Ϣ��ȡ����
			global $_G;
          	$uid_7ree = intval($uid_7ree);
          	$rankinfo_7ree = array();
            if($uid_7ree) $rankinfo_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_rank_7ree')." WHERE uid_7ree = '$uid_7ree'");
			return $return_7ree = $rankinfo_7ree;
		}


?>