<?php 
//olgift_7ree cache file, DO NOT modify me! 
//(c) dism.taobao.com
//upload: 2021-07-24 20:11:40 

$rankcachetime_7ree = '1627128700';

$rank_cache=array (
  0 => 
  array (
    'uid_7ree' => '1',
    'user_7ree' => 'admin',
    'nums_7ree' => '5',
    'user2_7ree' => 'admin',
  ),
);


?>