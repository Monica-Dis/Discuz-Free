<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-24 20:25:12
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$pluginid_7ree = 'olgift_7ree';
	$langdir_7ree = 'plugin/'.$pluginid_7ree;

	loadcache('plugin');
	$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
	
	if(!$vars_7ree['agreement_7ree']) cpmsg(lang($langdir_7ree, 'php_lang_agree_7ree'), "",'error');

	$pagemax_7ree = 30;
	$page = max(1, intval($_G['page']));
	$startpage = ($page - 1) * $pagemax_7ree;

    if($page == 1){
    		$todaytime_7ree = gmdate("Y-m-d", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600));
			$timewhere_7ree = strtotime($todaytime_7ree); 
			DB::query("DELETE FROM ".DB::table('olgift_log_7ree')." WHERE btime_7ree < {$timewhere_7ree} AND etime_7ree =0 AND extnum_7ree = 0"); 
    }

	$querynum = DB::result_first("SELECT Count(*) FROM ".DB::table('olgift_log_7ree')." WHERE extnum_7ree > 0");
	
	
	$query = DB::query("SELECT * FROM ".DB::table('olgift_log_7ree')." WHERE extnum_7ree > 0
						ORDER BY id_7ree DESC LIMIT {$startpage}, {$pagemax_7ree}");
       			while($table_7ree = DB::fetch($query)){
       			    $table_7ree['btime_7ree'] = $table_7ree['btime_7ree'] ? gmdate("Y-m-d H:i", $table_7ree['btime_7ree'] + $_G['setting']['timeoffset'] * 3600) : "-";
       			    $table_7ree['etime_7ree'] = $table_7ree['etime_7ree'] ? gmdate("Y-m-d H:i", $table_7ree['etime_7ree'] + $_G['setting']['timeoffset'] * 3600) : "-";
		   			$loglist_7ree[] = $table_7ree;
				} 

	$multipage = multi($querynum, $pagemax_7ree, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=".$pluginid_7ree."&pmod=log_7ree$extra");
	
	
	

	include template($pluginid_7ree.':log_7ree');

	
?>