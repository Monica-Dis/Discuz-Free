<?php
/*
    ID: olgift_7ree
	[dism.taobao.com] (C)2007-2016 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	Update: 2016/9/25 14:20
    Agreement: http://dism.taobao.com/agreement.html
*/

if(!defined('IN_DISCUZ') || !IN_ADMIN)  exit('Access Denied');


$sql = <<<EOF

DROP TABLE IF EXISTS `pre_olgift_log_7ree`;
DROP TABLE IF EXISTS `pre_olgift_rank_7ree`;

EOF;

runquery($sql);

$finish = TRUE;

?>