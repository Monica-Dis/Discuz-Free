<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-14 14:04:05
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include_once("source/plugin/olgift_7ree/function_7ree/olgift_function_7ree.php");

$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
		
if(!$vars_7ree['agreement_7ree']) showmessage('olgift_7ree:php_lang_agree_7ree');

$pagenum_7ree = 10;
$i_7ree = 1;
$navtitle = lang('plugin/olgift_7ree', 'php_lang_olgift_7ree');
		
$_GET['code'] = intval($_GET['code']);
$_GET['page'] = intval($_GET['page']);

		if(!$_GET['code']){
			$ranktime_7ree[0] = 0 ;
			$ranktime_7ree[1] = "" ;
		}else{
			$rankcycle_7ree = $_GET['code']+1;
			$ranktime_7ree = gettime_7ree($rankcycle_7ree);
		}
				
if($_G[uid] ){
//ɾ�������������
     if(!$_GET['page']){
	$todaytime_7ree = gmdate("Y-m-d", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600));
	$timewhere_7ree = strtotime($todaytime_7ree);
	//ɾ����������
	DB::query("DELETE FROM ".DB::table('olgift_log_7ree')." WHERE btime_7ree < {$timewhere_7ree} AND etime_7ree =0 AND extnum_7ree = 0 LIMIT 100");
     }
		
	//�ҵ���Ϣ 1������ȡ���������
		$mygiftnum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 AND uid_7ree = '{$_G[uid]}'");
		if($mygiftnum_7ree){
			$mydegree_7ree = getdegree_7ree($mygiftnum_7ree);
			$olddegree_7ree = DB::result_first("SELECT num_7ree FROM ".DB::table('olgift_rank_7ree')." WHERE uid_7ree = '$_G[uid]'");
			if(!$olddegree_7ree){
				DB::query("INSERT INTO ".DB::table('olgift_rank_7ree')." SET num_7ree = '{$mygiftnum_7ree}', rank_7ree = '{$mydegree_7ree}' , uid_7ree = '$_G[uid]'");
			}else{
				if($olddegree_7ree != $mygiftnum_7ree) DB::query("UPDATE ".DB::table('olgift_rank_7ree')." SET num_7ree = '{$mygiftnum_7ree}', rank_7ree = '{$mydegree_7ree}' WHERE uid_7ree = '$_G[uid]'");
			}
        }
	//�ҵ���Ϣ 1���ҵ�����
		$myrank_7ree = 1;
		$query = DB::query("SELECT count(*) as numssss_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY numssss_7ree DESC");
		while($table_7ree = DB::fetch($query)){
			if($table_7ree[numssss_7ree]>$mygiftnum_7ree) $myrank_7ree +=1;
			if($myrank_7ree>100) break; 
		}
		
}		
		
		
//�������ݶ�ȡ
				$querynum_7ree = DB::result_first("SELECT count(distinct uid_7ree) FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0");
				$page = max(1, intval($_GET['page']));
				$startpage = ($page - 1) * $pagenum_7ree;
		
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT {$startpage}, {$pagenum_7ree}");
				while($table_7ree = DB::fetch($query)){
					$table_7ree[rankid_7ree] = $startpage + $i_7ree;
					$table_7ree[rankcss_7ree]='big_7ree';
					if($table_7ree[rankid_7ree]==1) $table_7ree[rankcss_7ree]='bigred_7ree';
					if($table_7ree[rankid_7ree]==2 || $table_7ree[rankid_7ree]==3) $table_7ree[rankcss_7ree]='bigorange_7ree';
					if(!$_GET['code']) $table_7ree['degree_7ree'] = getdegree_7ree($table_7ree['nums_7ree']);	
					$rank_7ree[] = $table_7ree;
					$i_7ree++;
				}
				$multipage = multi($querynum_7ree, $pagenum_7ree, $page, "plugin.php?id=olgift_7ree:index_7ree&code=".$_GET['code']);


include template('olgift_7ree:index_7ree');

		
		
?>