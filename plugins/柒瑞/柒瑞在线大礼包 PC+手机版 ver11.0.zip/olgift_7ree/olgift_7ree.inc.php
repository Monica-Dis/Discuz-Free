<?php
/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-24 20:24:59
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		@include_once("source/plugin/olgift_7ree/function_7ree/olgift_function_7ree.php");

		$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
		
		
		if(!$vars_7ree['agreement_7ree']) showmessage('olgift_7ree:php_lang_agree_7ree');
		
		$bangid_7ree = $vars_7ree['bangid_7ree'] ? unserialize($vars_7ree['bangid_7ree']) : array();
		if(in_array($_G['groupid'],$bangid_7ree)) showmessage('olgift_7ree:php_lang_banfidmsg_7ree');
		
		if($_G['groupid']){
				if($vars_7ree['giftnum1g_7ree']){
						$giftnum1g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum1g_7ree']);
						$giftnum1g_array =  explode('|||', $giftnum1g_7ree);
						foreach($giftnum1g_array as $giftnum1g_value){
								$giftnum1g_array2 = explode('=',trim($giftnum1g_value));
								if($giftnum1g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum1_7ree']=$giftnum1g_array2[1];
									break;
								}
						}
				}
				if($vars_7ree['giftnum2g_7ree']){
						$giftnum2g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum2g_7ree']);
						$giftnum2g_array =  explode('|||', $giftnum2g_7ree);
						foreach($giftnum2g_array as $giftnum2g_value){
								$giftnum2g_array2 = explode('=',trim($giftnum2g_value));
								if($giftnum2g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum2_7ree']=$giftnum2g_array2[1];
									break;
								}
						}
				}
				if($vars_7ree['giftnum3g_7ree']){
						$giftnum3g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum3g_7ree']);
						$giftnum3g_array =  explode('|||', $giftnum3g_7ree);
						foreach($giftnum3g_array as $giftnum3g_value){
								$giftnum3g_array2 = explode('=',trim($giftnum3g_value));
								if($giftnum3g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum3_7ree']=$giftnum3g_array2[1];
									break;
								}
						}
				}
		}

		
		if($_G['uid']){
					
		$todaytime_7ree = gmdate("Y-m-d", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600));
		$timewhere_7ree = strtotime($todaytime_7ree); 
		$_GET['return_7ree'] = intval($_GET['return_7ree']);
		$ranktime_7ree = gettime_7ree($vars_7ree['rankcycle_7ree']);



		$unlimitgid_7ree = $vars_7ree['unlimitgid_7ree'] ? unserialize($vars_7ree['unlimitgid_7ree']) : array();
		$postrq_ban = 0;

		if(!in_array($_G['groupid'],$unlimitgid_7ree) && $vars_7ree['postrq_7ree']){
					$todaypost = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_post')." WHERE authorid = '{$_G[uid]}' AND dateline > '{$timewhere_7ree}'");
					$needpost_7ree = $vars_7ree['postrq_7ree'] - $todaypost;
		}
					
		if($needpost_7ree>0) showmessage(lang('plugin/olgift_7ree', 'php_lang_bantip1_7ree').$needpost_7ree.lang('plugin/olgift_7ree', 'php_lang_bantip2_7ree'));
	

		@include(DISCUZ_ROOT.'./source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php');

		if(!$_GET['return_7ree']){//��ȡ����ajax����


		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." 
									   WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} 
									   ORDER BY id_7ree DESC LIMIT 1");
									   
									   
		$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
		$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
		$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
			
		$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
		$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
		$oltime_7ree = $vars_7ree[$oltime_var] * 60;


			
					
			if(!$mylog_7ree[extnum_7ree]){
			//�ж��Ƿ�������������Ҫ��
			
			if(!$mylog_7ree[btime_7ree] || ($_G['timestamp'] - $mylog_7ree['btime_7ree'] < $oltime_7ree)) showmessage('olgift_7ree:php_lang_oltimenotenought_7ree');
			//�����û�����
			updatemembercount($_G[uid], array($vars_7ree[$giftext_7ree] => $vars_7ree[$giftnum_7ree]));
			
			$pmnotice_7ree = lang('plugin/olgift_7ree', 'php_lang_returnmsg1_7ree').$todaytime_7ree.lang('plugin/olgift_7ree', 'php_lang_returnmsg2_7ree').$vars_7ree[$oltime_var].lang('plugin/olgift_7ree', 'php_lang_returnmsg3_7ree').$mylog_7ree[type_7ree].lang('plugin/olgift_7ree', 'php_lang_returnmsg4_7ree').$vars_7ree[$giftnum_7ree].$exttitle_7ree.lang('plugin/olgift_7ree', 'php_lang_returnmsg5_7ree');
			//������Ϣ����
			if(!$vars_7ree['noticeoff_7ree']) notification_add($_G[uid], 'system', $pmnotice_7ree, $notevar, 1);
			
			//��д�콱״̬����ʱ��
			$updatevalue_7ree = array('etime_7ree' => $_G['timestamp'],
									  'extnum_7ree' => $vars_7ree[$giftnum_7ree],
									  'exttitle_7ree' => $exttitle_7ree,
									  );
			$wherevalue_7ree = array('id_7ree' => $mylog_7ree[id_7ree]);			
			DB::update('olgift_log_7ree', $updatevalue_7ree, $wherevalue_7ree);
			putdegree_7ree($_G['uid']);
			
			//�콱����
			if($vars_7ree[fid_7ree]){
			
			require_once DISCUZ_ROOT.'./source/function/function_forum.php'; 
			require_once DISCUZ_ROOT.'./source/function/function_post.php';
			
				$weekarray_7ree=array(lang('plugin/olgift_7ree', 'php_lang_week0_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week1_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week2_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week3_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week4_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week5_7ree'),
									  lang('plugin/olgift_7ree', 'php_lang_week6_7ree'));
				$vars_7ree[subject_7ree] = str_replace("{week_7ree}",$weekarray_7ree[gmdate("w", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600))],$vars_7ree[subject_7ree]);
				$subject_7ree = str_replace("{data_7ree}",gmdate("m".lang('plugin/olgift_7ree', 'php_lang_yue_7ree')."d".lang('plugin/olgift_7ree', 'php_lang_ri_7ree'), $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600)),$vars_7ree[subject_7ree]);
				$post_array_7ree = (array)explode('||||||',str_replace("\n","||||||",$vars_7ree[post_7ree]));
				$key_7ree=array_rand($post_array_7ree); 
				$post_array_7ree[$key_7ree] = str_replace("{giftnum_7ree}",$vars_7ree[$giftnum_7ree]."[b]".$exttitle_7ree."[/b]",$post_array_7ree[$key_7ree]);
				$post_7ree = str_replace("{n_7ree}","[b]".$mylog_7ree[type_7ree]."[/b]",$post_array_7ree[$key_7ree]);

				$todaytime_7ree = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));

				$tid = DB::result_first("SELECT tid FROM ".DB::table('forum_thread')." WHERE subject ='{$subject_7ree}' AND dateline > $todaytime_7ree AND fid = '{$vars_7ree[fid_7ree]}' LIMIT 1");


			if(!$tid){
				DB::query("INSERT INTO ".DB::table('forum_thread')." (fid, author, authorid, subject, dateline, lastpost, lastposter)
		VALUES ('$vars_7ree[fid_7ree]', '{$_G[username]}', '{$_G[uid]}', '{$subject_7ree}', '{$_G[timestamp]}', '{$_G[timestamp]}', '{$_G[username]}')");
				$tid = DB::insert_id();	
			}

				$pid = insertpost(array(
				'fid' => $vars_7ree[fid_7ree],
				'tid' => $tid,
				'first' => '1',
				'author' => $_G['username'],
				'authorid' => $_G['uid'],
				'subject' => $subject_7ree,
				'dateline' => $_G['timestamp'],
				'message' => $post_7ree,
				'useip' => $_G['clientip'],
				'invisible' => $pinvisible,
				'anonymous' => $isanonymous,
				'usesig' => $usesig,
				'htmlon' => $htmlon,
				'bbcodeoff' => $bbcodeoff,
				'smileyoff' => $smileyoff,
				'parseurloff' => $parseurloff,
				'attachment' => '0',
				'tags' => $tagstr,
				'replycredit' => 0,
				'status' => (defined('IN_MOBILE') ? 8 : 0)
			));
			
		
			DB::query("UPDATE ".DB::table('forum_thread')." SET lastposter='$_G[username]', lastpost='$_G[timestamp]', replies=replies+1 WHERE tid='{$tid}'", 'UNBUFFERED');		
				
			$lastpost = "$tid\t{$subject_7ree}\t{$_G[timestamp]}\t{$_G[username]}";
			DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='$lastpost', threads=threads+1, posts=posts+1, todayposts=todayposts+1 WHERE fid='{$vars_7ree[fid_7ree]}'", 'UNBUFFERED');
			}
			
			
			
			
			
			}


			if($mylog_7ree[type_7ree]<3){//��ʼ�µĵ���ʱ
			$type_7ree = $mylog_7ree[type_7ree] + 1;
			$insertvalue_7ree = array(
             						'uid_7ree' => $_G['uid'],
		     						'user_7ree' => $_G['username'],
		     						'btime_7ree' => $_G['timestamp'],
		     						'ip_7ree' => $_G['clientip'],
		     						'type_7ree' => $type_7ree,
			   						);
		   	DB::insert('olgift_log_7ree', $insertvalue_7ree);
		}elseif($mylog_7ree[type_7ree]==3){
			$mylog_7ree[extnum_7ree] = $vars_7ree[$giftnum_7ree];
		}
	
			
			include template('olgift_7ree:ajaxget_7ree');
			
		}else{//��ȡ���ص���ʱҳ��ajax����
			
			
			
			
		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." 
									   WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} 
									   ORDER BY id_7ree DESC LIMIT 1");
									   
									   
		$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
		$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
		$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
			
		$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
		$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
		$oltime_7ree = $vars_7ree[$oltime_var] * 60;
			
			
		$remaining_time_7ree = $oltime_7ree - ($_G['timestamp'] - $mylog_7ree[btime_7ree]);
		
		
		
		if($_G['timestamp'] - $rankcachetime_7ree > $vars_7ree['rankcachecycle_7ree']*3600){
				
				$RankCache_7ree = "<?php \n//olgift_7ree cache file, DO NOT modify me! \n//(c) dism.taobao.com\n//upload: ".gmdate("Y-m-d H:i:s", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600)." \n\n";
				$RankCache_7ree .= "\$rankcachetime_7ree = '".$_G['timestamp']."';\n\n";
				
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT 12");
				while($table_7ree = DB::fetch($query)){
					$table_7ree[user2_7ree] = cutstr($table_7ree[user_7ree],10,'');
			    	$rank_7ree[] = $table_7ree;
				}
				require_once libfile('function/cache');
				$RankCache_7ree .= "\$rank_cache=".arrayeval($rank_7ree).";\n\n\n?>";
				@$fp = fopen("source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php","w");
				if(!$fp){
					exit();
				}else {
            		fwrite($fp,$RankCache_7ree);
            		fclose($fp);
    			}        	
			}
		


			include template('olgift_7ree:ajaxagain_7ree');
		}

		}else{
		 	showmessage('olgift_7ree:php_lang_loginfirst_7ree');
		}





?>