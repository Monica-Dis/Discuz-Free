<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-07-24 20:24:53
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_olgift_7ree { 
	function global_footer_mobile(){
			global $_G;
			$return = "";
			$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];
			
			if(!$vars_7ree['mob_onoff_7ree']){
				return $return;
			}
			
			$ranktime_7ree = $this->gettime_7ree($vars_7ree['rankcycle_7ree']);
			$vars_7ree['postop_7ree'] = intval($vars_7ree['postop_7ree']) > 1 ? 0.2 : $vars_7ree['postop_7ree'];
			
			$bangid_7ree = $vars_7ree['bangid_7ree'] ? unserialize($vars_7ree['bangid_7ree']) : array();
			if(in_array($_G['groupid'],$bangid_7ree)) return $return;
			
			if($_G['groupid']){
				if($vars_7ree['giftnum1g_7ree']){
						$giftnum1g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum1g_7ree']);
						$giftnum1g_array =  explode('|||', $giftnum1g_7ree);
						foreach($giftnum1g_array as $giftnum1g_value){
								$giftnum1g_array2 = explode('=',trim($giftnum1g_value));
								if($giftnum1g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum1_7ree']=$giftnum1g_array2[1];
									break;
								}
						}
				}
				if($vars_7ree['giftnum2g_7ree']){
						$giftnum2g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum2g_7ree']);
						$giftnum2g_array =  explode('|||', $giftnum2g_7ree);
						foreach($giftnum2g_array as $giftnum2g_value){
								$giftnum2g_array2 = explode('=',trim($giftnum2g_value));
								if($giftnum2g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum2_7ree']=$giftnum2g_array2[1];
									break;
								}
						}
				}
				if($vars_7ree['giftnum3g_7ree']){
						$giftnum3g_7ree =  str_replace("\n","|||",$vars_7ree['giftnum3g_7ree']);
						$giftnum3g_array =  explode('|||', $giftnum3g_7ree);
						foreach($giftnum3g_array as $giftnum3g_value){
								$giftnum3g_array2 = explode('=',trim($giftnum3g_value));
								if($giftnum3g_array2[0]==$_G['groupid']){
									$vars_7ree['giftnum3_7ree']=$giftnum3g_array2[1];
									break;
								}
						}
				}
			}

			
			@include(DISCUZ_ROOT.'./source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php');
			

			if($_G['timestamp'] - $rankcachetime_7ree > $vars_7ree['rankcachecycle_7ree']*3600){
				
				$RankCache_7ree = "<?php \n//olgift_7ree cache file, DO NOT modify me! \n//(c) dism.taobao.com\n//upload: ".gmdate("Y-m-d H:i:s", $_G['timestamp'] + $_G['setting']['timeoffset'] * 3600)." \n\n";
				$RankCache_7ree .= "\$rankcachetime_7ree = '".$_G['timestamp']."';\n\n";
				
				$query = DB::query("SELECT uid_7ree, user_7ree, COUNT(id_7ree) AS nums_7ree FROM ".DB::table('olgift_log_7ree')." WHERE etime_7ree > {$ranktime_7ree[0]} AND extnum_7ree > 0 GROUP BY uid_7ree ORDER BY nums_7ree DESC LIMIT 12");
				while($table_7ree = DB::fetch($query)){
					$table_7ree['user2_7ree'] = cutstr($table_7ree['user_7ree'],10,'');
			    	$rank_7ree[] = $table_7ree;
				}
				require_once libfile('function/cache');
				$RankCache_7ree .= "\$rank_cache=".arrayeval($rank_7ree).";\n\n\n?>";
				@$fp = fopen("source/plugin/olgift_7ree/data_7ree/rank_cache_7ree.php","w");
				if(!$fp){
					exit();
				}else {
            		fwrite($fp,$RankCache_7ree);
            		fclose($fp);
    			}
			}	
		
			if($vars_7ree['agreement_7ree'] && $_G['uid']){
				$todaytime_7ree = gmdate("Y-m-d", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600));
				$timewhere_7ree = strtotime($todaytime_7ree);
			
				//ɾ����������
				DB::query("DELETE FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree < {$timewhere_7ree} AND etime_7ree =0 AND extnum_7ree = 0");
				
				
				$unlimitgid_7ree = $vars_7ree['unlimitgid_7ree'] ? unserialize($vars_7ree['unlimitgid_7ree']) : array();
			    $postrq_ban = 0;

				if(!in_array($_G['groupid'],$unlimitgid_7ree) && $vars_7ree['postrq_7ree']){
					$todaypost = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_post')." WHERE authorid = '{$_G[uid]}' AND dateline > '{$timewhere_7ree}'");
					$needpost_7ree = $vars_7ree['postrq_7ree'] - $todaypost;
					$postrq_ban = $needpost_7ree > 0 ? 1 : 0 ;
				}
				if(!$postrq_ban){
					$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} ORDER BY id_7ree DESC LIMIT 1");
				
					if(!$mylog_7ree[type_7ree]){
						$insertvalue_7ree = array(
		             						'uid_7ree' => $_G['uid'],
				     						'user_7ree' => $_G['username'],
				     						'btime_7ree' => $_G['timestamp'],
				     						'ip_7ree' => $_G['clientip'],
				     						'type_7ree' => 1,
					   						);
				   		DB::insert('olgift_log_7ree', $insertvalue_7ree);
				   		$mylog_7ree = DB::fetch_first("SELECT * FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} ORDER BY id_7ree DESC LIMIT 1");
					}
				
					$giftext_7ree ="exttype".$mylog_7ree[type_7ree]."_7ree";
					$giftnum_7ree = "giftnum".$mylog_7ree[type_7ree]."_7ree";
					$oltime_var = "oltime".$mylog_7ree[type_7ree]."_7ree";
					
					$extname_7ree = "extcredits".$vars_7ree[$giftext_7ree];
					$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree[$giftext_7ree]][title];
					$oltime_7ree = $vars_7ree[$oltime_var] * 60;

					//ʣ��ʱ�����
					$remaining_time_7ree = $oltime_7ree - ($_G['timestamp'] - $mylog_7ree[btime_7ree]);
				}

            }

			if($vars_7ree['agreement_7ree'] && ($vars_7ree['finishonoff_7ree'] || $mylog_7ree[type_7ree]<3 || $mylog_7ree['extnum_7ree']==0)){
				if(!$vars_7ree['js_onoff_7ree']){
					include template('olgift_7ree:olgift_7ree');
				}else{
					$postop_7ree=$vars_7ree['postop_7ree']*100;
					include template('olgift_7ree:olgift2_7ree');
				}
			}

			


			return $return;

	}
	
	function post() {
			global $_G;
			$vars_7ree = $_G['cache']['plugin']['olgift_7ree'];

			$todaytime_7ree = gmdate("Y-m-d", $_G['timestamp'] + ($_G['setting']['timeoffset'] * 3600));
			$timewhere_7ree = strtotime($todaytime_7ree);  
			$unlimitgid_7ree = $vars_7ree['unlimitgid_7ree'] ? unserialize($vars_7ree['unlimitgid_7ree']) : array();
			$ban_7ree = 0;

			if(!in_array($_G['groupid'],$unlimitgid_7ree)){
					if($vars_7ree[postlimit_7ree]) $gifttype_7ree = DB::result_first("SELECT type_7ree FROM ".DB::table('olgift_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND btime_7ree > {$timewhere_7ree} AND extnum_7ree > 0 ORDER BY id_7ree DESC LIMIT 1");
				
						if(!$vars_7ree[postlimit_7ree]){
							$ban_7ree = 0;
						}elseif($vars_7ree[postlimit_7ree]==1){
							$ban_7ree = $gifttype_7ree ? 0 : 1 ;
						}elseif($vars_7ree[postlimit_7ree]==2){
							$ban_7ree = $gifttype_7ree > 1 ? 0 : 1 ;
						}elseif($vars_7ree[postlimit_7ree]==3){
							$ban_7ree = $gifttype_7ree > 2 ? 0 : 1;
						}
						if(!empty($_POST) && $ban_7ree) {
							showmessage(lang('plugin/olgift_7ree', 'php_lang_banmsg1_7ree').$vars_7ree[postlimit_7ree].lang('plugin/olgift_7ree', 'php_lang_banmsg2_7ree')."<br>".$vars_7ree['limittip_7ree']);
						}
					}
	}
	
	
		function gettime_7ree($format_7ree){
		global $_G;
		$return_7ree = array();

		switch ($format_7ree){
		case 1://����
		  	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		  	break;
		case 2://����
		  	$return_7ree[0] = mktime(0, 0, 0, gmdate("m",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("d",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600),date("Y",strtotime("last Monday") + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benzhou_7ree');
		  	break;
		case 3://����
  			$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benyue_7ree');
  			break;
		case 4://������
			$season = ceil((gmdate("n",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600))/3);
			$return_7ree[0] = mktime(0, 0, 0,$season*3-3+1,1,date('Y'));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benji_7ree');
		  	break;
		case 5://�����
		  	$return_7ree[0] = mktime(0,0,0,1,1,gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_bennian_7ree');
 		 	break;
		default:
 		 	$return_7ree[0] = mktime(0,0,0,gmdate("m",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("d",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600),gmdate("Y",$_G['timestamp'] + $_G['setting']['timeoffset'] * 3600));
		  	$return_7ree[1] = lang('plugin/olgift_7ree', 'php_lang_benri_7ree');
		}

		return $return_7ree;

}
	
	
}


class mobileplugin_olgift_7ree_forum extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_group extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_home extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_member extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_portal extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_search extends mobileplugin_olgift_7ree {
}

class mobileplugin_olgift_7ree_plugin extends mobileplugin_olgift_7ree {
}
//From: dis'.'m.tao'.'bao.com
?>