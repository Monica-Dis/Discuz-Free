<?php
/**
 *	[�������⸽��--����ת����(threed_pan.{modulename})] Copyright (c) 2021 by dism.taobao.com
 *	Version: ��ҵ��   http://t.cn/Aiux1Jx1
 *	Date: 2014-12-3 21:54
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class mobileplugin_threed_pan
{


}

class mobileplugin_threed_pan_forum extends mobileplugin_threed_pan
{
    function viewthread_posttop_output()
    {
        global $_G, $postlist, $post;
        $pan_option = $_G['cache']['plugin']['threed_pan'];
        $pan_forums = unserialize($pan_option["thd_forum"]);
        $attachname=$_G['cache']['plugin']['threed_pan']['thd_name'];
        $pan_user = $pan_option["thd_user"];
        $pan_other = $pan_option["thd_other"];
        $pan_name = $pan_option['thd_name'];
        $pan_zhekou = array();
        $pan_zhekougroupid = array();
        $pan_zhekoudownnum = array();
        $pan_zheokou_temp = explode(",", $pan_user);
        foreach ($pan_zheokou_temp as $listk => $listv) {
            $listv_temp = explode("|", $listv);
            $pan_zhekou[] = $listv_temp[1];
            $pan_zhekougroupid[] = $listv_temp[0];
            $pan_zhekoudownum[] = $listv_temp[2];
        }
            $pan_tab1 = "[pan=";
            $pan_tab2 = "]";
            $pan_tab3 = "[/pan]";
            
        foreach ($postlist as $id => $post) {
			
            if ((in_array($_G['fid'], $pan_forums)) && $post['first']) {
				
            $pan_message = $post['message'];
            $tmpmessage='';
            $trmp1_arr = explode($pan_tab1, $pan_message);
            if (count($trmp1_arr) > 1) {
                $n = 1;
                foreach ($trmp1_arr as $key => $trmp1_arrstr) {
                    if ($n == 1) {
                        $pan_message = $trmp1_arrstr;
                        $n++;
                        continue;
                    } else {
                        $tmpmessage .= $pan_tab1 . $trmp1_arrstr;
                    }
                    $n = $n + 1;
                    $trmp2_arr = explode($pan_tab3, $trmp1_arrstr);
                    if (count($trmp2_arr) > 1) {
                        $trmp3_arr = explode($pan_tab2, $trmp2_arr[0]);
                        $pan_srl = $trmp3_arr[0];
                        $pan_srltemp = explode("|", $trmp3_arr[1]);
                        $pan_yuanjia = 0;
                        if (count($pan_srltemp) > 1)
                            $pan_srljiage = $pan_yuanjia = intval($pan_srltemp[1]);
                        $pan_srlname = $pan_srltemp[0];

                        $buycount = DB::result_first('SELECT count(1) FROM ' . DB::table('threed_pan') .
                            ' WHERE buy_tid=' . $_G[tid] . ' and buy_uid = ' . $_G['uid']);
                        $allcount = DB::result_first('SELECT count(1) FROM ' . DB::table('threed_pan') .
                            ' WHERE buy_tid=' . $_G[tid]);

                        foreach ($pan_zhekougroupid as $listk => $listv) {
                            if ($_G[groupid] == $listv) {
                                $pan_srljiage = intval($pan_zhekou[$listk] * $pan_yuanjia / 10);
                                $pan_downnum = $pan_zhekoudownum[$listk];
                            }
                        }
                        if ($post[authorid] == $_G['uid'] || $buycount > 0 || !$pan_srljiage) {
                            $pan_url = $pan_srl;
                            $pan_url = base64_encode($pan_url);
                            $pan_url = 'plugin.php?id=threed_pan:downld&url=' . $pan_url . '&tid=' . $_G['tid'] . '&formhash=' . FORMHASH;
                            $replace = "<br/><a href=\"$pan_url\" class=\"mobile_down\">".lang('plugin/threed_pan', 'mobile1')."($attachname ��$pan_srlname )</a><br/>";

                        } else {

                            $pan_srlgg = ($pan_srljiage + 3) * 91 + 131; //�򵥼���
                            $pan_url = 'plugin.php?id=threed_pan:payfor&ac=buy&tid=' . $_G['tid'] . '&gg=' .
                                $pan_srlgg . '&formhash=' . FORMHASH;
                            $replace = "<br/><a href=\"$pan_url\" class=\"mobile_down\">".lang('plugin/threed_pan', 'mobile2')."$pan_srljiage {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} )</a><br/>";

                        }
                        $replace.='<style> .mobile_down {display: inline-block;	color: #fff !important;	background: #33A0C7 none repeat scroll 0% 0%;	line-height: 35px;font-size: 16px;	width: auto;height: 35px;border-radius: 3px;text-align: center;	position: relative;	font-family: "microsoft yahei";
	vertical-align: middle; margin:5px 10px 5px 10px;}</style>';
                        $tmpmessage = str_replace($pan_tab1 . $trmp2_arr[0] . $pan_tab3, $replace, $tmpmessage);
						

                    }


                }
            }
            $post['message'] = $pan_message . $tmpmessage;
            $postlist[$id] = $post;

			}
		}
    }

}

//From: dis'.'m.tao'.'bao.com
?>