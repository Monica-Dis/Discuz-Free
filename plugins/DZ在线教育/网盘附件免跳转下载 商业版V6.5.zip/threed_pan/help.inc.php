<?php
/**
 *	[����ѡ�(threed_tab.{modulename})] Copyright (c) 2021 by dism.taobao.com
 *	Version: ��ҵ��   http://t.cn/Aiux1Jx1
 *	Date: 2014-11-7 19:49
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://www.3dcader.com/thread-895-1-1.html";
</script>