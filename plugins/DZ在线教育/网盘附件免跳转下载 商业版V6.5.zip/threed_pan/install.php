<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_ADMINCP')) exit('Access Denied');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_threed_pan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `buy_uid` int(10) unsigned NOT NULL,
  `buy_tid` int(10) signed NOT NULL,
  `buy_info` varchar(1000) NOT NULL,
  `buy_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
$sql=str_replace("pre_threed_pan",DB::table('threed_pan'),$sql);
runquery($sql);
$data="<?php if(!defined('IN_ADMINCP')) exit('Access Denied');$finish = TRUE; ?>";
filedelate(DISCUZ_ROOT . './source/plugin/threed_pan/upgrade.php',$data);
filedelate(DISCUZ_ROOT . './source/plugin/threed_pan/install.php',$data);
function filedelate($filename,$data){
	if($fp=@fopen($filename,'wb')){
		fwrite($fp,$data);
		fclose($fp);
		return TRUE;
	}
	return FALSE;
}
//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>