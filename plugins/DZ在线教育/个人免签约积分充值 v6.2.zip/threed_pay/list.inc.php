<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$uid = $_G['uid'];
if(!$uid){
    showmessage(lang('plugin/threed_pay', 'p2'), array(), array(), array('alert' => 'error','login' => '1'));
}
$pay_option = $_G['cache']['plugin']['threed_pay'];
$pay_credit = $pay_option['pay_credit'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
$pay_supadmin = explode(",", $pay_option['pay_admin']);
if (empty($pay_supadmin))
    $pay_supadmin = array('1');
if (in_array($uid, $pay_supadmin)) {
    $adadmin = 1;
} else {
    $adadmin = 0;
}
require_once libfile('function/threed','plugin/threed_pay');
if (submitcheck('delad')) {
    if (!$adadmin) {
        showmessage(lang('plugin/threed_pay', 'p6'), array(), array(), array('alert' => 'error'));
    } else {
        $get = daddslashes($_GET);
        $delad = $get['delete'];
        
        $del = 0;
        foreach ($delad as $key => $delid) {
            $delid = intval($delid);
            DB::delete('threed_pay', "id=$delid");
            $del = $del + 1;
        }
            showmessage(lang('plugin/threed_pay', 'p10') . $del . lang('plugin/threed_pay', 'p11'), "plugin.php?id=threed_pay:list",
                array(), array(), array('alert' => 'right'));
        die();
    }
}

$page = intval($_G['page']);
if (empty($page))
    $page = 1;
$pagenum = 20;
$limit_start = $pagenum * ($page - 1);
if($adadmin){
    $where='uid>0';
}else{
    $where='uid='.$uid;
}
$url='';
$status=intval($_GET['s']);
if($status){
    $where.=' AND status='.$status;
    $url='&s='.$status;
}
$payway=array('',lang('plugin/threed_pay', 'p12'),lang('plugin/threed_pay', 'p13'),lang('plugin/threed_pay', 'p14'));
$statxt=array(lang('plugin/threed_pay', 'p15'),'<span class="span_hui">'.lang('plugin/threed_pay', 'p16').'</span>','<span class="span_blue">'.lang('plugin/threed_pay', 'p17').'</span>','<span class="span_red">'.lang('plugin/threed_pay', 'p18').'</span>');
$totalnum = DB::result_first("SELECT COUNT(*) FROM " . DB::table('threed_pay').' WHERE '.$where);
$list = array();
$all_uid=array();
$query = DB::query("SELECT * FROM " . DB::table('threed_pay') ." WHERE $where order By time DESC LIMIT $limit_start,$pagenum");
while ($row = DB::fetch($query)) {
    $row['date'] =$row['time']?date('Y-m-d H:i:s',$row['time']):0;
    $row['payway'] =$payway[$row['way']];
    $row['statxt'] =$statxt[$row['status']];
    $row['order']= dhtmlspecialchars($row['order']);
    $row['account']= dhtmlspecialchars($row['account']);
    $all_uid[]=$row['uid'];
    $list[$row['id']] = $row;
}
$list_usnm=array();
$query = DB::query("SELECT username,uid FROM " . DB::table('common_member') ." WHERE ".DB::field('uid', $all_uid));
while ($row = DB::fetch($query)) {
    $list_usnm[$row['uid']]=$row['username'];
}
$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=threed_pay:list$url");
$navtitle = lang('plugin/threed_pay', 'p19');
include template("threed_pay:list");

?>