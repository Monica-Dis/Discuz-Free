<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$uid = $_G['uid'];

if(!$uid){
    showmessage(lang('plugin/threed_pay', 'p2'), array(), array(), array('alert' => 'error','login' => '1'));
}
$pay_option = $_G['cache']['plugin']['threed_pay'];
$pay_bili=$pay_option['pay_bili']/100;
$pay_min=$pay_option['pay_min'];
$pay_credit = $pay_option['pay_credit'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
if (submitcheck('advsubmit')) {
    //echo "�������ύ2";
    $get = daddslashes($_GET);
    $creditnum=intval($_GET['creditnum']);
    $payway=intval($_GET['payway']);
    $paynum=intval($_GET['paynum']);
    if($paynum!=$creditnum/$pay_bili||$get['payaccount']==''){
        showmessage(lang('plugin/threed_pay', 'p3'), array(), array(), array('alert' => 'error','login' => '1'));
    }
$svaebuy = array(
        'uid' => $uid,
        'cdtnum'=>$creditnum,
        'paynum'=>$paynum,
        'way'=>$payway,
        'account'=>$get['payaccount'],
        'order'=>$get['payorder'],
        'status'=>1,
        'time'=>$_G['timestamp']
        );
    $saveok = DB::insert('threed_pay', $svaebuy, true, true);
    if ($saveok) {
        showmessage(lang('plugin/threed_pay', 'p4'), "plugin.php?id=threed_pay:list", array(), array(),
            array('alert' => 'right'));
    }else{
        showmessage(lang('plugin/threed_pay', 'p5'), "plugin.php?id=threed_pay:list", array(), array(),
            array('alert' => 'right'));
    }
    die();
}
$pay_option['pay_weixin']=$pay_option['pay_weixin']?$pay_option['pay_weixin']:'source/plugin/threed_pay/template/images/weixin_erm.jpg';
$pay_option['pay_aliimg']=$pay_option['pay_aliimg']?$pay_option['pay_aliimg']:'source/plugin/threed_pay/template/images/alipay_erm.jpg';
$pay_title = $pay_option['pay_title'];
$navtitle = $pay_title;
include template("threed_pay:index");
?>