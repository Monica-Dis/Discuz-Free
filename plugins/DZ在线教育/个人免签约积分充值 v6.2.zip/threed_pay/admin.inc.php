<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$uid = $_G['uid'];
if(!$uid){
    showmessage(lang('plugin/threed_pay', 'p2'), array(), array(), array('alert' => 'error','login' => '1'));
}
$pay_option = $_G['cache']['plugin']['threed_pay'];
$pay_credit = $pay_option['pay_credit'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
$pay_supadmin = explode(",", $pay_option['pay_admin']);
if (empty($pay_supadmin))
    $pay_supadmin = array('1');
if (in_array($uid, $pay_supadmin)) {
    $adadmin = 1;
} else {
    $adadmin = 0;
}

if (!$adadmin) {
    showmessage(lang('plugin/threed_pay', 'p6'), array(), array(), array('alert' => 'info'));
    die();
}
$pay_id=intval($_GET['p']);
//echo $pay_id;
$pay_ac = intval($_GET['ac']);
$pay_info=DB::fetch_first("SELECT id,cdtnum,uid FROM " . DB::table('threed_pay') .
        ' WHERE id=' . $pay_id);
if (($pay_ac==2||$pay_ac==3)&&$pay_info['id']) {
    $saveok = DB::update('threed_pay', array('status'=>$pay_ac),array('id'=>$pay_info['id']));
    if ($saveok) {
        if($pay_info['cdtnum']&&$pay_info['uid']&&$pay_ac==2){
            updatemembercount($pay_info['uid'],array('extcredits'.$pay_credit=>'+'.$pay_info['cdtnum']),true,'AFD',$pay_info['uid']);
            $note = '��ϲ���ĳ�ֵ�ѵ��ʣ�'.$kami;
                notification_add($pay_info['uid'], 'system', $note, array(), 1);
        }
        showmessage(lang('plugin/threed_pay', 'p7'), "plugin.php?id=threed_pay:list", array(), array(),
            array('alert' => 'right'));

    }else{
        showmessage(lang('plugin/threed_pay', 'p8'), array(), array(), array('alert' => 'error'));
        die();
    }
} else {
    showmessage(lang('plugin/threed_pay', 'p9'), array(), array(), array('alert' => 'error'));
    die();
}
//From: Dism��taobao��com
?>