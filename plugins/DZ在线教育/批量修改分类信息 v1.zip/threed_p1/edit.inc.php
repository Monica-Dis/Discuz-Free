<?php
/**
 *	[�����༭������Ϣ(threed_p1.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: V1
 *	Date: 2017-10-25 16:37
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_option_arr, $_G;
require_once libfile('function/threed','plugin/threed_p1');
$fid = intval($_GET['fid']);
$thd_user = unserialize($_G['cache']['plugin']['threed_p1']["thd_user"]);
$thd_forums = unserialize($_G['cache']['plugin']['threed_p1']["thd_forums"]);
$moderator =DB::result_first("SELECT uid FROM %t WHERE fid =%d AND uid=%u", array('forum_moderator',
                $fid,$_G['uid']));
if ((in_array($_G['groupid'], $thd_user)||($moderator&&$_G['cache']['plugin']['threed_p1']['thd_mod']))&&in_array($fid, $thd_forums)){
    }else{
     showmessage(lang('plugin/threed_p1', 'index1')); 
     exit();
    }
if (submitcheck('edit_submit')) {
    $sortid = $_GET['sortid'];
    //print_r($_GET);
} else {
    $tidlist = explode('_', $_GET['tid']);
    unset($tidlist[0]);
    if (empty($tidlist)) {
        showmessage(lang('plugin/threed_p1', 'index2'));
    }

    $tid_sortid_arr = array();
    $sid_arr = array();
    $sortid = 0;
    $query = DB::query("SELECT distinct tid,sortid FROM " . DB::table('forum_typeoptionvar') .
        " WHERE " . DB::field('tid', $tidlist) . " order By sortid DESC");
    $tidlist = array();
    while ($row = DB::fetch($query)) {
        if (!$sortid)
            $sortid = $row['sortid'];
        if ($sortid == $row['sortid'])
            $tidlist[] = $row['tid'];
    }
    
    $query = DB::query("SELECT tid,subject,tags FROM " . DB::table('forum_post') .
        " WHERE " . DB::field('tid', $tidlist) . " order By tid DESC");
    $tid_subject = array();
    $tid_tags=array();
    while ($row = DB::fetch($query)) {
        $tid_subject[$row['tid']]=$row['subject'];
        $tid_tags[$row['tid']]=tags_strtag($row['tags'],'str');
    }
}

if ($sortid) {
    require_once libfile('function/threadsort');
    threadsort_checkoption($sortid);
    loadcache(array(
        'threadsorts',
        'threadsort_option_' . $sortid,
        'threadsort_template_' . $sortid));

    if (submitcheck('edit_submit')) {
        //print_r($_G['cache']['threadsort_option_' . $sortid]);
        //$_GET = daddslashes($_GET);
        if(!empty($_GET['typeoption'])){
            
            if($_G['cache']['plugin']['threed_p1']['thd_tag']&&is_array($_GET['mytags'])){
                foreach($_GET['mytags'] as $mytid=>$tag){
                    DB::update('forum_post',array('tags'=>tags_strtag($tag,'sql')), array('tid'=>$mytid,'first'=>'1'));
                }
            }
            $save_arr=array();
            $tid_arr=array();
            foreach($_GET['typeoption'] as $tid_oid=>$tid_val){
                $tidoid=explode('_',$tid_oid);
                if($_G['cache']['threadsort_option_' . $sortid][$tidoid[1]]['required']&&empty($tid_val)){
                    showmessage(lang('plugin/threed_p1', 'index3'));
                }
                $save_arr[$tid_oid]['t']['sortid']=$sortid;
                $save_arr[$tid_oid]['t']['fid']=$fid;
                $save_arr[$tid_oid]['t']['tid']=intval($tidoid[0]);
                $save_arr[$tid_oid]['t']['optionid']=intval($tidoid[1]);
                if(!is_array($tid_val)){
                    $save_arr[$tid_oid]['v']['value']=daddslashes($tid_val);
                    }elseif($tid_val['url']){
                        //$tid_val=serialize($tid_val);
                        $save_arr[$tid_oid]['v']['value']=serialize($tid_val);
                    }else{
                        //$tid_val=serialize($tid_val);
                        $save_arr[$tid_oid]['v']['value']=implode("\t",$tid_val);
                    }
                //$tid_arr[]=$tidoid[0];
            }
            //print_r($save_arr);
            foreach($save_arr as $tid_oid=>$data){
                DB::update('forum_typeoptionvar',$data[v], $data[t]);
            }
            showmessage(lang('plugin/threed_p1', 'index4'), 'forum.php?mod=forumdisplay&fid='.$fid, array(), array(),
            array(
            'alert' => 'right',
            'showdialog' => 1,
            'locationtime' => false));
            
        }else{
            showmessage(lang('plugin/threed_p1', 'index5'));
        }
    } else {
        $forum_optionlist = getsortedoptionlist_3d($_G['cache']['threadsort_option_' . $sortid]);
        foreach ($tidlist as $key => $tid) {
            threadsort_optiondata_3d($tid, $sortid, $_G['cache']['threadsort_option_' . $sortid]);
        }
        //print_r($_option_arr);
        include template("threed_p1:edit");
    }
} else {
    showmessage(lang('plugin/threed_p1', 'index6'));

}