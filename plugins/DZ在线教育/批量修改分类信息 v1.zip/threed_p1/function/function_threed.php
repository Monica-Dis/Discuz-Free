<?php

/**
 *	[3D�����ר�ú�����(threed_function.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('');
}

function make_request($url, $params, $timeout = 30)
{
    set_time_limit(0);
    $str = "";
    if ($params != "") {
        foreach ($params as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $kv => $vv) {
                    $str .= '&' . $k . '[' . $kv . ']=' . urlencode($vv);
                }
            } else {
                $str .= '&' . $k . '=' . urlencode($v);
            }
        }
    }
    if (function_exists('curl_init')) {
        // Use CURL if installed...
        $ch = curl_init();
        $header = array(
            'Accept-Language: zh-cn',
            'Connection: Keep-Alive',
            'Cache-Control: no-cache');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if ($timeout > 0)
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $result = curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        return $result;
    } else {
        $context = array('http' => array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded' . "\r\n" .
                    'Content-length: ' . strlen($str),
                'content' => $str));
        if ($timeout > 0)
            $context['http']['timeout'] = $timeout;
        $contextid = stream_context_create($context);
        $sock = @fopen($url, 'r', false, $contextid);
        if ($sock) {
            $result = '';
            while (!feof($sock)) {
                $result .= fgets($sock, 8192);
            }
            fclose($sock);
        } else {
            return 'TimeOut';
        }
    }
    return $result;
}

function tags_strtag($tags,$type){
    if($type=='str'){
    $tagarray_all = explode("\t", $tags);
		if($tagarray_all) {
			foreach($tagarray_all as $var) {
				if($var) {
					$array_temp = explode(',', $var);
					$threadtag_array[] = $array_temp['1'];
				}
			}
		}
		$tags = implode(',', $threadtag_array);
        return $tags;
}else{
  $tagarray_all = explode(',', $tags);
  $tags=array();
  if($tagarray_all) {
			foreach($tagarray_all as $key=>$var) {
			 $abc=$key+1;
			 if($var) {
			     $tags[]=$abc.','.$var;
			 }
    }
}
$tags = implode("\t", $tags);
return $tags;
}
}

function threadsort_optiondata_3d($tid, $sortid, $sortoptionarray)
{
    global $_option_arr;
    $forum_optiondata = array();
    $forum_optionlist = $sortoptionarray;
    if ($tid) {
        foreach (C::t('forum_typeoptionvar')->fetch_all_by_tid_optionid($tid) as $option) {
            $forum_optiondata[$option['optionid']] = $option['value'];
            $forum_optiondata['expiration'] = $option['expiration'];
        }
    }

    $forum_optiondata['expiration'] = $forum_optiondata['expiration'] ? dgmdate($forum_optiondata['expiration'],
        'd') : '';

    foreach ($sortoptionarray as $optionid => $option) {
        if ($tid) {
            $forum_optionlist[$optionid]['unchangeable'] = $sortoptionarray[$optionid]['unchangeable'] ?
                'disabled' : '';
            if ($sortoptionarray[$optionid]['type'] == 'radio') {
                $forum_optionlist[$optionid]['value'] = array($forum_optiondata[$optionid] =>
                        'checked="checked"');
            } elseif ($sortoptionarray[$optionid]['type'] == 'select') {
                $forum_optionlist[$optionid]['value'] = $forum_optiondata[$optionid] ? array($forum_optiondata[$optionid] =>
                        'selected="selected"') : '';
            } elseif ($sortoptionarray[$optionid]['type'] == 'checkbox') {
                foreach (explode("\t", $forum_optiondata[$optionid]) as $value) {
                    $forum_optionlist[$optionid]['value'][$value] = array($value =>
                            'checked="checked"');
                }
            } elseif ($sortoptionarray[$optionid]['type'] == 'image') {
                $forum_optionlist[$optionid]['value'] = dunserialize($forum_optiondata[$optionid]);
            } else {
                $forum_optionlist[$optionid]['value'] = $forum_optiondata[$optionid];
            }
            if (!isset($forum_optiondata[$optionid])) {
                C::t('forum_typeoptionvar')->insert(array(
                    'sortid' => $sortid,
                    'tid' => $tid,
                    'fid' => $_G['fid'],
                    'optionid' => $optionid,
                    ));
            }
        }
    }
    $_option_arr[$tid]['forum_optionlist'] = $forum_optionlist;
    $_option_arr[$tid]['forum_optiondata'] = $forum_optiondata;

}
function getsortedoptionlist_3d($forum_optionlist)
{
    global $_G;
    foreach ($forum_optionlist as $key => $value) {
        $choicesarr = $value['choices'];
        uksort($choicesarr, 'cmpchoicekey');
        $forum_optionlist[$key]['choices'] = $choicesarr;
    }
    $forum_optionlist = optionlistxml($forum_optionlist, 's');
    $forum_optionlist = '<?xml version="1.0" encoding="' . CHARSET . '"?>' . "" .
        '<forum_optionlist>' . $forum_optionlist . '</forum_optionlist>';
    return $forum_optionlist;
}