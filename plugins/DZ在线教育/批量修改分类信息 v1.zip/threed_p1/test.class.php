<?php
/**
 *	[�����༭������Ϣ(threed_p1.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: V1
 *	Date: 2017-10-25 16:37
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_threed_p1
{
  
}
class plugin_threed_p1_forum extends plugin_threed_p1
{
    function forumdisplay_modlayer(){
        global $_G;
        $fid=$_G['fid'];
        $thd_user = unserialize($_G['cache']['plugin']['threed_p1']["thd_user"]);
$thd_forums = unserialize($_G['cache']['plugin']['threed_p1']["thd_forums"]);
$moderator = DB::result_first("SELECT uid FROM %t WHERE fid =%d AND uid=%u", array('forum_moderator',
                $fid,$_G['uid']));
if ((in_array($_G['groupid'], $thd_user)||($moderator&&$_G['cache']['plugin']['threed_p1']['thd_mod']))&&in_array($fid, $thd_forums)){
    include template("threed_p1:forum");
        return $return;
    }else{
     return;   
    }
        }

}