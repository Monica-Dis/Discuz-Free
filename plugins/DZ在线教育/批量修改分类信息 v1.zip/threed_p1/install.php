<?php
/**
 *	[�����༭������Ϣ(threed_p1.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: V1
 *	Date: 2017-10-25 16:37
 */
if (!defined('IN_ADMINCP')||!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$data="<?php exit('Access Denied');?>";
filedelate(DISCUZ_ROOT . './source/plugin/threed_p1/upgrade.php',$data);
filedelate(DISCUZ_ROOT . './source/plugin/threed_p1/install.php',$data);
function filedelate($filename,$data){
	if($fp=@fopen($filename,'wb')){
		fwrite($fp,$data);
		fclose($fp);
		return TRUE;
	}
	return FALSE;
}
//DEFAULT CHARSET=gbk;
$finish = TRUE;