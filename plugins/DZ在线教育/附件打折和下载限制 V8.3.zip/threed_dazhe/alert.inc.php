<?php
/**
 *	[�������ۺ���������(threed_dazhe.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2015-5-18 12:12
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
if ($_GET['ac'] == "nodown") {
    showmessage(lang('plugin/threed_dazhe', 'index2').$_GET['pannum'].lang('plugin/threed_dazhe', 'index1'),array(), array(), array('alert' => 'error'));
    };
if ($_GET['ac'] == "noaccess") {
    showmessage($_G['cache']['plugin']['threed_dazhe']['thd_power'], array(), array(), array('alert' => 'error','login'=>1));
}
//TODO - http://t.cn/Aiux1Qh0

?>