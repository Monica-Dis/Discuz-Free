<?php
/**
 *	[����αװ�ɱ��ظ���(threed_attach.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2015-5-18 12:12 
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
//if($_GET['formhash']!=FORMHASH)exit();
$uid = $_G['uid'];

if($_GET['ac']=="add"){
    $pan_url = addslashes(trim($_GET['url']));
    $pan_name=addslashes(trim($_GET['name']));
    $pan_price=addslashes(trim($_GET['price']));
    $pan_size=addslashes(trim($_GET['size']))*1024;
    $tid = intval($_GET['tid']);
    if (!empty($pan_name)) {
        $attach_setting = array('uid' => $uid, 'tableid' => 127);
        $aid = DB::insert("forum_attachment", $attach_setting, true);
        $attach_unused = array(
        'aid' => $aid,
        'uid' => $uid,
        'dateline' => time(),
        'filename' => $pan_name.".pan",
        'filesize' => $pan_size, //Ĭ��Ϊ1000
        'attachment' => $pan_url
      );
    $unused_result = DB::insert("forum_attachment_unused", $attach_unused, true);
      $_G['attachnew'][$aid] = array(
      'description' => $pan_name,        
      'readperm' => $_GET['readaccess'],
      'filesize' => $pan_size,
      'price' => $pan_price);
    }
	if(is_int($aid))echo $aid;
exit();
}
if($_GET['ac']=="update"){
    $pan_url = addslashes(trim($_GET['url']));
    $pan_name=addslashes(trim($_GET['name']));
    $pan_size=addslashes(trim($_GET['size']))*1024;
    $aid=intval($_GET['aid']);
    if (!empty($pan_name)) {
        $tableid=DB::result_first('SELECT tableid FROM '.DB::table('forum_attachment').' WHERE aid='.$aid);
        if($tableid==127)$tableid='unused';
        $attach_unused = array(
        'filename' => $pan_name.".pan",
        'attachment' => $pan_url,
        'filesize' => $pan_size //Ĭ��Ϊ1000
      );
    $unused_result = DB::update('forum_attachment_'.$tableid, $attach_unused,array('aid'=>$aid));
    //DB::query('update '.DB::table('forum_attachment_'.$tableid).' set filename='.$pan_name.'pan attachment='.$pan_url.' where aid='.$aid);
    //  $_G['attachnew'][$aid] = array(
    //  'description' => $pan_name);
    }
	echo $aid;
exit();
}
//From: Dism��taobao��com
?>