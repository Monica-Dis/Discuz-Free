<?php

/**
 *	[���ֹ�����Ƶ�̳�(threed_ckplayer.{modulename})] Ӧ�ø���֧�֣�https://dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('');
}

function make_request($url, $params , $timeout =30){
    set_time_limit(0);
    $str="";
    if($params!="")
    {
        foreach ($params as $k=>$v) {
                    if (is_array($v)) {
                            foreach ($v as $kv => $vv) {
                                    $str .= '&' . $k . '[' . $kv  . ']=' . urlencode($vv);
                            }
                    } else {
                            $str .= '&' . $k . '=' . urlencode($v);
                    }
            }
    }
        if (function_exists('curl_init')) {
                // Use CURL if installed...
                $ch = curl_init();
                $header=array(
                        'Accept-Language: zh-cn',
                        'Connection: Keep-Alive',
                        'Cache-Control: no-cache'
                );
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
                if($timeout > 0)curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
                $result = curl_exec($ch);
                $errno = curl_errno($ch);
                curl_close($ch);
                return $result;
        } else {
                $context = array(
                        'http' => array(
                                'method' => 'POST',
                                'header' => 'Content-type: application/x-www-form-urlencoded'."\r\n".
                                'Content-length: ' . strlen($str),
                                'content' => $str));
                if($timeout > 0)$context['http']['timeout'] = $timeout;
                $contextid = stream_context_create($context);
                $sock = @fopen($url, 'r', false, $contextid);
                if ($sock) {
                        $result = '';
                        while (!feof($sock)) {
                              $result .= fgets($sock, 8192);
                        }
                        fclose($sock);
                }
                else{
                                return 'TimeOut';
                }
        }
        return $result;
}
//From: Dism_taobao-com
?>