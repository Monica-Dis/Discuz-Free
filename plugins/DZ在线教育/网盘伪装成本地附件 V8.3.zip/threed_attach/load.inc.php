<?php
/**
 *	[����αװ�ɱ��ظ���(threed_attach.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2015-5-18 12:12
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$tid=$_GET['tid'];
require_once libfile('function/threed','plugin/threed_attach');
include template('threed_attach:add');
//TODO - http://t.cn/Aiux1Qh0
?>