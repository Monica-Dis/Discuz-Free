<?php
/**
 *	[����αװ�ɱ��ظ���(threed_attach.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2015-5-18 12:12
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
    $aid=intval($_GET['aid']);
    //echo($aid);
    $tableid=DB::result_first('SELECT tableid FROM '.DB::table('forum_attachment').' WHERE aid='.$aid);
    if($tableid==127)$tableid='unused';
    //echo $tableid;
    $edit_arr=DB::fetch(DB::query('SELECT filename,attachment,filesize FROM '.DB::table('forum_attachment_'.$tableid).' WHERE aid='.$aid));
    //print_r($edit_arr);
    $edit_arr['filename']=chop($edit_arr['filename'],'.pan');
    $edit_arr['size']=$edit_arr['filesize']/1024;
    include template('threed_attach:edit');

//TODO - http://t.cn/Aiux1Qh0
?>