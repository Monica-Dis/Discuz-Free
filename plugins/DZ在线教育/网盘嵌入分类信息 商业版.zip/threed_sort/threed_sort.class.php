<?php
/**
 *	[�������⸽��--����ת����(threed_sort.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_threed_sort
{
    //TODO - Insert your code here
    function discuzcode($value)
    {
    global $_G, $threadsortshow;
        $sort_option = $_G['cache']['plugin']['threed_sort'];
        $sort_forums = unserialize($sort_option["thd_forum"]);
        $pid = $value[param][12];
        if ($value[caller] == "discuzcode" && $value[param][15] && in_array($_G['fid'],
            $sort_forums)) {
            $sort_auth = $value[param][10];
            $sort_user = unserialize($sort_option["thd_user"]);
            $sort_buyuser = unserialize($sort_option["thd_buyuser"]);
            $sort_tiao = $sort_option["thd_tiao"];
            $sort_info = $sort_option["thd_info"];
            $sort_ext = $sort_option["thd_ext"];
            $sort_replay = $sort_option["thd_replay"];
            $sort_power = $sort_option["thd_power"];
            $sort_price = $threadsortshow[optionlist][thd_price][value];
            $sort_ext_name = $_G['setting']['extcredits'][$sort_ext]['title'];
            $threadsortshow['optionlist']['thd_img']['value'] = $threadsortshow['optionlist']['thd_img']['value'] !=
                "" ? $threadsortshow['optionlist']['thd_img']['value'] : $this->getimgbypid($pid);
                //echo $threadsortshow['optionlist']['thd_img']['value'] ;
            $type_msg = $threadsortshow[typetemplate];
            $sort_url = $threadsortshow[optionlist][thd_vip][value];
            $sort_url2 = $threadsortshow[optionlist][thd_vip2][value];
            $sort_putong_url = $threadsortshow[optionlist][thd_putong][value];
            $sort_type = 0;
            $down_a = '';
            $buycount = DB::result_first('SELECT count(1) FROM ' . DB::table('threed_sort') .
                ' WHERE buy_tid=' . $_G[tid] . ' and buy_uid = ' . $_G['uid']);
            $allcount = DB::result_first('SELECT count(1) FROM ' . DB::table('threed_sort') .
                ' WHERE buy_tid=' . $_G[tid]);
            if (in_array($_G[groupid], $sort_user) || $sort_auth == $_G['uid'] || $buycount >
                0 || !$sort_price) {
                $sort_url = base64_encode($sort_url);
                $sort_url = 'plugin.php?id=threed_sort:downld&tid=' . $_G['tid'] . '&formhash=' .
                    FORMHASH;
                $ifbuy = 1;
                $down_a = '<a href="' . $sort_url . '" class="btnBuy2 htevent" target="_blank">' .
                    $threadsortshow[optionlist][thd_vip][title] . '</a>';
                if ($sort_url2) {
                    $down_a .= '<a href="' . $sort_url2 .
                        '" class="btnBuy2 htevent" target="_blank" style="background: #48C;">' .
                        $threadsortshow[optionlist][thd_vip2][title] . '</a>';
                }
            } else {
                $sort_srlgg = ($sort_price + 3) * 91 + 131; //�򵥼���
                //echo $sort_price;
                $sort_url = 'plugin.php?id=threed_sort:payfor&ac=buy&tid=' . $_G['tid'] . '&gg=' .
                    $sort_srlgg . '&formhash=' . FORMHASH;
                $ifbuy = 0;
                $down_a = '<a href="javascript:" onclick="showWindow(\'paybox\', \'' . $sort_url .
                    '\')" rel="nofollow" class="btnBuy2 htevent" target="_blank">��������</a>';
            }
            if ($sort_putong_url) {
                if (in_array($_G[groupid], $sort_buyuser)) {
                    $down_a .= '<a href="' . $sort_putong_url .
                        '"  target="_blank" style="font-size:14px;">' . $threadsortshow[optionlist][thd_putong][title] .
                        '</a>';
                } else {
                    $down_a .= '<a href="javascript:;" onclick="alert(\'' . $sort_power . '\');" target="_blank" style="font-size:14px;">' .
                        $threadsortshow[optionlist][thd_putong][title] . '</a>';
                }
            }
            $type_msg = str_replace("{threed_sort_img}", $threadsortshow['optionlist']['thd_img']['value'],
                $type_msg);
            $type_msg = str_replace("{threed_sort_downnum}",  $buycount, $type_msg);
            $type_msg = str_replace("{threed_sort_ext}", $sort_ext_name, $type_msg);
            $type_msg = str_replace("{threed_sort_info}", $sort_info, $type_msg);
            $type_msg = str_replace("{threed_sort_downld}", $down_a, $type_msg);


            //���濪ʼ�����ظ��ɼ�
            $sort_replay = $sort_option['thd_replay'];
            $postcount = DB::result_first('SELECT count(1) FROM ' . DB::table('forum_post') .
                ' WHERE tid=' . $_G[tid] . ' and authorid = ' . $_G['uid']);
            $reply_message = array();
            $reply_arr = explode("[hide]", $type_msg);
            if (count($reply_arr) > 1) {
                $n = 0;
                foreach ($reply_arr as $key => $reply_arrstr) {
                    if ($n) {
                        $tmp_arr = explode("[/hide]", $reply_arrstr);
                        //echo $tmp_arr[0];
                        array_push($reply_message, $tmp_arr[0]);
                    }
                    $n++;
                }
            }
            //echo $postcount;
            //print_r($reply_message);
            if ((in_array($_G['groupid'], $sort_user) && $sort_replay) || $sort_auth == $_G['uid'] ||
                $postcount != 0) { //�����ɼ��û��飬���ߣ��ѻظ�
                $type_msg = str_replace("[hide]", "", $type_msg);
                $type_msg = str_replace("[/hide]", "", $type_msg);
            } else {
                //$pd_tips=str_replace("{postcount_set}",$postcount_set+1,$it618_postdisplay['pd_tips']);
                $replace = '<a href="forum.php?mod=post&amp;action=reply&amp;fid=' . $_G['fid'] .
                    '&amp;tid=' . $_G['tid'] . '">' . $sort_option['thd_repinfo'] . '</a>';
                foreach ($reply_message as $key => $reply_arrstr) {
                    $type_msg = str_replace("[hide]" . $reply_arrstr . "[/hide]", $replace, $type_msg);
                }
            }
            $threadsortshow[typetemplate] = $type_msg;

        }

    }

    public function getimgbypid($pid)
    { //��ȡ��ǰ���ӵĵ�һ�������ĸ�����Ϣ
     global $_G;
        $pid = intval($pid);
        $nopic = 'source/plugin/threed_sort/template/nologo.jpg'; //ȱʡͼƬ
        $tableid = DB::result_first("SELECT tableid FROM " . DB::table('forum_attachment') .
            " WHERE pid='$pid' LIMIT 1");
        if (!$tableid)
            return $nopic;
        $tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
        $table = "forum_attachment_" . $tableid;
        $sql = "SELECT * FROM " . DB::table($table) . " WHERE pid=" . $pid .
            " and isimage=1 ORDER BY aid asc ";
        $attach = DB::fetch_first($sql);
        if ($attach) {
            $attachurl = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
            $attachfile = $attachurl . "/forum/" . $attach['attachment'];
            return $attachfile;
        } else {
            return $nopic;
        }

    }
}


?>