<?php

if(!defined('IN_DISCUZ')|| !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;

loadcache('plugin');
loadcache('pluginlanguage_template');
loadcache('pluginlanguage_script');

$ppp = 20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$deletes = '';
$extrasql = '';

$hosturl=ADMINSCRIPT."?action=";
$identifier = $_GET['identifier'];
$urls = '&pmod=admin&identifier='.$identifier.'&operation='.$operation.'&do='.$do;
define(TOOLS_ROOT, dirname(__FILE__).'/');

if(submitcheck('pansubmit')){
	$del=0;
	foreach($_GET['delete'] as $key => $delid) {
		$delid=intval($delid);
		//DB::delete('threed_sort', "id=$delid");
		DB::delete('threed_sort', "id=$delid");
		$del=$del+1;
	}
	cpmsg(lang('plugin/threed_sort', 'admin1').$del, "action=plugins&cp=admin_buysum&pmod=admin&operation=$operation&do=$do&page=$page", 'succeed');
}

showformheader("plugins&cp=admin_buysum&pmod=admin&operation=$operation&do=$do");
showtableheaders(lang('plugin/threed_sort', 'admin2'));

	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('threed_sort')." w WHERE 1 ");
	$multipage = multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&cp=admin_buysum&pmod=admin&operation=$operation&do=$do");
	
	showtableheader();
	showtablerow('', array('class="td25"', '', '', '', 'class="td25"', 'class="td28"'), array('', lang('plugin/threed_sort', 'admin3'),lang('plugin/threed_sort', 'admin4'),lang('plugin/threed_sort', 'admin5'),lang('plugin/threed_sort', 'admin6'),lang('plugin/threed_sort', 'admin7')));

	$query = DB::query("SELECT * FROM ".DB::table('threed_sort')." WHERE 1 LIMIT $startlimit, $ppp");
	while($threed_sort_t = DB::fetch($query)) {
		
		
			$threed_sort_td2='<a href="forum.php?mod=viewthread&tid='.$threed_sort_t['buy_tid'].'" target="_blank">'.threed_sort_subject($threed_sort_t['buy_tid']).'</a>';
		
			$threed_sort_td3='<a href="home.php?mod=space&uid='.threed_sort_buysaleid($threed_sort_t['buy_tid']).'" target="_blank">'.threed_sort_getusername(threed_sort_buysaleid($threed_sort_t['buy_tid'])).'</a>';
			$threed_sort_td5='<a href="home.php?mod=space&uid='.$threed_sort_t['buy_uid'].'" target="_blank">'.threed_sort_getusername($threed_sort_t['buy_uid']).'</a>';
		
		
		showtablerow('', array('class="td25"', '', '', '', 'class="td25"', 'class="td28"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$threed_sort_t[id]\"><input type=\"hidden\" name=\"id[$threed_sort_t[id]]\" value=\"$threed_sort[id]\">",
			$threed_sort_td2,
			$threed_sort_td3,
			$threed_sort_t['buy_info'],
			$threed_sort_td5,
			date('Y-m-d H:i:s', $threed_sort_t['buy_time']),
		));
	}
	
	function threed_sort_subject($tid){
	   if($reject=DB::result_first("select subject from ".DB::table('forum_post')." where tid=".$tid)){
	       return $reject;
        }else{
             return lang('plugin/threed_sort', 'admin8');
        }
	}
	
	function threed_sort_buysaleid($tid){
	   if(!$tid){
	        return lang('plugin/threed_sort', 'admin9');
	   }else{
		return DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=".$tid);
        }
		
	}
	
	function threed_sort_getusername($uid){
	   if(!$uid){
	        return lang('plugin/threed_sort', 'admin9');
	   }else{
		return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
        }
	}
	
	function showtableheaders($title = '', $classname = '', $extra = '', $titlespan = 15) {
	global $_G;
	$classname = str_replace(array('nobottom', 'notop'), array('nobdb', 'nobdt'), $classname);
	if(isset($_G['showsetting_multi'])) {
		if($_G['showsetting_multi'] == 0) {
			$extra .= ' style="width:'.($_G['showsetting_multicount'] * 270 + 20).'px"';
		} else {
			return;
		}
	}
	echo "\n".'<table class="tb tb2 '.$classname.'"'.($extra ? " $extra" : '').' style="clear: both;margin-top: 5px;width: 100%">';
	if($title) {
		$span = $titlespan ? 'colspan="'.$titlespan.'"' : '';
		echo "\n".'<tr><th '.$span.' class="partition">'.cplang($title).'</th></tr>';
		showmultititle(1);
	}
}
	
	showsubmit('pansubmit', 'submit', 'del', "<input type=hidden value=$page name=page />", $multipage);
	showtablefooter();
showformfooter();/*Dism_taobao-com*/
?>