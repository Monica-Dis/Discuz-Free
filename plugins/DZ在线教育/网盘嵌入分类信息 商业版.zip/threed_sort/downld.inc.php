<?php
/**
 *	[�������⸽��--����ת����(threed_sort.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$tid=intval($_GET['tid']);
$sort_user=unserialize($_G['cache']['plugin']['threed_sort']["thd_user"]);
$sort_buyuser=unserialize($_G['cache']['plugin']['threed_sort']["thd_buyuser"]);
if(!in_array($_G['groupid'], $sort_buyuser)) showmessage($_G['cache']['plugin']['threed_sort']['thd_power'], '', array(), array('alert' => 'info'));

$sort_srl=DB::result_first("SELECT a.value FROM " . DB::table('forum_typeoptionvar') . " a LEFT JOIN " . DB::table('forum_typeoption') ." t ON a.optionid=t.optionid WHERE t.identifier='thd_vip' AND a.tid='$tid'");
$sort_price=DB::result_first("SELECT a.value FROM " . DB::table('forum_typeoptionvar') . " a LEFT JOIN " . DB::table('forum_typeoption') ." t ON a.optionid=t.optionid WHERE t.identifier='thd_price' AND a.tid='$tid'");
$sort_pswd=DB::result_first("SELECT a.value FROM " . DB::table('forum_typeoptionvar') . " a LEFT JOIN " . DB::table('forum_typeoption') ." t ON a.optionid=t.optionid WHERE t.identifier='thd_pswd' AND a.tid='$tid'");
if($sort_pswd){
    $sort_srlname=lang('plugin/threed_sort', 'downld11').$sort_pswd;
}else{
    $sort_srlname=DB::result_first("SELECT subject FROM " .DB::table('forum_thread') . " WHERE tid=$tid AND displayorder>=0");
}
$buy_credit =$_G['cache']['plugin']['threed_sort']["thd_ext"];
//$aid=$_GET['aid'];
if(!$_G['cache']['plugin']['threed_sort']['thd_tiao']){
    //DB::query('update '.DB::table('forum_attachment').' set downloads=downloads+1 where aid='.$aid);
    header("location:{$sort_srl}");
	die();
}
if(substr($sort_srl,0,20)=='http://pan.baidu.com'){					
    $sort_type=1;
}elseif(substr($sort_srl,0,23)=='http://share.weiyun.com'){
    $sort_type=2;
}elseif(substr($sort_srl,0,16)=='http://yunpan.cn'){
    $sort_type=3;
}else {
    $sort_type=0;
}
$buycount=DB::result_first('SELECT count(1) FROM '.DB::table('threed_sort').' WHERE buy_tid='.$tid.' and buy_uid = '.$_G['uid']);
$sort_kofen=$_G['cache']['plugin']['threed_sort']['thd_koufen'];
$sort_auth=DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=".$tid);
$navtitle =$sort_srlname.lang('plugin/threed_sort', 'downld1');
$panbox_w=array(0,700,700,700,700,700,700,700);//���ؿ�ĳ���
$panbox_h=array(0,390,420,400,240,400,400,400);//���ؿ�ĸ߶�
$panbox_x=array(0,-30,-5,-130,-30,-30,-20,-20);//X����ƫ�ƾ���
$panbox_y=array(0,-80,-55,-130,-40,-80,-80,-80);//Y����ƫ�ƾ���
$iframe_w=$panbox_w[$sort_type]-$panbox_x[$sort_type];
$iframe_h=$panbox_h[$sort_type]-$panbox_y[$sort_type];

if($_GET['formhash']!=FORMHASH)showmessage(lang('plugin/threed_sort', 'downld2'),  array(), array(), array('alert' => 'error'));
if((!in_array($_G[groupid], $sort_user))&&$sort_kofen&&$buycount==0&&$sort_auth!=$_G['uid']){//������ǳ����û�������ѣ�δ���򣬲�������
	   $user_creditnum=DB::result_first("select extcredits".$buy_credit." from ".DB::table('common_member_count')." where uid=".$_G['uid']);
	   if($user_creditnum<$sort_kofen){
	       showmessage($_G['cache']['plugin']['threed_sort']['thd_credit'],  array(), array(), array('alert' => 'info'));
	       }
	   $buy_creditname = $_G['setting']['extcredits'][$buy_credit]['title'];
		$svaebuy = array(
			'buy_uid' => $_G['uid'],
			'buy_tid' => $tid,
			'buy_info' => lang('plugin/threed_sort', 'downld10').$sort_kofen.$buy_creditname,
			'buy_time' => $_G['timestamp']
		);
		$id = C::t('#threed_sort#threed_sort')->insert($svaebuy, true);
		if($id){
	           DB::query('update '.DB::table('common_member_count').' set extcredits'.$buy_credit.'=extcredits'.$buy_credit.'-'.$sort_kofen.' where uid='.$_G['uid']);
	           $kofen_info =$buy_creditname.'-'.$sort_kofen;			
	           $kofen_info.=','.$_G['cache']['plugin']['threed_sort']['thd_downld'];
		}else{
			showmessage(lang('plugin/threed_sort', 'downld2'),  array(), array(), array('alert' => 'error'));
		}
    }else{
        $daytimenow=$_G['timestamp'];
        $daytimeup=$_G['timestamp']+43200;
        $daytimedown=$_G['timestamp']-43200;
        $daydownnum=DB::result_first('SELECT count(1) FROM '.DB::table('threed_sort').' WHERE buy_uid = '.$_G['uid']. ' and buy_time between '.$daytimedown.' and '.$daytimeup );
        if(in_array($_G[groupid], $sort_user)&&$sort_price){
            if($daydownnum<$_G['cache']['plugin']['threed_sort']['thd_downnum']){
            if(!$buycount){
                $svaebuy = array(
			     'buy_uid' => $_G['uid'],
			     'buy_tid' => $tid,
                 'buy_info' => lang('plugin/threed_sort', 'downld12'),
			     'buy_time' => $_G['timestamp']
		          );
		          $id = C::t('#threed_sort#threed_sort')->insert($svaebuy, true);
                }
        }else{
            showmessage(lang('plugin/threed_sort', 'downld13'),  array(), array(), array('alert' => 'error'));
        } 
        }
	     $kofen_info=$_G['cache']['plugin']['threed_sort']['thd_downld'];  
    }
    include template('diy:downld', 0, 'source/plugin/threed_sort/template');

//TODO - Insert your code here
?>