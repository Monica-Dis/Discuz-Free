var jq = jQuery.noConflict();
jq(function() {
        var smallWrap = jq('.picsmall'),
            smallItem = smallWrap.children('li'),
            len = smallItem.length,
            maxStep = len - 6,
            smallWidth = 150 * len,
            cenpos = smallWidth / 2 - 75,
            smallScl = jq('.ad-thumbs'),
            maxMove = smallWidth - jq('.ad-thumbs').width();;
        bigWrap = jq('#slide_big .list'), titleWrap = jq('#slide_title');
        smallWrap.width(smallWidth);
        var scroll = {
                index: 0,
                time: 0,
                init: function() {
                        var pic = [],
                            title = [];
                        smallItem.each(function(i) {
                                if (i > 0) {
                                        var a = jq(this).children('a'),
                                            img = a.attr('href'),
                                            bt = a.children('img').attr('title');
                                        pic.push('<div class="ad-big-item"><img src="" data-src="' + img + '" /><a class="big mdicon" href="' + img + '" target="_blank"></a></div>');
                                        title.push('<p>' + bt + '</p>');
                                }
                        })
                        bigWrap.append(pic.join(""));
                        titleWrap.append(title.join(""));
                        this.smallCK();
                        this.keyDown();
                        this.btnChange();
                        smallItem.eq(0).click();
                        jq('.ad-back').addClass('disabled');
                        if (len <= 6) {
                                jq('.ad-forward').addClass('disabled');
                        } else {
                                this.smallScroll();
                        }
                },
                smallCK: function() {
                        var s = this;
                        smallItem.click(function(e) {
                                e.preventDefault();
                                var a = jq(this);
                                if (!a.hasClass('ad-active')) {
                                        s.index = a.index();
                                        s.to();
                                }
                        })
                },
                next: function() {
                        if (++this.index >= len) {
                                this.index = 0;
                        }
                        this.to();
                },
                prev: function() {
                        if (--this.index < 0) {
                                this.index = len - 1;
                        }
                        this.to();
                },
                to: function(no) {
                        if (no != undefined && no < 0 && no > len - 1) {
                                this.index = no;
                        }
                        smallItem.eq(this.index).addClass('ad-active').siblings().removeClass('ad-active');
                        var item = jq('.ad-big-item').eq(this.index);
                        item.fadeIn().siblings('.ad-big-item').stop().fadeOut(100);
                        titleWrap.children('p').eq(this.index).stop().fadeIn(100).siblings().stop().fadeOut(100);
                        var img = item.find('img');
                        if (img.attr('src') == '') {
                                img.attr('src', img.attr('data-src'));
                        }
                        if (len > 6) {
                                this.setCenter();
                        }
                },
                nextGroup: function() {
                        var scl = smallScl.scrollLeft(),
                            move = scl + 150 * 5;
                        smallScl.animate({
                                'scrollLeft': move + 'px'
                        }, 300)
                        jq('.ad-back').removeClass('disabled');
                        if (move >= maxMove) {
                                move = maxMove;
                                jq('.ad-forward').addClass('disabled');
                        }
                },
                prevGroup: function() {
                        var scl = smallScl.scrollLeft(),
                            move = scl - 150 * 5;
                        smallScl.animate({
                                'scrollLeft': move + 'px'
                        }, 300)
                        jq('.ad-forward').removeClass('disabled');
                        if (move <= 0) {
                                move = 0;
                                jq('.ad-back').addClass('disabled');
                        }
                },
                setCenter: function() {
                        var i = this.index;
                        c = i - 1;
                        if (c > 0) {
                                jq('.ad-back').removeClass('disabled');
                        } else {
                                jq('.ad-back').addClass('disabled');
                        }
                        if (c + 6 >= len) {
                                jq('.ad-forward').addClass('disabled');
                        } else {
                                jq('.ad-forward').removeClass('disabled');
                        }
                        smallScl.animate({
                                'scrollLeft': 150 * c + 'px'
                        }, 300)
                },
                keyDown: function() {
                        var s = this;
                        jq(window).keydown(function(e) {
                                var keyCode = e.keyCode;
                                if (s.time == 0) {
                                        if (keyCode == 37) {
                                                s.prev();
                                        } else if (keyCode == 39) {
                                                s.next();
                                        }
                                        s.time = setInterval(function() {
                                                if (keyCode == 37) {
                                                        s.prev();
                                                } else if (keyCode == 39) {
                                                        s.next();
                                                }
                                        }, 1000);
                                }
                        });
                        s.keyUp();
                },
                keyUp: function() {
                        var s = this;
                        jq(window).keyup(function(e) {
                                clearTimeout(s.time);
                                s.time = 0;
                        })
                },
                smallScroll: function() {
                        var s = this;
                        var next = jq('.ad-forward');
                        var prev = jq('.ad-back');
                        next.click(function() {
                                if (smallWrap.is(':animated') || next.hasClass('disabled')) return;
                                s.nextGroup();
                        })
                        prev.click(function() {
                                if (smallWrap.is(':animated') || prev.hasClass('disabled')) return;
                                s.prevGroup();
                        })
                },
                btnChange: function() {
                        var s = this;
                        jq('.ad-prev').click(function() {
                                s.prev();
                        })
                        jq('.ad-next').click(function() {
                                s.next();
                        })
                }
        }
        scroll.init();
})
