<?php
/**
 *	[帖内选项卡(threed_tab.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	Version: 商业版
 *	Date: 2014-11-7 19:49
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$tmp_lang = array(
    'imgguest' => '登录/注册后可看大图',
    'attachdown' => '请点击此处下载',
    'attachdownreg' => '请先注册会员后在进行下载',
    'attachdownlogin' => '已注册会员，请先登录后下载',
    'attachname' => '文件名称',
    'attachsize' => '文件大小',
    'attachprice' => '售价',
    'attachreadperm' => '下载权限',
    'attachdownloads' => '下载次数',
    'attachdown' => '请点击此处下载',
    'attachdownreg' => '请先注册会员后在进行下载',
    'attachdownlogin' => '已注册会员，请先登录后下载',
    'attachdownlogin_ok' => '您的用户组是',
    'attachdownreg_pay' => '需要先购买才能下载',
    'attach3'=>'查看状态：已购买或有权限',
    'attach4'=>'查看状态：需购买或无权限',
    'attach5'=>'查看状态：今天下载数已用完',
    'a1' => '免',
    'a2' => '立即下载',
    'a3' => '立即购买',
    'a4' => '无',
    'a5' => '请登陆后下载',
    'a6' => '请等待作者更新',
    'a7' => '请先登陆',
    'a8' => '暂无下载',
    'a9' => '私信',
    'a10' => '帖子',
    'a11' => '粉丝',
    'a12' => '帖子说明',
    'a13' => '评论',
    'a14' => '查看',
    'a15' => '收藏',
    'a16' => '已收藏',
    'mobile1' => '点击下载',
    'mobile2' => '点击购买',
    'mobile3' => '您今天的下载数已用完',
    'mobile4' => '您无权限下载',
    );

