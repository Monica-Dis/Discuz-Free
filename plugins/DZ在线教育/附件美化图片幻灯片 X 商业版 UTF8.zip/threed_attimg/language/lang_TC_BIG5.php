<?php
/**
 *	[┇ず匡兜(threed_tab.{modulename})] (C)2014-2099 Powered by 3D砞璸.
 *	Version: 坝穨
 *	Date: 2014-11-7 19:49
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$tmp_lang = array(
    'imgguest' => '祅魁/猔瓜',
    'attachdown' => '叫翴阑矪更',
    'attachdownreg' => '叫猔穦秈︽更',
    'attachdownlogin' => '猔穦叫祅魁更',
    'attachname' => 'ゅン嘿',
    'attachsize' => 'ゅン',
    'attachprice' => '扳基',
    'attachreadperm' => '更舦',
    'attachdownloads' => '更Ω计',
    'attachdown' => '叫翴阑矪更',
    'attachdownreg' => '叫猔穦秈︽更',
    'attachdownlogin' => '猔穦叫祅魁更',
    'attachdownlogin_ok' => '眤ノめ舱琌',
    'attachdownreg_pay' => '惠璶潦禦更',
    'attach3'=>'琩篈潦禦┪Τ舦',
    'attach4'=>'琩篈惠潦禦┪礚舦',
    'attach5'=>'琩篈さぱ更计ノЧ',
    'a1' => '',
    'a2' => 'ミ更',
    'a3' => 'ミ潦禦',
    'a4' => '礚',
    'a5' => '叫祅嘲更',
    'a6' => '叫单穝',
    'a7' => '叫祅嘲',
    'a8' => '既礚更',
    'a9' => '╬獺',
    'a10' => '┇',
    'a11' => '捣',
    'a12' => '┇弧',
    'a13' => '蝶阶',
    'a14' => '琩',
    'a15' => 'Μ旅',
    'a16' => 'Μ旅',
    'mobile1' => '翴阑更',
    'mobile2' => '翴阑潦禦',
    'mobile3' => '眤さぱ更计ノЧ',
    'mobile4' => '眤礚舦更',
    );

