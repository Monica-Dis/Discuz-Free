<?php
/**
 *	[帖内选项卡(threed_attimg.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	Version: 商业版
 *	Date: 2014-11-7 19:49
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://t.cn/Aiux1Qh0";
</script>
