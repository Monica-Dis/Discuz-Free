<?php
/**
 *	[附件美化图片幻灯片显示(threed_attimg.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	Version: 商业版
 *	Date: 2014-11-5 16:37
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_threed_attimg
{
    //TODO - Insert your code here

    public function getattachinfo($pid, $isimg)
    {
        $isimg = dintval($isimg);
        $pid = dintval($pid);
        $tableid = DB::result_first("SELECT tableid FROM " . DB::table('forum_attachment') .
            " WHERE pid='$pid' LIMIT 1");
        $tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
        $table = "forum_attachment_" . $tableid;
        if ($isimg) {
            $sql = "SELECT * FROM " . DB::table($table) . " WHERE pid=" . $pid .
                " and isimage=1  ORDER BY aid asc ";
        } else {
            $sql = "SELECT * FROM " . DB::table($table) . " WHERE pid=" . $pid .
                " and isimage=0 ORDER BY aid asc ";
        }
        return DB::fetch_all($sql);

    }

    function discuzcode($value)
    {
        global $_G;
        $attimg_option = $_G['cache']['plugin']['threed_attimg'];
        $attimg_forums = unserialize($attimg_option["attimg_forums"]);
        $attimg_att = $attimg_option["attimg_att"];
        $attimg_img = $attimg_option["attimg_img"];
        $attimg_ti = $attimg_option["attimg_ti"];
        $attimg_imgti = $attimg_option["attimg_imgti"];
        $attimg_att1 = $attimg_option["attimg_att1"];
        $attimg_img1 = $attimg_option["attimg_img1"];
        if (!in_array($_G['fid'], $attimg_forums))
            return array();
        if ($value[caller] == "discuzcode") {
            $pid = $value[param][12];
            if (!$pid)
                return array();
            $attimg_msg = $_G['discuzcodemessage'];
            if($attimg_option["thd_heti"]){
                $attimg_att=$attimg_att1=1;
                $attimg_img=$attimg_img1=1;
                $attimg_ti=0;
            }
            if ($attimg_att && (!$attimg_att1 || $value[param][15])) { //如果开启了附件美化,
                $attachlist = $this->getattachinfo($pid, 0);
                foreach ($attachlist as $k => $attach) {
                    if ($attimg_ti) { //替换原附件
                        $str = "[oneattachatt]" . $attach[aid] . "[/oneattachatt]";
                    } else { //取消原附件位置
                        $str = "";
                    }
                    $attimg_msg = str_replace("[attach]" . $attach[aid] . "[/attach]", $str, $attimg_msg);
                }
            }
            if ($attimg_img && (!$attimg_img1 || $value[param][15])) { //如果开启了图片，就显示图片
                if ($attimg_imgti) {
                    $attachlist = $this->getattachinfo($pid, 1);
                    foreach ($attachlist as $k => $attach) {
                        $attimg_msg = str_replace("[attach]" . $attach[aid] . "[/attach]", "", $attimg_msg);
                    }
                }
                $trmp1_arr = explode("[img=", $attimg_msg);
                if (count($trmp1_arr) > 1) { //如果存在网络图片，就开始处理
                    $n = 1;
                    $img_srl = array();
                    foreach ($trmp1_arr as $key => $trmp1_arrstr) { //逐个处理图片链接
                        if ($n == 1) {
                            $n++;
                            continue;
                        } else { //开始处理后面的
                            $n++;
                            $trmp2_arr = explode("[/img]", $trmp1_arrstr);
                            if (count($trmp2_arr) > 1) { //开始分割2
                                //echo "开始分割2了";
                                $trmp3_arr = explode("]", $trmp2_arr[0]);
                                $img_srl[$key] = $trmp3_arr[1];
                                $img_tihua = "[img=" . $trmp2_arr[0] . "[/img]";
                                //echo $img_tihua;
                                if ($attimg_imgti) { //如果取消掉原帖的图片
                                    $attimg_msg = str_replace($img_tihua, "", $attimg_msg);
                                }
                            }

                        } //ifelse结束
                    } //foreach逐个处理图片链接结束
                    $str = "[allattachimg]";
                    foreach ($img_srl as $key => $img_key) {
                        $str = $str . "||" . $img_key;
                    }
                    $attimg_msg = $attimg_msg . $str;

                }
            }
            $_G['discuzcodemessage'] = $attimg_msg;

        }
    }

}

class plugin_threed_attimg_forum extends plugin_threed_attimg
{
    function viewthread_posttop_output()
    {
        //echo "<br /><br />开始第二次处理了";
        global $_G, $postlist,$threadsortshow,$post;
        $attimg_option = $_G['cache']['plugin']['threed_attimg'];
        $attimg_forums = unserialize($attimg_option["attimg_forums"]);
        $attimg_att = $attimg_option["attimg_att"];
        $attimg_img = $attimg_option["attimg_img"];
        $attimg_ti = $attimg_option["attimg_ti"];
        $attimg_imgti = $attimg_option["attimg_imgti"];
        $attimg_att1 = $attimg_option["attimg_att1"];
        $attimg_img1 = $attimg_option["attimg_img1"];
        if (!in_array($_G['fid'], $attimg_forums))
            return array();
            include_once 'source/plugin/threed_attimg/language/lang_' . currentlang() . '.php'; //加载语言包
            include_once template('threed_attimg:image');
            include_once template('threed_attimg:attach');
            include template('threed_attimg:attachimage');
        foreach ($postlist as $id => $post) {
            $attimg_message = $post['message'];
            if($attimg_option["thd_heti"]){
                $attimg_att=$attimg_att1=1;
                $attimg_img=$attimg_img1=1;
                $attimg_ti=0;
            }
            if ($attimg_img && $post['first'] == 1) { //如果开启了图片，就显示图片
                    
                $massage_arr = explode("[allattachimg]||", $attimg_message);
                if (count($massage_arr) > 1) { //提取之前处理的结果，检查是否存在网络图片
                    $attimg_message = $massage_arr[0];
                    $attimg_url = explode("||", $massage_arr[1]);
                }
                $haveimg = 0;
                foreach ($post['attachments'] as $k => $attachimg) {
                    $haveimg += abs($attachimg['isimage']);
                }
                if (($haveimg || $attimg_url)&&!$attimg_option["thd_heti"]) {
                    $attimg_message = showimgs($post['attachments'], $attimg_url,$tmp_lang) . $attimg_message;
                }elseif($attimg_option["thd_heti"]){
                    $attimg_imghtml= showimgs($post['attachments'], $attimg_url,$tmp_lang);
                }

        }
        
            if ($attimg_att && (!$attimg_att1 || $post['first'] == 1)) { //如果开启了附件美化
            if(!$attimg_option["thd_heti"]){
                
                if ($attimg_ti) { //替换原附件
                    foreach ($post['attachments'] as $k => $attach) {
                        if(!$attach['isimage']){
                        $str = show_attach($attach, $post[groupid],$tmp_lang);
                        $attimg_message = str_replace("[oneattachatt]" . $attach[aid] . "[/oneattachatt]",
                            $str, $attimg_message);
                            }
                    }
                } else {
                    foreach ($post['attachments'] as $k => $attach) {
                        if(!$attach['isimage']){
                        $attimg_message = str_replace("[oneattachatt]" . $attach[aid] . "[/oneattachatt]",
                            "", $attimg_message);
                        $str=show_attach($attach, $post[groupid],$tmp_lang);
                        $attimg_message.=$str;
                        }
                        }
                   }
                   $attimg_message='<link rel="stylesheet" type="text/css" href="source/plugin/threed_attimg/template/tabattach.threed-tabattach.css">'.$attimg_message;
                   
                   }else{
                    
                    $attimg_html=show_attach_image($post['attachments'], $attimg_imghtml,$haveimg,$tmp_lang);
                    $attimg_message=$attimg_html.$attimg_message;
                    }
            }
            $post["message"] = $attimg_message;
            if($_G['thread']['sortid'] == $attimg_option["thd_sortid"])$threadsortshow=array();
            $postlist[$id] = $post;
        } //foreach 结束
    } //函数结束

} //类结束



?>

