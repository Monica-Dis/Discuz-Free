var jq = jQuery.noConflict();
var timelineType = !0,
	sunType = !0,
	showTime = !0,
	canGetData = !0;
jq(function() {
	getGoodsDetail();
	var b = jq("#pid").val() - 1;
	getInfo(b);
	getCB();
	period("");
	getTopGoods()
});

function getGoodsDetail() {
	var b = jq("#gid").val(),
		a = jq("#pid").val();
	ajaxGoodsDetailInfo(b, a, bindGoodsDetail)
}
function getCB() {
	var b = jq("#gid").val();
	ajaxGoodsDetailCB(b, bindCB)
}
function getInfo(b) {
	var a = jq("#gid").val();
	ajaxGoodsDetailPublish(a, b, bindinfo)
}
function getWinGoods() {
	jq("#gid").val()
}
function getTopGoods() {
	ajaxGoodsListTopGoods({
		order: "addTime",
		size: "4",
		page: "1"
	}, bindListTopGoods)
}
function bindListTopGoods(b) {
	if (b.status) {
		b = b.goods.dataList;
		var a = "";
		if ("undefined" != typeof b && 0 != b.length) for (var c in b) var a = a + '<ul class="w_shelves_one">',
			a = a + "<li>",
			a = a + ('<a href="../goods/goods' + b[c].gid + "-" + b[c].periodCurrent + '.html">'),
			d = "undefined" != typeof b[c].showImages && imageGoodsPath + b[c].showImages.split(",")[0] + imgsize,
			a = a + ('<img class="lazy200" data-original="' + d + '" />'),
			d = "undefined" != typeof b[c].showImages && imageGoodsPath + b[c].showImages.split(",")[0] + imgsize,
			a = a + ('<noscript><img src="' + d + '" alt=""/></noscript>'),
			a = a + "</a>",
			a = a + "</li>",
			a = a + ("<b>总需人次：" + b[c].priceTotal + "人次</b>"),
			a = a + ('<a href="../goods/goods' + b[c].gid + "-" + b[c].periodCurrent + '.html">' + b[c].title + "</a>"),
			a = a + "</ul>";
		else a += "暂无";
		jq(".w_shelves_top").append(a);
		lazyload("200")
	}
}
function bindListwinGoods(b) {
	if (b.status) {
		var a = "";
		b = b.goods;
		if ("undefined" != typeof b && 0 != b.length) for (var c in b) a += '\t<div class="w_record">', a += '  \t<div class="w_record_img">', a += '<img class="lazy54" data-original="' + path + eval("(" + b[c].userInfo + ")").icons + '" />', a += '<noscript><img src="' + path + eval("(" + b[c].userInfo + ")").icons + '" /></noscript>', a += "</div>", a += '<p class="w_record_con" style="word-break: break-all; word-wrap:break-word;"><a href="../other/recordBuy/' + eval("(" + b[c].userInfo + ")").mid + '.html">' + eval("(" + b[c].userInfo + ")").nickname + "</a>参与了" + b[c].buyTimes + "人次<span>" + b[c].gtitle + "</span></p>", a += '<div class="w_clear"></div>', a += "</div>";
		else a += '<!-- 2015-7-27 start  外面添加 两个div框--><div class="w_no_can"><img src="/static/img/front/goods/nocan_03.png"/></div>', a += '<a class="w_now_shopping" href="#top">立即参与</a>', a += "<!-- 2015-7-27 end-->";
		jq(".w_record_in").append(a);
		lazyload("54", "1")
	}
}
function bindinfo(b) {
	if (b.status) {
		var a = b.goods;
		if ("undefined" != typeof a && "" != a && "1" != jq("#pid").val()) {
			jq(".w_addss_img").hide();
			if ("undefined" == typeof a.userWinCode || "undefined" == typeof a.userId) canGetData = !0, jq("#lookPublishWaitDetail").attr("href", "../goods/goods" + a.gid + "-" + a.periodCurrent + ".html"), jq("#publishLog").hide(), showTime || jq("#publishWaitBlackTime").html("正在计算，请稍后..."), jq("#onePublishWait").show(), jq(".w_time_backward_other").hide(), jq(".w_deng").hide();
			else {
				canGetData = !1;
				jq("#WinmemberId").attr("href", "../other/recordBuy/" + a.userId + ".html");
				jq("#WinmemberIcon").attr("data-original", path + a.userAvatar);
				jq("#WinmemberIconN").attr("src", path + a.userAvatar);
				jq("#lookPublishDetail").attr("href", "../goods/goods" + a.gid + "-" + a.period + ".html");
				jq("#WinmemberNickNameId").attr("href", "../other/recordBuy/" + a.userId + ".html");
				jq("#WinmemberNickNameId").html(a.userNickname);
				var c = "undefined" != typeof a.ygIp && "" != a.ygIp ? a.ygIp.split(" ")[0] : "地址不详";
				jq("#WinmemberAddress").html("(" + c + ")");
				jq("#WinmemberCode").html(a.userWinCode);
				jq("#WinmemberTimes").html(a.userYgCount);
				jq("#WinmemberPTime").html("揭晓时间：" + formatDate(a.publishTime));
				jq("#WinmemberBuyTime").html("夺宝时间：" + formatDate(a.ygTime));
				jq("lookPublishDetail").attr("href", "../goods/goods" + a.gid + "-" + a.period + ".html");
				jq("#onePublishWait").hide();
				jq(".w_time_backward_other").hide();
				jq(".w_deng").hide();
				jq("#publishLog").show()
			}
			jq(".w_page_on").show()
		} else "1" == jq("#pid").val() && (jq("#onePublishWait").hide(), jq("#publishLog").hide(), jq(".w_time_backward_other").show(), jq(".w_deng").show(), jq(".w_page_on").hide());
		lazyload("54", "1");
		"1" == jq("#pid").val() || "undefined" != typeof b.goods.userWinCode && "undefined" != typeof b.goods.userId || (0 < b.goods.expectPublishTime - b.now ? (showTime && jq("#publishWaitBlackTime").removeClass("w_timeing"), timeFunDetails(b.goods.expectPublishTime - b.now + (new Date).getTime())) : (publishTimes--, showTime = !1, 0 > publishTimes ? (jq("#publishWaitBlackTime").addClass("w_timeing"), jq("#publishWaitBlackTime").html("福彩中心通讯故障或福彩中心未开奖~请耐心等待")) : setTimeout(function() {
			if (canGetData) {
				var a = jq("#pid").val() - 1;
				jq("#publishWaitBlackTime").addClass("w_timeing");
				getInfo(a)
			}
		}, 5E3)))
	}
}
function bindCB(b) {
	b.status && ("99999" != b.goodsCBMap.cid ? jq(".w_guide").html('<a href="/">首页</a><a href="/goods/allCat.html">全部商品</a><a href="/goods/allCat' + b.goodsCBMap.cid + '.html">' + b.goodsCBMap.cname + '</a><a class="w_accord" href="javascript:void 0">商品详情</a>') : jq(".w_guide").html('<a href="/">首页</a><a href="/goods/allCat.html">全部商品</a><a href="/goods/experience_zone.html">新手专区</a><a class="w_accord" href="javascript:void 0">商品详情</a>'))
}
function bindGoodsDetail(b) {
	if (b.status) {
		jq(".w_addss_img").hide();
		var a = b.goods,
			c = b.mid,
			d = b.winnerList;
		"undefined" == typeof a.periodCurrent && (window.location.href = "/goods/publish" + jq("#gid").val() + "-" + jq("#pid").val() + ".html");
		"undefined" != typeof a.expectPublishTime && (window.location.href = "/goods/publish" + jq("#gid").val() + "-" + jq("#pid").val() + ".html");
		if (a.thumbPath) {
			var e = a.thumbPath.split(","),
				f;
			for (f in e);
			for (f in e);
			jq("#by_title").html(a.title);
			0 == a.showFlag ? jq("#by_subTitle").html(a.subTitle + "【此商品不可晒单】") : jq("#by_subTitle").html(a.subTitle);
			jq("#by_priceTotal").html(a.goodsPrice);
			jq("#by_priceAll").html(a.priceAll);
			jq("#by_buyAllTotal").html(a.buyAllTotal)
		}
		jq("#cart_priceArea").val(a.priceArea);
		jq("#cart_priceTotal").html(a.goodsPrice);
		jq("#zc_line").css("width", (0 === a.selledTime / (a.goodsPrice / a.priceArea) * 100 || 1 <= a.selledTime / (a.goodsPrice / a.priceArea) * 100 ? a.selledTime / (a.goodsPrice / a.priceArea) * 100 : 1) + "%");
		jq("#cart_priceSell").html(null != a.selledTime ? a.selledTime : a.goodsPrice);
		jq("#cart_need").html(a.goodsPrice / a.priceArea);
		jq("#cart_surplus").html(null != a.selledTime ? a.goodsPrice / a.priceArea - a.selledTime : 0);
		jq(".times").val(null != a.selledTime ? 1 : 0);
		0 < a.maxBuy && jq(".times").val(a.maxBuy);
		jq(".times").attr("min", 0 != a.maxBuy ? a.maxBuy : 1);
		jq(".times").attr("max", 0 != a.maxBuy ? a.maxBuy : null != a.selledTime ? a.goodsPrice / a.priceArea - a.selledTime : 0);
		0 != a.maxBuy ? (jq(".times").attr("max", 1), jq(".w_purchasing_other").html("限购" + a.maxBuy + "人次"), jq(".w_purchasing_other").toggle()) : 99999 != a.cid && jq(".w_purchasing_other").after('<i>10</i><i>20</i><i>50</i><i>100</i><em>包尾</em><strong class="w_tail">人次</strong>');
		99999 == a.cid && (jq(".w_greenHands a").attr("href", experience_activity_address), jq(".w_greenHands").show(), jq(".y_rob_another").hide());
		jq("#iWantyg").attr("data-gid", a.gid);
		jq("#iWantyg").attr("data-pid", a.periodCurrent);
		"undefined" != typeof c && 0 != c ? "undefined" != typeof d && "" != d ? jq(".w_security").after('<!--您的本期夺宝码开始--><div class="w_winner_list w_winner_bg" ><label>您的本期夺宝码：</label><ul style="height:55px;overflow:hidden;"><li>' + d + '</li></ul><span class="w_winner_more" onclick="showCodes()">查看全部&gt;</span>  <div class="w_clear"></div><strong></strong></div>') : jq(".w_security").after('<!--未参加夺宝开始--> <div class="w_winner_bg">  <span class="w_not_join">您还没有参与本次夺宝哦！</span>  <strong></strong></div>') : jq(".w_security").after('<!--未登录开始--><div class="w_winner_bg"><span class="w_not_logged"><a href="../api/uc/login.do">请登录</a>，查看你的夺宝号码！</span><strong></strong></div>');
		lazyload("400", "1");
		lazyload("55", "1");
		0 == jq("#pid").val() ? jq("#pid").val(b.goods.periodCurrent) : "";
		window._bd_share_config = {
			common: {
				bdText: b.goods.title,
				bdPic: imageGoodsPath + b.goods.showImages,
				bdDesc: b.goods.subTitle
			},
			share: {}
		};
		with(document) 0[(getElementsByTagName("head")[0] || body).appendChild(createElement("script")).src = "http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=" + ~ (-new Date / 36E5)]
	}
}
setTimeout(function() {
	jq(window).resize(function() {
		jq("#pro-view-7").css({
			left: (jq(window).width() - jq("#pro-view-7").width()) / 2,
			top: (jq(window).height() - jq("#pro-view-7").height()) / 2
		});
		jq("#pro-view-8").css({
			left: (jq(window).width() - jq("#pro-view-8").width()) / 2,
			top: (jq(window).height() - jq("#pro-view-8").height()) / 2
		});
		jq(".c_msgbox_bj").height(jq("body").height());
		jq(".once_shop_con").css({
			left: (jq(window).width() - jq(".once_shop_con").width()) / 2,
			top: (jq(window).height() - jq("#once_shop_con").height()) / 2
		})
	});
	jq(window).resize();
	jq(".w_small_img li").mousemove(function() {
		var a = jq(this).index(".w_small_img li");
		jq(".w_small_img li").removeClass("w_small_color");
		jq(this).addClass("w_small_color");
		jq(".w_big_img dd").css({
			display: "none"
		});
		jq(jq(".w_big_img dd")[a]).css({
			display: "block"
		});
		jq(".w_modified").css({
			left: (jq(".w_small_img li").outerWidth() + 3) * a + 30
		})
	});
	jq(".w_period").delegate("li a", "click", function(a) {
		a = a || window.event;
		a = a.target || a.srcElement;
		jq(".w_period li a").removeClass("w_the");
		jq(a).addClass("w_the");
		a = jq(a).attr("data-pid");
		getInfo(a)
	});
	jq(".w-msgbox-close").click(function() {
		jq("#pro-view-7").hide();
		jq(".c_msgbox_bj").hide()
	});
	jq(".w_cumulative_another i").click(function() {
		jq(this).index(".w_cumulative_another i");
		var a = jq(this).html();
		a > parseInt(jq(".w_detailsinputs").attr("max")) && (a = parseInt(jq(".w_detailsinputs").attr("max")));
		a < parseInt(jq(".w_detailsinputs").attr("min")) && (a = parseInt(jq(".w_detailsinputs").attr("min")));
		jq(".w_cumulative_another em").removeClass("w_num_color");
		jq(".w_cumulative_another i").removeClass("w_num_color");
		jq(this).addClass("w_num_color");
		jq(".w_detailsinputs_one").val(a);
		change_input()
	});
	jq(".w_cumulative_another em").click(function() {
		var a = jq(".w_amount_val").html();
		a > parseInt(jq(".w_detailsinputs").attr("max")) && (a = parseInt(jq(".w_detailsinputs").attr("max")));
		a < parseInt(jq(".w_detailsinputs").attr("min")) && (a = parseInt(jq(".w_detailsinputs").attr("min")));
		jq(".w_cumulative_another i").removeClass("w_num_color");
		jq(".w_cumulative_another em").addClass("w_num_color");
		jq(".w_detailsinputs_one").val(a);
		change_input()
	});
	var b = 0,
		a = jq(".w_record_out").height(),
		c = jq(".w_record").outerHeight(),
		d = parseInt(a / c);
	if (5 < jq(".w_record").length) {
		var e = function() {
				b -= c;
				b >= -(jq(".w_record_in .w_record").length - (d + 1)) * c ? jq(".w_record_in").animate({
					marginTop: b
				}, 2E3) : jq(".w_record_in").animate({
					marginTop: b
				}, 2E3, function() {
					b = 0;
					jq(".w_record_in").css({
						marginTop: 0
					})
				})
			};
		jq(".w_record_in .w_record").clone(!0).insertAfter(jq(jq(".w_record_in .w_record")[jq(".w_record_in .w_record").length - 1]));
		var f = setInterval(e, 4E3);
		jq(".w_record_in").hover(function() {
			clearInterval(f)
		}, function() {
			f = setInterval(e, 4E3)
		})
	}
	jq(".c_pop_shop").hover(function() {
		jq(this).find(".c_pop_btn").show()
	}, function() {
		jq(this).find(".c_pop_btn").hide()
	});
	jq(".w_detailsinputs_one").bind("input propertychange change", function(a) {
		change_input()
	})
}, 1E3);

function period(b) {
	b = "" != b ? b : jq("#pid").val();
	if (1 == b) jq(".pageUp").addClass("w_page_in"), jq(".pageDown").addClass("w_page_in");
	else {
		jq(".w_period").html("");
		jq(".w_period").append('<li><a class="w_the" data-pid="' + (b - 1) + '" href="javascript:void 0">第' + (b - 1) + "期</a></li>");
		for (var a = 2; 8 >= a && 0 < b - a; a++) jq(".w_period").append('<li><a data-pid="' + (b - a) + '" href="javascript:void 0">第' + (b - a) + "期</a></li>");
		jq(".w_period>li:first>a").attr("data-pid") >= jq("#pid").val() - 1 ? jq(".pageUp").addClass("w_page_in") : jq(".pageUp").removeClass("w_page_in");
		1 == jq(".w_period>li:last>a").attr("data-pid") ? jq(".pageDown").addClass("w_page_in") : jq(".pageDown").removeClass("w_page_in")
	}
}
function timeFunDetails(b) {
	var a = jq(".w_addBg");
	Time_fun(b, a, function() {
		getInfo(jq("#pid").val() - 1)
	})
}
var t = {};

function Time_fun(b, a, c) {
	t.time = b - (new Date).getTime();
	t.h = parseInt(t.time / 1E3 / 60 / 60 % 24);
	t.i = parseInt(t.time / 1E3 / 60 % 60);
	t.s = parseInt(t.time / 1E3 % 60);
	t.ms = String(Math.floor(t.time % 1E3));
	t.ms = parseInt(t.ms.substr(0, 2));
	10 > t.h && (t.h = "0" + t.h);
	10 > t.i && (t.i = "0" + t.i);
	10 > t.s && (t.s = "0" + t.s);
	0 > t.ms && (t.ms = "00");
	t.oh = String(t.h).slice(0, 1);
	t.th = String(t.h).slice(1);
	t.oi = String(t.i).slice(0, 1);
	t.ti = String(t.i).slice(1);
	t.os = String(t.s).slice(0, 1);
	t.ts = String(t.s).slice(1);
	t.oms = String(t.ms).slice(0, 1);
	t.tms = String(t.ms).slice(1);
	0 > a.find("p").attr("class").indexOf("w_timeing") && (0 < t.h ? a.find("p").html("<b>" + t.oh + "</b><b>" + t.th + "</b><span>:</span><b>" + t.oi + "</b><b>" + t.ti + "</b><span>:</span><b>" + t.os + "</b><b>" + t.ts + "</b>") : 0 < b && a.find("p").html("<b>" + t.oi + "</b><b>" + t.ti + "</b><span>:</span><b>" + t.os + "</b><b>" + t.ts + "</b><span>:</span><b>" + t.oms + "</b><b>" + t.tms + "</b>"));
	0 >= t.time ? (jq("#publishWaitBlackTime").addClass("w_timeing"), jq("#publishWaitBlackTime").html("正在计算，请稍后..."), setTimeout(function() {
		c()
	}, 5E3)) : setTimeout(function() {
		Time_fun(b, a, c)
	}, 30)
}
function gotoCart(b) {
	jq("#cart_need").html();
	b = jq(".times").val() || jq(".w_detailsinputs").attr("min");
	var a = jq("#gid").val();
	addCart(a, b);
	gotoCartOrder()
}
function cartoon() {
	var b = jq("#gid").val();
	addCart(b, 1);
	if (jq(".shoppingCartRightFix").is(":visible")) {
		var b = jq(".w_slip_out").parents(".w_details_top").find(".w_big_img").css({
			display: "block"
		}),
			a = b.clone().css("opacity", .75);
		jq("body").append(a);
		a.css({
			"z-index": 9E3,
			display: "block",
			position: "absolute",
			top: b.offset().top + "px",
			left: b.offset().left + "px",
			width: b.width() + "px",
			height: b.height() + "px"
		});
		a.animate({
			top: jq(".shoppingCartRightFix").offset().top,
			left: jq(".shoppingCartRightFix").offset().left,
			width: 40,
			height: 37
		}, "slow", function() {
			a.remove()
		})
	}
}
function showCodes(b) {
	var a = jq(".w_results").text();
	$.ajax({
		url: "/goods/querycodes.do",
		type: "post",
		dataType: "json",
		data: {
			mid: b,
			gid: jq("#gid").val(),
			pid: jq("#pid").val()
		},
		success: function(c) {
			if (c.status) {
				jq("#pro-view-7 .m-detail-codesDetail-wrap").html("");
				jq("#pro-view-7 h3").html(b ? "奖品获得者" : '您本期总共参与了<span class="txt-red">' + c.size + "</span>人次");
				var d = [],
					e = [];
				jq(c.codes).each(function(b, c) {
					d.push('<dl class="m-detail-codesDetail-list f-clear">');
					d.push("<dt>夺宝时间：" + formatDate(c.buyTime) + "</dt>");
					e = c.buyCodes.replace("[", "").replace("]", "").replace(/"/g, "").split(",");
					jq(e).each(function(b, c) {
						c != a ? d.push("<dd>" + c + "</dd>") : d.push('<dd class="txt-red selected">' + c + "</dd>")
					});
					d.push("</dl>")
				});
				jq("#pro-view-7 .m-detail-codesDetail-wrap").html(d.join(""));
				jq("#pro-view-7").css({
					left: (jq(window).width() - jq("#pro-view-7").width()) / 2,
					top: (jq(window).height() - jq("#pro-view-7").height()) / 2
				});
				jq("#pro-view-7").show();
				jq(".c_msgbox_bj").height(jq("body").height());
				jq(".c_msgbox_bj").show()
			}
		},
		error: function() {}
	})
}
function closeCodesPane() {
	jq("#pro-view-7").hide();
	jq(".c_msgbox_bj").hide()
}
function pageDown() {
	var b = jq(".w_period>li:last>a").attr("data-pid");
	1 == b || isNaN(b) || (period(b), getInfo(b))
}
function pageUp() {
	var b = jq(".w_period>li:first>a").attr("data-pid");
	b >= jq("#pid").val() - 1 || isNaN(b) || (period(parseInt(b) + 9), getInfo(parseInt(b) + 8))
}
function bugTimesInput() {
	if (!jq(".w_detailsinputs").val() || isNaN(jq(".w_detailsinputs").val())) jq(".w_detailsinputs").val(jq(".w_detailsinputs").attr("min"));
	else {
		var b = parseInt(jq(".w_detailsinputs").attr("max")),
			a = parseInt(jq(".w_detailsinputs").attr("min"));
		0 != parseInt(jq(".w_detailsinputs").val()) % a && jq(".w_detailsinputs").val(parseInt(parseInt(jq(".w_detailsinputs").val()) / a) * a);
		parseInt(jq(".w_detailsinputs").val()) > b && jq(".w_detailsinputs").val(b);
		parseInt(jq(".w_detailsinputs").val()) < a && jq(".w_detailsinputs").val(a)
	}
	change_input()
}
var sttims = null,
	_times = !0;

function change_input() {
	null != sttims && (clearTimeout(sttims), sttims = null);
	var b = (parseFloat(jq(".w_detailsinputs").val() * parseInt(jq("#cart_priceArea").text())) / parseFloat(jq("#cart_priceTotal").text()) * 100).toFixed(3);
	jq(".y-hide-span span").html("&#x83B7;&#x5F97;&#x673A;&#x7387;" + (.001 <= b ? b : "<0.001") + "%<i></i>");
	_times && jq(".y-hide-span").show(10, function() {
		sttims = setTimeout(function() {
			jq(".y-hide-span").fadeOut("slow");
			sttims = null
		}, 3E3)
	})
}
function addBuyTimes() {
	var b = parseInt(jq(".w_detailsinputs").attr("max")),
		a = parseInt(jq(".w_detailsinputs").attr("min"));
	b - parseInt(jq(".w_detailsinputs").val()) >= a && jq(".w_detailsinputs").val(parseInt(jq(".w_detailsinputs").val()) + a);
	change_input()
}
function cutBuyTimes() {
	var b = parseInt(jq(".w_detailsinputs").attr("min"));
	0 < parseInt(jq(".w_detailsinputs").val()) - b && jq(".w_detailsinputs").val(parseInt(jq(".w_detailsinputs").val()) - b);
	change_input()
}
function tabChange(b) {
	var a = jq(b.target).index(".w_prize .w_calculate_nav dd");
	1 == parseInt(a) && "none" == jq(jq(".w_prize_con")[a]).css("display") && timelineType && timeline();
	2 == parseInt(a) && "none" == jq(jq(".w_prize_con")[a]).css("display") && sunType && sun();
	jq(".w_prize .w_calculate_nav dd").removeClass("w_results_arrow");
	jq(b.target).addClass("w_results_arrow");
	jq(".w_prize_con").css("display", "none");
	jq(jq(".w_prize_con")[a]).css("display", "block")
}
function baiduTag_view(b, a, c, d, e, f, g, h, k) {
	_hmt.push(["_trackRTEvent",
	{
		data: {
			ecom_view: {
				prod: [{
					p_id: b,
					p_name: a,
					p_brand: c,
					p_price: d,
					p_class1: e,
					p_class2: f,
					p_stock: g,
					p_img_url: h,
					p_url: k
				}]
			}
		}
	}])
};