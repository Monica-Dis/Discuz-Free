<?php
/**
 *	[���������ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if(!defined('IN_DISCUZ')|| !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://dism.taobao.com/?@41545.developer";
</script>