<?php
/**
 *	[���������ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$chou_option = $_G['cache']['plugin']['threed_chou'];
$chou_gouser = unserialize($chou_option["chou_gouser"]);
$chou_credit = $chou_option["chou_credit"];
$chou_creditname = $_G['setting']['extcredits'][$chou_credit]['title'];
$chou_supadmin = explode(",", $chou_option['chou_supadmin']);
$uid = $_G['uid'];
$tid = intval($_GET['tid']);
$tid=$tid>0?$tid:0;
if (!$chou_supadmin[0])
    $chou_supadmin = array('1');
if (in_array($uid, $chou_supadmin)) {
    $adadmin = 1;
    if (submitcheck('delad')) {
        $get = daddslashes($_GET);
        $delad = $get['delete'];
        $del = 0;
        foreach ($delad as $key => $delid) {
            $delid = intval($delid);
            DB::delete('threed_chou', "id=$delid");
            $del = $del + 1;
        }
        showmessage(lang('plugin/threed_chou', 'list2') . $del.lang('plugin/threed_chou', 'list3'),
            "plugin.php?id=threed_chou:chou&tid=$tid", array(), array(), array('alert' =>
                'right'));
        die();
    }
} else {
    $adadmin = 0;
}
require_once libfile('function/threed', 'plugin/threed_chou');
if (!$uid || !in_array($_G['groupid'], $chou_gouser)) {
    showmessage(lang('plugin/threed_chou', 'list1'), array(), array(), array('alert' =>
            'error', 'login' => '1'));
} else {
    $this_subject = DB::result_first("SELECT subject FROM " . DB::table('forum_thread') .
        ' WHERE tid=' . $tid);
    if (!$this_subject) {
        showmessage(lang('plugin/threed_chou', 'list5'), array(), array(), array('alert' =>
                'error'));
    }
  
    $page = intval($_GET['page']);
    if (empty($page))
        $page = 1;
    $pagenum = 20;
    $limit_start = $pagenum * ($page - 1);
    $where = "tid=$tid";
    if ($_GET['tj'] == 'my') {
        $url = '&tj=my';
        $where .= ' AND uid=' . $uid;
    } else {
        $url = '';
    }
    $list = array();
    $list_uid = array();
    $all_uid = array();
    $query = DB::query("SELECT * FROM " . DB::table('threed_chou') . " WHERE $where  ORDER BY uid DESC LIMIT $limit_start,$pagenum");
    while ($chujia = DB::fetch($query)) {
        $chujia['time'] = date('Y-m-d H:i:s', $chujia['time']);
        if($chujia['uid']==$uid){
            $list_uid[] = $chujia;
        }else{
            $list[] = $chujia;
            }
        $all_uid[] = $chujia['uid'];
    }
    $list=array_merge($list_uid,$list);
    $list_usnm = array();
    $query = DB::query("SELECT username,uid FROM " . DB::table('common_member') .
        " WHERE " . DB::field('uid', $all_uid));
    while ($row = DB::fetch($query)) {
        $list_usnm[$row['uid']] = $row['username'];
    }
    $totalnum = DB::result_first("SELECT count(1) FROM " . DB::table('threed_chou') .
        " WHERE $where");
    $multi = multi($totalnum, $pagenum, $page, "plugin.php?id=threed_chou:chou" .
        $url);
    $navtitle = lang('plugin/threed_chou', 'list4');
    include template("threed_chou:chou");
}
//From: Dism_taobao_com
?>