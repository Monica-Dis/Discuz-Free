<?php
/**
 *	[���ֹ�����Ƶ�̳�(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class mobileplugin_threed_chou
{
    //TODO - Insert your code here
}

class mobileplugin_threed_chou_forum extends mobileplugin_threed_chou
{
    function forumdisplay_thread_output()
    {
        global $_G, $sorttemplate;
        $sortid = intval($_GET['sortid']);
        $chou_option = $_G['cache']['plugin']['threed_chou'];
        $chou_forums = unserialize($chou_option["chou_forum"]);
        if (in_array($_G['fid'], $chou_forums) && !empty($sorttemplate)) {
            $sorttemplate=array();
            }
        }
            

    function viewthread_posttop_output()
    {
        global $_G, $postlist, $threadsortshow;
        $chou_option = $_G['cache']['plugin']['threed_chou'];
        $chou_forums = unserialize($chou_option["chou_forum"]);
        $chou_user = unserialize($chou_option["chou_user"]);
        $chou_gouser = unserialize($chou_option["chou_gouser"]);
        $tid = $_G['tid'];
        $uid = $_G['uid'];
        if (in_array($_G['fid'], $chou_forums) && !empty($threadsortshow)) {
            $chou_credit = $chou_option["chou_credit"];
            $chou_credit_name = $_G['setting']['extcredits'][$chou_credit]['title'];
            $chou_target = $threadsortshow['optionlist']['zc_target']['value'];
            $chou_price = $threadsortshow['optionlist']['zc_price']['value'];
            $chou_endtime = $threadsortshow['optionlist']['zc_endtime']['value'];
            $chou_endtime = strtotime($chou_endtime) + 86400;
            $chou_subject = $_G['thread']['subject'];
            $chou_buy = DB::fetch_first('SELECT SUM(buynum) as buycount,count(*) as buyn FROM ' .
                DB::table('threed_chou') . ' WHERE  tid = ' . $tid);
            $buycount = $chou_buy['buycount'];
            $chou_buy['buyn'] = $chou_buy['buyn'] ? $chou_buy['buyn'] : 0;
            $buycount = $buycount > 0 ? $buycount : 0;
            $yi_chou = $buycount * $chou_price;
            $chou_allnum = intval($chou_target / $chou_price);
            $chou_yuxia = $chou_allnum - $buycount;
            $chou_pset = round($buycount / $chou_allnum * 100, 2);
            $chou_status = DB::result_first('SELECT staus FROM ' . DB::table('threed_choutid') .
                ' WHERE  tid = ' . $tid);
            if (!$chou_status) {
                $id = DB::insert("threed_choutid", array('tid' => $tid, 'staus' => '1'), true, true);
                $chou_status = 1;
            }
            if ($chou_status == 1) {
                if ($buycount < $chou_allnum && $_G['timestamp'] < $chou_endtime) { //δ��ʱ��δ��
                    $pay_html = '<a id="iWantyg" class="w_slip"  href="javascript:;" onclick="showpay();">' .
                        lang('plugin/threed_chou', 'index1') . '</a>';
                } elseif ($buycount < $chou_allnum && $_G['timestamp'] >= $chou_endtime) { //��ʱδ������Ǯ
                    $id = DB::update("threed_choutid", array('staus' => '3'), 'tid=' . $tid);
                    $query = DB::query("SELECT uid,paynum FROM " . DB::table('threed_chou') .
                        " WHERE tid=$tid  ORDER BY time");
                    while ($chou = DB::fetch($query)) {
                        if ($chou['paynum'] && $chou['uid'])
                            updatemembercount($chou['uid'], array('extcredits' . $chou_credit => '+' . $chou['paynum']), true,
                                'STC', $tid);
                    }

                    $pay_html = '<a id="iWantyg" class="w_slip" >' . lang('plugin/threed_chou',
                        'index3') . '</a>';
                } elseif ($buycount >= $chou_allnum) { //���ܳ�ʱû��ʱ������ɹ�
                    $id = DB::update("threed_choutid", array('staus' => '2'), 'tid=' . $tid);
                    if ($yi_chou)
                        updatemembercount($_G['thread']['authorid'], array('extcredits' . $chou_credit =>
                                '+' . ($yi_chou - intval($yi_chou * $chou_option['chou_shui'] / 100))), true,
                            'STC', $tid);
                    $pay_html = '<a id="iWantyg" class="w_slip" >' . lang('plugin/threed_chou',
                        'index2') . '</a>';
                }
            } elseif ($chou_status == 2) {
                $pay_html = '<a id="iWantyg" class="w_slip" >' . lang('plugin/threed_chou',
                    'index2') . '</a>';
            } elseif ($chou_status == 3) {
                $pay_html = '<a id="iWantyg" class="w_slip" >' . lang('plugin/threed_chou',
                    'index3') . '</a>';
            } else {
                $pay_html = '<a id="iWantyg" class="w_slip" >' . lang('plugin/threed_chou',
                    'index3') . '</a>';
            }
            foreach ($postlist as $id => $post) {
                if (!$post['first']) {
                    break;
                }
                if (!stripos($threadsortshow['optionlist']['zc_img1']['value'], 'nophoto.gif') &&
                    $threadsortshow['optionlist']['zc_img1']['value'])
                    $allimage[] = $threadsortshow['optionlist']['zc_img1']['value'];
                if (!stripos($threadsortshow['optionlist']['zc_img2']['value'], 'nophoto.gif') &&
                    $threadsortshow['optionlist']['zc_img1']['value'])
                    $allimage[] = $threadsortshow['optionlist']['zc_img2']['value'];
                if (!stripos($threadsortshow['optionlist']['zc_img3']['value'], 'nophoto.gif') &&
                    $threadsortshow['optionlist']['zc_img1']['value'])
                    $allimage[] = $threadsortshow['optionlist']['zc_img3']['value'];
                if (!stripos($threadsortshow['optionlist']['zc_img4']['value'], 'nophoto.gif') &&
                    $threadsortshow['optionlist']['zc_img1']['value'])
                    $allimage[] = $threadsortshow['optionlist']['zc_img4']['value'];
                if (!stripos($threadsortshow['optionlist']['zc_img5']['value'], 'nophoto.gif') &&
                    $threadsortshow['optionlist']['zc_img1']['value'])
                    $allimage[] = $threadsortshow['optionlist']['zc_img5']['value'];
                if (empty($allimage) && !empty($post['attachments'])) {
                    $i = 1;
                    foreach ($post['attachments'] as $k => $attach) {
                        if ($attach['isimage'] && $i <= 5) {
                            $i++;
                            $attachurl = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
                            $allimage[] = $attachurl . "/forum/" . $attach['attachment'];
                        }

                    }
                }
                if (empty($allimage)) {
                    $allimage[] = $threadsortshow['optionlist']['zc_img1']['value'];
                }
                $datu_html = '<dl class="w_big_img">';
                $xiaotu_html = '<ul class="w_small_img"><i style="left: 30px;" class="w_modified"></i>';
                foreach ($allimage as $i => $img) {
                    if ($i == 0) {
                        $datu_html .= '<dd style="display:block;"><img src="' . $img . '"></dd>';
                        $xiaotu_html .= '<li class="w_small_color"><img src="' . $img . '"></li>';
                    } else {
                        $datu_html .= '<dd style="display: none;"><img src="' . $img . '"></dd>';
                        $xiaotu_html .= '<li class=""><img src="' . $img . '"></li>';
                    }
                }
                $datu_html .= '</dl>';
                $xiaotu_html .= '</ul>';

                $tmpmessage = '<link rel="stylesheet" href="source/plugin/threed_chou/template/css/phone.css">' .
                    $threadsortshow['typetemplate'];
                $tmpmessage = str_replace("{chou_tid}", $tid, $tmpmessage);
                $tmpmessage = str_replace("{chou_yichoudao}", $yi_chou, $tmpmessage);
                $tmpmessage = str_replace("{chou_allnum}", $chou_allnum, $tmpmessage);
                $tmpmessage = str_replace("{chou_imghtml}", $datu_html . $xiaotu_html, $tmpmessage);
                $tmpmessage = str_replace("{chou_subject}", $chou_subject, $tmpmessage);
                $tmpmessage = str_replace("{chou_target}", $chou_target, $tmpmessage);
                $tmpmessage = str_replace("{chou_pset}", $chou_pset, $tmpmessage);
                $tmpmessage = str_replace("{chou_buycount}", $buycount, $tmpmessage);
                $tmpmessage = str_replace("{chou_yuxia}", $chou_yuxia, $tmpmessage);
                $tmpmessage = str_replace("{chou_pay_html}", $pay_html, $tmpmessage);
                $tmpmessage = str_replace("{chou_credit_name}", $chou_credit_name, $tmpmessage);
                $tmpmessage = str_replace("{FORMHASH}", FORMHASH, $tmpmessage);
                $threadsortshow = array();

                $chou_list = array();
                $all_uid = array();
                $query = DB::query("SELECT * FROM " . DB::table('threed_chou') . " WHERE tid=$tid  ORDER BY time DESC LIMIT 0,20");
                while ($chou = DB::fetch($query)) {
                    $chou['time'] = date('Y-m-d H:i:s', $chou['time']);
                    $chou['paynum'] = $chou['buynum'] * $chou_price;
                    $all_uid[] = $chou['uid'];
                    $chou_list[] = $chou;
                }
                $list_usnm = array();
                $query = DB::query("SELECT username,uid FROM " . DB::table('common_member') .
                    " WHERE " . DB::field('uid', $all_uid));
                while ($row = DB::fetch($query)) {
                    $list_usnm[$row['uid']] = $row['username'];
                }
                include template('threed_chou:view');
                $chou_message = $post['message'];
                $post['message'] = show_viewlist($tid) . $chou_message;
                $post['message'] = $tmpmessage . $post['message'];
                $postlist[$id] = $post;
            }
        }
    }
}
//From: Dism_taobao_com
?>