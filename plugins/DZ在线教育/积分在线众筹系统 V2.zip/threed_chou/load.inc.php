<?php
/**
 *	[�����ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$tid = intval($_GET['tid']);
$chou_option = $_G['cache']['plugin']['threed_chou'];
$saleid=DB::result_first('SELECT authorid FROM '.DB::table('forum_thread').' WHERE tid='.$tid);
if((!$_G['uid']||$saleid!=$_G['uid']&&$_G['groupid']!=1)||$_GET['formhash']!=FORMHASH)showmessage(lang('plugin/threed_chou', 'list1'),  array(), array(), array('alert' => 'error'));//�ܾ�һ�зǷ�����
if ($_GET['ac'] == "show") {
    //�����Ǵ����ݿ��ȡ��ǰ����Ϣ
    //$all_chou=DB::fetch_all("SELECT * FROM " . DB::table('threed_choutime') ." WHERE tid=$tid ORDER BY ord ASC ");
    $query = DB::query("SELECT * FROM " . DB::table('threed_choutime') ." WHERE tid=$tid ORDER BY ord ASC ");
    while ($chou = DB::fetch($query)) {
        $all_chou[$chou['id']] = $chou;
    }
    include template('threed_chou:load');
}elseif ($_GET['ac'] == "addc") {
    $delnum=0;
    $addnum=0;
    $updatenum=0;
    //ɾ���������Ϣ
    //print_r($_GET['delete']);
    foreach ($_GET['delete'] as $key => $delid) { //ɾ����ѡ�˵�����
        $key = intval($key);
        if(DB::delete("threed_choutime", "id=$key"))$delnum++;
    }    
    //�����Ǵ�����������Ƶ
    $new_order_arr = !empty($_GET['neworder']) ? $_GET['neworder'] : array();
    $new_day_arr = !empty($_GET['newday']) ? $_GET['newday'] : array();
    $new_title_arr = !empty($_GET['newtitle']) ? $_GET['newtitle'] : array();
    $new_url_arr = !empty($_GET['newurl']) ? $_GET['newurl'] : array();
    $new_text_arr = !empty($_GET['newtext']) ? $_GET['newtext'] : array();

    foreach ($new_day_arr as $key => $value) { //��ʱ��Ϊ������������ʱ��Ϊ��
        $new_day = addslashes(trim($value));
        if ($value != '') {
            DB::insert("threed_choutime",array( //д���ݿ�
                'tid' => $tid,
                'day' => $new_day,
                'url' => addslashes(trim($new_url_arr[$key])),
                'title' => addslashes(trim($new_title_arr[$key])),
                'ord' => addslashes(trim($new_order_arr[$key])),
                'text' => addslashes(trim($new_text_arr[$key])),
                'time'=>$_G['timestamp']),true, true);
                $addnum++;
        }
    }
    //���洦���޸ĵ���Ƶ
    $id_arr = !empty($_GET['cid']) ? $_GET['cid'] : array();
    $order_arr = !empty($_GET['order']) ? $_GET['order'] : array();
    $day_arr = !empty($_GET['day']) ? $_GET['day'] : array();
    $title_arr = !empty($_GET['title']) ? $_GET['title'] : array();
    $url_arr = !empty($_GET['url']) ? $_GET['url'] : array();
    $text_arr = !empty($_GET['text']) ? $_GET['text'] : array();
    foreach ($day_arr as $id => $value) {
        $day = addslashes(trim($value));
        if (DB::result_first("SELECT count(1) FROM " . DB::table('threed_choutime') .
            " WHERE id='$id'")&&$value) {
            //����cid�Ƿ�ɾ����ɾ���Ͳ�Ҫ��
            $updata_chou = array(
                'day' => $day,
                'url' => addslashes(trim($url_arr[$id])),
                'title' => addslashes(trim($title_arr[$id])),
                'ord' => addslashes(trim($order_arr[$id])),
                'text' => addslashes(trim($text_arr[$id])));
            DB::update("threed_choutime", $updata_chou, 'id='.$id);
            $updatenum++;
        }
    }
    $msg=lang('plugin/threed_chou', 'load1').$addnum .lang('plugin/threed_chou', 'load2').$updatenum .lang('plugin/threed_chou', 'load3').$delnum .lang('plugin/threed_chou', 'load4');
 showmessage($msg, "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'info'));
}elseif ($_GET['ac'] == "del") {
    $delnum=0;
            if(DB::delete("threed_choutime", "tid=$tid"))$delnum++;
            if($delnum){
                showmessage(lang('plugin/threed_chou', 'load7'), "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'info'));
            }else{
                 showmessage(lang('plugin/threed_chou', 'load8'), "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'info'));
            }
            
  
}else{
    showmessage(lang('plugin/threed_chou', 'load8'), "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'info'));
}
//TODO - Insert your code here


?>