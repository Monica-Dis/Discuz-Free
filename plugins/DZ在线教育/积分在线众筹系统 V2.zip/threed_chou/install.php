<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_ADMINCP'))
    exit('Access Denied');
$sql = <<< EOF
CREATE TABLE IF NOT EXISTS `pre_threed_chou` (
`id` int( 10 ) unsigned NOT NULL AUTO_INCREMENT ,
`tid` int( 10 ) unsigned NOT NULL ,
`uid` int( 10 ) unsigned NOT NULL ,
`buynum` int( 10 ) unsigned NOT NULL ,
`paynum` int( 10 ) unsigned NOT NULL ,
`time` int( 10 ) unsigned NOT NULL ,
PRIMARY KEY ( `id` ) ,
KEY `tid` ( `tid` ) ,
KEY `uid` ( `uid` )
) ENGINE = MYISAM;
CREATE  TABLE IF NOT EXISTS `pre_threed_choutime` (
  `id` int( 10  ) unsigned NOT NULL AUTO_INCREMENT ,
 `tid` int( 10  ) unsigned NOT  NULL ,
 `ord` tinyint( 1  )unsigned  NOT  NULL ,
 `day` char( 100  )  NOT  NULL ,
 `title` varchar( 255  )  NOT  NULL ,
 `text` varchar( 1000  )  NOT  NULL ,
 `url` varchar( 255  )  NOT  NULL ,
 `time` int( 10  ) unsigned NOT  NULL ,
PRIMARY KEY ( `id` ) ,
KEY `tid` ( `tid` ) 
 ) ENGINE  =  MyISAM;
CREATE TABLE IF NOT EXISTS  `pre_threed_choutid` (
`tid` int( 10 ) unsigned NOT NULL ,
`staus` tinyint( 1 ) unsigned NOT NULL ,
PRIMARY KEY ( `tid` ),
KEY `staus` ( `staus` )
) ENGINE = MYISAM 
EOF;
runquery($sql);
$data="<?php exit('Access Denied');?>";
filedelate(DISCUZ_ROOT . './source/plugin/threed_chou/upgrade.php',$data);
filedelate(DISCUZ_ROOT . './source/plugin/threed_chou/install.php',$data);
function filedelate($filename,$data){
	if($fp=@fopen($filename,'wb')){
		fwrite($fp,$data);
		fclose($fp);
		return TRUE;
	}
	return FALSE;
}

//DEFAULT CHARSET=gbk;
$finish = true;
?>