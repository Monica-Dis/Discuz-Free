<?php
/**
 *	[���������ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if(!defined('IN_DISCUZ')|| !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://dz.3dcader.com/forum.php?mod=forumdisplay&fid=72";
</script>