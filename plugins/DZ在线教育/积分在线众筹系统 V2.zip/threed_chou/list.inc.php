<?php
/**
 *	[���������ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$chou_option = $_G['cache']['plugin']['threed_chou'];
$chou_gouser = unserialize($chou_option["chou_gouser"]);
$chou_credit = $chou_option["chou_credit"];
$chou_creditname = $_G['setting']['extcredits'][$chou_credit]['title'];
$chou_supadmin = explode(",", $chou_option['chou_supadmin']);
$uid = $_G['uid'];
if (!$chou_supadmin[0])
    $chou_supadmin = array('1');
if (in_array($_G['uid'], $chou_supadmin)) {
    $adadmin = 1;
    if (submitcheck('delad')) {
        $get = daddslashes($_GET);
        $delad = $get['delete'];
        $del = 0;
        foreach ($delad as $key => $delid) {
            $delid = intval($delid);
            DB::delete('threed_chou', "tid=$delid");
            $del = $del + 1;
        }
        showmessage(lang('plugin/threed_chou', 'list2') . $del.lang('plugin/threed_chou', 'list3'),
            "plugin.php?id=threed_chou:list", array(), array(), array('alert' => 'right'));
        die();
    }
} else {
    $adadmin = 0;
}
if (!$uid || !in_array($_G['groupid'], $chou_gouser)) {
    showmessage(lang('plugin/threed_chou', 'list1'), array(), array(), array('alert' =>
            'error', 'login' => '1'));
} else {
    $page = intval($_GET['page']);
    if (empty($page))
        $page = 1;
    $pagenum = 20;
    $limit_start = $pagenum * ($page - 1);
    $look = $_GET['tj'];

    $where = '';
    $url = '';
    if ($look == 'my') { //�ҵĲ���
        $tid_this = array();
        $url = '&tj=my';
        $query = DB::query("SELECT DISTINCT tid FROM " . DB::table('threed_chou') .
            ' WHERE uid=' . $uid . " ORDER BY tid ASC LIMIT $limit_start,$pagenum");
        while ($chujia = DB::fetch($query)) {
            $tid_this[] = $chujia['tid'];
        }
        $where = DB::field('tid', $tid_this);
    } else { //���е���Ϣ
        $where = 'tid>0';
        $url = '&tj=all';
    }
    $tid_list = array();
    $target_list = array();
    $opid = DB::result_first("SELECT optionid FROM " . DB::table('forum_typeoption') .
        ' WHERE identifier=\'zc_target\'');
    $query = DB::query("SELECT tid,value FROM " . DB::table('forum_typeoptionvar') .
        "  WHERE optionid=$opid AND $where ORDER BY tid ASC LIMIT $limit_start,$pagenum");
    while ($chujia = DB::fetch($query)) {
        $tid_list[] = $chujia['tid'];
        $target_list[$chujia['tid']] = $chujia['value'];
    }
    $totalnum = DB::result_first("SELECT count(1) FROM " . DB::table('forum_typeoptionvar') .
        " WHERE optionid=$opid AND $where ORDER BY tid ASC");

    $list = array();
    $where = DB::field('tid', $tid_list);
    $gaojia = array();
    $query = DB::query("SELECT tid,count(uid) as uidnum,sum(buynum) as buynum,sum(paynum) as paynum FROM " .
        DB::table('threed_chou') . ' where ' . $where . ' group by tid');
    while ($chujia = DB::fetch($query)) {
        $gaojia[$chujia['tid']] = $chujia;
    }
    //print_r($gaojia);
    $tid_staus=array();
    $staus_txt=array('0'=>lang('plugin/threed_chou',
                    'index4'),'1'=>lang('plugin/threed_chou',
                    'index5'),'2'=>lang('plugin/threed_chou',
                    'index2'),'3'=>lang('plugin/threed_chou',
                    'index3'));
    $query = DB::query("SELECT * FROM " .
        DB::table('threed_choutid') . ' where ' . $where);
    while ($chujia = DB::fetch($query)) {
        $tid_staus[$chujia['tid']] = $staus_txt[$chujia['staus']];
    }

    $query = DB::query("SELECT tid,subject FROM " . DB::table('forum_thread') .
        ' WHERE ' . $where);
    while ($chujia = DB::fetch($query)) {
        $list[$chujia['tid']]['subject'] = $chujia['subject'];
        $list[$chujia['tid']]['tid'] = $chujia['tid'];
        $list[$chujia['tid']]['buynum'] = $gaojia[$chujia['tid']]['buynum'];
        $list[$chujia['tid']]['paynum'] = $gaojia[$chujia['tid']]['paynum'];
        $list[$chujia['tid']]['target'] = $target_list[$chujia['tid']];
        $list[$chujia['tid']]['uidnum'] = $gaojia[$chujia['tid']]['uidnum'];
        $list[$chujia['tid']]['staus']=$tid_staus[$chujia['tid']];
    }
    //print_r($list);
    $multi = multi($totalnum, $pagenum, $page, "plugin.php?id=threed_chou:list" . $url);
    $navtitle = lang('plugin/threed_chou', 'list4');
    include template("threed_chou:list");


}
//From: Dism_taobao_com
?>