<?php
/**
 *	[���������ڳ�ϵͳ(threed_chou.{modulename})] (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$chou_option = $_G['cache']['plugin']['threed_chou'];
$chou_gouser = unserialize($chou_option["chou_gouser"]);
$chou_credit = $chou_option["chou_credit"];
$chou_creditname = $_G['setting']['extcredits'][$chou_credit]['title'];
$tid = intval($_GET['tid']);
$uid = $_G['uid'];
$num = intval($_GET['num']);
$num = $num > 0 ? $num : 1;
$chou_price = (intval($_GET['gg']) - 131) / 91 - 3;
if (!is_int($chou_price) || $chou_price <= 0 || !$tid || $_GET['formhash'] !=
    FORMHASH)
    showmessage(lang('plugin/threed_chou', 'payfor2'), array(), array(), array('alert' =>
            'error'));
$chou_topay = $chou_price * $num;
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pramga: no-cache");
if (!in_array($_G['groupid'], $chou_gouser)) {
    showmessage($chou_option['chou_read'], '', array(), array('alert' => 'info'));
    die();
}
if (!$uid) {
    showmessage(lang('plugin/threed_chou', 'payfor3'), '', array(), array('alert' =>
            'info', 'login' => '1'));
}
$user_creditnum = DB::result_first("select extcredits" . $chou_credit . " from " .
    DB::table('common_member_count') . " where uid=" . $uid);
$buy_username = DB::result_first("select username from " . DB::table('common_member') .
    " where uid=" . $uid);
if ($_GET['ac'] == "buy") {
    $yuxia = $user_creditnum - $chou_topay;
    $buycount = DB::result_first('SELECT count(1) FROM ' . DB::table('threed_chou') .
        ' WHERE tid=' . $tid . ' and uid=' . $uid);
    include template('threed_chou:pay');
}
if ($_GET['ac'] == "pay") {
    if ($user_creditnum < $chou_topay) {
        showmessage($chou_option['chou_bugou'], array(), array(), array('alert' => 'info'));
    }
    $svaebuy = array(
        'uid' => $uid,
        'tid' => $tid,
        'time' => $_G['timestamp'],
        'buynum' => $num,
        'paynum'=>$chou_topay);
    $id = DB::insert("threed_chou", $svaebuy, false, true);
    $saleid=DB::result_first('SELECT authorid FROM '.DB::table('forum_thread').' WHERE tid='.$tid);
    updatemembercount($uid, array('extcredits' . $chou_credit => '-' . $chou_topay), true,
        'BTC', $tid);
    showmessage(lang('plugin/threed_chou', 'payfor4'),
        "forum.php?mod=viewthread&tid=$tid", array(), array(), array(
        'alert' => 'right',
        'showdialog' => 1,
        'locationtime' => false));
} else {
    showmessage(lang('plugin/threed_chou', 'payfor2'), array(), array(), array('alert' =>
            'error'));
}
//From: Dism_taobao_com
?>