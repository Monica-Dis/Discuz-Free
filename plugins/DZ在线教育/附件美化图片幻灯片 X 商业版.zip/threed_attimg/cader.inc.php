<?php
/**
 *	[����ѡ�(threed_attimg.{modulename})] Copyright (c) 2020 by dism.taobao.com
 *	Version: ��ҵ��
 *	Date: 2014-11-7 19:49
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
?>
<script type="text/javascript">
window.location.href="http://dism.taobao.com/?@41545.developer";
</script>