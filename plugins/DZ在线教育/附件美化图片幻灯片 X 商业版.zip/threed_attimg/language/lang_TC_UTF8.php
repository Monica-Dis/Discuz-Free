<?php
/**
 *	[帖內選項卡(threed_tab.{modulename})] (C)2014-2099 Powered by 3D設計者.
 *	Version: 商業版
 *	Date: 2014-11-7 19:49
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$tmp_lang = array(
    'imgguest' => '登錄/注冊后可看大圖',
    'attachdown' => '請點擊此處下載',
    'attachdownreg' => '請先注冊會員后在進行下載',
    'attachdownlogin' => '已注冊會員，請先登錄后下載',
    'attachname' => '文件名稱',
    'attachsize' => '文件大小',
    'attachprice' => '售價',
    'attachreadperm' => '下載權限',
    'attachdownloads' => '下載次數',
    'attachdown' => '請點擊此處下載',
    'attachdownreg' => '請先注冊會員后在進行下載',
    'attachdownlogin' => '已注冊會員，請先登錄后下載',
    'attachdownlogin_ok' => '您的用戶組是',
    'attachdownreg_pay' => '需要先購買才能下載',
    'attach3'=>'查看狀態：已購買或有權限',
    'attach4'=>'查看狀態：需購買或無權限',
    'attach5'=>'查看狀態：今天下載數已用完',
    'a1' => '免',
    'a2' => '立即下載',
    'a3' => '立即購買',
    'a4' => '無',
    'a5' => '請登陸后下載',
    'a6' => '請等待作者更新',
    'a7' => '請先登陸',
    'a8' => '暫無下載',
    'a9' => '私信',
    'a10' => '帖子',
    'a11' => '粉絲',
    'a12' => '帖子說明',
    'a13' => '評論',
    'a14' => '查看',
    'a15' => '收藏',
    'a16' => '已收藏',
    'mobile1' => '點擊下載',
    'mobile2' => '點擊購買',
    'mobile3' => '您今天的下載數已用完',
    'mobile4' => '您無權限下載',
    );
