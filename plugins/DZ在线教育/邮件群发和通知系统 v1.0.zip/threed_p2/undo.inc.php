<?php
/**
 *	[�ʼ�֪ͨ��Ⱥ��ϵͳ(threed_p2.{modulename})] (C)2015-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2017-11-18 12:12 
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

require_once libfile('function/threed','plugin/threed_p2');
global $_G;
$option=$_G['cache']['plugin']['threed_p2'];
$tui_user=unserialize($option['thd_tuiuser']);
require_once libfile('function/threed','plugin/threed_p2');
if(!$_G['uid']){
    showmessage(lang('plugin/threed_p2', 'undo1'), array(), array(), array('alert' => 'error','login' => '1'));
}elseif(in_array($_G['groupid'],$tui_user)){
    $saveok = DB::insert('threed_p2', array('uid'=>$_G['uid'],'dateline'=>$_G['timestamp']),true,true);
    showmessage(lang('plugin/threed_p2', 'undo2'), "index.php", array(), array(), array('alert' => 'info'));
}else{
    showmessage(lang('plugin/threed_p2', 'undo3'));
}