<?php
/**
 *	[�ʼ�֪ͨ��Ⱥ��ϵͳ(threed_p2.{modulename})] (C)2015-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2017-11-18 12:12 
 */
if (!defined('IN_ADMINCP')||!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
DB::query("DROP TABLE IF EXISTS ".DB::table('threed_p2')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('threed_p222')."");
//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>