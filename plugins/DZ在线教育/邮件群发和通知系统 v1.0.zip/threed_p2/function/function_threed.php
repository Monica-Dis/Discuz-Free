<?php

/**
 *	[3D�����ר�ú�����(threed_function.{modulename})] (C)2014-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('');
}

function make_request($url, $params, $timeout = 30)
{
    set_time_limit(0);
    $str = "";
    if ($params != "") {
        foreach ($params as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $kv => $vv) {
                    $str .= '&' . $k . '[' . $kv . ']=' . urlencode($vv);
                }
            } else {
                $str .= '&' . $k . '=' . urlencode($v);
            }
        }
    }
    if (function_exists('curl_init')) {
        // Use CURL if installed...
        $ch = curl_init();
        $header = array(
            'Accept-Language: zh-cn',
            'Connection: Keep-Alive',
            'Cache-Control: no-cache');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        if ($timeout > 0)
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $result = curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        return $result;
    } else {
        $context = array('http' => array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded' . "\r\n" .
                    'Content-length: ' . strlen($str),
                'content' => $str));
        if ($timeout > 0)
            $context['http']['timeout'] = $timeout;
        $contextid = stream_context_create($context);
        $sock = @fopen($url, 'r', false, $contextid);
        if ($sock) {
            $result = '';
            while (!feof($sock)) {
                $result .= fgets($sock, 8192);
            }
            fclose($sock);
        } else {
            return 'TimeOut';
        }
    }
    return $result;
}

function get_thread($fids, $type = true, $orders = 'dateline', $sort = 'DESC',
    $limit = 5, $start = 0)
{
    if (!empty($fids)) {
        $fids = dintval($fids, true);
        $wheresql = is_array($fids) && $fids ? 'fid IN(%n)' : 'fid=%d';
        //print_r($fids);
    } else {
        return;
    }
    if ($orders == 'digest') {
        $wheresql .= ' AND digest>0';
        $order = 'ORDER BY dateline';
    } else {
        $order = 'ORDER BY ' . DB::order($orders, $sort);
    }
    $data_arr = DB::fetch_all("SELECT tid,subject,dateline,lastpost,$orders FROM %t WHERE $wheresql $order " .
        DB::limit($start, $limit), array('forum_thread', $fids));
    
        $str = '<ul>';
        foreach ($data_arr as $value) {
            $value['dateline'] = dgmdate($value['dateline']);
            $value['lastpost'] = dgmdate($value['lastpost']);
            if ($type) {
            $str .= '<li><a href="forum.php?mod=viewthread&tid=' . $value['tid'] .
                '" target="_black">' . $value['subject'] . "[$value[dateline]]</a></li>";
                }else{
               $str .= "<li> $value[subject] [".$value['dateline']."]</li>";     
                }
        }
        $str .= '</ul>';
        return $str;
}

function get_artcle($type = true, $limit = 5, $start = 0)
{
    $data_arr = DB::fetch_all("SELECT aid,title,dateline FROM %t order by dateline " .
        DB::limit($start, $limit), array('portal_article_title'));
    //print_r($data_arr);
        $str = '<ul>';
        foreach ($data_arr as $value) {
            $value['dateline'] = dgmdate($value['dateline']);
            if ($type) {
            $str .= '<li><a href="portal.php?mod=view&aid=' . $value['aid'] .
                '" target="_black">' . $value['title'] . "[$value[dateline]]</a></li>";
                }else{
               $str .= "<li> $value[title] [$value[dateline]]</li>";
                }
        }
        $str .= '</ul>';
        return $str;
}
function replace_template($temp)
{
    global $_G;
    require_once libfile('function/cache');
    loadcache('plugin');
    $option = $_G['cache']['plugin']['threed_p2'];
    $option['thd_num']=$option['thd_num']?$option['thd_num']:5;
    $newsforum = unserialize($option['thd_newsforums']);
    $news_thread_str = get_thread($newsforum, $option['thd_url'], $orders = 'dateline',
        $sort = 'DESC', $tlimit = $option['thd_num'], $start = 0);
    $hot_thread_str = get_thread($newsforum, $option['thd_url'], $orders = 'views', $sort =
        'DESC', $tlimit = $option['thd_num'], $start = 0);
    $semen_thread_str = get_thread($newsforum, $option['thd_url'], $orders = 'digest', $sort =
        'DESC', $tlimit = $option['thd_num'], $start = 0);
    $news_artcle_str = get_artcle($option['thd_url'], $alimit = $option['thd_num'], $start =
        0);
    $temp = str_replace("{new_thread}", $news_thread_str, $temp);
    $temp = str_replace("{hot_thread}", $hot_thread_str, $temp);
    $temp = str_replace("{semen_thread}", $semen_thread_str, $temp);
    $temp = str_replace("{new_article}", $news_artcle_str, $temp);
    return $temp;
}
//From: Dism_taobao_com
?>