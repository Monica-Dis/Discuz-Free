<?php
/**
 *	[�ʼ�֪ͨ��Ⱥ��ϵͳ(threed_p2.{modulename})] (C)2015-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2017-11-18 12:12 
 */

if (!defined('IN_ADMINCP')||!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_threed_p2` (
`uid` int( 10 ) unsigned NOT NULL ,
`dateline` int( 10 ) unsigned NOT NULL ,
PRIMARY KEY ( `uid` )
) ENGINE = MYISAM;
CREATE TABLE IF NOT EXISTS `pre_threed_p222` (
`id` int( 10 ) unsigned NOT NULL AUTO_INCREMENT ,
`uid` int( 10 ) unsigned NOT NULL ,
`dateline` int( 10 ) unsigned NOT NULL ,
PRIMARY KEY ( `id` )
) ENGINE = MYISAM;
EOF;
runquery($sql);
$data="<?php exit('Access Denied');$finish = TRUE; ?>";
filedelate(DISCUZ_ROOT . './source/plugin/threed_p2/upgrade.php',$data);
filedelate(DISCUZ_ROOT . './source/plugin/threed_p2/install.php',$data);
function filedelate($filename,$data){
	if($fp=@fopen($filename,'wb')){
		fwrite($fp,$data);
		fclose($fp);
		return TRUE;
	}
	return FALSE;
}

//DEFAULT CHARSET=gbk;
$finish = TRUE;
?>