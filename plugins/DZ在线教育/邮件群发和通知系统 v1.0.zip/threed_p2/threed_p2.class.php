<?php
/**
 *	[�ʼ�֪ͨ��Ⱥ��ϵͳ(threed_p2.{modulename})] (C)2015-2099 Powered by 3D�����.
 *	Version: ��ҵ��
 *	Date: 2017-11-18 12:12 
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
class plugin_threed_p2 {	
    public function post_message($params) {
	global $_G , $tid , $returnurl , $subject;
	$option=$_G['cache']['plugin']['threed_p2'];		
	if(!in_array($_G['fid'],unserialize($option['thd_notforums']))){
	 		return ;
	 	}
	if(!$params) return;  
	    $param = $params['param'];
	    if($param[0] == 'post_newthread_succeed'&&$option['thd_newt']) {
		 	$moderator = DB::fetch_all("SELECT a.uid,c.email FROM ".DB::table('forum_moderator')." a LEFT JOIN ".DB::table('common_member')." c  on a.uid=c.uid WHERE a.fid =%d ",array($_G['fid']));
            
            require_once libfile('function/threed','plugin/threed_p2');
            require_once   libfile('function/mail');
			if(!empty($moderator)){
			 $temp_notice=replace_template($option['thd_notice']);
             $mssage=$option['thd_newt']. '<a href="forum.php?mod=viewthread&tid='.$tid.'">'.$subject.'</a>';
             $temp_notice=str_replace("{message_info}", $mssage, $temp_notice);
				foreach($moderator as $value){
				notification_add($value['uid'], 'system', $mssage, array(), 1);
                if (isset($_G['setting']['mail'])) {
                    sendmail($value['email'], $option['thd_nottitle'], $temp_notice, '');
                    }
				}
		   }			
		}
        if($param[0] == 'post_reply_succeed'&&$option['thd_newh']) {
            
			 //����Ϣ���͸�¥��
             require_once libfile('function/threed','plugin/threed_p2');
            require_once   libfile('function/mail');
            
		 	$tid_author = DB::result_first("SELECT authorid FROM %t WHERE tid =%d ",array('forum_thread',$_G['tid']));
             $temp_notice=replace_template($option['thd_notice']);
             $mssage=$option['thd_newh']. '<a href="forum.php?mod=viewthread&tid='.$_G['tid'].'">'.$subject.'</a>';
             $temp_notice=str_replace("{message_info}", $mssage, $temp_notice);
                if (isset($_G['setting']['mail'])) {
                    $sendtoemail = DB::result_first("SELECT email FROM " . DB::table('common_member') . " WHERE uid='$tid_author'");
                    sendmail($sendtoemail, $option['thd_nottitle'], $temp_notice, '');
                    }
				
		   			
		}
	}

}
class plugin_threed_p2_home extends plugin_threed_p2 {
	function  spacecp_profile_extra() {
	global $_G;
		return "<a class=\"pn pnc\" style=\"overflow: hidden; line-height: 40px; padding: 5px; color:#fff\" href=\"plugin.php?id=threed_p2:undo\">".lang('plugin/threed_p2', 'undo4')."</a>".lang('plugin/threed_p2', 'undo5');
	}
}

class plugin_threed_p2_forum extends plugin_threed_p2 {}
