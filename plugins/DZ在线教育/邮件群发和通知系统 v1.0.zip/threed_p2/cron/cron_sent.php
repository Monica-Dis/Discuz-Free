<?php
//cronname:threed_day_updata
//hour:2
//minute:0

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

require_once libfile('function/threed','plugin/threed_p2');
global $_G;
require_once libfile('function/cache');
loadcache('plugin');

$option=$_G['cache']['plugin']['threed_p2'];
$news_user=unserialize($option['thd_fauser']);
$user_up=DB::result_first('SELECT uid FROM '.DB::table('threed_p222').' order by dateline DESC');
$user_up=$user_up?$user_up:1;
$dateline_up=DB::result_first('SELECT dateline FROM '.DB::table('threed_p222').' where uid=1 order by dateline DESC');
$dateline_up=$dateline_up?$dateline_up:0;
$option['thd_round']=$option['thd_round']?$option['thd_round']:30;
if($_G['timestamp']-$dateline_up>$option['thd_round']*24*60*60){
    $saveok = DB::insert('threed_p222', array('uid'=>1,'dateline'=>$_G['timestamp']), true, true);
    $user_up=1;
}

$where='c.uid>'.$user_up.' AND '.DB::field('groupid', $news_user);
//print_r($user_sum);
if(	$option['thd_email']){
    $where.=' and c.emailstatus>0';
}
if($option['thd_day']){
    $option['thd_day']=$_G['timestamp']-$option['thd_day']*24*60*60;
    $where.=' and s.lastvisit<'.$option['thd_day'];
}
if($option['thd_thread']){
    $where.=' and s.lastpost>0';
}

$option['thd_emailnum'] =$option['thd_emailnum']<200&&$option['thd_emailnum']>0? $option['thd_emailnum']:50;

$user_list= DB::fetch_all('SELECT c.uid,c.username,c.email FROM '.DB::table('common_member')." c left join ".DB::table('common_member_status')." s on c.uid=s.uid WHERE $where LIMIT 0,$option[thd_emailnum]");
if(empty($user_list)){
    //cpmsg('&#24403;&#21069;&#21608;&#26399;&#24050;&#23436;&#25104;', "", 'succeed');
    //echo '���޿�ִ�е����䷢������';
    exit();
}
$user_tuilist=DB::fetch_all('SELECT uid FROM '.DB::table('threed_p2'));

//print_r($user_list);

$temp_notice=replace_template($option['thd_model']);
//print_r($temp_notice);
require_once   libfile('function/mail');

if (isset($_G['setting']['mail'])) {
    $abc=0;
    $frommail=unserialize($_G['setting']['mail']);
    $mailnum=count($frommail['smtp']);
    
//$frommail['smtp'][$mailn]['from'];
foreach($user_list as $user_arr){
    //$saveok = DB::insert('threed_p2', array('uid'=>$_G['uid'],'dateline'=>$_G['timestamp']),true,true);
    $mailn=$abc%$mailnum;
    if(!in_array(array('uid'=>$user_arr['uid']),$user_tuilist)){ 
    $temp_notice=str_replace("{username}",$user_arr['username'] , $temp_notice);
    $abc+=sendmail($user_arr['email'], $option['thd_daytitle'], $temp_notice, $frommail['smtp'][$mailn]['from']);
    //echo $abc;
    //echo '���ʼ���'.$user_arr['email'];
    }
}
if($endarr=end($user_list)){
    $saveok = DB::insert('threed_p222', array('uid'=>$user_arr[uid],'dateline'=>$_G['timestamp']), true, true);
    //cpmsg('���޿�ִ�е����䷢������', "", 'succeed'); '�ʼ��������';
}
}