<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$uid = $_G['uid'];

if(!$uid){
    showmessage(lang('plugin/threed_vip', 'p2'), array(), array(), array('alert' => 'error','login' => '1'));
}
$pay_option = $_G['cache']['plugin']['threed_vip'];
$pay_bili=$pay_option['pay_bili']/100;
$pay_credit = $pay_option['pay_credit'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
$groupname=$_G['group']['grouptitle'];
$groupid=$_G['groupid'];
require_once libfile('function/threed','plugin/threed_vip');
$vip_rule=getviprule();
if (submitcheck('advsubmit')) {
    //echo "�������ύ2";
    $get = daddslashes($_GET);
    $kid=intval($_GET['vipkid']);
    $gid=$vip_rule[$kid]['gid'];
    $payway=intval($_GET['payway']);
    $paynum=intval($_GET['paynum']);
    if ($gid == $groupid) {
        showmessage(lang('plugin/threed_vip', 'sv1'), "plugin.php?id=threed_vip", array(), array(), array('alert' => 'info'));
    }
    if($get['payaccount']==''){
        showmessage(lang('plugin/threed_vip', 'p3'), array(), array(), array('alert' => 'error','login' => '1'));
    }
$svaebuy = array(
        'uid' => $uid,
        'groupid'=>$kid,
        'paynum'=>$paynum,
        'way'=>$payway,
        'account'=>$get['payaccount'],
        'order'=>$get['payorder'],
        'status'=>1,
        'time'=>$_G['timestamp']
        );
    $saveok = DB::insert('threed_vip', $svaebuy, true, true);
    if ($saveok) {
        showmessage(lang('plugin/threed_vip', 'p4'), "plugin.php?id=threed_vip:list", array(), array(),
            array('alert' => 'right'));
    }else{
        showmessage(lang('plugin/threed_vip', 'p5'), "plugin.php?id=threed_vip:list", array(), array(),
            array('alert' => 'right'));
    }
    die();
}
$pay_option['pay_weixin']=$pay_option['pay_weixin']?$pay_option['pay_weixin']:'source/plugin/threed_vip/template/images/weixin_erm.jpg';
$pay_option['pay_aliimg']=$pay_option['pay_aliimg']?$pay_option['pay_aliimg']:'source/plugin/threed_vip/template/images/alipay_erm.jpg';
$pay_title = $pay_option['pay_title'];
$pay_info=$pay_option['pay_info'];
if(!stripos($pay_info,'table')){
    $pay_info='<img src="'.$pay_option['pay_info'].'" />';
}
$navtitle = $pay_title;
include template("threed_vip:index");


?>