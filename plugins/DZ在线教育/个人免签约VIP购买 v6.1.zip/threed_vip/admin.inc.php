<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$uid = $_G['uid'];
if (!$uid) {
    showmessage(lang('plugin/threed_vip', 'p2'), array(), array(), array('alert' =>
            'error', 'login' => '1'));
}

$pay_option = $_G['cache']['plugin']['threed_vip'];
$pay_credit = $pay_option['pay_credit'];
$pay_song=$pay_option['pay_song'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
$pay_supadmin = explode(",", $pay_option['pay_admin']);
if (empty($pay_supadmin))
    $pay_supadmin = array('1');
if (in_array($uid, $pay_supadmin)) {
    $adadmin = 1;
} else {
    $adadmin = 0;
}
if (!$adadmin || $_GET['formhash'] != FORMHASH) {
    showmessage(lang('plugin/threed_vip', 'p6'), array(), array(), array('alert' =>
            'info'));
    die();
}
$pay_id = intval($_GET['p']);
$pay_ac = intval($_GET['ac']);
$pay_info = DB::fetch_first("SELECT id,groupid,uid FROM " . DB::table('threed_vip') .
    ' WHERE id=' . $pay_id);
if ($pay_info['uid']==1) {
    showmessage('&#24403;&#21069;&#29992;&#25143;&#26159;&#31649;&#29702;&#21592;&#65292;&#19981;&#20801;&#35768;&#20999;&#25442;&#29992;&#25143;', array(), array(), array('alert' =>
            'error', 'login' => '1'));
}
require_once libfile('function/threed', 'plugin/threed_vip');
$vip_rule = getviprule();
$kid = $pay_info['groupid'];
$gid=$vip_rule[$kid]['gid'];
if (($pay_ac == 2 || $pay_ac == 3) && $pay_info['id'] && !empty($vip_rule[$kid])) {
    $saveok = DB::update('threed_vip', array('status' => $pay_ac), array('id' => $pay_info['id']));
    if ($saveok) {
        if ($gid && $pay_info['uid'] && $pay_ac == 2) {
            $vipday = $vip_rule[$kid]['time']?strtotime($vip_rule[$kid]['time'] . ' days'):0;
            DB::update('common_member', array('groupid' => $gid, 'groupexpiry' => $vipday),
                "uid=".$pay_info['uid']);
                if($vipday){
                    $s['main'] = array('time' => $vipday, 'ext' => $vipday);
                    $savevip = serialize($s);
                    DB::update('common_member_field_forum', array('groupterms' => $savevip), "uid=".$pay_info['uid']);
                }
            $note=lang('plugin/threed_vip', 'sv5').$vip_rule[$kid]['name'].lang('plugin/threed_vip', 'sv6');
            notification_add($pay_info['uid'], 'system', $note, array(), 1);
            if ($vip_rule[$kid]['reward'] > 0) {
                updatemembercount($pay_info['uid'], array('extcredits' . $pay_song => $vip_rule[$kid]['reward']), true,
                    'AFD', $pay_info['uid']);
            }
        }
        showmessage(lang('plugin/threed_vip', 'p7'), "plugin.php?id=threed_vip:list",
            array(), array(), array('alert' => 'right'));

    } else {
        showmessage(lang('plugin/threed_vip', 'p8'), array(), array(), array('alert' =>
                'error'));
        die();
    }
} else {
    showmessage(lang('plugin/threed_vip', 'p9'), array(), array(), array('alert' =>
            'error'));
    die();
}
//From: Dism��taobao��com
?>