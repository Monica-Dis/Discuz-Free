<?php
/**
 *	[���ֹ�����������(threed_vip.{modulename})] Ӧ�ø���֧�֣�https://dism.taobao.com
 *	���²����http://t.cn/Aiux1Jx1
 *	Date: 2014-12-3 21:54
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$pay_option = $_G['cache']['plugin']['threed_vip'];
$pay_bili = $pay_option['pay_bili'] / 100;
$pay_credit = $pay_option['pay_credit'];
$pay_song=$pay_option['pay_song'];
$pay_credit_name = $_G['setting']['extcredits'][$pay_credit]['title'];
$uid = $_G['uid'];
$kid = intval($_GET['kid']);
require_once libfile('function/threed', 'plugin/threed_vip');
$vip_rule = getviprule();
$gid=$vip_rule[$kid]['gid'];
if ($_GET['formhash'] != FORMHASH || !$gid || !$uid || empty($vip_rule[$kid]))
    showmessage(lang('plugin/threed_vip', 'p2'), array(), array(), array('alert' =>
            'error', 'login' => 1));
$pay_price = $vip_rule[$kid]['price']*$pay_bili;
$groupname = $_G['group']['grouptitle'];
$groupid = $_G['groupid'];
$user_creditnum = DB::result_first("select extcredits" . $pay_credit . " from " .
    DB::table('common_member_count') . " where uid=" . $uid);
$buy_username = $_G['username'];
if ($_GET['ac'] == "buy") {
    $yuxia = $user_creditnum - $pay_price;
    include template('threed_vip:pay');
}
if ($_GET['ac'] == "pay") {
    if ($gid == $_G['groupid']||$uid==1) {
        showmessage(lang('plugin/threed_vip', 'sv1'), "plugin.php?id=threed_vip", array(), array(), array('alert' => 'info'));
    }
    if ($user_creditnum <= $pay_price) {
        showmessage(lang('plugin/threed_vip', 'sv2') . $pay_credit_name . lang('plugin/threed_vip', 'sv3'), array(), array(), array('alert' =>
                'info'));
    }
    $vipday = strtotime($vip_rule[$kid]['time'] . ' days');
    $s['main'] = array('time' => $vipday, 'ext' => $vipday);
    $savevip = serialize($s);
    $id = DB::update('common_member', array('groupid' => $gid, 'groupexpiry' =>
            $vipday), "uid=$uid");
    $id = DB::update('common_member_field_forum', array('groupterms' => $savevip),
        "uid='$uid'");
    if ($id) {
        updatemembercount($uid, array('extcredits'. $pay_credit=> '-' . $pay_price),true,'UGP',$gid);
        if ($vip_rule[$kid]['reward'] > 0) {
            updatemembercount($uid, array('extcredits'. $pay_song=> $vip_rule[$kid]['reward']),true,'AFD',$uid);
        }
        $svaebuy = array(
        'uid' => $uid,
        'groupid'=>$kid,
        'paynum'=>$pay_price,
        'way'=>4,
        'account'=>$uid,
        'order'=>'',
        'status'=>2,
        'time'=>$_G['timestamp']
        );
    $saveok = DB::insert('threed_vip', $svaebuy, true, true);
        showmessage(lang('plugin/threed_vip', 'sv4'), "plugin.php?id=threed_vip", array(), array(), array('alert' => 'info'));
    } else {
        showmessage(lang('plugin/threed_vip', 'p8'), "plugin.php?id=threed_vip",
            array(), array(), array('alert' => 'info'));
    }
}else{
    showmessage(lang('plugin/threed_vip', 'p2'), array(), array(), array('alert' =>
            'error', 'login' => 1));
}
//From: Dism��taobao��com
?>