<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

//��������lib�ļ�����

loadcache(array('forums','posttable_info'));

require_once libfile('function/attachment');
require_once libfile('function/discuzcode');
require_once libfile('function/misc');

if(empty($_G['cache']['plugin']['aurora_content_control']['cloudimgurl'])){
	$imgurl = $_G['setting']['attachurl'];
}else{
	$imgurl = $_G['cache']['plugin']['aurora_content_control']['cloudimgurl'];
}

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);
$clearloggroup = unserialize($_G['cache']['plugin']['aurora_content_control']['clearloggroup']);

$posttables = array_keys($_G['cache']['posttable_info']);

if(empty($posttables)){
	$posttables = array(0);
}

foreach ($posttables as $id) {
	$id = intval($id);
	$tables[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
}

if($_GET['searchtype'] == -1){
	$operatetimestatus = 'operatetime = 0';
}else{
	$operatetimestatus = 'operatetime > 0';
}

if(!empty($_GET['search'])){
	if(intval($_GET['searchtype']) == 0){
		$field = 'npid';
	}else{
		$field = 'ntid';
	}
	$search = 'AND '.DB::field($field,intval($_GET['search']));
}else{
	$search = '';
}

if(!empty($_GET['checkexpire'])){
	$checkexpire = 'AND (operatetime - ndateline) > '.intval($_G['cache']['plugin']['aurora_content_control']['checkexpire'] * 60);
}else{
	$checkexpire = '';
}

//���岿��

$amount = DB::result_first('SELECT count(*) FROM %t WHERE %i %i %i', array('aurora_content_control',$operatetimestatus,$search,$checkexpire));

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

$source = DB::fetch_all('SELECT * FROM %t WHERE %i %i %i ORDER BY ndateline DESC LIMIT %d , %d', array('aurora_content_control',$operatetimestatus,$search,$checkexpire,$startlimit,$pagesize),'npid');

$lognum = DB::result_first('SELECT count(*) FROM %t WHERE operatetime > 0', array('aurora_content_control'));

foreach($source as $k => $v){
	$uids[$k] = $v['operatorid'];
	$operatetime[$k] = $v['operatetime'];
	$edittime[$k] = $v['edittime'];
}

$username = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member',$uids),'uid');

$pidsforquery = array_keys($source);

$rs = $query = array();

foreach ($tables as $table) {
	$query = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n)', array($table,$pidsforquery),'pid');
	$rs = $rs + $query;
}

krsort($rs);

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:checklog", $pagecount);   // ��ʾ��ҳ


include template("aurora_content_control:checklog");


?>