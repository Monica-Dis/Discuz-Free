<?php
if((!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))){  
    exit('Access Denied');  
}

$sql = <<<EOF
DROP TABLE pre_aurora_content_control;
EOF;

runquery($sql);

$finish = TRUE;
?>