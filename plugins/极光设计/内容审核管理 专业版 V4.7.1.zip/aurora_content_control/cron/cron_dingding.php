<?php  

//cronname:aurora_content_control_dingding
//minute:0,5,10,15,20,25,30,35,40,45,50,55

if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}

loadcache('plugin');

if(!empty($_G['cache']['plugin']['aurora_content_control']['dingding_alerttime'])){
	$dingding_alerttime = explode('-',$_G['cache']['plugin']['aurora_content_control']['dingding_alerttime']);
}else{
	$dingding_alerttime[0] = '0:00';
	$dingding_alerttime[1] = '23:59';
}

$timenow =  date('H:i',$_G['timestamp']);

$timeoutline = $_G['timestamp'] - 60 * intval($_G['cache']['plugin']['aurora_content_control']['dingding_timeline']);

if(intval($_G['cache']['plugin']['aurora_content_control']['dingding_alert']) > 0 && $timenow >= $dingding_alerttime[0] && $timenow <= $dingding_alerttime[1]){

	$count['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE status = 0', array('forum_thread_moderate'));
	$count['post'] = DB::result_first('SELECT count(*) FROM %t WHERE status = 0', array('forum_post_moderate'));
	
	$timeout['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE status = 0 AND dateline < %d', array('forum_thread_moderate',$timeoutline));
	$timeout['post'] = DB::result_first('SELECT count(*) FROM %t WHERE status = 0 AND dateline < %d', array('forum_post_moderate',$timeoutline));
	
	$dingding['thread'] = array_keys(DB::fetch_all('SELECT * FROM %t WHERE status = 0 AND dateline < %d Limit 0,10', array('forum_thread_moderate',$timeoutline),'id'));
	
	$dingding['post'] = array_keys(DB::fetch_all('SELECT * FROM %t WHERE status = 0 AND dateline < %d Limit 0,10', array('forum_post_moderate',$timeoutline),'id'));
	
	
	$dingdingtids = implode('&dingdingtids[]=',$dingding['thread']);
	if(!empty($dingdingtids)){
		$dingdingtids = '&dingdingtids[]='.$dingdingtids;
	}
	

	$dingdingpids = implode('&dingdingpids[]=',$dingding['post']);
	if(!empty($dingdingpids)){
		$dingdingpids = '&dingdingpids[]='.$dingdingpids;
	}
	
	$count['all'] = array_sum($count);
	$timeout['all'] = array_sum($timeout);
	
	function request_by_curl($remote_server, $post_string) {  
		$ch = curl_init();  
		curl_setopt($ch, CURLOPT_URL, $remote_server);
		curl_setopt($ch, CURLOPT_POST, 1); 
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, array ('Content-Type: application/json;charset=utf-8'));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
		// ���»������ÿ���curl֤����֤, δ��ͨ����ɳ������Ӹô���
		curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0); 
		curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$data = curl_exec($ch);
		curl_close($ch);  
				   
		return $data;  
	}  
	
	$webhook = $_G['cache']['plugin']['aurora_content_control']['dingding_webkook'];
	
	if($count['all'] >= intval($_G['cache']['plugin']['aurora_content_control']['dingding_moderatepostnum'])){
		
		$message = lang('plugin/aurora_content_control', 'uncheckalarm_dingding',array(postallnum => $count['all'],threadnum => $count['thread'],postnum => $count['post'],alarmtime =>dgmdate($_G['timestamp'],'Y-m-d H:i:s',8)));
		
		if(CHARSET == 'gbk'){
			$message = diconv($message, 'gbk', 'utf-8');
			$title = diconv(lang('plugin/aurora_content_control', 'alarm'), 'gbk', 'utf-8');
		}
		
		$data = array ('msgtype' => 'link','link' => array ('text' => $message,'title' => $title,'picUrl' => '','messageUrl' => $_G['siteurl'].'plugin.php?id=aurora_content_control:moderate&forumtag=select&selectform=-1'));
		$data_string = json_encode($data);
		 
		$result = request_by_curl($webhook, $data_string);  
		
		echo $result;
		
	}
	
	if($timeout['all'] > 0){
		
		$message = lang('plugin/aurora_content_control', 'overtimealarm_dingding',array(timeoutthread => $timeout['thread'],timeoutpost => $timeout['post'],overtime => intval($_G['cache']['plugin']['aurora_content_control']['dingding_timeline']),alarmtime => dgmdate($_G['timestamp'],'Y-m-d H:i:s',8)));
		
		if(CHARSET == 'gbk'){
			$message = diconv($message, 'gbk', 'utf-8');
			$title = diconv(lang('plugin/aurora_content_control', 'alarm'), 'gbk', 'utf-8');
		}
		
		$data = array ('msgtype' => 'link','link' => array ('text' => $message,'title' => $title,'picUrl' => '','messageUrl' => $_G['siteurl'].'plugin.php?id=aurora_content_control:moderate&forumtag=select&selectform=-1'.$dingdingtids.$dingdingpids));
		$data_string = json_encode($data);
		 
		$result = request_by_curl($webhook, $data_string);  
		
		echo $result;
		
	}

}

//From: Dism_taobao-com
?>