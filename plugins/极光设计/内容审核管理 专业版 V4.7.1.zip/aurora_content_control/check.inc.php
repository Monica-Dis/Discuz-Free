<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$sforumsoperator = unserialize($_G['cache']['plugin']['aurora_content_control']['sforumsoperator']);
$sforumsuid = explode(',',$_G['cache']['plugin']['aurora_content_control']['sforumsuid']);
$othername['check'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['check_name']);
$othername['moderate'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['moderate_name']);
$othername['report'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['report_name']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}                        

//��������lib�ļ�����

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);
$sorttype = intval($_G['cache']['plugin']['aurora_content_control']['sort']);
$editedcheck = unserialize($_G['cache']['plugin']['aurora_content_control']['editedcheck']);
$notoforum = unserialize($_G['cache']['plugin']['aurora_content_control']['notoforum']);
$forums['focus'] = unserialize($_G['cache']['plugin']['aurora_content_control']['focusforums']);
$forums['normal'] = unserialize($_G['cache']['plugin']['aurora_content_control']['normalforums']);
if(!empty($_G['cache']['plugin']['aurora_content_control']['groupposts'])){
	$forums['group']  = array_keys(DB::fetch_all('SELECT fid FROM %t WHERE status = 3', array('forum_forum'),'fid'));
}
$forums['special'] = unserialize($_G['cache']['plugin']['aurora_content_control']['specialforums']);
if(intval($_GET['selectform']) != 0){
	$forums['select'] = intval($_GET['selectform']);
}
$days = intval($_G['cache']['plugin']['aurora_content_control']['days']);

$showpostsubject = intval($_G['cache']['plugin']['aurora_content_control']['showpostsubject']);

$forums_name = array_keys($forums);

$cencorword_notice = intval($_G['cache']['plugin']['aurora_content_control']['cencorword_notice']);

loadcache(array('forums','posttable_info'));

require_once libfile('function/attachment');
require_once libfile('function/discuzcode');
require_once libfile('function/misc');

//������ʼ��
if(empty($_G['cache']['plugin']['aurora_content_control']['cloudimgurl'])){
	$imgurl = $_G['setting']['attachurl'];
}else{
	$imgurl = $_G['cache']['plugin']['aurora_content_control']['cloudimgurl'];
}

if(substr($imgurl, -1) == '/'){
	$imgurl = substr($imgurl,0,-1);
}

if($sorttype == 0){
	$sort = 'DESC';
	$sortname = lang('plugin/aurora_content_control', 'DESC');
}else{
	$sort = 'ASC';
	$sortname = lang('plugin/aurora_content_control', 'ASC');
}

$dateline = intval($_G['timestamp'] - 3600 * 24 * $days);

$threadorpost = $_GET['threadorpost'];
	
$forumtag = daddslashes($_GET['forumtag']);	

$posttables = array_keys($_G['cache']['posttable_info']);

if(empty($posttables)){
	$posttables = array(0);
}


//���岿��

if(!empty($editedcheck[0])){
	$editedpids = array_keys(DB::fetch_all('SELECT * FROM %t', array('aurora_content_control_editedcheck'),'pid'));
}

foreach($forums_name as $name){
	
	$sum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE (ndateline > %d AND operatetime = 0) AND nfid IN (%n) AND first = 1', array('aurora_content_control',$dateline,$forums[$name]));   // ��ѯ�����������
	
	$sum[$name]['post'] = DB::result_first('SELECT count(*) FROM %t WHERE (ndateline > %d AND operatetime = 0) AND nfid IN (%n) AND first = 0', array('aurora_content_control',$dateline,$forums[$name]));   // ��ѯ����������
	
	if(!empty($editedpids)){
		
		$editedsum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE npid IN (%n) AND nfid IN (%n) AND first = 1', array('aurora_content_control',$editedpids,$forums[$name]));   // ��ѯ������޸�������

		$editedsum[$name]['post'] = DB::result_first('SELECT count(*) FROM %t WHERE npid IN (%n) AND nfid IN (%n) AND first = 0', array('aurora_content_control',$editedpids,$forums[$name]));   // ��ѯ������޸Ļ�����
		
	}
	
	if($name == 'select' && $_GET['selectform'] == -1){
		
		$sum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE (ndateline > %d AND operatetime = 0) AND first = 1', array('aurora_content_control',$dateline));   // ��ѯ�����������

		$sum[$name]['post'] = DB::result_first('SELECT count(*) FROM %t WHERE (ndateline > %d AND operatetime = 0) AND first = 0', array('aurora_content_control',$dateline,$forums[$name]));   // ��ѯ����������

		if(!empty($editedpids)){

			$editedsum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE npid IN (%n) AND first = 1', array('aurora_content_control',$editedpids));   // ��ѯ������޸�������

			$editedsum[$name]['post'] = DB::result_first('SELECT count(*) FROM %t WHERE npid IN (%n) AND first = 0', array('aurora_content_control',$editedpids));   // ��ѯ������޸Ļ�����

		}
		
	}
	
	$sum[$name]['thread'] = $sum[$name]['thread'] + intval($editedsum[$name]['thread']);
	
	$sum[$name]['post'] = $sum[$name]['post'] + intval($editedsum[$name]['post']);
	
	$count[$name] = array_sum($sum[$name]);
}

//formtag��ʼ��start

if(empty($forumtag)){
	$forumtag = 'focus';
}

foreach($count as $name => $num){
	if(!empty($num) && empty($count[$forumtag])){
		$forumtag = $name;
	}
}

//formtag��ʼ��end

if(empty($threadorpost)){
	if(!empty($sum[$forumtag]['post']) && empty($sum[$forumtag]['thread'])){
		$threadorpost = 'post';
	}else{
		$threadorpost = 'thread';
	}
}else{
	if(!empty($sum[$forumtag]['post']) && empty($sum[$forumtag]['thread'])){
		$threadorpost = 'post';
	}
	if(!empty($sum[$forumtag]['thread']) && empty($sum[$forumtag]['post'])){
		$threadorpost = 'thread';
	}
}

$first = '';

if($threadorpost == 'thread' && !empty($_G['cache']['plugin']['aurora_content_control']['threadorpostforop'])){
	$first = 'AND first = 1';
}

if($threadorpost == 'post' && !empty($_G['cache']['plugin']['aurora_content_control']['threadorpostforop'])){
	$first = 'AND first = 0';
}

//��ҳ������ʼ��

if(!empty($_G['cache']['plugin']['aurora_content_control']['threadorpostforop'])){
	$amount = $sum[$forumtag][$threadorpost];
}else{
	$amount = $sum[$forumtag]['thread'] + $sum[$forumtag]['post'];
}

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

//���ݲ�ѯ

$rs = $query = $editeddata = $pidsforquery = array();

if($_GET['selectform'] == -1){
	
	if(!empty($editedcheck[0])){
		$editeddata = DB::fetch_all('SELECT npid,editstatus,edittime FROM %t WHERE npid IN (%n) %i LIMIT %d,%d', array('aurora_content_control',$editedpids,$first,$startlimit,$pagesize),'npid');
	}

	$pidsforquery = array_keys(DB::fetch_all('SELECT npid FROM %t WHERE ndateline > %d AND operatetime = 0 %i LIMIT %d,%d', array('aurora_content_control',$dateline,$first,$startlimit,($pagesize - count($editeddata))),'npid'));	
	
}else{
	
	if(!empty($editedcheck[0])){
		$editeddata = DB::fetch_all('SELECT npid,editstatus,edittime FROM %t WHERE npid IN (%n) AND nfid IN (%n) %i LIMIT %d,%d', array('aurora_content_control',$editedpids,$forums[$forumtag],$first,$startlimit,$pagesize),'npid');
	}

	$pidsforquery = array_keys(DB::fetch_all('SELECT npid FROM %t WHERE ndateline > %d AND nfid IN (%n) AND operatetime = 0 %i LIMIT %d,%d', array('aurora_content_control',$dateline,$forums[$forumtag],$first,$startlimit,($pagesize - count($editeddata))),'npid'));
	
}

$pidsforquery = array_merge(array_keys($editeddata),$pidsforquery);

$pidsforquery_count = count($pidsforquery);

foreach ($posttables as $id) {
	$id = intval($id);
	$table[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
	if($pidsforquery_count > 0){
		$query = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n)', array($table[$id],$pidsforquery),'pid');
		$tableidforpids[$id] = array_keys($query); 
	}
	if(!empty($query)){
		foreach($tableidforpids[$id] as $v){
			$posttableids[$v] = $id;
		}
		$rs = $rs + $query;
		$pidsforquery_count = $pidsforquery_count - count($query);
	}
	$query = array();
}

if($sorttype == 0){
	krsort($rs);
}else{
	ksort($rs);
}

foreach($rs as $tmp){
	$tids[$tmp['tid']] = $tmp['tid'];
};

$threadinfo = DB::fetch_all('SELECT tid,digest,displayorder,subject FROM %t WHERE tid IN (%n)', array('forum_thread',$tids),'tid');

 // ��ʾ��ҳ
$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:check&forumtag=$forumtag&threadorpost=$threadorpost&selectform={$_GET['selectform']}&m={$_GET['m']}", $pagecount);  

foreach($rs as $uidsforgroupid_temp){
	$uidsforgroupid[] = $uidsforgroupid_temp['authorid'];
};
$uidsforgroupid = array_unique($uidsforgroupid);

$rs_groupid = DB::fetch_all('SELECT uid,groupid,regdate FROM %t WHERE uid IN (%n)', array('common_member',$uidsforgroupid),'uid');	

$pagename = explode(':',$_GET['id']);
$current[$pagename[1]] = 'current';

$checkmobile = checkmobile();

if(empty($checkmobile)){
	include template("aurora_content_control:check");
}else{
	include template("aurora_content_control:touch/check");
}


if(!empty($pidsforclear['normal'])){
	$pidsforclear_normal_str = dimplode($pidsforclear['normal']);
	DB::delete('aurora_content_control'," npid IN ($pidsforclear_normal_str)");	
}


if(!empty($pidsforclear['edited'])){
	$pidsforclear_edited_str = dimplode($pidsforclear['edited']);
	DB::delete('aurora_content_control_editedcheck'," pid IN ($pidsforclear_edited_str)");	
}
//From: Dism��taobao��com
?>