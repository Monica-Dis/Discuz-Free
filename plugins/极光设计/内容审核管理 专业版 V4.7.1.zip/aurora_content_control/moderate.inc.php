<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$sforumsoperator = unserialize($_G['cache']['plugin']['aurora_content_control']['sforumsoperator']);
$othername['check'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['check_name']);
$othername['moderate'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['moderate_name']);
$othername['report'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['report_name']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

//��������lib�ļ�����

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);
$sorttype = intval($_G['cache']['plugin']['aurora_content_control']['sort']);
if(!empty($_G['cache']['plugin']['aurora_content_control']['bandelpmreason'])){
	$deletereasons = explode(',',$_G['cache']['plugin']['aurora_content_control']['bandelpmreason']);
}
$notoforum = unserialize($_G['cache']['plugin']['aurora_content_control']['notoforum']);
$forums['focus'] = unserialize($_G['cache']['plugin']['aurora_content_control']['focusforums']);
$forums['normal'] = unserialize($_G['cache']['plugin']['aurora_content_control']['normalforums']);
$forums['special'] = unserialize($_G['cache']['plugin']['aurora_content_control']['specialforums']);
if(intval($_GET['selectform']) != 0){
	$forums['select'] = intval($_GET['selectform']);
}
$days = $_G['cache']['plugin']['aurora_content_control']['days'];
$nobandelgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['nobandelgroup']);
$ignorepost = intval($_G['cache']['plugin']['aurora_content_control']['ignorepost']);
$cencorword_notice = intval($_G['cache']['plugin']['aurora_content_control']['cencorword_notice']);

$showpostsubject = intval($_G['cache']['plugin']['aurora_content_control']['showpostsubject']);

$forums_name = array_keys($forums);

loadcache(array('forums','posttable_info'));

require_once libfile('function/attachment');
require_once libfile('function/discuzcode');
require_once libfile('function/misc');

//������ʼ��
if(empty($_G['cache']['plugin']['aurora_content_control']['cloudimgurl'])){
	$imgurl = $_G['setting']['attachurl'];
}else{
	$imgurl = $_G['cache']['plugin']['aurora_content_control']['cloudimgurl'];
}

if(substr($imgurl, -1) == '/'){
	$imgurl = substr($imgurl,0,-1);
}

if($sorttype == 0){
	$sort = 'DESC';
	$sortname = lang('plugin/aurora_content_control', 'DESC');
}else{
	$sort = 'ASC';
	$sortname = lang('plugin/aurora_content_control', 'ASC');
}

$dateline = intval($_G['timestamp'] - 3600 * 24 * $days);

$threadorpost = $_GET['threadorpost'];

$ignorestatus = intval($_GET['ignorestatus']);

$forumtag = daddslashes($_GET['forumtag']);	

$posttables = array_keys($_G['cache']['posttable_info']);	

if(empty($posttables)){
	$posttables = array(0);
}
foreach ($posttables as $id) {
	$id = intval($id);
	$tables[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
}


//���岿��

if(!empty($_GET['dingdingtids'])){
	
	foreach($forums_name as $name){
		$sum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t as moderate JOIN %t as thread ON moderate.id = thread.tid WHERE moderate.id IN (%n) AND thread.fid IN (%n)', array('forum_thread_moderate','forum_thread',dintval($_GET['dingdingtids'],true),$forums[$name]));
	}

	if($name == 'select' && $_GET['selectform'] == -1){

		$sum['select']['thread'] = count($_GET['dingdingtids']);

	}
	
}else{
	
	foreach($forums_name as $name){
		$sum[$name]['thread'] = DB::result_first('SELECT count(*) FROM %t as moderate JOIN %t as thread ON moderate.id = thread.tid WHERE thread.fid IN (%n) AND moderate.status = %d', array('forum_thread_moderate','forum_thread',$forums[$name],$ignorestatus));
	}

	if($name == 'select' && $_GET['selectform'] == -1){

		$sum['select']['thread'] = DB::result_first('SELECT count(*) FROM %t WHERE status = %d', array('forum_thread_moderate',$ignorestatus));

	}
	
}
	

if(!empty($_GET['dingdingpids'])){
	
	foreach($forums_name as $name){

		foreach ($tables as $id => $table) {
			$countpost = DB::result_first('SELECT count(*) FROM %t as moderate JOIN %t as post ON moderate.id = post.pid WHERE post.pid IN (%n) AND post.fid IN (%n) AND first = 0', array('forum_post_moderate',$table,dintval($_GET['dingdingpids'],true),$forums[$name]));
			$sum[$name]['post'] = intval($sum[$name]['post']) + intval($countpost);
		}

	}

	if($name == 'select' && $_GET['selectform'] == -1){

			$sum['select']['post'] = count($_GET['dingdingpids']);

	}	
	
}else{
	
	foreach($forums_name as $name){

		foreach ($tables as $id => $table) {
			$countpost = DB::result_first('SELECT count(*) FROM %t as moderate JOIN %t as post ON moderate.id = post.pid WHERE post.fid IN (%n) AND first = 0 AND moderate.status = %d', array('forum_post_moderate',$table,$forums[$name],$ignorestatus));
			$sum[$name]['post'] = intval($sum[$name]['post']) + intval($countpost);
		}

	}

	if($name == 'select' && $_GET['selectform'] == -1){

			$sum['select']['post'] = DB::result_first('SELECT count(*) FROM %t WHERE status = %d', array('forum_post_moderate',$ignorestatus));

	}
	
}
	

foreach($forums_name as $name){
	
	$count[$name] = array_sum($sum[$name]);
}

//formtag��ʼ��start

if(empty($forumtag)){
	$forumtag = 'focus';
}

foreach($count as $name => $num){
	if(!empty($num) && empty($count[$forumtag])){
		$forumtag = $name;
	}
}

//formtag��ʼ��end

if(empty($threadorpost)){
	if(!empty($sum[$forumtag]['post']) && empty($sum[$forumtag]['thread'])){
		$threadorpost = 'post';
	}else{
		$threadorpost = 'thread';
	}
}else{
	if(!empty($sum[$forumtag]['post']) && empty($sum[$forumtag]['thread'])){
		$threadorpost = 'post';
	}
	if(!empty($sum[$forumtag]['thread']) && empty($sum[$forumtag]['post'])){
		$threadorpost = 'thread';
	}
}

$amount = $sum[$forumtag][$threadorpost];

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

$rs = $query = array();

$querysize = $pagesize;

if(!empty($sum[$forumtag]['thread']) && $threadorpost == 'thread'){
	
	if(!empty($_GET['dingdingtids'])){
		$tidsforquery = dintval($_GET['dingdingtids'],true);
	}else{
		$tidsforquery = array_keys(DB::fetch_all('SELECT moderate.id FROM %t as moderate JOIN %t as thread ON moderate.id = thread.tid WHERE moderate.status = %d AND thread.fid IN (%n) ORDER BY moderate.id LIMIT %d , %d', array('forum_thread_moderate','forum_thread',$ignorestatus,$forums[$forumtag],$startlimit,$pagesize),'id'));
	}
	
	foreach ($tables as $id => $table) {
		
		if($querysize > 0){
			
			if($name == 'select' && $_GET['selectform'] == -1){
				$query = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND first = 1',array($table,$tidsforquery),'pid');
			}else{
				$query = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND first = 1 AND fid IN (%n)',array($table,$tidsforquery,$forums[$forumtag]),'pid');
			}

			$querysize = $querysize - count($query);

			$rs = $rs + $query;
			foreach (array_keys($query) as $v){
				$posttableids[$v] = $id;
			}
		}

	}

}



if(!empty($sum[$forumtag]['post']) && $threadorpost == 'post'){
	
	if(!empty($_GET['dingdingpids'])){
		$pidsforquery = dintval($_GET['dingdingpids'],true);
		$dingdingpids = ' AND '.DB::field(post.pid,$pidsforquery);
	}else{
		$dingdingpids = '';
	}
		
	foreach ($tables as $id => $table) {
		
		if($querysize > 0){

			if($name == 'select' && $_GET['selectform'] == -1){
				$query = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n)',array($table,$pidsforquery),'pid');
			}else{
				$query = DB::fetch_all('SELECT * FROM %t as moderate JOIN %t as post ON moderate.id = post.pid WHERE moderate.status = %d AND post.fid IN (%n) %i ORDER BY moderate.id LIMIT %d , %d', array('forum_post_moderate',$table,$ignorestatus,$forums[$forumtag],$dingdingpids,$startlimit,$querysize),'id');
			}
			
			$rs = $rs + $query;

			$querysize = $querysize - count($query);

			foreach (array_keys($query) as $v){
				$posttableids[$v] = $id;
			}

		}
	}		
	
}

if($sorttype == 0){
	krsort($rs);
}else{
	ksort($rs);
}

foreach($rs as $tmp){
	$tids[$tmp['tid']] = $tmp['tid'];
};

$threadinfo = DB::fetch_all('SELECT tid,subject,sortid FROM %t WHERE tid IN (%n)', array('forum_thread',$tids),'tid');

foreach($threadinfo as $tmp){
	$sorttids[$tmp['tid']] = $tmp['tid'];
};

if(!empty($sorttids)){
	$tmp = array();
	$sortinfo = array();
	$sortquery = DB::fetch_all('SELECT tid,sortid,value FROM %t WHERE tid IN (%n)', array('forum_typeoptionvar',$sorttids));
	foreach($sortquery as $tmp){
		if(array_key_exists($tmp['tid'],$sortinfo)){
			$sortinfo[$tmp['tid']] = array_merge($sortinfo[$tmp['tid']],array($tmp['value']));
		}else{
			$sortinfo[$tmp['tid']] = array($tmp['value']);
		}
	}
}

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:moderate&forumtag=$forumtag&ignorestatus=$ignorestatus&threadorpost=$threadorpost&selectform={$_GET['selectform']}&m={$_GET['m']}", $pagecount);   // ��ʾ��ҳ

foreach($rs as $uidsforgroupid_temp){
	$uidsforgroupid[] = $uidsforgroupid_temp['authorid'];
};
$uidsforgroupid = array_unique($uidsforgroupid);

$rs_groupid = DB::fetch_all('SELECT uid,groupid,regdate FROM %t WHERE uid IN (%n)', array('common_member',$uidsforgroupid),'uid');	

$pagename = explode(':',$_GET['id']);
$current[$pagename[1]] = 'current';

$checkmobile = checkmobile();

if(empty($checkmobile)){
	include template("aurora_content_control:moderate");
}else{
	include template("aurora_content_control:touch/moderate");
}
//From: Dism��taobao��com
?>