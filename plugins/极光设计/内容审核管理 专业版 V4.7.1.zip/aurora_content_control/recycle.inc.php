<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

//��������lib�ļ�����

loadcache(array('forums','posttable_info'));
require_once libfile('function/attachment');
require_once libfile('function/discuzcode');
require_once libfile('function/misc');
require_once libfile('function/forumlist');

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);

if(intval($_GET['tid']) > 1){
	$search['tid'] = " AND tid = {$_GET['tid']}";
}else{
	$search['tid'] = '';
}
if(intval($_GET['fromforum']) > 1){
	$search['fromforum'] = " AND fid = {$_GET['fromforum']}";
}else{
	$search['fromforum'] = '';
}
if(!empty($_GET['author'])){
	$search['author'] = " AND author = '".daddslashes($_GET['author'])."'";
}else{
	$search['author'] = '';
}
if(!empty($_GET['keyword'])){
	$search['keyword'] = ' AND subject LIKE '."'%".daddslashes(stripsearchkey($_GET['keyword']))."%'";
}else{
	$search['keyword'] = '';
}
if(!empty($_GET['timeon'])){
	$search['timeon'] = ' AND dateline >= '.dmktime($_GET['timeon']);
}else{
	$search['timeon'] = '';
}
if(!empty($_GET['timeoff'])){
	$search['timeoff'] = ' AND dateline < '.dmktime($_GET['timeoff']);
}else{
	$search['timeoff'] = '';
}

//���岿��

$amount = DB::result_first('SELECT count(*) FROM %t WHERE displayorder = -1 %i %i %i %i %i %i', array('forum_thread',$search['tid'],$search['fromforum'],$search['author'],$search['keyword'],$search['timeon'],$search['timeoff']));

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

$source = DB::fetch_all('SELECT * FROM %t WHERE displayorder = -1 %i %i %i %i %i %i ORDER BY tid DESC LIMIT %d , %d', array('forum_thread',$search['tid'],$search['fromforum'],$search['author'],$search['keyword'],$search['timeon'],$search['timeoff'],$startlimit,$pagesize));

foreach ($source as $key => $value){
	$tids[] = $value['tid'];
	$modthreadkeys[$value['tid']] = modauthkey($value['tid']);
	$posttables[$value['posttableid']] = $value['posttableid'];
	$viewandreplay[$value['tid']] = $value['views'].'/'.$value['replies'];
}

$modinfo = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n)', array('forum_threadmod',$tids),'tid');

foreach ($posttables as $id) {
	$id = intval($id);
	$tables[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
}

$rs = $query = array();

foreach ($tables as $table) {
	$query = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND first = 1', array($table,$tids),'pid');
	$rs = $rs + $query;
}

krsort($rs);

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:recycle&fid={$_GET['fromforum']}&author={$_GET['author']}&keyword={$_GET['keyword']}&timeon={$_GET['timeon']}&timeoff={$_GET['timeoff']}&tid={$_GET['tid']}", $pagecount);  

include template("aurora_content_control:recycle");
?>