<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$usermanagegroup = unserialize($_G['cache']['plugin']['aurora_content_control']['usermanagegroup']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

if(!(in_array($groupnow,$usermanagegroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

//��������lib�ļ�����

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);

//���岿��

$return = $_GET['return'];

if(!empty($_GET['search'])){
	
	$searchval = daddslashes(explode(',',$_GET['search']));

	if (submitcheck('searchbtn')){
		
			if(count($searchval) <= $pagesize){
				
				$search = DB::field('username',$searchval);
				
			}else{
				
				DB::query("TRUNCATE TABLE %t",array('aurora_content_control_usermanage'));
				
				$data = "('".implode("'),('",$searchval)."')";;
				
				$return = DB::query("INSERT IGNORE INTO %t (username) values %i",array('aurora_content_control_usermanage',$data));
				
			}
			
	}
	
}else{
	$search = DB::field('uid',0);
}

if(intval($return) == 0){
	
	$amount = DB::result_first('SELECT count(*) FROM %t WHERE %i', array('common_member',$search));

}else{
	
	$amount = DB::result_first('SELECT count(*) FROM %t', array('aurora_content_control_usermanage'));
	
}

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

if(intval($return) == 0){

	$rs = DB::fetch_all('SELECT * FROM %t WHERE %i ORDER BY uid DESC LIMIT %d , %d', array('common_member',$search,$startlimit,$pagesize));

}else{
	
	$rs = DB::fetch_all('SELECT * FROM %t a JOIN %t b ON  a.username = b.username ORDER BY a.uid DESC LIMIT %d , %d', array('common_member','aurora_content_control_usermanage',$startlimit,$pagesize));
	
}

foreach($rs as $user_temp){
	$uids[$user_temp['uid']] = $user_temp['uid'];
};

$rs_memberstatus = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member_status',$uids),'uid');

$usergroups = DB::fetch_all('SELECT * FROM %t', array('common_usergroup'),'groupid');

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:usermanage&return=$return", $pagecount);   // ��ʾ��ҳ

include template("aurora_content_control:usermanage");


?>