<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//权限验证

loadcache(array('plugin','forums','posttable_info'));

$groupnow = $_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

$pagesize = 10;

$userinfo = DB::fetch_first('SELECT * FROM %t WHERE uid = %d', array('common_member',$_GET['uid']));

$usergroup = DB::fetch_first('SELECT * FROM %t WHERE groupid = %d', array('common_usergroup',$userinfo['groupid']));

$userstatus = DB::fetch_first('SELECT * FROM %t WHERE uid = %d', array('common_member_status',$_GET['uid']));

if(!empty($_G['cache']['plugin']['aurora_content_control']['reasonforbatchban'])){
	$reasonforbatchban = 'batchban';
}

if(intval($_G['cache']['plugin']['aurora_content_control']['bandeltype']) == 0){
	$bandeltype = lang('plugin/aurora_content_control', 'banpost');
}else{
	$bandeltype = lang('plugin/aurora_content_control', 'banvisit');
}

//翻页参数初始化

$count['thread']['all'] = DB::result_first('SELECT count(*) FROM %t WHERE authorid = %d', array('forum_thread',$_GET['uid']));
$count['thread']['invalid'] = DB::result_first('SELECT count(*) FROM %t WHERE authorid = %d AND displayorder < 0', array('forum_thread',$_GET['uid']));

$posttables = array_keys($_G['cache']['posttable_info']);

if(empty($posttables)){
	$posttables = array(0);
}

foreach ($posttables as $id) {
	$id = intval($id);
	$tables[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
}

if($_GET['getpostdata'] == 'yes'){
	DB::query("TRUNCATE TABLE %t",array('aurora_content_control_userinfo_post'));
	
	foreach ($tables as $table) {
		DB::query("INSERT IGNORE INTO %t(pid,uid,invisible,tableid) SELECT pid,%d,invisible,%d FROM %t WHERE authorid = %d AND first = 0",array('aurora_content_control_userinfo_post',$_GET['uid'],$id,$table,$_GET['uid']));
	}
}


$count['post']['all'] = DB::result_first('SELECT count(*) FROM %t', array('aurora_content_control_userinfo_post'));
$count['post']['invalid'] = DB::result_first('SELECT count(*) FROM %t WHERE invisible < 0', array('aurora_content_control_userinfo_post'));

$lastipnow = DB::fetch_first('SELECT lastip FROM %t WHERE uid = %d', array('common_member_status',$_GET['uid']));
$lastipnow = $lastipnow['lastip'];

$count['repeat']['all'] = DB::result_first('SELECT count(*) FROM %t a JOIN %t b ON a.uid = b.uid WHERE lastip = %s', array('common_member','common_member_status',$lastipnow));
$count['repeat']['invalid'] = DB::result_first('SELECT count(*) FROM %t a JOIN %t b ON a.uid = b.uid WHERE lastip = %s AND groupid IN (4,5,6)', array('common_member','common_member_status',$lastipnow));

$amount = $count[$_GET['mod']]['all'];

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // 计算总页数

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // 取得当前页值

$startlimit = ($page - 1) * $pagesize;   // 查询起始的偏移量

if($_GET['mod'] == 'thread'){
	$threads = DB::fetch_all('SELECT * FROM %t WHERE authorid = %d ORDER BY tid DESC LIMIT %d,%d', array('forum_thread',$_GET['uid'],$startlimit,$pagesize),'tid');
}

$posts = $query = array();

if($_GET['mod'] == 'post'){

	$pids = DB::fetch_all('SELECT pid FROM %t LIMIT %d,%d', array('aurora_content_control_userinfo_post',$startlimit,$pagesize),'pid');
	foreach($tables as $table){
		$query = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n)', array($table,array_keys($pids)),'pid');
		$posts = $posts + $query;
	}
}

if($_GET['mod'] == 'repeat'){
	
	$repeatusers = DB::fetch_all('SELECT * FROM %t WHERE lastip = %s ORDER BY uid DESC LIMIT %d,%d', array('common_member_status',$lastipnow,$startlimit,$pagesize),'uid');
	
	$repeatusers_info = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member',array_keys($repeatusers)),'uid');
	
	foreach($repeatusers_info as $tmp){
		$groupids[$tmp['groupid']] = $tmp['groupid'];
	}
	
	$repeatusers_group = DB::fetch_all('SELECT * FROM %t WHERE groupid IN (%n)', array('common_usergroup',$groupids),'groupid');
}

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:userinfo&uid={$_GET['uid']}&mod={$_GET['mod']}", $pagecount); 

$checkmobile = checkmobile();

if(empty($checkmobile)){
	include template("aurora_content_control:userinfo");
}else{
	include template("aurora_content_control:touch/userinfo");
}
//From: Dism·taobao·com
?>