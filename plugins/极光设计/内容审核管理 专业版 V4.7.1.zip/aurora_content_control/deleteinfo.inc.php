<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}


//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$usermanagegroup = unserialize($_G['cache']['plugin']['aurora_content_control']['usermanagegroup']);


if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

if(intval($_GET['type']) == 1){
	$table = 'forum_thread';
	$status = ' AND displayorder = -1';
}else{
	$table = 'forum_post';
	$status = ' AND invisible = -5';
}

loadcache(array('forums','posttable_info'));

require_once libfile('function/misc');

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);

$amount = DB::result_first('SELECT count(*) FROM %t WHERE authorid = %d %i', array($table,$_GET['uid'],$status));

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:deleteinfo&uid={$_GET['uid']}&type={$_GET['type']}", $pagecount);   // ��ʾ��ҳ

if(intval($_GET['type']) == 1){
	$rs = DB::fetch_all('SELECT * FROM %t WHERE authorid = %d AND displayorder = -1 ORDER BY tid DESC LIMIT %d,%d', array('forum_thread',$_GET['uid'],$startlimit,$pagesize),'tid');
	include template("aurora_content_control:deleteinfo");
}else{
	$rs = DB::fetch_all('SELECT * FROM %t WHERE authorid = %d AND first = 0 AND invisible = -5 ORDER BY pid DESC LIMIT %d,%d', array('forum_post',$_GET['uid'],$startlimit,$pagesize),'pid');
	include template("aurora_content_control:deleteinfo_post");
}

//From: Dism_taobao-com
?>