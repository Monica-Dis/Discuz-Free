<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){  
    exit('Access Denied');  
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
	
if(!(in_array($groupnow,$operatorgroup))){
	exit(lang('plugin/aurora_content_control', 'forbiden'));	
}

//��������lib�ļ�����

loadcache(array('forums','posttable_info'));

require_once libfile('function/delete');
require_once libfile('function/post');
require_once libfile('function/forum');

$clearloggroup = unserialize($_G['cache']['plugin']['aurora_content_control']['clearloggroup']);
$credit = $_G['cache']['plugin']['aurora_content_control']['delcredit'];

//������ʼ��

$mod = daddslashes($_GET['mod']);
$pid = intval($_GET['pid']);
$tid = intval($_GET['tid']);
$bypids = dintval($_POST['bypids'],true);
$bytids = dintval($_POST['bytids'],true);
$operatetime = intval($_G['timestamp']);
$operatorid = intval($_G['uid']);
$operator = daddslashes($_G['username']);
$posttableid = intval($_GET['posttableid']);
if(!empty($_GET['authorids'])){
	$authorids = dintval($_GET['authorids'],true);
}else{
	$authorid = intval($_GET['authorid']);
	$authorids = array($authorid);
}
$moderate = daddslashes($_GET['moderate']);
if($moderate == 'undefined'){
	$moderate = '';
}
$toforum = intval($_GET['toforum']);

$posttables = array_keys($_G['cache']['posttable_info']);

if(empty($posttables)){
	$posttables = array(0);
}
foreach ($posttables as $id) {
	$id = intval($id);
	$tables[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
}

if(empty($bypids)){
	$bypids = array();
}
if(empty($bytids)){
	$bytids = array();
}

//���岿��

if ($mod == 'getdata' && FORMHASH == $_GET['linkhash']){
	$dateline = $_G['timestamp'] - 3600 * 24 * $_G['cache']['plugin']['aurora_content_control']['days'];
	$postloadtype = unserialize($_G['cache']['plugin']['aurora_content_control']['postloadtype']);
	
	if(intval($postloadtype[0]) < 2){
		$first = 'AND '.DB::field('first',intval($postloadtype[0]));
	}else{
		$first = '';
	}
	
	foreach ($tables as $table) {
		DB::query("INSERT IGNORE INTO %t(npid,ntid,nfid,first,ndateline) SELECT pid,tid,fid,first,dateline FROM %t WHERE dateline > %d AND invisible >=0 %i",array('aurora_content_control',$table,$dateline,$first));
	}
}

if ($mod == 'check' && FORMHASH == $_GET['linkhash']){
	
	if($moderate == 'post'){
		$posttableids = array($posttableid);
		$pidsformoderate = array($pid);
		$moderation['validate'] = $pidsformoderate;
		require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_post.php';
	}
	
	if($moderate == 'thread'){
		$posttableids = array($posttableid);
		$moderation['validate'] = array($tid);
		$pidsformoderate = array($pid);
		require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_thread.php';
	}
	if($moderate == 'report'){
		$rid = intval($_GET['rid']);
		DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore'),array('id' => $rid));
	}
	
	if($_GET['editstatus'] == 1){
		DB::update('aurora_content_control',array('editstatus' => 0),array('npid' => $pid));
		DB::delete('aurora_content_control_editedcheck',array('pid' => $pid));
	}
	
	if(empty($moderate) || $status == 0){
		DB::update('aurora_content_control',array('operatetime' => $operatetime,'operatorid' => $operatorid),array('npid' => $pid));
	}
	
}

if ($mod == 'ignore' && (submitcheck('ignorebtn') || FORMHASH == $_GET['linkhash'])){
	
	$pidsforcheck = $bypids + $bytids;
	
	if(!empty($pid) || !empty($tid)){
		$pidsforcheck = $pidsforcheck + array($pid => $tid);
	}

	if (!empty($pidsforcheck)){
		
		$pidsformoderate = dintval(array_keys($pidsforcheck),true);
		
		if(!empty($_POST['posttableids'])){
			foreach($_POST['posttableids'] as $k => $v){
				if(in_array($k,$pidsformoderate)){
					$posttableids[] = intval($v);
				}
			}
			$posttableids = array_unique($posttableids);
		}else{
			$posttableids = array($posttableid);
		}
		
		if($moderate == 'thread'){
			
			$moderation['ignore'] = array_values($pidsforcheck);

			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_thread.php';
	
			echo lang('plugin/aurora_content_control', 'ignored').count($pidsforcheck).lang('plugin/aurora_content_control', 'threads');
		}
		
		if($moderate == 'post'){
			
			$moderation['ignore'] = $pidsformoderate;
			
			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_post.php';
	
			echo lang('plugin/aurora_content_control', 'ignored').count($pidsforcheck).lang('plugin/aurora_content_control', 'posts');
			
		}
		
	}
	
}

if ($mod == 'checkall' && submitcheck('checkallbtn')){
	
	$pidsforcheck = $bypids + $bytids;
	
	if (!empty($pidsforcheck)){
		
		if(empty($moderate)){
			$pidsforcheck_str = dimplode(array_keys($pidsforcheck));
			if($_GET['moderate_checkall'] == 'yes'){
				$rids = dimplode(dintval($_POST['rids'],true));
				DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore')," id IN ($rids)");
			}else{
				DB::update('aurora_content_control',array('operatetime' => $operatetime,'operatorid' => $operatorid,'editstatus' => 0)," npid IN ($pidsforcheck_str)");
			}

		}
		
		if($moderate == 'thread'){
			$moderation['validate'] = array_values($pidsforcheck);
			$pidsformoderate = dintval(array_keys($pidsforcheck),true);
			foreach($_POST['posttableids'] as $k => $v){
				if(in_array($k,$pidsformoderate)){
					$posttableids[] = intval($v);
				}
			}
			$posttableids = array_unique($posttableids);

			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_thread.php';

		}
		if($moderate == 'post'){
			$pidsformoderate = dintval(array_keys($pidsforcheck),true);
			foreach($_POST['posttableids'] as $k => $v){
				if(in_array($k,$pidsformoderate)){
					$posttableids[] = intval($v);
				}
			}
			$posttableids = array_unique($posttableids);
			
			$moderation['validate'] = $pidsformoderate;
			
			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_post.php';

		}
		
		if(!empty($_POST['editstatus'])){
			$editedpids_str = dimplode(array_keys($_POST['editstatus']));
			DB::delete('aurora_content_control_editedcheck'," pid IN ($editedpids_str)");
		}
		
		if(!empty($bytids)){
			echo lang('plugin/aurora_content_control', 'checked').count($bytids).lang('plugin/aurora_content_control', 'threads');
		}
		if(!empty($bypids)){
			echo lang('plugin/aurora_content_control', 'checked').count($bypids).lang('plugin/aurora_content_control', 'posts');
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/common.php';
	
}

if ($mod == 'deletebypid' && FORMHASH == $_GET['linkhash']){
	$posttableid = intval(DB::result_first('SELECT posttableid FROM %t WHERE tid = %d', array('forum_thread',$tid)));
	$table = empty($posttableid) ? 'forum_post' : 'forum_post_'.$posttableid;
	if(empty($moderate)){
		deletepost(array($pid), 'pid', $credit, $posttableid, true);
		updatemodworks('DLP',1);
		deletethreadcaches($tid);
		$invisible = intval(DB::result_first('SELECT invisible FROM %t WHERE pid = %d', array($table,$pid)));
		if($invisible < 0){
			DB::delete('aurora_content_control',array('npid' => $pid));
			$respon = json_encode(array("flag" => "done"));
		}else{
			$respon = json_encode(array("flag" => "error"));
		}
		echo $respon;
		return;
	}
	if($moderate == 'post'){
		$moderation['delete'] = array($pid);
		$posttableids = array($posttableid);
		require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_post.php';
		DB::delete('aurora_content_control',array('npid' => $pid));
	}
	if($moderate == 'report'){
		$rid = intval($_GET['rid']);
		DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore'),array('id' => $rid));
	}
	if($_GET['editstatus'] == 1){
		DB::delete('aurora_content_control_editedcheck',array('pid' => $pid));
	}
}

if ($mod == 'deletebytid' && FORMHASH == $_GET['linkhash']){
	
	if(empty($moderate)){
		deletethread(array($tid) , true, $credit, true);
		updatemodworks('DEL',1);
		updatemodlog(implode(',', array($tid)), 'DEL');
		DB::delete('aurora_content_control',array('ntid' => $tid));
	}
	
	if($moderate == 'report'){
		$rid = intval($_GET['rid']);
		DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore'),array('id' => $rid));
	}
	
	if($moderate == 'thread'){
		$moderation['delete'] = array($tid);
		require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_thread.php';
		DB::delete('aurora_content_control',array('ntid' => $tid));
	}
	
	if($_GET['editstatus'] == 1){
		DB::delete('aurora_content_control_editedcheck',array('tid' => $tid));
	}
}

if ($mod == 'deleteall' && submitcheck('deleteallbtn')){
	
	$pidsforcheck = $bypids + $bytids;
	
	if(empty($moderate)){
		if (!empty($bytids)){
			$tids = array_values($bytids);
			$tids_str = dimplode($tids);
			deletethread($tids , true, $credit, true);
			updatemodworks('DEL',count($tids));
			updatemodlog(implode(',',$tids), 'DEL');
			DB::delete('aurora_content_control'," ntid IN ($tids_str)");
		}
		
		if (!empty($bypids)){		
			if (!empty($tids)){
				foreach($bypids as $k => $v){
					if(!in_array($v,$tids) && !empty($v)){
						$pids[] = $k;
					}
				}
			}else{
				$pids = array_keys($bypids);
			}
			$pids_str = dimplode($pids);
			foreach($tables as $key => $table){
				deletepost($pids, 'pid', $credit, $key, true);
			}
			updatemodworks('DLP',count($pids));
			if($_GET['moderate_checkall'] == 'yes'){
				$rids = dimplode(dintval($_POST['rids'],true));
				DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore')," id IN ($rids)");
			}else{
				DB::delete('aurora_content_control'," npid IN ($pids_str)");
			}
		}
		if(!empty($_POST['editstatus'])){
			$editedtids_str = dimplode(array_unique($_POST['editstatus']));
			DB::delete('aurora_content_control_editedcheck'," tid IN ($editedtids_str)");
		}
		echo lang('plugin/aurora_content_control', 'deleted').count($tids).lang('plugin/aurora_content_control', 'threads').'&'.count($pids).lang('plugin/aurora_content_control', 'posts');
	}
	
	if($moderate == 'thread'){
		if(!empty($bytids)){
			$moderation['delete'] = array_values($bytids);
			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_thread.php';
			echo lang('plugin/aurora_content_control', 'deleted').count($bytids).lang('plugin/aurora_content_control', 'threads');
		}
	}
	
	if($moderate == 'post'){
		if(!empty($bypids)){
			$pidsformoderate = dintval(array_keys($pidsforcheck),true);
			foreach($_POST['posttableids'] as $k => $v){
				if(in_array($k,$pidsformoderate)){
					$posttableids[] = intval($v);
				}
			}
			$posttableids = array_unique($posttableids);
			$moderation['delete'] = $pidsformoderate;

			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/morderate_post.php';
			echo lang('plugin/aurora_content_control', 'deleted').count($pidsformoderate).lang('plugin/aurora_content_control', 'posts');
		}
	}
}

if ($mod == 'bandel' && (FORMHASH == $_GET['linkhash'] || submitcheck('banform'))){
	
	if(intval($_GET['clearpost']) == 1){
		$dateline = 0;
	}else{
		$dateline = $operatetime - 3600 * 24 * $_G['cache']['plugin']['aurora_content_control']['bandeltime'];
	}
	
	foreach($authorids as $key => $authorid){
		$authorgroup = DB::fetch_first('SELECT adminid,groupid FROM %t WHERE uid = %d', array('common_member',$authorid));
		if($authorgroup['adminid'] <= 0){

			if(intval($_G['cache']['plugin']['aurora_content_control']['bandeltype']) == 0){
				$bandeltype = 4;
			}else{
				$bandeltype = 5;
			}

			$bandeltime = intval($_GET['bandeltime']);
			if($bandeltime > 0){
				$bandeltime = intval($bandeltime * 3600 * 24 + $_G['timestamp']);
				$member['groupterms']['main'] = array('time' => $bandeltime, 'adminid' => intval($authorgroup['adminid']), 'groupid' => intval($authorgroup['groupid']));
				$member['groupterms']['ext'][$bandeltype] = $bandeltime;
				C::t('common_member') -> update($authorid, array('adminid' => '-1' ,'groupid' => $bandeltype,'groupexpiry' => $bandeltime));
				C::t('common_member_field_forum')->update($authorid,array('groupterms' => (serialize($member['groupterms']))));
			}else{
				C::t('common_member') -> update($authorid, array('adminid' => '-1' ,'groupid' => $bandeltype));
			}
			include_once libfile('function/member');
			crime('recordaction', $authorid, 'crime_banspeak', lang('forum/misc', 'crime_reason', array('reason' => '')));
			DB::insert('aurora_content_control_bandellog',array('uid' => $authorid,'operatorid' => $operatorid,'operatetime' => $operatetime));

			$tids = array_keys(DB::fetch_all('SELECT tid FROM %t WHERE authorid = %d AND dateline > %d AND (displayorder = -2 OR displayorder >= 0)', array('forum_thread',$authorid,$dateline),'tid'));
			if (!empty($tids)){
				deletethread($tids , true, $credit, true);
				updatemodworks('DEL',count($tids));
				updatemodlog(implode(',',$tids), 'DEL');
				$tids_str = dimplode($tids);
				DB::delete('aurora_content_control'," ntid IN ($tids_str)");
				updatemoderate('tid',$tids, 2);
			}

			foreach ($tables as $id => $table) {
				$pidsforquery[$id] = array_keys(DB::fetch_all('SELECT pid FROM %t WHERE authorid = %d AND dateline > %d AND first = 0 AND (invisible = -2 OR invisible >= 0)', array($table,$authorid,$dateline),'pid'));
			}

			$pidscount = $pids = array();

			if (!empty($pidsforquery)){
				foreach($pidsforquery as $posttableid => $pids){
					deletepost($pids, 'pid', $credit, $posttableid, true);
					$pidscount =  $pidscount + $pids;
				}
				updatemodworks('DLP',count($pidscount));
				$pids_str = dimplode($pidscount);
				DB::delete('aurora_content_control'," npid IN ($pids_str)");
				updatemoderate('pid', $pidscount, 2);
			}

			if($moderate == 'report'){
				$rid = intval($_GET['rid']);
				DB::update('common_report',array('opuid' => $operatorid,'opname' => $operator,'optime' => $operatetime,'opresult' => 'ignore'),array('id' => $rid));
			}else{
				DB::delete('aurora_content_control',array('npid' => $pid));
			}
			if(intval($_G['cache']['plugin']['aurora_content_control']['bandelpm']) == 1 && !empty($_GET['reason'])){
				if($_GET['reason'] == 'batchban'){
					$reason = $_G['cache']['plugin']['aurora_content_control']['reasonforbatchban'];
				}else{
					$reason = lang('plugin/aurora_content_control', 'bandelreason').dhtmlspecialchars($_GET['reason']);
				}
				
				notification_add($authorid, 'system', $reason, array('from_id' => 0), 1);	
			}
		}
	}
}
if ($mod == 'bandelrestore' && FORMHASH == $_GET['linkhash']){
	$uids = array(intval($_GET['uid']));
	$uids_status = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member',$uids),'uid');
	
	foreach($uids_status as $uid => $val){
		$groupnew[$uid] = C::t('common_usergroup')->fetch_by_credits($val['credits']);
		C::t('common_member') -> update($uid, array('adminid' => '0' ,'groupid' => $groupnew[$uid]['groupid']));
	}
}
if ($mod == 'clearlog' && FORMHASH == $_GET['linkhash']){
	if(in_array($groupnow,$clearloggroup)){
		DB::delete('aurora_content_control'," operatetime > 0");
	}
}
if ($mod == 'deletelog' && FORMHASH == $_GET['linkhash']){
	DB::delete('aurora_content_control',array('npid' => intval($_GET['pid'])));
}
if ($mod == 'clearbandellog' && FORMHASH == $_GET['linkhash']){
	if(in_array($groupnow,$clearloggroup)){
		DB::delete('aurora_content_control_bandellog'," operatetime > 0");
	}
}
if ($mod == 'recyclerestore' && submitcheck('recyclerestorebtn')){
	
	$tids = $bytids;

	if($_G['setting']['plugins']['func'][HOOKTYPE]['undeletethreads']) {
		$param = func_get_args();
		hookscript('undeletethreads', 'global', 'funcs', array('param' => $param), 'undeletethreads');
	}
	$threadsundel = 0;
	if($tids && is_array($tids)) {
		$arrtids = $tids;
		$tids = '\''.implode('\',\'', $tids).'\'';

		$tuidarray = $ruidarray = $fidarray = $posttabletids = array();
		foreach(C::t('forum_thread')->fetch_all_by_tid($arrtids) as $thread) {
			$posttabletids[$thread['posttableid'] ? $thread['posttableid'] : 0][] = $thread['tid'];
		}
		foreach($posttabletids as $posttableid => $ptids) {
			foreach(C::t('forum_post')->fetch_all_by_tid($posttableid, $ptids, false) as $post) {
				if($post['first']) {
					$tuidarray[$post['fid']][] = $post['authorid'];
				} else {
					$ruidarray[$post['fid']][] = $post['authorid'];
				}
				if(!in_array($post['fid'], $fidarray)) {
					$fidarray[] = $post['fid'];
				}
			}
			C::t('forum_post')->update_by_tid($posttableid, $ptids, array('invisible' => '0'), true);
		}
		if($tuidarray) {
			foreach($tuidarray as $fid => $tuids) {
				updatepostcredits('+', $tuids, 'post', $fid);
			}
		}
		if($ruidarray) {
			foreach($ruidarray as $fid => $ruids) {
				updatepostcredits('+', $ruids, 'reply', $fid);
			}
		}

		$threadsundel = C::t('forum_thread')->update($arrtids, array('displayorder'=>0, 'moderated'=>1));

		updatemodlog($tids, 'UDL');
		updatemodworks('UDL', $threadsundel);

		foreach($fidarray as $fid) {
			updateforumcount($fid);
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/common.php';
	
	echo lang('plugin/aurora_content_control', 'restore'). $threadsundel .lang('plugin/aurora_content_control', 'threads');
	
}

if ($mod == 'getforumtype'){
	$types = C::t('forum_threadclass')->fetch_all_by_fid(intval($_GET['fid']));
	if(!empty($types)){
		foreach($types as $info){
			$type[$info['typeid']] = $info['name'];
			echo '<option value="'.$info['typeid'].'">'.$info['name'].'</option>'; 
		};
	}
}

if ($mod == 'setusergroup' && submitcheck('setusergroupbtn')){
	
	$usergroup = intval($_GET['usergroup']);
	
	if(empty($_GET['uids'])){
		$error[] = durlencode(lang('plugin/aurora_content_control', 'error_empty_uids'));
	}
	
	if($usergroup == 0){
		$error[] = durlencode(lang('plugin/aurora_content_control', 'error_empty_usergroup'));
	}
	
	if(!empty($error)){
		echo urldecode(json_encode(array('flag' => 'error','msg' => $error[0])));
		exit();
	}
	
	$admingroup = DB::fetch_all('SELECT * FROM %t WHERE radminid > 0', array('common_usergroup'),'groupid');
	
	if(in_array($usergroup,$admingroup)){
		$error[] = durlencode(lang('plugin/aurora_content_control', 'error_invalid_usergroup'));
		echo urldecode(json_encode(array('flag' => 'error','msg' => $error[0])));
		exit();
	}
	
	if($usergroup == -1){
		
		$uids_data = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member',array_unique($_GET['uids'])),'uid');
		
		foreach($uids_data as $uid => $data){
			
			$groupnew[$uid] = C::t('common_usergroup')->fetch_by_credits($data['credits']);
			C::t('common_member') -> update($uid, array('adminid' => '0' ,'groupid' => $groupnew[$uid]['groupid']));
			
			$count ++ ;
			
		}
				
		$msg = durlencode(lang('plugin/aurora_content_control', 'done_operated').$count.lang('plugin/aurora_content_control', 'done_users'));
		
	}else{
		
		$count = count($_GET['uids']);
		
		$uids_str = dimplode(dintval(array_unique($_GET['uids']),true));	
		DB::update('common_member',array('groupid' => $usergroup , 'adminid' => 0)," uid IN ($uids_str)");
		
		$msg = durlencode(lang('plugin/aurora_content_control', 'done_operated').$count.lang('plugin/aurora_content_control', 'done_users'));
		
	}
	
	echo(urldecode(json_encode(array('flag' => 'done','msg' => $msg ))));	
}
if ($mod == 'setdown' && FORMHASH == $_GET['linkhash']){
	C::t('forum_thread')->update(intval($_GET['tid']), array('lastpost'=> intval($_G['timestamp']) - 3600 * 24 *365, 'moderated'=>1), true);	
	$respon = json_encode(array("flag" => "done"));
	echo $respon;
	return;
}
//From: Dism_taobao_com
?>