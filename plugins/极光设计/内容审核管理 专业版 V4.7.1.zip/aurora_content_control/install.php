<?php
if((!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))){  
    exit('Access Denied');  
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_aurora_content_control;
DROP TABLE IF EXISTS pre_aurora_content_control_bandellog;
DROP TABLE IF EXISTS pre_aurora_content_control_usermanage;
DROP TABLE IF EXISTS pre_aurora_content_control_userinfo_post;
DROP TABLE IF EXISTS pre_aurora_content_control_editedcheck;

CREATE TABLE pre_aurora_content_control (
  opid int(10) unsigned NOT NULL key auto_increment,
  npid int(10) unsigned NOT NULL  DEFAULT '0',
  ntid int(10) unsigned NOT NULL  DEFAULT '0',
  nfid mediumint(8) unsigned NOT NULL  DEFAULT '0',
  first tinyint(1) unsigned NOT NULL  DEFAULT '0',
  ndateline int(10) unsigned NOT NULL  DEFAULT '0',
  editstatus tinyint(1) unsigned NOT NULL  DEFAULT '0',
  edittime int(10) unsigned NOT NULL  DEFAULT '0' , 
  operatetime int(10) unsigned NOT NULL  DEFAULT '0' , 
  operatorid int(10) unsigned NOT NULL  DEFAULT '0',
  UNIQUE npid(npid),
  INDEX ntid(ntid),
  INDEX ndateline(ndateline),
  INDEX nfid(nfid),
  INDEX editstatus(editstatus)
) ENGINE=MyISAM;

CREATE TABLE pre_aurora_content_control_bandellog (
  id int(10) unsigned NOT NULL key auto_increment,
  uid int(10) unsigned NOT NULL  DEFAULT '0',
  operatetime int(10) unsigned NOT NULL  DEFAULT '0' , 
  operatorid int(10) unsigned NOT NULL  DEFAULT '0',
  INDEX operatetime(operatetime)
)

ENGINE=MyISAM;

CREATE TABLE pre_aurora_content_control_usermanage (
  id int(10) unsigned NOT NULL key auto_increment,
  username char(15) NOT NULL,
  UNIQUE username(username)
)

ENGINE=MyISAM;

CREATE TABLE pre_aurora_content_control_userinfo_post (
  id int(10) unsigned NOT NULL key auto_increment,
  pid int(10) unsigned NOT NULL  DEFAULT '0',
  uid int(10) unsigned NOT NULL  DEFAULT '0',
  invisible tinyint(1) unsigned NOT NULL  DEFAULT '0',
  tableid tinyint(2) unsigned NOT NULL  DEFAULT '0',
  UNIQUE pid(pid)
)

ENGINE=MyISAM;

CREATE TABLE pre_aurora_content_control_editedcheck (
  pid int(10) unsigned NOT NULL key,
  tid int(10) unsigned NOT NULL  DEFAULT '0'
)

ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>