<?php  
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}

//ȫ��Ƕ��- ���Ӳ�����
class mobileplugin_aurora_content_control{}

//�����б�ҳ������ҳ
class mobileplugin_aurora_content_control_forum extends mobileplugin_aurora_content_control {

	
	public function forumdisplay_top_mobile_output() {
		
		global $_G;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee']) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
		
			global $separatepos;
			
			$mod = 'forumdisplay';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';
		
		}
		
		return '';
		
	}
	
	public function viewthread_top_mobile() {
		
		global $_G;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee']) && intval($_G['tid']) > 0 && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
		
			$mod = 'viewthread_thread';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';
		
		}
		
		return '';
	}
	
	public function viewthread_posttop_mobile_output() {
		
		global $_G;
		global $postlist;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee_post']) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
			
			$mod = 'viewthread_post';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';
			
		}
		
		return '';
	}
	
    public function post_message($params) {
		
		global $_G ;
		
		if( !empty($_G['cache']['plugin']['aurora_content_control']['zonenotcheck']) || !empty($_G['cache']['plugin']['aurora_content_control']['ipnotcheck'])){
			
			if(is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/zonecheck.php')){
				
				$zonenotcheck = explode('|',$_G['cache']['plugin']['aurora_content_control']['zonenotcheck']);
				
				$ipnotcheck = explode('|',$_G['cache']['plugin']['aurora_content_control']['ipnotcheck']);
				
				require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/zonecheck.php';
				
			}
			
		}
		
		$editedcheck = unserialize($_G['cache']['plugin']['aurora_content_control']['editedcheck']);
		
		if( !empty($editedcheck[0]) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/editedcheck.php')){
				
			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/editedcheck.php';
			
		}
		
	}
}
//From: Dism_taobao_com
?>