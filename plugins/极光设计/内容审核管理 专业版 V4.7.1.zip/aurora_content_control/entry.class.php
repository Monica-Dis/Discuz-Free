<?php  
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}

//ȫ��Ƕ��- ���Ӳ�����
class plugin_aurora_content_control{
	
	function global_usernav_extra1() {
		
		global $_G;
		$groupnow=$_G['groupid'];
		$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
		
		if(in_array($groupnow,$operatorgroup)){
			return "<a href='plugin.php?id=aurora_content_control' target='_blank'> ".lang('plugin/aurora_content_control', 'content_control')." </a>";
		}else{
			return '';
		}
	}
	
}

//�����б�ҳ������ҳ
class plugin_aurora_content_control_home extends plugin_aurora_content_control {
	
	function space_profile_baseinfo_middle() {
		
		return "<p style='border-bottom:1px dashed #CDCDCD; margin:0 0 10px 0;padding:0 0 10px 0'><a href='plugin.php?id=aurora_content_control:deleteinfo&uid={$_GET['uid']}&type=1' onclick=\"showWindow('mods', this.href, 'get', 0)\">".lang('plugin/aurora_content_control', 'deletedthreads')."</a>&nbsp;&nbsp<a href='plugin.php?id=aurora_content_control:deleteinfo&uid={$_GET['uid']}&type=0' onclick=\"showWindow('mods', this.href, 'get', 0)\">".lang('plugin/aurora_content_control', 'deletedposts').'</a></p>';
	}
	
}

//�����б�ҳ������ҳ
class plugin_aurora_content_control_forum extends plugin_aurora_content_control {
	
	public function viewthread_title_extra() {
		
		global $_G;
		
		global $postlist;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee']) && !in_array($_G['fid'],unserialize($_G['cache']['plugin']['aurora_content_control']['unchecknotsee_forums'])) && intval($_G['tid']) > 0 && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
			
			$mod = 'viewthread_thread';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';
			
		}

		return '';
	}
	
	public function forumdisplay_filter_extra_output() {
		
		global $_G;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee']) && !in_array($_G['fid'],unserialize($_G['cache']['plugin']['aurora_content_control']['unchecknotsee_forums'])) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
		
			global $separatepos;
			
			$mod = 'forumdisplay';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';

		}
		
		return '';
	}
	
	public function viewthread_postaction_output() {
		global $_G;
		global $postlist;
		$bandelconform = lang('plugin/aurora_content_control', 'bandelconform');
		$conform = lang('plugin/aurora_content_control', 'conform');
		$cancel = lang('plugin/aurora_content_control', 'cancel');
		$groupnow=$_G['groupid'];
		$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
		$formhash = FORMHASH;
		
		if(!empty($_G['cache']['plugin']['aurora_content_control']['unchecknotsee_post']) && !in_array($_G['fid'],unserialize($_G['cache']['plugin']['aurora_content_control']['unchecknotsee_forums'])) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php')){
			
			$mod = 'viewthread_post';
			
			include DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/unchecknotsee.php';
			
		}
		
		
		if(in_array($groupnow,$operatorgroup)){
			
			$fastdelete = '';
			
			foreach($postlist as $val){
				
				if($val['first'] == 0 && intval($_G['cache']['plugin']['aurora_content_control']['fastdelete']) == 1){
					
					$fastdelete = "<a href='plugin.php?id=aurora_content_control:fastdelete&pid={$val['pid']}&tid={$val['tid']}&fid={$val['fid']}' onclick=\"showWindow('mods', this.href, 'get', 0)\">".lang('plugin/aurora_content_control', 'fastdelete').'</a>';
					
				}

				$arr[] = $fastdelete."<a href='plugin.php?id=aurora_content_control:getchecker&pid={$val['pid']}&linkhash={$formhash}' onclick='ajaxmenu(this, 0, 0, 2);doane(event)'>".lang('plugin/aurora_content_control', 'checker').'</a>'."<a href=\"javascript:;\" onclick=\"showDialog('$bandelconform','confirm','','ajaxget(\'plugin.php?id=aurora_content_control:control&mod=bandel&authorid={$val['authorid']}&linkhash={$formhash}\')','1','','','$conform','$cancel')\">".lang('plugin/aurora_content_control', 'bandel').'</a>';
			}
			return $arr;
		}
		
	}
	
    public function post_message($params) {
		
		global $_G ;
		
		if( !empty($_G['cache']['plugin']['aurora_content_control']['zonenotcheck']) || !empty($_G['cache']['plugin']['aurora_content_control']['ipnotcheck'])){
			
			if(is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/zonecheck.php')){
				
				$zonenotcheck = explode('|',$_G['cache']['plugin']['aurora_content_control']['zonenotcheck']);
				
				$ipnotcheck = explode('|',$_G['cache']['plugin']['aurora_content_control']['ipnotcheck']);
				
				require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/zonecheck.php';
				
			}
			
		}
		
		$editedcheck = unserialize($_G['cache']['plugin']['aurora_content_control']['editedcheck']);
		
		if( !empty($editedcheck[0]) && is_file(DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/editedcheck.php')){
				
			require_once DISCUZ_ROOT.'./source/plugin/aurora_content_control/func/editedcheck.php';
			
		}
		
	}

}
//From: Dism��taobao��com
?>