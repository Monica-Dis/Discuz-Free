<?php  
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}

if($moderation['ignore']) {
	$ignores = C::t('forum_thread')->update_displayorder_by_tid_displayorder($moderation['ignore'], -2, -3);
	updatemoderate('tid', $moderation['ignore'], 1);
	foreach($posttableids as $id) {
		DB::query("INSERT IGNORE INTO %t(npid,ntid,nfid,ndateline,first,operatetime,operatorid) SELECT pid,tid,fid,dateline,first,%s,%s FROM %t WHERE pid IN (%n)",array('aurora_content_control',$operatetime,$operatorid,$tables[$id],$pidsformoderate));
	}
}

if($moderation['delete']) {

	$recyclebintids = array();
	
	include_once libfile('function/member');
	
	foreach(C::t('forum_thread')->fetch_all_by_tid_displayorder($moderation['delete'], $displayorder, '>=', array_keys($_G['cache']['forums'])) as $thread) {
		
		$recyclebintids[] = $thread['tid'];
		
		$pm = 'pm_'.$thread['tid'];
		
		if(!empty($_GET[$pm])){
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				$_GET[$pm] = diconv($_GET[$pm], 'utf-8');	
			}
		}
		
		if($thread['authorid'] && $thread['authorid'] != $_G['uid']) {
			$pmlist[] = array(
				'action' =>  $_GET[$pm] ? 'modthreads_delete_reason' : 'modthreads_delete',
				'notevar' => array('threadsubject' => $thread['subject'], 'reason' => $_GET[$pm]),
				'authorid' => $thread['authorid'],
			);
		}
		updatemodlog($thread['tid'], 'DEL',0,0,$_GET[$pm]);
	}
	
	if($recyclebintids) {
		$recycles = deletethread($recyclebintids, true, $credit, true);
		updatemodworks('MOD', $recycles);
	}
	
	updatemoderate('tid', $moderation['delete'], 2);
}

if($moderation['validate']) {

	$forums = array();

	$tids = $authoridarray = $moderatedthread = array();

	foreach(C::t('forum_thread')->fetch_all_by_tid_fid($moderation['validate'], array_keys($_G['cache']['forums'])) as $thread) {
		if($thread['displayorder'] != -2 && $thread['displayorder']!= -3) {
			continue;
		}
		$poststatus = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
		$poststatus = $poststatus['status'];
		$tids[] = $thread['tid'];

		if(getstatus($poststatus, 3) == 0) {
			updatepostcredits('+', $thread['authorid'], 'post', $thread['fid']);
			$attachcount = C::t('forum_attachment_n')->count_by_id('tid:'.$thread['tid'], 'tid', $thread['tid']);
			updatecreditbyaction('postattach', $thread['authorid'], array(), '', $attachcount, 1, $thread['fid']);
		}

		$forums[] = $thread['fid'];

		$pm = 'pm_'.$thread['tid'];
		if($thread['authorid'] && $thread['authorid'] != $_G['uid']) {
			$pmlist[] = array(
				'action' => 'modthreads_validate',
				'notevar' => array('tid' => $thread['tid'], 'threadsubject' => $thread['subject'], 'reason' => dhtmlspecialchars($_GET[''.$pm]), 'from_id' => 0, 'from_idtype' => 'modthreads'),
				'authorid' => $thread['authorid'],
			);
		}
	}

	if($tids) {

		$tidstr = dimplode($tids);
		C::t('forum_post')->update_by_tid(0, $tids, array('status' => 4), false, false, null, -2, 0);
		foreach($posttableids as $id) {
			C::t('forum_post')->update_by_tid($id, $tids, array('invisible' => '0'), false, false, 1);
			$status = DB::query("INSERT IGNORE INTO %t(npid,ntid,nfid,ndateline,first,operatetime,operatorid) SELECT pid,tid,fid,dateline,first,%s,%s FROM %t WHERE pid IN (%n)",array('aurora_content_control',$operatetime,$operatorid,$tables[$id],$pidsformoderate));
		}
		$validates = C::t('forum_thread')->update($tids, array('displayorder' => 0, 'moderated' => 1));

		foreach(array_unique($forums) as $fid) {
			updateforumcount($fid);
		}

		updatemodworks('MOD', $validates);
		updatemodlog($tidstr, 'MOD');
		updatemoderate('tid', $tids, 2);
	}

}

if(!empty($pmlist) && intval($_G['cache']['plugin']['aurora_content_control']['moderatepm']) > 0) {
	foreach($pmlist as $pm) {
		notification_add($pm['authorid'], 'system', $pm['action'], $pm['notevar'], 1);
	}
}
//From: Dism_taobao_com
?>