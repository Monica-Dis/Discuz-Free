<?php  
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {  
    exit('Access Denied');  
}

	
if($ignorepids = dimplode($moderation['ignore'])) {
	
	foreach($posttableids as $val){
	
		$ignores = C::t('forum_post')->update($tables[$val], $moderation['ignore'], array('invisible' => -3), false, false, 0, -2, array_keys($_G['cache']['forums']));
		
		updatemoderate('pid', $moderation['ignore'], 1);
		
		DB::query("INSERT IGNORE INTO %t(npid,ntid,nfid,ndateline,first,operatetime,operatorid) SELECT pid,tid,fid,dateline,first,%s,%s FROM %t WHERE pid IN (%n)",array('aurora_content_control',$operatetime,$operatorid,$tables[$val],$pidsformoderate));
	
	}
	
}

if($moderation['delete']) {
	
	foreach($posttableids as $val){
	
		$recyclebinpids = array();
		
		foreach(C::t('forum_post')->fetch_all($tables[$val], $moderation['delete']) as $post) {
			
			$recyclebinpids[] = $post['pid'];

			$pm = 'pm_'.$post['pid'];
			
			if(!empty($_GET[$pm])){
				$subject = DB::result_first('SELECT subject FROM %t WHERE tid = %d', array('forum_thread',$post['tid']));
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$_GET[$pm] = diconv($_GET[$pm], 'utf-8');	
				}
			}
			
			if($post['authorid'] && $post['authorid'] != $_G['uid']) {
				$pmlist[$post['pid']] = array(
					'action' =>  $_GET[$pm] ? 'reason_delete_post' : 'modreplies_delete',
					'notevar' => array('pid' => $post['pid'], 'post' => dhtmlspecialchars(cutstr($post['message'], 30)), 'reason' => dhtmlspecialchars($_GET[$pm]),'subject' => dhtmlspecialchars($subject),'tid' => $post['tid']),
					'authorid' => $post['authorid'],
				);
			}
		}
		if($recyclebinpids) {
			deletepost($recyclebinpids, 'pid', $credit, $tables[$val], true);
		}
		updatemodworks('DLP', count($moderation['delete']));
		updatemoderate('pid', $moderation['delete'], 2);
	}
}

	
if($moderation['validate']) {
	foreach($posttableids as $val){
		$forums = $threads = $attachments = $pidarray = $authoridarray = array();
		$tids = $postlist = array();
		foreach(C::t('forum_post')->fetch_all($tables[$val], $moderation['validate']) as $post) {
			if($post['first'] != 0) {
				continue;
			}
			$tids[$post['tid']] = $post['tid'];
			$postlist[] = $post;
		}
		$threadlist = C::t('forum_thread')->fetch_all($tids);
	
		foreach($postlist as $post) {
			$post['lastpost'] = $threadlist[$post['tid']]['lastpost'];
	
			$pidarray[] = $post['pid'];
			if(getstatus($post['status'], 3) == 0) {
				updatepostcredits('+', $post['authorid'], 'reply', $post['fid']);
				$attachcount = C::t('forum_attachment_n')->count_by_id('tid:'.$post['tid'], 'pid', $post['pid']);
				updatecreditbyaction('postattach', $post['authorid'], array(), '', $attachcount, 1, $post['fid']);
			}
	
			$forums[] = $post['fid'];
	
			$threads[$post['tid']]['replies']++;
			
			if($post['dateline'] > $post['lastpost']) {
				$threads[$post['tid']]['lastpost'] = array($post['dateline']);
				$threads[$post['tid']]['lastposter'] = array($post['anonymous'] && $post['dateline'] != $post['lastpost'] ? '' : $post['author']);
			}
			if($threads[$post['tid']]['attachadd'] || $post['attachment']) {
				$threads[$post['tid']]['attachment'] = array(1);
			}
			
			$pm = 'pm_'.$post['pid'];
			if($post['authorid'] && $post['authorid'] != $_G['uid']) {
				$pmlist[$post['pid']] = array(
					'action' => 'modreplies_validate',
					'notevar' => array('pid' => $post['pid'], 'tid' => $post['tid'], 'post' => dhtmlspecialchars(cutstr($post['message'], 30)), 'reason' => dhtmlspecialchars($_GET[''.$pm]), 'from_id' => 0, 'from_idtype' => 'modreplies'),
					'authorid' => $post['authorid'],
				);
			}
		}
		
		unset($postlist, $tids, $threadlist);
	
		foreach($threads as $tid => $thread) {
			C::t('forum_thread')->increase($tid, $thread);
		}
	
		foreach(array_unique($forums) as $fid) {
			updateforumcount($fid);
		}
	
		if(!empty($pidarray)) {
			C::t('forum_post')->update($tables[$val], $pidarray, array('status' => 4), false, false, null, -2, null, 0);
			$validates = C::t('forum_post')->update($tables[$val], $pidarray, array('invisible' => 0));
			updatemodworks('MOD', $validates);
			updatemoderate('pid', $pidarray, 2);
		} else {
			updatemodworks('MOD', 1);
		}
		
		$status = DB::query("INSERT IGNORE INTO %t(npid,ntid,nfid,ndateline,first,operatetime,operatorid) SELECT pid,tid,fid,dateline,first,%s,%s FROM %t WHERE pid IN (%n)",array('aurora_content_control',$operatetime,$operatorid,$tables[$val],$moderation['validate']));
	}
}

if(!empty($pmlist) && intval($_G['cache']['plugin']['aurora_content_control']['moderatepm']) > 0) {
	foreach($pmlist as $pm) {
		notification_add($pm['authorid'], 'system', $pm['action'], $pm['notevar'], 1);
	}
}
//From: Dism_taobao_com
?>