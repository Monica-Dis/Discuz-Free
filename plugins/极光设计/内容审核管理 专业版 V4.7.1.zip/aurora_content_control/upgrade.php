<?php
if((!defined('IN_DISCUZ') || !defined('IN_ADMINCP'))){
	exit('Access Denied!');
}
	 
if ($_GET['fromversion'] < 3.2) {
	$sql = <<<EOF
	
	DROP TABLE IF EXISTS pre_aurora_content_control_bandellog;
	
	CREATE TABLE pre_aurora_content_control_bandellog (
	  id int(10) unsigned NOT NULL key auto_increment,
	  uid int(10) unsigned NOT NULL  DEFAULT '0',
	  operatetime int(10) unsigned NOT NULL  DEFAULT '0' , 
	  operatorid int(10) unsigned NOT NULL  DEFAULT '0',
	  INDEX operatetime(operatetime)
	)
	
	ENGINE=MyISAM;
EOF;
	runquery($sql);
}

if ($_GET['fromversion'] < 4.0) {
	$sql = <<<EOF
	ALTER TABLE pre_aurora_content_control ADD first tinyint(1) unsigned NOT NULL DEFAULT '0';
	ALTER TABLE pre_aurora_content_control ADD INDEX (first);
EOF;
	runquery($sql);
}

if ($_GET['fromversion'] < '4.4.7') {
	$sql = <<<EOF
	ALTER TABLE pre_aurora_content_control ADD editstatus tinyint(1) unsigned NOT NULL DEFAULT '0';
	ALTER TABLE pre_aurora_content_control ADD edittime int(10) unsigned NOT NULL DEFAULT '0';
	ALTER TABLE pre_aurora_content_control ADD INDEX (ntid);
	ALTER TABLE pre_aurora_content_control ADD INDEX (editstatus);
EOF;
	runquery($sql);
}

if ($_GET['fromversion'] < '4.5.1') {
	$sql = <<<EOF
	
	DROP TABLE IF EXISTS pre_aurora_content_control_usermanage;
	
	CREATE TABLE pre_aurora_content_control_usermanage (
      id int(10) unsigned NOT NULL key auto_increment,
	  username char(15) NOT NULL,
	  UNIQUE username(username)
	)
	
	ENGINE=MyISAM;
EOF;
	runquery($sql);
}

if ($_GET['fromversion'] < '4.5.4') {
	$sql = <<<EOF
	
	DROP TABLE IF EXISTS pre_aurora_content_control_userinfo_post;
	
	CREATE TABLE pre_aurora_content_control_userinfo_post (
      id int(10) unsigned NOT NULL key auto_increment,
	  pid int(10) unsigned NOT NULL  DEFAULT '0',
	  uid int(10) unsigned NOT NULL  DEFAULT '0',
	  invisible tinyint(1) unsigned NOT NULL  DEFAULT '0',
	  tableid tinyint(2) unsigned NOT NULL  DEFAULT '0',
	  UNIQUE pid(pid)
	)
	
	ENGINE=MyISAM;
EOF;
	runquery($sql);
}

if ($_GET['fromversion'] < '4.5.9') {
	$sql = <<<EOF
	
	DROP TABLE IF EXISTS pre_aurora_content_control_editedcheck;
	
	CREATE TABLE pre_aurora_content_control_editedcheck (
	  pid int(10) unsigned NOT NULL key,
	  tid int(10) unsigned NOT NULL DEFAULT '0'
	)
	
	ENGINE=MyISAM;
EOF;
	runquery($sql);
}

$finish = TRUE;
?>