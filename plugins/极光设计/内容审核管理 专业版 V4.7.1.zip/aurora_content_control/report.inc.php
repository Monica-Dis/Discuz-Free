<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}

//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$nobandelgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['nobandelgroup']);
$othername['check'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['check_name']);
$othername['moderate'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['moderate_name']);
$othername['report'] = dhtmlspecialchars($_G['cache']['plugin']['aurora_content_control']['report_name']);

if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}                         

//��������lib�ļ�����

$pagesize = intval($_G['cache']['plugin']['aurora_content_control']['pagesize']);
loadcache(array('forums','posttable_info'));

require_once libfile('function/attachment');
require_once libfile('function/discuzcode');
require_once libfile('function/misc');

//������ʼ��
if(empty($_G['cache']['plugin']['aurora_content_control']['cloudimgurl'])){
	$imgurl = $_G['setting']['attachurl'];
}else{
	$imgurl = $_G['cache']['plugin']['aurora_content_control']['cloudimgurl'];
}

$posttables = array_keys($_G['cache']['posttable_info']);

if(empty($posttables)){
	$posttables = array(0);
}

$checkstatus = intval($_GET['checkstatus']);

//���岿��

$count['0'] = DB::result_first('SELECT count(*) FROM %t WHERE opuid = 0', array('common_report'));   // ��ѯ�ٱ�����

$count['1'] = DB::result_first('SELECT count(DISTINCT url) FROM %t WHERE opuid != 0', array('common_report'));   // ��ѯ�ٱ�����

//��ҳ������ʼ��

$amount = $count[$checkstatus];

$pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0;   // ������ҳ��

$page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

$page = $page > $pagecount ? 1 : $page;   // ȡ�õ�ǰҳֵ

$startlimit = ($page - 1) * $pagesize;   // ��ѯ��ʼ��ƫ����

//���ݲ�ѯ

if(empty($checkstatus)){
	$urls = DB::fetch_all('SELECT * FROM %t WHERE opuid = 0 ORDER BY dateline DESC LIMIT %d,%d', array('common_report',$startlimit,$pagesize),'id');
}else{
	$urls = DB::fetch_all('SELECT * FROM %t WHERE opuid != 0 ORDER BY dateline DESC LIMIT %d,%d', array('common_report',$startlimit,$pagesize),'id');
}

foreach($urls as $k => $v){
	if(strpos($v['url'],'viewthread')){
		$temp_viewthread = explode('tid=',$v['url']);
		$temp_viewthread = explode('&',$temp_viewthread[1]);
		$tids[$k] = $temp_viewthread[0];
		$temp_ridinfo[$k] = $v;
		$temp_ridinfo[$k]['tid'] = $temp_viewthread[0];
	}
	if(strpos($v['url'],'thread-')){
		$temp_thread = explode('thread-',$v['url']);
		$temp_thread = explode('-',$temp_thread[1]);
		$tids[$k] = $temp_thread[0];
		$temp_ridinfo[$k] = $v;
		$temp_ridinfo[$k]['tid'] = $temp_thread[0];
	}
	if(strpos($v['url'],'redirect')){
		$temp = explode('pid=',$v['url']);
		$pidsforquery[$temp['1']] = $temp['1'];
		$report[$temp['1']]['id'] = $k;
		$report[$temp['1']]['uid'] = $v['uid'];
		$report[$temp['1']]['username'] = $v['username'];
		$report[$temp['1']]['opuid'] = $v['opuid'];
		$report[$temp['1']]['opname'] = $v['opname'];
		$report[$temp['1']]['url'] = $v['url'];
		$report[$temp['1']]['message'][] = $v['message'];
		$report[$temp['1']]['dateline'] = $v['dateline'];
		$report[$temp['1']]['optime'] = $v['optime'];
		$report[$temp['1']]['opresult'] = $v['opresult'];
		$report[$temp['1']]['num'] = $v['num'];
	}
}

$rs = $query = array();

foreach ($posttables as $id) {
	$id = intval($id);
	$table[$id] = empty($id) ? 'forum_post' : 'forum_post_'.$id;
	$query = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n) OR (tid IN (%n) AND first = 1)', array($table[$id],$pidsforquery,array_unique($tids)),'pid');
	$rs = $rs + $query;
	foreach($query as $pid => $v){
		$posttableids[$pid] = $id;
		if($v['first'] == 1){
			$tid_pid[$v['tid']] = $v['pid'];
		}
	}
}

foreach($temp_ridinfo as $rid => $v){
	$report[$tid_pid[$v['tid']]]['id'] = $rid;
	$report[$tid_pid[$v['tid']]]['uid'] = $v['uid'];
	$report[$tid_pid[$v['tid']]]['username'] = $v['username'];
	$report[$tid_pid[$v['tid']]]['opuid'] = $v['opuid'];
	$report[$tid_pid[$v['tid']]]['opname'] = $v['opname'];
	$report[$tid_pid[$v['tid']]]['url'] = $v['url'];
	$report[$tid_pid[$v['tid']]]['message'][] = $v['message'];
	$report[$tid_pid[$v['tid']]]['dateline'] = $v['dateline'];
	$report[$tid_pid[$v['tid']]]['optime'] = $v['optime'];
	$report[$tid_pid[$v['tid']]]['opresult'] = $v['opresult'];
	$report[$tid_pid[$v['tid']]]['num'] = $v['num'];
}

foreach($rs as $uidsforgroupid_temp){
	$uidsforgroupid[] = $uidsforgroupid_temp['authorid'];
};
$uidsforgroupid = array_unique($uidsforgroupid);

$rs_groupid = DB::fetch_all('SELECT uid,groupid,regdate FROM %t WHERE uid IN (%n)', array('common_member',$uidsforgroupid),'uid');	

 // ��ʾ��ҳ
$multipage = multi($amount, $pagesize, $page, "plugin.php?id=aurora_content_control:report&checkstatus=$checkstatus", $pagecount);  

if($checkstatus == 0){
	foreach($rs as $clear){
		if($clear['invisible'] == -1 || $clear['invisible'] == -5){
			$pidsforclear[] = $report[$clear['pid']]['id'];
		}
	}
	$pidsforclear_str = dimplode($pidsforclear);
	$count['uncheck'] = $count['uncheck'] - count($pidsforclear);
	DB::update('common_report',array('opuid' => intval($_G['uid']),'opname' => daddslashes($_G['username']),'optime' => intval($_G['timestamp']),'opresult' => 'ignore')," id IN ($pidsforclear_str)");
}

$pagename = explode(':',$_GET['id']);
$current[$pagename[1]] = 'current';

$checkmobile = checkmobile();

if(empty($checkmobile)){
	include template("aurora_content_control:report");
}else{
	include template("aurora_content_control:touch/report");
}
//From: Dism_taobao_com
?>