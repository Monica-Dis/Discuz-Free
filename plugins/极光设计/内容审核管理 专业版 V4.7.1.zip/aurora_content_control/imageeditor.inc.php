<?php  
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if((!defined('IN_DISCUZ'))){
	exit('Access Denied!');
}


//Ȩ����֤

loadcache('plugin');

$groupnow=$_G['groupid'];
$operatorgroup = unserialize($_G['cache']['plugin']['aurora_content_control']['operatorgroup']);
$usermanagegroup = unserialize($_G['cache']['plugin']['aurora_content_control']['usermanagegroup']);


if(!(in_array($groupnow,$operatorgroup))){	
	showmessage(lang('plugin/aurora_content_control', 'forbiden'), null, array(), array('showmsg' => true, 'login' => 1));
}

if(empty($_G['cache']['plugin']['aurora_content_control']['cloudimgurl'])){
	$imgurl = $_G['setting']['attachurl'];
}else{
	$imgurl = $_G['cache']['plugin']['aurora_content_control']['cloudimgurl'];
}

if($_GET['mod'] == 'updateattach'){
	
	require_once libfile('function/post');
	require_once libfile('function/forum');

	$updateaids = array(
		intval($_GET['oldaid']) => intval($_GET['newaid']),
	);
	$newaids = array(
		intval($_GET['oldaid']) => array('description' => '')
	);

	updateattach(false,intval($_GET['tid']),intval($_GET['pid']),$newaids,$updateaids,intval($_GET['authorid']));
	
	DB::delete('forum_attachment',array('aid' => intval($_GET['newaid'])));
	
	$tableid = DB::result_first('SELECT tableid FROM %t WHERE aid = %d', array('forum_attachment',$_GET['oldaid']));
	
	$table = 'forum_attachment_'.$tableid;
	
	$imgsrc = DB::result_first('SELECT attachment FROM %t WHERE aid = %d', array($table,$_GET['oldaid']));
	
	echo $imgsrc;
	
}else{

	$filename = explode('/',$_GET['filename']);

	include template("aurora_content_control:imageeditor");
	
}

//From: Dism_taobao-com
?>