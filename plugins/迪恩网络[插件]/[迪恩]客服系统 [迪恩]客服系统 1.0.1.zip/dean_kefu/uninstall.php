<?php
/**
 *	[迪恩客服系统(dean_kefu.{modulename})] (C)2019-2099 Powered by DisM!应用中心 https://DisM.Taobao.Com.
 *	Version: 1.0.1
 *	Date: 2019-6-25 10:42
 * DisM!用户交流群: ①群778390776
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;

?>