<?php
/**
 *	[�϶��ͷ�ϵͳ(dean_kefu.{modulename})] (C)2019-2099 Powered by DisM!Ӧ������ https://DisM.Taobao.Com.
 *	Version: 1.0.1
 *	Date: 2019-6-25 10:42
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_dean_kefu {
	//TODO - Insert your code here
	/**
	 * @Methods describe
	 * @return string type
	 */
	public function global_header() {
		
		//TODO - Insert your code here
		loadcache('plugin');
		global $_G;
		$dnv=$_G['cache']['plugin']['dean_kefu'];
		$deanzdy=$dnv['deanzdy'];
		$deanzxsj=$dnv['deanzxsj']; //����ʱ��
		
		$deankf1=$dnv['deankf1']; //�ͷ�����
		$deankf2=$dnv['deankf2'];
		$deankf3=$dnv['deankf3'];
		$deankf4=$dnv['deankf4'];
		$deankf5=$dnv['deankf5'];
		$deankf6=$dnv['deankf6'];
		
		$deanqq1=$dnv['deanqq1']; //�ͷ�QQ��
		$deanqq2=$dnv['deanqq2'];
		$deanqq3=$dnv['deanqq3'];
		$deanqq4=$dnv['deanqq4'];
		$deanqq5=$dnv['deanqq5'];
		$deanqq6=$dnv['deanqq6'];
		
		$deanewmdz=$dnv['deanewmdz'];//΢�Ŷ�ά���ַ
		$deantel=$dnv['deantel'];//	��ϵ�绰
		$deanewmtxt=$dnv['deanewmtxt'];//΢�Ŷ�ά���ַ
		
		$deanor=$dnv['deanor'];
		if($deanor){
		include template('dean_kefu:kefu');
		return $return;	//TODO modify your return code here
		
		}
		
	}

}
//From: Dism_taobao_com
?>