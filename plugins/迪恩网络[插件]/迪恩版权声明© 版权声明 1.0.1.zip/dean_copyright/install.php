<?php
/**
 *	[迪恩客服系统(dean_kefu.{modulename})] (C)2019-2099 Powered by DISM.TAOBAO.COM工作室 https://dean17.com.
 *	Version: 1.0.1     最新插件：http://t.cn/Aiux1Jx1
 *	Date: 2019-6-25 10:42
 * 作者QQ dism.taobao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$finish = TRUE;

?>