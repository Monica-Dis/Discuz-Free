<?php
/**
 *	[�϶���Ȩ�������(dean_copyright.{modulename})] (C)2019-2099 [DisM!] (C)2001-2099 DisM Inc.
 *	Version: 1.0.1     ���²����http://t.cn/Aiux1Jx1
 *	Date: 2019-7-14 09:28
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_dean_copyright {
	//TODO - Insert your code here
	
}
class plugin_dean_copyright_forum extends plugin_dean_copyright{
	
	public function viewthread_modaction(){
		
		loadcache('plugin');
		
		global $_G;
		
		$varbl=$_G['cache']['plugin']['dean_copyright'];//�������
		
		$deanor=intval($varbl['deanor']);
		
		$deantextarea=$varbl['deantextarea'];
		
		$deanlxfs=$varbl['deanlxfs'];
		
		$deanbk=$varbl['deanbk'];
		
		$deantxtcolor=$varbl['deantxtcolor'];
		
		$deansize=intval($varbl['deansize']);
		
		$deanbkcolor=$varbl['deanbkcolor'];
		
		$denbjcolor=$varbl['denbjcolor'];
		
		$deanbtbgcolor=$varbl['deanbtbgcolor'];
	
		$this->deanbk =unserialize($varbl['deanbk']); //�жϰ��
		
		if($deanor){
			
			if(in_array($_G['fid'],$this->deanbk)){
				
				include template('dean_copyright:deanbqsm');
				
				
				return $return;
				
				}
			
			}
		
		}
	
	}
	
	class plugin_dean_copyright_portal extends plugin_dean_copyright{
	
	public function view_article_content(){
		
		loadcache('plugin');
		
		global $_G;
		
		$varbl=$_G['cache']['plugin']['dean_copyright'];//�������
		
		$deanor=intval($varbl['deanor']);
		
		$deantextarea=$varbl['deantextarea'];
		
		$deanlxfs=$varbl['deanlxfs'];
		
		$deanbk=$varbl['deanbk'];
		
		$deantxtcolor=$varbl['deantxtcolor'];
		
		$deansize=intval($varbl['deansize']);
		
		$deanbkcolor=$varbl['deanbkcolor'];
		
		$denbjcolor=$varbl['denbjcolor'];
		
		$deanbtbgcolor=$varbl['deanbtbgcolor'];
		
		if($deanor){
		
			include template('dean_copyright:deanbqsm');
			
			return $return;
			
			}
		
		}
	
	}	
	
?>