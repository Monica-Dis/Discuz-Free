<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['level']){
			
	
	

		$province = intval($_GET['province']);
		$city = intval($_GET['city']);
		$county = intval($_GET['county']);
		
		$query = DB::query("SELECT * FROM ".DB::table('common_district')." WHERE level = 1 order by id");
		$result = '<select id="province" name="province"><option>-'.lang('plugin/xj_event', 'chenshi').'-</option>';
		while($value = DB::fetch($query)){
			$result .= '<option value="'.$value['id'].'" '.($value['id']==$province?'selected':'').'>'.$value['name'].'</option>';
		}
		$result .= '</select>';
		
		if($province){
			$query = DB::query("SELECT * FROM ".DB::table('common_district')." WHERE level = 2 AND upid=$province order by id");
			$result .= '<select id="city" name="city"><option>-'.lang('plugin/xj_event', 'chenshi').'-</option>';
			while($value = DB::fetch($query)){
				$result .= '<option value="'.$value['id'].'" '.($value['id']==$city?'selected':'').'>'.$value['name'].'</option>';
			}
			$result .= '</select>';
		}
		if($city){
			$count = DB::result_first("SELECT count(*) FROM ".DB::table('common_district')." WHERE level = 3 AND upid=$city");
			if($count){
				$query = DB::query("SELECT * FROM ".DB::table('common_district')." WHERE level = 3 AND upid=$city order by id");
				$result .= '<select id="county" name="county"><option>-'.lang('plugin/xj_event', 'zhouxian').'-</option>';
				while($value = DB::fetch($query)){
					$result .= '<option value="'.$value['id'].'" '.($value['id']==$county?'selected':'').'>'.$value['name'].'</option>';
				}
				$result .= '</select>';
			}
		}
		if($county){
			$count = DB::result_first("SELECT count(*) FROM ".DB::table('common_district')." WHERE level = 4 AND upid=$county");
			if($count){
				$query = DB::query("SELECT * FROM ".DB::table('common_district')." WHERE level = 4 AND upid=$county order by id");
				$result .= '<select id="town" name="town"><option>-'.lang('plugin/xj_event', 'xiangzhen').'-</option>';
				while($value = DB::fetch($query)){
					$result .= '<option value="'.$value['id'].'">'.$value['name'].'</option>';
				}
				$result .= '</select>';
			}else{
				$result .= '<!--end-->';
			}
		}

	exit($result);
}else{
	$upid = intval($_GET['upid']);
	if($upid){
		$city = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE upid = $upid");
	}else{
		$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1 order by id");
	}
	include template('xj_event:city');
}
//From: dis'.'m.tao'.'bao.com
?>