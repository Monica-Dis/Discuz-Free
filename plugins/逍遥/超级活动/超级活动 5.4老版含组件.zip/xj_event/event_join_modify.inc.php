<?php
/**
 *    [�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//�ж��Ƿ��ǰ��������
if (strpos($_SERVER["HTTP_USER_AGENT"], 'Appbyme') > 0) {
    $Appbyme = true;
}
if (strpos($_SERVER["HTTP_USER_AGENT"], 'MAGAPP') > 0) {
    $magapp = true;
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') > 0) {
    $QianFan = true;
}

if (!$_G['uid']) {
    showmessage('not_loggedin', null, array(), array('login' => 1));
}

//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

include 'include/sms_func.php';
$tid     = intval($_GET['tid']);
$uid     = intval($_G['uid']);
$items   = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid = B.tid WHERE A.tid = '$tid'"));
$eid     = $items['eid'];
$setting = unserialize($items['setting']);
//������ʽ�ж�
if ($setting['nodaibaoming']) {
    dheader('location: plugin.php?id=xj_event:event_join_modify_single&tid=' . $tid);
}

if ($_GET['action'] == 'modifyfull') {
    if ($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    $post = file_get_contents("php://input");
    $post = json_decode($post, true);
    if ($_G['charset'] == 'gbk') {
        foreach ($post as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $post[$key][$key2] = iconv('utf-8', 'gbk', $value2);
            }
        }
    }

    //��֤�ֻ��ź�����֤
    if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/checkapply/checkapply.php')) {
        @include 'module/checkapply/checkapply.php';
    }

    $applynumber = count($post); //�����޸ĺ�������
    //��ȡ�ѱ���������
    $count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and uid=$uid");
    if ($count != $applynumber) {
        //����޸ĵı���������ǰ��
        if ($applynumber > $count) {
            //�жϻ��ֹ�����
            $member = DB::fetch_first("SELECT extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8 FROM " . DB::table('common_member_count') . " WHERE uid = " . $_G['uid']);
            /*
            if($member['extcredits'.$items['use_extcredits']]<($items['use_extcredits_num']*($applynumber-$count))){
            $result['full'] = 2;
            $result['message'] = $_G['setting']['extcredits'][$items['use_extcredits']]['title'].lang('plugin/xj_event', 'bgwfcj');
            $result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
            echo json_encode($result);
            exit;
            }
             */
            //��֤���������Ƿ�
            $applynum      = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"); //�ѱ�������
            $applycountnum = DB::result_first("SELECT event_number FROM " . DB::table('xj_event') . " WHERE tid='$tid'"); //�������
            if ($applycountnum > 0) {
                if (($applynumber - $count) > ($applycountnum - $applynum)) {
                    $result['full']    = 2;
                    $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', lang('plugin/xj_event', 'baomrsym')) : lang('plugin/xj_event', 'baomrsym');
                    echo json_encode($result);
                    exit;
                }
            }
        }
    }
    //ɾ����ǰ�ı���
    DB::query("DELETE FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid = $uid");
    //��ԭ���ֲ���
    /*
    if($items['use_extcredits_num']>0){
    $extnum = $items['use_extcredits_num']*$count;
    updatemembercount($_G['uid'],array($items['use_extcredits']=>$extnum));
    }
     */
    //��ȡ���֯�˵�ID
    $event_uid = $items['authorid'];
    //�����
    $event_title = $items['subject'];
    //���ʼʱ��
    $event_starttime = dgmdate($items['starttime'], 'dt');
    //�������������ݿ�
    $first = 1;
    if ($setting['myuserfield']) {
        $myuserfield = $eventcore->GetUserField($setting['myuserfield']); //�±����ֶ�
    }
    foreach ($post as $key => $value) {
        $ufielddata = array();
        foreach ($value as $key2 => $value2) {
            if ($key2 != 'message' && $key2 != 'session') {
                $ufielddata[$key2] = $value2;
            }
        }

        //�µı����ֶεı������������ݿ�
        foreach ($myuserfield as $val) {
            $ufielddata['myfield' . $val['id']] = $value['myfield' . $val['id']];
        }

        $ufielddata                = serialize($ufielddata);
        $eventapply                = array();
        $eventapply['tid']         = $tid;
        $eventapply['eid']         = $items['eid'];
        $eventapply['uid']         = $uid;
        $eventapply['realname']    = addslashes($value['realname']);
        $eventapply['qq']          = addslashes($value['qq']);
        $eventapply['mobile']      = addslashes($value['mobile']);
        $eventapply['bmmessage']   = addslashes($value['message']);
        $eventapply['dateline']    = $_G['timestamp'];
        $eventapply['applynumber'] = 1;
        $eventapply['ufielddata']  = $ufielddata;
        $eventapply['seccode']     = random(8, 1);
        $eventapply['session']     = intval($value['session']);
        $eventapply['first']       = $first;
        DB::insert('xj_eventapply', $eventapply);
        $first = 0; //����������0
    }
    //�û����ص���Ϣ���ݱ��Ƿ���ڣ������ھ��½�
    $num = DB::result_first("SELECT count(*) FROM " . DB::table('xj_event_member_info') . " WHERE uid = '$uid'");
    if ($num == 0) {
        DB::query("INSERT INTO " . DB::table('xj_event_member_info') . " (uid) VALUES ('$uid')");
    }
    //���ֲ���
    /*
    if($items['use_extcredits_num']>0){
    $extnum = $items['use_extcredits_num'] * $applynumber;
    updatemembercount($_G['uid'],array($items['use_extcredits']=>-$extnum));
    }
     */

    //��֪ͨ
    notification_add($event_uid, 'system', 'activity_notice', array('tid' => $tid, 'subject' => $event_title));
    $result['full']    = 1;
    $result['message'] = lang('plugin/xj_event', 'bmzlxgcg');
    $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
    $result['url']     = "forum.php?mod=viewthread&tid=$tid";
    echo json_encode($result);
    exit;

}
//�û���������
$apply = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid=$tid AND uid=$uid ORDER BY first DESC");
foreach ($apply as $key => $value) {
    $apply[$key]['ufielddata'] = unserialize($value['ufielddata']);
}
//������
$applynumber = count($apply);
//��һ��TAB���
$tabCounter = $applynumber + 1;

//��ȡ�û������ֶ�
if ($_G['mobile']) {
    $userfield       = unserialize($items['userfield']);
    $selectuserfield = unserialize($items['userfield']);
    if ($selectuserfield) {
        if ($selectuserfield) {
            $htmls = $settings = array();
            require_once libfile('function/profile');
            foreach ($selectuserfield as $fieldid) {
                /*
                if(empty($ufielddata['userfield'])) {
                $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                foreach($selectuserfield as $val) {
                if($val == 'birthday'){
                $ufielddata['userfield']['birthyear'] =  $memberprofile['birthyear'];
                $ufielddata['userfield']['birthmonth'] =  $memberprofile['birthmonth'];
                }
                $ufielddata['userfield'][$val] = $memberprofile[$val];
                }
                unset($memberprofile);
                }
                 */
                $html = profile_setting($fieldid, $ufielddata['userfield'], false, true);

                if ($fieldid == 'birthday') {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    $mybirthday    = $memberprofile['birthyear'] . '-' . $memberprofile['birthmonth'] . '-' . $memberprofile['birthday'];
                    $mybirthday    = strtotime($mybirthday);
                    $mybirthday    = date("Y-m-d", $mybirthday);
                    $html          = '<input name="birthday" type="date" id="birthday" value="' . $mybirthday . '" class="join_text" />';
                }
                if ($fieldid == 'residecity') {
                    $html = '<div><input type="hidden" name="residecity" value=""><span></span> <button class="residecity ui-btn">' . lang('plugin/xj_event', 'select') . '</button><span></span></div>';
                }
                if ($html) {
                    if (strpos($html, 'checkbox') > 0) {
                        $html = '<fieldset data-role="controlgroup">' . $html . '</fieldset>';
                        $html = str_replace(' class="lb"', '', $html);
                        //echo $html;
                        //exit();
                    }

                    //�����б�
                    if (strpos($html, 'select name=') > 0 && strpos($html, 'name="birthprovince"') < 1) {

                        if (strpos($html, 'name="gender"') > 0) {
                            preg_match('/name\=\"(.+?)\"/i', $html, $selectname);
                            preg_match_all('/value\=\"(.+?)\"/i', $html, $optionvalue);
                            preg_match_all('/\"\>(.+?)\<\/op/i', $html, $optiontext);
                            $html = '<div class="xjselect"><input type="hidden" name="' . $selectname[1] . '" id="' . $selectname[1] . '" value="">';
                            foreach ($optionvalue[1] as $opkey => $opvalue) {
                                $html .= '<span data-value="' . $opvalue . '" style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;font-weight:normal; text-shadow:none;">' . $optiontext[1][$opkey] . '</span>';
                            }
                            $html .= '</div><div style="clear:both;"></div>';
                        } else {
                            preg_match('/name\=\"(.+?)\"/i', $html, $selectname);
                            preg_match_all('/value\=\"(.+?)\"/i', $html, $optionvalue);
                            $html = '<div class="xjselect"><input type="hidden" name="' . $selectname[1] . '" id="' . $selectname[1] . '" value="">';
                            foreach ($optionvalue[1] as $opvalue) {
                                $html .= '<span data-value="' . $opvalue . '" style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;font-weight:normal; text-shadow:none;">' . $opvalue . '</span>';
                            }
                            $html .= '</div><div style="clear:both;"></div>';
                        }

                    }

                    $html = preg_replace("/<div class=\"rq mtn\" id=\"showerror.+<\/div>/is", "", $html);
                    if (strpos($html, 'type="text"') > 0) {
                        $html = str_replace('class="px"', 'class="join_text"', $html);
                    }
                    $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                    $htmls[$fieldid]    = $html;
                }
            }
        }
    } else {
        $selectuserfield = '';
    }
} else {
    $userfield       = unserialize($items['userfield']);
    $selectuserfield = unserialize($items['userfield']);
    if ($selectuserfield) {
        if ($selectuserfield) {
            $htmls = $settings = array();
            require_once libfile('function/profile');
            foreach ($selectuserfield as $fieldid) {
                /*
                if(empty($ufielddata['userfield'])) {
                $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                foreach($selectuserfield as $val) {
                if($val == 'birthday'){
                $ufielddata['userfield']['birthyear'] =  $memberprofile['birthyear'];
                $ufielddata['userfield']['birthmonth'] =  $memberprofile['birthmonth'];
                }
                $ufielddata['userfield'][$val] = $memberprofile[$val];
                }
                unset($memberprofile);
                }
                 */
                $html = profile_setting($fieldid, $ufielddata['userfield'], false, true);
                //$html = preg_replace('/value\=\"(.+?)\"/i','value=""',$html);

                if ($fieldid == 'birthday') {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    $mybirthday    = $memberprofile['birthyear'] . '-' . $memberprofile['birthmonth'] . '-' . $memberprofile['birthday'];
                    $html          = '<div style="height:36px;"><input name="birthday" type="text" value="' . $mybirthday . '" class="dateselect" /><div></div></div>';
                }
                if ($fieldid == 'residecity') {
                    $html = '<div style="height:36px;"><input type="hidden" name="residecity" value=""><span></span> <button class="residecity">' . lang('plugin/xj_event', 'select') . '</button><span></span></div>';
                }
                if ($html) {
                    $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                    $htmls[$fieldid]    = $html;
                }
            }
        }
    } else {
        $selectuserfield = '';
    }
}

//checkbox����
foreach ($apply as $key => $value) {
    if (!empty($selectuserfield)) {
        foreach ($selectuserfield as $fieldid) {
            if ($settings[$fieldid]['available']) {
                if ($settings[$fieldid]['formtype'] == 'checkbox') {
                    $apply[$key]['ufielddata'][$fieldid] = $htmls[$fieldid];
                    $tmp                                 = explode(',', $value['ufielddata'][$fieldid]);
                    foreach ($tmp as $cbvalue) {
                        $apply[$key]['ufielddata'][$fieldid] = str_replace($cbvalue . '"', $cbvalue . '" checked', $apply[$key]['ufielddata'][$fieldid]);
                    }
                }
            }
        }
    }
}
//���˵��Զ����������
/*
foreach($htmls as $key=>$value){
$htmls[$key] =      preg_replace("/value=\"[^\"]+\"/", "value=\"\"", $value);
}
 */

//�µı����ֶ�
if ($setting['myuserfield']) {
    $myuserfield = $eventcore->GetUserField($setting['myuserfield']);
    foreach ($apply as $key => $value) {
        $apply[$key]['myuserfield'] = $eventcore->GetUserField($setting['myuserfield'], $value['ufielddata']);
    }
}

include template('xj_event:event_join_modify');
