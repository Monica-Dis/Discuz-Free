<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/lottery/setting.php')) {
		@include 'module/lottery/setting.php';
	}else{
		showmessage('Please purchase module');
	}



?>