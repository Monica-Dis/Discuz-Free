<?php
/**
 *    [�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (strpos($_SERVER["HTTP_USER_AGENT"], 'Appbyme') > 0) {
    $Appbyme = true;
}
if (strpos($_SERVER["HTTP_USER_AGENT"], 'MAGAPP') > 0) {
    $magapp = true;
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') > 0) {
    $QianFan = true;
}


$tid     = intval($_GET['tid']);
$items   = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid = B.tid WHERE A.tid = '$tid'"));
$setting = unserialize($items['setting']);
if ($setting['onlyappbymejoin'] && $_GET['action'] != 'checkseccode') { //��APP����
    if (!$Appbyme && !$magapp) {
        //showmessage(lang('plugin/xj_event', 'qxzsjappkhdbm'), $_G['cache']['plugin']['xj_event']['appurl']);
        dheader('location: '.$_G['cache']['plugin']['xj_event']['appurl']);
    }
}






if ($Appbyme && !$_G['uid']) {
    //���׵�¼
    exit('<script language="javascript" src="source/plugin/xj_event/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $_G['siteurl'] . 'plugin.php?id=xj_event:event_join&tid=' . $_GET['tid'] . '";
        });
    });
    </script>');
}
if ($magapp && !$_G['uid']) {
    //���׵�¼
    exit('<script src="source/plugin/xj_event/js/magjs-x.js"></script>
    <script>
        mag.toLogin(function(){
            var url = "' . $_G['siteurl'] . 'plugin.php?id=xj_event:event_join&tid=' . $_GET['tid'] . '",
                  params = {
                      name: "zz"
                  };
            mag.newWin(url, params);

            //window.location.href="' . 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . '";
        });
    </script>
    ');
}
if ($QianFan && !$_G['uid']) {
    //ǧ����¼
    exit('<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>
    ');
}
//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

if ($_COOKIE['xj_event_fromuid']) {
    $fromuid = intval($_COOKIE['xj_event_fromuid']);
}

$tid     = intval($_GET['tid']);
$items   = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid = B.tid WHERE A.tid = '$tid'"));
$setting = unserialize($items['setting']);
if ($setting['onlyappbymejoin']) {
    if (!$Appbyme && !$magapp) {
        showmessage(lang('plugin/xj_event', 'qxzsjappkhdbm'), $_G['cache']['plugin']['xj_event']['appurl']);
    }
}
if ($setting['onlyvip']) {
    $vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
    if (!in_array($_G['groupid'], $vipgroup)) {
        showmessage(lang('plugin/xj_event', 'benhuodongjingxian') . ($_G['cache']['plugin']['xj_card']['cardname'] ? $_G['cache']['plugin']['xj_card']['cardname'] : 'VIP') . lang('plugin/xj_event', 'yonghubaomin'), 'plugin.php?id=xj_card');
        exit;
    }
}

if ($setting['nodaibaoming']) {
    if ($_GET['action'] == 'cannel') {
        dheader('location: plugin.php?id=xj_event:event_join_single&tid=' . $tid . '&action=cannel&formhash=' . $_GET['formhash']);
    } else {
        dheader('location: plugin.php?id=xj_event:event_join_single&tid=' . $tid);
    }
}

//������������
if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/wsqcenter/event_view.php')) {
    $retrunurl = $_G['siteurl'] . 'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid=' . $tid;
} else {
    $retrunurl = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $tid;
}

if ($_G['mobile']) {
    if ($_G['wechat']['setting']['wsq_allow']) {
        if (!$_G['uid'] && $_G['mobile']) {
            $url = "http://wsq.discuz.com/index.php?c=index&a=plugin&siteid=" . $_G['wechat']['setting']['wsq_siteid'] . "&pluginid=xj_event:autologin&param=" . urlencode(base64_encode("reload=event_join&tid=$tid")) . "&login=yes&mobile=2";
            dheader('location: ' . $url);
            exit;
        }
    } else {
        if (!$_G['uid'] && $_G['mobile']) {
            //$url = 'member.php?mod=logging&action=login&mobile=2';
            $thisurl = $_G['siteurl'] . 'plugin.php?id=xj_event:event_join&tid=' . $tid;
            $url     = $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($thisurl);
            //$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$tid);
            dheader('location: ' . $url);
            exit;
        }
    }
}

if (!$_G['uid']) {
    showmessage('not_loggedin', null, array(), array('login' => 1));
}


if ($setting['onlysubscribeweixin']) { //���޹�ע΢�ű���
    if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
        require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
        $xj_wxmessagecore = new xj_wxmessagecore();
        $res         = $xj_wxmessagecore->getweixinuserinfo($_G['uid']);
        if($res['subscribe']!=1){
            $url = $_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=guanzhu';
            if($_G['mobile']){
                dheader('location: '.$url);
            }else{
                if($_G['cache']['plugin']['xj_event']['weixinurl']){
                    $url = $_G['cache']['plugin']['xj_event']['weixinurl'];
                }
                showmessage(lang('plugin/xj_event','qingxianguanzhuweixinhaozbm'),$url);
            } 
        }
    }
}






include 'include/sms_func.php';
$tid = intval($_GET['tid']);
$uid = intval($_G['uid']);
$eid = $items['eid'];
//����΢��֧������
if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
    @include $xj_event_wxset;
}
if ($wxset['wsqonly']) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false) {
        $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_pay&tid=$tid";
    } else {
        $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:wsq_pay&tid=$tid";
    }
} else {
    $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_pay&tid=$tid";
}

if ($_GET['action'] == 'joinfull') {
    if ($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    $post = file_get_contents("php://input");
    $post = json_decode($post, true);
    if ($_G['charset'] == 'gbk') {
        foreach ($post as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $post[$key][$key2] = iconv('utf-8', 'gbk', $value2);
            }
        }
    }
    //��֤�ֻ��ź�����֤
    if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/checkapply/checkapply.php')) {
        @include 'module/checkapply/checkapply.php';
    }
    //�жϻظ���ſ��Ա���
    if ($setting['reply']) {
        $replys = DB::result_first("SELECT count(*) FROM " . DB::table('forum_post') . " WHERE tid='$tid' AND first<>1 AND invisible>=0 AND authorid = " . $_G['uid']);
        if ($replys < 1) {
            $result['full']    = 2;
            $result['message'] = lang('plugin/xj_event', 'huifuhoucaikeyibaoming');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
            echo json_encode($result);
            exit;
        }
    }
    //��֤����ظ��ſ��Ա���
    $replys = DB::result_first("SELECT count(*) FROM " . DB::table('forum_post') . " WHERE tid='$tid' AND first<>1 AND invisible>=0 AND authorid = " . $_G['uid']);
    if ($setting['reply'] && $replys < 1) {
        $result['full']    = 2;
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', lang('plugin/xj_event', 'hfhkybm')) : lang('plugin/xj_event', 'hfhkybm');
        echo json_encode($result);
        exit;
    }
    //��֤�Ƿ��ѱ���
    $count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and uid=$uid");
    if ($count > 0) {
        $result['full']    = 2;
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', lang('plugin/xj_event', 'qinwcfbm')) : lang('plugin/xj_event', 'baomrsym');
        echo json_encode($result);
        exit;
    }
    //��֤���������Ƿ�
    $applynumber   = count($post); //���α�������
    $applynum      = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"); //�ѱ�������
    $applycountnum = DB::result_first("SELECT event_number FROM " . DB::table('xj_event') . " WHERE tid='$tid'"); //�������
    if ($applycountnum > 0) {
        if ($applynumber > ($applycountnum - $applynum)) {
            $result['full']    = 2;
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', lang('plugin/xj_event', 'baomrsym')) : lang('plugin/xj_event', 'baomrsym');
            echo json_encode($result);
            exit;
        }
    }

    //��ȡ���֯�˵�ID
    $event_uid = $items['authorid'];
    //�����
    $event_title = $items['subject'];
    //���ʼʱ��
    $event_starttime = dgmdate($items['starttime'], 'dt');

    //�жϻ��ֹ�����
    $member = DB::fetch_first("SELECT extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8 FROM " . DB::table('common_member_count') . " WHERE uid = " . $_G['uid']);
    /*
    if($member['extcredits'.$items['use_extcredits']]<($items['use_extcredits_num']*$applynumber)){
    $result['full'] = 2;
    $result['message'] = $_G['setting']['extcredits'][$items['use_extcredits']]['title'].lang('plugin/xj_event', 'bgwfcj');
    $result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
    echo json_encode($result);
    exit;
    }
     */

    //�������������ݿ�
    $first = 1;
    if($setting['myuserfield']){
        $myuserfield = $eventcore->GetUserField($setting['myuserfield'],'');  //�±����ֶ�
    }
    foreach ($post as $key => $value) {
        $ufielddata = array();
        foreach ($value as $key2 => $value2) {
            if ($key2 != 'message' && $key2 != 'session') {
                $ufielddata[$key2] = $value2;
            }
        }

        //�µı����ֶεı������������ݿ�  
        foreach ($myuserfield as $val) {
            $ufielddata['myfield' . $val['id']] = $value['myfield' . $val['id']];
        }

        $ufielddata                = serialize($ufielddata);
        $eventapply                = array();
        $eventapply['tid']         = $tid;
        $eventapply['eid']         = $items['eid'];
        $eventapply['uid']         = $uid;
        $eventapply['realname']    = addslashes($value['realname']);
        $eventapply['qq']          = addslashes($value['qq']);
        $eventapply['mobile']      = addslashes($value['mobile']);
        $eventapply['bmmessage']   = addslashes($value['message']);
        $eventapply['dateline']    = $_G['timestamp'];
        $eventapply['applynumber'] = 1;
        $eventapply['ufielddata']  = $ufielddata;
        $eventapply['seccode']     = random(8, 1);
        $eventapply['session']     = intval($value['session']);
        $eventapply['first']       = $first;
        if ($fromuid != $_G['uid']) {
            $eventapply['fromuid'] = $fromuid;
        }

        $applyid = DB::insert('xj_eventapply', $eventapply,true);
        $first = 0; //����������0
    }
    //�û����ص���Ϣ���ݱ��Ƿ���ڣ������ھ��½�
    $num = DB::result_first("SELECT count(*) FROM " . DB::table('xj_event_member_info') . " WHERE uid = '$uid'");
    if ($num == 0) {
        DB::query("INSERT INTO " . DB::table('xj_event_member_info') . " (uid) VALUES ('$uid')");
    }
    //���ֲ���
    /*
    if($items['use_extcredits_num']>0){
    $extnum = $items['use_extcredits_num'] * $applynumber;
    updatemembercount($_G['uid'],array($items['use_extcredits']=>-$extnum));
    }
     */

    if ($setting['noverify'] == 1) {
        //���������
        if ($setting['eventpay']) {
            //�������֧��
            $result['full']    = 1;
            $result['message'] = lang('plugin/xj_event', 'bmzltjcgxzzrzfym');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
            $result['url']     = $zffyurl;
            $result['btntxt']  = lang('plugin/xj_event', 'zhifufy');
            $result['btntxt']  = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['btntxt']) : $result['btntxt'];
            echo json_encode($result);
            exit;
        } else {
            DB::query("update " . DB::table('xj_eventapply') . " set verify=1 where tid='$tid' and uid=$uid"); //�Զ����

            //����Ľ�������
            if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/invitation/event_yqjl.php')) {
                if ($setting['yqjl_jfs'] > 0 && $fromuid != $_G['uid']) {
                    $yqjl             = array();
                    $yqjl['tid']      = $tid;
                    $yqjl['fromuid']  = $fromuid;
                    $yqjl['applyuid'] = $_G['uid'];
                    $yqjl['jfs']      = $setting['yqjl_jfs'] * $applynumber;
                    $yqjl['jflx']     = $setting['yqjl_jflx'];
                    $yqjl['dateline'] = $_G['timestamp'];
                    DB::insert('xj_event_yqjl_log', $yqjl);
                    updatemembercount($yqjl['fromuid'], array($yqjl['jflx'] => +$yqjl['jfs']));
                    notification_add($fromuid, 'system', $_G['username'] . lang('plugin/xj_event', 'beiniyaoqinbaomincanjiale') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $event_title . '</a> ' . lang('plugin/xj_event', 'huodonghuode') . $yqjl['jfs'] . $_G['setting']['extcredits'][$yqjl['jflx']]['title'] . lang('plugin/xj_event', 'jiangli'));
                }
            }

            //���Ų���
            if ($setting['seccode'] == 1) {
                $message = cutstr($event_title, 30) . lang('plugin/xj_event', 'hdbmcgrs') . ':' . $applynumber . lang('plugin/xj_event', 'renyanzhengma') . ':' . $eventapply['seccode'] . ' ' . lang('plugin/xj_event', 'huodongshijian') . ':' . $event_starttime;
                //xjsendsms(array($eventapply['mobile']),$message,lang('plugin/xj_event', 'maomyzmdx'));
                sendsms_vcode($eventapply['mobile'], $event_title, $applynumber, $eventapply['seccode']);
                sendpm($eventapply['uid'], '', $message, $event_uid);
            } elseif ($setting['success_sms'] == 1) {
                sendsms_success($eventapply['mobile'], $event_title, $event_starttime);

                //�׻����
                //$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
                //$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
                //sendsms_notice_yhd($eventapply['mobile'],$event_title,$event_starttime,$items['event_address'],$smsmobile);
            }
            notification_add($event_uid, 'system', $_G['username'] . ' ' . lang('plugin/xj_event', 'bmcjlnd') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $event_title . '</a> ' . lang('plugin/xj_event', 'hdxtyzdsh'), array(), 0);
            //΢����Ϣ
            if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
                require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
                $xj_wxmessagecore = new xj_wxmessagecore();
                $xj_wxmessagecore->send_eventmessage($_G['uid'],$tid,1);
                $xj_wxmessagecore->send_eventapplymessage($applyid,$event_uid,2);
            }
            //�¶�����Ϣ
            if($_G['cache']['plugin']['xj_dxmessage']['enable']){
                require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
                $xj_dxmessagecore = new xj_dxmessagecore();
                $other = array();
                $other['applyid'] = $applyid;
                $other['uid'] = $_G['uid'];
                $xj_dxmessagecore->sendsms($eventapply['mobile'],1,$other);  //�����ɹ�����֪ͨ����
                if($setting['seccode'] == 1){ 
                   $other = array();
                   $other['applyid'] = $applyid;
                   $other['uid'] = $_G['uid'];
                   $other['verifycode'] = $eventapply['seccode'];
                   $xj_dxmessagecore->sendsms($eventapply['mobile'],2,$other);  //�����ɹ�������֤�����
                }
            }



            $result['full']    = 1;
            $result['message'] = lang('plugin/xj_event', 'gxnbmcg');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
            $result['url']     = $_G['siteurl'] . "forum.php?mod=viewthread&tid=$tid";
            echo json_encode($result);
            exit;
        }
    } else {
        //�������ʱ
        if ($setting['eventpay']) {
            //�������֧��
            $result['full']    = 1;
            $result['message'] = lang('plugin/xj_event', 'bmzltjcgxzzrzfym');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
            $result['url']     = $zffyurl;
            $result['btntxt']  = lang('plugin/xj_event', 'zhifufy');
            $result['btntxt']  = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['btntxt']) : $result['btntxt'];
            echo json_encode($result);
            exit;
        }
        //��֪ͨ
        notification_add($event_uid, 'system', 'activity_notice', array('tid' => $tid, 'subject' => $event_title));
        //΢����Ϣ
        if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
            $event_admins = array();
            $event_admins[] = $event_uid;
            foreach ($setting['event_admin'] as $v) {
                $event_admins[] = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='$v'");
            }
            require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
            $xj_wxmessagecore = new xj_wxmessagecore();
            $xj_wxmessagecore->send_eventapplyshmessage($applyid,$event_admins,3);
        }
        //�¶�����Ϣ
        if($_G['cache']['plugin']['xj_dxmessage']['enable']){
            $event_admins = array();
            $event_admins[] = $event_uid;
            foreach ($setting['event_admin'] as $v) {
                $event_admins[] = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='$v'");
            }
            require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
            $xj_dxmessagecore = new xj_dxmessagecore();
            foreach ($event_admins as $v) {
                $mobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$v");
                $other = array();
                $other['applyid'] = $applyid;
                $other['uid'] = $v;
                $xj_dxmessagecore->sendsms($mobile,3,$other);  //��������֪ͨ���Ÿ�����Ա����� 
            }      
        }



        $result['full']    = 1;
        $result['message'] = lang('plugin/xj_event', 'bmxxtjcgqddsh');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        $result['url']     = $_G['siteurl'] . "forum.php?mod=viewthread&tid=$tid";
        echo json_encode($result);
        exit;
    }

}

//ȡ������
if ($_GET['action'] == 'cannel') {
    if ($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " A," . DB::table('forum_thread') . " B WHERE A.tid=B.tid AND A.tid = '$tid'");
    if ($items['activityexpiration'] > $timestamp) {
        $count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid = '$tid' and uid = " . $_G['uid']);
        if ($count < 1) {
            exit('Access Denied');
        }
        $applynumber = $count;
        DB::query("DELETE FROM " . DB::table('xj_eventapply') . " WHERE tid = '$tid' and uid = " . $_G['uid']);
        //��ԭ���ֲ���
        /*
        if($items['use_extcredits_num']>0){
        $extnum = $items['use_extcredits_num']*$applynumber;
        updatemembercount($_G['uid'],array($items['use_extcredits']=>$extnum));
        }
         */
        //֪ͨ
        notification_add($items['authorid'], 'system', 'activity_cancel', array(
            'tid'     => $tid,
            'subject' => $items['subject'],
            'reason'  => $message,
        ));

        if ($_GET['inajax']) {
            $result            = array();
            $result['full']    = 1;
            $result['return']  = $return;
            $result['message'] = lang('plugin/xj_event', 'huodongquxiaochenggong');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
            $result['url']     = $_G['siteurl'] . 'plugin.php?id=xj_event:wsqcenter&mod=my_join';
            echo json_encode($result);
            exit();
        } else {
            dheader('location: ' . $retrunurl);
        }
    } else {
        exit('Access Denied');
    }
}
if ($_GET['action'] == 'checkseccode') {
    if ($_GET['formhash'] != $_G['formhash']) {
        showmessage('submit_invalid');
    }
    $eid = intval($_GET['eid']);
    if (!$_GET['seccode']) {
        showmessage(lang('plugin/xj_event', 'yzmwxhzyjsy'));
    }
    $seccode = dhtmlspecialchars(trim($_GET['seccode']));
    $apply   = DB::fetch_first("SELECT applyid,uid FROM " . DB::table('xj_eventapply') . " WHERE eid='$eid' AND secstate=0 AND seccode='$seccode'");
    $applyid = $apply['applyid'];
    if ($applyid) {
        DB::update('xj_eventapply', array('secstate' => 1, 'sectime' => $_G['timestamp']), "applyid=$applyid");
        notification_add($apply['uid'], 'system', lang('plugin/xj_event', 'ndhdbmyzm') . " $seccode " . lang('plugin/xj_event', 'yishiyong'), array(), 1);
        showmessage(lang('plugin/xj_event', 'yzmyxyzcg'), "forum.php?mod=viewthread&tid=$tid");
    } else {
        showmessage(lang('plugin/xj_event', 'yzmwxhzyjsy'));
    }
}

//��֤�Ƿ��ѱ���
$count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and uid=$uid");
if ($count > 0) {
    dheader('location: ' . $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $tid);
}

//��ȡ�û������ֶ�
if ($_G['mobile']) {
    $userfield       = unserialize($items['userfield']);
    $selectuserfield = unserialize($items['userfield']);
    if ($selectuserfield) {
        if ($selectuserfield) {
            $htmls = $settings = array();
            require_once libfile('function/profile');
            foreach ($selectuserfield as $fieldid) {
                if (empty($ufielddata['userfield'])) {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    foreach ($selectuserfield as $val) {
                        if ($val == 'birthday') {
                            $ufielddata['userfield']['birthyear']  = $memberprofile['birthyear'];
                            $ufielddata['userfield']['birthmonth'] = $memberprofile['birthmonth'];
                        }
                        $ufielddata['userfield'][$val] = $memberprofile[$val];
                    }
                    unset($memberprofile);
                }
                $html = profile_setting($fieldid, $ufielddata['userfield'], false, true);

                if ($fieldid == 'birthday') {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    $mybirthday    = $memberprofile['birthyear'] . '-' . $memberprofile['birthmonth'] . '-' . $memberprofile['birthday'];
                    $mybirthday    = strtotime($mybirthday);
                    $mybirthday    = date("Y-m-d", $mybirthday);
                    $html          = '<input name="birthday" type="date" id="birthday" value="' . $mybirthday . '" class="join_text" />';
                }
                if ($fieldid == 'residecity') {
                    $html = '<div><input type="hidden" name="residecity" value=""><span></span> <button class="residecity ui-btn">' . lang('plugin/xj_event', 'select') . '</button><span></span></div>';
                }
                if ($html) {
                    if (strpos($html, 'checkbox') > 0) {
                        $html = '<fieldset data-role="controlgroup">' . $html . '</fieldset>';
                        $html = str_replace(' class="lb"', '', $html);
                        //echo $html;
                        //exit();
                    }
                    //�����б�
                    if (strpos($html, 'select name=') > 0 && strpos($html, 'name="birthprovince"') < 1) {
                        if (strpos($html, 'name="gender"') > 0) {
                            preg_match('/name\=\"(.+?)\"/i', $html, $selectname);
                            preg_match_all('/value\=\"(.+?)\"/i', $html, $optionvalue);
                            preg_match_all('/\"\>(.+?)\<\/op/i', $html, $optiontext);
                            $html = '<div class="xjselect"><input type="hidden" name="' . $selectname[1] . '" id="' . $selectname[1] . '" value="">';
                            foreach ($optionvalue[1] as $opkey => $opvalue) {
                                $html .= '<span style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;font-weight:normal; text-shadow:none;" data-value="' . $opvalue . '">' . $optiontext[1][$opkey] . '</span>';
                            }
                            $html .= '</div><div style="clear:both;"></div>';
                        } else {
                            preg_match('/name\=\"(.+?)\"/i', $html, $selectname);
                            preg_match_all('/value\=\"(.+?)\"/i', $html, $optionvalue);
                            $html = '<div class="xjselect"><input type="hidden" name="' . $selectname[1] . '" id="' . $selectname[1] . '" value="">';
                            foreach ($optionvalue[1] as $opvalue) {
                                $html .= '<span style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;font-weight:normal; text-shadow:none;" data-value="' . $opvalue . '">' . $opvalue . '</span>';
                            }
                            $html .= '</div><div style="clear:both;"></div>';
                        }
                    }

                    $html = preg_replace("/<div class=\"rq mtn\" id=\"showerror.+<\/div>/is", "", $html);
                    if (strpos($html, 'type="text"') > 0) {
                        $html = str_replace('class="px"', 'class="join_text"', $html);
                    }
                    $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                    $htmls[$fieldid]    = $html;
                }
            }
        }
    } else {
        $selectuserfield = '';
    }
} else {
    $userfield       = unserialize($items['userfield']);
    $selectuserfield = unserialize($items['userfield']);
    if ($selectuserfield) {
        if ($selectuserfield) {
            $htmls = $settings = array();
            require_once libfile('function/profile');
            foreach ($selectuserfield as $fieldid) {
                if (empty($ufielddata['userfield'])) {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    foreach ($selectuserfield as $val) {
                        if ($val == 'birthday') {
                            $ufielddata['userfield']['birthyear']  = $memberprofile['birthyear'];
                            $ufielddata['userfield']['birthmonth'] = $memberprofile['birthmonth'];
                        }
                        $ufielddata['userfield'][$val] = $memberprofile[$val];
                    }
                    unset($memberprofile);
                }
                $html = profile_setting($fieldid, $ufielddata['userfield'], false, true);

                if ($fieldid == 'birthday') {
                    $memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
                    $mybirthday    = $memberprofile['birthyear'] . '-' . $memberprofile['birthmonth'] . '-' . $memberprofile['birthday'];
                    $html          = '<div style="height:36px;"><input name="birthday" type="text" value="' . $mybirthday . '" class="dateselect" /><div></div></div>';
                }
                if ($fieldid == 'residecity') {
                    $html = '<div style="height:36px;"><input type="hidden" name="residecity" value=""><span></span> <button class="residecity">' . lang('plugin/xj_event', 'select') . '</button><span></span></div>';
                }
                if ($html) {
                    $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                    $htmls[$fieldid]    = $html;
                }
            }
        }
    } else {
        $selectuserfield = '';
    }
}

//�µı����ֶ�
if($setting['myuserfield']){
$myuserfield = $eventcore->GetUserField($setting['myuserfield'],'');
}

include template('xj_event:event_join');
