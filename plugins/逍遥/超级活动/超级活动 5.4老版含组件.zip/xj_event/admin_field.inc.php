<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if (empty($_GET['act'])) {
    $_GET['act'] = 'add';
}
if ($_GET['act'] == 'add_full') {
    if (empty($_GET['title'])) {
        cpmsg(lang('plugin/xj_event', 'qingtianxiebiaodanxiangbiaoti'), '', 'error');
        exit;
    }
    $item                = array();
    $item['title']       = addslashes($_GET['title']);
    $item['description'] = addslashes($_GET['description']);
    $item['formtype']    = addslashes($_GET['formtype']);
    $item['size']        = intval($_GET['size']);
    $item['choices']     = addslashes($_GET['choices']);
    if ($_GET['id']) {
        $id = intval($_GET['id']);
        DB::update('xj_event_field', $item, "id=$id");
        cpmsg(lang('plugin/xj_event', 'xiugaichenggong'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=manage&page=' . $_GET['page'], 'succeed');
    } else {
        DB::insert('xj_event_field', $item);
        cpmsg(lang('plugin/xj_event', 'tianjiachenggong'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=add', 'succeed');
    }
    exit;
}
if ($_GET['act'] == 'delete') {
    $id = intval($_GET['id']);
    DB::delete('xj_event_field', "id=$id");
    cpmsg(lang('plugin/xj_event', 'shanchuchenggong'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=manage&page=' . $_GET['page'], 'succeed');
    exit;
}
//�����˵�
shownav('plugin', lang('plugin/xj_event', 'chaojhd'), lang('plugin/xj_event', 'baomingbiaodanxiangshezhi'));
showsubmenu(lang('plugin/xj_event', 'baomingbiaodanxiangshezhi'), array(
    array(lang('plugin/xj_event', 'tianjia'), 'plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=add', $_GET['act'] == 'add' ? 1 : 0),
    array(lang('plugin/xj_event', 'guanli'), 'plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=manage', $_GET['act'] == 'manage' ? 1 : 0),
    array(lang('plugin/xj_event', 'fanhui'), 'plugins&operation=config&do=' . $pluginid, 0),
));
//���ɿ�����
if ($_GET['act'] == 'add') {
    $formUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&act=add_full';
    showformheader($formUrl, 'enctype="multipart/form-data" onsubmit="return validate();"', 'createform');
    showtableheader(lang('plugin/xj_event', 'tianjiabiaodanxiang'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangbiaoti'), 'title', '', 'text', '', '', lang('plugin/xj_event', 'tianxiebiaodanxiangdezhongwenmingchengruxingming'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangmiaoshu'), 'description', '', 'text', '', '', lang('plugin/xj_event', 'tianxiebiaodanxiangdejiandanmiaoshujieshao'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangleixing'), array('formtype', array(
        array('text', lang('plugin/xj_event', 'danxingwenbenkuang'), array('valuenumber' => '', 'fieldchoices' => 'none')),
        array('textarea', lang('plugin/xj_event', 'duoxingwenbenkuang'), array('valuenumber' => '', 'fieldchoices' => 'none')),
        array('select', lang('plugin/xj_event', 'xiaweiliebiaokuang'), array('valuenumber' => 'none', 'fieldchoices' => '')),
        //array('uploadfile', '�ϴ�ͼƬ', array('valuenumber' => '', 'fieldchoices' => 'none')),
    )), 'text', 'mradio', '', '', lang('plugin/xj_event', 'xuanzebiaodanxiangdeleixing'));
    showtagheader('tbody', 'valuenumber', true, 'sub');
    showsetting(lang('plugin/xj_event', 'daxiaoxianding'), 'size', '0', 'text', '', '', lang('plugin/xj_event','zdktxdzfshzdkxztplxxzlsctpdx'), '', '', '');
    showtagfooter('tbody');
    showtagheader('tbody', 'fieldchoices', false, 'sub'); //����������������
    showsetting(lang('plugin/xj_event', 'kexuanzhi'), 'choices', '', 'textarea', '', '', lang('plugin/xj_event','mhygzlrsrbjsh'), '', '', '');
    showtagfooter('tbody');
    showsubmit('open_submit', 'submit');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
} elseif ($_GET['act'] == 'edit') {
    $id      = intval($_GET['id']);
    $item    = DB::fetch_first("SELECT * FROM " . DB::table('xj_event_field') . " WHERE id=$id");
    $formUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&id=' . $id . '&act=add_full';
    showformheader($formUrl, 'enctype="multipart/form-data" onsubmit="return validate();"', 'createform');
    showtableheader(lang('plugin/xj_event', 'tianjiabiaodanxiang'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangbiaoti'), 'title', $item['title'], 'text', '', '', lang('plugin/xj_event', 'tianxiebiaodanxiangdezhongwenmingchengruxingming'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangmiaoshu'), 'description', $item['description'], 'text', '', '', lang('plugin/xj_event', 'tianxiebiaodanxiangdejiandanmiaoshujieshao'));
    showsetting(lang('plugin/xj_event', 'biaodanxiangleixing'), array('formtype', array(
        array('text', lang('plugin/xj_event', 'danxingwenbenkuang'), array('valuenumber' => '', 'fieldchoices' => 'none')),
        array('textarea', lang('plugin/xj_event', 'duoxingwenbenkuang'), array('valuenumber' => '', 'fieldchoices' => 'none')),
        array('select', lang('plugin/xj_event', 'xiaweiliebiaokuang'), array('valuenumber' => 'none', 'fieldchoices' => '')),
    )), $item['formtype'], 'mradio', '', '', lang('plugin/xj_event', 'xuanzebiaodanxiangdeleixing'));
    if (in_array($item['formtype'], array('text', 'textarea', 'checkbox'))) {
        $valuenumberdisplay = true;
    } else {
        $valuenumberdisplay = false;
    }
    if (in_array($item['formtype'], array('radio', 'checkbox', 'select'))) {
        $fieldchoicesdisplay = true;
    } else {
        $fieldchoicesdisplay = false;
    }
    showtagheader('tbody', 'valuenumber', $valuenumberdisplay, 'sub');
    showsetting(lang('plugin/xj_event', 'daxiaoxianding'), 'size', $item['size'], 'text', '', '', lang('plugin/xj_event','zdktxdzfshzdkxztplxxzlsctpdx'), '', '', '');
    showtagfooter('tbody');
    showtagheader('tbody', 'fieldchoices', $fieldchoicesdisplay, 'sub'); //����������������
    showsetting(lang('plugin/xj_event', 'kexuanzhi'), 'choices', $item['choices'], 'textarea', '', '', lang('plugin/xj_event','mhygzlrsrbjsh'), '', '', '');
    showtagfooter('tbody');
    showsubmit('open_submit', 'submit');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
} elseif ($_GET['act'] == 'manage') {
    //δ��ͨ���Ź���
    $ppp   = 20; //ÿҳ����
    $page  = $_GET['page'] ? intval($_GET['page']) : 1;
    $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('xj_event_field'));
    $query = DB::query("SELECT * FROM " . DB::table('xj_event_field') . " LIMIT " . (($page - 1) * $ppp) . ",$ppp");
    showtableheader(lang('plugin/xj_event', 'ziduanguanli'));
    showtablerow('', array(), array('ID', lang('plugin/xj_event', 'ziduanbiaoti'), lang('plugin/xj_event', 'ziduanmiaoshu'), lang('plugin/xj_event', 'ziduanleixing'), ''), '');
    while ($value = DB::fetch($query)) {
        showtablerow('', array('class="td25"', 'class="td28"'), array($value['id'], $value['title'], $value['description'], $value['formtype'], '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&page=' . $page . '&act=delete&id=' . $value['id'] . '&formhash=' . $_G['formhash'] . '">['.lang('plugin/xj_event', 'shanchu').']</a> <a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=xj_event&pmod=admin_field&page=' . $page . '&act=edit&id=' . $value['id'] . '&formhash=' . $_G['formhash'] . '">['.lang('plugin/xj_event','xiugai').']</a> '));
    }
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
    echo multi($count, $ppp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_field&act=manage$extra");
}
