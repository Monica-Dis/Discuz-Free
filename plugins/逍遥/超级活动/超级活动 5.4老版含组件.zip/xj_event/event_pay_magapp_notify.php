﻿<?php

include '../../class/class_core.php';
$driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
DB::init($driver,$_G['config']['db']);
include 'include/sms_func.php';
$unionOrderNum = $_GET['unionOrderNum'];
$tradeno = $_GET['tradeNo'];


//调试记录开始
//$log_name="./magapppay.txt";//log文件路径
//log_result($log_name,"【接收到的notify通知】:\r\n".$unionOrderNum."\r\n【返回的信息】:".$tradeno."\r\n");
//调试记录结束


$paylog = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventpay_log')." WHERE tradeno='".$tradeno."'");
if($paylog['paystate'] != 3){	
	$data = array();
	$data['paystate'] = 3;
	$data['orderid'] = $post['transaction_id'];
	$data['pay_time'] = $_G['timestamp'];
	$data['notify_time'] = $_G['timestamp'];
	DB::update("xj_eventpay_log",$data,"tradeno='".$tradeno."'");
	$paylog = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE tradeno='".$tradeno."'");
	$tid = $paylog['tid'];
	$uid = $paylog['uid'];
	$data = array();
	$data['pay_state'] = 1;
	$data['verify'] = 1;
	DB::update("xj_eventapply",$data,"tid=$tid AND uid=$uid");
	paysmssend($tid,$uid);
    //微信消息
    $event_uid = DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=$tid");
    loadcache('plugin');
    if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
        require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
        $xj_wxmessagecore = new xj_wxmessagecore();
        $xj_wxmessagecore->send_eventmessage($uid,$tid,1);
        $xj_wxmessagecore->send_eventapplymessage($paylog['applyid'],$event_uid,2);
    }
    //新短信消息
    if($_G['cache']['plugin']['xj_dxmessage']['enable']){
    	$eventapply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = ".$paylog['applyid']);
        require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
        $xj_dxmessagecore = new xj_dxmessagecore();
        $other = array();
        $other['applyid'] = $eventapply['applyid'];
        $other['uid'] = $eventapply['uid'];
        $xj_dxmessagecore->sendsms($eventapply['mobile'],1,$other);  //报名成功发送通知短信
        if($setting['seccode'] == 1){ 
           $other = array();
           $other['applyid'] = $eventapply['applyid'];
           $other['uid'] = $event_uid;
           $other['verifycode'] = $eventapply['seccode'];
           $xj_dxmessagecore->sendsms($eventapply['mobile'],2,$other);  //报名成功发送验证码短信
        }
    }
    
}
$return = array();
$return['return_code'] = 'SUCCESS';  //SUCCESS/FAIL   SUCCESS表示商户接收通知成功并校验成功
$return['return_msg'] = 'ok';  //返回信息，如非空，为错误原因
echo json_encode($return);










/*

$url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
$url = str_replace('source/plugin/xj_event/event_pay_wx_notify.php','plugin.php?id=xj_event:wsq_pay_notify',$url); 
$return = postxml($url,$xml);

*/




function paysmssend($tid,$uid){
	global $_G;
	//调试记录开始
	//$log_name="./alipay.txt";//log文件路径
	//log_result($log_name,"【接收到的notify通知】:\r\n".$xml."\r\n【返回的信息】:\r\n");
	//调试记录结束
	
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=$uid");
	$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid=$tid and A.tid = B.tid");
	$setting = unserialize($thread['setting']);
	$event_starttime = dgmdate($thread['starttime'],'dt');
	if($setting['seccode'] == 1){		
		$message = cutstr($thread['subject'],30).'活动报名成功，人数:'.$apply['applynumber'].'人 验证码:'.$apply['seccode'].' 活动时间:'.$event_starttime;
		$sendtype = '报名验证码短信';
		if($_G[charset]=='gbk'){
			$message = diconv($message,'UTF-8','GBK');
			$sendtype = diconv($sendtype,'UTF-8','GBK');
		}
		sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
		//xjsendsms(array($apply['mobile']),$message,$sendtype);
		sendpm($apply['uid'],'',$message,$thread['authorid']);
	}elseif($setting['success_sms'] == 1){
		sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
		//易活动短信
		//$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
		//$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
		//sendsms_notice_yhd($apply['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);
		
	}
}




function postxml($url,$data){
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}

/**
 * 	作用：array转xml
 */
function arrayToXml($arr)
{
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">"; 

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
	}
	$xml.="</xml>";
	return $xml; 
}

/**
 * 	作用：将xml转为array
 */
function xmlToArray($xml)
{		
	//将XML转为array        
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
	return $array_data;
}

// 打印log
function  log_result($file,$word) 
{
	$fp = fopen($file,"a");
	flock($fp, LOCK_EX) ;
	fwrite($fp,"执行日期：".strftime("%Y-%m-%d-%H：%M：%S",time())."\n".$word."\n\n");
	flock($fp, LOCK_UN);
	fclose($fp);
}
/**
* 	作用：格式化参数，签名过程需要使用
*/
function formatBizQueryParaMap($paraMap, $urlencode)
{
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		//$buff .= strtolower($k) . "=" . $v . "&";
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0) 
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
//生成签名
function getSign($Obj){
	global $apikey;
	foreach ($Obj as $k => $v)
	{
		$Parameters[$k] = $v;
	}
	//签名步骤一：按字典序排序参数
	ksort($Parameters);
	$String = formatBizQueryParaMap($Parameters, false);
	//echo '【string1】'.$String.'</br>';
	//签名步骤二：在string后加入KEY
	$String = $String."&key=$apikey";
	//echo "【string2】".$String."</br>";
	//签名步骤三：MD5加密
	$String = md5($String);
	//echo "【string3】 ".$String."</br>";
	//签名步骤四：所有字符转为大写
	$result_ = strtoupper($String);
	//echo "【result】 ".$result_."</br>";
	return $result_;
}
//验证签名是否正确
function checkSign($xmlarray){
	$tmpData = $xmlarray;
	unset($tmpData['sign']);
	$sign = getSign($tmpData);//本地签名
	//调试记录开始
	//$log_name="./wxpay.txt";//log文件路径
	//log_result($log_name,"【本地签名】:\r\n".$sign."\r\n");
	//调试记录结
	if ($xmlarray['sign'] == $sign) {
		return TRUE;
	}
	return FALSE;
}


function postXmlCurl($xml,$url,$second=30)
{		
	//初始化curl        
	$ch = curl_init();
	//设置超时
	curl_setopt($ch, CURLOP_TIMEOUT, $second);
	//这里设置代理，如果有的话
	//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
	//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	//设置header
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	//要求结果为字符串且输出到屏幕上
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//post提交方式
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	//运行curl
	$data = curl_exec($ch);
	curl_close($ch);
	//返回结果
	if($data)
	{
		curl_close($ch);
		return $data;
	}
	else 
	{ 
		$error = curl_errno($ch);
		echo "curl error:$error"."<br>"; 
		echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>error view</a></br>";
		curl_close($ch);
		return false;
	}
}
//From: dis'.'m.tao'.'bao.com
?>