<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}






if($_GET['act'] == 'save' && submitcheck('open_submit')){
	$iconlist = array();
	foreach($_GET['icontext'] as $key=>$value){
		if($value){
			$tmp = array();
			$tmp['icontext'] = $value;
			$tmp['iconpic'] = $_GET['iconpic'][$key];
			$tmp['url'] = $_GET['url'][$key];
			$tmp['pc'] = $_GET['pc'][$key];
			$tmp['classid'] = $_GET['classid'][$key];
			$iconlist[] = $tmp;
		}
	}
	savecache('xj_event_mobileicon',$iconlist);
	cpmsg(lang('plugin/xj_event', 'baoccg'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_mobileicon', 'succeed');
}







	echo '
	<script src="static/js/calendar.js" type="text/javascript"></script>
	<script type="text/javascript" src="static/image/editor/editor_function.js"></script>
	<script type="text/JavaScript">
	function validate(obj) {
		if(itemsform.itemsname.value == ""){
			alert("'.lang('plugin/xj_mall', 'qingtianxieshangpinmingcheng').'");
			return false;
		}else if(document.getElementById("itemsmodel").value == ""){
			alert("'.lang('plugin/xj_mall', 'qingtianxieshangpinjiage').'");
			return false;
		}else{
			return true;
		}
	}
	</script>';
	$lang_shanchu = lang('plugin/xj_mall', 'shanchu');
	echo '<script type="text/JavaScript">
		var rowtypedata = [
			[
				[1,\'<input type="text" name="icontext[]" value="" />\',\'td25\'],
				[1,\'<input type="text" name="iconpic[]" value="" />\',\'td25\'],
				[1,\'<input type="text" name="url[]" value="" />\',\'td25\'],
				[1,\'<select name="pc[]"><option value="1">'.lang('plugin/xj_event', 'xxhd').'</option><option value="2">'.lang('plugin/xj_event', 'xshd').'</option></select>\',\'td25\'],
				[1,\'<input type="text" name="classid[]" value="" />\',\'td25\'],
				[1,\'<span><a href="javascript:;" class="deleterow" onClick="deleterow(this)">{$lang_shanchu}</a><span>\',\'td28\'],
			]
		];
	</script>';

loadcache('xj_event_mobileicon');



$formUrl = 'plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_mobileicon&act=save';
showformheader($formUrl,'enctype="multipart/form-data"','itemsform');
showtableheader(lang('plugin/xj_event', 'shoudonghuodongzhongxindaohangtubiaoshezhi'));
showtablerow('',array('class="td25"','class="td25"','class="td25"','class="td25"','class="td25"','class="td28"'),array(lang('plugin/xj_event', 'tubiaowenzi'),lang('plugin/xj_event', 'tubiaotupian'),lang('plugin/xj_event', 'lianjie'),lang('plugin/xj_event', 'xianshangxianxia'),lang('plugin/xj_event','huodongfenlei').'ID',''),'');
foreach($_G['cache']['xj_event_mobileicon'] as $value){
	showtablerow('',array('class="td25"','class="td25"','class="td25"','class="td25"','class="td25"','class="td28"'),array('<input type="text" name="icontext[]" value="'.$value['icontext'].'" />','<input type="text" name="iconpic[]" size="60" value="'.$value['iconpic'].'" />','<input type="text" name="url[]" size="60" value="'.$value['url'].'" />','<select name="pc[]"><option value="1" '.($value['pc']==1?'selected':'').'>'.lang('plugin/xj_event', 'xxhd').'</option><option value="2" '.($value['pc']==2?'selected':'').'>'.lang('plugin/xj_event', 'xshd').'</option></select>','<input type="text" name="classid[]" value="'.$value['classid'].'" />',' <span><a href="javascript:;" class="deleterow" onClick="deleterow(this)">'.lang('plugin/xj_event', 'shanchu').'</a><span>'),'');
}
        echo '<tr><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/xj_event', 'zengjia').'</a></div></td></tr>';
showsubmit('open_submit', 'submit');
showformfooter(); /*dism��taobao��com*/



?>