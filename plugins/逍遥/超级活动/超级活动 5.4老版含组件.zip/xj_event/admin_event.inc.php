<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if($_GET['act'] == 'shenhe'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	$tid = intval($_GET['tid']);
	DB::update('forum_thread',array('displayorder'=>0),"tid=$tid");
	DB::update('forum_post',array('invisible'=>0),"tid=$tid");
	cpmsg(lang('plugin/xj_event', 'shenhechenggong'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.intval($_GET['page']), 'succeed');
}

if($_GET['act'] == 'qxshenhe'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	$tid = intval($_GET['tid']);
	DB::update('forum_thread',array('displayorder'=>-2),"tid=$tid");
	DB::update('forum_post',array('invisible'=>-2),"tid=$tid");
	cpmsg(lang('plugin/xj_event', 'shenhechenggong'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.intval($_GET['page']), 'succeed');
}




if($_GET['act'] == 'event_yqjl'){
	  if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/invitation/admin_event_yqjl.php')) {
		  @include DISCUZ_ROOT.'./source/plugin/xj_event/module/invitation/admin_event_yqjl.php';
	  }
}elseif($_GET['act'] == 'event_xlbm'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/virtual/event_xlbm.php')) {
		@include DISCUZ_ROOT.'./source/plugin/xj_event/module/virtual/event_xlbm.php';
	}else{
		cpmsg(lang('plugin/xj_event','qinganzhuangzujian'),'http://dism.taobao.com/?@xj_event.plugin.70608','error');
		exit;
	}
}elseif($_GET['act'] == 'event_xlbm_full'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/virtual/event_xlbm_full.php')) {
		@include DISCUZ_ROOT.'./source/plugin/xj_event/module/virtual/event_xlbm_full.php';
	}
}elseif($_GET['act'] == 'event_qfwx'){
	loadcache('plugin');
	if($_G['cache']['plugin']['xj_wxmessage']){
		header('Location: '.$_G['siteurl'].'admin.php?action=plugins&operation=config&do=100&identifier=xj_wxmessage&pmod=admin_groupsend');
		exit;
	}else{
		cpmsg(lang('plugin/xj_event','qinganzhuangchajian'),'http://dism.taobao.com/?@xj_wxmessage.plugin','error');
		exit;
	}
}elseif($_GET['act'] == 'event_qfdx'){
	loadcache('plugin');
	if($_G['cache']['plugin']['xj_wxmessage']){
		header('Location: '.$_G['siteurl'].'admin.php?action=plugins&operation=config&identifier=xj_dxmessage&pmod=admin_groupsend');
		exit;
	}else{
		cpmsg(lang('plugin/xj_event','qinganzhuangchajian'),'http://dism.taobao.com/?@xj_wxmessage.plugin','error');
		exit;
	}

}else{


	  
	  
	  if($_GET['act'] == 'search'){
		  $keyword = addslashes($_GET['keyword']);
		  $sqlstr = " WHERE B.subject like '%".str_replace(array('%', '*', '_'), array('\%', '%', '\_'), $keyword)."%'";
	  }
	  
	  
	  showsubmenu(lang('plugin/xj_event', 'huodonggl'));
	  echo '<div><form name="form1" method="post" action="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_event&act=search">'.lang('plugin/xj_event', 'guanjianzi').'<input type="text" name="keyword" value=""> <input type="submit" name="button" id="button" value="'.lang('plugin/xj_event', 'chazhao').'" /></form></div>';
	  showtableheader(lang('plugin/xj_event', 'huodonggl'));
	  showtablerow('',array(),array('ID',lang('plugin/xj_event', 'huodongmingcheng'),lang('plugin/xj_event', 'baomingrs'),lang('plugin/xj_event', 'huodongshijian'),lang('plugin/xj_event', 'fabuhd'),''),'');
	  $ppp = 15;   //ÿ������
	  $page = $_GET['page']?intval($_GET['page']):1;
	  $count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid ".$sqlstr);
	  $query = DB::query("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid $sqlstr ORDER BY eid DESC LIMIT ".(($page - 1) * $ppp).",$ppp");
	  while($value = DB::fetch($query)) {
		  $value['setting'] = unserialize($value['setting']);
		  $value['number'] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_eventapply')." WHERE tid=".intval($value['tid']));
		  $value['starttime'] = $value['starttime']?dgmdate($value['starttime']):'';
		  if($value['displayorder'] == -2){
			  $shenhehtml = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=shenhe&tid='.$value['tid'].'&formhash='.$_G['formhash'].'" style="color:#f00;">'.lang('plugin/xj_event', 'shenhe').'</a>';
		  }elseif($value['displayorder']>=0){
			  $shenhehtml = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=qxshenhe&tid='.$value['tid'].'&formhash='.$_G['formhash'].'">'.lang('plugin/xj_event', 'quxiaoshenhe').'</a>';
		  }
		  
		  if($value['setting']['yqjl_jfs']>0){
			  $shenhehtml .= ' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=event_yqjl&tid='.$value['tid'].'&formhash='.$_G['formhash'].'">['.lang('plugin/xj_event','yaoqingguanli').']</a>';
		  }
		  
		  $qunfawxhtml = ' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=event_qfwx&tid='.$value['tid'].'&formhash='.$_G['formhash'].'">['.lang('plugin/xj_event','qunfaweixinxiaoxi').']</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=event_qfdx&tid='.$value['tid'].'&formhash='.$_G['formhash'].'">['.lang('plugin/xj_event','qunfaduanxin').']</a>';
		  
		  showtablerow('', array('class="td25"', 'class="td28"'), array($value['eid'],$value['subject'],$value['number'],$value['starttime'],dgmdate($value['dateline']),$shenhehtml.' <a href="forum.php?mod=viewthread&tid='.$value['tid'].($value['displayorder']==-2?'&modthreadkey='.modauthkey($value['tid']):'').'" target="_blank">['.lang('plugin/xj_event', 'view').']</a> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_event&page='.$page.'&act=event_xlbm&tid='.$value['tid'].'&formhash='.$_G['formhash'].'">['.lang('plugin/xj_event','xulibaoming').']</a> '.$qunfawxhtml));
	  }
	  
	  showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	  
	  echo multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_event$extra");

}
//From: Dism��taobao��com
?>