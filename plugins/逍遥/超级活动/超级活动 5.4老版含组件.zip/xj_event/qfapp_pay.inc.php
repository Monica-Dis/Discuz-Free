<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();





if($_GET['action'] == 'full'){
	include 'include/sms_func.php';
	$tradeno = $_GET['tradeno'];
	$paylog = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventpay_log')." WHERE tradeno='".$tradeno."'");
	if($paylog['paystate'] != 3){	
		$data = array();
		$data['paystate'] = 3;
		$data['orderid'] = $_GET['orderid'];
		$data['pay_time'] = $_G['timestamp'];
		$data['notify_time'] = $_G['timestamp'];
		DB::update("xj_eventpay_log",$data,"tradeno='".$tradeno."'");
		$paylog = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE tradeno='".$tradeno."'");
		$tid = $paylog['tid'];
		$uid = $paylog['uid'];
		$data = array();
		$data['pay_state'] = 1;
		$data['verify'] = 1;
		DB::update("xj_eventapply",$data,"tid=$tid AND uid=$uid");
		paysmssend($tid,$uid);
	    //΢����Ϣ
	    $event_uid = DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=$tid");
	    loadcache('plugin');
	    if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
	        require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
	        $xj_wxmessagecore = new xj_wxmessagecore();
	        $xj_wxmessagecore->send_eventmessage($uid,$tid,1);
	        $xj_wxmessagecore->send_eventapplymessage($paylog['applyid'],$event_uid,2);
	    }
        //�¶�����Ϣ
        if($_G['cache']['plugin']['xj_dxmessage']['enable']){
        	$eventapply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = ".$paylog['applyid']);
            require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
            $xj_dxmessagecore = new xj_dxmessagecore();
            $other = array();
            $other['applyid'] = $eventapply['applyid'];
            $other['uid'] = $eventapply['uid'];
            $xj_dxmessagecore->sendsms($eventapply['mobile'],1,$other);  //�����ɹ�����֪ͨ����
            if($setting['seccode'] == 1){ 
               $other = array();
               $other['applyid'] = $eventapply['applyid'];
               $other['uid'] = $event_uid;
               $other['verifycode'] = $eventapply['seccode'];
               $xj_dxmessagecore->sendsms($eventapply['mobile'],2,$other);  //�����ɹ�������֤�����
            }
        }



	}
	$return = array();
	$return['return_code'] = 'SUCCESS';  //SUCCESS/FAIL   SUCCESS��ʾ�̻�����֪ͨ�ɹ���У��ɹ�
	$return['return_msg'] = 'ok';  //������Ϣ����ǿգ�Ϊ����ԭ��
	echo json_encode($return);	
	exit;
}











$applyid = intval($_GET['applyid']);
$apply = DB::fetch_first("SELECT tid,applyid,applynumber FROM ".DB::table('xj_eventapply')." WHERE applyid = $applyid and uid=".$_G['uid']);
$tid = $apply['tid'];
$items = DB::fetch_first("SELECT A.*,B.subject FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid = $tid and A.tid=B.tid");
$setting = unserialize($items['setting']);
$pay_subject = $items['subject'];
$pay_price = $items['use_cost'];
$pay_number = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
//�жϱ��������Ƿ񹻣������Ͳ���֧��
if($items['event_number']>0){
	$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1");
	if($pay_number > ($items['event_number']-$applycountnumber)){
		showmessage(lang('plugin/xj_event','baomrsym'));
		exit();
	}
}
$pay_totalprice = $pay_price * $pay_number;
if($_G['charset']=='gbk'){
	$pay_subject = cutstr($pay_subject,20,'');
	$pay_subject = iconv('GBK','UTF-8',$pay_subject);
}
//����Ƕ��ֱ���
if($setting['cost']){
	if($setting['nodaibaoming']){
		$capply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$capply['ufielddata'] = unserialize($capply['ufielddata']);
		$price = 0;
		$paytext = '';
		foreach($setting['cost'] as $value){
			$paytext = $paytext.$value['cost_name'].' '.$capply['ufielddata']['cost'.$value['id']].' x &yen;'.$value['cost_price'].'<br>';
			$price = $price+$capply['ufielddata']['cost'.$value['id']]*$value['cost_price'];
		}
	}else{
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$price = 0;
		$paytext = '';
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$paytext = $paytext.$setting['cost'][$value['ufielddata']['costclass']]['cost_name'].' 1 x &yen;'.$setting['cost'][$value['ufielddata']['costclass']]['cost_price'].'<br>';
			$price = $price + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
		}
	}
	$pay_totalprice = $price;
}
//VIP�ۿ�
if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/vip/wxpay.php')) {
	@include 'module/vip/wxpay.php';
}

if($setting['app_benefit']>0){
	$pay_totalprice = $pay_totalprice - $setting['app_benefit'];
}



if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
$tradeno = date('Ymd',$_G['timestamp']).getRandChar(12);


//���ݿ�����֧����¼
$paylog = array();
$paylog['applyid'] = $apply['applyid'];
$paylog['uid'] = $_G['uid'];
$paylog['tid'] = $tid;
$paylog['tradeno'] = $tradeno;
$paylog['paytype'] = 'qfapppay';
$paylog['subject'] = $items['subject'];
$paylog['price'] = $pay_price;
$paylog['buyer_email'] = '';
$paylog['total_fee'] = $pay_totalprice;
$paylog['create_time'] = $_G['timestamp'];
$paylog['paystate'] = 1;
DB::insert("xj_eventpay_log",$paylog);





$result['full'] = 1;
$result['price'] = $pay_totalprice;
$result['tradeno'] = $tradeno;
$result['pay_subject'] = $pay_subject;
echo json_encode($result);
exit;




function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}


function paysmssend($tid,$uid){
	global $_G;
	//���Լ�¼��ʼ
	//$log_name="./alipay.txt";//log�ļ�·��
	//log_result($log_name,"�����յ���notify֪ͨ��:\r\n".$xml."\r\n�����ص���Ϣ��:\r\n");
	//���Լ�¼����
	
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=$uid");
	$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid=$tid and A.tid = B.tid");
	$setting = unserialize($thread['setting']);
	$event_starttime = dgmdate($thread['starttime'],'dt');
	if($setting['seccode'] == 1){		
		$message = cutstr($thread['subject'],30).'������ɹ�������:'.$apply['applynumber'].'�� ��֤��:'.$apply['seccode'].' �ʱ��:'.$event_starttime;
		$sendtype = '������֤�����';
		if($_G[charset]=='gbk'){
			$message = diconv($message,'UTF-8','GBK');
			$sendtype = diconv($sendtype,'UTF-8','GBK');
		}
		sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
		//xjsendsms(array($apply['mobile']),$message,$sendtype);
		sendpm($apply['uid'],'',$message,$thread['authorid']);
	}elseif($setting['success_sms'] == 1){
		sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
		//�׻����
		//$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
		//$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
		//sendsms_notice_yhd($apply['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);
		
	}
}
//From: dis'.'m.tao'.'bao.com
?>