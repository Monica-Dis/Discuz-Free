<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tid = intval($_GET['tid']);
$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = '$tid'"));
$setting = unserialize($items['setting']);


$perpage = $_G['cache']['plugin']['xj_event']['event_showapplynum']; //ÿҳ��

$allren = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid'");
$passren = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' AND verify=1");
$nopassren = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' AND verify=0");

$all = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid'");
$pass = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' AND verify=1");
$nopass = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' AND verify=0");
$eventinfo = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid='$tid'");
$eventinfo['setting'] = unserialize($eventinfo['setting']);

	
if($_GET['action']=='nopass'){
	$sqlstr .= " AND A.verify=0";
}elseif($_GET['action']=='pass'){
	$sqlstr .= " AND A.verify=1";
}

$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid LEFT JOIN ".DB::table('xj_event_member_info')." C ON A.uid=C.uid ".$joinstr."WHERE A.tid=$tid AND A.first=1 ".$sqlstr."");
$page = $_GET['page']?$_GET['page']:1;
if(@ceil($listcount/$perpage) < $page) {
	$page = 1;
}
$start_limit = ($page - 1) * $perpage;
$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:event_userlist&action=".$_GET['action']."&tid=$tid",0,10,false,false);
//$multipage = str_replace('class="pg"','class="jlpg"',$multipage);

$query = DB::query("SELECT * FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid LEFT JOIN ".DB::table('xj_event_member_info')." C ON A.uid=C.uid ".$joinstr."WHERE A.tid=$tid AND A.first=1 ".$sqlstr." ORDER BY A.dateline DESC,A.first DESC LIMIT $start_limit,$perpage");
$joinlist = array();
while($value = DB::fetch($query)){
	if(!$setting['nodaibaoming']){
		$value['applynumber'] = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".intval($value['uid']));
	}
	$value['avatar'] = '<img src="'.avatar($value[uid], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="26" height="26" align="absmiddle" />';
	$joinlist[] = $value;
}



include template('xj_event:userlist');

?>