<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$result = array();
//�ж�Ŀ¼�Ƿ���ڣ������ھʹ���
$path = 'data/attachment/xj_event/'.date('Ym',time()).'/';
if(!is_readable($path))
{
    if(!mkdir($path,0777,true)){
        $result['full'] = 2;
        $result['message'] = 'Directory to create failure';
        echo json_encode($result);
        exit;
    }
}


$extArr = array("jpg", "png", "gif");

if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST"){
    $name = $_FILES['file']['name'];
    $size = $_FILES['file']['size'];

    if(empty($name)){
        $result['full'] = 2;
        $result['message'] = lang('plugin/xj_event','qingxuanzeyaoscdtphwj');
        echo json_encode($result);
        exit;
    }
    $ext = extend($name);
    if(!in_array($ext,$extArr)){
        $result['full'] = 2;
        $result['message'] = lang('plugin/xj_event','znscjpgpnggsdtp');
        echo json_encode($result);
        exit;
    }
    if($size>(2000*1024)){
        $result['full'] = 2;
        $result['message'] = lang('plugin/xj_event','tupiandaxiaobncg').'2M';
        echo json_encode($result);
        exit;
    }



    $image_name = date("YmdHis").rand(100,999).".".$ext;
    $tmp = $_FILES['file']['tmp_name'];
    if(move_uploaded_file($tmp, $path.$image_name)){
        $result['full'] = 1;
        $result['fileurl'] = $path.$image_name;
        echo json_encode($result);
        exit;
    }else{
        $result['full'] = 2;
        $result['message'] = 'upload error';
        echo json_encode($result);
        exit;
    }
    exit;
}



//��ȡ�ļ����ͺ�׺
function extend($file_name){
    $extend = pathinfo($file_name);
    $extend = strtolower($extend["extension"]);
    return $extend;
}
?>