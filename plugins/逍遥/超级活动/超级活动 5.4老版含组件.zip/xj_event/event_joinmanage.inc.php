<?php
/**
 *    [�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!$_G['uid']) {
    showmessage('not_loggedin', null, array(), array('login' => 1));
}

//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

include DISCUZ_ROOT . './source/plugin/xj_event/include/func.php';
$tid = intval($_GET['tid']);

//Ȩ������
$thread          = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM " . DB::table('forum_thread') . " A," . DB::table('xj_event') . " B WHERE A.tid='$tid' and A.tid = B.tid");
$setting         = unserialize($thread['setting']);
$event_starttime = dgmdate($thread['starttime'], 'dt');

//�ж��ǲ��ǹ����Ŷ�
$event_admin = false;
if (in_array($_G['username'], $setting['event_admin'])) {
    $event_admin = true;
}
if ($_G['groupid'] > 1 && $_G['uid'] != $thread['authorid'] && !$event_admin) {
    showmessage('quickclear_noperm');
}

if ($_GET['action'] == 'verify' and $_GET['applyid']) {
    if (!submitcheck('jmsubmit')) {
        showmessage('submit_invalid');
    }
    $applyids = implode(',', $_GET['applyid']);
    if ($_GET['verifyaction'] == 1) {
        $checknum      = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)"); //������֤����
        $applynum      = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"); //�ѱ�������
        $applycountnum = DB::result_first("SELECT event_number FROM " . DB::table('xj_event') . " WHERE tid='$tid'"); //�������
        if ($checknum <= ($applycountnum - $applynum) or $applycountnum == 0) {
            $applys = DB::fetch_all("SELECT uid,tid,fromuid FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
            foreach ($applys as $value) {
                DB::query("UPDATE " . DB::table('xj_eventapply') . " SET verify = 1 WHERE uid=" . $value['uid'] . " AND tid=" . $value['tid']);
            }
            //DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify = 1 WHERE applyid in($applyids)");

            //������������
            if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/invitation/event_yqjl.php')) {
                if ($setting['yqjl_jfs'] > 0) {
                    $selectlist = DB::fetch_all("SELECT uid,tid,fromuid FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
                    foreach ($selectlist as $value) {
                        $value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid=" . $value['tid'] . " AND uid=" . $value['uid']);
                        if ($value['fromuid'] > 0) {
                            $yqjl             = array();
                            $yqjl['tid']      = $value['tid'];
                            $yqjl['fromuid']  = $value['fromuid'];
                            $yqjl['applyuid'] = $value['uid'];
                            $yqjl['jfs']      = $setting['yqjl_jfs'] * $value['applynumber'];
                            $yqjl['jflx']     = $setting['yqjl_jflx'];
                            $yqjl['dateline'] = $_G['timestamp'];
                            DB::insert('xj_event_yqjl_log', $yqjl);
                            updatemembercount($yqjl['fromuid'], array($yqjl['jflx'] => +$yqjl['jfs']));
                            $applyusername = DB::result_first("SELECT username FROM " . DB::table('common_member') . " WHERE uid=" . $yqjl['applyuid']);
                            notification_add($yqjl['fromuid'], 'system', $applyusername . lang('plugin/xj_event', 'beiniyaoqinbaomincanjiale') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $thread['subject'] . '</a> ' . lang('plugin/xj_event', 'huodonghuode') . $yqjl['jfs'] . $_G['setting']['extcredits'][$yqjl['jflx']]['title'] . lang('plugin/xj_event', 'jiangli'));
                        }
                    }
                }
            }

            //���ֻ�����
            if ($setting['seccode'] == 1) {
                include 'include/sms_func.php';
                $selectlist = DB::fetch_all("SELECT uid,mobile,applynumber,seccode FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
                foreach ($selectlist as $value) {
                    $message = cutstr($thread['subject'], 30) . lang('plugin/xj_event', 'hdbmcgrs') . ':' . $value['applynumber'] . lang('plugin/xj_event', 'renyanzhengma') . ':' . $value['seccode'] . lang('plugin/xj_event', 'huodongshijian') . ' :' . $event_starttime;
                    //xjsendsms(array($value['mobile']),$message,lang('plugin/xj_event', 'maomyzmdx'));
                    sendsms_vcode($value['mobile'], $thread['subject'], $value['applynumber'], $value['seccode']);
                    sendpm($value['uid'], '', $message, $_G['uid']);
                }
            } elseif ($setting['success_sms'] == 1) {
                include 'include/sms_func.php';
                $selectlist = DB::fetch_all("SELECT uid,mobile,applynumber,seccode FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
                foreach ($selectlist as $value) {
                    sendsms_success($value['mobile'], $thread['subject'], $event_starttime);
                    //�׻����
                    //$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
                    //$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
                    //sendsms_notice_yhd($value['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);

                }
            }

            //����֪ͨ
            $query = DB::query("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
            while ($value = DB::fetch($query)) {
                notification_add($value['uid'], 'system', lang('plugin/xj_event', 'ningbmcjd') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $thread['subject'] . '</a> ' . lang('plugin/xj_event', 'yishenghtg'), array(), 0);
                //΢����Ϣ
                if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
                    require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
                    $xj_wxmessagecore = new xj_wxmessagecore();
                    $xj_wxmessagecore->send_eventmessage($value['uid'],$tid,1);
                }
                //�¶�����Ϣ
                if($_G['cache']['plugin']['xj_dxmessage']['enable']){
                    $event_uid = DB::result_first("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid=$tid");
                    $applyid = $value['applyid'];
                    require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
                    $xj_dxmessagecore = new xj_dxmessagecore();
                    $other = array();
                    $other['applyid'] = $applyid;
                    $other['uid'] = $event_uid;
                    $xj_dxmessagecore->sendsms($value['mobile'],1,$other);  //�����ɹ�����֪ͨ����
                    if($setting['seccode'] == 1){ 
                       $other = array();
                       $other['applyid'] = $applyid;
                       $other['uid'] = $event_uid;
                       $other['verifycode'] = $value['seccode'];
                       $xj_dxmessagecore->sendsms($value['mobile'],2,$other);  //�����ɹ�������֤�����
                    }
                }

            }
        } else {
            $onerror = lang('plugin/xj_event', 'mebgwfsh');
        }
    } elseif ($_GET['verifyaction'] == 2) {
        $applys = DB::fetch_all("SELECT uid,tid FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
        foreach ($applys as $value) {
            DB::query("UPDATE " . DB::table('xj_eventapply') . " SET verify = 0 WHERE uid=" . $value['uid'] . " AND tid=" . $value['tid']);
            //���뽱����ȡ������
            if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/invitation/event_yqjl.php')) {
                if ($setting['yqjl_jfs'] > 0) {
                    $yqjl = DB::fetch_first("SELECT * FROM " . DB::table('xj_event_yqjl_log') . " WHERE tid=" . $value['tid'] . " AND applyuid=" . $value['uid']);
                    if ($yqjl['jfs'] > 0) {
                        updatemembercount($yqjl['fromuid'], array($yqjl['jflx'] => -$yqjl['jfs']));
                        DB::delete('xj_event_yqjl_log', "tid=" . $value['tid'] . " AND applyuid=" . $value['uid']);
                        $applyusername = DB::result_first("SELECT username FROM " . DB::table('common_member') . " WHERE uid=" . $yqjl['applyuid']);
                        notification_add($yqjl['fromuid'], 'system', '[<a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $thread['subject'] . '</a>] ' . $applyusername . lang('plugin/xj_event', 'beiglqxbmndyqjlsh') . ' -' . $yqjl['jfs'] . $_G['setting']['extcredits'][$yqjl['jflx']]['title']);
                    }
                }
            }

        }
        //DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify = 0 WHERE applyid in($applyids)");
    } elseif ($_GET['verifyaction'] == 3) {
        $items = DB::fetch_first("SELECT userfield,setting,use_extcredits_num,use_extcredits FROM " . DB::table('xj_event') . " WHERE tid = '$tid'");
        if ($items['use_extcredits_num'] > 0) {
            $query = DB::query("SELECT uid FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
            /*
        while($value = DB::fetch($query)){
        updatemembercount($value['uid'],array($items['use_extcredits']=>$items['use_extcredits_num']));
        }
         */
        }
        $applys = DB::fetch_all("SELECT uid,tid FROM " . DB::table('xj_eventapply') . " WHERE applyid in($applyids)");
        foreach ($applys as $value) {
            DB::query("DELETE FROM " . DB::table('xj_eventapply') . " WHERE uid=" . $value['uid'] . " AND tid=" . $value['tid']);
            //���뽱����ȡ������
            if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/invitation/event_yqjl.php')) {
                if ($setting['yqjl_jfs'] > 0) {
                    $yqjl = DB::fetch_first("SELECT * FROM " . DB::table('xj_event_yqjl_log') . " WHERE tid=" . $value['tid'] . " AND applyuid=" . $value['uid']);
                    if ($yqjl['jfs'] > 0) {
                        updatemembercount($yqjl['fromuid'], array($yqjl['jflx'] => -$yqjl['jfs']));
                        DB::delete('xj_event_yqjl_log', "tid=" . $value['tid'] . " AND applyuid=" . $value['uid']);
                        $applyusername = DB::result_first("SELECT username FROM " . DB::table('common_member') . " WHERE uid=" . $yqjl['applyuid']);
                        notification_add($yqjl['fromuid'], 'system', '[<a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $thread['subject'] . '</a>] ' . $applyusername . lang('plugin/xj_event', 'beiglqxbmndyqjlsh') . ' -' . $yqjl['jfs'] . $_G['setting']['extcredits'][$yqjl['jflx']]['title']);
                    }
                }
            }
        }
    }
}

//������ֶ�
$selectuserfield = unserialize($thread['userfield']);
$sysuserfield    = unserialize($_G['setting']['activityfield']);
//�µı����ֶ�
if($setting['myuserfield']){
	$myuserfield = $eventcore->GetUserField($setting['myuserfield']);
}

$listcount = DB::result_first("SELECT COUNT(*) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid'");
$perpage   = 15; //ÿҳ��
$page      = $_GET['page'] ? $_GET['page'] : 1;
if (@ceil($listcount / $perpage) < $page) {
    $page = 1;
}
$start_limit = ($page - 1) * $perpage;
$multipage   = multi($listcount, $perpage, $page, "plugin.php?id=xj_event:event_joinmanage&tid=$tid", 0, 10, false, true, false, 'joinlist_display');

$query    = DB::query("SELECT * FROM " . DB::table('xj_eventapply') . " A," . DB::table('common_member') . " B WHERE A.uid = B.uid and A.tid = '$tid' ORDER BY A.verify,A.dateline DESC,A.first DESC LIMIT $start_limit,$perpage");
$joinlist = array();
require_once libfile('function/profile');
loadcache('profilesetting');
$i = 1;
//ǩ��
if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/signed/wsq_signed.php')) {
    $signed_enable = true;
}

while ($value = DB::fetch($query)) {

    $value['dateline']   = dgmdate($value['dateline'], 'u'); //date('Y-m-d H:i:s',$value['dateline']);
    $value['ufielddata'] = unserialize($value['ufielddata']);

    //���ֱ�������
    foreach ($setting['cost'] as $costvalue) {
        $value['cost' . $costvalue['id']] = $value['ufielddata']['cost' . $costvalue['id']];
    }
    $value['costclass'] = $value['ufielddata']['costclass'];

    $data       = '';
    $ufielddata = array();
    foreach ($value['ufielddata'] as $key => $fieldid) {
        if (strpos($key, 'myfield')===false) {
            $data = profile_show($key, $value['ufielddata']);
            if ($_G['cache']['profilesetting'][$key]['formtype'] == 'file') {
                $data = '<a href="' . $data . '" target="_blank" onclick="zoom(this, this.href, 0, 0, 0); return false;">' . lang('forum/misc', 'activity_viewimg') . '</a>';
            }
            if ($key == 'birthday') {
                $ufielddata[$key]['value'] = $fieldid;
            } else {
                $ufielddata[$key]['value'] = $data;
            }
            if ($key == 'qq') {
                $ufielddata[$key]['value'] = '<a href="http://wpa.qq.com/msgrd?v=3&uin=' . $fieldid . '&Site=' . $_G['setting']['bbname'] . '&Menu=yes&from=discuz" target="_blank" title="' . lang('spacecp', 'qq_dialog') . '"><img src="' . STATICURL . '/image/common/qq.gif" alt="QQ" style="margin:0px;"/></a>' . $fieldid;
            }
        }else{
        	$ufielddata[$key]['value'] = $fieldid;
        }
    }
    $value['ufielddata'] = $ufielddata;
    $value['No']         = $i;

    //ǩ��
    if ($signed_enable) {
        $signed = DB::fetch_first("SELECT * FROM " . DB::table('xj_event_signed') . " WHERE tid='$tid' AND uid=" . $value['uid']);
        if ($signed) {
            $value['signed_dateline'] = dgmdate($signed['dateline']);
        }
    }

    //֧�����
    if ($setting['eventpay']) {
        $paylog           = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventpay_log') . " WHERE applyid=" . $value['applyid'] . " ORDER BY create_time DESC");
        $value['paytype'] = $paylog['paytype'];
        $value['price']   = $paylog['total_fee'];
    }

    $joinlist[] = $value;
    $i++;
}


include template('xj_event:join_manage');
