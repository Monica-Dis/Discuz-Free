<?php
/**
 *    [���(xj_event.{modulename})] (C)2012-2099 By DisM.taobao.COM.
 *    Version: 1.0
 *    Date: 2012-9-11 12:03
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define('EVENT_NAME', lang('plugin/xj_event', 'fabuhd'));
define('EVENT_BUTTONTEXT', lang('plugin/xj_event', 'fabuhd'));
define('EVENT_ICON', 'images/event.gif');
loadcache('plugin');
//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();
include 'source/plugin/xj_event/include/release.class.php';
$eventrelease = new xj_eventrelease();
include 'source/plugin/xj_event/include/view.class.php';
$eventview = new xj_eventview();


class threadplugin_xj_event {
	public $name = EVENT_NAME;
	//������������
	public $iconfile = EVENT_ICON;
	//�������������е�ǰ׺ͼ��
	public $buttontext = EVENT_BUTTONTEXT;
	//����ʱ��ť����
	public function newthread($fid) {
		global $_G,$eventcore,$eventrelease;
		if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/eventurl/view.php')) {  //�������ת
			$module_eventurl = true;
		}
		
		
		$extcredits = $_G['setting']['extcredits'];
		$citys = $eventcore->Getcity(false);
		$offlineclass = $eventcore->GetEventClass(1,false);
		$onlineclass = $eventcore->GetEventClass(2,false);
		$userfield = unserialize($_G['setting']['activityfield']);
		//�µı����ֶ�
		$myuserfield = C::t('#xj_event#xj_event_field')->fetch_all();

		$activity['ufield']['userfield'] = array('realname', 'mobile');

		//��ȡģ��
		$tmp = explode("\n", $_G['cache']['plugin']['xj_event']['event_template']);
		$event_template = array();
		foreach ($tmp as $key => $value) {
			$ctmp = array();
			$ctmp = explode("|", $value);
			$ctmp[0] = str_replace("\r", '', $ctmp[0]);
			$ctmp[1] = str_replace("\r", '', $ctmp[1]);
			$event_template[] = $ctmp;
		}
		$forumlist = $this -> forumselect(false, 0, 0, true);

		//���������������
		if ($_G['cache']['plugin']['xj_event']['event_city']) {
			$lang_province = lang('spacecp', 'district_level_1');
			$lang_city = lang('spacecp', 'district_level_2');
			$province = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE level = 1");
			$city = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE level = 2 order by upid");
			$i = 0;
			$tempid = 1;
			foreach ($city as $key => $value) {
				if ($value['upid'] != $tempid) {
					$i = 0;
					$tempid = $value['upid'];
				}
				$city[$key]['displayorder'] = $i;
				$i++;
			}
		};


		include  template('xj_event:post_event');
		return $return;
	}

	public function newthread_submit($fid) {
		global $_G;
		if (!in_array('mobile', $_GET['userfield']) && $_GET['seccode'] == 1) {
			showmessage(lang('plugin/xj_event', 'qylbmdxbtzlxbx'));
		}
	}

	public function newthread_submit_end($fid,$tid) {
		global $_G,$eventrelease;
		date_default_timezone_set('Asia/Shanghai');
        $eventrelease->event_post($_POST,$tid,'');
	}

	public function editpost($fid, $tid) {
		global $_G,$eventcore;

		if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/eventurl/view.php')) {  //�������ת
			$module_eventurl = true;
		}
		
		$items = C::t('#xj_event#xj_event')->fetch_first_event($tid);

		$extcredits = $_G['setting']['extcredits'];
        $citys = $eventcore->Getcity(false);
        $offlineclass = $eventcore->GetEventClass(1,false);
        $onlineclass = $eventcore->GetEventClass(2,false);
		$starttime = dgmdate($items['starttime'], 'dt');
		$endtime = dgmdate($items['endtime'], 'dt');
		$activitybegin = dgmdate($items['activitybegin'], 'dt');
		$activityexpiration = dgmdate($items['activityexpiration'], 'dt');
		$selectuserfield = unserialize($items['userfield']);
		$userfield = unserialize($_G['setting']['activityfield']);
		//�µı����ֶ�
        $myuserfield = C::t('#xj_event#xj_event_field')->fetch_all();
		$setting = unserialize($items['setting']);
		$setting['event_admin'] = implode(',', $setting['event_admin']);

		//�����
		$sessionarray = array();
		foreach ($setting['session'] as $key => $value) {
			$sessionarray[] = $key . '=' . $value;
		}
		$sessionstr = implode("\r\n", $sessionarray);

		if (!$items['activityaid'] and $items['activityaid_url']) {
			$imgurl = $items['activityaid_url'];
		} else {
			$imgurl = getforumimg($items['activityaid'], 0, 360, 230, 'fixnone');
		}

		if(substr($items['activityaid_url'],0,4)!='data' && substr($items['activityaid_url'],0,4)!='http'){
		    $items['activityaid_url'] = 'data/attachment/forum/'.$items['activityaid_url'];
        }


		$forumlist = $this -> forumselect(false, 0, $setting['eventzy_fid'], true);

		//���������������
		if ($_G['cache']['plugin']['xj_event']['event_city']) {
			$lang_province = lang('spacecp', 'district_level_1');
			$lang_city = lang('spacecp', 'district_level_2');
			$province = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE level = 1");
			$city = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE level = 2 order by upid");
			$i = 0;
			$tempid = 1;

			if ($items['citys']) {
				$upid = intval(DB::result_first("SELECT upid FROM " . DB::table('common_district') . " WHERE name = '" . $items['citys'] . "'"));
				$items['province'] = DB::result_first("SELECT name FROM " . DB::table('common_district') . " WHERE id = $upid");
			}

			foreach ($city as $key => $value) {
				if ($value['upid'] != $tempid) {
					$i = 0;
					$tempid = $value['upid'];
				}
				$city[$key]['displayorder'] = $i;
				$i++;
			}
		}
		//���Ƶ
		$setting['event_video'] = urldecode($setting['event_video']);
		include  template('xj_event:post_event');
		return $return;
	}

	public function editpost_submit($fid, $tid) {
		global $_G;
		if (!in_array('mobile', $_GET['userfield']) && $_GET['seccode'] == 1) {
			showmessage(lang('plugin/xj_event', 'qylbmdxbtzlxbx'));
		}
	}

	public function editpost_submit_end($fid, $tid) {
		global $_G,$eventrelease;
		date_default_timezone_set('Asia/Shanghai');

        $eid = C::t("#xj_event#xj_event")->result_first_event_tid($tid,'eid');
        $eventrelease->event_post($_POST,$tid,$eid);
     }

	public function viewthread($tid) {
		global $_G,$eventcore,$eventview;

		$items = $eventview->event_view(0,$tid);



        $items = C::t('#xj_event#xj_event')->fetch_first_event($tid);
		$setting = unserialize($items['setting']);
		if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/eventurl/view.php') && $items['postclass'] == 3) {  //�������ת
			$module_eventurl = true;
			@include DISCUZ_ROOT . './source/plugin/xj_event/module/eventurl/view.php';
			if($admineventurl){
				return $return;
			}
		}
		if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/wsqcenter/event_view.php')) {   //����ֻ�������ת�ֻ���
			if ($_G['mobile']) {
			    header("Location:" . $_G['siteurl'] . "plugin.php?id=xj_event:wsqcenter&mod=event_view&tid=$tid" . ($_GET['icode'] ? '&icode=' . $_GET['icode'] : ''));
			}
		}
		$timestamp = $_G['timestamp'];
		$extcredits = $_G['setting']['extcredits'];
		//�ר����ת�ж�
		if (!checkmobile()) {
			if ($setting['project']['openproject'] && (($_G['groupid'] > 1 && $_G['uid'] != $items['uid']) || !$_G['uid'])) {
				if ($setting['project']['openprojectauto']) {
					header("Location: plugin.php?id=xj_event:project_show&tid=$tid");
				}
			}
		}

		//��ȡ��������
		if ($items['postclass'] == 1) {
            $postclass = lang('plugin/xj_event','xxhd');
            $eventclassname = $eventcore->GetEventClassName($items['postclass'],$items['offlineclass']);
		} else {
            $postclass = lang('plugin/xj_event','xshd');
            $eventclassname = $eventcore->GetEventClassName($items['postclass'],$items['onlineclass']);
		}
		foreach ($extcredits as $key => $value) {
			if ($key == $items['use_extcredits']) {
				$extcredit_title = $value['title'];
			}
		}
		$citys = $items['citys'];
		$starttime = dgmdate($items['starttime'], 'dt');
		$endtime = dgmdate($items['endtime'], 'dt');
		$activityexpiration = dgmdate($items['activityexpiration'], 'dt');

		if (!$items['activityaid'] and $items['activityaid_url']) {
			$imgurl = $items['activityaid_url'];
		} else {
			//$imgurl = $this->_getpicurl($items['activityaid'],$tid);
			$imgurl = getforumimg($items['activityaid'], 0, 360, 230, 'fixnone');
		}

		if(substr($items['activityaid_url'],0,4)!='data' && substr($items['activityaid_url'],0,4)!='http'){
		    $imgurl = 'data/attachment/forum/'.$items['activityaid_url'];
        }else{
        	$imgurl = $items['activityaid_url'];
        }
        

		$userfield = unserialize($items['userfield']);
		$selectuserfield = unserialize($items['userfield']);
		if ($selectuserfield) {
			if ($selectuserfield) {
				$htmls = $settings = array();
				require_once  libfile('function/profile');
				foreach ($selectuserfield as $fieldid) {
					if (empty($ufielddata['userfield'])) {
						$memberprofile = C::t('common_member_profile') -> fetch($_G['uid']);
						foreach ($selectuserfield as $val) {
							if ($val == 'birthday') {
								$ufielddata['userfield']['birthyear'] = $memberprofile['birthyear'];
								$ufielddata['userfield']['birthmonth'] = $memberprofile['birthmonth'];
							}
							$ufielddata['userfield'][$val] = $memberprofile[$val];
						}
						unset($memberprofile);
					}
					$html = profile_setting($fieldid, $ufielddata['userfield'], false, true);
					if ($html) {
						$settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
						$htmls[$fieldid] = $html;
					}
				}
			}
		} else {
			$selectuserfield = '';
		}



		$hg = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventthread') . " WHERE eid=" . intval($items['eid']) . " and sort=1");
		//����ͨ��������
		$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1");
		$applycountnumber = !$applycountnumber ? 0 : $applycountnumber;
		$applycountnumberd = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=0");
		$applycountnumberd = !$applycountnumberd ? 0 : $applycountnumberd;

		//����ʱ����ѡ�������
		$items['event_number_max'] = $items['event_number_max'] > 0 ? $items['event_number_max'] : 1;
		$applynumber = array();
		for ($i = 1; $i <= $items['event_number_max']; $i++) {
			$applynumber[] = $i;
		}
		//�������״̬
		$apply = DB::fetch_first("SELECT applyid,pay_state,verify,seccode FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and uid=" . $_G['uid']);
		$verify = $apply['verify'];
		$pay_state = $apply['pay_state'];

		//�ж��ǲ��ǹ����Ŷ�
		$event_admin = false;
		if ($_G['username']) {
			if (in_array($_G['username'], $setting['event_admin'])) {
				$event_admin = true;
			}
		}
		//������б�
		$event_adminlist = implode(',', $setting['event_admin']);

		//�ظ��ſ��Ա���
		$bmbtnshow = true;
		if ($setting['reply']) {
			$replys = DB::result_first("SELECT count(*) FROM " . DB::table('forum_post') . " WHERE tid='$tid' AND first<>1 AND invisible>=0 AND authorid = " . $_G['uid']);
			if ($replys < 1) {
				$bmbtnshow = false;
			}
		}

		//���������������
		if ($_G['cache']['plugin']['xj_event']['event_city']) {
			$lang_province = lang('spacecp', 'district_level_1');
			$lang_city = lang('spacecp', 'district_level_2');
			if ($items['citys']) {
				$upid = intval(DB::result_first("SELECT upid FROM " . DB::table('common_district') . " WHERE name = '" . $items['citys'] . "'"));
				if ($upid) {
					$items['province'] = DB::result_first("SELECT name FROM " . DB::table('common_district') . " WHERE id = $upid");
				}
			}
		}

		if ($setting['vip_discount'] === '') {
		} else {
			$vip_price = $items['use_cost'] - $setting['vip_discount'];
		}





		if ($setting['onlysubscribeweixin'] && $_G['cache']['plugin']['xj_wxmessage']['wxlogin']) { //���޹�ע΢�ű���,��ȡ�Ƿ��ע
			require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
        	$xj_wxmessagecore = new xj_wxmessagecore();
        	$res         = $xj_wxmessagecore->getweixinuserinfo($_G['uid']);
        	$weixinsubscribe = $res['subscribe'];
		}


		//���Ƶ
		$setting['event_video'] = explode("\r\n",urldecode($setting['event_video']));



		include  template('xj_event:viewthread_event');
		return $return;
	}

	/**
	 * ͨ��aid��ȡͼƬ����
	 */
	public function _getpicurl($aid, $tid) {
		global $_G;
		$return = '';
		if ($aid) {
			$picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM " . DB::table(getattachtablebytid($tid)) . " WHERE aid='{$aid}'");
			if ($picatt['remote']) {
				$picatt['attachment'] = $_G['setting']['ftp']['attachurl'] . 'forum/' . $picatt['attachment'];
				$picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://' . $picatt['attachment'] : $picatt['attachment'];
			} else {
				$picatt['attachment'] = $_G['setting']['attachurl'] . 'forum/' . $picatt['attachment'];
			}
		}
		$return = $picatt['attachment'];
		return $return;
	}

	public function forumselect($groupselectable = false, $arrayformat = 0, $selectedfid = 0, $showhide = false, $evalue = false, $special = 0) {
		global $_G;
		if (!isset($_G['cache']['forums'])) {
			loadcache('forums');
		}
		$forumcache = &$_G['cache']['forums'];
		$forumlist = $arrayformat ? array() : '<optgroup label="&nbsp;">';
		foreach ($forumcache as $forum) {
			if (!$forum['status'] && !$showhide) {
				continue;
			}
			if ($selectedfid) {
				if (!is_array($selectedfid)) {
					$selected = $selectedfid == $forum['fid'] ? ' selected' : '';
				} else {
					$selected = in_array($forum['fid'], $selectedfid) ? ' selected' : '';
				}
			}
			if ($forum['type'] == 'group') {
				if ($arrayformat) {
					$forumlist[$forum['fid']]['name'] = $forum['name'];
				} else {
					$forumlist .= $groupselectable ? '<option value="' . ($evalue ? 'gid_' : '') . $forum['fid'] . '" class="bold">--' . $forum['name'] . '</option>' : '</optgroup><optgroup label="--' . $forum['name'] . '">';
				}
				$visible[$forum['fid']] = true;
			} elseif ($forum['type'] == 'forum' && isset($visible[$forum['fup']]) && (!$forum['viewperm'] || ($forum['viewperm'] && forumperm($forum['viewperm'])) || strstr($forum['users'], "\t$_G[uid]\t")) && (!$special || (substr($forum['allowpostspecial'], -$special, 1)))) {
				if ($arrayformat) {
					$forumlist[$forum['fup']]['sub'][$forum['fid']] = $forum['name'];
				} else {
					$forumlist .= '<option value="' . ($evalue ? 'fid_' : '') . $forum['fid'] . '"' . $selected . '>' . $forum['name'] . '</option>';
				}
				$visible[$forum['fid']] = true;
			} elseif ($forum['type'] == 'sub' && isset($visible[$forum['fup']]) && (!$forum['viewperm'] || ($forum['viewperm'] && forumperm($forum['viewperm'])) || strstr($forum['users'], "\t$_G[uid]\t")) && (!$special || substr($forum['allowpostspecial'], -$special, 1))) {
				if ($arrayformat) {
					$forumlist[$forumcache[$forum['fup']]['fup']]['child'][$forum['fup']][$forum['fid']] = $forum['name'];
				} else {
					$forumlist .= '<option value="' . ($evalue ? 'fid_' : '') . $forum['fid'] . '"' . $selected . '>&nbsp; &nbsp; &nbsp; ' . $forum['name'] . '</option>';
				}
			}
		}
		if (!$arrayformat) {
			$forumlist .= '</optgroup>';
			$forumlist = str_replace('<optgroup label="&nbsp;"></optgroup>', '', $forumlist);
		}
		return $forumlist;
	}

}
