<?php 

if(file_exists($xjsms = DISCUZ_ROOT.'./data/sysdata/cache_xjsms.php')) {
	@include $xjsms;
}

function regsms(){
	global $username,$password,$realname,$mobile,$email;
	$return = '';
	$message = dfsockopen("http://xjsms.sinaapp.com/reg.php?act=save",0,"username=$username&password=$password&realname=$realname&mobile=$mobile&email=$email");
	$return = $message;
	//exit($message);
	return $return;	
}



//��ȡ�������
function getsmsoverage(){
	global $_G,$xjsms;
	$return = '';
	$username = $xjsms['username'];
	$password = md5($xjsms['password']);
	$message = dfsockopen("http://xjsms.sinaapp.com/sms.php",0,"action=overage&username=$username&password=$password");
	$return = $message;
	return $return;
}

function xjsendsms($mobile = array(),$content,$sendtype = 'unknown',$sendtime = ''){
	global $_G,$xjsms;
	$username = $xjsms['username'];
	$password = md5($xjsms['password']);
	$content = $content.$xjsms['signature'];

	if($_G[charset]=='gbk'){
		$sendcontent = $content;
	}else{
		$sendcontent = diconv($content,'UTF-8','GBK');
	}

	$return = '';
	if(count($mobile)>0){
		$mobilestr = implode(",",$mobile);
		$message = dfsockopen("http://xjsms.sinaapp.com/sms.php",0,"action=send&username=$username&password=$password&mobile=".$mobilestr."&sendtime=".$sendtime."&content=".$sendcontent);
		$return = $message;
	}
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = lang('plugin/xj_event', 'test');
	$sendlog['sendcount'] = count($mobile);
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $content;
	$sendlog['sendnumber'] = implode(',',$mobile);
	DB::insert('xj_event_sms_log',$sendlog);
	
	
	return $return;
}

function sendsms_vcode($mobile,$eventname,$number,$vcode){
	global $_G,$xjsms;
	$data['username'] = $xjsms['username'];
	$data['password'] = md5($xjsms['password']);
	$data['signature'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$xjsms['signature']):$xjsms['signature'];
	$data['mobile'] = $mobile;
	$data['eventname'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$eventname):$eventname;
	$data['number'] = $number;
	$data['vcode'] = $vcode;
	$data = json_encode($data);
	$return = postjson('http://xjsms.sinaapp.com/dayu_eventvcode.php',$data);
	
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = 'eventvcode';
	$sendlog['sendcount'] = 1;
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $eventname.$vcode;
	$sendlog['sendnumber'] = $mobile;
	DB::insert('xj_event_sms_log',$sendlog);
	return $return;
}

function sendsms_success($mobile,$eventname,$eventtime){
	global $_G,$xjsms;
	$data['username'] = $xjsms['username'];
	$data['password'] = md5($xjsms['password']);
	$data['signature'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$xjsms['signature']):$xjsms['signature'];
	$data['mobile'] = $mobile;
	$data['eventname'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$eventname):$eventname;
	$data['eventtime'] = $eventtime;
	$data = json_encode($data);
	$return = postjson('http://xjsms.sinaapp.com/dayu_eventsuccess.php',$data);
	
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = 'eventsuccess';
	$sendlog['sendcount'] = 1;
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $eventname;
	$sendlog['sendnumber'] = $mobile;
	DB::insert('xj_event_sms_log',$sendlog);
	return $return;
}


function sendsms_notice($mobile,$eventname,$eventtime){
	global $_G,$xjsms;
	
	//���˲����ֻ��ŵ�
	$tmp = explode(',',$mobile);
	foreach($tmp as $key => $value){
		if(ismobilenumber($value) == false){
			unset($tmp[$key]);
		}
	}
	if(count($tmp)<1){
		return 'nomobile';
	}
	$mobile = implode(',',$tmp);
	
	
	$data['username'] = $xjsms['username'];
	$data['password'] = md5($xjsms['password']);
	$data['signature'] = $xjsms['signature'];
	$data['signature'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$data['signature']):$data['signature'];
	$data['mobile'] = $mobile;
	$data['eventname'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$eventname):$eventname;
	$data['eventtime'] = $eventtime;
	$data = json_encode($data);
	$return = postjson('http://xjsms.sinaapp.com/dayu_eventnotice.php',$data);
	
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$mobile = explode(',',$mobile);
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = 'notice';
	$sendlog['sendcount'] = count($mobile);
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $eventname.$eventtime;
	$sendlog['sendnumber'] = count($mobile);
	DB::insert('xj_event_sms_log',$sendlog);
	
	$return = iconv('utf-8','gbk',$return);
	
	return $return;
}


function sendsms_notice_hnmm($mobile,$eventname,$eventtime,$address,$editor,$editorphone){
	global $_G,$xjsms;
	
	//���˲����ֻ��ŵ�
	$tmp = explode(',',$mobile);
	foreach($tmp as $key => $value){
		if(ismobilenumber($value) == false){
			unset($tmp[$key]);
		}
	}
	if(count($tmp)<1){
		return 'nomobile';
	}
	$mobile = implode(',',$tmp);
	
	
	$data['username'] = $xjsms['username'];
	$data['password'] = md5($xjsms['password']);
	$data['signature'] = $xjsms['signature'];
	$data['signature'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$data['signature']):$data['signature'];
	$data['mobile'] = $mobile;
	$data['eventname'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$eventname):$eventname;
	$data['eventtime'] = $eventtime;
	$data['address'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$address):$address;
	$data['editor'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$editor):$editor;
	$data['editorphone'] = $editorphone;
	$data = json_encode($data);
	$return = postjson('http://xjsms.applinzi.com/dayu_eventnotice_hnmm.php',$data);
	
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$mobile = explode(',',$mobile);
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = 'notice';
	$sendlog['sendcount'] = count($mobile);
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $eventname.$eventtime;
	$sendlog['sendnumber'] = count($mobile);
	DB::insert('xj_event_sms_log',$sendlog);
	
	//$return = iconv('utf-8','gbk',$return);
	
	return $return;
}

function sendsms_notice_yhd($mobile,$eventname,$starttime,$address,$tel){
	global $_G,$xjsms;
	
	
	
	//���˲����ֻ��ŵ�
	$tmp = explode(',',$mobile);
	foreach($tmp as $key => $value){
		if(ismobilenumber($value) == false){
			unset($tmp[$key]);
		}
	}
	if(count($tmp)<1){
		return 'nomobile';
	}
	$mobile = implode(',',$tmp);
	
	
	$data['username'] = $xjsms['username'];
	$data['password'] = md5($xjsms['password']);
	$data['signature'] = $xjsms['signature'];
	$data['signature'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$data['signature']):$data['signature'];
	$data['mobile'] = $mobile;
	$data['eventname'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$eventname):$eventname;
	$data['starttime'] = $starttime;
	$data['address'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$address):$address;
	$data['tel'] = $tel;
	$data = json_encode($data);
	$return = postjson('http://xjsms.applinzi.com/dayu_eventnotice_yhd.php',$data);
	
	$sendlog = array();
	if($return == 'ok'){
		$sendlog['sendstate'] = 'success';
	}else{
		$sendlog['sendstate'] = $return;
	}
	$mobile = explode(',',$mobile);
	$sendlog['uid'] = $_G['uid'];
	$sendlog['sendtype'] = 'notice';
	$sendlog['sendcount'] = count($mobile);
	$sendlog['sendtime'] = $_G['timestamp'];
	$sendlog['sendcontent'] = $eventname.$starttime;
	$sendlog['sendnumber'] = count($mobile);
	DB::insert('xj_event_sms_log',$sendlog);
	
	//$return = iconv('utf-8','gbk',$return);
	
	return $return;
}



function postjson($url,$data){
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/json')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}

//�ж��Ƿ��ֻ���
function ismobilenumber($phonenumber){
	if(preg_match("/1[23456789]{1}\d{9}$/",$phonenumber)){  
		return true; 
	}else{  
		return false;  
	}  
}
//From: dis'.'m.tao'.'bao.com
?>