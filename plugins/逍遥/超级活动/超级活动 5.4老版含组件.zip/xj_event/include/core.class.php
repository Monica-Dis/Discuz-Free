<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xj_eventcore
{

    public function IsEventAdmin($tid, $uid)
    {
        global $_G;
        $return = 0;
        $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid WHERE A.tid=$tid");
        $setting = unserialize($items['setting']);
        $member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE uid=$uid");
        if ($member['groupid'] == 1) {
            $return = 1;
        } elseif ($items['authorid'] == $uid) {
            $return = 2;
        } elseif (in_array($member['username'], $setting['event_admin'])) {
            $return = 3;
        }
        return $return;
    }

    public function GetEventPrice($tid, $uid)
    {
        //��ȡ�۸�
        global $_G;

        $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " WHERE tid=$tid");
        $setting = unserialize($items['setting']);
        $price = 0;
        //����Ƕ��ֱ���
        if ($setting['cost']) {
            if ($setting['nodaibaoming']) {
                $apply = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid = $uid");
                $apply['ufielddata'] = unserialize($apply['ufielddata']);
                $price = 0;
                foreach ($setting['cost'] as $value) {
                    $price = $price + $apply['ufielddata']['cost' . $value['id']] * $value['cost_price'];
                }
            } else {
                $apply = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
                $price = 0;
                foreach ($apply as $value) {
                    $value['ufielddata'] = unserialize($value['ufielddata']);
                    $price = $price + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
                }
            }

        } else {
            if ($setting['nodaibaoming']) {
                $applynumber = DB::result_first("SELECT applynumber FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
            } else {
                $applynumber = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
            }
            $price = number_format($items['use_cost'] * $applynumber, 2, '.', '');
        }
        //VIP�ۿ�
        /*
         if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/vip/event_pay.php')) {
         @include DISCUZ_ROOT.'./source/plugin/xj_event/module/vip/event_pay.php';
         }
         */
        return $price;
    }

    public function GetEventApply($tid, $uid)
    {
        //��ȡ��������
        global $_G;
        $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " WHERE tid=$tid");
        $setting = unserialize($items['setting']);
        //����Ƕ��ֱ���
        if ($setting['cost']) {
            $return = array();
            if ($setting['nodaibaoming']) {
                $apply = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid = $uid");
                $apply['ufielddata'] = unserialize($apply['ufielddata']);
                foreach ($setting['cost'] as $value) {
                    $tmp = array();
                    $tmp['cost_number'] = $apply['ufielddata']['cost' . $value['id']];
                    $tmp['cost_name'] = $value['cost_name'];
                    $return[] = $tmp;
                }
            } else {
                $apply = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
                foreach ($apply as $value) {
                    $value['ufielddata'] = unserialize($value['ufielddata']);
                    $tmp = array();
                    $tmp['cost_number'] = 1;
                    $tmp['cost_name'] = $setting['cost'][$value['ufielddata']['costclass']]['cost_name'];
                    $return[] = $tmp;
                }
            }
        } else {
            if ($setting['nodaibaoming']) {
                $applynumber = DB::result_first("SELECT applynumber FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
            } else {
                $applynumber = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
            }
            $return = $applynumber;
        }
        return $return;
    }

    public function GetApplyInfo($tid, $uid)
    {
        //������ϸ��Ϣ
        global $_G;
        $return = array();
        $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " WHERE tid=$tid");
        $setting = unserialize($items['setting']);
        $selectuserfield = unserialize($items['userfield']);
        $sysuserfield = unserialize($_G['setting']['activityfield']);
        if ($setting['nodaibaoming']) {
            $apply = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid = $uid");
            foreach ($apply as $value) {
                $tmp = array();
                $value['ufielddata'] = unserialize($value['ufielddata']);
                foreach ($selectuserfield as $key => $val) {
                    if ($val != 'bmmessage') {
                        $tmp[$key]['title'] = $sysuserfield[$val];
                        $tmp[$key]['value'] = $value['ufielddata'][$val];
                    }
                }
                if ($setting['cost']) {
                    $cost = array();
                    $cost['title'] = lang('plugin/xj_event', 'baomingleixing');
                    foreach ($setting['cost'] as $val) {
                        $cost['value'] .= $val['cost_name'] . 'x' . $value['ufielddata']['cost' . $val['id']] . ' ';
                    }
                    $tmp[] = $cost;
                }
                $return[] = $tmp;
            }
        } else {
            $apply = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid = $uid ORDER BY first DESC");
            foreach ($apply as $value) {
                $tmp = array();
                $value['ufielddata'] = unserialize($value['ufielddata']);
                foreach ($selectuserfield as $key => $val) {
                    if ($val != 'bmmessage') {
                        $tmp[$key]['title'] = $sysuserfield[$val];
                        $tmp[$key]['value'] = $value['ufielddata'][$val];
                    }
                }
                if ($setting['cost']) {
                    $cost = array();
                    $cost['title'] = lang('plugin/xj_event', 'baomingleixing');
                    $cost['value'] = $setting['cost'][$value['ufielddata']['costclass']]['cost_name'];
                    $tmp[] = $cost;
                }
                $return[] = $tmp;
            }
        }
        return $return;
    }

    public function GetYouHui($tid, $uid)
    {
        global $_G;
        $return = 0;
        $items = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " WHERE tid = $tid");
        $eventnumber = $items['event_number'];
        $setting = unserialize($items['setting']);
        $use_cost = $items['use_cost'];
        $item = DB::fetch_first("SELECT applyid,applynumber FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
        //������ʽ��ͬ����������
        if ($setting['nodaibaoming']) {
            $applynumber = $item['applynumber'];
        } else {
            $applynumber = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid = $tid and uid=$uid");
        }
        $apply = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE first=1 AND tid = $tid AND uid=$uid");
        $apply['ufielddata'] = unserialize($apply['ufielddata']);
        //VIP�ۿ�
        $vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
        $_G['groupid'] = DB::result_first("SELECT groupid FROM " . DB::table('common_member') . " WHERE uid = $uid");

        if (in_array($_G['groupid'], $vipgroup)) {
            //�ж��Ƿ���VIP�û���
            //�Żݼ���
            $youhuiprice = 0;
            if ($setting['cost']) {
                //���ö����ʱ
                if ($setting['nodaibaoming']) {
                    //��������������ʱ
                    foreach ($setting['cost'] as $value) {
                        if ($value['cost_youhui'] !== '') {
                            if ($value['cost_youhui'] > 0) {
                                $youhuiprice = $youhuiprice + ($apply['ufielddata']['cost' . $value['id']] * $value['cost_youhui']);
                            }
                        }
                    }
                } else {
                    //������������ʱ
                    $apply_yh = DB::fetch_all("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid = '$tid' and uid=" . $uid);
                    foreach ($apply_yh as $value) {
                        $value['ufielddata'] = unserialize($value['ufielddata']);
                        if ($setting['cost'][$value['ufielddata']['costclass']]['cost_youhui'] !== '') {
                            if ($setting['cost'][$value['ufielddata']['costclass']]['cost_youhui'] > 0) {
                                $youhuiprice = $youhuiprice + $setting['cost'][$value['ufielddata']['costclass']]['cost_youhui'];
                            }
                        }
                    }
                }
            } else {
                //�����ö����ʱ
                if ($setting['vip_discount'] !== '') {
                    if ($setting['vip_discount'] > 0) {
                        $youhuiprice = $setting['vip_discount'] * $applynumber;
                    }
                }
            }
            $return = $youhuiprice;
        }
        return $return;
    }

    public function GetUserField($fields, $values)
    {
        global $_G;
        $return = array();
        $myuserfield = DB::fetch_all("SELECT * FROM " . DB::table('xj_event_field') . " WHERE id in(" . implode(',', $fields) . ") ORDER BY id");
        foreach ($myuserfield as $value) {
            if ($value['formtype'] == 'text') {
                $value['html'] = '<input type="text" class="myuserfield_text" name="' . 'myfield' . $value['id'] . '" value="' . $values['myfield' . $value['id']] . '">';
            }
            if ($value['formtype'] == 'textarea') {
                $value['html'] = '<textarea name="' . 'myfield' . $value['id'] . '" maxlength="100" cols="38" rows="3" class="pt">' . $values['myfield' . $value['id']] . '</textarea>';
            }

            if ($value['formtype'] == 'select') {
                $tmp = explode("\r\n", $value['choices']);
                if ($_G['mobile']) {
                    $value['html'] = '<div class="xjselect"><input type="hidden" name="' . 'myfield' . $value['id'] . '" id="' . 'myfield' . $value['id'] . '" value="' . $values['myfield' . $value['id']] . '">';
                    foreach ($tmp as $tmpkey => $tmpval) {
                        if ($tmpval) {
                            if ($tmpval == $values['myfield' . $value['id']]) {
                                $tmpcolor = '#48bd46';
                            } else {
                                $tmpcolor = '#cccccc';
                            }
                            $value['html'] = $value['html'] . '<span style="background-color:' . $tmpcolor . '; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;font-weight:normal; text-shadow:none;" data-value="' . $tmpval . '">' . $tmpval . '</span>';
                        }
                    }
                    $value['html'] .= '</div><div style="clear:both;"></div>';
                } else {
                    $value['html'] = '<select name="' . 'myfield' . $value['id'] . '">';
                    foreach ($tmp as $tmpkey => $tmpval) {
                        if ($tmpval) {
                            $value['html'] = $value['html'] . '<option value="' . $tmpval . '" ' . ($values['myfield' . $value['id']] == $tmpval ? 'selected' : '') . ' />' . $tmpval . '</option>';
                        }
                    }
                    $value['html'] .= '</select>';
                }

            }
            if ($value['formtype'] == 'uploadfile') {
                $value['html'] = '<div style="background-color:#FFF; border:1px solid #eee; ' . ($_G['mobile'] ? '' : 'margin-left:80px') . '">
      <div class="showimg">' . (!empty($values) ? '<img src="' . $values['myfield' . $value['id']] . '" style="width:100%;">' : '') . '</div>
      <div style="height:160px; text-align:center;' . (!empty($values) ? 'display:none;' : '') . '" class="uploadcover">
        <div style="font-size:56px; color:#e1e1e1; text-align:center; padding-top:60px; line-height:28px;">+<br>
          </div>
      </div>
      <input type="hidden" name="myfield' . $value['id'] . '" value="' . $values['myfield' . $value['id']] . '" class="inputtext">
      <form action="plugin.php?id=xj_event:wsqcenter&mod=event_pub&action=upload&formhash=' . $_G['formhash'] . '" method="post" enctype="multipart/form-data">
      <input class="uploadfile" type="file" data-role="none" data-value="' . $value['id'] . '" name="mypic" style="display:block;position: absolute; margin-top:-160px;width: 300px;height: 160px;opacity: 0;cursor:pointer;">
      </form>
      <div class="bar" style="background-color:#2ace51; width:0px; height:5px; clear:both; margin:0px;"></div>
      <div class="uploaderror" style="padding:0px 10%;"></div>
    </div>
    ';
            }

            $return[] = $value;
        }

        return $return;
    }
    //��ȡ�����������ص�������
    public static function  GetCity($getdata=false){
        global $_G;
        $return = array();
        $return = array_filter(explode("\r\n", $_G['cache']['plugin']['xj_event']['city']));
        if($getdata){
            foreach ($return as $key=>$value){
                $return[$key] = array();
                $return[$key][1] = $value;
                $return[$key][2] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_event')." WHERE citys='".$value."'");
            }
        }
        return $return;
    }

    //��ȡ����࣬�������ϻ����·������� $pc 1������2������  $getdata�Ƿ��ȡ�������ж��ٻ
    public static  function  GetEventClass($pc,$getdata=false){
        global $_G;
        $return = array();
        if($pc==1){  //����
            $tmp = array_filter(explode("\r\n", $_G['cache']['plugin']['xj_event']['event_offline_class']));
            foreach ($tmp as $key => $value) {
                $classarr =  explode("|", $value);
                if($getdata) {
                    $classarr[2] = C::t("#xj_event#xj_event")->count_event(1,$classarr[0]);
                }
                $return[] = $classarr;
            }
        }elseif($pc==2){
            $tmp = array_filter(explode("\r\n", $_G['cache']['plugin']['xj_event']['event_online_class']));
            foreach ($tmp as $key => $value) {
                $classarr =  explode("|", $value);
                if($getdata) {
                    $classarr[2] = C::t("#xj_event#xj_event")->count_event(2,$classarr[0]);
                }
                $return[] = $classarr;
            }
        }
        return array_filter($return);
    }

    //��ȡ���������
    public static  function  GetEventClassName($pc,$classid){
        global $_G;
        $return = '';
        if($pc==1){
            $tmp = array_filter(explode("\r\n", $_G['cache']['plugin']['xj_event']['event_offline_class']));
            foreach ($tmp as $key => $value) {
                $eventclass = explode("|", $value);
                if ($eventclass[0] == $classid) {
                    break;
                }
            }
        }else if($pc == 2){
            $tmp = array_filter(explode("\r\n", $_G['cache']['plugin']['xj_event']['event_online_class']));
            foreach ($tmp as $key => $value) {
                $eventclass = explode("|", $value);
                if ($eventclass[0] == $classid) {
                    break;
                }
            }
        }
        $return = $eventclass[1];
        return $return;
    }

}
