<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



class xj_eventview
{
    public static function event_view($eid,$tid)
    {
        global $_G,$eventcore;
        if(!class_exists($eventcore)){  //�жϺ������Ƿ�����
            //���ú�����
            include_once 'source/plugin/xj_event/include/core.class.php';
            $eventcore = new xj_eventcore();
        }


        $return = array();
        if($eid){
            $return = C::t('#xj_event#xj_event')->fetch_first_event_eid($eid);
        }else{
            $return = C::t('#xj_event#xj_event')->fetch_first_event($tid);
        }
        $return['setting'] = unserialize($return['setting']);
        //��ȡ���������
        if($return['postclass'] == 1){
            $return['classname'] = $eventcore->GetEventClassName($return['postclass'],$return['offlineclass']);
        }else{
            $return['classname'] = $eventcore->GetEventClassName($return['postclass'],$return['onlineclass']);
        }
        //��ȡ��������
        foreach ($_G['setting']['extcredits'] as $key => $value) {
            if ($key == $return['use_extcredits']) {
                $return['extcredit_title'] = $value['title'];
            }
        }
        //��ʾʱ��ת��
        $return['starttime_txt'] = dgmdate($return['starttime'], 'dt');
        $return['endtime_txt'] = dgmdate($return['endtime'], 'dt');
        $return['activitybegin_txt'] = dgmdate($return['activitybegin'], 'dt');
        $return['activityexpiration_txt'] = dgmdate($return['activityexpiration'], 'dt');
        //�����
        if(substr($return['activityaid_url'],0,4)!='data' && substr($return['activityaid_url'],0,4)!='http'){
            $return['activityaid_url'] = 'data/attachment/forum/'.$return['activityaid_url'];
        }
        //��ع�
        $return['huigu'] = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventthread') . " WHERE eid=" . intval($return['eid']) . " and sort=1");
        //����ͨ������
        $return['applynumber_verify'] = C::t("#xj_event#xj_eventapply")->sum_eventapply($tid,1);  //ͨ������
        $return['applynumber_noverify'] = C::t("#xj_event#xj_eventapply")->sum_eventapply($tid,0);  //ûͨ������
        $return['applynumber']=$return['applynumber_noverify']+$return['applynumber_verify'];
        //����ʱ������ѡ�������
        $return['event_number_max'] = $return['event_number_max'] > 0 ? $return['event_number_max'] : 1;
        //��ǰ�û��ı�����Ϣ
        if($_G['uid']){
            $return['my_apply'] = C::t("#xj_event#xj_eventapply")->fetch_first_eventapply($tid,$_G['uid'],1);
        }
        //�ж��ǲ��ǻ�Ĺ����Ŷ�
        $return['is_eventadmin'] = false;
        if ($_G['username']) {
            if (in_array($_G['username'], $return['setting']['event_admin'])) {
                $return['is_eventadmin'] = true;
            }
        }
        //���������
        $return['eventadmin_list'] = implode(',', $return['setting']['event_admin']);
        //�ظ��ſ��Ա���,��ȡ�Լ��������Ļ�����
        if ($return['setting']['reply']) {
            $return['my_replynumber'] = C::t('forum_post')->count_by_tid_invisible_authorid($tid, $_G['uid']);
        }
        //���������������
        if ($_G['cache']['plugin']['xj_event']['event_city']) {
            if ($return['citys']) {
                $upid = intval(DB::result_first("SELECT upid FROM " . DB::table('common_district') . " WHERE name = '" . $return['citys'] . "'"));
                if ($upid) {
                    $return['province'] = DB::result_first("SELECT name FROM " . DB::table('common_district') . " WHERE id = $upid");
                }
            }
        }
        //���ֱ�����VIP�۸����
        if ($return['setting']['vip_discount']) {
            $return['vip_price'] = $return['use_cost'] - $return['setting']['vip_discount'];
        }
        //���ֱ�����VIP�۸����
        foreach($return['setting']['cost'] as $key => $value){
            $return['setting']['cost'][$key]['cost_vip_price'] = $value['cost_price'] - $value['cost_youhui'];
        }
        //�Ƿ��ע΢��
        if ($return['setting']['onlysubscribeweixin'] && $_G['cache']['plugin']['xj_wxmessage']['wxlogin']) { //���޹�ע΢�ű���,��ȡ�Ƿ��ע
            require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
            $xj_wxmessagecore = new xj_wxmessagecore();
            $res         = $xj_wxmessagecore->getweixinuserinfo($_G['uid']);
            $return['weixin_subscribe'] = $res['subscribe'];
        }
        //���Ƶ
        $return['setting']['event_video'] = explode("\r\n",urldecode($return['setting']['event_video']));
        return $return;
    }


}
