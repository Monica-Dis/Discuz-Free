<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xj_eventrelease
{
    public static function event_post($post,$tid,$eid){
        global $_G;
        $tid = intval($tid);
        $eid = intval($eid);

        $items = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE tid = '$tid' AND first=1");
        $pid = $items['pid'];
        if($eid){ //����Ǳ༭�
            //��ȡ��ǰ������
            $event = DB::fetch_first("SELECT setting FROM " . DB::table('xj_event') . " WHERE eid='$eid'");
            $setting = unserialize($event['setting']);
        }else{
            $setting = array();
        }


        $data = array();
        $data['postclass'] = intval($post['postclass']);
        $data['starttime'] = @strtotime($post['starttime']);
        $data['endtime'] = @strtotime($post['endtime']);
        $data['offlineclass'] = intval($post['offlineclass']);
        $data['onlineclass'] =  intval($post['onlineclass']);
        $data['citys'] =  addslashes($post['citys']);
        $data['event_address'] = addslashes($post['event_address']);
        $data['event_number'] = intval($post['event_number']);
        $data['event_number_max'] = intval($post['event_number_max'])>0?intval($post['event_number_max']):1;
        $data['use_extcredits_num'] = intval($post['use_extcredits_num']);
        $data['use_extcredits'] = intval($post['use_extcredits']);
        $data['use_cost'] = floatval($post['use_cost']);
        $data['activityexpiration'] = @strtotime($post['activityexpiration']);
        $data['activitybegin'] = @strtotime($post['activitybegin']);
        $data['eventorder'] = intval($post['eventorder']);
        foreach ($post['userfield'] as $value) {
            $tmp[] = addslashes($value);
        }
        $data['userfield'] = serialize($tmp);
        $setting['event_admin'] = explode(',', $post['event_admin']);
        $setting['noverify'] = intval($post['noverify']);
        $setting['statements'] = intval($post['statements']);
        $setting['eventzy_enable'] = intval($post['eventzy_enable']);
        $setting['eventzy_name'] = addslashes($post['eventzy_name']);
        $setting['eventzy_fid'] = intval($post['eventzy_fid']);
        $setting['eventzy_xz'] = intval($post['eventzy_xz']);
        $setting['eventpay'] = intval($post['eventpay']);
        $setting['eventaa'] = intval($post['eventaa']);
        $setting['seccode'] = intval($post['seccode']);
        $setting['reply'] = intval($post['reply']);
        $setting['nodaibaoming'] = intval($post['nodaibaoming']);
        $setting['success_sms'] = intval($post['success_sms']);
        $setting['vip_discount'] = $post['vip_discount'];
        $setting['app_benefit'] = $post['app_benefit'];
        $setting['event_video'] = urlencode($post['event_video']);
        //APP�����Ż�
        $setting['event_url'] = $post['event_url'];
        //�����
        if ($post['sessionstr']) {
            $tmparray = explode("\r\n", $post['sessionstr']);
            $sessionarray = array();
            foreach ($tmparray as $value) {
                $tmpvalue = explode("=", $value);
                $sessionarray[$tmpvalue[0]] = $tmpvalue[1];
            }
            $setting['session'] = $sessionarray;
        }else{
            $setting['session'] = null;
        }
        //����ѡ��
        if($eid){
            $setting['moreitem'] = array();
        }
        foreach ($post['setting_itemname'] as $key => $value) {
            $tmparray = array();
            if ($value) {
                $tmparray['itemname'] = addslashes($value);
                $tmparray['itemcontent'] = addslashes($post['setting_itemcontent'][$key]);
                $setting['moreitem'][] = $tmparray;
            }
        }
        //���ֱ�������
        $setting['cost'] = array();
        $i = 1;
        foreach ($post['cost_price'] as $key => $value) {
            $value = floatval($value);
            if ($post['cost_name'][$key]) {
                $setting['cost'][$i]['cost_name'] = $post['cost_name'][$key];
                $setting['cost'][$i]['cost_price'] = $post['cost_price'][$key];
                $setting['cost'][$i]['cost_credits'] = $post['cost_credits'][$key];
                $setting['cost'][$i]['cost_youhui'] = $post['cost_youhui'][$key];
                $setting['cost'][$i]['id'] = $i;
            }
            $i++;
        }
        //���ϵ�绰
        $setting['tel'] = addslashes($post['tel']);
        //�±����ֶ�
        $setting['myuserfield'] = $post['myuserfield'];

        $data['setting'] = serialize($setting);

        /*
        if ($_GET['activityaid']) {
            $data['activityaid'] = intval($post['activityaid']);
            convertunusedattach($data['activityaid'], $tid, $pid);
            $data['activityaid_url'] = addslashes($post['activityaid_url']);
        }
        */
        $data['activityaid_url'] = addslashes($post['activityaid_url']);
        $data['activityaid'] = intval($post['activityaid']);

        if($eid){
            //�ͼƬ�༭����
            $activity = DB::fetch(DB::query("SELECT activityaid FROM " . DB::table('xj_event') . " WHERE tid = $tid"));
            $activityaid = $activity['activityaid'];
            if ($activityaid && $activityaid != $_GET['activityaid']) {
                $attach = C::t('forum_attachment_n') -> fetch('tid:' . $_G['tid'], $activityaid);
                C::t('forum_attachment') -> delete($activityaid);
                C::t('forum_attachment_n') -> delete('tid:' . $_G['tid'], $activityaid);
                dunlink($attach);
            }
            DB::update("xj_event",$data,"eid=$eid");
        }else{
            $data['tid'] = $tid;
            DB::insert("xj_event",$data);
        }

    }
}
