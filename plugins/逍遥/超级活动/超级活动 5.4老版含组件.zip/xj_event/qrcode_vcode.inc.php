<?php

$tid = intval($_GET['tid']);
$seccode = $_GET['seccode'];
require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
//dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP + 86400).' GMT');
//$qrsize = !empty($_GET['qrsize']) ? $_GET['qrsize'] : 3;
$dir = DISCUZ_ROOT.'./data/cache/qrcode/';
$file = $dir.'xj_event_v_'.$seccode.'_'.$tid.'.jpg';
//$url = str_replace("/source/plugin/xj_scoupon/","",$_G['siteurl']);
$validationurl = WeChatHook::getPluginUrl('xj_event:wsq_join_validation', $param = array('tid'=>$tid,'seccode'=>$seccode));

if(!file_exists($file) || !filesize($file)) {
	dmkdir($dir);
	require_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
	QRcode::png($validationurl, $file, QR_ECLEVEL_Q, 3);
}
dheader('Content-Disposition: inline; filename=qrcode_index.jpg');
dheader('Content-Type: image/pjpeg');
@readfile($file);
?>