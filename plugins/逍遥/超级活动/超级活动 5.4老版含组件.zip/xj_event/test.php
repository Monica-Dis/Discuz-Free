<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEDEFENSE', true);
define('DISABLEXSSCHECK', true);
require_once('../../../source/class/class_core.php');
require_once('../../../source/function/function_home.php');

$cachelist = array();
$discuz = C::app();

$discuz->cachelist = $cachelist;
$discuz->init_cron = false;
$discuz->init_setting = true;
$discuz->init_user = false;
$discuz->init_session = false;

$discuz->init();


include template('xj_event:wxpay');
?>