<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require 'include/email.class.php';
$mailto='77073580@qq.com';
$mailsubject="测试邮件";
$mailbody='这里是邮件内容';
$smtpserver     = "smtpdm.aliyun.com";
$smtpserverport = 25;
$smtpusermail   = "web@mail.xiaoyaoapp.cn";
$smtpuser       = "web@mail.xiaoyaoapp.cn";
$smtppass       = "AdJj77ww87446";
$mailsubject    = "=?UTF-8?B?" . base64_encode($mailsubject) . "?=";
$mailtype       = "HTML";
$smtp           = new smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass);
$smtp->debug    = false;
$smtp->sendmail($mailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);



?>