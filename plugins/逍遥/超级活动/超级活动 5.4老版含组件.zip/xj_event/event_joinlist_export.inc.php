<?php
/**
 *    [�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();



$filename = date('Ymd', TIMESTAMP) . '.csv';
header('Content-Encoding: none');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename=' . $filename);
header('Pragma: no-cache');
header('Expires: 0');




//ǩ��
if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/signed/wsq_signed.php')) {
    $signed_enable = true;
}

include DISCUZ_ROOT . './source/plugin/xj_event/include/func.php';
$tid = intval($_GET['tid']);

//Ȩ������
$thread  = DB::fetch_first("SELECT authorid,userfield,setting FROM " . DB::table('forum_thread') . " A," . DB::table('xj_event') . " B WHERE A.tid='$tid' and A.tid = B.tid");
$setting = unserialize($thread['setting']);
if ($_G['groupid'] > 1 && $_G['uid'] != $thread['authorid']) {
    showmessage('quickclear_noperm');
}

//������ֶ�
$selectuserfield = unserialize($thread['userfield']);
$sysuserfield    = unserialize($_G['setting']['activityfield']);
//�µı����ֶ�
if($setting['myuserfield']){
	$myuserfield = $eventcore->GetUserField($setting['myuserfield']);
}




$query = DB::query("SELECT B.username,A.* FROM " . DB::table('xj_eventapply') . " A," . DB::table('common_member') . " B WHERE A.uid = B.uid and A.tid = '$tid' ORDER BY A.verify,A.dateline DESC,A.first DESC");
require_once libfile('function/profile');
loadcache('profilesetting');
$i = 1;

$detail = lang('plugin/xj_event', 'xuhao') . "," . lang('plugin/xj_event', 'yonghuming') . ",";
if ($setting['session']) {
    $detail = $detail . lang('plugin/xj_event', 'huodongcc') . ",";
}

foreach ($selectuserfield as $val) {
    if ($sysuserfield[$val]) {
        $detail = $detail . $sysuserfield[$val] . ",";
    }
}

foreach($myuserfield as $val){
	$detail = $detail . $val['title'] . ",";
}


$detail = $detail . lang('plugin/xj_event', 'baomingrs') . ",";
//���ַ��ñ�������

if ($setting['cost']) {
    if ($setting['nodaibaoming']) {
        foreach ($setting['cost'] as $value) {
            $detail = $detail . $value['cost_name'] . ",";
        }
    } else {
        $detail .= lang('plugin/xj_event', 'leixin') . ",";
    }
}
$detail = $detail . 'message' . ",";
if ($setting['eventpay']) {
    $detail .= lang('plugin/xj_event', 'zhifufy') . "," . lang('plugin/xj_event', 'zhifuleixing') . "," . lang('plugin/xj_event', 'zhifufy') . ",";
}

//��֤��
if ($setting['seccode']) {
    $detail .= lang('plugin/xj_event', 'yanzhenma') . ',' . lang('plugin/xj_event', 'yzmzt') . ',' . lang('plugin/xj_event', 'yanzsj') . ',';
}

$detail .= lang('plugin/xj_event', 'shenhe') . "," . lang('plugin/xj_event', 'baomingsj') . "," . lang('plugin/xj_event', 'qiandsj') . "\n";

while ($value = DB::fetch($query)) {
    $value['No']       = $i;
    $value['dateline'] = date('Y-m-d H:i:s', $value['dateline']);

    $detail = $detail . $value['No'] . "," . ($value['first'] ? $value['username'] : '') . ",";

    if ($setting['session']) {
        $detail = $detail . $setting['session'][$value['session']] . ",";
    }

    $value['ufielddata'] = unserialize($value['ufielddata']);
    $data                = '';

    foreach ($selectuserfield as $val) {
        if ($sysuserfield[$val]) {
            $data = profile_show($val, $value['ufielddata']);
            if ($_G['cache']['profilesetting'][$val]['formtype'] == 'file') {
                $data = '<a href="' . $data . '" target="_blank" onclick="zoom(this, this.href, 0, 0, 0); return false;">' . lang('forum/misc', 'activity_viewimg') . '</a>';
            }
            if ($val == 'birthday') {
                $data = $value['ufielddata'][$val];
            }
            if ($val == 'qq') {
                $data = $value['ufielddata'][$val];
            }
            $data   = str_replace("\r", '', $data);
            $data   = str_replace("\n", '', $data);
            $detail = $detail . "\t" . str_replace(',', ' ', $data) . ",";
        }
    }


	foreach($myuserfield as $val){
		$data = $value['ufielddata']['myfield'.$val['id']];
        $data   = str_replace("\r", '', $data);
        $data   = str_replace("\n", '', $data);
        $detail = $detail . "\t" . str_replace(',', ' ', $data) . ",";
	}
    /*
    $ufielddata = array();
    foreach($value['ufielddata'] as $key => $fieldid) {
    $data = profile_show($key, $value['ufielddata']);
    if($_G['cache']['profilesetting'][$key]['formtype'] == 'file') {
    $data = '<a href="'.$data.'" target="_blank" onclick="zoom(this, this.href, 0, 0, 0); return false;">'.lang('forum/misc', 'activity_viewimg').'</a>';
    }
    if($key=='birthday'){
    $data = $fieldid;
    }
    if($key=='qq'){
    $data = $fieldid;
    }
    $ufielddata[$key]['value'] = $data;
    $value[$key] = str_replace(',',' ',$data);
    $data = str_replace("\r",'',$data);
    $data = str_replace("\n",'',$data);
    $detail = $detail."\t".str_replace(',',' ',$data).",";
    }
     */
    //print_r($ufielddata);
    //$value['ufielddata'] = $ufielddata;

    $detail = $detail . $value['applynumber'] . ",";
    //���ַ��ñ�������

    foreach ($setting['cost'] as $costvalue) {
        $value['cost' . $costvalue['id']] = $value['ufielddata']['cost' . $costvalue['id']];
    }
    $value['costclass'] = $value['ufielddata']['costclass'];

    if ($setting['cost']) {
        if ($setting['nodaibaoming']) {
            foreach ($setting['cost'] as $cvalue) {
                $detail = $detail . $value['ufielddata']['cost' . $cvalue['id']] . ",";
            }
        } else {
            $detail .= $setting['cost'][$value['costclass']]['cost_name'] . ",";
        }
    }
    $detail = $detail . $value['bmmessage'] . ",";
    //֧�����
    if ($setting['eventpay']) {
        if ($value['pay_state'] == 1) {
            $detail .= lang('plugin/xj_event', 'yizhifu') . ",";
        } else {
            $detail .= lang('plugin/xj_event', 'weizhifu') . ",";
        }

        $paylog = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventpay_log') . " WHERE applyid=" . $value['applyid'] . " ORDER BY create_time DESC");
        $detail .= $paylog['paytype'] . "," . $paylog['total_fee'] . ",";
    }

    //��֤��
    if ($setting['seccode']) {
        $detail .= $value['seccode'] . ',';
        if ($value['secstate']) {
            $detail .= lang('plugin/xj_event', 'yiyanzhen') . ',';
        } else {
            $detail .= ',';
        }
        $detail .= dgmdate($value['sectime']) . ',';

    }

    if ($value['verify'] == 1) {
        $detail = $detail . lang('plugin/xj_event', 'yishenhe') . ",";
    } else {
        $detail = $detail . lang('plugin/xj_event', 'weishenhe') . ",";
    }
    $detail = $detail . $value['dateline'];
    //ǩ��
    if ($signed_enable) {
        $signed = DB::fetch_first("SELECT * FROM " . DB::table('xj_event_signed') . " WHERE tid='$tid' AND uid=" . $value['uid']);
        if ($signed) {
            $value['signed_dateline'] = $signed['dateline'] ? dgmdate($signed['dateline']) : '';
        }
        $detail = $detail . "," . $value['signed_dateline'];
    }

    $detail = $detail . "\n";
    $i++;
}

if ($_G['charset'] != 'gbk') {
    $detail = diconv($detail, $_G['charset'], 'GBK');
}

echo $detail;
exit();
