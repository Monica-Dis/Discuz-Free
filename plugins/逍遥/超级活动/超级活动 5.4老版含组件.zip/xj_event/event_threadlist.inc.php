<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$eid = intval($_GET['eid']);
$fid = intval($_GET['fid']);
$perpage = 10; //ÿҳ��


$eventinfo = DB::fetch_first("SELECT tid,setting FROM ".DB::table('xj_event')." WHERE eid=$eid");
$tid = $eventinfo['tid'];
$setting = unserialize($eventinfo['setting']);
$nowtime = time();


$myapply = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE eid=$eid AND uid=$_G[uid] AND verify=1");
$applynumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE eid=$eid");
$listcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid = B.tid and A.eid = $eid AND B.displayorder>=0");
$page = $_GET['page']?$_GET['page']:1;
if(@ceil($listcount/$perpage) < $page) {
	$page = 1;
}
$start_limit = ($page - 1) * $perpage;
$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:event_threadlist&eid=$eid&order=".$_GET['order'],0,10,false,true);
$multipage = str_replace('class="pg"','class="jlpg"',$multipage);

$sqlorder = 'B.lastpost DESC';
if($_GET['order']=='tp'){
	$sqlorder = 'A.votes DESC';
}elseif($_GET['order']=='dj'){
	$sqlorder = 'B.views DESC';
}elseif($_GET['order']=='hf'){
	$sqlorder = 'B.replies DESC';
}elseif($_GET['order']=='sj'){
	$sqlorder = 'B.dateline DESC';
}

$query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid = B.tid and A.eid = '$eid' AND B.displayorder>=0 ORDER BY ".$sqlorder." LIMIT $start_limit,$perpage");
$threadlist = array();
while($value = DB::fetch($query)){
	$value['avatar'] = '<img src="'.avatar($value[authorid], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" />';
	$value['strdateline'] = dgmdate($value['dateline'],'dt');
	$threadlist[] = $value;
}



include template('xj_event:threadlist');

?>