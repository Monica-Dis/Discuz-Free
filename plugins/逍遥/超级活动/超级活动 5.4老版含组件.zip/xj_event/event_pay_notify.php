<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: notify_credit.php 29236 2012-03-30 05:34:47Z chenmengshu $
 */
define('IN_API', true);
define('CURSCRIPT', 'api');





require '../../../source/class/class_core.php';
require '../../../source/function/function_forum.php';
include 'include/sms_func.php';

$discuz = C::app();
$discuz->init();



$apitype = empty($_GET['attach']) || !preg_match('/^[a-z0-9]+$/i', $_GET['attach']) ? 'alipay' : $_GET['attach'];
//$_G['siteurl'] = dhtmlspecialchars('http://'.$_SERVER['HTTP_HOST'].preg_replace("/\/+(source\/plugin\/xj_event)?\/*$/i", '', substr($PHP_SELF, 0, strrpos($PHP_SELF, '/'))).'/');
//$PHP_SELF = $_SERVER['PHP_SELF'];
$_G['siteurl'] = str_replace('source/plugin/xj_event/','',$_G['siteurl']);




if($apitype == 'alipay'){
	list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
	define('DISCUZ_PARTNER', $ec_partner);
	define('DISCUZ_SECURITYCODE', $ec_securitycode);
	define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
	
	
	$notifydata = alipay_notifycheck();
	$orderid = $notifydata['order_no'];
	$tradeno = $notifydata['trade_no'];
	$trade_status = $notifydata['trade_status'];
	$notify_time = $_G['timestamp'];
	if($notifydata['trade_status'] == 'WAIT_BUYER_PAY'){   //等待支付
		$buyer_email = $_GET['buyer_email'];
		DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET paystate=1, trade_status='$trade_status', tradeno='$tradeno', buyer_email='$buyer_email', notify_time=$notify_time  WHERE orderid = '$orderid'");
	}elseif($notifydata['trade_status'] == 'WAIT_SELLER_SEND_GOODS'){         //买家已付款，等待发货
		$pay_time = $_G['timestamp'];
		DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET paystate=2, trade_status='$trade_status', pay_time=$pay_time, notify_time=$notify_time WHERE orderid = '$orderid'");
		$item = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE orderid = '$orderid'");
		$tid = $item['tid'];
		$uid = $item['uid'];
		DB::query("UPDATE ".DB::table('xj_eventapply')." SET pay_state=1 WHERE tid = $tid AND uid = $uid");
	}elseif($notifydata['trade_status'] == 'WAIT_BUYER_CONFIRM_GOODS'){
		DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET trade_status='$trade_status', notify_time=$notify_time WHERE orderid = '$orderid'");
	}elseif($notifydata['trade_status'] == 'TRADE_FINISHED' || $notifydata['trade_status'] == 'TRADE_SUCCESS'){
		$item = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventpay_log')." WHERE orderid = '$orderid'");
		if($item['paystate']<3){		
			DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET paystate=3, trade_status='$trade_status', notify_time=$notify_time WHERE orderid = '$orderid'");
			$item = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE orderid = '$orderid'");
			$tid = $item['tid'];
			$uid = $item['uid'];
			DB::query("UPDATE ".DB::table('xj_eventapply')." SET pay_state=1,verify=1 WHERE tid = $tid AND uid = $uid");
			if(!$notifydata['location']){
				paysmssend($tid,$uid);
			}
			
			//邀请的奖励处理
			$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
			$setting = unserialize($items['setting']);
			if($setting['yqjl_jfs']>0){
				$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = ".$item['applyid']);
				if($apply['fromuid'] > 0){
					$applynumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$tid." AND uid=".$uid);	
					$yqjl = array();
					$yqjl['tid'] = $tid;
					$yqjl['fromuid'] = $apply['fromuid'];
					$yqjl['applyuid'] = $uid;
					$yqjl['jfs'] = $setting['yqjl_jfs']*$applynumber;
					$yqjl['jflx'] = $setting['yqjl_jflx'];
					$yqjl['dateline'] = $_G['timestamp'];
					DB::insert('xj_event_yqjl_log',$yqjl);
					updatemembercount($yqjl['fromuid'],array($yqjl['jflx']=>+$yqjl['jfs']));
					
					$username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=$uid");
					$eventtitle = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid = $tid");
					notification_add($yqjl['fromuid'],'system',$username.lang('plugin/xj_event','beiniyaoqinbaomincanjiale').' <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$eventtitle.'</a> '.lang('plugin/xj_event','huodonghuode').$yqjl['jfs'].$_G['setting']['extcredits'][$yqjl['jflx']]['title'].lang('plugin/xj_event','jiangli'));
				}
			}
			//通知
			$username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=$uid");
			if($_G['charset']=='gbk'){
				notification_add($items['authorid'], 'system', $username.diconv('报名参加了你的活动','UTF-8','GBK').' <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$items['subject'].'</a> '.diconv('并已支付活动费用','UTF-8','GBK'),array(),0);
			}else{
				notification_add($items['authorid'], 'system', $username.'报名参加了你的活动 <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$items['subject'].'</a> 并已支付活动费用',array(),0);
			}
            //微信消息
            loadcache('plugin');
            if($_G['cache']['plugin']['xj_wxmessage']['wxlogin']){
                require_once DISCUZ_ROOT . './source/plugin/xj_wxmessage/class/core.class.php';
                $xj_wxmessagecore = new xj_wxmessagecore();
	//调试记录开始
	$log_name="./alipay.txt";//log文件路径
	log_result($log_name,"【接收到的notify通知】:\r\n".$item['applyid'].'|'.$items['authorid']."\r\n【返回的信息】:\r\n");
	//调试记录结束
                $xj_wxmessagecore->send_eventmessage($uid,$tid,1);
                $xj_wxmessagecore->send_eventapplymessage($item['applyid'],$items['authorid'],2);
            }
            //新短信消息
            if($_G['cache']['plugin']['xj_dxmessage']['enable']){
            	$eventapply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = ".$item['applyid']);
                require_once DISCUZ_ROOT . './source/plugin/xj_dxmessage/class/core.class.php';
                $xj_dxmessagecore = new xj_dxmessagecore();
                $other = array();
                $other['applyid'] = $item['applyid'];
                $other['uid'] = $uid;
                $xj_dxmessagecore->sendsms($eventapply['mobile'],1,$other);  //报名成功发送通知短信
                if($setting['seccode'] == 1){ 
                   $other = array();
                   $other['applyid'] = $item['applyid'];
                   $other['uid'] = $items['authorid'];
                   $other['verifycode'] = $eventapply['seccode'];
                   $xj_dxmessagecore->sendsms($eventapply['mobile'],2,$other);  //报名成功发送验证码短信
                }
            }



		}
		
	}elseif($notifydata['trade_status'] == 'TRADE_CLOSED'){
		DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET paystate=9, trade_status='$trade_status', notify_time=$notify_time WHERE orderid = '$orderid'");
	}
}elseif($apitype == 'tenpay'){
	
	define('DISCUZ_PARTNER', $_G['setting']['ec_tenpay_bargainor']);
	define('DISCUZ_SECURITYCODE', $_G['setting']['ec_tenpay_key']);
	define('DISCUZ_AGENTID', '1204737401');
	define('DISCUZ_TENPAY_OPENTRANS_CHNID', $_G['setting']['ec_tenpay_opentrans_chnid']);
	define('DISCUZ_TENPAY_OPENTRANS_KEY', $_G['setting']['ec_tenpay_opentrans_key']);
	require '../../../api/trade/api_tenpay.php';
	
	$notifydata = tenpay_notifycheck();
	$orderid = $notifydata['order_no'];
	$tradeno = $notifydata['trade_no'];
	$trade_status = $notifydata['trade_status'];
	$notify_time = $_G['timestamp'];
	if($orderid){
	  if($trade_status == 0){
		  $trade_status = intval($trade_status);
		  DB::query("UPDATE ".DB::table('xj_eventpay_log')." SET paystate=3, trade_status='$trade_status',tradeno=$tradeno,notify_time=$notify_time WHERE orderid = '$orderid'");
		  $item = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE orderid = '$orderid'");
		  $tid = $item['tid'];
		  $uid = $item['uid'];
		  DB::query("UPDATE ".DB::table('xj_eventapply')." SET pay_state=1,verify=1 WHERE tid = $tid AND uid = $uid");
		  paysmssend($tid,$uid);
		  
		  
		  //邀请的奖励处理
		  $items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid = $tid");
		  $setting = unserialize($items['setting']);
		  if($setting['yqjl_jfs']>0){
			  $apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = ".$item['applyid']);
			  $applynumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$tid." AND uid=".$uid);	
			  $yqjl = array();
			  $yqjl['tid'] = $tid;
			  $yqjl['fromuid'] = $apply['fromuid'];
			  $yqjl['applyuid'] = $uid;
			  $yqjl['jfs'] = $setting['yqjl_jfs']*$applynumber;
			  $yqjl['jflx'] = $setting['yqjl_jflx'];
			  $yqjl['dateline'] = $_G['timestamp'];
			  DB::insert('xj_event_yqjl_log',$yqjl);
			  updatemembercount($yqjl['fromuid'],array($yqjl['jflx']=>+$yqjl['jfs']));
			  $username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=$uid");
			  $eventtitle = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid = $tid");
			  notification_add($yqjl['fromuid'],'system',$username.lang('plugin/xj_event','beiniyaoqinbaomincanjiale').' <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$eventtitle.'</a> '.lang('plugin/xj_event','huodonghuode').$yqjl['jfs'].$_G['setting']['extcredits'][$yqjl['jflx']]['title'].lang('plugin/xj_event','jiangli'));
		  }
	  }
	}
	
}

function paysmssend($tid,$uid){
	global $_G;
	//调试记录开始
	//$log_name="./alipay.txt";//log文件路径
	//log_result($log_name,"【接收到的notify通知】:\r\n".$xml."\r\n【返回的信息】:\r\n");
	//调试记录结束
	
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=$uid");
	$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid=$tid and A.tid = B.tid");
	$setting = unserialize($thread['setting']);
	$event_starttime = dgmdate($thread['starttime'],'dt');
	if($setting['seccode'] == 1){		
		$message = cutstr($thread['subject'],30).'活动报名成功，人数:'.$apply['applynumber'].'人 验证码:'.$apply['seccode'].' 活动时间:'.$event_starttime;
		$sendtype = '报名验证码短信';
		if($_G[charset]=='gbk'){
			$message = diconv($message,'UTF-8','GBK');
			$sendtype = diconv($sendtype,'UTF-8','GBK');
		}
		sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
		//xjsendsms(array($apply['mobile']),$message,$sendtype);
		sendpm($apply['uid'],'',$message,$thread['authorid']);
	}elseif($setting['success_sms'] == 1){
		sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
		//易活动短信
		//$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
		//$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
		//sendsms_notice_yhd($apply['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);
	}
}



//调试记录开始
/*
$notifydatastr = print_r($notifydata,true)."-------------------notifydata  \r\n";
$notifydatastr = $notifydatastr.print_r($_GET,true)."---------GET \r\n";
$notifydatastr = $notifydatastr.print_r($_POST,true)."---------POST \r\n\r\n\r\n";
$notifydatastr = $notifydatastr.DISCUZ_PARTNER.'|'.DISCUZ_SECURITYCODE."---------常量 \r\n\r\n\r\n";;
$filename = "./pay.txt";
$fp = fopen("$filename", "a"); //打开文件指针，创建文件
fwrite($fp, $notifydatastr);
fclose($fp); //关闭指针
*/
//调试记录结束





if($notifydata['location']) {
	$url = rawurlencode('home.php?mod=spacecp&ac=credit');
	if($apitype == 'tenpay') {
		echo <<<EOS
<meta name="TENCENT_ONLINE_PAYMENT" content="China TENCENT">
<html>
<body>
<script language="javascript" type="text/javascript">
window.location.href='$_G[siteurl]plugin.php?id=xj_event:event_pay&action=paysucceed';
</script>
</body>
</html>
EOS;
	} else {
    	$orderid = $notifydata['order_no'];
    	$item = DB::fetch_first("SELECT applyid,uid,tid FROM ".DB::table('xj_eventpay_log')." WHERE orderid = '$orderid'");
		$tid = $item['tid'];
		dheader('location: '.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=join_success&tid='.$tid);
	}
} else {
	exit($notifydata['notify']);
}


function alipay_notifycheck() {
	global $_G;
	if(!empty($_POST)) {
		$notify = $_POST;
		$location = FALSE;
	} elseif(!empty($_GET)) {
		$notify = $_GET;
		$location = TRUE;
	} else {
		exit('Access Denied');
	}
	

	if(dfsockopen("http://notify.alipay.com/trade/notify_query.do?partner=".DISCUZ_PARTNER."&notify_id=".$notify['notify_id'], 60) !== 'true') {
		exit('Access Denied');
	}

	
	if(!DISCUZ_SECURITYCODE) {
		exit('Access Denied');
	}
	ksort($notify);
	$sign = '';
	foreach($notify as $key => $val) {
		if($key != 'sign' && $key != 'sign_type') $sign .= "&$key=$val";
	}
	if($notify['sign'] != md5(substr($sign,1).DISCUZ_SECURITYCODE)) {
		exit('Access Denied');
	}
	return array(
    	'order_no' 	=> $notify['out_trade_no'],
        'trade_no'	=> $notify['trade_no'],
        'trade_status' 	=> $notify['trade_status'],
        'price' 	=> $notify['total_fee'],
		'notify'	=> 'success',
		'location'	=> $location
	);
	/*
	if(($type == 'credit' || $type == 'invite') && (!DISCUZ_DIRECTPAY && $notify['notify_type'] == 'trade_status_sync' && ($notify['trade_status'] == 'WAIT_SELLER_SEND_GOODS' || $notify['trade_status'] == 'TRADE_FINISHED') || DISCUZ_DIRECTPAY && ($notify['trade_status'] == 'TRADE_FINISHED' || $notify['trade_status'] == 'TRADE_SUCCESS'))
		|| $type == 'trade' && $notify['notify_type'] == 'trade_status_sync') {
		return array(
			'validator'	=> TRUE,
			'status' 	=> trade_getstatus(!empty($notify['refund_status']) ? $notify['refund_status'] : $notify['trade_status'], 1),
			'order_no' 	=> $notify['out_trade_no'],
			'price' 	=> !DISCUZ_DIRECTPAY && $notify['price'] ? $notify['price'] : $notify['total_fee'],
			'trade_no'	=> $notify['trade_no'],
			'notify'	=> 'success',
			'location'	=> $location
			);
	} else {
		return array(
			'validator'	=> FALSE,
			'notify'	=> 'fail',
			'location'	=> $location
			);
	}
	*/
}

function tenpay_notifycheck() {
	global $_G;



    if(!DISCUZ_SECURITYCODE) {
        exit('Access Denied');
    }
    
   
    $resHandler = new ResponseHandler();
    $resHandler->setKey(DISCUZ_SECURITYCODE);
    $resHandler->setParameter("bankname", "");
    if($resHandler->isTenpaySign() && DISCUZ_PARTNER == $_GET['partner']) {
        return array(
            'validator'	=> isset($_GET['trade_state']) ? !$_GET['trade_state'] : 0,
            'trade_state' => $_GET['trade_state'],
            'order_no' 	=> $_GET['out_trade_no'],
            'trade_no'	=> isset($_GET['transaction_id']) ? $_GET['transaction_id'] : '',
            'price' 	=> $_GET['total_fee'] / 100,
            'bargainor_id' => $_GET['partner'],
            'notify'	=> 'Success',
            'location'	=> false,
            );
    }
}





// 打印log
function  log_result($file,$word) 
{
	$fp = fopen($file,"a");
	flock($fp, LOCK_EX) ;
	fwrite($fp,"执行日期：".strftime("%Y-%m-%d-%H：%M：%S",time())."\n".$word."\n\n");
	flock($fp, LOCK_UN);
	fclose($fp);
}
//From: Dism·taobao·com
?>