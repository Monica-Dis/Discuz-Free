<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if($_GET['act'] == 'save'){
	if($_GET['formhash'] != $_G['formhash']) {
		cpmsg('parameters_error','action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_wxpay','succeed');
	}
	$wxset = array();
	$wxset['appid'] = addslashes($_GET['appid']);
	$wxset['appsecret'] = addslashes($_GET['appsecret']);
	$wxset['apikey'] = addslashes($_GET['apikey']);
	$wxset['mch_id'] = addslashes($_GET['mch_id']);
	$wxset['wsqonly'] = intval($_GET['wsqonly']);
	$wxset['open_appid'] = addslashes($_GET['open_appid']);
	$wxset['open_mch_id'] = addslashes($_GET['open_mch_id']);
	$wxset['open_apikey'] = addslashes($_GET['open_apikey']);
	$wxset['xcx_appid'] = addslashes($_GET['xcx_appid']);
	$wxset['xcx_appsecret'] = addslashes($_GET['xcx_appsecret']);
	$wxset['xcx_mch_id'] = addslashes($_GET['xcx_mch_id']);
	$wxset['xcx_apikey'] = addslashes($_GET['xcx_apikey']);
	$wxset['magapp_secret'] = addslashes($_GET['magapp_secret']);
	$wxset['magapp_siteurl'] = addslashes($_GET['magapp_siteurl']);
	$wxset['qianfan_type'] = addslashes($_GET['qianfan_type']);
	
	writetocache('xj_event_wxset',getcachevars(array('wxset'=>$wxset)));
	$message = lang('plugin/xj_event', 'bccg');
	
	cpmsg($message,'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_wxpay','succeed');
}

if($_GET['act'] == 'clear'){
	//����΢��֧������
	if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
		@include $xj_event_wxset;
	}
	@include DISCUZ_ROOT.'source/plugin/xj_event/module/wxopen/include/wxpayfunc.php';
	require_once libfile('function/cache');
	//С����
	loadcache('wxxcx_token');
	$cx = get('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$wxset['xcx_appid'].'&secret='.$wxset['xcx_appsecret']);
	$token = json_decode($cx,true) ;
	$token['timestamp'] = $_G['timestamp'];
	savecache('wxxcx_token',$token);

	DB::delete('xj_wxopen_login',"uid=0");

	cpmsg(lang('plugin/xj_event','caozuochenggong'),'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_wxpay','succeed');
}



if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}


showformheader('plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_wxpay&act=save');
showtableheader(lang('plugin/xj_event','wxzfszqgj').' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_wxpay&act=clear" style=" border-radius:3px; padding:3px 10px; background-color:#44a1e2;color:#fff;">'.lang('plugin/xj_event','genxinhuanchun').'</a>');
showsetting(lang('plugin/xj_event', 'wxgahappid'), 'appid', $wxset['appid'], 'text');
showsetting('AppSecret', 'appsecret', $wxset['appsecret'], 'text');
showsetting('APIKEY', 'apikey', $wxset['apikey'], 'text');
showsetting(lang('plugin/xj_event','wxzfshh'), 'mch_id', $wxset['mch_id'], 'text');
showsetting(lang('plugin/xj_event','wsqzxswxzf'), 'wsqonly', $wxset['wsqonly'], 'radio');
showsetting(lang('plugin/xj_event', 'appwxkfpdappid'), 'open_appid', $wxset['open_appid'], 'text');
showsetting(lang('plugin/xj_event', 'appwxzfshh'), 'open_mch_id', $wxset['open_mch_id'], 'text');
showsetting(lang('plugin/xj_event', 'appwxzfapikey'), 'open_apikey', $wxset['open_apikey'], 'text');
showsetting(lang('plugin/xj_event','xcxappid'), 'xcx_appid', $wxset['xcx_appid'], 'text');
showsetting(lang('plugin/xj_event','xcxappsecret'), 'xcx_appsecret', $wxset['xcx_appsecret'], 'text');
showsetting(lang('plugin/xj_event','xcxwxzfshh'), 'xcx_mch_id', $wxset['xcx_mch_id'], 'text');
showsetting(lang('plugin/xj_event','xcxapikey'), 'xcx_apikey', $wxset['xcx_apikey'], 'text');
showtableheader(lang('plugin/xj_event','majiaapzfsz'));
showsetting(lang('plugin/xj_event','majiayinyongsecret'), 'magapp_secret', $wxset['magapp_secret'], 'text');
showsetting(lang('plugin/xj_event','majiaappyunming'),'magapp_siteurl', $wxset['magapp_siteurl'], 'text');
showtableheader(lang('plugin/xj_card','qianfanappzfsz'));
showsetting(lang('plugin/xj_card','qianfanappddlx'),'qianfan_type', $wxset['qianfan_type'], 'text');
showsubmit('submit',lang('plugin/xj_event', 'save'));
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
showformfooter(); /*dism��taobao��com*/


?>