<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}


$applyid = intval($_GET['applyid']);
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid = $applyid and uid=".$_G['uid']);
$tid = $apply['tid'];

$items = DB::fetch_first("SELECT A.*,B.subject FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid = $tid and A.tid=B.tid");
$setting = unserialize($items['setting']);
$extcredits = $_G['setting']['extcredits'][$items['use_extcredits']]['title'];



if($_GET['action'] == 'payfull'){
    if($apply['verify'] == 1 && $apply['pay_state'] == 1){
        showmessage('���Ѿ�֧���ɹ���');
        exit;
    }




	$myextedits = DB::result_first("SELECT extcredits".$items['use_extcredits']." FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['uid']);
	if($setting['cost']){  //���ֱ�������
		//�ҵĻ���
		if($setting['nodaibaoming']){  //�Ǵ�����
			$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid = '$tid' AND uid=".$_G['uid']);
			$apply['ufielddata'] = unserialize($apply['ufielddata']);
			$totalcredits = 0;
			foreach($setting['cost'] as $value){
				$totalcredits = $totalcredits+$apply['ufielddata']['cost'.$value['id']]*$value['cost_credits'];
			}
			//VIP�ۿ�
			$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
			if(in_array($_G['groupid'],$vipgroup)){
				if($setting['vip_discount']>0){
					$totalcredits = intval($totalcredits*$setting['vip_discount']);
				}
			}

			if($myextedits< $totalcredits){
				showmessage($extcredits.lang('plugin/xj_event','bgwfcj'));
			}
			
			
			DB::query("UPDATE ".DB::table('common_member_count')." SET extcredits".$items['use_extcredits']." = extcredits".$items['use_extcredits']." - ".$totalcredits." WHERE uid=".$_G['uid']);
			DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify=1,pay_state=1 WHERE tid = $tid AND uid=".$_G['uid']);
			
		}else{ //������

			$apply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
			$totalcredits = 0;
			foreach($apply as $value){
				$value['ufielddata'] = unserialize($value['ufielddata']);
				$totalcredits = $totalcredits + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			}
			
			//VIP�ۿ�
			$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
			if(in_array($_G['groupid'],$vipgroup)){
				if($setting['vip_discount']>0){
					//$totalcredits = intval($totalcredits*$setting['vip_discount']);
				}
			}
			
			if($myextedits< $totalcredits){
				showmessage($extcredits.lang('plugin/xj_event','bgwfcj'));
			}
			DB::query("UPDATE ".DB::table('common_member_count')." SET extcredits".$items['use_extcredits']." = extcredits".$items['use_extcredits']." - ".$totalcredits." WHERE uid=".$_G['uid']);
			DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify=1,pay_state=1 WHERE tid = $tid AND uid=".$_G['uid']);
		}
	}else{
		$use_credits = $items['use_extcredits_num'];
		$item = DB::fetch_first("SELECT applyid,applynumber FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		//������ʽ��ͬ����������
		if($setting['nodaibaoming']){
			$applynumber = $item['applynumber'];
		}else{
			$applynumber = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		}	
		$totalcredits = $use_credits*$applynumber;
		
		//VIP�ۿ�
		$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
		if(in_array($_G['groupid'],$vipgroup)){
			if($setting['vip_discount']>0){
				$totalcredits = intval($totalcredits*$setting['vip_discount']);
			}
		}
		
		if($myextedits< $totalcredits){
			showmessage($extcredits.lang('plugin/xj_event','bgwfcj'));
		}
		DB::query("UPDATE ".DB::table('common_member_count')." SET extcredits".$items['use_extcredits']." = extcredits".$items['use_extcredits']." - ".$totalcredits." WHERE uid=".$_G['uid']);
		DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify=1,pay_state=1 WHERE tid = $tid AND uid=".$_G['uid']);
	}

	
	include 'include/sms_func.php';
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=".$_G['uid']);
    //���뽱��
    if($apply['fromuid'] > 0){
        $applynumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$tid." AND uid=".$_G['uid']);
        $yqjl = array();
        $yqjl['tid'] = $tid;
        $yqjl['fromuid'] = $apply['fromuid'];
        $yqjl['applyuid'] = $_G['uid'];
        $yqjl['jfs'] = $setting['yqjl_jfs']*$applynumber;
        $yqjl['jflx'] = $setting['yqjl_jflx'];
        $yqjl['dateline'] = $_G['timestamp'];
        DB::insert('xj_event_yqjl_log',$yqjl);
        updatemembercount($yqjl['fromuid'],array($yqjl['jflx']=>+$yqjl['jfs']));
        $username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$_G['uid']);
        $eventtitle = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid = $tid");
        notification_add($yqjl['fromuid'],'system',$username.lang('plugin/xj_event','beiniyaoqinbaomincanjiale').' <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$eventtitle.'</a> '.lang('plugin/xj_event','huodonghuode').$yqjl['jfs'].$_G['setting']['extcredits'][$yqjl['jflx']]['title'].lang('plugin/xj_event','jiangli'));
    }





	$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid=$tid and A.tid = B.tid");
	$setting = unserialize($thread['setting']);
	$event_starttime = dgmdate($thread['starttime'],'dt');
	if($setting['seccode'] == 1){		
		$message = cutstr($thread['subject'],30).lang('plugin/xj_event', 'hdbmcgrs').':'.$apply['applynumber'].lang('plugin/xj_event', 'ren').' '.lang('plugin/xj_event', 'yanzhenma').':'.$apply['seccode'].' '.lang('plugin/xj_event', 'huodongshijian').':'.$event_starttime;
		$sendtype = lang('plugin/xj_event', 'maomyzmdx');
		if($_G[charset]=='gbk'){
			$message = diconv($message,'UTF-8','GBK');
			$sendtype = diconv($sendtype,'UTF-8','GBK');
		}
		sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
		//xjsendsms(array($apply['mobile']),$message,$sendtype);
		sendpm($apply['uid'],'',$message,$thread['authorid']);
	}elseif($setting['success_sms'] == 1){
		sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
		//�׻����
		//$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
		//$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
		//sendsms_notice_yhd($apply['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);
	}
	C::memory()->clear();//��memcache�ڴ�
	
	showmessage(lang('plugin/xj_event','jifengzfcg'),'plugin.php?id=xj_event:wsqcenter&mod=join_success&tid='.$tid);
	exit();
}
$item = DB::fetch_first("SELECT applyid,applynumber FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
$subject = $items['subject'];
$use_credits = $items['use_extcredits_num'];
//������ʽ��ͬ����������
if($setting['nodaibaoming']){
	$applynumber = $item['applynumber'];
}else{
	$applynumber = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
}



//�жϱ��������Ƿ񹻣������Ͳ���֧��
if($eventnumber>0){
	$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1");
	if($applynumber > ($eventnumber-$applycountnumber)){
		showmessage(lang('plugin/xj_event','baomrsym'));
		exit();
	}
}
$totalcredits = $use_credits*$applynumber;
//VIP�ۿ�
$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);

$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid = '$tid' AND uid=".$_G['uid']);
$apply['ufielddata'] = unserialize($apply['ufielddata']);

include template('xj_event:jfpay');



?>