<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

//0Ԫ֧������   
$tid = intval($_GET['tid']);
$youhuiprice = $eventcore->GetYouHui($tid,$_G['uid']);  //�Żݼ���
$totalprice = $eventcore->GetEventPrice($tid,$_G['uid']); //�ܼ۸�
if(($totalprice-$youhuiprice)<=0){
	$applyid = DB::result_first("SELECT applyid FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
	DB::update('xj_eventapply',array('verify'=>1,'pay_state'=>1),"applyid=$applyid");
	showmessage(lang('plugin/xj_event','gxnbmcg'),$_G['siteurl']."forum.php?mod=viewthread&tid=$tid");
	exit;
}


//����΢��֧������
if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
$appid = $wxset['appid'];
$apikey = $wxset['apikey'];
//APIKEY
$mch_id = $wxset['mch_id'];


//��ȡ����ݺͱ�������
$items = DB::fetch_first("SELECT A.*,B.subject FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid = $tid and A.tid=B.tid");
$setting = unserialize($items['setting']);
$pay_subject = $items['subject'];
$pay_price = $items['use_cost'];
$apply = DB::fetch_first("SELECT applyid,applynumber FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
if($setting['nodaibaoming']){
	$pay_number = $apply['applynumber'];
}else{
	$pay_number = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
}
//�жϱ��������Ƿ񹻣������Ͳ���֧��
if($items['event_number']>0){
	$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1");
	if($pay_number > ($items['event_number']-$applycountnumber)){
		showmessage(lang('plugin/xj_event','baomrsym'));
		exit();
	}
}
$pay_totalprice = $pay_price * $pay_number;
//����Ƕ��ֱ���
if($setting['cost']){
	if($setting['nodaibaoming']){
		$capply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$capply['ufielddata'] = unserialize($capply['ufielddata']);
		$price = 0;
		$paytext = '';
		foreach($setting['cost'] as $value){
			$paytext = $paytext.$value['cost_name'].' '.$capply['ufielddata']['cost'.$value['id']].' x &yen;'.$value['cost_price'].'<br>';
			$price = $price+$capply['ufielddata']['cost'.$value['id']]*$value['cost_price'];
		}
	}else{
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$price = 0;
		$paytext = '';
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$paytext = $paytext.$setting['cost'][$value['ufielddata']['costclass']]['cost_name'].' 1 x &yen;'.$setting['cost'][$value['ufielddata']['costclass']]['cost_price'].'<br>';
			$price = $price + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
		}
	}
	if(!$_G['charset']=='gbk'){
		$paytext = iconv('GBK','UTF-8',$paytext);
	}
	$pay_totalprice = $price;
}
if($_G['charset']=='gbk'){
	$pay_subject = iconv('GBK','UTF-8',$pay_subject);
}

//VIP�ۿ�
if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/vip/wsq_pay.php')) {
	@include 'module/vip/wsq_pay.php';
}

//prepay_id ��ȡ��΢��֧��ͳһ�µ�
$parameters = array();
$parameters["out_trade_no"] = getRandChar(20); //���ɶ�����
$parameters["body"] = mb_substr($pay_subject,0,32,'utf-8');//cutstr($pay_subject,32,'');  //��Ʒ����
$parameters["total_fee"] = intval($pay_totalprice*100);   //�ܽ�λ�Ƿ֣���������С��
$parameters["notify_url"] = $_G['siteurl'].'source/plugin/xj_event/event_pay_wx_notify.php';  //�첽�ص���ַ
$parameters["trade_type"] = 'MWEB';
$parameters["appid"] = $appid;
$parameters["mch_id"] = $mch_id; //�̻���
$parameters["spbill_create_ip"] = $_G['clientip'];  //�ͻ��˵�IP��ַ
$parameters["nonce_str"] = createNoncestr();  //����ַ���
$parameters["sign"] = getSign($parameters);


//���ݿ�����֧����¼
$paylog = array();
$paylog['applyid'] = $apply['applyid'];
$paylog['uid'] = $_G['uid'];
$paylog['tid'] = $tid;
$paylog['tradeno'] = $parameters["out_trade_no"];
$paylog['paytype'] = 'wxpay';
$paylog['subject'] = $items['subject'];
$paylog['price'] = $pay_price;
$paylog['buyer_email'] = $openid;
$paylog['total_fee'] = $pay_totalprice;
$paylog['create_time'] = $_G['timestamp'];
$paylog['paystate'] = 1;
DB::insert("xj_eventpay_log",$paylog);

$xmldata = arrayToXml($parameters);
$prepaystr = postXmlCurl($xmldata, "https://api.mch.weixin.qq.com/pay/unifiedorder");
$postObj = xmlToArray($prepaystr);

if ($postObj['return_code'] == 'FAIL') {
	if ($_G['charset'] == 'gbk') {
		echo iconv('UTF-8', 'GBK', $postObj['return_msg']);
	} else {
		echo $postObj['return_msg'];
	}
	exit ;
}

$url = $_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$tid;
$url = $postObj['mweb_url'].'&redirect_url='.urlencode(diconv($url, $_G['charset'], 'UTF-8'));;
Header("Location: $url");
exit();





function std_class_object_to_array($stdclassobject)
{
    $_array = is_object($stdclassobject) ? get_object_vars($stdclassobject) : $stdclassobject;

    foreach ($_array as $key => $value) {
        $value = (is_array($value) || is_object($value)) ? std_class_object_to_array($value) : $value;
        $array[$key] = $value;
    }

    return $array;
}
function postxml($url,$data){
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}
function postXmlCurl($xml,$url,$second=30)
{		
	//��ʼ��curl        
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, $second);
	//�������ô���������еĻ�
	//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
	//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	//����header
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	//Ҫ����Ϊ�ַ������������Ļ��
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//post�ύ��ʽ
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	//����curl
	$data = curl_exec($ch);
	curl_close($ch);
	//���ؽ��
	if($data)
	{
		curl_close($ch);
		return $data;
	}
	else 
	{ 
		$error = curl_errno($ch);
		echo "curlError, error code:$error"."<br>"; 
		echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>The reason for the error query</a></br>";
		curl_close($ch);
		return false;
	}
}

function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}
//����ָ����С���ַ���
function createNoncestr( $length = 32 ){
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {  
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
	}  
	return $str;
}
/**
* 	���ã���ʽ��������ǩ��������Ҫʹ��
*/
function formatBizQueryParaMap($paraMap, $urlencode)
{
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		//$buff .= strtolower($k) . "=" . $v . "&";
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0) 
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
//����ǩ��
function getSign($Obj){
	global $apikey;
	foreach ($Obj as $k => $v)
	{
		$Parameters[$k] = $v;
	}
	//ǩ������һ�����ֵ����������
	ksort($Parameters);
	$String = formatBizQueryParaMap($Parameters, false);
	//echo '��string1��'.$String.'</br>';
	//ǩ�����������string�����KEY
	$String = $String."&key=$apikey";
	//echo "��string2��".$String."</br>";
	//ǩ����������MD5����
	$String = md5($String);
	//echo "��string3�� ".$String."</br>";
	//ǩ�������ģ������ַ�תΪ��д
	$result_ = strtoupper($String);
	//echo "��result�� ".$result_."</br>";
	return $result_;
}

/**
 * 	���ã�arrayתxml
 */
function arrayToXml($arr)
{
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">"; 

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
	}
	$xml.="</xml>";
	return $xml; 
}

/**
 * 	���ã���xmlתΪarray
 */
function xmlToArray($xml)
{		
	//��XMLתΪarray        
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
	return $array_data;
}

/**
 * 	���ã����ɿ��Ի��code��url
 */
function createOauthUrlForCode($redirectUrl)
{
	global $appid;
	$urlObj["appid"] = $appid;
	$urlObj["redirect_uri"] = urlencode($redirectUrl);
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}

/**
 * 	���ã����ɿ��Ի��openid��url
 */
function createOauthUrlForOpenid()
{
	global $appid,$appsecret,$code;
	$urlObj["appid"] = $appid;
	$urlObj["secret"] = $appsecret;
	$urlObj["code"] = $code;
	$urlObj["grant_type"] = "authorization_code";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
}

/**
 * 	���ã�ͨ��curl��΢���ύcode���Ի�ȡopenid
 */
function getOpenid()
{
	$url = createOauthUrlForOpenid();
	//��ʼ��curl
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, 30);   //��ʱʱ��
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//����curl�������jason��ʽ����
	$res = curl_exec($ch);
	curl_close($ch);
	//ȡ��openid
	$data = json_decode($res,true);
	$return = $data['openid'];
	return $return;
}

//ɾ��΢����Ƕ���
/*
$pluginid = 'xj_event';
require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);
exit('fff');
*/

?>