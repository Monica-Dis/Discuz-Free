<?php

$tmp = explode("\n",$_G['cache']['plugin']['xj_event']['event_offline_class']);
$offline = array();
foreach($tmp as $key=>$value){
	$eclass = explode("|",$value);
	$offline[$eclass[0]] = $eclass[1];
}
$tmp = explode("\n",$_G['cache']['plugin']['xj_event']['event_online_class']);
$online = array();
foreach($tmp as $key=>$value){
	$eclass = explode("|",$value);
	$online[$eclass[0]] = $eclass[1];
}


$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.verify=1 AND A.activityaid>0  ORDER BY A.starttime DESC LIMIT 0,4");
$zhdlist = array();
while($value = DB::fetch($query)){
	$value['activityaid_url'] = getforumimg($value['activityaid'],0,228,310);
	

	//$value[activityaid_url] = getpicurl($value['activityaid'],$value['tid']);
	$zhdlist[] = $value;
}

$type = $_GET['type'];
$orderby = $_GET['orderby'];
if($_GET['type']=='official'){
	$sqlstr = " AND A.verify=1 ";
}elseif($_GET['type']=='personnal'){
	$sqlstr = " AND A.verify<>1 ";
}elseif($_GET['type']=='online'){
	$sqlstr = " AND A.postclass=2 ";
}elseif($_GET['type']=='offline'){
	$sqlstr = " AND A.postclass=1 ";
}else{
	$sqlstr = "";
}
if($_GET['orderby']=='hot'){
	$order = " ORDER BY B.views DESC";
}else{
	$order = " ORDER BY B.dateline DESC";
}
$perpage = 10; //ÿҳ��
$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid $sqlstr");
$page = $_GET['page']?$_GET['page']:1;
if(@ceil($listcount/$perpage) < $page) {
	$page = 1;
}
$start_limit = ($page - 1) * $perpage;
$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:event_center&type=$type&orderby=$orderby",0,10,false,true);
$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid $sqlstr $order LIMIT $start_limit,$perpage");
$eventlist = array();
while($value = DB::fetch($query)){

	if($value['activityaid_url']){
		if(substr($value['activityaid_url'],0,4)!='data' && substr($value['activityaid_url'],0,4)!='http'){
        	$value['activityaid_url'] = $_G['siteurl'].'data/attachment/forum/'.$value['activityaid_url'];
    	}
	}else{
		$value['activityaid_url'] = $_G['siteurl'].STATICURL.'image/common/nophoto.gif';
	}
	$value['coverurl'] = $value['activityaid_url'];



	if($value['postclass']==1){
		$value['classname'] = $offline[$value['offlineclass']];
	}else{
		$value['classname'] = $online[$value['onlineclass']];
	}
	$value['starttimestr'] = dgmdate($value['starttime'],'dt');
	$value['endtimestr'] = dgmdate($value['endtime'],'dt');
	$value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']);
	$value['applylist'] = DB::fetch_all("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid = B.uid AND A.tid=".$value['tid']." LIMIT 0,10");
	foreach($value['applylist'] as $key=>$val){
		$value['applylist'][$key]['avatar'] = avatar($val['uid'],'small',true);
	}
	
	$eventlist[] = $value;
}


$query = DB::query("SELECT A.uid,A.good,B.username FROM ".DB::table('xj_event_member_info')." A,".DB::table('common_member')." B WHERE A.uid=B.uid ORDER BY A.good DESC LIMIT 0,8");
$hddrlist = array();
$i = 1;
while($value = DB::fetch($query)){
	$value['avatar'] = avatar($value['uid'],'small',true);
	$value['event'] = DB::fetch_first("SELECT A.tid,B.subject FROM ".DB::table('xj_eventapply')." A,".DB::table('forum_thread')." B WHERE A.tid = B.tid AND A.uid = ".$value['uid']." ORDER BY A.dateline DESC");
	$value['index'] = $i;
	$i++;
	$hddrlist[] = $value;
}

$query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_post')." B WHERE A.tid=B.tid AND A.sort = 1 AND B.first=1 ORDER BY B.dateline DESC LIMIT 0,8");
$hdhglist = array();
$i = 1;
while($value = DB::fetch($query)){
	$value['dateline'] = dgmdate($value['dateline'],'d');
	$value['message'] = cutstr(xjeventc4ubb(strip_tags($value['message'])),200);
	$value['index'] = $i;
	$i++;
	$hdhglist[] = $value;
}

function xjeventc4ubb($Text) { 
        $Text=stripslashes($Text);
		$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
		$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
		$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
		$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
		$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
		$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
		$Text=preg_replace("/\[(.+?)\]/is","",$Text);
		$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
		$Text=str_replace("<br />","",$Text);
        return $Text;
}
//From: Dism��taobao��com
?>