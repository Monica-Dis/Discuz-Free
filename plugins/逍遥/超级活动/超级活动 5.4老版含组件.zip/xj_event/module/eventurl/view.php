<?php

if ($setting['event_url']) {
    //�������ת
    if ($_G['uid'] != $_G['thread']['authorid'] && $_G['groupid'] != 1) {

        dheader("Location: " . $setting['event_url']);
    } else {
        if ($_G['mobile']) {
            dheader("Location: " . $setting['event_url']);
        }

        include template('viewthread_event', 0, 'source/plugin/xj_event/module/eventurl/template');
        //include template('xj_event:viewthread_event_url');
        $admineventurl = true; 
		
    }
}
