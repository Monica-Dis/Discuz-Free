<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();


$threekey = addslashes($_GET['threekey']);
$tid = intval($_GET['tid']);
$mysession = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_session')." WHERE threekey='$threekey'");
$_G['uid'] = $mysession['uid'];

if($_GET['action'] == 'ysh'){
	//�����б�
	$query = DB::query("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid WHERE A.tid=$tid AND A.first=1 AND A.verify=1 ORDER BY A.dateline DESC");
	$applylist = array();
	while($value = DB::fetch($query)){
		$value['avatar'] = avatar($value['uid'], 'middle', true, false, true).'?random='.random(2);
		$value['username'] = showusername($value['username'],8);
		$value['username'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$value['username']):$value['username'];
		$applylist[] = $value;
	}
}elseif($_GET['action'] == 'wsh'){
	//�����б�
	$query = DB::query("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid WHERE A.tid=$tid AND A.first=1 AND A.verify=0 ORDER BY A.dateline DESC");
	$applylist = array();
	while($value = DB::fetch($query)){
		$value['avatar'] = avatar($value['uid'], 'middle', true, false, true).'?random='.random(2);
		$value['username'] = showusername($value['username'],8);
		$value['username'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$value['username']):$value['username'];
		$applylist[] = $value;
	}
}else{
	//�����б�
	$query = DB::query("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid WHERE tid=$tid AND first=1 ORDER BY A.dateline DESC");
	$applylist = array();
	while($value = DB::fetch($query)){
		$value['avatar'] = avatar($value['uid'], 'middle', true, false, true).'?random='.random(2);
		$value['username'] = showusername($value['username'],8);
		$value['username'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$value['username']):$value['username'];
		$applylist[] = $value;
	}
}



echo json_encode($applylist);

/*
function showusername($username,$len){
	global $_G;
	$return = $username;
	if(function_exists('mb_substr')){
		if(strlen($username)>$len){
			if($_G['charset'] == 'utf-8'){
				$return = mb_substr($username,0,2,'utf-8').'**'.mb_substr($username,-1,1,'utf-8');
			}else{
				$return = mb_substr($username,0,2).'**'.mb_substr($username,-4);
			}
		}
	}
	return $return;
}
*/
function showusername($username,$len){
	global $_G;
	$return = $username;
	if(function_exists('mb_substr')){
		if(mb_strlen($username,$_G['charset'])>$len){
			$return = mb_substr($username,0,$len,$_G['charset']).'...';
		}
	}
	return $return;
}
//From: Dism��taobao��com
?>