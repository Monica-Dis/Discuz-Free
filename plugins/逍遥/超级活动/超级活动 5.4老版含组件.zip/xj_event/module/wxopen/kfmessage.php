<?php
define('IN_DISCUZ',true);
include '../../../../class/class_core.php';
$driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
DB::init($driver,$_G['config']['db']);



$token = '123654';





if($_GET['echostr']){
	if(checkSignature($token)){
		echo $_GET['echostr'];
		exit();
	}
}

if(function_exists('file_get_contents')){
	$result = file_get_contents("php://input");
}else{
	$result = $GLOBALS["HTTP_RAW_POST_DATA"];
}

echo 'success';


log_result('kfdebug.txt',$result);

//验证接口
function checkSignature($tokenstr){
    $signature = $_GET["signature"];
    $timestamp = $_GET["timestamp"];
    $nonce = $_GET["nonce"];

    $token = '123654';
    $tmpArr = array($tokenstr, $timestamp, $nonce);
    sort($tmpArr, SORT_STRING);
    $tmpStr = implode( $tmpArr );
    $tmpStr = sha1( $tmpStr );

    if( $tmpStr == $signature ){
        return true;
    }else{
        return false;
    }
}

// 打印log
function  log_result($file,$word) 
{
	$fp = fopen($file,"a");
	flock($fp, LOCK_EX) ;
	fwrite($fp,"run time".strftime("%Y-%m-%d-%H：%M：%S",time())."\n".$word."\n\n");
	flock($fp, LOCK_UN);
	fclose($fp);
}
//From: Dism·taobao·com
?>