<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();
//���ó����������
@include DISCUZ_ROOT.'./source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

$tid = intval($_GET['tid']);
//��ȡ��½
$mysession = $wxopen->get_mysession();
$_G['uid'] = $mysession['uid'];



$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
$setting = unserialize($items['setting']);
$userfield = unserialize($items['userfield']);  //���ñ����ֶ�

//��ȡ��̳ϵͳ���û��ֶ�����
if(empty($_G['cache']['profilesetting'])) {
	loadcache('profilesetting');
}

$result=array();

//�����
if($setting['session']){
	$formitem = array();
	$formitem['formtype'] = 'select';
	$formitem['fieldid'] = 'session';
	$formitem['title'] = lang('plugin/xj_event', 'huodongchangci');
	$formitem['selvalue'] = '';
	$formitem['choices'] = array();
	foreach($setting['session'] as $key=>$value){
		$tmp = array();
		$tmp['id'] = $key;
		$tmp['name'] = $value;
		$formitem['choices'][] = $tmp;
	}
	$result['formfield'][] = $formitem;
}
//���ַ���ѡ��
if($setting['cost']){
	$formitem = array();
	$formitem['formtype'] = 'select';
	$formitem['fieldid'] = 'costclass';
	$formitem['title'] =  lang('plugin/xj_event', 'baomingleixing');
	$formitem['selvalue'] = '';
	$formitem['choices'] = array();
	foreach($setting['cost'] as $value){
		$tmp = array();
		$tmp['id'] = $value['id'];
		$tmp['name'] = $value['cost_name'];
		$formitem['choices'][] = $tmp;
	}
	$result['formfield'][] = $formitem;
}





//��ȡ�������ֶε�����
foreach($userfield as $value){
	if($value != 'bmmessage'){
		$_G['cache']['profilesetting'][$value]['title'] = $_G['cache']['profilesetting'][$value]['title'];
		$result['formfield'][] = $_G['cache']['profilesetting'][$value];
	}
}
//�µı����ֶ�
if($setting['myuserfield']){
	$myuserfield = $eventcore->GetUserField($setting['myuserfield']);
}
foreach($myuserfield as $value){
	$tmp = array();
	$tmp['fieldid'] = 'myfield'.$value['id'].'_';
	$tmp['title'] = $value['title'];
	$tmp['formtype'] = $value['formtype'];
	$tmp['choices'] = $value['choices'];
	$result['formfield'][] = $tmp;
}
//Ϊ�����Է�������������»�ȡ��������
foreach($userfield as $value){
	if($value == 'bmmessage'){
		$bmmessage = array();
		$bmmessage['fieldid'] = $value;
		$bmmessage['title'] = lang('plugin/xj_event', 'liuyan');
		$bmmessage['formtype'] = 'textarea';
		$result['formfield'][] = $bmmessage;
	}
}








foreach($result['formfield'] as $key=>$value){
	if($value['formtype'] == 'select'){
		if($value['fieldid'] == 'gender'){
			$gender = array();
			$gender[0]['id'] = 0;
			$gender[0]['name'] = lang('plugin/xj_event', 'baomi');
			$gender[1]['id'] = 1;
			$gender[1]['name'] = lang('plugin/xj_event', 'nan');
			$gender[2]['id'] = 2;
			$gender[2]['name'] = lang('plugin/xj_event', 'nv');
			$result['formfield'][$key]['selvalue'] = 0;
			$result['formfield'][$key]['choices'] = $gender;
		}elseif($value['fieldid'] == 'birthday'){
			$result['formfield'][$key]['formtype'] = 'date';
			$result['formfield'][$key]['selvalue'] = '';
		}elseif($value['fieldid'] == 'residecity'){   //��ס��
			$result['formfield'][$key]['formtype'] = 'area';
			$p = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE upid=0");
			$choices = array();
			foreach($p as $k => $op){
				$choices[$k]['id'] = $op['id'];
				$choices[$k]['name'] = $op['name'];
			}
			$result['formfield'][$key]['selvalue'] = '';
			$result['formfield'][$key]['selprovincevalue'] = '';
			$result['formfield'][$key]['selcityvalue'] = '';
			$result['formfield'][$key]['selcountyvalue'] = '';
			$result['formfield'][$key]['choices'] = $choices;
			$result['formfield'][$key]['city'] = array();
			$result['formfield'][$key]['county'] = array();
		}elseif($value['fieldid'] == 'session' || $value['fieldid'] == 'costclass'){
			
		}else{
			$value['choices'] = explode("\n", $value['choices']);
			$choices = array();
			foreach($value['choices'] as $k=>$op){
				$choices[$k]['id'] = $op;
				$choices[$k]['name'] = $op;
			}
			$result['formfield'][$key]['selvalue'] = '';
			$result['formfield'][$key]['choices'] = $choices;
		}
		
		
		
	}
}


$result['event_number_max'] = $items['event_number_max'];

$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
echo json_encode($result);

?>