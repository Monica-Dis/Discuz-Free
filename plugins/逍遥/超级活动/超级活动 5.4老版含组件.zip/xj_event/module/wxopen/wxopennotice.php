<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();

//获取登陆
$mysession = $wxopen->get_mysession();
$uid = $_G['uid'] = $mysession['uid'];
$_G['openid'] = $mysession['openid'];


$tid = intval($_GET['tid']);
$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
$event_starttime = dgmdate($items['starttime'],'dt');
//发送小程序的消息通知
$noticedata = array();
$noticedata['keyword1']['value'] = $items['subject'];
$noticedata['keyword2']['value'] = $items['event_address'];
$noticedata['keyword3']['value'] = $event_starttime;
$noticedata = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($noticedata):$noticedata;
$wxopen->send_xcxnotice($_G['openid'],$_GET['formid'],$wxopen_config['notice']['applysuccess']['template_id'],$noticedata,'pages/my/myticket?tid='.$tid);

$result = array();
$result['full'] = 1;
echo json_encode($result);

?>