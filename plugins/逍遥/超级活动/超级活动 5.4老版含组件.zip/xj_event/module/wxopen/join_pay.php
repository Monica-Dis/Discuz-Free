<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();

//调用活动核心类
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();



$threekey = addslashes($_GET['threekey']);
$tid = intval($_GET['tid']);
$mysession = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_session')." WHERE threekey='$threekey'");
$_G['uid'] = $mysession['uid'];
$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
$items['setting'] = $setting = unserialize($items['setting']);
$items['subject'] = $items['subject'];
$apply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$_G['uid']);
foreach($apply as $key=>$value){
	$apply[$key]['ufielddata'] = unserialize($value['ufielddata']);
}
$my = array();

if($items['use_extcredits']){
$my['myextedits'] = DB::result_first("SELECT extcredits".$items['use_extcredits']." FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['uid']);
}
$my['total_price'] = 0;
$my['total_credits'] = 0;


if($setting['cost']){  //多种报名方式
	if($setting['nodaibaoming']){ //代报名不填资料
		$my['number'] = 0;
		foreach($items['setting']['cost'] as $key=>$value){
			$tmp = array();
			$tmp['costname'] = $value['cost_name']; 
			$tmp['number'] = $apply[0]['ufielddata']['cost'.$key];
			$tmp['price'] = $value['cost_price'];
			$tmp['credits'] = $value['cost_credits'];
			$tmp['total_price'] = $tmp['price'] * $tmp['number'];
			$tmp['total_credits'] = $tmp['credits'] * $tmp['number'];
			$my['join'][] = $tmp;
			$my['total_price'] = $my['total_price'] + $tmp['total_price'];
			$my['total_credits'] = $my['total_credits'] + $tmp['total_credits'];
			$my['number'] = $tmp['number']+$my['number'];
		}
	}else{   //代报名填写资料方式
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
		$my['join'] = array();
		$my['number'] = 0;
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$costclass = $value['ufielddata']['costclass'];
			$my['join'][$costclass]['costname'] = $items['setting']['cost'][$costclass]['cost_name'];
			$my['join'][$costclass]['number'] = $my['join'][$costclass]['number'] + 1; 
			$my['join'][$costclass]['price'] = $my['join'][$costclass]['price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['credits'] = $my['join'][$costclass]['credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			$my['join'][$costclass]['total_price'] = $my['join'][$costclass]['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['total_credits'] = $my['join'][$costclass]['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			
			
			$my['total_price'] = $my['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['total_credits'] = $my['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			$my['number'] = $my['number']+1;
		}
		
	}
}else{
	$pay_credits = $items['use_extcredits_num'];
	$pay_price = $items['use_cost'];
	$pay_number = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
	$my['credits'] = $pay_credits;
	$my['price'] = $pay_price;
	$my['number'] = $pay_number;
	$my['total_price'] = $pay_price * $pay_number;
	$my['total_credits'] = $pay_credits * $pay_number;
}


//判断名额是否已满
$applynum = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1"); //已报名人数
$applycountnum = DB::result_first("SELECT event_number FROM ".DB::table('xj_event')." WHERE tid='$tid'"); //活动总人数
if($applycountnum>0){
	if($my['number'] > ($applycountnum-$applynum)){
		$result = array();
		$result['full'] = 2;
		$result['message'] = '报名已满';
		$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
		echo json_encode($result);
		exit;
	}
}





//优惠计算
if($eventcore->GetYouHui($tid,$_G['uid'])>0){
	$my['price_youhui'] = $my['total_price'] - $eventcore->GetYouHui($tid,$_G['uid']);
}


$my['creditsname'] = $_G['setting']['extcredits'][$items['use_extcredits']]['title'];
$my['creditsname'] = $my['creditsname'];

$result = array();
$result['event'] = $items;
$result['my'] = $my;


//print_r($result);
$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
echo json_encode($result);

?>