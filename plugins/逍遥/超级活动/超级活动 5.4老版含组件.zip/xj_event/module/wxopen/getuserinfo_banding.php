<?php

include '../../../../class/class_core.php';
$driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
DB::init($driver,$_G['config']['db']);


//调用微信支付设置
if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
@include DISCUZ_ROOT.'source/plugin/xj_event/module/wxopen/include/wxpayfunc.php';

$appid = $wxset['xcx_appid'];
$openid = addslashes($_GET['openid']);
$sessionkey = addslashes($_GET['sessionkey']);
$wxopen = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_login')." WHERE openid='$openid'");
$sessionKey = $wxopen['sessionkey'];

$encryptedData = $_GET['encryptedData'];
$iv = $_GET['iv'];



include_once "wxBizDataCrypt.php";

/*
$appid = 'wxbafaca0ad52bc8ab';
$sessionKey = 'R9KbNT87JwMTgkkCU44vTA==';

$encryptedData="x7zTWBrhqVXT6MSRi5h9FIkeI/CKECk2fKcA6datNXLvY+bOZRdsjOAFirBwGaN4/08FSi2FpeA2aynk5XpxKRwa4M5IwzRPW7jmWakXjhr/bhTnq7XJ8h93Cje6I3c2VWDRUaHhdLYaR4oJpzGtIvYmTHaSz1P/Ltgx0BzY+wKZO78BvxdxrcuVM8n6bwl/VvNlGyivuA2pvUH5lX5ACrMKb3wANB9Ul3cBcHFQ1O75X2Gtx2+rCd84QjvjUtuIHS16XA5JrvcyHRKAWEQ9LwETDr8FCXpdTD7FPI705pK/k19cuQv5qMYpd1QQ7o1qHMDsk1cGxIfUwEUEWxoiRULk0lMAbjfb4mlIG7niuIykOvHJm/AXX++n8zgsdh/hdhJ6YXp1diE46Sx9wRsPB8BD9Wt3KiKo9IwkTwaw8CmS+xsuDvSG+gAzsnWLFx61MSgGh/P+IRYwv7Qfau9SASTaZo2D29+FqjQtmJaqGdvljQ/BqxqMU69BChbG1Q6bsIbdkCA8BT3Twa7xTSEksg==";

$iv = 'O8euofoRHqGWAHktiUwjkg==';
*/



$pc = new WXBizDataCrypt($appid, $sessionKey);
$errCode = $pc->decryptData($encryptedData, $iv, $data );

if ($errCode == 0) {
	//$res = json_encode($data);
	$res = json_decode($data,true);
	$unionid = $res['unionId'];
	//if($unionid){
		//$uid = DB::result_first("SELECT uid FROM ".DB::table('appbyme_connection')." WHERE param='$unionid'");
	//}else{
		$uid = DB::result_first("SELECT uid FROM ".DB::table('xj_wxopen_login')." WHERE openid='$openid'");
	//}

	//登陆操作，记录threekey
	DB::delete('xj_wxopen_session',"openid='$openid'");
	$threekey = getRandChar(32);
	$wxsession = array();
	$wxsession['threekey'] = $threekey;
	$wxsession['sessionkey'] = $sessionkey;
	$wxsession['openid'] = $openid;
	$wxsession['uid'] = $uid;
	$wxsession['unionid'] = $unionid;
	$wxsession['dateline'] = $_G['timestamp'];
	DB::insert('xj_wxopen_session',$wxsession);
	
	
	$result = array();
	$result['full'] = 1;
	$result['openid'] = $openid;
	$result['threesession'] = $threekey;
	echo json_encode($result);
	exit;
	
	
	
	

} else {
	print_r($errCode);
    //print($errCode . "\n");
}

