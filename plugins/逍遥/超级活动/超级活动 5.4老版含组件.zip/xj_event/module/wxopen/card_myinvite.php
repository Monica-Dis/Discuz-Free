<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen    = new xj_eventwxopen();
$threekey  = addslashes($_GET['threekey']);
$mysession = DB::fetch_first("SELECT * FROM " . DB::table('xj_wxopen_session') . " WHERE threekey='$threekey'");
$_G['uid'] = intval($mysession['uid']);

loadcache('xj_card');

$data = array();

if ($_GET['action'] == 'list') {

    $myinvitecode = DB::fetch_first("SELECT * FROM " . DB::table('xj_card_invitecode') . " WHERE uid=" . $_G['uid']);
    $invitecode   = $myinvitecode['invitecode'];

    $perpage     = 10; //ÿҳ��
    $listcount   = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card_invite_log') . " WHERE invitecode='$invitecode' AND state>0");
    $page        = $_GET['page'] ? $_GET['page'] : 1;
    $start_limit = ($page - 1) * $perpage;
    $query       = DB::query("SELECT A.*,B.username FROM " . DB::table('xj_card_invite_log') . " A LEFT JOIN " . DB::table('common_member') . " B ON A.to_uid=B.uid WHERE invitecode='$invitecode' AND A.state>0 LIMIT $start_limit,$perpage");
    while ($value = DB::fetch($query)) {
        $value['kkdate']        = DB::result_first("SELECT kkdate FROM " . DB::table('xj_card') . " WHERE cardno=" . $value['to_cardno']);
        $value['kkdate']        = date('Y-m-d', $value['kkdate']);
        $value['dateline']      = date('Y-m-d', $value['dateline']);
        $data['myinvitelist'][] = $value;
    }

} elseif ($_GET['action'] == 'exchangefull') {

	$inviteid = intval($_GET['inviteid']);
	$card = DB::fetch_first("SELECT * FROM ".DB::table('xj_card')." WHERE uid=".$_G['uid']);
	if($card['state']<1){
		$data['full'] = 2;
		$data['message'] = lang('plugin/xj_card','qingxiankaikacaikeyiduihuan');
		$data['message'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$data['message']):$data['message'];
		echo json_encode($data);
		exit;
	}
	$log = DB::fetch_first("SELECT * FROM ".DB::table('xj_card_invite_log')." WHERE id=$inviteid");
	if($log['state']!=1){
		$data['full'] = 2;
		$data['message'] = lang('plugin/xj_card','niyijingduihuanguohuozheyaoqingweishengxiao');
		$data['message'] = $_G['charset']=='gbk'?iconv('gbk','utf-8',$data['message']):$data['message'];
		echo json_encode($data);
		exit;
	}
	
	//���ӻ�Ա����
	$uid = $_G['uid'];
	$old = DB::fetch_first("SELECT * FROM ".DB::table('common_member_field_forum')." WHERE uid=".$uid);
	$old['groupterms'] = unserialize($old['groupterms']);
	$groupexpiry = $old['groupterms']['main']['time']+ $_G['cache']['plugin']['xj_card']['invite_days'] * (3600*24);
	$old['groupterms']['main']['time'] = $groupexpiry;
	$old['groupterms']['ext'][$groupid] = $groupexpiry;
	$old['groupterms'] = serialize($old['groupterms']);
	DB::update('common_member',array('groupexpiry'=>$groupexpiry),"uid = ".$uid);
	DB::update('common_member_field_forum',array('groupterms'=>$old['groupterms']),"uid = ".$uid);
	DB::update('xj_card',array('jzdate'=>$groupexpiry),"uid=$uid");
	C::memory()->clear();//��memcache�ڴ�
	//���¼�¼
	DB::update('xj_card_invite_log',array('state'=>2),"id=$inviteid");
	
	$data['full'] = 1;


} else {

//����������
    $myinvitecode = DB::fetch_first("SELECT * FROM " . DB::table('xj_card_invitecode') . " WHERE uid=" . $_G['uid']);
    if (empty($myinvitecode['invitecode'])) {

        $itcode = getinvitecode(6);
        $cc     = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card_invitecode') . " WHERE invitecode='$itcode'");
        if ($cc > 0) {
            //���ɲ��ظ���������
            $itcode = getinvitecode(6);
            $cc     = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card_invitecode') . " WHERE invitecode='$itcode'");
        }
        $myinvitecode               = array();
        $myinvitecode['uid']        = $_G['uid'];
        $myinvitecode['invitecode'] = $itcode;
        DB::insert('xj_card_invitecode', $myinvitecode);
    }

    $data['invitecode']   = $myinvitecode['invitecode'];
    $data['invite_rules'] = $_G['cache']['plugin']['xj_card']['invite_rules'];

//����
    $data['share']['title']  = '�ҵ���������' . $data['invitecode'] . ' ' . $_G['cache']['plugin']['xj_card']['invite_sharetitle'];
    $data['share']['img']    = $_G['siteurl'] . $_G['cache']['plugin']['xj_card']['invite_shareimg'];
    $data['share']['remark'] = $_G['cache']['plugin']['xj_card']['invite_shareremark'];

    $data['invitecount'] = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card_invite_log') . " WHERE invitecode='" . $myinvitecode['invitecode'] . "' AND state>0");
    $data['jianglidays'] = $_G['cache']['plugin']['xj_card']['invite_days'] * $data['invitecount'];

}

$data = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($data) : $data;
echo json_encode($data);
