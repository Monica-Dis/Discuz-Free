<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();
//���û������
@include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

$tid = intval($_GET['tid']);
//��ȡ��½
$mysession    = $wxopen->get_mysession();
$_G['uid']    = $mysession['uid'];
$_G['openid'] = $mysession['openid'];

if (intval($_G['uid']) < 1) {
    $result['full']    = 2;
    $result['message'] = lang('plugin/xj_event', 'qingxiandengluzaibaoming');
    $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
    echo json_encode($result);
    exit;
}

$system    = addslashes($_GET['system']);
$items     = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid = B.tid WHERE A.tid = $tid"));
$setting   = unserialize($items['setting']);
$userfield = unserialize($items['userfield']); //���ñ����ֶ�



if ($setting['onlyvip']) {
    $vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);
    if (!in_array($_G['groupid'], $vipgroup)) {
        $result['full']    = 2;
        $result['message'] = lang('plugin/xj_event', 'benhuodongjingxian') . ($_G['cache']['plugin']['xj_card']['cardname'] ? $_G['cache']['plugin']['xj_card']['cardname'] : 'VIP') . lang('plugin/xj_event', 'yonghubaomin');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        echo json_encode($result);
        exit;
    }
}







$applynumber = intval($_GET['applynumber']);
$post        = array();

//�µı����ֶεı������������ݿ�
if ($setting['myuserfield']) {
    $myuserfield = $eventcore->GetUserField($setting['myuserfield']);
}

for ($i = 0; $i < $applynumber; $i++) {
    $postitem = array();
    foreach ($userfield as $value) {
        $postitem[$value] = addslashes($_GET[$value . $i]);
        if ($value != 'bmmessage' && empty($postitem[$value])) {
            $result['full']    = 2;
            $result['message'] = lang('plugin/xj_event', 'baomingxiangqingtianxiewanzheng');
            //$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
            echo json_encode($result);
            exit;
        }
        //$postitem[$value] = $_G['charset'] == 'gbk'?iconv('utf-8','gbk',$postitem[$value]):$postitem[$value];
    }

    foreach ($myuserfield as $value) {
        $postitem['myfield' . $value['id']] = $_GET['myfield' . $value['id'].'_'.$i];
    }

    $postitem['session']   = $_GET['session' . $i];
    $postitem['costclass'] = $_GET['costclass' . $i];
    $post[]                = $postitem;
}


//��֤�ֻ��ź�����֤
if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/checkapply/checkapply.php')) {
    @include '../checkapply/checkapply.php';
}
//�жϻظ���ſ��Ա���
if ($setting['reply']) {
    $replys = DB::result_first("SELECT count(*) FROM " . DB::table('forum_post') . " WHERE tid='$tid' AND first<>1 AND invisible>=0 AND authorid = " . $_G['uid']);
    if ($replys < 1) {
        $result['full']    = 2;
        $result['message'] = lang('plugin/xj_event', 'huifuhoucaikeyibaoming');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        echo json_encode($result);
        exit;
    }
}
//��֤�Ƿ��ѱ���
$count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and uid=" . $_G['uid']);
if ($count > 0) {
    $result['full']    = 2;
    $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', lang('plugin/xj_event', 'qinwcfbm')) : lang('plugin/xj_event', 'qinwcfbm');
    echo json_encode($result);
    exit;
}
//��֤���������Ƿ�
$applynumber   = count($post); //���α�������
$applynum      = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"); //�ѱ�������
$applycountnum = DB::result_first("SELECT event_number FROM " . DB::table('xj_event') . " WHERE tid='$tid'"); //�������
if ($applycountnum > 0) {
    if ($applynumber > ($applycountnum - $applynum)) {
        $result['full']    = 2;
        $result['message'] = lang('plugin/xj_event', 'baomrsym') . ' ' . lang('plugin/xj_event', 'shengyu') . ($applycountnum - $applynum) . lang('plugin/xj_event', 'geminge');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];

        echo json_encode($result);
        exit;
    }
}
//��ȡ���֯�˵�ID
$event_uid = $items['authorid'];
//�����
$event_title = $items['subject'];
//���ʼʱ��
$event_starttime = dgmdate($items['starttime'], 'dt');
//�жϻ��ֹ�����
$member = DB::fetch_first("SELECT extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8 FROM " . DB::table('common_member_count') . " WHERE uid = " . $_G['uid']);
//�������������ݿ�
$first = 1;

foreach ($post as $key => $value) {
    $ufielddata = array();
    foreach ($value as $key2 => $value2) {
        if ($key2 != 'message' && $key2 != 'session') {
            //if (substr($system, 0, 3) == 'iOS') {
            //    $ufielddata[$key2] = $_G['charset'] == 'gbk' ? iconv('utf-8', 'gbk', $value2) : $value2;
            //} else {
                $ufielddata[$key2] = $value2;
            //}
        }
    }
    $ufielddata                = serialize($ufielddata);
    $eventapply                = array();
    $eventapply['tid']         = $tid;
    $eventapply['eid']         = $items['eid'];
    $eventapply['uid']         = $_G['uid'];
    $eventapply['realname']    = addslashes($value['realname']);
    $eventapply['qq']          = addslashes($value['qq']);
    $eventapply['mobile']      = addslashes($value['mobile']);
    $eventapply['bmmessage']   = addslashes($value['bmmessage']);
    $eventapply['dateline']    = $_G['timestamp'];
    $eventapply['applynumber'] = 1;
    $eventapply['ufielddata']  = $ufielddata;
    $eventapply['seccode']     = random(8, 1);
    $eventapply['session']     = intval($value['session']);
    $eventapply['first']       = $first;
    if ($fromuid != $_G['uid']) {
        $eventapply['fromuid'] = $fromuid;
    }

    DB::insert('xj_eventapply', $eventapply);
    $first = 0; //����������0
}
//�û����ص���Ϣ���ݱ��Ƿ���ڣ������ھ��½�
$num = DB::result_first("SELECT count(*) FROM " . DB::table('xj_event_member_info') . " WHERE uid = " . $_G['uid']);
if ($num == 0) {
    DB::query("INSERT INTO " . DB::table('xj_event_member_info') . " (uid) VALUES (" . $_G['uid'] . ")");
}

if ($setting['noverify'] == 1) {
    //���������

    if ($setting['eventpay']) {
        //�������֧��
        $result['full']    = 1;
        $result['message'] = lang('plugin/xj_event', 'bmzltjcgxzzrzfym');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        $result['url']     = $zffyurl;
        $result['btntxt']  = lang('plugin/xj_event', 'zhifufy');
        $result['btntxt']  = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['btntxt']) : $result['btntxt'];

        //�����Ҫ֧�����������ֱ��ͨ��
        //�Żݼ���
        $youhuiprice = $eventcore->GetYouHui($tid, $_G['uid']);
        //�ܼ۸�
        $totalprice = $eventcore->GetEventPrice($tid, $_G['uid']);
        if (($totalprice - $youhuiprice) <= 0) {
            DB::update('xj_eventapply', array('verify' => 1, 'pay_state' => 1), "tid=$tid and uid=" . $_G['uid']);
            $result['message'] = lang('plugin/xj_event', 'gxnbmcg');
            $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        }

        echo json_encode($result);
        exit;
    } else {
        DB::query("update " . DB::table('xj_eventapply') . " set verify=1 where tid='$tid' and uid=" . $_G['uid']); //�Զ����
        //����Ľ�������
        if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/invitation/event_yqjl.php')) {
            if ($setting['yqjl_jfs'] > 0 && $fromuid != $_G['uid']) {
                $yqjl             = array();
                $yqjl['tid']      = $tid;
                $yqjl['fromuid']  = $fromuid;
                $yqjl['applyuid'] = $_G['uid'];
                $yqjl['jfs']      = $setting['yqjl_jfs'] * $applynumber;
                $yqjl['jflx']     = $setting['yqjl_jflx'];
                $yqjl['dateline'] = $_G['timestamp'];
                DB::insert('xj_event_yqjl_log', $yqjl);
                updatemembercount($yqjl['fromuid'], array($yqjl['jflx'] => +$yqjl['jfs']));
                notification_add($fromuid, 'system', $_G['username'] . lang('plugin/xj_event', 'beiniyaoqinbaomincanjiale') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $event_title . '</a> ' . lang('plugin/xj_event', 'huodonghuode') . $yqjl['jfs'] . $_G['setting']['extcredits'][$yqjl['jflx']]['title'] . lang('plugin/xj_event', 'jiangli'));
            }
        }
        //���Ų���
        require DISCUZ_ROOT . './source/plugin/xj_event/include/sms_func.php';
        if ($setting['seccode'] == 1) {
            $message = cutstr($event_title, 30) . lang('plugin/xj_event', 'hdbmcgrs') . ':' . $applynumber . lang('plugin/xj_event', 'renyanzhengma') . ':' . $eventapply['seccode'] . ' ' . lang('plugin/xj_event', 'huodongshijian') . ':' . $event_starttime;
            //xjsendsms(array($eventapply['mobile']),$message,lang('plugin/xj_event', 'maomyzmdx'));
            sendsms_vcode($eventapply['mobile'], $event_title, $applynumber, $eventapply['seccode']);
            sendpm($eventapply['uid'], '', $message, $event_uid);
        } elseif ($setting['success_sms'] == 1) {
            sendsms_success($eventapply['mobile'], $event_title, $event_starttime);
            //�׻����
            //$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
            //$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
            //sendsms_notice_yhd($eventapply['mobile'],$event_title,$event_starttime,$items['event_address'],$smsmobile);
        }
        notification_add($event_uid, 'system', $_G['username'] . ' ' . lang('plugin/xj_event', 'bmcjlnd') . ' <a href="forum.php?mod=viewthread&tid=' . $tid . '" target="_blank">' . $event_title . '</a> ' . lang('plugin/xj_event', 'hdxtyzdsh'), array(), 0);

        //����С�������Ϣ֪ͨ
        $noticedata                      = array();
        $noticedata['keyword1']['value'] = $event_title;
        $noticedata['keyword2']['value'] = $items['event_address'];
        $noticedata['keyword3']['value'] = $event_starttime;
        $noticedata                      = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($noticedata) : $noticedata;
        $tt                              = $wxopen->send_xcxnotice($_G['openid'], $_GET['formid'], $wxopen_config['notice']['applysuccess']['template_id'], $noticedata, 'pages/my/myticket?tid=' . $tid);
        log_result('xcxnotice.txt', $tt);

        $result['full']    = 1;
        $result['message'] = lang('plugin/xj_event', 'gxnbmcg');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        $result['url']     = $_G['siteurl'] . "forum.php?mod=viewthread&tid=$tid";
        echo json_encode($result);
        exit;
    }
} else {
    //�������ʱ
    if ($setting['eventpay']) { //�������֧��
        $result['full']    = 1;
        $result['message'] = lang('plugin/xj_event', 'bmzltjcgxzzrzfym');
        $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
        $result['url']     = $zffyurl;
        $result['btntxt']  = lang('plugin/xj_event', 'zhifufy');
        $result['btntxt']  = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['btntxt']) : $result['btntxt'];
        echo json_encode($result);
        exit;
    }
    //��֪ͨ
    notification_add($event_uid, 'system', 'activity_notice', array('tid' => $tid, 'subject' => $event_title));
    $result['full']    = 1;
    $result['message'] = lang('plugin/xj_event', 'bmxxtjcgqddsh');
    $result['message'] = $_G['charset'] == 'gbk' ? iconv('gbk', 'utf-8', $result['message']) : $result['message'];
    $result['url']     = $_G['siteurl'] . "forum.php?mod=viewthread&tid=$tid";
    echo json_encode($result);
    exit;
}

echo json_encode($result);

// ��ӡlog
function log_result($file, $word)
{
    $fp = fopen($file, "a");
    flock($fp, LOCK_EX);
    fwrite($fp, "run time" . strftime("%Y-%m-%d-%H��%M��%S", time()) . "\n" . $word . "\n\n");
    flock($fp, LOCK_UN);
    fclose($fp);
}
