<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();

//获取登陆
$mysession = $wxopen->get_mysession();
$uid = $_G['uid'] = $mysession['uid'];
$_G['openid'] = $mysession['openid'];


$tid = intval($_GET['tid']);
$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
$items['setting'] = unserialize($items['setting']);
$items['subject'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$items['subject']):$items['subject'];
$apply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$_G['uid']);
foreach($apply as $key=>$value){
	$apply[$key]['ufielddata'] = unserialize($value['ufielddata']);
}
$extcredits = $_G['setting']['extcredits'][$items['use_extcredits']]['title'];


//计算支付的积分和金额
$my = array();
$my['myextedits'] = DB::result_first("SELECT extcredits".$items['use_extcredits']." FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['uid']);
$my['total_price'] = 0;
$my['total_credits'] = 0;
if($setting['cost']){  //多种报名方式
	if($setting['nodaibaoming']){ //代报名不填资料
		foreach($items['setting']['cost'] as $key=>$value){
			$tmp = array();
			$tmp['costname'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$value['cost_name']):$value['cost_name']; 
			$tmp['number'] = $apply[0]['ufielddata']['cost'.$key];
			$tmp['price'] = $value['cost_price'];
			$tmp['credits'] = $value['cost_credits'];
			$tmp['total_price'] = $tmp['price'] * $tmp['number'];
			$tmp['total_credits'] = $tmp['credits'] * $tmp['number'];
			$my['join'][] = $tmp;
			$my['total_price'] = $my['total_price'] + $tmp['total_price'];
			$my['total_credits'] = $my['total_credits'] + $tmp['total_credits'];
		}
	}else{   //代报名填写资料方式
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
		$my['join'] = array();
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$costclass = $value['ufielddata']['costclass'];
			$my['join'][$costclass]['costname'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$items['setting']['cost'][$costclass]['cost_name']):$items['setting']['cost'][$costclass]['cost_name'];
			$my['join'][$costclass]['number'] = $my['join'][$costclass]['number'] + 1; 
			$my['join'][$costclass]['price'] = $my['join'][$costclass]['price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['credits'] = $my['join'][$costclass]['credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			$my['join'][$costclass]['total_price'] = $my['join'][$costclass]['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['total_credits'] = $my['join'][$costclass]['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			
			
			$my['total_price'] = $my['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['total_credits'] = $my['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
		}
		
	}
}else{
	$pay_credits = $items['use_extcredits_num'];
	$pay_price = $items['use_cost'];
	$pay_number = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
	$my['credits'] = $pay_credits;
	$my['price'] = $pay_price;
	$my['number'] = $pay_number;
	$my['total_price'] = $pay_price * $pay_number;
	$my['total_credits'] = $pay_credits * $pay_number;
}





//判断积份够否
if($my['myextedits']<$my['total_credits']){
	$result = array();
	$result['full'] = 2;
	$result['message'] = $extcredits.lang('plugin/xj_event','bgwfcj');
	$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
	echo json_encode($result); 
	exit;
}

DB::query("UPDATE ".DB::table('common_member_count')." SET extcredits".$items['use_extcredits']." = extcredits".$items['use_extcredits']." - ".$my['total_credits']." WHERE uid=".$_G['uid']);
DB::query("UPDATE ".DB::table('xj_eventapply')." SET verify=1,pay_state=1 WHERE tid = $tid AND uid=".$_G['uid']);

//短信操作
include 'include/sms_func.php';
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=".$_G['uid']);
$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime,event_address FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid=$tid and A.tid = B.tid");
$setting = unserialize($thread['setting']);
$event_starttime = dgmdate($thread['starttime'],'dt');
if($setting['seccode'] == 1){		
	$message = cutstr($thread['subject'],30).lang('plugin/xj_event', 'hdbmcgrs').':'.$apply['applynumber'].lang('plugin/xj_event', 'ren').' '.lang('plugin/xj_event', 'yanzhenma').':'.$apply['seccode'].' '.lang('plugin/xj_event', 'huodongshijian').':'.$event_starttime;
	$sendtype = lang('plugin/xj_event', 'maomyzmdx');
	if($_G['charset']=='gbk'){
		$message = diconv($message,'UTF-8','GBK');
		$sendtype = diconv($sendtype,'UTF-8','GBK');
	}
	sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
	//xjsendsms(array($apply['mobile']),$message,$sendtype);
	sendpm($apply['uid'],'',$message,$thread['authorid']);
}elseif($setting['success_sms'] == 1){
	sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
	//易活动短信
	//$smsuid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username='".$setting['event_admin'][0]."'");
	//$smsmobile = DB::result_first("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE uid=$smsuid");
	//sendsms_notice_yhd($apply['mobile'],$thread['subject'],$event_starttime,$thread['event_address'],$smsmobile);
}
//发送小程序的消息通知
$noticedata = array();
$noticedata['keyword1']['value'] = $thread['subject'];
$noticedata['keyword2']['value'] = $thread['event_address'];
$noticedata['keyword3']['value'] = $event_starttime;
$noticedata = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($noticedata):$noticedata;
$wxopen->send_xcxnotice($_G['openid'],$_GET['formid'],$wxopen_config['notice']['applysuccess']['template_id'],$noticedata,'pages/my/myticket?tid='.$tid);

$result = array();
$result['full'] = 1;
echo json_encode($result);

?>