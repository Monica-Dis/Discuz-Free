<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/config.php';
include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/include/key.php';
$xj_checkaccredit = new xj_checkaccredit();

class xj_eventwxopen
{
	public function get_mysession()
	{
		$threekey = addslashes($_GET['threekey']);
		$result = DB::fetch_first('SELECT * FROM ' . DB::table('xj_wxopen_session') . (' WHERE threekey=\'' . $threekey . '\''));
		return $result;
	}
	public function send_xcxnotice($openid, $formid, $template_id, $data, $pageurl)
	{
		global $_G;
		if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
			@(include $xj_event_wxset);
		}
		@(include DISCUZ_ROOT . 'source/plugin/xj_event/module/wxopen/include/wxpayfunc.php');
		require_once libfile('function/cache');
		loadcache('wxxcx_token');
		$token = $_G['cache']['wxxcx_token'];
		if ($_G['timestamp'] - intval($token['timestamp']) > 7100) {
			$cx = get('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $wxset['xcx_appid'] . '&secret=' . $wxset['xcx_appsecret']);
			$token = json_decode($cx, true);
			$token['timestamp'] = $_G['timestamp'];
			savecache('wxxcx_token', $token);
		}
		$access_token = $token['access_token'];
		$body = array();
		$body['touser'] = $openid;
		$body['template_id'] = $template_id;
		$body['page'] = $pageurl;
		$body['form_id'] = $formid;
		$body['data'] = $data;
		$body = json_encode($body);
		$header = array('Accept:application/json', 'Content-Type:application/json;charset=utf-8');
		$result = curl_post('https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=' . $access_token, $body, $header);
		$result = json_decode($result, true);
		return $result;
	}
	public function showusername($username, $len)
	{
		global $_G;
		$return = $username;
		if (function_exists('mb_substr')) {
			if (strlen($username) > $len) {
				if ($_G['charset'] == 'utf-8') {
					$return = mb_substr($username, 0, 2, 'utf-8') . '**' . mb_substr($username, 0 - 1, 1, 'utf-8');
				} else {
					$return = mb_substr($username, 0, 2) . '**' . mb_substr($username, 0 - 4);
				}
			}
		}
		return $return;
	}
	public function getattachs($tid, $pid)
	{
		global $_G;
		$return = array();
		foreach (C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'pid', $pid) as $attach) {
			if ($attach['remote']) {
				$attach['attachment'] = $_G['setting']['ftp']['attachurl'] . 'forum/' . $attach['attachment'];
				$attach['attachment'] = !(substr($attach['attachment'], 0, 7) == 'http://') ? 'http://' . $attach['attachment'] : $attach['attachment'];
			} else {
				$attach['attachment'] = $_G['setting']['attachurl'] . 'forum/' . $attach['attachment'];
			}
			$return[] = $attach;
		}
		return $return;
	}
	public function gbk_to_utf8($data)
	{
		if (is_array($data)) {
			foreach ($data as $k => $v) {
				if (is_array($v)) {
					$data[$k] = $this->gbk_to_utf8($v);
				} else {
					$data[$k] = iconv('gbk', 'utf-8', $v);
				}
			}
			return $data;
		}
		$data = iconv('gbk', 'utf-8', $data);
		return $data;
	}
}
function curl_post($url, $data, $header, $post = 1)
{
	$ch = curl_init();
	$res = curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_POST, $post);
	if ($post) {
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec($ch);
	if ($result == false) {
		if ($this->BodyType == 'json') {
			$result = '{"statusCode":"172001","statusMsg":"�������"}';
		} else {
			$result = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Response><statusCode>172001</statusCode><statusMsg>�������</statusMsg></Response>';
		}
	}
	curl_close($ch);
	return $result;
}