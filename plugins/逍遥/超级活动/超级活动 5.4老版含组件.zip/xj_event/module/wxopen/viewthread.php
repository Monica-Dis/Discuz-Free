<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();



$tid=intval($_GET['tid']);
$post = DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." WHERE tid=$tid AND first=1");
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');
$post['message'] = preg_replace("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = preg_replace("/\[img\=.+?\](.+?)\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = discuzcode($post['message'],0,0,0,1,1,1,0,0,0,$post['authorid'],0,$post['pid'],$post['dateline']);
$post['message'] = preg_replace("/\[xjimg\](.+?)\[\/xjimg\]/i", "<img src='$1' width='100%'>", $post['message']);
$post['message'] = str_replace(chr(0).chr(0).chr(0).'xj_event','',$post['message']);
$attachs = $wxopen->getattachs($tid,$post['pid']);
foreach($attachs as $att){
	if($items['activityaid'] != $att['aid']){
		$att['width'] = $att['width']>900?900:$att['width'];
		if(strpos($post['message'],'[attach]'.$att['aid'].'[/attach]')===false){
			$post['message'] = $post['message']."<div style='text-align:center;padding-top:10px;'><img src='source/plugin/xj_event/images/picloading.gif' data-original='".$att['attachment']."' width='".($att['width']>300?'100%':$att['width'])."'></div>";
		}else{
			if($att['isimage']==0){
				$att['filesize'] = number_format($att['filesize'] / 1024,2);
				$post['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<a href='".$att['attachment']."'>".$att['filename']."</a> (".$att['filesize']." KB)", $post['message']);
			}else{
				$post['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<img src='".$_G['siteurl'].$att['attachment']."' width='".($att['width']>300?'100%':$att['width'])."'>", $post['message']);
			}
		}
	}else{
		$post['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "", $post['message']);
	}
}


$post['message'] = preg_replace("/<font color\=\"(.+?)\">/i", "<span style=\"color:$1\">", $post['message'] );
$post['message'] = preg_replace("/<font face\=\"(.+?)\">/i", "<span>", $post['message'] );
$post['message'] = preg_replace("/<font style\=\"(.+?)\">/i", "<span>", $post['message'] );
$post['message'] = preg_replace("/<font size\=\"(.+?)\">/i", "<span>", $post['message'] );
$post['message'] = str_replace('</font>','</span>',$post['message']);



$post['dateline'] = dgmdate($post['dateline'],'d');
$post = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($post):$post;
echo json_encode($post);
exit;


?>