<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();


	
	$perpage = 10; //每页数
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventthread')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.sort=1");
	$page = $_GET['page']?$_GET['page']:1;
	/*
	if(@ceil($listcount/$perpage) < $page) {
		$page = 1;
	}
	*/
	$start_limit = ($page - 1) * $perpage;
	
	
	$threadlist = DB::fetch_all("SELECT A.*,B.subject FROM ".DB::table('xj_eventthread')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.sort=1 ORDER BY B.dateline DESC LIMIT $start_limit,$perpage");
	foreach($threadlist as $key => $value){
		$value['activityaid'] = DB::result_first("SELECT aid FROM ".DB::table('forum_attachment')." WHERE tid=".$value['tid']." ORDER BY aid");
		
		
		if($value['activityaid']){
			$value['activityaid_url'] = $value['activityaid']?getforumimg($value['activityaid'],0,500,320):'static/image/common/nophoto.gif';
			$value['activityaid_url'] = $_G['siteurl'].$value['activityaid_url'];
		}elseif(!$value['activityaid'] && !$value['activityaid_url']){
			$value['activityaid_url'] = $_G['siteurl'].'static/image/common/nophoto.gif';
		}
		$threadlist[$key]['activityaid_url'] = $value['activityaid_url'];
		$threadlist[$key]['subject'] = $value['subject'];
	}

	$result = $threadlist;
	
	
	$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
	echo json_encode($result);
	exit;


?>