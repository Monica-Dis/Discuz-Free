<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();


$threekey = addslashes($_GET['threekey']);
$tid = intval($_GET['tid']);
$mysession = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_session')." WHERE threekey='$threekey'");
$_G['uid'] = intval($mysession['uid']);


if($_GET['action'] == 'my'){
	$member = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE uid=".$_G['uid']);
	$result = array();
	$result['username'] = $member['username'];
	$result['avatar'] = avatar($_G['uid'], 'middle', true, false, true).'?random='.random(2);
	//�μӻ����
	$result['cjeventnumber'] = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE first = 1 AND uid=".$_G['uid']);

	//����Ϣ
	if($_G['cache']['plugin']['xj_card']['cardname']){	
		$card = DB::fetch_first("SELECT * FROM ".DB::table('xj_card')." WHERE uid=".$_G['uid']);
		$card['jzdate'] = date('Y-m-d',$card['jzdate']);
		$result['card'] = $card;
		if($card['cardno'] && $card['state']>0){
			$result['cardstatetext'] = '�Ѽ��� '.$card['jzdate'].'֮ǰ��Ч';
		}else{
			$result['cardstatetext'] = 'δ����';
		}
	}



	$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
	echo json_encode($result);
	exit;
}


if($_GET['action'] == 'event'){
	
	
	$perpage = 10; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." A INNER JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid INNER JOIN ".DB::table('xj_event')." C ON A.tid=C.tid WHERE A.first=1 AND A.uid=".$_G['uid']."");
	$page = $_GET['page']?$_GET['page']:1;
	/*
	if(@ceil($listcount/$perpage) < $page) {
		$page = 1;
	}
	*/
	$start_limit = ($page - 1) * $perpage;
	
	
	$eventlist = DB::fetch_all("SELECT A.*,B.subject,C.*,A.verify as applyverify,A.uid as applyuid FROM ".DB::table('xj_eventapply')." A INNER JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid INNER JOIN ".DB::table('xj_event')." C ON A.tid=C.tid WHERE A.first=1 AND A.uid=".$_G['uid']." ORDER BY A.dateline DESC LIMIT $start_limit,$perpage");
	foreach($eventlist as $key => $value){
		if($value['activityaid']){
			$value['activityaid_url'] = $value['activityaid']?getforumimg($value['activityaid'],0,500,320):'static/image/common/nophoto.gif';
			//$value['activityaid_url'] = $_G['siteurl'].$value['activityaid_url'];
		}elseif(!$value['activityaid'] && !$value['activityaid_url']){
			$value['activityaid_url'] = $_G['siteurl'].'static/image/common/nophoto.gif';
		}
		if($value['activitybegin']<= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdbmz');
			$value['eventstatebgcolor'] = '#88d268';
		}elseif($_G['timestamp']<=$value['starttime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdwks');
			$value['eventstatebgcolor'] = '#f45f05';
		}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdjxz');
			$value['eventstatebgcolor'] = '#dc696a';
		}elseif($_G['timestamp']>=$value['endtime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdyjs');
			$value['eventstatebgcolor'] = '#ccc';
		}
		
		$eventlist[$key]['setting'] = unserialize($value['setting']);
		$eventlist[$key]['eventstatetext'] = $value['eventstatetext'];
		$eventlist[$key]['eventstatebgcolor'] = $value['eventstatebgcolor'];
		$eventlist[$key]['starttime_str'] = date('Y-m-d',$value['starttime']);
		$eventlist[$key]['activityaid_url'] = $value['activityaid_url'];
		$eventlist[$key]['dateline_str'] = date('Y-m-d',$value['dateline']); 

	}
	$result = array();
	$result['eventlist'] = $eventlist;
	
	$result = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($result):$result;
	echo json_encode($result);
	exit;
}


/**
* ͨ��aid��ȡͼƬ����
*/
function getpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['siteurl'].$_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}
//From: Dism��taobao��com
?>