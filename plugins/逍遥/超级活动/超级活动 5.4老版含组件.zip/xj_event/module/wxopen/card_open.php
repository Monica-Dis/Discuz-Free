<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen    = new xj_eventwxopen();
$threekey  = addslashes($_GET['threekey']);
$mysession = DB::fetch_first("SELECT * FROM " . DB::table('xj_wxopen_session') . " WHERE threekey='$threekey'");
$_G['uid'] = intval($mysession['uid']);

loadcache('xj_card');

$data = array();

if ($_GET['action'] == 'getcardno') {

    $count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card') . " WHERE state = 0");
    for ($i = 1; $i <= 2; $i++) {
        $num                = mt_rand(0, $count - 1);
        $data['cardlist'][] = DB::fetch_first("SELECT * FROM " . DB::table('xj_card') . " WHERE state = 0 LIMIT $num,1");
    }

} elseif ($_GET['action'] == 'openfull') {

    /*
    if (substr($_GET['system'], 0, 3) == 'iOS') {
        $_GET = $wxopen->utf8_to_gbk($_GET);
    }
    */


    if (empty($_GET['realname'])) {
        $data['full']    = 2;
        $data['message'] = '����д��ʵ����';
    } elseif (!preg_match("/1[34578]{1}\d{9}$/", $_GET['mobile'])) {
        $data['full']    = 2;
        $data['message'] = '����д��ȷ���ֻ�����';
    } elseif (empty($_GET['cardno'])) {
        $data['full']    = 2;
        $data['message'] = '��ѡ�񿨺�';
    } else {

        $count = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card') . " WHERE uid=" . $_G['uid']);
        if ($count > 0) {
            $data['full']    = 2;
            $data['message'] = '���Ѿ�ѡ��������޷�����';
            $data            = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($data) : $data;
            echo json_encode($data);
            exit;
        }
        $cardno           = addslashes($_GET['cardno']);
        $card             = array();
        $card['uid']      = intval($_G['uid']);
        //$card['realname'] = $_G['charset'] == 'gbk' ?iconv('utf-8','gbk',$_POST['realname']):$_POST['realname'];
        $card['realname'] = $_GET['realname'];
        $card['mobile']   = addslashes($_GET['mobile']);
        DB::update('xj_card', $card, "cardno='$cardno'");
        //��������������������¼
        if ($_GET['invitecode']) {
            $invite = DB::fetch_first("SELECT * FROM " . DB::table('xj_card_invitecode') . " WHERE invitecode='" . addslashes($_GET['invitecode']) . "'");
            if ($invite['uid'] > 0 && $invite['uid'] != $_G['uid']) {
                $invitelog               = array();
                $invitelog['invitecode'] = addslashes($_GET['invitecode']);
                $invitelog['to_uid']     = $_G['uid'];
                $invitelog['to_cardno']  = $cardno;
                $invitelog['dateline']   = TIMESTAMP;
                DB::insert('xj_card_invite_log', $invitelog);
            }
        }
        $data['full'] = 1;
    }

} else {

    $data['cardpic']   = $_G['cache']['xj_card']['style']['cardpic'];
    $data['cardname']  = $_G['cache']['plugin']['xj_card']['cardname'];
    $data['cardprice'] = $_G['cache']['plugin']['xj_card']['card_price'];
    $data['doc_zstq']  = stripslashes($_G['cache']['xj_card']['doc_zstq']);
    $data['doc_zstq'] = str_replace('src="/','style="width:100%;" src="'.$_G['siteurl'].'/',$data['doc_zstq']);
    $data['doc_syxz']  = stripslashes($_G['cache']['xj_card']['doc_syxz']);
    $data['doc_syxz'] = str_replace('src="/','style="width:100%;" src="'.$_G['siteurl'].'/',$data['doc_syxz']);

    if ($_G['uid'] > 0) {
        $data['card']   = DB::fetch_first("SELECT * FROM " . DB::table('xj_card') . " WHERE uid=" . $_G['uid']);
        $data['jzdate'] = date('Y-m-d', $data['card']['jzdate']);
        if ($data['card']['cardno'] && $data['card']['state'] > 0) {
            $data['cardstate']     = '�Ѽ���';
            $data['cardopenstate'] = 1;
        } else {
            $data['cardstate'] = 'δ����';
            if ($data['card']['cardno']) {
                $data['cardopenstate'] = 2;
            } else {
                $data['cardopenstate'] = 3;
            }
        }
        if ($data['card']['cardno']) {
            $data['cardno'] = $data['card']['cardno'];
        } else {
            $data['cardno'] = '��δ����';
        }
        if ($data['card']['state'] > 0) {
            $data['cardbtntext'] = '����ʹ��';
        } else {
            $data['cardbtntext'] = '����ʹ��';
        }
    }
//�����Ѿ��ۿ���
    $data['opencardnumber'] = DB::result_first("SELECT count(*) FROM " . DB::table('xj_card') . " WHERE state=1");
    $data['opencardnumber'] = $_G['cache']['plugin']['xj_card']['card_number'] + $data['opencardnumber'];

}

$data = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($data) : $data;
echo json_encode($data);
