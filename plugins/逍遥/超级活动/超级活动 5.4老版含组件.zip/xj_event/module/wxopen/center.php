<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();





if($_GET['pc']){
	if($_GET['pc'] == 1){
		$sqlstr .= " AND A.postclass=1";
		if($_GET['classid']){
			$sqlstr .= " AND A.offlineclass=".intval($_GET['classid']);
		}
	}elseif($_GET['pc'] == 2){
		$sqlstr .= " AND A.postclass=2";
		if($_GET['classid']){
			$sqlstr .= " AND A.onlineclass=".intval($_GET['classid']);
		}
	}elseif($_GET['pc'] == 3){
		$joinstr = " left join ".DB::table('xj_eventapply')." C on A.tid=C.tid ";
		$sqlstr .= " AND C.uid = ".$_G['uid'];
	}elseif($_GET['pc'] == 4){
		$sqlstr .= " AND B.authorid=".$_G['uid'];
	}
}


$perpage = 10; //ÿҳ��
$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A inner join ".DB::table('forum_thread')." B on A.tid=B.tid ".$joinstr."WHERE 1=1 AND B.displayorder>=0 ".$sqlstr." ORDER BY A.eid");
$page = $_GET['page']?$_GET['page']:1;
//if(@ceil($listcount/$perpage) < $page) {
//	$page = 1;
//}
$start_limit = ($page - 1) * $perpage;


$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A inner join ".DB::table('forum_thread')." B on A.tid=B.tid ".$joinstr."WHERE 1=1 AND B.displayorder>=0 ".$sqlstr." ORDER BY A.eventorder DESC, B.dateline DESC LIMIT $start_limit,$perpage");
$toplist = array();
while($value = DB::fetch($query)){
	$value['subject'] = cutstr($value['subject'],50);
	//��ȡ��������
	$value['zynumber'] = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventthread')." WHERE eid=".$value['eid']);
	$value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']." and verify=1");
	$value['applynumber'] = $value['applynumber']?$value['applynumber']:0;
    if (substr($value['activityaid_url'], 0, 4) != 'data' && substr($value['activityaid_url'], 0, 4) != 'http') {
        $value['activityaid_url'] = $_G['siteurl'].'data/attachment/forum/' . $value['activityaid_url'];
    } else {
    	if(substr($value['activityaid_url'], 0, 4) != 'http'){
    		$value['activityaid_url'] = $_G['siteurl'].$value['activityaid_url'];
    	}else{
    		$value['activityaid_url'] = $value['activityaid_url'];
    	}
    }



	//�����
	if($value['event_number']>0){
		$value['event_number'] = $value['event_number'];
	}else{
		$value['event_number'] = $_G['charset']=='gbk'?'����':iconv('gbk','utf8','����');;
	}
	

	
	
	$value['starttimetext'] = date('Y-m-d',$value['starttime']);
	$value['message'] = DB::result_first("SELECT message FROM ".DB::table('forum_post')." WHERE tid=".$value['tid']);
	//$value['message'] = messagecutstr($value['message'],50);
	$value['setting'] = unserialize($value['setting']);
	$value['setting']['session'] = '';
	
	
	$value['subject'] = $value['subject'];
	if($value['activitybegin']<= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']){
		$value['eventstatetext'] = lang('plugin/xj_event', 'hdbmz');
		$value['eventstatebgcolor'] = '#88d268';
	}elseif($_G['timestamp']<=$value['starttime']){
		$value['eventstatetext'] = lang('plugin/xj_event', 'hdwks');
		$value['eventstatebgcolor'] = '#f45f05';
	}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']){
		$value['eventstatetext'] = lang('plugin/xj_event', 'hdjxz');
		$value['eventstatebgcolor'] = '#dc696a';
	}elseif($_G['timestamp']>=$value['endtime']){
		$value['eventstatetext'] = lang('plugin/xj_event', 'hdyjs');
		$value['eventstatebgcolor'] = '#ccc';
	}
	
	if(empty($value['setting']['event_url'])){  //���������������
		$toplist[] = $value;
	}
}


$toplist = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($toplist):$toplist;
$toplist = json_encode($toplist);
echo $toplist;
exit;

/**
* ͨ��aid��ȡͼƬ����
*/
function getpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['siteurl'].$_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}
//From: Dism��taobao��com
?>