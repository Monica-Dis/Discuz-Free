<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/cache'); //加载缓存类 
require_once libfile('function/member');


//调用微信支付设置
if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
@include DISCUZ_ROOT.'source/plugin/xj_event/module/wxopen/include/wxpayfunc.php';

$appid = $wxset['xcx_appid'];
$appsecret = $wxset['xcx_appsecret'];


$code = $_GET['code'];
$res = json_decode(get("https://api.weixin.qq.com/sns/jscode2session?appid=$appid&secret=$appsecret&js_code=$code&grant_type=authorization_code"),true);

if(!empty($res['session_key']) && !empty($res['openid'])){
	$openid = $res['openid'];
	$sessionkey = $res['session_key'];
	DB::delete('xj_wxopen_session',"openid='$openid'");
	$wxopen = array();
	$wxopen['sessionkey'] = $sessionkey;
	$wxopen['dateline'] = $_G['timestamp'];
	$login = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_login')." WHERE openid='$openid'");


	//过滤掉用户表中已删除的用户
	$c = DB::result_first("SELECT count(*) FROM ".DB::table('common_member')." WHERE uid=".intval($login['uid']));
	if($c<1){
		$login = array();
		DB::delete("xj_wxopen_login","openid='$openid'");
	} 

	/*
	if($login['openid']){
		DB::update('xj_wxopen_login',$wxopen,"openid='$openid'");
	}else{
		$wxopen['openid'] = $result['openid'];
		DB::insert('xj_wxopen_login',$wxopen);
	}
	*/
	$threekey = getRandChar(32);
	
	//绑定原用户名的操作
	if($_GET['action'] == 'binding'){
		$result = array();
		if($login['uid']>0){   //如果这个微信openid已经绑定过
			$result['full'] = 2;
			echo json_encode($result);
			exit();
		}
		
		$username = $_GET['username'];
		$password = $_GET['password'];
		$member = DB::fetch_first("SELECT * FROM ".DB::table('ucenter_members')." WHERE username = '$username'");
		$passwordmd5 = preg_match('/^\w{32}$/', $password) ? $password : md5($password);
		$passwordmd5 = md5($passwordmd5.$member['salt']);
		if($member['password'] != $passwordmd5){  //用户名或密码不正确
			$result['full'] = 3;
			echo json_encode($result);
			exit();
		}
		
		$count = DB::result_first("SELECT count(*) FROM ".DB::table('xj_wxopen_login')." WHERE uid=".$member['uid']);
		if($count > 0){   //用户已经被其它微信openid 绑定
			$result['full'] = 4;
			echo json_encode($result);
			exit();
		}
		
		
		
		
		$wxopen['openid'] = $openid;
		$wxopen['uid'] = $member['uid'];
		DB::insert('xj_wxopen_login',$wxopen);
		
		$result['full'] = 1;
		$result['uid'] = $member['uid'];
		$result['session_key'] = $sessionkey;
		$result['openid'] = $openid;
		echo json_encode($result);
		exit;

	}
	
	
	
	
	
	
	

	$result = array();
	if($login['uid']){
		$wxsession = array();
		$wxsession['threekey'] = $threekey;
		$wxsession['sessionkey'] = $sessionkey;
		$wxsession['openid'] = $openid;
		$wxsession['uid'] = $login['uid'];
		$wxsession['unionid'] = $login['unionid'];
		$wxsession['dateline'] = $_G['timestamp'];
		
		
		DB::insert('xj_wxopen_session',$wxsession);
		$result['full'] = 1;
		$result['openid'] = $openid;
		$result['threesession'] = $threekey;
		/*
		$username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$login['uid']);
		if($username){
			$uid = $login['uid'];
			$member = getuserbyuid($uid, 1);
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			C::t('common_member_status')->update($uid, array(
				'lastip' => $_G['clientip'],
				'lastvisit' => TIMESTAMP,
				'lastactivity' => TIMESTAMP
			));
			$result['full'] = 1;
			$result['uid'] = $uid;
		}else{
			$result['full'] = 2;
			$result['openid'] = $openid;
		}
		*/	
	}else{
		if($_GET['action'] == 'autologin'){
		}else{
		//login表中没有就新建
		DB::delete('xj_wxopen_login',"openid='$openid' AND uid=0");
		$wxopen['openid'] = $openid;
		DB::insert('xj_wxopen_login',$wxopen);
		$result['full'] = 2;
		$result['openid'] = $openid;
		}
	}

}else{
	$result = array();
}

//savecache('xj_event_session_key',$session_key);
echo json_encode($result);


?>