<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@include DISCUZ_ROOT.'./source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();
$threekey = addslashes($_GET['threekey']);
$mysession = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_session')." WHERE threekey='$threekey'");
$_G['uid'] = intval($mysession['uid']);

loadcache('xj_card');

$data = array();

$data['cardpic'] = $_G['cache']['xj_card']['style']['cardpic'];
$data['avatar'] = $_G['uid']?avatar($_G['uid'], 'middle', true, false, true) . '?random=' . random(2):$_G['siteurl'].'uc_server/images/noavatar_middle.gif';
$data['cardname'] = $_G['cache']['plugin']['xj_card']['cardname'];
$data['cardbtntext'] = '����ʹ��';

if ($_G['uid'] > 0) {
    $data['card'] = DB::fetch_first("SELECT * FROM " . DB::table('xj_card') . " WHERE uid=" . $_G['uid']);
    if($data['card']['cardno'] && $data['card']['state']>0){
    	$data['cardstate'] = '�Ѽ���';
    }else{
    	$data['cardstate'] = 'δ����';
    }
    if($data['card']['cardno']){
    	$data['cardno'] = $data['card']['cardno'];
    }else{
    	$data['cardno'] = '��δ����';
    }
    if($data['card']['state']>0){
    	$data['cardbtntext'] = '����ʹ��';
    }else{
    	$data['cardbtntext'] = '����ʹ��';
    }
}
//��Ȩ����
$data['cardtq'] = explode("\n", $_G['cache']['plugin']['xj_card']['tq_info']);
//ͼ�굼��
loadcache('xj_card_icon');
$data['icon'] = array();
foreach($_G['cache']['xj_card_icon'] as $value){
	$value['icontext'] = $value['icontext'];
	$value['iconpic'] = $value['iconpic'];
	$data['icon'][] = $value;
}
//���ûõ�
loadcache('xj_card_index_slider');
if ($_G['cache']['xj_card_index_slider']) {
    $sliderlist = DB::fetch_all("SELECT A.tid,A.activityaid,A.activityaid_url,B.subject FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid WHERE A.tid in(" . $_G['cache']['xj_card_index_slider'] . ") LIMIT 0,4");
    foreach ($sliderlist as $key => $value) {
        if ($value['activityaid']) {
            $value['activityaid_url'] = $value['activityaid'] ? getpicurl($value['activityaid'], $value['tid']) : $_G['siteurl'].'static/image/common/nophoto.gif';
        } elseif (!$value['activityaid'] && !$value['activityaid_url']) {
            $value['activityaid_url'] = $_G['siteurl'].'static/image/common/nophoto.gif';
        }
        $sliderlist[$key] = $value;
    }
    $data['cardslider'] = $sliderlist;
}else{
	$data['cardslider'] = 1;
}




$data = $_G['charset']=='gbk'?$wxopen->gbk_to_utf8($data):$data;
echo json_encode($data);


/**
* ͨ��aid��ȡͼƬ����
*/
function getpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['siteurl'].$_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}
//From: dis'.'m.tao'.'bao.com
?>