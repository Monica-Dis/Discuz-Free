<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

@include DISCUZ_ROOT . './source/plugin/xj_event/module/wxopen/include/wxopen.class.php';
$wxopen = new xj_eventwxopen();
//echo $wxopen->test();

$tid = intval($_GET['tid']);

if ($_GET['action'] == 'replylist') {
    $page = intval($_GET['page']);
    require_once libfile('function/discuzcode');
    if ($_GET['reply']) {
        $postlist = C::t('forum_post')->fetch_all_by_tid('tid:' . $tid, $tid, true, 'DESC', 0, 1, 0, 0, $_G['uid']);
    } else {
        $postlist = C::t('forum_post')->fetch_all_by_tid('tid:' . $tid, $tid, true, 'asc', ($page - 1) * 10, 10, 0, 0);
    }
    $result = array();
    foreach ($postlist as $key => $value) {
        $value['avatar']   = avatar($value['authorid'], 'middle', true, false, true) . '?random=' . random(2);
        $value['dateline'] = dgmdate($value['dateline']);
        $value['message']  = discuzcode($value['message'], 0, 0, 0, 1, 1, 1, 0, 0, 0, $value['authorid'], 0, $value['pid'], $value['dateline']);
        $value['message']  = str_replace('<blockquote>', '<blockquote>' . lang('plugin/xj_event', 'yingyong') . ':', $value['message']);

        $attachs = $wxopen->getattachs($tid, $value['pid']);
        foreach ($attachs as $att) {
            $att['width'] = $att['width'] > 900 ? 900 : $att['width'];
            if (strpos($value['message'], '[attach]' . $att['aid'] . '[/attach]') === false) {
                $value['message'] = $value['message'] . "<div style='text-align:center;padding-top:10px;'><img src='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'></div>";
            } else {
                if ($att['isimage'] == 0) {
                    $att['filesize']  = number_format($att['filesize'] / 1024, 2);
                    $value['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<a href='" . $att['attachment'] . "'>" . $att['filename'] . "</a> (" . $att['filesize'] . " KB)", $value['message']);
                } else {
                    $value['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<img src='" . $_G['siteurl'] . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'>", $value['message']);
                }
            }
        }
        $result[] = $value;
    }

    $result = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($result) : $result;
    echo json_encode($result);
    exit;
}

$items   = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid WHERE A.tid=$tid");
$setting = $items['setting'] = unserialize($items['setting']);

if (substr($items['activityaid_url'], 0, 4) != 'data' && substr($items['activityaid_url'], 0, 4) != 'http') {
    $items['activityaid_url'] = $_G['siteurl'] . 'data/attachment/forum/' . $items['activityaid_url'];
} else {
    if (substr($items['activityaid_url'], 0, 4) != 'http') {
        $items['activityaid_url'] = $_G['siteurl'] . $items['activityaid_url'];
    } else {
        $items['activityaid_url'] = $items['activityaid_url'];
    }
}
$imgurl = $shareimgurl = $items['activityaid_url'];





//��ť��ʾ״̬
if ($items['activitybegin'] > $_G['timestamp']) {
    $items['joinbtnstate'] = 1; //����δ��ʼ
} elseif ($items['activityexpiration'] < $_G['timestamp']) {
    $items['joinbtnstate'] = 2; //�����ѽ���
} else {
    $items['joinbtnstate'] = 3; //������
}

//�״̬�ж�
if ($_G['timestamp'] > $items['starttime'] && $_G['timestamp'] < $items['endtime']) {
    $items['eventstate']         = lang('plugin/xj_event', 'jinxingzhong');
    $items['eventstate_bgcolor'] = '#69bf35';
} elseif ($_G['timestamp'] < $items['starttime']) {
    $items['eventstate']         = lang('plugin/xj_event', 'weikaishi');
    $items['eventstate_bgcolor'] = '#ffc548';
} elseif ($_G['timestamp'] > $items['endtime']) {
    $items['eventstate']         = lang('plugin/xj_event', 'yijieshu');
    $items['eventstate_bgcolor'] = '#c5c5c5';
}

$items['imgurl']             = $imgurl;
$items['starttime']          = dgmdate($items['starttime'], 'Y-m-d H:i');
$items['endtime']            = dgmdate($items['endtime'], 'dt');
$items['activitybegin']      = dgmdate($items['activitybegin'], 'Y-m-d H:i');
$items['activityexpiration'] = dgmdate($items['activityexpiration'], 'Y-m-d H:i');
//��ͨ����˱�������
$applycountnumber_verify = intval(DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"));
//ʣ������
if ($items['event_number'] > 0) {
    $items['event_number_shenyu'] = $items['event_number'] - $applycountnumber_verify;
    $items['event_number_shenyu'] = $items['event_number_shenyu'] . lang('plugin/xj_event', 'ren');
    $items['event_number_shenyu'] = $items['event_number_shenyu'];
} else {
    $items['event_number_shenyu'] = lang('plugin/xj_event', 'buxian');
}
//������
$items['author'] = $items['author'];
//����
$eventcost = '';
if ($items['setting']['cost']) {
    $eventcost = 'cost';
    foreach ($items['setting']['cost'] as $key => $value) {
        $items['setting']['cost'][$key]['cost_name'] = $value['cost_name'];

        $items['setting']['cost'][$key]['cost_youhuihou'] = $value['cost_price'] - $value['cost_youhui'];
        if ($items['setting']['cost'][$key]['cost_youhuihou'] > 0) {
            $items['setting']['cost'][$key]['cost_youhuihou'] .= lang('plugin/xj_event', 'yuan');
        } else {
            $items['setting']['cost'][$key]['cost_youhuihou'] = lang('plugin/xj_event', 'mianfei');
        }

    }
} else {
    if ($setting['eventaa']) {
        $eventcost .= 'AA';
        if ($items['use_cost'] > 0) {
            $eventcost .= $items['use_cost'] . lang('plugin/xj_event', 'yuan') . '/' . lang('plugin/xj_event', 'ren') . ' ' . lang('plugin/xj_event', 'zuoyou');
        }
    } else {
        if ($items['use_cost'] <= 0) {
            $eventcost .= lang('plugin/xj_event', 'mianfei');
        } else {
            $eventcost .= $items['use_cost'] . lang('plugin/xj_event', 'yuan') . '/' . lang('plugin/xj_event', 'ren');
        }
    }
    if ($setting['vip_discount'] > 0) {
        $items['cose_youhuihou'] = $items['use_cost'] - $setting['vip_discount'];
        if ($items['cose_youhuihou'] > 0) {
            $items['cose_youhuihou'] = $items['cose_youhuihou'] . lang('plugin/xj_event', 'yuan');
        } else {
            $items['cose_youhuihou'] = lang('plugin/xj_event', 'mianfei');
        }

    }

}
$items['eventcost'] = $eventcost;
if ($_G['cache']['plugin']['xj_card']['cardname']) {
    $items['youhuiname'] = $_G['cache']['plugin']['xj_card']['cardname'];
} else {
    $items['youhuiname'] = 'VIP';
}

//����֧�����õĻ���
$items['extcredits_title'] = $_G['setting']['extcredits'][$items['use_extcredits']]['title'];
$items['extcredits_title'] = $items['extcredits_title'];

//������Ŀ
foreach ($items['setting']['moreitem'] as $key => $value) {
    $items['setting']['moreitem'][$key]['itemname']    = $value['itemname'];
    $items['setting']['moreitem'][$key]['itemcontent'] = $value['itemcontent'];
}
//��������
$applycountnumber          = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid'");
$applycountnumber          = $applycountnumber ? $applycountnumber : 0;
$items['applycountnumber'] = $applycountnumber;
//��ͨ����˱�������
$applycountnumber_verify          = intval(DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"));
$items['applycountnumber_verify'] = $applycountnumber_verify;
//ʣ������
if ($items['event_number'] > 0) {
    $applycountnumber_remain = $items['event_number'] - $applycountnumber_verify;
}
$items['applycountnumber_remain'] = $applycountnumber_remain;
//�����б�TOP5
$query     = DB::query("SELECT * FROM " . DB::table('xj_eventapply') . " A LEFT JOIN " . DB::table('common_member') . " B ON A.uid=B.uid WHERE tid=$tid AND first=1 ORDER BY A.dateline DESC LIMIT 0,4");
$applylist = array();
while ($value = DB::fetch($query)) {
    $value['avatar']   = avatar($value['uid'], 'middle', true, false, true) . '?random=' . random(2);
    $value['username'] = showusername($value['username'], 8);
    $value['username'] = $value['username'];
    $applylist[]       = $value;
}
$items['applylist'] = $applylist;

//��������
$post = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE tid=$tid AND first=1");
//ȥ����������APP���ӱ�������
$post['message'] = preg_replace("/\<\!--bmstart--\>.+?\<\!--bmend--\>/i", "", $post['message']);
//$post['message'] = my_discuzcode($post['message']);
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');
$post['message'] = preg_replace("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = preg_replace("/\[img\=.+?\](.+?)\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = discuzcode($post['message'], 0, 0, 0, 1, 1, 1, 0, 0, 0, $post['authorid'], 0, $post['pid'], $post['dateline']);
$post['message'] = preg_replace("/\[xjimg\](.+?)\[\/xjimg\]/i", "<img src='$1' width='100%'>", $post['message']);
$post['message'] = str_replace(chr(0) . chr(0) . chr(0) . 'xj_event', '', $post['message']);
$attachs         = $wxopen->getattachs($tid, $post['pid']);
foreach ($attachs as $att) {
    if ($items['activityaid'] != $att['aid']) {
        $att['width'] = $att['width'] > 900 ? 900 : $att['width'];
        if (strpos($post['message'], '[attach]' . $att['aid'] . '[/attach]') === false) {
            $post['message'] = $post['message'] . "<div style='text-align:center;padding-top:10px;'><img src='source/plugin/xj_event/images/picloading.gif' data-original='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'></div>";
        } else {
            if ($att['isimage'] == 0) {
                $att['filesize'] = number_format($att['filesize'] / 1024, 2);
                $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<a href='" . $att['attachment'] . "'>" . $att['filename'] . "</a> (" . $att['filesize'] . " KB)", $post['message']);
            } else {
                $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<img src='" . $_G['siteurl'] . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'>", $post['message']);
            }
        }
    } else {
        $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "", $post['message']);
    }
}
$items['postmessage'] = $post['message'];
$items['postmessage'] = preg_replace("/<font color\=\"(.+?)\">/i", "<span style=\"color:$1\">", $items['postmessage']);
$items['postmessage'] = preg_replace("/<font face\=\"(.+?)\">/i", "<span>", $items['postmessage']);
$items['postmessage'] = preg_replace("/<font style\=\"(.+?)\">/i", "<span>", $items['postmessage']);
$items['postmessage'] = preg_replace("/<font size\=\"(.+?)\">/i", "<span>", $items['postmessage']);
$items['postmessage'] = str_replace('</font>', '</span>', $items['postmessage']);
//$items['postmessage'] = str_replace('<br />','<br>',$items['postmessage']);

//�ж��Ƿ����ÿͷ�
if ($wxopen_config['customservice']['open']) {
    $items['customservice'] = $wxopen_config['customservice']['open'];
}

$items = $_G['charset'] == 'gbk' ? $wxopen->gbk_to_utf8($items) : $items;
echo json_encode($items);

function showusername($username, $len)
{
    global $_G;
    $return = $username;
    if (function_exists('mb_substr')) {
        if (mb_strlen($username, $_G['charset']) > $len) {
            $return = mb_substr($username, 0, $len, $_G['charset']) . '...';
        }
    }
    return $return;
}

/**
 * ͨ��aid��ȡͼƬ����
 */
function getpicurl($aid, $tid)
{
    global $_G;
    $return = '';
    if ($aid) {
        $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM " . DB::table(getattachtablebytid($tid)) . " WHERE aid='{$aid}'");
        if ($picatt['remote']) {
            $picatt['attachment'] = $_G['setting']['ftp']['attachurl'] . 'forum/' . $picatt['attachment'];
            $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://' . $picatt['attachment'] : $picatt['attachment'];
        } else {
            $picatt['attachment'] = $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/' . $picatt['attachment'];
        }
    }
    $return = $picatt['attachment'];
    return $return;
}
