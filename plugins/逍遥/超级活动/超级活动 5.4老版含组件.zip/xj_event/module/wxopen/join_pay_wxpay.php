<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//调用活动核心类
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();



$threekey = addslashes($_GET['threekey']);
$tid = intval($_GET['tid']);
$mysession = DB::fetch_first("SELECT * FROM ".DB::table('xj_wxopen_session')." WHERE threekey='$threekey'");
$_G['uid'] = $mysession['uid'];





//调用微信支付设置
if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}

@include DISCUZ_ROOT.'source/plugin/xj_event/module/wxopen/include/wxpayfunc.php';
require_once libfile('function/cache');



$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = $tid"));
$items['setting'] = $setting = unserialize($items['setting']);
$items['subject'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$items['subject']):$items['subject'];
$apply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$_G['uid']);
foreach($apply as $key=>$value){
	$apply[$key]['ufielddata'] = unserialize($value['ufielddata']);
}
$extcredits = $_G['setting']['extcredits'][$items['use_extcredits']]['title'];
//计算支付的积分和金额
$my = array();
if($items['use_extcredits']){
$my['myextedits'] = DB::result_first("SELECT extcredits".$items['use_extcredits']." FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['uid']);
}
$my['total_price'] = 0;
$my['total_credits'] = 0;
if($setting['cost']){  //多种报名方式
	if($setting['nodaibaoming']){ //代报名不填资料
		foreach($items['setting']['cost'] as $key=>$value){
			$tmp = array();
			$tmp['costname'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$value['cost_name']):$value['cost_name']; 
			$tmp['number'] = $apply[0]['ufielddata']['cost'.$key];
			$tmp['price'] = $value['cost_price'];
			$tmp['credits'] = $value['cost_credits'];
			$tmp['total_price'] = $tmp['price'] * $tmp['number'];
			$tmp['total_credits'] = $tmp['credits'] * $tmp['number'];
			$my['join'][] = $tmp;
			$my['total_price'] = $my['total_price'] + $tmp['total_price'];
			$my['total_credits'] = $my['total_credits'] + $tmp['total_credits'];
		}
	}else{   //代报名填写资料方式
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
		$my['join'] = array();
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$costclass = $value['ufielddata']['costclass'];
			$my['join'][$costclass]['costname'] = $_G['charset']=='gbk'?iconv("GBK", "UTF-8",$items['setting']['cost'][$costclass]['cost_name']):$items['setting']['cost'][$costclass]['cost_name'];
			$my['join'][$costclass]['number'] = $my['join'][$costclass]['number'] + 1; 
			$my['join'][$costclass]['price'] = $my['join'][$costclass]['price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['credits'] = $my['join'][$costclass]['credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			$my['join'][$costclass]['total_price'] = $my['join'][$costclass]['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['join'][$costclass]['total_credits'] = $my['join'][$costclass]['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
			
			
			$my['total_price'] = $my['total_price'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
			$my['total_credits'] = $my['total_credits'] + $setting['cost'][$value['ufielddata']['costclass']]['cost_credits'];
		}
		
	}
}else{
	$pay_credits = $items['use_extcredits_num'];
	$pay_price = $items['use_cost'];
	$pay_number = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid=".$_G['uid']);
	$my['credits'] = $pay_credits;
	$my['price'] = $pay_price;
	$my['number'] = $pay_number;
	$my['total_price'] = $pay_price * $pay_number;
	$my['total_credits'] = $pay_credits * $pay_number;
}



$openid = $mysession['openid'];
$pay_subject = $items['subject'];
$pay_price = $items['use_cost'];
$pay_totalprice = $my['total_price'];
//优惠后价格
$pay_totalprice = $pay_totalprice - $eventcore->GetYouHui($tid,$_G['uid']);




//prepay_id 获取，微信支付统一下单
$parameters = array();
$parameters["out_trade_no"] = getRandChar(20); //生成订单号
$parameters["body"] = mb_substr($pay_subject,0,32,'utf-8');//cutstr($pay_subject,32,'');  //商品描述
$parameters["total_fee"] = intval($pay_totalprice*100);   //总金额单位是分，不可以是小数
$parameters["notify_url"] = $_G['siteurl'].'source/plugin/xj_event/event_pay_wx_notify.php';  //异步回调地址
$parameters["trade_type"] = 'JSAPI';
$parameters["openid"] = $openid;
$parameters["appid"] = $appid;
$parameters["mch_id"] = $mch_id; //商户号
$parameters["spbill_create_ip"] = $_G['clientip'];  //客户端的IP地址
$parameters["nonce_str"] = createNoncestr();  //随机字符串
$parameters["sign"] = getSign($parameters);
$xmldata = arrayToXml($parameters);
$prepaystr = postXmlCurl($xmldata,"https://api.mch.weixin.qq.com/pay/unifiedorder");
$postObj = xmlToArray($prepaystr);


//数据库生成支付记录
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first = 1 AND tid=$tid AND uid=".$_G['uid']);
$paylog = array();
$paylog['applyid'] = $apply['applyid'];
$paylog['uid'] = $_G['uid'];
$paylog['tid'] = $tid;
$paylog['tradeno'] = $parameters["out_trade_no"];
$paylog['trade_status'] = $postObj['prepay_id'];   //用来记录prepayid 发消息用的
$paylog['paytype'] = 'xcxwxpay';
$paylog['subject'] = $_G['charset']=='gbk'?iconv("UTF-8","GBK",$items['subject']):$items['subject'];
$paylog['price'] = $pay_price;
$paylog['buyer_email'] = $openid;
$paylog['total_fee'] = $pay_totalprice;
$paylog['create_time'] = $_G['timestamp'];
$paylog['paystate'] = 1;
DB::insert("xj_eventpay_log",$paylog);



//paysign签名生成
$timestamp = strval($_G['timestamp']);
$apppay = array();
$apppay['appId'] = $appid;
$apppay['nonceStr'] = createNoncestr();
$apppay['package'] = 'prepay_id='.$postObj['prepay_id'];
$apppay['signType'] = 'MD5';
$apppay['timeStamp'] = $timestamp;
$apppay['sign'] = getSign($apppay);






$result = array();
$result = $apppay;
echo json_encode($result);

?>