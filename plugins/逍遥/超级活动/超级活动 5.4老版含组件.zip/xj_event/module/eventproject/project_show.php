<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}




$tid = intval($_GET['tid']);

if($_G['mobile']){
	$url = $_G['siteurl']."forum.php?mod=viewthread&tid=$tid";
	dheader('location: '.$url);
	exit;
}

$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid=$tid");
$eid = $items['eid'];
$setting = unserialize($items['setting']);
$post = DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." WHERE tid=$tid AND first=1");
$navtitle = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid=$tid");;
$metakeywords = $navtitle;
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');


if($_GET['action']=='intro'){
	/*
	$temp = file_get_contents($_G['siteurl'].'forum.php?mod=viewthread&tid='.$tid);
	preg_match('/\<td class="t_f" id="postmessage_\d+"\>([\s\S]+?)<\/td><\/tr><\/table>/',$temp,$matchs);
	$post['message'] = $matchs[1];
	*/



	//$post['message'] = followcode($post['message'],$post['tid'],$post['pid'],0,false);	
	$post['message'] = discuzcode($post['message'],0,0,0,1,1,1,0,0,0,$post['authorid'],0,$post['pid'],$post['dateline']);
	$post['message'] = str_replace('xj_event','',$post['message']);
	
	$attachs = getattachs($tid,$post['pid']);
	foreach($attachs as $att){
		$att['width'] = $att['width']>900?900:$att['width'];
		if(strpos($post['message'],'[attach]'.$att['aid'].'[/attach]')===false){
			$post['message'] = $post['message']."<div style='text-align:center;padding-top:10px;'><img src='".$att['attachment']."' width='".$att['width']."'></div>";
		}else{
			if($att['isimage']==0){
				$att['filesize'] = number_format($att['filesize'] / 1024,2);
				$post['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<a href='forum.php?mod=attachment&aid=".aidencode($att['aid'])."'>".$att['filename']."</a> (".$att['filesize']." KB)", $post['message']);
			}else{
				$post['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<img src='".$att['attachment']."' width='".$att['width']."'>", $post['message']);
			}
		}
	}

	
	
	
}elseif($_GET['action']=='viewthread'){
	



	
	$zptid = intval($_GET['zptid']);
	$zppost = DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." A,".DB::table('xj_eventthread')." B WHERE A.tid=B.tid AND A.tid=$zptid AND A.first=1");
	
	/*
	$temp = file_get_contents($_G['siteurl'].'forum.php?mod=viewthread&tid='.$zptid);
	preg_match('/\<td class="t_f" id="postmessage_\d+"\>([\s\S]+?)<\/td><\/tr><\/table>/',$temp,$matchs);
	$zppost['message'] = $matchs[1];
	*/
	//$zppost['message'] = followcode($zppost['message'],$zppost['tid'],$zppost['pid'],0,false);

	$zppost['message'] = discuzcode($zppost['message'],0,0,0,1,1,1,0,0,0,$zppost['authorid'],0,$zppost['pid'],$zppost['dateline']);
	
	$attachs = getattachs($zptid,$zppost['pid']);
	foreach($attachs as $att){
		$att['width'] = $att['width']>900?900:$att['width'];
		if(strpos($zppost['message'],'[attach]'.$att['aid'].'[/attach]')===false){
			$zppost['message'] = $zppost['message']."<div style='text-align:center;padding-top:10px;'><img src='".$att['attachment']."' width='".$att['width']."'></div>";
		}else{
			if($att['isimage']==0){
				$att['filesize'] = number_format($att['filesize'] / 1024,2);
				$zppost['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<a href='".$att['attachment']."'>".$att['filename']."</a> (".$att['filesize']." KB)", $zppost['message']);
			}else{
				$zppost['message'] = preg_replace("/\[attach\]".$att['aid']."\[\/attach\]/i", "<img src='".$att['attachment']."' width='".$att['width']."'>", $zppost['message']);
			}
		}
	}
	$zppost['dateline'] = dgmdate($zppost['dateline'],'dt');
	
	
}elseif($_GET['action']=='thread'){
	$authorid = intval($_GET['authorid']);
	if($authorid){
		$listcount = DB::result_first("SELECT count(*) FROM  ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.eid=$eid AND B.authorid=$authorid");
	}else{
		$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND displayorder>=0 AND A.eid=$eid");
	}
	$perpage = 20; //ÿҳ��
	$page = $_GET['page']?$_GET['page']:1;
	if(@ceil($listcount/$perpage) < $page) {
		$page = 1;
	}
	$start_limit = ($page - 1) * $perpage;
	$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:project_show&tid=$tid&action=thread",0,10,false,true,false);
	if($authorid){
		$query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND B.authorid=$authorid AND A.eid=$eid ORDER BY B.dateline DESC LIMIT $start_limit,$perpage");
	}else{
		$query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND displayorder>=0 AND A.eid=$eid ORDER BY B.dateline DESC LIMIT $start_limit,$perpage");
	}
	$threadlist = array();	
	while($value = DB::fetch($query)){
		$value['subject'] = cutstr($value['subject'],20);
		$value['dateline'] = dgmdate($value['dateline'],"d");
		$threadlist[] = $value;
	}
}elseif($_GET['action']=='join'){
		$userfield = unserialize($items['userfield']);
		$selectuserfield = unserialize($items['userfield']);
		if($selectuserfield) {
			if($selectuserfield) {
				$htmls = $settings = array();
				require_once libfile('function/profile');
				foreach($selectuserfield as $fieldid) {
					if(empty($ufielddata['userfield'])) {
						$memberprofile = C::t('common_member_profile')->fetch($_G['uid']);
						foreach($selectuserfield as $val) {
							if($val == 'birthday'){
							$ufielddata['userfield'][$val] = $memberprofile[$val];
						}
								$ufielddata['userfield']['birthyear'] =  $memberprofile['birthyear'];
								$ufielddata['userfield']['birthmonth'] =  $memberprofile['birthmonth'];
							}
						unset($memberprofile);
					}
					$html = profile_setting($fieldid, $ufielddata['userfield'], false, true);
					if($html) {
						$settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
						$htmls[$fieldid] = $html;
					}
				}
			}
		} else {
			$selectuserfield = '';
		}
		//����ʱ����ѡ�������
		$items['event_number_max'] = $items['event_number_max']>0?$items['event_number_max']:1;
		$applynumber = array();
		for($i=1;$i<=$items['event_number_max'];$i++){
			$applynumber[] = $i;
		}
		
}elseif($_GET['action']=='joinlist'){
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND verify=1");
	$perpage = 20; //ÿҳ��
	$page = $_GET['page']?$_GET['page']:1;
	if(@ceil($listcount/$perpage) < $page) {
		$page = 1;
	}
	$start_limit = ($page - 1) * $perpage;
	$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:project_show&tid=$tid&action=joinlist",0,10,false,true,false);
	$query = DB::query("SELECT * FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid=B.uid AND A.tid=$tid ORDER BY A.dateline DESC LIMIT $start_limit,$perpage");
	$joinlist = array();
	while($value = DB::fetch($query)){
		$value['avatar'] = avatar($value[uid],'middle',true);
		$value['zpnum'] = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.eid=$eid AND B.authorid=".$value['uid']);
		$joinlist[] = $value;
	}
}else{
		

	//$post['message'] = followcode($post['message'],$post['tid'],$post['pid'],320,true);	
	$post['message'] = cutstr(psubb(strip_tags($post['message'])),320);
	$post['message'] = str_replace('xj_event','',$post['message']);
	$citys = $items['citys'];
	$starttime = dgmdate($items['starttime'],'dt');
	$endtime = dgmdate($items['endtime'],'dt');
	$event_adminlist = implode(',',$setting['event_admin']);
	$activityexpiration = dgmdate($items['activityexpiration'],'dt');
	$activitybegin = dgmdate($items['activitybegin'],'dt');
	//����ͨ��������
	$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1");
	$applycountnumber = !$applycountnumber?0:$applycountnumber;
	$applycountnumberd = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=0");
	$applycountnumberd = !$applycountnumberd?0:$applycountnumberd;
	//���·�����Ʒ
	$query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.eid=$eid ORDER BY B.dateline DESC LIMIT 0,9");
	$threads = array();
	while($value = DB::fetch($query)){
		$value['subject'] = cutstr($value['subject'],20);
		$value['dateline'] = dgmdate($value['dateline'],"d");
		$threads[] = $value;
	}
	//���±���
	$query = DB::query("SELECT * FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid=B.uid AND A.tid=$tid ORDER BY A.dateline DESC LIMIT 0,10");
	$applys = array();
	while($value = DB::fetch($query)){
		$value['avatar'] = avatar($value[uid],'middle',true);
		$applys[] = $value;
	}

}




//��⵱ǰ�û��Ƿ���
if($_G['uid']){
	$count = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$_G['uid']);
	if($count>0){
		$iapplystate = true;
	}
}
//������Ʒ�İ��
$zpfid = $setting['eventzy_fid']?$setting['eventzy_fid']:$post['fid'];
include template('project_show',0,'source/plugin/xj_event/module/eventproject/template');

function psubb($Text) {      /// UBB����ת��
        $Text=stripslashes($Text);
		$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
		$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
		$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
		$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
		$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
		$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
		$Text=preg_replace("/\[(.+?)\]/is","",$Text);
		$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
		$Text=str_replace("<br />","",$Text);
        return $Text;
}
function getattachs($tid,$pid){
	global $_G;
	$return = array();
	foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$tid,'pid',$pid) as $attach) {
		if($attach['remote']) {
			$attach['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment'];
			$attach['attachment'] = substr($attach['attachment'], 0, 7) != 'http://' ? 'http://'.$attach['attachment'] : $attach['attachment'];
		}else{
			$attach['attachment'] = $_G['setting']['attachurl'].'forum/'.$attach['attachment'];
		}
		$return[] = $attach;
	}
	return $return;
}
//From: dis'.'m.tao'.'bao.com
?>