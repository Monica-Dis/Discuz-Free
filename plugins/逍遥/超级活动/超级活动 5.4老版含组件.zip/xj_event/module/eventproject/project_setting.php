<?php
$tid = intval($_GET['tid']);

//Ȩ����֤
$thread = DB::fetch_first("SELECT A.authorid,B.setting FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid='$tid' and A.tid = B.tid");
$setting = unserialize($thread['setting']);
//�ж��ǲ��ǹ����Ŷ�
$event_admin = false;
if(in_array($_G['username'],$setting['event_admin'])){
	$event_admin = true;
}
if($_G['groupid']>1 && $_G['uid']!=$thread['authorid'] && !$event_admin){
	showmessage('quickclear_noperm');
}



if($_GET['action'] == 'save'){
	if(!submitcheck('sfsubmit')){
		showmessage('submit_invalid');	
	}

	$project =array();
	$project['openproject'] = intval($_GET['openproject']);
	$project['openprojectauto'] = intval($_GET['openprojectauto']);
	$project['mainbgcolor'] = daddslashes($_GET['mainbgcolor']);
	$project['titlebgcolor'] = daddslashes($_GET['titlebgcolor']);
	$project['titlecolor'] = daddslashes($_GET['titlecolor']);
	$project['mainpic'] = daddslashes($_GET['mainpic']);
	$project['bgpic'] = daddslashes($_GET['bgpic']);

	$upload = new discuz_upload();
	$uploadtype = 'profile';
	
	
	if($upload->init($_FILES['mainpic'], $uploadtype)){
		$upload->save();
		$project['mainpic'] = $upload->attach['attachment'];
		$project['mainpic'] = 'data/attachment/profile/'.$project['mainpic'];
	}
	if($upload->init($_FILES['bgpic'], $uploadtype)){
		$upload->save();
		$project['bgpic'] = $upload->attach['attachment'];
		$project['bgpic'] = 'data/attachment/profile/'.$project['bgpic'];
	}
	$items = DB::fetch_first("SELECT setting FROM ".DB::table('xj_event')." WHERE tid=$tid");
	$setting = unserialize($items['setting']);
	$setting['project'] = $project;
	$setting = serialize($setting);
	DB::update('xj_event',array('setting'=>"$setting"),"tid=$tid");
	showmessage('spacecp_edit_ok','plugin.php?id=xj_event:project_setting&tid='.$tid);
}








/*
$editorid = 'e';
$editor = array(
	'editormode' => 1,
	'allowswitcheditor' => 1,
	'allowhtml' => 1,
	'allowhtml' => 1,
	'allowsmilies' => 1,
	'allowbbcode' => 1,
	'allowimgcode' => 1,
	'allowcustombbcode' => 0,
	'allowresize' => 1,
	'textarea' => 'message',
	'simplemode' => !isset($_G['cookie']['editormode_'.$editorid]) ? 1 : $_G['cookie']['editormode_'.$editorid],
);
*/

$items = DB::fetch_first("SELECT setting FROM ".DB::table('xj_event')." WHERE tid=$tid");
$setting = unserialize($items['setting']);
$project = $setting['project'];


include template('project_setting',0,'source/plugin/xj_event/module/eventproject/template');
?>