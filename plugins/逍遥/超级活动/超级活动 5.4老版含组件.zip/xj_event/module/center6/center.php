<?php



require_once libfile('function/post');
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');
if($_GET['ac'] == 'ajax'){

	$sqlstr = '';
	$orderstr = 'A.eventorder DESC,'; 
	if($_GET['type']){
		$px = intval($_GET['type']);
		if($px == 1){
			$sqlstr .= " AND A.verify=1";
		}elseif($px == 2){
			$sqlstr .= " AND A.endtime > ".$_G['timestamp'];
		}elseif($px == 3){
			$orderstr = ' B.views DESC,';
			$sqlstr .= " AND A.endtime > ".$_G['timestamp'];
		}
	}
	if($_GET['xx']){
		$xx = intval($_GET['xx']);
		$sqlstr .= " AND A.offlineclass=$xx AND A.postclass=1";
	}elseif($_GET['xs']){
		$xs = intval($_GET['xs']);
		$sqlstr .= " AND A.onlineclass=$xs AND A.postclass=2";
	}
	if($_GET['rq']){
		$rqstarttime = strtotime($_GET['rq']);
		$rqendtime = $rqstarttime + 86400;
		//$sqlstr .= " AND ((A.starttime>=$rqstarttime AND A.starttime<=$rqendtime) OR (A.endtime>=$rqstarttime AND A.endtime<=$rqendtime))";
		$sqlstr .= " AND ((A.starttime>$rqstarttime AND A.starttime<$rqendtime) OR (A.endtime>$rqstarttime AND A.endtime<$rqendtime) OR (A.starttime<$rqstarttime AND A.endtime>$rqendtime))";
	}
	if($_GET['city']){
		$city = addslashes($_GET['city']);
		$sqlstr .= " AND A.citys = '$city'";
	}
	if($_GET['keyword']){
		$keyword = addslashes($_GET['keyword']);
		$sqlstr .= " AND B.subject LIKE '%".str_replace(array('%', '*', '_'), array('\%', '%', '\_'), $keyword)."%'";
	}
	
	
	
	$perpage = 10; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid ".$sqlstr."");
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	

	$query = DB::query("SELECT A.*,B.subject,B.views FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND B.displayorder>=0 ".$sqlstr." ORDER BY $orderstr B.dateline DESC LIMIT $start_limit,$perpage");
	$ygeventlist = array();
	while($value = DB::fetch($query)){
		$value['setting'] = unserialize($value['setting']);
		
		
		$value['message'] = DB::result_first("SELECT message FROM ".DB::table('forum_post')." WHERE tid=".$value['tid']);
		$value['eventviews'] = $value['views'];
		$value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE eid=".$value['eid']);
		$value['applynumber'] = $value['applynumber']?$value['applynumber']:0;
		$value['document'] = messagecutstr($value['message'],70);
		
		
		
		//��������аٱ�
		if($value['event_number']>0){
			$value['eventapplyper'] = intval(100*($value['applynumber']/$value['event_number']));
		}else{
			$value['eventapplyper'] = 100;
		}
		
		

		//�ʱ���ж�
		if($_G['timestamp'] < $value['starttime']){
			$value['eventstate'] = 'δ��ʼ';
			$value['eventstateimg'] = 'e2.png';
		}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] < $value['endtime']){
			$value['eventstate'] = '������';
			$value['eventstateimg'] = 'e1.png';
		}elseif($_G['timestamp'] >= $value['endtime']){
			$value['eventstate'] = '�ѽ���';
			$value['eventstateimg'] = 'e3.png';
		}

		$value['eventstarttime'] = dgmdate($value['starttime'],"d");
		if($value['endtime']<$nowtime){
			$value['close'] = 1;
		}
		//$value['endtime'] = date("Y-m-d h:i",$value['endtime']);
		//$value['starttime'] = date("Y-m-d h:i",$value['starttime']);
		$value['activitybegin'] = dgmdate($value['activitybegin'],'dt');
		if($value['activityaid']){
			$value['activityaid_url'] = getforumimg($value['activityaid'],0,340,230);
		}
		$value['activityaid_url'] = $value['activityaid_url'] ? $value['activityaid_url'] : STATICURL.'image/common/nophoto.gif'; 
		//$value['pic'] = $value['activityaid_url'] ? 'data/attachment/forum/'.$value['activityaid_url'] : STATICURL.'image/common/nophoto.gif';

		//$value['document'] = followcode($value['message'],$value['tid'],$value['pid'],50,true);	
		
		$value['eventpic'] = '<img src="'.$value['activityaid_url'].'" width="340" height="230" border="0">';
		
		
		$value['jindu'] = '<div style=" overflow:hidden; margin-right:5px; margin-top:7px;float:left;height:8px;width:200px;background-color:#dde3e5;-moz-border-radius: 4px; -webkit-border-radius: 4px;border-radius:4px;"><div style="height:8px;background-color:#a6ca4e;-moz-border-radius: 4px; -webkit-border-radius: 4px;border-radius:4px;width:'.$value['eventapplyper'].'%"></div></div><div style=" padding-left:17px;padding-top:2px; float:left; background:url(source/plugin/xj_event/module/center6/images/'.$value['eventstateimg'].'); height:21px; width:48px;color:#fff;">'.$value['eventstate'].'</div>';

		if($value['setting']['eventaa']){
			if($value['use_cost']==0){
				$value['eventprice'] = 'AA';
			}else{
				$value['eventprice'] = 'AA '.$value['use_cost'].'Ԫ';
			}
		}else{
			if($value['use_cost']==0){
				$value['eventprice'] = '���';
			}else{
				$value['eventprice'] = $value['use_cost'].'Ԫ';
			}
		}
		if($value['postclass'] == 1){
			$value['eventaddress'] = $value['event_address'];
		}else{
			$value['eventaddress'] = '���ϻ';
		}
		
		$value['eventapplynumber'] = $value['applynumber'];
		
		$value['applylist'] = DB::fetch_all("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid = B.uid AND A.tid=".$value['tid']." LIMIT 0,5");
		$value['applylisthtml'] = '';
		foreach($value['applylist'] as $val){
			$value['applylisthtml'] .= '<img src="'.avatar($val['uid'],'small',true).'" height="36" width="36" border="0" title="'.$val['username'].'" style="-moz-border-radius: 4px; -webkit-border-radius: 4px;border-radius:4px;float:left; margin-right:3px;" />';
		}
		
		echo '<div class="itemtemplate" style="cursor:pointer" onclick="window.location.href=\'forum.php?mod=viewthread&tid='.$value['tid'].'\';">
					<div class="single_item">
                        <div class="eventpic">'.$value['eventpic'].'
                        </div>
                        <div class="eventcontent">
                        	<div class="subject">'.$value['subject'].'</div>
                            <div class="document">'.$value['document'].'</div>
                            <div class="jindu">'.$value['jindu'].'</div>
                            <div style="margin-top:20px; border-bottom:1px solid #dedddd; height:55px; ">
                            	<div style="float:left; width:70px; height:40px; padding-top:3px; line-height:20px; color:#888; border-right:1px solid #CCC; margin-right:10px; overflow:hidden;">
                                <span class="eventprice">'.$value['eventprice'].'</span><br />
                                �����
                                </div>
                                <div style="float:left; width:90px; height:40px; padding-top:3px; line-height:20px; color:#888; border-right:1px solid #CCC; margin-right:10px; overflow:hidden;">
                                <span class="eventaddress">'.$value['eventaddress'].'</span><br />
                                ��ص�
                                </div>
                                <div style="float:left; width:90px; height:40px; padding-top:3px; line-height:20px; color:#888;overflow:hidden;">
                                <span class="eventstarttime">'.$value['eventstarttime'].'</span><br />
                                �ʱ��
                                </div>
                            </div>
                            <div style="">
                            	<div style="float:right; width:60px; height:40px; padding-top:6px; line-height:20px; color:#888; margin-right:10px; overflow:hidden;">
                                ����:<span class="eventapplynumber">'.$value['applynumber'].'</span><br />
                                ��ע:<span class="eventviews">'.$value['eventviews'].'</span>
                                </div>
                                <div class="applylisthtml">
								'.$value['applylisthtml'].'
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
		
		
		
	} 
	if($page<@ceil($listcount/$perpage)){
		$page = $page+1;
		echo '<div id="morebtn">
                    <a href="javascript:;" onClick="moreitems(\''.$px.'\','.$page.',\''.$xx.'\',\''.$xs.'\',\''.$keyword.'\',\'\',\'\');" class="get_more">::�鿴����::</a> 
                </div>';
	}
	exit;
}

if($_GET['action'] == 'slideedit'){
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_xj_event_center6_slide.php')) {
		@include DISCUZ_ROOT.'./data/sysdata/cache_xj_event_center6_slide.php';
	}		
}elseif($_GET['action'] == 'slidesave'){
	$slide = array();
	foreach($_GET['pic'] as $key=>$value){
		if($value){
			$tmp = array();
			$tmp['pic'] = $value;
			$tmp['url'] = $_GET['url'][$key];
			$slide[] = $tmp;
		}
	}

	require_once libfile('function/cache');
	writetocache('xj_event_center6_slide',getcachevars(array('slide'=>$slide)));
	showmessage('����ɹ���','plugin.php?id=xj_event:event_center&action=slideedit');
	//
}else{
	  if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_xj_event_center6_slide.php')) {
		  @include DISCUZ_ROOT.'./data/sysdata/cache_xj_event_center6_slide.php';
	  }
	  
	  
	  //�����
	  $query = DB::query("SELECT A.uid,A.good,B.username FROM ".DB::table('xj_event_member_info')." A,".DB::table('common_member')." B WHERE A.uid=B.uid ORDER BY A.good DESC LIMIT 0,8");
	  $hddrlist = array();
	  $i = 1;
	  while($value = DB::fetch($query)){
		  $value['avatar'] = avatar($value['uid'],'small',true);
		  $value['event'] = DB::fetch_first("SELECT A.tid,B.subject FROM ".DB::table('xj_eventapply')." A,".DB::table('forum_thread')." B WHERE A.tid = B.tid AND A.uid = ".$value['uid']." ORDER BY A.dateline DESC");
		  $value['index'] = $i;
		  $i++;
		  $hddrlist[] = $value;
	  }
	  //��ع�
	  $query = DB::query("SELECT * FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_post')." B WHERE A.tid=B.tid AND A.sort = 1 AND B.first=1 ORDER BY B.dateline DESC LIMIT 0,8");
	  $hdhglist = array();
	  $i = 1;
	  while($value = DB::fetch($query)){
		  $value['dateline'] = dgmdate($value['dateline'],'d');
		  $value['message'] = messagecutstr($value['message'],80);
		  $value['index'] = $i;
		  $i++;
		  $hdhglist[] = $value;
	  }
	  
	  //��ȡ�����лʱ��
	  $query = DB::query("SELECT starttime,endtime FROM ".DB::table('xj_event')." ORDER BY starttime DESC LIMIT 0,30");
	  $eventdate = array();
	  while($value = DB::fetch($query)){
		  //$eventdate[] = date("'n-j'",$value['starttime']);
		  $tmp = getDateFromRange($value['starttime'],$value['endtime']);
		  $eventdate = array_merge($eventdate,$tmp);
	  }
	  $eventdate = array_unique($eventdate);
	  $eventdate =  implode(',',$eventdate);
}


/**
 * ��ȡָ�����ڶ���ÿһ�������
 * @param  Date  $startdate ��ʼ����
 * @param  Date  $enddate   ��������
 * @return Array
 */
function getDateFromRange($startdate, $enddate){

    $stimestamp = $startdate;
    $etimestamp = $enddate;

    // �������ڶ����ж�����
    $days = ($etimestamp-$stimestamp)/86400+1;

    // ����ÿ������
    $date = array();

    for($i=0; $i<$days; $i++){
        $date[] = date("'n-j'", $stimestamp+(86400*$i));
    }

    return $date;
}



function mygetpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}

function psubb($Text) {      /// UBB����ת��
        $Text=stripslashes($Text);
		$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
		$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
		$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
		$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
		$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
		$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
		$Text=preg_replace("/\[(.+?)\]/is","",$Text);
		$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
		$Text=str_replace("<br />","",$Text);
        return $Text;
}
//From: dis'.'m.tao'.'bao.com
?>