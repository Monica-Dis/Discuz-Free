<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



$tid = intval($_GET['tid']);
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE A.tid=$tid");
$setting = unserialize($items['setting']);
if(!$items['activityaid'] and $items['activityaid_url']){
	$shareimgurl = $items['activityaid_url'];
}else{
	$shareimgurl = $_G['siteurl'].'data/attachment/forum/'.$items['activityaid_url'];
}

if($_GET['action'] == 'list'){
	if($_GET['type'] == 2){
		
		
		
		$sqlstr = ' AND fromuid = '.$_G['uid'];
		$perpage = 20; //ÿҳ��
		$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_yqjl_log')." WHERE tid=$tid ".$sqlstr."");		
		$page = $_GET['page']?$_GET['page']:1;
		$start_limit = ($page - 1) * $perpage;
		$query = DB::query("SELECT * FROM ".DB::table('xj_event_yqjl_log')." WHERE tid=$tid ".$sqlstr." ORDER BY dateline DESC LIMIT $start_limit,$perpage");
		$i = 1+($page-1);
		while($value = DB::fetch($query)){
			$value['username'] = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$value['applyuid']);
			$value['dateline'] = dgmdate($value['dateline']);
			
			echo '<div style="padding:12px 15px; background-color:#fff;">
					<div style="overflow:hidden; margin-left:10px;border-radius:24px;width:48px; height:48px; background-color:#CCC; float:left;">
					<img src="'.avatar($value['applyuid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="48" height="48" align="absmiddle" />
					</div>
					<span style="float:left; line-height:48px; margin-left:8px;">'.$value['username'].' '.$value['dateline'].lang('plugin/xj_event','baomin').'</span>
					<span style="float:left; line-height:48px; margin-left:8px; float:right;">'.$value['jfs'].$_G['setting']['extcredits'][$value['jflx']]['title'].'</span>
					<div style="clear:both;"></div>
				</div>';
		}
		if($page<@ceil($listcount/$perpage)){
			$page = $page+1;
			echo '<div onClick="moreitems('.$page.',2);" id="morebtn" style=" text-align:center;line-height:40px;color:#bbb;">'.lang('plugin/xj_event', 'jiazaigengduo').'>>></div>';
		}
		
		if($listcount < 1){
			echo '<div style=" line-height:38px;font-size:14px; color:#f66;text-align:center;">'.lang('plugin/xj_event','nzwyqcgdbmgjyqhybm').'</div>';
		}
		
		
	}elseif($_GET['type'] == 1){
	
	
		$perpage = 20; //ÿҳ��
		$listcount = DB::fetch_all("SELECT fromuid FROM ".DB::table('xj_event_yqjl_log')." WHERE tid=$tid ".$sqlstr." GROUP BY fromuid");
		$listcount = count($listcount);
		
		$page = $_GET['page']?$_GET['page']:1;
		$start_limit = ($page - 1) * $perpage;
		$query = DB::query("SELECT *,SUM(jfs) as zjfs FROM ".DB::table('xj_event_yqjl_log')." WHERE tid=$tid ".$sqlstr." GROUP BY fromuid ORDER BY zjfs DESC LIMIT $start_limit,$perpage");
		$i = 1+($page-1);
		while($value = DB::fetch($query)){
			$value['username'] = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$value['fromuid']);
			if($i>3){
				$topcolor = '#aaa';
			}else{
				$topcolor = '#f66';
			}
			
			
			echo '<div style=" border-top:1px solid #dcdcdc;margin:2px 15px;padding:12px 15px; background-color:#fff;">
					<div style=" overflow:hidden; border-radius:24px;width:48px; height:48px; background-color:#CCC; float:left;">
						<img src="'.avatar($value['fromuid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="48" height="48" align="absmiddle" />
					</div>
					<div style=" text-align:right; width:180px; height:48px; float:right; line-height:24px;">
						<span style="color:#6cc96a;">'.$value['zjfs'].$_G['setting']['extcredits'][$value['jflx']]['title'].'</span><br>
						<span style="color:#aaaaaa;">'.lang('plugin/xj_event','chenggongyaoqing').intval($value['zjfs']/$setting['yqjl_jfs']).lang('plugin/xj_event','renbaoming').'</span>
					</div>
					<div style="margin-left:60px; margin-right:180px; line-height:24px;font-size:14px;">
					<span style="color:#f7442b;">'.lang('plugin/xj_event','di').$i.lang('plugin/xj_event','ming').'</span><br>				
					<span style="">'.$value['username'].'</span>
					</div>
					
					<div style="clear:both;"></div>
				</div>';
			$i++;
		}
		if($page<@ceil($listcount/$perpage)){
			$page = $page+1;
			echo '<div onClick="moreitems('.$page.',1);" id="morebtn" style=" text-align:center;line-height:40px;color:#bbb;">'.lang('plugin/xj_event', 'jiazaigengduo').'>>></div>';
		}
	
	}
	exit();
}



//����΢��֧������
if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
$appid = $wxset['appid'];
$appsecret = $wxset['appsecret'];
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')>0 && $appid && $appsecret){
	$isWeiXin = true;


	require_once libfile('function/cache');
	//��ȡaccess_token
	if(file_exists($token = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_token.php')) {
		@include $token;
	}
	if($_G['timestamp']-intval($token['timestamp'])>7100){
		$cul = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret ;
		$cx = get($cul);
		$token = json_decode($cx,true) ;
		$token['timestamp'] = $_G['timestamp'];
		writetocache('xj_event_token',getcachevars(array('token'=>$token)));
	}
	//��ȡjsapi_ticket
	if(file_exists($jsapiticke = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_jsapiticke.php')) {
		@include $jsapiticke;
	}
	if($_G['timestamp']-intval($jsapiticke['timestamp'])>7100){
		$cul = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$token['access_token'].'&type=jsapi';
		$cx = get($cul);
		$jsapiticke = json_decode($cx,true) ;
		$jsapiticke['timestamp'] = $_G['timestamp'];
		writetocache('xj_event_jsapiticke',getcachevars(array('jsapiticke'=>$jsapiticke)));
	}
	$jsapi_ticket = $jsapiticke['ticket'];
	$noncestr = getRandChar(12);
	$timestamp = $_G['timestamp'];
    //�ж�https
    $url       = dhtmlspecialchars('http' . ($_G['isHTTPS'] ? 's' : '') . '://' . $_SERVER['HTTP_HOST']) . $_SERVER['REQUEST_URI'];
	$string1 = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url";
	$signature = sha1($string1);
}


if($items['activityaid_url']){
    if(substr($items['activityaid_url'],0,4)!='data' && substr($items['activityaid_url'],0,4)!='http'){
        $items['activityaid_url'] = $_G['siteurl'].'data/attachment/forum/'.$items['activityaid_url'];
    }
}else{
    $items['activityaid_url'] = $_G['siteurl'].STATICURL.'image/common/nophoto.gif';
}
$imgurl = $items['activityaid_url'];

if(substr($items['activityaid_url'],0,4)!='http'){
    $shareimgurl = $_G['siteurl'].$imgurl;
}











function std_class_object_to_array($stdclassobject)
{
    $_array = is_object($stdclassobject) ? get_object_vars($stdclassobject) : $stdclassobject;

    foreach ($_array as $key => $value) {
        $value = (is_array($value) || is_object($value)) ? std_class_object_to_array($value) : $value;
        $array[$key] = $value;
    }

    return $array;
}
function postxml($url,$data){
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}
function postXmlCurl($xml,$url,$second=30)
{		
	//��ʼ��curl        
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, $second);
	//�������ô���������еĻ�
	//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
	//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	//����header
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	//Ҫ����Ϊ�ַ������������Ļ��
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//post�ύ��ʽ
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	//����curl
	$data = curl_exec($ch);
	curl_close($ch);
	//���ؽ��
	if($data)
	{
		curl_close($ch);
		return $data;
	}
	else 
	{ 
		$error = curl_errno($ch);
		echo "curlError, error code:$error"."<br>"; 
		echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>The reason for the error query</a></br>";
		curl_close($ch);
		return false;
	}
}

function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}
//����ָ����С���ַ���
function createNoncestr( $length = 32 ){
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {  
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
	}  
	return $str;
}
/**
* 	���ã���ʽ��������ǩ��������Ҫʹ��
*/
function formatBizQueryParaMap($paraMap, $urlencode)
{
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		//$buff .= strtolower($k) . "=" . $v . "&";
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0) 
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
//����ǩ��
function getSign($Obj){
	global $apikey;
	foreach ($Obj as $k => $v)
	{
		$Parameters[$k] = $v;
	}
	//ǩ������һ�����ֵ����������
	ksort($Parameters);
	$String = formatBizQueryParaMap($Parameters, false);
	//echo '��string1��'.$String.'</br>';
	//ǩ�����������string�����KEY
	$String = $String."&key=$apikey";
	//echo "��string2��".$String."</br>";
	//ǩ����������MD5����
	$String = md5($String);
	//echo "��string3�� ".$String."</br>";
	//ǩ�������ģ������ַ�תΪ��д
	$result_ = strtoupper($String);
	//echo "��result�� ".$result_."</br>";
	return $result_;
}

/**
 * 	���ã�arrayתxml
 */
function arrayToXml($arr)
{
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">"; 

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
	}
	$xml.="</xml>";
	return $xml; 
}

/**
 * 	���ã���xmlתΪarray
 */
function xmlToArray($xml)
{		
	//��XMLתΪarray        
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
	return $array_data;
}

/**
 * 	���ã����ɿ��Ի��code��url
 */
function createOauthUrlForCode($redirectUrl)
{
	global $appid;
	$urlObj["appid"] = $appid;
	$urlObj["redirect_uri"] = urlencode($redirectUrl);
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}

/**
 * 	���ã����ɿ��Ի��openid��url
 */
function createOauthUrlForOpenid()
{
	global $appid,$appsecret,$code;
	$urlObj["appid"] = $appid;
	$urlObj["secret"] = $appsecret;
	$urlObj["code"] = $code;
	$urlObj["grant_type"] = "authorization_code";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
}

/**
 * 	���ã�ͨ��curl��΢���ύcode���Ի�ȡopenid
 */
function getOpenid()
{
	$url = createOauthUrlForOpenid();
	//��ʼ��curl
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, 30);   //��ʱʱ��
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//����curl�������jason��ʽ����
	$res = curl_exec($ch);
	curl_close($ch);
	//ȡ��openid
	$data = json_decode($res,true);
	$return = $data['openid'];
	return $return;
}
//From: Dism��taobao��com
?>