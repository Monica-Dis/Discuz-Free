<?php
require_once libfile('function/post');
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');

$sqlstr = "";


if($_GET['pc']){
	$pc = intval($_GET['pc']);
	$sqlstr .= " AND postclass=$pc ";
}
if($_GET['onlineclass']){
	$onlinec = intval($_GET['onlineclass']);
	$sqlstr .= " AND onlineclass=$onlinec ";
}
if($_GET['offlineclass']){
	$offlinec = intval($_GET['offlineclass']);
	$sqlstr .= " AND offlineclass=$offlinec ";
}



$perpage = 20; //ÿҳ��
$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A,".DB::table('forum_post')." B WHERE A.tid=B.tid AND B.first=1 ".$sqlstr." ORDER BY A.eid");
$page = $_GET['page']?$_GET['page']:1;
if(@ceil($listcount/$perpage) < $page) {
	$page = 1;
	$countpage = 1;
}else{
	$countpage = @ceil($listcount/$perpage);
}
$start_limit = ($page - 1) * $perpage;

$query = DB::query("SELECT A.*,B.subject,B.message FROM ".DB::table('xj_event')." A,".DB::table('forum_post')." B WHERE A.tid=B.tid AND B.first=1 ".$sqlstr." ORDER BY A.eventorder DESC,B.dateline DESC LIMIT $start_limit,$perpage");
$ygeventlist = array();
while($value = DB::fetch($query)){
	$value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE eid=".$value['eid']);
	$value['applynumber'] = $value['applynumber']?$value['applynumber']:0;
	
	$value['document'] = messagecutstr($value['message'],90);
	//$value['message'] = cutstr(psubb(strip_tags($value['message'])),60);
	
	
	$value['starttime'] = dgmdate($value['starttime'],"dt");
	if($value['endtime']<$nowtime){
		$value['close'] = 1;
	}
	//$value['endtime'] = date("Y-m-d h:i",$value['endtime']);
	//$value['starttime'] = date("Y-m-d h:i",$value['starttime']);
	$value['activitybegin'] = dgmdate($value['activitybegin'],'dt');
	if($value['activityaid']){
		$value['activityaid_url'] = getforumimg($value['activityaid'],0,227,9999);
	}
	$value['activityaid_url'] = $value['activityaid_url'] ? $value['activityaid_url'] : STATICURL.'image/common/nophoto.gif'; 
	//$value['pic'] = $value['activityaid_url'] ? 'data/attachment/forum/'.$value['activityaid_url'] : STATICURL.'image/common/nophoto.gif';
	
	
	//$value['document'] = followcode($value['message'],$value['tid'],$value['pid'],50,true);	
	
	
	$ygeventlist[] = $value;
}

function mygetpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}

function psubb($Text) {      /// UBB����ת��
        $Text=stripslashes($Text);
		$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
		$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
		$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
		$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
		$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
		$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
		$Text=preg_replace("/\[(.+?)\]/is","",$Text);
		$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
		$Text=str_replace("<br />","",$Text);
        return $Text;
}
//From: dis'.'m.tao'.'bao.com
?>