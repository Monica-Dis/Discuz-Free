<?php



require_once libfile('function/post');
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');






if($_GET['action'] == 'eventlist'){
	$sqlstr = "";
	$orderstr = "ORDER BY A.eventorder DESC , B.dateline DESC";  //�����ʱ������
	//$orderstr = "ORDER BY A.starttime DESC";  //���ʼʱ������
	
	if($_GET['pc']){
		if($_GET['pc'] == 1){
			$sqlstr .= " AND A.postclass=1";
			if($_GET['classid']){
				$sqlstr .= " AND A.offlineclass=".intval($_GET['classid']);
			}
		}elseif($_GET['pc'] == 2){
			$sqlstr .= " AND A.postclass=2";
			if($_GET['classid']){
				$sqlstr .= " AND A.onlineclass=".intval($_GET['classid']);
			}
		}elseif($_GET['pc'] == 3){
			$joinstr = " left join ".DB::table('xj_eventapply')." C on A.tid=C.tid ";
			$sqlstr .= " AND C.uid = ".$_G['uid'];
		}elseif($_GET['pc'] == 4){
			$sqlstr .= " AND B.authorid=".$_G['uid'];
		}
	}
	
	if($_GET['city']){
		$city = addslashes($_GET['city']);
		$sqlstr .= " AND A.citys='$city'";
	}
	
	if($_GET['keyword']){
		$keyword = addslashes($_GET['keyword']);
		$sqlstr .= " AND B.subject LIKE '%$keyword%'";
	}
	
	
	
	$perpage = 15; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid $joinstr WHERE 1=1 ".$sqlstr."");
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid $joinstr WHERE 1=1 ".$sqlstr." AND B.displayorder>=0 $orderstr LIMIT $start_limit,$perpage");
	$i = 1;
	while($value = DB::fetch($query)){
		$value['setting'] = unserialize($value['setting']);
		

        if(substr($value['activityaid_url'],0,4)!='data' && substr($value['activityaid_url'],0,4)!='http'){
            $value['activityaid_url'] = 'data/attachment/forum/'.$value['activityaid_url'];
        }


	    $value['starttime'] = date('m/d',$value['starttime']);

		
		if($value['setting']['eventaa']){
			$value['use_cost_str'] = '<span style="font-size:26px;">AA</span>';	
		}else{
			if($value['use_cost']>0){
				$value['use_cost_str'] = '&yen;<span style="font-size:26px;">'.$value['use_cost'].'</span>';
			}else{
				$value['use_cost_str'] = '<span style="font-size:26px;">'.lang('plugin/xj_event', 'mianfei').'</span>';
			}
		}
		
		echo '<div style="float:left; width:384px;'.($i<3?'margin-right:24px;':'').'margin-bottom:24px;">
            	<a href="forum.php?mod=viewthread&tid='.$value['tid'].'" target="_blank" class="eventthread">
            	<div style="height:216px; overflow:hidden;">
                	<img src="'.$value['activityaid_url'].'" style="width:384px;height:260px;" class="fmpic">
                </div>
                <div style=" position:absolute; margin-top:-70px; height:70px; width:384px;background: linear-gradient(to top,rgba(0,0,0,.5) 0,rgba(0,0,0,0) 100%);text-shadow: 0 0 2px rgba(0,0,0,.5);">
                	<div style="padding:22px;">
                    	<span style="color:#FFF; margin-top:12px; float:left;">'.$value['starttime'].'</span>
                        <span style="color:#FFF;  float:right;">'.$value['use_cost_str'].'</span>
                    </div>
                </div>
                <div style="background-color:#ffffff;">
                	<div style="padding: 12px 22px;color: #333;font-size: 16px;font-weight: 400;height: 50px;text-align: left;">
                    	'.$value['subject'].'
                    </div>
                </div>
                </a>
            </div>';
			
		$i++;
		if($i>3){
			$i = 1;
		}
	}
	
	
	exit;
}

if($_GET['action'] == 'loadprovince'){
	$upid = intval($_GET['upid']);
	$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1 order by id");
	foreach($province as $value){
		echo '<span style="display:block; float:left; color:#7f7f7f; line-height:30px; min-width:70px; cursor:pointer;" onclick="selectprovince('.$value['id'].')">'.$value['name'].'</span> ';
		
	}
	echo '<div style="float:right;clear:both;"><span style=" padding:3px 12px; background-color:#cdcdcd; float:right; color:#ffffff; cursor:pointer;" onclick="closeprovince();">�ر�</span></div>';
	exit;
}

if($_GET['action'] == 'selcity'){
	$upid = intval($_GET['upid']);
	$city = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE upid = $upid");
	foreach($city as $value){
		echo '<span style="display:block; float:left; color:#7f7f7f; line-height:30px; min-width:70px; cursor:pointer;" onclick="selectcity(\''.$value['name'].'\');">'.$value['name'].'</span> ';
		
	}
	echo '<div style="float:right;clear:both;"><span style=" padding:4px 12px; background-color:#cdcdcd; float:left; color:#ffffff; cursor:pointer;" onclick="loadprovince();">����</span></div>';
	exit;
}











//�Ƽ� ��֤�
$rzlist = DB::fetch_all("SELECT A.*,B.tid,B.subject FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.verify = 1 ORDER BY A.eid DESC LIMIT 0,6");
foreach($rzlist as $key=>$value){
    if(substr($rzlist[$key]['activityaid_url'],0,4)!='data' && substr($rzlist[$key]['activityaid_url'],0,4)!='http'){
        $rzlist[$key]['activityaid_url'] = 'data/attachment/forum/'.$rzlist[$key]['activityaid_url'];
    }
	$rzlist[$key]['starttime'] = date('m/d',$value['starttime']);
	
	$value['setting'] = unserialize($value['setting']);
	if($value['setting']['eventaa']){
		$rzlist[$key]['use_cost_str'] = '<span style="font-size:26px;">AA</span>';	
	}else{
		if($value['use_cost']>0){
			$rzlist[$key]['use_cost_str'] = '&yen;<span style="font-size:26px;">'.$value['use_cost'].'</span>';
		}else{
			$rzlist[$key]['use_cost_str'] = '<span style="font-size:26px;">'.lang('plugin/xj_event', 'mianfei').'</span>';
		}
	}
	
}
//ʡ



/**
 * ��ȡָ�����ڶ���ÿһ�������
 * @param  Date  $startdate ��ʼ����
 * @param  Date  $enddate   ��������
 * @return Array
 */
function getDateFromRange($startdate, $enddate){

    $stimestamp = $startdate;
    $etimestamp = $enddate;

    // �������ڶ����ж�����
    $days = ($etimestamp-$stimestamp)/86400+1;

    // ����ÿ������
    $date = array();

    for($i=0; $i<$days; $i++){
        $date[] = date("'n-j'", $stimestamp+(86400*$i));
    }

    return $date;
}



function mygetpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}

function psubb($Text) {      /// UBB����ת��
        $Text=stripslashes($Text);
		$Text=preg_replace("/\[url=(.+?)\](.+?)\[\/.+?\]/is","",$Text);
		$Text=preg_replace("/\[coverimg\](.+?)\[\/coverimg\]/is","",$Text);
		$Text=preg_replace("/\[img\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[img=(.+?)\](.+?)\[\/img\]/is","",$Text);
		$Text=preg_replace("/\[media=(.+?)\](.+?)\[\/media\]/is","",$Text);
		$Text=preg_replace("/\[attach\](.+?)\[\/attach\]/is","",$Text);
		$Text=preg_replace("/\[audio\](.+?)\[\/audio\]/is","",$Text);
		$Text=preg_replace("/\[hide\](.+?)\[\/hide\]/is","",$Text);
		$Text=preg_replace("/\[(.+?)\]/is","",$Text);
		$Text=preg_replace("/\{:(.+?):\}/is","",$Text);
		$Text=str_replace("<br />","",$Text);
        return $Text;
}
//From: dis'.'m.tao'.'bao.com
?>