<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//�жϰ���
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){  //����Ƿ������������
	$magapp = true;
}
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="source/plugin/xj_event/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			window.location.href="plugin.php?id=xj_event:wsqcenter&mod=event_pub";
		});
    });
	</script>');
}

if($_G['wechat']){
	if(!$_G['uid'] && $_G['mobile']){
		$url = "http://wsq.discuz.qq.com/index.php?c=index&a=plugin&siteid=".$_G['wechat']['setting']['wsq_siteid']."&pluginid=xj_event:autologin&param=".urlencode(base64_encode("reload=event_pub"))."&login=yes&mobile=2";
		dheader('location: '.$url);
		exit;
	}
}else{
	if(!$_G['uid'] && $_G['mobile']){
		$url = 'member.php?mod=logging&action=login&mobile=2';
		dheader('location: '.$url);
		exit;
	}
}


if(!in_array('xj_event',$_G['group']['allowthreadplugin'])){
	exit('error');
}
$tid = intval($_GET['tid']);
$items = DB::fetch_first("SELECT A.*,B.fid,B.subject,B.message,B.authorid FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_post')." B ON A.tid = B.tid WHERE A.tid = $tid AND B.first = 1");
$setting = unserialize($items['setting']);
if($_G['uid'] != $items['authorid']){
	exit('error');
}


if($_GET['action'] == 'full'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	
	if(empty($_GET['activityaid_url']) && $_GET['activityaid']<1){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingshangchuanhuodongfengmian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['subject'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongbiaoti');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['offlineclass']) && empty($_GET['onlineclass'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanzehuodongfenlei');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['starttime']) || empty($_GET['endtime'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanzehuodongshijian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['activitybegin']) || empty($_GET['activityexpiration'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanbaomingshijian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['event_address']) && $_GET['postclass'] == 1){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongdizhi');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['message'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongxiangqingmiaoshu');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['event_agreement'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingyueduhuodongfabuxieyitongyihoucaikeyifabu');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	
	
	
	
	include_once libfile('function/forum');
	$fid = intval($_GET['fid']);
	$subject = daddslashes($_GET['subject']);
	$message = dhtmlspecialchars(daddslashes(trim($_GET['message'])));
	foreach($_GET['messagepic'] as $value){
		$message .= "\n[img]".$value.'[/img]'."\n";
	}

	
	
	$specialextra = 'xj_event';
	$message .= chr(0).chr(0).chr(0).$specialextra;

	@include_once DISCUZ_ROOT.'./source/plugin/'.$_G['setting']['threadplugins'][$specialextra]['module'].'.class.php';
	//�������������ύ��֤
	$classname = 'threadplugin_'.$specialextra;
	if(class_exists($classname) && method_exists($threadpluginclass = new $classname, 'editpost_submit')) {
		$threadpluginclass->editpost_submit($items['fid'], $tid);
	}
	//������������д�����ݿ�
	$classname = 'threadplugin_'.$specialextra;
	if(class_exists($classname) && method_exists($threadpluginclass = new $classname, 'editpost_submit_end')) {
		$threadpluginclass->editpost_submit_end($items['fid'], $tid);
	}
	DB::update('forum_post',array('subject'=>$subject,'message'=>$message),"tid=$tid AND first = 1");
	DB::update('forum_thread',array('subject'=>$subject),"tid=$tid");
	
	
	
	$result = array();
	$result['full'] = 1;
	$result['return'] = $return;
	$result['message'] = lang('plugin/xj_event', 'huodongneirongxiugaichenggong');
	$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
	$result['url'] = $_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$tid;
	echo json_encode($result);
	exit();
}
















$extcredits = $_G['setting']['extcredits'];
$citys = explode("\r\n",$_G['cache']['plugin']['xj_event']['city']);
foreach($extcredits as $key=>$value){
	$extcredits[$key]['id'] = $key;
}
$default_extcredit = reset($extcredits); //���Ĭ�ϻ�������
$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_offline_class']);
$offlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$offlineclass[$eventclass[0]] = $eventclass[1];
}
$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_online_class']);
$onlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$onlineclass[$eventclass[0]] = $eventclass[1];
}


$userfield = unserialize($_G['setting']['activityfield']);
$activity['ufield']['userfield'] = array('realname','mobile');



//���������������
if($_G['cache']['plugin']['xj_event']['event_city']){
	$lang_province = lang('spacecp', 'district_level_1');
	$lang_city = lang('spacecp', 'district_level_2');
	$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1");
	$provincecount = count($province);
	$city = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 2 order by upid");
	$i = 0;
	$tempid = 1;
	foreach($city as $key=>$value){
		if($value['upid']<> $tempid){
			$i = 0;
			$tempid = $value['upid'];
		}
		$city[$key]['displayorder'] = $i;
		$i++;
	}
}
//���ѡ�����
$forumlist = DB::fetch_all("select A.fid,A.name FROM ".DB::table('forum_forum')." A,".DB::table('forum_forumfield')." B WHERE A.fid = B.fid and A.type<>'group' and A.status=1 and B.threadplugin like '%xj_event%'");




//�ʱ��ͱ���ʱ��
$items['starttime'] = date("Y-m-d H:i:s",$items['starttime']);
$items['endtime'] = date("Y-m-d H:i:s",$items['endtime']);
$items['activitybegin'] = date("Y-m-d H:i:s",$items['activitybegin']);
$items['activityexpiration'] = date("Y-m-d H:i:s",$items['activityexpiration']);
//ѡ��ı�����Ϣ�ֶ�
$selectuserfield = unserialize($items['userfield']);
//����������ݵ�β�����
$items['message'] = str_replace(chr(0).chr(0).chr(0).'xj_event','',$items['message']);


preg_match_all("/\[img\](.+?)\[\/img\]/is",$items['message'],$messagepic,PREG_PATTERN_ORDER);

$items['message'] = preg_replace("/\[img\](.+?)\[\/img\]/is", "", $items['message']); 

$setting['vip_discount'] = $setting['vip_discount']*100;


if($items['activityaid']){
	$items['activityaid_url'] = getpicurl($items['activityaid'],$tid);
}


include template('wsq_event_edit',0,'source/plugin/xj_event/module/wsqcenter/template');


/**
* ͨ��aid��ȡͼƬ����
*/
function getpicurl($aid,$tid){
  global $_G;
  $return = '';
  if($aid) {
	  $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM ".DB::table(getattachtablebytid($tid))." WHERE aid='{$aid}'");
	  if($picatt['remote']) {
		  $picatt['attachment'] = $_G['setting']['ftp']['attachurl'].'forum/'.$picatt['attachment'];
		  $picatt['attachment'] = substr($picatt['attachment'], 0, 7) != 'http://' ? 'http://'.$picatt['attachment'] : $picatt['attachment'];
	  } else {
		  $picatt['attachment'] = $_G['siteurl'].$_G['setting']['attachurl'].'forum/'.$picatt['attachment'];
	  }
  }
  $return = $picatt['attachment'];
  return $return;
}
//From: Dism��taobao��com
?>