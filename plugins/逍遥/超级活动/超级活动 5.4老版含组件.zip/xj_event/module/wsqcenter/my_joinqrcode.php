<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$seccode = addslashes($_GET['seccode']);
$tid = intval($_GET['tid']);

$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND seccode='$seccode'");


$dir = DISCUZ_ROOT.'./data/cache/qrcode/xj_event/';
$file = $dir.'xj_event_'.$items['seccode'].'_'.$items['applyid'].'.jpg';
$validationurl = $_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_joinverify&tid='.$items['tid'].'&seccode='.$items['seccode'];


dmkdir($dir);
require_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
ob_clean();//这个一定要加上，清除缓冲区  
QRcode::png($validationurl, false, QR_ECLEVEL_Q, 3);
?>