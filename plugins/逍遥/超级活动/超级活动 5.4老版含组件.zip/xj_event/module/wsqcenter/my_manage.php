<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0 || $_SERVER['HTTP_MAG_MGSC']){  //����Ƿ��ǰ��������
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){
	$magapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan')>0){
	$QianFan = true;	
}



if ($_G['cache']['plugin']['xj_event']['weixin_js']) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') > 0 && $_GET['action'] != 'userlist' && $_GET['action'] != 'replylist' && $_GET['action'] != 'replyfull') {
        $isWeiXin = true;
        //����΢��֧������
        if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
            @include $xj_event_wxset;
        }
        $appid     = $wxset['appid'];
        $appsecret = $wxset['appsecret'];
        if ($appid && $appsecret) {
            require_once libfile('function/cache');
            //��ȡaccess_token
            if (file_exists($token = DISCUZ_ROOT . './data/sysdata/cache_xj_event_token.php')) {
                @include $token;
            }
            if ($_G['timestamp'] - intval($token['timestamp']) > 7100) {
                $cul                = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $appsecret;
                $cx                 = get($cul);
                $token              = json_decode($cx, true);
                $token['timestamp'] = $_G['timestamp'];
                writetocache('xj_event_token', getcachevars(array('token' => $token)));
            }
            //��ȡjsapi_ticket
            if (file_exists($jsapiticke = DISCUZ_ROOT . './data/sysdata/cache_xj_event_jsapiticke.php')) {
                @include $jsapiticke;
            }
            if ($_G['timestamp'] - intval($jsapiticke['timestamp']) > 7100) {
                $cul                     = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' . $token['access_token'] . '&type=jsapi';
                $cx                      = get($cul);
                $jsapiticke              = json_decode($cx, true);
                $jsapiticke['timestamp'] = $_G['timestamp'];
                writetocache('xj_event_jsapiticke', getcachevars(array('jsapiticke' => $jsapiticke)));
            }
            $jsapi_ticket = $jsapiticke['ticket'];
            $noncestr     = getRandChar(12);
            $timestamp    = $_G['timestamp'];
            //�ж�https
            $url       = dhtmlspecialchars('http' . ($_G['isHTTPS'] ? 's' : '') . '://' . $_SERVER['HTTP_HOST']) . $_SERVER['REQUEST_URI'];
            $string1   = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url";
            $signature = sha1($string1);
        }
    }
}




//�жϵ�¼״̬
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_manage";
		});
    });
	</script>');
}
if($magapp && !$_G['uid']){ //���׵�¼
	exit('<script src="http://app.lxh.magcloud.cc/public/static/dest/js/libs/magjs-x.js"></script>
	<script>
		mag.toLogin(function(){
			window.location.href="'.$_G['siteurl'].'/plugin.php?id=xj_event:wsqcenter&mod=my_manage";
		});
	</script>
	');
}
if($QianFan && !$_G['uid']){ //ǧ����¼
	exit('<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>
	');
}



if(!$_G['uid']){
	$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe');
	dheader('location: '.$url);
	exit;
}

$tid = intval($_GET['tid']);
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE A.tid=$tid");
$setting = unserialize($items['setting']);


if(!$items['activityaid'] and $items['activityaid_url']){
	$imgurl = $items['activityaid_url'];
}else{
	//$imgurl = $this->_getpicurl($items['activityaid'],$tid);
	if($items['activityaid']){
		$imgurl = getforumimg($items['activityaid'],0,600,450,'fixnone');
	}else{
		$imgurl = 'static/image/common/nophoto.gif';
	}
}
//��������
$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid'");
$applycountnumber = $applycountnumber?$applycountnumber:0;

//�鿴��
$items['views'] = $items['views'] + intval(DB::result_first("SELECT addviews FROM ".DB::table('forum_threadaddviews')." WHERE tid=".$tid));
$items['replys'] = DB::result_first("SELECT count(*) FROM ".DB::table('forum_post')." WHERE first=0 AND tid=".$tid);
include template('my_manage',0,'source/plugin/xj_event/module/wsqcenter/template');






function get($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    # curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    if (!curl_exec($ch)) {
        error_log(curl_error($ch));
        $data = '';
    } else {
        $data = curl_multi_getcontent($ch);
    }
    curl_close($ch);
    return $data;
}

function getRandChar($length)
{
    $str    = null;
    $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $max    = strlen($strPol) - 1;
    for ($i = 0; $i < $length; $i++) {
        $str .= $strPol[rand(0, $max)]; //rand($min,$max)���ɽ���min��max������֮���һ���������
    }
    return $str;
}