<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tid = intval($_GET['tid']);
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){  //����Ƿ��ǰ��������
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){  //����Ƿ������������
	$magapp = true;
}
//�жϵ�¼״̬
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=event_myinvitation";
		});
    });
	</script>');
}



if($_GET['action'] == 'list'){

		$sqlstr = ' AND fromuid = '.$_G['uid'];
		$perpage = 20; //ÿҳ��
		$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_yqjl_log')." WHERE 1=1 ".$sqlstr."");		
		$page = $_GET['page']?$_GET['page']:1;
		$start_limit = ($page - 1) * $perpage;
		$query = DB::query("SELECT * FROM ".DB::table('xj_event_yqjl_log')." WHERE 1=1 ".$sqlstr." ORDER BY dateline DESC LIMIT $start_limit,$perpage");
		$i = 1+($page-1);
		while($value = DB::fetch($query)){
			$value['username'] = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid=".$value['applyuid']);
			$value['subject'] = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid=".$value['tid']);
			$value['dateline'] = dgmdate($value['dateline']);
			
			echo '<div style="padding:12px 15px; background-color:#fff;">
					<div style=" margin-left:10px;width:48px; height:48px; background-color:#CCC; float:left;">
					<img src="'.avatar($value['applyuid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="48" height="48" align="absmiddle" />
					</div>
					<span style="float:left; line-height:24px; margin-left:8px;"><span style="color:#f66;">'.$value['subject'].'</span><br>'.$value['username'].' '.$value['dateline'].lang('plugin/xj_event','baomin').'</span>
					<span style="float:left; line-height:48px; margin-left:8px; float:right;">'.$value['jfs'].$_G['setting']['extcredits'][$value['jflx']]['title'].'</span>
					<div style="clear:both;"></div>
				</div>';
		}
		if($page<@ceil($listcount/$perpage)){
			$page = $page+1;
			echo '<div onClick="moreitems('.$page.',2);" id="morebtn" style=" text-align:center;line-height:40px;color:#bbb;">'.lang('plugin/xj_event', 'jiazaigengduo').'>>></div>';
		}
		
		if($listcount < 1){
			echo '<div style=" line-height:38px;font-size:14px; color:#f66;text-align:center;">'.lang('plugin/xj_event','nzwyqcgdbmgjyqhybm').'</div>';
		}
		

	exit();
}


include template('event_myinvitation',0,'source/plugin/xj_event/module/wsqcenter/template');
?>