<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//�жϰ���
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){  //����Ƿ������������
	$magapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan')>0){
	$QianFan = true;	
}


if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="source/plugin/xj_event/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			window.location.href="plugin.php?id=xj_event:wsqcenter&mod=event_pub";
		});
    });
	</script>');
}
if($magapp && !$_G['uid']){ //���׵�¼
	exit('<script src="source/plugin/xj_event/js/magjs-x.js"></script>
	<script>
		mag.toLogin(function(){
			var url = "'.$_G['siteurl'].'plugin.php?id=xj_event:event_join&tid='.$_GET['tid'].'",
				  params = {
					  name: "zz"
				  };
			mag.newWin(url, params);
			
			//window.location.href="'.'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'";
		});
	</script>
	');
}
if($QianFan && !$_G['uid']){ //ǧ����¼
	exit('<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>
	');
}

if($_G['wechat']){
	if(!$_G['uid'] && $_G['mobile']){
		$url = "http://wsq.discuz.qq.com/index.php?c=index&a=plugin&siteid=".$_G['wechat']['setting']['wsq_siteid']."&pluginid=xj_event:autologin&param=".urlencode(base64_encode("reload=event_pub"))."&login=yes&mobile=2";
		dheader('location: '.$url);
		exit;
	}
}else{
	if(!$_G['uid'] && $_G['mobile']){
		$url = 'member.php?mod=logging&action=login&mobile=2';
		dheader('location: '.$url);
		exit;
	}
}





if($_GET['action']=='upload'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	$action = $_GET['act'];
	//�ж�Ŀ¼�Ƿ���ڣ������ھʹ���
	$updir = 'data/attachment/xj_event/'.date('Ym',time()).'/';
	if(!is_readable($updir))  
    {  
        if(!mkdir($updir,0777,true)){
			echo 'Directory to create failure';
		}
    } 
	
	
	if($action=='delimg'){

		$filename = $_GET['pic'];
		$filename = str_replace($_G['siteurl'],'',$filename);
		if(!empty($filename)){
			unlink($filename);
			$result = array();
			$result['full'] = 1;
			echo json_encode($result);
			exit();
		}else{
			$result = array();
			$result['full'] = 2;
			echo json_encode($result);
			exit();
		}
	}else{
		$picname = $_FILES['mypic']['name'];
		$picsize = $_FILES['mypic']['size'];
		if ($picname != "") {
			if ($picsize > 8096000) {
				$errormessage = lang('plugin/xj_event', 'wenjiantaidashangchuanshibai');
				if($_G['charset']=='gbk'){
					$errormessage = iconv('gbk','utf-8',$errormessage);
				}
				
				$arr = array(
					'error'=>$errormessage
				);
				echo json_encode($arr);
				exit;
			}
			$type = strstr($picname, '.');
			if ($type != ".jpg" && $type != ".png" && $type != ".jpeg" && $type != ".JPG" && $type != ".PNG" && $type != ".JPEG") {
				$errormessage = lang('plugin/xj_event', 'znscjpgpnggsdtp').$type;
				if($_G['charset']=='gbk'){
					$errormessage = iconv('gbk','utf-8',$errormessage);
				}
				$arr = array(
					'error'=>$errormessage
				);
				echo json_encode($arr);
				exit;
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			//�ϴ�·��
			$pic_path = $updir.$pics;
			move_uploaded_file($_FILES['mypic']['tmp_name'], $pic_path);
			createsmallimg($updir,$pics);
			//require_once libfile('class/image');
			//$image = new image;
			//$image->Thumb($pic_path, '', 800, 800, 1, 1);
		}
		$size = round($picsize/1024,2);
		$arr = array(
			'name'=>$picname,
			'pic'=>$pics,
			'size'=>$size,
			'dir'=>$updir
		);
		echo json_encode($arr);
	}
	exit();
}

if(!in_array('xj_event',$_G['group']['allowthreadplugin'])){
	showmessage(lang('plugin/xj_event','nmyfbhddqx'));
}






if($_GET['action']=='getcity'){
	if($_G['cache']['plugin']['xj_event']['event_city']){
		$upid = intval($_GET['upid']);
		if($upid){
			$city = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE upid = $upid");
			
			foreach($city as $value){
				echo '<span style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;" data-value="'.$value['name'].'" class="city">'.$value['name'].'</span>';
			}
			echo '<span style="background-color:#ffb400; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;" id="returnprovince">'.lang('plugin/xj_event', 'fanhuishangji').'</span>';
		}else{
			$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1 order by id");
			foreach($province as $value){
				echo '<span style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;" data-value="'.$value['id'].'" class="province">'.$value['name'].'</span>';
			}
			
			
		}
	}else{
		$city = explode("\r\n",$_G['cache']['plugin']['xj_event']['city']);
		foreach($city as $value){
			echo '<span style="background-color:#ccc; font-size:14px; padding:3px 12px; color:#FFF; border-radius:4px; margin-bottom:5px; margin-right:5px; float:left;" data-value="'.$value.'" class="city">'.$value.'</span>';
		}
		
	}
	exit();
}










if($_GET['action'] == 'full'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	
	
	if(empty($_GET['activityaid_url'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingshangchuanhuodongfengmian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['subject'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongbiaoti');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['offlineclass']) && empty($_GET['onlineclass'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanzehuodongfenlei');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['starttime']) || empty($_GET['endtime'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanzehuodongshijian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['activitybegin']) || empty($_GET['activityexpiration'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingxuanbaomingshijian');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['event_address']) && $_GET['postclass'] == 1){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongdizhi');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['message'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingtianxiehuodongxiangqingmiaoshu');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	if(empty($_GET['event_agreement'])){
		$result['full'] = 2;
		$result['message'] = lang('plugin/xj_event', 'qingyueduhuodongfabuxieyitongyihoucaikeyifabu');
		$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
		echo json_encode($result);
		exit();
	}
	
	
	
	
	include_once libfile('function/forum');
	$modthread = C::m('forum_thread');
	$fid = intval($_GET['fid']);
	$subject = daddslashes($_GET['subject']);
	$message = dhtmlspecialchars(daddslashes(trim($_GET['message'])));
	foreach($_GET['messagepic'] as $value){
		$message .= "\n[img]".$value.'[/img]'."\n";
	}

	
	
	$modthread->forum = array('fid'=>$fid);
	$params = array(
		'subject' => $subject,
		'message' => $message,
		'typeid' => 0,
		'sortid' => 0,
		'special' => 127,     //��������
	);
	$specialextra = 'xj_event';
	//���������ύ������֤
	if($specialextra) {
		@include_once DISCUZ_ROOT.'./source/plugin/'.$_G['setting']['threadplugins'][$specialextra]['module'].'.class.php';
		$classname = 'threadplugin_'.$specialextra;
		if(class_exists($classname) && method_exists($threadpluginclass = new $classname, 'newthread_submit')) {
			$threadpluginclass->newthread_submit($fid);
		}
		$special = 127;
		$params['special'] = 127;
		$params['message'] .= chr(0).chr(0).chr(0).$specialextra;

	}
	$params['publishdate'] = $_G['timestamp'];
	$params['readperm'] = 0;     //�Ķ�Ȩ��
	$params['allownoticeauthor'] = 1;  //�ظ�����֪ͨ
	$params['usesig'] = 1;   //�Ƿ���ǩ��
	$return = $modthread->newthread($params);
	//������������д�����ݿ�
	if($specialextra) {
		$classname = 'threadplugin_'.$specialextra;
		if(class_exists($classname) && method_exists($threadpluginclass = new $classname, 'newthread_submit_end')) {
			$threadpluginclass->newthread_submit_end($_G['fid'], $modthread->tid);
		}
	}
	
	$tid = $modthread->tid;
	if($_G['groupid'] > 2){
		if($_G['cache']['plugin']['xj_event']['eventpub_audit']){
			DB::update('forum_thread',array('displayorder'=>-2),"tid=$tid");
		}
	}
	DB::insert('forum_thread_moderate',array('id'=>$tid,'status'=>0,'dateline'=>$_G['timestamp']));
	
	$result = array();
	$result['full'] = 1;
	$result['return'] = $return;
	if($_G['groupid'] > 2 && $_G['cache']['plugin']['xj_event']['eventpub_audit']){
		$result['message'] = lang('plugin/xj_event', 'huodongfabuchenggongqingdengdaiguanliyuanshenhe');
	}else{
		$result['message'] = lang('plugin/xj_event', 'huodongfabuchenggong');	
	}
	$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
	$result['url'] = $_G['siteurl'].'plugin.php?id=xj_event:wsq_event_center';
	echo json_encode($result);
	exit();
}
















$extcredits = $_G['setting']['extcredits'];
$citys = explode("\r\n",$_G['cache']['plugin']['xj_event']['city']);
foreach($extcredits as $key=>$value){
	$extcredits[$key]['id'] = $key;
}
$default_extcredit = reset($extcredits); //���Ĭ�ϻ�������
$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_offline_class']);
$offlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$offlineclass[$eventclass[0]] = $eventclass[1];
}
$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_online_class']);
$onlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$onlineclass[$eventclass[0]] = $eventclass[1];
}


$userfield = unserialize($_G['setting']['activityfield']);
$activity['ufield']['userfield'] = array('realname','mobile');



//���������������
if($_G['cache']['plugin']['xj_event']['event_city']){
	$lang_province = lang('spacecp', 'district_level_1');
	$lang_city = lang('spacecp', 'district_level_2');
	$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1");
	$provincecount = count($province);
	$city = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 2 order by upid");
	$i = 0;
	$tempid = 1;
	foreach($city as $key=>$value){
		if($value['upid']<> $tempid){
			$i = 0;
			$tempid = $value['upid'];
		}
		$city[$key]['displayorder'] = $i;
		$i++;
	}
}
//���ѡ�����
$forumlist = DB::fetch_all("select A.fid,A.name FROM ".DB::table('forum_forum')." A,".DB::table('forum_forumfield')." B WHERE A.fid = B.fid and A.type<>'group' and A.status=1 and B.threadplugin like '%xj_event%'");

//�µı����ֶ�
$myuserfield = DB::fetch_all("SELECT * FROM " . DB::table('xj_event_field') . " ORDER BY id");



include template('wsq_event_pub',0,'source/plugin/xj_event/module/wsqcenter/template');





function createsmallimg($dir,$source_img) {
	$img_name=substr($source_img,0,-4);
	$img_ex = strtolower(substr(strrchr($source_img,"."),1));
	switch($img_ex){
		case "jpg":
			$src_img=ImageCreateFromJpeg($dir.$source_img);
			break;
		case "gif":
			$src_img=ImageCreateFromGif($dir.$source_img);
			break;
		case "jpeg":
			$src_img=ImageCreateFromJpeg($dir.$source_img);
			break;
	}
	$maxwidth="600";
	$old_width=imagesx($src_img);
	$old_height=imagesy($src_img);
	if($maxwidth>=$maxwidth) {
		$new_width=$maxwidth;
		$new_height=($new_width*$old_height)/$old_width;
	}
	if($img_ex=="jpg" or $img_ex=="jpeg"){
		$dst_img=imagecreatetruecolor($new_width,$new_height);
	}else{
		$dst_img=imagecreate($new_width,$new_height);
	}
	ImageCopyResized($dst_img,$src_img,0,0,0,0,$new_width,$new_height,$old_width,$old_height);
	$smallname=$dir.$img_name.".".$img_ex;
	switch($img_ex) {
		case "jpg":
			ImageJpeg($dst_img,$smallname,100);
			break;
		case "gif":
			imageGif($dst_img,$smallname,100);
			break;
		case "jpeg":
			ImageJpeg($dst_img,$smallname,100);
			break;
	}
}
//From: dis'.'m.tao'.'bao.com
?>