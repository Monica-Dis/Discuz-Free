<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){  //����Ƿ��ǰ��������
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){
	$magapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan')>0){
	$QianFan = true;	
}
//�жϵ�¼״̬
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe";
		});
    });
	</script>');
}
if($magapp && !$_G['uid']){ //���׵�¼
	exit('<script src="http://app.lxh.magcloud.cc/public/static/dest/js/libs/magjs-x.js"></script>
	<script>
		mag.toLogin(function(){
			window.location.href="'.$_G['siteurl'].'/plugin.php?id=xj_event:wsqcenter&mod=my_publishe";
		});
	</script>
	');
}
if($QianFan && !$_G['uid']){ //ǧ����¼
	exit('<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>
	');
}



if(!$_G['uid']){
	$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe');
	dheader('location: '.$url);
	exit;
}

if($_GET['action'] == 'list'){
	$perpage = 15; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE B.authorid=".$_G['uid']);
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	$query = DB::query("SELECT A.*,B.subject,B.dateline,B.displayorder FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE B.authorid=".$_G['uid']." ORDER BY B.dateline DESC  LIMIT $start_limit,$perpage");
	while($value = DB::fetch($query)){
	
		if($value['activityaid']){
			$value['activityaid_url'] = $value['activityaid']?getforumimg($value['activityaid'],0,500,320):'static/image/common/nophoto.gif';
		}elseif(!$value['activityaid'] && !$value['activityaid_url']){
			$value['activityaid_url'] = 'static/image/common/nophoto.gif';
		}
		
		if($value['displayorder']<0){
			$eventstatehtml = '<span style="color:#ff6600;">'.lang('plugin/xj_event','weishenhe').'</span>';
			$clickhtml = '';
		}else{
			if($value['activitybegin']<= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']){
				$eventstatehtml = '<span style="color:#ff6600;">'.lang('plugin/xj_event', 'hdbmz').'</span>';
			}elseif($_G['timestamp']<=$value['starttime']){
				$eventstatehtml = '<span style="color:#c4c4c4;">'.lang('plugin/xj_event', 'hdwks').'</span>';
			}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']){
				$eventstatehtml = '<span style="color:#45bf3f;">'.lang('plugin/xj_event', 'hdjxz').'</span>';
			}elseif($_G['timestamp']>=$value['endtime']){
				$eventstatehtml = '<span style="color:#ff495e;">'.lang('plugin/xj_event', 'hdyjs').'</span>';
			}
			$clickhtml = 'onclick="tomanage('.$value['tid'].');"';
		}
		
		
		$value['bmnumber'] = intval(DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']));
		$value['tgbmnumber'] = intval(DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE verify=1 AND tid=".$value['tid']));
		
		
		echo '<div style="padding:10px 15px 8px 15px; margin-top:10px; background-color:#FFF;" '.$clickhtml.'>
            	<div style="padding-bottom:12px; border-bottom:1px solid #eee;">
                	<div style=" float:left;width:110px;">
                    	<img src="'.$value['activityaid_url'].'" style="width:120px; height:80px;">
                    </div>
                	<div style="padding-left:130px; margin-right:0px; padding-top:2px; min-height:50px;">
                    	<span style="line-height:18px; font-size:14px; color:#454545;">'.$value['subject'].'</span>
                    </div>
                    <div style="padding-left:130px; margin-right:0px; padding-top:8px;">
                    	<span style="line-height:16px; font-size:12px; color:#999;">'.dgmdate($value['dateline'],"Y-m-d H:i").' '.lang('plugin/xj_event', 'fabu').'</span>
                    </div>
                </div>
                <div style=" padding-top:8px; font-size:12px;">
                	'.$eventstatehtml.'
                    <span style="float:right;"><span style="color:#ff3c5c;">'.$value['bmnumber'].'</span>'.lang('plugin/xj_event', 'renbaoming').'<span style="color:#50b748;">'.$value['tgbmnumber'].'</span>'.lang('plugin/xj_event', 'rentongguo').'</span>
                </div>
                <div style="clear:both;"></div>
            </div>';
	}
	if($page<@ceil($listcount/$perpage)){
		$page = $page+1;
		echo '<div onClick="moreitems('.$page.');" id="morebtn" style=" text-align:center;line-height:40px;color:#bbb;">'.lang('plugin/xj_event', 'jiazaigengduo').'>>></div>';
	}
	exit();
}



include template('my_publishe',0,'source/plugin/xj_event/module/wsqcenter/template');
?>