<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$tid = $_GET['etid']?intval($_GET['etid']):intval($_GET['tid']);


//���ԣ��ֻ�ʶ��
if(!$_G['mobile']){
	$url = $_G['siteurl']."forum.php?mod=viewthread&tid=$tid";
	dheader('location: '.$url);
	exit;
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){
	$magapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')>0){
	$isWeiXin = true;	
}



$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE A.tid=$tid");
$setting = unserialize($items['setting']);
if(!$items['activityaid'] and $items['activityaid_url']){
	$imgurl = $items['activityaid_url'];
	$shareimgurl = $imgurl;
}else{
	//$imgurl = $this->_getpicurl($items['activityaid'],$tid);
	if($items['activityaid']){
		$imgurl = getforumimg($items['activityaid'],0,900,500,'fixnone');
	}else{
		$imgurl = 'static/image/common/nophoto.gif';
	}
	$shareimgurl = $_G['siteurl'].'data/attachment/forum/'.$items['activityaid_url'];
}
$starttime = dgmdate($items['starttime'],'Y-m-d H:i');
$endtime = dgmdate($items['endtime'],'dt');
//��������
$sharetitle = $items['subject'];


if($isWeiXin){
	//����΢��֧������
	if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
		@include $xj_event_wxset;
	}
	$appid = $wxset['appid'];
	$appsecret = $wxset['appsecret'];
	if($appid && $appsecret){
		require_once libfile('function/cache');
		//��ȡaccess_token
		if(file_exists($token = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_token.php')) {
			@include $token;
		}
		if($_G['timestamp']-intval($token['timestamp'])>7100){
			$cul = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret ;
			$cx = get($cul);
			$token = json_decode($cx,true) ;
			$token['timestamp'] = $_G['timestamp'];
			writetocache('xj_event_token',getcachevars(array('token'=>$token)));
		}
		//��ȡjsapi_ticket
		if(file_exists($jsapiticke = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_jsapiticke.php')) {
			@include $jsapiticke;
		}
		if($_G['timestamp']-intval($jsapiticke['timestamp'])>7100){
			$cul = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$token['access_token'].'&type=jsapi';
			$cx = get($cul);
			$jsapiticke = json_decode($cx,true) ;
			$jsapiticke['timestamp'] = $_G['timestamp'];
			writetocache('xj_event_jsapiticke',getcachevars(array('jsapiticke'=>$jsapiticke)));
		}
		$jsapi_ticket = $jsapiticke['ticket'];
		$noncestr = getRandChar(12);
		$timestamp = $_G['timestamp'];
		//�ж�https
		$url = dhtmlspecialchars('http'.($_G['isHTTPS']?'s':'').'://'.$_SERVER['HTTP_HOST']).$_SERVER['REQUEST_URI'];
		$string1 = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url";
		$signature = sha1($string1);
	}
}











if($wxset['wsqonly']){
	if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false){
		$zffyurl = $_G['siteurl']."plugin.php?id=xj_event:event_pay&tid=$tid";
	}else{
  		$zffyurl = $_G['siteurl']."plugin.php?id=xj_event:wsq_pay&tid=$tid";
	}
}else{
  $zffyurl = $_G['siteurl']."plugin.php?id=xj_event:event_pay&tid=$tid";
}



//����״̬
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND uid=".$_G['uid']);
if($setting['eventpay']){
	if($apply['verify'] == 1){
		$applystate = 1;  //���ͨ��
	}else{
		$applystate = 3;  //�ȴ�֧��
	}
}else{
	if($apply['verify'] == 1){
		$applystate = 1;  //���ͨ��
	}else{
		$applystate = 2;  //�ȴ����
	}
}





include template('join_success',0,'source/plugin/xj_event/module/wsqcenter/template');



function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}

function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}
//From: dis'.'m.tao'.'bao.com
?>