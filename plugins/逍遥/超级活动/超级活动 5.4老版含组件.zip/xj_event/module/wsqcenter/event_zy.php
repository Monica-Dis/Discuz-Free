<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$eid = intval($_GET['eid']);
$fid = intval($_GET['fid']);

$thread = DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." WHERE authorid = ".$_G['uid']." ORDER BY dateline DESC");

if($thread){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	$imgtype = 1;
	$tid = $thread['tid'];
	$basedir = !$_G['setting']['attachurl'] ? ('data/attachment/') : $_G['setting']['attachurl'];
	$coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
	$aid = DB::result_first("SELECT aid FROM ".DB::table('forum_attachment')." WHERE tid=$tid");
	if($aid){
		if(appeventsetthreadcover($thread['pid'],$thread['tid'],$aid,0,'',$imgtype,$fid)){
			$coverurl = $basedir.'forum/'.$coverdir.$tid.'-event.jpg';
		}
	}
	DB::query("INSERT INTO ".DB::table('xj_eventthread')." (eid,tid,fid,coverurl,sort) VALUES ('$eid','$tid','$fid','$coverurl',0)");
}


function appeventsetthreadcover($pid, $tid = 0, $aid = 0, $countimg = 0, $imgurl = '',$imgtype = 1,$fid) { 
	global $_G;
	$cover = 0;
	//ͼƬ��С
	$imgheight = 220;
	$imgwidth = 220;

	if(empty($_G['uid']) || !intval($imgheight) || !intval($imgwidth)) {
		return false;
	}

	if(($pid || $aid) && empty($countimg)) {
		if(empty($imgurl)) {
			if($aid) {
				$attachtable = 'aid:'.$aid;
				$attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid, array(1, -1));
			} else {
				$attachtable = 'pid:'.$pid;
				$attach = C::t('forum_attachment_n')->fetch_max_image('pid:'.$pid, 'pid', $pid);
			}
			if(!$attach) {
				return false;
			}
			if(empty($_G['forum']['ismoderator']) && $_G['uid'] != $attach['uid']) {
				return false;
			}
			$pid = empty($pid) ? $attach['pid'] : $pid;
			$tid = empty($tid) ? $attach['tid'] : $tid;
			$picsource = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$attach['attachment'];
		} else {
			$attachtable = 'pid:'.$pid;
			$picsource = $imgurl;
		}

		$basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
		$coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
		dmkdir($basedir.'./forum/'.$coverdir);

		require_once libfile('class/image');
		$image = new image();
		if($image->Thumb($picsource, 'forum/'.$coverdir.$tid.'-event.jpg', $imgwidth, $imgheight, 2)) {
			return true;
		} else {
			return false;
		}
	}
}
//From: Dism��taobao��com
?>