<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){  //����Ƿ��ǰ��������
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){  //����Ƿ������������
	$magapp = true;
}
//�жϵ�¼״̬
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe";
		});
    });
	</script>');
}
if(!$_G['uid']){
	$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);
	dheader('location: '.$url);
	exit;
}

//VIP�û���
$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);

include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

$seccode = addslashes($_GET['seccode']);
$tid = intval($_GET['tid']);
if($eventcore->IsEventAdmin($tid,$_G['uid'])<1){
	showmessage(lang('plugin/xj_event', 'ninmeiyoucaozuoquanxian'));

}
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid WHERE A.tid=$tid");
if($_GET['action'] == 'verifyfull'){  //��֤������
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND seccode='$seccode'");
	if($apply['secstate']==1){
		$errormessage = lang('plugin/xj_event', 'huodongpingzhengyijingshiyong');
	}elseif(!$apply){
		$errormessage = lang('plugin/xj_event', 'huodongpingzhengwuxiao');
	}elseif($_G['timestamp']>$items['endtime']){
		$errormessage = lang('plugin/xj_event', 'huodongyijieshu');
	}else{
		$errormessage = lang('plugin/xj_event', 'huodongpingzhengchenggongyanzhengshiyong');
		DB::update('xj_eventapply',array('secstate'=>1,'sectime'=>$_G['timestamp']),"first=1 AND tid=$tid AND seccode='$seccode'");
		$sign = array();
		$sign['tid'] = $tid;
		$sign['uid'] = $apply['uid'];
		$sign['dateline'] = $_G['timestamp'];
		DB::insert('xj_event_signed',$sign);
	}
}elseif($_GET['action'] == 'verify'){  //��֤��һ��

	

	$checkcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND secstate=1");
}else{   //��֤�ڶ���
	$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid=$tid AND seccode='$seccode'");
	$apply['dateline'] = dgmdate($apply['dateline']);
	if($apply['secstate']==1){
		$errormessage = lang('plugin/xj_event', 'huodongpingzhengyijingshiyong');
	}elseif(empty($apply['applyid'])){
		$errormessage = lang('plugin/xj_event', 'huodongpingzhengwuxiao');
	}elseif($_G['timestamp']>$items['endtime']){
		$errormessage = lang('plugin/xj_event', 'huodongyijieshu');
	}else{
		$apply['price'] = $eventcore->GetEventPrice($tid,$apply['uid']);
		$applycontent = $eventcore->GetEventApply($tid,$apply['uid']);
		if(is_array($applycontent)){
			foreach($applycontent as $value){
				$apply['applynumber_str'] .= $value['cost_name'].$value['cost_number'].lang('plugin/xj_event', 'ren').' ';
			}
		}else{
			$apply['applynumber_str'] = $applycontent.lang('plugin/xj_event', 'ren');
		}
		$applyinfo = $eventcore->GetApplyInfo($tid,$apply['uid']);
	}
	
}

include template('my_joinverify',0,'source/plugin/xj_event/module/wsqcenter/template');
?>