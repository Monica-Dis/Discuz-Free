<?php
/**
 *    [�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$tid = $_GET['etid'] ? intval($_GET['etid']) : intval($_GET['tid']);

//���ԣ��ֻ�ʶ��
if (!$_G['mobile']) {
    $url = $_G['siteurl'] . "forum.php?mod=viewthread&tid=$tid";
    dheader('location: ' . $url);
    exit;
}

if (strpos($_SERVER["HTTP_USER_AGENT"], 'Appbyme') > 0) {
    $Appbyme = true;
}
if (strpos($_SERVER["HTTP_USER_AGENT"], 'MAGAPP') > 0) {
    $magapp = true;
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') > 0) {
    $QianFan = true;
}

if ($_G['cache']['plugin']['xj_event']['weixin_js']) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') > 0 && $_GET['action'] != 'userlist' && $_GET['action'] != 'replylist' && $_GET['action'] != 'replyfull') {
        $isWeiXin = true;
        //����΢��֧������
        if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
            @include $xj_event_wxset;
        }
        $appid     = $wxset['appid'];
        $appsecret = $wxset['appsecret'];
        if ($appid && $appsecret) {
            require_once libfile('function/cache');
            //��ȡaccess_token
            if (file_exists($token = DISCUZ_ROOT . './data/sysdata/cache_xj_event_token.php')) {
                @include $token;
            }
            if ($_G['timestamp'] - intval($token['timestamp']) > 7100) {
                $cul                = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $appsecret;
                $cx                 = get($cul);
                $token              = json_decode($cx, true);
                $token['timestamp'] = $_G['timestamp'];
                writetocache('xj_event_token', getcachevars(array('token' => $token)));
            }
            //��ȡjsapi_ticket
            if (file_exists($jsapiticke = DISCUZ_ROOT . './data/sysdata/cache_xj_event_jsapiticke.php')) {
                @include $jsapiticke;
            }
            if ($_G['timestamp'] - intval($jsapiticke['timestamp']) > 7100) {
                $cul                     = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' . $token['access_token'] . '&type=jsapi';
                $cx                      = get($cul);
                $jsapiticke              = json_decode($cx, true);
                $jsapiticke['timestamp'] = $_G['timestamp'];
                writetocache('xj_event_jsapiticke', getcachevars(array('jsapiticke' => $jsapiticke)));
            }
            $jsapi_ticket = $jsapiticke['ticket'];
            $noncestr     = getRandChar(12);
            $timestamp    = $_G['timestamp'];
            //�ж�https
            $url       = dhtmlspecialchars('http' . ($_G['isHTTPS'] ? 's' : '') . '://' . $_SERVER['HTTP_HOST']) . $_SERVER['REQUEST_URI'];
            $string1   = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url";
            $signature = sha1($string1);
        }
    }
}

if ($_GET['action'] == 'replyformhash') {
    exit($_G['formhash']);
}

if ($_GET['action'] == 'userlist') {
    $s = $_GET['s'];
    if ($_GET['s'] == '2') {
        $sqlstr .= " AND A.verify=0";
    }
    if ($_GET['s'] == '3') {
        $sqlstr .= " AND A.verify=1";
    }

    //�жϻ����Ȩ
    $items       = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid WHERE A.tid=$tid");
    $setting     = unserialize($items['setting']);
    $event_admin = false;
    if ($items['authorid'] == $_G['uid'] || $_G['groupid'] == 1 || in_array($_G['username'], $setting['event_admin'])) {
        if ($_G['uid'] > 0) {
            $event_admin = true;
        }
    }

    //VIP�û���
    $vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);

    $perpage   = 20; //ÿҳ��
    $listcount = DB::result_first("SELECT count(*) FROM " . DB::table('xj_eventapply') . " A LEFT JOIN " . DB::table('common_member') . " B ON A.uid=B.uid " . $joinstr . "WHERE A.tid=$tid AND A.first=1 " . $sqlstr . "");
    $page      = $_GET['page'] ? $_GET['page'] : 1;
    //if(@ceil($listcount/$perpage) < $page) {
    //    $page = 1;
    //}
    $start_limit = ($page - 1) * $perpage;
    $query       = DB::query("SELECT * FROM " . DB::table('xj_eventapply') . " A LEFT JOIN " . DB::table('common_member') . " B ON A.uid=B.uid " . $joinstr . "WHERE A.tid=$tid AND A.first=1 " . $sqlstr . " ORDER BY A.dateline DESC,A.first DESC LIMIT $start_limit,$perpage");
    while ($value = DB::fetch($query)) {
        $value['applycount'] = DB::result_first("SELECT sum(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid=$tid AND uid=" . intval($value['uid']));

        if (in_array($value['groupid'], $vipgroup)) {
            $vipredname = 'color:#f00;';
            $viphtml    = '<span style=" padding:2px 4px;position:absolute;font-size:10px;right:8px; bottom:0px;background-color:#f8da20;color:#000;padding:2px; border-radius:2px;">' . ($_G['cache']['plugin']['xj_card']['cardname'] ? $_G['cache']['plugin']['xj_card']['cardname'] : 'VIP') . '</span>';
        } else {
            $vipredname = '';
            $viphtml    = '';
        }

        $value['avatar'] = '<img src="' . avatar($value['uid'], 'middle', true, false, true) . '?random=' . random(2) . '" onerror="this.onerror=null;this.src=\'' . $_G['setting']['ucenterurl'] . '/images/noavatar_middle.gif\'" width="50" height="50" align="absmiddle" style="-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;" />';
        echo '<div style="width:20%; height:90px; float:left;"' . ($event_admin ? ' onclick="top.location.href=\'' . $_G['siteurl'] . 'plugin.php?id=xj_event:wsqcenter&mod=event_apply_view&applyid=' . $value['applyid'] . '\';"' : '') . '>
                	<div style="text-align:center;position:relative;">' . ($value['applycount'] > 1 ? '<span style=" margin-left:-2px; margin-top:-2px; width:15px; font-size:12px; padding:2px; background-color:#00be1f;color:#fff;position:absolute;-moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius:10px;">' . $value['applycount'] . '</span>' : '') . $value['avatar'] . $viphtml . '</div>
                    <div style="overflow:hidden;white-space:nowrap;text-align:center;font-size:14px;' . $vipredname . '">' . ($value['secstate'] == 1 ? '[' . lang('plugin/xj_event', 'yan') . ']' : '') . showusername($value['username'], 3) . '</div>
                </div>';
    }

    if ($page < @ceil($listcount / $perpage)) {
        $page = $page + 1;
        echo '<div style="width:60px; height:90px; float:left; margin-right:10px;" id="more2btn" onclick="moreuserpage(' . $s . ',' . $page . ');">
                	<div style=" background-color:#fff;height:60px; width:60px; line-height:60px; text-align:center; color:#CCC; -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px; border:1px solid #d0d0d0;">' . lang('plugin/xj_event', 'genduo') . '</div>
                </div>';
    }

    exit();
} elseif ($_GET['action'] == 'replylist') {
    $page = intval($_GET['page']);
    require_once libfile('function/discuzcode');
    if ($_GET['reply']) {
        $postlist = C::t('forum_post')->fetch_all_by_tid('tid:' . $tid, $tid, true, 'DESC', 0, 1, 0, 0, $_G['uid']);
    } else {
        $postlist = C::t('forum_post')->fetch_all_by_tid('tid:' . $tid, $tid, true, 'asc', ($page - 1) * 10, 10, 0, 0);
    }
    foreach ($postlist as $key => $value) {
        $value['avatar']   = '<img src="' . avatar($value['authorid'], 'middle', true, false, true) . '?random=' . random(2) . '" onerror="this.onerror=null;this.src=\'' . $_G['setting']['ucenterurl'] . '/images/noavatar_middle.gif\'" width="40" height="40" align="absmiddle" style="-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;" />';
        $value['dateline'] = dgmdate($value['dateline']);
        $value['message']  = discuzcode($value['message'], 0, 0, 0, 1, 1, 1, 0, 0, 0, $value['authorid'], 0, $value['pid'], $value['dateline']);
        $attachs           = getattachs($tid, $value['pid']);
        foreach ($attachs as $att) {
            $att['width'] = $att['width'] > 900 ? 900 : $att['width'];
            if (strpos($value['message'], '[attach]' . $att['aid'] . '[/attach]') === false) {
                $value['message'] = $value['message'] . "<div style='text-align:center;padding-top:10px;'><img src='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'></div>";
            } else {
                if ($att['isimage'] == 0) {
                    $att['filesize']  = number_format($att['filesize'] / 1024, 2);
                    $value['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<a href='" . $att['attachment'] . "'>" . $att['filename'] . "</a> (" . $att['filesize'] . " KB)", $value['message']);
                } else {
                    $value['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<img src='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'>", $value['message']);
                }
            }
        }
        echo '<div style=" padding-top:10px; border-top:1px solid #cccccc;">
            	<div style="width:60px; float:left; text-align:center;">' . $value['avatar'] . '</div>
                <div style="margin-left:60px;">
                	<div><span style="font-size:14px; color:#999;">' . $value['author'] . '</span><span style=" margin-right:10px; color:#57a424; font-size:14px;float:right;">' . $value['position'] . lang('plugin/xj_event', 'lou') . '</span><br><span onclick="reply(' . $value['pid'] . ');" style=" float:right; border-radius:5px; background-color:#5cb8ff;font-size:14px; color:#fff;padding:2px 10px;">' . lang('plugin/xj_event', 'huifu') . '</span></div>
                    <div style="font-size:12px; color:#ccc;">' . $value['dateline'] . '</div>
                </div>
				<div style="padding:10px 10px; line-height:26px;">' . $value['message'] . ' </div>
                <div style="clear:both;"></div>
            </div>';

    }
    exit;
} elseif ($_GET['action'] == 'replyfull') {
    $result = array();
    //if($_GET['formhash'] != $_G['formhash']){
    if (!submitcheck('formhash')) {
        $result['full'] = 2;
        echo json_encode($result);
        exit;
    }
    if (!$_G['uid']) {
        $result['full'] = 2;
        echo json_encode($result);
        exit;
    }
    if (empty($_GET['message'])) {
        $result['full'] = 3;
        echo json_encode($result);
        exit;
    }
    if ($_GET['pid']) {
        $pid       = intval($_GET['pid']);
        $replypost = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE pid=$pid");
        $quote     = '[quote][size=2][url=forum.php?mod=redirect&goto=findpost&pid=' . $pid . '&ptid=$tid][color=#999999]' . $replypost['author'] . ' ' . lang('plugin/xj_event', 'faby') . ' ' . dgmdate($replypost['dateline']) . '[/color][/url][/size][/quote]';
    }

    include libfile('function/forum');
    $message = $quote . dhtmlspecialchars(daddslashes(trim($_GET['message'])));
    $thread  = get_thread_by_tid($tid);
    include_once libfile('function/forum');
    $postid = insertpost(array(
        'fid'         => $thread['fid'],
        'tid'         => $tid,
        'first'       => '0',
        'author'      => $_G['username'],
        'authorid'    => $_G['uid'],
        'subject'     => '',
        'dateline'    => $_G['timestamp'],
        'message'     => $message,
        'useip'       => $_G['clientip'],
        'invisible'   => 0,
        'anonymous'   => 0,
        'usesig'      => 1,
        'htmlon'      => 0,
        'bbcodeoff'   => 0,
        'smileyoff'   => -1,
        'parseurloff' => 0,
        'attachment'  => '0',
    ));
    if ($postid) {
        DB::query("UPDATE " . DB::table('forum_thread') . " SET replies=replies+1,lastpost='{$_G[timestamp]}',lastposter='" . $_G['username'] . "' WHERE tid='$tid'");
        DB::query("UPDATE " . DB::table('common_member_count') . " SET posts=posts+1 WHERE uid=" . $_G['uid']);
        DB::query("UPDATE " . DB::table('forum_forum') . " SET lastpost='$tid\t$thread[subject]\t{$_G[timestamp]}\t{$_G[username]}',posts=posts+1,todayposts=todayposts+1 WHERE fid='{$thread[fid]}'");
    }
    $result['full'] = 1;
    echo json_encode($result);
    exit();
}

$items   = DB::fetch_first("SELECT * FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid WHERE A.tid=$tid");
$setting = unserialize($items['setting']);


	if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/eventurl/view.php')) {  //�������ת
		if($setting['event_url']){ //�������ת
			dheader("Location: ".$setting['event_url']);
		}
	}




//�����
if($items['activityaid_url']){
    if(substr($items['activityaid_url'],0,4)!='data' && substr($items['activityaid_url'],0,4)!='http'){
        $items['activityaid_url'] = $_G['siteurl'].'data/attachment/forum/'.$items['activityaid_url'];
    } 
}else{
    $items['activityaid_url'] = $_G['siteurl'].STATICURL.'image/common/nophoto.gif';
}
$imgurl = $items['activityaid_url'];

if(substr($items['activityaid_url'],0,4)!='http'){
    $shareimgurl = $_G['siteurl'].$imgurl;
}else{
    $shareimgurl = $imgurl;
}





$starttime = dgmdate($items['starttime'], 'Y-m-d H:i');
$endtime   = dgmdate($items['endtime'], 'dt');

//�жϻ����Ȩ
$event_admin = false;
if ($items['authorid'] == $_G['uid'] || $_G['groupid'] == 1 || in_array($_G['username'], $setting['event_admin'])) {
    if ($_G['uid'] > 0) {
        $event_admin = true;
    }
}

//���������������
if ($_G['cache']['plugin']['xj_event']['event_city']) {
    $lang_province = lang('spacecp', 'district_level_1');
    $lang_city     = lang('spacecp', 'district_level_2');
    if ($items['citys']) {
        $upid = intval(DB::result_first("SELECT upid FROM " . DB::table('common_district') . " WHERE name = '" . $items['citys'] . "'"));
        if ($upid) {
            $items['province'] = DB::result_first("SELECT name FROM " . DB::table('common_district') . " WHERE id = $upid");
        }
    }
}
//���Ļ���
$extcredits = $_G['setting']['extcredits'];
foreach ($extcredits as $key => $value) {
    if ($key == $items['use_extcredits']) {
        $extcredit_title = $value['title'];
    }
}
//����ʱ��
$activityexpiration = dgmdate($items['activityexpiration'], 'dt');
$activitybegin      = dgmdate($items['activitybegin'], 'dt');
//��������
$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid'");
$applycountnumber = $applycountnumber ? $applycountnumber : 0;
//��ͨ����˱�������
$applycountnumber_verify = intval(DB::result_first("SELECT SUM(applynumber) FROM " . DB::table('xj_eventapply') . " WHERE tid='$tid' and verify=1"));
//ʣ������
if ($items['event_number'] > 0) {
    $applycountnumber_remain = $items['event_number'] - $applycountnumber_verify;
}
//�����б�TOP5
$query     = DB::query("SELECT * FROM " . DB::table('xj_eventapply') . " A LEFT JOIN " . DB::table('common_member') . " B ON A.uid=B.uid WHERE tid=$tid AND first=1 ORDER BY A.dateline DESC LIMIT 0,4");
$applylist = array();
while ($value = DB::fetch($query)) {
    $value['avatar']   = '<img src="' . avatar($value['uid'], 'middle', true, false, true) . '?random=' . random(2) . '" onerror="this.onerror=null;this.src=\'' . $_G['setting']['ucenterurl'] . '/images/noavatar_middle.gif\'" width="50" height="50" align="absmiddle" style="-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;" />';
    $value['username'] = showusername($value['username'], 3);
    $applylist[]       = $value;
}

//������������APP���ӱ�������,�˹�����ʱ���á�
/*
$num_matches = preg_match("/\[url\=plugin.+?\[\/url\]/i", $post['message']);
if($num_matches==0){
$post['message'] = str_replace(chr(0).chr(0).chr(0).'xj_event','[url=plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$tid.'][img=140,50]'.$_G['siteurl'].'source/plugin/xj_event/images/ljbm.gif[/img][/url]
'.chr(0).chr(0).chr(0).'xj_event',$post['message']);
DB::update('forum_post',array('message'=>$post['message']),"pid=".$post['pid']);
}
$post['message'] = preg_replace("/\[url\=plugin.+?\[\/url\]/i", "", $post['message']);
 */

//$post['message'] = my_discuzcode($post['message']);
$post = DB::fetch_first("SELECT * FROM ".DB::table('forum_post')." WHERE tid=$tid AND first=1");
require_once libfile('function/discuzcode');
require_once libfile('function/followcode');
$post['message'] = preg_replace("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = preg_replace("/\[img\=.+?\](.+?)\[\/img\]/i", "[xjimg]$1[/xjimg]", $post['message']);
$post['message'] = discuzcode($post['message'], 0, 0, 1, 1, 1, 1, 1, 0, 0, $post['authorid'], 0, $post['pid'], $post['dateline']);
$post['message'] = preg_replace("/\[xjimg\](.+?)\[\/xjimg\]/i", "<img src='$1' width='100%'>", $post['message']);
$post['message'] = str_replace(chr(0) . chr(0) . chr(0) . 'xj_event', '', $post['message']);
$attachs         = getattachs($tid, $post['pid']);
foreach ($attachs as $att) {
    if ($items['activityaid'] != $att['aid']) {
        $att['width'] = $att['width'] > 900 ? 900 : $att['width'];
        if (strpos($post['message'], '[attach]' . $att['aid'] . '[/attach]') === false) {
            $post['message'] = $post['message'] . "<div style='text-align:center;padding-top:10px;'><img src='source/plugin/xj_event/images/picloading.gif' data-original='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'></div>";
        } else {
            if ($att['isimage'] == 0) {
                $att['filesize'] = number_format($att['filesize'] / 1024, 2);
                $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<a href='" . $att['attachment'] . "'>" . $att['filename'] . "</a> (" . $att['filesize'] . " KB)", $post['message']);
            } else {
                $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "<img src='source/plugin/xj_event/images/picloading.gif' data-original='" . $att['attachment'] . "' width='" . ($att['width'] > 300 ? '100%' : $att['width']) . "'>", $post['message']);
            }
        }
    } else {
        $post['message'] = preg_replace("/\[attach\]" . $att['aid'] . "\[\/attach\]/i", "", $post['message']);
    }
}
$post['message'] = str_replace("\r\n", '<br>', $post['message']);




//��������ժҪ
$share_desc = trimall(mb_substr(strip_tags($post['message']), 0, 60, $_G['charset']));

//�Ƿ���
$myapply = DB::fetch_first("SELECT * FROM " . DB::table('xj_eventapply') . " WHERE tid=$tid AND first=1 AND uid=" . $_G['uid']);
//�����ҵ����
$fzyurl = $_G['siteurl'] . 'forum.php?mod=post&action=newthread&fid=' . ($setting['eventzy_fid'] ? $setting['eventzy_fid'] : $items['fid'] . '&eid=' . $items['eid']);
//��ȡ��������
$qxbmurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_join&action=cannel&tid=$tid&formhash=" . $_G['formhash'];
//�޸ı�������
$xgbmurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_join_modify&tid=$tid";

//֧����������
//����΢��֧������
if (file_exists($xj_event_wxset = DISCUZ_ROOT . './data/sysdata/cache_xj_event_wxset.php')) {
    @include $xj_event_wxset;
}
if ($wxset['wsqonly']) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false) {
        $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_pay&tid=$tid";
    } else {
        $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:wsq_pay&tid=$tid";
    }
} else {
    $zffyurl = $_G['siteurl'] . "plugin.php?id=xj_event:event_pay&tid=$tid";
}
//�ظ��ſ��Ա���
$bmbtnshow = true;
if ($setting['reply']) {
    $replys = DB::result_first("SELECT count(*) FROM " . DB::table('forum_post') . " WHERE tid='$tid' AND first<>1 AND invisible>=0 AND authorid = " . $_G['uid']);
    if ($replys < 1) {
        $bmbtnshow = false;
    }
}
//���뱨��
if ($setting['invitation']['open']) {
    if ($setting['invitation']['code'] != $_GET['icode']) {
        $bmbtnshow = 2;
    }
}

//VIP�ۿ�
if (file_exists(DISCUZ_ROOT . './source/plugin/xj_event/module/vip/event_view.php')) {
    @include DISCUZ_ROOT . './source/plugin/xj_event/module/vip/event_view.php';
    $vipin = true;
}

//���²鿴��
C::t('forum_threadaddviews')->update_by_tid($tid);

//�����ĸ��û��ķ���
if ($_GET['fromuid']) {
    setcookie("xj_event_fromuid", $_GET['fromuid'], TIMESTAMP + 3600 * 24);
}

//��ѡ�
$jxlist = DB::fetch_all("SELECT A.*,B.tid,B.subject FROM " . DB::table('xj_event') . " A," . DB::table('forum_thread') . " B WHERE A.tid<>$tid AND A.tid=B.tid AND B.displayorder>=0 AND A.verify = 1 AND A.endtime>" . $_G['timestamp'] . " ORDER BY A.eventorder DESC LIMIT 0,5");
foreach ($jxlist as $key => $value) {
    $value['setting'] = unserialize($value['setting']);

    if ($value['activityaid']) {
        $jxlist[$key]['activityaid_url'] = $value['activityaid'] ? getforumimg($value['activityaid'], 0, 200, 110) : 'static/image/common/nophoto.gif';
    } elseif (!$value['activityaid'] && !$value['activityaid_url']) {
        $jxlist[$key]['activityaid_url'] = 'static/image/common/nophoto.gif';
    }

    $jxlist[$key]['starttime'] = date("Y-m-d", $value['starttime']);
    if ($value['setting']['eventaa']) {
        $jxlist[$key]['use_cost_str'] = 'AA';
    } else {
        if ($value['use_cost'] > 0) {
            $jxlist[$key]['use_cost_str'] = $value['use_cost'] . lang('plugin/xj_event', 'yuan');
        } else {
            $jxlist[$key]['use_cost_str'] = lang('plugin/xj_event', 'mianfei');
        }
    }
}

$fid = $setting['eventzy_fid'] ? $setting['eventzy_fid'] : $items['fid'];


//���Ƶ
$setting['event_video'] = explode("\r\n",urldecode($setting['event_video']));


include template('wsq_event_view', 0, 'source/plugin/xj_event/module/wsqcenter/template');

function showusername($username, $len)
{
    global $_G;
    $return = $username;
    if (function_exists('mb_substr')) {
        if (mb_strlen($username, $_G['charset']) > $len) {
            $return = mb_substr($username, 0, $len, $_G['charset']) . '...';
        }
    }
    return $return;
}

function my_discuzcode($message)
{
    global $_G;
    $message = preg_replace(array(lang('forum/misc', 'post_edit_regexp'), lang('forum/misc', 'post_edithtml_regexp'), lang('forum/misc', 'post_editnobbcode_regexp')), '', $message);

    //note URL ����
    if (strpos($msglower, '[/url]') !== false) {
        $message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "mobile_parseurl('\\1', '\\5', '\\2')", $message);
    }
    //note E-mail ����
    if (strpos($msglower, '[/email]') !== false) {
        $message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "strip_tags(parseemail('\\1', '\\4'))", $message);
    }

    //note ������� ����Ƕ�� 4 ��
    $nest = 0;
    while (strpos($msglower, '[table') !== false && strpos($msglower, '[/table]') !== false) {
        $message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "mobile_parsetable('\\1', '\\2', '\\3')", $message);
        if (++$nest > 4) {
            break;
        }

    }

    //note CSS ��ش������
    $message = str_replace(array(
        '[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
        '[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
        '[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]',
    ), array(
        '</font>', '</font>', '', '', '', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '', '',
        '', '', '', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
        '<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '', '', '',
    ), preg_replace(array(
        "/\[color=([#\w]+?)\]/i",
        "/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
        "/\[backcolor=([#\w]+?)\]/i",
        "/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
        "/\[size=(\d{1,2}?)\]/i",
        "/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
        "/\[font=([^\[\<]+?)\]/i",
        "/\[align=(left|center|right)\]/i",
        "/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
        "/\[float=left\]/i",
        "/\[float=right\]/i",
    ), array(
        "<font color=\"\\1\">",
        "<font style=\"color:\\1\">",
        "<font style=\"background-color:\\1\">",
        "<font style=\"background-color:\\1\">",
        "",
        "",
        "",
        "",
        "<p>",
        "",
        "",
    ), $message));

    //note ���ӱ���ͼ
    $message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);

    if ($parsetype != 1) {
        if (strpos($msglower, '[/quote]') !== false) {
            $message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", mobile_quote(), $message);
        }
        if (strpos($msglower, '[/free]') !== false) {
            $message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", mobile_free(), $message);
        }
    }
    //note ��ý��������
    if (strpos($msglower, '[/media]') !== false) {
        $message = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", "bbcodeurl('\\2', '<a class=\"media\" href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
    }
    if (strpos($msglower, '[/audio]') !== false) {
        $message = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", "bbcodeurl('\\2', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
    }
    if (strpos($msglower, '[/flash]') !== false) {
        $message = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", "bbcodeurl('\\4', '<a href=\"{url}\" target=\"_blank\">{url}</a>')", $message);
    }

    //note �Զ��� Discuz! �������
    if ($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
        $message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
    }
    //note hide �������
    if ($parsetype != 1 && strpos($msglower, '[/hide]') !== false && $pid) {
        if ($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
            $message  = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
            $msglower = strtolower($message);
        }
        if (strpos($msglower, '[hide=d') !== false) {
            $message  = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
            $msglower = strtolower($message);
        }
        if (strpos($msglower, '[hide]') !== false) {
            if ($authorreplyexist === null) {
                if (!$_G['forum']['ismoderator']) {
                    if ($_G['uid']) {
                        $authorreplyexist = C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']);
                    }
                } else {
                    $authorreplyexist = true;
                }
            }
            if ($authorreplyexist) {
                $message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", mobile_hide_reply(), $message);
            } else {
                $message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", mobile_hide_reply_hidden(), $message);
            }
        }
        if (strpos($msglower, '[hide=') !== false) {
            $message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
        }
    }

    $attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
    $message = preg_replace(array(
        "/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
        "/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
    ), array(
        "my_mobile_parseimg(0, 0, '\\1', " . intval($lazyload) . ", " . intval($pid) . ", 'onmouseover=\"img_onmouseoverfunc(this)\" " . ($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"") . "')",
        "my_mobile_parseimg('\\1', '\\2', '\\3', " . intval($lazyload) . ", " . intval($pid) . ")",
    ), $message);
    $message = str_replace(chr(0) . chr(0) . chr(0) . 'xj_event', '', $message);
    return $message;
}

function my_mobile_parseimg($width, $height, $url)
{
    global $_G;
    $url = htmlspecialchars(str_replace(array('<', '>'), '', str_replace('\\"', '\"', $url)));
    if (strtolower(substr($url, 0, 7)) == 'static/') {
        $url = $_G['siteurl'] . $url;
    }
    if (!in_array(strtolower(substr($url, 0, 6)), array('http:/', 'https:', 'ftp://'))) {
        $url = 'http://' . $url;
    }
    return '<div class="img"><img src="' . $url . '" style=" width:100%;"/></div>';
}

function getattachs($tid, $pid)
{
    global $_G;
    $return = array();
    foreach (C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'pid', $pid) as $attach) {
        if ($attach['remote']) {
            $attach['attachment'] = $_G['setting']['ftp']['attachurl'] . 'forum/' . $attach['attachment'];
            if (substr($attach['attachment'], 0, 4) != 'http') {
                $attach['attachment'] = 'http://' . $attach['attachment'];
            } else {
                $attach['attachment'] = $attach['attachment'];
            }
        } else {
            $attach['attachment'] = $_G['setting']['attachurl'] . 'forum/' . $attach['attachment'];
        }
        $return[] = $attach;
    }
    return $return;
}

function std_class_object_to_array($stdclassobject)
{
    $_array = is_object($stdclassobject) ? get_object_vars($stdclassobject) : $stdclassobject;

    foreach ($_array as $key => $value) {
        $value       = (is_array($value) || is_object($value)) ? std_class_object_to_array($value) : $value;
        $array[$key] = $value;
    }

    return $array;
}
function postxml($url, $data)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_MUTE, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, "$data");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}
function postXmlCurl($xml, $url, $second = 30)
{
    //��ʼ��curl
    $ch = curl_init();
    //���ó�ʱ
    curl_setopt($ch, CURLOP_TIMEOUT, $second);
    //�������ô���������еĻ�
    //curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
    //curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    //����header
    curl_setopt($ch, CURLOPT_HEADER, false);
    //Ҫ����Ϊ�ַ������������Ļ��
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //post�ύ��ʽ
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    //����curl
    $data = curl_exec($ch);
    curl_close($ch);
    //���ؽ��
    if ($data) {
        curl_close($ch);
        return $data;
    } else {
        $error = curl_errno($ch);
        echo "curlError, error code:$error" . "<br>";
        echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>The reason for the error query</a></br>";
        curl_close($ch);
        return false;
    }
}

function get($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    # curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    if (!curl_exec($ch)) {
        error_log(curl_error($ch));
        $data = '';
    } else {
        $data = curl_multi_getcontent($ch);
    }
    curl_close($ch);
    return $data;
}

function getRandChar($length)
{
    $str    = null;
    $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $max    = strlen($strPol) - 1;
    for ($i = 0; $i < $length; $i++) {
        $str .= $strPol[rand(0, $max)]; //rand($min,$max)���ɽ���min��max������֮���һ���������
    }
    return $str;
}
//����ָ����С���ַ���
function createNoncestr($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
/**
 *     ���ã���ʽ��������ǩ��������Ҫʹ��
 */
function formatBizQueryParaMap($paraMap, $urlencode)
{
    $buff = "";
    ksort($paraMap);
    foreach ($paraMap as $k => $v) {
        if ($urlencode) {
            $v = urlencode($v);
        }
        //$buff .= strtolower($k) . "=" . $v . "&";
        $buff .= $k . "=" . $v . "&";
    }
    $reqPar;
    if (strlen($buff) > 0) {
        $reqPar = substr($buff, 0, strlen($buff) - 1);
    }
    return $reqPar;
}
//����ǩ��
function getSign($Obj)
{
    global $apikey;
    foreach ($Obj as $k => $v) {
        $Parameters[$k] = $v;
    }
    //ǩ������һ�����ֵ����������
    ksort($Parameters);
    $String = formatBizQueryParaMap($Parameters, false);
    //echo '��string1��'.$String.'</br>';
    //ǩ�����������string�����KEY
    $String = $String . "&key=$apikey";
    //echo "��string2��".$String."</br>";
    //ǩ����������MD5����
    $String = md5($String);
    //echo "��string3�� ".$String."</br>";
    //ǩ�������ģ������ַ�תΪ��д
    $result_ = strtoupper($String);
    //echo "��result�� ".$result_."</br>";
    return $result_;
}

/**
 *     ���ã�arrayתxml
 */
function arrayToXml($arr)
{
    $xml = "<xml>";
    foreach ($arr as $key => $val) {
        if (is_numeric($val)) {
            $xml .= "<" . $key . ">" . $val . "</" . $key . ">";

        } else {
            $xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
        }

    }
    $xml .= "</xml>";
    return $xml;
}

/**
 *     ���ã���xmlתΪarray
 */
function xmlToArray($xml)
{
    //��XMLתΪarray
    $array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
    return $array_data;
}

/**
 *     ���ã����ɿ��Ի��code��url
 */
function createOauthUrlForCode($redirectUrl)
{
    global $appid;
    $urlObj["appid"]         = $appid;
    $urlObj["redirect_uri"]  = urlencode($redirectUrl);
    $urlObj["response_type"] = "code";
    $urlObj["scope"]         = "snsapi_base";
    $urlObj["state"]         = "STATE" . "#wechat_redirect";
    $bizString               = formatBizQueryParaMap($urlObj, false);
    return "https://open.weixin.qq.com/connect/oauth2/authorize?" . $bizString;
}

/**
 *     ���ã����ɿ��Ի��openid��url
 */
function createOauthUrlForOpenid()
{
    global $appid, $appsecret, $code;
    $urlObj["appid"]      = $appid;
    $urlObj["secret"]     = $appsecret;
    $urlObj["code"]       = $code;
    $urlObj["grant_type"] = "authorization_code";
    $bizString            = formatBizQueryParaMap($urlObj, false);
    return "https://api.weixin.qq.com/sns/oauth2/access_token?" . $bizString;
}

/**
 *     ���ã�ͨ��curl��΢���ύcode���Ի�ȡopenid
 */
function getOpenid()
{
    $url = createOauthUrlForOpenid();
    //��ʼ��curl
    $ch = curl_init();
    //���ó�ʱ
    curl_setopt($ch, CURLOP_TIMEOUT, 30); //��ʱʱ��
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    //����curl�������jason��ʽ����
    $res = curl_exec($ch);
    curl_close($ch);
    //ȡ��openid
    $data   = json_decode($res, true);
    $return = $data['openid'];
    return $return;
}

function trimall($str) //ɾ���ո�

{
    $qian = array(" ", "��", "\t", "\n", "\r");
    $hou  = array("", "", "", "", "");
    return str_replace($qian, $hou, $str);
}

/**
 * ͨ��aid��ȡͼƬ����
 */
function getpicurl($aid, $tid)
{
    global $_G;
    $return = '';
    if ($aid) {
        $picatt = DB::fetch_first("SELECT remote,attachment,thumb FROM " . DB::table(getattachtablebytid($tid)) . " WHERE aid='{$aid}'");
        if ($picatt['remote']) {
            $picatt['attachment'] = $_G['setting']['ftp']['attachurl'] . 'forum/' . $picatt['attachment'];
            $picatt['attachment'] = substr($picatt['attachment'], 0, 4) != 'http' ? 'http://' . $picatt['attachment'] : $picatt['attachment'];
        } else {
            $picatt['attachment'] = $_G['setting']['attachurl'] . 'forum/' . $picatt['attachment'];
        }
    }
    $return = $picatt['attachment'];
    return $return;
}
