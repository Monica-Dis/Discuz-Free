<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['uid']<=0){
	exit('Access Denied');
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){  //����Ƿ������������
	$magapp = true;
}
//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();

$applyid = intval($_GET['applyid']);
$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid WHERE A.applyid=$applyid");
$tid = $userinfo['tid'];
$userinfo['ufielddata'] = unserialize($userinfo['ufielddata']);
$userinfo['avatar'] = '<img src="'.avatar($userinfo['uid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="60" height="60" align="absmiddle" style="-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;" />';
$userinfo['applycount'] = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$userinfo['uid']);



$items = DB::fetch(DB::query("SELECT A.*,B.authorid,B.subject FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid = B.tid WHERE A.tid = '$tid'"));
$setting = unserialize($items['setting']);
$userfield = unserialize($items['userfield']);
$selectuserfield = unserialize($items['userfield']);
$sysuserfield = unserialize($_G['setting']['activityfield']);
//�µı����ֶ�
if($setting['myuserfield']){
	$myuserfield = $eventcore->GetUserField($setting['myuserfield']);
}

//���ʼʱ��
$event_starttime = dgmdate($items['starttime'],'dt');


//�жϻ����Ȩ
	if($items['authorid'] == $_G['uid'] || $_G['groupid'] == 1 || in_array($_G['username'],$setting['event_admin'])){
		$event_admin = true;
	}
if(!$event_admin){
	exit('Have no legal power');
}




if($_GET['action'] == 'verify'){
	$result = array();
	if($event_admin){
		include DISCUZ_ROOT . './source/plugin/xj_event/include/func.php';
		$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid='$tid' and A.tid = B.tid");
		$setting = unserialize($thread['setting']);
		$checknum = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid= $tid AND uid=".$userinfo['uid']);  //������֤����
		$applynum = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1"); //�ѱ�������
		$applycountnum = DB::result_first("SELECT event_number FROM ".DB::table('xj_event')." WHERE tid='$tid'"); //�������
		if($checknum <= ($applycountnum-$applynum) or $applycountnum==0){
			DB::update('xj_eventapply',array('verify'=>1),"tid=$tid AND uid=".$userinfo['uid']);
			$apply = DB::fetch_first("SELECT uid,mobile,applynumber,seccode FROM ".DB::table('xj_eventapply')." WHERE first=1 AND tid= $tid AND uid=".$userinfo['uid']); 
			//���ֻ�����
			if($setting['seccode'] == 1){		
				include DISCUZ_ROOT . './source/plugin/xj_event/include/sms_func.php';
				$message = cutstr($thread['subject'],30).lang('plugin/xj_event', 'hdbmcgrs').':'.$apply['applynumber'].lang('plugin/xj_event', 'renyanzhengma').':'.$apply['seccode'].lang('plugin/xj_event', 'huodongshijian').' :'.$event_starttime;
				sendsms_vcode($apply['mobile'],$thread['subject'],$apply['applynumber'],$apply['seccode']);
				sendpm($apply['uid'],'',$message,$_G['uid']);
			}elseif($setting['success_sms'] == 1){
				include DISCUZ_ROOT . './source/plugin/xj_event/include/sms_func.php';
				sendsms_success($apply['mobile'],$thread['subject'],$event_starttime);
			}
			//��֪ͨ
			notification_add($apply['uid'], 'system',lang('plugin/xj_event', 'ningbmcjd').' <a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.$thread['subject'].'</a> '.lang('plugin/xj_event', 'yishenghtg'),array(),0);
			
			
			$result['full'] = 1;
			exit(json_encode($result));
		}else{
			$result['full'] = 2;
			exit(json_encode($result)); 
		}
	}else{
		$result['full'] = 2;
		exit(json_encode($result)); 
	}
}
if($_GET['action'] == 'noverify'){
	$result = array();
	if($event_admin){
		DB::update('xj_eventapply',array('verify'=>0),"tid=$tid AND uid=".$userinfo['uid']);
		$result['full'] = 1;
		exit(json_encode($result)); 
	}else{
		$result['full'] = 2;
		exit(json_encode($result)); 
	}
}
if($_GET['action'] == 'cancel'){
	$result = array();
	if($event_admin){
		//��ԭ����
		if($items['use_extcredits_num']>0){
			updatemembercount($userinfo['uid'],array($items['use_extcredits']=>$items['use_extcredits_num']));
		}
		DB::delete('xj_eventapply',"tid=$tid AND uid=".$userinfo['uid']);
		$result['full'] = 1;
		exit(json_encode($result)); 
	}else{
		$result['full'] = 2;
		exit(json_encode($result)); 
	}
}





$userapplyfield =array();
require_once libfile('function/profile');

if($setting[cost]){   //������������
	$value = array();
	$value['fieldid'] = 'costclass';
	$value['title'] = '��������';
	if($setting[nodaibaoming]){
		foreach ($setting['cost'] as $costvalue) {
			$value['value'] .= $costvalue['cost_name'].$userinfo['ufielddata']['cost'.$costvalue['id']].lang('plugin/xj_event','ren').' ';
		}
	}else{
		$value['value'] = $setting['cost'][$userinfo['ufielddata']['costclass']]['cost_name'];
	}
	$userapplyfield['field'][] = $value;
}
if($selectuserfield){
	foreach($userinfo['ufielddata'] as $key=>$v) {
		$value= array();
		if($key != 'bmmessage' && $key != 'applynumber'){
			if($sysuserfield[$key]){
				$value['fieldid'] = $key;
				$value['title'] = $sysuserfield[$key];
				$value['value'] = $userinfo['ufielddata'][$key];
				if($key == 'gender'){
					if($value['value'] == 1){
						$value['value'] = lang('plugin/xj_event', 'man');
					}elseif($value['value'] == 2){
						$value['value'] = lang('plugin/xj_event', 'woman');
					}else{
						$value['value'] = lang('plugin/xj_event', 'baomi');
					}
				}
				$userapplyfield['field'][] = $value;
			}
		}
	}
}

if($myuserfield){
	foreach($myuserfield as $field){
		$value = array();
		if($userinfo['ufielddata']['myfield'.$field['id']]){
			$value['fieldid'] = 'myfield'.$field['id'];
			$value['title'] = $field['title'];
			if($field['formtype'] == 'uploadfile'){
				$value['value'] = '<img src="'.$userinfo['ufielddata']['myfield'.$field['id']].'" style="width:100%;">';
			}else{
				$value['value'] = $userinfo['ufielddata']['myfield'.$field['id']];
			}
			$userapplyfield['field'][] = $value;
		}
	}
}







if(!$setting['nodaibaoming']){
	$query = DB::query("SELECT * FROM ".DB::table('xj_eventapply')." WHERE first<>1 AND tid=$tid AND uid=".$userinfo['uid']);
	$daibao = array();
	while($value = DB::fetch($query)){
		$value['ufielddata'] = unserialize($value['ufielddata']);

		if($setting[cost]){   //������������
			$apply = array();
			$apply['fieldid'] = 'costclass';
			$apply['title'] = lang('plugin/xj_event','baomingleixing');
			$apply['value'] = $setting['cost'][$value['ufielddata']['costclass']]['cost_name'];
			$value['applyinfo'][] = $apply;
		}


		foreach($selectuserfield as $fieldid) {
			$apply= array();
			if($fieldid != 'bmmessage'){
				$apply['fieldid'] = $fieldid;
				$apply['title'] = $sysuserfield[$fieldid];
				$apply['value'] = $value['ufielddata'][$fieldid];
				if($fieldid == 'gender'){
					if($value['value'] == 1){
						$value['value'] = lang('plugin/xj_event', 'man');
					}elseif($value['value'] == 2){
						$value['value'] = lang('plugin/xj_event', 'woman');
					}else{
						$value['value'] = lang('plugin/xj_event', 'baomi');
					}
				}
				$value['applyinfo'][] = $apply;
			}
		}

		if($myuserfield){
			foreach($myuserfield as $field){
				$apply = array();
				if($value['ufielddata']['myfield'.$field['id']]){
					$apply['fieldid'] = 'myfield'.$field['id'];
					$apply['title'] = $field['title'];
					if($field['formtype'] == 'uploadfile'){
						$apply['value'] = '<img src="'.$value['ufielddata']['myfield'.$field['id']].'" style="width:100%;">';
					}else{
						$apply['value'] = $value['ufielddata']['myfield'.$field['id']];
					}
					$value['applyinfo'][] = $apply;
				}
			}
		}


		$daibao[] = $value;
	}
}



include template('wsq_event_apply_view',0,'source/plugin/xj_event/module/wsqcenter/template');


?>