<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){  //����Ƿ��ǰ��������
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){
	$magapp = true;
}
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan')>0){
	$QianFan = true;	
}
//�жϵ�¼״̬
if($Appbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe";
		});
    });
	</script>');
}

if($magapp && !$_G['uid']){ //���׵�¼
	exit('<script src="http://app.lxh.magcloud.cc/public/static/dest/js/libs/magjs-x.js"></script>
	<script>
		mag.toLogin(function(){
			window.location.href="'.$_G['siteurl'].'/plugin.php?id=xj_event:wsqcenter&mod=my_join";
		});
	</script>
	');
}
if($QianFan && !$_G['uid']){ //ǧ����¼
	exit('<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>
	');
}



if(!$_G['uid']){
	$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_publishe');
	dheader('location: '.$url);
	exit;
}

//VIP�û���
$vipgroup = unserialize($_G['cache']['plugin']['xj_event']['vipgroupid']);




if($_GET['action'] == 'cannel'){
	if($_GET['formhash'] != $_G['formhash']){
			showmessage('submit_invalid');
	}
	$tid = intval($_GET['tid']);
	$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.tid = $tid");
	if($items['activityexpiration']>$timestamp){
		$count = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." WHERE tid = $tid and uid = ".$_G['uid']);
		if($count < 1){
			exit('Access Denied');
		}
		$applynumber = $count;
		DB::query("DELETE FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid = ".$_G['uid']);
		//֪ͨ
		notification_add($items['authorid'], 'activity', 'activity_cancel', array(
				'tid' => $tid,
				'subject' => $items['subject'],
				'reason' => $message
			));
			
		if($_GET['inajax']){
			$result = array();
			$result['full'] = 1;
			$result['return'] = $return;
			$result['message'] = lang('plugin/xj_event', 'huodongquxiaochenggong');
			$result['message'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$result['message']):$result['message'];
			$result['url'] = $_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=my_join';
			echo json_encode($result);
			exit();
		}else{
			dheader('location: '.$retrunurl);
		}
	}else{
		exit('Access Denied');
	}
}




if($_GET['action'] == 'list'){
	$perpage = 15; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid inner join ".DB::table('xj_eventapply')." C on A.tid=C.tid WHERE C.first=1 AND C.uid = ".$_G['uid']);
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	$query = DB::query("SELECT A.*,B.subject,C.*,C.uid as applyuid FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid inner join ".DB::table('xj_eventapply')." C on A.tid=C.tid WHERE C.first=1 AND C.uid = ".$_G['uid']." ORDER BY C.dateline DESC  LIMIT $start_limit,$perpage");
	while($value = DB::fetch($query)){
	
		if($value['activityaid']){
			$value['activityaid_url'] = $value['activityaid']?getforumimg($value['activityaid'],0,110,80):'static/image/common/nophoto.gif';
		}elseif(!$value['activityaid'] && !$value['activityaid_url']){
			$value['activityaid_url'] = 'static/image/common/nophoto.gif';
		}
		if($value['activitybegin']<= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']){
			$eventstatehtml = '<span style="color:#ff6600;">'.lang('plugin/xj_event', 'hdbmz').'</span>';
		}elseif($_G['timestamp']<=$value['starttime']){
			$eventstatehtml = '<span style="color:#c4c4c4;">'.lang('plugin/xj_event', 'hdwks').'</span>';
		}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']){
			$eventstatehtml = '<span style="color:#45bf3f;">'.lang('plugin/xj_event', 'hdjxz').'</span>';
		}elseif($_G['timestamp']>=$value['endtime']){
			$eventstatehtml = '<span style="color:#ff495e;">'.lang('plugin/xj_event', 'hdyjs').'</span>';
		}
		$value['bmnumber'] = intval(DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']));
		$value['tgbmnumber'] = intval(DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE verify=1 AND tid=".$value['tid']));
		
		$setting = unserialize($value['setting']);
		$numberhtml = '';
		$costhtml = '';
		$totalprice = 0;
		if($setting['nodaibaoming']){
			$ufielddata = unserialize($value['ufielddata']);
			if($setting['cost']){
				foreach($setting['cost'] as $cvalue){
					$totalprice = $totalprice + $cvalue['cost_price']*$ufielddata['cost'.$cvalue['id']];	
					if($ufielddata['cost'.$cvalue['id']]){
						$numberhtml .= $cvalue['cost_name'].'x'.$ufielddata['cost'.$cvalue['id']].' ';
					}
				}
				
				$costhtml = '&yen;'.$totalprice;
			}else{
				if($value['use_cost']>0){
					$totalprice = $value['use_cost'] * $value['applynumber'];
					$costhtml = '&yen;'.$totalprice;
					if($setting['eventpay']==0){
						$costhtml .= ' '.lang('plugin/xj_event', 'xianxiazhifu');
					}	
				}else{
					$costhtml = lang('plugin/xj_event', 'mianfei');
				}
				
				$numberhtml = $value['applynumber'].lang('plugin/xj_event', 'ren');
				
			}
		}else{
			$applynumber = 0;
			$myapply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']." AND uid=".$value['applyuid']);
			if($setting['cost']){
				foreach($myapply as $applyvalue){
					$applynumber = $applynumber+$applyvalue['applynumber'];
					$thisufielddata = unserialize($applyvalue['ufielddata']);
					$totalprice = $applynumber * $setting['cost'][$thisufielddata['costclass']]['cost_price'];
				}
				$numberhtml = $applynumber.lang('plugin/xj_event', 'ren');
				$costhtml = '&yen;'.$totalprice;
				if($setting['eventpay']==0){
					$costhtml .= ' '.lang('plugin/xj_event', 'xianxiazhifu');
				}	
			}else{
				foreach($myapply as $applyvalue){
					$applynumber = $applynumber+$applyvalue['applynumber'];
				}
				$numberhtml = $applynumber.lang('plugin/xj_event', 'ren');
				if($value['use_cost']>0){
					$totalprice = $applynumber * $value['use_cost'];
					$costhtml = '&yen;'.$totalprice;
					if($setting['eventpay']==0){
						$costhtml .= ' '.lang('plugin/xj_event', 'xianxiazhifu');
					}	
				}else{
					$costhtml = lang('plugin/xj_event', 'mianfei');
				}
				
			}
		}
		$fkbtnhtml = '';
		$qxbtnhtml = '';
		$bmzthtml = '';
		if($_G['timestamp']<=$value['endtime']){
			//֧����ť
			if($setting['eventpay']>0 && $value['pay_state']<1){
				if(in_array($value['groupid'],$vipgroup)){
					$fkbtnhtml = '<a href="'.$_G['siteurl']."plugin.php?id=xj_event:event_pay&tid=".$value['tid'].'" data-ajax="false" style="font-weight:normal;color:#ff6724; border:1px solid #ff6724; padding:5px 10px 5px 10px; float:right; font-size:12px; margin-right:5px; border-radius:5px;">VIP'.lang('plugin/xj_event', 'youhuizhifu').'</a>';
				}else{
					$fkbtnhtml = '<a href="'.$_G['siteurl']."plugin.php?id=xj_event:event_pay&tid=".$value['tid'].'" data-ajax="false" style="font-weight:normal;color:#ff6724; border:1px solid #ff6724; padding:5px 10px 5px 10px; float:right; font-size:12px; margin-right:5px; border-radius:5px;">'.lang('plugin/xj_event', 'lijifukuan').'</a>';
				}
			}
			
			//ȡ����ť
			if($value['verify']==0){
				$qxbtnhtml = '<a href="plugin.php?id=xj_event:event_join_modify&tid='.$value['tid'].'" data-ajax="false" style="font-weight:normal;color:#aaaaaa; border:1px solid #aaaaaa; padding:5px 10px 5px 10px; float:right; font-size:12px; margin-right:5px; border-radius:5px;">'.lang('plugin/xj_event', 'xiugaibaoming').'</a>';
			}
		}
		
		if($value['verify']){
			$bmzthtml = '<a href="plugin.php?id=xj_event:wsqcenter&mod=my_ticket&tid='.$value['tid'].'" data-ajax="false" style="font-weight:normal;color:#4ac46c; border:1px solid #4ac46c; padding:5px 10px 5px 10px; float:right; font-size:12px; margin-right:5px; border-radius:5px;">'.lang('plugin/xj_event', 'huodongpingzheng').'</a> <span style="float:right; padding:6px 8px; color:#3ab943; border-radius:5px; font-size:12px; margin-left:5px;">'.lang('plugin/xj_event', 'baomingchenggong').'</span>';
		}
		
		echo '<div id="join_'.$value['tid'].'_'.$_G['uid'].'"><div style=" margin-top:5px;line-height:20px; font-size:11px; color:#6b6b6b; padding-left:15px;">
            	'.dgmdate($value['dateline'],"Y.m.d").lang('plugin/xj_event','baomingbghd').'
            </div>
			<div style="padding:10px 15px 5px 15px; margin-top:0px; background-color:#FFF;">
            	<div style="padding-bottom:12px; border-bottom:1px solid #eee;" onclick="window.location.href=\'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$value['tid'].'\';">
                	<div style=" float:left;width:110px;">
                    	<img src="'.$value['activityaid_url'].'" style="width:110px; height:80px;">
                    </div>
                	<div style=" margin-left:120px; padding-top:1px; min-height:39px;">
                    	<span style="line-height:16px; font-size:13px; color:#454545;">'.$value['subject'].'</span>
                    </div>
                    <div style=" margin-left:120px; padding-top:5px; padding-right:5px;">
			<span style="line-height:12px; font-size:11px; color:#999;">'.lang('plugin/xj_event', 'shijian').dgmdate($value['starttime'],"Y.m.d h:i").'<br>'.lang('plugin/xj_event', 'baoming').$numberhtml.'</span>
                        <span style="line-height:16px; font-size:15px; color:#ff833f; float:right;">'.$costhtml.'</span>
                    </div>
                </div>
                <div style=" padding-top:5px; font-size:12px;">
                	<span style="line-height:28px; color:#828282;">'.$eventstatehtml.'</span>
                    '.$fkbtnhtml.$qxbtnhtml.$bmzthtml.'
                    
                </div>
                <div style="clear:both;"></div>
            </div></div>';
	}
	if($page<@ceil($listcount/$perpage)){
		$page = $page+1;
		echo '<div onClick="moreitems('.$page.');" id="morebtn" style=" text-align:center;line-height:40px;color:#bbb;">'.lang('plugin/xj_event', 'jiazaigengduo').'>>></div>';
	}
	exit();
}



include template('my_join',0,'source/plugin/xj_event/module/wsqcenter/template');
?>