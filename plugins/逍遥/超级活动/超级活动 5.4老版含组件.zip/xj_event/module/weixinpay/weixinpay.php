<?php



$appid = '';     //���ںŵ�appid
$appsecret = '';      //���ںŵ�appsecret



//ͨ��code���openid
if (!isset($_GET['code']))
{
	//��ȡ��һҳ������
	$domainname=parse_url($_SERVER["HTTP_REFERER"]);
	$apptype = $_GET['apptype'];
	
	//����΢�ŷ���code��
	$thisurl = dhtmlspecialchars('http'.($_G['isHTTPS']?'s':'').'://'.$_SERVER['HTTP_HOST']).$_SERVER['REQUEST_URI'].'&domainname='.$domainname['host'];
	$url = createOauthUrlForCode($thisurl);
	Header("Location: $url"); 
	exit();
}else
{
	//��ȡcode�룬�Ի�ȡopenid
	$code = $_GET['code'];
	$openid = getOpenId();
}

$siteurl = 'http://'.$_GET['domainname'].'/';
$apptype = $_GET['apptype'];


if($openid){
	$tid = intval($_GET['tid']);
	if($apptype == 'xj_event'){
		$url = $siteurl.'plugin.php?id=xj_event:wsq_pay&tid='.$tid.'&openid='.$openid;
	}elseif($apptype == 'xj_card'){
		$url = $siteurl.'plugin.php?id=xj_card:xj_card_pay&openid='.$openid;
	}
	Header("Location: $url"); 
	exit();
}






function dhtmlspecialchars($string) {
	if(is_array($string)) {
		foreach($string as $key => $val) {
			$string[$key] = dhtmlspecialchars($val);
		}
	} else {
		$string = str_replace(array('&', '"', '<', '>'), array('&amp;', '&quot;', '&lt;', '&gt;'), $string);
		if(strpos($string, '&amp;#') !== false) {
			$string = preg_replace('/&amp;((#(\d{3,5}|x[a-fA-F0-9]{4}));)/', '&\\1', $string);
		}
	}
	return $string;
}
/**
* 	���ã���ʽ��������ǩ��������Ҫʹ��
*/
function formatBizQueryParaMap($paraMap, $urlencode)
{
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		//$buff .= strtolower($k) . "=" . $v . "&";
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0) 
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
/**
 * 	���ã����ɿ��Ի��code��url
 */
function createOauthUrlForCode($redirectUrl)
{
	global $appid;
	$urlObj["appid"] = $appid;
	$urlObj["redirect_uri"] = urlencode($redirectUrl);
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}
/**
 * 	���ã����ɿ��Ի��openid��url
 */
function createOauthUrlForOpenid()
{
	global $appid,$appsecret,$code;
	$urlObj["appid"] = $appid;
	$urlObj["secret"] = $appsecret;
	$urlObj["code"] = $code;
	$urlObj["grant_type"] = "authorization_code";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
}
/**
 * 	���ã�ͨ��curl��΢���ύcode���Ի�ȡopenid
 */
function getOpenid()
{
	$url = createOauthUrlForOpenid();
	//��ʼ��curl
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, 30);   //��ʱʱ��
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//����curl�������jason��ʽ����
	$res = curl_exec($ch);
	curl_close($ch);
	//ȡ��openid
	$data = json_decode($res,true);
	$return = $data['openid'];
	return $return;
}
//From: Dism��taobao��com
?>