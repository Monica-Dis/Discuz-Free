<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0 || $_SERVER['HTTP_MAG_MGSC']){
	$Appbyme = true;
}
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPP')>0){
	$magapp = true;
}

$siteid = $_G['wechat']['setting']['wsq_siteid'];
require_once libfile('function/post');

$shareimg = $_G['siteurl'].$_G['style']['boardimg'];
$sharetitle = $_G['setting']['bbname'];


//��ȡʡ�ݺͳ���
if($_GET['action'] == 'getcitydata'){
	
	$result = array();
	$query = DB::query("SELECT name as text,id as value FROM ".DB::table('common_district')." WHERE upid=0");
	while($value = DB::fetch($query)){
		$value['children'] = DB::fetch_all("SELECT name as text,id as value FROM ".DB::table('common_district')." WHERE upid=".$value['value']);
		foreach($value['children'] as $key=>$v){
			$value['children'][$key]['text'] =  $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$v['text']):$v['text'];
		}
		
		
		$value['text'] = $_G['charset'] == 'gbk'?iconv('gbk','utf-8',$value['text']):$value['text'];
		$result[] = $value;
	}
	echo json_encode($result);
	exit;
}



//΢��JS�ӿڵ���CODE��ת
if($_G['cache']['plugin']['xj_event']['weixin_js']){
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')>0 && $_GET['action'] != 'itemslist'){
	$isWeiXin = true;
	//����΢��֧������
	if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
		@include $xj_event_wxset;
	}
	$appid = $wxset['appid'];
	$appsecret = $wxset['appsecret'];
	if($appid && $appsecret){
		require_once libfile('function/cache');
		//��ȡaccess_token
		if(file_exists($token = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_token.php')) {
			@include $token;
		}
		if($_G['timestamp']-intval($token['timestamp'])>7100){
			$cul = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret ;
			$cx = get($cul);
			$token = json_decode($cx,true) ;
			$token['timestamp'] = $_G['timestamp'];
			writetocache('xj_event_token',getcachevars(array('token'=>$token)));
		}
		//��ȡjsapi_ticket
		if(file_exists($jsapiticke = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_jsapiticke.php')) {
			@include $jsapiticke;
		}
		if($_G['timestamp']-intval($jsapiticke['timestamp'])>7100){
			$cul = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$token['access_token'].'&type=jsapi';
			$cx = get($cul);
			$jsapiticke = json_decode($cx,true) ;
			$jsapiticke['timestamp'] = $_G['timestamp'];
			writetocache('xj_event_jsapiticke',getcachevars(array('jsapiticke'=>$jsapiticke)));
		}
		$jsapi_ticket = $jsapiticke['ticket'];
		$noncestr = getRandChar(12);
		$timestamp = $_G['timestamp'];
		$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
		$string1 = "jsapi_ticket=$jsapi_ticket&noncestr=$noncestr&timestamp=$timestamp&url=$url";
		$signature = sha1($string1);
	}
}
}








$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_offline_class']);
$offlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$offlineclass[$eventclass[0]] = $eventclass[1];
}
$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['event_online_class']);
$onlineclass = array();
foreach($tmp as $key=>$value){
	$eventclass = explode("|",$value);
	$onlineclass[$eventclass[0]] = $eventclass[1];
}

$citykey = $_GET['citykey'];
if(!$_G['cache']['plugin']['xj_event']['event_city']){
	$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['city']);
	$cityclass = array();
	foreach($tmp as $key=>$value){
		$ctmp = array();
		$ctmp[1] = trim($value);
		$ctmp[2] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_event')." WHERE citys='".$ctmp[1]."'");
		$ctmp[3] = urlencode(trim($value));
		$cityclass[] = $ctmp;
	}
	
	if($citykey !== ''){
		$city = $cityclass[$citykey][1];
	}
}else{
	$province = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE level = 1 order by id");
	foreach($province as $key=>$value){
		$province[$key]['city'] = DB::fetch_all("SELECT * FROM ".DB::table('common_district')." WHERE upid = ".$value['id']);
	}
	
	if($citykey !== ''){
		$city = DB::result_first("SELECT name FROM ".DB::table('common_district')." WHERE id = ".intval($citykey));
	}
}



//�ж��Ƿ��з����Ȩ��
if(!in_array('xj_event',$_G['group']['allowthreadplugin'])){
	$eventpubadmin = true;
}


if($_GET['action'] == 'itemslist'){
	$sqlstr = "";
	$orderstr = "ORDER BY A.eventorder DESC , B.dateline DESC";  //�����ʱ������
	//$orderstr = "ORDER BY A.starttime DESC";  //���ʼʱ������
	
	
	if($_GET['pc']){
		if($_GET['pc'] == 1){
			$sqlstr .= " AND A.postclass=1";
			if($_GET['classid']){
				$sqlstr .= " AND A.offlineclass=".intval($_GET['classid']);
			}
		}elseif($_GET['pc'] == 2){
			$sqlstr .= " AND A.postclass=2";
			if($_GET['classid']){
				$sqlstr .= " AND A.onlineclass=".intval($_GET['classid']);
			}
		}elseif($_GET['pc'] == 3){
			$joinstr = " left join ".DB::table('xj_eventapply')." C on A.tid=C.tid ";
			$sqlstr .= " AND C.uid = ".$_G['uid'];
		}elseif($_GET['pc'] == 4){
			$sqlstr .= " AND B.authorid=".$_G['uid'];
		}
	}
	
	if($_GET['city']){
		$city = addslashes($_GET['city']);
		$sqlstr .=" AND A.citys='$city'";
	}
	if($_GET['keyword']){
		$keyword = addslashes($_GET['keyword']);
		$sqlstr .= " AND B.subject LIKE '%$keyword%'";
	}
	
	
	
	$perpage = 10; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid $joinstr WHERE 1=1 ".$sqlstr."");
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid $joinstr WHERE 1=1 ".$sqlstr." AND B.displayorder>=0 $orderstr LIMIT $start_limit,$perpage");
	while($value = DB::fetch($query)){
		
		if($value['use_cost']>0){
			$value['use_cost_str'] = '&yen;<span style="font-size:24px;">'.$value['use_cost'].'</span>';
		}else{
			$value['use_cost_str'] = lang('plugin/xj_event', 'mianfei');
		}
		
		
		//������ͷ��
		$value['avatar'] = '<img src="'.avatar($value['authorid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="28" height="28" align="absmiddle" style="border-radius:16px;float:left;" />';
		
		//�鿴��
		$value['views'] = $value['views'] + intval(DB::result_first("SELECT addviews FROM ".DB::table('forum_threadaddviews')." WHERE tid=".$value['tid']));
		
		
		if($value['activityaid']){
			$value['activityaid_url'] = $value['activityaid']?getforumimg($value['activityaid'],0,500,320):'static/image/common/nophoto.gif';
		}elseif(!$value['activityaid'] && !$value['activityaid_url']){
			$value['activityaid_url'] = 'static/image/common/nophoto.gif';
		}
		//����
		if($value['postclass']==1){
			$value['zclass'] = $offlineclass[$value['offlineclass']];
		}else{
			$value['zclass'] = $onlineclass[$value['onlineclass']];
		}
		//�жϱ���
		if($value['activitybegin']<= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdbmz');
			$value['eventstatestyle'] = '#00cd30';
		}elseif($_G['timestamp']<=$value['starttime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdwks');
			$value['eventstatestyle'] = '#ffb43f';
		}elseif($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdjxz');
			$value['eventstatestyle'] = '#e44268';
		}elseif($_G['timestamp']>=$value['endtime']){
			$value['eventstatetext'] = lang('plugin/xj_event', 'hdyjs');
			$value['eventstatestyle'] = '#bbbbbb';
		}
		//�ʱ��
		$value['starttimetext'] = date('Y/m/d',$value['starttime']);
		$value['endtimetext'] = date('Y/m/d',$value['endtime']);
		
		
		echo '<div class="item" data-url="'.$_G['siteurl'].'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid='.$value['tid'].'" style=" margin-bottom:10px;background-color:#ffffff;border-radius:2px; padding:5px 0px;">
        	<div style=" padding:6px 10px;line-height:28px; font-size:15px;overflow: hidden; white-space: nowrap; text-overflow: ellipsis;">
				'.$value['avatar'].'<span style=" padding-left:8px;color:#050505;font-size:14px;float:left;">'.$value['author'].'</span><img src="source/plugin/xj_event/module/wsqcenter_hdb/images/vip.png" style=" width:20px;height:20px;margin-left:8px;float:left;margin-top:3px;"/>
				<span style=" float:right;font-size:14px;color:'.$value['eventstatestyle'].';">'.$value['eventstatetext'].'</span>
            </div>
            <div style="margin-top:5px;">
            	<img src="'.$value['activityaid_url'].'" style="width:100%; height:220px;">
            </div>
			<div style="padding:8px 18px 4px 18px;">
				<span style="color:#2c2c2c;font-size:16px;">'.$value['subject'].'</span>
			</div>
			<div style="padding:5px 12px 8px 12px;">
				<div style="float:left; width:50%;font-size:12px; color:#8e8e8e;">
					'.$value['starttimetext'].' '.date('H:i',$value['starttime']).' '.weekday($value['starttime']).'<br>
					'.$value['zclass'].'
				</div>
				<div style=" padding-top:15px; margin-left:60%px;font-size:16px; color:#ff5a00;text-align:right;">
					'.$value['use_cost_str'].'
				</div>
			</div>
            <div style="clear:both;"></div>
        </div>';
	}
	exit();
}

//�����ֻ�����ͼ��
loadcache('xj_event_mobileicon');

function weekday($time){ 
  if(is_numeric($time)){ 
	  $weekday = array(lang('plugin/xj_event', 'zhouri'),lang('plugin/xj_event', 'zhouyi'),lang('plugin/xj_event', 'zhouer'),lang('plugin/xj_event', 'zhousan'),lang('plugin/xj_event', 'zhousi'),lang('plugin/xj_event', 'zhouwu'),lang('plugin/xj_event', 'zhouliu')); 
	  return $weekday[date('w', $time)]; 
  }
  return false;
} 




function std_class_object_to_array($stdclassobject)
{
    $_array = is_object($stdclassobject) ? get_object_vars($stdclassobject) : $stdclassobject;

    foreach ($_array as $key => $value) {
        $value = (is_array($value) || is_object($value)) ? std_class_object_to_array($value) : $value;
        $array[$key] = $value;
    }

    return $array;
}
function postxml($url,$data){
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}
function postXmlCurl($xml,$url,$second=30)
{		
	//��ʼ��curl        
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, $second);
	//�������ô���������еĻ�
	//curl_setopt($ch,CURLOPT_PROXY, '8.8.8.8');
	//curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	//����header
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	//Ҫ����Ϊ�ַ������������Ļ��
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//post�ύ��ʽ
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	//����curl
	$data = curl_exec($ch);
	curl_close($ch);
	//���ؽ��
	if($data)
	{
		curl_close($ch);
		return $data;
	}
	else 
	{ 
		$error = curl_errno($ch);
		echo "curlError, error code:$error"."<br>"; 
		echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>The reason for the error query</a></br>";
		curl_close($ch);
		return false;
	}
}

function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}
//����ָ����С���ַ���
function createNoncestr( $length = 32 ){
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {  
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
	}  
	return $str;
}
/**
* 	���ã���ʽ��������ǩ��������Ҫʹ��
*/
function formatBizQueryParaMap($paraMap, $urlencode)
{
	$buff = "";
	ksort($paraMap);
	foreach ($paraMap as $k => $v)
	{
		if($urlencode)
		{
		   $v = urlencode($v);
		}
		//$buff .= strtolower($k) . "=" . $v . "&";
		$buff .= $k . "=" . $v . "&";
	}
	$reqPar;
	if (strlen($buff) > 0) 
	{
		$reqPar = substr($buff, 0, strlen($buff)-1);
	}
	return $reqPar;
}
//����ǩ��
function getSign($Obj){
	global $apikey;
	foreach ($Obj as $k => $v)
	{
		$Parameters[$k] = $v;
	}
	//ǩ������һ�����ֵ����������
	ksort($Parameters);
	$String = formatBizQueryParaMap($Parameters, false);
	//echo '��string1��'.$String.'</br>';
	//ǩ�����������string�����KEY
	$String = $String."&key=$apikey";
	//echo "��string2��".$String."</br>";
	//ǩ����������MD5����
	$String = md5($String);
	//echo "��string3�� ".$String."</br>";
	//ǩ�������ģ������ַ�תΪ��д
	$result_ = strtoupper($String);
	//echo "��result�� ".$result_."</br>";
	return $result_;
}

/**
 * 	���ã�arrayתxml
 */
function arrayToXml($arr)
{
	$xml = "<xml>";
	foreach ($arr as $key=>$val)
	{
		 if (is_numeric($val))
		 {
			$xml.="<".$key.">".$val."</".$key.">"; 

		 }
		 else
			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";  
	}
	$xml.="</xml>";
	return $xml; 
}

/**
 * 	���ã���xmlתΪarray
 */
function xmlToArray($xml)
{		
	//��XMLתΪarray        
	$array_data = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
	return $array_data;
}

/**
 * 	���ã����ɿ��Ի��code��url
 */
function createOauthUrlForCode($redirectUrl)
{
	global $appid;
	$urlObj["appid"] = $appid;
	$urlObj["redirect_uri"] = urlencode($redirectUrl);
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}

/**
 * 	���ã����ɿ��Ի��openid��url
 */
function createOauthUrlForOpenid()
{
	global $appid,$appsecret,$code;
	$urlObj["appid"] = $appid;
	$urlObj["secret"] = $appsecret;
	$urlObj["code"] = $code;
	$urlObj["grant_type"] = "authorization_code";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
}

/**
 * 	���ã�ͨ��curl��΢���ύcode���Ի�ȡopenid
 */
function getOpenid()
{
	$url = createOauthUrlForOpenid();
	//��ʼ��curl
	$ch = curl_init();
	//���ó�ʱ
	curl_setopt($ch, CURLOP_TIMEOUT, 30);   //��ʱʱ��
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//����curl�������jason��ʽ����
	$res = curl_exec($ch);
	curl_close($ch);
	//ȡ��openid
	$data = json_decode($res,true);
	$return = $data['openid'];
	return $return;
}

//ɾ��΢����Ƕ���
/*
$pluginid = 'xj_event';
require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);
exit('fff');
*/
?>