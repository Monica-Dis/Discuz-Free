<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//����
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
$tid = intval($_GET['tid']);


if($_GET['action'] == 'userlist'){
	$perpage = 20; //ÿҳ��
	$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid LEFT JOIN ".DB::table('xj_event_signed')." C ON A.uid = C.uid AND C.tid=$tid WHERE A.tid=$tid AND A.first=1");
	$page = $_GET['page']?$_GET['page']:1;
	$start_limit = ($page - 1) * $perpage;
	$query = DB::query("SELECT A.uid,B.username,C.dateline FROM ".DB::table('xj_eventapply')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid LEFT JOIN ".DB::table('xj_event_signed')." C ON A.uid = C.uid AND C.tid=$tid WHERE A.tid=$tid AND A.first=1 ORDER BY C.dateline LIMIT $start_limit,$perpage");
	while($value = DB::fetch($query)){
		$value['applycount'] = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=$tid AND uid=".$value['uid']);
		$value['avatar'] = '<img src="'.avatar($value['uid'], 'middle', true, false, true).'?random='.random(2).'" onerror="this.onerror=null;this.src=\''.$_G['setting']['ucenterurl'].'/images/noavatar_middle.gif\'" width="32" height="32" align="absmiddle" style="-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;" />';
		echo '<div style=" border-bottom:1px solid #c8c8c8; padding:6px 0px;">
                	<div style=" float:left;text-align:center;width:40px;">'.($value['applycount']>1?'<span style=" margin-left:-2px; margin-top:-2px; width:15px; font-size:9px; padding:1px; background-color:#f64545;color:#fff;position:absolute;-moz-border-radius: 8px; -webkit-border-radius: 8px; border-radius:8px;">'.$value['applycount'].'</span>':'').$value['avatar'].'</div>
                    <div style=" line-height:32px; margin-left:41px;font-size:16px;color:#828282;">'.$value['username'].($value['dateline']?'<span style="float:right; font-size:16px;color:#46b145;">'.lang('plugin/xj_event', 'yiqiandao').'</span>':'<span style="float:right; font-size:16px;color:#f64545;">'.lang('plugin/xj_event', 'weiqiandao').'</span>').'</div>
					<div style="clear:both;"></div>
                </div>';
	}
	if($page<@ceil($listcount/$perpage)){
	$page = $page+1;
	echo '<div style="height:40px;margin-top:10px;" id="more1btn" onclick="signedlist('.$page.');">
                	<div style=" background-color:#fff;height:40px; line-height:40px; text-align:center; color:#aaa; -moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px;">'.lang('plugin/xj_event', 'djckgd').'</div>
                </div>';
	}
	
	exit();
}


include template('wsq_signed_list',0,'source/plugin/xj_event/module/signed/template');
?>