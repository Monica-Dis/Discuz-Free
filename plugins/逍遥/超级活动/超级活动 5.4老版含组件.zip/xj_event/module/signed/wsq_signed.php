<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//安米
if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme')>0){
	$Appbyme = true;
}
$tid = intval($_GET['tid']);
if($_G['uid']<1){
	dheader('location: '.$_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=xj_event:wsq_signed&tid='.$tid));
	exit;
}




$validation = $_GET['validation'];
$thread =  DB::fetch_first("SELECT * FROM ".DB::table('forum_thread')." WHERE tid='$tid'");
$count = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_signed')." WHERE tid='$tid' AND uid=".$_G['uid']);
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' AND verify = 1 AND uid=".$_G['uid']);

$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid=$tid");
$setting = unserialize($items['setting']);

if(!$setting['signed']['open']){
	$return = 4;
}elseif(!$apply && $_G['uid']>0){
	//showmessage(lang('plugin/xj_event', 'nmybmbhdhz'));
	$return = 2;
}elseif($count>0){
	//showmessage(lang('plugin/xj_event', 'nyjqgdl'));
	$signtime = DB::result_first("SELECT dateline FROM ".DB::table('xj_event_signed')." WHERE tid='$tid' AND uid=".$_G['uid']);
	$signtime = date('Y-m-d H:i:s',$signtime);
	$return = 3;
}else{
	$sign = array();
	$sign['tid'] = $tid;
	$sign['uid'] = $_G['uid'];
	$sign['dateline'] = $_G['timestamp'];
	DB::insert('xj_event_signed',$sign);
	$return = 1;
}


include template('wsq_signed',0,'source/plugin/xj_event/module/signed/template');

?>