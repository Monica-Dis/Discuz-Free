<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



if($_GET['action'] == 'delete'){
	if($_GET['formhash'] != $_G['formhash']){
		exit('error');
	}
	$zpid = intval($_GET['zpid']);
	DB::delete('xj_event_zhuanpan',"zpid=$zpid");
}




$tid = intval($_GET['tid']);
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid = $tid");
$setting = unserialize($items['setting']);


$selectuserfield = unserialize($items['userfield']);
$sysuserfield = unserialize($_G['setting']['activityfield']);
require_once libfile('function/profile');
loadcache('profilesetting');


$perpage = 15; //ÿҳ��
$listcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_zhuanpan')." WHERE tid=$tid");
$page = $_GET['page']?$_GET['page']:1;
if(@ceil($listcount/$perpage) < $page) {
	$page = 1;
}
$start_limit = ($page - 1) * $perpage;
$multipage = multi($listcount,$perpage,$page,"plugin.php?id=xj_event:event_zhuanpan&mod=awardlist&tid=$tid",$_G['setting']['threadmaxpages']);

$query = DB::query("SELECT A.*,B.username,C.ufielddata FROM ".DB::table('xj_event_zhuanpan')." A LEFT JOIN ".DB::table('common_member')." B ON A.uid=B.uid LEFT JOIN ".DB::table('xj_eventapply')." C ON B.uid = C.uid GROUP BY A.uid ORDER BY A.dateline DESC LIMIT $start_limit,$perpage");
$joinlist = array();
while($value = DB::fetch($query)){
	if($value['awardtime']){
		$value['awardtime'] = dgmdate($value['awardtime']);
	}else{
		$value['awardtime'] = '';
	}
	
	$value['ufielddata'] = unserialize($value['ufielddata']);
	$ufielddata = array();
	foreach($value['ufielddata'] as $key => $fieldid) {
		$data = profile_show($key, $value['ufielddata']);
		if($_G['cache']['profilesetting'][$key]['formtype'] == 'file') {
			$data = '<a href="'.$data.'" target="_blank" onclick="zoom(this, this.href, 0, 0, 0); return false;">'.lang('forum/misc', 'activity_viewimg').'</a>';
		}
		if($key=='birthday'){
			$ufielddata[$key]['value'] = $fieldid;
		}else{
			$ufielddata[$key]['value'] = $data;
		}
		if($key=='qq'){
			$ufielddata[$key]['value'] = '<a href="http://wpa.qq.com/msgrd?v=3&uin='.$fieldid.'&Site='.$_G['setting']['bbname'].'&Menu=yes&from=discuz" target="_blank" title="'.lang('spacecp', 'qq_dialog').'"><img src="'.STATICURL.'/image/common/qq.gif" alt="QQ" style="margin:0px;"/></a>'.$fieldid;
		}
	}
	$value['ufielddata'] = $ufielddata;
	//��ȡ��������
	$joinlist[] = $value;
}

include template('awardlist',0,'source/plugin/xj_event/module/zhuanpan/template');
?>