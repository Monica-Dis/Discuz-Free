<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tid = intval($_GET['tid']);
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE tid = $tid");
$setting = unserialize($items['setting']);

if($_G['timestamp']<$items['starttime']){
	$result = array();
	$result['full'] = 'wks';
	echo json_encode($result);
	exit();
}

if($_G['timestamp']>$items['endtime']){
	$result = array();
	$result['full'] = 'yjs';
	echo json_encode($result);
	exit();
}

if($setting['zhuanpan']['sign']){
	$signcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_signed')." WHERE tid=$tid AND uid=".$_G['uid']);
	if($signcount<1){
		$result = array();
		$result['full'] = 'wqd';
		echo json_encode($result);
		exit();
	}
}

if($setting['zhuanpan']['zuoye']){
	$threadcount = DB::result_first("SELECT count(*) FROM ".DB::table('xj_eventthread')." A LEFT JOIN ".DB::table('forum_thread')." B ON A.tid=B.tid  WHERE A.eid=".$items['eid']." AND B.authorid=".$_G['uid']);
	if($threadcount<1){
		$result = array();
		$result['full'] = 'mzy';
		echo json_encode($result);
		exit();
	}
}




$count = DB::result_first("SELECT count(*) FROM ".DB::table('xj_event_zhuanpan')." WHERE tid=$tid AND uid=".$_G['uid']);
if($count>0){
	$result = array();
	$result['full'] = 'ycj';
	echo json_encode($result);
	exit();
}



$prize_arr = array( 
    '0' => array('id'=>1,'prize'=>$setting['zhuanpan']['prizename'][0],'v'=>$setting['zhuanpan']['probability'][0],'num'=>$setting['zhuanpan']['prizenumber'][0]),
	'1' => array('id'=>2,'prize'=>$setting['zhuanpan']['prizename'][1],'v'=>$setting['zhuanpan']['probability'][1],'num'=>$setting['zhuanpan']['prizenumber'][1]), 
	'2' => array('id'=>3,'prize'=>$setting['zhuanpan']['prizename'][2],'v'=>$setting['zhuanpan']['probability'][2],'num'=>$setting['zhuanpan']['prizenumber'][2]), 
	'3' => array('id'=>4,'prize'=>$setting['zhuanpan']['prizename'][3],'v'=>$setting['zhuanpan']['probability'][3],'num'=>$setting['zhuanpan']['prizenumber'][3]), 
	'4' => array('id'=>5,'prize'=>$setting['zhuanpan']['prizename'][4],'v'=>$setting['zhuanpan']['probability'][4],'num'=>$setting['zhuanpan']['prizenumber'][4]), 
	'5' => array('id'=>6,'prize'=>$setting['zhuanpan']['prizename'][5],'v'=>$setting['zhuanpan']['probability'][5],'num'=>$setting['zhuanpan']['prizenumber'][5]), 
	'6' => array('id'=>7,'prize'=>$setting['zhuanpan']['prizename'][6],'v'=>$setting['zhuanpan']['probability'][6],'num'=>$setting['zhuanpan']['prizenumber'][6]), 
	'7' => array('id'=>8,'prize'=>$setting['zhuanpan']['prizename'][7],'v'=>$setting['zhuanpan']['probability'][7],'num'=>$setting['zhuanpan']['prizenumber'][7]), 
	'8' => array('id'=>9,'prize'=>$setting['zhuanpan']['prizename'][8],'v'=>$setting['zhuanpan']['probability'][8],'num'=>$setting['zhuanpan']['prizenumber'][8]), 
	'9' => array('id'=>10,'prize'=>$setting['zhuanpan']['prizename'][10],'v'=>$setting['zhuanpan']['probability'][9],'num'=>$setting['zhuanpan']['prizenumber'][9]), 
);

foreach ($prize_arr as $key => $val) {
	if($val['num']>0){
    	$arr[$val['id']] = $val['v']; 
	}
} 



if($_GET['formhash'] != $_G['formhash']){
	exit('error');
}

$id = get_rand($arr); //���ݸ��ʻ�ȡ����id 
$setting['zhuanpan']['prizenumber'][$id-1] = $setting['zhuanpan']['prizenumber'][$id-1] - 1;
DB::update('xj_event',array('setting'=>serialize($setting)),"tid=$tid");
$zhuanpan = array();
$zhuanpan['tid'] = $tid;
$zhuanpan['uid'] = $_G['uid'];
$zhuanpan['prizeid'] = $id;
$zhuanpan['dateline'] = $_G['timestamp'];
DB::insert('xj_event_zhuanpan',$zhuanpan);


$result = array();
$result['full'] = $id;
echo json_encode($result);



function get_rand($proArr) { 
    $result = ''; 
 
    //����������ܸ��ʾ��� 
    $proSum = array_sum($proArr); 
 
    //��������ѭ�� 
    foreach ($proArr as $key => $proCur) { 
        $randNum = mt_rand(1, $proSum); 
        if ($randNum <= $proCur) { 
            $result = $key; 
            break; 
        } else { 
            $proSum -= $proCur; 
        } 
    } 
    unset ($proArr); 
 
    return $result; 
} 

?>