<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (strpos($_SERVER["HTTP_USER_AGENT"], 'Appbyme') > 0 || $_SERVER['HTTP_MAG_MGSC']) {
    $Appbyme = true;
}
if (strpos($_SERVER["HTTP_USER_AGENT"], 'MAGAPP') > 0) {
    $magapp = true;
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') > 0) {
    $QianFan = true;
}

$siteid = $_G['wechat']['setting']['wsq_siteid'];
require_once libfile('function/post');

$tmp          = explode("\r\n", $_G['cache']['plugin']['xj_event']['event_offline_class']);
$offlineclass = array();
foreach ($tmp as $key => $value) {
    $eventclass                   = explode("|", $value);
    $offlineclass[$eventclass[0]] = $eventclass[1];
}
$tmp         = explode("\r\n", $_G['cache']['plugin']['xj_event']['event_online_class']);
$onlineclass = array();
foreach ($tmp as $key => $value) {
    $eventclass                  = explode("|", $value);
    $onlineclass[$eventclass[0]] = $eventclass[1];
}

$citykey = $_GET['citykey'];
if (!$_G['cache']['plugin']['xj_event']['event_city']) {
    $tmp       = explode("\r\n", $_G['cache']['plugin']['xj_event']['city']);
    $cityclass = array();
    foreach ($tmp as $key => $value) {
        $ctmp        = array();
        $ctmp[1]     = trim($value);
        $ctmp[2]     = DB::result_first("SELECT COUNT(*) FROM " . DB::table('xj_event') . " WHERE citys='" . $ctmp[1] . "'");
        $ctmp[3]     = urlencode(trim($value));
        $cityclass[] = $ctmp;
    }

    if ($citykey !== '') {
        $city = $cityclass[$citykey][1];
    }
} else {
    $province = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE level = 1 order by id");
    foreach ($province as $key => $value) {
        $province[$key]['city'] = DB::fetch_all("SELECT * FROM " . DB::table('common_district') . " WHERE upid = " . $value['id']);
    }

    if ($citykey !== '') {
        $city = DB::result_first("SELECT name FROM " . DB::table('common_district') . " WHERE id = " . intval($citykey));
    }
}

//�ж��Ƿ��з����Ȩ��
if (!in_array('xj_event', $_G['group']['allowthreadplugin'])) {
    $eventpubadmin = true;
}

if ($_GET['action'] == 'itemslist') {
    $sqlstr   = "";
    $orderstr = "ORDER BY A.eventorder DESC , B.dateline DESC"; //�����ʱ������
    //$orderstr = "ORDER BY A.starttime DESC";  //���ʼʱ������

    if ($_GET['pc']) {
        if ($_GET['pc'] == 1) {
            $sqlstr .= " AND A.postclass=1";
            if ($_GET['classid']) {
                $sqlstr .= " AND A.offlineclass=" . intval($_GET['classid']);
            }
        } elseif ($_GET['pc'] == 2) {
            $sqlstr .= " AND A.postclass=2";
            if ($_GET['classid']) {
                $sqlstr .= " AND A.onlineclass=" . intval($_GET['classid']);
            }
        } elseif ($_GET['pc'] == 3) {
            $joinstr = " left join " . DB::table('xj_eventapply') . " C on A.tid=C.tid ";
            $sqlstr .= " AND C.uid = " . $_G['uid'];
        } elseif ($_GET['pc'] == 4) {
            $sqlstr .= " AND B.authorid=" . $_G['uid'];
        }
    }

    if ($_GET['city']) {
        $city = addslashes($_GET['city']);
        $sqlstr .= " AND A.citys='$city'";
    }
    if ($_GET['keyword']) {
        $keyword = addslashes($_GET['keyword']);
        $sqlstr .= " AND B.subject LIKE '%$keyword%'";
    }

    $perpage     = 15; //ÿҳ��
    $listcount   = DB::result_first("SELECT count(*) FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid $joinstr WHERE 1=1 " . $sqlstr . "");
    $page        = $_GET['page'] ? $_GET['page'] : 1;
    $start_limit = ($page - 1) * $perpage;
    $query       = DB::query("SELECT * FROM " . DB::table('xj_event') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid $joinstr WHERE 1=1 " . $sqlstr . " AND B.displayorder>=0 $orderstr LIMIT $start_limit,$perpage");
    while ($value = DB::fetch($query)) {

        //�鿴��
        $value['views'] = $value['views'] + intval(DB::result_first("SELECT addviews FROM " . DB::table('forum_threadaddviews') . " WHERE tid=" . $value['tid']));

        if ($value['activityaid']) {
            $value['activityaid_url'] = $value['activityaid'] ? getforumimg($value['activityaid'], 0, 513, 240) : 'static/image/common/nophoto.gif';
        } elseif (!$value['activityaid'] && !$value['activityaid_url']) {
            $value['activityaid_url'] = 'static/image/common/nophoto.gif';
        }
        //����
        if ($value['postclass'] == 1) {
            $value['zclass'] = $offlineclass[$value['offlineclass']];
        } else {
            $value['zclass'] = $onlineclass[$value['onlineclass']];
        }
        //�жϱ���
        if ($value['activitybegin'] <= $_G['timestamp'] && $value['activityexpiration'] >= $_G['timestamp']) {
            $value['eventstatetext']  = lang('plugin/xj_event', 'hdbmz');
            $value['eventstatestyle'] = '#00cd30';
        } elseif ($_G['timestamp'] <= $value['starttime']) {
            $value['eventstatetext']  = lang('plugin/xj_event', 'hdwks');
            $value['eventstatestyle'] = '#ffb43f';
        } elseif ($_G['timestamp'] >= $value['starttime'] && $_G['timestamp'] <= $value['endtime']) {
            $value['eventstatetext']  = lang('plugin/xj_event', 'hdjxz');
            $value['eventstatestyle'] = '#e44268';
        } elseif ($_G['timestamp'] >= $value['endtime']) {
            $value['eventstatetext']  = lang('plugin/xj_event', 'hdyjs');
            $value['eventstatestyle'] = '#bbbbbb';
        }
        //�ʱ��
        $value['starttimetext'] = date('Y/m/d', $value['starttime']);
        $value['endtimetext']   = date('Y/m/d', $value['endtime']);

        if ($magapp) {
            $openwindowhtml = 'urlRequest(\'' . $_G['siteurl'] . 'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid=' . $value['tid'] . '\');';
        } else {
            $openwindowhtml = 'window.open(\'plugin.php?id=xj_event:wsqcenter&mod=event_view&tid=' . $value['tid'] . '\');';
        }

        echo '<div onclick="' . $openwindowhtml . '" style=" margin-bottom:10px;background-color:#ffffff;border-radius:2px; padding:5px 12px;">
        	<div style="line-height:28px; font-size:15px;overflow: hidden; white-space: nowrap; text-overflow: ellipsis;">
            	<span style=" color:#ff4153;">[' . $value['zclass'] . ']</span>
                <span style="color:#616161;">' . $value['subject'] . '</span>
            </div>
            <div style="margin-top:5px;">
            	<img src="' . $value['activityaid_url'] . '" style="width:100%; height:155px;">
            </div>
            <div style="margin-top:1px;">
            	<div style="margin-top:4px;float:right; width:85px; background-color:#fe655d; text-align:center; color:#FFF; line-height:37px;border-radius:5px;">
                	' . lang('plugin/xj_event', 'huodongxianqin') . '
                </div>
                <div style=" margin-right:100px;">
                	<div style="font-size:15px; color:#696969; height:25px;">' . lang('plugin/xj_event', 'yiyou') . '<span style="color:#fe655d;">' . $value['views'] . '</span>' . lang('plugin/xj_event', 'renganxinqu') . '</div>
                    <div>
                    	<span style="background-color:' . $value['eventstatestyle'] . '; color:#ffffff; padding:2px 7px; font-size:11px; border-top-right-radius:12px; border-bottom-right-radius:12px; margin-left:-12px;">' . $value['eventstatetext'] . '</span>
                        <span style="font-size:12px;color:#979797;">' . $value['starttimetext'] . ' ' . weekday($value['starttime']) . ' ' . date('H:i', $value['starttime']) . '</span>
                    </div>
                </div>
            </div>
            <div style="clear:both; height:10px;"></div>
        </div>';
    }
    if ($page < @ceil($listcount / $perpage)) {
        $page    = $page + 1;
        $classid = intval($_GET['classid']);
        $pc      = intval($_GET['pc']);
        echo '<div onClick="moreitems(\'' . $type . '\',' . $page . ',' . $pc . ',' . $classid . ',\'' . $keyword . '\');" id="morebtn" style=" text-align:center;font-size:16px;line-height:40px;color:#9c9c9c;padding-bottom:10px;">' . lang('plugin/xj_event', 'djckgd') . '>>></div>';
    }
    exit();
}

loadcache('xj_event_mobileicon');

function weekday($time)
{
    if (is_numeric($time)) {
        $weekday = array(lang('plugin/xj_event', 'zhouri'), lang('plugin/xj_event', 'zhouyi'), lang('plugin/xj_event', 'zhouer'), lang('plugin/xj_event', 'zhousan'), lang('plugin/xj_event', 'zhousi'), lang('plugin/xj_event', 'zhouwu'), lang('plugin/xj_event', 'zhouliu'));
        return $weekday[date('w', $time)];
    }
    return false;
}
