<?php

$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.verify=1 AND A.activityaid>0  ORDER BY A.starttime DESC LIMIT 0,3");
$focuslist = array();
while($value = DB::fetch($query)){
	$value['activityaid_url'] = getforumimg($value['activityaid'],0,400,250);
	

	//$value[activityaid_url] = getpicurl($value['activityaid'],$value['tid']);
	$focuslist[] = $value;
}

$query = DB::query("SELECT * FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid=B.tid AND A.endtime>".$_G['timestamp']." AND B.displayorder >= 0 ORDER BY A.starttime DESC LIMIT 0,10");
$newlist = array();
while($value = DB::fetch($query)){
	if($value['activityaid']){
		$value['activityaid_url'] = getforumimg($value['activityaid'],0,80,80);
	}else{
		$value['activityaid_url'] = 'source/plugin/xj_event/module/mobilecenter/images/nopic.jpg';
	}
	$value['setting'] = unserialize($value['setting']);
	$value['subject'] = cutstr($value['subject'],20);
	$value['applynumber'] = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid=".$value['tid']." and verify=1");
	$value['applynumber'] = $value['applynumber']?$value['applynumber']:0;
	$value['starttimestr'] = dgmdate($value['starttime'],'d');
	
	
	$newlist[] = $value;	
}

$tmp = explode("\r\n",$_G['cache']['plugin']['xj_event']['city']);
$cityclass = array();
foreach($tmp as $key=>$value){
	$ctmp = array();
	$ctmp[1] = trim($value);
	$ctmp[2] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('xj_event')." WHERE citys='".$ctmp[1]."'");
	$ctmp[3] = urlencode(trim($value));
	$cityclass[] = $ctmp;
}

$query = DB::query("SELECT A.tid,B.subject,B.dateline FROM ".DB::table('xj_eventthread')." A,".DB::table('forum_post')." B WHERE A.tid = B.tid AND B.first=1 AND A.sort=1 ORDER BY B.dateline DESC LIMIT 0,5");
$hglist = array();
while($value = DB::fetch($query)){
	$value['dateline'] = dgmdate($value['dateline'],'d');
	$hglist[] = $value;	
}

//From: Dism_taobao_com
?>