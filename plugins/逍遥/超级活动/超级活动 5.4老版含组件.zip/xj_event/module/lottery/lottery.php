<?php

$tid = $_GET['tid'];

if(!file_exists($lotteryuser_cache = DISCUZ_ROOT.'./data/sysdata/cache_lottery_'.$tid.'.php')) {
	$lotteryusers = array();
	$query = DB::query("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid = B.uid AND A.tid=$tid");	
	while($value = DB::fetch($query)){
		if($_G[charset]=='gbk'){
			$value['username'] = iconv("GBK", "UTF-8", $value['username']);
		}
		$lotteryusers[] = $value;
	}
	require_once libfile('function/cache');
	writetocache('lottery_'.$tid,getcachevars(array('lotteryusers'=>$lotteryusers)));
}




if($_GET['action'] == 'data'){
	if(file_exists($lotteryuser_cache = DISCUZ_ROOT.'./data/sysdata/cache_lottery_'.$tid.'.php')) {
		@include $lotteryuser_cache;
	}
	echo json_encode($lotteryusers); 
	exit;
}
if($_GET['action'] == 'ok'){
	$mid = intval($_GET['mid']);
	if(file_exists($lotteryuser_cache = DISCUZ_ROOT.'./data/sysdata/cache_lottery_'.$tid.'.php')) {
		@include $lotteryuser_cache;
	}
	if(!$lotterywinners){
		$lotterywinners =array();
	}
	
	$lotterywinners[] = $lotteryusers[$mid];
	array_splice($lotteryusers,$mid,1);
	require_once libfile('function/cache');
	writetocache('lottery_'.$tid,getcachevars(array('lotteryusers'=>$lotteryusers,'lotterywinners'=>$lotterywinners)));
	
	exit('1');	
}

if(file_exists($lotteryuser_cache = DISCUZ_ROOT.'./data/sysdata/cache_lottery_'.$tid.'.php')) {
	@include $lotteryuser_cache;
}

foreach($lotterywinners as $key=>$value){
	if($_G['charset']=='gbk'){
		$lotterywinners[$key]['username'] = iconv("UTF-8", "GBK", $value['username']);
	}
}

include template('event_lottery',0,'source/plugin/xj_event/module/lottery/template');

?>