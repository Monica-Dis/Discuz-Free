<?php

$tid = intval($_GET['tid']);
//Ȩ������
$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid='$tid' and A.tid = B.tid");
$setting = unserialize($thread['setting']);
//�ж��ǲ��ǹ����Ŷ�
$event_admin = false;
if(in_array($_G['username'],$setting['event_admin'])){
	$event_admin = true;
}
if($_G['groupid']>1 && $_G['uid']!=$thread['authorid'] && !$event_admin){
	showmessage('quickclear_noperm');
}




if($_GET['act']=='clear'){
	$lotteryusers = array();
	$query = DB::query("SELECT A.uid,B.username FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid = B.uid AND A.tid=$tid");	
	while($value = DB::fetch($query)){
		$value['username'] = iconv("GBK", "UTF-8", $value['username']);
		$lotteryusers[] = $value;
	}
	require_once libfile('function/cache');
	writetocache('lottery_'.$tid,getcachevars(array('lotteryusers'=>$lotteryusers)));
	showmessage('�齱����������ɣ��������¿�ʼ�齱�ˣ�');
}

if($_GET['act']=='zjmd'){
	if(file_exists($lotteryuser_cache = DISCUZ_ROOT.'./data/sysdata/cache_lottery_'.$tid.'.php')) {
		@include $lotteryuser_cache;
	}
	$winneruid = array();
	foreach($lotterywinners as $value){
		$winneruid[] = $value['uid'];
	}
	$winneruid = implode(',',$winneruid);

	$thread = DB::fetch_first("SELECT authorid,userfield,setting,subject,starttime FROM ".DB::table('forum_thread')." A,".DB::table('xj_event')." B WHERE A.tid='$tid' and A.tid = B.tid");
	$setting = unserialize($thread['setting']);
	
	$selectuserfield = unserialize($thread['userfield']);
	$sysuserfield = unserialize($_G['setting']['activityfield']);

	require_once libfile('function/profile');
	loadcache('profilesetting');
	
	
	$query = DB::query("SELECT * FROM ".DB::table('xj_eventapply')." A,".DB::table('common_member')." B WHERE A.uid = B.uid and A.tid = '$tid' AND A.uid in ($winneruid) ORDER BY A.verify,A.dateline DESC");
	while($value = DB::fetch($query)){
		$value['ufielddata'] = unserialize($value['ufielddata']);
		$ufielddata = array();
		foreach($value['ufielddata'] as $key => $fieldid) {
			$data = profile_show($key, $value['ufielddata']);
			if($_G['cache']['profilesetting'][$key]['formtype'] == 'file') {
				$data = '<a href="'.$data.'" target="_blank" onclick="zoom(this, this.href, 0, 0, 0); return false;">'.lang('forum/misc', 'activity_viewimg').'</a>';
			}
			if($key=='birthday'){
				$ufielddata[$key]['value'] = $fieldid;
			}else{
				$ufielddata[$key]['value'] = $data;
			}
			if($key=='qq'){
				$ufielddata[$key]['value'] = '<a href="http://wpa.qq.com/msgrd?v=3&uin='.$fieldid.'&Site='.$_G['setting']['bbname'].'&Menu=yes&from=discuz" target="_blank" title="'.lang('spacecp', 'qq_dialog').'"><img src="'.STATICURL.'/image/common/qq.gif" alt="QQ" style="margin:0px;"/></a>'.$fieldid;
			}
		}
		$value['ufielddata'] = $ufielddata;
		$joinlist[] = $value;
	}
}



include template('lottery_setting',0,'source/plugin/xj_event/module/lottery/template');

?>