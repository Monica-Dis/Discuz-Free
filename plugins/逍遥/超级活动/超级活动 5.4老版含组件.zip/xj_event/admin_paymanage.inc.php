<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();



//������ʱδ֧���Ķ���
if($_GET['act'] == 'clearorder'){
    if(!$_GET['confirmed']){
        cpmsg(lang('plugin/xj_event','shifuoquedingqinchu'),'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_paymanage&act=clearorder', 'form');
        exit;
    }else {
        $cleartime = $_G['timestamp'] - 86400;
        $clearcount = DB::delete("xj_eventpay_log","create_time<$cleartime AND paystate<=1");
        cpmsg(lang('plugin/xj_event','qinchuwangchen').$clearcount,'action=plugins&operation=config&do='.$pluginid.'&identifier=xj_event&pmod=admin_paymanage', 'succeed');
        exit;
    }
}





if ($_GET['act'] == 'search') {
    $keyword = addslashes($_GET['keyword']);
    $sqlstr  = " AND (B.subject like '%" . str_replace(array('%', '*', '_'), array('\%', '%', '\_'), $keyword) . "%' OR C.username like '%" . str_replace(array('%', '*', '_'), array('\%', '%', '\_'), $keyword) . "%')";
    $extra   = "&keyword=" . $_GET['keyword'] . "&act=search";
}

if($_GET['paystate'] == 'pay'){
	$sqlstr .= " AND A.paystate=3 ";
}


showsubmenu(lang('plugin/xj_event', 'huodongbaomingzhifuguanli'));
echo '<div><form name="form1" method="post" action="' . ADMINSCRIPT . '?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_paymanage&paystate='.$_GET['paystate'].'&act=search">' . lang('plugin/xj_event', 'guanjianzi') . '<input type="text" name="keyword" value=""> <input type="submit" name="button" id="button" value="' . lang('plugin/xj_event', 'chazhao') . '" /></form> </div> <div style="padding-top:10px;">
	<a href="'. ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_paymanage" style="padding:3px 10px; background-color:'.($_GET['paystate'] == 'pay'?'#BBBBBB':'#0099cc').';color:#fff;">'.lang('plugin/xj_event','suoyoudingdang').'</a>
	<a href="'. ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_paymanage&paystate=pay" style="padding:3px 10px; background-color:'.($_GET['paystate'] == 'pay'?'#0099cc':'#BBBBBB').';color:#fff;">'.lang('plugin/xj_event','yizhifudingdang').'</a>
	<a href="'. ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_paymanage&act=clearorder" style="padding:3px 10px; background-color:#4BB442;color:#fff;">'.lang('plugin/xj_event','qinlichaoshiweizhifudindan').'</a>
	</div>';
showtableheader();
showtablerow('', array(), array('applyid', lang('plugin/xj_event', 'huodongmingcheng'), lang('plugin/xj_event', 'yonghuming'), lang('plugin/xj_event', 'baomingrs'), lang('plugin/xj_event', 'zhifujine'), lang('plugin/xj_event', 'baomingsj'), lang('plugin/xj_event', 'zhifuleixing'), lang('plugin/xj_event', 'dindanhao'), lang('plugin/xj_event', 'zhifushijian'), ''), '');
$ppp   = 15; 
$page  = $_GET['page'] ? intval($_GET['page']) : 1;
$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('xj_eventpay_log') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid LEFT JOIN " . DB::table('common_member') . " C on A.uid=C.uid LEFT JOIN ".DB::table('xj_eventapply')." D ON A.applyid = D.applyid WHERE D.applyid<>''  $sqlstr");
$query = DB::query("SELECT A.*,B.subject,C.username,D.applynumber,D.dateline FROM " . DB::table('xj_eventpay_log') . " A LEFT JOIN " . DB::table('forum_thread') . " B ON A.tid=B.tid LEFT JOIN " . DB::table('common_member') . " C on A.uid=C.uid LEFT JOIN ".DB::table('xj_eventapply')." D ON A.applyid = D.applyid WHERE D.applyid<>'' $sqlstr ORDER BY A.create_time DESC LIMIT " . (($page - 1) * $ppp) . ",$ppp");
while ($value = DB::fetch($query)) {
    //$value['applynumber'] = DB::result_first("SELECT applynumber FROM " . DB::table('xj_eventapply') . " WHERE applyid=" . $value['applyid'] . " AND first = 1");
    $value['orderno'] = '';
    if ($value['paytype'] == 'alipay') {
    	$value['orderno'] = $value['orderid'];
        $value['paytype'] = lang('plugin/xj_event', 'zhifubao');
    } elseif ($value['paytype'] == 'wxpay') {
    	$value['orderno'] = $value['tradeno'];
        $value['paytype'] = lang('plugin/xj_event', 'weixzf');
    } elseif ($value['paytype'] == 'tenpay') {
    	$value['orderno'] = $value['orderid'];
        $value['paytype'] = lang('plugin/xj_event', 'caifutong');
    } elseif ($value['paytype'] == 'appwxpay') {
    	$value['orderno'] = $value['tradeno'];
        $value['paytype'] = 'APP' . lang('plugin/xj_event', 'weixzf');
    } elseif ($value['paytype'] == 'xcxwxpay'){
    	$value['orderno'] = $value['tradeno'];
        $value['paytype'] = lang('plugin/xj_event','xiaochengxu') . lang('plugin/xj_event', 'weixzf');
    }
    $value['bmtime'] = dgmdate($value['dateline']);
    $value['zftime'] = $value['notify_time']?dgmdate($value['notify_time']):lang('plugin/xj_event','weizhifu');
    showtablerow('', array('class="td25"', 'class="td28"'), array($value['applyid'], $value['subject'], $value['username'], $value['applynumber'], $value['total_fee'], $value['bmtime'], $value['paytype'], $value['orderno'], $value['zftime']));
}
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
echo multi($count, $ppp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xj_event&pmod=admin_paymanage$extra");