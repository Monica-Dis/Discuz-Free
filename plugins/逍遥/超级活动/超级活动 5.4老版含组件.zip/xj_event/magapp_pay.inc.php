<?php
/**
 *	[�����(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2012-9-15 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//���ú�����
include 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();




$applyid = intval($_GET['applyid']);
$apply = DB::fetch_first("SELECT tid,applyid,applynumber FROM ".DB::table('xj_eventapply')." WHERE applyid = $applyid and uid=".$_G['uid']);
$tid = $apply['tid'];
$items = DB::fetch_first("SELECT A.*,B.subject FROM ".DB::table('xj_event')." A,".DB::table('forum_thread')." B WHERE A.tid = $tid and A.tid=B.tid");
$setting = unserialize($items['setting']);
$pay_subject = $items['subject'];
$pay_price = $items['use_cost'];
$pay_number = DB::result_first("SELECT sum(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
//�жϱ��������Ƿ񹻣������Ͳ���֧��
if($items['event_number']>0){
	$applycountnumber = DB::result_first("SELECT SUM(applynumber) FROM ".DB::table('xj_eventapply')." WHERE tid='$tid' and verify=1");
	if($pay_number > ($items['event_number']-$applycountnumber)){
		showmessage(lang('plugin/xj_event','baomrsym'));
		exit();
	}
}
$pay_totalprice = $pay_price * $pay_number;
if($_G['charset']=='gbk'){
	$pay_subject = cutstr($pay_subject,20,'');
	$pay_subject = iconv('GBK','UTF-8',$pay_subject);
}
//����Ƕ��ֱ���
if($setting['cost']){
	if($setting['nodaibaoming']){
		$capply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$capply['ufielddata'] = unserialize($capply['ufielddata']);
		$price = 0;
		$paytext = '';
		foreach($setting['cost'] as $value){
			$paytext = $paytext.$value['cost_name'].' '.$capply['ufielddata']['cost'.$value['id']].' x &yen;'.$value['cost_price'].'<br>';
			$price = $price+$capply['ufielddata']['cost'.$value['id']]*$value['cost_price'];
		}
	}else{
		$capply = DB::fetch_all("SELECT * FROM ".DB::table('xj_eventapply')." WHERE tid = '$tid' and uid=".$_G['uid']);
		$price = 0;
		$paytext = '';
		foreach($capply as $value){
			$value['ufielddata'] = unserialize($value['ufielddata']);
			$paytext = $paytext.$setting['cost'][$value['ufielddata']['costclass']]['cost_name'].' 1 x &yen;'.$setting['cost'][$value['ufielddata']['costclass']]['cost_price'].'<br>';
			$price = $price + $setting['cost'][$value['ufielddata']['costclass']]['cost_price'];
		}
	}
	$pay_totalprice = $price;
}
//VIP�ۿ�
if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/vip/wxpay.php')) {
	@include 'module/vip/wxpay.php';
}

if($setting['app_benefit']>0){
	$pay_totalprice = $pay_totalprice - $setting['app_benefit'];
}



if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
	@include $xj_event_wxset;
}
$magappsecret = $wxset['magapp_secret'];
$tradeno = getRandChar(20);
$callback = $_G['siteurl'].'source/plugin/xj_event/event_pay_magapp_notify.php?tradeNo='.$tradeno;  //�ص���ַ
$res = get('http'.($_G['isHTTPS']?'s':'').'://'.$wxset['magapp_siteurl'].'/core/pay/pay/unifiedOrder?trade_no='.$tradeno.'&amount='.$pay_totalprice.'&title='.$pay_subject.'&user_id='.$_G['uid'].'&des='.$pay_subject.'&remark='.$pay_subject.'&secret='.$magappsecret.'&callback='.urlencode($callback));

$res = json_decode($res,true);

if(!$res['success']){
	echo 'http'.($_G['isHTTPS']?'s':'').'://'.$wxset['magapp_siteurl'].'/core/pay/pay/unifiedOrder?trade_no='.$tradeno.'&amount='.$pay_totalprice.'&title='.$pay_subject.'&user_id='.$_G['uid'].'&des='.$pay_subject.'&remark=&secret='.$magappsecret.'&callback='.urlencode($callback);
	echo $_G['charset'] == 'gbk'?iconv('utf-8','gbk',$res['msg']):$res['msg'];
	exit;
}



//���ݿ�����֧����¼
$paylog = array();
$paylog['applyid'] = $apply['applyid'];
$paylog['uid'] = $_G['uid'];
$paylog['tid'] = $tid;
$paylog['tradeno'] = $tradeno;
$paylog['paytype'] = 'magapppay';
$paylog['subject'] = $items['subject'];
$paylog['price'] = $pay_price;
$paylog['buyer_email'] = '';
$paylog['total_fee'] = $pay_totalprice;
$paylog['create_time'] = $_G['timestamp'];
$paylog['paystate'] = 1;
DB::insert("xj_eventpay_log",$paylog);





$result['full'] = 1;
$result['unionOrderNum'] = $res['data']['unionOrderNum'];
$result['price'] = $pay_totalprice;
$result['tradeno'] = $tradeno;
$result['pay_subject'] = $pay_subject;
echo json_encode($result);
exit;




function get($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	# curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }
  return $str;
}
//From: Dism��taobao��com
?>