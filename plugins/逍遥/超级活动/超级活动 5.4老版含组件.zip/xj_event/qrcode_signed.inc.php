<?php
if(file_exists(DISCUZ_ROOT.'./source/plugin/xj_event/module/signed/qrcode_signed.php')) {
	@include 'module/signed/qrcode_signed.php';
}
//From: dis'.'m.tao'.'bao.com
?>