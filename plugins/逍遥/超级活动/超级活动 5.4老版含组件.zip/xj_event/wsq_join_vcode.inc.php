<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$uid = intval($_G['uid']);
$siteid = $_G['wechat']['setting']['wsq_siteid'];
$applyid = intval($_GET['applyid']);
$apply = DB::fetch_first("SELECT * FROM ".DB::table('xj_eventapply')." WHERE applyid=$applyid");
$items = DB::fetch_first("SELECT * FROM ".DB::table('xj_event')." WHERE eid=".$apply['eid']);
$thread =  DB::fetch(DB::query("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid = ".$apply['tid']));
$setting = unserialize($items['setting']);

?>
<script type="text/javascript" src="http://wsq.discuz.com/cdn/discuz/js/openjs.js"></script>
<script>
	var menu = new Array();
	WSQ.initBtmBar(menu);
	WSQ.showBtmBar();
	WSQ.initPlugin({name:'<?php echo lang('plugin/xj_event', 'hdrcj'); ?>'});
</script>
    
    
<style type="text/css">
    #container {margin:5px;}
    body {height:100%;}
	.input1{padding:14px; line-height:14px; width:100%;-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px; border:1px solid #d8d8d8;}
    select{height:42px;-webkit-appearance:none;appearance:none;border:none;font-size:14px;padding:0px 10px;display:block;width:100%;-webkit-box-sizing:border-box;box-sizing:border-box;background-color: #FFFFFF;color:#aaa;border-radius:4px;}
	.selectdiv{margin-top:0px;outline:none;-moz-border-radius: 4px; -webkit-border-radius: 4px; border-radius:4px; border:1px solid #d8d8d8;position:relative;}
	.checkbox {
 width: 19px;
 height: 25px;
 padding: 0 5px 0 0;
 background: url(checkbox.png) no-repeat;
 display: block;
 float: left;
}
	label{float:left; font-size:14px; line-height:30px;}
</style>
<script type="text/javascript" src="source/plugin/xj_event/js/jquery.js"></script>
<script type="text/javascript">
$(function(){ 
     $("#testbtn").click(function(){
		  $.ajax({ 
			  type: 'POST', 
			  url: 'plugin.php?id=xj_event:wsq_join&tid=<?php echo $tid; ?>&action=full', 
			  //data: {level:'fff', roomnumber:'bbb'},
			  data:$('#bmform').serialize(),
			  dataType: 'json', 
			  cache: false, 
			  error: function(){ 
				  alert('error'); 
				  return false; 
			  }, 
			  success:function(json){ 
			  	  if(json.full == 2){
					  alert(json.showmessage);
					  if(json.tourl != null){
					  	top.location.href=json.tourl;
					  }
					  return false;		  
				  }
				  if(json.full == 1){
					  alert('<?php echo lang('plugin/xj_event','gxnbmcg'); ?>');
					  window.location.href="http://wsq.discuz.com/?c=index&a=viewthread&f=wx&tid=<?php echo $tid; ?>&siteid=<?php echo $siteid; ?>&_bpage=1";
					  return true;
				  }else{
					  alert('error'); 
					  return false; 
				  }
			  } 
		  });
    }); 
}); 
</script>
</head>
<body>
<div style="margin:20px 10px;">
	<div style=" border:1px solid #ccc; background-color:#fff; padding:15px;">
    	<div style="font-weight:bold; line-height:28px;">
        	<?php echo $thread['subject']; ?>
        </div>
        <div style="font-size:12px; line-height:24px; padding:10px 0px;">
        	<div style="float:left; width:40%;"><?php echo lang('plugin/xj_event', 'chanci'); ?>:<?php echo $setting['session'][$apply['session']]; ?></div>
            <div style="float:right; width:40%; text-align:right;"><?php echo lang('plugin/xj_event', 'renshu'); ?>:<?php echo $apply['applynumber']; ?></div>
        </div>
        <div style="clear:both; height:10px;"></div>
        <div style="padding:20px; border-top:1px solid #aaa; text-align:center;">
        	<img src="plugin.php?id=xj_event:qrcode_vcode&tid=<?php echo $apply['tid']; ?>&seccode=<?php echo $apply['seccode']; ?>" style="width:100%;">
        	<span style="font-size:20px;font-family: Microsoft YaHei;"><?php echo lang('plugin/xj_event', 'yanzhenma'); ?>:<?php echo $apply['seccode']; ?></span>
        </div>
        <div style="font-size:12px; color:#999; line-height:18px;">
        	<?php echo lang('plugin/xj_event', 'smyzmhewmy'); ?>
        </div>
    </div>
    
</div>  
</body>
</html>
