<?php
/**
 *    [超级活动(xj_event.{modulename})] (C)2012-2099 by dism.taobao.com
 *    Version: 1.0
 *    Date: 2012-9-15 10:27
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



//引用核心类
include_once 'source/plugin/xj_event/include/core.class.php';
$eventcore = new xj_eventcore();
//调用虎皮椒类
include_once 'source/plugin/xj_event/include/hupay.class.php';


//各APP的登录
include_once 'source/plugin/xj_event/include/app_login.php';
$orderid = addslashes($_GET['orderid']);
$paylog = C::t("#xj_event#xj_eventpay_log")->fetch_first_orderid($orderid);
$applyid = $paylog['applyid'];
$apply = C::t("#xj_event#xj_eventapply")->fetch_first_applyid($applyid);

include_once 'source/plugin/xj_event/include/view.class.php';
$eventview = new xj_eventview();
$event = $eventview->event_view($apply['eid'],0);

//计算金额
$totalprice = $apply['total_price'];
//计算积分
$totalcredits = $event['setting']['cost'][$apply['ticket']]['cost_credits']*$apply['applynumber'];
if($_G['charset']=='gbk'){
    $pay_subject = cutstr($event['subject'],20,'');
    $pay_subject = iconv('GBK','UTF-8',$pay_subject);
}else{
    $pay_subject = cutstr($event['subject'],20,'');
}


if(file_exists($xj_event_wxset = DISCUZ_ROOT.'./data/sysdata/cache_xj_event_wxset.php')) {
    @include $xj_event_wxset;
}

if($_GET['type'] == 'wechat'){
    $appid = $wxset['hupay_wxpay_appid']; //微信
    $appsecret =$wxset['hupay_wxpay_appsecret'];
}else{
    $appid = $wxset['hupay_alipay_appid']; //支付宝
    $appsecret =$wxset['hupay_alipay_appsecret'];
}


$type = $_GET['type'];
$my_plugin_id ='xj_event';
$data=array(
    'version'   => '1.1',//固定值，api 版本，目前暂时是1.1
    'lang'       => 'zh-cn', //必须的，zh-cn或en-us 或其他，根据语言显示页面
    'plugins'   => $my_plugin_id,//必须的，根据自己需要自定义插件ID，唯一的，匹配[a-zA-Z\d\-_]+
    'appid'     => $appid, //必须的，APPID
    'trade_order_id'=> $orderid, //必须的，网站订单ID，唯一的，匹配[a-zA-Z\d\-_]+
    'payment'   => $type,//必须的，支付接口标识：wechat(微信接口)|alipay(支付宝接口)
    'total_fee' => $totalprice,//人民币，单位精确到分(测试账户只支持0.1元内付款)
    'title'     => $pay_subject, //必须的，订单标题，长度32或以内
    'time'      => $_G['timestamp'],//必须的，当前时间戳，根据此字段判断订单请求是否已超时，防止第三方攻击服务器
    'notify_url'=>  $_G['siteurl']."source/plugin/xj_event/paynotify.php", //必须的，支付成功异步回调接口
    'return_url'=> $_G['siteurl']."plugin.php?id=xj_event",//必须的，支付成功后的跳转地址
    'callback_url'=>$_G['siteurl']."plugin.php?id=xj_event",//必须的，支付发起地址（未支付或支付失败，系统会会跳到这个地址让用户修改支付信息）
    'modal'=>null, //可空，支付模式 ，可选值( full:返回完整的支付网页; qrcode:返回二维码; 空值:返回支付跳转链接)
    'nonce_str' => str_shuffle($_G['timestamp'])//必须的，随机字符串，作用：1.避免服务器缓存，2.防止安全密钥被猜测出来
);


$hashkey =$appsecret;
$data['hash']     = XH_Payment_Api::generate_xh_hash($data,$hashkey);
/**
 * 个人支付宝/微信官方支付，支付网关：https://api.xunhupay.com
 * 微信支付宝代收款，需提现，支付网关：https://pay.wordpressopen.com
 */
$url              = 'https://api.xunhupay.com/payment/do.html';

try {
    $response     = XH_Payment_Api::http_post($url, json_encode($data));
    /**
     * 支付回调数据
     * @var array(
     *      order_id,//支付系统订单ID
     *      url//支付跳转地址
     *  )
     */
    $result       = $response?json_decode($response,true):null;
    if(!$result){
        throw new Exception('Internal server error',500);
    }

    $hash         = XH_Payment_Api::generate_xh_hash($result,$hashkey);
    if(!isset( $result['hash'])|| $hash!=$result['hash']){
        throw new Exception(__('Invalid sign!',XH_Wechat_Payment),40029);
    }

    if($result['errcode']!=0){
        throw new Exception($result['errmsg'],$result['errcode']);
    }


    $pay_url =$result['url'];
    header("Location: $pay_url");
    exit;
} catch (Exception $e) {
    echo "errcode:{$e->getCode()},errmsg:{$e->getMessage()}";
    //TODO:处理支付调用异常的情况
}
exit;

