<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * ��ַ�� http://dism.taobao.com
 * DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('location:http://dism.taobao.com/?@56030.developer');