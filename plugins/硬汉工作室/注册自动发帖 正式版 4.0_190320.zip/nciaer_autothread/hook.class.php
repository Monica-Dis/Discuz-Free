<?php
/**
 *   ע���Զ�����
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_autothread {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_autothread'];
    }

    public function _newthread() {

        global $_G;

        $subject_arr = explode(PHP_EOL, trim($this->config['subject']));
        $subject = str_replace('{username}', $_G['username'], $subject_arr[array_rand($subject_arr)]);
        $message_arr = explode(PHP_EOL, trim($this->config['message']));
        $message = str_replace(array('{username}', '{uid}', '{regtime}'), array($_G['username'], $_G['uid'], TIMESTAMP), $message_arr[array_rand($message_arr)]);
        $params = array(
            'subject' => $subject,
            'message' => $message,
            'typeid' => intval($this->config['typeid']),
            'sortid' => 0,
            'special' => 0,
            'publishdate' => TIMESTAMP,
        );

        $modthread = C::m('forum_thread', $this->config['fid']);
        $modthread->newthread($params);
    }
}

class plugin_nciaer_autothread_member extends plugin_nciaer_autothread {

    public function register_nciaer_message($params) {

        $param = $params["param"];
        if ($param[0] == "register_succeed") {
			$this->_newthread();
        }
    }
}

class mobileplugin_nciaer_autothread_member extends plugin_nciaer_autothread_member {}