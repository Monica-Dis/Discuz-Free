<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * ��ַ�� http://dism.taobao.com
 * DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
showtips(lang('plugin/' . $plugin['identifier'], '_contact_text'), 'tips', TRUE, lang('plugin/' . $plugin['identifier'], '_contact'));
showtips(lang('plugin/' . $plugin['identifier'], '_business_text'), 'tips2', TRUE, lang('plugin/' . $plugin['identifier'], '_business'));
$functioninfo = lang('plugin/' . $plugin['identifier'], 'functioninfo');
$logtip = '';
$logs = explode(PHP_EOL, $functioninfo);
foreach($logs as $v) {
    $logtip .= "<li>{$v}</li>";
}
showtips($logtip, 'tips3', TRUE, $plugin['name'].' '.lang('plugin/' . $plugin['identifier'], 'updatelog'));
