<?php
/**
 *	 ���Ѱ�鹺����Ч��
 *
 *   DisM!Ӧ���������� https://dism.Taobao.Com 
 *   ��ַ��dism.taobao.com
 *   DisM!�û�����Ⱥ: ��Ⱥ778390776
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_priceforumvalidity {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_priceforumvalidity'];
	}
	
	public function viewthread() {
		
        $this->validity();
	}

	public function forumdisplay() {

        $this->validity();
    }
	
    public function validity() {

        global $_G;

        if(!$this->config['on']) return;

        if(!in_array($_G['fid'], dunserialize($this->config['fids']))) return;
        if(!in_array($_G['groupid'], dunserialize($this->config['gids']))) return;

        if($_G['forum']['price'] && !$_G['forum']['ismoderator']) {
            $sql = "select * from %t where uid=%d and relatedid=%d and operation = 'FCP' order by dateline desc limit 1";
            $paylog = DB::fetch_first($sql, array('common_credit_log', $_G['uid'], $_G['fid']));
            if(!empty($paylog)) {
                $rulefile = 'source/plugin/nciaer_priceforumvalidity/rule.php';
                if(file_exists($rulefile)) {
                    include_once $rulefile;
                }
                $validity = !empty($rules[$_G['fid']]) ? $rules[$_G['fid']] : $this->config['validity'];
                if(TIMESTAMP - $paylog['dateline'] > $validity * 86400) {
                    DB::delete('common_member_forum_buylog', array('uid' => $_G['uid'], 'fid' => $_G['fid']));
                }
            }
        }

    }
}

class plugin_nciaer_priceforumvalidity_forum extends plugin_nciaer_priceforumvalidity {}

class mobileplugin_nciaer_priceforumvalidity_forum extends plugin_nciaer_priceforumvalidity {}