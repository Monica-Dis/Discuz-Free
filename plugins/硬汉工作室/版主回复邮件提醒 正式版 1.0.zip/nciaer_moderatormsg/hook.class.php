<?php
/**
*   DisM!Ӧ�����ģ�dism.taobao.com
*   �ͷ�QQ��DISM.TAOBAO.COM
*   ������http://dism.taobao.com
*   �汾��1.0
*   ����޸����ڣ�17.03.28
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_moderatormsg {}

class plugin_nciaer_moderatormsg_forum extends plugin_nciaer_moderatormsg {
	
	public function post_message($params) {
		
		global $_G;
		$pconfig = $_G['cache']['plugin']['nciaer_moderatormsg'];
		if($params['param'][0] == 'post_reply_succeed') {
			if($_G['uid'] == $_G['thread']['authorid']) return; // simple person
			$fid = $params['param'][2]['fid'];
			if(!in_array($fid, unserialize($pconfig['fids']))) return;
			$moderators = explode("\t", $_G['forum']['moderators']);
			if(in_array($_G['username'], $moderators)) {
				// is moderator
				$post_url = $_G['siteurl'] . $params['param'][1];
				$subject = $_G['thread']['subject'];
				$author = getuserbyuid($_G['thread']['authorid']);
				$msg = $pconfig['mail_text'];
				$msg = str_replace(array('{author}', '{subject}', '{url}'), array($author['username'], $subject, $post_url), $msg);
				if($author['email']) {
					include_once libfile("function/mail");
					sendmail($author['email'], $pconfig['mail_title'], $msg);					
				}
			}
		}
	}
}

class mobileplugin_nciaer_moderatormsg {}

class mobileplugin_nciaer_moderatormsg_forum extends mobileplugin_nciaer_moderatormsg {
	
	public function post_message($params) {
		
		global $_G;
		$pconfig = $_G['cache']['plugin']['nciaer_moderatormsg'];
		if(!$pconfig['mobile_true']) return;
		if($params['param'][0] == 'post_reply_succeed') {
			if($_G['uid'] == $_G['thread']['authorid']) return; // simple person
			$fid = $params['param'][2]['fid'];
			if(!in_array($fid, unserialize($pconfig['fids']))) return;
			$moderators = explode("\t", $_G['forum']['moderators']);
			if(in_array($_G['username'], $moderators)) {
				// is moderator
				$post_url = $_G['siteurl'] . $params['param'][1];
				$subject = $_G['thread']['subject'];
				$author = getuserbyuid($_G['thread']['authorid']);
				$msg = $pconfig['mail_text'];
				$msg = str_replace(array('{author}', '{subject}', '{url}'), array($author['username'], $subject, $post_url), $msg);
				if($author['email']) {
					include_once libfile("function/mail");
					sendmail($author['email'], $pconfig['mail_title'], $msg);					
				}
			}
		}
	}
}