<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';

loadcache('plugin');
$pconfig = $_G['cache']['plugin']['nciaer_down_log'];
if(!in_array($_G['groupid'], dunserialize($pconfig['gids']))) {
    showmessage(lang('plugin/nciaer_down_log', 'err'));
}
$count = DB::result_first('SELECT count(*) FROM %t where uid = %d', array('nciaer_down_log', $_G['uid']));
$pagesize = 10;
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $pagesize;
$lists = array();
if ($count) {
    $rs = DB::fetch_all("SELECT * FROM %t where uid = %d ORDER BY dateline DESC LIMIT %d, %d", array('nciaer_down_log', $_G['uid'], $start, $pagesize));
    foreach($rs as $result) {
        $result['dateline'] = date('Y-m-d H:i:s', $result['dateline']);
        $lists[] = $result;
    }
}
$multi = multi($count, $pagesize, $page, 'home.php?mod=spacecp&ac=plugin&id=nciaer_down_log:log');
