<?php
/**
 *     �������ؼ�¼
 *
 *   DisM!Ӧ���������� https://dism.Taobao.Com
 *   ��ַ��dism.taobao.com
 *   ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_down_log {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_down_log'];
    }

    function attachment() {

        global $_G;

        if (!$this->config['on']) return;
        if (!$_G['uid']) return;

        $rs = explode('|', base64_decode($_GET['aid']));
        $aid = intval($rs[0]);
        $tid = intval($rs[4]);
        $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid);

        if ($aid && $rs[3] == $_G['uid']) {
            if($id = DB::result_first('select id from %t where aid = %d and uid = %d', array('nciaer_down_log', $aid, $_G['uid']))) {
                DB::update('nciaer_down_log', array('dateline' => TIMESTAMP), array('aid' => $aid, 'uid' => $_G['uid']));
            } else {
                $thread = get_thread_by_tid($tid);
                DB::insert('nciaer_down_log', array(
                    'aid' => $aid,
                    'filename' => $attach['filename'],
                    'tid' => $tid,
                    'subject' => $thread['subject'],
                    'uid' => $_G['uid'],
                    'dateline' => TIMESTAMP,
                ));
            }
        }
    }
}

class plugin_nciaer_down_log_forum extends plugin_nciaer_down_log {}

class mobileplugin_nciaer_down_log_forum extends plugin_nciaer_down_log {}