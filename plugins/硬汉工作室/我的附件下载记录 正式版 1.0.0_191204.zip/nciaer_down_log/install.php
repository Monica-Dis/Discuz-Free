<?php
/**
 *   DisM!Ӧ���������� https://dism.Taobao.Com 
 *   ��ַ��dism.taobao.com
 *   ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
$sql = <<<EOF
   create table if not exists `pre_nciaer_down_log` (
	  `id` int(11) not null auto_increment primary key,
	  `aid` int(11) not null default 0,
	  `filename` varchar(250) not null default '',
	  `tid` int(11) not null default 0,
	  `subject` varchar(250) not null default '',
	  `uid` int(11) not null default 0,
	  `dateline` int not null default 0
   ) engine=myisam;
EOF;
runquery($sql);

$finish = TRUE;