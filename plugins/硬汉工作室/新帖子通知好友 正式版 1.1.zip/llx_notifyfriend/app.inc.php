<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 *
 * ��ַ�� http://dism.taobao.com
 * DisM.Taobao.Com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://dism.taobao.com/?@56030.developer');