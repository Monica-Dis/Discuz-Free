<?php
/**
 *   ������֪ͨ����
 *
 *   Copyright (c) 2021 by dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_notifyfriend {
	
	public $config = array();
	public $checked = '';
	
	public function __construct() {
		
		global $_G;
		$this->config = $_G['cache']['plugin']['llx_notifyfriend'];
		$this->checked = $this->config['checked'] ? 'checked = "checked"' : '';
	}
	
	public function post_message($p) {
		
		global $_G, $subject;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		$param = $p['param'];
		if($param[0] == 'post_newthread_succeed' && intval($_GET['notifyfriend'])) {
			$friends = C::t('home_friend')->fetch_all_by_uid($_G['uid']);
			$msg = str_replace(
				array('{username}', '{subject}'), 
				array($_G['username'], "<a href = '{$param[1]}'>{$subject}</a>"), $this->config['msg']
			);
			if($this->config['maxnum'] && count($friends) > $this->config['maxnum']) {
				$friend_indexs = array_rand($friends, $this->config['maxnum']);
				foreach($friend_indexs as $friend_index) {
					notification_add($friends[$friend_index]['fuid'], 'system', $msg, NULL, 1);
				}
			} else {
				foreach($friends as $friend) {
					notification_add($friend['fuid'], 'system', $msg, NULL, 1);
				}				
			}
		}
	}
}

class plugin_llx_notifyfriend_forum extends plugin_llx_notifyfriend {
	
	public function post_middle() {
	
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		include template('llx_notifyfriend:index');
		return $return;
	}
}

class mobileplugin_llx_notifyfriend_forum extends plugin_llx_notifyfriend {
	
	public function post_bottom_mobile() {
		
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		include template('llx_notifyfriend:index');
		return $return;	
	}
}