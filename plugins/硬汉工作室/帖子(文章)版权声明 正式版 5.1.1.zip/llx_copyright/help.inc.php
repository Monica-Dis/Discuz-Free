<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * ��ַ�� http://t.cn/AiuxBSZq
 * DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:http://t.cn/AiuxBSZq/plugin.php?id=nciaer_feedback&plugin='.$plugin['identifier']);