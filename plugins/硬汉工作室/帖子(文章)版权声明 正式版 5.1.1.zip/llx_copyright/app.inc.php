<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * ��ַ�� http://t.cn/AiuxBSZq
 * DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://dism.taobao.com/?@56030.developer');