<?php
/**
 * ���ӣ����£���Ȩ
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.Taobao.COm
 *   dism.taobao.com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_copyright {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['llx_copyright'];
    }

    public function viewthread_llx_output() {

        global $_G, $postlist;

        if (!$this->config['forum_enable']) return;
        if($_G['forum']['status'] != 3) {
            if (!in_array($_G['fid'], dunserialize($this->config['fids']))) return;
        }

        $color = $this->config['color'];
        $titlecolor = $this->config['titlecolor'];
        $background = $this->config['background'];

        if (!empty($_G['setting']['rewriterule']['forum_viewthread']) && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
            $url = $_G['siteurl'].rewriteoutput('forum_viewthread', 1, '', $_G['tid']);
        } else {
            $url = $_G['siteurl']."forum.php?mod=viewthread&tid={$_G['tid']}";
        }
        $pageurl = "<a href = '{$url}' target='_blank'>{$url}</a>";

        foreach ($postlist as $k => $post) {
            if ($post["first"]) {
                include template('llx_copyright:block');
                if ($this->config['position']) {
                    $postlist[$k]["message"] = $post["message"] . $return;
                } else {
                    $postlist[$k]["message"] = $return . $post["message"];
                }
            }
        }
    }

    public function view_llx_output() {

        global $_G, $article, $content;

        if (!$this->config['portal_enable']) return;

        $color = $this->config['color'];
        $titlecolor = $this->config['titlecolor'];
        $background = $this->config['background'];

        if (!empty($_G['setting']['rewriterule']['portal_article']) && in_array('portal_article', $_G['setting']['rewritestatus'])) {
            $url = $_G['siteurl'].rewriteoutput('portal_article', 1, '', $article['aid']);
        } else {
            $url = $_G['siteurl']."portal.php?mod=view&aid={$article['aid']}";
        }
        $pageurl = "<a href = '{$url}' target='_blank'>{$url}</a>";

        include template('llx_copyright:portal_block');
        if ($this->config['position']) {
            $content["content"] = $content["content"] . $return;
        } else {
            $content["content"] = $return . $content["content"];
        }
    }
}

class plugin_llx_copyright_forum extends plugin_llx_copyright {}
class mobileplugin_llx_copyright_forum extends plugin_llx_copyright {}

class plugin_llx_copyright_group extends plugin_llx_copyright {}
class mobileplugin_llx_copyright_group extends plugin_llx_copyright {}

class plugin_llx_copyright_portal extends plugin_llx_copyright {}
class mobileplugin_llx_copyright_portal extends plugin_llx_copyright {}