<?php
/**
 *   Copyright 2001-2099 DisM!Ӧ������. 
 *   From: DisM.taobao.Com
 *   DisM!�û�����Ⱥ: ��Ⱥ778390776
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied!');
}
//From: Dism_taobao_com
?>
<iframe src="http://dism.taobao.com/?@56030.developer" width="1010" height="2300" frameborder="0" scrolling="no"></iframe>