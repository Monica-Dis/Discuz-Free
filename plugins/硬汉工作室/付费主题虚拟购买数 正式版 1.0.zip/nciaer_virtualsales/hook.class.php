<?php
/**
 *	 �������⹺����
 *
 *   Copyright 2001-2099 DisM!Ӧ������. 
 *   From: DisM.taobao.Com
 *   DisM!�û�����Ⱥ: ��Ⱥ778390776
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_virtualsales {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_virtualsales'];
	}
	
	public function post_message($params) {
		
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		$param = $params['param'];
		if(($param[0] == 'post_newthread_succeed' || $param[0] == 'post_newthread_mod_succeed') && $_GET['price']) {
			list($min, $max) = explode('-', $this->config['nums']);
			$num = mt_rand(intval($min), intval($max));
			if($num) {
				for($i = 0; $i < $num; $i++) {
					updatemembercount($_G['uid'], array('extcredits2' => '+0'), 1, 'STC', $param[2]['tid']);
				}
			}
		}		
	}	
}

class plugin_nciaer_virtualsales_forum extends plugin_nciaer_virtualsales {}

class mobileplugin_nciaer_virtualsales_forum extends plugin_nciaer_virtualsales {}