<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_himickey_baiduseo {


    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['himickey_baiduseo'];
    }

	public function deletethread($params) {
		
		global $_G;

		if($this->config['del']) {
			$urls = array();
			foreach($params['param'][0] as $tid) {
				$urls[] = $this->_geturl($tid);
			}

			$this->_pushbaidu('del', $urls);
		}
	}

    public function post_message($params) {

        global $_G;

        if($_G['forum']['status'] != 3) {
            if(!in_array($_G['fid'], dunserialize($this->config['fids']))) return;
        }
        if(!in_array($_G['groupid'], dunserialize($this->config['gids']))) return;

        $param = $params['param'];
        $thread = C::t('forum_thread')->fetch($param[2]['tid']);
        if($thread['displayorder']<0) return;

        $pushurl = $_G['siteurl'] . $param[1];
        $urls = array($pushurl);

        if($param[0] == 'post_newthread_succeed') {
            if(!$this->config['push']) return;
            $this->_pushbaidu('urls', $urls);
        } elseif($param[0] == 'post_edit_succeed') {
            if(!$this->config['edit']) return;
            $this->_pushbaidu('update', $urls);
        }
    }
    public function _geturl($tid) {

        global $_G;

        if(!empty($_G['setting']['rewriterule']['forum_viewthread']) && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
            $pushurl = $_G['siteurl'] . rewriteoutput('forum_viewthread', 1, '', $tid, 1, '', '');
        } else {
            $pushurl = $_G['siteurl'] . "forum.php?mod=viewthread&tid=".$tid;
        }

        return $pushurl;
    }

    public function _pushbaidu($type, $urls) {

        global $_G;

        $api = "http://data.zz.baidu.com/{$type}?site={$_G['siteurl']}&token={$this->config['token']}";
        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        curl_exec($ch);
    }
}

class plugin_himickey_baiduseo_forum extends plugin_himickey_baiduseo {}

class plugin_himickey_baiduseo_group extends plugin_himickey_baiduseo {

    public function post_message($params) {

        if(!$this->config['group_enable']) return;

        parent::post_message($params);
    }

}

class mobileplugin_himickey_baiduseo extends plugin_himickey_baiduseo {}

class mobileplugin_himickey_baiduseo_forum extends mobileplugin_himickey_baiduseo {
	
	public function post_message($params) {
		
		if(!$this->config['mobile_enable']) return;

        parent::post_message($params);
	}
}