<?php
/**
 *   ���������Ż�SEO
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com 
 *   ��ַ��dism.taobao.com
 *   QQ: DISM.TAOBAO.COM
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nciaer_thread404seo {
	
    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_thread404seo'];
    }	

    public function viewthread() {

        global $_G;

        $thread = $_G['forum_thread'];
        if(empty($thread['tid']) || $thread['displayorder'] == -1) {
            if(isset($_GET['modthreadkey']) && ($_GET['modthreadkey'] == modauthkey($thread['tid']))) return;
            $this->_404();
            die;
        }
    }

    public function view() {

        global $_G;

        $aid = empty($_GET['aid'])?0:intval($_GET['aid']);

        $article = C::t('portal_article_title')->fetch($aid);
        require_once libfile('function/portalcp');
        $categoryperm = getallowcategory($_G['uid']);

        if(empty($article) || ($article['status'] > 0 && $article['uid'] != $_G['uid'] && !$_G['group']['allowmanagearticle'] && empty($categoryperm[$article['catid']]['allowmanage']) && $_G['adminid'] != 1 && $_GET['modarticlekey'] != modauthkey($article['aid']))) {
            $this->_404();
            die;
        }

    }
	
	function _404() {
		
		global $_G;
		
		$siteurl = !empty($this->config['btnurl']) ? $this->config['btnurl'] : $_G["siteurl"];
		$charset = $_G["charset"];
		$btntext = $this->config['btntext'];
		$title = $this->config['title'];
		$img404 = explode(PHP_EOL, $this->config['imglist']);
		$img = trim($img404[array_rand($img404)]);
		if($this->config['return_404']) {
            header("HTTP/1.1 404 Not Found");
        }
		include template("nciaer_thread404seo:index");
	}
}

class plugin_nciaer_thread404seo_forum extends plugin_nciaer_thread404seo {}
class mobileplugin_nciaer_thread404seo_forum extends plugin_nciaer_thread404seo {}
class plugin_nciaer_thread404seo_group extends plugin_nciaer_thread404seo {}
class mobileplugin_nciaer_thread404seo_group extends plugin_nciaer_thread404seo {}
class plugin_nciaer_thread404seo_portal extends plugin_nciaer_thread404seo {}
class mobileplugin_nciaer_thread404seo_portal extends plugin_nciaer_thread404seo {}
