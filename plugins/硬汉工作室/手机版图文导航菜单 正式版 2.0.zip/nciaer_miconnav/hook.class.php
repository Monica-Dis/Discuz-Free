<?php
/**
 *	 �ֻ���ͼ�ĵ����˵�
 *
 *   ������ҵ���/ģ������ ����DisM!Ӧ������
 *   Support: DisM!Ӧ������
 *   (C) dism-Taobao-com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_miconnav {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_miconnav'];
        $this->config['showposition'] = dunserialize($this->config['showposition']);
    }

    public function _getnav() {

        global $_G;

        if(!$this->config['on']) return '';
        $newblank = $this->config['newblank'] ? 'target="_blank"' : '';
        $width_arr = array(3 => '33.33%', 4 => '25%', 5 => '20%');
        $width = $width_arr[$this->config['colnum']];
        $cachefile = DISCUZ_ROOT.'./data/sysdata/cache_nciaer_miconnav.php';
        if(@file_exists($cachefile)) {
            require_once $cachefile;
        } else {
            $navs = C::t('#nciaer_miconnav#nciaer_miconnav')->fetch_all_by_displayorder();
        }

        $img_url = !empty($this->config['img_url']) ? $this->config['img_url'] : '';
        $url = $this->config['url'];

        include template('nciaer_miconnav:index');
        return $return;
    }
}

class mobileplugin_nciaer_miconnav_forum extends plugin_nciaer_miconnav {

    public function index_top_mobile() {

        return in_array(1, $this->config['showposition']) ? $this->_getnav() : '';
    }

    public function forumdisplay_top_mobile() {

        return in_array(2, $this->config['showposition']) ? $this->_getnav() : '';
    }

    public function viewthread_top_mobile() {

        return in_array(3, $this->config['showposition']) ? $this->_getnav() : '';
    }
}