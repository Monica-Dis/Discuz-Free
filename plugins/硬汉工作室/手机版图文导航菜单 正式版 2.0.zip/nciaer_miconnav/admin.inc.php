<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$operation = $_GET['op'] ? $_GET['op'] : '';
$purl = "action=plugins&operation=config&do={$do}&identifier=nciaer_miconnav&pmod=admin";
cpheader();

if(empty($operation)) {
    if(!submitcheck('navsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_miconnav&pmod=admin");
        showtableheader(L('navlist'));
        showsubtitle(array('del', 'display_order', 'subject', 'misc_customnav_icon', 'url', 'dateline', ''));

        $navlist = C::t('#nciaer_miconnav#nciaer_miconnav')->fetch_all_by_displayorder();
        foreach ($navlist as $nav) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\" >",
                "<input type=\"text\" class=\"txt\" name=\"displayordernew[{$nav[id]}]\" value=\"$nav[displayorder]\" size=\"2\">",
                $nav['title'],
                "<img src = '{$nav[pic]}' width = '50px' height='50px'/>",
                $nav['url'],
                dgmdate($nav['dateline'], 'Y-n-j H:i'),
                "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$do}&identifier=nciaer_miconnav&pmod=admin&op=edit&nid={$nav['id']}\" >$lang[edit]</a>"
            ));
        }
        showsubmit('navsubmit', 'submit', 'select_all', "<a href='".ADMINSCRIPT."?{$purl}&op=add'>".L('add')."</a>");
        showtablefooter();
        showformfooter();

    } else {
        if(is_array($_GET['delete'])) {
            C::t('#nciaer_miconnav#nciaer_miconnav')->delete_by_id($_GET['delete']);
        }

        if(is_array($_GET['displayordernew'])) {
            foreach($_GET['displayordernew'] as $id => $displayorder) {
                C::t('#nciaer_miconnav#nciaer_miconnav')->update_displayorder_by_id($id, $displayorder);
            }
        }
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'add') {
    if(!submitcheck('addsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_miconnav&pmod=admin&op=add", 'enctype');
        showtableheader(L('nav_add'));
        showsetting(L('title'), 'title', '', 'htmltext');
        showsetting(L('url'), 'url', '', 'text');
        showsetting(L('icon_title'), 'icon', '', 'filetext');
        showsubmit('addsubmit');
        showtablefooter();
        showformfooter();

    } else {
        $title = trim($_GET['title']);
        $url = trim($_GET['url']);
        if(!$title || !$url || (!$_FILES['icon']['name'] && !$_GET['icon'])) {
            cpmsg(L('field_error'), '', 'error');
        }
        if($_FILES['icon']) {
            $upload = new discuz_upload();
            if($upload->init($_FILES['icon'], 'common') && $upload->save(1)) {
                $pic = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $pic = trim($_GET['icon']);
        }

        $data = array(
            'title' => strip_tags($title, '<u><i><b><font>'),
            'pic' => $pic,
            'url' => $url,
            'dateline' => TIMESTAMP,
        );
        C::t('#nciaer_miconnav#nciaer_miconnav')->insert($data);
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'edit' && $_GET['nid']) {
    $nav = C::t('#nciaer_miconnav#nciaer_miconnav')->fetch($_GET['nid']);
    if(!$nav) {
        cpmsg(L('data_error'), $purl, 'error');
    }

    if(!submitcheck('editsubmit')) {

        $b = $i = $u = $colorselect = $colorcheck = '';
        if(preg_match('/<b>(.*?)<\/b>/i', $nav['title'])) {
            $b = 'class="a"';
        }
        if(preg_match('/<i>(.*?)<\/i>/i', $nav['title'])) {
            $i = 'class="a"';
        }
        if(preg_match('/<u>(.*?)<\/u>/i', $nav['title'])) {
            $u = 'class="a"';
        }
        $colorselect = preg_replace('/<font color=(.*?)>(.*?)<\/font>/i', '$1', $nav['title']);
        $colorselect = strip_tags($colorselect);
        $_G['forum_colorarray'] = array(1=>'#EE1B2E', 2=>'#EE5023', 3=>'#996600', 4=>'#3C9D40', 5=>'#2897C5', 6=>'#2B65B7', 7=>'#8F2A90', 8=>'#EC1282');
        if(in_array($colorselect, $_G['forum_colorarray'])) {
            $colorcheck = "style=\"background: $colorselect\"";
        }

        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_miconnav&pmod=admin&op=edit&nid={$_GET['nid']}", 'enctype');
        showtableheader();
        showtitle(L('navedit'));
        showsetting(L('title'), 'title', $nav['title'], 'htmltext');
        showsetting(L('url'), 'url', $nav['url'], 'text');
        showsetting(L('icon_title'), 'icon', $nav['pic'], 'filetext');
        showsubmit('editsubmit');
        showtablefooter();
        showformfooter();
    } else {
        $title = trim($_GET['title']);
        $url = trim($_GET['url']);
        if(!$title || !$url || (!$_FILES['icon']['name'] && !$_GET['icon'])) {
            cpmsg(L('field_error'), '', 'error');
        }

        if($_FILES['icon']) {
            $upload = new discuz_upload();
            if($upload->init($_FILES['icon'], 'common') && $upload->save(1)) {
                $pic = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $pic = trim($_GET['icon']);
        }

        C::t('#nciaer_miconnav#nciaer_miconnav')->update_by_id($_GET['nid'], array(
            'title' => strip_tags($title, '<u><i><b><font>'),
            'pic' => $pic,
            'url' => $url,
            'dateline' => TIMESTAMP,
        ));
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }
}

function L($lang) {
    return lang('plugin/nciaer_miconnav', $lang);
}

function _cache() {

    global $_G;

    require_once libfile('function/cache');
    $navlist = C::t('#nciaer_miconnav#nciaer_miconnav')->fetch_all_by_displayorder();
    $cacheArr = "\$navs = " . arrayeval($navlist) . ";\n";
    writetocache("nciaer_miconnav", $cacheArr);
}