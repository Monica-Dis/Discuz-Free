<?php
/**
 * �ֻ����������
 *
 *   Copyright 2001-2099 DisM!Ӧ������.
 *   https://dism.taobao.com
 *   DisM.taobao.Com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_relatedthread {

    public $config = array();

    public function __construct() {
		
        global $_G;
        $this->config = $_G['cache']['plugin']['llx_relatedthread'];
    }
}

class mobileplugin_llx_relatedthread_forum extends plugin_llx_relatedthread {
    
	public function viewthread_llx_output() {
        
		global $_G, $postlist;

        if($this->config['pos'] != 1) return;
        if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
        if($postlist) {
            foreach($postlist as $k => $post) {
                if($post["first"] && $post['relateitem']) {
                    $fontsize = intval($this->config['fontsize']);
                    $fontcolor = $this->config['fontcolor'];
                    include template('llx_relatedthread:index');
                    $postlist[$k]["message"] = $post["message"] . $return;
                }
            }
        }
    }

    public function viewthread_postbottom_mobile_output() {

	    global $_G, $postlist;

        if($this->config['pos'] != 2) return array();
        if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;

	    if($_G['page'] == 1) {
	        $return = '';
            if($postlist) {
                foreach($postlist as $k => $post) {
                    if($post["first"] && $post['relateitem']) {
                        $fontsize = intval($this->config['fontsize']);
                        $fontcolor = $this->config['fontcolor'];
                        include template('llx_relatedthread:index');
                    }
                }
            }
            return array($return);
        }
	    return array();
    }
}