<?php
/**
 *	 ��վ�������
 *
 *   DisM!Ӧ���������� https://dism.Taobao.Com
 *   ���̵�ַ��https://DisM.taobao.com
 *   Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_webpwd {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_webpwd'];
    }

    public function common() {

        global $_G;

        if(!$this->config['on']) return;


        if($this->config['robot'] && checkrobot()) return;

        if(CURSCRIPT == 'plugin' && $_GET['id'] == 'nciaer_webpwd:pwd') return;

        $pwd = authcode(getcookie('nciaer_webpwd'));
        if($pwd == $this->config['pwd']) return;

        $timestamp = TIMESTAMP - 3600;
        $errnum = intval(DB::result_first('select count(*) from %t where ip = %s and dateline >= %d', array('nciaer_webpwd', $_G['clientip'], $timestamp)));
        $errtip = $this->config['error_more'];
        include template('nciaer_webpwd:pwd');
        die;
    }
}

class mobileplugin_nciaer_webpwd extends plugin_nciaer_webpwd {}