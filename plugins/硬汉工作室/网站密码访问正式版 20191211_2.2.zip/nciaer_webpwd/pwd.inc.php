<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (submitcheck('pwdsubmit')) {
    loadcache('plugin');
    $pconfig = $_G['cache']['plugin']['nciaer_webpwd'];
    $timestamp = TIMESTAMP - 3600;
    $errnum = intval(DB::result_first('select count(*) from %t where ip = %s and dateline >= %d', array('nciaer_webpwd', $_G['clientip'], $timestamp)));
    if($errnum >= 3) {
        dheader('Location: ' . $_G['siteurl']);
        die;
    }
    $pwdtime = intval($pconfig['pwdtime']);
    $pwd = trim($_GET['pwd']);
    if ($pwd == $pconfig['pwd']) {
        $authpwd = authcode($pwd, 'ENCODE');
        dsetcookie('nciaer_webpwd', $authpwd, 3600 * $pwdtime);
    } else { // err pwd
        DB::insert('nciaer_webpwd', array('ip' => $_G['clientip'], 'dateline' => TIMESTAMP));
    }
    if($pconfig['referer']) {
        dheader('Location: ' . dreferer());
    } else {
        dheader('Location: ' . $_G['siteurl']);
    }
}

