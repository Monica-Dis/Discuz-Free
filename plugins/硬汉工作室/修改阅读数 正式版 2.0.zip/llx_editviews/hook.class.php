<?php
/**
 *   �޸����ӡ������Ķ��� v2.0
 *
 *   Ӳ�������� ��Ȩ����
 *   ��ַ��dism.taobao.com
 *   QQ: 1069971363
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_editviews {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['llx_editviews'];
	}
}
	
	
class plugin_llx_editviews_forum extends plugin_llx_editviews {
	
	public function viewthread_modoption() {
		
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		return "<a href='javascript:;' onclick=\"showWindow('mods', 'plugin.php?id=llx_editviews:views&idx=$_G[tid]&fid=$_G[fid]&type=1', 'get', 0)\">{$this->config['btn_text']}</a><span class='pipe'>|</span>";
	}	
}

class plugin_llx_editviews_group extends plugin_llx_editviews {

    public function viewthread_modoption() {

        global $_G;

        if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;

        return "<a href='javascript:;' onclick=\"showWindow('mods', 'plugin.php?id=llx_editviews:views&idx=$_G[tid]&fid=$_G[fid]&type=3', 'get', 0)\">{$this->config['btn_text']}</a><span class='pipe'>|</span>";
    }
}

class plugin_llx_editviews_portal extends plugin_llx_editviews {
	
	public function view_article_subtitle_output() {
		
		global $_G;
		
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		return "<span class=\"pipe\">|</span><a href='javascript:;' onclick=\"showWindow('mods', 'plugin.php?id=llx_editviews:views&idx=$_GET[aid]&type=2', 'get', 0)\">{$this->config['btn_text']}</a>";
	}	
}