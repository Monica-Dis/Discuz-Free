<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied!');
}

!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';

$type = intval($_GET['type']);
$idx = intval($_GET['idx']);
$config = $_G['cache']['plugin']['llx_editviews'];
if($type == 1 || $type == 3) {
	$rs = C::t('forum_thread')->fetch($idx);
	$views = $rs['views'];
} else {
	$rs = C::t('portal_article_count')->fetch($idx);
	$views = $rs['viewnum'];
}

if($_GET['formhash'] == FORMHASH) {
	$views = intval(trim($_GET['views']));
	if($views > 0) {
		if($type == 1) {
            $fid = intval($_GET['fid']);
            if (in_array($fid, unserialize($config['fids'])) && in_array($_G['groupid'], unserialize($config['gids']))) {
                C::t('forum_thread')->update($idx, array('views' => $views));
            }
        } elseif($type == 2) {
            if(in_array($_G['groupid'], unserialize($config['gids']))) {
                C::t('portal_article_count')->update($idx, array('viewnum'=>$views));
            }

		} else {
            $fid = intval($_GET['fid']);
            if (in_array($_G['groupid'], unserialize($config['gids']))){
                C::t('forum_thread')->update($idx, array('views' => $views));
            }
		}
	} else {
		die('-1');
	}
}
include template('llx_editviews:views');
