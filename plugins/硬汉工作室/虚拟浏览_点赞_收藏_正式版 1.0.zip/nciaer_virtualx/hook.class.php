<?php
/**
 *	 �������/����/�ղ�
 *
 *   ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *   ��ַ��dism.taobao.com
 *   ���²����http://t.cn/Aiux1Jx1
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_virtualx {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_virtualx'];
	}
	
	protected function _setVirtual($tid, $views, $like, $fav) {
	
		C::t('forum_thread')->update($tid, 
			array(
				'views' => $views,
				'recommends' => $like,
				'recommend_add' => $like,
				'favtimes' => $fav,
			)
		);
	}		
	
	public function post_message($params) {
		
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		$param = $params['param'];
		$views = mt_rand(intval($this->config['min']), intval($this->config['max']));
		
		if($param[0] == 'post_newthread_succeed' || $param[0] == 'post_newthread_mod_succeed') {
			
			$tid = $param[2]['tid'];
			list($min, $max) = explode('-', $this->config['views']);
			$views = mt_rand(intval($min), intval($max));
			list($min, $max) = explode('-', $this->config['like']);
			$like = mt_rand(intval($min), intval($max));
			list($min, $max) = explode('-', $this->config['fav']);
			$fav = mt_rand(intval($min), intval($max));			
			$this->_setVirtual($tid, $views, $like, $fav);
		}		
	}	
}

class plugin_nciaer_virtualx_forum extends plugin_nciaer_virtualx {}

class mobileplugin_nciaer_virtualx_forum extends plugin_nciaer_virtualx {}