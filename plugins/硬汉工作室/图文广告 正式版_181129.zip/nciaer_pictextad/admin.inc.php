<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$appurl = $_G['siteurl'] . ADMINSCRIPT . "?action=plugins&operation=config&do=$_GET[do]&identifier=nciaer_pictextad&pmod=admin";
$pagesize = 10;
$p = isset($_GET['p']) ? $_GET['p'] : 'index';
if(!in_array($p, array('index', 'add', 'edit', 'del'))) {
	cpmsg(dlang('error'), $appurl, 'error');
}

if($p == 'index') {
	$page = $_G['page'];
	$start = ($page - 1) * $pagesize ;
	$datas = DB::fetch_all('select * from %t order by displayorder desc limit %d, %d', array('nciaer_pictextad', $start, $pagesize));
	$count = C::t('#nciaer_pictextad#pictextad')->count();
	$pages = multi($count, $pagesize , $page, $appurl . "&p={$p}");
} elseif($p == 'add') {
	if(submitcheck('addsubmit')){
        $title = dhtmlspecialchars(addslashes(trim($_GET['title'])));
        $pic = dhtmlspecialchars(addslashes(trim($_GET['pic'])));
        $url = dhtmlspecialchars(addslashes(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
		$displayorder = intval($_GET['displayorder']);		
        $dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(dlang('miss_msg'), $appurl . '&p=add', 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(dlang('up_err'), $appurl . '&p=ad', 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(dlang('img_ext_err'), $appurl . '&p=add', 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		C::t('#nciaer_pictextad#pictextad')->insert(
            array(
                'title' => $title,
                'pic' => $pic,
                'url' => $url,
                'inuse' => $inuse,
                'displayorder' => $displayorder,
                'dateline' => $dateline,
            )
        );
		_updatecache();
		cpmsg(dlang('add_ok'), $appurl, 'succeed');
	}
} elseif($p == 'edit') {
	$id = intval($_GET['id']);
	$data = DB::fetch_first("select * from %t where id = %d", array('nciaer_pictextad', $id));
    if(submitcheck('editsubmit')){
        $title = dhtmlspecialchars(addslashes(trim($_GET['title'])));
        $pic = dhtmlspecialchars(addslashes(trim($_GET['pic'])));
        $url = dhtmlspecialchars(addslashes(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
		$displayorder = intval($_GET['displayorder']);
		$dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(dlang('miss_msg'), $appurl . '&p=add&id='.$id, 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(dlang('up_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(dlang('img_ext_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		C::t('#nciaer_pictextad#pictextad')->update_by_id($id,
            array(
                'title' => $title,
                'pic' => $pic,
                'url' => $url,
                'inuse' => $inuse,
                'displayorder' => $displayorder,
                'dateline' => $dateline,
            )
        );
		_updatecache();
		cpmsg(dlang('edit_ok'), $appurl, 'succeed');
	}
} elseif($p == 'del') {
	if($_GET['formhash'] == FORMHASH) {
		$id = intval($_GET['id']);
		$ad = C::t('#nciaer_pictextad#pictextad')->fetch($id);
		@unlink($pic_url);
        C::t('#nciaer_pictextad#pictextad')->delete_by_id($id);
		_updatecache();
		cpmsg(dlang('del_ok'), $appurl, 'succeed');
	}
}

function dlang($lang) {

    return lang('plugin/nciaer_pictextad', $lang);
}

function _updatecache() {
	
	global $_G;
	loadcache('plugin');
	$pconfig = $_G['cache']['plugin']['nciaer_pictextad'];
	require_once libfile('function/cache');
	$ads = C::t('#nciaer_pictextad#pictextad')->fetch_all_by_displayorder($pconfig['ad_num']);
	$cacheArr = "\$ads = " . arrayeval($ads) . ";\n";
	writetocache("nciaer_pictextad", $cacheArr);
}

include template("nciaer_pictextad:cp_{$p}");