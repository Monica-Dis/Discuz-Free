<?php
/**
 *   ͼ�Ĺ��
 *
 *   Copyright (c) 2020 by dism.taobao.com 
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_pictextad {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_pictextad'];
    }

    public function global_header() {
	
		global $_G;

		if(!$this->config['on']) return '';

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT.CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showPosition']);
        if(!in_array('all', $showvalue)) {
            if(!in_array($showkey, $showvalue)) return '';
        }

        if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_pictextad.php")) {
			require_once DISCUZ_ROOT . "./data/sysdata/cache_nciaer_pictextad.php";
		} else {
		    $ads = C::t('#nciaer_pictextad#pictextad')->fetch_all_by_displayorder($this->config['ad_num']);
            require_once libfile('function/cache');
			$cacheArr = "\$ads = " . arrayeval($ads) . ";\n";
			writetocache("nciaer_pictextad", $cacheArr);
		}
		$bordercolor = $this->config['bordercolor'];
		$titlebgcolor = $this->config['titlebgcolor'];
		$titlecolor = $this->config['titlecolor'];
		$noad = array(
		    'title' => $this->config['ad_tip'],
            'pic' => $this->config['defaultimg'],
            'url' => "https://wpa.qq.com/msgrd?v=3&uin={$this->config['qq']}&site=qq&menu=yes",
        );
		$leftnum = $this->config['ad_num'] - count($ads);
		for ($i = 0; $i < $leftnum; $i++) {
			$ads[] = $noad;
		}

		if($this->config['ad_width'] == 1) {
			$ad_width = 'width: 960px;';
		} elseif($this->config['ad_width'] == 2) {
			$ad_width = 'width: 1122px;';
		} elseif($this->config['ad_width'] == 3) {
            $ad_width = 'width: 1284px;';
        } elseif($this->config['ad_width'] == 4) {
            $ad_width = 'width: 1200px;';
		} else {
		    $ad_width = '';
        }
		require template('nciaer_pictextad:block');
		return $return;
	}
}