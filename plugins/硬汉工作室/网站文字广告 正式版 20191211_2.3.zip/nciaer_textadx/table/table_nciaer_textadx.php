<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nciaer_textadx extends discuz_table {

    public function __construct() {

        $this->_table = 'nciaer_textadx';
        $this->_pk    = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_all_by_displayorder() {
        return DB::fetch_all('SELECT * FROM %t ORDER BY displayorder DESC ', array($this->_table), $this->_pk);
    }

    public function fetch_all_by_displayorder2($start, $pagesize) {
        return DB::fetch_all('SELECT * FROM %t ORDER BY displayorder DESC limit %d, %d', array($this->_table, $start, $pagesize), $this->_pk);
    }

    public function fetch($id) {
        return DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
    }

    public function delete_by_id($ids) {
        if(($ids = dintval((array)$ids, true))) {
            DB::query('DELETE FROM %t WHERE id IN(%n)', array($this->_table, $ids), false, true);
        }
    }

    public function update_displayorder_by_id($id, $displayorder) {
        if(($id = dintval((array)$id, true))) {
            DB::query('UPDATE %t SET displayorder=%d WHERE id IN(%n)', array($this->_table, $displayorder, $id, $adminid, $username), false, true);
        }
    }

    public function update_by_id($id, $data) {
        DB::update($this->_table, $data, DB::field($this->_pk, $id), true);
    }

    public function count() {
        return DB::result_first('select count(*) from %t ', array($this->_table));
    }
}
