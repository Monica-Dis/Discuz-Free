<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$operation = $_GET['op'] ? $_GET['op'] : '';
$purl = "action=plugins&operation=config&do={$do}&identifier=nciaer_textadx&pmod=admin";
echo '<script src="static/js/calendar.js"></script>';

if(empty($operation)) {
    if(!submitcheck('adsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_textadx&pmod=admin");
        showtableheader(L('adlist'));
        showsubtitle(array('del', 'display_order', 'subject', 'url', L('starttime'), L('endtime'), L('status'), 'dateline', ''));
        $pagesize = 15;
        $count = C::t('#nciaer_textadx#nciaer_textadx')->count();
        $start = ($page - 1) * $pagesize;

        $adlist = C::t('#nciaer_textadx#nciaer_textadx')->fetch_all_by_displayorder2($start, $pagesize);
        foreach ($adlist as $nav) {
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\" >",
                "<input type=\"text\" class=\"txt\" name=\"displayordernew[{$nav[id]}]\" value=\"$nav[displayorder]\" size=\"2\">",
                $nav['title'].(!empty($nav['icon']) ? " <img style = 'vertical-align: middle;' src = 'source/plugin/nciaer_textadx/images/{$nav[icon]}' />" : ''),
                $nav['url'],
                date('Y-m-d', $nav['starttime']),
                date('Y-m-d', $nav['endtime']),
                dfetchstatus($nav['starttime'], $nav['endtime']),
                dgmdate($nav['dateline'], 'Y-n-j H:i'),
                "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$do}&identifier=nciaer_textadx&pmod=admin&op=edit&nid={$nav['id']}\" >$lang[edit]</a>"
            ));
        }
        $pages = multi($count, $pagesize, $page, ADMINSCRIPT.'?'.$purl);
        showsubmit('adsubmit', 'submit', 'select_all', "<a href='".ADMINSCRIPT."?{$purl}&op=add'>".L('addad')."</a>", $pages);
        showtablefooter(); /*Dism_taobao_com*/
        showformfooter(); /*Dism_taobao-com*/

    } else {
        if(is_array($_GET['delete'])) {
            C::t('#nciaer_textadx#nciaer_textadx')->delete_by_id($_GET['delete']);
        }

        if(is_array($_GET['displayordernew'])) {
            foreach($_GET['displayordernew'] as $id => $displayorder) {
                C::t('#nciaer_textadx#nciaer_textadx')->update_displayorder_by_id($id, $displayorder);
            }
        }
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'add') {
    if(!submitcheck('addsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_textadx&pmod=admin&op=add", 'enctype');
        showtableheader(L('addad'));
        showsetting(L('title'), 'title', '', 'htmltext');
        $icons = array('icon',
            array(
                array('', L('noicon')),
                array('hot1.gif', L('icon').'1'),
                array('hot2.gif', L('icon').'2'),
                array('hot3.gif', L('icon').'3'),
                array('hot4.gif', L('icon').'4'),
                array('hot5.gif', L('icon').'5'),
                array('hot6.gif', L('icon').'6'),
            )
        );
        showsetting(L('icon'), $icons, '', 'select', '', 0, L('icon_desc'));
        showsetting('url', 'url', '', 'text');
        showsetting(L('starttime'), 'starttime', date('Y-m-d'), 'calendar');
        showsetting(L('endtime'), 'endtime', '', 'calendar');
        showsubmit('addsubmit');
        showtablefooter(); /*Dism_taobao_com*/
        showformfooter(); /*Dism_taobao-com*/

    } else {
        $title = trim($_GET['title']);
        $url = trim($_GET['url']);
        $icon = trim($_GET['icon']);
        $starttime = strtotime($_GET['starttime']);
        $endtime = !empty($_GET['endtime']) ? strtotime($_GET['endtime']) : TIMESTAMP + 86400 * 7;
        if(empty($title) || empty($url)) {
            cpmsg(L('field_error'), '', 'error');
        }

        $data = array(
            'title' => strip_tags($title, '<u><i><b><font>'),
            'icon' => $icon,
            'url' => $url,
            'starttime' => $starttime,
            'endtime' => $endtime,
            'dateline' => TIMESTAMP,
        );
        C::t('#nciaer_textadx#nciaer_textadx')->insert($data);
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'edit' && $_GET['nid']) {
    $nav = C::t('#nciaer_textadx#nciaer_textadx')->fetch($_GET['nid']);
    if(!$nav) {
        cpmsg(L('data_error'), $purl, 'error');
    }

    if(!submitcheck('editsubmit')) {

        $b = $i = $u = $colorselect = $colorcheck = '';
        if(preg_match('/<b>(.*?)<\/b>/i', $nav['title'])) {
            $b = 'class="a"';
        }
        if(preg_match('/<i>(.*?)<\/i>/i', $nav['title'])) {
            $i = 'class="a"';
        }
        if(preg_match('/<u>(.*?)<\/u>/i', $nav['title'])) {
            $u = 'class="a"';
        }
        $colorselect = preg_replace('/<font color=(.*?)>(.*?)<\/font>/i', '$1', $nav['title']);
        $colorselect = strip_tags($colorselect);
        $_G['forum_colorarray'] = array(1=>'#EE1B2E', 2=>'#EE5023', 3=>'#996600', 4=>'#3C9D40', 5=>'#2897C5', 6=>'#2B65B7', 7=>'#8F2A90', 8=>'#EC1282');
        if(in_array($colorselect, $_G['forum_colorarray'])) {
            $colorcheck = "style=\"background: $colorselect\"";
        }

        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_textadx&pmod=admin&op=edit&nid={$_GET['nid']}", 'enctype');
        showtableheader();
        showtitle(L('editad'));
        showsetting(L('title'), 'title', $nav['title'], 'htmltext');
        $icons = array('icon',
            array(
                array('', L('noicon')),
                array('hot1.gif', L('icon').'1'),
                array('hot2.gif', L('icon').'2'),
                array('hot3.gif', L('icon').'3'),
                array('hot4.gif', L('icon').'4'),
                array('hot5.gif', L('icon').'5'),
                array('hot6.gif', L('icon').'6'),
            )
        );
        showsetting(L('icon'), $icons, $nav['icon'], 'select', '', 0, L('icon_desc'));
        showsetting('url', 'url', $nav['url'], 'text');
        showsetting(L('starttime'), 'starttime', date('Y-m-d', $nav['starttime']), 'calendar');
        showsetting(L('endtime'), 'endtime', date('Y-m-d', $nav['endtime']), 'calendar');
        showsubmit('editsubmit');
        showtablefooter(); /*Dism_taobao_com*/
        showformfooter(); /*Dism_taobao-com*/
    } else {
        $title = trim($_GET['title']);
        $url = trim($_GET['url']);
        $icon = trim($_GET['icon']);
        $starttime = strtotime($_GET['starttime']);
        $endtime = strtotime($_GET['endtime']);
        if(empty($title) || empty($url)) {
            cpmsg(L('field_error'), '', 'error');
        }

        C::t('#nciaer_textadx#nciaer_textadx')->update_by_id($_GET['nid'], array(
            'title' => strip_tags($title, '<u><i><b><font>'),
            'url' => $url,
            'icon' => $icon,
            'dateline' => TIMESTAMP,
            'endtime' => $endtime,
            'starttime' => $starttime,
        ));
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }
}

function L($lang) {
    return lang('plugin/nciaer_textadx', $lang);
}

function dfetchstatus($starttime, $endtime) {

    if($starttime > $endtime) {
        return L('time_error');
    } else if(TIMESTAMP < $starttime) {
        return L('no_start');
    } elseif(TIMESTAMP >= $starttime && TIMESTAMP <= $endtime) {
        return L('showing');
    } else {
        return L('ended');
    }
}

function _cache() {

    global $_G;

    require_once libfile('function/cache');
    $adlist = C::t('#nciaer_textadx#nciaer_textadx')->fetch_all_by_displayorder();
    $cacheArr = "\$adlist = " . arrayeval($adlist) . ";\n";
    writetocache("nciaer_textadx", $cacheArr);
}