<?php
/**
 *	 ��վ���ֹ��
 *
 *   Copyright (c) 2020 by dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_textadx {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_textadx'];
    }

    public function fetchtextad() {

        global $_G;

        if(!$this->config['on']) return '';

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT.CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showpage']);
        if(!in_array('all', $showvalue)) {
            if(!in_array($showkey, $showvalue)) return '';
        }

        $return = '';
        $blank = $this->config['blank'] ? 'target="_blank"' : '';
        $border = $this->config['border'];
        $bgcolor = $this->config['bgcolor'];
        $column = $this->config['column'];
        $width_arr = array(2 =>'50%', 3=>'33.33%', 4=>'25%', 5=>'20%', 6=>'16.66%', 8=>'12.5%');
        $width = $width_arr[$column];
        $cachefile = DISCUZ_ROOT.'./data/sysdata/cache_nciaer_textadx.php';
        if(@file_exists($cachefile)) {
            include $cachefile;
        } else {
            $adlist = C::t('#nciaer_textadx#nciaer_textadx')->fetch_all_by_displayorder();
        }

        if($this->config['shuffle']) {
            shuffle($adlist);
        }

        include template('nciaer_textadx:ad');

        return !empty($adlist) ? $return : '';
    }

    public function global_header() {

        if(in_array('header', dunserialize($this->config['showpos']))) {
            return $this->fetchtextad();
        } else {
            return '';
        }
    }

    public function global_footer() {

        if(in_array('footer', dunserialize($this->config['showpos']))) {
            return $this->fetchtextad();
        } else {
            return '';
        }
    }
}

