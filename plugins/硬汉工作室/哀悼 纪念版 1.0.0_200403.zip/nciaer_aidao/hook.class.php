<?php
/**
 *	 ����
 *
 *   Ӧ�ø���֧�֣�https://dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   ���²����http://t.cn/Aiux1Jx1
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_aidao {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_aidao'];
    }

    public function common() {

        global $_G;

        if(!$this->config['on']) return;
        $moai = $_G['cookie']['moai'];
        if(empty($moai)) {
            include template('nciaer_aidao:moai');
            die;
        }
    }
}
class mobileplugin_nciaer_aidao extends plugin_nciaer_aidao {}