<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once libfile('function/forumlist');
$operation = $_GET['op'] ? $_GET['op'] : '';
$purl = "action=plugins&operation=config&do={$do}&identifier=nciaer_editor_tip&pmod=admin";
$adminurl = ADMINSCRIPT . "?".$purl;
$pagesize = 10;
$start = ($page - 1) * $pagesize;
if (empty($operation)) {
    if (!submitcheck('dosubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_editor_tip&pmod=admin");
        showtableheader(dlang('list'));
        showsubtitle(array('del', dlang('selectforum'), dlang('message'), 'dateline', ''));

        $navlist = C::t('#nciaer_editor_tip#db')->fetch_all_by_displayorder($start, $pagesize);
        $count = C::t('#nciaer_editor_tip#db')->count($type);
        $pages = multi($count, $pagesize, $page, $adminurl);
        foreach ($navlist as $nav) {
            $forums = C::t('forum_forum')->fetch_all_name_by_fid(dunserialize($nav['fid']));
            $forumname = '';
            foreach($forums as $v) {
                $forumname .= $v['name'].', ';
            }

            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\" >",
                trim($forumname, ', '),
                $nav['message'],
                dgmdate($nav['dateline'], 'Y-n-j H:i'),
                "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do={$do}&identifier=nciaer_editor_tip&pmod=admin&op=edit&nid={$nav['id']}\" >$lang[edit]</a>"
            ));
        }
        showsubmit('dosubmit', 'submit', 'select_all', "<a href='" . ADMINSCRIPT . "?{$purl}&op=add'>" . $lang['add'] . "</a>", $pages);
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();

    } else {
        if (is_array($_GET['delete'])) {
            C::t('#nciaer_editor_tip#db')->delete_by_id($_GET['delete']);
        }
        cpmsg(dlang('success'), $purl, 'succeed');
    }

} elseif ($operation == 'add') {
    if (!submitcheck('addsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_editor_tip&pmod=admin&op=add", 'enctype');
        showtableheader('add');
        $forumselect = forumselect();
        $selectforum = dlang('selectforum');
        $forumstr = <<<STR
<select name="fid[]" id="copyto" class="ps vm" multiple="multiple" size = "10">
    <option value="0">{$selectforum}</option>
$forumselect
</select>
STR;
        showsetting(dlang('selectforum'), '', '', $forumstr, '', 0, '', 1);
        showsetting(dlang('message'), 'message', '', 'textarea');
        showsubmit('addsubmit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();

    } else {
        $fid = serialize($_GET['fid']);
        $message = addslashes(trim($_GET['message']));

        $data = array(
            'fid' => $fid,
            'message' => $message,
            'dateline' => TIMESTAMP,
        );
        C::t('#nciaer_editor_tip#db')->insert($data);
        cpmsg(dlang('success'), $purl, 'succeed');
    }

} elseif ($operation == 'edit' && $_GET['nid']) {
    $nav = C::t('#nciaer_editor_tip#db')->fetch($_GET['nid']);
    if (!$nav) {
        cpmsg(dlang('data_error'), $purl, 'error');
    }

    if (!submitcheck('editsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_editor_tip&pmod=admin&op=edit&nid={$_GET['nid']}", 'enctype');
        showtableheader('edit');
        $selectforum = dlang('selectforum');
        $forumselect = forumselect(FALSE, 0, dunserialize($nav['fid']));
        $forumstr = <<<STR
<select name="fid[]" id="copyto" class="ps vm" multiple="multiple" size = "10">
    <option value="0">{$selectforum}</option>
$forumselect
</select>
STR;
        showsetting(dlang('selectforum'), '', '', $forumstr, '', 0, '', 1);
        showsetting(dlang('message'), 'message', $nav['message'], 'textarea');
        showsubmit('editsubmit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();
    } else {
        $fid = serialize($_GET['fid']);
        $message = addslashes(trim($_GET['message']));

        $data = array(
            'fid' => $fid,
            'message' => $message,
            'dateline' => TIMESTAMP,
        );

        C::t('#nciaer_editor_tip#db')->update_by_id($_GET['nid'], $data);
        cpmsg(dlang('success'), $purl, 'succeed');
    }
}

function dlang($lang) {
    return lang('plugin/nciaer_editor_tip', $lang);
}

