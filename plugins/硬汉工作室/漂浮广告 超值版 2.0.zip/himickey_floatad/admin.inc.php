<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$appurl=$_G['siteurl'] . ADMINSCRIPT . "?action=plugins&operation=config&do=$_GET[do]&identifier=himickey_floatad&pmod=admin";
$pagesize = 10;
$p = isset($_GET['p']) ? $_GET['p'] : 'index';
if(!in_array($p, array('index', 'add', 'edit', 'del', 'cache'))) {
	cpmsg(lang('plugin/himickey_floatad', 'error'), $appurl, 'error');
}

if($p == 'index') {
	$page = $_G['page'];
	$start = ($page - 1) * $pagesize ;
	$datas=DB::fetch_all("select * from " . DB::table('himickey_floatad') . " order by id desc limit {$start}, {$pagesize}");
	$count=DB::result_first("select count(*) from " . DB::table('himickey_floatad'));
	$pages = multi($count, $pagesize , $page, $appurl . "&p={$p}");
} elseif($p == 'add') {
	if(submitcheck('addsubmit')){
        $title = dhtmlspecialchars(addslashes(trim($_GET['title'])));
        $pic = dhtmlspecialchars(addslashes(trim($_GET['pic'])));
        $url = dhtmlspecialchars(addslashes(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
        $dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(lang('plugin/himickey_floatad', 'miss_msg'), $appurl . '&p=add', 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(lang('plugin/himickey_floatad', 'up_err'), $appurl . '&p=ad', 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(lang('plugin/nciaer_superfloatad', 'img_ext_err'), $appurl . '&p=add', 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		DB::insert('himickey_floatad', 
		array(
			'title' => $title,
			'pic' => $pic,
			'url' => $url,
			'inuse' => $inuse, 
			'dateline' => $dateline,
		));
		setcache();
		cpmsg(lang('plugin/himickey_floatad', 'add_ok'), $appurl, 'succeed');
	}
} elseif($p == 'edit') {
	$id = intval($_GET['id']);
	$data = DB::fetch_first("select * from " . DB::table('himickey_floatad') . " where id ='{$id}'");

    if(submitcheck('editsubmit')){
        $title = dhtmlspecialchars(addslashes(trim($_GET['title'])));
        $pic = htmlspecialchars(addslashes(trim($_GET['pic'])));
        $url = dhtmlspecialchars(addslashes(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
		$dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(lang('plugin/himickey_floatad', 'miss_msg'), $appurl . '&p=add&id='.$id, 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(lang('plugin/himickey_floatad', 'up_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(lang('plugin/nciaer_superfloatad', 'img_ext_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		if($pic != $data['pic']) {
			$_pic_url = str_replace($_G['siteurl'], '', $data['pic']);
			@unlink($_pic_url);				
		}		
		DB::update('himickey_floatad',
			array(
				'title' => $title,
				'pic' => $pic,
				'url' => $url,
				'inuse' => $inuse,
				'dateline' => $dateline,
			),
			"id = {$id}"
		);
		setcache();
		cpmsg(lang('plugin/himickey_floatad', 'edit_ok'), $appurl, 'succeed');
	}
} elseif($p == 'del') {
	if($_GET['formhash'] == FORMHASH) {
		$id = intval($_GET['id']);
		$pic = DB::result_first("select pic from " . DB::table('himickey_floatad') . " where id = {$id}");
		$pic_url = str_replace($_G['siteurl'], '', $pic);
		@unlink($pic_url);
		DB::query("delete from " . DB::table('himickey_floatad') . " where id = {$id}");
		setcache();
		cpmsg(lang('plugin/himickey_floatad', 'del_ok'), $appurl, 'succeed');
	}
} else {
	setcache();
	cpmsg(lang('plugin/himickey_floatad', 'cache_ok'), $appurl, 'succeed');
}

function setcache() {
	
	require_once libfile('function/cache');
	$sql = "select * from " . DB::table('himickey_floatad') . " where inuse = 1";
	$datas = DB::fetch_all($sql);
	foreach($datas as &$data) {
		list($img_width, $img_height) = getimagesize($data['pic']);
		$data['w'] = $img_width;
		$data['h'] = $img_height;
	}
	unset($data);
	$cacheArr = "\$datas = " . arrayeval($datas) . ";\n";
	writetocache("himickey_floatad", $cacheArr);
}

require_once template("himickey_floatad:cp_{$p}");