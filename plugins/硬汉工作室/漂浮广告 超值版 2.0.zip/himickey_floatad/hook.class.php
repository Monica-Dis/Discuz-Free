<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_himickey_floatad {
	
	public $configs = array();
	public $return = '';
	
	public function __construct() {
		
		global $_G;
		$this->configs = $_G['cache']['plugin']['himickey_floatad'];
		$this->configs['fids'] = unserialize($this->configs['fids']);
		
		if (!file_exists(DISCUZ_ROOT . "./data/sysdata/cache_himickey_floatad.php")) {
			require_once libfile('function/cache');
			$sql = "select * from " . DB::table('himickey_floatad') . " where inuse = 1";
			$datas = DB::fetch_all($sql);
			foreach($datas as &$data) {
				list($img_width, $img_height) = getimagesize($data['pic']);
				$data['w'] = $img_width;
				$data['h'] = $img_height;
			}
			unset($data);			
			$cacheArr = "\$datas = " . arrayeval($datas) . ";\n";
			writetocache("himickey_floatad", $cacheArr);
		}
		require_once DISCUZ_ROOT . "./data/sysdata/cache_himickey_floatad.php";		
		if(!$datas) {return;}

		$speed = $this->configs['speed'];
		include template('himickey_floatad:index');
		$this->return = $return;		
	}
}

class plugin_himickey_floatad_forum extends plugin_himickey_floatad {
	
	public function index_top() {
		
		if($this->configs['show_index']) {
			return $this->return;
		}
	}
	
	public function forumdisplay_top() {
		
		global $_G;
		if($this->configs['show_forumdisplay']) {
			if(in_array($_G['fid'], $this->configs['fids'])) {
				return $this->return;
			}
		}
	}
	
	public function viewthread_top() {
		
		global $_G;
		if($this->configs['show_viewthread']) {
			if(in_array($_G['fid'], $this->configs['fids'])) {
				return $this->return;
			}
		}
	}
}