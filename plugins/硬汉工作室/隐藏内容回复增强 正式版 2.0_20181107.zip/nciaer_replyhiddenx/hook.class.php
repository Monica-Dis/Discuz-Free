<?php
/**
 *   �������ݻظ���ǿ
 *
 *   Ӳ�������� ��Ȩ����
 *   ��ַ��dism.taobao.com
 *   QQ: 1069971363
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_replyhiddenx {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_replyhiddenx'];
    }

    public function discuzcode($params) {

        global $_G;

        if (!$this->config['on']) return;

        if (!in_array($_G['fid'], unserialize($this->config['fids']))) return;
        if (!in_array($_G['groupid'], unserialize($this->config['gids']))) return;

        $msglower = strtolower($params['param'][0]);
        if ($params['caller'] == 'discuzcode' && strpos($msglower, '[/hide]') !== FALSE) {
            $posts = DB::fetch_all('SELECT * FROM %t WHERE tid = %d and authorid = %d', array('forum_post', $_G['tid'], $_G['uid']));
            $hidden = TRUE;
            foreach ($posts as $post) {
                if ($post['invisible'] == 0) {
                    $hidden = FALSE;
                    break;
                }
            }
            if ($hidden) {
                $_G['discuzcodemessage'] = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply_hidden(), $params['param'][0]);
                $_G['discuzcodemessage'] = '<script>replyreload += \',\' + ' . $params['param'][12] . ';</script>' . $_G['discuzcodemessage'];
            }
        }

    }
}

class mobileplugin_nciaer_replyhiddenx extends plugin_nciaer_replyhiddenx {}