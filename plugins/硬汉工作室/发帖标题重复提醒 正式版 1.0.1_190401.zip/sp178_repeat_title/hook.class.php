<?php
/**
 *     ���������ظ�����
 *
 *   Ӳ�������� ��Ȩ����
 *   ��ַ��dism.taobao.com
 *   QQ: 1069971363
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_sp178_repeat_title {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['sp178_repeat_title'];
    }

    function post() {

        global $_G;

        if (!in_array($_G['fid'], dunserialize($this->config['fids']))) return;
        if (!in_array($_G['groupid'], dunserialize($this->config['gids']))) return;

        $tip_arr = explode(PHP_EOL, trim($this->config['tip']));
        $tip = $tip_arr[array_rand($tip_arr)];

        if ($_GET['action'] == 'newthread' && submitcheck('topicsubmit')) {
            $subject = daddslashes(trim($_GET['subject']));
            $rs = DB::fetch_first("SELECT * FROM %t WHERE subject = %s", array('forum_thread', $subject));
            if ($rs) {
                if ($this->config['notify_admin']) {
                    $data = array(
                        'uid' => $_G['uid'],
                        'subject' => $subject,
                        'author' => $_G['username'],
                        'dateline' => dgmdate($_G['timestamp']),
                        'forumname' => $_G['forum']['name'],
                    );
                    notification_add(1, 'system', $this->config['msg'], $data, 1);
                }
                showmessage($tip, '', 'error');
            }
        }
    }
}

class plugin_sp178_repeat_title_forum extends plugin_sp178_repeat_title {}

class mobileplugin_sp178_repeat_title_forum extends plugin_sp178_repeat_title {}
