<?php
/**
 *	 �����������η���
 *
 *   DisM!Ӧ���������� https://dism.Taobao.Com
 *   ��ַ��dism.taobao.com
 *   ���̵�ַ��https://DisM.taobao.com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_denyurl {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_denyurl'];
    }

    public function viewthread_nciaer_output() {

        global $_G, $postlist;

        if(!$this->config['on']) return;
        if(!in_array($_G['fid'], dunserialize($this->config['fids']))) return;

        $urls = explode(PHP_EOL, $this->config['urls']);
        $urls =  array_map('trim', $urls);
        $preg = '#<a href="(http|https)://([^"]*)"([^>]*)>(.*)</a>#iUs';
        foreach($postlist as $id => $post) {
            preg_match_all($preg, $post['message'], $arr);
            if(!empty($arr)) {
                foreach($arr[2] as $k => $url) {
                    $tmpurl = parse_url($arr[1][$k].'://'.$url, PHP_URL_HOST);
                    if(in_array($tmpurl, $urls)) {
                        $find = $arr[0][$k];
                        $replace = "<a href=\"javascript:alert('{$this->config['tip']}');\">" . $arr[4][$k] . "</a>";
                        $post['message'] = str_replace($find, $replace, $post['message']);
                        $postlist[$id] = $post;
                    }
                }
            }
        }
    }
}

class plugin_nciaer_denyurl_forum extends plugin_nciaer_denyurl {}
class mobileplugin_nciaer_denyurl_forum extends plugin_nciaer_denyurl {}
class plugin_nciaer_denyurl_group extends plugin_nciaer_denyurl {}
class mobileplugin_nciaer_denyurl_group extends plugin_nciaer_denyurl {}
