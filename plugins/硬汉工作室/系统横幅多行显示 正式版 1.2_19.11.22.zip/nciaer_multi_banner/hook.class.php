<?php
/**
 *     ϵͳ���������ʾ
 *
 *   Ĭ��ϵͳ�ļ���������ֻ�������ʾһ���������˲���󣬿���ȫ����ʾ����
 *
 *   Copyright 2001-2099 DisM!Ӧ������.
 *   From: DisM.taobao.Com
 *   DisM!�û�����Ⱥ: ��Ⱥ778390776
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_multi_banner {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_multi_banner'];
    }

    private function _ad($param) {

        global $_G;

        if(!$this->config['on']) return $param['content'];

        $params = $param['params'];
        loadcache('advs');
        $adids = array();
        $evalcode = &$_G['cache']['advs']['evalcode'][$params[0]];
        $parameters = &$_G['cache']['advs']['parameters'][$params[0]];
        $codes = &$_G['cache']['advs']['code'][$_G['basescript']][$params[0]];
        $fid = !empty($_G['fid']) ? $_G['fid'] : -1;
        if (!empty($codes)) {
            foreach ($codes as $adid => $code) {
                $parameter = &$parameters[$adid];
                if(!in_array($fid, $parameter['fids'])) continue;
                $checked = true;
                @eval($evalcode['check']);
                if ($checked) {
                    $adids[] = $adid;
                }
            }

            if($this->config['shuffle']) {
                shuffle($adids);
            }

            if (!empty($adids)) {
                $adcontent = '<div class = "wp ah">';
                foreach($adids as $id) {
                    $adcontent .= $codes[$id];
                }
                $adcontent .= '</div>';
            }
        }

        return $adcontent;
    }

    public function ad_headerbanner($param) {

        if(in_array(1, dunserialize($this->config['ads']))) {
            return $this->_ad($param);
        } else {
            return $param['content'];
        }
    }

    public function ad_subnavbanner($param) {

        if(in_array(2, dunserialize($this->config['ads']))) {
            return $this->_ad($param);
        } else {
            return $param['content'];
        }
    }

}

