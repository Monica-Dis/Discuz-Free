<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 *
 * ��ַ�� https://DisM.Taobao.Com/
 * QQ��1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://dism.taobao.com/?@56030.developer');