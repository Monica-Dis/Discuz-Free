<?php
/**
 * ��������ͼ����¼
 *
 * ��ַ�� http://dism.taobao.com
 * From: DisM.taobao.Com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_twsl {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['llx_twsl'];
    }

    public function viewthread_twsl_output() {

        global $_G, $thread, $metadescription;

        if (!in_array($_G['fid'], unserialize($this->config['fids']))) return;
        $tid = intval($thread['tid']);
        $imgs = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'tid', $tid, 'aid asc', true, false, false, 1);
        if (!empty($imgs)) {
            $img = current($imgs);
            $img = !empty($this->config['ossurl']) ? $this->config['ossurl'].'forum/'.$img['attachment'] : $_G['siteurl'].$_G['setting']['attachurl'].'forum/' . $img['attachment'];
        } else {
            $img = $this->config['img'];
        }
        $pubdate = date("Y-m-d H:i", $thread['dateline']);
        $forum_type = $this->config['forum_type'];
        $meta = <<<EOF
<meta property="og:type" content="{$forum_type}"/>
<meta property="og:image" content="{$img}"/>
<meta property="og:release_date" content="{$pubdate}"/>
<meta property="og:title" content="{$thread['subject']}"/>
<meta property="og:description" content="{$metadescription}"/>
<meta property="og:author" content="{$thread['author']}"/>
<meta property="og:{$forum_type}:replay" content="{$thread['replies']}"/>
EOF;
        $_G['setting']['seohead'] .= $meta;
    }

    public function view_nciaer_output() {

        global $_G, $article, $content, $metadescription;;

        $text = $content['content'];

        $pattern = '/<img.*?src=[\"|\']?(.*?)[\"|\']?\s.*?>/i';
        preg_match_all($pattern, $text, $imgs);
        if ($imgs[1][0]) {
            $img = $imgs[1][0];
        } else {
            $img = $this->config['img'];
        }
        $pubdate = date("Y-m-d H:i", $article['timestamp']);
        $portal_type = $this->config['portal_type'];
        $meta = <<<EOF
<meta property="og:type" content="{$portal_type}"/>
<meta property="og:image" content="{$img}"/>
<meta property="og:release_date" content="{$pubdate}"/>
<meta property="og:title" content="{$article['title']}"/>
<meta property="og:description" content="{$metadescription}"/>
EOF;
        $_G['setting']['seohead'] .= $meta;

    }
}

class plugin_llx_twsl_forum extends plugin_llx_twsl {}
class mobileplugin_llx_twsl_forum extends plugin_llx_twsl {}

class plugin_llx_twsl_portal extends plugin_llx_twsl {}
class mobileplugin_llx_twsl_portal extends plugin_llx_twsl {}

