<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';

$tid = intval($_GET['tid']);
if(empty($tid)) {
	showmessage(lang('plugin/llx_mreport', 'tid_error'));
}

if(submitcheck('reportsubmit')) {
	
	$url = "forum.php?mod=viewthread&tid={$tid}";
	$urlkey = md5($url);
	$message = censor(cutstr(dhtmlspecialchars(trim($_GET['message'])), 200, ''));
	$message = $_G['username'].'&nbsp;:&nbsp;'.rtrim($message, "\\");
	if($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		C::t('common_report')->update_num($reportid, $message);
	} else {
		$data = array('url' => $url, 'urlkey' => $urlkey, 'uid' => $_G['uid'], 'username' => $_G['username'], 'message' => $message, 'dateline' => TIMESTAMP);
		C::t('common_report')->insert($data);
		$report_receive = unserialize($_G['setting']['report_receive']);
		$moderators = array();
		if($report_receive['adminuser']) {
			foreach($report_receive['adminuser'] as $touid) {
				notification_add($touid, 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
			}
		}
	}
	
	$config = $_G['cache']['plugin']['llx_mreport'];
	if($config['mail']) {
        $msg = str_replace(array('{url}', '{time}', '{message}'), array($_G['siteurl'] . $url, date('Y-m-d H:i:s'), $message), $config['msg']);
        include_once libfile("function/mail");
        sendmail($config['mail'], $config['title'], $msg);
    }
	
	showmessage('report_succeed', $url, array(), array('closetime' => true, 'showdialog' => 1, 'alert' => 'right'));
}
require_once libfile('function/misc');
include template('llx_mreport:index');