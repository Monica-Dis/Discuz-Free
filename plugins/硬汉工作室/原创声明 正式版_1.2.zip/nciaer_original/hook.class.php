<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * �ͷ�DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_original {

    public function __construct() {

        global $_G;
        $this->config = $_G['cache']['plugin']['nciaer_original'];
    }

    public function viewthread_nciaer_output() {

        global $_G, $thread, $postlist;

        foreach ($postlist as $k => $v) {
            if ($v['first']) {
                if($this->config['all']) {
                    if (in_array($_G["fid"], unserialize($this->config['fids']))) {
                        $original_text = str_replace('{author}', $v['author'], $this->config['original_text']);
                    } else {
                        $original_text = '';
                    }
                } else {
                    $original_text = DB::result_first('select original_text from %t where tid = %d', array('nciaer_original', $thread['tid']));
                }
                if ($original_text) {
                    $url = '';
                    if ($this->config['showurl']) {
                        if (in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                            $url = '<br />'.$_G['siteurl'] . rewriteoutput('forum_viewthread', 1, '', $thread['tid'], 1, '');
                        } else {
                            $url = '<br />'.$_G['siteurl'] . "forum.php?mod=viewthread&tid={$thread['tid']}";
                        }
                    }
                    $return = '';
                    require template('nciaer_original:original');
                    if ($this->config['show_position'] == 1) {
                        $postlist[$k]['message'] = $return . $v['message'];
                    } else {
                        $postlist[$k]['message'] .= $return;
                    }
                }

            }
        }
    }

    function post_message($params) {

        global $_G, $isfirstpost;

        if (!in_array($_G["fid"], unserialize($this->config['fids']))) return;
        if (!in_array($_G["groupid"], unserialize($this->config['gids']))) return;

        $param = $params["param"];
        $tid = $param[2]["tid"];
        $sql = "select tid from %t where tid = %d";
        $hastid = DB::fetch_first($sql, array('nciaer_original', $tid));

        if ($_GET['action'] == 'newthread' && $param[0] == 'post_newthread_succeed') {

            if ($_GET["nciaer_original"] && $_GET["original_text"]) {

                $original_text = daddslashes(dhtmlspecialchars($_GET["original_text"]));
                if (!$hastid) {
                    DB::query("insert into " . DB::table('nciaer_original') . " (tid, original_text) values('{$tid}', '{$original_text}')");
                }
            }
        } elseif ($_GET['action'] == 'edit' && $param[0] == 'post_edit_succeed' && $isfirstpost) {

            if (!$_GET['nciaer_original']) {
                DB::delete('nciaer_original', "tid = '{$tid}'");
                C::t('forum_thread')->update($tid, array('stamp' => -1, 'icon' => -1));
            } elseif ($_GET["nciaer_original"] && $_GET["original_text"]) {
                $original_text = daddslashes(dhtmlspecialchars($_GET["original_text"]));
                if (!$hastid) {
                    DB::query("insert into " . DB::table('nciaer_original') . " (tid, original_text) values('{$tid}', '{$original_text}')");
                }
            }
        }
    }

    public function post_middle_output() {

        global $_G, $isfirstpost;
        $check = '';
        $username = $_G['username'];
        if (!in_array($_G["fid"], unserialize($this->config['fids'])) || !in_array($_G["groupid"], unserialize($this->config['gids']))) {
            return;
        }

        if ($_GET["action"] == "newthread") {

            $original_text = $this->config['original_text'];
            $original_text = str_replace('{author}', $username, $original_text);
            include template("nciaer_original:index");
            return $return;
        } elseif ($_GET["action"] == "edit" && $isfirstpost) {

            $sql = "select original_text from " . DB::table('nciaer_original') . " where tid = '{$_G['tid']}'";
            $original_text = DB::result_first($sql);

            if ($original_text) {
                $check = "checked = 'checked'";
            } else {
                $original_text = $this->config['original_text'];
                $original_text = str_replace('{author}', $username, $original_text);
            }

            include template("nciaer_original:index");
            return $return;
        }
    }
}

class plugin_nciaer_original_forum extends plugin_nciaer_original {
}

class mobileplugin_nciaer_original_forum extends plugin_nciaer_original {

    public function post_bottom_mobile_output() {

        return $this->post_middle_output();
    }
}
