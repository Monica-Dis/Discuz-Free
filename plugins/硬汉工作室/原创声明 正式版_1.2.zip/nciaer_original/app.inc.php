<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 *
 * ��ַ�� http://dism.taobao.com
 * DisM.Taobao.Com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://dism.taobao.com/?@56030.developer');