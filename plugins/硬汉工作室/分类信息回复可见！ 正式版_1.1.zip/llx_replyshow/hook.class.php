<?php
/**
 * ������Ϣ�ظ��ɼ�
 *
 *   ������ҵ���/ģ������ ����DisM!Ӧ������
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_replyshow {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['llx_replyshow'];
		$this->config['fields'] = explode('|', trim($this->config['fields']));
	}

	public function viewthread_top_output() {

	    global $_G;

        if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
        if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;

	    return "<script>replyreload += ',' + {$_G['forum_firstpid']};</script>";
    }
	public function viewthread_llx_output() {
			
		global $_G, $threadsort, $threadsortshow, $thread;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;

		if($threadsort && $threadsortshow && is_array($threadsortshow['optionlist'])) {
			$_post = C::t('forum_post')->fetch('tid:'.$thread['tid'], $_G['forum_firstpid']);
			$authorreplyexist = $_post['tid'] == $thread['tid'] ? C::t('forum_post')->fetch_pid_by_tid_authorid($thread['tid'], $_G['uid']) : FALSE;
			if($authorreplyexist) return;
			foreach($threadsortshow['optionlist'] as $k=>&$sort) {
				if(in_array($k, $this->config['fields'])) {
					$sort['value'] = $this->config['tip'];
				}
			}
		}
	}
}

class plugin_llx_replyshow_forum extends plugin_llx_replyshow {}

class mobileplugin_llx_replyshow_forum extends plugin_llx_replyshow {}