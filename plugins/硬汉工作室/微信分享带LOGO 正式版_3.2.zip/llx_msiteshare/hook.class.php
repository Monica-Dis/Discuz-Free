<?php
/**
 * ΢�ŷ�����LOGO
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   QQ: DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_msiteshare {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['llx_msiteshare'];
    }

    public function fetchsign($desc, $logo) {

        require_once "source/plugin/llx_msiteshare/jssdk.php";
        $jssdk = new WeiXinShare($this->config['appid'], $this->config['appsecret'], 6000);
        $signPackage = $jssdk->GetSignPackage();
        include template('llx_msiteshare:index');
        return $return;
    }
}

class plugin_llx_msiteshare_forum extends plugin_llx_msiteshare {

    public function index_top_output() {

        global $metadescription;

        if(!$this->config['adaption']) return '';

        $logo = $this->config['logo'];
        if ($this->config['default']) {
            $desc = $this->config['desc'];
        } else {
            $desc = cutstr($metadescription, $this->config['len']);
        }

        return $this->fetchsign($desc, $logo);
    }

    public function forumdisplay_top_output() {

        global $_G, $metadescription;

        if(!$this->config['adaption']) return '';

        $logo = $this->config['logo'];
        if ($this->config['default']) {
            $desc = $this->config['desc'];
        } else {
            $desc = cutstr($metadescription, $this->config['len']);
        }

        return $this->fetchsign($desc, $logo);
    }

    public function viewthread_top_output() {

        global $_G, $postlist, $thread, $metadescription;

        if(!$this->config['adaption']) return '';

        $tid = intval($thread['tid']);
        $imgs = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'tid', $tid, 'aid asc', true, false, false, 1);
        if (!empty($imgs)) {
            $img = current($imgs);
            $logo = !empty($this->config['ossurl']) ? $this->config['ossurl'] . $img['attachment'] : $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/' . $img['attachment'];
        } else {
            $logo = $this->config['logo'];
        }

        $desc = cutstr($metadescription, $this->config['len']);

        return $this->fetchsign($desc, $logo);
    }
}

// mobile
class mobileplugin_llx_msiteshare_forum extends plugin_llx_msiteshare {

    public function index_top_mobile_output() {

        global $metadescription;

        $logo = $this->config['logo'];
        if ($this->config['default']) {
            $desc = $this->config['desc'];
        } else {
            $desc = cutstr($metadescription, $this->config['len']);
        }

        return $this->fetchsign($desc, $logo);
    }

    public function forumdisplay_top_mobile_output() {

        global $_G, $metadescription;

        $logo = $this->config['logo'];
        if ($this->config['default']) {
            $desc = $this->config['desc'];
        } else {
            $desc = cutstr($metadescription, $this->config['len']);
        }

        return $this->fetchsign($desc, $logo);
    }

    public function viewthread_top_mobile_output() {

        global $_G, $postlist, $thread, $metadescription;

        $tid = intval($thread['tid']);
        $imgs = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'tid', $tid, 'aid asc', true, false, false, 1);
        if (!empty($imgs)) {
            $img = current($imgs);
            $logo = !empty($this->config['ossurl']) ? $this->config['ossurl'] . $img['attachment'] : $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/' . $img['attachment'];
        } else {
            $logo = $this->config['logo'];
        }

        $desc = cutstr($metadescription, $this->config['len']);

        return $this->fetchsign($desc, $logo);
    }
}

class mobileplugin_llx_msiteshare_portal extends plugin_llx_msiteshare {

    public function view_article_top_mobile_output() {

        global $article;

        if(!empty($article['pic'])) {
            return $this->fetchsign($article['summary'], $article['pic']);
        }
    }
}