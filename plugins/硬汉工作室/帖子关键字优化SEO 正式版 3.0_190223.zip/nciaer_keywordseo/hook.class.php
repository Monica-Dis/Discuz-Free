<?php
/**
 *   ���ӹؼ����Ż�SEO
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   QQ: DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_keywordseo {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_keywordseo'];
    }

    public function viewthread_nciaer_output() {

        global $_G, $metakeywords, $postlist;

        if($_G['forum']['status'] != 3) {
            if (!in_array($_G['fid'], unserialize($this->config['fids']))) return;
        }

        $keyword = '';
        foreach ($postlist as $post) {
            if ($post['first']) {
                if ($post['tags']) {
                    foreach ($post['tags'] as $tag) {
                        $keyword .= ", " . dhtmlspecialchars($tag[1]);
                    }
                }
            }
        }

        if ($this->config['extra_forumname']) {
            $keyword .= ", " . dhtmlspecialchars($_G['forum']['name']);
        }
        if ($this->config['extra_keyword']) {
            $keyword .= ", " . dhtmlspecialchars($this->config['extra_keyword']);
        }

        $metakeywords .= $keyword;
    }
}

class plugin_nciaer_keywordseo_forum extends plugin_nciaer_keywordseo {}

class plugin_nciaer_keywordseo_group extends plugin_nciaer_keywordseo {}

class mobileplugin_nciaer_keywordseo_forum extends plugin_nciaer_keywordseo {}

class mobileplugin_nciaer_keywordseo_group extends plugin_nciaer_keywordseo {}