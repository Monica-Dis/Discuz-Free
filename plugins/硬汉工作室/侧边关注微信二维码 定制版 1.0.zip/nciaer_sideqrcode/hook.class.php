<?php
/**
 *	 ��߹�ע΢�Ŷ�ά��
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com 
 *   ��ַ��dism.taobao.com
 *   QQ: DISM.TAOBAO.COM
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_sideqrcode {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_sideqrcode'];
	}
}

class mobileplugin_nciaer_sideqrcode extends plugin_nciaer_sideqrcode {

    public function global_footer_mobile() {

        if(!$this->config['on']) return '';
        if($this->config['wxshow'] && (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') === false)) return '';
        include template('nciaer_sideqrcode:index');

        return $return;
    }
}