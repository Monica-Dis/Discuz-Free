<?php
/**
 *	 ����ر���ǿ
 *
 *   DisM!Ӧ������ dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   QQ: http://t.cn/Aiux1Jx1
 *
 *
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_threadcloseextra {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_threadcloseextra'];
	}
	
	public function viewthread_nciaer_output() {
		
		global $_G, $thread;

		if($this->config['robot_on'] && IS_ROBOT) return;

		if(!in_array($_G['fid'], dunserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		if($this->config['author_on'] && $thread['authorid'] == $_G['uid']) return;
		if($_G['forum_thread']['closed'] || checkautoclose($thread)) {
			showmessage($this->config['tip']);
		}
	}
}

class plugin_nciaer_threadcloseextra_forum extends plugin_nciaer_threadcloseextra {}

class mobileplugin_nciaer_threadcloseextra_forum extends plugin_nciaer_threadcloseextra {}