<?php
/**
 * ���κ��������¼��������
 * http://dism.Taobao.com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_himickey_bottombanner {
	
	public function global_footer() {
		
		global $_G;
		$configs = $_G['cache']['plugin']['himickey_bottombanner'];
		if($configs['show_visitor'] && $_G['uid']) return;
		$msg = explode(PHP_EOL, trim($configs['msg']));
		$msg_arr = array();
		foreach ($msg as $v) {
			$tmp = $tmp2 = array();
			$tmp = explode('|', trim($v));
			$tmp2['title'] = $tmp[0];
			$tmp2['url'] = $tmp[1];
			$msg_arr[] = $tmp2;
		}
		include template('himickey_bottombanner:index');
		return $return;
	}
}