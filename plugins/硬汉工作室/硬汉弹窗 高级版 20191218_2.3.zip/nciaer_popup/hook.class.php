<?php
/**
 *	 Ӳ������
 *
 *   From: Dism��taobao��com
 *   ��ַ��http://t.cn/Aiux1Qh0
 *   Ӧ�ø���֧�֣�https://dism.taobao.com
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_popup {

    public $config = array();
    public $msg = '';

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_popup'];

        $cachefile = DISCUZ_ROOT.'./data/sysdata/cache_nciaer_popup.php';
        if(@file_exists($cachefile)) {
            require_once $cachefile;
            foreach($msgs as $v) {
                if(in_array($_G['groupid'], dunserialize($v['gids']))) {
                    $this->msg = $v['msg'];
                    break;
                }
            }
        }

        if(empty($this->msg)) {
            $this->msg = $this->config['content'];
        }
    }

    public function global_footer() {

        if(!$this->config['on']) return '';
        if(!$this->msg) return '';

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT . CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showpage']);
        if (!in_array('all', $showvalue)) {
            if (!in_array($showkey, $showvalue)) return '';
        }
        list($width, $height) = explode(':', trim($this->config['size']));
        include template('nciaer_popup:popup');
        return $return;
    }
}

class mobileplugin_nciaer_popup extends plugin_nciaer_popup {

    public function global_footer_mobile() {

        if(!$this->config['on']) return '';
        if(!$this->msg) return '';

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT . CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showpage']);
        if (!in_array('all', $showvalue)) {
            if (!in_array($showkey, $showvalue)) return '';
        }

        $time = $this->config['closetime'] / 1000;
        include template('nciaer_popup:popup');
        return $return;
    }
}
