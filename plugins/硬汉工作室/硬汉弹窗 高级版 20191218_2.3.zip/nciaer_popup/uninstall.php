<?php
/**
 * From: Dism��taobao��com
 *
 * ��ַ�� http://http://t.cn/Aiux1Qh0
 * ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
	drop table if exists `pre_nciaer_popup`;
EOF;
runquery($sql);

$finish = TRUE;
