<?php
/**
 * From: Dism��taobao��com
 *
 * ��ַ�� http://http://t.cn/Aiux1Qh0
 * ���²����http://t.cn/Aiux1Jx1
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:http://http://t.cn/Aiux1Qh0/plugin.php?id=nciaer_feedback&plugin='.$plugin['identifier']);