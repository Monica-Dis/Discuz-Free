<?php
/**
 * From: Dism��taobao��com
 *
 * ��ַ�� http://http://t.cn/Aiux1Qh0
 * ���²����http://t.cn/Aiux1Jx1
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once libfile('function/forumlist');
include libfile('common', 'plugin/nciaer_popup');
$operation = $_GET['op'] ? $_GET['op'] : '';
$purl = "action=plugins&operation=config&do={$do}&identifier=nciaer_popup&pmod=admin";
if (empty($operation)) {
    if (!submitcheck('dosubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_popup&pmod=admin");
        showtableheader(dlang('list'));
        showsubtitle(array('del', dlang('groupname'), dlang('msg'), 'dateline', ''));

        $navlist = C::t('#nciaer_popup#db')->fetch_all_by_displayorder(TRUE);
        foreach ($navlist as $nav) {
            $groups = DB::fetch_all('select grouptitle from %t where groupid in(%n)', array('common_usergroup', dunserialize($nav['gids'])));
            $grouparr = array();
            foreach($groups as $group) {
                $grouparr[] = $group['grouptitle'];
            }
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\" >",
                join(', ', $grouparr),
                cutstr($nav['msg'], 80),
                dgmdate($nav['dateline'], 'Y-n-j H:i'),
                "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do={$do}&identifier=nciaer_popup&pmod=admin&op=edit&nid={$nav['id']}\" >$lang[edit]</a>"
            ));
        }
        showsubmit('dosubmit', 'submit', 'select_all', "<a href='" . ADMINSCRIPT . "?{$purl}&op=add'>" . dlang('add') . "</a>");
        showtablefooter();
        showformfooter();

    } else {
        if (is_array($_GET['delete'])) {
            C::t('#nciaer_popup#db')->delete_by_id($_GET['delete']);
        }
        dcache();
        cpmsg(dlang('success'), $purl, 'succeed');
    }

} elseif ($operation == 'add') {
    if (!submitcheck('dosubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_popup&pmod=admin&op=add", 'enctype');
        showtableheader(dlang('add'));
        $var = array();
        $var['variable'] = 'groups';
        $var['value'] = array();
        $var['type'] = '<select name="' . $var['variable'] . '[]" size="10" multiple="multiple"><option value=""' . (@in_array('', $var['value']) ? ' selected' : '') . '>' . cplang('plugins_empty') . '</option>';
        $var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);

        $query = C::t('common_usergroup')->range_orderby_credit();
        $groupselect = array();
        foreach ($query as $group) {
            $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
            $groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '"' . (@in_array($group['groupid'], $var['value']) ? ' selected' : '') . '>' . $group['grouptitle'] . '</option>';
        }
        $var['type'] .= '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' .
            ($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') .
            ($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') .
            '<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup></select>';

        showsetting(dlang('groupname'), '', '', $var['type'], '', 0, dlang('tip'));
        showsetting(dlang('msg'), 'msg', '', 'textarea');
        showsubmit('dosubmit');
        showtablefooter();
        showformfooter();

    } else {
        $msg = addslashes(trim($_GET['msg']));
        $groups = $_GET['groups'];
        if (empty($msg) || (count($groups) == 1 && $groups[0] == '')) {
            cpmsg(dlang('field_error'), '', 'error');
        }

        $data = array(
            'gids' => serialize($groups),
            'msg' => $msg,
            'dateline' => TIMESTAMP,
        );
        C::t('#nciaer_popup#db')->insert($data);
        dcache();
        cpmsg(dlang('success'), $purl, 'succeed');
    }

} elseif ($operation == 'edit' && $_GET['nid']) {
    $nav = C::t('#nciaer_popup#db')->fetch($_GET['nid']);
    if (!$nav) {
        cpmsg(dlang('data_error'), $purl, 'error');
    }

    if (!submitcheck('editsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_popup&pmod=admin&op=edit&nid={$_GET['nid']}", 'enctype');
        showtableheader();
        showtitle(dlang('edit'));
        $var = array();
        $var['variable'] = 'groups';
        $var['value'] = dunserialize($nav['gids']);
        $var['type'] = '<select name="' . $var['variable'] . '[]" size="10" multiple="multiple"><option value=""' . (@in_array('', $var['value']) ? ' selected' : '') . '>' . cplang('plugins_empty') . '</option>';
        $var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);

        $query = C::t('common_usergroup')->range_orderby_credit();
        $groupselect = array();
        foreach ($query as $group) {
            $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
            $groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '"' . (@in_array($group['groupid'], $var['value']) ? ' selected' : '') . '>' . $group['grouptitle'] . '</option>';
        }
        $var['type'] .= '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' .
            ($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') .
            ($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') .
            '<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup></select>';

        showsetting(dlang('groupname'), '', '', $var['type']);
        showsetting(dlang('msg'), 'msg', $nav['msg'], 'textarea');
        showsubmit('editsubmit');
        showtablefooter();
        showformfooter();
    } else {
        $msg = addslashes(trim($_GET['msg']));
        $groups = $_GET['groups'];
        if (empty($msg) || (count($groups) == 1 && $groups[0] == '')) {
            cpmsg(dlang('field_error'), '', 'error');
        }

        C::t('#nciaer_popup#db')->update_by_id($_GET['nid'], array(
            'gids' => serialize($groups),
            'msg' => $msg,
            'dateline' => TIMESTAMP,
        ));
        dcache();
        cpmsg(dlang('success'), $purl, 'succeed');
    }
}


