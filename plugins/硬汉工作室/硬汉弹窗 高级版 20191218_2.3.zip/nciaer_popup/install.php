<?php
/**
 * From: Dism��taobao��com
 *
 * ��ַ�� http://http://t.cn/Aiux1Qh0
 * ���²����http://t.cn/Aiux1Jx1
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
   create table if not exists `pre_nciaer_popup` (
	  `id` int(11) not null auto_increment primary key,
	  `gids` varchar(500) not null default '',
	  `msg` varchar(500) not null default '',
	  `dateline` int not null default 0
   ) engine=myisam;
EOF;
runquery($sql);

$finish = TRUE;
