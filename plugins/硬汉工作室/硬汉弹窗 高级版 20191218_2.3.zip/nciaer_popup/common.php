<?php
/**
 * From: Dism��taobao��com
 * 2018/11/5
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function dlang($lang) {
    return lang('plugin/nciaer_popup', $lang);
}

function dcache() {

    global $_G;

    require_once libfile('function/cache');
    $ads = C::t('#nciaer_popup#db')->fetch_all_by_displayorder();
    $cacheArr = "\$msgs = " . arrayeval($ads) . ";\n";
    writetocache("nciaer_popup", $cacheArr);
}
