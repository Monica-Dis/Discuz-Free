<?php
/**
 * zzb7taobao_copyright For Discuz!X 3.4+
 * ============================================================================
 * ����Դ��Դ�������ռ�,��������ѧϰ�о����ͣ�����������ҵ��;����������24Сʱ��ɾ��!
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    zzb7taobao_copyright
 * @module	   WWW.Zzb7.net
 * @date	   2019-10-15
 * @author	   վ����
 * @copyright  Copyright (c) 2019 Zzb7.Taobao.COm. (http://t.cn/AiujrsHR)
 */

/*
//--------------Tall us what you think!----------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_suggestlog {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_suggestlog'];
    }

    public function fetchdata() {

        global $_G;

        if (!$this->config['on']) return;
        if (!in_array($_G['fid'], dunserialize($this->config['fids2']))) return;

        $threadlist = array();
        if (!$_G['inajax'] && $_G['page'] == 1) {
            $cachefile = DISCUZ_ROOT . './data/sysdata/cache_nciaer_suggestlog.php';
            if (@file_exists($cachefile) && TIMESTAMP - intval(filemtime($cachefile)) <= $this->config['cachetime']) {
                require_once $cachefile;
            } else {
                $fidsarr = dunserialize($this->config['fids']);
                $num = intval($this->config['num']);
                $showtype = intval($this->config['showtype']);
                $threadlist = C::t('#nciaer_suggestlog#suggestlog')->fetch_all($fidsarr, $showtype, $num);
                require_once libfile('function/cache');
                $cacheArr = "\$threadlist = " . arrayeval($threadlist) . ";\n";
                writetocache("nciaer_suggestlog", $cacheArr);
            }

            foreach ($threadlist as $k => $thread) {
                if (!empty($_G['setting']['rewriterule']['forum_viewthread']) && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                    $returnurl = rewriteoutput('forum_viewthread', 1, '', $thread['tid'], 1, '', '');
                } else {
                    $returnurl = "forum.php?mod=viewthread&tid={$thread['tid']}";
                }
                $threadlist[$k]['url'] = $returnurl;
            }
        }

        return $threadlist;
    }
}

class plugin_nciaer_suggestlog_forum extends plugin_nciaer_suggestlog {

    function viewthread_postbottom_output() {

        $return = '';
        $threadlist = array();
        $threadlist = $this->fetchdata();
        $style = intval($this->config['style']);
        if($threadlist) {
            include template('nciaer_suggestlog:list');
        }
        return array($return);
    }

}

