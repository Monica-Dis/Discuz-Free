<?php
/**
 * [zzb7taobao!] (C)2009-2019 Www.Zzb7.Net.
 *
 * ��ַ�� http://zZb7.TaoBao.com
 * QQ��1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('location:http://Zzb7.Taobao.Com/?@56030.developer');