<?php
/**
 * [zzb7taobao!] (C)2009-2019 Www.Zzb7.Net.
 * 2018/11/6
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_suggestlog extends discuz_table {

    public function __construct() {

        $this->_table = 'forum_thread';
        $this->_pk = 'tid';

        parent::__construct();
    }

    public function fetch_all($fidsarr, $showtype, $num) {

        $type = '';
        switch ($showtype) {
            case 1:
                $type = 'dateline';
                break;
            case 2:
                $type = 'lastpost';
                break;
            case 3:
                $type = 'views';
                break;
            case 4:
                $type = 'replies';
                break;
            default:
                $type = 'dateline';
        }
        $threads = DB::fetch_all("SELECT * FROM %t WHERE fid in(%n) AND displayorder >=0 ORDER BY %i DESC LIMIT %d", array($this->_table, $fidsarr, $type, $num));

        $_G['forum_colorarray'] = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');

        $threadlist = array();
        foreach ($threads as $thread) {
            $thread['subject'] = dhtmlspecialchars($thread['subject']);
            if (@file_exists('source/plugin/nciaer_suggestlog/extend/extend_highlight.php')) {
                include 'source/plugin/nciaer_suggestlog/extend/extend_highlight.php';
            } else {
                $thread['highlight'] = '';
            }

            $threadlist[] = $thread;
        }

        return $threadlist;
    }
}
