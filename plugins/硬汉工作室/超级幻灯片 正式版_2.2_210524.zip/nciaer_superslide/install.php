<?php
/*
 * qq: 1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied!');
}

$sql = <<<EOF
create table if not exists `pre_nciaer_superslide` (
  `id` int not null auto_increment primary key,
  `title` varchar(200) not null,
  `img_url` varchar(200) not null,
  `client` tinyint not null default 0,
  `url` varchar(200) not null,
  `displayorder` tinyint not null default 0,
  `available` tinyint not null default 0,
  `dateline` int not null
)engine=myisam
EOF;
runquery($sql);
$finish = TRUE;
