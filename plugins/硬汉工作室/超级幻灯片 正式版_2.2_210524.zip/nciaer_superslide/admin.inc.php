<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$operation = $_GET['op'] ? $_GET['op'] : '';
$purl = "action=plugins&operation=config&do={$do}&identifier=nciaer_superslide&pmod=admin";

if(empty($operation)) {
    if(!submitcheck('navsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_superslide&pmod=admin");
        showtableheader(L('navlist'));
        showsubtitle(array('del', 'display_order', L('available'), 'subject', L('client'), L('banner'), 'url', 'dateline', ''));

        $navlist = C::t('#nciaer_superslide#superslide')->fetch_all_by_displayorder();
        foreach ($navlist as $nav) {
            $checked = !empty($nav['available']) ? "checked = 'true'":'';
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\" >",
                "<input type=\"text\" class=\"txt\" name=\"displayordernew[{$nav['id']}]\" value=\"$nav[displayorder]\" size=\"2\">",
                "<input {$checked} type = 'checkbox' name = 'available[{$nav['id']}]' value = '1' />",
                $nav['title'],
                !empty($nav['client']) ? L('mobile') : 'PC',
                "<img src = '{$nav['img_url']}' width = '150px' height = '50px'/>",
                $nav['url'],
                dgmdate($nav['dateline'], 'Y-n-j H:i'),
                "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$do}&identifier=nciaer_superslide&pmod=admin&op=edit&nid={$nav['id']}\" >$lang[edit]</a>"
            ));
        }
        showsubmit('navsubmit', 'submit', 'select_all', "<a href='".ADMINSCRIPT."?{$purl}&op=add'>".L('add')."</a>");
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

    } else {
        if(is_array($_GET['delete'])) {
            C::t('#nciaer_superslide#superslide')->delete_by_id($_GET['delete']);
        }

        DB::update('nciaer_superslide', array('available' => 0));

        if(is_array($_GET['displayordernew'])) {
            foreach($_GET['displayordernew'] as $id => $displayorder) {
                C::t('#nciaer_superslide#superslide')->update_displayorder_by_id($id, $displayorder);
            }
        }

        if(is_array($_GET['available'])) {
            foreach($_GET['available'] as $id => $a) {
                C::t('#nciaer_superslide#superslide')->update_available_by_id($id, $a);
            }
        }
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'add') {
    if(!submitcheck('addsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_superslide&pmod=admin&op=add", 'enctype');
        showtableheader(L('banner_add'));
        showsetting(L('title'), 'title', '', 'text');
        $client = array('client',
            array(
                array(0, 'PC'),
                array(1, L('mobile')),
            )
        );
        showsetting(L('client'), $client, '', 'select');
        showsetting(L('url'), 'url', '', 'text');
        showsetting(L('banner'), 'img_url', '', 'filetext');
        showsubmit('addsubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/

    } else {
        $title = trim($_GET['title']);
        $client = intval($_GET['client']);
        $url = trim($_GET['url']);
        if(!$title || !$url || (!$_FILES['img_url']['name'] && !$_GET['img_url'])) {
            cpmsg(L('field_error'), '', 'error');
        }
        if($_FILES['img_url']) {
            $upload = new discuz_upload();
            if($upload->init($_FILES['img_url'], 'common') && $upload->save(1)) {
                $pic = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $pic = trim($_GET['img_url']);
        }

        $data = array(
            'title' => $title,
            'client' => $client,
            'available' => 1,
            'img_url' => $pic,
            'url' => $url,
            'dateline' => TIMESTAMP,
        );
        C::t('#nciaer_superslide#superslide')->insert($data);
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }

} elseif($operation == 'edit' && $_GET['nid']) {
    $nav = C::t('#nciaer_superslide#superslide')->fetch($_GET['nid']);
    if(!$nav) {
        cpmsg(L('data_error'), $purl, 'error');
    }

    if(!submitcheck('editsubmit')) {
        showformheader("plugins&operation=config&do={$do}&identifier=nciaer_superslide&pmod=admin&op=edit&nid={$_GET['nid']}", 'enctype');
        showtableheader();
        showtitle(L('navedit'));
        showsetting(L('title'), 'title', $nav['title'], 'text');
        $client = array('client',
            array(
                array(0, 'PC'),
                array(1, L('mobile')),
            )
        );
        showsetting(L('client'), $client, $nav['client'], 'select');
        showsetting(L('url'), 'url', $nav['url'], 'text');
        showsetting(L('banner'), 'img_url', $nav['img_url'], 'filetext');
        showsubmit('editsubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
    } else {
        $title = trim($_GET['title']);
        $url = trim($_GET['url']);
        $client = intval($_GET['client']);
        if(!$title || !$url || (!$_FILES['img_url']['name'] && !$_GET['img_url'])) {
            cpmsg(L('field_error'), '', 'error');
        }

        if($_FILES['img_url']) {
            $upload = new discuz_upload();
            if($upload->init($_FILES['img_url'], 'common') && $upload->save(1)) {
                $pic = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
                @unlink(str_replace($_G['siteurl'], '', $nav['img_url']));
            }
        } else {
            $pic = trim($_GET['img_url']);
        }

        C::t('#nciaer_superslide#superslide')->update_by_id($_GET['nid'], array(
            'title' => $title,
            'client' => $client,
            'img_url' => $pic,
            'url' => $url,
            'dateline' => TIMESTAMP,
        ));
        _cache();
        cpmsg(L('success'), $purl, 'succeed');
    }
}

function L($lang) {
    return lang('plugin/nciaer_superslide', $lang);
}

function _cache() {

    global $_G;
    require_once libfile('function/cache');
    $banners = C::t('#nciaer_superslide#superslide')->fetch_all_by_available();
    $cacheArr = "\$slides = " . arrayeval($banners) . ";\n";
    writetocache("nciaer_superslide", $cacheArr);
}