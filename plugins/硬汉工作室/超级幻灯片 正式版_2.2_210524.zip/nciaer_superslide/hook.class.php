<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_nciaer_superslide {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_superslide'];
    }
	function global_header(){
		
		global $_G;

		if(!$this->config['on']) return '';

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT.CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showpage']);
        if(!in_array('all', $showvalue)) {
            if(!in_array($showkey, $showvalue)) return '';
        }

        $speed = intval($this->config['speed']);
		$showSeconds = intval($this->config['showSeconds']);
        $slides = $this->fetchdata(0);
		list($width, $height) = explode(':', trim($this->config['size']));
        $top = intval($height/2 - 50);
		switch(intval($this->config['turnStyle'])) {
			case 1:
				$turnStyle = "fade";
				break;
			case 2:
				$turnStyle = "zoom";
				break;
			case 3:
				$turnStyle = "shuffle";
				break;
		}
		$return = '';
		include template('nciaer_superslide:slide');
		return count($slides) > 0 ? $return : "";
	}

	public function fetchdata($client = 0) {

        if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_superslide.php")) {
            require_once DISCUZ_ROOT . "./data/sysdata/cache_nciaer_superslide.php";
        } else {
            $slides = C::t('#nciaer_superslide#superslide')->fetch_all_by_available();
            $cacheArr = "\$slides = " . arrayeval($slides) . ";\n";
            writetocache("nciaer_superslide", $cacheArr);
        }
        $arr = array();
        foreach($slides as $v) {
            if($v['client'] == $client) {
                $arr[] = $v;
            }
        }
        return $arr;
    }
}

class mobileplugin_nciaer_superslide_forum extends plugin_nciaer_superslide {

    public function index_top_mobile() {

        global $_G;

        if(!$this->config['on']) return '';

        $speed = intval($this->config['speed']);
        $showSeconds = intval($this->config['showSeconds']);
        $slides = $this->fetchdata(1);

        $return = '';
        include template('nciaer_superslide:slide');
        return count($slides) > 0 ? $return : "";
    }
}
