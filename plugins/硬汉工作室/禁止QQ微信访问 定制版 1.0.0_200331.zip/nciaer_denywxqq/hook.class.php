<?php
/**
 *	 ΢��QQ��ֹ����
 *
 *   Copyright (c) 2020 by dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_denywxqq {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_denywxqq'];
    }

    public function common() {

        global $_G;

        if(!$this->config['on']) return;

        $agent = strtolower($_SERVER['HTTP_USER_AGENT']);
        if(($this->config['wx_off'] && strpos($agent, 'micromessenger/') !== FALSE) || ($this->config['qq_off'] && strpos($agent, 'qq/') !== FALSE)) {
            include template('nciaer_denywxqq:tip');
            die;
        }
    }

}

class mobileplugin_nciaer_denywxqq extends plugin_nciaer_denywxqq {}