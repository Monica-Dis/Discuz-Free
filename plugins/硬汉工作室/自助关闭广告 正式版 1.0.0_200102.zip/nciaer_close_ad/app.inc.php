<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ��ַ�� http://dism.taobao.com
 * QQ��1069971363
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://addon.dismall.com/?@56030.developer');