<?php
/**
 * �ֻ��淢����������
 *
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_mhide {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		$this->config = $_G['cache']['plugin']['llx_mhide'];
	}
}

class mobileplugin_llx_mhide_forum extends plugin_llx_mhide {
	
	public function post_message($params) {
		
		global $_G;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		$param = $params['param'];
		$hidemsg = daddslashes(dhtmlspecialchars(trim($_GET['mhide'])));
		
		if(($param[0] == 'post_newthread_succeed' || $param[0] == 'post_newthread_mod_succeed') && !empty($hidemsg)) {
			$pid = $param[2]['pid'];
			$post = C::t('forum_post')->fetch(0, $pid);
			$message = $post['message'];
			$newmessage = $message."[hide]{$hidemsg}[/hide]";
			C::t('forum_post')->update(0, $pid, array('bbcodeoff' => 0, 'message' => $newmessage));		
			
		}
	}
	
	public function post_bottom_mobile_output() {
		
		global $_G;

		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		if(!in_array($_G['groupid'], unserialize($this->config['gids']))) return;
		
		include template('llx_mhide:index');
		return $return;
	}
}