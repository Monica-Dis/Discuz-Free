<?php
/**
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class mobileplugin_zhuan_guestrestrict
{


}

class mobileplugin_zhuan_guestrestrict_forum extends mobileplugin_zhuan_guestrestrict{
	
			function viewthread_top(){
			
			global $_G;
			$max = 0;

			$config=$_G['cache']['plugin']['zhuan_guestrestrict'];
			
			
			require_once DISCUZ_ROOT."./source/plugin/zhuan_guestrestrict/include/common.inc.php";
			
		}
		
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>