<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



			if(!$_G['uid']){
				
				$ip = ip2long($_G['clientip']);

			/*
				require_once libfile('function/cache');
				$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_zhuan_guestrestrict.php';
				if(file_exists($cache_file)){
					@include_once DISCUZ_ROOT.'./data/sysdata/cache_zhuan_guestrestrict.php';
				}
				*/
				
				$fetch = DB::fetch_first("SELECT * FROM ".DB::table('zhuan_guestrestrict')." WHERE ip = '$ip'");
				
				//$guestnum[$ip] = dintval($guestnum[$ip]);
				//$max = $guestnum[$ip];
				$max = intval($fetch['guesttime']);
				
				if( $max < $config['count'] ){
					
						//$guestnum[$ip] = $max + 1;
						
						//$cacheArray .= "\$guestnum=".arrayeval($guestnum).";\n";
						//writetocache('zhuan_guestrestrict', $cacheArray);
						
						if(empty($fetch)){
								DB::insert('zhuan_guestrestrict',array('guesttime'=>1,
								'accesstime'=>dgmdate(TIMESTAMP),
								'ip'=>$ip));
							}
							else{
								DB::query("update ".DB::table('zhuan_guestrestrict')." set guesttime = guesttime + 1");
							}

					}else{
						
						showmessage($config['lang_mustlogin'], '', array(), array('showmsg' => true, 'login' => 1));
						
				}
				
					
			}
			
			 
?>