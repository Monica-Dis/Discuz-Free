<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = '';


$sql = <<<EOF

DROP TABLE IF EXISTS `pre_zhuan_guestrestrict`;

EOF;


runquery($sql);

/*
$file  = DISCUZ_ROOT.'./data/sysdata/cache_zhuan_guestrestrict.php';
if(file_exists($file))
{
	unlink($file);
}
*/
$finish = TRUE;

?>