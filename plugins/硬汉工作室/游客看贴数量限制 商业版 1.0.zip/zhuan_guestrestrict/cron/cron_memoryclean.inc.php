<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


				$fetch = DB::query("SELECT * FROM ".DB::table('zhuan_guestrestrict')." where accesstime > DATE_SUB(CURDATE(), INTERVAL 1 MONTH)");

				foreach($fetch as $key=>$val){
					DB:delete('zhuan_guestrestrict',array("id"=>$val['id']));
				}
				


?>