<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zhuan_guestrestrict` (
  `id` int(11) NOT NULL,
  `ip` int(11) NOT NULL,
  `accesstime` datetime NOT NULL,
  `guesttime` int(11) NOT NULL
) ENGINE=MEMORY ;

EOF;

runquery($sql);

$finish = TRUE;

?>