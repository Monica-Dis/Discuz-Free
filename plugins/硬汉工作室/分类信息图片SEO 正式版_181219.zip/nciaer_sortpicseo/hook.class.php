<?php
/**
 *     ������ϢͼƬSEO
 *
 *   Ӳ�������� ��Ȩ����
 *   ��ַ��dism.taobao.com
 *   DisM!Ӧ������(dism.taobao.com)
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_sortpicseo {

    public $config = array();
    public $vars = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_sortpicseo'];
    }

    public function viewthread_nciaer_output() {

        global $_G, $thread, $threadsortshow;

        if (!$this->config['on']) return;

        if(!in_array($_G['fid'], dunserialize($this->config['fids']))) return;

        $this->vars['tid'] = intval($_G['tid']);
        $this->vars['title'] = dhtmlspecialchars($thread['subject']);
        $this->vars['dateline'] = dgmdate($thread['dateline'], 'Y-m-d H:i:s');
        $this->vars['author'] = dhtmlspecialchars($thread['author']);

        $typetemplate = $threadsortshow['typetemplate'];
        if(!empty($typetemplate)) {
            $return = preg_replace_callback('/<img[^>]+/', array($this, 'seo'), $typetemplate);
            $threadsortshow['typetemplate'] = $return;
        }
    }

    public function seo($data) {

        $data[0] = preg_replace('|([\'"])[/ ]*$|', '\1 /', $data[0]);
        $data[0] = preg_replace('/\s*=\s*/', '=', substr($data[0], 0, strlen($data[0]) - 2));
        $splits = preg_split('/(\w+=)/', $data[0], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $titleseo = $this->fetchseoinfo($this->config['titlerule']);
        $altseo = $this->fetchseoinfo($this->config['titlerule']);

        if (in_array('alt=', $splits)) {
            $index = array_search('alt=', $splits);
            $splits[$index + 1] = '"'.$altseo.'" ';
        } else {
            array_push($splits, ' alt="'.$altseo.'"');
        }

        if (in_array('title=', $splits)) {
            $index = array_search('title=', $splits);
            $splits[$index + 1] = '"'.$titleseo.'" ';
        } else {
            array_push($splits, ' title="'.$titleseo . '"');
        }

        return implode('', $splits) . ' /';
    }

    public function fetchseoinfo($str) {

        $str = str_ireplace('[title]', $this->vars['title'], $str);
        $str = str_ireplace('[tid]', $this->vars['tid'], $str);
        $str = str_ireplace('[author]', $this->vars['author'], $str);
        $str = str_ireplace('[dateline]', $this->vars['dateline'], $str);

        return $str;
    }
}

class plugin_nciaer_sortpicseo_forum extends plugin_nciaer_sortpicseo {}

class mobileplugin_nciaer_sortpicseo_forum extends plugin_nciaer_sortpicseo {}