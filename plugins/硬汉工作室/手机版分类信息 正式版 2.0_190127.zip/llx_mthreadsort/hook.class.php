<?php
/**
 *   �ֻ��������Ϣ
 *
 *   ������ҵ���/ģ������ ����DisM!Ӧ������
 *   Support: DisM!Ӧ������
 *   (C) dism-Taobao-com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_mthreadsort {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['llx_mthreadsort'];
	}
}


class mobileplugin_llx_mthreadsort_forum extends plugin_llx_mthreadsort {
	
	public function viewthread_llx_output() {
		
		global $_G, $postlist, $threadsort, $threadsortshow;
		
		if(!in_array($_G['fid'], unserialize($this->config['fids']))) return;
		
		foreach($postlist as &$post) {
			if($post['first']) {
				include template('llx_mthreadsort:index');
				if($this->config['position'] == 1) {
					$post['message'] = $return . $post['message'];
				} elseif($this->config['position'] == 2) {
					$post['message'] = $post['message'] . $return;
				}
			}
		}
	}
}
