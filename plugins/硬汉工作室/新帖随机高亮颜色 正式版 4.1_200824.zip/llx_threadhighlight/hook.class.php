<?php
/**
 *	 �������������ɫ
 *
 *   DisM!Ӧ������ dism.taobao.com 
 *   ��ַ��DisM.Taobao.Com
 *   DISM.TAOBAO.COM
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_threadhighlight {

    public $config = array();

    public function __construct() {

        global $_G;
        $this->config = $_G['cache']['plugin']['llx_threadhighlight'];
    }

    public function post_message($params) {

        global $_G;

        if(!$this->config['on']) return;

        if($_G['basescript'] != 'group') {
            $fids = dunserialize($this->config['fids']);
            if($fids[0] != '' && !in_array($_G['fid'], $fids)) return;
        }
        $gids = dunserialize($this->config['gids']);
        if($fids[0] != '' && !in_array($_G['groupid'], $gids)) return;

        $param = $params['param'];
        if($param[0] == 'post_newthread_succeed' || $param[0] == 'post_newthread_mod_succeed') {
            $tid = $param[2]['tid'];
            $colors = dunserialize($this->config['colors']);
            $highlight_color = $colors[array_rand($colors)];
            $blod = mt_rand(0, 100) > (100 - $this->config['prob']) ? 1 : 0;
            if($blod) {
                $highlight_color = '4'.$highlight_color;
            }
            C::t('forum_thread')->update($tid, array('highlight' => $highlight_color), true);
            C::t('forum_forumrecommend')->update($tid, array('highlight' => $highlight_color));
        }
    }
}

class plugin_llx_threadhighlight_forum extends plugin_llx_threadhighlight {}

class mobileplugin_llx_threadhighlight_forum extends plugin_llx_threadhighlight {}

class plugin_llx_threadhighlight_group extends plugin_llx_threadhighlight {}

class mobileplugin_llx_threadhighlight_group extends plugin_llx_threadhighlight {}
