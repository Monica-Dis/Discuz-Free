<?php
/**
 *     ϵͳ���������ʾ
 *
 *   Ĭ��ϵͳ�ļ���������ֻ�������ʾһ���������˲���󣬿���ȫ����ʾ����
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   Support: DisM!Ӧ������
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_multi_banner {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_multi_banner'];
    }

    public function ad() {

        return '';
    }

    public function global_usernav_extra3() {

        global $_G;


//�ж��Ƿ�vip	      
if($_G['dc_plugin']['vip']['hook'][ 'nciaer_multi_banner'][ 'view_ad']) {
        if(!$this->config['on']) return '';
        if(!$_G['uid']) return '';
        if(!in_array($_G['groupid'], dunserialize($this->config['gids']))) return '';

        if(!empty($_G['cookie'][$_G['uid'].'_ad'])) {
            return  '<a style="text-decoration:none"  href = "plugin.php?id=nciaer_multi_banner:close&status=0"><img src="source/plugin/nciaer_close_ad/kaiqi.jpg" style="position:relative;top: -4px;height: 18px;width: 58px;" align="middle"></a>';
        } else {
            return  '<a style="text-decoration:none"   href ="plugin.php?id=nciaer_multi_banner:close&status=1"><img src="source/plugin/nciaer_close_ad/guanbi.jpg" style="position:relative;top: -4px;height: 18px;width: 58px;" align="middle"> </a>';
        }
} else {

}	
			
		
		
		
    }

    private function _ad($param) {

        global $_G;

        if(!$this->config['on']) return $param['content'];

     
		
		
		//�ж��Ƿ�vip	
        if($_G['dc_plugin']['vip']['hook'][ 'nciaer_multi_banner'][ 'view_ad']) {
		   if(!empty($_G['cookie'][$_G['uid'].'_ad'])) {
            return '';
        }
		}
		
		
		

        $params = $param['params'];
        loadcache('advs');
        $adids = array();
        $evalcode = &$_G['cache']['advs']['evalcode'][$params[0]];
        $parameters = &$_G['cache']['advs']['parameters'][$params[0]];
        $codes = &$_G['cache']['advs']['code'][$_G['basescript']][$params[0]];
        $fid = !empty($_G['fid']) ? $_G['fid'] : -1;
        if (!empty($codes)) {
            foreach ($codes as $adid => $code) {
                $parameter = &$parameters[$adid];
                if(!in_array($fid, $parameter['fids'])) continue;
                $checked = true;
                @eval($evalcode['check']);
                if ($checked) {
                    $adids[] = $adid;
                }
            }

            if($this->config['shuffle']) {
                shuffle($adids);
            }

            if (!empty($adids)) {
                $adcontent = '<div class = "wp ah">';
                foreach($adids as $id) {
                    $adcontent .= $codes[$id];
                }
                $adcontent .= '</div>';
            }
        }

        return $adcontent;
    }

    public function ad_headerbanner($param) {

        if(in_array(1, dunserialize($this->config['ads']))) {
			
            return $this->_ad($param);
			
        } else {
            return $param['content'];
        }
    }

    public function ad_subnavbanner($param) {

        if(in_array(2, dunserialize($this->config['ads']))) {
            return $this->_ad($param);
        } else {
            return $param['content'];
        }
    }
	

    public function _hide_ad($param) {

        global $_G;
        if(!$this->config['on']) return $param['content'];
        //�ж��Ƿ�vip	
        if($_G['dc_plugin']['vip']['hook'][ 'nciaer_multi_banner'][ 'view_ad']) {
        if(!empty($_G['cookie'][$_G['uid'].'_ad'])) {
            return ''; //���ùر��˹��
        } else {
            return $param['content'];//���ÿ����˹��
        }
		  }	else {
            
			
		if(checkrobot() && in_array($param['params'][0], dunserialize($this->config['ads1']))) {
            return '';
        } else {
            return $param['content']; //����vip �������
        }
			
			
			
			
			
        }	

    }

    public function ad_footerbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_float($param) {

        return $this->_hide_ad($param);
    }

    public function ad_couplebanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_cornerbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_text($param) {

        return $this->_hide_ad($param);
    }

    public function ad_intercat($param) {

        return $this->_hide_ad($param);
    }

    public function ad_threadlist($param) {

        return $this->_hide_ad($param);
    }

    public function ad_interthread($param) {

        return $this->_hide_ad($param);
    }

    public function ad_thread($param) {

        return $this->_hide_ad($param);
    }

    public function ad_search($param) {

        return $this->_hide_ad($param);
    }

    public function ad_article($param) {

        return $this->_hide_ad($param);
    }

    public function ad_articlelist($param) {

        return $this->_hide_ad($param);
    }

    public function ad_feed($param) {

        return $this->_hide_ad($param);
    }

    public function ad_blog($param) {

        return $this->_hide_ad($param);
    }
	public function ad_custom($param) {

        return $this->_hide_ad($param);
    }
	public function ad_custom_1($param) {

        return $this->_hide_ad($param);
    }
	public function ad_custom_2($param) {

        return $this->_hide_ad($param);
    }

}


