<?php
/**
 *	 ����������Թ��
 *
 *   DisM!Ӧ�����ģ�dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   Support: DisM!Ӧ������
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_noad {

    public $config = array();

    public function __construct() {

        global $_G;

        $this->config = $_G['cache']['plugin']['nciaer_noad'];
    }

    public function _hide_ad($param) {

        if(!$this->config['on']) return $param['content'];

        if(checkrobot() && in_array($param['params'][0], dunserialize($this->config['ads']))) {
            return '';
        } else {
            return $param['content'];
        }
    }
    public function ad_headerbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_subnavbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_footerbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_float($param) {

        return $this->_hide_ad($param);
    }

    public function ad_couplebanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_cornerbanner($param) {

        return $this->_hide_ad($param);
    }

    public function ad_text($param) {

        return $this->_hide_ad($param);
    }

    public function ad_intercat($param) {

        return $this->_hide_ad($param);
    }

    public function ad_threadlist($param) {

        return $this->_hide_ad($param);
    }

    public function ad_interthread($param) {

        return $this->_hide_ad($param);
    }

    public function ad_thread($param) {

        return $this->_hide_ad($param);
    }

    public function ad_search($param) {

        return $this->_hide_ad($param);
    }

    public function ad_article($param) {

        return $this->_hide_ad($param);
    }

    public function ad_articlelist($param) {

        return $this->_hide_ad($param);
    }

    public function ad_feed($param) {

        return $this->_hide_ad($param);
    }

    public function ad_blog($param) {

        return $this->_hide_ad($param);
    }
}