<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * ��ַ�� http://dism.taobao.com
 * From: DisM.taobao.Com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://zzb7.taobao.com/?@56030.developer');