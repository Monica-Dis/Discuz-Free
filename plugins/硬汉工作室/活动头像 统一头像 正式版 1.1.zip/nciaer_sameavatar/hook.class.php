<?php
/**
 *	 �ͷ��(ͳһͷ��)
 *
 *   Ӳ�������� ��Ȩ���� 
 *   ��ַ��dism.taobao.com/?
 *   QQ: 1069971363
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_sameavatar {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['nciaer_sameavatar'];
	}
	
	public function avatar($params) {
		
		global $_G;

		if($this->config['login_on'] && !$_G['uid']) return;

		$param = $params['param'];
		if($param[1] == 'small') {
			$img = $this->config['small'];
		} elseif ($param[1] == 'big') {
			$img = $this->config['big'];
		} else {
			$img = $this->config['middle'];
		}

		if($param[2]) {
			$_G['hookavatar'] = $img;
		} else {
			$_G['hookavatar'] = '<img src="'.$img.'"/>';
		}
	}
}

class mobileplugin_nciaer_sameavatar extends plugin_nciaer_sameavatar {}