<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_sp178_baidu360 {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;
		
		$this->config = $_G['cache']['plugin']['sp178_baidu360'];
	}

	public function _getscript() {
		
		global $_G;

		if(!in_array(CURSCRIPT, array('forum', 'portal', 'group'))) return '';

		if($_G['basescript'] == 'forum' && !$this->config['forum_enable']) return '';
		if($_G['basescript'] == 'portal' && !$this->config['portal_enable']) return '';
		if($_G['basescript'] == 'group' && !$this->config['group_enable']) return '';
		if($_G['basescript'] == 'forum') {
		    if(CURMODULE != 'index' && !in_array($_G['fid'], dunserialize($this->config['fids']))) return '';
        }

		$html = '';
		if($this->config['baidu_enable']) {
			$html.=<<<EOF
			
(function(){
    var bp = document.createElement("script");
    var curProtocol = window.location.protocol.split(":")[0];
    if (curProtocol === "https") {
        bp.src = "https://zz.bdstatic.com/linksubmit/push.js";        
    }
    else {
        bp.src = "http://push.zhanzhang.baidu.com/push.js";
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
EOF;
		}
		
		if($this->config['s360_enable'] && $this->config['hash']) {
			$html .= <<<EOF
			
(function(){
    var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?{$this->config['hash']}":"https://jspassport.ssl.qhimg.com/11.0.1.js?{$this->config['hash']}";
    document.write("<script src='" + src + "' id='sozz'><\/script>");
})();

EOF;
		}
		
		return '<script>' . $html . '</script>';
	}
	
	public function global_footer() {
		
		return $this->_getscript();
    }	
}

class mobileplugin_sp178_baidu360 extends plugin_sp178_baidu360 {
	
	public function global_footer_mobile() {
		
		global $_G;
		
		if($this->config['mobile_enable']) {
			return $this->_getscript();
		}
		return '';
	}
}