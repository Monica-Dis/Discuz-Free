<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_himickey_scrollthreadnews {}

class plugin_himickey_scrollthreadnews_forum extends plugin_himickey_scrollthreadnews {
	
	private $config= array();
	
	public function __construct() {
		
		global $_G;
		$this -> configs = $_G["cache"]["plugin"]["himickey_scrollthreadnews"];
	}
	
	
	public function index_top_output() {
	
		if($this -> configs["show_index"]) {
			return $this -> _fetchData();
		}
		
	}
	
	public function forumdisplay_top_output(){
		
		if($this -> configs["show_list"]) {
			return $this -> _fetchData();
		}
	}
	
	public function viewthread_top_output(){

		if($this -> configs["show_viewthread"]) {
			return $this -> _fetchData();
		}
	}
	
	private function _fetchData() {
		
		global $_G;
		require_once libfile('function/cache');
		$fids = "(".dimplode((array)unserialize($this -> configs['fids'])).")";
		switch(intval($this -> configs['datasource'])) {
			case 1:
				$where = " 1 and ";
				$order = "dateline";
				break;
			case 2:
				$where = "t.replies > 0 and ";
				$order= "lastpost";
				break;
			case 3:
				$where = " 1 and ";
				$order= "views";
				break;
			case 4:
				$where = " 1 and ";
				$order= "replies";
				break;
		}
		$opentype = $this -> configs['newblank'] ? "target='_blank'" : "";
		
		if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollthreadnews.php")) {
			require_once DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollthreadnews.php";
			if(intval($_G["timestamp"]) - intval($data["ctime"]) > 600) {
				$rs = DB::fetch_all("select t.tid, t.subject, ti.attachment from " . DB::table('forum_thread') . " t, ".DB::table('forum_threadimage'). " ti where {$where} t.displayorder >= 0 and t.tid = ti.tid and t.fid in{$fids} order by {$order} desc limit 0, {$this -> configs['num']}");
				$data["data"] = $rs;
				$data["ctime"] = $_G["timestamp"];
				$cacheArr = "\$data = " . arrayeval($data) . ";\n";
				writetocache("himickey_scrollthreadnews", $cacheArr);
				require_once DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollthreadnews.php";				
			}
		} else {
			$rs = DB::fetch_all("select t.tid, t.subject, ti.attachment from " . DB::table('forum_thread') . " t, ".DB::table('forum_threadimage'). " ti where {$where} t.displayorder >= 0 and t.tid = ti.tid and t.fid in{$fids} order by {$order} desc limit 0, {$this -> configs['num']}");
			$data["data"] = $rs;
			$data["ctime"] = $_G["timestamp"];
			$cacheArr = "\$data = " . arrayeval($data) . ";\n";
			writetocache("himickey_scrollthreadnews", $cacheArr);
			require_once DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollthreadnews.php";
			
		}
		$rs = $data["data"];
		foreach($rs as &$v) {
			$v['subject'] = cutstr($v['subject'], 30);
		}
		unset($v);
		$delaytime = $this -> configs['delaytime'];
		include template('himickey_scrollthreadnews:index');
		return $return;
	}
}