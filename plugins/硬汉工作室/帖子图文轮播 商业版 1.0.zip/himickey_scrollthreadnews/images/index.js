jQuery(document).ready(function(e) {	
	linum = jQuery('.mainlist li').length;
	w = linum * 245;
	jQuery('.piclist').css('width', w + 'px');
	jQuery('.swaplist').html(jQuery('.mainlist').html());
	
	jQuery('.og_next').click(function(){
		
		if(jQuery('.swaplist,.mainlist').is(':animated')){
			jQuery('.swaplist,.mainlist').stop(true,true);
		}
		
		if(jQuery('.mainlist li').length>4){
			ml = parseInt(jQuery('.mainlist').css('left'));
			sl = parseInt(jQuery('.swaplist').css('left'));
			if(ml<=0 && ml>w*-1){
				jQuery('.swaplist').css({left: '980px'});
				jQuery('.mainlist').animate({left: ml - 980 + 'px'},'slow');			
				if(ml==(w-980)*-1){
					jQuery('.swaplist').animate({left: '0px'},'slow');
				}
			}else{
				jQuery('.mainlist').css({left: '980px'})
				jQuery('.swaplist').animate({left: sl - 980 + 'px'},'slow');
				if(sl==(w-980)*-1){
					jQuery('.mainlist').animate({left: '0px'},'slow');
				}
			}
		}
	})
	jQuery('.og_prev').click(function(){
		
		if(jQuery('.swaplist,.mainlist').is(':animated')){
			jQuery('.swaplist,.mainlist').stop(true,true);
		}
		
		if(jQuery('.mainlist li').length>4){
			ml = parseInt(jQuery('.mainlist').css('left'));
			sl = parseInt(jQuery('.swaplist').css('left'));
			if(ml<=0 && ml>w*-1){
				jQuery('.swaplist').css({left: w * -1 + 'px'});
				jQuery('.mainlist').animate({left: ml + 980 + 'px'},'slow');				
				if(ml==0){
					jQuery('.swaplist').animate({left: (w - 980) * -1 + 'px'},'slow');
				}
			}else{
				jQuery('.mainlist').css({left: (w - 980) * -1 + 'px'});
				jQuery('.swaplist').animate({left: sl + 980 + 'px'},'slow');
				if(sl==0){
					jQuery('.mainlist').animate({left: '0px'},'slow');
				}
			}
		}
	})    
});

jQuery(document).ready(function(){
	jQuery('.og_prev,.og_next').hover(function(){
			jQuery(this).fadeTo('fast',1);
		},function(){
			jQuery(this).fadeTo('fast',0.7);
	})

})