<?php
/**
 *	 �»�Ա������ʾ
 *
 *   Copyright (c) 2020 by dism.taobao.com
 *   ��ַ��dism.taobao.com
 *   DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_himickey_scrollnewer {
	
	public $return = '';
	public $config = array();
	
	public function __construct() {
		
		global $_G;

		$this->config = $_G['cache']['plugin']['himickey_scrollnewer'];


	}

	public function global_header() {

	    global $_G;

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT.CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->config['showpage']);
        if(!in_array('all', $showvalue)) {
            if(!in_array($showkey, $showvalue)) return '';
        }

        $new_blank = $this->config['new_blank'] ? 'target = "_blank"' : '';
        $cachefile = "./data/sysdata/cache_himickey_scrollnewer.php";
        if(file_exists(DISCUZ_ROOT . $cachefile) && (TIMESTAMP - intval(filemtime($cachefile)) < $this->config['cache_time'] * 60)) {
            require_once DISCUZ_ROOT . $cachefile;
        } else {
            $data = $this->_cache($this->config['num']);
        }

        include template('himickey_scrollnewer:index');

        return $return;
    }

    public function _cache($num = 10) {

        require_once libfile('function/cache');
        $data = DB::fetch_all('select uid, username from %t order by regdate desc limit %d', array('common_member', $num));
        $cacheArr = "\$data = " . arrayeval($data) . ";\n";
        writetocache("himickey_scrollnewer", $cacheArr);
        return $data;
    }
}
