<?php
/**
 * Copyright (c) 2020 by dism.taobao.com
 *
 * ��ַ�� http://t.cn/AiEbevTy
 * dism��taobao-com
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

dheader('Location:https://dism.taobao.com/?@56030.developer');