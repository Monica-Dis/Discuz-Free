<?php
/**
 *   Copyright (c) 2020 by dism.taobao.com
 *   网址：dism.taobao.com
 *   DISM.TAOBAO.COM
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied!');
}

if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollnewer.php")) {
	unlink(DISCUZ_ROOT . "./data/sysdata/cache_himickey_scrollnewer.php");
}

$finish = TRUE;