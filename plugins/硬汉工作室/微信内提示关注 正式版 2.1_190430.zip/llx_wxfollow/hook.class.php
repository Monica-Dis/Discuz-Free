<?php
/**
 * ΢������ʾ��ע
 *
 *   ������ҵ���/ģ������ ����DisM!Ӧ������
 *   Support: DisM!Ӧ������
 *   (C) dism-Taobao-com
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_llx_wxfollow {
	
	public $config = array();
	
	public function __construct() {
		
		global $_G;

		$this->config = $_G['cache']['plugin']['llx_wxfollow'];
	}

	public function iswx() {

        return strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') !== false ? 1 : 0;
    }
}

class mobileplugin_llx_wxfollow extends plugin_llx_wxfollow {
	
	public function global_footer_mobile() {

		$return = '';

		if($this->iswx()) {
			$opacity = intval($this->config['opacity'] * 100);
			include template('llx_wxfollow:index');
		}

		return $return;
	}
}

class mobileplugin_llx_wxfollow_forum extends plugin_llx_wxfollow {
	
	public function viewthread_postbottom_mobile() {
		
		global $_G;

		$return = '';
		if($this->iswx() && $this->config['showtip']) {
			include template('llx_wxfollow:tip');
		}
		return array($return);
	}	
}

class mobileplugin_llx_wxfollow_group extends plugin_llx_wxfollow {}