<?php
/**
*   DisM!应用中心：dism.taobao.com
*   客服QQ：1069971363
*   官网：http://dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
create table if not exists `pre_nciaer_multiad` (
	`id` int(11) not null auto_increment primary key,
	`title` varchar(100) not null default '',
	`pic` varchar(150) not null default '',
	`url` varchar(150) not null default '',
	`displayorder` int not null default 0,
	`inuse` tinyint not null default 0,
	`dateline` int not null default 0,
	key(`displayorder`)
) engine=myisam;
EOF;
runquery($sql);

$finish = TRUE;