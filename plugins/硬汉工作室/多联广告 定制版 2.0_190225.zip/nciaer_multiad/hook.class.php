<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_nciaer_multiad {
	
	public $configs = array();
	
	public function __construct() {
		
		global $_G;
		$this->configs = $_G['cache']['plugin']['nciaer_multiad'];
	}

	public function fetchad() {

        $mainWidth = intval($this->configs['mainWidth']);
        $adwidth = $this->configs['adwidth'];
        $adheight = $this->configs['adheight'];
        $top = $this->configs['top'];
        if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_multiad.php")) {
            require_once DISCUZ_ROOT . "./data/sysdata/cache_nciaer_multiad.php";
        } else {
            require_once libfile('function/cache');
            $ads = DB::fetch_all("select * from " . DB::table("nciaer_multiad"));
            $cacheArr = "\$ads = " . arrayeval($ads) . ";\n";
            writetocache("nciaer_multiad", $cacheArr);
        }
        if($this->configs['ad_num'] == 0) {
            $ad_num = 2;
        } elseif($this->configs['ad_num'] == 1) {
            $ad_num = 4;
        } else {
            $ad_num = 6;
        }
        if(!$ads || count($ads) < $ad_num) return;
        $top1 = $adheight + $this->configs['top'] + 20;
        $top2 = $adheight * 2 + $this->configs['top'] + 40;

        if($this->configs['rand_show']) {
            if($ad_num == 2) {
                list($ad1_index, $ad2_index) = array_rand($ads, 2);
                $ad1 = $ads[$ad1_index];
                $ad2 = $ads[$ad2_index];
                include template('nciaer_multiad:block2');
            } elseif($ad_num == 4) {
                list($ad1_index, $ad2_index, $ad3_index, $ad4_index) = array_rand($ads, 4);
                $ad1 = $ads[$ad1_index];
                $ad2 = $ads[$ad2_index];
                $ad3 = $ads[$ad3_index];
                $ad4 = $ads[$ad4_index];
                include template('nciaer_multiad:block4');
            } else {
                list($ad1_index, $ad2_index, $ad3_index, $ad4_index, $ad5_index, $ad6_index) = array_rand($ads, 6);
                $ad1 = $ads[$ad1_index];
                $ad2 = $ads[$ad2_index];
                $ad3 = $ads[$ad3_index];
                $ad4 = $ads[$ad4_index];
                $ad5 = $ads[$ad5_index];
                $ad6 = $ads[$ad6_index];
                include template('nciaer_multiad:block6');
            }

        } else {
            if($ad_num == 2) {
                $ad1 = $ads[0];
                $ad2 = $ads[1];
                include template('nciaer_multiad:block2');
            } elseif($ad_num == 4) {
                $ad1 = $ads[0];
                $ad2 = $ads[1];
                $ad3 = $ads[2];
                $ad4 = $ads[3];
                include template('nciaer_multiad:block4');
            } else {
                $ad1 = $ads[0];
                $ad2 = $ads[1];
                $ad3 = $ads[2];
                $ad4 = $ads[3];
                $ad5 = $ads[4];
                $ad6 = $ads[5];
                include template('nciaer_multiad:block6');
            }
        }

        if($this->configs['show_only_visitor'] && $_G['uid']) {
            return '';
        } else {
            return $return;
        }
    }

	public function global_header() {

        $showkey = CURSCRIPT != 'plugin' ? CURSCRIPT.CURMODULE : CURSCRIPT;
        $showvalue = dunserialize($this->configs['showpage']);
        if(!in_array('all', $showvalue)) {
            if(!in_array($showkey, $showvalue)) return '';
        }

        return $this->fetchad();
    }
}
