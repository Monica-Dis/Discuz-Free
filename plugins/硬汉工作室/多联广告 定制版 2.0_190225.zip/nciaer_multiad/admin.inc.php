<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$appurl=$_G['siteurl'] . ADMINSCRIPT . "?action=plugins&operation=config&do=$_GET[do]&identifier=nciaer_multiad&pmod=admin";
$pagesize = 10;
$p = isset($_GET['p']) ? $_GET['p'] : 'index';
if(!in_array($p, array('index', 'add', 'edit', 'del'))) {
	cpmsg(lang('plugin/nciaer_multiad', 'error'), $appurl, 'error');
}

if($p == 'index') {
	$page = max($_G['page'], 1);
	$start = ($page - 1) * $pagesize ;
	$datas=DB::fetch_all("select * from %t order by displayorder desc limit %d, %d", array('nciaer_multiad', $start, $pagesize));
	$count=DB::result_first("select count(*) from %t", array('nciaer_multiad'));
	$pages = multi($count, $pagesize , $page, $appurl . "&p={$p}");
} elseif($p == 'add') {
	if(submitcheck('addsubmit')){
        $title = addslashes(dhtmlspecialchars(trim($_GET['title'])));
        $pic = addslashes(dhtmlspecialchars(trim($_GET['pic'])));
        $url = addslashes(dhtmlspecialchars(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
		$displayorder = intval($_GET['displayorder']);		
        $dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(lang('plugin/nciaer_multiad', 'miss_msg'), $appurl . '&p=add', 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(lang('plugin/nciaer_multiad', 'up_err'), $appurl . '&p=ad', 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(lang('plugin/nciaer_superfloatad', 'img_ext_err'), $appurl . '&p=add', 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		DB::insert('nciaer_multiad', 
		array(
			'title' => $title,
			'pic' => $pic,
			'url' => $url,
			'inuse' => $inuse, 
			'displayorder' => $displayorder,
			'dateline' => $dateline,
		));
		_updatecache();
		cpmsg(lang('plugin/nciaer_multiad', 'add_ok'), $appurl, 'succeed');
	}
} elseif($p == 'edit') {
	
	$id = intval($_GET['id']);
	$data = DB::fetch_first("select * from " . DB::table('nciaer_multiad') . " where id ='{$id}'");
    if(submitcheck('editsubmit')){
        $title = addslashes(dhtmlspecialchars(trim($_GET['title'])));
        $pic = addslashes(dhtmlspecialchars(trim($_GET['pic'])));
        $url = addslashes(dhtmlspecialchars(trim($_GET['url'])));
		$inuse = intval($_GET['inuse']);
		$displayorder = intval($_GET['displayorder']);
		$dateline = $_G['timestamp'];
		if(empty($title) || empty($url) || (empty($pic) && empty($_FILES['file']['name']))) {
			cpmsg(lang('plugin/nciaer_multiad', 'miss_msg'), $appurl . '&p=add&id='.$id, 'error');
		} else{
			if($_FILES['file']['name']) {
				if($_FILES['file']['error'] != 0) {
					cpmsg(lang('plugin/nciaer_multiad', 'up_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				$imgExt = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
				$exts = array('jpg', 'jpeg', 'png', 'gif');
				if (!in_array(strtolower($imgExt), $exts)) { 
					cpmsg(lang('plugin/nciaer_superfloatad', 'img_ext_err'), $appurl . '&p=add&id='.$id, 'error');
				}
				
				$upload = new discuz_upload();
				$upload->init($_FILES['file'], 'forum');
				if($upload->save()){
					$pic = $_G['setting']['attachurl'] . 'forum/' . $upload->attach['attachment'];
				}
			}
		}
		DB::update('nciaer_multiad',
			array(
				'title' => $title,
				'pic' => $pic,
				'url' => $url,
				'inuse' => $inuse,
				'displayorder' => $displayorder,
				'dateline' => $dateline,
			),
			"id = {$id}"
		);
		_updatecache();
		cpmsg(lang('plugin/nciaer_multiad', 'edit_ok'), $appurl, 'succeed');
	}
} elseif($p == 'del') {
	if($_GET['formhash'] == FORMHASH) {
		$id=intval($_GET['id']);
		$pic = DB::result_first("select pic from " . DB::table('nciaer_multiad') . " where id = {$id}");
		@unlink($pic);
		DB::delete('nciaer_multiad', "id = {$id}");
		_updatecache();
		cpmsg(lang('plugin/nciaer_multiad', 'del_ok'), $appurl, 'succeed');
	}
}

function _updatecache() {
	
	global $_G;
	require_once libfile('function/cache');
	$sql = "select * from %t where inuse = 1 order by displayorder asc";
	$ads = DB::fetch_all($sql, array('nciaer_multiad'));
	$cacheArr = "\$ads = " . arrayeval($ads) . ";\n";
	writetocache("nciaer_multiad", $cacheArr);
}

require_once template("nciaer_multiad:cp_{$p}");
