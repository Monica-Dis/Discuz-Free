<?php
/**
*   DisM!应用中心：dism.taobao.com
*   客服QQ：1069971363
*   官网：http://dism.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$rs = DB::fetch_all("select pic from " . DB::table('pre_nciaer_multiad'));
foreach($rs as $pic) {
	@unlink($pic);
}
$sql = <<<EOF
	drop table if exists `pre_nciaer_multiad`;
EOF;
runquery($sql);

if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_multiad.php")) {
	unlink(DISCUZ_ROOT . "./data/sysdata/cache_nciaer_multiad.php");
}

$finish = TRUE;