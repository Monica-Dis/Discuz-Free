<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Deined');
}

class plugin_v2_mediaplay {
}

class plugin_v2_mediaplay_forum extends plugin_v2_mediaplay {
	
	function misc_postbottom_output() {
		global $_G, $attach, $aid;
		if(empty($_G['cache']['plugin']))loadcache('plugin');
		$mplay = $_G['cache']['plugin']['v2_mediaplay'];
		$mplay['forums'] = unserialize($mplay['forums']);
		$fid = C::t('forum_thread')->fetch($attach['tid']);
		$fid = $fid['fid'];		
		if(submitcheck('paysubmit') && in_array($fid,$mplay['forums'])){
			dheader('location: forum.php?mod=viewthread&tid='.$attach['tid']);
			dexit();
		}
	}
	
	function viewthread_postbottom_output() {
		require_once DISCUZ_ROOT . './source/plugin/v2_mediaplay/pc.core.php';						
	}
}

class mobileplugin_v2_mediaplay {
}

class mobileplugin_v2_mediaplay_forum extends mobileplugin_v2_mediaplay {

	function misc_postbottom_output() {			
		global $_G, $attach, $aid;
		if(empty($_G['cache']['plugin']))loadcache('plugin');
		$mplay = $_G['cache']['plugin']['v2_mediaplay'];
		$mplay['forums'] = unserialize($mplay['forums']);
		$fid = C::t('forum_thread')->fetch($attach['tid']);
		$fid = $fid['fid'];		
		if(submitcheck('paysubmit') && in_array($fid,$mplay['forums'])){
			dheader('location: forum.php?mod=viewthread&tid='.$attach['tid']);
			dexit();
		}			
	}

	function viewthread_postbottom_mobile_output() {			
		require_once DISCUZ_ROOT . './source/plugin/v2_mediaplay/touch.core.php';	
	}
}