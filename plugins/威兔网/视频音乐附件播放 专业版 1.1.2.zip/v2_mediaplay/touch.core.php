<?php

	if (!defined("IN_DISCUZ") || !is_dir("./source/plugin/v2_mediaplay")) {
		echo "Access Deined";
		return 0;
	}
	global $_G;
	global $postlist;
	if (empty($_G["cache"]["plugin"])) {
		loadcache("plugin");
	}
	$_var_2 = $_G["cache"]["plugin"]["v2_mediaplay"];
	$_var_3 = unserialize($_var_2["forums"]);
	$_var_4 = unserialize($_var_2["groups"]);
	$_var_5 = explode("|", $_var_2["video_en"]);
	$_var_6 = explode("|", $_var_2["audio_en"]);
	$_var_7 = $_var_2["mediatouchwidth"];
	$_var_8 = $_var_2["mediaheight"];
	$_var_9 = $_var_2["mediawarning"];
	$_var_10 = $_var_2["mediavolume"];
	$_var_11 = $_var_2["mediavideoct"];
	$_var_12 = $_var_2["mediaaudioct"];
	$_var_13 = $_var_2["mediabg"];
	$_var_14 = $_var_2["mediaimg"];
	if (!in_array($_G["fid"], $_var_3)) {
		return NULL;
	}
	foreach ($postlist as $_var_15 => $_var_16) {
		if (!$_var_16["first"] && $_var_2["onlythread"]) {
			return NULL;
		}
		if (!in_array($_var_16["groupid"], $_var_4)) {
			return NULL;
		}
		$_var_17 = "/<div id=\\\"attach_(\\d+)([\\s\\S]+?)<a href=\\\"(.*?)\\\"([\\s\\S]+?)<\\/div>/";
		$_var_18 = $_var_16["message"];
		preg_match_all($_var_17, $_var_18, $_var_19);
		$_var_20 = $_var_16["attachments"];
		$_var_21 = 0;
		$_var_19[1] = array_flip($_var_19[1]);
		foreach ($_var_20 as $_var_22 => $_var_23) {
			if (in_array($_var_23["ext"], $_var_5)) {
				$_var_24 = substr(md5($_var_23["attachment"]), 11, 10);
				$_var_25 = $_var_23["price"];
				$_var_26 = $_var_23["payed"];
				$_var_27 = $_var_23["readperm"];
				if (!$_var_26 && $_var_25 && $_G["uid"] || $_var_26 && $_var_25 && !$_G["uid"]) {
					if ($_var_2["ignorerule"]) {
						$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
					} else {
						continue;
					}
				} else {
					if ($_var_27 && $_G["cache"]["usergroups"][$_G["member"]["groupid"]]["readaccess"] < $_var_27 || $_var_27 && !$_G["uid"]) {
						if ($_var_2["ignorerule"]) {
							$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
						} else {
							continue;
						}
					} else {
						$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
					}
				}
				$_var_29 = "<video id=\"" . $_var_24 . "\" poster=\"" . $_var_14 . "\" " . $_var_11 . " style=\"width:" . $_var_7 . ";height:" . $_var_8 . ";background:" . $_var_13 . ";\" class=\"videostyle\"><source src=\"" . $_var_28[$_var_22] . "\" type=\"video/ogg\"><source src=\"" . $_var_28[$_var_22] . "\" type=\"video/mp4\">" . $_var_9 . "</video>\r\n<script type=\"text/javascript\">document.getElementById(\"" . $_var_24 . "\").volume = " . $_var_10 . ";</script>";
				$_var_30[$_var_22] = $_var_29;
				$_var_18 = str_replace($_var_19[0][$_var_19[1][$_var_22]], $_var_30[$_var_22], $_var_18);
				$_var_29 = NULL;
				$_var_22 = NULL;
				$_var_21 = $_var_21 + 1;
			} else {
				if (in_array($_var_23["ext"], $_var_6)) {
					$_var_24 = substr(md5($_var_23["attachment"]), 11, 10);
					$_var_25 = $_var_23["price"];
					$_var_26 = $_var_23["payed"];
					$_var_27 = $_var_23["readperm"];
					if (!$_var_26 && $_var_25 && $_G["uid"] || $_var_26 && $_var_25 && !$_G["uid"]) {
						if ($_var_2["ignorerule"]) {
							$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
						} else {
							continue;
						}
					} else {
						if ($_var_27 && $_G["cache"]["usergroups"][$_G["member"]["groupid"]]["readaccess"] < $_var_27 || $_var_27 && !$_G["uid"]) {
							if ($_var_2["ignorerule"]) {
								$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
							} else {
								continue;
							}
						} else {
							$_var_28[$_var_22] = $_var_23["url"] . $_var_23["attachment"];
						}
					}
					$_var_29 = "<audio id=\"" . $_var_24 . "\" src=\"" . $_var_28[$_var_22] . "\" " . $_var_12 . " style=\"width:" . $_var_7 . ";\" class=\"audiostyle\"><source src=\"" . $_var_28[$_var_22] . "\" type=\"audio/ogg\"><source src=\"" . $_var_28[$_var_22] . "\" type=\"audio/mpeg\">" . $_var_9 . "</audio>\r\n<script type=\"text/javascript\">document.getElementById(\"" . $_var_24 . "\").volume = " . $_var_10 . ";</script>";
					$_var_30[$_var_22] = $_var_29;
					$_var_18 = str_replace($_var_19[0][$_var_19[1][$_var_22]], $_var_30[$_var_22], $_var_18);
					$_var_29 = NULL;
					$_var_22 = NULL;
					$_var_21 = $_var_21 + 1;
				}
			}
		}
		$postlist[$_var_15]["message"] = $_var_18;
	}