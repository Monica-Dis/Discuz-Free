<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$more = "https://dism.taobao.com";
$addon = dfsockopen($more, 0, $dism, '', false, '', 120);
if ($addon) {
	$addon = iconv("gbk", CHARSET, $addon);
	echo $addon;
}