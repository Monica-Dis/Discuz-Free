<?php

function istype($_arg_0, $_arg_1)
{
	return preg_match("/" . $_arg_0 . "/i", $_arg_1, $_var_2);
}
function get_type($_arg_0)
{
	$_var_1 = array("qq" => "video.qq.com", "qq2" => "imgcache.qq.com", "qq3" => "v.qq.com\\/x\\/page", "qq4" => "v.qq.com\\/x\\/cover", "qq5" => "m.v.qq.com\\/play.html", "qq6" => "m.v.qq.com\\/page", "qq7" => "v.qq.com\\/iframe", "qq8" => "m.v.qq.com\\/play\\/play.html", "qq9" => "yoo.qq.com\\/m\\/video.html", "old_youku" => "youku.com\\/player.php", "youkuframe" => "src=\\'http:\\/\\/player.youku.com", "youku" => "player.youku.com", "youku2" => "youku.com", "tudou" => "tudou.com\\/v", "bilibili_iframe" => "player.bilibili.com", "bilibili_bv" => "bilibili.com\\/video\\/BV", "bilibili" => "bilibili.com", "acfun" => "m.acfun.cn", "acfun1" => "www.acfun.cn", "iqiyi" => "open.iqiyi.com", "iqiyi2" => "www.iqiyi.com", "ku6" => "ku6.com", "dji" => "djivideos.com", "sohu" => "my.tv.sohu.com", "sohu1" => "m.56.com", "sohu2" => "tv.sohu.com\\/s\\/", "sohu3" => "m.tv.sohu.com\\/sugs", "sohu4" => "m.tv.sohu.com\\/svs", "sohu5" => "m.tv.sohu.com", "sohu6" => "tv.sohu.com\\/upload", "cloudmusic0" => "163.com\\/#\\/song\\?id=", "cloudmusic1" => "163.com\\/song\\?id=", "cloudmusic2" => "163.com\\/song\\/", "cloudmusic3" => "163.com\\/m\\/song\\?id=", "cloudmusic4" => "163.com\\/#\\/outchain\\/2", "cloudmusic5" => "163.com\\/m\\/program\\?id=", "cloudmusic6" => "163.com\\/#\\/program\\?id=", "cloudmusic7" => "163.com\\/#\\/outchain\\/3", "cloudmusic8" => "163.com\\/#\\/outchain\\/4", "cloudmusic9" => "163.com\\/radio\\?id=", "cloudmusic10" => "163.com\\/m\\/radio\\?id=", "cloudmusic11" => "163.com\\/#\\/playlist\\?id=", "cloudmusic12" => "163.com\\/playlist\\/", "cloudmusic13" => "163.com\\/m\\/playlist\\?id=", "cloudmusic14" => "163.com\\/#\\/outchain\\/0", "ximalaya" => "ximalaya.com\\/thirdparty\\/player\\/", "ximalaya1" => "m.ximalaya.com\\/sound", "ximalaya2" => "m.ximalaya.com\\/album", "ximalaya3" => "m.ximalaya.com\\/share\\/", "ximalaya4" => "ximalaya.com\\/", "youtube" => "youtube.com\\/watch", "youtube1" => "youtube.com\\/v\\/", "youtube2" => "youtu.be\\/", "miaopai1" => "v.miaopai.com", "miaopai2" => "www.miaopai.com", "mp3" => "\\.mp3", "wav" => "\\.wav", "m4a" => "\\.m4a");
	foreach ($_var_1 as $_var_2 => $_var_3) {
		if (istype($_var_3, $_arg_0)) {
			return $_var_2;
		}
	}
	return 0;
}
function get_embed($_arg_0, $_arg_1, $_arg_2)
{
	do {

		global $_G;
		$_var_4 = $_G["cache"]["plugin"]["v2_mediaplus"]["videocontrol"];
		$_var_5 = $_G["cache"]["plugin"]["v2_mediaplus"]["audiocontrol"];
		if (defined("IN_MOBILE")) {
			$_var_6 = $_G["cache"]["plugin"]["v2_mediaplus"]["awidth_touch"];
		} else {
			$_var_6 = $_G["cache"]["plugin"]["v2_mediaplus"]["awidth_pc"];
			$_var_7 = "txp/";
		}
		if ($_arg_0 == "mp4") {
			return returndata($_arg_1, $_arg_2);
		}
		if ($_arg_0 == "qq") {
			$_var_8 = explode("vid=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq2") {
			$_var_8 = explode("vid=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq3") {
			$_var_8 = explode("x/page/", $_arg_1);
			$_var_8 = explode(".html", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq4") {
			$_var_8 = explode("x/cover/", $_arg_1);
			$_var_8 = explode(".html", $_var_8[1]);
			$_var_8 = explode("/", $_var_8[0]);
			$_var_8 = $_var_8[1];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq5") {
			$_var_8 = explode("vid=", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq6") {
			$_var_8 = explode(".html?ptag=", $_arg_1);
			$_var_8 = substr($_var_8[0], -11);
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq7") {
			$_var_8 = explode("vid=", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq8") {
			$_var_8 = explode("vid=", $_arg_1);
			$_var_8 = explode("&ptag", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "qq9") {
			$_var_8 = explode("id=", $_arg_1);
			$_var_8 = explode("&hgptag", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.qq.com/" . $_var_7 . "iframe/player.html?vid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "youku") {
			$_var_8 = explode("embed/", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe src=\"https://player.youku.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "youku2") {
			$_var_8 = explode("/id_", $_arg_1);
			$_var_8 = explode(".html", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://player.youku.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "old_youku") {
			$_var_8 = explode("/sid/", $_arg_1);
			$_var_8 = explode("/v.swf", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://player.youku.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "youkuframe") {
			$_var_8 = explode("/embed/", $_arg_1);
			$_var_8 = explode("==", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://player.youku.com/embed/" . $_var_8 . "==\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "tudou") {
			$_var_8 = explode("/v/", $_arg_1);
			$_var_8 = explode("==", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://player.youku.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "bilibili_iframe") {
			$_var_8 = explode("aid=", $_arg_1);
			$_var_8 = explode("\"", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://player.bilibili.com/player.html?aid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "bilibili_bv") {
			$_var_9 = "|(\\w+\\d+\\w+)|";
			preg_match($_var_9, $_arg_1, $_var_10);
			$_var_8 = $_var_10[1];
			return "<iframe src=\"https://player.bilibili.com/player.html?bvid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "bilibili") {
			$_var_9 = "|(\\d+)|";
			preg_match($_var_9, $_arg_1, $_var_10);
			$_var_8 = $_var_10[1];
			return "<iframe src=\"https://player.bilibili.com/player.html?aid=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "sohu") {
			$_var_8 = explode("/us/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = explode(".shtml", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "sohu1") {
			$_var_8 = explode("/v", $_arg_1);
			$_var_8 = explode(".shtml", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "sohu2") {
			if (strpos($_arg_1, "bid=") !== false) {
				$_var_8 = explode("bid=", $_arg_1);
				$_var_8 = explode("&", $_var_8[1]);
				$_var_8 = $_var_8[0];
				return "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?bid=" . $_var_8 . "&autoplay=false&disablePlaylist=false\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
			}
			if (strpos($_arg_1, "vid=") !== false) {
				$_var_8 = explode("vid=", $_arg_1);
				$_var_8 = explode("&", $_var_8[1]);
				$_var_8 = $_var_8[0];
				return "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?vid=" . $_var_8 . "&autoplay=false&disablePlaylist=false\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
			}
			break;
		}
		if ($_arg_0 == "sohu3") {
			$_var_8 = explode("sugs/sv", $_arg_1);
			$_var_8 = explode(".shtml", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?bid=" . $_var_8 . "&autoplay=false&disablePlaylist=false\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "sohu4") {
			$_var_8 = explode("svs/sv", $_arg_1);
			$_var_8 = explode(".shtml", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?vid=" . $_var_8 . "&autoplay=false&disablePlaylist=false\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "sohu5") {
			$_var_8 = explode("/v", $_arg_1);
			$_var_8 = explode(".shtml", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "acfun") {
			$_var_8 = explode("ac=", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe src=\"https://www.acfun.cn/player/ac" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "acfun1") {
			$_var_8 = explode("/ac", $_arg_1);
			$_var_8 = explode("\"", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://www.acfun.cn/player/ac" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "ku6") {
			return "<embed src=\"" . $_arg_1 . "\" " . $_arg_2 . " quality=\"high\" align=\"middle\" allowscriptaccess=\"always\" allowfullscreen=\"true\" type=\"application/x-shockwave-flash\" flashvars=\"\"></embed>";
		}
		if ($_arg_0 == "cloudmusic0") {
			$_var_8 = explode("/song?id=", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<audio src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "cloudmusic1") {
			$_var_8 = explode("/song?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<audio src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "cloudmusic2") {
			$_var_8 = explode("/song/", $_arg_1);
			$_var_8 = explode("/?userid=", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<audio src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "cloudmusic3") {
			$_var_8 = explode("/song?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<audio src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "cloudmusic4") {
			$_var_8 = explode("outchain/2/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<audio src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $_var_8 . ".mp3\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "cloudmusic5") {
			$_var_8 = explode("/program?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $_var_8 . "&auto=0&height=66\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic6") {
			$_var_8 = explode("/program?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $_var_8 . "&auto=0&height=66\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic7") {
			$_var_8 = explode("outchain/3/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $_var_8 . "&auto=0&height=66\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic8") {
			$_var_8 = explode("outchain/4/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=4&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic9") {
			$_var_8 = explode("/radio?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=4&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic10") {
			$_var_8 = explode("/radio?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=4&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic11") {
			$_var_8 = explode("/playlist?id=", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=0&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic12") {
			$_var_8 = explode("/playlist/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=0&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic13") {
			$_var_8 = explode("/playlist?id=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=0&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "cloudmusic14") {
			$_var_8 = explode("outchain/0/", $_arg_1);
			$_var_8 = explode("/", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=\"" . $_var_6 . "\" height=\"450\" src=\"//music.163.com/outchain/player?type=0&id=" . $_var_8 . "&auto=0&height=430\"></iframe>";
		}
		if ($_arg_0 == "ximalaya") {
			$_var_9 = "/(\\d+)/";
			preg_match($_var_9, $_arg_1, $_var_10);
			$_var_8 = $_var_10[1];
			if (strpos($_arg_1, "sound") !== false) {
				return "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
			}
			if (strpos($_arg_1, "album") !== false) {
				return "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
			}
			break;
		}
		if ($_arg_0 == "ximalaya1") {
			$_var_8 = explode("/sound/", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
		}
		if ($_arg_0 == "ximalaya2") {
			$_var_8 = explode("/album/", $_arg_1);
			$_var_8 = $_var_8[1];
			return "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
		}
		if ($_arg_0 == "ximalaya3") {
			$_var_9 = "/(\\d+)/";
			preg_match($_var_9, $_arg_1, $_var_10);
			$_var_8 = $_var_10[1];
			if (strpos($_arg_1, "sound") !== false) {
				return "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
			}
			if (strpos($_arg_1, "album") !== false) {
				return "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
			}
			break;
		}
		if ($_arg_0 == "ximalaya4") {
			preg_match_all("/[0-9]{1}/", $_arg_1, $_var_11);
			if (count($_var_11[0]) > 12) {
				$_var_9 = "/(\\d+)\$/";
			} else {
				$_var_9 = "/(\\d+)/";
			}
			preg_match($_var_9, $_arg_1, $_var_10);
			$_var_8 = $_var_10[1];
			if (count($_var_11[0]) > 12) {
				return "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
			}
			return "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $_var_8 . "&type=red\" frameborder=0 allowfullscreen></iframe>";
		}
		if ($_arg_0 == "youtube") {
			$_var_8 = explode("/watch?v=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://www.youtube.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "youtube1") {
			$_var_8 = explode("/v/", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://www.youtube.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "youtube2") {
			$_var_8 = explode("youtu.be/", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://www.youtube.com/embed/" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\"></iframe>";
		}
		if ($_arg_0 == "miaopai1") {
			$_var_8 = explode("iframe?scid=", $_arg_1);
			$_var_8 = explode("__", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.miaopai.com/iframe?scid=" . $_var_8 . "__\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
		}
		if ($_arg_0 == "miaopai2") {
			$_var_8 = explode("/show/", $_arg_1);
			$_var_8 = explode("__", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://v.miaopai.com/iframe?scid=" . $_var_8 . "__\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
		}
		if ($_arg_0 == "iqiyi") {
			$_var_8 = explode("tvId=", $_arg_1);
			$_var_8 = explode("&", $_var_8[1]);
			$_var_8 = $_var_8[0];
			return "<iframe src=\"https://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=" . $_var_8 . "&tvId=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
		}
		if ($_arg_0 == "iqiyi2") {
			$_var_12 = curl_init();
			curl_setopt($_var_12, CURLOPT_URL, $_arg_1);
			curl_setopt($_var_12, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($_var_12, CURLOPT_TIMEOUT, 5);
			$_var_13 = curl_exec($_var_12);
			curl_close($_var_12);
			$_var_14 = "/player\\?tvid=(.*?)&aid.*?/ism";
			if (preg_match_all($_var_14, $_var_13, $_var_15)) {
				$_var_8 = $_var_15[1][0];
			}
			return "<iframe src=\"https://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=" . $_var_8 . "&tvId=" . $_var_8 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
		}
		if ($_arg_0 == "mp3") {
			return "<audio src=\"" . $_arg_1 . "\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"" . $_arg_1 . "\" type=\"audio/ogg\"><source src=\"" . $_arg_1 . "\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "wav") {
			return "<audio src=\"" . $_arg_1 . "\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"" . $_arg_1 . "\" type=\"audio/ogg\"><source src=\"" . $_arg_1 . "\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		if ($_arg_0 == "m4a") {
			return "<audio src=\"" . $_arg_1 . "\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" " . $_var_5 . " style=\"width:" . $_var_6 . ";\" class=\"audiostyles\" ><source src=\"" . $_arg_1 . "\" type=\"audio/ogg\"><source src=\"" . $_arg_1 . "\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
		}
		return "<iframe src=\"" . $_arg_1 . "\" " . $_arg_2 . " frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
	} while(false);
}
function xmldata($_arg_0)
{
	$_var_1 = file_get_contents($_arg_0);
	$_var_2 = simplexml_load_string($_var_1);
	$_var_3 = count($_var_2->children()) - 1;
	$_var_4 = 0;
	while ($_var_4 <= $_var_3) {
		foreach ($_var_2->video[$_var_4]->files->file as $_var_5) {
			foreach ($_var_5 as $_var_6) {
				if ($_var_5->ftype == "mp4") {
					$_var_7['' . $_var_5 . "->seconds"][url] = $_var_5->furl;
					$_var_7['' . $_var_5 . "->seconds"][date] = strtotime($_var_5->time);
				}
			}
		}
		$_var_4 = $_var_4 + 1;
	}
	$_var_4 = 0;
	while ($_var_4 <= count($_var_7)) {
		$_var_8 = array();
		foreach ($_var_7 as $_var_5 => $_var_6) {
			$_var_8[$_var_5] = $_var_6["date"];
		}
		$_var_4 = $_var_4 + 1;
	}
	return $_var_7[array_search(max($_var_8), $_var_8)][url];
}
function returndata($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = $_G["cache"]["plugin"]["v2_mediaplus"]["videocontrol"];
	$_var_4 = $_G["cache"]["plugin"]["v2_mediaplus"]["audiocontrol"];
	if (defined("IN_MOBILE")) {
		$_var_5 = $_G["cache"]["plugin"]["v2_mediaplus"]["awidth_touch"];
	} else {
		$_var_5 = $_G["cache"]["plugin"]["v2_mediaplus"]["awidth_pc"];
	}
	if (stripos($_arg_0, ".mp3") !== false || stripos($_arg_0, ".wav") !== false || stripos($_arg_0, ".m4a") !== false) {
		return "<audio src=\"" . $_arg_0 . "\" id=\"audio_" . substr(md5($_arg_0), 14, 10) . "\" " . $_var_4 . " style=\"width:" . $_var_5 . ";\" class=\"audiostyles\" ><source src=\"" . $_arg_0 . "\" type=\"audio/ogg\"><source src=\"" . $_arg_0 . "\" type=\"audio/mpeg\"><p class=\"showhide\">your browser does not support this tag</p></audio>";
	}
	return "<video id=\"video_" . substr(md5($_arg_0), 14, 10) . "\" " . $_arg_1 . " " . $_var_3 . " ><source src=\"" . $_arg_0 . "\" type=\"video/ogg\" /><source src=\"" . $_arg_0 . "\" type=\"video/mp4\" /><p class=\"showhide\">your browser does not support this tag</p></video>";
}
function deal($_arg_0, $_arg_1)
{
	$_var_2 = preg_match_all("/\\[media.*?\\[\\/media\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[media.*?\\](.*)\\[\\/media\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, $_arg_1);
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	$_var_9 = preg_match_all("/\\[flash.*?\\[\\/flash\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[flash.*?\\](.*)\\[\\/flash\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, $_arg_1);
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	$_var_10 = preg_match_all("/\\[audio.*?\\[\\/audio\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[audio.*?\\](.*)\\[\\/audio\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, $_arg_1);
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ") || !is_dir("./source/plugin/v2_mediaplus")) {
		echo "Access Denied";
		return 0;
	}