<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/v2_mimageshow/mimageshow.core.php';

class mobileplugin_v2_mimageshow {	
	function discuzcode($param){
		global $_G;			
		if(empty($_G['cache']['plugin']))loadcache('plugin');
		$mimageshow = $_G['cache']['plugin']['v2_mimageshow'];
		if($mimageshow['imageshow'] == 1){
			if($param['caller'] == 'discuzcode' && in_array($_G['fid'], unserialize($mimageshow['selectforum']))){
				$_G['discuzcodemessage'] = ubbimage($_G['discuzcodemessage']);
				}
			}
		}
	}
//From: dis'.'m.tao'.'bao.com
?>