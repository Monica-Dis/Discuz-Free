<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
function ubbarray($_arg_0)
{
	$_var_1 = array("[img=", "[media=swf");
	$_var_2 = 0;
	while ($_var_2 < count($_var_1)) {
		$_var_3 = strpos($_arg_0, $_var_1[$_var_2]);
		$_var_2 = $_var_2 + 1;
	}
}
function ubbimage($_arg_0)
{
	$_var_1 = ubbstr($_arg_0, "[img", "[/img]", 0);
	foreach ($_var_1 as $_var_2) {
		$_var_3 = ubbstr($_var_2, "]", "[/", 1);
		$_var_4 = "<img src=\"" . $_var_3[0] . "\" alt=\"" . $_var_5["setting"]["bbname"] . "\" class=\"quoteimage\">";
		$_arg_0 = str_replace($_var_2, $_var_4, $_arg_0);
	}
	return $_arg_0;
}
function ubbstr($_arg_0, $_arg_1, $_arg_2, $_arg_3)
{
	$_var_4 = 0;
	$_var_5 = array();
	$_var_6 = strlen($_arg_0);
	while ($_var_4 <= $_var_6) {
		$_var_7 = strpos($_arg_0, $_arg_1, $_var_4);
		$_var_8 = strpos($_arg_0, $_arg_2, $_var_4);
		if ($_var_7 === false || $_var_8 === false) {
			break;
		}
		$_var_4 = $_var_8 + strlen($_arg_2);
		if ($_arg_3 == 1) {
			$_var_9 = substr($_arg_0, $_var_7 + strlen($_arg_1), $_var_8 - ($_var_7 + strlen($_arg_1)));
		} else {
			$_var_9 = substr($_arg_0, $_var_7, $_var_4 - $_var_7);
		}
		array_push($_var_5, $_var_9);
	}
	return $_var_5;
}

	if (!defined("IN_DISCUZ") || !is_dir("./source/plugin/v2_mimageshow")) {
		echo "Access Denied";
		return 0;
	}