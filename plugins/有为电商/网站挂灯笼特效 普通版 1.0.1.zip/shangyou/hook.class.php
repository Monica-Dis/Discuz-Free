<?php


if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    
    class plugin_shangyou {
	function global_footer(){
		global $_G;
		$config = $_G['cache']['plugin']['shangyou'];
		$denglong_txt1 = $config['denglong_txt1']?$config['denglong_txt1']:'default denglong_txt1';
		$denglong_txt2 = $config['denglong_txt2']?$config['denglong_txt2']:'default denglong_txt2';
		$denglong_txt3 = $config['denglong_txt3']?$config['denglong_txt3']:'88888888';
		$denglong_txt4 = $config['denglong_txt4']?$config['denglong_txt4']:'default denglong_txt4';
		$denglong_distance1 = $config['denglong_distance1']?$config['denglong_distance1']:'88888888';
		$denglong_distance2 = $config['denglong_distance2']?$config['denglong_distance2']:'default denglong_distance2';
		$denglong_distance3 = $config['denglong_distance3']?$config['denglong_distance3']:'default denglong_distance3';
		$denglong_distance4 = $config['denglong_distance4']?$config['denglong_distance4']:'default denglong_distance4';
		{
		    if ($config['open'])
			include template("shangyou:index");
            return $denglong;
		}
	}
	
}
 
?>