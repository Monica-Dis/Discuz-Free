<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/kyo_credit/config.php';
require_once libfile('function/misc');

	if(submitcheck("forumset")) {
		if(trim($_GET['delday']) && ($_GET['delday'] = daddslashes($_GET['delday'])) ) {
				$delday1 = explode(',', $_GET['delday']);
				$delday2 = "'".join("','", $delday1)."'";
				$nnhh = DB::query("DELETE FROM `".DB::table('kyo_credit_order')."` WHERE `orderid` IN({$delday2})");
			cpmsg("Del OK {$nnhh}", 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'succeed');
		} elseif($_GET['tuikuan_orderid'] = addslashes(trim(str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $_GET['tuikuan_orderid']))) ) {
					if($asdeds_1 = DB::fetch_first("SELECT * FROM `".DB::table('kyo_credit_order')."` WHERE `orderid`='{$_GET['tuikuan_orderid']}'")) {
						if($asdeds_1 && $asdeds_1['state'] == 2 && $asdeds_1['orderid2'] && $asdeds_1['orderidtrue'] && $asdeds_1['amount'] > 0 && $asdeds_1['zftime']) {
							if($asdeds_1['zftype'] == 1 || $asdeds_1['zftype'] == 2) {
								$data = array('payjs_order_id' => $asdeds_1['orderid2']);
								$data['sign'] = $kyo_credit_c->payjs_sign($data);
								$result = $kyo_credit_c->curlget_payapi('https://payjs.cn/api/refund', $data);
								$ret = json_decode($result, true);
								if(!$kyo_credit_c->payjs_checksign($ret, false) && ($ret['return_msg'] = dhtmlspecialchars($ret['return_msg']).'?')) cpmsg("Signtrue Error ".preg_replace('#[^0-9a-z\s[:punct:]]+#i', 'No_Use_Word', $ret['return_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'error', array(), '', TRUE, '', 600);
								if($ret && is_array($ret) && $ret['return_code'] == 1 && $ret['out_trade_no'] == $asdeds_1['orderid']) {
									$tuikuan_miaoshu = $_GET['tuikuan_miaoshu'] ? ':'.addslashes(trim(str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $_GET['tuikuan_miaoshu']))) : '';
									DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `state`=3,`uptime`=".(TIMESTAMP + 0).",`payuserinfo`=CONCAT(`payuserinfo`,'{$tuikuan_miaoshu}') WHERE `orderid`='{$_GET['tuikuan_orderid']}' LIMIT 1");
									$ret['return_msg'] = dhtmlspecialchars($ret['return_msg']);
									cpmsg("Success! ".preg_replace('#[^0-9a-z\s[:punct:]]+#i', 'No_Use_Word', $ret['return_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'succeed');							
								}else{
									$ret['return_msg'] = dhtmlspecialchars($ret['return_msg']);
									cpmsg("Error! ".preg_replace('#[^0-9a-z\s[:punct:]]+#i', 'No_Use_Word', $ret['return_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'error', array(), '', TRUE, '', 600);							
								}
		} elseif($asdeds_1['zftype'] == 3) {
			$data = array();
			$data['app_id'] = $kyo_credit['ali_appid'];
			$data['method'] = 'alipay.trade.refund';
			$data['format'] = 'JSON';
			$data['charset'] = 'utf-8';
			$data['sign_type'] = 'RSA2';
			$data['timestamp'] = date('Y-m-d H:i:s');
			$data['version'] = '1.0';
			$data2 = array();
			$data2['trade_no'] = $asdeds_1['orderidtrue'];
			$data2['refund_amount'] = $asdeds_1['amount'];
			ksort($data2);
			$data['biz_content'] = json_encode($data2);
			unset($data2);
			ksort($data);
			$data_signstr = urldecode(http_build_query(array_diff($data, array(''))));
			$data['sign'] = $kyo_credit_c->ali_sign($data_signstr);
			$result = $kyo_credit_c->curlget_payapi('https://openapi.alipay.com/gateway.do', $data);
			$ret = (array)json_decode(preg_replace('#[^0-9a-z\s[:punct:]]+#i', 'No_Use_Word', $result), true);
			$ret = $kyo_credit_c->kyo_encode_array($ret, 'utf-8', CHARSET);
			$ret = $ret['alipay_trade_refund_response'];
			if($ret['code'] != 10000 || $ret['refund_fee'] < $asdeds_1['amount']) cpmsg("code Error {$ret['code']} {$ret['refund_fee']}  ".strip_tags($ret['msg']).'='.strip_tags($ret['sub_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'error', array(), '', TRUE, '', 600);
			if($ret && is_array($ret) && $ret['code'] == 10000 && $ret['out_trade_no'] == $asdeds_1['orderid']) {
				$tuikuan_miaoshu = $_GET['tuikuan_miaoshu'] ? ':'.addslashes(trim(str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $_GET['tuikuan_miaoshu']))) : '';
				DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `state`=3,`uptime`=".(TIMESTAMP + 0).",`payuserinfo`=CONCAT(`payuserinfo`,'{$tuikuan_miaoshu}') WHERE `orderid`='{$_GET['tuikuan_orderid']}' LIMIT 1");
				cpmsg("Success! ".strip_tags($ret['msg']).'='.strip_tags($ret['sub_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'succeed');							
			}else{
				cpmsg("Error! ".strip_tags($ret['msg']).'='.strip_tags($ret['sub_msg']), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'error', array(), '', TRUE, '', 600);							
			}
		}
						}else{
							cpmsg(lang('plugin/kyo_credit', 'tuikuanorderno'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order', 'error', array(), '', TRUE, '', 600);							
						}
					}else{
						cpmsg("orderid not exists!", 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order&tuikuan_orderid='.$_GET['tuikuan_orderid'], 'error', array(), '', TRUE, '', 600);
					}
			
		}
	}
	$ppp = intval($_GET['ppp'])>0 ? min(intval($_GET['ppp']), 500) : 50;
    showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admin_order");
	echo lang('plugin/kyo_credit', 'listsn').': <input type="text" size="5" name="ppp" value="'.$ppp.'" style="" />';
	$allcount = $kyo_credit_c->count_orders($_GET['search_state']);
	showtableheader(lang('plugin/kyo_credit', 'dingdanliebiao')."({$allcount})");
	echo '<br/>'.lang('plugin/kyo_credit', 'delete').':<input size="50" type="text" name="delday" value="" placeholder="" /> &nbsp;'.lang('plugin/kyo_credit', 'deleteinfo').' 
	<br/>'.lang('plugin/kyo_credit', 'tuikuangaiorder').'orderid:<input size="25" type="text" name="tuikuan_orderid" value="'.$_GET['tuikuan_orderid'].'" />&nbsp; <input size="40" type="text" name="tuikuan_miaoshu" value="" placeholder="" /> '.lang('plugin/kyo_credit', 'tuikuaninfo').' 
	<br/><br/><input type="text" name="search_uid" value="'.$_GET['search_uid'].'" placeholder=" '.lang('plugin/kyo_credit', 'searchuid').'" /> &nbsp; 
	<input type="text" size="50" name="search_state" value="'.$_GET['search_state'].'" placeholder=" '.lang('plugin/kyo_credit', 'searchstate').'" /> &nbsp;&nbsp;
	<input type="text" size="50" name="search_zftype" value="'.$_GET['search_zftype'].'" placeholder=" '.lang('plugin/kyo_credit', 'searchtype').'" /> &nbsp;&nbsp; 
	<br/><input type="text" name="search_begintime" class="txt" value="'.$_GET['search_begintime'].'" onclick="if(!this.value) {var minetime = new Date(); this.value = minetime.getFullYear() + \'-\' + (minetime.getMonth() + 1) + \'-\' + minetime.getDate();}" placeholder=" '.lang('plugin/kyo_credit', 'begintime').'" /> &nbsp;&nbsp; 
	<input type="text" name="search_endtime" class="txt" value="'.$_GET['search_endtime'].'" onclick="if(!this.value) {var minetime = new Date(); this.value = minetime.getFullYear() + \'-\' + (minetime.getMonth() + 1) + \'-\' + minetime.getDate() + \' \' + (minetime.getHours() + 1) + \':00\';}" placeholder=" '.lang('plugin/kyo_credit', 'endtime').'" /><br/>';
	showsubmit('forumset', lang('plugin/kyo_credit', 'searchsubmit'), '', '');
    showsubtitle(array(lang('plugin/kyo_credit', 'time').'<br/>'.lang('plugin/kyo_credit', 'orderid'), lang('plugin/kyo_credit', 'user'), lang('plugin/kyo_credit', 'price'), lang('plugin/kyo_credit', 'zftype').' / '.lang('plugin/kyo_credit', 'state'), lang('plugin/kyo_credit', 'zftimeuptime'), lang('plugin/kyo_credit', 'orderid2').'<br/>'.lang('plugin/kyo_credit', 'orderidtrue'), 'IP<br/>Pay-User-info'));
	$tmpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=kyo_credit&pmod=admin_order&ppp='.$ppp.'&search_uid='.$_GET['search_uid'].'&search_state='.$_GET['search_state'].'&search_zftype='.$_GET['search_zftype'].'&search_begintime='.$_GET['search_begintime'].'&search_endtime='.$_GET['search_endtime'];
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($allcount, $ppp, $page, $tmpurl);
	echo $multipage;
	if($allcount) {
		$query = $kyo_credit_c->search_orders($startlimit, $ppp, $_GET['search_state']);
		foreach($query as $val) {
			$table = array();
			$table[0] = '<font color="'.($val['time']%2===1 ? 'hotpink' : '').'" title="'.lang('plugin/kyo_credit', 'pinkisphone').'">'.date('y-n-j G:i', $val['time']).($val['time']%2===1 ? ' (phone)' : '').'</font><br/>'.$val['orderid'];
			$table[1] = "<a style=color:".($val['state']==1 ? 'darkgray' : ($val['state']==2 ? '' : 'deeppink'))."; href=home.php?mod=space&uid={$val['uid']} target=_blank>".DB::result_first("SELECT `username` FROM `".DB::table('common_member')."` WHERE `uid`={$val['uid']} LIMIT 1")."</a>";
			$table[2] = '&yen; '.$val['amount'];
			$table[3] = ($val['zftype']==1||$val['zftype']==3 ? ($val['zftype']==1 ? '<font color="royalblue">'.lang('plugin/kyo_credit', 'alipay').'</font>' : '<font color="royalblue">'.lang('plugin/kyo_credit', 'dangmianhu').'</font>') : ($val['zftype']==2 ? '<font color="royalblue">'.lang('plugin/kyo_credit', 'weixin').'</font>' : 'Other')).' / '.($val['state']==2 ? '<font color="#33CC33">'.lang('plugin/kyo_credit', 'yizihu').'</font>' : ($val['state']==1 ? '<font color="darkgray">'.lang('plugin/kyo_credit', 'notpay').'</font>' : ($val['state']==0 ? '<font color="gray">'.lang('plugin/kyo_credit', 'jiandanfail').'</font>' : '<font color="#FF3333"><b>'.lang('plugin/kyo_credit', 'yituile').'</b></font>')));
			$table[4] = ($val['zftime'] ? date('n-j G:i:s', $val['zftime']) : '-').'<br/>'.($val['uptime'] ? date('n-j G:i:s', $val['uptime']) : '-');
			$table[5] = $val['orderid2'].'<br/>'.$val['orderidtrue'];
			$addresstmp = trim(convertip($val['ip']), '- ');
			$table[6] = $val['ip'].'<br/>'.$addresstmp.'<br/><font color="'.(preg_match('#complaint|\:#',$val['payuserinfo']) ? 'red' : '').'" title="'.lang('plugin/kyo_credit', 'userinfotisi').'">'.$val['payuserinfo'].'</font>';
			showtablerow('', array(), $table);
		}
	}
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dism _ taobao _com*/
