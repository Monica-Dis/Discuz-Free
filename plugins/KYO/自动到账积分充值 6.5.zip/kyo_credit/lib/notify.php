<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
error_reporting(0);
require_once '../../../class/class_core.php';
$discuz = C::app();
$discuz->init();
error_reporting(0);
loadcache('plugin');

if(!defined('IN_DISCUZ') || !$_G['cache']['plugin']['kyo_credit']['open']) {
	exit('Access Not Open');
}

require_once DISCUZ_ROOT."./source/plugin/kyo_credit/config.php";

if(isset($_POST['app_id']) && $_POST['app_id']) {
	$kyo_credit_c->ali_checksign($_POST);
	$_POST['return_code'] = $_POST['trade_no']&&(empty($_POST['trade_status'])||$_POST['trade_status']!=='WAIT_BUYER_PAY'&&$_POST['trade_status']!=='TRADE_CLOSED') ? 1 : 0;
	$_POST['total_fee'] = $_POST['total_amount'] ? $_POST['total_amount'] * 100  : 999999;
	$_POST['payjs_order_id'] = $_POST['trade_no'];
	$_POST['transaction_id'] = $_POST['trade_no'];
	$_POST['time_end'] = $_POST['gmt_payment'] ? $_POST['gmt_payment'] : date('Y-m-d H:i:s');
	$_POST['openid'] = $_POST['buyer_id'].'='.$_POST['buyer_logon_id'];
	$_POST['type'] = 'alipay';
}else{
	$kyo_credit_c->payjs_checksign($_POST);
}

foreach($_POST as $k=>$v) {
	$_GET[$k] = $v;
}

$orderdata = C::t('#kyo_credit#kyo_credit_order')->fetch(daddslashes($_POST['out_trade_no']));

if($orderdata && $_POST['return_code'] == 1 && ($_POST['total_fee'] >= $orderdata['amount'] * 100 || intval($_POST['total_fee']) >= intval($orderdata['amount']))  && $orderdata['state'] == 1) {

	updatemembercount($orderdata['uid'], array('extcredits'.$kyo_credit['credit'] => intval($orderdata['amount'] * $kyo_credit['multiple'])), 1, 'AFD', $orderdata['uid']);
	notification_add($orderdata['uid'], 'system', lang('plugin/kyo_credit', 'payokmss'), array(), 1);

	$orderdata['zftime'] = max(1, strtotime($_POST['time_end']));
	$orderdata['orderid2'] = preg_replace('#\'|"|\s|\<|\>#', '', $_POST['payjs_order_id']);
	$orderdata['orderidtrue'] = str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $_POST['transaction_id']);
	$orderdata['useropenid'] = str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $_POST['openid']);
	$kyo_credit_c->up_order_ok($orderdata);

$outstring = 'success';
header('Content-Encoding: Identity');
header('Content-Length: '.strval(ob_get_length() + strlen($outstring)));
header('Connection: Close');
echo $outstring;
ob_flush();
flush();

if($kyo_credit['alipay'] == 3 && ($alioldorder = DB::fetch_first("SELECT * FROM `".DB::table('kyo_credit_order')."` WHERE `time`>'".(TIMESTAMP - 86400*30)."' AND `time`<'".(TIMESTAMP - 300)."' AND `zftype`=3 AND `uptime`=0 AND `state`=1 AND `orderid2`='' AND `orderidtrue`='' ORDER BY `time` DESC LIMIT 1")) ) {
	DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `uptime`='".TIMESTAMP."' WHERE `orderid`='{$alioldorder['orderid']}' AND `uptime`=0 LIMIT 1");
	$data = array();
	$data['app_id'] = $kyo_credit['ali_appid'];
	$data['method'] = 'alipay.trade.query';
	$data['format'] = 'JSON';
	$data['charset'] = 'utf-8';
	$data['sign_type'] = 'RSA2';
	$data['timestamp'] = date('Y-m-d H:i:s');
	$data['version'] = '1.0';
	$data2 = array();
	$data2['out_trade_no'] = $alioldorder['orderid'];
	ksort($data2);
	$data['biz_content'] = json_encode($data2);
	unset($data2);
	ksort($data);
	$data_signstr = urldecode(http_build_query(array_diff($data, array(''))));
	$data['sign'] = $kyo_credit_c->ali_sign($data_signstr);
	$result = $kyo_credit_c->curlget_payapi('https://openapi.alipay.com/gateway.do', $data);
	$ret = (array)json_decode(preg_replace('#[^0-9a-z\s[:punct:]]#i', ' ', $result), true);
	$ret = $kyo_credit_c->kyo_encode_array($ret, 'utf-8', CHARSET);
	$ret = $ret['alipay_trade_query_response'];
	if($ret['code'] == 10000 && ($ret['trade_no'] = str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $ret['trade_no'])) && $ret['out_trade_no'] == $alioldorder['orderid']) {
		DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `orderid2`='{$ret['trade_no']}',`orderidtrue`='{$ret['trade_no']}',`payuserinfo`='".str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $ret['buyer_user_id'].'='.$ret['buyer_logon_id'])."' WHERE `orderid`='{$alioldorder['orderid']}' ORDER BY `time` DESC LIMIT 1");
	}
}

if($kyo_credit['payokmail']) {
	require_once libfile('function/mail');
	sendmail($kyo_credit['payokmail'], "UID {$orderdata['uid']} PAY {$orderdata['amount']} OK, at This Time", "UID {$orderdata['uid']} PAY {$orderdata['amount']} OK, at This Time");
}
	if($kyo_credit['adminmail'] && in_array($orderdata['zftype'], array(1, 2)) && in_array(date('G')%2, array(0, 1), true)) {
		$timehourbegin = strtotime(date('Y-m-d H:00:00'));
		if(DB::result_first("SELECT COUNT(*) FROM `".DB::table('kyo_credit_order')."` WHERE `zftime`>'{$timehourbegin}' AND `zftype` IN(1,2)") == 1) {
			$data = array('mchid' => $kyo_credit['payjs_id']);
			$data['sign'] = $kyo_credit_c->payjs_sign($data);
			$result = $kyo_credit_c->curlget_payapi('https://payjs.cn/api/complaint?'.http_build_query($data), array());
			$ret = json_decode($result, true);
			if($ret && is_array($ret) && $ret['return_code'] == 1 && $ret['complaints'] && is_array($ret['complaints']) ) {
				$isupnew = false;
				foreach($ret['complaints'] as $k => $v) {
					if($v['out_trade_no'] && ($xhyhxtrd1 = DB::fetch_first("SELECT * FROM `".DB::table('kyo_credit_order')."` WHERE `orderid`='".str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $v['out_trade_no'])."'")) ) {
						if(strpos($xhyhxtrd1['payuserinfo'], 'complaint') === false) {
							$isupnew = true;
							DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `payuserinfo`=CONCAT(`payuserinfo`,';complaint') WHERE `orderid`='{$xhyhxtrd1['orderid']}' LIMIT 1");
						}
					}
				}
				if($isupnew) {
					unset($ret['sign']);
					if(!function_exists('sendmail')) require_once libfile('function/mail');
					sendmail($kyo_credit['adminmail'], "credit have complaints [payjs] = tousu", "credit have complaints [payjs] = tousu");
				}
			}

			$data = array('mchid' => $kyo_credit['payjs_id']);
			$data['sign'] = $kyo_credit_c->payjs_sign($data);
			$result = $kyo_credit_c->curlget_payapi('https://payjs.cn/api/info?'.http_build_query($data), array());
			$ret = json_decode($result, true);
			if($ret && is_array($ret) && $ret['return_code'] == 1 && $ret['doudou'] < 200) {
				if(!function_exists('sendmail')) require_once libfile('function/mail');
				sendmail($kyo_credit['adminmail'], "credit doudou is less[payjs] = {$ret['doudou']}", "credit doudou is less[payjs] = {$ret['doudou']}");
			}
		}
	}
	exit;
} elseif($orderdata['state'] == 2) {
	exit('success');
}else{
	header('HTTP/1.1 503 Service Unavailable');
	exit(!$orderdata ? 'error1' : ($_POST['total_fee']<$orderdata['amount']*100 ? 'error2' : 'error3'));
}