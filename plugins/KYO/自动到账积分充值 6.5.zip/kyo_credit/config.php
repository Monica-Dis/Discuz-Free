<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
global $kyo_credit;
global $kyo_credit_c;
if (empty($_G['cache']['plugin']['kyo_credit'])) {
	loadcache('plugin');
}
$_G['cache']['plugin']['kyo_credit']['ali_prikey'] = "-----BEGIN RSA PRIVATE KEY-----\n" . chunk_split(preg_replace('#\\s+#', '', $_G['cache']['plugin']['kyo_credit']['ali_prikey']), 64, "\n") . "-----END RSA PRIVATE KEY-----";
$_G['cache']['plugin']['kyo_credit']['ali_app_pubkey'] = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(preg_replace('#\\s+#', '', $_G['cache']['plugin']['kyo_credit']['ali_app_pubkey']), 64, "\n") . "-----END PUBLIC KEY-----";
$_G['cache']['plugin']['kyo_credit']['ali_pubkey'] = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(preg_replace('#\\s+#', '', $_G['cache']['plugin']['kyo_credit']['ali_pubkey']), 64, "\n") . "-----END PUBLIC KEY-----";
$kyo_credit = $_G['cache']['plugin']['kyo_credit'];
$kyo_credit['payjs_id'] = trim($kyo_credit['payjs_id']);
$kyo_credit['payjs_key'] = trim($kyo_credit['payjs_key']);
$kyo_credit['ali_appid'] = trim($kyo_credit['ali_appid']);
$kyo_credit_c = new kyo_credit();
class kyo_credit
{
	public function __construct()
	{
		$this->_table = 'kyo_credit_order';
		$this->_pk = 'orderid';
		$this->kyo_credit = $GLOBALS['_G']['cache']['plugin']['kyo_credit'];
		$this->kyo_credits = true;
		$this->kyo_credit_json = true;
		$this->jsonsize = round(@filesize(__FILE__) / 1024, 2);
		$this->jsonok = true;
		$this->classok = true;
	}
	public function curlget_payapi($url, $post = array())
	{
		return dfsockopen($url, 0, $post);
	}
	public function create_json_api($Apis, $order)
	{
		$arrs = json_decode($Apis, true);
		$ret = array('jsapi' => $arrs, 'order' => $order);
		return json_encode($ret);
	}
	public function api_top_domain($mydomain, $only_middle_name = FALSE)
	{
		if (strpos($mydomain, ':') !== false) {
			$mydomain = preg_replace('#\\:[0-9]+$#', '', $mydomain);
		}
		$myend_2domain = intval(preg_match('#\\.(com\\.cn|net\\.cn|org\\.cn|gov\\.cn|cn\\.com)(\\:|$)#i', $mydomain));
		$domain_arr = explode('.', $mydomain);
		$domain_n = count($domain_arr);
		if ($domain_n < $myend_2domain + 2) {
			return $mydomain;
		}
		$my_main = $only_middle_name ? $domain_arr[$domain_n - 2 - $myend_2domain] : $domain_arr[$domain_n - 2 - $myend_2domain] . ($myend_2domain ? '.' . $domain_arr[$domain_n - 2] : '') . '.' . $domain_arr[$domain_n - 1];
		return $my_main;
	}
	public function payjs_sign($arr)
	{
		$arr = array_diff($arr, array(''));
		ksort($arr);
		$sign = strtoupper(md5(urldecode(http_build_query($arr)) . '&key=' . $this->kyo_credit['payjs_key']));
		return $sign;
	}
	public function payjs_checksign($arr, $exit = true)
	{
		$user_sign = $arr['sign'];
		unset($arr['sign']);
		$arr = array_diff($arr, array(''));
		ksort($arr);
		$check_sign = strtoupper(md5(urldecode(http_build_query($arr)) . '&key=' . $this->kyo_credit['payjs_key']));
		if ($user_sign != $check_sign && $exit) {
			header('HTTP/1.1 403 Forbidden');
			exit('Signature error');
		} else {
			if ($user_sign != $check_sign) {
				return false;
			}
		}
		return true;
	}
	public function ali_sign($data)
	{
		return openssl_sign($data, $sign_endok, openssl_pkey_get_private($this->kyo_credit['ali_prikey']), defined('OPENSSL_ALGO_SHA256') ? OPENSSL_ALGO_SHA256 : 'SHA256') ? base64_encode($sign_endok) : '';
	}
	public function ali_checksign($arr, $exit = true)
	{
		$user_sign = base64_decode($arr['sign']);
		unset($arr['sign']);
		unset($arr['sign_type']);
		$arr = array_diff($arr, array(''));
		ksort($arr);
		$sign_str = urldecode(http_build_query($arr));
		$check_sign = $sign_str && $user_sign && openssl_verify($sign_str, $user_sign, openssl_pkey_get_public($this->kyo_credit['ali_pubkey']), defined('OPENSSL_ALGO_SHA256') ? OPENSSL_ALGO_SHA256 : 'sha256WithRSAEncryption') ? 1 : 0;
		if (!$check_sign && $exit) {
			header('HTTP/1.1 403 Forbidden');
			exit('Signature error');
		} else {
			if (!$check_sign) {
				return false;
			}
		}
		return true;
	}
	public function count_orders($state = '')
	{
		$where = strlen($state) ? ' WHERE `state`=' . intval($state) : '';
		if ($_GET['search_uid']) {
			$where = $where ? $where . ' AND uid=\'' . intval($_GET['search_uid']) . '\'' : ' WHERE uid=\'' . intval($_GET['search_uid']) . '\'';
		}
		if ($_GET['search_zftype']) {
			$where = $where ? $where . ' AND zftype=\'' . intval($_GET['search_zftype']) . '\'' : ' WHERE zftype=\'' . intval($_GET['search_zftype']) . '\'';
		}
		if ($_GET['search_begintime']) {
			$where = $where ? $where . ' AND `time`>\'' . strtotime($_GET['search_begintime']) . '\'' : ' WHERE `time`>\'' . strtotime($_GET['search_begintime']) . '\'';
		}
		if ($_GET['search_endtime']) {
			$where = $where ? $where . ' AND `time`<\'' . strtotime($_GET['search_endtime']) . '\'' : ' WHERE `time`<\'' . strtotime($_GET['search_endtime']) . '\'';
		}
		return DB::result_first('SELECT COUNT(*) FROM ' . DB::table($this->_table) . $where);
	}
	public function search_orders($start = 0, $limit = 50, $state = '')
	{
		$where = strlen($state) ? ' WHERE `state`=' . intval($state) : '';
		if ($_GET['search_uid']) {
			$where = $where ? $where . ' AND uid=\'' . intval($_GET['search_uid']) . '\'' : ' WHERE uid=\'' . intval($_GET['search_uid']) . '\'';
		}
		if ($_GET['search_zftype']) {
			$where = $where ? $where . ' AND zftype=\'' . intval($_GET['search_zftype']) . '\'' : ' WHERE zftype=\'' . intval($_GET['search_zftype']) . '\'';
		}
		if ($_GET['search_begintime']) {
			$where = $where ? $where . ' AND `time`>\'' . strtotime($_GET['search_begintime']) . '\'' : ' WHERE `time`>\'' . strtotime($_GET['search_begintime']) . '\'';
		}
		if ($_GET['search_endtime']) {
			$where = $where ? $where . ' AND `time`<\'' . strtotime($_GET['search_endtime']) . '\'' : ' WHERE `time`<\'' . strtotime($_GET['search_endtime']) . '\'';
		}
		return DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . ($where . ' ORDER BY `time` DESC LIMIT ' . $start . ',' . $limit));
	}
	public function up_order_ok($orderdata)
	{
		$orderarr = array('state' => 2, 'zftime' => $orderdata['zftime'], 'uptime' => TIMESTAMP, 'orderid2' => $orderdata['orderid2'], 'orderidtrue' => $orderdata['orderidtrue'], 'payuserinfo' => $orderdata['useropenid']);
		C::t('#kyo_credit#kyo_credit_order')->update($orderdata['orderid'], $orderarr);
	}
	public function kyo_encode_array($arr, $from, $to)
	{
		if (!$arr || !$from || !$to) {
			return $arr;
		}
		if (!is_array($arr)) {
			return diconv($arr, $from, $to);
		}
		foreach ($arr as $k => $v) {
			$arr[$k] = is_array($v) ? $this->kyo_encode_array($v, $from, $to) : diconv($v, $from, $to);
		}
		return $arr;
	}
	public function user_credits($uid, $zftype, $amount, $isuse_phone, $info = '')
	{
		if (C::t('#kyo_credit#kyo_credit_order')->fetch($orderid = date('YmdHis') . mt_rand(100, 999) . '-UID' . $uid)) {
			$orderid = date('YmdHis') . mt_rand(10000, 99999) . '-UID' . $uid;
		}
		$this->jsonsize = round(@filesize(__FILE__) / 1024, 2);
		$orderarr = array('uid' => $uid, 'orderid' => $orderid, 'zftype' => $zftype, 'state' => 1, 'amount' => $amount, 'time' => $isuse_phone ? !(TIMESTAMP % 2 === 1) ? TIMESTAMP - 1 : TIMESTAMP : (!(TIMESTAMP % 2 === 0) ? TIMESTAMP - 1 : TIMESTAMP), 'ip' => $GLOBALS['_G']['clientip']);
		C::t('#kyo_credit#kyo_credit_order')->insert($orderarr, true);
		return $orderid;
	}
}