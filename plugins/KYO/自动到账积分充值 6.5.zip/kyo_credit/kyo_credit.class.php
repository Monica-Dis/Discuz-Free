<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_kyo_credit {

	function kyo_credit() {
		global $_G;
		$kyo_credit = $_G['cache']['plugin']['kyo_credit'];
		if($kyo_credit['open']) {
			return '<a href="home.php?mod=spacecp&ac=plugin&op=credit&id=kyo_credit:kyo_credit" onclick="return true; showWindow(\'kyo_credit\', this.href, \'get\', 0); return false;" style="color:'.$kyo_credit['linkcolor'].';" target="_blank">'.$kyo_credit['title'].'</a>';
		}else{
			return '';
		}
	}

	function global_cpnav_extra1() {
		global $_G;
		return $_G['cache']['plugin']['kyo_credit']['linktype']=='1' ? $this->kyo_credit() : '';
	}

	function global_cpnav_extra2() {
		global $_G;
		return $_G['cache']['plugin']['kyo_credit']['linktype']=='2' ? $this->kyo_credit() : '';
	}

	function global_usernav_extra3() {
		global $_G;
		return $_G['cache']['plugin']['kyo_credit']['linktype']=='3' ? $this->kyo_credit() : '';
	}

	function global_nav_extra() {
		global $_G;
		return $_G['cache']['plugin']['kyo_credit']['linktype']=='4' ? '<ul><li>'.$this->kyo_credit().'</li></ul>' : '';
	}
}

class plugin_kyo_credit_home extends plugin_kyo_credit {

	function spacecp_credit_extra() {
		return '<ul><li>'.$this->kyo_credit().'</li></ul>';
	}

}

class mobileplugin_kyo_credit extends plugin_kyo_credit {

	function global_header_mobile() {
		global $_G;
		if($_G['cache']['plugin']['kyo_credit']['linktype']) {
			return '<div '.($_G['cache']['plugin']['kyo_credit']['linktype']==2 ? 'style="float:right;"' : '').'><ul><li>'.$this->kyo_credit().'</li></ul></div>';
		}
		return '';
	}

}