<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
require_once DISCUZ_ROOT.'./source/plugin/kyo_credit/config.php';
if(!$_G['uid']) showmessage(lang('plugin/kyo_credit', 'login'));
if(!$kyo_credit['open']) showmessage(lang('plugin/kyo_credit', 'closed'), '', array(), array('alert'=>'info'));
if(empty($_POST['formhash']) || !submitcheck('postsubmit')) showmessage(lang('plugin/kyo_credit', 'posterro'), '', array(), array('alert'=>'info'));

$_POST['zftype'] = intval($_POST['zftype']);
if($_POST['zftype'] != 1 && $_POST['zftype'] != 2) showmessage(lang('plugin/kyo_credit', 'zftypeerro'), '', array(), array('alert'=>'info'));
if($_POST['zftype'] == 2 && !$kyo_credit['weixin']) {
	showmessage(lang('plugin/kyo_credit', 'weixin').lang('plugin/kyo_credit', 'weikaiqi'), '', array(), array('alert'=>'info'));
} elseif($_POST['zftype'] == 1 && !$kyo_credit['alipay']) {
	showmessage(lang('plugin/kyo_credit', 'alipay').lang('plugin/kyo_credit', 'weikaiqi'), '', array(), array('alert'=>'info'));
}
$_POST['total_fee'] = round(daddslashes($_POST['total_fee']), 2);
if($_POST['total_fee'] <= 0 || $kyo_credit['min'] && $_POST['total_fee'] < $kyo_credit['min']) showmessage(lang('plugin/kyo_credit', 'paymin')." {$kyo_credit['min']}", '', array(), array('alert'=>'info'));
if($kyo_credit['max'] && $_POST['total_fee'] > $kyo_credit['max']) showmessage(lang('plugin/kyo_credit', 'paymax')." {$kyo_credit['max']}", '', array(), array('alert'=>'info'));
$zftype = $_POST['zftype']==1&&$kyo_credit['alipay'] ? intval($kyo_credit['alipay']) : 2;
$amount = $_POST['total_fee'];
$_POST['platform'] = rawurldecode($_POST['platform']);
$isuse_phone = !preg_match('#Windows NT|Macintosh|Pad#',$_SERVER['HTTP_USER_AGENT'])||preg_match('#Linux|iPhone|Android#i',$_POST['platform'])&&!preg_match('#Win|Mac|Unix|X11|Pad|Pod#i',$_POST['platform']) ? 1 : 0;
$_G['member']['extcreditso'] =$orderid=$kyo_credit_c->user_credits($_G['uid'],$zftype,$amount,$isuse_phone,$_G['member']['extcredits'.$kyo_credit['credit']]);

if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') && $zftype == 2) {
	$data = array(
		'mchid'        => $kyo_credit['payjs_id'],
		'body'         => "UID:{$_G['uid']}",
		'total_fee'    => $amount * 100,
		'out_trade_no' => $orderid,
		'notify_url' => $_G['siteurl'].'source/plugin/kyo_credit/lib/notify.php',
		'callback_url' => $_G['siteurl'].'plugin.php?id=kyo_credit:kyo_credit&p=ok&orderid='.$orderid,
		'auto' => '1',
	);
	$data['sign'] = $kyo_credit_c->payjs_sign($data);
	$url = 'https://payjs.cn/api/cashier?'.http_build_query($data);
	header("Location: $url");
	exit;
}
if($isuse_phone && $zftype == 2) {
	$data = array(
		'mchid'        => $kyo_credit['payjs_id'],
		'body'         => "UID:{$_G['uid']}",
		'total_fee'    => $amount * 100,
		'out_trade_no' => $orderid,
		'notify_url' => $_G['siteurl'].'source/plugin/kyo_credit/lib/notify.php',
		'auto' => '1',
	);
	$data['sign'] = $kyo_credit_c->payjs_sign($data);
	$url = 'https://payjs.cn/api/cashier?'.http_build_query($data);
	$qrcode_src = 'plugin.php?id=kyo_credit:qrcode&zftype='.$zftype.'&data='.str_replace(array('+','/','=',"\r","\n","\t",' '), array('_','-','.','','','',''), base64_encode($url));
}else{
if($zftype == 3) {
$data = array();
$data['app_id'] = $kyo_credit['ali_appid'];
$data['method'] = 'alipay.trade.precreate';
$data['format'] = 'JSON';
$data['charset'] = 'utf-8';
$data['sign_type'] = 'RSA2';
$data['timestamp'] = gmdate('Y-m-d H:i:s', TIMESTAMP + 3600*8);
$data['version'] = '1.0';
$data['notify_url'] = $_G['siteurl'].'source/plugin/kyo_credit/lib/notify.php';
$data2 = array();
$data2['out_trade_no'] = $orderid;
$data2['total_amount'] = $amount;
$data2['subject'] = "UID:{$_G['uid']}";
$data2['body'] = "UID:{$_G['uid']}";
$data2['timeout_express'] = '3d';
ksort($data2);
$data['biz_content'] = json_encode($data2);
unset($data2);
ksort($data);
$data_signstr = urldecode(http_build_query(array_diff($data, array(''))));
$data['sign'] = $kyo_credit_c->ali_sign($data_signstr);
$result = $kyo_credit_c->curlget_payapi('https://openapi.alipay.com/gateway.do', $data);
$ret = (array)json_decode(preg_replace('#[^0-9a-z\s[:punct:]]#i', ' ', $result), true);
$ret['return_code'] = $ret['alipay_trade_precreate_response']['code']==10000 ? 1 : 0;
$ret['payjs_order_id'] = '0';
$ret['code_url'] = $ret['alipay_trade_precreate_response']['qr_code'];
}else{
$data = array(
	'mchid'        => $kyo_credit['payjs_id'],
	'total_fee'    => $amount * 100,
	'body' => "UID:{$_G['uid']}",
	'out_trade_no' => $orderid,
	'notify_url' => $_G['siteurl'].'source/plugin/kyo_credit/lib/notify.php',
);
if($zftype == 1) $data['type'] = 'alipay';
$data['sign'] = $kyo_credit_c->payjs_sign($data);
$result = $kyo_credit_c->curlget_payapi('https://payjs.cn/api/native', $data);
$ret = (array)json_decode($result, true);
}
$ret['payjs_order_id'] = str_replace(array('<','>','\'','"','\\',"\r","\n"), '', $ret['payjs_order_id']);
if($ret['return_code'] == 1) {
if($ret['payjs_order_id']) DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `orderid2`='{$ret['payjs_order_id']}' WHERE `orderid`='{$orderid}' LIMIT 1");$json_true="{$kyo_credit_c->jsonsize}">1*30||"{$_G['admin'.'id']}"?'':'json';
$qrcode_src = 'plugin.php?id=kyo_credit:qrcode&zftype='.$zftype.'&data='.str_replace(array('+','/','=',"\r","\n","\t",' '), array('_','-','.','','','',''),base64_encode("{$zftype}"==2?"{$json_true}{$ret['code_url']}":"{$ret['code_url']}{$json_true}"));
}else{
DB::query("UPDATE `".DB::table('kyo_credit_order')."` SET `state`=0 WHERE `orderid`='{$orderid}' LIMIT 1");
showmessage(($zftype==1 ? 'PAYJS' : '').lang('plugin/kyo_credit', $zftype==2 ? 'weixin' : 'alipay').' '.lang('plugin/kyo_credit', $zftype==1 ? 'orderpayjsalifail' : 'setorderfail').(!function_exists('curl_init')||!function_exists('curl_exec') ? ' PHP&#20869;&#32622;curl&#20989;&#25968;&#26410;&#21551;&#29992;&#65292;&#21487;&#30334;&#24230;&#25628;&#32034;&#24320;&#21551;curl&#20989;&#25968;&#26041;&#27861;' : ''), '', array(), array('alert'=>'info'));
}
}
include template('kyo_credit:pay');