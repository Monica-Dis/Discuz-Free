<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/kyo_credit/config.php';

if(preg_match('#Android|iPhone|Pad#', $_SERVER['HTTP_USER_AGENT']) && strpos($_G['PHP_SELF'], 'plugin.php') === false) {
	// dsetcookie('dismobilemessage', '1', 3600); $_G['cookie']['dismobilemessage'] = 1;
	dheader('Location: plugin.php?id=kyo_credit:kyo_credit&mobile=2&forcemobile=1');
	exit;
}

if(!$kyo_credit['open']) showmessage(lang('plugin/kyo_credit', 'closed'), '', array(), array('showmsg' => true, 'alert'=>'info'));

if(!$_G['uid']) showmessage(lang('plugin/kyo_credit', 'login'), '', array(), array('showmsg' => true, 'alert'=>'info'));

if(!empty($_GET['orderid']) && !is_array($_GET['orderid']) && isset($_GET['p']) && $_GET['p'] === 'ok') {
	if(!($myorder = C::t('#kyo_credit#kyo_credit_order')->fetch(daddslashes($_GET['orderid'])))) showmessage(lang('plugin/kyo_credit', 'noorderid'), '', array(), array('alert'=>'info'));
	showmessage(lang('plugin/kyo_credit', 'payoktisi')." {$_G['setting']['extcredits'][$kyo_credit['credit']]['title']}<font color=green><b>+".intval($myorder['amount'] * $kyo_credit['multiple']).'</b></font>', 'home.php?mod=spacecp&ac=credit&op=base', array(), array('alert'=>'right', 'refreshtime' => 5));
}else{
	$kyo_credit['information'] = str_replace(array("\r", "\n"), array('', '<br/>'), $kyo_credit['information']);
	if(strpos($_G['PHP_SELF'], 'plugin.php') !== false) include template('kyo_credit:kyo_credit');
}
