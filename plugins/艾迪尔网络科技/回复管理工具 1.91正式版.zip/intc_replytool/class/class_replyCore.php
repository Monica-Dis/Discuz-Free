<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

session_start();

class replyCore{
    private $tableid= null;
    private $tid	= null;
    private $authorid = null;
    private $useip = null;
    private $first = 0;
    
    public $page = 1;
    public $pagesize = 20;
    
    private $_pvars = array();
    
    public function __construct( $pvars = array() ){
    	$this->_pvars = $pvars;
    	$this->_getPageParams();
    }

    /**
     * �ظ��б���ȡ
     * @param number $invisible		����վ��ʾ|0�����ʾ���л��� 1����ʾ����վ�ڻ��� -2����˻���
     * @param array	 $manageFids	��������İ��
     * @return array()
     */
    public function postSearch($invisible='' , $manageFids = ''){
    	$invisible = ($invisible>0) ? 0 : $invisible;
    	
    	$keywords	= $_POST['postsearch'] ? trim($_POST['keywords']) : $_SESSION['keywords'];
    	$fids		= $_POST['postsearch'] ? $_POST['forumSel'] : $_SESSION['fid'];
    	$fids		= $this->getFid($fids , $manageFids);
    	$author		= $_POST['postsearch'] ? trim($_POST['author']) : $_SESSION['author'];
    	$this->useip= rtrim($_POST['authorip'] ? trim($_POST['authorip']) : $_SESSION['authorip'],'*');
    	$starttime	= $_POST['postsearch'] ? strtotime($_POST['searchStartTime']) : $_SESSION['starttime'];
    	$endtime	= $_POST['postsearch'] ? strtotime($_POST['searchStopTime']) : $_SESSION['endtime'];
    	
    	
    	if( !isset($_GET['showpic_num']) ){
    		$_GET['showpic_num'] = $this->_pvars['def_img_num'];//��ʾͼƬ����Ĭ��
    	}
    	
    	//
    	$start = $this->pagesize * ($this->page - 1);
    	$limit = $this->pagesize;
    	
    	$_POST['postsearch'] ? $this->writeToSession($keywords, $fids, $author, $starttime, $endtime) : '';
    	
    	$postlist = array(
    			'num' => 0,
    			'cont' => array()
    	);
    	$postlist['num']  = $this->count_by_search($this->tableid, $this->tid, $keywords, $invisible , $fids, $this->authorid, $author, $starttime , $endtime,'%'.($this->useip).'%',$this->first);
    	if($postlist['num'] > 0){
    		$postlist['cont'] = C::t('forum_post')->fetch_all_by_search($this->tableid, $this->tid, $keywords, $invisible , $fids, $this->authorid, $author, $starttime , $endtime,'%'.($this->useip).'%',$this->first,$start,$limit);
    		$postlist['cont'] = $this->_pvars['show_grouptitle'] == TRUE ? $this->postAddMemGroup($postlist['cont']) : $postlist['cont'];//�û�����ʾ�ж�
    	}
    	
    	if( $postlist['cont'] ){  			
    		$tids	= array_unique( $this->_i_array_column( $postlist['cont'] , 'tid' ) );
    		$threads= C::t('forum_thread')->fetch_all_by_tid($tids);
    		
    		if( $this->_pvars['allow_show_foruminfo'] ){    
    			$fids	= array_unique( $this->_i_array_column( $postlist['cont'] , 'fid' ) );
    			$forums	= C::t('forum_forum')->fetch_all_name_by_fid($fids);
    		}
    		
    		$censor = discuz_censor::instance();
    		$censor->highlight = '#f60';
    		
    		foreach( $postlist['cont'] as $k=>$post ){
    			$postlist['cont'][$k]['thread'] =  $threads[ $post['tid'] ];
    			$postlist['cont'][$k]['forum']  =  $forums[ $post['fid'] ];    			
    			
    			$postlist['cont'][$k]['censor'] =  $censor->check($post['message']);
    			
    			$post['message'] = $this->_parse_postmessage_code($post);
    			$postlist['cont'][$k]['message'] = cutstr($post['message'] , 300 , '..');  
    			
    			$postlist['cont'][$k]['pics'] = $this->_get_post_attach($post);
    		}
    	}
    	
    	return $postlist;
    }
    public function count_by_search($tableid, $tid = null, $keywords = null, $invisible = null, $fids = null, $authorid = null, $author = null, $starttime = null, $endtime = null, $useip = null, $first = null) {
    	$sql  = '';
    	$sql .= $tid		? ' AND '.DB::field('tid', $tid) : '';
    	$sql .= $authorid	? ' AND '.DB::field('authorid', $authorid) : '';
    	$sql .= ($invisible !== null) ? ' AND '.DB::field('invisible', $invisible) : '';
    	$sql .= ($first !== null) ? ' AND '.DB::field('first', $first) : '';
    	$sql .= $fids	? ' AND '.DB::field('fid', $fids) : '';
    	$sql .= $author ? ' AND '.DB::field('author', $author) : '';
    	$sql .= $starttime	? ' AND '.DB::field('dateline', $starttime, '>=') : '';
    	$sql .= $endtime	? ' AND '.DB::field('dateline', $endtime, '<') : '';
    	$sql .= $useip		? ' AND '.DB::field('useip', $useip, 'like') : '';
    	if(trim($keywords)) {
    		$sqlkeywords = $or = '';
    		foreach(explode(',', str_replace(' ', '', $keywords)) as $keyword) {
    			$keyword = addslashes($keyword);
    			$sqlkeywords .= " $or message LIKE '%$keyword%'";
    			$or = 'OR';
    		}
    		$sql .= " AND ($sqlkeywords)";
    	}
    	$count = DB::fetch_first('SELECT count(*) FROM %t WHERE 1 %i', array(C::t('forum_post')->get_tablename($tableid), $sql));
    	return current($count);
    }
    //�ظ�ɾ��
    public function postDel(){
    	if(submitcheck('delSubmit',1)){
    		include_once libfile('function/delete');
    		
    		//
    		$ids = $_POST['pidArray'];
    		$idtype = 'pid';
    		$credit = true;
    		$posttableid = false;
    		$recycle = false;
    		
    		//
    		if($_GET['toTrash'] == 'trash'){
    			$recycle = true;
    		}
    		if($_GET['subtract'] == 'noSubtract'){//ɾ���������û�����
    			$credit = false;
    		}
    		/* if(empty($_POST['toTrash']) && empty($_POST['subtract'])){
    			$idtype = true;
    		} */
    		
    		deletepost($ids,$idtype,$credit,$posttableid,$recycle);
    		
    	}
    }
    
    //�ظ����
    public function threadClear( $tids = 0 ){
    	global $_G;
    	if( $_G['group']['allowdelpost'] != 1 ){
    		return lang('plugin/intc_replytool','no_perm_tip');
    	}    	
    	
    	if($_G['adminid'] == 3){
    		$manageFids = C::t('forum_moderator')->fetch_all_by_uid($_G['uid']);
    		foreach($manageFids as $key=>$val){
    			$manageFidsId_Arr[] = $key;
    		}
    		
    		//�жϿ��������������
    		$this->_pvars['replyclear_forums'] = dunserialize($this->_pvars['replyclear_forums']);
    		$this->_pvars['replyclear_forums'] = array_intersect($this->_pvars['replyclear_forums'], $manageFidsId_Arr);
    		if( empty($this->_pvars['replyclear_forums']) ){
    			return '';
    		}
    	}
    	
    	
    	$tids = is_string($tids) ? explode(',', $tids) : $tids;
    	$threads = C::t('forum_thread')->fetch_all_by_tid($tids, 0, 0, $tableid = 0);//��֧�ֱַ�������$tableid��0
    	$pids = $fids = array();
    	foreach( $threads as $tid => $thread ){
    		if($_G['adminid'] == 3 && !in_array($thread['fid'], $this->_pvars['replyclear_forums']) ){
    			unset($threads[$tid]);
    			continue;
    		}
    		
    		//��ȡ�����pid
    		$threadpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
    		
    		//��ȡ���лظ�
    		$pids[ $tid ] = C::t('forum_post')->fetch_all_pid_by_tid_lastpid($tid,$threadpost['pid']);
    		$pids[ $tid ] = $this->_i_array_column($pids[ $tid ], 'pid');
    		
    		$fids[] = $thread['fid'];
    		$tids[] = $thread['tid'];
    	}
    	
    	if( empty($threads) ){
    		return;
    	}
    	
    	$fids = array_unique($fids);
    	$forum_threadcaches = DB::fetch_all('select fid,threadcaches from %t where %i', array('forum_forum',DB::field('fid', $fids)) , 'fid' );
    	//
    	$recycle = ($_GET['toTrash'] == 'trash') ? true : false;
    	$credit = ($_GET['subtract'] == 'noSubtract') ? false : true;
    	
    	require_once libfile('function/misc');
    	include_once libfile('function/post');
    	include_once libfile('function/delete');
    	
    	foreach( $threads as $tid => $thread ){
    		if( $pids[$tid] ){    			
    			deletepost($pids[$tid],'pid',$credit,$thread['posttableid'],$recycle);
    			updatethreadcount($thread['tid'], 1);
    			//updateforumcount($thread['fid'], 1);
    			
    			$forum_threadcaches[$thread['fid']]['threadcaches'] && deletethreadcaches($thread['tid']);			
    			
    			$modaction = 'DLP';
    			updatemodworks($modaction, count($pids[$tid]) );
    			modlog($thread, $modaction);
    		}
    	}
    	
    	C::t('forum_thread')->update($tids, array('moderated'=>1));
    }
    
    /**
     * ��ȡ�����ҳ�����
     */
    private function _getPageParams(){
    	$this->page = max(1, intval(getgpc('page')));
    	$this->page = $_GET['postsearch'] ? 1 : $this->page;
    	
    	$this->pagesize = intval(getgpc('pagesize'));
    	$this->pagesize = $this->pagesize ? $this->pagesize : $this->_pvars['pagesize'];
    }
    
    private function postAddMemGroup($postArr){
    	$groupArr = array();
    	global $_G;
    	loadcache('usergroups');
    	foreach($postArr as $key=>$post){
    		if(empty($groupArr[$post['authorid']])){
	    		$authorRes = DB::fetch_first('select groupid from '.DB::table('common_member').' where uid='.$post['authorid']);
	    		$grouptitle = $_G['cache']['usergroups'][$authorRes['groupid']]['grouptitle'];
	    		$groupArr[$post['authorid']] = $grouptitle;
    		}
    		$postArr[$key]['grouptitle'] = $groupArr[$post['authorid']];
    	}
    	return $postArr;
    }
    
    private function writeToSession($keywords = null , $fids = null , $author = null , $starttime = null , $endtime = null){
    	$_SESSION['keywords'] = $keywords;
    	$_SESSION['fid'] = $fids;
    	$_SESSION['author'] = $author;
    	$_SESSION['authorip'] = $this->useip;
    	$_SESSION['starttime'] = $starttime;
    	$_SESSION['endtime'] = $endtime;
    }
    
    private function getFid($fids , $manageFids = ''){
    	if($fids[0] == 'all'|| empty($fids)){
    		$fids = empty($manageFids) ? '' : $manageFids;
    	}else{
    		foreach($fids as $k=>$forumsel){
    			if( !is_numeric($forumsel) || ($forumsel<1) ){
    				unset( $fids[$k] );
    			}
    		}
    	}
    	return $fids;
    }
    
    /**
     * ��ȡ�������ݵ�ͼƬ
     * @param ���� $post
     * @return $pics	����ͼƬ����
     */
    private function _get_post_attach($post=array()){
    	global $_G;
    	
    	if($_GET['showpic_num']<=0 ){
    		return array();
    	}
    	
    	$tableid = substr($post['tid'], -1);
    	$pics = array();
    	foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$post['tid'],'pid', $post['pid'],'aid asc',1, false , FALSE , $_GET['showpic_num']) as $pic){
    		//��Ҫ�����������ӵ�Զ�̵�ַ
    		if($pic['remote']) {
    			$pic['attachment'] = strstr($pic['attachment'], 'http') ? $pic['attachment'] : $_G['setting']['ftp']['attachurl'].'forum/'.$pic['attachment'];
    		} else {
    			$pic['attachment'] = $_G['setting']['attachurl'].'forum/'.$pic['attachment'];
    		}
    		$pics[] = $pic;
    	}
    	
    	return (array) $pics;
    }
    
    private function _parse_postmessage_code($post){
    	if(strpos($post['message'], '[/quote]') !== FALSE) {
    		if( preg_match("/\[quote\].*\[color=#\d{1,}\](.*)\[\/color\]\[\/url\]\[\/size\](.*)\[\/quote\]/is", $post['message'] , $matchs ) ){
    			$post['quotetime'] = $matchs[1] ;
    			$post['quotetext'] = $matchs[2] ;
    		}elseif(preg_match("/\[quote\]\[color=#\d{1,}\](.*)\[\/color\].*\[color=#\d{1,}\](.*)\[\/color\]\[\/quote\]/is", $post['message'] , $matchs) ){
    			$post['quotetime'] = $matchs[1] ;
    			$post['quotetext'] = $matchs[2] ;
    		}
    		
    		$post['message'] = str_replace($matchs[0], '��'.$matchs[1].$matchs[2].'��', $post['message']);
    	}
    	return $post['message'];
    }
    
    private function _i_array_column($array, $columnKey, $indexKey = null){
    	if(!function_exists('array_column')){
    		$result = array();
    		foreach ($array as $subArray) {
    			if (is_null($indexKey) && array_key_exists($columnKey, $subArray)) {
    				$result[] = is_object($subArray)?$subArray->$columnKey: $subArray[$columnKey];
    			} elseif (array_key_exists($indexKey, $subArray)) {
    				if (is_null($columnKey)) {
    					$index = is_object($subArray)?$subArray->$indexKey: $subArray[$indexKey];
    					$result[$index] = $subArray;
    				} elseif (array_key_exists($columnKey, $subArray)) {
    					$index = is_object($subArray)?$subArray->$indexKey: $subArray[$indexKey];
    					$result[$index] = is_object($subArray)?$subArray->$columnKey: $subArray[$columnKey];
    				}
    			}
    		}
    		return $result;
    	}else{
    		return array_column($array, $columnKey, $indexKey);
    	}
    }
    
    function __destruct(){
        $this->tableid = NULL;
        $this->tid = NULL;
        $this->authorid = NULL;
        $this->useip = NULL;
        $this->first = NULL;
        
        $this->_pvars = array();
    }
}
//From: dis'.'m.tao'.'bao.com
?>