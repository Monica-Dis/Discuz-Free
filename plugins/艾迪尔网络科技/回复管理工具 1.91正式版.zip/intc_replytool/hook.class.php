<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_intc_replytool {
	private $_ident = 'intc_replytool';
	
	public function global_usernav_extra2(){
		global $_G;
		$allow_uids = $_G['cache']['plugin']['intc_replytool']['allow_uids'];
		$allow_uids = explode(',', $allow_uids);
		
		if(in_array($_G['uid'], $allow_uids)){
			$return = '<span class="pipe">|</span>';
			$return .= '<a href="forum.php?mod=modcp&action=plugin&op=tools&id=intc_replytool:replytoolfg" target="_blank">'.lang('plugin/intc_replytool', 'replytool').'</a> ';
			return $return;
		}
	}
	
	protected function _thread_show_clearBtn(){
		global $_G;
		if($_G['adminid'] < 1 || empty($_G['adminid']) || $_G['thread']['replies']<=0){
			return;
		}
		
		if( $_G['adminid'] == 3){
			if( empty($_G['forum']['ismoderator']) || $_G['forum']['ismoderator'] < 1 ){
				return;
			}			
			
			$pvars = $_G['cache']['plugin'][$this->_ident];
			$pvars['replyclear_forums'] = dunserialize($pvars['replyclear_forums']);
			if(empty($pvars['replyclear_forums']) || !in_array($_G['fid'], $pvars['replyclear_forums'])){
				return;
			}
		}
		
		//
		if( $_G['mobile'] ){
			$str  = '<link rel="stylesheet" type="text/css" href="./source/plugin/'.$this->_ident.'/static/css/style.css">';
			$str .= '<script src="./source/plugin/'.$this->_ident.'/static/m_ajax.min.js" type="text/javascript"></script>';
			$str .= '<a href="javascript:;" class="redbtn mt10 ml10 a_to_but" onclick="showWindow(\'mods\',\'plugin.php?id='.$this->_ident.':ajax&act=threadclearwin&hash='.FORMHASH.'&tid='.$_G['thread']['tid'] .'\')">' . lang('plugin/intc_replytool', 'replyclear') . '</a>';
			
		}else{			
			$str  = '<style>.a_to_but{padding:3px 5px;}.ml10{margin-left:10px;}.redbtn{background:#ea0000;border:1px solid #f65802;color:#fff !important;border-radius:5px;}</style>';
			$str .= '<a href="javascript:;" class="redbtn ml10 a_to_but" onclick="showWindow(\'mods\',\'plugin.php?id='.$this->_ident.':ajax&act=threadclearwin&hash='.FORMHASH.'&tid='.$_G['thread']['tid'] .'\')">' . lang('plugin/intc_replytool', 'replyclear') . '</a>';
		}
		
		return $str;
	}
}

class plugin_intc_replytool_forum extends plugin_intc_replytool {
	
	public function viewthread_title_extra(){
		
		return $this->_thread_show_clearBtn();
	}

}

class mobileplugin_intc_replytool {
}
class mobileplugin_intc_replytool_forum extends plugin_intc_replytool {
	public function viewthread_top_mobile(){
		
		return $this->_thread_show_clearBtn();		
	}
}
//From: dis'.'m.tao'.'bao.com
?>