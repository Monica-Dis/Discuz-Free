<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_rootadmin_qdy {
	function global_footer_mobile(){
		global $_G;
		$var = $_G['cache']['plugin']['rootadmin_qdy'];
		if($var['zzradio'] && IS_ROBOT) return; //蜘蛛访问结束
		if(!getcookie("rootadmin_qdy")){
            $jg=$var['jg'];
			$time=$jg;
			$tip = str_replace('{time}',$var['longtime'],$var['tip']);
			$js = str_replace('{time}','"+timelong+"',$var['tip']);
			include template("rootadmin_qdy:index");
			return $return;
		}else{return;}}
}