<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$tablename = DB::table('whotalk_member');

$uninstallsql = "DROP TABLE IF EXISTS {$tablename};";

runquery($uninstallsql);


$finish = TRUE;