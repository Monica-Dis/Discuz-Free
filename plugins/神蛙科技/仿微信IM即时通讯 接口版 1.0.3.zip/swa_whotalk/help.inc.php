<?php

/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G;

$pdf = "https://chat.gxit.org/addons/swa_supersale/plugin/whotalkcloud/static/discuz_plugin_readme.pdf";

include template('swa_whotalk:help');

?>