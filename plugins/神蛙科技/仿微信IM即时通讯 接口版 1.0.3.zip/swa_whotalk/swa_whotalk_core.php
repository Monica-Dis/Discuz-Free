<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!function_exists('getsetting')){
    function getsetting($setting=array()){
        if ($setting['profiles']){
            $setting['profiles'] = unserialize($setting['profiles']);
        }else{
            $setting['profiles'] = array();
        }
        return $setting;
    }
}

if (!function_exists('wavatar')){
    function wavatar($uid,$static=true){
        global $_G;
        $avatar = avatar($uid,'middle',true, false, $static);
        if (!$static) return $avatar;
        $avatar = str_replace($_G['setting']['discuzurl'],'',$avatar);
        if (file_exists(DISCUZ_ROOT.$avatar)){
            return  $_G['setting']['discuzurl'].$avatar;
        }else{
            return $_G['setting']['discuzurl'].'/uc_server/images/noavatar_middle.gif';
        }
    }
}

function error($errno, $message = '') {
    return array(
        'errno' => $errno,
        'message' => $message,
    );
}

function is_error($data) {
    if (empty($data) || !is_array($data) || !array_key_exists('errno', $data) || (array_key_exists('errno', $data) && 0 == $data['errno'])) {
        return false;
    } else {
        return true;
    }
}

function request_api($apiname,$data = array()){
    global $setting;
    $data['r'] = 'connect.'.$apiname;
    $data['noncestr'] = random(8);
    $data['token'] = md5($setting['apitoken'].$data['noncestr']);
    include_once libfile('swa_whotalk/http','plugin');
    $response = ihttp_post($setting['apiroot'],$data);
    if (is_error($response)) return $response;
    $result = json_decode($response['content'],true);
    if (isset($result['message']) && isset($result['type'])){
        if ($result['type']!='success') return error(-1,$result['message']);
        return $result['message'];
    }
    return $result;
}