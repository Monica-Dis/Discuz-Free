<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$tablename = DB::table('whotalk_member');

$installsql = <<<EOF
CREATE TABLE IF NOT EXISTS $tablename (
`id` mediumint(10) unsigned NOT NULL AUTO_INCREMENT,
`uniacid` int(11) NOT NULL DEFAULT '0' COMMENT '平台ID',
`uid` int(11) NOT NULL DEFAULT '0' COMMENT '站内UID',
`nickname` varchar(50) NOT NULL COMMENT '用户昵称',
`unionid` varchar(255) NOT NULL COMMENT 'WhotalkUID',
`status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
`addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
`dateline` int(11) NOT NULL DEFAULT '0' COMMENT '最后更新',
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOF;

runquery($installsql);


$finish = TRUE;