<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

global $_G,$pluginid;

include_once libfile('swa_whotalk/core','plugin');
loadcache('plugin');

$setting = getsetting($_G['cache']['plugin']['swa_whotalk']);
if (!$setting['uniacid']) cpmsg('未配置平台ID', 'action=plugins&operation=config&do='.$pluginid, 'error');
$setting['apihost'] = preg_replace("/\/$/",'',$setting['apihost']) . '/';

if ($_GET['remove']){
    if (trim($_GET['formhash']) != formhash()) {
        showmessage('submit_invalid');
    }
    $complete = DB::delete('whotalk_member',array('id'=>intval($_GET['remove']),'uniacid'=>intval($setting['uniacid'])),1);
    if (!$complete) cpmsg('删除失败，请重试', 'action=plugins&operation=config&do='.$pluginid, 'error');
    cpmsg('删除成功', 'action=plugins&operation=config&do='.$pluginid, 'succeed');
}

$page = max(intval($_GET['page']),1);
$limit = ' LIMIT ' . (($page-1)*15) . ',15';
$order = ' ORDER BY dateline DESC,addtime DESC';

$members = DB::fetch_all("SELECT * FROM %t WHERE uniacid=%d".$order.$limit,array('whotalk_member',intval($setting['uniacid'])));
$total = (int)DB::result_first("SELECT COUNT(*) FROM %t WHERE uniacid=%d",array('whotalk_member',intval($setting['uniacid'])));
$multipage = multi($total, $_G['setting']['memberperpage'], $page, ADMINSCRIPT."?action=plugins&operation=config&do={$_GET['do']}&identifier=swa_whotalk&pmod=member");

cpheader(); /*dism · taobao · com*/

showtableheader('用户管理','whotalkmembers');

showsubtitle(array('UID', '用户', 'UNIONID', '状态', '初次接入', '最后接入','操作'));

if (!empty($members)){
    foreach ($members as $value){
        $unionid = '<a href="'.$setting['apihost'].'web/index.php?c=mc&a=member&do=base_information&uid='.$value['unionid'].'" target="_blank">'.$value['unionid'].'</a>';
        $actions = '<a href="'.$setting['apihost'].'web/index.php?c=site&a=entry&m=xfy_whotalk&do=web&r=member.delete&uid='.$value['unionid'].'" target="_blank">清理</a>';
        $actions .= '&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=swa_whotalk&pmod=member&remove='.$value['id'].'&formhash='.FORMHASH.'" title="删除接入记录" onclick="if(!confirm(\'删除后不可恢复，是否确定要删除？\')){return false}">删除</a>';
        showtablerow('',array('class="td25"'),array(
            $value['uid'],
            '<a href="home.php?mod=space&uid='.$value['uid'].'&do=profile" target="_blank" class="useritem">'.avatar($value['uid'],'small').'<strong>'.$value['nickname'].'</strong></a>',
            $unionid,
            ($value['status']==1?'已接入':'接入失败'),
            date('m/d H:i',$value['addtime']),
            date('m/d H:i', $value['dateline']),
            $actions
        ));
    }
}else{
    showtablerow('',array('class="text-center" colspan="7"',''),array("暂无已接入用户"));
}
showtablefooter(); /*Dism·taobao·com*/
if (!empty($members)){
    showtableheader('共有'.$total.'个用户已对接IM系统');
    echo $multipage;
    showtablefooter(); /*Dism·taobao·com*/
}

$extrastyle = <<<EOF
<style type="text/css">
.whotalkmembers .useritem img{vertical-align: middle; height: 36px; margin-right: 5px; border-radius: 3px;}
.text-center{text-align: center;}
</style>
EOF;


echo $extrastyle;

cpfooter();

?>