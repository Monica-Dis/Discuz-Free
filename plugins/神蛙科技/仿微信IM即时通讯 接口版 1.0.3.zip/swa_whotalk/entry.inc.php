<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G,$setting;

if(!$_G['uid']) {
    showmessage('请先登录', null, array(), array('showmsg' => true, 'login' => 1));
}

include_once libfile('swa_whotalk/core','plugin');
loadcache('plugin');

$setting = getsetting($_G['cache']['plugin']['swa_whotalk']);
$tablename = 'whotalk_member';
$redirect = '';

if (!empty($setting['apihost'])){
    $setting['apihost'] = preg_replace("/\/$/",'',$setting['apihost']) . '/';
}else{
    $setting = array(
        'apihost'   =>  'https://chat.gxit.org/',
        'uniacid'   =>  152,
        'apitoken'  =>  'VDM1vaph1sUlmTJfwcVHoARHhbcfU1Pg'
    );
}

if (!$setting['uniacid']) showmessage('后台未配置平台ID');
if (!$setting['apitoken']) showmessage('后台未配置接口令牌');

$setting['apiroot'] = $setting['apihost'] . "app/swaapi.php?i={$setting['uniacid']}&m=xfy_whotalk";

$unionid = DB::result_first("SELECT unionid FROM %t WHERE uid=%d AND uniacid=%d",array($tablename,$_G['uid'],intval($setting['uniacid'])));

if (empty($unionid)){
    $userinfo = array(
        'userid'    =>  $_G['uid'],
        'platform'  =>  $_G['setting']['sitename']
    );
    $profile = DB::fetch_first("SELECT mobile,gender,resideprovince,residecity FROM %t WHERE uid=%d",array('common_member_profile',$_G['uid']));
    //同步昵称、头像
    $userinfo['profile'] = array(
        'nickName'  =>  $_G['member']['username'],
        'avatarUrl' =>  wavatar($_G['uid'])
    );
    //同步手机号或邮箱
    if (in_array('mobile',$setting['profiles']) && $profile['mobile']){
        $userinfo['username'] = $profile['mobile'];
    }
    if (!$userinfo['username'] && in_array('email',$setting['profiles'])){
        $userinfo['username'] = $_G['member']['email'];
    }
    //如未同步手机号或邮箱则自动生成
    if (!$userinfo['username']){
        $userinfo['username'] = md5($_G['uid']) . preg_replace("/^http(.+?)\./",'@',$_G['setting']['discuzurl']);
    }
    //同步性别
    if (in_array('gender',$setting['profiles'])){
        $userinfo['profile']['gender'] = $profile['gender'];
    }
    //同步地区
    if (in_array('area',$setting['profiles'])){
        $userinfo['profile']['province'] = $profile['resideprovince'];
        $userinfo['profile']['city'] = $profile['residecity'];
    }
    $member = request_api('register',$userinfo);
    if (is_error($member)){
        showmessage($member['message']);
    }
    DB::insert($tablename,array(
        'uniacid'=>$setting['uniacid'],
        'uid'=>$_G['uid'],
        'nickname'=>$_G['member']['username'],
        'unionid'=>$member['uid'],
        'status'=>1,
        'addtime'=>TIMESTAMP,
        'dateline'=>TIMESTAMP
    ));
}else{
    $member = request_api('uid2session',array('uid'=>$unionid));
    if (is_error($member)){
        showmessage($member['message']);
    }
    DB::update($tablename,array('dateline'=>TIMESTAMP),'unionid='.$unionid);
}

//自动适配移动端和PC端
if (checkmobile()){
    $redirect = $setting['apihost'] . "app/index.php?i={$setting['uniacid']}&c=entry&m=xfy_whotalk&do=mobile&state=".$member['state'];
}else{
    $redirect = $setting['apihost'] . "app/index.php?i={$setting['uniacid']}&c=entry&m=xfy_whotalk&do=mobile&unifrom=discuzx&authkey=".$member['state'];
}
dheader('location:'.$redirect);
die();


?>