<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_searchindex {

    
    function global_header(){
        global $_G;
        $micxp_setting=$_G['cache']['plugin']['micxp_searchindex'];
        if(!empty($micxp_setting['M_isopen'])){
           
            $maxnum = !empty($micxp_setting['M_num']) ? $micxp_setting['M_num'] :5;
            $list = DB::fetch_all("SELECT keywords FROM ".DB::table('common_searchindex')." GROUP BY keywords ORDER BY dateline DESC,num DESC LIMIT $maxnum");
            $userkey=array();
            foreach ($list as $key=>$val){
                if(!empty($val['keywords'])){
                    $userkey[]=$val['keywords'];
                }
            }
            if($micxp_setting['M_showtype']==2){
                $_G['setting']['srchhotkeywords']=$userkey;
            }elseif($micxp_setting['M_showtype']==1){
                $userkey = array_merge_recursive($_G['setting']['srchhotkeywords'],$userkey);
                $userkey= array_unique($userkey);
                $userkey=array_filter($userkey);
                $userkey= array_slice($userkey, 0,$maxnum);
                $_G['setting']['srchhotkeywords']=$userkey;
            }
            
            
            
        }
        
        
    }
}

//From: Dism_taobao��com

?>