<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$Mlang = $scriptlang['micxp_repeat'];
include_once libfile('function/admin','plugin/micxp_repeat');

if(submitcheck('rpchecksubmit')){
    $pagesize=!empty($_G['cache']['plugin']['micxp_repeat']['M_pagenum']) ?  intval($_G['cache']['plugin']['micxp_repeat']['M_pagenum']) : 100;
    $deltype=dhtmlspecialchars($_GET['deltype']);
    if(!in_array($deltype, array('delnew','delold'))){
        $deltype='delnew';
    }
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
</style>
EOF;
    $where="";
    $m_channel = isset($_GET['m_channel']) ?  dintval($_GET['m_channel'],true) : array('0');
    $m_channel=array_filter($m_channel);
    if(!empty($m_channel)){
        $catids = DB::field('catid', $m_channel,'IN');
        $where.=" AND  $catids";
    }
    
    $repeat_list= DB::fetch_all("SELECT COUNT(title) AS dd,title FROM `".DB::table('portal_article_title')."`  WHERE 1 $where   GROUP BY title ORDER BY dd DESC LIMIT 0,{$pagesize}");
    
    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=article&frame=no');
    showhiddenfields(array('deltype'=>$deltype));
    showtableheader($Mlang['check_result']);
    
    echo '<tr class="header"><th></th><th>'.$Mlang['repeat_num'].'</th><th>'.$Mlang['repeat_subject'].'</th></tr>';
    foreach($repeat_list as $list) {
        if($list['dd']==1){
            continue;
        }
        echo '<tr><td><input type="checkbox" class="checkbox" name="ids[]" value="'.$list['title'].'"></td>'.
            '<td>'.$list['dd'].'</td>'.
            '<td>'.$list['title'].'</td></tr>';
        
    }
    showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="managesubmit" value="'.$Mlang[$deltype].'" />');
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/
    exit;
    
    
    
    
}elseif(submitcheck('formhash') && !submitcheck('rpchecksubmit')){
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
</style>
EOF;
    $deltype=dhtmlspecialchars($_GET['deltype']);
    if(!in_array($deltype, array('delnew','delold'))){
        $deltype='delnew';
    }
    $ids = daddslashes($_GET['ids']);
    $pertask = 1;
    $current = isset($_GET['current']) && $_GET['current'] > 0 ? intval($_GET['current']) : 0;
    $next = $current + $pertask;
    if($current==0 && !empty($ids)){
        DB::query('TRUNCATE TABLE '.DB::table('micxp_repeat'));
        foreach ($ids as  $subject){
            $setarr=array(
                'subject'=>$subject,
                'type'=>'article'
            );
            C::t('#micxp_repeat#micxp_repeat')->insert($setarr);
        }
        
    }elseif($current==0 && empty($ids)){
        cpmsg_error($Mlang['noselect']);
        
    }
    $delinfo = C::t('#micxp_repeat#micxp_repeat')->fetch_by_type('article');
    
    $orderby = $deltype == "delnew" ? " ORDER BY aid DESC " : " ORDER BY aid ASC ";
    if(!empty($delinfo) && !empty($delinfo['subject'])){
        include_once libfile('function/admin','plugin/micxp_repeat');
        $sql = "SELECT aid,title FROM `".DB::table('portal_article_title')."` WHERE title=%s {$orderby}";
        $article = DB::fetch_all($sql,array($delinfo['subject']));
        $rownum=count($article);
        if($rownum>1){
            $i = 1;
            foreach ($article as $key=>$val){
                ++$i;
                if ( !( $rownum < $i ) )
                {
                 
                    micxp_repeat_delarticle($val);
                }
                
            }
        }
    }
    $nextlink = 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=thread&frame=no&managesubmit=yes&current='.$next.'&pertask='.$pertask.'&deltype='.$deltype;
    if($delinfo){
        C::t('#micxp_repeat#micxp_repeat')->delete($delinfo['id']);
        cpmsg(cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loadingform');
    }else{
        cpmsg($Mlang['delete_succeed'], '', 'succeed');
    }
    
    
    
    
    
}else{
    
    include_once libfile('function/portalcp');
    $categoryselect = micxp_repeat_category_showselect('portal', 'm_channel[]', true);
    
    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=article&frame=no','target="stafrm"');
    showtableheader($Mlang['search_repeat_article']);
      
    showsetting($Mlang['select_channel'], 'm_forums', '', $categoryselect, '', 0, $Mlang['select_mulit_tip'], '', '', true);
    
    $delsel=array('deltype',array(
        array('delnew',lang('plugin/micxp_repeat',delnew)),
        array('delold',lang('plugin/micxp_repeat',delold)),
        
    ));
    showsetting($Mlang['deltype'], $delsel,'','select');
    showsubmit('rpchecksubmit',$Mlang['rpchecksubmit']);
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/
    
    echo '<div id="mdv" style="width:100%;height:400px;">';
    echo '<iframe name="stafrm" frameborder="0" id="stafrm" width="100%" height="100%" onload=\'stafrm.document.body.scrollTop=stafrm.document.body.scrollHeight\'></iframe>';
    echo '</div>';
}
//From: dis'.'m.tao'.'bao.com
?>