<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$Mlang = $scriptlang['micxp_repeat'];

if(submitcheck('rpchecksubmit')){
    $pagesize=!empty($_G['cache']['plugin']['micxp_repeat']['M_pagenum']) ?  intval($_G['cache']['plugin']['micxp_repeat']['M_pagenum']) : 100;
    $deltype=dhtmlspecialchars($_GET['deltype']);
    if(!in_array($deltype, array('delnew','delold'))){
        $deltype='delnew';
    }
    
    
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
</style>
EOF;
    $where="";
    $m_forums = isset($_GET['m_forums']) ?  dintval($_GET['m_forums'],true) : array('0');
    $m_forums=array_filter($m_forums);
    if(!empty($m_forums)){
        $fids = DB::field('fid', $m_forums,'IN');
        $where.=" AND  $fids";
    }
    
    $repeat_list= DB::fetch_all("SELECT COUNT(subject) AS dd,subject FROM `".DB::table('forum_thread')."`   WHERE 1 $where   GROUP BY subject ORDER BY dd DESC LIMIT 0,{$pagesize}");

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=thread&frame=no');
    showhiddenfields(array('deltype'=>$deltype));
    showtableheader($Mlang['check_result']);
    
    echo '<tr class="header"><th></th><th>'.$Mlang['repeat_num'].'</th><th>'.$Mlang['repeat_subject'].'</th></tr>';
    foreach($repeat_list as $list) {
        if($list['dd']==1){
            continue;
        }
        echo '<tr><td><input type="checkbox" class="checkbox" name="ids[]" value="'.$list['subject'].'"></td>'.
            '<td>'.$list['dd'].'</td>'.
            '<td>'.$list['subject'].'</td></tr>';
        
    }
    showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="managesubmit" value="'.$Mlang[$deltype].'" />');
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/
    exit;
    
}elseif(submitcheck('formhash') && !submitcheck('rpchecksubmit')){
    echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
</style>
EOF;
    $deltype=dhtmlspecialchars($_GET['deltype']);
    if(!in_array($deltype, array('delnew','delold'))){
        $deltype='delnew';
    }
    
    $ids = daddslashes($_GET['ids']);
    
    $pertask = 1;
    $current = isset($_GET['current']) && $_GET['current'] > 0 ? intval($_GET['current']) : 0;
    $next = $current + $pertask;
    if($current==0 && !empty($ids)){
        DB::query('TRUNCATE TABLE '.DB::table('micxp_repeat'));
        foreach ($ids as  $subject){
            $setarr=array(
                'subject'=>$subject,
                'type'=>'thread'
            );
            C::t('#micxp_repeat#micxp_repeat')->insert($setarr);
        }
        
    }elseif($current==0 && empty($ids)){
        cpmsg_error($Mlang['noselect']);
        
    }
    $delinfo = C::t('#micxp_repeat#micxp_repeat')->fetch_by_type('thread');
    
    $orderby = $deltype == "delnew" ? " ORDER BY tid DESC " : " ORDER BY tid ASC ";
    if(!empty($delinfo) && !empty($delinfo['subject'])){
        include_once libfile('function/admin','plugin/micxp_repeat');
        $sql = "SELECT tid,subject FROM `".DB::table('forum_thread')."` WHERE subject=%s {$orderby}";
        $thread = DB::fetch_all($sql,array($delinfo['subject']));
        $rownum=count($thread);
        if($rownum>1){
            $i = 1;
            foreach ($thread as $key=>$val){
                ++$i;
                if ( !( $rownum < $i ) )
                {
                    
                    micxp_repeat_delthread($val); 
                }
                
            }
        }  
    }
    
    $nextlink = 'action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=thread&frame=no&managesubmit=yes&current='.$next.'&pertask='.$pertask.'&deltype='.$deltype;
    if($delinfo){
        C::t('#micxp_repeat#micxp_repeat')->delete($delinfo['id']);
        cpmsg(cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loadingform');
    }else{
        cpmsg($Mlang['delete_succeed'], '', 'succeed');
    }
    
    
    
}else{

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_repeat&pmod=thread&frame=no','target="stafrm"');
    showtableheader($Mlang['search_repeat_thread']);
    require_once libfile('function/forumlist');
    
    $forum_select = '<select name="m_forums[]" size="10" multiple="multiple"><option value="">'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, $var['value'], TRUE).'</select>';
    showsetting($Mlang['select_forums'], 'm_forums', '', $forum_select, '', 0, $Mlang['select_mulit_tip'], '', '', true);
    
    $delsel=array('deltype',array(
        array('delnew',lang('plugin/micxp_repeat',delnew)),
        array('delold',lang('plugin/micxp_repeat',delold)),
        
    ));
    showsetting($Mlang['deltype'], $delsel,'','select');
    showsubmit('rpchecksubmit',$Mlang['rpchecksubmit']);
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/
    
    echo '<div id="mdv" style="width:100%;height:400px;">';
    echo '<iframe name="stafrm" frameborder="0" id="stafrm" width="100%" height="100%" onload=\'stafrm.document.body.scrollTop=stafrm.document.body.scrollHeight\'></iframe>';
    echo '</div>';
    
}






?>