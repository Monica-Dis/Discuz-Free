<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_repeat extends discuz_table
{
	public function __construct() {
		$this->_table = 'micxp_repeat';
		$this->_pk    = 'id';
		parent::__construct();
	}
	
	public function fetch_by_type($type){
	    return DB::fetch_first("SELECT * FROM %t WHERE type = %s LIMIT 1",array($this->_table,$type));
	}
}
//From: Dism_taobao_com
?>