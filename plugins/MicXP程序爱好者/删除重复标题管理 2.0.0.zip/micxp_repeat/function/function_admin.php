<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
function micxp_repeat_delthread($thread){
    global $_G;
    loadforum($thread['fid'],$thread['fid']);
    if(empty($thread)){
        return '';
    }
    
    if($thread['digest']) {
        updatecreditbyaction('digest', $thread['authorid'], array('digestposts' => -1), '', -$thread['digest']);
    }
    if(in_array($thread['displayorder'], array(2, 3))) {
        $stickmodify = 1;
    }
    if($_G['forum']['status'] == 3 && $thread['closed'] > 1) {
        $deleteredirect[] = $thread['closed'];
    }
    if($thread['isgroup'] == 1 && $thread['closed'] > 1) {
        $remarkclosed[] = $thread['closed'];
    }
    
    
    
    $modaction = 'DEL';
    require_once libfile('function/delete');
    $tids =  array($thread['tid']);

    deletethread($tids, true, true);
    $updatemodlog = FALSE;
    
    
    if($_G['group']['allowbanuser'] && ($_GET['banuser'] || $_GET['userdelpost']) && $_G['deleteauthorids']) {
        $members = C::t('common_member')->fetch_all($_G['deleteauthorids']);
        $banuins = array();
        foreach($members as $member) {
            if(($_G['cache']['usergroups'][$member['groupid']]['type'] == 'system' &&
                in_array($member['groupid'], array(1, 2, 3, 6, 7, 8))) || $_G['cache']['usergroups'][$member['groupid']]['type'] == 'special') {
                    continue;
                }
                $banuins[$member['uid']] = $member['uid'];
        }
        if($banuins) {
            if($_GET['banuser']) {
                C::t('common_member')->update($banuins, array('groupid' => 4));
            }
            
            if($_GET['userdelpost']) {
                deletememberpost($banuins);
            }
        }
    }
    
    $forumstickthreads = $_G['setting']['forumstickthreads'];
    $forumstickthreads = !empty($forumstickthreads) ? dunserialize($forumstickthreads) : array();
    $delkeys = array($thread['tid']);
    foreach($delkeys as $k) {
        unset($forumstickthreads[$k]);
    }
    C::t('common_setting')->update('forumstickthreads', $forumstickthreads);
    
    C::t('forum_forum_threadtable')->delete_none_threads();
    if(!empty($deleteredirect)) {
        deletethread($deleteredirect);
    }
    if(!empty($remarkclosed)) {
        C::t('forum_thread')->update($remarkclosed, array('closed'=>0));
    }
    
    if($_G['setting']['globalstick'] && $stickmodify) {
        require_once libfile('function/cache');
        updatecache('globalstick');
    }
    include_once libfile('function/post');
    updateforumcount($_G['fid']);
    
}


function micxp_repeat_delarticle($article){
    
    if(empty($article)) {
        return '';
    }
 
    include_once libfile('function/delete');
    $article = deletearticle(array(intval($article['aid'])), 0);

}


function micxp_repeat_category_showselect($type, $name='catid', $shownull=true, $current='') {
    global $_G;
    if(! in_array($type, array('portal', 'blog', 'album'))) {
        return '';
    }
    loadcache($type.'category');
    
    $category = $_G['cache'][$type.'category'];
    $select = "<select  name=\"$name\" size=\"10\" multiple=\"multiple\">";
    if($shownull) {
        $select .= '<option value="">'.lang('portalcp', 'select_category').'</option>';
    }
    foreach ($category as $value) {
        if($value['level'] == 0) {
            $selected = ($current && $current==$value['catid']) ? 'selected="selected"' : '';
            $select .= "<option value=\"$value[catid]\"$selected>$value[catname]</option>";
            if(!$value['children']) {
                continue;
            }
            foreach ($value['children'] as $catid) {
                $selected = ($current && $current==$catid) ? 'selected="selected"' : '';
                $select .= "<option value=\"{$category[$catid][catid]}\"$selected>-- {$category[$catid][catname]}</option>";
                if($category[$catid]['children']) {
                    foreach ($category[$catid]['children'] as $catid2) {
                        $selected = ($current && $current==$catid2) ? 'selected="selected"' : '';
                        $select .= "<option value=\"{$category[$catid2][catid]}\"$selected>---- {$category[$catid2][catname]}</option>";
                    }
                }
            }
        }
    }
    $select .= "</select>";
    return $select;
}