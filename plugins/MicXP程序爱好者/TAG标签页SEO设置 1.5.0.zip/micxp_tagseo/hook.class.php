<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_tagseo {

}
class plugin_micxp_tagseo_misc extends plugin_micxp_tagseo{
    function tag_micxp_tagseo_output(){
        global $_G,$navtitle,$metakeywords,$metadescription,$nobbname,$tagname,$id,$name;
        if(empty($_G['cache']['plugin']['micxp_tagseo']['M_isopen'])) return '';
        $tagseo = dunserialize($_G['setting']['micxp_tagseo']);
        $nobbname=1;
        
        
        if($id || $name) {
            
            $seodata = array('page' => intval($_GET['page']),'tags'=>$tagname);
            $defset['seotitle']=!empty($tagseo['info_title']) ? $tagseo['info_title'] :$navtitle;
            $defset['seokeywords']=!empty($tagseo['info_keyword']) ? $tagseo['info_keyword'] : $metakeywords;
            $defset['seodescription']=!empty($tagseo['info_description']) ? $tagseo['info_description'] : $metadescription;

        }else{
            
            $seodata = array('page' => intval($_GET['page']));
            $defset['seotitle']=!empty($tagseo['index_title']) ? $tagseo['index_title'] : $navtitle;
            $defset['seokeywords']=!empty($tagseo['index_keyword']) ? $tagseo['index_keyword'] : $metakeywords;
            $defset['seodescription']=!empty($tagseo['index_description']) ? $tagseo['index_description'] : $metadescription;
        }
        
        
        list($navtitle, $metadescription, $metakeywords)=$this->micxp_seotag_get_seosetting($seodata,$defset);
    }
    
    
    
     function micxp_seotag_get_seosetting($data = array(), $defset = array()) {
        global $_G;
        $searchs = array('{bbname}');
        $replaces = array($_G['setting']['bbname']);
        
        $seotitle = $seodescription = $seokeywords = '';
        $titletext = $defset['seotitle'] ? $defset['seotitle'] : '';
        $descriptiontext = $defset['seodescription'] ? $defset['seodescription'] :'';
        $keywordstext = $defset['seokeywords'] ? $defset['seokeywords'] : '';
        preg_match_all("/\{([a-z0-9_-]+?)\}/", $titletext.$descriptiontext.$keywordstext, $pageparams);
        if($pageparams) {
            foreach($pageparams[1] as $var) {
                $searchs[] = '{'.$var.'}';
                if($var == 'page') {
                    $data['page'] = $data['page'] > 1 ? lang('core', 'page', array('page' => $data['page'])) : '';
                }
                $replaces[] = $data[$var] ? strip_tags($data[$var]) : '';
            }
            if($titletext) {
                $seotitle = helper_seo::strreplace_strip_split($searchs, $replaces, $titletext);
            }
            if($descriptiontext) {
                $seodescription = helper_seo::strreplace_strip_split($searchs, $replaces, $descriptiontext);
            }
            if($keywordstext) {
                $seokeywords = helper_seo::strreplace_strip_split($searchs, $replaces, $keywordstext);
            }
        }
        return array($seotitle, $seodescription, $seokeywords);
    }
}
//From: di'.'sm.t'.'aoba'.'o.com
?>