<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$Mlang = $scriptlang['micxp_tagseo'];
if(!submitcheck('seosubmit')) {
    $tagseo = dunserialize($_G['setting']['micxp_tagseo']);
    showformheader('plugins&operation=config&identifier=micxp_tagseo&pmod=seo');
    
    
    showtableheader($Mlang['tagindexpage']);
    showsetting($Mlang['seo_title'], 'tagseo[index_title]', $tagseo['index_title'], 'text','','','','onfocus="getcodetext(this,1);" id="i_t_seo"');
    showsetting($Mlang['seo_keyword'], 'tagseo[index_keyword]', $tagseo['index_keyword'], 'text','','','','onfocus="getcodetext(this,1);" id="i_k_seo"');
    showsetting($Mlang['seo_description'], 'tagseo[index_description]', $tagseo['index_description'], 'text','','','','onfocus="getcodetext(this,1);" id="i_d_seo"');
    showtablefooter();
    
    showtableheader($Mlang['taginfopage']);
    showsetting($Mlang['seo_title'], 'tagseo[info_title]', $tagseo['info_title'], 'text','','','','onfocus="getcodetext(this);" id="in_t_seo"');
    showsetting($Mlang['seo_keyword'], 'tagseo[info_keyword]', $tagseo['info_keyword'], 'text','','','','onfocus="getcodetext(this);" id="in_k_seo"');
    showsetting($Mlang['seo_description'], 'tagseo[info_description]', $tagseo['info_description'], 'text','','','','onfocus="getcodetext(this);" id="in_d_seo"');
    showtablefooter();
    
    
    showsubmit('seosubmit');
    
    showformfooter();
    
    echo "<div id=\"codediv\" style=\"top: 567px; background: transparent url('./static/image/common/mdly.png') no-repeat scroll 0px 0px; height: 100px; line-height: 32px; margin-top: -16px; overflow: hidden; padding: 10px 25px; position: absolute; left: 300px; width: 250px; display: none;\">
		<p>".lang('plugin/micxp_tagseo','tips')."</p>
		<p id=\"seocodes\"></p>
		</div>";
    
    echo <<<EOT
<script type="text/JavaScript">
		function getcodetext(obj,index='') {
			var codediv = $('codediv');
            if(index){
                var codes='bbname';
            }else{
                var codes='bbname,tags';
            }
			
            
			var top_offset = obj.offsetTop;
			var codecontent = '';
			var targetid = obj.id;
			while((obj = obj.offsetParent).tagName != 'BODY') {
				top_offset += obj.offsetTop;
			}
			types = codes.split(',');
			for(var i = 0; i < types.length; i++) {
				if(codecontent != '') {
					codecontent += '&nbsp;&nbsp;';
				}
				codecontent += '<a onclick="insertContent(\''+targetid+'\', \'{'+types[i]+'}\');return false;" href="javascript:;">{'+types[i]+'}</a>';
			}
			$('seocodes').innerHTML = codecontent;
			codediv.style.top = top_offset + 'px';
			codediv.style.display = '';
			
		}
		
		
		function insertContent(target, text) {
			var obj = $(target);
			checkFocus(target);
			
				obj.value += text;

		}
		
		function checkFocus(target) {
			var obj = $(target);
			if(!obj.hasfocus) {
				obj.focus();
			}
		}
</script>
EOT;

    
}else{
    $tagseo = serialize($_GET['tagseo']);
    DB::query("REPLACE INTO ".DB::table('common_setting')." (skey, svalue) VALUES ('micxp_tagseo', '$tagseo')");
    updatecache('setting');
    cpmsg($Mlang['seo_update_succeed'], 'action=plugins&operation=config&identifier=micxp_tagseo&pmod=seo', 'succeed');
}

?>