jQuery(function() {
    function ScrollChange(options) {
        this.navItem = options.navItem; 
        this.conItem = options.conItem; 
        this.navCur = options.navCur; 
        this.animate = options.animate == "" ? false : options.animate; 
        this.flag = false;
        this.init();
    }
    ScrollChange.prototype = {
        init: function(options) {
            var self = this;
            if (self.animate) {
               self.clickFun();
            }
            self.scrollFun();
           
        },
        scrollFun: function() {
            var self = this;
            jQuery(window).bind("scroll resize", function() {
              self.showTools();

              var sTop = jQuery(document).scrollTop();

              if (!self.flag) {
                self.conItem.each(function(index, el) {
                  var deH = jQuery(this).offset().top - sTop;

                  if ((0 <= deH && deH <= 80) || deH < 0) {
                    var $sideObj = jQuery("#j-side-cata-con .side-item"),
                      $sideIndex = $sideObj.eq(index);
                    
                    $sideObj.removeClass(self.navCur).eq(index).addClass(self.navCur);
                    $sideIndex
                      .prevAll(".side-item")
                      .removeClass("dot-visited")
                      .addClass("dot-visited");
                    $sideIndex
                      .nextAll(".side-item")
                      .removeClass("dot-hover")
                      .removeClass("dot-visited");
                  }
                });
              }
            });
          },
        clickFun: function() {
            var self = this;
            
            self.navItem.each(function(index, el) {
                jQuery(this).click(function(event) {
                    self.flag = true;
                    var conPos = self.conItem.eq(index).offset().top - 20;
					
                    jQuery("html,body").animate({
                        scrollTop: conPos + "px"
                    }, 300, function() {
                        

                        self.flag = false;
                    });
                   
                })
            })
        },
        showTools: function() {
            var h1 = document.documentElement.scrollTop
              ? document.documentElement.scrollTop
              : document.body.scrollTop;
            var h2 = document.documentElement.clientHeight
              ? document.documentElement.clientHeight
              : document.body.clientHeight;
            var top = h1 + h2;
            var goTop = jQuery("#j-side-tool");
            if (h1 > h2) {
              goTop.show();
              scrollBar({
                mod: "j-side-con",
                con: "j-side-cata-con",
                bar: "j-side-srcoll-tool",
                btn: "j-side-drag-btn",
                direction: "y"
              });
            } else {
              goTop.hide();
              jQuery("#j-side-con").show();
              jQuery("#floatBtns").removeClass("floatBtns-open");
            }
          }
        
    }

    new ScrollChange({
        navItem: jQuery("#j-bk-catalog .cata-list li a"),
        conItem: jQuery("#micxp-bk-area .micxp-bk-tit-1"),
        navCur: "dot-hover",
        animate: true
    });
    new ScrollChange({
        navItem: jQuery("#j-side-cata .side-item a"),
        conItem: jQuery("#micxp-bk-area .micxp-bk-tit-1"),
        navCur: "dot-hover",
        animate: true
     });

});
function setScrollBar() {
    //�����Ҳ�߶�
    var abH = jQuery("#j-content .col-ab").height();
    jQuery("#j-content .col-c").css("height", abH);

    //չ�����ջ�
    jQuery("#floatBtns .btnA").click(function(event) {
      if (jQuery("#j-side-con").css("display") == "none") {
    	  jQuery("#j-side-con").show();
    	  jQuery("#floatBtns").removeClass("floatBtns-open");
      } else {
    	  jQuery("#j-side-con").hide();
    	  jQuery("#floatBtns").addClass("floatBtns-open");
      }
    });
  }
  setScrollBar();
  
  
  
  jQuery(function() {
	  var scrollBar = (window["scrollBar"] = function(o) {
	      return new _scrollBar(o);
	    }),
	    _scrollBar = function(o) {
	      var _this = this;
	      this.mod = jQuery("#" + o.mod);
	      this.con = jQuery("#" + o.con);
	      this.bar = jQuery("#" + o.bar);
	      this.btn = jQuery("#" + o.btn);
	      this.dis = o.direction;
	      this.range = o.range || 10;

	      this.modH = this.dis == "y" ? this.mod.height() : this.mod.width();
	      this.conH = this.dis == "y" ? this.con.height() + 30 : this.con.width();
	      this.btnH =
	        this.modH * this.modH / this.conH < 20
	          ? 20
	          : this.modH * this.modH / this.conH;
	      this.init();
	    };
	  _scrollBar.prototype = {
	    init: function() {
	      var _this = this;
	      // _this.setScorllTools();
	      _this.TxtScroll();
	    },
	    TxtScroll: function() {
	      var _this = this;
	      if (_this.conH - _this.modH > 0) {
	        if (_this.dis == "x") {
	          _this.bar.css({
	            width: _this.modH + "px"
	          });
	        } else {
	          _this.bar.css({
	            height: _this.modH + "px"
	          });
	        }
	        _this.bar.show();
	        _this.startDrag(_this.btn);
	      } else {
	        _this.bar.hide();
	      }

	      if (_this.dis == "x") {
	        _this.btn.css({
	          width: _this.btnH + "px"
	        });
	      } else {
	        _this.btn.css({
	          height: _this.btnH + "px"
	        });
	      }
	    },
	    startDrag: function(btn) {
	      var _this = this,
	        _move = false, //�ƶ����
	        _y; //�����ؼ����Ͻǵ����λ��
	      btn.click(function() {}).mousedown(function(e) {
	        _move = true;
	        if (_this.dis == "x") {
	          _y = e.pageX - parseInt(btn.css("left"));
	        } else {
	          _y = e.pageY - parseInt(btn.css("top"));
	        }
	        btn.fadeTo(20, 0.9); //�����ʼ�϶���͸����ʾ
	        return false;
	      });

	      jQuery(document)
	        .mousemove(function(e) {
	          if (_move) {
	            //�ƶ�ʱ�������λ�ü���ؼ����Ͻǵľ���λ��
	            if (_this.dis == "x") {
	              _this.drag(e.pageX - _y);
	            } else {
	              _this.drag(e.pageY - _y);
	            }
	          }
	        })
	        .mouseup(function() {
	          _move = false;
	          btn.fadeTo("fast", 1); //�ɿ�����ֹͣ�ƶ����ָ��ɲ�͸��
	        });

	      _this.con.bind("mousewheel DOMMouseScroll", function(e, delta) {
	        if (_this.bar.css("display") == "none") return;
	        e.stopImmediatePropagation();
	        e.stopPropagation();
	        e.preventDefault();
	        var delta = parseInt(
	          e.originalEvent.wheelDelta || -e.originalEvent.detail
	        );
	        var y = parseInt(btn.css("top"));
	        if (delta < 0) {
	          y += _this.range;
	        } else {
	          y -= _this.range;
	        }
	        _this.drag(y);
	        return false;
	      });
	    },
	    drag: function(y) {
	      var _this = this;
	      if (y <= 0) {
	        y = 0;
	      } else if (y >= _this.modH - _this.btnH) {
	        y = _this.modH - _this.btnH;
	      }
	      var t = (_this.modH - _this.conH) * y / (_this.modH - _this.btnH);
	      if (_this.dis == "x") {
	        _this.btn.css({
	          left: y
	        });
	        _this.con.css({
	          left: t
	        });
	      } else {
	        _this.btn.css({
	          top: y
	        });
	        _this.con.css({
	          top: t
	        });
	      }
	      return this;
	    },
	    scrollTo: function(t) {
	      var _this = this;
	      var y = -(_this.modH - _this.btnH) * t / (_this.modH - _this.conH);
	      if (y <= 0) {
	        y = 0;
	      } else if (y >= _this.modH - _this.btnH) {
	        y = _this.modH - _this.btnH;
	      }
	      var t = (_this.modH - _this.conH) * y / (_this.modH - _this.btnH);
	      if (_this.dis == "x") {
	        _this.btn.animate({
	          left: y
	        });
	        _this.con.animate({
	          left: t
	        });
	      } else {
	        _this.btn.animate({
	          top: y
	        });
	        _this.con.animate({
	          top: t
	        });
	      }
	      return this;
	    }
	  };
	});