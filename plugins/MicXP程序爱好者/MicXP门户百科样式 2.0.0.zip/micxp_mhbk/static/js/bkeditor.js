function micxp_mhbk_editor(tag){
	
	var bk_tag = 'micxp_threadbk';
	var bk_tag_title = 'micxp_title';
	var str='';
	
	
	var sel, selection;
	var str1 = '', strdialog = 0, stitle = '';
	var ctrlid = 'micxp_' + tag;
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 270;
	var menupos = '43!';
	var menutype = 'menu';
	
	str += '<div id="micxp_titlearea">'+you_catalog_hear+'<br>';
	str += '<textarea id="' + ctrlid + '_param_1" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea></div>';

	
	
	
	if(menu) {
		
		if($(ctrlid).getAttribute('menupos') !== null) {
			menupos = $(ctrlid).getAttribute('menupos');
		}
		if($(ctrlid).getAttribute('menuwidth') !== null) {
			menu.style.width = $(ctrlid).getAttribute('menuwidth') + 'px';
		}

		if(selection) {
			$('micxp_titlearea').style.display = 'none';
		}

		showMenu({'ctrlid':ctrlid,'evt':'click','pos':menupos,'timeout':250,'duration':in_array(tag, ['fontname', 'fontsize', 'sml']) ? 2 : 3,'drag':1});
		
	} else {
		
		var menu = document.createElement('div');
		menu.id = ctrlid + '_menu';
		menu.style.display = 'none';
		menu.className = 'p_pof upf';
		menu.style.width = menuwidth + 'px';
		
		
		s = '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">'+close+'</a></span><div>' + str + '</div><div class="pns mtn"><span  id="' + ctrlid + '_submit" class="pn pnc"><strong>'+micxp_submit+'</strong></span></div></div>';
		
		menu.innerHTML = s;
		
		
		$('micxp_editortoolbar').appendChild(menu);

		
		showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});
	}
	
	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}

	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if(obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13) {
				if($(ctrlid + '_submit')) $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		
		str1 = $(ctrlid + '_param_1') && $(ctrlid + '_param_1').value ? $(ctrlid + '_param_1').value : (selection ? selection : '');
		
		var str2=str1.replace(/\r?\n/g, '');
		if(!str2){
			hideMenu();
			return '';
		}

	
		var contag='';
		
		
		
		str1 = preg_replace(['<', '>'], ['&lt;', '&gt;'], str1);
		str1 = str1.replace(/\r?\n/g, '<br />');
		
		var tmpstr = str1.split('<br />');
		if(tmpstr){
			var titlelen = tmpstr.length;
			for (var i=1;i<=titlelen;i++){
				var micxp='';
				for(var j=1;j<=i;j++){
					micxp+='#';
				}
				contag+='['+micxp+']<br />';
				contag+=micxp_content_here+'<br />';
			}
		}
		
		str1+='<br />';
		
		var opentag = '[' + bk_tag + ']<br />';
		var closetag = '[/' + bk_tag + ']<br />';
		var opentag_title = '[' + bk_tag_title + ']<br />';
		var closetag_title = '[/' + bk_tag_title + ']<br />';

		str1 = opentag + opentag_title+ str1+ closetag_title + contag +closetag;
		edit_insert(str1);
		hideMenu();
		
	};
	
	
	
}




function micxp_threadbk_getSel() {
	if(wysiwyg) {
		try {
			selection = editwin.getSelection();
			return selection.toString();
		} catch(e) {
			try {
				var range = editdoc.selection.createRange();
				if(range.htmlText && range.text) {
					return range.text;
				} else {
					var htmltext = '';
					for(var i = 0; i < range.length; i++) {
						htmltext += range.item(i).outerHTML;
					}
					return htmltext;
				}
			} catch(e) {
				return '';
			}
		}
	} else {
		if(!isUndefined(editdoc.selectionStart)) {
			return editdoc.value.substr(editdoc.selectionStart, editdoc.selectionEnd - editdoc.selectionStart);
		} else if(document.selection && document.selection.createRange) {
			return document.selection.createRange().text;
		} else if(window.getSelection) {
			alert(editdoc);
			return window.getSelection() + '';
		} else {
			return false;
		}
	}
}