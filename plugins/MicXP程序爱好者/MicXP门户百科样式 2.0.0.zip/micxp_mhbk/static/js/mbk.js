(function () {
    var compareTitle = document.querySelectorAll(".f-maplink");
    for (var i = 0 , len=compareTitle.length; i < len ; i++) {
        var newNode = document.createElement("div");
        newNode.className = "m-mark";
        compareTitle[i].parentNode.insertBefore(newNode,compareTitle[i]);
    }
    var divMark = document.querySelectorAll(".m-mark");
    var divFixed = document.createElement("div");
    divFixed.className = "f-fixed";
    divMark[0].parentNode.insertBefore(divFixed,divMark[0]);
    divFixed.innerHTML = compareTitle[0].innerHTML;

    window.onscroll=window.onresize=function(){
        for (var i = 0 , len=compareTitle.length; i < len ; i++) {
            var scrTop = document.documentElement.scrollTop+document.body.scrollTop,
                offTop = divMark[i].offsetTop;
            if(scrTop >=200){
                divFixed.style.display="block"
            }else{
                divFixed.style.display="none"
            }
            if (scrTop>=offTop) {
                divFixed.innerHTML = compareTitle[i].innerHTML
            }
        }

    }
})();