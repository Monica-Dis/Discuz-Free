<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_mhbk {

    function global_footer_mobile() {
        global $_G;

        if(CURMODULE=='view'  && CURSCRIPT=='portal' ){
            $css='<link rel="stylesheet" type="text/css" href="source/plugin/micxp_mhbk/static/css/mbk.css" />';    
            $bkjsurl='source/plugin/micxp_mhbk/static/js/mbk.js';
            $js = '<script language="javascript" type="text/javascript" src="'.$bkjsurl.'"></script>';
            return $js.$css;
        }
    
    }
}

class mobileplugin_micxp_mhbk_portal extends mobileplugin_micxp_mhbk{
    function view_micxp_output($param) {
         global $content;
         $content = preg_replace_callback('/\[micxp_threadbk\](.*?)\[\/micxp_threadbk\]/is', array($this, '_message_to_mhbk'), $content);
    
    }
    
    function _message_to_mhbk($message){
        
        global $_G;
        if($message['1']){
            $bktitle=preg_replace_callback('/\[micxp_title\](.*?)\[\/micxp_title\]/is', array($this, '_message_to_mhbk_title'), $message['1']);
            $bktitle = trim($bktitle);
            $bktitle = str_replace('[#]', '', $bktitle);
            $conarr = preg_split('/\[#+\]/',$bktitle);
            
            $bkcontent = $this->_message_to_threadbk_content($conarr);
            return $bkcontent;
        }else{
            return '';
        }
        
    
    }
    
    function _message_to_threadbk_content($message){
        global $_G;
    
        if(!empty($_G['micxp_title_array'])){
            $num=1;
            $html='';
            foreach ($_G['micxp_title_array'] as $key=>$val){
                $html.='<div class="m-item"><div class="u-tit"><i>'.$num.'</i><em class="f-maplink" id="p1">'.$val.'</em></div><div class="u-info"><div class="u-cont">'.trim($message[$key]).'</div></div></div>';
                $num++;
            }
        }
    
        return $html;
    }
    
    
    
    function _message_to_mhbk_title($message){
        global $_G;
        if($message['1']){
            $message =trim($message['1']);
            $return='';
            $message = strip_tags($message,'<br>');
            $title_array= explode('<br>', $message);
            $title_array= array_filter($title_array);
            $title_array=array_merge($title_array,array());
            $_G['micxp_title_array']=$title_array;
            return $return;
        }else{
            return '';
        }
        
    }
    
}
//From: Dism_taobao-com
?>