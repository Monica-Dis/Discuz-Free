<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_mhbk {
    
    function global_footer() {
        global $_G;
        
        if(CURMODULE=='view'){
            $jqueryurl='source/plugin/micxp_mhbk/static/js/jquery.pack.js';
            $bkjsurl='source/plugin/micxp_mhbk/static/js/bk.js';
            $js='<script src="'.$jqueryurl.'" type="text/javascript"></script>';
            $js.='<script src="'.$bkjsurl.'" type="text/javascript"></script>';
            return $js;
        }
    }
    
    
}

class plugin_micxp_mhbk_portal extends plugin_micxp_mhbk{
    

    
    
    function  portalcp_extend() {
        $bkbtn ="<link rel=\"stylesheet\" href=\"source/plugin/micxp_mhbk/static/css/bk_btn.css\" type=\"text/css\" />";
		$bkbtn .="<script type=\"text/javascript\">
		var you_catalog_hear = '".lang('plugin/micxp_mhbk','you_catalog_hear')."';
		var micxp_submit = '".lang('plugin/micxp_mhbk','micxp_submit')."';
		var micxp_close = '".lang('plugin/micxp_mhbk','micxp_close')."';
		var micxp_content_here = '".lang('plugin/micxp_mhbk','micxp_content_here')."';				
				</script>";
		$bkbtn .="<script src=\"source/plugin/micxp_mhbk/static/js/bkeditor.js\" type=\"text/javascript\"></script>";
		$bkbtn .= "<a id=\"micxp_mhbk_btn\" title=\"".lang('plugin/micxp_mhbk','postbk')."\" onClick=\"micxp_mhbk_editor('threadbk_btn')\" href='javascript:void(0);' >".lang('plugin/micxp_mhbk','baike')."</a><div id='micxp_editortoolbar'></div>";
		return $bkbtn;
    }
    
    function view_micxp_output($param) {
        global $content;
        
        $content = preg_replace_callback('/\[micxp_threadbk\](.*?)\[\/micxp_threadbk\]/is', array($this, '_message_to_mhbk'), $content);
        
    }
        
    function _message_to_mhbk($message){
         if($message[1]){
             $bktitle=preg_replace_callback('/\[micxp_title\](.*?)\[\/micxp_title\]/is',array($this, '_message_to_mhbk_title'), $message['1']);
             $bkcontent = $this->_message_to_mhbk_content($bktitle);
             return $bkcontent."</div>";
         }else{
             return '';
         }
        
    
    }
    
    function _message_to_mhbk_content($message){
        global $_G;

        if(!empty($_G['micxp_title_array_portal'])){
            $num=1;
            foreach ($_G['micxp_title_array_portal'] as $key=>$val){
                $replace_str="[".str_pad('#',$num,'#')."]";
                $html='<div class="micxp-bk-tit-1" name="bk-head-tit" rel="index-'.$num.'"><span class="bk-tit-num">'.$num.'</span><span class="bk-tit-name">'.$val.'</span></div>';
                $message=str_replace($replace_str, $html, $message);
                $num++;
            } 	
        }
        
        return $message;
    }
    
    
    function _message_to_mhbk_title($message){
        global $_G;
      
        if($message[1]){
            if(!empty($_GET['aid'])){
                $aid = intval($_GET['aid']);
                if(@in_array('portal_article', $_G['setting']['rewritestatus'])) {
                    $baseurl = rewriteoutput('portal_article', 1, '', $aid, 1, '', '');
                } else {
                    $baseurl='portal.php?'.dhtmlspecialchars($_SERVER['QUERY_STRING']);
                }
                	
            }else{
                $baseurl='';
            }
            $message =trim($message[1]);
            $return='';
    
            $message = strip_tags($message,'<br>');
            $title_array= explode('<br>', $message);
        
            $title_array= array_filter($title_array);
            $title_array=array_merge($title_array,array());
       
            
            if(empty($title_array)) return $return;
            $_G['micxp_title_array_portal']=$title_array;
            include template('micxp_mhbk:catalog');
        
            $return = str_replace('<br>', '', $return);
            return $return.'<div id="micxp-bk-area">';
        }else{
            return '';
        }
    
    }
    

    function view_article_content_output(){
        global $_G;
        $margin=intval($_G['cache']['plugin']['micxp_mhbk']['M_marginleft']);
        if(!empty($_G['micxp_title_array_portal'])){
            
            if(!empty($_GET['aid'])){
                $aid = intval($_GET['aid']);
                if(@in_array('portal_article', $_G['setting']['rewritestatus'])) {
                    $baseurl = rewriteoutput('portal_article', 1, '', $aid, 1, '', '');
                } else {
                    $baseurl='portal.php?'.dhtmlspecialchars($_SERVER['QUERY_STRING']);
                }
                
            }else{
                $baseurl='';
            }
            
            
            $side='';
            include template('micxp_mhbk:side');
            return $side;
        }else{
            return '';
        }
        
    }

}
//From: Dism��taobao��com
?>