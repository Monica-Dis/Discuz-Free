<?php
//cronname:cronname
//week:
//day:
//hour:
//minute:0,5,10,15,20,25,30,35,40,45,50,55
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$micxp_setting=$_G['cache']['plugin']['micxp_mp4upload'];
if(!defined('MICXP_OSS_ACCESS_ID')){
    define('MICXP_OSS_ACCESS_ID',$micxp_setting['M_accessKeyId']);
}
if(!defined('MICXP_OSS_ACCESS_KEY')){
    define('MICXP_OSS_ACCESS_KEY',$micxp_setting['M_accessKeySecret']);
}
if(!defined('MICXP_OSS_ENDPOINT')){
    define('MICXP_OSS_ENDPOINT', $micxp_setting['M_endpoint']);
}
if(!defined('MICXP_OSS_TEST_BUCKET')){
    define('MICXP_OSS_TEST_BUCKET', $micxp_setting['M_bucket']);
}
set_time_limit(0);

spl_autoload_unregister(array('core', 'autoload'));
include __DIR__."/../vendor/oss-sdk/autoload.php";
spl_autoload_register(array('core', 'autoload'));

if($micxp_setting['M_isoss']){
    include __DIR__."/../vendor/oss-sdk/Common.php";
    
    $where=" src!='' AND osssrc='' AND `use`=1 ";
    $order='ORDER BY id DESC';
    $video_info=C::t('#micxp_mp4upload#micxp_mp4upload')->fetch_all_by_sql($where,$order,0,1);
    $video_info=$video_info[0];
    
    if(!empty($video_info['src'])){
        $filename=$video_info['src'];
        $filepath=DISCUZ_ROOT.$video_info['src'];
        $bucket = MICXPCommon::getBucketName();
        $ossClient = MICXPCommon::getOssClient();
        
        if (!is_null($ossClient)) {
            $list =$ossClient->multiuploadFile($bucket, $filename, $filepath, array());
            
        }else{
            $list='';
        }
        
        if($list['info']['http_code']==200){
            $ossurl = $list['info']['url'];
        }else{
            $ossurl='';
        }
        if(!empty($ossurl)){
            C::t('#micxp_mp4upload#micxp_mp4upload')->update($video_info['id'],array('osssrc'=>$ossurl));
            
            if($micxp_setting['M_isdel']){
                @unlink($filepath);
            }
            
        }
        
        
        
    }
   
}
    

?>