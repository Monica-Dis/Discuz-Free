<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_micxp_mp4upload extends discuz_table
{
	public function __construct() {
		$this->_table = 'micxp_mp4upload';
		$this->_pk    = 'id';
		parent::__construct();
	}

	public function fetch_all_by_sql($where, $order = '', $start = 0, $limit = 0, $count = 0, $alias = '') {
	    $where = $where && !is_array($where) ? " WHERE $where" : '';
	    if(is_array($order)) {
	        $order = '';
	    }
	    if($count) {
	        return DB::result_first('SELECT count(*) FROM '.DB::table($this->_table).'  %i %i %i '.DB::limit($start, $limit), array($alias, $where, $order));
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' %i %i %i '.DB::limit($start, $limit), array($alias, $where, $order));
	}

	public function count_by_uid($uid){
	    return DB::result_first('SELECT count(*) FROM %t WHERE uid=%d',array($this->_table,$uid) );
	}
}
//From: Dism��taobao��com
?>