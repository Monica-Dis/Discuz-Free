<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_mp4upload {
    function discuzcode($param) {
    
        global $_G;
        include_once libfile('function/common','plugin/micxp_mp4upload');
        if($param['caller'] == 'discuzcode') {
            $_G['discuzcodemessage'] = preg_replace_callback("/\s?\[micxp_mp4\](.+?)\[\/micxp_mp4\]\s?/i", create_function('$matches', 'return micxp_mp4player_mobile($matches[1]);'), $_G['discuzcodemessage']);
        }
        if($param['caller'] == 'messagecutstr') {
            $_G['discuzcodemessage'] = preg_replace('/\[micxp_mp4\](.*?)\[\/micxp_mp4\]/is', '', $_G['discuzcodemessage']);
        }
    
    }
}

class mobileplugin_micxp_mp4upload_forum extends  mobileplugin_micxp_mp4upload{
    function post_bottom_mobile_output(){
        global $_G;
        if(CURMODULE=='post' && $_GET['action']=='newthread'){
            $micxp_setting = $_G['cache']['plugin']['micxp_mp4upload'];
            if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['M_groups']))) return '';
            if(!in_array($_G['fid'],(array)unserialize($micxp_setting['M_forums']))) return '';
            
            $html='';
            $html .= "<link rel=\"stylesheet\" href=\"source/plugin/micxp_mp4upload/static/css/mbtn.css\" type=\"text/css\" /><div id=\"micxp_mp4upload_wrap\"><a id=\"micxp_mp4upload\" class=\"dialog\" title=\"".lang('plugin/micxp_mp4upload','uploadmp4video')."\" href='plugin.php?id=micxp_mp4upload:window' > </a></div>"; 
            return   $html;
        }
        
    }
    
    
    function post_mp4upload_message(){
        global $_G,$tid,$pid,$message;
        include_once libfile('function/common','plugin/micxp_mp4upload');
        $micxp_setting = $_G['cache']['plugin']['micxp_mp4upload'];
        if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['M_groups']))) return '';
        if(!in_array($_G['fid'],(array)unserialize($micxp_setting['M_forums']))) return '';
        if($_GET['topicsubmit'] || $_GET['editsubmit'] || $_GET['replysubmit']){
            if($_GET['editsubmit'] || $_GET['replysubmit']){
                $tid = $_G['tid'];
            }
            preg_match_all("/\[micxp_mp4\](.*?)\[\/micxp_mp4\]/is", $message, $videolist);
            if(!empty($videolist['1'])){
                $videolist['1']=dintval($videolist['1'],true);
                $videolist['1']=array_filter($videolist['1']);
                $videolist['1']=array_unique($videolist['1']);
                if(!empty($videolist['1'])){
                    foreach ($videolist['1'] as $vid){
    
                        $video=C::t('#micxp_mp4upload#micxp_mp4upload')->fetch($vid);
                        if($video['use']==1 || !empty($video['articleid'])) continue;
                        $vide_file_ext=end(explode('.', $video['src']));
                        $pic_file_ext=end(explode('.', $video['poster']));;
                         
                        $path = DISCUZ_ROOT;
                        $dir = $path."source/plugin/micxp_mp4upload/data/".$video['uid'];
                        $save = $dir."/".$video['md5']."_".$tid.".".$vide_file_ext;
                        $savepic = $dir."/".$video['md5']."_".$tid.".".$pic_file_ext;
    
                        if(!is_dir($dir))
                        {
                            mkdir($dir);
                            chmod($dir,0777);
                        }
    
                        $tofile=diconv($path.$video['src'],CHARSET,'GBK');
                        copy($tofile,$save);
                        copy($path.$video['poster'],$savepic);
                        $setarr=array(
                            'use'=>1,
                            'articleid'=>$tid,
                            'pid'=>$pid,
                            'src'=>"source/plugin/micxp_mp4upload/data/".$video['uid']."/".$video['md5']."_".$tid.".".$vide_file_ext,
                            'poster'=>"source/plugin/micxp_mp4upload/data/".$video['uid']."/".$video['md5']."_".$tid.".".$pic_file_ext
                        );
                        C::t('#micxp_mp4upload#micxp_mp4upload')->update($vid,$setarr);
                        
                    }
                    micxp_delcache();
    
                }
    
            }
        }
    
         
    
    }
    
}
//From: Dism_taobao_com
?>