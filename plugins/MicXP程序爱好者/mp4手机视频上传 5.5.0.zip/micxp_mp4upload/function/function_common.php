<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function micxp_mp4player($vid){
    global $_G;
    $micxp_setting=$_G['cache']['plugin']['micxp_mp4upload'];
    $m_w=!empty($micxp_setting['M_w']) ? intval($micxp_setting['M_w']) : 600;
    $m_h=!empty($micxp_setting['M_h']) ? intval($micxp_setting['M_h']) : 400;
    
    $m_vh=!empty($micxp_setting['M_vh']) ? intval($micxp_setting['M_vh']) : 400;
    $m_vw=!empty($micxp_setting['M_vw']) ? intval($micxp_setting['M_vw']) : 600;
    $video=C::t('#micxp_mp4upload#micxp_mp4upload')->fetch($vid);
    if(empty($video['use'])){
        return '';
    }
    if($micxp_setting['M_isoss'] && !empty($video['osssrc'])){
        $video[src]=$video['osssrc'];
        
        $temurl=$video[src];
        $urlinfo = parse_url($temurl);
        //$video[src]=$urlinfo['scheme']."://".$urlinfo['host'].$urlinfo['path'];
        
        $video[src]=$_G['scheme']."://".$urlinfo['host'].$urlinfo['path'];
    }
    if($micxp_setting['M_isoss'] && !empty($video['ossposter'])){
        $video[poster]=$video['ossposter'];
    }
  
    return '<video id="mp4video" src="'.$video[src].'" width="'.$m_vw.'px" height="'.$m_vh.'px" controls="controls" poster="'.$video[poster].'"></video>';
}
function micxp_mp4player_mobile($vid){
    global $_G;
    $micxp_setting=$_G['cache']['plugin']['micxp_mp4upload'];
    $m_w=!empty($micxp_setting['M_w']) ? intval($micxp_setting['M_w']) : 600;
    $m_h=!empty($micxp_setting['M_h']) ? intval($micxp_setting['M_h']) : 400;
    $m_vh=!empty($micxp_setting['M_vh']) ? intval($micxp_setting['M_vh']) : 400;
    $m_vw=!empty($micxp_setting['M_vw']) ? intval($micxp_setting['M_vw']) : 600;
    $video=C::t('#micxp_mp4upload#micxp_mp4upload')->fetch($vid);
    
    
    
    if(empty($video['use'])){
        return '';
    }
    if($micxp_setting['M_isoss'] && !empty($video['osssrc'])){
        $video[src]=$video['osssrc'];
        $temurl=$video[src];
        $urlinfo = parse_url($temurl);
        //$video[src]=$urlinfo['scheme']."://".$urlinfo['host'].$urlinfo['path'];
        $video[src]=$_G['scheme']."://".$urlinfo['host'].$urlinfo['path'];
        
    }
    if($micxp_setting['M_isoss'] && !empty($video['ossposter'])){
        $video[poster]=$video['ossposter'];
    }
    
    return '<video id="mp4video" src="'.$video[src].'" width="100%" height="'.$m_vh.'px" controls="controls" poster="'.$video[poster].'"></video>';
}

function micxp_delcache(){
    global $_G;
    $path = DISCUZ_ROOT;
    $dir = $path."source/plugin/micxp_mp4upload/cache/";
    if(file_exists($dir) && $handle=opendir($dir)){
        while(false!==($item = readdir($handle))){
            if($item!= "." && $item != ".."){
                    $prelen=strlen($_G['uid'])+1;
                    $dirper=cutstr($item, $prelen,'');
                    
                    
                    if(file_exists($dir.'/'.$item) && is_dir($dir.'/'.$item)){
                        if($dirper==$_G['uid']."-"){
                            micxp_delcache2($dir.'/'.$item);
                            @rmdir($dir.'/'.$item);
                        }
                        
                    }else{
                        if($dirper==$_G['uid']."-"){
                            @unlink($dir.'/'.$item);
                        }
                    }
            }
            
        }
        DB::query("DELETE FROM ".DB::table('micxp_mp4upload')." WHERE `uid`=".$_G['uid']." AND `use`=0");
        closedir( $handle);
  
    }
        
}
function micxp_delcache2($dir){
    if(file_exists($dir) && $handle2=opendir($dir)){
        while(false!==($item = readdir($handle2))){
            if($item!= "." && $item != ".."){
                unlink($dir.'/'.$item);
            }

        }
        closedir($handle2);
    }

}




