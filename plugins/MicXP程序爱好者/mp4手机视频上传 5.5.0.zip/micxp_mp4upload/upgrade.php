<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$field = C::t('#micxp_mp4upload#micxp_mp4upload')->fetch_all_field();

$sql='';

$table = DB::table('micxp_mp4upload');
if(!$field['osssrc']){
	$sql .= "ALTER TABLE $table ADD `osssrc` varchar(255) NOT NULL DEFAULT '';\n";
}

if(!$field['ossposter']){
	$sql .= "ALTER TABLE $table ADD `ossposter` varchar(255) NOT NULL DEFAULT '';\n";
}
if ($sql) {
	runquery($sql);
}
$finish = true;
?>
