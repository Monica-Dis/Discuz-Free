<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$micxp_setting = $_G['cache']['plugin']['micxp_mp4upload'];
if(!empty($micxp_setting['M_limit'])){
    $limit_size=intval($micxp_setting['M_limit'])*1024*1024;
}else{
    $limit_size=0;
}
include template('micxp_mp4upload:window');