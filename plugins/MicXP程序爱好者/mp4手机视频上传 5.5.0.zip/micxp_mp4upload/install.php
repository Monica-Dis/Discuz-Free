<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql= <<<EOF
DROP TABLE IF EXISTS `cdb_micxp_mp4upload`;
CREATE TABLE `cdb_micxp_mp4upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `dateline` int(10) NOT NULL,
  `src` varchar(255) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `use` tinyint(4) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL,
  `articleid` int(11) NOT NULL,
  `md5` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `osssrc` varchar(255) NOT NULL,
  `ossposter` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


		
EOF;
runquery($sql);
$finish = TRUE;
?>