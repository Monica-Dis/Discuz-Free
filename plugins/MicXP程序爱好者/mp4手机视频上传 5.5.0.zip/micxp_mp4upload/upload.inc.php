<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$micxp_setting=$_G['cache']['plugin']['mp4upload'];
$m_w=!empty($micxp_setting['M_w']) ? intval($micxp_setting['M_w']) : 600;
$m_h=!empty($micxp_setting['M_h']) ? intval($micxp_setting['M_h']) : 400;

if($_GET['upload'] && submitcheck('formhash')){
    if($_GET['upload']==2){
        if(!empty($_GET['vid'])){
            $micxpvid=intval($_GET['vid']);
            $base64 = base64_decode($_GET['file']);
            $outputfile = 'source/plugin/micxp_mp4upload/cache/'.$_G[uid].'-'.uniqid(time()).'.jpg';
            if($base64){
                $ifp = fopen( DISCUZ_ROOT.$outputfile, "wb" );
                fwrite( $ifp, $base64 );
                fclose( $ifp );
                $image= new image();
               
                $status=$image->Thumb(DISCUZ_ROOT.$outputfile, '',$m_w, $m_h);
                $outputfile=getimgthumbname($outputfile);
                if($status){
                    $setarr=array(
                        'poster'=>$outputfile
                    );
                    C::t('#micxp_mp4upload#micxp_mp4upload')->update($micxpvid,$setarr);
                    $res = array("res"=>"success","url"=>$outputfile);
                    echo json_encode($res);
                    exit;
                }
            }
        }
        
    }elseif($_GET['upload']==1){
        
        $fsize = $_GET['size'];
        $findex =$_GET['indexCount'];
        $ftotal =$_GET['totalCount'];
        $ftype = $_GET['type'];
        $fdata = $_FILES['file'];
        
        if(defined('IN_MOBILE')) {
            $fname=$_GET['name'];
            
        }else{
            $fname=diconv($_GET['name'], 'UTF-8',CHARSET);
        }
        $name_info=explode('.', $fname);
        $uptype=end($name_info);
        $uptype=strtolower(end($name_info));
        if('mp4'!=$uptype && 'mov'!=$uptype){
            $res = array("res"=>"error");
            echo json_encode($res);
            exit;
        }
        
        
        $union_dir=$_G['uid'];
        
        $path = DISCUZ_ROOT;
        $dir = $path."source/plugin/micxp_mp4upload/cache/".$union_dir."-".$fsize;
        $save = $dir."/".$fname;
        $save=diconv($save, CHARSET,'GBK');
        if(!is_dir($dir))
        {
            mkdir($dir);
            chmod($dir,0777);
        }
        
        $temp = fopen($fdata["tmp_name"],"r+");
        $filedata = fread($temp,filesize($fdata["tmp_name"]));

        if(file_exists($dir."/".$findex.".tmp")) unlink($dir."/".$findex.".tmp");
        $tempFile = fopen($dir."/".$findex.".tmp","w+");
        fwrite($tempFile,$filedata);
        fclose($tempFile);
        fclose($temp);
        
        if($findex+1==$ftotal)
        {
            if(file_exists($save)) @unlink($save);

            for($i=0;$i<$ftotal;$i++)
            {
                $readData = fopen($dir."/".$i.".tmp","r+");
                $writeData = fread($readData,filesize($dir."/".$i.".tmp"));
        
                $newFile = fopen($save,"a+");
                fwrite($newFile,$writeData);
                fclose($newFile);
        
                fclose($readData);
                $resu = @unlink($dir."/".$i.".tmp");
            }
            
            $burl=diconv("source/plugin/micxp_mp4upload/cache/".$union_dir."-".$fsize."/".$fname,CHARSET,'UTF-8');
            $burl1="source/plugin/micxp_mp4upload/cache/".$union_dir."-".$fsize."/".$fname;
            
            $setarr=array(
              'uid'=>$_G['uid'],
              'dateline'=>TIMESTAMP,
              'src'=>$burl1,
              'type'=>'thread',
              'md5'=>md5_file($save)
            );
            $insertid=C::t('#micxp_mp4upload#micxp_mp4upload')->insert($setarr,true);
            $res = array("res"=>"success","url"=>$burl,"vid"=>$insertid);
            echo json_encode($res);
            exit;
        }
        
    }
    
}


    