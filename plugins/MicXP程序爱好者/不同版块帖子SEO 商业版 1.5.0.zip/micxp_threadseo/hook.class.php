<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_threadseo {

}

class plugin_micxp_threadseo_forum extends plugin_micxp_threadseo{
		
	function viewthread_micxp_threadseo_output(){
		global $_G,$fup,$tagnames,$summary,$nav,$navtitle,$metadescription,$metakeywords;
		if($_G['cache']['plugin']['micxp_threadseo']['M_available']){
			
			$threadseo  = C::t('#micxp_threadseo#micxp_threadseo')->fetch($_G['fid']);
			
			
			if(empty($threadseo)) return ;
			
			$curpage = intval($_GET['page']);
			if($curpage>1){
			    $first_post=C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['forum_thread']['tid']);
			    $tagarray_all = $mixptagnames= array();
			    $tagarray_all = explode("\t", $first_post['tags']);
			    if($tagarray_all) {
			        foreach($tagarray_all as $var) {
			            if($var) {
			                $tag = explode(',', $var);
			                $mixptagnames[] = $tag[1];
			            }
			        }
			    }
			    
			    $micxp_tagnames=$mixptagnames;
			   
			}else{
			    $micxp_tagnames=$tagnames;
			}
			
			$seodata = array('forum' => $_G['forum']['name'], 'fup' => $_G['cache']['forums'][$fup]['name'], 'subject' => $_G['forum_thread']['subject'], 'summary' => $summary, 'tags' => @implode(',', $micxp_tagnames), 'page' => $curpage);
			
			if($_G['forum']['status'] != 3) {
				$seotype = 'viewthread';
			} else {
				$seotype = 'viewthread_group';
				$seodata['first'] = $nav['first']['name'];
				$seodata['second'] = $nav['second']['name'];
			}
			$defset=array();
			if(!empty($threadseo['seo_title'])){
				$defset['seotitle']=$threadseo['seo_title'];
			}
			if(!empty($threadseo['seo_keyword'])){
				$defset['seokeywords']=$threadseo['seo_keyword'];
			}
			if(!empty($threadseo['seo_description'])){
				$defset['seodescription']=$threadseo['seo_description'];
			}
			
			list($navtitle, $metadescription, $metakeywords) = get_seosetting($seotype, $seodata,$defset);
		
			
		
		}
		
		
		
	}
	
	
	
}
//From: Dism_taobao_com
?>