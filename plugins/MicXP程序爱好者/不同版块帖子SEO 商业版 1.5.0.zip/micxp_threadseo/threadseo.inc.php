<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once libfile('function/forumlist');
loadcache('forums');
$Mlang = $scriptlang['micxp_threadseo'];
$forumid = isset($_GET['forumid']) ? dintval($_GET['forumid']) : 0;
$threadseo=C::t('#micxp_threadseo#micxp_threadseo')->fetch($forumid);


if(!submitcheck('seosubmit')) {
	$forumselect = "<select name=\"%s\" id=\"forumid\">\n<option value=\"\">&nbsp;&nbsp;> ".cplang('select')."</option>".str_replace('%', '%%', forumselect(FALSE, 0, $forumid, TRUE)).'</select>';
	
	showformheader('plugins&operation=config&identifier=micxp_threadseo&pmod=threadseo');
	showtableheader(); /*dis'.'m.tao'.'bao.com*/
	showsetting('forums_merge_target', '', '', sprintf($forumselect, 'forumid'));
	
	if($forumid){
		showsetting($Mlang['seo_title'], 'seo_title', $threadseo['seo_title'], 'text','','','','onfocus="getcodetext(this, \'viewthread\');" id="t_seo"');
		showsetting($Mlang['seo_keyword'], 'seo_keyword', $threadseo['seo_keyword'], 'text','','','','onfocus="getcodetext(this, \'viewthread\');" id="k_seo"');
		showsetting($Mlang['seo_description'], 'seo_description', $threadseo['seo_description'], 'text','','','','onfocus="getcodetext(this, \'viewthread\');" id="d_seo"');
	}
	
	showsubmit('seosubmit');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*DISM-TAOBAO-COM*/
	echo "<div id=\"codediv\" style=\"top: 567px; background: transparent url('./static/image/common/mdly.png') no-repeat scroll 0px 0px; height: 100px; line-height: 32px; margin-top: -16px; overflow: hidden; padding: 10px 25px; position: absolute; left: 300px; width: 250px; display: none;\">
		<p>".lang('plugin/micxp_threadseo','tips')."</p>
		<p id=\"seocodes\"></p>
		</div>";
	
	$adminscript =ADMINSCRIPT;
	echo <<<EOT
<script type="text/JavaScript">
	var sdom = document.getElementById('forumid');
sdom.onchange=function(){
	var catids = sdom.options[sdom.options.selectedIndex].value;
	location.href="$adminscript?action=plugins&operation=config&identifier=micxp_threadseo&pmod=threadseo&forumid="+catids;
};
			
			
		function getcodetext(obj, ctype) {
			var codediv = $('codediv');
			var codes='bbname,forum,fup,fgroup,subject,summary,tags,page';
			var top_offset = obj.offsetTop;
			var codecontent = '';
			var targetid = obj.id;
			while((obj = obj.offsetParent).tagName != 'BODY') {
				top_offset += obj.offsetTop;
			}
			types = codes.split(',');
			for(var i = 0; i < types.length; i++) {
				if(codecontent != '') {
					codecontent += '&nbsp;&nbsp;';
				}
				codecontent += '<a onclick="insertContent(\''+targetid+'\', \'{'+types[i]+'}\');return false;" href="javascript:;">{'+types[i]+'}</a>';
			}
			$('seocodes').innerHTML = codecontent;
			codediv.style.top = top_offset + 'px';
			codediv.style.display = '';
			
		}
			
			
		function insertContent(target, text) {
			var obj = $(target);
			selection = document.selection;
			checkFocus(target);
			if(!isUndefined(obj.selectionStart)) {
				var opn = obj.selectionStart + 0;
				obj.value = obj.value.substr(0, obj.selectionStart) + text + obj.value.substr(obj.selectionEnd);
			} else if(selection && selection.createRange) {
				var sel = selection.createRange();
				sel.text = text;
				sel.moveStart('character', -strlen(text));
			} else {
				obj.value += text;
			}
		}
			
		function checkFocus(target) {
			var obj = $(target);
			if(!obj.hasfocus) {
				obj.focus();
			}
		}			
</script>
EOT;
}else{
	$seo_title= daddslashes($_GET['seo_title']);
	$seo_keyword= daddslashes($_GET['seo_keyword']);
	$seo_description= daddslashes($_GET['seo_description']);
	
	$insertdata = array(
			'forumid'=>$forumid,
			'seo_title' => $seo_title,
			'seo_keyword'=>$seo_keyword,
			'seo_description'=>$seo_description,
	);
	
	$updatedata = array(
			'seo_title' => $seo_title,
			'seo_keyword'=>$seo_keyword,
			'seo_description'=>$seo_description,
	);
	
	if(empty($threadseo)){
		C::t('#micxp_threadseo#micxp_threadseo')->insert($insertdata);
	}else{
		C::t('#micxp_threadseo#micxp_threadseo')->update($forumid,$updatedata);
	}
	
	cpmsg($Mlang['threadseo_save'],dreferer(),'succeed');
}
//From: Dism_taobao_com
?>