
var micxp_XMLHttpReq; 
function addmap(cmd) {
	checkFocus();
	showEditorMenu2(cmd);
	return;
}

function showEditorMenu2(tag, params) {
	var sel, selection;
	var str = '', strdialog = 0, stitle = '';
	var ctrlid = editorid + (params ? '_cst' + params + '_' : '_') + tag;
	var opentag = '[' + tag + ']';
	var closetag = '[/' + tag + ']';
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 600;
	var menupos = '43!';
	var menutype = 'menu';

	
	
	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();	
	stitle = micxp_stitle;
	
	
	str = '<p class="pbn"><input id="wxonekeyurl" class="px" value="" style="width: 550px;" type="text"></p>';
	
	menupos = '00';
	menutype = 'win';
	var menu = document.createElement('div');
	menu.id = ctrlid + '_menu';
	menu.style.display = 'none';
	menu.className = 'p_pof upf';
	menu.style.width = menuwidth + 'px';
	if(menupos == '00') {
			menu.className = 'fwinmask';
			s = '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + stitle + '</em><span><a onclick="hideMenu(\'\', \'win\');return false;" class="flbc" href="javascript:;">'+closeicon+'</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>'+getcontent+'</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		} else {
			s = '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">'+closeicon+'</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>'+getcontent+'</strong></button></div></div>';
		}
	menu.innerHTML = s;
	$(editorid + '_editortoolbar').appendChild(menu);
	showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});

	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.V   ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		checkFocus();
		var mapsrc = document.getElementById('wxonekeyurl').value;
		
		showDialog('<div id="getwxinfo"><p class="mbn">'+getdata+'</p><p><img src="static/image/common/uploading.gif" alt="" /></p></div>', 'notice', '', null, 1);
		micxp_sendAjaxRequest('plugin.php?id=micxp_wxonekey:core&url='+escape(mapsrc) );
		hideMenu('', 'win');
		hideMenu();
	};
}




function micxp_createXMLHttpRequest() {  
    try {  
    	micxp_XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
    }  
    catch(E) {  
        try {  
        	micxp_XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
        }  
        catch(E) {  
        	micxp_XMLHttpReq = new XMLHttpRequest();
        }  
    }  
  
}  
function micxp_sendAjaxRequest(url) {  
	micxp_createXMLHttpRequest();                                
    micxp_XMLHttpReq.open("post", url, true);  
    micxp_XMLHttpReq.onreadystatechange = micxp_processResponse; 
    micxp_XMLHttpReq.send(null);  
}  

function micxp_processResponse() {  
    if (micxp_XMLHttpReq.readyState == 4) {  
        if (micxp_XMLHttpReq.status == 200) {  
            var text = micxp_XMLHttpReq.responseText;
            
            var json=JSON.parse(text);
            var sel;
             
            
    		
            document.getElementById('subject').value=json.subject;
    			parent.ATTACHORIMAGE = 1;
    			parent.wxupdateDownImageList(json.message);

    		
        }  
    } 
} 


function wxupdateDownImageList(msg) {
	hideMenu('fwin_dialog', 'dialog');
	if(msg == '') {
		showError(wxnodata);
	} else {
		ajaxget('forum.php?mod=ajax&action=imagelist&pid=' + pid + '&posttime=' + $('posttime').value + (!fid ? '' : '&fid=' + fid), 'imgattachlist', null, null, null, function(){if(wysiwyg) {editdoc.body.innerHTML = msg;switchEditor(0);switchEditor(1)} else {textobj.value = msg;}});
		switchImagebutton('imgattachlist');$('imgattach_notice').style.display = '';
		showDialog(wxgetdatasuccess, 'right', null, null, 0, null, null, null, null, 3);
	}
	hideMenu();
}