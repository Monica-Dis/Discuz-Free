<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_wxonekey {
    function discuzcode($param){
        global $_G;
        include_once 'source/plugin/micxp_wxonekey/include/micxp_video.php';
        if($param['caller'] == 'discuzcode') {
            $_G['has_wxonekey']=1;

            $_G['discuzcodemessage'] = preg_replace_callback('/\[micxp_wxonkey\](.*?)\[\/micxp_wxonkey\]/is', create_function('$matches','return _message_to_wxonekey_video($matches[1],"");'), $_G['discuzcodemessage']);
        }
        if($param['caller'] == 'messagecutstr') {
            $_G['discuzcodemessage'] = preg_replace('/\[micxp_wxonkey\](.*?)\[\/micxp_wxonkey\]/is', '', $_G['discuzcodemessage']);
        }
    }
    
    
    function global_footer_mobile(){
        global $_G;
        if($_G['has_wxonekey']){
            $html='';
            include template('micxp_wxonekey:js');
            return $html;
        }
    }
}


class mobileplugin_micxp_wxonekey_forum extends  mobileplugin_micxp_wxonekey{
	
	function post_bottom_mobile(){
		global $_G;
		$micxp_setting = $_G['cache']['plugin']['micxp_wxonekey'];
		
		if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['groupsAllowed']))) return '';
		if(!in_array($_G['fid'],(array)unserialize($micxp_setting['forumsAllowed']))) return '';
		
		if(empty($_G['fid'])) return '';
		
		$css ='<style>.mx_btn{text-align:center;}.mx_btn a{background-color: #2f9833;color: #fff;height: 33px;
line-height: 33px;
*line-height: 31px;
width: 120px;display: inline-block;
overflow: visible;
vertical-align: middle;
text-align: center;
border-radius: 3px;
-moz-border-radius: 3px;
-webkit-border-radius: 3px;
border-width: 1px;
border-style: solid;
cursor: pointer;
background-color: #44b549;}</style>';
		$url = $_G['siteurl']."plugin.php?id=micxp_wxonekey:weixin&fid=".$_G['fid'];
		$html='<div class="mx_btn"><a href="'.$url.'">'.lang("plugin/micxp_wxonekey","post_weixin").'</a></div>';
		
		return $css.$html;
	}
}
//From: Dism_taobao_com
?>