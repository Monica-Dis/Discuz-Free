<?php
/**
 *      wxonekey 7.0.0 by https://dism.taobao.com
 *      2019-11-6
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_micxp_wxonekey {
    function discuzcode($param){
        global $_G;
        include_once 'source/plugin/micxp_wxonekey/include/micxp_video.php';
        if($param['caller'] == 'discuzcode') {
            $_G['has_wxonekey']=1;
            
            $_G['discuzcodemessage'] = preg_replace_callback('/\[micxp_wxonkey\]([^\]]*?)\[\/micxp_wxonkey\]/is', create_function('$matches','return _message_to_wxonekey_video($matches[1],"");'), $_G['discuzcodemessage']);
        }
        if($param['caller'] == 'messagecutstr') {
            $_G['discuzcodemessage'] = preg_replace('/\[micxp_wxonkey\]([[^\]]*?)\[\/micxp_wxonkey\]/is', '', $_G['discuzcodemessage']);
        } 
    }

    
    function global_footer(){
        global $_G;
        if($_G['has_wxonekey']){
           $html='';
           include template('micxp_wxonekey:js');
           return $html;
        } 
    }
    

}

class plugin_micxp_wxonekey_forum extends plugin_micxp_wxonekey {
       function post_editorctrl_left() {
       	   
	   	   global $Plang,$_G;
		   
		   $micxp_setting = $_G['cache']['plugin']['micxp_wxonekey'];
		   
		   if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['groupsAllowed']))) return '';
		   if(!in_array($_G['fid'],(array)unserialize($micxp_setting['forumsAllowed']))) return '';
		   $onekeybtn = "<script type=\"text/javascript\">var wxgetdatasuccess = '".lang('plugin/micxp_wxonekey','wxgetdatasuccess')."';var wxnodata = '".lang('plugin/micxp_wxonekey','wxnodata')."';var micxp_stitle = '".lang('plugin/micxp_wxonekey','mytitle')."';var getcontent = '".lang('plugin/micxp_wxonekey','getcontent')."'; var closeicon = '".lang('plugin/micxp_wxonekey','closeicon')."';var getdata = '".lang('plugin/micxp_wxonekey','getdata')."';</script><link rel=\"stylesheet\" href=\"source/plugin/micxp_wxonekey/img/btn_wxonekey.css\" type=\"text/css\" /><script src=\"source/plugin/micxp_wxonekey/js/wxonekey.js\" type=\"text/javascript\"></script><a id=\"btn_wxonekey\" title=\"".lang('plugin/micxp_wxonekey','getweixinarticle')."\" onClick=\"addmap('btn_wxonekey')\" href='javascript:void(0);' >".lang('plugin/micxp_wxonekey','wxarticle')."</a>"; 
		   return $onekeybtn;
		}

}

class plugin_micxp_wxonekey_group extends plugin_micxp_wxonekey {
	function post_editorctrl_left() {
		 
		global $Plang,$_G;
		
		$micxp_setting = $_G['cache']['plugin']['micxp_wxonekey'];
		
		if(!empty($micxp_setting['M_isgroup'])){
			if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['groupsAllowed']))) return '';
			$onekeybtn = "<script type=\"text/javascript\">var wxgetdatasuccess = '".lang('plugin/micxp_wxonekey','wxgetdatasuccess')."';var wxnodata = '".lang('plugin/micxp_wxonekey','wxnodata')."';var micxp_stitle = '".lang('plugin/micxp_wxonekey','mytitle')."';var getcontent = '".lang('plugin/micxp_wxonekey','getcontent')."'; var closeicon = '".lang('plugin/micxp_wxonekey','closeicon')."';var getdata = '".lang('plugin/micxp_wxonekey','getdata')."';</script><link rel=\"stylesheet\" href=\"source/plugin/micxp_wxonekey/img/btn_wxonekey.css\" type=\"text/css\" /><script src=\"source/plugin/micxp_wxonekey/js/wxonekey.js\" type=\"text/javascript\"></script><a id=\"btn_wxonekey\" title=\"".lang('plugin/micxp_wxonekey','getweixinarticle')."\" onClick=\"addmap('btn_wxonekey')\" href='javascript:void(0);' >".lang('plugin/micxp_wxonekey','wxarticle')."</a>";
			return $onekeybtn;
		}
		
	}

}
//From: Dism��taobao��com
?>