<?php 
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$_G['fid']=intval($_GET['fid']);
if(empty($_G['fid'])){
	showmessage(lang("plugin/micxp_wxonekey","notfid"),dreferer());
}

require_once libfile('function/forumlist');
$forumselect = "<select name=\"%s\" id=\"forumid\">\n".str_replace('%', '%%', forumselect(FALSE, 0, $_G['fid'])).'</select>';


$micxp_setting = $_G['cache']['plugin']['micxp_wxonekey'];

if(!in_array($_G['groupid'],(array)unserialize($micxp_setting['groupsAllowed']))) {
	showmessage(lang("plugin/micxp_wxonekey","groupidnotallowed"),dreferer());
}
if(!in_array($_G['fid'],(array)unserialize($micxp_setting['forumsAllowed']))){
	showmessage(lang("plugin/micxp_wxonekey","forumsnotallowed"),dreferer());
}


if(submitcheck('formhash')){
	$url = $_GET['url'];
	if(empty($url)){
		showmessage(lang("plugin/micxp_wxonekey","input_url"),dreferer());
	}
	$content = get_weixin_article($url);
	
	
	if(empty($content)){
		$gourl =$_G['siteurl']."plugin.php?id=micxp_wxonekey:weixin&fid=".$_G['fid'];
		showmessage(lang("plugin/micxp_wxonekey","save_error"),$gourl);
	}else{
		
		$tid = insert_to_database($content);
		
		$gourl = $_G['siteurl']."forum.php?mod=viewthread&tid=".$tid;
		showmessage(lang("plugin/micxp_wxonekey","save_ok"),$gourl);
	}
	
}else{
	
	include template("micxp_wxonekey:weixin");
}

function get_weixin_article($url){
	global $_G;
	$source = dfsockopen($url);
	if(empty($source)) return ;
	
	$source = diconv($source, 'UTF-8');
	$pattern=$_G['cache']['plugin']['micxp_wxonekey']['M_regex_title'];
	preg_match($pattern, $source,$title);
	$title=trim($title[1]);
	$title=strip_tags($title);
	$title = daddslashes($title);
	if(empty($title)) return ;
	
	$pattern=$_G['cache']['plugin']['micxp_wxonekey']['M_regex_content'];
	
	preg_match($pattern, $source,$content);
	$content=$content[1];
	$content = downloadimage($content);
	
	$content_array = explode("#=#=#=#=#=#=#=#=#=#=#=#", $content);
	$content=$content_array['0'];
	
	$imageaidstr = $content_array['1'];
	
	$data['imageaid']=$imageaidstr;
	$data['subject']=filter_html($title);
	
	if($_G['cache']['plugin']['micxp_wxonekey']['M_style']){
		$data['message']=filter_html($content);
	}else{
		$data['message']=$content;
	}
	return $data;
}




function filter_html($string) {
	$string=strip_tags($string,'<br>');
	return $string;
}

function downloadimage($content,$type=''){
	global $_G;
	static $imageaid = array();
	$imgurl=array();
	$upload = new discuz_upload();

	$pimg="/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/";
	preg_match_all($pimg,$content,$imgurl);
	
	foreach ($imgurl[1] as  $ik=>$iv){

	    if(preg_match("/v\.qq\.com.*?vid=([^&]*?)(.*)?/Ui", $iv,$arr)){
	        if(!empty($arr[1])){
	            
	            $newurl = '[micxp_wxonkey]'.$arr[1].'[/micxp_wxonkey]';
	        }else{
	            $newurl = '';
	            
	        }
	        
	        
	    }else{
			$pos = strpos($iv, '?');
			if($pos){
				$iv = substr($iv, 0,$pos);
			}
			$iv=rtrim($iv,'640');
			$im ="";
			$minfo = $attach= array();
			$im = dfsockopen($iv);
				
			if(empty($im)){
				$content= str_replace($imgurl[0][$ik], '', $content);
				continue;
			}
			$minfo =getimagesize("data://text/plain;base64," . base64_encode($im));
			if($minfo['mime']=='image/jpeg'){
				$attach['ext']='jpg';
			}elseif($minfo['mime']=='image/gif'){
				$attach['ext']='gif';
			}elseif($minfo['mime']=='image/png'){
				$attach['ext']='png';
			}elseif($minfo['mime']=='image/bmp'){
				$attach['ext']='bmp';
			}
				
			if(empty($attach['ext'])) continue;
			if($minfo['0']<100 && $minfo['1']<100) continue;

			$attach['name'] =  md5($iv).'.'.$attach['ext'];
			$attach['thumb'] = '';
			$attach['isimage'] = $upload -> is_image_ext($attach['ext']);
			$attach['extension'] = $upload -> get_target_extension($attach['ext']);
				
			$attach['attachdir'] = $upload -> get_target_dir('forum');
			$attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
			$attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];
				
				
			if (!@$fp = fopen($attach['target'], 'wb'))
			{
				continue;
			} else{
				flock($fp, 2);
				fwrite($fp, $im);
				fclose($fp);
			}
				
			if(!$upload->get_image_info($attach['target'])) {
				@unlink($attach['target']);
				continue;
			}
			$attach['size'] = filesize($attach['target']);
				
			$upload->attach = $attach;
			$thumb = $width = 0;
			$aids[] = $aid = getattachnewaid();
			if($_G['cache']['plugin']['micxp_wxonekey']['M_water']){
				$image = new image();
				$image->Watermark($attach['target']);
			}
				
			$setarr = array(
					'aid' => $aid,
					'dateline' => $_G['timestamp'],
					'filename' => $upload->attach['name'],
					'filesize' => $upload->attach['size'],
					'attachment' => $upload->attach['attachment'],
					'isimage' => $upload->attach['isimage'],
					'uid' => $_G['uid'],
					'thumb' => $thumb,
					'remote' => '0',
					'width' => $minfo['0']
			);
				
			C::t("forum_attachment_unused")->insert($setarr);
			$newurl = "<br>[attachimg]".$aid."[/attachimg]";
			array_push($imageaid, $aid);
		}

		if(!empty($newurl)){
			$content= str_replace($imgurl[0][$ik], $newurl, $content);
		}else{
			$content= str_replace($imgurl[0][$ik], "", $content);
		}

	}
	return $content."#=#=#=#=#=#=#=#=#=#=#=#".serialize($imageaid);

}


function insert_to_database($content){
	
		global $_G;
		
		$clientip=$_G['clientip'];
		require_once libfile('class/credit');
		require_once libfile('function/forum');
		require_once libfile('function/post');
		require_once libfile('function/stat');
		require_once libfile('function/editor');
		$content['content']= html2bbcode($content['message']);
		
		$imageaid = unserialize($content['imageaid']);
		
		if(!empty($imageaid)){
			$attachment=2;
		}else{
			$attachment=0;
		}
		
		$newthread = array(
				'fid' =>$_G['fid'],
				'posttableid' => 0,
				'readperm' => '',
				'price' => 0,
				'typeid' => 0,
				'sortid' => 0,
				'author' => $_G['username'],
				'authorid' => $_G['uid'],
				'subject' => daddslashes($content['subject']),
				'views'	 =>	1,
				'dateline' => TIMESTAMP,
				'lastpost' => TIMESTAMP,
		        'lastposter' => $_G['username'],
				'displayorder' => 0,
				'digest' => 0,
				'special' => 0,
				'attachment' => $attachment,
				'moderated' => 0,
				'status' => 32,
				'isgroup' => 0,
				'replycredit' => 0,
				'closed' => 0,
		);
		$tid = C::t('forum_thread')->insert($newthread, true);
		C::t('forum_newthread')->insert(array(
		'tid' => $tid,
		'fid' => $_G['fid'],
		'dateline' => TIMESTAMP,
		));
		useractionlog($_G['uid'], 'tid');
		C::t('common_member_field_home')->update($_G['uid'], array('recentnote'=>daddslashes($content['subject'])));
			
		$bbcodeoff = checkbbcodes($content['message'], 0);
		$smileyoff = checksmilies($content['message'], 0);
		$htmlon = strpos($content['message'] , '<') !==false ? 1 : 0;
		$htmlon = 0;
			
		$content['message'] = preg_replace('/\[attachimg\](\d+)\[\/attachimg\]/is', '[attach]\1[/attach]', $content['content']);

		
			
		$pid = insertpost(array(
				'fid' =>$_G['fid'],
				'tid' => $tid,
				'first' => 1,
				'author' => $_G['username'],
				'authorid' => $_G['uid'],
				'subject' => daddslashes($content['subject']),
				'dateline' => TIMESTAMP,
				'message' => $content['message'],
				'useip' => $clientip,
				'invisible' => '',
				'anonymous' => '',
				'usesig' => '',
				'htmlon' => $htmlon,
				'bbcodeoff' => $bbcodeoff,
				'smileyoff' => $smileyoff,
				'parseurloff' => '',
				'attachment' => '0',
				'tags' => '',
				'replycredit' => 0,
				'status' => 0
		));
			
		updatestat('thread');
		updatepostcredits('+',  $_G['uid'], 'post',$_G['fid']);
		C::t('forum_forum')->update_forum_counter($_G['fid'], 1, 1, 1);
		if(!empty($imageaid)){

			foreach ($imageaid as $single){
				$single = intval($single);
				$attachtable = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$single'");
				!$attachtable && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_unused')." WHERE aid='$single' AND uid='$_G[uid]' AND isimage='1'");
				$attachtable = $attachtable == 127 ? 'unused' : $attachtable;
				($attachtable && empty($attachment)) && $attachment = DB::fetch_first("SELECT * FROM ".DB::table('forum_attachment_'.$attachtable)." WHERE aid='$single' AND uid='$_G[uid]' AND isimage='1'");
				if(!empty($attachment)){
					if($attachtable == 'unused') {
						convertunusedattach($single, $tid, $pid);
					}
					$tableid = DB::result_first("SELECT posttableid FROM ".DB::table('forum_thread')." WHERE tid='$tid'");
					if(!$tableid) {
						$tablename = 'forum_post';
					} else {
						$tablename = "forum_post_$tableid";
					}
					DB::query("UPDATE ".DB::table('forum_thread')." SET attachment=2 WHERE tid='$tid'");
					DB::query("UPDATE ".DB::table($tablename)." SET attachment=2 WHERE pid='$pid'");

				}
				$attachtable = $attachment =$tableid =$tablename ='';
			}

		}
			
	return $tid;

}
//From: Dism��taobao��com
?>