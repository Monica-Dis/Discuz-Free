<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
require './source/function/function_editor.php';



$url = getgpc('url');
$source = dfsockopen($url);

$pattern=$_G['cache']['plugin']['micxp_wxonekey']['M_regex_title'];

preg_match($pattern, $source,$title);


$title=trim($title[1]);
$title=strip_tags($title);
$title = daddslashes($title);
if(empty($title)){
    exit('');
}
$pattern=$_G['cache']['plugin']['micxp_wxonekey']['M_regex_content'];
preg_match($pattern, $source,$content);

$content=$content[1];

$content = get_music($content);

$content = downloadimage($content);



$data['subject']=filter_html($title);

if($_G['cache']['plugin']['micxp_wxonekey']['M_style']){
	$data['message']=filter_html($content);
}else{
	$data['message']=$content;
}



echo json_encode($data);
exit;


function filter_html($string) {
	$string=strip_tags($string,'<br>');
	return $string;
}

function get_music($content){
    $music_parent='/<qqmusic.*?audiourl=[\'|\"](.*?)[\'|\"].*?><\/qqmusic>/';
    preg_match_all($music_parent,$content,$music_url);
    
    foreach ($music_url[1] as  $ik=>$iv){
        $music_u = '[audio]'.$iv.'[/audio]';
        $content= str_replace($music_url[0][$ik], $music_u, $content);
    }

    return $content;
}


function downloadimage($content,$type=''){
	global $_G;
	$imgurl=array();
	$upload = new discuz_upload();
	
	$pimg="/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/";
	preg_match_all($pimg,$content,$imgurl);
	
	
	foreach ($imgurl[1] as  $ik=>$iv){
		
		if(preg_match("/[mp\.weixin|v]\.qq\.com.*?vid=([^&]*?)(.*)?/Ui", $iv,$arr)){		    
			if(!empty($arr[1])){
			  
				$newurl = '[micxp_wxonkey]'.$arr[1].'[/micxp_wxonkey]';
			}else{
				$newurl = '';
				
			}	
			
			
		}else{

			$pos = strpos($iv, '?');
			if($pos){
				$iv = substr($iv, 0,$pos);
			}
			$iv=rtrim($iv,'640');
			
			$im ="";
			$minfo = $attach= array();
			$im = dfsockopen($iv);
			
			if(empty($im)){
				$content= str_replace($imgurl[0][$ik], '', $content);
				continue;
			}
			$minfo =getimagesize("data://text/plain;base64," . base64_encode($im));
			if($minfo['mime']=='image/jpeg'){
				$attach['ext']='jpg';
			}elseif($minfo['mime']=='image/gif'){
				$attach['ext']='gif';
			}elseif($minfo['mime']=='image/png'){
				$attach['ext']='png';
			}elseif($minfo['mime']=='image/bmp'){
				$attach['ext']='bmp';
			}
			
			if(empty($attach['ext'])) continue;
			if($minfo['0']<100 && $minfo['1']<100) continue;
	
			$attach['name'] =  md5($iv).'.'.$attach['ext'];
			$attach['thumb'] = '';
			$attach['isimage'] = $upload -> is_image_ext($attach['ext']);
			$attach['extension'] = $upload -> get_target_extension($attach['ext']);
			
			$attach['attachdir'] = $upload -> get_target_dir('forum');
			$attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
			$attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];
			
			
			if (!@$fp = fopen($attach['target'], 'wb'))
			{
				continue;
			} else{
				flock($fp, 2);
				fwrite($fp, $im);
				fclose($fp);
			}
			
			if(!$upload->get_image_info($attach['target'])) {
				@unlink($attach['target']);
				continue;
			}
			$attach['size'] = filesize($attach['target']);
			
			$upload->attach = $attach;
			$thumb = $width = 0;
			$aids[] = $aid = getattachnewaid();
			if($_G['cache']['plugin']['micxp_wxonekey']['M_water']){
				$image = new image();
				$image->Watermark($attach['target']);
			}
			
			$setarr = array(
					'aid' => $aid,
					'dateline' => $_G['timestamp'],
					'filename' => $upload->attach['name'],
					'filesize' => $upload->attach['size'],
					'attachment' => $upload->attach['attachment'],
					'isimage' => $upload->attach['isimage'],
					'uid' => $_G['uid'],
					'thumb' => $thumb,
					'remote' => '0',
					'width' => $minfo['0']
			);
			
			C::t("forum_attachment_unused")->insert($setarr);
			$newurl = "<br>[attachimg]".$aid."[/attachimg]<br>";
		}
		
		if(!empty($newurl)){
			$content= str_replace($imgurl[0][$ik], $newurl, $content);
		}else{
			$content= str_replace($imgurl[0][$ik], "", $content);
		}

	}
	return $content;

}


