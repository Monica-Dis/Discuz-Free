<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_titletag {

}

class mobileplugin_micxp_titletag_portal extends mobileplugin_micxp_titletag{
    
    function view_micxp_output(){
        global $_G, $metakeywords, $article, $content;
        
        $aid = !empty($_GET['aid']) ? intval($_GET['aid']) : '0';
        $tagstring = DB::result_first("SELECT tags FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$aid' AND idtype = 'articleid'");
        
        if(empty($tagstring)){
            $itemid=$aid;
            
            if(CHARSET=='UTF-8'){
                $vi=3;
            }else{
                $vi=2;
            }
            $key['1']=cutstr($article['title'], $vi*2,'');
            $key['2']=cutstr($article['title'], $vi*3,'');
            $key['3']=cutstr($article['title'], $vi*4,'');
            $key['4']=cutstr($article['title'], $vi*5,'');
            
            $tagarray=array_unique($key);
            
            //debug($key);
            
            $tagcount = 0;
            $returnarray = 0;
            foreach($tagarray as $tagname) {
                $tagname = trim($tagname);
                $idtype='articleid';
                //if(preg_match('/^([\x7f-\xff_-]|\w|\s){3,100}$/', $tagname)) {
                $status = $idtype != 'uid' ? 0 : 3;
                $result = C::t('common_tag')->get_bytagname($tagname, $idtype);
                
                if($result['tagid']) {
                    if($result['status'] == $status) {
                        $tagid = $result['tagid'];
                    }
                } else {
                    $tagid = C::t('common_tag')->insert($tagname,$status);
                }
                if($tagid) {
                    if($itemid) {
                        C::t('common_tagitem')->replace($tagid,$itemid,$idtype);
                    }
                    $tagcount++;
                    if(!$returnarray) {
                        $return .= $tagid.','.$tagname."\t";
                    } else {
                        $return[$tagid] = $tagname;
                    }
                    
                }
                
                
                
                
                //}
            }
            
            
            
            if($return == '') return;
            $tags=$return;
            $tagid = DB::result_first("SELECT tagid FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$itemid' AND idtype = '$idtype'");
            if($tagid > 0) {
                DB::query("UPDATE ".DB::table('plugin_onexin_tags')." SET tags = '$tags', idtype = '$idtype' WHERE tagid='$tagid'");
            }else{
                DB::query("INSERT INTO ".DB::table('plugin_onexin_tags')." (tags, idtype, itemid) VALUES ('$tags', '$idtype', '$itemid')");
            }
            
            
            //             $tags = self::add_tag($tags, $itemid, $idtype, 0);
            //             if($tags == '') return;
            
            //             $tagid = DB::result_first("SELECT tagid FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$itemid' AND idtype = '$idtype'");
            //             if($tagid > 0) {
            //                 DB::query("UPDATE ".DB::table('plugin_onexin_tags')." SET tags = '$tags', idtype = '$idtype' WHERE tagid='$tagid'");
            //             }else{
            //                 DB::query("INSERT INTO ".DB::table('plugin_onexin_tags')." (tags, idtype, itemid) VALUES ('$tags', '$idtype', '$itemid')");
            //             }
            
            
        }
        
        //         $tags = explode("\t", $tagstring);
        
        //         $tags_arr= self::micxp_get_tag($tags);
        //         debug($tags_arr);
        
    }
    
    
    public function micxp_get_tag($tags, $itemid = 0){
        global $_G;
        $tagarray = $tagarray_data = array();
        foreach($tags as $key => $var) {
            if($var) {
                $array_temp = is_string($var) ? explode(',', $var) : $var;
                $tagarray[$array_temp['0']] = $array_temp['1'];
                $tagarray_data[$key]['tagid'] = $array_temp['0'];
                $tagarray_data[$key]['tagname'] = $array_temp['1'];
            }
        }
        return array($tagarray_data, implode(',', $tagarray), implode(' ', $tagarray));
    }
}
//From: Dism��taobao��com
?>