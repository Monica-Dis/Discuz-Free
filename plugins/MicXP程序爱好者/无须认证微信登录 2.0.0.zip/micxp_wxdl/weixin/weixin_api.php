<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once 'source/plugin/micxp_wxdl/weixin/class/wx_message.class.php';
   
$echoStr = $_GET["echostr"];
if(checkSignature()){
	if($echoStr){
		echo $echoStr;
		exit;
	}else{
		getmsg();
	}
}
function getmsg(){
    global $_G;
	$postdata = file_get_contents("php://input");
	if ($postdata) {
	    include_once 'source/plugin/micxp_wxdl/weixin/class/wx_event.class.php';
		$postObj = simplexml_load_string($postdata, 'SimpleXMLElement', LIBXML_NOCDATA);
		$postObj = micxp_handlePostObj($postObj);
	
		if (isset($postObj['event'])) {
			
			switch ($postObj['event']){
				case 'subscribe':
					wx_event::subscribe($postObj);
					break;
				
			}
		} else {
			switch ($postObj['type']){
				case 'text':
				    $bind_key=diconv($_G['cache']['plugin']['micxp_wxdl']['M_bind'],CHARSET,'UTF-8');
				    if($postObj['content']==$bind_key){
				        wx_event::send_wxbind_news($postObj); 
				    }
				    if(is_numeric($postObj['content'])){
				        wx_event::loginwxuser($postObj);
				    }
					break;
			}
		}
		
	} 
}


function micxp_handlePostObj($postObj) {
	$MsgType = strtolower((string) $postObj->MsgType);
	$result = array(
			'from' => (string) htmlspecialchars($postObj->FromUserName),
			'to' => (string) htmlspecialchars($postObj->ToUserName),
			'time' => (int) $postObj->CreateTime,
			'type' => (string) $MsgType
	);

	if (property_exists($postObj, 'MsgId')) {
		$result['id'] = $postObj->MsgId;
	}

	switch ($result['type']) {
		case 'text':
			$result['content'] = (string) $postObj->Content;
			break;

		case 'location':
			$result['X'] = (float) $postObj->Location_X;
			$result['Y'] = (float) $postObj->Location_Y;
			$result['S'] = (float) $postObj->Scale; 
			$result['I'] = (string) $postObj->Label;
			break;

		case 'image':
			$result['url'] = (string) $postObj->PicUrl; 
			$result['mid'] = (string) $postObj->MediaId; 
			break;

		case 'video':
			$result['mid'] = (string) $postObj->MediaId; 
			$result['thumbmid'] = (string) $postObj->ThumbMediaId; 
			break;

		case 'link':
			$result['title'] = (string) $postObj->Title;       
			$result['desc'] = (string) $postObj->Description; 
			$result['url'] = (string) $postObj->Url; 
			break;

		case 'voice':
			$result['mid'] = (string) $postObj->MediaId; 
			$result['format'] = (string) $postObj->Format;      
			if (property_exists($postObj, Recognition)) {
				$result['txt'] = (string) $postObj->Recognition; 
			}
			break;

		case 'event':
			$result['event'] = strtolower((string) $postObj->Event);
			switch ($result['event']) {
				case 'subscribe': 
				case 'scan': 
					if (property_exists($postObj, EventKey)) {
						
						$result['key'] = str_replace(
								'qrscene_', '', (string) $postObj->EventKey
						);
						$result['ticket'] = (string) $postObj->Ticket;
					}
					break;

				case 'location':
					$result['la'] = (string) $postObj->Latitude;  
					$result['lo'] = (string) $postObj->Longitude; 
					$result['p'] = (string) $postObj->Precision;
					break;

				case 'click': 
					$result['key'] = (string) $postObj->EventKey; 
					break;
				case 'masssendjobfinish':
					$result['msg_id'] = (string) $postObj->MsgID;
					$result['status'] = (string) $postObj->Status;
					$result['totalcount'] = (string) $postObj->TotalCount;
					$result['filtercount'] = (string) $postObj->FilterCount;
					$result['sentcount'] = (string) $postObj->SentCount;
					$result['errorcount'] = (string) $postObj->ErrorCount;
			}
	}

	return $result;
}


function checkSignature()
{
	$signature = $_GET["signature"];
	$timestamp = $_GET["timestamp"];
	$nonce = $_GET["nonce"];

	$token = MX_TOKEN;
	$tmpArr = array($token, $timestamp, $nonce);
	sort($tmpArr, SORT_STRING);
	$tmpStr = implode( $tmpArr );
	$tmpStr = sha1( $tmpStr );

	if( $tmpStr == $signature ){
		return true;
	}else{
		return false;
	}
}


