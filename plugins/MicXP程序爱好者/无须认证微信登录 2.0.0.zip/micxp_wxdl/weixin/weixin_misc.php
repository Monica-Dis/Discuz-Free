<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET['action'] = in_array($_GET['action'], array('tmpqrcode','bind')) ? $_GET['action'] : 'tmpqrcode';

$qrauth = authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $_G['config']['security']['authkey']);

if(!$_G['uid'] || !$qrauth){
    $_GET['action']='tmpqrcode';
}
if($_GET['action'] == 'tmpqrcode' || $_GET['action'] == 'bind'){
	if(submitcheck('formhash',true)){
		$random = daddslashes($_GET['random']);
		$micxp_key= authcode($random,'ENCODE',$micxp_setting['M_key']);
	
		$expire = max(intval($micxp_setting['M_expire']),1)*60;
		$scene_id=rand(1,100000);
		if($_GET['action'] == 'bind'){
		    $scene_id=rand(100001,200000);
		}
		dsetcookie('micxp_wxdl_scene_id',$scene_id);
		$insertarr=array(
			'scene_id'=>$scene_id,
			'expire'=>TIMESTAMP+$expire,
			'status'=>0,
			'micxp_key'=>$micxp_key,
			'random'=>$random,
		    'uid'=>$_G['uid'],
		);
		
		
	    $scan = C::t('#micxp_wxdl#micxp_wxdl_scan')->fetch($scene_id);
	    if(!$scan){
	        C::t('#micxp_wxdl#micxp_wxdl_scan')->insert($insertarr);
	        	
	    }else{
	        unset($insertarr['scene_id']);
	        C::t('#micxp_wxdl#micxp_wxdl_scan')->update($scene_id,$insertarr);
	    }
		
		
	    $qrcodesrc='';
	    if(is_file(DISCUZ_ROOT.'/data/sysdata/cache_micxp_wxdl_qrcode.php')){
	        include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_wxdl_qrcode.php';
	    }
	    
	    $qrcodesrc=$_G['siteurl'].$_G['setting']['attachurl'].'common/'.$qrcodesrc;
		$qrcode =$qrcodesrc;
		$img=$qrcode;
		$info = getimagesize($img);
		$imgExt = image_type_to_extension($info[2], false); 
		$fun = "imagecreatefrom{$imgExt}";
		$imgInfo = $fun($img); 
		if(function_exists('exif_imagetype')){
		    $mime = image_type_to_mime_type(exif_imagetype($img)); 
		}else{
		    $mime = image_type_to_mime_type(2); 
		}
		
		header('Content-Type:'.$mime);
		$quality = 100;
		if($imgExt == 'png') $quality = 9; 
		$getImgInfo = "image{$imgExt}";
		$getImgInfo($imgInfo, null, $quality);
		imagedestroy($imgInfo);
		exit;
	}
	
}


