<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wx_message {

	public function resText($postObj){
		$template='<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[%s]]></MsgType>
<Content><![CDATA[%s]]></Content>
</xml>';
		$formUser = $postObj['from'];
		$toUser	= $postObj['to'];
		$time=TIMESTAMP;
		$type='text';
		$content=$postObj['content'];
		$return = sprintf($template,$formUser,$toUser,$time,$type,$content);
		$return= diconv($return, CHARSET, 'UTF-8');
		echo $return;
		exit();
		
	}
	
	public function resNews($postObj){
		$itemtemplate='<item>
<Title><![CDATA[%s]]></Title> 
<Description><![CDATA[%s]]></Description>
<PicUrl><![CDATA[%s]]></PicUrl>
<Url><![CDATA[%s]]></Url>
</item>';
		foreach ($postObj['item'] as $value){
			$item.=sprintf($itemtemplate,$value['title'],$value['description'],$value['picurl'],$value['url']);
		}
		$template='<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[%s]]></MsgType>
<ArticleCount>%s</ArticleCount>
<Articles>';
		$template.=$item;
		$template.='</Articles>
</xml>';
		$formUser = $postObj['from'];
		$toUser	= $postObj['to'];
		$time=TIMESTAMP;
		$type='news';
		$count=$postObj['count'];
		$return=sprintf($template,$formUser,$toUser,$time,$type,$count);
		$return= diconv($return, CHARSET, 'UTF-8');
		echo $return;
		exit();
		
	}
	
	
	
}