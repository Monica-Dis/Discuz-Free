<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wx_event{
	public function subscribe($postObj){
		global $_G;
		if(!empty($_G['cache']['plugin']['micxp_wxdl']['M_welcome'])){
			$postObj['content']=$_G['cache']['plugin']['micxp_wxdl']['M_welcome'];
			wx_message::resText($postObj);
		}
		
	}
	public function send_wxbind_news($postObj){
	    global $_G;
	    $wxuser = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch($postObj['from']);
	    if($wxuser && $wxuser['type']=='bind' && $wxuser['uid']){
	        
	        $uinfo = getuserbyuid($wxuser['uid']);
	        $postObj['content']=lang('plugin/micxp_wxdl','has_bind_user',array(1=>$uinfo['username']));
	        wx_message::resText($postObj);
	    }
	    if(empty($wxuser)){
	        $setarr = array(
	            'openid'=>$postObj['from'],
	            'uid'=>0,
	            'type'=>'bind',
	            'passwordset'=>1,
	        );
	        
	        C::t('#micxp_wxdl#micxp_wxdl_user')->insert($setarr);
	    }
	    
	    $postObj['item']=array(
	        array(
	            'title'=>lang('plugin/micxp_wxdl','bd_news_title'),
	            'description'=>lang('plugin/micxp_wxdl','bd_news_description'),
	            'picurl'=>$_G['siteurl'].'source/plugin/micxp_wxdl/static/images/bind.jpg',
	            'url'=>$_G['siteurl'].'plugin.php?id=micxp_wxdl:bind&openid='.$postObj['from'],
	            
	        ),
	    );
	    $postObj['count']=1;	
	    wx_message::resNews($postObj);
	}
	
	public function bindwxuser($postObj){
	   
	    $wxuser = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch($postObj['from']);	    
	    $scaninfo = C::t('#micxp_wxdl#micxp_wxdl_scan')->fetch($postObj['content']);
	    
	    if(empty($scaninfo['uid'])){
	        $postObj['content']=lang('plugin/micxp_wxdl','bind_error');
	        wx_message::resText($postObj);
	    }
	    
	    if($wxuser && $wxuser['type']=='bind' && $wxuser['uid']){
	        $uinfo = getuserbyuid($wxuser['uid']);
	        $postObj['content']=lang('plugin/micxp_wxdl','has_bind',array(1=>$uinfo['username']));
	        wx_message::resText($postObj);
	    }elseif($wxuser && $wxuser['type']=='register'){
            C::t('#micxp_wxdl#micxp_wxdl_user')->delete_by_uid($scaninfo['uid']);
            C::t('#micxp_wxdl#micxp_wxdl_user')->update($postObj['from'],array('uid'=>$scaninfo['uid'],'type'=>'bind','passwordset'=>1));
            C::t('#micxp_wxdl#micxp_wxdl_scan')->update($postObj['content'],array('status'=>1));
	    }else{
	        $setarr = array(
	            'openid'=>$postObj['from'],
	            'uid'=>$scaninfo['uid'],
	            'type'=>'bind',
	            'passwordset'=>1,
	        );
	        C::t('#micxp_wxdl#micxp_wxdl_user')->insert($setarr);
	        C::t('#micxp_wxdl#micxp_wxdl_scan')->update($postObj['content'],array('status'=>1));   
	    }
	    
	    $postObj['content']=lang('plugin/micxp_wxdl','bind_success');
	    wx_message::resText($postObj);
	    
	}
	
	
	public function loginwxuser($postObj){
	    global $_G;
		if($postObj['content']>100000 && $postObj['content']<200001){
		    wx_event::bindwxuser($postObj);
		}
        $scan_info=C::t('#micxp_wxdl#micxp_wxdl_scan')->fetch($postObj['content']);
		if(empty($scan_info)){
		    $postObj['content']=lang('plugin/micxp_wxdl','code_error');
		    wx_message::resText($postObj);
		}
 		$wxuser = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch($postObj['from']);
		if(!empty($wxuser) && !empty($wxuser['uid'])){
			C::t('#micxp_wxdl#micxp_wxdl_scan')->update($postObj['content'],array('status'=>1,'uid'=>$wxuser['uid']));
			
		}else{
			if(empty($wxuser)){
				$uid = micxp_wxdl_register_user($postObj);  
				if($uid <= 0) {
					if($uid == -1) {
						$backmsg =lang('message', 'profile_username_illegal');
					} elseif($uid == -2) {
						$backmsg =lang('message','profile_username_protect');
					} elseif($uid == -3) {
						$backmsg =lang('message','profile_username_duplicate');
					} elseif($uid == -4) {
						$backmsg =lang('message','profile_email_illegal');
					} elseif($uid == -5) {
						$backmsg =lang('message','profile_email_domain_illegal');
					} elseif($uid == -6) {
						$backmsg =lang('message','profile_email_duplicate');
					} else {
						$backmsg =lang('message','undefined_action');
					}
					$postObj['content']=$backmsg;
					wx_message::resText($postObj);
				}
				$setarr = array(
						'openid'=>$postObj['from'],
						'uid'=>$uid,
				        'type'=>'register',
				);
				C::t('#micxp_wxdl#micxp_wxdl_user')->insert($setarr);
				C::t('#micxp_wxdl#micxp_wxdl_scan')->update($postObj['content'],array('status'=>1,'uid'=>$uid));
			}

			
		}
		if(!empty($_G['cache']['plugin']['micxp_wxdl']['M_loginsuccess'])){
		    $postObj['content']=$_G['cache']['plugin']['micxp_wxdl']['M_loginsuccess'];
		}else{
		    $postObj['content']=lang('plugin/micxp_wxdl','login_success');
		}


		wx_message::resText($postObj);
		
	}
}