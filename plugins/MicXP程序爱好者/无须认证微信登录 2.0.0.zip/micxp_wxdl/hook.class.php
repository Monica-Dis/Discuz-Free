<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_wxdl {

	function global_login_extra(){
		$random = random(6);
		return '<div class="fastlg_fm y" style="margin-right: 10px; padding-right: 10px">
<p><a href="" onclick=showWindow("micxp_wxdl_qrcode","plugin.php?id=micxp_wxdl:login_qrcode&r='.$random.'","get",0); return false;><img src="source/plugin/micxp_wxdl/static/images/wx_login.png" class="vm"></a></p>
<p class="hm xg1" style="padding-top: 2px;">'.lang('plugin/micxp_wxdl','scan_login').'</p>
</div>';
	}
	
	function global_usernav_extra1(){
	    global $_G;
	    if(!$_G['uid']) return ;

	    if(empty($_G['cookie']['micxp_user_status'])){
	        
	        $wxinfo=C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($_G['uid']);
	        if(empty($wxinfo)){
	            dsetcookie('micxp_user_status','weixin',3600);
	            return '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind\', \'plugin.php?id=micxp_wxdl:bind\');"><img src="source/plugin/micxp_wxdl/static/images/wechat_bind.png" class="qq_bind" align="absmiddle"></a>&nbsp;';
	        }elseif($wxinfo['type']=='register'){
	            dsetcookie('micxp_user_status','pc',3600);
	            return '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind_old\', \'plugin.php?id=micxp_wxdl:bind\');">'.lang('plugin/micxp_wxdl','bind_old_userid').'</a>&nbsp;';
	        }else{
	            dsetcookie('micxp_user_status','hasbind',3600);
	            return ;
	        }
	    }else{
	        
	        if($_G['cookie']['micxp_user_status']=='hasbind'){
	            return ;
	        }
	        if($_G['cookie']['micxp_user_status']=='weixin'){
	            return '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind\', \'plugin.php?id=micxp_wxdl:bind\');"><img src="source/plugin/micxp_wxdl/static/images/wechat_bind.png" class="qq_bind" align="absmiddle"></a>&nbsp;';
	        }elseif($_G['cookie']['micxp_user_status']=='pc'){
	            return '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind_old\', \'plugin.php?id=micxp_wxdl:bind\');">'.lang('plugin/micxp_wxdl','bind_old_userid').'</a>&nbsp;';
	        }
	         
	    }
	    return ;
	}

}

class plugin_micxp_wxdl_member extends plugin_micxp_wxdl{
	function logging_input(){
		$random = random(6);
		return '<div class="rfm"><table>
<tbody><tr>
<th></th>
<td><a href="" onclick=showWindow("micxp_wxdl_qrcode","plugin.php?id=micxp_wxdl:login_qrcode&r='.$random.'","get",0); return false;><img src="source/plugin/micxp_wxdl/static/images/wx_login.png" class="vm"></a></td>
<td class="tipcol"></td>
</tr>
</tbody></table></div>';
	}
}

class plugin_micxp_wxdl_home extends plugin_micxp_wxdl{

    function spacecp_profile_setpassword_output(){
        global $_G,$conisregister,$wechatuser;
        if($_GET['op']=='password'){
            
            $wxinfo = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($_G['uid']);
            
            if($wxinfo['type']=='register' && $wxinfo['passwordset']==0){
                $_G['setting']['connect']['allow']=1;
                $conisregister=1;
                $wechatuser['isregister']=1;
            }
        }
    }

    function spacecp_profile_setpassword(){
        global $_G,$seccodecheck,$secqaacheck,$wechatuser;
        $wxinfo = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($_G['uid']);
        if($wxinfo['type']=='register' && $wxinfo['passwordset']==0){
            if(submitcheck('passwordsubmit', 0, $seccodecheck, $secqaacheck)){
                array_push($_G['setting']['plugins']['available'], 'mobile');
                $wechatuser['isregister']=1;
                $_G['micxp_passwordset']=1;
            }
        }
    }
    
    function spacecp_profile_message($p){
        global $_G;
        if($p['param']['0']=='profile_succeed' && $_G['micxp_passwordset']==1){ 
            DB::update('micxp_wxdl_user', array('passwordset'=>1), array('uid'=>$_G['uid']));
        } 
    }   
    
 }
//From: Dism_taobao-com
?>