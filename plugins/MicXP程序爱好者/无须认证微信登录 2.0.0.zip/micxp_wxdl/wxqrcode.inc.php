<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$qrcodesrc='';
if(is_file(DISCUZ_ROOT.'/data/sysdata/cache_micxp_wxdl_qrcode.php')){
	include_once DISCUZ_ROOT.'/data/sysdata/cache_micxp_wxdl_qrcode.php';
}
if(!submitcheck('editsubmit')) {
	
	if($qrcodesrc) {
		$qrcodelogo = $_G['setting']['attachurl'].'common/'.$qrcodesrc.'?'.random(6);
		$qrcodehtml = '<br /><label><input type="checkbox" class="checkbox" name="deletelqrcode" value="yes" /> '.$lang['delete'].'</label><br /><img src="'.$qrcodelogo.'" />';
	}else{
		$qrcodehtml=''; 
	}
	showformheader('plugins&operation=config&identifier=micxp_wxdl&pmod=wxqrcode','enctype');
	showtableheader();
	showsetting(lang('plugin/micxp_wxdl','uploadqrcode'), 'qrcodenew', $qrcodesrc, 'filetext', '', 0,$qrcodehtml);
	showtablefooter(); /*Dism��taobao��com*/
	showsubmit('editsubmit');
	showformfooter(); /*Dism_taobao_com*/
	
}else{
	if($_FILES['qrcodenew']) {
	    if($qrcodesrc){
	        @unlink($_G['setting']['attachdir'].'common/'.$qrcodesrc);
	    }
		$upload = new discuz_upload();
		if($upload->init($_FILES['qrcodenew'], 'common') && $upload->save()) {
			$qrcodesrc = $upload->attach['attachment'];
		}
		
	} else{
		$qrcodesrc = $_GET['qrcodenew'];
	}
	
	if($_GET['deletelqrcode'] && !empty($qrcodesrc)) {
		@unlink($_G['setting']['attachdir'].'common/'.$qrcodesrc);
		$qrcodesrc = '';
	}
 	$cachestr .= "\$qrcodesrc='".$qrcodesrc."';\n";
 	writetocache("micxp_wxdl_qrcode", $cachestr);
 	$url=ADMINSCRIPT."?frames=yes&action=plugins&operation=config&do=$pluginid&identifier=micxp_wxdl&pmod=wxqrcode";
 	cpmsg(lang('plugin/micxp_wxdl','uploadok'),$url,'succeed');
}

//d'.'i'.'sm.ta'.'o'.'bao.com
?>