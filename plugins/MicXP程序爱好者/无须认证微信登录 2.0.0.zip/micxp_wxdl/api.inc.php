<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(empty($_GET['module']) || !in_array($_GET['module'], array('api','misc'))) $_GET['module'] = 'api';
if($_GET['module']!='api'){
    micxp_wxdl_xss_check();
}

define(MCURMODULE, $_GET['module']);
$micxp_setting = $_G['cache']['plugin']['micxp_wxdl'];



define("MX_TOKEN", $micxp_setting['M_token'] ? $micxp_setting['M_token']:"micxp_wxdl");
$access_token = micxp_wxdlget_access_token($micxp_setting['M_appid'], $micxp_setting['M_appsecret']);
define('MX_ACCESS_TOKEN', $access_token);

define('MX_APPID', $micxp_setting['M_appid']);
define('MX_APPSECRET', $micxp_setting['M_appsecret']);

include_once libfile('weixin/'.$_GET['module'],'plugin/micxp_wxdl');

function micxp_wxdl_uuid($username){
    global $_G;
    $newname = md5($username.TIMESTAMP);
    $newname = substr($newname, -10);
    if(!empty($_G['cache']['plugin']['micxp_wxdl']['M_per'])){
        $m_per=daddslashes($_G['cache']['plugin']['micxp_wxdl']['M_per']);
    }else{
        $m_per='';
    }
    return $m_per.$newname;
}
function micxp_wxdl_register_user($data){
    global $_G;
    loaducenter();
    $uid =0;
    $password = md5(random(10));
    $email=random(10,true)."@qq.com";
    $data['nickname']= micxp_wxdl_uuid($data['from']);
    $uid=uc_user_register(addslashes($data['nickname']),$password, $email, '', '', $_G['clientip']);
    if($uid <= 0) {
        return $uid;
    }


    //$init_arr = array('credits' => explode(',',$_G['setting']['initcredits']), 'profile'=>'', 'emailstatus' => '');
    $init_arr = explode(',', $_G['setting']['initcredits']);
    C::t('common_member')->insert($uid, $data['nickname'], $password, $email, $_G['clientip'], $_G['setting']['newusergroupid'], $init_arr);
    require_once libfile('cache/userstats', 'function');
    build_cache_userstats();
    require libfile('function/member');

    setloginstatus(array(
        'uid' => $uid,
        'username' => $_G['username'],
        'password' => $password,
        'groupid' => $_G['setting']['newusergroupid'],
    ), 0);

    return $uid;

}


function micxp_wxdlget_access_token($appid,$appsecret,$news=0){
    $tokeninfo = C::t('#micxp_wxdl#micxp_wxdl_token')->fetch('micxp_wxdl');
    if($news==0 && !empty($tokeninfo['access_token']) && time()<($tokeninfo['expires_in']+$tokeninfo['create_time'])){
        return $tokeninfo['access_token'];
    }else{
        $url='https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
        $res = dfsockopen($url);
        $json= json_decode($res,true);
        $insertdata['create_time']=TIMESTAMP;
        $insertdata['access_token']=$json['access_token'];
        $insertdata['expires_in']=$json['expires_in'];
        $insertdata['type']='micxp_wxdl';
        
        if(!empty($insertdata['access_token'])){
            if(empty($tokeninfo)){
                C::t('#micxp_wxdl#micxp_wxdl_token')->insert($insertdata);
            }else{
                unset($insertdata['type']);
                C::t('#micxp_wxdl#micxp_wxdl_token')->update('micxp_wxdl',$insertdata);
            }
        }
        return $insertdata['access_token'];

    }
}

function micxp_post($url, $data) {
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}
function micxp_wxdl_xss_check() {

    static $check = array('"', '>', '<', '\'', '(', ')', 'CONTENT-TRANSFER-ENCODING');

    if(isset($_GET['formhash']) && $_GET['formhash'] !== formhash()) {
        system_error('request_tainting');
    }

    if($_SERVER['REQUEST_METHOD'] == 'GET' ) {
        $temp = $_SERVER['REQUEST_URI'];
    } elseif(empty ($_GET['formhash'])) {
        $temp = $_SERVER['REQUEST_URI'].file_get_contents('php://input');
    } else {
        $temp = '';
    }

    if(!empty($temp)) {
        $temp = strtoupper(urldecode(urldecode($temp)));
        foreach ($check as $str) {
            if(strpos($temp, $str) !== false) {
                system_error('request_tainting');
            }
        }
    }

    return true;
}