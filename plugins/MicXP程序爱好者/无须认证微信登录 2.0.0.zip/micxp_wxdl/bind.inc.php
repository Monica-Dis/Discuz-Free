<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
list($seccodecheck) = seccheck('login');

$micxp_setting = $_G['cache']['plugin']['micxp_wxdl'];
$expire = max(intval($micxp_setting['M_expire']),1)*60;

$wxinfo=C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($_G['uid']);

$myformash=FORMHASH;

if(IN_WECHAT && !submitcheck('checkoldsubmit')){
    $openid=daddslashes($_GET['openid']);
}

if($_G['uid'] && submitcheck('confirmsubmit')) {
	loaducenter();
	list($result) = uc_user_login($_G['uid'], $_GET['passwordconfirm'], 1, 0);
	if($result >= 0) {
		dsetcookie('qrauth', base64_encode(authcode($result, 'ENCODE', $_G['config']['security']['authkey'],$expire)));
		showmessage('', 'plugin.php?id=micxp_wxdl:bind');
	}
	showmessage('login_password_invalid');
}

if($_G['uid'] && !IN_WECHAT && submitcheck('checkoldsubmit',false, $seccodecheck)) {
    
    if(!empty($wxinfo)){
    
        if($wxinfo['type']=='register'){
            $oldusername = $_GET['oldusername'];
            if(empty($oldusername)){
                showmessage(lang('plugin/micxp_wxdl','nousername'));
            }
            if($_GET['oldpassword']!=addslashes($_GET['oldpassword'])){
                showmessage('profile_passwd_illegal');
            }
            include_once libfile('function/member');
            $result = userlogin($_GET['oldusername'],$_GET['oldpassword']);
            if($result['status'] > 0) {
                if($result['member']['uid']==$wxinfo['uid']){
                    C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','passwordset'=>1));
                }else{
                    $bindinfo =C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($result['member']['uid']);
                    if($bindinfo['type']=='bind'){
                        $uinfo = getuserbyuid($bindinfo['uid']);
                        showmessage(lang('plugin/micxp_wxdl','has_bind_user',array(1=>$uinfo['username']))); 
                    }
                    
                    C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','uid'=>$result['member']['uid'],'passwordset'=>1));
                    $uinfo = getuserbyuid($result['member']['uid']);
                    setloginstatus(array(
                        'uid' => $uinfo['uid'],
                        'username' => $uinfo['username'],
                        'password' => $uinfo['password'],
                        'groupid' => $uinfo['groupid'],
                    ), 0);
                    
                    
                }
                dsetcookie('micxp_user_status','');
                showmessage('', dreferer());
            }else{
                showmessage(lang('plugin/micxp_wxdl','user_error'));
            }
            
            
        
        }else{
            $uinfo = getuserbyuid($wxinfo['uid']);
            showmessage(lang('plugin/micxp_wxdl','has_bind_user',array(1=>$uinfo['username'])));
            
        }
    
    }else{

        if(!IN_WECHAT){
            showmessage(lang('plugin/micxp_wxdl','open_by_wx'));
        }
 
    }
}elseif($_G['uid'] && IN_WECHAT && submitcheck('checkoldsubmit',1, $seccodecheck)){
   
    
    if(!empty($wxinfo)){
        if($wxinfo['type']=='register'){
            $oldusername = $_GET['oldusername'];
            if(empty($oldusername)){
                showmessage(lang('plugin/micxp_wxdl','nousername'));
            }
            if($_GET['oldpassword']!=addslashes($_GET['oldpassword'])){
                showmessage('profile_passwd_illegal');
            }
            include_once libfile('function/member');
            $result = userlogin($_GET['oldusername'],$_GET['oldpassword']);
            if($result['status'] > 0) {
                if($result['member']['uid']==$wxinfo['uid']){
                    C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','passwordset'=>1));
                }else{
                    $bindinfo =C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_by_uid($result['member']['uid']);
                    if($bindinfo['type']=='bind'){
                        $uinfo = getuserbyuid($bindinfo['uid']);
                        showmessage(lang('plugin/micxp_wxdl','has_bind_user',array(1=>$uinfo['username'])));
                    }
    
                    C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','uid'=>$result['member']['uid'],'passwordset'=>1));
                    $uinfo = getuserbyuid($result['member']['uid']);
                    setloginstatus(array(
                        'uid' => $uinfo['uid'],
                        'username' => $uinfo['username'],
                        'password' => $uinfo['password'],
                        'groupid' => $uinfo['groupid'],
                    ), 0);
                    
    
                }
                
                showmessage(lang('plugin/micxp_wxdl','bind_success'), $_G['siteurl']);
            }else{
                showmessage(lang('plugin/micxp_wxdl','user_error'));
            }
    
    
    
        }else{
            $uinfo = getuserbyuid($wxinfo['uid']);
            showmessage(lang('plugin/micxp_wxdl','has_bind_user',array(1=>$uinfo['username'])));
    
        }
    
    
    }else{
        $openid=daddslashes($_GET['openid']);
        $wxinfo=C::t('#micxp_wxdl#micxp_wxdl_user')->fetch($openid);
        if($wxinfo && $wxinfo['uid']==0 && $wxinfo['type']=='bind'){
            $oldusername = $_GET['oldusername'];
            if(empty($oldusername)){
                showmessage(lang('plugin/micxp_wxdl','nousername'));
            }
            if($_GET['oldpassword']!=addslashes($_GET['oldpassword'])){
                showmessage('profile_passwd_illegal');
            }
            include_once libfile('function/member');
            $result = userlogin($_GET['oldusername'],$_GET['oldpassword']);
            if($result['status'] > 0) {
        
        
        
                C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','uid'=>$result['member']['uid'],'passwordset'=>1));
                $uinfo = getuserbyuid($result['member']['uid']);
                setloginstatus(array(
                    'uid' => $uinfo['uid'],
                    'username' => $uinfo['username'],
                    'password' => $uinfo['password'],
                    'groupid' => $uinfo['groupid'],
                ), 0);
        
        
                showmessage(lang('plugin/micxp_wxdl','bind_success'), $_G['siteurl']);
            }else{
                showmessage(lang('plugin/micxp_wxdl','user_error'));
            }
        }else{
            $bind_key=$_G['cache']['plugin']['micxp_wxdl']['M_bind'];
            showmessage(lang('plugin/micxp_wxdl','sen_code_by_wx',array('1'=>$bind_key)));
        }
        
        
        
    }
    
}elseif(!$_G['uid'] &&   IN_WECHAT && submitcheck('checkoldsubmit',1, $seccodecheck) && !empty($_GET['openid'])){
    
    $openid=daddslashes($_GET['openid']);
    $wxinfo=C::t('#micxp_wxdl#micxp_wxdl_user')->fetch($openid);
    
    
    if($wxinfo && $wxinfo['uid']==0 && $wxinfo['type']=='bind'){
        $oldusername = $_GET['oldusername'];
        if(empty($oldusername)){
            showmessage(lang('plugin/micxp_wxdl','nousername'));
        }
        if($_GET['oldpassword']!=addslashes($_GET['oldpassword'])){
            showmessage('profile_passwd_illegal');
        }
        include_once libfile('function/member');
        $result = userlogin($_GET['oldusername'],$_GET['oldpassword']);
        if($result['status'] > 0) {


    
            C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','uid'=>$result['member']['uid'],'passwordset'=>1));
            $uinfo = getuserbyuid($result['member']['uid']);
            setloginstatus(array(
                'uid' => $uinfo['uid'],
                'username' => $uinfo['username'],
                'password' => $uinfo['password'],
                'groupid' => $uinfo['groupid'],
            ), 0);

        
            showmessage(lang('plugin/micxp_wxdl','bind_success'), $_G['siteurl']);
        }else{
            showmessage(lang('plugin/micxp_wxdl','user_error'));
        }
    }elseif($wxinfo && !empty($wxinfo['uid']) && $wxinfo['type']=='register'){
        
        $oldusername = $_GET['oldusername'];
        if(empty($oldusername)){
            showmessage(lang('plugin/micxp_wxdl','nousername'));
        }
        if($_GET['oldpassword']!=addslashes($_GET['oldpassword'])){
            showmessage('profile_passwd_illegal');
        }
        include_once libfile('function/member');
        $result = userlogin($_GET['oldusername'],$_GET['oldpassword']);
        if($result['status'] > 0) {
        
        
        
            C::t('#micxp_wxdl#micxp_wxdl_user')->update($wxinfo['openid'],array('type'=>'bind','uid'=>$result['member']['uid'],'passwordset'=>1));
            $uinfo = getuserbyuid($result['member']['uid']);
            setloginstatus(array(
                'uid' => $uinfo['uid'],
                'username' => $uinfo['username'],
                'password' => $uinfo['password'],
                'groupid' => $uinfo['groupid'],
            ), 0);
        
        
            showmessage(lang('plugin/micxp_wxdl','bind_success'), $_G['siteurl']);
        }else{
            showmessage(lang('plugin/micxp_wxdl','user_error'));
        }
        
        
        
        
    }else{
        $bind_key=$_G['cache']['plugin']['micxp_wxdl']['M_bind'];
        showmessage(lang('plugin/micxp_wxdl','sen_code_by_wx',array('1'=>$bind_key)));
    }
    
    
    
}





if($_G['cookie']['qrauth']) {
    $qrauth = authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $_G['config']['security']['authkey']);
}

$micxp_random = random(8);
$micxp_key= authcode($micxp_random,'ENCODE',$micxp_setting['M_key']);

include template('micxp_wxdl:bind');


