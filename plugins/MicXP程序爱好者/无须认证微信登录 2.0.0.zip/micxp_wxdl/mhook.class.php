<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_wxdl {

}
class mobileplugin_micxp_wxdl_member extends mobileplugin_micxp_wxdl{
	function logging_bottom_mobile(){
	    //if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	        return '<br><div class="btn_login" ><a class="dialog pn pnc" href="plugin.php?id=micxp_wxdl:login_qrcode">'.lang('plugin/micxp_wxdl','wxlogin').'</a></div>';
	   // }
		
	}
}



?>