<?php 
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$micxp_setting = $_G['cache']['plugin']['micxp_wxdl'];
if(submitcheck('formhash',true)){
	$micxp_key = $_GET['micxp_key'];
	if(empty($micxp_key)){
		myshowmessage(lang('plugin/micxp_wxdl','parmerr').'1');
	}
	$randcode= authcode($micxp_key,'DECODE',$micxp_setting['M_key']);
	if(empty($randcode)){
		myshowmessage(lang('plugin/micxp_wxdl','parmerr').'2');
	}

	$scaninfo = C::t('#micxp_wxdl#micxp_wxdl_scan')->fetch_by_random(daddslashes($randcode));
	
	if(empty($scaninfo)){
		myshowmessage(lang('plugin/micxp_wxdl','parmerr').'3');
	}
	
	$secrandcode= authcode($scaninfo['micxp_key'],'DECODE',$micxp_setting['M_key']);
	
	if($secrandcode!=$randcode){
		myshowmessage(lang('plugin/micxp_wxdl','parmerr').'4');
	}
	
	if(TIMESTAMP>$scaninfo['expire']){
		C::t('#micxp_wxdl#micxp_wxdl_scan')->delete($scaninfo['scene_id']);
		myshowmessage('expire');
		
	}
	
	if($scaninfo['status']==1 && !empty($scaninfo['uid'])){
		$uinfo = getuserbyuid($scaninfo['uid']);
		
		require libfile('function/member');
		setloginstatus(array(
		'uid' => $uinfo['uid'],
		'username' => $uinfo['username'],
		'password' => $uinfo['password'],
		'groupid' => $uinfo['groupid'],
		), 0);
		
		C::t('#micxp_wxdl#micxp_wxdl_scan')->delete($scaninfo['scene_id']);
		
		myshowmessage('ok');
	}
	
	
}


myshowmessage("");
function myshowmessage($msg){
    if(defined('IN_MOBILE')){
        echo $msg;
        exit;
    }else{
        helper_output::xml($msg);
        exit;
    }
	
}
//d'.'is'.'m.ta'.'obao.com
?>