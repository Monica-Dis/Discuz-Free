<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
	
}
$Mlang = $scriptlang['micxp_wxdl'];
loadcache('plugin');
if($_GET['op'] == 'delete' && submitcheck('formhash',1)) {
	$uid= intval($_GET['uid']);
	if(!empty($uid)){
		C::t('#micxp_wxdl#micxp_wxdl_user')->delete_by_uid($uid);
	}
	ajaxshowheader();
	echo $Mlang['deleted'];
	ajaxshowfooter();

}

$ppp = 15;
$page = max(1, intval($_GET['page']));
$srchadd = $searchtext = $extra = $srchuid = '';

$srchadd =" 1 ";
if(!empty($_GET['srchusername'])){
	$srchusername = dintval($_GET['srchusername']);
	$srchadd.="AND ( uid = $srchusername )";
	$sextra=$extra="&srchusername=".$srchusername;
}


showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_wxdl&pmod=member','memberform');
showsubmit('membersubmit', $Mlang['search'], 'UID: <input name="srchusername" value="'.htmlspecialchars($_GET['srchusername']).'" class="txt" />&nbsp;&nbsp;',$Mlang['delete_tips']);
showformfooter(); /*Dism_taobao_com*/



echo '<tr class="header"><th>UID</th><th>OPENID</th><th></th></tr>';

$count = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_all_by_sql($srchadd, '', 0,  0, 1);
$users = C::t('#micxp_wxdl#micxp_wxdl_user')->fetch_all_by_sql($srchadd, 'ORDER BY uid DESC', ($page - 1) * $ppp, $ppp );


$i=0;
foreach($users as $value) {
	$i++;
	if(empty($value['uid'])){
	    $value['uid']=$Mlang['usernobind'];
	}
	echo '<tr><td><a href="home.php?mod=space&uid='.$value[uid].'" target="_blank">UID:'.$value['uid'].'</a></td>'.
	   	    '<td>'.$value['openid'].'</td>'.
			'<td><a id="p'.$i.'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=micxp_wxdl&pmod=member&uid='.$value['uid'].'&op=delete&formhash='.FORMHASH.'">['.$Mlang['delete'].']</a></td></tr>';
}

showtablefooter(); /*Dism��taobao��com*/

echo multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=micxp_wxdl&pmod=member$sextra");


?>