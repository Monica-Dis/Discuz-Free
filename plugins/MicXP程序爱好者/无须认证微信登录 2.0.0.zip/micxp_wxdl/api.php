<?php
if(!empty($_SERVER['QUERY_STRING'])) {
    define('SUB_DIR', '/source/plugin/micxp_wxdl/');
	$dir = '../../../';
	chdir($dir);
	define('DISABLEXSSCHECK', true);
	$_GET['id']='micxp_wxdl:api';
	require 'plugin.php';
}
