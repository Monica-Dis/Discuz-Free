<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_nofollow {

	function discuzcode($p){

		global $_G;
		if(($_G['cache']['plugin']['micxp_nofollow']['M_isrobot'] && IS_ROBOT) || !$_G['cache']['plugin']['micxp_nofollow']['M_isrobot'] ){
			
			$message =$p['param']['0'];
			$msglower = strtolower($message);
			if($p['caller']=='discuzcode'){
				$message=$_G['discuzcodemessage'];
				
				if(!$p['param']['2'] && $p['param']['5']) {
					if(strpos($msglower, '[/url]') !== FALSE) {	
						
					    $message=preg_replace_callback("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/", 'micxp_nofollow_parseurl', $message);
					}
				}else{
					include_once libfile('function/editor');
					$message= recursion('a', $message, 'atag');
					
					$message=preg_replace_callback("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/", 'micxp_nofollow_parseurl', $message);
				}
				$_G['discuzcodemessage']=$message;
				
			}
			
		}

	}


}

class plugin_micxp_nofollow_forum extends plugin_micxp_nofollow {
	function forumdisplay_top_output() {
		global $_G;
		if(! $_G['cache']['plugin']['micxp_nofollow']['M_threadlist']) return '';
		if($_G['cache']['plugin']['micxp_nofollow']['M_list_forums']){
			$fids = (array)unserialize($_G['cache']['plugin']['micxp_nofollow']['M_forums']);
			if (!in_array($_G['fid'], $fids)){
				return '';
			}
		}
		
		
		$return = '<link rel="stylesheet" type="text/css" href="source/plugin/micxp_nofollow/static/css/nofollow.css" media="all" />';
		return $return;
	}
	
	function forumdisplay_thread_subject_output() {
		global $_G;
		$return = array();
		if(! $_G['cache']['plugin']['micxp_nofollow']['M_threadlist']) return $return;
		if($_G['cache']['plugin']['micxp_nofollow']['M_list_forums']){
			$fids = (array)unserialize($_G['cache']['plugin']['micxp_nofollow']['M_forums']);
			if (!in_array($_G['fid'], $fids)){
				return $return;
			}
				
		}
		
		foreach($_G['forum_threadlist'] as $key=>$thread){
			$postinfo = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
			if($postinfo['status'] & 1){
				$_G['forum_threadlist'][$key]['highlight'].=' rel="nofollow" ';
				$return[]='<a tool-map="top" title="'.lang('plugin/micxp_nofollow','bund').'"  class="micxp_nofollow_icons micxp_nofollow_icons_spider" href="javascript:;"></a>';
			}else{
				$return[]='';
			}
			
		}
		unset($postinfo);
		return $return;
	}
		
}




function micxp_nofollow_atag($aoptions, $text) {
	$href = getoptionvalue('href', $aoptions);

	
	
	$tag = 'url';
	if(!preg_match("/^[a-z0-9]+:/i", $href)) {
		$href = absoluteurl($href);
	}
	$url = $href;
	$url = micxp_add_nofollow($url);
	
	return '<'.$tag.' href="'.$url.'"  target="_blank">'.trim(recursion('a', $text, 'micxp_nofollow_atag')).'</'.$tag.'>';
}


function micxp_nofollow_parseurl($omatches) {
    $url=$omatches['1'];
    $text=$omatches['5'];
    $scheme=$omatches['2'];
	global $_G;
	
	if(!$url && preg_match("/((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.)[^\[\"']+/i", trim($text), $matches)) {
	    
	    $url = $matches[0];
	    
		$length = 65;
		if(strlen($url) > $length) {
			$text = substr($url, 0, intval($length * 0.5)).' ... '.substr($url, - intval($length * 0.3));
		}
		$url = micxp_add_nofollow($url);
		return '<a href="'.(substr(strtolower($url), 0, 4) == 'www.' ? 'http://'.$url : $url).'" target="_blank">'.$text.'</a>';
	} else {
	    
		$url = substr($url, 1);
		if(substr(strtolower($url), 0, 4) == 'www.') {
			$url = 'http://'.$url;
		}
		$url = !$scheme ? $_G['siteurl'].$url : $url;
		
		$url = micxp_add_nofollow($url);
		return '<a href="'.$url.'" target="_blank">'.$text.'</a>';
	}
}



function micxp_add_nofollow($url = '')
{
	global $_G;
	
	$dm=array();
	$domains = $_G['cache']['plugin']['micxp_nofollow']['M_domains'];
	$dm = $strarr = explode ("\n", str_replace ("\r", "", $domains));
	array_push($dm, $_SERVER['HTTP_HOST']);
	$dm=array_filter($dm);

	$temp = array();

	if( ! empty($url))
	{
	    
		$temp = parse_url($url);
		
		if($temp['host']){
		    if(!in_array($temp['host'], $dm)){
		        $url .= '" rel="nofollow';
		    }
		    
		}else{
		    if(!in_array($url, $dm)){
		        $url .= '" rel="nofollow';
		    }
		    
		}
		
		
	}

	unset($temp);
	return $url;
}



?>