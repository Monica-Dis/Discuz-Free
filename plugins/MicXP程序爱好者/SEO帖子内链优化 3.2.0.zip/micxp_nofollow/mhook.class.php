<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_nofollow {
    function discuzcode($p){
        
        global $_G;
        if(($_G['cache']['plugin']['micxp_nofollow']['M_isrobot'] && IS_ROBOT) || !$_G['cache']['plugin']['micxp_nofollow']['M_isrobot'] ){
            
            $message =$p['param']['0'];
            $msglower = strtolower($message);
            if($p['caller']=='discuzcode'){
                $message=$_G['discuzcodemessage'];
                
                if(!$p['param']['2'] && $p['param']['5']) {
                    if(strpos($msglower, '[/url]') !== FALSE) {
                        
                        $message=preg_replace_callback("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/", 'm_micxp_nofollow_parseurl', $message);
                    }
                }else{
                    include_once libfile('function/editor');
                    $message= recursion('a', $message, 'atag');
                    
                    $message=preg_replace_callback("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/", 'm_micxp_nofollow_parseurl', $message);
                }
                $_G['discuzcodemessage']=$message;
                
            }
            
        }
        
    }
}
function m_micxp_nofollow_atag($aoptions, $text) {
    $href = getoptionvalue('href', $aoptions);
    
    
    
    $tag = 'url';
    if(!preg_match("/^[a-z0-9]+:/i", $href)) {
        $href = absoluteurl($href);
    }
    $url = $href;
    $url = m_micxp_add_nofollow($url);
    
    return '<'.$tag.' href="'.$url.'"  target="_blank">'.trim(recursion('a', $text, 'm_micxp_nofollow_atag')).'</'.$tag.'>';
}
function m_micxp_nofollow_parseurl($omatches) {
    $url=$omatches['1'];
    $text=$omatches['5'];
    $scheme=$omatches['2'];
    global $_G;
    
    if(!$url && preg_match("/((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.)[^\[\"']+/i", trim($text), $matches)) {
        
        $url = $matches[0];
        
        $length = 65;
        if(strlen($url) > $length) {
            $text = substr($url, 0, intval($length * 0.5)).' ... '.substr($url, - intval($length * 0.3));
        }
        $url = m_micxp_add_nofollow($url);
        return '<a href="'.(substr(strtolower($url), 0, 4) == 'www.' ? 'http://'.$url : $url).'" target="_blank">'.$text.'</a>';
    } else {
        
        $url = substr($url, 1);
        if(substr(strtolower($url), 0, 4) == 'www.') {
            $url = 'http://'.$url;
        }
        $url = !$scheme ? $_G['siteurl'].$url : $url;
        
        $url = m_micxp_add_nofollow($url);
        return '<a href="'.$url.'" target="_blank">'.$text.'</a>';
    }
}



function m_micxp_add_nofollow($url = '')
{
    global $_G;
    
    $dm=array();
    $domains = $_G['cache']['plugin']['micxp_nofollow']['M_domains'];
    $dm = $strarr = explode ("\n", str_replace ("\r", "", $domains));
    array_push($dm, $_SERVER['HTTP_HOST']);
    $dm=array_filter($dm);
    
    $temp = array();
    
    if( ! empty($url))
    {
        
        $temp = parse_url($url);
        
        if($temp['host']){
            if(!in_array($temp['host'], $dm)){
                $url .= '" rel="nofollow';
            }
            
        }else{
            if(!in_array($url, $dm)){
                $url .= '" rel="nofollow';
            }
            
        }
        
        
    }
    
    unset($temp);
    return $url;
}

//From: dis'.'m.tao'.'bao.com
?>