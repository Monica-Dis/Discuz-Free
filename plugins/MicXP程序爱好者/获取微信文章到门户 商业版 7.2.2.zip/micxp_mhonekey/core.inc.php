<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require './source/function/function_editor.php';
$url = getgpc('url');
$source = dfsockopen($url);
$pattern=$_G['cache']['plugin']['micxp_mhonekey']['M_regex_title'];
preg_match($pattern, $source,$title);
$title=trim($title[1]);
$title=strip_tags($title);
$title = daddslashes($title);


if(empty($title)){
    echo json_encode(null);
    exit;
}

$pattern=$_G['cache']['plugin']['micxp_mhonekey']['M_regex_content'];
preg_match($pattern, $source,$content);
$content=$content[1];



if(empty($content)){
    echo json_encode(null);
    exit;
}

$_G['returnaids']=array();
$content = downLoadPic($content);


if($_G['cache']['plugin']['micxp_mhonekey']['M_clearstyle']){
    $content=strip_tags($content,'<br>,<img>');
}

$data['subject']=$title;
$data['message']=$content;
$data['imgaids']=implode(',', $_G['returnaids']);
echo json_encode($data);


function downLoadPic($content){
	global $_G;
	$pimg="/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/";
	preg_match_all($pimg,$content,$imgurl);
	
	if(!empty($imgurl[0]) && is_array($imgurl[0])){
		$upload = new discuz_upload();
		$image = new image();
		foreach ($imgurl[0] as  $ik=>$iv){
			if(preg_match("/v\.qq\.com.*?vid=(.*?)&(.*)/", $iv,$arr)){
				if(!empty($arr[1])){
					$newurl = '[flash=media]https://imgcache.qq.com/tencentvideo_v1/playerv3/TPout.swf?vid='.$arr[1].'&auto=1[/flash]';
				}else{
					$newurl = '';
				}
			
			}else{
				$pos = strpos($imgurl[1][$ik], '?');
				if($pos){
					$nimgurl = substr($imgurl[1][$ik], 0,$pos);
				}else{
					$nimgurl=$imgurl[1][$ik];
				}
				
				//=====
				$im ="";
				$minfo = $attach= array();
				$im = dfsockopen($nimgurl);
				if(empty($im)){
					$content= str_replace($iv, '', $content);
					continue;
				}
				$minfo =getimagesize("data://text/plain;base64," . base64_encode($im));
				if($minfo['mime']=='image/jpeg'){
					$attach['ext']='jpg';
				}elseif($minfo['mime']=='image/gif'){
					$attach['ext']='gif';
				}elseif($minfo['mime']=='image/png'){
					$attach['ext']='png';
				}elseif($minfo['mime']=='image/bmp'){
					$attach['ext']='bmp';
				}
				
				if(empty($attach['ext'])){
					$content= str_replace($iv, '', $content);
					continue;
				}
				
				$attach['name'] =  md5($iv).'.'.$attach['ext'];
				$attach['thumb'] = '';
				$attach['isimage'] = $upload -> is_image_ext($attach['ext']);
				$attach['extension'] = $upload -> get_target_extension($attach['ext']);
				
				$attach['attachdir'] = $upload -> get_target_dir('portal');
				$attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('portal').'.'.$attach['extension'];
				$attach['target'] = getglobal('setting/attachdir').'./portal/'.$attach['attachment'];
				
				if (!@$fp = fopen($attach['target'], 'wb'))
				{
					$content= str_replace($iv, '', $content);
					continue;
				} else{
					flock($fp, 2);
					fwrite($fp, $im);
					fclose($fp);
				}
				
				if(!$upload->get_image_info($attach['target'])) {
					@unlink($attach['target']);
					$content= str_replace($iv, '', $content);
					continue;
				}
				
				$attach['size'] = filesize($attach['target']);
				$upload->attach = $attach;
				if($_G['cache']['plugin']['micxp_wxonekey']['M_water']){
					$image->Watermark($attach['target']);
				}
				$setarr = array(
						'uid' => $_G['uid'],
						'filename' => $attach['name'],
						'attachment' => $attach['attachment'],
						'filesize' => $attach['size'],
						'isimage' => $attach['isimage'],
						'thumb' => $attach['thumb'],
						'remote' => $attach['remote'],
						'filetype' => $attach['extension'],
						'dateline' => $_G['timestamp'],
						'aid' => 0
				);
				$setarr['attachid'] = C::t('portal_attachment')->insert($setarr, true);
				if($setarr['attachid']){
					$_G['returnaids'][]=$setarr['attachid'];
				}
				if($attach['isimage'] && empty($_G['setting']['portalarticleimgthumbclosed'])) {
					require_once libfile('class/image');
					$image = new image();
					$thumbimgwidth = $_G['setting']['portalarticleimgthumbwidth'] ? $_G['setting']['portalarticleimgthumbwidth'] : 300;
					$thumbimgheight = $_G['setting']['portalarticleimgthumbheight'] ? $_G['setting']['portalarticleimgthumbheight'] : 300;
					$attach['thumb'] = $image->Thumb($attach['target'], '', $thumbimgwidth, $thumbimgheight, 2);
					$image->Watermark($attach['target'], '', 'portal');
				}
				
				require_once DISCUZ_ROOT.'./source/function/function_home.php';
				$bigimg = pic_get($attach['attachment'], 'portal', 0, $attach['remote']);
				
				
				
				//=========
				
				if($_G['cache']['plugin']['micxp_mhonekey']['M_clearstyle']){
				    $newurl = '<img src='.$bigimg.' /><br>';
				}else{
				    $newurl = '<img src='.$bigimg.' />';
				}
				
				
				
			}
			$content= str_replace($iv, $newurl, $content);
		}
	}
	return $content;
}