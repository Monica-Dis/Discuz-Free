<?php

/**
 *      mhonekey 1.0.0 by http://t.cn/Aiux14ti
 *      2015 5 17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_micxp_mhonekey {
	
}
class plugin_micxp_mhonekey_portal extends plugin_micxp_mhonekey {
       function  portalcp_extend() {
           global $_G;
           $onekeybtn ="<link rel=\"stylesheet\" href=\"source/plugin/micxp_mhonekey/static/css/onekey_btn.css\" type=\"text/css\" />";
           $onekeybtn .= "<a id=\"micxp_mhonekey_btn\" title=\"".lang('plugin/micxp_mhonekey','getweixin')."\" onClick=\"showWindow('mhonekey', 'plugin.php?id=micxp_mhonekey:window', 'get', 0)\" href='javascript:void(0);' >".lang('plugin/micxp_mhonekey','weixin')."</a><div id='micxp_mhonekey_editortoolbar'></div>";
           if(!empty($_G['setting']['pluginhooks']['portalcp_extend'])){
               $_G['setting']['pluginhooks']['portalcp_extend']=$_G['setting']['pluginhooks']['portalcp_extend'].$onekeybtn;
           }else{
               return $onekeybtn;
           }
       }


}
//From: dis'.'m.tao'.'bao.com
?>