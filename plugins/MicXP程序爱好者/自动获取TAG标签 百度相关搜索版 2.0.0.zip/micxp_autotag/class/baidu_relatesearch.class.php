<?php
class baidu {
	public static function build_request_uri($words){
		return '/s?wd='.$words;
	}

	public static function get_relate_search($words){
		
		$content = self::get_content($words);
		$doc = new DOMDocument();
		@$doc->loadHtml($content);
		$xpath = new DOMXPath($doc);
		
		$nodes = @$xpath->query("//*[@id='rs']/table/tr/th/a");
		
		$key=array();
	
		foreach ($nodes as $entry) {
			$key[]=$entry->nodeValue;
		}
		if(count($key)>5){
			$key=array_slice($key,0,5);
		}
		return $key;

	}



	public static function get_content($words){

		static $loaded_contents = array();

		if(!isset($loaded_contents[$words])){
			$content=self::sendRequest("https://www.baidu.com".self::build_request_uri($words));
			$loaded_contents[$words] = $content;
		}

		return $loaded_contents[$words];

	}

	function check_veriy($content){

		if(strpos($content,"https://verify.baidu.com/")!==FALSE){

		}
	}
	
	
	public static function sendRequest($url, $postData = false)
	{
		$postJson = false;
		$ch = curl_init($url);
		curl_setopt_array($ch, array(
				CURLOPT_USERAGENT => sprintf('Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0'),
				CURLOPT_REFERER=>"https://www.baidu.com",
				CURLOPT_RETURNTRANSFER  => 1,
				CURLOPT_CONNECTTIMEOUT  => 30,
				CURLOPT_FOLLOWLOCATION  => 1,
				CURLOPT_MAXREDIRS       => 2,
				CURLOPT_SSL_VERIFYPEER  => 0,
		));
	
		if (false != $postData) {
			if (false != $postJson) {
				curl_setopt($ch, CURLOPT_HTTPHEADER,
						array('Content-type: application/json'));
				$data = json_encode($postData);
			} else {
				$data = http_build_query($postData);
			}
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}
	
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
	
		if($httpCode == 200) {
			return $response;
		}else { 
			return '';
		}
	}

}
