<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_micxp_autotag {

}

class mobileplugin_micxp_autotag_forum extends mobileplugin_micxp_autotag{
    
    function viewthread_micxp_output($p){
        
        global $_G,$postlist;
        
        $setting = $_G['cache']['plugin']['micxp_autotag'];
        $fids = (array)unserialize($setting['M_forum']);
        if (in_array($_G['fid'], $fids)){
            foreach ($postlist as $key=>$val){
                if($val['first'] && empty($val['tags'])){
                    $postlist[$key]['tags']=$this->_get_autotag($val['tid'],$val['pid'],$val['subject'],cutstr($val['message'], 500, ''));
                }
            }
        }
    }
    
    
    function _get_autotag($tid,$pid,$subject,$message){
        $tid= dintval($tid);
        $pid= dintval($pid);
        $posttag_array =array();
        if(!empty($tid) && !empty($pid)){
            include_once 'source/plugin/micxp_autotag/class/baidu_relatesearch.class.php';
            
            $subjectenc = rawurlencode(strip_tags($subject));
            $messageenc = rawurlencode(strip_tags(preg_replace("/\[.+?\]/U", '', $message)));
            $backdata =  baidu::get_relate_search($subjectenc);
            
            if(!empty($backdata)){
                foreach ($backdata as $bkey=>$bstr){
                    $backdata[$bkey]=diconv($bstr,'UTF-8' ,CHARSET);
                }
            }
            
            
            if($backdata) {
                $kws = $backdata;
                $return = $posttags='';
                if($kws) {
                    foreach($kws as $kw) {
                        $kw = dhtmlspecialchars($kw);
                        $return .= $kw.',';
                    }
                    $return = dhtmlspecialchars($return);
                }
                $return = substr($return, 0, strlen($return)-1);
                
                $class_tag = new tag();
                $posttags = $class_tag->add_tag($return, $tid, 'tid');
                if($kws) {
                    loadcache('censor');
                    C::t('forum_post')->update('tid:'.$tid, $pid, array(
                        'tags' => $posttags,
                    ));
                }
                
                if(!empty($posttags)){
                    $tagarray_all = explode("\t", $posttags);
                    
                    if($tagarray_all) {
                        foreach($tagarray_all as $var) {
                            if($var) {
                                $tag = explode(',', $var);
                                $posttag_array[] = $tag;
                            }
                        }
                    }
                }
                
            }
        }
        
        return $posttag_array;
        
        
    }
    
}
//From: dis'.'m.tao'.'bao.com
?>