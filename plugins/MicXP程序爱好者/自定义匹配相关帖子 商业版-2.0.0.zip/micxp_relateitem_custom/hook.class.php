<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_micxp_relateitem_custom {

}
class plugin_micxp_relateitem_custom_forum extends plugin_micxp_relateitem_custom{
	
	function viewthread_micxp_output($p){
		global $_G,$postlist;
		
		$setting = $_G['cache']['plugin']['micxp_relateitem_custom'];
		
		$fids = (array)unserialize($setting['M_forums']);
		if (in_array($_G['fid'], $fids)){
			$num =  $_G['setting']['relatenum'];
			foreach ($postlist as $key=>$val){
				if($val['first']){
					
					$tags = C::t('#micxp_relateitem_custom#micxp_relateitem_custom_threadtags')->fetch($val['tid']);
					if(!empty($tags['tags'])){
						$postlist[$key]['relateitem']= $this->_getrelateitem($tags,$num,$setting['M_model']);
					}
					
				}
			}
		}
	}
	
	function _getrelateitem($tags,$num,$model){
		$tagidarray = $relatearray =  array();
		$tagidstr = $tags['tags'];
		$tid = $tags['tid'];
		$tagidarray = explode(',', $tagidstr);
		
		$tagidarray = dintval($tagidarray,true);

		if(!$tagidarray) {
			return '';
		}
		
		$query = C::t('#micxp_relateitem_custom#micxp_relateitem_custom_tagitem')->select($tagidarray, $tid, 'tid', 'itemid', 'DESC', $num, 0, '<>',0,$model);
		foreach($query as $result) {
			if($result['itemid']) {
				$relatearray[] = $result['itemid'];
			}
		}
		
		if(!empty($relatearray)) {
			rsort($relatearray);
			foreach(C::t('forum_thread')->fetch_all_by_tid($relatearray) as $result) {
				if($result['displayorder'] >= 0) {
					$relateitem[] = $result;
				}
			}
		}
		return $relateitem;

		
	}
	

	
}



//From: Dism��taobao��com
?>