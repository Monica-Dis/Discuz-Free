<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
set_time_limit(0);

$alltagnames = C::t('#micxp_relateitem_custom#micxp_relateitem_custom_tag')->range();
$cacheArray .= "\$taglist=".arrayeval($alltagnames).";\n";
writetocache("micxp_relateitem_custom_tag", $cacheArray);


$op = daddslashes($_GET['op']);
$op = in_array($op, array('search','sids')) ? $op : 'search';
$Plang = $scriptlang['micxp_relateitem_custom'];
define('MICXP_STATIC','source/plugin/micxp_relateitem_custom/static/');

$css = '<style>
		#mk_result {width:100%; margin-top:10px; border: 1px solid #ccc; margin: 0 auto; font-size:16px; text-align:center; display:none; }
		#mk_article, #mk_category, #mk_index{ line-height:30px;}
		#progress_bar{ width:400px; height:25px; border:1px solid #09f; margin: 10px auto 0; display:none;}
		.mk_msg{ width:100%; line-height:120px;}
		</style>';
$result = '<tr><td colspan="15"><div id="mk_result">
			<div id="progress_bar"></div>
			<div id="mk_website" mktitle="'.$Plang['search_posts'].'"></div>
			<div id="mk_index" mktitle="'.$Plang['search_posts'].'"></div>
			</div></td></tr>';


if($op=='search'){
	showformheader('');
	showtableheader('');

	
	
	echo '<tr><td colspan="15"><div class="fixsel"><a href="javascript:void(0);" class="btn_big" id="submit_march">'.$Plang['start_march'].'</a></div></td></tr>', $result;
	$adminscript = ADMINSCRIPT;
	echo <<<EOT
	<script type="text/JavaScript">
		var stoptips ='$Plang[stoptips]';
		var js_statr_march='$Plang[start_march]';
		var js_complete = '$Plang[complete]';
		var js_match = '$Plang[match]';
		var js_match_error='$Plang[match_error]';
		var js_match_ok='$Plang[match_ok]';
		var js_unit='$Plang[unit]';
		var js_hasok='$Plang[hasok]';
		var js_needmatch='$Plang[needmatch]';
		var js_posts = '$Plang[posts]';
		var js_cgpp='$Plang[cgpp]';
		var js_nowmatch='$Plang[nowmatch]';
		
		var form = document.forms['cpform'];
		form.onsubmit = function(){return false;};
		_attachEvent($('submit_march'), 'click', function(){
			$('mk_result').style.display = 'block';
			$('mk_index').style.display = 'none';
			this.innerHTML = '$Plang[restart_march]';
			search_keyword_posts();
			return false;
		});
		function search_keyword_posts_ok(){
			var dom = $('mk_index');
			dom.style.display = 'block';
			dom.style.color = 'green';
			dom.innerHTML = '<div class="mk_msg">$Plang[complete]</div>';
					
		}			
					
		function search_keyword_posts(){
				var dom = $('mk_website');
				dom.innerHTML = '<div class="mk_msg">$Plang[search_waitcheckposts]</div>';
				dom.style.display = 'block';
				
				var x = new Ajax();
				x.get('$adminscript?action=plugins&operation=config&do=$pluginid&identifier=micxp_relateitem_custom&pmod=match&op=sids&inajax=1&frame=no', function (s) {
					if(s && s.indexOf('<') < 0){
						new search_keyword_batch('plugin.php?id=micxp_relateitem_custom:searchkw&sid=', s.split(','), search_keyword_posts_ok, dom);
					} else {
						dom.innerHTML = '$Plang[search_nofindposts]';
					}
				});	
		}
					
	</script>
	
EOT;
	echo '<script type="text/javascript" src="'.MICXP_STATIC.'js/search.js?1"></script>',$css;
	
	showtablefooter();
	showformfooter();/*DISM-TAOBAO-COM*/
	
}elseif($op=='sids'){
	loadcache('plugin');
	$fids = (array)unserialize($_G['cache']['plugin']['micxp_relateitem_custom']['M_forums']);
	//debug($fis);
	$fids = dintval($fids, true);
	$fids = dimplode($fids);
	$sql ="SELECT tid FROM ".DB::table('forum_thread')." WHERE fid IN(".$fids.") ";
	$query = DB::query($sql);
	$tids = array();
	while ($row = DB::fetch($query)){
		$tids[$row['tid']] =$row['tid'];
	}
	$data =$tids;
	helper_output::xml($data ? implode(',', array_keys($data)) : '');
}



?>