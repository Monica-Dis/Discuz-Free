<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$Plang = $scriptlang['micxp_relateitem_custom'];

if(submitcheck('deletesubmit')){
	$ids = dintval($_GET['ids'],true);
	if(empty($ids)){
		cpmsg($Plang['noselect'],'action=plugins&operation=config&identifier=micxp_relateitem_custom&pmod=kwcp','error');
	}
	
	C::t('#micxp_relateitem_custom#micxp_relateitem_custom_tag')->delete_byids($ids);
	cpmsg($Plang['deleteok'],'action=plugins&operation=config&identifier=micxp_relateitem_custom&pmod=kwcp','succeed');
		
}

$ppp = 15;
$page = max(1, intval($_GET['page']));

showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_relateitem_custom&pmod=kwcp', 'kwsubmit');
showsubmit('kwsubmit', $Plang['search'], $Plang['keywords'].': <input name="searchname" value="'.dhtmlspecialchars($_GET['searchname']).'" class="txt" />');
showformfooter();/*DISM-TAOBAO-COM*/


$srchadd = $extra = '';
$searchname = isset($_GET['searchname']) ?daddslashes(strip_tags($_GET['searchname'])):'';
if(!empty($searchname)){
	$extra="&searchname='$searchname'";
}

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=micxp_relateitem_custom&pmod=kwcp');

echo '<tr class="header"><th></th><th>'.$Plang['tagname'].'</th></tr>';

$count = C::t('#micxp_relateitem_custom#micxp_relateitem_custom_tag')->fetch_all_by_status(NUll,$searchname,0, 0, 1);
$taglist =C::t('#micxp_relateitem_custom#micxp_relateitem_custom_tag')->fetch_all_by_status(NUll,$searchname,($page - 1) * $ppp, $ppp, 0);

foreach ($taglist as $key=>$val){
	echo '<tr><td><input type="checkbox" class="checkbox" name="ids[]" value="'.$val[tagid].'"></td>'.
			'<td>'.$val[tagname].'</td></tr>';
}

$multipage =multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=micxp_relateitem_custom&pmod=kwcp$extra");

showsubmit('', '', '','<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />'.cplang('all').'&nbsp;&nbsp;<input type="submit" class="btn" name="deletesubmit" value="'.cplang('delete').'" />',$multipage);


?>