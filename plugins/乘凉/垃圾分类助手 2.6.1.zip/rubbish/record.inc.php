<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record';

$op = in_array($_GET['op'], array('index','clean')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$intkeys = array();
		$strkeys = array('searchtype');
		$randkeys = array();
		$likekeys = array('username', 'name');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		if(strlen($_GET['searchtype'])) {
			$searchtypearr[$_GET['searchtype']] = ' selected';
		}
		$searchlang = array();
		$keys = array('record_name', 'record_searchtype', 'item_searchtype_text', 'item_searchtype_image');
		foreach ($keys as $key) {
			$searchlang[$key] = lang('plugin/'.$plugin['identifier'], $key);
		}
		$adminscript = ADMINSCRIPT;
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$lang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
					<th>$searchlang[record_name]</th><td><input type="text" class="txt" name="name" value="$_GET[name]"></td>
					<th>$searchlang[record_searchtype]</th><td><select name="searchtype"><option value="">$lang[all]</option><option value="text" $searchtypearr[text]>$searchlang[item_searchtype_text]</option><option value="image" $searchtypearr[image]>$searchlang[item_searchtype_image]</option></select></td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="rubbish">
						<input type="hidden" name="pmod" value="record">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'record_list'). '<a href="'.$pluginurl.'&op=clean" style="margin-left:10px">['.lang('plugin/'.$plugin['identifier'], 'record_clean').']</a>');
		showsubtitle(array('del', 'username', lang('plugin/'.$plugin['identifier'], 'record_name'), lang('plugin/'.$plugin['identifier'], 'record_found'), lang('plugin/'.$plugin['identifier'], 'record_searchtype'), 'ip', lang('plugin/'.$plugin['identifier'], 'record_createtime')));
		$count = C::t('#'.$plugin['identifier'].'#rubbish_record')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#rubbish_record')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
		foreach ($list as $value) {
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
			showtablerow('', array('class="td25"', 'class="td24"', '', 'class="td24"', 'class="td24"', 'class="td24"', 'class="td24"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$value['username'] ? $value['username'] : '/',
				$value['searchtype'] == 'image' ? '<a href="'.$_G['setting']['attachurl'].'rubbish/'.$value['name'].'" target="_blank"><img src="'.$_G['setting']['attachurl'].'rubbish/'.$value['name'].'" height="60"></a>' : $value['name'],
				$value['found'] ? $lang['yes'] : '<font color=red>'.$lang['no'].'</font>',
				lang('plugin/'.$plugin['identifier'], 'item_searchtype_'.$value['searchtype']),
				$value['postip'],
				$value['createtime']
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', 'select_all', '', $multipage);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	} else {
		if(is_array($_GET['delete'])) {
			C::t('#'.$plugin['identifier'].'#rubbish_record')->delete_by_id($_GET['delete']);
		}
		cpmsg(lang('plugin/'.$plugin['identifier'], 'record_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record', 'succeed');
	}
} elseif($op == 'clean') {
	if(!submitcheck('rbsubmit', 1)) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record&op=clean','enctype');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'clean_title'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'clean_days'), 'days', '30', 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'clean_days_comment'));
		showsubmit('rbsubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

	} else {
		$deleteids = array();
		$pernum = 500;
		$linksdel = intval($_GET['linksdel']);
		$days = intval($_GET['days']);
		$wherearr = array();
		if($days){
			$wherearr[] = "createtime < '".(TIMESTAMP - ($days * 86400))."'";
		}
		$list = C::t('#'.$plugin['identifier'].'#rubbish_record')->fetch_all_by_search_where($wherearr,'order by createtime asc', 0, $pernum);
		foreach($list as $value) {
			$deleteids[] = $value['id'];
		}
		if($deleteids) {
			C::t('#'.$plugin['identifier'].'#rubbish_record')->delete_by_id($deleteids);
			$linksdel += count($deleteids);
			//$startlimit += $pernum;
			cpmsg(lang('plugin/'.$plugin['identifier'], 'clean_next'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record&op=clean&rbsubmit=1&linksdel='.$linksdel.'&days='.$days, 'succeed', array('linksdel' => $linksdel));
		} else {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'clean_succeed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=record&op=clean', 'succeed', array('linksdel' => $linksdel));
		}
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>