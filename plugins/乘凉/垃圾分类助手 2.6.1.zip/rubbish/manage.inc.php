<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage';

$op = in_array($_GET['op'], array('index','add','edit','gather')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('savesubmit')) {
		$intkeys = array('cateid');
		$strkeys = array();
		$randkeys = array();
		$likekeys = array('name');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$searchcate = lang('plugin/'.$plugin['identifier'], 'item_cate');
		$searchname = lang('plugin/'.$plugin['identifier'], 'item_name');
		$categorylist = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
		$categoryselect = category_select($categorylist, 'cateid', true, $_GET['cateid']);
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$searchcate</th><td>$categoryselect</td>
					<th>$searchname</th><td><input type="text" class="txt" name="name" value="$_GET[name]"></td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="rubbish">
						<input type="hidden" name="pmod" value="manage">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'item_list'). '<a href="'.$pluginurl.'&op=add" style="margin-left:10px">['.lang('plugin/'.$plugin['identifier'], 'item_add').']</a>');
		showsubtitle(array('del', 'id', lang('plugin/'.$plugin['identifier'], 'item_name'), lang('plugin/'.$plugin['identifier'], 'item_cate'), lang('plugin/'.$plugin['identifier'], 'item_queries'), 'operation'));
		$count = C::t('#'.$plugin['identifier'].'#rubbish_item')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_all_by_search_where($wherearr,'order by id desc', $start, $perpage);
		foreach ($list as $value) {
			$value['lasttime'] = $value['lasttime'] ? dgmdate($value['lasttime'], 'Y-n-j H:i') : '/';
			showtablerow('', array('class="td25"', 'class="td28"', '', 'class="td28"', 'class="td26"', 'class="td26"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$value['id'],
				$value['name'],
				$categorylist[$value['cateid']]['name'],
				$value['queries'],
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">$lang[edit]</a>",
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('savesubmit', 'submit', 'select_all', '', $multipage);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

	} else {

		if($_GET['delete']) {
			C::t('#'.$plugin['identifier'].'#rubbish_item')->delete($_GET['delete']);
		}

		cpmsg(lang('plugin/'.$plugin['identifier'], 'item_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage', 'succeed');

	}
} elseif($op == 'edit' && $_GET['id']) {

	$item = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_by_id($_GET['id']);
	if(!$item) {
		cpmsg(lang('plugin/'.$plugin['identifier'], 'manage_nonexistence'), '', 'error');
	}
	$categorylist = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
	if(!submitcheck('savesubmit')) {
		$categorypselect = array();
		foreach($categorylist as $value) {
			$categorypselect[] = array($value['id'], $value['name']);
		}
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage&op=edit&id='.$_GET['id'],'enctype');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'item_edit'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'item_cate'), array('cateid', $categorypselect), $item['cateid'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'item_cate_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'item_name'), 'name', $item['name'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'item_name_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

	} else {

		$data = array(
			'cateid' => intval($_GET['cateid']),
			'name' => $_GET['name'],
		);
		if(!$data['cateid']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'item_cateid_empty'), '', 'error');
		}
		if(!$data['name']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'item_name_empty'), '', 'error');
		}
		$getitem = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_by_name($data['name']);
		if($getitem && $item['id'] != $getitem['id']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'item_name_exist'), '', 'error');
		}

		C::t('#'.$plugin['identifier'].'#rubbish_item')->update_by_id($_GET['id'], $data);
		cpmsg(lang('plugin/'.$plugin['identifier'], 'item_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage', 'succeed');
	}

} elseif($op == 'add') {
	$categorylist = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
	if(!submitcheck('savesubmit')) {
		$categorypselect = array();
		foreach($categorylist as $value) {
			$categorypselect[] = array($value['id'], $value['name']);
		}
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage&op=add','enctype');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'item_add'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'item_cate'), array('cateid', $categorypselect), 0, 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'item_cate_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'item_name'), 'name', $item['name'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'item_name_comment1'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	} else {
		if(!$_GET['cateid']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'item_cateid_empty'), '', 'error');
		}
		if(!$_GET['name']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'item_name_empty'), '', 'error');
		}
		foreach(explode("\n", $_GET['name']) as $key => $option) {
			$option = trim($option);
			if($option){
				$item = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_by_name($option);
				if(!$item){
					$data = array(
						'name' => $option,
						'cateid' => intval($_GET['cateid']),
					);
					C::t('#'.$plugin['identifier'].'#rubbish_item')->insert($data);
				}
			}
		}
		cpmsg(lang('plugin/'.$plugin['identifier'], 'item_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=manage', 'succeed');
	}

} elseif($op == 'gather') {
	if($_GET['import']) {
		$schkey = trim($_GET['schkey']);
		$result = dfsockopen('https://apps.juhe.cn/rubbish/server/search?keyWord='.durlencode(diconv($schkey, CHARSET, 'utf-8')).'&type=1');
		$result = json_decode($result, true);
		if(!$result['error_code']) {
			$categorylist = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
			foreach($result['result'] as $key => $value){
				$itemCategory = diconv($value['itemCategory'], 'utf-8');
				foreach($categorylist as $k => $val){
					if(strpos($val['mapping'], $itemCategory) !== false){
						$category = $val;
						break;
					}
				}
				$resinfo = array(
					'cateid' => $category['id'],
					'catename' => $itemCategory,
					'name' => diconv($value['itemName'], 'utf-8'),
					'queries' => 1,
					'lasttime' => $_G['timestamp']
				);
				$iteminfo = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_by_name($resinfo['name']);
				if(!$iteminfo){
					C::t('#'.$plugin['identifier'].'#rubbish_item')->insert($resinfo);
				}
			}
		}
		include template('common/header');
		echo $schkey;
		print_r($result);
		include template('common/footer');
		exit;

	} else {

		$wordlist = '';
		for($i = 0x4e00; $i <= 0x9fa5; $i ++){
			$word = '"\u' . dechex($i) . '"';
			$wordlist .= json_decode($word);
		}
		echo <<<SEARCH
<div id="showcount"></div>
<div id="showover"></div>
<div id="showmessage"></div>
<script type="text/javascript">
var wordlist = "$wordlist";
var wordarr = wordlist.split("");
document.getElementById('showcount').innerHTML += wordarr.length + '<br />';
function showmessage(i) {
	var x = new Ajax();
	x.get('{$pluginurl}&op=gather&import=1&inajax=1&schkey='+wordarr[i], function(s){
		var meg = document.getElementById('showmessage').innerHTML;
		document.getElementById('showmessage').innerHTML = i + s + '<br />' + meg;
		if(i < wordarr.length - 1){
			setTimeout(function(){ showmessage(i+1) }, 10);
		}else{
			document.getElementById('showover').innerHTML = 'success';
		}
	});
	return false;
}
setTimeout(function(){ showmessage(0) }, 10);
</script>
SEARCH;

	}

}

function category_select($categorylist, $name='catid', $shownull=true, $current='') {
	global $lang;
	$select = "<select id=\"$name\" name=\"$name\" class=\"ps vm\">";
	if($shownull) {
		$select .= '<option value="">'.$lang['select'].'</option>';
	}
	foreach ($categorylist as $value) {
		$selected = ($current && $current==$value['id']) ? 'selected="selected"' : '';
		$select .= "<option value=\"$value[id]\"$selected>$value[name]</option>";
	}
	$select .= "</select>";
	return $select;
}
//From: d'.'is'.'m.ta'.'obao.com
?>