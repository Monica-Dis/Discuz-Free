<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}

$navtitle = $setconfig['seo_title'];
$metakeywords = $setconfig['seo_keywords'];
$metadescription = $setconfig['seo_description'];
$topic = array();
$topic['useheader'] = 0;
$topic['usefooter'] = 0;

if(submitcheck('savesubmit')) {
	if($setconfig['allow_usergroups'] && !in_array($_G['groupid'], $setconfig['allow_usergroups'])){
		$errorinfo = lang('plugin/'.CURMODULE, 'usergroup_not_allow');
		include template(CURMODULE.':result');
		exit;
	}
	if($setconfig['limit_times']){
		$wherearr = array();
		$wherearr[] = "createtime >= '".dmktime(dgmdate($_G['timestamp'], 'd'))."'";
		if($_G['uid']){
			$wherearr[] = "uid = '".$_G['uid']."'";
		}else{
			$wherearr[] = "postip = '".$_G['clientip']."'";
		}
		$todaycount = C::t('#'.CURMODULE.'#rubbish_record')->count_by_search_where($wherearr);
		if($todaycount >= $setconfig['limit_times']){
			$errorinfo = lang('plugin/'.CURMODULE, 'today_limit');
			include template(CURMODULE.':result');
			exit;
		}
	}
	$searchtype = in_array($_GET['searchtype'], array('text', 'image', 'voice')) ? $_GET['searchtype'] : 'text';

	if($searchtype == 'text'){
		$schkey = trim($_GET['schkey']);
		if(empty($schkey)){
			$errorinfo = lang('plugin/'.CURMODULE, 'schkey_not_empty');
			include template(CURMODULE.':result');
			exit;
		}
		if(dstrlen($schkey) > 64){
			$errorinfo = lang('plugin/'.CURMODULE, 'schkey_too_long');
			include template(CURMODULE.':result');
			exit;
		}
		$item = C::t('#'.CURMODULE.'#rubbish_item')->fetch_by_name($schkey);
		if($item){
			C::t('#'.CURMODULE.'#rubbish_item')->update_by_id($item['id'], array('queries' => $item['queries'] + 1, 'lasttime' => $_G['timestamp']));
			$category = C::t('#'.CURMODULE.'#rubbish_cate')->fetch_by_id($item['cateid']);
		}elseif($setconfig['useApi']){
			$result = array();
			if($setconfig['useApi'] == 1){
				$result = dfsockopen('https://apps.juhe.cn/rubbish/server/search?keyWord='.durlencode(diconv($schkey, CHARSET, 'utf-8')).'&type=2');
				$result = json_decode($result, true);
			}elseif($setconfig['useApi'] == 2){
				$result = dfsockopen('http://apis.juhe.cn/rubbish/search?key='.$setconfig['AppKey'].'&q='.durlencode(diconv($schkey, CHARSET, 'utf-8')).'&type=2');
				$result = json_decode($result, true);
			}elseif($setconfig['useApi'] == 3){
				$result = dfsockopen('http://apis.juhe.cn/voiceRubbish/search?key='.$setconfig['AppKey'].'&q='.durlencode(diconv($schkey, CHARSET, 'utf-8')).'&type=2');
				$result = json_decode($result, true);
			}elseif($setconfig['useApi'] == 4){
				$result = wx_http_request('https://way.jd.com/JDAI/garbageTextSearch', array('appkey' => $setconfig['AppKey']), json_encode(array('cityId' => '310000', 'text' => diconv($schkey, CHARSET, 'utf-8'))), true);
				$result = json_decode($result, true);
				if($result['code'] == '10000'){
					$reslist = array();
					if($result['result']['result']['status'] == '0'){
						foreach($result['result']['result']['garbage_info'] as $key => $value){
							$reslist[] = array(
								'itemCategory' => $value['cate_name'],
								'itemName' => $value['garbage_name'],
							);
						}
					}
					$result = array('result' => $reslist);
				}else{
					$result = array('error_code' => $result['code'], 'reason' => $result['msg'], 'result' => '');
				}
			}
			if($result['error_code']) {
				$apierror = array(
					'uid' => $_G['uid'],
					'username' => $_G['username'],
					'errorcode' => $result['error_code'],
					'reason' => diconv($result['reason'], 'utf-8'),
					'result' => $result['result'],
					'createtime' => $_G['timestamp'],
					'postip' => $_G['clientip'],
				);
				C::t('#'.CURMODULE.'#rubbish_apierror')->insert($apierror);
				if($setconfig['remind_email']) {
					require_once libfile('function/mail');
					$res = sendmail($setconfig['remind_email'], lang('plugin/'.CURMODULE, 'remind_email_title'), lang('plugin/'.CURMODULE, 'remind_email_content'));
				}
				//include template(CURMODULE.':result');
				//exit;
			}else{
				$categorylist = C::t('#'.CURMODULE.'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
				foreach($result['result'] as $key => $value){
					$itemCategory = diconv($value['itemCategory'], 'utf-8');
					foreach($categorylist as $k => $val){
						if(strpos($val['mapping'], $itemCategory) !== false){
							$category = $val;
							break;
						}
					}
					$resinfo = array(
						'cateid' => $category['id'],
						'catename' => $itemCategory,
						'name' => diconv($value['itemName'], 'utf-8'),
						'queries' => 1,
						'lasttime' => $_G['timestamp']
					);
					if(!$item){
						$item = $resinfo;
					}
					if($setconfig['save_itemdata']){
						$iteminfo = C::t('#'.CURMODULE.'#rubbish_item')->fetch_by_name($resinfo['name']);
						if(!$iteminfo){
							C::t('#'.CURMODULE.'#rubbish_item')->insert($resinfo);
						}
					}
				}
			}
		}
	}elseif($searchtype == 'image'){
		if(!$setconfig['useApi1'] || !$setconfig['AppKey1']){
			$errorinfo = lang('plugin/'.CURMODULE, 'image_not_use');
			include template(CURMODULE.':result');
			exit;
		}

		require DISCUZ_ROOT . './source/plugin/rubbish/lib/discuz_upload.php';
		$upload = new discuz_upload();
		$upload->init($_FILES['Filedata'], 'rubbish');
		if(!$upload->error()) {
			$upload->save(1);
		}
		if($upload->error()){
			$errorinfo = lang('plugin/'.CURMODULE, 'upload_image_error');
			include template(CURMODULE.':result');
			exit;
		}

		$image = new image();
		$thumb = $image->Thumb($upload->attach['target'], '', 2048, 2048, 1, 1);

		$image_file = $_G['setting']['attachurl'].'rubbish/'.$upload->attach['attachment'];
		$image_info = getimagesize($image_file);
		$image_body = fread(fopen($image_file, 'r'), filesize($image_file));
		$image_body = base64_encode($image_body);

		//$image_body = getgpc('image', 'P');
		//$image_body = substr(strstr($image_body, ','), 1);
		if($setconfig['useApi1'] == 1){
			$result = dfsockopen('http://apis.juhe.cn/voiceRubbish/imgDisti', 0, array('image' => $image_body, 'type' => '2', 'key' => $setconfig['AppKey1']));
			$result = json_decode($result, true);
		}elseif($setconfig['useApi1'] == 2){
			$result = wx_http_request('https://way.jd.com/JDAI/garbageImageSearch', array('appkey' => $setconfig['AppKey1']), json_encode(array('cityId' => '310000', 'imgBase64' => $image_body)), true);
			$result = json_decode($result, true);
			if($result['code'] == '10000'){
				$reslist = array();
				if($result['result']['result']['status'] == '0'){
					foreach($result['result']['result']['garbage_info'] as $key => $value){
						$reslist[] = array(
							'itemCategory' => $value['cate_name'],
							'itemName' => $value['garbage_name'],
						);
					}
				}
				$result = array('result' => array(array('list' => $reslist)));
			}else{
				$result = array('error_code' => $result['code'], 'reason' => $result['msg'], 'result' => '');
			}
		}

		$schkey = $upload->attach['attachment'];
		if($result['error_code']) {
			$apierror = array(
				'uid' => $_G['uid'],
				'username' => $_G['username'],
				'errorcode' => $result['error_code'],
				'reason' => diconv($result['reason'], 'utf-8'),
				'result' => $result['result'],
				'createtime' => $_G['timestamp'],
				'postip' => $_G['clientip'],
			);
			C::t('#'.CURMODULE.'#rubbish_apierror')->insert($apierror);
			if($setconfig['remind_email']) {
				require_once libfile('function/mail');
				$res = sendmail($setconfig['remind_email'], lang('plugin/'.CURMODULE, 'remind_email_title'), lang('plugin/'.CURMODULE, 'remind_email_content'));
			}
			//include template(CURMODULE.':result');
			//exit;
		}else{
			$categorylist = C::t('#'.CURMODULE.'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
			foreach($result['result'] as $k => $val){
				foreach($val['list'] as $key => $value){
					$itemCategory = diconv($value['itemCategory'], 'utf-8');
					foreach($categorylist as $k => $val){
						if(strpos($val['mapping'], $itemCategory) !== false){
							$category = $val;
							break;
						}
					}
					$resinfo = array(
						'cateid' => $category['id'],
						'catename' => $itemCategory,
						'name' => diconv($value['itemName'], 'utf-8'),
						'queries' => 1,
						'lasttime' => $_G['timestamp']
					);
					if(!$item){
						$item = $resinfo;
					}
					if($setconfig['save_itemdata']){
						$iteminfo = C::t('#'.CURMODULE.'#rubbish_item')->fetch_by_name($resinfo['name']);
						if(!$iteminfo){
							C::t('#'.CURMODULE.'#rubbish_item')->insert($resinfo);
						}
					}
				}
			}
		}
	}elseif($searchtype == 'voice'){
		if(!$setconfig['useApi2'] || !$setconfig['AppKey2']){
			$errorinfo = lang('plugin/'.CURMODULE, 'voice_not_use');
			include template(CURMODULE.':result');
			exit;
		}


	}
	if($setconfig['save_record']){
		$record = array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'name' => $schkey,
			'found' => $item ? 1 : 0,
			'searchtype' => $searchtype,
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		C::t('#'.CURMODULE.'#rubbish_record')->insert($record);
	}
	include template(CURMODULE.':result');
}else{
	if($setconfig['show_keys']){
		$hotkeys = array();
		$wherearr = array();
		if($setconfig['show_keys'] == 1){
			$hotitems = C::t('#'.CURMODULE.'#rubbish_item')->fetch_all_by_search_where($wherearr, 'order by queries desc', 0, 15);
		}elseif($setconfig['show_keys'] == 2){
			$hotitems = C::t('#'.CURMODULE.'#rubbish_item')->fetch_all_by_search_where($wherearr, 'order by lasttime desc', 0, 15);
		}
		foreach($hotitems as $key => $value){
			$hotkeys[] = $value['name'];
		}
		if(count($hotkeys) < 15 && $setconfig['useApi']){
			if($setconfig['useApi'] == 1){
				$result = dfsockopen('https://apps.juhe.cn/rubbish/server/hot');
				$result = json_decode($result, true);
			}elseif($setconfig['useApi'] == 2){
				$result = dfsockopen('http://apis.juhe.cn/rubbish/hotSearch?key='.$setconfig['AppKey']);
				$result = json_decode($result, true);
			}elseif($setconfig['useApi'] == 3){
				$result = dfsockopen('http://apis.juhe.cn/voiceRubbish/hotSearch?key='.$setconfig['AppKey']);
				$result = json_decode($result, true);
			}
			$categorylist = C::t('#'.CURMODULE.'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
			foreach($result['result'] as $key => $value){
				if(!in_array($value['itemName'], $hotkeys)){
					$itemCategory = diconv($value['itemCategory'], 'utf-8');
					foreach($categorylist as $k => $val){
						if(strpos($val['mapping'], $itemCategory) !== false){
							$category = $val;
							break;
						}
					}
					$item = array(
						'cateid' => $category['id'],
						'catename' => $itemCategory,
						'name' => diconv($value['itemName'], 'utf-8'),
						'queries' => 1,
					);
					if($setconfig['save_itemdata']){
						C::t('#'.CURMODULE.'#rubbish_item')->insert($item);
					}
					$hotkeys[] = diconv($value['itemName'], 'utf-8');
				}
			}
		}
	}
	include template(CURMODULE.':index');
}

function wx_http_request($url, $params, $body="", $isPost=false, $isImage=false ) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url."?".http_build_query($params));
    if($isPost){
        if($isImage){
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: multipart/form-data;',
                    "Content-Length: ".strlen($body)
                )
            );
        }else{
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: text/plain'
                )
            );
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}