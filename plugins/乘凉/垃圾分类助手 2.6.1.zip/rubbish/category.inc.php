<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=category';

$op = in_array($_GET['op'], array('index','add','edit','export')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('savesubmit')) {
		showtableheader(lang('plugin/'.$plugin['identifier'], 'category_list'));
		showsubtitle(array('id', lang('plugin/'.$plugin['identifier'], 'category_name'), lang('plugin/'.$plugin['identifier'], 'category_explain'), lang('plugin/'.$plugin['identifier'], 'category_quantity'), 'operation'));
		$list = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_all_by_search_where(array(),'order by id asc');
		foreach ($list as $value) {
			$quantity = C::t('#'.$plugin['identifier'].'#rubbish_item')->count_by_search_where(array("cateid = '".$value['id']."'"));
			showtablerow('', array('class="td25"', 'class="td28"', '', 'class="td28"', 'class="td26"'), array(
				$value['id'],
				$value['name'],
				$value['explain'],
				$quantity,
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">$lang[edit]</a> <a href=\"".$pluginurl."&op=export&id=$value[id]\">$lang[export]</a>",
			));
		}
		showtablefooter(); /*dism��taobao��com*/

	} else {

		if($_GET['delete']) {
			C::t('#'.$plugin['identifier'].'#rubbish_cate')->delete($_GET['delete']);
		}

		cpmsg(lang('plugin/'.$plugin['identifier'], 'category_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=category', 'succeed');

	}
} elseif($op == 'edit' && $_GET['id']) {

	$category = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_by_id($_GET['id']);
	if(!$category) {
		cpmsg(lang('plugin/'.$plugin['identifier'], 'category_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {

		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=category&op=edit&id='.$_GET['id'],'enctype');
		showtableheader(); /*dism��taobao��com*/
		showsetting(lang('plugin/'.$plugin['identifier'], 'category_name'), 'name', $category['name'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'category_name_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'category_explain'), 'explain', $category['explain'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'category_explain_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'category_require'), 'require', $category['require'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'category_require_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'category_common'), 'common', $category['common'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'category_common_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

	} else {

		$data = array(
			'name' => $_GET['name'],
			'explain' => $_GET['explain'],
			'require' => $_GET['require'],
			'common' => $_GET['common'],
		);

		C::t('#'.$plugin['identifier'].'#rubbish_cate')->update_by_id($_GET['id'], $data);
		cpmsg(lang('plugin/'.$plugin['identifier'], 'category_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=category', 'succeed');
	}

} elseif($op == 'export') {
	
	$category = C::t('#'.$plugin['identifier'].'#rubbish_cate')->fetch_by_id($_GET['id']);
	if(!$category) {
		cpmsg(lang('plugin/'.$plugin['identifier'], 'category_nonexistence'), '', 'error');
	}
	$wherearr = array();
	$wherearr[] = "cateid = '".$category['id']."'";
	$list = C::t('#'.$plugin['identifier'].'#rubbish_item')->fetch_all_by_search_where($wherearr,'order by id desc');
	foreach ($list as $value) {
		$content .= $value['name']."\n";
	}
	$filename = 'rubbish_'.$category['id'].'.csv';

	ob_end_clean();
	header('Content-Encoding: none');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename='.$filename);
	header('Pragma: no-cache');
	header('Expires: 0');
	if($_G['charset'] != 'gbk') {
		$content = diconv($content, $_G['charset'], 'GBK');
	}
	echo $content;
	define('FOOTERDISABLED' , 1);
	exit();
}

//d'.'i'.'sm.ta'.'o'.'bao.com
?>