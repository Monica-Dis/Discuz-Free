<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_rubbish_cate`;
CREATE TABLE `cdb_plugin_rubbish_cate` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `explain` varchar(255) NOT NULL DEFAULT '',
  `require` varchar(255) NOT NULL DEFAULT '',
  `common` varchar(255) NOT NULL DEFAULT '',
  `mapping` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_rubbish_item`;
CREATE TABLE `cdb_plugin_rubbish_item` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` smallint(2) NOT NULL DEFAULT 0,
  `catename` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `queries` int(10) unsigned NOT NULL DEFAULT 0,
  `lasttime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cateid` (`cateid`),
  UNIQUE KEY `name` (`name`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_rubbish_record`;
CREATE TABLE `cdb_plugin_rubbish_record` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `found` tinyint(1) NOT NULL DEFAULT 0,
  `searchtype` varchar(25) NOT NULL DEFAULT '',
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_rubbish_apierror`;
CREATE TABLE `cdb_plugin_rubbish_apierror` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `errorcode` int(10) unsigned NOT NULL DEFAULT 0,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `result` text NOT NULL DEFAULT '',
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$category_array = lang('plugin/rubbish', 'category_array');
foreach($category_array as $key => $value) {
	$data = array(
		'id' => $value['id'],
		'name' => $value['name'],
		'explain' => $value['explain'],
		'require' => $value['require'],
		'common' => $value['common'],
		'mapping' => $value['mapping'],
	);
	C::t('#rubbish#rubbish_cate')->insert($data);
}

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvaW5zdGFsbC5waHA='));

?>