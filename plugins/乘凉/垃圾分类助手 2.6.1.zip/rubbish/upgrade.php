<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//���������
$category_array = lang('plugin/rubbish', 'category_array');
foreach($category_array as $key => $value) {
	$data = array(
		'id' => $value['id'],
		'name' => $value['name'],
		'explain' => $value['explain'],
		'require' => $value['require'],
		'common' => $value['common'],
		'mapping' => $value['mapping'],
	);
	C::t('#rubbish#rubbish_cate')->update_by_id($value['id'], $data);
}

//������Ϣ��
$lasttime_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_rubbish_item'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'lasttime') {
		$lasttime_existed = true;
		continue;
	}
}
$sql = '';
$sql .= !$lasttime_existed ? "ALTER TABLE `cdb_plugin_rubbish_item` ADD `lasttime` int(10) unsigned NOT NULL DEFAULT 0;\n" : '';
if($sql) {
	runquery($sql);
}


//������¼��
$searchtype_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_rubbish_record'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'searchtype') {
		$searchtype_existed = true;
		continue;
	}
}
$sql = '';
$sql .= !$searchtype_existed ? "ALTER TABLE `cdb_plugin_rubbish_record` ADD `searchtype` varchar(25) NOT NULL DEFAULT '';\n" : '';
if($sql) {
	runquery($sql);
	if(!$searchtype_existed) {
		C::t('#rubbish#rubbish_record')->update(array('searchtype' => 'text'));
	}
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `cdb_plugin_rubbish_apierror` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `errorcode` int(10) unsigned NOT NULL DEFAULT 0,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `result` text NOT NULL DEFAULT '',
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvZGlzY3V6X3BsdWdpbl9ydWJiaXNoX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3J1YmJpc2gvdXBncmFkZS5waHA='));

?>