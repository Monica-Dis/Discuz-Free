<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror';

$op = in_array($_GET['op'], array('index','clean')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'apierror_list'));
		showsubtitle(array('del', 'username', lang('plugin/'.$plugin['identifier'], 'apierror_reason'), lang('plugin/'.$plugin['identifier'], 'apierror_errorcode'), 'ip', lang('plugin/'.$plugin['identifier'], 'apierror_createtime')));
		$wherearr = array();
		$count = C::t('#'.$plugin['identifier'].'#rubbish_apierror')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#rubbish_apierror')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
		foreach ($list as $value) {
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
			showtablerow('', array('class="td25"', 'class="td24"', '', 'class="td24"', 'class="td24"', 'class="td24"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$value['username'],
				$value['reason'],
				$value['errorcode'],
				$value['postip'],
				$value['createtime']
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', 'select_all', '', $multipage);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	} else {
		if(is_array($_GET['delete'])) {
			C::t('#'.$plugin['identifier'].'#rubbish_apierror')->delete_by_id($_GET['delete']);
		}
		cpmsg(lang('plugin/'.$plugin['identifier'], 'apierror_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror', 'succeed');
	}
} elseif($op == 'clean') {
	if(!submitcheck('rbsubmit', 1)) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror&op=clean','enctype');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'clean_title'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'clean_days'), 'days', '30', 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'clean_days_comment'));
		showsubmit('rbsubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/

	} else {
		$deleteids = array();
		$pernum = 500;
		$linksdel = intval($_GET['linksdel']);
		$days = intval($_GET['days']);
		$wherearr = array();
		if($days){
			$wherearr[] = "createtime < '".(TIMESTAMP - ($days * 86400))."'";
		}
		$list = C::t('#'.$plugin['identifier'].'#rubbish_apierror')->fetch_all_by_search_where($wherearr,'order by createtime asc', 0, $pernum);
		foreach($list as $value) {
			$deleteids[] = $value['id'];
		}
		if($deleteids) {
			C::t('#'.$plugin['identifier'].'#rubbish_apierror')->delete_by_id($deleteids);
			$linksdel += count($deleteids);
			//$startlimit += $pernum;
			cpmsg(lang('plugin/'.$plugin['identifier'], 'clean_next'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror&op=clean&rbsubmit=1&linksdel='.$linksdel.'&days='.$days, 'succeed', array('linksdel' => $linksdel));
		} else {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'clean_succeed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=apierror&op=clean', 'succeed', array('linksdel' => $linksdel));
		}
	}
}
//From: d'.'is'.'m.ta'.'obao.com
?>