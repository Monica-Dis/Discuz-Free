<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','threadjump');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=record';

$op = in_array($_GET['op'], array('index','edit')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$intkeys = array('tid');
		$strkeys = array();
		$randkeys = array();
		$likekeys = array('linkurl');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$search_tid = lang('plugin/'.IDENTIFIER, 'record_tid');
		$search_linkurl = lang('plugin/'.IDENTIFIER, 'record_linkurl');
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
		<div style="margin-top:8px;">
		<table cellspacing="3" cellpadding="3">
			<tr>
				<th>$search_tid</th><td><input type="text" class="txt" name="linkurl" value="$_GET[tid]"></td>
				<th>$search_linkurl</th><td><input type="text" class="txt" name="linkurl" value="$_GET[linkurl]"></td>
				<td>
					<input type="hidden" name="action" value="plugins">
					<input type="hidden" name="identifier" value="threadjump">
					<input type="hidden" name="pmod" value="record">
					<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
				</td>
			</tr>
		</table>
		</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=record');
		showtableheader(lang('plugin/'.IDENTIFIER, 'record_list'));
		showsubtitle(array('del', 'username', 'subject', lang('plugin/'.IDENTIFIER, 'record_linkurl'), 'ip', 'dateline', 'operation'));
		$count = C::t('#'.IDENTIFIER.'#threadjump_record')->count_by_search_where($wherearr);
		$list = C::t('#'.IDENTIFIER.'#threadjump_record')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
		require_once libfile('function_forum', 'function');
		foreach ($list as $value) {
			$thread = get_thread_by_tid($value['tid']);
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
			showtablerow('', array('class="td25"', 'class="td23"', 'class="td31"', '', 'class="td24"', 'class="td24"', 'class="td25"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$value['username'],
				'<a href="forum.php?mod=viewthread&tid='.$value['tid'].'" target="_blank">'.$thread['subject'].'</a>',
				'<div style="word-break:break-all;">'.$value['linkurl'].'</div>',
				$value['postip'],
				$value['createtime'],
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">".$lang['edit']."</a> "
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', 'select_all', '', $multipage);
		showtablefooter(); //d'.'is'.'m.ta'.'obao.com
		showformfooter(); //di'.'sm.t'.'aoba'.'o.com

	} else {

		if($_GET['delete']) {
			C::t('#'.IDENTIFIER.'#threadjump_record')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/'.IDENTIFIER, 'record_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=record', 'succeed');

	}
} elseif($op == 'edit' && $_GET['id']) {

	$item = C::t('#'.IDENTIFIER.'#threadjump_record')->fetch_by_id($_GET['id']);
	if(!$item) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'record_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=record&op=edit&id='.$_GET['id'],'enctype');
		showtableheader(lang('plugin/'.IDENTIFIER, 'record_edit'));
		showsetting(lang('plugin/'.IDENTIFIER, 'record_linkurl'), 'linkurl', $item['linkurl'], 'textarea', '', 0, lang('plugin/'.IDENTIFIER, 'record_linkurl_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); //d'.'is'.'m.ta'.'obao.com
		showformfooter(); //di'.'sm.t'.'aoba'.'o.com
	} else {
		$data = array(
			'linkurl' => $_GET['linkurl'],
		);
		C::t('#'.IDENTIFIER.'#threadjump_record')->update_by_id($_GET['id'], $data);
		cpmsg(lang('plugin/'.IDENTIFIER, 'record_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=record&op=index', 'succeed');
	}

}
//From: Dism_taobao-com
?>