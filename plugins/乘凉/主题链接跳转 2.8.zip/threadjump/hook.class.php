<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_threadjump {

	public static $identifier = 'threadjump';

	function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
		if(in_array('', $setconfig['allow_forums'])) {
			$setconfig['allow_forums'] = array();
		}
		$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
		if(in_array('', $setconfig['allow_usergroups'])) {
			$setconfig['allow_usergroups'] = array();
		}
		$setconfig['allow_notjump'] = (array)unserialize($setconfig['allow_notjump']);
		if(in_array('', $setconfig['allow_notjump'])) {
			$setconfig['allow_notjump'] = array();
		}
		$this->setconfig = $setconfig;
	}

}


class plugin_threadjump_forum extends plugin_threadjump {
	
	function forumdisplay_thread_subject_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['subject_pctext']){
			$tids = array();
			foreach ($_G['forum_threadlist'] as $key => $value) {
				$tids[] = $value['tid'];
			}
			$wherearr = array();
			$wherearr[] = 'tid in ('.dimplode($tids).')';
			$threadlist = C::t('#'.self::$identifier.'#threadjump_record')->fetch_all_by_search_where($wherearr, "order by createtime desc");
			foreach ($threadlist as $value) {
				$thread[$value['tid']] = $setconfig['subject_pctext'];
			}
			foreach ($_G['forum_threadlist'] as $value) {
				$return[] = isset($thread[$value['tid']]) ? $thread[$value['tid']] : '';
			}
		}
		return $return;
	}
	
	function viewthread_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		if(!in_array($_G['groupid'], $setconfig['allow_notjump']) && ((!$setconfig['author_notjump'] && $_G['thread']['authorid'] == $_G['uid']) || $_G['thread']['authorid'] != $_G['uid'])){
			$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
			if($record){
				header('location: '.$record['linkurl']);
				exit();
			}
		}
		return '';
	}

	function viewthread_posttop_output() {
		global $_G,$postlist;
		$t = array();
		$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
		if($record){
			foreach($postlist as $post) {
				if($post['first']){
					include template(self::$identifier.':viewthread');
					$t[] = $return;
				}
			}
		}
		return $t;
	}

	function post_attribute_extra_output() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost)) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			include template(self::$identifier.':attribute');
		}
		return $return;
	}

	function post_attribute_extra_body_output() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost)) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			if($_GET['action'] == 'edit'){
				$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
				$linkurl = $record ? $record['linkurl'] : '';
			}
			include template(self::$identifier.':attribute_body');
		}
		return $return;
	}

	function post_sync_method() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' && submitcheck('topicsubmit')) || ($_GET['action'] == 'edit' && submitcheck('editsubmit') && $isfirstpost)){
			if((!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
				$linkurl = str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['linkurl'])));
				if(!empty($linkurl) && !preg_match('/^https?:\/\//is', $linkurl)) {
					showmessage(lang('plugin/'.self::$identifier, 'threadjump_urlerror'));
				}
			}
		}
		return '';
	}

	function post_sync_method_message($value){
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if($value['param'][0] == 'post_newthread_succeed' || ($value['param'][0] == 'post_edit_succeed' && $isfirstpost)){
			if((!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
				if($value['param'][0] == 'post_newthread_succeed'){
					$_G['tid'] = $value['param'][2]['tid'];
				}
				$linkurl = str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['linkurl'])));
				$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
				if(!empty($linkurl)){
					if($record){
						$data = array(
							'uid' => $_G['uid'],
							'username' => $_G['username'],
							'tid' => $_G['tid'],
							'linkurl' => $linkurl,
							'createtime' => $_G['timestamp'],
							'postip' => $_G['clientip'],
						);
						C::t('#'.self::$identifier.'#threadjump_record')->update_by_id($record['id'], $data);
					}else{
						$data = array(
							'uid' => $_G['uid'],
							'username' => $_G['username'],
							'tid' => $_G['tid'],
							'linkurl' => $linkurl,
							'createtime' => $_G['timestamp'],
							'postip' => $_G['clientip'],
						);
						C::t('#'.self::$identifier.'#threadjump_record')->insert($data);
					}
				}else{
					if($record) {
						C::t('#'.self::$identifier.'#threadjump_record')->delete_by_id($record['id']);
					}
				}
			}
		}
	}
}

class plugin_threadjump_group extends plugin_threadjump {
	
	function forumdisplay_thread_subject_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['subject_pctext']){
			$tids = array();
			foreach ($_G['forum_threadlist'] as $key => $value) {
				$tids[] = $value['tid'];
			}
			$wherearr = array();
			$wherearr[] = 'tid in ('.dimplode($tids).')';
			$threadlist = C::t('#'.self::$identifier.'#threadjump_record')->fetch_all_by_search_where($wherearr, "order by createtime desc");
			foreach ($threadlist as $value) {
				$thread[$value['tid']] = $setconfig['subject_pctext'];
			}
			foreach ($_G['forum_threadlist'] as $value) {
				$return[] = isset($thread[$value['tid']]) ? $thread[$value['tid']] : '';
			}
		}
		return $return;
	}
	
	function viewthread_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		if(!in_array($_G['groupid'], $setconfig['allow_notjump']) && ((!$setconfig['author_notjump'] && $_G['thread']['authorid'] == $_G['uid']) || $_G['thread']['authorid'] != $_G['uid'])){
			$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
			if($record){
				header('location: '.$record['linkurl']);
				exit();
			}
		}
		return '';
	}

	function viewthread_posttop_output() {
		global $_G,$postlist;
		$t = array();
		$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
		if($record){
			foreach($postlist as $post) {
				if($post['first']){
					include template(self::$identifier.':viewthread');
					$t[] = $return;
				}
			}
		}
		return $t;
	}

	function post_attribute_extra_output() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost)) && (!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			include template(self::$identifier.':attribute');
		}
		return $return;
	}

	function post_attribute_extra_body_output() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost)) && (!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			if($_GET['action'] == 'edit'){
				$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
				$linkurl = $record ? $record['linkurl'] : '';
			}
			include template(self::$identifier.':attribute_body');
		}
		return $return;
	}

	function post_sync_method() {
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if(($_GET['action'] == 'newthread' && submitcheck('topicsubmit')) || ($_GET['action'] == 'edit' && submitcheck('editsubmit') && $isfirstpost)){
			if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
				$linkurl = str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['linkurl'])));
				if(!empty($linkurl) && !preg_match('/^https?:\/\//is', $linkurl)) {
					showmessage(lang('plugin/'.self::$identifier, 'threadjump_urlerror'));
				}
			}
		}
		return '';
	}

	function post_sync_method_message($value){
		global $_G, $isfirstpost;
		$setconfig = $this->setconfig;
		if($value['param'][0] == 'post_newthread_succeed' || ($value['param'][0] == 'post_edit_succeed' && $isfirstpost)){
			if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
				if($value['param'][0] == 'post_newthread_succeed'){
					$_G['tid'] = $value['param'][2]['tid'];
				}
				$linkurl = str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['linkurl'])));
				$record = C::t('#'.self::$identifier.'#threadjump_record')->fetch_by_tid($_G['tid']);
				if(!empty($linkurl)){
					if($record){
						$data = array(
							'uid' => $_G['uid'],
							'username' => $_G['username'],
							'tid' => $_G['tid'],
							'linkurl' => $linkurl,
							'createtime' => $_G['timestamp'],
							'postip' => $_G['clientip'],
						);
						C::t('#'.self::$identifier.'#threadjump_record')->update_by_id($record['id'], $data);
					}else{
						$data = array(
							'uid' => $_G['uid'],
							'username' => $_G['username'],
							'tid' => $_G['tid'],
							'linkurl' => $linkurl,
							'createtime' => $_G['timestamp'],
							'postip' => $_G['clientip'],
						);
						C::t('#'.self::$identifier.'#threadjump_record')->insert($data);
					}
				}else{
					if($record) {
						C::t('#'.self::$identifier.'#threadjump_record')->delete_by_id($record['id']);
					}
				}
			}
		}
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}

}
//From: Dism��taobao��com
?>