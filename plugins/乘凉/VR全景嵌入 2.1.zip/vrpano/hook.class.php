<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_vrpano {

	public static $identifier = 'vrpano';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
		if(in_array('', $setconfig['allow_usergroups'])) {
			$setconfig['allow_usergroups'] = array();
		}
		$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
		if(in_array('', $setconfig['allow_forums'])) {
			$setconfig['allow_forums'] = array();
		}
		$setconfig['allow_groups'] = $setconfig['allow_groups'] ? explode(",", $setconfig['allow_groups']) : array();
		$websiteArr = array();
		foreach(explode("\n", $setconfig['allow_website']) as $key => $option) {
			if($option){
				$websiteArr[] = trim($option);
			}
		}
		$setconfig['allow_website'] = $websiteArr;
		$setconfig['linkurl_tip'] = nl2br($setconfig['linkurl_tip']);
		$this->setconfig = $setconfig;
    }

	function global_footer() {
		global $_G,$article,$content;
		$setconfig = $this->setconfig;
		if(CURSCRIPT == 'portal' && CURMODULE == 'view' && $article && strpos($content['content'], '[/pano]') !== FALSE){
			$content['content'] = preg_replace_callback("/\[pano\]\s*([^\[\<\r\n]+?)\s*\[\/pano\]/is", array(__CLASS__, '_parse_pano_callback'), $content['content']);
		}
		return '';
	}

	function _parse_pano($post) {
		global $_G;
		$message = $post['message'];
		if(strpos($message, '[/pano]') !== FALSE) {
			$message = preg_replace_callback("/\[pano\]\s*([^\[\<\r\n]+?)\s*\[\/pano\]/is", array(__CLASS__, '_parse_pano_callback'), $message);
		}
		$post['message'] = $message;
		return $post;
	}

	function _parse_pano_callback($matches) {
		$url = $matches[1];
		$setconfig = $this->setconfig;
		$host = parse_url($url, PHP_URL_HOST);
		if(!$host) {
			return '';
		}
		if($setconfig['allow_website']) {
			$hostlen = strlen($host);
			foreach($setconfig['allow_website'] as $val) {
				$domainlen = strlen($val);
				if($domainlen > $hostlen) {
					continue;
				}
				//if(substr($host, -$domainlen) == $val) {
				if($host == $val) {
					include template(self::$identifier.':vrpano');
					break;
				}
			}
		}else{
			include template(self::$identifier.':vrpano');
		}
		return $return;
	}


}

class plugin_vrpano_portal extends plugin_vrpano {

	function portalcp_middle_output() {
		global $_G;
		$setconfig = $this->setconfig;
		if(!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])){
			$setconfig['allow_website'] = implode(",",$setconfig['allow_website']);
			$setconfig['allow_website'] = $setconfig['allow_website'] ? "'".str_replace(",","','",$setconfig['allow_website'])."'" : '';
			include template(self::$identifier.':portalcp_middle');
		}
		return $return;
	}

}


class plugin_vrpano_forum extends plugin_vrpano {

	function post_editorctrl_left_output() {
		global $_G, $editorid;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			include template(self::$identifier.':editorctrl');
		}
		return $return;
	}

	function post_middle_output() {
		global $_G, $editorid;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			$setconfig['allow_website'] = implode(",",$setconfig['allow_website']);
			$setconfig['allow_website'] = $setconfig['allow_website'] ? "'".str_replace(",","','",$setconfig['allow_website'])."'" : '';
			include template(self::$identifier.':editorctrl_menu');
		}
		return $return;
	}

	function viewthread_posttop_output() {
		global $_G, $post, $postlist;
		$setconfig = $this->setconfig;
		if(!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])){
			if(empty($_GET['viewpid'])) {
				foreach($postlist as $key => $value) {
					if(!$setconfig['allow_usergroups'] || in_array($value['groupid'], $setconfig['allow_usergroups'])){
						$postlist[$key] = $this->_parse_pano($value);
					}
				}
			}else{
				if(!$setconfig['allow_usergroups'] || in_array($post['groupid'], $setconfig['allow_usergroups'])){
					$post = $this->_parse_pano($post);
				}
			}
		}
		return array();
	}
}

class plugin_vrpano_group extends plugin_vrpano {

	function post_editorctrl_left_output() {
		global $_G, $editorid;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			include template(self::$identifier.':editorctrl');
		}
		return $return;
	}

	function post_middle_output() {
		global $_G, $editorid;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			$setconfig['allow_website'] = implode(",",$setconfig['allow_website']);
			$setconfig['allow_website'] = $setconfig['allow_website'] ? "'".str_replace(",","','",$setconfig['allow_website'])."'" : '';
			include template(self::$identifier.':editorctrl_menu');
		}
		return $return;
	}

	function viewthread_posttop_output() {
		global $_G, $post, $postlist;
		$setconfig = $this->setconfig;
		if(!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])){
			if(empty($_GET['viewpid'])) {
				foreach($postlist as $key => $value) {
					if(!$setconfig['allow_usergroups'] || in_array($value['groupid'], $setconfig['allow_usergroups'])){
						$postlist[$key] = $this->_parse_pano($value);
					}
				}
			}else{
				if(!$setconfig['allow_usergroups'] || in_array($post['groupid'], $setconfig['allow_usergroups'])){
					$post = $this->_parse_pano($post);
				}
			}
		}
		return array();
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}
}

?>