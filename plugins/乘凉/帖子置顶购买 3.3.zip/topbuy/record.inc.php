<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp.inc.php 29364 2012-04-09 02:51:41Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','topbuy');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=record';

if(!submitcheck('submit')) {
	$intkeys = array('tid','displayorder');
	$strkeys = array();
	$randkeys = array();
	$likekeys = array('username');
	$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
	foreach($likekeys as $k) {
		$_GET[$k] = dhtmlspecialchars($_GET[$k]);
	}
	$wherearr = $results['wherearr'];
	$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
	$adminscript = ADMINSCRIPT;
	$searchtid = lang('plugin/'.IDENTIFIER, 'record_tid');
	$searchtoptype = lang('plugin/'.IDENTIFIER, 'topbuy_toptype');
	$displayorder_selected[$_GET["displayorder"]] = " selected";
	$threadsticky = $_G['setting']['threadsticky'];
	echo <<<SEARCH
	<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
		<div style="margin-top:8px;">
		<table cellspacing="3" cellpadding="3">
			<tr>
				<th>$lang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
				<th>$searchtid</th><td><input type="text" class="txt" name="tid" value="$_GET[tid]"></td>
				<th>$searchtoptype</th><td><select name="displayorder" class="ps vm"><option value="">$lang[select]</option><option value="1"$displayorder_selected[1]>$threadsticky[2]</option><option value="2"$displayorder_selected[2]>$threadsticky[1]</option><option value="3"$displayorder_selected[3]>$threadsticky[0]</option></select></td>
				<td>
					<input type="hidden" name="action" value="plugins">
					<input type="hidden" name="identifier" value="topbuy">
					<input type="hidden" name="pmod" value="record">
					<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
				</td>
			</tr>
		</table>
		</div>
	</form>
	<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
	$perpage = 30;
	$start = ($page-1)*$perpage;
	showformheader('plugins&identifier='.IDENTIFIER.'&pmod=record');
	showtableheader(lang('plugin/'.IDENTIFIER, 'record_list'));
	showsubtitle(array('del', 'username', 'subject', lang('plugin/'.IDENTIFIER, 'topbuy_toptype'), lang('plugin/'.IDENTIFIER, 'record_credit'), lang('plugin/'.IDENTIFIER, 'record_endtime'), lang('plugin/'.IDENTIFIER, 'record_createtime'), 'ip'));
	$count = C::t('#'.IDENTIFIER.'#topbuy_record')->count_by_search_where($wherearr);
	$list = C::t('#'.IDENTIFIER.'#topbuy_record')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
	require_once libfile('function_forum', 'function');
	foreach ($list as $value) {
		$thread = get_thread_by_tid($value['tid']);
		$value['endtime'] = dgmdate($value['endtime'], 'Y-n-j H:i');
		$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
		showtablerow('', array('class="td25"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
			$value['username'],
			'<a href="forum.php?mod=viewthread&tid='.$value['tid'].'" target="_blank">'.$thread['subject'].'</a>',
			$_G['setting']['threadsticky'][3-$value['displayorder']],
			$value['credit_num'].$_G['setting']['extcredits'][$value['credit_item']]['title'],
			$value['endtime'],
			$value['createtime'],
			$value['postip'],
		));
	}
	$multipage = multi($count, $perpage, $page, $mpurl);

	showsubmit('submit', 'submit', 'select_all', '', $multipage);
	showtablefooter();
	showformfooter();/*Dism_taobao-com*/
} else {
	if(is_array($_GET['delete'])) {
		C::t('#'.IDENTIFIER.'#topbuy_record')->delete_by_id($_GET['delete']);
	}
	cpmsg(lang('plugin/'.IDENTIFIER, 'record_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=record', 'succeed');
}
//From: Dism_taobao-com
?>