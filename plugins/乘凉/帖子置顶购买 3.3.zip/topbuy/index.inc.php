<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}
$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
if(in_array('', $setconfig['allow_forums'])) {
	$setconfig['allow_forums'] = array();
}
$setconfig['stick_level'] = (array)unserialize($setconfig['stick_level']);
if(!$setconfig['stick_level']) {
	showmessage(lang('plugin/'.CURMODULE, 'no_stick_level'));
}

require_once libfile('function/forum');

loadforum();
$thread = $_G['thread'];

if(!$thread || $thread['displayorder'] < 0) {
	showmessage('thread_nonexistence');
}
if($thread['authorid'] != $_G['uid']) {
	showmessage('quickclear_noperm');
}
if($setconfig['allow_forums'] && !in_array($thread['fid'], $setconfig['allow_forums'])){
	showmessage(lang('plugin/'.CURMODULE, 'forum_not_allow'));
}
if($setconfig['allow_usergroups'] && !in_array($_G['groupid'], $setconfig['allow_usergroups'])){
	showmessage(lang('plugin/'.CURMODULE, 'usergroup_not_allow'));
}
$wherearr = array();
$wherearr[] = "uid = '".$_G['uid']."'";
$wherearr[] = "tid = '".$thread['tid']."'";
$wherearr[] = "endtime > '".$_G['timestamp']."'";
$record = C::t('#'.CURMODULE.'#topbuy_record')->count_by_search_where($wherearr);
if($record) {
	showmessage(lang('plugin/'.CURMODULE, 'topbuy_takeup'));
}
if($thread['displayorder'] != 0) {
	showmessage(lang('plugin/'.CURMODULE, 'thread_not_allow'));
}
if($setconfig['tids_limit']) {
	$showcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_thread')." t LEFT JOIN ".DB::table('plugin_topbuy_record')." tr ON tr.tid=t.tid where t.fid = '".$thread['fid']."' and t.displayorder = '1' and tr.endtime > '".$_G['timestamp']."'");
	if($showcount >= $setconfig['tids_limit']) {
		showmessage(lang('plugin/'.CURMODULE, 'tids_limit'));
	}
}
$mycredit = array();
foreach($setconfig['stick_level'] as $value){
	if(!$mycredit[$setconfig['credit_item'.$value]]){
		$mycredit[$setconfig['credit_item'.$value]] = getuserprofile('extcredits'.$setconfig['credit_item'.$value]);
	}
}

if(submitcheck('savesubmit')) {
	$sticklevel = in_array($_GET['sticklevel'], $setconfig['stick_level']) ? $_GET['sticklevel'] : 0; //�ö���ʽ
	if(!$sticklevel) {
		showmessage(lang('plugin/'.CURMODULE, 'select_stick_level'));
	}
	$paytimes = intval($_GET['paytimes']);
	if($paytimes < 1 || $paytimes > $setconfig['time_long']) {
		showmessage(lang('plugin/'.CURMODULE, 'record_paytimes_error'));
	}

	$expiration = 0;
	if($setconfig['time_unit'] == 1){
		$expiration = $_G['timestamp'] + $paytimes * 3600;
	}elseif($setconfig['time_unit'] == 2){
		$expiration = $_G['timestamp'] + $paytimes * 24 * 3600;
	}elseif($setconfig['time_unit'] == 3){
		$expiration = $_G['timestamp'] + $paytimes * 7 * 24 * 3600;
	}elseif($setconfig['time_unit'] == 4){
		$expiration = $_G['timestamp'] + $paytimes * 30 * 24 * 3600;
	}elseif($setconfig['time_unit'] == 5){
		$expiration = $_G['timestamp'] + $paytimes * 365 * 24 * 3600;
	}

	$setconfig['credit_num'.$sticklevel] = $setconfig['credit_num'.$sticklevel] * $paytimes;
	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'displayorder' => $sticklevel,
		'fid' => $thread['fid'],
		'tid' => $thread['tid'],
		'credit_item' => $setconfig['credit_item'.$sticklevel],
		'credit_num' => $setconfig['credit_num'.$sticklevel],
		'endtime' => $expiration,
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	if($mycredit[$setconfig['credit_item'.$sticklevel]] < $setconfig['credit_num'.$sticklevel]) {
		showmessage(lang('plugin/'.CURMODULE, 'credit_notenough', array('credit_item' => $_G['setting']['extcredits'][$setconfig['credit_item'.$sticklevel]]['title'])));
	}
	updatemembercount($_G['uid'], array('extcredits'.$setconfig['credit_item'.$sticklevel] => -$setconfig['credit_num'.$sticklevel]), 1, '', 0, '', lang('plugin/'.CURMODULE, 'topbuy_usecredit'), lang('plugin/'.CURMODULE, 'topbuy_usecredit').'('.$_G['setting']['threadsticky'][3-$sticklevel].')');
	C::t('#'.CURMODULE.'#topbuy_record')->insert($data);

	$forumstickthreads = $_G['setting']['forumstickthreads'];
	$forumstickthreads = isset($forumstickthreads) ? dunserialize($forumstickthreads) : array();
	C::t('forum_thread')->update($thread['tid'], array('displayorder'=>$sticklevel, 'moderated'=>1), true);
	unset($forumstickthreads[$thread['tid']]);
	C::t('common_setting')->update('forumstickthreads', $forumstickthreads);

	$stickmodify = 0;
	$stickmodify = (in_array($thread['displayorder'], array(2, 3)) || in_array($sticklevel, array(2, 3))) && $sticklevel != $thread['displayorder'] ? 1 : $stickmodify;
	if(class_exists('table_common_member_secwhite')) {
		C::t('common_member_secwhite')->add($thread['authorid']);
	}
	if($_G['setting']['globalstick'] && $stickmodify) {
		require_once libfile('function/cache');
		updatecache('globalstick');
	}

	$modaction = $sticklevel ? ($expiration ? 'EST' : 'STK') : 'UST';
	C::t('forum_threadmod')->update_by_tid_action($thread['tid'], array('STK', 'UST', 'EST', 'UES'), array('status' => 0));
	if(class_exists('table_forum_threadhidelog')) {
		C::t('forum_threadhidelog')->delete_by_tid($thread['tid']);
	}

	require_once libfile('function/post');
	updatemodlog($thread['tid'], $modaction, $expiration);

	updatemodworks($modaction);

	//��־��¼
	require_once libfile('function/misc');
	modlog($thread, $modaction);

	//�������ͼ��
	$stampaction = 'SPA';
	$stampstatus = 1;
	if(array_key_exists($stampstatus, $_G['cache']['stamptypeid'])) {
		C::t('forum_thread')->update($thread['tid'], array('stamp'=>$_G['cache']['stamptypeid'][$stampstatus]), true);
		updatemodlog($thread['tid'], $stampaction, $expiration, 0, '', $_G['cache']['stamptypeid'][$stampstatus]);
	}

	notification_add($_G['uid'], 'system', lang('plugin/'.CURMODULE, 'topbuy_notification'), array('thread' => '<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" target="_blank">'.$thread['subject'].'</a>', 'sticktype' => $_G['setting']['threadsticky'][3-$sticklevel], 'createtime' => dgmdate($data['createtime'], 'Y-n-j H:i'), 'endtime' => dgmdate($data['endtime'], 'Y-n-j H:i')), 1);

	showmessage(lang('plugin/'.CURMODULE, 'topbuy_addsucceed'), dreferer(), array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));
}else{
	include template(CURMODULE.':topbuy');
}