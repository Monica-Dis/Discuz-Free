<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_topbuy {

	public static $identifier = 'topbuy';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
		if(in_array('', $setconfig['allow_usergroups'])) {
			$setconfig['allow_usergroups'] = array();
		}
		$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
		if(in_array('', $setconfig['allow_forums'])) {
			$setconfig['allow_forums'] = array();
		}
		$setconfig['allow_groups'] = $setconfig['allow_groups'] ? explode(",", $setconfig['allow_groups']) : array();
		$this->setconfig = $setconfig;
    }

}

class plugin_topbuy_forum extends plugin_topbuy {

	function forumdisplay_thread_subject_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['subject_pctext']){
			$tids = array();
			foreach ($_G['forum_threadlist'] as $key => $value) {
				$tids[] = $value['tid'];
			}
			$wherearr = array();
			$wherearr[] = 'tid in ('.dimplode($tids).')';
			$wherearr[] = "endtime > '".$_G['timestamp']."'";
			$threadlist = C::t('#'.self::$identifier.'#topbuy_record')->fetch_all_by_search_where($wherearr, "order by createtime desc");
			foreach ($threadlist as $value) {
				$thread[$value['tid']] = $setconfig['subject_pctext'];
			}
			foreach ($_G['forum_threadlist'] as $value) {
				//if($value['displayorder'] == 1){
					$return[] = $thread[$value['tid']];
				//}
			}
		}
		return $return;
	}
	

	function viewthread_useraction_output() {
		global $_G;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])) && $_G['thread']['authorid'] == $_G['uid']){
			include template(self::$identifier.':viewthread');
		}
		return $return;
	}

}

class plugin_topbuy_group extends plugin_topbuy {

	function forumdisplay_thread_subject_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['subject_text']){
			$wherearr = array();
			//$wherearr[] = 'fid = '.$_G['fid'];
			$wherearr[] = "endtime > '".$_G['timestamp']."'";
			$threadlist = C::t('#'.self::$identifier.'#topbuy_record')->fetch_all_by_search_where($wherearr, "order by createtime desc");
			foreach ($threadlist as $value) {
				$thread[$value['tid']] = $setconfig['subject_text'];
			}
			foreach ($_G['forum_threadlist'] as $value) {
				//if($value['displayorder'] == 1){
					$return[] = $thread[$value['tid']];
				//}
			}
		}
		return $return;
	}
	

	function viewthread_useraction_output() {
		global $_G;
		$setconfig = $this->setconfig;
		if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])) && $_G['thread']['authorid'] == $_G['uid']){
			include template(self::$identifier.':viewthread');
		}
		return $return;
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}

}
//From: Dism��taobao��com
?>