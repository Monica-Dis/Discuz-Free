<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_setrewrite_rule`;
CREATE TABLE `cdb_plugin_setrewrite_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `displayorder` smallint(4) NOT NULL DEFAULT 0,
  `rulekey` varchar(40) NOT NULL DEFAULT '',
  `rulesearch` varchar(255) NOT NULL DEFAULT '',
  `rulereplace` varchar(255) NOT NULL DEFAULT '',
  `rulevars` varchar(255) NOT NULL DEFAULT '',
  `rewritestatus` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);

//�Ż���ҳ
$data = array(
	'rulekey' => 'portal_index',
	'rulesearch' => 'portal.html',
	'rulereplace' => 'portal.php',
	'rulevars' => serialize(array()),
	'rewritestatus' => 0,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//�Ż�Ƶ��ҳ
$data = array(
	'rulekey' => 'portal_list',
	'rulesearch' => 'list-{catid}-{page}.html',
	'rulereplace' => 'portal.php?mod=list&catid={catid}&page={page}',
	'rulevars' => serialize(array('{catid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//����ҳ��
$data = array(
	'rulekey' => 'guide_list',
	'rulesearch' => 'guide-{view}-{page}.html',
	'rulereplace' => 'forum.php?mod=guide&view={view}&page={page}',
	'rulevars' => serialize(array('{view}' => '(\w+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��̳��ҳ
$data = array(
	'rulekey' => 'forum_index',
	'rulesearch' => 'forum.html',
	'rulereplace' => 'forum.php',
	'rulevars' => serialize(array()),
	'rewritestatus' => 0,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//�������
$data = array(
	'rulekey' => 'forum_group',
	'rulesearch' => 'forum-{gid}.html',
	'rulereplace' => 'forum.php?gid={gid}',
	'rulevars' => serialize(array('{gid}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��̳�����б���ҳ
$data = array(
	'rulekey' => 'forum_forumdisplay_index',
	'rulesearch' => 'forum-{fid}-1.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}',
	'rulevars' => serialize(array('{fid}' => '(\w+)')),
	'rewritestatus' => 0,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��̳����������ҳ
$data = array(
	'rulekey' => 'forum_viewthread_index',
	'rulesearch' => 'thread-{tid}-1-1.html',
	'rulereplace' => 'forum.php?mod=viewthread&tid={tid}',
	'rulevars' => serialize(array('{tid}' => '([0-9]+)')),
	'rewritestatus' => 0,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//�������ҳ
$data = array(
	'rulekey' => 'forum_forumdisplay_type',
	'rulesearch' => 'forum-{fid}-t{typeid}-{page}.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}&filter=typeid&typeid={typeid}&page={page}',
	'rulevars' => serialize(array('{fid}' => '(\w+)', '{typeid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//������Ϣҳ
$data = array(
	'rulekey' => 'forum_forumdisplay_sort',
	'rulesearch' => 'forum-{fid}-s{sortid}-{page}.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}&filter=sortid&sortid={sortid}&page={page}',
	'rulevars' => serialize(array('{fid}' => '(\w+)', '{sortid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��������������Ϣ����ҳ
$data = array(
	'rulekey' => 'forum_forumdisplay_type_sort',
	'rulesearch' => 'forum-{fid}-t{typeid}-s{sortid}-{page}.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}&filter=typeid&typeid={typeid}&sortid={sortid}&page={page}',
	'rulevars' => serialize(array('{fid}' => '(\w+)', '{typeid}' => '([0-9]+)', '{sortid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//������Ϣҳ��֧��ɸѡ��
$data = array(
	'rulekey' => 'forum_forumdisplay_searchsort',
	'rulesearch' => 'forum-{fid}-s{sortid}-{vars}-{page}.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}&filter=sortid&sortid={sortid}&searchsort=1&rewritevars={vars}&page={page}',
	'rulevars' => serialize(array('{fid}' => '(\w+)', '{sortid}' => '([0-9]+)', '{vars}' => '([\w\.\|]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��������������Ϣ����ҳ��֧��ɸѡ��
$data = array(
	'rulekey' => 'forum_forumdisplay_type_searchsort',
	'rulesearch' => 'forum-{fid}-t{typeid}-s{sortid}-{vars}-{page}.html',
	'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}&filter=sortid&typeid={typeid}&sortid={sortid}&searchsort=1&rewritevars={vars}&page={page}',
	'rulevars' => serialize(array('{fid}' => '(\w+)', '{typeid}' => '([0-9]+)', '{sortid}' => '([0-9]+)', '{vars}' => '([\w\.\|]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��ǩ��ҳ
$data = array(
	'rulekey' => 'misc_tag_index',
	'rulesearch' => 'tag.html',
	'rulereplace' => 'misc.php?mod=tag',
	'rulevars' => serialize(array()),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��ǩҳ�棨ID��ѯ��
$data = array(
	'rulekey' => 'misc_tag',
	'rulesearch' => 'tag-{id}.html',
	'rulereplace' => 'misc.php?mod=tag&id={id}',
	'rulevars' => serialize(array('{id}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��ǩҳ�棨���Ʋ�ѯ��
$data = array(
	'rulekey' => 'misc_tag_name',
	'rulesearch' => 'tag-name-{name}.html',
	'rulereplace' => 'misc.php?mod=tag&name={name}',
	'rulevars' => serialize(array('{name}' => '(.+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//��ǩ����ҳ��
$data = array(
	'rulekey' => 'misc_tag_type',
	'rulesearch' => 'tag-{id}-{type}-{page}.html',
	'rulereplace' => 'misc.php?mod=tag&id={id}&type={type}&page={page}',
	'rulevars' => serialize(array('{id}' => '([0-9]+)', '{type}' => '(\w+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//ֻ��������ҳ��
$data = array(
	'rulekey' => 'forum_viewthread_author',
	'rulesearch' => 'thread-{tid}-author-{authorid}-{page}.html',
	'rulereplace' => 'forum.php?mod=viewthread&tid={tid}&authorid={authorid}&page={page}',
	'rulevars' => serialize(array('{tid}' => '([0-9]+)', '{authorid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//ֻ����ͼҳ��
$data = array(
	'rulekey' => 'forum_viewthread_album',
	'rulesearch' => 'thread-{tid}-album.html',
	'rulereplace' => 'forum.php?mod=viewthread&tid={tid}&from=album',
	'rulevars' => serialize(array('{tid}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//�û����ҳ
$data = array(
	'rulekey' => 'home_album',
	'rulesearch' => 'album-{uid}-{albumid}.html',
	'rulereplace' => 'home.php?mod=space&uid={uid}&do=album&id={albumid}',
	'rulevars' => serialize(array('{uid}' => '([0-9]+)', '{albumid}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//Ⱥ�����ҳ
$data = array(
	'rulekey' => 'group_type',
	'rulesearch' => 'group-{type}-{gid}.html',
	'rulereplace' => 'group.php?{type}={gid}',
	'rulevars' => serialize(array('{type}' => '(gid|sgid)', '{gid}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//������ҳ
$data = array(
	'rulekey' => 'forum_collection_index',
	'rulesearch' => 'collection.html',
	'rulereplace' => 'forum.php?mod=collection',
	'rulevars' => serialize(array()),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

//����ר��ҳ
$data = array(
	'rulekey' => 'forum_collection',
	'rulesearch' => 'collection-{ctid}-{page}.html',
	'rulereplace' => 'forum.php?mod=collection&action=view&ctid={ctid}&page={page}',
	'rulevars' => serialize(array('{ctid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
	'rewritestatus' => 1,
);
C::t('#setrewrite#setrewrite_rule')->insert($data);

updatecache('setrewrite:setrewrite_rule');

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvdXBncmFkZS5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvaW5zdGFsbC5waHA='));

?>