<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!submitcheck('savesubmit')) {
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=seo');
	showtips(lang('plugin/'.$plugin['identifier'], 'seo_tip'));
	showtableheader('', 'nobottom');
	showsubtitle(array('setting_seo_pages', 'setting_seo_vars', 'setting_seo_rule', 'available'));
	loadcache('setrewrite_rule');
	$rulelist = $_G['cache']['setrewrite_rule'];
	foreach($rulelist as $k => $v) {
		$v['rulevars'] = unserialize($v['rulevars']);
		$rulelang = lang('plugin/'.$plugin['identifier'], 'rewritekeys');
		showtablerow('', array('class="td24"', 'class="td31"', 'class="longtxt"', 'class="td25"'), array(
			$rulelang[$v['rulekey']],
			$v['rulevars'] ? implode(', ', array_keys($v['rulevars'])) : '/',
			'<input onclick="doane(event)" name="rulesearch['.$v['id'].']" class="txt" value="'.dhtmlspecialchars($v['rulesearch']).'"/>',
			'<input type="checkbox" name="rewritestatus['.$v['id'].']" class="checkbox" value="1" '.($v['rewritestatus'] ? 'checked="checked"' : '').'/>'
		));
	}
	showtablefooter(); /*dism��taobao��com*/
	showsubmit('savesubmit', 'submit');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
} else {

	if(is_array($_GET['rulesearch'])) {
		foreach($_GET['rulesearch'] as $id => $val) {
			if($val) {
				$query = C::t('#'.$plugin['identifier'].'#setrewrite_rule')->update($id, array(
					'rulesearch' => $_GET['rulesearch'][$id],
					'rewritestatus' => intval($_GET['rewritestatus'][$id]) ? 1 : 0,
				));
			}
		}
	}
	updatecache('setrewrite:setrewrite_rule');

	cpmsg(lang('plugin/'.$plugin['identifier'], 'rewrite_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=seo', 'succeed');

}


?>