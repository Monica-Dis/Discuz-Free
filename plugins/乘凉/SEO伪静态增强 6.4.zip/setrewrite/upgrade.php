<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$displayorder_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_setrewrite_rule'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'displayorder') {
		$displayorder_existed = true;
		continue;
	}
}
$sql = !$displayorder_existed ? "ALTER TABLE `cdb_plugin_setrewrite_rule` ADD `displayorder` smallint(4) NOT NULL DEFAULT 0;\n" : '';
if($sql) {
	runquery($sql);
}

$wherearr = array();
$rulelist = C::t('#setrewrite#setrewrite_rule')->fetch_all_by_search_where($wherearr, '');
$rules = array();
foreach($rulelist as $k => $v) {
	$rules[$v['rulekey']] = $v;
}
//�Ż���ҳ
if(!$rules['portal_index']) {
	$data = array(
		'rulekey' => 'portal_index',
		'rulesearch' => 'portal.html',
		'rulereplace' => 'portal.php',
		'rulevars' => serialize(array()),
		'rewritestatus' => 0,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//Ⱥ�����ҳ
if(!$rules['group_type']) {
	$data = array(
		'rulekey' => 'group_type',
		'rulesearch' => 'group-{type}-{gid}.html',
		'rulereplace' => 'group.php?{type}={gid}',
		'rulevars' => serialize(array('{type}' => '(gid|sgid)', '{gid}' => '([0-9]+)')),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��̳��ҳ
if(!$rules['forum_index']) {
	$data = array(
		'rulekey' => 'forum_index',
		'rulesearch' => 'forum.html',
		'rulereplace' => 'forum.php',
		'rulevars' => serialize(array()),
		'rewritestatus' => 0,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��ǩ��ҳ
if(!$rules['misc_tag_index']) {
	$data = array(
		'rulekey' => 'misc_tag_index',
		'rulesearch' => 'tag.html',
		'rulereplace' => 'misc.php?mod=tag',
		'rulevars' => serialize(array()),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��ǩҳ�棨���Ʋ�ѯ��
if(!$rules['misc_tag_name']) {
	$data = array(
		'rulekey' => 'misc_tag_name',
		'rulesearch' => 'tag-name-{name}.html',
		'rulereplace' => 'misc.php?mod=tag&name={name}',
		'rulevars' => serialize(array('{name}' => '(.+)')),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//ֻ��������ҳ��
if(!$rules['forum_viewthread_author']) {
	$data = array(
		'rulekey' => 'forum_viewthread_author',
		'rulesearch' => 'thread-{tid}-author-{authorid}-{page}.html',
		'rulereplace' => 'forum.php?mod=viewthread&tid={tid}&authorid={authorid}&page={page}',
		'rulevars' => serialize(array('{tid}' => '([0-9]+)', '{authorid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��ǩ��ҳ
if(!$rules['forum_collection_index']) {
	$data = array(
		'rulekey' => 'forum_collection_index',
		'rulesearch' => 'collection.html',
		'rulereplace' => 'forum.php?mod=collection',
		'rulevars' => serialize(array()),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//����ר��ҳ
if(!$rules['forum_collection']) {
	$data = array(
		'rulekey' => 'forum_collection',
		'rulesearch' => 'collection-{ctid}-{page}.html',
		'rulereplace' => 'forum.php?mod=collection&action=view&ctid={ctid}&page={page}',
		'rulevars' => serialize(array('{ctid}' => '([0-9]+)', '{page}' => '([0-9]+)')),
		'rewritestatus' => 1,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��̳�����б���ҳ
if(!$rules['forum_forumdisplay_index']) {
	$data = array(
		'rulekey' => 'forum_forumdisplay_index',
		'rulesearch' => 'forum-{fid}-1.html',
		'rulereplace' => 'forum.php?mod=forumdisplay&fid={fid}',
		'rulevars' => serialize(array('{fid}' => '(\w+)')),
		'rewritestatus' => 0,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

//��̳����������ҳ
if(!$rules['forum_viewthread_index']) {
	$data = array(
		'rulekey' => 'forum_viewthread_index',
		'rulesearch' => 'thread-{tid}-1-1.html',
		'rulereplace' => 'forum.php?mod=viewthread&tid={tid}',
		'rulevars' => serialize(array('{tid}' => '([0-9]+)')),
		'rewritestatus' => 0,
	);
	C::t('#setrewrite#setrewrite_rule')->insert($data);
}

$ruleorder = array(
	'portal_index' => 1,
	'portal_list' => 2,
	'guide_list' => 3,
	'forum_index' => 4,
	'forum_group' => 5,
	'forum_forumdisplay_index' => 6,
	'forum_viewthread_index' => 7,
	'forum_forumdisplay_type' => 8,
	'forum_forumdisplay_sort' => 9,
	'forum_forumdisplay_type_sort' => 10,
	'forum_forumdisplay_searchsort' => 11,
	'forum_forumdisplay_type_searchsort' => 12,
	'misc_tag_index' => 13,
	'misc_tag' => 14,
	'misc_tag_name' => 15,
	'misc_tag_type' => 16,
	'forum_viewthread_author' => 17,
	'forum_viewthread_album' => 18,
	'home_album' => 19,
	'group_type' => 20,
	'forum_collection_index' => 21,
	'forum_collection' => 22
);
foreach($ruleorder as $key => $value){
	C::t('#setrewrite#setrewrite_rule')->update_by_rulekey($key, array('displayorder' => $value));
}
updatecache('setrewrite:setrewrite_rule');

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1NDX0dCSy54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1NDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvZGlzY3V6X3BsdWdpbl9zZXRyZXdyaXRlX1RDX1VURjgueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvaW5zdGFsbC5waHA='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3NldHJld3JpdGUvdXBncmFkZS5waHA='));

?>