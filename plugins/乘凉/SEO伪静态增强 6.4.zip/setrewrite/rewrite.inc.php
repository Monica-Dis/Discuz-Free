<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$wherearr = array();
$wherearr[] = "rewritestatus = 1";
$rulelist = C::t('#'.$plugin['identifier'].'#setrewrite_rule')->fetch_all_by_search_where($wherearr, 'order by displayorder asc');
$rule = array();
$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = $rule['{lighttpd}'] = $rule['{caddy}'] = '';
foreach($rulelist as $k => $v) {
	if(!$v['rewritestatus']) {
		continue;
	}
	$v['rulevars'] = unserialize($v['rulevars']);
	$pvmaxv = count($v['rulevars']) + 2;
	$vkeys = array_keys($v['rulevars']);
	$v['rulereplace'] = pvsort($vkeys, $v['rulesearch'], $v['rulereplace']);
	$v['rulesearch'] = str_replace($vkeys, $v['rulevars'], addcslashes($v['rulesearch'], '?*+^$.[]()|'));
	$rulepath = '';
	$rule['{apache1}'] .= "\t".'RewriteCond %{QUERY_STRING} ^(.*)$'."\n\t".'RewriteRule ^(.*)/'.$v['rulesearch'].'$ $1/'.$rulepath.pvadd($v['rulereplace']).(strpos($v['rulereplace'], '?') !== false ? "&" : "?")."%1\n";
	$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v['rulesearch'].'$ '.$rulepath.$v['rulereplace'].(strpos($v['rulereplace'], '?') !== false ? "&" : "?")."%1\n";
	$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v['rulesearch'].'(\?(.*))*$ $1/'.$rulepath.addcslashes(pvadd($v['rulereplace']).(strpos($v['rulereplace'], '?') !== false ? '&' : '?').'$'.($pvmaxv + 1), '.?')."\n";
	$rule['{iis7}'] .= "\t\t".'&lt;rule name="'.$v['rulekey'].'"&gt;'."\n\t\t\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v['rulesearch']).'\?*(.*)$" /&gt;'."\n\t\t\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), $rulepath.addcslashes(pvadd($v['rulereplace'], 1).(strpos($v['rulereplace'], '?') !== false ? '&' : '?').'{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n\t\t".'&lt;/rule&gt;'."\n";
	$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v['rulesearch'].'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.$rulepath.pvadd($v['rulereplace']).(strpos($v['rulereplace'], '?') !== false ? '&' : '?').'$'.$pvmaxv."\nendif\n";
	$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v['rulesearch'].'$ $1/'.$rulepath.stripslashes(pvadd($v['rulereplace']))." last;\n";
	$rule['{lighttpd}'] .= '"(.*)/'.$v['rulesearch'].'\?*(.*)$" =&gt; "$1/'.$rulepath.pvadd($v['rulereplace']).'&$'.$pvmaxv.'",'."\n";
	$rule['{caddy}'] .= '@'.$v['rulekey'].' path_regexp '.$v['rulekey'].' ^(.*)/'.$v['rulesearch']."$\n".'rewrite @'.$v['rulekey'].' {re.'.$v['rulekey'].'.1}/'.$rulepath.pvadd($v['rulereplace'], array('{re.'.$v['rulekey'].'.', '}')).'&{query}'."\n";
}
$rule['{nginx}'] .= "if (!-e \$request_filename) {\n\treturn 404;\n}";
showtips(lang('plugin/'.$plugin['identifier'], 'rewrite_tip'));
echo '<br><br>';
echo str_replace(array_keys($rule),$rule,cplang('rewrite_message'));

function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$5', '$4', '$3', '$2', '$1'), array('~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('$6', '$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('{R:6}', '{R:5}', '{R:4}', '{R:3}', '{R:2}'), $s);
	}

}
//From: Dism��taobao��com
?>