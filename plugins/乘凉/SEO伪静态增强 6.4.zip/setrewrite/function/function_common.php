<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function setrewriteout($type, $returntype, $host) {
	global $_G;
	$fextra = '';
	if(empty($_G['cache']['plugin']['setrewrite'])){
		loadcache('plugin');
	}
	$setconfig = $_G['cache']['plugin']['setrewrite'];
	if(empty($_G['cache']['setrewrite_rule'])){
		loadcache('setrewrite_rule');
	}
	$rulelist = $_G['cache']['setrewrite_rule'];
	$rulesearch = $rulelist[$type]['rulesearch'];
	if($type == 'portal_index') {
		list(,,, $extra) = func_get_args();
		$r = array();
	} elseif($type == 'portal_list') {
		list(,,, $catid, $page, $extra) = func_get_args();
		$r = array(
			'{catid}' => $catid,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'guide_list') {
		list(,,, $view, $page, $extra) = func_get_args();
		$r = array(
			'{view}' => $view ? $view : 'index',
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_index') {
		list(,,, $extra) = func_get_args();
		$r = array();
	} elseif($type == 'forum_group') {
		list(,,, $gid, $extra) = func_get_args();
		$r = array(
			'{gid}' => $gid,
		);
	} elseif($type == 'forum_forumdisplay_index') {
		list(,,, $fid, $extra) = func_get_args();
		$r = array(
			'{fid}' => $fid,
		);
	} elseif($type == 'forum_viewthread_index') {
		list(,,, $tid, $extra) = func_get_args();
		$r = array(
			'{tid}' => $tid,
		);
	} elseif($type == 'forum_forumdisplay_type') {
		list(,,, $fid, $typeid, $page, $extra) = func_get_args();
		$r = array(
			'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
			'{typeid}' => $typeid,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_forumdisplay_sort') {
		list(,,, $fid, $sortid, $page, $extra) = func_get_args();
		$r = array(
			'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
			'{sortid}' => $sortid,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_forumdisplay_searchsort') {
		list(,,, $fid, $sortid, $vars, $page, $extra) = func_get_args();
		$vars = str_replace('&amp;', '&', $vars);
		parse_str($vars, $geturl);
		$varsarr = array();
		if(empty($_G['cache']['threadsort_option_'.$sortid])){
			loadcache('threadsort_option_'.$sortid);
		}
		$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
		foreach($sortoptionarray as $optionid => $option) {
			if(in_array($option['identifier'], array_keys($geturl))){
				$varsarr[] = $option['identifier'];
				$varsarr[] = $geturl[$option['identifier']];
			}
		}
		$vars = implode($setconfig['sortspace'],$varsarr);
		if(empty($vars)){
			$rulesearch = $rulelist['forum_forumdisplay_sort']['rulesearch'];
		}
		$r = array(
			'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
			'{sortid}' => $sortid,
			'{vars}' => $vars,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_forumdisplay_type_sort') {
		list(,,, $fid, $typeid, $sortid, $page, $extra) = func_get_args();
		$r = array(
			'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
			'{typeid}' => $typeid,
			'{sortid}' => $sortid,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_forumdisplay_type_searchsort') {
		list(,,, $fid, $typeid, $sortid, $vars, $page, $extra) = func_get_args();
		$vars = str_replace('&amp;', '&', $vars);
		parse_str($vars, $geturl);
		$varsarr = array();
		if(empty($_G['cache']['threadsort_option_'.$sortid])){
			loadcache('threadsort_option_'.$sortid);
		}
		$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
		foreach($sortoptionarray as $optionid => $option) {
			if(in_array($option['identifier'], array_keys($geturl))){
				$varsarr[] = $option['identifier'];
				$varsarr[] = $geturl[$option['identifier']];
			}
		}
		$vars = implode($setconfig['sortspace'],$varsarr);
		if(empty($vars)){
			$rulesearch = $rulelist['forum_forumdisplay_type_sort']['rulesearch'];
		}
		$r = array(
			'{fid}' => empty($_G['setting']['forumkeys'][$fid]) ? $fid : $_G['setting']['forumkeys'][$fid],
			'{typeid}' => $typeid,
			'{sortid}' => $sortid,
			'{vars}' => $vars,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_viewthread_author') {
		list(,,, $tid, $authorid, $page, $extra) = func_get_args();
		$r = array(
			'{tid}' => $tid,
			'{authorid}' => $authorid,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'forum_viewthread_album') {
		list(,,, $tid, $extra) = func_get_args();
		$r = array(
			'{tid}' => $tid,
		);
	} elseif($type == 'misc_tag') {
		list(,,, $id, $extra) = func_get_args();
		$r = array(
			'{id}' => $id,
		);
	} elseif($type == 'misc_tag_name') {
		list(,,, $name, $extra) = func_get_args();
		$setconfig['rewritecompatible'] && $name = rawurlencode($name);
		$r = array(
			'{name}' => $name,
		);
	} elseif($type == 'misc_tag_index') {
		list(,,, $param, $extra) = func_get_args();
		$r = array();
		if($param) {
			$fextra = '?'.$param;
		}
	} elseif($type == 'misc_tag_type') {
		list(,,, $id, $type, $page, $extra) = func_get_args();
		$r = array(
			'{id}' => $id,
			'{type}' => $type,
			'{page}' => $page ? $page : 1,
		);
	} elseif($type == 'misc_mobile') {
		list(,,, $param, $extra) = func_get_args();
		$r = array();
		if($param) {
			$fextra = '?'.$param;
		}
	} elseif($type == 'home_album') {
		list(,,, $uid, $albumid, $extra) = func_get_args();
		$r = array(
			'{uid}' => $uid,
			'{albumid}' => $albumid,
		);
	} elseif($type == 'group_type') {
		list(,,, $type, $gid, $extra) = func_get_args();
		$r = array(
			'{type}' => $type,
			'{gid}' => $gid,
		);
	} elseif($type == 'forum_collection_index') {
		list(,,, $param, $extra) = func_get_args();
		$r = array();
		if($param) {
			$fextra = '?'.$param;
		}
	}elseif($type == 'forum_collection') {
		list(,,, $ctid, $page, $param, $extra) = func_get_args();
		$r = array(
			'{ctid}' => $ctid,
			'{page}' => $page ? $page : 1,
		);
		if($param) {
			$fextra = '?'.$param;
		}
	}
	$href = str_replace(array_keys($r), $r, $rulesearch).$fextra;
	if(!$returntype) {
		return '<a href="'.$host.$href.'"'.(!empty($extra) ? ' '.trim(stripslashes($extra)) : '').'>';
	} else {
		return $host.$href;
	}
}

function rewritenextthread($goto, $tid, $returntype, $host) {
	global $_G;
	list(,,, $extra) = func_get_args();
	$href = '';
	$thread = get_thread_by_tid($tid);
	if($thread){
		$lastpost = $thread['lastpost'];

		$glue = '<';
		$sort = 'DESC';
		if($goto == 'nextnewset') {
			$glue = '>';
			$sort = 'ASC';
		}
		$next = C::t('forum_thread')->fetch_next_tid_by_fid_lastpost($thread['fid'], $lastpost, $glue, $sort, $thread['threadtableid']);
		if($next) {
			$href = rewriteoutput('forum_viewthread', 1, '', $next);
		}else{
			$href = rewriteoutput('forum_viewthread', 1, '', $thread['tid']);
		}
	}
	if(!$returntype) {
		return '<a href="'.$host.$href.'"'.(!empty($extra) ? ' '.trim(stripslashes($extra)) : '').'>';
	} else {
		return $host.$href;
	}
}
//From: dis'.'m.tao'.'bao.com
?>