<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_setrewrite {

	public static $identifier = 'setrewrite';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$this->setconfig = $setconfig;
		loadcache('setrewrite_rule');
		$rulelist = $_G['cache']['setrewrite_rule'];
		$this->rulelist = $rulelist;
		require_once libfile('function/common', 'plugin/'.self::$identifier);
    }

	function common() {
		global $_G;
		$setconfig = $this->setconfig;
		if($_G['uid'] && $setconfig['rewriteguest']){
			return '';
		}
		$request_url = $this->_get_request_url();
		if(strpos($_G['siteurl'], 'http://') === 0 && $setconfig['httpsjump']){
			header('HTTP/1.1 301 Moved Permanently');
			header("Location:https://".$_SERVER['HTTP_HOST'].$request_url);
			exit();
		}
		$rulelist = $this->rulelist;
		if($setconfig['rewriteforce'] && $request_url && strpos($request_url, '.php?') !== false){
			$rewriteurl = '';
			if($rulelist['portal_list']['rewritestatus'] && CURSCRIPT == 'portal' && CURMODULE == 'list' && $_GET['catid'] && !defined('SUB_DIR')){
				$rewriteurl = setrewriteout('portal_list', 1, '', $_GET['catid'], $_G['page']);
			}
			if($rulelist['guide_list']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'guide' && $_GET['rss'] != 1){
				$view = $_GET['view'];
				if(!in_array($view, array('hot', 'digest', 'new', 'my', 'newthread', 'sofa'))) {
					$view = 'hot';
				}
				$rewriteurl = setrewriteout('guide_list', 1, '', $view, $_G['page']);
				if($view == 'my' && !empty($_GET['type'])) {
					$rewriteurl = '';
				}
			}
			if($rulelist['forum_group']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'index' && $_G['fid']){
				$rewriteurl = setrewriteout('forum_group', 1, '', $_G['fid']);
			}
			if(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && $_G['fid']){
				$filter = trim($_GET['filter']);
				if(intval($_GET['typeid']) && intval($_GET['sortid']) && empty($_GET['formhash']) && empty($_GET['orderby'])) {
					$query_string = $_SERVER['QUERY_STRING'];
					parse_str($query_string, $geturl);
					$vars = '';
					foreach($geturl as $option => $value) {
						$vars .= $option && !in_array($option, array('filter', 'sortid', 'typeid', 'orderby', 'fid', 'searchsort', 'mod', 'page', 'dateline', 'digest')) ? '&'.$option.'='.$value : '';
					}
					if($vars){
						$vars = substr($vars, 1);
						if($rulelist['forum_forumdisplay_type_searchsort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_type_searchsort', 1, '', $_G['fid'], intval($_GET['typeid']), intval($_GET['sortid']), $vars, $_G['page']);
						}
					}else{
						if($rulelist['forum_forumdisplay_type_sort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_type_sort', 1, '', $_G['fid'], intval($_GET['typeid']), intval($_GET['sortid']), $_G['page']);
						}
					}
				}elseif(intval($_GET['typeid']) && empty($_GET['orderby'])){
					if($rulelist['forum_forumdisplay_type']['rewritestatus']){
						$rewriteurl = setrewriteout('forum_forumdisplay_type', 1, '', $_G['fid'], intval($_GET['typeid']), $_G['page']);
					}
				}elseif(intval($_GET['sortid']) && empty($_GET['formhash']) && empty($_GET['orderby'])){
					$query_string = $_SERVER['QUERY_STRING'];
					parse_str($query_string, $geturl);
					$vars = '';
					foreach($geturl as $option => $value) {
						$vars .= $option && !in_array($option, array('filter', 'sortid', 'orderby', 'fid', 'searchsort', 'mod', 'page', 'dateline', 'digest')) ? '&'.$option.'='.$value : '';
					}
					if($vars){
						$vars = substr($vars, 1);
						if($rulelist['forum_forumdisplay_searchsort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_searchsort', 1, '', $_G['fid'], intval($_GET['sortid']), $vars, $_G['page']);
						}
					}else{
						if($rulelist['forum_forumdisplay_sort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_sort', 1, '', $_G['fid'], intval($_GET['sortid']), $_G['page']);
						}
					}
				}
			}
			if($rulelist['forum_viewthread_author']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && $_G['tid']){
				$authorid = !empty($_GET['authorid']) ? intval($_GET['authorid']) : 0;
				if($authorid){
					$rewriteurl = setrewriteout('forum_viewthread_author', 1, '', $_G['tid'], $authorid, $_G['page']);
				}
			}
			if($rulelist['forum_viewthread_album']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && $_G['tid'] && $_GET['from'] == 'album'){
				$rewriteurl = setrewriteout('forum_viewthread_album', 1, '', $_G['tid']);
			}
			if($rulelist['forum_collection']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'collection' && $_GET['ctid'] && $_GET['action'] == 'view' && !$_GET['op']){
				$rewriteurl = setrewriteout('forum_collection', 1, '', $_GET['ctid'], $_G['page']);
			}
			if($rulelist['misc_mobile']['rewritestatus'] && CURSCRIPT == 'misc' && CURMODULE == 'mobile' && empty($_GET['view'])){
				$rewriteurl = setrewriteout('misc_mobile', 1, '', '');
			}
			if(CURSCRIPT == 'misc' && CURMODULE == 'tag'){
				if($_GET['name']) {
					if(empty($_POST['name']) && $rulelist['misc_tag_name']['rewritestatus']){
						$rewriteurl = setrewriteout('misc_tag_name', 1, '', $_GET['name']);
					}
				} elseif(intval($_GET['id'])) {
					$type = trim($_GET['type']);
					if($type == 'thread' || $type == 'blog') {
						if($rulelist['misc_tag_type']['rewritestatus']){
							$rewriteurl = setrewriteout('misc_tag_type', 1, '', intval($_GET['id']), $type);
						}
					} else {
						if($rulelist['misc_tag']['rewritestatus']){
							$rewriteurl = setrewriteout('misc_tag', 1, '', intval($_GET['id']));
						}
					}
				} else {
					if($rulelist['misc_tag_index']['rewritestatus']){
						$rewriteurl = setrewriteout('misc_tag_index', 1, '', $_GET['page'] ? 'page='.$_G['page'] : '', '');
					}
				}
			}
			if($rulelist['home_album']['rewritestatus'] && CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'album' && intval($_GET['uid']) && intval($_GET['id'])){
				$rewriteurl = setrewriteout('home_album', 1, '', intval($_GET['uid']), intval($_GET['id']));
			}
			if($rulelist['group_type']['rewritestatus'] && CURSCRIPT == 'group' && CURMODULE == 'index' && empty($_GET['orderby']) && empty($_G['page'])){
				$gid = intval($_GET['gid']);
				$sgid = intval($_GET['sgid']);
				if($gid) {
					$rewriteurl = setrewriteout('group_type', 1, '', 'gid', $gid);
				} elseif($sgid) {
					$rewriteurl = setrewriteout('group_type', 1, '', 'sgid', $sgid);
				}
			}
			//�Ż�����ҳα��̬
			if(in_array('portal_article', $_G['setting']['rewritestatus']) && CURSCRIPT == 'portal' && CURMODULE == 'view' && intval($_GET['aid']) && !$_GET['modarticlekey'] && !$_GET['inajax']) {
				$rewriteurl = rewriteoutput('portal_article', 1, '', $_GET['aid'], $_G['page']);
			}
			//��̳�����б�ҳα��̬
			if(in_array('forum_forumdisplay', $_G['setting']['rewritestatus']) && CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && $_G['fid'] && !$_GET['action'] && !$_GET['filter'] && !$_GET['specialtype'] && !$_GET['digest'] && !$_GET['dateline'] && !$_GET['orderby'] && !$_GET['forumdefstyle'] && !$_GET['typeid'] && !$_GET['sortid'] && !$_GET['sortall'] && !$_GET['modthreadkey'] && !$_GET['inajax']) {
				if($rulelist['forum_forumdisplay_index']['rewritestatus'] && $_G['page']==1){
					$rewriteurl = setrewriteout('forum_forumdisplay_index', 1, '', $_G['fid']);
				}else{
					$rewriteurl = rewriteoutput('forum_forumdisplay', 1, '', $_G['fid'], $_G['page']);
				}
			}
			//��̳��������ҳα��̬
			if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) && CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && $_G['tid'] && !$_GET['action'] && !$_GET['do'] && !$_GET['authorid'] && !$_GET['viewpid'] && !$_GET['ctid'] && !$_GET['ordertype'] && !$_GET['from'] && !$_GET['modthreadkey'] && !$_GET['inajax'] && !$_GET['ajaxtarget'] && strpos($request_url, '#pid') === FALSE) {
				if($rulelist['forum_viewthread_index']['rewritestatus'] && $_G['page']==1){
					$rewriteurl = setrewriteout('forum_viewthread_index', 1, '', $_G['tid']);
				}else{
					$rewriteurl = rewriteoutput('forum_viewthread', 1, '', $_G['tid'], $_G['page']);
				}
			}
			//Ⱥ�������б�ҳα��̬
			if(in_array('group_group', $_G['setting']['rewritestatus']) && CURSCRIPT == 'forum' && CURMODULE == 'group' && $_G['fid'] && !$_GET['action'] && !$_GET['inajax'] && !$_GET['ajaxtarget']) {
				$rewriteurl = rewriteoutput('group_group', 1, '', $_G['fid'], $_G['page']);
			}
			//�û�������ҳα��̬
			if(in_array('home_space', $_G['setting']['rewritestatus']) && CURSCRIPT == 'home' && $_GET['mod'] == 'space' && ($_GET['uid'] || $_GET['username']) && !$_GET['do'] && !$_GET['inajax'] && !$_GET['ajaxtarget']) {
				$rewriteurl = rewriteoutput('home_space', 1, '', $_GET['uid'], $_GET['username']);
			}
			//�û���־����ҳα��̬
			if(in_array('home_blog', $_G['setting']['rewritestatus']) && CURSCRIPT == 'home' && $_GET['mod'] == 'space' && $_GET['do'] == 'blog' && $_GET['uid'] && $_GET['id'] && !$_GET['inajax'] && !$_GET['ajaxtarget']) {
				$rewriteurl = rewriteoutput('home_blog', 1, '', $_GET['uid'], $_GET['id']);
			}
		}
		//�Ż���ҳα��̬
		if($setconfig['rewriteforce'] && $rulelist['portal_index']['rewritestatus'] && CURSCRIPT == 'portal' && $request_url == '/portal.php'){
			$rewriteurl = setrewriteout('portalindex', 1, '');
		}
		//��̳��ҳα��̬
		if($setconfig['rewriteforce'] && $rulelist['forum_index']['rewritestatus'] && CURSCRIPT == 'forum' && $request_url == '/forum.php'){
			$rewriteurl = setrewriteout('forum_index', 1, '');
		}
		//������ҳα��̬
		if($setconfig['rewriteforce'] && $rulelist['forum_collection_index']['rewritestatus'] && CURSCRIPT == 'forum' && CURMODULE == 'collection' && $request_url == '/forum.php?mod=collection'){
			$rewriteurl = setrewriteout('forum_collection_index', 1, '', $_GET['page'] ? 'page='.$_GET['page'] : '', '');
		}
		if($rewriteurl){
			header('HTTP/1.1 301 Moved Permanently');
			header("Location: ".$rewriteurl);
			exit();
		}
		return '';
    }

	function global_footer() {
		global $_G;
		$return = '';
		$setconfig = $this->setconfig;
		if($_G['uid'] && $setconfig['rewriteguest']){
			return '';
		}
		$rulelist = $this->rulelist;
		foreach($rulelist as $k => $v) {
			if(!$v['rewritestatus']){
				unset($rulelist[$k]);
			}
		}
		$defaultcurhost = empty($_G['setting']['domain']['app']['default']) ? '{CURHOST}' : $_G['setting']['domain']['app']['default'];
		$_G['domain'] = array();
		if(is_array($_G['setting']['domain']['app'])) {
			$apps = $_G['setting']['domain']['app'];
			$repflag = $apps['portal'] || $apps['forum'] || $apps['group'] || $apps['home'] || $apps['default'];
			foreach($apps as $app => $domain) {
				if(in_array($app, array('default', 'mobile'))) {
					continue;
				}
				$appphp = "{$app}.php";
				if(!$domain) {
					$domain = $defaultcurhost;
				}
				if($domain != '{CURHOST}') {
					$domain = 'http://'.$domain.$_G['siteport'].'/';
				}
				if($repflag) {
					$_G['domain']['pregxprw'][$app] = '<a([^\>]*)href\="(|'.preg_quote(str_replace('http://', 'https://', $domain), '/').'|'.preg_quote($domain, '/').')'.$appphp;
				} else {
					$_G['domain']['pregxprw'][$app] = '<a([^\>]*)href\="(|'.preg_quote($_G['siteurl'], '/').')'.$appphp;
				}
			}
		}
		if($rulelist){
			foreach($rulelist as $k => $v) {
				$_G['setting']['rewritestatus'][] = $v['rulekey'];
				if(in_array($_G['setting']['version'], array('X3', 'X3.1', 'X3.2'))){
					if($v['rulekey'] == 'portal_index') {
						$_G['setting']['output']['preg']['search']['portal_index'] = "/".$_G['domain']['pregxprw']['portal']."\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['portal_index'] = "setrewriteout('portal_index', 0, '\\2', '\\1\\3')";
					} elseif($v['rulekey'] == 'portal_list'){
						$_G['setting']['output']['preg']['search']['portal_list'] = "/".$_G['domain']['pregxprw']['portal']."\?mod\=list&(amp;)?catid\=(\d+)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['portal_list'] = "setrewriteout('portal_list', 0, '\\2', '\\4', '\\7', '\\8')";
					} elseif($v['rulekey'] == 'guide_list') {
						$_G['setting']['output']['preg']['search']['guide_list'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=guide(&(amp;)?view\=(\w+))?(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['guide_list'] = "setrewriteout('guide_list', 0, '\\2', '\\5', '\\8', '\\1\\9')";
					} elseif($v['rulekey'] == 'forum_index') {
						$_G['setting']['output']['preg']['search']['forum_index'] = "/".$_G['domain']['pregxprw']['forum']."\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_index'] = "setrewriteout('forum_index', 0, '\\2', '\\1\\3')";
					} elseif($v['rulekey'] == 'forum_group') {
						$_G['setting']['output']['preg']['search']['forum_group'] = "/".$_G['domain']['pregxprw']['forum']."\?gid\=(\d+)\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_group'] = "setrewriteout('forum_group', 0, '\\2', '\\3', '\\4')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_index') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_index'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=1)?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_index'] = "setrewriteout('forum_group', 0, '\\2', '\\4', '\\1\\7')";
					} elseif($v['rulekey'] == 'forum_viewthread_index') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_index'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?extra\=(page\%3D(\d+))?)?(&(amp;)?page\=1)?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_index'] = "setrewriteout('forum_group', 0, '\\2', '\\4', '\\1\\11')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_type') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?(&(amp;)?filter\=typeid&(amp;)?typeid\=(\d+)|(&(amp;)?typeid\=(\d+))+&(amp;)?filter\=typeid(&(amp;)?typeid\=(\d+))?)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type'] = "setrewriteout('forum_forumdisplay_type', 0, '\\2', '\\4', '\\18' ? '\\18' : '\\11', '\\21' ? '\\21' : '\\7', '\\1\\22')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_sort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_sort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?(&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)|(&(amp;)?sortid\=(\d+))+(&(amp;)?filter\=sortid)?(&(amp;)?sortid\=(\d+))?)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_sort'] = "setrewriteout('forum_forumdisplay_sort', 0, '\\2', '\\4', '\\19' ? '\\19' : ('\\14' ? '\\14' : '\\11'), '\\22' ? '\\22' : '\\7', '\\1\\23')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_searchsort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_searchsort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?sortid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)(&(amp;)?((?!typeid\=(\d+))|(?!orderby\=(\w+))[^\"])+?)(&(amp;)?page\=(\d*))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_searchsort'] = "setrewriteout('forum_forumdisplay_searchsort', 0, '\\2', '\\4', '\\10', '\\11', '\\18', '\\1\\19')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_type_sort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type_sort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?((&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+)|(&(amp;)?typeid\=(\d+)&(amp;)?sortid\=(\d+))?&(amp;)?filter\=typeid&(amp;)?typeid\=(\d+)&(amp;)?sortid\=(\d+))(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type_sort'] = "setrewriteout('forum_forumdisplay_type_sort', 0, '\\2', '\\4', '\\18' ? '\\18' : '\\26', '\\16' ? '\\16' : '\\28', '\\31' ? '\\31' : '\\7', '\\1\\32')";
					} elseif($v['rulekey'] == 'forum_forumdisplay_type_searchsort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type_searchsort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)(&(amp;)?[^\"]+?)(&(amp;)?typeid\=(\d+))(&(amp;)?page\=(\d*))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type_searchsort'] = "setrewriteout('forum_forumdisplay_type_searchsort', 0, '\\2', '\\4', '\\17', '\\12', '\\13', '\\20', '\\1\\21')";
					} elseif($v['rulekey'] == 'forum_viewthread_album') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_album'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)&(amp;)?from\=album\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_album'] = "setrewriteout('forum_viewthread_album', 0, '\\2', '\\4', '\\6')";
					} elseif($v['rulekey'] == 'misc_tag') {
						$_G['setting']['output']['preg']['search']['misc_tag'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?id\=(\d+)\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['misc_tag'] = "setrewriteout('misc_tag', 0, '\\2', '\\4', '\\1\\5')";
					} elseif($v['rulekey'] == 'misc_tag_name') {
						$_G['setting']['output']['preg']['search']['misc_tag_name'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?name\=([^&]+?)\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['misc_tag_name'] = "setrewriteout('misc_tag_name', 0, '\\2', '\\4', '\\1\\5')";
					} elseif($v['rulekey'] == 'misc_tag_index') {
						$_G['setting']['output']['preg']['search']['misc_tag_index'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag(&amp;|&)?(page\=(\d*))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['misc_tag_index'] = "setrewriteout('misc_tag_index', 0, '\\2', '\\4', '\\1\\6')";
					} elseif($v['rulekey'] == 'misc_tag_type') {
						$_G['setting']['output']['preg']['search']['misc_tag_type'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?id\=(\d+)&(amp;)?type\=(\w+)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['misc_tag_type'] = "setrewriteout('misc_tag_type', 0, '\\2', '\\4', '\\6', '\\9', '\\1\\10')";
					} elseif($v['rulekey'] == 'home_album') {
						$_G['setting']['output']['preg']['search']['home_album'] = "/".$_G['domain']['pregxprw']['home']."\?mod=space&(amp;)?uid\=(\d+)&(amp;)?do=album&(amp;)?id=(\d+)\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['home_album'] = "setrewriteout('home_album', 0, '\\2', '\\4', '\\7', '\\8')";
					} elseif($v['rulekey'] == 'group_type') {
						$_G['setting']['output']['preg']['search']['group_type'] = "/".$_G['domain']['pregxprw']['group']."\?[gid|sgid]\=(\d+)\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['group_type'] = "setrewriteout('group_type', 0, '\\2', '\\3', '\\4', '\\5')";
					} elseif($v['rulekey'] == 'misc_mobile') {
						$_G['setting']['output']['preg']['search']['misc_mobile'] = "/<a([^\>]*)href=\"()misc.php\?mod\=mobile\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['misc_mobile'] = "setrewriteout('misc_mobile', 0, '\\2', '\\1\\3')";
					} elseif($v['rulekey'] == 'forum_viewthread_author') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_author'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?extra\=)?((&(amp;)?authorid\=(\d*)&(amp;)?page\=(\d*))|(&(amp;)?page\=(\d*)&(amp;)?authorid\=(\d*)))\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_author'] = "setrewriteout('forum_viewthread_author', 0, '\\2', '\\4', '\\10' ? '\\10' : '\\17', '\\12' ? '\\12' : '\\15', '\\1\\18')";
					} elseif($v['rulekey'] == 'forum_collection_index') {
						$_G['setting']['output']['preg']['search']['forum_collection_index'] = "/<a([^\>]*)href=\"()forum.php\?mod\=collection(&amp;|&)?(page\=(\d*))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_collection_index'] = "setrewriteout('forum_collection_index', 0, '\\2', '\\4', '\\1\\6')";
					}elseif($v['rulekey'] == 'forum_collection'){
						$_G['setting']['output']['preg']['search']['forum_collection'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=collection&(amp;)?action\=view&(amp;)?ctid\=(\d+)(&(amp;)?page\=(\d+))?(&amp;|&)?(fromop\=(\w+))?\"([^\>]*)\>/e";
						$_G['setting']['output']['preg']['replace']['forum_collection'] = "setrewriteout('forum_viewthread_author', 0, '\\2', '\\5', '\\8', '\\10', '\\1\\12')";
					}
				}else{
					if($v['rulekey'] == 'portal_index') {
						$_G['setting']['output']['preg']['search']['portal_index'] = "/".$_G['domain']['pregxprw']['portal']."\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['portal_index'] = 'setrewriteout(\'portal_index\', 0, $matches[2], $matches[1].$matches[3])';
					} elseif($v['rulekey'] == 'portal_list'){
						$_G['setting']['output']['preg']['search']['portal_list'] = "/".$_G['domain']['pregxprw']['portal']."\?mod\=list&(amp;)?catid\=(\d+)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['portal_list'] = 'setrewriteout(\'portal_list\', 0, $matches[2], $matches[4], $matches[7], $matches[8])';
					} elseif($v['rulekey'] == 'guide_list') {
						$_G['setting']['output']['preg']['search']['guide_list'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=guide(&(amp;)?view\=(\w+))?(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['guide_list'] = 'setrewriteout(\'guide_list\', 0, $matches[2], $matches[5], $matches[8], $matches[1].$matches[9])';
					} elseif($v['rulekey'] == 'forum_index') {
						$_G['setting']['output']['preg']['search']['forum_index'] = "/".$_G['domain']['pregxprw']['forum']."\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_index'] = 'setrewriteout(\'forum_index\', 0, $matches[2], $matches[1].$matches[3])';
					} elseif($v['rulekey'] == 'forum_group') {
						$_G['setting']['output']['preg']['search']['forum_group'] = "/".$_G['domain']['pregxprw']['forum']."\?gid\=(\d+)\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_group'] = 'setrewriteout(\'forum_group\', 0, $matches[2], $matches[3], $matches[4])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_index') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_index'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=1)?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_index'] = 'setrewriteout(\'forum_forumdisplay_index\', 0, $matches[2], $matches[4], $matches[1].$matches[7])';
					} elseif($v['rulekey'] == 'forum_viewthread_index') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_index'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?extra\=(page\%3D(\d+))?)?(&(amp;)?page\=1)?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_index'] = 'setrewriteout(\'forum_viewthread_index\', 0, $matches[2], $matches[4], $matches[1].$matches[11])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_type') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?(&(amp;)?filter\=typeid&(amp;)?typeid\=(\d+)|(&(amp;)?typeid\=(\d+))+&(amp;)?filter\=typeid(&(amp;)?typeid\=(\d+))?)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type'] = 'setrewriteout(\'forum_forumdisplay_type\', 0, $matches[2], $matches[4], $matches[18] ? $matches[18] : $matches[11], $matches[21] ? $matches[21] : $matches[7], $matches[1].$matches[22])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_sort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_sort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?(&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)|(&(amp;)?sortid\=(\d+))+(&(amp;)?filter\=sortid)?(&(amp;)?sortid\=(\d+))?)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_sort'] = 'setrewriteout(\'forum_forumdisplay_sort\', 0, $matches[2], $matches[4], $matches[19] ? $matches[19] : ($matches[14] ? $matches[14] : $matches[11]), $matches[22] ? $matches[22] : $matches[7], $matches[1].$matches[23])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_searchsort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_searchsort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?sortid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)(&(amp;)?((?!typeid\=(\d+))|(?!orderby\=(\w+))[^\"])+?)(&(amp;)?page\=(\d*))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_searchsort'] = 'setrewriteout(\'forum_forumdisplay_searchsort\', 0, $matches[2], $matches[4], $matches[10], $matches[11], $matches[18], $matches[1].$matches[19])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_type_sort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type_sort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+))?((&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+)|(&(amp;)?typeid\=(\d+)&(amp;)?sortid\=(\d+))?&(amp;)?filter\=typeid&(amp;)?typeid\=(\d+)&(amp;)?sortid\=(\d+))(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type_sort'] = 'setrewriteout(\'forum_forumdisplay_type_sort\', 0, $matches[2], $matches[4], $matches[18] ? $matches[18] : $matches[26], $matches[16] ? $matches[16] : $matches[28], $matches[31] ? $matches[31] : $matches[7], $matches[1].$matches[32])';
					} elseif($v['rulekey'] == 'forum_forumdisplay_type_searchsort') {
						$_G['setting']['output']['preg']['search']['forum_forumdisplay_type_searchsort'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?sortid\=(\d+)&(amp;)?typeid\=(\d+))?&(amp;)?filter\=sortid&(amp;)?sortid\=(\d+)(&(amp;)?[^\"]+?)(&(amp;)?typeid\=(\d+))(&(amp;)?page\=(\d*))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_forumdisplay_type_searchsort'] = 'setrewriteout(\'forum_forumdisplay_type_searchsort\', 0, $matches[2], $matches[4], $matches[17], $matches[12], $matches[13], $matches[20], $matches[1].$matches[21])';
					} elseif($v['rulekey'] == 'forum_viewthread_album') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_album'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)&(amp;)?from\=album\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_album'] = 'setrewriteout(\'forum_viewthread_album\', 0, $matches[2], $matches[4], $matches[6])';
					} elseif($v['rulekey'] == 'misc_tag') {
						$_G['setting']['output']['preg']['search']['misc_tag'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?id\=(\d+)\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['misc_tag'] = 'setrewriteout(\'misc_tag\', 0, $matches[2], $matches[4], $matches[1].$matches[5])';
					} elseif($v['rulekey'] == 'misc_tag_name') {
						$_G['setting']['output']['preg']['search']['misc_tag_name'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?name\=([^&]+?)\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['misc_tag_name'] = 'setrewriteout(\'misc_tag_name\', 0, $matches[2], $matches[4], $matches[1].$matches[5])';
					} elseif($v['rulekey'] == 'misc_tag_index') {
						$_G['setting']['output']['preg']['search']['misc_tag_index'] = "/<a([^\>]*)href=\"()misc.php\?mod\=tag(&amp;|&)?(page\=(\d*))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['misc_tag_index'] = 'setrewriteout(\'misc_tag_index\', 0, $matches[2], $matches[4], $matches[1].$matches[6])';
					} elseif($v['rulekey'] == 'misc_tag_type') {
						$_G['setting']['output']['preg']['search']['misc_tag_type'] = 	"/<a([^\>]*)href=\"()misc.php\?mod\=tag&(amp;)?id\=(\d+)&(amp;)?type\=(\w+)(&(amp;)?page\=(\d+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['misc_tag_type'] = 'setrewriteout(\'misc_tag_type\', 0, $matches[2], $matches[4], $matches[6], $matches[9], $matches[1].$matches[10])';
					} elseif($v['rulekey'] == 'home_album') {
						$_G['setting']['output']['preg']['search']['home_album'] = "/".$_G['domain']['pregxprw']['home']."\?mod=space&(amp;)?uid\=(\d+)&(amp;)?do=album&(amp;)?id=(\d+)\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['home_album'] = 'setrewriteout(\'home_album\', 0, $matches[2], $matches[4], $matches[7], $matches[8])';
					} elseif($v['rulekey'] == 'group_type') {
						$_G['setting']['output']['preg']['search']['group_type'] = "/".$_G['domain']['pregxprw']['group']."\?(gid|sgid)\=(\d+)\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['group_type'] = 'setrewriteout(\'group_type\', 0, $matches[2], $matches[3], $matches[4], $matches[5])';
					} elseif($v['rulekey'] == 'misc_mobile') {
						$_G['setting']['output']['preg']['search']['misc_mobile'] = "/<a([^\>]*)href=\"()misc.php\?mod\=mobile\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['misc_mobile'] = 'setrewriteout(\'misc_mobile\', 0, $matches[2], $matches[1].$matches[3])';
					} elseif($v['rulekey'] == 'forum_viewthread_author') {
						$_G['setting']['output']['preg']['search']['forum_viewthread_author'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?extra\=)?((&(amp;)?authorid\=(\d*)&(amp;)?page\=(\d*))|(&(amp;)?page\=(\d*)&(amp;)?authorid\=(\d*)))\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_viewthread_author'] = 'setrewriteout(\'forum_viewthread_author\', 0, $matches[2], $matches[4], $matches[10] ? $matches[10] : $matches[17], $matches[12] ? $matches[12] : $matches[15], $matches[1].$matches[18])';
					} elseif($v['rulekey'] == 'forum_collection_index') {
						$_G['setting']['output']['preg']['search']['forum_collection_index'] = "/<a([^\>]*)href=\"()forum.php\?mod\=collection(&amp;|&)?(page\=(\d*))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_collection_index'] = 'setrewriteout(\'forum_collection_index\', 0, $matches[2], $matches[4], $matches[1].$matches[6])';
					}elseif($v['rulekey'] == 'forum_collection'){
						$_G['setting']['output']['preg']['search']['forum_collection'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=collection&(amp;)?action\=view&(amp;)?ctid\=(\d+)(&(amp;)?page\=(\d+))?(&amp;|&)?(fromop\=(\w+))?\"([^\>]*)\>/";
						$_G['setting']['output']['preg']['replace']['forum_collection'] = 'setrewriteout(\'forum_collection\', 0, $matches[2], $matches[5], $matches[8], $matches[10], $matches[1].$matches[12])';
					}
				}
			}
		}
		//��ϵͳ�Դ�����б�ҳα��̬��������
		if(in_array('forum_forumdisplay', $_G['setting']['rewritestatus'])) {
			$searchrule = $_G['setting']['output']['preg']['search']['forum_forumdisplay'];
			$replacerule = $_G['setting']['output']['preg']['replace']['forum_forumdisplay'];
			unset($_G['setting']['output']['preg']['search']['forum_forumdisplay']);
			unset($_G['setting']['output']['preg']['replace']['forum_forumdisplay']);
			$_G['setting']['output']['preg']['search']['forum_forumdisplay'] = $searchrule;
			$_G['setting']['output']['preg']['replace']['forum_forumdisplay'] = $replacerule;
		}
		//��ϵͳ�Դ���������ҳα��̬��������
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$searchrule = $_G['setting']['output']['preg']['search']['forum_viewthread'];
			$replacerule = $_G['setting']['output']['preg']['replace']['forum_viewthread'];
			unset($_G['setting']['output']['preg']['search']['forum_viewthread']);
			unset($_G['setting']['output']['preg']['replace']['forum_viewthread']);
			$_G['setting']['output']['preg']['search']['forum_viewthread'] = $searchrule;
			$_G['setting']['output']['preg']['replace']['forum_viewthread'] = $replacerule;
		}
		//$setconfig['rewritesearch'] = 1;
		if($setconfig['rewritesearch'] && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$_G['setting']['rewritestatus'][] = 'forum_viewthread_search';
			if(in_array($_G['setting']['version'], array('X3', 'X3.1', 'X3.2'))){
				$_G['setting']['output']['preg']['search']['forum_viewthread_search'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?highlight\=([^&]+?))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_search'] = "rewriteoutput('forum_viewthread', 0, '\\2', '\\4', 1, 1, '\\1\\8')";
			}else{
				$_G['setting']['output']['preg']['search']['forum_viewthread_search'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&(amp;)?highlight\=([^&]+?))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_search'] = 'rewriteoutput(\'forum_viewthread\', 0, $matches[2], $matches[4], 1, 1, $matches[1].$matches[8])';
			}
		}
		//$setconfig['rewriteforumtype'] = 1;
		if($setconfig['rewriteforumtype'] && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$_G['setting']['rewritestatus'][] = 'forum_viewthread_forumtype';
			if(in_array($_G['setting']['version'], array('X3', 'X3.1', 'X3.2'))){
				$_G['setting']['output']['preg']['search']['forum_viewthread_forumtype'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?\%26filter\%3D(typeid|sortid)(\%26typeid\%3D(\d+)|\%26sortid\%3D(\d+)|\%26typeid\%3D(\d+)\%26sortid\%3D(\d+)|\%26sortid\%3D(\d+)\%26typeid\%3D(\d+))+(&amp;page\=(\d+))?\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_forumtype'] = "rewriteoutput('forum_viewthread', 0, '\\2', '\\4', '\\17', '\\7', '\\1\\18')";
			}else{
				$_G['setting']['output']['preg']['search']['forum_viewthread_forumtype'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?\%26filter\%3D(typeid|sortid)(\%26typeid\%3D(\d+)|\%26sortid\%3D(\d+)|\%26typeid\%3D(\d+)\%26sortid\%3D(\d+)|\%26sortid\%3D(\d+)\%26typeid\%3D(\d+))+(&amp;page\=(\d+))?\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_forumtype'] = 'rewriteoutput(\'forum_viewthread\', 0, $matches[2], $matches[4], $matches[17], $matches[7], $matches[1].$matches[18])';
			}
		}
		//$setconfig['rewritenextthread'] = 1;
		if($setconfig['rewritenextthread'] && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$_G['setting']['rewritestatus'][] = 'forum_viewthread_nextset';
			if(in_array($_G['setting']['version'], array('X3', 'X3.1', 'X3.2'))){
				$_G['setting']['output']['preg']['search']['forum_viewthread_nextset'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=redirect&(amp;)?goto\=(nextoldset|nextnewset)&(amp;)?tid\=(\d+)\"([^\>]*)\>/e";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_nextset'] = "rewritenextthread('\\4', '\\6', 0, '\\2', '\\1\\7')";
			}else{
				$_G['setting']['output']['preg']['search']['forum_viewthread_nextset'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=redirect&(amp;)?goto\=(nextoldset|nextnewset)&(amp;)?tid\=(\d+)\"([^\>]*)\>/";
				$_G['setting']['output']['preg']['replace']['forum_viewthread_nextset'] = 'rewritenextthread($matches[4], $matches[6], 0, $matches[2], $matches[1].$matches[7])';
			}
		}
		//ǿ���������
		if(in_array('forum_forumdisplay', $_G['setting']['rewritestatus'])) {
			if(in_array($_G['setting']['version'], array('X3', 'X3.1', 'X3.2'))){
				//$_G['setting']['output']['preg']['search']['forum_forumdisplay'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+)?)?\"([^\>]*)\>/e";
				//$_G['setting']['output']['preg']['replace']['forum_forumdisplay'] = "rewriteoutput('forum_forumdisplay', 0, '\\2', '\\4', '\\7', '\\1\\8')";
			}else{
				//$_G['setting']['output']['preg']['search']['forum_forumdisplay'] = "/".$_G['domain']['pregxprw']['forum']."\?mod\=forumdisplay&(amp;)?fid\=(\w+)(&(amp;)?page\=(\d+)?)?\"([^\>]*)\>/";
				//$_G['setting']['output']['preg']['replace']['forum_forumdisplay'] = 'rewriteoutput(\'forum_forumdisplay\', 0, $matches[2], $matches[4], $matches[7], $matches[1].$matches[8])';
			}
		}
		return $return;
	}

	function _get_request_url() {
		if (isset($_SERVER['HTTP_X_ORIGINAL_URL'])) {
			$request_url = $_SERVER['HTTP_X_ORIGINAL_URL'];
		} elseif (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
			$request_url = $_SERVER['HTTP_X_REWRITE_URL'];
		} elseif (isset($_SERVER['REQUEST_URI'])) {
			$request_url = $_SERVER['REQUEST_URI'];
		} elseif (isset($_SERVER['REDIRECT_URL'])) {
			$request_url = $_SERVER['REDIRECT_URL'];
			if (isset($_SERVER['REDIRECT_QUERY_STRIN'])) {
				$request_url .= '?' . $_SERVER['REDIRECT_QUERY_STRIN'];
			}
		} else {
			$request_url = $_SERVER['PHP_SELF'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '');
		}
		return $request_url;
    }

}

class plugin_setrewrite_forum extends plugin_setrewrite {

	function forumdisplay() {
		global $_G;
		$setconfig = $this->setconfig;
		$rewritevars = $_GET['rewritevars'];
		if($rewritevars && strpos($rewritevars, $setconfig['sortspace']) !== false){
			$typeid = $_GET['typeid'];
			$page = $_GET['page'];
			$sortoptionvars = array();
			$rewritevars = explode($setconfig['sortspace'], $rewritevars);
			for($i=0; $i<count($rewritevars); $i++){
				if(($i+1) % 2 != 0){
					$_GET[$rewritevars[$i]] = isset($rewritevars[$i+1]) && $rewritevars[$i+1] ? $rewritevars[$i+1] : 'all';
					$sortoptionvars[] = $rewritevars[$i];
				}
			}

			$sortid = intval($_GET['sortid']);
			if(empty($_G['cache']['threadsort_option_'.$sortid])){
				loadcache('threadsort_option_'.$sortid);
			}
			$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
			$varsarr = array();
			foreach($sortoptionarray as $optionid => $option) {
				if(in_array($option['identifier'], $sortoptionvars)){
					$varsarr[] = $option['identifier'].'='.$_GET[$option['identifier']];
				}
			}
			if(count($sortoptionvars) != count($varsarr)){
				$rulelist = $this->rulelist;
				$vars = implode('&',$varsarr);
				if(intval($_GET['typeid'])) {
					if($vars){
						if($rulelist['forum_forumdisplay_type_searchsort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_type_searchsort', 1, '', $_G['fid'], intval($_GET['typeid']), intval($_GET['sortid']), $vars, $_G['page']);
						}
					}else{
						if($rulelist['forum_forumdisplay_type_sort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_type_sort', 1, '', $_G['fid'], intval($_GET['typeid']), intval($_GET['sortid']), $_G['page']);
						}
					}
				}else{
					if($vars){
						if($rulelist['forum_forumdisplay_searchsort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_searchsort', 1, '', $_G['fid'], intval($_GET['sortid']), $vars, $_G['page']);
						}
					}else{
						if($rulelist['forum_forumdisplay_sort']['rewritestatus']){
							$rewriteurl = setrewriteout('forum_forumdisplay_sort', 1, '', $_G['fid'], intval($_GET['sortid']), $_G['page']);
						}
					}
				}
			}
			if($rewriteurl){
				header('HTTP/1.1 301 Moved Permanently');
				header("Location: ".$rewriteurl);
				exit();
			}

			unset($_GET['rewritevars']);
			if(isset($_GET['typeid'])){
				unset($_GET['typeid']);
				$_GET['typeid'] = $typeid;
			}
			if(isset($_GET['page'])){
				unset($_GET['page']);
				$_GET['page'] = $page;
			}
			$_SERVER['QUERY_STRING'] = '';
			foreach($_GET as $key => $value){
				$_SERVER['QUERY_STRING'] .= '&'.$key.'='.$value;
			}
			$_SERVER['QUERY_STRING'] = substr($_SERVER['QUERY_STRING'], 1);
		}
	}

	function redirect() {
		global $_G;
		$setconfig = $this->setconfig;
		if($setconfig['rewritenextthread'] && ($_GET['goto'] == 'nextnewset' || $_GET['goto'] == 'nextoldset')) {

			$lastpost = $_G['thread']['lastpost'];

			$glue = '<';
			$sort = 'DESC';
			if($_GET['goto'] == 'nextnewset') {
				$glue = '>';
				$sort = 'ASC';
			}
			$next = C::t('forum_thread')->fetch_next_tid_by_fid_lastpost($_G['fid'], $lastpost, $glue, $sort, $_G['thread']['threadtableid']);
			if($next) {
				$nexturl = "forum.php?mod=viewthread&tid=$next";
				if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) && (empty($_G['setting']['rewriteguest']) || empty($_G['uid']))) {
					$nexturl = rewriteoutput('forum_viewthread', 1, '', $next);
				}
				header('HTTP/1.1 301 Moved Permanently');
				dheader("Location: ".$nexturl);
			} elseif($_GET['goto'] == 'nextnewset') {
				showmessage('redirect_nextnewset_nonexistence');
			} else {
				showmessage('redirect_nextoldset_nonexistence');
			}
			exit();
		}
	}
}

class plugin_setrewrite_group extends plugin_setrewrite {

	function redirect() {
		global $_G;
		$setconfig = $this->setconfig;
		if($setconfig['rewritenextthread'] && ($_GET['goto'] == 'nextnewset' || $_GET['goto'] == 'nextoldset')) {

			$lastpost = $_G['thread']['lastpost'];

			$glue = '<';
			$sort = 'DESC';
			if($_GET['goto'] == 'nextnewset') {
				$glue = '>';
				$sort = 'ASC';
			}
			$next = C::t('forum_thread')->fetch_next_tid_by_fid_lastpost($_G['fid'], $lastpost, $glue, $sort, $_G['thread']['threadtableid']);
			if($next) {
				$nexturl = "forum.php?mod=viewthread&tid=$next";
				if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) && (empty($_G['setting']['rewriteguest']) || empty($_G['uid']))) {
					$nexturl = rewriteoutput('forum_viewthread', 1, '', $next);
				}
				header("HTTP/1.1 301 Moved Permanently");
				dheader("Location: ".$nexturl);
			} elseif($_GET['goto'] == 'nextnewset') {
				showmessage('redirect_nextnewset_nonexistence');
			} else {
				showmessage('redirect_nextoldset_nonexistence');
			}
			exit();
		}
	}
}
//From: Dism��taobao��com
?>