<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_hidemobile {

	public static $identifier = 'hidemobile';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['hide_usergroups'] = (array)unserialize($setconfig['hide_usergroups']);
		if(in_array('', $setconfig['hide_usergroups'])) {
			$setconfig['hide_usergroups'] = array();
		}
		$setconfig['hide_forums'] = (array)unserialize($setconfig['hide_forums']);
		if(in_array('', $setconfig['hide_forums'])) {
			$setconfig['hide_forums'] = array();
		}
		$regexp = '/(\<\!--(.*?)--\>)+/is';
		if($setconfig['tip_text']) {
			$contents = preg_split($regexp, $setconfig['tip_text'], 2);
			if(count($contents) > 1){
				$setconfig['tip_text'] = $contents[1];
			}
		}
		if($setconfig['tail_text']) {
			$contents = preg_split($regexp, $setconfig['tail_text'], 2);
			if(count($contents) > 1){
				$setconfig['tail_text'] = $contents[1];
			}
		}
		if($setconfig['show_text']) {
			$contents = preg_split($regexp, $setconfig['show_text'], 2);
			if(count($contents) > 1){
				$setconfig['show_text'] = $contents[1];
			}
		}
		$setconfig['show_text'] = str_replace(array('{bbname}', '{siteurl}'), array($_G['setting']['bbname'], $_G['siteurl']), $setconfig['show_text']);
		$this->setconfig = $setconfig;
    }

	function _hide_mobile($matches) {
		global $_G;
		$setconfig = $this->setconfig;
		$mobile = str_replace(" ",'',$matches[0]);
		if(!$setconfig['hide_type']){
			$mobile = $setconfig['hide_replace'];
		}elseif($setconfig['hide_type'] == 1){
			$mobile = '***********';
		}elseif($setconfig['hide_type'] == 2){
			$mobile = preg_replace('/(1[345789]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$mobile);
		}elseif($setconfig['hide_type'] == 3){
			$mobile = preg_replace('/(1[345789]{1}[0-9])([0-9]{4})[0-9]{4}/i','$1$2****',$mobile);
		}elseif($setconfig['hide_type'] == 4){
			$mobile = preg_replace('/(1[345789]{1}[0-9])([0-9]{8})/i','$1********',$mobile);
		}
		return $mobile.$setconfig['tail_text'];
	}

	function _show_mobile($matches) {
		global $_G;
		$setconfig = $this->setconfig;
		$mobile = str_replace(" ",'',$matches[0]);
		return $mobile.$setconfig['show_text'];
	}
}

class mobileplugin_hidemobile_forum extends mobileplugin_hidemobile {
	
	function viewthread_posttop_mobile_output() {
		global $_G,$postlist, $threadsort, $threadsortshow;
		$setconfig = $this->setconfig;
		if((!$setconfig['hide_forums'] || in_array($_G['fid'], $setconfig['hide_forums']))){

			$rule = "/1\s*[345789]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]/is";

			foreach($postlist as $key => $post) {
				if($post['authorid'] != $_G['uid'] && (!$setconfig['hide_usergroups'] || in_array($_G['groupid'], $setconfig['hide_usergroups'])) && $post['dbdateline'] < TIMESTAMP - $setconfig['after_days'] * 24 * 3600){
					if($setconfig['tip_text'] && preg_match($rule, $post['message'])){
						include template(self::$identifier.':viewthread');
					}else{
						$return = '';
					}
					$post['message'] = $return.preg_replace_callback($rule, array(__CLASS__, '_hide_mobile'), $post['message']);
					$postlist[$key] = $post;
				}else{
					$post['message'] = preg_replace_callback($rule, array(__CLASS__, '_show_mobile'), $post['message']);
					$postlist[$key] = $post;
				}
			}
		}
		return array();
	}


}

class mobileplugin_hidemobile_group extends mobileplugin_hidemobile {

	function viewthread_posttop_mobile_output() {
		global $_G,$postlist, $threadsort, $threadsortshow;
		$setconfig = $this->setconfig;
		$t = array();
		if((!$setconfig['hide_groups'] || $this->_allow_groups($_G['forum'], $setconfig['hide_groups']))){

			$rule = "/1\s*[345789]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]\s*[0-9]/is";

			foreach($postlist as $key => $post) {
				if($post['authorid'] != $_G['uid'] && (!$setconfig['hide_usergroups'] || in_array($_G['groupid'], $setconfig['hide_usergroups'])) && $post['dbdateline'] < TIMESTAMP - $setconfig['after_days'] * 24 * 3600){
					if($setconfig['tip_text'] && preg_match($rule, $post['message'])){
						include template(self::$identifier.':viewthread');
						$t[] = $return;
					}else{
						$t[] = '';
					}
					$post['message'] = preg_replace_callback($rule, array(__CLASS__, '_hide_mobile'), $post['message']);
					$postlist[$key] = $post;
				}else{
					$post['message'] = preg_replace_callback($rule, array(__CLASS__, '_show_mobile'), $post['message']);
					$postlist[$key] = $post;
				}
			}
		}
		return $t;
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}

}

//From: dis'.'m.tao'.'bao.com
?>