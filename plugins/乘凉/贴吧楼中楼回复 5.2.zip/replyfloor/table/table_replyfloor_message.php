<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_replyfloor_message extends discuz_table {

	public function __construct() {
		$this->_table = 'plugin_replyfloor_message';
		$this->_pk = 'id';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function count_by_search_where($wherearr) {
		$wheresql = empty($wherearr) ? '' : implode(' AND ', $wherearr);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->_table).($wheresql ? ' WHERE '.$wheresql : ''));
	}

	public function fetch_all_by_search_where($wherearr, $ordersql = '', $start = 0, $limit = 0) {
		$wheresql = empty($wherearr) ? '' : implode(' AND ', $wherearr);
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).($wheresql ? ' WHERE '.$wheresql : '').' '.$ordersql.DB::limit($start, $limit), null, 'id');
	}

	public function fetch_by_id($id) {
		return DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
	}

	public function fetch_by_ids($ids) {
		if(($ids = dintval((array)$ids, true))) {
			return DB::fetch_all('SELECT * FROM %t WHERE id IN(%n)', array($this->_table, $ids), false, true);
		}
	}

	public function fetch_message_by_pid($pids, $perpage, $ordersql = '', $setconfig = array()) {
		global $_G;
		$date_convert = $_G['setting']['dateconvert'];
		$_G['setting']['dateconvert'] = $setconfig['date_convert'];
		$query = DB::query("SELECT * FROM ".DB::table($this->_table)." WHERE status=0 and pid IN (".dimplode($pids).') '.$ordersql);
		$messageinfo = $messagecount = $messagelist = array();
		require_once libfile('function/common', 'plugin/replyfloor');
		while($message = DB::fetch($query)) {
			$messagecount[$message['pid']]++;
			if(count($messagelist[$message['pid']]) < $perpage) {
				$message['avatar'] = avatar($message['uid'], 'small');
				$message['message'] = reply_discuzcode($message['message']);
				$message['createtime'] = dgmdate($message['createtime'], 'u');
				$messagelist[$message['pid']][] = $message;
			}
			$messageinfo[$message['pid']]['count'] = $messagecount[$message['pid']];
			$messageinfo[$message['pid']]['list'] = $messagelist[$message['pid']];
		}
		$_G['setting']['dateconvert'] = $date_convert;
		return $messageinfo;
	}

	public function update_by_id($id, $data) {
		if(($id = dintval($id, true)) && $data && is_array($data)) {
			DB::update($this->_table, $data, DB::field($this->_pk, $id), true);
		}
	}

	public function restore_by_id($ids) {
		if(($ids = dintval((array)$ids, true))) {
			DB::update($this->_table, array('status'=>0), DB::field('id', $ids, 'in'), true);
		}
	}

	public function delete_by_id($ids, $recycle = 0) {
		if(($ids = dintval((array)$ids, true))) {
			if($recycle) {
				DB::update($this->_table, array('status'=>1), DB::field('id', $ids, 'in'), true);
			}else{
				DB::query('DELETE FROM %t WHERE id IN(%n)', array($this->_table, $ids), false, true);
			}
		}
	}

	public function delete_by_pid($ids, $recycle = 0) {
		if(($ids = dintval((array)$ids, true))) {
			if($recycle) {
				DB::update($this->_table, array('status'=>1), DB::field('pid', $ids, 'in'), true);
			}else{
				DB::query('DELETE FROM %t WHERE pid IN(%n)', array($this->_table, $ids), false, true);
			}
		}
	}

	public function delete_by_tid($ids, $recycle = 0) {
		if(($ids = dintval((array)$ids, true))) {
			if($recycle) {
				DB::update($this->_table, array('status'=>1), DB::field('tid', $ids, 'in'), true);
			}else{
				DB::query('DELETE FROM %t WHERE tid IN(%n)', array($this->_table, $ids), false, true);
			}
		}
	}

	public function delete_by_authorid($ids, $recycle = 0) {
		if(($ids = dintval((array)$ids, true))) {
			if($recycle) {
				DB::update($this->_table, array('status'=>1), DB::field('uid', $ids, 'in'), true);
			}else{
				DB::query('DELETE FROM %t WHERE uid IN(%n)', array($this->_table, $ids), false, true);
			}
		}
	}

}