<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/common', 'plugin/replyfloor');

$setconfig = $_G['cache']['plugin'][CURMODULE];

$ac = in_array($_GET['ac'], array('index', 'post', 'delete')) ? $_GET['ac'] : 'index';

require_once libfile('function/forum');

loadforum();
$thread = $_G['thread'];
if(!$thread || $thread['displayorder'] < 0) {
	showmessage('thread_nonexistence');
}
$post = C::t('forum_post')->fetch('tid:'.$_G['tid'], $_GET['pid']);
if(!$post['tid']) {
	showmessage(lang('plugin/'.CURMODULE, 'replyfloor_post_nonexistence'));
}
if($post['tid'] != $_G['tid']) {
	showmessage(lang('plugin/'.CURMODULE, 'replyfloor_post_error'));
}

if($ac == 'index') {
	$_G['setting']['dateconvert'] = $setconfig['date_convert'];
	$msgid = intval($_GET['msgid']);
	if($msgid) {
		$msginfo = C::t('#'.CURMODULE.'#replyfloor_message')->fetch_by_id($msgid);
		if(!$msginfo) {
			showmessage(lang('plugin/'.CURMODULE, 'message_nonexistence'));
		}
		$msginfo['message'] = reply_discuzcode($msginfo['message']);
		$msginfo['createtime'] = dgmdate($msginfo['createtime'], 'u');
	}else{
		$page = max(1, $_G['page']);
		if(defined('IN_MOBILE')) {
			$setconfig['shownum_mobile'] = $setconfig['shownum_mobile'] > 0 ? $setconfig['shownum_mobile'] : 5;
			$perpage = $setconfig['perpage_mobile'] > 0 ? $setconfig['perpage_mobile'] : 10;
		}else{
			$setconfig['shownum_pc'] = $setconfig['shownum_pc'] > 0 ? $setconfig['shownum_pc'] : 5;
			$perpage = $setconfig['perpage_pc'] > 0 ? $setconfig['perpage_pc'] : 10;
		}
		$start = ($page-1)*$perpage;
		$mpurl = 'plugin.php?id='.CURMODULE.':index&tid='.$post['tid'].'&pid='.$post['pid'];
		$wherearr = array();
		$wherearr[] = "status = '0'";
		$wherearr[] = "pid = '".$post['pid']."'";
		$count = C::t('#'.CURMODULE.'#replyfloor_message')->count_by_search_where($wherearr);
		$orderby = 'order by createtime desc';
		if($setconfig['order_type'] == 2){
			$orderby = 'order by createtime asc';
		}
		$list = C::t('#'.CURMODULE.'#replyfloor_message')->fetch_all_by_search_where($wherearr, $orderby, $start, $perpage);
		foreach ($list as $key => $value) {
			$value['message'] = reply_discuzcode($value['message']);
			$value['createtime'] = dgmdate($value['createtime'], 'u');
			$list[$key] = $value;
		}
		if(defined('IN_MOBILE')) {
			$multipage = multi($count, $perpage, $page, $mpurl, 0, 3, false, true);
		}else{
			$multipage = multi($count, $perpage, $page, $mpurl);
		}
	}
	include template(CURMODULE.':message');

} elseif($ac == 'post') {
	if(empty($_G['uid'])) {
		showmessage('to_login', '', array(), array('showmsg' => true));
	}
	//���ֻظ���ϰ��
	cknewuser();

	require_once libfile('function/post');
	require_once libfile('function/forumlist');
	$allowpostreply = ($_G['forum']['allowreply'] != -1) && (($_G['forum_thread']['isgroup'] || (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']))) || $_G['forum']['ismoderator']) && ((!$_G['forum']['replyperm'] && $_G['group']['allowreply']) || ($_G['forum']['replyperm'] && forumperm($_G['forum']['replyperm'])) || $_G['forum']['allowreply']);
	if(!$allowpostreply) {
		showmessage(lang('plugin/'.CURMODULE, 'replyfloor_no_permission_to_post'));
	}

	$ruid = 0;
	$rusername = '';
	$_GET['msgid'] = intval($_GET['msgid']);
	if($_GET['msgid']) {
		$remsg = C::t('#'.CURMODULE.'#replyfloor_message')->fetch_by_id($_GET['msgid']);
		if($remsg) {
			$ruid = $remsg['uid'];
			$rusername = $remsg['username'];
		}
	}
	if(submitcheck('savesubmit')) {
		$message = isset($_GET['message']) ? censor($_GET['message']) : '';
		if(empty($message)) {
			showmessage(lang('plugin/'.CURMODULE, 'message_message_empty'));
		}
		//$message = messagecutstr($message, 200, '');
		if(strlen($message) < $setconfig['message_minsize']) {
			showmessage(lang('plugin/'.CURMODULE, 'message_message_tooshort'), '', array('message_minsize' => $setconfig['message_minsize']));
		}
		if(strlen($message) > $setconfig['message_maxsize']) {
			showmessage(lang('plugin/'.CURMODULE, 'message_message_toolong'), '', array('message_minsize' => $setconfig['message_maxsize']));
		}
		//���η���ʱ����
		if(checkflood()) {
			showmessage('post_flood_ctrl', '', array('floodctrl' => $_G['setting']['floodctrl']));
		}
		$data = array(
			'tid' => $post['tid'],
			'pid' => $post['pid'],
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'ruid' => $ruid,
			'rusername' => $rusername,
			'message' => $message,
			'mobile' => defined('IN_MOBILE') ? IN_MOBILE : 0,
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		$msgid = C::t('#'.CURMODULE.'#replyfloor_message')->insert($data, true);
		if($setconfig['get_credit']) {
			updatepostcredits('+', $_G['uid'], 'reply', $_G['fid']);
		}
		if($setconfig['thread_bump']) {
			$expiration = $_G['timestamp'];
			C::t('forum_thread')->update($thread['tid'], array('lastpost'=>$expiration), true);
			C::t('forum_forum')->update($_G['fid'], array('lastpost' => "$thread[tid]\t$thread[subject]\t$expiration\t$thread[lastposter]"));

			$_G['forum']['threadcaches'] && deletethreadcaches($thread['tid']);
		}
		if($setconfig['notice_author'] == 1 || ($setconfig['notice_author'] == 2 && $_GET['notice_author'])) {
			$nauthorid = $ruid ? $ruid : $post['authorid'];
			if($nauthorid != $_G['uid']){
				notification_add($nauthorid, 'post', 'replyfloor:replyfloor_noticeauthor', array(
					'tid' => $thread['tid'],
					'subject' => $thread['subject'],
					'fid' => $_G['fid'],
					'pid' => $post['pid'],
					'from_id' => $post['tid'],
					'from_idtype' => 'post',
				));
			}
		}

		//�������ӻظ���
		//C::t('forum_thread')->increase($_G['tid'], array('replies' => 1));
		//���°��������
		//C::t('forum_forum')->update_forum_counter($_G['fid'], 0, 1);
		//���½���������
		if($setconfig['today_posts']) {
			C::t('forum_forum')->update_forum_counter($_G['fid'], 0, 0, 1);
		}

		showmessage('', dreferer(), array('tid' => $post['tid'], 'pid' => $post['pid'], 'msgid' => $msgid));
	} else {
		include template(CURMODULE.':post');
	}
} elseif($ac == 'delete') {
	if(empty($_G['uid'])) {
		showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
	}
	$msgid = intval($_GET['msgid']);
	if(!$msgid) {
		showmessage(lang('plugin/'.CURMODULE, 'message_nonexistence'));
	}
	$msginfo = C::t('#'.CURMODULE.'#replyfloor_message')->fetch_by_id($msgid);
	if(!$msginfo) {
		showmessage(lang('plugin/'.CURMODULE, 'message_nonexistence'));
	}
	if(!($_G['forum']['ismoderator'] && $_G['group']['allowdelpost']) && !($setconfig['allow_delete'] && $_G['uid'] && $_G['uid'] == $_G['thread']['authorid']) && !($setconfig['self_delete'] && $_G['uid'] && $_G['uid'] == $msginfo['uid'])){
		showmessage(lang('plugin/'.CURMODULE, 'replyfloor_no_permission'));
	}
	require_once libfile('function/misc');
	if(submitcheck('modsubmit')) {
		if($setconfig['get_credit']) {
			require_once libfile('function/post');
			updatepostcredits('-', $msginfo['uid'], 'reply', $_G['fid']);
		}
		C::t('#'.CURMODULE.'#replyfloor_message')->delete_by_id(array($msgid), $setconfig['open_recycle']);
		$wherearr = array();
		$wherearr[] = "status = '0'";
		$wherearr[] = "pid = '".$post['pid']."'";
		$count = C::t('#'.CURMODULE.'#replyfloor_message')->count_by_search_where($wherearr);
		showmessage('', dreferer(), array('tid' => $post['tid'], 'pid' => $post['pid'], 'count' => $count));
	} else {
		include template(CURMODULE.':delete');
	}
}
