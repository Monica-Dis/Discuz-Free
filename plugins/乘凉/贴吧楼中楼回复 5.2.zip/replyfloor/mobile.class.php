<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_replyfloor {

	public static $identifier = 'replyfloor';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
		if(in_array('', $setconfig['allow_forums'])) {
			$setconfig['allow_forums'] = array();
		}
		$setconfig['allow_groups'] = $setconfig['allow_groups'] ? explode(",", $setconfig['allow_groups']) : array();
		$setconfig['perpage_mobile'] = $setconfig['perpage_mobile'] > 0 ? $setconfig['perpage_mobile'] : 10;
		$this->setconfig = $setconfig;
    }

	function deletethread($value) {
		global $_G;
		$setconfig = $this->setconfig;
		if($value['step'] == 'delete'){
			list($tids, $membercount, $credit, $ponly) = $value['param'];
			if($setconfig['get_credit']) {
				require_once libfile('function/post');
				require_once libfile('function_forum', 'function');
				$wherearr = array();
				$wherearr[] = 'tid in ('.dimplode($tids).')';
				$wherearr[] = "status = '0'";
				$recordlist = DB::fetch_all('SELECT * FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : ''));
				foreach ($recordlist as $value) {
					$thread = get_thread_by_tid($value['tid']);
					updatepostcredits('-', $value['uid'], 'reply', $thread['fid']);
				}
			}
			C::t('#'.self::$identifier.'#replyfloor_message')->delete_by_tid($tids, $setconfig['open_recycle']);
		}
    }

	function deletepost($value) {
		global $_G;
		$setconfig = $this->setconfig;
		if($value['step'] == 'delete'){
			list($ids, $idtype, $credit, $posttableid, $recycle) = $value['param'];
			if($idtype == 'pid') {
				if($setconfig['get_credit']) {
					require_once libfile('function/post');
					require_once libfile('function_forum', 'function');
					$wherearr = array();
					$wherearr[] = 'pid in ('.dimplode($ids).')';
					$wherearr[] = "status = '0'";
					$recordlist = DB::fetch_all('SELECT * FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : ''));
					foreach ($recordlist as $value) {
						$thread = get_thread_by_tid($value['tid']);
						updatepostcredits('-', $value['uid'], 'reply', $thread['fid']);
					}
				}
				C::t('#'.self::$identifier.'#replyfloor_message')->delete_by_pid($ids, $setconfig['open_recycle']);
			} elseif($idtype == 'tid') {
				if($setconfig['get_credit']) {
					require_once libfile('function/post');
					require_once libfile('function_forum', 'function');
					$wherearr = array();
					$wherearr[] = 'tid in ('.dimplode($ids).')';
					$wherearr[] = "status = '0'";
					$recordlist = DB::fetch_all('SELECT * FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : ''));
					foreach ($recordlist as $value) {
						$thread = get_thread_by_tid($value['tid']);
						updatepostcredits('-', $value['uid'], 'reply', $thread['fid']);
					}
				}
				C::t('#'.self::$identifier.'#replyfloor_message')->delete_by_tid($ids, $setconfig['open_recycle']);
			} elseif($idtype == 'authorid') {
				if($setconfig['get_credit']) {
					require_once libfile('function/post');
					require_once libfile('function_forum', 'function');
					$wherearr = array();
					$wherearr[] = 'uid in ('.dimplode($ids).')';
					$wherearr[] = "status = '0'";
					$recordlist = DB::fetch_all('SELECT * FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : ''));
					foreach ($recordlist as $value) {
						$thread = get_thread_by_tid($value['tid']);
						updatepostcredits('-', $value['uid'], 'reply', $thread['fid']);
					}
				}
				C::t('#'.self::$identifier.'#replyfloor_message')->delete_by_authorid($ids, $setconfig['open_recycle']);
			}
		}
    }
}

class mobileplugin_replyfloor_forum extends mobileplugin_replyfloor {

	function forumdisplay_thread_mobile_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['add_replies']){
			$tids = array();
			foreach ($_G['forum_threadlist'] as $key => $value) {
				$tids[] = $value['tid'];
			}
			$wherearr = array();
			$wherearr[] = 'tid in ('.dimplode($tids).')';
			$wherearr[] = "status = '0'";
			$recordlist = DB::fetch_all('SELECT tid,count(*) as count FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : '').' group by tid');
			$count = array();
			foreach ($recordlist as $value) {
				$count[$value['tid']] = $value['count'];
			}
			foreach ($_G['forum_threadlist'] as &$thread) {
				if($count[$thread['tid']]){
					$thread['allreplies'] += $count[$thread['tid']];
					$thread['replies'] += $count[$thread['tid']];
				}
			}
		}
		return $return;
	}
	
	function viewthread_top_mobile_output() {
		global $_G,$allowpostreply;
		$setconfig = $this->setconfig;
		if(($setconfig['position_mobile'] > 0) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums']))){
			include template(self::$identifier.':style');
		}
		return $return;
	}

	function viewthread_bottom_mobile_output() {
		global $_G,$allowpostreply;
		$setconfig = $this->setconfig;
		if(($setconfig['position_mobile'] > 0) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums']))){
			include template(self::$identifier.':js');
		}
		return $return;
	}

	function viewthread_postbottom_mobile_output() {
		global $_G,$postlist,$postno,$postnostick,$allowpostreply;
		$setconfig = $this->setconfig;
		$t = $pids = array();
		if($_G['inajax']){
			return $t;
		}
		if(($setconfig['position_mobile'] == 1 || $setconfig['position_mobile'] == 2) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums']))){
			foreach($postlist as $key => $post) {
				if(!$post['first']){
					$pids[] = $post['pid'];
				}
			}
			if($pids){
				$orderby = 'order by createtime desc';
				if($setconfig['order_type'] == 2){
					$orderby = 'order by createtime asc';
				}
				$messageinfo = C::t('#'.self::$identifier.'#replyfloor_message')->fetch_message_by_pid($pids, $setconfig['perpage_mobile'], $orderby, $setconfig);
				foreach($postlist as $key => $post) {
					if($post['first']){
						$t[] = '';
					}else{
						$count = $messageinfo[$post['pid']]['count'];
						$list = $messageinfo[$post['pid']]['list'];
						$_GET['ajaxtarget'] = 'replyfloor_content_'.$post['pid'];
						$multipage = multi($count, $setconfig['perpage_mobile'], 1, 'plugin.php?id=replyfloor:index&tid='.$post['tid'].'&pid='.$post['pid']);
						$_GET['ajaxtarget'] = '';
						include template(self::$identifier.':viewthread');
						if($setconfig['position_mobile'] == 1){
							$post['message'] .= $return;
							$postlist[$key] = $post;
						}else{
							$t[] = $return;
						}
					}
				}
			}
		}
		return $t;
	}

	function viewthread_replyfloor_mobile_output() {
		global $_G,$postlist,$postno,$postnostick,$allowpostreply;
		$setconfig = $this->setconfig;
		$t = $pids = array();
		if($_G['inajax']){
			return $t;
		}
		if(($setconfig['position_mobile'] == 3) && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums']))){
			foreach($postlist as $key => $post) {
				if(!$post['first']){
					$pids[] = $post['pid'];
				}
			}
			if($pids){
				$orderby = 'order by createtime desc';
				if($setconfig['order_type'] == 2){
					$orderby = 'order by createtime asc';
				}
				$messageinfo = C::t('#'.self::$identifier.'#replyfloor_message')->fetch_message_by_pid($pids, $setconfig['perpage_mobile'], $orderby, $setconfig);
				foreach($postlist as $key => $post) {
					if($post['first']){
						$t[] = '';
					}else{
						$count = $messageinfo[$post['pid']]['count'];
						$list = $messageinfo[$post['pid']]['list'];
						$_GET['ajaxtarget'] = 'replyfloor_content_'.$post['pid'];
						$multipage = multi($count, $setconfig['perpage_mobile'], 1, 'plugin.php?id=replyfloor:index&tid='.$post['tid'].'&pid='.$post['pid']);
						$_GET['ajaxtarget'] = '';
						include template(self::$identifier.':viewthread');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

}

class mobileplugin_replyfloor_group extends mobileplugin_replyfloor {

	function forumdisplay_thread_mobile_output() {
		global $_G;
		$return = array();
		$setconfig = $this->setconfig;
		if($setconfig['add_replies']){
			$tids = array();
			foreach ($_G['forum_threadlist'] as $key => $value) {
				$tids[] = $value['tid'];
			}
			$wherearr = array();
			$wherearr[] = 'tid in ('.dimplode($tids).')';
			$wherearr[] = "status = '0'";
			$recordlist = DB::fetch_all('SELECT tid,count(*) as count FROM '.DB::table('plugin_replyfloor_message').($wherearr ? ' WHERE '.implode(' AND ', $wherearr) : '').' group by tid');
			$count = array();
			foreach ($recordlist as $value) {
				$count[$value['tid']] = $value['count'];
			}
			foreach ($_G['forum_threadlist'] as &$thread) {
				if($count[$thread['tid']]){
					$thread['allreplies'] += $count[$thread['tid']];
				}
			}
		}
		return $return;
	}
	
	function viewthread_bottom_mobile_output() {
		global $_G,$allowpostreply;
		$setconfig = $this->setconfig;
		if(($setconfig['position_mobile'] > 0) && (!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups']))){
			include template(self::$identifier.':style');
		}
		return $return;
	}

	function viewthread_postbottom_mobile_output() {
		global $_G,$postlist,$postno,$postnostick,$allowpostreply;
		$setconfig = $this->setconfig;
		$t = $pids = array();
		if($_G['inajax']){
			return $t;
		}
		if(($setconfig['position_mobile'] == 1 || $setconfig['position_mobile'] == 2) && (!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups']))){
			foreach($postlist as $key => $post) {
				if(!$post['first']){
					$pids[] = $post['pid'];
				}
			}
			if($pids){
				$orderby = 'order by createtime desc';
				if($setconfig['order_type'] == 2){
					$orderby = 'order by createtime asc';
				}
				$messageinfo = C::t('#'.self::$identifier.'#replyfloor_message')->fetch_message_by_pid($pids, $setconfig['perpage_mobile'], $orderby, $setconfig);
				foreach($postlist as $key => $post) {
					if($post['first']){
						$t[] = '';
					}else{
						$count = $messageinfo[$post['pid']]['count'];
						$list = $messageinfo[$post['pid']]['list'];
						$_GET['ajaxtarget'] = 'replyfloor_content_'.$post['pid'];
						$multipage = multi($count, $setconfig['perpage_mobile'], 1, 'plugin.php?id=replyfloor:index&tid='.$post['tid'].'&pid='.$post['pid']);
						$_GET['ajaxtarget'] = '';
						include template(self::$identifier.':viewthread');
						if($setconfig['position_mobile'] == 1){
							$post['message'] .= $return;
							$postlist[$key] = $post;
						}else{
							$t[] = $return;
						}
					}
				}
			}
		}
		return $t;
	}

	function viewthread_replyfloor_mobile_output() {
		global $_G,$postlist,$postno,$postnostick,$allowpostreply;
		$setconfig = $this->setconfig;
		$t = $pids = array();
		if($_G['inajax']){
			return $t;
		}
		if(($setconfig['position_mobile'] == 3) && (!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups']))){
			foreach($postlist as $key => $post) {
				if(!$post['first']){
					$pids[] = $post['pid'];
				}
			}
			if($pids){
				$orderby = 'order by createtime desc';
				if($setconfig['order_type'] == 2){
					$orderby = 'order by createtime asc';
				}
				$messageinfo = C::t('#'.self::$identifier.'#replyfloor_message')->fetch_message_by_pid($pids, $setconfig['perpage_mobile'], $orderby, $setconfig);
				foreach($postlist as $key => $post) {
					if($post['first']){
						$t[] = '';
					}else{
						$count = $messageinfo[$post['pid']]['count'];
						$list = $messageinfo[$post['pid']]['list'];
						$_GET['ajaxtarget'] = 'replyfloor_content_'.$post['pid'];
						$multipage = multi($count, $setconfig['perpage_mobile'], 1, 'plugin.php?id=replyfloor:index&tid='.$post['tid'].'&pid='.$post['pid']);
						$_GET['ajaxtarget'] = '';
						include template(self::$identifier.':viewthread');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}

}
//From: Dism��taobao��com
?>