<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
$setconfig = $_G['cache']['plugin'][$plugin['identifier']];

$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=recycle';

$op = in_array($_GET['op'], array('index','edit')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$intkeys = array('tid', 'pid');
		$strkeys = array();
		$randkeys = array();
		$likekeys = array('username', 'message');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$wherearr[] = "status = '1'";
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$searchmessage = lang('plugin/'.$plugin['identifier'], 'message_message');
		$searchtid = lang('plugin/'.$plugin['identifier'], 'message_tid');
		$searchpid = lang('plugin/'.$plugin['identifier'], 'message_pid');
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$lang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
					<th>$searchmessage</th><td><input type="text" class="txt" name="message" value="$_GET[message]"></td>
					<th>$searchtid</th><td><input type="text" class="txt" name="tid" value="$_GET[tid]" size="4"></td>
					<th>$searchpid</th><td><input type="text" class="txt" name="pid" value="$_GET[pid]" size="4"></td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="replyfloor">
						<input type="hidden" name="pmod" value="recycle">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=recycle');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'message_list'));
		showsubtitle(array('', 'username', lang('plugin/'.$plugin['identifier'], 'message_message'), lang('plugin/'.$plugin['identifier'], 'message_createtime'), 'ip', ''));
		$count = C::t('#'.$plugin['identifier'].'#replyfloor_message')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#replyfloor_message')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
		require_once libfile('function/common', 'plugin/replyfloor');
		foreach ($list as $value) {
			$value['message'] = reply_discuzcode($value['message']);
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
			showtablerow('', array('class="td25"', 'class="td24"', '', 'class="td24"', 'class="td24"', 'class="td32"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"ids[]\" value=\"$value[id]\">",
				$value['username'],
				$value['message'],
				$value['createtime'],
				$value['postip'],
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">".$lang['edit']."</a> ".
				"<a href=\"forum.php?mod=redirect&goto=findpost&ptid=$value[tid]&pid=$value[pid]\" target=\"_blank\">".lang('plugin/'.$plugin['identifier'], 'message_viewpost')."</a>",
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp;<select name="optype"><option value="restore">'.lang('plugin/'.$plugin['identifier'], 'optype_restore').'</option><option value="delete">'.lang('plugin/'.$plugin['identifier'], 'optype_delete').'</option></select>', '', $multipage, false);
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/
	} else {
		if(is_array($_GET['ids'])) {
			if($_GET['optype'] == 'restore') {
				if($setconfig['get_credit']) {
					require_once libfile('function/post');
					require_once libfile('function_forum', 'function');
					$list = C::t('#'.$plugin['identifier'].'#replyfloor_message')->fetch_by_ids($_GET['ids']);
					foreach ($list as $value) {
						$thread = get_thread_by_tid($value['tid']);
						updatepostcredits('+', $value['uid'], 'reply', $thread['fid']);
					}
				}
				C::t('#'.$plugin['identifier'].'#replyfloor_message')->restore_by_id($_GET['ids']);
			}else{
				C::t('#'.$plugin['identifier'].'#replyfloor_message')->delete_by_id($_GET['ids']);
			}
		}else{
			cpmsg(lang('plugin/'.$plugin['identifier'], 'operate_not_check'), '', 'error');
		}
		cpmsg(lang('plugin/'.$plugin['identifier'], 'message_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=recycle', 'succeed');
	}
} elseif($op == 'edit' && $_GET['id']) {

	$item = C::t('#'.$plugin['identifier'].'#replyfloor_message')->fetch_by_id($_GET['id']);
	if(!$item) {
		cpmsg(lang('plugin/'.$plugin['identifier'], 'message_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=recycle&op=edit&id='.$_GET['id'],'enctype');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'message_edit'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'message_message'), 'message', $item['message'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'message_message_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/
	} else {
		$data = array(
			'message' => $_GET['message'],
		);
		C::t('#'.$plugin['identifier'].'#replyfloor_message')->update_by_id($_GET['id'], $data);
		cpmsg(lang('plugin/'.$plugin['identifier'], 'message_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=recycle&op=index', 'succeed');
	}

}
//From: Dism_taobao_com
?>