<?php

/**
 *      author: ����
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$available_existed = $targets_existed = $tarpara_existed = $popshow_existed = $interunit_existed = $shownum_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_popadv_adv'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'available') {
		$available_existed = true;
		continue;
	}
	if($row['Field'] == 'targets') {
		$targets_existed = true;
		continue;
	}
	if($row['Field'] == 'tarpara') {
		$tarpara_existed = true;
		continue;
	}
	if($row['Field'] == 'popshow') {
		$popshow_existed = true;
		continue;
	}
	if($row['Field'] == 'interunit') {
		$interunit_existed = true;
		continue;
	}
	if($row['Field'] == 'shownum') {
		$shownum_existed = true;
		continue;
	}
}
$sql .= !$available_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `available` tinyint(1) NOT NULL DEFAULT '0';\n" : '';
$sql .= !$targets_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `targets` text NOT NULL DEFAULT '';\n" : '';
$sql .= !$tarpara_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `tarpara` text NOT NULL DEFAULT '';\n" : '';
$sql .= !$popshow_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `popshow` tinyint(1) NOT NULL DEFAULT 0;\n" : '';
$sql .= !$interunit_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `interunit` varchar(20) NOT NULL DEFAULT '';\n" : '';
$sql .= !$shownum_existed ? "ALTER TABLE `cdb_plugin_popadv_adv` ADD `shownum` int(10) unsigned NOT NULL DEFAULT 0;\n" : '';

$sql .= "ALTER TABLE `cdb_plugin_popadv_adv` MODIFY `postip` varchar(45) NOT NULL DEFAULT '';\n";

if($sql) {
	runquery($sql);
	if(!$available_existed) {
		C::t('#popadv#popadv_adv')->update(array('available' => '1'));
	}
	if(!$targets_existed) {
		C::t('#popadv#popadv_adv')->update(array('targets' => 'forum'));
	}
	if(!$popshow_existed) {
		C::t('#popadv#popadv_adv')->update(array('popshow' => '1'));
	}
	if(!$interunit_existed) {
		C::t('#popadv#popadv_adv')->update(array('interunit' => 'day'));
	}
}

updatecache('popadv:popadv_adv');

$finish = TRUE;

?>