<?php

/**
 *      author: ����
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_popadv_adv`;
CREATE TABLE `cdb_plugin_popadv_adv` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `available` tinyint(1) NOT NULL DEFAULT '0',
  `displayorder` mediumint(8) NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `showarea` varchar(120) NOT NULL DEFAULT '',
  `targets` text NOT NULL DEFAULT '',
  `tarpara` text NOT NULL DEFAULT '',
  `usergroup` text NOT NULL DEFAULT '',
  `popshow` tinyint(1) NOT NULL DEFAULT 0,
  `style` varchar(20) NOT NULL DEFAULT '',
  `parameters` text NOT NULL DEFAULT '',
  `staytime` int(10) unsigned NOT NULL DEFAULT 0,
  `intertime` int(10) unsigned NOT NULL DEFAULT 0,
  `interunit` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `shownum` int(10) unsigned NOT NULL DEFAULT 0,
  `postip` varchar(45) NOT NULL DEFAULT '',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `showarea` (`showarea`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>