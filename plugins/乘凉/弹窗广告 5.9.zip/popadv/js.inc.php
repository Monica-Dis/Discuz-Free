<?php

/**
 *      author: ����
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$advid = intval($_GET["advid"]);
if(!$advid){
	exit;
}

$adv = C::t('#'.CURMODULE.'#popadv_adv')->fetch_by_id($adv);
if(!$adv) {
	exit;
}

$advcookie = getcookie('popadv');
$advcookie = $advcookie ? unserialize($advcookie) : array();

$wherearr = array();
$wherearr[] = "showarea = 'custom'";
$wherearr[] = "(starttime = 0 or starttime <= ".$_G['timestamp'].")";
$wherearr[] = "(endtime = 0 or endtime >= ".$_G['timestamp'].")";
$advlist = C::t('#'.CURMODULE.'#popadv_adv')->fetch_all_by_search_where($wherearr, 'order by createtime desc');
foreach ($advlist as $key => $value) {
	$value['usergroup'] = explode("\t", $value['usergroup']);
	if(in_array('', $value['usergroup'])) {
		$value['usergroup'] = array();
	}
	if($value['usergroup'] &&  !in_array($_G['groupid'], $value['usergroup'])) {
		unset($advlist[$key]);
		continue;
	}
	if($advcookie && array_key_exists($value['id'], $advcookie)){
		$getadvtime = $advcookie[$value['id']];
		if($value['interunit'] == 'second'){
			$value['intertime'] = $getadvtime + $value['intertime'];
		}elseif($value['interunit'] == 'minute'){
			$value['intertime'] = $getadvtime + $value['intertime'] * 60;
		}elseif($value['interunit'] == 'hour'){
			$value['intertime'] = $getadvtime + $value['intertime'] * 3600;
		}elseif($value['interunit'] == 'day'){
			$value['intertime'] = dmktime(dgmdate($getadvtime + $value['intertime'] * 24 *3600, 'd'));
		}
		if($value['intertime'] > $_G['timestamp']) {
			unset($advlist[$key]);
			continue;
		}
	}

}
if($advlist){
	$adv = $advlist[array_rand($advlist)];
	$adv['parameters'] = unserialize($adv['parameters']);
	$advcookie[$adv['id']] = $_G['timestamp'];
	dsetcookie('popadv', serialize($advcookie));
	include template(CURMODULE.':js_'.$adv['style']);
}else{
	dsetcookie('popadv', serialize($advcookie));
}

