<?php

/**
 *      author: ����
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

delDirAndFile(getglobal('setting/attachdir').'./popadv');

$sql = <<<EOF
	DROP TABLE IF EXISTS `cdb_plugin_popadv_adv`;
EOF;

runquery($sql);

C::t('common_syscache')->delete('popadv_adv');

$finish = TRUE;

function delDirAndFile($path, $delDir = true) {  
    if (is_array($path)) {  
        foreach ($path as $subPath)  
            delDirAndFile($subPath, $delDir);  
    }  
    if (is_dir($path)) {  
        $handle = opendir($path);  
        if ($handle) {  
            while (false !== ( $item = readdir($handle) )) {  
                if ($item != "." && $item != "..")  
                    is_dir("$path/$item") ? delDirAndFile("$path/$item", $delDir) : unlink("$path/$item");  
            }  
            closedir($handle);  
            if ($delDir)  
                return rmdir($path);  
        }  
    } else {  
        if (file_exists($path)) {  
            return unlink($path);  
        } else {  
            return FALSE;  
        }  
    }  
    clearstatcache();  
} 