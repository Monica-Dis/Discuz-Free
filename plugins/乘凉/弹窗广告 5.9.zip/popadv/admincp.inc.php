<?php

/**
 *      author: ����
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
$setconfig = $_G['cache']['plugin'][$plugin['identifier']];
$setconfig['usergroup'] = (array)unserialize($setconfig['usergroup']);
$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp';

$op = in_array($_GET['op'], array('index','add','edit')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$intkeys = array();
		$strkeys = array('showarea');
		$randkeys = array();
		$likekeys = array('title');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$searchshowarea = lang('plugin/'.$plugin['identifier'], 'adv_showarea');
		$searchshowarea_pc = lang('plugin/'.$plugin['identifier'], 'adv_showarea_pc');
		$searchshowarea_mobile = lang('plugin/'.$plugin['identifier'], 'adv_showarea_mobile');
		$showarea_selected[$_GET["showarea"]] = " selected";
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$lang[subject]</th><td><input type="text" class="txt" name="title" value="$_GET[title]"></td>
					<th>$searchshowarea</th><td><select name="showarea" class="ps vm"><option value="">$lang[select]</option><option value="pc"$showarea_selected[pc]>$searchshowarea_pc</option><option value="mobile"$showarea_selected[mobile]>$searchshowarea_mobile</option></select></td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="popadv">
						<input type="hidden" name="pmod" value="admincp">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'adv_list'). '<a href="'.$pluginurl.'&op=add" style="margin-left:10px">['.lang('plugin/'.$plugin['identifier'], 'adv_add').']</a>');
		showsubtitle(array('del', 'display_order', 'available', 'subject', lang('plugin/'.$plugin['identifier'], 'adv_shownum'), lang('plugin/'.$plugin['identifier'], 'adv_showarea'), 'start_time', 'end_time', 'adv_targets', 'operation'));
		$count = C::t('#'.$plugin['identifier'].'#popadv_adv')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#popadv_adv')->fetch_all_by_search_where($wherearr,'order by displayorder desc, createtime desc', $start, $perpage);
		foreach ($list as $value) {
			$targets = array();
			foreach(explode("\t", $value['targets']) as $t) {
				$targetsarr = array('portal', 'forum', 'group', 'plugin', 'home', 'member', 'search', 'popadv', 'custom');
				if($t && 'adv_edit_targets_'.$t != 'adv_edit_targets_custom') {
					$targets[] = in_array($t, $targetsarr) ? lang('plugin/'.$plugin['identifier'], 'adv_targets_'.$t) : $t;
				}
			}
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j');
			showtablerow('', array('class="td25"', 'class="td25"', 'class="td25"', '', 'class="td24"', 'class="td24"', 'class="td24"', 'class="td24"', 'class="td24"', 'class="td25"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$value[id]]\" value=\"$value[displayorder]\">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$value[id]]\" value=\"1\" ".($value['available'] ? 'checked' : '').">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"titlenew[$value[id]]\" value=\"".dhtmlspecialchars($value['title'])."\">",
				$value['shownum'],
				lang('plugin/'.$plugin['identifier'], 'adv_showarea_'.$value['showarea']),
				$value['starttime'] ? dgmdate($value['starttime'], 'Y-n-j H:i') : $lang['unlimited'],
				$value['endtime'] ? dgmdate($value['endtime'], 'Y-n-j H:i') : $lang['unlimited'],
				implode(', ', $targets),
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">$lang[edit]</a>"
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', 'select_all', '', $multipage, false);
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dism��taobao��com*/
	} else {
		if(is_array($_GET['delete'])) {
			$list = C::t('#'.$plugin['identifier'].'#popadv_adv')->fetch_by_ids($_GET['delete']);
			foreach ($list as $value) {
				$value['parameters'] = unserialize($value['parameters']);
				del_adv_img($value);
			}
			C::t('#'.$plugin['identifier'].'#popadv_adv')->delete_by_id($_GET['delete']);
		}
			
		if(is_array($_GET['titlenew'])) {
			foreach($_GET['titlenew'] as $advid => $title) {
				C::t('#'.$plugin['identifier'].'#popadv_adv')->update_by_id($advid, array(
					'available' => $_GET['availablenew'][$advid],
					'displayorder' => $_GET['displayordernew'][$advid],
					'title' => cutstr($_GET['titlenew'][$advid], 50)
				));
			}
		}

		updatecache('popadv:popadv_adv');
		cpmsg(lang('plugin/'.$plugin['identifier'], 'adv_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp', 'succeed');
	}
} elseif($op == 'add' || ($op == 'edit' && $_GET['id'])) {
	if($op == 'edit') {
		$adv = C::t('#'.$plugin['identifier'].'#popadv_adv')->fetch_by_id($_GET['id']);
		if(!$adv) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'adv_nonexistence'), '', 'error');
		}
		$adv['tarpara'] = $adv['tarpara'] ? unserialize($adv['tarpara']) : array();
		$adv['usergroup'] = explode("\t", $adv['usergroup']);
		$adv['parameters'] = unserialize($adv['parameters']);
	}
	if(!submitcheck('savesubmit')) {
		if($op == 'edit') {
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp&op=edit&id='.$_GET['id'],'enctype');
			showtableheader(lang('plugin/'.$plugin['identifier'], 'adv_edit'));
		} else {
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp&op=add','enctype');
			showtableheader(lang('plugin/'.$plugin['identifier'], 'adv_add'));
		}
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_title'), 'title', $adv['title'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_title_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_showarea'), array('showarea', array(
				array('pc', lang('plugin/'.$plugin['identifier'], 'adv_showarea_pc')),
				array('mobile', lang('plugin/'.$plugin['identifier'], 'adv_showarea_mobile'))
			), 1), $adv['showarea'] ? $adv['showarea'] : 'pc', 'mradio', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_showarea_comment'));
		
		$targetsarr = array('portal', 'forum', 'group', 'plugin', 'home', 'member', 'search', 'popadv', 'custom');
		$targets = array();
		foreach($targetsarr as $target) {
			if($target != 'custom') {
				if($target == 'portal' || $target == 'forum' || $target == 'group' || $target == 'plugin' || $target == 'popadv') {
					$targets[] = array($target, lang('plugin/'.$plugin['identifier'], 'adv_targets_'.$target), 'tarpara_'.$target);
				} else {
					$targets[] = array($target, lang('plugin/'.$plugin['identifier'], 'adv_targets_'.$target));
				}
			} else {
				$ets = explode("\t", $adv['targets']);
				$customv = array();
				foreach($ets as $et) {
					if(!in_array($et, $targetsarr)) {
						$customv[] = $et;
					}
				}
				$targets[] = array($target, '<input title="'.cplang('adv_custom_target').'" name="targetcustom" value="'.implode(',', $customv).'" />');
			}
		}
		showsetting('adv_edit_targets', array('targets', $targets), explode("\t",$adv['targets']), 'mcheckbox');
		loadcache(array('portalcategory', 'forums', 'grouptype'));
		showtagheader('tbody', 'tarpara_portal', in_array('portal', explode("\t",$adv['targets'])));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_tarpara_portal'), array('tarpara[portal][]', array_merge(array(array('', '&nbsp;'), array(-1, $lang['home'])), getcategory(0))), $adv['tarpara']['portal'], 'mselect', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_tarpara_portal_comment'));
		showtagfooter('tbody');
		$forumvalue[] = $groupvalue[] = array('', '&nbsp;');
		$forumvalue[] = $groupvalue[] = array(-1, $lang['home']);
		$forumvalue[] = array(-2, 'Archiver');
		$forumvalue[] = array(-3, lang('plugin/'.$plugin['identifier'], 'page_forum_guide'));
		if(!empty($_G['cache']['forums'])){
			foreach($_G['cache']['forums'] as $fid => $forum) {
				$forumvalue[] = array($fid, ($forum['type'] == 'forum' ? str_repeat('&nbsp;', 4) : ($forum['type'] == 'sub' ? str_repeat('&nbsp;', 8) : '')).$forum['name']);
			}
		}
		foreach($_G['cache']['grouptype']['first'] as $gid => $group) {
			$groupvalue[] = array($gid, str_repeat('&nbsp;', 4).$group['name']);
			if($group['secondlist']) {
				foreach($group['secondlist'] as $sgid) {
					$groupvalue[] = array($sgid, str_repeat('&nbsp;', 8).$_G['cache']['grouptype']['second'][$sgid]['name']);
				}
			}
		}
		$plugins = C::t('common_plugin')->fetch_all_data(true);
		foreach($plugins as $id => $value) {
			$pluginvalue[] = array($value['identifier'], $value['name']);
		}
		showtagheader('tbody', 'tarpara_forum', in_array('forum', explode("\t",$adv['targets'])));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_tarpara_forum'), array('tarpara[forum][]', $forumvalue), $adv['tarpara']['forum'], 'mselect', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_tarpara_forum_comment'));
		showtagfooter('tbody');
		showtagheader('tbody', 'tarpara_group', in_array('group', explode("\t",$adv['targets'])));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_tarpara_group'), array('tarpara[group][]', $groupvalue), $adv['tarpara']['group'], 'mselect', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_tarpara_group_comment'));
		showtagfooter('tbody');
		showtagheader('tbody', 'tarpara_plugin', in_array('plugin', explode("\t",$adv['targets'])));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_tarpara_plugin'), array('tarpara[plugin][]', $pluginvalue), $adv['tarpara']['plugin'], 'mselect', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_tarpara_plugin_comment'));
		showtagfooter('tbody');
		showtagheader('tbody', 'tarpara_popadv', in_array('popadv', explode("\t",$adv['targets'])));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_tarpara_popadv'), 'tarpara[popadv]', $adv['tarpara']['popadv'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_tarpara_popadv_comment'));
		showtagfooter('tbody');

		$query = C::t('common_usergroup')->range_orderby_credit();
		$groupselect = array();
		foreach($query as $group) {
			$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
			$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], isset($adv['usergroup']) ? $adv['usergroup'] : $setconfig['usergroup']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
		}
		$select = '<select name="usergroup[]" size="10" multiple="multiple"><option value=""'.(@in_array('', isset($adv['usergroup']) ? $adv['usergroup'] : $setconfig['usergroup']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.
				'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
				($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
				($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
				'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_usergroup'), '', '', $select, '', 0, lang('plugin/'.$plugin['identifier'], 'adv_usergroup_comment'));

		//showsetting(lang('plugin/'.$plugin['identifier'], 'adv_expiredtime'), array('starttime', 'endtime'), array($adv['starttime'] ? dgmdate($adv['starttime'], 'Y-n-j') : '', $adv['endtime'] ? dgmdate($adv['endtime'], 'Y-n-j') : ''), 'daterange', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_expiredtime_comment'), 1);
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_starttime'), 'starttime', $adv['starttime'] ? dgmdate($adv['starttime'], 'Y-n-j H:i') : '', 'calendar', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_starttime_comment'), 1);
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_endtime'), 'endtime', $adv['endtime'] ? dgmdate($adv['endtime'], 'Y-n-j H:i') : '', 'calendar', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_endtime_comment'), 1);
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_staytime'), 'staytime', isset($adv['staytime']) ? $adv['staytime'] : $setconfig['staytime'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_staytime_comment'));
		showtablerow('', 'colspan="2" class="td27" s="1"', lang('plugin/'.$plugin['identifier'], 'adv_intertime').':');
		$selectunit = '<select name="interunit" style="width: 108px;">';
		foreach(lang('plugin/'.$plugin['identifier'], 'adv_interunit') as $key =>$value) {
			$selectunit .= '<option value="'.$key.'"'.($key == $adv['interunit'] ? ' selected' : '').'>'.$value.'</option>';
		}
		$selectunit .= '</select>';
		showtablerow('class="noborder" onmouseover="setfaq(this, \'faq'.substr(md5(lang('plugin/'.$plugin['identifier'], 'adv_intertime')), 0, 4).'\')"', array('class="vtop rowform"', 'class="vtop tips2" s="1"'), array(
			'<input name="intertime" value="'.($adv['intertime'] ? $adv['intertime'] : 0).'" type="text" class="txt" style="width: 128px;" />'.$selectunit, lang('plugin/'.$plugin['identifier'], 'adv_intertime_comment')
		));
		//showsetting(lang('plugin/'.$plugin['identifier'], 'adv_intertime'), 'intertime', isset($adv['intertime']) ? $adv['intertime'] : $setconfig['intertime'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_intertime_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_popshow'), array('popshow', lang('plugin/'.$plugin['identifier'], 'adv_popshow_style')), $adv['popshow'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_popshow_comment'));
		$adtypearray = array();
		$adtypes = array('image', 'code');
		foreach($adtypes as $adtype) {
			$displayary = array();
			foreach($adtypes as $adtype1) {
				$displayary['style_'.$adtype1] = $adtype1 == $adtype ? '' : 'none';
			}
			$adtypearray[] = array($adtype, $lang['adv_style_'.$adtype], $displayary);
		}
		showsetting('adv_edit_style', array('style', $adtypearray, 1), $adv['style'] ? $adv['style'] : 'image', 'mradio');
		showtagheader('tbody', 'style_image', !$adv['style'] || $adv['style'] == 'image');
		showtitle('adv_edit_style_image');
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_url'), 'imageurl', $adv['parameters']['url'], 'filetext', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_url_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_size'), array('parameters[image][width]', 'parameters[image][height]'), array($adv['parameters']['width'], $adv['parameters']['height']), 'multiply', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_size_comment'));
		//showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_width'), 'parameters[image][width]', $adv['parameters']['width'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_width_comment'));
		//showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_height'), 'parameters[image][height]', $adv['parameters']['height'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_height_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_link'), 'parameters[image][link]', $adv['parameters']['link'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_link_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_alt'), 'parameters[image][alt]', $adv['parameters']['alt'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_alt_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_image_target'), 'parameters[image][target]', $adv['parameters']['target'], 'radio', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_image_target_comment'));
		showtagfooter('tbody');
		showtagheader('tbody', 'style_code', $adv['style'] == 'code');
		showtitle('adv_edit_style_code');
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_code_html'), 'parameters[code][html]', $adv['parameters']['html'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_code_html_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'adv_code_size'), array('parameters[code][width]', 'parameters[code][height]'), array($adv['parameters']['width'], $adv['parameters']['height']), 'multiply', '', 0, lang('plugin/'.$plugin['identifier'], 'adv_code_size_comment'));
		showtagfooter('tbody');
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dism��taobao��com*/
		echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	} else {
		$data = array(
			'title' => $_GET['title'],
			'showarea' => $_GET['showarea'],
			'targets' => $_GET['targets'],
			'tarpara' => serialize($_GET['tarpara']),
			'usergroup' => implode("\t", $_GET['usergroup']),
			'popshow' => intval($_GET['popshow']),
			'staytime' => intval($_GET['staytime']),
			'intertime' => intval($_GET['intertime']),
			'interunit' => $_GET['interunit'],
			'starttime' => $_GET['starttime'],
			'endtime' => $_GET['endtime'],
			'style' => $_GET['style'] ? $_GET['style'] : 'image',
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		if(@in_array('custom', $data['targets'])) {
			$targetcustom = explode(',', $_GET['targetcustom']);
			$data['targets'] = array_merge($data['targets'], $targetcustom);
		}
		if(is_array($data['targets'])) {
			$data['targets'] = implode("\t", $data['targets']);
		}
		$data['parameters'] = $_GET['parameters'][$data['style']];
		$data['starttime'] = $data['starttime'] ? strtotime($data['starttime']) : 0;
		$data['endtime'] = $data['endtime'] ? strtotime($data['endtime']) : 0;

		if(!$data['title']) {
			cpmsg('adv_title_invalid', '', 'error');
		} elseif(strlen($data['title']) > 50) {
			cpmsg('adv_title_more', '', 'error');
		} elseif($data['endtime'] && ($data['endtime'] <= TIMESTAMP || $data['endtime'] <= $data['starttime'])) {
			cpmsg('adv_endtime_invalid', '', 'error');
		} elseif($data['style'] == 'image' && !$_FILES['imageurl'] && !$_GET['imageurl']) {
			cpmsg('adv_parameter_invalid', '', 'error');
		} elseif($data['style'] == 'code' && (!$data['parameters']['html'] || !$data['parameters']['width'] || !$data['parameters']['height'])) {
			cpmsg('adv_parameter_invalid', '', 'error');
		}

		if($data['style'] == 'image') {
			if($_FILES['imageurl']) {
				if($op == 'edit') {
					del_adv_img($adv);
				}
				require DISCUZ_ROOT . './source/plugin/popadv/lib/discuz_upload.php';
				$upload = new discuz_upload();
				if($upload->init($_FILES['imageurl'], 'popadv') && $upload->save(1)) {
					$data['parameters']['url'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'popadv/'.$upload->attach['attachment'];
				}else{
					echo $upload->errorcode;
					exit;
				}
			} else {
				$data['parameters']['url'] = $_GET['imageurl'];
			}
		}
		$data['parameters'] = serialize($data['parameters']);

		if($op == 'edit') {
			C::t('#'.$plugin['identifier'].'#popadv_adv')->update_by_id($_GET['id'], $data);
			updatecache('popadv:popadv_adv');
			cpmsg(lang('plugin/'.$plugin['identifier'], 'adv_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp', 'succeed');
		} else {
			$data['available'] = 1;
			C::t('#'.$plugin['identifier'].'#popadv_adv')->insert($data);
			updatecache('popadv:popadv_adv');
			cpmsg(lang('plugin/'.$plugin['identifier'], 'adv_addsucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp', 'succeed');
		}
	}
}

function getcategory($upid = 0) {
	global $_G;
    $list = array();
	foreach($_G['cache']['portalcategory'] as $category) {
		if($category['upid'] == $upid) {
			$list[] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4).$category['catname']);
			$list = array_merge($list, getcategory($category['catid']));
		}
	}
	return $list;
}

function del_adv_img($adv) {
	global $_G;
	if($adv['style'] == 'image' && $adv['parameters']['url']){
		$adv['parameters']['url'] = str_replace($_G['siteurl'],"",$adv['parameters']['url']);
		$valueparse = parse_url($adv['parameters']['url']);
		if(!isset($valueparse['host'])) {
			@unlink($adv['parameters']['url']);
		}
	}
	return '';
}

?>