<?php

/**
 *      author: ����
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_popadv {

	public static $identifier = 'popadv';

	var $advcookie = '';

    function __construct() {

    }

	function common() {
		$advcookie = getcookie('popadv');//�û��˳�ʱ�����cookie���ʴ˱���
		$this->advcookie = $advcookie;
	}

	function global_footer_mobile() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['maskopacity'] = $setconfig['maskopacity']/100;
		loadcache('popadv_adv');
		$advlist = $_G['cache']['popadv_adv'];
		$advcookie = $this->advcookie;
		$advcookie = $advcookie ? unserialize($advcookie) : array();
		foreach ($advlist as $key => $value) {
			if($value['showarea'] != 'mobile') {
				unset($advlist[$key]);
				continue;
			}
			if(($value['starttime'] && $value['starttime'] > $_G['timestamp']) || ($value['endtime'] && $value['endtime'] < $_G['timestamp'])) {
				unset($advlist[$key]);
				continue;
			}
			$value['targets'] = explode("\t", $value['targets']);
			$value['tarpara'] = unserialize($value['tarpara']);
			if(!in_array('popadv', $value['targets']) || !$this->_in_linkurl($value['tarpara']['popadv'])) {
				if(!in_array($_G['basescript'], $value['targets'])) {
					unset($advlist[$key]);
					continue;
				}
				if($_G['basescript'] == 'portal' && $value['tarpara']['portal'] && !((!empty($_G['catid']) && in_array($_G['catid'], $value['tarpara']['portal'])) || (empty($_G['catid']) && in_array(-1, $value['tarpara']['portal'])))) {
					unset($advlist[$key]);
					continue;
				}
				if($_G['basescript'] == 'forum' && $value['tarpara']['forum'] && !((!defined('IN_ARCHIVER') && (in_array($_G['fid'], $value['tarpara']['forum']) || (CURMODULE == 'index' && !$_G['fid'] && in_array(-1, $value['tarpara']['forum'])) || (CURMODULE == 'guide' && in_array(-3, $value['tarpara']['forum'])))) || (defined('IN_ARCHIVER') && in_array(-2, $value['tarpara']['forum'])))) {
					unset($advlist[$key]);
					continue;
				}
				if($_G['basescript'] == 'group' && $value['tarpara']['group'] && !(in_array($_G['grouptypeid'], $value['tarpara']['group']) || (CURMODULE == 'index' && in_array(-1, $value['tarpara']['group'])))) {
					unset($advlist[$key]);
					continue;
				}
				if($_G['basescript'] == 'plugin' && $value['tarpara']['plugin'] && !in_array(CURMODULE, $value['tarpara']['plugin'])) {
					unset($advlist[$key]);
					continue;
				}
			}
			$value['usergroup'] = explode("\t", $value['usergroup']);
			if(in_array('', $value['usergroup'])) {
				$value['usergroup'] = array();
			}
			if($value['usergroup'] &&  !in_array($_G['groupid'], $value['usergroup'])) {
				unset($advlist[$key]);
				continue;
			}
			if($advcookie && array_key_exists($value['id'], $advcookie)){
				$getadvtime = $advcookie[$value['id']];
				if($value['interunit'] == 'second'){
					$value['intertime'] = $getadvtime + $value['intertime'];
				}elseif($value['interunit'] == 'minute'){
					$value['intertime'] = $getadvtime + $value['intertime'] * 60;
				}elseif($value['interunit'] == 'hour'){
					$value['intertime'] = $getadvtime + $value['intertime'] * 3600;
				}elseif($value['interunit'] == 'day'){
					$value['intertime'] = dmktime(dgmdate($getadvtime + $value['intertime'] * 24 *3600, 'd'));
				}
				if($value['intertime'] > $_G['timestamp']) {
					unset($advlist[$key]);
					continue;
				}
			}
		}
		if($advlist){
			$adv = $advlist[array_rand($advlist)];
			if(!IS_ROBOT) {
				C::t('#'.self::$identifier.'#popadv_adv')->update_shownum($adv['id']);
			}
			$adv['parameters'] = unserialize($adv['parameters']);
			$advcookie[$adv['id']] = $_G['timestamp'];
			include template(self::$identifier.':adv_'.$adv['style']);
		}
		dsetcookie('popadv', serialize($advcookie));
		return $return;
	}

	function _in_linkurl($linkurls) {
		global $_G;
		$linkurls = explode("\n", $linkurls);
		$protocol = $this->_get_http_type() ? "https://" : "http://";
		$currenturl = $protocol.$_SERVER['HTTP_HOST'].$this->_get_request_url();
		foreach($linkurls as $key => $value) {
			$value = trim($value);
			if(!$value){
				continue;
			}
			if(strpos($value, '/') === 0){
				if(preg_match($value, $currenturl)){
					return true;
				}
			}else{
				if($value == $currenturl){
					return true;
				}
			}
		}
		return false;
	}

	function _get_http_type() {
		if(isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off') {
			return true;
		}
		if(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) == 'https') {
			return true;
		}
		if(isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && strtolower($_SERVER['HTTP_X_CLIENT_SCHEME']) == 'https') {
			return true;
		}
		if(isset($_SERVER['HTTP_FROM_HTTPS']) && strtolower($_SERVER['HTTP_FROM_HTTPS']) != 'off') {
			return true;
		}
		if(isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) {
			return true;
		}
		return false;
    }

	function _get_request_url() {
		if (isset($_SERVER['HTTP_X_ORIGINAL_URL'])) {
			$request_url = $_SERVER['HTTP_X_ORIGINAL_URL'];
		} elseif (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
			$request_url = $_SERVER['HTTP_X_REWRITE_URL'];
		} elseif (isset($_SERVER['REQUEST_URI'])) {
			$request_url = $_SERVER['REQUEST_URI'];
		} elseif (isset($_SERVER['REDIRECT_URL'])) {
			$request_url = $_SERVER['REDIRECT_URL'];
			if (isset($_SERVER['REDIRECT_QUERY_STRIN'])) {
				$request_url .= '?' . $_SERVER['REDIRECT_QUERY_STRIN'];
			}
		} else {
			$request_url = $_SERVER['PHP_SELF'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '');
		}
		return $request_url;
    }

}

?>