<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = "";
$forumid_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_hidethreadsort_field'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'forumid') {
		$forumid_existed = true;
		continue;
	}
}
$sql .= !$forumid_existed ? "ALTER TABLE `cdb_plugin_hidethreadsort_field` ADD `forumid` mediumint(8) unsigned NOT NULL DEFAULT 0;\n" : '';

$sql .= "ALTER TABLE `cdb_plugin_hidethreadsort_field` MODIFY `postip` varchar(45) NOT NULL DEFAULT '';\n";
$sql .= "ALTER TABLE `cdb_plugin_hidethreadsort_buy` MODIFY `postip` varchar(45) NOT NULL DEFAULT '';\n";

if($sql) {
	runquery($sql);
}

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnQueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2luc3RhbGwucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L3VwZ3JhZGUucGhw'));

?>