<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_hidethreadsort {

	public static $identifier = 'hidethreadsort';

    function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$this->setconfig = $setconfig;
    }

}

class mobileplugin_hidethreadsort_forum extends mobileplugin_hidethreadsort {
	
	function viewthread_top_mobile_output() {
		global $_G, $threadsort, $threadsortshow;
		$setconfig = $this->setconfig;
		$return = '';
		if($threadsort && $threadsortshow){

			loadcache(array('threadsort_option_'.$_G['thread']['sortid'], 'threadsort_template_'.$_G['thread']['sortid']));
			$sortoptionarray = $_G['cache']['threadsort_option_'.$_G['thread']['sortid']];
			$templatearray = $_G['cache']['threadsort_template_'.$_G['thread']['sortid']];

			$optionarray = C::t('#'.self::$identifier.'#hidethreadsort_field')->fetch_all_by_sortid($_G['thread']['sortid']);
			if(!$optionarray){
				return $return;
			}
			$optionlist = array();
			foreach($optionarray as $option) {
				if($option['forumid'] && $option['forumid'] != $_G['fid']){
					continue;
				}
				$option['parameters'] = unserialize($option['parameters']);
				$sortoption = $sortoptionarray[$option['optionid']];
				if($sortoption && TIMESTAMP - $_G['thread']['dateline'] >= $option['afterdays'] * 24 * 3600){
					$optionlist[$sortoption['identifier']] = $option;
				}
			}
			$this->optionlist = $optionlist;

			if($threadsortshow['typetemplate']){
				$typetemplate = '';
				if($templatearray['viewthread']) {
					foreach($sortoptionarray as $option) {
						$searchtitle[] = '/{('.$option['identifier'].')}/';
						$searchvalue[] = '/\[('.$option['identifier'].')value\]/';
						$searchvalue[] = '/{('.$option['identifier'].')_value}/';
						$searchunit[] = '/\[('.$option['identifier'].')unit\]/';
						$searchunit[] = '/{('.$option['identifier'].')_unit}/';
					}

					foreach(C::t('forum_typeoptionvar')->fetch_all_by_tid_optionid($_G['tid']) as $option) {
						$sortdataexpiration = $option['expiration'];
					}

					$threadexpiration = $sortdataexpiration ? dgmdate($sortdataexpiration) : lang('forum/misc', 'never_expired');
					$typetemplate = preg_replace(array("/\{expiration\}/i"), array($threadexpiration), stripslashes($templatearray['viewthread']));
					$typetemplate = preg_replace_callback($searchtitle, array(__CLASS__, "_callback_showoption_title"), $typetemplate);
					$typetemplate = preg_replace_callback($searchvalue, array(__CLASS__, "_callback_showoption_value"), $typetemplate);
					$typetemplate = preg_replace_callback($searchunit, array(__CLASS__, "_callback_showoption_unit"), $typetemplate);
				}

				$threadsortshow['typetemplate'] = $typetemplate;
			}elseif($threadsortshow['optionlist']){
				if($threadsortshow['optionlist'] != 'expire'){
					foreach($threadsortshow['optionlist'] as $key => $option) {
						if($setconfig['hide_empty'] && $option['value'] == ''){
							unset($threadsortshow['optionlist'][$key]);
						}else{
							$option['value'] = $this->_callback_showoption_value(array($key, $key));
							$threadsortshow['optionlist'][$key] = $option;
						}
					}
				}
			}
		}
		return $return;
	}

	function _callback_showoption_title($matches) {
		global $_G;
		$var = $matches[1];
		if($_G['forum_option'][$var]['title'] != '') {
			return $_G['forum_option'][$var]['title'];
		} else {
			return '';
		}
	}

	function _callback_showoption_value($matches) {
		global $_G;
		$setconfig = $this->setconfig;
		$optionlist = $this->optionlist;
		$var = $matches[1];
		if($_G['forum_option'][$var]['value'] != '' || $setconfig['valid_empty']) {
			//���߻�����߲�����
			if(($_G['uid'] && $_G['thread']['authorid'] == $_G['uid']) || $_G['forum']['ismoderator']){
				return $_G['forum_option'][$var]['value'];
			}
			$hideoption = $optionlist[$var];
			if($hideoption){
				//�涨�����ڲ�����
				if($hideoption['afterdays'] && $_G['thread']['dateline'] >= TIMESTAMP - $hideoption['afterdays'] * 24 * 3600){
					return $_G['forum_option'][$var]['value'];
				}
				switch ($hideoption['showtype']) {
					case "login":
						if($_G['uid']){
							return $_G['forum_option'][$var]['value'];
						}else{
							return $hideoption['parameters']['wapmsg'];
						}
						break;
					case "buy":
						if(in_array($_G['groupid'], $hideoption['parameters']['vipgroup'])){
							return $_G['forum_option'][$var]['value'];
						}
						if($hideoption['parameters']['credittids']){
							$hideoption['parameters']['credittids'] = preg_replace("/[\r\n]{1,2}/","\n", trim($hideoption['parameters']['credittids']));
							foreach(explode("\n", $hideoption['parameters']['credittids']) as $val) {
								list($credittid, $creditnum) = explode('=', $val);
								if($_G['tid'] == $credittid){
									$hideoption['parameters']['creditnum'] = intval($creditnum);
								}
							}
						}
						$hideoption['parameters']['wapmsg'] = str_replace(array("{buyurl}", "{creditnum}"), array("plugin.php?id=".self::$identifier.":payment&tid=$_G[tid]&optionid=$hideoption[optionid]", $hideoption['parameters']['creditnum']), $hideoption['parameters']['wapmsg']);
						if($_G['uid']){
							if($hideoption['parameters']['once']){
								$wherearr = array();
								$wherearr[] = "uid = ".$_G['uid'];
								$wherearr[] = "tid = ".$_G['tid'];
								$buylog = C::t('#'.self::$identifier.'#hidethreadsort_buy')->fetch_one_by_search_where($wherearr);
							}else{
								$wherearr = array();
								$wherearr[] = "uid = ".$_G['uid'];
								$wherearr[] = "tid = ".$_G['tid'];
								$wherearr[] = "optionid = ".$hideoption['optionid'];
								$buylog = C::t('#'.self::$identifier.'#hidethreadsort_buy')->fetch_one_by_search_where($wherearr);
							}
							if($buylog){
								return $_G['forum_option'][$var]['value'];
							}else{
								return $hideoption['parameters']['wapmsg'];
							}
						}else{
							return $hideoption['parameters']['wapmsg'];
						}
						break;
					case "vipuser":
						if(in_array($_G['groupid'], $hideoption['parameters']['vipgroup'])){
							return $_G['forum_option'][$var]['value'];
						}else{
							return $hideoption['parameters']['wapmsg'];
						}
						break;
					case "reply":
						if(in_array($_G['groupid'], $hideoption['parameters']['vipgroup'])){
							return $_G['forum_option'][$var]['value'];
						}
						$hideoption['parameters']['wapmsg'] = str_replace("{replyurl}", "forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]", $hideoption['parameters']['wapmsg']);
						if($_G['uid']){
							$replylog = C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']);
							if($replylog){
								return $_G['forum_option'][$var]['value'];
							}else{
								$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['tid']);
								return '<script type="text/javascript">if(typeof replyreload !== \'undefined\'){replyreload += \',\' + '.$firstpost['pid'].';}</script>'.$hideoption['parameters']['wapmsg'];
							}
						}else{
							$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_G['tid']);
							return '<script type="text/javascript">if(typeof replyreload !== \'undefined\'){replyreload += \',\' + '.$firstpost['pid'].';}</script>'.$hideoption['parameters']['wapmsg'];
						}
						break;
					case "credit":
						if(in_array($_G['groupid'], $hideoption['parameters']['vipgroup'])){
							return $_G['forum_option'][$var]['value'];
						}
						$hideoption['parameters']['wapmsg'] = str_replace("{credits}", $_G['member']['credits'], $hideoption['parameters']['wapmsg']);
						if($_G['member']['credits'] >= $hideoption['parameters']['creditnum']){
							return $_G['forum_option'][$var]['value'];
						}else{
							return $hideoption['parameters']['wapmsg'];
						}
						break;
					case "pwverify":
						if(in_array($_G['groupid'], $hideoption['parameters']['vipgroup'])){
							return $_G['forum_option'][$var]['value'];
						}
						$hideoption['parameters']['wapmsg'] = str_replace("{pwverifyurl}", "plugin.php?id=".self::$identifier.":pwverify&tid=$_G[tid]&optionid=$hideoption[optionid]", $hideoption['parameters']['wapmsg']);
						if($hideoption['parameters']['password'] == $_G['cookie']['hideoptionpw_'.$_G['tid'].'_'.$hideoption['optionid']]){
							return $_G['forum_option'][$var]['value'];
						}else{
							return $hideoption['parameters']['wapmsg'];
						}
						break;
					default:
						return $_G['forum_option'][$var]['value'];
						break;
				}
			}else{
				return $_G['forum_option'][$var]['value'];
			}
		} else {
			return '';
		}
	}

	function _callback_showoption_unit($matches) {
		global $_G;
		$var = $matches[1];
		if($_G['forum_option'][$var]['unit'] != '') {
			return $_G['forum_option'][$var]['unit'];
		} else {
			return '';
		}
	}


}



?>