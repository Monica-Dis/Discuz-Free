<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$setconfig = $_G['cache']['plugin'][CURMODULE];

require_once libfile('function/forum');

loadforum();
$thread = $_G['thread'];
if(!$thread || $thread['displayorder'] < 0) {
	showmessage('thread_nonexistence');
}
$_GET['optionid'] = intval($_GET['optionid']);
$hideoption = C::t('#'.CURMODULE.'#hidethreadsort_field')->fetch_by_sortid_optionid($_G['thread']['sortid'], $_GET['optionid']);
if(!$hideoption) {
	showmessage(lang('plugin/'.CURMODULE, 'field_nonexistence'));
}
loadcache('threadsort_option_'.$_G['thread']['sortid']);
$sortoptionarray = $_G['cache']['threadsort_option_'.$_G['thread']['sortid']];
$sortoption = $sortoptionarray[$hideoption['optionid']];
$hideoption['parameters'] = unserialize($hideoption['parameters']);


if(!submitcheck('pwverifysubmit', 1)) {

	include template(CURMODULE.':pwverify');

} else {

	if($_GET['pw'] != $hideoption['parameters']['password']) {
		showmessage(lang('plugin/'.CURMODULE, 'hidethreadsort_passwd_incorrect'));
	}

	dsetcookie('hideoptionpw_'.$_G['tid'].'_'.$hideoption['optionid'], $_GET['pw']);
	showmessage(lang('plugin/'.CURMODULE, 'hidethreadsort_passwd_correct'), 'forum.php?mod=viewthread&tid='.$_G['tid'].($_GET['from'] ? '&from='.$_GET['from'] : ''), array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));

}


