<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_hidethreadsort_field`;
CREATE TABLE `cdb_plugin_hidethreadsort_field` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sortid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `optionid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forumid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `afterdays` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `showtype` varchar(32) NOT NULL DEFAULT '',
  `parameters` text NOT NULL DEFAULT '',
  `postip` varchar(45) NOT NULL DEFAULT '',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_hidethreadsort_buy`;
CREATE TABLE `cdb_plugin_hidethreadsort_buy` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(32) NOT NULL DEFAULT '',
  `tid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `optionid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credititem` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `creditnum` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `postip` varchar(45) NOT NULL DEFAULT '',
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tid` (`tid`),
  KEY `optionid` (`tid`,`optionid`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnQueG1s'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfU0NfR0JLLnhtbA=='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfU0NfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2Rpc2N1el9wbHVnaW5faGlkZXRocmVhZHNvcnRfVENfVVRGOC54bWw='));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L3VwZ3JhZGUucGhw'));
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2hpZGV0aHJlYWRzb3J0L2luc3RhbGwucGhw'));

?>