<?php

/**
 *      author: ����
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

loadcache('plugin');
$setconfig = $_G['cache']['plugin'][$plugin['identifier']];
$setconfig['usergroup'] = (array)unserialize($setconfig['usergroup']);
$pluginurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field';

$op = in_array($_GET['op'], array('index','add','edit','optionlist','forumlist')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('savesubmit')) {
		$sortlist = DB::fetch_all('SELECT * FROM %t', array('forum_threadtype'), 'typeid');
		$optionlist = DB::fetch_all('SELECT * FROM %t', array('forum_typeoption'), 'optionid');
		$forumlist = DB::fetch_all('SELECT * FROM %t', array('forum_forum'), 'fid');
		$intkeys = array('sortid');
		$strkeys = array();
		$randkeys = array();
		$likekeys = array();
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$searchsortid = lang('plugin/'.$plugin['identifier'], 'field_sortid');
		$sortlistselect = sortlist_select($sortlist, 'sortid', true, $_GET['sortid']);
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$searchsortid</th><td>$sortlistselect</td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="hidethreadsort">
						<input type="hidden" name="pmod" value="field">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field');
		showtableheader(lang('plugin/'.$plugin['identifier'], 'field_list'). '<a href="'.$pluginurl.'&op=add" style="margin-left:10px">['.lang('plugin/'.$plugin['identifier'], 'field_add').']</a>');
		showsubtitle(array('del', lang('plugin/'.$plugin['identifier'], 'field_sortid'), lang('plugin/'.$plugin['identifier'], 'field_optionid'), lang('plugin/'.$plugin['identifier'], 'field_forumid'), lang('plugin/'.$plugin['identifier'], 'field_showtype'), 'operation'));
		$count = C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->count_by_search_where($wherearr);
		$list = C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
		foreach ($list as $value) {
			$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j');
			showtablerow('', array('class="td25"', '', '', '', '', 'class="td25"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$sortlist[$value['sortid']] ? $sortlist[$value['sortid']]['name'] : '/',
				$optionlist[$value['optionid']] ? $optionlist[$value['optionid']]['title'] : '/',
				$forumlist[$value['forumid']] ? $forumlist[$value['forumid']]['name'] : $lang['nolimit'],
				lang('plugin/'.$plugin['identifier'], 'field_showtype_'.$value['showtype']),
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">$lang[edit]</a>"
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('savesubmit', 'submit', 'select_all', '', $multipage, false);
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
	} else {
		if(is_array($_GET['delete'])) {
			C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->delete_by_id($_GET['delete']);
			updatecache('hidethreadsort:hidethreadsort_field');
		}
		cpmsg(lang('plugin/'.$plugin['identifier'], 'field_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field', 'succeed');
	}
} elseif($op == 'add' || ($op == 'edit' && $_GET['id'])) {
	if($op == 'edit') {
		$field = C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->fetch_by_id($_GET['id']);
		if(!$field) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'field_nonexistence'), '', 'error');
		}
		$field['parameters'] = unserialize($field['parameters']);
	}
	if(!submitcheck('savesubmit')) {
		if($op == 'edit') {
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field&op=edit&id='.$_GET['id'],'enctype');
			showtableheader(lang('plugin/'.$plugin['identifier'], 'field_edit'));
		} else {
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field&op=add','enctype');
			showtableheader(lang('plugin/'.$plugin['identifier'], 'field_add'));
		}
		$sortlist = array();
		$query = C::t('forum_threadtype')->fetch_all_for_order();
		foreach($query as $type) {
			$sortlist[] = array($type['typeid'], $type['name']);
		}
		showsetting(lang('plugin/'.$plugin['identifier'], 'field_sortid'), array('sortid', array_merge(array(array(0, $lang['select'])), $sortlist)), $field['sortid'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'field_sortid_comment'), "onchange=\"ajaxget('".$pluginurl."&op=optionlist&sortid='+this.options[this.selectedIndex].value, 'optionlist', 'optionlist');ajaxget('".$pluginurl."&op=forumlist&sortid='+this.options[this.selectedIndex].value, 'forumlist', 'forumlist');\"");
		showsetting(lang('plugin/'.$plugin['identifier'], 'field_optionid'), array('optionid', array(array(0, $lang['select']))), $field['optionid'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'field_optionid_comment'), 'id="optionlist"');
		showsetting(lang('plugin/'.$plugin['identifier'], 'field_forumid'), array('forumid', array(array(0, $lang['nolimit']))), $field['forumid'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'field_forumid_comment'), 'id="forumlist"');
		showsetting(lang('plugin/'.$plugin['identifier'], 'field_afterdays'), 'afterdays', $field['afterdays'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'field_afterdays_comment'));

		$adtypearray = array();
		$adtypes = array('login', 'buy', 'vipuser', 'reply', 'credit', 'pwverify');
		foreach($adtypes as $adtype) {
			$displayary = array();
			foreach($adtypes as $adtype1) {
				$displayary['showtype_'.$adtype1] = $adtype1 == $adtype ? '' : 'none';
			}
			$adtypearray[] = array($adtype, lang('plugin/'.$plugin['identifier'], 'field_showtype_'.$adtype), $displayary);
		}
		showsetting(lang('plugin/'.$plugin['identifier'], 'field_showtype'), array('showtype', $adtypearray), $field['showtype'] ? $field['showtype'] : 'login', 'mradio2', '', 0, lang('plugin/'.$plugin['identifier'], 'field_showtype_comment'));

		$grouplist = C::t('common_usergroup')->range_orderby_credit();

		showtagheader('tbody', 'showtype_login', !$field['showtype'] || $field['showtype'] == 'login');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_login'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_login_pcmsg'), 'parameters[login][pcmsg]', $field['showtype'] == 'login' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_login_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_login_wapmsg'), 'parameters[login][wapmsg]', $field['showtype'] == 'login' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_login_wapmsg_comment'));
		showtagfooter('tbody');

		showtagheader('tbody', 'showtype_buy', $field['showtype'] == 'buy');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_buy'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_vipgroup'), '', '', grouplist_select($grouplist, 'parameters[buy][vipgroup][]', true, $field['showtype'] == 'buy' ? $field['parameters']['vipgroup'] : ''), '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_vipgroup_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_credititem'), array('parameters[buy][credititem]', extcredit_select()), $field['showtype'] == 'buy' ? $field['parameters']['credititem'] : '', 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_credititem_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_creditnum'), 'parameters[buy][creditnum]', $field['showtype'] == 'buy' ? $field['parameters']['creditnum'] : '', 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_creditnum_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_credittids'), 'parameters[buy][credittids]', $field['showtype'] == 'buy' ? $field['parameters']['credittids'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_credittids_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_once'), 'parameters[buy][once]', $field['showtype'] == 'buy' ? $field['parameters']['once'] : 0, 'radio', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_once_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_pcmsg'), 'parameters[buy][pcmsg]', $field['showtype'] == 'buy' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_buy_wapmsg'), 'parameters[buy][wapmsg]', $field['showtype'] == 'buy' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_buy_wapmsg_comment'));
		showtagfooter('tbody');

		showtagheader('tbody', 'showtype_vipuser', $field['showtype'] == 'vipuser');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_vipuser'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_vipgroup'), '', '', grouplist_select($grouplist, 'parameters[vipuser][vipgroup][]', true, $field['showtype'] == 'vipuser' ? $field['parameters']['vipgroup'] : ''), '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_vipgroup_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_pcmsg'), 'parameters[vipuser][pcmsg]', $field['showtype'] == 'vipuser' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_wapmsg'), 'parameters[vipuser][wapmsg]', $field['showtype'] == 'vipuser' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_vipuser_wapmsg_comment'));
		showtagfooter('tbody');

		showtagheader('tbody', 'showtype_reply', $field['showtype'] == 'reply');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_reply'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_reply_vipgroup'), '', '', grouplist_select($grouplist, 'parameters[reply][vipgroup][]', true, $field['showtype'] == 'reply' ? $field['parameters']['vipgroup'] : ''), '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_reply_vipgroup_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_reply_pcmsg'), 'parameters[reply][pcmsg]', $field['showtype'] == 'reply' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_reply_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_reply_wapmsg'), 'parameters[reply][wapmsg]', $field['showtype'] == 'reply' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_reply_wapmsg_comment'));
		showtagfooter('tbody');

		showtagheader('tbody', 'showtype_credit', $field['showtype'] == 'credit');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_credit'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_credit_vipgroup'), '', '', grouplist_select($grouplist, 'parameters[credit][vipgroup][]', true, $field['showtype'] == 'credit' ? $field['parameters']['vipgroup'] : ''), '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_credit_vipgroup_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_credit_creditnum'), 'parameters[credit][creditnum]', $field['showtype'] == 'credit' ? $field['parameters']['creditnum'] : '', 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_credit_creditnum_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_credit_pcmsg'), 'parameters[credit][pcmsg]', $field['showtype'] == 'credit' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_credit_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_credit_wapmsg'), 'parameters[credit][wapmsg]', $field['showtype'] == 'credit' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_credit_wapmsg_comment'));
		showtagfooter('tbody');

		showtagheader('tbody', 'showtype_pwverify', $field['showtype'] == 'pwverify');
		showtitle(lang('plugin/'.$plugin['identifier'], 'field_showtype_pwverify'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_vipgroup'), '', '', grouplist_select($grouplist, 'parameters[pwverify][vipgroup][]', true, $field['showtype'] == 'pwverify' ? $field['parameters']['vipgroup'] : ''), '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_vipgroup_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_password'), 'parameters[pwverify][password]', $field['showtype'] == 'pwverify' ? $field['parameters']['password'] : '', 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_password_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_pcmsg'), 'parameters[pwverify][pcmsg]', $field['showtype'] == 'pwverify' ? $field['parameters']['pcmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_pcmsg_comment'));
		showsetting(lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_wapmsg'), 'parameters[pwverify][wapmsg]', $field['showtype'] == 'pwverify' ? $field['parameters']['wapmsg'] : '', 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'showtype_pwverify_wapmsg_comment'));
		showtagfooter('tbody');

		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*dis'.'m.tao'.'bao.com*/
		if($op == 'edit') {
			echo '<script type="text/JavaScript">ajaxget("'.$pluginurl.'&op=optionlist&sortid='.$field['sortid'].'&optionid='.$field['optionid'].'", "optionlist", "optionlist");ajaxget("'.$pluginurl.'&op=forumlist&sortid='.$field['sortid'].'&forumid='.$field['forumid'].'", "forumlist", "forumlist");</script>';
		}

	} else {
		$data = array(
			'sortid' => intval($_GET['sortid']),
			'optionid' => intval($_GET['optionid']),
			'forumid' => intval($_GET['forumid']),
			'afterdays' => intval($_GET['afterdays']),
			'showtype' => $_GET['showtype'] ? $_GET['showtype'] : 'login',
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		$data['parameters'] = $_GET['parameters'][$data['showtype']];

		$data['parameters'] = serialize($data['parameters']);

		if(!$data['sortid']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'field_sortid_empty'), '', 'error');
		}
		if(!$data['optionid']) {
			cpmsg(lang('plugin/'.$plugin['identifier'], 'field_optionid_empty'), '', 'error');
		}
		if($op == 'edit') {
			C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->update_by_id($_GET['id'], $data);
			updatecache('hidethreadsort:hidethreadsort_field');
			cpmsg(lang('plugin/'.$plugin['identifier'], 'field_updatesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field', 'succeed');
		} else {
			C::t('#'.$plugin['identifier'].'#hidethreadsort_field')->insert($data);
			updatecache('hidethreadsort:hidethreadsort_field');
			cpmsg(lang('plugin/'.$plugin['identifier'], 'field_addsucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=field', 'succeed');
		}
	}
} elseif($op == 'optionlist') {

	$typevararr = C::t('forum_typevar')->fetch_all_by_sortid($_GET['sortid'], 'ASC');
	$typeoptionarr = C::t('forum_typeoption')->fetch_all(array_keys($typevararr));
	$optionlist = '<option value="0">'.$lang['select'].'</option>';
	foreach($typevararr as $option) {
		if($option['optionid'] == $_GET['optionid']){
			$optionlist .= '<option value="'.$option['optionid'].'" selected>'.$typeoptionarr[$option['optionid']]['title'].'</option>';
		}else{
			$optionlist .= '<option value="'.$option['optionid'].'">'.$typeoptionarr[$option['optionid']]['title'].'</option>';
		}
	}

	include template('common/header');
	echo $optionlist;
	include template('common/footer');
	exit;
} elseif($op == 'forumlist') {

	$optionlist = '<option value="0">'.$lang['nolimit'].'</option>';
	$query = C::t('forum_forum')->fetch_all_for_threadsorts();
	$changetype = 'threadsorts';
	foreach($query as $forum) {
		$forum[$changetype] = dunserialize($forum[$changetype]);
		if(is_array($forum[$changetype]['types'])) {
			foreach($forum[$changetype]['types'] as $typeid => $name) {
				if($typeid == $_GET['sortid']){
					$optionlist .= '<option value="'.$forum['fid'].'"'.($forum['fid'] == $_GET['forumid'] ? ' selected' : '').'>'.$forum['name'].'</option>';
				}
			}
		}
	}

	include template('common/header');
	echo $optionlist;
	include template('common/footer');
	exit;
}

function sortlist_select($sortlist, $name='sortid', $shownull=true, $current='') {
	global $lang;
	$select = "<select id=\"$name\" name=\"$name\" class=\"ps vm\">";
	if($shownull) {
		$select .= '<option value="">'.$lang['select'].'</option>';
	}
	foreach ($sortlist as $value) {
		$selected = ($current && $current==$value['typeid']) ? 'selected="selected"' : '';
		$select .= "<option value=\"$value[typeid]\"$selected>$value[name]</option>";
	}
	$select .= "</select>";
	return $select;
}

function grouplist_select($grouplist, $name='usergroups[]', $shownull=true, $current='') {
	global $lang;
	$select = "<select name=\"$name\" size=\"10\" multiple=\"multiple\">";
	if($shownull) {
		$select .= '<option value=""'.(@in_array('', $current) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
	}
	foreach($grouplist as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $current) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$select .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
			($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
			($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
			'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
	$select .= "</select>";
	return $select;
}

function extcredit_select() {
	global $_G;
    $list = array();
	$list[] = array('', cplang('plugins_empty'));
	foreach($_G['setting']['extcredits'] as $i => $credit) {
		$extcredit = 'extcredits'.$i.' ('.$credit['title'].')';
		$list[] = array($i, $extcredit);
	}
	return $list;
}
//d'.'is'.'m.tao'.'ba'.'o.com
?>