<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$setconfig = $_G['cache']['plugin'][CURMODULE];

require_once libfile('function/forum');

loadforum();
$thread = $_G['thread'];
if(!$thread || $thread['displayorder'] < 0) {
	showmessage('thread_nonexistence');
}
$_GET['optionid'] = intval($_GET['optionid']);
$hideoption = C::t('#'.CURMODULE.'#hidethreadsort_field')->fetch_by_sortid_optionid($_G['thread']['sortid'], $_GET['optionid']);
if(!$hideoption) {
	showmessage(lang('plugin/'.CURMODULE, 'field_nonexistence'));
}
loadcache('threadsort_option_'.$_G['thread']['sortid']);
$sortoptionarray = $_G['cache']['threadsort_option_'.$_G['thread']['sortid']];
$sortoption = $sortoptionarray[$hideoption['optionid']];
$hideoption['parameters'] = unserialize($hideoption['parameters']);
if($hideoption['parameters']['once']){
	$wherearr = array();
	$wherearr[] = "uid = ".$_G['uid'];
	$wherearr[] = "tid = ".$_G['tid'];
	$buylog = C::t('#'.CURMODULE.'#hidethreadsort_buy')->fetch_one_by_search_where($wherearr);
}else{
	$wherearr = array();
	$wherearr[] = "uid = ".$_G['uid'];
	$wherearr[] = "tid = ".$_G['tid'];
	$wherearr[] = "optionid = ".$hideoption['optionid'];
	$buylog = C::t('#'.CURMODULE.'#hidethreadsort_buy')->fetch_one_by_search_where($wherearr);
}

if($buylog) {
	showmessage(lang('plugin/'.CURMODULE, 'pay_already'));
}

if($hideoption['parameters']['credittids']){
	$hideoption['parameters']['credittids'] = preg_replace("/[\r\n]{1,2}/","\n", trim($hideoption['parameters']['credittids']));
	foreach(explode("\n", $hideoption['parameters']['credittids']) as $val) {
		list($credittid, $creditnum) = explode('=', $val);
		if($_G['tid'] == $credittid){
			$hideoption['parameters']['creditnum'] = intval($creditnum);
		}
	}
}
$mycredit = getuserprofile('extcredits'.$hideoption['parameters']['credititem']);

if(!submitcheck('paysubmit')) {

	include template(CURMODULE.':payment');

} else {

	if($mycredit < $hideoption['parameters']['creditnum']) {
		showmessage(lang('plugin/'.CURMODULE, 'credit_notenough', array('credit_item' => $_G['setting']['extcredits'][$hideoption['parameters']['credititem']]['title'])));
	}

	updatemembercount($_G['uid'], array($hideoption['parameters']['credititem'] => - $hideoption['parameters']['creditnum']), 1, '', 0, '', lang('plugin/'.CURMODULE, 'pay_sort'), lang('plugin/'.CURMODULE, 'pay_sort_comment'));

	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'tid' => $_G['tid'],
		'optionid' => $hideoption['optionid'],
		'credititem' => $hideoption['parameters']['credititem'],
		'creditnum' => $hideoption['parameters']['creditnum'],
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	C::t('#'.CURMODULE.'#hidethreadsort_buy')->insert($data);
	if($setconfig['remind_mail']) {
		require_once libfile('function/mail');
		$res = sendmail($setconfig['remind_mail'], lang('plugin/'.CURMODULE, 'mail_title'), lang('plugin/'.CURMODULE, 'mail_content'));
	}

	showmessage(lang('plugin/'.CURMODULE, 'pay_succeed'), 'forum.php?mod=viewthread&tid='.$_G['tid'].($_GET['from'] ? '&from='.$_GET['from'] : ''), array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));

}
