<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tid = intval($_GET['tid']);

require_once libfile('function_forum', 'function');
$thread = get_thread_by_tid($tid);
if(!$thread) {
	showmessage('thread_nonexistence');
}

$page = max(1, $_G['page']);
$perpage = 20;
$start = ($page-1)*$perpage;
$mpurl = 'plugin.php?id='.CURMODULE.':viewaward&tid='.$tid;
$wherearr = array();
$wherearr[] = "tid = '".$tid."'";
$recordcount = C::t('#'.CURMODULE.'#lookaward_record')->count_by_search_where($wherearr);
$recordlist = C::t('#'.CURMODULE.'#lookaward_record')->fetch_all_by_search_where($wherearr, 'order by createtime desc', $start, $perpage);
$multipage = multi($recordcount, $perpage, $page, $mpurl);

include template(CURMODULE.':viewaward');

