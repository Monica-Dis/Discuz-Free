<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','lookaward');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=usergroup';
loadcache('plugin');
$setconfig = $_G['cache']['plugin'][IDENTIFIER];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}

if(!submitcheck('savesubmit')) {
	showtips(lang('plugin/'.IDENTIFIER, 'usergroup_tip'));
	showformheader('plugins&identifier='.IDENTIFIER.'&pmod=usergroup');
	showtableheader(lang('plugin/'.IDENTIFIER, 'usergroup_list'));
	showsubtitle(array(lang('plugin/'.IDENTIFIER, 'usergroup_name'), lang('plugin/'.IDENTIFIER, 'usergroup_credit'), lang('plugin/'.IDENTIFIER, 'usergroup_need_seconds'), lang('plugin/'.IDENTIFIER, 'usergroup_get_times'), lang('plugin/'.IDENTIFIER, 'usergroup_get_everytime')));
	loadcache('lookaward_usergroup');
	$lookaward_usergroup = $_G['cache']['lookaward_usergroup'];

	$query = C::t('common_usergroup')->range_orderby_credit();
	$grouplist = array();
	foreach($query as $value) {
		$group = array();
		if($lookaward_usergroup[$value['groupid']]){
			$group = $lookaward_usergroup[$value['groupid']];
		}else{
			$group = array(
				'groupid' => $value['groupid'],
				'credit_item' => 0,
				'credit_num' => '',
				'need_seconds' => 0,
				'get_times' => 0,
				'get_everytime' => 0,
			);
		}
		$group['grouptitle'] = $value['grouptitle'];
		$group['type'] = $value['type'] == 'special' && $value['radminid'] ? 'specialadmin' : $value['type'];
		if(!$setconfig['allow_usergroups'] || in_array($group['groupid'], $setconfig['allow_usergroups'])){
			$grouplist[$group['type']][] = $group;
		}
	}
	foreach ($grouplist as $key => $list) {
		echo '<tr><td colspan="5"><strong>'.$lang['usergroups_'.$key].'</strong></td></tr>';
		foreach ($list as $value) {
			showtablerow('', array(), array(
				$value['grouptitle'],
				'<input type="text" class="txt" name="credit_num['.$value['groupid'].']" value="'.$value['credit_num'].'" size="5" /> <select name="credit_item['.$value['groupid'].']">'.credit_option($value['credit_item']).'</select>',
				'<input type="text" class="txt" name="need_seconds['.$value['groupid'].']" value="'.$value['need_seconds'].'" size="3" />'.lang('plugin/'.IDENTIFIER, 'unit_second'),
				'<input type="text" class="txt" name="get_times['.$value['groupid'].']" value="'.$value['get_times'].'" size="3" />'.lang('plugin/'.IDENTIFIER, 'unit_time'),
				'<input type="text" class="txt" name="get_everytime['.$value['groupid'].']" value="'.$value['get_everytime'].'" size="3" />'.lang('plugin/'.IDENTIFIER, 'unit_second'),
			));
		}
	}

	showsubmit('savesubmit', 'submit');
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*Dism_taobao-com*/

} else {

	if(is_array($_GET['credit_num'])) {
		foreach($_GET['credit_num'] as $groupid => $val) {
			$groupconfig = C::t('#'.IDENTIFIER.'#lookaward_usergroup')->fetch_by_id($groupid);
			if($groupconfig){
				$query = C::t('#'.IDENTIFIER.'#lookaward_usergroup')->update($groupid, array(
					'credit_item' => intval($_GET['credit_item'][$groupid]) > 0 ? intval($_GET['credit_item'][$groupid]) : 0,
					'credit_num' => $_GET['credit_num'][$groupid],
					'need_seconds' => intval($_GET['need_seconds'][$groupid]) > 0 ? intval($_GET['need_seconds'][$groupid]) : 0,
					'get_times' => intval($_GET['get_times'][$groupid]) > 0 ? intval($_GET['get_times'][$groupid]) : 0,
					'get_everytime' => intval($_GET['get_everytime'][$groupid]) > 0 ? intval($_GET['get_everytime'][$groupid]) : 0,
				));
			}else{
				$query = C::t('#'.IDENTIFIER.'#lookaward_usergroup')->insert(array(
					'groupid' => $groupid,
					'credit_item' => intval($_GET['credit_item'][$groupid]) > 0 ? intval($_GET['credit_item'][$groupid]) : 0,
					'credit_num' => $_GET['credit_num'][$groupid],
					'need_seconds' => intval($_GET['need_seconds'][$groupid]) > 0 ? intval($_GET['need_seconds'][$groupid]) : 0,
					'get_times' => intval($_GET['get_times'][$groupid]) > 0 ? intval($_GET['get_times'][$groupid]) : 0,
					'get_everytime' => intval($_GET['get_everytime'][$groupid]) > 0 ? intval($_GET['get_everytime'][$groupid]) : 0,
				));
			}
		}
	}

	updatecache('lookaward:lookaward_usergroup');

	cpmsg(lang('plugin/'.IDENTIFIER, 'usergroup_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=usergroup', 'succeed');

}

function credit_option($cur = 0) {
	global $_G;
	$apicredits = '<option value="0">'.cplang('none').'</option>';
	foreach($_G['setting']['extcredits'] as $i => $credit) {
		$extcredit = 'extcredits'.$i.' ('.$credit['title'].')';
		$apicredits .= '<option value="'.$i.'" '.($i == $cur ? 'selected' : '').'>'.$extcredit.'</option>';
	}
	return $apicredits;
}

//From: Dism��taobao-com
?>