<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_lookaward_record`;
CREATE TABLE `cdb_plugin_lookaward_record` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `fid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `tid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credititem` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `getcredit` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tid` (`uid`, `tid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_lookaward_usergroup`;
CREATE TABLE `cdb_plugin_lookaward_usergroup` (
  `groupid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credit_item` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credit_num` varchar(60) NOT NULL DEFAULT '',
  `need_seconds` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `get_times` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `get_everytime` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`groupid`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>