<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_lookaward {

	public static $identifier = 'lookaward';

	function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
		if(in_array('', $setconfig['allow_forums'])) {
			$setconfig['allow_forums'] = array();
		}
		$setconfig['allow_thread'] = $setconfig['allow_thread'] ? explode(",", $setconfig['allow_thread']) : array();
		$setconfig['allow_groups'] = $setconfig['allow_groups'] ? explode(",", $setconfig['allow_groups']) : array();
		$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
		if(in_array('', $setconfig['allow_usergroups'])) {
			$setconfig['allow_usergroups'] = array();
		}
		$this->setconfig = $setconfig;
	}

}

class plugin_lookaward_forum extends plugin_lookaward {

	function viewthread_posttop_output() {
		global $_G,$postlist;
		$setconfig = $this->setconfig;
		$t = array();
		if($_GET['from'] == 'preview') {
			return $t;
		}
		loadcache('lookaward_usergroup');
		$lookaward_usergroup = $_G['cache']['lookaward_usergroup'];
		if($groupconfig = $lookaward_usergroup[$_G['groupid']]) {
			$setconfig['credit_item'] = $groupconfig['credit_item'] ? $groupconfig['credit_item'] : $setconfig['credit_item'];
			$setconfig['credit_num'] = $groupconfig['credit_num'] ? $groupconfig['credit_num'] : $setconfig['credit_num'];
			$setconfig['need_seconds'] = $groupconfig['need_seconds'] ? $groupconfig['need_seconds'] : $setconfig['need_seconds'];
			$setconfig['get_times'] = $groupconfig['get_times'] ? $groupconfig['get_times'] : $setconfig['get_times'];
			$setconfig['get_everytime'] = $groupconfig['get_everytime'] ? $groupconfig['get_everytime'] : $setconfig['get_everytime'];
		}
		if(!$setconfig['credit_item'] || !$setconfig['credit_num']) {
			return '';
		}
		if(strexists($setconfig['credit_num'], "|")) {
			$credit_num = explode("|", $setconfig['credit_num']);
			if(count($credit_num) > 2){
				$setconfig['credit_num'] = $credit_num[array_rand($credit_num)];
				$setconfig['credit_num'] = intval($setconfig['credit_num']);
			}else{
				$credit_num[0] = intval($credit_num[0]);
				$credit_num[1] = intval($credit_num[1]);
				if($credit_num[0] > $credit_num[1]){
					$setconfig['credit_num'] = 0;
				}else{
					$setconfig['credit_num'] = mt_rand($credit_num[0], $credit_num[1]);
				}
			}
		}else{
			$setconfig['credit_num'] = intval($setconfig['credit_num']);
		}
		if($setconfig['credit_num'] < 1){
			return '';
		}
		$setconfig['tip_text'] = str_replace(array('{need_seconds}', '{credit_num}', '{credit_unit}', '{credit_item}'), array($setconfig['need_seconds'], $setconfig['credit_num'], $_G['setting']['extcredits'][$setconfig['credit_item']]['unit'], $_G['setting']['extcredits'][$setconfig['credit_item']]['title']), $setconfig['tip_text']);
		if((($setconfig['allow_thread'] && in_array($_G['tid'], $setconfig['allow_thread'])) || (!$setconfig['allow_thread'] && (!$setconfig['allow_forums'] || in_array($_G['fid'], $setconfig['allow_forums'])))) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])) && ($setconfig['open_author'] || $_G['thread']['authorid'] != $_G['uid'])){
			foreach($postlist as $post) {
				if($post['first']){
					$todaycount = $lastrecordtime = $lastsamerecordtime = $need_lefttime = 0;
					if($_G['uid']){
						$wherearr = array();
						$wherearr[] = "uid = '".$_G['uid']."'";
						$wherearr[] = "createtime >= '".dmktime(dgmdate($_G['timestamp'], 'd'))."'";
						$todaycount = C::t('#'.self::$identifier.'#lookaward_record')->count_by_search_where($wherearr);
						if($setconfig['get_everytime']){
							$wherearr = array();
							$wherearr[] = "uid = '".$_G['uid']."'";
							$lastrecord = C::t('#'.self::$identifier.'#lookaward_record')->fetch_one_by_search_where($wherearr, 'order by createtime desc');
							if($lastrecord){
								$lastrecordtime = $lastrecord['createtime'];
								$need_lefttime = $setconfig['get_everytime'] - ($_G['timestamp'] - $lastrecordtime);
							}
						}
						$wherearr = array();
						$wherearr[] = "uid = '".$_G['uid']."'";
						$wherearr[] = "tid = '".$_G['tid']."'";
						if($setconfig['same_thread']){
							$wherearr[] = "createtime >= '".($_G['timestamp'] - $setconfig['same_thread']*3600)."'";
						}
						$lastsamerecord = C::t('#'.self::$identifier.'#lookaward_record')->fetch_one_by_search_where($wherearr, 'order by createtime desc');
						if($lastsamerecord){
							$lastsamerecordtime = $lastsamerecord['createtime'];
							if($setconfig['same_thread']){
								$need_lefttime = $need_lefttime > $setconfig['same_thread'] * 3600 - ($_G['timestamp'] - $lastsamerecordtime) ? $need_lefttime : $setconfig['same_thread'] * 3600 - ($_G['timestamp'] - $lastsamerecordtime);
							}else{
								$need_lefttime = 0;
							}
						}
						if($need_lefttime > 0){
							foreach (array(3600 => lang('plugin/'.self::$identifier, 'unit_hour'), 60 => lang('plugin/'.self::$identifier, 'unit_minute'), 1 => lang('plugin/'.self::$identifier, 'unit_second')) as $key => $value) {
								if ($need_lefttime >= $key) $output_lefttime .= floor($need_lefttime/$key) . $value;
								$need_lefttime %= $key;
							}
							$setconfig['nexttip_text'] = str_replace(array('{need_lefttime}'), array($output_lefttime), $setconfig['nexttip_text']);
						}else{
							$setconfig['nexttip_text'] = '';
						}
					}
					if(!$setconfig['get_times'] || $todaycount < $setconfig['get_times']){
						$hash = authcode("$_G[tid]\t$setconfig[credit_num]\t$_G[timestamp]", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16)));
						$hash = urlencode($hash);
						if($setconfig['html_pc']){
							$setconfig['html_pc'] = str_replace(array('{credit_num}', '{credit_unit}', '{credit_item}', '{get_url}', '{need_seconds}'), array($setconfig['credit_num'], $_G['setting']['extcredits'][$setconfig['credit_item']]['unit'], $_G['setting']['extcredits'][$setconfig['credit_item']]['title'], "plugin.php?id=lookaward:index&hash=$hash", $setconfig['need_seconds']), $setconfig['html_pc']);
						}
						include template(self::$identifier.':viewthread');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

	function viewthread_postbottom_output() {
		global $_G,$postlist;
		$setconfig = $this->setconfig;
		$t = array();
		if($setconfig['records_pc']){
			foreach($postlist as $post) {
				if($post['first']){
					$wherearr = array();
					$wherearr[] = "tid = '".$_G['tid']."'";
					$recordcount = C::t('#'.self::$identifier.'#lookaward_record')->count_by_search_where($wherearr);
					if($recordcount){
						$recordlist = C::t('#'.self::$identifier.'#lookaward_record')->fetch_all_by_search_where($wherearr, 'order by createtime desc', 0, $setconfig['records_pc']);
						include template(self::$identifier.':showaward');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

}

class plugin_lookaward_group extends plugin_lookaward {

	function viewthread_posttop_output() {
		global $_G,$postlist;
		$setconfig = $this->setconfig;
		$t = array();
		if($_GET['from'] == 'preview') {
			return $t;
		}
		loadcache('lookaward_usergroup');
		$lookaward_usergroup = $_G['cache']['lookaward_usergroup'];
		if($groupconfig = $lookaward_usergroup[$_G['groupid']]) {
			$setconfig['credit_item'] = $groupconfig['credit_item'] ? $groupconfig['credit_item'] : $setconfig['credit_item'];
			$setconfig['credit_num'] = $groupconfig['credit_num'] ? $groupconfig['credit_num'] : $setconfig['credit_num'];
			$setconfig['need_seconds'] = $groupconfig['need_seconds'] ? $groupconfig['need_seconds'] : $setconfig['need_seconds'];
			$setconfig['get_times'] = $groupconfig['get_times'] ? $groupconfig['get_times'] : $setconfig['get_times'];
			$setconfig['get_everytime'] = $groupconfig['get_everytime'] ? $groupconfig['get_everytime'] : $setconfig['get_everytime'];
		}
		if(!$setconfig['credit_item'] || !$setconfig['credit_num']) {
			return '';
		}
		if(strexists($setconfig['credit_num'], "|")) {
			$credit_num = explode("|", $setconfig['credit_num']);
			if(count($credit_num) > 2){
				$setconfig['credit_num'] = $credit_num[array_rand($credit_num)];
				$setconfig['credit_num'] = intval($setconfig['credit_num']);
			}else{
				$credit_num[0] = intval($credit_num[0]);
				$credit_num[1] = intval($credit_num[1]);
				if($credit_num[0] > $credit_num[1]){
					$setconfig['credit_num'] = 0;
				}else{
					$setconfig['credit_num'] = mt_rand($credit_num[0], $credit_num[1]);
				}
			}
		}else{
			$setconfig['credit_num'] = intval($setconfig['credit_num']);
		}
		if($setconfig['credit_num'] < 1){
			return '';
		}
		$setconfig['tip_text'] = str_replace(array('{need_seconds}', '{credit_num}', '{credit_unit}', '{credit_item}'), array($setconfig['need_seconds'], $setconfig['credit_num'], $_G['setting']['extcredits'][$setconfig['credit_item']]['unit'], $_G['setting']['extcredits'][$setconfig['credit_item']]['title']), $setconfig['tip_text']);

		if((!$setconfig['allow_groups'] || $this->_allow_groups($_G['forum'], $setconfig['allow_groups'])) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])) && ($setconfig['open_author'] || $_G['thread']['authorid'] != $_G['uid'])){
			foreach($postlist as $post) {
				if($post['first']){
					$todaycount = $lastrecordtime = $lastsamerecordtime = $need_lefttime = 0;
					if($_G['uid']){
						$wherearr = array();
						$wherearr[] = "uid = '".$_G['uid']."'";
						$wherearr[] = "createtime >= '".dmktime(dgmdate($_G['timestamp'], 'd'))."'";
						$todaycount = C::t('#'.self::$identifier.'#lookaward_record')->count_by_search_where($wherearr);
						if($setconfig['get_everytime']){
							$wherearr = array();
							$wherearr[] = "uid = '".$_G['uid']."'";
							$lastrecord = C::t('#'.self::$identifier.'#lookaward_record')->fetch_one_by_search_where($wherearr, 'order by createtime desc');
							if($lastrecord){
								$lastrecordtime = $lastrecord['createtime'];
								$need_lefttime = $setconfig['get_everytime'] - ($_G['timestamp'] - $lastrecordtime);
							}
						}
						$wherearr = array();
						$wherearr[] = "uid = '".$_G['uid']."'";
						$wherearr[] = "tid = '".$_G['tid']."'";
						if($setconfig['same_thread']){
							$wherearr[] = "createtime >= '".($_G['timestamp'] - $setconfig['same_thread']*3600)."'";
						}
						$lastsamerecord = C::t('#'.self::$identifier.'#lookaward_record')->fetch_one_by_search_where($wherearr, 'order by createtime desc');
						if($lastsamerecord){
							$lastsamerecordtime = $lastsamerecord['createtime'];
							if($setconfig['same_thread']){
								$need_lefttime = $need_lefttime > $setconfig['same_thread'] * 3600 - ($_G['timestamp'] - $lastsamerecordtime) ? $need_lefttime : $setconfig['same_thread'] * 3600 - ($_G['timestamp'] - $lastsamerecordtime);
							}else{
								$need_lefttime = 0;
							}
						}
						if($need_lefttime > 0){
							foreach (array(3600 => lang('plugin/'.self::$identifier, 'unit_hour'), 60 => lang('plugin/'.self::$identifier, 'unit_minute'), 1 => lang('plugin/'.self::$identifier, 'unit_second')) as $key => $value) {
								if ($need_lefttime >= $key) $output_lefttime .= floor($need_lefttime/$key) . $value;
								$need_lefttime %= $key;
							}
							$setconfig['nexttip_text'] = str_replace(array('{need_lefttime}'), array($output_lefttime), $setconfig['nexttip_text']);
						}else{
							$setconfig['nexttip_text'] = '';
						}
					}
					if(!$setconfig['get_times'] || $todaycount < $setconfig['get_times']){
						$hash = authcode("$_G[tid]\t$setconfig[credit_num]\t$_G[timestamp]", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16)));
						$hash = urlencode($hash);
						if($setconfig['html_pc']){
							$setconfig['html_pc'] = str_replace(array('{credit_num}', '{credit_unit}', '{credit_item}', '{get_url}', '{need_seconds}'), array($setconfig['credit_num'], $_G['setting']['extcredits'][$setconfig['credit_item']]['unit'], $_G['setting']['extcredits'][$setconfig['credit_item']]['title'], "plugin.php?id=lookaward:index&hash=$hash", $setconfig['need_seconds']), $setconfig['html_pc']);
						}
						include template(self::$identifier.':viewthread');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

	function viewthread_postbottom_output() {
		global $_G,$postlist;
		$setconfig = $this->setconfig;
		$t = array();
		if($setconfig['records_pc']){
			foreach($postlist as $post) {
				if($post['first']){
					$wherearr = array();
					$wherearr[] = "tid = '".$_G['tid']."'";
					$recordcount = C::t('#'.self::$identifier.'#lookaward_record')->count_by_search_where($wherearr);
					if($recordcount){
						$recordlist = C::t('#'.self::$identifier.'#lookaward_record')->fetch_all_by_search_where($wherearr, 'order by createtime desc', 0, $setconfig['records_pc']);
						include template(self::$identifier.':showaward');
						$t[] = $return;
					}
				}
			}
		}
		return $t;
	}

	function _allow_groups($forum, $groupids) {
		global $_G;
		if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
			return false;
		}
		loadcache('grouptype');
		$groupsecond = $_G['cache']['grouptype']['second'];
		if($forum['type'] == 'sub') {
			$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
		} else {
			$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
		}
		$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
		$firsttype = $_G['cache']['grouptype']['first'][$firstid];
		if($firsttype && in_array($firsttype['fid'], $groupids)) {
			return true;
		}
		if($secondtype && in_array($secondtype['fid'], $groupids)) {
			return true;
		}
		return false;
	}

}
//From: Dism��taobao��com
?>