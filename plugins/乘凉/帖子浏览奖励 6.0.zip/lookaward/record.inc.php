<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','lookaward');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=record';

if(!submitcheck('submit')) {
	$intkeys = array('tid');
	$strkeys = array();
	$randkeys = array();
	$likekeys = array('username');
	$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
	foreach($likekeys as $k) {
		$_GET[$k] = dhtmlspecialchars($_GET[$k]);
	}
	$wherearr = $results['wherearr'];
	$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
	$adminscript = ADMINSCRIPT;
	$searchtid = lang('plugin/'.IDENTIFIER, 'record_tid');
	echo <<<SEARCH
	<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
		<div style="margin-top:8px;">
		<table cellspacing="3" cellpadding="3">
			<tr>
				<th>$lang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
				<th>$searchtid</th><td><input type="text" class="txt" name="tid" value="$_GET[tid]"></td>
				<td>
					<input type="hidden" name="action" value="plugins">
					<input type="hidden" name="identifier" value="lookaward">
					<input type="hidden" name="pmod" value="record">
					<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
				</td>
			</tr>
		</table>
		</div>
	</form>
	<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
	$perpage = 30;
	$start = ($page-1)*$perpage;
	showformheader('plugins&identifier='.IDENTIFIER.'&pmod=record');
	showtableheader(lang('plugin/'.IDENTIFIER, 'record_list'));
	showsubtitle(array('del', 'uid', 'username', 'subject', lang('plugin/'.IDENTIFIER, 'record_getcredit'), 'ip', lang('plugin/'.IDENTIFIER, 'record_createtime')));
	$count = C::t('#'.IDENTIFIER.'#lookaward_record')->count_by_search_where($wherearr);
	$list = C::t('#'.IDENTIFIER.'#lookaward_record')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
	require_once libfile('function_forum', 'function');
	foreach ($list as $value) {
		$thread = get_thread_by_tid($value['tid']);
		$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
		showtablerow('', array('class="td25"', 'class="td32"', 'class="td24"', '', 'class="td24"', 'class="td24"', 'class="td24"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
			$value['uid'],
			$value['username'],
			'<a href="forum.php?mod=viewthread&tid='.$value['tid'].'" target="_blank">'.$thread['subject'].'</a>',
			$_G['setting']['extcredits'][$value['credititem']]['title']." +".$value['getcredit']." ".$_G['setting']['extcredits'][$value['credititem']]['unit'],
			$value['postip'],
			$value['createtime']
		));
	}
	$multipage = multi($count, $perpage, $page, $mpurl);

	showsubmit('submit', 'submit', 'select_all', '', $multipage);
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*Dism_taobao-com*/
} else {
	if(is_array($_GET['delete'])) {
		C::t('#'.IDENTIFIER.'#lookaward_record')->delete_by_id($_GET['delete']);
	}
	cpmsg(lang('plugin/'.IDENTIFIER, 'record_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=record', 'succeed');
}

//From: Dism��taobao-com
?>