<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_forums'] = (array)unserialize($setconfig['allow_forums']);
if(in_array('', $setconfig['allow_forums'])) {
	$setconfig['allow_forums'] = array();
}
$setconfig['allow_thread'] = $setconfig['allow_thread'] ? explode(",", $setconfig['allow_thread']) : array();
$setconfig['allow_groups'] = $setconfig['allow_groups'] ? explode(",", $setconfig['allow_groups']) : array();
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}
loadcache('lookaward_usergroup');
$lookaward_usergroup = $_G['cache']['lookaward_usergroup'];

if($groupconfig = $lookaward_usergroup[$_G['groupid']]) {
	$setconfig['credit_item'] = $groupconfig['credit_item'] ? $groupconfig['credit_item'] : $setconfig['credit_item'];
	$setconfig['credit_num'] = $groupconfig['credit_num'] ? $groupconfig['credit_num'] : $setconfig['credit_num'];
	$setconfig['need_seconds'] = $groupconfig['need_seconds'] ? $groupconfig['need_seconds'] : $setconfig['need_seconds'];
	$setconfig['get_times'] = $groupconfig['get_times'] ? $groupconfig['get_times'] : $setconfig['get_times'];
	$setconfig['get_everytime'] = $groupconfig['get_everytime'] ? $groupconfig['get_everytime'] : $setconfig['get_everytime'];
}

if(!$setconfig['credit_item'] || !$setconfig['credit_num']) {
	showmessage('parameters_error');
}

$tid = $getcredit = $timestamp = 0;
$_GET['hash'] = empty($_GET['hash']) ? '' : $_GET['hash'];
if($_GET['hash']) {
	list($tid, $getcredit, $timestamp) = explode("\t", authcode($_GET['hash'], 'DECODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16))));
	$tid = intval($tid);
	$getcredit = intval($getcredit);
}

if($tid && $getcredit && $timestamp) {
	if($setconfig['allow_usergroups'] && !in_array($_G['groupid'], $setconfig['allow_usergroups'])){
		showmessage(lang('plugin/'.CURMODULE, 'lookaward_usergroup_notallow'));
	}
	require_once libfile('function_forum', 'function');
	$thread = get_thread_by_tid($tid);
	if(!$thread) {
		showmessage('thread_nonexistence');
	}
	$forum = C::t('forum_forum')->fetch_info_by_fid($thread['fid']);
	if($forum['status'] == 3){
		if($setconfig['allow_groups'] && !_allow_groups($forum, $setconfig['allow_groups'])){
			showmessage(lang('plugin/'.CURMODULE, 'lookaward_forum_notallow'));
		}
	}else{
		if($setconfig['allow_thread']){
			if(!in_array($thread['tid'], $setconfig['allow_thread'])){
				showmessage(lang('plugin/'.CURMODULE, 'lookaward_thread_notallow'));
			}
		}else{
			if($setconfig['allow_forums'] && !in_array($thread['fid'], $setconfig['allow_forums'])){
				showmessage(lang('plugin/'.CURMODULE, 'lookaward_forum_notallow'));
			}
		}
	}
	//����¥����ȡ����
	if(!$setconfig['open_author'] && $thread['authorid'] == $_G['uid']){
		showmessage(lang('plugin/'.CURMODULE, 'lookaward_author_cannotget'));
	}
	//������ͬ������ȡ
	$wherearr = array();
	$wherearr[] = "uid = '".$_G['uid']."'";
	$wherearr[] = "tid = '".$thread['tid']."'";
	if($setconfig['same_thread']){
		$wherearr[] = "createtime >= '".($_G['timestamp'] - $setconfig['same_thread']*3600)."'";
	}
	$recordcount = C::t('#'.CURMODULE.'#lookaward_record')->count_by_search_where($wherearr);
	if($recordcount){
		showmessage(lang('plugin/'.CURMODULE, 'lookaward_already_get'));
	}
	//����ÿ�ս�������
	if($setconfig['get_times']){
		$wherearr = array();
		$wherearr[] = "uid = '".$_G['uid']."'";
		$wherearr[] = "createtime >= '".dmktime(dgmdate($_G['timestamp'], 'd'))."'";
		$todaycount = C::t('#'.CURMODULE.'#lookaward_record')->count_by_search_where($wherearr);
		if($todaycount >= $setconfig['get_times']){
			showmessage(lang('plugin/'.CURMODULE, 'lookaward_today_limit'));
		}
	}
	//���ƽ������ʱ��
	if($setconfig['get_everytime']){
		$wherearr = array();
		$wherearr[] = "uid = '".$_G['uid']."'";
		$lastrecord = C::t('#'.CURMODULE.'#lookaward_record')->fetch_one_by_search_where($wherearr, 'order by createtime desc');
		if($lastrecord && $_G['timestamp'] - $lastrecord['createtime'] < $setconfig['get_everytime']){
			showmessage(lang('plugin/'.CURMODULE, 'lookaward_forbid_everytime'));
		}
	}
	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'fid' => $thread['fid'],
		'tid' => $thread['tid'],
		'credititem' => $setconfig['credit_item'],
		'getcredit' => $getcredit,
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	C::t('#'.CURMODULE.'#lookaward_record')->insert($data);
	updatemembercount($_G['uid'], array('extcredits'.$setconfig['credit_item'] => $getcredit), 1, '', 0, '', lang('plugin/'.CURMODULE, 'lookaward_getcredit'), lang('plugin/'.CURMODULE, 'lookaward_getcredit_desc'));

	//�������߽���
	if(strexists($setconfig['author_return'], "|")) {
		$credit_num = explode("|", $setconfig['author_return']);
		if(count($credit_num) > 2){
			$setconfig['author_return'] = $credit_num[array_rand($credit_num)];
			$setconfig['author_return'] = intval($setconfig['author_return']);
		}else{
			$credit_num[0] = intval($credit_num[0]);
			$credit_num[1] = intval($credit_num[1]);
			if($credit_num[0] > $credit_num[1]){
				$setconfig['author_return'] = 0;
			}else{
				$setconfig['author_return'] = mt_rand($credit_num[0], $credit_num[1]);
			}
		}
	}else{
		$setconfig['author_return'] = intval($setconfig['author_return']);
	}
	if($setconfig['author_return'] > 0){
		updatemembercount($thread['authorid'], array('extcredits'.$setconfig['credit_item'] => $setconfig['author_return']), 1, '', 0, '', lang('plugin/'.CURMODULE, 'lookaward_authorcredit'), lang('plugin/'.CURMODULE, 'lookaward_authorcredit_desc'));
	}

	//���Ⱥ�齱��
	if($forum['status'] == 3){
		//����Ⱥ��
		if(file_exists(DISCUZ_ROOT.'./source/plugin/'.CURMODULE.'/extend/moderator.inc.php')){
			@include DISCUZ_ROOT.'./source/plugin/'.CURMODULE.'/extend/moderator.inc.php';
		}
	}

	showmessage(lang('plugin/'.CURMODULE, 'lookaward_add_succeed'), dreferer(), array('getcredit' => $getcredit, 'creditunit' => $_G['setting']['extcredits'][$setconfig['credit_item']]['unit'], 'credititem' => $_G['setting']['extcredits'][$setconfig['credit_item']]['title'], 'closetime' => 4), array('showmsg' => true, 'closetime' => 4, 'alert' => 'right'));
}else{
	showmessage('parameters_error');
}


function _allow_groups($forum, $groupids) {
	global $_G;
	if(empty($forum) || empty($forum['fid']) || empty($forum['name'])) {
		return false;
	}
	loadcache('grouptype');
	$groupsecond = $_G['cache']['grouptype']['second'];
	if($forum['type'] == 'sub') {
		$secondtype = !empty($groupsecond[$forum['fup']]) ? $groupsecond[$forum['fup']] : array();
	} else {
		$secondtype = !empty($groupsecond[$forum['fid']]) ? $groupsecond[$forum['fid']] : array();
	}
	$firstid = !empty($secondtype) ? $secondtype['fup'] : (!empty($forum['fup']) ? $forum['fup'] : $forum['fid']);
	$firsttype = $_G['cache']['grouptype']['first'][$firstid];
	if($firsttype && in_array($firsttype['fid'], $groupids)) {
		return true;
	}
	if($secondtype && in_array($secondtype['fid'], $groupids)) {
		return true;
	}
	return false;
}