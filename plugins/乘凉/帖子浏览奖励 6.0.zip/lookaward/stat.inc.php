<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','lookaward');

$all_stat = $xa = $stat_person = $stat_time = $stat_score = array();

$all_stat["person"] = DB::result_first("SELECT COUNT(distinct uid) FROM ".DB::table('plugin_lookaward_record'));
$all_stat["person"] = $all_stat["person"] ? $all_stat["person"] : 0;
$all_stat["time"] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_lookaward_record'));
$all_stat["time"] = $all_stat["time"] ? $all_stat["time"] : 0;
$all_stat["score"] = DB::result_first("SELECT SUM(getcredit) FROM ".DB::table('plugin_lookaward_record'));
$all_stat["score"] = $all_stat["score"] ? $all_stat["score"] : 0;

for($i = 15; $i >= 0; $i--) {
    $date = dgmdate($_G['timestamp'] - $i*60*60*24, 'Y-m-d');
    $xa[$date] = substr($date, 0, 4).'<br/>'.substr($date, 5);
    $stat_person[$date] = DB::result_first("SELECT COUNT(distinct uid) FROM ".DB::table('plugin_lookaward_record')." WHERE createtime >= '".dmktime($date)."' and createtime < '".(dmktime($date) + 60*60*24)."'");
    $stat_person[$date] = $stat_person[$date] ? $stat_person[$date] : 0;
    $stat_time[$date] = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_lookaward_record')." WHERE createtime >= '".dmktime($date)."' and createtime < '".(dmktime($date) + 60*60*24)."'");
    $stat_time[$date] = $stat_time[$date] ? $stat_time[$date] : 0;
    $stat_score[$date] = DB::result_first("SELECT SUM(getcredit) FROM ".DB::table('plugin_lookaward_record')." WHERE createtime >= '".dmktime($date)."' and createtime < '".(dmktime($date) + 60*60*24)."'");
    $stat_score[$date] = $stat_score[$date] ? $stat_score[$date] : 0;
}

$xas = "'".implode('\',\'', $xa)."'";
$stat_persons = implode(',', $stat_person);
$stat_times = implode(',', $stat_time);
$stat_scores = implode(',', $stat_score);

$langarray = array('stat_createtime', 'stat_persons', 'stat_times', 'stat_scores', 'stat_allpersons', 'stat_alltimes', 'stat_allscores');
$lang = array();
foreach($langarray as $l) {
    $lang[$l] = lang('plugin/'.IDENTIFIER, $l);
}

echo <<<EOF
<style>
.all_stat{width: 100%;border-collapse:separate;}
.all_stat td{background:#eee;width:33.33333%;padding: 10px 15px !important;}
.all_stat p{color: #09C;font-size: 30px;margin-top:10px;}
</style>
<table class="all_stat" cellspacing="10" cellpadding="10"><tr><td><div>$lang[stat_allpersons]</div><p>$all_stat[person]</p></td><td><div>$lang[stat_alltimes]</div><p>$all_stat[time]</p></td><td><div>$lang[stat_allscores]</div><p>$all_stat[score]</p></td></tr></table>
<script src="./source/plugin/lookaward/js/jquery.min.js"></script>
<script type="text/javascript" src="./source/plugin/lookaward/js/highcharts.js"></script>
<script type="text/javascript">
var jq=$.noConflict();
jq(function () {
    jq('#chart-container').highcharts({
        chart: {type: 'line'},
        title: {text: ''},
        xAxis: {categories: [$xas]},
        yAxis: {min:0, title: {text: ''}, plotLines: [{value: 0, width: 1, color: '#808080'}]},
        plotOptions: {line: {dataLabels: { enabled: false},enableMouseTracking: true}},
        series: [{name: '$lang[stat_persons]', data: [$stat_persons]}, {name: '$lang[stat_times]', data: [$stat_times]}, {name: '$lang[stat_scores]', data: [$stat_scores]}]
    });
});
</script>
<div id="chart-container" style="min-width:800px;height:400px"></div>
EOF;
$xa = array_reverse($xa, true);
showtableheader('');
showsubtitle(array($lang['stat_createtime'], $lang['stat_persons'], $lang['stat_times'], $lang['stat_scores']));
foreach($xa as $key=>$value) {
    showtablerow('', array(), array(
        $key,
        $stat_person[$key],
        $stat_time[$key],
        $stat_score[$key]
    ));
}
showtablefooter(); /*dis'.'m.tao'.'bao.com*/

?>