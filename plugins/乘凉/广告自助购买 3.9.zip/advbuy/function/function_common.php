<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function advbuy_showarea($showarea) {
	global $_G;
	$advreturn = '';
	loadcache('plugin');
	$setconfig = $_G['cache']['plugin']['advbuy'];
	$wherearr = array();
	$wherearr[] = "showarea = '$showarea'";
	$advpalcelist = C::t('#advbuy#advbuy_place')->fetch_all_by_search_where($wherearr, 'order by displayorder asc');
	foreach($advpalcelist as $key => $advpalce) {
		if($advpalce['status']){
			$advwidth = round(100/$advpalce['listnum'], 2).'%';
			$wherearr = array();
			$wherearr[] = "placeid = '".$advpalce['id']."'";
			$wherearr[] = "status = '1'";
			$advlist = C::t('#advbuy#advbuy_adv')->fetch_all_by_search_where($wherearr, 'order by displayorder asc');
			$wherearr = array();
			$wherearr[] = "placeid = '".$advpalce['id']."'";
			$wherearr[] = "endtime > '".$_G['timestamp']."'";
			$recordarr = C::t('#advbuy#advbuy_record')->fetch_all_by_search_where($wherearr, 'order by endtime desc');
			foreach($recordarr as $value){
				if($setconfig['change_url']){
					$hash = authcode("$value[id]\t$_G[timestamp]", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16)));
					$hash = urlencode($hash);
					$value['linkurl'] = "plugin.php?id=advbuy:jump&hash=".$hash;
				}
				$value['image'] = $value['image'] ? $_G['setting']['attachurl'].'advbuy/'.$value['image'] : '';
				$advrecord[$value['advid']] = $value;
			}
			if($advpalce['template']){
				$return = advbuy_template($advpalce, $advlist, $advrecord);
			}else{
				include template('advbuy:advblock');
			}
			$advreturn .= $return;
		}
	}
	return $advreturn;
}

function advbuy_block($placeid, $output = 1) {
	global $_G;
	loadcache('plugin');
	$setconfig = $_G['cache']['plugin']['advbuy'];
	$advpalce = C::t('#advbuy#advbuy_place')->fetch_by_id($placeid);
	if($advpalce && $advpalce['status']){
		$advwidth = round(100/$advpalce['listnum'], 2).'%';
		$wherearr = array();
		$wherearr[] = "placeid = '".$advpalce['id']."'";
		$wherearr[] = "status = '1'";
		$advlist = C::t('#advbuy#advbuy_adv')->fetch_all_by_search_where($wherearr, 'order by displayorder asc');
		$wherearr = array();
		$wherearr[] = "placeid = '".$advpalce['id']."'";
		$wherearr[] = "endtime > '".$_G['timestamp']."'";
		$recordarr = C::t('#advbuy#advbuy_record')->fetch_all_by_search_where($wherearr, 'order by endtime desc');
		foreach($recordarr as $value){
			if($setconfig['change_url']){
				$hash = authcode("$value[id]\t$_G[timestamp]", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16)));
				$hash = urlencode($hash);
				$value['linkurl'] = "plugin.php?id=advbuy:jump&hash=".$hash;
			}
			$value['image'] = $value['image'] ? $_G['setting']['attachurl'].'advbuy/'.$value['image'] : '';
			$advrecord[$value['advid']] = $value;
		}
		if($advpalce['template']){
			$return = advbuy_template($advpalce, $advlist, $advrecord);
		}else{
			include template('advbuy:advblock');
		}
	}
	if($output){
		echo $return;
	}else{
		return $return;
	}
}

function advbuy_template($place, $advlist, $advrecord) {
	global $_G;
	loadcache('plugin');
	$setconfig = $_G['cache']['plugin']['advbuy'];
	$advtemplate = $replaces = array();
	$advtemplate['header'] = $advtemplate['footer'] = $advtemplate['body'] = $templatebody = '';
	if(strexists($place['template'], '[loop]') && strexists($place['template'], '[/loop]')) {
		preg_match('/^(.+?)\[loop\](.+?)\[\/loop\](.+?)$/s', $place['template'], $r);
		$advtemplate['header'] = stripslashes($r[1]);
		$templatebody = stripslashes($r[2]);
		$advtemplate['footer'] = stripslashes($r[3]);
	}

	if($templatebody) {
		foreach($advlist as $value){
			foreach($value as $k => $v) {
				$replaces['{adv_'.$k.'}'] = $v;
			}
			$body = $templatebody;
			if($advrecord[$value['id']]){
				foreach($advrecord[$value['id']] as $k => $v) {
					$replaces['{record_'.$k.'}'] = $v;
				}
				if($advrecord[$value['id']]['color']){
					$replaces['{record_title}'] = '<font color="'.$advrecord[$value['id']]['color'].'">'.$advrecord[$value['id']]['title'].'</font>';
				}
				$body = preg_replace('/(\[buy\](.+?)\[else\](.+?)\[\/buy\])/ismU', '${2}', $body);
			}else{
				$replaces['{buy_url}'] = 'plugin.php?id=advbuy:index&aid='.$value['id'];
				$body = preg_replace('/(\[buy\](.+?)\[else\](.+?)\[\/buy\])/ismU', '${3}', $body);
			}
			$body = str_replace(array_keys($replaces), $replaces, $body);
			$advtemplate['body'] .= $body;
		}
	}

	$place['template'] = $advtemplate['header'].$advtemplate['body'].$advtemplate['footer'];
	return $place['template'];
}



?>