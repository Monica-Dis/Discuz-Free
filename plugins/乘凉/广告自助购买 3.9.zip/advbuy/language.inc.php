<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.$plugin['identifier'].'&pmod=language';

$selectlang = array('template' => '&#27169;&#26495;&#39029;&#38754;');
$type = in_array($_GET['type'], array_keys($selectlang)) ? $_GET['type'] : 'template';
loadcache('pluginlanguage_'.$type, 1);
if(empty($_G['cache']['pluginlanguage_'.$type])) {
	$_G['cache']['pluginlanguage_'.$type] = array();
}

if(!submitcheck('savesubmit')) {
	showformheader('plugins&identifier='.$plugin['identifier'].'&pmod=language&type='.$type);
	$headertab = '';
	foreach ($selectlang as $key => $value) {
		if($key == $type){
			$headertab .= '<div style="float:left;margin-right:10px;"><a href="'.$pluginurl.'&type='.$key.'" style="display:block;background:#555;color:#fff;padding:0 15px;line-height:25px;text-decoration:none">'.$value.'</a></div>';
		}else{
			$headertab .= '<div style="float:left;margin-right:10px;"><a href="'.$pluginurl.'&type='.$key.'" style="display:block;background:#ddd;padding:0 15px;line-height:25px;text-decoration:none">'.$value.'</a></div>';
		}
	}
	showtableheader($headertab);
	foreach ($_G['cache']['pluginlanguage_'.$type][$plugin['identifier']] as $key => $value) {
		showsetting($key, "setting[$key]", $value, 'textarea');
	}
	showsubmit('savesubmit', 'submit');
	showtablefooter(); /*Dism_taobao_com*/
	showformfooter(); /*Dism_taobao-com*/
} else {
	$_G['cache']['pluginlanguage_'.$type][$plugin['identifier']] = $_GET['setting'];
	savecache('pluginlanguage_'.$type, $_G['cache']['pluginlanguage_'.$type]);
	if($type == 'template') {
		cleartemplatecache();
	}
	cpmsg('plugins_edit_succeed', 'action=plugins&identifier='.$plugin['identifier'].'&pmod=language&type='.$type, 'succeed');
}

//From: dis'.'m.tao'.'bao.com
?>