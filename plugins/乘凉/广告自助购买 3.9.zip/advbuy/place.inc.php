<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','advbuy');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=place';

$op = in_array($_GET['op'], array('index','edit','adv','editadv','code','template')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('savesubmit')) {
		$showarea_option = showarea_option();
		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
	[
		[1,'', 'td25'],
		[1,'<input type="text" class="txt" name="newdisplayorder[]" size="3">', 'td28'],
		[1,'<input type="text" class="txt" name="newtitle[]" size="15">'],
		[1,'<input type="text" class="txt" name="newlistnum[]" size="3">', 'td28'],
		[1,'<select name="newshowarea[]">$showarea_option</select>', 'td28'],
		[1,'<input type="checkbox" class="checkbox" value="1" name="newstatus[]" checked>', 'td25'],
		[1,'', 'td31'],
	]
]
</script>
EOT;
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=place');
		showtableheader(lang('plugin/'.IDENTIFIER, 'place_list'));
		showsubtitle(array('del', 'display_order', lang('plugin/'.IDENTIFIER, 'place_title'), lang('plugin/'.IDENTIFIER, 'place_listnum'), lang('plugin/'.IDENTIFIER, 'place_showarea'), 'enable', ''));

		$showarea_list = lang('plugin/'.IDENTIFIER, 'place_showarea_list');
		$query = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_all_by_displayorder();
		foreach ($query as $value) {
			showtablerow('', array('class="td25"', 'class="td28"', '', 'class="td28"', 'class="td28"', 'class="td25"', 'class="td31"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['id'].'" />',
				'<input type="text" class="txt" name="displayorder['.$value[id].']" value="'.$value['displayorder'].'" size="3" />',
				'<input type="text" class="txt" name="title['.$value[id].']" value="'.$value['title'].'" size="15" />',
				'<input type="text" class="txt" name="listnum['.$value[id].']" value="'.$value['listnum'].'" size="3" />',
				$value['showarea'] ? $showarea_list[$value['showarea']] : $lang['custom'],
				'<input class="checkbox" type="checkbox" value="1" name="status['.$value[id].']" '.($value['status'] ? "checked" : '').'>',
				"<a href=\"".$pluginurl."&op=edit&placeid=$value[id]\">".$lang['edit']."</a> ".
				"<a href=\"".$pluginurl."&op=template&placeid=$value[id]\">".lang('plugin/'.IDENTIFIER, 'place_template')."</a> ".
				"<a href=\"".$pluginurl."&op=adv&placeid=$value[id]\">".lang('plugin/'.IDENTIFIER, 'adv_list')."</a>".
				($value['showarea'] ? "" : " <a href=\"".$pluginurl."&op=code&placeid=$value[id]\">".lang('plugin/'.IDENTIFIER, 'place_code')."</a>"),
			));
		}

		echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/'.IDENTIFIER, 'place_add').'</a></div></td></tr>';
		showsubmit('savesubmit', 'submit', 'del');
		showtablefooter(); /*Dism_taobao_com*/
		showformfooter(); /*Dism_taobao-com*/

	} else {

		if($_GET['delete']) {
			C::t('#'.IDENTIFIER.'#advbuy_place')->delete($_GET['delete']);
		}

		if(is_array($_GET['title'])) {
			foreach($_GET['title'] as $id => $val) {
				$query = C::t('#'.IDENTIFIER.'#advbuy_place')->update($id, array(
					'displayorder' => intval($_GET['displayorder'][$id]),
					'title' => $_GET['title'][$id],
					'listnum' => intval($_GET['listnum'][$id]),
					'status' => intval($_GET['status'][$id]),
				));
			}
		}

		if(is_array($_GET['newtitle'])) {
			foreach($_GET['newtitle'] as $key => $value) {
				if($value) {
					C::t('#'.IDENTIFIER.'#advbuy_place')->insert(array(
						'displayorder' => intval($_GET['newdisplayorder'][$key]),
						'title' => $value,
						'listnum' => intval($_GET['newlistnum'][$key]),
						'showarea' => $_GET['newshowarea'][$key],
						'status' => intval($_GET['newstatus'][$key]),
					));
				}
			}
		}

		cpmsg(lang('plugin/'.IDENTIFIER, 'place_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=place', 'succeed');

	}
} elseif($op == 'edit' && $_GET['placeid']) {

	$item = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_by_id($_GET['placeid']);
	if(!$item) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=place&op=edit&placeid='.$_GET['placeid'],'enctype');
		showtableheader(lang('plugin/'.IDENTIFIER, 'place_edit'));
		$showarea = array();
		$showarea[] = array('', cplang('custom'));
		$showarea_list = lang('plugin/advbuy', 'place_showarea_list');
		foreach($showarea_list as $key => $value) {
			$showarea[] = array($key, $value);
		}
		showsetting(lang('plugin/'.IDENTIFIER, 'place_showarea'), array('showarea', $showarea), $item['showarea'], 'select', '', 0, lang('plugin/'.IDENTIFIER, 'place_showarea_comment'));
		showsetting('display_order', 'displayorder', $item['displayorder'], 'text');
		showsetting(lang('plugin/'.IDENTIFIER, 'place_title'), 'title', $item['title'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'place_title_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'place_advtype'), array('advtype', array(array(0, lang('plugin/'.IDENTIFIER, 'place_advtype_0'), array('advtype_1' => 'none')), array(1, lang('plugin/'.IDENTIFIER, 'place_advtype_1'), array('advtype_1' => ''))), 1), $item['advtype'], 'mradio');
		showtagheader('tbody', 'advtype_1', $item['advtype'] == 1);
		showsetting(lang('plugin/'.IDENTIFIER, 'place_imgsize'), array('imgwidth', 'imgheight'), array($item['imgwidth'], $item['imgheight']), 'multiply', '', 0, lang('plugin/'.IDENTIFIER, 'place_imgsize_comment'));
		showtagfooter('tbody');
		showsetting(lang('plugin/'.IDENTIFIER, 'place_listnum'), 'listnum', $item['listnum'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'place_listnum_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'place_htmlcode'), 'htmlcode', $item['htmlcode'], 'textarea', '', 0, lang('plugin/'.IDENTIFIER, 'place_htmlcode_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'place_status'), 'status', $item['status'], 'radio', '', 0, lang('plugin/'.IDENTIFIER, 'place_status_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*Dism_taobao_com*/
		showformfooter(); /*Dism_taobao-com*/
	} else {
		$data = array(
			'showarea' => $_GET['showarea'],
			'displayorder' => intval($_GET['displayorder']),
			'title' => $_GET['title'],
			'listnum' => intval($_GET['listnum']) > 0 ? intval($_GET['listnum']) : 1,
			'htmlcode' => $_GET['htmlcode'],
			'advtype' => intval($_GET['advtype']),
			'imgwidth' => intval($_GET['imgwidth']),
			'imgheight' => intval($_GET['imgheight']),
			'status' => intval($_GET['status']) ? 1 : 0,
		);
		C::t('#'.IDENTIFIER.'#advbuy_place')->update_by_id($_GET['placeid'], $data);
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=place&op=index', 'succeed');
	}

} elseif($op == 'adv' && $_GET['placeid']) {

	$place = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_by_id($_GET['placeid']);
	if(!$place) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_nonexistence'), '', 'error');
	}

	if(!submitcheck('savesubmit')) {
		$credit_option = credit_option();
		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
	[
		[1,'', 'td25'],
		[1,'', 'td28'],
		[1,'<input type="text" class="txt" name="newdisplayorder[]" size="3">', 'td28'],
		[1,'<input type="text" class="txt" name="newcredit_num[]" size="3"> <select name="newcredit_item[]">$credit_option</select>', 'td28'],
		[1,'$place[title]', ''],
		[1,'<input type="checkbox" class="checkbox" value="1" name="newstatus[]" checked>', 'td26']
	]
]
</script>
EOT;
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=place&op=adv&placeid='.$_GET['placeid']);
		showtableheader(lang('plugin/'.IDENTIFIER, 'adv_list'));
		showsubtitle(array('del', lang('plugin/'.IDENTIFIER, 'adv_advid'), 'display_order', lang('plugin/'.IDENTIFIER, 'adv_credit'), lang('plugin/'.IDENTIFIER, 'place_title'), 'enable', ''));

		$wherearr = array();
		$wherearr[] = "placeid = '".$_GET['placeid']."'";
		$query = C::t('#'.IDENTIFIER.'#advbuy_adv')->fetch_all_by_search_where($wherearr, 'order by displayorder asc');
		foreach ($query as $value) {
			showtablerow('', array('class="td25"', 'class="td28"', 'class="td28"', 'class="td28"', '', 'class="td26"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['id'].'"'.($value['showarea'] ? ' disabled="disabled"' : '').' />',
				'#'.$value['id'],
				'<input type="text" class="txt" name="displayorder['.$value[id].']" value="'.$value['displayorder'].'" size="3" />',
				'<input type="text" class="txt" name="credit_num['.$value[id].']" value="'.$value['credit_num'].'" size="3" /> <select name="credit_item['.$value[id].']">'.credit_option($value['credit_item']).'</select>',
				$place['title'],
				'<input class="checkbox" type="checkbox" value="1" name="status['.$value[id].']" '.($value['status'] ? "checked" : '').'>',
				"<a href=\"".$pluginurl."&op=editadv&advid=$value[id]\">$lang[edit]</a>",
			));
		}

		echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/'.IDENTIFIER, 'adv_add').'</a></div></td></tr>';
		showsubmit('savesubmit', 'submit', 'del');
		showtablefooter(); /*Dism_taobao_com*/
		showformfooter(); /*Dism_taobao-com*/

	} else {

		if($_GET['delete']) {
			C::t('#'.IDENTIFIER.'#advbuy_adv')->delete($_GET['delete']);
		}

		if(is_array($_GET['displayorder'])) {
			foreach($_GET['displayorder'] as $id => $val) {
				$query = C::t('#'.IDENTIFIER.'#advbuy_adv')->update($id, array(
					'displayorder' => intval($_GET['displayorder'][$id]),
					'placeid' => $_GET['placeid'],
					'credit_num' => intval($_GET['credit_num'][$id]) ? intval($_GET['credit_num'][$id]) : 0,
					'credit_item' => intval($_GET['credit_item'][$id]),
					'status' => intval($_GET['status'][$id]),
				));
			}
		}

		if(is_array($_GET['newdisplayorder'])) {
			foreach($_GET['newdisplayorder'] as $key => $value) {
				if($value) {
					C::t('#'.IDENTIFIER.'#advbuy_adv')->insert(array(
						'displayorder' => intval($_GET['newdisplayorder'][$key]),
						'placeid' => $_GET['placeid'],
						'credit_num' => intval($_GET['newcredit_num'][$key]) > 0 ? intval($_GET['newcredit_num'][$key]) : 0,
						'credit_item' => intval($_GET['newcredit_item'][$key]),
						'status' => intval($_GET['newstatus'][$key]),
					));
				}
			}
		}

		cpmsg(lang('plugin/'.IDENTIFIER, 'adv_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=place&op=adv&placeid='.$_GET['placeid'], 'succeed');

	}
} elseif($op == 'editadv' && $_GET['advid']) {

	$item = C::t('#'.IDENTIFIER.'#advbuy_adv')->fetch_by_id($_GET['advid']);
	if(!$item) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'adv_nonexistence'), '', 'error');
	}
	$place = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_by_id($item['placeid']);
	if(!$place) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=place&op=editadv&advid='.$_GET['advid'],'enctype');
		showtableheader(lang('plugin/'.IDENTIFIER, 'adv_edit'));
		showsetting('display_order', 'displayorder', $item['displayorder'], 'text');
		if($place['advtype']){
			showsetting(lang('plugin/'.IDENTIFIER, 'adv_bdimage'), 'bdimage', $item['bdimage'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'adv_bdimage_comment'));
		}else{
			showsetting(lang('plugin/'.IDENTIFIER, 'adv_bdtext'), 'bdtext', $item['bdtext'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'adv_bdtext_comment'));
		}
		$credit_item = array();
		$credit_item[] = array(0, cplang('none'));
		foreach($_G['setting']['extcredits'] as $i => $credit) {
			$credit_item[] = array($i, 'extcredits'.$i.' ('.$credit['title'].')');
		}
		showsetting(lang('plugin/'.IDENTIFIER, 'adv_credit_item'), array('credit_item', $credit_item), $item['credit_item'], 'select', '', 0, lang('plugin/'.IDENTIFIER, 'adv_credit_item_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'adv_credit_num'), 'credit_num', $item['credit_num'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'adv_credit_num_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'adv_status'), 'status', $item['status'], 'radio', '', 0, lang('plugin/'.IDENTIFIER, 'adv_status_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*Dism_taobao_com*/
		showformfooter(); /*Dism_taobao-com*/
	} else {
		$data = array(
			'displayorder' => intval($_GET['displayorder']),
			'bdtext' => $_GET['bdtext'],
			'bdimage' => $_GET['bdimage'],
			'credit_num' => intval($_GET['credit_num']) > 0 ? intval($_GET['credit_num']) : 0,
			'credit_item' => intval($_GET['credit_item']),
			'status' => intval($_GET['status']) ? 1 : 0,
		);
		C::t('#'.IDENTIFIER.'#advbuy_adv')->update_by_id($_GET['advid'], $data);
		cpmsg(lang('plugin/'.IDENTIFIER, 'adv_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=place&op=adv&placeid='.$item['placeid'], 'succeed');
	}

} elseif($op == 'code' && $_GET['placeid']) {
	$place = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_by_id($_GET['placeid']);
	if(!$place) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_nonexistence'), '', 'error');
	}
	showtips(lang('plugin/'.IDENTIFIER, 'place_codetip'));
	showtableheader();
	showtablerow('', 'colspan="2" class="td27" s="1"', lang('plugin/'.IDENTIFIER, 'place_jscode'));
	showtablerow('class="noborder"', array('colspan="2" class="vtop rowform"'), array('<textarea rows="6" cols="50" class="tarea" style="width: 90%;"><script src="plugin.php?id=advbuy:js&placeid='.$place['id'].'"></script></textarea>'));
	showtablerow('', 'colspan="2" class="td27" s="1"', lang('plugin/'.IDENTIFIER, 'place_funcode'));
	showtablerow('class="noborder"', array('colspan="2" class="vtop rowform"'), array('<textarea rows="6" cols="50" class="tarea" style="width: 90%;"><!--{eval function_exists(\'advbuy_block\') && advbuy_block('.$place['id'].');}--></textarea>'));
	//showtablerow('', 'colspan="2" class="tips2" s="1"', lang('plugin/'.IDENTIFIER, 'place_codemark'));
	showtablefooter(); /*Dism_taobao_com*/

} elseif($op == 'template' && $_GET['placeid']) {
	$item = C::t('#'.IDENTIFIER.'#advbuy_place')->fetch_by_id($_GET['placeid']);
	if(!$item) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showtips(lang('plugin/'.IDENTIFIER, 'place_templatetip'));
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=place&op=template&placeid='.$_GET['placeid'],'enctype');
		showtableheader();
		showtablerow('class="noborder"', array('class="bold" width="50"', 'class="vtop"'), array(lang('plugin/'.IDENTIFIER, 'place_template_example'), '<textarea rows="3" cols="50" name="template" style="width: 90%;" readonly="" onclick="this.select()">'.lang('plugin/'.IDENTIFIER, 'place_template_sample_'.$item['advtype']).'</textarea>'));
		showtablerow('class="noborder"', array('colspan="2" class="vtop rowform"'), array('<textarea rows="15" cols="50" name="template" style="width: 91%;">'.dhtmlspecialchars($item['template']).'</textarea>'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); /*Dism_taobao_com*/
		showformfooter(); /*Dism_taobao-com*/
	} else {
		$data = array(
			'template' => $_GET['template'],
		);
		C::t('#'.IDENTIFIER.'#advbuy_place')->update_by_id($_GET['placeid'], $data);
		cpmsg(lang('plugin/'.IDENTIFIER, 'place_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=place', 'succeed');
	}
}

function showarea_option($cur = '') {
	global $_G;
	$showareas = '<option value="">'.cplang('custom').'</option>';
	$showarea_list = lang('plugin/advbuy', 'place_showarea_list');
	foreach($showarea_list as $key => $showarea) {
		$showareas .= '<option value="'.$key.'" '.($key == $cur ? 'selected' : '').'>'.$showarea.'</option>';
	}
	return $showareas;
}

function credit_option($cur = 0) {
	global $_G;
	$apicredits = '<option value="0">'.cplang('none').'</option>';
	foreach($_G['setting']['extcredits'] as $i => $credit) {
		$extcredit = 'extcredits'.$i.' ('.$credit['title'].')';
		$apicredits .= '<option value="'.$i.'" '.($i == $cur ? 'selected' : '').'>'.$extcredit.'</option>';
	}
	return $apicredits;
}

//From: dis'.'m.tao'.'bao.com
?>