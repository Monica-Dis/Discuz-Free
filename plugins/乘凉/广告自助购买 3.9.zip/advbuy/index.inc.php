<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}
if($setconfig['text_color']){
	$colorArr = array();
	foreach(explode("\n", $setconfig['text_color']) as $key => $option) {
		$option = trim($option);
		if($option){
			$colorArr[] = $option;
		}
	}
	$setconfig['text_color'] = $colorArr;
}else{
	$setconfig['text_color'] = array();
}
$advid = intval($_GET['aid']);
$adv = C::t('#'.CURMODULE.'#advbuy_adv')->fetch_by_id($advid);
if(!$adv || !$adv['status']){
	showmessage(lang('plugin/'.CURMODULE, 'adv_nonexistence'));
}
$advplace = C::t('#'.CURMODULE.'#advbuy_place')->fetch_by_id($adv['placeid']);
if(!$advplace || !$advplace['status']){
	showmessage(lang('plugin/'.CURMODULE, 'place_nonexistence'));
}
$wherearr = array();
$wherearr[] = "advid = '".$advid."'";
$wherearr[] = "endtime > '".$_G['timestamp']."'";
$advrecord = C::t('#'.CURMODULE.'#advbuy_record')->count_by_search_where($wherearr);
if($advrecord) {
	showmessage(lang('plugin/'.CURMODULE, 'adv_takeup'));
}
if($setconfig['allow_usergroups'] && !in_array($_G['groupid'], $setconfig['allow_usergroups'])){
	showmessage(lang('plugin/'.CURMODULE, 'adv_nopermission'));
}
$mycredit = getuserprofile('extcredits'.$adv['credit_item']);
if(submitcheck('savesubmit')) {
	$paydays = intval($_GET['paydays']);
	if($paydays < 1 || $paydays > $setconfig['days_limit']) {
		showmessage(lang('plugin/'.CURMODULE, 'record_paydays_error'));
	}
	
	$expiration = 0;
	if($setconfig['days_unit'] == 1){
		$expiration = $_G['timestamp'] + $paydays * 3600;
	}elseif($setconfig['days_unit'] == 2){
		$expiration = $_G['timestamp'] + $paydays * 24 * 3600;
	}elseif($setconfig['days_unit'] == 3){
		$expiration = $_G['timestamp'] + $paydays * 7 * 24 * 3600;
	}elseif($setconfig['days_unit'] == 4){
		$expiration = $_G['timestamp'] + $paydays * 30 * 24 * 3600;
	}elseif($setconfig['days_unit'] == 5){
		$expiration = $_G['timestamp'] + $paydays * 365 * 24 * 3600;
	}

	$adv['credit_num'] = $paydays * $adv['credit_num'];
	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'placeid' => $advplace['id'],
		'advid' => $advid,
		'title' => $_GET['title'],
		'color' => $_GET['color'],
		'linkurl' => str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['linkurl']))),
		'credit_item' => $adv['credit_item'],
		'credit_num' => $adv['credit_num'],
		'endtime' => $expiration,
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	$data['color'] = in_array($data['color'], $setconfig['text_color']) ? $data['color'] : '';
	if(!$data['title']) {
		showmessage(lang('plugin/'.CURMODULE, 'record_title_empty'));
	}
	if(dstrlen($data['title']) > $setconfig['title_limit']) {
		showmessage(lang('plugin/'.CURMODULE, 'record_title_long'));
	}
	if($advplace['advtype']) {
		if($_FILES['imageurl']) {
			require DISCUZ_ROOT . './source/plugin/advbuy/lib/discuz_upload.php';
			$upload = new discuz_upload();
			$upload->init($_FILES['imageurl'], 'advbuy');
			$upload->save(1);
			$data['image'] = $upload->attach['attachment'];
		}else{
			showmessage(lang('plugin/'.CURMODULE, 'record_image_empty'));
		}
	}
	if(!$data['linkurl']) {
		showmessage(lang('plugin/'.CURMODULE, 'record_linkurl_empty'));
	}
	if(dstrlen($data['linkurl']) > 255) {
		showmessage(lang('plugin/'.CURMODULE, 'record_linkurl_long'));
	}
	if(!preg_match("/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/", $data['linkurl'])) {
		showmessage(lang('plugin/'.CURMODULE, 'record_linkurl_error'));
	}
	if($setconfig['website_limit'] && strpos($data['linkurl'], $_G['siteurl']) !== 0) {
		showmessage(lang('plugin/'.CURMODULE, 'website_limit'));
	}
	if($mycredit < $adv['credit_num']) {
		showmessage(sprintf(lang('plugin/'.CURMODULE, 'credit_notenough'), $_G['setting']['extcredits'][$adv['credit_item']]['title']));
	}
	updatemembercount($_G['uid'], array('extcredits'.$adv['credit_item'] => -$adv['credit_num']), 1, '', 0, '', lang('plugin/'.CURMODULE, 'advbuy_usecredit'), lang('plugin/'.CURMODULE, 'advbuy_usecredit'));
	C::t('#'.CURMODULE.'#advbuy_record')->insert($data);
	notification_add($_G['uid'], 'system', lang('plugin/'.CURMODULE, 'advbuy_notification'), array('createtime' => dgmdate($data['createtime'], 'Y-n-j H:i'), 'endtime' => dgmdate($data['endtime'], 'Y-n-j H:i')), 1);
	if($setconfig['remind_mail']) {
		require_once libfile('function/mail');
		$res = sendmail($setconfig['remind_mail'], lang('plugin/'.CURMODULE, 'mail_title'), lang('plugin/'.CURMODULE, 'mail_content'));
	}
	showmessage(lang('plugin/'.CURMODULE, 'advbuy_addsucceed'), dreferer(), array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));
}else{
	include template(CURMODULE.':advbuy');
}