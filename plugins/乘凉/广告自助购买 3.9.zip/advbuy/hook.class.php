<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_advbuy {

	public static $identifier = 'advbuy';

	function __construct() {
		global $_G;
		$setconfig = $_G['cache']['plugin'][self::$identifier];
		$this->setconfig = $setconfig;
		require_once libfile('function/common', 'plugin/advbuy');
	}

	function common() {
		global $_G;
	}

	function global_header() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('global_header');
		return $advreturn;
	}

	function global_footer() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('global_footer');
		return $advreturn;
	}

}

class plugin_advbuy_forum extends plugin_advbuy {

	function index_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('index_top');
		return $advreturn;
	}

	function index_middle_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('index_middle');
		return $advreturn;
	}

	function index_bottom_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('index_bottom');
		return $advreturn;
	}

	function forumdisplay_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('forumdisplay_top');
		return $advreturn;
	}

	function forumdisplay_middle_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('forumdisplay_middle');
		return $advreturn;
	}

	function forumdisplay_bottom_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('forumdisplay_bottom');
		return $advreturn;
	}

	function viewthread_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('viewthread_top');
		return $advreturn;
	}

	function viewthread_middle_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('viewthread_middle');
		return $advreturn;
	}

	function viewthread_bottom_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('viewthread_bottom');
		return $advreturn;
	}

}

class plugin_advbuy_portal extends plugin_advbuy {

	function view_article_top_output() {
		global $_G;
		$setconfig = $this->setconfig;
		$advreturn = advbuy_showarea('view_article_top');
		return $advreturn;
	}


}
//From: Dism��taobao��com
?>