<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = "ALTER TABLE `cdb_plugin_advbuy_place` MODIFY COLUMN `showarea` varchar(60) NOT NULL DEFAULT '';\n";

$advtype_existed = $htmlcode_existed = $template_existed = $imgwidth_existed = $imgheight_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_advbuy_place'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'advtype') {
		$advtype_existed = true;
		continue;
	}
	if($row['Field'] == 'htmlcode') {
		$htmlcode_existed = true;
		continue;
	}
	if($row['Field'] == 'template') {
		$template_existed = true;
		continue;
	}
	if($row['Field'] == 'imgwidth') {
		$imgwidth_existed = true;
		continue;
	}
	if($row['Field'] == 'imgheight') {
		$imgheight_existed = true;
		continue;
	}
}
$sql .= !$advtype_existed ? "ALTER TABLE `cdb_plugin_advbuy_place` ADD `advtype` tinyint(1) NOT NULL DEFAULT 0;\n" : '';
$sql .= !$htmlcode_existed ? "ALTER TABLE `cdb_plugin_advbuy_place` ADD `htmlcode` text NOT NULL DEFAULT '';\n" : '';
$sql .= !$template_existed ? "ALTER TABLE `cdb_plugin_advbuy_place` ADD `template` text NOT NULL DEFAULT '';\n" : '';
$sql .= !$imgwidth_existed ? "ALTER TABLE `cdb_plugin_advbuy_place` ADD `imgwidth` mediumint(8) unsigned NOT NULL DEFAULT 0;\n" : '';
$sql .= !$imgheight_existed ? "ALTER TABLE `cdb_plugin_advbuy_place` ADD `imgheight` mediumint(8) unsigned NOT NULL DEFAULT 0;\n" : '';

$bdtext_existed = $bdimage_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_advbuy_adv'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'bdtext') {
		$bdtext_existed = true;
		continue;
	}
	if($row['Field'] == 'bdimage') {
		$bdimage_existed = true;
		continue;
	}
}
$sql .= !$bdtext_existed ? "ALTER TABLE `cdb_plugin_advbuy_adv` ADD `bdtext` varchar(120) NOT NULL DEFAULT '';\n" : '';
$sql .= !$bdimage_existed ? "ALTER TABLE `cdb_plugin_advbuy_adv` ADD `bdimage` varchar(255) NOT NULL DEFAULT '';\n" : '';

$image_existed = $color_existed = $status_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_advbuy_record'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'image') {
		$image_existed = true;
		continue;
	}
	if($row['Field'] == 'color') {
		$color_existed = true;
		continue;
	}
	if($row['Field'] == 'status') {
		$status_existed = true;
		continue;
	}
}
$sql .= !$image_existed ? "ALTER TABLE `cdb_plugin_advbuy_record` ADD `image` varchar(255) NOT NULL DEFAULT '';\n" : '';
$sql .= !$color_existed ? "ALTER TABLE `cdb_plugin_advbuy_record` ADD `color` varchar(12) NOT NULL DEFAULT '';\n" : '';
$sql .= !$status_existed ? "ALTER TABLE `cdb_plugin_advbuy_record` ADD `status` tinyint(1) NOT NULL DEFAULT 0;\n" : '';

if($sql) {
	runquery($sql);
}

$advpalces = C::t('#advbuy#advbuy_place')->fetch_all_by_displayorder();
$showarea = array();
foreach($advpalces as $value){
	if($value['showarea'] == 'forumindex'){
		C::t('#advbuy#advbuy_place')->update_by_id($value['id'], array('showarea' => 'index_top'));
	}
	if($value['showarea'] == 'forumdisplay'){
		C::t('#advbuy#advbuy_place')->update_by_id($value['id'], array('showarea' => 'forumdisplay_top'));
	}
	if($value['showarea'] == 'viewthread'){
		C::t('#advbuy#advbuy_place')->update_by_id($value['id'], array('showarea' => 'viewthread_top'));
	}
	$showarea[] = $value['showarea'];
}
$showarea_list = lang('plugin/advbuy', 'place_showarea_list');
if(!in_array("view_article_top", $showarea)){
	$data = array(
		'displayorder' => 0,
		'title' => $showarea_list["view_article_top"],
		'showarea' => "view_article_top",
		'listnum' => 3,
		'status' => 0,
	);
	$placeid = C::t('#advbuy#advbuy_place')->insert($data, true);
	for ($i=1; $i<=9; $i++) {
		$data = array(
			'displayorder' => $i,
			'placeid' => $placeid,
			'credit_item' => 2,
			'credit_num' => 1,
			'status' => 0,
		);
		C::t('#advbuy#advbuy_adv')->insert($data);
	}
}

$finish = TRUE;

?>