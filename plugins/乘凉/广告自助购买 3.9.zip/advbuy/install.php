<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
 
DROP TABLE IF EXISTS `cdb_plugin_advbuy_place`;
CREATE TABLE `cdb_plugin_advbuy_place` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(15) NOT NULL DEFAULT '',
  `displayorder` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `template` text NOT NULL DEFAULT '',
  `htmlcode` text NOT NULL DEFAULT '',
  `showarea` varchar(60) NOT NULL DEFAULT '',
  `listnum` tinyint(1) NOT NULL DEFAULT 0,
  `advtype` tinyint(1) NOT NULL DEFAULT 0,
  `imgwidth` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `imgheight` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `showarea` (`showarea`)
) TYPE=MyISAM;
 
DROP TABLE IF EXISTS `cdb_plugin_advbuy_adv`;
CREATE TABLE `cdb_plugin_advbuy_adv` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `placeid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `displayorder` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credit_item` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credit_num` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `bdtext` varchar(120) NOT NULL DEFAULT '',
  `bdimage` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `placeid` (`placeid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_advbuy_record`;
CREATE TABLE `cdb_plugin_advbuy_record` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `placeid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `advid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `title` varchar(32) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `color` varchar(12) NOT NULL DEFAULT '',
  `linkurl` text NOT NULL DEFAULT '',
  `credit_item` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credit_num` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `placeid` (`placeid`),
  KEY `advid` (`advid`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$showarea_list = lang('plugin/advbuy', 'place_showarea_list');
foreach($showarea_list as $key => $showarea) {
	$data = array(
		'title' => $showarea,
		'showarea' => $key,
		'listnum' => 3,
		'status' => 1,
	);
	$placeid = C::t('#advbuy#advbuy_place')->insert($data, true);
	for ($i=1; $i<=9; $i++) {
		$data = array(
			'displayorder' => $i,
			'placeid' => $placeid,
			'credit_item' => 2,
			'credit_num' => 1,
			'status' => 1,
		);
		C::t('#advbuy#advbuy_adv')->insert($data);
	}
}

$finish = TRUE;

?>