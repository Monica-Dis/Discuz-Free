<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mimeType = array(
	'3gp' => 'video/3gpp',
	'7z' => 'application/x-7z-compressed',
	'aac' => 'audio/aac',
	'abw' => 'application/x-abiword',
	'arc' => 'application/x-freearc',
	'avi' => 'video/x-msvideo',
	'apk' => 'application/vnd.android.package-archive',
	'azw' => 'application/vnd.amazon.ebook',
	'bin' => 'application/octet-stream',
	'bmp' => 'image/bmp',
	'bz' => 'application/x-bzip',
	'bz2' => 'application/x-bzip2',
	'bzip2' => 'application/x-bzip2',
	'chm' => 'application/vnd.ms-htmlhelp',
	'csh' => 'application/x-csh',
	'css' => 'text/css',
	'csv' => 'text/csv',
	'doc' => 'application/msword',
	'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
	'eot' => 'application/vnd.ms-fontobject',
	'epub' => 'application/epub+zip',
	'flv' => 'video/x-flv',
	'gif' => 'image/gif',
	'gz' => 'application/gzip',
	'htm' => 'text/html',
	'html' => 'text/html',
	'ico' => 'image/vnd.microsoft.icon',
	'ics' => 'text/calendar',
	'jar' => 'application/java-archive',
	'jpeg' => 'image/jpeg',
	'jpg' => 'image/jpeg',
	'js' => 'text/javascript',
	'json' => 'application/json',
	'jsonld' => 'application/ld+json',
	'm4a' => 'audio/mp4',
	'mid' => 'audio/midi',
	'midi' => 'audio/midi',
	'mjs' => 'text/javascript',
	'mov' => 'video/quicktime',
	'mkv' => 'video/x-matroska',
	'mp3' => 'audio/mpeg',
	'mp4' => 'video/mp4',
	'mp4a' => 'audio/mp4',
	'mp4v' => 'video/mp4',
	'mpeg' => 'video/mpeg',
	'mpkg' => 'application/vnd.apple.installer+xml',
	'odp' => 'application/vnd.oasis.opendocument.presentation',
	'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
	'odt' => 'application/vnd.oasis.opendocument.text',
	'oga' => 'audio/ogg',
	'ogv' => 'video/ogg',
	'ogx' => 'application/ogg',
	'opus' => 'audio/opus',
	'otf' => 'font/otf',
	'pdf' => 'application/pdf',
	'php' => 'application/php',
	'png' => 'image/png',
	'ppt' => 'application/vnd.ms-powerpoint',
	'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
	'rar' => 'application/x-rar',
	'rtf' => 'application/rtf',
	'sh' => 'application/x-sh',
	'svg' => 'image/svg+xml',
	'swf' => 'application/x-shockwave-flash',
	'tar' => 'application/x-tar',
	'tif' => 'image/tiff',
	'tiff' => 'image/tiff',
	'ts' => 'video/mp2t',
	'ttf' => 'font/ttf',
	'txt' => 'text/plain',
	'vsd' => 'application/vnd.visio',
	'wav' => 'audio/wav',
	'wma' => 'audio/x-ms-wma',
	'wmv' => 'video/x-ms-asf',
	'weba' => 'audio/webm',
	'webm' => 'video/webm',
	'webp' => 'image/webp',
	'woff' => 'font/woff',
	'woff2' => 'font/woff2',
	'xhtml' => 'application/xhtml+xml',
	'xls' => 'application/vnd.ms-excel',
	'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
	'xml' => 'application/xml',
	'xul' => 'application/vnd.mozilla.xul+xml',
	'zip' => 'application/zip'
);

?>