<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$csspath = 'source/plugin/'.CURMODULE.'/css/';
$jspath = 'source/plugin/'.CURMODULE.'/js/';
$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}
$setconfig['tip_usergroups'] = (array)unserialize($setconfig['tip_usergroups']);
if(in_array('', $setconfig['tip_usergroups'])) {
	$setconfig['tip_usergroups'] = array();
}
if(!$setconfig['open_frontuser']) {
	showmessage(lang('plugin/'.CURMODULE, 'frontuser_closed'));
}

$navtitle = lang('plugin/'.CURMODULE, 'shortlink');

if(submitcheck('savesubmit')) {
	if($setconfig['allow_usergroups']){
		if(empty($_G['uid']) && !in_array('7', $setconfig['allow_usergroups'])) {
			showmessage('to_login', '', array(), array('msgtype' => true, 'login' => 1));
		}
		if(!in_array($_G['groupid'], $setconfig['allow_usergroups'])){
			showmessage(lang('plugin/'.CURMODULE, 'no_permission'));
		}
	}
	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'title' => $setconfig['default_title'],
		'url' => str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['longurl']))),
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	if(!$data['url']) {
		showmessage(lang('plugin/'.CURMODULE, 'link_url_empty'));
	}
	if(!preg_match("/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/", $data['url'])) {
		//showmessage(lang('plugin/'.CURMODULE, 'link_url_error'));
	}
	$host = parse_url($data['url'], PHP_URL_HOST);
	if(!$host) {
		showmessage(lang('plugin/'.CURMODULE, 'link_url_error'));
	}
	if(!white_url($setconfig['white_domain'], $host)) {
		showmessage(lang('plugin/'.CURMODULE, 'link_url_ban'));
	}
	$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_uid_url($_G['uid'], $data['url']);
	if($link){
		$link_id = $link['id'];
	}else{
		$link_id = C::t('#'.CURMODULE.'#shortlink_link')->insert($data, true);
	}

	require_once DISCUZ_ROOT . './source/plugin/'.CURMODULE.'/lib/hashids.class.php';
	$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
	$hashid = $Hashids->encode($link_id);
	$shorturl = ($setconfig['url_host'] ? $setconfig['url_host'] : $_G['siteurl']).str_replace(array('{aid}', '{nid}'), array($hashid, $link_id), $setconfig['rewrite_rule']);

	showmessage('', dreferer(), array('hashid' => $hashid, 'longurl' => $data['url'], 'shorturl' => $shorturl));
} else {
	include template(CURMODULE.':index');
}

function white_url($whitelist, $host) {
	if($whitelist) {
		$whitelist = explode("\n", $whitelist);
		$hostlen = strlen($host);
		foreach($whitelist as $val) {
			$val = trim($val);
			$domainlen = strlen($val);
			if($domainlen > $hostlen) {
				continue;
			}
			if(substr($host, -$domainlen) == $val) {
				return true;
			}
		}
		return false;
	}else{
		return true;
	}
}