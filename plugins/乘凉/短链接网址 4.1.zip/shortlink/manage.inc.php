<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/'.CURMODULE.'/lib/hashids.class.php';
if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$csspath = 'source/plugin/'.CURMODULE.'/css/';
$jspath = 'source/plugin/'.CURMODULE.'/js/';
$setconfig = $_G['cache']['plugin'][CURMODULE];
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
if(in_array('', $setconfig['allow_usergroups'])) {
	$setconfig['allow_usergroups'] = array();
}
if(!$setconfig['open_frontuser']) {
	showmessage(lang('plugin/'.CURMODULE, 'frontuser_closed'));
}
if(!$setconfig['open_manage']) {
	showmessage(lang('plugin/'.CURMODULE, 'manage_closed'));
}
if($setconfig['allow_usergroups'] && !in_array($_G['groupid'], $setconfig['allow_usergroups'])){
	showmessage(lang('plugin/'.CURMODULE, 'no_permission'));
}

$navtitle = lang('plugin/'.CURMODULE, 'shortlink');
$ac = in_array($_GET['ac'], array('index','edit','qrcode','delete')) ? $_GET['ac'] : 'index';

if($ac == 'index') {
	if(submitcheck('savesubmit')) {
		if(empty($_GET['aids'])) {
			showmessage(lang('plugin/'.CURMODULE, 'link_not_choose'));
		}
		if(is_array($_GET['aids'])) {
			$links = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_ids($_GET['aids']);
			foreach ($links as $key => $value) {
				if($value['uid'] == $_G['uid']){
					$aids[] = $value['id'];
				}
			}
			if(empty($aids)) {
				showmessage(lang('plugin/'.CURMODULE, 'link_not_choose'));
			}
			C::t('#'.CURMODULE.'#shortlink_link')->delete_by_id($aids);
		}
		$dreferer = dreferer();
		$dreferer = $dreferer ? $dreferer : 'plugin.php?id=shortlink:manage';
		showmessage(lang('plugin/'.CURMODULE, 'link_deletesucceed'), $dreferer, array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));
	} else {
		$page = max(1, $_G['page']);
		$perpage = defined('IN_MOBILE') ? 10 : 20;
		$start = ($page-1)*$perpage;
		$mpurl = 'plugin.php?id='.CURMODULE.':manage&order='.rawurlencode($_GET['order']).'&asc='.rawurlencode($_GET['asc']);
		$wherearr = array();
		$wherearr[] = "uid = ".$_G['uid'];
		$title = trim($_GET["title"]);
		if($title) {
			$mpurl .= '&title='.rawurlencode($title);
			$title = addslashes(stripsearchkey($title));
			$wherearr[] = "title like binary '%".$title."%'";
			$_GET["title"] = dhtmlspecialchars($_GET["title"]);
		}
		$orderby = in_array($_GET['order'], array('clicknum','createtime'), true) ? $_GET['order'] : 'createtime';
		$orderby = 'order by '.$orderby.' '.($_GET['asc'] ? 'ASC' : 'DESC');
		$count = C::t('#'.CURMODULE.'#shortlink_link')->count_by_search_where($wherearr);
		$list = C::t('#'.CURMODULE.'#shortlink_link')->fetch_all_by_search_where($wherearr, $orderby, $start, $perpage);
		$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
		foreach ($list as $key => $value) {
			$hashid = $Hashids->encode($value['id']);
			$value['createtime'] = dgmdate($value['createtime'], 'Y-m-d H:i');
			$value['url_2'] = ($setconfig['url_host'] ? $setconfig['url_host'] : $_G['siteurl']).str_replace(array('{aid}', '{nid}'), array($hashid, $value['id']), $setconfig['rewrite_rule']);
			$list[$key] = $value;
		}
		$multipage = multi($count, $perpage, $page, $mpurl);
		include template(CURMODULE.':manage');
	}
} elseif($ac == 'edit') {
	$aid = intval($_GET['aid']);
	if(!$aid) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_id($aid);
	if(!$link) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	if($link['uid'] != $_G['uid']) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	if(submitcheck('savesubmit')) {
		$data = array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'title' => trim($_GET['title']),
			'url' => str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['url']))),
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		if(!$data['title']) {
			showmessage(lang('plugin/'.CURMODULE, 'link_title_empty'));
		}
		if(dstrlen($data['title']) > 20) {
			showmessage(lang('plugin/'.CURMODULE, 'link_title_toolong'));
		}
		if(!$data['url']) {
			showmessage(lang('plugin/'.CURMODULE, 'link_url_empty'));
		}
		if(!preg_match("/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/", $data['url'])) {
			//showmessage(lang('plugin/'.CURMODULE, 'link_url_error'));
		}
		$host = parse_url($data['url'], PHP_URL_HOST);
		if(!$host) {
			showmessage(lang('plugin/'.CURMODULE, 'link_url_error'));
		}
		if(!white_url($setconfig['white_domain'], $host)) {
			showmessage(lang('plugin/'.CURMODULE, 'link_url_ban'));
		}
		C::t('#'.CURMODULE.'#shortlink_link')->update_by_id($link['id'], $data);
		$dreferer = dreferer();
		$dreferer = $dreferer ? $dreferer : 'plugin.php?id=shortlink:manage';
		showmessage(lang('plugin/'.CURMODULE, 'link_updatesucceed'), $dreferer, array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));
	} else {
		include template(CURMODULE.':manage_edit');
	}
} elseif($ac == 'qrcode') {
	$aid = intval($_GET['aid']);
	if(!$aid) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_id($aid);
	if(!$link) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	if($link['uid'] != $_G['uid']) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
	$hashid = $Hashids->encode($link['id']);
	$link['url_2'] = ($setconfig['url_host'] ? $setconfig['url_host'] : $_G['siteurl']).str_replace(array('{aid}', '{nid}'), array($hashid, $link['id']), $setconfig['rewrite_rule']);
	include template(CURMODULE.':manage_qrcode');
} elseif($ac == 'delete') {
	$aid = intval($_GET['aid']);
	if(!$aid) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_id($aid);
	if(!$link) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	if($link['uid'] != $_G['uid']) {
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
	if(submitcheck('modsubmit')) {
		C::t('#'.CURMODULE.'#shortlink_link')->delete_by_id($link['id']);
		$dreferer = dreferer();
		$dreferer = $dreferer ? $dreferer : 'plugin.php?id=shortlink:manage';
		showmessage(lang('plugin/'.CURMODULE, 'link_deletesucceed'), $dreferer, array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));
	} else {
		include template(CURMODULE.':manage_delete');
	}
}

function white_url($whitelist, $host) {
	if($whitelist) {
		$whitelist = explode("\n", $whitelist);
		$hostlen = strlen($host);
		foreach($whitelist as $val) {
			$val = trim($val);
			$domainlen = strlen($val);
			if($domainlen > $hostlen) {
				continue;
			}
			if(substr($host, -$domainlen) == $val) {
				return true;
			}
		}
		return false;
	}else{
		return true;
	}
}