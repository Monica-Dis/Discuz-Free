<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','shortlink');

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=clean';

if(!submitcheck('rbsubmit', 1)) {

	showformheader('plugins&identifier='.IDENTIFIER.'&pmod=clean');
	showtableheader(lang('plugin/'.IDENTIFIER, 'clean_title'));

	showsetting(lang('plugin/'.IDENTIFIER, 'clean_days'), 'days', '30', 'text', '', 0, lang('plugin/'.IDENTIFIER, 'clean_days_comment'));
	showsetting(lang('plugin/'.IDENTIFIER, 'clean_guest'), 'guest', '1', 'radio', '', 0, lang('plugin/'.IDENTIFIER, 'clean_guest_comment'));
	showsubmit('rbsubmit');
	showtablefooter(); //Dism��taobao��com
	showformfooter(); //Dism_taobao_com

} else {

	$deleteids = array();
	$pernum = 500;
	$linksdel = intval($_GET['linksdel']);
	$days = intval($_GET['days']);
	$guest = intval($_GET['guest']);
	$wherearr = array();
	if($days){
		$wherearr[] = "createtime < '".(TIMESTAMP - ($days * 86400))."'";
	}
	if($guest){
		$wherearr[] = "uid = '0'";
	}
	$list = C::t('#'.IDENTIFIER.'#shortlink_link')->fetch_all_by_search_where($wherearr,'order by createtime asc', 0, $pernum);
	foreach($list as $value) {
		$deleteids[] = $value['id'];
	}
	if($deleteids) {
		C::t('#'.IDENTIFIER.'#shortlink_link')->delete_by_id($deleteids);
		$linksdel += count($deleteids);
		//$startlimit += $pernum;
		cpmsg(lang('plugin/'.IDENTIFIER, 'clean_next'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=clean&rbsubmit=1&linksdel='.$linksdel.'&days='.$days.'&guest='.$guest, 'succeed', array('linksdel' => $linksdel));
	} else {
		cpmsg(lang('plugin/'.IDENTIFIER, 'clean_succeed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=clean', 'succeed', array('linksdel' => $linksdel));
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>