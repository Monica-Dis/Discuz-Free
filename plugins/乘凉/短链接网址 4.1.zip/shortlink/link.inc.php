<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

define('IDENTIFIER','shortlink');
require_once DISCUZ_ROOT . './source/plugin/'.IDENTIFIER.'/lib/hashids.class.php';

loadcache('plugin');
$setconfig = $_G['cache']['plugin'][IDENTIFIER];
$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.IDENTIFIER.'&pmod=link';

$op = in_array($_GET['op'], array('index','add','edit')) ? $_GET['op'] : 'index';

if($op == 'index') {
	if(!submitcheck('submit')) {
		$intkeys = array();
		$strkeys = array();
		$randkeys = array();
		$likekeys = array('title', 'url');
		$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
		foreach($likekeys as $k) {
			$_GET[$k] = dhtmlspecialchars($_GET[$k]);
		}
		$wherearr = $results['wherearr'];
		$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
		$adminscript = ADMINSCRIPT;
		$searchtitle = lang('plugin/'.IDENTIFIER, 'link_title');
		$searchurl = lang('plugin/'.IDENTIFIER, 'link_url');
		echo <<<SEARCH
		<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
			<div style="margin-top:8px;">
			<table cellspacing="3" cellpadding="3">
				<tr>
					<th>$searchtitle</th><td><input type="text" class="txt" name="title" value="$_GET[title]"></td>
					<th>$searchurl</th><td><input type="text" class="txt" name="url" value="$_GET[url]"></td>
					<td>
						<input type="hidden" name="action" value="plugins">
						<input type="hidden" name="identifier" value="shortlink">
						<input type="hidden" name="pmod" value="link">
						<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
					</td>
				</tr>
			</table>
			</div>
		</form>
		<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
		$perpage = 30;
		$start = ($page-1)*$perpage;
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=link');
		showtableheader(lang('plugin/'.IDENTIFIER, 'link_list'). '<a href="'.$pluginurl.'&op=add" style="margin-left:10px">['.lang('plugin/'.IDENTIFIER, 'link_add').']</a>');
		showsubtitle(array('del', 'username', lang('plugin/'.IDENTIFIER, 'link_title'), lang('plugin/'.IDENTIFIER, 'link_url'), lang('plugin/'.IDENTIFIER, 'link_url_2'), lang('plugin/'.IDENTIFIER, 'link_clicknum'), 'ip', 'dateline', 'operation'));
		$count = C::t('#'.IDENTIFIER.'#shortlink_link')->count_by_search_where($wherearr);
		$list = C::t('#'.IDENTIFIER.'#shortlink_link')->fetch_all_by_search_where($wherearr,'order by createtime desc,id desc', $start, $perpage);
		$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
		foreach ($list as $value) {
			$hashid = $Hashids->encode($value['id']);
			$value['createtime'] = dgmdate($value['createtime'], 'Y-m-d H:i');
			showtablerow('', array('class="td25"', 'class="td32"', 'class="td24"', '', 'class="td31"', 'class="td32"', 'class="td24"', 'class="td24"', 'class="td25"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
				$value['username'] ? $value['username'] : '/',
				$value['title'],
				'<div style="word-break:break-all;">'.$value['url'].'</div>',
				($setconfig['url_host'] ? $setconfig['url_host'] : $_G['siteurl']).str_replace(array('{aid}', '{nid}'), array($hashid, $value['id']), $setconfig['rewrite_rule']),
				$value['clicknum'],
				$value['postip'],
				$value['createtime'],
				"<a href=\"".$pluginurl."&op=edit&id=$value[id]\">$lang[edit]</a>"
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);

		showsubmit('submit', 'submit', 'select_all', '', $multipage, false);
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
	} else {
		if(is_array($_GET['delete'])) {
			C::t('#'.IDENTIFIER.'#shortlink_link')->delete_by_id($_GET['delete']);
		}
		cpmsg(lang('plugin/'.IDENTIFIER, 'link_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=link', 'succeed');
	}
} elseif($op == 'add') {
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=link&op=add','enctype');
		showtableheader(lang('plugin/'.IDENTIFIER, 'link_add'));
		showsetting(lang('plugin/'.IDENTIFIER, 'link_title'), 'title', '', 'text', '', 0, lang('plugin/'.IDENTIFIER, 'link_title_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'link_url'), 'url', '', 'textarea', '', 0, lang('plugin/'.IDENTIFIER, 'link_url_comment1'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
	} else {
		if(!trim($_GET['title'])) {
			cpmsg(lang('plugin/'.IDENTIFIER, 'link_title_empty'), '', 'error');
		}
		if(!trim($_GET['url'])) {
			cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_empty'), '', 'error');
		}
		
		foreach(explode("\n", $_GET['url']) as $key => $url) {
			$url = trim($url);
			if($url){
				$data = array(
					'uid' => $_G['uid'],
					'username' => $_G['username'],
					'title' => trim($_GET['title']),
					'url' => str_replace('&amp;', '&', dhtmlspecialchars(trim($url))),
					'createtime' => $_G['timestamp'],
					'postip' => $_G['clientip'],
				);
				if(!preg_match("/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/", $data['url'])) {
					//cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_error'), '', 'error');
				}
				$host = parse_url($data['url'], PHP_URL_HOST);
				if(!$host) {
					continue;
					//cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_error'), '', 'error');
				}

				C::t('#'.IDENTIFIER.'#shortlink_link')->insert($data);
			}
		}

		cpmsg(lang('plugin/'.IDENTIFIER, 'link_addsucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=link', 'succeed');
	}
} elseif($op == 'edit' && $_GET['id']) {
	$link = C::t('#'.IDENTIFIER.'#shortlink_link')->fetch_by_id($_GET['id']);
	if(!$link) {
		cpmsg(lang('plugin/'.IDENTIFIER, 'link_nonexistence'), '', 'error');
	}
	if(!submitcheck('savesubmit')) {
		showformheader('plugins&identifier='.IDENTIFIER.'&pmod=link&op=edit&id='.$_GET['id'],'enctype');
		showtableheader(lang('plugin/'.IDENTIFIER, 'link_edit'));
		showsetting(lang('plugin/'.IDENTIFIER, 'link_title'), 'title', $link['title'], 'text', '', 0, lang('plugin/'.IDENTIFIER, 'link_title_comment'));
		showsetting(lang('plugin/'.IDENTIFIER, 'link_url'), 'url', $link['url'], 'textarea', '', 0, lang('plugin/'.IDENTIFIER, 'link_url_comment'));
		showsubmit('savesubmit', 'submit');
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
	} else {
		$data = array(
			'title' => trim($_GET['title']),
			'url' => str_replace('&amp;', '&', dhtmlspecialchars(trim($_GET['url']))),
			'createtime' => $_G['timestamp'],
			'postip' => $_G['clientip'],
		);
		if(!$data['title']) {
			cpmsg(lang('plugin/'.IDENTIFIER, 'link_title_empty'), '', 'error');
		}
		if(!$data['url']) {
			cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_empty'), '', 'error');
		}
		if(!preg_match("/^http(s?):\/\/(?:[A-za-z0-9-]+\.)+[A-za-z]{2,4}(?:[\/\?#][\/=\?%\-&~`@[\]\':+!\.#\w]*)?$/", $data['url'])) {
			//cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_error'), '', 'error');
		}
		$host = parse_url($data['url'], PHP_URL_HOST);
		if(!$host) {
			cpmsg(lang('plugin/'.IDENTIFIER, 'link_url_error'), '', 'error');
		}

		C::t('#'.IDENTIFIER.'#shortlink_link')->update_by_id($_GET['id'], $data);
		cpmsg(lang('plugin/'.IDENTIFIER, 'link_updatesucceed'), 'action=plugins&identifier='.IDENTIFIER.'&pmod=link', 'succeed');
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>