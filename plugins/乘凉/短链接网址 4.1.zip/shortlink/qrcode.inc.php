<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/'.CURMODULE.'/lib/hashids.class.php';
require_once DISCUZ_ROOT . './source/plugin/'.CURMODULE.'/lib/phpqrcode.php';

$setconfig = $_G['cache']['plugin'][CURMODULE];

if(!$_GET['aid']) {
	showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
}

$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
$hashid = $Hashids->decode($_GET['aid']);
if(!$hashid){
	showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
}
$hashid = implode(",", $hashid);

$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_id($hashid);
if(!$link) {
	showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
}

$shorturl = ($setconfig['url_host'] ? $setconfig['url_host'] : $_G['siteurl']).str_replace(array('{aid}', '{nid}'), array($Hashids->encode($link['id']), $link['id']),$setconfig['rewrite_rule']);

QRcode::png($shorturl, false, 'L', 10, 1); 
