<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/'.CURMODULE.'/lib/hashids.class.php';

$setconfig = $_G['cache']['plugin'][CURMODULE];

if(!$_GET['aid']) {
	if($setconfig['nopage_url']){
		dheader('location: '.$setconfig['nopage_url']);
	}else{
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
}

if(strpos($setconfig['rewrite_rule'],'{aid}') !== false) {
	$Hashids = new Hashids(md5(substr(md5($_G['config']['security']['authkey']), 0, 16)), 6);
	$hashid = $Hashids->decode($_GET['aid']);
	if(!$hashid){
		if($setconfig['nopage_url']){
			dheader('location: '.$setconfig['nopage_url']);
		}else{
			showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
		}
	}
	$hashid = implode(",", $hashid);
}else{
	$hashid = intval($_GET['aid']);
	if(!$hashid){
		if($setconfig['nopage_url']){
			dheader('location: '.$setconfig['nopage_url']);
		}else{
			showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
		}
	}
}

$link = C::t('#'.CURMODULE.'#shortlink_link')->fetch_by_id($hashid);
if(!$link) {
	if($setconfig['nopage_url']){
		dheader('location: '.$setconfig['nopage_url']);
	}else{
		showmessage(lang('plugin/'.CURMODULE, 'link_nonexistence'));
	}
}
C::t('#'.CURMODULE.'#shortlink_link')->update_click($link['id']);

header('location: '.$link['url']);
exit();