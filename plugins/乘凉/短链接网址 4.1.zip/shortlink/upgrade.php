<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$uid_existed = $username_existed = $clicknum_existed = false;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('plugin_shortlink_link'));
while($row = DB::fetch($query)) {
	if($row['Field'] == 'uid') {
		$uid_existed = true;
		continue;
	}
	if($row['Field'] == 'username') {
		$username_existed = true;
		continue;
	}
	if($row['Field'] == 'clicknum') {
		$clicknum_existed = true;
		continue;
	}
}
$sql .= !$uid_existed ? "ALTER TABLE `cdb_plugin_shortlink_link` ADD `uid` mediumint(8) NOT NULL DEFAULT 0;\n" : '';
$sql .= !$username_existed ? "ALTER TABLE `cdb_plugin_shortlink_link` ADD `username` varchar(32) NOT NULL DEFAULT '';\n" : '';
$sql .= !$clicknum_existed ? "ALTER TABLE `cdb_plugin_shortlink_link` ADD `clicknum` int(10) unsigned NOT NULL DEFAULT 0;\n" : '';

$sql .= "ALTER TABLE `cdb_plugin_shortlink_link` MODIFY `title` varchar(60) NOT NULL DEFAULT '';\n";

if($sql) {
	runquery($sql);
}

$finish = TRUE;

?>