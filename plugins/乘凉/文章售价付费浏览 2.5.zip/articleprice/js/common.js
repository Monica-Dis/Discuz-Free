
function articleprice_free() {
	var ctrlid = 'articleprice_free';
	var opentag = '[free]';
	var closetag = '[/free]';
	var menu = $(ctrlid + '_menu');
	var menupos = '00';
	var menutype = 'win';
	
	if(menu) {
		showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});
	} else {
		var stitle = '免费可见内容';
		var str = '<p class="px" style="height:300px"><iframe id="' + ctrlid + '_param_1" frameborder="0" style="width:100%;height:100%" onload="this.contentWindow.document.body.style.wordWrap=\'break-word\';this.contentWindow.document.body.contentEditable=true;this.contentWindow.document.body.focus();this.onload=null"></iframe></p><p class="xg2 pbn" style="margin-top:10px;">如果您设置了帖子售价，请输入购买前免费可见的信息内容</p>';
		var menuwidth = 600;
		menu = document.createElement('div');
		menu.id = ctrlid + '_menu';
		menu.style.display = 'none';
		menu.className = 'p_pof upf';
		menu.style.width = menuwidth + 'px';
		if(menupos == '00') {
			menu.className = 'fwinmask';
			s = '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + stitle + '</em><span><a onclick="hideMenu(\'\', \'win\');return false;" class="flbc" href="javascript:;">关闭</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="button" id="' + ctrlid + '_submit" class="pn pnc"><strong>提交</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		} else {
			s = '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">关闭</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>提交</strong></button></div></div>';
		}
		menu.innerHTML = s;
		$('articleform').appendChild(menu);
		showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		edit_insert(opentag + $(ctrlid + '_param_1').contentWindow.document.body.innerHTML + closetag);
		hideMenu('', 'win');
	};
}
