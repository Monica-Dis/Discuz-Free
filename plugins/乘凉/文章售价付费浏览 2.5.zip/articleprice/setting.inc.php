<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.$plugin['identifier'].'&pmod=setting';

loadcache('articleprice_setting');
$setconfig = $_G['cache']['articleprice_setting'];
$setconfig['allow_category'] = (array)unserialize($setconfig['allow_category']);
$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
$setconfig['free_usergroups'] = (array)unserialize($setconfig['free_usergroups']);

if(!submitcheck('savesubmit')) {

	showformheader('plugins&identifier='.$plugin['identifier'].'&pmod=setting','enctype');
	showtableheader(lang('plugin/'.$plugin['identifier'], 'setting_list'));
	//showsetting(lang('plugin/'.$plugin['identifier'], 'setting_allow_category'), array('setting[allow_category][]',  array_merge(array(array('', cplang('plugins_empty'))), getportalcategory(0))), $setconfig['allow_category'], 'mselect', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_allow_category_comment'));
	$query = C::t('common_usergroup')->range_orderby_credit();
	$groupselect = array();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $setconfig['allow_usergroups']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$select = '<select name="setting[allow_usergroups][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $setconfig['allow_usergroups']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.
			'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
			($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
			($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
			'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_allow_usergroups'), '', '', $select, '', 0, lang('plugin/'.$plugin['identifier'], 'setting_allow_usergroups_comment'));
	$groupselect = array();
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $setconfig['free_usergroups']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
	}
	$select = '<select name="setting[free_usergroups][]" size="10" multiple="multiple"><option value=""'.(@in_array('', $setconfig['free_usergroups']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.
			'<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
			($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
			($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
			'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_free_usergroups'), '', '', $select, '', 0, lang('plugin/'.$plugin['identifier'], 'setting_free_usergroups_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_credit_item'), array('setting[credit_item]', getextcredit()), $setconfig['credit_item'], 'select', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_credit_item_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_credit_high'), 'setting[credit_high]', $setconfig['credit_high'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_credit_high_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_credit_stax'), 'setting[credit_stax]', $setconfig['credit_stax'], 'text', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_credit_stax_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_extra_tip'), 'setting[extra_tip]', $setconfig['extra_tip'], 'textarea', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_extra_tip_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_add_quote'), 'setting[add_quote]', $setconfig['add_quote'], 'radio', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_add_quote_comment'));
	showsetting(lang('plugin/'.$plugin['identifier'], 'setting_notice_author'), 'setting[notice_author]', $setconfig['notice_author'], 'radio', '', 0, lang('plugin/'.$plugin['identifier'], 'setting_notice_author_comment'));
	showsubmit('savesubmit', 'submit');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dism _ taobao _ com*/

} else {

	$settings = $_GET['setting'];
	C::t('#'.$plugin['identifier'].'#articleprice_setting')->update_batch($settings);
	updatecache('articleprice:articleprice_setting');
	cpmsg(lang('plugin/'.$plugin['identifier'], 'setting_updatesucceed'), 'action=plugins&identifier='.$plugin['identifier'].'&pmod=setting', 'succeed');

}


function getportalcategory($upid) {
	global $_G;
    $list = array();
	loadcache('portalcategory');
	foreach($_G['cache']['portalcategory'] as $category) {
		if($category['upid'] == $upid) {
			$list[] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4).$category['catname']);
			$list = array_merge($list, getportalcategory($category['catid']));
		}
	}
	return $list;
}

function getextcredit() {
	global $_G;
    $list = array();
	$list[] = array('', cplang('plugins_empty'));
	foreach($_G['setting']['extcredits'] as $i => $credit) {
		$extcredit = 'extcredits'.$i.' ('.$credit['title'].')';
		$list[] = array($i, $extcredit);
	}
	return $list;
}



?>