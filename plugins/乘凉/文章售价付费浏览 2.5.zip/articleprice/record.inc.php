<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginurl = ADMINSCRIPT.'?action=plugins&identifier='.$plugin['identifier'].'&pmod=record';

if(!submitcheck('submit')) {
	$intkeys = array('aid');
	$strkeys = array();
	$randkeys = array();
	$likekeys = array('username');
	$results = getwheres($intkeys, $strkeys, $randkeys, $likekeys);
	foreach($likekeys as $k) {
		$_GET[$k] = dhtmlspecialchars($_GET[$k]);
	}
	$wherearr = $results['wherearr'];
	$mpurl = $pluginurl.'&'.implode('&', $results['urls']);
	$adminscript = ADMINSCRIPT;
	$searchaid = lang('plugin/'.$plugin['identifier'], 'article_aid');
	echo <<<SEARCH
	<form method="get" autocomplete="off" action="$adminscript" id="tb_search">
		<div style="margin-top:8px;">
		<table cellspacing="3" cellpadding="3">
			<tr>
				<th>$lang[username]</th><td><input type="text" class="txt" name="username" value="$_GET[username]"></td>
				<th>$searchaid</th><td><input type="text" class="txt" name="aid" value="$_GET[aid]"></td>
				<td>
					<input type="hidden" name="action" value="plugins">
					<input type="hidden" name="identifier" value="$plugin[identifier]">
					<input type="hidden" name="pmod" value="record">
					<input type="submit" name="searchsubmit" value="$lang[search]" class="btn" id="submit_searchsubmit">
				</td>
			</tr>
		</table>
		</div>
	</form>
	<script type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'searchsubmit'); });</script>
SEARCH;
	$perpage = 30;
	$start = ($page-1)*$perpage;
	showformheader('plugins&identifier='.$plugin['identifier'].'&pmod=record');
	showtableheader(lang('plugin/'.$plugin['identifier'], 'record_list'));
	showsubtitle(array('del', 'username', 'subject', lang('plugin/'.$plugin['identifier'], 'record_creditnum'), 'ip', lang('plugin/'.$plugin['identifier'], 'record_createtime')));
	$count = C::t('#'.$plugin['identifier'].'#articleprice_record')->count_by_search_where($wherearr);
	$list = C::t('#'.$plugin['identifier'].'#articleprice_record')->fetch_all_by_search_where($wherearr,'order by createtime desc', $start, $perpage);
	foreach ($list as $value) {
		$article = C::t('portal_article_title')->fetch($value['aid']);
		$value['createtime'] = dgmdate($value['createtime'], 'Y-n-j H:i');
		showtablerow('', array('class="td25"', 'class="td24"', '', 'class="td24"', 'class="td24"', 'class="td24"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$value[id]\">",
			$value['username'],
			'<a href="portal.php?mod=view&aid='.$article['aid'].'" target="_blank">'.$article['title'].'</a>',
			$_G['setting']['extcredits'][$value['credititem']]['title']." ".$value['creditnum']." ".$_G['setting']['extcredits'][$value['credititem']]['unit'],
			$value['postip'],
			$value['createtime']
		));
	}
	$multipage = multi($count, $perpage, $page, $mpurl);

	showsubmit('submit', 'submit', 'select_all', '', $multipage);
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dism _ taobao _ com*/
} else {
	if(is_array($_GET['delete'])) {
		C::t('#'.$plugin['identifier'].'#articleprice_record')->delete_by_id($_GET['delete']);
	}
	cpmsg(lang('plugin/'.$plugin['identifier'], 'record_updatesucceed'), 'action=plugins&identifier='.$plugin['identifier'].'&pmod=record', 'succeed');
}

//From: Dism��taobao��com
?>