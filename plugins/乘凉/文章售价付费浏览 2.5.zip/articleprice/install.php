<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `cdb_plugin_articleprice_setting`;
CREATE TABLE `cdb_plugin_articleprice_setting` (
  `skey` varchar(255) NOT NULL DEFAULT '',
  `svalue` text NOT NULL,
  PRIMARY KEY (`skey`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_articleprice_article`;
CREATE TABLE `cdb_plugin_articleprice_article` (
  `aid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credititem` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `creditnum` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`aid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `cdb_plugin_articleprice_record`;
CREATE TABLE `cdb_plugin_articleprice_record` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `username` varchar(15) NOT NULL DEFAULT '',
  `aid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `credititem` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `creditnum` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `postip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$settings = lang('plugin/articleprice', 'setting_data');
C::t('#articleprice#articleprice_setting')->update_batch($settings);
updatecache('articleprice:articleprice_setting');

$finish = TRUE;

?>