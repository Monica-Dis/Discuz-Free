<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('articleprice_setting');
$setconfig = $_G['cache']['articleprice_setting'];
if($setconfig['extra_tip']) {
	$contents = preg_split('/(\<\!--(.*?)--\>)+/is', $setconfig['extra_tip'], 2);
	if(count($contents) > 1){
		if(defined('IN_MOBILE')) {
			$setconfig['extra_tip'] = $contents[1];
		}else{
			$setconfig['extra_tip'] = $contents[0];
		}
	}
}
$aid = intval($_GET['aid']);
if(!$aid) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_article_noid'));
}
$article = C::t('portal_article_title')->fetch($aid);
if(!$article) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_article_noexist'));
}
if(!$_G['uid']) {
	showmessage('group_nopermission', NULL, array('grouptitle' => $_G['group']['grouptitle']), array('login' => 1));
}
$article_priceinfo = C::t('#'.CURMODULE.'#articleprice_article')->fetch_by_id($article['aid']);
if(!$article_priceinfo) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_pay_error'), NULL);
} elseif(!isset($_G['setting']['extcredits'][$article_priceinfo['credititem']])) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_credits_disabled'));
} elseif($article_priceinfo['creditnum'] <= 0) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_pay_error'), NULL);
}
if(C::t('#'.CURMODULE.'#articleprice_record')->fetch_by_uid_aid($_G['uid'], $article['aid'])) {
	showmessage(lang('plugin/'.CURMODULE, 'articleprice_pay_already'), 'portal.php?mod=view&aid='.$article['aid'].($_GET['from'] ? '&from='.$_GET['from'] : ''));
}
$article_priceinfo['netprice'] = floor($article_priceinfo['creditnum'] * (1 - $setconfig['credit_stax']));
$mycredit = getuserprofile('extcredits'.$article_priceinfo['credititem']);
$balance = $mycredit - $article_priceinfo['creditnum'];

if(submitcheck('paysubmit')) {
	if($balance < 0) {
		showmessage(lang('plugin/'.CURMODULE, 'articleprice_credits_insufficient'), '', array('title' => $_G['setting']['extcredits'][$article_priceinfo['credititem']]['title'], 'minbalance' => $article_priceinfo['creditnum']));
	}

	$updateauthor = true;
	$authorEarn = $article_priceinfo['netprice'];

	if($updateauthor) {
		updatemembercount($article['uid'], array($article_priceinfo['credititem'] => $authorEarn), 1, '', 0, '', lang('plugin/'.CURMODULE, 'articleprice_title'), lang('plugin/'.CURMODULE, 'articleprice_desc'));
	}
	updatemembercount($_G['uid'], array($article_priceinfo['credititem'] => - $article_priceinfo['creditnum']), 1, '', 0, '', lang('plugin/'.CURMODULE, 'articleprice_title'), lang('plugin/'.CURMODULE, 'articleprice_desc'));


	$data = array(
		'uid' => $_G['uid'],
		'username' => $_G['username'],
		'aid' => $article['aid'],
		'credititem' => $article_priceinfo['credititem'],
		'creditnum' => $article_priceinfo['creditnum'],
		'createtime' => $_G['timestamp'],
		'postip' => $_G['clientip'],
	);
	C::t('#'.CURMODULE.'#articleprice_record')->insert($data);

	if($setconfig['notice_author']) {
		if($article['uid'] != $_G['uid']){
			notification_add($article['uid'], 'system', 'articleprice:articleprice_noticeauthor', array(
				'aid' => $article['aid'],
				'title' => $article['title'],
				'from_id' => $article['aid'],
				'from_idtype' => '',
			));
		}
	}

	showmessage(lang('plugin/'.CURMODULE, 'articleprice_pay_succeed'), 'portal.php?mod=view&aid='.$article['aid'].($_GET['from'] ? '&from='.$_GET['from'] : ''), array(), array('showdialog' => 1, 'showmsg' => true, 'locationtime' => 3, 'alert' => 'right'));

} else {

	include template(CURMODULE.':payment');

}


