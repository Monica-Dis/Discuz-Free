<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_articleprice {

	public static $identifier = 'articleprice';

	function __construct() {
		global $_G;
		loadcache('articleprice_setting');
		$setconfig = $_G['cache']['articleprice_setting'];
		$setconfig['allow_category'] = (array)unserialize($setconfig['allow_category']);
		if(in_array('', $setconfig['allow_category'])) {
			$setconfig['allow_category'] = array();
		}
		$setconfig['allow_usergroups'] = (array)unserialize($setconfig['allow_usergroups']);
		if(in_array('', $setconfig['allow_usergroups'])) {
			$setconfig['allow_usergroups'] = array();
		}
		$setconfig['free_usergroups'] = (array)unserialize($setconfig['free_usergroups']);
		if(in_array('', $setconfig['free_usergroups'])) {
			$setconfig['free_usergroups'] = array();
		}
		$this->setconfig = $setconfig;
	}

	function global_footer_mobile() {
		global $_G,$article,$content;
		$setconfig = $this->setconfig;
		if(CURSCRIPT == 'portal' && CURMODULE == 'view' && $article){
			$article_priceinfo = C::t('#'.self::$identifier.'#articleprice_article')->fetch_by_id($article['aid']);
			if($article_priceinfo){
				$article_payers = C::t('#'.self::$identifier.'#articleprice_record')->count_by_aid($article['aid']);
				$articlepay = 0;
				if($_G['uid'] == $article['uid'] || in_array($_G['groupid'], $setconfig['free_usergroups'])){
					$articlepay = 1;
				}elseif($_G['uid']){
					$article_buyinfo = C::t('#'.self::$identifier.'#articleprice_record')->fetch_by_uid_aid($_G['uid'], $article['aid']);
					if($article_buyinfo){
						$articlepay = 1;
					}
				}
				$freemessage = '';
				if(preg_match_all("/\[free\](.+?)\[\/free\]/is", $content['content'], $matches)) {
					foreach($matches[1] AS $match) {
						$freemessage .= $this->_filter_html($match);
					}
					$content['content'] = preg_replace_callback("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", array(__CLASS__, '_parse_free_callback'), $content['content']);
				}
				include template(self::$identifier.':locked');
				$content['content'] = $return;
			}else{
				$content['content'] = preg_replace_callback("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", array(__CLASS__, '_parse_free_callback'), $content['content']);
			}
		}
		return '';
	}

	function _parse_free_callback($matches) {
		$html = $matches[1];
		$setconfig = $this->setconfig;
		if($setconfig['add_quote']){
			$html = '<div class="quote"><blockquote>'.$html.'</blockquote></div>';
		}
		return $html;
	}

	function _filter_html($html) {
		$html = trim(str_replace(array('\r', '\n'), '', $html));
		$taglist = array("div", "p", "span", "font", "b", "i", "u", "em", "li", "ol", "blockquote");
		foreach($taglist as $tag) {
			$tag = "</".$tag.">";
			if(strpos($html, $tag) === 0){
				$html = substr($html, strlen($tag));
				return $this->_filter_html($html);
			}
		}
		foreach($taglist as $tag) {
			$tag = "<".$tag.">";
			if(substr($html, -strlen($tag)) === $tag){
				$html = substr($html, 0, -strlen($tag));
				return $this->_filter_html($html);
			}
		}
		return $html;
	}

}

class mobileplugin_articleprice_portal extends mobileplugin_articleprice {

	function portalcp_extend_mobile_output() {
		global $_G, $aid;
		$setconfig = $this->setconfig;
		if(!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups'])){
			$articleprice = '';
			if($aid) {
				$article_priceinfo = C::t('#'.self::$identifier.'#articleprice_article')->fetch_by_id($aid);
				if($article_priceinfo){
					$articleprice = $article_priceinfo['creditnum'];
				}
			}
			include template(self::$identifier.':portalcp_extend');
		}
		if(!empty($_G['setting']['pluginhooks']['portalcp_extend'])){
			$_G['setting']['pluginhooks']['portalcp_extend'] = $_G['setting']['pluginhooks']['portalcp_extend'].$return;
		}else{
			return $return;
		}
	}

	function portalcp() {
		global $_G;
		$setconfig = $this->setconfig;
		if(submitcheck("articlesubmit", 1) && empty($_POST['summary']) && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))){
			$articleprice = intval($_POST['articleprice']);
			$articleprice = $articleprice > 0 ? $articleprice : 0;
			if($articleprice){
				$content = preg_replace("/(\s|\<strong\>##########NextPage(\[title=.*?\])?##########\<\/strong\>)+/", ' ', $_POST['content']);
				if(preg_match_all("/\[free\](.+?)\[\/free\]/is", $content, $matches)) {
					foreach($matches[1] AS $match) {
						$_POST['summary'] .= $match;
					}
				}
				if(empty($_POST['summary'])){
					$_POST['summary'] = lang('plugin/'.self::$identifier, 'articleprice_summary');
				}
			}
		}
	}

	function portalcp_output() {
		global $_G, $article;
		$setconfig = $this->setconfig;
		if(submitcheck("articlesubmit", 1) && $article && (!$setconfig['allow_usergroups'] || in_array($_G['groupid'], $setconfig['allow_usergroups']))) {
			$articleprice = intval($_GET['articleprice']);
			$articleprice = $articleprice > 0 ? $articleprice : 0;
			$article_priceinfo = C::t('#'.self::$identifier.'#articleprice_article')->fetch_by_id($article['aid']);
			if($articleprice){
				$data = array(
					'aid' => $article['aid'],
					'catid' => $article['catid'],
					'credititem' => $setconfig['credit_item'],
					'creditnum' => $articleprice,
				);
				if($article_priceinfo){
					C::t('#'.self::$identifier.'#articleprice_article')->update_by_id($article['aid'], $data);
				}else{
					C::t('#'.self::$identifier.'#articleprice_article')->insert($data);
				}
			}else{
				if($article_priceinfo) {
					C::t('#'.self::$identifier.'#articleprice_article')->delete_by_id($article['aid']);
				}
			}
		}
	}


}

//From: Dism��taobao��com
?>