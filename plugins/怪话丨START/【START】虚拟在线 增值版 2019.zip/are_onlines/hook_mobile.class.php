<?php

/**		CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_onlines [在线人数]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      [DisMall!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'hook.class.php';

new plugin_are_onlines();

class mobileplugin_are_onlines {//手机版脚本中的类名以 mobileplugin_ 开头。
    
	public static $_G, $onlinenum;
    public static function global_header_mobile() {
    	global $_G, $onlinenum;
		$plg=$_G['cache']['plugin']['are_onlines'];
		$ymd = date('H:i', TIMESTAMP);
		if ($ymd >=$plg['start_time'] && $ymd <=$plg['off_time']){
			if($plg['z_hynums']) {
				$_G['cache']['userstats']['totalmembers']=$_G['cache']['userstats']['totalmembers']+$plg['z_hynums'];
			}
			if($plg['zzx_nums'] || $plg['xn_nums']) {
				$membercount_mt=mt_rand($plg['zzx_nums']/2, $plg['zzx_nums']);
				$guestcount_mt=mt_rand($plg['yk_nums']/2, $plg['yk_nums']);
				$onlinenum=$onlinenum+$membercount_mt+$guestcount_mt;
			}
		}else {
			return '';
		}
    }
    
}

class mobileplugin_are_onlines_forum extends mobileplugin_are_onlines {}
class mobileplugin_are_onlines_member extends mobileplugin_are_onlines {}

//From: dis'.'m.tao'.'bao.com
?>