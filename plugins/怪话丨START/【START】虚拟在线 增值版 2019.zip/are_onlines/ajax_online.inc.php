<?php

/**		CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_onlines [在线人数]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      [DisMall!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once 'common.class.php';
$are_langs = commoncls::are_langs();
global $_G;
$plg = $_G['cache']['plugin']['are_onlines'];
$plstatic = 'source/plugin/are_onlines/statics/';

$ct_sqls = DB::fetch_all("SELECT * FROM ".DB::table('common_session')." WHERE uid>0");
if ($plg['xn_nums'] >0){
	echo mt_rand($plg['xn_mins'], $plg['xn_nums']);
}else {
	echo count($ct_sqls);
}


//From: Dism·taobao·com
?>