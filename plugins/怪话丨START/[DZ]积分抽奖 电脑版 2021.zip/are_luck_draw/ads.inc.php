<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$are_langs = commoncls::are_langs();//print_r($are_langs);
global $_G;

if ($_G['uid'] < 1) {//检测是否登录
	showmessage($are_langs['login'], '', array(), array('login' => TRUE));
}

if ($_POST['submit'] && $_POST['fh'] == FORMHASH){
		
	$shname = addslashes(strip_tags($_POST['shname']));
	if (!$shname){showmessage($are_langs['inc1']);}
		
	$region = addslashes(strip_tags($_POST['region']));
	if (!$region){showmessage($are_langs['inc2']);}
		
	$address = addslashes(strip_tags($_POST['address']));
	if (!$address){showmessage($are_langs['inc3']);}
			
	$iphone =addslashes(strip_tags($_POST['iphone']));
	if(!preg_match("/^1[345678]{1}\\d{9}$/", $iphone)){showmessage($are_langs['inc4']);}
		
	$qqnb =addslashes(strip_tags($_POST['qqnb']));
	if(!preg_match("/^[1-9]\\d{4,10}$/", $qqnb)){showmessage($are_langs['inc5']);}
		
	$ads = DB::fetch_all("SELECT * FROM ".DB::table('are_luck_draw_ads')." WHERE uid='{$_G['uid']}'");
	$ymd = TIMESTAMP;
	DB::query("replace into pre_are_luck_draw_ads(uid, shname, region, address, iphone, qqnb, addtime) 
	values('{$_G['uid']}', '{$shname}', '{$region}', '{$address}', '{$iphone}', '{$qqnb}', '{$ymd}')");
	showmessage($are_langs['inc6'], dreferer());
			
}

//From: Dism_taobao-com
?>