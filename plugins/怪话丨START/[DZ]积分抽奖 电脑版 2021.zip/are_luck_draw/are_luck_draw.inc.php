<?php

/**		CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_luck_draw [九宫格抽奖]
 * 
 * 		更多商业插件/模版下载 就在DisM!应用中心
 * 
 * 		Compile time: 2019/06/07
 * 
 * 		Author website: dism.taobao.com
 * 
 *      [Discuz!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$are_langs = commoncls::are_langs();
global  $_G,$s;

if ($_G['uid'] < 1) {
	showmessage($are_langs['login'], '', array(), array('login' => TRUE));	
}

$navtitle = $are_langs['navtitle'];
$_G['setting']['bbname'] = $are_langs['bbname'] ? $are_langs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $are_langs['metakeywords'] ? $are_langs['metakeywords'] : $navtitle;
$metadescription = $are_langs['metadescription'] ? $are_langs['metadescription'] : $navtitle;

$plg = $_G['cache']['plugin']['are_luck_draw'];//引用后台参数
$plstatic = 'source/plugin/are_luck_draw/statics/';//设置$plstatic变量，快捷调用statics文件下css、images、js等方式
$myscore = commoncls::myscore($plg['scoretype']);

$ld_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_luck_draw')." WHERE 1 ORDER BY addtime DESC LIMIT 100");
$img_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_img')." WHERE 1 ORDER BY addtime DESC");
if (empty($img_sql)) showmessage($are_langs['inc7']);
$my_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_luck_draw')." WHERE uid='{$_G['uid']}' AND ldid=1 ORDER BY uptime ASC");
$ads_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_ads')." WHERE uid='{$_G['uid']}'");

$score_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_score')." WHERE uid='{$_G['uid']}'";
$score_sql = DB::fetch_all($sql, array(), 'spid');

$xn_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_xn')." WHERE uid='{$_G['uid']}'";
$xn_sql = DB::fetch_all($sql, array(), 'czid');

$sw_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_sw')." WHERE uid='{$_G['uid']}'";
$sw_sql = DB::fetch_all($sql, array(), 'czid');

$today = date('Ymd', TIMESTAMP);

$ct = array();
$td_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_luck_draw')." WHERE uid='{$_G['uid']}'");
foreach ($td_sql as $k=>$v){
	$vymd = date('Ymd', $v['addtime']);
	if ($vymd == $today){
		$ct[]=$vymd;
	}
}

$tq_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw')." WHERE uid='{$_G['uid']}' AND ldid=1");
$tq_time = date('Ymd', $tq_sql['uptime']);
$yymd = date('Ymd', TIMESTAMP);
$ct = intval(count($tq_sql));



$power = unserialize($plg['gp_power']);//print_r($power);
$gp_power = $_G['member']['groupid'];//print_r($gp_power);
if (in_array($_G['member']['groupid'], $power)) {
	$gp_sql = DB::fetch_first("SELECT * FROM ".DB::table('common_usergroup')." WHERE groupid={$gp_power}");
	showmessage($are_langs['inc8'].$gp_sql['grouptitle'].$are_langs['inc9']);
} 

include template('diy:are_luck_draw', '', commoncls::$diydir);//引用DIY


?>