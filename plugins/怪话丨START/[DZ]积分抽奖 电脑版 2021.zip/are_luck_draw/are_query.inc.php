<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$are_langs = commoncls::are_langs();
global  $_G;

if ($_G['uid'] < 1) {
	showmessage($are_langs['login'], '', array(), array('login' => TRUE));	
}

$plg = $_G['cache']['plugin']['are_luck_draw'];//引用后台参数
$plstatic = 'source/plugin/are_luck_draw/statics/';//设置$plstatic变量，快捷调用statics文件下css、images、js等方式
$myscore = commoncls::myscore($plg['scoretype']);
if ($_GET['fh'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($are_langs['fh']);
}
$my_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_luck_draw')." WHERE uid='{$_G['uid']}' AND ldid=1 AND uptime>0 ORDER BY uptime ASC");
$score_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_score')." WHERE uid='{$_G['uid']}'";
$score_sql = DB::fetch_all($sql, array(), 'spid');
$xn_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_xn')." WHERE uid='{$_G['uid']}'";
$xn_sql = DB::fetch_all($sql, array(), 'czid');
$sw_sql = array();
$sql = "SELECT * FROM ".DB::table('are_luck_draw_sw')." WHERE uid='{$_G['uid']}'";
$sw_sql = DB::fetch_all($sql, array(), 'czid');

$flid = intval($_GET['flid']);
if ($flid == 1) {
	$xnid = intval($_GET['xnid']);
	$sp_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_xn')." WHERE czid=$xnid");//print_r($sp_sql);
}elseif ($flid == 2){
	$swid = intval($_GET['swid']);
	$sp_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_sw')." WHERE czid=$swid");//print_r($sp_sql);
}


include template('diy:are_query', '', commoncls::$diydir);//引用DIY
//include template('are_luck_draw:are_luck_draw');

?>