
window.onload=function(){
		
	var inx_divs =document.getElementById('inx_divs'); 
	var xh_tb1 = document.getElementById('xh_tb1'); 
	var xh_tb2 = document.getElementById('xh_tb2'); 
		
	if(xh_tb1.offsetHeight >= '400'){
		xh_tb2.innerHTML=xh_tb1.innerHTML; 
	}
		
	function scrollUp(){ 
		if(inx_divs.scrollTop>=xh_tb1.offsetHeight){ 
			inx_divs.scrollTop=0; 
		}else{ 
			inx_divs.scrollTop++; 
		} 
	} 
		
	var times = 100; 
	var mytimer=setInterval(scrollUp,times); 
		
	inx_divs.onmouseover=function(){ 
		clearInterval(mytimer); 
	} 
	inx_divs.onmouseout=function(){
		mytimer=setInterval(scrollUp,times); 
	} 

}