<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'common.class.php';
require_once 'x_upload_module.php';
$are_langs = commoncls::are_langs();//print_r($are_langs);
$plstatic = commoncls::$plsrc;
global $_G, $PLNAME, $pluginid, $remote, $lm;
$file = str_replace('.inc.php', '', basename(__FILE__));
$burl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&fh='.FORMHASH.'&pmod=';
$murl = $burl.$file;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'are_luck_draw_sw';

if ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$addinfo = $_GET['dget'];
	foreach ($addinfo as $k => $v) {
		$addinfo[$k] = trim(strip_tags($v));//不能再addcslashes()，入库前dz已经addcslashes()
	}
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	if ($r) {
		$addinfo['uptime'] = TIMESTAMP;
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($are_langs['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = commoncls::sqlwhere(dhtmlspecialchars($_GET['ids']));
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($are_langs['succeed'], dreferer(), 'succeed');
	}
}

$js = <<<EOF
	<script>var CSSPATH = '{$_G['setting']['csspath']}';</script>
	<link rel="stylesheet" href="{$plstatic}css/css.css" type="text/css">
	<script type="text/javascript" src="{$plstatic}dialog417/dialog.js?skin=default"></script>
	<script type="text/javascript" src="{$plstatic}dialog417/plugins/iframeTools.js"></script>
	<script type="text/javascript" src="{$plstatic}jquery.min.js"></script>
	<script type="text/javascript" src="static/js/common.js?WT2"></script>
	<script type="text/javascript" src="static/js/calendar.js"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript">

function setstatus(obj, id, name) {
	//var name = name ? name : '';
	jQuery.get('{$turl}&setstatus=1&opid='+ id, {name:name, t:Math.random()}, function(data){
		switch(parseInt(data)) {
			case 1 :
				jQuery(obj).html('{$are_langs['no']}');
				break;
			case 0 :
				jQuery(obj).html('{$are_langs['yes']}');
				break;
		}
		art.dialog.tips('{$are_langs['succeed']}');
	});
}

function setoption(obj, id, name, value) {
	jQuery.get('{$turl}&setoption=1&opid='+ id, {name:name, value:value, t:Math.random()}, function(data){
		art.dialog.tips('{$are_langs['succeed']}'+ data);
		if (data =='102') window.location = window.location;
	});
}



function diy_code_form(formid) {
	art.dialog({id:'diy_code_form_id', title:'{$are_langs['diycode']}', content:'&lt;iframe width="100%" height="0" frameborder="0" marginheight="0" '
	+'src="plugin.php?id=levform:form&amp;ifr=1&amp;fmid='+formid+'" scrolling="no"&gt;&lt;/iframe&gt;'});
}

function deladimg(gid, src, obj) {
	if (confirm('{$are_langs['confirm']}')) {
		jQuery.get('{$remote}_deladimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery(obj).parent().fadeOut();
				art.dialog.tips('{$are_langs['succeed']}');
			}else {
				art.dialog.tips(data);
			}
		});
	}
}

function del_imgs(gid, src, obj) {
	if (confirm('{$are_langs['confirm']}')) {
		jQuery.get('{$remote}_delimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery('#oldadimgbox').fadeOut();
				art.dialog.tips('{$are_langs['succeed']}');
			}else {
				art.dialog.tips(data);
				jQuery(obj).parent().fadeOut();
			}
		});
	}
}


jQuery(function(){
	jQuery.get('{$lm}_pay._openaward.{$_GET['gid']}', {}, function(){});
});
</script>
EOF;
echo $js;
$sp_label = array(0=>$are_langs['ad33'], 1=>$are_langs['ad34']);
if (!$_GET['addtmp']) {
	
	$limit = 100;
	$where = " 1 ";
	$pgurl = $turl;
	$srhkeyxs = dstripslashes(strip_tags($_GET['srhkeys']));
	if ($srhkeyxs) {
		$where = "(id LIKE '%{$srhkeyxs}%' OR spname LIKE '%{$srhkeyxs}%') ";// OR id LIKE '%{$srhkeyxs}%'
		$pgurl = $turl.'&srhkeys='.$srhkeyxs;
	}
	$infos = commoncls::are_pages($table, $where.' ORDER BY id DESC', $limit, $pgurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$are_langs['ad1'].'</label></a>',
		'ID',
		$are_langs['ad26'],
		$are_langs['ad14'],
		$are_langs['ad15'],
		$are_langs['ad27'],
		$are_langs['ad28'],
		$are_langs['ad29'],
		$are_langs['ad19'],
		$are_langs['ad30'],
		$are_langs['ad31'],
		$are_langs['ad32'],
	);
	showformheader($murl);
		$tithtm = <<<eof
	<table width=100%>
<tr>
<td>{$are_langs['ad8']} <b><font color=red>{$infos['total']}</font></b> {$are_langs['ad9']} </td>
<td align=center></td>
<td align=right><form action="{$turl}" method="post" name="">
	<input type="text" name="srhkeys" placeholder="{$are_langs['ad20']}" value="{$srhkeyxs}"/> 
	<input type="submit" name="dosubmit" value=" {$are_langs['ad11']} " class="btn" style="width:auto;vertical-align:top;margin:0;" />
	</form></td>
</tr>
</table>

eof;
	showtableheader($tithtm);
	showsubtitle($_subtitle);
	
	if ($lists) {
		foreach ($lists as $v) {
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'],
			$v['username'],
			$v['spid'],
			$v['spname'],
			$v['address'],
			$v['qqadd'],
			$v['dhadd'],
			dgmdate($v['addtime'], 'u'),
			$v['ordernb'],
			$v['confirm']==0 ? $are_langs['ad33'] : $are_langs['ad34'],
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$are_langs['edit'].'</a>',
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$are_langs['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$are_langs['del'].'" onclick="return confirm(\''.$are_langs['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($are_langs['nodata']));
	}
	showtablefooter(); /*Dism·taobao·com*/
	showformfooter(); /*Dism_taobao_com*/
}else {
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	showformheader($murl.'&addtmp=1&opid='.$opid, ' enctype="multipart/form-data"');
	showtableheader('<a href="'.$turl.'"><b>'.$are_langs['ad12'].'</b></a>');
	
	foreach ($sp_label as $k => $v) {
		$sp_option.= "<option value='{$k}'>{$v}</option>";
	}
	
	$formhtml = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;} .tb.tb2 input{vertical-align:middle;}#show_bgcolor{padding:4px 25px;margin:0 10px;}</style>
	<tr>
		<td class=t>{$are_langs['ad35']}</td><td>{$r['username']}</td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad36']}</td><td><input type="text" name="dget[ordernb]" id="ordernb" value='{$r['ordernb']}' style='width:200px'></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad37']}</td><td><select name='dget[confirm]' id=confirm style="width:100px;">{$sp_option}</select></td>
	</tr>
	
	<tr><td class=t></td><td><input type="submit" value=" {$are_langs['ad38']} " name="doaddsubmit" class="btn"></td></tr>
	
	<tr>
		<td class=t style="font-size:20px;color:red;">{$are_langs['ad39']}</td>
		<td style="font-size:18px;">{$are_langs['ad40']}
			<br>{$are_langs['ad401']}
			<br>{$are_langs['ad402']}
			<br>{$are_langs['ad403']}
			<br>
			
		</td>
	</tr>
EOF;
	echo $formhtml;
	showtablefooter(); /*Dism·taobao·com*/
	showformfooter(); /*Dism_taobao_com*/
}


























