<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'common.class.php';
require_once 'x_upload_module.php';
$are_langs = commoncls::are_langs();//print_r($are_langs);
$plstatic = commoncls::$plsrc;
global $_G, $PLNAME, $pluginid, $remote, $lm;
$file = str_replace('.inc.php', '', basename(__FILE__));
$burl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&fh='.FORMHASH.'&pmod=';
$murl = $burl.$file;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'are_luck_draw_img';

if ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$addinfo = $_GET['dget'];
	foreach ($addinfo as $k => $v) {
		$addinfo[$k] = trim(strip_tags($v));//不能再addcslashes()，入库前dz已经addcslashes()
	}
	
	$upfile1 = x_upload_module::up_image('imgfile1');//echo $upfile;
	if ($upfile1) $addinfo['img1'] = $upfile1;
	$upfile2 = x_upload_module::up_image('imgfile2');//echo $upfile;
	if ($upfile2) $addinfo['img2'] = $upfile2;
	$upfile3 = x_upload_module::up_image('imgfile3');//echo $upfile;
	if ($upfile3) $addinfo['img3'] = $upfile3;
	$upfile4 = x_upload_module::up_image('imgfile4');//echo $upfile;
	if ($upfile4) $addinfo['img4'] = $upfile4;
	$upfile5 = x_upload_module::up_image('imgfile5');//echo $upfile;
	if ($upfile5) $addinfo['img5'] = $upfile5;
	$upfile6 = x_upload_module::up_image('imgfile6');//echo $upfile;
	if ($upfile6) $addinfo['img6'] = $upfile6;
	$upfile7 = x_upload_module::up_image('imgfile7');//echo $upfile;
	if ($upfile7) $addinfo['img7'] = $upfile7;
	$upfile8 = x_upload_module::up_image('imgfile8');//echo $upfile;
	if ($upfile8) $addinfo['img8'] = $upfile8;
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	if ($r) {
		$addinfo['uptime'] = TIMESTAMP;
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($are_langs['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = commoncls::sqlwhere(dhtmlspecialchars($_GET['ids']));
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($are_langs['succeed'], dreferer(), 'succeed');
	}
}

$js = <<<EOF
	<script>var CSSPATH = '{$_G['setting']['csspath']}';</script>
	<link rel="stylesheet" href="{$plstatic}css/css.css" type="text/css">
	<script type="text/javascript" src="{$plstatic}dialog417/dialog.js?skin=default"></script>
	<script type="text/javascript" src="{$plstatic}dialog417/plugins/iframeTools.js"></script>
	<script type="text/javascript" src="{$plstatic}jquery.min.js"></script>
	<script type="text/javascript" src="static/js/common.js?WT2"></script>
	<script type="text/javascript" src="static/js/calendar.js"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript">

function setstatus(obj, id, name) {
	//var name = name ? name : '';
	jQuery.get('{$turl}&setstatus=1&opid='+ id, {name:name, t:Math.random()}, function(data){
		switch(parseInt(data)) {
			case 1 :
				jQuery(obj).html('{$are_langs['no']}');
				break;
			case 0 :
				jQuery(obj).html('{$are_langs['yes']}');
				break;
		}
		art.dialog.tips('{$are_langs['succeed']}');
	});
}

function setoption(obj, id, name, value) {
	jQuery.get('{$turl}&setoption=1&opid='+ id, {name:name, value:value, t:Math.random()}, function(data){
		art.dialog.tips('{$are_langs['succeed']}'+ data);
		if (data =='102') window.location = window.location;
	});
}



function diy_code_form(formid) {
	art.dialog({id:'diy_code_form_id', title:'{$are_langs['diycode']}', content:'&lt;iframe width="100%" height="0" frameborder="0" marginheight="0" '
	+'src="plugin.php?id=levform:form&amp;ifr=1&amp;fmid='+formid+'" scrolling="no"&gt;&lt;/iframe&gt;'});
}

function deladimg(gid, src, obj) {
	if (confirm('{$are_langs['confirm']}')) {
		jQuery.get('{$remote}_deladimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery(obj).parent().fadeOut();
				art.dialog.tips('{$are_langs['succeed']}');
			}else {
				art.dialog.tips(data);
			}
		});
	}
}

function del_imgs(gid, src, obj) {
	if (confirm('{$are_langs['confirm']}')) {
		jQuery.get('{$remote}_delimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery('#oldadimgbox').fadeOut();
				art.dialog.tips('{$are_langs['succeed']}');
			}else {
				art.dialog.tips(data);
				jQuery(obj).parent().fadeOut();
			}
		});
	}
}


jQuery(function(){
	jQuery.get('{$lm}_pay._openaward.{$_GET['gid']}', {}, function(){});
});
</script>
EOF;
echo $js;

$sp_label = array(0=>$are_langs['ad41'], 1=>$are_langs['ad42'], 2=>$are_langs['ad43']);
$sp_label2 = array(0=>$are_langs['ad44'], 1=>$are_langs['ad45']);

if (!$_GET['addtmp']) {
	
	$limit = 100;
	$where = " 1 ";
	$pgurl = $turl;
	$srhkeyxs = dstripslashes(strip_tags($_GET['srhkeys']));
	if ($srhkeyxs) {
		$where = "(id LIKE '%{$srhkeyxs}%') ";// OR id LIKE '%{$srhkeyxs}%'
		$pgurl = $turl.'&srhkeys='.$srhkeyxs;
	}
	$infos = commoncls::are_pages($table, $where.' ORDER BY id DESC', $limit, $pgurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$are_langs['ad1'].'</label></a>',
		'ID'.'(1)',
		$are_langs['ad46'].'1',
		$are_langs['ad47'].'1',
		$are_langs['ad48'].'1',
		$are_langs['ad49'].'1',
		$are_langs['ad50'].'1',
		$are_langs['ad51'].'1',
		$are_langs['ad46'].'2',
		$are_langs['ad47'].'2',
		$are_langs['ad48'].'2',
		$are_langs['ad49'].'2',
		$are_langs['ad50'].'2',
		$are_langs['ad51'].'2',
		$are_langs['ad58'],
		$are_langs['ad32'],
	);
	$_subtitle1 = array (
		'<a href="javascript:;"><label for="chkall">'.$are_langs['ad1'].'</label></a>',
		'ID'.'(2)',
		$are_langs['ad46'].'3',
		$are_langs['ad47'].'3',
		$are_langs['ad48'].'3',
		$are_langs['ad49'].'3',
		$are_langs['ad50'].'3',
		$are_langs['ad51'].'3',
		$are_langs['ad46'].'4',
		$are_langs['ad47'].'4',
		$are_langs['ad48'].'4',
		$are_langs['ad49'].'4',
		$are_langs['ad50'].'4',
		$are_langs['ad51'].'4',
		$are_langs['ad58'],
		$are_langs['ad32'],
	);
	$_subtitle2 = array (
		'<a href="javascript:;"><label for="chkall">'.$are_langs['ad1'].'</label></a>',
		'ID'.'(3)',
		$are_langs['ad46'].'5',
		$are_langs['ad47'].'5',
		$are_langs['ad48'].'5',
		$are_langs['ad49'].'5',
		$are_langs['ad50'].'5',
		$are_langs['ad51'].'5',
		$are_langs['ad46'].'6',
		$are_langs['ad47'].'6',
		$are_langs['ad48'].'6',
		$are_langs['ad49'].'6',
		$are_langs['ad50'].'6',
		$are_langs['ad51'].'6',
		$are_langs['ad58'],
		$are_langs['ad32'],
	);
	$_subtitle3 = array (
		'<a href="javascript:;"><label for="chkall">'.$are_langs['ad1'].'</label></a>',
		'ID'.'(4)',
		$are_langs['ad46'].'7',
		$are_langs['ad47'].'7',
		$are_langs['ad48'].'7',
		$are_langs['ad49'].'7',
		$are_langs['ad50'].'7',
		$are_langs['ad51'].'7',
		$are_langs['ad46'].'8',
		$are_langs['ad47'].'8',
		$are_langs['ad48'].'8',
		$are_langs['ad49'].'8',
		$are_langs['ad50'].'8',
		$are_langs['ad51'].'8',
		$are_langs['ad58'],
		$are_langs['ad32'],
	);
	showformheader($murl);
		$tithtm = <<<eof
	<table width=100%>
<tr>
<td>{$are_langs['ad8']} <b><font color=red>{$infos['total']}</font></b> {$are_langs['ad9']} <a href="{$turl}&addtmp=1" class="btn"> <b>{$are_langs['ad59']}</b> </a></td>
<td align=center></td>
<td align=right><form action="{$turl}" method="post" name="">
	<input type="text" name="srhkeys" placeholder="{$are_langs['ad60']}" value="{$srhkeyxs}"/> 
	<input type="submit" name="dosubmit" value=" {$are_langs['ad11']} " class="btn" style="width:auto;vertical-align:top;margin:0;" />
	</form></td>
</tr>
</table>

eof;
	showtableheader($tithtm);
	showsubtitle($_subtitle);
	showsubtitle($_subtitle1);
	showsubtitle($_subtitle2);
	showsubtitle($_subtitle3);
	
	if ($lists) {
		foreach ($lists as $v) {
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'].'(1)',
			$v['img1'] ? "<img src='{$v['img1']}' width=40 height=40>" : '',
			$v['score1'],
			$v['namefl1']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo1'],
			$v['winrate1'],
			$v['spsort1']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			$v['img2'] ? "<img src='{$v['img2']}' width=40 height=40>" : '',
			$v['score2'],
			$v['namefl2']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo2'],
			$v['winrate2'],
			$v['spsort2']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$are_langs['edit'].'</a>',
			));
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'].'(2)',
			$v['img3'] ? "<img src='{$v['img3']}' width=40 height=40>" : '',
			$v['score3'],
			$v['namefl3']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo3'],
			$v['winrate3'],
			$v['spsort3']==0 ? $are_langs['ad23'] : $are_langs['ad424'],
			$v['img4'] ? "<img src='{$v['img4']}' width=40 height=40>" : '',
			$v['score4'],
			$v['namefl4']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo4'],
			$v['winrate4'],
			$v['spsort4']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$are_langs['edit'].'</a>',
			));
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'].'(3)',
			$v['img5'] ? "<img src='{$v['img5']}' width=40 height=40>" : '',
			$v['score5'],
			$v['namefl5']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo5'],
			$v['winrate5'],
			$v['spsort5']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			$v['img6'] ? "<img src='{$v['img6']}' width=40 height=40>" : '',
			$v['score6'],
			$v['namefl6']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo6'],
			$v['winrate6'],
			$v['spsort6']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$are_langs['edit'].'</a>',
			));
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'].'(4)',
			$v['img7'] ? "<img src='{$v['img7']}' width=40 height=40>" : '',
			$v['score7'],
			$v['namefl7']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo7'],
			$v['winrate7'],
			$v['spsort7']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			$v['img8'] ? "<img src='{$v['img8']}' width=40 height=40>" : '',
			$v['score8'],
			$v['namefl8']==0 ? $are_langs['ad44'] : $are_langs['ad45'],
			$v['imginfo8'],
			$v['winrate8'],
			$v['spsort8']==0 ? $are_langs['ad23'] : $are_langs['ad24'],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$are_langs['edit'].'</a>',
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$are_langs['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$are_langs['del'].'" onclick="return confirm(\''.$are_langs['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($are_langs['nodata']));
	}
	showtablefooter(); /*Dism·taobao·com*/
	showformfooter(); /*Dism_taobao_com*/
}else {
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	showformheader($murl.'&addtmp=1&opid='.$opid, ' enctype="multipart/form-data"');
	showtableheader('<a href="'.$turl.'"><b>'.$are_langs['ad12'].'</b></a>');
	
	foreach ($sp_label as $k => $v) {
		$sp_option.= "<option value='{$k}'>{$v}</option>";
	}
	
	foreach ($sp_label2 as $k => $v) {
		$sp_option2.= "<option value='{$k}'>{$v}</option>";
	}
	
	$img1 = $r['img1'] ? "<img src='{$r['img1']}' width=40 height=40>" : '';
	$img2 = $r['img2'] ? "<img src='{$r['img2']}' width=40 height=40>" : '';
	$img3 = $r['img3'] ? "<img src='{$r['img3']}' width=40 height=40>" : '';
	$img4 = $r['img4'] ? "<img src='{$r['img4']}' width=40 height=40>" : '';
	$img5 = $r['img5'] ? "<img src='{$r['img5']}' width=40 height=40>" : '';
	$img6 = $r['img6'] ? "<img src='{$r['img6']}' width=40 height=40>" : '';
	$img7 = $r['img7'] ? "<img src='{$r['img7']}' width=40 height=40>" : '';
	$img8 = $r['img8'] ? "<img src='{$r['img8']}' width=40 height=40>" : '';
	
	$formhtml = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;} .tb.tb2 input{vertical-align:middle;}#show_bgcolor{padding:4px 25px;margin:0 10px;}</style>
	
	<tr>
		<td class=t>{$are_langs['ad46']}1:</td><td><input type="file" name="imgfile1" id="imgfile1"> <input type=hidden name=dget[img1] id=logo value="{$r['img1']}"><br><imging>{$img1}</imging></td>
		<td class=t>{$are_langs['ad47']}1:</td><td><input type="text" name="dget[score1]" id="score1" value='{$r['score1']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl1]' id=namefl1 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}1:</td><td><input type="text" name="dget[imginfo1]" id="imginfo1" value='{$r['imginfo1']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}1:</td><td><input type="text" name="dget[winrate1]" id="winrate1" value='{$r['winrate1']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort1]' id=spsort1 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}2:</td><td><input type="file" name="imgfile2" id="imgfile2"> <input type=hidden name=dget[img2] id=logo value="{$r['img2']}"><br><imging>{$img2}</imging></td>
		<td class=t>{$are_langs['ad47']}2:</td><td><input type="text" name="dget[score2]" id="score2" value='{$r['score2']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl2]' id=namefl2 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}2:</td><td><input type="text" name="dget[imginfo2]" id="imginfo2" value='{$r['imginfo2']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}2:</td><td><input type="text" name="dget[winrate2]" id="winrate2" value='{$r['winrate2']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort2]' id=spsort2 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}3:</td><td><input type="file" name="imgfile3" id="imgfile3"> <input type=hidden name=dget[img3] id=logo value="{$r['img3']}"><br><imging>{$img3}</imging></td>
		<td class=t>{$are_langs['ad47']}3:</td><td><input type="text" name="dget[score3]" id="score3" value='{$r['score3']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl3]' id=namefl3 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}3:</td><td><input type="text" name="dget[imginfo3]" id="imginfo3" value='{$r['imginfo3']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}3:</td><td><input type="text" name="dget[winrate3]" id="winrate3" value='{$r['winrate3']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort3]' id=spsort3 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}4:</td><td><input type="file" name="imgfile4" id="imgfile4"> <input type=hidden name=dget[img4] id=logo value="{$r['img4']}"><br><imging>{$img4}</imging></td>
		<td class=t>{$are_langs['ad47']}4:</td><td><input type="text" name="dget[score4]" id="score4" value='{$r['score4']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl4]' id=namefl4 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}4:</td><td><input type="text" name="dget[imginfo4]" id="imginfo4" value='{$r['imginfo4']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}4:</td><td><input type="text" name="dget[winrate4]" id="winrate4" value='{$r['winrate4']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort4]' id=spsort4 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}5:</td><td><input type="file" name="imgfile5" id="imgfile5"> <input type=hidden name=dget[img5] id=logo value="{$r['img5']}"><br><imging>{$img5}</imging></td>
		<td class=t>{$are_langs['ad47']}5:</td><td><input type="text" name="dget[score5]" id="score5" value='{$r['score5']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl5]' id=namefl5 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}5:</td><td><input type="text" name="dget[imginfo5]" id="imginfo5" value='{$r['imginfo5']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}5:</td><td><input type="text" name="dget[winrate5]" id="winrate5" value='{$r['winrate5']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort5]' id=spsort5 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}6:</td><td><input type="file" name="imgfile6" id="imgfile6"> <input type=hidden name=dget[img6] id=logo value="{$r['img6']}"><br><imging>{$img6}</imging></td>
		<td class=t>{$are_langs['ad47']}6:</td><td><input type="text" name="dget[score6]" id="score6" value='{$r['score6']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl6]' id=namefl6 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}6:</td><td><input type="text" name="dget[imginfo6]" id="imginfo6" value='{$r['imginfo6']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}6:</td><td><input type="text" name="dget[winrate6]" id="winrate6" value='{$r['winrate6']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort6]' id=spsort6 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}7:</td><td><input type="file" name="imgfile7" id="imgfile7"> <input type=hidden name=dget[img7] id=logo value="{$r['img7']}"><br><imging>{$img7}</imging></td>
		<td class=t>{$are_langs['ad47']}7:</td><td><input type="text" name="dget[score7]" id="score7" value='{$r['score7']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl7]' id=namefl7 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}7:</td><td><input type="text" name="dget[imginfo7]" id="imginfo7" value='{$r['imginfo7']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}7:</td><td><input type="text" name="dget[winrate7]" id="winrate7" value='{$r['winrate7']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort7]' id=spsort7 style="width:100px;">{$sp_option}</select></td>
	</tr>
	<tr>
		<td class=t>{$are_langs['ad46']}8:</td><td><input type="file" name="imgfile8" id="imgfile8"> <input type=hidden name=dget[img8] id=logo value="{$r['img8']}"><br><imging>{$img8}</imging></td>
		<td class=t>{$are_langs['ad47']}8:</td><td><input type="text" name="dget[score8]" id="score8" value='{$r['score8']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad48']}:</td><td><select name='dget[namefl8]' id=namefl8 style="width:100px;">{$sp_option2}</select></td>
		<td class=t>{$are_langs['ad49']}8:</td><td><input type="text" name="dget[imginfo8]" id="imginfo8" value='{$r['imginfo8']}' style='width:200px'></td>
		<td class=t>{$are_langs['ad50']}8:</td><td><input type="text" name="dget[winrate8]" id="winrate8" value='{$r['winrate8']}' style='width:100px'></td>
		<td class=t>{$are_langs['ad51']}:</td><td><select name='dget[spsort8]' id=spsort8 style="width:100px;">{$sp_option}</select></td>
	</tr>
	
	<tr><td class=t></td><td><input type="submit" value=" {$are_langs['ad38']} " name="doaddsubmit" class="btn"></td></tr>
	
	<tr>
		<td class=t style="font-size:20px;color:red;">{$are_langs['ad39']}</td>
		<td colspan=11 style="font-size:18px;">
			{$are_langs['ad61']}<br>
			{$are_langs['ad62']}<br>
			{$are_langs['ad63']}<br>
			{$are_langs['ad64']}<br>
			{$are_langs['ad65']}<br>
			{$are_langs['ad66']}<br>
			{$are_langs['ad67']}<br>
			{$are_langs['ad68']}
		</td>
	</tr>
EOF;
	echo $formhtml;
	showtablefooter(); /*Dism·taobao·com*/
	showformfooter(); /*Dism_taobao_com*/
	echo <<<eof
	<script>
	</script>
eof;
}


























