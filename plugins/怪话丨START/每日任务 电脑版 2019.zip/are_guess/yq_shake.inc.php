<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_guess'];//print_r($plg);

$plstatic = 'source/plugin/are_guess/statics/';

if ($_G['formhash'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

if ($_G['uid'] < 1) {
	shomessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
}
$ratescor = mt_rand(1, intval($plg['xyjlscore']/4)*2);//随机奖励
$typeid = intval($_GET['typeid']);
$ckget = DB::fetch_first("SELECT * FROM ".DB::table('are_guess_yq')." WHERE uid='{$_G['uid']}' LIMIT 1");
$ymd = date('Ymd', TIMESTAMP);
$ysymd = date('Ymd', TIMESTAMP -24*3600);
if ($typeid == 1) {//
	if ($ckget['yqymd'] >=$ymd) showmessage($lxlxlangs['are9']);
	if ($ckget['yqymd'] ==$ysymd) {
		$data['yqnum'] = $ckget['yqnum'] +1;
		$data['lxyqnum'] = $ckget['lxyqnum'] +1;
	}else {
		$data['lxyqnum'] = $ckget['lxyqnum'] +1;
		$data['yqnum'] = 1;
	}
	$data['yqymd'] = $ymd;
	if ($ckget) {
		$data['uptime'] = TIMESTAMP;
		DB::update('are_guess_yq', $data, array('uid'=>$_G['uid']));
	}else {
		$data['uid'] = $_G['uid'];
		$data['addtime'] = TIMESTAMP;
		DB::insert('are_guess_yq', $data);
	}
	$ac = commoncls::acscore($ratescor, $lxlxlangs['are10'], $plg['scoretype'], 0, $lxlxlangs['are10']);
	if (!$ac) {
		showmessage($lxlxlangs['are11']);
	}else {
		showmessage($lxlxlangs['are12'], dreferer());
	}
}











?>