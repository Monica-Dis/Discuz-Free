<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class myself extends commoncls {
	
	public static function userdttime() {//答题时间
		global $_G;
		$plg = $_G['cache']['plugin']['are_guess_data'];//print_r($plg);
		
		$userinfo = self::userinfo();
		$dttime = $plg['cmtime'] *60;
		if ($userinfo['jrcmymd'] + $dttime <TIMESTAMP) {
			$data['jrcmymd'] = TIMESTAMP;
			$data['cduinum'] = 0;
			$data['ccuonum'] = 0;
			$data['jrcmnum'] = 0;
			DB::update('are_guess', $data, array('id'=>$userinfo['id']));
			$userinfo['jrcmymd'] = TIMESTAMP;
		}
		return $userinfo;
	}
	
	public static function getmfnum() {//返回可用答题机会
		global $_G;
		$plg = $_G['cache']['plugin']['are_guess'];//print_r($plg);
		$mfdtnum = $plg['mfcmnum'];
		$ymd = date('Ymd', TIMESTAMP);
		$userinfo = self::userinfo();
		if ($userinfo['jrcmymd'] >= $ymd) {
			$mfdtnum -= $userinfo['jrcmnum'];
		}
		if ($userinfo['hqcmymd'] >=$ymd) {
			$mfdtnum += $userinfo['hqcmnum'];
		}
		return $mfdtnum;
	}
	
	
	public  static function hbrate($hbinfo){//抢红包随机金额
		global $_G;
		$score = $hbinfo['syhbmoney'];
		$hbnum = $hbinfo['syhbnum'];
		if ($hbnum == 1) {
			$ratescore = $score;
		}else {
			$ratescore = mt_rand(1, intval($score/3)*2);
		}
		return $ratescore;
	}
	
	public static function userinfo() {
		global $_G;
		if ($_G['uid'] <1) return array();
		$sql = "SELECT * FROM ".DB::table('are_guess')." WHERE uid='{$_G['uid']}'";
		$userinfo = DB::fetch_first($sql);
		if (empty($userinfo)) {
			$userinfo['uid'] = $_G['uid'];
			$userinfo['addtime'] = date('Ymd', TIMESTAMP);
			$userinfo['id'] = DB::insert('are_guess', $userinfo, TRUE);
		}
		return $userinfo;
	}
	
}