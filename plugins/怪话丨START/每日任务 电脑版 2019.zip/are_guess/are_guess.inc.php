<?php

/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_guess'];//print_r($plg);

$plstatic = 'source/plugin/are_guess/statics/';

if ($_G['formhash'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

if ($_G['uid'] < 1) {
	shomessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
}

$myscore = commoncls::myscore($plg['scoretype']);//积分类型

//$dttime = $plg['cmtime'] *60;print_r($dttime);

$ggao_url1 = DB::fetch_all("SELECT * FROM ".DB::table('are_guess_url')." WHERE id=1");
$ggao_url2 = DB::fetch_all("SELECT * FROM ".DB::table('are_guess_url')." WHERE id=2");

$user_picture = avatar($_G['uid'], big);//获取用户图标
//$todayquestion = showtodaynum();记录答题人数
//$todayquestion = floor($todayquestion);
$guess_data = DB::fetch_all("SELECT * FROM ".DB::table('are_guess_data')." WHERE status=0");
shuffle($guess_data);//print_r($guess_data);

$ymd = date('Ymd', TIMESTAMP);
$ysymd = date('Ymd', TIMESTAMP-24*3600);//print_r($ysymd);


$userinfo = myself::userinfo();

$du = intval($userinfo['cduinum']);
$dac = intval($userinfo['cmnum']);
$zhengl = sprintf('%0.2f', $du / $dac *100).'%';//print_r($zhengl);
	
$dttime = $plg['cmtime'] *60 *1000;

$ckbuy = array();
$qdckbuy = array();
$xy_ckbuy = array();
$yq_ckbuy = array();
if ($_G['uid'] > 0) {
	$ckbuy = DB::fetch_first("SELECT * FROM ".DB::table('are_guess')." WHERE uid='{$_G['uid']}'");
	$qdckbuy = DB::fetch_first("SELECT * FROM ".DB::table('are_guess_qd')." WHERE uid='{$_G['uid']}'");
	$xy_ckbuy = DB::fetch_first("SELECT * FROM ".DB::table('are_guess_xy')." WHERE uid='{$_G['uid']}'");
	$yq_ckbuy = DB::fetch_first("SELECT * FROM ".DB::table('are_guess_yq')." WHERE uid='{$_G['uid']}'");
}

if ($_GET['Submit'] && $_GET['formhash'] ==FORMHASH) {//留言
	if ($plg['islogin'] ==1) {
		if ($_G['uid'] <1) showmessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
	}
 	$xm =addslashes(strip_tags($_GET['xm']));
	if (!$xm) {
		showmessage($lxlxlangs['fa7']);
	}
	$email =addslashes(strip_tags($_GET['email']));
	if (!$email || strpos($email, '.') ===FALSE || strpos($email, '@') ===FALSE) {
		showmessage($lxlxlangs['fa8']);
	}
	$addr =addslashes(strip_tags($_GET['addr']));
	$neirong =addslashes(strip_tags($_GET['neirong']));
	if (!$neirong) {
		showmessage($lxlxlangs['fa9']);
	}
	
	DB::insert('are_guess_lyb', array(
		'uid'    => $_G['uid'], 
		'xm'     => $xm, 
		'email'  => $email, 
		'addr'   => $addr, 
		'neirong'=> $neirong,
		'addtime'=> TIMESTAMP
	));
	showmessage($lxlxlangs['fa10'], dreferer());
}

$pgurl = 'plugin.php?id=are_guess';
$infos = commoncls::lxlxpages('are_guess_lyb', " 1 ORDER BY id DESC ", 3, $pgurl);//print_r($infos);
$lists = $infos['lists'];//print_r($lists);

/*
$qdckbuy = array();
if ($_G['uid'] > 0) {
	$sql = "SELECT * FROM ".DB::table('are_guess_qd')." WHERE uid='{$_G['uid']}'";
	$qdckbuy = DB::fetch_first($sql);
}
*/
include template('diy:are_guess', '', commoncls::$diydir);
//include template('are_guess:are_guess');
?>