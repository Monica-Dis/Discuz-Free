<?php
/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'common.class.php';
$plstatic = commoncls::$plsrc;
$lxlxlangs = commoncls::lxlxlangs();

$file = str_replace('.inc.php', '', basename(__FILE__));
$burl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&fh='.FORMHASH.'&pmod=';
$murl = $burl.$file;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'are_guess_lyb';

if (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$addinfo = $_GET['dget'];//print_r($_GET);
	foreach ($addinfo as $k => $v) {
		$addinfo[$k] = addslashes(strip_tags($v));//dhtmlspecialchars();
	}
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	$addinfo['uptime'] = TIMESTAMP;
	if ($r) {
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = commoncls::sqlwhere($_GET['ids']);
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
	}
}

$js = <<<EOF
	<script>var CSSPATH = '{$_G[setting][csspath]}';</script>
	<link rel="stylesheet" href="{$plstatic}css/css.css" type="text/css">
	<script type="text/javascript" src="{$plstatic}dialog417/dialog.js?skin=default"></script>
	<script type="text/javascript" src="{$plstatic}dialog417/plugins/iframeTools.js"></script>
	<script type="text/javascript" src="{$plstatic}jquery.min.js"></script>
	<script type="text/javascript" src="static/js/common.js?WT2"></script>
	<script type="text/javascript" src="static/js/calendar.js"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
EOF;
echo $js;


if (!$_GET['addtmp']) {
	
	$limit = 20;
	$where = " 1 ";
	$pgurl = $turl;
	$srhkeys =addslashes(strip_tags($_GET['srhkeys']));
	if ($srhkeys) {
		$where = " (neirong LIKE '%{$srhkeys}%' OR uid='{$srhkeys}') ";
		$pgurl = $turl.'&srhkeys='.$srhkeys;
	}
	$infos = commoncls::lxlxpages($table, $where.' ORDER BY id DESC', $limit, $pgurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$lxlxlangs['fa11'].'</label></a>',
		'UID',
		$lxlxlangs['fa12'],
		$lxlxlangs['fa13'],
		$lxlxlangs['fa14'],
		$lxlxlangs['fa15'],
		$lxlxlangs['fa16'],
	);
	showformheader($murl);
		$tithtm = <<<eof
	<table width=100%>
<tr>
<td>{$lxlxlangs['fa17']} <b><font color=red>{$infos['total']}</font></b> {$lxlxlangs['fa18']} <a href="{$turl}&addtmp=1" class="btn"> <b>{$lxlxlangs['fa19']}</b> </a></td>
<td align=center></td>
<td align=right><form action="{$turl}" method="post" name="">
	<input type="text" name="srhkeys" value="{$lxlxlangs['fa20']}/{$lxlxlangs['fa21']}" onfocus="if(this.value=='{$lxlxlangs['fa20']}/{$lxlxlangs['fa21']}'){this.value=''}"/> 
	<input type="submit" name="dosubmit" value="{$lxlxlangs['fa22']}" class="btn" style="width:auto;vertical-align:top;margin:0;" />
	</form></td>
</tr>
</table>
<script>jQuery('a.buytype{$_GET['tabid']}').css({'color':'#fff', 'background':'red'})</script>
eof;
	showtableheader($tithtm);
	showsubtitle($_subtitle);
	
	if ($lists) {
		foreach ($lists as $v) {
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
				'',
				'',
				'width=100',
				'width=100',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['uid'],
			$v['neirong'],
			$v['replys'],
			$v['email'],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$lxlxlangs['replys'].'</a>',
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$lxlxlangs['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$lxlxlangs['del'].'" onclick="return confirm(\''.$lxlxlangs['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($lxlxlangs['nodata']));
	}
	showtablefooter();
	showformfooter();
}else {
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	showformheader($murl.'&addtmp=1&opid='.$opid, ' enctype="multipart/form-data"');
	showtableheader('<a href="'.$turl.'"><b>'.$lxlxlangs['emnr'].'</b></a>');
	
	echo $formhtml = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;} .tb.tb2 input{vertical-align:middle;}#show_bgcolor{padding:4px 25px;margin:0 10px;}</style>
	<tr><td class=t>{$lxlxlangs['fa23']}</td><td><textarea name="dget[neirong]" id="neirong" style='width:720px'>{$r['neirong']}</textarea></td></tr>
	<tr><td class=t>{$lxlxlangs['fa24']}</td><td><textarea name="dget[replys]" id="replys" style='width:720px'>{$r['replys']}</textarea></td></tr>
	
	<tr><td class=t></td><td><input type="submit" value="{$lxlxlangs['submit']} " name="doaddsubmit" class="btn"></td></tr>
EOF;
	showtablefooter();
	showformfooter();
	echo <<<eof
	<script>
	jQuery('#status').val('{$r['status']}');
	</script>
eof;
}
//From: Dism·taobao·com
?>