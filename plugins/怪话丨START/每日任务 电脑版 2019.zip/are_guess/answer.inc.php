<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_guess'];//print_r($plg);

$plstatic = 'source/plugin/are_guess/statics/';

if ($_G['formhash'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

if ($_G['uid'] < 1) {
	shomessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
}

$scoretype = $plg['scoretype'] > 0 && $plg['scoretype'] < 9 ? 'extcredits'.$plg['scoretype'] : '';
if (!$scoretype) {
	showmessage($lxlxlangs['hua1']);
}

$typeid = intval($_GET['typeid']);
$active = DB::fetch_first("SELECT * FROM ".DB::table('are_guess')." WHERE uid='{$_G['uid']}' LIMIT 1");
$ymd = date('Ymd', TIMESTAMP);
$ysymd = date('Ymd', TIMESTAMP -24*3600);
if ($typeid == 1) {//兑换答题次数
	if ($plg['hqcmscore'] >=1) {
		if ($active['hqcmymd'] >=$ymd) showmessage($lxlxlangs['huas']);
		$ac = commoncls::acscore(-$plg['hqcmscore'], $lxlxlangs['hua2'], $plg['scoretype2'], 0, $lxlxlangs['hua2']);
		if ($active) {
			$data['hqcmymd'] = date('Ymd', TIMESTAMP);
			if ($active['hqcmymd'] == $ymd) {	
				$data['hqcmnum'] = $active['hqcmnum'] +$plg['hqcmnum'];
			}else {
				$data['hqcmnum'] = $plg['hqcmnum'];
			}	
			DB::update('are_guess', $data, array('uid'=>$_G['uid']));
			showmessage($lxlxlangs['hua3'].$plg['hqcmnum'].$lxlxlangs['hua4'], dreferer());
		}else {
			showmessage($lxlxlangs['hua5']);
		}
	}else {
		showmessage($lxlxlangs['hua6']);
	}
}elseif ($typeid == 4) {//额外奖励
	if ($active['ewjlnum'] >=$plg['cmddnum']) {
		$data['ewjlnum'] = $active['ewjlnum']-$plg['cmddnum'];
		$data['cmnum'] = 0;
		$data['cduinum'] = 0;
		$data['ccuonum'] = 0;
		if ($active) {
			$data['ewjlymd'] = $ymd;
			DB::update('are_guess', $data, array('uid'=>$_G['uid']));
		}
		$ac = commoncls::acscore($plg['ewscore'], $lxlxlangs['hua2'], $plg['scoretype'], 0, $lxlxlangs['hua2']);
		if ($ac) {
			showmessage($lxlxlangs['hua10'].$plg['ewscore'].$lxlxlangs['hua11'], dreferer());
		}
	}else {
		showmessage($lxlxlangs['hua12'] .'<font color=red; size=25px;><b>'.($plg['cmddnum']-$active['ewjlnum']).'</b></font>'. $lxlxlangs['hua13']);
	}
}











?>