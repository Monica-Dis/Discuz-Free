<?php
/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);
$plstatic = commoncls::$plsrc;

$file = str_replace('.inc.php', '', basename(__FILE__));
$burl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&fh='.FORMHASH.'&pmod=';
$murl = $burl.$file;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'are_guess_data';

if ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$addinfo = $_GET['dget'];
	foreach ($addinfo as $k => $v) {
		$addinfo[$k] = trim(strip_tags($v));//不能再addcslashes()，入库前dz已经addcslashes()
	}
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	if ($r) {
		$addinfo['uptime'] = TIMESTAMP;
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = commoncls::sqlwhere($_GET['ids']);
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
	}
}

$js = <<<EOF
	<script>var CSSPATH = '{$_G[setting][csspath]}';</script>
	<link rel="stylesheet" href="{$plstatic}css/css.css" type="text/css">
	<script type="text/javascript" src="{$plstatic}dialog417/dialog.js?skin=default"></script>
	<script type="text/javascript" src="{$plstatic}dialog417/plugins/iframeTools.js"></script>
	<script type="text/javascript" src="{$plstatic}jquery.min.js"></script>
	<script type="text/javascript" src="static/js/common.js?WT2"></script>
	<script type="text/javascript" src="static/js/calendar.js"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript">

function setstatus(obj, id, name) {
	//var name = name ? name : '';
	jQuery.get('{$turl}&setstatus=1&opid='+ id, {name:name, t:Math.random()}, function(data){
		switch(parseInt(data)) {
			case 1 :
				jQuery(obj).html('{$lxlxlangs['no']}');
				break;
			case 0 :
				jQuery(obj).html('{$lxlxlangs['yes']}');
				break;
		}
		art.dialog.tips('{$lxlxlangs['succeed']}');
	});
}

function setoption(obj, id, name, value) {
	jQuery.get('{$turl}&setoption=1&opid='+ id, {name:name, value:value, t:Math.random()}, function(data){
		art.dialog.tips('{$lxlxlangs['succeed']}'+ data);
		if (data =='102') window.location = window.location;
	});
}



function diy_code_form(formid) {
	art.dialog({id:'diy_code_form_id', title:'{$lxlxlangs['diycode']}', content:'&lt;iframe width="100%" height="0" frameborder="0" marginheight="0" '
	+'src="plugin.php?id=levform:form&amp;ifr=1&amp;fmid='+formid+'" scrolling="no"&gt;&lt;/iframe&gt;'});
}

function deladimg(gid, src, obj) {
	if (confirm('{$lxlxlangs['confirm']}')) {
		jQuery.get('{$remote}_deladimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery(obj).parent().fadeOut();
				art.dialog.tips('{$lxlxlangs['succeed']}');
			}else {
				art.dialog.tips(data);
			}
		});
	}
}

function del_imgs(gid, src, obj) {
	if (confirm('{$lxlxlangs['confirm']}')) {
		jQuery.get('{$remote}_delimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery('#oldadimgbox').fadeOut();
				art.dialog.tips('{$lxlxlangs['succeed']}');
			}else {
				art.dialog.tips(data);
				jQuery(obj).parent().fadeOut();
			}
		});
	}
}


jQuery(function(){
	jQuery.get('{$lm}_pay._openaward.{$_GET[gid]}', {}, function(){});
});
</script>
EOF;
echo $js;

$arstatus = commoncls::xiconvs(array(0=>'A', 1=>'B', 2=>'C', 3=>'D'));//此处采用程序转码，不会出现乱码
if (!$_GET['addtmp']) {
	
	$limit = 100;
	$where = " 1 ";
	$pgurl = $turl;
	$srhkeyxs = daddslashes(trim(strip_tags($_GET['srhkeys'])));
	if ($srhkeyxs) {
		$where = "(question LIKE '%{$srhkeyxs}%') ";// OR id LIKE '%{$srhkeyxs}%'
		$pgurl = $turl.'&srhkeys='.$srhkeyxs;
	}
	$infos = commoncls::lxlxpages($table, $where.' ORDER BY id DESC', $limit, $pgurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	
	$_subtitle = commoncls::xiconvs(array (
		'<a href="javascript:;"><label for="chkall">全选</label></a>',
		'ID',
		'题目',
		'问题',
		'选项A',
		'选项B',
		'选项C',
		'选项D',
		'正确答案',
		'添加时间',
		'操作',
	));
	showformheader($murl);
		$tithtm = <<<eof
	<table width=100%>
<tr>
<td>共计 <b><font color=red>{$infos['total']}</font></b> 条 <a href="{$turl}&addtmp=1" class="btn"> <b>添 加</b> </a></td>
<td align=center></td>
<td align=right><form action="{$turl}" method="post" name="">
	<input type="text" name="srhkeys" placeholder="按问题模糊查找" value="{$srhkeyxs}"/> 
	<input type="submit" name="dosubmit" value=" 搜 索 " class="btn" style="width:auto;vertical-align:top;margin:0;" />
	</form></td>
</tr>
</table>

eof;
	showtableheader(commoncls::xiconvs($tithtm));
	showsubtitle($_subtitle);
	
	if ($lists) {
		foreach ($lists as $v) {
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'],
			$v['subject'],
			$v['problem'],
			$v['A'],
			$v['B'],
			$v['C'],
			$v['D'],
			$lxlxlangs['arstatus'.$v['arstatus']],
			dgmdate($v['addtime'], 'u'),
			'<a href="'.$turl.'&addtmp=1&opid='.$v['id'].'">'.$lxlxlangs['edit'].'</a>',
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$lxlxlangs['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$lxlxlangs['del'].'" onclick="return confirm(\''.$lxlxlangs['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($lxlxlangs['nodata']));
	}
	showtablefooter();
	showformfooter();
}else {
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	showformheader($murl.'&addtmp=1&opid='.$opid, ' enctype="multipart/form-data"');
	showtableheader(commoncls::xiconvs('<a href="'.$turl.'"><b>添加/修改信息</b></a>'));
	
	
	
	foreach ($arstatus as $k => $v) {
		$options.= "<option value='{$k}'>{$v}</option>";
	}
	
	$formhtml = <<<EOF
	
	<style>.tb.tb2 tr td.t {width:120px;text-align:right;font-weight:bold;} .tb.tb2 input{vertical-align:middle;}#show_bgcolor{padding:4px 25px;margin:0 10px;}</style>
	<tr><td class=t>题目：</td><td><input type="text" name="dget[subject]" id="subject" value='单选题' style='width:200px'></td></tr>
	<tr><td class=t>问题：</td><td><input type="text" name="dget[problem]" id="problem" value='{$r['problem']}' style='width:660px'></td></tr>
	<tr><td class=t>选项A：</td><td><input type="text" name="dget[A]" id="A" value='{$r['A']}' style='width:200px'></td></tr>
	<tr><td class=t>选项B：</td><td><input type="text" name="dget[B]" id="B" value='{$r['B']}' style='width:200px'></td></tr>
	<tr><td class=t>选项C：</td><td><input type="text" name="dget[C]" id="C" value='{$r['C']}' style='width:200px'></td></tr>
	<tr><td class=t>选项D：</td><td><input type="text" name="dget[D]" id="D" value='{$r['D']}' style='width:200px'></td></tr>
	<tr><td class=t>正确答案：</td><td><select name='dget[arstatus]' id=arstatus>{$options}</select></td></tr>
	
	<tr><td class=t></td><td><input type="submit" value=" 提 交 " name="doaddsubmit" class="btn"></td></tr>
EOF;
	echo commoncls::xiconvs($formhtml);
	showtablefooter();
	showformfooter();
	echo <<<eof
	<script>
	jQuery('#status').val('{$r['status']}');
	jQuery('#arstatus').val('{$r['arstatus']}');
	</script>
eof;
}


























