<?php
/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_guess`;
CREATE TABLE `pre_are_guess` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `jrcmnum` int(10) NOT NULL DEFAULT '0',
  `jrcmymd` int(10) NOT NULL DEFAULT '0',
  `cduinum` int(10) NOT NULL DEFAULT '0',
  `ccuonum` int(10) NOT NULL DEFAULT '0',
  `cmnum` int(10) NOT NULL DEFAULT '0',
  `cmymd` int(10) NOT NULL DEFAULT '0',
  `hqcmnum` int(10) NOT NULL DEFAULT '0',
  `hqcmymd` int(10) NOT NULL DEFAULT '0',
  `ewjlnum` int(10) NOT NULL DEFAULT '0',
  `ewjlymd` int(10) NOT NULL DEFAULT '0',
  `zqlv` varchar(255) NOT NULL,
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_xy`;
CREATE TABLE `pre_are_guess_xy` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `xynum` int(10) NOT NULL DEFAULT '0',
  `lxxynum` int(10) NOT NULL DEFAULT '0',
  `xyymd` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_yq`;
CREATE TABLE `pre_are_guess_yq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `yqnum` int(10) NOT NULL DEFAULT '0',
  `lxyqnum` int(10) NOT NULL DEFAULT '0',
  `yqymd` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_data`;
CREATE TABLE `pre_are_guess_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '0',
  `problem` varchar(255) NOT NULL DEFAULT '0',
  `A` varchar(255) NOT NULL,
  `B` varchar(255) NOT NULL,
  `C` varchar(255) NOT NULL,
  `D` varchar(255) NOT NULL,
  `arstatus` int(10) NOT NULL DEFAULT '0',
  `status` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_lyb`;
CREATE TABLE `pre_are_guess_lyb` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `xm` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `addr` varchar(255) NOT NULL,
  `neirong` text NOT NULL,
  `replys` text NOT NULL,
  `settings` text NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_qd`;
CREATE TABLE `pre_are_guess_qd` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `qdnum` int(10) NOT NULL DEFAULT '0',
  `qdymd` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_guess_url`;
CREATE TABLE `pre_are_guess_url` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `logo` varchar(255) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

EOF;

runquery($sql);
$finish = true;
?>