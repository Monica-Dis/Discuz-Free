<?php

/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if ($_GET['fh'] !==FORMHASH) exit($lxlxlangs['ze']);

require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_guess'];//print_r($plg);

$plstatic = 'source/plugin/are_guess/statics/';
$typeid = intval($_GET['typeid']);
if ($_G['uid'] <1) {
	exit('-5');
}

//if ($_GET['start']) {
//	$userinfo = myself::userdttime();
//	exit('starting');
//}

$dttime = $plg['cmtime'] *60;
$userinfo = myself::userinfo();

$qid = intval($_GET['qid']);
$myaid = intval($_GET['myaid']);

//$dtzshu = $plg['mrdtjihui']+$userinfo['hqscore'];
//if ($userinfo['datinum'] >= $dtzshu) {
//	exit('0');
//}

$mfdtnum = myself::getmfnum();

if ($mfdtnum < 1) {
	exit('3');
}

$sql = "SELECT * FROM ".DB::table('are_guess_data')." WHERE id='{$qid}'";
$rs = DB::fetch_first($sql);
//if (empty($rs)) exit('-3');

$data['cmymd'] = date('Ymd', TIMESTAMP);
$ymd = date('Ymd', TIMESTAMP);
if ($userinfo['jrcmymd'] >= $ymd) {
	$data['jrcmnum'] = $userinfo['jrcmnum'] +1;
}else {
	$data['jrcmymd'] = $ymd;
	$data['jrcmnum'] = 1;
}

if ($rs['arstatus'] == $myaid) {
	$data['cduinum'] = $userinfo['cduinum'] +1;
	$data['cmnum'] = $userinfo['cmnum'] +1;
	$data['ewjlnum'] = $userinfo['ewjlnum'] +1;
	$ac = commoncls::acscore($plg['cd_jl_score'], $lxlxlangs['hua2'], $plg['scoretype'], 0, $lxlxlangs['hua2']);	
	DB::update('are_guess', $data, array('uid'=>$_G['uid']));
	exit('1');//答对
}else {
	$data['ccuonum'] = $userinfo['ccuonum'] +1;
	$data['cmnum'] = $userinfo['cmnum']+1;
	$data['ewjlnum'] = $userinfo['ewjlnum'] +1;
	$ac = commoncls::acscore(-$plg['cc_kc_score'], $lxlxlangs['hua2'], $plg['scoretype'], 0, $lxlxlangs['hua2']);
	DB::update('are_guess', $data, array('uid'=>$_G['uid']));
	exit('2');//答错	
}




