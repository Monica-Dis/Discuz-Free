<?php

/**
 * Lev.levme.com
 *
 * Copyright (c) 2013-2014 http://www.levme.com All rights reserved.
 *
 * Author: Mr.Lee <675049572@qq.com>
 *
 * Date: 2013-02-17 16:22:17 Mr.Lee $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_are_guess extends discuz_table {
	
	public static $table = 'are_guess';
	
}
//From: Dism��taobao��com
?>