<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(defined('IN_ADMINCP')) loadcache('plugin');

class commoncls {

	public static $diydir= 'source/plugin/are_guess/template/';
	public static $plsrc = 'source/plugin/are_guess/statics/';
	public static $pgurl = 'plugin.php?id=are_guess';
	public static $pgidf = 'are_guess';
	public static $table = '#are_guess#are_guess';
	
	//积分消费
	public static function acscore($spend, $notice = '', $type = 0, $uid = 0, $title = '') {
		global $_G;
		$plg =  $_G['cache']['plugin'][self::$pgidf];
		
		$type = intval($type) ? intval($type) : $plg['scoretype'];
		$uid  = intval($uid) ? intval($uid) : $_G['uid'];
		if ($uid && intval($spend) && $type >0 && $type <9) {
			$score = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid={$uid}");
			$upscore = $score['extcredits'.$type] + $spend;
			if ($upscore >=0) {
				$title = $title ? $title : $notice;
				updatemembercount($uid, array($type=>$spend), TRUE, '', 0, '', $title, $notice);
				//if ($spend >0) $spend = '+'.$spend;
				//if (self::isopen('scnotice') && $notice) {
					//notification_add($uid, 'system', $notice.' &raquo; '.self::$lang['extscore'].' '.$spend);
				//}
				return TRUE;
			}
		}
		return false;
	}
	//
	public static function myscore($type = 0) {
		global $_G;
		if ($_G['uid'] <1) return '0';
		$plg =  $_G['cache']['plugin'][self::$pgidf];
		static $score;
		if (!$score) {
			$score = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid={$_G['uid']}");
		}
		$upscore = isset($score['extcredits'.$type]) ? $score['extcredits'.$type] : $score['extcredits'.$plg['scoretype']];
		return $upscore;
	}
	
	//递归数组转换编码
	public static function xiconvs($str, $in_charset = 'utf-8', $out_charset = CHARSET) {
		
	    $in_charset = strtoupper($in_charset);
	    $out_charset = strtoupper($out_charset);
	    if ($in_charset ==$out_charset) return $str;
	    
	    if (is_array($str)) {
	        foreach ($str as $k => $v) {
	            if (is_array($v)) {
	                $str[$k] = self::xiconvs($v, $in_charset, $out_charset);
	            }else {
	                $str[$k] = mb_convert_encoding($v, $out_charset, $in_charset);
	            }
	        }
	    }else {
	        $str = mb_convert_encoding($str, $out_charset, $in_charset);
	    }
	    return $str;
	}
	
//分页代码
	public static function lxlxpages($table, $where = '', $limit = 20, $url = '', $feilds = '*') {
		if (!$url) $url = self::$pgurl;
		
		$where = $table ? DB::table($table).' WHERE '.$where : $where ;
		$page  = max(intval($_GET['page']), 1);
		$total = DB::result_first("SELECT COUNT(*) FROM ".$where);
		$start = ($page - 1) * $limit;
		$sql   = "SELECT ".$feilds." FROM ".$where." ".DB::limit($start, $limit);
		$lists = DB::fetch_all($sql);//print_r($lists);
		$pages = multi($total, $limit, $page, $url);//print_r($pages);
		$infos = array('pages'=>$pages, 'lists'=>$lists, 'total'=>$total);
		
		return $infos;
	}

	//return $instr = 1,2,3,4,5,6
	public static function sqlwhere($array, $key = '') {
		if (!is_array($array)) {
			$array = (array)unserialize($array);
			$key = '';
		}
		$instr = '';
		if ($key) {
			foreach ($array as $v) {
				if (is_numeric($v[$key])) $instr .= $v[$key].',';
			}
		}else {
			foreach ($array as $v) {
				if (is_numeric($v)) $instr .= $v.',';
			}
		}
		if ($instr) $instr = substr($instr, 0, -1);
		return $instr;
	}
	
//获取中文语言包
	public static function lxlxlangs($string = '', $key = 0) {
		global $_G;
		if ($key && !$string) return array();
		
		$plg =  $_G['cache']['plugin'][self::$pgidf];
		$sets  = $string ? $string : $plg['lxlangs'];
		
		$lang  = array();
		if ($sets) {
			$array = explode("\n", $sets);
			foreach ($array as $r) {
				$thisr  = explode('=', trim($r), 2);
				$lang[trim($thisr[0])] = trim($thisr[1]);
			}
			if (!$key) {
				$lang['extscore']  = $_G['setting']['extcredits'][$plg['scoretype']]['title'];
				$lang['extscore2'] = $_G['setting']['extcredits'][$plg['scoretype2']]['title'];
				$lang['xfscore'] = $_G['setting']['extcredits'][$plg['xfscore']]['title'];
				$lang['jlscore'] = $_G['setting']['extcredits'][$plg['jlscore']]['title'];
				$flang = lang('plugin/'.self::$pgidf);
				if (is_array($flang)) $lang = $lang + $flang;
			}
		}
		return $lang;
	}
	
	
	
	
	
}
//From: Dism·taobao·com
?>