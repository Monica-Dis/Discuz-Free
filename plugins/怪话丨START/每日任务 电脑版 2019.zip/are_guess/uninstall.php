<?php
/**		[DisM!] (C)2001-2099 DisM Inc.
 * 
 * 		Plugin name: are_guess [每日任务]
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 * 		Compile time: 2019/06/19
 * 
 * 		Support: DisM!应用中心
 * 
 *      应用更新支持：https://dism.taobao.com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_guess`;
DROP TABLE IF EXISTS `pre_are_guess_xy`;
DROP TABLE IF EXISTS `pre_are_guess_yq`;
DROP TABLE IF EXISTS `pre_are_guess_data`;
DROP TABLE IF EXISTS `pre_are_guess_lyb`;
DROP TABLE IF EXISTS `pre_are_guess_qd`;
DROP TABLE IF EXISTS `pre_are_guess_url`;

EOF;

runquery($sql);
$finish = true;
?>