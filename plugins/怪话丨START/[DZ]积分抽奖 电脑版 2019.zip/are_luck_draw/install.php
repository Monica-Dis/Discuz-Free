<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_luck_draw`;
CREATE TABLE `pre_are_luck_draw` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(10) NOT NULL DEFAULT '0',
  `spid` int(10) NOT NULL DEFAULT '0',
  `score` int(10) NOT NULL DEFAULT '0',
  `spname` varchar(150) NOT NULL DEFAULT '0',
  `ldid` int(10) NOT NULL DEFAULT '0',
  `spsort` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_luck_draw_score`;
CREATE TABLE `pre_are_luck_draw_score` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(150) NOT NULL DEFAULT '0',
  `spid` int(10) NOT NULL DEFAULT '0',
  `spname` varchar(150) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_luck_draw_xn`;
CREATE TABLE `pre_are_luck_draw_xn` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `czid` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(150) NOT NULL DEFAULT '0',
  `spid` int(10) NOT NULL DEFAULT '0',
  `spname` varchar(150) NOT NULL DEFAULT '0',
  `address` varchar(200) NOT NULL DEFAULT '0',
  `qqadd` varchar(11) NOT NULL DEFAULT '0',
  `ordernb` varchar(50) NOT NULL DEFAULT '0',
  `confirm` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_luck_draw_sw`;
CREATE TABLE `pre_are_luck_draw_sw` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `czid` int(10) NOT NULL DEFAULT '0',
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(150) NOT NULL DEFAULT '0',
  `spid` int(10) NOT NULL DEFAULT '0',
  `spname` varchar(150) NOT NULL DEFAULT '0',
  `address` varchar(200) NOT NULL DEFAULT '0',
  `qqadd` varchar(11) NOT NULL DEFAULT '0',
  `dhadd` varchar(11) NOT NULL DEFAULT '0',
  `ordernb` varchar(50) NOT NULL DEFAULT '0',
  `confirm` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_luck_draw_ads`;
CREATE TABLE `pre_are_luck_draw_ads` (
  `uid` int(10) NOT NULL DEFAULT '0',
  `shname` varchar(150) NOT NULL DEFAULT '0',
  `region` varchar(100) NOT NULL DEFAULT '0',
  `address` varchar(200) NOT NULL DEFAULT '0',
  `iphone` varchar(11) NOT NULL DEFAULT '0',
  `qqnb` varchar(11) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_luck_draw_img`;
CREATE TABLE `pre_are_luck_draw_img` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `img1` varchar(255) NOT NULL DEFAULT '0',
  `score1` int(10) NOT NULL DEFAULT '0',
  `namefl1` int(10) NOT NULL DEFAULT '0',
  `imginfo1` varchar(150) NOT NULL DEFAULT '0',
  `winrate1` float(10) NOT NULL DEFAULT '0',
  `spsort1` int(10) NOT NULL DEFAULT '0',
  `img2` varchar(255) NOT NULL DEFAULT '0',
  `score2` int(10) NOT NULL DEFAULT '0',
  `namefl2` int(10) NOT NULL DEFAULT '0',
  `imginfo2` varchar(150) NOT NULL DEFAULT '0',
  `winrate2` float(10) NOT NULL DEFAULT '0',
  `spsort2` int(10) NOT NULL DEFAULT '0',
  `img3` varchar(255) NOT NULL DEFAULT '0',
  `score3` int(10) NOT NULL DEFAULT '0',
  `namefl3` int(10) NOT NULL DEFAULT '0',
  `imginfo3` varchar(150) NOT NULL DEFAULT '0',
  `winrate3` float(10) NOT NULL DEFAULT '0',
  `spsort3` int(10) NOT NULL DEFAULT '0',
  `img4` varchar(255) NOT NULL DEFAULT '0',
  `score4` int(10) NOT NULL DEFAULT '0',
  `namefl4` int(10) NOT NULL DEFAULT '0',
  `imginfo4` varchar(150) NOT NULL DEFAULT '0',
  `winrate4` float(10) NOT NULL DEFAULT '0',
  `spsort4` int(10) NOT NULL DEFAULT '0',
  `img5` varchar(255) NOT NULL DEFAULT '0',
  `score5` int(10) NOT NULL DEFAULT '0',
  `namefl5` int(10) NOT NULL DEFAULT '0',
  `imginfo5` varchar(150) NOT NULL DEFAULT '0',
  `winrate5` float(10) NOT NULL DEFAULT '0',
  `spsort5` int(10) NOT NULL DEFAULT '0',
  `img6` varchar(255) NOT NULL DEFAULT '0',
  `score6` int(10) NOT NULL DEFAULT '0',
  `namefl6` int(10) NOT NULL DEFAULT '0',
  `imginfo6` varchar(150) NOT NULL DEFAULT '0',
  `winrate6` float(10) NOT NULL DEFAULT '0',
  `spsort6` int(10) NOT NULL DEFAULT '0',
  `img7` varchar(255) NOT NULL DEFAULT '0',
  `score7` int(10) NOT NULL DEFAULT '0',
  `namefl7` int(10) NOT NULL DEFAULT '0',
  `imginfo7` varchar(150) NOT NULL DEFAULT '0',
  `winrate7` float(10) NOT NULL DEFAULT '0',
  `spsort7` int(10) NOT NULL DEFAULT '0',
  `img8` varchar(255) NOT NULL DEFAULT '0',
  `score8` int(10) NOT NULL DEFAULT '0',
  `namefl8` int(10) NOT NULL DEFAULT '0',
  `imginfo8` varchar(50) NOT NULL DEFAULT '0',
  `winrate8` float(10) NOT NULL DEFAULT '0',
  `spsort8` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);
$finish = true;
?>