<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$are_langs = commoncls::are_langs();
global  $_G, $arr;

if ($_G['uid'] < 1) {
	showmessage($are_langs['login'], '', array(), array('login' => TRUE));	
}

$plg = $_G['cache']['plugin']['are_luck_draw'];//引用后台参数
$plstatic = 'source/plugin/are_luck_draw/statics/';//设置$plstatic变量，快捷调用statics文件下css、images、js等方式
$myscore = commoncls::myscore($plg['scoretype']);

if ($_GET['fh'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($are_langs['fh']);
}

$ads_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_ads')." WHERE uid='{$_G['uid']}'");

$spid = intval($_GET['spid']);
$ld_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw')." WHERE id={$spid}");//print_r($ld_sql);
DB::update('are_luck_draw', array('uptime'=>TIMESTAMP), array('id'=>$spid));
if (intval($ld_sql['spsort']) == 0){
		commoncls::acscore(intval(intval($ld_sql['score'])), $are_langs['inc11'], $plg['scoretype'], $_G['uid'], $are_langs['inc11']);
		DB::insert('are_luck_draw_score', array(
			'uid'=>$_G['uid'], 
			'username'=>$_G['username'], 
			'spid'=>$spid, 
			'spname'=>$ld_sql['spname'], 
			'addtime'=>TIMESTAMP
		));
		showmessage($are_langs['inc12'], dreferer());
}elseif (intval($ld_sql['spsort']) == 1){
	$adds = $ads_sql['region'].$ads_sql['address'].$are_langs['inc99'].$ads_sql['shname'].$are_langs['inc15'];
	DB::insert('are_luck_draw_xn', array(
		'czid'=>$spid,
		'uid'=>$_G['uid'], 
		'username'=>$_G['username'], 
		'spid'=>$ld_sql['spid'], 
		'spname'=>$ld_sql['spname'], 
		'address'=>$adds, 
		'qqadd'=>$ads_sql['qqnb'], 
		'addtime'=>TIMESTAMP
	));
	showmessage($are_langs['inc13'], dreferer());
}elseif (intval($ld_sql['spsort']) == 2){
	$addrs = $ads_sql['region'].$ads_sql['address'].$are_langs['inc14'].$ads_sql['shname'].$are_langs['inc15'];
	DB::insert('are_luck_draw_sw', array(
		'czid'=>$spid,
		'uid'=>$_G['uid'], 
		'username'=>$_G['username'], 
		'spid'=>$ld_sql['spid'], 
		'spname'=>$ld_sql['spname'], 
		'address'=>$addrs, 
		'qqadd'=>$ads_sql['qqnb'], 
		'dhadd'=>$ads_sql['iphone'], 
		'addtime'=>TIMESTAMP
	));
	showmessage($are_langs['inc16'], dreferer());
}else {
	showmessage($are_langs['inc17']);
}


//From: Dism_taobao-com
?>