<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$are_langs = commoncls::are_langs();
global  $_G;

$plg = $_G['cache']['plugin']['are_luck_draw'];//引用后台参数
$plstatic = 'source/plugin/are_luck_draw/statics/';//设置$plstatic变量，快捷调用statics文件下css、images、js等方式
$myscore = commoncls::myscore($plg['scoretype']);
if ($_G['uid'] <1) {
	exit('-5');
}
if ($plg['mr_ld']>8 || $plg['mr_ld']<1) {
	exit('1');
}
if ($myscore < $plg['ld_kc']) {
	exit('2');
}
if ($_GET['fh'] != FORMHASH) {
	exit($are_langs['fh']);
}
$img_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_luck_draw_img')." WHERE 1 ORDER BY addtime DESC");
//奖品配置
$award = array(
    // 奖品ID => array('奖品名称',概率)
    1 => array($img_sql['imginfo1'],$img_sql['score1'],$img_sql['namefl1'],$img_sql['winrate1'],$img_sql['spsort1']),
    2 => array($img_sql['imginfo2'],$img_sql['score2'],$img_sql['namefl2'],$img_sql['winrate2'],$img_sql['spsort2']),
    3 => array($img_sql['imginfo3'],$img_sql['score3'],$img_sql['namefl3'],$img_sql['winrate3'],$img_sql['spsort3']),
    4 => array($img_sql['imginfo5'],$img_sql['score5'],$img_sql['namefl5'],$img_sql['winrate5'],$img_sql['spsort5']),
    5 => array($img_sql['imginfo8'],$img_sql['score8'],$img_sql['namefl8'],$img_sql['winrate8'],$img_sql['spsort8']),
    6 => array($img_sql['imginfo7'],$img_sql['score7'],$img_sql['namefl7'],$img_sql['winrate7'],$img_sql['spsort7']),
    7 => array($img_sql['imginfo6'],$img_sql['score6'],$img_sql['namefl6'],$img_sql['winrate6'],$img_sql['spsort6']),
    8 => array($img_sql['imginfo4'],$img_sql['score4'],$img_sql['namefl4'],$img_sql['winrate4'],$img_sql['spsort4']),
);

$r =rand(1,100);
$num = 0;

$award_id = intval($plg['mr_ld']);
foreach($award as $k=>$v){
    $tmp = $num;
    $num += $v[3]*100;
    if($r>$tmp && $r<=$num){
        $award_id = $k;
        break;
    }
}

if ($award_id < 1 || $award_id > 8) {
	exit();
}else{
	function jsonBack($data){
	    //header("Content-type: application/json");
	    if(isset($_GET['callback'])){
	        echo $_GET['callback']."(".json_encode($data).")";
	    }else{
	        echo json_encode($data);
	    }
	    exit();
	}
	
	function characet($data){
    if( !empty($data) ){    
    $fileType = mb_detect_encoding($data, array('UTF-8', 'GBK', 'LATIN1', 'BIG5')) ;   
        if( $fileType != 'UTF-8'){   
        $data = mb_convert_encoding($data, 'utf-8', $fileType);   
    }   
    }   
    return $data;   
	}
	
	commoncls::acscore(-intval($plg['ld_kc']), $are_langs['inc11'], $plg['scoretype'], $_G['uid'], $are_langs['inc11']);
	DB::insert('are_luck_draw', array(
									'uid'=>$_G['uid'], 
									'username'=>$_G['username'], 
									'spid'=>$award_id,
									'score'=>$award[$award_id][1],
									'spname'=>$award[$award_id][0], 
									'ldid'=>$award[$award_id][2], 
									'spsort'=>$award[$award_id][4],
									'addtime'=>TIMESTAMP
								)
			);
	//$awardlists = '=====';'awardlists'=>$awardlists
	if (intval($award[$award_id][1])!=0){
		$ad_name = $award[$award_id][1].characet(htmlspecialchars($award[$award_id][0]));
		jsonBack(array('award_id'=>$award_id,'award_name'=>$ad_name,'mcfl'=>$award[$award_id][2]));
	}else {
		$adname = characet(htmlspecialchars($award[$award_id][0]));
		jsonBack(array('award_id'=>$award_id,'award_name'=>$adname,'mcfl'=>$award[$award_id][2]));
	}
	
}

//From: Dism_taobao_com
?>