Framework7.prototype.plugins.upscroller = function (app, params) {
    'use strict';
    params = params || {text: '<i class="f7-icons">arrow_up</i>'};
    //Export selectors engine
    var $$ = window.Dom7;

    return {
        hooks : {
			pageBeforeInit: function (pageData) {				
				var $$btn = $$('<div class="upscroller">' + params.text + '</div>');				
				$$(pageData.container).prepend($$btn);
				if ($$("[data-page='"+pageData.name+"'] > .searchbar")[0]) $$("[data-page='"+pageData.name+"'] >  .upscroller").css();
				
				$$btn.click(function(event) {
					event.stopPropagation();
				    event.preventDefault();
				    //var curpage = $$(".page-content", app.getCurrentView().activePage.container);		
				    //$$(curpage).scrollTop(0, Math.round($$(curpage).scrollTop()/4));
				    $$(event.target).parent().parent().find(".page-content").scrollTop(0, 
				    		Math.round($$(event.target).parent().parent().find(".page-content").scrollTop()/8));
				});
				
				$$(".page-content", pageData.container).scroll(function(event){					  
				  var e = $$(event.target).scrollTop();
				  if(e > 300) {
			          //$$btn.addClass('show'); 
					  jQuery(event.target).parent().find(".upscroller").addClass('show');
				  }
				  else {
			          //$$btn.removeClass('show');
					  jQuery(event.target).parent().find(".upscroller").removeClass('show');
				  }					  
				});
            }
        }
    };
};




//回到顶部
var Dom7scroller = jQuery(".page-content");
Dom7scroller.bind('touchend', function (ev) {
var Dom7this = jQuery(this);
var scroller = Dom7scroller.get(0);

//if (Dom7this.scrollTop() === 0) Dom7this.scrollTop(1);
//var scrollTop = scroller.scrollTop;
//var scrollHeight = scroller.scrollHeight;
//var offsetHeight = scroller.offsetHeight;
//var contentHeight = scrollHeight - offsetHeight;
//if (contentHeight == scrollTop) Dom7this.scrollTop(scrollTop-1);
});


//操作提示窗
Framework7.prototype.plugins.toast = function (app, globalPluginParams) {
	  'use strict';
	  
	  var Toast = function (text, iconhtml, options) {
	    var self = this,
	        $$ = Dom7,
	        $box;

	    function hideBox($curbox) {
	      if ($curbox) {
	        $curbox.removeClass('fadein').transitionEnd(function () {
	          $curbox.remove();
	          if (options && typeof options.onHide == 'function') options.onHide();
	        });
	      }
	    }

	    function isString(obj) {
	      return toString.call(obj) === '[object String]';
	    }
	    
	    this.show = function (message) {
	      var clientLeft,
	          $curbox,
	          html = [];
	      
	      // Remove old toasts first if there are still any
	      $$('.toast-container').off('click').off('transitionEnd').remove();
	      $box = $$('<div class="toast-container show">');
	      
	      // Add content
	      if (isString(iconhtml) && iconhtml.length > 0) {
	        html.push(
	          '<div class="toast-icon">' + 
	            iconhtml + 
	          '</div>'
	        );
	      }

	      if (isString(message) && message.length > 0) {
	        text = message;
	      }

	      if (isString(text) && text.length > 0) {
	        html.push(
	          '<div class="toast-msg">' + 
	            text + 
	          '</div>'
	        );
	      }

	      $box.html(
	        html.join('')
	      );

	      // Add to DOM
	      clientLeft = $box[0].clientLeft;
	      $$('body').append($box);

	      //$box.css('margin-top', $box.outerHeight() / -2 + 'px')
	      //    .css('margin-left', $box.outerWidth() / -2 + 'px');
	      
	      // Hide box on click
	      $box.click(function () {
	        hideBox($box);
	      });

	      // Dirty hack to cause relayout xD
	      clientLeft = $box[0].clientLeft;
	      
	      // Fade in toast
	      $box.addClass('fadein');

	      var duration = options && options.duration ? options.duration : 1500;

	      // Automatically hide box after few seconds
	      $curbox = $box;
	      setTimeout(function () {
	        hideBox($curbox);
	    }, duration);
	    };

	    this.hide = function() {
	      hideBox($box);
	    };
	    
	    return this;
	  };
	  
	  app.toast = function (text, iconhtml, options) {
	    return new Toast(text, iconhtml, options);
	  };
};

function levtoast(txt, seconds, icon) {
	var seconds = seconds ? seconds : 5000;
	var options = {
		duration: seconds // Hide toast after 2 seconds
	},
	toast = myApp.toast(txt, '<div>'+ icon +'</div>', {duration: seconds}),
	toastWithOutIcon = myApp.toast('', '', options);
	if (icon) {
		toast.show();
	}else {
		toastWithOutIcon.show(txt);
	}
}





