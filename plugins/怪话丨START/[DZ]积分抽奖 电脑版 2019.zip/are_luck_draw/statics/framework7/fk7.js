// Initialize your app
var myApp = new Framework7({
	//material:true,
	//materialPageLoadDelay:3,
	//allowDuplicateUrls:true,
	//pushStateNoAnimation:true,
	//reloadPages:true,
	//swipePanel: 'left',//左滑动屏幕打开侧边栏
    modalTitle: '',
    modalButtonOk: '\u786e\u5b9a',//确定
	modalButtonCancel:'\u53d6\u6d88',///取消
    smartSelectBackText: '\u8fd4\u56de',//返回
    smartSelectPopupCloseText: '\u5173\u95ed',//关闭
    smartSelectPickerCloseText: '\u5b8c\u6210',//完成
	animateNavBackIcon:true,
    pushState: true,
    ajaxLinks:'a.is_ajax_a',
    
    // Hide and show indicator during ajax requests
    onAjaxStart: function (xhr) {
        myApp.showIndicator();
    },
    onAjaxComplete: function (xhr) {
        myApp.hideIndicator();
    }
});

// Export selectors engine
//var Dom7 = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    //dynamicNavbar: true,
    // Enable Dom Cache so we can use all inline pages
    //domCache: true
});


//Pull to refresh content 下拉刷新
var ptrContent = Dom7('.pull-to-refresh-content');
ptrContent.on('pullstart', function (e) {
	jQuery('.pull-to-refresh-layer .pull-to-refresh-arrow').show();
});
ptrContent.on('refresh', function (e) {
 setTimeout(function () {
     window.location = window.location;
     myApp.pullToRefreshDone();
 	jQuery('.pull-to-refresh-layer .pull-to-refresh-arrow').hide();
 }, 1000);
});


//幻灯片
var mySwiper = myApp.swiper('.hdimgs_box', {
	pagination:'.swiper-pagination',
    speed: 400,
    spaceBetween: 1,
    autoplay:2000
});  


jQuery(function() {myApp.hideIndicator();});
jQuery(document).on('click', 'a, ax, input[type="button"]', function(){
	var _thrf = jQuery(this).attr('href');
	if (_thrf && _thrf.indexOf('javascript:') <0 && _thrf.indexOf('#') <0 && jQuery(this).attr('target')!="_blank") {
		//myApp.alert(myApp.device.os);
		if (!myApp.device.os) {//手机端没效果，不执行
			myApp.showIndicator();
			window.setTimeout(function(){myApp.hideIndicator();}, 1000*3);
		}
	}else {
		//myApp.hideIndicator();
	}
	var aonclick = jQuery(this).attr('onclick');
	if (aonclick && aonclick.indexOf('showWindow') !=-1) return false;
	if (_thrf && typeof(Site__url) != 'undefined' && (_thrf +'/').indexOf(Site__url) ==-1 && _thrf.indexOf('http') ==0) {
		openziframescreenx(_thrf, jQuery(this).attr('creload'), jQuery(this).attr('titlex'), jQuery(this).attr('hidetitle'));
		if (typeof(PL__url) != 'undefined' && jQuery(this).attr('cnzz')) {
			jQuery.get(PL__url +':l&surl='+ _thrf);
		}
		return false;
	}
	if (jQuery(this).attr('target') =="_blank") {
		openziframescreenx(_thrf, jQuery(this).attr('creload'), jQuery(this).attr('titlex'), jQuery(this).attr('hidetitle'));
		return false;
	}
});
jQuery(document).on('click', 'ax, input[type="button"]', function(){
	if (jQuery(this).attr('href')) {
		window.location = jQuery(this).attr('href');
	}
});

jQuery(document).on('click', '.closescreen', function(){
	myApp.closeModal();
});
function openscreen(id, hide, obj) {
	myApp.showIndicator();
	myApp.closeModal('.picker-modal', false);
	myApp.closeModal('', false);
	myApp.loginScreen(id);//'.qju_login'
	if (!hide) {
		jQuery(id).on('opened', function(){myApp.hideIndicator();});
	}
	var replyscreen = jQuery(obj).attr('reply');
	if (replyscreen) {
		jQuery(id +' .replytoscreen').attr('class', replyscreen +' replytoscreen');
	}
	
	jQuery('.cleartzbtn').click();
}

function dom7showmsg(msgtxt, time) {
	myApp.closeModal();
	var time = time ? time : 1500;
	 myApp.modal({
		    title: false,
		    text: '<div class="msg_box">'+ msgtxt +'</div>',
		    buttons: [{
		    	text:'\u786e\u5b9a',//确定
		    	bold:true
		    }]
	 });
	 if (time >0) {
		 var cls_win = window.setTimeout(function(){
			 clearTimeout(cls_win);
			 myApp.closeModal();
		 }, time);
	 }
}

function levmarquee(elementID, h, n, speed, delay){
	var t = null;
	var box = '#' + elementID;
	jQuery(box).hover(function(){
		clearInterval(t);
	}, function(){
		t = setInterval(function(){_start(box, h, n, speed)}, delay);
	}).trigger('mouseout');
}
function _start(box, h, n, speed){
	jQuery(box).children('ul:first').animate({marginTop: '-='+h}, speed, function(){
		jQuery(this).css({marginTop:'0'}).find('li').slice(0,n).appendTo(this);
	})
}

function loginscreen() {
	//levtoast('抱歉，您需要先登陆才能执行该操作！');
	levtoast('\u62b1\u6b49\uff0c\u60a8\u9700\u8981\u5148\u767b\u9646\u624d\u80fd\u6267\u884c\u8be5\u64cd\u4f5c\uff01');
	myApp.closeModal('', false);
	myApp.loginScreen('.qju_login');
}

var ___is_timestamp = (new Date()).valueOf();
function cklevweblive(time) {
	var time = time >=1 ? time : 300000;//5分
	var timestamp = (new Date()).valueOf();
	if ((timestamp - ___is_timestamp) >time) {
		if (___is_timestamp >1) {
			___is_timestamp = -1;
			//myApp.alert('页面过期，请刷新！', function(){window.location.reload();});
			myApp.confirm('<a onclick="window.location.reload();">\u9875\u9762\u8fc7\u671f\uff0c\u8bf7\u5237\u65b0\uff01</a>', 
						function(){window.location.reload();});
		}
	}else {
		___is_timestamp = timestamp;
		return true;
	}
}

function czconfirmart(czurl, tips) {
	var tips = tips ? tips : '\u62b1\u6b49\uff0c\u60a8\u7684\u4f59\u989d\u4e0d\u8db3\uff0c\u8bf7\u5145\u503c';//抱歉，您的余额不足，请充值
	//var tips = tips ? tips : '抱歉，您的积分不足';
	myApp.confirm(tips, '', function(){
		if (czurl) {
			openziframescreenx(czurl)
			//window.location.href = czurl;
		}
	});
}

function arr_remove(val, arr) {
	var xindex = arr.indexOf(val);
	if (xindex !=-1) {
		 arr.splice(xindex, 1);
	}
	return arr;
}

function levmaxmin(noarr) {//返回数组中最大、最小数；
	var min = 0, max = 0;
	var len = noarr.length;
	for (var i=0; i<len; i++) {
		var no = parseInt(noarr[i]);
		min = i==0 || no <min ? no : min;
		max = i==0 || no >max ? no : max;
	}
	var res = [max,min];
	return res;
}

function levtoMao(val) {
	var ztop = parseInt(jQuery("#"+val).offset().top);
	var ctop = parseInt(jQuery(".page-content").scrollTop());
	var myY = ztop + ctop -44;console.log(ztop, ctop, myY);
	myY = ztop ==44 ? 0 : myY;
	jQuery(".page-content").stop().animate({ scrollTop:myY},800);
}    

function levcutstr(str, len, hasDot) {
    var newLength = 0;
    var newStr = "";
    var chineseRegex = /[^\x00-\xff]/g;
    var singleChar = "";
    var strLength = str.replace(chineseRegex, "**").length;
    for (var i = 0; i < strLength; i++) {
        singleChar = str.charAt(i).toString();
        if (singleChar.match(chineseRegex) != null) {
            newLength += 2;
        }
        else {
            newLength++;
        }
        if (newLength > len) {
            break;
        }
        newStr += singleChar;
    }

    if (hasDot && strLength > len) {
        newStr += "...";
    }
    return newStr;
}

jQuery('textarea').dblclick(function(){
    var iswhx = jQuery(this).attr('iswh');
if (iswhx =="1") {
    jQuery(this).css({height:'auto'});
    jQuery(this).attr('iswh', "0");
}else {
    jQuery(this).css({height:'700px'});
    jQuery(this).attr('iswh', "1");
}
});

jQuery(function(){
	if (typeof(___animated) =='undefined') {
		jQuery('.pages').addClass('animated fadeInRight');//页面右侧滑入
	}
	
    jQuery( ".draggable_btn" ).draggable({ cursor: "move",//拖动
        stop: function() {
        	jQuery(this).css({'right':'unset', 'bottom':'unset'});
        } 
    });//拖动
});



//artDialog 弹窗重写。
var art = {
	dialog : {
		tips: function(tip, time) {dom7showmsg(tip, 3000);}
	}
}










