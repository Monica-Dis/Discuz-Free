<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class Templates
{
    private $O_Animation_effects;
    private $value;
    private $RedList;
    private $key;
    private $O_consumption;
    private $O_consumption_number;
    private $O_integral;
    private $before_Deduct;
    private $bonus_template;
    private $lastStatus;

    public function setTemplate($O_Animation_effects, $value, $RedList, $key, $O_consumption, $O_consumption_number, $O_integral, $before_Deduct, $bonus_template, $lastStatus)
    {
        $this->O_Animation_effects = $O_Animation_effects;
        $this->value = $value;
        $this->RedList = $RedList;
        $this->key = $key;
        $this->O_consumption = $O_consumption;
        $this->O_consumption_number = $O_consumption_number;
        $this->O_integral = $O_integral;
        $this->before_Deduct = $before_Deduct;
        $this->bonus_template = $bonus_template;
        $this->lastStatus = $lastStatus;


        switch ($bonus_template) {
            case 1:
                return $this->defaultTemplate();
                break;
            case 2:
                return $this->mallTemplate();
                break;
        }

    }

    private function defaultTemplate()
    {
        $html = "";
        $html .= '<div class="zxs_envelope_red_background"></div>';
        $html .= '<div class="zxs_envelope_red_background_png"></div>';
        $html .= '<div class="zxs_envelope_red_div" style="-webkit-user-select:text !important;">';
        $html .= ' <div class="zxs_envelope_red_div_close" title="' . lang('plugin/zxs_envelope_red',
                'Lng_button_close') . '"></div>';
        $html .= ' <div class="zxs_envelope_red_div_Page ' . $this->O_Animation_effects . '">';
        $html .= ' <img src="uc_server/avatar.php?uid=' . $this->value['uid'] . '&size=big">';
        $html .= ' <input type="hidden" value="' . $this->value['bonus_states'] . '" id="bonus_states_out">';
        $titleStyle = $this->value['bonus_states'] == 4 ? "top:40%" : "";
        $html .= ' <span class="zxs_envelope_red_div_title" style="' . $titleStyle . '">' . mb_substr($this->value['bonus_title'],
                0, 8,
                "UTF-8") . '</span>';
        if ($this->value['bonus_states'] == 4) {
            $html .= ' <input type="text" placeholder="' . languageFile('js_sy_red_password') . '" class="packetsPassword-class packetsPassword">';
        }
        if (!$this->lastStatus) {
            $html .= '<div class="red_next_zxs"  nextid="' . ($this->key + 2) . '" hidx="' . $this->key . '"></div>';
        }
        $html .= ' <div class="zxs_envelope_red_button" redid="' . $this->value['ID'] . '" nextid="' . $this->key . '"  title="' . languageFile('Lng_button_lqhb') . '" data-consumption="' . $this->O_consumption . '" data-consumption-number="' . $this->O_consumption_number . '" O_integral = "' . $this->O_integral['title'] . '" before_Deduct = "' . $this->before_Deduct . '"></div>';
        $html .= ' <div class="zxs_envelope_red_button_next" nextid="' . ($this->key + 2) . '" title="' . languageFile('Lng_button_lqhb_next') . '"></div>';
        $html .= ' </div>';
        $html .= '</div>';

        return $html;
    }


    private function mallTemplate(){
        $html = "";
        $html .= '<div class="zxs_envelope_red_background"></div>';
        $html .= '<div class="zxs_envelope_red_background_png"></div>';
        $html .= '<div class="zxs_envelope_red_div" style="-webkit-user-select:text !important;">';
        $html .= ' <div class="zxs_envelope_red_div_close" title="' . lang('plugin/zxs_envelope_red',
                'Lng_button_close') . '"></div>';
        $html .= ' <div class="zxs_envelope_red_div_Page ' . $this->O_Animation_effects . '">';
        $html .= ' <img src="uc_server/avatar.php?uid=' . $this->value['uid'] . '&size=big">';
        $html .= ' <span class="zz"></span>';
        $html .= ' <input type="hidden" value="' . $this->value['bonus_states'] . '" id="bonus_states_out">';
        $titleStyle = $this->value['bonus_states'] == 4 ? "top:52%" : "";
        $html .= ' <span class="zxs_envelope_red_div_title" style="' . $titleStyle . '">' . mb_substr($this->value['bonus_title'],
                0, 8,
                "UTF-8") . '</span>';
        if ($this->value['bonus_states'] == 4) {
            $html .= ' <input type="text" placeholder="' . languageFile('js_sy_red_password') . '" class="packetsPassword-class packetsPassword">';
        }
        if (!$this->lastStatus) {
            $html .= '<div class="red_next_zxs"  nextid="' . ($this->key + 2) . '" hidx="' . $this->key . '"></div>';
        }
        $html .= ' <div class="zxs_envelope_red_button" redid="' . $this->value['ID'] . '" nextid="' . $this->key . '"  title="' . languageFile('Lng_button_lqhb') . '" data-consumption="' . $this->O_consumption . '" data-consumption-number="' . $this->O_consumption_number . '" O_integral = "' . $this->O_integral['title'] . '" before_Deduct = "' . $this->before_Deduct . '"></div>';
        $html .= ' <div class="zxs_envelope_red_button_next" nextid="' . ($this->key + 2) . '" title="' . languageFile('Lng_button_lqhb_next') . '"></div>';
        $html .= ' </div>';
        $html .= '</div>';

        return $html;
    }


}