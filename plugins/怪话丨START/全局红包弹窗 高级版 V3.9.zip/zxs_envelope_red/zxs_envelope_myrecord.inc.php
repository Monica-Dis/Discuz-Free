<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018\11\19
 * Time: 18:37
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';

if(empty($_G['uid'])){
    showmessage(languageFile('Lng_login_msg'),"member.php?mod=logging&action=login");
}
if(G_meat()){
    include template('zxs_envelope_red:myrecord');
}else{
    include template('zxs_envelope_red:touch/myrecord');
}
