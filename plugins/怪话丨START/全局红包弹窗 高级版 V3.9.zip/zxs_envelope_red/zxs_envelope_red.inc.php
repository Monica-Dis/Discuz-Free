<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018\11\15
 * Time: 9:50
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';

if (empty($_G['uid'])) {
    showmessage(languageFile('Lng_login_msg'), "member.php?mod=logging&action=login");
}

$USER_PRE = new UserListGets();
$Lang = $_G['cache']['plugin']['zxs_envelope_red'];
$user = $_G['uid'];
$SetUp = array();
$SetUp['O_title'] = empty($Lang['O_title']) ? languageFile('Lng_default_O_title') : $Lang['O_title'];
$SetUp['O_Logo'] = empty($Lang['O_Logo']) ? languageFile('Lng_default_O_Logo') : $Lang['O_Logo'];
$userInfo = new UserListGets();
$SetUp['O_integral'] = $userInfo->userIntegral(empty($Lang['O_integral']) ? 1 : $Lang['O_integral']);
$SetUp['O_fb_Max'] = $Lang['O_fb_Max'];
$SetUp['O_hb_Max'] = $Lang['O_hb_Max'];
$SetUp['O_hb_Title'] = explode("\n", $Lang['O_hb_Title']);
$SetUp['O_hb_Title'] = $global_cha ? json_encode(gbk2utf8($SetUp['O_hb_Title'])) : json_encode($SetUp['O_hb_Title']);
$Prohibit_create = $USER_PRE->userJudgeResult("Prohibit_create");
$sql_adts = DB::fetch_first("SELECT * FROM %t WHERE gid=%d", array("plugin_zxs_envelope_advertising", 1));
$advertising = empty($sql_adts['img']) ? "" : $USER_PRE->Space_information($sql_adts['img'], "|");
if(G_meat()){
    include template('zxs_envelope_red:index');
}else{
    include template('zxs_envelope_red:touch/add');
}



