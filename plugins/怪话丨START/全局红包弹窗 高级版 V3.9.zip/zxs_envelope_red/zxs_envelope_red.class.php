<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018\11\15
 * Time: 13:55
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';

class plugin_zxs_envelope_red
{
    function global_header()
    {
        $html = ' ';
        $EvCon = new EnvelopeConfiguratio();
        $ZxsRedStates = $EvCon->redDisplayWindow();
        if (!empty($ZxsRedStates)) {
            include template('zxs_envelope_red:entrance/index');
            return $ZxsRedStates . $html;
        }
    }

    function global_cpnav_extra1()
    {
        return $this->displayNone(1, 0);
    }

    function global_cpnav_extra2()
    {
        return $this->displayNone(2, 0);
    }

    function global_usernav_extra4()
    {
        return $this->displayNone(3, 2);
    }

    function global_usernav_extra2()
    {
        return $this->displayNone(4, 1);
    }

    function global_usernav_extra3()
    {
        return $this->displayNone(5, 2);
    }

    function displayNone($number, $states)
    {
        global $_G;
        $Lang = $_G['cache']['plugin']['zxs_envelope_red'];
        $O_href_color = empty($Lang['O_href_color']) ? languageFile('Lng_href_color') : $Lang['O_href_color'];
        $O_href_text = empty($Lang['O_href_text']) ? languageFile('Lng_default_O_title') : $Lang['O_href_text'];
        if ($Lang['O_Display_area'] == $number) {
            $allStates_1 = $states == 1 ? '<span class="pipe"> | </span>' : "";
            $allStates_2 = $states == 2 ? '<span class="pipe"> |</span> ' : "";
            return '<a href="plugin.php?id=zxs_envelope_red" style="text-decoration:none;color:' . $O_href_color . '">' . $allStates_1 . $O_href_text . $allStates_2 . ' </a>';
        }
    }
}




