<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018\11\15
 * Time: 13:55
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_zxs_envelope_red {
    function global_header_mobile()
    {
        require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
        global $_G;
        if($_G['cache']['plugin']['zxs_envelope_red']['O_phone_Open']==1){
            $html = ' ';
            $EvCon = new EnvelopeConfiguratio();
            $ZxsRedStates = $EvCon->redDisplayWindow();
            if(!empty($ZxsRedStates)) {
                include template('zxs_envelope_red:index');
                return  $ZxsRedStates.$html;
            }
        }
    }
}




