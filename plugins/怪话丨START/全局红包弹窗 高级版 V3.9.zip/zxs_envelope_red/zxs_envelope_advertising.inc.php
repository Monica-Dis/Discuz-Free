<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/11/20
 * Time: 11:42
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';

$USER_PRE = new UserListGets();
$baseUrl = rawurldecode(cpurl());
$formUrl = ltrim($baseUrl, 'action=');

if (submitcheck('sumbAction')) {
    $data = DB::update('plugin_zxs_envelope_advertising', array(
        'img' => $_GET['advertising_Afooter']
    ), array(
        'gid' => 1
    ), true, true);
    cpmsg(languageFile('Jump_prompt'),
        "action=plugins&operation=config&do=" . $do . "&identifier=zxs_envelope_red&pmod=zxs_envelope_advertising",
        'succeed');
} else {
    showtagheader('div', 'start', true);
    showformheader($formUrl);
    showtableheader(languageFile('Lng_permission_g_title'));
    $sql = DB::fetch_all("SELECT * FROM %t ",
        array('plugin_zxs_envelope_advertising')
    );
    showsetting(languageFile('Lng_advertising_Afooter'), 'advertising_Afooter', $sql[0]['img'], 'textarea', '', 0,
        languageFile('Lng_advertising_Afooter_msg'));
    showsubmit('sumbAction', languageFile('submit_save'));
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
    showtagfooter('div');
}

