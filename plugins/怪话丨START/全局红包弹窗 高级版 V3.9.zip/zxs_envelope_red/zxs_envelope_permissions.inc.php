<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/11/18
 * Time: 00:15
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once 'source/plugin/zxs_envelope_red/inc/Comm.class.php';
$USER_PRE = new UserListGets();
$baseUrl = rawurldecode(cpurl());
$formUrl = ltrim($baseUrl, 'action=');

if (submitcheck('sumbAction')) {
    $Forbidden_receive_group = $USER_PRE->userGrounpJudg($_GET['Forbidden_receive_group']);
    $Forbidden_Prohibit_create = $USER_PRE->userGrounpJudg($_GET['Forbidden_Prohibit_create']);
    $Forbidden_Title = $USER_PRE->userGrounpJudg($_GET['Forbidden_Forbidden_Title']);
    $Forbidden_before_Deduct = $USER_PRE->userGrounpJudg($_GET['Forbidden_before_Deduct']);
    $Red_skin = $USER_PRE->userGrounpJudg($_GET['Forbidden_Red_skin']);

    $data = DB::update('plugin_zxs_envelope_permissions', array(
        'receive_group' => $Forbidden_receive_group,
        'Prohibit_create' => $Forbidden_Prohibit_create,
        'Forbidden_Title' => $Forbidden_Title,
        'before_Deduct' => $Forbidden_before_Deduct,
        'not_logged' => $_GET['not_logged'],
        'not_logged_text' => $_GET['not_logged_text'],
        'Red_skin' => $Red_skin
    ), array(
        'ID' => 1
    ), true, true);
    if ($data) {
        cpmsg(languageFile('Jump_prompt'), "action=plugins&operation=config&do=" . $do . "&identifier=zxs_envelope_red&pmod=zxs_envelope_permissions", 'succeed');
    }
} else {
    showtagheader('div', 'start', true);
    showformheader($formUrl);
    showtableheader(languageFile('Lng_permissions_title'));
    echo $USER_PRE->Jurisdiction_area("receive_group", $USER_PRE->userGrounpPermissionsList("receive_group", 1));
    echo $USER_PRE->Jurisdiction_area("Prohibit_create", $USER_PRE->userGrounpPermissionsList("Prohibit_create", 1));
    echo $USER_PRE->Jurisdiction_area("Forbidden_Title", $USER_PRE->userGrounpPermissionsList("Forbidden_Title", 1));
    echo $USER_PRE->Jurisdiction_area("Red_skin", $USER_PRE->userGrounpPermissionsList("Red_skin", 1));
    echo $USER_PRE->Jurisdiction_area("before_Deduct", $USER_PRE->userGrounpPermissionsList("before_Deduct", 1));
    $sqlList = DB::fetch_first("SELECT * FROM %t WHERE ID=%d",
        array("plugin_zxs_envelope_permissions", 1));
    $not_logged = $sqlList['not_logged'];
    $not_logged_text = $sqlList['not_logged_text'];

    function getNotLogged($num, $not_logged)
    {
        return $not_logged == $num ? "checked" : "";
    }

    echo '<tr>
      <td colspan="2" class="td27" s="1">' . languageFile('not_logged') . '</td></tr>
        <tr class="noborder">
          <td class="vtop rowform">
            <ul onmouseover="altStyle(this);">
                <li><input class="radio" type="radio" name="not_logged" value="1" ' . getNotLogged(1, $not_logged) . ' onchange="showLoggedInput(1);">&nbsp;' . languageFile('is') . '</li>
                <li class="checked"><input class="radio" type="radio" name="not_logged" value="0" ' . getNotLogged(0, $not_logged) . ' onchange="showLoggedInput(0);">&nbsp;' . languageFile('no') . '</li>
            </ul>
        </td>
        <td class="vtop tips2" s="1">' . languageFile('not_logged_msg') . '</td></tr>';

    echo '<tr>
      <td colspan="2" class="td27" s="1">' . languageFile('not_logged_input') . '</td></tr>
        <tr class="noborder">
          <td class="vtop rowform">
                <input type="text" class="txt" style="float:left; width:210px;" name="not_logged_text" value="' . $not_logged_text . '">
        </td>
        <td class="vtop tips2" s="1">' . languageFile('not_logged_input_msg') . '</td></tr>';

    showsubmit('sumbAction', languageFile('submit_save'));
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
    showtagfooter('div');
}


