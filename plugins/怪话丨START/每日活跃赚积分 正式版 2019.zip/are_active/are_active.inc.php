<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_active'];//print_r($plg);

$plstatic = 'source/plugin/are_active/statics/';//引用css

$myscore = commoncls::myscore($plg['active']);

$ymd = date('Ymd', TIMESTAMP);//print_r($ymd);

$ckbuy = array();
if ($_G['uid'] > 0) {
	$sql = "SELECT * FROM ".DB::table('are_active')." WHERE uid='{$_G['uid']}'";
	$ckbuy = DB::fetch_first($sql);
}

$date = intval($_G['uid']);
$ftcount = myself::cktreads($date);//print_r($ftcount);

if (checkmobile()) {
	include template('are_active:are_m_getword');
}else {
	include template('are_active:are_active');
}

//include template('diy:are_active', '', commoncls::$diydir);
//include template('are_active:are_active');

?>