<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once 'common.class.php';
require_once 'myself.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_active'];//print_r($plg);

$plstatic = 'source/plugin/are_active/statics/';

if ($_G['formhash'] !=FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['formhash']);
}

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['aa'], '', array(), array('login'=>TRUE) );
}

$typeid = intval($_GET['typeid']);
$surface = DB::fetch_first("SELECT * FROM ".DB::table('are_active')." WHERE uid = '{$_G['uid']}' LIMIT 1");
$ymd = date('Ymd', TIMESTAMP);
if ($typeid == 1) {//每日活跃和积分领取
	$ysymd = date('Ymd', TIMESTAMP - 24*3600);
	if ($surface['ymd'] >= $ymd ) {
		showmessage($lxlxlangs['bb']);
	}
	if ($surface['ymd'] == $ysymd) {
		$data['hyd'] = $surface['hyd'] +$plg['mractive'];
	}else {
		$data['hyd'] = $plg['mractive'];
	}
    
	$data['ymd'] = $ymd;
	if ($surface) {
		$data['uptime'] = date('Ymd', TIMESTAMP);
		DB::update('are_active', $data, array('uid'=>$_G['uid']));
	}else {
		$data['uid'] = $_G['uid'];
		$data['addtime'] = date('Ymd', TIMESTAMP);
		DB::insert('are_active', $data);
	}
	$ac = commoncls::acscore($plg['mractive'], $lxlxlangs['cc'], $plg['active'], 0, $lxlxlangs['cc']);
	if (!$ac) {
		showmessage($lxlxlangs['dd']);
	}else {
		showmessage($lxlxlangs['ee'], dreferer());
	}
}elseif ($typeid == 2) {//当活跃值≥30,领取30积分
	
	if ($surface['hyd'] >=30) {
		$data['hyd'] = 0;
		if ($surface) {
			$data['tymd'] =date('Ymd', TIMESTAMP);
			DB::update('are_active', $data, array('uid'=>$_G['uid']));
		}
		
		$ac = commoncls::acscore($plg['lqscore30'], $lxlxlangs['cc'], $plg['active'], 0, $lxlxlangs['cc']);
		if (!$ac) {
			showmessage($lxlxlangs['dd']);
		}else {
			showmessage($lxlxlangs['ff'], dreferer());
		}
	}else {
		showmessage($lxlxlangs['gg']);
	}
}elseif ($typeid == 3) {//发帖，活跃/积分领取
	$ftcount = myself::cktreads(intval($_G['uid']));//print_r($ftcount);
	if ($surface['ymd'] >= $ymd) {
	if ($surface['posttime'] >= $ymd) showmessage($lxlxlangs['bb']);
	if ($ftcount >= $plg['ftnumber']) {
		
		$data['hyd'] = $surface['hyd'] + $plg['ftlqactive'];
		$data['posttime'] = date('Ymd', TIMESTAMP);
		DB::update('are_active', $data, array('uid'=>$_G['uid']));
		$ac = commoncls::acscore($plg['ftlqactive'], $lxlxlangs['cc'], $plg['active'], 0, $lxlxlangs['cc']);
		if (!$ac) {
			showmessage($lxlxlangs['hh']);
		}else {			
			showmessage($lxlxlangs['ee'], dreferer());
		}
	}else {
		showmessage($lxlxlangs['ii']);
	}
	}else {
		showmessage($lxlxlangs['jj']);
	}
}elseif ($typeid == 4) {//回帖,活跃/积分领取
	$htcount = myself::ckposts(intval($_G['uid']));//print_r($htcount);
	if ($surface['ymd'] >= $ymd) {
	if ($surface['Repliestime'] >= $ymd) showmessage($lxlxlangs['bb']);
	if ($htcount >= $plg['htnumber']) {
		
		$data['hyd'] = $surface['hyd'] + $plg['htlqactive'];
		$data['Repliestime'] = date('Ymd',TIMESTAMP);
		DB::update('are_active', $data, array('uid'=>$_G['uid']));
		$ac = commoncls::acscore($plg['htlqactive'], $lxlxlangs['cc'], $plg['active'], 0, $lxlxlangs['cc']);
		if (!$ac) {
			showmessage($lxlxlangs['hh']);
		}else {
			showmessage($lxlxlangs['ee'], dreferer());
		}
	}else {
		showmessage($lxlxlangs['kk']);
	}
	}else {
		showmessage($lxlxlangs['jj']);
	}
}







