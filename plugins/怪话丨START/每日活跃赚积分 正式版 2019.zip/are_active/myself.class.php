<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class myself extends commoncls {
	
	public static function cktreads() {//当天发表帖子数
		global $_G;
		if ($_G['uid'] <1) return '0';
		
		$todaytime = strtotime(date('Y-m-d', TIMESTAMP));
		$sql = "SELECT * FROM ".DB::table('forum_thread')." WHERE authorid='{$_G['uid']}' AND dateline>=$todaytime";
		$res = DB::fetch_all($sql);
		$count = count($res);
		return $count;
	}
	
	public static function ckposts() {//当天回复帖子数
		global $_G;
		if ($_G['uid'] <1) return '0';
		
		$todaytime = strtotime(date('Y-m-d', TIMESTAMP));
		$sql = "SELECT * FROM ".DB::table('forum_post')." WHERE authorid='{$_G['uid']}' AND dateline>=$todaytime AND position >1";
		$res = DB::fetch_all($sql);
		$count = count($res);
		return $count;
	}
	
}


