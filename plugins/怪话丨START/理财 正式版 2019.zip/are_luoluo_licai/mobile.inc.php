<?php

/**		Author: 帮帮帮Mr_Luo [专注Discuz论坛插件开发]
 * 
 * 		Plugin name: are_luoluo_licai [理财]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		Compile time: 2019/05/21
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      [Discuz!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_luoluo_licai'];//print_r($plg);

$plstatic = 'source/plugin/are_luoluo_licai/statics/';

$myscore = commoncls::myscore($plg['scoretype']);//commoncls：：myscore，common.class.php文件下的myscore函数
//$score = $plg['scoretype'];
//$myscore = commoncls::myscore($score);

$ymd = date('Ymd', TIMESTAMP);

$ckbuy = array();
if ($_G['uid'] > 0) {
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}'";
	$ckbuy = DB::fetch_all($sql, array(), 'typeid');
}


include template('are_luoluo_licai:are_m_getword');
?>