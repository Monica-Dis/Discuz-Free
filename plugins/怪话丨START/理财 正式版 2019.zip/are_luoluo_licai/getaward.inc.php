<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_luoluo_licai'];//print_r($plg);

$plstatic = 'source/plugin/are_luoluo_licai/statics/';

if ($_G['formhash'] !=FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
}

$typeid = intval($_GET['typeid']);//获取变量的整数值

if ($typeid == 1) {//体验版周卡积分领取
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(1, 2) LIMIT 1";
	$ck = DB::fetch_first($sql);//print_r($ck);//查询的第一条数据	
	if ($ck) {
		$ymd = date('Ymd', TIMESTAMP);
		if ($ck['ymd'] >=$ymd) {
			showmessage($lxlxlangs['hua14']);
		}
		$cktime = $ck['buytime'] + 7 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			$ac = commoncls::acscore($plg['weekget1'], $lxlxlangs['hua15'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
			if ($ac) {
				DB::update('are_luoluo_licai', array('ymd'=>$ymd), array('id'=>$ck['id']));
				showmessage($lxlxlangs['hua17'], dreferer());
			}
		}else {
			showmessage($lxlxlangs['hua18']);
		}
	}	
}elseif ($typeid == 2) {//升级版周卡积分领取
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(1, 2) LIMIT 1";
	$ck = DB::fetch_first($sql);//print_r($ck);//查询的第一条数据	
	if ($ck) {
		$ymd = date('Ymd', TIMESTAMP);
		if ($ck['ymd'] >=$ymd) {
			showmessage($lxlxlangs['hua14']);
		}
		$cktime = $ck['buytime'] + 7 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			$ac = commoncls::acscore($plg['weekget2'], $lxlxlangs['hua19'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
			if ($ac) {
				DB::update('are_luoluo_licai', array('ymd'=>$ymd), array('id'=>$ck['id']));
				showmessage($lxlxlangs['hua17'], dreferer());
			}
		}else {
			showmessage($lxlxlangs['hua20']);
		}
	}	
}elseif ($typeid == 3) {//体验版月卡积分领取
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(3, 4) LIMIT 1";
	$ck = DB::fetch_first($sql);//print_r($ck);//查询的第一条数据	
	if ($ck) {
		$ymd = date('Ymd', TIMESTAMP);
		if ($ck['ymd'] >=$ymd) {
			showmessage($lxlxlangs['hua14']);
		}
		$cktime = $ck['buytime'] + 30 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			$ac = commoncls::acscore($plg['yuekalingqu'], $lxlxlangs['hua21'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
			if ($ac) {
				DB::update('are_luoluo_licai', array('ymd'=>$ymd), array('id'=>$ck['id']));
				showmessage($lxlxlangs['hua17'], dreferer());
			}
		}else {
			showmessage($lxlxlangs['hua22']);
		}
	}	
}elseif ($typeid == 4) {//升级版月卡积分领取
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(3, 4) LIMIT 1";
	$ck = DB::fetch_first($sql);//print_r($ck);//查询的第一条数据	
	if ($ck) {
		$ymd = date('Ymd', TIMESTAMP);
		if ($ck['ymd'] >=$ymd) {
			showmessage($lxlxlangs['hua14']);
		}
		$cktime = $ck['buytime'] + 30 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			$ac = commoncls::acscore($plg['yuekalingqu2'], $lxlxlangs['hua23'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
			if ($ac) {
				DB::update('are_luoluo_licai', array('ymd'=>$ymd), array('id'=>$ck['id']));
				showmessage($lxlxlangs['hua17'], dreferer());
			}
		}else {
			showmessage($lxlxlangs['hua24']);
		}
	}	
}
//From: Dism_taobao-com
?>