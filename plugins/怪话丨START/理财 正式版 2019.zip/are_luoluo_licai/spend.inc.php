<?php

/**		Author: 帮帮帮Mr_Luo [专注Discuz论坛插件开发]
 * 
 * 		Plugin name: are_luoluo_licai [理财]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		Compile time: 2019/05/21
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      [Discuz!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs); //$lxlxlangs[' '] 用于语言包处理（处理文件中文）

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_luoluo_licai'];//print_r($plg);

if ($_G['formhash'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['login'], '', array(), array('login'=>TRUE));
}

$typeid = intval($_GET['typeid']);//获取变量的整数值


if ($typeid == 1) {//体验版周卡购买
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(1, 2) LIMIT 1";
	$ck = DB::fetch_first($sql);//查询的第一条数据	
	if ($ck) {
		$cktime = $ck['buytime'] + 7 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			showmessage($lxlxlangs['hua25']);
		}
	}	
	$spend = intval($plg['weekprice1']);//获取变量的整数值	
	if ($spend < 1) {
		showmessage($lxlxlangs['hua26']);
	}	
	$ac = commoncls::acscore(-$spend, $lxlxlangs['hua27'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
	if ($ac) {
		$timex = strtotime(date('Y-m-d', TIMESTAMP));//echo date('Y-m-d H:i:s', $timex);strtotime解析为 Unix 时间戳
		if ($ck) {
			DB::update('are_luoluo_licai', array('buytime'=>$timex, 'typeid'=>$typeid), array('id'=>$ck['id']));
		}else {
			DB::insert('are_luoluo_licai', array('uid'=>$_G['uid'], 'typeid'=>$typeid, 'buytime'=>$timex, 'addtime'=>TIMESTAMP));
		}
		showmessage($lxlxlangs['hua28'], dreferer());
	}else {
		showmessage($lxlxlangs['hua29']);
	}
}elseif ($typeid == 2) {//升级版周卡购买
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(1, 2) LIMIT 2";
	$ck = DB::fetch_first($sql);
	if ($ck) {
		$cktime = $ck['buytime'] + 7 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			showmessage($lxlxlangs['hua30']);
		}
	}
	$spend = intval($plg['weekprice2']);
	if ($spend < 1) {
		showmessage($lxlxlangs['hua26']);
	}
	$ac = commoncls::acscore(-$spend, $lxlxlangs['hua31'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
	if ($ac) {
		$timex = strtotime(date('Y-m-d', TIMESTAMP));//echo date('Y-m-d H:i:s', $timex);
		if ($ck) {
			DB::update('are_luoluo_licai', array('buytime'=>$timex, 'typeid'=>$typeid), array('id'=>$ck['id']));
		}else {
			DB::insert('are_luoluo_licai', array('uid'=>$_G['uid'], 'typeid'=>$typeid, 'buytime'=>$timex, 'addtime'=>TIMESTAMP));
		}
		showmessage($lxlxlangs['hua32'], dreferer());
	}else {
		showmessage($lxlxlangs['hua29']);
	}
}elseif ($typeid == 3) {//体验版月卡购买
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(3, 4) LIMIT 3";
	$ck = DB::fetch_first($sql);
	if ($ck) {
		$cktime = $ck['buytime'] + 30 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			showmessage($lxlxlangs['hua33']);
		}
	}
	$spend = intval($plg['yuekajiage']);
	if ($spend < 1) {
		showmessage($lxlxlangs['hua26']);
	}
	$ac = commoncls::acscore(-$spend, $lxlxlangs['hua34'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
	if ($ac) {
		$timex = strtotime(date('Y-m-d', TIMESTAMP));//echo date('Y-m-d H:i:s', $timex);
		if ($ck) {
			DB::update('are_luoluo_licai', array('buytime'=>$timex, 'typeid'=>$typeid), array('id'=>$ck['id']));
		}else {
			DB::insert('are_luoluo_licai', array('uid'=>$_G['uid'], 'typeid'=>$typeid, 'buytime'=>$timex, 'addtime'=>TIMESTAMP));
		}
		showmessage($lxlxlangs['hua35'], dreferer());
	}else {
		showmessage($lxlxlangs['hua29']);
	}
}elseif ($typeid == 4) {//升级版月卡购买
	$sql = "SELECT * FROM ".DB::table('are_luoluo_licai')." WHERE uid='{$_G['uid']}' AND typeid IN(3, 4) LIMIT 4";
	$ck = DB::fetch_first($sql);
	if ($ck) {
		$cktime = $ck['buytime'] + 30 * 24 * 3600;
		if (TIMESTAMP < $cktime) {
			showmessage($lxlxlangs['hua36']);
		}
	}
	$spend = intval($plg['yuekajiage1']);
	if ($spend < 1) {
		showmessage($lxlxlangs['hua26']);
	}
	$ac = commoncls::acscore(-$spend, $lxlxlangs['hua37'], $plg['scoretype'], $_G['uid'], $lxlxlangs['hua16']);
	if ($ac) {
		$timex = strtotime(date('Y-m-d', TIMESTAMP));//echo date('Y-m-d H:i:s', $timex);
		if ($ck) {
			DB::update('are_luoluo_licai', array('buytime'=>$timex, 'typeid'=>$typeid), array('id'=>$ck['id']));
		}else {
			DB::insert('are_luoluo_licai', array('uid'=>$_G['uid'], 'typeid'=>$typeid, 'buytime'=>$timex, 'addtime'=>TIMESTAMP));
		}
		showmessage($lxlxlangs['hua38'], dreferer());
	}else {
		showmessage($lxlxlangs['hua29']);
	}
}
//From: Dism_taobao-com
?>