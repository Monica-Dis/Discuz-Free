<?php
/**		Author: 帮帮帮Mr_Luo [专注Discuz论坛插件开发]
 * 
 * 		Plugin name: are_luoluo_licai [理财]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		Compile time: 2019/05/21
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      [Discuz!] (C) 87661 All rights reserved $Id$
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_luoluo_licai`;
CREATE TABLE `pre_are_luoluo_licai` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `typeid` int(10) NOT NULL DEFAULT '0',
  `ymd` int(10) NOT NULL DEFAULT '0',
  `settings` text NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `buytime` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);
$finish = TRUE; /*dism·taobao·com*/
?>