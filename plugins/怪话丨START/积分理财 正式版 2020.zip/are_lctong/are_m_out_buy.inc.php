<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

if ($_G['uid'] < 1) {//若没有登录论坛，将弹出登录窗口
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));
}

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_lctong'];//print_r($plg);
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

$sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_m_hq')." WHERE uid='{$_G['uid']}'");

if ($_GET['out_btn'] && $_GET['fh'] == FORMHASH) {
	$score_out = intval($_GET['score_out']);
	if ($score_out <=0){
		showmessage($lxlxlangs['minc6']);
	}
	
	if($score_out > $sql['xmmoney']){
		showmessage($lxlxlangs['minc7']);
	}
	
	$ac = commoncls::acscore($score_out, $lxlxlangs['minc8'], 0, 0, $lxlxlangs['minc4']);
	DB::update('are_lctong_m_hq', array('xmmoney'=>$sql['xmmoney']-$score_out, 'outmoney'=>$score_out, 'outtime'=>TIMESTAMP , 'addtime'=>TIMESTAMP, 'ljmoney'=>0), array('uid'=>$_G['uid']));
	
	DB::insert('are_lctong_m_hqout', array('uid'=>$_G['uid'], 'username'=>$_G['username'], 'outmoney'=>$score_out, 'addtime'=>TIMESTAMP));
	
	showmessage($lxlxlangs['minc9'], dreferer());
}


//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>