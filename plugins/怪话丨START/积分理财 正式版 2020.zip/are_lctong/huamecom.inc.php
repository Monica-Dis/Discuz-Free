<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

//DB::update('lev_award_award', array('uid'=>10, 'bbsname'=>'levaward'));
//DB::update('lev_award', array('uid'=>10, 'bbsname'=>'levaward'));

header('location:http://dism.taobao.com/?@87661.developer');