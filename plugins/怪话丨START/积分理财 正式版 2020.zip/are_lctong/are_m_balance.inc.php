<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();
global  $_G;

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));	
}

$plg = $_G['cache']['plugin']['are_lctong'];
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

//每天返回利息
$sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_m_hq')." WHERE uid='{$_G['uid']}'");

$ymd = date('Ymd', TIMESTAMP);
$gmtime = date('Ymd', $sql['uptime']);
$m_time = date('m', TIMESTAMP);//获取本月月份
$m_dt = date('d', TIMESTAMP);//获取当前日期
$zh_time = date('m', $sql['uptime']);//获得最后收益的月份
$yz_time = date('Y', $sql['uptime']);//获得最后收益的年份
$yd_time = date('Y', TIMESTAMP);//获得当前的年份

$startdate=date('Ym01', strtotime(date("Ymd")));
$dqd_d = date('d', strtotime("$startdate+1 month -1 day"));//获取本月中的最后一天日期

if($yd_time >$yz_time){//当前年份大于最后收益的年份，计算可获取的累计收益
	$dqm_m = date('m', TIMESTAMP) + 12*($yd_time - $yz_time) - $zh_time;
	$qhtime = $dqd_d*$dqm_m;
}else{
	if ($m_time >$zh_time){
		if(intval($m_time-$zh_time)==1){
			$sm_dt = date('Ymd', strtotime(date('Ym01').' -1 day'));//获取上一个月最后一天
			$qhtime = $sm_dt - $gmtime + $m_dt;//计算总天数
		}elseif(intval($m_time-$zh_time)>1){
			$qhtime = $dqd_d*($m_time-$zh_time); 
		}
	}else{
		$qhtime = $ymd - $gmtime;//计算总天数
	}
}

$hq_lv = $plg['hq_lv'] >0 ? $plg['hq_lv'] : 1;
$flt = $hq_lv/100;
$mtlr = intval($sql['xmmoney']*$flt/356);//print_r($mtlr);
$wdl = intval($mtlr*$qhtime);//print_r($wdl);
$zsymoney = $sql['xmmoney']+$wdl;

$uptime = date('Ymd', $sql['uptime']);
if($ymd > $uptime){
	DB::update('are_lctong_m_hq', array('xmmoney'=>$zsymoney,'daymoney'=>$mtlr,'ljmoney'=>$sql['ljmoney']+$wdl,'uptime'=>TIMESTAMP), array('uid'=>$_G['uid']));
	if (!empty($sql)){
		DB::insert('are_lctong_m_hqprofit', array('uid'=>$_G['uid'], 'username'=>$_G['username'], 'profitmoney'=>$wdl, 'addtime'=>TIMESTAMP));
	}
}

$hqlc = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_m_hq')." WHERE uid='{$_G['uid']}'");

include template('are_lctong:are_m_balance');

?>