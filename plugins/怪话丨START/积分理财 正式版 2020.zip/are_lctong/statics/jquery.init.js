

var $$ = jQuery.noConflict();