
$(function(){
	var c = 0;
	//改变显示效果
	function shxs(){
		//让c号图片显示，兄弟图片隐藏
		$("#img_div img").eq(c).stop().fadeIn(200).siblings("img").stop().fadeOut(200);
		//让c号li变红，兄弟li变灰
		$("#img_div ul li").eq(c).css('background','red').siblings("li").css('background','#dddddd');
	}
	//定时器调用的函数
	function autor(){
		c++;
		c = c==$("#img_div img").length ? 0 : c;
		shxs();
	}
	var timer = setInterval(autor, 5000);
	$("#img_div").mouseenter(function(){
		//清除定时器
		clearInterval(timer);
	});
	$("#img_div").mouseleave(function(){
		timer = setInterval(autor, 5000);
	});
	//给小圆点加鼠标移入事件
	$("#img_div ul li").mouseenter(function(){
		//获得移入的li的序号
		c = $(this).index();
		shxs();
	});
});