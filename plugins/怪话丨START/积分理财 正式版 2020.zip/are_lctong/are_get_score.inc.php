<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs); //$lxlxlangs[' '] 用于语言包处理（处理文件中文）

if ($_G['uid'] < 1) {//若没有登录论坛，将弹出登录窗口
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));
}

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_lctong'];//print_r($plg);
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

if ($_GET['fh'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

$gid = intval($_GET['gid']);
$gs_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_spend')." WHERE id={$gid}");

$xmlv = $gs_sql['xmlv']/100;
$mtsy = $xmlv/365;
$xmmoney_lv = round($gs_sql['xmmoney']*$mtsy*$gs_sql['xmday']);
$xmmoney = $gs_sql['xmmoney']+$xmmoney_lv;

$get = commoncls::acscore($xmmoney, $lxlxlangs['inc4'].$gs_sql['xmname'], $plg['scoretype'], $_G['uid'], $lxlxlangs['inc2']);
if ($get){
	DB::insert('are_lctong_draw', array(
		'uid'=>$_G['uid'],
		'username'=>$_G['username'],
		'xmid'=>$gid,
		'xmimg'=>$gs_sql['xmimg'],
		'xmname'=>$gs_sql['xmname'],
		'xmmoney'=>$gs_sql['xmmoney'],
		'xmlv'=>$gs_sql['xmlv'],
		'xmday'=>$gs_sql['xmday'],
		'xmfbxs'=>$gs_sql['xmfbxs'],
		'dwtime'=>TIMESTAMP,
		'buytime'=>$gs_sql['buytime']
	));
	DB::query("DELETE FROM ".DB::table('are_lctong_spend')." WHERE id='{$gid}'");
	showmessage($lxlxlangs['inc5'], dreferer());
}













