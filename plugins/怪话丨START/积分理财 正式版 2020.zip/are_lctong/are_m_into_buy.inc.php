<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);

if ($_G['uid'] < 1) {//若没有登录论坛，将弹出登录窗口
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));
}

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_lctong'];//print_r($plg);
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

$sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_m_hq')." WHERE uid='{$_G['uid']}'");

if ($_GET['into_btn'] && $_GET['fh'] == FORMHASH) {
	
	$score_into = intval($_GET['score_into']);
	if ($score_into <=0){
		showmessage($lxlxlangs['minc1']);
	}
	if ($myscore < $score_into){
		showmessage($lxlxlangs['minc2']);
	}
	
	$ac = commoncls::acscore(-$score_into, $lxlxlangs['minc3'], 0, 0, $lxlxlangs['minc4']);
		
	if ($_G['uid'] == $sql['uid']) {
		DB::update('are_lctong_m_hq', array('username'=>$_G['username'],'xmmoney'=>$sql['xmmoney']+$score_into, 'intomoney'=>$score_into, 'intotime'=>TIMESTAMP, 'addtime'=>TIMESTAMP), array('uid'=>$_G['uid']));
	}else{
		DB::insert('are_lctong_m_hq', array('username'=>$_G['username'],'uid'=>$_G['uid'], 'xmmoney'=>$score_into, 'intomoney'=>$score_into, 'intotime'=>TIMESTAMP, 'addtime'=>TIMESTAMP, 'uptime'=>TIMESTAMP));
	}
	DB::insert('are_lctong_m_hqinto', array('uid'=>$_G['uid'], 'username'=>$_G['username'], 'intomoney'=>$score_into, 'addtime'=>TIMESTAMP));
		
	showmessage($lxlxlangs['minc5'], dreferer());
}


//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>