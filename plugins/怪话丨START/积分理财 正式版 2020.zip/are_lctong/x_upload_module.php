<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';

class x_upload_module {

	public static function up_image($field) {
		$uploadurl = commoncls::$plsrc.'upload/common/';//print_r($_FILES);
		if ($_FILES[$field]['size']) {
			$attach = self::upload($_FILES[$field]);
			if ($attach['attachment']) {
				$data = $uploadurl.$attach['attachment'];
			}
		}
		return $data;
	}

	public static function up_attach($field) {
		$uploadurl = commoncls::$plsrc.'upload/common/';
		if ($_FILES[$field]['size']) {
			$attach = self::upload($_FILES[$field], 0);
			if ($attach['attachment']) {
				$data = $uploadurl.$attach['attachment'];
			}
		}
		return $data;
	}
	
	
	public static function upload($files, $isimg = 1, $ext = array(), $extid = 0, $forcename = '') {//X2.5 up
		self::ckupload($files, $isimg);
		if (is_array($files)) {
			if (!$isimg) {
				$ext = $ext ? $ext : self::exts();
			}
			$PLSTATIC = commoncls::$plsrc;
			$fileroot = DISCUZ_ROOT.$PLSTATIC.'upload/';
			dmkdir($fileroot);
		    setglobal('setting/attachdir', $fileroot);//更改上传目录到$fileroot插件目录
			require_once libfile('discuz/upload', 'class');
		    $upload = new discuz_upload();
		    if($upload->init($files, 'common', $extid, $forcename) && $upload->save(1)) {//print_r($upload->attach);
		    	if ($isimg && !$upload->attach['isimage']) {
					@chmod($upload->attach['target'], 0644); 
					@unlink($upload->attach['target']);
		    	}elseif (!empty($ext) && !in_array($upload->attach['ext'], $ext)) {
					@chmod($upload->attach['target'], 0644); 
					@unlink($upload->attach['target']);
		    	}else{
		    		if (!$isimg && self::isopen('zip') && !in_array($upload->attach['ext'], array('zip', 'rar'))) {
		    			rename($upload->attach['target'], $upload->attach['target'].'.'.$upload->attach['ext']);
		    			$upload->attach['attachment'] .= '.'.$upload->attach['ext'];
		    		}
		    		return $upload->attach;
		    	}
		    }
		}
	}
	public static function ckupload($thumb, $isimage = 1, $uploadsize = 0) {
		$uploadsize = $uploadsize ? $uploadsize : 100000;
		if ($thumb['error']) {
			showmessage(commoncls::xiconvs('文件上传失败！'.$thumb['error']));
		}elseif ($thumb['size'] > $uploadsize * 1000) {
			showmessage(commoncls::xiconvs('操作失败！上传文件超出限制【100000KB】'));
		}elseif ($isimage && !strstr($thumb['type'], 'image')) {
			showmessage(commoncls::xiconvs('操作失败！请上传图片文件！'));
		}
	}
	public static function exts() {
		$exts = explode('=', trim(commoncls::$PL_G['exts']));
		if ($exts[0]) return $exts;
		return array();
	}
	
	public static function isopen() {
		
	}
}







