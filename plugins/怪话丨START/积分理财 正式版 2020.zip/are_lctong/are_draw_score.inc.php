<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs); //$lxlxlangs[' '] 用于语言包处理（处理文件中文）


if ($_G['uid'] < 1) {//若没有登录论坛，将弹出登录窗口
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));
}

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_lctong'];//print_r($plg);
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

if ($_GET['fh'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

$dwid = intval($_GET['dwid']);
$dws_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_spend')." WHERE id={$dwid}");

$kc_score = $plg['tq_sxf']/100;
$sy_score = round($dws_sql['xmmoney']-$kc_score*$dws_sql['xmmoney']);

$draw = commoncls::acscore($sy_score, $lxlxlangs['inc1'].$dws_sql['xmname'], $plg['scoretype'], $_G['uid'], $lxlxlangs['inc2']);
if ($draw){
	DB::insert('are_lctong_draw', array(
		'uid'=>$_G['uid'],
		'username'=>$_G['username'],
		'xmid'=>$dwid,
		'xmimg'=>$dws_sql['xmimg'],
		'xmname'=>$dws_sql['xmname'],
		'xmmoney'=>$dws_sql['xmmoney'],
		'xmlv'=>$dws_sql['xmlv'],
		'xmday'=>$dws_sql['xmday'],
		'xmfbxs'=>$dws_sql['xmfbxs'],
		'dwtime'=>TIMESTAMP,
		'buytime'=>$dws_sql['buytime']
	));
	DB::query("DELETE FROM ".DB::table('are_lctong_spend')." WHERE id='{$dwid}'");
	showmessage($lxlxlangs['inc3'], dreferer());
}













