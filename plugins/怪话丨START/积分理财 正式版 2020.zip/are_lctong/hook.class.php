<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_are_lctong {//普通版脚本中的类名以 plugin_ 开头
    
    public static function global_footer() {
        $PLSTATIC = self::$PLSTATIC;
        $lxlxlangs = self::$lang;
        include template('are_lctong:hook_block');
        $hkhtm.= self::loadjs();
        return $hkhtm;
    }
	
	public function __construct() {
		self::_init();
	}
	public static $PL_G, $_G, $PLNAME, $PLSTATIC, $PLURL, $lang = array(), $table, $navtitle, $uploadurl, $remote, $talk;
	public static $lm, $lm2, $loadjs;
	public static function _init() {

		global $_G;
		self::$_G     = $_G;
		self::$PLNAME = 'are_lctong';
		self::$PL_G   = self::$_G['cache']['plugin'][self::$PLNAME];//print_r($PL_G);

		self::$PLSTATIC = 'source/plugin/'.self::$PLNAME.'/statics/';
		self::$PLURL    = 'plugin.php?id='.self::$PLNAME;
		self::$uploadurl= self::$PLSTATIC.'upload/common/';
		self::$remote   = 'plugin.php?id='.self::$PLNAME.':l&fh='.FORMHASH.'&m=';
		self::$lm       = self::$remote.'_m.';
		self::$lm2      = self::$remote.'__m.';
		self::$loadjs   = self::$remote.'__m.x_loadjs.__init';
		self::$lang     = self::lxlxlangs();
	}

	//return $instr = 1,2,3,4,5,6
	public static function sqlinstr($array, $key = '') {
		if (!is_array($array)) {
			$array = (array)unserialize($array);
			$key = '';
		}
		$instr = '';
		if ($key) {
			foreach ($array as $v) {
				if (is_numeric($v[$key])) $instr .= $v[$key].',';
			}
		}else {
			foreach ($array as $v) {
				if (is_numeric($v)) $instr .= $v.',';
			}
		}
		if ($instr) $instr = substr($instr, 0, -1);
		return $instr;
	}
	
	public static function lxlxlangs($string = '', $key = 0) {
		$sets  = $string ? $string : (!$key ? self::$PL_G['lxlangs'] : '');
		$lang  = array();
		if ($sets) {
			$array = explode("\n", $sets);
			foreach ($array as $r) {
				$thisr  = explode('=', trim($r), 2);
				$lang[trim($thisr[0])] = trim($thisr[1]);
			}
			if (!$key) {
				$lang['extscore'] = self::$_G['setting']['extcredits'][self::$PL_G['scoretype']]['title'];
				$flang = lang('plugin/are_lctong');
				if (is_array($flang)) $lang = $lang + $flang;
			}
		}
		return $lang;
	}

	public static function _lxxdiconv($string, $in_charset = 'utf-8', $out_charset = CHARSET) {
		if(is_array($string)) {
			foreach($string as $key => $val) {
				$string[$key] = diconv($val, $in_charset, $out_charset);
			}
		} else {
			$string = diconv($string, $in_charset, $out_charset);
		}
		return $string;
	}
	
	public static function _isopen($key = 'close') {
		$isopen = unserialize(self::$PL_G['isopen']);
		if (is_array($isopen) && in_array($key, $isopen)) return TRUE;
		return FALSE;
	}
	
	public static function loadjs() {
		//$js = '<script language="javascript" type="text/javascript" src="'.self::$loadjs.'"></script>';
		$PLSTATIC = self::$PLSTATIC;
		$js =<<<eof
		
	<link  href='{$PLSTATIC}dialog417/skins/default.css?4.1.7' type='text/css' rel='stylesheet'>
	<script src='{$PLSTATIC}dialog417/dialog.js?skin=default' type='text/javascript'></script>
	<script src='{$PLSTATIC}dialog417/plugins/iframeTools.js' type='text/javascript'></script>
eof;
		return $js;
	}

	
}

class plugin_are_lctong_forum extends plugin_are_lctong {}
