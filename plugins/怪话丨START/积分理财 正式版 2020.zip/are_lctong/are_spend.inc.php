<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs); //$lxlxlangs[' '] 用于语言包处理（处理文件中文）

if ($_G['uid'] < 1) {//若没有登录论坛，将弹出登录窗口
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));
}

$navtitle = $lxlxlangs['navtitle'];
$_G['setting']['bbname'] = $lxlxlangs['bbname'] ? $lxlxlangs['bbname'] : $_G['setting']['bbname'];
$metakeywords = $lxlxlangs['metakeywords'] ? $lxlxlangs['metakeywords'] : $metakeywords;
$metadescription = $lxlxlangs['metadescription'] ? $lxlxlangs['metadescription'] : $metadescription;

$plg = $_G['cache']['plugin']['are_lctong'];//print_r($plg);
$plstatic = 'source/plugin/are_lctong/statics/';
$myscore = commoncls::myscore($plg['scoretype']);

if ($_GET['fh'] != FORMHASH) {//检测请求来源（如调用submitcheck()或校验formhash）避免CSRF
	showmessage($lxlxlangs['fh']);
}

$xmid = intval($_GET['xmid']);
$xms_sql = DB::fetch_first("SELECT * FROM ".DB::table('are_lctong_addxm')." WHERE id={$xmid}");
if ($myscore <$xms_sql['xmmoney']) {
	showmessage($lxlxlangs['inc6']);
}
$cut = commoncls::acscore(-$xms_sql['xmmoney'], $lxlxlangs['inc7'].$xms_sql['xmname'], 0, 0, $lxlxlangs['inc2']);
if ($cut){
	DB::insert('are_lctong_spend', array(
		'uid'=>$_G['uid'], 
		'username'=>$_G['username'], 
		'xmid'=>$xmid, 
		'xmimg'=>$xms_sql['xmimg'], 
		'xmname'=>$xms_sql['xmname'], 
		'xmmoney'=>$xms_sql['xmmoney'], 
		'xmlv'=>$xms_sql['xmlv'], 
		'xmday'=>$xms_sql['xmday'], 
		'xmfbxs'=>$xms_sql['xmfbxs'], 
		'buytime'=>TIMESTAMP
	));
	DB::insert('are_lctong_record', array(
		'uid'=>$_G['uid'], 
		'username'=>$_G['username'], 
		'xmid'=>$xmid, 
		'xmimg'=>$xms_sql['xmimg'], 
		'xmname'=>$xms_sql['xmname'], 
		'xmmoney'=>$xms_sql['xmmoney'], 
		'xmlv'=>$xms_sql['xmlv'], 
		'xmday'=>$xms_sql['xmday'], 
		'xmfbxs'=>$xms_sql['xmfbxs'], 
		'buytime'=>TIMESTAMP
	));
	DB::update('are_lctong_addxm', array('xmnums'=>$xms_sql['xmnums']-1, 'xmysnums'=>$xms_sql['xmysnums']+1), array('id'=>$xmid));
	showmessage($lxlxlangs['inc8'], dreferer());
}













