<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_lctong_m_img`;
CREATE TABLE `pre_are_lctong_m_img` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL DEFAULT '0',
  `imginfo` varchar(255) NOT NULL DEFAULT '0',
  `b_n` varchar(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_lctong_m_notice`;
CREATE TABLE `pre_are_lctong_m_notice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL DEFAULT '0',
  `content_url` varchar(255) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_lctong_m_hq`;
CREATE TABLE `pre_are_lctong_m_hq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `xmmoney` int(10) NOT NULL DEFAULT '0',
  `daymoney` int(10) NOT NULL DEFAULT '0',
  `ljmoney` int(10) NOT NULL DEFAULT '0',
  `intomoney` int(10) NOT NULL DEFAULT '0',
  `intotime` int(10) NOT NULL DEFAULT '0',
  `outmoney` int(10) NOT NULL DEFAULT '0',
  `outtime` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_lctong_m_hqinto`;
CREATE TABLE `pre_are_lctong_m_hqinto` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `intomoney` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_lctong_m_hqout`;
CREATE TABLE `pre_are_lctong_m_hqout` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `outmoney` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `pre_are_lctong_m_hqprofit`;
CREATE TABLE `pre_are_lctong_m_hqprofit` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '0',
  `profitmoney` int(10) NOT NULL DEFAULT '0',
  `uptime` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

EOF;

runquery($sql);
$finish = TRUE; /*dism·taobao·com*/
?>