<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();
global  $_G;

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));	
}

$plg = $_G['cache']['plugin']['are_lctong'];
$plstatic = 'source/plugin/are_lctong/statics/';

$zsimg_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_lctong_m_img')." WHERE 1 ORDER BY id DESC");

$notice_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_lctong_m_notice')." WHERE 1 ORDER BY id DESC");

$synums = $plg['sy_num'] >0 ? $plg['sy_num'] : 10;
$xms_sql = DB::fetch_all("SELECT * FROM ".DB::table('are_lctong_addxm')." WHERE 1 ORDER BY addtime DESC  LIMIT {$synums}");


include template('are_lctong:are_m_lctong');

?>