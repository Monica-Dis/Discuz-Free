<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_are_lctong_addxm`;
DROP TABLE IF EXISTS `pre_are_lctong_spend`;
DROP TABLE IF EXISTS `pre_are_lctong_record`;
DROP TABLE IF EXISTS `pre_are_lctong_draw`;
DROP TABLE IF EXISTS `pre_are_lctong_m_img`;
DROP TABLE IF EXISTS `pre_are_lctong_m_notice`;
DROP TABLE IF EXISTS `pre_are_lctong_m_hq`;
DROP TABLE IF EXISTS `pre_are_lctong_m_hqinto`;
DROP TABLE IF EXISTS `pre_are_lctong_m_hqout`;
DROP TABLE IF EXISTS `pre_are_lctong_m_hqprofit`;

EOF;

runquery($sql);
$finish = TRUE; /*dism·taobao·com*/
?>