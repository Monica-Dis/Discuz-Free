<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once 'common.class.php';
require_once 'x_upload_module.php';
$lxlxlangs = commoncls::lxlxlangs();//print_r($lxlxlangs);
$plstatic = commoncls::$plsrc;

$file = str_replace('.inc.php', '', basename(__FILE__));
$burl = 'plugins&operation=config&do='.$pluginid.'&identifier='.$PLNAME.'&fh='.FORMHASH.'&pmod=';
$murl = $burl.$file;
$turl = ADMINSCRIPT.'?action='.$murl;
$table = 'are_lctong_m_hqinto';

if ($_GET['fh'] ==FORMHASH && $_GET['setoption'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setoption($table);
	exit($msg);
}elseif ($_GET['fh'] ==FORMHASH && $_GET['setstatus'] ==1) {
	ob_clean();
	$msg = C::t(commoncls::$table)->setstatus($table);
	exit($msg);
}elseif (isset($_GET['doaddsubmit']) && $_GET['formhash'] ==FORMHASH) {
	$addinfo = $_GET['dget'];
	foreach ($addinfo as $k => $v) {
		$addinfo[$k] = trim(strip_tags($v));//不能再addcslashes()，入库前dz已经addcslashes()
	}
	
	$opid = intval($_GET['opid']);
	$r = DB::fetch_first("SELECT * FROM ".DB::table($table)." WHERE id='$opid'");
	if ($r) {
		$addinfo['uptime'] = TIMESTAMP;
		DB::update($table, $addinfo, array('id'=>$opid));
	}else {
		$addinfo['addtime'] = TIMESTAMP;
		$opid = DB::insert($table, $addinfo, TRUE);
	}
	cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
}elseif (isset($_GET['dosubmit']) && $_GET['formhash'] ==FORMHASH) {
	$insql = commoncls::sqlwhere(dhtmlspecialchars($_GET['ids']));
	if ($insql) {
		DB::query("DELETE FROM ".DB::table($table)." WHERE `id` IN ({$insql})");
		cpmsg($lxlxlangs['succeed'], dreferer(), 'succeed');
	}
}

$js = <<<EOF
	
	<link rel="stylesheet" href="{$plstatic}css/css.css" type="text/css">
	<script type="text/javascript" src="{$plstatic}dialog417/dialog.js?skin=default"></script>
	<script type="text/javascript" src="{$plstatic}dialog417/plugins/iframeTools.js"></script>
	<script type="text/javascript" src="{$plstatic}jquery.min.js"></script>
	<script type="text/javascript" src="static/js/common.js?WT2"></script>
	<script type="text/javascript" src="static/js/calendar.js"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript">

function setstatus(obj, id, name) {
	//var name = name ? name : '';
	jQuery.get('{$turl}&setstatus=1&opid='+ id, {name:name, t:Math.random()}, function(data){
		switch(parseInt(data)) {
			case 1 :
				jQuery(obj).html('{$lxlxlangs['no']}');
				break;
			case 0 :
				jQuery(obj).html('{$lxlxlangs['yes']}');
				break;
		}
		art.dialog.tips('{$lxlxlangs['succeed']}');
	});
}

function setoption(obj, id, name, value) {
	jQuery.get('{$turl}&setoption=1&opid='+ id, {name:name, value:value, t:Math.random()}, function(data){
		art.dialog.tips('{$lxlxlangs['succeed']}'+ data);
		if (data =='102') window.location = window.location;
	});
}



function diy_code_form(formid) {
	art.dialog({id:'diy_code_form_id', title:'{$lxlxlangs['diycode']}', content:'&lt;iframe width="100%" height="0" frameborder="0" marginheight="0" '
	+'src="plugin.php?id=levform:form&amp;ifr=1&amp;fmid='+formid+'" scrolling="no"&gt;&lt;/iframe&gt;'});
}

function deladimg(gid, src, obj) {
	if (confirm('{$lxlxlangs['confirm']}')) {
		jQuery.get('{$remote}_deladimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery(obj).parent().fadeOut();
				art.dialog.tips('{$lxlxlangs['succeed']}');
			}else {
				art.dialog.tips(data);
			}
		});
	}
}

function del_imgs(gid, src, obj) {
	if (confirm('{$lxlxlangs['confirm']}')) {
		jQuery.get('{$remote}_delimg', {src:src,gid:gid}, function(data){
			if (parseInt(data) ==1) {
				jQuery('#oldadimgbox').fadeOut();
				art.dialog.tips('{$lxlxlangs['succeed']}');
			}else {
				art.dialog.tips(data);
				jQuery(obj).parent().fadeOut();
			}
		});
	}
}



</script>
EOF;
echo $js;

if (!$_GET['addtmp']) {
	
	$limit = 100;
	$where = " 1 ";
	$pgurl = $turl;
	$srhkeyxs = dstripslashes(strip_tags($_GET['srhkeys']));
	if ($srhkeyxs) {
		$where = "(uid LIKE '%{$srhkeyxs}%' OR username LIKE '%{$srhkeyxs}%') ";// OR id LIKE '%{$srhkeyxs}%'
		$pgurl = $turl.'&srhkeys='.$srhkeyxs;
	}
	$infos = commoncls::lxlxpages($table, $where.' ORDER BY id DESC', $limit, $pgurl);
	$lists = $infos['lists'];
	$pages = $infos['pages'];
	
	$_subtitle = array (
		'<a href="javascript:;"><label for="chkall">'.$lxlxlangs['slts'].'</label></a>',
		'ID',
		$lxlxlangs['madw1'],
		$lxlxlangs['madw2'],
		$lxlxlangs['madw3'],
		$lxlxlangs['madw4'],
	);
	showformheader($murl);
		$tithtm = <<<eof
	<table width=100%>  
<tr>
<td>{$lxlxlangs['mad6']} <b><font color=red>{$infos['total']}</font></b> {$lxlxlangs['mad7']} </td>
<td align=center></td>
<td align=right><form action="{$turl}" method="post" name="">
	<input type="text" name="srhkeys" placeholder="{$lxlxlangs['madw5']}" value="{$srhkeyxs}"/> 
	<input type="submit" name="dosubmit" value="{$lxlxlangs['mad9']}" class="btn" style="width:auto;vertical-align:top;margin:0;" />
	</form></td>
</tr>
</table>

eof;
	showtableheader($tithtm);
	showsubtitle($_subtitle);
	
	if ($lists) {
		foreach ($lists as $v) {
			showtablerow(
			'',
			array(
				'width=30',
				'width=40',
			),
			array (
				"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"{$v['id']}\">",
			$v['id'],
			'<span style="color:red;font-size:18px;">'.$v['uid'].'</span>',
			'<span style="color:red;font-size:18px;">'.$v['username'].'</span>',
			'<span style="color:#2ea7e0;font-size:18px;">'.$v['intomoney'].'</span>&nbsp;'.$lxlxlangs['scoretype'],
			dgmdate($v['addtime'], 'u'),
			
			));
		}
		showsubmit(
			'', 
			'', 
			'', 
			'<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" />
			<label for="chkall">'.$lxlxlangs['slts'].'</label>&nbsp;&nbsp;<input type="submit" class="btn" name="dosubmit" value="'.$lxlxlangs['del'].'" onclick="return confirm(\''.$lxlxlangs['confirm'].'\');"/>
			', 
		$pages);
	}else {
		showtablerow('', array('colspan='.count($_subtitle)), array($lxlxlangs['nodata']));
	}
	showtablefooter(); /*Dism·taobao·com*/
	showformfooter(); /*Dism_taobao_com*/
}


























