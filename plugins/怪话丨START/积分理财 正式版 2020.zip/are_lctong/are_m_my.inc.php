<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'common.class.php';
$lxlxlangs = commoncls::lxlxlangs();
global  $_G;

if ($_G['uid'] < 1) {
	showmessage($lxlxlangs['login'], '', array(), array('login' => TRUE));	
}

$plg = $_G['cache']['plugin']['are_lctong'];
$plstatic = 'source/plugin/are_lctong/statics/';

$mylc_sql =DB::fetch_all("SELECT * FROM ".DB::table('are_lctong_spend')." WHERE uid='{$_G['uid']}' ORDER BY xmday ASC");//获取所以用户购买项目


include template('are_lctong:are_m_my');

?>