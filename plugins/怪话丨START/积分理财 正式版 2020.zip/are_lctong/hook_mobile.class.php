<?php

/**		Author     : DisM!应用中心 dism.taobao.com $
 * 
 * 		Plugin name: are_lctong [理财通]
 * 
 * 		应用更新支持：https://dism.taobao.com
 * 
 * 		最新插件：http://t.cn/Aiux1Jx1
 * 
 *      Created by DisM. All rights reserved $Id$
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'hook.class.php';

new plugin_are_lctong();

class mobileplugin_are_lctong {//手机版脚本中的类名以 mobileplugin_ 开头。
    
    public static function global_footer_mobile() {
        $PLSTATIC = plugin_are_lctong::$PLSTATIC;
        $style = 'position: fixed;bottom: 55px;right: 25px;display: inline-block;';
        $hkhtm = '<a href="plugin.php?id=are_lctong:mobile" style="'.$style.'"><img src="'.$PLSTATIC.'img/url.png"></a>';
        return $hkhtm;
    }
    
}

class mobileplugin_are_lctong_forum extends mobileplugin_are_lctong {}
class mobileplugin_are_lctong_member extends mobileplugin_are_lctong {}







