<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("function/core", "plugin/addon_collect_toutiao/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	require_once libfile("function/forumlist");
	$_var_13 = array("list", "edit");
	$op = in_array($_GET["op"], $_var_13) ? $_GET["op"] : "list";
	$ac = '';
	$posttypelist = array("1" => "&#x8BBA;&#x575B;&#x5E16;&#x5B50;", "2" => "&#x95E8;&#x6237;&#x6587;&#x7AE0;", "3" => "&#x7FA4;&#x7EC4;&#x5E16;&#x5B50;");
	if ($_GET["update_spider_url"] && $_GET["_signature"]) {
		$_var_14 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_by_search(array("id" => $_GET["spiderid"]));
		if ($_var_14["url"]) {
			preg_match("/mid=([\\d]+)/is", $_var_14["url"], $_var_15);
			$_var_16 = explode("/user/", $_var_14["url"]);
			$_var_16 = explode("/", $_var_16[1]);
			$_var_17 = $_var_16[0];
			$_var_18 = $_var_15[1];
			if ($_var_17 && $_var_18) {
				C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update_by_where(array("id" => $_var_14["id"]), array("url" => "https://www.toutiao.com/c/user/" . $_var_17 . "/#mid=" . $_var_18 . "&_signature=" . $_GET["_signature"]), true);
			}
		}
		ajaxshowheader();
		ajaxshowfooter();
		return 0;
	}
	if ($op == "list") {
		if (!submitcheck("submit")) {
			showtips("\r\n\t\t    <li><b style=\"color:red\">&#x63D2;&#x4EF6;&#x4EC5;&#x4F9B;&#x6536;&#x96C6;&#x6587;&#x7AE0;&#xFF0C;&#x65B9;&#x4FBF;&#x81EA;&#x5DF1;&#x9605;&#x8BFB;&#xFF0C;&#x60A8;&#x9700;&#x8981;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x6587;&#x7AE0;&#x7248;&#x6743;&#x98CE;&#x9669;&#xFF0C;&#x672A;&#x83B7;&#x5F97;&#x539F;&#x6587;&#x4F5C;&#x8005;&#x6388;&#x6743;&#x7684;&#x60C5;&#x51B5;&#x4E0B;&#xFF0C;&#x8BF7;&#x52FF;&#x5C06;&#x6587;&#x7AE0;&#x516C;&#x5F00;&#x53D1;&#x5E03;&#x6216;&#x7528;&#x4E8E;&#x5546;&#x4E1A;&#x7528;&#x9014;&#x3002;</b></li>\r\n\t\t    <li>&#x53EA;&#x6709;&#x5173;&#x952E;&#x5B57;&#x3001;&#x540C;&#x6B65;&#x7C7B;&#x578B;&#x3001;&#x9891;&#x9053;&#x680F;&#x76EE;&#x90FD;&#x8BBE;&#x7F6E;&#x4E86;&#x624D;&#x53EF;&#x4EE5;&#x542F;&#x7528;&#x722C;&#x866B;&#xFF0C;&#x8BBE;&#x7F6E;&#x9519;&#x8BEF;&#x6216;&#x65E0;&#x6CD5;&#x91C7;&#x96C6;&#x7684;&#x7F51;&#x7AD9;&#x5728;&#x6267;&#x884C;&#x91C7;&#x96C6;&#x65F6;&#x4F1A;&#x81EA;&#x52A8;&#x5173;&#x95ED;&#x722C;&#x866B;</li>\r\n\t\t    <li>&#x91C7;&#x96C6;&#x9875;&#x6570;&#x8BBE;&#x7F6E;&#x53EA;&#x5BF9;&#x722C;&#x866B;&#x53F3;&#x4FA7;&#x7684;&#x4E00;&#x952E;&#x91C7;&#x96C6;&#x6709;&#x6548;&#xFF0C;&#x81EA;&#x52A8;&#x91C7;&#x96C6;&#x53EA;&#x91C7;&#x96C6;&#x6700;&#x65B0;&#x7684;&#x4E00;&#x9875;&#xFF0C;&#x8BF7;&#x52FF;&#x77ED;&#x65F6;&#x95F4;&#x9891;&#x7E41;&#x624B;&#x52A8;&#x91C7;&#x96C6;&#x548C;&#x53D1;&#x5E03;&#xFF0C;&#x4EE5;&#x514D;&#x89E6;&#x53D1;&#x9632;&#x91C7;&#x96C6;&#x88AB;&#x5C4F;&#x853D;&#x3002;</li>\r\n\t\t    <li>&#x5982;&#x679C;&#x4F7F;&#x7528;&#x5934;&#x6761;&#x53F7;&#x91C7;&#x96C6;&#xFF0C;&#x94FE;&#x63A5;&#x683C;&#x5F0F;&#x4E3A;&#xFF1A;https://www.toutiao.com/c/user/56750760167/#mid=1560560318418945&#xFF0C;&#x6DFB;&#x52A0;&#x540E;&#x70B9;&#x51FB;&#x53F3;&#x4FA7;&#x4E00;&#x952E;&#x91C7;&#x96C6;</li>\r\n\t\t    ", "tips", true, "&#x6280;&#x5DE7;&#x63D0;&#x793A; - " . dgmdate($_G["timestamp"], "Y-m-d H:i:s", $_G["setting"]["timeoffset"]));
			s_shownav("sort", "sorts_admin");
			showtableheader("&#x722C;&#x866B;&#x7BA1;&#x7406;");
			showtablefooter();
			$_GET["f_kw"] = trim($_GET["f_kw"]);
			if ($_GET["formhash"] != $_G["formhash"]) {
				$_GET["f_kw"] = '';
			}
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			echo "&nbsp;&nbsp;&#x722C;&#x866B;&#x641C;&#x7D20;&nbsp;&nbsp;<input type=\"text\" name=\"f_kw\" value=\"" . dhtmlspecialchars($_GET["f_kw"]) . "\" class=\"px vm\" autocomplete=\"off\" placeholder=\"&#x8BF7;&#x8F93;&#x5165;&#x722C;&#x866B;&#x540D;&#x79F0;\">&nbsp;&nbsp;\r\n\t\t\t\t<button type=\"submit\" class=\"pn\" name=\"search\" id=\"submit_search\" value=\"true\"><span class=\"xi1 xw1\">&#x641C;&#x7D22;</span></button>\r\n\t\t    &nbsp;&nbsp;\r\n\t\t    <script type=\"text/JavaScript\">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'search'); });</script>\r\n\t\t    ";
			showtablefooter();
			showformfooter();
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "class=\"spiderform\"", "spiderform");
			showtableheader('');
			$portalcategory = array();
			loadcache("portalcategory");
			$portalcategory = $_G["cache"]["portalcategory"];
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x722C;&#x866B;&#x540D;&#x79F0;", "&#x6293;&#x53D6;&#x5173;&#x952E;&#x5B57;/&#x5934;&#x6761;&#x53F7;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x540C;&#x6B65;&#x7C7B;&#x578B;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x9891;&#x9053;&#x680F;&#x76EE;/&#x677F;&#x5757;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x91C7;&#x96C6;&#x9875;&#x6570;<b style=\"color:red\">&#xFF08;1-5&#xFF09;</b>", '', "&#x6587;&#x7AE0;&#x6570;&#x91CF;", "&#x6700;&#x540E;&#x91C7;&#x96C6;&#x65F6;&#x95F4;", "&#x72B6;&#x6001;", '', '', ''));
			$_var_22 = array();
			if ($_GET["f_kw"]) {
				$_GET["f_kw"] = addslashes($_GET["f_kw"]);
				$_var_22["name"] = array("%" . addcslashes($_GET["f_kw"], "%_") . "%", "like");
			}
			$_var_23 = 30;
			$_var_24 = 100;
			$_var_25 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->count_by_where($_var_22);
			$_var_26 = $_G["page"] - 1 > $_var_25 / $_var_23 || $_G["page"] > $_var_24 ? 1 : $_G["page"];
			$_var_27 = ($_var_26 - 1) * $_var_23;
			$_var_28 = multi($_var_25, $_var_23, $_var_26, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . ($_GET["f_kw"] ? "&formhash=" . $_G["formhash"] . "&search=ok&f_kw=" . urlencode($_GET["f_kw"]) : ''), $_var_24);
			echo "<script src=\"source/plugin/addon_collect_toutiao/images/acrawler.js\"></script>";
			$_var_29 = '';
			$_var_30 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_all_by_search($_var_22, array("displayorder" => "ASC", "id" => "DESC"), $_var_27, $_var_23);
			foreach ($_var_30 as $_var_14) {
				$_var_31 = 1;
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td28\"", "class=\"td28\"", "class=\"td28\"", "class=\"td28\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:60px;\"", " style=\"width:100px;\"", " style=\"width:30px;\"", " style=\"width:60px;\"", " style=\"width:60px;\"", ''), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_14["id"] . "\" " . $_var_32 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_14["id"] . "]\" value=\"" . $_var_14["displayorder"] . "\" style=\"height: 20px;\">", "<input type=\"text\" name=\"name[" . $_var_14["id"] . "]\" value=\"" . $_var_14["name"] . "\" class=\"txt\" style=\"width: 120px;height: 20px;\">", "<input type=\"text\" name=\"url[" . $_var_14["id"] . "]\" value=\"" . $_var_14["url"] . "\" id=\"spider_url_" . $_var_14["id"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", addon_collect_toutiao_posttypeselect($posttypelist, $_var_14["posttype"], $_var_14["id"]), addon_collect_toutiao_catidselect($portalcategory, $_var_14["catid"], $_var_14["id"], 0, $_var_14["posttype"]), "<input type=\"text\" class=\"txt\" name=\"page[" . $_var_14["id"] . "]\" value=\"" . $_var_14["page"] . "\" style=\"height: 20px;\">", "<div style=\"width:100px;\"><a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&spiderid=" . $_var_14["id"] . "\" class=\"act\">&#x66F4;&#x591A;&#x8BBE;&#x7F6E;</a></div>", "<div style=\"width:100px;\">" . $_var_14["count"] . "</div>", "<div style=\"width:80px;\">" . ($_var_14["updatetime"] ? dgmdate($_var_14["updatetime"], "Y-m-d", $_G["setting"]["timeoffset"]) : "&#x672A;&#x91C7;&#x96C6;") . "</div>", "<div style=\"width:30px;\"><input name=\"status[" . $_var_14["id"] . "]\" type=\"checkbox\" value=\"1\" " . ($_var_14["status"] ? "checked=\"checked=\"" : '') . "/></div>", "<div style=\"width:60px;\">" . ($_var_14["status"] ? "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=" . dhtmlspecialchars($_GET["identifier"]) . "&pmod=admin_set&type1314=collect&formhash=" . $_G["formhash"] . "&onlyspiderid=" . $_var_14["id"] . "&page=1\" class=\"act\">&#x4E00;&#x952E;&#x91C7;&#x96C6;</a>" : "<-&#x5148;&#x542F;&#x7528;") . "</div>", "<div style=\"width:60px;\">" . ($_var_14["status"] ? "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=" . dhtmlspecialchars($_GET["identifier"]) . "&pmod=admin_article&type1314=list&op=wait&formhash=" . $_G["formhash"] . "&search=ok&spiderid=" . $_var_14["id"] . "\" class=\"act\">&#x4E00;&#x952E;&#x53D1;&#x5E03;</a>" : '') . "</div>", ''));
				if (strpos($_var_14["url"], "/user/")) {
					preg_match("/mid=([\\d]+)/is", $_var_14["url"], $_var_15);
					$_var_16 = explode("/user/", $_var_14["url"]);
					$_var_16 = explode("/", $_var_16[1]);
					$_var_17 = $_var_16[0];
					$_var_18 = $_var_15[1];
					$_var_29 = $_var_29 . ("<script type=\"text/JavaScript\">\r\n\t\t\t\te = 'https://profile.zjurl.cn/api/feed_backflow/profile_share/v1/?category=profile_article&visited_uid=" . $_var_17 . "&stream_api_version=82&request_source=1&offset=0&user_id=" . $_var_17 . "&media_id=" . $_var_18 . "';\r\n\t\t\t\tvar o = {\r\n\t\t\t\t    url: e\r\n\t\t\t\t};\r\n\t\t\t\tsignature = window.byted_acrawler.sign(o);\r\n\t\t\t\tif(signature){\r\n\t\t\t\t\t\$('spider_url_" . $_var_14["id"] . "').value = 'https://www.toutiao.com/c/user/" . $_var_17 . "/#mid=" . $_var_18 . "&_signature=' + signature;\r\n\t\t\t\t\tajaxget('" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "&formhash=" . $_G["formhash"] . "&update_spider_url=ok&spiderid=" . $_var_14["id"] . "&_signature=' + signature);\r\n\t\t\t\t}\r\n\t\t\t\t</script>");
				}
			}
			require_once libfile("include/sort", "plugin/addon_collect_toutiao/source");
			showsubmit("submit", "submit", "del", '', $_var_28, false);
			showtablefooter();
			showformfooter();
			echo $_var_29;
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_33) {
					$_var_33 = intval($_var_33);
					C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->delete_by_where(array("id" => $_var_33), true);
					C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->delete_by_where(array("spiderid" => $_var_33), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_33 => $_var_34) {
					$_var_35 = array("url" => $_POST["url"][$_var_33], "catid" => $_POST["catid"][$_var_33], "page" => max($_POST["page"][$_var_33], 1), "status" => $_POST["status"][$_var_33] ? 1 : 0, "displayorder" => $_POST["order"][$_var_33]);
					$_var_35["posttype"] = min(max($_POST["posttype"][$_var_33], 0), 3);
					if (!empty($_POST["name"][$_var_33])) {
						$_var_35["name"] = $_POST["name"][$_var_33];
					}
					if (empty($_var_35["url"]) || empty($_var_35["catid"]) || empty($_var_35["posttype"])) {
						$_var_35["status"] = 0;
					}
					$_var_14 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_by_search(array("id" => $_var_33));
					if ($_var_35["catid"] != $_var_14["catid"]) {
						$_var_35["typeid"] = 0;
					}
					C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update($_var_33, $_var_35);
				}
			}
			if (is_array($_GET["newname"])) {
				foreach ($_GET["newname"] as $_var_33 => $_var_36) {
					if (empty($_var_36)) {
						$_var_36 = strpos($_POST["newurl"][$_var_33], "http") === false ? $_POST["newurl"][$_var_33] : random(10);
					}
					$_var_35 = array("name" => $_var_36, "url" => $_POST["newurl"][$_var_33], "catid" => $_POST["newcatid"][$_var_33], "page" => min(max($_POST["newpage"][$_var_33], 1), 5), "status" => 1, "creattime" => $_G["timestamp"], "displayorder" => $_GET["neworder"][$_var_33]);
					$_var_35["posttype"] = min(max($_POST["newposttype"][$_var_33], 0), 3);
					if (empty($_var_35["url"]) || empty($_var_35["catid"]) || empty($_var_35["posttype"])) {
						$_var_35["status"] = 0;
					}
					C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->insert($_var_35, 1);
				}
			}
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	} else {
		if ($op == "edit") {
			require_once libfile("include/spider", "plugin/addon_collect_toutiao/source");
		}
	}