<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("class/rule", "plugin/addon_collect_toutiao/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	echo "<style type=\"text/css\">\r\n\t\t\t\t.ss em{display:block;float:left;margin-right:3px;padding-left:2px;width:15px;line-height:20px;background:#EEE;cursor:pointer;}\r\n\t\t\t\t.ss em.a{background:#09F;color:#FFF;}\r\n\t\t\t\t.board{ padding-left:35px;}\r\n\t\t\t\t.td33{ width:25px; }\r\n\t\t\t\t.td33 .txt{ width:15px; }\r\n\t\t\t\t.td_k{ width:90px; }\r\n\t\t\t\t.td_k .txt{ width:80px; }\r\n\t\t\t\t.td_l{ width:250px; }\r\n\t\t\t\t.td_l .txt{ width:190px; }\r\n#s, .userInt {border-radius: 0;background: url(source/plugin/addon_collect_toutiao/images/soso_bg.png) no-repeat;}\r\n#s {position: relative;background-position: -89px 0px;height: 36px;padding-left: 3px;margin-top:25px;margin-bottom:25px;width:500px;margin-left: auto;margin-right: auto;}\r\n#s_input {width: 402px;border: 0 none;float: left;font: 16px Arial;height: 18px;outline: 0 none;margin-top: 3px;padding: 7px 5px 5px;}\r\n#s_button {width: 85px;height: 36px;background: none;border: 0 none;float: left;text-indent: -9999px;cursor: pointer;}\r\n.s_icn {padding-left: 5px;width: 38px;text-align: left;}\r\n\r\n\t\t\t</style>\r\n\t\t\t<div id=\"my_addonlist\"></div><div id=\"s\">\r\n    <form id=\"search_soft\" method=\"post\" autocomplete=\"off\" action=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "\">\r\n    \t<input type=\"hidden\" name=\"formhash\" value=\"" . $_G["formhash"] . "\">\r\n    \t<input type=\"text\" name=\"keyword\" id=\"s_input\" value=\"" . ($_GET["keyword"] ? dhtmlspecialchars($_GET["keyword"]) : "&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;") . "\" onclick=\"if(this.value=='&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;'){this.value='';}\" onblur=\"if(this.value==''){this.value='&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;';}\" autocomplete=\"off\" required=\"\" placeholder=\"\" x-webkit-speech=\"\" speech=\"\">\r\n        <input type=\"submit\" id=\"s_button\">\r\n    </form>\r\n    <div id=\"smart_pop\" style=\"display: none; \"></div>\r\n</div>";
	s_shownav("sort", "sorts_admin");
	showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "class=\"spiderform\"", "spiderform");
	showtableheader('');
	if (!empty($_GET["keyword"])) {
		$_var_11 = "https://www.toutiao.com/api/search/content/?aid=24&app_name=web_search&offset=0&format=json&keyword=" . rawurlencode(addon_collect_toutiao_iconv($_GET["keyword"], CHARSET, "UTF-8")) . "&autoload=true&count=20&&en_qc=1&cur_tab=4&from=media&pd=user&timestamp=" . time() . "974";
		$_var_12 = addon_collect_toutiao_rule_getcontent($_var_11);
		$_var_13 = json_decode($_var_12, true);
	}
	if (isset($_var_13["data"]) && !empty($_var_13["data"])) {
		showsubtitle(array('', "&#x5934;&#x6761;&#x53F7;&#x540D;&#x79F0;", "&#x4ECB;&#x7ECD;"));
		foreach ($_var_13["data"] as $_var_14 => $_var_15) {
			showtablerow('', array(" style=\"width:40px;\"", " style=\"width:150px;\"", ''), array($_var_15["is_pgc"] ? "<img src=\"source/plugin/addon_collect_toutiao/images/pgc.jpg\">" : '', "<a href=\"" . dhtmlspecialchars($_var_15["source_url"]) . "\" target=\"_blank\">" . dhtmlspecialchars(addon_collect_toutiao_iconv($_var_15["name"], "UTF-8", CHARSET)) . "</a>", dhtmlspecialchars(addon_collect_toutiao_iconv($_var_15["description"] ? $_var_15["description"] : $_var_15["verify_content"], "UTF-8", CHARSET))));
		}
		if (count($_var_13["data"]) == 20) {
			$_var_11 = "https://www.toutiao.com/search_content/?offset=20&format=json&keyword=" . rawurlencode(addon_collect_toutiao_iconv($_GET["keyword"], CHARSET, "UTF-8")) . "&autoload=true&count=20&cur_tab=4&from=media";
			$_var_12 = addon_collect_toutiao_rule_getcontent($_var_11);
			$_var_13 = json_decode($_var_12, true);
			foreach ($_var_13["data"] as $_var_14 => $_var_15) {
				showtablerow('', array(" style=\"width:40px;\"", " style=\"width:150px;\"", ''), array($_var_15["is_pgc"] ? "<img src=\"source/plugin/addon_collect_toutiao/images/pgc.jpg\">" : '', "<a href=\"" . dhtmlspecialchars($_var_15["source_url"]) . "\" target=\"_blank\">" . dhtmlspecialchars(addon_collect_toutiao_iconv($_var_15["name"], "UTF-8", CHARSET)) . "</a>", dhtmlspecialchars(addon_collect_toutiao_iconv($_var_15["description"] ? $_var_15["description"] : $_var_15["verify_content"], "UTF-8", CHARSET))));
			}
		}
	}