<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("class/rule", "plugin/addon_collect_toutiao/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	require_once libfile("function/forumlist");
	$portalcategory = array();
	loadcache("portalcategory");
	$portalcategory = $_G["cache"]["portalcategory"];
	$posttypelist = array("1" => "&#x8BBA;&#x575B;&#x5E16;&#x5B50;", "2" => "&#x95E8;&#x6237;&#x6587;&#x7AE0;", "3" => "&#x7FA4;&#x7EC4;&#x5E16;&#x5B50;");
	$_var_13 = array("study_post_uids", "study_reply_radio", "study_reply_uids", "downremoteimg_radio", "cover_minheight", "cover_minbytes", "study_filter_mao", "gb2312tobig5_radio", "wyc_radio", "from_radio", "from_format", "rand_view", "rand_posttime", "rand_replytime", "ban_samename");
	if (!submitcheck("submit")) {
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314);
		showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
		s_showsetting("&#x6587;&#x7AE0;URL<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "url", '', "text", '', '', "&#x5982;&#xFF1A;https://www.toutiao.com/a6409273516507529730/");
		echo "\r\n\t<tr><td colspan=\"2\" class=\"td27\" s=\"1\">&#x540C;&#x6B65;&#x7C7B;&#x578B;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>:</td></tr>\r\n\t<tr class=\"noborder\" onmouseover=\"setfaq(this, 'faq7de0')\"><td class=\"vtop rowform\">" . addon_collect_toutiao_posttypeselect($posttypelist, '', "1314") . "</td><td class=\"vtop tips2\" s=\"1\"></td></tr>\r\n\t<tr><td colspan=\"2\" class=\"td27\" s=\"1\">&#x9891;&#x9053;&#x680F;&#x76EE;/&#x677F;&#x5757;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>:</td></tr>\r\n\t<tr class=\"noborder\" onmouseover=\"setfaq(this, 'faqe862')\"><td class=\"vtop rowform\">" . addon_collect_toutiao_catidselect($portalcategory, '', "1314", 0, '') . "</td><td class=\"vtop tips2\" s=\"1\"></td></tr>\r\n\t\r\n\t<tr id=\"threadtypes_title\"><td colspan=\"2\" class=\"td27\" s=\"1\">&#x677F;&#x5757;&#x4E3B;&#x9898;&#x5206;&#x7C7B;:</td></tr>\r\n  <tr id=\"threadtypes_input\" class=\"noborder\">\r\n    <td class=\"vtop rowform\" id=\"threadtypes\">\r\n      <select name=\"threadtypeid\">\r\n        <option value=\"0\"></option>\r\n      </select>\r\n     </td>\r\n    <td class=\"vtop tips2\" s=\"1\">&#x4EC5;&#x9650;&#x53D1;&#x5E03;&#x5230;&#x8BBA;&#x575B;&#x7248;&#x5757;&#xFF0C;&#x4E14;&#x7248;&#x5757;&#x6709;&#x5206;&#x7C7B;</td>\r\n  </tr>\r\n\t";
		$pluginvars = array();
		foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_14) {
			if (!strexists($_var_14["type"], "_")) {
				C::t("common_pluginvar")->update_by_variable($pluginid, $_var_14["variable"], array("type" => $_var_14["type"] . "_1314"));
			} else {
				$_var_15 = explode("_", $_var_14["type"]);
				if ($_var_15[1] == "1314") {
					$_var_14["type"] = $_var_15[0];
				} else {
					continue;
				}
			}
			$pluginvars[$_var_14["variable"]] = $_var_14;
		}
		$_var_16 = s_showsettings($pluginvars, $_var_13);
		echo implode('', $_var_16);
		showtableheader();
		showsubmit("submit", "submit");
		showformfooter();
		echo "\r\n<script type=\"text/JavaScript\">\r\nsortsupcat = new Array();";
		echo "sortsupcat[1] = new Array(1314);";
		$_var_17 = 1;
		echo "sortsupcat[2] = new Array();";
		echo "sortsupcat[2][0] = new Array(\"" . $splugin_lang["slang_001"] . "\", \"0\");";
		foreach ($portalcategory as $_var_18 => $_var_19) {
			echo "sortsupcat[2][" . $_var_17 . "] = new Array(\"" . $_var_19["catname"] . "\", \"" . $_var_19["catid"] . "\");";
			$_var_17 = $_var_17 + 1;
		}
		echo "sortsupcat[3] = new Array(1314);";
		echo "addFormEvent('sale_form', 0);\r\nfunction onSortGroupChange(sortgroup, formid){\r\n\tvar locationid = sortgroup.value;\r\n\tvar suplist = sortsupcat[locationid];\r\n\t\r\n\tif(suplist){\r\n\t\t\$('sortsup_' + formid).style.display = \"\";\r\n\t\tif(locationid == 1){\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).outerHTML = '<select class=\"catid\" onchange=\"if(\$(\\'sortgroup_1314\\').value == 1){\$(\\'threadtypes_title\\').style.display = \\'\\';\$(\\'threadtypes_input\\').style.display = \\'\\';ajaxget(\\'forum.php?mod=ajax&action=getthreadtypes&fid=\\' + this.value, \\'threadtypes\\');} else {\$(\\'threadtypes_title\\').style.display = \\'none\\';\$(\\'threadtypes_input\\').style.display = \\'none\\';}\" name=\"'+\$('sortsup_' + formid).getAttribute(\"name\")+'\" id=\"sortsup_'+formid+'\"><option value=\"\">" . $splugin_lang["slang_002"] . "</option>" . str_replace("'", '', forumselect(false, 0, 0, true)) . "</select>';\r\n\t\t}else if(locationid == 2){\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).length = suplist.length; \r\n\t\t\tvar i = 0;\r\n\t\t\tfor (supid in suplist){\r\n\t\t\t\t\$('sortsup_' + formid).options[i] = new Option(suplist[supid][0], suplist[supid][1]);\r\n\t\t\t\ti++;\r\n\t\t\t}\r\n\t\t}else{\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).outerHTML = '<select class=\"catid\" name=\"'+\$('sortsup_' + formid).getAttribute(\"name\")+'\" id=\"sortsup_'+formid+'\"><option value=\"\">" . $splugin_lang["slang_017"] . "</option>" . str_replace("'", '', addon_collect_toutiao_groupselect(0)) . "</select>';\r\n\t\t}\r\n\t}else{\r\n\t\t\$('sortsup_' + formid).style.display = \"none\";\r\n\t\t\$('sortsup_' + formid).value = \"\";\r\n\t}\r\n}\r\n</script>";
	} else {
		if (empty($_GET["url"])) {
			cpmsg_error("&#x8BF7;&#x586B;&#x5199;&#x91C7;&#x96C6;&#x7684;&#x6587;&#x7AE0;URL");
		}
		$_var_20 = intval($_GET["posttype"]["1314"]);
		if (empty($_var_20)) {
			cpmsg_error("&#x8BF7;&#x9009;&#x62E9;&#x540C;&#x6B65;&#x7C7B;&#x578B;");
		}
		$_var_21 = intval($_GET["catid"]["1314"]);
		if (empty($_var_21)) {
			cpmsg_error("&#x8BF7;&#x9009;&#x62E9;&#x9891;&#x9053;&#x680F;&#x76EE;/&#x677F;&#x5757;");
		}
		preg_match("#/a([\\d]+)/?\$#is", $_GET["url"], $_var_22);
		if (!empty($_var_22[1])) {
			$_var_23 = $_var_22[1];
		} else {
			preg_match("#/i([\\d]+)/?\$#is", $_GET["url"], $_var_22);
			if (!empty($_var_22[1])) {
				$_var_23 = "i" . $_var_22[1];
			} else {
				cpmsg_error("&#x6587;&#x7AE0;URL&#x683C;&#x5F0F;&#x9519;&#x8BEF;");
			}
		}
		$_var_24 = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->fetch_by_search(array("group_id" => $_var_23), array("id" => "DESC"));
		if ($_var_24["status"] == 1) {
			cpmsg_error("&#x8BE5;&#x6587;&#x7AE0;&#x5DF2;&#x53D1;&#x5E03;&#x8FC7;");
		}
		foreach ($_var_13 as $_var_25) {
			if (isset($_GET["varsnew"][$_var_25])) {
				$_G["cache"]["plugin"]["addon_collect_toutiao"][$_var_25] = $_GET["varsnew"][$_var_25];
			}
		}
		$_var_26 = array("posttype" => $_var_20, "catid" => $_var_21, "typeid" => $_GET["threadtypeid"], "configs_arr" => array());
		if (isset($_var_24["id"])) {
			$_var_24["configs"] = array();
			$_var_24["posttype"] = $_var_26["posttype"];
			$_var_27 = new addon_collect_toutiao_rule();
			$_var_28 = $_var_27->spider($_var_24);
			if ($_var_28["censor"]) {
				C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_24["id"]), array("status" => -1, "errlog" => "&#x542B;&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;", "updatetime" => $_G["timestamp"]), true);
			} else {
				if (empty($_var_28["subject"])) {
					C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_24["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x540D;&#x79F0;", "updatetime" => $_G["timestamp"]), true);
				} else {
					if (empty($_var_28["message"])) {
						if ($splugin_setting["optimize_fcj"] && $_var_28["fcj"]) {
							C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_24["id"]), array("status" => 0, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;"), true);
							cpmsg_error("&#x60A8;&#x7684;&#x670D;&#x52A1;&#x5668;&#x76EE;&#x524D;&#x65E0;&#x6CD5;&#x6B63;&#x5E38;&#x8BBF;&#x95EE;&#x5934;&#x6761;&#x6587;&#x7AE0;&#x9875;&#xFF0C;&#x8BF7;&#x7A0D;&#x540E;&#x518D;&#x8BD5;");
						} else {
							if ($_var_28["404"]) {
								C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_24["id"]), array("status" => -1, "errlog" => "404", "updatetime" => $_G["timestamp"]), true);
							} else {
								C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_24["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;", "updatetime" => $_G["timestamp"]), true);
							}
						}
					} else {
						$_var_29 = array("url" => $_var_28["url"], "subject" => $_var_28["subject"], "message" => $_var_28["message"], "comments" => $_var_28["comments"], "updatetime" => $_G["timestamp"]);
						$_var_30 = addon_collect_toutiao_rule_getuser("post", $_var_24);
						$_var_29["articleid"] = $_var_24["id"];
						$_var_29["uid"] = $_var_30["uid"];
						$_var_29["username"] = $_var_30["username"];
						$_var_29["posttype"] = $_var_26["posttype"];
						$_var_29["catid"] = $_var_26["catid"];
						$_var_29["typeid"] = $_var_26["typeid"];
						$_var_29["configs"] = $_var_26["configs_arr"];
						$_var_27->post($_var_29);
					}
				}
			}
		} else {
			if (strpos($_var_23, "i") !== false) {
				$_var_24 = array("url" => "https://www.toutiao.com/" . $_var_23 . "/", "group_id" => $_var_23);
			} else {
				$_var_24 = array("url" => "https://www.toutiao.com/a" . $_var_23 . "/", "group_id" => $_var_23);
			}
			$_var_24["configs"] = array();
			$_var_24["posttype"] = $_var_26["posttype"];
			$_var_27 = new addon_collect_toutiao_rule();
			$_var_28 = $_var_27->spider($_var_24);
			if ($_var_28["censor"]) {
				cpmsg("&#x6587;&#x7AE0;&#x5185;&#x5BB9;&#x542B;&#x5C4F;&#x853D;&#x7684;&#x5173;&#x952E;&#x5B57;");
			} else {
				if (empty($_var_28["subject"])) {
					cpmsg("&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x6587;&#x7AE0;&#x6807;&#x9898;");
				} else {
					if (empty($_var_28["message"])) {
						if ($_var_28["404"]) {
							cpmsg("&#x539F;&#x6587;&#x5DF2;&#x88AB;&#x5220;&#x9664;&#xFF0C;&#x8FD4;&#x56DE;404");
						} else {
							cpmsg("&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x6587;&#x7AE0;&#x5185;&#x5BB9;&#x6216;&#x89E6;&#x53D1;&#x9632;&#x91C7;&#x96C6;");
						}
					} else {
						$_var_31 = array("spiderid" => 0, "url" => $_var_28["url"], "sha1" => sha1($_var_28["url"]), "subject" => $_var_28["subject"], "message" => $_var_28["message"], "group_id" => $_var_28["group_id"], "creattime" => $_G["timestamp"], "updatetime" => $_G["timestamp"]);
						$_var_24["id"] = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->insert($_var_31, true);
						$_var_29 = array("url" => $_var_28["url"], "subject" => $_var_28["subject"], "message" => $_var_28["message"], "comments" => $_var_28["comments"], "updatetime" => $_G["timestamp"]);
						$_var_30 = addon_collect_toutiao_rule_getuser("post", $_var_24);
						$_var_29["articleid"] = $_var_24["id"];
						$_var_29["uid"] = $_var_30["uid"];
						$_var_29["username"] = $_var_30["username"];
						$_var_29["posttype"] = $_var_26["posttype"];
						$_var_29["catid"] = $_var_26["catid"];
						$_var_29["typeid"] = $_var_26["typeid"];
						$_var_29["configs"] = $_var_26["configs_arr"];
						$_var_27->post($_var_29);
					}
				}
			}
		}
		cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314, "succeed");
	}