<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_toutiao_rule_spider($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = $_var_4 = array();
	if (strpos($_arg_0["url"], "/dongtai/") !== false) {
		C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->delete_by_where(array("id" => $_arg_0["id"]), true);
		return -1;
	}
	$_arg_0["url"] = str_replace("www.toutiao.comhttp://lf.snssdk.com", "www.toutiao.com", $_arg_0["url"]);
	$_arg_0["url"] = str_replace("http://toutiao.com/", "http://www.toutiao.com/", $_arg_0["url"]);
	$_arg_0["url"] = str_replace("//toutiao.com/", "http://www.toutiao.com/", $_arg_0["url"]);
	$_arg_0["url"] = str_replace("/group/", "/a", $_arg_0["url"]);
	$_var_5 = str_replace("/item/", "/i", $_arg_0["url"]);
	$_var_5 = str_replace("http://", "https://", $_var_5);
	$_var_6 = false;
	if (preg_match("#/a([\\d]+)/#is", $_arg_0["url"], $_var_7)) {
		$_var_5 = "https://m.toutiao.com/group/" . $_var_7[1] . "/";
		$_var_8 = curl_init();
		$_var_9 = 10;
		curl_setopt($_var_8, CURLOPT_URL, $_var_5);
		curl_setopt($_var_8, CURLOPT_TIMEOUT, 30);
		curl_setopt($_var_8, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1");
		curl_setopt($_var_8, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($_var_8, CURLOPT_HEADER, 1);
		curl_setopt($_var_8, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($_var_8, CURLOPT_CONNECTTIMEOUT, $_var_9);
		$_var_10 = curl_exec($_var_8);
		curl_close($_var_8);
		if (preg_match("#/i([\\d]+)/#is", $_var_10, $_var_11)) {
			$_arg_0["group_id"] = "i" . $_var_11[1];
			$_arg_0["url"] = "https://www.toutiao.com/i" . $_var_11[1] . "/";
			$_var_5 = $_arg_0["url"];
			$_var_6 = true;
		}
	} else {
		$_var_6 = true;
	}
	$_arg_0["author"] = lang("plugin/addon_collect_toutiao", "slang_018");
	if ($_var_6) {
		$_var_5 = str_replace("www.toutiao.com", "m.toutiao.com", $_var_5);
		$_var_12 = addon_collect_toutiao_rule_getcontent($_var_5 . "info/");
		$_var_13 = json_decode($_var_12, true);
		$_var_4[1] = addon_collect_toutiao_iconv($_var_13["data"]["content"], $_arg_0["charset"], CHARSET);
		$_arg_0["author"] = addon_collect_toutiao_iconv($_var_13["data"]["source"], $_arg_0["charset"], CHARSET);
		if (empty($_arg_0["subject"]) && !empty($_var_13["data"]["title"])) {
			$_arg_0["subject"] = addon_collect_toutiao_iconv($_var_13["data"]["title"], $_arg_0["charset"], CHARSET);
		}
	} else {
		$_var_14 = addon_collect_toutiao_rule_getcontent($_var_5);
		if (strpos($_var_14, "'learning_toutiao_wap'") !== false || strpos($_var_14, "sdk/slardar.js") !== false && !preg_match("/gallery:/is", $_var_15)) {
			$_var_16 = "https://learning.snssdk.com/toutiao/v1/item_info/?item_id=" . $_arg_0["group_id"] . "&app_name=news_article";
			$_var_12 = addon_collect_toutiao_rule_getcontent($_var_16);
			$_var_13 = json_decode($_var_12, true);
			if (!empty($_var_13["data"]["item_info"]["item_base_info"]["detail"])) {
				$_var_14 = "<div class=\"article-content\"><div>" . $_var_13["data"]["item_info"]["item_base_info"]["detail"] . "</div></div>";
				$_var_14 = preg_replace("#<img src=\"{[^>]+\"dfic-imagehandler/([^\"]+)\"[^>]+}\">#is", "<img src=\"https://p3.pstatp.com/large/dfic-imagehandler/\\1\">", $_var_14);
				$_var_14 = preg_replace("#<img src=\"{[^>]+}\">#is", '', $_var_14);
				$_var_14 = str_replace("<p class=\"ql-align-justify\"><br></p>", '', $_var_14);
			}
			if (empty($_arg_0["subject"]) && !empty($_var_13["data"]["item_info"]["item_base_info"]["title"])) {
				$_arg_0["subject"] = $_var_13["data"]["item_info"]["item_base_info"]["title"];
			}
		}
		$_arg_0["fcj"] = false;
		if (empty($_var_14) || strpos($_var_14, "content: '',") !== false) {
			$_arg_0["fcj"] = true;
		}
		if ($_arg_0["debug"]) {
			$_arg_0["debug_content"] = $_var_14;
		}
		$_var_15 = $_var_14;
		$_var_14 = addon_collect_toutiao_iconv($_var_14, $_arg_0["charset"], CHARSET);
		$_var_14 = str_replace("&#x3D;", "=", $_var_14);
		$_var_14 = str_replace("\\&quot;", "&quot;", $_var_14);
		$_var_14 = str_replace("&quot;", "\"", $_var_14);
		$_var_14 = preg_replace("/\\\\u([0-9a-f]{3,4})/i", "&#x\\1;", $_var_14);
		$_var_14 = html_entity_decode($_var_14, NULL, "UTF-8");
		if ($_arg_0["debug"]) {
			$_arg_0["debug_content_charset"] = $_var_14;
		}
		if (empty($_arg_0["subject"])) {
			preg_match("/title: '\"(.*?)\"'/is", $_var_14, $_var_4);
			if (!isset($_var_4[1])) {
				preg_match("/<title>(.*?)<\\/title>/is", $_var_14, $_var_4);
			}
			$_arg_0["subject"] = $_var_4[1];
		}
		$_var_14 = str_replace("<p class=\"pgc-img-caption\"></p>", '', $_var_14);
		$_var_14 = preg_replace("/<div><div class=\"pgc-img\">(.*?)<\\/div><\\/div>/is", "<div class=\"pgc-img\">\\1</div>", $_var_14);
		$_var_14 = preg_replace("/<div class=\"pgc-img\">(.*?)<\\/div>/is", "<p>\\1</p>", $_var_14);
		preg_match("/<div class=\"article-content\"><div>(.*?)<\\/div><\\/div>/is", $_var_14, $_var_4);
		if (!isset($_var_4[1])) {
			preg_match("/<div class=\"article-content\">(.*?)<\\/div><\\/div>/is", $_var_14, $_var_4);
			if (!isset($_var_4[1])) {
				preg_match("/content: '\"(.*?)\"'/is", $_var_14, $_var_4);
				if (!isset($_var_4[1])) {
					preg_match("/<div class=\"article-content\">(.*?)<div class=\"y-box article-actions\">/is", $_var_14, $_var_4);
					if (!isset($_var_4[1])) {
						$_var_15 = str_replace("\\u80f\\", "\\u80fd\\", $_var_15);
						preg_match("/var gallery = {(.*?)};/is", $_var_15, $_var_17);
						if (empty($_var_17[1])) {
							preg_match("/gallery: {(.*?)]},/is", $_var_15, $_var_17);
							$_var_13 = json_decode("{" . $_var_17[1] . "]}", true);
							if (empty($_var_17[1])) {
								preg_match("/gallery: JSON\\.parse\\(\"{(.*?)}\"\\),/is", $_var_15, $_var_17);
								$_var_17[1] = stripslashes($_var_17[1]);
								$_var_17[1] = "{" . $_var_17[1] . "}";
								$_var_13 = json_decode($_var_17[1], true);
							}
						} else {
							$_var_13 = json_decode("{" . $_var_17[1] . "}", true);
						}
						if (is_array($_var_13["sub_images"])) {
							$_var_4[1] = '';
							foreach ($_var_13["sub_images"] as $_var_18 => $_var_19) {
								$_var_19["url"] = preg_match("/^https?:\\/\\//i", $_var_19["url"]) ? $_var_19["url"] : "http:" . $_var_19["url"];
								$_var_13["sub_abstracts"][$_var_18] = trim($_var_13["sub_abstracts"][$_var_18]);
								$_var_4[1] = $_var_4[1] . ("<p><img src=\"" . $_var_19["url"] . "\"/></p><br>" . (!empty($_var_13["sub_abstracts"][$_var_18]) ? "<p class=\"pgc-img-caption\">" . addon_collect_toutiao_iconv($_var_13["sub_abstracts"][$_var_18], $_arg_0["charset"], CHARSET) . "</p><br>" : ''));
							}
						}
					} else {
						$_var_4[1] = "<div class=\"article-content\">" . $_var_4[1];
					}
				} else {
					$_var_4[1] = htmlspecialchars_decode($_var_4[1]);
					$_var_4[1] = str_replace("<p class=\"image_title\"></p>", '', $_var_4[1]);
					$_var_4[1] = str_replace("<p class=\"image_desc\"></p>", '', $_var_4[1]);
					$_var_4[1] = preg_replace("/<div class=\"image_content\">(.*?)<\\/div>/is", "<p>\\1</p>", $_var_4[1]);
				}
			} else {
				$_var_4[1] = preg_replace("/\\<div class=\"mp-vote-box mp-vote-outer\".*?\\<\\/div\\>\\<\\/p\\>/s", "</p>", $_var_4[1]);
			}
		}
		preg_match("/mediaInfo: {(.*?)},/is", $_var_14, $_var_20);
		if ($_var_20[1]) {
			preg_match("/name: '([^']*)',/is", $_var_20[1], $_var_17);
			if ($_var_17[1]) {
				$_arg_0["author"] = $_var_17[1];
			}
		}
	}
	if (isset($_var_4[1])) {
		$_arg_0["message"] = addon_collect_toutiao_msgformatting($_var_4[1]);
	}
	$_var_21 = explode("|", $_G["cache"]["plugin"]["addon_collect_toutiao"]["notcollect_authors"]);
	if (!empty($_var_21) && in_array($_arg_0["author"], $_var_21)) {
		$_arg_0["censor"] = true;
		return $_arg_0;
	}
	$_arg_0["comments"] = array();
	if (!empty($_arg_0["message"])) {
		if (isset($_arg_0["configs"]["censor"]) && !empty($_arg_0["configs"]["censor"])) {
			$_var_22 = "/(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_arg_0["configs"]["censor"] = trim($_arg_0["configs"]["censor"]), "/")) . ")/i";
			if ($_arg_0["configs"]["censor"] && @preg_match($_var_22, strip_tags($_arg_0["author"] . $_arg_0["subject"] . $_arg_0["message"]))) {
				$_arg_0["censor"] = true;
				return $_arg_0;
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["gb2312tobig5_radio"]) {
			if ($_arg_0["debug"]) {
				$_arg_0["debug_message_big5"] = $_arg_0["message"];
			}
			$_arg_0["message"] = addon_collect_toutiao_rule_gb2312tobig5($_arg_0["message"]);
		}
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["wyc_radio"]) {
			$_arg_0["subject"] = addon_collect_toutiao_rule_wyc($_arg_0["subject"]);
			$_arg_0["message"] = addon_collect_toutiao_rule_wyc($_arg_0["message"]);
			if ($_arg_0["debug"]) {
				$_arg_0["debug_message_wyc"] = $_arg_0["message"];
			}
		}
		$_arg_0["chineseTag"] = lang("plugin/addon_collect_toutiao", "slang_019");
		preg_match("/ga_event=\"click_channel\">([^<]*)<\\/a>/is", $_var_14, $_var_17);
		if ($_var_17[1]) {
			$_arg_0["chineseTag"] = $_var_17[1];
		} else {
			preg_match("/chineseTag: '([^']*)',/is", $_var_14, $_var_17);
			if ($_var_17[1]) {
				$_arg_0["chineseTag"] = $_var_17[1];
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["from_head_radio"]) {
			$_arg_0["message"] = ($_G["cache"]["plugin"]["addon_collect_toutiao"]["from_head_format"] ? str_replace(array("{url}", "{author}", "{chineseTag}"), array($_var_5, $_arg_0["author"], $_arg_0["chineseTag"]), $_G["cache"]["plugin"]["addon_collect_toutiao"]["from_head_format"]) . "<br>" : '') . $_arg_0["message"];
		}
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["from_radio"]) {
			$_arg_0["message"] = $_arg_0["message"] . ($_G["cache"]["plugin"]["addon_collect_toutiao"]["from_format"] ? "<br>" . str_replace(array("{url}", "{author}", "{chineseTag}"), array($_var_5, $_arg_0["author"], $_arg_0["chineseTag"]), $_G["cache"]["plugin"]["addon_collect_toutiao"]["from_format"]) : '');
		}
		$_arg_0["message"] = str_replace("src=\"//", "src=\"http://", $_arg_0["message"]);
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["study_reply_radio"]) {
			preg_match("/groupId: '([\\d]+)'/is", $_var_14, $_var_23);
			preg_match("/itemId: '([\\d]+)'/is", $_var_14, $_var_24);
			if (empty($_var_23[1])) {
				preg_match("/group_id:\\s'([\\d]+)'/is", $_var_14, $_var_23);
			}
			if (empty($_var_24[1])) {
				preg_match("/item_id:\\s'([\\d]+)'/is", $_var_14, $_var_24);
			}
			if (empty($_var_23[1]) || empty($_var_24[1])) {
				if (preg_match("#/(i|a)([\\d]+)/#is", $_arg_0["url"], $_var_11)) {
					$_var_23[1] = $_var_24[1] = $_var_11[2];
				}
			}
			if ($_var_23[1] && $_var_24[1]) {
				$_var_5 = "https://www.toutiao.com/api/comment/list/?group_id=" . $_var_23[1] . "&item_id=" . $_var_24[1] . "&comments_count=18";
				$_var_12 = addon_collect_toutiao_rule_getcontent($_var_5);
				$_var_25 = json_decode($_var_12, true);
				if ($_var_25["message"] != "success") {
					$_var_12 = dfsockopen($_var_5);
					$_var_25 = json_decode($_var_12, true);
				}
				if ($_arg_0["debug"]) {
					$_arg_0["debug_comment"] = $_var_12;
				}
				if (is_array($_var_25["data"]["comments"]) && !empty($_var_25["data"]["comments"])) {
					$_var_26 = rand(10, 20);
					$_var_27 = 0;
					foreach ($_var_25["data"]["comments"] as $_var_28) {
						$_var_28["text"] = trim(addon_collect_toutiao_iconv($_var_28["text"], $_arg_0["charset"], CHARSET));
						if (!empty($_var_28["text"])) {
							if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["gb2312tobig5_radio"]) {
								$_var_28["text"] = addon_collect_toutiao_rule_gb2312tobig5($_var_28["text"]);
							}
							if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["wyc_radio"]) {
								$_var_28["text"] = addon_collect_toutiao_rule_wyc($_var_28["text"]);
							}
							$_var_28["text"] = str_replace("src=\"//", "src=\"http://", $_var_28["text"]);
							$_arg_0["comments"][] = $_var_28["text"];
							$_var_27 = $_var_27 + 1;
							if ($_var_27 >= $_var_26) {
								break;
							}
						}
					}
				}
			}
		}
	}
	$_arg_0["404"] = false;
	preg_match("/404\\.jpg/is", $_var_14, $_var_29);
	if (!empty($_var_29)) {
		$_arg_0["404"] = true;
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	global $forumfield;
	$forumfield = array();
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["ftp_remote_radio"] && in_array("addon_storage_aliyunoss", $_G["setting"]["plugins"]["available"])) {
		include_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/OSS/AutoLoad.php";
	}
	require_once libfile("include/rule3", "plugin/addon_collect_toutiao/source");
	require_once libfile("include/rule4", "plugin/addon_collect_toutiao/source");
	require_once libfile("include/rule5", "plugin/addon_collect_toutiao/source");
	require_once libfile("include/rule6", "plugin/addon_collect_toutiao/source");