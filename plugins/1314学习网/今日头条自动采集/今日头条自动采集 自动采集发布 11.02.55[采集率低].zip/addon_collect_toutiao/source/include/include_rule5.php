<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_toutiao_msgformatting($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = $_var_4 = 0;
	$_var_5 = strtolower($_arg_0);
	$_var_3 = substr_count($_var_5, "<div");
	$_var_4 = substr_count($_var_5, "</div");
	if ($_var_3 > $_var_4) {
		$_var_2 = $_var_3 - $_var_4;
		$_var_6 = 0;
		while ($_var_6 < $_var_2) {
			$_arg_0 = $_arg_0 . "</div>";
			$_var_6 = $_var_6 + 1;
		}
	} else {
		if ($_var_3 < $_var_4) {
			$_var_2 = $_var_4 - $_var_3;
			$_var_6 = 0;
			while ($_var_6 < $_var_2) {
				$_arg_0 = "<div>" . $_arg_0;
				$_var_6 = $_var_6 + 1;
			}
		}
	}
	$_arg_0 = preg_replace("/>[\\s]+</iUs", "><", $_arg_0);
	$_arg_0 = preg_replace(array("/\\<link.*?\\>/", "/\\<script.*?\\<\\/script\\>/", "/\\<style.*?\\<\\/style\\>/is"), '', $_arg_0);
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["filterimg_radio"]) {
		$_arg_0 = preg_replace("/\\[img\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]|\\[img=\\d{1,4}[x|\\,]\\d{1,4}\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is", '', $_arg_0);
		$_arg_0 = preg_replace("/\\<img.+src=('|\"|)?(.*)(\\1)([\\s].*)?\\/?\\>/ismU", '', $_arg_0);
	}
	$_arg_0 = str_replace("<h1>", "<br><h1>", $_arg_0);
	$_arg_0 = str_replace("<img ", "<br><img ", $_arg_0);
	$_arg_0 = preg_replace("/<p([^>]*)><br><img/is", "<p\\1><img", $_arg_0);
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["img_aligncenter_radio"]) {
		$_arg_0 = str_replace("class=\"pgc-img-caption\"", "style=\"text-align:center;\"", $_arg_0);
		$_arg_0 = str_replace("<p><img ", "<p style=\"text-align:center;\"><img ", $_arg_0);
		$_arg_0 = preg_replace("/<br><img ([^>]*)>/is", "<br><p style=\"text-align:center;\"><img \\1></p>", $_arg_0);
	} else {
		$_arg_0 = preg_replace("/<p class=\"pgc-img-caption\">(.*?)<\\/p>/is", "<br>\\1", $_arg_0);
		$_arg_0 = preg_replace("/<img ([^>]*)>/is", "<img \\1><br>", $_arg_0);
	}
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["study_filter_mao"]) {
		$_arg_0 = preg_replace("/<a [^>]*>(.*?)<\\/a>/is", "\\1", $_arg_0);
	}
	$_arg_0 = preg_replace("/<p>(.*?)<\\/p>/is", "<br>\\1<br>", $_arg_0);
	$_arg_0 = str_replace("<br><p style=\"text-align:center;\"><br>", "<p style=\"text-align:center;\">", $_arg_0);
	$_arg_0 = preg_replace("/(<br>){1,}<\\/div>/is", "</div><br>", $_arg_0);
	$_arg_0 = preg_replace("/(<br>){2,}/is", "<br><br>", $_arg_0);
	$_arg_0 = preg_replace("/<\\/div>(<br>){2,}/is", "</div><br>", $_arg_0);
	$_arg_0 = preg_replace("/<p [^>]*><\\/p>/is", '', $_arg_0);
	$_arg_0 = str_replace("</p><br><br>", "</p><br>", $_arg_0);
	$_arg_0 = str_replace("</p><br><p style=\"text-align:center;\">", "</p><p style=\"text-align:center;\">", $_arg_0);
	$_arg_0 = str_replace("inline=\"0\"></p><br>", "inline=\"0\"></p>", $_arg_0);
	$_arg_0 = preg_replace("/<div id=\"pgc-card\" class=\"pgc-card\">(.*?)<\\/div>/iUs", '', $_arg_0);
	$_arg_0 = preg_replace("/^<br>/", '', $_arg_0);
	return $_arg_0;
}
function addon_collect_toutiao_rule_dealtime($_arg_0)
{
	global $_G;
	$_var_2 = false;
	$_var_3 = dgmdate($_G["timestamp"], "H", $_G["setting"]["timeoffset"]);
	$_var_4 = explode("-", $_arg_0);
	$_var_4[0] = intval(trim($_var_4[0]));
	if ($_var_4[0] < 0 || $_var_4[0] >= 24) {
		$_var_4[0] = 0;
	}
	$_var_4[1] = intval(trim($_var_4[1]));
	if ($_var_4[1] <= 0 || $_var_4[1] > 24) {
		$_var_4[1] = 24;
	}
	if ($_var_3 >= $_var_4[0] && $_var_3 <= $_var_4[1]) {
		$_var_2 = true;
	}
	return $_var_2;
}
function addon_collect_toutiao_rule_getcontent($_arg_0, $_arg_1 = false)
{
	global $_G;
	$_var_3 = curl_init();
	$_var_4 = '';
	if (strpos($_arg_0, "www.toutiao.com") !== false) {
		$_var_4 = DISCUZ_ROOT . "./source/plugin/addon_collect_toutiao/images/w.tmp";
		if (file_exists($_var_4)) {
			$_var_5 = file_get_contents($_var_4);
			$_var_5 = preg_replace("#s_v_web_id\\s+[\\w]+#i", "s_v_web_id\t" . md5(time()), $_var_5);
			$_var_5 = preg_replace("#www\\.toutiao\\.com\\s+FALSE\\s+/(a|i)\\d+/\\s+FALSE\\s+\\d+\\s+tt_webid\\s+\\d+#i", '', $_var_5);
			file_put_contents($_var_4, $_var_5);
		}
	} else {
		if (strpos($_arg_0, "m.toutiao.com") !== false) {
			$_var_4 = DISCUZ_ROOT . "./source/plugin/addon_collect_toutiao/images/m.tmp";
		}
	}
	$_var_6 = 10;
	curl_setopt($_var_3, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_3, CURLOPT_TIMEOUT, 30);
	if (!$_arg_1) {
		$_var_7 = addon_collect_toutiao_rule_get_rand_ip();
		curl_setopt($_var_3, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_var_7 . '', "CLIENT-IP:" . $_var_7 . ''));
	}
	if (strpos($_arg_0, "m.toutiao.com") !== false || strpos($_arg_0, "zjurl.cn") !== false) {
		curl_setopt($_var_3, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1");
	} else {
		$_var_8 = array("Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; 360SE)", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; 360Chrome)", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Maxthon 2.0)", "Mozilla/4.0 (Windows; MSIE 6.0; Windows NT 5.2)", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)", "Mozilla/5.0 (compatible; WOW64; MSIE 10.0; Windows NT 6.2)");
		$_var_9 = mt_rand(0, count($_var_8) - 1);
		curl_setopt($_var_3, CURLOPT_USERAGENT, $_var_8[$_var_9]);
	}
	curl_setopt($_var_3, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_3, CURLOPT_HEADER, 0);
	curl_setopt($_var_3, CURLOPT_SSL_VERIFYPEER, false);
	if ($_var_4 && file_exists($_var_4)) {
		curl_setopt($_var_3, CURLOPT_COOKIEJAR, $_var_4);
		curl_setopt($_var_3, CURLOPT_COOKIEFILE, $_var_4);
	}
	curl_setopt($_var_3, CURLOPT_FOLLOWLOCATION, 1);
	if (strpos($_arg_0, "zjurl.cn") !== false) {
		curl_setopt($_var_3, CURLOPT_REFERER, "https://profile.zjurl.cn/");
	}
	curl_setopt($_var_3, CURLOPT_MAXREDIRS, 3);
	curl_setopt($_var_3, CURLOPT_CONNECTTIMEOUT, $_var_6);
	$_var_10 = curl_exec($_var_3);
	curl_close($_var_3);
	$_var_10 = str_replace("<html><head></head><body></body></html>", '', $_var_10);
	if (strpos($_arg_0, "zjurl.cn") === false && empty($_var_10) || strpos($_var_10, "content: '',") !== false) {
		savecache("addon_collect_toutiao_fcjtime", $_G["timestamp"]);
	}
	return $_var_10;
}
function addon_collect_toutiao_fcjtimecheck()
{
	global $_G;
	$_var_1 = true;
	if (!isset($_G["cache"]["addon_collect_toutiao_fcjtime"])) {
		loadcache(array("addon_collect_toutiao_fcjtime"));
	}
	if (empty($_G["cache"]["addon_collect_toutiao_fcjtime"]) || is_array($_G["cache"]["addon_collect_toutiao_fcjtime"])) {
		$_G["cache"]["addon_collect_toutiao_fcjtime"] = 0;
	}
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["optimize_fcj"] && abs($_G["timestamp"] - $_G["cache"]["addon_collect_toutiao_fcjtime"]) < 300) {
		$_var_1 = false;
	}
	return $_var_1;
}
function addon_collect_toutiao_rule_summary($_arg_0)
{
	$_arg_0 = preg_replace(array("/\\[attach\\].*?\\[\\/attach\\]/", "/\\&[a-z]+\\;/i", "/\\<script.*?\\<\\/script\\>/"), '', $_arg_0);
	$_arg_0 = preg_replace("/\\[.*?\\]/", '', $_arg_0);
	$_arg_0 = addon_collect_toutiao_getstr(strip_tags($_arg_0), 200);
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}