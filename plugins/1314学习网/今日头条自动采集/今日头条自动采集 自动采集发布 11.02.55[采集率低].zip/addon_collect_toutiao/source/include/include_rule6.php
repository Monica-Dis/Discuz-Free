<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_toutiao_rule_post2article($_arg_0)
{
	global $_G;
	$_arg_0["subject"] = addon_collect_toutiao_getstr(trim($_arg_0["subject"]), 0);
	if (strlen($_arg_0["subject"]) < 1) {
		return array("status" => -1, "error" => lang("plugin/addon_collect_toutiao", "slang_007"));
	}
	if (empty($_arg_0["catid"])) {
		return array("status" => -1, "error" => lang("plugin/addon_collect_toutiao", "slang_008"));
	}
	$_var_2 = explode("-", $_G["cache"]["plugin"]["addon_collect_toutiao"]["rand_posttime"]);
	$_var_2[0] = max(intval($_var_2[0]), 0);
	$_var_2[1] = max(intval($_var_2[1]), 0);
	if (!empty($_var_2[1])) {
		$_var_3 = TIMESTAMP - rand($_var_2[0], $_var_2[1]);
	} else {
		$_var_3 = TIMESTAMP;
	}
	$_var_4 = array("title" => $_arg_0["subject"], "summary" => addon_collect_toutiao_rule_summary($_arg_0["message"]), "uid" => $_arg_0["uid"], "username" => $_arg_0["username"], "dateline" => $_var_3, "allowcomment" => "1", "catid" => intval($_arg_0["catid"]), "status" => 0);
	$_var_5 = C::t("portal_article_title")->insert($_var_4, 1);
	$_arg_0["content"] = addon_collect_toutiao_getstr($_arg_0["message"], 0, 0, 0, 0, 1);
	C::t("portal_article_content")->insert(array("aid" => $_var_5, "content" => $_arg_0["content"], "pageorder" => 1, "dateline" => $_var_3));
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["downremoteimg_radio"]) {
		addon_collect_toutiao_articledownremoteimg(array("message" => $_arg_0["content"], "subject" => $_arg_0["subject"], "aid" => $_var_5, "uid" => $_arg_0["uid"]));
	}
	C::t("common_member_status")->update($_arg_0["uid"], array("lastpost" => $_var_3), "UNBUFFERED");
	C::t("portal_category")->increase($_var_4["catid"], array("articles" => 1));
	if ($_G["setting"]["version"] != "X2.5") {
		C::t("portal_category")->update($_var_4["catid"], array("lastpublish" => TIMESTAMP));
	}
	C::t("portal_article_count")->insert(array("aid" => $_var_5, "catid" => $_var_4["catid"], "viewnum" => $_arg_0["views"]));
	C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_arg_0["articleid"]), array("postid" => $_var_5, "posttype" => "2"), true);
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["study_reply_radio"]) {
		if (is_array($_arg_0["comments"]) && !empty($_arg_0["comments"])) {
			$_var_6 = 0;
			$_var_7 = array();
			$_var_8 = explode("-", $_G["cache"]["plugin"]["addon_collect_toutiao"]["rand_replytime"]);
			$_var_8[0] = max(intval($_var_8[0]), 0);
			$_var_8[1] = max(intval($_var_8[1]), 0);
			foreach ($_arg_0["comments"] as $_var_9) {
				if (!empty($_var_9)) {
					$_var_7 = addon_collect_toutiao_rule_getuser("reply", $_arg_0);
					if (!empty($_var_8[1])) {
						$_var_3 = $_var_3 + rand($_var_8[0], $_var_8[1]);
					} else {
						$_var_3 = $_var_3 + rand(1, 20);
					}
					$_var_7["comment_time"] = $_var_3;
					addon_collect_toutiao_rule_comment($_var_7, $_var_5, $_var_9, "aid");
				}
			}
		}
	}
	return array("status" => 1, "postid" => $_var_5);
}
function addon_collect_toutiao_rule_post($_arg_0)
{
	global $_G;
	$_var_2 = array("status" => -1, "error" => lang("plugin/addon_collect_toutiao", "slang_006"));
	$_var_3 = explode("-", $_G["cache"]["plugin"]["addon_collect_toutiao"]["rand_view"]);
	$_var_3[0] = max(intval($_var_3[0]), 1);
	$_var_3[1] = max(intval($_var_3[1]), 1);
	if ($_var_3[1] > $_var_3[0]) {
		$_arg_0["views"] = rand($_var_3[0], $_var_3[1]);
	} else {
		$_arg_0["views"] = $_var_3[0];
	}
	$_var_4 = 0;
	if ($_arg_0["posttype"] == 2) {
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["ban_samename"]) {
			$_var_4 = DB::result_first("SELECT aid FROM " . DB::table("portal_article_title") . " WHERE " . DB::field("title", addon_collect_toutiao_getstr(trim($_arg_0["subject"]), 0)));
		}
		if ($_var_4) {
			$_var_2 = array("status" => -1, "postid" => $_var_4, "error" => lang("plugin/addon_collect_toutiao", "slang_011"));
		} else {
			$_var_2 = addon_collect_toutiao_rule_post2article($_arg_0);
		}
	} else {
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["ban_samename"]) {
			$_var_5 = DB::result_first("SELECT tid FROM " . DB::table("forum_thread") . " WHERE " . DB::field("subject", $_arg_0["subject"]));
		}
		if ($_var_5) {
			$_var_2 = array("status" => -1, "postid" => $_var_5, "error" => lang("plugin/addon_collect_toutiao", "slang_011"));
		} else {
			$_var_2 = addon_collect_toutiao_rule_post2thread($_arg_0);
		}
	}
	$_var_6 = array();
	if ($_var_2["status"] == 1) {
		$_var_6 = array("status" => 1, "postid" => $_var_2["postid"], "posttype" => $_arg_0["posttype"], "errlog" => '', "updatetime" => $_G["timestamp"]);
		C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_arg_0["articleid"]), $_var_6, true);
		if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["linksubmit_radio"]) {
			$_var_7 = addon_collect_toutiao_rule_dealurl(array("postid" => $_var_2["postid"], "posttype" => $_arg_0["posttype"], "catid" => $_arg_0["catid"]));
			addon_collect_toutiao_rule_linksubmit($_var_7);
		}
	} else {
		$_var_6 = array("status" => -1, "postid" => 0, "posttype" => 0, "errlog" => $_var_2["error"], "updatetime" => $_G["timestamp"]);
		if (isset($_var_2["postid"])) {
			$_var_6["status"] = 1;
			$_var_6["postid"] = $_var_2["postid"];
			$_var_6["posttype"] = $_arg_0["posttype"];
		}
		C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_arg_0["articleid"]), $_var_6, true);
	}
	return $_var_2;
}
function addon_collect_toutiao_rule_getuser($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	$_arg_0 = $_arg_0 ? $_arg_0 : "post";
	if (isset($_arg_1["configs"]["study_" . $_arg_0 . "_uids"]) && !empty($_arg_1["configs"]["study_" . $_arg_0 . "_uids"])) {
		$_var_4 = str_replace("-", ",", $_arg_1["configs"]["study_" . $_arg_0 . "_uids"]);
	} else {
		$_var_4 = str_replace("-", ",", $_G["cache"]["plugin"]["addon_collect_toutiao"]["study_" . $_arg_0 . "_uids"]);
	}
	$_var_5 = explode(",", $_var_4);
	if (count($_var_5) == 2) {
		$_var_6 = intval($_var_5[0]) > 0 ? intval($_var_5[0]) : 1;
		$_var_7 = intval($_var_5[1]) > $_var_6 ? intval($_var_5[1]) : $_var_6;
		$_var_8 = rand($_var_6, $_var_7);
	} else {
		$_var_9 = rand(0, count($_var_5) - 1);
		$_var_8 = max(intval($_var_5[$_var_9]), 1);
	}
	$_var_3 = getuserbyuid($_var_8, 1);
	if (empty($_var_3)) {
		$_var_3 = getuserbyuid(1);
	}
	return $_var_3;
}
function addon_collect_toutiao_rule_linksubmit($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["addon_collect_toutiao"]["linksubmit_api"];
	if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["linksubmit_radio"] && $_var_2) {
		if (function_exists("curl_init") && function_exists("curl_exec")) {
			$_var_3 = curl_init();
			curl_setopt($_var_3, CURLOPT_URL, $_var_2);
			curl_setopt($_var_3, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($_var_3, CURLOPT_HTTPHEADER, "Content-Type: text/plain");
			curl_setopt($_var_3, CURLOPT_POST, 1);
			curl_setopt($_var_3, CURLOPT_POSTFIELDS, $_arg_0);
			$_var_4 = curl_exec($_var_3);
			curl_close($_var_3);
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("function/core", "plugin/addon_collect_toutiao/source");
	global $_G;
	global $forumfield;
	$forumfield = array();
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			addon_collect_toutiao_check();
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}