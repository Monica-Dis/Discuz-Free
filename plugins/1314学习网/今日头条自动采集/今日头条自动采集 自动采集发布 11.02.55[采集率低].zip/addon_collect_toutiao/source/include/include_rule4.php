<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_toutiao_rule_analyze($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = array();
	$_var_4 = false;
	$_var_5 = $_arg_0["current_page"] > 1 ? 20 * $_arg_0["current_page"] : 0;
	$_arg_0["page"] = max(1, $_arg_0["page"]);
	$_arg_0["articlelist"] = $_var_3 = array();
	if (strpos($_arg_0["url"], "/user/")) {
		$_var_4 = true;
		preg_match("/mid=([\\d]+)/is", $_arg_0["url"], $_var_6);
		preg_match("/_signature=([^&]+)/is", $_arg_0["url"], $_var_7);
		$_var_8 = explode("/user/", $_arg_0["url"]);
		$_var_8 = explode("/", $_var_8[1]);
		$_var_9 = $_var_8[0];
		if (!empty($_var_6[1])) {
			$_var_10 = $_var_6[1];
			$_var_11 = $_var_7[1];
			if ($_GET["_signature"]) {
				if ($_arg_0["current_page"] == 1) {
					C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update_by_where(array("id" => $_arg_0["id"]), array("url" => "https://www.toutiao.com/c/user/" . $_var_9 . "/#mid=" . $_var_10 . "&_signature=" . $_GET["_signature"]), true);
				}
				$_var_11 = $_GET["_signature"];
			}
			if ($_var_11) {
				$_arg_0["max_behot_time"] = $_arg_0["max_behot_time"] ? $_arg_0["max_behot_time"] : 0;
				$_arg_0["url"] = "https://profile.zjurl.cn/api/feed_backflow/profile_share/v1/?category=profile_article&visited_uid=" . $_var_9 . "&stream_api_version=82&request_source=1&offset=" . $_arg_0["max_behot_time"] . "&user_id=" . $_var_9 . "&media_id=" . $_var_10 . "&_signature=" . $_var_11;
			} else {
				$_arg_0["url"] = "https://profile.zjurl.cn/api/feed/profile/v1/?category=profile_article&visited_uid=" . rawurlencode(addon_collect_toutiao_iconv($_var_9, CHARSET, $_arg_0["charset"])) . "&stream_api_version=82&request_source=1&offset=" . $_arg_0["max_behot_time"] . "&user_id=" . rawurlencode(addon_collect_toutiao_iconv($_var_9, CHARSET, $_arg_0["charset"])) . "&media_id=" . $_var_10 . '';
			}
		} else {
			$_arg_0["url"] = "https://www.toutiao.com/c/user/article/?page_type=1&user_id=" . rawurlencode(addon_collect_toutiao_iconv($_var_9, CHARSET, $_arg_0["charset"])) . "&max_behot_time=" . dintval($_arg_0["max_behot_time"]) . "&count=20&_signature=xMbZSBAbnunk2wJRCoWLt8TG2F";
		}
	} else {
		if (strpos($_arg_0["url"], "/ch/")) {
			$_var_4 = true;
			$_var_8 = explode("/ch/", $_arg_0["url"]);
			$_var_8 = explode("/", $_var_8[1]);
			$_arg_0["url"] = $_var_8[0];
			if ($_arg_0["url"] == "news_image") {
				$_arg_0["url"] = "https://www.toutiao.com/api/pc/feed/?category=%E7%BB%84%E5%9B%BE&utm_source=toutiao&max_behot_time=1513086371&as=A1784D09CAA7C0C&cp=8D9AC71CE05C0E1&_signature=fO0g6wAAJsVc8Pvydzp0q3ztIP";
			} else {
				$_arg_0["url"] = "https://m.toutiao.com/list/?tag=" . rawurlencode(addon_collect_toutiao_iconv($_arg_0["url"], CHARSET, $_arg_0["charset"])) . "&ac=wap&count=20&format=json_raw&as=A1784D09CAA7C0C&cp=8D9AC71CE05C0E1";
			}
		} else {
			$_arg_0["keyword"] = $_arg_0["url"];
			$_arg_0["url"] = "https://www.toutiao.com/api/search/content/?aid=24&app_name=web_search&offset=" . $_var_5 . "&format=json&keyword=" . rawurlencode(addon_collect_toutiao_iconv($_arg_0["keyword"], CHARSET, $_arg_0["charset"])) . "&autoload=true&count=20&en_qc=1&cur_tab=" . ($_G["cache"]["plugin"]["addon_collect_toutiao"]["tuji_radio"] ? 3 : 1) . "&from=search_tab&pd=information&timestamp=" . time() . "974";
		}
	}
	$_var_12 = array();
	$_var_13 = addon_collect_toutiao_rule_getcontent($_arg_0["url"]);
	$_var_12 = json_decode($_var_13, true);
	$_var_12["data"] = is_array($_var_12["data"]) ? $_var_12["data"] : array();
	foreach ($_var_12["data"] as $_var_14 => $_var_15) {
		if ($_var_15["has_video"]) {
			unset($_var_12["data"][$_var_14]);
		}
	}
	if (!$_var_4 && count($_var_12["data"]) < 5) {
		$_var_16 = array("010152045023154BB5C", "0100110351310689556", "0101520200393980296", "010152024131128EFB2", "010011041227758517C", "0101520320821252CE2");
		$_var_17 = mt_rand(0, count($_var_16) - 1);
		$_var_18 = $_var_19[$_var_17];
		if (empty($_var_18)) {
			$_var_18 = "010152045023154BB5C";
		}
		$_arg_0["url"] = "https://m.toutiao.com/search/?format=json&count=20&offset=" . $_var_5 . "&start_index=" . $_var_5 . "&keyword=" . rawurlencode(addon_collect_toutiao_iconv($_arg_0["keyword"], CHARSET, $_arg_0["charset"])) . "&pd=information&search_id=" . date("YmdHis") . $_var_18 . "&traffic_source=";
		$_var_13 = addon_collect_toutiao_rule_getcontent($_arg_0["url"]);
		$_var_20 = json_decode($_var_13, true);
		preg_match_all("#<script type=\"application/json\" id=\"ala-data-[\\w]+\"[^>]*>(.*?)</script>#is", $_var_20["scripts"], $_var_21);
		if (!empty($_var_21[1]) && is_array($_var_21[1])) {
			foreach ($_var_21[1] as $_var_15) {
				$_var_22 = json_decode($_var_15, true);
				if (!$_var_22["has_video"]) {
					$_var_12["data"][] = $_var_22;
				}
			}
			if ($_var_5 == 0 && count($_var_12["data"]) < 5) {
				$_arg_0["url"] = "https://m.toutiao.com/search/?format=json&count=10&offset=10&start_index=10&keyword=" . rawurlencode(addon_collect_toutiao_iconv($_arg_0["keyword"], CHARSET, $_arg_0["charset"])) . "&pd=information&search_id=" . date("YmdHis") . $_var_18 . "&traffic_source=";
				$_var_13 = addon_collect_toutiao_rule_getcontent($_arg_0["url"]);
				$_var_20 = json_decode($_var_13, true);
				preg_match_all("#<script type=\"application/json\" id=\"ala-data-[\\w]+\"[^>]*>(.*?)</script>#is", $_var_20["scripts"], $_var_21);
				if (!empty($_var_21[1]) && is_array($_var_21[1])) {
					foreach ($_var_21[1] as $_var_15) {
						$_var_22 = json_decode($_var_15, true);
						if (!$_var_22["has_video"]) {
							$_var_12["data"][] = $_var_22;
						}
					}
				}
			}
		}
	}
	if (isset($_var_12["error"]) && $_var_12["error"]) {
		$_var_13 = addon_collect_toutiao_rule_getcontent($_arg_0["url"], true);
		$_var_12 = json_decode($_var_13, true);
	}
	$_var_23 = explode("|", $_G["cache"]["plugin"]["addon_collect_toutiao"]["notcollect_authors"]);
	foreach ($_var_12["data"] as $_var_14 => $_var_15) {
		if ($_var_4) {
			$_var_15 = json_decode($_var_15["content"], true);
		}
		if (!empty($_var_15["title"]) && ($_var_4 && (!$_var_15["has_video"] || $_var_15["has_gallery"] || in_array($_var_15["article_genre"], array("article", "gallery"))) || !$_var_15["has_video"])) {
			if ($_var_15["tag"] != "ad" && $_var_15["article_live_type"] != "video") {
				preg_match("#/group/([\\d]+)/#is", $_var_15["article_url"], $_var_24);
				if (empty($_var_24[1])) {
					preg_match("#/group/([\\d]+)/#is", $_var_15["seo_url"], $_var_24);
					if (empty($_var_24[1])) {
						preg_match("#/group/([\\d]+)/#is", $_var_15["source_url"], $_var_24);
						if (empty($_var_24[1])) {
							preg_match("#/group/([\\d]+)/#is", $_var_15["display_url"], $_var_24);
						}
					}
				}
				if (empty($_var_24[1])) {
					preg_match("#/item/([\\d]+)/#is", $_var_15["seo_url"], $_var_24);
					if (empty($_var_24[1])) {
						preg_match("#/item/([\\d]+)/#is", $_var_15["article_url"], $_var_24);
						if (empty($_var_24[1])) {
							preg_match("#/item/([\\d]+)/#is", $_var_15["source_url"], $_var_24);
						}
					}
					if (empty($_var_24[1])) {
						continue;
					}
					$_var_3["url"] = "http://www.toutiao.com/item/" . $_var_24[1] . "/";
				} else {
					$_var_3["url"] = "http://www.toutiao.com/group/" . $_var_24[1] . "/";
				}
				if (strpos($_var_3["url"], "/dongtai/") === false) {
					if (!empty($_var_15["source"])) {
						$_var_3["author"] = addon_collect_toutiao_iconv($_var_15["source"], $_arg_0["charset"], CHARSET);
						if (!empty($_var_23) && !empty($_var_3["author"]) && in_array($_var_3["author"], $_var_23)) {
							goto Label_Temp_52;
						}
					}
					$_var_3["url"] = str_replace("https://", "http://", $_var_3["url"]);
					$_var_3["url"] = str_replace("http://toutiao.com/", "http://www.toutiao.com/", $_var_3["url"]);
					$_var_3["url"] = str_replace("//toutiao.com/", "http://www.toutiao.com/", $_var_3["url"]);
					$_var_3["url"] = str_replace("http:http://", "http://", $_var_3["url"]);
					$_var_3["url"] = str_replace("http://www.toutiao.com/http://", "http://", $_var_3["url"]);
					if ($_var_15["item_id_str"] && preg_match("#^[\\d]+\$#is", $_var_15["item_id_str"])) {
						$_var_3["group_id"] = "i" . $_var_15["item_id_str"];
						$_var_3["url"] = "https://www.toutiao.com/i" . $_var_15["item_id_str"] . "/";
					} else {
						if ($_var_15["item_id"] && preg_match("#^[\\d]+\$#is", $_var_15["item_id"])) {
							$_var_3["group_id"] = "i" . $_var_15["item_id"];
							$_var_3["url"] = "https://www.toutiao.com/i" . $_var_15["item_id"] . "/";
						} else {
							if (preg_match("#/[i|a]*([\\d]+)/#is", $_var_3["url"], $_var_25)) {
								$_var_15["group_id"] = $_var_25[1];
							}
							$_var_3["group_id"] = !(strpos($_var_3["url"], "/item/") === false) ? "i" : '' . ($_var_15["log_pb"]["group_id_str"] ? $_var_15["log_pb"]["group_id_str"] : $_var_15["group_id"]);
						}
					}
					$_var_3["subject"] = addon_collect_toutiao_iconv($_var_15["title"], $_arg_0["charset"], CHARSET);
					$_var_3["subject"] = preg_replace("#^\\?#is", '', $_var_3["subject"]);
					if ($_G["cache"]["plugin"]["addon_collect_toutiao"]["gb2312tobig5_radio"]) {
						$_var_3["subject"] = addon_collect_toutiao_rule_gb2312tobig5($_var_3["subject"]);
					}
					$_arg_0["articlelist"][] = $_var_3;
					Label_Temp_52:
				}
			}
		}
	}
	if (isset($_var_12["next"]["max_behot_time"])) {
		$_arg_0["max_behot_time"] = $_var_12["next"]["max_behot_time"];
	} else {
		if (isset($_var_12["offset"])) {
			$_arg_0["max_behot_time"] = $_var_12["offset"];
		}
	}
	return $_arg_0;
}
function addon_collect_toutiao_rule_comment($_arg_0, $_arg_1, $_arg_2, $_arg_3 = "aid")
{
	global $_G;
	$_arg_1 = intval($_arg_1);
	if (empty($_arg_1)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = addon_collect_toutiao_getstr($_arg_2, 0, 0, 0, 1, 0);
	if (strlen($_arg_2) < 2) {
		return "content_is_too_short";
	}
	$_arg_3 = in_array($_arg_3, array("aid", "topicid")) ? $_arg_3 : "aid";
	$_var_5 = $_arg_3 == "aid" ? "portal_article_title" : "portal_topic";
	$_var_6 = C::t($_var_5)->fetch($_arg_1);
	if (empty($_var_6)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = censor($_arg_2);
	if (censormod($_arg_2)) {
		$_var_7 = 1;
	} else {
		$_var_7 = 0;
	}
	$_var_8 = array("uid" => $_arg_0["uid"], "username" => $_arg_0["username"], "id" => $_arg_1, "idtype" => $_arg_3, "postip" => addon_collect_toutiao_rule_get_rand_ip(), "dateline" => $_arg_0["comment_time"], "status" => $_var_7, "message" => $_arg_2);
	$_var_9 = C::t("portal_comment")->insert($_var_8, true);
	if ($_var_7 == 1) {
		updatemoderate($_arg_3 . "_cid", $_var_9);
		$_var_10 = $_arg_3 == "aid" ? "verifyacommont" : "verifytopiccommont";
		manage_addnotify($_var_10);
	}
	$_var_5 = $_arg_3 == "aid" ? "portal_article_count" : "portal_topic";
	C::t($_var_5)->increase($_arg_1, array("commentnum" => 1));
	C::t("common_member_status")->update($_G["uid"], array("lastpost" => $_G["timestamp"]), "UNBUFFERED");
	return "do_success";
}
function addon_collect_toutiao_rule_wyc($_arg_0)
{
	global $_G;
	if (!isset($_G["toutiao_wyc_keywords"])) {
		$_G["toutiao_wyc_keywords"]["find"] = array();
		$_G["toutiao_wyc_keywords"]["replace"] = array();
		$_var_2 = explode("\n", str_replace("\r\n", "\n", $_G["cache"]["plugin"]["addon_collect_toutiao"]["wyc_keywords"]));
		if (is_array($_var_2) && !empty($_var_2)) {
			foreach ($_var_2 as $_var_3) {
				$_var_4 = explode("==", $_var_3);
				if ($_var_4[0] && $_var_4[1]) {
					$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
					$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
				}
			}
		}
		if (is_file(DISCUZ_ROOT . "./source/plugin/addon_collect_toutiao/images/keywords.tmp")) {
			$_var_5 = @file(DISCUZ_ROOT . "./source/plugin/addon_collect_toutiao/images/keywords.tmp");
			if (is_array($_var_5) && !empty($_var_5)) {
				foreach ($_var_5 as $_var_3) {
					$_var_4 = explode("==", trim($_var_3));
					if ($_var_4[0] && $_var_4[1] && !in_array($_var_4[0], $_G["toutiao_wyc_keywords"]["find"])) {
						$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
						$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
					}
				}
			}
		}
	}
	if (isset($_G["toutiao_wyc_keywords"]["find"]) && is_array($_G["toutiao_wyc_keywords"]["find"])) {
		$_arg_0 = str_replace($_G["toutiao_wyc_keywords"]["find"], $_G["toutiao_wyc_keywords"]["replace"], $_arg_0);
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}