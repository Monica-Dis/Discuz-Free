<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_addon_collect_toutiao {
	function global_footer_mobile() {
		global $_G;
		$return = '';
		if ($_G['cache']['plugin']['addon_collect_toutiao']['touch_auto_radio'] && (in_array($_G['cache']['plugin']['addon_collect_toutiao']['auto_collect_radio'], array('1', '3')) || in_array($_G['cache']['plugin']['addon_collect_toutiao']['auto_post_radio'], array('1', '3')))) {
			$return = '<script type="text/javascript" src="' . $_G['siteurl'] . 'plugin.php?id=addon_collect_toutiao:autopost" defer="defer"></script>';
		}
		return $return;
	}
}