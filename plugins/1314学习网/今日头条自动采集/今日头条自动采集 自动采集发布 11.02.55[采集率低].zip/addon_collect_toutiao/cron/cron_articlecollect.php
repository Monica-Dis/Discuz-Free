<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=2
 * ���ο������ƣ�http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=22
 */
//cronname:slang_010
//minute:0,10,20,30,40,50


if (!defined('IN_DISCUZ')) {
    exit('');
}

require_once libfile('class/rule', 'plugin/addon_collect_toutiao/source');

loadcache('plugin');
if (!empty($_G['cache']['plugin']['addon_collect_toutiao'])) {

    $spiderlist = array();
    $splugin_setting = $_G['cache']['plugin']['addon_collect_toutiao'];
    $count = 0;
		if(!empty($splugin_setting['count_limit'])){
			$count = C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->count_by_where(array('status' => '0'));
		}
		
		if(empty($splugin_setting['count_limit']) || $splugin_setting['count_limit'] > $count){
      if(in_array($splugin_setting['auto_collect_radio'], array('1', '2'))){
  	    if (addon_collect_toutiao_rule_dealtime($splugin_setting['study_start_time'])){
  	    	$splugin_setting['study_list_number'] = max(min($splugin_setting['study_list_number'], 5), 1);
  	    	$todaytime = strtotime(dgmdate($_G['timestamp'], 'Y-m-d', $_G['setting']['timeoffset'])) - $_G['setting']['timeoffset']*3600;
  	    	//$todaytime = strtotime(dgmdate($_G['timestamp'], 'Y-m-d', $splugin_setting['timeoffset']));
  		    $spiderlist = C::t('#addon_collect_toutiao#addon_collect_toutiao_spider')->fetch_all_by_search(array('updatetime' => array($todaytime, '<'), 'status' => '1'), array('updatetime' => 'ASC'), $splugin_setting['study_list_number']);
  		  }
  	  }
  	}
	  
    if (!empty($spiderlist)) {
				define('IN_TOUTIAO_COLLECT_CRON', '1');
        $articleclasses = new addon_collect_toutiao_rule;

        foreach ($spiderlist as $spider) {
            $articledata = $articleclasses->analyze($spider);
            if ($articledata === false) {
                C::t('#addon_collect_toutiao#addon_collect_toutiao_spider')->update_by_where(array('id' => $spider['id']), array('status' => 0), true);
            } else {
                $sha1list = $articlelist = array();
                $articlelist = C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->fetch_all_by_search(array('spiderid' => $spider['id']), array('creattime' => 'DESC'), 40);
                foreach ($articlelist as $article) {
                    $sha1list[] = $article['sha1'];
                }
                $count = 0;
                $articledata['articlelist'] = array_reverse($articledata['articlelist']);
                foreach ($articledata['articlelist'] as $article) {
                    $article['sha1'] = sha1($article['url']);
                    if (!in_array($article['sha1'], $sha1list)) {
                        $article_result = C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->fetch_by_search(DB::field('sha1', $article['sha1']).' OR '.DB::field('group_id', $article['group_id']), array('id' => 'DESC'));
                        if (empty($article_result['id'])) {
                            $data = array(
                                'spiderid' => $spider['id'],
                                'url' => $article['url'],
                                'sha1' => $article['sha1'],
                                'subject' => $article['subject'],
                                'message' => $article['message'],
                                'group_id' => $article['group_id'],
                                'creattime' => $_G['timestamp'],
                                'updatetime' => $_G['timestamp'],
                            );
                            
                            C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->insert($data);
                            $count++;
                        }
                    }
                }

                $spiderdata = array(
                    'updatetime' => $_G['timestamp'],
                );
                if ($count > 0) {
                    $spiderdata['count'] = C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->count_by_where(array('spiderid' => $spider['id']));
                }
                if ($articledata['page'] && $articledata['page'] != $spider['page']) {
                    $spiderdata['page'] = $articledata['page'];
                }
                C::t('#addon_collect_toutiao#addon_collect_toutiao_spider')->update_by_where(array('id' => $spider['id']), $spiderdata, true);
            }
            sleep(5);
        }
    } elseif(in_array($splugin_setting['auto_post_radio'], array('2'))){//ȡ�� �ƻ�����+ǰ̨����
        define('IN_TOUTIAO_COLLECT_CRON', '1');
		    if (addon_collect_toutiao_rule_dealtime($splugin_setting['study_post_time']) && addon_collect_toutiao_fcjtimecheck()){
	        $articlelist = array();
	        $splugin_setting['study_article_number'] = max(min($splugin_setting['study_article_number'], 5), 1);
	        $articlelist = C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->fetch_all_by_search(array('status' => '0'), array('id' => 'ASC'), $splugin_setting['study_article_number']);
	        if (!empty($articlelist)) {
	        		$articleids = array();
	            foreach ($articlelist as $article) {
	            	$articleids[] = $article['id'];
	            }
	            C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(DB::field('id', $articleids), array('status' => -1, 'errlog' => '&#x53D1;&#x5E03;&#x4E2D;', 'updatetime' => $_G['timestamp']), true);
	            
	            $spiderlist = array();
	            $articleclasses = new addon_collect_toutiao_rule;
	            foreach ($articlelist as $article) {
	                $processname ='DZS_AUTOPOST_'.$article['id'];
									if(discuz_process::islocked($processname, 15)) {
										continue;
									}
									
	                if (!$spiderlist[$article['spiderid']]) {
	                    $spiderlist[$article['spiderid']] = C::t('#addon_collect_toutiao#addon_collect_toutiao_spider')->fetch_by_search(array('id' => $article['spiderid']));
	                    $spiderlist[$article['spiderid']]['configs_arr'] = !empty($spiderlist[$article['spiderid']]['configs']) ? dunserialize($spiderlist[$article['spiderid']]['configs']) : array();
									    if(!is_array($spiderlist[$article['spiderid']]['configs_arr'])){
									    	$spiderlist[$article['spiderid']]['configs_arr'] = array();
									    }
	                }
	
	                $spider = $spiderlist[$article['spiderid']];
	                $article['configs'] = $spider['configs_arr'];
	                $article['posttype'] = $spider['posttype'];
	                $articleinfo = $articleclasses->spider($article);
	                if($articleinfo['censor']){
	                		C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x542B;&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;', 'updatetime' => $_G['timestamp']), true);
	                } elseif (empty($articleinfo['subject'])) {
	                    C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x540D;&#x79F0;', 'updatetime' => $_G['timestamp']), true);
	                } elseif (empty($articleinfo['message'])) {
	                		if($splugin_setting['optimize_fcj'] && $articleinfo['fcj']){
						        		  C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(array('id' => $article['id']), array('status' => 0, 'errlog' => 'FCJ', 'updatetime' => $_G['timestamp']), true);
						        			break;
						        	}else{
						          	if($articleinfo['404']){
					        				C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '404', 'updatetime' => $_G['timestamp']), true);
					        			}else{
						            	C::t('#addon_collect_toutiao#addon_collect_toutiao_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;', 'updatetime' => $_G['timestamp']), true);
						            }
						          }
	                } else {
	                    $articledata = array(
									        'url' => $articleinfo['url'],
									        'subject' => $articleinfo['subject'],
									        'message' => $articleinfo['message'],
									        'comments' => $articleinfo['comments'],
									        'updatetime' => $_G['timestamp'],
									    );
									    
									    $member = addon_collect_toutiao_rule_getuser('post', $article);
									    
	                    $articledata['articleid'] = $article['id'];
	                    $articledata['uid'] = $member['uid'];
	                    $articledata['username'] = $member['username'];
	                    
	                    $articledata['posttype'] = $spider['posttype'];
	                    $articledata['catid'] = $spider['catid'];
	                    $articledata['typeid'] = $spider['typeid'];
	                    $articledata['configs'] = $spider['configs_arr'];
	
	                    $articleclasses->post($articledata);
	                }
	                
					discuz_process::unlock($processname);
					sleep(5);
	            }
	        }
	      }
    }
}