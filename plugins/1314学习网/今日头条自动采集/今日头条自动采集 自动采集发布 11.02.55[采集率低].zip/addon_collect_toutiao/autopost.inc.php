<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	require_once libfile("class/rule", "plugin/addon_collect_toutiao/source");
	loadcache("plugin");
	if (!empty($_G["cache"]["plugin"]["addon_collect_toutiao"])) {
		$_var_1 = $_G["cache"]["plugin"]["addon_collect_toutiao"];
		$_var_1["autopost_jiange"] = min(86400, max(60, intval($_var_1["autopost_jiange"])));
		$_var_2 = "//";
		if (defined("IN_TOUTIAO_COLLECT_CRON")) {
			$_var_2 = $_var_2 . ("on cron");
		} else {
			$_var_3 = array();
			$_var_4 = "DZS_AUTOJIANGE_TOUTIAO_" . $_var_1["autopost_jiange"];
			if (!discuz_process::islocked($_var_4, $_var_1["autopost_jiange"])) {
				$_var_5 = 0;
				if (!empty($_var_1["count_limit"])) {
					$_var_5 = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->count_by_where(array("status" => "0"));
				}
				if (empty($_var_1["count_limit"]) || $_var_1["count_limit"] > $_var_5) {
					if (in_array($_var_1["auto_collect_radio"], array("1", "3"))) {
						$_var_2 = $_var_2 . ("-collect");
						if (addon_collect_toutiao_rule_dealtime($_var_1["study_start_time"])) {
							$_var_2 = $_var_2 . "-t";
							$_var_6 = $_G["timestamp"] - 3600;
							$_var_3 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_all_by_search(array("updatetime" => array($_var_6, "<"), "status" => "1"), array("updatetime" => "ASC"), 1);
						} else {
							$_var_2 = $_var_2 . ("-notime");
						}
						if (!empty($_var_3)) {
							$_var_2 = $_var_2 . "-s";
							$_var_7 = new addon_collect_toutiao_rule();
							foreach ($_var_3 as $_var_8) {
								$_var_2 = $_var_2 . ("." . $_var_8["id"]);
								$_var_9 = "DZS_AUTOANALYZE_TOUTIAO_" . $_var_8["id"];
								if (!discuz_process::islocked($_var_9, 15)) {
									$_var_10 = $_var_7->analyze($_var_8);
									if ($_var_10 === false) {
										C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update_by_where(array("id" => $_var_8["id"]), array("status" => 0), true);
									} else {
										$_var_11 = $_var_12 = array();
										$_var_12 = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->fetch_all_by_search(array("spiderid" => $_var_8["id"]), array("creattime" => "DESC"), 40);
										foreach ($_var_12 as $_var_13) {
											$_var_11[] = $_var_13["sha1"];
										}
										$_var_5 = 0;
										$_var_10["articlelist"] = array_reverse($_var_10["articlelist"]);
										foreach ($_var_10["articlelist"] as $_var_13) {
											$_var_13["sha1"] = sha1($_var_13["url"]);
											if (!in_array($_var_13["sha1"], $_var_11)) {
												$_var_14 = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->fetch_by_search(DB::field("sha1", $_var_13["sha1"]) . " OR " . DB::field("group_id", $_var_13["group_id"]), array("id" => "DESC"));
												if (empty($_var_14["id"])) {
													$_var_15 = array("spiderid" => $_var_8["id"], "url" => $_var_13["url"], "sha1" => $_var_13["sha1"], "subject" => $_var_13["subject"], "message" => $_var_13["message"], "group_id" => $_var_13["group_id"], "creattime" => $_G["timestamp"], "updatetime" => $_G["timestamp"]);
													C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->insert($_var_15);
													$_var_5 = $_var_5 + 1;
												}
											}
										}
										$_var_16 = array("updatetime" => $_G["timestamp"]);
										if ($_var_5 > 0) {
											$_var_16["count"] = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->count_by_where(array("spiderid" => $_var_8["id"]));
										}
										if ($_var_10["page"] && $_var_10["page"] != $_var_8["page"]) {
											$_var_16["page"] = $_var_10["page"];
										}
										C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update_by_where(array("id" => $_var_8["id"]), $_var_16, true);
									}
									discuz_process::unlock($_var_9);
								}
							}
						}
					}
				}
				if (in_array($_var_1["auto_post_radio"], array("1", "3"))) {
					if (addon_collect_toutiao_fcjtimecheck()) {
						$_var_2 = $_var_2 . ("-post");
						if (addon_collect_toutiao_rule_dealtime($_var_1["study_post_time"])) {
							$_var_2 = $_var_2 . "-t";
							$_var_12 = array();
							$_var_17 = 0;
							Label_17468:
							$_var_8 = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_by_search(array("status" => "1", "updatetime" => array(0, ">")), array("posttime" => "ASC"));
							if ($_var_8["id"]) {
								$_var_2 = $_var_2 . "-p";
								C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->update_by_where(array("id" => $_var_8["id"]), array("posttime" => $_G["timestamp"]), true);
								$_var_12 = C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->fetch_all_by_search(array("spiderid" => $_var_8["id"], "status" => "0"), array("id" => "ASC"), 1);
							}
							$_var_17 = $_var_17 + 1;
							if (empty($_var_12) && $_var_17 < 5) {
								goto Label_17468;
							}
							$_var_2 = $_var_2 . ("-x" . $_var_17);
							if (!empty($_var_12)) {
								$_var_18 = array();
								foreach ($_var_12 as $_var_13) {
									$_var_2 = $_var_2 . ("." . $_var_13["id"]);
									$_var_18[] = $_var_13["id"];
								}
								C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(DB::field("id", $_var_18), array("status" => -1, "errlog" => "&#x53D1;&#x5E03;&#x4E2D;", "updatetime" => $_G["timestamp"]), true);
								$_var_3 = array();
								$_var_7 = new addon_collect_toutiao_rule();
								foreach ($_var_12 as $_var_13) {
									$_var_19 = "DZS_AUTOPOST_TOUTIAO_" . $_var_13["id"];
									if (!discuz_process::islocked($_var_19, 15)) {
										if (!$_var_3[$_var_13["spiderid"]]) {
											$_var_3[$_var_13["spiderid"]] = C::t("#addon_collect_toutiao#addon_collect_toutiao_spider")->fetch_by_search(array("id" => $_var_13["spiderid"]));
											$_var_3[$_var_13["spiderid"]]["configs_arr"] = !empty($_var_3[$_var_13["spiderid"]]["configs"]) ? dunserialize($_var_3[$_var_13["spiderid"]]["configs"]) : array();
											if (!is_array($_var_3[$_var_13["spiderid"]]["configs_arr"])) {
												$_var_3[$_var_13["spiderid"]]["configs_arr"] = array();
											}
										}
										$_var_8 = $_var_3[$_var_13["spiderid"]];
										$_var_13["configs"] = $_var_8["configs_arr"];
										$_var_20 = $_var_7->spider($_var_13);
										if ($_var_20["censor"]) {
											C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_13["id"]), array("status" => -1, "errlog" => "&#x542B;&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;", "updatetime" => $_G["timestamp"]), true);
										} else {
											if (empty($_var_20["subject"])) {
												C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_13["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x540D;&#x79F0;", "updatetime" => $_G["timestamp"]), true);
											} else {
												if (empty($_var_20["message"])) {
													if ($_var_1["optimize_fcj"] && $_var_20["fcj"]) {
														C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_13["id"]), array("status" => 0, "errlog" => "FCJ", "updatetime" => $_G["timestamp"]), true);
													} else {
														if ($_var_20["404"]) {
															C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_13["id"]), array("status" => -1, "errlog" => "404", "updatetime" => $_G["timestamp"]), true);
														} else {
															C::t("#addon_collect_toutiao#addon_collect_toutiao_articlelist")->update_by_where(array("id" => $_var_13["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;", "updatetime" => $_G["timestamp"]), true);
														}
													}
												} else {
													$_var_10 = array("url" => $_var_20["url"], "subject" => $_var_20["subject"], "message" => $_var_20["message"], "comments" => $_var_20["comments"], "updatetime" => $_G["timestamp"]);
													$_var_21 = addon_collect_toutiao_rule_getuser("post", $_var_13);
													$_var_10["articleid"] = $_var_13["id"];
													$_var_10["uid"] = $_var_21["uid"];
													$_var_10["username"] = $_var_21["username"];
													$_var_10["posttype"] = $_var_8["posttype"];
													$_var_10["catid"] = $_var_8["catid"];
													$_var_10["typeid"] = $_var_8["typeid"];
													$_var_10["configs"] = $_var_8["configs_arr"];
													$_var_7->post($_var_10);
												}
											}
										}
										discuz_process::unlock($_var_19);
									}
								}
							}
						} else {
							$_var_2 = $_var_2 . ("-noposttime");
						}
					} else {
						$_var_2 = $_var_2 . "-fcj";
					}
				}
			} else {
				$_var_2 = $_var_2 . ("sleep " . $_var_1["autopost_jiange"]);
			}
		}
		echo $_G["adminid"] ? "//ok" : "//&#x672C;&#x9875;&#x9762;&#x7531;&#x3010;&#x4ECA;&#x65E5;&#x5934;&#x6761;&#x81EA;&#x52A8;&#x91C7;&#x96C6;&#x3011;&#x63D2;&#x4EF6;&#x9A71;&#x52A8;, &#x4E0B;&#x8F7D;&#x5730;&#x5740;&#xFF1A;<a href=\"http://dism.Taobao.com/?@addon_collect_toutiao.plugin\" target=\"_blank\">http://dism.Taobao.com/?@addon_collect_toutiao.plugin</a>";
		if ($_var_1["debug"] || $_GET["debug"]) {
			echo "//<br>" . $_var_2;
		}
		if ($_GET["auto"]) {
			$_var_22 = file_get_contents(DISCUZ_ROOT . "./source/plugin/addon_collect_toutiao/demo.php");
			if (preg_match("#statInfo\\['ClientUrl'\\] = '([^']+)';#i", $_var_22, $_var_23)) {
				if ($_var_23[1] == "{ADDONVAR:ClientUrl}") {
					$_var_23[1] = $_G["siteurl"];
				}
				$_var_1["autopost_jiange"] = $_var_1["autopost_jiange"] + 1;
				$_var_24 = max(1, $_G["timestamp"] - $_GET["t"]);
				if ($_var_24 < $_var_1["autopost_jiange"]) {
					$_var_1["autopost_jiange"] = $_var_1["autopost_jiange"] - $_var_24;
				} else {
					$_var_1["autopost_jiange"] = 1;
				}
				$_var_25 = parse_url($_G["siteurl"]);
				echo "&nbsp;&nbsp;" . $_var_25["host"] . "&nbsp;<b id=\"time\">" . $_var_1["autopost_jiange"] . "</b> &#x79D2; &#x8DF3;&#x8F6C;<br>";
				echo "<script language=\"javascript\">\r\n\t\t\t\tfunction refresh(){\r\n\t\t\t\t\twindow.location.href=\"" . $_var_23[1] . "plugin.php?id=addon_collect_toutiao:autopost&auto=1&t=" . $_G["timestamp"] . "\";\r\n\t\t\t\t}\r\n\t\t\t\tsetInterval(\"refresh()\", " . $_var_1["autopost_jiange"] * 1000 . ");\r\n\t\t\t\tvar t = document.getElementById(\"time\");\r\n\t\t\t\tfunction settime(obj) {\r\n\t\t\t\t    if (obj.innerHTML > 1) {\r\n\t\t\t\t        obj.innerHTML = parseInt(obj.innerHTML) - 1;\r\n\t\t\t\t\t\t\t\tsetTimeout(function() { settime(obj) }, 1000);\r\n\t\t\t\t    }\r\n\t\t\t\t}\r\n\t\t\t\tsettime(t);\r\n\t\t\t\t</script>";
			}
		}
	}