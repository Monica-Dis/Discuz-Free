<?php

function addon_seo_mobilerewrite_shutdown()
{
	global $_G;
	$_G["addon_seo_mobilerewrite_shutdown"] = 1;
	addon_seo_mobilerewrite();
}
function addon_seo_mobilerewrite()
{
	global $_G;
	$_var_1 = implode('', $_G["setting"]["domain"]["app"]);
	if ($_G["setting"]["rewritestatus"] || !empty($_var_1)) {
		if (defined("ADDON_DISCUZ_OUTPUTED")) {
			return NULL;
		}
		if (IN_MOBILE == 2) {
			define("ADDON_DISCUZ_OUTPUTED", 1);
			if (!empty($_G["blockupdate"])) {
				block_updatecache($_G["blockupdate"]["bid"]);
			}
			if (!defined("TPL_DEFAULT")) {
				$_var_2 = ob_get_contents();
				if (!$_G["addon_seo_mobilerewrite_shutdown"] || strpos($_var_2, "</html>") !== false) {
					ob_end_clean();
					$_var_2 = str_replace("&\" class=\"z\">", "\" class=\"z\">", $_var_2);
					$_var_2 = str_replace("&amp;mobile=2\"", "\"", $_var_2);
					if (is_array($_G["setting"]["domain"]["app"]) && $_G["setting"]["domain"]["app"]["mobile"]) {
						$_var_3 = empty($_G["setting"]["domain"]["app"]["default"]) ? "{CURHOST}" : $_G["setting"]["domain"]["app"]["default"];
						$_var_4 = $_G["setting"]["domain"]["app"];
						$_var_5 = $_var_4["portal"] || $_var_4["forum"] || $_var_4["group"] || $_var_4["home"] || $_var_4["default"];
						$_var_6 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_var_4["mobile"] . "/";
						foreach ($_var_4 as $_var_7 => $_var_8) {
							if (!in_array($_var_7, array("default", "mobile"))) {
								if (!$_var_8) {
									$_var_8 = $_var_3;
								}
								if ($_var_8 != "{CURHOST}") {
									$_var_8 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_var_8 . $_G["siteport"] . "/";
								}
								$_G["setting"]["output"]["str"]["search"][$_var_7] = str_replace($_var_8, $_var_6, $_G["setting"]["output"]["str"]["search"][$_var_7]);
								$_G["setting"]["output"]["str"]["replace"][$_var_7] = str_replace($_var_8, $_var_6, $_G["setting"]["output"]["str"]["replace"][$_var_7]);
							}
						}
						foreach ($_G["setting"]["output"]["preg"]["search"] as $_var_9 => $_var_10) {
							$_G["setting"]["output"]["preg"]["search"][$_var_9] = preg_replace("/<a href\\\\=\"\\((https?[^\"]*\\/)\\)/", "<a href\\=\"(" . preg_quote($_var_6, "/") . ")", $_var_10);
						}
					}
					$_var_2 = output_replace($_var_2);
					ob_start();
					if (!defined("DISCUZ_OUTPUTED")) {
						$_var_2 = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" . $_var_2;
						define("DISCUZ_OUTPUTED", 1);
						if ("utf-8" != CHARSET) {
							$_var_2 = diconv($_var_2, CHARSET, "utf-8");
						}
					}
					if (IN_MOBILE === "3") {
						header("Content-type: text/vnd.wap.wml; charset=utf-8");
					} else {
						@header("Content-Type: text/html; charset=utf-8");
					}
					echo $_var_2;
					return 0;
				}
			} else {
				if (!defined("DISCUZ_OUTPUTED")) {
					define("DISCUZ_OUTPUTED", 1);
				}
				mobileoutput();
			}
		} else {
			output();
		}
	}
}
function addon_seo_mobilerewrite_rewriteoutput()
{
	global $_G;
	return "<a href=\"" . $_G["setting"]["domain"]["app"]["default"] . "\"";
}
function addon_seo_mobilerewrite_init()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_seo_mobilerewrite"];
	if ($_var_1["auto_radio"] && !defined("IN_ADDON_SEO_TAGS")) {
		if (!defined("STYLEID") || !defined("TEMPLATEID")) {
			include_once template("common/footer");
			ob_end_clean();
		}
		$_var_2 = IN_MOBILE == 2 ? "touch" : "mobile";
		loadcache(array("splugin_addon_seo_mobilerewrite"));
		$_var_3 = $_G["cache"]["splugin_addon_seo_mobilerewrite"];
		$_var_4 = STYLEID;
		$_var_5 = TEMPLATEID;
		$_var_6 = DISCUZ_ROOT . "data/template/" . $_var_4 . "_" . $_var_5 . "_" . $_var_2 . "_common_footer.tpl.php";
		if (file_exists($_var_6)) {
			$_var_7 = @filemtime($_var_6);
			if ($_var_7 > $_var_3[$_var_2 . "_cachetime"]["common_footer"]) {
				$_var_8 = file_get_contents($_var_6);
				if (!strpos($_var_8, "addon_seo_mobilerewrite")) {
					$_var_8 = str_replace("output();", "if(function_exists('addon_seo_mobilerewrite')){addon_seo_mobilerewrite();}else{output();}", $_var_8);
					file_put_contents($_var_6, $_var_8);
					clearstatcache();
					$_var_7 = @filemtime($_var_6);
				}
				$_var_3[$_var_2 . "_cachetime"]["common_footer"] = $_var_7;
				savecache("splugin_addon_seo_mobilerewrite", $_var_3);
			}
		}
		$_var_6 = DISCUZ_ROOT . "data/template/" . $_var_4 . "_" . $_var_5 . "_" . $_var_2 . "_common_header.tpl.php";
		if (file_exists($_var_6)) {
			$_var_7 = @filemtime($_var_6);
			if ($_var_7 > $_var_3[$_var_2 . "_cachetime"]["common_header"]) {
				$_var_8 = file_get_contents($_var_6);
				if (!strpos($_var_8, "<base href=")) {
					if ($_G["isHTTPS"]) {
						$_G["siteurl"] = str_replace("http://", "https://", $_G["siteurl"]);
					}
					$_var_8 = str_replace("</title>", "</title>\n<base href=\"" . $_G["siteurl"] . "\" />", $_var_8);
					file_put_contents($_var_6, $_var_8);
					clearstatcache();
					$_var_7 = @filemtime($_var_6);
				}
				$_var_3[$_var_2 . "_cachetime"]["common_header"] = $_var_7;
				savecache("splugin_addon_seo_mobilerewrite", $_var_3);
			}
		}
	}
}
function addon_seo_mobilerewrite_check()
{
}
function addon_seo_mobilerewrite_cleardir($_arg_0)
{
}
function addon_seo_mobilerewrite_deltree($_arg_0)
{
}
function addon_seo_mobilerewrite_validator()
{
	global $_G;
	if (!defined("DISCUZ_VERSION")) {
		include_once DISCUZ_ROOT . "./source/discuz_version.php";
	}
	$_var_1 = array();
	$_var_1["pluginName"] = "addon_seo_mobilerewrite";
	$_var_1["pluginVersion"] = $_G["setting"]["plugins"]["version"]["addon_seo_mobilerewrite"];
	$_var_1["bbsVersion"] = DISCUZ_VERSION;
	$_var_1["bbsRelease"] = DISCUZ_RELEASE;
	$_var_1["timestamp"] = TIMESTAMP;
	$_var_1["bbsUrl"] = $_G["siteurl"];
	$_var_1["bbsAdminEMail"] = $_G["setting"]["adminemail"];
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		if ($_GET["keymob_check"]) {
			addon_seo_mobilerewrite_check();
		}
		if (empty($_G["inajax"]) && empty($_POST)) {
			if ($_G["cache"]["plugin"]["addon_seo_mobilerewrite"]["addon_seo_rewrite"] && file_exists(DISCUZ_ROOT . "./source/plugin/addon_seo_rewrite/source/function/function_core.php")) {
				include_once libfile("function/core", "plugin/addon_seo_rewrite/source");
			}
			if ($_G["cache"]["plugin"]["addon_seo_mobilerewrite"]["study_rewrite_tag"] && file_exists(DISCUZ_ROOT . "./source/plugin/study_rewrite_tag/source/function/function_core.php")) {
				include_once libfile("function/core", "plugin/study_rewrite_tag/source");
			}
			if ($_G["cache"]["plugin"]["addon_seo_mobilerewrite"]["addon_sortrewrite"] && file_exists(DISCUZ_ROOT . "./source/plugin/addon_sortrewrite/source/function/function_core.php")) {
				include_once libfile("function/core", "plugin/addon_sortrewrite/source");
			}
			if ($_G["cache"]["plugin"]["addon_seo_mobilerewrite"]["addon_seo_portalrewrite"] && file_exists(DISCUZ_ROOT . "./source/plugin/addon_seo_portalrewrite/source/function/function_core.php")) {
				include_once libfile("function/core", "plugin/addon_seo_portalrewrite/source");
			}
			$_G["addon_seo_mobilerewrite_shutdown"] = 0;
			register_shutdown_function("addon_seo_mobilerewrite_shutdown");
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
	}