<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From dism.zzb7-net
 * Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=2
 * ���ο������ƣ�http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=22
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

function build_cache_plugin_addon_seo_mobilerewrite() {
	global $_G;
	$cachetime = array();
	savecache('splugin_addon_seo_mobilerewrite', $cachetime);
}