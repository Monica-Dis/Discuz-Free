<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function zzbuluo_shadowpost_output($_arg_0 = "post_bottom")
{
	global $_G;
	$_var_2 = '';
	$_var_3 = $_G["cache"]["plugin"]["zzbuluo_shadowpost"];
	$_var_4 = (array) unserialize($_var_3["study_fids"]);
	$_var_5 = (array) unserialize($_var_3["study_gids"]);
	if (in_array($_G["fid"], $_var_4) && in_array($_G["groupid"], $_var_5)) {
		if (!in_array($_arg_0, array("post_bottom", "post_bottom_mobile")) || getgpc("action") == "newthread" || getgpc("action") == "reply") {
			$_var_6 = zzbuluo_shadowpost_getuser();
			if ($_var_3["study_keep_radio"]) {
				$_var_7 = dintval(getcookie("zzbuluo_shadowpost_uid"));
				if ($_var_7 > 0) {
					if (!isset($_var_6[$_var_7])) {
						$_var_7 = 0;
					} else {
						$_var_3["study_def_radio"] = 0;
					}
				} else {
					if ($_var_7 == -1) {
						$_var_3["study_def_radio"] = 1;
					} else {
						if ($_var_7 == -2) {
							$_var_3["study_def_radio"] = 0;
						}
					}
				}
			}
			if (in_array($_arg_0, array("post_bottom"))) {
				$_var_2 = "<p class=\"mbn\"><span id=\"zzbuluo_shadowpost\" style=\"font-weight: 600;\"><label>" . lang("plugin/zzbuluo_shadowpost", "slang_001") . "<select name=\"zzbuluo_shadowpost_uid\"><option value=\"-2\">" . lang("plugin/zzbuluo_shadowpost", "slang_002") . "</option><option value=\"-1\" " . ($_var_3["study_def_radio"] ? "selected=\"selected\"" : '') . ">" . lang("plugin/zzbuluo_shadowpost", "slang_003") . "</option>";
			} else {
				if (in_array($_arg_0, array("fastpost"))) {
					$_var_2 = "<label class=\"lb\"><select name=\"zzbuluo_shadowpost_uid\" class=\"ps\" style=\"height: 26px;line-height: 26px;\"><option value=\"-2\">" . lang("plugin/zzbuluo_shadowpost", "slang_002") . "</option><option value=\"-1\" " . ($_var_3["study_def_radio"] ? "selected=\"selected\"" : '') . ">" . lang("plugin/zzbuluo_shadowpost", "slang_003") . "</option>";
				} else {
					if (in_array($_arg_0, array("viewthread_bottom_mobile"))) {
						$_var_2 = "<li id=\"zzbuluo_shadowpost\" style=\"padding: 7px 0;\"><select name=\"zzbuluo_shadowpost_uid\" class=\"ps\" style=\"height: 26px;line-height: 26px;\"><option value=\"-2\">" . lang("plugin/zzbuluo_shadowpost", "slang_002") . "</option><option value=\"-1\" " . ($_var_3["study_def_radio"] ? "selected=\"selected\"" : '') . ">" . lang("plugin/zzbuluo_shadowpost", "slang_003") . "</option>";
					} else {
						$_var_2 = "<label class=\"z\" style=\"padding-left: 10px;\"><select name=\"zzbuluo_shadowpost_uid\" class=\"ps\"><option value=\"-2\">" . lang("plugin/zzbuluo_shadowpost", "slang_002") . "</option><option value=\"-1\" " . ($_var_3["study_def_radio"] ? "selected=\"selected\"" : '') . ">" . lang("plugin/zzbuluo_shadowpost", "slang_003") . "</option>";
					}
				}
			}
			if (is_array($_var_6) && !empty($_var_6)) {
				foreach ($_var_6 as $_var_8) {
					$_var_2 = $_var_2 . ("<option value=\"" . $_var_8["uid"] . "\" " . ($_var_8["uid"] == $_var_7 ? "selected=\"selected\"" : '') . ">" . $_var_8["username"] . "</option>");
				}
			}
			if (in_array($_arg_0, array("post_bottom"))) {
				$_var_2 = $_var_2 . "</select></label></span></p>";
			} else {
				if (in_array($_arg_0, array("viewthread_bottom_mobile"))) {
					$_var_2 = $_var_2 . "</select></li>\r\n\t\t\t\t\t\t\t<script type=\"text/javascript\">\r\n\t\t\t\t\t\t\tvar vcurrent = document.getElementById(\"comiis_post_tab\");\r\n\t\t          var newNodeTop = document.getElementById(\"zzbuluo_shadowpost\");\r\n\t\t          vcurrent.parentNode.insertBefore(newNodeTop, vcurrent);\r\n\t\t          </script>";
				} else {
					$_var_2 = $_var_2 . "</select></label>";
				}
			}
		}
	}
	return $_var_2;
}
function zzbuluo_shadowpost_post()
{
	global $_G;
	if (submitcheck("topicsubmit") && getgpc("action") == "newthread" || submitcheck("replysubmit") && getgpc("action") == "reply") {
		if ($_POST["save"]) {
			return '';
		}
		$_var_1 = intval($_POST["zzbuluo_shadowpost_uid"]);
		if (empty($_var_1)) {
			return '';
		}
		$_var_2 = $_G["cache"]["plugin"]["zzbuluo_shadowpost"];
		$_var_3 = (array) unserialize($_var_2["study_fids"]);
		$_var_4 = (array) unserialize($_var_2["study_gids"]);
		if (!in_array($_G["fid"], $_var_3) || !in_array($_G["groupid"], $_var_4)) {
			return '';
		}
		dsetcookie("zzbuluo_shadowpost_uid", $_var_1, "864000");
		if ($_var_1 == -2) {
			return '';
		}
		$_var_5 = zzbuluo_shadowpost_getuser(1, $_var_1);
		if (!empty($_var_5)) {
			if ($_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_keep2_radio"]) {
				dsetcookie("zzbuluo_shadowpost_uid", $_var_5["uid"], "864000");
			}
			if (isset($_var_5["_inarchive"]) && $_var_5["_inarchive"]) {
				C::t("common_member_archive")->move_to_master($_var_5["uid"]);
			}
			$_G["tmpuser"] = array("uid" => $_G["uid"], "username" => $_G["username"], "formhash" => formhash());
			$_G["uid"] = $_var_5["uid"];
			$_G["username"] = $_var_5["username"];
			$_G["member"] = $_var_5;
			$_G["setting"]["floodctrl"] = 0;
			$_G["forum"]["ismoderator"] = 1;
			$_G["group"]["seccode"] = 0;
			$_G["setting"]["newbiespan"] = 0;
			$_G["setting"]["need_avatar"] = 0;
			$_G["setting"]["need_email"] = 0;
			$_G["setting"]["need_friendnum"] = 0;
			$_GET["formhash"] = $_POST["formhash"] = $_G["formhash"] = formhash();
		}
	}
}
function zzbuluo_shadowpost_post_message($_arg_0)
{
	global $_G;
	$_var_2 = $_arg_0["param"];
	$_var_3 = intval($_var_2[2]["fid"]);
	$_var_4 = intval($_var_2[2]["tid"]);
	$_var_5 = intval($_var_2[2]["pid"]);
	if ($_var_3 && $_var_4) {
		$_var_6 = array("post_newthread_succeed", "post_newthread_mod_succeed", "edit_newthread_mod_succeed", "post_edit_succeed", "post_reply_succeed", "post_reply_mod_succeed", "edit_reply_mod_succeed", "post_edit_delete_succeed");
		if (in_array($_var_2[0], $_var_6)) {
			if (isset($_G["tmpuser"]) && $_G["tmpuser"]["uid"] != $_G["uid"]) {
				DB::update("forum_attachment", array("uid" => $_G["uid"]), "pid = '" . $_var_5 . "'");
				DB::update("forum_attachment_" . getattachtableid($_var_4), array("uid" => $_G["uid"]), "pid = '" . $_var_5 . "'");
				if ($_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_lastvisit_radio"]) {
					C::t("common_member_status")->update($_G["uid"], array("lastvisit" => $_G["timestamp"], "lastactivity" => $_G["timestamp"], "lastpost" => $_G["timestamp"]), "UNBUFFERED");
				}
				$_var_7 = getuserbyuid($_G["tmpuser"]["uid"], 1);
				$_G["uid"] = $_var_7["uid"];
				$_G["username"] = $_var_7["username"];
				$_G["member"] = $_var_7;
				$_GET["formhash"] = $_POST["formhash"] = $_G["formhash"] = formhash();
			}
		}
	}
}
function zzbuluo_shadowpost_getuser($_arg_0 = 20, $_arg_1 = 0)
{
	global $_G;
	$_var_3 = $_var_4 = $_var_5 = array();
	$_var_6 = 0;
	$_var_7 = explode(",", $_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_top_uids"]);
	$_var_7 = dintval($_var_7, true);
	$_var_7 = array_filter($_var_7);
	if (!empty($_var_7)) {
		$_var_4 = DB::fetch_all("SELECT uid,username FROM %t WHERE %i " . DB::limit($_var_8, $_var_9), array("common_member", DB::field("uid", $_var_7)), "uid");
		if (getglobal("setting/membersplit") && count($_var_5) !== count($_var_7)) {
			$_var_4 = $_var_4 + DB::fetch_all("SELECT uid,username FROM %t WHERE %i " . DB::limit($_var_8, $_var_9), array("common_member_archive", DB::field("uid", $_var_7)), "uid");
		}
		foreach ($_var_7 as $_var_10) {
			if (!empty($_var_4[$_var_10])) {
				$_var_5[$_var_10] = $_var_4[$_var_10];
			}
		}
	}
	$_var_11 = str_replace("-", ",", $_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_uids"]);
	$_var_12 = explode(",", $_var_11);
	if (count($_var_12) == 2) {
		$_var_13 = intval($_var_12[0]) > 0 ? intval($_var_12[0]) : 1;
		$_var_14 = intval($_var_12[1]) > $_var_13 ? intval($_var_12[1]) : $_var_13;
		if ($_arg_1 > 0) {
			if (isset($_var_5[$_arg_1]) || $_arg_1 >= $_var_13 && $_arg_1 <= $_var_14) {
				$_var_3 = getuserbyuid($_arg_1, 1);
			}
		} else {
			if ($_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_keep_radio"]) {
				$_var_6 = dintval(getcookie("zzbuluo_shadowpost_uid"));
				if ($_var_6 < $_var_13 || $_var_6 > $_var_14) {
					$_var_6 = 0;
				}
			}
			$_var_15 = $_var_14 - $_var_13;
			$_var_9 = max(1, min($_var_15, $_arg_0));
			if ($_var_15 > $_arg_0) {
				$_var_8 = rand(0, $_var_15);
			} else {
				$_var_8 = 0;
			}
			if ($_arg_1 < 0) {
				$_var_3 = DB::fetch_first("SELECT * FROM %t WHERE `uid` >= %d AND `uid` <= %d " . DB::limit(1), array("common_member", $_var_13 + $_var_8, $_var_14), "uid");
				if (getglobal("setting/membersplit") && empty($_var_3)) {
					$_var_3 = DB::fetch_first("SELECT * FROM %t WHERE `uid` >= %d AND `uid` <= %d " . DB::limit(1), array("common_member_archive", $_var_13 + $_var_8, $_var_14), "uid");
				}
			} else {
				$_var_3 = DB::fetch_all("SELECT uid,username FROM %t WHERE `uid` >= %d AND `uid` <= %d " . DB::limit($_var_8, $_var_9), array("common_member", $_var_13, $_var_14), "uid");
				if (getglobal("setting/membersplit") && count($_var_3) !== $_var_9) {
					$_var_3 = $_var_3 + DB::fetch_all("SELECT uid,username FROM %t WHERE `uid` >= %d AND `uid` <= %d " . DB::limit($_var_8, $_var_9), array("common_member_archive", $_var_13, $_var_14), "uid");
				}
				if ($_var_6 > 0 && !isset($_var_3[$_var_6])) {
					$_var_16 = getuserbyuid($_var_6, 1);
					$_var_3[$_var_6] = $_var_16;
				}
			}
		}
	} else {
		if ($_arg_1 > 0) {
			if (isset($_var_5[$_arg_1]) || in_array($_arg_1, $_var_12)) {
				$_var_3 = getuserbyuid($_arg_1, 1);
			}
		} else {
			$_var_12 = dintval($_var_12, true);
			$_var_12 = array_filter($_var_12);
			if (!empty($_var_12)) {
				shuffle($_var_12);
				if ($_arg_0 > 0) {
					if ($_G["cache"]["plugin"]["zzbuluo_shadowpost"]["study_keep_radio"]) {
						$_var_6 = dintval(getcookie("zzbuluo_shadowpost_uid"));
						if (!in_array($_var_6, $_var_12)) {
							$_var_6 = 0;
						}
					}
					$_var_12 = array_slice($_var_12, 0, $_arg_0, false);
					if ($_arg_1 < 0) {
						$_var_3 = DB::fetch_first("SELECT * FROM %t WHERE %i " . DB::limit(1), array("common_member", DB::field("uid", $_var_12)), "uid");
						if (getglobal("setting/membersplit") && empty($_var_3)) {
							$_var_3 = $_var_3 + DB::fetch_first("SELECT * FROM %t WHERE %i " . DB::limit(1), array("common_member_archive", DB::field("uid", $_var_12)), "uid");
						}
					} else {
						$_var_3 = DB::fetch_all("SELECT uid,username FROM %t WHERE %i " . DB::limit($_arg_0), array("common_member", DB::field("uid", $_var_12)), "uid");
						if (getglobal("setting/membersplit") && count($_var_3) !== $_var_9) {
							$_var_3 = $_var_3 + DB::fetch_all("SELECT uid,username FROM %t WHERE %i " . DB::limit($_arg_0), array("common_member_archive", DB::field("uid", $_var_12)), "uid");
						}
						if ($_var_6 > 0 && !isset($_var_3[$_var_6])) {
							$_var_16 = getuserbyuid($_var_6, 1);
							$_var_3[$_var_6] = $_var_16;
						}
					}
				}
			}
		}
	}
	if ($_arg_1 == 0 && $_arg_0 > 1) {
		$_var_3 = $_var_5 + $_var_3;
	}
	return $_var_3;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}
	global $_G;