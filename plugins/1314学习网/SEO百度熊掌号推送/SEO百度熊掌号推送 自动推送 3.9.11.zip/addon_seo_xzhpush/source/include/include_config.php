<?php

function addon_seo_xzhpush_cleardir($_arg_0)
{
}
function addon_seo_xzhpush_deltree($_arg_0)
{
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$pluginvars = array();
	foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_9) {
		if (!strexists($_var_9["type"], "_")) {
			C::t("common_pluginvar")->update_by_variable($pluginid, $_var_9["variable"], array("type" => $_var_9["type"] . "_1314"));
		} else {
			$_var_10 = explode("_", $_var_9["type"]);
			if ($_var_10[1] == "1314") {
				$_var_9["type"] = $_var_10[0];
			} else {
				continue;
			}
		}
		$pluginvars[$_var_9["variable"]] = $_var_9;
	}
	require_once libfile("function/var", "plugin/addon_seo_xzhpush/source");
	if (!submitcheck("editsubmit")) {
		$_var_11 = '';
		if ($pluginvars) {
			showformheader("plugins&operation=config&do=" . $pluginid . '');
			showtableheader();
			echo "<div id=\"my_addonlist\"></div>";
			showtitle($lang["plugins_config"]);
			$_var_12 = array();
			foreach ($pluginvars as $_var_9) {
				if (!strexists($_var_9["type"], "_")) {
					if ($_var_9["variable"] == "forum_datetime") {
						showtablefooter();
						showtableheader("&#x5E16;&#x5B50;&#x63A8;&#x9001;");
					} else {
						if ($_var_9["variable"] == "token") {
							$_var_9["description"] = "&#x5BC6;&#x94A5;&#x83B7;&#x53D6;&#x5730;&#x5740;&#xFF1A;http://ziyuan.baidu.com/xzh/right/oriprotect?appid=" . $pluginvars["xzh_appid"]["value"];
						} else {
							if ($_var_9["variable"] == "site") {
								showtablefooter();
								showtableheader("&#x539F;&#x521B;&#x4FDD;&#x62A4;&#x529F;&#x80FD;");
								$_var_9["description"] = "&#x5982;&#xFF1A;http://www.d'.'i'.'szz.net/";
							} else {
								if ($_var_9["variable"] == "js_push") {
									showtablefooter();
									showtableheader("&#x9644;&#x52A0;&#x7684;&#x5C0F;&#x529F;&#x80FD; - JS&#x81EA;&#x52A8;&#x63A8;&#x9001;");
								}
							}
						}
					}
					$_var_9["variable"] = "varsnew[" . $_var_9["variable"] . "]";
					if ($_var_9["type"] == "number") {
						$_var_9["type"] = "text";
					} else {
						if ($_var_9["type"] == "select") {
							$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\">\n";
							foreach (explode("\n", $_var_9["extra"]) as $_var_13 => $_var_14) {
								$_var_14 = trim($_var_14);
								if (strpos($_var_14, "=") === false) {
									$_var_13 = $_var_14;
								} else {
									$_var_15 = explode("=", $_var_14);
									$_var_13 = trim($_var_15[0]);
									$_var_14 = trim($_var_15[1]);
								}
								$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . dhtmlspecialchars($_var_13) . "\" " . ($_var_9["value"] == $_var_13 ? "selected" : '') . ">" . $_var_14 . "</option>\n");
							}
							$_var_9["type"] = $_var_9["type"] . "</select>\n";
							$_var_9["variable"] = $_var_9["value"] = '';
						} else {
							if ($_var_9["type"] == "datetime") {
								$_var_9["type"] = "calendar";
								$_var_9["extra"] = 1;
								$_var_12["date"] = "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
							} else {
								if ($_var_9["type"] == "forums") {
									$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
									$_var_9["value"] = dunserialize($_var_9["value"]);
									$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array();
									require_once libfile("function/forumlist");
									$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\">" . cplang("plugins_empty") . "</option>" . forumselect(false, 0, 0, true) . "</select>";
									foreach ($_var_9["value"] as $_var_16) {
										$_var_9["type"] = str_replace("<option value=\"" . $_var_16 . "\">", "<option value=\"" . $_var_16 . "\" selected>", $_var_9["type"]);
									}
									$_var_9["variable"] = $_var_9["value"] = '';
								} else {
									if (substr($_var_9["type"], 0, 5) == "group") {
										if ($_var_9["type"] == "groups") {
											$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
											$_var_9["value"] = dunserialize($_var_9["value"]);
											$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\"" . (@in_array('', $_var_9["value"]) ? " selected" : '') . ">" . cplang("plugins_empty") . "</option>";
										} else {
											$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\"><option value=\"\">" . cplang("plugins_empty") . "</option>";
										}
										$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array($_var_9["value"]);
										$_var_17 = C::t("common_usergroup")->range_orderby_credit();
										$_var_18 = array();
										foreach ($_var_17 as $_var_19) {
											$_var_19["type"] = $_var_19["type"] == "special" && $_var_19["radminid"] ? "specialadmin" : $_var_19["type"];
											$_var_18[$_var_19["type"]] = $_var_18[$_var_19["type"]] . ("<option value=\"" . $_var_19["groupid"] . "\"" . (@in_array($_var_19["groupid"], $_var_9["value"]) ? " selected" : '') . ">" . $_var_19["grouptitle"] . "</option>");
										}
										$_var_9["type"] = $_var_9["type"] . ("<optgroup label=\"" . $lang["usergroups_member"] . "\">" . $_var_18["member"] . "</optgroup>" . ($_var_18["special"] ? "<optgroup label=\"" . $lang["usergroups_special"] . "\">" . $_var_18["special"] . "</optgroup>" : '') . ($_var_18["specialadmin"] ? "<optgroup label=\"" . $lang["usergroups_specialadmin"] . "\">" . $_var_18["specialadmin"] . "</optgroup>" : '') . "<optgroup label=\"" . $lang["usergroups_system"] . "\">" . $_var_18["system"] . "</optgroup></select>");
										$_var_9["variable"] = $_var_9["value"] = '';
									}
								}
							}
						}
					}
					s_showsetting(isset($lang[$_var_9["title"]]) ? $lang[$_var_9["title"]] : dhtmlspecialchars($_var_9["title"]), $_var_9["variable"], $_var_9["value"], $_var_9["type"], '', 0, isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : nl2br(dhtmlspecialchars($_var_9["description"])), dhtmlspecialchars($_var_9["extra"]), '', true);
				}
			}
			showsubmit("editsubmit");
			showtablefooter();
			showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
			echo implode('', $_var_12);
			$_var_20 = array();
			$_var_20["pluginName"] = $plugin["identifier"];
			$_var_20["pluginVersion"] = $plugin["version"];
			$_var_20["bbsVersion"] = DISCUZ_VERSION;
			$_var_20["bbsRelease"] = DISCUZ_RELEASE;
			$_var_20["timestamp"] = TIMESTAMP;
			$_var_20["bbsUrl"] = $_G["siteurl"];
			$_var_20["SiteUrl"] = $_statInfo["SiteUrl"];
			$_var_20["ClientUrl"] = $_statInfo["ClientUrl"];
			$_var_20["SiteID"] = $_statInfo["SiteID"];
			$_var_20["bbsAdminEMail"] = $_G["setting"]["adminemail"];
			$_var_20["genuine"] = splugin_genuine($plugin["identifier"]);
			echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"></div>\r\n\t\t";
		}
	} else {
		if (is_array($_GET["varsnew"])) {
			foreach ($_GET["varsnew"] as $_var_21 => $_var_22) {
				if (isset($pluginvars[$_var_21])) {
					if ($pluginvars[$_var_21]["type"] == "number") {
						$_var_22 = (double) $_var_22;
					} else {
						if (in_array($pluginvars[$_var_21]["type"], array("forums", "groups", "selects"))) {
							$_var_22 = serialize($_var_22);
						}
					}
					$_var_22 = (string) $_var_22;
					C::t("common_pluginvar")->update_by_variable($pluginid, $_var_21, array("value" => $_var_22));
				}
			}
		}
		updatecache(array("plugin", "setting", "styles"));
		cleartemplatecache();
		cpmsg("plugins_setting_succeed", "action=plugins&operation=config&do=" . $pluginid . "&anchor=" . $_var_23, "succeed");
	}