<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $ac;
	global $op;
	$op = in_array($_GET["op"], array("list", "check", "thread", "succeed", "fail")) ? $_GET["op"] : "list";
	addon_seo_xzhpush_admin::subtitle(array(array("&#x5168;&#x90E8;", "list"), array("&#x6210;&#x529F;", "succeed"), array("&#x5931;&#x8D25;", "fail"), array("&#x672A;&#x63A8;&#x9001;&#x7684;&#x5E16;&#x5B50;", "thread")), $type1314, $op);
	$_var_11 = 0;
	if (empty($_GET["formhash"])) {
		loadcache(array("saddon_seo_xzhpush"));
		$_var_12 = $_G["cache"]["saddon_seo_xzhpush"];
		$_var_11 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->count_by_where();
		$_var_13 = $_var_13 . ("&#x7D2F;&#x8BA1;&#x5DF2;&#x63A8;&#x9001; <b style=\"color:red\">" . $_var_12["count"] . "</b> &#x6761;");
		showtips("<li>" . $_var_13 . "</li>");
	}
	if ($op != "check") {
		if ($op == "thread") {
			require_once libfile("function/core", "plugin/addon_seo_xzhpush/source");
			if (!submitcheck("formhash")) {
				s_shownav("sort", "sorts_admin");
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
				showtableheader('');
				showsubtitle(array("&#x63A8;&#x9001;", "&#x6807;&#x9898;", "&#x94FE;&#x63A5;", "&#x65F6;&#x95F4;"));
				$_var_14 = array("1" => "&#x5E16;&#x5B50;", "2" => "&#x6587;&#x7AE0;", "3" => "&#x624B;&#x52A8;");
				$_var_15 = 20;
				$_var_16 = 1000;
				$_var_11 = DB::result_first("SELECT COUNT(*) FROM " . DB::table("forum_thread") . " WHERE displayorder>=0 AND linksubmit = 0");
				$_var_17 = intval($_GET["page"]);
				$_var_17 = $_var_17 - 1 > $_var_11 / $_var_15 || $_var_17 > $_var_16 ? 1 : $_var_17;
				$_var_18 = ($_var_17 - 1) * $_var_15;
				$_var_19 = multi($_var_11, $_var_15, $_var_17, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op, $_var_16);
				$_var_20 = DB::fetch_all("SELECT * FROM " . DB::table("forum_thread") . " WHERE displayorder >= 0 AND linksubmit = 0 ORDER BY tid DESC " . DB::limit($_var_18, $_var_15));
				$_var_20 = dhtmlspecialchars($_var_20);
				foreach ($_var_20 as $_var_21) {
					showtablerow('', array("class=\"td25\"", "class=\"td28\"", "class=\"td28\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_21["tid"] . "\" " . $_var_22 . ">", $_var_21["subject"], addon_seo_xzhpush_dealurl($_var_21), dgmdate($_var_21["dateline"], "Y-m-d H:i", $_G["setting"]["timeoffset"])));
				}
				showsubmit("submit", "&#x63D0;&#x4EA4;&#x63A8;&#x9001;", "select_all", "&#x662F;&#x5426;&#x539F;&#x521B;&#xFF1A;<label><input class=\"radio\" type=\"radio\" name=\"original\" value=\"1\">&nbsp;&#x662F;</label>&nbsp;&nbsp;<label><input class=\"radio\" type=\"radio\" name=\"original\" value=\"0\" checked=\"\">&nbsp;&#x5426;</label>", $_var_19);
				showtablefooter();
				showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
			} else {
				if (is_array($_POST["delete"])) {
					$_var_15 = 20;
					$_var_20 = DB::fetch_all("SELECT * FROM " . DB::table("forum_thread") . " WHERE " . DB::field("tid", $_POST["delete"]) . " AND linksubmit = 0 AND displayorder >= 0 ORDER BY tid DESC " . DB::limit(0, $_var_15));
					foreach ($_var_20 as $_var_21) {
						$_var_21["original"] = $_POST["original"] ? 1 : 0;
						$_var_21["manual"] = 1;
						addon_seo_xzhpush_baidu($_var_21);
					}
				}
				cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
			}
		} else {
			if (empty($_GET["formhash"]) || $_GET["formhash"] != $_G["formhash"]) {
				s_shownav("sort", "sorts_admin");
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
				showtableheader('');
				showsubtitle(array("del", "&#x6807;&#x9898;", "&#x94FE;&#x63A5;", "&#x7C7B;&#x578B;", "&#x63A8;&#x9001;&#x7C7B;&#x578B;", "&#x65F6;&#x95F4;", "&#x72B6;&#x6001;", "&#x63A8;&#x9001;&#x5931;&#x8D25;&#x539F;&#x56E0;"));
				$_var_14 = array("1" => "&#x5E16;&#x5B50;", "2" => "&#x6587;&#x7AE0;", "3" => "&#x624B;&#x52A8;");
				$_var_23 = array();
				if ($op == "succeed") {
					$_var_23 = array("success" => array("0", ">"));
				} else {
					if ($op == "fail") {
						$_var_23 = array("success" => 0);
					}
				}
				$_var_15 = 20;
				$_var_16 = 1000;
				if (in_array($op, array("succeed", "fail"))) {
					$_var_11 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->count_by_where($_var_23);
				}
				$_var_17 = intval($_GET["page"]);
				$_var_17 = $_var_17 - 1 > $_var_11 / $_var_15 || $_var_17 > $_var_16 ? 1 : $_var_17;
				$_var_18 = ($_var_17 - 1) * $_var_15;
				$_var_19 = multi($_var_11, $_var_15, $_var_17, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op, $_var_16);
				$_var_24 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_all_by_search($_var_23, array("id" => "DESC"), $_var_18, $_var_15);
				$_var_24 = dhtmlspecialchars($_var_24);
				foreach ($_var_24 as $_var_25) {
					showtablerow('', array("class=\"td25\"", "class=\"td28\"", "class=\"td28\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:200px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_25["id"] . "\" " . $_var_22 . ">", $_var_25["title"] ? $_var_25["title"] : $_var_25["url"], $_var_25["url"], $_var_14[$_var_25["posttype"]], $_var_25["original"] ? "<b style=\"color:green\">&#x539F;&#x521B;</b>" : "&#x975E;&#x539F;&#x521B;", dgmdate($_var_25["dateline"], "Y-m-d H:i", $_G["setting"]["timeoffset"]), $_var_25["success"] ? "<b style=\"color:green\">&#x6210;&#x529F;</b>" : "<b style=\"color:red\">&#x5931;&#x8D25;</b>", $_var_25["message"]));
				}
				if ($op == "fail") {
					showsubmit("submit", "submit", "del", "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&clear=all&submit=ok&formhash=" . FORMHASH . "\">&#x5220;&#x9664;&#x5168;&#x90E8;</a>", $_var_19);
				} else {
					showsubmit("submit", "submit", "del", '', $_var_19);
				}
				showtablefooter();
				showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
			} else {
				require_once libfile("function/core", "plugin/addon_seo_xzhpush/source");
				if ($_GET["clear"] && $op == "fail") {
					C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->delete_by_where(array("success" => 0), true);
				}
				if (is_array($_POST["delete"])) {
					foreach ($_POST["delete"] as $_var_26) {
						$_var_26 = intval($_var_26);
						C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->delete_by_where(array("id" => $_var_26), true);
					}
				}
				cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
			}
		}
	}