<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $ac;
	global $op;
	$_var_11 = array("realtime" => 2, "batch" => 3);
	$_var_12 = $type1314;
	$_var_13 = $_var_11[$type1314];
	$op = in_array($_GET["op"], array("list", "succeed", "fail")) ? $_GET["op"] : "list";
	addon_seo_xzhpush_admin::subtitle(array(array("&#x5168;&#x90E8;", "list"), array("&#x6210;&#x529F;", "succeed"), array("&#x5931;&#x8D25;", "fail")), $type1314, $op);
	if (!empty($_GET["formhash"]) && $_GET["formhash"] == $_G["formhash"] && $_GET["clear_remain_cache"]) {
		savecache("saddon_seo_xzhpush", array());
		cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
	}
	$_var_14 = 0;
	if (empty($_GET["formhash"])) {
		loadcache(array("saddon_seo_xzhpush"));
		$_var_15 = $_G["cache"]["saddon_seo_xzhpush"];
		$_var_14 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->count_by_where(array("type" => $_var_13));
		if (!isset($_var_15["success_" . $_var_12]) || $_var_15["success_" . $_var_12] < $_var_14) {
			$_var_15["success_" . $_var_12] = $_var_14;
			savecache("saddon_seo_xzhpush", $_var_15);
		}
		$_var_16 = $_var_16 . ("&#x7D2F;&#x8BA1;&#x5DF2;&#x63A8;&#x9001; <b style=\"color:red\">" . intval($_var_15["success_" . $_var_12]) . "</b> &#x6761;");
		$_var_17 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->count_by_where(array("type" => $_var_13, "success" => 0));
		$_var_16 = $_var_16 . ("&#xFF0C;&#x5931;&#x8D25; <b style=\"color:red\">" . $_var_17 . "</b> &#x6761;");
		$_var_18 = strtotime(dgmdate(TIMESTAMP, "Y-m-d", $_G["setting"]["timeoffset"]));
		if ($_var_15["todaytime_" . $_var_12] < $_var_18) {
			$_var_16 = $_var_16 . ("&#xFF0C;&#x4ECA;&#x65E5;&#x8FD8;&#x672A;&#x63A8;&#x9001;&#x4EFB;&#x4F55;&#x4FE1;&#x606F;");
		} else {
			$_var_16 = $_var_16 . ("&#xFF0C;&#x4ECA;&#x65E5;&#x5269;&#x4F59;&#x53EF;&#x63A8;&#x9001;&#x6761;&#x6570;&#xFF1A;<b style=\"color:red\">" . $_var_15["remain_" . $_var_12] . "</b> " . (empty($_var_15["remain_" . $_var_12]) ? "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&clear_remain_cache=1&formhash=" . FORMHASH . "\">(&#x5982;&#x679C;&#x5269;&#x4F59;&#x53EF;&#x63A8;&#x9001;&#x6570;&#x9519;&#x8BEF;&#xFF0C;&#x70B9;&#x51FB;&#x6E05;&#x7406;&#x7F13;&#x5B58;)</a>" : ''));
		}
		showtips("<li>" . $_var_16 . "</li>", "tips", true, "&#x6280;&#x5DE7;&#x63D0;&#x793A; - " . dgmdate($_G["timestamp"], "Y-m-d H:i:s", $_G["setting"]["timeoffset"]));
	}
	if (empty($_GET["formhash"]) || $_GET["formhash"] != $_G["formhash"]) {
		s_shownav("sort", "sorts_admin");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
		showtableheader('');
		showsubtitle(array("del", "&#x6807;&#x9898;", "&#x94FE;&#x63A5;", "&#x7C7B;&#x578B;", "&#x65F6;&#x95F4;", "&#x72B6;&#x6001;", "&#x63A8;&#x9001;&#x5931;&#x8D25;&#x539F;&#x56E0;"));
		$_var_19 = array("1" => "&#x5E16;&#x5B50;", "2" => "&#x6587;&#x7AE0;", "3" => "&#x624B;&#x52A8;");
		$_var_20 = array("type" => $_var_13);
		if ($op == "succeed") {
			$_var_20["success"] = array("0", ">");
		} else {
			if ($op == "fail") {
				$_var_20["success"] = 0;
			}
		}
		$_var_21 = 20;
		$_var_22 = 1000;
		if (in_array($op, array("succeed", "fail"))) {
			$_var_14 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->count_by_where($_var_20);
		}
		$_var_23 = intval($_GET["page"]);
		$_var_23 = $_var_23 - 1 > $_var_14 / $_var_21 || $_var_23 > $_var_22 ? 1 : $_var_23;
		$_var_24 = ($_var_23 - 1) * $_var_21;
		$_var_25 = multi($_var_14, $_var_21, $_var_23, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op, $_var_22);
		$_var_26 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_all_by_search($_var_20, array("id" => "DESC"), $_var_24, $_var_21);
		$_var_26 = dhtmlspecialchars($_var_26);
		foreach ($_var_26 as $_var_27) {
			showtablerow('', array("class=\"td25\"", "class=\"td28\"", "class=\"td28\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:200px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_27["id"] . "\" " . $_var_28 . ">", "<a href=\"" . $_var_27["url"] . "\" target=\"_blank\">" . ($_var_27["title"] ? $_var_27["title"] : $_var_27["url"]) . "</a>", $_var_27["url"], $_var_19[$_var_27["posttype"]], dgmdate($_var_27["dateline"], "Y-m-d H:i", $_G["setting"]["timeoffset"]), $_var_27["success"] ? "<b style=\"color:green\">&#x6210;&#x529F;</b>" : "<b style=\"color:red\">&#x5931;&#x8D25;</b>", $_var_27["message"]));
		}
		if ($op == "fail") {
			showsubmit("submit", "submit", "del", "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&clear=all&submit=ok&formhash=" . FORMHASH . "\">&#x5220;&#x9664;&#x5168;&#x90E8;</a>", $_var_25);
		} else {
			showsubmit("submit", "submit", "del", '', $_var_25);
		}
		showtablefooter();
		showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
	} else {
		require_once libfile("function/core", "plugin/addon_seo_xzhpush/source");
		if ($_GET["clear"] && $op == "fail") {
			C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->delete_by_where(array("type" => $_var_13, "success" => 0), true);
		}
		if (is_array($_POST["delete"])) {
			foreach ($_POST["delete"] as $_var_29) {
				$_var_29 = intval($_var_29);
				C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->delete_by_where(array("id" => $_var_29), true);
			}
		}
		cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
	}