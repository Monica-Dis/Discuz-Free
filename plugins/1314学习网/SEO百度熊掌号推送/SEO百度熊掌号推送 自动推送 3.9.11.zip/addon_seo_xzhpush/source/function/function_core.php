<?php

function addon_seo_xzhpush_post_message($_arg_0)
{
	global $_G;
	if (!$_G["addon_seo_xzhpush"]["newthread_radio"]) {
		return NULL;
	}
	$_arg_0 = $_arg_0["param"];
	if (!in_array($_arg_0[0], array("post_newthread_succeed", "post_newthread_mod_succeed"))) {
		return NULL;
	}
	$_var_2 = intval($_arg_0[2]["tid"]);
	$_var_3 = intval($_arg_0[2]["fid"]);
	$_var_4 = intval($_arg_0[2]["pid"]);
	if (!$_var_2 || !$_var_4) {
		return NULL;
	}
	$_var_5 = unserialize($_G["addon_seo_xzhpush"]["study_fids"]);
	$_var_6 = unserialize($_G["addon_seo_xzhpush"]["study_gids"]);
	if (in_array($_G["fid"], $_var_5) && in_array($_G["groupid"], $_var_6)) {
		$_var_7 = DB::fetch_first("SELECT * FROM " . DB::table("forum_thread") . " WHERE tid='" . $_var_2 . "' ORDER BY tid DESC");
		if ($_var_7["displayorder"] >= 0) {
			$_var_8 = "DZS_XZHPUSH_TID" . $_var_2;
			if (!discuz_process::islocked($_var_8, 10)) {
				addon_seo_xzhpush_baidu(array("tid" => $_var_2, "fid" => $_var_3, "subject" => $_POST["subject"]));
				discuz_process::unlock($_var_8);
			}
		}
	}
}
function addon_seo_xzhpush_filter($_arg_0)
{
	global $_G;
	$_arg_0 = preg_replace(array("/\\&[a-z]+\\;/i", "/\\<script.*?\\<\\/script\\>/is", "/\\<ignore_js_op>.*?\\<\\/ignore_js_op\\>/is", "/<p class=\"hide\">.*?<\\/p>/is"), '', $_arg_0);
	$_arg_0 = strip_tags($_arg_0);
	$_arg_0 = preg_replace("/(\r|\n|\t|\\s)/is", '', $_arg_0);
	$_arg_0 = dhtmlspecialchars($_arg_0);
	return $_arg_0;
}
function addon_seo_xzhpush_viewthread_posttop()
{
	global $_G;
	global $postlist;
	global $canonical;
	$_var_3 = array();
	if ($_G["forum_thread"]["displayorder"] >= 0) {
		$_var_4 = array();
		$_var_4["canonical"] = $_G["siteurl"] . $canonical;
		$_var_4["title"] = addon_seo_xzhpush_filter($_G["thread"]["subject"]);
		if (isset($postlist[$_G["forum_firstpid"]])) {
			$_var_5 = $postlist[$_G["forum_firstpid"]];
		}
		$_var_6 = array();
		if (is_array($_var_5["attachments"]) && !empty($_var_5["attachments"])) {
			foreach ($_var_5["attachments"] as $_var_7) {
				if ($_var_7["isimage"] && count($_var_6) < 3) {
					$_var_6[] = "\"" . (preg_match("/^https?:\\/\\//i", $_var_7["url"]) ? '' : $_G["siteurl"]) . $_var_7["url"] . $_var_7["attachment"] . "\"";
				}
			}
		}
		if (count($_var_6) == 3) {
			$_var_4["images"] = implode(",", $_var_6);
		} else {
			$_var_4["images"] = isset($_var_6[0]) ? $_var_6[0] : '';
		}
		$_var_4["description"] = messagecutstr(addon_seo_xzhpush_filter($_var_5["message"]), 160, '');
		if (empty($_var_4["description"])) {
			$_var_4["description"] = $_var_4["title"];
		}
		$_var_4["pubDate"] = dgmdate($_G["thread"]["dateline"], "Y-m-d", $_G["setting"]["timeoffset"]) . "T" . dgmdate($_G["thread"]["dateline"], "H:i:s", $_G["setting"]["timeoffset"]);
		$_var_8 = array();
		$_var_9 = false;
		if ($_G["uid"] && $_G["thread"]["displayorder"] >= 0) {
			if ($_G["page"] == 1 && !$_G["inajax"]) {
				$_var_10 = unserialize($_G["addon_seo_xzhpush"]["admin_fids"]);
				$_var_11 = explode(",", $_G["addon_seo_xzhpush"]["admin_uids"]);
				if (in_array($_G["fid"], $_var_10) && in_array($_G["uid"], $_var_11)) {
					$_var_9 = true;
					$_var_8 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("postid" => $_G["tid"], "posttype" => 1));
				}
			}
		}
		if ($_G["addon_seo_xzhpush"]["oldpush_radio"] && $_G["thread"]["displayorder"] >= 0) {
			if (empty($_var_5)) {
				foreach ($postlist as $_var_12 => $_var_13) {
					if ($_var_13["first"]) {
						$_var_5 = $_var_13;
						break;
					}
				}
			}
			$_var_14 = unserialize($_G["addon_seo_xzhpush"]["study_fids"]);
			$_var_15 = unserialize($_G["addon_seo_xzhpush"]["study_gids"]);
			if (in_array($_var_5["fid"], $_var_14) && in_array($_var_5["groupid"], $_var_15)) {
				if (!$_var_9) {
					$_var_8 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("postid" => $_G["tid"], "posttype" => 1));
				}
				if (empty($_var_8)) {
					$_var_16 = $_G["timestamp"] - $_G["thread"]["dateline"] > $_G["addon_seo_xzhpush"]["oldpush_time"] ? "batch" : "realtime";
					if ($_var_16 == "batch" || $_G["addon_seo_xzhpush"]["newthread_radio"]) {
						$_var_17 = "DZS_XZHPUSH_TID" . $_G["tid"];
						if (!discuz_process::islocked($_var_17, 10)) {
							addon_seo_xzhpush_baidu(array("tid" => $_G["tid"], "fid" => $_G["fid"], "subject" => $_G["thread"]["subject"]), $_var_16);
							discuz_process::unlock($_var_17);
						}
						$_var_8 = array("tid" => $_G["tid"], "fid" => $_G["fid"], "subject" => $_G["thread"]["subject"]);
					}
				}
			}
		}
		$_var_3[0] = addon_seo_xzhpush_tmphook($_var_4, $_var_8, $_var_18, $_var_9);
		if (defined("IN_MOBILE") && $_G["addon_seo_xzhpush"]["focuson_select"] == 2) {
			$_var_3[0] = $_var_3[0] . ("<script src=\"//msite.baidu.com/sdk/c.js?appid=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "\"></script><div style=\"padding-left: 17px; padding-right: 17px;background-color: #fff;\"><script>cambrian.render('body')</script></div>");
		}
	}
	return $_var_3;
}
function addon_seo_xzhpush_explode($_arg_0)
{
	$_var_1 = array();
	$_arg_0 = explode("\n", str_replace("\\r\\n", "\\n", $_arg_0));
	foreach ($_arg_0 as $_var_2) {
		$_var_2 = trim($_var_2);
		$_var_1[] = $_var_2;
	}
	return $_var_1;
}
function addon_seo_xzhpush_check()
{
}
function addon_seo_xzhpush_cleardir($_arg_0)
{
}
function addon_seo_xzhpush_deltree($_arg_0)
{
}
function addon_seo_xzhpush_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	require_once libfile("function/post");
	global $_G;
	$_G["addon_seo_xzhpush"] = $_G["cache"]["plugin"]["addon_seo_xzhpush"];
	if (!defined("IN_ADMINCP")) {
		if ($_GET["download_check"]) {
			addon_seo_xzhpush_check();
		}
	}
	include_once libfile("function/core2", "plugin/addon_seo_xzhpush/source");
	include_once libfile("function/core3", "plugin/addon_seo_xzhpush/source");
	include_once libfile("function/core4", "plugin/addon_seo_xzhpush/source");
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			addon_seo_xzhpush_check();
		}
	}