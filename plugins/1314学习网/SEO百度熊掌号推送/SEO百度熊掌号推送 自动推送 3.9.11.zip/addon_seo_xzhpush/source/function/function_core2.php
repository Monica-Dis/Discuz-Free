<?php

function addon_seo_xzhpush_baidu($_arg_0, $_arg_1 = "realtime")
{
	global $_G;
	$_var_3 = 1;
	if (!isset($_G["cache"]["saddon_seo_xzhpush"])) {
		loadcache(array("saddon_seo_xzhpush"));
		if (empty($_G["cache"]["saddon_seo_xzhpush"]) || $_G["cache"]["saddon_seo_xzhpush"]["md5key"] != md5($_G["addon_seo_xzhpush"]["xzh_appid"] . $_G["addon_seo_xzhpush"]["xzh_token"])) {
			$_G["cache"]["saddon_seo_xzhpush"] = array();
		}
	}
	$_var_4 = array("original" => 1, "realtime" => 2, "batch" => 3);
	if ($_G["addon_seo_xzhpush"]["xzh_appid"] && $_G["addon_seo_xzhpush"]["xzh_token"]) {
		$_var_5 = $_G["cache"]["saddon_seo_xzhpush"];
		$_var_6 = strtotime(dgmdate(TIMESTAMP, "Y-m-d", $_G["setting"]["timeoffset"]));
		if ($_var_5["todaytime_" . $_arg_1] < $_var_6 || $_var_5["remain_" . $_arg_1] > 0 || !isset($_var_5["remain_" . $_arg_1])) {
			$_var_7 = array();
			if ($_arg_0["tid"]) {
				$_var_8 = addon_seo_xzhpush_dealurl($_arg_0);
				$_var_9 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("url" => $_var_8));
				if ($_var_9) {
					C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->update_by_where(array("id" => $_var_9["id"]), array("title" => $_arg_0["subject"], "posttype" => 1, "postid" => $_arg_0["tid"]), true);
					return -3;
				}
			} else {
				if ($_arg_0["aid"]) {
					$_var_8 = addon_seo_xzhpush_dealurl($_arg_0);
					$_var_9 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("url" => $_var_8));
					if ($_var_9) {
						C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->update_by_where(array("id" => $_var_9["id"]), array("title" => $_arg_0["title"], "posttype" => 2, "postid" => $_arg_0["aid"]), true);
						return -3;
					}
				} else {
					if ($_arg_0["url"]) {
						if (!is_array($_arg_0["url"])) {
							$_arg_0["url"] = addon_seo_xzhpush_explode($_arg_0["url"]);
						}
						$_var_10 = array();
						foreach ($_arg_0["url"] as $_var_11 => $_var_12) {
							$_var_9 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("url" => $_var_12));
							if (empty($_var_9)) {
								$_var_10[] = $_var_12;
							}
						}
						$_arg_0["url"] = $_var_10;
						$_var_8 = implode("\n", $_arg_0["url"]);
					}
				}
			}
			if (empty($_var_8)) {
				return 0;
			}
			if (in_array($_arg_1, array("realtime", "batch"))) {
				$_var_13 = "http://data.zz.baidu.com/urls?appid=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "&token=" . $_G["addon_seo_xzhpush"]["xzh_token"] . "&type=" . $_arg_1;
			} else {
				if ($_arg_1 == "original") {
					$_var_13 = "http://data.zz.baidu.com/urls?site=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "&token=" . $_G["addon_seo_xzhpush"]["xzh_token"] . "&type=realtime,original";
				} else {
					return 0;
				}
			}
			if (function_exists("curl_init") && function_exists("curl_exec")) {
				$_var_14 = curl_init();
				$_var_15 = array(CURLOPT_URL => $_var_13, CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => $_var_8, CURLOPT_HTTPHEADER => array("Content-Type: text/plain"));
				curl_setopt_array($_var_14, $_var_15);
				$_var_16 = curl_exec($_var_14);
				curl_close($_var_14);
			} else {
				if (defined("IN_ADMINCP")) {
					cpmsg("&#x670D;&#x52A1;&#x5668;&#x9700;&#x8981;&#x5F00;&#x542F;Curl");
				} else {
					return -4;
				}
			}
			$_var_7 = json_decode($_var_16, true);
			if ($_arg_0["tid"]) {
				$_var_17 = '';
				if (!empty($_var_7["error"])) {
					$_var_18 = 0;
					$_var_17 = "error " . $_var_7["error"] . ", message " . $_var_7["message"];
				} else {
					if (in_array($_var_8, $_var_7["not_same_site"])) {
						$_var_18 = 0;
						$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_001");
					} else {
						if (in_array($_var_8, $_var_7["not_valid"])) {
							$_var_18 = 0;
							$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_002");
						} else {
							if (isset($_var_7["remain_" . $_arg_1])) {
								$_var_18 = 1;
							} else {
								if (isset($_var_7["success_" . $_arg_1])) {
									$_var_18 = 1;
								} else {
									$_var_18 = 1;
								}
							}
						}
					}
				}
				$_var_19 = array("title" => $_arg_0["subject"], "url" => $_var_8, "postid" => $_arg_0["tid"], "posttype" => 1, "success" => $_var_18, "message" => $_var_17, "type" => $_var_4[$_arg_1], "dateline" => $_G["timestamp"]);
				C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->insert($_var_19, true);
			} else {
				if ($_arg_0["aid"]) {
					$_var_17 = '';
					if (!empty($_var_7["error"])) {
						$_var_18 = 0;
						$_var_17 = "error " . $_var_7["error"] . ", message " . $_var_7["message"];
					} else {
						if (in_array($_var_8, $_var_7["not_same_site"])) {
							$_var_18 = 0;
							$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_001");
						} else {
							if (in_array($_var_8, $_var_7["not_valid"])) {
								$_var_18 = 0;
								$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_002");
							} else {
								if (isset($_var_7["remain_" . $_arg_1])) {
									$_var_18 = 1;
								} else {
									if (isset($_var_7["success_" . $_arg_1])) {
										$_var_18 = 1;
									} else {
										$_var_18 = 1;
									}
								}
							}
						}
					}
					$_var_19 = array("title" => $_arg_0["title"], "url" => $_var_8, "postid" => $_arg_0["aid"], "posttype" => 2, "success" => $_var_18, "message" => $_var_17, "type" => $_var_4[$_arg_1], "dateline" => $_G["timestamp"]);
					C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->insert($_var_19, true);
				} else {
					if ($_arg_0["url"]) {
						$_arg_0["original"] = $_arg_0["original"] ? 1 : 0;
						foreach ($_arg_0["url"] as $_var_8) {
							$_var_17 = '';
							if (in_array($_var_8, $_var_7["not_same_site"])) {
								$_var_18 = 0;
								$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_001");
							} else {
								if (in_array($_var_8, $_var_7["not_valid"])) {
									$_var_18 = 0;
									$_var_17 = lang("plugin/addon_seo_xzhpush", "slang_002");
								} else {
									if (!empty($_var_7["error"])) {
										$_var_18 = 0;
										$_var_17 = "error " . $_var_7["error"] . ", message " . $_var_7["message"];
									} else {
										if (isset($_var_7["remain_" . $_arg_1])) {
											$_var_18 = 1;
										} else {
											if (isset($_var_7["success_" . $_arg_1])) {
												$_var_18 = 1;
											} else {
												$_var_18 = 1;
											}
										}
									}
								}
							}
							$_var_19 = array("title" => '', "url" => $_var_8, "postid" => $_arg_0["tid"], "posttype" => 3, "success" => $_var_18, "message" => $_var_17, "type" => $_var_4[$_arg_1], "dateline" => $_G["timestamp"]);
							C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->insert($_var_19, true);
						}
					}
				}
			}
			if (isset($_var_7["remain_" . $_arg_1])) {
				$_var_5["remain_" . $_arg_1] = $_var_7["remain_" . $_arg_1];
				$_var_5["success_" . $_arg_1] = $_var_7["success_" . $_arg_1];
				$_var_5["todaytime_" . $_arg_1] = $_var_6;
			}
			$_var_5["md5key"] = md5($_G["addon_seo_xzhpush"]["xzh_appid"] . $_G["addon_seo_xzhpush"]["xzh_token"]);
			savecache("saddon_seo_xzhpush", $_var_5);
		} else {
			$_var_3 = -1;
		}
	} else {
		$_var_3 = -2;
	}
	return $_var_3;
}
function addon_seo_xzhpush_portalcp_xzhpush()
{
	global $_G;
	global $op;
	global $article;
	$_var_3 = '';
	if ($_GET["ac"] == "article" && submitcheck("articlesubmit") && $_G["addon_seo_xzhpush"]["portal_radio"] && $_G["addon_seo_xzhpush"]["portal_auto_radio"]) {
		$_var_4 = $article["dateline"] ? $article["dateline"] : $article["timestamp"];
		if (!empty($article) && $_G["timestamp"] - $article["dateline"] < 600) {
			loadcache(array("saddon_seo_xzhpush"));
			$_var_5 = $_G["cache"]["saddon_seo_xzhpush"];
			$_var_6 = strtotime(dgmdate(TIMESTAMP, "Y-m-d", $_G["setting"]["timeoffset"]));
			if ($_var_5["todaytime"] < $_var_6 || $_var_5["remain_realtime"] > 0) {
				$_var_7 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("postid" => $article["aid"], "posttype" => 2));
				if (empty($_var_7)) {
					$_var_8 = "DZS_XZHPUSH_AID" . $article["aid"];
					if (!discuz_process::islocked($_var_8, 10)) {
						$article["subject"] = $article["title"];
						addon_seo_xzhpush_baidu($article);
						discuz_process::unlock($_var_8);
					}
				}
			}
		}
	}
	return $_var_3;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}