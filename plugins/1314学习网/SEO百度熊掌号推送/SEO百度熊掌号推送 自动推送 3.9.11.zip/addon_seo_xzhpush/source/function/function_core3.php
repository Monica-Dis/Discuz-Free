<?php

function addon_seo_xzhpush_dealurl($_arg_0)
{
	global $_G;
	$_var_2 = '';
	if ($_arg_0["tid"]) {
		$_var_2 = $_G["addon_seo_xzhpush"]["forum_viewthread"] ? $_G["addon_seo_xzhpush"]["forum_viewthread"] : $_G["setting"]["rewriterule"]["forum_viewthread"];
		$_var_2 = $_var_2 ? $_var_2 : "thread-{tid}-{page}-{prevpage}.html";
		$_var_3 = array("{tid}" => $_arg_0["tid"], "{fid}" => empty($_G["setting"]["forumkeys"][$_arg_0["fid"]]) ? $_arg_0["fid"] : $_G["setting"]["forumkeys"][$_arg_0["fid"]], "{page}" => 1, "{prevpage}" => 1);
	} else {
		if ($_arg_0["aid"]) {
			$_var_2 = $_G["addon_seo_xzhpush"]["portal_article"] ? $_G["addon_seo_xzhpush"]["portal_article"] : $_G["setting"]["rewriterule"]["portal_article"];
			$_var_2 = $_var_2 ? $_var_2 : "article-{id}-{page}.html";
			$_var_3 = array("{id}" => $_arg_0["aid"], "{catid}" => $_arg_0["catid"], "{page}" => 1);
		}
	}
	$_var_4 = $_G["addon_seo_xzhpush"]["siteurl"] ? $_G["addon_seo_xzhpush"]["siteurl"] : $_G["siteurl"];
	return $_var_4 . str_replace(array_keys($_var_3), $_var_3, $_var_2);
}
function addon_seo_xzhpush_header_mobile()
{
	global $_G;
	global $content;
	$_var_2 = '';
	if ($_G["addon_seo_xzhpush"]["focuson_select"] == 1) {
		$_var_2 = "<script src=\"//msite.baidu.com/sdk/c.js?appid=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "\"></script><div style=\"padding-left: 17px; padding-right: 17px;background-color: #fff;\"><script>cambrian.render('head')</script></div>";
	}
	if (CURSCRIPT == "portal" && CURMODULE == "view") {
		if (defined("IN_MOBILE") && $_G["addon_seo_xzhpush"]["focuson_select"] == 2) {
			$content["content"] = "<script src=\"//msite.baidu.com/sdk/c.js?appid=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "\"></script><div style=\"padding-left: 17px; padding-right: 17px;background-color: #fff;\"><script>cambrian.render('body')</script></div>" . $content["content"];
		}
	}
	return $_var_2;
}
function addon_seo_xzhpush_footer_mobile()
{
	global $_G;
	$_var_1 = '';
	if ($_G["addon_seo_xzhpush"]["focuson_select"] == 3) {
		$_var_1 = "<script src=\"//msite.baidu.com/sdk/c.js?appid=" . $_G["addon_seo_xzhpush"]["xzh_appid"] . "\"></script><script>cambrian.render('tail')</script>";
	}
	return $_var_1;
}
function addon_seo_xzhpush_view_article()
{
	global $_G;
	global $article;
	global $content;
	global $canonical;
	$_var_4 = '';
	if (!empty($article) && $_G["addon_seo_xzhpush"]["portal_radio"]) {
		$_var_5 = array();
		$canonical = "portal.php?mod=view&aid=" . $article["aid"];
		if (in_array("portal_article", $_G["setting"]["rewritestatus"])) {
			$canonical = rewriteoutput("portal_article", 1, '', $article["aid"], $_G["page"]);
		}
		$_G["setting"]["seohead"] = $_G["setting"]["seohead"] . ("<link href=\"" . $_G["siteurl"] . $canonical . "\" rel=\"canonical\" />");
		$_var_5["canonical"] = $_G["siteurl"] . $canonical;
		$_var_5["title"] = addon_seo_xzhpush_filter($article["title"]);
		$_var_6 = $_var_7[$_G["forum_firstpid"]];
		$_var_8 = array();
		preg_match_all("/\\<img.+src=('|\"|)?(.*)(\\1)([\\s].*)?\\/?\\>/ismU", $content["content"], $_var_9, PREG_SET_ORDER);
		if (is_array($_var_9) && !empty($_var_9)) {
			foreach ($_var_9 as $_var_10) {
				if (!empty($_var_10[2]) && count($_var_8) < 3) {
					$_var_8[] = "\"" . (preg_match("/^https?:\\/\\//i", $_var_10[2]) ? '' : $_G["siteurl"]) . $_var_10[2] . "\"";
				}
			}
		}
		if (count($_var_8) == 3) {
			$_var_5["images"] = implode(",", $_var_8);
		} else {
			$_var_5["images"] = isset($_var_8[0]) ? $_var_8[0] : '';
		}
		$_var_5["description"] = $article["summary"] ? $article["summary"] : cutstr(addon_seo_xzhpush_filter($content["content"]), 160, '');
		if (empty($_var_5["description"])) {
			$_var_5["description"] = $_var_5["title"];
		}
		$_var_5["pubDate"] = dgmdate($content["dateline"], "Y-m-d", $_G["setting"]["timeoffset"]) . "T" . dgmdate($content["dateline"], "H:i:s", $_G["setting"]["timeoffset"]);
		$_var_11 = array();
		$_var_12 = false;
		if ($_G["uid"]) {
			if ($_G["page"] == 1 && !$_G["inajax"]) {
				$_var_13 = explode(",", $_G["addon_seo_xzhpush"]["admin_uids"]);
				if (in_array($_G["uid"], $_var_13)) {
					$_var_12 = true;
					$_var_11 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("postid" => $article["aid"], "posttype" => 2));
				}
			}
		}
		if ($_G["addon_seo_xzhpush"]["oldpush_radio"] || $_G["addon_seo_xzhpush"]["portal_auto_radio"]) {
			if (!$_var_12) {
				$_var_11 = C::t("#addon_seo_xzhpush#addon_seo_xzhpush")->fetch_by_search(array("postid" => $article["aid"], "posttype" => 2));
			}
			if (empty($_var_11)) {
				$_var_14 = $_G["timestamp"] - $article["timestamp"] > $_G["addon_seo_xzhpush"]["oldpush_time"] ? "batch" : "realtime";
				if ($_G["addon_seo_xzhpush"]["oldpush_radio"] && $_var_14 == "batch" || $_G["addon_seo_xzhpush"]["portal_auto_radio"] && $_var_14 == "realtime") {
					$_var_11 = array("aid" => $article["aid"], "catid" => $article["catid"], "title" => $article["title"]);
					$_var_15 = "DZS_XZHPUSH_AID" . $article["aid"];
					if (!discuz_process::islocked($_var_15, 10)) {
						addon_seo_xzhpush_baidu($_var_11, $_var_14);
						discuz_process::unlock($_var_15);
					}
				}
			}
		}
		addon_seo_xzhpush_tmphook2($_var_5, $_var_11, $article, $_var_12);
	}
	return $_var_4;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}