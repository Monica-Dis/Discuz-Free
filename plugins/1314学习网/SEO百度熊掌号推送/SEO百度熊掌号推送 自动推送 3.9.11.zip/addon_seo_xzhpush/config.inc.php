<?php

/**
 * Copyright 2001-2099 DisM-Taobao.
 * This is NOT a freeware, use is subject to license terms
 * $Id: config.inc.php 4243 2019-12-04 17:00:01
 * Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM-Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=rewrite');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = 'http://127.0.0.1/';$_statInfo['ClientUrl'] = 'http://127.0.0.1/';$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
loadcache('plugin');//  dism-taobao_com
$splugin_setting = $_G['cache']['plugin']['addon_seo_xzhpush'];/*DISM_TAOBAO-COM*/
$splugin_lang = lang('plugin/addon_seo_xzhpush');
$type1314 = in_array($_GET['type1314'], array('config', 'icon', 'category', 'slide', 'rewrite', 'seo')) ? $_GET['type1314'] : 'config';
$splugin_setting['0'] = array('0' => '20160621192CzBa5zHaF', '1' => '79827','2' => '1503281236', '3' => 'http://127.0.0.1/', '4' => 'http://127.0.0.1/', '5' => '', '6' => '', '7' => '');
require_once libfile('include/config', 'plugin/addon_seo_xzhpush/source');

//Copyright 2001-2099 .DisM.TaoBao.
//This is NOT a freeware, use is subject to license terms
//$Id: config.inc.php 4705 2019-12-04 09:00:01
//Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM��Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��