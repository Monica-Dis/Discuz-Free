<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_nge_middle_order($_arg_0, $_arg_1)
{
	global $_G;
	global $lang;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	$_var_7 = $_var_8 = array();
	$_var_9 = array("middle_order" => array("2", "3", "4", "5", "6"), "right_order" => array("7", "8", "9", "10"), "bottom_avatar" => array("7", "8", "9", "10"));
	$_var_7[2] = $splugin_setting["newpost_title"] ? $splugin_setting["newpost_title"] : $splugin_lang["study_newpost_title"];
	$_var_7[3] = $splugin_setting["newreply_title"] ? $splugin_setting["newreply_title"] : $splugin_lang["study_newreply_title"];
	$_var_7[4] = $splugin_setting["recpost_title"] ? $splugin_setting["recpost_title"] : $splugin_lang["study_recpost_title"];
	$_var_7[5] = $splugin_setting["goodreply_title"] ? $splugin_setting["goodreply_title"] : $splugin_lang["study_goodreply_title"];
	$_var_7[6] = $splugin_setting["hotpost_title"] ? $splugin_setting["hotpost_title"] : $splugin_lang["study_hotpost_title"];
	$_var_7[7] = $splugin_setting["newmember_title"] ? $splugin_setting["newmember_title"] : $splugin_lang["study_newmember_title"];
	$_var_7[8] = $splugin_setting["posts_title"] ? $splugin_setting["posts_title"] : $splugin_lang["study_posts_title"];
	$_var_7[9] = $splugin_setting["online_title"] ? $splugin_setting["online_title"] : $splugin_lang["study_online_title"];
	$_var_7[10] = $splugin_setting["credits_title"] ? $splugin_setting["credits_title"] : $splugin_lang["study_credits_title"];
	$_var_10 = explode(",", $_arg_1["value"]);
	if (is_array($_var_10) && !empty($_var_10)) {
		foreach ($_var_10 as $_var_11) {
			if (in_array($_var_11, $_var_9[$_arg_0])) {
				$_var_8[$_var_11] = 1;
			}
		}
	}
	foreach ($_var_9[$_arg_0] as $_var_11) {
		if (!isset($_var_8[$_var_11])) {
			$_var_8[$_var_11] = 0;
		}
	}
	echo "\r\n\t<tr><td colspan=\"2\" class=\"td27\" s=\"1\">" . dhtmlspecialchars($_arg_1["title"]) . ":</td></tr>\r\n\t<tr class=\"noborder\"><td>";
	showtableheader('', '', "style=\"margin-top: 0px;\"");
	showsubtitle(array("&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x540D;&#x79F0;", "&#x72B6;&#x6001;", ''), "hover");
	$_var_12 = 1;
	foreach ($_var_8 as $_var_13 => $_var_11) {
		showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td25\"", "class=\"td25\""), array("<input type=\"text\" class=\"txt\" name=\"varsnew[" . $_arg_0 . "][order][" . $_var_13 . "]\" value=\"" . $_var_12 . "\" style=\"height: 20px;\">", $_var_7[$_var_13], "<input name=\"varsnew[" . $_arg_0 . "][status][" . $_var_13 . "]\" type=\"checkbox\" value=\"1\" " . ($_var_11 ? "checked=\"checked=\"" : '') . "/>"));
		$_var_12 = $_var_12 + 1;
	}
	showtablefooter();
	echo "</td><td class=\"vtop tips2\" s=\"1\">" . nl2br(dhtmlspecialchars($_arg_1["description"])) . "</td></tr>";
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}