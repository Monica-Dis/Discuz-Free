<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('https://DisM.Taobao.Com/');
}

$pluginvars = array();
foreach(C::t('common_pluginvar')->fetch_all_by_pluginid($pluginid) as $var) {
	if(!strexists($var['type'], '_')) {
		C::t('common_pluginvar')->update_by_variable($pluginid, $var['variable'], array('type' => $var['type'].'_1314'));
	}else{
		$type = explode('_', $var['type']);
		if($type[1] == '1314'){
			$var['type'] = $type[0];
		}else{
			continue;
		}
	}
	$pluginvars[$var['variable']] = $var;
}

if(!submitcheck('editsubmit')) {
    if ($pluginvars) {
    		$_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
				showformheader(STUDY_MANAGE_URL.'&type1314='.$type1314);
        showtableheader();
       	echo '<div id="my_addonlist"></div>';
				showtitle($lang['plugins_config']);
        $extra = array();
        $extra = s_showsettings($pluginvars, $pluginvars_array[$type1314]);
        showsubmit('editsubmit');
        showtablefooter();
        showformfooter();
        echo implode('', $extra);
        echo '<div id="my_addonlist_temp" style="display:none;"><script id="my_addonlist_js" src="//www.d'.'i'.'szz.net/services.php?mod=product&ac=js&op=manage&timestamp='.$_G['timestamp'].'&info='.base64_encode(serialize($_statInfo)).'&md5check='.md5(base64_encode(serialize($_statInfo))).'"></script></div>
				<script type="text/javascript">$("my_addonlist_js").src= "";$("my_addonlist").innerHTML = $("my_addonlist_temp").innerHTML;</script>';
    }
}else {
	// ���ǰ����
	$postdata = daddslashes(dstripslashes($_POST['varsnew']));
	
	asort($postdata['middle_order']['order']);
	asort($postdata['right_order']['order']);
	asort($postdata['bottom_avatar']['order']);
	
//	print_r($postdata);
//	exit;
	if (is_array($postdata)) {
		$dfv = array('middle_order' => array('2', '3', '4', '5', '6'), 'right_order' => array('7', '8', '9', '10'), 'bottom_avatar' => array('7', '8', '9', '10'));
    foreach ($postdata as $variable => $value) {
	    if(isset($pluginvars[$variable])) {
	    	if(in_array($variable, array('middle_order', 'right_order', 'bottom_avatar'))){
	    		$middle_order = array();
	    		if(is_array($value['order'])){
	    			foreach($value['order'] as $k => $v){
	    				if(!empty($value['status'][$k]) && in_array($k, $dfv[$variable])){
	    					$middle_order[] = (float)$k;
	    				}
	    			}
	    		}
					DB::query("UPDATE ".DB::table('common_pluginvar')." SET value='".implode(',', $middle_order)."' WHERE pluginid='$pluginid' AND variable='$variable'");
	    	}else{
					if($pluginvars[$variable]['type'] == 'number') {
						$value = (float)$value;
					} elseif(in_array($pluginvars[$variable]['type'], array('forums', 'groups', 'selects'))) {
						$value = addslashes(serialize($value));
					}
					DB::query("UPDATE ".DB::table('common_pluginvar')." SET value='$value' WHERE pluginid='$pluginid' AND variable='$variable'");
				}
			}
	  }
	}
	updatecache(array('plugin', 'setting', 'styles'));
	cpmsg('plugins_setting_succeed', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314, 'succeed');
}
