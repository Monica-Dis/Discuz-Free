<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_storage_qiniuoss_downpic($_arg_0)
{
	global $_G;
	$_var_2 = rawurlencode(diconv($_arg_0["filename"], CHARSET, "utf-8"));
	dheader("location: " . $_G["setting"]["ftp"]["attachurl"] . "forum/" . $_arg_0["attachment"] . "?attname=" . $_var_2);
}
function addon_storage_qiniuoss_signurl($_arg_0)
{
	global $_G;
	$_var_2 = rawurlencode(diconv($_arg_0["filename"], CHARSET, "utf-8"));
	$_var_3 = $_G["QiniuOss_Auth"]->privateDownloadUrl($_G["setting"]["ftp"]["attachurl2"] . "forum/" . $_arg_0["attachment"] . "?attname=" . $_var_2);
	dheader("location: " . $_var_3);
}
function addon_storage_qiniuoss_ftp_upload($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = 0;
	$_arg_0 = str_replace("//forum", "/forum", $_arg_0);
	$_var_4 = fileext($_arg_0);
	if (is_file($_arg_0) && $_var_4) {
		if (in_array($_var_4, array("jpg", "jpeg", "gif", "png", "bmp"))) {
			list($_var_5, $_var_6) = $_G["QiniuOss_UploadManager"]->putFile($_G["qiniuoss"]["token"], $_arg_1, $_arg_0);
		} else {
			list($_var_5, $_var_6) = $_G["QiniuOss_UploadManager"]->putFile($_G["qiniuoss"]["attach_token"], $_arg_1, $_arg_0);
		}
		if ($_var_6 === NULL) {
			$_var_3 = 1;
		}
	}
	return $_var_3;
}
function addon_storage_qiniuoss_ftp_size($_arg_0)
{
	global $_G;
	$_var_2 = fileext($_arg_0);
	if (in_array($_var_2, array("jpg", "jpeg", "gif", "png", "bmp"))) {
		$_var_3 = $_G["QiniuOss_BucketManager"]->stat($_G["qiniuoss"]["oss_bucket"], $_arg_0);
	} else {
		$_var_3 = $_G["QiniuOss_BucketManager"]->stat($_G["qiniuoss"]["oss_attach_bucket"], $_arg_0);
	}
	if (!empty($_var_3[0]) && !empty($_var_3[0]["fsize"])) {
		return 1314;
	}
	return 0;
}
function addon_storage_qiniuoss_ftp_delete($_arg_0)
{
	global $_G;
	$_var_2 = 0;
	$_var_3 = fileext($_arg_0);
	if (in_array($_var_3, array("jpg", "jpeg", "gif", "png", "bmp"))) {
		$_var_4 = $_G["QiniuOss_BucketManager"]->delete($_G["qiniuoss"]["oss_bucket"], $_arg_0);
	} else {
		$_var_4 = $_G["QiniuOss_BucketManager"]->delete($_G["qiniuoss"]["oss_attach_bucket"], $_arg_0);
	}
	if ($_var_4 === NULL) {
		$_var_2 = 1;
	}
	return $_var_2 ? 1 : 0;
}
function addon_storage_qiniuoss_forum_upload($_arg_0)
{
	global $_G;
	$_var_2 = 0;
	$_var_3 = fileext($_arg_0["attachment"]);
	$_var_4 = !$_G["setting"]["attachdir"] ? DISCUZ_ROOT . "./data/attachment/" : $_G["setting"]["attachdir"];
	if (file_exists($_var_4 . "/forum/" . $_arg_0["attachment"])) {
		if (in_array($_var_3, array("jpg", "jpeg", "gif", "png", "bmp"))) {
			list($_var_5, $_var_6) = $_G["QiniuOss_UploadManager"]->putFile($_G["qiniuoss"]["token"], "forum/" . $_arg_0["attachment"], $_var_4 . "/forum/" . $_arg_0["attachment"]);
		} else {
			list($_var_5, $_var_6) = $_G["QiniuOss_UploadManager"]->putFile($_G["qiniuoss"]["attach_token"], "forum/" . $_arg_0["attachment"], $_var_4 . "/forum/" . $_arg_0["attachment"]);
		}
		if ($_var_6 === NULL) {
			$_var_2 = 1;
		}
	}
	return $_var_2;
}
function addon_storage_qiniuoss_viewthread()
{
	global $_G;
	global $postlist;
	if ($_G["tid"] && empty($postlist[$_G["forum_firstpid"]]["tags"])) {
		$_var_2 = C::t("forum_post")->fetch_threadpost_by_tid_invisible($_G["tid"]);
		$_var_3 = $_var_2["subject"];
		$_var_4 = cutstr($_var_2["message"], 500, '');
		$_var_5 = $_var_2["pid"];
		$_var_6 = strip_tags(preg_replace("/\\[.+?\\]/U", '', $_var_3 . $_var_4));
		$_var_7 = addon_storage_qiniuoss_gettag($_var_6);
		if ($_var_7) {
			$_var_8 = addon_storage_qiniuoss_modthreadtag(implode(",", $_var_7), $_G["tid"]);
			$_var_9 = $_var_10 = array();
			$_var_9 = explode("\t", $_var_8);
			if ($_var_9) {
				foreach ($_var_9 as $_var_11) {
					if ($_var_11) {
						$_var_12 = explode(",", $_var_11);
						$_var_10[] = $_var_12;
					}
				}
			}
			$postlist[$_G["forum_firstpid"]]["tags"] = $_var_10;
		}
	}
}
function addon_storage_qiniuoss_modthreadtag($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	if ($_arg_0) {
		if (function_exists("modthreadtag")) {
			$_var_3 = modthreadtag($_arg_0, $_arg_1);
			$_var_4 = getposttablebytid($_arg_1);
			DB::query("UPDATE " . DB::table($_var_4) . " SET tags='" . $_var_3 . "'  WHERE tid='" . $_arg_1 . "' AND first = '1'");
			$_var_3 = str_replace("\\t", '', $_var_3);
		} else {
			if (class_exists("tag")) {
				C::t("common_tagitem")->delete(0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => ''), true);
				$_var_5 = new tag();
				$_var_3 = $_var_5->update_field($_arg_0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => $_var_3), true, false, 1);
			}
		}
	}
	return $_var_3;
}
function addon_storage_qiniuoss_check()
{
	$_var_0 = NULL;
}
function addon_storage_qiniuoss_cleardir($_arg_0)
{
}
function addon_storage_qiniuoss_deltree($_arg_0)
{
}
function addon_storage_qiniuoss_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}