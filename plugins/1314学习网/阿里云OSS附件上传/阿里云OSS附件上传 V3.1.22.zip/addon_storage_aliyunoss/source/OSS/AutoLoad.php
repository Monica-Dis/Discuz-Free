<?php

function addon_storage_aliyunoss_classLoader($_arg_0)
{
	if ($_arg_0 == "forum_upload") {
		require_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/include/forum_upload.php";
	} else {
		if ($_arg_0 == "discuz_ftp") {
			require_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/include/discuz_ftp.php";
		} else {
			$_var_1 = str_replace("\\", DIRECTORY_SEPARATOR, $_arg_0);
			$_var_2 = DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/" . $_var_1 . ".php";
			if (file_exists($_var_2)) {
				require_once $_var_2;
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	if (function_exists("spl_autoload_register")) {
		spl_autoload_register("addon_storage_aliyunoss_classLoader", false, true);
		if (!isset($_G["cache"]["plugin"]["addon_storage_aliyunoss"]) || empty($_G["cache"]["plugin"]["addon_storage_aliyunoss"])) {
			loadcache("plugin");
		}
		$_G["aliyunoss"] = $_G["cache"]["plugin"]["addon_storage_aliyunoss"];
		$_G["aliyunoss"]["public_read_exts"] = explode("|", strtolower($_G["aliyunoss"]["public_read_fileexts"]));
		if (!$_G["adminid"]) {
			$_G["aliyunoss"]["debug"] = 0;
		}
		$_G["setting"]["ftp"]["on"] = 1;
		$_G["setting"]["ftp"]["attachurl"] = $_G["aliyunoss"]["view_url"] . (substr($_G["aliyunoss"]["view_url"], -1) == "/" ? '' : "/");
	}