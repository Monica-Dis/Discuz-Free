<?php

function addon_storage_aliyunoss_signurl($_arg_0)
{
	global $_G;
	$_var_2 = $_G["setting"]["ftp"]["attachurl"] . "forum/" . $_arg_0["attachment"];
	$_var_3 = $_G["OssClient"]->getObjectMeta($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"]);
	if (!isset($_var_3["x-oss-filename-md5"]) || $_var_3["x-oss-filename-md5"] != md5($_arg_0["filename"])) {
		$_var_4 = rawurlencode(diconv($_arg_0["filename"], CHARSET, "utf-8"));
		$_var_5 = array("headers" => array("Content-Disposition" => "attachment; filename=\"" . $_var_4 . "\";filename*=utf-8''" . $_var_4 . '', "x-oss-filename-md5" => md5($_arg_0["filename"])));
		$_G["OssClient"]->copyObject($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"], $_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"], $_var_5);
	}
	$_var_6 = max($_G["aliyunoss"]["signurl_timeout"], 10);
	$_var_2 = $_G["OssClient"]->signUrl($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"], $_var_6);
	$_var_2 = str_replace("http://" . $_G["aliyunoss"]["oss_bucket"] . "." . $_G["aliyunoss"]["oss_endpoint"] . "/", $_G["setting"]["ftp"]["attachurl"], $_var_2);
	$_var_2 = str_replace("https://" . $_G["aliyunoss"]["oss_bucket"] . "." . $_G["aliyunoss"]["oss_endpoint"] . "/", $_G["setting"]["ftp"]["attachurl"], $_var_2);
	$_var_2 = str_replace("-internal.aliyuncs.com", ".aliyuncs.com", $_var_2);
	return $_var_2;
}
function addon_storage_aliyunoss_ftp_upload($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = 0;
	$_var_4 = fileext($_arg_0);
	if (is_file($_arg_0) && $_var_4) {
		$_G["OssClient"]->multiuploadFile($_G["aliyunoss"]["oss_bucket"], $_arg_1, $_arg_0);
		if ($_G["OssClient"]->doesObjectExist($_G["aliyunoss"]["oss_bucket"], $_arg_1)) {
			if (in_array($_var_4, array("jpg", "jpeg", "gif", "png", "bmp"))) {
				$_var_5 = "public-read";
			} else {
				if (!empty($_G["aliyunoss"]["public_read_exts"]) && in_array($_var_4, $_G["aliyunoss"]["public_read_exts"])) {
					$_var_5 = "public-read";
				} else {
					$_var_5 = "private";
				}
			}
			$_G["OssClient"]->putObjectAcl($_G["aliyunoss"]["oss_bucket"], $_arg_1, $_var_5);
			$_var_3 = 1;
		}
	}
	return $_var_3;
}
function addon_storage_aliyunoss_ftp_size($_arg_0)
{
	global $_G;
	if ($_G["OssClient"]->doesObjectExist($_G["aliyunoss"]["oss_bucket"], $_arg_0)) {
		return 1314;
	}
	return 0;
}
function addon_storage_aliyunoss_ftp_delete($_arg_0)
{
	global $_G;
	$_var_2 = 0;
	$_G["OssClient"]->deleteObject($_G["aliyunoss"]["oss_bucket"], $_arg_0);
	if (!$_G["OssClient"]->doesObjectExist($_G["aliyunoss"]["oss_bucket"], $_arg_0)) {
		$_var_2 = 1;
	}
	return $_var_2 ? 1 : 0;
}
function addon_storage_aliyunoss_forum_upload($_arg_0)
{
	global $_G;
	$_var_2 = 0;
	$_var_3 = !$_G["setting"]["attachdir"] ? DISCUZ_ROOT . "./data/attachment/" : $_G["setting"]["attachdir"];
	$_var_4 = fileext($_arg_0["attachment"]);
	if (file_exists($_var_3 . "/forum/" . $_arg_0["attachment"]) && $_var_4) {
		$_G["OssClient"]->multiuploadFile($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"], $_var_3 . "/forum/" . $_arg_0["attachment"]);
		if ($_G["OssClient"]->doesObjectExist($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"])) {
			if (in_array($_var_4, array("jpg", "jpeg", "gif", "png", "bmp"))) {
				$_var_5 = "public-read";
			} else {
				if (!empty($_G["aliyunoss"]["public_read_exts"]) && in_array($_var_4, $_G["aliyunoss"]["public_read_exts"])) {
					$_var_5 = "public-read";
				} else {
					$_var_5 = "private";
				}
			}
			$_G["OssClient"]->putObjectAcl($_G["aliyunoss"]["oss_bucket"], "forum/" . $_arg_0["attachment"], $_var_5);
			$_var_2 = 1;
		}
	}
	return $_var_2;
}
function addon_storage_aliyunoss_viewthread()
{
	global $_G;
	global $postlist;
	if ($_G["tid"] && empty($postlist[$_G["forum_firstpid"]]["tags"])) {
		$_var_2 = C::t("forum_post")->fetch_threadpost_by_tid_invisible($_G["tid"]);
		$_var_3 = $_var_2["subject"];
		$_var_4 = cutstr($_var_2["message"], 500, '');
		$_var_5 = $_var_2["pid"];
		$_var_6 = strip_tags(preg_replace("/\\[.+?\\]/U", '', $_var_3 . $_var_4));
		$_var_7 = addon_storage_aliyunoss_gettag($_var_6);
		if ($_var_7) {
			$_var_8 = addon_storage_aliyunoss_modthreadtag(implode(",", $_var_7), $_G["tid"]);
			$_var_9 = $_var_10 = array();
			$_var_9 = explode("\t", $_var_8);
			if ($_var_9) {
				foreach ($_var_9 as $_var_11) {
					if ($_var_11) {
						$_var_12 = explode(",", $_var_11);
						$_var_10[] = $_var_12;
					}
				}
			}
			$postlist[$_G["forum_firstpid"]]["tags"] = $_var_10;
		}
	}
}
function addon_storage_aliyunoss_modthreadtag($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	if ($_arg_0) {
		if (function_exists("modthreadtag")) {
			$_var_3 = modthreadtag($_arg_0, $_arg_1);
			$_var_4 = getposttablebytid($_arg_1);
			DB::query("UPDATE " . DB::table($_var_4) . " SET tags='" . $_var_3 . "'  WHERE tid='" . $_arg_1 . "' AND first = '1'");
			$_var_3 = str_replace("\\t", '', $_var_3);
		} else {
			if (class_exists("tag")) {
				C::t("common_tagitem")->delete(0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => ''), true);
				$_var_5 = new tag();
				$_var_3 = $_var_5->update_field($_arg_0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => $_var_3), true, false, 1);
			}
		}
	}
	return $_var_3;
}
function addon_storage_aliyunoss_check()
{
}
function addon_storage_aliyunoss_cleardir($_arg_0)
{
}
function addon_storage_aliyunoss_deltree($_arg_0)
{
}
function addon_storage_aliyunoss_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		if ($_GET["s_aliyunoss"]) {
			addon_storage_aliyunoss_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			addon_storage_aliyunoss_check();
		}
	}