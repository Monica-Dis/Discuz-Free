<?php

function study_pvsort($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = "/";
	$_var_4 = '';
	foreach ($_arg_0 as $_var_5) {
		$_var_3 = $_var_3 . ($_var_4 . preg_quote($_var_5));
		$_var_4 = "|";
	}
	$_var_3 = $_var_3 . "/";
	preg_match_all($_var_3, $_arg_1, $_var_6);
	$_var_6 = $_var_6[0];
	$_var_6 = array_flip($_var_6);
	foreach ($_var_6 as $_arg_0 => $_var_7) {
		$_arg_2 = str_replace($_arg_0, "\$" . ($_var_7 + 1), $_arg_2);
	}
	return $_arg_2;
}
function study_pvadd($_arg_0, $_arg_1 = 0)
{
	$_arg_0 = str_replace(array("\$3", "\$2", "\$1"), array("~4", "~3", "~2"), $_arg_0);
	if (!$_arg_1) {
		return str_replace(array("~4", "~3", "~2"), array("\$4", "\$3", "\$2"), $_arg_0);
	}
	return str_replace(array("~4", "~3", "~2"), array("{R:4}", "{R:3}", "{R:2}"), $_arg_0);
}
function addon_storage_aliyunoss_cleardir($_arg_0)
{
}
function addon_storage_aliyunoss_deltree($_arg_0)
{
}
function study_rewritedata()
{
	global $_G;
	$_var_1 = array();
	$_var_2 = $_G["cache"]["plugin"]["addon_storage_aliyunoss"];
	$_var_1["rulesearch"]["forum_forumdisplay_gid"] = "data/attachment/{more}";
	$_var_1["rulereplace"]["forum_forumdisplay_gid"] = "plugin.php?id=addon_storage_aliyunoss:goto&url={more}";
	$_var_1["rulevars"]["forum_forumdisplay_gid"]["{more}"] = "(.*)";
	return $_var_1;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}
	require_once libfile("function/var", "plugin/addon_storage_aliyunoss/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	loadcache("plugin");
	$splugin_setting = $_G["cache"]["plugin"]["addon_storage_aliyunoss"];
	$splugin_lang = lang("plugin/addon_storage_aliyunoss");
	$_var_9 = array();
	$_var_10 = study_rewritedata();
	$_var_9["{apache1}"] = $_var_9["{apache2}"] = $_var_9["{iis}"] = $_var_9["{iis7}"] = $_var_9["{zeus}"] = $_var_9["{nginx}"] = '';
	foreach ($_var_10["rulesearch"] as $_var_11 => $_var_12) {
		$_var_13 = count($_var_10["rulevars"][$_var_11]) + 2;
		$_var_14 = array_keys($_var_10["rulevars"][$_var_11]);
		$_var_10["rulereplace"][$_var_11] = study_pvsort($_var_14, $_var_12, $_var_10["rulereplace"][$_var_11]);
		$_var_12 = str_replace($_var_14, $_var_10["rulevars"][$_var_11], addcslashes($_var_12, "?*+^\$.[]()|"));
		$_var_9["{apache1}"] = $_var_9["{apache1}"] . ("\t" . "RewriteCond %{REQUEST_FILENAME} !-f" . "\n\t" . "RewriteCond %{REQUEST_FILENAME} !-d" . "\n");
		$_var_9["{apache2}"] = $_var_9["{apache2}"] . ("RewriteCond %{REQUEST_FILENAME} !-f" . "\n" . "RewriteCond %{REQUEST_FILENAME} !-d" . "\n");
		$_var_9["{apache1}"] = $_var_9["{apache1}"] . ("\t" . "RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n\t" . "RewriteRule ^(.*)/" . $_var_12 . "\$ \$1/" . study_pvadd($_var_10["rulereplace"][$_var_11]) . "&%1\n");
		if ($_var_11 != "forum_archiver") {
			$_var_9["{apache2}"] = $_var_9["{apache2}"] . ("RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n" . "RewriteRule ^" . $_var_12 . "\$ " . $_var_10["rulereplace"][$_var_11] . "&%1\n");
		} else {
			$_var_9["{apache2}"] = $_var_9["{apache2}"] . ("RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n" . "RewriteRule ^archiver/" . $_var_12 . "\$ archiver/" . $_var_10["rulereplace"][$_var_11] . "&%1\n");
		}
		$_var_9["{iis}"] = $_var_9["{iis}"] . ("RewriteRule ^(.*)/" . $_var_12 . "(\\?(.*))*\$ \$1/" . addcslashes(study_pvadd($_var_10["rulereplace"][$_var_11]) . "&\$" . ($_var_13 + 1), ".?") . "\n");
		$_var_9["{iis7}"] = $_var_9["{iis7}"] . ("\t\t" . "&lt;rule name=\"" . $_var_11 . "\"&gt;" . "\n\t\t\t" . "&lt;match url=\"^(.*/)*" . str_replace("\\.", ".", $_var_12) . "\\?*(.*)\$\" /&gt;" . "\n");
		$_var_9["{iis7}"] = $_var_9["{iis7}"] . ("\t\t\t" . "&lt;conditions&gt;" . "\n\t\t\t\t" . "&lt;add input=\"{REQUEST_FILENAME}\" matchType=\"IsFile\" ignoreCase=\"false\" negate=\"true\" /&gt;" . "\n\t\t\t\t" . "&lt;add input=\"{REQUEST_FILENAME}\" matchType=\"IsDirectory\" ignoreCase=\"false\" negate=\"true\" /&gt;" . "\n\t\t\t" . "&lt;/conditions&gt;" . "\n");
		$_var_9["{iis7}"] = $_var_9["{iis7}"] . ("\t\t\t" . "&lt;action type=\"Rewrite\" url=\"{R:1}/" . str_replace(array("&", "page\\%3D"), array("&amp;amp;", "page%3D"), addcslashes(study_pvadd($_var_10["rulereplace"][$_var_11], 1) . "&{R:" . $_var_13 . "}", "?")) . "\" /&gt;" . "\n\t\t" . "&lt;/rule&gt;" . "\n");
		$_var_9["{zeus}"] = $_var_9["{zeus}"] . ("match URL into \$ with ^(.*)/" . $_var_12 . "\\?*(.*)\$" . "\n" . "if matched then" . "\n\t" . "set URL = \$1/" . study_pvadd($_var_10["rulereplace"][$_var_11]) . "&\$" . $_var_13 . "\nendif\n");
		$_var_9["{nginx}"] = $_var_9["{nginx}"] . ("if (!-e \$request_filename) {" . "\n\t" . "rewrite ^([^\\.]*)/" . $_var_12 . "\$ \$1/" . stripslashes(study_pvadd($_var_10["rulereplace"][$_var_11])) . " break;" . "\t\n" . "}" . "\n");
	}
	showtips($splugin_lang["rewrite_tip"]);
	$_var_15 = '';
	if ($_SERVER["HTTP_HOST"] == "www.ceshi.com") {
		$_var_15 = $splugin_lang["rewrite_message_apache1"] . $splugin_lang["rewrite_message_apache2"] . $splugin_lang["rewrite_message_iis1"] . $splugin_lang["rewrite_message_iis2"] . $splugin_lang["rewrite_message_zeus"] . $splugin_lang["rewrite_message_nginx"];
	} else {
		if (stripos($_SERVER["SERVER_SOFTWARE"], "apache") !== false) {
			$_var_15 = $splugin_lang["rewrite_message_apache1"] . $splugin_lang["rewrite_message_apache2"];
		} else {
			if (stripos($_SERVER["SERVER_SOFTWARE"], "iis") !== false) {
				if (stripos($_SERVER["SERVER_SOFTWARE"], "6.0") !== false) {
					$_var_15 = $splugin_lang["rewrite_message_iis1"];
				} else {
					$_var_15 = $splugin_lang["rewrite_message_iis2"];
				}
			} else {
				if (stripos($_SERVER["SERVER_SOFTWARE"], "zeus") !== false) {
					$_var_15 = $splugin_lang["rewrite_message_zeus"];
				} else {
					if (stripos($_SERVER["SERVER_SOFTWARE"], "nginx") !== false) {
						$_var_15 = $splugin_lang["rewrite_message_nginx"];
					} else {
						echo "&#x6682;&#x65E0;&#xFF1A;" . $_SERVER["SERVER_SOFTWARE"] . " &#x5BF9;&#x5E94;&#x7684;&#x4F2A;&#x9759;&#x6001;&#x89C4;&#x5219;&#xFF0C;&#x8054;&#x7CFB;QQ&#xFF1A;http://t.cn/Aiux1012 &#x54A8;&#x8BE2;";
						return 0;
					}
				}
			}
		}
	}
	echo str_replace(array("{prevpage}", "{page}", "{typeid}", "{sortid}", "{siteroot}"), array(1, 1, 0, 0, $_G["siteroot"] ? $_G["siteroot"] : "/"), str_replace(array_keys($_var_9), $_var_9, $_var_15));