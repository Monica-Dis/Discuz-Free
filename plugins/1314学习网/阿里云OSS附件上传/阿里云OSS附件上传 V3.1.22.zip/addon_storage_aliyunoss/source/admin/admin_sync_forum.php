<?php

function addon_storage_aliyunoss_shutdown()
{
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $akey;
	global $attachmentkey;
	if (isset($_G["gettag_error"]) && $_G["gettag_error"] > 0) {
		cpmsg("&#x9644;&#x4EF6;&#x8868;" . $attachmentkey[$akey] . "&#x540C;&#x6B65;&#x4E2D;......" . $_var_11, "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_12 . "&ac=" . $_var_13 . "&formhash=" . $_G["formhash"] . "&onlyattachkey=" . dhtmlspecialchars($_var_14) . "&akey=" . $akey . "&aid=" . $_var_11, "loading");
	}
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	set_time_limit(0);
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $akey;
	global $attachmentkey;
	require_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/function/function_core.php";
	require_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/OSS/AutoLoad.php";
	$_var_11 = $_var_12 = '';
	$attachmentkey = array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
	if (empty($_G["inajax"])) {
		register_shutdown_function("addon_storage_aliyunoss_shutdown");
	}
	if ($_GET["formhash"] && $_GET["formhash"] == $_G["formhash"]) {
		$_var_13 = intval($_GET["aid"]);
		$_var_14 = $_GET["onlyattachkey"];
		if ($_var_14) {
			$akey = intval(str_replace("t_", '', $_var_14));
		} else {
			$akey = intval($_GET["akey"]);
		}
		if (!isset($attachmentkey[$akey])) {
			cpmsg("&#x540C;&#x6B65;&#x5B8C;&#x6210;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12, "succeed");
		}
		C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->set_table($attachmentkey[$akey]);
		$_var_15 = intval($_GET["onlyaid"]);
		if ($_var_15 > 0) {
			$_var_16 = C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->fetch_all_by_search(array("remote" => 0, "aid" => $_var_15), array("aid" => "ASC"), 1);
		} else {
			$_var_16 = C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->fetch_all_by_search(array("remote" => 0, "aid" => array($_var_13, ">")), array("aid" => "ASC"), 1);
		}
		if (!empty($_var_16)) {
			clearstatcache();
			$_var_17 = !$_G["setting"]["attachdir"] ? DISCUZ_ROOT . "./data/attachment/" : $_G["setting"]["attachdir"];
			$_var_18 = $_var_19 = $_var_20 = array();
			foreach ($_var_16 as $_var_21) {
				$_var_13 = $_var_21["aid"];
				$_G["gettag_error"] = $_var_13;
				if (is_file($_var_17 . "forum/" . $_var_21["attachment"])) {
					$_var_22 = filesize($_var_17 . "forum/" . $_var_21["attachment"]);
					if ($_var_22 > 0) {
						if (!isset($_var_20[$_var_21["tid"]])) {
							$_var_20[$_var_21["tid"]] = DB::fetch_first("SELECT * FROM " . DB::table("forum_thread") . " WHERE " . DB::field("tid", $_var_21["tid"]) . " LIMIT 1");
						}
						if (empty($_var_20[$_var_21["tid"]]) || $_var_20[$_var_21["tid"]]["displayorder"] < 0 || $_var_20[$_var_21["tid"]]["sortid"] > 0) {
							continue;
						}
						if (ftpcmd("upload", "forum/" . $_var_21["attachment"])) {
							$_var_19 = array();
							$_var_18[$_var_21["aid"]] = $_var_21["aid"];
							if ($_var_21["picid"]) {
								$_var_19[] = $_var_21["picid"];
							}
							if ($_var_21["thumb"]) {
								if (ftpcmd("upload", "forum/" . getimgthumbname($_var_21["attachment"]))) {
									if ($splugin_setting["sync_deletelocal"]) {
										@unlink($_var_17 . "/forum/" . getimgthumbname($_var_21["attachment"]));
									}
								}
							}
							if ($splugin_setting["sync_deletelocal"]) {
								@unlink($_var_17 . "/forum/" . $_var_21["attachment"]);
							}
							if ($_var_21["filesize"] <= 0) {
								C::t("forum_attachment_n")->update($attachmentkey[$akey], array($_var_21["aid"]), array("remote" => 1, "filesize" => $_var_22));
							} else {
								C::t("forum_attachment_n")->update($attachmentkey[$akey], array($_var_21["aid"]), array("remote" => 1));
							}
							if (!empty($_var_19)) {
								C::t("home_pic")->update($_var_19, array("remote" => 3));
							}
						}
					}
				}
				if ($_var_21["filesize"] > 10040611) {
					break;
				}
			}
			$_G["gettag_error"] = 0;
			if ($_var_15 > 0) {
				cpmsg("&#x9644;&#x4EF6; " . $_var_15 . " &#x540C;&#x6B65;&#x7ED3;&#x675F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12, "succeed");
			} else {
				cpmsg("&#x9644;&#x4EF6;&#x8868;" . $attachmentkey[$akey] . "&#x540C;&#x6B65;&#x4E2D;..." . $_var_13, "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12 . "&formhash=" . $_G["formhash"] . "&onlyattachkey=" . dhtmlspecialchars($_var_14) . "&akey=" . $akey . "&aid=" . $_var_13, "loading");
			}
		} else {
			if ($_var_15 > 0) {
				cpmsg("&#x9644;&#x4EF6; " . $_var_15 . " &#x540C;&#x6B65;&#x7ED3;&#x675F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12, "succeed");
			} else {
				if ($_var_14) {
					cpmsg("&#x9644;&#x4EF6;&#x8868;" . $attachmentkey[$akey] . "&#x540C;&#x6B65;&#x5B8C;&#x6210;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12, "succeed");
				} else {
					cpmsg("&#x9644;&#x4EF6;&#x8868;" . $attachmentkey[$akey] . "&#x540C;&#x6B65;&#x5B8C;&#x6210;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12 . "&formhash=" . $_G["formhash"] . "&akey=" . ($akey + 1) . "&aid=0", "loading");
				}
			}
		}
	} else {
		s_shownav("sort", "sorts_admin");
		$_var_23 = 0;
		$_var_24 = array();
		foreach ($attachmentkey as $_var_25) {
			C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->set_table($_var_25);
			$_var_24[$_var_25] = C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->count_by_where(array("remote" => "0"));
			$_var_23 = $_var_23 + $_var_24[$_var_25];
		}
		showtips("\r\n\t<li>&#x672C;&#x5730;&#x9644;&#x4EF6;&#x6570;&#x91CF;&#xFF1A;" . $_var_23 . "&#xFF0C;&#x9009;&#x62E9;&#x5BF9;&#x5E94;&#x7684;&#x9644;&#x4EF6;&#x5206;&#x8868;&#xFF0C;&#x53EF;&#x4EE5;&#x67E5;&#x770B;&#x672C;&#x5730;&#x9644;&#x4EF6;&#x4FE1;&#x606F;</li>\r\n\t<li>&#x672C;&#x5730;&#x6E90;&#x6587;&#x4EF6;&#x4E0D;&#x5B58;&#x5728;&#x3001;&#x5E16;&#x5B50;&#x5728;&#x5BA1;&#x6838;&#x6216;&#x56DE;&#x6536;&#x7AD9;&#x7B49;&#xFF0C;&#x56FE;&#x7247;&#x4E0D;&#x4F1A;&#x88AB;&#x540C;&#x6B65;</li>\r\n\t<li>&#x540C;&#x6B65;&#x540E;&#x53EF;&#x80FD;&#x4F1A;&#x81EA;&#x52A8;&#x5220;&#x9664;&#x672C;&#x5730;&#x5BF9;&#x5E94;&#x56FE;&#x7247;&#x548C;&#x9644;&#x4EF6;&#xFF0C;&#x4E0D;&#x7BA1;&#x662F;&#x5426;&#x81EA;&#x52A8;&#x5220;&#x9664;&#x672C;&#x5730;&#x56FE;&#x7247;&#x548C;&#x9644;&#x4EF6;&#xFF0C;&#x8BF7;&#x5148;&#x5907;&#x4EFD;&#x597D;&#x672C;&#x5730;&#x56FE;&#x7247;&#x548C;&#x9644;&#x4EF6;(data/attachment/forum)&#xFF0C;&#x4EE5;&#x514D;&#x51FA;&#x73B0;&#x5F02;&#x5E38;&#x65F6;&#x53EF;&#x4EE5;&#x8FD8;&#x539F;&#xFF0C;&#x4E0D;&#x8FDB;&#x884C;&#x5907;&#x4EFD;&#x5C31;&#x540C;&#x6B65;&#xFF0C;&#x9700;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x98CE;&#x9669;&#x3002;</li>\r\n\t");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12);
		showtableheader('');
		echo "<tr onmouseover=\"setfaq(this, 'faq0514')\"><td colspan=\"2\" class=\"td27\" s=\"1\">&#x540C;&#x6B65;&#x54EA;&#x4E9B;&#x8868;:</td></tr>\r\n\t<tr class=\"noborder\" onmouseover=\"setfaq(this, 'faq0514')\">\r\n\t<td class=\"vtop rowform\">\r\n\t<select name=\"onlyattachkey\" onchange=\"window.location='" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12 . "&attachkey=' + this.value;\">";
		$_var_26 = array(array(0, "&#x5168;&#x90E8;&#x9644;&#x4EF6;&#x8868; (" . $_var_23 . ")"));
		foreach ($attachmentkey as $_var_25) {
			$_var_26[] = array("t_" . $_var_25, "&#x5E16;&#x5B50;&#x9644;&#x4EF6;&#x8868; forum_attachment_" . $_var_25 . " (" . $_var_24[$_var_25] . ")");
		}
		foreach ($_var_26 as $_var_27) {
			echo "<option value=\"" . $_var_27[0] . "\" " . ($_GET["attachkey"] == $_var_27[0] ? "selected=\"selected\"" : '') . ">" . $_var_27[1] . "</option>";
		}
		echo "</select>\r\n\t</td>\r\n\t<td class=\"vtop tips2\" s=\"1\">\r\n\t</td>\r\n\t</tr>";
		showsubmit("submit", "&#x4E00;&#x952E;&#x540C;&#x6B65;&#x5230;&#x963F;&#x91CC;&#x4E91;OSS");
		showtablefooter();
		showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
		if ($_GET["attachkey"]) {
			$_var_28 = explode("_", $_GET["attachkey"]);
			if ($_var_28[0] == "t" && isset($attachmentkey[$_var_28[1]])) {
				C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->set_table($_var_28[1]);
				$_var_29 = array("remote" => 0);
				$_var_30 = 20;
				$_var_31 = 1000;
				$_var_23 = C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->count_by_where($_var_29);
				$_var_32 = intval($_GET["page"]);
				$_var_32 = $_var_32 - 1 > $_var_23 / $_var_30 || $_var_32 > $_var_31 ? 1 : $_var_32;
				$_var_33 = ($_var_32 - 1) * $_var_30;
				$_var_34 = multi($_var_23, $_var_30, $_var_32, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12 . "&attachkey=" . dhtmlspecialchars($_GET["attachkey"]), $_var_31);
				$_var_16 = C::t("#addon_storage_aliyunoss#aliyunoss_forum_attachment_n")->fetch_all_by_search($_var_29, $_var_35, $_var_33, $_var_30);
				$_var_16 = dhtmlspecialchars($_var_16);
				showtableheader('');
				showsubtitle(array("&#x9644;&#x4EF6;ID", "&#x9644;&#x4EF6;&#x540D;&#x79F0;", "&#x5927;&#x5C0F;", "&#x6240;&#x5C5E;&#x5E16;&#x5B50;", "&#x65F6;&#x95F4;", "&#x6587;&#x4EF6;&#x662F;&#x5426;&#x5B58;&#x5728;", ''));
				clearstatcache();
				$_var_36 = helper_attach::attachpreurl();
				$_var_20 = array();
				foreach ($_var_16 as $_var_21) {
					if (!isset($_var_20[$_var_21["tid"]])) {
						$_var_20[$_var_21["tid"]] = DB::fetch_first("SELECT * FROM " . DB::table("forum_thread") . " WHERE " . DB::field("tid", $_var_21["tid"]) . " LIMIT 1");
					}
					$_var_21 = dhtmlspecialchars($_var_21);
					$_var_37 = is_file($_G["setting"]["attachdir"] . "forum/" . $_var_21["attachment"]) ? 1 : 0;
					showtablerow('', array(" style=\"width:100px;\"", "class=\"td28\" style=\"width:400px;\"", " style=\"width:100px;\"", "class=\"td28\" style=\"width:400px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", ''), array($_var_21["aid"], "<div style=\"height: 14px;line-height: 14px;overflow: hidden;\"><a href=\"" . $_var_36 . "forum/" . $_var_21["attachment"] . "\" target=\"_blank\" title=\"" . $_var_21["filename"] . "\" class=\"act\">" . $_var_21["filename"] . "</a></div>", sizecount($_var_21["filesize"]), !empty($_var_20[$_var_21["tid"]]) ? "<a href=\"forum.php?mod=viewthread&tid=" . $_var_21["tid"] . "\" target=\"_blank\" class=\"act\">" . dhtmlspecialchars($_var_20[$_var_21["tid"]]["subject"]) . "</a>" : "<b style=\"color:red;\">&#x5E16;&#x5B50;&#x4E0D;&#x5B58;&#x5728;</b>", dgmdate($_var_21["dateline"], "Y-m-d H:i:s", $_G["setting"]["timeoffset"]), $_var_37 ? "<b style=\"color:green;\">&#x5B58;&#x5728;</a>" : "<b style=\"color:red;\">&#x4E0D;&#x5B58;&#x5728;</b>", $_var_37 ? "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_11 . "&ac=" . $_var_12 . "&onlyattachkey=" . $_var_28[1] . "&onlyaid=" . $_var_21["aid"] . "&formhash=" . $_G["formhash"] . "\" target=\"_blank\" class=\"act\">&#x540C;&#x6B65;</a>" : '', ''));
				}
				showsubmit('', '', '', '', $_var_34);
				showtablefooter();
			}
		}
	}