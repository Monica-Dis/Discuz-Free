<?php

	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_storage_aliyunoss"];
	if ($_GET["url"] && $_G["setting"]["ftp"]["attachurl"]) {
		header("HTTP/1.1 301 Moved Permanently");
		dheader("Location:" . $_G["setting"]["ftp"]["attachurl"] . $_GET["url"]);
	} else {
		echo "Access Denied";
		return 0;
	}