<?php

/**
 * Copyright 2001-2099 DisM-Taobao.
 * This is NOT a freeware, use is subject to license terms
 * $Id: table_aliyunoss_forum_attachment_n.php 3979 2020-02-24 19:04:17
 * Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM-Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
exit('Access Denied');
}
class table_aliyunoss_forum_attachment_n extends discuz_table
{
	public function __construct() {

		$this->_table = '';
		$this->_pk    = 'aid';

		parent::__construct();
	}

	public function set_table($tableid) {
		if(!is_numeric($tableid)) {
			list($idtype, $id) = explode(':', $tableid);
			if($idtype == 'aid') {
				$aid = dintval($id);
				$tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
			} elseif($idtype == 'tid') {
				$tid = (string)$id;
				$tableid = dintval($tid{strlen($tid)-1});
			} elseif($idtype == 'pid') {
				$pid = dintval($id);
				$tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE pid='$pid' LIMIT 1");
				$tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
			}
		}
		if($tableid >= 0 && $tableid < 10) {
			$this->_table = 'forum_attachment_'.intval($tableid);
		} elseif($tableid == 127) {
			$this->_table = 'forum_attachment_unused';
		} else {
			throw new DbException('Table forum_attachment_'.$this->_table.' has not exists');
		}
	}

	public function count_by_where($param = array()) {
		$count = (int) DB::result_first('SELECT count(*) FROM  %t %i', array($this->_table, $this->wheresql($param)));
		return $count;
	}
	
	public function delete_by_where($param, $unbuffered = false) {
		$ret = false;
		if(isset($param)) {
			$this->checkpk();
			$ret = DB::delete($this->_table, $this->wheresql($param, false), null, $unbuffered);
			if($param[$this->_pk]){
				$this->clear_cache($param[$this->_pk]);
			}
		}
		return $ret;
	}

	public function update_by_where($param, $data, $unbuffered = false, $low_priority = false) {
		if(isset($param) && !empty($data) && is_array($data)) {
			$this->checkpk();
			$ret = DB::update($this->_table, $data, $this->wheresql($param, false), $unbuffered, $low_priority);
			if($param[$this->_pk]){
				$this->update_cache($param[$this->_pk], $data);
			}
			return $ret;
		}
		return !$unbuffered ? 0 : false;
	}
	
	public function fetch_by_search($param, $order = array()) {
	  return DB::fetch_first('SELECT * FROM %t %i %i LIMIT 1', array($this->_table, $this->wheresql($param), $this->ordersql($order)));
	}
	
	public function fetch_all_by_search($param = array(), $order = array(), $start = 0, $limit = 0) {
	  return DB::fetch_all('SELECT * FROM %t %i %i ' . DB::limit($start, $limit), array($this->_table, $this->wheresql($param), $this->ordersql($order)), $this->_pk);
	}
	
	public function wheresql($param, $havewhere = true) {
	  $return = '';
	  $wherearr = array();
	  if (is_array($param)) {
	      foreach ($param as $key => $value) {
	      		if(is_array($value)){
	      			/*
	      			array(
	      			'uid' => $uid, 
	      			'complete_percent' => array('60', '>='),
	      			'complete_percent' => array('complete_percent', '100', '<='),
	      			'keyword' => array('%'.addcslashes($keyword, '%_').'%', 'like'),
	      			)
	      			*/
	      			if(count($value) > 2){
	      				$wherearr[] = DB::field($value[0], $value[1], $value[2]);
	      			}else{
		      			$wherearr[] = DB::field($key, $value[0], $value[1]);
		      		}
	      		}else{
	              	$wherearr[] = DB::field($key, $value);
	          }
	      }
	      $return = $wherearr ? ($havewhere ? 'WHERE ' : '') . implode(' AND ', $wherearr) : '';
	  }
	  return $return;
	}
	
	public function ordersql($param, $haveorderby = true) {
	  $return = '';
	  $orderbyarr = array();
	  if (is_array($param)) {
	      foreach ($param as $key => $value) {
	      		$orderbyarr[] = DB::order($key, $value);
	      }
	      $return = $orderbyarr ? ($haveorderby ? ' ORDER BY ' : '') . implode(',', $orderbyarr) : '';
	  }else{
	  	  $return = ($haveorderby ? ' ORDER BY ' : '') . $this->_pk.' DESC';	
	  }
	  return $return;
	}
}



//Copyright 2001-2099 .DisM.TaoBao.
//This is NOT a freeware, use is subject to license terms
//$Id: table_aliyunoss_forum_attachment_n.php 4465 2020-02-24 11:04:17
//Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM��Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��