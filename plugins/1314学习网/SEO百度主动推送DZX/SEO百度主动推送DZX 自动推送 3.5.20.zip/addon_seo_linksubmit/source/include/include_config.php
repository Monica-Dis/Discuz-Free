<?php

function addon_seo_linksubmit_cleardir($_arg_0)
{
}
function addon_seo_linksubmit_deltree($_arg_0)
{
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$pluginvars = array();
	foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_9) {
		if (!strexists($_var_9["type"], "_")) {
			C::t("common_pluginvar")->update_by_variable($pluginid, $_var_9["variable"], array("type" => $_var_9["type"] . "_1314"));
		} else {
			$_var_10 = explode("_", $_var_9["type"]);
			if ($_var_10[1] == "1314") {
				$_var_9["type"] = $_var_10[0];
			} else {
				continue;
			}
		}
		$pluginvars[$_var_9["variable"]] = $_var_9;
	}
	require_once libfile("function/var", "plugin/addon_seo_linksubmit/source");
	if (!submitcheck("editsubmit")) {
		$_var_11 = '';
		if ($pluginvars) {
			showformheader("plugins&operation=config&do=" . $pluginid . '');
			showtableheader();
			echo "<div id=\"my_addonlist\"></div>";
			showtitle($lang["plugins_config"]);
			$_var_12 = array();
			foreach ($pluginvars as $_var_9) {
				if (!strexists($_var_9["type"], "_")) {
					if ($_var_9["variable"] == "forum_datetime") {
						showtablefooter();
						showtableheader("&#x5E16;&#x5B50;&#x63A8;&#x9001;");
					} else {
						if ($_var_9["variable"] == "portal_article") {
							showtablefooter();
							showtableheader("&#x6587;&#x7AE0;&#x63A8;&#x9001;");
						} else {
							if ($_var_9["variable"] == "token") {
								$_var_9["description"] = $_var_9["description"] . $_G["siteurl"];
							} else {
								if ($_var_9["variable"] != "site") {
									if ($_var_9["variable"] == "js_push") {
										showtablefooter();
										showtableheader("&#x9644;&#x52A0;&#x7684;&#x5C0F;&#x529F;&#x80FD; - JS&#x81EA;&#x52A8;&#x63A8;&#x9001;");
									}
								}
							}
						}
					}
					$_var_9["variable"] = "varsnew[" . $_var_9["variable"] . "]";
					if ($_var_9["type"] == "number") {
						$_var_9["type"] = "text";
					} else {
						if ($_var_9["type"] == "datetime") {
							$_var_9["type"] = "calendar";
							$_var_9["extra"] = 1;
							$_var_12["date"] = "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
						} else {
							if ($_var_9["type"] == "forums") {
								$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
								$_var_9["value"] = dunserialize($_var_9["value"]);
								$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array();
								require_once libfile("function/forumlist");
								$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\">" . cplang("plugins_empty") . "</option>" . forumselect(false, 0, 0, true) . "</select>";
								foreach ($_var_9["value"] as $_var_13) {
									$_var_9["type"] = str_replace("<option value=\"" . $_var_13 . "\">", "<option value=\"" . $_var_13 . "\" selected>", $_var_9["type"]);
								}
								$_var_9["variable"] = $_var_9["value"] = '';
							} else {
								if (substr($_var_9["type"], 0, 5) == "group") {
									if ($_var_9["type"] == "groups") {
										$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
										$_var_9["value"] = dunserialize($_var_9["value"]);
										$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\"" . (@in_array('', $_var_9["value"]) ? " selected" : '') . ">" . cplang("plugins_empty") . "</option>";
									} else {
										$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\"><option value=\"\">" . cplang("plugins_empty") . "</option>";
									}
									$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array($_var_9["value"]);
									$_var_14 = C::t("common_usergroup")->range_orderby_credit();
									$_var_15 = array();
									foreach ($_var_14 as $_var_16) {
										$_var_16["type"] = $_var_16["type"] == "special" && $_var_16["radminid"] ? "specialadmin" : $_var_16["type"];
										$_var_15[$_var_16["type"]] = $_var_15[$_var_16["type"]] . ("<option value=\"" . $_var_16["groupid"] . "\"" . (@in_array($_var_16["groupid"], $_var_9["value"]) ? " selected" : '') . ">" . $_var_16["grouptitle"] . "</option>");
									}
									$_var_9["type"] = $_var_9["type"] . ("<optgroup label=\"" . $lang["usergroups_member"] . "\">" . $_var_15["member"] . "</optgroup>" . ($_var_15["special"] ? "<optgroup label=\"" . $lang["usergroups_special"] . "\">" . $_var_15["special"] . "</optgroup>" : '') . ($_var_15["specialadmin"] ? "<optgroup label=\"" . $lang["usergroups_specialadmin"] . "\">" . $_var_15["specialadmin"] . "</optgroup>" : '') . "<optgroup label=\"" . $lang["usergroups_system"] . "\">" . $_var_15["system"] . "</optgroup></select>");
									$_var_9["variable"] = $_var_9["value"] = '';
								}
							}
						}
					}
					s_showsetting(isset($lang[$_var_9["title"]]) ? $lang[$_var_9["title"]] : dhtmlspecialchars($_var_9["title"]), $_var_9["variable"], $_var_9["value"], $_var_9["type"], '', 0, isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : nl2br(dhtmlspecialchars($_var_9["description"])), dhtmlspecialchars($_var_9["extra"]), '', true);
				}
			}
			showsubmit("editsubmit");
			showtablefooter();
			showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
			echo implode('', $_var_12);
			$_var_17 = array();
			$_var_17["pluginName"] = $plugin["identifier"];
			$_var_17["pluginVersion"] = $plugin["version"];
			$_var_17["bbsVersion"] = DISCUZ_VERSION;
			$_var_17["bbsRelease"] = DISCUZ_RELEASE;
			$_var_17["timestamp"] = TIMESTAMP;
			$_var_17["bbsUrl"] = $_G["siteurl"];
			$_var_17["SiteUrl"] = $_statInfo["SiteUrl"];
			$_var_17["ClientUrl"] = $_statInfo["ClientUrl"];
			$_var_17["SiteID"] = $_statInfo["SiteID"];
			$_var_17["bbsAdminEMail"] = $_G["setting"]["adminemail"];
			$_var_17["genuine"] = splugin_genuine($plugin["identifier"]);
			echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"></div>\r\n\t\t";
		}
	} else {
		if (is_array($_GET["varsnew"])) {
			foreach ($_GET["varsnew"] as $_var_18 => $_var_19) {
				if (isset($pluginvars[$_var_18])) {
					if ($pluginvars[$_var_18]["type"] == "number") {
						$_var_19 = (double) $_var_19;
					} else {
						if (in_array($pluginvars[$_var_18]["type"], array("forums", "groups", "selects"))) {
							$_var_19 = serialize($_var_19);
						}
					}
					$_var_19 = (string) $_var_19;
					C::t("common_pluginvar")->update_by_variable($pluginid, $_var_18, array("value" => $_var_19));
				}
			}
		}
		updatecache(array("plugin", "setting", "styles"));
		cleartemplatecache();
		cpmsg("plugins_setting_succeed", "action=plugins&operation=config&do=" . $pluginid . "&anchor=" . $_var_20, "succeed");
	}