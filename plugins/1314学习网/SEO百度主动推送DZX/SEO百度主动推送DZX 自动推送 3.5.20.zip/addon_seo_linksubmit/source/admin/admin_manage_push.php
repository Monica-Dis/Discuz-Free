<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$_var_9 = $_var_10 = '';
	if (!submitcheck("submit")) {
		s_shownav("sort", "sorts_admin");
		loadcache(array("saddon_seo_linksubmit"));
		$_var_11 = $_G["cache"]["saddon_seo_linksubmit"];
		$_var_12 = strtotime(dgmdate(TIMESTAMP, "Y-m-d", $_G["setting"]["timeoffset"]));
		if ($_var_11["todaytime"] < $_var_12) {
			$_var_13 = "&#x4ECA;&#x65E5;&#x8FD8;&#x672A;&#x63A8;&#x9001;&#x4EFB;&#x4F55;&#x4FE1;&#x606F;";
		} else {
			$_var_13 = "&#x4ECA;&#x65E5;&#x5269;&#x4F59;&#x53EF;&#x63A8;&#x9001;&#x6761;&#x6570;&#xFF1A;<b style=\"color:red\">&#x65E0;&#x9650;&#x5236;</b>";
		}
		showtips("<li>" . $_var_13 . "</li>");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_9 . "&ac=" . $_var_10);
		showtableheader('');
		s_showsetting("&#x624B;&#x52A8;&#x63A8;&#x9001;&#x94FE;&#x63A5;", "links", '', "textarea", '', 0, "<b>&#x591A;&#x6761;&#x94FE;&#x63A5;&#x4EE5;&#x56DE;&#x8F66;&#x6362;&#x884C;&#x6765;&#x5206;&#x9694;</b>");
		showsubmit("submit", "submit");
		showtablefooter();
		showformfooter();/*di'.'sm.t'.'aoba'.'o.com*/
	} else {
		require_once libfile("function/core", "plugin/addon_seo_linksubmit/source");
		if (!empty($_POST["links"])) {
			addon_seo_linksubmit_baidu(array("url" => $_POST["links"]));
		}
		cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_9 . "&ac=" . $_var_10, "succeed");
	}