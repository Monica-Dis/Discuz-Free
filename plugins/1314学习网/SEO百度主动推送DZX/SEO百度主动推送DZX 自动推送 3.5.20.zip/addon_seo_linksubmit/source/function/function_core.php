<?php

function addon_seo_linksubmit_dealurl($_arg_0)
{
	global $_G;
	$_var_2 = '';
	$_var_3 = $_G["siteurl"];
	if ($_G["cache"]["plugin"]["addon_seo_linksubmit"]["site"]) {
		$_var_3 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_G["cache"]["plugin"]["addon_seo_linksubmit"]["site"] . "/";
	}
	if ($_arg_0["tid"]) {
		$_var_2 = $_G["cache"]["plugin"]["addon_seo_linksubmit"]["forum_viewthread"] ? $_G["cache"]["plugin"]["addon_seo_linksubmit"]["forum_viewthread"] : $_G["setting"]["rewriterule"]["forum_viewthread"];
		$_var_2 = $_var_2 ? $_var_2 : "thread-{tid}-{page}-{prevpage}.html";
		$_var_4 = array("{tid}" => $_arg_0["tid"], "{fid}" => empty($_G["setting"]["forumkeys"][$_arg_0["fid"]]) ? $_arg_0["fid"] : $_G["setting"]["forumkeys"][$_arg_0["fid"]], "{page}" => 1, "{prevpage}" => 1);
	} else {
		if ($_arg_0["aid"]) {
			$_var_2 = $_G["cache"]["plugin"]["addon_seo_linksubmit"]["portal_article"] ? $_G["cache"]["plugin"]["addon_seo_linksubmit"]["portal_article"] : $_G["setting"]["rewriterule"]["portal_article"];
			$_var_2 = $_var_2 ? $_var_2 : "article-{id}-{page}.html";
			$_var_4 = array("{id}" => $_arg_0["aid"], "{catid}" => $_arg_0["catid"], "{page}" => 1);
			if ($_G["cache"]["plugin"]["addon_seo_linksubmit"]["portal_site"]) {
				$_var_3 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_G["cache"]["plugin"]["addon_seo_linksubmit"]["portal_site"] . "/";
			}
		}
	}
	return $_var_3 . str_replace(array_keys($_var_4), $_var_4, $_var_2);
}
function addon_seo_linksubmit_explode($_arg_0)
{
	$_var_1 = array();
	$_arg_0 = explode("\n", str_replace("\\r\\n", "\\n", $_arg_0));
	foreach ($_arg_0 as $_var_2) {
		$_var_2 = trim($_var_2);
		$_var_1[] = $_var_2;
	}
	return $_var_1;
}
function addon_seo_linksubmit_check()
{
	addon_seo_linksubmit_validator();
}
function addon_seo_linksubmit_cleardir($_arg_0)
{
}
function addon_seo_linksubmit_deltree($_arg_0)
{
}
function addon_seo_linksubmit_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		if ($_GET["download_check"]) {
			addon_seo_linksubmit_check();
		}
	}
	include_once libfile("function/core2", "plugin/addon_seo_linksubmit/source");
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			addon_seo_linksubmit_check();
		}
	}