<?php

function addon_seo_linksubmit_baidu($_arg_0)
{
	global $_G;
	$_var_2 = 1;
	if (!isset($_G["cache"]["saddon_seo_linksubmit"])) {
		loadcache(array("saddon_seo_linksubmit"));
	}
	$_var_3 = $_G["cache"]["plugin"]["addon_seo_linksubmit"];
	$_arg_0["original"] = 0;
	if ($_arg_0["aid"]) {
		if ($_var_3["portal_site"]) {
			$_var_3["site"] = $_var_3["portal_site"];
			$_var_3["token"] = $_var_3["portal_token"];
		}
	}
	if ($_var_3["site"] && $_var_3["token"]) {
		$_var_4 = $_G["cache"]["saddon_seo_linksubmit"];
		$_var_5 = strtotime(dgmdate(TIMESTAMP, "Y-m-d", $_G["setting"]["timeoffset"]));
		if ($_var_4["todaytime"] < $_var_5) {
			addon_seo_linksubmit_check();
		}
		if ($_var_4["todaytime"] < $_var_5 || $_var_4["remain"] > 0) {
			$_var_6 = array();
			if ($_arg_0["tid"]) {
				$_var_7 = addon_seo_linksubmit_dealurl($_arg_0);
				$_var_8 = C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->fetch_by_search(array("url" => $_var_7));
				if ($_var_8) {
					C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->update_by_where(array("id" => $_var_8["id"]), array("title" => $_arg_0["subject"], "posttype" => 1, "postid" => $_arg_0["tid"]), true);
					C::t("forum_thread")->update($_arg_0["tid"], array("linksubmit" => $_var_8["success"] ? 1 : -1));
					return -3;
				}
			} else {
				if ($_arg_0["aid"]) {
					$_var_7 = addon_seo_linksubmit_dealurl($_arg_0);
					$_var_8 = C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->fetch_by_search(array("url" => $_var_7));
					if ($_var_8) {
						C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->update_by_where(array("id" => $_var_8["id"]), array("title" => $_arg_0["title"], "posttype" => 2, "postid" => $_arg_0["aid"]), true);
						return -3;
					}
				} else {
					if ($_arg_0["url"]) {
						if (!is_array($_arg_0["url"])) {
							$_arg_0["url"] = addon_seo_linksubmit_explode($_arg_0["url"]);
						}
						$_var_9 = array();
						foreach ($_arg_0["url"] as $_var_10 => $_var_11) {
							$_var_8 = C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->fetch_by_search(array("url" => $_var_11));
							if (empty($_var_8)) {
								$_var_9[] = $_var_11;
							}
						}
						$_arg_0["url"] = $_var_9;
						$_var_7 = implode("\n", $_arg_0["url"]);
					}
				}
			}
			if (empty($_var_7)) {
				return 0;
			}
			$_var_12 = "http://data.zz.baidu.com/urls?site=" . $_var_3["site"] . "&token=" . $_var_3["token"];
			if (function_exists("curl_init") && function_exists("curl_exec")) {
				$_var_13 = curl_init();
				curl_setopt($_var_13, CURLOPT_URL, $_var_12);
				curl_setopt($_var_13, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($_var_13, CURLOPT_HTTPHEADER, "Content-Type: text/plain");
				curl_setopt($_var_13, CURLOPT_POST, 1);
				curl_setopt($_var_13, CURLOPT_POSTFIELDS, $_var_7);
				$_var_14 = curl_exec($_var_13);
				curl_close($_var_13);
			} else {
				if (defined("IN_ADMINCP")) {
					cpmsg("&#x670D;&#x52A1;&#x5668;&#x9700;&#x8981;&#x5F00;&#x542F;Curl");
				} else {
					return -4;
				}
			}
			$_var_6 = json_decode($_var_14, true);
			if ($_arg_0["tid"]) {
				$_var_15 = '';
				if ($_var_6["error"]) {
					$_var_16 = 0;
					$_var_15 = $_var_6["message"];
				} else {
					if (in_array($_var_7, $_var_6["not_same_site"])) {
						$_var_16 = 0;
						$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_001");
					} else {
						if (in_array($_var_7, $_var_6["not_valid"])) {
							$_var_16 = 0;
							$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_002");
						} else {
							if (!empty($_var_6["error"])) {
								$_var_16 = 0;
								$_var_15 = "error " . $_var_6["error"] . ", message " . $_var_6["message"];
							} else {
								if (isset($_var_6["success_original"])) {
									$_var_16 = 1;
								} else {
									if (empty($_var_6["success"])) {
										$_var_16 = 1;
									} else {
										$_var_16 = 1;
									}
								}
							}
						}
					}
				}
				$_var_17 = array("title" => $_arg_0["subject"], "url" => $_var_7, "postid" => $_arg_0["tid"], "posttype" => 1, "success" => $_var_16, "remain" => $_var_6["remain"], "message" => $_var_15, "original" => $_arg_0["original"] ? 1 : 0, "manual" => $_arg_0["manual"] ? 1 : 0, "dateline" => $_G["timestamp"]);
				C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->insert($_var_17, true);
				C::t("forum_thread")->update($_arg_0["tid"], array("linksubmit" => $_var_16 ? 1 : -1));
			} else {
				if ($_arg_0["aid"]) {
					$_var_15 = '';
					if ($_var_6["error"]) {
						$_var_16 = 0;
						$_var_15 = $_var_6["message"];
					} else {
						if (in_array($_var_7, $_var_6["not_same_site"])) {
							$_var_16 = 0;
							$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_001");
						} else {
							if (in_array($_var_7, $_var_6["not_valid"])) {
								$_var_16 = 0;
								$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_002");
							} else {
								if (!empty($_var_6["error"])) {
									$_var_16 = 0;
									$_var_15 = "error " . $_var_6["error"] . ", message " . $_var_6["message"];
								} else {
									if (isset($_var_6["success_original"])) {
										$_var_16 = 1;
									} else {
										if (empty($_var_6["success"])) {
											$_var_16 = 1;
										} else {
											$_var_16 = 1;
										}
									}
								}
							}
						}
					}
					$_var_17 = array("title" => $_arg_0["title"], "url" => $_var_7, "postid" => $_arg_0["aid"], "posttype" => 2, "success" => $_var_16, "remain" => $_var_6["remain"], "message" => $_var_15, "original" => $_arg_0["original"] ? 1 : 0, "manual" => $_arg_0["manual"] ? 1 : 0, "dateline" => $_G["timestamp"]);
					C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->insert($_var_17, true);
				} else {
					if ($_arg_0["url"]) {
						$_arg_0["original"] = $_arg_0["original"] ? 1 : 0;
						foreach ($_arg_0["url"] as $_var_7) {
							$_var_15 = '';
							if ($_var_6["error"]) {
								$_var_16 = 0;
								$_var_15 = $_var_6["message"];
							} else {
								if (in_array($_var_7, $_var_6["not_same_site"])) {
									$_var_16 = 0;
									$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_001");
								} else {
									if (in_array($_var_7, $_var_6["not_valid"])) {
										$_var_16 = 0;
										$_var_15 = lang("plugin/addon_seo_linksubmit", "slang_002");
									} else {
										if (!empty($_var_6["error"])) {
											$_var_16 = 0;
											$_var_15 = "error " . $_var_6["error"] . ", message " . $_var_6["message"];
										} else {
											if (isset($_var_6["success_original"])) {
												$_var_16 = 1;
											} else {
												if (empty($_var_6["success"])) {
													$_var_16 = 1;
												} else {
													$_var_16 = 1;
												}
											}
										}
									}
								}
							}
							$_var_17 = array("title" => '', "url" => $_var_7, "postid" => $_arg_0["tid"], "posttype" => 3, "success" => $_var_16, "remain" => $_var_6["remain"], "message" => $_var_15, "original" => $_arg_0["original"], "manual" => 1, "dateline" => $_G["timestamp"]);
							C::t("#addon_seo_linksubmit#addon_seo_linksubmit")->insert($_var_17, true);
						}
					}
				}
			}
			if (isset($_var_6["remain"])) {
				$_var_18 = is_array($_arg_0["url"]) ? count($_arg_0["url"]) : 1;
				savecache("saddon_seo_linksubmit", array("remain" => $_var_6["remain"], "todaytime" => $_var_5, "count" => $_var_4["count"] + $_var_18));
			}
		} else {
			$_var_2 = -1;
		}
	} else {
		$_var_2 = -2;
	}
	return $_var_2;
}

	if (!defined("IN_DISCUZ")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}