<?php

/**
 * Copyright 2001-2099 DisM-Taobao.
 * This is NOT a freeware, use is subject to license terms
 * $Id: admin_manage.inc.php 4739 2020-02-19 19:40:36
 * Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM-Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=admin_manage');
require_once libfile('function/var', 'plugin/addon_seo_linksubmit/source');
$cdgtuttc = "DisM";
require_once libfile('class/admin', 'plugin/addon_seo_linksubmit/source');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = 'http://127.0.0.1/';$_statInfo['ClientUrl'] = 'http://127.0.0.1/';$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['addon_seo_linksubmit'];
$splugin_lang = lang('plugin/addon_seo_linksubmit');
$type1314 = in_array($_GET['type1314'], array('linksubmit', 'push')) ? $_GET['type1314'] : 'linksubmit';
$splugin_setting['0'] = array('0' => '20160621192CzBa5zHaF', '1' => '63033','2' => '1503281236', '3' => 'http://127.0.0.1/', '4' => 'http://127.0.0.1/', '5' => '', '6' => '', '7' => '');
echo '<link href="./source/plugin/addon_seo_linksubmit/images/manage.css?'.VERHASH.'" rel="stylesheet" type="text/css" />';
addon_seo_linksubmit_admin::subtitle(array(
	array('&#x63A8;&#x9001;&#x5217;&#x8868;', 'linksubmit'),
	array('&#x624B;&#x52A8;&#x63A8;&#x9001;', 'push'),
),$type1314);

require_once libfile('admin/manage_'.$type1314, 'plugin/addon_seo_linksubmit/source');

//Copyright 2001-2099 .DisM.TaoBao.
//This is NOT a freeware, use is subject to license terms
//$Id: admin_manage.inc.php 5207 2020-02-19 11:40:36
//Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM��Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��