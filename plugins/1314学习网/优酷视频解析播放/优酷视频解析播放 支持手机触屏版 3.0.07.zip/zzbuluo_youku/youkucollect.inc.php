<?php
 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

echo '<script type="text/javascript">location.href=\''.ADMINSCRIPT.'?action=cloudaddons&id=addon_videocollect_youku.plugin\';</script>';
exit;