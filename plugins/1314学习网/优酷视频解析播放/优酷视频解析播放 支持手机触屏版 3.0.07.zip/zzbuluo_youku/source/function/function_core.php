<?php

function zzbuluo_youku_discuzcode($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["zzbuluo_youku"];
	$_var_3 = strtolower($_G["discuzcodemessage"]);
	if (strpos($_var_3, ".youku.com") !== false) {
		if ($_var_2["media_radio"] && strpos($_var_3, "[/media]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[media(=([\\w,]+))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/media\\]/is", "zzbuluo_youku_callback_parsemedia", $_G["discuzcodemessage"]);
		}
		if ($_var_2["flash_radio"] && strpos($_var_3, "[/flash]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[flash(=(\\d+),(\\d+))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/flash\\]/is", "zzbuluo_youku_callback_parseflash", $_G["discuzcodemessage"]);
		}
		if ($_var_2["url_radio"] && strpos($_var_3, "[/url]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[url(=([^\\]]+))?\\](.+?)\\[\\/url\\]/is", "zzbuluo_youku_callback_parseurl", $_G["discuzcodemessage"]);
		}
	}
}
function zzbuluo_youku_callback_parsemedia($_arg_0)
{
	global $_G;
	$_var_2 = zzbuluo_youku_callback_parse($_arg_0[3]);
	if (empty($_var_2)) {
		$_var_3 = $_arg_0[0];
	} else {
		$_var_3 = $_var_2;
	}
	return $_var_3;
}
function zzbuluo_youku_callback_parseurl($_arg_0)
{
	global $_G;
	$_var_2 = $_arg_0[0];
	if (empty($_arg_0[2])) {
		$_arg_0[2] = $_arg_0[3];
	}
	$_var_3 = zzbuluo_youku_callback_parse($_arg_0[2]);
	if (empty($_var_3)) {
		$_var_2 = $_arg_0[0];
	} else {
		$_var_2 = $_var_3;
	}
	return $_var_2;
}
function zzbuluo_youku_callback_parseflash($_arg_0)
{
	global $_G;
	$_var_2 = zzbuluo_youku_callback_parse($_arg_0[4]);
	if (empty($_var_2)) {
		$_var_3 = $_arg_0[0];
	} else {
		$_var_3 = $_var_2;
	}
	return $_var_3;
}
function zzbuluo_youku_callback_parse($_arg_0)
{
	global $_G;
	$_var_2 = '';
	preg_match("#^https?://[\\w-]+\\.youku\\.com/player\\.php/sid/([\\w=]+)/v\\.swf#is", $_arg_0, $_var_3);
	if (empty($_var_3[1])) {
		preg_match("#^https?://[\\w-]+\\.youku\\.com/v_show/id_([\\w=]+)\\.html#is", $_arg_0, $_var_3);
		if (empty($_var_3[1])) {
			preg_match("#^https?://[\\w-]+\\.youku\\.com/embed/([\\w=]+)#is", $_arg_0, $_var_3);
		}
	}
	if (!empty($_var_3[1])) {
		if (defined("IN_MOBILE")) {
			$_var_4 = $_G["cache"]["plugin"]["zzbuluo_youku"]["touch_width"];
			$_var_5 = $_G["cache"]["plugin"]["zzbuluo_youku"]["touch_height"];
		} else {
			$_var_4 = $_G["cache"]["plugin"]["zzbuluo_youku"]["pc_width"];
			$_var_5 = $_G["cache"]["plugin"]["zzbuluo_youku"]["pc_height"];
		}
		$_var_2 = "<iframe width=\"" . $_var_4 . "\" height=\"" . $_var_5 . "\" src=\"//player.youku.com/embed/" . $_var_3[1] . "\" frameborder=\"0\" allowfullscreen=\"true\"></iframe>";
	}
	return $_var_2;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}