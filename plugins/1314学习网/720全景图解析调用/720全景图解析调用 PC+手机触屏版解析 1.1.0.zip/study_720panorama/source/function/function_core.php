<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_720panorama_init($_arg_0)
{
	global $_G;
	if ($_arg_0["caller"]) {
		$_var_2 = $_G["cache"]["plugin"]["study_720panorama"];
		$_var_2["study_tag"] = "study_720panorama";
		if ($_arg_0["caller"] == "discuzcode") {
			$_var_3 = (array) unserialize($_var_2["study_fids"]);
			if (in_array($_G["fid"], $_var_3) || $_G["forum"]["status"] == 3 && $_var_2["group_radio"]) {
				if (strpos($_G["discuzcodemessage"], "[/" . $_var_2["study_tag"] . "]") !== false) {
					$_G["discuzcodemessage"] = preg_replace_callback("/\\s?\\[" . $_var_2["study_tag"] . "([^\\]]*)\\][\n\r]*(.*?)[\n\r]*\\[\\/" . $_var_2["study_tag"] . "\\]\\s?/is", "study_720panorama_callback", $_G["discuzcodemessage"]);
				}
			}
		} else {
			$_G["discuzcodemessage"] = preg_replace("/\\s?\\[" . $_var_2["study_tag"] . "\\][\n\r]*(.*?)[\n\r]*\\[\\/" . $_var_2["study_tag"] . "\\]\\s?/is", '', $_G["discuzcodemessage"]);
			if (strpos($_G["discuzcodemessage"], "[" . $_var_2["study_tag"] . "]") !== false) {
				$_var_4 = explode("[" . $_var_2["study_tag"] . "]", $_G["discuzcodemessage"]);
				$_G["discuzcodemessage"] = $_var_4[0];
			}
			$_G["discuzcodemessage"] = str_replace("[/" . $_var_2["study_tag"] . "]", '', $_G["discuzcodemessage"]);
		}
	}
}
function study_720panorama_callback($_arg_0)
{
	global $_G;
	$_var_2 = '';
	$_var_3 = array(".720yun.com", ".720yuntu.com", ".vrqjcs.com", ".cnquanjing.com", ".vryun720.com", ".geeker.com.cn", ".720think.com", ".quanjingyun.cn", ".qj10.cn", ".720.so", ".fcz.cn", ".skypixel.com", ".expoon.com", ".zqbtv.com");
	$_var_4 = false;
	if ($_arg_0[2]) {
		$_var_5 = parse_url($_arg_0[2]);
		if (!empty($_var_5["host"]) && in_array($_var_5["scheme"], array("http", "https"))) {
			if ($_G["cache"]["plugin"]["study_720panorama"]["study_security_radio"]) {
				foreach ($_var_3 as $_var_6) {
					if (preg_match("/" . preg_quote($_var_6, "/") . "\$/i", $_var_5["host"])) {
						$_var_4 = true;
						break;
					}
				}
				if (!$_var_4 && preg_match("/^" . preg_quote("720yun.com", "/") . "\$/i", $_var_5["host"])) {
					$_var_4 = true;
				}
			} else {
				$_var_4 = true;
			}
		}
		if ($_var_4) {
			if (defined("IN_MOBILE")) {
				$_var_2 = "<p><iframe src=\"" . $_arg_0[2] . "\" style=\"" . $_G["cache"]["plugin"]["study_720panorama"]["touch_css"] . "\" allowfullscreen>" . $_arg_0[2] . "</iframe></p>";
			} else {
				$_var_2 = "<p><iframe src=\"" . $_arg_0[2] . "\" style=\"" . $_G["cache"]["plugin"]["study_720panorama"]["pc_css"] . "\" allowfullscreen=\"allowfullscreen\">" . $_arg_0[2] . "</iframe></p>";
			}
		} else {
			$_var_2 = "<p>" . $_arg_0[2] . "</p>";
		}
	} else {
		$_var_2 = $_arg_0[0];
	}
	return $_var_2;
}
	if (!defined("IN_DISCUZ")) {
		echo "https://dism.Taobao.com/?@study_720panorama.plugin";
		return 0;
	}