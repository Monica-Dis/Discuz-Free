<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_kuang_rob_formula_status($_arg_0)
{
	$_var_1 = array("flag" => false);
	foreach ($_arg_0 as $_var_2 => $_var_3) {
		if ($_var_3["type"] == 1) {
			if ($_var_3["status"]) {
				$_var_1["credit"] = $_var_1["flag"] = true;
			}
		} else {
			if ($_var_3["type"] == 2) {
				if ($_var_3["status"]) {
					$_var_1["miner"] = $_var_1["flag"] = true;
				}
			} else {
				if ($_var_3["type"] == 3) {
					if ($_var_3["status"]) {
						$_var_1["crystal"] = $_var_1["flag"] = true;
					}
				} else {
					if ($_var_3["type"] == 4 && $_var_3["oretype"]) {
						if ($_var_3["status"]) {
							$_var_1["ore"][$_var_3["oretype"]] = $_var_1["flag"] = true;
						}
					}
				}
			}
		}
	}
	return $_var_1;
}
function addon_kuang_rob_set2str($_arg_0)
{
	$_var_1 = array("str", "rand");
	$_arg_0 = explode(",", $_arg_0);
	$_arg_0[1] = dintval($_arg_0[1]);
	$_arg_0[1] = dintval($_arg_0[1]);
	if ($_arg_0[1] <= 0) {
		if ($_arg_0[0] <= 0) {
			$_var_1 = array("str" => 0, "rand" => 0);
		} else {
			$_var_1 = array("str" => $_arg_0[0], "rand" => $_arg_0[0]);
		}
	} else {
		if ($_arg_0[0] <= 0) {
			$_var_1 = array("str" => "0-" . $_arg_0[1], "rand" => rand(0, $_arg_0[1]));
		} else {
			if ($_arg_0[0] == $_arg_0[1]) {
				$_var_1 = array("str" => $_arg_0[0], "rand" => $_arg_0[0]);
			} else {
				$_var_2 = min($_arg_0[0], $_arg_0[1]);
				$_arg_0[1] = max($_arg_0[0], $_arg_0[1]);
				$_arg_0[0] = $_var_2;
				$_var_1 = array("str" => $_arg_0[0] . "-" . $_arg_0[1], "rand" => rand($_arg_0[0], $_arg_0[1]));
			}
		}
	}
	return $_var_1;
}
function addon_kuang_rob_lottery($_arg_0)
{
	$_var_1 = 0;
	if ($_arg_0 >= 100) {
		$_var_1 = 1;
	} else {
		if ($_arg_0 >= 0) {
			$_var_2 = array_fill(0, $_arg_0, 1);
			$_var_3 = array_fill(0, 100 - $_arg_0, 0);
			$_var_4 = array_merge($_var_2, $_var_3);
			shuffle($_var_4);
			$_var_5 = mt_rand(0, 99);
			return $_var_4[$_var_5];
		}
	}
	return $_var_1;
}
function addon_kuang_rob_formula_init($_arg_0, $_arg_1)
{
	$_var_2 = array();
	foreach ($_arg_0 as $_var_3 => $_var_4) {
		if ($_var_4["type"] == 1) {
			if ($_var_2["extcredits"]) {
				unset($_arg_0[$_var_3]);
				C::t("#addon_kuang_rob#addon_kuang_rob_formula")->delete_by_where(array("id" => $_var_4["id"]), true);
			} else {
				$_var_2["extcredits"] = true;
			}
		} else {
			if ($_var_4["type"] == 2) {
				if ($_var_2["miner"]) {
					unset($_arg_0[$_var_3]);
					C::t("#addon_kuang_rob#addon_kuang_rob_formula")->delete_by_where(array("id" => $_var_4["id"]), true);
				} else {
					$_var_2["miner"] = true;
				}
			} else {
				if ($_var_4["type"] == 3) {
					if ($_var_2["crystal"]) {
						unset($_arg_0[$_var_3]);
						C::t("#addon_kuang_rob#addon_kuang_rob_formula")->delete_by_where(array("id" => $_var_4["id"]), true);
					} else {
						$_var_2["crystal"] = true;
					}
				} else {
					if ($_var_4["type"] == 4 && $_var_4["oretype"]) {
						$_var_2["ore"][$_var_4["oretype"]] = true;
					} else {
						unset($_arg_0[$_var_3]);
						C::t("#addon_kuang_rob#addon_kuang_rob_formula")->delete_by_where(array("id" => $_var_4["id"]), true);
					}
				}
			}
		}
	}
	$_var_5 = array("type" => 1, "expend" => "1,5", "gain" => "5,10", "probability" => 60, "protect" => 10, "condition" => 10, "oretype" => 0, "status" => 0, "dateline" => $_var_6["timestamp"]);
	if (!$_var_2["extcredits"]) {
		$_var_5["type"] = 1;
		$_var_5["oretype"] = 0;
		$_var_7 = C::t("#addon_kuang_rob#addon_kuang_rob_formula")->insert($_var_5, 1);
		$_arg_0[$_var_7] = array_merge($_var_5, array("id" => $_var_7));
	}
	if (!$_var_2["miner"]) {
		$_var_5["type"] = 2;
		$_var_5["oretype"] = 0;
		$_var_7 = C::t("#addon_kuang_rob#addon_kuang_rob_formula")->insert($_var_5, 1);
		$_arg_0[$_var_7] = array_merge($_var_5, array("id" => $_var_7));
	}
	if (!$_var_2["crystal"]) {
		$_var_5["type"] = 3;
		$_var_5["oretype"] = 0;
		$_var_7 = C::t("#addon_kuang_rob#addon_kuang_rob_formula")->insert($_var_5, 1);
		$_arg_0[$_var_7] = array_merge($_var_5, array("id" => $_var_7));
	}
	foreach ($_arg_1 as $_var_8) {
		if (!$_var_2["ore"][$_var_8["id"]]) {
			$_var_5["type"] = 4;
			$_var_5["oretype"] = $_var_8["id"];
			$_var_7 = C::t("#addon_kuang_rob#addon_kuang_rob_formula")->insert($_var_5, 1);
			$_arg_0[$_var_7] = array_merge($_var_5, array("id" => $_var_7));
		}
	}
	return $_arg_0;
}
function addon_kuang_rob_check()
{
	addon_kuang_rob_validator();
	$_var_0 = '';
	$_var_1 = DISCUZ_ROOT . "./source/plugin/addon_kuang_rob/demo.php";
	if ($_var_2 = @fopen($_var_1, "r")) {
		$_var_0 = fread($_var_2, filesize($_var_1));
		fclose($_var_2);
	}
	$_var_0 = NULL;
}
function addon_kuang_rob_cleardir($_arg_0)
{
}
function addon_kuang_rob_deltree($_arg_0)
{
}
function addon_kuang_rob_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}
	if (!defined("IN_ADMINCP")) {
		if ($_GET["r_check"]) {
			addon_kuang_rob_check();
		}
	}
	if ($_var_0["adminid"] > 0 || $_var_0["uid"] == 1) {
	}