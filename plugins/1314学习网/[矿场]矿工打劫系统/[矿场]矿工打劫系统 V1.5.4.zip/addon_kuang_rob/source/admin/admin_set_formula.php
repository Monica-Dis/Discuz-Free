<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	require_once libfile("function/core", "plugin/addon_kuang_rob/source");
	$_var_11 = array("list", "edit", "group", "category");
	$op = in_array($_GET["op"], $_var_11) ? $_GET["op"] : "list";
	$_var_12 = $_G["cache"]["plugin"]["addon_kuang"];
	if ($op == "list") {
		if (!submitcheck("submit")) {
			s_shownav("sort", "sorts_admin");
			echo "<div id=\"my_addonlist\"></div>";
			showtips("\r\n\t    <li>&#x8BF7;&#x8BBE;&#x7F6E;&#x597D;&#x6253;&#x52AB;&#x6D88;&#x8017;&#x3001;&#x6253;&#x52AB;&#x6210;&#x529F;&#x83B7;&#x5F97;&#x3001;&#x6253;&#x52AB;&#x6210;&#x529F;&#x6982;&#x7387;&#x540E;&#x518D;&#x5F00;&#x542F;&#x89C4;&#x5219;</li>\r\n\t    <li>&#x6240;&#x6709;&#x89C4;&#x5219;&#x90FD;&#x5173;&#x95ED;&#x7684;&#x8BDD;&#x524D;&#x53F0;&#x5C06;&#x63D0;&#x793A;&#x6253;&#x52AB;&#x7CFB;&#x7EDF;&#x5DF2;&#x5173;&#x95ED;</li>\r\n\t    ");
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			showtableheader('');
			$_var_13 = array();
			$_var_13 = C::t("#addon_kuang#addon_kuang_oretype")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
			showsubtitle(array("&#x7C7B;&#x578B;", '', "&#x72B6;&#x6001;", "&#x6253;&#x52AB;&#x6D88;&#x8017;", "&#x6253;&#x52AB;&#x6210;&#x529F;&#x83B7;&#x5F97;", "&#x6253;&#x52AB;&#x6210;&#x529F;&#x6982;&#x7387;", "&#x88AB;&#x6253;&#x52AB;&#x8005;&#x6700;&#x4F4E;&#x503C;", "&#x6253;&#x52AB;&#x8005;&#x6700;&#x4F4E;&#x503C;", ''));
			$_var_14 = C::t("#addon_kuang_rob#addon_kuang_rob_formula")->fetch_all_by_search(array(), array("type" => "ASC", "id" => "ASC"));
			$_var_14 = addon_kuang_rob_formula_init($_var_14, $_var_13);
			foreach ($_var_14 as $_var_15) {
				if ($_var_15["type"] == 1) {
					$_var_15["name"] = "<img src=\"source/plugin/addon_kuang/images/money.png\" width=\"15\" height=\"15\"/> " . $_G["setting"]["extcredits"][$_var_12["extid"]]["title"];
				} else {
					if ($_var_15["type"] == 2) {
						$_var_15["name"] = "<img src=\"source/plugin/addon_kuang/images/kuanggong.png\" width=\"15\" height=\"15\"/> &#x77FF;&#x5DE5;";
					} else {
						if ($_var_15["type"] == 3) {
							$_var_15["name"] = "<img src=\"source/plugin/addon_kuang/images/shuijin.png\" width=\"15\" height=\"15\"/> &#x6C34;&#x6676;";
						} else {
							if ($_var_15["type"] == 4 && $_var_15["oretype"]) {
								$_var_15["name"] = ($_var_13[$_var_15["oretype"]]["icon"] ? "<img src=\"" . $_var_13[$_var_15["oretype"]]["icon"] . "\" width=\"15\" height=\"15\"/> " : '') . $_var_13[$_var_15["oretype"]]["name"];
							} else {
								continue;
							}
						}
					}
				}
				$_var_15["expend"] = dintval(explode(",", $_var_15["expend"]), true);
				$_var_15["gain"] = dintval(explode(",", $_var_15["gain"]), true);
				$_var_15["probability"] = dintval(explode(",", $_var_15["probability"]), true);
				$_var_15["protect"] = dintval($_var_15["protect"]);
				$_var_15["condition"] = dintval($_var_15["condition"]);
				showtablerow('', array(" style=\"width:100px;\"", " style=\"width:20px;\"", " style=\"width:100px;\"", " style=\"width:150px;\"", " style=\"width:150px;\"", " style=\"width:150px;\"", " style=\"width:130px;\"", " style=\"width:130px;\""), array($_var_15["name"], "<img src=\"" . ($_var_15["status"] == 1 ? "static/image/common/access_allow.gif" : "static/image/common/access_disallow.gif") . "\" width=\"15\" height=\"15\"/>", "<select name=status[" . $_var_15["id"] . "]\"><option value=\"0\" " . (!($_var_15["status"] == 1) ? "selected=\"selected\"" : '') . ">&#x5173;&#x95ED;</option><option value=\"1\" " . ($_var_15["status"] == 1 ? "selected=\"selected\"" : '') . ">&#x5F00;&#x542F;</option></select>", "<input type=\"text\" name=\"expend1[" . $_var_15["id"] . "]\" value=\"" . $_var_15["expend"][0] . "\"  style=\"width: 50px;height: 20px;\"> - <input type=\"text\" name=\"expend2[" . $_var_15["id"] . "]\" value=\"" . $_var_15["expend"][1] . "\" style=\"width: 50px;height: 20px;\">", "<input type=\"text\" name=\"gain1[" . $_var_15["id"] . "]\" value=\"" . $_var_15["gain"][0] . "\"  style=\"width: 50px;height: 20px;\"> - <input type=\"text\" name=\"gain2[" . $_var_15["id"] . "]\" value=\"" . $_var_15["gain"][1] . "\" style=\"width: 50px;height: 20px;\">", "<input type=\"text\" name=\"probability1[" . $_var_15["id"] . "]\" value=\"" . $_var_15["probability"][0] . "\"  style=\"width: 50px;height: 20px;\"> - <input type=\"text\" name=\"probability2[" . $_var_15["id"] . "]\" value=\"" . $_var_15["probability"][1] . "\" style=\"width: 50px;height: 20px;\">", "<input type=\"text\" name=\"protect[" . $_var_15["id"] . "]\" value=\"" . $_var_15["protect"] . "\" style=\"width: 100px;height: 20px;\">", "<input type=\"text\" name=\"condition[" . $_var_15["id"] . "]\" value=\"" . $_var_15["condition"] . "\" style=\"width: 100px;height: 20px;\">", ''));
			}
			showsubmit("submit", "submit", '');
			showtablefooter();
			showformfooter();
			echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"></div>\r\n\t\t<script type=\"text/javascript\">\$(\"my_addonlist_js\").src= \"\";\$(\"my_addonlist\").innerHTML = \$(\"my_addonlist_temp\").innerHTML;</script>";
		} else {
			if (is_array($_POST["status"])) {
				foreach ($_POST["status"] as $_var_16 => $_var_17) {
					$_var_18 = array("expend" => dintval($_POST["expend1"][$_var_16]) . "," . dintval($_POST["expend2"][$_var_16]), "gain" => dintval($_POST["gain1"][$_var_16]) . "," . dintval($_POST["gain2"][$_var_16]), "probability" => dintval($_POST["probability1"][$_var_16]) . "," . dintval($_POST["probability"][$_var_16]), "protect" => dintval($_POST["protect"][$_var_16]), "condition" => dintval($_POST["condition"][$_var_16]), "status" => $_var_17 == 1 ? 1 : 0);
					C::t("#addon_kuang_rob#addon_kuang_rob_formula")->update($_var_16, $_var_18);
				}
			}
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	}