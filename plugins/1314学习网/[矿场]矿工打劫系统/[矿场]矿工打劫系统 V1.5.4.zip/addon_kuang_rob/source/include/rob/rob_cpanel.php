<?php

/**
 * Copyright 2001-2099 Dism.Taobbao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: rob_cpanel.php 8959 2019-12-24 18:57:10
 * Ӧ���ۺ����⣺http://dism.taobao.com/?services.php?mod=issue������ https://dism.taobao.com��
 * Ӧ����ǰ��ѯ��dism.taobao.com
 * Ӧ�ö��ƿ�����dism.taobao.com
 * �����Ϊ 1314ѧϰ����dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
exit('2018091117LQ2xdantqc');
}
$todaytime = strtotime(dgmdate($_G['timestamp'], 'Y-m-d', $_G['setting']['timeoffset']));# https://dism.taobao.com
$rob_member = C::t('#addon_kuang#addon_kuang_member')->fetch_by_search(array('uid' => $_GET['robuid'], 'status' => 1));/*���棺 https://dism.taobao.com*/
if(empty($rob_member)){
showmessage($splugin_rob_lang['slang_007']);//  https://dism.taobao.com
}# www_dz-x_net
if($rob_member['uid'] == $_G['uid']){
showmessage($splugin_rob_lang['slang_008']);//  DZ�����W
}
$_GET['type'] = dintval($_GET['type']);
$m5m07r__ = "���棺 https://dism.taobao.com";
$_GET['oretypeid'] = dintval($_GET['oretypeid']);
if($_GET['type'] == 1){
if(!$formula_status['credit']){
showmessage($splugin_rob_lang['slang_005']);
}#�����Ϊ DZ �� �� ����www . dz-x . net�� ����������ԭ�����, ����ӵ�а�Ȩ
$formula = C::t('#addon_kuang_rob#addon_kuang_rob_formula')->fetch_by_search(array('type' => 1));# http://suo.im/5D3dJB
$type_name = $_G['setting']['extcredits'][$splugin_setting['extid']]['title'];
$count = C::t('common_member_count')->fetch($rob_member['uid']);
$type_number = $count['extcredits'.$splugin_setting['extid']];
$jnb81hrv = "DZ�����W";
$my_number = $_G['member']['extcredits'.$splugin_setting['extid']];
}elseif($_GET['type'] == 2){
if(!$formula_status['miner']){
showmessage($splugin_rob_lang['slang_005']);
}
$formula = C::t('#addon_kuang_rob#addon_kuang_rob_formula')->fetch_by_search(array('type' => 2));
$type_name = $splugin_rob_lang['slang_006'];
$type_number = $rob_member['miner'];
$my_number = $kuang_member['miner'];
}elseif($_GET['type'] == 3){
if(!$formula_status['crystal']){
showmessage($splugin_rob_lang['slang_005']);
$q0tz1a_x = "���棺 https://dism.taobao.com";
}
$formula = C::t('#addon_kuang_rob#addon_kuang_rob_formula')->fetch_by_search(array('type' => 3));
$type_name = $splugin_rob_lang['slang_009'];
$_1sop14x = "DZ�����W";
$type_number = $rob_member['crystal'];/*DISM��Taobao��Com*/
$my_number = $kuang_member['crystal'];
}elseif($_GET['type'] == 4 && $_GET['oretypeid']){
if(!$formula_status['ore'][$_GET['oretypeid']]){
showmessage($splugin_rob_lang['slang_005']);
}
$formula = C::t('#addon_kuang_rob#addon_kuang_rob_formula')->fetch_by_search(array('type' => 4, 'oretype' => $_GET['oretypeid']));#From addon_dz-x_net
$type_name = $oretypelist[$formula['oretype']]['name'];
$count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_by_search(array('uid' => $rob_member['uid'], 'oretype' => $formula['oretype']));
$type_number = dintval($count['number']);
$my_number = dintval($member_count[$formula['oretype']]['number']);
}else{
showmessage($splugin_rob_lang['slang_010']);
}
$mugged_log = C::t('#addon_kuang_rob#addon_kuang_rob_log')->fetch_by_search(array('uid' => $_GET['robuid'], 'dateline' => $todaytime));
if(!empty($mugged_log) && $addon_kuang_rob['mugged_max'] > 0 && $mugged_log['mugged'] >= $addon_kuang_rob['mugged_max']){
showmessage($rob_member['username'].' '.$splugin_rob_lang['slang_011']);
}
$rob_log = C::t('#addon_kuang_rob#addon_kuang_rob_log')->fetch_by_search(array('uid' => $_G['uid'], 'dateline' => $todaytime));
if(!empty($rob_log) && $addon_kuang_rob['rob_max'] > 0 && $rob_log['rob'] >= $addon_kuang_rob['rob_max']){
showmessage(str_replace('{rob_max}', $addon_kuang_rob['rob_max'], $splugin_rob_lang['slang_012']));/*DZ_��_��_��*/
}
if($type_number <= 0 || ($formula['protect'] && $type_number <= $formula['protect'])){
showmessage(str_replace('{type_name}', $type_name, $splugin_rob_lang['slang_013']));
}elseif($formula['condition'] && $my_number < $formula['condition']){
showmessage(str_replace(array('{type_name}', '{condition}'), array($type_name, $formula['condition']), $splugin_rob_lang['slang_014']));
}elseif($my_number <= 0){
showmessage(str_replace(array('{type_name}'), array($type_name), $splugin_rob_lang['slang_015']));
}# DISM��Taobao��Com
$formula['expend'] = addon_kuang_rob_set2str($formula['expend']);
$formula['gain'] = addon_kuang_rob_set2str($formula['gain']);
$formula['gain']['rand'] = min($formula['gain']['rand'], $type_number);#www_dz-x_net
$formula['probability'] = addon_kuang_rob_set2str($formula['probability']);
$formula['probability']['str'] .= '%';//  DZ�����W
if($addon_kuang_rob['hood_radio'] && $addon_kuang_rob['hood_probability'] && $type_number > $my_number){
	$formula['probability']['str'] .= '<b class="red"> + '.dintval($addon_kuang_rob['hood_probability']).'%</b>';
	$formula['probability']['rand'] += dintval($addon_kuang_rob['hood_probability']);
}

if (submitcheck('submit')) {
	$lottery = addon_kuang_rob_lottery($formula['probability']['rand']);
	if($_GET['type'] == 1){
		if($formula['expend']['rand']){
			updatemembercount($_G['uid'], array('extcredits'.$splugin_setting['extid'] => - $formula['expend']['rand']));
		}
		if($lottery && $formula['gain']['rand']){
			updatemembercount($_G['uid'], array('extcredits'.$splugin_setting['extid'] => $formula['gain']['rand']));
			updatemembercount($rob_member['uid'], array('extcredits'.$splugin_setting['extid'] => - $formula['gain']['rand']));
		}
	}elseif($_GET['type'] == 2){
		if($formula['expend']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET miner = miner - '".min($formula['expend']['rand'], $my_number)."' WHERE uid='$_G[uid]'", 'UNBUFFERED');
		}
		if($lottery && $formula['gain']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET miner = miner + '".$formula['gain']['rand']."' WHERE uid='$_G[uid]'", 'UNBUFFERED');
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET miner = miner - '".$formula['gain']['rand']."' WHERE uid='$rob_member[uid]'", 'UNBUFFERED');
		}
	}elseif($_GET['type'] == 3){
		if($formula['expend']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET crystal = crystal - '".min($formula['expend']['rand'], $my_number)."' WHERE uid='$_G[uid]'", 'UNBUFFERED');
		}
		if($lottery && $formula['gain']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET crystal = crystal + '".$formula['gain']['rand']."' WHERE uid='$_G[uid]'", 'UNBUFFERED');
			DB::query('UPDATE '.DB::table('addon_kuang_member')." SET crystal = crystal - '".$formula['gain']['rand']."' WHERE uid='$rob_member[uid]'", 'UNBUFFERED');
		}
	}elseif($_GET['type'] == 4){
		if($formula['expend']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member_count')." SET number = number - '".min($formula['expend']['rand'], $my_number)."' WHERE uid='$_G[uid]' AND oretype='$formula[oretype]'", 'UNBUFFERED');
		}
		if($lottery && $formula['gain']['rand']){
			DB::query('UPDATE '.DB::table('addon_kuang_member_count')." SET number = number + '".$formula['gain']['rand']."' WHERE uid='$_G[uid]' AND oretype='$formula[oretype]'", 'UNBUFFERED');
			DB::query('UPDATE '.DB::table('addon_kuang_member_count')." SET number = number - '".$formula['gain']['rand']."' WHERE uid='$rob_member[uid]' AND oretype='$formula[oretype]'", 'UNBUFFERED');
		}
	}
	
	if($addon_kuang_rob['mugged_max'] > 0){
		if(empty($mugged_log)){
			C::t('#addon_kuang_rob#addon_kuang_rob_log')->insert(array('uid' => $_GET['robuid'], 'mugged' => 1, 'dateline' => $todaytime));
		}else{
			DB::query('UPDATE '.DB::table('addon_kuang_rob_log')." SET mugged = mugged + 1 WHERE uid='".intval($_GET['robuid'])."'", 'UNBUFFERED');
		}
	}
	
	if($addon_kuang_rob['rob_max'] > 0){
		if(empty($rob_log)){
			C::t('#addon_kuang_rob#addon_kuang_rob_log')->insert(array('uid' => $_G['uid'], 'rob' => 1, 'dateline' => $todaytime));
		}else{
			DB::query('UPDATE '.DB::table('addon_kuang_rob_log')." SET rob = rob + 1 WHERE uid='$_G[uid]'", 'UNBUFFERED');
		}
	}
	
	$find = array('{robuser}', '{type_number}', '{type_name}', '{expend}', '{gain}', '{probability}');
	$replace = array($rob_member['username'], $type_number, $type_name, $formula['expend']['rand'], $formula['gain']['rand'], $formula['probability']['rand']);
	if($lottery && $formula['gain']['rand']){
		$msg = str_replace($find, $replace, $splugin_rob_lang['slang_001']);
		notification_add($rob_member['uid'], 'system', str_replace(':', '&#58;', str_replace(array('{username}', '{type_name}', '{number}'), array($_G['username'], $type_name, $formula['gain']['rand']), $splugin_rob_lang['slang_016'])), '', 1);
	}else{
		$msg = str_replace($find, $replace, $splugin_rob_lang['slang_002']);
	}
	addon_add_log($msg);
	showmessage($msg, 'kuang.php?mod=rob', 'succeed');
}else{
	$find = array('{robuser}', '{type_number}', '{type_name}', '{expend}', '{gain}', '{probability}');
	$replace = array($rob_member['username'], $type_number, $type_name, $formula['expend']['str'], $formula['gain']['str'], $formula['probability']['str']);
	$addon_kuang_rob['rob_tips'] = str_replace($find, $replace, $addon_kuang_rob['rob_tips']);
	include template('addon_kuang_rob:kuang_cpanel');
}


//Copyright 2001-2099 .DZ�������.
//This is NOT a freeware, use is subject to license terms
//$Id: rob_cpanel.php 9421 2019-12-24 10:57:10
//Ӧ���ۺ����⣺http://dism.taobao.com/?services.php?mod=issue ������ https://dism.taobao.com��
//Ӧ����ǰ��ѯ��QQ 1909.859.577
//Ӧ�ö��ƿ�����QQ 190.985.9577
//�����Ϊ DZ-�������www.d'.'z-x.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��