<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 20160621192CzBa5zHaF
 * This is NOT a freeware, use is subject to license terms
 * From www.d'.'iszz.net
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once ('pluginvar.func.php');
$s_installlang = array(
	'plugininstall' => '&#x5B89;&#x88C5;',
	'pluginupgrade' => '&#x5347;&#x7EA7;',
	'pluginuninstall' => '&#x5378;&#x8F7D;',
	'ilang_guide' => '&#x5411;&#x5BFC;',
	'ilang_check' => '&#x6821;&#x9A8C;&#x7A0B;&#x5E8F;',
	'ilang_check_ok' => '&#x63D2;&#x4EF6;&#x6587;&#x4EF6;&#x5B8C;&#x6574;&#x6027;&#x68C0;&#x67E5;&#x901A;&#x8FC7;&#xFF0C;&#x6B63;&#x5728;&#x51C6;&#x5907;{operation}...',
	'ilang_sql' => '&#x6570;&#x636E;&#x5E93;&#x66F4;&#x65B0;',
	'ilang_sql_delete' => '<font color=red size=4><b>&#x786E;&#x8BA4;&#x5220;&#x9664;&#x63D2;&#x4EF6;&#x6570;&#x636E;&#x5E93;? &#x672C;&#x64CD;&#x4F5C;&#x4E0D;&#x53EF;&#x9006;</b></font><br>(&#x5982;&#x5E0C;&#x671B;&#x4FDD;&#x5B58;&#x6570;&#x636E;&#x5E93;&#x4E2D;&#x7684;&#x6570;&#x636E;&#x4E0B;&#x6B21;&#x5B89;&#x88C5;&#x65F6;&#x4F7F;&#x7528;&#xFF0C;&#x8BF7;&#x9009;&#x62E9;&#x53D6;&#x6D88;)',
	'ilang_sql_ok' => '&#x6570;&#x636E;&#x5E93;&#x66F4;&#x65B0;&#x5B8C;&#x6210;&#xFF0C;&#x6B63;&#x5728;&#x5B8C;&#x6210;{operation}...',
	'ilang_stat' => '&#x7F13;&#x5B58;&#x6E05;&#x7406;',
	'ilang_stat_agree' => '<font color=red size=4><b>&#x662F;&#x5426;&#x53D1;&#x9001;&#x5E94;&#x7528;&#x53CD;&#x9988;&#x4FE1;&#x606F;&#xFF0C;&#x4EE5;&#x4FBF;&#x5E2E;&#x52A9;&#x63D2;&#x4EF6;&#x6539;&#x8FDB;&#xFF0C;&#x83B7;&#x5F97;&#x66F4;&#x591A;&#x6280;&#x672F;&#x652F;&#x6301;&#xFF1F;</b></font><br>(&#x53CD;&#x9988;&#x7684;&#x4FE1;&#x606F;&#x5305;&#x62EC;Discuz!&#x7248;&#x672C;&#x3001;&#x7F51;&#x7AD9;&#x5730;&#x5740;&#x3001;&#x5B89;&#x88C5;&#x65F6;&#x95F4;&#x7B49;&#x4FE1;&#x606F;)',
	'ilang_stat_ok' => '{operation}&#x6210;&#x529F;&#xFF0C;&#x6B63;&#x5728;&#x6E05;&#x7406;&#x7F13;&#x5B58;...{stat_code}<br>&#x6E05;&#x7406;&#x7F13;&#x5B58;&#x5B8C;&#x6210;&#xFF01;',
	'ilang_addon' => '&#x5E94;&#x7528;&#x63A8;&#x8350;',
	'ilang_ok' => '&#x5B8C;&#x6210;',
);

?>