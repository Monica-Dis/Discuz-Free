<?php

function zzbuluo_seo_gidrewrite_rewrite()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["zzbuluo_seo_gidrewrite"];
	if ($_var_1["study_radio"]) {
		$_G["setting"]["output"]["preg"]["search"]["forum_forumdisplay_gid"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?forum\\.php\\?gid=(\\d+)\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["forum_forumdisplay_gid"] = "zzbuluo_seo_gidrewrite_rewriteoutput('forum_forumdisplay_gid', 0, '\\2', '\\3', '\\4')";
		if ($_var_1["forum_index"]) {
			$_G["setting"]["output"]["preg"]["search"]["forum_index"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?forum\\.php\"([^\\>]*)\\>/";
			$_G["setting"]["output"]["preg"]["replace"]["forum_index"] = "zzbuluo_seo_gidrewrite_rewriteoutput('forum_index', 0, '\\2', '', '\\4')";
		}
		$_var_2 = array("forum_forumdisplay_gid", "forum_index");
		if ($_var_1["dz_version"] <= 1) {
			if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
				$_var_3 = true;
			} else {
				if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
					$_var_3 = true;
				}
			}
		} else {
			if ($_var_1["dz_version"] == 3) {
				$_var_3 = true;
			}
		}
		if ($_var_3) {
			foreach ($_var_2 as $_var_4 => $_var_5) {
				if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_5])) {
					$_G["setting"]["output"]["preg"]["replace"][$_var_5] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_5]);
				}
			}
		} else {
			foreach ($_var_2 as $_var_4 => $_var_5) {
				if (isset($_G["setting"]["output"]["preg"]["search"][$_var_5])) {
					$_G["setting"]["output"]["preg"]["search"][$_var_5] = $_G["setting"]["output"]["preg"]["search"][$_var_5] . "e";
				}
			}
		}
	}
}
function zzbuluo_seo_gidrewrite_rewriteoutput($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	list(, , , $_var_4, $_var_5) = func_get_args();
	$_var_6 = array("{gid}" => $_var_4);
	$_var_7 = str_replace(array_keys($_var_6), $_var_6, $_G["cache"]["plugin"]["zzbuluo_seo_gidrewrite"][$_arg_0]);
	if (!$_arg_1) {
		return "<a href=\"" . $_arg_2 . $_var_7 . "\"" . (!empty($_var_5) ? stripslashes($_var_5) : '') . ">";
	}
	return $_arg_2 . $_var_7;
}
function zzbuluo_seo_gidrewrite_check()
{
}
function zzbuluo_seo_gidrewrite_cleardir($_arg_0)
{
}
function zzbuluo_seo_gidrewrite_deltree($_arg_0)
{
}
function zzbuluo_seo_gidrewrite_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		zzbuluo_seo_gidrewrite_rewrite();
		if ($_GET["download_check"]) {
			zzbuluo_seo_gidrewrite_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			zzbuluo_seo_gidrewrite_check();
		}
	}