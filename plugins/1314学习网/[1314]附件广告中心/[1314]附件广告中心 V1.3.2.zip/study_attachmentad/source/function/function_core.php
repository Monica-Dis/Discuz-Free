<?php

function study_attachmentad_ad($_arg_0 = null)
{
	$_var_1 = "#<a href=\"forum.php\\?mod=attachment([^\"]+)\" target=\"_blank\">#iUs";
	preg_match_all($_var_1, $_arg_0["message"], $_var_2);
	if (!empty($_var_2)) {
		foreach ($_var_2[0] as $_var_3 => $_var_4) {
			$_var_5 = $_var_4;
			$_var_6 = "<a href=\"javascript:;\" onclick=\"showWindow('study_attachmentad','plugin.php?id=study_attachmentad:ad" . $_var_2[1][$_var_3] . "');return false;\">";
			$_arg_0["message"] = str_replace($_var_5, $_var_6, $_arg_0["message"]);
		}
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}