<?php

function addon_seo_portalrewrite_rewrite()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_seo_portalrewrite"];
	if ($_var_1["study_radio"]) {
		if ($_G["adminid"] == 1 && $_GET["action"] == "newthread" || $_GET["check"] == "yes") {
		}
		if (is_array($_G["setting"]["domain"]["app"])) {
			$_var_2 = empty($_G["setting"]["domain"]["app"]["default"]) ? "{CURHOST}" : $_G["setting"]["domain"]["app"]["default"];
			$_var_3 = $_G["setting"]["domain"]["app"];
			$_var_4 = $_var_3["portal"];
			$_var_5 = "portal\\.php";
			if (!$_var_4) {
				$_var_4 = $_var_2;
			}
			if ($_var_4 != "{CURHOST}") {
				$_var_4 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_var_4 . $_G["siteport"] . "/";
			}
			if ($_var_3["portal"]) {
				$_G["domain"]["pregxprw"]["portal"] = "<a href\\=\"(" . preg_quote($_var_4, "/") . ")" . $_var_5;
				$_G["domain"]["pregxprw"]["portal_category_folder"] = "<a href\\=\"(" . preg_quote($_var_4, "/") . "[\\w\\/]*)?";
			} else {
				$_G["domain"]["pregxprw"]["portal"] = "<a href\\=\"(" . preg_quote($_G["siteurl"], "/") . ")?" . $_var_5;
				$_G["domain"]["pregxprw"]["portal_category_folder"] = "<a href\\=\"(" . preg_quote($_G["siteurl"], "/") . "[\\w\\/]*)?";
			}
		}
		if (!in_array("portal_category", $_G["setting"]["rewritestatus"])) {
			$_G["setting"]["rewritestatus"][] = "portal_category";
		}
		$_G["setting"]["output"]["preg"]["search"]["portal_category"] = "/" . $_G["domain"]["pregxprw"]["portal"] . "\\?mod\\=list&(amp;)?catid\\=(\\d+)(&amp;page\\=(\\d+))?\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["portal_category"] = "addon_seo_portalrewrite_rewriteoutput('portal_category', 0, '\\1', '\\3', '\\5', '\\6')";
		$_G["setting"]["output"]["preg"]["search"]["portal_category_folder"] = "/" . $_G["domain"]["pregxprw"]["portal_category_folder"] . "index\\.php\\?page\\=(\\d+)\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["portal_category_folder"] = "addon_seo_portalrewrite_rewriteoutput('portal_category_folder', 0, '\\1', '\\2', '\\3')";
		$_var_6 = array("portal_category", "portal_category_folder");
		if ($_var_1["dz_version"] <= 1) {
			if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
				$_var_7 = true;
			} else {
				if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
					$_var_7 = true;
				}
			}
		} else {
			if ($_var_1["dz_version"] == 3) {
				$_var_7 = true;
			}
		}
		if ($_var_7) {
			foreach ($_var_6 as $_var_8 => $_var_9) {
				if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_9])) {
					$_G["setting"]["output"]["preg"]["replace"][$_var_9] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_9]);
				}
			}
		} else {
			foreach ($_var_6 as $_var_8 => $_var_9) {
				if (isset($_G["setting"]["output"]["preg"]["search"][$_var_9])) {
					$_G["setting"]["output"]["preg"]["search"][$_var_9] = $_G["setting"]["output"]["preg"]["search"][$_var_9] . "e";
				}
			}
		}
	}
}
function addon_seo_portalrewrite_rewriteoutput($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	if ($_arg_0 == "portal_category") {
		list(, , , $_var_4, $_var_5, $_var_6) = func_get_args();
		$_var_7 = array("{catid}" => $_var_4, "{page}" => $_var_5 ? $_var_5 : 1);
		$_arg_0 = $_var_7["{page}"] > 1 && $_G["cache"]["plugin"]["addon_seo_portalrewrite"][$_arg_0 . "2"] ? $_arg_0 . "2" : $_arg_0;
	} else {
		if ($_arg_0 == "portal_category_folder") {
			list(, , , $_var_5, $_var_6) = func_get_args();
			$_var_7 = array("{page}" => $_var_5 ? $_var_5 : 1);
		}
	}
	$_var_8 = str_replace(array_keys($_var_7), $_var_7, $_G["cache"]["plugin"]["addon_seo_portalrewrite"][$_arg_0]);
	if ($_arg_0 == "portal_category_folder" && $_var_7["{page}"] == 1) {
		$_var_8 = '';
	}
	if (!$_arg_1) {
		return "<a href=\"" . $_arg_2 . $_var_8 . "\"" . (!empty($_var_6) ? stripslashes($_var_6) : '') . ">";
	}
	return $_arg_2 . $_var_8;
}
function addon_seo_portalrewrite_check()
{
}
function addon_seo_portalrewrite_cleardir($_arg_0)
{
}
function addon_seo_portalrewrite_deltree($_arg_0)
{
}
function addon_seo_portalrewrite_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		addon_seo_portalrewrite_rewrite();
		if ($_GET["talrewri_check"]) {
			addon_seo_portalrewrite_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			addon_seo_portalrewrite_check();
		}
	}