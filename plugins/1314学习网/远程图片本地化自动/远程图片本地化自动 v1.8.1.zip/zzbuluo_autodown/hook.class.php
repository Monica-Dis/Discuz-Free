<?php

/**
 * Copyright 2001-2099 DisM-Taobao.
 * This is NOT a freeware, use is subject to license terms
 * $Id: hook.class.php 56673 2020-06-15 15:26:13Z zhuge $
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */
if (!defined('IN_DISCUZ')) {
exit('');
}
class plugin_zzbuluo_autodown
{
     public function __construct()
    {
        require_once libfile('function/core', 'plugin/zzbuluo_autodown/source');
        require_once './source/discuz_version.php';
    }
}

class plugin_zzbuluo_autodown_forum extends plugin_zzbuluo_autodown
{
    public function post_message($param)
    {

        global $_G;
        $param           = $param['param'];
        $tid             = intval($param[2]['tid']);
        $pid             = intval($param[2]['pid']);
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $uid             = $_G['uid'];
        $tlautoextra     = $splugin_setting['zzbuluo_hide_button'] ? 1 : intval($_GET['tlautoextra']);
        if (($param[0] == "post_newthread_succeed" || $param[0] == "post_edit_succeed" || $param[0] == "post_reply_succeed" || $param[0] == "post_newthread_mod_succeed" || $param[0] == "edit_newthread_mod_succeed"  || $param[0] == "audit_edit_succeed") && $tlautoextra && in_array($_G['groupid'], $zzbuluo_groups)) {
            $post = C::t('#zzbuluo_autodown#zzbuluo_autodown')->fetch_by_search(array('pid' => $pid), array('pid' => 'DESC'));
            if ($post['first'] == 1 || $splugin_setting['zzbuluo_fast_radio']) {
                $subject = $post['subject'];
                $message = $post['message'];
                preg_match_all("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]|\[img=\d{1,4}[x|\,]\d{1,4}\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", $message, $image1, PREG_SET_ORDER);
                preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\/?\>/ismU", $message, $image2, PREG_SET_ORDER);
                if (empty($image2)) {
                    preg_match_all("/\<img.+src=('|\"){1}(.*)('|\"){1}([\s].*)?\/?\>/isU", $message, $image2, PREG_SET_ORDER);
                }
                $temp = $aids[] = $existentimg = array();
                if (is_array($image1) && !empty($image1)) {
                    foreach ($image1 as $value) {
                        $temp[] = array(
                            '0' => $value[0],
                            '1' => trim(!empty($value[1]) ? $value[1] : $value[2]),
                        );
                    }
                }
                if (is_array($image2) && !empty($image2)) {
                    foreach ($image2 as $value) {
                        $temp[] = array(
                            '0' => $value[0],
                            '1' => trim($value[2]),
                        );
                    }
                }

                require_once libfile('class/image');
                if (is_array($temp) && !empty($temp)) {
                    $upload      = new discuz_upload();
                    $attachaids  = array();
                    $threadimage = $cover = 0;
                    foreach ($temp as $key => $value) {
                        $imageurl = $value[1];
                        $hash     = md5($imageurl); //

                        if (strlen($imageurl)) {
                            if (!isset($existentimg[$hash])) {
                                $imagereplace['oldimageurl'][$key] = $value[0];
                                $imagereplace['newimageurl'][$key] = $value[0];
                                $existentimg[$hash]                = $imageurl;
                                $attach['ext']                     = $upload->fileext($imageurl);
                                if (!in_array($attach['ext'], array('jpg', 'jpeg', 'gif', 'png', 'bmp'))) {
                                    $attach['ext'] = 'jpg';
                                }

                                $content = '';
                                if (preg_match('/^(https?:\/\/|\.)/i', $imageurl)) {

                                    $content = autodowncurlhttps($imageurl); //dfsockopen
                                } elseif(preg_match('/^(\/\/|\.)/i', $imageurl)){
                                      $content = autodowncurlhttps($imageurl); //dfsockopen
                                } elseif (preg_match('/^(' . preg_quote(getglobal('setting/attachurl'), '/') . ')/i', $imageurl)) {
                                    continue;
                                }
                                if (empty($content)) {
                                    continue;
                                }

                                $censor_pic = false;
                                if (isset($param['censor_picmd5exp']) && !empty($param['censor_picmd5exp'])) {
                                    if (@preg_match($param['censor_picmd5exp'], md5($content))) {
                                        $censor_pic = true;
                                    }
                                }

                                if ($censor_pic) {
                                    $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '';
                                } else {
                                    $patharr              = explode('/', $imageurl);
                                    $attach['name']       = trim($patharr[count($patharr) - 1]);
                                    $attach['thumb']      = '';
                                    $attach['isimage']    = $upload->is_image_ext($attach['ext']);
                                    $attach['extension']  = $upload->get_target_extension($attach['ext']);
                                    $attach['attachdir']  = $upload->get_target_dir('forum');
                                    $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum') . '.' . $attach['extension'];
                                    $attach['target']     = getglobal('setting/attachdir') . './forum/' . $attach['attachment'];

                                    if (!@$fp = fopen($attach['target'], 'wb')) {
                                        continue;
                                    } else {
                                        flock($fp, 2);
                                        fwrite($fp, $content);
                                        fclose($fp);
                                    }
                                    
                                    $imageinfo = $upload->get_image_info($attach['target']);
                                    if(empty($imageinfo)){
                                        zzbuluo_autodown_webp($attach['target'], $content);
                                    }
                                    
                                    if ($imageinfo = $upload->get_image_info($attach['target'])) {
                                        $attach['size'] = filesize($attach['target']);
                                        $upload->attach = $attach;
                                        $thumb          = $width          = 0;

                                        if ($upload->attach['isimage']) {
                                            $image = new image();
                                            if ($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {

                                                //$thumb                  = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                                                $width                  = $image->imginfo['width'];
                                                $height                 = $image->imginfo['height'];
                                                $upload->attach['size'] = $image->imginfo['size'];
                                            }
                                            if ($_G['setting']['thumbstatus']) {

                                                $thumb  = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                                                $width  = $image->imginfo['width'];
                                                $height = $image->imginfo['height'];
                                            }
                                            if ($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                                                list($width) = @getimagesize($upload->attach['target']);
                                            }
                                            if ($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {

                                                $image->Watermark($attach['target'], '', 'forum');
                                                $upload->attach['size'] = $image->imginfo['size'];
                                            }
                                        }

                                        $aids[] = $aid = getattachnewaid();
                                        if ($tid) {
                                            $setarr = array(
                                                'aid'        => $aid,
                                                'tid'        => $tid,
                                                'pid'        => $pid,
                                                'uid'        => $uid,
                                                'dateline'   => $_G['timestamp'],
                                                'filename'   => $subject ? $subject . '-' . ($key + 1) . '.' . $attach['ext'] : $upload->attach['name'],
                                                'filesize'   => $upload->attach['size'],
                                                'attachment' => $upload->attach['attachment'],
                                                'isimage'    => $upload->attach['isimage'],
                                                'thumb'      => $thumb,
                                                'remote'     => '0',
                                                'width'      => $width,
                                            );
                                            
                                                                                        if($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']){
                                                                                            if(getglobal('setting/ftp/on')) {
                                                                                                if(ftpcmd('upload', 'forum/'.$upload->attach['attachment'])) {
                                                                                                    $setarr['remote'] = 1;
                                                                                                    $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
                                                                                                    @unlink($basedir.'/forum/'.$upload->attach['attachment']);
                                                                                                }
                                                                                            }
                                                                                        } 

                                            C::t('forum_attachment_n')->insert('tid:' . $tid, $setarr);
                                            C::t('forum_attachment')->update($aid, array('tid' => $tid, 'pid' => $pid, 'uid' => $uid, 'tableid' => getattachtableid($tid)), true);

                                            if (empty($threadimage)) {
                                                list($width, $height, $type) = !empty($imageinfo) ? $imageinfo : array('', '', '');
                                                if ((!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight'] || $height > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight']) && (!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'] || $attach['size'] > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'])) {
                                                    C::t('forum_threadimage')->insert(array(
                                                        'tid'        => $tid,
                                                        'attachment' => $attach['attachment'],
                                                        'remote'     => $attach['remote'],
                                                    ));
                                                    $threadimage = 1;

                                                    if (!is_array($_G['setting']['forumpicstyle'])) {
                                                        if ($_G['setting']['forumpicstyle']) {
                                                            $_G['setting']['forumpicstyle']                = dunserialize($_G['setting']['forumpicstyle']);
                                                            $_G['setting']['forumpicstyle']['thumbwidth']  = !empty($_G['setting']['forumpicstyle']['thumbwidth']) ? $_G['setting']['forumpicstyle']['thumbwidth'] : 203;
                                                            $_G['setting']['forumpicstyle']['thumbheight'] = !empty($_G['setting']['forumpicstyle']['thumbheight']) ? $_G['setting']['forumpicstyle']['thumbheight'] : 999;
                                                        } else {
                                                            $_G['setting']['forumpicstyle'] = array('thumbwidth' => 203, 'thumbheight' => 999);
                                                        }
                                                    }

                                                    $picsource = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
                                                    $picsource .= 'forum/' . $attach['attachment'];
                                                    $basedir  = !$_G['setting']['attachdir'] ? DISCUZ_ROOT . './data/attachment/' : $_G['setting']['attachdir'];
                                                    $coverdir = 'threadcover/' . substr(md5($tid), 0, 2) . '/' . substr(md5($tid), 2, 2) . '/';
                                                    dmkdir($basedir . './forum/' . $coverdir);
                                                    if ($image->Thumb($picsource, 'forum/' . $coverdir . $tid . '.jpg', $_G['setting']['forumpicstyle']['thumbwidth'], $_G['setting']['forumpicstyle']['thumbheight'], 2)) {
                                                        $remote = '';
                                                        if ($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']) {
                                                            if (getglobal('setting/ftp/on')) {
                                                                if (ftpcmd('upload', 'forum/' . $coverdir . $tid . '.jpg')) {
                                                                    $remote = '-';
                                                                }
                                                            }
                                                        }
                                                        $cover = $remote . '1';
                                                    } else {
                                                        if (@$fp = fopen($basedir . './forum/' . $coverdir . $tid . '.jpg', 'wb')) {
                                                            flock($fp, 2);
                                                            fwrite($fp, $content);
                                                            fclose($fp);
                                                        }
                                                        $cover = '1';
                                                    }
                                                }
                                            }

                                            $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '[attach]' . $aid . '[/attach]';

                                        } else {
                                            $setarr = array(
                                                'aid'        => $aid,
                                                'dateline'   => $_G['timestamp'],
                                                'filename'   => $subject ? $subject . '-' . ($key + 1) . '.' . $attach['ext'] : $upload->attach['name'],
                                                'filesize'   => $upload->attach['size'],
                                                'attachment' => $upload->attach['attachment'],
                                                'isimage'    => $upload->attach['isimage'],
                                                'uid'        => $_G['uid'],
                                                'thumb'      => $thumb,
                                                'remote'     => '0',
                                                'width'      => $width,
                                            );

                                            C::t("forum_attachment_unused")->insert($setarr);
                                            $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '[attachimg]' . $aid . '[/attachimg]';
                                        }
                                    } else {
                                        @unlink($attach['target']);
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($aids)) {
                        if ($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']) {
                            ftpupload($aids, $uid);
                        }
                        if ($tid) {
                            C::t('forum_thread')->update($tid, array('attachment' => 2, 'cover' => $cover), 1);
                        }
                    }

                    $message = str_replace($imagereplace['oldimageurl'], $imagereplace['newimageurl'], $message);

                    if ($tid) {
                        DB::update('forum_post', array('message' => $message, 'attachment' => !empty($aids) ? 2 : 0), 'pid=' . $pid, 1);
                    }

                }
            }
        }

    }
    public function forumdisplay_fastpost_btn_extra()
    {
        global $_G;
        $splugin_setting  = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups   = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums   = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra_fast = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_fast;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio']) {
            include template("zzbuluo_autodown:tlautoextra_fast");
        }
        return $tlautoextra_fast;

    }

    public function viewthread_fastpost_btn_extra()
    {
        global $_G;
        $splugin_setting  = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups   = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums   = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra_fast = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_fast;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio'] && $splugin_setting['zzbuluo_fast_radio']) {
            include template("zzbuluo_autodown:tlautoextra_fast");
        }
        return $tlautoextra_fast;

    }
    public function post_infloat_btn_extra()
    {
        global $_G;
        $splugin_setting   = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups    = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums    = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra_fast2 = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_fast;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio'] && $splugin_setting['zzbuluo_fast_radio']) {
            include template("zzbuluo_autodown:tlautoextra_fast");
        }
        return $tlautoextra_fast2;

    }

    public function post_attribute_extra()
    {
        global $_G;
      
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums  = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra     = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra;
        }
       if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio']) {
            if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra");
        }
        return $tlautoextra;
    }

    public function post_attribute_extra_body()
    {
        global $_G;
        $splugin_setting  = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups   = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums   = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra_body = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_body;
        }
       if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio']) {
            if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra_body");
        }
        return $tlautoextra_body;
    }


        public function post_side_bottom()
    {   

        
        global $_G;
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $zzbyluo_forums  = unserialize($splugin_setting['zzbyluo_forums']);
        $tlautoextra     = '';
        if (constant("DISCUZ_VERSION") != "X2.5") {
            return $tlautoextra;
        }
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra;
        }
        
        if (in_array($_G['groupid'], $zzbuluo_groups) && in_array($_G['fid'], $zzbyluo_forums) && $splugin_setting['zzbuluo_radio']) {
            if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra25");//
        }
        return $tlautoextra;
    }
   

}

class plugin_zzbuluo_autodown_group extends plugin_zzbuluo_autodown_forum
{
    public function post_message($param)
    {
        global $_G;
        $param           = $param['param'];
        $tid             = intval($param[2]['tid']);
        $pid             = intval($param[2]['pid']);
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $uid             = $_G['uid'];
        $deleimages      = array();
        $tlautoextra     = $splugin_setting['zzbuluo_hide_button'] ? 1 : intval($_GET['tlautoextra']);
        if (($param[0] == "post_newthread_succeed" || $param[0] == "post_edit_succeed" || $param[0] == "post_reply_succeed") && $tlautoextra && $splugin_setting['zzbuluo_groups_radio'] ) {
             
            $post = C::t('#zzbuluo_autodown#zzbuluo_autodown')->fetch_by_search(array('pid' => $pid), array('pid' => 'DESC'));
            if ($post['first'] == 1 || $splugin_setting['zzbuluo_fast_radio']) {
                $subject = $post['subject'];
                $message = $post['message'];
                preg_match_all("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]|\[img=\d{1,4}[x|\,]\d{1,4}\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", $message, $image1, PREG_SET_ORDER);
                preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\/?\>/ismU", $message, $image2, PREG_SET_ORDER);
                if (empty($image2)) {
                    preg_match_all("/\<img.+src=('|\"){1}(.*)('|\"){1}([\s].*)?\/?\>/isU", $message, $image2, PREG_SET_ORDER);
                }
                $temp = $aids[] = $existentimg = array();
                if (is_array($image1) && !empty($image1)) {
                    foreach ($image1 as $value) {
                        $temp[] = array(
                            '0' => $value[0],
                            '1' => trim(!empty($value[1]) ? $value[1] : $value[2]),
                        );
                    }
                }
                if (is_array($image2) && !empty($image2)) {
                    foreach ($image2 as $value) {
                        $temp[] = array(
                            '0' => $value[0],
                            '1' => trim($value[2]),
                        );
                    }
                }
                require_once libfile('class/image');
                if (is_array($temp) && !empty($temp)) {
                    $upload      = new discuz_upload();
                    $attachaids  = array();
                    $threadimage = $cover = 0;
                    foreach ($temp as $key => $value) {
                        $imageurl = $value[1];
                        $hash     = md5($imageurl);
                        if (strlen($imageurl)) {
                            if (!isset($existentimg[$hash])) {
                                    $imagereplace['oldimageurl'][$key] = $value[0];
                                $imagereplace['newimageurl'][$key] = $value[0];
                                $existentimg[$hash]                = $imageurl;
                                $attach['ext']                     = $upload->fileext($imageurl);
                                if (!in_array($attach['ext'], array('jpg', 'jpeg', 'gif', 'png', 'bmp'))) {
                                    $attach['ext'] = 'jpg';
                                }
                                $content = '';
                                if (preg_match('/^(https?:\/\/|\.)/i', $imageurl)) {
                                    $content = autodowncurlhttps($imageurl); //dfsockopen
                                }elseif(preg_match('/^(\/\/|\.)/i', $imageurl)){
                                      $content = autodowncurlhttps($imageurl); //dfsockopen
                                }elseif (preg_match('/^(' . preg_quote(getglobal('setting/attachurl'), '/') . ')/i', $imageurl)) {
                                    continue;
                                }
                                if (empty($content)) {
                                    continue;
                                }

                                $censor_pic = false;
                                if (isset($param['censor_picmd5exp']) && !empty($param['censor_picmd5exp'])) {
                                    if (@preg_match($param['censor_picmd5exp'], md5($content))) {
                                        $censor_pic = true;
                                    }
                                }

                                if ($censor_pic) {
                                    $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '';
                                } else {
                                    $patharr              = explode('/', $imageurl);
                                    $attach['name']       = trim($patharr[count($patharr) - 1]);
                                    $attach['thumb']      = '';
                                    $attach['isimage']    = $upload->is_image_ext($attach['ext']);
                                    $attach['extension']  = $upload->get_target_extension($attach['ext']);
                                    $attach['attachdir']  = $upload->get_target_dir('forum');
                                    $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum') . '.' . $attach['extension'];
                                    $attach['target']     = getglobal('setting/attachdir') . './forum/' . $attach['attachment'];

                                    if (!@$fp = fopen($attach['target'], 'wb')) {
                                        continue;
                                    } else {
                                        flock($fp, 2);
                                        fwrite($fp, $content);
                                        fclose($fp);
                                    }
                                    if ($imageinfo = $upload->get_image_info($attach['target'])) {
                                        $attach['size'] = filesize($attach['target']);
                                        $upload->attach = $attach;
                                        $thumb          = $width          = 0;

                                        if ($upload->attach['isimage']) {
                                            if ($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                                                $image = new image();
                                                //$thumb                  = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                                                $width                  = $image->imginfo['width'];
                                                $height                 = $image->imginfo['height'];
                                                $upload->attach['size'] = $image->imginfo['size'];
                                            }
                                            if ($_G['setting']['thumbstatus']) {
                                                $image  = new image();
                                                $thumb  = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                                                $width  = $image->imginfo['width'];
                                                $height = $image->imginfo['height'];
                                            }
                                            if ($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                                                list($width) = @getimagesize($upload->attach['target']);
                                            }
                                            if ($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
                                                $image = new image();
                                                $image->Watermark($attach['target'], '', 'forum');
                                                $upload->attach['size'] = $image->imginfo['size'];
                                            }
                                        }

                                        $aids[] = $aid = getattachnewaid();
                                        if ($tid) {
                                            $setarr = array(
                                                'aid'        => $aid,
                                                'tid'        => $tid,
                                                'pid'        => $pid,
                                                'uid'        => $uid,
                                                'dateline'   => $_G['timestamp'],
                                                'filename'   => $subject ? $subject . '-' . ($key + 1) . '.' . $attach['ext'] : $upload->attach['name'],
                                                'filesize'   => $upload->attach['size'],
                                                'attachment' => $upload->attach['attachment'],
                                                'isimage'    => $upload->attach['isimage'],
                                                'thumb'      => $thumb,
                                                'remote'     => '0',
                                                'width'      => $width,
                                            );

                                            C::t('forum_attachment_n')->insert('tid:' . $tid, $setarr);
                                            C::t('forum_attachment')->update($aid, array('tid' => $tid, 'pid' => $pid, 'uid' => $uid, 'tableid' => getattachtableid($tid)), true);

                                            //设置封面
                                            if (empty($threadimage)) {
                                                list($width, $height, $type) = !empty($imageinfo) ? $imageinfo : array('', '', '');
                                                if ((!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight'] || $height > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight']) && (!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'] || $attach['size'] > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'])) {
                                                    C::t('forum_threadimage')->insert(array(
                                                        'tid'        => $tid,
                                                        'attachment' => $attach['attachment'],
                                                        'remote'     => $attach['remote'],
                                                    ));
                                                    $threadimage = 1;

                                                    if (!is_array($_G['setting']['forumpicstyle'])) {
                                                        if ($_G['setting']['forumpicstyle']) {
                                                            $_G['setting']['forumpicstyle']                = dunserialize($_G['setting']['forumpicstyle']);
                                                            $_G['setting']['forumpicstyle']['thumbwidth']  = !empty($_G['setting']['forumpicstyle']['thumbwidth']) ? $_G['setting']['forumpicstyle']['thumbwidth'] : 203;
                                                            $_G['setting']['forumpicstyle']['thumbheight'] = !empty($_G['setting']['forumpicstyle']['thumbheight']) ? $_G['setting']['forumpicstyle']['thumbheight'] : 999;
                                                        } else {
                                                            $_G['setting']['forumpicstyle'] = array('thumbwidth' => 203, 'thumbheight' => 999);
                                                        }
                                                    }

                                                    $picsource = $attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'];
                                                    $picsource .= 'forum/' . $attach['attachment'];
                                                    $basedir  = !$_G['setting']['attachdir'] ? DISCUZ_ROOT . './data/attachment/' : $_G['setting']['attachdir'];
                                                    $coverdir = 'threadcover/' . substr(md5($tid), 0, 2) . '/' . substr(md5($tid), 2, 2) . '/';
                                                    dmkdir($basedir . './forum/' . $coverdir);
                                                    if ($image->Thumb($picsource, 'forum/' . $coverdir . $tid . '.jpg', $_G['setting']['forumpicstyle']['thumbwidth'], $_G['setting']['forumpicstyle']['thumbheight'], 2)) {
                                                        $remote = '';
                                                        if ($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']) {
                                                            if (getglobal('setting/ftp/on')) {
                                                                if (ftpcmd('upload', 'forum/' . $coverdir . $tid . '.jpg')) {
                                                                    $remote = '-';
                                                                }
                                                            }
                                                        }
                                                        $cover = $remote . '1';
                                                    } else {
                                                        if (@$fp = fopen($basedir . './forum/' . $coverdir . $tid . '.jpg', 'wb')) {
                                                            flock($fp, 2);
                                                            fwrite($fp, $content);
                                                            fclose($fp);
                                                        }
                                                        $cover = '1';
                                                    }
                                                }
                                            }

                                            $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '[attach]' . $aid . '[/attach]';
                                        } else {
                                            $setarr = array(
                                                'aid'        => $aid,
                                                'dateline'   => $_G['timestamp'],
                                                'filename'   => $subject ? $subject . '-' . ($key + 1) . '.' . $attach['ext'] : $upload->attach['name'],
                                                'filesize'   => $upload->attach['size'],
                                                'attachment' => $upload->attach['attachment'],
                                                'isimage'    => $upload->attach['isimage'],
                                                'uid'        => $_G['uid'],
                                                'thumb'      => $thumb,
                                                'remote'     => '0',
                                                'width'      => $width,
                                            );

                                            C::t("forum_attachment_unused")->insert($setarr);
                                            $attachaids[$hash] = $imagereplace['newimageurl'][$key] = '[attachimg]' . $aid . '[/attachimg]';
                                        }
                                    } else {
                                        @unlink($attach['target']);
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($aids)) {
                        if ($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']) {
                            ftpupload($aids, $uid);
                        }
                        if ($tid) {
                            C::t('forum_thread')->update($tid, array('attachment' => 2, 'cover' => $cover), 1);
                        }
                    }
                    $message = str_replace($imagereplace['oldimageurl'], $imagereplace['newimageurl'], $message);
                    if ($tid) {
                        DB::update('forum_post', array('message' => $message, 'attachment' => !empty($aids) ? 2 : 0), 'pid=' . $pid, 1);
                    }
                }
            }
        }

    }

    public function viewthread_fastpost_btn_extra()
    {
        global $_G;
        $splugin_setting  = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups   = unserialize($splugin_setting['zzbuluo_groups']);
        $tlautoextra_fast = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_fast;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && $splugin_setting['zzbuluo_radio'] && $splugin_setting['zzbuluo_groups_radio'] && $splugin_setting['zzbuluo_fast_radio']) {
            include template("zzbuluo_autodown:tlautoextra_fast");
        }
        return $tlautoextra_fast;

    }
    public function post_attribute_extra()
    {
        global $_G;
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $tlautoextra     = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && $splugin_setting['zzbuluo_radio'] && $splugin_setting['zzbuluo_groups_radio']) {
              if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra");
        }
        return $tlautoextra;
    }
    public function post_attribute_extra_body()
    {
        global $_G;
        $splugin_setting  = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups   = unserialize($splugin_setting['zzbuluo_groups']);
        $tlautoextra_body = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra_body;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && $splugin_setting['zzbuluo_radio'] && $splugin_setting['zzbuluo_groups_radio']) {
              if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra_body");
        }
        return $tlautoextra_body;
    }
     public function post_side_bottom()
    {
        global $_G;
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
       
        $tlautoextra     = '';
        if (constant("DISCUZ_VERSION") != "X2.5") {
            return $tlautoextra;
        }

        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlautoextra;
        }

        if (in_array($_G['groupid'], $zzbuluo_groups) && $splugin_setting['zzbuluo_radio']) {
        
            if ($_GET['action'] == "reply" && !$splugin_setting['zzbuluo_fast_radio'] && $splugin_setting['zzbuluo_groups_radio']) {
              return $tlautoextra;
            }
            include template("zzbuluo_autodown:tlautoextra25");//
        }
        return $tlautoextra;
    }

}
class plugin_zzbuluo_autodown_portal extends plugin_zzbuluo_autodown
{

    public function portalcp_zzbuluo_autodown_output()
    {
        global $_G, $op, $aid;
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $tlautoextra     = $splugin_setting['zzbuluo_hide_button'] ? 1 : intval($_GET['tlarticleextend']);
        if ($op == 'add_success' && !empty($aid) && $tlautoextra == 1 && $splugin_setting['zzbuluo_radio'] && in_array($_G['groupid'], $zzbuluo_groups)) {
            $post      = C::t('#zzbuluo_autodown#zzbuluo_autodown_article')->fetch_by_search(array('aid' => $aid), array('aid' => 'DESC'));
            $atcontent = $post['content'];
            preg_match_all("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]|\[img=\d{1,4}[x|\,]\d{1,4}\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", $atcontent, $image1, PREG_SET_ORDER);
            preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\/?\>/ismU", $atcontent, $image2, PREG_SET_ORDER);
            if (empty($image2)) {
                preg_match_all("/\<img.+src=('|\"){1}(.*)('|\"){1}([\s].*)?\/?\>/isU", $atcontent, $image2, PREG_SET_ORDER);
            }
            $temp = $aids[] = $existentimg = $coverarr = array();
            if (is_array($image1) && !empty($image1)) {
                foreach ($image1 as $value) {
                    $temp[] = array(
                        '0' => $value[0],
                        '1' => trim(!empty($value[1]) ? $value[1] : $value[2]),
                    );
                }
            }
            if (is_array($image2) && !empty($image2)) {
                foreach ($image2 as $value) {
                    $temp[] = array(
                        '0' => $value[0],
                        '1' => trim($value[2]),
                    );
                }
            }
            //  print_r($temp);exit();
            if (is_array($temp) && !empty($temp)) {
                $upload     = new discuz_upload();
                $attachaids = array();
                $cover      = 0;

                foreach ($temp as $key => $value) {
                    $imageurl = $value[1];
                    $hash     = md5($imageurl);
                    if (strlen($imageurl)) {
                        if (!isset($existentimg[$hash])) {
                                $imagereplace['oldimageurl'][$key] = $value[0];
                            $imagereplace['newimageurl'][$key] = $value[0];
                            $existentimg[$hash]                = $imageurl;

                            $attach        = array();
                            $attach['ext'] = $upload->fileext($imageurl);

                            if (!in_array($attach['ext'], array('jpg', 'jpeg', 'gif', 'png', 'bmp'))) {
                                $attach['ext'] = 'jpg';
                            }
                            if ($upload->is_image_ext($attach['ext'])) {
                                $content = '';
                                if (preg_match('/^(https?:\/\/|\.)/i', $imageurl)) {
                                    $content = autodowncurlhttps($imageurl);

                                }elseif(preg_match('/^(\/\/|\.)/i', $imageurl)){
                                      $content = autodowncurlhttps($imageurl); //dfsockopen
                                } elseif (preg_match('/^(' . preg_quote(getglobal('setting/attachurl'), '/') . ')/i', $imageurl)) {
                                    continue;
                                }
                                if (empty($content)) {
                                    continue;
                                }

                                $temp                 = explode('/', $imageurl);
                                $attach['name']       = trim($temp[count($temp) - 1]);
                                $attach['thumb']      = '';
                                $attach['isimage']    = $upload->is_image_ext($attach['ext']);
                                $attach['extension']  = $upload->get_target_extension($attach['ext']);
                                $attach['attachdir']  = $upload->get_target_dir('portal');
                                $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('portal') . '.' . $attach['extension'];
                                $attach['target']     = getglobal('setting/attachdir') . './portal/' . $attach['attachment'];
                                if (@$fp = fopen($attach['target'], 'wb')) {
                                    flock($fp, 2);
                                    fwrite($fp, $content);
                                    fclose($fp);
                                    if ($imageinfo = $upload->get_image_info($attach['target'])) {
                                        $attach['size'] = filesize($attach['target']);
                                        if ($attach['isimage'] && empty($_G['setting']['portalarticleimgthumbclosed'])) {
                                            require_once libfile('class/image');
                                            $image           = new image();
                                            $thumbimgwidth   = $_G['setting']['portalarticleimgthumbwidth'] ? $_G['setting']['portalarticleimgthumbwidth'] : 300;
                                            $thumbimgheight  = $_G['setting']['portalarticleimgthumbheight'] ? $_G['setting']['portalarticleimgthumbheight'] : 300;
                                            $attach['thumb'] = $image->Thumb($attach['target'], '', $thumbimgwidth, $thumbimgheight, 2);
                                            $image->Watermark($attach['target'], '', 'portal');
                                        }
                                        if ($_G['cache']['plugin']['zzbuluo_autodown']['ftp_remote_radio']) {
                                            if (getglobal('setting/ftp/on') && ((!$_G['setting']['ftp']['allowedexts'] && !$_G['setting']['ftp']['disallowedexts']) || ($_G['setting']['ftp']['allowedexts'] && in_array($attach['ext'], $_G['setting']['ftp']['allowedexts'])) || ($_G['setting']['ftp']['disallowedexts'] && !in_array($attach['ext'], $_G['setting']['ftp']['disallowedexts']))) && (!$_G['setting']['ftp']['minsize'] || $attach['size'] >= $_G['setting']['ftp']['minsize'] * 1024)) {
                                                if (ftpcmd('upload', 'portal/' . $attach['attachment']) && (!$attach['thumb'] || ftpcmd('upload', 'portal/' . getimgthumbname($attach['attachment'])))) {
                                                    @unlink($_G['setting']['attachdir'] . '/portal/' . $attach['attachment']);
                                                    @unlink($_G['setting']['attachdir'] . '/portal/' . getimgthumbname($attach['attachment']));
                                                    $attach['remote'] = 1;
                                                } else {
                                                    if (getglobal('setting/ftp/mirror')) {
                                                        @unlink($attach['target']);
                                                        @unlink(getimgthumbname($attach['target']));
                                                        portal_upload_error(lang('portalcp', 'upload_remote_failed'));
                                                    }
                                                }
                                            }
                                        }

                                        $setarr = array(
                                            'uid'        => $param['uid'],
                                            'filename'   => $subject ? $subject . '-' . ($key + 1) . '.' . $attach['ext'] : $attach['name'],
                                            'attachment' => $attach['attachment'],
                                            'filesize'   => $attach['size'],
                                            'isimage'    => $attach['isimage'],
                                            'thumb'      => $attach['thumb'],
                                            'remote'     => $attach['remote'],
                                            'filetype'   => $attach['extension'],
                                            'dateline'   => $_G['timestamp'],
                                            'aid'        => $aid,
                                        );
                                        C::t('portal_attachment')->insert($setarr, true);
                                        if (empty($coverarr)) {
                                            list($width, $height, $type) = !empty($imageinfo) ? $imageinfo : array('', '', '');
                                            if ((!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight'] || $height > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minheight']) && (!$_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'] || $attach['size'] > $_G['cache']['plugin']['zzbuluo_autodown']['cover_minbytes'])) {
                                                $coverarr['pic']    = './portal/' . $attach['attachment'];
                                                $coverarr['thumb']  = intval($attach['thumb']);
                                                $coverarr['remote'] = intval($attach['remote']);
                                            }
                                        }
                                        //$attachaids[$hash] = $imagereplace['newimageurl'][$key] = '<img src="'.($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'portal/'.$attach['attachment'].'"/>';
                                        $attachaids[$hash] = $imagereplace['newimageurl'][$key] = str_replace($imageurl, ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'portal/' . $attach['attachment'], $imagereplace['oldimageurl'][$key]);
                                    } else {
                                        @unlink($attach['target']);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $atcontent = preg_replace(array("/\<(script|style|iframe)[^\>]*?\>.*?\<\/(\\1)\>/si", "/\<!*(--|doctype|html|head|meta|link|body)[^\>]*?\>/si"), '', $atcontent);
            $atcontent = str_replace($imagereplace['oldimageurl'], $imagereplace['newimageurl'], $atcontent);
            $atcontent = str_replace('.jpg&', '.jpg?', $atcontent);
            $atcontent = str_replace(array("\r", "\n", "\r\n"), '', $atcontent);
            //C::t('portal_article_content')->update($aid, array('content' => $atcontent), 1);
            DB::update('portal_article_content', array('content' => $atcontent), 'aid=' . $aid, 1);

            if (!empty($coverarr)) {
                DB::update('portal_article_title', $coverarr, 'aid=' . $aid, 1);
            }
        }

    }


    public function portalcp_bottom()
    {
        global $_G;
        $splugin_setting = $_G['cache']['plugin']['zzbuluo_autodown'];
        $zzbuluo_groups  = unserialize($splugin_setting['zzbuluo_groups']);
        $tlarticleextend = '';
        if ($splugin_setting['zzbuluo_hide_button']) {
            return $tlarticleextend;
        }
        if (in_array($_G['groupid'], $zzbuluo_groups) && $splugin_setting['zzbuluo_radio']) {
            include template("zzbuluo_autodown:tlarticleextend");
        }
        return $tlarticleextend;
    }
}


//Copyright 2001-2099 DisM-Taobao.
//This is NOT a freeware, use is subject to license terms
//$Id: hook.class.php 57120 2020-06-15 07:26:13Z zhuge $
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��