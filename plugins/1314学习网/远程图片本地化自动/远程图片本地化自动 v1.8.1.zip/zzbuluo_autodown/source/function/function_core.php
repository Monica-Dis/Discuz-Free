<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function autodowncurlhttps($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = $_var_4 = $_var_5 = $_var_6 = array();
	$_arg_0 = (preg_match("/^https?:\\/\\//i", $_arg_0) ? '' : "http:") . $_arg_0;
	$_arg_0 = str_ireplace("_.webp", '', $_arg_0);
	$_arg_0 = str_ireplace("&amp;", "&", $_arg_0);
	$_arg_0 = str_ireplace("tp=webp&", '', $_arg_0);
	$_var_7 = $_G["cache"]["plugin"]["zzbuluo_autodown"];
	$_var_8 = $_var_7["zzbuluo_imagesize"] * 1024;
	$_var_5 = explode("\n", str_replace("\r\n", "\n", $_var_7["zzbuluo_source"]));
	$_var_9 = explode("\n", str_replace("\r\n", "\n", $_var_7["zzbuluo_noimage"]));
	$_var_10 = explode("\n", str_replace("\r\n", "\n", $_var_7["zzbuluo_replace"]));
	foreach ($_var_10 as $_var_11 => $_var_12) {
		$_var_3 = explode("|", $_var_12);
		if (!empty($_var_3[0]) && !empty($_var_3[1])) {
			$_arg_0 = str_ireplace(trim($_var_3[0]), trim($_var_3[1]), $_arg_0);
		}
	}
	$_var_13 = parse_url($_G["siteurl"]);
	$_var_14 = parse_url($_arg_0);
	foreach ($_var_5 as $_var_11 => $_var_12) {
		$_var_4 = explode("|", $_var_12);
		if (!empty($_var_4[0]) && !empty($_var_4[1])) {
			$_var_2[trim($_var_4[0])] = trim($_var_4[1]);
		}
	}
	if (in_array($_var_14["host"], $_var_9)) {
		return '';
	}
	$_var_15 = get_headers($_arg_0, true);
	$_var_6["filesize"] = $_var_15["Content-Length"];
	if ($_var_6["filesize"] >= $_var_8 && $_var_8 != 0) {
		return '';
	}
	if ($_var_13["host"] == "api.dismall.com" && $_var_14["host"] == "api.zzbuluo.com") {
		$_var_16 = dfsockopen("http://www.d'.'i'.'szz.net/api/xd0_pic.php?url=" . urlencode($_arg_0));
		$_var_16 = gzuncompress($_var_16);
	} else {
		if (function_exists("curl_init") && function_exists("curl_exec")) {
			$_var_17 = curl_init();
			curl_setopt($_var_17, CURLOPT_URL, $_arg_0);
			curl_setopt($_var_17, CURLOPT_HEADER, $_POST["status"] ? 1 : 0);
			curl_setopt($_var_17, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($_var_17, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($_var_17, CURLOPT_FOLLOWLOCATION, 1);
			$_var_18 = '';
			if (isset($_var_2[$_var_14["host"]])) {
				$_var_18 = (preg_match("/^https?:\\/\\//i", $_var_2[$_var_14["host"]]) ? '' : "http://") . $_var_2[$_var_14["host"]];
			}
			if ($_var_18) {
				curl_setopt($_var_17, CURLOPT_REFERER, '' . $_var_18 . '');
			} else {
				curl_setopt($_var_17, CURLOPT_AUTOREFERER, 1);
			}
			curl_setopt($_var_17, CURLOPT_MAXREDIRS, 3);
			$_var_16 = curl_exec($_var_17);
			curl_close($_var_17);
		} else {
			$_var_16 = dfsockopen($_arg_0);
		}
	}
	return $_var_16;
}
function zzbuluo_autodown_webp($_arg_0, $_arg_1)
{
	global $_G;
	if (stripos($_arg_1, "webp") !== false && function_exists("imagecreatefromwebp")) {
		$_var_3 = imagecreatefromwebp($_arg_0);
		imagejpeg($_var_3, $_arg_0, 100);
		imagedestroy($_var_3);
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}