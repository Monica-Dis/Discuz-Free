<?php
 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

echo '<script type="text/javascript">'.($_G['isHTTPS'] ? 'parent.' : '').'location.href=\'http://addon.dismall.com/index.php?mod=app&ac=developer&id=4865&price=0&f_k=%B1%EA%C7%A9\';</script>';
exit;