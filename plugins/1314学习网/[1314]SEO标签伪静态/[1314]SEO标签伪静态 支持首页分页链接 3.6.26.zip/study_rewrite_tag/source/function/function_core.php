<?php

function study_rewrite_tag_rewrite()
{
	global $_G;
	global $canonical;
	$_var_2 = $_G["cache"]["plugin"]["study_rewrite_tag"];
	if ($_var_2["study_tag_radio"]) {
		if (CURSCRIPT == "misc" && CURMODULE == "tag") {
			$_var_3 = intval($_GET["id"]);
			$_var_4 = trim($_GET["type"]);
			$_var_5 = trim($_GET["name"]);
			$_var_6 = intval($_GET["page"]);
			if ($_var_3 || $_var_5) {
				if (isset($_G["cache"]["plugin"]["addon_seo_tags"]["only_thread"]) && $_G["cache"]["plugin"]["addon_seo_tags"]["only_thread"] && $_var_6 < 2) {
					$_var_4 = '';
				}
				if (!$_var_3) {
					if (!preg_match("/^([\\x7f-\\xff_-]|\\w|\\s)+\$/", $_var_5)) {
						showmessage("parameters_error");
					}
					$_var_5 = addslashes($_var_5);
					$_var_7 = C::t("common_tag")->fetch_info(0, $_var_5);
					$_var_3 = $_var_7["tagid"];
				}
				if (in_array($_var_4, array("thread", "blog", "article"))) {
					$canonical = study_rewrite_tag_rewriteoutput("forum_tag_list", 1, '', $_var_3, $_var_4, $_var_6, '');
				} else {
					$canonical = study_rewrite_tag_rewriteoutput("forum_tag_view", 1, '', $_var_3, '');
				}
			} else {
				$canonical = study_rewrite_tag_rewriteoutput("forum_tag_index", 1, '', $_var_6, '');
			}
			if (stripos($_G["setting"]["seohead"], "rel=\"canonical\"") === false) {
				$_G["setting"]["seohead"] = $_G["setting"]["seohead"] . ("<link href=\"" . $_G["siteurl"] . $canonical . "\" rel=\"canonical\" />");
			}
		}
		if (!is_array($_G["setting"]["rewritestatus"])) {
			$_G["setting"]["rewritestatus"] = array();
		}
		if (!in_array("forum_tag_list", $_G["setting"]["rewritestatus"])) {
			$_G["setting"]["rewritestatus"][] = "forum_tag_list";
		}
		$_G["setting"]["output"]["preg"]["search"]["forum_tag_list"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?misc.php\\?mod\\=tag&(amp;)?id\\=(\\d+)&(amp;)?type\\=(thread|blog|article)(&amp;page\\=(\\d+))?\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["forum_tag_list"] = "study_rewrite_tag_rewriteoutput('forum_tag_list', 0, '\\2', '\\4', '\\6', '\\8', '\\9')";
		$_G["setting"]["output"]["preg"]["search"]["forum_tag_view"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?misc.php\\?mod\\=tag&(amp;)?id\\=(\\d+)(&amp;page\\=(\\d+))?[^\"]*\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["forum_tag_view"] = "study_rewrite_tag_rewriteoutput('forum_tag_view', 0, '\\2', '\\4', '\\6', '\\7')";
		$_G["setting"]["output"]["preg"]["search"]["forum_tag_name"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?misc.php\\?mod\\=tag&(amp;)?name\\=([^&]+?)\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["forum_tag_name"] = "study_rewrite_tag_rewriteoutput('forum_tag_name', 0, '\\2', '\\4', '\\5')";
		$_G["setting"]["output"]["preg"]["search"]["forum_tag_index"] = "/<a([^\\>]*)href\\=\"(https?:\\/\\/[^\"]*\\/)?misc.php\\?mod\\=tag(&amp;page\\=(\\d+))?\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["forum_tag_index"] = "study_rewrite_tag_rewriteoutput('forum_tag_index', 0, '\\2', '\\4', '\\5')";
		$_var_8 = array("forum_tag_list", "forum_tag_view", "forum_tag_name", "forum_tag_index");
		if ($_var_2["dz_version"] <= 1) {
			if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
				$_var_9 = true;
			} else {
				if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
					$_var_9 = true;
				}
			}
		} else {
			if ($_var_2["dz_version"] == 3) {
				$_var_9 = true;
			}
		}
		if ($_var_9) {
			foreach ($_var_8 as $_var_10 => $_var_11) {
				if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_11])) {
					$_G["setting"]["output"]["preg"]["replace"][$_var_11] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_11]);
				}
			}
		} else {
			foreach ($_var_8 as $_var_10 => $_var_11) {
				if (isset($_G["setting"]["output"]["preg"]["search"][$_var_11])) {
					$_G["setting"]["output"]["preg"]["search"][$_var_11] = $_G["setting"]["output"]["preg"]["search"][$_var_11] . "e";
				}
			}
		}
	}
}
function study_rewrite_tag_rewriteoutput($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	if ($_arg_0 == "forum_tag_view") {
		list(, , , $_var_4, $_var_5, $_var_6) = func_get_args();
		$_var_7 = array("{id}" => $_var_4, "{page}" => $_var_5 ? $_var_5 : 1);
		if ($_G["cache"]["plugin"]["study_rewrite_tag"]["comiis_app_radio"] || $_G["cache"]["plugin"]["addon_seo_tags"]["only_thread"] && ($_G["cache"]["plugin"]["addon_seo_tags"]["touch_radio"] || !defined("IN_MOBILE"))) {
			if ($_var_7["{page}"] > 1) {
				$_var_7["{type}"] = "thread";
				$_arg_0 = "forum_tag_list";
			}
		}
	} else {
		if ($_arg_0 == "forum_tag_name") {
			list(, , , $_var_4, $_var_6) = func_get_args();
			$_var_4 = urlencode($_var_4);
			if ($_G["cache"]["plugin"]["study_rewrite_tag"]["study_cn_radio"]) {
				$_var_4 = rawurlencode($_var_4);
			}
			$_var_7 = array("{id}" => $_var_4);
		} else {
			if ($_arg_0 == "forum_tag_list") {
				list(, , , $_var_4, $_var_8, $_var_5, $_var_6) = func_get_args();
				$_var_7 = array("{id}" => $_var_4, "{type}" => $_var_8, "{page}" => $_var_5 ? $_var_5 : 1);
				if ($_G["cache"]["plugin"]["study_rewrite_tag"]["comiis_app_radio"]) {
					if (defined("IN_MOBILE") && $_var_8 == "thread" && $_var_7["{page}"] == 1) {
						$_arg_0 = "forum_tag_view";
					}
				}
			} else {
				if ($_arg_0 == "forum_tag_index") {
					list(, , , $_var_5, $_var_6) = func_get_args();
					$_var_7 = array("{page}" => $_var_5 ? $_var_5 : 1);
					if ($_var_7["{page}"] > 1) {
						$_arg_0 = "forum_tag_index2";
					}
				}
			}
		}
	}
	$_var_9 = str_replace(array_keys($_var_7), $_var_7, $_G["cache"]["plugin"]["study_rewrite_tag"][$_arg_0]);
	if (!$_arg_1) {
		return "<a href=\"" . $_arg_2 . $_var_9 . "\"" . (!empty($_var_6) ? stripslashes($_var_6) : '') . ">";
	}
	return $_arg_2 . $_var_9;
}
function study_rewrite_tag_check()
{
}
function study_rewrite_tag_cleardir($_arg_0)
{
}
function study_rewrite_tag_deltree($_arg_0)
{
}
function study_rewrite_tag_validator()
{
	global $_G;
	if (!defined("DISCUZ_VERSION")) {
		include_once DISCUZ_ROOT . "./source/discuz_version.php";
	}
	$_var_1 = array();
	$_var_1["pluginName"] = "study_rewrite_tag";
	$_var_1["pluginVersion"] = $_G["setting"]["plugins"]["version"]["study_rewrite_tag"];
	$_var_1["bbsVersion"] = DISCUZ_VERSION;
	$_var_1["bbsRelease"] = DISCUZ_RELEASE;
	$_var_1["timestamp"] = TIMESTAMP;
	$_var_1["bbsUrl"] = $_G["siteurl"];
	$_var_1["bbsAdminEMail"] = $_G["setting"]["adminemail"];
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		study_rewrite_tag_rewrite();
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
	}