<?php

/**
 * Copyright 2001-2099 DisM!Ӧ-��.��-��
 * This is NOT a freeware, use is subject to license terms
 * $Id: rewrite.inc.php 4932 2019-10-25 12:11:38
 * Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue������ http://t.cn/Aiux14ti��
 * Ӧ����ǰ��ѯ��QQ Dism��taobao-com
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux14ti
 * �����Ϊ DisM.taobao.com��d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('Access Denied');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=rewrite');#�����Ϊ 1314 ѧ ϰ ����www . 1314Study . com�� ����������ԭ�����, ����ӵ�а�Ȩ
require_once libfile('function/var', 'plugin/study_rewrite_tag/source');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = 'http://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['ClientUrl'] = 'http://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['study_rewrite_tag'];
$splugin_lang = lang('plugin/study_rewrite_tag');
$type1314 = in_array($_GET['type1314'], array('config', 'icon', 'category', 'slide', 'rewrite', 'seo')) ? $_GET['type1314'] : 'config';/*1314�W���W*/
$splugin_setting['0'] = array('0' => '2018091117LQ2xdantqc', '1' => '4487','2' => '1554289201', '3' => 'http://d'.'is'.'m.tao'.'ba'.'o.com/', '4' => 'http://d'.'is'.'m.tao'.'ba'.'o.com/', '5' => '', '6' => '', '7' => '');
$vuoujvt2 = "1314ѧϰ�W";
$_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = 'http://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['ClientUrl'] = 'http://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
require_once libfile('include/rewrite', 'plugin/study_rewrite_tag/source');

//Copyright 2001-2099 .DisM!Ӧ������.
//This is NOT a freeware, use is subject to license terms
//$Id: rewrite.inc.php 5395 2019-10-25 04:11:38
//Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue ������ http://t.cn/Aiux1Jx1��
//Ӧ����ǰ��ѯ��QQ Dism��taobao��com
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1012
//�����Ϊ DisM!��Ӧ.�á���.�ģ�d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��