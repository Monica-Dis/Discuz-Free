<?php
 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

echo '<script type="text/javascript">'.($_G['isHTTPS'] ? 'parent.' : '').'location.href=\'http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=product&ac=list&f_k=%CE%B1%BE%B2%CC%AC\';</script>';
exit;