<?php

/**
 * Copyright 2001-2099 DisM!Ӧ-��.��-��
 * This is NOT a freeware, use is subject to license terms
 * $Id: rewrite.inc.php 4388 2019-05-16 14:43:47
 * Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue������ http://t.cn/Aiux14ti��
 * Ӧ����ǰ��ѯ��QQ Dism��taobao-com
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux14ti
 * �����Ϊ DisM.taobao.com��d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('Access Denied');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=rewrite');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = 'https://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['ClientUrl'] = 'https://d'.'is'.'m.tao'.'ba'.'o.com/';$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['addon_seo_rewrite'];/*dism_taobao_com*/
$splugin_lang = lang('plugin/addon_seo_rewrite');
$type1314 = in_array($_GET['type1314'], array('config', 'icon', 'category', 'slide', 'rewrite', 'seo')) ? $_GET['type1314'] : 'config';//  1314ѧ����
$splugin_setting['0'] = array('0' => '2018091117LQ2xdantqc', '1' => '62812','2' => '1554289201', '3' => 'https://d'.'is'.'m.tao'.'ba'.'o.com/', '4' => 'https://d'.'is'.'m.tao'.'ba'.'o.com/', '5' => '', '6' => '', '7' => '');
$fwt5jepn = "1314�W���W";
require_once libfile('include/rewrite', 'plugin/addon_seo_rewrite/source');

//Copyright 2001-2099 .DisM!Ӧ������.
//This is NOT a freeware, use is subject to license terms
//$Id: rewrite.inc.php 4851 2019-05-16 06:43:47
//Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue ������ http://t.cn/Aiux1Jx1��
//Ӧ����ǰ��ѯ��QQ Dism��taobao��com
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1012
//�����Ϊ DisM!��Ӧ.�á���.�ģ�d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��