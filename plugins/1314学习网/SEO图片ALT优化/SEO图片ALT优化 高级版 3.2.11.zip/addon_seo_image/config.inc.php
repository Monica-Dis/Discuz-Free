<?php

/**
 * Copyright 2001-2099 Dism.Taobao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: config.inc.php 4226 2020-06-03 01:37:53
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=config');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
loadcache('plugin');/*DisM*/
$splugin_setting = $_G['cache']['plugin']['addon_seo_image'];
$splugin_lang = lang('plugin/addon_seo_image');
$xn_jucn6 = "http://t.cn/Aiux14ti";
$type1314 = in_array($_GET['type1314'], array('config')) ? $_GET['type1314'] : 'config';
$splugin_setting['0'] = array('0' => '2018091117LQ2xdantqc', '1' => '64060','2' => '1554289201', '3' => 'http://127.0.0.1/', '4' => 'http://127.0.0.1/', '5' => '', '6' => '', '7' => '');//dism_taobao_com
require_once libfile('include/config', 'plugin/addon_seo_image/source');

//Copyright 2001-2099 Dism.Taobao.Com.
//This is NOT a freeware, use is subject to license terms
//$Id: config.inc.php 4688 2020-06-02 17:37:53
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��