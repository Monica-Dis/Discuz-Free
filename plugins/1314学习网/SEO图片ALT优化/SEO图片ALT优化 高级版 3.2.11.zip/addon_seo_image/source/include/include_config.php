<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_seo_image_cleardir($_arg_0)
{

}
function addon_seo_image_deltree($_arg_0)
{
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$pluginvars = array();
	foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_9) {
		if (!strexists($_var_9["type"], "_")) {
			C::t("common_pluginvar")->update_by_variable($pluginid, $_var_9["variable"], array("type" => $_var_9["type"] . "_1314"));
		} else {
			$_var_10 = explode("_", $_var_9["type"]);
			if ($_var_10[1] == "1314") {
				$_var_9["type"] = $_var_10[0];
			} else {
				continue;
			}
		}
		$pluginvars[$_var_9["variable"]] = $_var_9;
	}
	require_once libfile("function/var", "plugin/addon_seo_image/source");
	if (!submitcheck("editsubmit")) {
		$_var_11 = '';
		if ($pluginvars) {
			showformheader("plugins&operation=config&do=" . $pluginid . '');
			showtableheader();
			echo "<div id=\"my_addonlist\"></div>";
			showtitle($lang["plugins_config"]);
			$_var_12 = array();
			foreach ($pluginvars as $_var_9) {
				if (!strexists($_var_9["type"], "_")) {
					$_var_9["variable"] = "varsnew[" . $_var_9["variable"] . "]";
					if ($_var_9["type"] == "number") {
						$_var_9["type"] = "text";
					} else {
						if ($_var_9["type"] == "select") {
							$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\">\n";
							foreach (explode("\n", $_var_9["extra"]) as $_var_13 => $_var_14) {
								$_var_14 = trim($_var_14);
								if (strpos($_var_14, "=") === false) {
									$_var_13 = $_var_14;
								} else {
									$_var_15 = explode("=", $_var_14);
									$_var_13 = trim($_var_15[0]);
									$_var_14 = trim($_var_15[1]);
								}
								$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . dhtmlspecialchars($_var_13) . "\" " . ($_var_9["value"] == $_var_13 ? "selected" : '') . ">" . $_var_14 . "</option>\n");
							}
							$_var_9["type"] = $_var_9["type"] . "</select>\n";
							$_var_9["variable"] = $_var_9["value"] = '';
						} else {
							if ($_var_9["type"] == "selects") {
								$_var_9["value"] = dunserialize($_var_9["value"]);
								$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array($_var_9["value"]);
								$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" multiple=\"multiple\" size=\"10\">\n";
								foreach (explode("\n", $_var_9["extra"]) as $_var_13 => $_var_14) {
									$_var_14 = trim($_var_14);
									if (strpos($_var_14, "=") === false) {
										$_var_13 = $_var_14;
									} else {
										$_var_15 = explode("=", $_var_14);
										$_var_13 = trim($_var_15[0]);
										$_var_14 = trim($_var_15[1]);
									}
									$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . dhtmlspecialchars($_var_13) . "\" " . (in_array($_var_13, $_var_9["value"]) ? "selected" : '') . ">" . $_var_14 . "</option>\n");
								}
								$_var_9["type"] = $_var_9["type"] . "</select>\n";
								$_var_9["variable"] = $_var_9["value"] = '';
							} else {
								if ($_var_9["type"] == "date") {
									$_var_9["type"] = "calendar";
									$_var_12["date"] = "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
								} else {
									if ($_var_9["type"] == "datetime") {
										$_var_9["type"] = "calendar";
										$_var_9["extra"] = 1;
										$_var_12["date"] = "<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>";
									} else {
										if ($_var_9["type"] == "forum") {
											require_once libfile("function/forumlist");
											$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\"><option value=\"\">" . cplang("plugins_empty") . "</option>" . forumselect(false, 0, $_var_9["value"], true) . "</select>";
											$_var_9["variable"] = $_var_9["value"] = '';
										} else {
											if ($_var_9["type"] == "forums") {
												$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
												$_var_9["value"] = dunserialize($_var_9["value"]);
												$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array();
												require_once libfile("function/forumlist");
												$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\">" . cplang("plugins_empty") . "</option>" . forumselect(false, 0, 0, true) . "</select>";
												foreach ($_var_9["value"] as $_var_16) {
													$_var_9["type"] = str_replace("<option value=\"" . $_var_16 . "\">", "<option value=\"" . $_var_16 . "\" selected>", $_var_9["type"]);
												}
												$_var_9["variable"] = $_var_9["value"] = '';
											} else {
												if (substr($_var_9["type"], 0, 5) == "group") {
													if ($_var_9["type"] == "groups") {
														$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
														$_var_9["value"] = dunserialize($_var_9["value"]);
														$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\"" . (@in_array('', $_var_9["value"]) ? " selected" : '') . ">" . cplang("plugins_empty") . "</option>";
													} else {
														$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\"><option value=\"\">" . cplang("plugins_empty") . "</option>";
													}
													$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array($_var_9["value"]);
													$_var_17 = C::t("common_usergroup")->range_orderby_credit();
													$_var_18 = array();
													foreach ($_var_17 as $_var_19) {
														$_var_19["type"] = $_var_19["type"] == "special" && $_var_19["radminid"] ? "specialadmin" : $_var_19["type"];
														$_var_18[$_var_19["type"]] = $_var_18[$_var_19["type"]] . ("<option value=\"" . $_var_19["groupid"] . "\"" . (@in_array($_var_19["groupid"], $_var_9["value"]) ? " selected" : '') . ">" . $_var_19["grouptitle"] . "</option>");
													}
													$_var_9["type"] = $_var_9["type"] . ("<optgroup label=\"" . $lang["usergroups_member"] . "\">" . $_var_18["member"] . "</optgroup>" . ($_var_18["special"] ? "<optgroup label=\"" . $lang["usergroups_special"] . "\">" . $_var_18["special"] . "</optgroup>" : '') . ($_var_18["specialadmin"] ? "<optgroup label=\"" . $lang["usergroups_specialadmin"] . "\">" . $_var_18["specialadmin"] . "</optgroup>" : '') . "<optgroup label=\"" . $lang["usergroups_system"] . "\">" . $_var_18["system"] . "</optgroup></select>");
													$_var_9["variable"] = $_var_9["value"] = '';
												} else {
													if ($_var_9["type"] == "extcredit") {
														$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\"><option value=\"\">" . cplang("plugins_empty") . "</option>";
														foreach ($_G["setting"]["extcredits"] as $_var_20 => $_var_21) {
															$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . $_var_20 . "\"" . ($_var_9["value"] == $_var_20 ? " selected" : '') . ">" . $_var_21["title"] . "</option>");
														}
														$_var_9["type"] = $_var_9["type"] . ("</select>");
														$_var_9["variable"] = $_var_9["value"] = '';
													}
												}
											}
										}
									}
								}
							}
						}
					}
					s_showsetting(isset($lang[$_var_9["title"]]) ? $lang[$_var_9["title"]] : dhtmlspecialchars($_var_9["title"]), $_var_9["variable"], $_var_9["value"], $_var_9["type"], '', 0, isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : nl2br(dhtmlspecialchars($_var_9["description"])), dhtmlspecialchars($_var_9["extra"]), '', true);
				}
			}
			showsubmit("editsubmit");
			showtablefooter();
			showformfooter();
			echo implode('', $_var_12);
			$_var_22 = array();
			$_var_22["pluginName"] = $plugin["identifier"];
			$_var_22["pluginVersion"] = $plugin["version"];
			$_var_22["bbsVersion"] = DISCUZ_VERSION;
			$_var_22["bbsRelease"] = DISCUZ_RELEASE;
			$_var_22["timestamp"] = TIMESTAMP;
			$_var_22["bbsUrl"] = $_G["siteurl"];
			$_var_22["SiteUrl"] = $_statInfo["SiteUrl"];
			$_var_22["ClientUrl"] = $_statInfo["ClientUrl"];
			$_var_22["SiteID"] = $_statInfo["SiteID"];
			$_var_22["bbsAdminEMail"] = $_G["setting"]["adminemail"];
			$_var_22["genuine"] = splugin_genuine($plugin["identifier"]);
			echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"><script id=\"my_addonlist_js\" src=\"http" . ($_G["isHTTPS"] ? "s" : '') . "://ww'.'w.zz'.'b'.'7.net/services.php?mod=product&ac=js&op=manage&timestamp=" . $_G["timestamp"] . "&info=" . base64_encode(serialize($_var_22)) . "&md5check=" . md5(base64_encode(serialize($_var_22))) . "\"></script></div>\r\n\t\t<script type=\"text/javascript\">\$(\"my_addonlist_js\").src= \"\";\$(\"my_addonlist\").innerHTML = \$(\"my_addonlist_temp\").innerHTML;</script>";
		}
	} else {
		if (is_array($_GET["varsnew"])) {
			foreach ($_GET["varsnew"] as $_var_23 => $_var_24) {
				if (isset($pluginvars[$_var_23])) {
					if ($pluginvars[$_var_23]["type"] == "number") {
						$_var_24 = (double) $_var_24;
					} else {
						if (in_array($pluginvars[$_var_23]["type"], array("forums", "groups", "selects"))) {
							$_var_24 = serialize($_var_24);
						}
					}
					$_var_24 = (string) $_var_24;
					C::t("common_pluginvar")->update_by_variable($pluginid, $_var_23, array("value" => $_var_24));
				}
			}
		}
		updatecache(array("plugin", "setting", "styles"));
		cleartemplatecache();
		cpmsg("plugins_setting_succeed", "action=plugins&operation=config&do=" . $pluginid . "&anchor=" . $_var_25, "succeed");
	}