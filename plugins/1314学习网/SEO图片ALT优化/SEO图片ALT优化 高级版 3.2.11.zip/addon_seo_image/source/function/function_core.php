<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_seo_image_init()
{
	global $_G;
	if ($_G["inajax"]) {
		return NULL;
	}
	$_G["addon_seo_image_altlang"] = $_var_1 = array();
	$_var_2 = explode("\n", str_replace("\r\n", "\n", $_G["cache"]["plugin"]["addon_seo_image"]["alt_lang"]));
	if (!empty($_var_2) && is_array($_var_2)) {
		foreach ($_var_2 as $_var_3 => $_var_4) {
			$_var_1 = explode("=", $_var_4);
			$_var_5 = count($_var_1);
			if ($_var_5 > 2) {
				$_var_1[1] = $_var_1[$_var_5 - 1];
				$_var_1[0] = str_replace("=" . $_var_1[1], '', $_var_4);
			}
			if (!empty($_var_1[0]) && !empty($_var_1[1])) {
				$_G["addon_seo_image_altlang"][$_var_1[0]] = $_var_1[1];
			}
		}
	}
	$_G["setting"]["rewritestatus"][] = "addon_seo_image";
	$_G["setting"]["output"]["preg"]["search"]["addon_seo_image"] = "/<img ([^>]*)>/";
	$_G["setting"]["output"]["preg"]["replace"]["addon_seo_image"] = "addon_seo_image_rewriteoutput('\\1')";
	$_var_6 = $_G["cache"]["plugin"]["addon_seo_image"];
	$_var_7 = array("addon_seo_image");
	$_G["newdz"] = false;
	if ($_var_6["dz_version"] <= 1) {
		if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
			$_G["newdz"] = true;
		} else {
			if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
				$_G["newdz"] = true;
			}
		}
	} else {
		if ($_var_6["dz_version"] == 3) {
			$_G["newdz"] = true;
		}
	}
	if ($_G["newdz"]) {
		foreach ($_var_7 as $_var_3 => $_var_4) {
			if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_4])) {
				$_G["setting"]["output"]["preg"]["replace"][$_var_4] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_4]);
			}
		}
	} else {
		foreach ($_var_7 as $_var_3 => $_var_4) {
			if (isset($_G["setting"]["output"]["preg"]["search"][$_var_4])) {
				$_G["setting"]["output"]["preg"]["search"][$_var_4] = $_G["setting"]["output"]["preg"]["search"][$_var_4] . "e";
			}
		}
	}
}
function addon_seo_image_thread($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["addon_seo_image"];
	$_var_3 = dhtmlspecialchars(str_replace("\\\\", '', $_G["thread"]["subject"]));
	foreach ($_arg_0 as $_var_4 => $_var_5) {
		if (strpos($_var_5["message"], "<img ") !== false) {
			preg_match_all("/<img id=\"aimg_([0-9]*)\"/is", $_var_5["message"], $_var_6);
			foreach ($_var_5["attachments"] as $_var_7 => $_var_8) {
				if ($_var_5["attachments"][$_var_7]["filename"] == $_var_5["attachments"][$_var_7]["imgalt"]) {
					$_var_5["attachments"][$_var_7]["imgalt"] = $_var_3;
					$_var_5["message"] = str_replace("alt=\"" . $_var_5["attachments"][$_var_7]["filename"] . "\"" . ($_var_2["title_radio"] ? " title=\"" . $_var_5["attachments"][$_var_7]["filename"] . "\"" : ''), "alt=\"" . $_var_5["attachments"][$_var_7]["imgalt"] . "\"" . ($_var_2["title_radio"] ? " title=\"" . $_var_5["attachments"][$_var_7]["imgalt"] . "\"" : ''), $_var_5["message"]);
				}
			}
			$_var_5["message"] = str_replace("alt=\"\"", "alt=\"" . $_var_3 . "\"" . ($_var_2["title_radio"] ? " title=\"" . $_var_3 . "\"" : ''), $_var_5["message"]);
			$_var_9 = "/<img ([^>]*)>/";
			$_var_10 = "addon_seo_image_rewriteoutput('\\1')";
			$_G["addon_seo_image_replace_alt"] = $_var_3;
			if ($_G["newdz"]) {
				$_var_10 = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_var_10);
				$_var_5["message"] = preg_replace_callback($_var_9, create_function("\$matches", "return " . $_var_10 . ";"), $_var_5["message"]);
			} else {
				$_var_9 = $_var_9 . "e";
				$_var_5["message"] = preg_replace($_var_9, $_var_10, $_var_5["message"]);
			}
			unset($_G["addon_seo_image_replace_alt"]);
			$_arg_0[$_var_4] = $_var_5;
		}
	}
	return $_arg_0;
}
function addon_seo_image_article()
{
	global $_G;
	global $article;
	global $content;
	global $article_content;
	$_var_4 = $_G["cache"]["plugin"]["addon_seo_image"];
	$_var_5 = dhtmlspecialchars(str_replace("\\\\", '', $article["title"]));
	$_G["addon_seo_image_replace_alt"] = $_var_5;
	$_var_6 = "/<img ([^>]*)>/";
	$_var_7 = "addon_seo_image_rewriteoutput('\\1')";
	$_var_7 = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_var_7);
	if (isset($content["content"]) && !empty($content["content"])) {
		$content["content"] = preg_replace_callback($_var_6, create_function("\$matches", "return " . $_var_7 . ";"), $content["content"]);
	} else {
		if (isset($article_content["content"]) && !empty($article_content["content"])) {
			$article_content["content"] = preg_replace_callback($_var_6, create_function("\$matches", "return " . $_var_7 . ";"), $article_content["content"]);
		}
	}
	unset($_G["addon_seo_image_replace_alt"]);
}
function addon_seo_image_rewriteoutput($_arg_0)
{
	global $_G;
	$_var_2 = '';
	$_var_3 = array();
	if (strpos($_arg_0, "static/image/common/loading.gif") === false) {
		$_arg_0 = stripslashes($_arg_0);
	} else {
		$_arg_0 = str_replace("\\\\", "\\", $_arg_0);
	}
	$_var_4 = strtolower($_arg_0);
	if (strpos($_var_4, "alt") === false) {
		$_var_5 = $_G["addon_seo_image_replace_alt"] ? $_G["addon_seo_image_replace_alt"] : '';
		if ($_var_5) {
			$_var_2 = "alt=\"" . $_var_5 . "\"" . ($_G["cache"]["plugin"]["addon_seo_image"]["title_radio"] ? " title=\"" . $_var_5 . "\"" : '');
		} else {
			preg_match("/src=('|\"|)?(.*)(\\1)([\\s].*)?/ismUe", $_arg_0, $_var_3);
			if ($_var_3[2]) {
				$_var_6 = pathinfo($_var_3[2], PATHINFO_BASENAME);
				if ($_var_6) {
					$_var_7 = strrpos($_var_6, ".");
					if ($_var_7 !== false) {
						$_var_5 = substr($_var_6, 0, $_var_7);
					} else {
						$_var_5 = $_var_6;
					}
					if (!empty($_G["addon_seo_image_altlang"]) && is_array($_G["addon_seo_image_altlang"]) && !empty($_G["addon_seo_image_altlang"][$_var_5])) {
						$_var_5 = trim($_G["addon_seo_image_altlang"][$_var_5]);
					} else {
						$_var_5 = trim(str_replace(array("{", "}", "=", "[", "]", "(", ")", "\$", "+", "'"), '', $_var_5));
					}
				}
				$_var_2 = "alt=" . $_var_3[1] . $_var_5 . $_var_3[1] . ($_G["cache"]["plugin"]["addon_seo_image"]["title_radio"] ? " title=" . $_var_3[1] . $_var_5 . $_var_3[1] : '');
			} else {
				$_var_2 = "alt=\"\"" . ($_G["cache"]["plugin"]["addon_seo_image"]["title_radio"] ? " title=\"\"" : '');
			}
		}
	}
	return "<img " . ($_var_2 ? $_var_2 . " " : '') . $_arg_0 . ">";
}
function addon_seo_image_check()
{
	$_var_0 = NULL;
}
function addon_seo_image_cleardir($_arg_0)
{
}
function addon_seo_image_deltree($_arg_0)
{
}
function addon_seo_image_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		if ($_GET["op"] != "edit") {
			addon_seo_image_init();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}