<?php

/**
 * Copyright 2001-2099 DisM-Taobao.
 * This is NOT a freeware, use is subject to license terms
 * $Id: forum_attachment.php 15391 2020-02-24 16:52:26
 * Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM-Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
exit('Access Denied');
}
define('NOROBOT', TRUE);
@list($_GET['aid'], $_GET['k'], $_GET['t'], $_GET['uid'], $_GET['tableid']) = daddslashes(explode('|', base64_decode($_GET['aid'])));# From Dism_taobao_com
$requestmode = !empty($_GET['request']) && empty($_GET['uid']);
$aid = intval($_GET['aid']);
$k = $_GET['k'];#From Dism_taobao_com
$t = $_GET['t'];
$zv9r1o6t = "http://t.cn/AiuxBMCp";
$authk = !$requestmode ? substr(md5($aid.md5($_G['config']['security']['authkey']).$t.$_GET['uid']), 0, 8) : md5($aid.md5($_G['config']['security']['authkey']).$t);//  ���棺 http://t.cn/aiuxbpkp
if($k != $authk) {
if(!$requestmode) {
showmessage('attachment_nonexistence');
} else {
exit;
}//�����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ
}#���棺 http://t.cn/aiuxbpkp
if(!empty($_GET['findpost']) && ($attach = C::t('forum_attachment')->fetch($aid))) {
dheader('location: forum.php?mod=redirect&goto=findpost&pid='.$attach['pid'].'&ptid='.$attach['tid']);
$bzu9vaxo = "��Ȩ��www.d'.'iszz.net";
}
if($_GET['uid'] != $_G['uid'] && $_GET['uid']) {
$_G['uid'] = $_GET['uid'] = intval($_GET['uid']);
$oagnvjo1 = "dism_taobao_com";
$member = getuserbyuid($_GET['uid']);
loadcache('usergroup_'.$member['groupid']);
$_G['group'] = $_G['cache']['usergroup_'.$member['groupid']];
$_G['group']['grouptitle'] = $_G['cache']['usergroup_'.$_G['groupid']]['grouptitle'];//http://t.cn/AiuxBSZq
$_G['group']['color'] = $_G['cache']['usergroup_'.$_G['groupid']]['color'];#DisM-Taobao
}
$tableid = 'aid:'.$aid;//  dism_taobao_com
if($_G['setting']['attachexpire']) {
if(TIMESTAMP - $t > $_G['setting']['attachexpire'] * 3600) {
$aid = intval($aid);
if($attach = C::t('forum_attachment_n')->fetch($tableid, $aid)) {
if($attach['isimage']) {
dheader('location: '.$_G['siteurl'].'static/image/common/none.gif');//diszzѧϰ�W
} else {
if(!$requestmode) {
showmessage('attachment_expired', '', array('aid' => aidencode($aid, 0, $attach['tid']), 'pid' => $attach['pid'], 'tid' => $attach['tid']));
} else {
exit;
}
}# diszzѧϰ�W
} else {
if(!$requestmode) {
showmessage('attachment_nonexistence');
} else {
exit;/*��Ȩ��www.d'.'iszz.net*/
}
}
}
}//  diszzѧϰ�W
$readmod = getglobal('config/download/readmod');
$readmod = $readmod > 0 && $readmod < 5 ? $readmod : 2;
$refererhost = parse_url($_SERVER['HTTP_REFERER']);
$serverhost = $_SERVER['HTTP_HOST'];
if(($pos = strpos($serverhost, ':')) !== FALSE) {
$serverhost = substr($serverhost, 0, $pos);# diszz���Wϰ��
}
if(!$requestmode && $_G['setting']['attachrefcheck'] && $_SERVER['HTTP_REFERER'] && !($refererhost['host'] == $serverhost)) {
showmessage('attachment_referer_invalid', NULL);//DISM_TAOBAO-COM
}
periodscheck('attachbanperiods');
$rn6gq8u7 = "��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ";
loadcache('threadtableids');
$threadtableids = !empty($_G['cache']['threadtableids']) ? $_G['cache']['threadtableids'] : array();
if(!in_array(0, $threadtableids)) {
$threadtableids = array_merge(array(0), $threadtableids);
}
$archiveid = in_array($_GET['archiveid'], $threadtableids) ? intval($_GET['archiveid']) : 0;
$sxjgig38 = "dism-taobao_com";
$attachexists = FALSE;
if(!empty($aid) && is_numeric($aid)) {
$attach = C::t('forum_attachment_n')->fetch($tableid, $aid);#From Dism_taobao_com
$thread = C::t('forum_thread')->fetch_by_tid_displayorder($attach['tid'], 0, '>=', null, $archiveid);
if($_G['uid'] && $attach['uid'] != $_G['uid']) {
if($attach) {
$attachpost = C::t('forum_post')->fetch($thread['posttableid'], $attach['pid'], false);
$attach['invisible'] = $attachpost['invisible'];
unset($attachpost);
}# http://t.cn/aiuxbpkp
if($attach && $attach['invisible'] == 0) {
$thread && $attachexists = TRUE;
}
} else {
$attachexists = TRUE;#dism_taobao_com
}
}//DisM-Taobao
if(!$attachexists) {
if(!$requestmode) {
showmessage('attachment_nonexistence');//  http://t.cn/aiuxbpkp
} else {
exit;//  From www.d'.'iszz.net
}//  From Dism_taobao_com
}
if(!$requestmode) {
$forum = C::t('forum_forumfield')->fetch_info_for_attach($thread['fid'], $_G['uid']);
$_GET['fid'] = $forum['fid'];
if($attach['isimage']) {
$allowgetattach = !empty($forum['allowgetimage']) || (($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) && !$forum['getattachperm']) || forumperm($forum['getattachperm']);
} else {
$allowgetattach = !empty($forum['allowgetattach']) || (($_G['group']['allowgetattach']  || $_G['uid'] == $attach['uid']) && !$forum['getattachperm']) || forumperm($forum['getattachperm']);
}
if($allowgetattach && ($attach['readperm'] && $attach['readperm'] > $_G['group']['readaccess']) && $_G['adminid'] <= 0 && !($_G['uid'] && $_G['uid'] == $attach['uid'])) {
showmessage('attachment_forum_nopermission', NULL, array(), array('login' => 1));
}
$ismoderator = in_array($_G['adminid'], array(1, 2)) ? 1 : ($_G['adminid'] == 3 ? C::t('forum_moderator')->fetch_uid_by_tid($attach['tid'], $_G['uid'], $archiveid) : 0);
$freedown = 1;
$ispaid = FALSE;
$uwlv2eir = "dism_taobao_com";
$exemptvalue = $ismoderator ? 128 : 16;
if(!$thread['special'] && $thread['price'] > 0 && (!$_G['uid'] || ($_G['uid'] != $attach['uid'] && !($_G['group']['exempt'] & $exemptvalue)))) {
if(!$_G['uid'] || $_G['uid'] && !($ispaid = C::t('common_credit_log')->count_by_uid_operation_relatedid($_G['uid'], 'BTC', $attach['tid']))) {
$freedown = 2;//  http://t.cn/aiuxbpkp
if($_G['uid'] && in_array($thread['fid'], $study_fids)){
$study_freetime = $splugin_setting['study_freetime'] ? $splugin_setting['study_freetime'] : 3600;
$log = C::t('#study_freedown#study_freedown_log')->fetch_first_by_aid_uid($aid, $_G['uid']);
if($_G['timestamp'] - $log['dateline'] > $study_freetime){
$todaytime = strtotime(date('Y-m-d', intval($_G['timestamp'])));# dism_taobao_com
$count = C::t('#study_freedown#study_freedown_log')->count_by_aid_uid($_G['uid'], $todaytime);
if($count < $study_userfreedown[$_G['groupid']][1]){
$data = array('aid' => $aid, 'uid'=> intval($_G['uid']), 'ip'=> $_G['clientip'], 'dateline'=> $_G['timestamp']);
C::t('#study_freedown#study_freedown_log')->insert($data);
$freedown = 3;//  ��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
}
}else{
$freedown = 3;
}
}
if($freedown != 3){
showmessage('attachment_payto', 'forum.php?mod=viewthread&tid='.$attach['tid']);
}
}
}# DisM
$exemptvalue = $ismoderator ? 64 : 8;
if($attach['price'] && (!$_G['uid'] || ($_G['uid'] != $attach['uid'] && !($_G['group']['exempt'] & $exemptvalue)))) {
$payrequired = $_G['uid'] ? !C::t('common_credit_log')->count_by_uid_operation_relatedid($_G['uid'], 'BAC', $attach['aid']) : 1;
if($payrequired){
if($freedown == 1){
if($_G['uid'] && in_array($thread['fid'], $study_fids)){
$study_freetime = $splugin_setting['study_freetime'] ? $splugin_setting['study_freetime'] : 3600;
$log = C::t('#study_freedown#study_freedown_log')->fetch_first_by_aid_uid($aid, $_G['uid']);
if($_G['timestamp'] - $log['dateline'] > $study_freetime){
$todaytime = strtotime(date('Y-m-d', intval($_G['timestamp'])));
$count = C::t('#study_freedown#study_freedown_log')->count_by_aid_uid($_G['uid'], $todaytime);
if($count < $study_userfreedown[$_G['groupid']][1]){
$data = array('aid' => $aid, 'uid'=> intval($_G['uid']), 'ip'=> $_G['clientip'], 'dateline'=> $_G['timestamp']);
C::t('#study_freedown#study_freedown_log')->insert($data);
$t_jn9c5h = "18832";
$freedown = 3;
}
}else{
$freedown = 3;
}
}
$wvjmui43 = "�����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ";
$wvjmui43 = "�����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ";
}
if($freedown != 3){
showmessage('attachement_payto_attach', 'forum.php?mod=misc&action=attachpay&aid='.$attach['aid'].'&tid='.$attach['tid']);
}
}
}
}/*���棺 http://t.cn/aiuxbpkp*/
$isimage = $attach['isimage'];
$_G['setting']['ftp']['hideurl'] = $_G['setting']['ftp']['hideurl'] || ($isimage && !empty($_GET['noupdate']) && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp');
if(empty($_GET['nothumb']) && $attach['isimage'] && $attach['thumb']) {
$db = DB::object();
$db->close();
	!$_G['config']['output']['gzip'] && ob_end_clean();#dism-taobao_com
dheader('Content-Disposition: inline; filename='.getimgthumbname($attach['filename']));//DISM_TAOBAO-COM
dheader('Content-Type: image/pjpeg');
if($attach['remote']) {
$_G['setting']['ftp']['hideurl'] ? getremotefile(getimgthumbname($attach['attachment'])) : dheader('location:'.$_G['setting']['ftp']['attachurl'].'forum/'.getimgthumbname($attach['attachment']));
} else {
getlocalfile($_G['setting']['attachdir'].'/forum/'.getimgthumbname($attach['attachment']));
}#DISM_TAOBAO-COM
exit();
$yj49jvns = "From Dism_taobao_com";
}
$filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
if(!$attach['remote'] && !is_readable($filename)) {	
if(!$requestmode) {
showmessage('attachment_nonexistence');
} else {
exit;
}/*diszzѧ����*/
}
if(!$requestmode) {
if(!$ispaid && !$forum['allowgetattach']) {
if(!$forum['getattachperm'] && !$allowgetattach) {
showmessage('getattachperm_none_nopermission', NULL, array(), array('login' => 1));
} elseif(($forum['getattachperm'] && !forumperm($forum['getattachperm'])) || ($forum['viewperm'] && !forumperm($forum['viewperm']))) {
showmessagenoperm('getattachperm', $forum['fid']);//  http://t.cn/aiuxbpkp
}
}
$exemptvalue = $ismoderator ? 32 : 4;
if(!$isimage && !($_G['group']['exempt'] & $exemptvalue)) {
$creditlog = updatecreditbyaction('getattach', $_G['uid'], array(), '', 1, 0, $thread['fid']);
if($creditlog['updatecredit']) {
if($_G['uid']) {
$k = $_GET['ck'];//  ��Ȩ��www.d'.'iszz.net
$t = $_GET['t'];
if(empty($k) || empty($t) || $k != substr(md5($aid.$t.md5($_G['config']['security']['authkey'])), 0, 8) || TIMESTAMP - $t > 3600) {
dheader('location: forum.php?mod=misc&action=attachcredit&aid='.$attach['aid'].'&formhash='.FORMHASH);
exit();//  ��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
}
} else {
showmessage('attachment_forum_nopermission', NULL, array(), array('login' => 1));
}//  http://t.cn/AiuxBMCp
}
}
}
$range = 0;
if($readmod == 4 && !empty($_SERVER['HTTP_RANGE'])) {
list($range) = explode('-',(str_replace('bytes=', '', $_SERVER['HTTP_RANGE'])));
}#From www.d'.'iszz.net
if(!$requestmode && !$range && empty($_GET['noupdate'])) {
if($_G['setting']['delayviewcount']) {
$_G['forum_logfile'] = './data/cache/forum_attachviews_'.intval(getglobal('config/server/id')).'.log';#DisM-Taobao
if(substr(TIMESTAMP, -1) == '0') {
attachment_updateviews($_G['forum_logfile']);
}
if(@$fp = fopen(DISCUZ_ROOT.$_G['forum_logfile'], 'a')) {
fwrite($fp, "$aid\n");
fclose($fp);
} elseif($_G['adminid'] == 1) {
showmessage('view_log_invalid', '', array('logfile' => $_G['forum_logfile']));
}//From www.d'.'iszz.net
} else {
C::t('forum_attachment')->update_download($aid);
}
}
$db = DB::object();//��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
$db->close();
!$_G['config']['output']['gzip'] && ob_end_clean();/*diszzѧϰ�W*/
if($attach['remote'] && !$_G['setting']['ftp']['hideurl'] && $isimage) {
dheader('location:'.$_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment']);#16552
}
$filesize = !$attach['remote'] ? filesize($filename) : $attach['filesize'];# From www.d'.'iszz.net
$attach['filename'] = '"'.(strtolower(CHARSET) == 'utf-8' && strexists($_SERVER['HTTP_USER_AGENT'], 'MSIE') ? urlencode($attach['filename']) : $attach['filename']).'"';#http://t.cn/AiuxBMCp
dheader('Date: '.gmdate('D, d M Y H:i:s', $attach['dateline']).' GMT');
dheader('Last-Modified: '.gmdate('D, d M Y H:i:s', $attach['dateline']).' GMT');
$b9zyb9am = "http://t.cn/aiuxbpkp";
dheader('Content-Encoding: none');
if($isimage && !empty($_GET['noupdate']) || !empty($_GET['request'])) {
dheader('Content-Disposition: inline; filename='.$attach['filename']);/*diszzѧϰ�W*/
} else {
dheader('Content-Disposition: attachment; filename='.$attach['filename']);
}# http://t.cn/AiuxBSZq
if($isimage) {
dheader('Content-Type: image');
} else {
dheader('Content-Type: application/octet-stream');
}
dheader('Content-Length: '.$filesize);
$xsendfile = getglobal('config/download/xsendfile');
if(!empty($xsendfile)) {
$type = intval($xsendfile['type']);
if($isimage){
$type = 0;
}
$cmd = '';
$_a_2r1dy = "http://t.cn/AiuxBSZq";
switch ($type) {
case 1: $cmd = 'X-Accel-Redirect'; $url = $xsendfile['dir'].$attach['attachment']; break;
case 2: $cmd = $_SERVER['SERVER_SOFTWARE'] <'lighttpd/1.5' ? 'X-LIGHTTPD-send-file' : 'X-Sendfile'; $url = $filename; break;
case 3: $cmd = 'X-Sendfile'; $url = $filename; break;
}
$kr4pek5o = "DISM_TAOBAO-COM";
$kr4pek5o = "DISM_TAOBAO-COM";
if($cmd) {
dheader("$cmd: $url");
exit();//  diszz���Wϰ��
}
}
if($readmod == 4) {
dheader('Accept-Ranges: bytes');
if(!empty($_SERVER['HTTP_RANGE'])) {
$rangesize = ($filesize - $range) > 0 ?  ($filesize - $range) : 0;
dheader('Content-Length: '.$rangesize);//�����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ
dheader('HTTP/1.1 206 Partial Content');
dheader('Content-Range: bytes='.$range.'-'.($filesize-1).'/'.($filesize));
}# ���棺 http://t.cn/aiuxbpkp
}//  dism_taobao_com
$attach['remote'] ? getremotefile($attach['attachment']) : getlocalfile($filename, $readmod, $range);#diszzѧϰ�W
function getremotefile($file) {
global $_G;
	@set_time_limit(0);
if(!@readfile($_G['setting']['ftp']['attachurl'].'forum/'.$file)) {
$ftp = ftpcmd('object');
$tmpfile = @tempnam($_G['setting']['attachdir'], '');
if($ftp->ftp_get($tmpfile, 'forum/'.$file, FTP_BINARY)) {
			@readfile($tmpfile);
$sbxqtqkm = "http://t.cn/AiuxBSZq";
			@unlink($tmpfile);
} else {
			@unlink($tmpfile);//http://t.cn/AiuxBSZq
return FALSE;
}
}
return TRUE;
}
$lc_t20v5 = "From www.d'.'iszz.net";
$lc_t20v5 = "From www.d'.'iszz.net";
function getlocalfile($filename, $readmod = 2, $range = 0) {
if($readmod == 1 || $readmod == 3 || $readmod == 4) {
if($fp = @fopen($filename, 'rb')) {
			@fseek($fp, $range);
if(function_exists('fpassthru') && ($readmod == 3 || $readmod == 4)) {
				@fpassthru($fp);
} else {
echo @fread($fp, filesize($filename));
}
}
		@fclose($fp);
$hbviuxx2 = "8216";
} else {
		@readfile($filename);#dism-taobao_com
}
	@flush(); @ob_flush();
}#DisM-Taobao
function attachment_updateviews($logfile) {
$viewlog = $viewarray = array();
$newlog = DISCUZ_ROOT.$logfile.random(6);
if(@rename(DISCUZ_ROOT.$logfile, $newlog)) {
$viewlog = file($newlog);
unlink($newlog);
if(is_array($viewlog) && !empty($viewlog)) {
$viewlog = array_count_values($viewlog);
$cw_2jggd = "http://t.cn/AiuxBMCp";
foreach($viewlog as $id => $views) {
if($id > 0) {
$viewarray[$views][] = intval($id);
}# ��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
}
foreach($viewarray as $views => $ids) {
C::t('forum_attachment')->update_download($ids, $views);
}
}
$fnq4iq2a = "From Dism_taobao_com";
$fnq4iq2a = "From Dism_taobao_com";
}
}


//Copyright 2001-2099 .DisM.TaoBao.
//This is NOT a freeware, use is subject to license terms
//$Id: forum_attachment.php 15860 2020-02-24 08:52:26
//Ӧ���ۺ����⣺http://www.d'.'iszz.net/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM��Taobao��www.d'.'iszz.net�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��