<?php

/**
 * Copyright 2001-2099 DisM!Ӧ-��.��-��
 * This is NOT a freeware, use is subject to license terms
 * $Id: hook.class.php 4301 2019-07-10 21:27:22
 * Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue������ http://t.cn/Aiux14ti��
 * Ӧ����ǰ��ѯ��QQ Dism��taobao-com
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux14ti
 * �����Ϊ DisM.taobao.com��d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */
/*
 * This is NOT a freeware, use is subject to license terms
 * From dism.zzb7-net
 */
if (!defined('IN_DISCUZ')) {
exit('Access Denied');
}
class plugin_study_seo_wyc {

}

class plugin_study_seo_wyc_forum extends plugin_study_seo_wyc {
	function viewthread_output() {
		global $_G, $postlist, $navtitle, $metakeywords, $metadescription;
		$splugin_setting = $_G['cache']['plugin']['study_seo_wyc'];
		$wyc_selects = unserialize($splugin_setting['wyc_selects']);
		if (in_array('forum', $wyc_selects)) {
			$wyc_gids = unserialize($splugin_setting['wyc_gids']);
			if (IS_ROBOT || in_array($_G['groupid'], $wyc_gids)) {
				$wyc_fids = unserialize($splugin_setting['wyc_fids']);
				if (in_array($_G['fid'], $wyc_fids)) {
					$keyword_default = array();
					if ($splugin_setting['wyc_keyword_default_radio']) {
						$wyc_keyword_charset = in_array($splugin_setting['wyc_keyword_charset'], array('gbk', 'utf8', 'big5', 'tc_utf8')) ? $splugin_setting['wyc_keyword_charset'] : 'gbk';
						@include_once DISCUZ_ROOT . './source/plugin/study_seo_wyc/keyword/keyword_' . $wyc_keyword_charset . '.php';
					}
					include_once libfile('function/core', 'plugin/study_seo_wyc/source');
					study_seo_wyc_thread_replace($keyword_default);
				}
			}
		}
		return array();
	}
}

class plugin_study_seo_wyc_portal extends plugin_study_seo_wyc {

	function view_output() {
		global $_G, $article, $content, $navtitle, $metakeywords, $metadescription;
		$splugin_setting = $_G['cache']['plugin']['study_seo_wyc'];
		$wyc_selects = unserialize($splugin_setting['wyc_selects']);
		if (in_array('portal', $wyc_selects)) {
			$wyc_gids = unserialize($splugin_setting['wyc_gids']);
			if (IS_ROBOT || in_array($_G['groupid'], $wyc_gids)) {
				$keyword_default = array();
				if ($splugin_setting['wyc_keyword_default_radio']) {
					$wyc_keyword_charset = in_array($splugin_setting['wyc_keyword_charset'], array('gbk', 'utf8', 'big5', 'tc_utf8')) ? $splugin_setting['wyc_keyword_charset'] : 'gbk';
					@include_once DISCUZ_ROOT . './source/plugin/study_seo_wyc/keyword/keyword_' . $wyc_keyword_charset . '.php';
				}
				include_once libfile('function/core', 'plugin/study_seo_wyc/source');
				study_seo_wyc_article_replace($keyword_default);
			}
		}
		return '';
	}
}

class plugin_study_seo_wyc_group extends plugin_study_seo_wyc {

	function viewthread_output() {
		global $_G, $postlist;
		$splugin_setting = $_G['cache']['plugin']['study_seo_wyc'];
		$wyc_selects = unserialize($splugin_setting['wyc_selects']);
		if (in_array('group', $wyc_selects)) {
			$wyc_gids = unserialize($splugin_setting['wyc_gids']);
			if (IS_ROBOT || in_array($_G['groupid'], $wyc_gids)) {
				$keyword_default = array();
				if ($splugin_setting['wyc_keyword_default_radio']) {
					$wyc_keyword_charset = in_array($splugin_setting['wyc_keyword_charset'], array('gbk', 'utf8', 'big5', 'tc_utf8')) ? $splugin_setting['wyc_keyword_charset'] : 'gbk';
					@include_once DISCUZ_ROOT . './source/plugin/study_seo_wyc/keyword/keyword_' . $wyc_keyword_charset . '.php';
				}
				include_once libfile('function/core', 'plugin/study_seo_wyc/source');
				study_seo_wyc_thread_replace($keyword_default);
			}
		}
		return array();
	}
}

class plugin_study_seo_wyc_home extends plugin_study_seo_wyc {

	function space_blog_title_output() {
		global $_G, $blog, $navtitle, $metakeywords, $metadescription;
		$splugin_setting = $_G['cache']['plugin']['study_seo_wyc'];
		$wyc_selects = unserialize($splugin_setting['wyc_selects']);
		if (in_array('home', $wyc_selects)) {
			$wyc_gids = unserialize($splugin_setting['wyc_gids']);
			if (IS_ROBOT || in_array($_G['groupid'], $wyc_gids)) {
				$keyword_default = array();
				if ($splugin_setting['wyc_keyword_default_radio']) {
					$wyc_keyword_charset = in_array($splugin_setting['wyc_keyword_charset'], array('gbk', 'utf8', 'big5', 'tc_utf8')) ? $splugin_setting['wyc_keyword_charset'] : 'gbk';
					@include_once DISCUZ_ROOT . './source/plugin/study_seo_wyc/keyword/keyword_' . $wyc_keyword_charset . '.php';
				}
				include_once libfile('function/core', 'plugin/study_seo_wyc/source');
				study_seo_wyc_blog_replace($keyword_default);
			}
		}
		return '';
	}
}




//Copyright 2001-2099 .DisM!Ӧ������.
//This is NOT a freeware, use is subject to license terms
//$Id: hook.class.php 4763 2019-07-10 13:27:22
//Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/?services.php?mod=issue ������ http://t.cn/Aiux1Jx1��
//Ӧ����ǰ��ѯ��QQ Dism��taobao��com
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1012
//�����Ϊ DisM!��Ӧ.�á���.�ģ�d'.'is'.'m.tao'.'ba'.'o.com�� ����ɹ��Ĳ��, ��������ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��