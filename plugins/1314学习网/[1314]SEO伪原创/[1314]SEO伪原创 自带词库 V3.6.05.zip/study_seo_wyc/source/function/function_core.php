<?php

function study_seo_wyc_thread_replace($_arg_0 = array())
{
	global $_G;
	global $postlist;
	global $navtitle;
	global $metakeywords;
	global $metadescription;
	$_var_6 = $_G["cache"]["plugin"]["study_seo_wyc"];
	$_var_7 = explode("\n", str_replace("\r\n", "\n", $_var_6["wyc_keyword"]));
	foreach ($_var_7 as $_var_8) {
		$_var_9 = explode("==", $_var_8);
		if ($_var_9[0] && $_var_9[1]) {
			$_var_10[] = $_var_9[0];
			$_var_11[] = $_var_9[1];
		}
	}
	$_var_12 = $_G["forum_thread"]["subject"];
	foreach ($postlist as $_var_13 => $_var_14) {
		if ($_var_6["wyc_way"] == 1 && $_var_14["first"] || $_var_6["wyc_way"] == 2 && !$_var_14["first"] || $_var_6["wyc_way"] == 3) {
			if ($_var_6["wyc_title"]) {
				$_G["forum_thread"]["subject"] = str_replace($_var_10, $_var_11, $_G["forum_thread"]["subject"]);
				if ($_var_6["wyc_keyword_default_radio"]) {
					$_G["forum_thread"]["subject"] = str_replace($_arg_0["find"], $_arg_0["replace"], $_G["forum_thread"]["subject"]);
				}
			}
			$postlist[$_var_13]["message"] = str_replace($_var_10, $_var_11, $_var_14["message"]);
			if ($_var_6["wyc_keyword_default_radio"]) {
				$postlist[$_var_13]["message"] = str_replace($_arg_0["find"], $_arg_0["replace"], $postlist[$_var_13]["message"]);
			}
			break;
		}
	}
	$navtitle = str_replace($_var_12, dhtmlspecialchars($_G["forum_thread"]["subject"]), $navtitle);
}
function study_seo_wyc_article_replace($_arg_0 = array())
{
	global $_G;
	global $article;
	global $content;
	global $navtitle;
	global $metakeywords;
	global $metadescription;
	$_var_7 = $_G["cache"]["plugin"]["study_seo_wyc"];
	$_var_8 = explode("\n", str_replace("\r\n", "\n", $_var_7["wyc_keyword"]));
	foreach ($_var_8 as $_var_9) {
		$_var_10 = explode("==", $_var_9);
		if ($_var_10[0] && $_var_10[1]) {
			$_var_11[] = $_var_10[0];
			$_var_12[] = $_var_10[1];
		}
	}
	$_var_13 = $article["title"];
	if ($_var_7["wyc_title"]) {
		$article["title"] = str_replace($_var_11, $_var_12, $article["title"]);
		if ($_var_7["wyc_keyword_default_radio"]) {
			$article["title"] = str_replace($_arg_0["find"], $_arg_0["replace"], $article["title"]);
		}
	}
	$content["content"] = str_replace($_var_11, $_var_12, $content["content"]);
	if ($_var_7["wyc_keyword_default_radio"]) {
		$content["content"] = str_replace($_arg_0["find"], $_arg_0["replace"], $content["content"]);
	}
	$navtitle = str_replace($_var_13, dhtmlspecialchars($article["title"]), $navtitle);
}
function study_seo_wyc_blog_replace($_arg_0 = array())
{
	global $_G;
	global $blog;
	global $navtitle;
	global $metakeywords;
	global $metadescription;
	$_var_6 = $_G["cache"]["plugin"]["study_seo_wyc"];
	$_var_7 = explode("\n", str_replace("\r\n", "\n", $_var_6["wyc_keyword"]));
	foreach ($_var_7 as $_var_8) {
		$_var_9 = explode("==", $_var_8);
		if ($_var_9[0] && $_var_9[1]) {
			$_var_10[] = $_var_9[0];
			$_var_11[] = $_var_9[1];
		}
	}
	$_var_12 = $blog["subject"];
	if ($_var_6["wyc_title"]) {
		$blog["subject"] = str_replace($_var_10, $_var_11, $blog["subject"]);
		if ($_var_6["wyc_keyword_default_radio"]) {
			$blog["subject"] = str_replace($_arg_0["find"], $_arg_0["replace"], $blog["subject"]);
		}
	}
	$blog["message"] = str_replace($_var_10, $_var_11, $blog["message"]);
	if ($_var_6["wyc_keyword_default_radio"]) {
		$blog["message"] = str_replace($_arg_0["find"], $_arg_0["replace"], $blog["message"]);
	}
	$navtitle = str_replace($_var_12, dhtmlspecialchars($blog["subject"]), $navtitle);
}
function study_seo_wyc_check()
{
}
function study_seo_wyc_cleardir($_arg_0)
{
}
function study_seo_wyc_deltree($_arg_0)
{
}
function study_seo_wyc_validator()
{
	global $_G;
	if (!defined("DISCUZ_VERSION")) {
		include_once DISCUZ_ROOT . "./source/discuz_version.php";
	}
	$_var_1 = array();
	$_var_1["pluginName"] = "study_seo_wyc";
	$_var_1["pluginVersion"] = $_G["setting"]["plugins"]["version"]["study_seo_wyc"];
	$_var_1["bbsVersion"] = DISCUZ_VERSION;
	$_var_1["bbsRelease"] = DISCUZ_RELEASE;
	$_var_1["timestamp"] = TIMESTAMP;
	$_var_1["bbsUrl"] = $_G["siteurl"];
	$_var_1["bbsAdminEMail"] = $_G["setting"]["adminemail"];
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}
	if (!defined("IN_ADMINCP")) {
	}
	global $_G;
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
	}