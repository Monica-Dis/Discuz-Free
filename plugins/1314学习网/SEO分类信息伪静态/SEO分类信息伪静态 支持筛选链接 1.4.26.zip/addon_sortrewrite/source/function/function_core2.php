<?php

function addon_sortrewrite_rewriteoutput($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_var_4 = array();
	if ($_arg_0 == "addon_sortrewrite") {
		list(, , , $_var_5, $_var_6, $_var_7) = func_get_args();
		if ($_G["cache"]["plugin"]["addon_sortrewrite"]["subdomain_radio"]) {
			if (isset($_G["setting"]["domain"]["list"]) && !empty($_G["setting"]["domain"]["list"]) && !empty($_G["setting"]["domain"]["root"]["forum"])) {
				foreach ($_G["setting"]["domain"]["list"] as $_var_8 => $_var_9) {
					if ($_var_9["idtype"] == "forum" && $_var_9["id"] == $_var_5) {
						$_arg_2 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_var_8 . $_G["siteport"] . "/";
						break;
					}
				}
			}
		}
		if (strpos($_var_6, "&") !== false) {
			parse_str(str_replace("&amp;", "&", $_var_6), $_var_4);
			$_var_6 = $_var_4["page"];
		}
		if (in_array($_var_4["filter"], array("typeid", "sortid", "sortall")) || isset($_var_4["sortid"]) && !empty($_var_4["sortid"])) {
			if ($_G["cache"]["plugin"]["addon_sortrewrite"]["url_radio"]) {
				$_var_10 = array();
				if (isset($_var_4["typeid"]) && !empty($_var_4["typeid"])) {
					$_var_10[] = "typeid-" . $_var_4["typeid"];
				}
				$_var_11 = array();
				foreach ($_var_4 as $_var_12 => $_var_9) {
					if (!in_array($_var_12, array("filter", "searchsort", "typeid", "sortid", "sortall", "page", "t", "mobile")) && $_var_9 != "all") {
						if ($_var_12 == "vars") {
							$_var_13 = explode("-", $_var_9);
							foreach ($_var_13 as $_var_14 => $_var_15) {
								if ($_var_14 % 2) {
									if (!in_array($_var_13[$_var_14 - 1], array("filter", "searchsort", "typeid", "sortid", "sortall", "page", "t", "mobile")) && $_var_15 != "all") {
										if (!in_array($_var_13[$_var_14 - 1], $_var_11)) {
											$_var_11[] = $_var_13[$_var_14 - 1];
											$_var_4[$_var_13[$_var_14 - 1]] = str_replace("_", "|", $_var_15);
										}
									}
								}
							}
						} else {
							$_var_11[] = $_var_12;
						}
					}
				}
				if (isset($_var_4["sortid"]) && !empty($_var_4["sortid"])) {
					if (!empty($_var_11) || !$_G["forum"]["threadsorts"]["defaultshow"] || $_G["forum"]["threadsorts"]["defaultshow"] != $_var_4["sortid"]) {
						$_var_10[] = "sortid-" . $_var_4["sortid"];
					}
				}
				if (isset($_var_4["sortall"]) && !empty($_var_4["sortall"]) && empty($_var_10)) {
					$_var_10[] = "sortall-" . $_var_4["sortall"];
				}
				$_var_11 = array_unique($_var_11);
				sort($_var_11);
				foreach ($_var_11 as $_var_12) {
					$_var_10[] = $_var_12 . "-" . str_replace("|", "_", $_var_4[$_var_12]);
				}
				if (isset($_var_4["page"]) && $_var_4["page"] > 1) {
					$_var_10[] = "page-" . $_var_4["page"];
				}
				$_var_10 = implode("-", $_var_10);
				$_var_16 = array("{fid}" => empty($_G["setting"]["forumkeys"][$_var_5]) ? $_var_5 : $_G["setting"]["forumkeys"][$_var_5], "{vars}" => $_var_10);
			} else {
				$_var_10 = array();
				foreach ($_var_4 as $_var_12 => $_var_9) {
					if ($_var_12 != "filter" && $_var_9 != "all" && $_var_12 != "searchsort" && ($_var_12 != "page" || $_var_9 >= 2)) {
						$_var_10[] = $_var_12 . "-" . str_replace("|", "_", $_var_9);
					}
				}
				$_var_10 = implode("-", $_var_10);
				$_var_16 = array("{fid}" => empty($_G["setting"]["forumkeys"][$_var_5]) ? $_var_5 : $_G["setting"]["forumkeys"][$_var_5], "{vars}" => $_var_10);
			}
			if (isset($_var_4["typeid"])) {
				$_var_16["{typeid}"] = $_var_4["typeid"];
			}
		} else {
			$_var_17 = "forum.php?mod=forumdisplay&fid=" . $_var_5 . (!empty($_var_4) ? "&" . http_build_query($_var_4) : '');
			if (!$_arg_1) {
				return "<a href=\"" . $_arg_2 . $_var_17 . "\"" . (!empty($_var_7) ? stripslashes($_var_7) : '') . ">";
			}
			return $_arg_2 . $_var_17;
		}
	}
	if (!empty($_var_16["{vars}"])) {
		$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["addon_sortrewrite"][$_arg_0]);
		if ($_var_4["filter"] == "typeid" && !isset($_var_4["sortid"])) {
			$_var_16["{page}"] = isset($_var_4["page"]) ? max($_var_4["page"], 1) : 1;
			if (!empty($_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"]["forum_forumdisplay_type"])) {
				if ($_var_4["page"] > 1 && !empty($_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"]["forum_forumdisplay_type2"])) {
					$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"]["forum_forumdisplay_type2"]);
				} else {
					$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"]["forum_forumdisplay_type"]);
				}
			} else {
				if (!empty($_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay_type"])) {
					if ($_var_4["page"] > 1 && !empty($_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay_type2"])) {
						$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay_type2"]);
					} else {
						$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay_type"]);
					}
				}
			}
		}
	} else {
		$_var_16["{page}"] = 1;
		if (!empty($_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay"])) {
			$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_forumdisplay"]);
		} else {
			$_var_17 = str_replace(array_keys($_var_16), $_var_16, $_G["setting"]["rewriterule"]["forum_forumdisplay"]);
		}
	}
	if (!$_arg_1) {
		return "<a href=\"" . $_arg_2 . $_var_17 . "\"" . (!empty($_var_7) ? stripslashes($_var_7) : '') . ">";
	}
	return $_arg_2 . $_var_17;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}