<?php

function addon_sortrewrite_rewrite()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_sortrewrite"];
	if ($_var_1["study_radio"]) {
		if (!defined("IN_MOBILE") || $_G["cache"]["plugin"]["addon_seo_mobilerewrite"]["addon_sortrewrite"]) {
			if (is_array($_G["setting"]["domain"]["app"])) {
				$_var_2 = empty($_G["setting"]["domain"]["app"]["default"]) ? "{CURHOST}" : $_G["setting"]["domain"]["app"]["default"];
				$_var_3 = $_G["setting"]["domain"]["app"];
				$_var_4 = $_var_3["portal"] || $_var_3["forum"] || $_var_3["group"] || $_var_3["home"] || $_var_3["default"];
				foreach ($_var_3 as $_var_5 => $_var_6) {
					if (!in_array($_var_5, array("default", "mobile"))) {
						$_var_7 = '' . $_var_5 . ".php";
						if (!$_var_6) {
							$_var_6 = $_var_2;
						}
						if ($_var_6 != "{CURHOST}") {
							$_var_6 = "http" . ($_G["isHTTPS"] ? "s" : '') . "://" . $_var_6 . $_G["siteport"] . "/";
						}
						if ($_var_4) {
							$_G["setting"]["output"]["str"]["search"][$_var_5] = "<a href=\"" . $_var_5 . ".php";
							$_G["setting"]["output"]["str"]["replace"][$_var_5] = "<a href=\"" . $_var_6 . $_var_7;
							$_G["domain"]["pregxprw"][$_var_5] = "<a href\\=\"(" . preg_quote($_var_6, "/") . ")" . $_var_7;
						} else {
							$_G["domain"]["pregxprw"][$_var_5] = "<a href\\=\"()" . $_var_7;
						}
					}
				}
			}
			if (!in_array("addon_sortrewrite", $_G["setting"]["rewritestatus"])) {
				$_G["setting"]["rewritestatus"][] = "addon_sortrewrite";
			}
			$_G["setting"]["output"]["preg"]["search"]["addon_sortrewrite"] = "/" . $_G["domain"]["pregxprw"]["forum"] . "\\?mod\\=forumdisplay&(amp;)?fid\\=(\\w+)([^\"]*)\"([^\\>]*)\\>/";
			$_G["setting"]["output"]["preg"]["replace"]["addon_sortrewrite"] = "addon_sortrewrite_rewriteoutput('addo'.'n_so'.'rtre'.'writ'.'e', 0, '\\1', '\\3', '\\4', '\\5')";
			$_var_8 = array("addon_sortrewrite");
			if ($_var_1["dz_version"] <= 1) {
				if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
					$_var_9 = true;
				} else {
					if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
						$_var_9 = true;
					}
				}
			} else {
				if ($_var_1["dz_version"] == 3) {
					$_var_9 = true;
				}
			}
			if ($_var_9) {
				foreach ($_var_8 as $_var_10 => $_var_11) {
					if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_11])) {
						$_G["setting"]["output"]["preg"]["replace"][$_var_11] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_11]);
					}
				}
			} else {
				foreach ($_var_8 as $_var_10 => $_var_11) {
					if (isset($_G["setting"]["output"]["preg"]["search"][$_var_11])) {
						$_G["setting"]["output"]["preg"]["search"][$_var_11] = $_G["setting"]["output"]["preg"]["search"][$_var_11] . "e";
					}
				}
			}
		}
		parse_str($_SERVER["QUERY_STRING"], $_var_12);
		$_GET["vars"] = explode("-", $_GET["vars"]);
		foreach ($_GET["vars"] as $_var_10 => $_var_11) {
			if ($_var_10 % 2) {
				$_var_12[$_GET["vars"][$_var_10 - 1]] = $_GET[$_GET["vars"][$_var_10 - 1]] = str_replace("_", "|", $_var_11);
			}
		}
		unset($_GET["vars"]);
		unset($_var_12["vars"]);
		if ($_GET["sortid"]) {
			$_var_12["searchsort"] = $_GET["searchsort"] = 1;
		}
		if (isset($_GET["typeid"])) {
			$_var_12["filter"] = $_GET["filter"] = "typeid";
		}
		if (isset($_GET["sortid"])) {
			$_var_12["filter"] = $_GET["filter"] = "sortid";
		}
		if (isset($_GET["sortall"])) {
			$_var_12["filter"] = $_GET["filter"] = "sortall";
		}
		if (isset($_GET["page"])) {
			$_G["page"] = max(1, dintval($_GET["page"]));
		}
		$_SERVER["QUERY_STRING"] = http_build_query($_var_12);
	}
}
function addon_sortrewrite_check()
{
}
function addon_sortrewrite_cleardir($_arg_0)
{
}
function addon_sortrewrite_deltree($_arg_0)
{
}
function addon_sortrewrite_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	include_once libfile("function/core2", "plugin/addon_sortrewrite/source");
	global $_G;
	if (!defined("IN_ADMINCP")) {
		addon_sortrewrite_rewrite();
		if ($_GET["trewr_check"]) {
			addon_sortrewrite_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
			addon_sortrewrite_check();
		}
	}