<?php

function freeaddon_closepc()
{
	global $_G;
	global $navtitle;
	global $metakeywords;
	global $metadescription;
	$_var_4 = '';
	$_var_5 = $_G["cache"]["plugin"]["freeaddon_closepc"];
	$_var_6 = (array) unserialize($_var_5["page_selects"]);
	$_var_7 = (array) unserialize($_var_5["study_gids"]);
	if (!in_array(-1, $_var_6) && !in_array($_G["groupid"], $_var_7) && $_G["adminid"] != 1) {
		$_var_8 = false;
		if ($_G["inajax"] && $_var_5["inajax_radio"]) {
			$_var_8 = false;
		} else {
			if (IS_ROBOT && $_var_5["robots_radio"]) {
				$_var_8 = false;
			} else {
				if (CURSCRIPT == "forum") {
					if (in_array(1, $_var_6)) {
						$_var_8 = true;
					}
				} else {
					if (CURSCRIPT == "portal") {
						if (in_array(2, $_var_6)) {
							$_var_8 = true;
						}
					} else {
						if (CURSCRIPT == "group") {
							if (in_array(3, $_var_6)) {
								$_var_8 = true;
							}
						} else {
							if (CURSCRIPT == "home") {
								if (in_array(4, $_var_6)) {
									$_var_8 = true;
								}
							} else {
								if (CURSCRIPT == "plugin") {
									$_var_9 = explode("|", $_var_5["pluginlist"]);
									if (in_array(5, $_var_6) && !in_array(CURMODULE, $_var_9)) {
										$_var_8 = true;
									}
								} else {
									if (CURSCRIPT == "member") {
										if (in_array(6, $_var_6)) {
											$_var_8 = true;
										}
									} else {
										if (CURSCRIPT == "misc" && in_array(CURMODULE, array("seccode", "secqaa", "mobile"))) {
											$_var_8 = false;
										} else {
											if (in_array(100, $_var_6)) {
												$_var_8 = true;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if ($_var_8) {
			$navtitle = $_var_5["navtitle"];
			$metakeywords = $_var_5["metakeywords"];
			$metadescription = $_var_5["metadescription"];
			freeaddon_closepc_tpl($_var_5);
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}