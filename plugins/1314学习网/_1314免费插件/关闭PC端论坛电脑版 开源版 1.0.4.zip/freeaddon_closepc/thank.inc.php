<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 2020022501dvRdUvRWSW
 * This is NOT a freeware, use is subject to license terms
 * From www.d'.'iszz.net
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once ('pluginvar.func.php');
splugin_thinks(CURMODULE);
?>