<?php

function freeaddon_attach_auto_description($_arg_0)
{
	$_var_1 = '';
	if (is_array($_arg_0)) {
		$_var_2 = "1314";
		foreach ($_arg_0 as $_var_3 => $_var_4) {
			if (!empty($_var_4) && $_var_4) {
				if ($_var_2 == "1314") {
					$_var_1 = $_var_1 . $_var_4;
					$_var_2 = "DIY";
				} else {
					$_var_1 = $_var_1 . ("," . $_var_4);
				}
			}
		}
	}
	return $_var_1;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}