<?php

function zzbuluo_https_domain()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["zzbuluo_https"];
	$_var_2 = explode("\n", str_replace("\r\n", "\n", $_var_1["zzbuluo_domain"]));
	foreach ($_var_2 as $_var_3) {
		$_var_3 = trim($_var_3);
		if ($_var_3) {
			$_var_4 = md5($_var_3);
			$_G["setting"]["output"]["str"]["search"][$_var_4] = "http://" . $_var_3;
			$_G["setting"]["output"]["str"]["replace"][$_var_4] = "https://" . $_var_3;
		}
	}
	$_G["setting"]["rewritestatus"][] = "zzbuluo_https";
	return '';
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}