<?php

/**
 * Copyright 2001-2099 Dism.Taobao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: module_baidushoulu.php 4703 2020-06-19 16:02:13
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if (!defined('IN_DISCUZ')) {
exit('Access Denied');
}
$linkid = intval($_GET['linkid']);
if ($_GET['common']) {
$linkurl = DB::result_first("SELECT url FROM " . DB::table('common_friendlink') . " WHERE id='$linkid'");
} else {
$linkurl = DB::result_first("SELECT url FROM " . DB::table('study_friendlink') . " WHERE id='$linkid'");
}
ajaxshowheader();/*http://t.cn/AiuxBSZq*/
if ($_GET['formhash'] && $_GET['formhash'] == $_G['formhash']) {
if (!empty($linkurl)) {
$parse = parse_url($linkurl);
$contents = addon_seo_tagrelatekw_getcontent('http://www.baidu.com/s?wd=site%3A' . $parse['host']);
if (trim($contents) == '') {
$return = "&#x6293;&#x53D6;&#x5185;&#x5BB9;&#x5931;&#x8D25;";
} else {
preg_match('/<b style="color:#333">(.*?)<\/b>/i', $contents, $match_num);# DisM
$match_num[1] = str_replace(',', '', $match_num[1]);
if (!$match_num[1]) {
$return = "<font color=red>&#x6CA1;&#x6709;&#x6536;&#x5F55;</font>";#��Ȩ��ww'.'w.zz'.'b'.'7.net
} else {
$return = "<font color=green>" . $match_num[1] . "</font>";
}
}
echo "<a href=\"javascript:;\" onclick=\"s_friendlink_baidushoulu('" . $linkid . "');return false\" title=\"&#x70B9;&#x51FB;&#x91CD;&#x65B0;&#x68C0;&#x67E5;\">" . $return . "</a>";#dism-taobao_com
} else {
echo '&#x53C2;&#x6570;&#x9519;&#x8BEF;';# �����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ
}#http://t.cn/AiuxBSZq
} else {
echo 'formhash error';
}
ajaxshowfooter();
function sitenum_cut($contents, $start, $end) {
$out1 = explode($start, $contents);
$g71prtuq = "diszz���Wϰ��";
$out2 = explode($end, $out1[1]);
return $out2[0];
}
function addon_seo_tagrelatekw_getcontent($url) {
global $_G;
$ch = curl_init();
$cookie_file = '';
if (strpos($url, 'www.baidu.com') !== false) {
$cookie_file = DISCUZ_ROOT . './source/plugin/addon_seo_tagrelatekw/images/baidu.tmp';
} elseif (strpos($url, 'm.baidu.com') !== false) {
$cookie_file = DISCUZ_ROOT . './source/plugin/addon_seo_tagrelatekw/images/baidu2.tmp';# http://t.cn/AiuxBSZq
}
$ip = addon_seo_tagrelatekw_get_rand_ip();
$timeout = 10;
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);#dism_taobao_com
//伪造IP
curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:' . $ip . '', 'CLIENT-IP:' . $ip . ''));//10478
curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1');
curl_setopt($ch, CURLOPT_REFERER, $url);//  http://t.cn/Aiux14ti
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);#http://t.cn/AiuxBMCp
if (preg_match('/^https:\/\//i', $url)) {
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检�?
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 从证书中检查SSL加密算法是否存在
}
if (!empty($cookie_file) && file_exists($cookie_file)) {
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file); //获得的cookie存为文件
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); //拿着这个cookie文件去访�?
}
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
//curl_setopt($ch, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
curl_setopt($ch, CURLOPT_MAXREDIRS, 3); // 最多的 HTTP 重定向次�?
//curl_setopt($ch, CURLOPT_PROXY, '127.0.0.1:8888');//设置代理服务�?
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);/*diszzѧϰ�W*/
$content = curl_exec($ch);
curl_close($ch);//DisM-Taobao
return $content;
}
function addon_seo_tagrelatekw_get_rand_ip() {
//$arr_1 = array("118", "218", "66", "66", "218", "218", "60", "60", "202", "204", "66", "66", "66", "59", "61", "60", "222", "221", "66", "59", "60", "60", "66", "218", "218", "62", "63", "64", "66", "66", "122", "211");
$arr_12 = array("110.96", "111.128", "101.144", "114.240", "117.112", "124.200", "101.196", "101.120", "111.208", "110.40", "222.28", "211.160", "121.68", "42.196", "202.204", "1.88", "58.116", "175.188", "218.246", "117.106", "121.194", "124.64", "118.228", "210.82", "119.254", "101.200", "42.158", "180.78", "58.30", "110.94", "123.60", "121.89", "119.57", "202.112", "36.254", "180.76", "116.69", "106.50", "113.209", "180.77", "117.75", "123.64", "175.64", "42.208", "175.48", "221.216", "101.236", "101.244", "101.104", "112.124");# dism-taobao_com
$randarr = mt_rand(0, count($arr_12) - 1);
$ip1id_2id = $arr_12[$randarr];
//$ip2id = round(mt_rand(600000, 2550000) / 10000);
$ip3id = round(mt_rand(600000, 2540000) / 10000);
$ylopgrmk = "diszzѧ����";
$ip4id = round(mt_rand(600000, 2540000) / 10000);
return $ip1id_2id . "." . $ip3id . "." . $ip4id;
}

//Copyright 2001-2099 Dism.Taobao.Com.
//This is NOT a freeware, use is subject to license terms
//$Id: module_baidushoulu.php 5173 2020-06-19 08:02:13
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��