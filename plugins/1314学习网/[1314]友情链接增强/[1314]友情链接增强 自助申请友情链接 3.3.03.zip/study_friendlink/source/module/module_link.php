<?php

/**
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From ww'.'w.zz'.'b'.'7.net
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!submitcheck('linksubmit')) {

?>
<script type="text/JavaScript">
var rowtypedata = [
	[
		[1,'', 'td25'],
		[1,'<input type="text" class="txt" name="newdisplayorder[]" size="3">', 'td28'],
		[1,'<input type="text" class="txt" name="newname[]" size="15">'],
		[1,'<input type="text" class="txt" name="newurl[]" size="20">'],
		[1,'<input type="text" class="txt" name="newdescription[]" size="30">'],
		[1,'<input type="text" class="txt" name="newlogo[]" size="20">'],
		
		
		[1,'<input class="td25" type="checkbox" value="1" name="newportal[]" checked>'],
		[1,'<input class="td25" type="checkbox" value="1" name="newforum[]" checked>'],
		[1,'<input class="td25" type="checkbox" value="1" name="newgroup[]" checked>'],
		[1,'<input class="td25" type="checkbox" value="1" name="newhome[]" checked>']
	]
]
</script>
<?php
	showtips('<font color=red>&#x4F7F;&#x7528;&#x672C;&#x63D2;&#x4EF6;&#x7684;&#x8BDD;&#xFF0C;&#x6240;&#x6709;&#x53CB;&#x60C5;&#x94FE;&#x63A5;&#x5FC5;&#x987B;&#x901A;&#x8FC7;&#x672C;&#x63D2;&#x4EF6;&#xFF0C;&#x5426;&#x5219;&#x65E0;&#x6CD5;&#x81EA;&#x52A8;&#x66F4;&#x65B0;&#x7F13;&#x5B58;</font>');
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_friendlink&pmod=link');
	showtableheader();
	showsubtitle(array('', 'display_order', 'misc_link_edit_name', 'misc_link_edit_url', 'misc_link_edit_description', 'misc_link_edit_logo', $splugin_setting['friendlink_group0'] ? $splugin_setting['friendlink_group0'] : 'misc_link_group1', $splugin_setting['friendlink_group1'] ? $splugin_setting['friendlink_group1'] : 'misc_link_group2', $splugin_setting['friendlink_group2'] ? $splugin_setting['friendlink_group2'] : 'misc_link_group3',$splugin_setting['friendlink_group3'] ? $splugin_setting['friendlink_group3'] : 'misc_link_group4', '&#x53CB;&#x94FE;&#x68C0;&#x6D4B;', '&#x767E;&#x5EA6;&#x6536;&#x5F55;'));
	showsubtitle(array('', '', '', '', '', '', '<input class="td25" type="checkbox" name="portalall" onclick="checkAll(\'prefix\', this.form, \'portal\', \'portalall\')">',
		'<input class="td25" type="checkbox" name="forumall" onclick="checkAll(\'prefix\', this.form, \'forum\', \'forumall\')">',
		'<input class="td25" type="checkbox" name="groupall" onclick="checkAll(\'prefix\', this.form, \'group\', \'groupall\')">',
		'<input class="td25" type="checkbox" name="homeall" onclick="checkAll(\'prefix\', this.form, \'home\', \'homeall\')">',
		"<a href=\"javascript:;\" onclick=\"s_friendlink_checkall();return false\">&#x4E00;&#x952E;&#x68C0;&#x6D4B;</a>",
		"<a href=\"javascript:;\" onclick=\"s_friendlink_baidushouluall();return false\">&#x4E00;&#x952E;&#x67E5;&#x8BE2;</a>"));
	$js_checkfriendlinkalltext = '';
	$query = DB::query("SELECT * FROM ".DB::table('common_friendlink')." ORDER BY displayorder");
	while($forumlink = DB::fetch($query)) {
		$type = sprintf('%04b', $forumlink['type']);
		showtablerow('', array('class="td25"', 'class="td28"', '', '', ''), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$forumlink['id'].'" />',
			'<input type="text" class="txt" name="displayorder['.$forumlink[id].']" value="'.$forumlink['displayorder'].'" size="3" />',
			'<input type="text" class="txt" name="name['.$forumlink[id].']" value="'.dhtmlspecialchars(stripslashes($forumlink['name'])).'" size="15" />',
			'<input type="text" class="txt" name="url['.$forumlink[id].']" value="'.dhtmlspecialchars($forumlink['url']).'" size="20" />',
			'<input type="text" class="txt" name="description['.$forumlink[id].']" value="'.dhtmlspecialchars(stripslashes($forumlink['description'])).'" size="30" />',
			'<input type="text" class="txt" name="logo['.$forumlink[id].']" value="'.dhtmlspecialchars($forumlink['logo']).'" size="20" />',
			'<input class="td25" type="checkbox" value="1" name="portal['.$forumlink[id].']" '.($type[0] ? "checked" : '').'>',
			'<input class="td25" type="checkbox" value="1" name="forum['.$forumlink[id].']" '.($type[1] ? "checked" : '').'>',
			'<input class="td25" type="checkbox" value="1" name="group['.$forumlink[id].']" '.($type[2] ? "checked" : '').'>',
			'<input class="td25" type="checkbox" value="1" name="home['.$forumlink[id].']" '.($type[3] ? "checked" : '').'>',
			"<div id=\"link".$forumlink['id']."\" class=\"td32\"><a href=\"javascript:;\" onclick=\"s_friendlink_check('".$forumlink['id']."');return false\">&#x68C0;&#x6D4B;&#x53CB;&#x94FE;</a></div>",
			"<div id=\"baidushoulu".$forumlink['id']."\" class=\"td32\"><a href=\"javascript:;\" onclick=\"s_friendlink_baidushoulu('".$forumlink['id']."');return false\">&#x67E5;&#x8BE2;&#x6536;&#x5F55;</a></div>",
		));
		$js_checkfriendlinkalltext .= 's_friendlink_check(\''.$forumlink['id'].'\');';
	}

	echo '<tr><td></td><td colspan="3"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.$lang['misc_link_add'].'</a></div></td></tr>';
	showsubmit('linksubmit', 'submit', 'del');
	splugin_thinks($plugin['identifier'],0);
	showtablefooter();
	showformfooter();
	
	echo "
<script type=\"text/JavaScript\">
function s_friendlink_check(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=check&common=ok&formhash=".$_G['formhash']."&linkid=' + linkid, 'link' + linkid, 'link' + linkid,'loading');
}
function s_friendlink_checkall(){
	".$js_checkfriendlinkalltext."
}
function s_friendlink_baidushoulu(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=baidushoulu&common=ok&formhash=".$_G['formhash']."&linkid=' + linkid, 'baidushoulu' + linkid, 'baidushoulu' + linkid,'loading');
}
function s_friendlink_baidushouluall(){
	".str_replace('s_friendlink_check', 's_friendlink_baidushoulu', $js_checkfriendlinkalltext)."
}
function s_friendlink_pr(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=pr&common=ok&formhash=".$_G['formhash']."&linkid=' + linkid, 'pr' + linkid, 'pr' + linkid,'loading');
}
function s_friendlink_prall(){
	".str_replace('s_friendlink_check', 's_friendlink_pr', $js_checkfriendlinkalltext)."
}
</script>";



} else {
	
	//���ǰ����
	$postdata = daddslashes(dstripslashes($_POST));
	
	if($postdata['delete']) {
		DB::delete('common_friendlink', "id IN (".dimplode($postdata['delete']).")");
	}

	if(is_array($postdata['name'])) {
		foreach($postdata['name'] as $id => $val) {
			$type_str = intval($postdata['portal'][$id]).intval($postdata['forum'][$id]).intval($postdata['group'][$id]).intval($postdata['home'][$id]);
			$type_str = intval($type_str, '2');
			//daddslashes
			DB::update('common_friendlink', array(
				'displayorder' => $postdata['displayorder'][$id],
				'name' => $postdata['name'][$id],
				'url' => $postdata['url'][$id],
				'description' => $postdata['description'][$id],
				'logo' => $postdata['logo'][$id],
				'type' => $type_str,
			), array(
				'id' => intval($id),
			));
		}
	}

	if(is_array($postdata['newname'])) {
		foreach($postdata['newname'] as $key => $value) {
			if($value) {
				$type_str = intval($postdata['newportal'][$key]).intval($postdata['newforum'][$key]).intval($postdata['newgroup'][$key]).intval($postdata['newhome'][$key]);
				$type_str = intval($type_str, '2');
				DB::insert('common_friendlink', array(
					'displayorder' => $postdata['newdisplayorder'][$key],
					'name' => $value,
					'url' => $postdata['newurl'][$key],
					'description' => $postdata['newdescription'][$key],
					'logo' => $postdata['newlogo'][$key],
					'type' => $type_str,
				));
			}
		}
	}
	updatecache('forumlinks');
	require_once DISCUZ_ROOT . './source/plugin/study_friendlink/cache.func.php';
	studyFriendlinkUpdatecache();
	cpmsg('forumlinks_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_friendlink&pmod=link', 'succeed');

}
?>