<?php

/**
 *      This is NOT a freeware, use is subject to license terms
 *
 *      From ww'.'w.zz'.'b'.'7.net
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['study_friendlink'];
$splugin_lang = lang('plugin/study_friendlink');
require_once DISCUZ_ROOT.'./source/plugin/stud'.'y_friend'.'link/pluginvar.func.php';
if(!$_GET['examine']){
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_friendlink&pmod=link');
	showtableheader();
	showsubtitle(array('misc_link_edit_name', 'misc_link_edit_url', 'misc_link_edit_description', 'misc_link_edit_logo', '&#x53CB;&#x94FE;&#x68C0;&#x6D4B;', '&#x767E;&#x5EA6;&#x6536;&#x5F55;', 'PR&#x503C;', '&#x5BA1;&#x6838;'));
	$js_checkfriendlinkalltext = '';
	$query = DB::query("SELECT * FROM ".DB::table('study_friendlink')." WHERE status = '0' ORDER BY id DESC");
	while($forumlink = DB::fetch($query)) {
		$type = sprintf('%04b', $forumlink['type']);
		showtablerow('', array(), array(
			'<input type="text" class="txt" name="name['.$forumlink[id].']" value="'.dhtmlspecialchars(stripslashes($forumlink['name'])).'" size="15" />',
			'<input type="text" class="txt" name="url['.$forumlink[id].']" value="'.dhtmlspecialchars($forumlink['url']).'" size="20" />',
			'<input type="text" class="txt" name="description['.$forumlink[id].']" value="'.dhtmlspecialchars(stripslashes($forumlink['description'])).'" size="30" />',
			$forumlink['logo'] ? '<img src="'.dhtmlspecialchars($forumlink['logo']).'" border="0" alt="">' : '',
			"<div id=\"link".$forumlink['id']."\" style=\"width:48px;\"><a href=\"javascript:;\" onclick=\"s_friendlink_check('".$forumlink['id']."');return false\">&#x68C0;&#x6D4B;&#x53CB;&#x94FE;</a></div>",
			"<div id=\"baidushoulu".$forumlink['id']."\" style=\"width:48px;\"><a href=\"javascript:;\" onclick=\"s_friendlink_baidushoulu('".$forumlink['id']."');return false\">&#x67E5;&#x8BE2;&#x6536;&#x5F55;</a></div>",
			"<div id=\"pr".$forumlink['id']."\" style=\"width:48px;\"><a href=\"javascript:;\" onclick=\"s_friendlink_pr('".$forumlink['id']."');return false\">PR&#x67E5;&#x8BE2;</a></div>",
			"<div style=\"width:50px;\"><a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=adminapply&examine=yes&linkid=".$forumlink['id']."\">&#x5BA1;&#x6838;</a></div>",
		));
		$js_checkfriendlinkalltext .= 's_friendlink_check(\''.$forumlink['id'].'\');';
	}
	splugin_thinks($plugin['identifier'],0);
	showtablefooter();
	showformfooter();
	
	echo "
	<script type=\"text/JavaScript\">
	function s_friendlink_check(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=check&formhash=".$_G['formhash']."&linkid=' + linkid, 'link' + linkid, 'link' + linkid,'loading');
	}
	
	function s_friendlink_baidushoulu(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=baidushoulu&formhash=".$_G['formhash']."&linkid=' + linkid, 'baidushoulu' + linkid, 'baidushoulu' + linkid,'loading');
	}
	
	function s_friendlink_pr(linkid){
	ajaxget('".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=study_friendlink&pmod=link&s_mod=pr&formhash=".$_G['formhash']."&linkid=' + linkid, 'pr' + linkid, 'pr' + linkid,'loading');
	}
	".$js_checkfriendlinkalltext.str_replace('s_friendlink_check', 's_friendlink_baidushoulu', $js_checkfriendlinkalltext).str_replace('s_friendlink_check', 's_friendlink_pr', $js_checkfriendlinkalltext)."
	</script>";
}else{
	$linkid = intval($_GET['linkid']);
	$link = DB::fetch_first("SELECT * FROM ".DB::table('study_friendlink')." WHERE id='$linkid'");
	if(empty($link)){
		cpmsg('&#x53CB;&#x94FE;&#x4FE1;&#x606F;&#x4E0D;&#x5B58;&#x5728;&#x6216;&#x53C2;&#x6570;&#x9519;&#x8BEF;');
	}
	require_once libfile('function/mail');
	if(!submitcheck('adminsubmit')) {
			$link = dhtmlspecialchars($link);
			$actionurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=study_friendlink&pmod=adminapply&examine=yes&linkid='.$linkid;
			include template('study_friendlink:adminapply');
	}else{
			$date = date('Y-m-d H:i:s');
			if($_POST['admintype'] == 1){
					$data = array();
					$_POST = daddslashes(dstripslashes($_POST));
					$type_str = intval($_POST['portal']).intval($_POST['forum']).intval($_POST['group']).intval($_POST['home']);
					$type_str = intval($type_str, '2');
					$data = array(
						'name' => $_POST['name'],
						'url' => $_POST['url'],
						'type' => $type_str,
					);
					if($_POST['linktype'] == 'pictext'){
							$data['description'] = $_POST['description'];
							$data['logo'] = $_POST['logo'];
					}elseif($_POST['linktype'] == 'pic'){
							$data['logo'] = $_POST['logo'];
					}
					DB::insert('common_friendlink', $data);
					DB::update('study_friendlink', array('status' => '1'), array('id' => $linkid));
					if($_POST['email'] && isemail($_POST['email'])){
							sendmail($_POST['email'], $splugin_lang['slang_9'].' @ '.$date, str_replace(array('{name}', '{url}'), array($_POST['name'], $_POST['url']), $splugin_lang['slang_11']).'<br><br><br>'.$splugin_setting['email_footer']);
					}
					updatecache('forumlinks');
					require_once DISCUZ_ROOT . './source/plugin/study_friendlink/cache.func.php';
					studyFriendlinkUpdatecache();
			}elseif($_POST['admintype'] == 2){
					DB::update('study_friendlink', array('status' => '-1'), array('id' => $linkid));
					if($_POST['email'] && isemail($_POST['email'])){
							sendmail($_POST['email'], $splugin_lang['slang_9'].' @ '.$date, str_replace(array('{name}', '{url}'), array($_POST['name'], $_POST['url']), $splugin_lang['slang_12']).'<br><br><br>'.$splugin_setting['email_footer']);
					}
			}
			cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_friendlink&pmod=adminapply', 'succeed');
	}
}
?>