<?php

function study_textpane_timediff($_arg_0, $_arg_1, $_arg_2)
{
	if ($_arg_2 == 0) {
		return "-";
	}
	if ($_arg_0 < $_arg_1) {
		$_var_3 = $_arg_0;
		$_var_4 = $_arg_1;
	} else {
		$_var_3 = $_arg_1;
		$_var_4 = $_arg_0;
	}
	$_var_5 = $_var_4 - $_var_3;
	$_var_6 = intval($_var_5 / 86400);
	$_var_7 = $_var_5 % 86400;
	$_var_8 = intval($_var_7 / 3600);
	$_var_7 = $_var_7 % 3600;
	$_var_9 = intval($_var_7 / 60);
	$_var_10 = $_var_7 % 60;
	$_var_11 = '';
	if ($_var_6 > 0) {
		$_var_11 = $_var_6 . "d" . $_var_8 . "h" . $_var_9 . "m";
	} else {
		if ($_var_8 > 0) {
			$_var_11 = $_var_8 . "h" . $_var_9 . "m";
		} else {
			$_var_11 = $_var_9 . "m";
		}
	}
	return $_var_11;
}
function study_textpane_cache($_arg_0 = '')
{
	global $study_textpane_slidelist;
	global $slidelist;
	if (!is_array($study_textpane_slidelist)) {
		$study_textpane_slidelist = array();
	}
	$slidelist = array();
	if (!file_exists(DISCUZ_ROOT . "./data/sysdata/cache_study_textpane_info.php") || $_arg_0) {
		require_once libfile("function/cache");
		$_var_3 = C::t("#study_textpane#study_textpane_slide")->fetch_all_by_search(array("status" => "1"), array("displayorder" => "ASC"));
		foreach ($_var_3 as $_var_4 => $_var_5) {
			if ($_var_5["status"]) {
				if ($_var_5["pt"] == 1) {
					$slidelist["pc"][$_var_5["id"]] = $_var_5;
				} else {
					$slidelist["touch"][$_var_5["id"]] = $_var_5;
				}
			}
		}
		writetocache("study_textpane_info", "global \$slidelist,\$tslidelist;" . getcachevars(array("slidelist" => $slidelist)));
	} else {
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_textpane_info.php");
	}
	if (!empty($slidelist)) {
		$study_textpane_slidelist = $slidelist;
	}
	return $study_textpane_slidelist;
}
function study_textpane_s_filter_url($_arg_0)
{
	preg_match("/((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.)[^\\[\"']+/i", trim($_arg_0), $_var_1);
	return $_var_1[0];
}
function study_textpane_ad($_arg_0)
{
	global $_G;
	$_var_2 = array();
	$_var_3 = $_G["cache"]["plugin"]["study_textpane"];
	$_var_4 = $_var_3["study_margin"];
	if (!is_array($_var_5)) {
		$_var_5 = array();
	}
	$_var_6 = false;
	$_var_7 = array();
	$_var_8 = intval($_var_3["study_guige"] / $_var_3["study_width"]);
	$_var_9 = study_textpane_cache();
	foreach ($_var_9[$_arg_0] as $_var_10 => $_var_11) {
		if ($_G["timestamp"] > $_var_11["endtime"] && $_var_11["seat"] == 1 && $_var_11["audit"] == 1) {
			C::t("#study_textpane#study_textpane_slide")->update($_var_11["id"], array("uid" => "0", "username" => '', "audit" => 0, "title" => '', "pic" => '', "url" => '', "extidnum" => 0, "day" => 0, "starttime" => 0, "datetime" => "0", "endtime" => 0, "seat" => 0));
			$_var_11["seat"] = 0;
			$_var_6 = true;
		}
		$_var_7[$_var_10] = $_var_11;
	}
	if ($_var_6) {
		study_textpane_cache(1);
	}
	return $_var_7;
}
function study_textpane_topay($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["study_textpane"];
	$_var_3 = $_POST["typeoption"];
	$_var_3["siteurl"] = study_textpane_s_filter_url($_var_3["siteurl"]);
	$_var_3["extidnumday"] = dintval($_var_3["extidnumday"]);
	$_var_3["texid"] = dintval($_var_3["texid"]);
	$_var_4 = $_arg_0[$_var_3["extidnumday"]];
	$_var_5 = getuserprofile("extcredits" . $_var_2["study_extid"]) - $_var_4;
	$_var_6 = $_var_2["study_imagesize"] * 1024;
	if (empty($_var_3["thistitle"])) {
		showmessage(lang("plugin/study_textpane", "slang_001"));
	} else {
		if (empty($_var_3["siteurl"])) {
			showmessage(lang("plugin/study_textpane", "slang_002"));
		} else {
			if ($_var_5 < 0) {
				showmessage(lang("plugin/study_textpane", "slang_010"));
			}
		}
	}
	$_var_7 = '';
	if ($_FILES["logo"]["name"]) {
		require_once libfile("discuz/upload", "class");
		$_var_8 = new discuz_upload();
		$_var_8->init($_FILES["logo"]);
		if (!$_var_8->attach["isimage"]) {
			showmessage(lang("plugin/study_textpane", "slang_003"));
		}
		if (!$_var_8->errorcode) {
			if ($_var_6 && $_var_8->attach["size"] > $_var_6) {
				showmessage(lang("plugin/study_textpane", "slang_004") . " " . $_var_6);
			}
			$_var_9[] = $_var_10;
		}
		$_var_11 = "data/attachment/study_textpane";
		$_var_12 = date("Ym") . "/" . date("d") . "/";
		$_var_13 = $_var_11 . "/" . $_var_12;
		dmkdir($_var_13);
		$_var_7 = $_var_13 . date("His") . strtolower(random(16)) . "_" . $_G["uid"] . "." . $_var_8->get_target_extension($_var_8->attach["ext"]);
		$_var_8->save_to_local($_var_8->attach["tmp_name"], $_var_7);
	}
	if (empty($_var_7)) {
		showmessage(lang("plugin/study_textpane", "slang_005"));
	}
	$_var_14 = C::t("#study_textpane#study_textpane_slide")->fetch_by_search(array("id" => $_var_3["texid"]));
	if (empty($_var_14)) {
		showmessage(lang("plugin/study_textpane", "slang_012"));
	} else {
		if ($_var_14["seat"] == 1 && $_var_14["status"] == 0) {
			showmessage(lang("plugin/study_textpane", "slang_013"));
		}
	}
	$_var_15 = $_var_16 = array("uid" => $_G["uid"], "username" => $_G["username"], "pt" => "1", "title" => $_var_3["thistitle"], "pic" => $_var_7, "url" => $_var_3["siteurl"], "extidnum" => $_var_4, "extid" => $_var_2["study_extid"], "day" => $_var_3["extidnumday"], "datetime" => $_G["timestamp"], "seat" => 1);
	$_var_16["audit"] = 0;
	$_var_17 = lang("plugin/study_textpane", "slang_007") . $_var_3["extidnumday"] . lang("plugin/study_textpane", "slang_008") . $_var_4 . $_G["setting"]["extcredits"][$_var_2["study_extid"]]["title"];
	updatemembercount($_G["uid"], array("extcredits" . $_var_2["study_extid"] => "-" . $_var_4), true, '', 0, '', lang("plugin/study_textpane", "slang_006"), $_var_17);
	C::t("#study_textpane#study_textpane_record")->insert($_var_15);
	C::t("#study_textpane#study_textpane_slide")->update($_var_3["texid"], $_var_16);
	study_textpane_cache(1);
	showmessage(lang("plugin/study_textpane", "slang_011"), dreferer());
}
function study_textpane_pic($_arg_0)
{
	global $_G;
	$_var_2 = '';
	require_once libfile("discuz/upload", "class");
	$_var_3 = new discuz_upload();
	$_var_3->init($_FILES["pic"]);
	if ($_var_3->errorcode) {
		if ($_arg_0) {
			showmessage(lang("plugin/study_textpane", "slang_026"), dreferer());
		}
		cpmsg("&#x56FE;&#x7247;&#x4E0D;&#x80FD;&#x4E3A;&#x7A7A;", '', "error");
	} else {
		if (!$_var_3->attach["isimage"]) {
			if ($_arg_0) {
				showmessage(lang("plugin/study_textpane", "slang_027"), dreferer());
			}
			cpmsg("&#x56FE;&#x7247;&#x683C;&#x5F0F;&#x9519;&#x8BEF;", '', "error");
		}
	}
	$_var_4 = $_var_3->attach["tmp_name"];
	$_var_5 = "data/attachment/study_textpane/slide";
	$_var_6 = date("Ym") . "/" . date("d") . "/";
	$_var_7 = $_var_5 . "/" . $_var_6;
	dmkdir($_var_7);
	$_var_8 = $_var_7 . date("His") . strtolower(random(16)) . "." . $_var_3->attach["ext"];
	if ($_var_3->save_to_local($_var_4, $_var_8)) {
		$_var_2 = $_var_8;
		@unlink($_var_9["pic"]);
	}
	return $_var_2;
}
function study_textpane_audit()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["study_textpane"];
	$_var_2 = $_POST["typeoption"];
	$_var_2["siteurl"] = study_textpane_s_filter_url($_var_2["siteurl"]);
	$_var_3 = dintval($_var_2["texid"]);
	$_var_4 = in_array(intval($_POST["auditt"]), array(1, 2, 3)) ? intval($_POST["auditt"]) : 0;
	if (empty($_var_2["thistitle"])) {
		showmessage(lang("plugin/study_textpane", "slang_001"));
	} else {
		if (empty($_var_2["siteurl"])) {
			showmessage(lang("plugin/study_textpane", "slang_002"));
		}
	}
	$_var_5 = '';
	$_var_6 = C::t("#study_textpane#study_textpane_slide")->fetch_by_search(array("id" => $_var_3));
	if (empty($_var_6)) {
		showmessage(lang("plugin/study_textpane", "slang_012"));
	} else {
		if ($_var_6["seat"] == 1 && $_var_6["status"] == 0) {
			showmessage(lang("plugin/study_textpane", "slang_013"));
		}
	}
	$_var_7 = array("title" => $_var_2["thistitle"], "url" => $_var_2["siteurl"]);
	if (!empty($_FILES["pic"]["name"])) {
		$_var_8 = study_textpane_pic(1);
		if (!empty($_var_8)) {
			$_var_7["pic"] = $_var_8;
		}
	}
	if ($_var_4 == 0) {
		C::t("#study_textpane#study_textpane_slide")->update($_var_3, $_var_7);
		study_textpane_cache(1);
		showmessage(lang("plugin/study_textpane", "slang_022"), dreferer());
	} else {
		if ($_var_4 == 1) {
			$_var_9 = 86400 * $_var_6["day"] + $_G["timestamp"];
			$_var_7["starttime"] = $_G["timestamp"];
			$_var_7["endtime"] = $_var_9;
			$_var_7["audit"] = 1;
			C::t("#study_textpane#study_textpane_slide")->update($_var_3, $_var_7);
			C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_6["datetime"]), array("note" => lang("plugin/study_textpane", "slang_023")));
			study_textpane_cache(1);
			showmessage(lang("plugin/study_textpane", "slang_023"), dreferer());
		} else {
			if ($_var_4 == 2) {
				C::t("#study_textpane#study_textpane_slide")->update($_var_6["id"], array("uid" => "0", "username" => '', "audit" => "0", "pic" => '', "title" => '', "url" => '', "extidnum" => 0, "day" => 0, "starttime" => 0, "datetime" => "0", "endtime" => 0, "seat" => 0));
				C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_6["datetime"]), array("note" => lang("plugin/study_textpane", "slang_024")));
				if ($_var_6["extidnum"] != 0) {
					$_var_10 = lang("plugin/study_textpane", "slang_024") . $_var_6["extidnum"] . $_G["setting"]["extcredits"][$_var_1["study_extid"]]["title"];
					updatemembercount($_var_6["uid"], array("extcredits" . $_var_1["study_extid"] => "+" . $_var_6["extidnum"]), true, '', 0, '', lang("plugin/study_textpane", "slang_006"), $_var_10);
				}
				study_textpane_cache(1);
				showmessage(lang("plugin/study_textpane", "slang_025"), dreferer());
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}