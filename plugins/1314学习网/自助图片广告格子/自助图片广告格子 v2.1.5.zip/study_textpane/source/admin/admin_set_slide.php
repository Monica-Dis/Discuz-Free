<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $type1314;
	global $op;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	require_once libfile("function/core", "plugin/study_textpane/source");
	$_var_8 = array("list", "edit", "adds", "audits");
	$op = in_array($_GET["op"], $_var_8) ? $_GET["op"] : "list";
	$_var_9 = $_GET["type1314"];
	$splugin_setting = $_G["cache"]["plugin"]["study_textpane"];
	if ($op == "list") {
		if (!submitcheck("submit")) {
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10);
			showtableheader('');
			$_var_11 = $_var_12 = array();
			if ($_var_9 == "record") {
				showsubtitle(array("del", "&#73;&#68;", "&#29992;&#25143;&#21517;", "&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "&#24191;&#21578;&#38142;&#25509;", "&#28040;&#32791;&#31215;&#20998;", "&#25552;&#20132;&#26085;&#26399;", "&#26102;&#38271;", "&#22791;&#27880;", ''));
			} else {
				showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#29992;&#25143;&#21517;", "&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "&#24191;&#21578;&#38142;&#25509;", "&#21551;&#29992;", "&#21097;&#20313;&#26102;&#38388;", "&#36141;&#20080;&#26102;&#38388;", "&#x7ED3;&#x675F;   &#x65F6;&#x95F4;", "&#23457;&#26680;", "&#x64CD;&#x4F5C;", ''));
			}
			if ($_var_9 == "touchslide") {
				$_var_13 = C::t("#study_textpane#study_textpane_slide")->fetch_all_by_search(array("pt" => "2"), array("displayorder" => "ASC", "id" => "ASC"));
			} else {
				if ($_var_9 == "record") {
					$_var_13 = C::t("#study_textpane#study_textpane_record")->fetch_all_by_search(array(), array("id" => "DESC"));
				} else {
					$_var_13 = C::t("#study_textpane#study_textpane_slide")->fetch_all_by_search(array("pt" => "1"), array("displayorder" => "ASC", "id" => "ASC"));
				}
			}
			if ($_var_9 == "record") {
				foreach ($_var_13 as $_var_14) {
					$_var_15 = $_var_14["audit"] == 0 ? "&#24453;&#23457;" : $_var_14["audit"] == 1 ? "&#23457;&#26680;&#36890;&#36807;" : "&#23457;&#26680;&#22833;&#36133;&#36820;&#22238;&#31215;&#20998;";
					showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td25\"", "class=\"td32\"", "class=\"td31\"", "class=\"td31\"", " style=\"width:60px;\"", " style=\"width:160px;\"", " style=\"width:100px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_14["id"] . "\" " . $_var_16 . ">", $_var_14["uid"], $_var_14["username"], "<a href=\"" . $_var_14["pic"] . "\" target=\"_blank\"  class=\"tooltip\"><img src=\"" . $_var_14["pic"] . "\" style=\"width:50px;height: 50px;\"></a>", "<input type=\"text\" name=\"title[" . $_var_14["id"] . "]\" value=\"" . $_var_14["title"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", "<input type=\"text\" name=\"url[" . $_var_14["id"] . "]\" value=\"" . $_var_14["url"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", $_var_14["extidnum"] . $_G["setting"]["extcredits"][$_var_14["extid"]]["title"], date("Y-m-d H:i", $_var_14["datetime"]), $_var_14["day"] . "&#22825;", empty($_var_14["note"]) ? "&#24453;&#23457;&#29366;&#24577;" : $_var_14["note"], ''));
				}
				showsubmit("submit", "submit", "del");
			} else {
				$_var_17 = false;
				foreach ($_var_13 as $_var_14) {
					if ($_var_14["seat"] == 1 && $_var_14["audit"] == 1) {
						if ($_G["timestamp"] > $_var_14["endtime"]) {
							C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_14["datetime"]), array("note" => "&#36890;&#36807;&#19988;&#21040;&#26399;"));
							C::t("#study_textpane#study_textpane_slide")->update($_var_14["id"], array("uid" => "0", "username" => '', "audit" => "0", "title" => '', "pic" => '', "url" => '', "extidnum" => 0, "datetime" => "0", "day" => 0, "starttime" => 0, "endtime" => 0, "seat" => 0));
							$_var_17 = true;
						}
					}
					if ($_var_14["seat"] == 0) {
						$_var_18 = "&#34394;&#22352;&#20197;&#24453;";
						$_var_19 = "-";
						$_var_20 = "-";
						$_var_21 = "-";
						$_var_22 = "-";
						$_var_23 = "-";
						$_var_24 = "-";
						$_var_15 = "-";
						$_var_25 = "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_14["id"] . "\" class=\"act\">" . cplang("edit") . "</a>";
					} else {
						$_var_18 = $_var_14["username"];
						$_var_19 = "<a href=\"" . $_var_14["pic"] . "\" target=\"_blank\"  class=\"tooltip\"><img src=\"" . $_var_14["pic"] . "\" style=\"width:50px;height: 50px;\"></a>";
						$_var_20 = "<input type=\"text\" name=\"title[" . $_var_14["id"] . "]\" value=\"" . $_var_14["title"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">";
						$_var_21 = "<input type=\"text\" name=\"url[" . $_var_14["id"] . "]\" value=\"" . $_var_14["url"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">";
						$_var_22 = study_textpane_timediff($_var_14["endtime"], $_G["timestamp"], $_var_14["audit"]);
						$_var_23 = $_var_14["day"] . "&#22825;";
						if ($_var_14["audit"] == 0) {
							$_var_24 = "-";
							$_var_25 = "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_14["id"] . "\" class=\"act\">" . cplang("edit") . "</a>" . "|<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=audits&cid=" . $_var_14["id"] . "&audito=1\" class=\"act\"><font color=\"red\">&#23457;&#26680;&#36890;&#36807;</font></a>" . "|<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=audits&cid=" . $_var_14["id"] . "&audito=2\" class=\"act\"><font color=\"green\">&#x5BA1;&#x6838;&#x5931;&#x8D25;</font></a>";
						} else {
							$_var_24 = "<input type=\"text\" class=\"txt\" name=\"endt[" . $_var_14["id"] . "]\" style=\"width: 120px;\"  value=\"" . ($_var_14["endtime"] == 0 ? '' : date("Y-m-d H:i", $_var_14["endtime"])) . "\" onclick=\"showcalendar(event, this, 1)\">";
							$_var_25 = "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_14["id"] . "\" class=\"act\">" . cplang("edit") . "</a>" . "|<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=audits&cid=" . $_var_14["id"] . "&audito=3\" class=\"act\">&#28165;&#31354;</a>";
						}
						$_var_15 = $_var_14["audit"] == 1 ? "<font color=\"red\">&#x901A;&#x8FC7;</font>" : "<font color=\"green\">&#x5F85;&#x5BA1;</font>";
					}
					showtablerow('', array("class=\"td25\"", "class=\"td25\"", "style=\"width:75px;\"", "style=\"width:70px;\"", "style=\"width:90px;\"", "style=\"width:90px;\"", "style=\"width:30px;\"", "style=\"width:80px;\"", " style=\"width:60px;\"", "style=\"width:60px;\"", " style=\"width:30px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_14["id"] . "\" " . $_var_16 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_14["id"] . "]\" value=\"" . $_var_14["displayorder"] . "\" style=\"height: 20px;\">", $_var_18, $_var_19, $_var_20, $_var_21, "<div style=\"width:30px;\"><input name=\"status[" . $_var_14["id"] . "]\" type=\"checkbox\" value=\"1\" " . ($_var_14["status"] ? "checked=\"checked=\"" : '') . "/></div>", $_var_22, $_var_23, $_var_24, $_var_15, $_var_25, ''));
				}
				if ($_var_17) {
					study_textpane_cache(1);
				}
				echo "<tr><td></td><td colspan=\"7\"><div><a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=adds\" class=\"addtr\">&#28155;&#21152;&#24191;&#21578;&#20301;</a></div></td></tr>";
				showsubmit("submit", "submit", "del");
			}
			showtablefooter();
			showformfooter();
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_26) {
					$_var_26 = intval($_var_26);
					if ($_var_9 == "record") {
						C::t("#study_textpane#study_textpane_record")->delete_by_where(array("id" => $_var_26), true);
					} else {
						C::t("#study_textpane#study_textpane_slide")->delete_by_where(array("id" => $_var_26), true);
					}
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_26 => $_var_27) {
					C::t("#study_textpane#study_textpane_slide")->update($_var_26, array("title" => $_POST["title"][$_var_26], "status" => $_POST["status"][$_var_26], "url" => $_POST["url"][$_var_26], "endtime" => empty($_POST["endt"][$_var_26]) ? 0 : strtotime($_POST["endt"][$_var_26]), "displayorder" => $_POST["order"][$_var_26]));
				}
			}
			study_textpane_cache(1);
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10, "succeed");
		}
	} else {
		if ($op == "edit") {
			$_var_26 = intval($_GET["cid"]);
			$_var_14 = C::t("#study_textpane#study_textpane_slide")->fetch_by_search(array("id" => $_var_26));
			if (!submitcheck("submit")) {
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10 . "&cid=" . $_var_26, "enctype");
				showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "title", $_var_14["title"], "text", '', '', '');
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "pic", $_var_14["pic"], "filetext", '', '', "&#22270;&#29255;&#23610;&#23544;&#58;" . $splugin_setting["study_width"] . "*" . $splugin_setting["study_height"] . "(px)");
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x94FE;&#x63A5;", "url", $_var_14["url"], "text", '', '', '');
				if ($_var_14["seat"] == 0 && $_var_14["audit"] == 0) {
					s_showsetting("&#28155;&#21152;&#22810;&#23569;&#22825;", "extidnumday", "1", "number", '', '', '');
				} else {
					if ($_var_14["seat"] == 1 && $_var_14["audit"] == 1) {
						s_showsetting("&#x7ED3;&#x675F;&#x65F6;&#x95F4;", "endt", $_var_14["endtime"] == 0 ? '' : date("Y-m-d H:i:s", $_var_14["endtime"]), "calendar", '', '', '', 1);
					}
				}
				s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", $_var_14["status"] === 0 ? 0 : 1, "radio", '', '', '');
				s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", $_var_14["displayorder"], "number", '', '', '');
				showtableheader();
				showsubmit("submit", "submit");
				showformfooter();
			} else {
				if ($_var_14["seat"] == 0 && $_var_14["audit"] == 0) {
					$_var_28 = array("title" => $_POST["title"], "url" => $_POST["url"], "uid" => $_var_14["uid"] == 0 ? $_G["uid"] : $_var_14["uid"], "username" => empty($_var_14["username"]) ? $_G["username"] : $_var_14["username"], "status" => dintval($_POST["status"]), "audit" => 1, "seat" => 1, "displayorder" => dintval($_POST["displayorder"]));
					$_var_28["day"] = dintval($_POST["extidnumday"]) == 0 ? 1 : dintval($_POST["extidnumday"]);
					$_var_28["endtime"] = 86400 * $_POST["extidnumday"] + $_G["timestamp"];
				} else {
					if ($_var_14["seat"] == 1 && $_var_14["audit"] == 1) {
						$_var_28 = array("title" => $_POST["title"], "url" => $_POST["url"], "username" => empty($_var_14["username"]) ? $_G["username"] : $_var_14["username"], "status" => dintval($_POST["status"]), "displayorder" => dintval($_POST["displayorder"]));
						$_var_28["endtime"] = strtotime($_POST["endt"]);
					} else {
						$_var_28 = array("title" => $_POST["title"], "url" => $_POST["url"], "username" => empty($_var_14["username"]) ? $_G["username"] : $_var_14["username"], "status" => dintval($_POST["status"]), "displayorder" => dintval($_POST["displayorder"]));
					}
				}
				if ($_FILES["pic"]) {
					$_var_29 = study_textpane_pic();
					if (!empty($_var_29)) {
						$_var_28["pic"] = $_var_29;
					}
				} else {
					$_var_28["pic"] = $_POST["pic"];
				}
				C::t("#study_textpane#study_textpane_slide")->update($_var_26, $_var_28, 1);
				study_textpane_cache(1);
				cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
			}
		} else {
			if ($op == "audits") {
				$_var_30 = intval($_GET["audito"]);
				$_var_26 = intval($_GET["cid"]);
				$_var_14 = C::t("#study_textpane#study_textpane_slide")->fetch_by_search(array("id" => $_var_26));
				if ($_var_30 == 1) {
					$_var_31 = 86400 * $_var_14["day"] + $_G["timestamp"];
					$_var_28 = array("starttime" => $_G["timestamp"], "endtime" => $_var_31, "audit" => 1);
					C::t("#study_textpane#study_textpane_slide")->update($_var_26, $_var_28);
					C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_14["datetime"]), array("note" => "&#23457;&#26680;&#36890;&#36807;"));
					study_textpane_cache(1);
					cpmsg("&#x5BA1;&#x6838;&#x901A;&#x8FC7;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
				} else {
					if ($_var_30 == 2) {
						C::t("#study_textpane#study_textpane_slide")->update($_var_14["id"], array("uid" => "0", "username" => '', "audit" => "0", "title" => '', "pic" => '', "url" => '', "extidnum" => 0, "day" => 0, "starttime" => 0, "datetime" => "0", "endtime" => 0, "seat" => 0));
						C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_14["datetime"]), array("note" => "&#23457;&#26680;&#22833;&#36133;&#36820;&#22238;&#31215;&#20998;"));
						if ($_var_14["extidnum"] != 0) {
							$_var_32 = "&#23457;&#26680;&#22833;&#36133;&#36820;&#36824;&#31215;&#20998;" . $_var_14["extidnum"] . $_G["setting"]["extcredits"][$splugin_setting["study_extid"]]["title"];
							updatemembercount($_var_14["uid"], array("extcredits" . $splugin_setting["study_extid"] => "+" . $_var_14["extidnum"]), true, '', 0, '', lang("plugin/study_textpane", "slang_006"), $_var_32);
						}
						study_textpane_cache(1);
						cpmsg("&#x5BA1;&#x6838;&#x5931;&#x8D25;&#x8FD4;&#x56DE;&#x79EF;&#x5206;&#x7ED9;&#x7528;&#x6237;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
					} else {
						if ($_var_30 == 3) {
							C::t("#study_textpane#study_textpane_slide")->update($_var_14["id"], array("uid" => "0", "username" => '', "audit" => "0", "title" => '', "pic" => '', "url" => '', "extidnum" => 0, "day" => 0, "starttime" => 0, "datetime" => "0", "endtime" => 0, "seat" => 0));
							C::t("#study_textpane#study_textpane_record")->update_by_where(array("datetime" => $_var_14["datetime"]), array("note" => "&#25552;&#21069;&#28165;&#31354;&#22788;&#29702;"));
							study_textpane_cache(1);
							cpmsg("&#28165;&#31354;&#35813;&#26465;&#25968;&#25454;&#25104;&#21151;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
						}
					}
				}
			} else {
				if ($op == "adds") {
					if (!submitcheck("submit")) {
						showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10 . "&cid=" . $_var_26, "enctype");
						showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
						s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "title", $_var_14["title"], "text", '', '', '');
						s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "pic", $_var_14["pic"], "filetext", '', '', "&#22270;&#29255;&#23610;&#23544;&#58;" . $splugin_setting["study_width"] . "*" . $splugin_setting["study_height"] . "(px)" . "&#40;&#26410;&#19978;&#20256;&#22270;&#29255;&#26159;&#40664;&#35748;&#21482;&#28155;&#21152;&#24191;&#21578;&#20301;&#25968;&#37327;&#41;");
						s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x94FE;&#x63A5;", "url", $_var_14["url"], "text", '', '', '');
						s_showsetting("&#28155;&#21152;&#22810;&#23569;&#22825;", "extidnumday", "1", "number", '', '', '');
						s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", $_var_14["status"] === 0 ? 0 : 1, "radio", '', '', '');
						s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", $_var_14["displayorder"], "number", '', '', '');
						showtableheader();
						showsubmit("submit", "submit");
						showformfooter();
					} else {
						if (empty($_var_14)) {
							if (!empty($_FILES["pic"]["tmp_name"])) {
								$_var_28 = array("title" => $_POST["title"], "url" => $_POST["url"], "uid" => $_var_14["uid"] == 0 ? $_G["uid"] : $_var_14["uid"], "username" => empty($_var_14["username"]) ? $_G["username"] : $_var_14["username"], "status" => dintval($_POST["status"]), "day" => dintval($_POST["extidnumday"]), "audit" => 1, "starttime" => $_G["timestamp"], "endtime" => 86400 * $_POST["extidnumday"] + $_G["timestamp"], "seat" => 1, "displayorder" => dintval($_POST["displayorder"]));
								$_var_29 = study_textpane_pic();
								if (!empty($_var_29)) {
									$_var_28["pic"] = $_var_29;
								}
								C::t("#study_textpane#study_textpane_slide")->insert($_var_28);
							} else {
								$_var_28 = array("status" => dintval($_POST["status"]), "seat" => 0);
								C::t("#study_textpane#study_textpane_slide")->insert($_var_28);
							}
						}
						study_textpane_cache(1);
						cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
					}
				}
			}
		}
	}
	echo "\r\n<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>\r\n<script type=\"text/javascript\" src=\"source/plugin/study_textpane/images/jquery-1.10.2.min.js\"></script>\r\n<script type=\"text/javascript\">\r\njQuery.noConflict();\r\njQuery(function () {\r\nvar x = 10;\r\nvar y = 20;\r\njQuery(\"a.tooltip\").mouseover(function (e) {\r\nthis.myTitle = this.title;\r\nthis.title = \"\";\r\nvar imgTitle = this.myTitle ? \"<br />\" + this.myTitle + \" \" : \"\";\r\nvar tooltip = \"<div id='tooltip'><img src='\" + this.href + \"'  width='100%' height='100%' />\" + imgTitle + \"</div>\";\r\njQuery(\"body\").append(tooltip);\r\njQuery(\"#tooltip\")\r\n.css({\r\n\"top\": (e.pageY + y) + \"px\",\r\n\"left\": (e.pageX + x) + \"px\"\r\n}).show(\"fast\");\r\n}).mouseout(function (e) {\r\nthis.title = this.myTitle;\r\njQuery(\"#tooltip\").remove();\r\n}).mousemove(function (e) {\r\njQuery(\"#tooltip\").css({\r\n\"top\": (e.pageY + y) + \"px\",\r\n\"left\": (e.pageX + x) + \"px\"\r\n});\r\n});\r\n})\r\n</script>\r\n<style>\r\n#tooltip{\r\nposition: absolute;\r\nbackground-color: #eee;\r\nborder: 1px solid #999;\r\n}\r\n #hourminute .px {\r\n    width:20px;\r\n}\r\n\r\n</style>\r\n";