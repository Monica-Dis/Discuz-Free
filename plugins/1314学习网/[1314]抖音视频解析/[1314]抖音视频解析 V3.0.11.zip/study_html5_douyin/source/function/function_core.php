<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_html5_douyin_discuzcode($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["study_html5_douyin"];
	$_var_3 = strtolower($_G["discuzcodemessage"]);
	if (strpos($_var_3, "douyin.com") !== false || strpos($_var_3, "b23.tv") !== false) {
		if ($_var_2["media_radio"] && strpos($_var_3, "[/media]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[media(=([\\w,]+))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/media\\]/is", "study_html5_douyin_callback_parsemedia", $_G["discuzcodemessage"]);
		}
		if ($_var_2["flash_radio"] && strpos($_var_3, "[/flash]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[flash(=(\\d+),(\\d+))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/flash\\]/is", "study_html5_douyin_callback_parseflash", $_G["discuzcodemessage"]);
		}
		if ($_var_2["url_radio"] && strpos($_var_3, "[/url]") !== false) {
			$_G["discuzcodemessage"] = preg_replace_callback("/\\[url(=([^\\]]+))?\\](.+?)\\[\\/url\\]/is", "study_html5_douyin_callback_parseurl", $_G["discuzcodemessage"]);
		}
		if (!isset($_G["study_html5_douyin_texts"])) {
			$_G["study_html5_douyin_texts"] = explode("\n", str_replace("\r\n", "\n", $_var_2["texts"]));
		}
		foreach ($_G["study_html5_douyin_texts"] as $_var_4) {
			if (!empty($_var_4)) {
				$_G["discuzcodemessage"] = str_replace($_var_4, '', $_G["discuzcodemessage"]);
			}
		}
	}
}
function study_html5_douyin_callback_parsemedia($_arg_0)
{
	global $_G;
	$_var_2 = study_html5_douyin_callback_parse($_arg_0[3]);
	if (empty($_var_2)) {
		$_var_3 = $_arg_0[0];
	} else {
		$_var_3 = $_var_2;
	}
	return $_var_3;
}
function study_html5_douyin_callback_parseurl($_arg_0)
{
	global $_G;
	$_var_2 = $_arg_0[0];
	if (empty($_arg_0[2])) {
		$_arg_0[2] = $_arg_0[3];
	}
	$_var_3 = study_html5_douyin_callback_parse($_arg_0[2]);
	if (empty($_var_3)) {
		$_var_2 = $_arg_0[0];
	} else {
		$_var_2 = $_var_3;
	}
	return $_var_2;
}
function study_html5_douyin_callback_parseflash($_arg_0)
{
	global $_G;
	$_var_2 = study_html5_douyin_callback_parse($_arg_0[4]);
	if (empty($_var_2)) {
		$_var_3 = $_arg_0[0];
	} else {
		$_var_3 = $_var_2;
	}
	return $_var_3;
}
function study_html5_douyin_callback_parse($_arg_0)
{
	global $_G;
	$_var_2 = '';
	$_arg_0 = str_replace("b23.tv/", "wwww.bilibili.com/video/", $_arg_0);
	preg_match("#^https?://[\\w-]+\\.douyin\\.com/([\\w]+)/#is", $_arg_0, $_var_3);
	if (empty($_var_3[1])) {
		preg_match("#^https?://[\\w-]+\\.iesdouyin\\.com/share/video/([\\d]+)/#is", $_arg_0, $_var_3);
	}
	if (!empty($_var_3[1])) {
		if (defined("IN_MOBILE")) {
			$_var_4 = $_G["cache"]["plugin"]["study_html5_douyin"]["touch_width"];
			$_var_5 = $_G["cache"]["plugin"]["study_html5_douyin"]["touch_height"];
		} else {
			$_var_4 = $_G["cache"]["plugin"]["study_html5_douyin"]["pc_width"];
			$_var_5 = $_G["cache"]["plugin"]["study_html5_douyin"]["pc_height"];
		}
		$_var_6 = "plugin.php?id=study_html5_douyin&url=" . rawurlencode(authcode($_arg_0, "ENCODE", md5($_G["config"]["security"]["authkey"] . "study_html5_douyin"), 3600));
		$_var_2 = "<iframe width=\"" . $_var_4 . "\" height=\"" . $_var_5 . "\" src=\"" . $_var_6 . "\" style=\"margin: 10px 0px;\" frameborder=\"0\" border=\"0\" scrolling=\"no\" allowfullscreen=\"true\" seamless></iframe>";
	}
	return $_var_2;
}
function study_html5_douyin_getvideourl()
{
	global $_G;
	$_var_1 = $_var_2 = '';
	$_var_3 = authcode($_GET["url"], "DECODE", md5($_G["config"]["security"]["authkey"] . "study_html5_douyin"));
	preg_match("#^https?://[\\w-]+\\.iesdouyin\\.com/share/video/([\\d]+)/#is", $_var_3, $_var_4);
	if (empty($_var_4[1])) {
		$_var_5 = study_html5_douyin_getcontent($_var_3);
		preg_match("#video/([\\d]+)/\\?region#is", $_var_5, $_var_4);
	}
	if (!empty($_var_4[1])) {
		$_var_6 = json_decode(study_html5_douyin_getcontent("https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids=" . $_var_4[1]), true);
		if ($_var_6["item_list"][0]["video"]["play_addr"]["url_list"][0]) {
			$_var_1 = $_var_6["item_list"][0]["video"]["play_addr"]["url_list"][0];
			if ($_var_6["item_list"][0]["video"]["cover"]["url_list"][0]) {
				$_var_2 = $_var_6["item_list"][0]["video"]["cover"]["url_list"][0];
			}
		}
	}
	return array("videourl" => $_var_1, "cover" => $_var_2);
}
function study_html5_douyin_randip()
{
	$_var_0 = array("110.96", "111.128", "101.144", "114.240", "117.112", "124.200", "101.196", "101.120", "111.208", "110.40", "222.28", "211.160", "121.68", "42.196", "202.204", "1.88", "58.116", "175.188", "218.246", "117.106", "121.194", "124.64", "118.228", "210.82", "119.254", "101.200", "42.158", "180.78", "58.30", "110.94", "123.60", "121.89", "119.57", "202.112", "36.254", "180.76", "116.69", "106.50", "113.209", "180.77", "117.75", "123.64", "175.64", "42.208", "175.48", "221.216", "101.236", "101.244", "101.104", "112.124");
	$_var_1 = mt_rand(0, count($_var_0) - 1);
	$_var_2 = $_var_0[$_var_1];
	$_var_3 = round(mt_rand(600000, 2540000) / 10000);
	$_var_4 = round(mt_rand(600000, 2540000) / 10000);
	return $_var_2 . "." . $_var_3 . "." . $_var_4;
}
function study_html5_douyin_getcontent($_arg_0)
{
	global $_G;
	$_var_2 = curl_init();
	if (strpos($_arg_0, ".douyin.com") === false && strpos($_arg_0, ".iesdouyin.com") === false) {
		return '';
	}
	$_var_3 = study_html5_douyin_randip();
	$_var_4 = 10;
	curl_setopt($_var_2, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_2, CURLOPT_TIMEOUT, 30);
	curl_setopt($_var_2, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_var_3 . '', "CLIENT-IP:" . $_var_3 . ''));
	curl_setopt($_var_2, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1");
	curl_setopt($_var_2, CURLOPT_REFERER, $_arg_0);
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_HEADER, 0);
	if (preg_match("/^https:\\/\\//i", $_arg_0)) {
		curl_setopt($_var_2, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($_var_2, CURLOPT_SSL_VERIFYHOST, false);
	}
	curl_setopt($_var_2, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($_var_2, CURLOPT_CONNECTTIMEOUT, $_var_4);
	$_var_5 = curl_exec($_var_2);
	curl_close($_var_2);
	return $_var_5;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}