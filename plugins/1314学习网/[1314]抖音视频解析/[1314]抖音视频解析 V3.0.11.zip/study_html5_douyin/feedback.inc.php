<?php
 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

echo '<script type="text/javascript">location.href=\'http://suo.im/5D3dJB\';</script>';
exit;