<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	require_once libfile("class/rule", "plugin/addon_collect_tieba/source");
	loadcache("plugin");
	if (!empty($_G["cache"]["plugin"]["addon_collect_tieba"])) {
		$_var_1 = $_G["cache"]["plugin"]["addon_collect_tieba"];
		$_var_1["autopost_jiange"] = min(86400, max(60, intval($_var_1["autopost_jiange"])));
		$_var_2 = "//";
		if (defined("IN_COLLECT_CRON")) {
			$_var_2 = $_var_2 . ("on cron");
		} else {
			$_var_3 = array();
			$_var_4 = "DZS_AUTOJIANGE_TIEBA_" . $_var_1["autopost_jiange"];
			if (!discuz_process::islocked($_var_4, $_var_1["autopost_jiange"])) {
				if (in_array($_var_1["auto_collect_radio"], array("1", "3"))) {
					$_var_2 = $_var_2 . ("-collect");
					if (addon_collect_tieba_rule_dealtime($_var_1["study_start_time"])) {
						$_var_2 = $_var_2 . "-t";
						$_var_5 = $_G["timestamp"] - 3600;
						$_var_3 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_all_by_search(array("updatetime" => array($_var_5, "<"), "status" => "1"), array("updatetime" => "ASC"), 1);
					}
					if (!empty($_var_3)) {
						$_var_2 = $_var_2 . "-s";
						$_var_6 = new addon_collect_tieba_rule();
						foreach ($_var_3 as $_var_7) {
							$_var_2 = $_var_2 . ("." . $_var_7["id"]);
							$_var_8 = "DZS_AUTOANALYZE_TIEBA_" . $_var_7["id"];
							if (!discuz_process::islocked($_var_8, 15)) {
								$_var_9 = $_var_6->analyze($_var_7);
								if ($_var_9 === false) {
									C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update_by_where(array("id" => $_var_7["id"]), array("status" => 0), true);
								} else {
									$_var_10 = $_var_11 = array();
									$_var_11 = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->fetch_all_by_search(array("spiderid" => $_var_7["id"]), array("creattime" => "DESC"), 40);
									foreach ($_var_11 as $_var_12) {
										$_var_10[] = $_var_12["sha1"];
									}
									$_var_13 = 0;
									$_var_9["articlelist"] = array_reverse($_var_9["articlelist"]);
									foreach ($_var_9["articlelist"] as $_var_12) {
										$_var_12["sha1"] = sha1($_var_12["url"]);
										if (!in_array($_var_12["sha1"], $_var_10)) {
											$_var_14 = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->fetch_by_search(DB::field("sha1", $_var_12["sha1"]) . " OR " . DB::field("group_id", $_var_12["group_id"]), array("id" => "DESC"));
											if (empty($_var_14["id"])) {
												$_var_15 = array("spiderid" => $_var_7["id"], "url" => $_var_12["url"], "sha1" => $_var_12["sha1"], "subject" => $_var_12["subject"], "message" => $_var_12["message"], "group_id" => $_var_12["group_id"], "creattime" => $_G["timestamp"], "updatetime" => $_G["timestamp"]);
												C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->insert($_var_15);
												$_var_13 = $_var_13 + 1;
											}
										}
									}
									$_var_16 = array("updatetime" => $_G["timestamp"]);
									if ($_var_13 > 0) {
										$_var_16["count"] = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->count_by_where(array("spiderid" => $_var_7["id"]));
									}
									if ($_var_9["page"] && $_var_9["page"] != $_var_7["page"]) {
										$_var_16["page"] = $_var_9["page"];
									}
									C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update_by_where(array("id" => $_var_7["id"]), $_var_16, true);
								}
								discuz_process::unlock($_var_8);
							}
						}
					}
				}
				if (in_array($_var_1["auto_post_radio"], array("1", "3"))) {
					if (addon_collect_tieba_fcjtimecheck()) {
						$_var_2 = $_var_2 . "-post";
						if (addon_collect_tieba_rule_dealtime($_var_1["study_post_time"])) {
							$_var_2 = $_var_2 . "-t";
							$_var_11 = array();
							$_var_7 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("status" => "1"), array("posttime" => "ASC"));
							if ($_var_7["id"]) {
								$_var_2 = $_var_2 . "-p";
								C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update_by_where(array("id" => $_var_7["id"]), array("posttime" => $_G["timestamp"]), true);
								$_var_11 = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->fetch_all_by_search(array("spiderid" => $_var_7["id"], "status" => "0"), array("id" => "ASC"), 1);
							}
							if (empty($_var_11)) {
								$_var_2 = $_var_2 . "-x";
								$_var_11 = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->fetch_all_by_search(array("status" => "0"), array("id" => "ASC"), 1);
							}
							if (!empty($_var_11)) {
								$_var_17 = array();
								foreach ($_var_11 as $_var_12) {
									$_var_2 = $_var_2 . ("." . $_var_12["id"]);
									$_var_17[] = $_var_12["id"];
								}
								C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(DB::field("id", $_var_17), array("status" => -1, "errlog" => "&#x53D1;&#x5E03;&#x4E2D;", "updatetime" => $_G["timestamp"]), true);
								$_var_3 = array();
								$_var_6 = new addon_collect_tieba_rule();
								foreach ($_var_11 as $_var_12) {
									$_var_18 = "DZS_AUTOPOST_TIEBA_" . $_var_12["id"];
									if (!discuz_process::islocked($_var_18, 15)) {
										if (!$_var_3[$_var_12["spiderid"]]) {
											$_var_3[$_var_12["spiderid"]] = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("id" => $_var_12["spiderid"]));
											$_var_3[$_var_12["spiderid"]]["configs_arr"] = !empty($_var_3[$_var_12["spiderid"]]["configs"]) ? dunserialize($_var_3[$_var_12["spiderid"]]["configs"]) : array();
											if (!is_array($_var_3[$_var_12["spiderid"]]["configs_arr"])) {
												$_var_3[$_var_12["spiderid"]]["configs_arr"] = array();
											}
										}
										$_var_7 = $_var_3[$_var_12["spiderid"]];
										$_var_12["configs"] = $_var_7["configs_arr"];
										$_var_19 = $_var_6->spider($_var_12);
										if ($_var_19["censor"]) {
											C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(array("id" => $_var_12["id"]), array("status" => -1, "errlog" => "&#x542B;&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;", "updatetime" => $_G["timestamp"]), true);
										} else {
											if (empty($_var_19["subject"])) {
												C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(array("id" => $_var_12["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x540D;&#x79F0;", "updatetime" => $_G["timestamp"]), true);
											} else {
												if (empty($_var_19["message"])) {
													if ($_var_1["optimize_fcj"] && $_var_19["fcj"]) {
														C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(array("id" => $_var_12["id"]), array("status" => 0, "errlog" => "FCJ", "updatetime" => $_G["timestamp"]), true);
														cpmsg_error("&#x60A8;&#x7684;&#x670D;&#x52A1;&#x5668;&#x76EE;&#x524D;&#x65E0;&#x6CD5;&#x6B63;&#x5E38;&#x8BBF;&#x95EE;&#x5934;&#x6761;&#x6587;&#x7AE0;&#x9875;&#xFF0C;&#x8BF7;&#x7A0D;&#x540E;&#x518D;&#x8BD5;");
													} else {
														if ($_var_19["404"]) {
															C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(array("id" => $_var_12["id"]), array("status" => -1, "errlog" => "404", "updatetime" => $_G["timestamp"]), true);
														} else {
															C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->update_by_where(array("id" => $_var_12["id"]), array("status" => -1, "errlog" => "&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;", "updatetime" => $_G["timestamp"]), true);
														}
													}
												} else {
													$_var_9 = array("url" => $_var_19["url"], "subject" => $_var_19["subject"], "message" => $_var_19["message"], "comments" => $_var_19["comments"], "updatetime" => $_G["timestamp"]);
													$_var_20 = addon_collect_tieba_rule_getuser("post", $_var_12);
													$_var_9["articleid"] = $_var_12["id"];
													$_var_9["uid"] = $_var_20["uid"];
													$_var_9["username"] = $_var_20["username"];
													$_var_9["posttype"] = $_var_7["posttype"];
													$_var_9["catid"] = $_var_7["catid"];
													$_var_9["typeid"] = $_var_7["typeid"];
													$_var_9["configs"] = $_var_7["configs_arr"];
													$_var_6->post($_var_9);
												}
											}
										}
										discuz_process::unlock($_var_18);
									}
								}
							}
						}
					} else {
						$_var_2 = $_var_2 . ("-fcj");
					}
				}
			} else {
				$_var_2 = $_var_2 . ("sleep " . $_var_1["autopost_jiange"]);
			}
		}
		echo $_G["adminid"] ? "//ok" : "//&#x672C;&#x9875;&#x9762;&#x7531;&#x3010;&#x767E;&#x5EA6;&#x8D34;&#x5427;&#x81EA;&#x52A8;&#x91C7;&#x96C6;&#x3011;&#x63D2;&#x4EF6;&#x9A71;&#x52A8;, &#x4E0B;&#x8F7D;&#x5730;&#x5740;&#xFF1A;<a href=\"https://dism.Taobao.com/?@addon_collect_tieba.plugin\" target=\"_blank\">https://dism.Taobao.com/?@addon_collect_tieba.plugin</a>";
		if ($_var_1["debug"] || $_GET["debug"]) {
			echo "//<br>" . $_var_2;
		}
		if ($_GET["auto"]) {
			$_var_21 = file_get_contents(DISCUZ_ROOT . "./source/plugin/addon_collect_tieba/demo.php");
			if (preg_match("#statInfo\\['ClientUrl'\\] = '([^']+)';#i", $_var_21, $_var_22)) {
				if ($_var_22[1] == "{ADDONVAR:ClientUrl}") {
					$_var_22[1] = $_G["siteurl"];
				}
				$_var_1["autopost_jiange"] = $_var_1["autopost_jiange"] + 1;
				$_var_23 = max(1, $_G["timestamp"] - $_GET["t"]);
				if ($_var_23 < $_var_1["autopost_jiange"]) {
					$_var_1["autopost_jiange"] = $_var_1["autopost_jiange"] - $_var_23;
				} else {
					$_var_1["autopost_jiange"] = 1;
				}
				$_var_24 = parse_url($_G["siteurl"]);
				echo "&nbsp;&nbsp;" . $_var_24["host"] . "&nbsp;<b id=\"time\">" . $_var_1["autopost_jiange"] . "</b> &#x79D2; &#x8DF3;&#x8F6C;<br>";
				echo "<script language=\"javascript\">\r\n\t\t\t\t\tfunction refresh(){\r\n\t\t\t\t\t\twindow.location.href=\"" . $_var_22[1] . "plugin.php?id=addon_collect_tieba:autopost&auto=1&t=" . $_G["timestamp"] . "\";\r\n\t\t\t\t\t}\r\n\t\t\t\t\tsetInterval(\"refresh()\", " . $_var_1["autopost_jiange"] * 1000 . ");\r\n\t\t\t\t\tvar t = document.getElementById(\"time\");\r\n\t\t\t\t\tfunction settime(obj) {\r\n\t\t\t\t\t    if (obj.innerHTML > 1) {\r\n\t\t\t\t\t        obj.innerHTML = parseInt(obj.innerHTML) - 1;\r\n\t\t\t\t\t\t\t\t\tsetTimeout(function() { settime(obj) }, 1000);\r\n\t\t\t\t\t    }\r\n\t\t\t\t\t}\r\n\t\t\t\t\tsettime(t);\r\n\t\t\t\t\t</script>";
			}
		}
	}