<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_tieba_rule_analyze($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = array();
	$_var_4 = false;
	$_var_5 = $_arg_0["current_page"] > 1 ? 20 * $_arg_0["current_page"] : 0;
	$_arg_0["page"] = max(1, $_arg_0["page"]);
	$_arg_0["articlelist"] = $_var_3 = array();
	if (strpos($_arg_0["url"], "?") !== false && strpos($_arg_0["url"], "kw=") !== false) {
		$_var_4 = true;
		if ($_arg_0["current_page"] > 1) {
			$_var_5 = 50 * ($_arg_0["current_page"] - 1);
			$_var_6 = explode("?", $_arg_0["url"]);
			parse_str($_var_6[1], $_var_7);
			$_arg_0["url"] = "http://tieba.baidu.com/f?kw=" . rawurlencode($_var_7["kw"]) . "&ie=utf-8&pn=" . $_var_5;
		}
	} else {
		$_arg_0["charset"] = "gbk";
		$_arg_0["url"] = "http://tieba.baidu.com/f/search/res?isnew=1&kw=&qw=" . rawurlencode(diconv($_arg_0["url"], CHARSET, $_arg_0["charset"])) . "&rn=20&un=&only_thread=1&sm=1&sd=&ed=&pn=" . $_arg_0["current_page"];
	}
	$_var_8 = addon_collect_tieba_rule_getcontent($_arg_0["url"]);
	if ($_var_4) {
		preg_match_all("/<a rel=\"noreferrer\"\\s*href=\"\\/p\\/([\\d]+)\" title=\"([^\"]+)\" target=\"_blank\" class=\"j_th_tit/is", $_var_8, $_var_9);
	} else {
		preg_match_all("/<a data-tid=\"([^\"]*)\"[^>]*>(.*?)<\\/a>/is", $_var_8, $_var_9);
	}
	foreach ($_var_9[1] as $_var_10 => $_var_11) {
		if (!empty($_var_9[2][$_var_10])) {
			$_var_3["url"] = "https://tieba.baidu.com/p/" . $_var_11;
			$_var_3["group_id"] = $_var_11;
			$_var_3["subject"] = diconv(strip_tags($_var_9[2][$_var_10]), $_arg_0["charset"], CHARSET);
			if ($_G["cache"]["plugin"]["addon_collect_tieba"]["gb2312tobig5_radio"]) {
				$_var_3["subject"] = addon_collect_tieba_rule_gb2312tobig5($_var_3["subject"]);
			}
			$_arg_0["articlelist"][] = $_var_3;
		}
	}
	return $_arg_0;
}
function addon_collect_tieba_rule_comment($_arg_0, $_arg_1, $_arg_2, $_arg_3 = "aid")
{
	global $_G;
	$_arg_1 = intval($_arg_1);
	if (empty($_arg_1)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = addon_collect_tieba_getstr($_arg_2, 0, 0, 0, 1, 0);
	if (strlen($_arg_2) < 2) {
		return "content_is_too_short";
	}
	$_arg_3 = in_array($_arg_3, array("aid", "topicid")) ? $_arg_3 : "aid";
	$_var_5 = $_arg_3 == "aid" ? "portal_article_title" : "portal_topic";
	$_var_6 = C::t($_var_5)->fetch($_arg_1);
	if (empty($_var_6)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = censor($_arg_2);
	if (censormod($_arg_2)) {
		$_var_7 = 1;
	} else {
		$_var_7 = 0;
	}
	$_var_8 = array("uid" => $_arg_0["uid"], "username" => $_arg_0["username"], "id" => $_arg_1, "idtype" => $_arg_3, "postip" => addon_collect_tieba_rule_get_rand_ip(), "dateline" => $_arg_0["comment_time"], "status" => $_var_7, "message" => $_arg_2);
	$_var_9 = C::t("portal_comment")->insert($_var_8, true);
	if ($_var_7 == 1) {
		updatemoderate($_arg_3 . "_cid", $_var_9);
		$_var_10 = $_arg_3 == "aid" ? "verifyacommont" : "verifytopiccommont";
		manage_addnotify($_var_10);
	}
	$_var_5 = $_arg_3 == "aid" ? "portal_article_count" : "portal_topic";
	C::t($_var_5)->increase($_arg_1, array("commentnum" => 1));
	C::t("common_member_status")->update($_G["uid"], array("lastpost" => $_G["timestamp"]), "UNBUFFERED");
	return "do_success";
}
function addon_collect_tieba_rule_wyc($_arg_0)
{
	global $_G;
	if (!isset($_G["toutiao_wyc_keywords"])) {
		$_G["toutiao_wyc_keywords"]["find"] = array();
		$_G["toutiao_wyc_keywords"]["replace"] = array();
		$_var_2 = explode("\n", str_replace("\r\n", "\n", $_G["cache"]["plugin"]["addon_collect_tieba"]["wyc_keywords"]));
		if (is_array($_var_2) && !empty($_var_2)) {
			foreach ($_var_2 as $_var_3) {
				$_var_4 = explode("==", $_var_3);
				if ($_var_4[0] && $_var_4[1]) {
					$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
					$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
				}
			}
		}
		if (is_file(DISCUZ_ROOT . "./source/plugin/addon_collect_tieba/images/keywords.tmp")) {
			$_var_5 = @file(DISCUZ_ROOT . "./source/plugin/addon_collect_tieba/images/keywords.tmp");
			if (is_array($_var_5) && !empty($_var_5)) {
				foreach ($_var_5 as $_var_3) {
					$_var_4 = explode("==", trim($_var_3));
					if ($_var_4[0] && $_var_4[1] && !in_array($_var_4[0], $_G["toutiao_wyc_keywords"]["find"])) {
						$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
						$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
					}
				}
			}
		}
	}
	if (isset($_G["toutiao_wyc_keywords"]["find"]) && is_array($_G["toutiao_wyc_keywords"]["find"])) {
		$_arg_0 = str_replace($_G["toutiao_wyc_keywords"]["find"], $_G["toutiao_wyc_keywords"]["replace"], $_arg_0);
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}