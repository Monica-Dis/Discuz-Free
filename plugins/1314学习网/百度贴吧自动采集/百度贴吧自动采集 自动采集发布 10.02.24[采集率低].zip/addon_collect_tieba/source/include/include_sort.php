<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	echo "<tr><td></td><td colspan=\"13\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">&#x6DFB;&#x52A0;&#x722C;&#x866B;</a></div></td></tr>";
	echo "\r\n<style>\r\n.spiderform .catid{\r\nmargin-right: 10px;\r\nwidth: 128px;\r\n}\r\n.td28{width:100px;}\r\n</style>\r\n\r\n<script type=\"text/JavaScript\">\r\n\r\nvar rowtypedata = new Array();\r\nrowtypedata[0] = [\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, '<input type=\"text\" class=\"txt\" name=\"neworder[]\" style=\"height: 20px;\"/>', \"td25\"],\r\n\t\t\t[1, '<input type=\"text\" class=\"txt\" name=\"newname[]\" style=\"width: 120px;height: 20px;\"/>', \"td28\"],\r\n\t\t\t[1, '<input type=\"text\" name=\"newurl[]\" value=\"\" class=\"txt\" style=\"width: 150px;height: 20px;\">'],\r\n\t\t\t[1, '" . addon_collect_tieba_posttypeselect($posttypelist, 0, 0, 1) . "'],\r\n\t\t\t[1, '" . addon_collect_tieba_catidselect($portalcategory, 0, 0, 1) . "'],\r\n\t\t\t[1, '<input type=\"text\" class=\"txt\" name=\"newpage[]\" value=\"1\" style=\"height: 20px;\"/>', \"\"],\r\n\t\t\t[1, '<div><a href=\"javascript:;\" class=\"deleterow\" onClick=\"deleterow(this)\">" . cplang("delete") . "</a></div>'],\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, \"\"],\r\n\t\t];\r\nsortsupcat = new Array();";
	echo "sortsupcat[1] = new Array(1314);";
	$_var_13 = 1;
	echo "sortsupcat[2] = new Array();";
	echo "sortsupcat[2][0] = new Array(\"" . $splugin_lang["slang_001"] . "\", \"0\");";
	foreach ($portalcategory as $_var_14 => $_var_15) {
		echo "sortsupcat[2][" . $_var_13 . "] = new Array(\"" . $_var_15["catname"] . "\", \"" . $_var_15["catid"] . "\");";
		$_var_13 = $_var_13 + 1;
	}
	echo "sortsupcat[3] = new Array(1314);";
	echo "addFormEvent('sale_form', 0);\r\nfunction onSortGroupChange(sortgroup, formid){\r\n\tvar locationid = sortgroup.value;\r\n\tvar suplist = sortsupcat[locationid];\r\n\t\r\n\tif(suplist){\r\n\t\t\$('sortsup_' + formid).style.display = \"\";\r\n\t\tif(locationid == 1){\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).outerHTML = '<select class=\"catid\" name=\"'+\$('sortsup_' + formid).getAttribute(\"name\")+'\" id=\"sortsup_'+formid+'\"><option value=\"\">" . $splugin_lang["slang_002"] . "</option>" . str_replace("'", '', forumselect(false, 0, 0, true)) . "</select>';\r\n\t\t}else if(locationid == 2){\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).length = suplist.length; \r\n\t\t\tvar i = 0;\r\n\t\t\tfor (supid in suplist){\r\n\t\t\t\t\$('sortsup_' + formid).options[i] = new Option(suplist[supid][0], suplist[supid][1]);\r\n\t\t\t\ti++;\r\n\t\t\t}\r\n\t\t}else{\r\n\t\t\t\$('sortsup_' + formid).innerHTML = '';\r\n\t\t\t\$('sortsup_' + formid).outerHTML = '<select class=\"catid\" name=\"'+\$('sortsup_' + formid).getAttribute(\"name\")+'\" id=\"sortsup_'+formid+'\"><option value=\"\">" . $splugin_lang["slang_017"] . "</option>" . str_replace("'", '', addon_collect_tieba_groupselect(0)) . "</select>';\r\n\t\t}\r\n\t}else{\r\n\t\t\$('sortsup_' + formid).style.display = \"none\";\r\n\t\t\$('sortsup_' + formid).value = \"\";\r\n\t}\r\n}\r\n</script>";