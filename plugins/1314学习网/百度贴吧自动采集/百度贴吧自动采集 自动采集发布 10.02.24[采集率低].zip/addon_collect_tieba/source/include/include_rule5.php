<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_tieba_rule_getcontent($_arg_0)
{
	global $_G;
	$_var_2 = curl_init();
	$_var_3 = '';
	if (strpos($_arg_0, "tieba.baidu.com") !== false) {
		$_var_3 = DISCUZ_ROOT . "./source/plugin/addon_collect_tieba/images/w.tmp";
	} else {
		if (strpos($_arg_0, "m.toutiao.com") !== false) {
			$_var_3 = DISCUZ_ROOT . "./source/plugin/addon_collect_tieba/images/m.tmp";
		}
	}
	$_var_4 = addon_collect_tieba_rule_get_rand_ip();
	$_var_5 = 10;
	curl_setopt($_var_2, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_2, CURLOPT_TIMEOUT, 30);
	curl_setopt($_var_2, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_var_4 . '', "CLIENT-IP:" . $_var_4 . ''));
	curl_setopt($_var_2, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)");
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_HEADER, 0);
	curl_setopt($_var_2, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($_var_2, CURLOPT_SSL_VERIFYHOST, false);
	if ($_var_3 && file_exists($_var_3)) {
		curl_setopt($_var_2, CURLOPT_COOKIEJAR, $_var_3);
		curl_setopt($_var_2, CURLOPT_COOKIEFILE, $_var_3);
	}
	curl_setopt($_var_2, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($_var_2, CURLOPT_AUTOREFERER, 1);
	curl_setopt($_var_2, CURLOPT_MAXREDIRS, 3);
	curl_setopt($_var_2, CURLOPT_CONNECTTIMEOUT, $_var_5);
	$_var_6 = curl_exec($_var_2);
	curl_close($_var_2);
		savecache("addon_collect_tieba_fcjtime", $_G["timestamp"]);
}
function addon_collect_tieba_rule_getuser($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	$_arg_0 = $_arg_0 ? $_arg_0 : "post";
	if (isset($_arg_1["configs"]["study_" . $_arg_0 . "_uids"]) && !empty($_arg_1["configs"]["study_" . $_arg_0 . "_uids"])) {
		$_var_4 = str_replace("-", ",", $_arg_1["configs"]["study_" . $_arg_0 . "_uids"]);
	} else {
		$_var_4 = str_replace("-", ",", $_G["cache"]["plugin"]["addon_collect_tieba"]["study_" . $_arg_0 . "_uids"]);
	}
	$_var_5 = explode(",", $_var_4);
	if (count($_var_5) == 2) {
		$_var_6 = intval($_var_5[0]) > 0 ? intval($_var_5[0]) : 1;
		$_var_7 = intval($_var_5[1]) > $_var_6 ? intval($_var_5[1]) : $_var_6;
		$_var_8 = rand($_var_6, $_var_7);
	} else {
		$_var_9 = rand(0, count($_var_5) - 1);
		$_var_8 = max(intval($_var_5[$_var_9]), 1);
	}
	$_var_3 = getuserbyuid($_var_8, 1);
	if (empty($_var_3)) {
		$_var_3 = getuserbyuid(1);
	}
	return $_var_3;
}
function addon_collect_tieba_rule_dealtime($_arg_0)
{
	global $_G;
	$_var_2 = false;
	$_var_3 = dgmdate($_G["timestamp"], "H", $_G["setting"]["timeoffset"]);
	$_var_4 = explode("-", $_arg_0);
	$_var_4[0] = intval(trim($_var_4[0]));
	if ($_var_4[0] < 0 || $_var_4[0] >= 24) {
		$_var_4[0] = 0;
	}
	$_var_4[1] = intval(trim($_var_4[1]));
	if ($_var_4[1] <= 0 || $_var_4[1] > 24) {
		$_var_4[1] = 24;
	}
	if ($_var_3 >= $_var_4[0] && $_var_3 <= $_var_4[1]) {
		$_var_2 = true;
	}
	return $_var_2;
}
function addon_collect_tieba_fcjtimecheck()
{
	global $_G;
	$_var_1 = true;
	if (!isset($_G["cache"]["addon_collect_tieba_fcjtime"])) {
		loadcache(array("addon_collect_tieba_fcjtime"));
	}
	if ($_G["cache"]["plugin"]["addon_collect_tieba"]["optimize_fcj"] && abs($_G["timestamp"] - $_G["cache"]["addon_collect_tieba_fcjtime"]) < 300) {
		$_var_1 = false;
	}
	return $_var_1;
}
function addon_collect_tieba_rule_html2bbcode($_arg_0)
{
	global $_G;
	$_var_2 = array("/<li>(.*)((?=<li>)|<\\/li>)/iU");
	$_var_3 = array("\\1\n");
	$_arg_0 = preg_replace($_var_2, $_var_3, $_arg_0);
	$_arg_0 = str_replace(array("</h1><br>", "<th", "</th>"), array("</h1>", "<td", "</td>"), $_arg_0);
	$_arg_0 = html2bbcode($_arg_0);
	$_arg_0 = str_replace("[img]" . $_G["siteurl"] . "[/img]", '', $_arg_0);
	$_arg_0 = htmlspecialchars_decode($_arg_0, ENT_QUOTES);
	$_arg_0 = diconv($_arg_0, CHARSET, "UTF-8");
	$_arg_0 = html_entity_decode($_arg_0, ENT_QUOTES, "UTF-8");
	$_arg_0 = diconv($_arg_0, "UTF-8", CHARSET);
	$_arg_0 = str_replace("]" . $_G["siteurl"], "]", $_arg_0);
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}