<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_tieba_rule_post2thread($_arg_0)
{
	global $_G;
	global $forumfield;
	$_arg_0["subject"] = isset($_arg_0["subject"]) ? dhtmlspecialchars(trim($_arg_0["subject"])) : '';
	$_arg_0["subject"] = str_replace("\t", " ", $_arg_0["subject"]);
	if (strlen($_arg_0["subject"]) < 1) {
		return array("status" => -1, "error" => lang("plugin/addon_collect_tieba", "slang_007"));
	}
	if (empty($_arg_0["catid"])) {
		return array("status" => -1, "error" => lang("plugin/addon_collect_tieba", "slang_008"));
	}
	$_var_3 = $_arg_0["catid"];
	$_var_4 = explode("-", $_G["cache"]["plugin"]["addon_collect_tieba"]["rand_posttime"]);
	$_var_4[0] = max(intval($_var_4[0]), 0);
	$_var_4[1] = max(intval($_var_4[1]), 0);
	if (!empty($_var_4[1])) {
		$_var_5 = TIMESTAMP - rand($_var_4[0], $_var_4[1]);
	} else {
		$_var_5 = TIMESTAMP;
	}
	$_var_6 = array("fid" => $_var_3, "posttableid" => 0, "readperm" => 0, "price" => 0, "typeid" => $_arg_0["posttype"] == 1 ? $_arg_0["typeid"] : 0, "sortid" => 0, "author" => $_arg_0["username"], "authorid" => $_arg_0["uid"], "subject" => $_arg_0["subject"], "dateline" => $_var_5, "lastpost" => $_var_5, "lastposter" => $_arg_0["username"], "views" => $_arg_0["views"], "displayorder" => 0, "digest" => 0, "special" => 0, "attachment" => 0, "moderated" => 0, "status" => 32, "isgroup" => $_arg_0["posttype"] == 3 ? 1 : 0, "replycredit" => 0, "closed" => 0);
	$_var_7 = C::t("forum_thread")->insert($_var_6, true);
	useractionlog($_arg_0["uid"], "tid");
	if ($_var_7) {
		$_var_8 = '';
		$_var_8 = addon_collect_tieba_rule_html2bbcode($_arg_0["message"]);
		$_var_9 = insertpost(array("fid" => $_var_3, "tid" => $_var_7, "first" => "1", "author" => $_arg_0["username"], "authorid" => $_arg_0["uid"], "subject" => $_arg_0["subject"], "dateline" => $_var_5, "message" => $_var_8, "useip" => addon_collect_tieba_rule_get_rand_ip(), "invisible" => 0, "anonymous" => 0, "usesig" => 1, "htmlon" => 0, "bbcodeoff" => 0, "smileyoff" => -1, "parseurloff" => 1, "attachment" => 0, "tags" => '', "replycredit" => 0, "status" => 0));
		if ($_var_9) {
			$_var_10 = str_replace("\t", " ", $_arg_0["subject"]);
			$_var_11 = '' . $_var_7 . "\t" . $_var_10 . "\t" . $_var_5 . "\t" . $_arg_0["username"] . '';
			C::t("forum_forum")->update($_var_3, array("lastpost" => $_var_11));
			C::t("forum_forum")->update_forum_counter($_var_3, 1, 1, 1);
			updatepostcredits("+", $_arg_0["uid"], "post", $_var_3);
			if ($_var_6["isgroup"]) {
				C::t("forum_groupuser")->update_counter_for_user($_arg_0["uid"], $_var_3, 1);
			}
			if ($_G["cache"]["plugin"]["addon_collect_tieba"]["downremoteimg_radio"]) {
				if (isset($_arg_0["configs"]["censor_picmd5"]) && !empty($_arg_0["configs"]["censor_picmd5"])) {
					$_arg_0["configs"]["censor_picmd5"] = strtolower($_arg_0["configs"]["censor_picmd5"]);
					$_var_12 = "/(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_arg_0["configs"]["censor_picmd5"] = trim($_arg_0["configs"]["censor_picmd5"]), "/")) . ")/i";
				} else {
					$_var_12 = '';
				}
				addon_collect_tieba_downremoteimg(array("message" => $_var_8, "subject" => $_var_10, "tid" => $_var_7, "pid" => $_var_9, "fid" => $_var_3, "uid" => $_arg_0["uid"], "censor_picmd5exp" => $_var_12));
			}
			if ($_G["cache"]["plugin"]["addon_collect_tieba"]["study_reply_radio"]) {
				if (is_array($_arg_0["comments"]) && !empty($_arg_0["comments"])) {
					$_var_13 = $_var_14 = 0;
					$_var_15 = array();
					$_var_16 = explode("-", $_G["cache"]["plugin"]["addon_collect_tieba"]["rand_replytime"]);
					$_var_16[0] = max(intval($_var_16[0]), 0);
					$_var_16[1] = max(intval($_var_16[1]), 0);
					foreach ($_arg_0["comments"] as $_var_17) {
						$_var_17 = addon_collect_tieba_rule_html2bbcode($_var_17);
						if (!empty($_var_17)) {
							$_var_15 = addon_collect_tieba_rule_getuser("reply", $_arg_0);
							if (!empty($_var_16[1])) {
								$_var_5 = $_var_5 + rand($_var_16[0], $_var_16[1]);
							} else {
								$_var_5 = $_var_5 + rand(1, 20);
							}
							$_var_18 = insertpost(array("fid" => $_var_3, "tid" => $_var_7, "first" => 0, "author" => $_var_15["username"], "authorid" => $_var_15["uid"], "subject" => '', "dateline" => $_var_5, "message" => $_var_17, "useip" => addon_collect_tieba_rule_get_rand_ip(), "invisible" => 0, "anonymous" => 0, "usesig" => 0, "htmlon" => 0, "bbcodeoff" => 0, "smileyoff" => -1, "parseurloff" => 1, "attachment" => 0, "tags" => '', "replycredit" => 0, "status" => 0));
							if ($_var_18) {
								$_var_14 = $_var_14 + 1;
								addon_collect_tieba_downremoteimg(array("message" => $_var_17, "subject" => $_arg_0["subject"], "tid" => $_var_7, "pid" => $_var_18, "fid" => $_var_3, "uid" => $_var_15["uid"]));
							}
							DB::query("UPDATE " . DB::table("common_member_count") . " SET posts=posts+1 WHERE uid='" . $_var_15["uid"] . "'");
							DB::query("UPDATE " . DB::table("common_member_status") . " SET lastvisit='" . $_var_5 . "',lastactivity='" . $_var_5 . "',lastpost='" . $_var_5 . "' WHERE uid='" . $_var_15["uid"] . "'");
						}
					}
					if ($_var_14) {
						$_var_5 = $_var_5 > TIMESTAMP ? TIMESTAMP : $_var_5;
						$_var_11 = '' . $_var_7 . "\t" . addslashes($_arg_0["subject"]) . "\t" . $_var_5 . "\t" . addslashes($_var_15["username"]);
						DB::query("UPDATE " . DB::table("forum_forum") . " SET posts=posts+" . $_var_14 . ",todayposts=todayposts+" . $_var_14 . ",lastpost='" . $_var_11 . "' WHERE fid='" . $_var_3 . "'");
						DB::query("UPDATE " . DB::table("forum_thread") . " SET replies=replies+" . $_var_14 . ",views=views+" . $_var_14 . ",lastposter='" . addslashes($_var_15["username"]) . "', lastpost='" . $_var_5 . "' WHERE tid='" . $_var_7 . "'");
						$_var_13 = C::t("forum_post")->fetch_maxposition_by_tid(0, $_var_7);
						if ($_var_13) {
							$_var_19 = array();
							$_var_19[] = DB::field("maxposition", $_var_13);
							if (!empty($_var_19)) {
								C::t("forum_thread")->update($_var_7, $_var_19, false, false, 0, true);
							}
						}
					}
				}
			}
		} else {
			return array("status" => -1, "error" => lang("plugin/addon_collect_tieba", "slang_009"));
		}
	} else {
		return array("status" => -1, "error" => lang("plugin/addon_collect_tieba", "slang_009"));
	}
	return array("status" => 1, "postid" => $_var_7);
}
function addon_collect_tieba_rule_dealurl($_arg_0)
{
	global $_G;
	$_var_2 = '';
	if ($_arg_0["posttype"] == 2) {
		$_var_2 = $_G["cache"]["plugin"]["addon_collect_tieba"]["linksubmit_portal_article"] ? $_G["cache"]["plugin"]["addon_collect_tieba"]["linksubmit_portal_article"] : "portal.php?mod=view&aid={tid}";
		$_var_3 = array("{id}" => $_arg_0["postid"], "{catid}" => $_arg_0["catid"], "{page}" => 1);
	} else {
		$_var_2 = $_G["cache"]["plugin"]["addon_collect_tieba"]["linksubmit_forum_viewthread"] ? $_G["cache"]["plugin"]["addon_collect_tieba"]["linksubmit_forum_viewthread"] : "forum.php?mod=viewthread&tid={tid}";
		$_var_3 = array("{tid}" => $_arg_0["postid"], "{fid}" => empty($_G["setting"]["forumkeys"][$_arg_0["catid"]]) ? $_arg_0["catid"] : $_G["setting"]["forumkeys"][$_arg_0["catid"]], "{page}" => 1, "{prevpage}" => 1);
	}
	return $_G["siteurl"] . str_replace(array_keys($_var_3), $_var_3, $_var_2);
}
function addon_collect_tieba_rule_get_rand_ip()
{
	$_var_0 = array("110.96", "111.128", "101.144", "114.240", "117.112", "124.200", "101.196", "101.120", "111.208", "110.40", "222.28", "211.160", "121.68", "42.196", "202.204", "1.88", "58.116", "175.188", "218.246", "117.106", "121.194", "124.64", "118.228", "210.82", "119.254", "101.200", "42.158", "180.78", "58.30", "110.94", "123.60", "121.89", "119.57", "202.112", "36.254", "180.76", "116.69", "106.50", "113.209", "180.77", "117.75", "123.64", "175.64", "42.208", "175.48", "221.216", "101.236", "101.244", "101.104", "112.124");
	$_var_1 = mt_rand(0, count($_var_0) - 1);
	$_var_2 = $_var_0[$_var_1];
	$_var_3 = round(mt_rand(600000, 2540000) / 10000);
	$_var_4 = round(mt_rand(600000, 2540000) / 10000);
	return $_var_2 . "." . $_var_3 . "." . $_var_4;
}
function addon_collect_tieba_rule_gb2312tobig5($_arg_0)
{
	$_arg_0 = diconv($_arg_0, CHARSET, "utf-8");
	$_arg_0 = diconv($_arg_0, "utf-8", "big5", true);
	$_arg_0 = diconv($_arg_0, "big5", CHARSET);
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}