<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_tieba_rule_summary($_arg_0)
{
	$_arg_0 = preg_replace(array("/\\[attach\\].*?\\[\\/attach\\]/", "/\\&[a-z]+\\;/i", "/\\<script.*?\\<\\/script\\>/"), '', $_arg_0);
	$_arg_0 = preg_replace("/\\[.*?\\]/", '', $_arg_0);
	$_arg_0 = addon_collect_tieba_getstr(strip_tags($_arg_0), 200);
	return $_arg_0;
}
function addon_collect_tieba_rule_spider($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = $_var_4 = array();
	$_var_5 = $_arg_0["url"];
	$_var_6 = addon_collect_tieba_rule_getcontent($_var_5);
	if (empty($_var_6)) {
		$_var_6 = addon_collect_tieba_rule_getcontent($_var_5);
	}
	$_arg_0["fcj"] = false;
	if ($_arg_0["debug"]) {
		$_arg_0["debug_content"] = $_var_6;
	}
	$_var_7 = $_var_6;
	$_var_6 = diconv($_var_6, $_arg_0["charset"], CHARSET);
	$_var_6 = preg_replace("/<div class=\"video_src_wrapper\">(.*?)<\\/div>/is", '', $_var_6);
	$_var_6 = preg_replace("/<div class=\"post_bubble_[^>]*>(.*?)<\\/div>/is", "\\1", $_var_6);
	$_var_6 = preg_replace("/<div class=\"post_bubble_[^>]*>(.*?)<\\/div>/is", "\\1", $_var_6);
	$_var_6 = preg_replace("/<div class=\"voice_player voice_player_pb clearfix\">(.*?)<\\/div>/is", '', $_var_6);
	$_var_6 = preg_replace("/<img class=\"j_voice_ad_gif\"[^>]*>/is", '', $_var_6);
	$_var_6 = str_replace("&#x3D;", "=", $_var_6);
	if ($_arg_0["debug"]) {
		$_arg_0["debug_content_charset"] = $_var_6;
	}
	if (empty($_arg_0["subject"])) {
		preg_match("/<h3[^>]*>(.*?)<\\/h3>/is", $_var_6, $_var_4);
		if (!isset($_var_4[1])) {
			preg_match("/<h1[^>]*>(.*?)<\\/h1>/is", $_var_6, $_var_4);
			if (!isset($_var_4[1])) {
				preg_match("/title: '(.*?)'/is", $_var_6, $_var_4);
				if (!isset($_var_4[1])) {
					preg_match("/title: \"(.*?)\"/is", $_var_6, $_var_4);
					if (!isset($_var_4[1])) {
						preg_match("/<title>(.*?)<\\/title>/is", $_var_6, $_var_4);
					}
				}
			}
		}
		$_arg_0["subject"] = $_var_4[1];
	}
	preg_match("/<div id=\"post_content_[\\d]+\"[^>]+>(.*?)<\\/div>/is", $_var_6, $_var_4);
	if (isset($_var_4[1])) {
		$_var_4[1] = preg_replace("/>[\\s]+</iUs", "><", $_var_4[1]);
		$_var_4[1] = preg_replace(array("/\\<link.*?\\>/", "/\\<script.*?\\<\\/script\\>/", "/\\<style.*?\\<\\/style\\>/is"), '', $_var_4[1]);
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["img_aligncenter_radio"]) {
			$_var_4[1] = str_replace("class=\"pgc-img-caption\"", "style=\"text-align:center;\"", $_var_4[1]);
			$_var_4[1] = str_replace("<p><img ", "<p style=\"text-align:center;\"><img ", $_var_4[1]);
			$_var_4[1] = preg_replace("/<br><img ([^>]*)>/is", "<br><p style=\"text-align:center;\"><img \\1></p>", $_var_4[1]);
		} else {
			$_var_4[1] = preg_replace("/<p class=\"pgc-img-caption\">(.*?)<\\/p>/is", "<br>\\1", $_var_4[1]);
			$_var_4[1] = preg_replace("/<img ([^>]*)>/is", "<br><img \\1>", $_var_4[1]);
		}
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["study_filter_mao"]) {
			$_var_4[1] = preg_replace("/<a [^>]*>(.*?)<\\/a>/is", "\\1", $_var_4[1]);
		}
		$_arg_0["message"] = trim($_var_4[1]);
	}
	$_arg_0["author"] = lang("plugin/addon_collect_tieba", "slang_018");
	preg_match("/mediaInfo: {(.*?)},/is", $_var_6, $_var_4);
	if ($_var_8[1]) {
		preg_match("/name: '([^']*)',/is", $_var_4[1], $_var_8);
		if ($_var_8[1]) {
			$_arg_0["author"] = $_var_8[1];
		}
	}
	$_arg_0["comments"] = array();
	if (!empty($_arg_0["message"])) {
		if (isset($_arg_0["configs"]["censor"]) && !empty($_arg_0["configs"]["censor"])) {
			$_var_9 = "/(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_arg_0["configs"]["censor"] = trim($_arg_0["configs"]["censor"]), "/")) . ")/i";
			if ($_arg_0["configs"]["censor"] && @preg_match($_var_9, strip_tags($_arg_0["subject"] . $_arg_0["message"]))) {
				$_arg_0["censor"] = true;
				return $_arg_0;
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["gb2312tobig5_radio"]) {
			if ($_arg_0["debug"]) {
				$_arg_0["debug_message_big5"] = $_arg_0["message"];
			}
			$_arg_0["message"] = addon_collect_tieba_rule_gb2312tobig5($_arg_0["message"]);
		}
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["wyc_radio"]) {
			$_arg_0["subject"] = addon_collect_tieba_rule_wyc($_arg_0["subject"]);
			$_arg_0["message"] = addon_collect_tieba_rule_wyc($_arg_0["message"]);
			if ($_arg_0["debug"]) {
				$_arg_0["debug_message_wyc"] = $_arg_0["message"];
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["from_radio"]) {
			$_arg_0["message"] = $_arg_0["message"] . ($_G["cache"]["plugin"]["addon_collect_tieba"]["from_format"] ? "<br>" . str_replace(array("{url}", "{author}"), array($_var_5, $_arg_0["author"]), $_G["cache"]["plugin"]["addon_collect_tieba"]["from_format"]) : '');
		}
		$_arg_0["message"] = str_replace("src=\"//", "src=\"http://", $_arg_0["message"]);
		if ($_G["cache"]["plugin"]["addon_collect_tieba"]["study_reply_radio"]) {
			preg_match_all("/<div id=\"post_content_[\\d]+\"[^>]+>(.*?)<\\/div>/is", $_var_6, $_var_10);
			if (is_array($_var_10[1]) && !empty($_var_10[1])) {
				foreach ($_var_10[1] as $_var_11 => $_var_12) {
					if ($_var_11 > 0) {
						$_var_12 = trim($_var_12);
						if (!empty($_var_12)) {
							if ($_G["cache"]["plugin"]["addon_collect_tieba"]["img_aligncenter_radio"]) {
								$_var_12 = str_replace("class=\"pgc-img-caption\"", "style=\"text-align:center;\"", $_var_12);
								$_var_12 = str_replace("<p><img ", "<p style=\"text-align:center;\"><img ", $_var_12);
								$_var_12 = preg_replace("/<br><img ([^>]*)>/is", "<br><p style=\"text-align:center;\"><img \\1></p>", $_var_12);
							} else {
								$_var_12 = preg_replace("/<p class=\"pgc-img-caption\">(.*?)<\\/p>/is", "<br>\\1", $_var_12);
								$_var_12 = preg_replace("/<img ([^>]*)>/is", "<br><img \\1>", $_var_12);
							}
							if ($_G["cache"]["plugin"]["addon_collect_tieba"]["study_filter_mao"]) {
								$_var_12 = preg_replace("/<a [^>]*>(.*?)<\\/a>/is", "\\1", $_var_12);
							}
							if ($_G["cache"]["plugin"]["addon_collect_tieba"]["gb2312tobig5_radio"]) {
								$_var_12 = addon_collect_tieba_rule_gb2312tobig5($_var_12);
							}
							if ($_G["cache"]["plugin"]["addon_collect_tieba"]["wyc_radio"]) {
								$_var_12 = addon_collect_tieba_rule_wyc($_var_12);
							}
							$_var_12 = str_replace("src=\"//", "src=\"http://", $_var_12);
							$_arg_0["comments"][] = $_var_12;
						}
					}
				}
			}
		}
	}
	$_arg_0["404"] = false;
	preg_match("/page404/is", $_var_6, $_var_13);
	if (!empty($_var_13)) {
		$_arg_0["404"] = true;
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	global $forumfield;
	$forumfield = array();
	if ($_G["cache"]["plugin"]["addon_collect_tieba"]["ftp_remote_radio"]) {
		if (in_array("addon_storage_aliyunoss", $_G["setting"]["plugins"]["available"])) {
			include_once DISCUZ_ROOT . "source/plugin/addon_storage_aliyunoss/source/OSS/AutoLoad.php";
		} else {
			if (in_array("addon_storage_qiniuoss", $_G["setting"]["plugins"]["available"])) {
				include_once DISCUZ_ROOT . "source/plugin/addon_storage_qiniuoss/source/Qiniu/AutoLoad.php";
			}
		}
	}
	require_once libfile("include/rule3", "plugin/addon_collect_tieba/source");
	require_once libfile("include/rule4", "plugin/addon_collect_tieba/source");
	require_once libfile("include/rule5", "plugin/addon_collect_tieba/source");
	require_once libfile("include/rule2", "plugin/addon_collect_tieba/source");