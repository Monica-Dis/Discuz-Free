<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=2
 * ���ο������ƣ�http://www.di'.'szz.net/ser'.'vices.php?mod=ask&sid=22
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('');
}

require_once libfile('class/rule', 'plugin/addon_collect_tieba/source');

$op = in_array($_GET['op'], array('all', 'wait', 'succeed', 'fail', 'edit', 'post')) ? $_GET['op'] : 'all';
if (in_array($op, array('all', 'wait', 'succeed', 'fail'))) {
    if ($_GET['formhash'] != $_G['formhash'] || $_GET['search']) {
		    showtips('
		    <li>&#x5BF9;&#x4E8E;&#x53D1;&#x5E03;&#x6210;&#x529F;&#x7684;&#x6587;&#x7AE0;&#xFF0C;&#x70B9;&#x51FB;&#x72B6;&#x6001;&#x91CC;&#x7684;&#x201C;&#x6210;&#x529F;&#x201D;&#x5C31;&#x53EF;&#x4EE5;&#x6253;&#x5F00;&#x6240;&#x5BF9;&#x5E94;&#x7684;&#x6587;&#x7AE0;</li>
		    <li>&#x6587;&#x7AE0;&#x6807;&#x9898;&#x3001;&#x6587;&#x7AE0;&#x5185;&#x5BB9;&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#xFF0C;&#x6587;&#x7AE0;&#x5C31;&#x4E0D;&#x4F1A;&#x88AB;&#x53D1;&#x5E03;</li>
		    <li>&#x6587;&#x7AE0;&#x5185;&#x5BB9;&#x4E00;&#x822C;&#x5728;&#x53D1;&#x5E03;&#x6587;&#x7AE0;&#x65F6;&#x624D;&#x4F1A;&#x91C7;&#x96C6;&#xFF0C;&#x6587;&#x7AE0;&#x56FE;&#x7247;&#x5728;&#x53D1;&#x5E03;&#x65F6;&#x624D;&#x4F1A;&#x672C;&#x5730;&#x5316;&#xFF08;&#x5546;&#x4E1A;&#x7248;&#xFF09;</li>
		    ');
				addon_collect_tieba_admin::subtitle(array(array('&#x5168;&#x90E8;', 'all'), array('&#x5F85;&#x53D1;&#x5E03;', 'wait'), array('&#x53D1;&#x5E03;&#x6210;&#x529F;', 'succeed'), array('&#x53D1;&#x5E03;&#x5931;&#x8D25;', 'fail')), $type1314, $op);
				s_shownav('sort', 'sorts_admin');
				
				
				$spiderlist = array();
				$result = C::t('#addon_collect_tieba#addon_collect_tieba_spider')->fetch_all_by_search(array());
				foreach($result as $value){
					$spiderlist[$value['id']] = strip_tags($value['name']);
				}
				
				$spiderlist = dhtmlspecialchars($spiderlist);
				
				if($_GET['formhash'] != $_G['formhash']){
					$_GET['f_kw'] = '';
				}
				showformheader(STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac);
				echo '&#x722C;&#x866B;&#x7B5B;&#x9009;&nbsp;&nbsp;
		    <select name="spiderid" onchange="window.location=\''.ADMINSCRIPT.'?action='.STUDY_MANAGE_URL. '&type1314='.$type1314.'&op='.$op.'&ac='.$ac .'&f_kw='.urlencode($_GET['f_kw']).'&formhash='.$_G['formhash'].'&search=ok&spiderid=\' + this.value;"><option value="0" selected="selected">&#x5168;&#x90E8;</option>';
		    echo '<option value="-1" '.($_GET['spiderid'] == '-1' ? 'selected="selected"' : '').'>&#x975E;&#x722C;&#x866B;</option>';
		    foreach($spiderlist as $key => $value){
						echo '<option value="'.$key.'" '.($_GET['spiderid'] == $key ? 'selected="selected"' : '').'>'.$value.'</option>';
				}
		
				echo '</select>
		    &nbsp;&nbsp;<b style="color:red;">|</b>&nbsp;&nbsp;
				&#x6587;&#x7AE0;&#x641C;&#x7D22;&nbsp;&nbsp;<input type="text" name="f_kw" value="'.dhtmlspecialchars($_GET['f_kw']).'" class="px vm" autocomplete="off" placeholder="">&nbsp;&nbsp;
				<button type="submit" class="pn" name="search" id="submit_search" value="true"><span class="xi1 xw1">&#x641C;&#x7D22;</span></button>
		    &nbsp;&nbsp;
		    <script type="text/JavaScript">_attachEvent(document.documentElement, \'keydown\', function (e) { entersubmit(e, \'search\'); });</script>
		    ';
		    
		    showformfooter();
				
				showformheader(STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac.'&spiderid='.intval($_GET['spiderid']));
				showtableheader('');
				
				//$spiderlist = C::t('#addon_collect_tieba#addon_collect_tieba_spider')->fetch_all_by_search(array(), array('displayorder' => 'ASC', 'id' => 'DESC'));
				
				$portalcategory = array();
				loadcache('portalcategory');
				$portalcategory = $_G['cache']['portalcategory'];
				showsubtitle(array('', '&#x722C;&#x866B;&#x540D;&#x79F0;', '&#x6587;&#x7AE0;ID', '&#x6587;&#x7AE0;&#x540D;&#x79F0;', '&#x6700;&#x540E;&#x64CD;&#x4F5C;&#x65F6;&#x95F4;', $op == 'succeed' ? '' : ($op == 'fail' ? '&#x5931;&#x8D25;&#x539F;&#x56E0;' : '&#x72B6;&#x6001;'), '&#x64CD;&#x4F5C;','', ''));
				
				
				$where_array = array();
				if($_GET['spiderid'] == '-1'){
					$where_array['spiderid'] = 0;
				}elseif($_GET['spiderid']){
					$where_array['spiderid'] = intval($_GET['spiderid']);
				}
				
				if($_GET['f_kw']){
					$_GET['f_kw'] = addslashes($_GET['f_kw']);
					$where_array['subject'] = array('%'.addcslashes($_GET['f_kw'], '%_').'%', 'like');
				}
				
				if($op == 'wait'){
					$where_array['status'] = 0;
				}elseif($op == 'succeed'){
					$where_array['status'] = 1;
				}elseif($op == 'fail'){
					$where_array['status'] = -1;
				}
				
				$perpage = 20;
				$maxpages = 1000;
				$count = C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->count_by_where($where_array);
				$page = intval($_GET['page']);
				$page = ($page-1 > $count/$perpage || $page > $maxpages) ? 1 : $page;
				$start_limit = ($page - 1) * $perpage;
				$multipage = multi($count, $perpage, $page, ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac.'&spiderid='.intval($_GET['spiderid']).($_GET['f_kw'] ? '&formhash='.$_G['formhash'].'&search=ok&f_kw='.urlencode($_GET['f_kw']) : ''), $maxpages);
				
				if($op == 'wait'){
//					if($where_array['spiderid']){
//						showsubmit('submit_all', '&#x4E00;&#x952E;&#x53D1;&#x5E03;&#x8BE5;&#x722C;&#x866B;&#x4E0B;&#x7684;&#x6240;&#x6709;&#x6587;&#x7AE0;');
//					}else{
//						showsubmit('submit_all', '&#x4E00;&#x952E;&#x53D1;&#x5E03;&#x6240;&#x6709;&#x6587;&#x7AE0;');
//					}
				}elseif($op == 'fail'){
					showhiddenfields(array('fail' => 'true'));
					showhiddenfields(array('dateline' => $_G['timestamp'] - 1));
					if(empty($where_array['spiderid'])){
						showsubmit('submit_all', '&#x4E00;&#x952E;&#x91CD;&#x65B0;&#x8FDB;&#x5165;&#x5F85;&#x53D1;&#x5E03;');
					}
				}
				
				$order = $op == 'all' ? array('id' => 'DESC') : array('updatetime' => 'DESC');
				
				$articlelist = C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->fetch_all_by_search($where_array, $order, $start_limit, $perpage);
				$articlelist = dhtmlspecialchars($articlelist);
				foreach ($articlelist as $article) {
			    $article['url'] = str_replace('/group/', '/a', $article['url']);
			    $article['url'] = str_replace('/item/', '/i', $article['url']);
			    $article['errlog'] = str_replace('&amp;', '&', $article['errlog']);
					showtablerow('', array('class="td25"', 'class="td28" style="width:100px;"', 'class="td25"', 'class="td28" style="width:500px;"', ' style="width:100px;"', ' style="width:'.($op == 'succeed' ? '120' : ($op == 'fail' ? '120' : '50')).'px;"', ' style="width:50px;"', ' style="width:100px;"', ''), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$article[id]\" $disabled>",
						'<div style="height: 14px;line-height: 14px;overflow: hidden;"><a href="'.ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac.'&spiderid='.$article['spiderid'].'" title="'.$spiderlist[$article['spiderid']].'" class="act">'.$spiderlist[$article['spiderid']].'</a></div>',
						$article['id'],
						'<a href="'.$article['url'].'" target="_blank" class="act">'.$article['subject'].'</a>',
						dgmdate($article['updatetime'], 'Y-m-d H:i:s', $_G['setting']['timeoffset']),
						$article['status'] ? ($article['status'] > 0 ? '<a href="'.($article['posttype'] == 2 ? 'portal.php?mod=view&aid='.$article['postid'] : 'forum.php?mod=viewthread&tid='.$article['postid']).'" target="_blank"><b style="color:green;">'.($op == 'succeed' ? '&#x67E5;&#x770B;&#x6587;&#x7AE0;' : '&#x6210;&#x529F;').'</b></a>' : '<b style="color:green;" title="'.$article['errlog'].'">'.($op == 'fail' ? ($article['postid'] ? '<a href="'.($article['posttype'] == 2 ? 'portal.php?mod=view&aid='.$article['postid'] : 'forum.php?mod=viewthread&tid='.$article['postid']).'" target="_blank"><b style="color:green;">'.$article['errlog'].'</b></a>' : $article['errlog']) : '&#x5931;&#x8D25;').'</b>') : '<b style="color:red;" title="'.$article['errlog'].'">&#x5F85;&#x53D1;&#x5E03;</b>',
						'<a href="'.ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=edit&cid='.$article['id'].'" class="act">'.cplang('edit').'</a>',
						$article['status'] == 0 ? '<a href="'.ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=post&onlyarticleid='.$article['id'].'&formhash='.$_G['formhash'].'" class="act">&#x4E00;&#x952E;&#x53D1;&#x5E03;</a>' : ($article['status'] == -1 ? '<a href="'.ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=post&onlyarticleid='.$article['id'].'&fail=true&formhash='.$_G['formhash'].'" class="act">&#x5C1D;&#x8BD5;&#x91CD;&#x65B0;&#x53D1;&#x5E03;</a>' : ''),
						'',
		        ));
				}
				
				if($op == 'wait'){
					showsubmit('submit', '&#x4E00;&#x952E;&#x53D1;&#x5E03;', 'select_all', '<input type="submit" class="btn" name="del" value="&#x5220;&#x9664;">', $multipage, false);
				}elseif($op == 'fail'){
//					showhiddenfields(array('fail' => 'true'));
//					showsubmit('submit', '&#x5C1D;&#x8BD5;&#x4E00;&#x952E;&#x91CD;&#x65B0;&#x53D1;&#x5E03;', 'select_all', '<input type="submit" class="btn" name="del" value="&#x5220;&#x9664;">', $multipage, false);
					showsubmit('del', 'submit', 'del', '', $multipage, false);
				}else{
					showsubmit('del', 'submit', 'del', '', $multipage, false);
				}
				
				showtablefooter();
				showformfooter();
   	} else {
   			if($_POST['submit_all']){
   				
					if(!empty($_GET['fail'])){
						C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('status' => -1), array('status' => 0, 'updatetime' => $_G['timestamp']), true);
						cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=wait&spiderid='.intval($_GET['spiderid']), 'succeed');
					}
					
					//cpmsg('&#x5F00;&#x59CB;&#x91C7;&#x96C6;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=post&formhash='.$_G['formhash'].'&spiderid='.intval($_GET['spiderid']).'&aids=all'.($_GET['fail'] ? '&fail=true' : '').($_GET['dateline'] ? '&dateline='.$_GET['dateline'] : ''), 'loading');
				}else{
		   		if(is_array($_POST['delete'])) {
		   			if($_POST['del']){
							foreach($_POST['delete'] as $key) {
								$key = intval($key);
								C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->delete_by_where(array('id' => $key), true);
							}
						}else{
							cpmsg('&#x5F00;&#x59CB;&#x91C7;&#x96C6;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=post&formhash='.$_G['formhash'].'&aids='.implode('.', $_POST['delete']).($_GET['fail'] ? '&fail=true' : ''), 'loading');
						}
					}elseif($_POST['submit']){
						cpmsg('&#x8BF7;&#x9009;&#x62E9;&#x8981;&#x53D1;&#x5E03;&#x7684;&#x6587;&#x7AE0;');
					}
				}
				
//			if (is_array($_POST['subject'])) {
//            foreach ($_POST['subject'] as $key => $value) {
//            	$data = array(
//	            	'subject' => $_POST['subject'][$key],
//	            	'cover' => $_POST['cover'][$key],
//	            	'message' => $_POST['message'][$key],
//	            	'flashurl' => $_POST['flashurl'][$key],
//            	);
//                C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update($key, $data);
//            }
//        }

        cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac, 'succeed');
    }
} elseif ($op == 'edit') {
    $cid = intval($_GET['cid']);
    if (!submitcheck('submit')) {
    		$article = C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->fetch_by_search(array('id' => $cid));
        showformheader(STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac.'&cid='.$cid);
        showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
        s_showsetting("&#x6587;&#x7AE0;&#x540D;&#x79F0;", 'subject', $article['subject'], 'text', '', '', '');
        s_showsetting("&#x6587;&#x7AE0;&#x7F51;&#x5740;", 'url', $article['url'], 'text', '', '', '&#x6587;&#x7AE0;&#x7684;&#x539F;&#x7F51;&#x5740;&#xFF0C;&#x8BE5;&#x9879;&#x4E0D;&#x5141;&#x8BB8;&#x4FEE;&#x6539;&#xFF0C;<a href="'.$article['url'].'" target="_blank">&#x70B9;&#x51FB;&#x6253;&#x5F00;</a>');
        s_showsetting('&#x662F;&#x5426;&#x542F;&#x7528;', array('status', array(array('0', '&#x5F85;&#x53D1;&#x5E03;'), array('1', '&#x53D1;&#x5E03;&#x6210;&#x529F;'), array('-1', '&#x53D1;&#x5E03;&#x5931;&#x8D25;'))), $article['status'], 'select', '', '', '');
        showtableheader();
        showsubmit('submit', "submit");
        showformfooter();
    } else {
    	$data = array(
	    	'subject' => $_POST['subject'],
	    	'status' => dintval($_POST['status']),
	    	'updatetime' => $_G['timestamp'],
    	);
        C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update($cid, $data, 1);
        cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=list', 'succeed');
    }
} elseif ($op == 'post' && $_GET['formhash'] == $_G['formhash']) {
		//op=post&ac=&spiderid=0&formhash=8061430e&aids=all&key=2
		if($_GET['aids'] == 'all'){
			
			$where_array = array();
			if($_GET['spiderid']){
				$where_array['spiderid'] = intval($_GET['spiderid']);
			}
			$where_array['status'] = !empty($_GET['fail']) ? -1 : 0;
			
			if($_GET['dateline']){
				$where_array['updatetime'] = array(intval($_GET['dateline']), '<');
			}
			
			$article = C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->fetch_by_search($where_array, array('id' => 'ASC'));
			if (empty($article)) {
				cpmsg('&#x5168;&#x90E8;&#x91C7;&#x96C6;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=wait&spiderid='.intval($_GET['spiderid']), 'succeed');
			}
			
		}else{
			$onlyarticleid = intval($_GET['onlyarticleid']);
			if($onlyarticleid){
				$articleid = $onlyarticleid;
			}else{
				$key = $_GET['key'] ? intval($_GET['key']) : 0;
				$article_idarr = explode('.', $_GET['aids']);
				if(!isset($article_idarr[$key])){
					cpmsg('&#x5168;&#x90E8;&#x91C7;&#x96C6;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op=wait', 'succeed');
				}
				$articleid = $article_idarr[$key];
			}
			
			if($_GET['fail']){
				$status = -1;
			}else{
				$status = 0;
			}
			
			$article = C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->fetch_by_search(array('id' => $articleid, 'status' => $status), array('id' => 'DESC'));
		}
		
    if (!empty($article)) {
    		$processname ='DZS_AUTOPOST_'.$article['id'];
				if(!discuz_process::islocked($processname, 15)) {
			    $spider = C::t('#addon_collect_tieba#addon_collect_tieba_spider')->fetch_by_search(array('id' => $article['spiderid']));
			    $spider['configs_arr'] = !empty($spider['configs']) ? dunserialize($spider['configs']) : array();
			    if(!is_array($spider['configs_arr'])){
			    	$spider['configs_arr'] = array();
			    }
			    $article['configs'] = $spider['configs_arr'];
			    $article['posttype'] = $spider['posttype'];
			    $articleclasses = new addon_collect_tieba_rule;
			    $articleinfo = $articleclasses->spider($article);
					//$articleinfo['message'] = '';
			    if($articleinfo['censor']){
          		C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x542B;&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;', 'updatetime' => $_G['timestamp']), true);
          } elseif (empty($articleinfo['subject'])) {
	            C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x540D;&#x79F0;', 'updatetime' => $_G['timestamp']), true);
	        } elseif (empty($articleinfo['message'])) {
	        		if($splugin_setting['optimize_fcj'] && $articleinfo['fcj']){
		        		  C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('id' => $article['id']), array('status' => 0, 'errlog' => '&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;'), true);//, 'updatetime' => $_G['timestamp']
		        		  cpmsg_error('&#x60A8;&#x7684;&#x670D;&#x52A1;&#x5668;&#x76EE;&#x524D;&#x65E0;&#x6CD5;&#x6B63;&#x5E38;&#x8BBF;&#x95EE;&#x5934;&#x6761;&#x6587;&#x7AE0;&#x9875;&#xFF0C;&#x8BF7;&#x7A0D;&#x540E;&#x518D;&#x8BD5;');
		        	}else{
		          	if($articleinfo['404']){
	        				C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '404', 'updatetime' => $_G['timestamp']), true);
	        			}else{
		            	C::t('#addon_collect_tieba#addon_collect_tieba_articlelist')->update_by_where(array('id' => $article['id']), array('status' => -1, 'errlog' => '&#x91C7;&#x96C6;&#x4E0D;&#x5230;&#x5185;&#x5BB9;', 'updatetime' => $_G['timestamp']), true);
		            }
		          }
	        } else {
					    $articledata = array(
					        'url' => $articleinfo['url'],
					        'subject' => $articleinfo['subject'],
					        'message' => $articleinfo['message'],
					        'comments' => $articleinfo['comments'],
					        'updatetime' => $_G['timestamp'],
					    );
					    
					    $member = addon_collect_tieba_rule_getuser('post', $article);
					    
					    $articledata['articleid'] = $article['id'];
					    $articledata['uid'] = $member['uid'];
					    $articledata['username'] = $member['username'];
					    $articledata['posttype'] = $spider['posttype'];
					    $articledata['catid'] = $spider['catid'];
					    $articledata['typeid'] = $spider['typeid'];
              $articledata['configs'] = $spider['configs_arr'];
					    $articleclasses->post($articledata);
				  }
				  discuz_process::unlock($processname);
				}
	  }
	  
		if($onlyarticleid){
			cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.($_GET['fail'] ? 'fail' : 'wait'), 'succeed');
		}else{
			cpmsg('['.str_replace(':', '&#58;', $article['subject']).']&#x91C7;&#x96C6;&#x6210;&#x529F;&#xFF0C;&#x81EA;&#x52A8;&#x8DF3;&#x8F6C;&#x91C7;&#x96C6;&#x4E0B;&#x4E00;&#x7BC7;&#x6587;&#x7AE0;', 'action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.'&ac='.$ac.'&spiderid='.intval($_GET['spiderid']).($_GET['dateline'] ? '&dateline='.$_GET['dateline'] : '').($_GET['fail'] ? '&fail=true' : '').'&formhash='.$_G['formhash'].'&aids='.dhtmlspecialchars($_GET['aids']).'&key='.($key+1), 'loading');
		}
}
