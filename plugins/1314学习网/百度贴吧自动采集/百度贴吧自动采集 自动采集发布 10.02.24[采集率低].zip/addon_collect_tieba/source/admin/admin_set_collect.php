<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	set_time_limit(0);
	require_once libfile("function/core", "plugin/addon_collect_tieba/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	require_once libfile("class/rule", "plugin/addon_collect_tieba/source");
	if ($_GET["formhash"] && $_GET["formhash"] == $_G["formhash"]) {
		$_var_9 = false;
		$_var_10 = intval($_GET["onlyspiderid"]);
		$_var_11 = $_var_10 ? $_var_10 : intval($_GET["spiderid"]);
		if (empty($_var_11)) {
			$_var_12 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("status" => "1"), array("id" => "ASC"));
		} else {
			$_var_12 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("id" => $_var_11, "status" => "1"), array("id" => "ASC"));
		}
		if (empty($_var_12)) {
			cpmsg("&#x5168;&#x90E8;&#x91C7;&#x96C6;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14, "succeed");
		}
		$_var_12["current_page"] = max(intval($_GET["page"]), 1);
		$_var_12["max_behot_time"] = dintval($_GET["max_behot_time"]);
		$_var_15 = new addon_collect_tieba_rule();
		$_var_16 = $_var_15->analyze($_var_12);
		if (empty($_GET["begin"]) && $_var_16["page"] > 1 && $_var_16["order"] != "ASC") {
			$_var_12["current_page"] = $_var_16["page"];
			$_var_12["max_page"] = $_var_16["page"];
			$_var_16 = $_var_15->analyze($_var_12);
		}
		if ($_var_16 === false) {
			$_var_9 = true;
		} else {
			if ($_var_16 === 0) {
				return 0;
			}
			$_var_16["articlelist"] = array_reverse($_var_16["articlelist"]);
			foreach ($_var_16["articlelist"] as $_var_17) {
				$_var_17["sha1"] = sha1($_var_17["url"]);
				$_var_18 = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->fetch_by_search(DB::field("sha1", $_var_17["sha1"]) . " OR " . DB::field("group_id", $_var_17["group_id"]), array("id" => "DESC"));
				if (empty($_var_18["id"])) {
					$_var_19 = array("spiderid" => $_var_12["id"], "url" => $_var_17["url"], "sha1" => $_var_17["sha1"], "subject" => $_var_17["subject"], "message" => $_var_17["message"], "group_id" => $_var_17["group_id"], "creattime" => $_G["timestamp"], "updatetime" => $_G["timestamp"]);
					C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->insert($_var_19);
				}
			}
			if ($_var_16["order"] == "ASC" && $_var_16["page"] > $_var_12["current_page"]) {
				cpmsg(str_replace(":", "&#58;", $_var_12["name"]) . "&#x7B2C;" . $_var_12["current_page"] . "&#x9875;&#x91C7;&#x96C6;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14 . "&formhash=" . $_G["formhash"] . "&begin=ok&onlyspiderid=" . $_var_10 . "&spiderid=" . $_var_12["id"] . "&page=" . ($_var_12["current_page"] + 1) . ($_var_16["max_behot_time"] ? "&max_behot_time=" . $_var_16["max_behot_time"] : ''), "loading");
			} else {
				if ($_var_16["order"] != "ASC" && $_var_12["current_page"] > 1) {
					cpmsg(str_replace(":", "&#58;", $_var_12["name"]) . "&#x7B2C;" . $_var_12["current_page"] . "&#x9875;&#x91C7;&#x96C6;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14 . "&formhash=" . $_G["formhash"] . "&begin=ok&onlyspiderid=" . $_var_10 . "&spiderid=" . $_var_12["id"] . "&page=" . ($_var_12["current_page"] - 1) . ($_var_16["max_behot_time"] ? "&max_behot_time=" . $_var_16["max_behot_time"] : ''), "loading");
				}
			}
			$_var_20 = array("updatetime" => $_G["timestamp"]);
			$_var_20["count"] = C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->count_by_where(array("spiderid" => $_var_12["id"]));
			$_var_20["page"] = $_var_16["page"];
			C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update_by_where(array("id" => $_var_12["id"]), $_var_20, true);
		}
		if ($_var_9) {
			$_var_20 = array("status" => 0);
			C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update_by_where(array("id" => $_var_12["id"]), $_var_20, true);
		}
		if ($_var_10) {
			cpmsg(str_replace(":", "&#58;", $_var_12["name"]) . "&#x91C7;&#x96C6;&#x6210;&#x529F;", "action=plugins&operation=config&do=" . $pluginid . "&identifier=" . dhtmlspecialchars($_GET["identifier"]) . "&pmod=admin_set&type1314=spider", "succeed");
		} else {
			$_var_21 = str_replace(":", "&#58;", $_var_12["name"]) . "&#x7B2C;" . $_var_12["current_page"] . "&#x9875;&#x91C7;&#x96C6;&#x6210;&#x529F;";
			$_var_12 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("id" => array($_var_12["id"], ">"), "status" => "1"), array("id" => "ASC"));
			if (empty($_var_12)) {
				cpmsg("&#x5168;&#x90E8;&#x91C7;&#x96C6;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14, "succeed");
			}
			cpmsg($_var_21, "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14 . "&formhash=" . $_G["formhash"] . "&spiderid=" . $_var_12["id"] . "&page=1", "loading");
		}
	} else {
		s_shownav("sort", "sorts_admin");
		showtips("<li>&#x4E00;&#x952E;&#x91C7;&#x96C6;&#x4F1A;&#x4ECE;&#x7B2C;&#x4E00;&#x9875;&#x5F00;&#x59CB;&#x91C7;&#x96C6;&#x5230;&#x6700;&#x540E;&#x4E00;&#x9875;&#xFF0C;&#x53EF;&#x4EE5;&#x591A;&#x6B21;&#x6267;&#x884C;&#xFF0C;&#x4E0D;&#x4F1A;&#x91CD;&#x590D;&#x8BB0;&#x5F55;&#x76F8;&#x540C;&#x7684;&#x6587;&#x7AE0;</li><li>&#x91C7;&#x96C6;&#x7684;&#x6587;&#x7AE0;&#x4E0D;&#x4F1A;&#x81EA;&#x52A8;&#x53D1;&#x5E03;&#xFF0C;&#x8BA1;&#x5212;&#x4EFB;&#x52A1;&#x6267;&#x884C;&#x65F6;&#x6587;&#x7AE0;&#x624D;&#x4F1A;&#x4E00;&#x6279;&#x4E00;&#x6279;&#x7684;&#x81EA;&#x52A8;&#x53D1;&#x5E03;</li>");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_13 . "&ac=" . $_var_14);
		showtableheader("&#x70B9;&#x51FB;&#x201C;&#x63D0;&#x4EA4;&#x201D;&#x4E00;&#x952E;&#x91C7;&#x96C6;&#x6240;&#x6709;&#x6587;&#x7AE0;");
		$_var_22 = array(array(0, "&#x5168;&#x90E8;&#x8718;&#x86DB;"));
		$_var_23 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_all_by_search(array("status" => "1"), array("displayorder" => "ASC", "id" => "DESC"));
		foreach ($_var_23 as $_var_12) {
			$_var_22[] = array($_var_12["id"], dhtmlspecialchars($_var_12["name"]));
		}
		s_showsetting("&#x6267;&#x884C;&#x54EA;&#x4E9B;&#x8718;&#x86DB;", array("onlyspiderid", $_var_22), 0, "select", '', '', '');
		showsubmit("submit", "submit");
		showtablefooter();
		showformfooter();
	}