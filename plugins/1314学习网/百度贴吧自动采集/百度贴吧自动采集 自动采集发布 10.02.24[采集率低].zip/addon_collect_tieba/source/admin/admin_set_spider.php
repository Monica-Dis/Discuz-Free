<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("function/core", "plugin/addon_collect_tieba/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	require_once libfile("function/forumlist");
	$_var_13 = array("list", "edit");
	$op = in_array($_GET["op"], $_var_13) ? $_GET["op"] : "list";
	$ac = '';
	$posttypelist = array("1" => "&#x8BBA;&#x575B;&#x5E16;&#x5B50;", "2" => "&#x95E8;&#x6237;&#x6587;&#x7AE0;", "3" => "&#x7FA4;&#x7EC4;&#x5E16;&#x5B50;");
	if ($op == "list") {
		if (!submitcheck("submit")) {
			showtips("\r\n\t\t    <li><b style=\"color:red\">&#x63D2;&#x4EF6;&#x4EC5;&#x4F9B;&#x6536;&#x96C6;&#x6587;&#x7AE0;&#xFF0C;&#x65B9;&#x4FBF;&#x81EA;&#x5DF1;&#x9605;&#x8BFB;&#xFF0C;&#x60A8;&#x9700;&#x8981;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x6587;&#x7AE0;&#x7248;&#x6743;&#x98CE;&#x9669;&#xFF0C;&#x672A;&#x83B7;&#x5F97;&#x539F;&#x6587;&#x4F5C;&#x8005;&#x6388;&#x6743;&#x7684;&#x60C5;&#x51B5;&#x4E0B;&#xFF0C;&#x8BF7;&#x52FF;&#x5C06;&#x6587;&#x7AE0;&#x516C;&#x5F00;&#x53D1;&#x5E03;&#x6216;&#x7528;&#x4E8E;&#x5546;&#x4E1A;&#x7528;&#x9014;&#x3002;</b></li>\r\n\t\t    <li>&#x53EA;&#x6709;&#x5173;&#x952E;&#x5B57;&#x3001;&#x540C;&#x6B65;&#x7C7B;&#x578B;&#x3001;&#x9891;&#x9053;&#x680F;&#x76EE;&#x90FD;&#x8BBE;&#x7F6E;&#x4E86;&#x624D;&#x53EF;&#x4EE5;&#x542F;&#x7528;&#x722C;&#x866B;&#xFF0C;&#x8BBE;&#x7F6E;&#x9519;&#x8BEF;&#x6216;&#x65E0;&#x6CD5;&#x91C7;&#x96C6;&#x7684;&#x7F51;&#x7AD9;&#x5728;&#x6267;&#x884C;&#x91C7;&#x96C6;&#x65F6;&#x4F1A;&#x81EA;&#x52A8;&#x5173;&#x95ED;&#x722C;&#x866B;</li>\r\n\t\t    <li>&#x91C7;&#x96C6;&#x9875;&#x6570;&#x8BBE;&#x7F6E;&#x53EA;&#x5BF9;&#x722C;&#x866B;&#x53F3;&#x4FA7;&#x7684;&#x4E00;&#x952E;&#x91C7;&#x96C6;&#x6709;&#x6548;&#xFF0C;&#x81EA;&#x52A8;&#x91C7;&#x96C6;&#x53EA;&#x91C7;&#x96C6;&#x6700;&#x65B0;&#x7684;&#x4E00;&#x9875;&#xFF0C;&#x8BF7;&#x52FF;&#x77ED;&#x65F6;&#x95F4;&#x9891;&#x7E41;&#x624B;&#x52A8;&#x91C7;&#x96C6;&#x548C;&#x53D1;&#x5E03;&#xFF0C;&#x4EE5;&#x514D;&#x89E6;&#x53D1;&#x9632;&#x91C7;&#x96C6;&#x88AB;&#x5C4F;&#x853D;&#x3002;</li>\r\n\t\t    <li>&#x5982;&#x679C;&#x6309;&#x5177;&#x4F53;&#x7684;&#x8D34;&#x5427;&#x91C7;&#x96C6;&#xFF0C;&#x5982;&#x201C;&#x7F8E;&#x5973;&#x5427;&#x201D;&#xFF0C;&#x683C;&#x5F0F;&#x4E3A;&#xFF1A;https://tieba.baidu.com/f?kw=%E7%BE%8E%E5%A5%B3&ie=utf-8</li>\r\n\t\t    ");
			s_shownav("sort", "sorts_admin");
			showtableheader("&#x722C;&#x866B;&#x7BA1;&#x7406;");
			showtablefooter();
			$_GET["f_kw"] = trim($_GET["f_kw"]);
			if ($_GET["formhash"] != $_G["formhash"]) {
				$_GET["f_kw"] = '';
			}
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			echo "&nbsp;&nbsp;&#x722C;&#x866B;&#x641C;&#x7D20;&nbsp;&nbsp;<input type=\"text\" name=\"f_kw\" value=\"" . dhtmlspecialchars($_GET["f_kw"]) . "\" class=\"px vm\" autocomplete=\"off\" placeholder=\"&#x8BF7;&#x8F93;&#x5165;&#x722C;&#x866B;&#x540D;&#x79F0;\">&nbsp;&nbsp;\r\n\t\t\t\t<button type=\"submit\" class=\"pn\" name=\"search\" id=\"submit_search\" value=\"true\"><span class=\"xi1 xw1\">&#x641C;&#x7D22;</span></button>\r\n\t\t    &nbsp;&nbsp;\r\n\t\t    <script type=\"text/JavaScript\">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'search'); });</script>\r\n\t\t    ";
			showtablefooter();
			showformfooter();
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "class=\"spiderform\"", "spiderform");
			showtableheader('');
			$portalcategory = array();
			loadcache("portalcategory");
			$portalcategory = $_G["cache"]["portalcategory"];
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x722C;&#x866B;&#x540D;&#x79F0;", "&#x6293;&#x53D6;&#x5173;&#x952E;&#x5B57;/&#x8D34;&#x5427;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x540C;&#x6B65;&#x7C7B;&#x578B;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x9891;&#x9053;&#x680F;&#x76EE;/&#x677F;&#x5757;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#x91C7;&#x96C6;&#x9875;&#x6570;<b style=\"color:red\">&#xFF08;1-5&#xFF09;</b>", '', "&#x6587;&#x7AE0;&#x6570;&#x91CF;", "&#x6700;&#x540E;&#x91C7;&#x96C6;&#x65F6;&#x95F4;", "&#x72B6;&#x6001;", '', '', ''));
			$_var_17 = array();
			if ($_GET["f_kw"]) {
				$_GET["f_kw"] = addslashes($_GET["f_kw"]);
				$_var_17["name"] = array("%" . addcslashes($_GET["f_kw"], "%_") . "%", "like");
			}
			$_var_18 = 30;
			$_var_19 = 100;
			$_var_20 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->count_by_where($_var_17);
			$_var_21 = $_G["page"] - 1 > $_var_20 / $_var_18 || $_G["page"] > $_var_19 ? 1 : $_G["page"];
			$_var_22 = ($_var_21 - 1) * $_var_18;
			$_var_23 = multi($_var_20, $_var_18, $_var_21, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . ($_GET["f_kw"] ? "&formhash=" . $_G["formhash"] . "&search=ok&f_kw=" . urlencode($_GET["f_kw"]) : ''), $_var_19);
			$_var_24 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_all_by_search($_var_17, array("displayorder" => "ASC", "id" => "DESC"), $_var_22, $_var_18);
			foreach ($_var_24 as $_var_25) {
				$_var_26 = 1;
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td28\"", "class=\"td28\"", "class=\"td28\"", "class=\"td28\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:60px;\"", " style=\"width:100px;\"", " style=\"width:30px;\"", " style=\"width:60px;\"", " style=\"width:60px;\"", ''), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_25["id"] . "\" " . $_var_27 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_25["id"] . "]\" value=\"" . $_var_25["displayorder"] . "\" style=\"height: 20px;\">", "<input type=\"text\" name=\"name[" . $_var_25["id"] . "]\" value=\"" . $_var_25["name"] . "\" class=\"txt\" style=\"width: 120px;height: 20px;\">", "<input type=\"text\" name=\"url[" . $_var_25["id"] . "]\" value=\"" . $_var_25["url"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", addon_collect_tieba_posttypeselect($posttypelist, $_var_25["posttype"], $_var_25["id"]), addon_collect_tieba_catidselect($portalcategory, $_var_25["catid"], $_var_25["id"], 0, $_var_25["posttype"]), "<input type=\"text\" class=\"txt\" name=\"page[" . $_var_25["id"] . "]\" value=\"" . $_var_25["page"] . "\" style=\"height: 20px;\">", "<div style=\"width:100px;\"><a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&spiderid=" . $_var_25["id"] . "\" class=\"act\">&#x66F4;&#x591A;&#x8BBE;&#x7F6E;</a></div>", "<div style=\"width:100px;\">" . $_var_25["count"] . "</div>", "<div style=\"width:80px;\">" . ($_var_25["updatetime"] ? dgmdate($_var_25["updatetime"], "Y-m-d", $_G["setting"]["timeoffset"]) : "&#x672A;&#x91C7;&#x96C6;") . "</div>", "<div style=\"width:30px;\"><input name=\"status[" . $_var_25["id"] . "]\" type=\"checkbox\" value=\"1\" " . ($_var_25["status"] ? "checked=\"checked=\"" : '') . "/></div>", "<div style=\"width:60px;\">" . ($_var_25["status"] ? "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=" . dhtmlspecialchars($_GET["identifier"]) . "&pmod=admin_set&type1314=collect&formhash=" . $_G["formhash"] . "&onlyspiderid=" . $_var_25["id"] . "&page=1\" class=\"act\">&#x4E00;&#x952E;&#x91C7;&#x96C6;</a>" : "<-&#x5148;&#x542F;&#x7528;") . "</div>", "<div style=\"width:60px;\">" . ($_var_25["status"] ? "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=" . dhtmlspecialchars($_GET["identifier"]) . "&pmod=admin_article&type1314=list&op=wait&formhash=" . $_G["formhash"] . "&search=ok&spiderid=" . $_var_25["id"] . "\" class=\"act\">&#x4E00;&#x952E;&#x53D1;&#x5E03;</a>" : '') . "</div>", ''));
			}
			require_once libfile("include/sort", "plugin/addon_collect_tieba/source");
			showsubmit("submit", "submit", "del", '', $_var_23, false);
			showtablefooter();
			showformfooter();
			$_var_28 = "addon_collect_tieba.plugin";
			$_var_29 = "DZG_ADDONS_" . substr(md5($_var_28), 0, 12);
			if (discuz_process::islocked($_var_29, 86400)) {
			}
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_32) {
					$_var_32 = intval($_var_32);
					C::t("#addon_collect_tieba#addon_collect_tieba_spider")->delete_by_where(array("id" => $_var_32), true);
					C::t("#addon_collect_tieba#addon_collect_tieba_articlelist")->delete_by_where(array("spiderid" => $_var_32), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_32 => $_var_33) {
					$_var_34 = array("url" => $_POST["url"][$_var_32], "catid" => $_POST["catid"][$_var_32], "page" => $_POST["page"][$_var_32], "status" => $_POST["status"][$_var_32] ? 1 : 0, "displayorder" => $_POST["order"][$_var_32]);
					$_var_34["posttype"] = min(max($_POST["posttype"][$_var_32], 0), 3);
					if (!empty($_POST["name"][$_var_32])) {
						$_var_34["name"] = $_POST["name"][$_var_32];
					}
					if (empty($_var_34["url"]) || empty($_var_34["catid"]) || empty($_var_34["posttype"])) {
						$_var_34["status"] = 0;
					}
					$_var_25 = C::t("#addon_collect_tieba#addon_collect_tieba_spider")->fetch_by_search(array("id" => $_var_32));
					if ($_var_34["catid"] != $_var_25["catid"]) {
						$_var_34["typeid"] = 0;
					}
					C::t("#addon_collect_tieba#addon_collect_tieba_spider")->update($_var_32, $_var_34);
				}
			}
			if (is_array($_GET["newname"])) {
				foreach ($_GET["newname"] as $_var_32 => $_var_35) {
					if (empty($_var_35)) {
						$_var_35 = strpos($_POST["newurl"][$_var_32], "http") === false ? $_POST["newurl"][$_var_32] : random(10);
					}
					$_var_34 = array("name" => $_var_35, "url" => $_POST["newurl"][$_var_32], "catid" => $_POST["newcatid"][$_var_32], "page" => min(max($_POST["newpage"][$_var_32], 1), 5), "status" => 1, "creattime" => $_G["timestamp"], "displayorder" => $_GET["neworder"][$_var_32]);
					$_var_34["posttype"] = min(max($_POST["newposttype"][$_var_32], 0), 3);
					if (empty($_var_34["url"]) || empty($_var_34["catid"]) || empty($_var_34["posttype"])) {
						$_var_34["status"] = 0;
					}
					C::t("#addon_collect_tieba#addon_collect_tieba_spider")->insert($_var_34, 1);
				}
			}
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	} else {
		if ($op == "edit") {
			require_once libfile("include/spider", "plugin/addon_collect_tieba/source");
		}
	}