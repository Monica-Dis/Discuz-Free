<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 2018091117LQ2xdantqc
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 */
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/discuz_version.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$pluginarray['plugin']['identifier'].'/installlang.lang.php';
$request_url = str_replace('&step='.$_GET['step'],'',$_SERVER['QUERY_STRING']);
showsubmenusteps($pluginarray['plugin']['name'].$s_installlang[$operation].$s_installlang['ilang_001'], array(
	array($s_installlang['ilang_check'], !$_GET['step']),
	array($s_installlang['ilang_sql'], $_GET['step'] == 'sql'),
	array($s_installlang['ilang_stat'], $_GET['step'] == 'stat'),
	array($s_installlang['ilang_addon'], $_GET['step'] == 'addon'),
	array($s_installlang['ilang_ok'].$s_installlang[$operation], $_GET['step']=='ok'),
));
switch($_GET['step']){
	default:
	case 'check':
		$addonid = $pluginarray['plugin']['identifier'].'.plugin';
		$array = cloudaddons_getmd5($addonid);
		if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
			
			
		}
		cpmsg($s_installlang['ilang_check_ok'], "{$request_url}&step=sql", 'loading', array('operation' => $s_installlang[$operation]));
		break;
	case 'sql':
		$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_addon_collect_tieba_articlelist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `spiderid` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `sha1` varchar(40) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `group_id` varchar(40) NOT NULL,
  `postid` int(10) unsigned NOT NULL DEFAULT '0',
  `posttype` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `errlog` varchar(255) NOT NULL,
  `creattime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sha1` (`sha1`),
  KEY `creattime` (`creattime`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_collect_tieba_spider` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `url` varchar(255) NOT NULL,
  `posttype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `typeid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `configs` text NOT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `page` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `displayorder` int(10) NOT NULL DEFAULT '0',
  `creattime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `posttime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `updatetime` (`updatetime`),
  KEY `displayorder` (`displayorder`),
  KEY `posttime` (`posttime`)
) ENGINE=MyISAM;
EOF;
		runquery($sql);
		$columns = array();
		$query = DB::query("SHOW COLUMNS FROM ".DB::table('addon_collect_tieba_spider'));
		while($temp = DB::fetch($query)) {
			$columns[] = $temp['Field'];
		}
		if(!in_array('typeid', $columns)){
			DB::query("ALTER TABLE ".DB::table('addon_collect_tieba_spider')." ADD `typeid` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0' AFTER `catid`");
		}
		if(!in_array('configs', $columns)){
			DB::query("ALTER TABLE ".DB::table('addon_collect_tieba_spider')." ADD `configs` TEXT NOT NULL AFTER `typeid`");
		}
		if(!in_array('posttime', $columns)){
			DB::query("ALTER TABLE ".DB::table('addon_collect_tieba_spider')." ADD `posttime` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `updatetime`");
			DB::query("ALTER TABLE ".DB::table('addon_collect_tieba_spider')." ADD INDEX(`posttime`)");
		}
		cpmsg($s_installlang['ilang_sql_ok'], "{$request_url}&step=stat", 'loading', array('operation' => $s_installlang[$operation]));
		break;
	case 'stat':
		$_statInfo = array();
		$_statInfo['pluginName'] = $pluginarray['plugin']['identifier'];
		$_statInfo['pluginVersion'] = $pluginarray['plugin']['version'];
		$_statInfo['bbsVersion'] = DISCUZ_VERSION;
		$_statInfo['bbsRelease'] = DISCUZ_RELEASE;
		$_statInfo['timestamp'] = TIMESTAMP;
		$_statInfo['bbsUrl'] = $_G['siteurl'];
		$_statInfo['SiteUrl'] = $_G['siteurl'];
		$_statInfo['ClientUrl'] = $_G['siteurl'];
		$_statInfo['SiteID'] = '';
		$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
		$_statInfo['action'] = str_replace('plugin', '', $operation);
		$_statInfo['genuine'] = splugin_genuine($pluginarray['plugin']['identifier']);
		$_statInfo = base64_encode(serialize($_statInfo));
		$_md5Check = md5($_statInfo);
		$StatUri = 'http'.($_G['isHTTPS'] ? 's' : '').'://ww'.'w.zz'.'b'.'7.net/s'.'ta'.'t.p'.'hp';
		$_StatUrl = $StatUrl.'?info='.$_statInfo.'&md5check='.$_md5Check;
		$code =  "<script src=\"".$_StatUrl."\" type=\"text/javascript\"></script>";
		cpmsg($s_installlang['ilang_stat_ok'], "{$request_url}&step=addon", 'loading', array('operation' => $s_installlang[$operation], 'stat_code' => $code));
		break;
	case 'addon':
		$available = dfsockopen('http://ww'.'w.zz'.'b'.'7.net/api/available.php?siteurl='.rawurlencode($_G['siteurl']).'&identifier='.$identifier, 0, '', '', false, '', 5);
		if($available == 'succeed'){
			$_statInfo = array();
			$_statInfo['pluginName'] = $pluginarray['plugin']['identifier'];
			$_statInfo['bbsVersion'] = DISCUZ_VERSION;
			$_statInfo['bbsUrl'] = $_G['siteurl'];
			$_statInfo['action'] = str_replace('plugin', '', $operation);
			$_statInfo['nextUrl'] = ADMINSCRIPT.'?'.$request_url;
			$_statInfo = base64_encode(serialize($_statInfo));
			$_md5Check = md5($_statInfo);
			$StatUrl = 'http'.($_G['isHTTPS'] ? 's' : '').'://www.z'.'z'.'b7.net/api/outer_addon.php';
			$_StatUrl = $StatUrl.'?type=js&info='.$_statInfo.'&md5check='.$_md5Check;
			echo '<script type="text/javascript">location.href="'.$_G['siteurl'].ADMINSCRIPT.'?'.$request_url.'&step=ok";</script>';
		}
		splugin_updatecache($pluginarray['plugin']['identifier']);
		break;
	case 'ok':
		$finish = TRUE;
		break;
}
