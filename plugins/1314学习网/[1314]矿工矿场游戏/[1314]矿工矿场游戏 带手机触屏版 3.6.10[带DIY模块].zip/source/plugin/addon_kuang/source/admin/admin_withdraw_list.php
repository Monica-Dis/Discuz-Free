<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	$_var_11 = array("all", "status0", "status1", "status_1");
	$op = in_array($_GET["op"], $_var_11) ? $_GET["op"] : "all";
	addon_kuang_admin::subtitle(array(array("&#x5168;&#x90E8;", "all"), array("&#x5F85;&#x5904;&#x7406;", "status0"), array("&#x5DF2;&#x53D7;&#x7406;", "status1"), array("&#x5DF2;&#x5173;&#x95ED;", "status_1")), $type1314, $op);
	if (!submitcheck("submit")) {
		s_shownav("sort", "sorts_admin");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
		showtableheader('');
		$_var_12 = array();
		$_var_12 = C::t("#addon_kuang#addon_kuang_withdraw_channel")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
		showsubtitle(array("del", "&#x72B6;&#x6001;", "&#x7528;&#x6237;", "&#x6E20;&#x9053;&#x540D;&#x5B57;", "&#x5F00;&#x6237;&#x4EBA;", "&#x8D26;&#x53F7;/&#x5361;&#x53F7;", "&#x63D0;&#x73B0;&#x91D1;&#x989D;", "&#x6D88;&#x8017;&#x7684;&#x6C34;&#x6676;", "IP(&#x7AEF;&#x53E3;)", "&#x65F6;&#x95F4;", "&#x5907;&#x6CE8;"));
		if ($op == "status0") {
			$_var_13 = array("status" => 0);
		} else {
			if ($op == "status1") {
				$_var_13 = array("status" => 1);
			} else {
				if ($op == "status_1") {
					$_var_13 = array("status" => -1);
				} else {
					$_var_13 = array();
				}
			}
		}
		$_var_14 = 20;
		$_var_15 = 1000;
		$_var_16 = C::t("#addon_kuang#addon_kuang_withdraw_record")->count_by_where($_var_13);
		$_var_17 = intval($_GET["page"]);
		$_var_17 = $_var_17 - 1 > $_var_16 / $_var_14 || $_var_17 > $_var_15 ? 1 : $_var_17;
		$_var_18 = ($_var_17 - 1) * $_var_14;
		$_var_19 = multi($_var_16, $_var_14, $_var_17, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op, $_var_15);
		$_var_20 = C::t("#addon_kuang#addon_kuang_withdraw_record")->fetch_all_by_search($_var_13, array("id" => "DESC"), $_var_18, $_var_14);
		foreach ($_var_20 as $_var_21) {
			showtablerow('', array("class=\"td25\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", " style=\"width:100px;\"", ''), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_21["id"] . "\" " . $_var_22 . ">", "<select name=\"status[" . $_var_21["id"] . "]\"><option value=\"0\">&#x5F85;&#x5904;&#x7406;</option><option value=\"1\" " . ($_var_21["status"] == 1 ? "selected=\"selected\"" : '') . ">&#x5DF2;&#x53D7;&#x7406;</option><option value=\"-1\" " . ($_var_21["status"] == -1 ? "selected=\"selected\"" : '') . ">&#x5DF2;&#x5173;&#x95ED;</option></select>", "<a href=\"home.php?mod=space&uid=" . $_var_21["uid"] . "\" target=\"_blank\">" . $_var_21["username"] . "</a>", $_var_12[$_var_21["channelid"]]["name"], "<input type=\"text\" name=\"name[" . $_var_21["id"] . "]\" value=\"" . dhtmlspecialchars($_var_21["name"]) . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", "<input type=\"text\" name=\"account[" . $_var_21["id"] . "]\" value=\"" . dhtmlspecialchars($_var_21["account"]) . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", $_var_21["money"] . "&#x5143;", $_var_21["crystal"], $_var_21["useip"] . "<br>(" . $_var_21["port"] . ")", dgmdate($_var_21["dateline"], "Y-m-d H:i", $_G["setting"]["timeoffset"]), "<textarea name=\"remark[" . $_var_21["id"] . "]\" rows=\"3\" cols=\"40\" tabindex=\"1\">" . dhtmlspecialchars($_var_21["remark"]) . "</textarea>"));
		}
		showsubmit("submit", "submit", "del", '', $_var_19);
		showtablefooter();
		showformfooter();
	} else {
		if (is_array($_POST["delete"])) {
			foreach ($_POST["delete"] as $_var_23) {
				$_var_23 = intval($_var_23);
				C::t("#addon_kuang#addon_kuang_withdraw_record")->delete_by_where(array("id" => $_var_23), true);
			}
		}
		if (is_array($_POST["status"])) {
			foreach ($_POST["status"] as $_var_23 => $_var_24) {
				$_var_25 = array("name" => $_POST["name"][$_var_23], "account" => $_POST["account"][$_var_23], "remark" => $_POST["remark"][$_var_23], "status" => $_POST["status"][$_var_23]);
				C::t("#addon_kuang#addon_kuang_withdraw_record")->update($_var_23, $_var_25);
			}
		}
		cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
	}