<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net timestamp 1554289201
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('');
}

$oparray = array('list', 'edit', 'group', 'category');
$op = in_array($_GET['op'], $oparray) ? $_GET['op'] : 'list';

if ($op == 'list') {
    if (!submitcheck('submit')) {
    	$_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
			echo '<div id="my_addonlist"></div>';
			s_shownav('sort', 'sorts_admin');
	    showformheader(STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac);
        showtableheader('');
        
        $oretypearray = $oretypelist = array();
        showsubtitle(array('del', '&#x663E;&#x793A;&#x987A;&#x5E8F;', '&#x77FF;&#x77F3;&#x540D;&#x79F0;', '&#x56FE;&#x6807;&#xFF08;&#x70B9;&#x51FB;&#x7F16;&#x8F91;&#x53EF;&#x4EE5;&#x4E0A;&#x4F20;&#xFF09;', '&#x591A;&#x5C11;&#x77FF;&#x77F3;&#x5151;&#x6362;&#x4E00;&#x4E2A;&#x4EA4;&#x6613;&#x79EF;&#x5206;', '&#x72B6;&#x6001;', '&#x64CD;&#x4F5C;'));

		$minelist = C::t('#addon_kuang#addon_kuang_oretype')->fetch_all_by_search(array(), array('displayorder' => 'ASC', 'id' => 'ASC'));
		foreach ($minelist as $mine) {
			showtablerow('', array('class="td25"', 'class="td25"', 'class="td28"', '', 'class="td28"', ' style="width:50px;"', ' style="width:100px;"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$mine[id]\" $disabled>",
				'<input type="text" class="txt" name="order['.$mine['id'].']" value="'.$mine['displayorder'].'" style="height: 20px;">',
				'<input type="text" name="name['.$mine['id'].']" value="'.dhtmlspecialchars($mine['name']).'" class="txt" style="width: 150px;height: 20px;">(id:'.$mine['id'].')',
				'<input type="text" name="icon['.$mine['id'].']" value="'.dhtmlspecialchars($mine['icon']).'" class="txt" style="width: 150px;height: 20px;">'.($mine['icon'] ? '<img src="'.$mine['icon'].'" width="15" height="15"/>' : ''),
				'<input type="text" name="ore2credit['.$mine['id'].']" value="'.dhtmlspecialchars($mine['ore2credit']).'" class="txt" style="width: 150px;height: 20px;">',
				$mine['status'] ? '<b style="color:green;">&#x542F;&#x7528;</b>' : '<b style="color:red;">&#x5173;&#x95ED;</b>',
				'<a href="' . ADMINSCRIPT . '?action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=edit&cid=' . $mine['id'] . '" class="act">' . cplang('edit') . '</a>',
            ));
		}
		echo '<tr><td></td><td colspan="6"><div><a href="javascript:;" onclick="addrow(this, 0)" class="addtr">&#x6DFB;&#x52A0;&#x5206;&#x7C7B;</a></div></td></tr>';
		echo '<script type="text/JavaScript">
	
		var rowtypedata = new Array();
		rowtypedata[0] = [
					[1, ""],
					[1,\'<input type="text" class="txt" name="neworder[]" style="height: 20px;"/>\', "td25"],
					[1, \'<div><input type="text" class="txt" name="newname[]" style="width: 150px;height: 20px;"/><a href="javascript:;" class="deleterow" onClick="deleterow(this)">'.cplang('delete').'</a></div>\', "td28"],
					[1, ""],
					[1, \'<input type="text" class="txt" name="newore2credit[]" style="width: 150px;height: 20px;"/>\'],
					[1, ""],
					[1, ""],
				];
		</script>';
		showsubmit('submit', 'submit', 'del');
		showtablefooter();
		showformfooter();
		echo '<div id="my_addonlist_temp" style="display:none;"><script id="my_addonlist_js" src="//www.d'.'i'.'szz.net/services.php?mod=product&ac=js&op=manage&timestamp='.$_G['timestamp'].'&info='.base64_encode(serialize($_statInfo)).'&md5check='.md5(base64_encode(serialize($_statInfo))).'"></script></div>
		<script type="text/javascript">$("my_addonlist_js").src= "";$("my_addonlist").innerHTML = $("my_addonlist_temp").innerHTML;</script>';
   	} else {
   		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $cid) {
				$cid = intval($cid);
				C::t('#addon_kuang#addon_kuang_oretype')->delete_by_where(array('id' => $cid), true);
			}
		}
   		
		if (is_array($_POST['order'])) {
            foreach ($_POST['order'] as $cid => $value) {
                C::t('#addon_kuang#addon_kuang_oretype')->update($cid, array('name' => $_POST['name'][$cid], 'displayorder' => $_POST['order'][$cid], 'icon' => $_POST['icon'][$cid], 'ore2credit' => $_POST['ore2credit'][$cid]));
            }
        }
        
        if (is_array($_GET['newname'])) {
            foreach ($_GET['newname'] as $key => $name) {
                if (empty($name)) {
                    continue;
                }
                C::t('#addon_kuang#addon_kuang_oretype')->insert(array('name' => $name, 'status' => 1, 'displayorder' => $_GET['neworder'][$key], 'ore2credit' => $_GET['newore2credit'][$key]), 1);
            }
        }
        
        cpmsg($splugin_lang['slang_022'], 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac, 'succeed');
    }
} elseif ($op == 'edit') {
    $cid = intval($_GET['cid']);
    if (!submitcheck('submit')) {
    	$mine = C::t('#addon_kuang#addon_kuang_oretype')->fetch_by_search(array('id' => $cid));
        showformheader(STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac.'&cid='.$cid, 'enctype');
        showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
        s_showsetting("&#x77FF;&#x77F3;&#x540D;&#x79F0;", 'name', $mine['name'], 'text', '', '', '');
        s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", 'status', $mine['status'], 'radio', '', '', '');
        s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", 'displayorder', $mine['displayorder'], 'number', '', '', '');
		s_showsetting('&#x56FE;&#x7247;&#x94FE;&#x63A5;', 'icon', $mine['icon'], 'filetext','', '', '&#x56FE;&#x6807;&#x5927;&#x5C0F;&#xFF1A;15x15');
        showtableheader();
        showsubmit('submit', "submit");
        showformfooter();
    } else {
    	$data = array(
	    	'name' => $_POST['name'],
	    	'status' => dintval($_POST['status']),
	    	'displayorder' => dintval($_POST['displayorder']),
    	);
    	if($_FILES['icon']) {
			if(in_array($_G['setting']['version'],array('X1.5','X2'))){
				require_once libfile('class/upload');
			}else{
				require_once libfile('discuz/upload','class');
			}
			$upload = new discuz_upload();
			$upload->init($_FILES['icon']);
			if($upload->errorcode){
			  	showmessage('&#x56FE;&#x7247;&#x4E0D;&#x80FD;&#x4E3A;&#x7A7A;','','error');
			}elseif (!$upload->attach['isimage']) {
				showmessage('&#x56FE;&#x7247;&#x683C;&#x5F0F;&#x9519;&#x8BEF;','','error');
			}
			$source = $upload->attach['tmp_name'];
			
			$basedir = 'data/attachment/addon_kuang/icon';
			$subdir = date('Ym').'/'.date('d').'/';
			$targetpath = $basedir.'/'.$subdir;
			dmkdir($targetpath);
			$target = $targetpath.date('His').strtolower(random(16)).'.'.$upload->attach['ext'];
			if($upload->save_to_local($source, $target)) {
				$data['icon'] = $target;
			}
		} else {
			$data['icon'] = $_POST['icon'];
		}
        C::t('#addon_kuang#addon_kuang_oretype')->update($cid, $data, 1);
        cpmsg($splugin_lang['slang_022'], 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=list', 'succeed');
    }
}
