<?php

/**
 * Copyright 2001-2099 Dism.Taobao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: module_mining.php 7217 2020-06-28 17:35:03
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
exit('');
}
if(!$_G['uid']) {
showmessage('not_loggedin', null, array(), array('login' => 1));
}
$oparray = array('kaicai', 'zhaohui', 'lingqu');//  diszzѧ����
$op = in_array($_GET['op'], $oparray) ? $_GET['op'] : 'kaicai';# dism_taobao_com
if($op == 'kaicai'){
if (submitcheck('formhash')) {
$miner = intval($_POST['miner']);
$zdtl6dv7 = "http://t.cn/Aiux14ti";
if($miner <= 0){
addon_kuang_showmessage($splugin_lang['slang_001']);
$vh52z7gt = "diszz���Wϰ��";
}
if($kuang_member['miner'] <= 0 || $kuang_member['work_miner'] >= $kuang_member['miner']){
addon_kuang_showmessage($splugin_lang['slang_029']);
}
if($miner + $kuang_member['work_miner'] > $kuang_member['miner']){
addon_kuang_showmessage(str_replace('{minernum}', $kuang_member['miner']-$kuang_member['work_miner'], $splugin_lang['slang_030']));
}//  DisM-Taobao
$mineid = intval($_POST['mineid']);
if(!$mineid){
addon_kuang_showmessage($splugin_lang['slang_002']);
}/*diszzѧϰ�W*/
$mine = C::t('#addon_kuang#addon_kuang_mine')->fetch_by_search(array('id' => $mineid, 'status' => 1));
if(empty($mine)){
addon_kuang_showmessage($splugin_lang['slang_003']);
}
$data = array(
	    	'mineid' => $mineid,
	        'uid' => $_G['uid'],
	        'username' => $_G['username'],
	    	'miner' => $miner,
	        'useip' => $_G['clientip'],
	        'port' => $_G['remoteport'],
	        'dateline' => $_G['timestamp'],
	    );
$mining = C::t('#addon_kuang#addon_kuang_mining')->fetch_by_search(array('uid' => $_G['uid'], 'mineid' => $mineid));#��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
if($mining){
if($mining['miner'] > 0){
$cycle = floor(($_G['timestamp'] - $mining['dateline'])/($splugin_setting['cycle']*3600));
if($cycle > 0){
if($splugin_setting['limit'] > 0){
$cycle = min($splugin_setting['limit'], $cycle);
}
$kuang = $cycle * $mine['output'] * $mining['miner'];
$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_by_search(array('uid' => $_G['uid'], 'oretype' => $mine['oretype']));
if($member_count){
DB::query('UPDATE '.DB::table('addon_kuang_member_count')." SET number = number + '$kuang' WHERE uid='$_G[uid]' AND oretype='$mine[oretype]'", 'UNBUFFERED');
}else{
$countdata = array(
					        'uid' => $_G['uid'],
					    	'oretype' => $mine['oretype'],
					        'number' => $kuang,
					    );
C::t('#addon_kuang#addon_kuang_member_count')->insert($countdata);
}# dism-taobao_com
}
$data['miner'] += $mining['miner'];
addon_add_log(str_replace(array('{kuangname}', '{number}', '{number2}'), array($minelist[$mine['oretype']]['name'], $data['miner'] - $mining['miner'], $data['miner']), $splugin_lang['slang_004']));
}else{
addon_add_log(str_replace(array('{kuangname}', '{number}', '{number2}'), array($minelist[$mine['oretype']]['name'], $data['miner'], $data['miner']), $splugin_lang['slang_004']));
}//25450
C::t('#addon_kuang#addon_kuang_mining')->update_by_where(array('uid' => $_G['uid'], 'mineid' => $mineid), $data, true);
}else{
addon_add_log(str_replace(array('{kuangname}', '{number}', '{number2}'), array($minelist[$mine['oretype']]['name'], $data['miner'], $data['miner']), $splugin_lang['slang_004']));#DisM
C::t('#addon_kuang#addon_kuang_mining')->insert($data);
}
addon_kuang_showmessage($splugin_lang['slang_028'], 'kuang.php?mod=list');
} else {
addon_kuang_showmessage($splugin_lang['slang_038']);//  diszz���Wϰ��
}
}elseif($op == 'zhaohui'){
if($_GET['formhash'] && $_GET['formhash'] == $_G['formhash']){
$mineid = intval($_GET['mineid']);
if(!$mineid){
addon_kuang_showmessage($splugin_lang['slang_002']);
}
$mine = C::t('#addon_kuang#addon_kuang_mine')->fetch_by_search(array('id' => $mineid, 'status' => 1));
if(empty($mine)){
addon_kuang_showmessage($splugin_lang['slang_003']);
}
$mining = C::t('#addon_kuang#addon_kuang_mining')->fetch_by_search(array('uid' => $_G['uid'], 'mineid' => $mineid));
if($mining['miner'] > 0){
$data = array(
		    	'miner' => 0,
		        'useip' => $_G['clientip'],
		        'port' => $_G['remoteport'],
		    );
C::t('#addon_kuang#addon_kuang_mining')->update_by_where(array('uid' => $_G['uid'], 'mineid' => $mineid), $data, true);
addon_add_log(str_replace(array('{minernum}'), array($mining['miner']), $splugin_lang['slang_043']));
addon_kuang_showmessage($splugin_lang['slang_039'], 'kuang.php?mod=list');
$vvj74sx9 = "http://t.cn/Aiux14ti";
}else{
addon_kuang_showmessage($splugin_lang['slang_040'], 'kuang.php?mod=list');
}//From ww'.'w.zz'.'b'.'7.net
} else {
addon_kuang_showmessage($splugin_lang['slang_038']);
}/*DISM_TAOBAO-COM*/
}elseif($op == 'lingqu'){
if($_GET['formhash'] && $_GET['formhash'] == $_G['formhash']){
$mineid = intval($_GET['mineid']);
if(!$mineid){
addon_kuang_showmessage($splugin_lang['slang_002']);
$mcc1p3b3 = "From ww'.'w.zz'.'b'.'7.net";
}
$mine = C::t('#addon_kuang#addon_kuang_mine')->fetch_by_search(array('id' => $mineid, 'status' => 1));
if(empty($mine)){
addon_kuang_showmessage($splugin_lang['slang_003']);#���棺 http://t.cn/Aiux14ti
}
$mining = C::t('#addon_kuang#addon_kuang_mining')->fetch_by_search(array('uid' => $_G['uid'], 'mineid' => $mineid));
if($mining['miner'] > 0){
$cycle = floor(($_G['timestamp'] - $mining['dateline'])/($splugin_setting['cycle']*3600));
if($cycle > 0){
$data = array(
			        'useip' => $_G['clientip'],
			        'port' => $_G['remoteport'],
		        	'dateline' => $_G['timestamp'],
			    );
C::t('#addon_kuang#addon_kuang_mining')->update_by_where(array('uid' => $_G['uid'], 'mineid' => $mineid), $data, true);
if($splugin_setting['limit'] > 0){
$cycle = min($splugin_setting['limit'], $cycle);# dism_taobao_com
}# diszzѧϰ�W
$kuang =  $cycle * $mine['output'] * $mining['miner'];
$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_by_search(array('uid' => $_G['uid'], 'oretype' => $mine['oretype']));
$plsduijy = "DISM_TAOBAO-COM";
if($member_count){
DB::query('UPDATE '.DB::table('addon_kuang_member_count')." SET number = number + '$kuang' WHERE uid='$_G[uid]' AND oretype='$mine[oretype]'", 'UNBUFFERED');#��Ȩ��dism taobao com��δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ
//C::t('#addon_kuang#addon_kuang_member_count')->update_by_where(array('uid' => $_G['uid'], 'mineid' => $mineid), array('number' => $member_count['number'] + $kuang), true);
}else{
$data = array(
				        'uid' => $_G['uid'],
				    	'oretype' => $mine['oretype'],
				        'number' => $kuang,
				    );
C::t('#addon_kuang#addon_kuang_member_count')->insert($data);
}
addon_add_log(str_replace(array('{orenum}', '{orename}'), array($kuang, $oretypelist[$mine['oretype']]['name']), $splugin_lang['slang_041']));# dism_taobao_com
addon_kuang_showmessage($splugin_lang['slang_042'], 'kuang.php?mod=list');
}else{
addon_kuang_showmessage($splugin_lang['slang_044']);
}
}else{
addon_kuang_showmessage($splugin_lang['slang_045']);
}//http://t.cn/AiuxBMCp
} else {
addon_kuang_showmessage($splugin_lang['slang_038']);
}//  �����Ϊ dism taobao com��www . diszz . net�� ����������ԭ�����, ����ӵ�а�Ȩ
}


//Copyright 2001-2099 Dism.Taobao.Com.
//This is NOT a freeware, use is subject to license terms
//$Id: module_mining.php 7682 2020-06-28 09:35:03
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��