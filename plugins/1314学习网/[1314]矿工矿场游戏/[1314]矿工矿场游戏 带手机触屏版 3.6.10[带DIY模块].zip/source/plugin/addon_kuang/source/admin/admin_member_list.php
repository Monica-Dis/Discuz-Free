<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net timestamp 1554289201
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('');
}

$oparray = array('list', 'edit');
$op = in_array($_GET['op'], $oparray) ? $_GET['op'] : 'list';

$oretypelist = array();
$oretypelist = C::t('#addon_kuang#addon_kuang_oretype')->fetch_all_by_search(array('status' => 1), array('displayorder' => 'ASC', 'id' => 'ASC'));

if ($op == 'list') {
    if (!submitcheck('submit')) {
	    s_shownav('sort', 'sorts_admin');
	    $_GET['keyword'] = trim($_GET['keyword']);
	    if(!$_GET['formhash'] || $_GET['formhash'] != $_G['formhash']){
				$_GET['keyword'] = '';
			}
	    echo '
	    <style type="text/css">

				.ss em{display:block;float:left;margin-right:3px;padding-left:2px;width:15px;line-height:20px;background:#EEE;cursor:pointer;}
				.ss em.a{background:#09F;color:#FFF;}
				.board{ padding-left:35px;}
				.td33{ width:25px; }
				.td33 .txt{ width:15px; }
				.td_k{ width:90px; }
				.td_k .txt{ width:80px; }
				.td_l{ width:250px; }
				.td_l .txt{ width:190px; }
#s, .userInt {border-radius: 0;background: url(source/plugin/addon_kuang/images/soso_bg.png) no-repeat;}
#s {position: relative;background-position: -89px 0px;height: 36px;padding-left: 3px;margin-top:25px;margin-bottom:25px;width:500px;margin-left: auto;margin-right: auto;}
#s_input {width: 402px;border: 0 none;float: left;font: 16px Arial;height: 18px;outline: 0 none;margin-top: 3px;padding: 7px 5px 5px;}
#submit_button {width: 85px;height: 36px;background: none;border: 0 none;float: left;text-indent: -9999px;cursor: pointer;}
.s_icn {padding-left: 5px;width: 38px;text-align: left;}

			</style>
	    <div id="s">
    <form id="search_soft" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=addon_kuang&pmod=admin_member&op='.$op.'">
    	<input type="hidden" name="formhash" value="'.$_G['formhash'].'">
    	<input type="text" name="keyword" id="s_input" value="'.($_GET['keyword'] ? dhtmlspecialchars($_GET['keyword']) : '&#x8BF7;&#x8F93;&#x5165;&#x7528;&#x6237;&#x540D;').'" onclick="if(this.value==\'&#x8BF7;&#x8F93;&#x5165;&#x7528;&#x6237;&#x540D;\'){this.value=\'\';}" onblur="if(this.value==\'\'){this.value=\'&#x8BF7;&#x8F93;&#x5165;&#x7528;&#x6237;&#x540D;\';}" autocomplete="off" required="" placeholder="" x-webkit-speech="" speech="">
        <input type="submit" id="submit_button">
    </form>
    <div id="smart_pop" style="display: none; "></div>
</div>
<script type="text/JavaScript">_attachEvent(document.documentElement, \'keydown\', function (e) { entersubmit(e, \'button\'); });</script>
';
	    showformheader(STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac);
        showtableheader('');
        
        $channellist = array();
		$channellist = C::t('#addon_kuang#addon_kuang_withdraw_channel')->fetch_all_by_search(array('status' => 1), array('displayorder' => 'ASC', 'id' => 'ASC'));

        showsubtitle(array('del', '&#x7528;&#x6237;', '&#x623F;&#x5C4B;&#x6570;&#x91CF;', '&#x77FF;&#x5DE5;&#x6570;&#x91CF;', '&#x6C34;&#x6676;&#x6570;&#x91CF;', '&#x77FF;&#x77F3;&#x6570;&#x91CF;', '&#x65F6;&#x95F4;', '&#x72B6;&#x6001;', ''));
		$param = array();
		if($_GET['keyword']){
			$param['username'] = array('%'.addcslashes(addslashes($_GET['keyword']), '%_').'%', 'like');
		}
		$_GET['keyword'] = dhtmlspecialchars($_GET['keyword']);
		$perpage = 20;
		$maxpages = 1000;
		$count = C::t('#addon_kuang#addon_kuang_member')->count_by_where($param);
		$page = intval($_GET['page']);
		$page = ($page-1 > $count/$perpage || $page > $maxpages) ? 1 : $page;
		$start_limit = ($page - 1) * $perpage;
		$multipage = multi($count, $perpage, $page, ADMINSCRIPT.'?action='.STUDY_MANAGE_URL.'&type1314='.$type1314.'&op='.$op.($_GET['keyword'] ? '&keyword='.$_GET['keyword'] : '').'&formhash='.$_G['formhash'], $maxpages);
		
		$memberlist = C::t('#addon_kuang#addon_kuang_member')->fetch_all_by_search($param, array('id' => 'DESC'), $start_limit, $perpage);
		$memberlist = dhtmlspecialchars($memberlist);
		foreach ($memberlist as $member) {
			$member_count = array();
			$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_all_by_search(array('uid' => $member['uid']));
			$kuang = '';
			foreach ($oretypelist as $oretype){
                $kuang .= ($oretype['icon'] ? '<img src="'.$oretype['icon'].'" width="15" height="15"/> ' : '').$oretype['name'].': '.intval($member_count[$oretype['id']]['number']).' ';
	        }
			showtablerow('', array('class="td25"', ' style="width:100px;"', ' style="width:100px;"', ' style="width:100px;"', ' style="width:100px;"', '', ' style="width:100px;"', ' style="width:50px;"', ' style="width:50px;"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$member[uid]\" $disabled>",
				'<a href="home.php?mod=space&uid='.$member['uid'].'" target="_blank">'.str_replace($_GET['keyword'], '<b style="color:red;">'.$_GET['keyword'].'</b>', dhtmlspecialchars($member['username'])).'</a>',
				$member['house'],
				$member['miner'],
				$member['crystal'],
				'<div name="remark" rows="3" cols="40" tabindex="1">'.$kuang.'</div>',
				dgmdate($member['dateline'], 'Y-m-d H:i', $_G['setting']['timeoffset']),
				$member['status'] ? '<b style="color:green;">&#x542F;&#x7528;</b>' : '<b style="color:red;">&#x7981;&#x6B62;</b>',
				'<a href="' . ADMINSCRIPT . '?action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=edit&uid=' . $member['uid'] . '" class="act">' . cplang('edit') . '</a>',
			));
		}
		showsubmit('submit', 'submit', 'del', '', $multipage, false);
		showtablefooter();
		showformfooter();
   	} else {
   		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $uid) {
				$uid = intval($uid);
				C::t('#addon_kuang#addon_kuang_member')->delete_by_where(array('uid' => $uid), true);
				C::t('#addon_kuang#addon_kuang_member_count')->delete_by_where(array('uid' => $uid), true);
				C::t('#addon_kuang#addon_kuang_mining')->delete_by_where(array('uid' => $uid), true);
			}
		}
        
        cpmsg($splugin_lang['slang_022'], 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac, 'succeed');
    }
} elseif ($op == 'edit') {
    $uid = intval($_GET['uid']);
    if($uid <= 0){
    	cpmsg('&#x8BF7;&#x9009;&#x62E9;&#x7528;&#x6237;');
    }
    if (!submitcheck('submit')) {
    	$member = C::t('#addon_kuang#addon_kuang_member')->fetch_by_search(array('uid' => $uid));
        showformheader(STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=' . $op . '&ac=' . $ac.'&uid='.$uid, 'enctype');
        showtableheader($member['username'].' &#x7684;&#x4FE1;&#x606F;&#x4FEE;&#x6539;');
        s_showsetting("&#x623F;&#x5C4B;&#x6570;&#x91CF;", 'house', $member['house'], 'number', '', '', '');
        s_showsetting("&#x77FF;&#x5DE5;&#x6570;&#x91CF;", 'miner', $member['miner'], 'number', '', '', '');
        s_showsetting("&#x6C34;&#x6676;&#x6570;&#x91CF;", 'crystal', $member['crystal'], 'number', '', '', '');
		
		$member_count = array();
		$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_all_by_search(array('uid' => $member['uid']));
		
		foreach($oretypelist as  $value){
	        s_showsetting($value['name'], 'oretype['.$value['id'].']', intval($member_count[$value['id']]['number']), 'number', '', '', '');
	    }
	    
        s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", 'status', $member['status'], 'radio', '', '', '&#x9009;&#x62E9;&#x5426;&#x5219;&#x7981;&#x6B62;&#x7528;&#x6237;&#x73A9;&#x77FF;&#x5DE5;&#x6E38;&#x620F;');
        showtableheader();
        showsubmit('submit', "submit");
        showformfooter();
    } else {
    	$member_count = array();
		$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_all_by_search(array('uid' => $uid));
    	foreach($_POST['oretype'] as $key => $value){
        	if(isset($member_count[$key])){
				C::t('#addon_kuang#addon_kuang_member_count')->update_by_where(array('uid' => $uid, 'oretype' => $key), array('number' => intval($value)), 1);
    		}else{
		    	$data = array(
			        'uid' => $uid,
			    	'oretype' => $key,
			        'number' => $value,
			    );
			    C::t('#addon_kuang#addon_kuang_member_count')->insert($data);
			}
        }
    	$data = array(
	    	'crystal' => $_POST['crystal'],
	    	'house' => $_POST['house'],
	    	'miner' => $_POST['miner'],
	    	'crystal' => $_POST['crystal'],
	    	'status' => dintval($_POST['status']),
    	);
        C::t('#addon_kuang#addon_kuang_member')->update_by_where(array('uid' => $uid), $data, 1);
        cpmsg($splugin_lang['slang_022'], 'action=' . STUDY_MANAGE_URL . '&type1314=' . $type1314 . '&op=list', 'succeed');
    }
}

