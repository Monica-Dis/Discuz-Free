<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_pvsort($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = "/";
	$_var_4 = '';
	foreach ($_arg_0 as $_var_5) {
		$_var_3 = $_var_3 . ($_var_4 . preg_quote($_var_5));
		$_var_4 = "|";
	}
	$_var_3 = $_var_3 . "/";
	preg_match_all($_var_3, $_arg_1, $_var_6);
	$_var_6 = $_var_6[0];
	$_var_6 = array_flip($_var_6);
	foreach ($_var_6 as $_arg_0 => $_var_7) {
		$_arg_2 = str_replace($_arg_0, "\$" . ($_var_7 + 1), $_arg_2);
	}
	return $_arg_2;
}
function study_pvadd($_arg_0, $_arg_1 = 0)
{
	$_arg_0 = str_replace(array("\$3", "\$2", "\$1"), array("~4", "~3", "~2"), $_arg_0);
	if (!$_arg_1) {
		return str_replace(array("~4", "~3", "~2"), array("\$4", "\$3", "\$2"), $_arg_0);
	}
	return str_replace(array("~4", "~3", "~2"), array("{R:4}", "{R:3}", "{R:2}"), $_arg_0);
}
function study_rewritedata()
{
	global $_G;
	global $plugin;
	$_var_2 = array();
	$_var_3 = $_G["cache"]["plugin"]["addon_kuang"];
	$_var_2["rulesearch"]["addon_kuang_mod"] = $_var_3["addon_kuang_mod"] ? $_var_3["addon_kuang_mod"] : "kuang-{mod}.html";
	$_var_2["rulereplace"]["addon_kuang_mod"] = "plugin.php?id=addon_kuang&mod={mod}";
	$_var_2["rulevars"]["addon_kuang_mod"]["{mod}"] = "([a-z]+)";
	$_var_2["rulesearch"]["plugin"] = "{pluginid}-{module}.html";
	$_var_2["rulereplace"]["plugin"] = "plugin.php?id={pluginid}:{module}";
	$_var_2["rulevars"]["plugin"]["{pluginid}"] = "([a-z]+[a-z0-9_]*)";
	$_var_2["rulevars"]["plugin"]["{module}"] = "([a-z0-9_\\-]+)";
	return $_var_2;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	$op = in_array($_GET["op"], array("setting", "rule")) ? $_GET["op"] : "setting";
	addon_kuang_admin::subtitle(array(array("&#x8BBE;&#x7F6E;", "setting"), array("<font color=\"red\">&#x3010;&#x67E5;&#x770B;&#x4F2A;&#x9759;&#x6001;&#x89C4;&#x5219;&#x3011;</font>", "rule")), $type1314, $op);
	if ($op == "setting") {
		$pluginvars = array();
		foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_11) {
			if (!strexists($_var_11["type"], "_")) {
				C::t("common_pluginvar")->update_by_variable($pluginid, $_var_11["variable"], array("type" => $_var_11["type"] . "_1314"));
			} else {
				$_var_12 = explode("_", $_var_11["type"]);
				if ($_var_12[1] == "1314") {
					$_var_11["type"] = $_var_12[0];
				} else {
					continue;
				}
			}
			$pluginvars[$_var_11["variable"]] = $_var_11;
		}
		$_var_13 = array("study_rewrite_radio", "dz_version", "study_rewrite_mod");
		if (!submitcheck("editsubmit")) {
			if ($pluginvars) {
				$op = "rewrite";
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op);
				showtableheader();
				$_var_14 = array();
				$_var_14 = s_showsettings($pluginvars, $_var_13);
				showsubmit("editsubmit");
				showtablefooter();
				showformfooter();
				echo implode('', $_var_14);
			}
		} else {
			$_var_15 = daddslashes(dstripslashes($_POST["varsnew"]));
			if (is_array($_var_15)) {
				foreach ($_var_15 as $_var_16 => $_var_17) {
					if (isset($pluginvars[$_var_16])) {
						if ($pluginvars[$_var_16]["type"] == "number") {
							$_var_17 = (double) $_var_17;
						} else {
							if (in_array($pluginvars[$_var_16]["type"], array("forums", "groups", "selects"))) {
								$_var_17 = addslashes(serialize($_var_17));
							}
						}
						DB::query("UPDATE " . DB::table("common_pluginvar") . " SET value='" . $_var_17 . "' WHERE pluginid='" . $pluginid . "' AND variable='" . $_var_16 . "'");
					}
				}
			}
			updatecache(array("plugin", "setting", "styles"));
			cpmsg("plugins_setting_succeed", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op, "succeed");
		}
	} else {
		$_var_18 = array();
		$_var_19 = study_rewritedata();
		$_var_18["{apache1}"] = $_var_18["{apache2}"] = $_var_18["{iis}"] = $_var_18["{iis7}"] = $_var_18["{zeus}"] = $_var_18["{nginx}"] = '';
		foreach ($_var_19["rulesearch"] as $_var_20 => $_var_21) {
			$_var_22 = "<font color=red>";
			if ($_var_20 == "plugin") {
				$_var_22 = "<font color=blue>";
			}
			$_var_23 = count($_var_19["rulevars"][$_var_20]) + 2;
			$_var_24 = array_keys($_var_19["rulevars"][$_var_20]);
			$_var_19["rulereplace"][$_var_20] = study_pvsort($_var_24, $_var_21, $_var_19["rulereplace"][$_var_20]);
			$_var_21 = str_replace($_var_24, $_var_19["rulevars"][$_var_20], addcslashes($_var_21, "?*+^\$.[]()|"));
			$_var_18["{apache1}"] = $_var_18["{apache1}"] . ($_var_22 . "RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n\t" . "RewriteRule ^(.*)/" . $_var_21 . "\$ \$1/" . study_pvadd($_var_19["rulereplace"][$_var_20]) . "&%1\n</font>");
			if ($_var_20 != "forum_archiver") {
				$_var_18["{apache2}"] = $_var_18["{apache2}"] . ($_var_22 . "RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n" . "RewriteRule ^" . $_var_21 . "\$ " . $_var_19["rulereplace"][$_var_20] . "&%1\n</font>");
			} else {
				$_var_18["{apache2}"] = $_var_18["{apache2}"] . ($_var_22 . "RewriteCond %{QUERY_STRING} ^(.*)\$" . "\n" . "RewriteRule ^archiver/" . $_var_21 . "\$ archiver/" . $_var_19["rulereplace"][$_var_20] . "&%1\n</font>");
			}
			$_var_18["{iis}"] = $_var_18["{iis}"] . ($_var_22 . "RewriteRule ^(.*)/" . $_var_21 . "(\\?(.*))*\$ \$1/" . addcslashes(study_pvadd($_var_19["rulereplace"][$_var_20]) . "&\$" . ($_var_23 + 1), ".?") . "\n</font>");
			$_var_18["{iis7}"] = $_var_18["{iis7}"] . ($_var_22 . "&lt;rule name=\"" . $_var_20 . "\"&gt;" . "\n\t\t\t" . "&lt;match url=\"^(.*/)*" . str_replace("\\.", ".", $_var_21) . "\\?*(.*)\$\" /&gt;" . "\n\t\t\t" . "&lt;action type=\"Rewrite\" url=\"{R:1}/" . str_replace(array("&", "page\\%3D"), array("&amp;amp;", "page%3D"), addcslashes(study_pvadd($_var_19["rulereplace"][$_var_20], 1) . "&{R:" . $_var_23 . "}", "?")) . "\" /&gt;" . "\n\t\t" . "&lt;/rule&gt;" . "\n</font>");
			$_var_18["{zeus}"] = $_var_18["{zeus}"] . ($_var_22 . "match URL into \$ with ^(.*)/" . $_var_21 . "\\?*(.*)\$" . "\n" . "if matched then" . "\n\t" . "set URL = \$1/" . study_pvadd($_var_19["rulereplace"][$_var_20]) . "&\$" . $_var_23 . "\nendif\n</font>");
			$_var_18["{nginx}"] = $_var_18["{nginx}"] . ($_var_22 . "rewrite ^([^\\.]*)/" . $_var_21 . "\$ \$1/" . stripslashes(study_pvadd($_var_19["rulereplace"][$_var_20])) . " last;\n</font>");
		}
		showtips($splugin_lang["rewrite_tip"]);
		echo str_replace(array_keys($_var_18), $_var_18, $splugin_lang["rewrite_message"]);
	}