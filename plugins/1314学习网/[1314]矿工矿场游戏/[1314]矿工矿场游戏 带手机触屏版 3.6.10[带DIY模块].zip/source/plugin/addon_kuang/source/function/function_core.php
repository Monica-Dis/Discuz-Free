<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_kuang_sortselect($_arg_0)
{
	global $_G;
	$_var_2 = array();
	foreach ($_arg_0 as $_var_3) {
		if ($_var_3["status"]) {
			if (empty($_var_3["parentid"])) {
				$_var_2[$_var_3["id"]]["name"] = $_var_3["name"];
				$_var_4[$_var_3["id"]] = true;
			}
		}
	}
	foreach ($_arg_0 as $_var_3) {
		if ($_var_3["status"]) {
			if (!empty($_var_3["parentid"]) && isset($_var_4[$_var_3["parentid"]])) {
				$_var_2[$_var_3["parentid"]]["sub"][$_var_3["id"]] = $_var_3["name"];
			}
		}
	}
	return $_var_2;
}
function addon_kuang_messagecutstr($_arg_0, $_arg_1 = 0, $_arg_2 = " ...")
{
	global $_G;
	$_var_4 = strpos($_arg_0, chr(0) . chr(0) . chr(0));
	if ($_var_4 !== false) {
		$_arg_0 = substr($_arg_0, 0, $_var_4);
	}
	$_var_5 = lang("forum/misc");
	loadcache(array("bbcodes_display", "bbcodes", "smileycodes", "smilies", "smileytypes", "domainwhitelist"));
	$_var_6 = "b|i|u|p|color|size|font|align|list|indent|float";
	$_var_7 = "email|code|free|table|tr|td|img|swf|flash|attach|media|audio|payto" . ($_G["cache"]["bbcodes_display"][$_G["groupid"]] ? "|" . implode("|", array_keys($_G["cache"]["bbcodes_display"][$_G["groupid"]])) : '');
	$_arg_0 = strip_tags(preg_replace(array("/\\[hide=?\\d*\\](.*?)\\[\\/hide\\]/is", "/\\[quote](.*?)\\[\\/quote]/si", $_var_5["post_edit_regexp"], "/\\[url=?.*?\\](.+?)\\[\\/url\\]/si", "/\\[(" . $_var_7 . ")=?.*?\\].+?\\[\\/\\1\\]/si", "/\\[(" . $_var_6 . ")=?.*?\\]/i", "/\\[\\/(" . $_var_6 . ")\\]/i"), array("[b]" . $_var_5["post_hidden"] . "[/b]", '', '', "\\1", '', '', ''), $_arg_0));
	if ($_arg_1) {
		$_arg_0 = cutstr($_arg_0, $_arg_1, $_arg_2);
	}
	$_arg_0 = preg_replace($_G["cache"]["smilies"]["searcharray"], '', $_arg_0);
	return trim($_arg_0);
}
function addon_add_log($_arg_0, $_arg_1 = array())
{
	global $_G;
	$_var_3 = array("uid" => $_arg_1["uid"] ? $_arg_1["uid"] : $_G["uid"], "username" => $_arg_1["username"] ? $_arg_1["username"] : $_G["username"], "info" => $_arg_0, "useip" => $_G["clientip"], "port" => $_G["remoteport"], "dateline" => $_G["timestamp"]);
	C::t("#addon_kuang#addon_kuang_log")->insert($_var_3);
}
function addon_kuang_get_qrcode($_arg_0)
{
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["addon_kuang"];
	$_arg_0 = str_replace("{ADDONVAR:ClientUrl}", $_G["siteurl"], $_arg_0);
	$_var_3 = addon_kuang_authkey($_arg_0);
	$_arg_0 = urlencode($_arg_0);
	$_var_4 = array("1" => "http://chart.googleapis.com/chart?cht=qr&chs=150x150&choe=UTF-8&chld=L|2&chl=", "2" => "https://chart.googleapis.com/chart?cht=qr&chs=150x150&choe=UTF-8&chld=L|2&chl=", "3" => "http://b.bshare.cn/barCode?site=weixin&url=", "4" => "http://qr.liantu.com/api.php?text=", "5" => "https://b.bshare.cn/barCode?site=weixin&url=", "6" => "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=", "7" => "plugin.php?id=addon_kuang&mod=qrcode&url=");
	$_var_5 = intval($_var_2["study_qrcode_api"]);
	$_var_6 = $_var_4[$_var_5] . $_arg_0;
	if ($_var_5 == 7) {
		$_var_6 = $_var_6 . ("&md5hash=" . $_var_3);
	}
	return $_var_6;
}
function addon_kuang_authkey($_arg_0)
{
	global $_G;
	return substr(md5(md5($_arg_0 . $_G["uid"] . $_G["authkey"]) . $_G["formhash"]), 8, 8);
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}