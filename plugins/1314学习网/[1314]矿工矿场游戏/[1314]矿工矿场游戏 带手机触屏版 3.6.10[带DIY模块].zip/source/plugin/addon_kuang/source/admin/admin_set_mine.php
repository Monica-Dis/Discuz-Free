<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function get_oretype_select($_arg_0, $_arg_1, $_arg_2, $_arg_3 = 0)
{
	$_var_4 = '';
	$_var_4 = $_var_4 . ("<select name=\"" . ($_arg_3 ? "neworetype[]" : "oretype[" . $_arg_2 . "]") . "\"><option value=\"0\">&#x8BF7;&#x9009;&#x62E9;&#x77FF;&#x77F3;&#x7C7B;&#x578B;</option>");
	foreach ($_arg_0 as $_var_5) {
		$_var_4 = $_var_4 . ("<option value=\"" . $_var_5["id"] . "\" " . ($_var_5["id"] == $_arg_1 ? "selected=\"selected\"" : '') . ">" . $_var_5["name"] . "</option>");
	}
	$_var_4 = $_var_4 . ("</select>");
	return $_var_4;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	$_var_11 = array("list", "edit", "group", "category");
	$op = in_array($_GET["op"], $_var_11) ? $_GET["op"] : "list";
	if ($op == "list") {
		if (!submitcheck("submit")) {
			s_shownav("sort", "sorts_admin");
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			showtableheader('');
			$_var_12 = $_var_13 = array();
			$_var_13 = C::t("#addon_kuang#addon_kuang_oretype")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x77FF;&#x573A;&#x540D;&#x5B57;", "&#x77FF;&#x77F3;&#x7C7B;&#x578B;", "&#x4E00;&#x4E2A;&#x77FF;&#x5DE5;&#x5355;&#x4F4D;&#x5468;&#x671F;&#x5185;&#x77FF;&#x77F3;&#x4EA7;&#x91CF;", "&#x72B6;&#x6001;", "&#x64CD;&#x4F5C;"));
			$_var_14 = C::t("#addon_kuang#addon_kuang_mine")->fetch_all_by_search(array(), array("displayorder" => "ASC", "id" => "ASC"));
			foreach ($_var_14 as $_var_15) {
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td28\"", " style=\"width:100px;\"", '', '', " style=\"width:100px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_15["id"] . "\" " . $_var_16 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_15["id"] . "]\" value=\"" . $_var_15["displayorder"] . "\" style=\"height: 20px;\">", "<input type=\"text\" name=\"name[" . $_var_15["id"] . "]\" value=\"" . dhtmlspecialchars($_var_15["name"]) . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">(id:" . $_var_15["id"] . ")", get_oretype_select($_var_13, $_var_15["oretype"], $_var_15["id"], 0), "<input type=\"text\" name=\"output[" . $_var_15["id"] . "]\" value=\"" . dhtmlspecialchars($_var_15["output"]) . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", $_var_15["status"] ? "<b style=\"color:green;\">&#x542F;&#x7528;</b>" : "<b style=\"color:red;\">&#x5173;&#x95ED;</b>", "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_15["id"] . "\" class=\"act\">" . cplang("edit") . "</a>"));
			}
			echo "<tr><td></td><td colspan=\"6\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">&#x6DFB;&#x52A0;&#x5206;&#x7C7B;</a></div></td></tr>";
			echo "<script type=\"text/JavaScript\">\r\n\r\n\t\tvar rowtypedata = new Array();\r\n\t\trowtypedata[0] = [\r\n\t\t\t\t\t[1, \"\"],\r\n\t\t\t\t\t[1,'<input type=\"text\" class=\"txt\" name=\"neworder[]\" style=\"height: 20px;\"/>', \"td25\"],\r\n\t\t\t\t\t[1, '<div><input type=\"text\" class=\"txt\" name=\"newname[]\" style=\"width: 150px;height: 20px;\"/><a href=\"javascript:;\" class=\"deleterow\" onClick=\"deleterow(this)\">" . cplang("delete") . "</a></div>', \"td28\"],\r\n\t\t\t\t\t[1, '" . get_oretype_select($_var_13, 0, $_var_15["id"], 1) . "'],\r\n\t\t\t\t\t[1, '<input type=\"text\" name=\"newoutput[]\" value=\"1\" class=\"txt\" style=\"width: 150px;height: 20px;\">'],\r\n\t\t\t\t\t[1, \"\"],\r\n\t\t\t\t\t[1, \"\"],\r\n\t\t\t\t];\r\n\t\t</script>";
			showsubmit("submit", "submit", "del");
			showtablefooter();
			showformfooter();
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_17) {
					$_var_17 = intval($_var_17);
					C::t("#addon_kuang#addon_kuang_mine")->delete_by_where(array("id" => $_var_17), true);
					C::t("#addon_kuang#addon_kuang_mining")->delete_by_where(array("mineid" => $_var_17), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_17 => $_var_18) {
					C::t("#addon_kuang#addon_kuang_mine")->update($_var_17, array("name" => $_POST["name"][$_var_17], "displayorder" => $_POST["order"][$_var_17], "output" => $_POST["output"][$_var_17], "oretype" => $_POST["oretype"][$_var_17]));
				}
			}
			if (is_array($_GET["newname"])) {
				foreach ($_GET["newname"] as $_var_19 => $_var_20) {
					if (!empty($_var_20)) {
						C::t("#addon_kuang#addon_kuang_mine")->insert(array("name" => $_var_20, "status" => 1, "displayorder" => $_GET["neworder"][$_var_19], "output" => $_GET["newoutput"][$_var_19], "oretype" => $_GET["neworetype"][$_var_19]), 1);
					}
				}
			}
			cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	} else {
		if ($op == "edit") {
			$_var_17 = intval($_GET["cid"]);
			if (!submitcheck("submit")) {
				$_var_15 = C::t("#addon_kuang#addon_kuang_mine")->fetch_by_search(array("id" => $_var_17));
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "&cid=" . $_var_17);
				showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
				s_showsetting("&#x5206;&#x7C7B;&#x540D;&#x79F0;", "name", $_var_15["name"], "text", '', '', '');
				s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", $_var_15["status"], "radio", '', '', '');
				s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", $_var_15["displayorder"], "number", '', '', '');
				showtableheader();
				showsubmit("submit", "submit");
				showformfooter();
			} else {
				$_var_21 = array("name" => $_POST["name"], "status" => dintval($_POST["status"]), "displayorder" => dintval($_POST["displayorder"]));
				C::t("#addon_kuang#addon_kuang_mine")->update($_var_17, $_var_21, 1);
				cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
			}
		}
	}