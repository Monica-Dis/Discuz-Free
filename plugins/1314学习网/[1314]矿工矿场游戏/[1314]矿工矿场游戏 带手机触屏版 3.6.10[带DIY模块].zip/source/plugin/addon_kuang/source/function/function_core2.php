<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_kuang_rewrite()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_kuang"];
	if ($_var_1["study_rewrite_radio"]) {
		$_var_2 = $_var_1["study_rewrite_mod"] ? $_var_1["study_rewrite_mod"] : "kuang-{mod}.html";
		$_G["setting"]["output"]["preg"]["search"]["addon_kuang_mod"] = "/<a([^\\>]*)href\\=\"(http:\\/\\/[^\"]*\\/)?kuang.php\\?mod\\=([a-z]+)\"([^\\>]*)\\>/";
		$_G["setting"]["output"]["preg"]["replace"]["addon_kuang_mod"] = "addon_kuang_rewriteoutput('" . $_var_2 . "','', '\\3', '', '\\4')";
		$_var_3 = false;
		$_var_4 = array("addon_kuang_mod");
		if ($_var_1["dz_version"] <= 1) {
			if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
				$_var_3 = true;
			} else {
				if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
					$_var_3 = true;
				}
			}
		} else {
			if ($_var_1["dz_version"] == 3) {
				$_var_3 = true;
			}
		}
		if ($_var_3) {
			foreach ($_var_4 as $_var_5 => $_var_6) {
				if (isset($_G["setting"]["output"]["preg"]["replace"][$_var_6])) {
					$_G["setting"]["output"]["preg"]["replace"][$_var_6] = preg_replace("/'\\\\([0-9]+)'/", "\$matches[\${1}]", $_G["setting"]["output"]["preg"]["replace"][$_var_6]);
				}
			}
		} else {
			foreach ($_var_4 as $_var_5 => $_var_6) {
				if (isset($_G["setting"]["output"]["preg"]["search"][$_var_6])) {
					$_G["setting"]["output"]["preg"]["search"][$_var_6] = $_G["setting"]["output"]["preg"]["search"][$_var_6] . "e";
				}
			}
		}
	}
}
function addon_kuang_rewriteoutput($_arg_0, $_arg_1, $_arg_2, $_arg_3, $_arg_4)
{
	global $_G;
	$_var_6 = array("{id}" => $_arg_1, "{mod}" => $_arg_2, "{page}" => $_arg_3 ? $_arg_3 : 1);
	$_var_7 = str_replace(array_keys($_var_6), $_var_6, $_arg_0);
	return "<a href=\"" . $_var_7 . "\"" . (!empty($_arg_4) ? stripslashes($_arg_4) : '') . ">";
}
function addon_kuang_check()
{
	$_var_0 = NULL;
}
function addon_kuang_cleardir($_arg_0)
{
}
function addon_kuang_deltree($_arg_0)
{
}
function addon_kuang_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		addon_kuang_rewrite();
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}