<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	$_var_11 = array("list", "add", "edit");
	$op = in_array($_GET["op"], $_var_11) ? $_GET["op"] : "list";
	$_var_12 = array();
	$_var_12 = C::t("#addon_kuang#addon_kuang_oretype")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
	if ($op == "list") {
		if (!submitcheck("submit")) {
			s_shownav("sort", "sorts_admin");
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			showtableheader('');
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x6C34;&#x6676;&#x5DE5;&#x5382;&#x540D;&#x79F0;", "&#x6C34;&#x6676;&#x5408;&#x6210;&#x89C4;&#x5219;", "&#x72B6;&#x6001;", "&#x64CD;&#x4F5C;"));
			$_var_13 = C::t("#addon_kuang#addon_kuang_formula")->fetch_all_by_search(array(), array("displayorder" => "ASC", "id" => "ASC"));
			foreach ($_var_13 as $_var_14) {
				$_var_15 = unserialize($_var_14["formula"]);
				$_var_14["formula"] = '';
				foreach ($_var_15 as $_var_16 => $_var_17) {
					if (!empty($_var_14["formula"])) {
						$_var_14["formula"] = $_var_14["formula"] . " + ";
					} else {
						$_var_14["formula"] = $_var_14["formula"] . ("1&#x5757;&#x6C34;&#x6676; = ");
					}
					$_var_14["formula"] = $_var_14["formula"] . ($_var_17 . "&#x5757;" . $_var_12[$_var_16]["name"]);
				}
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td28\"", '', " style=\"width:50px;\"", " style=\"width:50px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_14["id"] . "\" " . $_var_18 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_14["id"] . "]\" value=\"" . $_var_14["displayorder"] . "\" style=\"height: 20px;\">", "<input type=\"text\" name=\"name[" . $_var_14["id"] . "]\" value=\"" . dhtmlspecialchars($_var_14["name"]) . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">(id:" . $_var_14["id"] . ")", $_var_14["formula"], $_var_14["status"] ? "<b style=\"color:green;\">&#x542F;&#x7528;</b>" : "<b style=\"color:red;\">&#x5173;&#x95ED;</b>", "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_14["id"] . "\" class=\"act\">" . cplang("edit") . "</a>"));
			}
			echo "<tr><td></td><td colspan=\"4\"><div><a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=add&ac=" . $ac . "\" class=\"addtr\">&#x6DFB;&#x52A0;&#x6C34;&#x6676;&#x5DE5;&#x5382;</a></div></td></tr>";
			showsubmit("submit", "submit", "del");
			showtablefooter();
			showformfooter();
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_19) {
					$_var_19 = intval($_var_19);
					C::t("#addon_kuang#addon_kuang_formula")->delete_by_where(array("id" => $_var_19), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_19 => $_var_17) {
					C::t("#addon_kuang#addon_kuang_formula")->update($_var_19, array("name" => $_POST["name"][$_var_19], "displayorder" => $_POST["order"][$_var_19]));
				}
			}
			cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	} else {
		if ($op == "add") {
			$_var_19 = intval($_GET["cid"]);
			if (!submitcheck("submit")) {
				$_var_20 = C::t("#addon_kuang#addon_kuang_formula")->fetch_by_search(array("id" => $_var_19));
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "&cid=" . $_var_19);
				showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
				s_showsetting("&#x6C34;&#x6676;&#x5DE5;&#x5382;&#x540D;&#x79F0;", "name", '', "text", '', '', '');
				foreach ($_var_12 as $_var_17) {
					s_showsetting($_var_17["name"], "oretype[" . $_var_17["id"] . "]", '', "number", '', '', "&#x5408;&#x6210;&#x4E00;&#x4E2A;&#x6C34;&#x6676;&#x9700;&#x8981;&#x591A;&#x5C11;" . $_var_17["name"] . "&#xFF0C;&#x4E0D;&#x9700;&#x8981;" . $_var_17["name"] . "&#x7684;&#x8BDD;&#x4E3A;&#x7A7A;&#x6216;&#x8005;0");
				}
				s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", 1, "radio", '', '', '');
				s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", 0, "number", '', '', '');
				showtableheader();
				showsubmit("submit", "submit");
				showformfooter();
			} else {
				$_var_15 = array();
				foreach ($_POST["oretype"] as $_var_16 => $_var_17) {
					$_var_17 = intval($_var_17);
					if ($_var_17 > 0) {
						$_var_15[$_var_16] = $_var_17;
					}
				}
				if (empty($_var_15)) {
					$_POST["status"] = 0;
				}
				$_var_14 = serialize($_var_15);
				$_var_21 = array("name" => $_POST["name"], "formula" => $_var_14, "status" => $_POST["status"] ? 1 : 0, "displayorder" => dintval($_POST["displayorder"]));
				C::t("#addon_kuang#addon_kuang_formula")->insert($_var_21, 1);
				cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
			}
		} else {
			if ($op == "edit") {
				$_var_19 = intval($_GET["cid"]);
				if (!submitcheck("submit")) {
					$_var_14 = C::t("#addon_kuang#addon_kuang_formula")->fetch_by_search(array("id" => $_var_19));
					showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "&cid=" . $_var_19);
					showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
					s_showsetting("&#x6C34;&#x6676;&#x5DE5;&#x5382;&#x540D;&#x79F0;", "name", $_var_14["name"], "text", '', '', '');
					$_var_14["formula"] = unserialize($_var_14["formula"]);
					foreach ($_var_12 as $_var_17) {
						s_showsetting($_var_17["name"], "oretype[" . $_var_17["id"] . "]", $_var_14["formula"][$_var_17["id"]], "number", '', '', '');
					}
					s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", $_var_14["status"], "radio", '', '', '');
					s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", $_var_14["displayorder"], "number", '', '', '');
					showtableheader();
					showsubmit("submit", "submit");
					showformfooter();
				} else {
					$_var_15 = array();
					foreach ($_POST["oretype"] as $_var_16 => $_var_17) {
						$_var_17 = intval($_var_17);
						if ($_var_17 > 0) {
							$_var_15[$_var_16] = $_var_17;
						}
					}
					if (empty($_var_15)) {
						$_POST["status"] = 0;
					}
					$_var_14 = serialize($_var_15);
					$_var_21 = array("name" => $_POST["name"], "formula" => $_var_14, "status" => $_POST["status"] ? 1 : 0, "displayorder" => dintval($_POST["displayorder"]));
					C::t("#addon_kuang#addon_kuang_formula")->update($_var_19, $_var_21, 1);
					cpmsg($splugin_lang["slang_022"], "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
				}
			}
		}
	}