<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/discuz_version.php';
require_once DISCUZ_ROOT.'./source/plugin/'.$pluginarray['plugin']['identifier'].'/installlang.lang.php';
$request_url = str_replace('&step='.$_GET['step'],'',$_SERVER['QUERY_STRING']);
showsubmenusteps($pluginarray['plugin']['name'].$s_installlang[$operation].$s_installlang['ilang_001'], array(
	array($s_installlang['ilang_check'], !$_GET['step']),
	array($s_installlang['ilang_sql'], $_GET['step'] == 'sql'),
	array($s_installlang['ilang_stat'], $_GET['step'] == 'stat'),
	array($s_installlang['ilang_addon'], $_GET['step'] == 'addon'),
	array($s_installlang['ilang_ok'].$s_installlang[$operation], $_GET['step']=='ok'),
));
switch($_GET['step']){
	default:
	case 'check':
		$addonid = $pluginarray['plugin']['identifier'].'.plugin';
		$array = cloudaddons_getmd5($addonid);
		if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
			
			
		}
		cpmsg($s_installlang['ilang_check_ok'], "{$request_url}&step=sql", 'loading', array('operation' => $s_installlang[$operation]));
		break;
	case 'sql':
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_formula` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `formula` text NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `displayorder` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_log` (
  `id` int(10) NOT NULL auto_increment,
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `username` char(15) NOT NULL,
  `info` text NOT NULL,
  `useip` varchar(15) NOT NULL,
  `port` smallint(6) unsigned NOT NULL default '0',
  `dateline` int(19) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_member` (
  `id` int(10) NOT NULL auto_increment,
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `username` char(15) NOT NULL,
  `house` int(10) NOT NULL default '0',
  `miner` int(10) NOT NULL default '0',
  `crystal` int(10) NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`),
  KEY `house` (`house`),
  KEY `miner` (`miner`),
  KEY `crystal` (`crystal`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_member_count` (
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `oretype` int(10) unsigned NOT NULL default '0',
  `number` int(10) NOT NULL default '0',
  KEY `uid` (`uid`),
  KEY `uid_2` (`uid`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_mine` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `oretype` int(10) unsigned NOT NULL default '0',
  `output` int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  `displayorder` int(10) NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_mining` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mineid` int(10) unsigned NOT NULL default '0',
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `username` char(15) NOT NULL,
  `miner` int(10) unsigned NOT NULL default '0',
  `useip` varchar(15) NOT NULL,
  `port` smallint(6) unsigned NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`),
  KEY `mineid` (`mineid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_oretype` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` char(30) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `ore2credit` int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) NOT NULL default '0',
  `displayorder` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `displayorder` (`displayorder`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_withdraw_channel` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` char(30) NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `displayorder` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_addon_kuang_withdraw_record` (
  `id` int(10) NOT NULL auto_increment,
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `username` char(15) NOT NULL,
  `channelid` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `crystal` int(10) NOT NULL,
  `money` int(10) NOT NULL default '0',
  `remark` text NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `useip` varchar(15) NOT NULL,
  `port` smallint(6) unsigned NOT NULL default '0',
  `dateline` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `uid` (`uid`),
  KEY `status` (`status`),
  KEY `channelid` (`channelid`)
) ENGINE=MyISAM;
EOF;
		runquery($sql);
		
		$result = array();
		$result = C::t('#addon_kuang#addon_kuang_oretype')->fetch_by_search();
		if(empty($result)){
			$sql = <<<EOF
INSERT INTO `pre_addon_kuang_oretype` (`id`, `name`, `icon`, `ore2credit`, `status`, `displayorder`) VALUES
(1, '$installlang[ilang_001]', 'source/plugin/addon_kuang/images/tie.png', 10000, 1, 1),
(2, '$installlang[ilang_002]', 'source/plugin/addon_kuang/images/tong.png', 1000, 1, 2),
(3, '$installlang[ilang_003]', 'source/plugin/addon_kuang/images/yin.png', 10, 1, 3),
(4, '$installlang[ilang_004]', 'source/plugin/addon_kuang/images/jin.png', 1, 1, 4);
INSERT INTO `pre_addon_kuang_mine` (`id`, `name`, `oretype`, `output`, `status`, `displayorder`, `dateline`) VALUES
(1, '$installlang[ilang_005]', 1, 100, 1, 1, 0),
(2, '$installlang[ilang_006]', 2, 50, 1, 2, 0),
(3, '$installlang[ilang_007]', 3, 10, 1, 3, 0),
(4, '$installlang[ilang_008]', 4, 1, 1, 4, 0),
(5, '$installlang[ilang_009]', 4, 1, 1, 5, 0),
(6, '$installlang[ilang_010]', 2, 30, 1, 6, 0);
INSERT INTO `pre_addon_kuang_formula` (`id`, `name`, `formula`, `status`, `displayorder`) VALUES
(1, '$installlang[ilang_011]', 'a:4:{i:1;i:300;i:2;i:300;i:3;i:300;i:4;i:50;}', 1, 1),
(2, '$installlang[ilang_012]', 'a:4:{i:1;i:300;i:2;i:300;i:3;i:500;i:4;i:20;}', 1, 2),
(3, '$installlang[ilang_013]', 'a:4:{i:1;i:1000;i:2;i:500;i:3;i:100;i:4;i:10;}', 1, 3);
INSERT INTO `pre_addon_kuang_withdraw_channel` (`id`, `name`, `status`, `displayorder`) VALUES
(1, '$installlang[ilang_014]', 1, 1),
(2, '$installlang[ilang_015]', 1, 2),
(3, '$installlang[ilang_016]', 1, 3),
(4, '$installlang[ilang_017]', 1, 4),
(5, '$installlang[ilang_018]', 1, 5);
EOF;
			runquery($sql);
		}
		
		if(!C::t('common_block_style')->fetch_all_by_blockclass('study_addonkuanglog')) {
			
			$arr = array(
				'name' => '[1314]'.$installlang['ilang_019'],
				'blockclass' => 'study_addonkuanglog',
			);
			$template = '<div class="module cl xl xl1 addon_kuang_list_lh" style="height:200px;">
<ul>
[loop]
<li><a href="home.php?mod=space&uid={authorid}" c="1"" title="{author}"{target}>{author}</a>: {title}</li>
[/loop]
</ul>
</div>
<link type="text/css" href="source/plugin/addon_kuang/images/diy.css" rel="stylesheet" />
<script type="text/javascript" src="source/plugin/addon_kuang/images/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="source/plugin/addon_kuang/images/scroll.js"></script>
<script type="text/javascript">
ADDON_KUANG(function(){
	ADDON_KUANG("div.addon_kuang_list_lh").myScroll({
		speed:40,
		rowHeight:18
	});
});
</script>';
			include_once libfile('function/block');
			block_parse_template($template, $arr);
			C::t('common_block_style')->insert($arr);
			require_once libfile('function/cache');
			updatecache('blockclass');
		}
		
		cpmsg($s_installlang['ilang_sql_ok'], "{$request_url}&step=stat", 'loading', array('operation' => $s_installlang[$operation]));
		break;
	case 'stat':
		$_statInfo = array();
		$_statInfo['pluginName'] = $pluginarray['plugin']['identifier'];
		$_statInfo['pluginVersion'] = $pluginarray['plugin']['version'];
		$_statInfo['bbsVersion'] = DISCUZ_VERSION;
		$_statInfo['bbsRelease'] = DISCUZ_RELEASE;
		$_statInfo['timestamp'] = TIMESTAMP;
		$_statInfo['bbsUrl'] = $_G['siteurl'];
		$_statInfo['SiteUrl'] = $_G['siteurl'];
		$_statInfo['ClientUrl'] = $_G['siteurl'];
		$_statInfo['SiteID'] = '';
		$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
		$_statInfo['action'] = str_replace('plugin', '', $operation);
		$_statInfo['genuine'] = splugin_genuine($pluginarray['plugin']['identifier']);
		$_statInfo = base64_encode(serialize($_statInfo));
		$_md5Check = md5($_statInfo);
		$StatUri = 'http://ww'.'w.zz'.'b'.'7.net/s'.'ta'.'t.p'.'hp';
		$_StatUrl = $StatUrl.'?info='.$_statInfo.'&md5check='.$_md5Check;
		$code =  "<script src=\"".$_StatUrl."\" type=\"text/javascript\"></script>";
		cpmsg($s_installlang['ilang_stat_ok'], "{$request_url}&step=addon", 'loading', array('operation' => $s_installlang[$operation], 'stat_code' => $code));
		break;
	case 'addon':
		$available = dfsockopen('http://ww'.'w.zz'.'b'.'7.net/api/available.php?siteurl='.rawurlencode($_G['siteurl']).'&identifier='.$identifier, 0, '', '', FALSE, '', 5);
		if($available == 'succeed'){
			$_statInfo = array();
			$_statInfo['pluginName'] = $pluginarray['plugin']['identifier'];
			$_statInfo['bbsVersion'] = DISCUZ_VERSION;
			$_statInfo['bbsUrl'] = $_G['siteurl'];
			$_statInfo['action'] = str_replace('plugin', '', $operation);
			$_statInfo['nextUrl'] = ADMINSCRIPT.'?'.$request_url;
			$_statInfo = base64_encode(serialize($_statInfo));
			$_md5Check = md5($_statInfo);
			$StatUrl = 'http'.($_G['isHTTPS'] ? 's' : '').'://www.z'.'z'.'b7.net/api/outer_addon.php';
			$_StatUrl = $StatUrl.'?type=js&info='.$_statInfo.'&md5check='.$_md5Check;
			echo '<script type="text/javascript">location.href="'.$_G['siteurl'].ADMINSCRIPT.'?'.$request_url.'&step=ok";</script>';
		}
		splugin_updatecache($pluginarray['plugin']['identifier']);
		break;
	case 'ok':
		$finish = TRUE;
		break;
}






































































