<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net timestamp 1554289201
 * Ӧ���ۺ����⣺http://www.di'.'szz.net/ser'.'vices.php?mod=issue
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
    exit('');
}

require_once libfile('function/core', 'plugin/addon_kuang/source');

$splugin_setting = $_G['cache']['plugin']['addon_kuang'];
$splugin_setting['0'] = array('0' => '2018091117LQ2xdantqc', '1' => '43755','2' => '1554289201', '3' => 'http://127.0.0.1/', '4' => 'http://127.0.0.1/', '5' => '', '6' => '', '7' => '');
$splugin_lang = lang('plugin/addon_kuang');
$groups_admin = (array)unserialize($splugin_setting['groups_admin']);
$groups_normal = (array)unserialize($splugin_setting['groups_normal']);
$splugin_setting['extid'] = min(max($splugin_setting['extid'], 1), 8);
//$_G['setting']['allowwidthauto'] = 1;
//$_G['setting']['switchwidthauto'] = 0;
$modarray = array('index', 'mining', 'compound', 'buy', 'exchange', 'withdraw', 'log', 'qrcode');

if($_G['cache']['plugin']['addon_kuang_rob']['radio']){
	$modarray[] = 'rob';
}

$mod = in_array($_GET['mod'], $modarray) ? $_GET['mod'] : 'index';


if($mod == 'compound' && !$splugin_setting['crystal_radio']){
	$mod = 'index';	
}elseif($mod == 'withdraw' && !$splugin_setting['withdraw_radio']){
	$mod = 'index';	
}

$mod_class[$mod] = ' class="on"';

if($_G['uid']){
	$kuang_member = C::t('#addon_kuang#addon_kuang_member')->fetch_by_search(array('uid' => $_G['uid']));
	if(!$kuang_member){
		  $kuang_member = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'house' => intval($splugin_setting['new_house']),
        'miner' => min($splugin_setting['new_house']*$splugin_setting['house_miner'], $splugin_setting['new_miner']),
        'status' => 1,
        'dateline' => $_G['timestamp'],
	    );
	    C::t('#addon_kuang#addon_kuang_member')->insert($kuang_member);
	    if($kuang_member['miner'] > 0){
	    	addon_add_log(str_replace(array('{house}', '{miner}'), array($kuang_member['house'], $kuang_member['miner']), $splugin_lang['slang_054']));
	    }elseif($kuang_member['house'] > 0){
	    	addon_add_log(str_replace(array('{house}'), array($kuang_member['house']), $splugin_lang['slang_055']));
	    }else{
	    	addon_add_log($splugin_lang['slang_056']);
	    }
	}else{
		if($kuang_member['status'] != 1){
			showmessage(str_replace(':', '&#58;', $splugin_setting['forbid_msg']));
		}
	}
	$member_count = array();
	$member_count = C::t('#addon_kuang#addon_kuang_member_count')->fetch_all_by_search(array('uid' => $_G['uid']));
	getuserprofile('extcredits'.$splugin_setting['extid']);
}

$oretypelist = C::t('#addon_kuang#addon_kuang_oretype')->fetch_all_by_search(array('status' => 1), array('displayorder' => 'ASC', 'id' => 'ASC'));

$minelist = C::t('#addon_kuang#addon_kuang_mine')->fetch_all_by_search(array('status' => 1), array('displayorder' => 'ASC', 'id' => 'ASC'));

$mininglist = $miningquery = array();
$miningquery = C::t('#addon_kuang#addon_kuang_mining')->fetch_all_by_search(array('uid' => $_G['uid']));
foreach($miningquery as $value){
	$mininglist[$value['mineid']] = $value;
}

$kuang_member['work_miner'] = 0;
foreach($minelist as $key => $mine){
	$mine['miner'] = intval($mininglist[$mine['id']]['miner']);
	$cycle = floor(($_G['timestamp'] - $mininglist[$mine['id']]['dateline'])/($splugin_setting['cycle']*3600));
	if($splugin_setting['limit'] > 0){
    	$cycle = min($splugin_setting['limit'], $cycle);
    }
	$mine['kuang'] = $mine['miner'] ? $cycle*$mine['output']*$mininglist[$mine['id']]['miner'] : 0;
	$mine['updatetime'] = dgmdate(intval($mininglist[$mine['id']]['dateline']), 'm-d H:i', $_G['setting']['timeoffset']);
	$minelist[$key] = $mine;
	$kuang_member['work_miner'] += $mine['miner'];
}

$kuang_member['extcredits']['name'] = $_G['setting']['extcredits'][$splugin_setting['extid']]['title'];
$kuang_member['extcredits']['number'] = $_G['member']['extcredits'.$splugin_setting['extid']];

if($splugin_setting['study_rewrite_radio']){
	include_once libfile('function/core2', 'plugin/addon_kuang/source');
}

include_once libfile('module/'.$mod, 'plugin/addon_kuang/source');


function addon_kuang_showmessage($message, $url = '', $focusid = ''){
	if($_GET['s_in_mobile']){
		echo "<script>";
		if(!empty($focusid)){
			echo "parent.$('{$focusid}').focus();";
		}
		echo "parent.showPrompt(null, null, '<span>{$message}</span>', ".( $url ? "1000, function(){parent.location.href='{$url}';}" : "3000").");";
		echo "</script>";
		exit;
	}else{
		showmessage($message, $url);
	}
}

