function $(id) {
	return !id ? null : document.getElementById(id);
}

function showPrompt(ctrlid, evt, msg, timeout, func) {
	var menuid = ctrlid ? ctrlid + '_pmenu' : 'ntcwin';
	var duration = timeout ? 0 : 3;
	if(document.getElementById(menuid)) {
		document.getElementById(menuid).parentNode.removeChild($(menuid));
	}
	
	var div = document.createElement('div');
	div.id = menuid;
	div.className = menuid;
	document.getElementById('append_parent').appendChild(div);
	div.innerHTML = msg;
	div.style.left = parseInt((jQuery(window).width() - jQuery('#'+menuid).width()) / 2) + 'px';
	div.style.top = parseInt(jQuery(window).scrollTop() + (jQuery(window).height() - jQuery('#'+menuid).height()) / 2) + 'px';
	jQuery('#'+menuid).click(function(){document.getElementById(menuid).style.display = 'none';});
	setTimeout(function() { div.style.display = 'none'; if(func){func();}}, timeout);
}
