function $(id) {
	return !id ? null : document.getElementById(id);
}

function attachimglst(pid, op, islazy) {
	if(!op) {
		$('imagelist_' + pid).style.display = 'none';
		$('imagelistthumb_' + pid).style.display = '';
	} else {
		$('imagelistthumb_' + pid).style.display = 'none';
		$('imagelist_' + pid).style.display = '';
	}
	doane();
}


function strCounter(message){
	if(message.value.length <= 0){
		$('submit_post').className = "submit_post disabled";
		$('submit_post').disabled = "true";
		$("count_num").innerHTML = 140;
	}else{
		if (message.value.length > 140){
			message.value = message.value.substring(0, 140);
		}else{
			$("count_num").innerHTML = 140 - message.value.length;
		}
		$('submit_post').className = "submit_post";
		$('submit_post').disabled = "";
	}
}

function addon_kuang_HoverLi(m, n, counter, showclass){
  for(var i=0;i < counter;i++){
      $('addon_kuang_tab_t'+m+i).className = 'tab_t_unhover';
      $('addon_kuang_tab_m'+m+i).className = 'undis';
  }
  $('addon_kuang_tab_t'+m+n).className = 'tab_t_hover';
  $('addon_kuang_tab_m'+m+n).className = showclass;
}