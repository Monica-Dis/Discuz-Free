<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From www.1314study.com
 * Ӧ���ۺ����⣺http://www.discuz.1314study.com/services.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://www.discuz.1314study.com/services.php?mod=ask&sid=2
 * ���ο������ƣ�http://www.discuz.1314study.com/services.php?mod=ask&sid=22
 */

define('APPTYPEID', 127);
define('CURSCRIPT', 'plugin');


require './source/class/class_core.php';

$discuz = C::app();

$cachelist = array('plugin', 'diytemplatename');

$discuz->cachelist = $cachelist;
$discuz->init();
 
$_GET['id'] = 'addon_kuang';
if(!empty($_GET['id'])) {
	list($identifier, $module) = explode(':', $_GET['id']);
	$module = $module !== NULL ? $module : $identifier;
} else {
	showmessage('plugin_nonexistence');
}
$mnid = 'plugin_'.$identifier.'_'.$module;
$pluginmodule = isset($_G['setting']['pluginlinks'][$identifier][$module]) ? $_G['setting']['pluginlinks'][$identifier][$module] : (isset($_G['setting']['plugins']['script'][$identifier][$module]) ? $_G['setting']['plugins']['script'][$identifier][$module] : array('adminid' => 0, 'directory' => preg_match("/^[a-z]+[a-z0-9_]*$/i", $identifier) ? $identifier.'/' : ''));

if(!preg_match('/^[\w\_]+$/', $identifier)) {
	showmessage('plugin_nonexistence');
}

if(empty($identifier) || !preg_match("/^[a-z0-9_\-]+$/i", $module) || !in_array($identifier, $_G['setting']['plugins']['available'])) {
	showmessage('plugin_nonexistence');
} elseif($pluginmodule['adminid'] && ($_G['adminid'] < 1 || ($_G['adminid'] > 0 && $pluginmodule['adminid'] < $_G['adminid']))) {
	showmessage('plugin_nopermission');
} elseif(@!file_exists(DISCUZ_ROOT.($modfile = './source/plugin/'.$pluginmodule['directory'].$module.'.inc.php'))) {
	showmessage('plugin_module_nonexistence', '', array('mod' => $modfile));
} 

define('CURMODULE', $identifier);
runhooks();

include DISCUZ_ROOT.$modfile;

?>