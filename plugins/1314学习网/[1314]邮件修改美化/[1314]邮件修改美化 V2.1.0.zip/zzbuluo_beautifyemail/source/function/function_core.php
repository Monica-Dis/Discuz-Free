<?php

function zzbuluo_beautifyemail_fun()
{
	$_var_0 = '';
	global $_G;
	$_var_2 = $_G["cache"]["plugin"]["zzbuluo_beautifyemail"];
	if ($_var_2["study_table"]) {
		$_var_3 = '';
		$_var_3 = $_var_3 . ($_var_2["color"] ? "background-color: " . $_var_2["color"] . ";" : "background-color: #ff5a18;");
		$_var_3 = $_var_3 . ($_var_2["hide_title"] ? "position: relative;top: -25px;" : '');
		$_var_3 = $_var_3 . ($_var_2["hide_title"] ? "border-top-left-radius: 5px;border-top-right-radius: 5px;" : '');
		foreach ($_var_2 as $_var_4 => $_var_5) {
			if (!in_array($_var_4, array("study_table", "color", "hide_title", "get_passwd_subject", "email_verify_subject", "email_register_subject", "birthday_subject", "email_to_friend_subject", "email_to_invite_subject", "adv_expiration_subject"))) {
				$_var_6[$_var_4] = "<table cellspacing=\"1\" cellpadding=\"1\" border=\"0\" style=\"" . $_var_3 . "width: 100%;\"><tr><td style=\"height:50px;text-align:center;\"><span style=\"font-weight: bold; font-size: 22px; color: white;\">{bbname}</span></td></tr><tr><td style=\"padding: 15px;background-color: white;\">" . $_var_5 . "</td></tr></table>";
			}
		}
		$_G["setting"]["welcomemsgtxt"] = "<table cellspacing=\"1\" cellpadding=\"1\" border=\"0\" style=\"" . $_var_3 . "width: 100%;\"><tr><td style=\"height:50px;text-align:center;\"><span style=\"font-weight: bold; font-size: 22px; color: white;\">{bbname}</span></td></tr><tr><td style=\"padding: 15px;background-color: white;\">" . $_G["setting"]["welcomemsgtxt"] . "</td></tr></table>";
	} else {
		foreach ($_var_2 as $_var_4 => $_var_5) {
			if (!in_array($_var_4, array("study_table", "color", "hide_title"))) {
				$_var_6[$_var_4] = $_var_5;
			}
		}
	}
	$_G["lang"]["email"] = array_merge($_G["lang"]["email"], $_var_6);
	$_G["hooklang"]["email"] = true;
	return $_var_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}