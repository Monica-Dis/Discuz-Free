<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From dism.zzb7-net
 * Ӧ���ۺ����⣺http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=2
 * ���ο������ƣ�http://d'.'is'.'m.tao'.'ba'.'o.com/ser'.'vices.php?mod=ask&sid=22
 */

if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$cachekey = 'scache_'.$pluginarray['plugin']['identifier'];
loadcache($cachekey);
$cachevalue = $_G['cache'][$cachekey];

if($operation == 'import' && empty($license)){
	$license = dfsockopen('http://d'.'is'.'m.tao'.'ba'.'o.com/api/license.php?siteurl='.rawurlencode($_G['siteurl']).'&identifier='.$identifier, 0, '', '', false, '', 5);$cachevalue['license'] = 1;savecache($cachekey, $cachevalue);
	if(empty($_GET['license']) && $license) {
		$installtype = $_GET['installtype'];
		$dir = $_GET['dir'];
		require_once libfile('function/discuzcode');
		$pluginarray['license'] = discuzcode(strip_tags($pluginarray['license']), 1, 0);
		echo '<div class="infobox"><h4 class="infotitle2">'.$pluginarray['plugin']['name'].' '.$pluginarray['plugin']['version'].' '.$lang['plugins_import_license'].'</h4><div style="text-align:left;line-height:25px;">'.$license.'</div><br /><br /><center>'.
			'<button onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=import&dir='.$dir.'&installtype='.$installtype.'&license=yes&formhash='.FORMHASH.'\'">'.$lang['plugins_import_agree'].'</button>&nbsp;&nbsp;'.
			'<button onclick="location.href=\''.ADMINSCRIPT.'?action=plugins\'">'.$lang['plugins_import_pass'].'</button></center></div>';
		exit;
	}
}

$addonid = $pluginarray['plugin']['identifier'].'.plugin';
$array = cloudaddons_getmd5($addonid);
	$cachevalue['check'] = $pluginarray['plugin']['identifier'];
	savecache($cachekey, $cachevalue);