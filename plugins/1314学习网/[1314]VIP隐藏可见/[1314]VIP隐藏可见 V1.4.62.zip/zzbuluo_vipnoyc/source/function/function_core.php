<?php

function zzbuluo_vipnoyc_discuzcode($_arg_0)
{
	global $_G;
	if ($_arg_0["caller"] == "discuzcode") {
		if ($_arg_0["param"][3] > 10 || $_arg_0["param"][1] > 1 && $_arg_0["param"][2] > 1) {
			return NULL;
		}
		$_var_2 = $_G["cache"]["plugin"]["zzbuluo_vipnoyc"];
		$_var_3 = (array) unserialize($_var_2["study_fids"]);
		$_var_4 = (array) unserialize($_var_2["study_gids"]);
		if (in_array($_G["fid"], $_var_3) && in_array($_G["groupid"], $_var_4)) {
			$_var_5 = strtolower($_G["discuzcodemessage"]);
			if (strpos($_var_5, "[hide") !== false) {
				if ($_var_2["hide_all_radio"]) {
					if (strpos($_var_5, "[hide=d") !== false) {
						$_G["discuzcodemessage"] = preg_replace("/\\[hide=(d\\d+)?[,]?(\\d+)?\\]\\s*(.*?)\\s*\\[\\/hide\\]/is", "<div class=\"showhide\"><h4>" . $_var_2["showhidemsg"] . "</h4>\\3</div>", $_G["discuzcodemessage"]);
					}
					if (strpos($_var_5, "[hide=") !== false) {
						$_G["discuzcodemessage"] = preg_replace("/\\[hide=(\\d+)\\]\\s*(.*?)\\s*\\[\\/hide\\]/is", "<div class=\"showhide\"><h4>" . $_var_2["showhidemsg"] . "</h4>\\2</div>", $_G["discuzcodemessage"]);
					}
				}
				$_G["discuzcodemessage"] = preg_replace("/\\[hide\\]\\s*(.*?)\\s*\\[\\/hide\\]/is", "<div class=\"showhide\"><h4>" . $_var_2["showhidemsg"] . "</h4>\\1</div>", $_G["discuzcodemessage"]);
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}