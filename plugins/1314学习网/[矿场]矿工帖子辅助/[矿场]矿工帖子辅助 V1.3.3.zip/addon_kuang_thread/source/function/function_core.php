<?php

function addon_kuang_thread_addlog($_arg_0, $_arg_1 = array())
{
	global $_G;
	$_var_3 = array("uid" => $_arg_1["uid"] ? $_arg_1["uid"] : $_G["uid"], "username" => $_arg_1["username"] ? $_arg_1["username"] : $_G["username"], "info" => $_arg_0, "useip" => $_G["clientip"], "port" => $_G["remoteport"], "dateline" => $_G["timestamp"]);
	C::t("#addon_kuang#addon_kuang_log")->insert($_var_3);
}
function addon_kuang_thread_posttop()
{
	global $_G;
	$_var_1 = '';
	$_var_2 = $_G["cache"]["plugin"]["addon_kuang"];
	if (!empty($_var_2)) {
		$_var_3 = array();
		$_var_3 = C::t("#addon_kuang_thread#addon_kuang_thread_formula")->fetch_by_search(array("groupid" => $_G["groupid"]));
		if (!empty($_var_3)) {
			$_var_3["formula"] = unserialize($_var_3["formula"]);
			if (!empty($_var_3["formula"])) {
				$_var_3["formula_text"] = '';
				$_var_3["thread"] = '';
				$_var_4 = array();
				$_var_5 = C::t("#addon_kuang#addon_kuang_member")->fetch_by_search(array("uid" => $_G["uid"]));
				if (!$_var_5) {
					$_var_5 = array("uid" => $_G["uid"], "username" => $_G["username"], "house" => intval($_var_2["new_house"]), "miner" => min($_var_2["new_house"] * $_var_2["house_miner"], $_var_2["new_miner"]), "status" => 1, "dateline" => $_G["timestamp"]);
					C::t("#addon_kuang#addon_kuang_member")->insert($_var_5);
					if ($_var_5["miner"] > 0) {
						addon_kuang_thread_addlog(str_replace(array("{house}", "{miner}"), array($_var_5["house"], $_var_5["miner"]), lang("plugin/addon_kuang", "slang_054")));
					} else {
						if ($_var_5["house"] > 0) {
							addon_kuang_thread_addlog(str_replace(array("{house}"), array($_var_5["house"]), lang("plugin/addon_kuang", "slang_055")));
						} else {
							addon_kuang_thread_addlog(lang("plugin/addon_kuang", "slang_056"));
						}
					}
				} else {
					$_var_4 = C::t("#addon_kuang#addon_kuang_member_count")->fetch_all_by_search(array("uid" => $_G["uid"]));
				}
				$_var_6 = C::t("#addon_kuang#addon_kuang_oretype")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
				foreach ($_var_3["formula"] as $_var_7 => $_var_8) {
					if (!empty($_var_3["formula_text"])) {
						$_var_3["formula_text"] = $_var_3["formula_text"] . " + ";
					}
					$_var_3["formula_text"] = $_var_3["formula_text"] . ("<span style=\"color:red;font-weight: 600;\">" . $_var_8 . lang("plugin/addon_kuang", "slang_033") . "</span>" . $_var_6[$_var_7]["name"] . ($_var_6[$_var_7]["icon"] ? " <img src=\"" . $_var_6[$_var_7]["icon"] . "\" width=\"15\" height=\"15\"/>" : ''));
					$_var_3["thread"] = $_var_3["thread"] === '' ? floor($_var_4[$_var_7]["number"] / $_var_8) : min($_var_3["thread"], floor($_var_4[$_var_7]["number"] / $_var_8));
				}
				$_var_3["thread"] = intval($_var_3["thread"]);
				$_var_1 = "<p class=\"tbms mbm\">&#x4F60;&#x7684;&#x7528;&#x6237;&#x7EC4;&#x5728;&#x8BE5;&#x677F;&#x5757;&#x53D1;&#x5E16;&#x9700;&#x8981;&#x6D88;&#x8017; " . $_var_3["formula_text"] . ($_var_3["thread"] < 1 ? "&#xFF0C;&#x4F60;&#x7684;&#x77FF;&#x77F3;&#x4E0D;&#x8DB3;&#x65E0;&#x6CD5;&#x53D1;&#x5E16;&#xFF0C;&#x8BF7;&#x8FDB;&#x5165; <a href=\"kuang.php\" target=\"_blank\" style=\"color: #0C0CF5;\">&#x793E;&#x533A;&#x77FF;&#x573A;</a> &#x91C7;&#x77FF;</p>" : '');
				if (defined("IN_MOBILE")) {
					$_var_1 = $_var_1 . "<style>.tbms {padding: 10px;border: 1px dashed #FF9A9A;}</style>";
				}
			}
		}
	}
	return $_var_1;
}
function addon_kuang_thread_topicsubmit()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_kuang"];
	if (!empty($_var_1)) {
		$_var_2 = array();
		$_var_2 = C::t("#addon_kuang_thread#addon_kuang_thread_formula")->fetch_by_search(array("groupid" => $_G["groupid"]));
		if (!empty($_var_2)) {
			$_var_2["formula"] = unserialize($_var_2["formula"]);
			if (!empty($_var_2["formula"])) {
				$_var_2["formula_text"] = '';
				$_var_2["thread"] = '';
				$_var_3 = array();
				$_var_3 = C::t("#addon_kuang#addon_kuang_member_count")->fetch_all_by_search(array("uid" => $_G["uid"]));
				$_var_4 = C::t("#addon_kuang#addon_kuang_oretype")->fetch_all_by_search(array("status" => 1), array("displayorder" => "ASC", "id" => "ASC"));
				foreach ($_var_2["formula"] as $_var_5 => $_var_6) {
					if (!empty($_var_2["formula_text"])) {
						$_var_2["formula_text"] = $_var_2["formula_text"] . " + ";
					}
					$_var_2["formula_text"] = $_var_2["formula_text"] . ("<span style=\"color:red;font-weight: 600;\">" . $_var_6 . lang("plugin/addon_kuang", "slang_033") . "</span>" . $_var_4[$_var_5]["name"] . ($_var_4[$_var_5]["icon"] ? " <img src=\"" . $_var_4[$_var_5]["icon"] . "\" width=\"15\" height=\"15\"/>" : ''));
					$_var_2["thread"] = $_var_2["thread"] === '' ? floor($_var_3[$_var_5]["number"] / $_var_6) : min($_var_2["thread"], floor($_var_3[$_var_5]["number"] / $_var_6));
				}
				$_var_2["thread"] = intval($_var_2["thread"]);
				if ($_var_2["thread"] < 1) {
					$_var_7 = str_replace(":", "&#58;", "<p class=\"tbms mbm\">&#x4F60;&#x7684;&#x7528;&#x6237;&#x7EC4;&#x5728;&#x8BE5;&#x677F;&#x5757;&#x53D1;&#x5E16;&#x9700;&#x8981;&#x6D88;&#x8017; " . $_var_2["formula_text"] . "&#xFF0C;&#x4F60;&#x7684;&#x77FF;&#x77F3;&#x4E0D;&#x8DB3;&#x65E0;&#x6CD5;&#x53D1;&#x5E16;&#xFF0C;&#x8BF7;&#x8FDB;&#x5165; <a href=\"kuang.php\" target=\"_blank\" style=\"color: #0C0CF5;\">&#x793E;&#x533A;&#x77FF;&#x573A;</a> &#x91C7;&#x77FF;</p>");
					showmessage($_var_7);
				} else {
					$_var_8 = 0;
					$_var_9 = array();
					foreach ($_var_2["formula"] as $_var_5 => $_var_6) {
						if ($_var_6 > 0) {
							$_var_10 = $_var_6;
							$_var_8 = $_var_8 + $_var_10;
							$_var_9[] = $_var_10 . lang("plugin/addon_kuang", "slang_059") . $_var_4[$_var_5]["name"];
							DB::query("UPDATE " . DB::table("addon_kuang_member_count") . " SET number = number - '" . $_var_10 . "' WHERE uid='" . $_G["uid"] . "' AND oretype='" . $_var_5 . "'", "UNBUFFERED");
						}
					}
					if ($_var_8 > 0) {
						addon_kuang_thread_addlog(str_replace(array("{number}"), array($_var_11), lang("plugin/addon_kuang_thread", "slang_001") . implode(lang("plugin/addon_kuang", "slang_060"), $_var_9)));
					}
				}
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism.zzb7-net";
		return 0;
	}