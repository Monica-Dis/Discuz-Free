<?php

function study_updatepluginlanguage($_arg_0)
{
	global $_G;
	if (!$_arg_0["language"]) {
		return false;
	}
	foreach (array("script", "template", "install") as $_var_2) {
		loadcache("pluginlanguage_" . $_var_2, 1);
		if (!empty($_arg_0["language"][$_var_2]) && is_array($_arg_0["language"][$_var_2])) {
			foreach ($_arg_0["language"][$_var_2] as $_var_3 => $_var_4) {
				if (is_array($_var_4)) {
					foreach ($_var_4 as $_var_5 => $_var_6) {
						if (isset($_G["cache"]["pluginlanguage_" . $_var_2][$_arg_0["identifier"]][$_var_3][$_var_5])) {
							$_G["cache"]["pluginlanguage_" . $_var_2][$_arg_0["identifier"]][$_var_3][$_var_5] = $_var_6;
						}
					}
				} else {
					if (isset($_G["cache"]["pluginlanguage_" . $_var_2][$_arg_0["identifier"]][$_var_3])) {
						$_G["cache"]["pluginlanguage_" . $_var_2][$_arg_0["identifier"]][$_var_3] = $_var_4;
					}
				}
			}
		}
		savecache("pluginlanguage_" . $_var_2, $_G["cache"]["pluginlanguage_" . $_var_2]);
		updatecache(array("pluginlanguage_" . $_var_2));
	}
	return true;
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	if (!submitcheck("previewsubmit", "1")) {
		$_statInfo["pluginName"] = $plugin["identifier"];
		$_statInfo["pluginVersion"] = $plugin["version"];
		$_statInfo["bbsVersion"] = DISCUZ_VERSION;
		$_statInfo["bbsRelease"] = DISCUZ_RELEASE;
		$_statInfo["timestamp"] = TIMESTAMP;
		$_statInfo["bbsUrl"] = $_G["siteurl"];
		$_statInfo["bbsAdminEMail"] = $_G["setting"]["adminemail"];
		echo "<div id=\"my_addonlist\"></div>";
		$_var_13 = "<li><font color=red>&#x672C;&#x63D2;&#x4EF6;&#x7531;Discuz!&#x6559;&#x7A0B;&#x7F51;(<a href=\"http://www.d'.'i'.'szz.net/\" target=\"_blank\" >www.d'.'iszz.net</a>)&#x5236;&#x4F5C;&#xFF0C;&#x7981;&#x6B62;&#x975E;&#x6CD5;&#x4F20;&#x64AD;&#x63D2;&#x4EF6;&#xFF0C;&#x6B63;&#x7248;&#x5730;&#x5740;&#xFF1A;<a href=\"https://addon.discuz.com/?@study_changepluginlang.plugin\" target=\"_blank\" >https://addon.discuz.com/?@study_changepluginlang.plugin</a></font></li>\r\n\t<li>BUG&#x3001;&#x5EFA;&#x8BAE;&#x63D0;&#x4EA4;&#x5730;&#x5740;&#xFF1A;<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=feedback\" target=\"_blank\" >http://www.di'.'szz.net/ser'.'vices.php</a></li>\r\n\t<li><font color=red>&#x8BED;&#x8A00;&#x5305;&#x5C5E;&#x4E8E;&#x7CFB;&#x7EDF;&#x5E95;&#x5C42;&#x5185;&#x5BB9;&#xFF0C;&#x4FEE;&#x6539;&#x6709;&#x98CE;&#x9669;&#xFF0C;&#x60A8;&#x9700;&#x8981;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x98CE;&#x9669;&#xFF0C;&#x5EFA;&#x8BAE;&#x64CD;&#x4F5C;&#x524D;&#x5907;&#x4EFD;&#x6570;&#x636E;&#x5E93;</font></li>";
		showtips($_var_13);
		$_var_14 = DB::query("SELECT * FROM " . DB::table("common_plugin") . " ORDER BY available DESC");
		showtableheader("&#x6709;&#x8BED;&#x8A00;&#x5305;&#x7684;&#x63D2;&#x4EF6;&#x5217;&#x8868;");
		showsubtitle(array("&#x63D2;&#x4EF6;&#x540D;&#x79F0;", "&#x7248;&#x672C;", "&#x4F5C;&#x8005;", "&#x72B6;&#x6001;", "&#x64CD;&#x4F5C;"));
		while ($plugin = DB::fetch($_var_14)) {
			$plugin["modules"] = unserialize($plugin["modules"]);
			if ($plugin["modules"]["extra"]["langexists"]) {
				$_var_15 = false;
				if (stripos($plugin["copyright"], "1314") !== false) {
					$_var_15 = true;
				} else {
					if (stripos($plugin["name"], "[1314]") !== false) {
						$_var_15 = true;
					}
				}
				echo "<tbody><tr>\r\n\t\t\t<td>" . $plugin["name"] . "</td>\r\n\t\t\t<td>" . $plugin["version"] . "</td>\r\n\t\t\t<td>" . ($_var_15 ? "<a href=\"http://www.d'.'i'.'szz.net\" target=\"_blank\">" . $plugin["copyright"] . "</a>" : $plugin["copyright"]) . "</td>\r\n\t\t\t<td>" . ($plugin["available"] ? "<font color=\"#00DD00\">&#x5DF2;&#x542F;&#x7528;" . ($_var_15 ? '' : "(<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=disable&pluginid=" . $plugin["pluginid"] . "\" target=\"_blank\">&#x5173;&#x95ED;</a> <a href=\"" . ADMINSCRIPT . "?action=plugins&operation=delete&pluginid=" . $plugin["pluginid"] . "\" target=\"_blank\">&#x5378;&#x8F7D;</a>)") . "</font>" : "&#x672A;&#x542F;&#x7528;(<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=enable&pluginid=" . $plugin["pluginid"] . "\" target=\"_blank\">&#x542F;&#x7528;</a>" . ($_var_15 ? '' : " <a href=\"" . ADMINSCRIPT . "?action=plugins&operation=delete&pluginid=" . $plugin["pluginid"] . "\" target=\"_blank\">&#x5378;&#x8F7D;</a>") . ")") . "</td>\r\n\t\t\t<td><a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin&type1314=script&previewsubmit=true&changeidentifier=" . $plugin["identifier"] . "\">&#x4FEE;&#x6539;&#x8BED;&#x8A00;&#x5305;</a></td>\r\n\t\t\t</tr>\r\n\t\t\t</tbody>";
			}
		}
		showtablefooter();
		echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"></div>\r\n\t";
	} else {
		$_var_16 = $_POST["changeidentifier"] ? $_POST["changeidentifier"] : ($_GET["changeidentifier"] ? $_GET["changeidentifier"] : '');
		$_var_16 = trim($_var_16);
		if (!ispluginkey($_var_16)) {
			cpmsg("&#x60A8;&#x8F93;&#x5165;&#x7684;&#x552F;&#x4E00;&#x6807;&#x8BC6;&#x7B26;&#x4E0D;&#x5408;&#x6CD5;", '', "error");
		}
		$type1314 = trim($_GET["type1314"]);
		$type1314 = in_array($type1314, array("script", "template", "install")) ? $type1314 : "script";
		$_var_17[$type1314] = " class=\"active\"";
		showtableheader('', "study_tb");
		showtablerow('', array(''), array("\r\n\t<div class=\"study_tab study_tab_min\">\r\n\t<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin&type1314=script&previewsubmit=true&changeidentifier=" . $_var_16 . "\" " . $_var_17["script"] . "><i></i><ins></ins>&#x811A;&#x672C;&#x8BED;&#x8A00;&#x5305;</a>\r\n\t<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin&type1314=template&previewsubmit=true&changeidentifier=" . $_var_16 . "\" " . $_var_17["template"] . "><i></i><ins></ins>&#x6A21;&#x7248;&#x8BED;&#x8A00;&#x5305;</a>\r\n\t<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin&type1314=install&previewsubmit=true&changeidentifier=" . $_var_16 . "\" " . $_var_17["install"] . "><i></i><ins></ins>&#x5B89;&#x88C5;&#x8BED;&#x8A00;&#x5305;</a>\r\n\t<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin\"><i></i><ins></ins>&#x8FD4;&#x56DE;&#x4E3B;&#x9875;&#x9762;</a>\r\n\t</div>"));
		showtablefooter();
		loadcache("pluginlanguage_" . $type1314, 1);
		$_var_18 = $_G["cache"]["pluginlanguage_" . $type1314][$_var_16];
		$_var_19 = DB::fetch_first("SELECT * FROM " . DB::table("common_plugin") . " WHERE identifier='" . $_var_16 . "'");
		$_var_20 = substr($_var_19["directory"], 0, -1);
		$_var_21 = unserialize($_var_19["modules"]);
		if (!$_var_19) {
			cpmsg("plugin_not_found", '', "error");
		}
		$_var_22 = DISCUZ_ROOT . "./source/plugin/" . $_var_20 . "/discuz_plugin_" . $_var_20 . ($_var_21["extra"]["installtype"] ? "_" . $_var_21["extra"]["installtype"] : '') . ".xml";
		if (file_exists($_var_22)) {
			@unlink($_var_22);
		}
		$_var_23 = array("script" => "&#x811A;&#x672C;&#x8BED;&#x8A00;&#x5305;", "template" => "&#x6A21;&#x7248;&#x8BED;&#x8A00;&#x5305;", "install" => "&#x5B89;&#x88C5;&#x8BED;&#x8A00;&#x5305;");
		if (!$_var_18) {
			cpmsg("&#x672C;&#x63D2;&#x4EF6;&#x4E0D;&#x5B58;&#x5728; <font color=\"#0099CC\">" . $_var_23[$type1314] . "</font>", '', "error");
		}
		if (!submitcheck("changesubmit")) {
			showformheader("plugins&operation=config&do=" . $pluginid . "&identifier=study_changepluginlang&pmod=admin&type1314=" . $type1314 . "&previewsubmit=true&changeidentifier=" . $_var_16 . '');
			showtableheader($_var_19["name"] . " " . $_var_19["version"] . " &#x8BED;&#x8A00;&#x5305;&#x5217;&#x8868;" . (!(stripos($_var_19["copyright"], "1314") === false) ? " <font color=\"red\">&#x3010;" . $_var_19["name"] . " &#x95EE;&#x9898;&#x53CD;&#x9988;&#x7248;&#x5757;&#xFF1A;<a href=\"http://www.di'.'szz.net/ser'.'vices.php\" target=\"_blank\" >http://www.di'.'szz.net/ser'.'vices.php</a>&#x3011;</font>" : ''));
			showsubtitle(array("ID", "&#x8BED;&#x8A00;"));
			$_var_24 = array("slang_1", "slang_2", "slang_3", "slang_4", "slang_5", "slang_6", "slang_7", "slang_8");
			$_var_25 = array("1314study", "slang_2", "slang_3", "slang_4", "slang_5", "slang_6", "slang_7", "slang_8");
			foreach ($_var_18 as $_var_26 => $_var_27) {
				if (!in_array($_var_26, $_var_24)) {
					if (is_array($_var_27)) {
						foreach ($_var_27 as $_var_28 => $_var_29) {
							showtablerow('', array("class=\"td25\"", ''), array($_var_28, "<textarea class=\"text\" name=\"pluginlanguage[" . $type1314 . "][" . $_var_26 . "][" . $_var_28 . "]\" style=\"width:100%;\">" . dhtmlspecialchars($_var_29) . "</textarea>"));
						}
					} else {
						$_var_30 = false;
						foreach ($_var_25 as $_var_31) {
							if (stripos($_var_27, $_var_31) !== false) {
								$_var_30 = true;
								break;
							}
						}
						if (!$_var_30) {
							showtablerow('', array("class=\"td25\"", ''), array($_var_26, "<textarea class=\"text\" name=\"pluginlanguage[" . $type1314 . "][" . $_var_26 . "]\" style=\"width:100%;\">" . dhtmlspecialchars($_var_27) . "</textarea>"));
						}
					}
				}
			}
			showsubmit("changesubmit", "&#x5F00;&#x59CB;&#x66F4;&#x65B0;");
			showtablefooter();
			showformfooter();
		} else {
			study_updatepluginlanguage(array("identifier" => $_var_16, "language" => $_POST["pluginlanguage"]));
			updatecache(array("plugin", "setting", "styles"));
			cleartemplatecache();
			cpmsg("&#x4FEE;&#x6539;&#x6210;&#x529F;&#xFF0C;&#x60A8;&#x662F;&#x5426;&#x8FD8;&#x6C89;&#x6D78;&#x5728;&#x6109;&#x60A6;&#x7684;&#x4FEE;&#x6539;&#x8FC7;&#x7A0B;&#x4E2D;&#xFF1F;&#x5F88;&#x9057;&#x61BE;&#xFF0C;&#x4E00;&#x5207;&#x7686;&#x5DF2;&#x5B8C;&#x6210;&#xFF01;", "action=plugins&operation=config&do=\$pluginid&identifier=study_changepluginlang&pmod=admin&type1314=" . $type1314 . "&previewsubmit=true&changeidentifier=" . $_var_16, "succeed");
		}
	}