<?php

function study_seo_head_postattributeextra()
{
	global $_G;
	$_var_1 = '';
	$_var_2 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_fids"]);
	$_var_3 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_admin_gids"]);
	if (in_array($_G["fid"], $_var_2) && in_array($_G["groupid"], $_var_3)) {
		$_var_1 = "<label id=\"extra_head_b\" onclick=\"showExtra('extra_head')\"><span id=\"extra_head_chk\">SEO&#x8BBE;&#x7F6E;</span></label>";
	}
	return $_var_1;
}
function study_seo_head_postattributeextrabody()
{
	global $_G;
	$_var_1 = array("title" => '', "keywords" => '', "description" => '');
	$_var_2 = intval($_G["tid"]);
	$_var_3 = $_var_4 = $_var_5 = '';
	$_var_6 = DB::fetch_first("SELECT title,keywords,description FROM " . DB::table("study_seo_head") . " WHERE typeid = '" . $_var_2 . "'");
	if ($_var_6) {
		if ($_var_6["title"]) {
			$_var_1["title"] = dhtmlspecialchars($_var_6["title"]);
		}
		if ($_var_6["keywords"]) {
			$_var_1["keywords"] = dhtmlspecialchars($_var_6["keywords"]);
		}
		if ($_var_6["description"]) {
			$_var_1["description"] = dhtmlspecialchars($_var_6["description"]);
		}
	}
	return $_var_1;
}
function study_seo_head_post_message($_arg_0)
{
	global $_G;
	$_arg_0 = $_arg_0["param"];
	$_var_2 = intval($_arg_0[2]["tid"]);
	$_var_3 = intval($_arg_0[2]["fid"]);
	$_var_4 = intval($_arg_0[2]["pid"]);
	if ($_var_2 && $_var_4) {
		$_G["cache"]["plugin"]["study_seo_head"] = $_G["cache"]["plugin"]["study_seo_head"];
		$_var_5 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_fids"]);
		$_var_6 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_admin_gids"]);
		if (in_array($_G["fid"], $_var_5) && in_array($_G["groupid"], $_var_6)) {
			if (in_array($_arg_0[0], array("post_newthread_succeed", "post_newthread_mod_succeed", "post_edit_succeed"))) {
				$_var_7 = DB::fetch_first("SELECT * FROM " . DB::table("forum_post") . " WHERE pid='" . $_var_4 . "' AND tid='" . $_var_2 . "'");
				if ($_var_7["first"]) {
					$_var_8 = array("typeid" => $_var_2, "type" => "tid", "title" => $_POST["title"], "keywords" => $_POST["keywords"], "description" => $_POST["description"]);
					$_var_9 = C::t("#study_seo_head#study_seo_head")->fetch_by_search(array("typeid" => $_var_2));
					if ($_var_9) {
						C::t("#study_seo_head#study_seo_head")->update_by_where(array("typeid" => $_var_2), $_var_8, 1);
					} else {
						C::t("#study_seo_head#study_seo_head")->insert($_var_8);
					}
				}
			}
		}
	}
	return '';
}
function study_seo_head_viewthreadposttop()
{
	global $_G;
	global $postlist;
	global $thread;
	global $navtitle;
	global $metakeywords;
	global $metadescription;
	$_var_6 = array();
	$_var_7 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_fids"]);
	if (!$_G["inajax"] && in_array($_G["fid"], $_var_7)) {
		$_var_8 = intval($_G["tid"]);
		$_var_9 = DB::fetch_first("SELECT * FROM " . DB::table("study_seo_head") . " WHERE typeid = '" . $_var_8 . "'");
		if ($_var_9) {
			$navtitle = dhtmlspecialchars($_var_9["title"] ? str_replace($thread["subject"], $_var_9["title"], $navtitle) : $navtitle);
			$metakeywords = $_var_9["keywords"] ? $_var_9["keywords"] : $metakeywords;
			$metadescription = $_var_9["description"] ? $_var_9["description"] : $metadescription;
			$_var_10 = "button_ok.gif";
		} else {
			$_var_10 = "button.gif";
		}
		if (!defined("IN_MOBILE")) {
			if ($_G["page"] == 1 && $_G["cache"]["plugin"]["study_seo_head"]["study_button"] == "1") {
				$_var_11 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_admin_gids"]);
				if (in_array($_G["groupid"], $_var_11)) {
					$_var_6[0] = "<a href=\"javascript:;\" onclick=\"showWindow('sethead', 'plugin.php?id=study_seo_head:sethead&handlekey=sethead&tid=" . $_G[tid] . "&formhash=" . $_G[formhash] . "','get','0');return false;\" title=\"SEO&#x5934;&#x90E8;&#x4F18;&#x5316;&#xFF08;&#x4F5C;&#x8005;&#xFF1A;www.d'.'iszz.net&#xFF09;\"><img src=\"source/plugin/study_seo_head/images/" . $_var_10 . "\" alt=\"SEO&#x5934;&#x90E8;&#x4F18;&#x5316;&#xFF08;&#x4F5C;&#x8005;&#xFF1A;www.d'.'iszz.net&#xFF09;\"/></a>";
				}
			}
		}
	}
	return $_var_6;
}
function study_seo_head_viewthreaduseraction()
{
	global $_G;
	$_var_1 = '';
	if ($_G["cache"]["plugin"]["study_seo_head"]["study_button"] == "2") {
		$_var_2 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_fids"]);
		if (in_array($_G["fid"], $_var_2)) {
			$_var_3 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_admin_gids"]);
			if (in_array($_G["groupid"], $_var_3)) {
				$_var_1 = "<a href=\"javascript:;\" onclick=\"showWindow('sethead', 'plugin.php?id=study_seo_head:sethead&handlekey=sethead&tid=" . $_G[tid] . "&formhash=" . $_G[formhash] . "','get','0');return false;\" title=\"SEO&#x5934;&#x90E8;&#x4F18;&#x5316;&#xFF08;&#x4F5C;&#x8005;&#xFF1A;www.d'.'iszz.net&#xFF09;\"><i><img src=\"source/plugin/study_seo_head/images/seo_head.gif\" alt=\"SEO&#x5934;&#x90E8;&#x4F18;&#x5316;&#xFF08;&#x4F5C;&#x8005;&#xFF1A;www.d'.'iszz.net&#xFF09;\">SEO&#x5934;&#x90E8;&#x4F18;&#x5316;</i></a>";
			}
		}
	}
	return $_var_1;
}
function study_seo_head_viewthreadpostfooter()
{
	global $_G;
	$_var_1 = array();
	if ($_G["cache"]["plugin"]["study_seo_head"]["study_button"] == "3") {
		$_var_2 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_fids"]);
		if (in_array($_G["fid"], $_var_2)) {
			$_var_3 = (array) unserialize($_G["cache"]["plugin"]["study_seo_head"]["study_admin_gids"]);
			if (in_array($_G["groupid"], $_var_3)) {
				$_var_1[] = "<a href=\"javascript:;\" onclick=\"showWindow('sethead', 'plugin.php?id=study_seo_head:sethead&handlekey=sethead&tid=" . $_G[tid] . "&formhash=" . $_G[formhash] . "','get','0');return false;\" title=\"SEO&#x5934;&#x90E8;&#x4F18;&#x5316;&#xFF08;&#x4F5C;&#x8005;&#xFF1A;www.d'.'iszz.net&#xFF09;\" style=\"background: url(source/plugin/study_seo_head/images/seo_head.gif) no-repeat 0 50%;\">SEO&#x5934;&#x90E8;&#x4F18;&#x5316;</a>";
			}
		}
	}
	return $_var_1;
}
	if (!defined("IN_DISCUZ")) {
		echo "From www.d'.'iszz.net";
		return 0;
	}