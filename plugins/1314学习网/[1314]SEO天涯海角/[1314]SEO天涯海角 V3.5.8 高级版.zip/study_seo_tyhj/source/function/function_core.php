<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_seo_tyhj_urlencode_diconv()
{
	$_var_7 = $_var_6["tags"];
	$_var_4 = $_var_5;
	if ($_var_7) {
		if (in_array($_var_2["study_postbottom"], array("2", "3", "4"))) {
			$postlist[$_var_4]["stags"] = $postlist[$_var_4]["tags"];
			$postlist[$_var_4]["tags"] = array();
			$_var_8 = 1314;
			if ($_var_2["study_tag_way"] == 2) {
				foreach ($_var_7 as $_var_9) {
					if ($_var_8 == 1314) {
						$_var_3["tag"] = $_var_3["tag"] . ("<a href=\"misc.php?mod=tag&name=" . $_var_9[1] . "\" title=\"" . $_var_9[1] . "\" target=\"_blank\">" . $_var_9[1] . "</a>");
						$_var_8 = "dly";
					} else {
						$_var_3["tag"] = $_var_3["tag"] . (",<a href=\"misc.php?mod=tag&name=" . $_var_9[1] . "\" title=\"" . $_var_9[1] . "\" target=\"_blank\">" . $_var_9[1] . "</a>");
					}
				}
			} else {
				foreach ($_var_7 as $_var_9) {
					if ($_var_8 == 1314) {
						$_var_3["tag"] = $_var_3["tag"] . ("<a href=\"misc.php?mod=tag&id=" . $_var_9[0] . "\" title=\"" . $_var_9[1] . "\" target=\"_blank\">" . $_var_9[1] . "</a>");
						$_var_8 = "dly";
					} else {
						$_var_3["tag"] = $_var_3["tag"] . (",<a href=\"misc.php?mod=tag&id=" . $_var_9[0] . "\" title=\"" . $_var_9[1] . "\" target=\"_blank\">" . $_var_9[1] . "</a>");
					}
				}
			}
		}
		foreach ($_var_7 as $_var_10 => $_var_11) {
			$_var_12 = $_var_12 . ($_var_11[1] . " ");
		}
		$_var_3[3]["gbk"] = urlencode(diconv($_var_12, CHARSET, "gb2312"));
		$_var_3[3]["utf8"] = urlencode(diconv($_var_12, CHARSET, "utf-8"));
	} else {
		$_var_3[3] = $_var_3[2];
	}
	$_var_12 = $_var_2["study_keyword"];
	if ($_var_12) {
		$_var_3[4]["gbk"] = urlencode(diconv($_var_12, CHARSET, "gb2312"));
		$_var_3[4]["utf8"] = urlencode(diconv($_var_12, CHARSET, "utf-8"));
	} else {
		$_var_3[4] = $_var_3[2];
	}
	if ($_var_2["study_site"]) {
		$_var_3["site"] = "+site%3A" . $_var_2["study_site"];
	}
	return $_var_3;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}