<?php

/**
 *      
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: sousuo.inc.php 2012-10-18 14:19:59Z dz-x.net $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo '<script type="text/javascript">location.href="source/plugin/study_seo_tyhj/tijiao/index.html";</script>';
?>
