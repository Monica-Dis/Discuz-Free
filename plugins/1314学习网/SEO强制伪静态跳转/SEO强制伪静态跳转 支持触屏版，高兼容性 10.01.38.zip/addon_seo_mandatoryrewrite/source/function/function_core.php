<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_seo_mandatoryrewrite_checkrewrite()
{
	global $_G;
	$_var_1 = '';
	if (!empty($_SERVER["QUERY_STRING"])) {
		if (isset($_SERVER["HTTP_X_ORIGINAL_URL"])) {
			$_var_1 = $_SERVER["HTTP_X_ORIGINAL_URL"];
		} else {
			if (isset($_SERVER["HTTP_X_REWRITE_URL"])) {
				$_var_1 = $_SERVER["HTTP_X_REWRITE_URL"];
			} else {
				if (isset($_SERVER["REQUEST_URI"])) {
					$_var_1 = $_SERVER["REQUEST_URI"];
				} else {
					$_var_1 = $_SERVER["REDIRECT_URL"];
				}
			}
		}
	}
	return strpos($_var_1, "?") === false ? true : false;
}
function addon_seo_mandatoryrewrite_location()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["addon_seo_mandatoryrewrite"];
	if ($_var_1["study_radio"] && !$_GET["ajax"] && !addon_seo_mandatoryrewrite_checkrewrite()) {
		$_var_2 = CURSCRIPT . "_" . CURMODULE;
		if (isset($_var_1[$_var_2]) && !empty($_var_1[$_var_2])) {
			parse_str($_SERVER["QUERY_STRING"], $_var_3);
			if (!empty($_var_3)) {
				if (addon_seo_mandatoryrewrite_checkvar(array("isrewrite", "diy", "inajax"), $_var_3)) {
					return '';
				}
				if ($_var_2 == "forum_viewthread") {
					if (addon_seo_mandatoryrewrite_checkvar(array("authorid", "ordertype", "fromuid", "from", "modthreadkey", "_dsign"), $_var_3)) {
						return '';
					}
					if ($_G["page"] > 1 && !empty($_var_1[$_var_2 . "2"])) {
						$_var_2 = $_var_2 . "2";
					}
				} else {
					if ($_var_2 == "forum_forumdisplay") {
						if ($_var_3["filter"] == "typeid" && isset($_var_3["typeid"]) && !isset($_var_3["sortid"])) {
							$_var_2 = "forum_forumdisplay_type";
						} else {
							if (addon_seo_mandatoryrewrite_checkvar(array("filter"), $_var_3)) {
								return '';
							}
							if ($_G["page"] > 1 && !empty($_var_1[$_var_2 . "2"])) {
								$_var_2 = $_var_2 . "2";
							}
						}
					} else {
						if ($_var_2 == "forum_group") {
							if (addon_seo_mandatoryrewrite_checkvar(array("action"), $_var_3)) {
								return '';
							}
						}
					}
				}
				if ($_var_2 == "misc_tag") {
					if (empty($_G["cache"]["plugin"]["study_rewrite_tag"]) && empty($_G["cache"]["plugin"]["addon_seo_rewrite"]["forum_tag_radio"])) {
						return '';
					}
					if (addon_seo_mandatoryrewrite_checkvar(array("id"), $_var_3)) {
						if (addon_seo_mandatoryrewrite_checkvar(array("type"), $_var_3)) {
							$_var_2 = "forum_tag_list";
						} else {
							$_var_2 = "forum_tag_view";
						}
					} else {
						if (addon_seo_mandatoryrewrite_checkvar(array("name"), $_var_3)) {
							$_var_2 = "forum_tag_nameview";
						} else {
							$_var_2 = "forum_tag_index";
						}
					}
					$_var_4 = array("{id}", "{name}", "{type}", "{page}");
					$_var_5 = array(intval($_GET["id"]), $_GET["name"], $_GET["type"], $_G["page"]);
					if (!empty($_G["cache"]["plugin"]["study_rewrite_tag"])) {
						if ($_G["page"] > 1 && !empty($_G["cache"]["plugin"]["study_rewrite_tag"][$_var_2 . "2"])) {
							$_var_2 = $_var_2 . "2";
						}
						$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["study_rewrite_tag"][$_var_2]);
					} else {
						if ($_G["page"] > 1 && $_var_2 != "forum_tag_list" || $_var_2 == "forum_tag_nameview") {
							return '';
						}
						$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["addon_seo_rewrite"][$_var_2]);
					}
				} else {
					if ($_var_2 == "forum_guide") {
						if (empty($_G["cache"]["plugin"]["addon_seo_guiderewrite"])) {
							return '';
						}
						if (addon_seo_mandatoryrewrite_checkvar(array("view"), $_var_3)) {
							if ($_GET["view"] == $_G["cache"]["plugin"]["addon_seo_guiderewrite"]["guide_index_view"] && $_G["page"] < 2) {
								$_var_2 = "guide_index";
							} else {
								$_var_2 = "guide_list";
							}
							if (!in_array($_GET["view"], array("hot", "digest", "new", "newthread", "sofa", "my"))) {
								$_var_2 = "guide_index";
							}
						} else {
							$_var_2 = "guide_index";
						}
						if ($_G["page"] > 1 && !empty($_G["cache"]["plugin"]["addon_seo_guiderewrite"][$_var_2 . "2"])) {
							$_var_2 = $_var_2 . "2";
						}
						$_var_4 = array("{view}", "{page}");
						$_var_5 = array($_GET["view"], $_G["page"]);
						$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["addon_seo_guiderewrite"][$_var_2]);
					} else {
						if ($_var_2 == "forum_forumdisplay_type") {
							if (isset($_var_1["zzbuluo_seo_forumtyperewrite"]) && !empty($_var_1["zzbuluo_seo_forumtyperewrite"])) {
								if (empty($_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"])) {
									return '';
								}
								if ($_G["page"] > 1 && !empty($_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"][$_var_2 . "2"])) {
									$_var_2 = $_var_2 . "2";
								}
								$_var_4 = array("{fid}", "{typeid}", "{page}");
								$_var_5 = array($_G["fid"], $_var_3["typeid"], $_G["page"]);
								$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["zzbuluo_seo_forumtyperewrite"][$_var_2]);
							} else {
								return '';
							}
						} else {
							if ($_var_2 == "forum_index") {
								if (empty($_G["cache"]["plugin"]["zzbuluo_seo_gidrewrite"]) || addon_seo_mandatoryrewrite_checkvar(array("showoldetails"), $_var_3)) {
									return '';
								}
								if (addon_seo_mandatoryrewrite_checkvar(array("gid"), $_var_3)) {
									if (!empty($_G["cache"]["plugin"]["zzbuluo_seo_gidrewrite"]["forum_forumdisplay_gid"])) {
										$_var_2 = "forum_forumdisplay_gid";
									} else {
										return '';
									}
								} else {
									return '';
								}
								$_var_4 = array("{gid}");
								$_var_5 = array($_GET["gid"]);
								$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["zzbuluo_seo_gidrewrite"][$_var_2]);
							} else {
								if ($_var_2 == "forum_viewthread" && empty($_G["tid"])) {
									return '';
								}
								$_var_7 = $_G["fid"];
								if ($_var_7 && !empty($_G["setting"]["forumkeys"][$_var_7])) {
									$_var_7 = $_G["setting"]["forumkeys"][$_var_7];
								}
								$_var_4 = array("{id}", "{fid}", "{tid}", "{page}", "{prevpage}");
								$_var_5 = array(intval($_GET["aid"]), $_var_7, $_G["tid"], $_G["page"], 1);
								if (isset($_G["cache"]["plugin"]["addon_seo_rewrite"][$_var_2]) && !empty($_G["cache"]["plugin"]["addon_seo_rewrite"][$_var_2])) {
									$_var_6 = str_replace($_var_4, $_var_5, $_G["cache"]["plugin"]["addon_seo_rewrite"][$_var_2]);
								} else {
									$_var_6 = str_replace($_var_4, $_var_5, $_var_1[$_var_2]);
								}
							}
						}
					}
				}
				if (!empty($_var_6)) {
					header("HTTP/1.1 301 Moved Permanently");
					header("location: " . (preg_match("/^https?:\\/\\//i", $_var_6) ? '' : $_G["siteurl"]) . $_var_6);
					return '';
				}
			}
		}
	}
}
function addon_seo_mandatoryrewrite_checkvar($_arg_0 = array(), $_arg_1 = array())
{
	$_var_2 = false;
	foreach ($_arg_0 as $_var_3) {
		if (isset($_arg_1[$_var_3])) {
			$_var_2 = true;
			break;
		}
	}
	return $_var_2;
}
function addon_seo_mandatoryrewrite_check()
{
	addon_seo_mandatoryrewrite_validator();
	$_var_0 = '';
	$_var_1 = DISCUZ_ROOT . "./source/plugin/addon_seo_mandatoryrewrite/demo.php";
	if (!file_exists($_var_1)) {
		C::t("common_plugin")->delete_by_identifier("addon_seo_mandatoryrewrite");
		return '';
	}
	if ($_var_2 = @fopen($_var_1, "r")) {
		$_var_0 = fread($_var_2, filesize($_var_1));
		fclose($_var_2);
	}
	$_var_0 = NULL;
}
function addon_seo_mandatoryrewrite_cleardir($_arg_0)
{
}
function addon_seo_mandatoryrewrite_deltree($_arg_0)
{
}
function addon_seo_mandatoryrewrite_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}
	global $_G;
	if (!defined("IN_ADMINCP")) {
		addon_seo_mandatoryrewrite_location();
		if ($_GET["e_locaon_check"]) {
			addon_seo_mandatoryrewrite_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
	}