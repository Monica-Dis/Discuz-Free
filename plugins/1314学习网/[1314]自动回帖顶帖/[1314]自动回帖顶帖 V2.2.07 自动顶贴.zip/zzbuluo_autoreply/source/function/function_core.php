<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function zzbuluo_autoreply_list_array($_arg_0)
{
	$_var_1 = '';
	if (is_array($_arg_0)) {
		$_var_2 = "1314";
		foreach ($_arg_0 as $_var_3 => $_var_4) {
			if (!empty($_var_4) && $_var_4) {
				if ($_var_2 == "1314") {
					$_var_1 = $_var_1 . $_var_4;
					$_var_2 = "DIY";
				} else {
					$_var_1 = $_var_1 . ("," . $_var_4);
				}
			}
		}
	}
	return $_var_1;
}
function zzbuluo_autoreply_checkdate()
{
	global $_G;
	$_var_1 = true;
	if ($_G["cache"]["plugin"]["zzbuluo_autoreply"]["study_date"]) {
		$_var_2 = explode("-", $_G["cache"]["plugin"]["zzbuluo_autoreply"]["study_date"]);
		$_var_2[0] = intval(trim($_var_2[0]));
		if ($_var_2[0] < 0 || $_var_2[0] > 24) {
			$_var_2[0] = 0;
		}
		$_var_2[1] = intval(trim($_var_2[1]));
		if ($_var_2[1] < 0 || $_var_2[1] > 24) {
			$_var_2[1] = 24;
		}
		$_var_3 = strtotime(date("Y-m-d", intval($_G["timestamp"])));
		if ($_G["timestamp"] < $_var_3 + $_var_2[0] * 3600 || $_G["timestamp"] > $_var_3 + $_var_2[1] * 3600) {
			$_var_1 = false;
		}
	}
	return $_var_1;
}
function zzbuluo_autoreply_deal()
{
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["zzbuluo_autoreply"];
	$_var_2 = '';
	$_var_3 = intval($_var_1["study_day"]);
	$_var_2 = $_var_2 . ($_var_3 ? " AND dateline > '" . ($_G["timestamp"] - $_var_3 * 86400) . "' " : '');
	$_var_4 = intval($_var_1["study_noreply"]);
	$_var_2 = $_var_2 . ($_var_4 ? " AND (lastpost < '" . ($_G["timestamp"] - $_var_4) . "' OR replies = '0') " : '');
	$_var_5 = (array) unserialize($_var_1["study_fids"]);
	$_var_6 = zzbuluo_autoreply_list_array($_var_5);
	$_var_2 = $_var_2 . ($_var_6 ? " AND fid in(" . $_var_6 . ") " : '');
	$_var_7 = intval($_var_1["study_maxreply"]);
	$_var_2 = $_var_2 . ($_var_7 ? " AND replies < '" . $_var_7 . "' " : '');
	$_var_8 = intval($_var_1["study_order"]);
	if ($_var_8 < 2) {
		$_var_9 = " ORDER BY rand() ";
	} else {
		if ($_var_8 = 2) {
			$_var_9 = " ORDER BY tid DESC";
		} else {
			if ($_var_8 = 3) {
				$_var_9 = " ORDER BY replies ASC";
			} else {
				$_var_9 = " ORDER BY views ASC";
			}
		}
	}
	$_var_10 = array();
	$_var_11 = DB::query("SELECT tid,fid,posttableid,subject,authorid,author FROM " . DB::table("forum_thread") . " WHERE displayorder >= 0 AND closed = '0' " . $_var_2 . " " . $_var_9 . " LIMIT 10");
	while ($_var_12 = DB::fetch($_var_11)) {
		$_var_10[] = $_var_12;
	}
	if (!empty($_var_10)) {
		$_var_13 = rand(0, count($_var_10) - 1);
		$_var_14 = $_var_10[$_var_13];
		$_var_15 = intval($_var_14["fid"]);
		$_var_16 = intval($_var_14["tid"]);
		$_var_17 = rand(1, 255) . "." . rand(1, 255) . "." . rand(1, 255) . "." . rand(1, 255);
		$_var_1["study_uids"] = str_replace("-", ",", $_var_1["study_uids"]);
		$_var_18 = explode(",", $_var_1["study_uids"]);
		if (count($_var_18) == 2) {
			$_var_19 = intval($_var_18[0]) > 0 ? intval($_var_18[0]) : 1;
			$_var_20 = intval($_var_18[1]) > $_var_19 ? intval($_var_18[1]) : $_var_19;
			$_var_21 = rand($_var_19, $_var_20);
		} else {
			$_var_22 = rand(0, count($_var_18) - 1);
			$_var_21 = max(intval($_var_18[$_var_22]), 1);
		}
		$_var_23 = getuserbyuid($_var_21, 1);
		$_var_24 = $_var_23["username"];
		$_var_25 = explode("\n", str_replace("\r\n", "\n", $_var_1["study_replylist"]));
		$_var_26 = rand(0, count($_var_25) - 1);
		$_var_27 = daddslashes($_var_25[$_var_26]);
		if ($_var_24 && $_var_27 && $_var_16) {
			$_var_27 = str_replace(array("{author}", "{subject}", "{username}"), array($_var_14["author"], $_var_14["subject"], $_var_24), $_var_27);
			$_var_28 = array("fid" => $_var_15, "tid" => $_var_16, "first" => "0", "author" => $_var_24, "authorid" => $_var_21, "subject" => '', "dateline" => $_G["timestamp"], "message" => $_var_27, "useip" => $_var_17, "invisible" => "0", "anonymous" => "0", "usesig" => "0", "htmlon" => "0", "bbcodeoff" => "0", "smileyoff" => "0", "parseurloff" => "0", "attachment" => "0");
			$_var_29 = insertpost($_var_28);
			$_var_30 = '' . $_var_16 . "\t" . addslashes($_var_14["subject"]) . "\t" . $_G["timestamp"] . "\t" . addslashes($_var_24);
			DB::query("UPDATE " . DB::table("forum_forum") . " SET posts=posts+1,todayposts=todayposts+1,lastpost='" . $_var_30 . "' WHERE fid='" . $_var_15 . "'");
			DB::query("UPDATE " . DB::table("forum_thread") . " SET replies=replies+1,views=views+'1',lastposter='" . $_var_24 . "', lastpost='" . $_G["timestamp"] . "' WHERE tid='" . $_var_16 . "'");
			require_once libfile("function/post");
			updatepostcredits("+", $_var_21, "reply", $_var_15);
			DB::query("UPDATE " . DB::table("common_member_status") . " SET lastip='" . $_var_17 . "',lastvisit='" . $_G["timestamp"] . "',lastactivity='" . $_G["timestamp"] . "',lastpost='" . $_G["timestamp"] . "' WHERE uid='" . $_var_21 . "'");
			$_var_31 = C::t("forum_post")->fetch_maxposition_by_tid($_var_14["posttableid"], $_var_14["tid"]);
			$_var_32 = array();
			$_var_32[] = DB::field("maxposition", $_var_31);
			if (!empty($_var_32)) {
				C::t("forum_thread")->update($_var_14["tid"], $_var_32, false, false, 0, true);
			}
			define("IN_ZZBULUO_AUTOREPLY", true);
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "from:www.d'.'z-x.net";
		return 0;
	}