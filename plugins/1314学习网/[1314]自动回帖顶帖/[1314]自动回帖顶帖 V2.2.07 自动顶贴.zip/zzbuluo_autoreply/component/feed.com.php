<?php

/*
 * This is NOT a freeware, use is subject to license terms
 * From dism��taobao��com
 */

if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
}elseif(defined('IN_ZZBULUO_AUTOREPLY')) {
		$post_url = "forum.php?mod=redirect&goto=findpost&pid=$pid&ptid=$tid";
		$feed['icon'] = 'post';
		$feed['title_template'] = !empty($nowthread['author']) ? 'feed_reply_title' : 'feed_reply_title_anonymous';
		$feed['title_data'] = array(
			'subject' => "<a href=\"$post_url\">$nowthread[subject]</a>",
			'author' => "<a href=\"home.php?mod=space&uid=$nowthread[authorid]\">$nowthread[author]</a>"
		);
		$feed['title_data']['hash_data'] = "tid{$tid}";
		$feed['id'] = $pid;
		$feed['idtype'] = 'pid';
		require_once libfile('function/feed');
		feed_add($feed['icon'], $feed['title_template'], $feed['title_data'], $feed['body_template'], $feed['body_data'], '', $feed['images'], $feed['image_links'], '', '', '', 0, $feed['id'], $feed['idtype'], $uid, $username);
}
?>