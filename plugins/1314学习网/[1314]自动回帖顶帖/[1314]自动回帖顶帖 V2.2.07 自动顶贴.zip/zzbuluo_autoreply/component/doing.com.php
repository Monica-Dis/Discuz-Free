<?php

/*
 * This is NOT a freeware, use is subject to license terms
 * From dism��taobao��com
 */

if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
}elseif(defined('IN_ZZBULUO_AUTOREPLY')) {
		//����������ҳ�ѹ���
		$setarr = array(
			'uid' => $uid,
			'username' => $username,
			'dateline' => $_G['timestamp'],
			'message' => $message,
			'ip' => $useip,
			'status' => 0,
		);
		DB::insert('home_doing', $setarr);
}
?>