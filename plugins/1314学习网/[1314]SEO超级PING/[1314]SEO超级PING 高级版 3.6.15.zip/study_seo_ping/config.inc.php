<?php

/**
 * Copyright 2001-2099 DisM!.Ӧ.��.��.��.
 * This is NOT a freeware, use is subject to license terms
 * $Id: config.inc.php 4263 2020-07-07 22:30:18
 * Ӧ���ۺ����⣺http://dism.t'.'aobao.com?/services.php?mod=issue������ http://t.cn/Aiux14ti��
 * Ӧ����ǰ��ѯ��QQ dism.taobao.com
 * Ӧ�ö��ƿ�����QQ dism.taobao.com
 * �����Ϊ DisM!Ӧ�����ģ�dism.t'.'aobao.com?�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('');
}
define('STUDY_MANAGE_URL', 'plugins&operation=config&do='.$pluginid.'&identifier='.dhtmlspecialchars($_GET['identifier']).'&pmod=config');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['study_seo_ping'];
$splugin_lang = lang('plugin/study_seo_ping');
$a236mdg1 = "���棺 http://t.cn/Aiux14ti";
$type1314 = in_array($_GET['type1314'], array('config', 'icon', 'category', 'slide', 'rewrite', 'seo')) ? $_GET['type1314'] : 'config';/*From dism_taobao_com*/
$splugin_setting['0'] = array('0' => '2013090320ikG5iDN5qX', '1' => '19257','2' => '1356969600', '3' => 'http://127.0.0.1/', '4' => 'http://127.0.0.1/', '5' => '', '6' => '', '7' => '');
require_once libfile('include/config', 'plugin/study_seo_ping/source');

//Copyright 2001-2099 .DisM��Taobao��Com.
//This is NOT a freeware, use is subject to license terms
//$Id: config.inc.php 4725 2020-07-07 14:30:18
//Ӧ���ۺ����⣺http://dism.t'.'aobao.com?/services.php?mod=issue ������ http://t.cn/Aiux14ti��
//Ӧ����ǰ��ѯ��QQ DisM��Taobao-Com
//Ӧ�ö��ƿ�����QQ DisM.Taobao.Com
//�����Ϊ DisM-Ӧ�����ģ�dism.t'.'aobao.com?�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��