<?php

function study_seo_ping_cleardir($_arg_0 = null)
{
}
function study_seo_ping_deltree($_arg_0 = null)
{
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From dism.taobao.com?";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$pluginvars = array();
	foreach (C::t("common_pluginvar")->fetch_all_by_pluginid($pluginid) as $_var_9) {
		if (!strexists($_var_9["type"], "_")) {
			C::t("common_pluginvar")->update_by_variable($pluginid, $_var_9["variable"], array("type" => $_var_9["type"] . "_1314"));
		} else {
			$_var_10 = explode("_", $_var_9["type"]);
			if ($_var_10[1] == "1314") {
				$_var_9["type"] = $_var_10[0];
			} else {
				continue;
			}
		}
		$pluginvars[$_var_9["variable"]] = $_var_9;
	}
	require_once libfile("function/var", "plugin/study_seo_ping/source");
	if (!submitcheck("editsubmit")) {
		$_var_11 = '';
		if ($pluginvars) {
			showformheader("plugins&operation=config&do=" . $pluginid . '');
			showtableheader();
			echo "<div id=\"my_addonlist\"></div>";
			showtitle($lang["plugins_config"]);
			$_var_12 = array();
			foreach ($pluginvars as $_var_9) {
				if (!strexists($_var_9["type"], "_")) {
					$_var_9["description"] = dhtmlspecialchars($_var_9["description"]);
					if ($_var_9["variable"] == "addon_seo_rewrite") {
						$_var_9["description"] = "&#x5F00;&#x542F;&#x524D;&#x8BF7;&#x786E;&#x8BA4;&#x4F60;&#x5DF2;&#x7ECF;&#x5B89;&#x88C5;&#x4E86;[1314]SEO&#x8D85;&#x7EA7;&#x4F2A;&#x9759;&#x6001;&#x63D2;&#x4EF6;&#xFF1A;<a href=\"http://addon.dism.taobao.com/?@study_seo_ping.plugin\" style=\"color: #09C;font-weight: 600;\" target=\"_blank\">http://addon.dism.taobao.com/?@study_seo_ping.plugin</a>";
					}
					$_var_9["variable"] = "varsnew[" . $_var_9["variable"] . "]";
					if ($_var_9["type"] == "number") {
						$_var_9["type"] = "text";
					} else {
						if ($_var_9["type"] == "select") {
							$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "\">\n";
							foreach (explode("\n", $_var_9["extra"]) as $_var_13 => $_var_14) {
								$_var_14 = trim($_var_14);
								if (strpos($_var_14, "=") === false) {
									$_var_13 = $_var_14;
								} else {
									$_var_15 = explode("=", $_var_14);
									$_var_13 = trim($_var_15[0]);
									$_var_14 = trim($_var_15[1]);
								}
								$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . dhtmlspecialchars($_var_13) . "\" " . ($_var_9["value"] == $_var_13 ? "selected" : '') . ">" . $_var_14 . "</option>\n");
							}
							$_var_9["type"] = $_var_9["type"] . "</select>\n";
							$_var_9["variable"] = $_var_9["value"] = '';
						} else {
							if ($_var_9["type"] == "selects") {
								$_var_9["value"] = dunserialize($_var_9["value"]);
								$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array($_var_9["value"]);
								$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" multiple=\"multiple\" size=\"10\">\n";
								foreach (explode("\n", $_var_9["extra"]) as $_var_13 => $_var_14) {
									$_var_14 = trim($_var_14);
									if (strpos($_var_14, "=") === false) {
										$_var_13 = $_var_14;
									} else {
										$_var_15 = explode("=", $_var_14);
										$_var_13 = trim($_var_15[0]);
										$_var_14 = trim($_var_15[1]);
									}
									$_var_9["type"] = $_var_9["type"] . ("<option value=\"" . dhtmlspecialchars($_var_13) . "\" " . (in_array($_var_13, $_var_9["value"]) ? "selected" : '') . ">" . $_var_14 . "</option>\n");
								}
								$_var_9["type"] = $_var_9["type"] . "</select>\n";
								$_var_9["variable"] = $_var_9["value"] = '';
							} else {
								if ($_var_9["type"] == "forums") {
									$_var_9["description"] = ($_var_9["description"] ? (isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : $_var_9["description"]) . "\n" : '') . $lang["plugins_edit_vars_multiselect_comment"] . "\n" . $_var_9["comment"];
									$_var_9["value"] = dunserialize($_var_9["value"]);
									$_var_9["value"] = is_array($_var_9["value"]) ? $_var_9["value"] : array();
									require_once libfile("function/forumlist");
									$_var_9["type"] = "<select name=\"" . $_var_9["variable"] . "[]\" size=\"10\" multiple=\"multiple\"><option value=\"\">" . cplang("plugins_empty") . "</option>" . forumselect(false, 0, 0, true) . "</select>";
									foreach ($_var_9["value"] as $_var_16) {
										$_var_9["type"] = str_replace("<option value=\"" . $_var_16 . "\">", "<option value=\"" . $_var_16 . "\" selected>", $_var_9["type"]);
									}
									$_var_9["variable"] = $_var_9["value"] = '';
								}
							}
						}
					}
					s_showsetting(isset($lang[$_var_9["title"]]) ? $lang[$_var_9["title"]] : dhtmlspecialchars($_var_9["title"]), $_var_9["variable"], $_var_9["value"], $_var_9["type"], '', 0, isset($lang[$_var_9["description"]]) ? $lang[$_var_9["description"]] : nl2br($_var_9["description"]), dhtmlspecialchars($_var_9["extra"]), '', true);
				}
			}
			showsubmit("editsubmit");
			showtablefooter();
			showformfooter();
			echo implode('', $_var_12);
			echo "<div id=\"my_addonlist_temp\" style=\"display:none;\"></div>\r\n\t\t<script type=\"text/javascript\">\$(\"my_addonlist_js\").src= \"\";\$(\"my_addonlist\").innerHTML = \$(\"my_addonlist_temp\").innerHTML;</script>";
		}
	} else {
		if (is_array($_GET["varsnew"])) {
			foreach ($_GET["varsnew"] as $_var_17 => $_var_18) {
				if (isset($pluginvars[$_var_17])) {
					if ($pluginvars[$_var_17]["type"] == "number") {
						$_var_18 = (double) $_var_18;
					} else {
						if (in_array($pluginvars[$_var_17]["type"], array("forums", "groups", "selects"))) {
							$_var_18 = serialize($_var_18);
						}
					}
					$_var_18 = (string) $_var_18;
					C::t("common_pluginvar")->update_by_variable($pluginid, $_var_17, array("value" => $_var_18));
				}
			}
		}
		updatecache(array("plugin", "setting", "styles"));
		cleartemplatecache();
		cpmsg("plugins_setting_succeed", "action=plugins&operation=config&do=" . $pluginid . "&anchor=" . $_var_19, "succeed");
	}