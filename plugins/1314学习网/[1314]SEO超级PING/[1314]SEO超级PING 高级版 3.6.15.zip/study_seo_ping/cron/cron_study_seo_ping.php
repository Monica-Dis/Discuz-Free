<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From dism.taobao.com?
 * Ӧ���ۺ����⣺http://dism.taobao.com?/ser'.'vices.php?mod=ask&sid=1
 * Ӧ����ǰ��ѯ��http://dism.taobao.com?/ser'.'vices.php?mod=ask&sid=2
 * ���ο������ƣ�http://dism.taobao.com?/ser'.'vices.php?mod=ask&sid=22
 */

//cronname:&#x6BCF;&#x65E5;&#x6570;&#x636E;&#x6E05;&#x7406;
////minute:3,8,13,18,23,28,33,38,43,48,53,58

if (!defined('IN_DISCUZ')) {
	exit('');
}

if (empty($_G['cache']['plugin']['study_seo_ping'])) {
	loadcache('plugin');
}

require_once libfile('function/core', 'plugin/st' . 'udy_seo_pi' . 'ng/source');
$splugin_setting = $_G['cache']['plugin']['study_seo_ping'];
$ping_range = (array) unserialize($splugin_setting['ping_range']);
if (in_array('forum', $ping_range)) {
	if ($splugin_setting['ping_way'] == 3) {
		$study_fids = (array) unserialize($splugin_setting['study_fids']);
		$pingthreadlist = C::t('#study_seo_ping#study_seo_ping')->fetch_all_by_search(array('baidu' => 0, 'google' => 0), array('dateline' => 'ASC'), 5);
		if ($pingthreadlist && is_array($pingthreadlist)) {
			foreach ($pingthreadlist as $key => $value) {
				//if($value['dateline'] < $_G['timestamp']){
				$threadinfo = DB::fetch_first("SELECT authorid as uid,fid,displayorder FROM " . DB::table('forum_thread') . " WHERE tid='$value[tid]' ORDER BY tid DESC");
				if (!in_array($threadinfo['fid'], $study_fids)) {
					C::t('#study_seo_ping#study_seo_ping')->delete_by_where(array('id' => $value['id']), 1);
					continue;
				}

				if ($threadinfo['displayorder'] >= 0) {
					superping_thread_run(array('tid' => $value['tid']));
				} elseif ($threadinfo['displayorder'] == -2) {
					C::t('#study_seo_ping#study_seo_ping')->update_by_where(array('id' => $value['id']), array('dateline' => $_G['timestamp'] + 86400), 1);
				} else {
					C::t('#study_seo_ping#study_seo_ping')->delete_by_where(array('id' => $value['id']), 1);
				}
				//}
			}
		}
	}
}

if (in_array('portal', $ping_range)) {
	$splugin_setting['portal_nocatid'] = explode(',', $splugin_setting['portal_nocatid']);
	$pingarticlelist = C::t('#study_seo_ping#study_seo_ping_article')->fetch_all_by_search(array('baidu' => 0, 'google' => 0), array('dateline' => 'ASC'), 5);
	if ($pingarticlelist && is_array($pingarticlelist)) {
		foreach ($pingarticlelist as $key => $value) {
			//if($value['dateline'] < $_G['timestamp']){
			$article_count = DB::fetch_first("SELECT catid,status FROM " . DB::table('portal_article_title') . " WHERE aid='$value[aid]' ORDER BY aid DESC");
			if (in_array($article_count['catid'], $splugin_setting['portal_nocatid'])) {
				C::t('#study_seo_ping#study_seo_ping_article')->delete_by_where(array('id' => $value['id']), 1);
				continue;
			}
			if ($article_count['status'] == 0) {
				superping_portal_run(array('aid' => $value['aid']));
			} elseif ($article_count['status'] == 1) {
				C::t('#study_seo_ping#study_seo_ping_article')->update_by_where(array('id' => $value['id']), array('dateline' => $_G['timestamp'] + 86400), 1);
			} else {
				C::t('#study_seo_ping#study_seo_ping_article')->delete_by_where(array('id' => $value['id']), 1);
			}
			//}
		}
	}
}