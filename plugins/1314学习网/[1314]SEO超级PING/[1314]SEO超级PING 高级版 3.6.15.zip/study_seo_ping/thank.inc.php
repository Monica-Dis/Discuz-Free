<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 2013090320ikG5iDN5qX
 * This is NOT a freeware, use is subject to license terms
 * From dism.taobao.com?
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once ('pluginvar.func.php');
splugin_thinks(CURMODULE);
?>