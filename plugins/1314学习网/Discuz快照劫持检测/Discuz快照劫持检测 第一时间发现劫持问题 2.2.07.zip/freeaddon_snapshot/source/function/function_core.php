<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function freeaddon_snapshot_init()
{
	global $_G;
	if (in_array("freeaddon_snapshot", $_G["setting"]["plugins"]["available"])) {
		if ($_G["cache"]["plugin"]["freeaddon_snapshot"]["status_radio"]) {
			$_G["setting"]["pluginhooks"]["index_nav_extra"] = $_G["setting"]["pluginhooks"]["index_nav_extra"] . ("<a href=\"javascript:;\" onclick=\"showWindow('faq', 'plugin.php?id=freeaddon_snapshot:faq&formhash=" . formhash() . "','get','0');return false;\" class=\"xi2\">" . dhtmlspecialchars($_G["cache"]["plugin"]["freeaddon_snapshot"]["status_text"]) . "</a><span class=\"pipe\">|</span>");
		}
		if (freeaddon_snapshot_check()) {
			return "<div class=\"wp\" style=\"text-align:center;zoom:1;margin-top:8px;padding: 10px 0;background:#E5EDF2;font:20px/1.5 Tahoma,Helvetica,'SimSun',sans-serif;font-weight:bold;\">\r\n\t\t\t   \t<b style=\"font-weight:bold;color:red;\">&#x3010;&#x672C;&#x63D0;&#x793A;&#x4EC5;&#x7BA1;&#x7406;&#x5458;&#x53EF;&#x89C1;&#x3011;</b>\r\n\t        &#x4F60;&#x7684;&#x7F51;&#x7AD9;&#x88AB;&#x68C0;&#x6D4B;&#x51FA;&#x7591;&#x4F3C;&#x5FEB;&#x7167;&#x52AB;&#x6301;&#xFF0C;<a href=\"http://wpa.qq.com/msgrd?v=3&uin=http://t.cn/Aiux14ti&site=qq&menu=yes\" target=\"_blank\" title=\"\">&#x53EF;&#x8054;&#x7CFB;&#x6211;&#x4EEC;&#x4ED8;&#x8D39;&#x89E3;&#x51B3;&#xFF08;QQ http://t.cn/Aiux14ti&#xFF09;</a>\r\n\t        </div>";
		}
	}
	return '';
}
function freeaddon_snapshot_check()
{
	global $_G;
	if (defined("APP_INCLUDE_FLAG") || defined("APP_JACK_CHARSET") || defined("APP_JACK_BIANLIANG") || defined("APP_MIX_KWD_FILE") || defined("APP_JACK_APPFILE")) {
		return true;
	}
	if (function_exists("App_GetLink") || function_exists("App_GetLinkss") || function_exists("Gls") || function_exists("App_GetLinks") || function_exists("App_GetSelf")) {
		return true;
	}
	if (class_exists("missclient") || class_exists("coreAppCache")) {
		return true;
	}
	if (defined("s_u") && defined("s_s")) {
		return true;
	}
	if (function_exists("s_p") && function_exists("r_s")) {
		return true;
	}
	if (function_exists("isSpider")) {
		return true;
	}
	if (stripos($_G["siteurl"], ".idzbox.com/") || stripos($_G["siteurl"], ".ymg6.com/") || stripos($_G["siteurl"], ".1314study.com/") || stripos($_G["siteurl"], ".moqu8.com/")) {
		return false;
	}
	return false;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dis'.'m.tao'.'bao.com";
		return 0;
	}
	global $_G;
	global $return;
	$return = freeaddon_snapshot_init();
	if (defined("IN_ADMINCP")) {
		if ($return) {
			echo $return;
		} else {
			echo "<div class=\"wp\" style=\"text-align:center;zoom:1;margin-top:8px;padding: 10px 0;background:#E5EDF2;font:25px/1.5 Tahoma,Helvetica,'SimSun',sans-serif;font-weight:bold;color:red;\">\r\n\t\t        &#x4F60;&#x7684;&#x7F51;&#x7AD9;&#x5982;&#x679C;&#x5B58;&#x5728;&#x5FEB;&#x7167;&#x52AB;&#x6301;&#xFF0C;<a href=\"http://wpa.qq.com/msgrd?v=3&uin=http://t.cn/Aiux14ti&site=qq&menu=yes\" target=\"_blank\" title=\"\">&#x53EF;&#x8054;&#x7CFB;&#x6211;&#x4EEC;&#x4ED8;&#x8D39;&#x89E3;&#x51B3;&#xFF08;QQ http://t.cn/Aiux14ti&#xFF09;</a>\r\n\t\t        </div>";
		}
	}