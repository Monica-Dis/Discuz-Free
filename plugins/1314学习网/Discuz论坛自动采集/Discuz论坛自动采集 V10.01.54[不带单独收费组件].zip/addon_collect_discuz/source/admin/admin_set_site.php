<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("function/core", "plugin/addon_collect_discuz/source");
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	global $posttypelist;
	global $portalcategory;
	global $rules_config;
	require_once libfile("function/forumlist");
	$_var_14 = array("list", "edit");
	$op = in_array($_GET["op"], $_var_14) ? $_GET["op"] : "list";
	$ac = '';
	$_var_15 = $rules_config = array();
	$_var_16 = DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/source/component/";
	if (is_dir($_var_16)) {
		@(include_once $_var_16 . "/discuz/discuz_config.php");
		if ($rules_config) {
			$_var_15["discuz"] = $rules_config;
		}
		if ($_var_17 = @dir($_var_16)) {
			while ($_var_18 = $_var_17->read()) {
				if ($_var_18 == "." || $_var_18 == ".." || $_var_18 == ".svn" || $_var_18 == "discuz") {
					continue;
				}
				$_var_19 = $_var_16 . "/" . $_var_18;
				if (is_dir($_var_19)) {
					$_var_20 = $_var_19 . "/" . $_var_18 . "_config.php";
					if (is_file($_var_20) && fileext($_var_20) == "php") {
						$rules_config = array();
						@(include_once $_var_20);
						if ($rules_config) {
							$rules_config["rulesid"] = $_var_18;
							$_var_15[$rules_config["rulesid"]] = $rules_config;
						}
					}
				}
			}
			$_var_17->close();
		}
	}
	$_var_21 = array();
	foreach ($_var_15 as $_var_22 => $_var_23) {
		$_var_21[$_var_22] = $_var_23["name"];
	}
	$_var_24 = array("gbk_sc" => "&#31616;&#20307;&#71;&#66;&#75;&#32534;&#30721;", "utf8_sc" => "&#31616;&#20307;&#85;&#84;&#70;&#56;&#32534;&#30721;", "utf8_tc" => "&#32321;&#20307;&#85;&#84;&#70;&#56;&#32534;&#30721;", "big5_tc" => "&#32321;&#20307;&#66;&#73;&#71;&#53;&#32534;&#30721;");
	if ($op == "list") {
		if (!submitcheck("submit")) {
			showtips("\r\n\t\t    <li><b style=\"color:red\">&#x63D2;&#x4EF6;&#x4EC5;&#x4F9B;&#x6536;&#x96C6;&#x6587;&#x7AE0;&#xFF0C;&#x65B9;&#x4FBF;&#x9605;&#x8BFB;&#xFF0C;&#x60A8;&#x9700;&#x8981;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x6587;&#x7AE0;&#x7248;&#x6743;&#x98CE;&#x9669;&#xFF0C;&#x672A;&#x83B7;&#x5F97;&#x539F;&#x6587;&#x4F5C;&#x8005;&#x6388;&#x6743;&#x7684;&#x60C5;&#x51B5;&#x4E0B;&#xFF0C;&#x8BF7;&#x52FF;&#x5C06;&#x6587;&#x7AE0;&#x516C;&#x5F00;&#x53D1;&#x5E03;&#x6216;&#x7528;&#x4E8E;&#x5546;&#x4E1A;&#x7528;&#x9014;&#x3002;</b></li>\r\n\t\t    <li>&#x53EA;&#x6709;&#x7F51;&#x7AD9;&#x7F51;&#x5740;&#x3001;&#x91C7;&#x96C6;&#x89C4;&#x5219;&#x3001;&#x8BBA;&#x575B;&#x7F16;&#x7801;&#x90FD;&#x8BBE;&#x7F6E;&#x4E86;&#x624D;&#x53EF;&#x4EE5;&#x542F;&#x7528;&#x7F51;&#x7AD9;&#xFF0C;&#x5220;&#x9664;&#x7F51;&#x7AD9;&#x65F6;&#x4F1A;&#x81EA;&#x52A8;&#x5220;&#x9664;&#x7F51;&#x7AD9;&#x4E0B;&#x7684;&#x722C;&#x866B;&#x548C;&#x6587;&#x7AE0;&#x3002;</li>\r\n\t\t    <li>&#x5982;&#x679C;&#x81EA;&#x5E26;&#x7684;Discuz&#x8BBA;&#x575B;&#x9ED8;&#x8BA4;&#x89C4;&#x5219;&#x65E0;&#x6CD5;&#x6B63;&#x5E38;&#x91C7;&#x96C6;&#x4F60;&#x8BBE;&#x7F6E;&#x7684;&#x7F51;&#x7AD9;&#xFF0C;&#x53EF;&#x8054;&#x7CFB;&#x6211;&#x4EEC;&#x5B9A;&#x5236;&#x91C7;&#x96C6;&#x89C4;&#x5219;&#xFF0C;QQ&#xFF1A;http://t.cn/Aiux14ti</li>\r\n\t\t    ", "tips", true, "&#x6280;&#x5DE7;&#x63D0;&#x793A; - " . dgmdate($_G["timestamp"], "Y-m-d H:i:s", $_G["setting"]["timeoffset"]));
			s_shownav("sort", "sorts_admin");
			showtableheader("&#x7F51;&#x7AD9;&#x7BA1;&#x7406;");
			showtablefooter();
			$_GET["f_kw"] = trim($_GET["f_kw"]);
			if ($_GET["formhash"] != $_G["formhash"]) {
				$_GET["f_kw"] = '';
			}
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac);
			echo "&nbsp;&nbsp;&#x7F51;&#x7AD9;&#x641C;&#x7D20;&nbsp;&nbsp;<input type=\"text\" name=\"f_kw\" value=\"" . dhtmlspecialchars($_GET["f_kw"]) . "\" class=\"px vm\" autocomplete=\"off\" placeholder=\"&#x8BF7;&#x8F93;&#x5165;&#x7F51;&#x7AD9;&#x540D;&#x79F0;\">&nbsp;&nbsp;\r\n\t\t\t\t<button type=\"submit\" class=\"pn\" name=\"search\" id=\"submit_search\" value=\"true\"><span class=\"xi1 xw1\">&#x641C;&#x7D22;</span></button>\r\n\t\t    &nbsp;&nbsp;\r\n\t\t    <script type=\"text/JavaScript\">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'search'); });</script>\r\n\t\t    ";
			showtablefooter();
			showformfooter();
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "class=\"siteform\"", "siteform");
			showtableheader('');
			$portalcategory = array();
			loadcache("portalcategory");
			$portalcategory = $_G["cache"]["portalcategory"];
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x7F51;&#x7AD9;&#x540D;&#x79F0;", "&#32593;&#31449;&#32593;&#22336;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#37319;&#38598;&#35268;&#21017;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#35770;&#22363;&#32534;&#30721;<b style=\"color:red\">&#xFF08;&#x5FC5;&#x586B;&#xFF09;</b>", "&#26159;&#21542;&#21551;&#29992;", ''));
			$_var_28 = array();
			if ($_GET["f_kw"]) {
				$_GET["f_kw"] = addslashes($_GET["f_kw"]);
				$_var_28["name"] = array("%" . addcslashes($_GET["f_kw"], "%_") . "%", "like");
			}
			$_var_29 = 30;
			$_var_30 = 100;
			$_var_31 = C::t("#addon_collect_discuz#addon_collect_discuz_site")->count_by_where($_var_28);
			$_var_32 = $_G["page"] - 1 > $_var_31 / $_var_29 || $_G["page"] > $_var_30 ? 1 : $_G["page"];
			$_var_33 = ($_var_32 - 1) * $_var_29;
			$_var_34 = multi($_var_31, $_var_29, $_var_32, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . ($_GET["f_kw"] ? "&formhash=" . $_G["formhash"] . "&search=ok&f_kw=" . urlencode($_GET["f_kw"]) : ''), $_var_30);
			$_var_35 = C::t("#addon_collect_discuz#addon_collect_discuz_site")->fetch_all_by_search($_var_28, array("displayorder" => "ASC", "id" => "DESC"), $_var_33, $_var_29);
			foreach ($_var_35 as $_var_36) {
				$_var_37 = 1;
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td28\"", " style=\"width:60px;\"", " style=\"width:60px;\"", " style=\"width:100px;\"", ''), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_36["id"] . "\" " . $_var_38 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_36["id"] . "]\" value=\"" . $_var_36["displayorder"] . "\" style=\"height: 20px;\">", "<input type=\"text\" name=\"name[" . $_var_36["id"] . "]\" value=\"" . $_var_36["name"] . "\" class=\"txt\" style=\"width: 120px;height: 20px;\">", "<input type=\"text\" name=\"siteurl[" . $_var_36["id"] . "]\" value=\"" . $_var_36["siteurl"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", addon_collect_discuz_rulesselect($_var_21, $_var_36["rules"], $_var_36["id"]), addon_collect_discuz_charsetselect($_var_24, $_var_36["charset"], $_var_36["id"]), "<div style=\"width:30px;\"><input name=\"status[" . $_var_36["id"] . "]\" type=\"checkbox\" value=\"1\" " . ($_var_36["status"] ? "checked=\"checked=\"" : '') . "/></div>", ''));
			}
			echo "<tr><td></td><td colspan=\"13\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">&#x6DFB;&#x52A0;&#x7F51;&#x7AD9;</a></div></td></tr>";
			echo "\r\n<style>\r\n.siteform .catid{\r\nmargin-right: 10px;\r\nwidth: 128px;\r\n}\r\n.td28{width:100px;}\r\n</style>\r\n<script type=\"text/JavaScript\">\r\n\r\nvar rowtypedata = new Array();\r\nrowtypedata[0] = [\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, '<input type=\"text\" class=\"txt\" name=\"neworder[]\" style=\"height: 20px;\"/>', \"td25\"],\r\n\t\t\t[1, '<input type=\"text\" class=\"txt\" name=\"newname[]\" style=\"width: 120px;height: 20px;\"/>', \"td28\"],\r\n\t\t\t[1, '<input type=\"text\" name=\"newsiteurl[]\" value=\"\" class=\"txt\" style=\"width: 150px;height: 20px;\">'],\r\n\t\t\t[1, '" . addon_collect_discuz_rulesselect($_var_21, "discuz", 0, 1) . "'],\r\n\t\t\t[1, '" . addon_collect_discuz_charsetselect($_var_24, "utf8_sc", 0, 1) . "'],\r\n\t\t\t[1, '<div><a href=\"javascript:;\" class=\"deleterow\" onClick=\"deleterow(this)\">" . cplang("delete") . "</a></div>'],\r\n\t\t\t[1, \"\"],\r\n\t\t\t[1, \"\"],\r\n\t\t];\r\n</script>";
			showsubmit("submit", "submit", "del", '', $_var_34, false);
			showtablefooter();
			showformfooter();
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_22) {
					$_var_22 = intval($_var_22);
					C::t("#addon_collect_discuz#addon_collect_discuz_site")->delete_by_where(array("id" => $_var_22), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_22 => $_var_23) {
					$_POST["siteurl"][$_var_22] = trim($_POST["siteurl"][$_var_22]);
					if (empty($_POST["siteurl"][$_var_22])) {
						cpmsg_error("&#32593;&#22336;&#19981;&#33021;&#20026;&#31354;");
					}
					$_var_39 = parse_url($_POST["siteurl"][$_var_22]);
					if (!in_array($_var_39["scheme"], array("http", "https"))) {
						cpmsg_error("&#32593;&#22336;&#26684;&#24335;&#38169;&#35823;&#65292;&#31034;&#20363;&#65306;http://www.discuz.net/");
					}
					$_POST["siteurl"][$_var_22] = $_POST["siteurl"][$_var_22] . (substr($_POST["siteurl"][$_var_22], -1) == "/" ? '' : "/");
					$_var_40 = array("siteurl" => $_POST["siteurl"][$_var_22], "status" => $_POST["status"][$_var_22] ? 1 : 0, "rules" => !empty($_POST["rules"][$_var_22]) && isset($_var_21[$_POST["rules"][$_var_22]]) ? $_POST["rules"][$_var_22] : "discuz", "charset" => !empty($_POST["charset"][$_var_22]) && isset($_var_24[$_POST["charset"][$_var_22]]) ? $_POST["charset"][$_var_22] : "utf8_sc", "displayorder" => $_POST["order"][$_var_22]);
					if (!empty($_POST["name"][$_var_22])) {
						$_var_40["name"] = $_POST["name"][$_var_22];
					}
					if (empty($_var_40["siteurl"])) {
						$_var_40["status"] = 0;
					}
					C::t("#addon_collect_discuz#addon_collect_discuz_site")->update($_var_22, $_var_40);
				}
			}
			if (empty($_statInfo["SiteID"])) {
				C::t("common_plugin")->delete_by_identifier("addon_collect_wechat");
			}
			if (is_array($_GET["newname"])) {
				foreach ($_GET["newname"] as $_var_22 => $_var_41) {
					$_POST["newsiteurl"][$_var_22] = trim($_POST["newsiteurl"][$_var_22]);
					if (empty($_POST["newsiteurl"][$_var_22])) {
						cpmsg_error("&#32593;&#22336;&#19981;&#33021;&#20026;&#31354;");
					}
					$_POST["newsiteurl"][$_var_22] = preg_replace("#/forum\\.php(\\?.*)?\$#i", "/", $_POST["newsiteurl"][$_var_22]);
					$_POST["newsiteurl"][$_var_22] = preg_replace("#/forum-([\\w-]+)\\.html\$#i", "/", $_POST["newsiteurl"][$_var_22]);
					$_var_39 = parse_url($_POST["newsiteurl"][$_var_22]);
					if (!in_array($_var_39["scheme"], array("http", "https"))) {
						cpmsg_error("&#32593;&#22336;&#26684;&#24335;&#38169;&#35823;&#65292;&#31034;&#20363;&#65306;http://www.discuz.net/");
					}
					$_POST["newsiteurl"][$_var_22] = $_POST["newsiteurl"][$_var_22] . (substr($_POST["newsiteurl"][$_var_22], -1) == "/" ? '' : "/");
					if (empty($_var_41)) {
						$_var_41 = $_var_39["host"];
					}
					$_var_40 = array("name" => $_var_41, "siteurl" => $_POST["newsiteurl"][$_var_22], "rules" => !empty($_POST["newrules"][$_var_22]) && isset($_var_21[$_POST["newrules"][$_var_22]]) ? $_POST["newrules"][$_var_22] : "discuz", "charset" => !empty($_POST["newcharset"][$_var_22]) && isset($_var_24[$_POST["newcharset"][$_var_22]]) ? $_POST["newcharset"][$_var_22] : "utf8_sc", "status" => 1, "creattime" => $_G["timestamp"], "displayorder" => $_GET["neworder"][$_var_22]);
					if (empty($_var_40["siteurl"])) {
						$_var_40["status"] = 0;
					}
					C::t("#addon_collect_discuz#addon_collect_discuz_site")->insert($_var_40, 1);
				}
			}
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac, "succeed");
		}
	} else {
		if ($op == "edit") {
			require_once libfile("include/site", "plugin/addon_collect_discuz/source");
		}
	}