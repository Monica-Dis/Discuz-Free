<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_discuz_rule_dealtime($_arg_0)
{
	global $_G;
	$_var_2 = false;
	$_var_3 = dgmdate($_G["timestamp"], "H", $_G["setting"]["timeoffset"]);
	$_var_4 = explode("-", $_arg_0);
	$_var_4[0] = intval(trim($_var_4[0]));
	if ($_var_4[0] < 0 || $_var_4[0] >= 24) {
		$_var_4[0] = 0;
	}
	$_var_4[1] = intval(trim($_var_4[1]));
	if ($_var_4[1] <= 0 || $_var_4[1] > 24) {
		$_var_4[1] = 24;
	}
	if ($_var_3 >= $_var_4[0] && $_var_3 <= $_var_4[1]) {
		$_var_2 = true;
	}
	return $_var_2;
}
function addon_collect_discuz_rule_getcontent($_arg_0)
{
	global $_G;
	if (!preg_match("#^[a-z0-9_]+\$#i", $_arg_0["rules"])) {
		$_arg_0["rules"] = '';
	}
	$_var_2 = "addon_collect_discuz_getcontent_" . $_arg_0["rules"];
	if (function_exists($_var_2)) {
		return call_user_func($_var_2, $_arg_0);
	}
	$_var_3 = $_arg_0["url"];
	$_var_4 = curl_init();
	$_var_5 = '';
	if (strpos($_var_3, "www.discuz.net") !== false) {
		$_var_5 = DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/images/discuz.tmp";
	}
	$_var_6 = addon_collect_discuz_rule_get_rand_ip();
	$_var_7 = 10;
	curl_setopt($_var_4, CURLOPT_URL, $_var_3);
	curl_setopt($_var_4, CURLOPT_TIMEOUT, 30);
	curl_setopt($_var_4, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_var_6 . '', "CLIENT-IP:" . $_var_6 . ''));
	$_var_8 = array("Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)");
	$_var_9 = parse_url($_var_3);
	if (!in_array($_var_9["host"], array("www.jy5201.com", "bbs.0550.com"))) {
		curl_setopt($_var_4, CURLOPT_USERAGENT, $_var_8[0]);
	}
	curl_setopt($_var_4, CURLOPT_HTTPHEADER, array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", "Accept-Language: zh-CN,zh;q=0.8"));
	curl_setopt($_var_4, CURLOPT_REFERER, $_var_3);
	curl_setopt($_var_4, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_4, CURLOPT_HEADER, 0);
	if (preg_match("/^https:\\/\\//i", $_var_3)) {
		curl_setopt($_var_4, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($_var_4, CURLOPT_SSL_VERIFYHOST, false);
	}
	if (!empty($_var_5) && file_exists($_var_5)) {
		curl_setopt($_var_4, CURLOPT_COOKIEJAR, $_var_5);
		curl_setopt($_var_4, CURLOPT_COOKIEFILE, $_var_5);
	}
	curl_setopt($_var_4, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($_var_4, CURLOPT_MAXREDIRS, 3);
	curl_setopt($_var_4, CURLOPT_CONNECTTIMEOUT, $_var_7);
	$_var_10 = curl_exec($_var_4);
	curl_close($_var_4);
	return $_var_10;
}
function addon_collect_discuz_fcjtimecheck()
{
	global $_G;
	$_var_1 = true;
	return $_var_1;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}