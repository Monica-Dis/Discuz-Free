<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	global $op;
	global $ac;
	$_var_11 = intval($_GET["spiderid"]);
	if (!submitcheck("submit")) {
		$_var_12 = C::t("#addon_collect_discuz#addon_collect_discuz_spider")->fetch_by_search(array("id" => $_var_11));
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $ac . "&spiderid=" . $_var_11);
		showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
		s_showsetting("&#x722C;&#x866B;&#x540D;&#x79F0;", "name", $_var_12["name"], "text", '', '', '');
		s_showsetting("&#x7248;&#x5757;&#x94FE;&#x63A5;", "url", $_var_12["url"], "text", '', '', '');
		if ($_var_12["posttype"] == 1 && $_var_12["catid"]) {
			$_var_13 = C::t("forum_threadclass")->fetch_all_by_fid($_var_12["catid"]);
			if (is_array($_var_13) && !empty($_var_13)) {
				$_var_14 = array(array(0, "&#x8BF7;&#x9009;&#x62E9;&#x4E3B;&#x9898;&#x5206;&#x7C7B;"));
				foreach ($_var_13 as $_var_15) {
					$_var_14[] = array($_var_15["typeid"], $_var_15["name"]);
				}
				s_showsetting("&#x4E3B;&#x9898;&#x5206;&#x7C7B;", array("typeid", $_var_14), $_var_12["typeid"], "select", '', '', '');
			}
		}
		$_var_16 = !empty($_var_12["configs"]) ? dunserialize($_var_12["configs"]) : array();
		if (!is_array($_var_16)) {
			$_var_16 = array();
		}
		if (!isset($_var_16["censor"])) {
			$_var_16["censor"] = '';
		}
		s_showsetting("&#x5C4F;&#x853D;&#x5173;&#x952E;&#x5B57;", "censor", $_var_16["censor"], "textarea", '', '', "&#x6BCF;&#x4E2A;&#x5173;&#x952E;&#x5B57;&#x4E00;&#x884C;&#xFF0C;&#x6587;&#x7AE0;&#x4E2D;&#x51FA;&#x73B0;&#x8FD9;&#x4E9B;&#x5173;&#x952E;&#x5B57;&#x5C06;&#x4E0D;&#x4F1A;&#x53D1;&#x5E03;&#x6210;&#x529F;");
		if (!isset($_var_16["censor_picmd5"])) {
			$_var_16["censor_picmd5"] = '';
		}
		s_showsetting("&#x81EA;&#x52A8;&#x5220;&#x9664;&#x7684;&#x56FE;&#x7247;&#x7684;MD5&#x503C;", "censor_picmd5", $_var_16["censor_picmd5"], "textarea", '', '', "&#x6BCF;&#x4E2A;MD5&#x4E00;&#x884C;&#xFF0C;&#x56DE;&#x8F66;&#x6362;&#x884C;&#xFF0C;&#x6587;&#x7AE0;&#x4E2D;&#x51FA;&#x73B0;&#x8FD9;&#x4E9B;MD5&#x503C;&#x7684;&#x56FE;&#x7247;&#x5C06;&#x4F1A;&#x81EA;&#x52A8;&#x5220;&#x9664;&#x5BF9;&#x5E94;&#x56FE;&#x7247;&#x3002;<br>&#x672C;&#x529F;&#x80FD;&#x4EC5;&#x5728;&#x56FE;&#x7247;&#x672C;&#x5730;&#x5316;&#x65F6;&#x6709;&#x6548;");
		s_showsetting("&#x53D1;&#x5E03;&#x8005;UID", "study_post_uids", $_var_16["study_post_uids"], "text", '', '', "&#x3010;&#x6307;&#x5B9A;UID&#x968F;&#x673A;&#x3011;&#x5982;&#xFF1A;2,3,5,7,6 &#xFF08;&#x6570;&#x5B57;&#x4E4B;&#x95F4;&#x4F7F;&#x7528;&#x82F1;&#x6587;&#x7684;&#x9017;&#x53F7;&#x5206;&#x9694;&#xFF0C;uid&#x6570;&#x91CF;&#x5927;&#x4E8E;3&#x4E2A;&#xFF09;<br>&#x3010;&#x6307;&#x5B9A;UID&#x8303;&#x56F4;&#x968F;&#x673A;&#x3011;&#x5982;&#xFF1A;2-100 &#x6216; 2,100 &#xFF0C;&#x8868;&#x793A;UID 2-100&#x4E4B;&#x95F4;&#x968F;&#x673A;&#xFF08;&#x5F53;&#x4F7F;&#x7528;&#x82F1;&#x6587;&#x9017;&#x53F7;&#x5206;&#x9694;&#xFF0C;uid&#x4E3A;&#x4E24;&#x4E2A;&#x65F6;&#x81EA;&#x52A8;&#x8BA4;&#x4E3A;&#x662F;UID&#x8303;&#x56F4;&#x968F;&#x673A;&#xFF09;<br>&#x5982;&#x679C;&#x4E3A;&#x7A7A;&#xFF0C;&#x5219;&#x8C03;&#x7528;&#x5168;&#x5C40;&#x8BBE;&#x7F6E;&#x91CC;&#x7684;&#x53D1;&#x5E03;&#x8005;UID");
		showtableheader();
		showsubmit("submit", "submit");
		showformfooter();
	} else {
		$_var_17 = array("name" => $_POST["name"], "url" => $_POST["url"], "typeid" => dintval($_POST["typeid"]));
		$_var_16 = array();
		if (isset($_POST["censor"])) {
			$_var_16["censor"] = trim(preg_replace("/\\s*(\r\n|\n\r|\n|\r)\\s*/", "\r\n", $_POST["censor"]));
		}
		if (isset($_POST["censor_picmd5"])) {
			$_var_16["censor_picmd5"] = trim(preg_replace("/\\s*(\r\n|\n\r|\n|\r)\\s*/", "\r\n", $_POST["censor_picmd5"]));
		}
		if (isset($_POST["study_post_uids"])) {
			$_var_16["study_post_uids"] = trim($_POST["study_post_uids"]);
		}
		if (isset($_POST["study_reply_uids"])) {
			$_var_16["study_reply_uids"] = trim($_POST["study_reply_uids"]);
		}
		$_var_17["configs"] = serialize($_var_16);
		C::t("#addon_collect_discuz#addon_collect_discuz_spider")->update($_var_11, $_var_17, 1);
		cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&spiderid=" . $_var_11, "succeed");
	}