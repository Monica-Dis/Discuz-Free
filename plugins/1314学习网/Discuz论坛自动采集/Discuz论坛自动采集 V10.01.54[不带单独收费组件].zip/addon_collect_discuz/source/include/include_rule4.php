<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_discuz_rule_analyze($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = array();
	$_var_4 = false;
	$_var_5 = $_arg_0["current_page"] > 1 ? 20 * $_arg_0["current_page"] : 0;
	$_var_6 = explode("_", $_arg_0["charset"]);
	$_arg_0["charset"] = $_var_6[0];
	$_arg_0["page"] = max(1, $_arg_0["page"]);
	$_arg_0["articlelist"] = $_var_3 = array();
	if (preg_match("#\\.discuz\\.net#is", $_arg_0["siteurl"])) {
		$_var_3 = C::t("#addon_collect_discuz#addon_collect_discuz_articlelist")->fetch_by_search(array(), array("id" => "DESC"));
		if ($_var_3["id"] > 100) {
			if (defined("IN_ADMINCP")) {
				cpmsg("addon_collect_discuz:error_discuzlimit", '', "error");
			}
			return $_arg_0;
		}
	}
	if (!preg_match("#^[a-z0-9_]+\$#i", $_arg_0["rules"])) {
		$_arg_0["rules"] = "discuz";
	}
	if (file_exists(DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/source/component/" . $_arg_0["rules"] . "/" . $_arg_0["rules"] . "_rules.php")) {
		require_once libfile($_arg_0["rules"] . "/rules", "plugin/addon_collect_discuz/source/component");
		$_arg_0 = call_user_func("addon_collect_discuz_analyze_" . $_arg_0["rules"], $_arg_0);
	} else {
		require_once libfile("discuz/rules", "plugin/addon_collect_discuz/source/component");
		$_arg_0 = addon_collect_discuz_analyze_discuz($_arg_0);
	}
	foreach ($_arg_0["articlelist"] as $_var_7 => $_var_3) {
		if (empty($_var_3["url"]) && !empty($_var_3["group_id"])) {
			$_var_3["url"] = "forum.php?mod=viewthread&tid=" . $_var_3["group_id"];
		}
		$_var_3["subject"] = diconv($_var_3["subject"], $_arg_0["charset"], "UTF-8");
		$_var_3["subject"] = htmlspecialchars_decode($_var_3["subject"], ENT_QUOTES);
		$_var_3["subject"] = html_entity_decode($_var_3["subject"], ENT_QUOTES, "UTF-8");
		if (!empty($_var_3["url"]) && !empty($_var_3["subject"])) {
			$_var_3["subject"] = strip_tags(diconv($_var_3["subject"], "UTF-8", CHARSET));
			$_var_3["url"] = diconv($_var_3["url"], $_arg_0["charset"], CHARSET);
			if (!preg_match("/^https?:\\/\\//i", $_var_3["url"])) {
				$_var_3["url"] = $_arg_0["siteurl"] . $_var_3["url"];
			}
			$_arg_0["articlelist"][$_var_7] = $_var_3;
		}
	}
	return $_arg_0;
}
function addon_collect_discuz_rule_comment($_arg_0, $_arg_1, $_arg_2, $_arg_3 = "aid")
{
	global $_G;
	$_arg_1 = intval($_arg_1);
	if (empty($_arg_1)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = getstr($_arg_2, 0, 0, 0, 1, 0);
	if (strlen($_arg_2) < 2) {
		return "content_is_too_short";
	}
	$_arg_3 = in_array($_arg_3, array("aid", "topicid")) ? $_arg_3 : "aid";
	$_var_5 = $_arg_3 == "aid" ? "portal_article_title" : "portal_topic";
	$_var_6 = C::t($_var_5)->fetch($_arg_1);
	if (empty($_var_6)) {
		return "comment_comment_noexist";
	}
	$_arg_2 = censor($_arg_2);
	if (censormod($_arg_2)) {
		$_var_7 = 1;
	} else {
		$_var_7 = 0;
	}
	$_var_8 = array("uid" => $_arg_0["uid"], "username" => $_arg_0["username"], "id" => $_arg_1, "idtype" => $_arg_3, "postip" => "127.0.0.1", "dateline" => $_arg_0["comment_time"], "status" => $_var_7, "message" => $_arg_2);
	$_var_9 = C::t("portal_comment")->insert($_var_8, true);
	if ($_var_7 == 1) {
		updatemoderate($_arg_3 . "_cid", $_var_9);
		$_var_10 = $_arg_3 == "aid" ? "verifyacommont" : "verifytopiccommont";
		manage_addnotify($_var_10);
	}
	$_var_5 = $_arg_3 == "aid" ? "portal_article_count" : "portal_topic";
	C::t($_var_5)->increase($_arg_1, array("commentnum" => 1));
	C::t("common_member_status")->update($_G["uid"], array("lastpost" => $_G["timestamp"]), "UNBUFFERED");
	return "do_success";
}
function addon_collect_discuz_rule_wyc($_arg_0)
{
	global $_G;
	if (!isset($_G["toutiao_wyc_keywords"])) {
		$_G["toutiao_wyc_keywords"]["find"] = array();
		$_G["toutiao_wyc_keywords"]["replace"] = array();
		$_var_2 = explode("\n", str_replace("\r\n", "\n", $_G["cache"]["plugin"]["addon_collect_discuz"]["wyc_keywords"]));
		if (is_array($_var_2) && !empty($_var_2)) {
			foreach ($_var_2 as $_var_3) {
				$_var_4 = explode("==", $_var_3);
				if ($_var_4[0] && $_var_4[1]) {
					$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
					$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
				}
			}
		}
		if (is_file(DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/images/keywords.tmp")) {
			$_var_5 = @file(DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/images/keywords.tmp");
			if (is_array($_var_5) && !empty($_var_5)) {
				foreach ($_var_5 as $_var_3) {
					$_var_4 = explode("==", trim($_var_3));
					if ($_var_4[0] && $_var_4[1] && !in_array($_var_4[0], $_G["toutiao_wyc_keywords"]["find"])) {
						$_G["toutiao_wyc_keywords"]["find"][] = $_var_4[0];
						$_G["toutiao_wyc_keywords"]["replace"][] = $_var_4[1];
					}
				}
			}
		}
	}
	if (isset($_G["toutiao_wyc_keywords"]["find"]) && is_array($_G["toutiao_wyc_keywords"]["find"])) {
		$_arg_0 = str_replace($_G["toutiao_wyc_keywords"]["find"], $_G["toutiao_wyc_keywords"]["replace"], $_arg_0);
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}