<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_discuz_rule_summary($_arg_0)
{
	$_arg_0 = preg_replace(array("/\\[attach\\].*?\\[\\/attach\\]/", "/\\&[a-z]+\\;/i", "/\\<script.*?\\<\\/script\\>/"), '', $_arg_0);
	$_arg_0 = preg_replace("/\\[.*?\\]/", '', $_arg_0);
	$_arg_0 = getstr(strip_tags($_arg_0), 200);
	return $_arg_0;
}
function addon_collect_discuz_rule_spider($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = $_var_4 = array();
	$_arg_0["error"] = '';
	$_var_5 = explode("_", $_arg_0["charset"]);
	$_arg_0["charset"] = $_var_5[0];
	if (!preg_match("#^[a-z0-9_]+\$#i", $_arg_0["rules"])) {
		$_arg_0["rules"] = "discuz";
	}
	if (file_exists(DISCUZ_ROOT . "./source/plugin/addon_collect_discuz/source/component/" . $_arg_0["rules"] . "/" . $_arg_0["rules"] . "_rules.php")) {
		require_once libfile($_arg_0["rules"] . "/rules", "plugin/addon_collect_discuz/source/component");
		$_var_6 = "addon_collect_discuz_spider_" . $_arg_0["rules"];
	} else {
		require_once libfile("discuz/rules", "plugin/addon_collect_discuz/source/component");
		$_var_6 = "addon_collect_discuz_spider_discuz";
	}
	$_arg_0["original_url"] = $_arg_0["url"];
	if (!preg_match("/^https?:\\/\\/\$/i", $_arg_0["url"]) && $_arg_0["group_id"]) {
		$_arg_0["url"] = $_arg_0["siteurl"] . "forum.php?mod=viewthread&tid=" . $_arg_0["group_id"];
		$_var_7 = parse_url($_arg_0["siteurl"]);
		if (in_array($_var_7["host"], array("www.52ghai.com"))) {
			$_arg_0["url"] = $_arg_0["siteurl"] . "thread-" . $_arg_0["group_id"] . "-1-1.html";
		}
	}
	$_arg_0["content"] = addon_collect_discuz_rule_getcontent($_arg_0);
	if (empty($_arg_0["charset"])) {
		preg_match("#content=\"text/html; charset=gbk\">#is", $_arg_0["content"], $_var_4);
		if (empty($_var_4[0])) {
			$_arg_0["charset"] = "utf-8";
		} else {
			$_arg_0["charset"] = "gbk";
		}
	}
	if ($_arg_0["debug"]) {
		$_arg_0["debug_content"] = $_arg_0["content"];
	}
	$_arg_0["content"] = diconv($_arg_0["content"], $_arg_0["charset"], CHARSET);
	$_arg_0["content"] = str_replace("&#x3D;", "=", $_arg_0["content"]);
	preg_match("#<div id=\"messagetext\" class=\"alert_error\">\\s+<p>(.*?)</p>#is", $_arg_0["content"], $_var_4);
	if (!empty($_var_4[0])) {
		$_arg_0["error"] = "error";
		$_arg_0["error_info"] = dhtmlspecialchars(strip_tags($_var_4[1]));
		return $_arg_0;
	}
	preg_match("#class=\"y viewpay\"#is", $_arg_0["content"], $_var_4);
	if (!empty($_var_4[0])) {
		$_arg_0["error"] = "viewpay";
		return $_arg_0;
	}
	$_arg_0["content"] = preg_replace("#<div class=\"locked\">(.*?)</div>#is", '', $_arg_0["content"]);
	$_arg_0 = call_user_func($_var_6, $_arg_0);
	if (!empty($_arg_0["error"])) {
		return $_arg_0;
	}
	if ($_arg_0["posttype"] != 2) {
		$_arg_0["message"] = preg_replace("#<div class=\"showhide\"><h4>[^>]+</h4>(.*?)</div>#is", "[hide]\\1[/hide]", $_arg_0["message"]);
	}
	if (!empty($_arg_0["message"])) {
		if (isset($_arg_0["configs"]["censor"]) && !empty($_arg_0["configs"]["censor"])) {
			$_var_8 = "/(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_arg_0["configs"]["censor"] = trim($_arg_0["configs"]["censor"]), "/")) . ")/i";
			if ($_arg_0["configs"]["censor"] && @preg_match($_var_8, strip_tags($_arg_0["subject"] . $_arg_0["message"]))) {
				$_arg_0["error"] = "censor";
				return $_arg_0;
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["gb2312tobig5_radio"]) {
			if ($_arg_0["debug"] && $_GET["debug_message_big5"]) {
				$_arg_0["debug_message_big5"] = $_arg_0["message"];
			}
			$_arg_0["message"] = addon_collect_discuz_rule_gb2312tobig5($_arg_0["message"]);
		}
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["wyc_radio"]) {
			$_arg_0["subject"] = addon_collect_discuz_rule_wyc($_arg_0["subject"]);
			$_arg_0["message"] = addon_collect_discuz_rule_wyc($_arg_0["message"]);
			if (!empty($_arg_0["comments"]) && is_array($_arg_0["comments"])) {
				foreach ($_arg_0["comments"] as $_var_9 => $_var_10) {
					$_arg_0["comments"][$_var_9] = addon_collect_discuz_rule_wyc($_var_10);
				}
			}
			if ($_arg_0["debug"] && $_GET["debug_message_wyc"]) {
				$_arg_0["debug_message_wyc"] = $_arg_0["message"];
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["from_head_radio"]) {
			$_arg_0["message"] = ($_G["cache"]["plugin"]["addon_collect_discuz"]["from_head_format"] ? str_replace(array("{url}", "{author}"), array($_arg_0["url"], $_arg_0["author"]), $_G["cache"]["plugin"]["addon_collect_discuz"]["from_head_format"]) . "<br>" : '') . $_arg_0["message"];
		}
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["from_radio"]) {
			$_arg_0["message"] = $_arg_0["message"] . ($_G["cache"]["plugin"]["addon_collect_discuz"]["from_format"] ? "<br>" . str_replace(array("{url}", "{author}"), array($_arg_0["url"], $_arg_0["author"]), $_G["cache"]["plugin"]["addon_collect_discuz"]["from_format"]) : '');
		}
	}
	if (!$_arg_0["debug"]) {
		unset($_arg_0["content"]);
	}
	return $_arg_0;
}
function addon_collect_discuz_rule_callback_code($_arg_0)
{
	$_var_1 = $_var_2 = '';
	if (!empty($_arg_0[1])) {
		$_arg_0[1] = $_arg_0[1] . "</em>";
		$_arg_0[1] = preg_replace("#<em ([^<]+)</em>#is", '', $_arg_0[1]);
		$_arg_0[1] = str_replace(array("<li>", "</li>", "<ol>", "</ol>", "</div>"), '', $_arg_0[1]);
		$_arg_0[1] = str_replace("<br />", '', $_arg_0[1]);
		$_var_1 = "[code]" . $_arg_0[1] . "[/code]";
	} else {
		$_var_1 = $_arg_0[0];
	}
	return $_var_1;
}
function addon_collect_discuz_rule_callback_code2($_arg_0)
{
	$_var_1 = $_var_2 = '';
	if (!empty($_arg_0[1])) {
		$_arg_0[1] = nl2br($_arg_0[1]);
		$_var_1 = "[code]" . $_arg_0[1] . "[/code]";
	} else {
		$_var_1 = $_arg_0[0];
	}
	return $_var_1;
}
function addon_collect_discuz_rule_callback_img($_arg_0)
{
	global $_G;
	if (!preg_match("/^https?:\\/\\//i", $_arg_0[1])) {
		$_arg_0[0] = "src=\"" . $_G["addon_collect_discuz_siteurl"] . $_arg_0[1] . "\"";
	}
	return $_arg_0[0];
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}
	require_once libfile("include/rule3", "plugin/addon_collect_discuz/source");
	require_once libfile("include/rule4", "plugin/addon_collect_discuz/source");
	require_once libfile("include/rule5", "plugin/addon_collect_discuz/source");
	require_once libfile("include/rule2", "plugin/addon_collect_discuz/source");
	global $_G;
	global $forumfield;
	$forumfield = array();