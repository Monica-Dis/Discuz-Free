<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_collect_discuz_analyze_discuz($_arg_0)
{
	global $_G;
	$_var_2 = array();
	$_var_3 = false;
	$_arg_0["page"] = max(1, $_arg_0["page"]);
	$_arg_0["articlelist"] = $_var_2 = array();
	if ($_arg_0["current_page"] > 1) {
		preg_match("#&page=([\\d]+)#is", $_arg_0["url"], $_var_4);
		if (!empty($_var_4[1])) {
			$_arg_0["url"] = preg_replace("#&page=([\\d]+)#is", "&page=" . $_arg_0["current_page"], $_arg_0["url"]);
		} else {
			preg_match("#forum-([\\w]+)-([\\d]+).html#is", $_arg_0["url"], $_var_4);
			if (!empty($_var_4[1])) {
				$_arg_0["url"] = preg_replace("#forum-([\\w]+)-([\\d]+).html#is", "forum-\\1-" . $_arg_0["current_page"] . ".html", $_arg_0["url"]);
			} else {
				preg_match("#f-([\\w]+).html#is", $_arg_0["url"], $_var_4);
				if (!empty($_var_4[1])) {
					$_arg_0["url"] = preg_replace("#f-([\\w]+).html#is", "f-\\1-" . $_arg_0["current_page"] . ".html", $_arg_0["url"]);
				} else {
					preg_match("#f-([\\w]+)-([\\d]+).html#is", $_arg_0["url"], $_var_4);
					if (!empty($_var_4[1])) {
						$_arg_0["url"] = preg_replace("#f-([\\w]+)-([\\d]+).html#is", "f-\\1-" . $_arg_0["current_page"] . ".html", $_arg_0["url"]);
					} else {
						preg_match("#forum_([\\w]+)_([\\d]+).html#is", $_arg_0["url"], $_var_4);
						if (!empty($_var_4[1])) {
							$_arg_0["url"] = preg_replace("#forum_([\\w]+)_([\\d]+).html#is", "forum_\\1_" . $_arg_0["current_page"] . ".html", $_arg_0["url"]);
						} else {
							$_arg_0["url"] = $_arg_0["url"] . ((strpos($_arg_0["url"], "?") === false ? "?" : "&") . "page=" . $_arg_0["current_page"]);
						}
					}
				}
			}
		}
	}
	$_var_5 = addon_collect_discuz_rule_getcontent($_arg_0);
	if (empty($_arg_0["charset"])) {
		preg_match("#http-equiv=\"Content-Type\"\\s*content=\"text/html;\\s*charset=gb#is", $_var_5, $_var_4);
		if (empty($_var_4[0])) {
			$_arg_0["charset"] = "utf-8";
		} else {
			$_arg_0["charset"] = "gbk";
		}
	} else {
		$_arg_0["charset"] = str_replace("utf8", "utf-8", $_arg_0["charset"]);
	}
	preg_match("#style_([\\d]+)_common\\.css#is", $_var_5, $_var_6);
	preg_match_all("#<a\\s+href=\"([^\"]+)\"[^>]+class=\"(s\\s)?xst\"[^>]*>(.*?)</a>#is", $_var_5, $_var_7);
	if (empty($_var_7[1])) {
		preg_match_all("#<a\\s+href=\"([^\"]+)\"([^>]+)onclick=\"atarget\\(this\\)\"[^>]*>(.*?)</a>#is", $_var_5, $_var_7);
	}
	foreach ($_var_7[1] as $_var_8 => $_var_9) {
		$_var_9 = str_replace("amp;", '', $_var_9);
		$_var_2["url"] = $_var_9;
		preg_match("#tid=([\\d]+)#is", $_var_9, $_var_4);
		if (empty($_var_4[1])) {
			preg_match("#thread-([\\d]+)-#is", $_var_9, $_var_4);
			if (empty($_var_4[1])) {
				preg_match("#t-([\\d]+)#is", $_var_9, $_var_4);
				if (empty($_var_4[1])) {
					preg_match("#thread_([\\d]+)_#is", $_var_9, $_var_4);
				}
			}
		}
		if (!empty($_var_4[1])) {
			$_var_2["group_id"] = $_var_4[1];
		}
		$_var_2["subject"] = trim($_var_7[3][$_var_8]);
		if (!empty($_var_2["group_id"]) && !empty($_var_2["subject"])) {
			$_arg_0["articlelist"][] = $_var_2;
		}
	}
	return $_arg_0;
}
function addon_collect_discuz_spider_discuz($_arg_0)
{
	global $_G;
	$_var_2 = array();
	$_arg_0["content"] = preg_replace("#<font class=\"jammer\">([^>]+)</font>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<span style=\"display:none\">([^>]+)</span>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<hook>([^>]+)</hook>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<script[^>]*>(.*?)</script>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<div class=\"a_pr\"(.*?)</div>#is", '', $_arg_0["content"]);
	if ($_arg_0["posttype"] != 2) {
		$_arg_0["content"] = preg_replace("#<div class=\"quote\"><blockquote>\\s*(.*?)\\s*</blockquote></div>#is", "[quote]\\1[/quote]", $_arg_0["content"]);
		$_arg_0["content"] = preg_replace_callback("#<div class=\"blockcode\"><div id=\"code_[\\w]+\">\\s*(.*?)\\s*</em></div>#is", "addon_collect_discuz_rule_callback_code", $_arg_0["content"]);
		$_arg_0["content"] = preg_replace("#<em class=\"(viewsource|copycode)\"([^>]+)>([^<]+)</em>#is", '', $_arg_0["content"]);
		$_arg_0["content"] = preg_replace_callback("#<pre\\s*[^>]*>\\s*(.*?)\\s*</pre>#is", "addon_collect_discuz_rule_callback_code2", $_arg_0["content"]);
	}
	$_arg_0["content"] = preg_replace("#<div class=\"tip tip_4 aimg_tip\" id=\"aimg_([\\d]+)_menu\"(.*?)</ignore_js_op>#is", "</ignore_js_op>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<img[^>]+ file=\"([^\"]+)\"[^>]+>#is", "<img src=\"\\1\"/>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<ignore_js_op>\\s*<img src=\"static/image/filetype/zip.gif\"(.*?)</ignore_js_op>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<table cellspacing=\"0\" class=\"t_table\"([^>]+)>(.*?)</td></tr></table>#is", "<table cellspacing=\"0\" class=\"t_table\"\\1>\\2</td></tr> </table>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("#<div class=\"mag_viewthread\">(.*?)</div>#is", '', $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<span>(.*?)<\\/span>/is", "\\1", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<br[^>]*>/is", "<br>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<p [^>]*>/is", "<p>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<p><br[^>]*>/is", "<p>", $_arg_0["content"]);
	$_arg_0["content"] = str_replace("<p></p>", "<br>", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<img[^>]*data-src=/is", "<img src=", $_arg_0["content"]);
	$_arg_0["content"] = preg_replace("/<img[^>]* src=/is", "<img src=", $_arg_0["content"]);
	$_arg_0["content"] = str_replace(array("<ignore_js_op>", "</ignore_js_op>"), '', $_arg_0["content"]);
	$_arg_0["content"] = str_replace("src=\"//", "src=\"http://", $_arg_0["content"]);
	$_G["addon_collect_discuz_siteurl"] = $_arg_0["siteurl"];
	$_arg_0["content"] = preg_replace_callback("#src=\"([^\"]*)\"#is", "addon_collect_discuz_rule_callback_img", $_arg_0["content"]);
	unset($_G["addon_collect_discuz_siteurl"]);
	if (empty($_arg_0["subject"])) {
		preg_match("#<span[^>]+id=\"thread_subject\">(.*?)</span>#is", $_arg_0["content"], $_var_2);
		$_arg_0["subject"] = trim($_var_2[1]);
	}
	if (empty($_arg_0["subject"])) {
		$_arg_0["error"] = "nosubject";
		return $_arg_0;
	}
	preg_match_all("#<td class=\"t_f\" id=\"postmessage_[\\d]+\"\\s*>(.*?)</td></tr></table>#is", $_arg_0["content"], $_var_3);
	if (empty($_var_3[0])) {
		preg_match_all("#<td class=\"t_f\" id=\"postmessage_[\\d]+\">(.*?)</td>#is", $_arg_0["content"], $_var_3);
	}
	if (isset($_var_3[1][0]) && !empty($_var_3[1][0])) {
		$_arg_0["message"] = $_var_3[1][0];
		$_arg_0["message"] = preg_replace("/>[\\s]+</iUs", "><", $_arg_0["message"]);
		$_arg_0["message"] = preg_replace(array("/\\<link.*?\\>/", "/\\<script.*?\\<\\/script\\>/", "/\\<style.*?\\<\\/style\\>/is"), '', $_arg_0["message"]);
		$_arg_0["message"] = preg_replace("/<p([^>]*)><br><img/is", "<p\\1><img", $_arg_0["message"]);
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["study_filter_mao"]) {
			$_arg_0["message"] = preg_replace("/<a [^>]*>(.*?)<\\/a>/is", "\\1", $_arg_0["message"]);
		}
		$_arg_0["message"] = trim($_arg_0["message"]);
		$_arg_0["message"] = trim(preg_replace("#<div class=\"attach_nopermission attach_tips\"><div>(.*?)</span></div>#is", '', $_arg_0["message"]));
		$_arg_0["message"] = trim(preg_replace("#^<i class=\"pstatus\">(.*?)</i><br[^>]*>#is", '', $_arg_0["message"]));
		preg_match_all("#<div id=\"post_[\\d]+\"[^>]*>(.*?)<div id=\"comment_[\\d]+\" class=\"cm\">#is", $_arg_0["content"], $_var_4);
		if (isset($_var_4[1][0]) && !empty($_var_4[1][0])) {
			preg_match_all("#<div class=\"mbn savephotop\">(.*?)</div>#is", $_var_4[1][0], $_var_5);
			if (empty($_var_5[0])) {
				preg_match_all("#<dl class=\"tattl attm\">(.*?)</dl>#is", $_var_4[1][0], $_var_5);
			}
			foreach ($_var_5[1] as $_var_6) {
				preg_match("#src=\"([^\"]+)\"#is", $_var_6, $_var_7);
				if (!empty($_var_7[1])) {
					$_arg_0["message"] = $_arg_0["message"] . ("<br /><img src=\"" . $_var_7[1] . "\"/>");
				}
			}
		}
		if ($_G["cache"]["plugin"]["addon_collect_discuz"]["study_reply_radio"]) {
			$_arg_0["comments"] = array();
			foreach ($_var_3[1] as $_var_8 => $_var_9) {
				if ($_var_8 > 0) {
					$_arg_0["comments"][$_var_8] = trim($_var_9);
					$_arg_0["comments"][$_var_8] = trim(preg_replace("#^<i class=\"pstatus\">(.*?)</i><br>#is", '', $_arg_0["comments"][$_var_8]));
					$_arg_0["comments"][$_var_8] = trim(preg_replace("#^\\[quote\\]<font size=\"2\">(.*?)\\[/quote\\]<br>#is", '', $_arg_0["comments"][$_var_8]));
					if ($_G["cache"]["plugin"]["addon_collect_discuz"]["study_filter_mao"]) {
						$_arg_0["comments"][$_var_8] = preg_replace("/<a [^>]*>(.*?)<\\/a>/is", "\\1", $_arg_0["comments"][$_var_8]);
					}
					if (isset($_var_4[1][$_var_8]) && !empty($_var_4[1][$_var_8])) {
						preg_match_all("#<div class=\"mbn savephotop\">(.*?)</div>#is", $_var_4[1][$_var_8], $_var_5);
						if (empty($_var_5[0])) {
							preg_match_all("#<dl class=\"tattl attm\">(.*?)</dl>#is", $_var_4[1][$_var_8], $_var_5);
						}
						foreach ($_var_5[1] as $_var_6) {
							preg_match("#src=\"([^\"]+)\"#is", $_var_6, $_var_7);
							if (!empty($_var_7[1])) {
								$_arg_0["comments"][$_var_8] = $_arg_0["comments"][$_var_8] . ("<br /><img src=\"" . $_var_7[1] . "\"/>");
							}
						}
					}
				}
			}
		}
	}
	$_arg_0["author"] = lang("plugin/addon_collect_discuz", "slang_018");
	preg_match("#<div class=\"authi\"><a href=\"[^\"]+\" target=\"_blank\" class=\"xw1\">(.*?)</a>#is", $_arg_0["content"], $_var_10);
	if ($_var_10[1]) {
		$_arg_0["author"] = $_var_10[1];
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "From ww'.'w.zz'.'b'.'7.net";
		return 0;
	}