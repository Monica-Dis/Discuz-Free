<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_addon_collect_discuz {
		function global_footer(){
				global $_G;
				$return = '';
				if (in_array($_G['cache']['plugin']['addon_collect_discuz']['auto_collect_radio'], array('1', '3')) || in_array($_G['cache']['plugin']['addon_collect_discuz']['auto_post_radio'], array('1', '3'))) {
						$return = '<script type="text/javascript" src="'.$_G['siteurl'].'plugin.php?id=addon_collect_discuz:autopost" defer="defer"></script>';
				}
				return $return;
		}
}