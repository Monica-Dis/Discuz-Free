<?php

function zzbuluo_integral_cache($_arg_0 = '')
{
	global $slidelist;
	if (!is_array($slidelist)) {
		$slidelist = array();
	}
	if (!file_exists(DISCUZ_ROOT . "./data/sysdata/cache_zzbuluo_integral_info.php") || $_arg_0) {
		require_once libfile("function/cache");
		$_var_2 = C::t("#zzbuluo_integral#zzbuluo_integral_info")->fetch_all_by_search();
		foreach ($_var_2 as $_var_3 => $_var_4) {
			$slidelist[$_var_4["fid"]] = $_var_4["type"];
		}
		writetocache("zzbuluo_integral_info", "global \$slidelist;" . getcachevars(array("slidelist" => $slidelist)));
	} else {
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_zzbuluo_integral_info.php");
	}
	return $slidelist;
}
function zzbuluo_integral_fid()
{
	$_var_0 = '';
	$_var_1 = intval($_GET["aid"]);
	$_var_2 = C::t("forum_attachment")->fetch_all_by_id("aid", $_var_1, $_var_3 = '');
	if (!empty($_var_2[$_var_1]["tid"])) {
		$_var_0 = C::t("forum_thread")->fetch($_var_2[$_var_1]["tid"]);
	}
	return $_var_0["fid"];
}
function zzbuluo_integral_update()
{
	$_var_0 = array();
	$_var_1 = C::t("#zzbuluo_integral#zzbuluo_integral_info")->fetch_all_by_search();
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_0[$_var_3["fid"]] = $_var_3["type"];
	}
	if (is_array($_POST["upselect"])) {
		foreach ($_POST["upselect"] as $_var_4 => $_var_5) {
			if (isset($_var_0[$_var_4])) {
				if ($_var_0[$_var_4] != $_var_5) {
					C::t("#zzbuluo_integral#zzbuluo_integral_info")->update($_var_4, array("type" => $_var_5));
				}
			} else {
				C::t("#zzbuluo_integral#zzbuluo_integral_info")->insert(array("fid" => $_var_4, "type" => $_var_5));
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}