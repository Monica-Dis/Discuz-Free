<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $type1314;
	global $op;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	require_once libfile("function/core", "plugin/zzbuluo_integral/source");
	$_var_8 = array("list", "edit", "add");
	$op = in_array($_GET["op"], $_var_8) ? $_GET["op"] : "list";
	$_var_9 = unserialize($_G["cache"]["plugin"]["zzbuluo_integral"]["zzbuluo_forums"]);
	loadcache("forums");
	if ($op == "list") {
		if (!submitcheck("submit")) {
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10);
			showtableheader('');
			$_var_11 = $_var_12 = $_var_13 = array();
			showsubtitle(array("&#102;&#105;&#100;&#29256;&#22359;&#32534;&#21495;", "&#x7248;&#x5757;&#x540D;", "&#x79EF;&#x5206;&#x8BBE;&#x7F6E;", ''));
			$_var_14 = C::t("#zzbuluo_integral#zzbuluo_integral_info")->fetch_all_by_search();
			foreach ($_var_14 as $_var_15 => $_var_16) {
				$_var_13[$_var_16["fid"]] = $_var_16["type"];
			}
			foreach ($_var_9 as $_var_17 => $_var_18) {
				$_var_19 = '';
				$_var_20 = true;
				if (!empty($_var_18)) {
					foreach ($_G["setting"]["extcredits"] as $_var_21 => $_var_22) {
						if ($_var_20) {
							$_var_19 = "<option value=\"0\"" . ($_var_13[$_var_18] == $_var_21 ? "selected" : '') . ">&#19981;&#35774;&#32622;</option>";
							$_var_20 = false;
						}
						$_var_19 = $_var_19 . ("<option value=\"" . $_var_21 . "\"" . ($_var_13[$_var_18] == $_var_21 ? "selected" : '') . ">" . $_var_22["title"] . "</option>");
					}
					showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td32\"", "class=\"td31\"", "class=\"td31\"", " style=\"width:50px;\"", " style=\"width:120px;\"", " style=\"width:120px;\"", " style=\"width:100px;\""), array($_var_18, $_G["cache"]["forums"][$_var_18]["name"], "<select name=\"upselect[" . $_var_18 . "]\">" . $_var_19 . "</select>", ''));
				}
			}
			showsubmit("submit", "submit");
			showtablefooter();
			showformfooter();
		} else {
			zzbuluo_integral_update();
			zzbuluo_integral_cache(1);
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_10, "succeed");
		}
	}