<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From dism��taobao��com
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_addon_seo_tagrelatekw {}
class mobileplugin_addon_seo_tagrelatekw_forum extends mobileplugin_addon_seo_tagrelatekw {
	function relatekw_gettag() {
		global $_G;
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['radio']) {
			include_once DISCUZ_ROOT . './source/plugin/addon_seo_tagrelatekw/source/module/forum_relatekw.php';
			exit;
		}
	}

	function viewthread_gettag_output() {
		global $_G, $postlist;
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['radio'] && $splugin_setting['notag_radio'] == 1) {
			$study_nofids = dunserialize($splugin_setting['study_nofids']);
			if (!in_array($_G['fid'], $study_nofids) && $_G['page'] == 1 && empty($postlist[$_G['forum_firstpid']]['tags']) && empty($postlist[$_G['forum_firstpid']]['stags'])){
				include_once libfile('function/core', 'plugin/addon_seo_tagrelatekw/source');
			}
		}
	}
	
	function viewthread_bottom_mobile_output(){
		global $_G, $postlist;
		$return = '';
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['radio'] && $splugin_setting['notag_radio'] == 2) {
			$study_nofids = dunserialize($splugin_setting['study_nofids']);
			if (!in_array($_G['fid'], $study_nofids) && $_G['page'] == 1 && empty($postlist[$_G['forum_firstpid']]['tags']) && empty($postlist[$_G['forum_firstpid']]['stags'])){
				$return = '<script type="text/javascript" src="plugin.php?id=addon_seo_tagrelatekw&tid='.$_G['tid'].'" defer="defer"></script>';
			}
		}
		return $return;
	}
}