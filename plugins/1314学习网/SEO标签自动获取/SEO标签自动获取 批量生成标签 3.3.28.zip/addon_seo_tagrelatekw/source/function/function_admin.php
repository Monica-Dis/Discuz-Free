<?php

function addon_seo_tagrelatekw_relatekw_ways($_arg_0, $_arg_1)
{
	global $_G;
	global $lang;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	$splugin_lang = lang("plugin/addon_seo_tagrelatekw");
	$splugin_lang["relatekw_way_4"] = "<a href=\"https://market.aliyun.com/products/57124001/cmapi017956.html\" target=\"_blank\">" . $splugin_lang["relatekw_way_4"] . "</a>";
	$splugin_lang["relatekw_way_5"] = "<a href=\"https://market.aliyun.com/products/57124001/cmapi017929.html\" target=\"_blank\">" . $splugin_lang["relatekw_way_5"] . "</a>";
	$_var_7 = $_var_8 = array();
	$_var_9 = array("relatekw_ways" => array("1", "2", "3", "4", "5", "6", "7"));
	$_var_10 = explode(",", $_arg_1["value"]);
	if (is_array($_var_10) && !empty($_var_10)) {
		foreach ($_var_10 as $_var_11) {
			if (in_array($_var_11, $_var_9[$_arg_0])) {
				$_var_8[$_var_11] = 1;
			}
		}
	}
	foreach ($_var_9[$_arg_0] as $_var_11) {
		if (!isset($_var_8[$_var_11])) {
			$_var_8[$_var_11] = 0;
		}
	}
	echo "\r\n\t<tr><td colspan=\"2\" class=\"td27\" s=\"1\">" . dhtmlspecialchars($_arg_1["title"]) . ":</td></tr>\r\n\t<tr class=\"noborder\"><td>";
	showtableheader('', '', "style=\"margin-top: 0px;\"");
	showsubtitle(array("&#x6267;&#x884C;&#x987A;&#x5E8F;", "&#x540D;&#x79F0;", "&#x662F;&#x5426;&#x542F;&#x7528;", ''), "hover");
	$_var_12 = 1;
	foreach ($_var_8 as $_var_13 => $_var_11) {
		showtablerow('', array("class=\"td25\"", "class=\"td25\" style=\"width:120px;\"", "class=\"td25\"", "class=\"td25\""), array("<input type=\"text\" class=\"txt\" name=\"varsnew[" . $_arg_0 . "][order][" . $_var_13 . "]\" value=\"" . $_var_12 . "\" style=\"height: 20px;\">", $splugin_lang["relatekw_way_" . $_var_13], "<input name=\"varsnew[" . $_arg_0 . "][status][" . $_var_13 . "]\" type=\"checkbox\" value=\"1\" " . ($_var_11 ? "checked=\"checked=\"" : '') . "/>"));
		$_var_12 = $_var_12 + 1;
	}
	showtablefooter();
	echo "</td><td class=\"vtop tips2\" s=\"1\">" . nl2br(dhtmlspecialchars($_arg_1["description"])) . "</td></tr>";
}
function addon_seo_tagrelatekw_relatekw_wayssubmit($_arg_0, $_arg_1)
{
	global $_G;
	global $pluginid;
	$_var_4 = array("relatekw_ways" => array("1", "2", "3", "4", "5", "6", "7"));
	asort($_arg_1["order"]);
	$_var_5 = array();
	if (is_array($_arg_1["order"])) {
		foreach ($_arg_1["order"] as $_var_6 => $_var_7) {
			if (!empty($_arg_1["status"][$_var_6]) && in_array($_var_6, $_var_4[$_arg_0])) {
				$_var_5[] = (double) $_var_6;
			}
		}
	}
	C::t("common_pluginvar")->update_by_variable($pluginid, $_arg_0, array("value" => implode(",", $_var_5)));
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}
	global $_G;