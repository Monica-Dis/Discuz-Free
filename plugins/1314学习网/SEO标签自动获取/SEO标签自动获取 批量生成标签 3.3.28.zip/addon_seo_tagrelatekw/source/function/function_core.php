<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_seo_tagrelatekw_gettags($_arg_0, $_arg_1, $_arg_2 = '')
{
	global $_G;
	global $tmptags;
	$_var_5 = $_var_6 = array();
	if (in_array($_arg_0, array(1, 2))) {
		if (count($tmptags) < 8) {
			if (!isset($_G["addon_seo_tagrelatekw_baidu"])) {
				$_G["addon_seo_tagrelatekw_baidu"] = array("keyword_list" => array(), "wordrank" => array());
				$_var_7 = addon_seo_tagrelatekw_getcontent("http://zhannei.baidu.com/api/customsearch/keywords?title=" . rawurlencode($_arg_1));
				preg_match("/^\"(.*?)\"\$/i", $_var_7, $_var_5);
				if ($_var_5[1]) {
					$_var_7 = str_replace("\\\"", '', $_var_5[1]);
				}
				$_var_8 = array();
				if (!empty($_var_7) && preg_match("/^{\"id/i", $_var_7)) {
					$_var_8 = json_decode($_var_7, true);
					if (is_array($_var_8["result"]) && $_var_8["result"]["_ret"] != 1 && isset($_var_8["result"]) && isset($_var_8["result"]["res"]) && !empty($_var_8["result"]["res"])) {
						if ($_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["relatekw_way"] != 3 && isset($_var_8["result"]["res"]["keyword_list"])) {
							if (is_array($_var_8["result"]["res"]["keyword_list"]) && !empty($_var_8["result"]["res"]["keyword_list"])) {
								$_G["addon_seo_tagrelatekw_baidu"]["keyword_list"] = $_var_8["result"]["res"]["keyword_list"];
							}
						}
						if ($_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["relatekw_way"] != 2 && isset($_var_8["result"]["res"]["wordrank"])) {
							if (is_array($_var_8["result"]["res"]["wordrank"]) && !empty($_var_8["result"]["res"]["wordrank"])) {
								$_G["addon_seo_tagrelatekw_baidu"]["wordrank"] = $_var_8["result"]["res"]["wordrank"];
							}
						}
					}
				}
			}
			if ($_arg_0 == 1) {
				if (!empty($_G["addon_seo_tagrelatekw_baidu"]["keyword_list"])) {
					foreach ($_G["addon_seo_tagrelatekw_baidu"]["keyword_list"] as $_var_9) {
						$_var_10 = addon_seo_tagrelatekw_strlen($_var_9);
						if (!in_array($_var_9, $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
							$tmptags[$_var_9] = $_var_10;
						}
					}
				}
			} else {
				if (!empty($_G["addon_seo_tagrelatekw_baidu"]["wordrank"])) {
					foreach ($_G["addon_seo_tagrelatekw_baidu"]["wordrank"] as $_var_9) {
						$_var_11 = explode(":", $_var_9);
						$_var_11[0] = trim($_var_11[0]);
						if ($_var_11[0]) {
							$_var_10 = addon_seo_tagrelatekw_strlen($_var_11[0]);
							if (!in_array($_var_11[0], $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
								$tmptags[$_var_11[0]] = $_var_10;
							}
						}
					}
				}
			}
		}
	} else {
		if ($_arg_0 == 3) {
			if (count($tmptags) < 8) {
				$_arg_1 = cutstr($_arg_1, 300, '');
				$_var_12 = "http://api.pullword.com/get.php?source=" . rawurlencode($_arg_1) . "&param1=0.6&param2=1&json=1";
				$_var_7 = dfsockopen($_var_12, 0, '', '', false, '', 60);
				if (empty($_var_7)) {
					$_var_12 = str_replace("api.pullword.com", "120.26.6.172", $_var_12);
					$_var_7 = dfsockopen($_var_12, 0, '', '', false, '', 60);
				}
				if (!empty($_var_7)) {
					$_var_8 = json_decode($_var_7, true);
					if (is_array($_var_8) && !empty($_var_8)) {
						foreach ($_var_8 as $_var_9) {
							$_var_10 = addon_seo_tagrelatekw_strlen($_var_9["t"]);
							if (!in_array($_var_9["t"], $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
								$tmptags[$_var_9["t"]] = $_var_10;
							}
						}
					}
				}
			}
		} else {
			if ($_arg_0 == 6) {
				if (count($tmptags) < 6) {
					$_var_7 = addon_seo_tagrelatekw_getcontent("http://www.baidu.com/s?wd=" . rawurlencode($_arg_2) . '');
					preg_match("#<div id=\"rs\">(.*?)</table></div>#is", $_var_7, $_var_5);
					if ($_var_5[1]) {
						preg_match_all("#<a[^>]+>(.*?)</a>#is", $_var_5[1], $_var_6);
					}
					if (is_array($_var_6[1]) && !empty($_var_6[1])) {
						foreach ($_var_6[1] as $_var_9) {
							$_var_9 = strip_tags($_var_9);
							$_var_10 = addon_seo_tagrelatekw_strlen($_var_9);
							if (!in_array($_var_9, $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
								$tmptags[$_var_9] = $_var_10;
							}
						}
					}
				}
			} else {
				if ($_arg_0 == 7) {
					if (count($tmptags) < 6) {
						$_var_7 = addon_seo_tagrelatekw_getcontent("https://m.baidu.com/s?word=" . rawurlencode($_arg_2));
						preg_match("#lid:'(\\d+)'#is", $_var_7, $_var_13);
						if (empty($_var_13[1])) {
							preg_match("#lid=(\\d+)#is", $_var_7, $_var_13);
						}
						if (!empty($_var_13[1])) {
							$_G["cache"]["addon_seo_tagrelatekw_qid"] = $_var_13[1];
						}
						savecache("addon_seo_tagrelatekw_qid", $_G["cache"]["addon_seo_tagrelatekw_qid"]);
						$_var_14 = addon_seo_tagrelatekw_getcontent("https://m.baidu.com/rec?platform=wise&ms=1&lsAble=1&rset=rcmd&word=" . rawurlencode($_arg_2) . "&qid=" . $_G["cache"]["addon_seo_tagrelatekw_qid"] . "&rq=" . rawurlencode($_arg_2) . "&from=0&tn=&clientWidth=360&t=1891769827639");
						$_var_15 = json_decode($_var_14, true);
						if ($_var_15["errcode"] === 0 && is_array($_var_15["rs"]["ars"]["rs"]) && !empty($_var_15["rs"]["ars"]["rs"])) {
							foreach ($_var_15["rs"]["ars"]["rs"] as $_var_16 => $_var_17) {
								$_var_9 = strip_tags($_var_17["text"]);
								$_var_10 = addon_seo_tagrelatekw_strlen($_var_9);
								if (!in_array($_var_9, $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
									$tmptags[$_var_9] = $_var_10;
								}
								if ($_var_16 > 8) {
									break;
								}
							}
						} else {
							preg_match_all("#<div class=\"rw-list-new rw-list-new2\"[^>]+><a[^>]+>(.*?)</a></div>#is", $_var_7, $_var_6);
							if (empty($_var_6[1])) {
								preg_match_all("#<div class=\"rw-list-new rw-list-new1\"[^>]+><a[^>]+>(.*?)</a></div>#is", $_var_7, $_var_6);
								if (empty($_var_6[1])) {
									preg_match_all("#<div data-a-6df6b556 class=\"c-span6 c-gap-inner-bottom-small c-gap-inner-top-small span-item2[^>]+><a[^>]+>(.*?)</a></div>#is", $_var_7, $_var_6);
								}
							}
							if (is_array($_var_6[1]) && !empty($_var_6[1])) {
								foreach ($_var_6[1] as $_var_9) {
									$_var_9 = strip_tags($_var_9);
									$_var_10 = addon_seo_tagrelatekw_strlen($_var_9);
									if (!in_array($_var_9, $tmptags) && $_var_10 > 1 && $_var_10 < 20) {
										$tmptags[$_var_9] = $_var_10;
									}
								}
							}
						}
					}
				} else {
					if (!empty($_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["appcode"])) {
						if (count($tmptags) < 8) {
							$_var_18 = $_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["appcode"];
							if ($_arg_0 == 4) {
								$_var_19 = "http://gjccq.market.alicloudapi.com/rest/160601/text_analysis/key_words_extraction.json";
								$_var_20 = array();
								array_push($_var_20, "Authorization:APPCODE " . $_var_18);
								array_push($_var_20, "Content-Type" . ":" . "application/json; charset=UTF-8");
								$_arg_1 = str_replace(array("[", "]", "{", "{", "\"", "'"), '', $_arg_1);
								$_var_21 = "{\"inputs\":[{\"text\":{\"dataType\":50,\"dataValue\":\"" . $_arg_1 . "\"},\"config\":{\"dataType\":50,\"dataValue\":\"{\\\"topN\\\":3,\\\"similarityType\\\":\\\"lcs\\\",\\\"delimiter\\\":\\\",\\\"}\"}}]}";
								$_var_22 = curl_init();
								curl_setopt($_var_22, CURLOPT_CUSTOMREQUEST, "POST");
								curl_setopt($_var_22, CURLOPT_URL, $_var_19);
								curl_setopt($_var_22, CURLOPT_HTTPHEADER, $_var_20);
								curl_setopt($_var_22, CURLOPT_FAILONERROR, false);
								curl_setopt($_var_22, CURLOPT_RETURNTRANSFER, true);
								curl_setopt($_var_22, CURLOPT_HEADER, false);
								curl_setopt($_var_22, CURLOPT_POSTFIELDS, $_var_21);
								$_var_7 = curl_exec($_var_22);
								if (!empty($_var_7) && substr($_var_7, 0, 1) == "{") {
									$_var_8 = json_decode($_var_7, true);
									if (isset($_var_8["outputs"]) && isset($_var_8["outputs"][0]) && isset($_var_8["outputs"][0]["outputValue"])) {
										if (isset($_var_8["outputs"][0]["outputValue"]["dataValue"]) && !empty($_var_8["outputs"][0]["outputValue"]["dataValue"])) {
											$_var_23 = json_decode($_var_8["outputs"][0]["outputValue"]["dataValue"], true);
											if (isset($_var_23["words weight"]) && is_array($_var_23["words weight"]) && !empty($_var_23["words weight"])) {
												foreach ($_var_23["words weight"] as $_var_9) {
													if (!in_array($_var_9["word"], $tmptags)) {
														$_var_10 = addon_seo_tagrelatekw_strlen($_var_9["word"]);
														if ($_var_10 > 1 && $_var_10 < 20) {
															$tmptags[$_var_9["word"]] = $_var_10;
														}
													}
												}
											}
										}
									}
								}
							} else {
								if ($_arg_0 == 5) {
									$_var_19 = "http://xwys.market.alicloudapi.com/rest/160601/text_analysis/news_element_extraction.json";
									$_var_20 = array();
									array_push($_var_20, "Authorization:APPCODE " . $_var_18);
									array_push($_var_20, "Content-Type" . ":" . "application/json; charset=UTF-8");
									$_arg_2 = str_replace(array("[", "]", "{", "{", "\"", "'"), '', $_arg_2);
									$_arg_1 = str_replace(array("[", "]", "{", "{", "\"", "'"), '', $_arg_1);
									$_var_21 = "{\"inputs\":[{\"title\":{\"dataType\":50,\"dataValue\":\"" . $_arg_2 . "\"},\"content\":{\"dataType\":50,\"dataValue\":\"" . $_arg_1 . "\"},\"config\":{\"dataType\":50,\"dataValue\":\"{\\\"topN\\\":5}\"}}]}";
									$_var_22 = curl_init();
									curl_setopt($_var_22, CURLOPT_CUSTOMREQUEST, "POST");
									curl_setopt($_var_22, CURLOPT_URL, $_var_19);
									curl_setopt($_var_22, CURLOPT_HTTPHEADER, $_var_20);
									curl_setopt($_var_22, CURLOPT_FAILONERROR, false);
									curl_setopt($_var_22, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($_var_22, CURLOPT_HEADER, false);
									curl_setopt($_var_22, CURLOPT_POSTFIELDS, $_var_21);
									$_var_7 = curl_exec($_var_22);
									if (!empty($_var_7) && substr($_var_7, 0, 1) == "{") {
										$_var_8 = json_decode($_var_7, true);
										if (isset($_var_8["outputs"]) && isset($_var_8["outputs"][0]) && isset($_var_8["outputs"][0]["outputValue"])) {
											if (isset($_var_8["outputs"][0]["outputValue"]["dataValue"]) && !empty($_var_8["outputs"][0]["outputValue"]["dataValue"])) {
												$_var_23 = json_decode($_var_8["outputs"][0]["outputValue"]["dataValue"], true);
												if (isset($_var_23["data"]) && is_array($_var_23["data"]) && !empty($_var_23["data"])) {
													if (isset($_var_23["data"]["concept"]) && is_array($_var_23["data"]["concept"]) && !empty($_var_23["data"]["concept"])) {
														foreach ($_var_23["data"]["concept"] as $_var_9) {
															if (!in_array($_var_9["tag"], $tmptags)) {
																$_var_10 = addon_seo_tagrelatekw_strlen($_var_9["tag"]);
																if ($_var_10 > 1 && $_var_10 < 20) {
																	$tmptags[$_var_9["tag"]] = $_var_10;
																}
															}
														}
													}
													if (isset($_var_23["data"]["who"]) && is_array($_var_23["data"]["who"]) && !empty($_var_23["data"]["who"])) {
														foreach ($_var_23["data"]["who"] as $_var_9) {
															if (!in_array($_var_9["tag"], $tmptags)) {
																$_var_10 = addon_seo_tagrelatekw_strlen($_var_9["tag"]);
																if ($_var_10 > 1 && $_var_10 < 20) {
																	$tmptags[$_var_9["tag"]] = $_var_10;
																}
															}
														}
													}
													if (isset($_var_23["data"]["event"]) && is_array($_var_23["data"]["event"]) && !empty($_var_23["data"]["event"])) {
														foreach ($_var_23["data"]["event"] as $_var_9) {
															if (!in_array($_var_9["tag"], $tmptags)) {
																$_var_10 = addon_seo_tagrelatekw_strlen($_var_9["tag"]);
																if ($_var_10 > 1 && $_var_10 < 20) {
																	$tmptags[$_var_9["tag"]] = $_var_10;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return $tmptags;
}
function addon_seo_tagrelatekw_getcontent($_arg_0)
{
	global $_G;
	$_var_2 = curl_init();
	$_var_3 = '';
	if (strpos($_arg_0, "www.baidu.com") !== false) {
		$_var_3 = DISCUZ_ROOT . "./source/plugin/addon_seo_tagrelatekw/images/baidu.tmp";
	} else {
		if (strpos($_arg_0, "m.baidu.com") !== false) {
			$_var_3 = DISCUZ_ROOT . "./source/plugin/addon_seo_tagrelatekw/images/baidu2.tmp";
		}
	}
	$_var_4 = addon_seo_tagrelatekw_get_rand_ip();
	$_var_5 = 10;
	curl_setopt($_var_2, CURLOPT_URL, $_arg_0);
	curl_setopt($_var_2, CURLOPT_TIMEOUT, 30);
	curl_setopt($_var_2, CURLOPT_HTTPHEADER, array("X-FORWARDED-FOR:" . $_var_4 . '', "CLIENT-IP:" . $_var_4 . ''));
	curl_setopt($_var_6, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1");
	curl_setopt($_var_2, CURLOPT_REFERER, $_arg_0);
	curl_setopt($_var_2, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($_var_2, CURLOPT_HEADER, 0);
	if (preg_match("/^https:\\/\\//i", $_arg_0)) {
		curl_setopt($_var_2, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($_var_2, CURLOPT_SSL_VERIFYHOST, false);
	}
	if (!empty($_var_3) && file_exists($_var_3)) {
		curl_setopt($_var_2, CURLOPT_COOKIEJAR, $_var_3);
		curl_setopt($_var_2, CURLOPT_COOKIEFILE, $_var_3);
	}
	curl_setopt($_var_2, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($_var_2, CURLOPT_MAXREDIRS, 3);
	curl_setopt($_var_2, CURLOPT_CONNECTTIMEOUT, $_var_5);
	$_var_7 = curl_exec($_var_2);
	curl_close($_var_2);
	return $_var_7;
}
function addon_seo_tagrelatekw_get_rand_ip()
{
	$_var_0 = array("110.96", "111.128", "101.144", "114.240", "117.112", "124.200", "101.196", "101.120", "111.208", "110.40", "222.28", "211.160", "121.68", "42.196", "202.204", "1.88", "58.116", "175.188", "218.246", "117.106", "121.194", "124.64", "118.228", "210.82", "119.254", "101.200", "42.158", "180.78", "58.30", "110.94", "123.60", "121.89", "119.57", "202.112", "36.254", "180.76", "116.69", "106.50", "113.209", "180.77", "117.75", "123.64", "175.64", "42.208", "175.48", "221.216", "101.236", "101.244", "101.104", "112.124");
	$_var_1 = mt_rand(0, count($_var_0) - 1);
	$_var_2 = $_var_0[$_var_1];
	$_var_3 = round(mt_rand(600000, 2540000) / 10000);
	$_var_4 = round(mt_rand(600000, 2540000) / 10000);
	return $_var_2 . "." . $_var_3 . "." . $_var_4;
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}
	include_once libfile("function/core2", "plugin/addon_seo_tagrelatekw/source");
	global $_G;
	global $relatekw_way;
	if (!defined("IN_ADMINCP")) {
		if (CURMODULE == "viewthread") {
			addon_seo_tagrelatekw_viewthread();
		}
		if ($_GET["e_tagrelatekw"]) {
			addon_seo_tagrelatekw_check();
		}
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
	}