<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function addon_seo_tagrelatekw_gettag($_arg_0, $_arg_1 = '')
{
	global $_G;
	global $tmptags;
	$_var_4 = $tmptags = $_var_5 = $_var_6 = array();
	$_var_7 = $_G["cache"]["plugin"]["addon_seo_tagrelatekw"];
	$_arg_0 = preg_replace("#\\s+#i", '', $_arg_0);
	$_arg_0 = str_replace("nbsp;", '', $_arg_0);
	$_var_8 = $_arg_0;
	if (function_exists("mb_stripos")) {
		$_arg_0 = diconv($_arg_0, CHARSET, "utf-8");
		$_var_9 = explode("|", diconv($_var_7["tags"], CHARSET, "utf-8"));
		if (!empty($_var_9)) {
			foreach ($_var_9 as $_var_10) {
				if (!empty($_var_10) && mb_stripos($_arg_0, $_var_10, 0, "utf-8") !== false) {
					$_var_4[] = $_var_10;
				}
			}
		}
	}
	$_var_11 = explode(",", $_var_7["relatekw_ways"]);
	$_arg_1 = diconv($_arg_1, CHARSET, "utf-8");
	if (in_array(4, $_var_11) || in_array(5, $_var_11)) {
		$_arg_0 = diconv($_var_8, CHARSET, "utf-8");
	} else {
		$_arg_0 = cutstr($_var_8, 500, '');
		$_arg_0 = diconv($_arg_0, CHARSET, "utf-8");
	}
	foreach ($_var_11 as $_var_12) {
		addon_seo_tagrelatekw_gettags($_var_12, $_arg_0, $_arg_1);
	}
	if ($_var_7["words_more_tags"]) {
		arsort($tmptags);
	}
	$tmptags = array_keys($tmptags);
	if (is_array($tmptags) && !empty($tmptags)) {
		foreach ($tmptags as $_var_13 => $_var_12) {
			if ($_var_7["filter_have_digital"]) {
				if (preg_match("#([\\d]+)#i", $_var_12)) {
					unset($tmptags[$_var_13]);
					continue;
				}
			} else {
				if ($_var_7["filter_digital"]) {
					if (preg_match("#^([\\d]+)\$#i", $_var_12)) {
						unset($tmptags[$_var_13]);
						continue;
					}
				}
			}
			if ($_var_7["filter_have_letter"]) {
				if (preg_match("#([A-Za-z]+)#i", $_var_12)) {
					unset($tmptags[$_var_13]);
					continue;
				}
			} else {
				if ($_var_7["filter_letter"]) {
					if (preg_match("#^([A-Za-z]+)\$#i", $_var_12)) {
						unset($tmptags[$_var_13]);
						continue;
					}
				}
			}
			if ($_var_7["filter_digitalandletter"]) {
				if (preg_match("#^([\\w]+)\$#i", $_var_12)) {
					unset($tmptags[$_var_13]);
					continue;
				}
			}
			if (!in_array($_var_12, $_var_4)) {
				$_var_4[] = $_var_12;
			}
		}
	}
	if (empty($_var_4)) {
		if (!empty($_var_7["notag_tags"])) {
			$_var_14 = explode("|", $_var_7["notag_tags"]);
			shuffle($_var_14);
			$_var_4 = array_slice($_var_14, 0, 5);
		}
	} else {
		$_var_4 = array_slice($_var_4, 0, 5);
		foreach ($_var_4 as $_var_13 => $_var_12) {
			$_var_4[$_var_13] = diconv($_var_12, "utf-8", CHARSET);
		}
	}
	return $_var_4;
}
function addon_seo_tagrelatekw_viewthread()
{
	global $_G;
	global $postlist;
	if ($_G["tid"] && $_G["page"] == 1 && empty($postlist[$_G["forum_firstpid"]]["tags"])) {
		$_var_2 = "DZS_ADDON_SEO_TAGRELATEKW_" . $_G["tid"];
		if (!discuz_process::islocked($_var_2, 10)) {
			$_var_3 = C::t("forum_post")->fetch_threadpost_by_tid_invisible($_G["tid"]);
			$_var_4 = $_var_3["subject"];
			$_var_5 = $_var_3["message"];
			$_var_6 = '';
			if ($_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["only_subject"]) {
				$_var_6 = $_var_4;
			} else {
				$_var_6 = $_var_4 . $_var_5;
			}
			$_var_6 = strip_tags(preg_replace("/\\[.+?\\]/is", '', $_var_6));
			$_var_7 = addon_seo_tagrelatekw_gettag($_var_6, $_var_4);
			if ($_var_7) {
				$_var_8 = addon_seo_tagrelatekw_modthreadtag(implode(",", $_var_7), $_G["tid"]);
				$_var_9 = $_var_10 = array();
				$_var_9 = explode("\t", $_var_8);
				if ($_var_9) {
					foreach ($_var_9 as $_var_11) {
						if ($_var_11) {
							$_var_12 = explode(",", $_var_11);
							$_var_10[] = $_var_12;
						}
					}
				}
				$postlist[$_G["forum_firstpid"]]["tags"] = $_var_10;
			}
		}
	}
}
function addon_seo_tagrelatekw_modthreadtag($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	if ($_arg_0) {
		if (function_exists("modthreadtag")) {
			$_var_3 = modthreadtag($_arg_0, $_arg_1);
			$_var_4 = getposttablebytid($_arg_1);
			DB::query("UPDATE " . DB::table($_var_4) . " SET tags='" . $_var_3 . "'  WHERE tid='" . $_arg_1 . "' AND first = '1'");
			$_var_3 = str_replace("\\t", '', $_var_3);
		} else {
			if (class_exists("tag")) {
				C::t("common_tagitem")->delete(0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => ''), true);
				$_var_5 = new tag();
				$_var_3 = $_var_5->update_field($_arg_0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => $_var_3), true, false, 1);
			}
		}
	}
	return $_var_3;
}
function addon_seo_tagrelatekw_strlen($_arg_0)
{
	if (function_exists("mb_strlen")) {
		$_var_1 = mb_strlen($_arg_0, "utf-8");
	} else {
		preg_match_all("/./us", $_arg_0, $_var_2);
		$_var_1 = count($_var_2[0]);
	}
	return $_var_1;
}
function addon_seo_tagrelatekw_check()
{
	addon_seo_tagrelatekw_validator();
	$_var_0 = '';
	$_var_1 = DISCUZ_ROOT . "./source/plugin/addon_seo_tagrelatekw/demo.php";
	if (!file_exists($_var_1)) {
		C::t("common_plugin")->delete_by_identifier("addon_seo_tagrelatekw");
		return 0;
	}
	if ($_var_2 = @fopen($_var_1, "r")) {
		$_var_0 = fread($_var_2, filesize($_var_1));
		fclose($_var_2);
	}
	$_var_0 = NULL;
}
function addon_seo_tagrelatekw_cleardir($_arg_0)
{
}
function addon_seo_tagrelatekw_deltree($_arg_0)
{
}
function addon_seo_tagrelatekw_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "From dism��taobao��com";
		return 0;
	}
	global $_G;