<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From dism��taobao��com";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	$_var_9 = in_array($_var_9, array("admin")) ? $_var_9 : "admin";
	if ($_var_9 == "admin") {
		$_var_10 = array();
		if (empty($_GET["perpage"]) && !empty($_POST["perpage"])) {
			$_GET["perpage"] = $_POST["perpage"];
		}
		if (submitcheck("submit") && !empty($_GET["tagidarray"]) && is_array($_GET["tagidarray"]) && !empty($_GET["operate_type"])) {
			$_var_11 = new tag();
			$_var_12 = array();
			$_var_13 = $_var_14 = $_var_15 = '';
			$_var_12 = $_GET["tagidarray"];
			$_var_13 = $_GET["operate_type"];
			if ($_var_13 == "delete") {
				$_var_11->delete_tag($_var_12);
			} else {
				if ($_var_13 == "open") {
					C::t("common_tag")->update($_var_12, array("status" => 0));
				} else {
					if ($_var_13 == "close") {
						C::t("common_tag")->update($_var_12, array("status" => 1));
					} else {
						if ($_var_13 == "merge") {
							$_var_16 = $_var_11->merge_tag($_var_12, $_GET["newtag"]);
							if ($_var_16 != "succeed") {
								cpmsg($_var_16);
							}
						}
					}
				}
			}
			cpmsg("tag_admin_updated", "action=" . STUDY_MANAGE_URL . "&searchsubmit=yes&formhash=" . $_G["formhash"] . "&tagname=" . $_GET["tagname"] . "&perpage=" . $_GET["perpage"] . "&status=" . $_GET["status"] . "&page=" . $_GET["page"], "succeed");
		}
		$_var_17 = trim($_GET["tagname"]);
		showformheader('' . STUDY_MANAGE_URL . '');
		showtableheader();
		showsetting("tagname", "tagname", $_var_17, "text");
		showsetting("feed_search_perpage", '', $_GET["perpage"], "<select name='perpage'><option value='20'" . ($_GET["perpage"] == 20 ? "selected=\"selected\"" : '') . ">" . $lang["perpage_20"] . "</option><option value='50'" . ($_GET["perpage"] == 50 ? "selected=\"selected\"" : '') . ">" . $lang["perpage_50"] . "</option><option value='100'" . ($_GET["perpage"] == 100 ? "selected=\"selected\"" : '') . ">" . $lang["perpage_100"] . "</option></select>");
		showsetting("misc_tag_status", array("status", array(array('', cplang("unlimited")), array(0, cplang("misc_tag_status_0")), array(1, cplang("misc_tag_status_1"))), true), '', "mradio");
		showsubmit("searchsubmit");
		showtablefooter();
		showformfooter();
		if (!empty($_GET["formhash"]) && $_GET["formhash"] == $_G["formhash"] || empty($_GET["tagname"])) {
			$_var_18 = $_GET["status"];
			if (!$_var_18) {
				$_var_19 = NULL;
			} else {
				$_var_19 = $_var_18;
			}
			$_var_20 = $_G["page"];
			$_var_21 = $_GET["perpage"] ? $_GET["perpage"] : 20;
			$_var_22 = ($_var_20 - 1) * $_var_21;
			$_var_23 = '';
			$_var_24 = C::t("common_tag")->fetch_all_by_status($_var_19, $_var_17, 0, 0, 1);
			$_var_23 = multi($_var_24, $_var_21, $_var_20, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&searchsubmit=yes&formhash=" . $_G["formhash"] . "&tagname=" . $_var_17 . "&perpage=" . $_var_21 . "&status=" . $_var_18 . '');
			$_var_25 = C::t("common_tag")->fetch_all_by_status($_var_19, $_var_17, $_var_22, $_var_21, 0, "DESC");
			showformheader('' . STUDY_MANAGE_URL . '');
			showtableheader(cplang("tag_result") . " " . $_var_24 . " ", "nobottom");
			showhiddenfields(array("page" => $_GET["page"], "tagname" => $_var_17, "status" => $_var_18, "perpage" => $_var_21));
			showsubtitle(array('', "ID", "tagname", "misc_tag_status"));
			foreach ($_var_25 as $_var_26) {
				if ($_var_26["status"] == 0) {
					$_var_27 = cplang("misc_tag_status_0");
				} else {
					if ($_var_26["status"] == 1) {
						$_var_27 = cplang("misc_tag_status_1");
					}
				}
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "width=300", ''), array("<input class=\"checkbox\" type=\"checkbox\" name=\"tagidarray[]\" value=\"" . $_var_26["tagid"] . "\" />", $_var_26["tagid"], "<a href=\"misc.php?mod=tag&id=" . $_var_26["tagid"] . "\" target=\"_blank\">" . $_var_26["tagname"] . "</a>", $_var_27));
			}
			showtablerow('', array("class=\"td25\" colspan=\"3\""), array("<input name=\"chkall\" id=\"chkall\" type=\"checkbox\" class=\"checkbox\" onclick=\"checkAll('prefix', this.form, 'tagidarray', 'chkall')\" /><label for=\"chkall\">" . cplang("select_all") . "</label>"));
			showtablerow('', array("class=\"td25\"", "colspan=\"3\""), array(cplang("operation"), "<input class=\"radio\" type=\"radio\" name=\"operate_type\" value=\"open\" checked> " . cplang("misc_tag_status_0") . " &nbsp; &nbsp;<input class=\"radio\" type=\"radio\" name=\"operate_type\" value=\"close\"> " . cplang("misc_tag_status_1") . " &nbsp; &nbsp;<input class=\"radio\" type=\"radio\" name=\"operate_type\" value=\"delete\"> " . cplang("delete") . " &nbsp; &nbsp;<input class=\"radio\" type=\"radio\" name=\"operate_type\" value=\"merge\"> " . cplang("mergeto") . " <input name=\"newtag\" value=\"\" class=\"txt\" type=\"text\">"));
			showsubmit("submit", "submit", '', '', $_var_23);
			showtablefooter();
			showformfooter();
		}
	}