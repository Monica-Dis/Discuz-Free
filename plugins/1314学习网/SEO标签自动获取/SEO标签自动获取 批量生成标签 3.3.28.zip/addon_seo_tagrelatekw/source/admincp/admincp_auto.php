<?php

function addon_seo_tagrelatekw_shutdown()
{
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	if (isset($_G["gettag_error"]) && $_G["gettag_error"] > 0) {
		cpmsg("&#x5E16;&#x5B50;&#x6807;&#x7B7E;&#x751F;&#x6210;&#x4E2D;......" . $_var_9, "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_10 . "&ac=" . $_var_11 . "&formhash=" . $_G["formhash"] . "&tid=" . $_G["gettag_error"], "loading");
	}
}
	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "From dism��taobao��com";
		return 0;
	}
	set_time_limit(0);
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $splugin_lang;
	global $type1314;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	global $lang;
	require_once DISCUZ_ROOT . "./source/plugin/addon_seo_tagrelatekw/source/function/function_core.php";
	if (empty($_G["inajax"])) {
		register_shutdown_function("addon_seo_tagrelatekw_shutdown");
	}
	if ($_GET["formhash"] && $_GET["formhash"] == $_G["formhash"]) {
		$_var_9 = dunserialize($splugin_setting["study_nofids"]);
		$_var_10 = intval($_GET["tid"]);
		$_var_11 = C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->fetch_all_by_search(array("first" => 1, "tags" => '', "tid" => array($_var_10, ">"), "invisible" => 0), array("tid" => "ASC"), 5);
		if (!empty($_var_11)) {
			foreach ($_var_11 as $_var_12 => $_var_13) {
				$_var_10 = $_var_13["tid"];
				$_G["gettag_error"] = $_var_10;
				if (!in_array($_var_13["fid"], $_var_9)) {
					$_var_14 = $_var_13["subject"];
					$_var_15 = $_var_13["message"];
					$_var_16 = '';
					if ($_G["cache"]["plugin"]["addon_seo_tagrelatekw"]["only_subject"]) {
						$_var_16 = $_var_14;
					} else {
						$_var_16 = $_var_14 . $_var_15;
					}
					$_var_16 = strip_tags(preg_replace("/\\[.+?\\]/is", '', $_var_16));
					$_var_17 = addon_seo_tagrelatekw_gettag($_var_16, $_var_14);
					if ($_var_17) {
						addon_seo_tagrelatekw_modthreadtag(implode(",", $_var_17), $_var_13["tid"]);
					}
					sleep(2);
				}
			}
			$_G["gettag_error"] = 0;
			cpmsg("&#x5E16;&#x5B50;&#x6807;&#x7B7E;&#x751F;&#x6210;&#x4E2D;..." . $_var_10, "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_18 . "&ac=" . $_var_19 . "&formhash=" . $_G["formhash"] . "&tid=" . $_var_10, "loading");
		} else {
			cpmsg("&#x5E16;&#x5B50;&#x6807;&#x7B7E;&#x751F;&#x6210;&#x5B8C;&#x6210;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_18 . "&ac=" . $_var_19, "succeed");
		}
	} else {
		s_shownav("sort", "sorts_admin");
		$_var_20 = C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->fetch_by_search(array("first" => 1, "tags" => 0), array("tid" => "ASC"));
		if (!empty($_var_20)) {
			C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->update_by_where(array("first" => 1, "tags" => 0), array("tags" => ''));
		}
		$_var_21 = C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->count_by_where(array("first" => 1, "tags" => '', "status" => 0));
		showtips("\r\n\t<li>&#x5E16;&#x5B50;&#x5728;&#x5BA1;&#x6838;&#x4E2D;&#x3001;&#x56DE;&#x6536;&#x7AD9;&#x3001;&#x5BA1;&#x6838;&#x5FFD;&#x7565;&#x3001;&#x8349;&#x7A3F;&#x7B49;&#x60C5;&#x51B5;&#x7684;&#xFF0C;&#x4E0D;&#x4F1A;&#x5904;&#x7406;</li>\r\n\t<li>&#x65E0;&#x6807;&#x7B7E;&#x5E16;&#x5B50;&#xFF1A;" . $_var_21 . "&#xFF0C;&#x8FD9;&#x91CC;&#x663E;&#x793A;&#x7684;&#x662F;&#x5168;&#x7AD9;&#x6570;&#x636E;&#xFF0C;&#x4F46;&#x5B9E;&#x9645;&#x4E0D;&#x4F1A;&#x5904;&#x7406;&#x201C;&#x4E0D;&#x4F7F;&#x7528;&#x7684;&#x7248;&#x5757;&#x201D;&#x91CC;&#x7684;&#x5E16;&#x5B50;</li>\r\n\t<li>&#x64CD;&#x4F5C;&#x524D;&#x8BF7;&#x5148;&#x5907;&#x4EFD;&#x597D;&#x6570;&#x636E;&#x5E93;&#xFF0C;&#x4EE5;&#x514D;&#x51FA;&#x73B0;&#x5F02;&#x5E38;&#x65F6;&#x53EF;&#x4EE5;&#x8FD8;&#x539F;&#xFF0C;&#x4E0D;&#x8FDB;&#x884C;&#x5907;&#x4EFD;&#x5C31;&#x64CD;&#x4F5C;&#xFF0C;&#x9700;&#x81EA;&#x884C;&#x627F;&#x62C5;&#x98CE;&#x9669;</li>\r\n\t");
		showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_18 . "&ac=" . $_var_19);
		showtableheader('');
		showsubmit("submit", "&#x4E00;&#x952E;&#x751F;&#x6210;&#x6807;&#x7B7E;");
		showtablefooter();
		showformfooter();
		$_var_22 = array("first" => 1, "tags" => '', "status" => 0);
		$_var_23 = 20;
		$_var_24 = 1000;
		$_var_21 = C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->count_by_where($_var_22);
		$_var_25 = intval($_GET["page"]);
		$_var_25 = $_var_25 - 1 > $_var_21 / $_var_23 || $_var_25 > $_var_24 ? 1 : $_var_25;
		$_var_26 = ($_var_25 - 1) * $_var_23;
		$_var_27 = multi($_var_21, $_var_23, $_var_25, ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $_var_18 . "&ac=" . $_var_19, $_var_24);
		$_var_11 = C::t("#addon_seo_tagrelatekw#addon_seo_tagrelatekw_forum_post")->fetch_all_by_search($_var_22, array("tid" => "ASC"), $_var_26, $_var_23);
		$_var_11 = dhtmlspecialchars($_var_11);
		$_var_28 = "addon_seo_tagrelatekw.plugin";
		$_var_29 = "DZG_ADDONS_" . substr(md5($_var_28), 0, 12);
		if (discuz_process::islocked($_var_29, 600)) {
			$_var_30 = cloudaddons_getmd5($_var_28);
			$_var_31 = dfsockopen(cloudaddons_url("&from=s") . "&mod=app&ac=validator&ver=2&addonid=" . $_var_28 . (!($_var_30 === false) ? "&rid=" . $_var_30["RevisionID"] . "&sn=" . $_var_30["SN"] . "&rd=" . $_var_30["RevisionDateline"] : ''), 0, '', '', false, '', 60);
		}
		showtableheader('');
		showsubtitle(array("&#x5E16;&#x5B50;", "&#x65F6;&#x95F4;", ''));
		clearstatcache();
		foreach ($_var_11 as $_var_20) {
			if (!empty($_var_20["subject"])) {
				showtablerow('', array("class=\"td28\" style=\"width:600px;\"", " style=\"width:180px;\"", ''), array(!empty($_var_20["tid"]) ? "<a href=\"forum.php?mod=viewthread&tid=" . $_var_20["tid"] . "\" target=\"_blank\" class=\"act\" style=\"text-decoration: none;\">" . $_var_20["subject"] . "</a>" : "<b style=\"color:red;\">&#x5E16;&#x5B50;&#x4E0D;&#x5B58;&#x5728;</b>", dgmdate($_var_20["dateline"], "Y-m-d H:i:s", $_G["setting"]["timeoffset"]), ''));
			}
		}
		showsubmit('', '', '', '', $_var_27);
		showtablefooter();
	}