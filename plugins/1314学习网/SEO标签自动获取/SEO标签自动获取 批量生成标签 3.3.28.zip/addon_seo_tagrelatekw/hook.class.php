<?php

/**
 * This is NOT a freeware, use is subject to license terms
 * From dism��taobao��com
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_addon_seo_tagrelatekw {
	function common(){
		global $_G;
		if(CURSCRIPT == 'forum' && $_GET['mod'] == 'relatekw'){
			$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
			if ($splugin_setting['radio']) {
				include_once DISCUZ_ROOT . './source/plugin/addon_seo_tagrelatekw/source/module/forum_relatekw.php';
				exit;
			}
		}
	}
}
class plugin_addon_seo_tagrelatekw_forum extends plugin_addon_seo_tagrelatekw {

	function viewthread_gettag_output() {
		global $_G, $postlist;
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['radio'] && $splugin_setting['notag_radio'] == 1) {
			$study_nofids = dunserialize($splugin_setting['study_nofids']);
			if (!in_array($_G['fid'], $study_nofids) && $_G['page'] == 1 && empty($postlist[$_G['forum_firstpid']]['tags']) && empty($postlist[$_G['forum_firstpid']]['stags'])){
				include_once libfile('function/core', 'plugin/addon_seo_tagrelatekw/source');
			}
		}
	}
	
	function viewthread_bottom_output(){
		global $_G, $postlist;
		$return = '';
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['radio'] && $splugin_setting['notag_radio'] == 2) {
			$study_nofids = dunserialize($splugin_setting['study_nofids']);
			if (!in_array($_G['fid'], $study_nofids) && $_G['page'] == 1 && empty($postlist[$_G['forum_firstpid']]['tags']) && empty($postlist[$_G['forum_firstpid']]['stags'])){
				$return = '<script type="text/javascript" src="plugin.php?id=addon_seo_tagrelatekw&tid='.$_G['tid'].'" defer="defer"></script>';
			}
		}
		return $return;
	}
	
	function post_attribute_extra_body() {
		global $_G;
		$return = '';
		$splugin_setting = $_G['cache']['plugin']['addon_seo_tagrelatekw'];
		if ($splugin_setting['messageenc_length']) {
			$messageenc_length = min(5000, max($splugin_setting['messageenc_length'], 100));
			if (preg_match('/MSIE/i', $_SERVER['HTTP_USER_AGENT'])) {
				$messageenc_length = min(2000, $messageenc_length); //IE
			}
			include template('addon_seo_tagrelatekw:relatekw');
		}
		return $return;
	}
}