<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 2020072707NGD0zc3TX3
 * This is NOT a freeware, use is subject to license terms
 * From dism.taobao.com?
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once ('pluginvar.func.php');
splugin_thinks(CURMODULE);
?>