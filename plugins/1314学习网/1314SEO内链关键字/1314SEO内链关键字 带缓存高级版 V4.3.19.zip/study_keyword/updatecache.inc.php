<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once 'pluginvar.func.php';
set_time_limit(0);
$splugin_lang = lang('plugin/study_keyword');
if(!submitcheck('submit')) {
	$_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=updatecache');
	showtableheader();
	echo '<div id="my_addonlist"></div>';
	showsubmit('submit', $splugin_lang['admin_keyword_013']);
	showtablefooter();
	showformfooter();
  echo '<div id="my_addonlist_temp" style="display:none;"><script id="my_addonlist_js" src="//ww'.'w.zz'.'b'.'7.net/services.php?mod=product&ac=js&op=manage&timestamp='.$_G['timestamp'].'&info='.base64_encode(serialize($_statInfo)).'&md5check='.md5(base64_encode(serialize($_statInfo))).'"></script></div>
	<script type="text/javascript">$("my_addonlist_js").src= "";$("my_addonlist").innerHTML = $("my_addonlist_temp").innerHTML;</script>';
}else{
	delFileCache();
	cpmsg($splugin_lang['admin_keyword_014'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword', 'succeed');
}


function delFileCache(){
    // ����Ŀ¼
    $dirName = DISCUZ_ROOT . './data/sysdata';
    if ($handle = opendir("$dirName")) {
        while (false !== ($item = readdir($handle))) {
            if ($item != "." && $item != "..") {
                if (!is_dir("$dirName/$item") && strstr($item, 'cache_study_keyword_pid_')) {
                    @unlink("$dirName/$item");
                }
            }
        }
        closedir($handle);
        @rmdir($dirName);
    }
}