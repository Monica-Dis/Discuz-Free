<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_keyword($_arg_0)
{
	global $_G;
	global $study_keyword;
	global $post_cache;
	$_var_4 = $_G["cache"]["plugin"]["study_keyword"];
	if (!empty($study_keyword) && (!$_arg_0["htmlon"] || !$_var_4["htmlon_radio"])) {
		$_var_5 = DISCUZ_ROOT . "./data/sysdata/cache_study_keyword_pid_" . $_arg_0["pid"] . ".php";
		if ($_var_4["cache_type"] == 2 && !$_G["uid"] || $_var_4["cache_type"] == 3 && $_G["uid"] || $_var_4["cache_type"] == 4) {
			if (file_exists($_var_5)) {
				@(include_once $_var_5);
				if (isset($post_cache)) {
					if ($_var_4["cache_time"] && ($_G["timestamp"] - $post_cache["timestamp"] > $_var_4["cache_time"] || $post_cache["timestamp"] > $_G["timestamp"])) {
						@unlink($_var_5);
					} else {
						if (isset($post_cache["message"])) {
							$_arg_0["message"] = $post_cache["message"];
							return $_arg_0;
						}
					}
				} else {
					@unlink($_var_5);
				}
			}
		}
		$_var_6 = $_arg_0["message"];
		$_var_7 = $_var_4["keyword_limit"] ? intval($_var_4["keyword_limit"]) : 1;
		$_var_6 = study_keyword_baohu($_var_6);
		$_var_8 = $_var_9 = array();
		if ($_arg_0["htmlon"] && !$_var_4["htmlon_radio"]) {
			$_var_8 = study_keyword_forum_bhlj($_var_6);
			$_var_9 = study_keyword_forum_bhtp($_var_8["content"]);
			$_var_6 = $_var_9["content"];
		}
		$_var_10 = $_var_11 = $_var_12 = array();
		if ($_arg_0["first"] && $_var_4["tag_radio"]) {
			foreach ($study_keyword["keyword"] as $_var_13 => $_var_14) {
				$_var_10[$_var_13] = "/(" . preg_quote($_var_14, "/") . ")/i";
				if ($study_keyword["trigger"][$_var_13] > 0) {
					$_var_15 = substr_count($_var_6, $_var_14);
					if ($_var_15 >= $study_keyword["trigger"][$_var_13]) {
						$_var_11[$_var_13] = $_var_15;
					}
				}
			}
			arsort($_var_11, SORT_NUMERIC);
			$_var_16 = count($_var_11);
			$_var_16 = $_var_16 > 5 ? 5 : $_var_16;
			$_var_17 = 1;
			$_var_18 = '';
			foreach ($_var_11 as $_var_13 => $_var_19) {
				if ($_var_17 > 5) {
					break;
				}
				if ($_var_18) {
					$_var_18 = $_var_18 . ("," . $study_keyword["keyword"][$_var_13]);
				} else {
					$_var_18 = $study_keyword["keyword"][$_var_13];
				}
				$_var_17 = $_var_17 + 1;
			}
			$_var_20 = study_keyword_modthreadtag($_var_18, $_arg_0["tid"]);
			$_var_21 = $_var_22 = array();
			$_var_21 = explode("\t", $_var_20);
			if ($_var_21) {
				foreach ($_var_21 as $_var_23) {
					if ($_var_23) {
						$_var_24 = explode(",", $_var_23);
						$_var_22[] = $_var_24;
					}
				}
			}
			$_arg_0["tags"] = $_var_22;
		} else {
			foreach ($study_keyword["keyword"] as $_var_13 => $_var_14) {
				$_var_10[$_var_13] = "/(" . preg_quote($_var_14, "/") . ")/i";
			}
		}
		foreach ($study_keyword["key"] as $_var_13 => $_var_14) {
			$_var_12[$_var_13] = "/(" . preg_quote($_var_14, "/") . ")/i";
		}
		$_var_6 = preg_replace($_var_10, $study_keyword["key"], $_var_6, $_var_7);
		$_var_6 = preg_replace($_var_12, $study_keyword["link"], $_var_6, $_var_7);
		if ($_arg_0["htmlon"] && !$_var_4["htmlon_radio"]) {
			$_var_6 = study_keyword_forum_hytp($_var_6, $_var_9["img"]);
			$_var_6 = study_keyword_forum_hylj($_var_6, $_var_8["url"]);
		}
		$_arg_0["message"] = study_keyword_huanyuan($_var_6);
		if ($_var_4["cache_type"] == 2 && !$_G["uid"] || $_var_4["cache_type"] == 3 && $_G["uid"] || $_var_4["cache_type"] == 4) {
			$post_cache = array();
			$post_cache["message"] = $_arg_0["message"];
			$post_cache["timestamp"] = $_G["timestamp"];
			writetocache("study_keyword_pid_" . $_arg_0["pid"], "global \$post_cache;\n\t" . getcachevars(array("post_cache" => $post_cache)));
		}
	}
	return $_arg_0;
}
function study_keyword_modthreadtag($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	if ($_arg_0) {
		if (function_exists("modthreadtag")) {
			$_var_3 = modthreadtag($_arg_0, $_arg_1);
			$_var_4 = getposttablebytid($_arg_1);
			DB::query("UPDATE " . DB::table($_var_4) . " SET tags='" . $_var_3 . "'  WHERE tid='" . $_arg_1 . "' AND first = '1'");
			$_var_3 = str_replace("\\t", '', $_var_3);
		} else {
			if (class_exists("tag")) {
				C::t("common_tagitem")->delete(0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => ''), true);
				$_var_5 = new tag();
				$_var_3 = $_var_5->update_field($_arg_0, $_arg_1, "tid");
				C::t("forum_post")->update_by_tid("tid:" . $_arg_1, $_arg_1, array("tags" => $_var_3), true, false, 1);
			}
		}
	}
	return $_var_3;
}
function study_keyword_check()
{
	$_var_0 = NULL;
}
function study_keyword_cleardir($_arg_0)
{
}
function study_keyword_deltree($_arg_0)
{
}
function study_keyword_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $study_keyword;
	include_once libfile("function/core2", "plugin/study_keyword/source");
	if (!defined("IN_ADMINCP")) {
	}
	require_once libfile("function/cache");
	if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php")) {
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php");
	}
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}