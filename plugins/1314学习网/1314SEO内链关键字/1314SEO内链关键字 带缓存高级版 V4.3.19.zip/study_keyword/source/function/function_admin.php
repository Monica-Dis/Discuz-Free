<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_keyword_loadCache()
{
	global $_G;
	global $study_keyword;
	global $forum_num;
	if (!@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php")) {
		study_keyword_updateCache();
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php");
	}
	@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_forum_num.php");
	$_G["study_keyword"]["keywords"] = $study_keyword;
	$_G["study_keyword"]["statistics"]["forum"] = $forum_num;
}
function study_keyword_updateCache()
{
	global $_G;
	global $study_keyword;
	global $forum_num;
	$_var_3 = array();
	$_var_4 = DB::query("SELECT * FROM " . DB::table("study_neilian_keyword") . " ORDER BY id ASC");
	while ($_var_5 = DB::fetch($_var_4)) {
		$_var_3[] = array("{study_key" . $_var_5["id"] . "}", $_var_5["keyword"], "<a href=\"" . $_var_5["link"] . "\" target=\"_blank\">" . study_keyword_wordStyle($_var_5["keyword"], unserialize($_var_5["style"])) . "</a>", intval($_var_5["trigger"]));
	}
	$_var_6 = count($_var_3);
	$_var_7 = 0;
	while ($_var_7 < $_var_6) {
		$_var_8 = $_var_6 - 1;
		while ($_var_8 > $_var_7) {
			if (strlen($_var_3[$_var_8][1]) > strlen($_var_3[$_var_8 - 1][1])) {
				$_var_9 = $_var_3[$_var_8];
				$_var_3[$_var_8] = $_var_3[$_var_8 - 1];
				$_var_3[$_var_8 - 1] = $_var_9;
			}
			$_var_8 = $_var_8 - 1;
		}
		$_var_7 = $_var_7 + 1;
	}
	foreach ($_var_3 as $_var_10 => $_var_11) {
		$_var_12["key"][$_var_10] = $_var_11[0];
		$_var_12["keyword"][$_var_10] = $_var_11[1];
		$_var_12["link"][$_var_10] = $_var_11[2];
		$_var_12["trigger"][$_var_10] = $_var_11[3];
	}
	writetocache("study_keyword", "global \$study_keyword;" . "\n\t" . getcachevars(array("study_keyword" => $_var_12)));
}
function study_keyword_updateOneConut($_arg_0, $_arg_1 = '')
{
	global $_G;
	global $study_keyword;
	global $forum_num;
	$_arg_0 = intval($_arg_0);
	if (empty($_arg_1)) {
		$_arg_1 = DB::result_first("SELECT keyword FROM " . DB::table("study_neilian_keyword") . " WHERE id ='" . $_arg_0 . "'");
	}
	if ($_arg_1) {
		$_arg_1 = addcslashes($_arg_1, "%_");
		$_var_5 = DB::query("SELECT pid,message FROM " . DB::table("forum_post") . " where message like '%" . $_arg_1 . "%' ORDER BY pid ASC");
		$_var_6 = 0;
		$_var_7 = 0;
		while ($_var_8 = DB::fetch($_var_5)) {
			$_var_7 = $_var_7 + substr_count($_var_8[message], $_arg_1);
			$_var_6 = $_var_6 + 1;
		}
		$forum_num = $_G["study_keyword"]["statistics"]["forum"];
		$forum_num["t"][$_arg_0] = $_var_6;
		$forum_num["all"][$_arg_0] = $_var_7;
		writetocache("study_forum_num", "global \$forum_num;" . "\n\t" . getcachevars(array("forum_num" => $forum_num)));
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_forum_num.php");
		if ($forum_num["t"][$_arg_0] == $_var_6) {
			return $_var_6;
		}
		return false;
	}
	return false;
}
function study_keyword_wordStyle($_arg_0 = '', $_arg_1 = '')
{
	$_arg_0 = $_arg_1["b"] ? "<b>" . $_arg_0 . "</b>" : $_arg_0;
	$_arg_0 = $_arg_1["i"] ? "<i>" . $_arg_0 . "</i>" : $_arg_0;
	$_arg_0 = $_arg_1["u"] ? "<u>" . $_arg_0 . "</u>" : $_arg_0;
	$_arg_0 = $_arg_1["c"] ? "<font color=" . $_arg_1["c"] . ">" . $_arg_0 . "</font>" : $_arg_0;
	return $_arg_0;
}
function study_keyword_check()
{
	$_var_0 = NULL;
}
function study_keyword_cleardir($_arg_0)
{
}
function study_keyword_deltree($_arg_0)
{
}
function study_keyword_validator()
{
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $study_keyword;
	global $forum_num;
	if ($_G["adminid"] > 0 || $_G["uid"] == 1) {
		if (!getcookie("security_created") || abs($_G["timestamp"] - getcookie("security_created")) > 86400) {
			dsetcookie("security_created", $_G["timestamp"], "86400");
		}
	}