<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_keyword_baohu($_arg_0)
{
	global $_G;
	$_var_2 = strtolower($_arg_0);
	$_var_3 = $_G["cache"]["plugin"]["study_keyword"];
	$_var_4 = false;
	if ($_var_3["dz_version"] <= 1) {
		if (in_array(substr($_G["setting"]["version"], 0, 1), array("F", "L"))) {
			$_var_4 = true;
		} else {
			if (substr($_G["setting"]["version"], 0, 1) == "X" && version_compare($_G["setting"]["version"], "X3.3", ">=")) {
				$_var_4 = true;
			}
		}
	} else {
		if ($_var_3["dz_version"] == 3) {
			$_var_4 = true;
		}
	}
	if (strpos($_var_2, "[/url]") !== false) {
		if ($_var_4) {
			$_arg_0 = preg_replace_callback("/\\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.|mailto:)?([^\r\n\\[\"']+?))?\\](.+?)\\[\\/url\\]/is", create_function("\$matches", "return study_keyword_parse(\$matches[0]);"), $_arg_0);
		} else {
			$_arg_0 = preg_replace("/\\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.|mailto:)?([^\r\n\\[\"']+?))?\\](.+?)\\[\\/url\\]/ies", "study_keyword_parse('\\0')", $_arg_0);
		}
	}
	if (strpos($_var_2, "[/img]") !== false) {
		if ($_var_4) {
			$_arg_0 = preg_replace_callback("/\\[img(=(\\d{1,4})[x|\\,](\\d{1,4}))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is", create_function("\$matches", "return study_keyword_parse(\$matches[0]);"), $_arg_0);
		} else {
			$_arg_0 = preg_replace("/\\[img(=(\\d{1,4})[x|\\,](\\d{1,4}))?\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/ies", "study_keyword_parse('\\0')", $_arg_0);
		}
	}
	return $_arg_0;
}
function study_keyword_parse($_arg_0)
{
	global $_G;
	if (isset($_G["study_keyword"]["count"])) {
		$_G["study_keyword"]["count"] = $_G["study_keyword"]["count"] + 1;
	} else {
		$_G["study_keyword"]["count"] = 1;
	}
	$_G["study_keyword"]["replace"][$_G["study_keyword"]["count"]] = $_arg_0;
	return "[study_keyword_replace]" . $_G["study_keyword"]["count"] . "[/study_keyword_replace]";
}
function study_keyword_huanyuan($_arg_0)
{
	global $_G;
	if ($_G["study_keyword"]["count"] && is_array($_G["study_keyword"]["replace"])) {
		foreach ($_G["study_keyword"]["replace"] as $_var_2 => $_var_3) {
			$_arg_0 = str_replace("[study_keyword_replace]" . $_var_2 . "[/study_keyword_replace]", $_var_3, $_arg_0);
		}
	}
	return $_arg_0;
}
function study_keyword_forum_bhlj($_arg_0)
{
	$_var_1 = "#<a (.*)href=\"(.*)\"(.*)>(.*)</a>#iUs";
	preg_match_all($_var_1, $_arg_0, $_var_2);
	if (!empty($_var_2)) {
		foreach ($_var_2[0] as $_var_3 => $_var_4) {
			$_var_5["url"][$_var_3] = $_var_4;
			$_var_6 = "[study_link]" . $_var_3 . "[/study_link]";
			$_arg_0 = str_replace($_var_5["url"][$_var_3], $_var_6, $_arg_0);
		}
		$_var_5["content"] = $_arg_0;
	}
	return $_var_5;
}
function study_keyword_forum_hylj($_arg_0, $_arg_1)
{
	$_var_2 = "#\\[study_link\\](.*)\\[/study_link\\]#iUs";
	preg_match_all($_var_2, $_arg_0, $_var_3);
	if (!empty($_var_3)) {
		foreach ($_var_3[0] as $_var_4 => $_var_5) {
			$_var_6 = $_var_5;
			$_var_7 = $_arg_1[$_var_4];
			$_arg_0 = str_replace($_var_6, $_var_7, $_arg_0);
		}
	}
	return $_arg_0;
}
function study_keyword_forum_bhtp($_arg_0)
{
	$_var_1 = "#<img (.*)src=\"([^\"]*)\"([^>]*)>#iUs";
	preg_match_all($_var_1, $_arg_0, $_var_2);
	if (!empty($_var_2)) {
		foreach ($_var_2[0] as $_var_3 => $_var_4) {
			$_var_5["img"][$_var_3] = $_var_4;
			$_var_6 = "[study_img]" . $_var_3 . "[/study_img]";
			$_arg_0 = str_replace($_var_5["img"][$_var_3], $_var_6, $_arg_0);
		}
		$_var_5["content"] = $_arg_0;
	}
	return $_var_5;
}
function study_keyword_forum_hytp($_arg_0, $_arg_1)
{
	if (!empty($_arg_1)) {
		foreach ($_arg_1 as $_var_2 => $_var_3) {
			$_var_4 = "[study_img]" . $_var_2 . "[/study_img]";
			$_var_5 = $_var_3;
			$_arg_0 = str_replace($_var_4, $_var_5, $_arg_0);
		}
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $study_keyword;