<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function study_keyword_portal($_arg_0)
{
	global $_G;
	global $study_keyword;
	$_var_3 = $_G["cache"]["plugin"]["study_keyword"];
	if ($_var_3["portal_radio"] && !empty($study_keyword)) {
		$_var_4 = $_var_3["keyword_limit"] ? intval($_var_3["keyword_limit"]) : 1;
		$_var_5 = study_keyword_portal_bhlj($_arg_0);
		$_var_6 = study_keyword_portal_bhtp($_var_5["content"]);
		$_arg_0 = $_var_6["content"];
		foreach ($study_keyword["keyword"] as $_var_7 => $_var_8) {
			$_var_9[$_var_7] = "/(" . preg_quote($_var_8, "/") . ")/i";
		}
		foreach ($study_keyword["key"] as $_var_7 => $_var_8) {
			$_var_10[$_var_7] = "/(" . preg_quote($_var_8, "/") . ")/i";
		}
		$_arg_0 = preg_replace($_var_9, $study_keyword["key"], $_arg_0, $_var_4);
		$_arg_0 = preg_replace($_var_10, $study_keyword["link"], $_arg_0, $_var_4);
		$_arg_0 = study_keyword_portal_hytp($_arg_0, $_var_6["img"]);
		$_arg_0 = study_keyword_portal_hylj($_arg_0, $_var_5["url"]);
	}
	return $_arg_0;
}
function study_keyword_portal_bhlj($_arg_0)
{
	$_var_1 = "#<a (.*)href=\"(.*)\"(.*)>(.*)</a>#iUs";
	preg_match_all($_var_1, $_arg_0, $_var_2);
	if (!empty($_var_2)) {
		foreach ($_var_2[0] as $_var_3 => $_var_4) {
			$_var_5["url"][$_var_3] = $_var_4;
			$_var_6 = "[study_link]" . $_var_3 . "[/study_link]";
			$_arg_0 = str_replace($_var_5["url"][$_var_3], $_var_6, $_arg_0);
		}
		$_var_5["content"] = $_arg_0;
	}
	return $_var_5;
}
function study_keyword_portal_hylj($_arg_0, $_arg_1)
{
	$_var_2 = "#\\[study_link\\](.*)\\[/study_link\\]#iUs";
	preg_match_all($_var_2, $_arg_0, $_var_3);
	if (!empty($_var_3)) {
		foreach ($_var_3[0] as $_var_4 => $_var_5) {
			$_var_6 = $_var_5;
			$_var_7 = $_arg_1[$_var_4];
			$_arg_0 = str_replace($_var_6, $_var_7, $_arg_0);
		}
	}
	return $_arg_0;
}
function study_keyword_portal_bhtp($_arg_0)
{
	$_var_1 = "#<img (.*)src=\"([^\"]*)\"([^>]*)>#iUs";
	preg_match_all($_var_1, $_arg_0, $_var_2);
	if (!empty($_var_2)) {
		foreach ($_var_2[0] as $_var_3 => $_var_4) {
			$_var_5["img"][$_var_3] = $_var_4;
			$_var_6 = "[study_img]" . $_var_3 . "[/study_img]";
			$_arg_0 = str_replace($_var_5["img"][$_var_3], $_var_6, $_arg_0);
		}
		$_var_5["content"] = $_arg_0;
	}
	return $_var_5;
}
function study_keyword_portal_hytp($_arg_0, $_arg_1)
{
	if (!empty($_arg_1)) {
		foreach ($_arg_1 as $_var_2 => $_var_3) {
			$_var_4 = "[study_img]" . $_var_2 . "[/study_img]";
			$_var_5 = $_var_3;
			$_arg_0 = str_replace($_var_4, $_var_5, $_arg_0);
		}
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $study_keyword;
	if (file_exists(DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php")) {
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_study_keyword.php");
	}