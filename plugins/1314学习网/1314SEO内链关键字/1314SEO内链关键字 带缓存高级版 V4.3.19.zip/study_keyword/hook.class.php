<?php

/**
 * Copyright 2001-2099 Dism.Taobao.Com.
 * This is NOT a freeware, use is subject to license terms
 * $Id: hook.class.php 4275 2020-06-19 16:39:21
 * Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue������ http://t.cn/AiuxBtT0��
 * Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux14ti
 * Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1Qh0
 * �����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
 * δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��
 */

if(!defined('IN_DISCUZ')) {
exit('Access Denied');
}
class plugin_study_keyword {
		public function discuzcode($param){
				global $_G, $postlist;
				if($param['caller'] == 'discuzcode' && CURSCRIPT == 'forum' && CURMODULE == 'viewthread'){
						$splugin_setting = $_G['cache']['plugin']['study_keyword'];
						if($splugin_setting['ifneilink']){
							if(!$_G['uid'] || !$splugin_setting['guest_radio']){
								//htmlon 
								//print_r($postlist);
									$post = $postlist[$param['param'][12]];
									if($splugin_setting['keyword_way'] == 1 && !$post['first']){
											return '';
									}elseif($splugin_setting['keyword_way'] == 2 && $post['first']){
											return '';
									}else{
											$post['message'] = $_G['discuzcodemessage'];
											$keyword_fids = unserialize($splugin_setting['keyword_fids']);
											if(in_array($post['fid'], $keyword_fids)){
												if(!function_exists('study_keyword')){
													include_once libfile('function/core','plugin/study_keyword/source');
												}
												$post = study_keyword($post);
											}
											$_G['discuzcodemessage'] = $post['message'];
									}
							}
						}
				}
		}
}

class plugin_study_keyword_forum extends plugin_study_keyword {

	
	public function misc_message($param) {
			global $_G;
			$param = $param['param'];
			$tid = intval($param[2]['tid']);
			$pid = intval($param[2]['pid']);
			if ($tid && $pid) {
					$splugin_setting = $_G['cache']['plugin']['study_keyword'];
					if($splugin_setting['ifneilink']){
							if(in_array($param[0], array('postappend_add_succeed'))){
									$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_study_keyword_pid_'.$pid.'.php';
									if(file_exists($cache_file)){
										@unlink($cache_file);
									}
							}
					}
			}
			return '';
	}
	
	public function post_message($param) {
			global $_G;
			$param = $param['param'];
			$tid = intval($param[2]['tid']);
			$fid = intval($param[2]['fid']);
			$pid = intval($param[2]['pid']);
			if ($tid && $pid) {
					$splugin_setting = $_G['cache']['plugin']['study_keyword'];
					$keyword_fids = unserialize($splugin_setting['keyword_fids']);
					
					if($splugin_setting['ifneilink'] && in_array($fid, $keyword_fids)){
							
							if(in_array($param[0], array('post_newthread_succeed', 'post_newthread_mod_succeed', 'post_edit_succeed', 'edit_newthread_mod_succeed', 'post_reply_succeed', 'edit_reply_mod_succeed'))){
									$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_study_keyword_pid_'.$pid.'.php';
									if(file_exists($cache_file)){
										@unlink($cache_file);
									}
							}
					}
			}
			return '';
	}
	
	public function _keyword_way_1($postlist) {
		foreach($postlist as $id => $post) {
			if($post['first']){
				$postlist[$id] = study_keyword($post);
				break;
			}
		}
		return $postlist;
	}
	
	public function _keyword_way_2($postlist) {
		foreach($postlist as $id => $post) {
			if(!$post['first']){
				$postlist[$id] = study_keyword($post);
			}
		}
		return $postlist;
	}
	
	public function _keyword_way_3($postlist) {
		foreach($postlist as $id => $post) {
			$postlist[$id] = study_keyword($post);
		}
		return $postlist;
	}
}

class plugin_study_keyword_portal extends plugin_study_keyword {

		function view_article_content_output() {

        global $_G, $content;
        $splugin_setting = $_G['cache']['plugin']['study_keyword'];
        if($splugin_setting['portal_radio'] && (!$_G['uid'] || !$splugin_setting['guest_radio'])){
            include_once libfile('function/core_portal','plugin/study_keyword/source');
            $content['content'] = study_keyword_portal($content['content']);
        }
        return '';
    }
}

$funcs = array();
foreach($_G['setting']['hookscript']['global']['discuzcode']['funcs']['discuzcode'] as $value){
	if($value[0] == 'study_keyword'){
		$funcs[] = $value;
		break;
	}
}
foreach($_G['setting']['hookscript']['global']['discuzcode']['funcs']['discuzcode'] as $value){
	if($value[0] != 'study_keyword'){
		$funcs[] = $value;
	}
}
$_G['setting']['hookscript']['global']['discuzcode']['funcs']['discuzcode'] = $funcs;

//Copyright 2001-2099 Dism.Taobao.Com.
//This is NOT a freeware, use is subject to license terms
//$Id: hook.class.php 4737 2020-06-19 08:39:21
//Ӧ���ۺ����⣺http://dism.taobao.com/?/services.php?mod=issue ������ http://t.cn/AiuxBLQV��
//Ӧ����ǰ��ѯ��QQ http://t.cn/Aiux1Jx1
//Ӧ�ö��ƿ�����QQ http://t.cn/Aiux1ug8
//�����Ϊ DisM!Ӧ�����ģ�dism.taobao.com�� ����������ԭ�����, ����ӵ�а�Ȩ��
//δ���������ù������ۡ�������ʹ�á��޸ģ����蹺������ϵ���ǻ����Ȩ��