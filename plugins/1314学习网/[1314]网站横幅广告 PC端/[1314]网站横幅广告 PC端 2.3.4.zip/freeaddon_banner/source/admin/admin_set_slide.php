<?php

	if (!defined("IN_DISCUZ") || !defined("IN_ADMINCP")) {
		echo "{ADDONVAR:SiteID}";
		return 0;
	}
	global $_G;
	global $plugin;
	global $splugin_setting;
	global $type1314;
	global $op;
	global $_statInfo;
	global $pluginid;
	global $pluginvars;
	require_once libfile("function/core", "plugin/freeaddon_banner/source");
	$_var_8 = array("list", "edit", "add");
	$op = in_array($_GET["op"], $_var_8) ? $_GET["op"] : "list";
	if ($op == "list") {
		if (!submitcheck("submit")) {
			if (defined("IN_FREEADDON_BANNER_FREE")) {
				echo "<div class=\"wp\" style=\"text-align:center;zoom:1;margin-top:8px;padding: 10px 0;background:#E5EDF2;font:25px/1.5 Tahoma,Helvetica,'SimSun',sans-serif;font-weight:bold;color:red;\">\r\n\t\t      &#x514D;&#x8D39;&#x7248;&#x53EA;&#x80FD;&#x663E;&#x793A;&#x4E00;&#x6761;&#xFF0C;<a href=\"https://addon.dismall.com/?@freeaddon_banner.plugin.80906\" target=\"_blank\">&#x5982;&#x9700;&#x663E;&#x793A;&#x66F4;&#x591A;&#x8BF7;&#x5B89;&#x88C5;&#x6536;&#x8D39;&#x7248;</a>\r\n\t\t      </div>";
			}
			showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_9);
			showtableheader('');
			$_var_10 = $_var_11 = array();
			showsubtitle(array("del", "&#x663E;&#x793A;&#x987A;&#x5E8F;", "&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "&#24191;&#21578;&#38142;&#25509;", "&#x72B6;&#x6001;", "&#x5F00;&#x59CB;&#x65F6;&#x95F4;", "&#x7ED3;&#x675F;&#x65F6;&#x95F4;", "&#x64CD;&#x4F5C;", ''));
			if ($_GET["type1314"] == "touchslide") {
				$_var_12 = C::t("#freeaddon_banner#freeaddon_banner_slide")->fetch_all_by_search(array("pt" => "2"), array("displayorder" => "ASC", "id" => "ASC"));
			} else {
				$_var_12 = C::t("#freeaddon_banner#freeaddon_banner_slide")->fetch_all_by_search(array("pt" => "1"), array("displayorder" => "ASC", "id" => "ASC"));
			}
			foreach ($_var_12 as $_var_13) {
				showtablerow('', array("class=\"td25\"", "class=\"td25\"", "class=\"td32\"", "class=\"td31\"", "class=\"td31\"", " style=\"width:50px;\"", " style=\"width:120px;\"", " style=\"width:120px;\"", " style=\"width:100px;\""), array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"" . $_var_13["id"] . "\" " . $_var_14 . ">", "<input type=\"text\" class=\"txt\" name=\"order[" . $_var_13["id"] . "]\" value=\"" . $_var_13["displayorder"] . "\" style=\"height: 20px;\">", "<a href=\"" . $_var_13["pic"] . "\" target=\"_blank\"  class=\"tooltip\"><img src=\"" . $_var_13["pic"] . "\" style=\"width:250px;height: 50px;\"></a>", "<input type=\"text\" name=\"title[" . $_var_13["id"] . "]\" value=\"" . $_var_13["title"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", "<input type=\"text\" name=\"url[" . $_var_13["id"] . "]\" value=\"" . $_var_13["url"] . "\" class=\"txt\" style=\"width: 150px;height: 20px;\">", "<div style=\"width:30px;\"><input name=\"status[" . $_var_13["id"] . "]\" type=\"checkbox\" value=\"1\" " . ($_var_13["status"] ? "checked=\"checked=\"" : '') . "/></div>", "<input type=\"text\" class=\"txt\" name=\"startt[" . $_var_13["id"] . "]\" style=\"width: 120px;\" value=\"" . ($_var_13["starttime"] == 0 ? '' : date("Y-m-d", $_var_13["starttime"])) . "\" onclick=\"showcalendar(event, this)\">", "<input type=\"text\" class=\"txt\" name=\"endt[" . $_var_13["id"] . "]\" style=\"width: 120px;\"  value=\"" . ($_var_13["endtime"] == 0 ? '' : date("Y-m-d", $_var_13["endtime"])) . "\" onclick=\"showcalendar(event, this)\">", "<a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit&cid=" . $_var_13["id"] . "\" class=\"act\">" . cplang("edit") . "</a>", ''));
			}
			echo "<tr><td></td><td colspan=\"7\"><div><a href=\"" . ADMINSCRIPT . "?action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=edit\" class=\"addtr\">&#x6DFB;&#x52A0;&#x5E7F;&#x544A;</a></div></td></tr>";
			showsubmit("submit", "submit", "del");
			showtablefooter();
			showformfooter();
		} else {
			if (is_array($_POST["delete"])) {
				foreach ($_POST["delete"] as $_var_15) {
					$_var_15 = intval($_var_15);
					C::t("#freeaddon_banner#freeaddon_banner_slide")->delete_by_where(array("id" => $_var_15), true);
				}
			}
			if (is_array($_POST["order"])) {
				foreach ($_POST["order"] as $_var_15 => $_var_16) {
					C::t("#freeaddon_banner#freeaddon_banner_slide")->update($_var_15, array("title" => $_POST["title"][$_var_15], "status" => $_POST["status"][$_var_15], "url" => $_POST["url"][$_var_15], "starttime" => empty($_POST["startt"][$_var_15]) ? 0 : strtotime($_POST["startt"][$_var_15]), "endtime" => empty($_POST["endt"][$_var_15]) ? 0 : strtotime($_POST["endt"][$_var_15]), "displayorder" => $_POST["order"][$_var_15]));
				}
			}
			freeaddon_banner_cache(1);
			cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_9, "succeed");
		}
	} else {
		if ($op == "edit") {
			$_var_15 = intval($_GET["cid"]);
			$_var_13 = C::t("#freeaddon_banner#freeaddon_banner_slide")->fetch_by_search(array("id" => $_var_15));
			if (!submitcheck("submit")) {
				showformheader(STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=" . $op . "&ac=" . $_var_9 . "&cid=" . $_var_15, "enctype");
				showtableheader("&#x57FA;&#x672C;&#x8BBE;&#x7F6E;");
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x6807;&#x9898;", "title", $_var_13["title"], "text", '', '', '');
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x56FE;&#x7247;", "pic", $_var_13["pic"], "filetext", '', '', "&#x56FE;&#x7247;&#x5927;&#x5C0F;&#xFF1A;960x90");
				s_showsetting("&#x5E7F;&#x544A;&#x4F4D;&#x94FE;&#x63A5;", "url", $_var_13["url"], "text", '', '', '');
				s_showsetting("&#x5F00;&#x59CB;&#x65F6;&#x95F4;", "startt", $_var_13["starttime"] == 0 ? '' : date("Y-m-d", $_var_13["starttime"]), "calendar", '', '', '');
				s_showsetting("&#x7ED3;&#x675F;&#x65F6;&#x95F4;", "endt", $_var_13["endtime"] == 0 ? '' : date("Y-m-d", $_var_13["endtime"]), "calendar", '', '', '');
				s_showsetting("&#x662F;&#x5426;&#x542F;&#x7528;", "status", $_var_13["status"] === 0 ? 0 : 1, "radio", '', '', '');
				s_showsetting("&#x663E;&#x793A;&#x987A;&#x5E8F;", "displayorder", $_var_13["displayorder"], "number", '', '', '');
				showtableheader();
				showsubmit("submit", "submit");
				showformfooter();
			} else {
				$_var_17 = array("title" => $_POST["title"], "url" => $_POST["url"], "starttime" => empty($_POST["startt"]) ? 0 : strtotime($_POST["startt"]), "endtime" => empty($_POST["endt"]) ? 0 : strtotime($_POST["endt"]), "status" => dintval($_POST["status"]), "displayorder" => dintval($_POST["displayorder"]));
				$_var_17["pt"] = $_GET["type1314"] == "touchslide" ? 2 : 1;
				if ($_FILES["pic"]) {
					require_once libfile("discuz/upload", "class");
					$_var_18 = new discuz_upload();
					$_var_19 = freeaddon_banner_pic();
					if (!empty($_var_19)) {
						$_var_17["pic"] = $_var_19;
					}
				} else {
					$_var_17["pic"] = $_POST["pic"];
				}
				if (empty($_var_13)) {
					C::t("#freeaddon_banner#freeaddon_banner_slide")->insert($_var_17);
				} else {
					C::t("#freeaddon_banner#freeaddon_banner_slide")->update($_var_15, $_var_17, 1);
				}
				freeaddon_banner_cache(1);
				cpmsg("&#x64CD;&#x4F5C;&#x6210;&#x529F;", "action=" . STUDY_MANAGE_URL . "&type1314=" . $type1314 . "&op=list", "succeed");
			}
		}
	}
	echo "\r\n<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>\r\n<script type=\"text/javascript\" src=\"http://code.jquery.com/jquery-1.10.2.min.js\"></script>\r\n<script type=\"text/javascript\">\r\njQuery.noConflict();\r\njQuery(function () {\r\nvar x = 10;\r\nvar y = 20;\r\njQuery(\"a.tooltip\").mouseover(function (e) {\r\nthis.myTitle = this.title;\r\nthis.title = \"\";\r\nvar imgTitle = this.myTitle ? \"<br />\" + this.myTitle + \" \" : \"\";\r\nvar tooltip = \"<div id='tooltip'><img src='\" + this.href + \"'  width='100%' height='100%' />\" + imgTitle + \"</div>\";\r\njQuery(\"body\").append(tooltip);\r\njQuery(\"#tooltip\")\r\n.css({\r\n\"top\": (e.pageY + y) + \"px\",\r\n\"left\": (e.pageX + x) + \"px\"\r\n}).show(\"fast\");\r\n}).mouseout(function (e) {\r\nthis.title = this.myTitle;\r\njQuery(\"#tooltip\").remove();\r\n}).mousemove(function (e) {\r\njQuery(\"#tooltip\").css({\r\n\"top\": (e.pageY + y) + \"px\",\r\n\"left\": (e.pageX + x) + \"px\"\r\n});\r\n});\r\n})\r\n</script>\r\n<style>\r\n#tooltip{\r\nposition: absolute;\r\nbackground-color: #eee;\r\nborder: 1px solid #999;\r\n}\r\n</style>\r\n";