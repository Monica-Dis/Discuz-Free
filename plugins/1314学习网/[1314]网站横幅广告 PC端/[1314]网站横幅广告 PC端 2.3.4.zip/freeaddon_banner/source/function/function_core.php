<?php

function freeaddon_banner_cache($_arg_0 = '')
{
	global $freeaddon_banner_slidelist;
	global $slidelist;
	if (!is_array($freeaddon_banner_slidelist)) {
		$freeaddon_banner_slidelist = array();
	}
	$slidelist = array();
	if (!file_exists(DISCUZ_ROOT . "./data/sysdata/cache_freeaddon_banner_info.php") || $_arg_0) {
		require_once libfile("function/cache");
		$_var_3 = C::t("#freeaddon_banner#freeaddon_banner_slide")->fetch_all_by_search(array("status" => "1"), array("displayorder" => "ASC", "id" => "ASC"));
		foreach ($_var_3 as $_var_4 => $_var_5) {
			$_var_5["starttime"] = date("Ymd", $_var_5["starttime"]);
			$_var_5["endtime"] = date("Ymd", $_var_5["endtime"]);
			if ($_var_5["pt"] == 1) {
				$slidelist["pc"][] = $_var_5;
			} else {
				$slidelist["touch"][] = $_var_5;
			}
		}
		writetocache("freeaddon_banner_info", "global \$slidelist,\$tslidelist;" . getcachevars(array("slidelist" => $slidelist)));
	} else {
		@(include_once DISCUZ_ROOT . "./data/sysdata/cache_freeaddon_banner_info.php");
	}
	if (!empty($slidelist)) {
		$freeaddon_banner_slidelist = $slidelist;
	}
	return $freeaddon_banner_slidelist;
}
function freeaddon_banner_ad($_arg_0, $_arg_1)
{
	global $_G;
	$_var_3 = array();
	$_var_4 = $_G["cache"]["plugin"]["freeaddon_banner"];
	$_var_5 = unserialize($_G["cache"]["plugin"]["freeaddon_banner"]["freeadon_no_groups"]);
	if (!is_array($_var_5)) {
		$_var_5 = array();
	}
	$_var_3[] = $_var_4["list_radio"] ? "forumdisplay" : '';
	$_var_3[] = $_var_4["viewthread_radio"] ? "viewthread" : '';
	$_var_6 = array();
	$_var_7 = dgmdate($_G["timestamp"], "Ymd", $_G["setting"]["timeoffset"]);
	if ($_var_4[$_arg_0 . "_radio"] && !in_array($_G["groupid"], $_var_5) && (in_array(CURMODULE, $_var_3) || CURMODULE == "index") && CURSCRIPT == "forum") {
		$_var_8 = freeaddon_banner_cache();
		foreach ($_var_8[$_arg_1] as $_var_9 => $_var_10) {
			if ($_var_10["starttime"] <= $_var_7 && $_var_10["starttime"] && ($_var_7 <= $_var_10["endtime"] || $_var_10["endtime"] == 19700101)) {
				$_var_6[$_var_9] = $_var_10;
			}
		}
		if ($_var_4[$_arg_0 . "_random"]) {
			shuffle($_var_6);
		}
		if (defined("IN_FREEADDON_BANNER_FREE")) {
			$_var_4[$_arg_0 . "_num"] = 1;
		}
		$_var_6 = array_slice($_var_6, 0, $_var_4[$_arg_0 . "_num"]);
	}
	return $_var_6;
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}