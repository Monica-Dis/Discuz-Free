<?php

function study_anonymous_post()
{
	global $_G;
	global $subject;
	$_var_2 = $_var_3 = array();
	$_var_4 = $_G["cache"]["plugin"]["study_anonymous"];
	$_var_5 = unserialize($_var_4["study_forums"]);
	$_var_6 = unserialize($_var_4["study_groups"]);
	if ($_var_4["study_newthread"]) {
		$_var_2 = array("newthread");
	}
	if ($_var_4["study_reply"]) {
		$_var_2[] = "reply";
	}
	if ($_G["uid"] && in_array($_G["groupid"], $_var_6) && in_array($_G["fid"], $_var_5) && in_array($_GET["action"], $_var_2)) {
		$_G["group"]["allowanonymous"] = $_G["forum"]["allowanonymous"] = $_GET["isanonymous"] = $_POST["isanonymous"] = 1;
	}
}
function study_anonymous_look()
{
	global $_G;
	global $postlist;
	$_var_2 = unserialize($_G["cache"]["plugin"]["study_anonymous"]["study_lookgroups"]);
	if (!in_array($_G["groupid"], $_var_2)) {
		return '';
	}
	foreach ($postlist as $_var_3 => $_var_4) {
		if ($_var_4["anonymous"] == 1) {
			if ($_var_4["authorid"] != 0) {
				$postlist[$_var_3]["anonymous"] = 0;
				$postlist[$_var_3]["author"] = "<font color=\"" . $_G["cache"]["plugin"]["study_anonymous"]["study_color"] . "\">" . lang("plugin/study_anonymous", "slang_001") . "</font>" . $postlist[$_var_3]["username"];
			}
		}
	}
}
	if (!defined("IN_DISCUZ")) {
		echo "{ADDONVAR:SiteUrl}";
		return 0;
	}