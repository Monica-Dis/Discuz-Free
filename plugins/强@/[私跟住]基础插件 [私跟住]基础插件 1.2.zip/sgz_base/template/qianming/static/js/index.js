$(document).ready(function(){
    var AllPageData = {
    }

    var shareData = {}

    $(function() {
        // $('.ui-page').addClass('scroll');
        $('.poster-box').hide()
        var res = JSON.parse(value)
        AllPageData = res.index
        pxToRem()
        // $("body").on('touchmove', function (e) {
        //     e.preventDefault()
        // }) 

        var聽overscroll聽=聽function(el)聽{
            聽聽el.addEventListener('touchstart',聽function()聽{聽聽聽聽
                var聽top聽=聽el.scrollTop,聽
                totalScroll聽=聽el.scrollHeight,聽
                currentScroll聽=聽top聽+聽el.offsetHeight;聽聽聽聽
            聽聽聽聽if(top聽===聽0)聽{
            聽聽聽聽聽聽el.scrollTop聽=聽1;
            聽聽聽聽}聽else聽if(currentScroll聽===聽totalScroll)聽{
            聽聽聽聽聽聽el.scrollTop聽=聽top聽-聽1;
            聽聽聽聽}
            聽聽});
            聽聽el.addEventListener('touchmove',聽function(evt)聽{聽聽聽
            聽聽聽聽if(el.offsetHeight聽<聽el.scrollHeight)
            聽聽聽聽聽聽evt._isScroller聽=聽true;
            聽聽});
            }

        overscroll(document.querySelector('.scroll'));
        document.body.addEventListener('touchmove',聽function(evt)聽{聽聽
        聽聽if(!evt._isScroller)聽{
        聽聽聽聽evt.preventDefault();
        聽聽}
        });
    })

    var domain = window.location.host

    var name = ""
	var isPost = false
    var timer = 0
	$(document).on('tap','.button',function(){
        window.scrollTo(0,0)
        var complete = true
        var _form = {}
        var parms = ''
        // index.blur()

        $(".input-box").map(function(value,index) {

            parms += '&'+ $(index).data('id') + '=' + $(index).val()
            // if($(index).val().length == 0){complete = false}
            index.blur()
        })
        // if(!complete) return tpl('璇峰厛瀹屽杽淇℃伅')
        showLoading('娴锋姤鐢熸垚涓�...')
        isPost = true
        var posterImg = document.getElementById("poster-img")
        var poster = document.getElementById("poster")
        poster.touchmove = function(e){
            e.preventDefault();
            e.stopPropagation();
        }

        $.ajax({
            type: 'get',
            url: '/poster/index/poster?unique_id='+ getUrlParms('unique_id')+ parms,
            // data: $(this).serializeArray(),
            dataType: "json",
            success: function(data) {
            },
            fail: function(err){
            },
            complete: function(e){
                if(e.responseJSON.code!=0){
                    hideLoading()
                    tpl(e.responseJSON.msg)    
                }else{
                var image = new Image()
                image.src =  'data:image/png;base64,'+e.responseJSON.data.poster_base64
                image.onload = function(){
                        $('.poster-box').show()
                        hideLoading()
                        isPost = false
                        
                        posterImg.src = 'data:image/png;base64,'+e.responseJSON.data.poster_base64
                        poster.scrollTop = poster.scrollHeight; 
                    }
                }
            }
        })
	})

	function tpl(text) {
        var html = "";
        html = "<div class='hint'>" + text + "</div>";
        $("body").append(html);
        setTimeout(function() {
            $('.hint').remove();
        }, 2000)
    }

    function showLoading(text){
        var _text = text || '姝ｅ湪鎻愪氦'
        var html = "";
        html = "<div class='Loading'><div class='icon'></div><div>"+ _text + "</div></div>";
        $("body").append(html);
    }

    function hideLoading(){
        $('.Loading').remove();
    }


    function getTime(){
        var myDate = new Date();
        var year = myDate.getFullYear();
        var month = myDate.getMonth() + 1
        var day = myDate.getDate()
        return year + '骞�' + month + '鏈�' + day + '鏃�'
    }

    $(document).on('tap','.close',function(){
        $('.poster-box').hide()
    })

    // 椤甸潰
    function pxToRem(){
        // console.log(AllPageData)
        // //37.5PX = 1em
        var buttonObj = AllPageData.buttonObj,
        inputBox = AllPageData.inputBox
        $('.button').css('width', buttonObj.width/37.5 + 'rem')
        $('.button').css('height', buttonObj.height/37.5 + 'rem')
        $('.button').css('top', buttonObj.y/37.5 + 'rem')
        $('.button').css('left', buttonObj.x/37.5 + 'rem' )
        if(buttonObj.background){
            $('.button').css('background-image', "url(" + buttonObj.background +")")
        }

        $('.wrapper').css('background-image', "url(" + AllPageData.background +")")
        $('.wrapper').height(Number(AllPageData.height)/37.5+'rem')

        Object.keys(inputBox).map(function(value,index) {
            var _inputData = inputBox[value]
            var dom = ".input-box-"+_inputData.id
            var styleContent = dom+'input:-moz-placeholder {color:' + _inputData.color + ';} '+dom+'::-webkit-input-placeholder {color:' + _inputData.color + ';}'; 
            var styleBlock = '<style id="placeholder-style">' + styleContent + '</style>'; 
            $('head').append(styleBlock); 


            var draggable = "<input class='input-box input-box-"+_inputData.id+"' style='color:"+ _inputData.color+";background:"+_inputData.background +";width:" + _inputData.width/37.5 +"rem; height: " + _inputData.height/37.5 +"rem; top: "+ _inputData.y/37.5 +"rem;left: "+ _inputData.x/37.5 +"rem; font-size: "+ _inputData.fontSize/37.5 +"rem' placeholder='" + _inputData.placeholder + "' data-id='" + _inputData.id +"'/>"
            $(draggable).appendTo('#form')
        })

        $("input").on("blur",function(){
            window.scrollTo(0,0); //璁╅〉闈㈠綊浣�
        });
    }

    //鑾峰彇椤甸潰鍙傛暟

     function getUrlParms(name){
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if(r!=null)
        return unescape(r[2]);
        return null;
    }

})

