<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function check_region(){

    global $_G;
    $sgz_baseConfig = $_G['cache']['plugin']['sgz_base'];
    $appcode    = trim($sgz_baseConfig['sgz_regioncode']);
    $headers    = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $url        =  "https://api01.aliyun.venuscn.com/ip?ip=" . $_G['clientip'];
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    $return = curl_exec($curl);
    $content = json_decode($return,true);
    $content = wx_iconv($content);
    $ip_region = '';
    if(is_array($content) && !empty($content) && $content['msg'] == 'success' && is_array($content['data']) && !empty($content['data'])){
        $ip_region = $content['data']['region'].' '.$content['data']['city'];  
        $region_list = preg_quote(trim($sgz_baseConfig['sgz_region_list']), '/');
        $region_list = str_replace(array("\\*"), array('.*'), $region_list);
        $region_list = '.*('.$region_list.').*';
        $region_list = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $region_list).')$/i';
        if(@preg_match($region_list, $ip_region,$matches)) {
            return true;
        }
    }
    return false;
}

if(!function_exists('get_plugin_config')){
	function get_plugin_config($pluginid){
		$pluginVarList = C::t('common_pluginvar')->fetch_all_by_pluginid($pluginid);
		$pluginConfig = array();
		foreach ($pluginVarList as $vark => $varv){
			$pluginConfig[$varv['variable']] = $varv['value'];
		}
		return $pluginConfig;
	}
}

if(!function_exists('wx_iconv')){
	function wx_iconv($arr) {
		if(is_array($arr)) {
			foreach($arr AS $key => $val) {
				$arr[$key] = wx_iconv($val);
			}
		} else {
			$arr = diconv($arr, 'utf-8', CHARSET);
		}
		return $arr;
	}
}

if(!function_exists('newpicurl')){
	function newpicurl($picurl) {
		global $_G;
		if (!preg_match('/^http/', $picurl)) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'sgzwx/' . $picurl;
			
		}else {
			$picurl = $picurl;
		}
		return $picurl;
	}
}

if(!function_exists('getHtml')){
	function getHtml($url){
		if(function_exists('curl_init')){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			$return = curl_exec($ch);
			curl_close($ch); 
			return $return;
		}
		return false;
	}
}


if(!function_exists('postDataCurl')){
	function postDataCurl($data, $url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$return = curl_exec($ch);
		if($return){
			curl_close($ch);
			return $return;
		} else { 
			$error = curl_errno($ch);
			curl_close($ch);
			return false;
		}
	}
}

