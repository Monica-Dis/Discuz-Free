<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = '';
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
	$tom_weixin_qrcode_field = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_field();
	if (!empty($tom_weixin_qrcode_field) && !isset($tom_weixin_qrcode_field['sgz_type'])) {
		$sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `sgz_type` tinyint(4) DEFAULT '0';\n";
	}
	if (!empty($tom_weixin_qrcode_field) && !isset($tom_weixin_qrcode_field['sgz_expire_days'])) {
		$sql .= "ALTER TABLE ".DB::table('tom_weixin_qrcode')." ADD `sgz_expire_days` tinyint(4) DEFAULT '0';\n";
	}

	if (!empty($sql)) {
		runquery($sql);
	}
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_sgz_base_activityjoin20` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `picurl` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `add_time` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `activity_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_sgz_base_haibao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `xuni_num` int(11) NOT NULL DEFAULT '0',
  `bg0` varchar(255) NOT NULL,
  `bg1` varchar(255) NOT NULL,
  `hb_btn` varchar(255) NOT NULL,
  `mp3url` varchar(255) NOT NULL,
  `user_name_left` int(11) NOT NULL,
  `user_name_top` int(11) NOT NULL,
  `riqi_left` int(11) NOT NULL,
  `riqitop` int(11) NOT NULL,
  `cydesc` varchar(255) NOT NULL,
  `cydesc_bottom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `share_title` varchar(255) NOT NULL,
  `share_logo` varchar(255) NOT NULL,
  `share_desc` varchar(255) NOT NULL,
  `clicks` int(11) NOT NULL DEFAULT '0',
  `bgcolor` varchar(255) NOT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;