<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$Lang = $scriptlang['sgz_base'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=sgz_base&pmod=admin';
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=sgz_base&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=sgz_base&pmod=admin';

include DISCUZ_ROOT.'./source/plugin/sgz_base/class/sgz_common.core.php';
include DISCUZ_ROOT.'./source/plugin/sgz_base/class/sgz_form.php';
include DISCUZ_ROOT.'./source/plugin/sgz_base/class/sgz_upload.php';


$sgzSysOffset = getglobal('setting/timeoffset');
$sgz_baseConfig = get_plugin_config($pluginid);
$appid              = trim($sgz_baseConfig['sgz_appid']);
$appsecret          = trim($sgz_baseConfig['sgz_appsecret']);
$Lang = formatLang($Lang);
include DISCUZ_ROOT.'./source/plugin/sgz_base/admin/haibao.php';