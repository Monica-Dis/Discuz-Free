<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=haibao';
$modListUrl = $adminListUrl.'&tmod=haibao';
$modFromUrl = $adminFromUrl.'&tmod=haibao';


if($_GET['act'] == 'add'){
	
	if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
		C::t('#sgz_base#sgz_base_haibao')->insert($insertData);
        cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', $modListUrl, 'succeed');
		
    }else{
		
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype="multipart/form-data" onsubmit="return check()"');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism��taobao��com*/
    }

}elseif($_GET['act']== 'edit'){
	 $haibaoInfo = C::t('#sgz_base#sgz_base_haibao')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($haibaoInfo);
        C::t('#sgz_base#sgz_base_haibao')->update($_GET['id'],$updateData);
        cpmsg('&#x64CD;&#x4F5C;&#x6210;&#x529F;', $modListUrl, 'succeed');
    }else{

        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype="multipart/form-data" onsubmit="return check()"');
        showtableheader();
        __create_info_html($haibaoInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism��taobao��com*/
    }

}else if($_GET['act'] == 'del'){
    
    C::t('#sgz_base#sgz_base_haibao')->delete_by_id($_GET['id']);
    cpmsg('&#x5220;&#x9664;&#x6210;&#x529F;', $modListUrl, 'succeed');
    
}else{
	
	$page = intval($_GET['page'])>0? intval($_GET['page']):1;
	$pagesize = 20;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#sgz_base#sgz_base_haibao')->fetch_all_count(" ");
    $haibaoList = C::t('#sgz_base#sgz_base_haibao')->fetch_all_list(" ","ORDER BY id desc",$start,$pagesize);
	$modBasePageUrl = $modBaseUrl;
	
	__create_nav_html();
	showtableheader();
    echo '<tr class="header">';
    echo '<th>id</th>';
	echo '<th>&#x6D77;&#x62A5;&#x56FE;</th>';
    echo '<th style="width:250px;">&#x6D3B;&#x52A8;&#x540D;&#x79F0;<br/>(&#x540D;&#x79F0;&#x4E0A;&#x53F3;&#x952E;&#x590D;&#x5236;&#x94FE;&#x63A5;)</th>';
    echo '<th>&#x865A;&#x62DF;&#x53C2;&#x4E0E;&#x4EBA;&#x6570;</th>';
    echo '<th>&#x5B9E;&#x9645;&#x53C2;&#x4E0E;&#x4EBA;&#x6570;</th>';
    echo '<th  style="width:200px;">&#x64CD;&#x4F5C;</th>';
    echo '</tr>';
	foreach ($haibaoList as $key => $value){
		
		echo '<tr>';
        echo '<td>'.$value['id'].'</td>';
		echo '<td><img src="'.newpicurl($value['bg1']).'" width="60"></td>';
        echo '<td style="width:100px;"><a href="'.$_G['siteurl'].'plugin.php?id=sgz_base&mod=qm&aid='.$value['id'].'">'.$value['title'].'</a></td>';
        echo '<td>'.$value['xuni_num'].'</td>';
        echo '<td>'.$value['clicks'].'</td>';
        echo '<td><div class="tc_content_box_handle"><ul>';
		echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'")">&#x7F16;&#x8F91;&nbsp;&nbsp;</a></li>';
		echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'\',\'&#x786E;&#x5B9A;&#x8981;&#x5220;&#x9664;&#xFF1F;\');">|&nbsp;&nbsp;&#x5220;&#x9664;</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
	  
	  }
	showtablefooter(); /*dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
	sgz_deltishi();

	}


function __get_post_data($infoArr = array()){
    global $_G;
	$title				 =   isset($_GET['title'])? addslashes($_GET['title']):'';
	$bg0				 =   isset($_GET['bg0'])? addslashes($_GET['bg0']):'';
	$bg1				 =   isset($_GET['bg1'])? addslashes($_GET['bg1']):'';
	$hb_btn				 =   isset($_GET['hb_btn'])? addslashes($_GET['hb_btn']):'';
	$mp3url				 =   isset($_GET['mp3url'])? addslashes($_GET['mp3url']):'';
	$cydesc				 =   isset($_GET['cydesc'])? addslashes($_GET['cydesc']):'';
	$share_title		 =   isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
	$share_logo			 =   isset($_GET['share_logo'])? addslashes($_GET['share_logo']):'';
	$share_desc			 =   isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
	$bgcolor			 =   isset($_GET['bgcolor'])? addslashes($_GET['bgcolor']):'';
					  
	$xuni_num		  	 =	isset($_GET['xuni_num'])? intval($_GET['xuni_num']):0;
	$user_name_left      =	isset($_GET['user_name_left'])? intval($_GET['user_name_left']):0;
	$user_name_top       =	isset($_GET['user_name_top'])? intval($_GET['user_name_top']):0;
	$riqi_left		     =	isset($_GET['riqi_left'])? intval($_GET['riqi_left']):0;
	$riqitop		     =	isset($_GET['riqitop'])? intval($_GET['riqitop']):0;
	$cydesc_bottom		 =	isset($_GET['cydesc_bottom'])? intval($_GET['cydesc_bottom']):0;



    if($_GET['act'] == 'add'){
        $bg0        = sgz_uploadFile("bg0");
        $bg1        = sgz_uploadFile("bg1");
        $hb_btn     = sgz_uploadFile("hb_btn");
    }else if($_GET['act'] == 'edit'){
		$bg0        = sgz_uploadFile("bg0",$infoArr['bg0']);
        $bg1        = sgz_uploadFile("bg1",$infoArr['bg1']);
        $hb_btn     = sgz_uploadFile("hb_btn",$infoArr['hb_btn']);
    }

	$data = array();
    $data['title']				= $title;
    $data['bg0']				= $bg0;
    $data['bg1']				= $bg1;
    $data['hb_btn']				= $hb_btn;
    $data['mp3url']				= $mp3url;
    $data['cydesc']				= $cydesc;
    $data['share_title']		= $share_title;
    $data['share_logo']			= $share_logo;
    $data['share_desc']			= $share_desc;
    $data['xuni_num']			= $xuni_num;
    $data['user_name_left']		= $user_name_left;
    $data['user_name_top']		= $user_name_top;
    $data['riqi_left']			= $riqi_left;
    $data['riqitop']			= $riqitop;
    $data['cydesc_bottom']		= $cydesc_bottom;

    $data['bgcolor']			= $bgcolor;

    return $data;
}

function __create_info_html($infoArr = array()){
    global $_G;
    $options = array(
		'title'				=>'',
		'bg0'				=>$_G['siteurl'].'source/plugin/sgz_base/template/qianming/static/bg0.jpg',
		'bg1'				=>$_G['siteurl'].'source/plugin/sgz_base/template/qianming/static/bg1.jpg',
		'hb_btn'			=>$_G['siteurl'].'source/plugin/sgz_base/static/img/hbbtn.png',
		'mp3url'			=>'',
		'cydesc'			=>'',
		'share_title'		=>'',
		'share_logo'		=>'',
		'share_desc'		=>'#308ddb',			
		'bgcolor'		=>'',			
		'xuni_num'			=>0,
		'user_name_left'	=>400,
		'user_name_top'		=>1200,
		'riqi_left'			=>450,
		'riqitop'			=>1270,
		'cydesc_bottom'		=>30,

    );
    $options = array_merge($options, $infoArr);

    sgz_create(true,array('title'=>'&#x6D3B;&#x52A8;&#x6807;&#x9898;','name'=>'title','value'=>$options['title'],'msg'=>''),"input");
	sgz_create(false,array('title'=>'&#x6D3B;&#x52A8;&#x9996;&#x9875;&#x5E95;&#x56FE;','name'=>'bg0','value'=>$options['bg0'],'msg'=>'&#x6700;&#x597D;&#x4E0D;&#x8981;&#x8D85;&#x8FC7;1M&#xFF0C;&#x5C3A;&#x5BF8;&#x53EF;&#x81EA;&#x5B9A;&#x4E49;&#xFF0C;&#x5982;800px * 1350px'),"file");
	sgz_create(false,array('title'=>'&#x6D77;&#x62A5;&#x56FE;','name'=>'bg1','value'=>$options['bg1'],'msg'=>'&#x6700;&#x597D;&#x4E0D;&#x8981;&#x8D85;&#x8FC7;1M&#xFF0C;&#x5C3A;&#x5BF8;&#x53EF;&#x81EA;&#x5B9A;&#x4E49;&#xFF0C;&#x5982;750px * 1350px'),"file");
	sgz_create(false,array('title'=>'&#x751F;&#x6210;&#x6D77;&#x62A5;&#x6309;&#x94AE;&#x56FE;','name'=>'hb_btn','value'=>$options['hb_btn'],'msg'=>'&#x9ED8;&#x8BA4;&#x7CFB;&#x7EDF;&#x6309;&#x94AE;'),"file");
	sgz_create(true,array('title'=>'&#x80CC;&#x666F;&#x8272;','name'=>'bgcolor','value'=>$options['bgcolor'],'msg'=>'&#x53EF;&#x4EE5;&#x914D;&#x5408;&#x5E95;&#x56FE;&#x8C03;&#x6574;&#x9875;&#x9762;&#x80CC;&#x666F;&#x989C;&#x8272;&#xFF0C;&#x989C;&#x8272;&#x503C; &#x4EE5; # &#x5F00;&#x5934;&#xFF0C;&#x6BD4;&#x5982;&#xFF1A;#308ddb &#x8FD9;&#x6837;'),"input");
    sgz_create(true,array('title'=>'&#x59D3;&#x540D;&#x8DDD;&#x79BB;&#x6D77;&#x62A5;&#x5DE6;&#x8FB9;&#x8DDD;','name'=>'user_name_left','value'=>$options['user_name_left'],'msg'=>'px&#xFF0C;&#x586B;&#x5199;&#x6574;&#x6570;'),"input");
    sgz_create(true,array('title'=>'&#x59D3;&#x540D;&#x8DDD;&#x79BB;&#x6D77;&#x62A5;&#x4E0A;&#x8FB9;&#x8DDD;','name'=>'user_name_top','value'=>$options['user_name_top'],'msg'=>'px&#xFF0C;&#x586B;&#x5199;&#x6574;&#x6570;'),"input");
    sgz_create(true,array('title'=>'&#x65E5;&#x671F;&#x8DDD;&#x79BB;&#x6D77;&#x62A5;&#x5DE6;&#x8FB9;&#x8DDD;','name'=>'riqi_left','value'=>$options['riqi_left'],'msg'=>'px&#xFF0C;&#x586B;&#x5199;&#x6574;&#x6570;'),"input");
    sgz_create(true,array('title'=>'&#x65E5;&#x671F;&#x8DDD;&#x79BB;&#x6D77;&#x62A5;&#x4E0A;&#x8FB9;&#x8DDD;','name'=>'riqitop','value'=>$options['riqitop'],'msg'=>'px&#xFF0C;&#x586B;&#x5199;&#x6574;&#x6570;'),"input");
	sgz_create(true,array('title'=>'&#x5BA3;&#x8A00;&#x6587;&#x5B57;','name'=>'cydesc','value'=>$options['cydesc'],'msg'=>'&#x5982;&#xFF1A;&#x75AB;&#x60C5;&#x9632;&#x63A7;&#xFF0C;&#x6211;&#x662F;&#x65B0;&#x5BC6;&#x7B2C;<&#x53BB;&#x6389;font color=#ffeb3a>{num}<&#x53BB;&#x6389;/font>&#x4F4D;&#x7B7E;&#x540D;&#x8005;&#xFF01;<br/>&#x8BA9;&#x6211;&#x4EEC;&#x4E00;&#x8D77;&#x4E3A;&#x6B66;&#x6C49;&#x52A0;&#x6CB9;&#xFF01;(#ffeb3a&#x662F;&#x989C;&#x8272;&#x503C;&#xFF0C;{num}&#x662F;&#x7B2C;&#x591A;&#x5C11;&#x4F4D;&#xFF0C;<br/>&#x7528;&#x6765;&#x6362;&#x884C;)'),"input");
   
    sgz_create(true,array('title'=>'&#x5BA3;&#x8A00;&#x6587;&#x5B57;&#x8DDD;&#x79BB;&#x6D77;&#x62A5;&#x4E0B;&#x8FB9;&#x8DDD;','name'=>'cydesc_bottom','value'=>$options['cydesc_bottom'],'msg'=>'px&#xFF0C;&#x586B;&#x5199;&#x6574;&#x6570;'),"input");
	sgz_create(true,array('title'=>'&#x80CC;&#x666F;&#x97F3;&#x4E50;url','name'=>'mp3url','value'=>$options['mp3url'],'msg'=>''),"input");
	sgz_create(true,array('title'=>'&#x6D3B;&#x52A8;&#x5206;&#x4EAB;&#x6807;&#x9898;','name'=>'share_title','value'=>$options['share_title'],'msg'=>'&#x53EF;&#x7528;{num}&#x4EE3;&#x8868;&#x603B;&#x53C2;&#x6570;&#x4EBA;&#x6570;'),"input");
    sgz_create(false,array('title'=>'&#x6D3B;&#x52A8;&#x5206;&#x4EAB;&#x5C01;&#x9762;&#x56FE;','name'=>'share_logo','value'=>$options['share_logo'],'msg'=>''),"file");
    sgz_create(true,array('title'=>'&#x6D3B;&#x52A8;&#x5206;&#x4EAB;&#x63CF;&#x8FF0;','name'=>'share_desc','value'=>$options['share_desc'],'msg'=>'&#x53EF;&#x7528;{num}&#x4EE3;&#x8868;&#x603B;&#x53C2;&#x6570;&#x4EBA;&#x6570;'),"input");
	sgz_create(true,array('title'=>'&#x865A;&#x62DF;&#x53C2;&#x4E0E;&#x4EBA;&#x6570;','name'=>'xuni_num','value'=>$options['xuni_num'],'msg'=>''),"input");
	sgz_check();

    return;
}


function __create_nav_html($infoArr = array()){
    global $modBaseUrl,$adminBaseUrl;
    sgz_shownavheader();
    if($_GET['act'] == 'add'){
        sgz_shownavli('&#x6D3B;&#x52A8;&#x5217;&#x8868;',$modBaseUrl,false);
        sgz_shownavli('&#x6DFB;&#x52A0;&#x6D77;&#x62A5;&#x6D3B;&#x52A8;',"",true);
    }else if($_GET['act'] == 'edit'){
        sgz_shownavli('&#x6D3B;&#x52A8;&#x5217;&#x8868;',$modBaseUrl,false);
        sgz_shownavli('&#x7F16;&#x8F91;',"",true);
    }else{
        sgz_shownavli('&#x6D3B;&#x52A8;&#x5217;&#x8868;',$modBaseUrl,true);
        sgz_shownavli('&#x6DFB;&#x52A0;&#x6D77;&#x62A5;&#x6D3B;&#x52A8;',$modBaseUrl."&act=add",false);
    }
    sgz_shownavfooter();
}