<?php
/**
 *	[����ϵͳ(zgxsh_wco.install)] (C)2019-2099 Powered by DisM!Ӧ������.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_wco_ocl`;
CREATE TABLE `cdb_zgxsh_wco_ocl` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(20) default NULL,
  `color` varchar(30) default NULL,
  `fee` int(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_wco_order`;
CREATE TABLE `cdb_zgxsh_wco_order` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) default NULL,
  `class` int(20) default NULL,
  `txt` varchar(1500) default NULL,
  `img` varchar(500) default NULL,
  `atta_class` int(1) NOT NULL,
  `atta` varchar(255) NOT NULL,
  `atta_extr` varchar(10) NOT NULL,
  `state` int(1) default '0',
  `ext_v` int(20) default NULL,
  `time` int(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `in_uid` (`uid`,`class`,`state`,`time`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_wco_qa`;
CREATE TABLE `cdb_zgxsh_wco_qa` (
  `id` int(10) NOT NULL auto_increment,
  `oid` int(20) default NULL,
  `a_uid` int(20) default NULL,
  `txt` varchar(1500) default NULL,
  `img` varchar(500) default NULL,
  `atta_class` int(1) NOT NULL,
  `atta` varchar(255) NOT NULL,
  `atta_extr` varchar(10) NOT NULL,
  `time` int(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `in_oid` (`oid`,`a_uid`,`time`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_wco_user`;
CREATE TABLE `cdb_zgxsh_wco_user` (
  `uid` int(20) NOT NULL,
  `email` varchar(30) default NULL,
  `qq` varchar(30) default NULL,
  `phone` varchar(12) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = true;
?>