<?php
/**
 *	[����ϵͳ(zgxsh_wco.uninstall)] (C)2019-2099 Powered by DisM!Ӧ������.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//���µ�ͼ����
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_order')." LIKE 'atta_class'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_order')." ADD atta_class int(1) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_order')." LIKE 'atta'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_order')." ADD atta varchar(255) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_order')." LIKE 'atta_extr'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_order')." ADD atta_extr varchar(10) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_qa')." LIKE 'atta_class'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_qa')." ADD atta_class int(1) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_qa')." LIKE 'atta'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_qa')." ADD atta varchar(255) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_wco_qa')." LIKE 'atta_extr'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_wco_qa')." ADD atta_extr varchar(10) NOT NULL");
}

$finish = true;
?>