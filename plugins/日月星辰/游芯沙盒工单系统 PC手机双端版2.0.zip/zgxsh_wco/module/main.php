<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

if(!$_G['uid']){
  header( "Location:member.php?mod=logging&action=login" );
  exit();
}
//----ϵͳ��������----
$_TRC = $_G['cache']['plugin']['zgxsh_wco'];
$_TRC['f_admin'] = explode('|',$_TRC['f_admin']);
$_TRC['f_admin_true'] = in_array($_G['uid'],$_TRC['f_admin']);

//----��������----
$_TRC["sys_ext_name"] = $_G['setting']['extcredits'][$_TRC['sys_ext']]['title'];
$_TRC["sys_ext_logo"] = $_G['setting']['extcredits'][$_TRC['sys_ext']]['img'];
$_TRC["sys_ext_unit"] = $_G['setting']['extcredits'][$_TRC['sys_ext']]['unit'];
$_TRC["sys_ext_value"] = getuserprofile('extcredits'.$_TRC['sys_ext']);

//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC['p_name'];

//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';

//----�������----
//����������ʾ
function on_see($admin=1){
  
global $_TRC,$_G;
  
  if($admin){
    $where = " AND uid='".$_G['uid']."'";
  }else{
    $where = " AND uid!='".$_G['uid']."'";
  }
    
  $on_see[1]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='0'".$where);
  $on_see[2]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='1'".$where);
  $on_see[3]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='2'".$where);
  $on_see[4]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='3'".$where);
  $on_see[5]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='4'".$where);
  $on_see[6]['count'] = DB::result_first('SELECT COUNT(id) FROM '.DB::table('zgxsh_wco_order')." WHERE state='5'".$where);
  
  if($on_see[1]['count']>$_TRC['warning_lv2']){
    $on_see[1]['color'] = "color:#f90";
  }elseif($on_see[1]['count']>$_TRC['warning_lv1']){
    $on_see[1]['color'] = "color:#f10";
  }else{
    $on_see[1]['color'] = "";
  }
  if($on_see[2]['count']>$_TRC['warning_lv2']){
    $on_see[2]['color'] = "color:#f90";
  }elseif($on_see[2]['count']>$_TRC['warning_lv1']){
    $on_see[2]['color'] = "color:#f10";
  }else{
    $on_see[2]['color'] = "";
  }
  if($on_see[3]['count']>$_TRC['warning_lv2']){
    $on_see[3]['color'] = "color:#f90";
  }elseif($on_see[3]['count']>$_TRC['warning_lv1']){
    $on_see[3]['color'] = "color:#f10";
  }else{
    $on_see[2]['color'] = "";
  }
  
  return $on_see;
}
//������Ȩ
function admin_true(){
  global $_G,$_TRC;
  if($_TRC['f_admin_true'] or $_G['adminid']==1){
    return true;
  }
  $paramete['icon'] = 3;
  prompt(co('inde44'),"location='plugin.php?id=zgxsh_wco:index'",$paramete);
}

//��� ��ֵ intval() ���� daddslashes()
class order{
  
  function state_edit($id,$state){
    DB::update('zgxsh_wco_order',array('state'=>$state),array('id'=>$id));
    return true;
  }
  
}
//From: Dism_taobao-com
?>