<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';


if($_GET['op']=="ro_add"){  //��������
	$ls = security::filter( $_GET );
  
  //----�û���Ȩ----
  $db_user = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$_G['uid']."'");
  if(!$db_user or (!$db_user['email'] and !$db_user['qq'] and !$db_user['phone'])){  //û���û�������ת���û�����ҳ��
    header( "Location:plugin.php?id=zgxsh_wco:index_if&op=user" );
    exit();
  }
  
  $db_or = DB::fetch_all('SELECT * FROM '.DB::table('zgxsh_wco_ocl'));
  include template('zgxsh_wco:ro/ro_add');
  exit();
}
elseif($_GET['op']=="ro_add_sub"){  //��������
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  security::txt_en($ls['txt'],co('inde09').$ls['txt'],$_TRC['min_txt'],1400);

  $db_orcl = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_ocl')." WHERE id='".$ls['class']."'");
  if($db_orcl['fee']>0){
    integral($_G['uid'],-$db_orcl['fee'],$_TRC['sys_ext'],$_TRC['p_name'],co('inde10'));
    $db_orcl['fee'] = -$db_orcl['fee'];
  }else{
    $db_orcl['fee'] = 0;
  }
  
  $in = array(
    'uid' => $_G['uid'],
    'class' => intval($ls['class']),
    'txt' => $ls['txt'],
    'img' => $ls['img'],
    'ext_v' => $db_orcl['fee'],
    'time' => time(),
  );
  
  //�����ϴ�
  if($_TRC['atta_radio']){  //�����ϴ�
    if($_TRC['atta_class']==1){  //1�ϴ� 2����
      $in['atta_class'] = 1;
      $in['atta'] = $ls['atta'];
      $in['atta_extr'] = '';
    }else{
      $in['atta_class'] = 2;
      $in['atta'] = $ls['atta_url'];
      $in['atta_extr'] = $ls['atta_extr'];
    }
  }
    
  DB::insert('zgxsh_wco_order',$in);
  
  prompt(co('inde21'),"location='plugin.php?id=zgxsh_wco:index'");
}


//��������
elseif($_GET['op']=="ro_see"){  //�鿴��������
	$ls = security::filter( $_GET );

  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['bh']."'");
  
  $db_order['class_s'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_ocl')." WHERE id='".$db_order['class']."'");
  if(!$db_order['class_s']){
    $db_order['class_s']['name'] = co('inde01');
    $db_order['class_s']['color'] = "rgba(0,0,0,1)";
  }
  if($db_order['state']==0){
    $db_order['state_name'] = "<spna style='color:#ff0000'>".co('inde02')."</spna>";
  }elseif($db_order['state']==1){
    $db_order['state_name'] = "<spna style='color:#0f0'>".co('inde03')."</spna>";
  }elseif($db_order['state']==2){
    $db_order['state_name'] = "<spna style='color:#00f'>".co('inde04')."</spna>";
  }elseif($db_order['state']==3){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde05')."</spna>";
  }elseif($db_order['state']==4){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde06')."</spna>";
  }elseif($db_order['state']==5){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde07')."</spna>";
  }
  if($db_order['ext_v']==0){
    $db_order['fee'] = "<b style='color:#bbbbbb'>".co('inde08')."</b>";
  }elseif($db_order['ext_v']>0){
    $db_order['fee'] = "<b style='color:#00b259'>".$db_order['ext_v']."</b>";
  }else{
    $db_order['fee'] = "<b style='color:#ff4400'>".$db_order['ext_v']."</b>";
  }
  $db_order['date'] = dgmdate($db_order['time'],'u');
  $db_order['username'] = q_name($db_order['uid']);
  $db_order['user'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$db_order['uid']."'");
  
  //��ȡ�ʴ�
  $db_qa = DB::fetch_all('SELECT * FROM '.DB::table('zgxsh_wco_qa')." WHERE oid='".$db_order['id']."' ORDER BY time ASC");

  for($i=0;$i<count($db_qa);$i++){
    $db_qa[$i]['username'] = q_name($db_qa[$i]['a_uid']);
    $db_qa[$i]['date'] = dgmdate($db_qa[$i]['time'],'u');
  }
  
  include template('zgxsh_wco:ro/ro_see');
  exit();
}
elseif($_GET['op']=="ro_ask_sub"){  //׷��
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  security::txt_en($ls['txt'],co('inde11'),$_TRC['min_txt'],1400);
  
  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['oid']."'");
  if($db_order['uid']!=$_G['uid']){
    prompt(co('inde12'));
  }
  
  $in = array(
    'a_uid' => $_G['uid'],
    'oid' => intval($ls['oid']),
    'txt' => $ls['txt'],
    'img' => $ls['img'],
    'time' => time(),
  );
  
  //�����ϴ�
  if($_TRC['atta_radio']){  //�����ϴ�
    if($_TRC['atta_class']==1){  //1�ϴ� 2����
      $in['atta_class'] = 1;
      $in['atta'] = $ls['atta'];
      $in['atta_extr'] = '';
    }else{
      $in['atta_class'] = 2;
      $in['atta'] = $ls['atta_url'];
      $in['atta_extr'] = $ls['atta_extr'];
    }
  }
      
  DB::insert('zgxsh_wco_qa',$in);
  
  order::state_edit($ls['oid'],1);
  
  prompt(co('inde13'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_see&bh=".$ls['oid']."'");
}
elseif($_GET['op']=="ro_reply"){  //��������̨
  
  admin_true();  //������Ȩ
  
  if($_G['uid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    $icon = '<p style="margin: 10px"><i class="layui-icon" style="color: #fb0;font-size: 40px;">&#xe664;</i></p>';
    $prompt = co('inde14');
    $prompt .= "<br><a href='plugin.php?id=zgxsh_wco:index' style='color:#00f'>".co('inde15')."</a>";
    include template('zgxsh_wco:prompt/on_admin'); 
    exit();
  }
  
  $db_order = DB::fetch_all('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE uid!='".$_G['uid']."' AND (state='0' OR state='1' OR state='2') ORDER BY time DESC");

  for($i=0;$i<count($db_order);$i++){
    $db_order[$i]['class_s'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_ocl')." WHERE id='".$db_order[$i]['class']."'");
    if(!$db_order[$i]['class_s']){
      $db_order[$i]['class_s']['name'] = co('inde01');
      $db_order[$i]['class_s']['color'] = "rgba(0,0,0,1)";
    }
    if($db_order[$i]['state']==0){
      $db_order[$i]['state_name'] = "<spna style='color:#ff0000'>".co('inde16')."</spna>";
    }elseif($db_order[$i]['state']==1){
      $db_order[$i]['state_name'] = "<spna style='color:#0f0'>".co('inde02')."</spna>";
    }elseif($db_order[$i]['state']==2){
      $db_order[$i]['state_name'] = "<spna style='color:#00f'>".co('inde04')."</spna>";
    }elseif($db_order[$i]['state']==3){
      $db_order[$i]['state_name'] = "<spna style='color:#bbbbbb'>".co('inde05')."</spna>";
    }elseif($db_order[$i]['state']==4){
      $db_order[$i]['state_name'] = "<spna style='color:#bbbbbb'>".co('inde06')."</spna>";
    }elseif($db_order[$i]['state']==5){
      $db_order[$i]['state_name'] = "<spna style='color:#bbbbbb'>".co('inde07')."</spna>";
    }
    if($db_order[$i]['ext_v']==0){
      $db_order[$i]['fee'] = "<b style='color:#bbbbbb'>".co('inde08')."</b>";
    }elseif($db_order[$i]['ext_v']>0){
      $db_order[$i]['fee'] = "<b style='color:#00b259'>".$db_order[$i]['ext_v']."</b>";
    }else{
      $db_order[$i]['fee'] = "<b style='color:#ff4400'>".$db_order[$i]['ext_v']."</b>";
    }
    $db_order[$i]['date'] = dgmdate($db_order[$i]['time']);
  }

  $on_see = on_see(0);
  
  include template('zgxsh_wco:reply/reply'); 
  exit();
}
elseif($_GET['op']=="ro_reply_see"){  //��������
  
  admin_true();  //������Ȩ
  
	$ls = security::filter( $_GET );
  
  if($_G['uid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    $icon = '<p style="margin: 10px"><i class="layui-icon" style="color: #fb0;font-size: 40px;">&#xe664;</i></p>';
    $prompt = co('inde14');
    $prompt .= "<br><a href='plugin.php?id=zgxsh_wco:index' style='color:#00f'>".co('inde15')."</a>";
    include template('zgxsh_wco:prompt/on_admin'); 
    exit();
  }

  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['bh']."'");
  
  $db_order['class_s'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_ocl')." WHERE id='".$db_order['class']."'");
  if(!$db_order['class_s']){
    $db_order['class_s']['name'] = co('inde01');
    $db_order['class_s']['color'] = "rgba(0,0,0,1)";
  }
  if($db_order['state']==0){
    $db_order['state_name'] = "<spna style='color:#ff0000'>".co('inde02')."</spna>";
  }elseif($db_order['state']==1){
    $db_order['state_name'] = "<spna style='color:#0f0'>".co('inde03')."</spna>";
  }elseif($db_order['state']==2){
    $db_order['state_name'] = "<spna style='color:#00f'>".co('inde04')."</spna>";
  }elseif($db_order['state']==3){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde05')."</spna>";
  }elseif($db_order['state']==4){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde06')."</spna>";
  }elseif($db_order['state']==5){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde07')."</spna>";
  }
  if($db_order['ext_v']==0){
    $db_order['fee'] = "<b style='color:#bbbbbb'>".co('inde08')."</b>";
  }elseif($db_order['ext_v']>0){
    $db_order['fee'] = "<b style='color:#00b259'>".$db_order['ext_v']."</b>";
  }else{
    $db_order['fee'] = "<b style='color:#ff4400'>".$db_order['ext_v']."</b>";
  }
  $db_order['date'] = dgmdate($db_order['time'],'u');
  $db_order['username'] = q_name($db_order['uid']);
  $db_order['user'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$db_order['uid']."'");
  
  //��ȡ�ʴ�
  $db_qa = DB::fetch_all('SELECT * FROM '.DB::table('zgxsh_wco_qa')." WHERE oid='".$db_order['id']."' ORDER BY time ASC");

  for($i=0;$i<count($db_qa);$i++){
    $db_qa[$i]['username'] = q_name($db_qa[$i]['a_uid']);
    $db_qa[$i]['date'] = dgmdate($db_qa[$i]['time'],'u');
  }
  
  //�����ᵥ
  if($db_qa[count($db_qa)-1]['uid']<>$db_order['uid'] and count($db_qa)>0){  //�����ظ���ͻ�û�лظ�
    if($db_qa[count($db_qa)-1]['time']<(time()-$_TRC['over_time'])){
      $over = true;
    }
  }

  
  include template('zgxsh_wco:reply/ro_reply_see');
  exit();
}
elseif($_GET['op']=="ro_rep_sub"){  //��
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  security::txt_en($ls['txt'],co('inde17'),$_TRC['min_txt'],1400);
  
  if($_G['uid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    $icon = '<p style="margin: 10px"><i class="layui-icon" style="color: #fb0;font-size: 40px;">&#xe664;</i></p>';
    $prompt = co('inde14');
    $prompt .= "<br><a href='plugin.php?id=zgxsh_wco:index' style='color:#00f'>".co('inde15')."</a>";
    include template('zgxsh_wco:prompt/on_admin'); 
    exit();
  }
  
  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['oid']."'");
  if($db_order['uid']==$_G['uid']){
    prompt(co('inde18'));
  }
  
  $in = array(
    'a_uid' => $_G['uid'],
    'oid' => intval($ls['oid']),
    'txt' => $ls['txt'],
    'img' => $ls['img'],
    'time' => time(),
  );
  
  //�����ϴ�
  if($_TRC['atta_radio']){  //�����ϴ�
    if($_TRC['atta_class']==1){  //1�ϴ� 2����
      $in['atta_class'] = 1;
      $in['atta'] = $ls['atta'];
      $in['atta_extr'] = '';
    }else{
      $in['atta_class'] = 2;
      $in['atta'] = $ls['atta_url'];
      $in['atta_extr'] = $ls['atta_extr'];
    }
  }
      
  DB::insert('zgxsh_wco_qa',$in);
  
  order::state_edit($ls['oid'],2);
  
  prompt(co('inde19'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_reply_see&bh=".$ls['oid']."'");
}
elseif($_GET['op']=="ro_over"){  //�ᵥ����
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['bh']."'");
  
  $db_order['class_s'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_ocl')." WHERE id='".$db_order['class']."'");
  if(!$db_order['class_s']){
    $db_order['class_s']['name'] = co('inde01');
    $db_order['class_s']['color'] = "rgba(0,0,0,1)";
  }
  if($db_order['state']==0){
    $db_order['state_name'] = "<spna style='color:#ff0000'>".co('inde02')."</spna>";
  }elseif($db_order['state']==1){
    $db_order['state_name'] = "<spna style='color:#0f0'>".co('inde03')."</spna>";
  }elseif($db_order['state']==2){
    $db_order['state_name'] = "<spna style='color:#00f'>".co('inde04')."</spna>";
  }elseif($db_order['state']==3){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde05')."</spna>";
  }elseif($db_order['state']==4){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde06')."</spna>";
  }elseif($db_order['state']==5){
    $db_order['state_name'] = "<spna style='color:#bbbbbb'>".co('inde07')."</spna>";
  }
  if($db_order['ext_v']==0){
    $db_order['fee'] = "<b style='color:#bbbbbb'>".co('inde08')."</b>";
  }elseif($db_order['ext_v']>0){
    $db_order['fee'] = "<b style='color:#00b259'>".$db_order['ext_v']."</b>";
  }else{
    $db_order['fee'] = "<b style='color:#ff4400'>".$db_order['ext_v']."</b>";
  }
  $db_order['date'] = dgmdate($db_order['time'],'u');
  $db_order['username'] = q_name($db_order['uid']);
  $db_order['user'] = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$db_order['uid']."'");
  
  include template('zgxsh_wco:reply/ro_over');
  exit();
}
elseif($_GET['op']=="ro_over_sub"){  //�����ᵥ
  
  admin_true();  //������Ȩ
  
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  
  if($_G['uid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    $icon = '<p style="margin: 10px"><i class="layui-icon" style="color: #fb0;font-size: 40px;">&#xe664;</i></p>';
    $prompt = co('inde14');
    $prompt .= "<br><a href='plugin.php?id=zgxsh_wco:index' style='color:#00f'>".co('inde15')."</a>";
    include template('zgxsh_wco:prompt/on_admin'); 
    exit();
  }
  
  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['oid']."'");
  if($db_order['uid']==$_G['uid']){
    prompt(co('inde18'));
  }
  
  if($ls['over_v']==1){
    $over_txt = co('inde20');
  }elseif($ls['over_v']==2){
    $over_txt = co('inde22');
  }elseif($ls['over_v']==2){
    $over_txt = co('inde23');
  }else{
    $over_txt = co('inde24');
  }
  
  if($ls['txt']){
    $ls['txt'] = $over_txt.co('inde25').$ls['txt'];
  }else{
    $ls['txt'] = $over_txt;
  }
  
  $in = array(
    'a_uid' => $_G['uid'],
    'oid' => intval($ls['oid']),
    'txt' => $ls['txt'],
    'img' => $ls['img'],
    'time' => time(),
  );
      
  DB::insert('zgxsh_wco_qa',$in);
  
  //�ж�����
  if($db_order['ext_v']==0){
    $ext_v = 3;
  }elseif($db_order['ext_v']>0){
    $ext_v = 4;
  }elseif($db_order['ext_v']<0){
    $ext_v = 5;
  }
  order::state_edit($ls['oid'],$ext_v);
  
  prompt(co('inde26'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_reply'");
}
elseif($_GET['op']=="ro_over_user"){  //�ͻ��ᵥ
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
    
  $db_order = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_order')." WHERE id='".$ls['bh']."'");
  if($db_order['uid']!=$_G['uid']){
    prompt(co('inde27'));
  }
  
  $ls['txt'] = co('inde28');
    
  $in = array(
    'a_uid' => $_G['uid'],
    'oid' => intval($ls['bh']),
    'txt' => $ls['txt'],
    'img' => $ls['img'],
    'time' => time(),
  );
      
  DB::insert('zgxsh_wco_qa',$in);
  
  //�ж�����
  if($db_order['ext_v']==0){
    $ext_v = 3;
  }elseif($db_order['ext_v']>0){
    $ext_v = 4;
  }elseif($db_order['ext_v']<0){
    $ext_v = 5;
  }
  order::state_edit($ls['bh'],$ext_v);
  
  prompt(co('inde26'),"location='plugin.php?id=zgxsh_wco:index'");
}


//�û�ϵͳ
elseif($_GET['op']=="user"){
	$ls = security::filter( $_GET );
  
  $db_user = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$_G['uid']."'");
  
  include template('zgxsh_wco:user/user');
  exit();
}
elseif($_GET['op']=="user_sub"){
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  
  if(!$ls['email'] and !$ls['qq'] and !$ls['phone']){
    prompt(co('inde29'));
  }
  if($ls['email']){
    security::txt_email($ls['email'],co('inde30'));
  }
  if($ls['phone']){
    if(!security::phone_if_r($ls['phone'])){
      prompt(co('inde31'));
    }
  }
  
  $in = array(
    'email' => $ls['email'],
    'qq' => $ls['qq'],
    'phone' => $ls['phone'],
  );
  
  $db_user = DB::fetch_first('SELECT * FROM '.DB::table('zgxsh_wco_user')." WHERE uid='".$_G['uid']."'");
  if(!$db_user){  //û���û�������ת���û�����ҳ��
    $in['uid'] = $_G['uid'];
    DB::insert('zgxsh_wco_user',$in);
  }else{
    DB::update('zgxsh_wco_user',$in,array('uid'=>$_G['uid']));
  }
  
  prompt(co('inde32'),"location='plugin.php?id=zgxsh_wco:index_if&op=user'");
}

//������������
elseif($_GET['op']=="ro_setup"){  //������������
  
  admin_true();  //������Ȩ
  
	$ls = security::filter( $_GET );
  
  $db_or = DB::fetch_all('SELECT * FROM '.DB::table('zgxsh_wco_ocl'));
  
  include template('zgxsh_wco:ro/ro_setup');
  exit();
}
elseif($_GET['op']=="ro_class_add_sub"){  //���ӹ�������
  
  admin_true();  //������Ȩ
  
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  security::txt_en($ls['name'],co('inde33'),2,20);
  security::int_if($ls['fee'],co('inde34'),0,1);
  security::txt_en($ls['color'],co('inde35'));
  
  $in = array(
    'name' => $ls['name'],
    'color' => $ls['color'],
    'fee' => $ls['fee'],
  );
  DB::insert('zgxsh_wco_ocl',$in);
  
  prompt(co('inde37'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_setup'");
}
elseif($_GET['op']=="ro_class_edit_sub"){  //�޸Ĺ�������
  
  admin_true();  //������Ȩ
  
  security::hash_if(); //formhash
	$ls = security::filter( $_GET );
  security::txt_en($ls['name'],co('inde33'),2,20);
  security::int_if($ls['fee'],co('inde34'),0,1);
  security::txt_en($ls['color'],co('inde35'));
  security::int_if($ls['bh'],co('inde36'));
  
  $up = array(
    'name' => $ls['name'],
    'color' => $ls['color'],
    'fee' => $ls['fee'],
  );
  DB::update('zgxsh_wco_ocl',$up,array('id'=>$ls['bh']));
      
  prompt(co('inde38'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_setup'");
}
elseif($_GET['op']=="ro_class_del_sub"){  //ɾ����������
  
  admin_true();  //������Ȩ
  
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  security::int_if($ls['bh'],co('inde36'));
  
  DB::delete('zgxsh_wco_ocl',array('id'=>$ls['bh']));
      
  prompt(co('inde39'),"location='plugin.php?id=zgxsh_wco:index_if&op=ro_setup'");
}

//�����������
elseif($_GET['op']=="admin_assess"){
  
  admin_true();  //������Ȩ
  
  if(!$_TRC['admin_assess']){
    $paramete['icon']=2;  //��ʾͼ��
    $setup_url = '<a style="color:#229" target="_blank">'.co('inde40').'</a>';
    prompt(co('inde41').'<br>'.$setup_url,"location='plugin.php?id=zgxsh_wco:index'",$paramete);
  }
}

//�ߵ���չ ro_rush
elseif($_GET['op']=="ro_rush"){
  if(!$_TRC['ro_rush']){
    $paramete['icon']=2;  //��ʾͼ��
    $setup_url = '<a style="color:#229" target="_blank">'.co('inde40').'</a>';
    prompt(co('inde42').'<br>'.$setup_url,"location='plugin.php?id=zgxsh_wco:index'",$paramete);
  }
}

//������չ ro_reward
elseif($_GET['op']=="ro_reward"){
  
  admin_true();  //������Ȩ
  
  if(!$_TRC['ro_reward']){
    $paramete['icon']=2;  //��ʾͼ��
    $setup_url = '<a style="color:#229" target="_blank">'.co('inde40').'</a>';
    prompt(co('inde43').'<br>'.$setup_url,"location='plugin.php?id=zgxsh_wco:index_if&op=ro_reply'",$paramete);
  }
}

system_end();
?>