<?php
//cronname:cron_clean
//week:6
//day:
//hour:12
//minute:

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function co_cron($txt,$arr=""){  //语言包缩短函数
	global $_G;
	global $_GET;
  $a = lang('plugin/zgxsh_clean',$txt,$arr);
  return $a;
}

include 'source/plugin/zgxsh_clean/module/class/system.php';
global $_G;
loadcache('plugin');



?>