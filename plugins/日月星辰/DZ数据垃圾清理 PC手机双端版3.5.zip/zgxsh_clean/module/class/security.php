<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){exit('Access Denied');}
//本类组件需要 system 组件支持 本组件由西安日月星辰软件开发 使用者请尊重开发人员 保留此信息 , 百度搜索游芯沙盒可更新本工具
/* 语言包设置
'namefalse' => 'name参数为空',
'hash_if' => '非法提交,请您验证请求来源!',
'int_pro_0' => '数值不能为空!',
'int_pro_1' => '数值不能为0!如果是选项则为必选!',
'int_pro_2' => '数值不能为小数!',
'int_pro_3' => '数值不能为负数!',
'int_pro_4' => '不是合法数字!',
'int_pro_5' => '不能小于',
'int_pro_6' => '不能大于',
'txt_pro_1' => '不是合法中文汉字!',
'txt_pro_2' => '不能为空',
'txt_pro_3' => '字数不能小于',
'txt_pro_4' => '字数不能大于',
'txt_pro_5' => '每个中文字符占',
'txt_pro_6' => '长度',
'ema_pro_1' => '填写格式不正确!',
'dmsc01' => '免费定制,售后服务,请加群!!! <br> QQ群:976232044 <br> 请注意 , 客服按钮有时效 , 超过1小时我无法主动回复您的咨询 , 所以可以加群咨询相关事宜 , 另外 , 群里偶尔会发放优惠劵 , 或者红包',
'dmsc02' => '温馨提示',
*/

class security {
  
  function onClick_v(){
    global $_G,$onClick_v;
    if($onClick_v==""){
      if($_G['mobile']==false){
        $onClick_v = "window.location.reload(true);";
      }else{
        $onClick_v = "location=document.referrer";
      }
    }
    return $onClick_v;
  }
	
	function hash_if($get=0){  //get=1开启GET formhash 判断
    global $_GET;
    if($get){
      if($_GET['formhash'] != formhash()){
        prompt(co('hash_if'),self::onClick_v(),array('icon'=>2));
      }
    }else{
      if(!submitcheck('formhash',$get)){
        prompt(co('hash_if'),self::onClick_v(),array('icon'=>2));
      }
    }   
		return true;
  }
	function filter($GB,$dk=0){  //安全过滤 $dk 数字键名数组
    foreach ($GB as $k=>$v){
      if(is_array($v)){
			  $r[$k] = self::filter($v);
		  }else{
        if(in_array($k,$dk)){
          $r[$k] = intval(dhtmlspecialchars($v));
        }else{
          $r[$k] = daddslashes(dhtmlspecialchars($v));
        }
		  }
    }
    return $r;
  }

  //数字判定 : 值 中文名称 是否跳过合法数字检查 能否可为零 能否可为负 能否可为小数 最小值 最大值
  function int_if($v,$name,$intturn=false,$zero=false,$negative=false,$decimal=false,$min=false,$max=false){ 
    global $_G;

    if(!$name){  //将这些写入一个设置项目编号为99
			prompt(co('namefalse'),self::onClick_v(),array('icon'=>2));
    }
		
		if($v === NULL or $v === ""){
			prompt($name.co('int_pro_0'),self::onClick_v(),array('icon'=>2));
    }
		if(!$intturn and !is_numeric($v)) {  //不是数字为真
			prompt($name.co('int_pro_4'),self::onClick_v(),array('icon'=>2));
    }
    if(!$zero and $v == 0){
			prompt($name.co('int_pro_1'),self::onClick_v(),array('icon'=>2));
    }
    if(!$negative and $v+0<0){
			prompt($name.co('int_pro_3'),self::onClick_v(),array('icon'=>2));
    }
		if(!$decimal and strpos($v,'.')){
			prompt($name.co('int_pro_2'),self::onClick_v(),array('icon'=>2));
    }
		
		if($min !== false and $v+0<$min) {
			prompt($name.co('int_pro_5').$min,self::onClick_v(),array('icon'=>2));
    }
    if($max !== false and $v+0>$max) {
			prompt($name.co('int_pro_6').$max,self::onClick_v(),array('icon'=>2));
    }
		
    return true;
  }
	//中文字符串判定 : 值 中文名称 纯中文判定 最短 最长 (长度为汉字长度程序会根据编码自动判定字节长度)
  function txt_ch($v,$name,$ch=false,$min=false,$max=false){
    global $_G;
		
    $cl = CHARSET=='utf-8'?3:2;  //判定编码字数

    if(!$name){
			prompt(co('namefalse'),self::onClick_v(),array('icon'=>2));
    }
    
    $v = diconv($v,CHARSET,'utf-8');  //如果是其他编码则转换为UTF-8
    if(preg_match('/^[\x{4e00}-\x{9fa5}]+$/u',$v)<=0 and $ch!=false and strlen($v)>0){
			prompt($name.co('txt_pro_1'),self::onClick_v(),array('icon'=>2));
    }
		
		if($min>0 and !strlen($v) and $min!==false){  //如果min设置为0则可以为空
			prompt($name.co('txt_pro_2'),self::onClick_v(),array('icon'=>2));
    }
    
    if(strlen($v)<$min*$cl and $min!==false){
			prompt($name.co('txt_pro_3').$min,self::onClick_v(),array('icon'=>2));
    }
    
    if(strlen($v)>$max*$cl and $max!==false){
			prompt($name.co('txt_pro_4').$max,self::onClick_v(),array('icon'=>2));
    }
  }
	//混合字符串判定 : 值 中文名称 最短 最长
  function txt_en($v,$name,$min=false,$max=false){
    global $_G;
    
		$cl = CHARSET=='utf-8'?3:2;  //判定编码字数
		
    if(!$name){
			prompt(co('namefalse'),self::onClick_v(),array('icon'=>2));
    }
    
		if(!strlen($v) and $min===false){  //如果min设置为0则可以为空
			prompt($name.co('txt_pro_2'),self::onClick_v(),array('icon'=>2));
    }
    
    if(strlen($v)<$min and $min!==false){
			prompt($name.co('txt_pro_3').$min.co('txt_pro_5').$cl.co('txt_pro_6'),self::onClick_v(),array('icon'=>2));
    }
    
    if(strlen($v)>=$max and $max!==false){
			prompt($name.co('txt_pro_4').$max.co('txt_pro_5').$cl.co('txt_pro_6'),self::onClick_v(),array('icon'=>2));
    }
  }
	//邮箱验证 : 此判定前可以先那字符串函数规定长短避免邮箱名称填写过长
  function txt_email($v,$name){
    global $_G;

    if(!$name){
      prompt(co('namefalse'),self::onClick_v(),array('icon'=>2));
    }
    
    $r = strlen($v) > 6 && preg_match("/^([A-Za-z0-9\-_.+]+)@([A-Za-z0-9\-]+[.][A-Za-z0-9\-.]+)$/",$v);
    
    if(!$r){
			prompt($name.co('ema_pro_1'),self::onClick_v(),array('icon'=>2));
    }
        
    return true;
  }
  
  
  //身份证验证
  function is_idcard( $id ) {
    $id = strtoupper( $id );
    $id = trim($id);
    $regx = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/";
    $arr_split = array();
    if ( !preg_match( $regx, $id ) ) {
      return FALSE;
    }
    if ( 15 == strlen( $id ) ) //检查15位
    {
      $regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/";

      @preg_match( $regx, $id, $arr_split );
      //检查生日日期是否正确
      $dtm_birth = "19" . $arr_split[ 2 ] . '/' . $arr_split[ 3 ] . '/' . $arr_split[ 4 ];
      if ( !strtotime( $dtm_birth ) ) {
        return FALSE;
      } else {
        return TRUE;
      }
    } else //检查18位
    {
      $regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/";
      @preg_match( $regx, $id, $arr_split );
      $dtm_birth = $arr_split[ 2 ] . '/' . $arr_split[ 3 ] . '/' . $arr_split[ 4 ];
      if ( !strtotime( $dtm_birth ) ) //检查生日日期是否正确
      {
        return FALSE;
      } else {
        //检验18位身份证的校验码是否正确。
        //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
        $arr_int = array( 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 );
        $arr_ch = array( '1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2' );
        $sign = 0;
        for ( $i = 0; $i < 17; $i++ ) {
          $b = ( int )$id {
            $i
          };
          $w = $arr_int[ $i ];
          $sign += $b * $w;
          //echo "<br>余数".$sign."<br>";
        }
        $n = $sign % 11;
        
        $val_num = $arr_ch[ $n ];
        if ( $val_num != substr( $id, 17, 1 ) ) {
          return FALSE;
        } //phpfensi.com
        else {
          return TRUE;
        }
      }
    }
  }
  
  //手机号码验证 
  function phone_if_r($v){ 

    if(strlen($v)!=11 or $v[0]!=1){  //不是11位 或者第一位不=1
      return false;
    }
	
    return true;
  }

  function in_arr($var,$arr=array(),$txt){
    if(!in_array($var,$arr)){
      prompt($txt,"hideWindow('TS');",array('icon'=>2));
    }
    return;
  }
}
include 'extension.php';
?>