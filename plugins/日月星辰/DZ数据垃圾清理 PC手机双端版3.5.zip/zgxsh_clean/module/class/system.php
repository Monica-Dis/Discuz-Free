<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){exit('Access Denied');}
//本组件由西安日月星辰软件开发 使用者请尊重开发人员 保留此信息 , 百度搜索游芯沙盒可更新本工具
/* 语言包设置
  'system_end' => '错误跳出系统',
  'prompt_title' => '系统提示',
  'prompt_button' => '知道了',
  'sys_integral1' => '不足!!当前操作需求如下!<br>需要: ',
  'sys_integral2' => '<br>拥有: ',
  'sys_integral3' => '<br>还差: ',
  'sys_d' => '天',
  'sys_h' => '小时',
  'sys_m' => '分',
  'sys_s' => '秒',
  'prompt_admin' => '您权限不足无法访问此页面',
  //----模版语言包----
  'upload01' => '上传失败',
  'upload02' => '上传成功',
*/

function co($txt,$arr=""){  //语言包缩短函数
	global $_G;
	global $_GET;
  $a = lang('plugin/'.array_shift(explode(":",$_GET['id'])),$txt,$arr);
  return $a;
}
function prompt($prompt,$onClick_v="",$paramete=array()){  //提示信息跳转 $url指定提示页面地址 onClick_v返回按钮执行JS paramete参数
	global $_G;
	global $_GET;
	global $_TRC;
  $navtitle = $_TRC[ 'p_name' ];
  
  if($onClick_v==""){
    global $onClick_v;
  }
	
	$url=$paramete['url'];  //指定模版
	$title=$paramete['title'];  //标题文字
	$button=$paramete['button'];  //按钮文字
	$icon=$paramete['icon'];  //提示图标 1=绿色成功 2=红色失败 3=黄色警告 4=蓝色提醒
	
	if($onClick_v==""){
		if($_G['mobile']==false){
			$onClick_v = "window.location.reload(true);";
		}else{
			$onClick_v = "location=document.referrer";
		}
	}
	
	if($url==""){
		$url = array_shift(explode(":",$_GET['id'])).':prompt/prompt';
	}
	if($title==""){
		$title = co('prompt_title');
	}
	if($button==""){
		$button = co('prompt_button');
	}
	if($icon==1){
		$icon = '<p style="margin: 20px"><i class="layui-icon layui-icon-face-smile" style="color: #0b0;font-size: 40px;"></i></p>';
	}elseif($icon==2){
		$icon = '<p style="margin: 20px"><i class="layui-icon layui-icon-face-cry" style="color: #f00;font-size: 40px;"></i></p>';
	}elseif($icon==3){
		$icon = '<p style="margin: 20px"><i class="layui-icon layui-icon-face-surprised" style="color: #fb0;font-size: 40px;"></i></p>';
	}elseif($icon==4){
		$icon = '<p style="margin: 20px"><i class="layui-icon layui-icon-about" style="color: #06f;font-size: 40px;"></i></p>';
	}else{
		$icon = '';
	}
	
	include template($url);
	exit();
}

function system_end($txt=""){  //系统报错
  global $_G;
  $prompt = co('system_end').$txt;  //根据插件语言包更换system_end
	prompt($prompt);
}

function q_name($uid){  //查询昵称
  $name = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '".$uid."'");
	$name = $name==""?" -- ":$name;
	return $name;
}
function q_uid($username){  //查询昵称
  $uid = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username = '".$username."'");
	$uid = $uid==""?0:$uid;
	return $uid;
}

function integral($uid,$v,$k,$title,$txt,$easytxt=""){  //积分操作 UID 增减数值 积分编号 标题 详细 弹闪提示
	global $_G;
  $db_ext = DB::result_first("SELECT extcredits".$k." FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
	if(!$db_ext){
    $db_ext = 0;  
  }
  if($db_ext+$v<0 and $v<0){
		$extname = $_G['setting']['extcredits'][$k]['title'];
    prompt($extname.co('sys_integral1').abs($v).$extname.co('sys_integral2').$db_ext.$extname.co('sys_integral3').(abs($v)-$db_ext).$extname,"",array('icon'=>2));
  }
  updatemembercount($uid,array('extcredits'.$k=>$v),true,'',0,$easytxt,$title,$txt);
	return true;
}

function inte_probe($uid,$v,$k){
  $db_ext = DB::result_first("SELECT extcredits".$k." FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  if(!$db_ext){
    $db_ext = 0;  
  }
  if($db_ext-$v<0){
    $r = $v - $db_ext;
    return $r;
  }
  return 0;
}

function inte_see($uid){
  $r[1] = DB::result_first("SELECT extcredits1 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[2] = DB::result_first("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[3] = DB::result_first("SELECT extcredits3 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[4] = DB::result_first("SELECT extcredits4 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[5] = DB::result_first("SELECT extcredits5 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[6] = DB::result_first("SELECT extcredits6 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[7] = DB::result_first("SELECT extcredits7 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  $r[8] = DB::result_first("SELECT extcredits8 FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
  return $r;
}

function notice($uid,$title,$txt){  //发送消息 UID 标题 内容
	$fsarr = array('subject' => $title , 'message' => $txt);
  notification_add($uid,'system','system_notice',$fsarr,1);
}

function symbol($v){  //正负符号显示函数
  $v+=0;
  if($v<0){
    $r = $v+"";
  }else{
    $r = "+".$v;
  }
  return $r;
}

function arr_col($array, $column_key, $index_key=null){  //数组列剥离 数组 剥离列名 新建列名
	foreach($array as $arr) {
		if(!is_array($arr)) continue;  //不是数组结束循环

		if(is_null($column_key)){  //是null
				$value = $arr;
		}else{
				$value = $arr[$column_key];  
		}

		if(!is_null($index_key)){  //是否指定新的键名
				$key = $arr[$index_key];
				$result[$key] = $value;
		}else{
				$result[] = $value;
		}
	}
	return $result; 
}

function get_client_ip(){  //获取客户IP
	$headers = array('HTTP_X_REAL_FORWARDED_FOR', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
	foreach ($headers as $h){
		$ip = $_SERVER[$h];
		// 有些ip可能隐匿，即为unknown
		if ( isset($ip) && strcasecmp($ip, 'unknown') ){
			break;
		}
	}
	if( $ip ){
		// 可能通过多个代理，其中第一个为真实ip地址
		list($ip) = explode(',', $ip, 2);		
	}
	if ('127.0.0.1' == $ip or !$ip){
		$ip = 'hidden';
	}
	return $ip;	
}

function rand_str($num){  //随机字符串
  $passwor_strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
  for($i=0;$i<$num;$i++){  //生成N位随机字符串
    $salt.=$passwor_strPol[rand(0,strlen($passwor_strPol)-1)];  //strlen($passwor_strPol)-1)长度-1   
  }
  return $salt;
}

function seq_str($num){  //序列字符串
  $passwor_strPol = "A"."BCDEFGHIJK"."LMNOPQRSTU"."VWXYZ01234"."56789abcde"."fghijklmno"."pqrstuvwxy"."z:?/.&_=";
  //                 0        1            2            3            4            5            6   
  $salt = $passwor_strPol[$num];  
  return $salt;
}

function is_weixin(){  //是否微信访问
	if ( strpos( $_SERVER[ 'HTTP_USER_AGENT' ],'MicroMessenger' ) !== false ) {
		return true;
	}
	return false;
}

function parsing_array($arr){  //输出数组显示
	foreach($arr as $k=>$v){
		if(is_array($v)){
			$r .= "<div style='padding-left: 18px'>".parsing_array($v)."</div>";
		}else{
			$r .= $k.":".$v."<br>";
		}
	}
	return $r;
}

function genSign($toSign, $privateKey){  //支付宝签名方法
  $privateKey = "-----BEGIN RSA PRIVATE KEY-----\n".wordwrap($privateKey,64,"\n",true)."\n-----END RSA PRIVATE KEY-----";

  $key = openssl_get_privatekey($privateKey);
  openssl_sign($toSign, $signature, $key);
  openssl_free_key($key);
  $sign = base64_encode($signature);
  return $sign;
}

function conv_time($time,$unit=""){  //unit=精确单位 s秒 m分 h小时 d天 r反向
  if($unit=="r"){
    if($time<60 or $unit=='s'){
      return $time.co('sys_s');
    }elseif($time<3600 or $unit=='m'){
      $t['s'] = floor($time%60);
      $t['m'] = floor($time/60);
      return $t['m'].co('sys_m');
    }elseif($time<86400 or $unit=='h'){
      $t['s'] = floor($time%3600%60);
      $t['m'] = floor($time%3600/60);
      $t['h'] = floor($time/3600);
      return $t['h'].co('sys_h');
    }elseif($time>=86400 or $unit=='d'){
      $t['s'] = floor($time%86400%3600%60);
      $t['m'] = floor($time%86400%3600/60);
      $t['h'] = floor($time%86400/3600);
      $t['d'] = floor($time/86400);
      return $t['d'].co('sys_d');
    }
  }
  if($time<60 or $unit=='s'){
    return $time.co('sys_s');
  }elseif($time<3600 or $unit=='m'){
    $t['s'] = floor($time%60);
    $t['m'] = floor($time/60);
    return $t['m'].co('sys_m').$t['s'].co('sys_s');
  }elseif($time<86400 or $unit=='h'){
    $t['s'] = floor($time%3600%60);
    $t['m'] = floor($time%3600/60);
    $t['h'] = floor($time/3600);
    return $t['h'].co('sys_h').$t['m'].co('sys_m').$t['s'].co('sys_s');
  }elseif($time>=86400 or $unit=='d'){
    $t['s'] = floor($time%86400%3600%60);
    $t['m'] = floor($time%86400%3600/60);
    $t['h'] = floor($time%86400/3600);
    $t['d'] = floor($time/86400);
    return $t['d'].co('sys_d').$t['h'].co('sys_h').$t['m'].co('sys_m').$t['s'].co('sys_s');
  }
}

function in_admin($uid,$admin_uid,$url=""){
  if(in_array($uid,$admin_uid)){
    return true;
  }else{
    prompt(co('prompt_admin'),$url,array('icon'=>2));
  }
}
//From: Dism_taobao-com
?>