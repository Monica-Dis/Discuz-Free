<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){exit('Access Denied');}
//本组件由西安日月星辰软件开发 使用者请尊重开发人员 保留此信息 , 百度搜索游芯沙盒可更新本工具
class layui {
	function form_name(){
    $rand = rand(1,99999);
    $r['news'] = "var form".$rand." = layui.form;form".$rand.".render();";
    $r['rend'] = "form".$rand.".render();";
    $r['name'] = "form".$rand;
		return $r;
  }
  function laydate_name(){  //随机HTML标签的ID就行
    $rand = rand(1,99999);
    $r = "laydate".$rand;
		return $r;
  }
  function laypage_name(){
    $rand = rand(1,99999);
    $r = "var laypage".$rand." = layui.laypage;";
		return $r;
  }
  function element_name(){
    $rand = rand(1,99999);
    $r = "var element".$rand." = layui.element;element".$rand.".render();";
		return $r;
  }
}
//From: Dism·taobao·com
?>