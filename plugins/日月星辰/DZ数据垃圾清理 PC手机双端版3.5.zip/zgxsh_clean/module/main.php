<?php
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

if(!$_G['uid']){
  header( "Location:member.php?mod=logging&action=login" );
  exit();
}

//----系统变量处理----
$_TRC = $_G[ 'cache' ][ 'plugin' ][ 'zgxsh_clean' ];
$_TRC['f_admin'] = explode('|',$_TRC['f_admin']);

//应用名称-用于页面标题显示
$navtitle = $_TRC[ 'p_name' ];

//----调用列表----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';

//----拓展列表----
include 'exte/chat.php';
include 'exte/public.php';
include 'exte/jninvest_clean.php';


//管理鉴权
if($_G['uid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
  $paramete['icon'] = 3;
  prompt(co('main01'),"location='forum.php'",$paramete);
}

//----插件函数----
//入库 数值 intval() 文字 daddslashes()
?>