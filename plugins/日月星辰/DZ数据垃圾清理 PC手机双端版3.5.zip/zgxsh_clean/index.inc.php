<?php
/**
 *	[DZ数据垃圾清理(zgxsh_clean.{modulename})] (C)2020-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2020-5-4 14:37
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';



$db_count = DB::result_first("SELECT count(id) FROM ".DB::table('home_notification'));

if($db_count<$_TRC['lv1_see']){
  $count_txt = co('inde01');
  $count_op = co('inde02');
}elseif($db_count<$_TRC['lv2_see']){
  $count_txt = co('inde03');
  $count_op = co('inde04');
}elseif($db_count<$_TRC['lv3_see']){
  $count_txt = co('inde05');
  $count_op = co('inde06');
}elseif($db_count>=$_TRC['lv3_see']){
  $count_txt = co('inde07');
  $count_op = co('inde08');
}


if($_TRC['chat']){
  $db_count_c = chat_count();
  if($db_count_c<$_TRC['lv1_see']){
    $count_txt_c = co('inde01');
    $count_op_c = co('inde02');
  }elseif($db_count_c<$_TRC['lv2_see']){
    $count_txt_c = co('inde03');
    $count_op_c = co('inde04');
  }elseif($db_count_c<$_TRC['lv3_see']){
    $count_txt_c = co('inde05');
    $count_op_c = co('inde06');
  }elseif($db_count_c>=$_TRC['lv3_see']){
    $count_txt_c = co('inde07');
    $count_op_c = co('inde08');
  }
}

if($_TRC['public']){
  $db_count_p = chat_public();
  if($db_count_p<$_TRC['lv1_see']){
    $count_txt_p = co('inde01');
    $count_op_p = co('inde02');
  }elseif($db_count_p<$_TRC['lv2_see']){
    $count_txt_p = co('inde03');
    $count_op_p = co('inde04');
  }elseif($db_count_p<$_TRC['lv3_see']){
    $count_txt_p = co('inde05');
    $count_op_p = co('inde06');
  }elseif($db_count_p>=$_TRC['lv3_see']){
    $count_txt_p = co('inde07');
    $count_op_p = co('inde08');
  }
}

//数据大小
$dbname = $_G['config']['db']['1']['dbname'];
$table_z = DB::fetch_all("SELECT * FROM information_schema.tables WHERE TABLE_SCHEMA='".$dbname."' ORDER BY DATA_LENGTH DESC LIMIT 10");
for($i=0;$i<count($table_z);$i++){
  $table_z[$i]['dl'] = round((($table_z[$i]['DATA_LENGTH'])/1024)/1024,2);
  $table_z[$i]['il'] = round((($table_z[$i]['INDEX_LENGTH'])/1024)/1024,2);
  if($table_z[$i]['TABLE_NAME']==DB::table("game_jninvest_invest_log")){  //TABLE_NAME
    if($_TRC['jninvest_clean']){
      $table_z[$i]['clean'] = "<button type='button' class='layui-btn layui-btn-xsm' onClick='table_clean(\"game_jninvest_invest_log\")'>CLEAN</button>";
    }
  }
}
$table_n = DB::fetch_first("SELECT * FROM information_schema.tables WHERE TABLE_SCHEMA='".$dbname."' AND TABLE_NAME='".DB::table('home_notification')."'");
$table_n_z = round((($table_n['DATA_LENGTH']+$table_n['INDEX_LENGTH'])/1024)/1024,2);
//print_r($aab);

include template('zgxsh_clean:index/index'); 
?>