<?php
/**
 *	[DZ数据垃圾清理(zgxsh_clean.{modulename})] (C)2020-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2020-5-4 14:37
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';

if($_GET['op']=="clean"){
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  DB::query("truncate table ".DB::table('home_notification'));
  $paramete['icon'] = 1;
  prompt(co('inde09'),"location='plugin.php?id=zgxsh_clean:index'",$paramete);
}
elseif($_GET['op']=="clean_chat"){
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  if($_TRC['chat']){
    clean_chat();
    $paramete['icon'] = 1;
    prompt(co('inde09'),"location='plugin.php?id=zgxsh_clean:index'",$paramete);
  }else{
    $paramete['icon'] = 2;
    prompt(co('inde10'),"location='plugin.php?id=zgxsh_clean:index'",$paramete);
  }
}
elseif($_GET['op']=="clean_public"){
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  if($_TRC['public']){
    public_chat();
    $paramete['icon'] = 1;
    prompt(co('inde09'),"location='plugin.php?id=zgxsh_clean:index'",$paramete);
  }else{
    $paramete['icon'] = 2;
    prompt(co('inde11'),"location='plugin.php?id=zgxsh_clean:index'",$paramete);
  }
}
elseif($_GET['op']=="table_clean"){  //特殊表格清理
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  if($ls['bh']=="game_jninvest_invest_log"){
    if($_TRC['jninvest_clean']){
      clean_jninvest_log();
    }
  }
  
  prompt(co('inde10'),"location='plugin.php?id=zgxsh_clean:index'",array('icon'=>1));
}


system_end();
?>