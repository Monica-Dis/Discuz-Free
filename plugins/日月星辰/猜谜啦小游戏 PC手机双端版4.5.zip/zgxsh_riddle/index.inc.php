<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

//�û���ȡ
$user = user::init();
//�Ƿ�����
if($user['exp_v']>=$user['exp_k']){
  $lvup = "showWindow('TC','plugin.php?id=zgxsh_riddle:index_if&op=lvup','get',0,{'cover':'1'});";
  $lvup_mob = "location='plugin.php?id=zgxsh_riddle:index_if&op=lvup';";
}

//�����ȡ10������
$riddle = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_riddle_list')." WHERE state='1' ORDER BY rand() LIMIT 10");
for($i=0;$i<10;$i++){
  if(!$riddle[$i]){
    $riddle[$i]['fee'] = " -- ";
    $riddle[$i]['class'] = " -- ";
    $riddle[$i]['title'] = " -- ";
    $riddle[$i]['but'] = 'f';
  }
}

//�������а�
$rank = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_riddle_user')." ORDER BY win DESC LIMIT 8");
for($i=0;$i<8;$i++){
  if(!$rank[$i]){
    $rank[$i]['name'] = " -- ";
    $rank[$i]['lv'] = " -- ";
    $rank[$i]['win'] = " -- ";
    
  }else{
    $rank[$i]['name'] = q_name($rank[$i]['uid']);
  }
  $rank[$i]['no'] = $i+1;
}

if($_TRC[ 'reward_ext' ]>0){
  $ls_time = time()-$_TRC['reward_time'];
  $riddle_count = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_riddle_list')." WHERE lz_uid='".$_G['uid']."' AND reward_true='1' AND time>='".$ls_time."'");
  if(count($riddle_count)<$_TRC['reward_num']){
    $co = array(
      'co1' => $_TRC['reward_rand'],
      'co2' => $_TRC['reward_v'].$_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'reward_ext' ] ][ 'title' ],
    );
    $txt_ts = co('inde11',$co);
  }else{
    $txt_ts = conv_time($riddle_count[0]['time']+$_TRC['reward_time']-time(),'r').co('inde12');
  }
}

//������ʾ
if($_TRC['quarter_true'] and $_TRC['quarter_ext'] and $_TRC['quarter_v']){  //��������
  $quarter = quarter::see(" WHERE state='0'");
  if(!$quarter){  //mei
    $in = array(
      'set_time' => time(),
      'end_time' => time()+$_TRC['quarter_time'],
    );
    quarter::add($in);
    $quarter = quarter::see(" WHERE state='0'");
  }
  //��������
  if($quarter['end_time']<time()){
    $i = 1;
    foreach($rank as $k=>$v){
      $co = array(
        'co1' => dgmdate($quarter['set_time'])."~".dgmdate($quarter['end_time']),
        'co2' => $i,
        'co3' => $_TRC['quarter_v'][$i].$_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'quarter_ext' ] ][ 'unit' ].$_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'quarter_ext' ] ][ 'title' ],
      );
      $txt = co('inde15',$co);
      integral($v['uid'],$_TRC['quarter_v'][$i],$_TRC['quarter_ext'],$_TRC['p_name'],$txt);
      notice($v['uid'],$_TRC['p_name'],$txt);
      $i++;
    }
    if($_TRC['quarter_state']!=2){
      $up = array(
        'win' => 0,
      );
      DB::update('zgxsh_riddle_user',$up);
    }
    
    //��������
    quarter::edit(array('id'=>$quarter['id']),array('state'=>1));
    //�ض�����
    $quarter = quarter::see(" WHERE state='0'");
    if(!$quarter){  //mei
      $in = array(
        'set_time' => time(),
        'end_time' => time()+$_TRC['quarter_time'],
      );
      quarter::add($in);
      $quarter = quarter::see(" WHERE state='0'");
    }
  }
  $quarter['end_date'] = dgmdate($quarter['end_time']);
}


include template('zgxsh_riddle:index/index'); 
?>