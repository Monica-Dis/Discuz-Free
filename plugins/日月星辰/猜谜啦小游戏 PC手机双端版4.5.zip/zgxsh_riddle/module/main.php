<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

if ( !$_G[ 'uid' ] ) {
  header( "Location:member.php?mod=logging&action=login" );
  exit();
}

//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';



//----ϵͳ��������----
$_TRC = $_G[ 'cache' ][ 'plugin' ][ 'zgxsh_riddle' ];

$_TRC['r_class'] = explode("|",$_TRC['r_class']);
$_TRC['add_exp'] = explode("|",$_TRC['add_exp']);
$_TRC['red_exp'] = explode("|",$_TRC['red_exp']);

if ( !$_TRC[ 'ext_sys' ] ) {
  prompt( co('main01'), "location='forum.php'" );
}

$_TRC[ 'ext_sys_title' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'ext_sys' ] ][ 'title' ]; //��ȡ��������
$_TRC[ 'ext_sys_img' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'ext_sys' ] ][ 'img' ]; //��ȡͼ��
$_TRC[ 'ext_sys_unit' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'ext_sys' ] ][ 'unit' ]; //��ȡ��λ
$_TRC[ 'ext_sys_num' ] = getuserprofile( 'extcredits' . $_TRC[ 'ext_sys' ] ); //��ȡ��ǰ�û�ӵ����

//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC[ 'p_name' ];

//�������
$_TRC['quarter_v'] = explode("|",$_TRC['quarter_v']);

//----�������----
//��� ��ֵ intval() ���� daddslashes()
class user{ 
  function init(){
    global $_G,$_TRC;
    $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_riddle_user')." WHERE uid='".$_G['uid']."'");
    if(!$user){
      $in = array(
        'uid' => $_G['uid'],
      );
      DB::insert('zgxsh_riddle_user',$in);
      $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_riddle_user')." WHERE uid='".$_G['uid']."'");
    }
    return $user;
  }
  function win_add($uid,$v){
    DB::query("UPDATE ".DB::table( 'zgxsh_riddle_user' )." SET win=win+".$v." WHERE uid='".$uid."'");
    return true;
  }
  function exp_add($uid,$v){
    DB::query("UPDATE ".DB::table( 'zgxsh_riddle_user' )." SET exp_v=exp_v+".$v." WHERE uid='".$uid."'");
    return true;
  }
  function exp_red($uid,$v){
    DB::query("UPDATE ".DB::table( 'zgxsh_riddle_user' )." SET exp_v=exp_v-".$v." WHERE uid='".$uid."'");
    return true;
  }
  function lvup(){
    global $_G,$_TRC;
    $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_riddle_user')." WHERE uid='".$_G['uid']."'");
    if($user['exp_v']<$user['exp_k'] or !$user){
      return false;
    }
    $up = array(
      'exp_v' => $user['exp_v']-$user['exp_k'],
      'exp_k' => $user['exp_k']+100,
      'lv' => $user['lv']+1,
    );
    DB::update('zgxsh_riddle_user',$up,array('uid'=>$_G['uid']));
          
    if($_TRC['lv_v']>0 and ($_TRC['lv_ext']>=1 or $_TRC['lv_ext']<=8)){
      integral($_G['uid'],$_TRC['lv_v']*($user['lv']+1),$_TRC['lv_ext'],$_TRC['p_name'],co('main16'));
    }
    
    return true;
  }
  function lv_c(){
    $up = array(
      'exp_v' => 0,
      'exp_k' => 100,
      'lv' => 1,
    );
    DB::update('zgxsh_riddle_user',$up);
  }
}
class riddle{
  function add($ls){
    global $_G;
    
    $answer = array(
      'answer1' => $ls['answer1'],
      'answer2' => $ls['answer2'],
      'answer3' => $ls['answer3'],
      'answer4' => $ls['answer4'],
      'answer5' => $ls['answer5'],
      'answer6' => $ls['answer6'],
      'answer7' => $ls['answer7'],
      'answer8' => $ls['answer8'],
      'answer_true' => $ls['answer_true'],
    );
    
    $answer = serialize($answer);
    $ls['class'] = !$ls['class']?co('main02'):$ls['class'];
    
    $in = array(
      'class' => $ls['class'],	//�������
      'fee' => $ls['fee'],	//����ѹ��
      'title' => $ls['title'],	//�������
      'txt' => $ls['txt'],	//��������
      'answer' => $answer,	//���б�
      'lz_uid' => $_G['uid'],	//����UID
      'time' => time(),
      'reward_true' => $ls['reward_true'],
    );
    
    DB::insert('zgxsh_riddle_list',$in);
    
    return true;
  }
  function guess($ls){
    global $_G,$_TRC;
    
    $riddle = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_riddle_list')." WHERE id='".$ls['bh']."'");
    if(!$riddle){
      prompt(co('ridd34'),"");
    }
    $riddle_list = unserialize($riddle['answer']);
    
    if($riddle['lz_uid']==$_G['uid']){
      prompt(co('main03'),"",array('icon'=>3));
    }
    
    for($i=1;$i<=8;$i++){
      if($riddle_list['answer'.$i]!=""){
        $riddle_list_fss[] = $riddle_list['answer'.$i];
      }
    }

    $fss_count = count($riddle_list_fss)-2;   
    if($fss_count>1){
      $fee_v = floor($riddle['fee']/$fss_count);
      $fee_v = $fee_v<0?1:$fee_v;
    }else{
      $fee_v = $riddle['fee'];
    }
        
    integral($_G['uid'],-$fee_v,$_TRC['ext_sys'],$_TRC['p_name'],co('main04').q_name($riddle['lz_uid']));
    
    if($riddle_list['answer_true'] != $ls['answer']){
      $fee = $riddle['fee']+$fee_v-$_TRC['sys_fee']<0?0:$riddle['fee']+$fee_v-$_TRC['sys_fee'];
      integral($riddle['lz_uid'],$fee,$_TRC['ext_sys'],$_TRC['p_name'],q_name($_G['uid']).co('main05'));
      
      $add_exp = rand($_TRC['add_exp'][0],$_TRC['add_exp'][1]);
      $red_exp = rand($_TRC['red_exp'][0],$_TRC['red_exp'][1]);
      user::win_add($riddle['lz_uid'],1);
      user::exp_add($riddle['lz_uid'],$add_exp);
      user::exp_red($_G['uid'],$red_exp);
      
      $txt .= co('main06').": ".$riddle['title']."<br>";
      $txt .= co('main07').": ".$riddle['fee'].$_TRC[ 'ext_sys_title' ]."<br>";
      $txt .= co('main08').": ".$fee_v.$_TRC[ 'ext_sys_title' ]."<br>";
      $txt .= "<span style='color:#f40'>".co('main09').": -".$_TRC['sys_fee'].$_TRC[ 'ext_sys_title' ]."</span><br>";
      $txt .= "<span style='color:#04f'>".co('main10').": +".$fee.$_TRC[ 'ext_sys_title' ]."</span><br>";
      $txt .= "<span style='color:#04f'>EXP: +".$add_exp."</span><br>";
      
      notice($riddle['lz_uid'],$_TRC['p_name'],$txt);
      
      DB::update("zgxsh_riddle_list",array('state'=>2,'tz_uid'=>$_G['uid']),array('id'=>$ls['bh']));
      
      prompt(co('main11').":<br>".$riddle_list['answer'.$riddle_list['answer_true']]."<br>".co('main12').": -".$fee_v.$_TRC[ 'ext_sys_title' ]."<br>EXP: -".$red_exp,"location='plugin.php?id=zgxsh_riddle:index'");
    }else{  //����ȷ
      $fee = $riddle['fee']+$fee_v-$_TRC['sys_fee']<0?0:$riddle['fee']+$fee_v-$_TRC['sys_fee'];
      integral($_G['uid'],$fee,$_TRC['ext_sys'],$_TRC['p_name'],co('main13').q_name($riddle['lz_uid']));
      
      $add_exp = rand($_TRC['add_exp'][0],$_TRC['add_exp'][1]);
      user::win_add($_G['uid'],1);
      user::exp_add($_G['uid'],$add_exp);
            
      $co = array(
        'co1' => $riddle['title'],
        'co2' => q_name($_G['uid']),
      );
    
      notice($riddle['lz_uid'],$_TRC['p_name'],co('main14',$co));
      
      DB::update("zgxsh_riddle_list",array('state'=>3,'tz_uid'=>$_G['uid']),array('id'=>$ls['bh']));
      
      $txt .= co('main15').": ".$riddle['title']."<br>";
      $txt .= co('main07').": ".$riddle['fee'].$_TRC[ 'ext_sys_title' ]."<br>";
      $txt .= "<span style='color:#f40'>".co('main09').": -".$_TRC['sys_fee'].$_TRC[ 'ext_sys_title' ]."</span><br>";
      $txt .= "<span style='color:#04f'>".co('main10').": +".($fee-$fee_v).$_TRC[ 'ext_sys_title' ]."</span><br>";
      $txt .= "<span style='color:#04f'>EXP: +".$add_exp."</span><br>";
      
      prompt($txt,"location='plugin.php?id=zgxsh_riddle:index'",array('icon'=>1));
    }
    return true;
  }
}
class quarter{
  function t_name() {
    return "zgxsh_riddle_quarter";
  }

  function add($in) {
    global $_G,$_TRC;
    DB::insert( self::t_name(), $in );
    
    $user_all = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_riddle_user'));
    foreach($user_all as $k=>$v){
      //quarter_v | quarter_ext
      $jltitle = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'quarter_ext' ] ][ 'title' ];
      $jl = "<br>".co('main18')."<br>";
      if($_TRC['quarter_v'][0]>0){$jl .= co('main19')." : ".$_TRC['quarter_v'][0].$jltitle."<br>";}
      if($_TRC['quarter_v'][1]>0){$jl .= co('main20')." : ".$_TRC['quarter_v'][1].$jltitle."<br>";}
      if($_TRC['quarter_v'][2]>0){$jl .= co('main21')." : ".$_TRC['quarter_v'][2].$jltitle."<br>";}
      if($_TRC['quarter_v'][3]>0){$jl .= co('main22')." : ".$_TRC['quarter_v'][3].$jltitle."<br>";}
      if($_TRC['quarter_v'][4]>0){$jl .= co('main23')." : ".$_TRC['quarter_v'][4].$jltitle."<br>";}
      if($_TRC['quarter_v'][5]>0){$jl .= co('main24')." : ".$_TRC['quarter_v'][5].$jltitle."<br>";}
      if($_TRC['quarter_v'][6]>0){$jl .= co('main25')." : ".$_TRC['quarter_v'][6].$jltitle."<br>";}
      if($_TRC['quarter_v'][7]>0){$jl .= co('main26')." : ".$_TRC['quarter_v'][7].$jltitle."<br>";}
      $txt = co('main17').$jl;
      notice($v['uid'],$_TRC['p_name'],$txt);
    }
    
    return;
  }

  function edit( $query, $up ) {
    DB::update( self::t_name(), $up, $query );
    return;
  }

  function del( $query, $n=0 ) {
  if(!$n){
      DB::delete( self::t_name(), $query);
    }else{
      DB::delete( self::t_name(), $query, $n );
    }
    return;
  }

  function see( $WHERE="" ) {
    $see = DB::fetch_first( "SELECT * FROM " . DB::table( self::t_name() ) . $WHERE );
    return $see;
  }

  function see_one( $WHERE="" , $field="*") {  //count()���� sum()���
    $see = DB::result_first( "SELECT ".$field." FROM " . DB::table( self::t_name() ) . $WHERE );
    return $see;
  }

  function see_all( $WHERE="" , $field="*") {
    $see = DB::fetch_all( "SELECT ".$field." FROM " . DB::table( self::t_name() ) . $WHERE );
    return $see;
  }

  function math($id,$field,$v,$nega=0){  //��� �ֶ� ���� �ɸ���
    $field_v = self::see_one(" WHERE id='".$id."'",$field);
    $v = intval($v);
    $field_v += $v;
    if($field_v<0 and !$nega){
      $field_v = 0;
    }
    self::edit(array('id'=>$id),array($field=>$field_v));
    return $field_v;
  }

}
//From: dis'.'m.tao'.'bao.com
?>