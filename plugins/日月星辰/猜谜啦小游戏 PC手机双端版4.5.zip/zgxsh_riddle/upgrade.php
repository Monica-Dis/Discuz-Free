<?php
/**
 *	[������(zgxsh_riddle.upgrade)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2020-6-18 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_riddle_list')." LIKE 'time'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_riddle_list')." ADD time int(20) default 0 NOT NULL AFTER tz_uid");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_riddle_list')." LIKE 'reward_true'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_riddle_list')." ADD reward_true int(1) default 0 NOT NULL AFTER time");
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_riddle_quarter` (
  `id` int(20) NOT NULL auto_increment,
  `set_time` int(20) NOT NULL,
  `end_time` int(20) NOT NULL,
  `state` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>