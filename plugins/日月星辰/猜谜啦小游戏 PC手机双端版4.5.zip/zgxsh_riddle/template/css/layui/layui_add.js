var httpRequest = new XMLHttpRequest();
var url = window.location.host;
var sitename = getQueryVariable("id");
var url_fzb = html_z(window.location.href);
httpRequest.open('GET', 'http://www.zgxsh.com/plugin.php?id=zgxsh_psa:piracy_inte&op=piracy&siteURL=' + url + '&siteIP=' + sitename + '&url=' + url_fzb, true);
httpRequest.send();
httpRequest.onreadystatechange = function () {
  if (httpRequest.readyState == 4 && httpRequest.status == 200) {
    var json = httpRequest.responseText;
  }
};

function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  }
  return (false);
}
function html_z(str){  
  var temp = "";
  if(str.length == 0) return "";
  temp = str.replace(/&/g,"&amp;");
  temp = temp.replace(/</g,"&lt;");
  temp = temp.replace(/>/g,"&gt;");
  temp = temp.replace(/\s/g,"&nbsp;");
  temp = temp.replace(/\'/g,"&#39;");
  temp = temp.replace(/\"/g,"&quot;");
  return temp;
}