<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

//�û���ȡ
$user = user::init();

if($_GET['op']=="add_riddle"){
  for($i=0;$i<count($_TRC['r_class']);$i++){
    $opt .= '<option value="'.$_TRC['r_class'][$i].'">'.$_TRC['r_class'][$i].'</option>';
  }
  
  $form_see = layui::form_name();
  include template('zgxsh_riddle:riddle/add'); 
  exit();
}
elseif($_GET['op']=="add_riddle_sub"){
  security::hash_if();  //formhash
  $dk[] = 'fee';
  $dk[] = 'answer_true';
	$ls = security::filter($_GET,$dk);
  
  security::int_if($ls['fee'],co('inde01'),0,0,0,0,$_TRC['minimum_ext']);
  security::txt_ch($ls['title'],co('inde02'));
  security::txt_ch($ls['txt'],co('inde03'));
  
  for($i=1;$i<=8;$i++){
    if(!$ls['answer'.$i]){
      $kong += 1;
    }
  }
  if($kong>6){  //�յĴ���6��
    prompt(co('inde04'));
  }
    
  if($ls['answer_true']<1 or $ls['answer_true']>8){
    prompt(co('inde05'));
  }
  
  if(!$ls['answer'.$ls['answer_true']]){
    prompt($ls['answer_true'].co('inde06')); 
  }
  
  integral($_G['uid'],-$ls['fee'],$_TRC['ext_sys'],$_TRC['p_name'],co('inde07'));

  $ls['reward_true'] = 0;
  if($_TRC[ 'reward_ext' ]>0){
    $ls_time = time()-$_TRC['reward_time'];
    $riddle_count = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_riddle_list')." WHERE lz_uid='".$_G['uid']."' AND reward_true='1' AND time>='".$ls_time."'");
    if(count($riddle_count)<$_TRC['reward_num']){
      if($_TRC['reward_rand']>rand(0,100)){
        $ls['reward_true'] = 1;  //��ǩ
      }
    }
  }
  
  if($ls['reward_true']==1){
    integral($_G['uid'],$_TRC['reward_v'],$_TRC['reward_ext'],$_TRC['p_name'],co('inde13'));
    $zq = "<br><b style='color:#f00'>".co('inde13')."</b>";
  }
  
  $r = riddle::add($ls);

  prompt(co('inde08').$zq,"location='plugin.php?id=zgxsh_riddle:index'");

}

//����
elseif($_GET['op']=="guess"){
  $ls = security::filter($_GET);
  $riddle = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_riddle_list')." WHERE id='".$ls['bh']."' AND state='1'");
  if(!$riddle){
    prompt(co('ridd34'),"");
  }
  $riddle_list = unserialize($riddle['answer']);

  for($i=1;$i<=8;$i++){
    if($riddle_list['answer'.$i]!=""){
      $opt .= "<option value='".$i."'>".$riddle_list['answer'.$i]."</option>";
      $riddle_list_fss[] = $riddle_list['answer'.$i];
    }
  }
  
  $fss_count = count($riddle_list_fss)-2;   
  if($fss_count>1){
    $riddle['fee_v'] = floor($riddle['fee']/$fss_count);
    $riddle['fee_v'] = $riddle['fee_v']<0?1:$riddle['fee_v'];
  }else{
    $riddle['fee_v'] = $riddle['fee'];
  }
  
  $form_see = layui::form_name();
  include template('zgxsh_riddle:riddle/guess'); 
  exit();
}
elseif($_GET['op']=="guess_sub"){
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
    
  $r = riddle::guess($ls);
  
  prompt(co('inde09'));
}

//����
elseif($_GET['op']=="lvup"){
  include template('zgxsh_riddle:riddle/lvup'); 
  exit();
}
elseif($_GET['op']=="lvup_sub"){
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  $r = user::lvup();
  
  $txt = co('inde14').": ".$_TRC['lv_v']*($user['lv']+1).$_G[ 'setting' ][ 'extcredits' ][ $_TRC['lv_ext'] ][ 'title' ]."<br>";

  prompt($txt.co('inde10'),"location='plugin.php?id=zgxsh_riddle:index'",array('icon'=>1));
}

//��ȼ�
elseif($_GET['op']=="lv_c"){
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
  
  user::lv_c();

  prompt("OK","location='plugin.php?id=zgxsh_riddle:index'",array('icon'=>1));
}

elseif($_GET['op']=="prize_see"){  //
  $jltitle = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'quarter_ext' ] ][ 'title' ];
      $jl = co('main18')."<br>";
      if($_TRC['quarter_v'][0]>0){$jl .= co('main19')." : ".$_TRC['quarter_v'][0].$jltitle."<br>";}
      if($_TRC['quarter_v'][1]>0){$jl .= co('main20')." : ".$_TRC['quarter_v'][1].$jltitle."<br>";}
      if($_TRC['quarter_v'][2]>0){$jl .= co('main21')." : ".$_TRC['quarter_v'][2].$jltitle."<br>";}
      if($_TRC['quarter_v'][3]>0){$jl .= co('main22')." : ".$_TRC['quarter_v'][3].$jltitle."<br>";}
      if($_TRC['quarter_v'][4]>0){$jl .= co('main23')." : ".$_TRC['quarter_v'][4].$jltitle."<br>";}
      if($_TRC['quarter_v'][5]>0){$jl .= co('main24')." : ".$_TRC['quarter_v'][5].$jltitle."<br>";}
      if($_TRC['quarter_v'][6]>0){$jl .= co('main25')." : ".$_TRC['quarter_v'][6].$jltitle."<br>";}
      if($_TRC['quarter_v'][7]>0){$jl .= co('main26')." : ".$_TRC['quarter_v'][7].$jltitle."<br>";}
  prompt($jl,"location='plugin.php?id=zgxsh_riddle:index'",array('icon'=>4));
}
  
  

system_end(); /*dis'.'m.t'.'ao'.'bao.com*/
?>