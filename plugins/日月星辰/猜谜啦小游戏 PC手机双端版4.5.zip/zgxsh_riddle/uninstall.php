<?php
/**
 *	[������(zgxsh_riddle.uninstall)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_user`;
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_list`;
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_quarter`;
EOF;

runquery($sql);
$finish = TRUE; /*dism��taobao��com*/
?>