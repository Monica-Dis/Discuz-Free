<?php
/**
 *	[������(zgxsh_riddle.install)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_user`;
CREATE TABLE `cdb_zgxsh_riddle_user` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `lv` int(3) NOT NULL default '1',
  `exp_k` int(20) NOT NULL default '100',
  `exp_v` int(20) NOT NULL default '0',
  `win` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_list`;
CREATE TABLE `cdb_zgxsh_riddle_list` (
  `id` int(20) NOT NULL auto_increment,
  `class` varchar(20) NOT NULL,
  `fee` int(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `txt` varchar(500) NOT NULL,
  `answer` varchar(500) NOT NULL,
  `state` int(1) NOT NULL default '1',
  `lz_uid` int(20) NOT NULL,
  `tz_uid` int(20) NOT NULL,
  `time` int(20) NOT NULL,
  `reward_true` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_riddle_quarter`;
CREATE TABLE `cdb_zgxsh_riddle_quarter` (
  `id` int(20) NOT NULL auto_increment,
  `set_time` int(20) NOT NULL,
  `end_time` int(20) NOT NULL,
  `state` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = TRUE; /*dism��taobao��com*/
?>