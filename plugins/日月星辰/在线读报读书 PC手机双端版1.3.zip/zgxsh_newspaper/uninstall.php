<?php
/**
 *	[���߶���(zgxsh_newspaper.uninstall)] (C)2020-2100 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2020-09-02 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_entity`;
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_img`;
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_type`;
EOF;

runquery($sql);

$finish = true;
?>