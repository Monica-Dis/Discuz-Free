<?php
/**
 *	[���߶���(zgxsh_newspaper.install)] (C)2020-2100 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2020-09-03 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_entity`;
CREATE TABLE `cdb_zgxsh_newspaper_entity` (
  `id` int(20) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `seri` varchar(40) NOT NULL,
  `type` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index` (`name`,`seri`,`type`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_img`;
CREATE TABLE `cdb_zgxsh_newspaper_img` (
  `id` int(20) NOT NULL auto_increment,
  `e_id` int(20) NOT NULL,
  `img` varchar(200) NOT NULL,
  `page` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index` (`e_id`,`page`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_newspaper_type`;
CREATE TABLE `cdb_zgxsh_newspaper_type` (
  `id` int(20) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$finish = true;
?>