<?php
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

if ( $_GET[ 'op' ] != "tr_t" and!$_G[ 'uid' ] ) {
  header( "Location:member.php?mod=logging&action=login" );
  exit();
}

//----�����б�----
include 'class/system.php';
include 'class/sysadd.php';
include 'class/security.php';
include 'class/layui.php';

//----ϵͳ��������---- 
$_TRC = $_G[ 'cache' ][ 'plugin' ][ 'zgxsh_newspaper' ];

//ϵͳ
$_TRC[ 'sys_ext_title' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'sys_ext' ] ][ 'title' ];
$_TRC[ 'sys_ext_img' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'sys_ext' ] ][ 'img' ];
$_TRC[ 'sys_ext_unit' ] = $_G[ 'setting' ][ 'extcredits' ][ $_TRC[ 'sys_ext' ] ][ 'unit' ];
$_TRC[ 'sys_ext_num' ] = getuserprofile( 'extcredits' . $_TRC[ 'sys_ext' ] ); //��ȡ��ǰ�û�ӵ����

//���������߼�
$navtitle = $_TRC['p_name'];

//�ֻ��˵���ɫ
$fop_color[1] = "color: rgb(206,215,222)";
$fop_color[2] = "color: rgb(206,215,222)";
$fop_color[3] = "color: rgb(206,215,222)";
$fop_color[4] = "color: rgb(206,215,222)";
if($_GET['id']=='zgxsh_newspaper:index' or $_GET['id']=='zgxsh_newspaper:index_if'){
  $fop_color[1] = "color: rgb(0,188,216)";
}elseif($_GET['id']=='zgxsh_newspaper:market' or $_GET['id']=='zgxsh_newspaper:market_if'){
  $fop_color[2] = "color: rgb(0,188,216)";
}elseif($_GET['id']=='zgxsh_newspaper:invitation' or $_GET['id']=='zgxsh_newspaper:invitation_if'){
  $fop_color[3] = "color: rgb(0,188,216)";
}elseif($_GET['id']=='zgxsh_newspaper:user' or $_GET['id']=='zgxsh_newspaper:user_if'){
  $fop_color[4] = "color: rgb(0,188,216)";
}


//----�������----
include 'child/type.php';
include 'child/entity.php';
include 'child/img.php';
?>