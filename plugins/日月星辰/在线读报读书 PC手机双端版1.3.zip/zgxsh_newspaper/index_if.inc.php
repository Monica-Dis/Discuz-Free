<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//zgxsh_newspaper ���߶���
include 'module/main.php';

if($_GET['op']=="type_setup"){  //���ӷ����ǩ
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  $type = type::see_all();
  
  include template('zgxsh_newspaper:index/type_setup');
  exit();
}
elseif($_GET['op']=="type_add"){  //���ӷ����ǩ
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  include template('zgxsh_newspaper:index/type_add');
  exit();
}

elseif($_GET['op']=="paper_add"){
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  $type = type::see_all();
  foreach($type as $k=>$v){
    $opt .= '<option value="'.$v['id'].'">'.$v['name'].'</option>';
  }
  
  $form_see = layui::form_name();
  include template('zgxsh_newspaper:index/paper_add');
  exit();
}
elseif($_GET['op']=="paper_edit"){  
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  $ls = security::filter($_GET);
    
  $entity = entity::see(" WHERE id='".$ls['bh']."'");
  
  $type = type::see_all();
  foreach($type as $k=>$v){
    if($entity['type']==$v['id']){
      $v['selected'] = "selected";
    }
    $opt .= '<option value="'.$v['id'].'" '.$v['selected'].'>'.$v['name'].'</option>';
  }
  
  $form_see = layui::form_name();
  include template('zgxsh_newspaper:index/paper_edit');
  exit();
}
elseif($_GET['op']=="paper_del"){  
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
    
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
  
  entity::del(array('id'=>$ls['bh']));
  
  prompt(co('inde13'),"location='plugin.php?id=zgxsh_newspaper:index'",array('icon'=>1));
}
elseif($_GET['op']=="paper_setup"){  
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  $ls = security::filter($_GET);
  
  $entity = entity::see(" WHERE id='".$ls['bh']."'");
  $img = img::see_all(" WHERE e_id='".$entity['id']."' ORDER BY page ASC");
  
  include template('zgxsh_newspaper:index/paper_setup');
  exit();
}
elseif($_GET['op']=="paper_setup_add"){
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  $ls = security::filter($_GET);
  
  $form_see = layui::form_name();
  include template('zgxsh_newspaper:index/paper_setup_add');
  exit();
}
elseif($_GET['op']=="paper_setup_edit"){
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  $ls = security::filter($_GET);
  
  $img = img::see(" WHERE id='".$ls['page_id']."'");
  
  $form_see = layui::form_name();
  include template('zgxsh_newspaper:index/paper_setup_edit');
  exit();
}

//��ǩ
elseif($_GET['op']=="type_add_sub"){  //���ӷ����ǩ
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  $name = type::see(" WHERE name='".$ls['name']."'");
  
  if($name){
    prompt(co('inde02'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=type_setup'");
  }
  
  type::add($ls['name']);
  
  prompt(co('inde03'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=type_setup'",array('icon'=>1));
}
elseif($_GET['op']=="type_del_sub"){  //���ӷ����ǩ
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
  
  type::del(array('id'=>$ls['bh']));
  
  prompt(co('inde04'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=type_setup'",array('icon'=>1));
}

//�鼮����
elseif($_GET['op']=="paper_add_sub"){
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  $in = array(
    'name'=>$ls['name'],
    'seri'=>$ls['seri'],
    'type'=>$ls['type'],
  );
  
  entity::add($in);
  
  prompt(co('inde05'),"location='plugin.php?id=zgxsh_newspaper:index'",array('icon'=>1));
}
elseif($_GET['op']=="paper_edit_sub"){
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  $up = array(
    'name'=>$ls['name'],
    'seri'=>$ls['seri'],
    'type'=>$ls['type'],
  );
  
  entity::edit(array('id'=>$ls['bh']),$up);
  
  prompt(co('inde06'),"location='plugin.php?id=zgxsh_newspaper:index'",array('icon'=>1));
}

//��ҳͼƬ
elseif($_GET['op']=="paper_setup_add_sub"){
    
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  if(!$ls['e_id']){
    prompt(co('inde07'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  if(!$ls['img_s']){
    prompt(co('inde10'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=paper_setup&bh=".$ls['e_id']."'");
  }
  
  $in = array(
    'e_id'=>$ls['e_id'],
    'img'=>$ls['img_s'],
    'page'=>intval($ls['page']),
  );
  
  img::add($in);
    
  prompt(co('inde08'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=paper_setup&bh=".$ls['e_id']."'",array('icon'=>1));
}
elseif($_GET['op']=="paper_setup_edit_sub"){
    
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  if(!$ls['e_id']){
    prompt(co('inde09'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  if(!$ls['img_s']){
    prompt(co('inde10'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=paper_setup&bh=".$ls['e_id']."'");
  }
  
  $up = array(
    'e_id'=>$ls['e_id'],
    'img'=>$ls['img_s'],
    'page'=>intval($ls['page']),
  );
  
  img::edit(array('id'=>$ls['bh']),$up);
    
  prompt(co('inde11'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=paper_setup&bh=".$ls['e_id']."'",array('icon'=>1));
}
elseif($_GET['op']=="paper_setup_del_sub"){
    
  if($_G['uid']!=1){
    prompt(co('inde01'),"location='plugin.php?id=zgxsh_newspaper:index'");
  }
  
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
    
  img::del(array('id'=>$ls['page_id']),1);
    
  prompt(co('inde12'),"location='plugin.php?id=zgxsh_newspaper:index_if&op=paper_setup&bh=".$ls['bh']."'",array('icon'=>1));
}

//�鱨�鿴
elseif($_GET['op']=="paper_see"){
  
  $ls = security::filter($_GET);
  
  $entity = entity::see(" WHERE id='".$ls['bh']."'");
  $img = img::see_all(" WHERE e_id='".$ls['bh']."' ORDER BY page ASC");

  include template('zgxsh_newspaper:index/paper_see');
  exit();
}

system_end();
?>

