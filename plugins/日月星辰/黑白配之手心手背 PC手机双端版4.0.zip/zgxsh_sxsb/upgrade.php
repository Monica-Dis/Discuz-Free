<?php
/**
 *	[��ڰ�֮�����ֱ�(zgxsh_sxsb.upgrade)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_sxsb_rank` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `f` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT;
EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>