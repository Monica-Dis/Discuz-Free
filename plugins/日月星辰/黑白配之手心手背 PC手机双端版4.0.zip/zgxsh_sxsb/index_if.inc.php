<?php
/**
 *	[�����ֱ�(zgxsh_sxsb.{modulename})] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2019-3-18 15:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';
$AQ = new AQ();
$db = war_monitoring();

if($_GET['cz']=="ck"){  //�����λ
  
  $LS = $AQ -> ck($_GET);
  
  if(($db['time']<time() and $_TRC['SYS_TIME']>0 and $db['time']<>0)){
    $TS = co('if01');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $uid_l = unserialize($db['uid_l']);
  
  //�����ж�
  $LS['There'] = false;
  for($i=1;$i<=24;$i++){
    if($uid_l[$i]['uid'] == $_G['uid']){
      $LS['There'] = true;
      $LS['dqcp'] = $uid_l[$i]['cp']==1?co('if02'):co('if03');
      $LS['card'] = $uid_l[$i]['cp'];
      break;
    }
  }
  
  //�㵽�Լ�
  if($LS['uid'] == $_G['uid']){  
    if($LS['card']==1){
      $card1_hidden = 'hidden';
      $card2_hidden = '';
    }elseif($LS['card']==2){
      $card1_hidden = '';
      $card2_hidden = 'hidden';
    }
    include template('zgxsh_sxsb:ck/zj');
    exit();
  }
  
  //·��
  if($LS['There']){
    if($LS['uid']>0){
      $LS['name'] = cx_username($LS['uid']);
      include template('zgxsh_sxsb:ck/ty');  //���۹���
      exit();
    }else{
      $TS = co('if04');
      include template('zgxsh_sxsb:ts/ts');  //�տ�
      exit();
    }
  }else{
    if($LS['uid']>0){
      $TS = co('if05');
      include template('zgxsh_sxsb:ts/ts');  //����
      exit();
    }else{
      include template('zgxsh_sxsb:ck/jr');  //����ս��
      exit();
    }
  }
  
  $TS = $LS['bh'];
  
  $XS['rand'] = rand(1,99999);
  $XS['form'] = "var form".$XS['rand']." = layui.form;form".$XS['rand'].".render();";
  include template('zgxsh_sxsb:ts/ts');
  exit();
}
elseif($_GET['cz']=='join_sub'){
  
  if(!submitcheck('formhash')){
    $TS = co('main03');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $LS = $AQ -> join_sub($_GET);
    
  $uid_l = unserialize($db['uid_l']);
  foreach($uid_l as $k=>$v){
    if($v['uid']==$_G['uid']){
      $TS = "You have joined the war";
      include template('zgxsh_sxsb:ts/ts');
      exit();
    }
  }
  $uid_l[$LS['bh']]['uid'] = $_G['uid'];
  $uid_l[$LS['bh']]['name'] = cx_username($_G['uid']);
  $uid_l[$LS['bh']]['cp'] = $LS['cq'];
  $db['uid_l'] = serialize($uid_l);
  $db['jr'] += $_TRC['SYS_JR'];
  
  if(!$db['time']){
    $db['time'] = time()+$_TRC['SYS_TIME'];  //����������
  }
    
  sys_integral($_G['uid'],-$_TRC['SYS_JR'],$_TRC);
  
  if($_TRC['lock']){
    DB::query("LOCK TABLE ".DB::table('zgxsh_sxsb_zj')." WRITE");
  }
  DB::update('zgxsh_sxsb_zj',$db,array('id'=>1));
  if($_TRC['lock']){
    DB::query("UNLOCK TABLES");
  }
  
  $TS = co('if06');
  
  include template('zgxsh_sxsb:ts/ts');
  exit();
}
elseif($_GET['cz']=='change_sub'){
  
  if(!submitcheck('formhash')){
    $TS = co('main03');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $LS = $AQ -> join_sub($_GET);
  
  sys_integral($_G['uid'],-$_TRC['SYS_TY'],$_TRC);
  
  $uid_l = unserialize($db['uid_l']);
  $uid_l[$LS['bh']]['cp'] = $LS['cq'];
  $db['uid_l'] = serialize($uid_l);
    
  DB::update('zgxsh_sxsb_zj',$db,array('id'=>1));
  
  $TS = co('if07');
  
  include template('zgxsh_sxsb:ts/ts');
  exit();
}
elseif($_GET['cz']=='eagle_eye_sub'){  //eagle_eye
  
  if(!submitcheck('formhash')){
    $TS = co('main03');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  if(!$_TRC['SYS_TY']){
    $TS = co('main08');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $LS = $AQ -> eagle_eye_sub($_GET);
  
  sys_integral($_G['uid'],-$_TRC['SYS_TY'],$_TRC);
  
  $uid_l = unserialize($db['uid_l']);
  $LS['cp'] = $uid_l[$LS['bh']]['cp']==1?co('if02'):co('if03');
    
  $TS = $uid_l[$LS['bh']]['name'].co('if08')."[".$LS['cp']."]";
  $fsarr = array('subject' => co('if09') , 'message' => co('if10').' '.$_G['username'].' '.co('if11'));
  notification_add($uid_l[$LS['bh']]['uid'], 'system', 'system_notice', $fsarr, 1);
  
  include template('zgxsh_sxsb:ts/ts');
  exit();
}
elseif($_GET['cz']=='full_sub'){  //��������
  
  if(!submitcheck('formhashget',1)){  //get�ύ
    $TS = co('main03');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $uid_l = unserialize($db['uid_l']);
  
  $LS['rs'] = 0;
  for($i=1;$i<=24;$i++){
    if($uid_l[$i]['uid']){
      $LS['rs']++;
      $uid_l[$i]['img'] = avatar($uid_l[$i]['uid'],'',1);
      if($uid_l[$i]['uid']==$_G['uid']){
        $LS['cp'] = $uid_l[$i]['cp']==1?co('if02'):co('if03');
      }
      $uid_l[$i]['box'] = 'box-shadow:-1px -1px 1px 1px rgba(44,44,44,0.00)';
    }else{
      $uid_l[$i]['img'] = 'source/plugin/zgxsh_sxsb/template/img/tx.png';
      $uid_l[$i]['box'] = 'box-shadow:-1px -1px 1px 1px rgba(44,44,44,0.44)';
    }
    if($uid_l[$i]['cp']==1){  //�ڰ׼���
      $LS['tj']['h'] += 1; 
    }elseif($uid_l[$i]['cp']==2){
      $LS['tj']['b'] += 1;
    }
  }
	
	if($LS['rs']<$_TRC['SYS_RS']){  //��û��
		header("Location:plugin.php?id=zgxsh_sxsb:index");
    exit();
	}
  
  if($LS['tj']['h']<$_TRC['SYS_RS'] and $LS['tj']['b']<$_TRC['SYS_RS']){
    if($LS['tj']['h']>$LS['tj']['b']){  //��ʤ
      $LS['win'] = "b";
      $LS['SF'] = co('inde01');
      $LS['jl'] = floor(($db['jr']-($db['jr']*$_TRC['SYS_SF']))/$LS['tj']['b']);
    }elseif($LS['tj']['h']<$LS['tj']['b']){  //��ʤ
      $LS['win'] = "h";
      $LS['SF'] = co('inde02');
      $LS['jl'] = floor(($db['jr']-($db['jr']*$_TRC['SYS_SF']))/$LS['tj']['h']);
    }else{  //ƽ��
      $LS['win'] = "p";
      $LS['SF'] = co('inde03');
      $LS['jl'] = floor(($db['jr']-($db['jr']*$_TRC['SYS_SF']))/($LS['tj']['h']+$LS['tj']['b']));
    }
  }
  else{  //ȫ�ڻ���ȫ��
    $LS['win'] = "p";
    $LS['SF'] = co('inde03');
    $LS['jl'] = floor(($db['jr']-($db['jr']*$_TRC['SYS_SF']))/($LS['tj']['h']+$LS['tj']['b']));
  }
  
  for($i=1;$i<=24;$i++){
    if($uid_l[$i]['uid']){
      $LS['cp'] = $uid_l[$i]['cp']==1?'<b style="color:rgba(50,50,50,1.00)">'.co('inde04').'</b>':'<b style="color:rgba(200,200,200,1.00)">'.co('inde05').'</b>';
      if($LS['win']=="h" and $uid_l[$i]['cp']==1){  //��ʤ
        sys_integral($uid_l[$i]['uid'],$LS['jl'],$_TRC);
        $LS['XX'] .= $uid_l[$i]['name']." ".co('inde06')." ".$LS['cp']." ".co('inde07')." [".$LS['jl']."]".$_TRC['MAIN_JFX_unit'].$_TRC['MAIN_JFX_CName'].$_TRC['MAIN_JFX_Logo']."<br>";
				rank_ud($uid_l[$i]['uid'],3);
      }elseif($LS['win']=="b" and $uid_l[$i]['cp']==2){  //��ʤ
        sys_integral($uid_l[$i]['uid'],$LS['jl'],$_TRC);
        $LS['XX'] .= $uid_l[$i]['name']." ".co('inde06')." ".$LS['cp']." ".co('inde07')." [".$LS['jl']."]".$_TRC['MAIN_JFX_unit'].$_TRC['MAIN_JFX_CName'].$_TRC['MAIN_JFX_Logo']."<br>";
				rank_ud($uid_l[$i]['uid'],3);
      }elseif($LS['win']=="p"){  //ƽ��
        sys_integral($uid_l[$i]['uid'],$LS['jl'],$_TRC);
        $LS['XX'] .= $uid_l[$i]['name']." ".co('inde06')." ".$LS['cp']." ".co('inde08')." [".$LS['jl']."]".$_TRC['MAIN_JFX_unit'].$_TRC['MAIN_JFX_CName'].$_TRC['MAIN_JFX_Logo']."<br>";
				rank_ud($uid_l[$i]['uid'],2);
      }else{  //ʧ��
        $LS['XX'] .= $uid_l[$i]['name']." ".co('inde06')." ".$LS['cp']." ".co('inde09')."<br>";
				rank_ud($uid_l[$i]['uid'],1);
      }
    }else{
			$LS['false'] += 1;
		}
  }

	if($LS['false']>=24){  //û�˲μ�
		header("Location:plugin.php?id=zgxsh_sxsb:index");
    exit();
	}else{
		$db['jr'] = ceil(($db['jr']*$_TRC['SYS_SF'])*$_TRC['SYS_JC']);
	}
  
	
	$LS['XX'] = '<b style="color:rgba(50,50,50,1.00)">'.co('inde04').'</b>'." ".$LS['tj']['h']." ".co('inde10')." , ".'<b style="color:rgba(200,200,200,1.00)">'.co('inde05').'</b>'." ".$LS['tj']['b']." ".co('inde10')." , ".$LS['SF']."<br>".$LS['XX'];
  $LS['XX'] .= "<br>".co('inde11').$db['jr'].$_TRC['MAIN_JFX_unit'].$_TRC['MAIN_JFX_CName'].$_TRC['MAIN_JFX_Logo'];
  
  for($i=1;$i<=24;$i++){ 
    if($uid_l[$i]['uid']){
      $fsarr = array('subject' => co('inde12') , 'message' => $LS['XX']);
      notification_add($uid_l[$i]['uid'], 'system', 'system_notice', $fsarr, 1);
      $uid_l[$i]['uid'] = 0;
      $uid_l[$i]['name'] = "<em style='color:rgba(80,80,80,0.50)'><".co('main04')."></em>";
      $uid_l[$i]['cp'] = 0;
    }
    unset($uid_l[$i]['img']);
    unset($uid_l[$i]['box']);
  }
  
  $db['uid_l'] = serialize($uid_l);
  $db['time'] = 0;
    
  DB::update('zgxsh_sxsb_zj',$db,array('id'=>1));
  
  $TS = co('inde13')."<br>".$LS['XX'];
  include template('zgxsh_sxsb:index/index_ts');
  exit();

}
elseif($_GET['cz']=='flow_bureau'){  //���ֽ���
  
  //print_r($_GET);
  
  if(!submitcheck('formhashget',1)){  //get�ύ
    $TS = co('main03');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  
  $uid_l = unserialize($db['uid_l']);
  
  for($i=1;$i<=24;$i++){
    if($uid_l[$i]['uid']){
      sys_integral($uid_l[$i]['uid'],$_TRC['SYS_JR'],$_TRC);
      $LS['XX'] .= $uid_l[$i]['name']." ".co('inde14')." [".$_TRC['SYS_JR']."]".$_TRC['MAIN_JFX_unit'].$_TRC['MAIN_JFX_CName'].$_TRC['MAIN_JFX_Logo']."<br>";
      $db['jr'] -= $_TRC['SYS_JR'];
    }
  }
  
  for($i=1;$i<=24;$i++){ 
    if($uid_l[$i]['uid']){
      $fsarr = array('subject' => co('inde12') , 'message' => $LS['XX']);
      notification_add($uid_l[$i]['uid'], 'system', 'system_notice', $fsarr, 1);
      $uid_l[$i]['uid'] = 0;
      $uid_l[$i]['name'] = "<em style='color:rgba(80,80,80,0.50)'><".co('main04')."></em>";
      $uid_l[$i]['cp'] = 0;
    }
    unset($uid_l[$i]['img']);
    unset($uid_l[$i]['box']);
  }
  
  $db['uid_l'] = serialize($uid_l);
  $db['time'] = 0;
  
  
  DB::update('zgxsh_sxsb_zj',$db,array('id'=>1));
  
  $TS = co('inde15')."<br>".$LS['XX'];
  include template('zgxsh_sxsb:index/index_ts');
  exit();

}
elseif($_GET['cz']=='help'){
  $TS = co('if12');
  $TS .= co('if13');
  $TS .= co('if14');
  $TS .= co('if15');
  $TS .= co('if16');
  $TS .= co('if17');
  $TS .= co('if18');
  $TS .= co('if19');
  $TS .= co('if20');
  include template('zgxsh_sxsb:ts/ts');
  exit();
}
system_end(); /*dis'.'m.t'.'ao'.'bao.com*/
?>