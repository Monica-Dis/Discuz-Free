<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';


//�û�����
if($_GET['op']=='desc_see'){  //ģ����ܲ鿴
  security::hash_if(1);  //GET�ύ
  $ls = security::filter($_GET);
  $db_mod_desc = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id='".$ls['bh']."'" );
  love::heat_add($ls['bh']);  //�����ȶ�
  
  include template('zgxsh_mod:index/mod_see'); 
	exit();
}
elseif($_GET['op']=='heat_add'){  //ajax��ʽ�����ȶ�
  
  security::hash_if();  //GET�ύ
  $ls = security::filter($_GET);
  love::heat_add($ls['bh']);  //�����ȶ�
  exit();
}
elseif($_GET['op']=='down_add'){  //ajax��ʽ����������
  security::hash_if();  //GET�ύ
  $ls = security::filter($_GET);
  love::down_add($ls['bh']);  //�����ȶ�
  exit();
}


//��������
elseif($_GET['op']=='mod_add'){  
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  include template('zgxsh_mod:mod/mod_add'); 
  exit();
}
elseif($_GET['op']=='mod_add_sub'){  
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if();
  $ls = security::filter($_GET);
    
  security::txt_en($ls['name_ch'],co('inde01'));
  security::txt_en($ls['name_en'],co('inde02'));
  security::txt_en($ls['author_name'],co('inde03'));
  security::txt_en($ls['loader_v'],$_TRC['add_txt']);
  security::txt_en($ls['home_ch'],co('inde04'));
  security::txt_en($ls['home_en'],co('inde05'));
  
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE name_ch='".$ls['name_ch']."' OR name_en='".$ls['name_en']."'" );
  if($db_mod){
    prompt(co('inde06'),"location='plugin.php?id=zgxsh_mod:index'");
  }
  
  mod::add($ls);  
  
  prompt(co('inde07'),"location='plugin.php?id=zgxsh_mod:index'");
}
elseif($_GET['op']=='mod_edit'){ 
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if(1);
  $ls = security::filter($_GET);
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id='".$ls['bh']."'" );
  include template('zgxsh_mod:mod/mod_edit'); 
  exit();
}
elseif($_GET['op']=='mod_edit_sub'){ 
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if();
  $ls = security::filter($_GET);
  security::txt_en($ls['name_ch'],co('inde01'));
  security::txt_en($ls['name_en'],co('inde02'));
  security::txt_en($ls['author_name'],co('inde03'));
  security::txt_en($ls['loader_v'],$_TRC['add_txt']);
  security::txt_en($ls['home_ch'],co('inde04'));
  security::txt_en($ls['home_en'],co('inde05'));
  
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id!='".$ls['bh']."' AND (name_ch='".$ls['name_ch']."' OR name_en='".$ls['name_en']."')" );
  if($db_mod){
    prompt(co('inde06'),"location='plugin.php?id=zgxsh_mod:index'");
  }
  
  mod::edit($ls);  
  
  prompt(co('inde08'),"location='plugin.php?id=zgxsh_mod:index'");
}
elseif($_GET['op']=='mod_upda'){
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if(1);
  $ls = security::filter($_GET);
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id='".$ls['bh']."'" );
  include template('zgxsh_mod:mod/mod_upda'); 
  exit();
}
elseif($_GET['op']=='mod_upda_sub'){ 
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if();
  $ls = security::filter($_GET);
  security::txt_en($ls['loader_v'],$_TRC['add_txt']);
  security::txt_en($ls['version'],co('inde09'));
  security::txt_en($ls['volume'],co('inde10'));
  security::txt_en($ls['down_url'],co('inde11'));
  
  mod::upda($ls);  
  
  prompt(co('inde12'),"location='plugin.php?id=zgxsh_mod:index'");
}
elseif($_GET['op']=='mod_desc'){
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if(1);
  $ls = security::filter($_GET);
  $see['form'] = layui::form_name();
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id='".$ls['bh']."'" );
  include template('zgxsh_mod:mod/mod_desc'); 
  exit();
}
elseif($_GET['op']=='mod_desc_sub'){ 
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if();
  $ls = security::filter($_GET);
  
  security::txt_en($ls['desc_en'],co('inde13'));
  security::txt_en($ls['desc_ch'],co('inde14'));
  
  mod::desc($ls);
  
  prompt(co('inde15'),"location='plugin.php?id=zgxsh_mod:index'");
}
elseif($_GET['op']=='mod_del'){
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if(1);
  $ls = security::filter($_GET);
  $db_mod = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_mod_list' ) . " WHERE id='".$ls['bh']."'" );
  include template('zgxsh_mod:mod/mod_del'); 
  exit();
}
elseif($_GET['op']=='mod_del_sub'){
  
  if($_G['adminid']!=1 and !in_array($_G['uid'],$_TRC['f_admin'])){
    prompt(co('inde19'));
  }
  
  security::hash_if();
  $ls = security::filter($_GET);
  
  mod::del($ls);
  
  prompt(co('inde16'),"location='plugin.php?id=zgxsh_mod:index'");
}
  
system_end();
?>