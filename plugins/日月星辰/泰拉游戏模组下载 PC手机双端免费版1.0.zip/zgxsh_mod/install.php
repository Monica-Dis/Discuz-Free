<?php
/**
 *	[����ǽ(zgxsh_mod.install)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_mod_list`;
CREATE TABLE `cdb_zgxsh_mod_list` (
  `id` int(10) NOT NULL auto_increment,
  `name_en` varchar(255) NOT NULL,
  `name_ch` varchar(255) NOT NULL,
  `name_ni` varchar(255) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `volume` varchar(255) NOT NULL,
  `down_url` varchar(255) NOT NULL,
  `author_name` varchar(255) NOT NULL,
  `home_en` varchar(255) NOT NULL,
  `home_ch` varchar(255) NOT NULL,
  `desc_en` text NOT NULL,
  `desc_ch` text NOT NULL,
  `time` int(20) NOT NULL,
  `loader_v` varchar(255) NOT NULL,
  `download_n` int(10) NOT NULL,
  `heat` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = true;
?>