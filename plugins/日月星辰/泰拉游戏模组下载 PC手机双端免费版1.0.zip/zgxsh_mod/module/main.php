<?php
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

//if(!$_G['uid']){
//  header("Location:member.php?mod=logging&action=login");
//  exit();
//}

//----ϵͳ��������----
$_TRC = $_G[ 'cache' ][ 'plugin' ][ 'zgxsh_mod' ];

//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC[ 'p_name' ];

//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';

//����Ա�б�
$_TRC['f_admin'] = explode('|',$_TRC['f_admin']);
for($i=0;$i<count($_TRC['f_admin']);$i++){
  $_TRC['f_admin_name'][$i] = "<a href='?".$_TRC['f_admin'][$i]."'>".q_name($_TRC['f_admin'][$i])."</a>";
}
$_TRC['f_admin_name_txt'] = implode(' | ',$_TRC['f_admin_name']);

//----�������----
//��� ��ֵ intval() ���� daddslashes()
class love {  //���ϲ����
  function heat_add($id){  //�ȶ����� 
    DB::query("UPDATE ".DB::table( 'zgxsh_mod_list' )." SET heat=heat+1 where id='".$id."'");
    return true;
  }
  function down_add($id){  //����������
    DB::query("UPDATE ".DB::table( 'zgxsh_mod_list' )." SET download_n=download_n+1 where id='".$id."'");
    return true;
  }
}
class mod {  //ģ����
  function add($ls){
    $in = array(
      'ico' => daddslashes($ls['ico']),
      'name_ch' => daddslashes($ls['name_ch']),
      'name_en' => daddslashes($ls['name_en']),
      'author_name' => daddslashes($ls['author_name']),
      'loader_v' => daddslashes($ls['loader_v']),
      'home_ch' => daddslashes($ls['home_ch']),
      'home_en' => daddslashes($ls['home_en']),
    );
    DB::insert('zgxsh_mod_list',$in);
    return true;
  }
  function edit($ls){
    $in = array(
      'ico' => daddslashes($ls['ico']),
      'name_ch' => daddslashes($ls['name_ch']),
      'name_en' => daddslashes($ls['name_en']),
      'author_name' => daddslashes($ls['author_name']),
      'loader_v' => daddslashes($ls['loader_v']),
      'home_ch' => daddslashes($ls['home_ch']),
      'home_en' => daddslashes($ls['home_en']),
    );
    DB::update('zgxsh_mod_list',$in,array('id'=>$ls['bh']));
    return true;
  }
  function upda($ls){
    $in = array(
      'version' => daddslashes($ls['version']),
      'volume' => daddslashes($ls['volume']),
      'down_url' => daddslashes($ls['down_url']),
      'time' => daddslashes(time()),
      'loader_v' => daddslashes($ls['loader_v']),
    );
    DB::update('zgxsh_mod_list',$in,array('id'=>$ls['bh']));
    return true;
  }
  function desc($ls){
    $in = array(
      'name_ni' => daddslashes($ls['name_ni']),
      'desc_en' => daddslashes($ls['desc_en']),
      'desc_ch' => daddslashes($ls['desc_ch']),
    );
    DB::update('zgxsh_mod_list',$in,array('id'=>$ls['bh']));
    return true;
  }
  function del($ls){
    DB::delete('zgxsh_mod_list',array('id'=>$ls['bh']));
    return true;
  }
}
//From: Dism_taobao_com
?>