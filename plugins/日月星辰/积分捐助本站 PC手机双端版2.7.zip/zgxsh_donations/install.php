<?php
/**
 *	[���־�����վ(zgxsh_donations.install)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_donations_user`;
CREATE TABLE `cdb_zgxsh_donations_user` (
  `uid` int(10) NOT NULL,
  `k` int(10) NOT NULL default '0',
  `v` int(10) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = true;
?>