<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$_GET["page"] = dhtmlspecialchars($_GET["page"]);
$_GET["limit"] = dhtmlspecialchars($_GET["limit"]);

if($_GET["page"]<2){
    $_GET["page"] = 1;
}

$CX01 = 0 + ($_GET['limit'] * ($_GET["page"]-1));  
$CX02 = $_GET['limit'];                   

//$WHERE = " WHERE sl_uid is null";

$DB = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_bdx_zjb').$WHERE." LIMIT ".$CX01.",".$CX02);    
$count = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_bdx_zjb').$WHERE);    

for($i=0;$i<count($DB);$i++){
  $DB[$i]["lz_name"] = urlencode ( DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '".$DB[$i]['lz_uid']."'"));
  $DB[$i]["lz_time_zw"] = urlencode ( date("Y".lang('plugin/zgxsh_bdx', 'zj41')."m".lang('plugin/zgxsh_bdx', 'zj42')."d".lang('plugin/zgxsh_bdx', 'zj43')." H:i:s",$DB[$i]["lz_time"]) );
  
  $DB[$i]["lz_sz"] = "<img src='source/plugin/zgxsh_bdx/template/img/".$DB[$i]["lz_sz"].".png' width='28' height='28'/>";
  
  $an["no1"] = "location='plugin.php?id=zgxsh_bdx:index_if&cz=settlement&bh=".$DB[$i]["id"]."&mobile=2'";
  $an["no2"] = "location='plugin.php?id=zgxsh_bdx:index_if&cz=challenge&bh=".$DB[$i]["id"]."&mobile=2'";
  
  if($DB[$i]['lz_uid'] <> $_G['uid']){
    $DB[$i]["lz_sz"] = urlencode (lang('plugin/zgxsh_bdx', 'zj50'));
    $DB[$i]["cz"] .= "<button class='layui-btn layui-btn-sm layui-btn-danger' onClick=".$an["no2"].">".lang('plugin/zgxsh_bdx', 'zj39')."</button>";
  }else{
    $DB[$i]["cz"] .= "<button class='layui-btn layui-btn-sm' onClick=".$an["no1"].">".lang('plugin/zgxsh_bdx', 'zj40')."</button>";
  }
  $DB[$i]["cz"] = urlencode($DB[$i]["cz"]);
  
  if(!$DB[$i]['lz_kill']){
    $DB[$i]['lz_kill'] = 0;
  }
}

if(!count($DB)){
  $DB[0]['id'] = " -- ";
  $DB[0]['lz_name'] = " -- ";
  $DB[0]['lz_yf'] = " -- ";
  $DB[0]['lz_time_zw'] = " -- ";
  $DB[0]['lz_sz'] = " -- ";
  $DB[0]['lz_kill'] = " -- ";
  $DB[0]['cz'] = " -- ";
}

$ARR["code"] = 0;
$ARR["msg"] = "";
$ARR["count"] = $count;
$ARR["data"] = $DB;
$ARR["page"] = $_GET["page"];
$ARR["limit"] = $_GET['limit'];

echo urldecode( json_encode($ARR) ); 
?>