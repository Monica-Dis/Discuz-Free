<?php
/**
 *	[��ȭPK(zgxsh_cq.upgrade)] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_bdx_profit`;
CREATE TABLE `cdb_zgxsh_bdx_profit` (
  `id` int(10) NOT NULL auto_increment,
  `v` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

runquery($sql);

$finish = true;
?>