<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';
$GL = new bl_yz;

if($_GET['cz'] == "build_round"){
  $ls['on'] = floor($_BDX['integralNumber']/$_BDX['poundage']);
  include template('zgxsh_bdx:cjzj/cjzj');
  exit();
}  
elseif($_GET['cz'] == "build_round_sub"){  //build_round
  
  $_GET['jr'] += 0;
  $LS['jr'] = dhtmlspecialchars($_GET['jr']);
  $_GET['jus'] += 0;
  $LS['jus'] = dhtmlspecialchars($_GET['jus']);
    
  if(!submitcheck('formhash')){
    $prompt = lang('plugin/zgxsh_bdx','inif01');
    include template('zgxsh_bdx:ts/ts');
    exit();
  }

  if($LS['jr']<=0 or !is_numeric($LS['jr']) or strpos($LS['jr'],'.')){system_end(lang('plugin/zgxsh_bdx', 'zj01'));}
  if(strpos($LS['jus'],'.')){system_end(lang('plugin/zgxsh_bdx', 'zj53'));}  //��ʾ�Ϸ�����
  
  if($LS['jr']<$_BDX['poundage']){
    system_end(lang('plugin/zgxsh_bdx','zj54'));
  }
  
  if($LS['jus']<=0 or !is_numeric($LS['jus'])){$LS['jus']=1;}
  
  f_Integral_operation($_G['uid'],-($LS['jr']*$LS['jus']),$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'zj05'));
    
  for($i=0;$i<$LS['jus'];$i++){
    
    $ins = array(
      'lz_uid'  => intval($_G['uid']),
      'lz_yf'   => intval($LS['jr']),
      'lz_time' => time(),
      'lz_sz'   => rand(1,6),
      'lz_kill' => 0
    );

    //ShowMessage($ins['lz_time']);

    $ins = $GL -> zjb($ins);
    
    DB::insert('zgxsh_bdx_zjb',$ins);
  }
  
  if($LS['jr'] >= $_BDX['highMarksCreated']){
    $ins = array(
      'x_nr'    => lang('plugin/zgxsh_bdx', 'zj02').$_G['username'].lang('plugin/zgxsh_bdx', 'zj03').$LS['jr'].$_BDX['integralName'].lang('plugin/zgxsh_bdx', 'zj04'),
      'x_time'  => time(),
      'x_class' => 2
    );
    $ins = $GL -> xx($ins);
    DB::insert('zgxsh_bdx_xx',$ins);
  }
  
  
  $prompt = lang('plugin/zgxsh_bdx', 'zj05');
  include template('zgxsh_bdx:ts/ts');
  exit();
}
elseif($_GET['cz'] == "settlement"){
    
  $LS['bh'] = intval(dhtmlspecialchars($_GET['bh']));
  
  include template('zgxsh_bdx:cjzj/cjzj_js');
  exit();
}
elseif($_GET['cz'] == "settlement_sub"){
    
  if(!submitcheck('formhash')){
    $prompt = lang('plugin/zgxsh_bdx','inif01');
    include template('zgxsh_bdx:ts/ts');
    exit();
  }
  
  $LS['bh'] = intval(dhtmlspecialchars($_GET['bh']));
  
  $DB_Z = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_bdx_zjb')." WHERE id = '".$LS['bh']."'");
  if(!$DB_Z){
    ShowMessage("Read data error");
  }
  if($_G['uid']<>$DB_Z['lz_uid']){
    $ls['all_ex'] = getuserprofile($_BDX['integralField']);
    f_Integral_operation($_G['uid'],-$ls['all_ex'],$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'ffjs_nr'));
    
    $fsarr = array('subject' => lang('plugin/zgxsh_bdx', 'zb01'), 'message' => lang('plugin/zgxsh_bdx', 'zb02').$_G['uid'].lang('plugin/zgxsh_bdx', 'zb03'));
    notification_add($_BDX['SYS_FUID'], 'system', 'system_notice', $fsarr, 1);
    
    $prompt = lang('plugin/zgxsh_bdx', 'ffjs')."<br>";
    include template('zgxsh_bdx:ts/ts');
    exit();
  }
  
  if($DB_Z['lz_yf']-$_BDX['poundage']<0){system_end(lang('plugin/zgxsh_bdx', 'zj06').$_BDX['poundage'].$_BDX['integralName']."!");}
    
  $LS['HS'] = $DB_Z['lz_yf']-$_BDX['poundage'];
                           
  f_Integral_operation($DB_Z['lz_uid'],$LS['HS'],$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'zj40').lang('plugin/zgxsh_bdx', 'zj21'));
  
  DB::delete("zgxsh_bdx_zjb",array('id' => $LS['bh']),1);
  
  $prompt = lang('plugin/zgxsh_bdx', 'zj07')."<br>";
  $prompt .= lang('plugin/zgxsh_bdx', 'zj08').$LS['HS'].$_BDX['integralName']."<br>";
  $prompt .= lang('plugin/zgxsh_bdx', 'zj09').$_BDX['poundage'].$_BDX['integralName'].lang('plugin/zgxsh_bdx', 'zj10')."<br>";
  
  $ins = array(  //д��ӯ����
    'v' => $_BDX['poundage'] 
  );
  DB::insert('zgxsh_bdx_profit',$ins);
  
  include template('zgxsh_bdx:ts/ts');
  exit();
}
elseif($_GET['cz'] == "challenge"){
  
  $LS['bh'] = dhtmlspecialchars($_GET['bh'])+0;
  
  $DB_Z = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_bdx_zjb')." WHERE id = '".$LS['bh']."'");
  if(!$DB_Z){
    ShowMessage("Read data error");
  }
  
  if(f_Integral_query($_G['uid'],$_BDX['integralField'])<$DB_Z['lz_yf']){system_end(lang('plugin/zgxsh_bdx', 'zj11').$DB_Z['lz_yf'].$_BDX['integralName'].lang('plugin/zgxsh_bdx', 'zj12'));}
  
  include template('zgxsh_bdx:cjzj/cjzj_tz');
  exit();
}
elseif($_GET['cz'] == "challenge_sub"){  //��ս�ύ
  
  if(!submitcheck('formhash')){
    $prompt = lang('plugin/zgxsh_bdx','inif01');
    include template('zgxsh_bdx:ts/ts');
    exit();
  }
  
  $LS['bh'] = intval(dhtmlspecialchars($_GET['bh']));
  $LS['dx'] = dhtmlspecialchars($_GET['dx']);
  
  $DB_Z = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_bdx_zjb')." WHERE id = '".$LS['bh']."'");
  if(!$DB_Z){
    ShowMessage("Read data error");
  }
	
  if($_BDX['SYS_REP']){  //��ֹ�ظ���ս
		if($_BDX['SYS_REP_TIME']>0){   //������ʱ����
			if(($DB_Z['sl_time']+$_BDX['SYS_REP_TIME']*60)>time()){  //û�г�����ȫʱ��
				if($DB_Z['sl_uid']==$_G['uid']){  //�û��ظ�
			    $prompt = lang('plugin/zgxsh_bdx', 'zj55')."<br>".lang('plugin/zgxsh_bdx', 'zj58').dgmdate($DB_Z['sl_time']+$_BDX['SYS_REP_TIME']*60,'u').lang('plugin/zgxsh_bdx', 'zj59');
          include template('zgxsh_bdx:ts/ts');
          exit();
		    }
				//�û�û�ظ��ж�С��
				$ls_slip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$DB_Z['sl_uid']."'");
				$ls_ndip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$_G['uid']."'");
				if($ls_slip==$ls_ndip){
					$prompt = lang('plugin/zgxsh_bdx', 'zj57');
					include template('zgxsh_bdx:ts/ts');
					exit();
				}
			}
		}else{  //û����ʱ����
			if($DB_Z['sl_uid']==$_G['uid']){  //����û��Ƿ��ظ�
				$prompt = lang('plugin/zgxsh_bdx', 'zj55');
			  include template('zgxsh_bdx:ts/ts');
			  exit();
			}
			//�û�û�ظ��ж�С��
			$ls_slip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$DB_Z['sl_uid']."'");
			$ls_ndip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$_G['uid']."'");
			if($ls_slip==$ls_ndip){
				$prompt = lang('plugin/zgxsh_bdx', 'zj57');
				include template('zgxsh_bdx:ts/ts');
				exit();
			}
		}
			
	  
	}
  
  if($DB_Z['id'] == ""){system_end(lang('plugin/zgxsh_bdx', 'zj13'));}
  if($LS['dx'] == ""){system_end(lang('plugin/zgxsh_bdx', 'zj14'));}
  
  $LS['XJ'] = rand(1,6);
  $LS['ZJ'] = $DB_Z['lz_sz'];
  
  if($LS['dx']=="dx_d"){
    $LS['dxzw'] = lang('plugin/zgxsh_bdx', 'zj15');
  }else{
    $LS['dxzw'] = lang('plugin/zgxsh_bdx', 'zj16');  
  }
    
  if(($LS['ZJ'] > $LS['XJ'] and $LS['dx'] == 'dx_d') or ($LS['ZJ'] < $LS['XJ'] and $LS['dx'] == 'dx_x')){
    
		if($_BDX['SYS_SK']){  //������ս��ȡ
			$ls['ss'] = $DB_Z['lz_yf'];
		  $DB_Z['lz_yf'] = round($DB_Z['lz_yf'] * $_BDX['lossProportion']);
			$ls['ss'] = $ls['ss'] - $DB_Z['lz_yf'];
      $ins = array(  //д��ӯ����
        'v' => $DB_Z['lz_yf'] 
      );
      DB::insert('zgxsh_bdx_profit',$ins);
		}
		
    $prompt = lang('plugin/zgxsh_bdx', 'zj20')."!!!<br>";
    $prompt .= lang('plugin/zgxsh_bdx', 'zj17')." <img src='source/plugin/zgxsh_bdx/template/img/".$LS['ZJ'].".png' width='18' height='18'/> VS ";
    $prompt .= "<img src='source/plugin/zgxsh_bdx/template/img/".$LS['XJ'].".png' width='18' height='18'/> ".lang('plugin/zgxsh_bdx', 'zj18')."<br>";
    $prompt .= lang('plugin/zgxsh_bdx', 'zj19')." [".$LS['dxzw']."] ".lang('plugin/zgxsh_bdx', 'zj20')."!<br>";
    $prompt .= lang('plugin/zgxsh_bdx', 'zj21')." ".$DB_Z['lz_yf'].$_BDX['integralName'].$_BDX['integralLogo']."<br>";
		
		if($_BDX['SYS_SK']){  //������ս��ʾ
		  $prompt .= lang('plugin/zgxsh_bdx','zj56').$ls['ss'].$_BDX['integralName'].$_BDX['integralLogo']."<br>";  
		}
    
    $fsarr = array('subject' => $navtitle.lang('plugin/zgxsh_bdx', 'zj24'), 'message' => lang('plugin/zgxsh_bdx', 'zj25') . $_G['username'] . lang('plugin/zgxsh_bdx', 'zj26').' '.lang('plugin/zgxsh_bdx', 'zj27').' <br/> '.lang('plugin/zgxsh_bdx', 'zj31').' '.$LS['bh'].' '.lang('plugin/zgxsh_bdx', 'zj29')."<br>".lang('plugin/zgxsh_bdx', 'zj22').$DB_Z['lz_yf'].$_BDX['integralName'].$_BDX['integralLogo']);
    notification_add($DB_Z['lz_uid'], 'system', 'system_notice', $fsarr, 1);
    
    f_Integral_operation($_G['uid'],$DB_Z['lz_yf'],$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'zj39').lang('plugin/zgxsh_bdx', 'zj21'));
  
    DB::delete("zgxsh_bdx_zjb",array('id' => $LS['bh']),1);
    
		
		
    if($DB_Z['lz_kill'] >= $_BDX['SYS_KILL'] and $_BDX['SYS_KILL']>1){  //���ܳ���ս��,����С��2ʧЧ
      $ins = array(
        'x_nr'    => lang('plugin/zgxsh_bdx', 'zj32').$_G['username'].lang('plugin/zgxsh_bdx', 'zj33').$LS['bh'].lang('plugin/zgxsh_bdx', 'zj34').$DB_Z['lz_kill'].lang('plugin/zgxsh_bdx', 'zj35'),
        'x_time'  => time(),
        'x_class' => 3
      );
      $ins = $GL -> xx($ins);
      DB::insert('zgxsh_bdx_xx',$ins);
    }
    
  }
  elseif(($LS['ZJ'] <= $LS['XJ'] and $LS['dx'] == 'dx_d') or ($LS['ZJ'] >= $LS['XJ'] and $LS['dx'] == 'dx_x')){
    
    $prompt = lang('plugin/zgxsh_bdx', 'zj23')."!!!<br>";
    $prompt .= lang('plugin/zgxsh_bdx', 'zj19')." [".$LS['dxzw']."] ".lang('plugin/zgxsh_bdx', 'zj23')."!<br>";
    $prompt .= lang('plugin/zgxsh_bdx', 'zj22')." ".$DB_Z['lz_yf'].$_BDX['integralName'].$_BDX['integralLogo']."<br>";
    
    $LS['ZJHL'] = round($DB_Z['lz_yf'] * $_BDX['lossProportion']);
    
    $ins = array(  //д��ӯ����
      'v' => $DB_Z['lz_yf']-$LS['ZJHL'] 
    );
    DB::insert('zgxsh_bdx_profit',$ins);    
    
    $fsarr = array('subject' => $navtitle.lang('plugin/zgxsh_bdx', 'zj24'), 'message' => lang('plugin/zgxsh_bdx', 'zj25') . $_G['username'] . lang('plugin/zgxsh_bdx', 'zj26').' '.lang('plugin/zgxsh_bdx', 'zj28') .' <br/> '.lang('plugin/zgxsh_bdx', 'zj31').' '.$LS['bh'].' '.lang('plugin/zgxsh_bdx', 'zj30').' : '.$LS['ZJHL'].$_BDX['integralName']);
    notification_add($DB_Z['lz_uid'], 'system', 'system_notice', $fsarr, 1);
    
    f_Integral_operation($_G['uid'],-$DB_Z['lz_yf'],$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'zj39').lang('plugin/zgxsh_bdx', 'zj22'));
    
    $up = array(
      'lz_kill' =>  $DB_Z['lz_kill'] + 1,
      'lz_yf' => $DB_Z['lz_yf']+$LS['ZJHL'],
			'sl_uid' => $_G['uid'],
			'sl_time' => time()
    );
    $up = $GL -> zjb($up);
    DB::update('zgxsh_bdx_zjb',$up,array('id' => $LS['bh']));
    
    if($DB_Z['lz_kill']+1 >= $_BDX['SYS_KILL'] and $_BDX['SYS_KILL']>1){  //����ս�ֵ���
      $ins = array(
        'x_nr'    => lang('plugin/zgxsh_bdx', 'zj36').$LS['bh'].lang('plugin/zgxsh_bdx', 'zj37').($DB_Z['lz_kill']+1).lang('plugin/zgxsh_bdx', 'zj38'),
        'x_time'  => time(),
        'x_class' => 3
      );
      $ins = $GL -> xx($ins);
      DB::insert('zgxsh_bdx_xx',$ins);
    }
    
  }
  
  
  if($_BDX['Secondskill']>0){
    $lz_kill = DB::result_first("SELECT lz_kill FROM ".DB::table('zgxsh_bdx_zjb')." WHERE id = '".$LS['bh']."'");
    if($lz_kill>=$_BDX['Secondskill']){
      $DB_Z = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_bdx_zjb')." WHERE id = '".$LS['bh']."'");
      if(!$DB_Z){
        ShowMessage("Read data error");
      }

      $LS['HS'] = $DB_Z['lz_yf']-$_BDX['poundage'];
      $_BDX['poundages'] = $_BDX['poundage'];  //�洢������
      if($LS['HS']<0){
        $LS['HS']=0;
        $_BDX['poundages'] = $DB_Z['lz_yf'];  //���ѹ�ֵ����������������Ѱ���ѹ��ֵ����
      }
      $ins = array(  //д��ӯ����
        'v' => $_BDX['poundages'] 
      );
      DB::insert('zgxsh_bdx_profit',$ins); 
      f_Integral_operation($DB_Z['lz_uid'],$LS['HS'],$_BDX['integralField'],$_BDX['integralName'],$_BDX['integralField'],lang('plugin/zgxsh_bdx', 'zj40').lang('plugin/zgxsh_bdx', 'zj21'));

      DB::delete("zgxsh_bdx_zjb",array('id' => $LS['bh']),1);

      $info1 = $LS['bh'].lang('plugin/zgxsh_bdx', 'zj31').lang('plugin/zgxsh_bdx', 'zj51');
      $info2 = lang('plugin/zgxsh_bdx', 'zj08').$LS['HS'].$_BDX['integralName']."<br>";
      $info2 .= lang('plugin/zgxsh_bdx', 'zj09').$_BDX['poundage'].$_BDX['integralName'].lang('plugin/zgxsh_bdx', 'zj10')."<br>";
      
      $fsarr = array('subject' => $info1, 'message' => $info2);
      notification_add($DB_Z['lz_uid'], 'system', 'system_notice', $fsarr, 1);
    }
  }
  
  include template('zgxsh_bdx:ts/ts');
  exit();
}
elseif($_GET['cz']=="profit"){
  
  $profit = DB::result_first("SELECT sum(v) FROM ".DB::table('zgxsh_bdx_profit'));
  $profit = $profit+0;
  $prompt = $_BDX['SYS_PROFIT_TXT']."<br>".$_BDX['integralLogo'].$profit.$_BDX['integralName'];
  
  include template('zgxsh_bdx:ts/ts');
  exit();
}
elseif($_GET['cz']=="profit_del"){
  
  if(!submitcheck('formhash',1)){  //get
    $prompt = lang('plugin/zgxsh_bdx','inif01');
    include template('zgxsh_bdx:ts/ts');
    exit();
  }
  
  DB::query('DELETE FROM '.DB::table('zgxsh_bdx_profit'));
  $prompt = "OK";
  
  include template('zgxsh_bdx:ts/ts');
  exit();
}

system_end();
?>