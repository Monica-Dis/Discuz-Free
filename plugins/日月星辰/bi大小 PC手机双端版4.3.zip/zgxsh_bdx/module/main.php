<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

$_BDX['extcreditsSerialnumber'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_EXT'];  
$_BDX['lossProportion'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_SSB'];  
$_BDX['highMarksCreated'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_GFJ']+0;  
$_BDX['poundage'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_SXF']+0;  
$_BDX['integralName'] = $_G['setting']['extcredits'][$_BDX['extcreditsSerialnumber']]['title'];  
$_BDX['integralLogo'] = $_G['setting']['extcredits'][$_BDX['extcreditsSerialnumber']]['img'];  
$_BDX['integralField'] = 'extcredits'.$_BDX['extcreditsSerialnumber'];  
$_BDX['integralNumber'] = DB::result_first("SELECT ".$_BDX['integralField']." FROM ".DB::table('common_member_count')." WHERE uid = '".$_G['uid']."'");
$_BDX['integralTopUp'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_TOPUP'];
$_BDX['integralTopUpM'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_TOPUP_M'];
$_BDX['SYS_TOPTXT'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_TOPTXT'];
$_BDX['Secondskill'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_1TIME'];
$_BDX['SYS_DIRE'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_DIRE'];
$_BDX['SYS_RETURN_PC'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_RETURN_PC'];
$_BDX['SYS_RETURN_MB'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_RETURN_MB'];
$_BDX['SYS_REP'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_REP'];
$_BDX['SYS_REP_TIME'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_REP_TIME'];
$_BDX['SYS_SK'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_SK'];
$_BDX['SYS_KILL'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_KILL'];
$_BDX['SYS_PROFIT'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_PROFIT'];
$_BDX['SYS_PROFIT_TXT'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_PROFIT_TXT'];
$_BDX['SYS_FUID'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_FUID']<1?1:$_G['cache']['plugin']['zgxsh_bdx']['SYS_FUID'];
$_BDX['SYS_BLACK'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_BLACK'];
$_BDX['SYS_ASSAS'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_ASSAS'];
$_BDX['SYS_PROFIT_DEL'] = $_G['cache']['plugin']['zgxsh_bdx']['SYS_PROFIT_DEL'];
$_BDX['boaw'] = $_G['cache']['plugin']['zgxsh_bdx']['boaw'];
$navtitle = $_G['cache']['plugin']['zgxsh_bdx']['SYS_PNAME'];



function f_Integral_operation($GUID,$NUMBER,$EXT,$EXTNAME,$JFX,$custommemo){
  
  if($GUID == 0){system_end(lang('plugin/zgxsh_bdx', 'zj45'));}
  
  $LS_JF = DB::result_first( "SELECT " . $EXT . " FROM " . DB::table( 'common_member_count' ) . " WHERE uid = '" . $GUID . "'" );
  
  if($LS_JF + $NUMBER < 0){system_end(lang('plugin/zgxsh_bdx', 'zj46').$EXTNAME.lang('plugin/zgxsh_bdx', 'zj47')." [".$LS_JF."] ");}
  
  $LSJS = $LS_JF += $NUMBER;
  $UP = array(
    $EXT => intval($LSJS)
  );
  
  updatemembercount($GUID,array($JFX=>$NUMBER),true,'',0,'',lang('plugin/zgxsh_bdx','zj52'),$custommemo);
  
  return true;
}
function f_Integral_query($GUID,$EXT){
  
  if($GUID == 0){system_end(lang('plugin/zgxsh_bdx', 'zj48'));}
  
  $LS_JF = DB::result_first( "SELECT " . $EXT . " FROM " . DB::table( 'common_member_count' ) . " WHERE uid = '" . $GUID . "'" );
  
  return $LS_JF;
}


function system_end($prompt = "e"){
  global $_G;
  if($prompt == "e"){
    $prompt = lang('plugin/zgxsh_bdx', 'zj49');
  }
  include template('zgxsh_bdx:ts/ts');
  exit();
}

class bl_yz {
  
  /*zgxsh_bdx_zjb*/
  /*zgxsh_bdx_xx*/
  
  function zjb($bl){
    if($bl['lz_uid']){$bl_zh['lz_uid'] = intval($bl['lz_uid']);}
    if($bl['lz_yf']){$bl_zh['lz_yf'] = intval($bl['lz_yf']);}
    if($bl['lz_time']){$bl_zh['lz_time'] = intval($bl['lz_time']);}
    if($bl['lz_sz']){$bl_zh['lz_sz'] = intval($bl['lz_sz']);}
    if($bl['lz_kill']){$bl_zh['lz_kill'] = intval($bl['lz_kill']);}
    if($bl['sl_uid']){$bl_zh['sl_uid'] = intval($bl['sl_uid']);}
    if($bl['sl_time']){$bl_zh['sl_time'] = intval($bl['sl_time']);}
    return $bl_zh;
  }
  
  function xx($bl){
    if($bl['x_nr']){$bl_zh['x_nr'] = daddslashes($bl['x_nr']);}
    if($bl['x_time']){$bl_zh['x_time'] = intval($bl['x_time']);}
    if($bl['x_class']){$bl_zh['x_class'] = intval($bl['x_class']);}
    return $bl_zh;
  }
  
}

?>