<?php
/**
 *	[�ȴ�С(zgxsh_bdx.{modulename})] (C)2018-2099 Powered by ��о�羺.
 *	Version: 1.0
 *	Date: 2018-10-25 21:20
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//TODO - Insert your code here
include 'module/main.php';

$DB_message = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_bdx_xx')." ORDER BY id DESC LIMIT 0,10");

for($i=0;$i<count($DB_message);$i++){
  if($DB_message[$i]['x_class'] == 1){
    $LS = "layui-bg-red";
  }elseif($DB_message[$i]['x_class'] == 2){
    $LS = "layui-bg-black";
  }else{
    $LS = "layui-bg-black";
  }
  $carousel .= "<div class='".$LS."'><img src='source/plugin/zgxsh_bdx/template/img/xx".$DB_message[$i]['x_class'].".png'/> ".$DB_message[$i]['x_nr']." [".date("Y-m-d H:i:s",$DB_message[$i]["x_time"])."]</div>";  
}
$LS = "layui-bg-black";
$carousel .= "<div class='".$LS."'><img src='source/plugin/zgxsh_bdx/template/img/xx2.png'/> ".lang('plugin/zgxsh_bdx', 'zj44')." </div>";

include template('zgxsh_bdx:index/index');