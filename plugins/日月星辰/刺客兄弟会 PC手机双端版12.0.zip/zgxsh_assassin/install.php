<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.install)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_user`;
CREATE TABLE `cdb_zgxsh_assassin_user` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `works` varchar(255) NOT NULL,
  `will_id` int(10) default NULL,
  `will_po` int(10) NOT NULL default '0',
  `lv` int(3) NOT NULL default '1',
  `exp_k` int(10) NOT NULL default '100',
  `exp_v` int(10) NOT NULL default '0',
  `hp_k` int(10) NOT NULL default '200',
  `hp_v` int(10) NOT NULL default '200',
  `mp_k` int(10) NOT NULL default '100',
  `mp_v` int(10) NOT NULL default '100',
  `np_k` int(10) NOT NULL default '100',
  `np_v` int(10) NOT NULL default '0',
  `load` int(10) NOT NULL default '10',
  `attr_p` int(10) NOT NULL default '20',
  `skil_p` int(10) NOT NULL default '1',
  `attack` int(10) NOT NULL default '0',
  `defense` int(10) NOT NULL default '0',
  `smart` int(10) NOT NULL default '0',
  `insight` int(10) NOT NULL default '0',
  `armed_head` int(10) NOT NULL default '0',
  `armed_body` int(10) NOT NULL default '0',
  `armed_foot` int(10) NOT NULL default '0',
  `armed_weapons` int(10) NOT NULL default '0',
  `armed_crossbow` int(10) NOT NULL default '0',
  `armed_special` int(10) NOT NULL default '0',
  `skills1` int(3) NOT NULL default '0',
  `skills2` int(3) NOT NULL default '0',
  `skills3` int(3) NOT NULL default '0',
  `skills4` int(3) NOT NULL default '0',
  `skills5` int(3) NOT NULL default '0',
  `skills6` int(3) NOT NULL default '0',
  `skills7` int(3) NOT NULL default '0',
  `skills8` int(3) NOT NULL default '0',
  `time` int(20) NOT NULL default '0',
  `rank_s` int(20) NOT NULL default '0',
  `rank_t` int(20) NOT NULL default '0',
  `plot_id` int(10) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `id_in` USING BTREE (`id`),
  KEY `uid_in` USING BTREE (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_will`;
CREATE TABLE `cdb_zgxsh_assassin_will` (
  `id` int(11) NOT NULL auto_increment,
  `w_name` varchar(255) NOT NULL,
  `w_uid` int(20) NOT NULL,
  `w_qq` int(20) default NULL,
  `join_way` int(1) NOT NULL default '0',
  `grou` int(20) NOT NULL,
  `weal` int(20) NOT NULL default '0',
  `hono` int(20) NOT NULL default '0',
  `crim` int(20) NOT NULL default '0',
  `popu` int(4) NOT NULL default '5',
  `posi` varchar(255) NOT NULL,
  `buil_1` int(3) NOT NULL default '1',
  `buil_2` int(3) NOT NULL default '1',
  `buil_3` int(3) NOT NULL default '0',
  `buil_4` int(3) NOT NULL default '0',
  `buil_5` int(3) NOT NULL default '0',
  `buil_6` int(3) NOT NULL default '0',
  `buil_7` int(3) NOT NULL default '0',
  `buil_8` int(3) NOT NULL default '0',
  `sob_time` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id_in` USING BTREE (`id`),
  KEY `uid_in` USING BTREE (`w_uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_items`;
CREATE TABLE `cdb_zgxsh_assassin_items` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` int(2) NOT NULL,
  `du_k` int(3) NOT NULL,
  `du_v` int(3) NOT NULL,
  `value` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `exp_k` int(10) NOT NULL,
  `exp_v` int(10) NOT NULL,
  `hp_k` int(10) NOT NULL,
  `hp_v` int(10) NOT NULL,
  `mp_k` int(10) NOT NULL,
  `mp_v` int(10) NOT NULL,
  `np_k` int(10) NOT NULL,
  `np_v` int(10) NOT NULL,
  `load` int(10) NOT NULL,
  `attack` int(10) NOT NULL,
  `defense` int(10) NOT NULL,
  `smart` int(10) NOT NULL,
  `insight` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_map`;
CREATE TABLE `cdb_zgxsh_assassin_map` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `map_id` int(10) NOT NULL default '1',
  PRIMARY KEY  (`id`),
	KEY `map_in` USING BTREE (`uid`,`map_id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_boss`;
CREATE TABLE `cdb_zgxsh_assassin_boss` (
  `id` int(20) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `hp_k` int(20) NOT NULL,
  `hp_v` int(20) NOT NULL,
  `np_k` int(20) NOT NULL,
  `np_v` int(20) NOT NULL,
  `attack` int(20) NOT NULL,
  `defense` int(20) NOT NULL,
  `smart` int(20) NOT NULL,
  `insight` int(20) NOT NULL,
  `ext` int(20) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(20) NOT NULL,
  `kt` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_boss_user`;
CREATE TABLE `cdb_zgxsh_assassin_boss_user` (
  `uid` int(20) NOT NULL,
  `hp_k` int(20) NOT NULL,
  `hp_v` int(20) NOT NULL,
  `np_k` int(20) NOT NULL,
  `np_v` int(20) NOT NULL,
  `attack` int(20) NOT NULL,
  `defense` int(20) NOT NULL,
  `smart` int(20) NOT NULL,
  `insight` int(20) NOT NULL,
  `sh` int(20) NOT NULL,
  `mb` int(20) NOT NULL,
  `state` int(20) NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_assassin_boss_news`;
CREATE TABLE `cdb_zgxsh_assassin_boss_news` (
  `id` int(20) NOT NULL auto_increment,
  `txt` varchar(500) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

runquery($sql);
$finish = true;
?>