<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

//ϵͳ��������
$_TRC = $_G['cache']['plugin']['zgxsh_assassin'];
$_TRC["extname"] = $_G['setting']['extcredits'][$_TRC['extid']]['title'];
$_TRC["extlogo"] = $_G['setting']['extcredits'][$_TRC['extid']]['img'];
$_TRC["extunit"] = $_G['setting']['extcredits'][$_TRC['extid']]['unit'];
$_TRC["extvalue"] = getuserprofile('extcredits'.$_TRC['extid']);

if(!$_TRC['extid']){
	showmessage(co('main00'), '');	
}
//��������
$_TRC['buil_up_cost'] = explode("\n",$_TRC['buil_up_cost']);
for($i=0;$i<count($_TRC['buil_up_cost']);$i++){
  $_TRC['buil_up_cost'][$i] = explode(":",$_TRC['buil_up_cost'][$i]);
  $_TRC['buil_up_cost_setup'][$_TRC['buil_up_cost'][$i][0]] = explode(",",$_TRC['buil_up_cost'][$i][1]);
}
//������
$_TRC['stea_exp_max'] = $_TRC['stea_exp_min']>$_TRC['stea_exp_max']?$_TRC['stea_exp_min']:$_TRC['stea_exp_max'];
$_TRC['kill_exp_max'] = $_TRC['kill_exp_min']>$_TRC['kill_exp_max']?$_TRC['kill_exp_min']:$_TRC['kill_exp_max'];

//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC['p_name'];

//�����б�
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';

//�����б�
include 'data/speak.php';
include 'data/enemy.php';
include 'data/item.php';
include 'data/item_synthe.php';

//��չ��
include 'data/poor_po.php';
include 'data/sob.php';
include 'data/boss.php';

//�������
function a_works($v){  //������϶�ȡ����
	if($v==""){$r = co("works0");}
	elseif($v==1){$r = co("works1");}
	elseif($v==2){$r = co("works2");}
	elseif($v==3){$r = co("works3");}
	elseif($v==4){$r = co("works4");}
	elseif($v==5){$r = co("works5");}
	elseif($v==6){$r = co("works6");}
	elseif($v==7){$r = co("works7");}
	elseif($v==8){$r = co("works8");}
	elseif($v==9){$r = co("works9");}
	elseif($v==10){$r = co("works10");}
	elseif($v==11){$r = co("works11");}
	elseif($v==12){$r = co("works12");}
	elseif($v==13){$r = co("works13");}
	return $r;
}
function will_po($v,$id=0){  //�ֵܻ�ְ��
  if($id>0){  //��ȡ�����Զ�������
    $posi = DB::result_first("SELECT posi FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$id."'");
    $posi_a = unserialize($posi);
  }
	if($v=="" or $v==0){$r = co("willpo0");}
	elseif($v==1){$r = !$posi_a[1]?co("willpo1"):$posi_a[1];}
	elseif($v==2){$r = !$posi_a[2]?co("willpo2"):$posi_a[2];}
	elseif($v==3){$r = !$posi_a[3]?co("willpo3"):$posi_a[3];}
	elseif($v==4){$r = !$posi_a[4]?co("willpo4"):$posi_a[4];}
	elseif($v==5){$r = !$posi_a[5]?co("willpo5"):$posi_a[5];}
	elseif($v==6){$r = !$posi_a[6]?co("willpo6"):$posi_a[6];}
	elseif($v==7){$r = !$posi_a[7]?co("willpo7"):$posi_a[7];}
	return $r;
}
function will_name($id){  //�ֵܻ�����
	$name = DB::result_first("SELECT w_name FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$id."'");
	if(!$name){
		$name = " -- ";
	}
	return $name;
}
function will_f_op($id,$k,$v){  //�ֵܻ���ֲ��� �ֵܻ�id �������� ֵ
  $will_f = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$id."'");
  
  if(!$will_f['weal']){$will_f['weal'] = 0;}
  if(!$will_f['hono']){$will_f['hono'] = 0;}
  if(!$will_f['crim']){$will_f['crim'] = 0;}
  
  if($k=="weal"){  //����
    $k_name = co('main01');
  }elseif($k=="hono"){
    $k_name = co('main02');
  }elseif($k=="crim"){
    $k_name = co('main03');
  }
  
  if($will_f[$k]+$v<0 and $v<0){
		prompt(co('main04').$k_name.co('main05').abs($v));
  }
  $will_f[$k] += $v;
  
  $r = DB::update('zgxsh_assassin_will',array($k=>intval($will_f[$k])),array('id'=>$id));
    
  return $r; 
}
function map_name_q($id){
  if($id==1){
    $r = co('main06');
  }elseif($id==2){
    $r = co('main07');
  }elseif($id==3){
    $r = co('main08');
  }elseif($id==4){
    $r = co('main09');
  }elseif($id==5){
    $r = co('main10');
  }
  return $r;
}
function item_class_name($id){
  if($id==1){
    $r = co('main11');
  }elseif($id==2){
    $r = co('main12');
  }elseif($id==3){
    $r = co('main13');
  }elseif($id==4){
    $r = co('main14');
  }elseif($id==5){
    $r = co('main15');
  }elseif($id==6){
    $r = co('main16');
  }elseif($id==7){
    $r = co('main17');
  }elseif($id==8){
    $r = co('main18');
  }elseif($id==9){
    $r = co('main19');
  }elseif($id==10){
    $r = co('main20');
  }
  
  return $r;
}

function item_give($uid,$item_id,$item_cl){
  if($item_cl==11){  //���ж� ����10������
    $item_cl = rand(1,4);  //������κ�����
  }
  $time_db = item::item_add($item_id,$item_cl);
  $time_db['uid'] = $uid;
  if($time_db['name']==""){
    $r['over'] = false;
    $r['txt'] = co('main21'); 
    return $r;
  }
  //��Ʒ����
  $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
  $items_count = DB::result_first("SELECT COUNT(id) FROM ".DB::table('zgxsh_assassin_items')." WHERE uid = '".$uid."'");
  if($items_count>=$user['load']){
    $r['over'] = false;
    $r['txt'] = co('main22'); 
    return $r;
  }
  if(!DB::insert('zgxsh_assassin_items',$time_db)){
    $r['over'] = false;
    $r['txt'] = co('main23'); 
    return $r;
  }else{
    $r['over'] = true;
    $r['item'] = $time_db; 
    return $r;
  }
}

function ass_name($uid){
  $name = DB::result_first("SELECT name FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
	if(!$name){
		$name = " -- ";
	}
	return $name;
}

function map_see($uid){
  $map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$uid."'");
  $name = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
  if($name['time']>0 and !$map){
    $map_name = map_name_q($map['map_id']);
  }elseif($name['time']>0){
    $map_name = co('main24');
  }else{
    $map_name = co('main25');
  }
  return $map_name;
}

function user_exp($uid,$v){
  $name = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
	$up = array(
	  'exp_v' => $name['exp_v'] + $v,
	);
	DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
  return;
}

function map_hiding($uid){  //����
  global $_G;
  global $_TRC;
  $name = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
  $map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$uid."'");
  
  if(!$name){
    prompt(co('over01'),"forum.php",array('icon'=>2));
  }
  
  if($name['time']>0 and !$map){  //����״̬
		
		$navtitle = $_TRC['p_name'];
		
		if(floor((time()-$name['time'])/86400)>0){
			$date .= floor((time()-$name['time'])/86400).co('main98');
		}
		if(floor((time()-$name['time'])%86400/3600)>0){
			$date .= floor((time()-$name['time'])%86400/3600).co('main99');
		}
    $date .= floor((time()-$name['time'])%86400%3600/60).co('main100');
		
		$date_v = floor((time()-$name['time'])/60);
		
    $hp_hf = $name['hp_v']+$date_v>$name['hp_k']?$name['hp_k']:$name['hp_v']+$date_v;
    $mp_hf = $name['mp_v']+$date_v>$name['mp_k']?$name['mp_k']:$name['mp_v']+$date_v;
		
		$ls['z_time'] = dgmdate($_TRC['hiding_time']+time(),"u");
				
    include template('zgxsh_assassin:index/index_hiding');
    exit();
  }
}

function map_appearance(){
  $name_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE time <= '0'");
  for($i=0;$i<count($name_all);$i++){
    $map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$name_all[$i]['uid']."'");
    if(!$map){
      $ls['bh'] = rand(1,5);
      db_op::map_walk($name_all[$i]['uid'],$ls);  //����ӽ�ĳ����ͼ
      notice($name_all[$i]['uid'],$_TRC['p_name'],co('main101').map_name_q($ls['bh']));  //֪ͨ�Լ����߳���
    }
  }
}
  
//װ����
class equ {
  function add($uid,$armed,$item_id){  //����
    $up = array(
		  $armed => $item_id,
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
    return $r; 
  }
  function del($uid,$armed){  //ж��
    $up = array(
		  $armed => 0,
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
    return $r;
  }
  function i_use($uid,$item_id){
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
    $item_db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$item_id."'");
    if(!$item_db){
      prompt(co('main26'));
    }
    if($item_db['uid']!=$uid){
      prompt(co('main27'));
    }
    if($item_db['class']!=7){
      prompt(co('main28'));
    }
    //ʩչ��ƷЧ��
    $up['exp_k'] = $db_user['exp_k'] + $item_db['exp_k'];  //�̿;�������
    $up['exp_v'] = $db_user['exp_v'] + $item_db['exp_v'];  //�̿͵�ǰ����
    $up['hp_k'] = $db_user['hp_k'] + $item_db['hp_k'];  //HP����
    $up['hp_v'] = $db_user['hp_v'] + $item_db['hp_v'];  //HPָ��
    $up['mp_k'] = $db_user['mp_k'] + $item_db['mp_k'];  //MP����
    $up['mp_v'] = $db_user['mp_v'] + $item_db['mp_v'];  //MPָ��
    $up['np_k'] = $db_user['np_k'] + $item_db['np_k'];  //ŭ������
    $up['np_v'] = $db_user['np_v'] + $item_db['np_v'];  //ŭ��ָ��
    $up['load'] = $db_user['load'] + $item_db['load'];  //����
    $up['attack'] = $db_user['attack'] + $item_db['attack'];    //����
    $up['defense'] = $db_user['defense'] + $item_db['defense'];  //����
    $up['smart'] = $db_user['smart'] + $item_db['smart'];      //����
    $up['insight'] = $db_user['insight'] + $item_db['insight'];  //����
    //���
    $r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
    if($r){
      $r = DB::delete('zgxsh_assassin_items',array('id'=>$item_id),1);
    }
    return $r;
  }
}

//���ݿ������
class db_op {
	
	//��� ��ֵ intval() ���� daddslashes()
	function new_user($ls){
		global $_G;
    //���临��
    $ls['po'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE w_uid = '".$_G['uid']."'");
    if($ls['po']){
      $ls['po']['will_id'] = $ls['po']['id'];
      $ls['po']['will_po'] = 7;
    }
    
		$ins = array(
      'uid' => $_G['uid'],
      'name' => daddslashes($ls['name']),
      'works' => intval($ls['works']),
      'will_id' => $ls['po']['will_id'],
      'will_po' => $ls['po']['will_po'],
    );
    
		//��������ͼ����
		DB::delete('zgxsh_assassin_map',array('uid'=>$_G['uid']));
		
		
		$r = DB::insert('zgxsh_assassin_user',$ins);
		return $r;
  }
	
	function edit_user($ls){
		global $_G;
		$up = array(
		  'works' => intval($ls['works']),
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
		return $r;
  }
	
	function new_will($ls){
		global $_G;
		$ins = array(
      'w_uid' => $_G['uid'],
      'w_name' => daddslashes($ls['name']),
      'w_qq' => intval($ls['qq']),
      'join_way' => intval($ls['join_way']),
    );
		$r = DB::insert('zgxsh_assassin_will',$ins,1);
		$up = array(
		  'will_id' => $r,
			'will_po' => 7,
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
		return $r;
  }
	
	function join_req($ls){
		global $_G;
		if($ls['join_way']==0){
			$po = 2;
		}else{
			$po = 1;
		}
		$up = array(
      'will_id' => intval($ls['bh']),
      'will_po' => intval($po),
    );
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
		return $r;
  }
	
	function will_exit($ls){
		global $_G,$_TRC;
    
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$ls['bh']."'");
    //��������    
    if($_TRC['poor_po'] and $_TRC['poor_po_k']){  
			poor_po::del($db_user['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user['will_po']]),co("inif222"),co("inif228"));
		}
    
		$up = array(
      'will_id' => 0,
      'will_po' => 0,
    );
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$ls['bh']));
		return $r;
  }
	
	function join_model($ls){
		global $_G;
		$up = array(
      'join_way' => intval($ls['join_way']),
    );
		$r = DB::update('zgxsh_assassin_will',$up,array('id'=>$ls['bh']));
		return $r;
	}
	
	function qqs_editl($ls){
		global $_G;
		$up = array(
      'w_qq' => intval($ls['qq']),
    );
		$r = DB::update('zgxsh_assassin_will',$up,array('id'=>$ls['bh']));
		return $r;
	}
  
	function ref_yes($ls){
		global $_G;
		$up = array(
			'will_po' => 2,
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$ls['bh']));
		return $r;
  }
	
	function del_will($ls){
		global $_G,$_TRC;

		$up = array(
		  'will_id' => 0,
			'will_po' => 0,
		);
    
		DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
		$r = DB::delete("zgxsh_assassin_will",array('w_uid'=>$_G['uid']));
		return $r;
	}
  
  //���Ե����
  function attr_add($uid,$ls){
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
		if($db_user['attr_p']<1){
			return false;
		}
    $up['attr_p'] = $db_user['attr_p']-1;
		if($ls['bh']=="attack"){
      $up['attack'] = $db_user['attack']+1;
    }elseif($ls['bh']=="defense"){
      $up['defense'] = $db_user['defense']+1;
    }elseif($ls['bh']=="smart"){
      $up['smart'] = $db_user['smart']+1;
    }elseif($ls['bh']=="insight"){
      $up['insight'] = $db_user['insight']+1;
    }else{
      $up['attr_p']++;  //û���κ�����������
      return;
    }
    
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
		return $r;
	}
  
  //���ܵ����
  function user_skil_sub($ls){
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$ls['uid']."'");
    $db_user['skills1'] += intval($ls['skil_add_1']);
    $db_user['skills2'] += intval($ls['skil_add_2']);
    $db_user['skills3'] += intval($ls['skil_add_3']);
    $db_user['skills4'] += intval($ls['skil_add_4']);
    $db_user['skills5'] += intval($ls['skil_add_5']);
    $db_user['skills6'] += intval($ls['skil_add_6']);
    $db_user['skills7'] += intval($ls['skil_add_7']);
    $db_user['skills8'] += intval($ls['skil_add_8']);
    $db_user['skil_p'] -= intval($ls['sum']);
    $up = array(
      'skills1' => $db_user['skills1'],
      'skills2' => $db_user['skills2'],
      'skills3' => $db_user['skills3'],
      'skills4' => $db_user['skills4'],
      'skills5' => $db_user['skills5'],
      'skills6' => $db_user['skills6'],
      'skills7' => $db_user['skills7'],
      'skills8' => $db_user['skills8'],
      'skil_p' => $db_user['skil_p'],
    );
    $r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$ls['uid']));
		return $r;
  }
  
  //������ֵ��������
  function user_mp($uid,$v){  
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
    if($db_user['mp_v']+$v<0 and $v<0){
      prompt(co('main29'),"location='plugin.php?id=zgxsh_assassin:index'");
    }
    $db_user['mp_v'] += $v;
    $up = array(
			'mp_v' => intval($db_user['mp_v']),
		);
		$r = DB::update('zgxsh_assassin_user',$up,array('uid'=>$uid));
		return $r;
  }
  
  //��ͼ����
  function map_db($uid){  //��ͼ�ڿ��ѯ
    $db_map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$uid."'");
    if(!$db_map){
      $ins = array(
        'uid' => $uid,  //��ͼ�˻�UID
      );
      DB::insert('zgxsh_assassin_map',$ins);
      $db_map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$uid."'");
    }
    will_name($id);
    return $db_map;
  }
  function map_walk($uid,$ls){
    $db_map = self::map_db($uid);
    $up = array(
      'map_id' => intval($ls['bh']),
    );
    $r = DB::update('zgxsh_assassin_map',$up,array('uid'=>$uid));
    return $r;
  }
  
  //ս���浵-һ���˳�ǰʹ��
  function fighting_save($db_user1,$db_user2,$npc,$death){
    
    $up1 = array(
      'exp_v' => intval($db_user1['exp_v']),
      'hp_v' => intval($db_user1['hp_v']),
      'mp_v' => intval($db_user1['mp_v']),
      'np_v' => intval($db_user1['np_v']),
      'armed_head' => intval($db_user1['armed_head']),
      'armed_body' => intval($db_user1['armed_body']),
      'armed_foot' => intval($db_user1['armed_foot']),
      'armed_weapons' => intval($db_user1['armed_weapons']),
      'armed_crossbow' => intval($db_user1['armed_crossbow']),
      'armed_special' => intval($db_user1['armed_special']),
    );
    $up2 = array(
      'exp_v' => intval($db_user2['exp_v']),
      'hp_v' => intval($db_user2['hp_v']),
      'mp_v' => intval($db_user2['mp_v']),
      'np_v' => intval($db_user2['np_v']),
      'armed_head' => intval($db_user2['armed_head']),
      'armed_body' => intval($db_user2['armed_body']),
      'armed_foot' => intval($db_user2['armed_foot']),
      'armed_weapons' => intval($db_user2['armed_weapons']),
      'armed_crossbow' => intval($db_user2['armed_crossbow']),
      'armed_special' => intval($db_user2['armed_special']),
    );
    DB::update('zgxsh_assassin_user',$up1,array('uid'=>$db_user1['uid']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_head_db'],array('id'=>$db_user1['armed_head_db']['id']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_body_db'],array('id'=>$db_user1['armed_body_db']['id']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_foot_db'],array('id'=>$db_user1['armed_foot_db']['id']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_weapons_db'],array('id'=>$db_user1['armed_weapons_db']['id']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_crossbow_db'],array('id'=>$db_user1['armed_crossbow_db']['id']));
    DB::update('zgxsh_assassin_items',$db_user1['armed_special_db'],array('id'=>$db_user1['armed_special_db']['id']));
    
    if(!$npc){
      DB::update('zgxsh_assassin_user',$up2,array('uid'=>$db_user2['uid']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_head_db'],array('id'=>$db_user2['armed_head_db']['id']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_body_db'],array('id'=>$db_user2['armed_body_db']['id']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_foot_db'],array('id'=>$db_user2['armed_foot_db']['id']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_weapons_db'],array('id'=>$db_user2['armed_weapons_db']['id']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_crossbow_db'],array('id'=>$db_user2['armed_crossbow_db']['id']));
      DB::update('zgxsh_assassin_items',$db_user2['armed_special_db'],array('id'=>$db_user2['armed_special_db']['id']));
    }
   
    if($db_user1['armed_head_db']['du_v'] <= 0 and $db_user1['armed_head_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_head_db']['id']),1);
    }
    if($db_user1['armed_body_db']['du_v'] <= 0 and $db_user1['armed_body_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_body_db']['id']),1);
    }
    if($db_user1['armed_foot_db']['du_v'] <= 0 and $db_user1['armed_foot_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_foot_db']['id']),1);
    }
    if($db_user1['armed_weapons_db']['du_v'] <= 0 and $db_user1['armed_weapons_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_weapons_db']['id']),1);
    }
    if($db_user1['armed_crossbow_db']['du_v'] <= 0 and $db_user1['armed_crossbow_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_crossbow_db']['id']),1);
    }
    if($db_user1['armed_special_db']['du_v'] <= 0 and $db_user1['armed_special_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user1['armed_special_db']['id']),1);
    }
    if(!$npc){
    if($db_user2['armed_head_db']['du_v'] <= 0 and $db_user2['armed_head_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_head_db']['id']),1);
    }
    if($db_user2['armed_body_db']['du_v'] <= 0 and $db_user2['armed_body_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_body_db']['id']),1);
    }
    if($db_user2['armed_foot_db']['du_v'] <= 0 and $db_user2['armed_foot_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_foot_db']['id']),1);
    }
    if($db_user2['armed_weapons_db']['du_v'] <= 0 and $db_user2['armed_weapons_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_weapons_db']['id']),1);
    }
    if($db_user2['armed_crossbow_db']['du_v'] <= 0 and $db_user2['armed_crossbow_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_crossbow_db']['id']),1);
    }
    if($db_user2['armed_special_db']['du_v'] <= 0 and $db_user2['armed_special_db']['id']>0){
      DB::delete('zgxsh_assassin_items',array('id'=>$db_user2['armed_special_db']['id']),1);
    }
    }
    return true;
  }
  //ս������
  function fighting($uid_1p,$uid_2p,$npc=0,$death=0){  //1p 2p pve ����
    //����˫��������
    $db_user[1] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid_1p."'");
    $db_user[1]['armed_head_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_head']."'");
    $db_user[1]['armed_body_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_body']."'");
    $db_user[1]['armed_foot_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_foot']."'");
    $db_user[1]['armed_weapons_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_weapons']."'"); 
    $db_user[1]['armed_crossbow_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_crossbow']."'");  
    $db_user[1]['armed_special_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[1]['armed_special']."'"); 
    //����ADD����
    $db_user[1]['attack_add'] = $db_user[1]['attack'] + $db_user[1]['armed_head_db']['attack'] + $db_user[1]['armed_body_db']['attack'] + $db_user[1]['armed_foot_db']['attack'] + $db_user[1]['armed_weapons_db']['attack'] + $db_user[1]['armed_special_db']['attack'];
    $db_user[1]['defense_add'] = $db_user[1]['defense'] + $db_user[1]['armed_head_db']['defense'] + $db_user[1]['armed_body_db']['defense'] + $db_user[1]['armed_foot_db']['defense'] + $db_user[1]['armed_weapons_db']['defense'] + $db_user[1]['armed_special_db']['defense'];
    $db_user[1]['smart_add'] = $db_user[1]['smart'] + $db_user[1]['armed_head_db']['smart'] + $db_user[1]['armed_body_db']['smart'] + $db_user[1]['armed_foot_db']['smart'] + $db_user[1]['armed_weapons_db']['smart'] + $db_user[1]['armed_special_db']['smart'];
    $db_user[1]['insight_add'] = $db_user[1]['insight'] + $db_user[1]['armed_head_db']['insight'] + $db_user[1]['armed_body_db']['insight'] + $db_user[1]['armed_foot_db']['insight'] + $db_user[1]['armed_weapons_db']['insight'] + $db_user[1]['armed_special_db']['insight'];
    if($npc){  //�Ƿ�Ϊ�˻���ս
      $db_user[2] = enemy::build_enemy($uid_2p);  //����NPC����
    }else{
      $db_user[2] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid_2p."'");
      $db_user[2]['armed_head_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_head']."'");
      $db_user[2]['armed_body_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_body']."'");
      $db_user[2]['armed_foot_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_foot']."'");
      $db_user[2]['armed_weapons_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_weapons']."'"); 
      $db_user[2]['armed_crossbow_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_crossbow']."'");  
      $db_user[2]['armed_special_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user[2]['armed_special']."'"); 
    }
    //����ADD����
    $db_user[2]['attack_add'] = $db_user[2]['attack'] + $db_user[2]['armed_head_db']['attack'] + $db_user[2]['armed_body_db']['attack'] + $db_user[2]['armed_foot_db']['attack'] + $db_user[2]['armed_weapons_db']['attack'] + $db_user[2]['armed_special_db']['attack'];
    $db_user[2]['defense_add'] = $db_user[2]['defense'] + $db_user[2]['armed_head_db']['defense'] + $db_user[2]['armed_body_db']['defense'] + $db_user[2]['armed_foot_db']['defense'] + $db_user[2]['armed_weapons_db']['defense'] + $db_user[2]['armed_special_db']['defense'];
    $db_user[2]['smart_add'] = $db_user[2]['smart'] + $db_user[2]['armed_head_db']['smart'] + $db_user[2]['armed_body_db']['smart'] + $db_user[2]['armed_foot_db']['smart'] + $db_user[2]['armed_weapons_db']['smart'] + $db_user[2]['armed_special_db']['smart'];
    $db_user[2]['insight_add'] = $db_user[2]['insight'] + $db_user[2]['armed_head_db']['insight'] + $db_user[2]['armed_body_db']['insight'] + $db_user[2]['armed_foot_db']['insight'] + $db_user[2]['armed_weapons_db']['insight'] + $db_user[2]['armed_special_db']['insight'];
        
    //ս����ʼ
    $ls['s1'] = rand(1,2);
    $ls['s2'] = $ls['s1']==1?2:1;
    $txt[$ls['s1']] .= co('main30').$db_user[$ls['s2']]['name']."<br>";
    $txt[$ls['s2']] .= co('main30').$db_user[$ls['s1']]['name']."<br>";
    
    for($i=1;true;$i++){
    //��ʱ��������
    $ls['damage'] = 0;  //�˺�
    $ls['acc'] = 0;  //����
    $ls['doable'] = 0;  //����
    $ls['escape'] = 0;  //���봥��
    $ls['escape_chance'] = 0;  //�������
    $ls['saves'] = 0;  //����
      
    //�����ж�
    $ls['s1'] = rand(1,2);
    $ls['s2'] = $ls['s1']==1?2:1;
      
    //�غϿ�ʼ
    $txt[$ls['s1']] .= co('main31').$i.co('main32');
    $txt[$ls['s2']] .= co('main31').$i.co('main32');
    
    $txt[$ls['s1']] .= co('main34');
    $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main35');
    //Ѫ������10%���������ж�
    if($db_user[$ls['s1']]['hp_v']<floor($db_user[$ls['s1']]['hp_k']/10)){  
      if(rand(0,100)<30){  //30%��������
        $ls['escape'] = true;  
        $txt[$ls['s1']] .= co('main36');
        $txt[$ls['s2']] .= co('main37');
      }
    }
    if($ls['escape']){  //�������
      $ls['escape'] = 0;
      $ls['escape_chance'] = rand(0,50); //�������
      if($db_user[$ls['s1']]['np_v']>=$db_user[$ls['s1']]['np_k'] and $db_user[$ls['s1']]['skills4']>0){  //����ŭ���� ����
        $ls['escape_chance'] += $db_user[$ls['s1']]['skills4'];  //�ͷ����ټ���
        $txt[$ls['s1']] .= co('main38').$db_user[$ls['s1']]['skills4']."%] ".co('main39');
        $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main40').$db_user[$ls['s1']]['skills4']."%] ".co('main41');
        //�������ŭ��
        $db_user[$ls['s1']]['np_v'] = 0;
      }
      if($db_user[$ls['s2']]['np_v']>=$db_user[$ls['s2']]['np_k'] and $db_user[$ls['s2']]['skills5']>0){  //����ŭ���� ׷��
        $ls['escape_chance'] -= $db_user[$ls['s2']]['skills5'];  //�ͷ�׷������
        $txt[$ls['s1']] .= co('main42').$db_user[$ls['s2']]['name'].co('main43').$db_user[$ls['s2']]['skills5']."%] ".co('main44');
        $txt[$ls['s2']] .= co('main45').$db_user[$ls['s2']]['skills5']."%] ".co('main46').$db_user[$ls['s1']]['name']."<br>";
        //��պ���ŭ��
        $db_user[$ls['s1']]['np_v'] = 0;
      }
      if(rand(0,100)<$ls['escape_chance']){  //��������
        $ls['saves'] = self::fighting_save($db_user[1],$db_user[2],$npc,$death);
        
        if($ls['saves']){
          $txt[$ls['s1']] .= co('main47').$db_user[$ls['s2']]['name'].co('main48');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main49');
        }else{
          $txt[$ls['s1']] .= co('main50');
          $txt[$ls['s2']] .= co('main50');
        }
        
        if($ls['s1']==1){  //�ж���ǰ������Ǹ�
          $r['txt'] = $txt[$ls['s1']];
          if(!$npc){
            notice($db_user[$ls['s2']]['uid'],co('main51'),$txt[$ls['s2']]);
          }
          $r['over'] = 'escape1';  //��� �Լ�����
        }else{
          $r['txt'] = $txt[$ls['s2']];
          if(!$npc){
            notice($db_user[$ls['s1']]['uid'],co('main51'),$txt[$ls['s1']]);
          }
          $r['over'] = 'escape2';  //��� �Է�����
        }
        
        return $r;  //��������
      }else{  //����ʧ��
        $txt[$ls['s1']] .= co('main52').$db_user[$ls['s2']]['name'].co('main53');
        $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main54');
      }
    }
    else{  //û������
      //�佣��ɱ
      if($db_user[$ls['s1']]['armed_crossbow']>0 and $db_user[$ls['s1']]['armed_crossbow_db']['du_v']>0 and rand(0,300)<5+$db_user[$ls['s1']]['lv']+$db_user[$ls['s1']]['skills8']){  //������� 5%+�ȼ�+ӥ�� ���ʴ������
        if($db_user[$ls['s1']]['np_v']>=$db_user[$ls['s1']]['np_k'] and $db_user[$ls['s1']]['skills8']>0){  //������ŭ�� ӥ��
          $ls['damage'] = $db_user[$ls['s1']]['armed_crossbow_db']['attack']*$db_user[$ls['s1']]['skills8'];  //��ɱ����˺�
          $txt[$ls['s1']] .= co('main55').$db_user[$ls['s1']]['skills8']."] ".co('main56');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main57').$db_user[$ls['s1']]['skills8']."] ".co('main56');
          //�������ŭ��
          $db_user[$ls['s1']]['np_v'] = 0;
        }else{  //��ͨ���
          $ls['damage'] = $db_user[$ls['s1']]['armed_crossbow_db']['attack'];  //��ͨ���
          $txt[$ls['s1']] .= co('main58');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main59');
        }
        //��������;�
        $db_user[$ls['s1']]['armed_crossbow_db']['du_v'] -= rand(1,$ls['damage']);
        if($db_user[$ls['s1']]['armed_crossbow_db']['du_v']<=0){  //����Ϊ����
          $db_user[$ls['s1']]['armed_crossbow_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main61')." [".$db_user[$ls['s1']]['armed_crossbow_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main62')." [".$db_user[$ls['s1']]['armed_crossbow_db']['name']."] ".co('main60');
        }
      }
      //��ͨ����
      else{  
        $ls['damage'] = ceil(($db_user[$ls['s1']]['attack_add']*$db_user[$ls['s1']]['attack_add'])/($db_user[$ls['s1']]['attack_add'] + $db_user[$ls['s2']]['defense_add']*2));
        $txt[$ls['s1']] .= co('main65').$db_user[$ls['s2']]['name'].co('main66');
        $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main67');
        //����������������Ʒ�;�
        $db_user[$ls['s1']]['armed_weapons_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s1']]['armed_special_db']['du_v'] -= rand(1,10);
        if($db_user[$ls['s1']]['armed_weapons_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_weapons']>0){  //������
          $db_user[$ls['s1']]['armed_weapons_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_weapons_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_weapons_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_weapons_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_weapons_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_weapons_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_weapons_db']['insight'];
          $db_user[$ls['s1']]['armed_weapons'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s1']]['armed_special_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_special']>0){  //��Ʒ��
          $db_user[$ls['s1']]['armed_special_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_special_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_special_db']['name']."] ".co('main60');
          //��ȥ��Ʒ����
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_special_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_special_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_special_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_special_db']['insight'];
          $db_user[$ls['s1']]['armed_special'] = 0;  //ж��װ��
        }
      }
      //�����ж�
      $ls['acc'] = 60+$db_user[$ls['s1']]['insight']-$db_user[$ls['s2']]['smart'];  //��������60 + �Լ����� - ��������
      if(rand(0,100)<$ls['acc']){  //����
        //�����ж�
        $ls['double'] = 10+$db_user[$ls['s1']]['insight']-$db_user[$ls['s2']]['insight'];  //�������10 + �Լ����� - ���ֶ���
        if(rand(0,100)<$ls['double']){  //����
          $ls['damage'] *= 2;
          $txt[$ls['s1']] .= co('main68');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main68');
        }
        $txt[$ls['s1']] .= co('main69')." [".$ls['damage']."] ".co('main70');
        $txt[$ls['s2']] .= co('main71').$ls['damage']."<br>";
        //���Ӿ���
        if($db_user[$ls['s1']]['lv']<=$db_user[$ls['s2']]['lv']){
          $ls['exp'] = rand(1,$db_user[$ls['s2']]['lv']);
          $db_user[$ls['s1']]['exp_v'] += $ls['exp'];
          $txt[$ls['s1']] .= co('main72')." [".$ls['exp']."] ".co('dian')."!<br>";
        }
        //����HP
        $db_user[$ls['s2']]['hp_v'] -= $ls['damage'];
        if($db_user[$ls['s2']]['hp_v']<0){  //��ֹΪ����
          $db_user[$ls['s2']]['hp_v'] = 0;
        }
        //���Ӻ���ŭ��
        $db_user[$ls['s2']]['np_v'] += $ls['damage'];
        if($db_user[$ls['s2']]['np_v']>$db_user[$ls['s2']]['np_k']){  //��ֹŭ����������
          $db_user[$ls['s2']]['np_v'] = $db_user[$ls['s2']]['np_k'];
        }
        //���ٺ���ͷ����������Ʒ�;�
        $db_user[$ls['s2']]['armed_head_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s2']]['armed_body_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s2']]['armed_foot_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s2']]['armed_special_db']['du_v'] -= rand(1,10);
        //�𻵺�����
        if($db_user[$ls['s1']]['armed_head_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_head']>0){  //ͷ��
          $db_user[$ls['s1']]['armed_head_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_head_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_head_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_head_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_head_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_head_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_head_db']['insight'];
          $db_user[$ls['s1']]['armed_head'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s1']]['armed_body_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_body']>0){  //����
          $db_user[$ls['s1']]['armed_body_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_body_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_body_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_body_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_body_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_body_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_body_db']['insight'];
          $db_user[$ls['s1']]['armed_body'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s1']]['armed_foot_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_foot']>0){  //����
          $db_user[$ls['s1']]['armed_foot_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_foot_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_foot_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_foot_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_foot_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_foot_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_foot_db']['insight'];
          $db_user[$ls['s1']]['armed_foot'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s1']]['armed_special_db']['du_v']<=0 and $db_user[$ls['s1']]['armed_special']>0){  //��Ʒ��
          $db_user[$ls['s1']]['armed_special_db']['du_v'] = 0;
          $txt[$ls['s1']] .= co('main63')." [".$db_user[$ls['s1']]['armed_special_db']['name']."] ".co('main60');
          $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main64')." [".$db_user[$ls['s1']]['armed_special_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s1']]['attack_add'] -= $db_user[$ls['s1']]['armed_special_db']['attack'];
          $db_user[$ls['s1']]['defense_add'] -= $db_user[$ls['s1']]['armed_special_db']['defense'];
          $db_user[$ls['s1']]['smart_add'] -= $db_user[$ls['s1']]['armed_special_db']['smart'];
          $db_user[$ls['s1']]['insight_add'] -= $db_user[$ls['s1']]['armed_special_db']['insight'];
          $db_user[$ls['s1']]['armed_special'] = 0;  //ж��װ��
        }
      }
      else{  //��ƫ
        $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main73');
        $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main74');
      }
    }
      
    if($db_user[$ls['s2']]['hp_v']<=0){  //����
      if(!$death or $db_user[$ls['s2']]['lv']<$db_user[$ls['s1']]['lv']){  //������ģʽ��ָ�Ϊ1��Ѫ
        $db_user[$ls['s2']]['hp_v'] = 1;
      }
      $ls['saves'] = self::fighting_save($db_user[1],$db_user[2],$npc,$death);
      if($ls['saves']){
        $txt[$ls['s1']] .= co('main75').$db_user[$ls['s2']]['name']."<br>";
        $txt[$ls['s2']] .= co('main76').$db_user[$ls['s1']]['name']."����<br>";
      }else{
        $txt[$ls['s1']] .= co('main50');
        $txt[$ls['s2']] .= co('main50');
      }
      $txt[$ls['s1']] .= co('main31').$i.co('main33');
      $txt[$ls['s2']] .= co('main31').$i.co('main33');
      $txt[$ls['s1']] .= "<br>";
      $txt[$ls['s2']] .= "<br>";
      if($ls['s1']==1){  //�ж���ǰ������Ǹ�
        //���˵ȼ������ҷ�
        if($db_user[$ls['s2']]['lv']>=$db_user[$ls['s1']]['lv']){
          if(!$npc){
            //�Է����ݽ����ӳ�
            if($db_user[$ls['s2']]['will_po']==7){  
              $will_po_jia = 10;  //����
            }elseif($db_user[$ls['s2']]['will_po']==6){
              $will_po_jia = 6;  //��ʦ
            }elseif($db_user[$ls['s2']]['will_po']==5){
              $will_po_jia = 2;  //�ų�
            }else{
              $will_po_jia = 1;  //����
            }
            //���ַ�npc�ֵܻ�������
            will_f_op($db_user[$ls['s1']]['will_id'],'hono',($db_user[$ls['s2']]['lv']*$will_po_jia));
            $txt[$ls['s1']] .= co('main78')." [".$db_user[$ls['s2']]['lv']*$will_po_jia."]<br>";
          }else{
            //������npc�ֵܻ��òƸ�
            will_f_op($db_user[$ls['s1']]['will_id'],'weal',$db_user[$ls['s2']]['lv']);
            $txt[$ls['s1']] .= co('main79')." [".$db_user[$ls['s2']]['lv']."]<br>";
          }
        }
        $r['txt'] = $txt[$ls['s1']];
        if(!$npc){
          notice($db_user[$ls['s2']]['uid'],co('main51'),$txt[$ls['s2']]);
        }
        $r['over'] = 'death2';  //��� �Է�����
      }
      else{   
        $r['txt'] = $txt[$ls['s2']];
        if(!$npc){
          notice($db_user[$ls['s1']]['uid'],co('main51'),$txt[$ls['s1']]);
        }
        $r['over'] = 'death1';  //��� �Լ�����
      }
      
      return $r;
    }
    
    $txt[$ls['s1']] .= co('main80');
    $txt[$ls['s2']] .= co('main80');
    
    $txt[$ls['s2']] .= co('main81');
    $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main82');
    //Ѫ������10%���������ж�
    if($db_user[$ls['s2']]['hp_v']<floor($db_user[$ls['s2']]['hp_k']/10)){  
      if(rand(0,100)<30){  //30%��������
        $ls['escape'] = true;  
        $txt[$ls['s2']] .= co('main36');
        $txt[$ls['s1']] .= co('main37');
      }
    }
    if($ls['escape']){  //�������
      $ls['escape'] = 0;
      $ls['escape_chance'] = rand(0,50); //�������
      if($db_user[$ls['s2']]['np_v']>=$db_user[$ls['s2']]['np_k'] and $db_user[$ls['s2']]['skills4']>0){  //����ŭ���� ����
        $ls['escape_chance'] += $db_user[$ls['s2']]['skills4'];  //�ͷ����ټ���
        $txt[$ls['s2']] .= co('main38').$db_user[$ls['s2']]['skills4']."%] ".co('main39');
        $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main40').$db_user[$ls['s2']]['skills4']."%] ".co('main41');
        //�������ŭ��
        $db_user[$ls['s2']]['np_v'] = 0;
      }
      if($db_user[$ls['s1']]['np_v']>=$db_user[$ls['s1']]['np_k'] and $db_user[$ls['s1']]['skills5']>0){  //����ŭ���� ׷��
        $ls['escape_chance'] -= $db_user[$ls['s1']]['skills5'];  //�ͷ�׷������
        $txt[$ls['s2']] .= co('main42').$db_user[$ls['s1']]['name'].co('main43').$db_user[$ls['s1']]['skills5']."%] ".co('main44');
        $txt[$ls['s1']] .= co('main45').$db_user[$ls['s1']]['skills5']."%] ".co('main46').$db_user[$ls['s2']]['name']."<br>";
        //��պ���ŭ��
        $db_user[$ls['s2']]['np_v'] = 0;
      }
      if(rand(0,100)<$ls['escape_chance']){  //��������
        $ls['saves'] = self::fighting_save($db_user[1],$db_user[2],$npc,$death);
        if($ls['saves']){
          $txt[$ls['s2']] .= co('main47').$db_user[$ls['s1']]['name'].co('main48');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main49');
        }else{
          $txt[$ls['s2']] .= co('main50');
          $txt[$ls['s1']] .= co('main50');
        }

        if($ls['s2']==1){  //�ж���ǰ������Ǹ�
          $r['txt'] = $txt[$ls['s2']];
          if(!$npc){
            notice($db_user[$ls['s2']]['uid'],co('main51'),$txt[$ls['s2']]);
          }
          $r['over'] = 'escape1';  //��� �Լ�����
        }else{
          $r['txt'] = $txt[$ls['s1']];
          if(!$npc){
            notice($db_user[$ls['s1']]['uid'],co('main51'),$txt[$ls['s1']]);
          }
          $r['over'] = 'escape2';  //��� �Է�����
        }
        return $r;
      }else{  //����ʧ��
        $txt[$ls['s2']] .= co('main52').$db_user[$ls['s1']]['name'].co('main53');
        $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main54');
      }
    }
    else{  //û������
      //�佣��ɱ
      if($db_user[$ls['s2']]['armed_crossbow']>0 and $db_user[$ls['s2']]['armed_crossbow_db']['du_v']>0 and rand(0,300)<5+$db_user[$ls['s2']]['lv']+$db_user[$ls['s2']]['skills8']){  //������� 5%+�ȼ�+ӥ�� ���ʴ������
        if($db_user[$ls['s2']]['np_v']>=$db_user[$ls['s2']]['np_k'] and $db_user[$ls['s2']]['skills8']>0){  //������ŭ�� ӥ��
          $ls['damage'] = $db_user[$ls['s2']]['armed_crossbow_db']['attack']*$db_user[$ls['s2']]['skills8'];  //��ɱ����˺�
          $txt[$ls['s2']] .= co('main55').$db_user[$ls['s2']]['skills8']."] ".co('main56');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main57').$db_user[$ls['s2']]['skills8']."] ".co('main56');
          //�������ŭ��
          $db_user[$ls['s2']]['np_v'] = 0;
        }else{  //��ͨ���
          $ls['damage'] = $db_user[$ls['s2']]['armed_crossbow_db']['attack'];  //��ͨ���
          $txt[$ls['s2']] .= co('main58');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main59');
        }
        //��������;�
        $db_user[$ls['s2']]['armed_crossbow_db']['du_v'] -= rand(1,$ls['damage']);
        if($db_user[$ls['s2']]['armed_crossbow_db']['du_v']<=0){  //����Ϊ����
          $db_user[$ls['s2']]['armed_crossbow_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main61')." [".$db_user[$ls['s2']]['armed_crossbow_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main62')." [".$db_user[$ls['s2']]['armed_crossbow_db']['name']."] ".co('main60');
        }
      }
      //��ͨ����
      else{  
        $ls['damage'] = ceil(($db_user[$ls['s2']]['attack_add']*$db_user[$ls['s2']]['attack_add'])/($db_user[$ls['s2']]['attack_add'] + $db_user[$ls['s1']]['defense_add']*2));
        $txt[$ls['s2']] .= co('main65').$db_user[$ls['s1']]['name'].co('main66');
        $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main67');
        //����������������Ʒ�;�
        $db_user[$ls['s2']]['armed_weapons_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s2']]['armed_special_db']['du_v'] -= rand(1,10);
        if($db_user[$ls['s2']]['armed_weapons_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_weapons']>0){  //������
          $db_user[$ls['s2']]['armed_weapons_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_weapons_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_weapons_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_weapons_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_weapons_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_weapons_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_weapons_db']['insight'];
          $db_user[$ls['s2']]['armed_weapons'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s2']]['armed_special_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_special']>0){  //��Ʒ��
          $db_user[$ls['s2']]['armed_special_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_special_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_special_db']['name']."] ".co('main60');
          //��ȥ��Ʒ����
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_special_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_special_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_special_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_special_db']['insight'];
          $db_user[$ls['s2']]['armed_special'] = 0;  //ж��װ��
        }
      }
      //�����ж�
      $ls['acc'] = 60+$db_user[$ls['s2']]['insight']-$db_user[$ls['s1']]['smart'];  //��������60 + �Լ����� - ��������
      if(rand(0,100)<$ls['acc']){  //����
        //�����ж�
        $ls['double'] = 10+$db_user[$ls['s2']]['insight']-$db_user[$ls['s1']]['insight'];  //�������10 + �Լ����� - ���ֶ���
        if(rand(0,100)<$ls['double']){  //����
          $ls['damage'] *= 2;
          $txt[$ls['s2']] .= co('main68');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main68');
        }
        $txt[$ls['s2']] .= co('main69')." [".$ls['damage']."] ".co('dian')."!<br>";
        $txt[$ls['s1']] .= co('main71').$ls['damage']."<br>";
        //���Ӿ���
        if($db_user[$ls['s2']]['lv']<=$db_user[$ls['s1']]['lv']){
          $ls['exp'] = rand(1,$db_user[$ls['s1']]['lv']);
          $db_user[$ls['s2']]['exp_v'] += $ls['exp'];
          $txt[$ls['s2']] .= co('main72')." [".$ls['exp']."] ".co('dian')."!<br>";
        }
        //����HP
        $db_user[$ls['s1']]['hp_v'] -= $ls['damage'];
        if($db_user[$ls['s1']]['hp_v']<0){  //��ֹΪ����
          $db_user[$ls['s1']]['hp_v'] = 0;
        }
        //���Ӻ���ŭ��
        $db_user[$ls['s1']]['np_v'] += $ls['damage'];
        if($db_user[$ls['s1']]['np_v']>$db_user[$ls['s1']]['np_k']){  //��ֹŭ����������
          $db_user[$ls['s1']]['np_v'] = $db_user[$ls['s1']]['np_k'];
        }
        //���ٺ���ͷ����������Ʒ�;�
        $db_user[$ls['s1']]['armed_head_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s1']]['armed_body_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s1']]['armed_foot_db']['du_v'] -= rand(1,10);
        $db_user[$ls['s1']]['armed_special_db']['du_v'] -= rand(1,10);
        //�𻵺�����
        if($db_user[$ls['s2']]['armed_head_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_head']>0){  //ͷ��
          $db_user[$ls['s2']]['armed_head_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_head_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_head_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_head_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_head_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_head_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_head_db']['insight'];
          $db_user[$ls['s2']]['armed_head'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s2']]['armed_body_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_body']>0){  //����
          $db_user[$ls['s2']]['armed_body_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_body_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_body_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_body_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_body_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_body_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_body_db']['insight'];
          $db_user[$ls['s2']]['armed_body'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s2']]['armed_foot_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_foot']>0){  //����
          $db_user[$ls['s2']]['armed_foot_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_foot_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_foot_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_foot_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_foot_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_foot_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_foot_db']['insight'];
          $db_user[$ls['s2']]['armed_foot'] = 0;  //ж��װ��
        }
        if($db_user[$ls['s2']]['armed_special_db']['du_v']<=0 and $db_user[$ls['s2']]['armed_special']>0){  //��Ʒ��
          $db_user[$ls['s2']]['armed_special_db']['du_v'] = 0;
          $txt[$ls['s2']] .= co('main63')." [".$db_user[$ls['s2']]['armed_special_db']['name']."] ".co('main60');
          $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main64')." [".$db_user[$ls['s2']]['armed_special_db']['name']."] ".co('main60');
          //��ȥ��������
          $db_user[$ls['s2']]['attack_add'] -= $db_user[$ls['s2']]['armed_special_db']['attack'];
          $db_user[$ls['s2']]['defense_add'] -= $db_user[$ls['s2']]['armed_special_db']['defense'];
          $db_user[$ls['s2']]['smart_add'] -= $db_user[$ls['s2']]['armed_special_db']['smart'];
          $db_user[$ls['s2']]['insight_add'] -= $db_user[$ls['s2']]['armed_special_db']['insight'];
          $db_user[$ls['s2']]['armed_special'] = 0;  //ж��װ��
        }
      }
      else{  //��ƫ
        $txt[$ls['s2']] .= $db_user[$ls['s1']]['name'].co('main73');
        $txt[$ls['s1']] .= $db_user[$ls['s2']]['name'].co('main74');
      }
    }
    if($db_user[$ls['s1']]['hp_v']<=0){  //����
      if(!$death or $db_user[$ls['s1']]['lv']<$db_user[$ls['s2']]['lv']){  //������ģʽ��ָ�Ϊ1��Ѫ
        $db_user[$ls['s1']]['hp_v'] = 1;
      }
      $ls['saves'] = self::fighting_save($db_user[1],$db_user[2],$npc,$death);
      if($ls['saves']){
        $txt[$ls['s2']] .= co('main75').$db_user[$ls['s1']]['name']."<br>";
        $txt[$ls['s1']] .= co('main76').$db_user[$ls['s2']]['name']."����<br>";
      }else{
        $txt[$ls['s2']] .= co('main50');
        $txt[$ls['s1']] .= co('main50');
      }
      $txt[$ls['s1']] .= co('main31').$i.co('main33');
      $txt[$ls['s2']] .= co('main31').$i.co('main33');
      $txt[$ls['s1']] .= "<br>";
      $txt[$ls['s2']] .= "<br>";
      if($ls['s2']==1){  //�ж���ǰ������Ǹ�
        //���˵ȼ������ҷ�
        if($db_user[$ls['s1']]['lv']>=$db_user[$ls['s2']]['lv']){
          if(!$npc){
            //�Է����ݽ����ӳ�
            if($db_user[$ls['s1']]['will_po']==7){  
              $will_po_jia = 10;  //����
            }elseif($db_user[$ls['s1']]['will_po']==6){
              $will_po_jia = 6;  //��ʦ
            }elseif($db_user[$ls['s1']]['will_po']==5){
              $will_po_jia = 2;  //�ų�
            }else{
              $will_po_jia = 1;  //����
            }
            //���ַ�npc�ֵܻ�������
            will_f_op($db_user[$ls['s2']]['will_id'],'hono',$db_user[$ls['s1']]['lv']*$will_po_jia);
            $txt[$ls['s2']] .= co('main78')." [".$db_user[$ls['s1']]['lv']*$will_po_jia."]<br>";
          }else{
            //������npc�ֵܻ��òƸ�
            will_f_op($db_user[$ls['s2']]['will_id'],'weal',$db_user[$ls['s1']]['lv']*$will_po_jia);
            $txt[$ls['s2']] .= co('main79')." [".$db_user[$ls['s1']]['lv']."]<br>";
          }
        }
        $r['txt'] = $txt[$ls['s2']];
        if(!$npc){
          notice($db_user[$ls['s1']]['uid'],co('main51'),$txt[$ls['s1']]);
        }
        $r['over'] = 'death2';  //��� �Է�����
      }else{
        $r['txt'] = $txt[$ls['s1']];
        if(!$npc){
          notice($db_user[$ls['s2']]['uid'],co('main51'),$txt[$ls['s2']]);
        }
        $r['over'] = 'death1';  //��� �Լ�����
      }
      
      return $r;  //��������
    }
      
    }
  }
  
  //���亯��
  function open_ches($uid,$ches,$item_id=0,$item_cl=0){  //������� �����Ѷ�
    $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$uid."'");
    $txt .= co('main83');
    //�������
    $ches_true = $db_user['insight']-$ches;
    $txt .= co('main84')." [".($ches_true+$ches)."] ".co('main85')." [".$ches_true."]<br>";
    //�������ļ���
    if($db_user['skills6']>0 and $db_user['np_v']>=$db_user['np_k']){  
      $ches_true += $db_user['skills6'];
      $db_user['np_v'] = 0;
      $txt .= co('main86')." [".$ches_true."%] (+".$db_user['skills6'].") <br>";
    }else{
      $db_user['np_v'] += rand(1,$ches);  //û�д�������������ŭ��
      if($db_user['np_v'] > $db_user['np_k']){  //��ֹŭ����������
        $db_user['np_v'] = $db_user['np_k'];
      }
      $txt .= co('main87')." [".$db_user['np_v']."] ".co('dian')."<br>";
    }
    //�Ƿ�ɹ�����
    if(rand(1,$ches) < $ches_true){
      //�����Ʒ����
      $txt .= co('main88');
      $r['over'] = true;
      //�б������Ǳ���
      if($item_id>0 and $item_cl>0){  //�б���
        
        $item_give_true = item_give($uid,$item_id,$item_cl);
        if(!$item_give_true['over']){
          $txt .= co('main89').$item_give_true['txt']."!<br>";
        }else{
          $txt .= co('main90')." [".item_class_name($item_give_true['item']['class'])."] [".$item_give_true['item']['name']."]!<br>";
        }
      }  
    }else{
      $txt .= co('main91');
      $r['over'] = false;
      //��������
      if($ches>40){  //�����Ѷȸ���40��������
        $txt .= co('main92');
        //�����˺�
        if($ches>$db_user['insight']+$db_user['smart']){
          $db_user['hp_v'] -= $ches;
          if($db_user['hp_v']<0){  //��ֹHPС��0
            $db_user['hp_v'] = 0;
          }
          $txt .= co('main93').$ches."<br>";
        }else{
          $txt .= co('main94');
        }
      }
      if($ches>100){  //�����Ѷȸ���100��������
        $txt .= co('main95');
        //�����˺�
        if($ches>$db_user['insight']+$db_user['smart']){
          $db_user['hp_v'] -= $ches*10;  //�ɶ�����ģ�˺�
          if($db_user['hp_v']<0){  //��ֹHPС��0
            $db_user['hp_v'] = 0;
          }
          $txt .= co('main96').($ches*10)."<br>";
        }else{
          $txt .= co('main97');
        }
      }
    }
    DB::update('zgxsh_assassin_user',$db_user,array('uid'=>$db_user['uid']));
    $r['txt'] = $txt;
    return $r;
  }
}

//���в�����
class rank {
  function s_add($uid){
    DB::query("UPDATE ".DB::table( 'zgxsh_assassin_user' )." SET rank_s=rank_s+1 where uid='".$uid."'");
  }
  function t_add($uid){
    DB::query("UPDATE ".DB::table( 'zgxsh_assassin_user' )." SET rank_t=rank_t+1 where uid='".$uid."'");
  }
}
//From: Dism��taobao��com
?>