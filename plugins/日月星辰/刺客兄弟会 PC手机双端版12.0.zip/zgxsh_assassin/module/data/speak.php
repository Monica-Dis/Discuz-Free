<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//��������
class speak{
  function title($speak_id){
    $title[1] = array('title'=>co('spe_01_title'),'img'=>'01.jpg');  //img 400*100px
    $title[2] = array('title'=>co('spe_02_title'),'img'=>'02.jpg');
    $title[3] = array('title'=>co('spe_03_title'),'img'=>'03.jpg'); 
    $title[4] = array('title'=>co('spe_04_title'),'img'=>'04.jpg'); 
    $title[5] = array('title'=>co('spe_05_title'),'img'=>'05.jpg'); 
    $title[6] = array('title'=>co('spe_06_title'),'img'=>'06.jpg'); 
    $title[7] = array('title'=>co('spe_07_title'),'img'=>'07.jpg'); 
    $title[8] = array('title'=>co('spe_08_title'),'img'=>'08.jpg'); 
    $title[9] = array('title'=>co('spe_09_title'),'img'=>'09.jpg'); 
    $title[10] = array('title'=>co('spe_10_title'),'img'=>'10.jpg'); 
    $title[11] = array('title'=>co('spe_11_title'),'img'=>'11.jpg'); 
    $title[12] = array('title'=>co('spe_12_title'),'img'=>'12.jpg'); 
    $title[13] = array('title'=>co('spe_13_title'),'img'=>'13.jpg'); 
    $title[14] = array('title'=>co('spe_14_title'),'img'=>'14.jpg'); 
    $title[15] = array('title'=>co('spe_15_title'),'img'=>'15.jpg'); 
    $title[16] = array('title'=>co('spe_16_title'),'img'=>'16.jpg'); 
    $title[17] = array('title'=>co('spe_17_title'),'img'=>'17.jpg'); 
    $title[18] = array('title'=>co('spe_18_title'),'img'=>'18.jpg'); 
    $title[19] = array('title'=>co('spe_19_title'),'img'=>'19.jpg'); 

    //�����ӦIDֵ
    $r = $title[$speak_id];
    return $r;
  }
  function call($speak_id,$pro){  //�Ի�ID �Ի����
    $title = self::title($speak_id);
    //���鹹��
    if($speak_id==1){  //��һ��Ŀ��
      if($pro==1){  
        $txt = co('cal_01_01');
        $bh_next = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next, 'an_txt' => co('an01'));
      }
      elseif($pro==2){
        $txt = co('cal_01_02');
        $bh_next = 3;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next , 'an_txt' => co('an01'));
      }
      elseif($pro==3){
        $txt = co('cal_01_03');
        $bh_next = 4;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next , 'an_txt' => co('an01'));
      }
      elseif($pro==4){
        $txt = co('cal_01_04');
        $bh_next = 5;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next , 'an_txt' => co('an01'));
      }
      elseif($pro==5){
        $txt = co('cal_01_05');
        $bh_next1 = 6;
        $bh_next2 = 7;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1 , 'an_txt' => co('cal_01_06'));  //����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('cal_01_07'));  //����
      }
      elseif($pro==6){
        $txt = co('cal_01_08');
        $bh_next1 = 8;
        $bh_next2 = 9;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=1" , 'an_txt' => co('an03'));  //ene=1 ���˱��1
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('an04'));
      }
      elseif($pro==7){
        $txt = co('cal_01_09');
        $bh_next = 11;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next."&ches=1" , 'an_txt' => co('an02'));  //���� ��ֵ=�����Ѷ�
        $bh_next = 12;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next."" , 'an_txt' => co('an05'));
      }
      elseif($pro==8){
        $txt = co('cal_01_10');
        $bh_next = 10;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next , 'an_txt' => co('an01'));  //���� ��ֵ=�����Ѷ�
      }
      elseif($pro==9){
        $txt = co('cal_01_11');
      }
      elseif($pro==10){
        $on = "location='plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=2&formhash=".FORMHASH."'";
        $txt = co('cal_01_12').$on.co('cal_01_13');
      }
      elseif($pro==11){
        $txt = co('cal_01_14');
        $bh_next = 12;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next , 'an_txt' => co('an01'));  //���� ��ֵ=�����Ѷ�
      }
      elseif($pro==12){
        $txt = co('cal_01_15');
        $bh_next1 = 6;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1 , 'an_txt' => co('cal_01_16'));  //���� ��ֵ=�����Ѷ�
        $bh_next2 = 13;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('cal_01_17'));  //���� ��ֵ=�����Ѷ�
        $bh_next3 = 14;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next3 , 'an_txt' => co('cal_01_18'));  //���� ��ֵ=�����Ѷ�
      }
      elseif($pro==13){
        $txt = co('cal_01_19');
      }
      elseif($pro==14){
        $txt = co('cal_01_20');
      }
    }
    
    elseif($speak_id==2){  //β������Ѿ
      if($pro==1){  
        $txt = co('cal_02_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==2){
        $txt = co('cal_02_02');
        $bh_next1 = 3;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_02_03'));
				$bh_next2 = 9;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2, 'an_txt' => co('cal_02_04'));
      }
			elseif($pro==3){
        $txt = co('cal_02_05');
        $bh_next1 = 4;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==4){
        $txt = co('cal_02_06');
        $bh_next1 = 5;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==5){
        $txt = co('cal_02_07');
        $bh_next1 = 6;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==6){
        $txt = co('cal_02_08');
        $bh_next1 = 7;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==7){
        $txt = co('cal_02_09');
        $bh_next1 = 8;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==8){  //����
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=3&formhash=".FORMHASH."'";
				$txt = co('cal_02_10',array('on'=>$on));
      }
			elseif($pro==9){
				$txt = co('cal_02_11');
        $bh_next1 = 10;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_02_12');
        $bh_next1 = 11;
        $bh_next2 = 12;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=2" , 'an_txt' => co('an02'));
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('an05'));
			}
			elseif($pro==11){
				$txt = co('cal_02_13');
        $bh_next1 = 12;
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."" , 'an_txt' => co('an01'));
			}
			elseif($pro==12){  //����
				$txt = co('cal_02_14');
      }
    }
		
		elseif($speak_id==3){  //����ɭ��
      if($pro==1){  
        $txt = co('cal_03_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
				$bh_next2 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2, 'an_txt' => co('an05'));
      }
			elseif($pro==2){  //ǰ������ɭ��
				$txt = co('cal_03_02');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){  //��������
				$txt = co('cal_03_03');
			}
			elseif($pro==4){  //��·��
				$txt = co('cal_03_04');
				$bh_next1 = 5;  //�Ǻ�֮��-ս��
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=2", 'an_txt' => co('cal_03_05'));
				$bh_next2 = 6;  //��������-�˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2, 'an_txt' => co('cal_03_06'));
				$bh_next3 = 15;  //�¹��-�˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next3, 'an_txt' => co('cal_03_07'));
			}
			elseif($pro==5){  //�Ǻ�֮��
			  $txt = co('cal_03_08');
				$bh_next1 = 7;  //����ĸ�Ǹ������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."", 'an_txt' => co('an01'));
			}
			elseif($pro==6){  //����-�˳�
			  $txt = co('cal_03_09');
			}
			elseif($pro==7){  //ĸ�Ǹ���
			  $txt = co('cal_03_10');
				$bh_next1 = 8;  //ĸ��-ս��
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=3", 'an_txt' => co('an03'));
				$bh_next2 = 9;  //����-�˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2, 'an_txt' => co('an04'));
			}
			elseif($pro==8){  //ĸ��ս��
			  $txt = co('cal_03_11');
				$bh_next1 = 10;  //��������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."", 'an_txt' => co('an01'));
			}
			elseif($pro==9){  //����
			  $txt = co('cal_03_12');
				$bh_next2 = 3;  //����-�˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){  //��������
			  $txt = co('cal_03_13');
				$bh_next1 = 11;  //����-ս��
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=4", 'an_txt' => co('an03'));
			}
			elseif($pro==11){  //����ս��
			  $txt = co('cal_03_14');
				$bh_next1 = 12;  //��������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."", 'an_txt' => co('an01'));
			}
			elseif($pro==12){  //��������
			  $txt = co('cal_03_15');
				$bh_next1 = 13;  //���� - �������
        $bh_next2 = 3;  //���� - �˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=3" , 'an_txt' => co('an02'));
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('an05'));
			}
			elseif($pro==13){  //�������
				$txt = co('cal_03_16');
				$bh_next1 = 14;  //��������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."", 'an_txt' => co('an01'));
			}
			elseif($pro==14){  //����
				$txt = co('cal_03_17');
			}
			elseif($pro==15){  //�¹�ݱ���
			  $txt = co('cal_03_18');
				$bh_next1 = 16;  //���� - �¹��
        $bh_next2 = 3;  //���� - �˳�
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=3" , 'an_txt' => co('an02'));
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next2 , 'an_txt' => co('an05'));
			}
			elseif($pro==16){  //�¹��
				$txt = co('cal_03_19');
				$bh_next1 = 17;  //��������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."", 'an_txt' => co('an01'));
			}
			elseif($pro==17){  //����
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=4&formhash=".FORMHASH."'";
				$txt = co('cal_03_20',array('on'=>$on));
      }
		}
		
		elseif($speak_id==4){  //ƽ���������
			if($pro==1){
        $txt = co('cal_04_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==2){  
        $txt = co('cal_04_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==3){  
        $txt = co('cal_04_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==4){  
        $txt = co('cal_04_04');
				$bh_next1 = 5;  //��������
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=5", 'an_txt' => co('an03'));
				$bh_next1 = 6;  //����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
      }
			elseif($pro==5){  
        $txt = co('cal_04_05');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==6){  
        $txt = co('cal_04_06');
      }
			elseif($pro==7){  
        $txt = co('cal_04_07');
				$bh_next1 = 8;  //��̽
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_04_19'));
				$bh_next1 = 19;  //����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_04_18'));
      }
			elseif($pro==8){  
        $txt = co('cal_04_08');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==9){  
        $txt = co('cal_04_09');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=6", 'an_txt' => co('cal_04_17'));
				$bh_next1 = 19;  //����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_04_18'));
      }
			elseif($pro==10){  
        $txt = co('cal_04_10');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=6", 'an_txt' => co('an01'));
      }
			elseif($pro==11){  
        $txt = co('cal_04_10');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=6", 'an_txt' => co('an01'));
      }
			elseif($pro==12){  
        $txt = co('cal_04_10');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=6", 'an_txt' => co('an01'));
      }
			elseif($pro==13){  
        $txt = co('cal_04_10');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=7", 'an_txt' => co('an01'));
      }
			elseif($pro==14){  
        $txt = co('cal_04_11');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==15){  
        $txt = co('cal_04_12');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=4", 'an_txt' => co('an02'));
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
      }
			elseif($pro==16){  
        $txt = co('cal_04_13');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==17){  
        $txt = co('cal_04_14');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==18){  
        $txt = co('cal_04_15');
      }
			elseif($pro==19){  
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=5&formhash=".FORMHASH."'";
        $txt = co('cal_04_16',array('on'=>$on));
      }
		}
		
		elseif($speak_id==5){  //��ʦ�ڵ϶�
			if($pro==1){  
        $txt = co('cal_05_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==2){
				$txt = co('cal_05_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_05_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_05_04');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_05_05');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_05_06');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_05_07'));
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_05_08'));
			}
			elseif($pro==7){
				$txt = co('cal_05_09');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==8){
				$txt = co('cal_05_10');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=5", 'an_txt' => co('an02'));
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==9){
				$txt = co('cal_05_11');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_05_12');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==11){
				$txt = co('cal_05_13');
			}
			elseif($pro==12){  
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=6&formhash=".FORMHASH."'";
        $txt = co('cal_05_14',array('on'=>$on));
      }
		}
		
		elseif($speak_id==6){  //ҩʦѧͽ
			if($pro==1){  
        $txt = co('cal_06_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==2){  
        $txt = co('cal_06_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_03'));
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_04'));
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_05'));
      }
			elseif($pro==3){  
        $txt = co('cal_06_06');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_07'));
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_08'));
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_09'));
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_10'));
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_11'));
      }
			elseif($pro==4){  
        $txt = co('cal_06_12');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==5){  
        $txt = co('cal_06_13');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_14'));
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_15'));
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=6", 'an_txt' => co('cal_06_16'));
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_06_17'));
      }
			elseif($pro==6){  
        $txt = co('cal_06_18');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==7){  
        $txt = co('cal_06_19');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==8){  
        $txt = co('cal_06_20');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==9){  
        $txt = co('cal_06_21');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==10){  
        $txt = co('cal_06_22');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==11){  
        $txt = co('cal_06_23');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=8", 'an_txt' => co('an03'));
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an04'));
      }
			elseif($pro==12){ 
				$txt = co('cal_06_24');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==13){
				$txt = co('cal_06_25');
			}
			elseif($pro==14){ 
				$txt = co('cal_06_26');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==15){
				$txt = co('cal_06_27');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==16){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=7&formhash=".FORMHASH."'";
				$txt = co('cal_06_28',array('on'=>$on));
			}
			elseif($pro==17){
				$txt = co('cal_06_29');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=8", 'an_txt' => co('an03'));
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an04'));
			}
			elseif($pro==18){
				$txt = co('cal_06_24');
				$bh_next1 = 19;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==19){
				$txt = co('cal_06_30');
				$bh_next1 = 20;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=7", 'an_txt' => co('an02'));
			}
			elseif($pro==20){
				$txt = co('cal_06_31');
				$bh_next1 = 21;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==21){
				$txt = co('cal_06_32');
			}
		}
		
		elseif($speak_id==7){  //����Ϊ��
			if($pro==1){  
        $txt = co('cal_07_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
      }
			elseif($pro==2){
				$txt = co('cal_07_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_07_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=9", 'an_txt' => co('an03'));
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_07_04'));
			}
			elseif($pro==4){
				$txt = co('cal_07_05');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=9", 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_07_05');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=9", 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_07_05');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=10", 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_07_06');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==8){
				$txt = co('cal_07_07');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=8", 'an_txt' => co('an02'));
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==9){
				$txt = co('cal_07_08');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_07_09');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==11){
				$txt = co('cal_07_10');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_07_11'));
				$bh_next1 = 20;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_07_12'));
			}
			elseif($pro==12){
				$txt = co('cal_07_13');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=11", 'an_txt' => co('an03'));
			}
			elseif($pro==13){
				$txt = co('cal_07_14');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=11", 'an_txt' => co('an03'));
			}
			elseif($pro==14){
				$txt = co('cal_07_14');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=11", 'an_txt' => co('an03'));
			}
			elseif($pro==15){
				$txt = co('cal_07_14');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=12", 'an_txt' => co('an03'));
			}
			elseif($pro==16){
				$txt = co('cal_07_22');
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==17){
				$txt = co('cal_07_15');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=35", 'an_txt' => co('an02'));
				$bh_next1 = 19;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==18){
				$txt = co('cal_07_16');
				$bh_next1 = 20;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==19){
				$txt = co('cal_07_17');
				$bh_next1 = 20;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==20){
				$txt = co('cal_07_18');
				$bh_next1 = 21;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==21){
				$txt = co('cal_07_19');
				$bh_next1 = 22;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==22){
				$txt = co('cal_07_20');
				$bh_next1 = 23;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==23){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=8&formhash=".FORMHASH."'";
				$txt = co('cal_07_21',array('on'=>$on));
			}
		}
		
		elseif($speak_id==8){  //���ռ�ū
      if($pro==1){
				$txt = co('cal_08_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_08_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=13", 'an_txt' => co('an03'));
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_08_03'));
			}
			elseif($pro==3){
				$txt = co('cal_08_04');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_08_05');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=9", 'an_txt' => co('an02'));
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==5){
				$txt = co('cal_08_06');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_08_07');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_08_08');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==8){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=9&formhash=".FORMHASH."'";
				$txt = co('cal_08_09',array('on'=>$on));
			}
		}
		
		elseif($speak_id==9){  //���׷��ս
			if($pro==1){
				$txt = co('cal_09_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_09_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_09_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_09_04');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_09_05'));
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_09_06'));
			}
			elseif($pro==5){
				$txt = co('cal_09_07');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_09_08');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=14", 'an_txt' => co('an03'));
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==7){
				$txt = co('cal_09_09');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=14", 'an_txt' => co('an03'));
			}
			elseif($pro==8){
				$txt = co('cal_09_09');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=14", 'an_txt' => co('an03'));
			}
			elseif($pro==9){
				$txt = co('cal_09_09');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=10&formhash=".FORMHASH."'";
				$txt = co('cal_09_10',array('on'=>$on));
			}
			elseif($pro==11){
				$txt = co('cal_09_11');
			}
			elseif($pro==12){
				$txt = co('cal_09_12');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=15", 'an_txt' => co('cal_09_17'));
			}
			elseif($pro==13){
				$txt = co('cal_09_13');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=15", 'an_txt' => co('an03'));
			}
			elseif($pro==14){
				$txt = co('cal_09_13');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==15){
				$txt = co('cal_09_14');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=10", 'an_txt' => co('an02'));
			}
			elseif($pro==16){
				$txt = co('cal_09_15');
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==17){
				$txt = co('cal_09_16');
			}
		}
		
		elseif($speak_id==10){  //���ӵı���
			if($pro==1){
				$txt = co('cal_10_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_10_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==3){
				$txt = co('cal_10_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==4){
				$txt = co('cal_10_04');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==5){
				$txt = co('cal_10_05');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==6){
				$txt = co('cal_10_06');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_10_07'));
        $bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_10_08'));
			}
      elseif($pro==7){
				$txt = co('cal_10_09');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=12", 'an_txt' => co('an02'));
        $bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_10_10'));
			}
      elseif($pro==8){
				$txt = co('cal_10_11');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==9){
				$txt = co('cal_10_12');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==10){
				$txt = co('cal_10_13');
		  }
      elseif($pro==11){
				$txt = co('cal_10_14');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=16", 'an_txt' => co('an03'));
			}
      elseif($pro==12){
				$txt = co('cal_10_15');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=16", 'an_txt' => co('an03'));
			}
      elseif($pro==13){
				$txt = co('cal_10_15');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=17", 'an_txt' => co('an03'));
			}
      elseif($pro==14){
				$txt = co('cal_10_16');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an03'));
			}
      elseif($pro==15){
				$txt = co('cal_10_17');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an03'));
			}
      elseif($pro==16){
        $on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=11&formhash=".FORMHASH."'";
				$txt = co('cal_10_18',array('on'=>$on));
			}
		}
    
		elseif($speak_id==11){  //��������
			if($pro==1){
				$txt = co('cal_11_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_11_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==3){
				$txt = co('cal_11_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_11_04'));
        $bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_11_05'));
			}
      elseif($pro==4){
				$txt = co('cal_11_06');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=18", 'an_txt' => co('cal_11_07'));
        $bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_11_08'));
			}
      elseif($pro==5){
				$txt = co('cal_11_09');
			}
      elseif($pro==6){
				$txt = co('cal_11_10');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==7){
				$txt = co('cal_11_11');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=16", 'an_txt' => co('an02'));
			}
      elseif($pro==8){
				$txt = co('cal_11_12');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==9){
				$txt = co('cal_11_13');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=19", 'an_txt' => co('an03'));
			}
      elseif($pro==10){
				$txt = co('cal_11_14');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==11){
				$txt = co('cal_11_15');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==12){
				$txt = co('cal_11_16');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==13){
				$txt = co('cal_11_17');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==14){
				$txt = co('cal_11_18');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==15){
				$txt = co('cal_11_19');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=20", 'an_txt' => co('an03'));
			}
      elseif($pro==16){
				$txt = co('cal_11_20');
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==17){
				$txt = co('cal_11_21');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==18){
        $on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=12&formhash=".FORMHASH."'";
				$txt = co('cal_11_22',array('on'=>$on));
			}
		}
		
		elseif($speak_id==12){  //��΢�ı���
			if($pro==1){
				$txt = co('cal_12_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_12_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==3){
				$txt = co('cal_12_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==4){
				$txt = co('cal_12_04');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_05'));
        $bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_06'));
			}
      elseif($pro==5){
				$txt = co('cal_12_07');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==6){
				$txt = co('cal_12_08');
			}
      elseif($pro==7){
				$txt = co('cal_12_09');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
      elseif($pro==8){
				$txt = co('cal_12_10');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==9){
				$txt = co('cal_12_11');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_12'));
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_06'));
			}
			elseif($pro==10){
				$txt = co('cal_12_13');
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_14'));
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_12_15'));
			}
			elseif($pro==11){
				$txt = co('cal_12_16');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=21", 'an_txt' => co('an03'));
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an04'));
			}
			elseif($pro==12){
				$txt = co('cal_12_17');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==13){
				$txt = co('cal_12_18');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=20", 'an_txt' => co('an02'));
			}
			elseif($pro==14){
				$txt = co('cal_12_19');
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==15){
				$txt = co('cal_12_21');
			}
			elseif($pro==16){
				$txt = co('cal_12_22');
			}
			elseif($pro==17){
				$txt = co('cal_12_23');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=22", 'an_txt' => co('an03'));
			}
			elseif($pro==18){
				$txt = co('cal_12_24');
				$bh_next1 = 19;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==19){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=13&formhash=".FORMHASH."'";
				$txt = co('cal_12_25',array('on'=>$on));
			}
		}
		
		elseif($speak_id==13){  //��;ĩ·
			if($pro==1){
				$txt = co('cal_13_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_13_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_13_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_13_04');
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_13_05');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_13_06');
				$bh_next1 = 7;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_13_07');
				$bh_next1 = 8;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_13_08'));
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_13_09'));
			}
			elseif($pro==8){
				$txt = co('cal_13_10');
				$bh_next1 = 9;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==9){
				$txt = co('cal_13_11');
				$bh_next1 = 10;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=23", 'an_txt' => co('an03'));
				$bh_next1 = 15;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==10){
				$txt = co('cal_13_12');
				$bh_next1 = 11;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=23", 'an_txt' => co('an03'));
			}
			elseif($pro==11){
				$txt = co('cal_13_12');
				$bh_next1 = 12;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==12){
				$txt = co('cal_13_13');
				$bh_next1 = 13;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=25", 'an_txt' => co('an02'));
			}
			elseif($pro==13){
				$txt = co('cal_13_14');
				$bh_next1 = 14;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==14){
				$txt = co('cal_13_15');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==15){
				$txt = co('cal_13_16');
				$bh_next1 = 16;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==16){
				$txt = co('cal_13_17');
				$bh_next1 = 17;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an03'));
			}
			elseif($pro==17){
				$txt = co('cal_13_18');
				$bh_next1 = 18;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=24", 'an_txt' => co('an03'));
			}
			elseif($pro==18){
				$txt = co('cal_13_19');
				$bh_next1 = 19;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=24", 'an_txt' => co('an03'));
			}
			elseif($pro==19){
				$txt = co('cal_13_19');
				$bh_next1 = 20;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=24", 'an_txt' => co('an03'));
			}
			elseif($pro==20){
				$txt = co('cal_13_19');
				$bh_next1 = 21;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=24", 'an_txt' => co('an03'));
			}
			elseif($pro==21){
				$txt = co('cal_13_19');
				$bh_next1 = 22;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==22){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=14&formhash=".FORMHASH."'";
				$txt = co('cal_13_20',array('on'=>$on));
			}
		}
		
		elseif($speak_id==14){  //��α��Ͷ��
			if($pro==1){
				$txt = co('cal_14_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_14_02');
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_14_03');
				$bh_next1 = 4;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_14_04'));
				$bh_next1 = 5;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_14_05'));
			}
			elseif($pro==4){
				$txt = co('cal_14_06');
				$bh_next1 = 6;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_14_07');
			}
			elseif($pro==6){
				$txt = co('cal_14_08');
				$bh_next1 = 7;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=25", 'an_txt' => co('an03'));
			}
			elseif($pro==7){
				$txt = co('cal_14_09');
				$bh_next1 = 8;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=25", 'an_txt' => co('an03'));
			}
			elseif($pro==8){
				$txt = co('cal_14_09');
				$bh_next1 = 9;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==9){
				$txt = co('cal_14_10');
				$bh_next1 = 10;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_14_11');
				$bh_next1 = 11;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==11){
				$txt = co('cal_14_12');
				$bh_next1 = 12;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==12){
				$txt = co('cal_14_13');
				$bh_next1 = 13;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=29", 'an_txt' => co('cal_14_14'));
				$bh_next1 = 15;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=26", 'an_txt' => co('cal_14_15'));
			}
			elseif($pro==13){
				$txt = co('cal_14_16');
				$bh_next1 = 14;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==14){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=15&formhash=".FORMHASH."'";
				$txt = co('cal_14_17',array('on'=>$on));
			}
			elseif($pro==15){
				$txt = co('cal_14_18');
				$bh_next1 = 16;  //��תpro�����br
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==16){
				$txt = co('cal_14_19');
			}
		}
		
		elseif($speak_id==15){  //����ıɱ
			if($pro==1){
				$txt = co('cal_15_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_15_02');
				$bh_next1 = 3;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_15_03');
				$bh_next1 = 4;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_15_04');
				$bh_next1 = 5;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_15_05');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_15_15'));
				$bh_next1 = 12;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('cal_15_16'));
			}
			elseif($pro==6){
				$txt = co('cal_15_06');
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_15_07');
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=28", 'an_txt' => co('an03'));
			}
			elseif($pro==8){
				$txt = co('cal_15_08');
				$bh_next1 = 9;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=28", 'an_txt' => co('an03'));
			}
			elseif($pro==9){
				$txt = co('cal_15_08');
				$bh_next1 = 10;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_15_09');
				$bh_next1 = 11;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==11){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=16&formhash=".FORMHASH."'";
				$txt = co('cal_15_10',array('on'=>$on));
			}
			elseif($pro==12){
				$txt = co('cal_15_11');
				$bh_next1 = 13;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=40", 'an_txt' => co('an02'));
			}
			elseif($pro==13){
				$txt = co('cal_15_12');
				$bh_next1 = 14;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==14){
				$txt = co('cal_15_13');
				$bh_next1 = 15;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==15){
				$txt = co('cal_15_14');
			}
		}
		
		elseif($speak_id==16){  //�ʳ�����
			if($pro==1){
				$txt = co('cal_16_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_16_02');
				$bh_next1 = 3;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_16_03');
				$bh_next1 = 5;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=29", 'an_txt' => co('an03'));
				$bh_next1 = 4;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==4){
				$txt = co('cal_16_04');
			}
			elseif($pro==5){
				$txt = co('cal_16_05');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=29", 'an_txt' => co('an03'));
			}
			elseif($pro==6){
				$txt = co('cal_16_06');
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=29", 'an_txt' => co('an03'));
			}
			elseif($pro==7){
				$txt = co('cal_16_07');
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=29", 'an_txt' => co('an03'));
			}
			elseif($pro==8){
				$txt = co('cal_16_08');
				$bh_next1 = 9;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=29", 'an_txt' => co('an03'));
			}
			elseif($pro==9){
				$txt = co('cal_16_09');
				$bh_next1 = 10;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_16_10');
				$bh_next1 = 11;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=45", 'an_txt' => co('an02'));
			}
			elseif($pro==11){
				$txt = co('cal_16_11');
				$bh_next1 = 12;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==12){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=17&formhash=".FORMHASH."'";
				$txt = co('cal_16_12',array('on'=>$on));
			}
		}
		
		elseif($speak_id==17){  //����
			if($pro==1){
				$txt = co('cal_17_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_17_02');
				$bh_next1 = 3;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_17_03');
				$bh_next1 = 4;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_17_04');
				$bh_next1 = 5;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=30", 'an_txt' => co('an03'));
			}
			elseif($pro==5){
				$txt = co('cal_17_05');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=30", 'an_txt' => co('an03'));
			}
			elseif($pro==6){
				$txt = co('cal_17_05');
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_17_06');
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==8){
				$txt = co('cal_17_07');
				$bh_next1 = 9;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==9){
				$txt = co('cal_17_08');
				$bh_next1 = 10;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==10){
				$txt = co('cal_17_09');
				$bh_next1 = 11;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=50", 'an_txt' => co('an02'));
				$bh_next1 = 12;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==11){
				$txt = co('cal_17_10');
				$bh_next1 = 12;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==12){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=18&formhash=".FORMHASH."'";
				$txt = co('cal_17_11',array('on'=>$on));
			}
		}
		
		elseif($speak_id==18){  //���������
			if($pro==1){
				$txt = co('cal_18_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==2){
				$txt = co('cal_18_02');
				$bh_next1 = 3;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_18_03');
				$bh_next1 = 4;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_18_04');
				$bh_next1 = 5;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==5){
				$txt = co('cal_18_05');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_18_06');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
			}
			elseif($pro==7){
				$txt = co('cal_18_06');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 7;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
				$bh_next1 = 8;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=31", 'an_txt' => co('an01'));
			}
			elseif($pro==8){
				$txt = co('cal_18_06');
				$bh_next1 = 9;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==9){
				$txt = co('cal_18_07');
				$bh_next1 = 10;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=60", 'an_txt' => co('an02'));
			}
			elseif($pro==10){
				$txt = co('cal_18_08');
				$bh_next1 = 11;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==11){
				$on = "'plugin.php?id=zgxsh_assassin:index_if&op=plot_add&bh=19&formhash=".FORMHASH."'";
				$txt = co('cal_18_09',array('on'=>$on));
			}
		}
		
		elseif($speak_id==19){  //���������
			if($pro==1){
				$txt = co('cal_19_01');
				$bh_next1 = 2;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ene=32", 'an_txt' => co('an03'));
				$bh_next1 = 3;  //��תpro�����
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an05'));
			}
			elseif($pro==2){
				$txt = co('cal_19_02');
				$bh_next1 = 3;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==3){
				$txt = co('cal_19_03');
				$bh_next1 = 4;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==4){
				$txt = co('cal_19_04');
				$bh_next1 = 5;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1."&ches=80", 'an_txt' => co('an02'));
			}
			elseif($pro==5){
				$txt = co('cal_19_05');
				$bh_next1 = 6;  //��תpro�����ber
        $speak_an[] = array('op' => "&bh=".$speak_id."&pro=".$bh_next1, 'an_txt' => co('an01'));
			}
			elseif($pro==6){
				$txt = co('cal_19_06');
			}
		}		
		
    //���ر���
    $r['title'] = $title;
    $r['txt'] = $txt;
    $r['speak_an'] = $speak_an;
    return $r;
  }
}
//From: Dism��taobao��com
?>