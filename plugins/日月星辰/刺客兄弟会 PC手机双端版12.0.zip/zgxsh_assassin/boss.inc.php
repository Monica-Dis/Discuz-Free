<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.{modulename})] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0 ȫ���BOSS
 *	Date: 2020-8-8 15:39
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include 'module/main.php';

$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
if(!$db_user){  //û�Ŵ�����ɫ
	include template('zgxsh_assassin:index/index_new');
	exit();
}
$db_user['works'] = a_works($db_user['works']);
$db_user['will_po_name'] = will_po($db_user['will_po'],$db_user['will_id']);
$db_user['will_name'] = will_name($db_user['will_id']);

if(!$db_user['will_id']){	
	$db_will = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_will'));
	for($i=0;$i<count($db_will);$i++){
		$db_will[$i]['name'] = ass_name($db_will[$i]['w_uid']);
	}
}else{
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
	if($db_will){
		$db_will['w_lxname'] = ass_name($db_will['w_uid']);
		$db_will_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_will['id']."'");
		for($i=0;$i<count($db_will_user_all);$i++){
			$db_will_user_all[$i]['will_po_name'] = will_po($db_will_user_all[$i]['will_po'],$db_will_user_all[$i]['will_id']);
			$db_will_user_all[$i]['works'] = a_works($db_will_user_all[$i]['works']);
		}
		$db_will['rs'] = count($db_will_user_all);
		if($db_will['join_way']==0){
			$db_will['join_way'] = co('plot07');
		}elseif($db_will['join_way']==1){
			$db_will['join_way'] = co('plot08');
		}elseif($db_will['join_way']==2){
			$db_will['join_way'] = co('plot15');
		}
	}
}

$map_see = map_see($_G['uid']);
map_hiding($_G['uid']);  //�����ж�

//��ɫ�Ƿ�����
if($db_user['hp_v']<=0){
  notice($_G['uid'],co('plot10').$db_user['name'].co('plot11'));
	if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
		poor_po::del($db_user['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user['will_po']]),co("inif222"),co("inif228"));
	}
  
  
  //ע����ɫ
  DB::delete('zgxsh_assassin_user',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_map',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_items',array('uid'=>$_G['uid']));  //ɾ��������Ʒ����
  
  $no_users = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user')." WHERE uid != '".$_G['uid']."' AND will_id='".$db_user['will_id']."'");
  for($i=0;$i<count($no_users);$i++){
    notice($no_users[$i]['uid'],co('plot12'),co('plot13'));
  }
  include template('zgxsh_assassin:index/index_end');
	exit();
}

//��ɫ�Ƿ��ܹ�����
if($db_user['exp_v'] >= $db_user['exp_k']){
  $see_upcl = "layui-btn-normal";
  $see_upon = "showWindow('TC','plugin.php?id=zgxsh_assassin:index_if&op=user_up&formhash=".FORMHASH."','get',0,{'cover':'1'});";
}else{
  $see_upcl = "layui-btn-disabled";
  $see_upon = "";
}

//ȫ���boss��ʼ
if(!$_TRC['boss_true']){
  prompt(co('boss17')."<br><a href='https://dism.taobao.com/plugins/zgxsh_assassin.html'>".co('boss18')."</a>","location='plugin.php?id=zgxsh_assassin:index'");
}

//boss �����ڶ��һ�û��ˢ��ʱ��
$boss_cz = boss::see(" WHERE state='1'");
$dq_time = date("H",time());
if($dq_time<$_TRC['boss_Dtime'] and !$boss_cz){
  prompt(co('boss29').$_TRC['boss_Dtime'].co('boss30'),"location='plugin.php?id=zgxsh_assassin:boss'");
}

if($dq_time>=$_TRC['boss_Dtime'] and $_TRC['boss_class'] and !$boss_cz){  //ÿ�ո���
  $boss = boss::see(" WHERE state='1'");
  if($boss['id']){$bossid=" AND mb='".$boss['id']."'";}else{$bossid="";}
  $b_user = b_user::see_all(" WHERE state='1'".$bossid);
  boss::edit(array('id'=>$boss['id']),array('state'=>2));  //BOSS����
  foreach($b_user as $k=>$v){  //����û�
    b_user::del('uid',$b_user['uid']);
  }
}

$boss = boss::init();  //BOSS���ϳ�ʼ��

//������
if($boss['kt']<time()){
  //BOSS����ҿ�ʼ�Թ�
  $cuser = b_user::see_all();
  if(count($cuser)>0){
    $mb_user = $cuser[rand(0,count($cuser)-1)];
    boss::kill($mb_user);
    $boss = boss::init();
  }else{  //û��Ŀ����
    if($boss['hp_v']<$boss['hp_k']){
      $boss['hp_v']++;
      boss::edit(array('id'=>$boss['id']),array('hp_v'=>$boss['hp_v']));
      b_news::add(co('boss19'));
    }else{
      b_news::add(co('boss20'));
    }    
  }
  //���ü�ʱ��
  $boss['s_time'] = time()*1000;
  $boss['e_time'] = (time()+$_TRC['boss_kt'])*1000;
  boss::edit(array('id'=>$boss['id']),array('kt'=>time()+$_TRC['boss_kt']));
}else{
  $boss['s_time'] = time()*1000;
  $boss['e_time'] = $boss['kt']*1000;
}

$boss['jc'] = $boss['ext'] + boss::hours($boss['id']);

$b_user = b_user::init();  //������ҳ�ʼ��
for($i=0;$i<20;$i++){
  if($b_user[$i]['uid']>0){
    $b_user[$i]['name'] = ass_name($b_user[$i]['uid']);
  }else{
    $b_user[$i]['name'] = "<span style='color:#999'>".co('boss21')."</span>";
  }
}
$b_news = b_news::init();  //���ų�ʼ��
for($i=0;$i<count($b_news);$i++){
  $b_news[$i]['date'] = dgmdate($b_news[$i]['time'],"u");
}

$db_sh = b_user::see_all(" WHERE mb='".$boss['id']."'");  //���˺�
foreach($db_sh as $k=>$v){
  $sum_sh += $v['sh'];
}
$i_sh = b_user::see_one(" WHERE uid='".$_G['uid']."' AND mb='".$boss['id']."'","sh");  //������ҳ�ʼ��
$i_sh = !$i_sh?0:$i_sh;
if($i_sh>0){
  $i_bfb = round($i_sh/$sum_sh,2);
  $i_ext = floor($boss['jc']*$i_bfb);
  $i_bfb *= 100;
}else{
  $i_bfb = 0;
  $i_ext = 0;
}


//print_r($boss);

include template('zgxsh_assassin:boss/boss');
?>