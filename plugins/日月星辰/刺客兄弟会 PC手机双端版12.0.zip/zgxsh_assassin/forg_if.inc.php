<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");



if($_GET['op']=="forg"){  //�����߼�
	$ls = security::filter($_GET);  //dhtmlspecialchars
	
	$db_item = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id='".$ls['bh']."'");
	$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	
	if(!$db_item){
		prompt(co('forg01'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	
	$db_item_up1 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite09')."'");
	$db_item_up2 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite10')."'");
	$db_item_up3 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite11')."'");
	$db_item_up4 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite12')."'");
	$db_item_up5 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite13')."'");
	$db_item_up6 = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND name='".co('ite14')."'");
	
	//�Ƿ�����װ����Ʒ
	if($ls['bh']==$db_user['armed_head'] or $ls['bh']==$db_user['armed_body'] or $ls['bh']==$db_user['armed_foot'] or $ls['bh']==$db_user['armed_weapons'] or $ls['bh']==$db_user['armed_crossbow'] or $ls['bh']==$db_user['armed_special']){
    $equi = 1;  //װ����
  }else{
		$equi = 0;  //ûװ��
	}
	
  include template('zgxsh_assassin:forg/forg_op');
}
elseif($_GET['op']=="forg_repair"){  //����
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
	
	$db_item = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id='".$ls['bh']."' AND uid='".$_G['uid']."'");
	
	if(!$db_item){
		prompt(co('forg01'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	if($db_item['du_k']<=10){
		prompt(co('forg02'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	
	$fee = $db_item['du_k']-$db_item['du_v']-($db_will['buil_7']*10);  //������ - ��ǽ�ȼ�*10
	$fee = $fee<1?1:$fee; 
	$du_k = $db_item['du_k']-rand(1,5);  //�����;�����
	$du_v = $du_k;  //�ظ��;�
	
	integral($_G['uid'],-$fee,$_TRC['extid'],$_TRC['p_name'],co('forg03'));  //�۷�

	//�޸�װ��
	$up = array(
	  'du_k' => $du_k,
	  'du_v' => $du_v,
	);
	DB::update('zgxsh_assassin_items',$up,array('id'=>$ls['bh']));
	
	$co_txt = array(
	  'co1' => $db_item["name"],
	  'co2' => $fee,
	  'co3' => $_TRC["extname"],
	);
	prompt(co('forg04',$co_txt),"location='plugin.php?id=zgxsh_assassin:forg'");
}
elseif($_GET['op']=="forg_deco"){  //�ֽ�
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
	
	$db_item = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id='".$ls['bh']."' AND uid='".$_G['uid']."'");
	
	if(!$db_item){
		prompt(co('forg01'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}

	$fee = 100-($db_will['buil_7']*3);  //��ǽ�ȼ��Ż�
	
	integral($_G['uid'],-$fee,$_TRC['extid'],$_TRC['p_name'],co('forg09'));  //�۷�
	
	if(rand(0,1)){  //���ʧ��!
		DB::delete('zgxsh_assassin_items',array('id'=>$ls['bh']));  //ɾ����Ʒ
		prompt(co('forg05'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
		
	//�ֽ���
	if($db_item['class'] < 5){  //�ֽ�Ϊ��ͨǿ��
		$item_add = item_give($_G['uid'],rand(1,4),9);  //���Сǿ��
	}elseif($db_item['class'] == 6 or $db_item['class'] == 8){  //�ֽ�Ϊ���ǿ�������;�ʯͷ
		$item_add = item_give($_G['uid'],rand(5,6),9);  //��ǿ��
	}else{
		integral($_G['uid'],$fee,$_TRC['extid'],$_TRC['p_name'],co('forg10'));  //�۷�
		prompt(co('forg06'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}

	//�ж��ֽ�ʧ��
	if(!$item_add['over']){
		integral($_G['uid'],$fee,$_TRC['extid'],$_TRC['p_name'],co('forg10'));  //�۷�
	  prompt($item_add['txt'],"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	
	DB::delete('zgxsh_assassin_items',array('id'=>$ls['bh']));  //ɾ����Ʒ
	
	$co_txt = array(
	  'co1' => $db_item["name"],
	  'co2' => $item_add['item']['name'],
	);
	prompt(co('forg08',$co_txt),"location='plugin.php?id=zgxsh_assassin:forg'");
	
}
elseif($_GET['op']=="strengthen"){
	security::hash_if(1);  //formhash
	$ls = security::filter($_GET);  //dhtmlspecialchars
	
	$db_item = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id='".$ls['bh']."' AND uid='".$_G['uid']."'");
	$db_item_up = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE class='9' AND id='".$ls['cl']."'");
	if(!$db_item){
		prompt(co('ite21'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	if(!$db_item_up){
		prompt(co('ite22'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	if($db_item_up['name']==co('ite09')){
		$up['attack'] = $db_item['attack']+1;
		$up['du_k'] = $db_item['du_k']-1;
		$up['value'] = $db_item['value'] + 1;
	}elseif($db_item_up['name']==co('ite10')){
		$up['defense'] = $db_item['defense']+1;
		$up['du_k'] = $db_item['du_k']-1;
		$up['value'] = $db_item['value'] + 1;
	}elseif($db_item_up['name']==co('ite11')){
		$up['smart'] = $db_item['smart']+1;
		$up['du_k'] = $db_item['du_k']-1;
		$up['value'] = $db_item['value'] + 1;
	}elseif($db_item_up['name']==co('ite12')){
		$up['insight'] = $db_item['insight']+1;
		$up['du_k'] = $db_item['du_k']-1;
		$up['value'] = $db_item['value'] + 1;
	}elseif($db_item_up['name']==co('ite13')){
		$rand=rand(1,4);
		if($rand==1){
			$up['attack'] = $db_item['attack']+2;
		}elseif($rand==2){
			$up['defense'] = $db_item['defense']+2;
		}elseif($rand==3){
			$up['smart'] = $db_item['smart']+2;
		}elseif($rand==4){
		  $up['insight'] = $db_item['insight']+2;
		}
		$up['du_k'] = $db_item['du_k']-1;
		$up['value'] = $db_item['value'] + 2;
	}elseif($db_item_up['name']==co('ite14')){
		$up['du_k'] = $db_item['du_k']+rand(1,5);
		$up['value'] = $db_item['value'] + 1;
	}else{
		prompt(co('ite23'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	//�;ò��ܳ�������
	if($db_item['du_v'] > $up['du_k']){
		$up['du_v'] = $up['du_k'];
	}
	//���Ķ������
	DB::delete('zgxsh_assassin_items',array('id'=>$ls['cl']));
	//�ж��Ƿ����ɹ�
	if(rand(0,1)){
		
		DB::update('zgxsh_assassin_items',$up,array('id'=>$ls['bh']));
		
		$txt = co('ite24',array('co1'=>$db_item_up['name']));
		if($up['attack']>$db_item['attack']){
			$txt .= co('ite25',array('co1'=>$db_item['attack'],'co2'=>$up['attack'])); 
		}elseif($up['defense']>$db_item['defense']){
			$txt .= co('ite26',array('co1'=>$db_item['defense'],'co2'=>$up['defense'])); 
		}elseif($up['smart']>$db_item['smart']){
			$txt .= co('ite27',array('co1'=>$db_item['smart'],'co2'=>$up['smart'])); 
		}elseif($up['insight']>$db_item['insight']){
			$txt .= co('ite28',array('co1'=>$db_item['insight'],'co2'=>$up['insight'])); 
		}
		$txt .= co('ite29',array('co1'=>$db_item['du_k'],'co2'=>$up['du_k'])); 
		$txt .= co('ite30',array('co1'=>$db_item['value'],'co2'=>$up['value'])); 
		prompt($txt,"location='plugin.php?id=zgxsh_assassin:forg'");
	}else{
		//����ʧ�������;�
		DB::update('zgxsh_assassin_items',array('du_v'=>$up['du_v'],'du_k'=>$up['du_k']),array('id'=>$ls['bh']));
	  prompt(co('ite31',array('co1'=>$db_item_up['name'])),"location='plugin.php?id=zgxsh_assassin:forg'");	
	}
}
elseif($_GET['op']=="synthe"){  //�ϳ� cl�ϳ�����
	$ls = security::filter($_GET);  //dhtmlspecialchars
	$see['form'] = layui::form_name();
	
	$db_item = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id='".$ls['bh']."' AND class='9' AND uid='".$_G['uid']."'");
	$db_item_syn = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id != '".$ls['bh']."' AND class='9' AND uid='".$_G['uid']."'");
	if(!$db_item){
		prompt(co('ite21'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	if(count($db_item_syn)<=0){
		prompt(co('forg13'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	$db_item['cl_name'] = item_class_name($db_item['class']);
	for($i=0;$i<count($db_item_syn);$i++){
		$db_item_syn[$i]['cl_name'] = item_class_name($db_item_syn[$i]['class']);
	}
	
  //ѡ��������
	include template('zgxsh_assassin:forg/synthe');
}
elseif($_GET['op']=="synthe_sub"){ 
  security::hash_if();  //formhash
	$ls = security::filter($_GET);  //dhtmlspecialchars
	
	if(!$ls['bh']){
		prompt(co('forg11'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	if(count($ls['sell'])<=0){
		prompt(co('forg12'),"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	
	$r = synthe($ls['bh'],$ls['sell']);
	for($i=0;$i<count($r['loss']);$i++){
		$loss_txt .= '<span style="color:#f60">'.co('forg14').' ['.$r['loss'][$i].']</span><br>';
	}		
	
	if($r['over']==true){  //�ϳɳɹ�
		prompt(co('forg15').'<br><span style="color:#0A0">'.co('forg16').' ['.$r['name'].']</span><br>'.$loss_txt,"location='plugin.php?id=zgxsh_assassin:forg'");
	}else{  //�ϳ�ʧ��
		prompt(co('forg18').'<br>'.co('forg17').'<br>'.$loss_txt,"location='plugin.php?id=zgxsh_assassin:forg'");
	}
	
}

system_end();
?>