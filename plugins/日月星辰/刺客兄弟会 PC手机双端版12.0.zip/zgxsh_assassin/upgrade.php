<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.upgrade)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_assassin_user')." LIKE 'plot_id'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_assassin_user')." ADD plot_id int(20) default 1 NOT NULL AFTER rank_t");
}

$sql = <<<EOF
EOF;

runquery($sql);

$finish = true;
?>