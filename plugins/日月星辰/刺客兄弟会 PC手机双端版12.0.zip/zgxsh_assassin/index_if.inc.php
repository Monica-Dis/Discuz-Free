<?php
/**
 *	[�����ֱ�(zgxsh_sxsb.{modulename})] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';

if($_GET['op']=="new_user"){  //������ɫ
  security::hash_if();  //formhash
	$ls = security::filter($_GET);  //dhtmlspecialchars
  security::txt_en($ls['name'],co('inif001'),4,20);
	security::int_if($ls['works'],co('inif002'));
	
	if(db_op::new_user($ls)){
		prompt(co('inif003'));
	}
	prompt(co('inif004'));
}

//�ֵܻ����
elseif($_GET['op']=="new_will"){  //�����ֵܻ�
	$see['form'] = layui::form_name();
  include template('zgxsh_assassin:will/new_will');	
	exit();
}
elseif($_GET['op']=="new_will_sub"){  //�����ֵܻ��ύ
	security::hash_if();
	$ls = security::filter($_GET);
	security::txt_en($ls['name'],co('inif005'),4,30);
	security::int_if($ls['qq'],co('inif006'));
	security::int_if($ls['join_way'],co('inif007'),0,1);
	//�Ƿ������ֵܻ�
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE w_uid = '".$_G['uid']."'");
	if($db_will){
		prompt(co('inif008'));
	}
	if($_TRC['new_consu']>0){
	  integral($_G['uid'],-$_TRC['new_consu'],$_TRC['extid'],co('inif012'),co('inif009'));
	}
	if(db_op::new_will($ls)){
		prompt(co('inif010'));
	}
	prompt(co('inif011'));
}
elseif($_GET['op']=="join_req"){  //�������
	security::hash_if(1);  //GET�ύ
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif013'));
	
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$ls['bh']."'");
	$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	
	$will_user_sum = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$ls['bh']."'");
	if($will_user_sum>=$db_will['popu']){  //popu �ֵܻ���������
		prompt(co('inif233'));
	}
	
	if(!$db_will){
		prompt(co('inif014'));
	}
	if(!$db_user){
		prompt(co('inif015'));
	}
	if($db_user['will_po']>0){
		prompt(co('inif016').will_name($db_user['will_id']).co('inif017'));
	}
  if($db_will['join_way']==2){
    prompt(co('inif243'),"",array('icon'=>2));
  }
  
  
	
	$ls['join_way'] = $db_will['join_way'];
	
	if(db_op::join_req($ls)){
		prompt(co('inif018'));
	}
	prompt(co('inif019'));
}
elseif($_GET['op']=="exit"){  //�˳��ֵܻ�
	security::hash_if(1);  //GET�ύ
	$ls['bh'] = $_G['uid'];
	if(db_op::will_exit($ls)){
		prompt(co('inif020'));
	}
	prompt(co('inif021'));
}
elseif($_GET['op']=="join_model"){  //�����᷽ʽ
	security::hash_if(1);
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif013'));
	$join_way = DB::result_first("SELECT join_way FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$ls['bh']."'");
	if($join_way==0){
		$join_class[0] = "checked";
		$join_class[1] = "";
		$join_class[2] = "";
	}elseif($join_way==1){
		$join_class[0] = "";
		$join_class[1] = "checked";
		$join_class[2] = "";
	}elseif($join_way==2){
		$join_class[0] = "";
		$join_class[1] = "";
		$join_class[2] = "checked";
	}
	$see['form'] = layui::form_name();
  include template('zgxsh_assassin:will/join_model');	
	exit();
}
elseif($_GET['op']=="join_model_sub"){  //�����᷽ʽ
	security::hash_if();
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif013'));
	security::int_if($ls['join_way'],co('inif007'),0,1);
	security::int_if($ls['join_dq'],co('inif008'),0,1);
	if($ls['join_way']==$ls['join_dq']){
		prompt(co('inif022'));
	}
	if($_TRC['join_consu']>0){
	  integral($_G['uid'],-$_TRC['join_consu'],$_TRC['extid'],co('inif012'),co('inif023'));
	}
	if(db_op::join_model($ls)){
		prompt($_TRC["extname"]." : ".(-$_TRC['join_consu']).co('inif024'));
	}
	prompt(co('inif025'));
}
elseif($_GET['op']=="qqs_edit"){  //�����᷽ʽ
	security::hash_if(1);
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif013'));
	$see['form'] = layui::form_name();
  include template('zgxsh_assassin:will/qqs_edit');	
	exit();
}
elseif($_GET['op']=="qqs_editl_sub"){  //�����᷽ʽ
	security::hash_if();
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif013'));
	security::int_if($ls['qq'],co('inif006'));
	if(db_op::qqs_editl($ls)){
		prompt(co('inif026'));
	}
	prompt(co('inif027'));
}
elseif($_GET['op']=="kick"){  //���߳��ֵܻ�
	security::hash_if(1);  //GET�ύ
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif031'));
	if(db_op::will_exit($ls)){
		notice($ls['bh'],co('inif028'),co('inif029'));
		prompt(co('inif030'));
	}
	prompt(co('inif032'));
}
elseif($_GET['op']=="ref_no"){  //�ܾ����
	security::hash_if(1);  //GET�ύ
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif031'));
	if(db_op::will_exit($ls)){
		notice($ls['bh'],co('inif028'),co('inif033'));
		prompt(co('inif034'));
	}
	prompt(co('inif035'));
}
elseif($_GET['op']=="ref_yes"){  //ͬ�����
	security::hash_if(1);  //GET�ύ
	$ls = security::filter($_GET);
	security::int_if($ls['bh'],co('inif031'));
	if(db_op::ref_yes($ls)){
		notice($ls['bh'],co('inif028'),co('inif036'));
		prompt(co('inif037'));
	}
	prompt(co('inif038'));
}
elseif($_GET['op']=="del_will"){  //��ɢ�ֵܻ�
	security::hash_if(1);  //GET�ύ
  //����Ϣ
  $db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE w_uid = '".$_G['uid']."'");
	if(!$db_will){
		prompt(co('inif039'));
	}
	$db_will_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_will['id']."'");
	if(count($db_will_user_all)>1){
		prompt(co('inif040').$db_will['w_name'].co('inif041'));
	}
  
	if(db_op::del_will($ls)){
		prompt(co('inif042'));
	}
	prompt(co('inif043'));
}
elseif($_GET['op']=="user_edit"){  //�̿������޸�
	security::hash_if(1);  //GET�ύ
  //����Ϣ
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_user){
		prompt(co('inif044'));
	}
	$db_user['works_name'] = a_works($db_user['works']);
	$see['form'] = layui::form_name();
	include template('zgxsh_assassin:user/user_edit');	
	exit();
}
elseif($_GET['op']=="user_edit_sub"){  //�̿������޸��ύ
	security::hash_if();
	$ls = security::filter($_GET);
	security::int_if($ls['works'],co('inif002'));
  if(db_op::edit_user($ls)){
		prompt(co('inif045'));
	}
	prompt(co('inif046'));
}
elseif($_GET['op']=="posi_setup"){  //����ְλ����
  security::hash_if(1);
	$ls = security::filter($_GET);
  
  $posi = DB::result_first("SELECT posi FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$ls['bh']."'");
  if($posi){
    $posi_a = unserialize($posi);
  }else{
    $posi_a[1] = co("willpo1");
    $posi_a[2] = co("willpo2");
    $posi_a[3] = co("willpo3");
    $posi_a[4] = co("willpo4");
    $posi_a[5] = co("willpo5");
    $posi_a[6] = co("willpo6");
    $posi_a[7] = co("willpo7");
  }
  
  include template('zgxsh_assassin:plist/posi_setup');
  exit();
}
elseif($_GET['op']=="posi_setup_sub"){  //����ְλ����
  security::hash_if();
	$ls = security::filter($_GET);
  security::txt_ch($ls['posi1'],co("willpo1").co("posi01"),0,1);
  security::txt_ch($ls['posi2'],co("willpo2").co("posi02"),0,1);
  security::txt_ch($ls['posi3'],co("willpo3").co("posi03"),0,1);
  security::txt_ch($ls['posi4'],co("willpo4").co("posi04"),0,1);
  security::txt_ch($ls['posi5'],co("willpo5").co("posi05"),0,1);
  security::txt_ch($ls['posi6'],co("willpo6").co("posi06"),0,1);
  security::txt_ch($ls['posi7'],co("willpo7").co("posi07"),0,1);
  
  $posi_a[1] = $ls['posi1'];
  $posi_a[2] = $ls['posi2'];
  $posi_a[3] = $ls['posi3'];
  $posi_a[4] = $ls['posi4'];
  $posi_a[5] = $ls['posi5'];
  $posi_a[6] = $ls['posi6'];
  $posi_a[7] = $ls['posi7'];
  
  $up = array(
    'posi' => serialize($posi_a)
  );
  
  $will_id = DB::result_first("SELECT will_id FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  
  DB::update('zgxsh_assassin_will',$up,array('id'=>$will_id));
  
  prompt(co("inif208"));
}
elseif($_GET['op']=="posi_edit"){  //�����Ա����
	security::hash_if(1);
	$ls = security::filter($_GET);
	$see['form'] = layui::form_name();
	
	//ȷ�����ݼ���
	$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	//��ȡ��������
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$ls['bh']."'");
	if($db_will['posi']){
    $posi_a = unserialize($db_will['posi']);
  }else{
    $posi_a[1] = co("willpo1");
    $posi_a[2] = co("willpo2");
    $posi_a[3] = co("willpo3");
    $posi_a[4] = co("willpo4");
    $posi_a[5] = co("willpo5");
    $posi_a[6] = co("willpo6");
    $posi_a[7] = co("willpo7");
  }
	//��ȡ���й���̿�
	$db_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$ls['bh']."' AND will_po != '7' AND uid!='".$_G['uid']."'");
	//ȷ���û�ѡ����
	for($i=0;$i<count($db_user_all);$i++){
		$db_user_option .= '<option value="'.$db_user_all[$i]['uid'].'">'.$db_user_all[$i]['name'].'</option>';
	}
	//���ݼ���ȷ���������㼶
	if($db_user['will_po']==7){
		$posi_edit_6[0] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_po = '6' AND will_id='".$ls['bh']."'");
		//����ȼ�����9���������������ʦ
		if($db_will['buil_1']>=9){
			$WHERE = " WHERE will_po = '6' AND will_id='".$ls['bh']."' AND uid!='".$posi_edit_6[0]['uid']."'";
			$posi_edit_6[1] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user').$WHERE);
		}
	}
	if($db_user['will_po']>=6){
		$posi_edit_5 = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_po = '5' AND will_id='".$ls['bh']."'");
	}
	$posi_edit_4 = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_po = '4' AND will_id='".$ls['bh']."'");
	$posi_edit_3 = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_po = '3' AND will_id='".$ls['bh']."'");
	//Ĭ�Ϲ�λ����-��ʦ
  for($i=0;$i<2;$i++){
		if($posi_edit_6[$i]['uid']>0){
			$select_6[$i]['option'] = '<option value="'.$posi_edit_6[$i]['uid'].'">'.$posi_edit_6[$i]['name'].co("inif226").'</option><option value="">'.co("inif227").'</option>';
		}else{
			$select_6[$i]['option'] = '<option value=""></option>';
		}
	}
	for($i=0;$i<4;$i++){
		if($posi_edit_5[$i]['uid']>0){
			$select_5[$i]['option'] = '<option value="'.$posi_edit_5[$i]['uid'].'">'.$posi_edit_5[$i]['name'].co("inif226").'</option><option value="">'.co("inif227").'</option>';
		}else{
			$select_5[$i]['option'] = '<option value=""></option>';
		}
	}
	for($i=0;$i<8;$i++){
		if($posi_edit_4[$i]['uid']>0){
			$select_4[$i]['option'] = '<option value="'.$posi_edit_4[$i]['uid'].'">'.$posi_edit_4[$i]['name'].co("inif226").'</option><option value="">'.co("inif227").'</option>';
		}else{
			$select_4[$i]['option'] = '<option value=""></option>';
		}
	}
	for($i=0;$i<16;$i++){
		if($posi_edit_3[$i]['uid']>0){
			$select_3[$i]['option'] = '<option value="'.$posi_edit_3[$i]['uid'].'">'.$posi_edit_3[$i]['name'].co("inif226").'</option><option value="">'.co("inif227").'</option>';
		}else{
			$select_3[$i]['option'] = '<option value=""></option>';
		}
	}
	
	include template('zgxsh_assassin:plist/posi_edit');
  exit();
}
elseif($_GET['op']=="posi_edit_sub"){  //�����Ա����
	security::hash_if();
	$ls = security::filter($_GET);
	//ȷ�����ݼ���
	$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	//��ȡ���й���̿�
	$db_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_user['will_id']."' AND uid != '".$_G['uid']."' AND will_po != '1' AND will_po != '7'");
	if(!$db_user_all){
		prompt(co("inif209"));
	}

	
	
	//����ְ��
	for($i=0;$i<count($db_user_all);$i++){
		$db_user_all[$i]['will_po_edit'] = 2;
		if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
			poor_po::del($db_user_all[$i]['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user_all[$i]['will_po']]),co("inif222"),co("inif228"));
		}
		$change = false;  //�����ɹ���һ������
		//��ʦ
		if(!in_array($db_user_all[$i]['uid'],$existing)){  //���UID��������ִ��	
			if($db_user_all[$i]['uid'] == $ls['select_6_1'] or $db_user_all[$i]['uid'] == $ls['select_6_2']){
			  $db_user_all[$i]['will_po_edit'] = 6;
			  $existing[] = $db_user_all[$i]['uid'];
				$change = true;
				notice($db_user_all[$i]['uid'],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(6,$db_user['will_id'])."] ".co("inif214"));
				$rm .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif216")." [".will_po(6,$db_user['will_id'])."] ".co("inif217")."<br>";
				if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
					poor_po::add($db_user_all[$i]['uid'],$_TRC['poor_po_add_ext'],$_TRC['poor_po_add_val'][$db_user_all[$i]['will_po_edit']],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(6,$db_user['will_id'])."] ".co("inif214") );
				}
		  }
		}else{
			$pc .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif218")." [".will_po(6,$db_user['will_id'])."] ".co("inif217")."<br>";
		}
		//�ų�
		if(!in_array($db_user_all[$i]['uid'],$existing)){
			
			$ls['po'][1] = ($db_user_all[$i]['uid'] == $ls['select_5_1'] or $db_user_all[$i]['uid'] == $ls['select_5_2']);
			$ls['po'][2] = ($db_user_all[$i]['uid'] == $ls['select_5_3'] or $db_user_all[$i]['uid'] == $ls['select_5_4']);
			$ls['po']['true'] = ($ls['po'][1] or $ls['po'][2]);
			
			if($ls['po']['true']){
				$db_user_all[$i]['will_po_edit'] = 5;
			  $existing[] = $db_user_all[$i]['uid'];
				$change = true;
				notice($db_user_all[$i]['uid'],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(5,$db_user['will_id'])."] ".co("inif214"));
				$rm .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif216")." [".will_po(5,$db_user['will_id'])."] ".co("inif217")."<br>";
				if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
					poor_po::add($db_user_all[$i]['uid'],$_TRC['poor_po_add_ext'],$_TRC['poor_po_add_val'][$db_user_all[$i]['will_po_edit']],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(5,$db_user['will_id'])."] ".co("inif214") );
				}
			}
		}elseif(!$change){
			$pc .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif218")." [".will_po(5,$db_user['will_id'])."] ".co("inif217")."<br>";
		}
		//�ӳ�
		if(!in_array($db_user_all[$i]['uid'],$existing)){
			$ls['po'][1] = ($db_user_all[$i]['uid'] == $ls['select_4_1'] or $db_user_all[$i]['uid'] == $ls['select_4_2']);
			$ls['po'][2] = ($db_user_all[$i]['uid'] == $ls['select_4_3'] or $db_user_all[$i]['uid'] == $ls['select_4_4']);
			$ls['po'][3] = ($db_user_all[$i]['uid'] == $ls['select_4_5'] or $db_user_all[$i]['uid'] == $ls['select_4_6']);
			$ls['po'][4] = ($db_user_all[$i]['uid'] == $ls['select_4_7'] or $db_user_all[$i]['uid'] == $ls['select_4_8']);
			$ls['po']['true'] = ($ls['po'][1] or $ls['po'][2] or $ls['po'][3] or $ls['po'][4]);
			if($ls['po']['true']){
				$db_user_all[$i]['will_po_edit'] = 4;
			  $existing[] = $db_user_all[$i]['uid'];
				$change = true;
				notice($db_user_all[$i]['uid'],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(4,$db_user['will_id'])."] ".co("inif214"));
				$rm .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif216")." [".will_po(4,$db_user['will_id'])."] ".co("inif217")."<br>";
				if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
					poor_po::add($db_user_all[$i]['uid'],$_TRC['poor_po_add_ext'],$_TRC['poor_po_add_val'][$db_user_all[$i]['will_po_edit']],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(4,$db_user['will_id'])."] ".co("inif214") );
				}
			}
		}elseif(!$change){
			$pc .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif218")." [".will_po(4,$db_user['will_id'])."] ".co("inif217")."<br>";
		}
		//��Ӣ
		if(!in_array($db_user_all[$i]['uid'],$existing)){
			$ls['po'][1] = ($db_user_all[$i]['uid'] == $ls['select_3_1'] or $db_user_all[$i]['uid'] == $ls['select_3_2']);
			$ls['po'][2] = ($db_user_all[$i]['uid'] == $ls['select_3_3'] or $db_user_all[$i]['uid'] == $ls['select_3_4']);
			$ls['po'][3] = ($db_user_all[$i]['uid'] == $ls['select_3_5'] or $db_user_all[$i]['uid'] == $ls['select_3_6']);
			$ls['po'][4] = ($db_user_all[$i]['uid'] == $ls['select_3_7'] or $db_user_all[$i]['uid'] == $ls['select_3_8']);
			$ls['po'][5] = ($db_user_all[$i]['uid'] == $ls['select_3_9'] or $db_user_all[$i]['uid'] == $ls['select_3_10']);
			$ls['po'][6] = ($db_user_all[$i]['uid'] == $ls['select_3_11'] or $db_user_all[$i]['uid'] == $ls['select_3_12']);
			$ls['po'][7] = ($db_user_all[$i]['uid'] == $ls['select_3_13'] or $db_user_all[$i]['uid'] == $ls['select_3_14']);
			$ls['po'][8] = ($db_user_all[$i]['uid'] == $ls['select_3_15'] or $db_user_all[$i]['uid'] == $ls['select_3_16']);
			$ls['po'][9] = ($ls['po'][1] or $ls['po'][2] or $ls['po'][3] or $ls['po'][4]);
			$ls['po'][10] = ($ls['po'][5] or $ls['po'][6] or $ls['po'][7] or $ls['po'][8]);
			$ls['po']['true'] = ($ls['po'][9] or $ls['po'][10]);
			if($ls['po']['true']){
				$db_user_all[$i]['will_po_edit'] = 3;
			  $existing[] = $db_user_all[$i]['uid'];
				$change = true;
				notice($db_user_all[$i]['uid'],co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(3,$db_user['will_id'])."] ".co("inif214"));
				$rm .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif216")." [".will_po(3,$db_user['will_id'])."] ".co("inif217")."<br>";
				if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
					poor_po::add($db_user_all[$i]['uid'],$_TRC['poor_po_add_ext'],$_TRC['poor_po_add_val'][$db_user_all[$i]['will_po_edit']],co("inif210"),co("inif211")." [".will_po($db_user['will_po'],$db_user['will_id']).ass_name($_G['uid'])."] ".co("inif212")." [".will_name($db_user['will_id'])."] ".co("inif213")." [".will_po(3,$db_user['will_id'])."] ".co("inif214") );
				}
			}
		}elseif(!$change){
			$pc .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif218")." [".will_po(3,$db_user['will_id'])."] ".co("inif217")."<br>";
		}
		if(!$change){
			if($db_user_all[$i]['will_po'] != 2){  //���ԭ��������ͨ��Ա
				notice($db_user_all[$i]['uid'],co("inif222"),co("inif223")." [".will_po(2,$db_user['will_id'])."] ".co("inif224"));
				$md .= co("inif215")." [".ass_name($db_user_all[$i]['uid'])."] ".co("inif225")." [".will_po(2,$db_user['will_id'])."]";
			}
		}
		DB::update('zgxsh_assassin_user',array('will_po'=>$db_user_all[$i]['will_po_edit']),array('uid'=>$db_user_all[$i]['uid']));
	}
	
	if($rm){$txt .= co("inif219")."<br>".$rm;}
	if($pc){$txt .= co("inif220")."<br>".$pc;}
	if($md){$txt .= co("inif221")."<br>".$md;}
	
	prompt($txt);
}


//�̿ͼ���
elseif($_GET['op']=="user_skil"){  //�̿ͼ���
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_user){
		prompt(co('inif044'));
	}
  $skil_css_1 = $db_user['skills1']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_2 = $db_user['skills2']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_3 = $db_user['skills3']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_4 = $db_user['skills4']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_5 = $db_user['skills5']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_6 = $db_user['skills6']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_7 = $db_user['skills7']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  $skil_css_8 = $db_user['skills8']==0?'filter:Gray; -webkit-filter: grayscale(100%)':'';
  include template('zgxsh_assassin:user/user_skil');
	exit();
}
elseif($_GET['op']=="user_skil_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_user){
		prompt(co('inif044'));
	}
  $ls['sum'] += $ls['skil_add_1'];
  $ls['sum'] += $ls['skil_add_2'];
  $ls['sum'] += $ls['skil_add_3'];
  $ls['sum'] += $ls['skil_add_4'];
  $ls['sum'] += $ls['skil_add_5'];
  $ls['sum'] += $ls['skil_add_6'];
  $ls['sum'] += $ls['skil_add_7'];
  $ls['sum'] += $ls['skil_add_8'];
  if($ls['sum']<=0){
    prompt(co('inif047'));
  }
  if($ls['sum']>$db_user['skil_p']){
    prompt(co('inif048'));
  }
  $ls['uid'] = $_G['uid'];
  if(db_op::user_skil_sub($ls)){
    prompt(co('inif049'));
  }
}

//���Ե�������
elseif($_GET['op']=="attr_add"){
  security::hash_if(1);  //GET
	$ls = security::filter($_GET);
  
  db_op::attr_add($_G['uid'],$ls);
  //�ض�����ֵ
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  
  include template('zgxsh_assassin:ajax/ajax_attr');
  exit();
}

//�������
elseif($_GET['op']=="buil_on"){
	$ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  $rs = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_user['will_id']."'");
  $db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
  $db_user['will_po_name'] = will_po($db_user['will_po'],$db_user['will_id']);
  $db_user['will_name'] = will_name($db_user['will_id']);
  
  if($db_user['will_po']==1){
    prompt(co("inif244"),"location='plugin.php?id=zgxsh_assassin:index'");
  }
  
  //������
  if($ls['bh']=="buil_1"){  //����
    include template('zgxsh_assassin:buil/buil_1');
    exit();
  }elseif($ls['bh']=="buil_2"){  //����
    include template('zgxsh_assassin:buil/buil_2');
    exit();
  }elseif($ls['bh']=="buil_3"){  //ѵ��
    include template('zgxsh_assassin:buil/buil_3');
    exit();
  }elseif($ls['bh']=="buil_4"){  //��԰
    include template('zgxsh_assassin:buil/buil_4');
    exit();
  }elseif($ls['bh']=="buil_5"){  //���
    include template('zgxsh_assassin:buil/buil_5');
    exit();
  }elseif($ls['bh']=="buil_6"){  //�г�
    include template('zgxsh_assassin:buil/buil_6');
    exit();
  }elseif($ls['bh']=="buil_7"){  //��ǽ
    include template('zgxsh_assassin:buil/buil_7');
    exit();
  }elseif($ls['bh']=="buil_8"){  //����
    include template('zgxsh_assassin:buil/buil_8');
    exit();
  }
}
elseif($_GET['op']=="buil_on_sub"){
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  $db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
  //�ж��û����
  if($db_user['will_po']<2){
    prompt(co('inif242'));
  }
  //��������
  if($ls['bh']=="up_1"){  //��������
    if($db_will['buil_1']+1>10){
      prompt(co('inif050'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][1][$db_will['buil_1']-1]);
    $up = array(
      'buil_1' => intval($db_will['buil_1']+1)
    );
    $txt = co('inif051');
  }
  if($ls['bh']=="up_2"){  //��������
    if($db_will['buil_2']+1>10){
      prompt(co('inif052'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][2][$db_will['buil_2']-1]);
    $up = array(
      'buil_2' => intval($db_will['buil_2']+1),
      'popu' => intval($db_will['popu']+$_TRC['buil_up_2_effe'])
    );
    $txt = co('inif053').$_TRC['buil_up_2_effe'];
  }
  if($ls['bh']=="up_3"){  //����ѵ����
    if($db_will['buil_3']+1>10){
      prompt(co('inif054'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][3][$db_will['buil_3']-1]);
    $up = array(
      'buil_3' => intval($db_will['buil_3']+1)
    );
    $txt = co('inif055');
  }
  if($ls['bh']=="up_4"){  //�������黨԰
    if($db_will['buil_4']+1>10){
      prompt(co('inif056'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][4][$db_will['buil_4']-1]);
    $up = array(
      'buil_4' => intval($db_will['buil_4']+1)
    );
    $txt = co('inif057');
  }
  if($ls['bh']=="up_5"){  //�������Ժ
    if($db_will['buil_5']+1>10){
      prompt(co('inif058'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][5][$db_will['buil_5']-1]);
    $up = array(
      'buil_5' => intval($db_will['buil_5']+1)
    );
    $txt = co('inif059');
  }
  if($ls['bh']=="up_6"){  //�����г�
    if($db_will['buil_6']+1>10){
      prompt(co('inif060'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][6][$db_will['buil_6']-1]);
    $up = array(
      'buil_6' => intval($db_will['buil_6']+1)
    );
    $txt = co('inif061');
  }
  if($ls['bh']=="up_7"){  //������ǽ
    if($db_will['buil_7']+1>10){
      prompt(co('inif062'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][7][$db_will['buil_7']-1]);
    $up = array(
      'buil_7' => intval($db_will['buil_7']+1)
    );
    $txt = co('inif063');
  }
  if($ls['bh']=="up_8"){  //������ʦ����
    if($db_will['buil_8']+1>10){
      prompt(co('inif064'));
    }
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][8][$db_will['buil_8']-1]);
    $up = array(
      'buil_8' => intval($db_will['buil_8']+1)
    );
    $txt = co('inif065');
  }
  //��������
  elseif($ls['bh']=="bu_3"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][3][0]);
    $up = array(
      'buil_3' => 1
    );
    $txt = co('inif066');
  }
  elseif($ls['bh']=="bu_7"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][7][0]);
    $up = array(
      'buil_7' => 1
    );
    $txt = co('inif067');
  }
  elseif($ls['bh']=="bu_4"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][4][0]);
    $up = array(
      'buil_4' => 1
    );
    $txt = co('inif068');
  }
  elseif($ls['bh']=="bu_5"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][5][0]);
    $up = array(
      'buil_5' => 1
    );
    $txt = co('inif069');
  }
  elseif($ls['bh']=="bu_6"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][6][0]);
    $up = array(
      'buil_6' => 1
    );
    $txt = co('inif070');
  }
  elseif($ls['bh']=="bu_8"){
    will_f_op($db_user['will_id'],'weal',-$_TRC['buil_up_cost_setup'][8][0]);
    $up = array(
      'buil_8' => 1
    );
    $txt = co('inif071');
  }
  //��������
  elseif($ls['bh']=="use_2"){  //�ָ�����
    if($db_user['mp_v']==$db_user['mp_k']){
      prompt(co('inif072'));
    }
    
    $ls['cons'] = $_TRC['buil_use_1']+$_TRC['buil_kill_up']*$db_will['crim'];  //����������
    $ls['mp_rest'] = $db_will['buil_2']*100;  //mp�ָ���
    $ls['hp_rest'] = $db_will['buil_2']*1;  //hp�ָ���
    will_f_op($db_user['will_id'],'hono',-$ls['cons']);
    $db_user['mp_v'] += $ls['mp_rest'];  //�ظ�MP
    if($db_user['mp_v']>$db_user['mp_k']){  //��������
      $db_user['mp_v'] = $db_user['mp_k'];
    }
    $db_user['hp_v'] += $ls['hp_rest'];  //�ظ�HP
    if($db_user['hp_v']>$db_user['hp_k']){
      $db_user['hp_v'] = $db_user['hp_k'];
    }
    $up_user = array(
      'mp_v' => intval($db_user['mp_v']),
      'hp_v' => intval($db_user['hp_v']),
    );
    DB::update('zgxsh_assassin_user',$up_user,array('uid'=>$_G['uid']));
    prompt(co('inif073',array('mp_rest'=>$ls['mp_rest'],'hp_rest'=>$ls['hp_rest'],'cons'=>$ls['cons'])));
  }
  elseif($ls['bh']=="use_3"){  //�̿�ѵ��
    if($db_user['mp_v']<=0){  //û������
      prompt(co('inif074'));
    }
    $ls['hono_cons'] = $_TRC['buil_use_2']+$_TRC['buil_kill_up']*$db_will['crim'];  //����������
    $ls['mp_cons'] = $db_user['mp_v'];  //��������
    $ls['exp_add'] = $ls['mp_cons']*$db_will['buil_3']*1;  //����������
    will_f_op($db_user['will_id'],'hono',-$ls['hono_cons']);
    $up_user = array(
      'mp_v' => 0,
      'exp_v' => intval($db_user['exp_v']+$ls['exp_add']),
    );
    DB::update('zgxsh_assassin_user',$up_user,array('uid'=>$_G['uid']));
    prompt(co('inif075',array('exp_add'=>$ls['exp_add'],'mp_cons'=>$ls['mp_cons'],'hono_cons'=>$ls['hono_cons'])));
  }
  elseif($ls['bh']=="use_4"){  //ڤ�� �����ָ����������� ���ľ�������� С���ʻ�����Ե�
    if($db_user['exp_v']<=0){  //û�о���
      prompt(co('inif076'));
    }
    $ls['hono_cons'] = $_TRC['buil_use_3']+$_TRC['buil_kill_up']*$db_will['crim'];  //����������
    $ls['xp_cons'] = $db_user['exp_v'];  //��������
    $ls['mp_rest'] = $db_will['buil_4']*1;  //mp�ָ���
    $ls['hp_rest'] = $db_will['buil_4']*1;  //hp�ָ���
    will_f_op($db_user['will_id'],'hono',-$ls['hono_cons']);
    
    $db_user['mp_v'] += $ls['mp_rest'];  //�ظ�MP
    if($db_user['mp_v']>$db_user['mp_k']){  //��������
      $db_user['mp_v'] = $db_user['mp_k'];
    }
    $db_user['hp_v'] += $ls['hp_rest'];  //�ظ�HP
    if($db_user['hp_v']>$db_user['hp_k']){
      $db_user['hp_v'] = $db_user['hp_k'];
    }
    
    if(rand(0,100)<$db_will['buil_4']){  //������Ե���
      $ls['attr_p'] = 1;
      $prompt_add = "<br>[".co('inif077')."] +".$ls['attr_p'];
      $db_user['attr_p']++;
    }
    
    $up_user = array(
      'mp_v' => intval($db_user['mp_v']),
      'hp_v' => intval($db_user['hp_v']),
      'exp_v' => 0,
      'attr_p' => intval($db_user['attr_p']),
      'np_v' => 0
    );
    DB::update('zgxsh_assassin_user',$up_user,array('uid'=>$_G['uid']));
    prompt(co('inif078',array('xp_cons'=>$ls['xp_cons'],'hp_rest'=>$ls['hp_rest'],'mp_rest'=>$ls['mp_rest'],'hono_cons'=>$ls['hono_cons'])).$prompt_add.co('inif079'));
  }
  elseif($ls['bh']=="use_5"){  //�д� �������������� �������� ����������� ��ü��ܵ�
    if($db_user['hp_v']<$db_user['hp_k']){  //��������
      prompt(co('inif080'));
    }
    if($db_user['mp_v']<=0){  //û������
      prompt(co('inif081'));
    }
    $ls['hono_cons'] = $_TRC['buil_use_4']+$_TRC['buil_kill_up']*$db_will['crim'];  //����������
    $ls['xp_rest'] = $db_will['buil_5']*1;  //������
    $ls['mp_cons'] = $db_user['mp_v'];  //mp������
    $ls['hp_cons'] = rand(1,$db_user['hp_v']-1+0);  //hp������ �����д�����
    will_f_op($db_user['will_id'],'hono',-$ls['hono_cons']);
    $db_user['mp_v'] -= $ls['mp_cons'];
    $db_user['hp_v'] -= $ls['hp_cons'];
    $db_user['exp_v'] += $ls['xp_rest'];
    
    if(rand(0,100)<$db_will['buil_5']){  //������Ե���
      $ls['skil_p'] = 1;
      $prompt_add = "<br>[".co('inif082')."] +".$ls['skil_p'];
      $db_user['skil_p']++;
    }elseif($ls['hp_cons']+1==$db_user['hp_k']){
      $ls['skil_p'] = 2;
      $prompt_add = "<br>[".co('inif082')."] +".$ls['skil_p']." (".".co('inif083').".")";
      $db_user['skil_p']++;
      $db_user['skil_p']++;
    }
    $up_user = array(
      'mp_v' => intval($db_user['mp_v']),
      'hp_v' => intval($db_user['hp_v']),
      'exp_v' => intval($db_user['exp_v']),
      'skil_p' => intval($db_user['skil_p']),
    );
    DB::update('zgxsh_assassin_user',$up_user,array('uid'=>$_G['uid']));
    prompt(co('inif084',array('xp_rest'=>$ls['xp_rest'],'hp_cons'=>$ls['hp_cons'],'mp_cons'=>$ls['mp_cons'],'hono_cons'=>$ls['hono_cons'])).$prompt_add);
  }
  elseif($ls['bh']=="use_8"){  //��� ������������ɱ��
    $ls['hono_cons'] = $_TRC['buil_use_5']+$_TRC['buil_kill_up']*$db_will['crim'];  //����������
    $ls['crim_cons'] = $db_will['buil_8']+0;  //����ɱ��
    will_f_op($db_user['will_id'],'hono',-$ls['hono_cons']);
    will_f_op($db_user['will_id'],'crim',-$ls['crim_cons']);
    prompt(co('inif085',array('crim_cons'=>$ls['crim_cons'],'hono_cons'=>$ls['hono_cons'])));
  }
  
  DB::update('zgxsh_assassin_will',$up,array('id'=>$db_user['will_id']));
  prompt($txt);
}

//�½ڼ���
elseif($_GET['op']=="plot_add"){
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  
  $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  
  if($ls['bh'] > $user['plot_id']){
    if($ls['bh'] - $user['plot_id']>1){
      prompt(co('inif245'));
    }
  }
  
  if($ls['bh'] == $user['plot_id']){
    $expadd = 0;
  }else{
    $expadd = intval($user['plot_id']-1)*$_TRC['plot_exp'];
  }
  
  $up = array(
    'plot_id' => intval($ls['bh']),
    'exp_v' => $user['exp_v']+$expadd,
  );
  
  DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
  
  $co = array(
    'co1' => $ls['bh'],
    'co2' => $expadd,
  );
	$prompt = co('inif086',$co);
	
	include template('zgxsh_assassin:plot/plot_add');
	exit();
}

//����ϵͳ
elseif($_GET['op']=="item_see"){  //��
  $ls = security::filter($_GET);
  $item_db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['bh']."'");
  if(!$item_db){
    prompt(co('inif087'));
  }
  if($item_db['uid']!=$_G['uid']){
    prompt(co('inif088'));
  }
  $item_db['cl_name'] = item_class_name($item_db['class']);
  $item_db['as_name'] = ass_name($item_db['uid']);
  include template('zgxsh_assassin:back/back_see');
  exit();
}
elseif($_GET['op']=="item_equ"){  //װ
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  $item_db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['bh']."'");
  $item_db['cl_name'] = item_class_name($item_db['class']);
  if(!$item_db){
    prompt(co('inif087'));
  }
  if($item_db['uid']!=$_G['uid']){
    prompt(co('inif088'));
  }
  if($item_db['class']==1){
  if($db_user['armed_head']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_head');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_head',$item_db['id']);
    $txt = co('inif090');
  }
  }
  if($item_db['class']==2){
  if($db_user['armed_body']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_body');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_body',$item_db['id']);
    $txt = co('inif090');
  }
  }
  if($item_db['class']==3){
  if($db_user['armed_foot']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_foot');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_foot',$item_db['id']);
    $txt = co('inif090');
  }
  }
  if($item_db['class']==4){
  if($db_user['armed_weapons']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_weapons');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_weapons',$item_db['id']);
    $txt = co('inif090');
  }
  }
  if($item_db['class']==5){
  if($db_user['armed_crossbow']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_crossbow');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_crossbow',$item_db['id']);
    $txt = co('inif090');
  }
  }
  if($item_db['class']==6){
  if($db_user['armed_special']==$item_db['id']){  //ͷ �Ƿ�����ж������
    equ::del($_G['uid'],'armed_special');
    $txt = co('inif089');
  }else{
    equ::add($_G['uid'],'armed_special',$item_db['id']);
    $txt = co('inif090');
  }
  }
  $txt .= $item_db['cl_name']." [".$item_db['name']."]";
  prompt($txt);
}
elseif($_GET['op']=="item_use"){  //��
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  $item_db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['bh']."'");
  if(equ::i_use($_G['uid'],$ls['bh'])){  //ʹ��ҩƷ
    prompt(co('inif091').' ['.$item_db['name'].']');
  }  
}
elseif($_GET['op']=="item_del"){  //ɾ
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  $item_db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['bh']."'");
  if(!$item_db){
    prompt(co('inif087'));
  }
  if($item_db['uid']!=$_G['uid']){
    prompt(co('inif088'));
  }
  if(DB::delete('zgxsh_assassin_items',array('id'=>$ls['bh']),1)){
    prompt(co('inif092').' ['.$item_db['name'].'] '.co('inif093'));
  }
}

//��������
elseif($_GET['op']=="user_up"){
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_user){
    prompt(co('inif094'));
  }
  if($db_user['exp_v']<$db_user['exp_k']){
    prompt(co('inif095'));
  }
  if($db_user['lv']>=100){
    prompt(co('inif096'));
  }
  //��������
  $up = array(
    'lv' => $db_user['lv']+1,
    'exp_v' => $db_user['exp_v']-$db_user['exp_k'],
    'exp_k' => $db_user['exp_k']+100,
    'attr_p' => $db_user['attr_p']+5,
    'skil_p' => $db_user['skil_p']+1,
    'hp_k' => $db_user['hp_k']+round($db_user['hp_k']*0.01),
    'mp_k' => $db_user['mp_k']+round($db_user['mp_k']*0.04),
  );
  DB::update('zgxsh_assassin_user',$up,array('uid'=>$_G['uid']));
  prompt(co('inif097'));
}

//�ֵܻ�����ǻ�
elseif($_GET['op']=="began_reign"){
  security::hash_if(1);  //GET
  $ls = security::filter($_GET);
  if($_TRC['new_consu']>0){
	  integral($_G['uid'],-$_TRC['new_consu'],$_TRC['extid'],co('inif009'),co('inif098'));
	}
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_user){
    prompt(co('inif094'));
  }
  $db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
  if(!$db_will){
    prompt(co('inif099'));
  }
  if($db_will['w_uid']>0){
    prompt(co('inif100'));
  }
  //���������Ϊ����
  $up = array(
    'w_uid' => $_G['uid'],
  );
  DB::update('zgxsh_assassin_will',$up,array('id'=>$db_user['will_id']));
  DB::update('zgxsh_assassin_user',array('will_po'=>7),array('uid'=>$_G['uid']));
  //���ֵܻ��ڷ���Ϣ
  $no_users = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user')." WHERE uid != '".$_G['uid']."' AND will_id='".$db_user['will_id']."'");
  for($i=0;$i<count($no_users);$i++){
    $co_a = array(
      'will_po' => will_po($db_user['will_po'],$db_user['will_id']),
      'name' => $db_user['name'],
      'w_name' => $db_will['w_name']
    );
    notice($no_users[$i]['uid'],co('inif101'),co('inif102',$co_a));
  }
  $co_a = array(
    'w_name' => $db_will['w_name']
  );
  prompt(co('inif103',$co_a));
}

//�г�����Ͷ��
elseif($_GET['op']=="w_inve"){  //Ͷ��
  include template('zgxsh_assassin:trad/inve');
  exit();
}
elseif($_GET['op']=="w_trad"){  //����
  $items = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE uid = '0'");
  for($i=0;$i<count($items);$i++){
    $items[$i]['value_s'] = ceil($items[$i]['value']*1.1);
    $items[$i]['cl_name'] = item_class_name($items[$i]['class']);
      if($items[$i]['exp_k']!=0){
      $db_attr[$i][] = co('inif104').symbol($items[$i]['exp_k']);
      }
      if($items[$i]['exp_v']!=0){
      $db_attr[$i][] = co('inif105').symbol($items[$i]['exp_v']);
      }
      if($items[$i]['hp_k']!=0){
      $db_attr[$i][] = co('inif106').symbol($items[$i]['hp_k']);
      }
      if($items[$i]['hp_v']!=0){
      $db_attr[$i][] = co('inif107').symbol($items[$i]['hp_v']);
      }
      if($items[$i]['mp_k']!=0){
      $db_attr[$i][] = co('inif108').symbol($items[$i]['mp_k']);
      }
      if($items[$i]['mp_v']!=0){
      $db_attr[$i][] = co('inif109').symbol($items[$i]['mp_v']);
      }
      if($items[$i]['np_k']!=0){
      $db_attr[$i][] = co('inif110').symbol($items[$i]['np_k']);
      }
      if($items[$i]['np_v']!=0){
      $db_attr[$i][] = co('inif111').symbol($items[$i]['np_v']);
      }
      if($items[$i]['load']!=0){
      $db_attr[$i][] = co('inif112').symbol($items[$i]['load']);
      }
      if($items[$i]['attack']!=0){
      $db_attr[$i][] = co('inif113').symbol($items[$i]['attack']);
      }
      if($items[$i]['defense']!=0){
      $db_attr[$i][] = co('inif114').symbol($items[$i]['defense']);
      }
      if($items[$i]['smart']!=0){
      $db_attr[$i][] = co('inif115').symbol($items[$i]['smart']);
      }
      if($items[$i]['insight']!=0){
      $db_attr[$i][] = co('inif116').symbol($items[$i]['insight']);
      }
    $items[$i]['attr_all'] = implode("<br>",$db_attr[$i]);
  }
  $items_user = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE uid = '".$_G['uid']."'");
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  for($i=0;$i<count($items_user);$i++){
    $items_user[$i]['value_s'] = ceil($items_user[$i]['value']*($items_user[$i]['du_v']/$items_user[$i]['du_k']));  //�;��۾�
    $items_user[$i]['cl_name'] = item_class_name($items_user[$i]['class']);
    
    if($items_user[$i]['id']==$db_user['armed_head'] or $items_user[$i]['id']==$db_user['armed_body'] or $items_user[$i]['id']==$db_user['armed_foot'] or $items_user[$i]['id']==$db_user['armed_weapons'] or $items_user[$i]['id']==$db_user['armed_crossbow'] or $items_user[$i]['id']==$db_user['armed_special']){
   $items_user[$i]['armed']  = '<i class="layui-icon" style="color:#292">&#xe672;</i>';
  }
    
      if($items_user[$i]['exp_k']!=0){
      $db_attr2[$i][] = co('inif104').symbol($items_user[$i]['exp_k']);
      }
      if($items_user[$i]['exp_v']!=0){
      $db_attr2[$i][] = co('inif105').symbol($items_user[$i]['exp_v']);
      }
      if($items_user[$i]['hp_k']!=0){
      $db_attr2[$i][] = co('inif106').symbol($items_user[$i]['hp_k']);
      }
      if($items_user[$i]['hp_v']!=0){
      $db_attr2[$i][] = co('inif107').symbol($items_user[$i]['hp_v']);
      }
      if($items_user[$i]['mp_k']!=0){
      $db_attr2[$i][] = co('inif108').symbol($items_user[$i]['mp_k']);
      }
      if($items_user[$i]['mp_v']!=0){
      $db_attr2[$i][] = co('inif109').symbol($items_user[$i]['mp_v']);
      }
      if($items_user[$i]['np_k']!=0){
      $db_attr2[$i][] = co('inif110').symbol($items_user[$i]['np_k']);
      }
      if($items_user[$i]['np_v']!=0){
      $db_attr2[$i][] = co('inif111').symbol($items_user[$i]['np_v']);
      }
      if($items_user[$i]['load']!=0){
      $db_attr2[$i][] = co('inif112').symbol($items_user[$i]['load']);
      }
      if($items_user[$i]['attack']!=0){
      $db_attr2[$i][] = co('inif113').symbol($items_user[$i]['attack']);
      }
      if($items_user[$i]['defense']!=0){
      $db_attr2[$i][] = co('inif114').symbol($items_user[$i]['defense']);
      }
      if($items_user[$i]['smart']!=0){
      $db_attr2[$i][] = co('inif115').symbol($items_user[$i]['smart']);
      }
      if($items_user[$i]['insight']!=0){
      $db_attr2[$i][] = co('inif116').symbol($items_user[$i]['insight']);
      }
    $items_user[$i]['attr_all'] = implode("<br>",$db_attr2[$i]);
  }
  $see['form'] = layui::form_name();
  include template('zgxsh_assassin:trad/trad');
  exit();
}
elseif($_GET['op']=="w_inve_sub"){  //Ͷ���ύ
  security::hash_if();
  $ls = security::filter($_GET);
  $ls['v'] += 0;
  $ls['v2'] += 0;
  security::int_if($ls['v'],co('inif117'),0,1);
  security::int_if($ls['v2'],co('inif118'),0,1);
  
  //Ͷ�ʱ���
  $bd_v = inte_probe($_G['uid'],$ls['v']+$ls['v2']+$_TRC['dona_bd'],$_TRC['extid']);
  if($bd_v>0){
    $paramete['icon'] = 3;
    $co['co1'] = $_TRC['dona_bd'];
    prompt(co('inif240',$co),"location='plugin.php?id=zgxsh_assassin:index'",$paramete);
  }
  
  integral($_G['uid'],-($ls['v']+$ls['v2']),$_TRC['extid'],co('inif204'),co('inif205').($ls['v']+$ls['v2']).$_TRC["extname"]);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	//Ͷ���޶�
	if($ls['v']+$ls['v2']<$_TRC['dona_min'] and $_TRC['dona_min']>0){
		prompt(co('inif230').$_TRC['dona_min']);
	}
	user_exp($_G['uid'],($ls['v']+$ls['v2']));  //Ͷ�����Ӿ���ֵ
  $r1 = will_f_op($db_user['will_id'],'hono',$ls['v']);
  $r2 = will_f_op($db_user['will_id'],'weal',$ls['v2']);
  //prompt($ls['v']);
  if($r1 or $r2){
    $co_a = array(
      'v' => $ls['v'],
      'v2' => $ls['v2'],
      'extunit' => $_TRC['extunit'],
      'extname' => $_TRC['extname'],
    );
    prompt(co('inif119',$co_a));
  }else{
		prompt(co('inif238'));
	}
}
elseif($_GET['op']=="w_trad_sub"){  //�����ύ
  security::hash_if();
  $ls = security::filter($_GET);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  //��ȡ������Ʒ
  for($i=0;$i<count($ls['buy']);$i++){
    $buy_i[$i] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['buy'][$i]."'");
    //�ѱ�����
    if($buy_i[$i]['uid']>0){
      $co_a = array(
        'buy' => $ls['buy'][$i],
        'name' => $buy_i[$i]['name'],
      );
      prompt(co('inif120',$co_a));
    }
    $buy_i_v += ceil($buy_i[$i]['value']*1.1);
  }
  //��ȡ������Ʒ
  for($i=0;$i<count($ls['sell']);$i++){
    $sell_i[$i] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$ls['sell'][$i]."'");
    $co_a = array(
        'sell' => $ls['sell'][$i],
        'name' => $sell_i[$i]['name'],
      );
    if(!$sell_i[$i]){
      prompt(co('inif121',$co_a));
    }
    if($sell_i[$i]['uid']<>$_G['uid']){
      prompt(co('inif122',$co_a));
    }
    if($ls['sell'][$i]==$db_user['armed_head'] or $ls['sell'][$i]==$db_user['armed_body'] or $ls['sell'][$i]==$db_user['armed_foot'] or $ls['sell'][$i]==$db_user['armed_weapons'] or $ls['sell'][$i]==$db_user['armed_crossbow'] or $ls['sell'][$i]==$db_user['armed_special']){
      prompt(co('inif123',$co_a));
    }
    $sell_i_v += ceil($sell_i[$i]['value']*($sell_i[$i]['du_v']/$sell_i[$i]['du_k']));
  }
  $sum_v = $sell_i_v - $buy_i_v;
  //��Ǯ
  if($sum_v<0){
    $q = inte_probe($_G['uid'],abs($sum_v),$_TRC['extid']);
    if($q){
      $co_a = array(
        'q' => $q,
        'extunit' => $_TRC['extunit'],
        'extname' => $_TRC['extname'],
      );
      prompt(co('inif124',$co_a));
    }
  }
  
  will_f_op($db_user['will_id'],"weal",-($sum_v));
  integral($_G['uid'],$sum_v,$_TRC['extid'],co('inif125'),co('inif126'));
  //������Ʒ
  for($i=0;$i<count($ls['buy']);$i++){
    DB::update('zgxsh_assassin_items',array('uid'=>$_G['uid']),array('id'=>$ls['buy'][$i]));
  }
  //��ȡ������Ʒ
  for($i=0;$i<count($ls['sell']);$i++){
    DB::update('zgxsh_assassin_items',array('uid'=>0),array('id'=>$ls['sell'][$i]));
  }
  prompt(co('inif127'));
}

//��ͼPVP����
elseif($_GET['op']=="pvp_stea"){  //͵��
  $loca = "plugin.php?id=zgxsh_assassin:map";
  security::hash_if(1);
  $ls = security::filter($_GET);
  
  //��������
  db_op::user_mp($_G['uid'],-$_TRC['stea_mp_v']);  //������������
    
  $username = ass_name($ls['bh']);
	if($username == " -- "){
    $username = q_name($ls['bh']);
  }
	if($username == " -- "){
    prompt(co('inif128'));
  }
  
  //��ȡ˫������
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$ls['bh']."'");
  $db_iuser = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	//�ж��Է��Ƿ�����
	$db_mapt = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$ls['bh']."'");
	if(!$db_mapt){
		prompt(co('inif239'));
	}
	
  $txt = co('inif129');
  
  if(!$db_user){  //ƽ��
		//�жϾ������
	  $pm_user_ext = DB::result_first("SELECT extcredits".$_TRC['extid']." FROM ".DB::table('common_member_count')." WHERE uid = '".$ls['bh']."'");
		if($pm_user_ext<=0){  //ƽ�񸺷ֹ���
			DB::delete('zgxsh_assassin_map',array('uid'=>$ls['bh']));
			notice($ls['bh'],co('inif235'),co('inif236')."<br>"."[".co('inif150')."]-><a href='plugin.php?id=zgxsh_assassin:index'>[".co('inif151')."]");
			prompt(co('inif237'),"location='plugin.php?id=zgxsh_assassin:map&op=map_m&bh=".$ls['map']."&formhash=".FORMHASH."'");
		}
		
    $txt .= "<br>".co('inif130');
    $txt .= "<br>".co('inif131').$_TRC['stea_civi_succ']."%";
    if(rand(1,100)<$_TRC['stea_civi_succ']){  //�ɹ�
      $_TRC['stea_civi_v'] = $_TRC['stea_civi_v']<1?1:$_TRC['stea_civi_v'];  //С��1�����1
      $stea_civi_v = rand(1,$_TRC['stea_civi_v']);  //������
      $stea_civi_v -= inte_probe($ls['bh'],$stea_civi_v,$_TRC['extid']);
      integral($ls['bh'],-$stea_civi_v,$_TRC['extid'],co('inif132'),co('inif133')." [".ass_name($_G['uid'])."] ".co('inif134')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      notice($ls['bh'],co('inif135'),co('inif133')." [".ass_name($_G['uid'])."] ".co('inif134')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      integral($_G['uid'],$stea_civi_v,$_TRC['extid'],co('inif136'),co('inif137')." [".$username."] ".co('inif138')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      $txt .= "<br>".co('inif137')." [".$username."] ".co('inif138')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"];
      //��ʧ����
      $stea_civi_loss = rand($_TRC['stea_loss_min'],$_TRC['stea_loss_max']);
      $stea_civi_loss -= inte_probe($ls['bh'],$stea_civi_loss,$_TRC['extid']);
      if($_TRC['stea_loss'] and $stea_civi_loss){
        integral($_G['uid'],-$stea_civi_loss,$_TRC['extid'],co('inif140'),co('inif141')." [".$stea_civi_loss."] ".$_TRC["extunit"].$_TRC["extname"]);
        $txt .= "<br>".co('inif142')." [".$stea_civi_loss."] ".$_TRC["extunit"].$_TRC["extname"];
      }
      $prompt = co('inif143')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"].$txt;
      rank::t_add($_G['uid']);
    }
    else{  //ʧ��
      $txt .= co('inif144')."<br>[".$username."] ".co('inif145');
      if(rand(1,100)<$_TRC['stea_loss_kill']){  //��ɱ
        DB::delete('zgxsh_assassin_map',array('uid'=>$ls['bh']),1);
        //֪ͨ��ɱ
        $_TRC['stea_loss_kill_v'] = $_TRC['stea_loss_kill_v']>0?$_TRC['stea_loss_kill_v']:0;
        $_TRC['stea_loss_kill_v'] -= inte_probe($ls['bh'],$_TRC['stea_loss_kill_v'],$_TRC['extid']);
        integral($ls['bh'],-$stea_civi_v,$_TRC['extid'],co('inif146'),co('inif133')." [".ass_name($_G['uid'])."] ".co('inif137')." [".$_TRC['stea_loss_kill_v']."] ".$_TRC["extunit"].$_TRC["extname"]);
        notice($ls['bh'],co('inif135'),co('inif148')." [".ass_name($_G['uid'])."] ".co('inif149')." [".$_TRC['stea_loss_kill_v']."] ".$_TRC["extunit"].$_TRC["extname"]."<br>[".co('inif150')."]-><a href='plugin.php?id=zgxsh_assassin:index'>[".co('inif151')."]</a>");
        
        if($_TRC['stea_loss_karma']>0){  //�Ƿ�����ɱ��
          $karma_add = rand(1,$_TRC['stea_loss_karma']);
          will_f_op($db_iuser['will_id'],"crim",$karma_add);  //����ɱ��
        }
        rank::s_add($_G['uid']);
        $txt .= "<br>".co('inif152')." [".$username."] ".co('inif153')." [".$username."] ".co('inif154').$karma_add; 
      }
      else{  //����
        $txt .= "<br>".co('inif155'); 
      }
      $prompt = $txt;
    }
  }
  else{  //�̿�
    
    //�жϴ̿ͷ���
	  $pm_user_ext = DB::result_first("SELECT extcredits".$_TRC['extid']." FROM ".DB::table('common_member_count')." WHERE uid = '".$ls['bh']."'");
		if($pm_user_ext<0){  //�̿�û�з�����ʾ
			prompt(co('inif237'),"location='plugin.php?id=zgxsh_assassin:map&op=map_m&bh=".$ls['map']."'");
		}
    
    $txt .= "<br>".co('inif156');
    //����͵�Դ̿ͳɹ���
    $db_iuser['comp'] = ($db_iuser['lv']*5)+($db_iuser['smart']*5)+($db_iuser['insight']*3);
    $db_user['comp'] = ($db_user['lv']*5)+($db_user['smart']*3)+($db_user['insight']*10);
    $comp = ceil($db_iuser['comp']/$db_user['comp']*100);
    $txt .= "<br>".co('inif131').$comp."%";
    //������͵����
    if($db_iuser['skills7']>0 and $db_iuser['np_v']>=$db_iuser['np_k'] and $comp<100){
      //���ŭ��
      DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_iuser['uid']));
      //���ӳɹ���
      $comp+=$db_iuser['skills7'];
      $txt .= co('inif157').$db_iuser['skills7'];
    }
    if(rand(1,100)<$comp){  //�ɹ�
      $_TRC['stea_civi_v'] = $_TRC['stea_civi_v']<1?1:$_TRC['stea_civi_v'];  //С��1�����1
      $stea_civi_v = rand(1,$_TRC['stea_civi_v']);  //������
      $stea_civi_v -= inte_probe($ls['bh'],$stea_civi_v,$_TRC['extid']);
			$stea_civi_v = $stea_civi_v<0?0:$stea_civi_v;  //���ֽ�������ڻ��ߵ���0
      integral($ls['bh'],-$stea_civi_v,$_TRC['extid'],co('inif132'),co('inif133')." [".ass_name($_G['uid'])."] ".co('inif134')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      notice($ls['bh'],co('inif135'),co('inif133')." [".ass_name($_G['uid'])."] ".co('inif134')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      integral($_G['uid'],$stea_civi_v,$_TRC['extid'],co('inif136'),co('inif158')." [".$db_user['name']."] ".co('inif138')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"]);
      $txt .= "<br>".co('inif158')." [".$db_user['name']."] ".co('inif138')." [".$stea_civi_v."] ".$_TRC["extunit"].$_TRC["extname"];
      //��ʧ����
      $stea_civi_loss = rand($_TRC['stea_loss_min'],$_TRC['stea_loss_max']);
      $stea_civi_loss -= inte_probe($ls['bh'],$stea_civi_loss,$_TRC['extid']);
      if($_TRC['stea_loss'] and $stea_civi_loss){
        integral($_G['uid'],-$stea_civi_loss,$_TRC['extid'],co('inif140'),co('inif141')." [".$stea_civi_loss."] ".$_TRC["extunit"].$_TRC["extname"]);
        $txt .= "<br>".co('inif142')." [".$stea_civi_loss."] ".$_TRC["extunit"].$_TRC["extname"];
      }
      $prompt = co('inif143')." [".($stea_civi_v-$stea_civi_loss)."] ".$_TRC["extunit"].$_TRC["extname"].$txt;
      $prompt = $txt;
      rank::t_add($_G['uid']);
    }
    else{
      $txt .= "<br>[".$db_user['name']."]".co('inif159')."<br>";
      $txt2 .= "<br>[".$db_iuser['name']."]".co('inif160')."<br>";
      //�����ж�
      $ls['escape_chance'] = rand(0,50); //�������
      if($db_iuser['np_v']>=$db_iuser['np_k'] and $db_iuser['skills4']>0){  //��ŭ���� ����
        $ls['escape_chance'] += $db_iuser['skills4'];  //�ͷ����ټ���
        $txt .= co('inif161').$db_iuser['skills4']."%] ".co('inif162')."<br>";
        $txt2 .= $db_iuser['name'].co('inif163').$db_iuser['skills4']."%] ".co('inif164')."<br>";
        //�������ŭ��
        $db_iuser['np_v'] = 0;
        DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_iuser['id']));
      }
      if($db_user['np_v']>=$db_user['np_k'] and $db_user['skills5']>0){  //����ŭ���� ׷��
        $ls['escape_chance'] -= $db_user['skills5'];  //�ͷ�׷������
        $txt .= co('inif165').$db_user['name'].co('inif166').$db_user['skills5']."%] co('inif167')<br>";
        $txt2 .= co('inif168').$db_iuser['skills5']."%] ".co('inif169').$db_iuser['name']."<br>";
        //��պ���ŭ��
        $db_user['np_v'] = 0;
        DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_user['uid']));
      }
      if(rand(0,100)<$ls['escape_chance']){  //���ܳɹ�
        $txt .= co('inif170')."<br>";
        $txt2 .= co('inif171')."<br>";
        notice($db_user['uid'],co('inif135'),$txt2);
      }else{  //����ʧ��
        $txt .= co('inif172');
        $txt2 .= co('inif173');
        $figh = db_op::fighting($db_iuser['uid'],$db_user['uid']);
        if($figh['over'] == 'death2'){  //�Է�������
          if($db_iuser['will_id'] == $db_user['will_id']){  //ͬ����
            will_f_op($db_iuser['will_id'],"crim",$db_iuser['lv']);  //����ɱ��
            $txt .= co('inif174').$db_iuser['lv']."<br>".$figh['txt'];
          }else{  //�𹫻�
            will_f_op($db_iuser['will_id'],"hono",$db_user['lv']);  //��������
            $txt .= co('inif175').$db_user['lv']."<br>";
            rank::s_add($_G['uid']);
          }
         }
         notice($db_user['uid'],co('inif135'),$txt2);
         $txt .= $figh['txt'];
       } 
    }
  }
  //����������
  $guard = rand(0,100);
  $txt .= co('inif176');
  if($db_iuser['np_v']>=$db_iuser['np_k'] and $db_iuser['skills3']>0){  //����ŭ���� ׷��
    $guard -= $db_iuser['skills3'];  //�ͷ��ػؼ���
    $txt .= co('inif177').$db_iuser['skills3']."%";
    //����Լ�ŭ��
    $db_iuser['np_v'] = 0;
    DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_iuser['uid']));
  }
  if(rand(0,100)<$guard and $stea_civi_v>10+$stea_civi_loss){  //������׷ɱ ֻ���ڵ��ֽ�����10+��ʧ��ʱ��Żᱻ��������
    $txt .= co('inif178').$_TRC["extname"];
    $txt .= "[".$_TRC["extname"]."] -10<br>";
    $bribe = 10;
    $bribe -= inte_probe($db_iuser['uid'],$bribe,$_TRC['extid']);
    integral($db_iuser['uid'],-$bribe,$_TRC['extid'],co('inif179'),co('inif180'));
  }else{
    $txt .= co('inif181');
  }
	
	$ls['exp_rand'] = rand($_TRC['stea_exp_min'],$_TRC['stea_exp_max']);
	user_exp($_G['uid'],$ls['exp_rand']);
	//EXP��ʾ
  $txt .= "<br>EXP: +".$ls['exp_rand'];
  
  
	
  $prompt = $txt;
  include template('zgxsh_assassin:pvp/pvp_stea');
  exit();
}
elseif($_GET['op']=="pvp_kill"){  //��ɱ
  $loca = "plugin.php?id=zgxsh_assassin:map";
  security::hash_if(1);
  $ls = security::filter($_GET);
  $username = ass_name($ls['bh']);
  if($username == " -- "){
    $username = q_name($ls['bh']);
  }
	if($username == " -- "){
    prompt(co('inif182'));
  }
  db_op::user_mp($_G['uid'],-$_TRC['kill_mp_v']);  //��ɱ��������
  //����˫������
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$ls['bh']."'");
  $db_iuser = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  if(!$db_iuser){
    prompt(co('inif183'));
  }
  if(!$db_user){  //���Ǵ̿�
    $db_user['uid'] = $ls['bh'];
    $db_user['name'] = q_name($ls['bh']);
    $ls['on_ass'] = true;
  }

  $txt = co('inif184');
  
  $db_user['comp'] = ($db_user['lv']*5)+($db_user['smart']*3)+($db_user['insight']*10)+$db_user['hp_v'];
  $db_iuser['comp'] = ($db_iuser['lv']*5)+($db_iuser['smart']*3)+($db_iuser['insight']*3);
  
  $db_user['comp'] = $db_user['comp']==0?1:$db_user['comp'];
  $db_iuser['comp'] = $db_iuser['comp']==0?1:$db_iuser['comp'];
  
  $comp = ceil($db_iuser['comp']/$db_user['comp']*100);
  $txt .= "<br>".co('inif185').$comp."%<br>";
  //�ͷŰ�ɱ
  if($db_iuser['np_v']>=$db_iuser['np_k'] and $db_iuser['skills1']>0){  //����ŭ���� ׷��
    $comp += $db_iuser['skills1'];  //�ͷŰ�ɱ����
    $txt .= co('inif186').$db_iuser['skills1']."%<br>";
    //����Լ�ŭ��
    $db_iuser['np_v'] = 0;
    DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_iuser['uid']));
  }
  //�ͷž���
  if($db_user['np_v']>=$db_user['np_k'] and $db_user['skills2']>0){  //����ŭ���� ׷��
    $comp -= $db_user['skills2'];  //�ͷž�������
    $txt .= co('inif187').$db_user['skills2']."%<br>";
    //����Լ�ŭ��
    $db_user['np_v'] = 0;
    DB::update('zgxsh_assassin_user',array('np_v'=>0),array('uid'=>$db_user['uid']));
  }
  
  if(rand(1,100)<$comp){  //��ɱ�ɹ�
		
		$ls['exp_rand'] = rand($_TRC['kill_exp_min'],$_TRC['kill_exp_max']);
	  user_exp($_G['uid'],$ls['exp_rand']);
		
    notice($db_user['uid'],$_TRC['p_name'],co('plot10').$db_user['name']."] ".co('inif188')." [".$db_iuser['name']."] ".co('inif189')."<br>"."[".co('inif150')."]-><a href='plugin.php?id=zgxsh_assassin:index'>[".co('inif151')."]</a>");
    
    //��������    
    if($_TRC['poor_po'] and $_TRC['poor_po_k']){  
			poor_po::del($db_user['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user['will_po']]),co("inif222"),co("inif228"));
		}
    
    //ע����ɫ
    DB::delete('zgxsh_assassin_user',array('uid'=>$db_user['uid']));
    DB::delete('zgxsh_assassin_map',array('uid'=>$db_user['uid']));
    DB::delete('zgxsh_assassin_items',array('uid'=>$db_user['uid']));  //ɾ��������Ʒ����
    
		if($db_user['will_po']==7){  //�Է���������֪ͨ�Է�����
			$no_users = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user')." WHERE uid != '".$db_user['uid']."' AND will_id='".$db_user['will_id']."'");
			for($i=0;$i<count($no_users);$i++){
				notice($no_users[$i]['uid'],co('plot12'),co('inif190')." [".$db_iuser['name']."] ".co('inif189'));
			}
		}
		
    $db_user['lv']+=1;  //������Ϊ���ֵȼ�Ϊ0����û�н���
    
    //�Է����ݽ����ӳ�
    if($db_user['will_po']==7){  
      $will_po_jia = 10;  //����
    }elseif($db_user['will_po']==6){
      $will_po_jia = 6;  //��ʦ
    }elseif($db_user['will_po']==5){
      $will_po_jia = 2;  //�ų�
    }else{
      $will_po_jia = 1;  //����
    }
    
    if(!$ls['on_ass'] and $db_user['lv']>=$db_iuser['lv']){  //�Ǵ̿�
			if($db_user['will_id']==$db_iuser['will_id']){  //ͬ�����ɱ
				will_f_op($db_iuser['will_id'],"hono",-$db_user['lv']*10*$will_po_jia);  //��������
				will_f_op($db_iuser['will_id'],"crim",$db_user['lv']*10*$will_po_jia);  //����ɱ��
				$co_n = $db_user['lv']*10*$will_po_jia;
        $txt .= co('inif232',array('co1'=>$co_n,'co2'=>$co_n));
			}else{
				will_f_op($db_iuser['will_id'],"hono",$db_user['lv']*10*$will_po_jia);  //��������
        $txt .= co('inif191').$db_user['lv']*10*$will_po_jia;
        rank::s_add($_G['uid']);
			}
    }else{  //��ɱƽ��
			//ƽ��������
			$user_dl = 10 - inte_probe($db_user['uid'],10,$_TRC['extid']);
			integral($db_user['uid'],-$user_dl,$_TRC['extid'],$_TRC['p_name'],co("inif234",array('co1'=>$db_iuser['name'])));
			
			$ls['rand_cw'] = rand(1,2);
			if($ls['rand_cw']==1){  //50%�ĸ��ʻ��ɱ�����߲Ƹ�
				will_f_op($db_iuser['will_id'],"crim",$db_user['lv']*2*$will_po_jia);  //����ɱ��
        $txt .= co('inif192').$db_user['lv']*2*$will_po_jia;
				$txt .= "<br>".co('inif231');
			}else{
				will_f_op($db_iuser['will_id'],"weal",$db_user['lv']*10*$will_po_jia);  //���ӲƸ�
        $txt .= co('inif229').$db_user['lv']*10*$will_po_jia;
				$txt .= "<br>".co('inif231');
			}
      rank::s_add($_G['uid']);
    }
  }else{  //��ɱʧ���ж��Ƿ񿪴�
    if(!$db_user){
      $txt .= "[".$db_user['name']."] ".co('inif193');
      notice($db_user['uid'],co('inif194')," [".$db_iuser['name']."] ".co('inif195'));
    }else{
      $txt .= co('inif199');
      notice($db_user['uid'],co('inif194')," [".$db_iuser['name']."] ".co('inif196'));
      $figh = db_op::fighting($db_iuser['uid'],$db_user['uid']);
      $txt .= $figh['txt'];
      if($figh['over'] == 'death2'){  //�Է�������
        if($db_iuser['will_id'] == $db_user['will_id']){  //ͬ����
          will_f_op($db_iuser['will_id'],"crim",$db_iuser['lv']);  //����ɱ��
          $txt .= co('inif197').$db_iuser['lv']."<br>";
        }else{  //�𹫻�
          will_f_op($db_iuser['will_id'],"hono",$db_user['lv']);  //��������
          $txt .= co('inif198').$db_user['lv']."<br>";
          rank::s_add($_G['uid']);
        }
      }
    }
  }
	
	//EXP��ʾ
	$txt .= "<br>EXP: +".$ls['exp_rand'];
  
  $prompt = $txt;
  include template('zgxsh_assassin:pvp/pvp_kill');
  exit();
}

elseif($_GET['op']=="hiding"){  //�����Ѫ
  security::hash_if(1);
  
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
	if(abs($db_user['time'])+$_TRC['hiding_time']>time()){  //����ʱ���ж� �ϴβ���ʱ�������������1�첻�ò���(����)
		prompt(co('inif206')." [".dgmdate(abs($db_user['time'])+$_TRC['hiding_time'])."] ".co('inif207'));
	}
  if(($db_user['hp_v']/$db_user['hp_k']*100)>=10 and $db_user['mp_v']>=$_TRC['stea_mp_v']){  //����Ѫ �����㹻͵�� ���ܽ���ӻ���
    prompt(co('inif200',array('mp'=>$_TRC['stea_mp_v'])));
  }
  
  //�߳���ʱ�������Ա ����˳����4��
  $db_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE time < '".(time()-172800)."' AND time > '0' ORDER BY RAND() LIMIT 4");
  for($i=0;$i<count($db_user_all);$i++){
    DB::update('zgxsh_assassin_user',array('time'=>-(time())),array('uid'=>$db_user_all[$i]['uid']));
    $ls['bh'] = rand(1,5);
    db_op::map_walk($db_user_all[$i]['uid'],$ls);  //����ӽ�ĳ����ͼ
    notice($db_user_all[$i]['uid'],$_TRC['p_name'],co('inif241'));  //֪ͨ�Լ����߳���
  }
	
  DB::update('zgxsh_assassin_user',array('time'=>time()),array('uid'=>$_G['uid']));
  DB::delete('zgxsh_assassin_map',array('uid'=>$_G['uid']),1);
  prompt(co('inif201'));
}
elseif($_GET['op']=="hiding_leave"){  //�뿪�����
  security::hash_if(1);
  $db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
  
  if($db_user['time']<0){
    prompt(co('inif245'));
  }
  
  $date = floor((time()-$db_user['time'])/60);
  $hp_hf = $db_user['hp_v']+$date>$db_user['hp_k']?$db_user['hp_k']:$db_user['hp_v']+$date;
  $mp_hf = $db_user['mp_v']+$date>$db_user['mp_k']?$db_user['mp_k']:$db_user['mp_v']+$date;
  
  DB::update('zgxsh_assassin_user',array('time'=>-(time()),'hp_v'=>$hp_hf,'mp_v'=>$mp_hf),array('uid'=>$_G['uid']));
  
  prompt(co('inif202').' ['.$hp_hf.'/'.$db_user['hp_k'].']<br>'.co('inif203').' ['.$mp_hf.'/'.$db_user['mp_k'].']');
}



system_end();
?>