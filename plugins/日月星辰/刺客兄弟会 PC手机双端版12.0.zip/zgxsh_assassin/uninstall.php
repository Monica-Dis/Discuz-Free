<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.uninstall)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS cdb_zgxsh_assassin_user;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_will;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_items;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_map;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_boss;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_boss_user;
DROP TABLE IF EXISTS cdb_zgxsh_assassin_boss_news;
EOF;

runquery($sql);

$finish = true;
?>