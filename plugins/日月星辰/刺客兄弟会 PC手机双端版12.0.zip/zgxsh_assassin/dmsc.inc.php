<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$tips = '&#x514D;&#x8D39;&#x5B9A;&#x5236;,&#x552E;&#x540E;&#x670D;&#x52A1;,&#x8BF7;&#x52A0;&#x7FA4;!!! <br> QQ&#x7FA4;:976232044 <br> &#x8BF7;&#x6CE8;&#x610F; , &#x5BA2;&#x670D;&#x6309;&#x94AE;&#x6709;&#x65F6;&#x6548; , &#x8D85;&#x8FC7;1&#x5C0F;&#x65F6;&#x6211;&#x65E0;&#x6CD5;&#x4E3B;&#x52A8;&#x56DE;&#x590D;&#x60A8;&#x7684;&#x54A8;&#x8BE2; , &#x6240;&#x4EE5;&#x53EF;&#x4EE5;&#x52A0;&#x7FA4;&#x54A8;&#x8BE2;&#x76F8;&#x5173;&#x4E8B;&#x5B9C; , &#x53E6;&#x5916; , &#x7FA4;&#x91CC;&#x5076;&#x5C14;&#x4F1A;&#x53D1;&#x653E;&#x4F18;&#x60E0;&#x52B5; , &#x6216;&#x8005;&#x7EA2;&#x5305;;';
showtips($tips,'tips',true,'&#x6E29;&#x99A8;&#x63D0;&#x793A;');