<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.{modulename})] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include 'module/main.php';

$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
if(!$db_user){  //û�Ŵ�����ɫ
	include template('zgxsh_assassin:index/index_new');
	exit();
}
$db_user['works'] = a_works($db_user['works']);
$db_user['will_po_name'] = will_po($db_user['will_po'],$db_user['will_id']);
$db_user['will_name'] = will_name($db_user['will_id']);

if(!$db_user['will_id']){	
	$db_will = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_will'));
	for($i=0;$i<count($db_will);$i++){
		$db_will[$i]['name'] = q_name($db_will[$i]['w_uid']);
	}
}else{
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
	if($db_will){
		$db_will['w_lxname'] = q_name($db_will['w_uid']);
		$db_will_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_will['id']."'");
		for($i=0;$i<count($db_will_user_all);$i++){
			$db_will_user_all[$i]['will_po_name'] = will_po($db_will_user_all[$i]['will_po'],$db_will_user_all[$i]['will_id']);
			$db_will_user_all[$i]['works'] = a_works($db_will_user_all[$i]['works']);
		}
		$db_will['rs'] = count($db_will_user_all);
		if($db_will['join_way']==0){
			$db_will['join_way'] = co('plot07');
		}elseif($db_will['join_way']==1){
			$db_will['join_way'] = co('plot08');
		}elseif($db_will['join_way']==2){
			$db_will['join_way'] = co('plot15');
		}
	}
}

$map_see = map_see($_G['uid']);
map_hiding($_G['uid']);  //�����ж�

//��ɫ�Ƿ�����
if($db_user['hp_v']<=0){
  notice($_G['uid'],co('plot10').$db_user['name'].co('plot11'));
  if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
		poor_po::del($db_user['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user['will_po']]),co("inif222"),co("inif228"));
	}
  //ע����ɫ
  DB::delete('zgxsh_assassin_user',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_map',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_items',array('uid'=>$_G['uid']));  //ɾ��������Ʒ����
  
  $no_users = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user')." WHERE uid != '".$_G['uid']."' AND will_id='".$db_user['will_id']."'");
  for($i=0;$i<count($no_users);$i++){
    notice($no_users[$i]['uid'],co('plot12'),co('plot13'));
  }
  include template('zgxsh_assassin:index/index_end');
	exit();
}

//��ɫ�Ƿ��ܹ�����
if($db_user['exp_v'] >= $db_user['exp_k']){
  $see_upcl = "layui-btn-normal";
  $see_upon = "showWindow('TC','plugin.php?id=zgxsh_assassin:index_if&op=user_up&formhash=".FORMHASH."','get',0,{'cover':'1'});";
}else{
  $see_upcl = "layui-btn-disabled";
  $see_upon = "";
}

$db_map = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE uid = '".$_G['uid']."'");
$db_map['plot_id'] = DB::result_first("SELECT plot_id FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");

//��ͼϵͳ
if($_GET['op']=="map_m"){
  security::hash_if(1);
	$ls = security::filter($_GET);
  $ls['map_img_id'] = 'm'.$ls['bh'];
  $ls['map_name'] = map_name_q($ls['bh']);
  db_op::map_walk($_G['uid'],$ls);  //��ͼ�ƶ�
  //��������з����(ƽ���̿�ֻҪû�ڵ�ͼ��)
  $map_uid = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_map'));
	if(count($map_uid)<1000){  //��ͼ������Ա��������1000NPC�Żᱻ����
		for($i=0;$i<count($map_uid);$i++){
			$map_uid_arr[] = "uid != '".$map_uid[$i]['uid']."'";
		}
		//Ŀ�겻���Ǵ̿�
		$a_uid = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user'));
		for($i=0;$i<count($a_uid);$i++){
			$map_uid_arr[] = "uid != '".$a_uid[$i]['uid']."'";
		}
		$map_uid_arr[] = "extcredits".$_TRC['extid'].">0";
		$WHERE = implode(" AND ",$map_uid_arr);
		$map_uid_add = DB::result_first("SELECT uid FROM ".DB::table('common_member_count')." WHERE ".$WHERE." ORDER BY uid DESC");
		if($map_uid_add){  //������˾�����
			$map_id = rand(1,5);
			$ins = array(
				'uid' => $map_uid_add,  //��ͼ�˻�UID
				'map_id' => $map_id,  //��ͼ�˻�UID
			);
			notice($map_uid_add,co('map01'),co('map02').map_name_q($map_id).co('map03'));
			DB::insert('zgxsh_assassin_map',$ins);
		}
	}
  //��ȡ��ͼ�������
  $map_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_map')." WHERE map_id = '".$ls['bh']."' AND uid != '".$_G['uid']."'");
  //�����ȡ20���������
	$user_max = count($map_user_all)>20?20:count($map_user_all);
	$ai_uid_k = array_rand($map_user_all,$user_max);
	if($ai_uid_k>0){
		for($i=0;$i<count($ai_uid_k);$i++){
		  $map_user_20[$i] = $map_user_all[$ai_uid_k[$i]];
	  }
	  $map_user_all = $map_user_20;
	}
  
	for($i=0;$i<count($map_user_all);$i++){
    $map_user_all[$i]['user'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$map_user_all[$i]['uid']."'");
    if(!$map_user_all[$i]['user']){
      $map_user_all[$i]['will_admin'] = co('map04');
      $map_user_all[$i]['user']['name'] = q_name($map_user_all[$i]['uid']);
      $map_user_all[$i]['user']['hp_k'] = 100;
      $map_user_all[$i]['user']['hp_v'] = 100;
    }else{
      $map_user_all[$i]['will_admin'] = will_name($map_user_all[$i]['user']['will_id']);
    }
  }
	//print_r($ai_uid_k);
	
  include template('zgxsh_assassin:map/map_m');	
	exit();
}


include template('zgxsh_assassin:map/map');
?>