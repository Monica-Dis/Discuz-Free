<?php
/**
 *	[�̿��ֵܻ�(zgxsh_assassin.{modulename})] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0 ����
 *	Date: 2019-3-18 15:39
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include 'module/main.php';

$db_user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE uid = '".$_G['uid']."'");
if(!$db_user){  //û�Ŵ�����ɫ
	include template('zgxsh_assassin:index/index_new');
	exit();
}
$db_user['works'] = a_works($db_user['works']);
$db_user['will_po_name'] = will_po($db_user['will_po'],$db_user['will_id']);
$db_user['will_name'] = will_name($db_user['will_id']);

if(!$db_user['will_id']){	
	$db_will = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_will'));
	for($i=0;$i<count($db_will);$i++){
		$db_will[$i]['name'] = q_name($db_will[$i]['w_uid']);
	}
}else{
	$db_will = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_will')." WHERE id = '".$db_user['will_id']."'");
	if($db_will){
		$db_will['w_lxname'] = q_name($db_will['w_uid']);
		$db_will_user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_user')." WHERE will_id = '".$db_will['id']."'");
		for($i=0;$i<count($db_will_user_all);$i++){
			$db_will_user_all[$i]['will_po_name'] = will_po($db_will_user_all[$i]['will_po'],$db_will_user_all[$i]['will_id']);
			$db_will_user_all[$i]['works'] = a_works($db_will_user_all[$i]['works']);
		}
		$db_will['rs'] = count($db_will_user_all);
		if($db_will['join_way']==0){
			$db_will['join_way'] = co('plot07');
		}elseif($db_will['join_way']==1){
			$db_will['join_way'] = co('plot08');
		}elseif($db_will['join_way']==2){
			$db_will['join_way'] = co('plot15');
		}
	}
}

$map_see = map_see($_G['uid']);
map_hiding($_G['uid']);  //�����ж�

//��ɫ�Ƿ�����
if($db_user['hp_v']<=0){
  notice($_G['uid'],co('plot10').$db_user['name'].co('plot11'));
	if($_TRC['poor_po'] and $_TRC['poor_po_k']){  //��������
		poor_po::del($db_user['uid'],$_TRC['poor_po_add_ext'],-($_TRC['poor_po_add_val'][$db_user['will_po']]),co("inif222"),co("inif228"));
	}
  
  
  //ע����ɫ
  DB::delete('zgxsh_assassin_user',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_map',array('uid'=>$_G['uid']),1);
  DB::delete('zgxsh_assassin_items',array('uid'=>$_G['uid']));  //ɾ��������Ʒ����
  
  $no_users = DB::fetch_all("SELECT uid FROM ".DB::table('zgxsh_assassin_user')." WHERE uid != '".$_G['uid']."' AND will_id='".$db_user['will_id']."'");
  for($i=0;$i<count($no_users);$i++){
    notice($no_users[$i]['uid'],co('plot12'),co('plot13'));
  }
  include template('zgxsh_assassin:index/index_end');
	exit();
}

//��ɫ�Ƿ��ܹ�����
if($db_user['exp_v'] >= $db_user['exp_k']){
  $see_upcl = "layui-btn-normal";
  $see_upon = "showWindow('TC','plugin.php?id=zgxsh_assassin:index_if&op=user_up&formhash=".FORMHASH."','get',0,{'cover':'1'});";
}else{
  $see_upcl = "layui-btn-disabled";
  $see_upon = "";
}

//���߿��ȡ
$items = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE uid = '".$_G['uid']."'");
for($i=0;$i<count($items);$i++){
  $items[$i]['cl_name'] = item_class_name($items[$i]['class']);
  if($items[$i]['id']==$db_user['armed_head'] or $items[$i]['id']==$db_user['armed_body'] or $items[$i]['id']==$db_user['armed_foot'] or $items[$i]['id']==$db_user['armed_weapons'] or $items[$i]['id']==$db_user['armed_crossbow'] or $items[$i]['id']==$db_user['armed_special']){
   $items[$i]['armed']  = '<i class="layui-icon" style="color:#292">&#xe672;</i>';
  }
}
$db_user['load_v'] = count($items);
if($db_user['load_v']>=$db_user['load']){
  $db_user['load_v'] = "<b style='color:#F00'>".$db_user['load_v']."</b>";
}

$db_user['armed_head_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_head']."'");
$db_user['armed_body_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_body']."'");
$db_user['armed_foot_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_foot']."'");
$db_user['armed_weapons_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_weapons']."'");
$db_user['armed_crossbow_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_crossbow']."'");
$db_user['armed_special_db'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_assassin_items')." WHERE id = '".$db_user['armed_special']."'");
if($db_user['armed_head_db']['name']==""){
  $db_user['armed_head_db']['name'] = co('back01');
  $db_user['armed_head_db']['du_k'] = 0;
  $db_user['armed_head_db']['du_v'] = 0;
}
if($db_user['armed_body_db']['name']==""){
  $db_user['armed_body_db']['name'] = co('back01');
  $db_user['armed_body_db']['du_k'] = 0;
  $db_user['armed_body_db']['du_v'] = 0;
}
if($db_user['armed_foot_db']['name']==""){
  $db_user['armed_foot_db']['name'] = co('back01');
  $db_user['armed_foot_db']['du_k'] = 0;
  $db_user['armed_foot_db']['du_v'] = 0;
}
if($db_user['armed_weapons_db']['name']==""){
  $db_user['armed_weapons_db']['name'] = co('back01');
  $db_user['armed_weapons_db']['du_k'] = 0;
  $db_user['armed_weapons_db']['du_v'] = 0;
}
if($db_user['armed_crossbow_db']['name']==""){
  $db_user['armed_crossbow_db']['name'] = co('back01');
  $db_user['armed_crossbow_db']['du_k'] = 0;
  $db_user['armed_crossbow_db']['du_v'] = 0;
}
if($db_user['armed_special_db']['name']==""){
  $db_user['armed_special_db']['name'] = co('back01');
  $db_user['armed_special_db']['du_k'] = 0;
  $db_user['armed_special_db']['du_v'] = 0;
}

include template('zgxsh_assassin:forg/forg');
?>