<?php
/**
 *	[��ڰ�֮�����ֱ�(zgxsh_sxsb.install)] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: 1.0
 *	Date: 2019-4-5 13:56
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_sxsb_zj`;
CREATE TABLE `cdb_zgxsh_sxsb_zj` (
  `id` int(10) NOT NULL default '0',
  `jr` int(10) NOT NULL,
  `time` int(20) NOT NULL,
  `uid_l` varchar(3000) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_sxsb_rank`;
CREATE TABLE `cdb_zgxsh_sxsb_rank` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `f` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT;
EOF;

runquery($sql);
$finish = true;
?>