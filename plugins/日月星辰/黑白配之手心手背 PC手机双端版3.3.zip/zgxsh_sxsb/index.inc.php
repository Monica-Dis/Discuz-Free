<?php
/**
 *	[�����ֱ�(zgxsh_sxsb.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include 'module/main.php';

$db = war_monitoring();
$uid_l = unserialize($db['uid_l']);
$AQ = new AQ();

$LS['rs'] = 0;
for($i=1;$i<=24;$i++){
  if($uid_l[$i]['uid']){
    $LS['rs']++;
    $ls['ai_f'][] = "a.uid != '".$uid_l[$i]['uid']."'";
    $uid_l[$i]['img'] = avatar($uid_l[$i]['uid'],'',1);
    if($uid_l[$i]['uid']==$_G['uid']){
      $LS['cp'] = $uid_l[$i]['cp']==1?1:2;
    }
    $uid_l[$i]['box'] = 'box-shadow:0px 0px 0px 0px rgba(44,44,44,0.00)';
  }else{
    $uid_l[$i]['img'] = 'source/plugin/zgxsh_sxsb/template/img/tx1.png';
    $uid_l[$i]['box'] = 'box-shadow:0px 0px 0px 0px rgba(44,44,44,0.44)';
  }
  if($uid_l[$i]['cp']==1){  //�ڰ׼���
    $LS['tj']['h'] += 1; 
  }elseif($uid_l[$i]['cp']==2){
    $LS['tj']['b'] += 1;
  }
	if($i<=12){
		$uid_l_s[$i] = $uid_l[$i];
	}else{
		$uid_l_x[$i] = $uid_l[$i];
	}
}



if($LS['rs']>=$_TRC['SYS_RS']){  //��������
  $TS = co('inde16')."<br>";
  $ls['url'] = 'full_sub';
  include template('zgxsh_sxsb:index/index_if');
  exit();
}else{ //��û��
  loadcache('zgxsh_sxsb');
  if($_G['cache']['zgxsh_sxsb']['ai_time']<=0){
    $CA['ai_time'] = time();
    savecache('zgxsh_sxsb',$CA);
    loadcache('zgxsh_sxsb');
  }
  //�Ƿ���AI���ܲ�ս �������˲ż���AI ���1����
  if($_TRC['SYS_AI'] and $LS['rs']>0 and time()-$_G['cache']['zgxsh_sxsb']['ai_time']>60){ 
    $ls['ext'] = 'extcredits'.$_TRC['SYS_JFX'];
    $ls['jr'] = $_TRC['SYS_JR'];
    $ls['WHERE'] = implode(' AND ',$ls['ai_f']);
    $AI_UID = DB::result_first( "SELECT a.uid FROM " . DB::table( 'common_member_status' ) . " a," . DB::table( 'common_member_count' ) . " b WHERE a.lastvisit < '" . ( time() - 604800 ) . "' AND b.".$ls['ext']." >= ".$ls['jr']." AND a.uid = b.uid AND ".$ls['WHERE']);
    
    if($AI_UID){
      $db['jr'] += $_TRC['SYS_JR'];
      sys_integral($AI_UID,-$_TRC['SYS_JR'],$_TRC);
      $uid_l = unserialize($db['uid_l']);
      //����ձ��
      for($i=1;$i<=count($uid_l);$i++){
        if($uid_l[$i]['uid'] <= 0){
          $LS['bh'] = $i;
          break;
        }
      }
      $uid_l[$LS['bh']]['uid'] = $AI_UID;
      $uid_l[$LS['bh']]['name'] = cx_username($AI_UID);
      $uid_l[$LS['bh']]['cp'] = rand(1,2);
      $db['uid_l'] = serialize($uid_l);

      if(!$db['time']){
        $db['time'] = time()+$_TRC['SYS_TIME'];  //����������
      }
      $fsarr = array('subject' => co('inde18') , 'message' => co('inde19'));
      notification_add($AI_UID, 'system', 'system_notice', $fsarr, 1);
      DB::update('zgxsh_sxsb_zj',$db,array('id'=>1));
    }
    $CA['ai_time'] = time();
    savecache('zgxsh_sxsb',$CA);
  }
}

if($db['time']<=time() and $_TRC['SYS_TIME']>0 and $db['time']<>0){//ǿ������
  $TS = co('inde17')."<br>";
  $ls['url'] = 'flow_bureau';
  include template('zgxsh_sxsb:index/index_if');
  exit();
}else{
  $db['time'] = $db['time']*1000;
}

$LS['SL'] = $_TRC['SYS_SF']*100;

//----[���а�]----
$rank = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_sxsb_rank')." ORDER BY f DESC LIMIT 10");
for($i=0;$i<10;$i++){
	$rank[$i]['pm'] = "<b>TOP.".($i+1)."</b>";  //����
	$rank[$i]['name'] = cx_username($rank[$i]['uid']);  //�û���
	if(!$rank[$i]['f']){
		$rank[$i]['f'] = 0;
	}
}
//----[�Լ�����]----
$rank_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_sxsb_rank')." ORDER BY f DESC");
for($i=0;$i<count($rank_all);$i++){
	if($rank_all[$i]['uid']==$_G['uid']){
		$rank_zj = ($i+1);
		break;
	}else{
		$rank_zj = 0;
	}
}

include template('zgxsh_sxsb:index/index');
?>