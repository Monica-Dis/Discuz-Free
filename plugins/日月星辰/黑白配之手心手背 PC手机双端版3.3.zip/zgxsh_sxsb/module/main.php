<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

function co($txt){
	global $_G;
  $a = lang('plugin/zgxsh_sxsb',$txt);
  return $a;
}

//--------[��������߼�]--------
if(!$_G['cache']['plugin']['zgxsh_sxsb']['SYS_JFX']){
  global $_G;
  $TS = co('main02');
  include template('zgxsh_sxsb:index/index_ts');
  exit();
}
//--------[��������߼�]--------


//----[ϵͳ����]----
$_TRC = $_G['cache']['plugin']['zgxsh_sxsb'];
$_TRC['MAIN_JFX_CName'] = $_G['setting']['extcredits'][$_TRC['SYS_JFX']]['title'];  
$_TRC['MAIN_JFX_Logo'] = $_G['setting']['extcredits'][$_TRC['SYS_JFX']]['img']; 
$_TRC['MAIN_JFX_unit'] = $_G['setting']['extcredits'][$_TRC['SYS_JFX']]['unit']; 
$_TRC['MAIN_JFZ'] = getuserprofile('extcredits'.$_TRC['SYS_JFX']);
//$_TRC['SYS_RS'] = 2;
//��������
$_TRC['SYS_width'] += 0;
$_TRC['SYS_width'] = $_TRC['SYS_width']<960?960:$_TRC['SYS_width'];
$_TRC['SYS_width'] = $_TRC['SYS_width']>1170?1170:$_TRC['SYS_width'];
$_TRC['SYS_width'] -= 30;
//----[ϵͳ����]----

//ҳ������
$navtitle = $_TRC['SYS_PNAME'];


//--------[ϵͳ����]--------
function system_end($T){
  global $_G;
  $TS = co('main01').$T;
  include template('zgxsh_sxsb:ts/ts');
  exit();
}

function cx_username($UID){  //��ѯ�ǳ�
  $Trid = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '".$UID."'");
	$Trid = $Trid==""?" <em style='color:rgba(80,80,80,0.50)'><".co('main04')."></em> ":$Trid;
	return $Trid;
}

function sys_integral($UID,$SZ,$_TRC){  //���ֲ���
  global $_G;
	//�������˻��ֵ��ò���getuserprofile����
  $JFDQ = DB::result_first("SELECT extcredits".$_TRC['SYS_JFX']." FROM ".DB::table('common_member_count')." WHERE uid = '".$UID."'"); 
	if(!$JFDQ){
    $JFDQ = 0;  
  }
  if($JFDQ+$SZ<0 and $SZ<0){
    $TS = co('main05');
    include template('zgxsh_sxsb:ts/ts');
    exit();
  }
  updatemembercount($UID,array('extcredits'.$_TRC['SYS_JFX']=>$SZ),true,'',0,'',co('if09'),co('inde12'));
	return $Trid;
}
//--------[ϵͳ����]--------

//----���а�÷ֺ���----
function rank_ud($uid,$n){
	$rank = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_sxsb_rank')." WHERE uid='".$uid."'");
	if(!$rank){
		DB::insert('zgxsh_sxsb_rank',array('uid'=>$uid,'f'=>$n));
	}else{
		$rank['f'] += $n;
		DB::update('zgxsh_sxsb_rank',array('f'=>$rank['f']),array('uid'=>$uid));
	}
	return true;
}

function war_monitoring(){
  $db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_sxsb_zj')." WHERE id = '1'");

  if(!$db){
    for($i=1;$i<=24;$i++){
      $uid_l[$i]['uid'] = 0;
      $uid_l[$i]['name'] = "<em style='color:rgba(80,80,80,0.50)'><".co('main04')."></em>";
      $uid_l[$i]['cp'] = 0;
    }
    $db['uid_l'] = serialize($uid_l);
    $db['jr'] = 0;
    $db['time'] = 0;

    $ins = array(  //���ⲿ����
      'id' => 1,
      'jr' => 0,
      'time' => 0,
      'uid_l' => $db['uid_l']
    );

    DB::insert('zgxsh_sxsb_zj',$ins);
    $db = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_sxsb_zj')." WHERE id = '1'");
  }
  return $db;
}

class AQ {  //��ȫ��֤��
   
  function ck($GB){
    global $_G;
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    $LS['uid'] = dhtmlspecialchars($GB['uid']);
    if(!$LS['bh']){
      $TS = co('main06');
      include template('zgxsh_sxsb:ts/ts');
      exit();
    }
    return $LS;
  }
  
  function join_sub($GB){
    global $_G;
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    $LS['cq'] = dhtmlspecialchars($GB['cq']);
    if(!$LS['bh']){
      $TS = co('main06');
      include template('zgxsh_sxsb:ts/ts');
      exit();
    }
    if(!$LS['cq']){
      $TS = co('main07');
      include template('zgxsh_sxsb:ts/ts');
      exit();
    }
    return $LS;
  }
  function eagle_eye_sub($GB){
    global $_G;
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    if(!$LS['bh']){
      $TS = co('main06');
      include template('zgxsh_sxsb:ts/ts');
      exit();
    }
    return $LS;
  }  
  
  //��� ��ֵ intval() ���� daddslashes()
  
  function release_ins($ins){
    if($ins['lz_uid']){$ins['lz_uid'] = intval($ins['lz_uid']);}
    if($ins['lz_time']){$ins['lz_time'] = intval($ins['lz_time']);}
    if($ins['lz_sz']){$ins['lz_sz'] = intval($ins['lz_sz']);}
    return $ins;
  }
  
}
//From: Dism��taobao��com
?>