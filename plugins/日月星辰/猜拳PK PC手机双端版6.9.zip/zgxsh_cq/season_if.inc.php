<?php
/**
 *	[��ȭPK(zgxsh_cq.{modulename})] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';

$security = new bl_yz();

if($_GET['cz']=="system"){  //������չ��ҳ
  $see['rand'] = rand(1,99999);
  $see['form'] = "var form".$see['rand']." = layui.form;form".$see['rand'].".render();";
	
	$season = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state != '0'");
	for($i=0;$i<count($season);$i++){
		$season[$i]['date'] = dgmdate($season[$i]['time']);
		$season[$i]['dsdate'] = dgmdate($season[$i]['dstime']);
		if($season[$i]['state']==1){
			$season[$i]['state_cn'] = co('seaenh01');
		}elseif($season[$i]['state']==2){
			$season[$i]['state_cn'] = co('seaenh02');
		}else{
			$season[$i]['state_cn'] = co('seaenh03');
		}
	}

  include template('zgxsh_cq:season_enh/season_enh');
  exit();
}
elseif($_GET['cz']=="season_name_edit"){  //������չ�޸�������
	$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE id = '".$_GET['bh']."' AND state != '0'");
	if(!$season){  //��������
		$text .= co('seaenh04');
	  include template('zgxsh_cq:ts/ts');
    exit();
	}
	
  include template('zgxsh_cq:season_enh/season_name_edit');
  exit();
}
elseif($_GET['cz']=="season_name_edit_sub"){  //������չ�޸�������
	$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE id = '".$_GET['bh']."' AND state != '0'");
	if(!$season){  //��������
		$text .= co('seaenh04');
	  include template('zgxsh_cq:ts/ts');
    exit();
	}
	if(!$_GET['name']){  //��������
		$text .= co('seaenh05');
	  include template('zgxsh_cq:ts/ts');
    exit();
	}
	DB::update('zgxsh_cq_season',array('name'=>dhtmlspecialchars($_GET['name'])),array('id'=>dhtmlspecialchars($_GET['bh'])));
	$text .= co('seaenh06');
	include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="season_enh_add"){  //���Ӷ�ʱ����
	//����������
	$see['rand'] = rand(1,99999);
  $see['form'] = "var form".$see['rand']." = layui.form;form".$see['rand'].".render();";
	//ѡ��������
	for($i=1;$i<=8;$i++){
		if($_G['setting']['extcredits'][$i]['title']){
		  $option .= "<option value='".$i."'>".$_G['setting']['extcredits'][$i]['title']."</option>";
		}
	}
	//��������ִ������
  include template('zgxsh_cq:season_enh/season_enh_add');
  exit();
}
elseif($_GET['cz']=="season_enh_add_sub"){  //���Ӷ�ʱ����
	if(!submitcheck('formhash')){
		$text = co('main04');
		include template('zgxsh_cq:ts/ts');
		exit();
	}

	if(!$_GET['name']){
		$text = co('inde33');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if(!$_GET['time'] or strtotime($_GET['time'])<time()){
		$text = co('inde34');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if((!$_GET['m_reward'][1]['ext'] or !$_GET['m_reward'][1]['v']) and (!$_GET['p_reward']['ext'] or !$_GET['p_reward']['v'])){
		$text = co('inde35');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if(strtotime($_GET['time'])<=strtotime($_GET['dstime'])){  //����ʱ��С�ڿ�ʼʱ��
		$text = co('seaenh07');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if(strtotime($_GET['dstime'])<=0){  //��ʼʱ��û����д
		$text = co('seaenh08');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
  
	$security -> season_add($_GET);

	$text = co('seaenh09');
	include template('zgxsh_cq:ts/ts');
  exit();
}

system_end();
?> 