<?php
/**
 *	[��ȭPK(zgxsh_cq.install)] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_cq_user`;
CREATE TABLE `cdb_zgxsh_cq_user` (
  `uid` int(10) NOT NULL,
  `cqjf` int(20) NOT NULL default '0',
  `s` int(20) NOT NULL default '0',
  `f` int(20) NOT NULL default '0',
  `p` int(20) NOT NULL default '0',
  `obta` int(20) NOT NULL default '0',
  `lose` int(20) NOT NULL default '0',
  `tax` int(20) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_cq_xx`;
CREATE TABLE `cdb_zgxsh_cq_xx` (
  `id` int(10) NOT NULL auto_increment,
  `x_nr` varchar(255) NOT NULL,
  `x_time` int(20) NOT NULL,
  `x_lx` int(2) NOT NULL,
  `uid` int(20) NOT NULL,
  `j_id` int(20) NOT NULL,
  `v` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_cq_zjb`;
CREATE TABLE `cdb_zgxsh_cq_zjb` (
  `id` int(10) NOT NULL auto_increment,
  `lz_uid` int(10) NOT NULL,
  `lz_time` int(20) NOT NULL,
  `lz_sz` int(1) NOT NULL,
  `lz_cm` int(20) NOT NULL,
  `lz_sd` int(1) NOT NULL,
  `spf_setup` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_cq_season`;
CREATE TABLE `cdb_zgxsh_cq_season` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(20),
  `time` int(20) NOT NULL,
  `m_reward` varchar(500) NOT NULL,
  `p_reward` varchar(200) NOT NULL,
  `state` int(1) NOT NULL default '1',
  `dstime` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_cq_profit`;
CREATE TABLE `pre_zgxsh_cq_profit` (
  `id` int(10) NOT NULL auto_increment,
  `v` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

runquery($sql);
$finish = true;
?>