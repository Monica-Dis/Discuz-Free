<?php
/**
 *	[��ȭPK(zgxsh_cq.{modulename})] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//TODO - Insert your code here
include 'module/main.php';

cheating();

loadcache('zgxsh_cq');

//----[����]----
if($_TRC['rank_cl']==1){
  if(time() - $_G['cache']['zgxsh_cq']['phtime'] > $_TRC['SYS_CACHE_TIME']){
    $ph = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY s DESC,p DESC,f ASC LIMIT 12");
    for($i=0;$i<count($ph);$i++){
      $ph[$i]['zh'] = $ph[$i]['s']*3 + $ph[$i]['p']*2 + $ph[$i]['f']*1;
      if($i == 0){
        $ph[$i]['ys'] = 'color: rgba(255,100,0,1.00)';
      }elseif($i == 1){
        $ph[$i]['ys'] = 'color: rgba(255,140,0,1.00)';
      }elseif($i == 2){
        $ph[$i]['ys'] = 'color: rgba(255,180,0,1.00)';
      }else{
        $ph[$i]['ys'] = '';
      }
      $ph[$i]['cname'] = cx_username($ph[$i]['uid']);
      $ph[$i]['TOP'] = $i+1;
    }
    $CA['ph'] = $ph;
    $CA['phtime'] = time();
    savecache('zgxsh_cq',$CA);
  }else{
    $ph = $_G['cache']['zgxsh_cq']['ph'];
  }
}elseif($_TRC['rank_cl']==2 and $_TRC['obta_lose']){
  $obta = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY obta DESC LIMIT 10");
  for($i=0;$i<count($obta);$i++){
    $obta[$i]['cname'] = cx_username($obta[$i]['uid']);
  }
  $lose = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY lose DESC LIMIT 10");
  for($i=0;$i<count($lose);$i++){
    $lose[$i]['cname'] = cx_username($lose[$i]['uid']);
  }
  $obta_lose_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." WHERE obta>0 AND lose>0");
  for($i=0;$i<count($obta_lose_all);$i++){
    $obta_lose_all[$i]['cname'] = cx_username($obta_lose_all[$i]['uid']);
  }
}elseif($_TRC['rank_cl']==3 and $_TRC['tax_fee']){
  $tax_fee = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY tax DESC LIMIT 10");
  for($i=0;$i<count($tax_fee);$i++){
    $tax_fee[$i]['cname'] = cx_username($tax_fee[$i]['uid']);
  }
  $tax_fee_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." WHERE tax>0");
  for($i=0;$i<count($tax_fee_all);$i++){
    $tax_fee_all[$i]['cname'] = cx_username($tax_fee_all[$i]['uid']);
  }
}


$ph_zj = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY s DESC,p DESC,f DESC");
for($i=0;$i<count($ph_zj);$i++){
  if($ph_zj[$i]['uid']==$_G['uid']){
    $ph_zj_c = "[TOP.".($i+1)."]";  
  }
}
//----[ս���б�]----

$db_round= DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_zjb')." LIMIT 0,10");
$count_zj = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_cq_zjb'));
for($i=0;$i<10;$i++){
  if($_TRC['SYS_HOT']){
    $db_round[$i]['dates'] = !$db_round[$i]['lz_time']?" -- ":$_TRC['SYS_HOT_TXT'];
  }else{
    $db_round[$i]['dates'] = !$db_round[$i]['lz_time']?" -- ":dgmdate($db_round[$i]['lz_time'],'u');
  }
  $db_round[$i]['datets'] = date('Y-m-d H:i:s',$db_round[$i]['lz_time']);
  $db_round[$i]['name'] = cx_username($db_round[$i]['lz_uid']);  //���ﲻ���������������
  if($db_round[$i]['lz_uid']==$_G['uid']){
    $db_round[$i]["cl"] = "layui-btn-danger";
    $db_round[$i]["on"] = "del";
    $db_round[$i]["co"] = co('inif03');
  }elseif($db_round[$i]['id']){
    $db_round[$i]["cl"] = "layui-btn-primary";
    $db_round[$i]["on"] = "than";
    $db_round[$i]["co"] = co('inif04');
  }else{
    $db_round[$i]["cl"] = "";
    $db_round[$i]["on"] = "";
    $db_round[$i]["co"] = "";
  }
  if($db_round[$i]['lz_uid']==$_G['uid'] and $db_round[$i]['lz_sd']){  //�Լ���ս����ʾʥ��
    $db_round[$i]["see_sd"] = '<div class="layui-anim layui-anim-scaleSpring layui-inline"><i class="layui-icon">&#xe672;</i></div>';
  }
}

//----[������ʾ]----
$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state = '1'");
$season['m_reward_v'] = unserialize($season['m_reward']);
$season['p_reward_v'] = unserialize($season['p_reward']);
if($season['time']>0 and $season['time']<time()){
  
  if(!discuz_process::islocked('season')) {
	
    
	
	$ls['name'] = $season['name'];
  
  //���з���ģʽ
  
  if($_TRC['obta_lose'] and $_TRC['rank_cl']==2){
    for($i=0;$i<count($obta);$i++){
      if($season['m_reward_v'][1]['ext'] and $season['m_reward_v'][1]['v']>0 and $i==0){  //��������
        updatemembercount($obta[$i]['uid'],array("extcredits".$season['m_reward_v'][1]['ext']=>$season['m_reward_v'][1]['v']),true,'',0,'',co('inde13'),co('inde15'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde21')." [".$season['m_reward_v'][1]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][1]['ext']]['title']."]");
        notification_add($obta[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no1'] = cx_username($obta[$i]['uid']);
      }
      elseif($season['m_reward_v'][2]['ext'] and $season['m_reward_v'][2]['v']>0 and $i==1){
        updatemembercount($obta[$i]['uid'],array("extcredits".$season['m_reward_v'][2]['ext']=>$season['m_reward_v'][2]['v']),true,'',0,'',co('inde13'),co('inde16'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde22')." [".$season['m_reward_v'][2]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][2]['ext']]['title']."]");
        notification_add($obta[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no2'] = cx_username($obta[$i]['uid']);
      }
      elseif($season['m_reward_v'][3]['ext'] and $season['m_reward_v'][3]['v']>0 and $i==2){
        updatemembercount($obta[$i]['uid'],array("extcredits".$season['m_reward_v'][3]['ext']=>$season['m_reward_v'][3]['v']),true,'',0,'',co('inde13'),co('inde17'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde23')." [".$season['m_reward_v'][3]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][3]['ext']]['title']."]");
        notification_add($obta[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no3'] = cx_username($obta[$i]['uid']);
      }
    }
    for($i=0;$i<count($lose);$i++){
      if($_TRC['m_reward_v'][1]['ext'] and $_TRC['m_reward_v'][1]['v']>0 and $i==0){  //��������
        updatemembercount($lose[$i]['uid'],array("extcredits".$_TRC['m_reward_v'][1]['ext']=>$_TRC['m_reward_v'][1]['v']),true,'',0,'',co('inde13'),co('inde15'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde21')." [".$_TRC['m_reward_v'][1]['v'].$_G['setting']['extcredits'][$_TRC['m_reward_v'][1]['ext']]['title']."]");
        notification_add($lose[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no1'] = cx_username($lose[$i]['uid']);
      }
      elseif($_TRC['m_reward_v'][2]['ext'] and $_TRC['m_reward_v'][2]['v']>0 and $i==1){
        updatemembercount($lose[$i]['uid'],array("extcredits".$_TRC['m_reward_v'][2]['ext']=>$_TRC['m_reward_v'][2]['v']),true,'',0,'',co('inde13'),co('inde16'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde22')." [".$_TRC['m_reward_v'][2]['v'].$_G['setting']['extcredits'][$_TRC['m_reward_v'][2]['ext']]['title']."]");
        notification_add($lose[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no2'] = cx_username($lose[$i]['uid']);
      }
      elseif($_TRC['m_reward_v'][3]['ext'] and $_TRC['m_reward_v'][3]['v']>0 and $i==2){
        updatemembercount($lose[$i]['uid'],array("extcredits".$_TRC['m_reward_v'][3]['ext']=>$_TRC['m_reward_v'][3]['v']),true,'',0,'',co('inde13'),co('inde17'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde23')." [".$_TRC['m_reward_v'][3]['v'].$_G['setting']['extcredits'][$_TRC['m_reward_v'][3]['ext']]['title']."]");
        notification_add($lose[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no3'] = cx_username($lose[$i]['uid']);
      }
    }
    for($i=0;$i<count($obta_lose_all);$i++){
      if($season['p_reward_v']['ext'] and $season['p_reward_v']['v']>0){  //������
        updatemembercount($obta_lose_all[$i]['uid'],array("extcredits".$season['p_reward_v']['ext'] => $season['p_reward_v']['v'] ),true,'',0,'',co('inde13'),co('inde14'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde20')." [".$season['p_reward_v']['v'].$_G['setting']['extcredits'][$season['p_reward_v']['ext']]['title']."]");
        notification_add($obta_lose_all[$i]['uid'],'system','system_notice',$reward,1);
        $ls['cy'] += 1;  //�����߼���
      }
    }
  }
  
  elseif($_TRC['tax_fee'] and $_TRC['rank_cl']==3){

    for($i=0;$i<count($tax_fee);$i++){
      if($season['m_reward_v'][1]['ext'] and $season['m_reward_v'][1]['v']>0 and $i==0){  //��������
        updatemembercount($tax_fee[$i]['uid'],array("extcredits".$season['m_reward_v'][1]['ext']=>$season['m_reward_v'][1]['v']),true,'',0,'',co('inde13'),co('inde15'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde21')." [".$season['m_reward_v'][1]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][1]['ext']]['title']."]");
        notification_add($tax_fee[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no1'] = cx_username($tax_fee[$i]['uid']);
      }
      elseif($season['m_reward_v'][2]['ext'] and $season['m_reward_v'][2]['v']>0 and $i==1){
        updatemembercount($tax_fee[$i]['uid'],array("extcredits".$season['m_reward_v'][2]['ext']=>$season['m_reward_v'][2]['v']),true,'',0,'',co('inde13'),co('inde16'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde22')." [".$season['m_reward_v'][2]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][2]['ext']]['title']."]");
        notification_add($tax_fee[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no2'] = cx_username($tax_fee[$i]['uid']);
      }
      elseif($season['m_reward_v'][3]['ext'] and $season['m_reward_v'][3]['v']>0 and $i==2){
        updatemembercount($tax_fee[$i]['uid'],array("extcredits".$season['m_reward_v'][3]['ext']=>$season['m_reward_v'][3]['v']),true,'',0,'',co('inde13'),co('inde17'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde23')." [".$season['m_reward_v'][3]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][3]['ext']]['title']."]");
        notification_add($tax_fee[$i]['uid'],'system','system_notice',$reward,1);
        $ls['no3'] = cx_username($tax_fee[$i]['uid']);
      }
    }
    for($i=0;$i<count($tax_fee_all);$i++){
      if($season['p_reward_v']['ext'] and $season['p_reward_v']['v']>0){  //������
        updatemembercount($tax_fee_all[$i]['uid'],array("extcredits".$season['p_reward_v']['ext'] => $season['p_reward_v']['v'] ),true,'',0,'',co('inde13'),co('inde14'));
        $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde20')." [".$season['p_reward_v']['v'].$_G['setting']['extcredits'][$season['p_reward_v']['ext']]['title']."]");
        notification_add($tax_fee_all[$i]['uid'],'system','system_notice',$reward,1);
        $ls['cy'] += 1;  //�����߼���
      }
    }
  
  }
  
  else{
	  for($i=0;$i<count($ph_zj);$i++){  //������ҷ�����Ϣ  
      if($ph_zj[$i]['s']>0 or $ph_zj[$i]['p']>0 or $ph_zj[$i]['f']>0){
        if($season['p_reward_v']['ext'] and $season['p_reward_v']['v']>0){  //������
          updatemembercount($ph_zj[$i]['uid'],array("extcredits".$season['p_reward_v']['ext'] => $season['p_reward_v']['v'] ),true,'',0,'',co('inde13'),co('inde14'));
          $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde20')." [".$season['p_reward_v']['v'].$_G['setting']['extcredits'][$season['p_reward_v']['ext']]['title']."]");
          notification_add($ph_zj[$i]['uid'],'system','system_notice',$reward,1);
          $ls['cy'] += 1;  //�����߼���
        }
        if($season['m_reward_v'][1]['ext'] and $season['m_reward_v'][1]['v']>0 and $i==0){  //��������
          updatemembercount($ph_zj[$i]['uid'],array("extcredits".$season['m_reward_v'][1]['ext']=>$season['m_reward_v'][1]['v']),true,'',0,'',co('inde13'),co('inde15'));
          $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde21')." [".$season['m_reward_v'][1]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][1]['ext']]['title']."]");
          notification_add($ph_zj[$i]['uid'],'system','system_notice',$reward,1);
          $ls['no1'] = cx_username($ph_zj[$i]['uid']);
        }
        elseif($season['m_reward_v'][2]['ext'] and $season['m_reward_v'][2]['v']>0 and $i==1){
          updatemembercount($ph_zj[$i]['uid'],array("extcredits".$season['m_reward_v'][2]['ext']=>$season['m_reward_v'][2]['v']),true,'',0,'',co('inde13'),co('inde16'));
          $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde22')." [".$season['m_reward_v'][2]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][2]['ext']]['title']."]");
          notification_add($ph_zj[$i]['uid'],'system','system_notice',$reward,1);
          $ls['no2'] = cx_username($ph_zj[$i]['uid']);
        }
        elseif($season['m_reward_v'][3]['ext'] and $season['m_reward_v'][3]['v']>0 and $i==2){
          updatemembercount($ph_zj[$i]['uid'],array("extcredits".$season['m_reward_v'][3]['ext']=>$season['m_reward_v'][3]['v']),true,'',0,'',co('inde13'),co('inde17'));
          $reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde23')." [".$season['m_reward_v'][3]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][3]['ext']]['title']."]");
          notification_add($ph_zj[$i]['uid'],'system','system_notice',$reward,1);
          $ls['no3'] = cx_username($ph_zj[$i]['uid']);
        }
      }
    }
	}
	
	//֪ͨ��������
	$ext0 = $season['p_reward_v']['ext'];
	$ext1 = $season['m_reward_v'][1]['ext'];
	$ext2 = $season['m_reward_v'][2]['ext'];
	$ext3 = $season['m_reward_v'][3]['ext'];
	$txt_xx1 = "[".$ls['name']."] ".co('inde61');
	if($ls['no1']){
		$txt_xx2 = co('inde62')." [".$ls['no1']."] ".co('inde60')." [".$season['m_reward_v'][1]['v'].":".$_G['setting']['extcredits'][$ext1]['title']."]";
	}
	if($ls['no2']){
		$txt_xx3 = co('inde63')." [".$ls['no2']."] ".co('inde60')." [".$season['m_reward_v'][2]['v'].":".$_G['setting']['extcredits'][$ext2]['title']."]";
	}
	if($ls['no3']){
		$txt_xx4 = co('inde64')." [".$ls['no3']."] ".co('inde60')." [".$season['m_reward_v'][3]['v'].":".$_G['setting']['extcredits'][$ext3]['title']."]";
	}
	if($ls['cy']>0){
		$txt_xx5 = co('inde65')." [".$ls['cy']."] ".co('inde66')." [".$season['p_reward_v']['v'].":".$_G['setting']['extcredits'][$ext0]['title']."]";
	}
	$txt_mse = $txt_xx1."<br>";
  if($txt_xx2){
		$txt_mse .= $txt_xx2."<br>";
	}
	if($txt_xx3){
		$txt_mse .= $txt_xx3."<br>";
	}
	if($txt_xx4){
		$txt_mse .= $txt_xx4."<br>";
	}
	if($txt_xx5){
		$txt_mse .= $txt_xx5."<br>";
	}
	$fsarr = array('subject' => co('inde11') , 'message' => $txt_mse);
	//����Ϣ
	for($i=0;$i<count($ph_zj);$i++){  //��������ҷ�����Ϣ
	  notification_add($ph_zj[$i]['uid'],'system','system_notice',$fsarr,1);
	}
	//����
	if($ls['cy']>0){
		bl_yz::cq_xx(6,$txt_xx5);
	}
	if($ls['no3']){
		bl_yz::cq_xx(6,$txt_xx4);
	}
	if($ls['no2']){
		bl_yz::cq_xx(6,$txt_xx3);
	}
	if($ls['no1']){
		bl_yz::cq_xx(6,$txt_xx2);
	}
	bl_yz::cq_xx(6,$txt_xx1);
	
	DB::update('zgxsh_cq_user',array("s"=>0,"f"=>0,"p"=>0,'obta'=>0,'lose'=>0,'tax'=>0));
	//�ر�����
	$up = array(
		'state' => 0,
	);
	DB::update('zgxsh_cq_season',$up ,array('id'=>$season['id']));
	$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state = '1'");

    
    discuz_process::unlock('season');
  }

}
if(!$season['id']){  //û������
	$season_txt = "[".co('inde24').":".co('inde25')."]";
}
else{
	$season_txt = "[".co('inde24').":".$season['name']."]";
}


//----[��Ϣ�б�]----
$db_xx = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_xx')." ORDER BY id DESC LIMIT 0,10");
$count_xx = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_cq_xx'));  
for($i=0;$i<10;$i++){
  if($_TRC['SYS_HOT']){
    $db_xx[$i]['date'] = !$db_xx[$i]['x_time']?" -- ":$_TRC['SYS_HOT_TXT'];
  }else{
    $db_xx[$i]['date'] = !$db_xx[$i]['x_time']?" -- ":dgmdate($db_xx[$i]['x_time'],'u');
  }
    
  if($db_xx[$i]['x_lx']==1){
    $db_xx[$i]['x_lx_class'] = "layui-bg-blue";
    $db_xx[$i]['x_lx_txt'] = co('inif05');
    $db_xx[$i]['x_lx'] = "";
  }elseif($db_xx[$i]['x_lx']==2){
    $db_xx[$i]['x_lx_class'] = "layui-bg-orange";
    $db_xx[$i]['x_lx_txt'] = co('inif06');
  }elseif($db_xx[$i]['x_lx']==3){
    $db_xx[$i]['x_lx_class'] = "";
    $db_xx[$i]['x_lx_txt'] = co('inif07');
  }elseif($db_xx[$i]['x_lx']==4){
    $db_xx[$i]['x_lx_class'] = "layui-bg-gray";
    $db_xx[$i]['x_lx_txt'] = co('inif03');
  }elseif($db_xx[$i]['x_lx']==5){
    $db_xx[$i]['x_lx_class'] = "layui-bg-green";
    $db_xx[$i]['x_lx_txt'] = co('inif28');
  }elseif($db_xx[$i]['x_lx']==6){
    $db_xx[$i]['x_lx_class'] = "layui-bg-blue";
    $db_xx[$i]['x_lx_txt'] = co('inde59');
  }else{
    $db_xx[$i]['x_lx_class'] = "layui-bg-gray";
    $db_xx[$i]['x_lx_txt'] = co('inif08');
  }
}

if($_GET['mae'] and $_TRC['mae']){
  include template('zgxsh_cq:index/index_mae');
}else{
  include template('zgxsh_cq:index/index');
}
//From: d'.'is'.'m.ta'.'obao.com
?>