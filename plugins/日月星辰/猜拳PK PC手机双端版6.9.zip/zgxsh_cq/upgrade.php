<?php
/**
 *	[��ȭPK(zgxsh_cq.upgrade)] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_user')." LIKE 'lz_cm'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_cq_user')." DROP COLUMN lz_cm");
}
if($row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_user')." LIKE 'lz_sd'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_cq_user')." DROP COLUMN lz_sd");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_zjb')." LIKE 'lz_cm'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_cq_zjb')." ADD lz_cm int(20) NOT NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_zjb')." LIKE 'lz_sd'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_cq_zjb')." ADD lz_sd int(1) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_season')." LIKE 'dstime'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_cq_season')." ADD dstime int(20) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_zjb')." LIKE 'spf_setup'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_zjb')." ADD spf_setup varchar(1) NOT NULL AFTER lz_sd");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_user')." LIKE 'obta'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_user')." ADD obta int(20) default 0 NOT NULL AFTER p");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_user')." LIKE 'lose'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_user')." ADD lose int(20) default 0 NOT NULL AFTER obta");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_user')." LIKE 'tax'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_user')." ADD tax int(20) default 0 NOT NULL AFTER lose");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_xx')." LIKE 'uid'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_xx')." ADD uid int(20) default 0 NOT NULL AFTER x_lx");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_xx')." LIKE 'j_id'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_xx')." ADD j_id int(20) default 0 NOT NULL AFTER uid");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_cq_xx')." LIKE 'v'")) {
  DB::query("ALTER TABLE ".DB::table('zgxsh_cq_xx')." ADD v int(20) default 0 NOT NULL AFTER j_id");
}


$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_cq_season` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(20),
  `time` int(20) NOT NULL,
  `m_reward` varchar(500) NOT NULL,
  `p_reward` varchar(200) NOT NULL,
  `state` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_cq_profit` (
  `id` int(10) NOT NULL auto_increment,
  `v` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

runquery($sql);

updatecache('zgxsh_cq');

$finish = true;
?>