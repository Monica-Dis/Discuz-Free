<?php
/**
 *	[��ȭPK(zgxsh_cq.{modulename})] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-18 15:39
 */

if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}
//TODO - Insert your code here
include 'module/main.php';

cheating();

$security = new bl_yz();

if ( $_GET[ 'cz' ] == "release" ) { //����
  $see[ 'rand' ] = rand( 1, 99999 );
  $see[ 'form' ] = "var form" . $see[ 'rand' ] . " = layui.form;form" . $see[ 'rand' ] . ".render();";
  if ( $_TRC[ 'SYS_RANDCQ' ] ) { //�����ȭ
    $randcq = "xz(" . rand( 1, 3 ) . ");";
  }
  include template( 'zgxsh_cq:game/game_cj' );
  exit();
} 
elseif ( $_GET[ 'cz' ] == "release_sub" ) { //�����ύ

  $LS = $security->release_aq( $_GET );

  if ( $LS[ 'cm' ] < $_TRC[ 'SYS_JR' ] ) {
    $text = co( 'inde03' ) . $_TRC[ 'SYS_JR' ];
    include template( 'zgxsh_cq:ts/ts' );
    exit();
  }
  if ( $LS[ 'cm' ] > $_TRC[ 'max_jr' ] ) { //�����趨ֵ
    $text = co( 'inde71' ) . $_TRC[ 'max_jr' ];
    include template( 'zgxsh_cq:ts/ts' );
    exit();
  }


  if ( $LS[ 'bur' ] < 1 ) {
    $LS[ 'bur' ] = 1;
  }

  if ( !$LS[ 'sd' ] ) {
    $_TRC[ 'SYS_CQJF_XH' ] = 0;
  }

  //��ʤ/ʥ������ = SYS_CQJF_XH �����������Ĳ�ȭ���� SYS_CQJF_LXFB

  $LS[ 'cqjf_cons' ] = $_TRC[ 'SYS_CQJF_XH' ] * $LS[ 'bur' ] + $_TRC[ 'SYS_CQJF_LXFB' ] * ( $LS[ 'bur' ] - 1 );

  if ( $user[ 'cqjf' ] < $LS[ 'cqjf_cons' ] ) { //��ȭ���ֲ���
    $text = co( 'inde70' ) . $LS[ 'cqjf_cons' ] . $_TRC[ 'SYS_CQJF' ];
    include template( 'zgxsh_cq:ts/ts' ); //����ʧ�� ����
    exit();
  }

  $number = -( $LS[ 'cm' ] + $_TRC[ 'SYS_CJ_SF' ] ) * $LS[ 'bur' ];
  sys_integral( $_G[ 'uid' ], $number, $_TRC, co( 'inif05' ) );

  if ( $LS[ 'bur' ] > 1 ) { //��������1
    $cqjf = DB::result_first( "SELECT cqjf FROM " . DB::table( 'zgxsh_cq_user' ) . " WHERE uid = '" . $_G[ 'uid' ] . "'" );
    $security->cjf( $_G[ 'uid' ], -( $_TRC[ 'SYS_CQJF_LXFB' ] * ( $LS[ 'bur' ] - 1 ) ) ); //�۳���������ר����
  }

  profit( $_TRC[ 'SYS_CJ_SF' ] * $LS[ 'bur' ] ); //ӯ��

  if ( $LS[ 'sd' ] ) {
    $sdtext = co( 'inde06' ) . $_TRC[ 'SYS_CQJF_XH' ] . $_TRC[ 'SYS_CQJF' ];
    $security->cjf( $_G[ 'uid' ], -( $_TRC[ 'SYS_CQJF_XH' ] * $LS[ 'bur' ] ) );
    $LS[ 'sd' ] = 1;
  } else {
    $LS[ 'sd' ] = 0;
  }

  for ( $i = 1; $i <= $LS[ 'bur' ]; $i++ ) {
    if ( $i >= 2 ) {
      $LS[ 'cq' ] = rand( 1, 3 );
    }
    $ins = array(
      'lz_uid' => $_G[ 'uid' ],
      'lz_time' => time(),
      'lz_sz' => $LS[ 'cq' ],
      'lz_sd' => $LS[ 'sd' ],
      'lz_cm' => $LS[ 'cm' ],
    );
    $ins = $security->release_ins( $ins );
    DB::insert( 'zgxsh_cq_zjb', $ins );
  }

  if ( $LS[ 'bur' ] == 1 ) {
    $security->cjf( $_G[ 'uid' ], $_TRC[ 'SYS_CQJF_FBHD' ] );
  }

  $security->cq_xx( 1, $_G[ 'username' ] . co( 'inif01' ) );

  if ( ( ( $_TRC[ 'SYS_CQJF_FBHD' ] * $LS[ 'bur' ] ) - ( $_TRC[ 'SYS_CQJF_LXFB' ] * ( $LS[ 'bur' ] - 1 ) ) ) >= 0 ) {
    $zf = " +";
  } else {
    $zf = " ";
  }

  $text = co( 'inif02' ) . "<br>";
  $text .= $_TRC[ 'MAIN_JFX_CName' ] . " -" . ( ( $LS[ 'cm' ] + $_TRC[ 'SYS_CJ_SF' ] ) * $LS[ 'bur' ] ) . "<br>";
  $text .= $_TRC[ 'SYS_CQJF' ] . $zf . ( ( $_TRC[ 'SYS_CQJF_FBHD' ] * $LS[ 'bur' ] ) - ( $_TRC[ 'SYS_CQJF_LXFB' ] * ( $LS[ 'bur' ] - 1 ) ) );
  $text .= "<br>" . $sdtext;
  include template( 'zgxsh_cq:ts/ts' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "list" ) { //��ҳ

  $LS = $security->list_aq( $_GET );

  $CX01 = 0 + ( 10 * ( $LS[ 'curr' ] - 1 ) );
  $CX02 = 10;

  if ( $LS[ 'el' ] == 'list_zj' ) {

    $db_round = DB::fetch_all( "SELECT * FROM " . DB::table( 'zgxsh_cq_zjb' ) . " LIMIT " . $CX01 . "," . $CX02 );
    $count_zj = DB::result_first( "SELECT count(id) FROM " . DB::table( 'zgxsh_cq_zjb' ) );
    for ( $i = 0; $i < 10; $i++ ) {
      if ( $_TRC[ 'SYS_HOT' ] ) {
        $db_round[ $i ][ 'dates' ] = !$db_round[ $i ][ 'lz_time' ] ? " -- " : $_TRC[ 'SYS_HOT_TXT' ];
      } else {
        $db_round[ $i ][ 'dates' ] = !$db_round[ $i ][ 'lz_time' ] ? " -- " : dgmdate( $db_round[ $i ][ 'lz_time' ], 'u' );
      }
      $db_round[ $i ][ 'datets' ] = date( 'Y-m-d H:i:s', $db_round[ $i ][ 'lz_time' ] );
      $db_round[ $i ][ 'name' ] = cx_username( $db_round[ $i ][ 'lz_uid' ] ); //���ﲻ���������������
      if ( $db_round[ $i ][ 'lz_uid' ] == $_G[ 'uid' ] ) {
        $db_round[ $i ][ "cl" ] = "layui-btn-danger";
        $db_round[ $i ][ "on" ] = "del";
        $db_round[ $i ][ "co" ] = co( 'inif03' );
      } elseif ( $db_round[ $i ][ 'id' ] ) {
        $db_round[ $i ][ "cl" ] = "layui-btn-primary";
        $db_round[ $i ][ "on" ] = "than";
        $db_round[ $i ][ "co" ] = co( 'inif04' );
      } else {
        $db_round[ $i ][ "cl" ] = "";
        $db_round[ $i ][ "on" ] = "";
        $db_round[ $i ][ "co" ] = "";
      }
      if ( $db_round[ $i ][ 'lz_uid' ] == $_G[ 'uid' ]and $db_round[ $i ][ 'lz_sd' ] ) { //�Լ���ս����ʾʥ��
        $db_round[ $i ][ "see_sd" ] = '<div class="layui-anim layui-anim-scaleSpring layui-inline"><i class="layui-icon">&#xe672;</i></div>';
      }
    }

    include template( 'zgxsh_cq:ajax/list_zj' );
    exit();
  }
  if ( $LS[ 'el' ] == 'list_xx' ) {

    $db_xx = DB::fetch_all( "SELECT * FROM " . DB::table( 'zgxsh_cq_xx' ) . " ORDER BY id DESC LIMIT " . $CX01 . "," . $CX02 );
    $count_xx = DB::result_first( "SELECT count(id) FROM " . DB::table( 'zgxsh_cq_xx' ) );

    for ( $i = 0; $i < 10; $i++ ) {
      if ( $_TRC[ 'SYS_HOT' ] ) {
        $db_xx[ $i ][ 'date' ] = !$db_xx[ $i ][ 'x_time' ] ? " -- " : $_TRC[ 'SYS_HOT_TXT' ];
      } else {
        $db_xx[ $i ][ 'date' ] = !$db_xx[ $i ][ 'x_time' ] ? " -- " : dgmdate( $db_xx[ $i ][ 'x_time' ], 'u' );
      }
      if ( $db_xx[ $i ][ 'x_lx' ] == 1 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-blue";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif05' );
        $db_xx[ $i ][ 'x_lx' ] = "";
      } elseif ( $db_xx[ $i ][ 'x_lx' ] == 2 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-orange";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif06' );
      } elseif ( $db_xx[ $i ][ 'x_lx' ] == 3 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif07' );
      } elseif ( $db_xx[ $i ][ 'x_lx' ] == 4 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-gray";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif03' );
      } elseif ( $db_xx[ $i ][ 'x_lx' ] == 5 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-green";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif28' );
      } elseif ( $db_xx[ $i ][ 'x_lx' ] == 6 ) {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-blue";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inde59' );
      } else {
        $db_xx[ $i ][ 'x_lx_class' ] = "layui-bg-gray";
        $db_xx[ $i ][ 'x_lx_txt' ] = co( 'inif08' );
      }
    }

    include template( 'zgxsh_cq:ajax/list_xx' );
    exit();
  }
}
elseif ( $_GET[ 'cz' ] == "del" ) { //����

  $LS = $security->del_than_aq( $_GET );

  $LS[ 'cz' ] = DB::result_first( "SELECT id FROM " . DB::table( 'zgxsh_cq_zjb' ) . " WHERE id = '" . $LS[ 'bh' ] . "'" );
  $LS[ 'lz_cm' ] = DB::result_first( "SELECT lz_cm FROM " . DB::table( 'zgxsh_cq_zjb' ) . " WHERE id = '" . $LS[ 'bh' ] . "'" );
  $LS[ 'lz_uid' ] = DB::result_first( "SELECT lz_uid FROM " . DB::table( 'zgxsh_cq_zjb' ) . " WHERE id = '" . $LS[ 'bh' ] . "'" );

  if ( $LS[ 'lz_uid' ] <> $_G[ 'uid' ] ) { //�жϳ������Ƿ�������
    $text = co( 'inif30' );
  }

  if ( $LS[ 'cz' ] ) {
    $LS[ 'tf' ] = DB::delete( 'zgxsh_cq_zjb', array( 'id' => $LS[ 'bh' ] ), 1 );
    if ( $LS[ 'tf' ] ) {
      $number = $LS[ 'lz_cm' ];
      sys_integral( $_G[ 'uid' ], $number, $_TRC, co( 'inif03' ) );
      $security->cjf( $_G[ 'uid' ], -( $_TRC[ 'SYS_CQJF_FBHD' ] ) );
      $security->cq_xx( 4, $_G[ 'username' ] . co( 'inif11' ) );
    }
    $text = $LS[ 'tf' ] == true ? co( 'inif09' ) : co( 'inif10' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " -" . $_TRC[ 'SYS_CQJF_FBHD' ];
  } else {
    $text = co( 'inif10' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " -" . $_TRC[ 'SYS_CQJF_FBHD' ];
  }

  include template( 'zgxsh_cq:ts/ts' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "than" ) { //��ս
  $LS = $security->del_than_aq( $_GET );
  $db = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_cq_zjb' ) . " WHERE id = '" . $LS[ 'bh' ] . "'" );
  include template( 'zgxsh_cq:game/game_than' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "than_sub" ) { //��ս�ύ
  $LS = $security->thansub_aq( $_GET );
  
  
  
  $db = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_cq_zjb' ) . " WHERE id = '" . $LS[ 'bh' ] . "'" );
  if ( !$db ) {
    $text = co( 'inif12' );
    include template( 'zgxsh_cq:ts/ts' );
    exit();
  }
  if ( $LS[ 'cq' ] == 4 ) {
    $security->cjf( $_G[ 'uid' ], -$_TRC[ 'SYS_CQJF_XH' ] );
    if ( $db[ 'lz_sd' ] ) { //�ж�ʥ��
      $text = co( 'inde02' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " -" . $_TRC[ 'SYS_CQJF_XH' ];
      $security->cq_xx( 3, $_G[ 'username' ] . co( 'inde07' ) );
      include template( 'zgxsh_cq:ts/ts' );
      exit();
    } else {
      $security->cq_xx( 3, $_G[ 'username' ] . co( 'inif13' ) . cx_username( $db[ 'lz_uid' ] ) . '��' );
    }
  }
  if ( !$_TRC[ 'hs_sf' ] ) {
    sys_integral( $_G[ 'uid' ], ( -( $db[ 'lz_cm' ] + $_TRC[ 'SYS_TZ_SF' ] ) ), $_TRC, co( 'inif04' ) );
    profit( $_TRC[ 'SYS_TZ_SF' ] );
  } else {
    sys_integral( $_G[ 'uid' ], -$db[ 'lz_cm' ], $_TRC, co( 'inif04' ) );
  }

  $db[ 'username' ] = cx_username( $db[ 'lz_uid' ] );
  $LS[ 'outcome' ] = $security->outcome( $LS[ 'cq' ], $db[ 'lz_sz' ] );

  //��Ȼʤƽ��
  if ( $_TRC[ 'spf_setup' ] and $db[ 'spf_setup' ] ) {
    if ( $db[ 'spf_setup' ] == 1 ) {
      $LS[ 'outcome' ] = "s";
    } elseif ( $db[ 'spf_setup' ] == 2 ) {
      $LS[ 'outcome' ] = "p";
    } elseif ( $db[ 'spf_setup' ] == 3 ) {
      $LS[ 'outcome' ] = "f";
    }
  }

  if ( $LS[ 'outcome' ] == "s" ) { //s f p ʤ��ƽ
    $text = co( 'inif14' ) . $db[ 'lz_cm' ] . $_TRC[ 'MAIN_JFX_CName' ] . "<br>" . $_TRC[ 'SYS_CQJF' ] . " +" . $_TRC[ 'SYS_CQJF_SLHD' ];
    $security->cjf( $_G[ 'uid' ], $_TRC[ 'SYS_CQJF_SLHD' ] );
    $security->cjf( $db[ 'lz_uid' ], $_TRC[ 'SYS_CQJF_SBHD' ] );

    if ( $LS[ 'cq' ] <> 4 ) {
      $security->cq_xx( 2, $_G[ 'username' ] . co( 'inif04' ) . cx_username( $db[ 'lz_uid' ] ) . co( 'inif15' ) );
    }

    $fsarr = array( 'subject' => co( 'inif16' ), 'message' => $_G[ 'username' ] . co( 'inif17' ) );
    notification_add( $db[ 'lz_uid' ], 'system', 'system_notice', $fsarr, 1 );
    if ( !$_TRC[ 'hs_sf' ] ) {
      sys_integral( $_G[ 'uid' ], $db[ 'lz_cm' ] * 2 + $_TRC[ 'SYS_TZ_SF' ], $_TRC, co( 'inif15' ) ); //��ʤ�˻������� $_TRC['SYS_TZ_SF']
      $fee_win = $db[ 'lz_cm' ] + $_TRC[ 'SYS_TZ_SF' ];
      $fee_los = $db[ 'lz_cm' ];
    } else {
      $hs_sf_v = ceil( $db[ 'lz_cm' ] ) * ( $_TRC[ 'hs_sf_v' ] / 100 );
      profit( $hs_sf_v );
      sys_integral( $_G[ 'uid' ], $db[ 'lz_cm' ] * 2 - $hs_sf_v, $_TRC, co( 'inif15' ) ); //��ʤ��ȡ������
      $text .= co( 'inde72' ) . $hs_sf_v . $_TRC[ 'MAIN_JFX_CName' ];
      $fee_win = $db[ 'lz_cm' ] - $hs_sf_v;
      $fee_los = $db[ 'lz_cm' ];
    }
    $security->s_f_p( $_G[ 'uid' ], 's' );
    $security->s_f_p( $db[ 'lz_uid' ], 'f' );

    $security->obta_lose( $_G[ 'uid' ], "obta", $fee_win );
    $security->obta_lose( $_G[ 'uid' ], "lose", -$fee_win );
    $security->obta_lose( $db[ 'lz_uid' ], "lose", $fee_los );
    $security->obta_lose( $db[ 'lz_uid' ], "obta", -$fee_los );

    $security->tax_rank( $_G[ 'uid' ], $hs_sf_v );

    $p1img = $LS[ 'cq' ];
    $p2img = $db[ 'lz_sz' ] . "_b";
  } elseif ( $LS[ 'outcome' ] == "f" ) {
    $text = co( 'inif18' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " +" . $_TRC[ 'SYS_CQJF_SBHD' ];
    $security->cjf( $_G[ 'uid' ], $_TRC[ 'SYS_CQJF_SBHD' ] );
    $security->cjf( $db[ 'lz_uid' ], $_TRC[ 'SYS_CQJF_SLHD' ] );
    $security->cq_xx( 2, $_G[ 'username' ] . co( 'inif04' ) . cx_username( $db[ 'lz_uid' ] ) . co( 'inif19' ) );

    if ( !$_TRC[ 'hs_sf' ] ) {
      sys_integral( $db[ 'lz_uid' ], $db[ 'lz_cm' ] * 2, $_TRC, co( 'inif19' ) );
      $fee_win = $db[ 'lz_cm' ];
      $fee_los = $db[ 'lz_cm' ];
    } else {
      $hs_sf_v = ceil( $db[ 'lz_cm' ] ) * ( $_TRC[ 'hs_sf_v' ] / 100 );
      profit( $hs_sf_v );
      sys_integral( $db[ 'lz_uid' ], $db[ 'lz_cm' ] * 2 - $hs_sf_v, $_TRC, co( 'inif15' ) ); //��ʤ��ȡ������
      $fee_win = $db[ 'lz_cm' ] - $hs_sf_v;
      $fee_los = $db[ 'lz_cm' ];
    }

    $fsarr = array( 'subject' => co( 'inif16' ), 'message' => $_G[ 'username' ] . co( 'inif20' ) . $db[ 'lz_cm' ] . $_TRC[ 'MAIN_JFX_CName' ] . co( 'inde72' ) . $hs_sf_v . $_TRC[ 'MAIN_JFX_CName' ] );
    notification_add( $db[ 'lz_uid' ], 'system', 'system_notice', $fsarr, 1 );

    $security->s_f_p( $_G[ 'uid' ], 'f' );
    $security->s_f_p( $db[ 'lz_uid' ], 's' );

    $security->obta_lose( $db[ 'lz_uid' ], "obta", $fee_win );
    $security->obta_lose( $db[ 'lz_uid' ], "lose", -$fee_win );
    $security->obta_lose( $_G[ 'uid' ], "lose", $fee_los );
    $security->obta_lose( $_G[ 'uid' ], "obta", -$fee_los );

    $security->tax_rank( $db[ 'lz_uid' ], $hs_sf_v );

    $p1img = $LS[ 'cq' ] . "_b";
    $p2img = $db[ 'lz_sz' ];
  }
  else {
    $security->cjf( $_G[ 'uid' ], $_TRC[ 'SYS_CQJF_PJHD' ] );
    $security->cjf( $db[ 'lz_uid' ], $_TRC[ 'SYS_CQJF_PJHD' ] );
    $text = co( 'inif21' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " +" . $_TRC[ 'SYS_CQJF_PJHD' ];
    $security->cq_xx( 2, $_G[ 'username' ] . co( 'inif04' ) . cx_username( $db[ 'lz_uid' ] ) . co( 'inif22' ) );
    $fsarr = array( 'subject' => co( 'inif16' ), 'message' => $_G[ 'username' ] . co( 'inif23' ) );
    notification_add( $db[ 'lz_uid' ], 'system', 'system_notice', $fsarr, 1 );
    sys_integral( $_G[ 'uid' ], $db[ 'lz_cm' ], $_TRC, co( 'inif22' ) );
    sys_integral( $db[ 'lz_uid' ], $db[ 'lz_cm' ], $_TRC, co( 'inif22' ) );
    $security->s_f_p( $_G[ 'uid' ], 'p' );
    $security->s_f_p( $db[ 'lz_uid' ], 'p' );
    $p1img = $LS[ 'cq' ] . "_b";
    $p2img = $db[ 'lz_sz' ] . "_b";
  }
  DB::delete( 'zgxsh_cq_zjb', array( 'id' => $LS[ 'bh' ] ), 1 );

  if ( $_TRC[ 'spf_setup' ]and $db[ 'spf_setup' ] ) {
    if ( $db[ 'spf_setup' ] == 1 ) {
      if ( $LS[ 'cq' ] == 1 ) {
        $p2img = "2_b";
      } elseif ( $LS[ 'cq' ] == 2 ) {
        $p2img = "3_b";
      } else {
        $p2img = "1_b";
      }
    } elseif ( $db[ 'spf_setup' ] == 2 ) {
      if ( $LS[ 'cq' ] == 1 ) {
        $p2img = "1_b";
      } elseif ( $LS[ 'cq' ] == 2 ) {
        $p2img = "2_b";
      } else {
        $p2img = "3_b";
      }
    } elseif ( $db[ 'spf_setup' ] == 3 ) {
      if ( $LS[ 'cq' ] == 1 ) {
        $p2img = "3_b";
      } elseif ( $LS[ 'cq' ] == 2 ) {
        $p2img = "1_b";
      } else {
        $p2img = "2_b";
      }
    }
  }

  include template( 'zgxsh_cq:game/game_outcome' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "buy" ) { //�ڹ�

  $LS[ 'kd' ] = floor( $_TRC[ 'MAIN_JFZ' ] / $_TRC[ 'SYS_CQJF_JS' ] );
  if ( $LS[ 'kd' ] == 0 ) {
    $text = co( 'inif24' ) . $_TRC[ 'MAIN_JFX_CName' ] . co( 'inif25' ) . $_TRC[ 'SYS_CQJF_JS' ] . co( 'inif26' );
    include template( 'zgxsh_cq:ts/ts' );
    exit();
  } elseif ( $LS[ 'kd' ] > 20 ) {
    $LS[ 'kd' ] = 20;
  }
  for ( $i = 1; $i <= $LS[ 'kd' ]; $i++ ) {
    $see[ 'option' ] .= "<option value='" . $i . "'>" . $_TRC[ 'SYS_CQJF_LS' ] * $i . $_TRC[ 'SYS_CQJF' ] . "(" . $_TRC[ 'SYS_CQJF_JS' ] * $i . $_TRC[ 'MAIN_JFX_CName' ] . ")" . "</option>";
  }

  $see[ 'rand' ] = rand( 1, 99999 );
  $see[ 'form' ] = "var form" . $see[ 'rand' ] . " = layui.form;form" . $see[ 'rand' ] . ".render();";

  include template( 'zgxsh_cq:buy/buy' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "buy_sub" ) { //�ڹ��ύ

  $LS = $security->buysub_aq( $_GET );

  sys_integral( $_G[ 'uid' ], -$_TRC[ 'SYS_CQJF_JS' ] * $LS[ 'buy_sl' ], $_TRC, co( 'inif31' ) );
  profit( $_TRC[ 'SYS_CQJF_JS' ] * $LS[ 'buy_sl' ] );
  $security->cjf( $_G[ 'uid' ], $_TRC[ 'SYS_CQJF_LS' ] * $LS[ 'buy_sl' ] );

  $security->cq_xx( 5, $_G[ 'username' ] . co( 'inde09' ) . " " . $_TRC[ 'SYS_CQJF_LS' ] * $LS[ 'buy_sl' ] . $_TRC[ 'SYS_CQJF' ] );

  $text = co( 'inif27' ) . "<br>" . $_TRC[ 'SYS_CQJF' ] . " +" . $_TRC[ 'SYS_CQJF_LS' ] * $LS[ 'buy_sl' ];
  include template( 'zgxsh_cq:ts/ts' );
  exit();
}
elseif ( $_GET[ 'cz' ] == "season" ) {
  //����������
  $see[ 'rand' ] = rand( 1, 99999 );
  $see[ 'form' ] = "var form" . $see[ 'rand' ] . " = layui.form;form" . $see[ 'rand' ] . ".render();";
  //ѡ��������
  for ( $i = 1; $i <= 8; $i++ ) {
    if ( $_G[ 'setting' ][ 'extcredits' ][ $i ][ 'title' ] ) {
      $option .= "<option value='" . $i . "'>" . $_G[ 'setting' ][ 'extcredits' ][ $i ][ 'title' ] . "</option>";
    }
  }
  //���������������������ҳ��
  $season = DB::fetch_first( "SELECT * FROM " . DB::table( 'zgxsh_cq_season' ) . " WHERE state = '1'" );
  if ( !$season ) { //������������ҳ��
    include template( 'zgxsh_cq:season/season_add' );
    exit();
  }
  //��������ִ������
  include template( 'zgxsh_cq:season/season_edit' );
  exit();
}


elseif($_GET['cz']=="season_add_sub"){
	
	if(!submitcheck('formhash')){
		$text = co('main04');
		include template('zgxsh_cq:ts/ts');
		exit();
	}
	
	if(!$_GET['name']){
		$text = co('inde33');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if(!$_GET['time'] or strtotime($_GET['time'])<time()){
		$text = co('inde34');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	if((!$_GET['m_reward'][1]['ext'] or !$_GET['m_reward'][1]['v']) and (!$_GET['p_reward']['ext'] or !$_GET['p_reward']['v'])){
		$text = co('inde35');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	
	$security -> season_add($_GET);
	
	//��֪ͨ������Ϣ
	$ls['name'] = daddslashes($_GET['name']);
  
  $text = co('inde27')." [".$ls['name']."] ".co('inde28')."<br><br>";
	$text .= co('inde26')." [".$_GET['time']."] "."<br><br>";
	if($_GET['p_reward']['ext'] and $_GET['p_reward']['v']){
		$text .= co('inde31')." [".$_GET['p_reward']['v'].$_G['setting']['extcredits'][$_GET['p_reward']['ext']]['title']."]"."<br>";
	}
	if($_GET['m_reward'][1]['ext'] and $_GET['m_reward'][1]['v']){
		$text .= co('inde21')." [".$_GET['m_reward'][1]['v'].$_G['setting']['extcredits'][$_GET['m_reward'][1]['ext']]['title']."]"."<br>";
	}
	if($_GET['m_reward'][2]['ext'] and $_GET['m_reward'][2]['v']){
		$text .= co('inde22')." [".$_GET['m_reward'][2]['v'].$_G['setting']['extcredits'][$_GET['m_reward'][2]['ext']]['title']."]"."<br>";
	}
	if($_GET['m_reward'][3]['ext'] and $_GET['m_reward'][3]['v']){
		$text .= co('inde23')." [".$_GET['m_reward'][3]['v'].$_G['setting']['extcredits'][$_GET['m_reward'][3]['ext']]['title']."]"."<br>";
	}
	$text .= "<br>";
  
	$fsarr = array('subject' => co('inde35') , 'message' => $ls['name'].co('inde42').$text."<a href='plugin.php?id=zgxsh_cq:index'>[".co('inde67')."]</a><br><br>");
  
  
  
	$user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user'));
	for($i=0;$i<count($user_all);$i++){  //��������ҷ�����Ϣ
	  notification_add($user_all[$i]['uid'],'system','system_notice',$fsarr,1);
	}
	//���ʤ��ƽ
	DB::update('zgxsh_cq_user',array("s"=>0,"f"=>0,"p"=>0,'obta'=>0,'lose'=>0,'tax'=>0));
	//������Ϣ�б�
	$security -> cq_xx(1,co('inde32')." [".$_G['username']."] ".co('inde43')." [".$ls['name']."] ".co('inde44'));
	
	$text = co('inde43')."[".$ls['name']."]".co('inde24')."<br>".$text;
	include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="season_edit_sub"){
	
	if(!submitcheck('formhash')){
		$text = co('main04');
		include template('zgxsh_cq:ts/ts');
		exit();
	}

	if(!$_GET['season_op']){
		$text = co('inde45');
		include template('zgxsh_cq:ts/ts');
    exit();
	}elseif(($_GET['season_op']==1 or $_GET['season_op']==2) and $_GET['season_v']<=0){
		$text = co('inde46');
		include template('zgxsh_cq:ts/ts');
		exit();
	}
	//��ȡ������Ϣ
	$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state = '1'");
	//�����и����
	$season['m_reward_v'] = unserialize($season['m_reward']);
	$season['p_reward_v'] = unserialize($season['p_reward']);
	
	$security -> season_edit($_GET);
	//��ȡ�����û�����
	$user_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY s DESC,p DESC,f DESC");
  $obta_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY obta DESC"); 
  $lose_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY lose DESC"); 
  $tax_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_user')." ORDER BY tax DESC"); 
	//��֪ͨ������Ϣ
	if($_GET['season_op']==1){  //��ʱ
    $ts_add = co('inde47').",".co('inde49')." [".$_GET['season_v']."] ".co('inde48')."!";
		$se_add = co('inde50');
	}elseif($_GET['season_op']==2){  //��ʱ
    $ts_add = co('inde47').",".co('inde51')." [".$_GET['season_v']."] ".co('inde48')."!";
		$se_add = co('inde52');
	}elseif($_GET['season_op']==3){  //��ֹ
    $ts_add = co('inde53');
		$se_add = co('inde54');
		//����
		if($_GET['reward_true']==0){
			$se_add2 = co('inde55');
		}elseif($_GET['reward_true']==1){
			$se_add2 = co('inde56');
		}elseif($_GET['reward_true']==2){
			$se_add2 = co('inde57');
		}elseif($_GET['reward_true']==3){
			$se_add2 = co('inde58');
		}
	  DB::update('zgxsh_cq_user',array("s"=>0,"f"=>0,"p"=>0,'obta'=>0,'lose'=>0,'tax'=>0));
	}
	$ls['name'] = daddslashes($season['name']);
	$fsarr = array('subject' => co('inde11') , 'message' => $ls['name'].co('inde24').$ts_add.$se_add2);
	for($i=0;$i<count($user_all);$i++){  //��������ҷ�����Ϣ
		
	  notification_add($user_all[$i]['uid'],'system','system_notice',$fsarr,1);
		
		if($ph_zj[$i]['s']>0 or $ph_zj[$i]['p']>0 or $ph_zj[$i]['f']>0 or $ph_zj[$i]['obta']>0 or $ph_zj[$i]['lose']>0 or $ph_zj[$i]['tax']>0){
      
		if($_GET['reward_true']==1 or $_GET['reward_true']==3){  //����
			if($season['p_reward_v']['ext'] and $season['p_reward_v']['v']>0){
				updatemembercount($user_all[$i]['uid'],array("extcredits".$season['p_reward_v']['ext'] => $season['p_reward_v']['v'] ),true,'',0,'',co('inde13'),co('inde14'));
				$reward = array('subject' => co('inde18') , 'message' => co('inde19')." [".$ls['name']."] ".co('inde24')." ".co('inde20')." [".$season['p_reward_v']['v'].$_G['setting']['extcredits'][$season['p_reward_v']['ext']]['title']."]");
				notification_add($user_all[$i]['uid'],'system','system_notice',$reward,1);
			}
		}
      

		if ( $_GET[ 'reward_true' ] == 2 or $_GET[ 'reward_true' ] == 3 ) {
                if ( $_TRC[ 'obta_lose' ]and $_TRC[ 'rank_cl' ] == 2 ) {
                  if ( $season[ 'm_reward_v' ][ 1 ][ 'ext' ]and $season[ 'm_reward_v' ][ 1 ][ 'v' ] > 0 and $i == 0 ) {
                    updatemembercount( $obta_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 1 ][ 'ext' ] => $season[ 'm_reward_v' ][ 1 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde15' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde21' ) . " [" . $season[ 'm_reward_v' ][ 1 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 1 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $obta_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 2 ][ 'ext' ]and $season[ 'm_reward_v' ][ 2 ][ 'v' ] > 0 and $i == 1 ) {
                    updatemembercount( $obta_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 2 ][ 'ext' ] => $season[ 'm_reward_v' ][ 2 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde16' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde22' ) . " [" . $season[ 'm_reward_v' ][ 2 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 2 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $obta_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 3 ][ 'ext' ]and $season[ 'm_reward_v' ][ 3 ][ 'v' ] > 0 and $i == 2 ) {
                    updatemembercount( $obta_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 3 ][ 'ext' ] => $season[ 'm_reward_v' ][ 3 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde17' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde23' ) . " [" . $season[ 'm_reward_v' ][ 3 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 3 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $obta_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  }
                  
                  if ( $season[ 'm_reward_v' ][ 1 ][ 'ext' ]and $season[ 'm_reward_v' ][ 1 ][ 'v' ] > 0 and $i == 0 ) {
                    updatemembercount( $lose_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 1 ][ 'ext' ] => $season[ 'm_reward_v' ][ 1 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde15' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde21' ) . " [" . $season[ 'm_reward_v' ][ 1 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 1 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $lose_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 2 ][ 'ext' ]and $season[ 'm_reward_v' ][ 2 ][ 'v' ] > 0 and $i == 1 ) {
                    updatemembercount( $lose_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 2 ][ 'ext' ] => $season[ 'm_reward_v' ][ 2 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde16' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde22' ) . " [" . $season[ 'm_reward_v' ][ 2 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 2 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $lose_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 3 ][ 'ext' ]and $season[ 'm_reward_v' ][ 3 ][ 'v' ] > 0 and $i == 2 ) {
                    updatemembercount( $lose_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 3 ][ 'ext' ] => $season[ 'm_reward_v' ][ 3 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde17' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde23' ) . " [" . $season[ 'm_reward_v' ][ 3 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 3 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $lose_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  }
                }
                elseif ( $_TRC[ 'tax_fee' ]and $_TRC[ 'rank_cl' ] == 3 ) {
                  if ( $season[ 'm_reward_v' ][ 1 ][ 'ext' ]and $season[ 'm_reward_v' ][ 1 ][ 'v' ] > 0 and $i == 0 ) {
                    updatemembercount( $tax_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 1 ][ 'ext' ] => $season[ 'm_reward_v' ][ 1 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde15' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde21' ) . " [" . $season[ 'm_reward_v' ][ 1 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 1 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $tax_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 2 ][ 'ext' ]and $season[ 'm_reward_v' ][ 2 ][ 'v' ] > 0 and $i == 1 ) {
                    updatemembercount( $tax_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 2 ][ 'ext' ] => $season[ 'm_reward_v' ][ 2 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde16' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde22' ) . " [" . $season[ 'm_reward_v' ][ 2 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 2 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $tax_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 3 ][ 'ext' ]and $season[ 'm_reward_v' ][ 3 ][ 'v' ] > 0 and $i == 2 ) {
                    updatemembercount( $tax_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 3 ][ 'ext' ] => $season[ 'm_reward_v' ][ 3 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde17' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde23' ) . " [" . $season[ 'm_reward_v' ][ 3 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 3 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $tax_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  }
                } 
                elseif ( $_TRC[ 'rank_cl' ] == 1 ) {
                  if ( $season[ 'm_reward_v' ][ 1 ][ 'ext' ]and $season[ 'm_reward_v' ][ 1 ][ 'v' ] > 0 and $i == 0 ) {
                    updatemembercount( $user_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 1 ][ 'ext' ] => $season[ 'm_reward_v' ][ 1 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde15' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde21' ) . " [" . $season[ 'm_reward_v' ][ 1 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 1 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $user_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 2 ][ 'ext' ]and $season[ 'm_reward_v' ][ 2 ][ 'v' ] > 0 and $i == 1 ) {
                    updatemembercount( $user_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 2 ][ 'ext' ] => $season[ 'm_reward_v' ][ 2 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde16' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde22' ) . " [" . $season[ 'm_reward_v' ][ 2 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 2 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $user_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  } 
                  elseif ( $season[ 'm_reward_v' ][ 3 ][ 'ext' ]and $season[ 'm_reward_v' ][ 3 ][ 'v' ] > 0 and $i == 2 ) {
                    updatemembercount( $user_all[ $i ][ 'uid' ], array( "extcredits" . $season[ 'm_reward_v' ][ 3 ][ 'ext' ] => $season[ 'm_reward_v' ][ 3 ][ 'v' ] ), true, '', 0, '', co( 'inde13' ), co( 'inde17' ) );
                    $reward = array( 'subject' => co( 'inde18' ), 'message' => co( 'inde19' ) . " [" . $ls[ 'name' ] . "] " . co( 'inde24' ) . " " . co( 'inde23' ) . " [" . $season[ 'm_reward_v' ][ 3 ][ 'v' ] . $_G[ 'setting' ][ 'extcredits' ][ $season[ 'm_reward_v' ][ 3 ][ 'ext' ] ][ 'title' ] . "]" );
                    notification_add( $user_all[ $i ][ 'uid' ], 'system', 'system_notice', $reward, 1 );
                  }
                }
              }
		}
	}	
	//������Ϣ�б�
	$security -> cq_xx(1,co('inde32')." [".$_G['username']."] ".$se_add." [".$ls['name']."] ".co('inde24')."!".$se_add2);
	
	$text = co('inde30');
	include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="season_see"){
  //���������������������ҳ��
	$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state = '1'");
	if(!$season){  //������������ҳ��
		$text = co('inde29');
		include template('zgxsh_cq:ts/ts');
    exit();
	}
	//�����и����
	$season['m_reward_v'] = unserialize($season['m_reward']);
	$season['p_reward_v'] = unserialize($season['p_reward']);
	
	$text = co('inde27')." [".$season['name']."] ".co('inde28')."<br><br>";
	$text .= co('inde26')." [".dgmdate($season['time'])."] "."<br><br>";
	if($season['p_reward_v']['ext'] and $season['p_reward_v']['v']){
		$text .= co('inde31')." [".$season['p_reward_v']['v'].$_G['setting']['extcredits'][$season['p_reward_v']['ext']]['title']."]"."<br>";
	}
	if($season['m_reward_v'][1]['ext'] and $season['m_reward_v'][1]['v']){
		$text .= co('inde21')." [".$season['m_reward_v'][1]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][1]['ext']]['title']."]"."<br>";
	}
	if($season['m_reward_v'][2]['ext'] and $season['m_reward_v'][2]['v']){
		$text .= co('inde22')." [".$season['m_reward_v'][2]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][2]['ext']]['title']."]"."<br>";
	}
	if($season['m_reward_v'][3]['ext'] and $season['m_reward_v'][3]['v']){
		$text .= co('inde23')." [".$season['m_reward_v'][3]['v'].$_G['setting']['extcredits'][$season['m_reward_v'][3]['ext']]['title']."]"."<br>";
	}
	$text .= "<br>";
	$text .= co('inde68').$_TRC['SYS_CACHE_TIME'].co('inde69');
	$text .= "<br>";
	
  include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="profit"){
  $profit = DB::result_first("SELECT sum(v) FROM ".DB::table('zgxsh_cq_profit'));
  if(!$profit){$profit=0;}
  $prompt = co('inif29')."<br>".$_TRC['MAIN_JFX_Logo'].$profit.$_TRC['MAIN_JFX_CName'];
  include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="remo_xx"){
  DB::query('DELETE FROM '.DB::table('zgxsh_cq_xx'));
  $prompt = "OK";
  include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="remo_yl"){
  DB::query('DELETE FROM '.DB::table('zgxsh_cq_profit'));
  $prompt = "OK";
  include template('zgxsh_cq:ts/ts');
  exit();
}
elseif($_GET['cz']=="edit_ol_v"){  //edit_ol_v �ķ�
  
  if($_GET['formhash'] != formhash()){
    $text = co('main04');
		include template('zgxsh_cq:ts/ts');
		exit();
  }
  
  $ls['bh'] = daddslashes(dhtmlspecialchars($_GET['bh']));
  $ls['v'] = daddslashes(dhtmlspecialchars($_GET['v']));
  $ls['cl'] = daddslashes(dhtmlspecialchars($_GET['cl']));
  
  DB::update('zgxsh_cq_user',array($ls['cl']=>$ls['v']),array('uid'=>$ls['bh']));
  
  $prompt = "OK";
  include template('zgxsh_cq:ts/ts');
  exit();
}


system_end();
?> 
?>