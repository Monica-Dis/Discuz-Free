<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

$_TRC = $_G['cache']['plugin']['zgxsh_cq'];
$_TRC['MAIN_JFX_CName'] = $_G['setting']['extcredits'][$_TRC['SYS_JFX']]['title'];  
$_TRC['MAIN_JFX_Logo'] = $_G['setting']['extcredits'][$_TRC['SYS_JFX']]['img']; 
$_TRC['MAIN_JFX_NAME'] = 'extcredits'.$_TRC['SYS_JFX'];
$_TRC['MAIN_JFZ'] = DB::result_first("SELECT ".$_TRC['MAIN_JFX_NAME']." FROM ".DB::table('common_member_count')." WHERE uid = '".$_G['uid']."'"); 
if($_TRC['SYS_FHPE_URL']==""){
  $_TRC['SYS_FHPE_URL'] = "forum.php";
}
if($_TRC['SYS_FHPC_URL']==""){
  $_TRC['SYS_FHPC_URL'] = "forum.php";
}
if($_TRC['pc_w']==1){
  $_TRC['pc_w_v'][1] = 6;
  $_TRC['pc_w_v'][2] = 6;
}elseif($_TRC['pc_w']==2){
  $_TRC['pc_w_v'][1] = 7;
  $_TRC['pc_w_v'][2] = 5;
}elseif($_TRC['pc_w']==3){
  $_TRC['pc_w_v'][1] = 8;
  $_TRC['pc_w_v'][2] = 4;
}
//ҳ������
$navtitle = $_TRC['SYS_PNAME'];

//�ı�
$_TRC['obta_lose_txt'] = explode("|",$_TRC['obta_lose_txt']);
$_TRC['tax_fee_txt'] = explode("|",$_TRC['tax_fee_txt']);

//˥����
$_TRC['lose_reward1'] = explode("|",$_TRC['lose_reward1']);
$_TRC['lose_reward2'] = explode("|",$_TRC['lose_reward2']);
$_TRC['lose_reward3'] = explode("|",$_TRC['lose_reward3']);

$_TRC['m_reward_v'][1]['ext'] = $_TRC['lose_reward1'][0];
$_TRC['m_reward_v'][1]['v'] = $_TRC['lose_reward1'][1];
$_TRC['m_reward_v'][2]['ext'] = $_TRC['lose_reward2'][0];
$_TRC['m_reward_v'][2]['v'] = $_TRC['lose_reward2'][1];
$_TRC['m_reward_v'][3]['ext'] = $_TRC['lose_reward3'][0];
$_TRC['m_reward_v'][3]['v'] = $_TRC['lose_reward3'][1];

//�����б�
include 'data/ai_sys.php';
include 'data/season_enh.php';
include 'data/user_enh.php';
include 'data/temp_comp.php';
include 'data/spf.php';
include 'data/mae.php';
include 'data/obta_lose.php';
include 'data/tax_fee.php';

function co($txt){
  $a = lang('plugin/zgxsh_cq',$txt);
  return $a;
}

function system_end($txt=""){
  global $_G;
  $text = co('main01').$txt;
  include template('zgxsh_cq:ts/ts');
  exit();
}

if(!$_G['cache']['plugin']['zgxsh_cq']['SYS_JFX']){
  global $_G;
  $text = co('main02');
  include template('zgxsh_cq:index/index_ts');
  exit();
}

function cx_username($uid){  //��ѯ�ǳ�
  $username = DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '".$uid."'");
	$username = $username==""?" -- ":$username;
	return $username;
}

function sys_integral($uid,$number,$_TRC,$txt=""){  //���ֲ���
  $weal = DB::result_first("SELECT ".$_TRC['MAIN_JFX_NAME']." FROM ".DB::table('common_member_count')." WHERE uid = '".$uid."'"); 
	if(!$weal){
    $weal = 0;   
  }
  if($weal+$number<0 and $number<0){
    global $_G;
    $text = co('main03');
    include template('zgxsh_cq:ts/ts');
    exit();
  }
  updatemembercount($uid,array($_TRC['MAIN_JFX_NAME']=>$number),true,'',0,'',$_TRC['SYS_PNAME'],$txt);
	return;
}

//----[����]----
$user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '".$_G['uid']."'");
if(!$user){
  DB::insert('zgxsh_cq_user',array('uid'=>$_G['uid']));
  $user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '".$_G['uid']."'");
}else{  //�������ڼ����ۺ�ս��
  $user['zh'] = $user['s']*3 + $user['p']*2 + $user['f']*1;
}


$ls['grouplb'] = unserialize($_TRC['SYS_GROUP']);
for($i=0;$i<count($ls['grouplb']);$i++){
	if($ls['grouplb'][$i]==$_G['groupid']){
		$ls['group_true'] = true;
		break;
	}
}
if(!$ls['group_true']){
	showmessage($text = co('inde10'), '', '');
}

function profit($v){
  DB::insert('zgxsh_cq_profit',array('v'=>$v));
}

function cheating(){
  global $_G,$_TRC;
  $cheating = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_xx')." WHERE uid='{$_G['uid']}'");
  foreach($cheating as $k=>$v){
    $penalty = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_xx')." WHERE uid='{$_G['uid']}' AND x_time='{$v['x_time']}' AND j_id='{$v['j_id']}'");  //ս������
    if(count($penalty)>1){
      $txt = co('main07');
      foreach($penalty as $l=>$b){
        if($b['v']>0){
          updatemembercount($_G['uid'],array($_TRC['MAIN_JFX_NAME']=>-$b['v']),true,'',0,'',$_TRC['SYS_PNAME'],$txt);
        }
        DB::update("zgxsh_cq_xx",array('uid'=>0),array('id'=>$b['id']));
      }
      $fsarr = array( 'subject' => co('main08'), 'message' => co('main09') );
      notification_add( $_G['uid'], 'system', 'system_notice', $fsarr, 1 );
      
      $fsarr = array( 'subject' => co('main08'), 'message' => co('main10').cx_username($_G['uid'])." UID ".$_G['uid'].co('main11') );
      notification_add( 1, 'system', 'system_notice', $fsarr, 1 );

    }
    
    $penalty = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_cq_xx')." WHERE uid='{$_G['uid']}' AND x_time='{$v['x_time']}' AND (x_lx='4' OR x_lx='5')");  //�����ڹ�����
    if(count($penalty)>1){
      $fsarr = array( 'subject' => co('main08'), 'message' => co('main10').cx_username($_G['uid'])." UID ".$_G['uid'].co('main12'));
      notification_add( 1, 'system', 'system_notice', $fsarr, 1 );
      
    }
    DB::update("zgxsh_cq_xx",array('uid'=>0),array('id'=>$v['id']));
  }
}

class bl_yz {  //��ȫ��֤��
    
  function release_aq($GB){
    if(!submitcheck('formhash',1)){
      global $_G;
      $text = co('main04');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    $LS['cq'] = dhtmlspecialchars($GB['cq']);
    $LS['sd'] = dhtmlspecialchars($GB['sd']);
    $LS['cm'] = dhtmlspecialchars($GB['cm'])+0;
    $LS['bur'] = dhtmlspecialchars($GB['bur'])+0;
    if(!$LS['cq']){
      global $_G;
      $text = co('main05');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    return $LS;
  }
  
  function list_aq($GB){
    $LS['el'] = dhtmlspecialchars($GB['el']);
    $LS['curr'] = dhtmlspecialchars($GB['curr']);
    return $LS;
  }
  
  function del_than_aq($GB){
    if(!submitcheck('formhash',1)){
      global $_G;
      $text = co('main04');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    return $LS;
  }
  
  function thansub_aq($GB){
    if(!submitcheck('formhash',1)){
      global $_G;
      $text = co('main04');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    $LS['cq'] = dhtmlspecialchars($GB['cq']);
    if(!$LS['cq']){
      global $_G;
      $text = co('main05');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    return $LS;
  }
  
  function cjf($uid,$ZJ){
    $DQ = DB::result_first("SELECT cqjf FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '".$uid."'");  
    $DQ += $ZJ;
    if($DQ<0 and $ZJ<0){
      global $_G;
      $text = co('main03');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    DB::update('zgxsh_cq_user',array('cqjf'=>$DQ),array('uid'=>$uid));
  }
  
  function buysub_aq($GB){
    if(!submitcheck('formhash',1)){
      global $_G;
      $text = co('main04');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    $LS['bh'] = dhtmlspecialchars($GB['bh']);
    $LS['buy_sl'] = dhtmlspecialchars($GB['buy_sl']);
    if(!$LS['buy_sl']){
      global $_G;
      $text = co('main06');
      include template('zgxsh_cq:ts/ts');
      exit();
    }
    return $LS;
  }
  
  //����
  function outcome($p1,$p2){
    if($p1==$p2){
      return 'p';
    }elseif($p1==4){  //��ʤ
      return 's';
    }elseif(($p1==1 and $p2==2)or($p1==2 and $p2==3)or($p1==3 and $p2==1)){
      return 's';
    }else{
      return 'f';
    }
  }

  function s_f_p($uid,$sfp){
    $db = DB::result_first("SELECT ".$sfp." FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '".$uid."'"); 
    $db += 1;
    DB::update('zgxsh_cq_user',array($sfp=>$db),array('uid'=>$uid));
  }
  
  function obta_lose($uid,$field,$v){
    global $_TRC;
    if($field!="obta" and $field!="lose"){
      return;  //EXIT
    }
    if(!$_TRC['obta_lose']){
      return;  //EXIT
    }
    $db = DB::result_first("SELECT {$field} FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '{$uid}'");
    $db += $v;
    DB::update('zgxsh_cq_user',array($field=>$db),array('uid'=>$uid));
    return;
  }
  
  function tax_rank($uid,$v){
    $db = DB::result_first("SELECT tax FROM ".DB::table('zgxsh_cq_user')." WHERE uid = '{$uid}'");
    $db += $v;
    DB::update('zgxsh_cq_user',array("tax"=>$db),array('uid'=>$uid));
    return;
  }
  
  //��� ��ֵ intval() ���� daddslashes()
  function cq_xx($type,$txt){
    global $_G,$LS,$db;
    $ins = array(
      'x_nr' => daddslashes($txt),
      'x_time' => time(),
      'x_lx' => intval($type),
    );
    if($type!=6){
      $ins['uid'] = $_G['uid'];
      $ins['j_id'] = $LS['bh'];
    }
    if($LS[ 'outcome' ]=="s"){
      $ins["v"] = $db[ 'lz_cm' ] * 2 + $_TRC[ 'SYS_TZ_SF' ];
    }
    DB::insert('zgxsh_cq_xx',$ins);
  }
  
  
  
  function release_ins($ins){
    if($ins['lz_uid']){$ins['lz_uid'] = intval($ins['lz_uid']);}
    if($ins['lz_time']){$ins['lz_time'] = intval($ins['lz_time']);}
    if($ins['lz_sz']){$ins['lz_sz'] = intval($ins['lz_sz']);}
    return $ins;
  }
	
	function season_add($get){
    global $_G;
		$get['m_reward'][1]['ext'] = intval($get['m_reward'][1]['ext']);
		$get['m_reward'][1]['v'] = intval($get['m_reward'][1]['v']);
		$get['m_reward'][2]['ext'] = intval($get['m_reward'][2]['ext']);
		$get['m_reward'][2]['v'] = intval($get['m_reward'][2]['v']);
		$get['m_reward'][3]['ext'] = intval($get['m_reward'][3]['ext']);
		$get['m_reward'][3]['v'] = intval($get['m_reward'][3]['v']);
		$get['p_reward']['ext'] = intval($get['p_reward']['ext']);
		$get['p_reward']['v'] = intval($get['p_reward']['v']);
		
		$ins = array(
			'name' => daddslashes($get['name']),
      'time' => strtotime($get['time']),
      'm_reward' => serialize($get['m_reward']),
      'p_reward' => serialize($get['p_reward']),
    );
		if($get['dstime']){  //����ж�ʱ�����Ӷ�ʱ��
			$ins['dstime'] = strtotime($get['dstime']);
			$ins['state'] = 2;
		}
		
		DB::insert('zgxsh_cq_season',$ins);
    
  $text = co('seaenh_10');
	include template('zgxsh_cq:ts/ts');
  exit();
    
	}
	
	function season_edit($get){
		$season = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_cq_season')." WHERE state = '1'");

		if($get['season_op']==1){  //��ʱ
			$season['time'] += $get['season_v']*3600;
			$up = array(
        'time' => intval($season['time']),
      );
		}elseif($get['season_op']==2){  //��ʱ
			$season['time'] -= $get['season_v']*3600;
			$up = array(
        'time' => intval($season['time']),
      );
		}elseif($get['season_op']==3){  //��ֹ
			$season['time'] -= $get['season_v']*3600;
			$up = array(
        'state' => 0,
      );
		}
		
		DB::update('zgxsh_cq_season',$up ,array('id'=>$season['id']));
	}
  
}
//From: d'.'is'.'m.ta'.'obao.com
?>