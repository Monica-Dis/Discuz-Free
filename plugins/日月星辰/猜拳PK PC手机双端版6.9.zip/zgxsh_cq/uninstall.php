<?php
/**
 *	[��ȭPK(zgxsh_cq.uninstall)] (C)2019-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS cdb_zgxsh_cq_user;
DROP TABLE IF EXISTS cdb_zgxsh_cq_xx;
DROP TABLE IF EXISTS cdb_zgxsh_cq_zjb;
DROP TABLE IF EXISTS cdb_zgxsh_cq_season;
DROP TABLE IF EXISTS cdb_zgxsh_cq_profit;
EOF;

runquery($sql);

C::t('common_syscache')->delete('zgxsh_cq');  //��������
C::t('common_syscache')->delete('zgxsh_cq_aitime');  //��������

$finish = true;
?>