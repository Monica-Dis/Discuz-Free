<?php
/**
 *	[����ǽ(zgxsh_pig.install)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_pig_user`;
CREATE TABLE `cdb_zgxsh_pig_user` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `lv` int(2) NOT NULL default '1',
  `exp` int(10) NOT NULL default '0',
  `exp_t` int(10) NOT NULL default '100',
  `jar_cap` int(2) NOT NULL default '2',
  `cost_t` int(10) NOT NULL default '0',
  `cost_s` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
	KEY `uid` (`uid`,`lv`,`cost_t`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_pig_news`;
CREATE TABLE `cdb_zgxsh_pig_news` (
  `id` int(20) NOT NULL auto_increment,
  `txt` varchar(255) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_pig_jar`;
CREATE TABLE `cdb_zgxsh_pig_jar` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `class` int(1) NOT NULL,
  `ceiling` int(5) NOT NULL,
  `current` int(5) NOT NULL default '0',
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
	KEY `uid` (`uid`,`time`)
) ENGINE=MyISAM;
EOF;

runquery($sql);
$finish = true;
?>