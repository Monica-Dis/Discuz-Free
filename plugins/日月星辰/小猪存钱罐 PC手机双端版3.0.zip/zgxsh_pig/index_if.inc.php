<?php
if ( !defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}

include 'module/main.php';

if ( $_GET[ 'op' ] == 'save' ) {
	security::hash_if(1); //formhash
	$ls = security::filter( $_GET );

	$prompt = pig_cap::save_money( $_G[ 'uid' ], $ls[ 'bh' ], $ls[ 'v' ] );

	prompt( $prompt );
} 

elseif ( $_GET[ 'op' ] == 'tank' ) {
	security::hash_if(1); //formhash
	$ls = security::filter( $_GET );

	$prompt = pig_cap::sma_jar( $_G[ 'uid' ], $ls[ 'bh' ] );
	prompt( $prompt );
}

elseif ( $_GET[ 'op' ] == 'buy' ) {
	security::hash_if(1); //formhash
	$ls = security::filter( $_GET );

	if ( $ls[ 'cl' ]==0 ) {
		$price = $_TRC['small_price'];
	} else {
		$price = $_TRC['fly_price'];
	}
	$prompt = pig_cap::win_jar( $_G[ 'uid' ], $price, $ls[ 'cl' ] );
	prompt( $prompt );
}

elseif ( $_GET[ 'op' ] == 'make' ) {
	$ls[ "make" ] = DB::result_first( "SELECT SUM(cost_t) FROM " . DB::table( 'zgxsh_pig_user' ) );
	$prompt = co('inde03'). $ls[ "make" ] . " " . $_TRC[ 'ext_main_title' ];
  if($_G['adminid']==1){
    $prompt .= "<br><a style='color:#369' href='plugin.php?id=zgxsh_pig:index_if&op=empty'>".co('inde13')."</a>"; 
  }
	prompt( $prompt );
}
elseif ( $_GET[ 'op' ] == 'user_see' ) {
	//��ȡ�ֿ�͹�����Ϣ
	$db_user = pig_cap::user_true( $_G[ 'uid' ] );
	$db_cap = DB::fetch_all( "SELECT * FROM " . DB::table( 'zgxsh_pig_jar' ) . " WHERE uid = '" . $_G[ 'uid' ] . "'" );

	//��������
	$db_cap_n = count( $db_cap );

	//ǰ̨��ʾ����
	for ( $i = 0; $i < $db_cap_n; $i++ ) {
		if ( $db_cap[ $i ][ 'class' ] ) {
			$db_cap[ $i ][ 'pf' ] = 'f';
			$db_cap[ $i ][ 'img' ] = 'fz';
			$db_cap[ $i ][ 'txt' ] = co('inde01');
		} else {
			$db_cap[ $i ][ 'pf' ] = 'p';
			$db_cap[ $i ][ 'img' ] = 'xz';
			$db_cap[ $i ][ 'txt' ] = co('inde02');
		}
	}

  //���㾭��ٷֱȺ͹��Ӱٷֱ�
  $cap_exp = floor($db_user['exp'] / $db_user['exp_t']*100)."%";
  $cap_num = floor($db_cap_n / $db_user['jar_cap']*100)."%";

	//�����λ������
	if ( $db_cap_n < $db_user[ 'jar_cap' ] ) {
		$db_cap_empty = $db_user[ 'jar_cap' ] - $db_cap_n;
	}

	//�����б�
	$pig_news_list = pig_news::see();

	$db_jar_num = DB::fetch_all( "SELECT * FROM " . DB::table( 'zgxsh_pig_jar' ) . " ORDER BY current DESC" );
	for ( $i = 0; $i < count( $db_jar_num ); $i++ ) {
		$db_jar_num[ $i ][ 'name' ] = q_name( $db_jar_num[ $i ][ 'uid' ] );
		if ( $db_jar_num[ $i ][ 'class' ] ) {
			$db_jar_num[ $i ][ 'class_name' ] = co('inde05');
		} else {
			$db_jar_num[ $i ][ 'class_name' ] = co('inde04');
		}
		$db_jar_num[ $i ][ 'pm' ] = $i + 1;
	}
	include template( 'zgxsh_pig:index/user_see' );
	exit();
}
elseif ( $_GET[ 'op' ] == 'eat' ) {  //�̽�
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  security::int_if($ls['v'],co('inde06'));
  //���úϷ��ж�
  if(!$_TRC['ext_eat']){
    prompt(co('inde07'));
  }
  if($_TRC['ext_v']<1){
    prompt(co('inde08'));
  }
  //�����̽�
  $ls['add'] = floor($ls['v']/$_TRC['ext_v']); //���ӵĻ���
  $ls['rem'] = $ls['v']%$_TRC['ext_v'];  //ʣ�����
  $ls['red'] = $ls['v']-$ls['rem'];  //Ӧ���ٻ���
  //������ӯ��
  $db_cap = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_pig_jar')." WHERE id = '".$ls['bh']."'");
  if($db_cap['ceiling']==$db_cap['current']){
    prompt(co('inde09'));
  }
  if($db_cap['ceiling']<$db_cap['current']+$ls['add']){
    $ls['add_d'] = $db_cap['current']+$ls['add']-$db_cap['ceiling'];  //���˶���
    $ls['add'] -= $ls['add_d'];  //��ȥ��Ļ���
    $ls['rem'] += $ls['add_d']*$_TRC['ext_v'];  //����ʣ�����
    $ls['red'] = $ls['v']-$ls['rem'];  //���¼���Ӧ�ü��ٵĻ���
  }
  //���ֲ���
  integral($_G['uid'],-$ls['red'],$_TRC['ext_eat'],co('inde10'),co('inde11'));
  DB::update('zgxsh_pig_jar',array('current'=>$db_cap['current']+$ls['add']),array('id'=>$ls['bh']));
  $co = array(
    'co1' => $ls['red'],
    'co2' => $_G['setting']['extcredits'][$_TRC['ext_eat']]['title'],
    'co3' => $ls['rem'],
    'co4' => $ls['add'],
    'co5' => $_TRC['ext_save_title'],
  );
  prompt(co('inde12',$co));
}
// ���Ӫҵͳ��
elseif ( $_GET[ 'op' ] == 'empty' ) {
  DB::update('zgxsh_pig_user',array('cost_t'=>0));
  prompt(co('inde14'),"location='plugin.php?id=zgxsh_pig:index'");
}

//��������
elseif ( $_GET[ 'op' ] == 'pig_clean' ) {
  security::hash_if(1); //formhash
	$ls = security::filter( $_GET );
  
  if($_G['uid']!=1){
    prompt(co('inde20'),"location='plugin.php?id=zgxsh_pig:index_if&op=user_see'",array('icon'=>3));
  }
  
  $pig = pig_clean::see_all();
  foreach($pig as $k=>$v){
    if($v['class']){  //��
      integral($v['uid'],$_TRC['fly_price'],$_TRC['ext_main'],$_TRC['p_name'],co('inde15'));
      integral($v['uid'],$v['current'],$_TRC['ext_save'],$_TRC['p_name'],co('inde16'));
    }else{  //С
      integral($v['uid'],$_TRC['small_price'],$_TRC['ext_main'],$_TRC['p_name'],co('inde17'));
      integral($v['uid'],$v['current'],$_TRC['ext_save'],$_TRC['p_name'],co('inde16'));
    }
    notice($v['uid'],$_TRC['p_name'],co('inde18'));
    pig_clean::del(array('id'=>$v['id']));
  }
  
  prompt(co('inde19'),"location='plugin.php?id=zgxsh_pig:index_if&op=user_see'");
}

system_end();
?>