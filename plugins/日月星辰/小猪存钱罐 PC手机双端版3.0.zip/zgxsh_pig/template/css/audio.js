function autoPlay(name) {
  var myAuto = document.getElementById(name);
  myAuto.play();
}
function closePlay(name) {
  var myAuto = document.getElementById(name);
  myAuto.pause();
  myAuto.load();
}