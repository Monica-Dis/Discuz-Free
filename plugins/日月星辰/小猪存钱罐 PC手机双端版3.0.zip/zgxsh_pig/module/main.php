<?php
if ( !defined( 'IN_DISCUZ' ) ) {
  exit( 'Access Denied' );
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

//----ϵͳ��������----
$_TRC = $_G[ 'cache' ][ 'plugin' ][ 'zgxsh_pig' ];
//����
$_TRC['ext_main_title'] = $_G['setting']['extcredits'][$_TRC['ext_main']]['title'];
$_TRC['ext_main_img'] = $_G['setting']['extcredits'][$_TRC['ext_main']]['img']; 	
$_TRC['ext_main_unit'] = $_G['setting']['extcredits'][$_TRC['ext_main']]['unit']; 
$_TRC['ext_main_num'] = getuserprofile('extcredits'.$_TRC['ext_main']); 

$_TRC['ext_save_title'] = $_G['setting']['extcredits'][$_TRC['ext_save']]['title'];  //��������
$_TRC['ext_save_img'] = $_G['setting']['extcredits'][$_TRC['ext_save']]['img']; 	  //����ͼ��
$_TRC['ext_save_unit'] = $_G['setting']['extcredits'][$_TRC['ext_save']]['unit'];   //���ֵ�λ
$_TRC['ext_save_num'] = getuserprofile('extcredits'.$_TRC['ext_save']);  //��ȡ�û���
	
//ȥ�������еĻس��Ϳո�
$qian=array(" ","��","\t","\n","\r");
$_TRC['help_txt'] = str_replace($qian,'',$_TRC['help_txt']);  

//print_r($_TRC['help_txt']);

//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC[ 'p_name' ];

//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';
include 'class/ip.php';

//----�������----
//��� ��ֵ intval() ���� daddslashes()
class pig_cap{
  function user_true($uid){  //�����û���ʼ��
    global $_TRC;
    $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_pig_user')." WHERE uid = '".$uid."'");
    if(!$r){
      DB::insert('zgxsh_pig_user',array('uid'=>$uid));
      $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_pig_user')." WHERE uid = '".$uid."'");
			pig_news::add(co('main03').q_name($uid).co('main04').$_TRC['p_name'].co('main05'));
    }
    return $r;
  }
  
  function jar_increase($lv){  //Ŀ��ȼ�
    if($lv>1 and $lv<18){
      return 1;
    }elseif($lv>=18 and $lv<=20){
      return 2;
    }else{
      return 0; 
    }
  }
  
  function exp_change($uid,$number){  //���������䶯
    $r = self::user_true($uid);
    $r['exp']+=$number;
    if($r['exp']>=$r['exp_t']){  //������
      $r['exp']-=$r['exp_t'];
      $r['exp_t']+=$r['exp_t'];
      $r['lv']+=1;
      $r['jar_cap']+=self::jar_increase($r['lv']);
      $ls['lvup'] = co('main06').self::jar_increase($r['lv']);
			pig_news::add(q_name($uid).$ls['lvup']);
    }
    DB::update('zgxsh_pig_user',$r,array('uid'=>$uid));
    $r = $ls['lvup'];
    return $r;
  }
  
  function win_jar($uid,$price,$class){  //��������
		
		global $_TRC;
		
    $r = self::user_true($uid);
    $db_cap_n = DB::fetch_all("SELECT id FROM ".DB::table('zgxsh_pig_jar')." WHERE uid = '".$uid."'");

    if(count($db_cap_n)>=$r['jar_cap']){  //���ӳ�������
      prompt(co('main07'));
    }
        
    if($price>0){
			integral($uid,-$price,$_TRC['ext_main'],co('main08'),co('main09'));
      $r['cost_t']+=$price;
      DB::update('zgxsh_pig_user',array('cost_t'=>$r['cost_t']),array('uid'=>$uid));
    }
    
    if(!$class){
      $cap_save_max = $_TRC['small_k'];
    }else{
      $cap_save_max = $_TRC['fly_k'];
    }
    
    $in = array(
      'uid' => $uid,
      'class' => $class,
      'ceiling' => $cap_save_max,
      'time' => time()
    );
    DB::insert('zgxsh_pig_jar',$in);
    
    $cap_class = $class==0?$_TRC['small_name']:$_TRC['fly_name'];

		pig_news::add(q_name($uid).co('main12').$cap_class.co('main13'));
    return co('main14').' ['.$cap_class.co('main15').$price.$_TRC['ext_main_title'].co('main16');
  }
  
  function sma_jar($uid,$jarid){  //�ҹ�ȡǮ
		
		global $_TRC;
		
    $db_cap = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_pig_jar')." WHERE id = '".$jarid."'");
    if(!$db_cap){  //���Ӳ�������ʾ
      prompt(co('main17'));
    }
    if(($db_cap['time']+86400)>time()){ //���Ӵ���ʱ�䲻��24Сʱ��ʾ
      prompt(co('main18'));
    }
		integral($uid,$db_cap['current'],$_TRC['ext_save'],co('main19'),co('main20'));
    DB::delete('zgxsh_pig_jar',array('id'=>$jarid),1);
    
    if($db_cap['class']){
      $ls['base'] = floor(100*($db_cap['current']/$db_cap['ceiling']))+rand(6,18);
    }else{
      $ls['base'] = floor(20*($db_cap['current']/$db_cap['ceiling']))+rand(6,18);
    }
    
    $ls['lvup'] = self::exp_change($uid,$ls['base']);
      
    $exp = co('main21').$ls['base']."<br>";
    $money = co('main22').$_TRC['ext_save_title'].": ".$db_cap['current']."<br>";
		
		pig_news::add(q_name($uid).co('main23'));

    return co('main24').'<br>'.$exp.$money.$ls['lvup'];
  }
  
  function save_money($uid,$jarid,$number){  //��Ǯ
		
		global $_TRC;
		
    $db_cap = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_pig_jar')." WHERE id = '".$jarid."'");
    if(!$db_cap){  //���Ӳ�������ʾ
      prompt(co('main25'));
    }
    if($db_cap['current']>=$db_cap['ceiling']){  //���Ӳ�������ʾ
      prompt(co('main26'));
    }
    
    if($number<0){
      //������й���
      DB::delete('zgxsh_pig_jar',array('uid'=>$uid));
      //ͬʱ����
      $fsarr = array( 'subject' => co('main27'), 'message' => co('main28').q_name($uid).co('main29'));
      notification_add( 1, 'system', 'system_notice', $fsarr, 1 );
      //��ʾ�������
      prompt(co('main30'));
    }
        
    $money_all = $db_cap['current']+$number;
    
    if($money_all>$db_cap['ceiling']){  //����ӯ��
      $money_bala = $money_all-$db_cap['ceiling'];
      $money_all = $db_cap['ceiling'];
      $money_save = $number - $money_bala;
    }else{
      $money_save = $number;
    }
       
		integral($uid,-$money_save,$_TRC['ext_save'],co('main31'),co('main32'));

    DB::update('zgxsh_pig_jar',array('current'=>$money_all),array('id'=>$jarid));
       
    $r  = co('main33');
    $r .= co('main34').$number." ".$_TRC['ext_save_title'].co('main35');
    $r .= co('main36').$money_save." ".$_TRC['ext_save_title'].co('main37');
    if($money_bala>0){
      $r .= co('main38').$money_bala." ".$_TRC['ext_save_title'].co('main39');
    }
		
		pig_news::add(q_name($uid).co('main40'));
    
    return $r;
  }
}
//����
class pig_news{
	function add($txt){
		$in = array(
      'txt' => $txt,
      'time' => time(),
		);
		DB::insert('zgxsh_pig_news',$in);
		return true;
	}
	function see(){
		$db_new = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_pig_news')." ORDER BY id DESC LIMIT 10");
		for($i=0;$i<count($db_new);$i++){
			$db_new[$i]['date'] = dgmdate($db_new[$i]['time'],'u');
		}
		return $db_new;
	}
}

//----��չ----
include 'extension/pig_clean.php';

?>