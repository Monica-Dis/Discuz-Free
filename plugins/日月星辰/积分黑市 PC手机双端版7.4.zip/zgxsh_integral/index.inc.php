<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

$beyond_all['t_name_2'] = "";
$beyond_all['query_field_2'] = "";
$beyond_all['query_field'] = "";


//$beyond_all['inte_query'] = DB::result_first("SELECT ".$beyond_all['query_field']." FROM ".$beyond_all['t_name_2']." WHERE ".$beyond_all['query_field_2']."='".$_G['uid']."'");
//$beyond_all['inte_v'] = DB::result_first("SELECT ".$beyond_all['target_field']." FROM ".$beyond_all['t_name']." WHERE ".$beyond_all['query_field']."='".$beyond_all['inte_query']."'");
//
//
//print_r($beyond_all['inte_query']);
//exit();

//----������ʱ�¼�---- 
if($_TRC['o_time']>0){
  $sale_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE state = '0' AND time_1<'".(time()-$_TRC['o_time'])."'");
  for($i=0;$i<count($sale_all);$i++){
    if($sale_all[$i]['inte_1']<=8){
      integral($sale_all[$i]['uid_1'],$sale_all[$i]['v_1'],$sale_all[$i]['inte_1'],$_TRC['p_name'],co('i_if48'));
    }else{
      beyond_inte($sale_all[$i]['uid_1'],$sale_all[$i]['v_1'],$sale_all[$i]['inte_1']);
    }
    notice($sale_all[$i]['uid_1'],$_TRC['p_name'],co('i_if49',array('co1'=>$sale_all[$i]['id'])));
    news::add(5,q_name($sale_all[$i]['uid_1']).co('news07').$ls['bh'].co('news09'));
    DB::update('zgxsh_integral_sale',array('state'=>2),array('id'=>$sale_all[$i]['id']));
  }
  if(count($sale_all)>0){  //��������
    header("Location:plugin.php?id=zgxsh_integral:index");
    exit();
  }
}


//----��ȡ�����û�����----
$user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_user')." WHERE uid='".$_G['uid']."'");
if(!$user){
  $_TRC['giving'] = $_TRC['giving']<=0?0:$_TRC['giving'];  //������СΪ0
  $user = array(
     'uid' => $_G['uid']
    ,'inte' => $_TRC['giving']
  );
  DB::insert('zgxsh_integral_user',$user);
  news::add(1,q_name($_G['uid']).co('i_if50')); 
}

//----������������ͼ----
db_op::detection_writing();  //ץȡ��������
$e_rf = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_rf')." ORDER BY id DESC LIMIT 10");
sort($e_rf);  //���������ع���
for($i=0;$i<count($e_rf);$i++){  //����ʱ����
  $rf_see['time_all'][] = dgmdate($e_rf[$i]['time'],"Y-m-d");
  $rf_see['e1_v_all'][] = $e_rf[$i]['e1_v'];
  $rf_see['e2_v_all'][] = $e_rf[$i]['e2_v'];
  $rf_see['e3_v_all'][] = $e_rf[$i]['e3_v'];
  $rf_see['e4_v_all'][] = $e_rf[$i]['e4_v'];
  $rf_see['e5_v_all'][] = $e_rf[$i]['e5_v'];
  $rf_see['e6_v_all'][] = $e_rf[$i]['e6_v'];
  $rf_see['e7_v_all'][] = $e_rf[$i]['e7_v'];
  $rf_see['e8_v_all'][] = $e_rf[$i]['e8_v'];
}
foreach($_TRC['extc'] as $k=>$v){  //վ�㿪ͨ��ʲô����
  //����������
  $lsid = $_TRC['extc'][$k]['id'];
  if(($_TRC['guan_ext'] and !$_TRC['guan'.$lsid]) or !$_TRC['guan_ext']){
    $rf_see['title_all'][] = $_TRC['extc'][$k]['title'];
  
  
  //��������
  //$rf_see['e_v'] .= "{name:'".$_TRC['extc'][$k]['title']."',type:'line',stack: 'e".$k."_v',data:['".implode("','",$rf_see['e'.$k.'_v_all'])."']},";
  $rf_see['e_v'][] = array(
    'name' => diconv($_TRC['extc'][$k]['title'],CHARSET,'utf-8'),
    'type' => 'line',
    'stack' => 'e'.$k.'_v',
    'data' => $rf_see['e'.$k.'_v_all'],
  ); 
  
  }
}

$rf_see['e_v'] = json_encode($rf_see['e_v']);


//ͼ����ݹ���
$rf_see['time'] = "'".implode("','",$rf_see['time_all'])."'";
$rf_see['title'] = "'".implode("','",$rf_see['title_all'])."'";

//��ͼ���ǰ��ձ����ȡ�ֽ���
if(CHARSET == 'utf-8'){
  $coding = 3;
}else{
  $coding = 2;
}

//--------[��ȡ����]--------
$db_order = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE state='0'");
for($i=0;$i<count($db_order);$i++){
  $k_1 = $db_order[$i]['inte_1'];  //������1
  $k_2 = $db_order[$i]['inte_2'];  //������2
  $db_order[$i]['name_1'] = q_name($db_order[$i]['uid_1']);
  $db_order[$i]['name_2'] = q_name($db_order[$i]['uid_2']);
  $db_order[$i]['date_1'] = dgmdate($db_order[$i]['time_1'],'u');
  
  $db_order[$i]['inte_n_1'] = $_TRC['extc'][$k_1]['title'];
  $db_order[$i]['inte_i_1'] = $_TRC['extc'][$k_1]['img']==''?substr($db_order[$i]['inte_n_1'],0,$coding):$_TRC['extc'][$k_1]['img'];
  $db_order[$i]['inte_u_1'] = $_TRC['extc'][$k_1]['unit'];
  
  if($k_2<=8){  //����2ʱ��ͨ����    
    $db_order[$i]['inte_n_2'] = $_TRC['extc'][$k_2]['title'];
    $db_order[$i]['inte_i_2'] = $_TRC['extc'][$k_2]['img']==''?substr($db_order[$i]['inte_n_2'],0,$coding):$_TRC['extc'][$k_1]['img'];
    $db_order[$i]['inte_u_2'] = $_TRC['extc'][$k_2]['unit'];
  }else{  //����2���Զ������
    $ls_intname = DB::fetch_first("SELECT int_name,int_unit,int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$k_2."'");
    if(!$ls_intname){
      $db_order[$i]['inte_n_2'] = " -- ";
      $db_order[$i]['inte_i_2'] = "";
      $db_order[$i]['inte_u_2'] = "";
    }else{
      $db_order[$i]['inte_n_2'] = $ls_intname['int_name'];
      $db_order[$i]['inte_i_2'] = $ls_intname['int_ico']==''?substr($beyond_all[$i]['inte_n_2'],0,$coding):$ls_intname['int_ico'];
      $db_order[$i]['inte_u_2'] = $ls_intname['int_unit'];
    }
  }
  
  
}

//�����������
$beyond_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE trading>0");
for($i=0;$i<count($beyond_all);$i++){
  $beyond_all[$i]['order_db'] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE inte_1='".$beyond_all[$i]['inte_id']."' AND state='0'");
  $beyond_all[$i]['order'] = count($beyond_all[$i]['order_db']);
  for($o=0;$o<count($beyond_all[$i]['order_db']);$o++){
    $k_1 = $beyond_all[$i]['order_db'][$o]['inte_1'];  //������1
    $k_2 = $beyond_all[$i]['order_db'][$o]['inte_2'];  //������2
    $beyond_all[$i]['order_db'][$o]['name_1'] = q_name($beyond_all[$i]['order_db'][$o]['uid_1']);
    $beyond_all[$i]['order_db'][$o]['name_2'] = q_name($beyond_all[$i]['order_db'][$o]['uid_2']);
    $beyond_all[$i]['order_db'][$o]['inte_n_1'] = $beyond_all[$i]['int_name'];
    $beyond_all[$i]['order_db'][$o]['inte_i_1'] = $beyond_all[$i]['int_ico']==''?substr($beyond_all[$i]['order_db'][$o]['inte_n_1'],0,$coding):$ls_intname['int_ico'];
    $beyond_all[$i]['order_db'][$o]['inte_u_1'] = $beyond_all[$i]['int_unit'];
    if($k_2<=8){  //����2ʱ��ͨ����
      $beyond_all[$i]['order_db'][$o]['inte_n_2'] = $_TRC['extc'][$k_2]['title'];
      $beyond_all[$i]['order_db'][$o]['inte_i_2'] = $_TRC['extc'][$k_2]['img']==''?substr($beyond_all[$i]['order_db'][$o]['inte_n_2'],0,$coding):$_TRC['extc'][$k_1]['img'];
      $beyond_all[$i]['order_db'][$o]['inte_u_2'] = $_TRC['extc'][$k_2]['unit'];
    }else{  //����2���Զ������
      $ls_intname = DB::fetch_first("SELECT int_name,int_unit,int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$k_2."'");
      if(!$ls_intname){
        $beyond_all[$i]['order_db'][$o]['inte_n_2'] = " -- ";
        $beyond_all[$i]['order_db'][$o]['inte_i_2'] = "";
        $beyond_all[$i]['order_db'][$o]['inte_u_2'] = "";
      }else{
        $beyond_all[$i]['order_db'][$o]['inte_n_2'] = $ls_intname['int_name'];
        $beyond_all[$i]['order_db'][$o]['inte_i_2'] = $ls_intname['int_ico']==''?substr($beyond_all[$i]['order_db'][$o]['inte_n_2'],0,$coding):$ls_intname['int_ico'];
        $beyond_all[$i]['order_db'][$o]['inte_u_2'] = $ls_intname['int_unit'];
      }
    }
    
    $beyond_all[$i]['order_db'][$o]['date_1'] = dgmdate($beyond_all[$i]['order_db'][$o]['time_1'],'u');
  }
}

$news_see = news::see();


include template('zgxsh_integral:index/index'); 
?>