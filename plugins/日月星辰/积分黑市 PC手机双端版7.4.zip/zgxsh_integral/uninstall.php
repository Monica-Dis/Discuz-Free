<?php
/**
 *	[��ȭPK(zgxsh_integral.uninstall)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS cdb_zgxsh_integral_rf;
DROP TABLE IF EXISTS cdb_zgxsh_integral_sale;
DROP TABLE IF EXISTS cdb_zgxsh_integral_system;
DROP TABLE IF EXISTS cdb_zgxsh_integral_user;
DROP TABLE IF EXISTS cdb_zgxsh_integral_beyond_space;
EOF;

runquery($sql);

$finish = true;
?>