<?php
/**
 *	[��ȭPK(zgxsh_cq.upgrade)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_integral_system')." LIKE 'integral_limit'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_integral_system')." ADD integral_limit varchar(2000) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_integral_system')." LIKE 'conv_min_eid'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_integral_system')." ADD conv_min_eid varchar(2000) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_integral_system')." LIKE 'conv_max_eid'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_integral_system')." ADD conv_max_eid varchar(2000) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_integral_system')." LIKE 'conv_min_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_integral_system')." ADD conv_min_v varchar(2000) NOT NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_integral_system')." LIKE 'conv_max_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_integral_system')." ADD conv_max_v varchar(2000) NOT NULL");
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_integral_beyond_space` (
  `id` int(10) NOT NULL auto_increment,
  `inte_id` int(10) NOT NULL,
  `t_name` varchar(80) NOT NULL,
  `target_field` varchar(80) NOT NULL,
  `query_field` varchar(80) NOT NULL,
  `model` int(1) NOT NULL,
  `t_name_2` varchar(80) NOT NULL,
  `query_field_2` varchar(80) NOT NULL,
  `int_name` varchar(80) NOT NULL,
  `int_unit` varchar(80) NOT NULL,
  `int_ico` varchar(180) NOT NULL,
  `trading` int(1) NOT NULL default '0',
  `v` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id` USING BTREE (`id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `cdb_zgxsh_integral_news` (
  `id` int(10) NOT NULL auto_increment,
  `type` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = true;
?>