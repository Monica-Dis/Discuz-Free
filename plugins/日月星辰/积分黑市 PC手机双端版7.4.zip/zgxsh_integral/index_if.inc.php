<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

if($_GET['op']=="setup_trading"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  foreach($_TRC['extc'] as $k=>$v){
    if(!$system['integral_switch_'.$k]){
      $checked = "";
    }else{
      $checked = "checked";
    }
    $checkbox .= '<input type="checkbox" name="like[e_'.$k.']" title="'.$_TRC['extc'][$k]['title'].'" '.$checked.'>';
  }
  
  include template('zgxsh_integral:setup/setup_trading');
	exit();
}
elseif($_GET['op']=="setup_trading_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);  //dhtmlspecialchars
  db_op::setup_trading($ls);
  prompt(co('i_if01'));
}
elseif($_GET['op']=="setup_exchange"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  include template('zgxsh_integral:setup/setup_exchange');
	exit();
}
elseif($_GET['op']=="setup_exchange_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  db_op::setup_exchange($ls);
  prompt(co('i_if01'));
}
elseif($_GET['op']=="setup_beyond"){  //������������
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  $space = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space'));
  include template('zgxsh_integral:setup/setup_beyond');
	exit();
}
elseif($_GET['op']=="setup_limit"){  //�����������
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  $space = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space'));
  include template('zgxsh_integral:setup/setup_limit');
	exit();
}
elseif($_GET['op']=="setup_limit_sub"){  //������������ύ
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  db_op::setup_limit($ls);
  prompt(co("i_if31"));
}
elseif($_GET['op']=='setup_conv'){  //����ת������
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  include template('zgxsh_integral:setup/setup_conv');
	exit();
}
elseif($_GET['op']=="setup_conv_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  db_op::setup_conv($ls);
  prompt(co('i_if01'));
}

//�һ�ī��
elseif($_GET['op']=="exchange"){
  $beyond_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE v>0");
  for($i=0;$i<count($beyond_all);$i++){
    if($beyond_all[$i]['model']==0){  //ֱ�Ӳ�ѯ
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$_G['uid']."'");
    }else{  //��ά��ѯ
      $beyond_all[$i]['inte_query'] = DB::result_first("SELECT ".$beyond_all[$i]['query_field']." FROM ".$beyond_all[$i]['t_name_2']." WHERE ".$beyond_all[$i]['query_field_2']."='".$_G['uid']."'");
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE u".$beyond_all[$i]['query_field']."='".$beyond_all[$i]['inte_query']."'");
    }
    $beyond_all[$i]['k'] = "n_".$beyond_all[$i]['inte_id'];
    if(!$beyond_all[$i]['inte_v']){
      $beyond_all[$i]['inte_v'] = 0;
    }
  }
  include template('zgxsh_integral:exchange/exchange');
	exit();
}
elseif($_GET['op']=="exchange_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  for($i=1;$i<=8;$i++){
    $ls["n_".$i] += 0;
    if($ls["n_".$i]>0){  //���۸÷������
      security::int_if($ls["n_".$i],co('i_if02').$_TRC['extc'][$i]['title']);
      $ls['qs'][$i] = inte_probe($_G['uid'],$ls["n_".$i],$i);  //����̽�� ̽��ȱ����
      if($ls['qs'][$i]>0){  //ȱ�ٴ���0
        $ls["n_".$i] -= $ls['qs'][$i];  //�ı���۽��
        $prompt_add .= co('i_if03').($ls["n_".$i]+$ls['qs'][$i]).$_TRC['extc'][$i]['unit'].$_TRC['extc'][$i]['title']."<br>";
        $prompt_add .= co('i_if04').$ls["n_".$i].$_TRC['extc'][$i]['unit']."<br>";
      }
      $ls['sum'] += $ls["n_".$i];
    }
  }
  //�ж���������
  $beyond_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE v>0");
  for($i=0;$i<count($beyond_all);$i++){
    if($beyond_all[$i]['model']==0){  //ֱ�Ӳ�ѯ
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$_G['uid']."'");
    }else{  //��ά��ѯ
      $beyond_all[$i]['inte_query'] = DB::result_first("SELECT ".$beyond_all[$i]['query_field']." FROM ".$beyond_all[$i]['t_name_2']." WHERE ".$beyond_all[$i]['query_field_2']."='".$_G['uid']."'");
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$beyond_all[$i]['inte_query']."'");
    }
    $beyond_all[$i]['k'] = "n_".$beyond_all[$i]['inte_id'];
    if($ls[$beyond_all[$i]['k']]>0){  //��������ύ����
      $beyond_all[$i]['qs'] = $ls[$beyond_all[$i]['k']] - $beyond_all[$i]['inte_v'];
      if($beyond_all[$i]['qs']>0){  //ȱ�ٴ���0
        $ls[$beyond_all[$i]['k']] -= $beyond_all[$i]['qs'];  //�ı���۽��
        $prompt_add .= co('i_if03').($ls[$beyond_all[$i]['k']]+$beyond_all[$i]['qs']).$beyond_all[$i]['int_unit'].$beyond_all[$i]['int_name']."<br>";
        $prompt_add .= co('i_if04').$ls[$beyond_all[$i]['k']].$beyond_all[$i]['int_unit']."<br>";
      }
      $ls['sum'] += $ls[$beyond_all[$i]['k']];
    }
  }
  
  
  if($ls['sum']<=0){  //�޷���ʾ
    prompt(co('i_if18').$beyond_all[$i]['k']);
  }
  
  if(db_op::exchange_sub($ls)){
		prompt(co('i_if05').$prompt_add);
	}
}
//����ת��
elseif($_GET['op']=="conv"){
  
  $conv_max_l = getuserprofile('extcredits'.$system['conv_max_eid']);
    
  $o = 1;
  for($i=$system['conv_min_v'];$i<=$conv_max_l;$i+=$system['conv_min_v']){
    if($o>100){
      break;
    }
    $option .= '<option value="'.$i.'"> '.co('i_if41').' '.$i.$_TRC['extc'][$system['conv_max_eid']]['title'].' '.co('i_if42').' '.$o*$system['conv_max_v'].$_TRC['extc'][$system['conv_min_eid']]['title'].' </option>';
    $o++;
  }
  
  include template('zgxsh_integral:conv/conv');
	exit();
}
elseif($_GET['op']=="conv_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  if($ls['conv_v']<=0){
    prompt(co('i_if43'));
  }
  $min_add = $system['conv_max_v']*floor($ls['conv_v']/$system['conv_min_v']);  //����ͽ׷�������
  
  integral($_G['uid'],-$ls['conv_v'],$system['conv_max_eid'],$_TRC['p_name'],co('i_if45'));
  integral($_G['uid'],$min_add,$system['conv_min_eid'],$_TRC['p_name'],co('i_if46'));
  
  $co = array(
    'co1' => q_name($_G['uid']),
    'co2' => $ls['conv_v'].$_TRC['extc'][$system['conv_max_eid']]['title'],
    'co3' => $min_add.$_TRC['extc'][$system['conv_min_eid']]['title'],
  );
  news::add(4,co('i_if47',$co));
  $pro = array(
    '1' => $_TRC['extc'][$system['conv_max_eid']]['title'],
    '2' => $ls['conv_v'],
    '3' => $_TRC['extc'][$system['conv_min_eid']]['title'],
    '4' => $min_add,
  );
  prompt(co('i_if40',$pro));
}
//���ֽ��� 
elseif($_GET['op']=="integral_sale"){
  $see['form'] = layui::form_name();
  //�����������
  $beyond_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE trading!=0");
  for($i=0;$i<count($beyond_all);$i++){
    if($beyond_all[$i]['model']==0){  //ֱ�Ӳ�ѯ
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$_G['uid']."'");
    }else{  //��ά��ѯ
      $beyond_all[$i]['inte_query'] = DB::result_first("SELECT ".$beyond_all[$i]['query_field']." FROM ".$beyond_all[$i]['t_name_2']." WHERE ".$beyond_all[$i]['query_field_2']."='".$_G['uid']."'");
      $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$beyond_all[$i]['inte_query']."'");
    }
    if(!$beyond_all[$i]['inte_v']){
      $beyond_all[$i]['inte_v'] = 0;
    }
  }
  
  $see['form']['form_on'] = $see['form']['name'].".on('select()', function(data){
    var opt_length = document.getElementById(data.elem.name).options.length;
    for(var i=0;i<opt_length;i++){
      document.getElementById(data.elem.name).options[i].disabled=false;
    }
    var index = data.elem.selectedIndex;
    //console.log(index);    
    document.getElementById(data.elem.name).options[index].disabled=true;
    ".$see['form']['name'].".render('select');    
  });";
  
  if($_GET['cq']=="c"){  //����/��    
    include template('zgxsh_integral:integral/integral_sale_c');
  }else{
    include template('zgxsh_integral:integral/integral_sale_q');
  }
	exit();
}
elseif($_GET['op']=="integral_sale_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
    
  security::int_if($ls['inte_1'],co('i_if06'));
  security::int_if($ls['v_1'],co('i_if07'));
  security::int_if($ls['inte_2'],co('i_if08'));
  security::int_if($ls['v_2'],co('i_if09'));
  if($ls['sl']<=0){
    $ls['sl'] = 1;
  }
  security::int_if($ls['sl'],co('i_if54'));
  if($ls['inte_1'] == $ls['inte_2']){
    prompt(co('i_if10'));
  }
  if($ls['v_1']<$system['integral_limit']['min_'.$ls['inte_1']] and $system['integral_limit']['min_'.$ls['inte_1']]>0){
    prompt(co('i_if29',array('inte'=>$_TRC['extc'][$ls['inte_1']]['title'],'min'=>$system['integral_limit']['min_'.$ls['inte_1']])));
  }
  if($ls['v_1']>$system['integral_limit']['max_'.$ls['inte_1']] and $system['integral_limit']['max_'.$ls['inte_1']]>0){
    prompt(co('i_if30',array('inte'=>$_TRC['extc'][$ls['inte_1']]['title'],'max'=>$system['integral_limit']['max_'.$ls['inte_1']])));
  }
  $ls['uid_1'] = $_G['uid'];
  
  if($ls['inte_1']<=8){
    $ls['qs'] = inte_probe($ls['uid_1'],$ls['v_1']*$ls['sl'],$ls['inte_1']);
  }else{  //�������̽��
    $ls['qs'] = beyond_inte_probe($ls['uid_1'],$ls['v_1']*$ls['sl'],$ls['inte_1']);
  }
  
  if($ls['qs']>0){
    $ls['sl'] = $ls['sl'] - ceil($ls['qs']/$ls['v_1']);
    $qs_txt = "<br>".$title.co('main25',array('co1'=>$ls['sl']));
  }
  
  if(!$_TRC['more_e'] and $ls['sl']>1){
    prompt(co('i_if55'));
  }

  for($i=0;$i<$ls['sl'];$i++){
    db_op::integral_sale_sub($ls);
  }
  	
  prompt(co('i_if11').$_TRC['inte_name'].$_TRC['poundage'].$_TRC['inte_unit'].$qs_txt);
	
}
elseif($_GET['op']=="integral_buy"){
  
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  security::int_if($ls['bh'],co('i_if12'));
  $db_buy = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE id='".$ls['bh']."'");
  //state='1' ������ state='2' �ѹ��� ������ �޴˶���
  if(!$db_buy){
    showmessage(co('ofc'),'');
  }elseif($db_buy['state']==1){
    showmessage(co('alr').q_name($db_buy['uid_2']).co('buy'),'');
  }elseif($db_buy['state']==2){
    showmessage(co('oec'),'');
  }
  //���Ʊ���
  if($db_buy['inte_2']<=8){
    $inte_2_title = $_TRC['extc'][$db_buy['inte_2']]['title'];
    $inte_2_img = $_TRC['extc'][$db_buy['inte_2']]['img'];
    $inte_2_unit = $_TRC['extc'][$db_buy['inte_2']]['unit'];
  }else{
    $inte_2_title = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
    $inte_2_img = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
    $inte_2_unit = DB::result_first("SELECT int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
  } 
  if($db_buy['inte_1']<=8){
    $inte_1_title = $_TRC['extc'][$db_buy['inte_1']]['title'];
    $inte_1_img = $_TRC['extc'][$db_buy['inte_1']]['img'];
    $inte_1_unit = $_TRC['extc'][$db_buy['inte_1']]['unit'];
  }else{
    $inte_1_title = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
    $inte_1_img = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
    $inte_1_unit = DB::result_first("SELECT int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
  }
  
  //̽���ж������Ƿ��㹻
  if($db_buy['inte_2']<=8){
    $ls['qs'] = inte_probe($_G['uid'],$db_buy['v_2'],$db_buy['inte_2']);
  }else{  //�������̽��
    $ls['qs'] = beyond_inte_probe($_G['uid'],$db_buy['v_2'],$db_buy['inte_2']);
  }
  if($ls['qs']>0){
    showmessage(co('i_if13').$inte_2_title.co('i_if16').$ls['qs'].co('i_if17'),'');
  }
    
  include template('zgxsh_integral:integral/integral_buy');
	exit();
}
elseif($_GET['op']=="integral_buy_sub"){
  
  security::hash_if();
	$ls = security::filter($_GET);
  security::int_if($ls['bh'],co('i_if12'));
  $db_buy = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE id='".$ls['bh']."'");
  if(!$db_buy){
    showmessage(co('ofc'),'');
  }elseif($db_buy['state']==1){
    showmessage(co('alr').q_name($db_buy['uid_2']).co('buy'),'');
  }elseif($db_buy['state']==2){
    showmessage(co('oec'),'');
  }
  //�������ж�
  if($_TRC['prev_chea'] and $_G['adminid']!=1){  //�����˷����� ���ҹ����߲��ǳ�������
    $cs_ip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$db_buy['uid_1']."'");
		$gm_ip = DB::result_first("SELECT lastip FROM ".DB::table('common_member_status')." WHERE uid = '".$_G['uid']."'");
    if($cs_ip==$gm_ip){
      $paramete['icon']=2;  //��ʾͼ��
      prompt(co('i_if53'),"",$paramete);
    }
  }
  
  //���Ʊ���
  if($db_buy['inte_2']<=8){
    $inte_2_title = $_TRC['extc'][$db_buy['inte_2']]['title'];
    $inte_2_img = $_TRC['extc'][$db_buy['inte_2']]['img'];
    $inte_2_unit = $_TRC['extc'][$db_buy['inte_2']]['unit'];
  }else{
    $inte_2_title = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
    $inte_2_img = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
    $inte_2_unit = DB::result_first("SELECT int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
  } 
  if($db_buy['inte_1']<=8){
    $inte_1_title = $_TRC['extc'][$db_buy['inte_1']]['title'];
    $inte_1_img = $_TRC['extc'][$db_buy['inte_1']]['img'];
    $inte_1_unit = $_TRC['extc'][$db_buy['inte_1']]['unit'];
  }else{
    $inte_1_title = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
    $inte_1_img = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
    $inte_1_unit = DB::result_first("SELECT int_ico FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
  }
  //̽��
  if($db_buy['inte_2']<=8){
    $ls['qs'] = inte_probe($_G['uid'],$db_buy['v_2'],$db_buy['inte_2']);
  }else{  //�������̽��
    $ls['qs'] = beyond_inte_probe($_G['uid'],$db_buy['v_2'],$db_buy['inte_2']);
  }
  
  if($ls['qs']>0){
    showmessage(co('i_if13').$inte_2_title.co('i_if16').$ls['qs'].co('i_if17'),'');
  }
  $ls['uid'] = $_G['uid'];
  
  if(db_op::integral_buy_sub($ls)){
		prompt(co('i_if14').$_TRC['inte_name'].$_TRC['poundage'].$_TRC['inte_unit'],"location='plugin.php?id=zgxsh_integral:index'");
	}
}
elseif($_GET['op']=="integral_del"){  //����
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  security::int_if($ls['bh'],co('i_if12'));
  $ls['uid'] = $_G['uid'];
  
  if(db_op::integral_del_sub($ls)){
		prompt(co('i_if15').$_TRC['inte_name'].$_TRC['poundage'].$_TRC['inte_unit']);
	}
}
elseif($_GET['op']=="integral_adv"){  //���
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  
  if(!$_TRC['adv_e']){
    prompt(co('i_if60'));
  }
  
  adv_init();
  
  prompt(co('i_if59').$_TRC['inte_name'].$_TRC['poundage'].$_TRC['inte_unit']);
}

//��������
elseif($_GET['op']=="beyond_add"){
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  $see['form'] = layui::form_name();
  include template('zgxsh_integral:beyond/beyond_add');
	exit();
}
elseif($_GET['op']=="beyond_edit"){
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  $see['form'] = layui::form_name();
  
  $db_deyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE id='".$ls['bh']."'");
  
  include template('zgxsh_integral:beyond/beyond_edit');
	exit();
}
elseif($_GET['op']=="beyond_del"){
  security::hash_if(1);  //GET  �ύ
	$ls = security::filter($_GET);
  
  $db_deyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE id='".$ls['bh']."'");
  
  include template('zgxsh_integral:beyond/beyond_del');
	exit();
}
elseif($_GET['op']=="beyond_add_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  security::int_if($ls['inte_id'],co('i_if19'),0,0,0,0,9);
  security::txt_en($ls['t_name'],co('i_if20'),1);
  security::txt_en($ls['target_field'],co('i_if21'),1);
  security::txt_en($ls['query_field'],co('i_if22'),1);
  if($ls['model']==1){  //��ά��ѯ��֤����
    security::txt_en($ls['t_name_2'],co('i_if23'),1);
    security::txt_en($ls['query_field_2'],co('i_if24'),1);
  }
  security::txt_en($ls['int_name'],co('i_if25'),1);
  security::txt_en($ls['int_unit'],co('i_if26'),1);
  security::int_if($ls['v'],co('i_if27'),0,1);
  
  if(db_op::beyond_add_sub($ls)){
		prompt(co('i_if28'));
	}
}
elseif($_GET['op']=="beyond_edit_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  security::int_if($ls['inte_id'],co('i_if19'),0,0,0,0,9);
  security::txt_en($ls['t_name'],co('i_if20'),1);
  security::txt_en($ls['target_field'],co('i_if21'),1);
  security::txt_en($ls['query_field'],co('i_if22'),1);
  if($ls['model']==1){  //��ά��ѯ��֤����
    security::txt_en($ls['t_name_2'],co('i_if23'),1);
    security::txt_en($ls['query_field_2'],co('i_if24'),1);
  }
  security::txt_en($ls['int_name'],co('i_if25'),1);
  security::txt_en($ls['int_unit'],co('i_if26'),1);
  security::int_if($ls['v'],co('i_if27'),0,1);
  
  if(db_op::beyond_edit_sub($ls)){
		prompt(co('i_if32'));
	}else{
    prompt(co('i_if61'));
  }
}
elseif($_GET['op']=="beyond_del_sub"){
  security::hash_if();
	$ls = security::filter($_GET);
  
  $db_deyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE id='".$ls['bh']."'");
  $inte_1_o = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE inte_1='".$db_deyond['inte_id']."'");
  $inte_2_o = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE inte_2='".$db_deyond['inte_id']."'");
  
  //���۶��� inte_1
  for($i=0;$i<count($inte_1_o);$i++){
    beyond_inte($inte_1_o[$i]['uid_1'],$inte_1_o[$i]['v_1'],$db_deyond['inte_id']);
    notice($inte_1_o[$i]['uid_1'],co('i_if34',array('co1'=>$_TRC['p_name'])),co('i_if35')." [".$inte_1_o[$i]['id']."] ".co('i_if36'));
    $up = array(
      'time_2' => time(),
      'state' => 2,
    );
		$r = DB::update('zgxsh_integral_sale',$up,array('id'=>$inte_1_o[$i]['id']));
  }
  //�չ����� inte_2
  for($i=0;$i<count($inte_2_o);$i++){
    if($inte_2_o[$i]['inte_1']>8){
      beyond_inte($inte_2_o[$i]['uid_1'],$inte_2_o[$i]['v_1'],$inte_2_o[$i]['inte_1']);
    }else{
      integral($inte_2_o[$i]['uid_1'],$inte_2_o[$i]['v_1'],$inte_2_o[$i]['inte_1'],$_TRC['p_name'],co('i_if38')." ".$db_deyond['int_name']." ".co('i_if39'));
      notice($inte_2_o[$i]['uid_1'],co('i_if34',array('co1'=>$_TRC['p_name'])),co('i_if35')." [".$inte_2_o[$i]['id']."] ".co('i_if36'));
    }
    $up = array(
      'time_2' => time(),
      'state' => 2,
    );
		$r = DB::update('zgxsh_integral_sale',$up,array('id'=>$inte_2_o[$i]['id']));
  }
  //ɾ���������
  DB::delete('zgxsh_integral_beyond_space',array('id'=>$ls['bh']));
  
  prompt(co('i_if33'));
}

//��������ͨ�� 
elseif($_GET['op']=="inte_setup"){
  if(!$_TRC['inte_setup']){  //�ж���չ�Ƿ�װ
    $paramete['icon']=2;  //��ʾͼ��
    $setup_url = '<a style="color:#229" target="_blank" href="https://dism.taobao.com/?@zgxsh_integral.plugin">'.co('i_if51').'</a>';
    prompt(co('i_if52').'<br>'.$setup_url,"location='plugin.php?id=zgxsh_integral:index'",$paramete);
  }
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_integral:index'");
  }
  
  //ͨ����֤
  header("Location:plugin.php?id=zgxsh_integral:inte_setup");
  exit();
}

elseif($_GET['op']=="see_news"){
  
  $news = news::see(" LIMIT 1000");
  
  include template('zgxsh_integral:index/see_news');
  exit();  
}

system_end()
?>