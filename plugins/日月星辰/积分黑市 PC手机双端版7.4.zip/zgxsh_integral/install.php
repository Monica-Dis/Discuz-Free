<?php
/**
 *	[�̿��ֵܻ�(zgxsh_integral.install)] (C)2019-2099 Powered by �����ǳ�����.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_integral_rf`;
CREATE TABLE `cdb_zgxsh_integral_rf` (
  `id` int(10) NOT NULL auto_increment,
  `time` int(20) default NULL,
  `e1_v` int(10) default NULL,
  `e2_v` int(10) default NULL,
  `e3_v` int(10) default NULL,
  `e4_v` int(10) default NULL,
  `e5_v` int(10) default NULL,
  `e6_v` int(10) default NULL,
  `e7_v` int(10) default NULL,
  `e8_v` int(10) default NULL,
  PRIMARY KEY  (`id`),
  KEY `id` USING BTREE (`id`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=59;
DROP TABLE IF EXISTS `cdb_zgxsh_integral_sale`;
CREATE TABLE `cdb_zgxsh_integral_sale` (
  `id` int(10) NOT NULL auto_increment,
  `uid_1` int(10) NOT NULL,
  `inte_1` int(1) NOT NULL,
  `v_1` int(10) NOT NULL,
  `uid_2` int(10) default NULL,
  `inte_2` int(1) NOT NULL,
  `v_2` int(10) NOT NULL,
  `time_1` int(20) NOT NULL,
  `time_2` int(20) default '0',
  `state` int(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `id` USING BTREE (`id`,`state`),
  KEY `inte_1` USING BTREE (`inte_1`,`state`),
  KEY `inte_2` USING BTREE (`inte_2`,`state`)
) ENGINE=MyISAM AUTO_INCREMENT=7;
DROP TABLE IF EXISTS `cdb_zgxsh_integral_system`;
CREATE TABLE `cdb_zgxsh_integral_system` (
  `integral_switch_1` int(1) NOT NULL default '0',
  `integral_switch_2` int(1) NOT NULL default '0',
  `integral_switch_3` int(1) NOT NULL default '0',
  `integral_switch_4` int(1) NOT NULL default '0',
  `integral_switch_5` int(1) NOT NULL default '0',
  `integral_switch_6` int(1) NOT NULL default '0',
  `integral_switch_7` int(1) NOT NULL default '0',
  `integral_switch_8` int(1) NOT NULL default '0',
  `exchange_1` int(10) NOT NULL default '0',
  `exchange_2` int(10) NOT NULL default '0',
  `exchange_3` int(10) NOT NULL default '0',
  `exchange_4` int(10) NOT NULL default '0',
  `exchange_5` int(10) NOT NULL default '0',
  `exchange_6` int(10) NOT NULL default '0',
  `exchange_7` int(10) NOT NULL default '0',
  `exchange_8` int(10) NOT NULL default '0',
  `integral_limit` varchar(2000) NOT NULL,
  `conv_min_eid` int(10) NOT NULL default '0',
  `conv_max_eid` int(10) NOT NULL default '0',
  `conv_min_v` int(10) NOT NULL default '0',
  `conv_max_v` int(10) NOT NULL default '0'
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_integral_beyond_space`;
CREATE TABLE `cdb_zgxsh_integral_beyond_space` (
  `id` int(10) NOT NULL auto_increment,
  `inte_id` int(10) NOT NULL,
  `t_name` varchar(80) NOT NULL,
  `target_field` varchar(80) NOT NULL,
  `query_field` varchar(80) NOT NULL,
  `model` int(1) NOT NULL,
  `t_name_2` varchar(80) NOT NULL,
  `query_field_2` varchar(80) NOT NULL,
  `int_name` varchar(80) NOT NULL,
  `int_unit` varchar(80) NOT NULL,
  `int_ico` varchar(180) NOT NULL,
  `trading` int(1) NOT NULL default '0',
  `v` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id` USING BTREE (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_integral_user`;
CREATE TABLE `cdb_zgxsh_integral_user` (
  `uid` int(10) NOT NULL,
  `inte` int(10) NOT NULL default '0',
  PRIMARY KEY  (`uid`),
  KEY `uid` USING BTREE (`uid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_integral_news`;
CREATE TABLE `cdb_zgxsh_integral_news` (
  `id` int(10) NOT NULL auto_increment,
  `type` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
INSERT INTO `cdb_zgxsh_integral_system` VALUES ('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' , '','0','0','0','0');
EOF;

runquery($sql);
$finish = true;
?>