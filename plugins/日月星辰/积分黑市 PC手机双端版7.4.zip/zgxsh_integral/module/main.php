<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

//----ϵͳ��������----
$system = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_system'));
$system['integral_limit'] = unserialize($system['integral_limit']);  //��������

$_TRC = $_G['cache']['plugin']['zgxsh_integral'];

$_TRC["in_tax_name"] = $_G['setting']['extcredits'][$_TRC['in_tax']]['title'];
$_TRC["in_tax_logo"] = $_G['setting']['extcredits'][$_TRC['in_tax']]['img'];
$_TRC["in_tax_value"] = getuserprofile('extcredits'.$_TRC['in_tax']);

$_TRC['extc'] = $_G['setting']['extcredits'];  //��ȡ�����Ļ�������
foreach($_TRC['extc'] as $k=>$v){
  $_TRC['extc'][$k]['id'] = $k;  //���
  $_TRC['extc'][$k]['k'] = "n_".$k;  //html��name���Ա���������ĸ
  $_TRC['extc'][$k]['value'] = getuserprofile('extcredits'.$k);
  $_TRC['extc'][$k]['all'] = DB::result_first("SELECT sum(extcredits".$k.") FROM ".DB::table('common_member_count'));
  $_TRC['extc'][$k]['portion'] = round($_TRC['extc'][$k]['value']/$_TRC['extc'][$k]['all']*100)."%";  //�Ƹ�ռ��
  if(!$system['integral_switch_'.$k]){
    $_TRC['extc'][$k]['on_class'] = "extc-no";
  }
  //��ȡ���ֶ�����
  $_TRC['extc'][$k]['order'] = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_integral_sale')." WHERE inte_1='".$k."' AND  state='0'");  
}

//ҳ������
$navtitle = $_TRC['p_name'];

//if(!$_TRC['in_tax']){
//	showmessage('��ǰ����û���趨ͨ����������ϵվ��!','');
//}

//print_r($system);


//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';

//----��չ�б�----
include 'class/inte_setup.php';
include 'class/more.php';
include 'class/adv.php';
include 'class/guan.php';

//----�������----
function coin_op($uid,$v){  //ͨ������
  global $_G;
  global $_TRC;
  $db_ext = DB::result_first("SELECT inte FROM ".DB::table('zgxsh_integral_user')." WHERE uid = '".$uid."'"); 
	if(!$db_ext){
    $db_ext = 0;  
  }
  if($db_ext+$v<0 and $v<0){
    $supurl = '<button class="layui-btn layui-btn-fluid layui-btn-xs layui-btn-primary" onClick="'."showWindow('TC','plugin.php?id=zgxsh_integral:index_if&op=exchange','get',0,{'cover':'1'});".'">'.co('main12').$_TRC['inte_name'].'</button>';
    prompt(co('main01').$_TRC['inte_name'].co('main02').abs($v).$_TRC['inte_unit'].co('main03').$db_ext.$_TRC['inte_unit']."<br>".$supurl);
  }
  $db_ext += $v;  //��������
  $up = array(
    'inte' => $db_ext
  );
  //system_end($uid);
  $r = DB::update('zgxsh_integral_user',$up,array('uid'=>$uid));
  return $r;
}
function beyond_inte($uid,$v,$k){  //������ֲ���
  $beyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$k."'");

  if($beyond['model']==0){  //ֱ�Ӳ�ѯ
    $beyond['inte_v'] = DB::result_first("SELECT ".$beyond['target_field']." FROM ".$beyond['t_name']." WHERE ".$beyond['query_field']."='".$uid."'");
  }else{  //��ά��ѯ
    $beyond['inte_query'] = DB::result_first("SELECT ".$beyond['query_field']." FROM ".$beyond['t_name_2']." WHERE ".$beyond['query_field_2']."='".$uid."'");
    $beyond['inte_v'] = DB::result_first("SELECT ".$beyond['target_field']." FROM ".$beyond['t_name']." WHERE ".$beyond['query_field']."='".$beyond['inte_query']."'");
  }
  
  if(!$beyond['inte_v']){  //û��ȡ������0
    $beyond['inte_v'] = 0;
  }

  if($beyond['inte_v']+$v<0 and $v<0){  //���ֲ���
    prompt($beyond['int_name'].co('sys_integral1').abs($v).$beyond['int_name'].co('sys_integral2').$beyond['inte_v'].$beyond['int_name'].co('sys_integral3').(abs($v)-$beyond['inte_v']).$beyond['int_name']);
  }
  
  $beyond['inte_v'] += $v;  //������������
  //���
  $up = array(
    $beyond['target_field'] => $beyond['inte_v']
  );

  $beyond['t_name'] = str_replace(DB::table(''),'',$beyond['t_name']);  //ȥ����ǰ׺��Ϊ�ո�
  
  if($beyond['model']==0){  //ֱ�Ӳ�ѯ���
    //prompt($beyond['query_field']);
    $r = DB::update($beyond['t_name'],$up,array($beyond['query_field']=>$uid)); 
  }else{  //��ά��ѯ���
    $r = DB::update($beyond['t_name'],$up,array($beyond['query_field']=>$beyond['inte_query'])); 
  }
  
  return $r;
}
function beyond_inte_probe($uid,$v,$k){  //�������̽��

  $beyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$k."'");
  
  if($beyond['model']==0){  //ֱ�Ӳ�ѯ
    $beyond['inte_v'] = DB::result_first("SELECT ".$beyond['target_field']." FROM ".$beyond['t_name']." WHERE ".$beyond['query_field']."='".$uid."'");
  }else{  //��ά��ѯ
    $beyond['inte_query'] = DB::result_first("SELECT ".$beyond['query_field']." FROM ".$beyond['t_name_2']." WHERE ".$beyond['query_field_2']."='".$uid."'");
    $beyond['inte_v'] = DB::result_first("SELECT ".$beyond['target_field']." FROM ".$beyond['t_name']." WHERE ".$beyond['query_field']."='".$beyond['inte_query']."'");
  }
  
  if(!$beyond['inte_v']){  //û��ȡ������0
    $beyond['inte_v'] = 0;
  }

  if($beyond['inte_v']-$v<0){
    $r = $v - $beyond['inte_v'];
    return $r;
  }
  return 0;
}


//----���ݿ������----
class db_op {
  //�������Ʒ���
  function detection_writing($format="d"){
    //��ȡ���һ��
    $rf_today = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_rf')." ORDER BY id DESC LIMIT 1");
    $rf_today['date'] = dgmdate($rf_today['time'],$format);  //���һ��ʱ��
    $date = dgmdate(time(),$format);  //��ǰʱ��
    if($rf_today['date']<>$date){
      $extc_all = DB::fetch_first("SELECT sum(extcredits1),sum(extcredits2),sum(extcredits3),sum(extcredits4),sum(extcredits5),sum(extcredits6),sum(extcredits7),sum(extcredits8) FROM ".DB::table('common_member_count'));
      $int = array(
        'time' => time()
        ,'e1_v' => $extc_all['sum(extcredits1)']
        ,'e2_v' => $extc_all['sum(extcredits2)']
        ,'e3_v' => $extc_all['sum(extcredits3)']
        ,'e4_v' => $extc_all['sum(extcredits4)']
        ,'e5_v' => $extc_all['sum(extcredits5)']
        ,'e6_v' => $extc_all['sum(extcredits6)']
        ,'e7_v' => $extc_all['sum(extcredits7)']
        ,'e8_v' => $extc_all['sum(extcredits8)']
      );
      DB::insert('zgxsh_integral_rf',$int);
    }
  }
	
	//��� ��ֵ intval() ���� daddslashes()
  //�������� 
	function setup_trading($ls){
		global $_G;
    if($ls['like']['e_1']){$up['integral_switch_1'] = 1;}else{$up['integral_switch_1'] = 0;}
    if($ls['like']['e_2']){$up['integral_switch_2'] = 1;}else{$up['integral_switch_2'] = 0;}
    if($ls['like']['e_3']){$up['integral_switch_3'] = 1;}else{$up['integral_switch_3'] = 0;}
    if($ls['like']['e_4']){$up['integral_switch_4'] = 1;}else{$up['integral_switch_4'] = 0;}
    if($ls['like']['e_5']){$up['integral_switch_5'] = 1;}else{$up['integral_switch_5'] = 0;}
    if($ls['like']['e_6']){$up['integral_switch_6'] = 1;}else{$up['integral_switch_6'] = 0;}
    if($ls['like']['e_7']){$up['integral_switch_7'] = 1;}else{$up['integral_switch_7'] = 0;}
    if($ls['like']['e_8']){$up['integral_switch_8'] = 1;}else{$up['integral_switch_8'] = 0;}
		$r = DB::update('zgxsh_integral_system',$up,'');
		return $r;
  }
	//�һ�����
	function setup_exchange($ls){
		global $_G;
    if($ls['exchange_1']){$up['exchange_1'] = $ls['exchange_1'];}else{$up['exchange_1'] = 0;}
    if($ls['exchange_2']){$up['exchange_2'] = $ls['exchange_2'];}else{$up['exchange_2'] = 0;}
    if($ls['exchange_3']){$up['exchange_3'] = $ls['exchange_3'];}else{$up['exchange_3'] = 0;}
    if($ls['exchange_4']){$up['exchange_4'] = $ls['exchange_4'];}else{$up['exchange_4'] = 0;}
    if($ls['exchange_5']){$up['exchange_5'] = $ls['exchange_5'];}else{$up['exchange_5'] = 0;}
    if($ls['exchange_6']){$up['exchange_6'] = $ls['exchange_6'];}else{$up['exchange_6'] = 0;}
    if($ls['exchange_7']){$up['exchange_7'] = $ls['exchange_7'];}else{$up['exchange_7'] = 0;}
    if($ls['exchange_8']){$up['exchange_8'] = $ls['exchange_8'];}else{$up['exchange_8'] = 0;}
		$r = DB::update('zgxsh_integral_system',$up,'');
		return $r;
  }
  //���ֶ����޶�
  function setup_limit($ls){
    global $_G;
    global $_TRC;
    foreach($_TRC['extc'] as $k=>$v){
      $upser['min_'.$k] = $ls['min_'.$k]<=0?0:$ls['min_'.$k];
      $upser['max_'.$k] = $ls['max_'.$k]<=0?0:$ls['max_'.$k];
    }
    $up['integral_limit'] = serialize($upser);
    $r = DB::update('zgxsh_integral_system',$up,'');
  }
  //����ת��
  
  function setup_conv($ls){
		
    $up = array(
    'conv_min_eid' => intval($ls['conv_min_eid']),	 //����ת��_�ͽ׻���
    'conv_max_eid' => intval($ls['conv_max_eid']),	 //����ת��_�߽׻���
    'conv_min_v' => intval($ls['conv_min_v']),	 //����ת��_�ͽ׼�ֵ
    'conv_max_v' => intval($ls['conv_max_v']),	 //����ת��_�߽׼�ֵ
    );
    
		$r = DB::update('zgxsh_integral_system',$up,'');
		return $r;
  }  
  //�һ�ͨ��
  function exchange_sub($ls){
		global $_G;
    global $system;
    global $_TRC;
    //���ٻ���
    for($i=1;$i<=8;$i++){
      if($ls["n_".$i]>0){  //���۸÷������
        integral($_G['uid'],-$ls["n_".$i],$i,$_TRC['p_name'],co('main04',array("co1"=>$_TRC['p_name'])));  //���ֲ���
        $coinadd += $ls["n_".$i]*$system['exchange_'.$i];
      }
    }
    $beyond_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE v>0");
    for($i=0;$i<count($beyond_all);$i++){
      if($beyond_all[$i]['model']==0){  //ֱ�Ӳ�ѯ
        $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$_G['uid']."'");
      }else{  //��ά��ѯ
        $beyond_all[$i]['inte_query'] = DB::result_first("SELECT ".$beyond_all[$i]['query_field']." FROM ".$beyond_all[$i]['t_name_2']." WHERE ".$beyond_all[$i]['query_field_2']."='".$_G['uid']."'");
        $beyond_all[$i]['inte_v'] = DB::result_first("SELECT ".$beyond_all[$i]['target_field']." FROM ".$beyond_all[$i]['t_name']." WHERE ".$beyond_all[$i]['query_field']."='".$beyond_all[$i]['inte_query']."'");
      }
      $beyond_all[$i]['k'] = "n_".$beyond_all[$i]['inte_id'];
      if($ls[$beyond_all[$i]['k']]>0){  //��������ύ����
        beyond_inte($_G['uid'],-$ls[$beyond_all[$i]['k']],$beyond_all[$i]['inte_id']);  //������ֲ���
        $coinadd += $ls[$beyond_all[$i]['k']]*$beyond_all[$i]['v'];
      }
    }
    
    //����ī��
    $r = coin_op($_G['uid'],$coinadd);
    
    news::add(4,q_name($_G['uid']).co('news01').$coinadd.$_TRC['inte_name'].co('news02'));
    
		return $r;
  }
	
  //����
	function integral_sale_sub($ls){
		global $_G;
		global $_TRC;
    
    coin_op($ls['uid_1'],-$_TRC['poundage']);
    if($ls['inte_1']<=8){
      $ls['qs'] = inte_probe($ls['uid_1'],$ls['v_1'],$ls['inte_1']);
    }else{  //�������̽��
      $ls['qs'] = beyond_inte_probe($ls['uid_1'],$ls['v_1'],$ls['inte_1']);
    }
        
    if($ls['qs']>0){
      coin_op($ls['uid_1'],$_TRC['poundage']);
      if($ls['inte_1']<=8){
        $title = $_G['setting']['extcredits'][$ls['inte_1']]['title'];
      }else{  //������ֲ���
        $title = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='{$ls['inte_1']}'");
      }
      prompt($title.co('main05'));
    }
     
    if($ls['inte_1']<=8){
      integral($ls['uid_1'],-$ls['v_1'],$ls['inte_1'],$_TRC['p_name'],co('main06'));
      $inte_name1 = $_G['setting']['extcredits'][$ls['inte_1']]['title'];
    }else{  //������ֲ���
      beyond_inte($ls['uid_1'],-$ls['v_1'],$ls['inte_1']);  //������ֲ���  
      $inte_name1 = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='{$ls['inte_1']}'");
    }
    
    if($ls['inte_2']<=8){
      $inte_name2 = $_G['setting']['extcredits'][$ls['inte_2']]['title'];
    }else{
      $inte_name2 = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$ls['inte_2']."'");
    }
		$ins = array(
      'uid_1' => intval($ls['uid_1']),
      'inte_1' => intval($ls['inte_1']),
      'v_1' => intval($ls['v_1']),
      'inte_2' => intval($ls['inte_2']),
      'v_2' => intval($ls['v_2']),
      'time_1' => time()
    );
    
		$r = DB::insert('zgxsh_integral_sale',$ins);
    
    news::add(2,q_name($ls['uid_1']).co('news03').$ls['v_1'].$inte_name1.co('news04').":".$ls['v_2'].$inte_name2);
    
		return $r;
  }
	
	function integral_buy_sub($ls){
		global $_G;
		global $_TRC;
     
    $db_buy = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE id='".$ls['bh']."'");
    
    coin_op($ls['uid'],-$_TRC['poundage']);  //������
    if($db_buy['inte_2']<=8){
      $ls['qs'] = inte_probe($ls['uid'],$db_buy['v_2'],$db_buy['inte_2']);
    }else{  //�������̽��
      $ls['qs'] = beyond_inte_probe($ls['uid'],$db_buy['v_2'],$db_buy['inte_2']);
    }
    if($ls['qs']>0){
      coin_op($ls['uid'],$_TRC['poundage']);
      $title = $_TRC['extc'][$db_buy['inte_2']]['title'];
      prompt($title.co('main07'));
    }
    if($db_buy['inte_2']<=8){
      integral($ls['uid'],-$db_buy['v_2'],$db_buy['inte_2'],$_TRC['p_name'],co('main08'));
      integral($db_buy['uid_1'],$db_buy['v_2'],$db_buy['inte_2'],$_TRC['p_name'],co('main09'));
      $inte_name2 = $_G['setting']['extcredits'][$db_buy['inte_2']]['title'];
      $inte_unit2 = $_G['setting']['extcredits'][$db_buy['inte_2']]['unit'];
    }else{  //������ֲ���
      beyond_inte($ls['uid'],-$db_buy['v_2'],$db_buy['inte_2']);  
      beyond_inte($db_buy['uid_1'],$db_buy['v_2'],$db_buy['inte_2']);  
      $inte_name2 = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
      $inte_unit2 = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_2']."'");
    }
    if($db_buy['inte_1']<=8){
      integral($ls['uid'],$db_buy['v_1'],$db_buy['inte_1'],$_TRC['p_name'],co('main10'));
      $inte_name1 = $_G['setting']['extcredits'][$db_buy['inte_1']]['title'];
      $inte_unit1 = $_G['setting']['extcredits'][$db_buy['inte_1']]['unit'];
    }else{  //������ֲ���
      beyond_inte($ls['uid'],$db_buy['v_1'],$db_buy['inte_1']);  //������ֲ���
      $inte_name1 = DB::result_first("SELECT int_name FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
      $inte_unit1 = DB::result_first("SELECT int_unit FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$db_buy['inte_1']."'");
    }
    
    
    //������ʾ���͸�����
    $inte1name = $inte_name1;
    $inte2name = $inte_name2;
    $inte1unit = $inte_unit1;
    $inte2unit = $inte_unit2;
    
    $text_no = co('main13').$db_buy['v_1'].$inte1unit.$inte1name;
    $text_no .= co('main14').q_name($ls['uid']);
    $text_no .= co('main15').$db_buy['v_2'].$inte2unit.$inte2name;
    notice($db_buy['uid_1'],$_TRC['p_name'],$text_no);
    
    $up = array(
      'time_2' => time(),
      'uid_2' => $ls['uid'],
      'state' => 1,
    );
		$r = DB::update('zgxsh_integral_sale',$up,array('id'=>$ls['bh']));
    
    news::add(3,q_name($ls['uid']).co('news05').$db_buy['v_1'].$inte_unit1.$inte_name1.co('news06').":".$db_buy['v_2'].$inte_unit2.$inte_name2);
    
		return $r;
  }
	
	function integral_del_sub($ls){  //����
		global $_G;
		global $_TRC;
    
    $db_del = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_sale')." WHERE id='".$ls['bh']."'");
    if(!$db_del){
      prompt(co('ofc'),'');
    }elseif($db_del['state']==1){
      prompt(co('alr').q_name($db_del['uid_2']).co('buy'),'');
    }elseif($db_del['state']==2){
      prompt(co('oec'),'');
    }
        
    if($db_del['inte_1']<=8){
      integral($db_del['uid_1'],$db_del['v_1'],$db_del['inte_1'],$_TRC['p_name'],co('main10'));
    }else{  //������ֲ���
      beyond_inte($db_del['uid_1'],$db_del['v_1'],$db_del['inte_1']);  //������ֲ���
    }
    
    notice($db_del['uid_1'],$_TRC['p_name'],co('main18',array('co1'=>$ls['bh'])));
    
		$up = array(
      'time_2' => time(),
      'state' => 2,
    );
		$r = DB::update('zgxsh_integral_sale',$up,array('id'=>$ls['bh']));
    
    news::add(5,q_name($db_del['uid_1']).co('news07').$ls['bh'].co('news08'));
    
		return $r;
	}
  
  //�������������
  function beyond_add_sub($ls){
    $beyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$ls['inte_id']."'");
    if($beyond){
      prompt(co('main16'));
    }
    
    $ins = array(
      'inte_id' => intval($ls['inte_id']),  //��������
      't_name' => daddslashes($ls['t_name']),  //���ڱ���
      'target_field' => daddslashes($ls['target_field']),  //�����ֶ�
      'query_field' => daddslashes($ls['query_field']),  //��ѯ�ֶ�
      'model' => intval($ls['model']),  //��ѯģʽ
      't_name_2' => daddslashes($ls['t_name_2']),  //�����ѯ��
      'query_field_2' => daddslashes($ls['query_field_2']),  //�����ֶ���
      'int_name' => daddslashes($ls['int_name']),  //��������
      'int_unit' => daddslashes($ls['int_unit']),  //���ֵ�λ
      'int_ico' => daddslashes($ls['int_ico']),  //����ͼ��
      'trading' => intval($ls['trading']),  //�Ƿ���뽻��
      'v' => intval($ls['v']),  //����ī�Ҽ�ֵ
    );
        
		$r = DB::insert('zgxsh_integral_beyond_space',$ins);
    
    return $r;
  }
  function beyond_edit_sub($ls){
    $beyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE id='".$ls['bh']."'");
    if(!$beyond){
      prompt(co('main17'));
    }
    $beyond = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_integral_beyond_space')." WHERE inte_id='".$ls['inte_id']."' AND id!='".$ls['bh']."'");
    if($beyond){
      prompt(co('main16'));
    }
    
    $ins = array(
      'inte_id' => intval($ls['inte_id']),  //��������
      't_name' => daddslashes($ls['t_name']),  //���ڱ���
      'target_field' => daddslashes($ls['target_field']),  //�����ֶ�
      'query_field' => daddslashes($ls['query_field']),  //��ѯ�ֶ�
      'model' => intval($ls['model']),  //��ѯģʽ
      't_name_2' => daddslashes($ls['t_name_2']),  //�����ѯ��
      'query_field_2' => daddslashes($ls['query_field_2']),  //�����ֶ���
      'int_name' => daddslashes($ls['int_name']),  //��������
      'int_unit' => daddslashes($ls['int_unit']),  //���ֵ�λ
      'int_ico' => daddslashes($ls['int_ico']),  //����ͼ��
      'trading' => intval($ls['trading']),  //�Ƿ���뽻��
      'v' => intval($ls['v']),  //����ī�Ҽ�ֵ
    );
        
		$r = DB::update('zgxsh_integral_beyond_space',$ins,array('id'=>$ls['bh']));
    return $r;
  }
}
//������ news::see()
class news{
  function add($type,$txt){
    $ins = array(
      'type' => $type,
      'txt' => $txt,
      'time' => time(),
    );
    DB::insert('zgxsh_integral_news',$ins);
    return true;
  }
  function see($s=" LIMIT 8"){
    $db = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_integral_news')." ORDER BY id DESC{$s}");

    for($i=0;$i<count($db);$i++){
      $db[$i]['date'] = dgmdate($db[$i]['time']);
      if($db[$i]['type']==1){
        $db[$i]['type_name'] = co('main19');
        $db[$i]['color'] = "color:#2626ff";
      }elseif($db[$i]['type']==2){
        $db[$i]['type_name'] = co('main20');
        $db[$i]['color'] = "color:#c926ff";
      }elseif($db[$i]['type']==3){
        $db[$i]['type_name'] = co('main21');
        $db[$i]['color'] = "color:#ff6600";
      }elseif($db[$i]['type']==4){
        $db[$i]['type_name'] = co('main22');
        $db[$i]['color'] = "color:#008c46";
      }elseif($db[$i]['type']==5){
        $db[$i]['type_name'] = co('main23');
        $db[$i]['color'] = "color:#bbbbbb";
      }
    }
    
    if(count($db)<=0){
      $db[0]['type_name'] = co('main24');
      $db[0]['date'] = " -- ";
      $db[0]['txt'] = " -- ";
    }
    
    return $db;
  }
}
//From: Dism��taobao��com
?>