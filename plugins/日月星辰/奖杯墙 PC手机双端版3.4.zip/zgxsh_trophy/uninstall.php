<?php
/**
 *	[����ǽ(zgxsh_trophy.uninstall)] Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS cdb_zgxsh_trophy_user;
DROP TABLE IF EXISTS cdb_zgxsh_trophy_list;
DROP TABLE IF EXISTS cdb_zgxsh_trophy_varieties;
EOF;

runquery($sql);
$finish = true;
?>