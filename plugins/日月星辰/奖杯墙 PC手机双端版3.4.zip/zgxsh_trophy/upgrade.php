<?php
/**
 *	[����ǽ(zgxsh_trophy.upgrade)] Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_trophy_varieties')." LIKE 'zq_time'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_trophy_varieties')." ADD zq_time int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_trophy_varieties')." LIKE 'zq_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_trophy_varieties')." ADD zq_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_trophy_list')." LIKE 'sf_time'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_trophy_list')." ADD sf_time int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_trophy_list')." LIKE 'fee_time'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_trophy_list')." ADD fee_time int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_trophy_list')." LIKE 'sf_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_trophy_list')." ADD sf_v int(20) default NULL");
}

runquery($sql);

$finish = true;
?>