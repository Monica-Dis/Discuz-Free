<?php
/**
 *	[����ǽ(zgxsh_trophy.install)] Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_trophy_list`;
CREATE TABLE `cdb_zgxsh_trophy_list` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `t_name` varchar(20) NOT NULL,
  `t_txt` varchar(255) NOT NULL,
  `t_img` varchar(255) NOT NULL,
  `time` int(20) NOT NULL,
  `sf_time` int(20) default NULL,
  `sf_v` int(20) default NULL,
  `fee_time` int(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_trophy_user`;
CREATE TABLE `cdb_zgxsh_trophy_user` (
  `uid` int(20) NOT NULL,
  `trophy1` int(10) NOT NULL default '0',
  `trophy2` int(10) NOT NULL default '0',
  `trophy3` int(10) NOT NULL default '0',
  `trophy4` int(10) NOT NULL default '0',
  `trophy5` int(10) NOT NULL default '0',
  `trophy6` int(10) NOT NULL default '0',
  `trophy7` int(10) NOT NULL default '0',
  `trophy8` int(10) NOT NULL default '0',
  `trophy9` int(10) NOT NULL default '0',
  `trophy10` int(10) NOT NULL default '0',
  `trophy11` int(10) NOT NULL default '0',
  `trophy12` int(10) NOT NULL default '0',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_trophy_varieties`;
CREATE TABLE `cdb_zgxsh_trophy_varieties` (
  `id` int(10) NOT NULL auto_increment,
  `t_name` varchar(20) NOT NULL,
  `t_txt` varchar(255) NOT NULL,
  `t_img` varchar(255) NOT NULL,
  `zq_time` int(20) default NULL,
  `zq_v` int(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13;
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('1', '$installlang[main01]', '$installlang[main02]', 'source/plugin/zgxsh_trophy/template/img/index/1.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('2', '$installlang[main05]', '$installlang[main06]', 'source/plugin/zgxsh_trophy/template/img/index/3.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('3', '$installlang[main07]', '$installlang[main08]', 'source/plugin/zgxsh_trophy/template/img/index/4.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('4', '$installlang[main09]', '$installlang[main10]', 'source/plugin/zgxsh_trophy/template/img/index/5.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('5', '$installlang[main11]', '$installlang[main12]', 'source/plugin/zgxsh_trophy/template/img/index/6.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('6', '$installlang[main13]', '$installlang[main14]', 'source/plugin/zgxsh_trophy/template/img/index/7.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('7', '$installlang[main15]', '$installlang[main16]', 'source/plugin/zgxsh_trophy/template/img/index/8.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('8', '$installlang[main17]', '$installlang[main18]', 'source/plugin/zgxsh_trophy/template/img/index/9.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('9', '$installlang[main19]', '$installlang[main20]', 'source/plugin/zgxsh_trophy/template/img/index/10.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('10', '$installlang[main21]', '$installlang[main22]', 'source/plugin/zgxsh_trophy/template/img/index/11.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('11', '$installlang[main23]', '$installlang[main24]', 'source/plugin/zgxsh_trophy/template/img/index/12.png','','');
INSERT INTO `cdb_zgxsh_trophy_varieties` VALUES ('12', '$installlang[main03]', '$installlang[main04]', 'source/plugin/zgxsh_trophy/template/img/index/2.png','','');
EOF;

runquery($sql);
$finish = true;
?>