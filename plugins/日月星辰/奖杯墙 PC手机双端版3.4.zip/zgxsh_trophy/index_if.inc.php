<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

if($_GET['op']=="trophy_awarded"){  //��������
	//��Ա�˵�
	$username_all = DB::fetch_all("SELECT uid,username FROM ".DB::table('common_member'));
	for($i=0;$i<count($username_all);$i++){
		$user_opt .= '<option value="'.$username_all[$i]['uid'].'">'.$username_all[$i]['username'].' (UID:'.$username_all[$i]['uid'].')</option>';
	}
	//�����˵�
	$trophy_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_trophy_varieties'));
	for($i=0;$i<count($trophy_all);$i++){
		$trop_opt .= '<option value="'.$trophy_all[$i]['id'].'">'.$trophy_all[$i]['t_name'].'</option>';
	}
	include template('zgxsh_trophy:trophy/trophy_awarded');
  exit();
}
elseif($_GET['op']=="trophy_awarded_sub"){  //���������ύ
	security::hash_if();  //formhash
	$ls = security::filter($_GET);
  security::int_if($ls['uid'],co('inif01'));
  security::int_if($ls['trophy'],co('inif02'));

  if(db_op::trophy_awarded($ls)){
		prompt(co('inif04'),"location='plugin.php?id=zgxsh_trophy:setup'");
	}else{
		prompt(co('inif05'),"location='plugin.php?id=zgxsh_trophy:setup'");
	}
}
if($_GET['op']=="trophy_awarded_all"){  //��������
	//�����˵�
	$trophy_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_trophy_varieties'));
	for($i=0;$i<count($trophy_all);$i++){
		$trop_opt .= '<option value="'.$trophy_all[$i]['id'].'">'.$trophy_all[$i]['t_name'].'</option>';
	}
	include template('zgxsh_trophy:trophy/trophy_awarded_all');
  exit();
}
elseif($_GET['op']=="trophy_awarded_all_sub"){  //���������ύ
	security::hash_if();  //formhash
	$ls = security::filter($_GET);
  security::int_if($ls['trophy'],co('inif02'));

  if(db_op::trophy_awarded_all($ls)){
		prompt(co('inif04'),"location='plugin.php?id=zgxsh_trophy:setup'");
	}else{
		prompt(co('inif05'),"location='plugin.php?id=zgxsh_trophy:setup'");
	}
}


elseif($_GET['op']=="trophy_recycling"){  //����_ѡ��
	
	//��Ա�˵�
	$username_all = DB::fetch_all("SELECT uid,username FROM ".DB::table('common_member'));
	for($i=0;$i<count($username_all);$i++){
		$user_opt .= '<option value="'.$username_all[$i]['uid'].'">'.$username_all[$i]['username'].' (UID:'.$username_all[$i]['uid'].')</option>';
	}
	
	include template('zgxsh_trophy:trophy/trophy_recycling');
  exit();
}
elseif($_GET['op']=="trophy_recycling_choose"){  //����_ѡ����
	security::hash_if();  //formhash
	$ls = security::filter($_GET);
  security::int_if($ls['uid'],co('inif01'));
	$see['form'] = layui::form_name();
	
	$ls['name'] = q_name($ls['uid']);
	
	//�����˵�
	$trophy_all = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_trophy_list')." WHERE uid='".$ls['uid']."'");
	if(count($trophy_all)<=0){
		prompt(co('inif06'));
	}
	for($i=0;$i<count($trophy_all);$i++){
		$trop_opt .= '<option value="'.$trophy_all[$i]['id'].'">'.$trophy_all[$i]['t_name'].'</option>';
	}

	include template('zgxsh_trophy:trophy/trophy_recycling_choose');
  exit();
}
elseif($_GET['op']=="trophy_recycling_sub"){  //���ս���_�ύ
	security::hash_if();  //formhash  trop
	$ls = security::filter($_GET);
  security::int_if($ls['uid'],co('inif01'));
  security::int_if($ls['trop'],co('inif01'));
	
	$ls['name'] = q_name($ls['uid']);
	
	//��ȡ������
	$trophy = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_trophy_list')." WHERE uid='".$ls['uid']."' AND id='".$ls['trop']."'");
	if(!$trophy){
		prompt(co('inif07'),"location='plugin.php?id=zgxsh_trophy:setup'");
	}
	//��ȡ���м�
	$user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_trophy_user')." WHERE uid='".$ls['uid']."'");
	for($i=1;$i<12;$i++){
		if($user['trophy'.$i]==$ls['trop']){
		  $up['trophy'.$i] = 0;
	  }
	}
	
	DB::update('zgxsh_trophy_user',$up,array('uid'=>$ls['uid']));
	DB::delete('zgxsh_trophy_list',array('id'=>$ls['trop']));
	
	notice($ls['uid'],co('inif08'),co('inif09')." ".$trophy['t_name']." ".co('inif10'));

	prompt(co('inif11').$ls['name'].co('inif12').$trophy['t_name'].co('inif13'),"location='plugin.php?id=zgxsh_trophy:setup'");
}

elseif($_GET['op']=="trophy_add"){  //����
	include template('zgxsh_trophy:trophy/trophy_add');
  exit();
}

elseif($_GET['op']=="trophy_add_sub"){  //����
	security::hash_if();  //formhash
	$ls = security::filter($_GET);
	security::txt_ch($ls['t_name'],co('inif14'),0,2,10);
	security::txt_ch($ls['t_txt'],co('inif15'),0,10);
	if(!$ls['t_img']){
		prompt(co('inif16'));
	}
	
	$t_name = DB::fetch_first("SELECT t_name FROM ".DB::table('zgxsh_trophy_varieties')." WHERE t_name='".$ls['t_name']."'");
	if($t_name){
		prompt(co('inif17'));
	}
	
	$in = array(
	  't_name' => $ls['t_name'],
	  't_txt' => $ls['t_txt'],
	  't_img' => $ls['t_img'],
	);
	
	DB::insert('zgxsh_trophy_varieties',$in);
		
	prompt(co('inif18'),"location='plugin.php?id=zgxsh_trophy:setup'");
}
elseif($_GET['op']=="trophy_edit"){  //�༭
	security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
	
	$trophy = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_trophy_varieties')." WHERE id='".$ls['bh']."'");
	
	include template('zgxsh_trophy:trophy/trophy_edit');
  exit();
}
elseif($_GET['op']=="trophy_edit_sub"){  //�༭
	security::hash_if();  //formhash
	$ls = security::filter($_GET);
	security::txt_ch($ls['t_name'],co('inif14'),0,2,10);
	security::txt_ch($ls['t_txt'],co('inif15'),0,10);
	if(!$ls['t_img']){
		prompt(co('inif19'));
	}
	
	$t_name = DB::fetch_first("SELECT t_name FROM ".DB::table('zgxsh_trophy_varieties')." WHERE t_name='".$ls['t_name']."' AND id!='".$ls['bh']."'");
	if($t_name){
		prompt(co('inif20'));
	}
	
	$up = array(
	  't_name' => $ls['t_name'],
	  't_txt' => $ls['t_txt'],
	  't_img' => $ls['t_img'],
	);
	
	DB::update('zgxsh_trophy_varieties',$up,array('id'=>$ls['bh']));
		
	prompt(co('inif21'),"location='plugin.php?id=zgxsh_trophy:setup'");
}

elseif($_GET['op']=="trophy_del"){  //ɾ��
	security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
	
	DB::delete('zgxsh_trophy_varieties',array('id'=>$ls['bh']),1);
	
	prompt(co('inif22'),"location='plugin.php?id=zgxsh_trophy:setup'");
}
	
//ǽ�����
elseif($_GET['op']=="metope_edit"){  //�޸�ǽ�潱��
	security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
	//��ȡ�û����ݺ��û����н���
	$user = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_trophy_user')." WHERE uid='".$_G['uid']."'");
	$trophy = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_trophy_list')." WHERE uid='".$_G['uid']."'");
	//ѡ���
	$trophy_option .= '<option value="0">'.co('inif23').'</option>';
	
	for($i=0;$i<count($trophy);$i++){
		if($user['trophy'.$ls['bh']] == $trophy[$i]['id']){  //�Ƿ�ǰĬ��
			$trophy_option .= '<option value="'.$trophy[$i]['id'].'" selected>'.$trophy[$i]['t_name'].'</option>';
		}elseif(trophy_are($trophy[$i]['id'],$_G['uid'])){  //�Ƿ��Ѿ�����
			$trophy_option .= '<option value="'.$trophy[$i]['id'].'" disabled>'.$trophy[$i]['t_name'].'</option>';
		}else{
			$trophy_option .= '<option value="'.$trophy[$i]['id'].'">'.$trophy[$i]['t_name'].'</option>';
		}
	}
	
	include template('zgxsh_trophy:metope/metope_edit');
  exit();
}
elseif($_GET['op']=="metope_edit_sub"){  //�޸�ǽ�潱��_�ύ
	security::hash_if(1);
	$ls = security::filter($_GET);
	
	$up = array(
	  'trophy'.$ls['bh'] => $ls['t_id'],
	);
	
	DB::update('zgxsh_trophy_user',$up,array('uid'=>$_G['uid']));
	
	prompt(co('inif24'),"location='plugin.php?id=zgxsh_trophy:metope'");
}
//���������տ�
elseif($_GET['op']=="due_to"){

	$ls = security::filter($_GET);
  
  $paramete['icon']=2;  //��ʾͼ��
  
  $setup_url = '<a style="color:#229" target="_blank" href="https://dism.taobao.com/?@zgxsh_trophy.plugin">'.co('inif25').'</a>';
  
  if(!$_TRC['due_to']){
    prompt(co('inif26').'<br>'.$setup_url,"",$paramete);
  }
  
  header("Location:plugin.php?id=zgxsh_trophy:due_to");
  exit();
}

system_end()
?>