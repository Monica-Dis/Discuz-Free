<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

if($_GET['op'] == "prize_add"){
	$ls = security::filter($_GET);
  include template('zgxsh_chest:prize/prize_add');
  exit();
}
elseif($_GET['op'] == "prize_add_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  security::txt_en($ls['name'],co('priz01'),2,30);
  security::txt_en($ls['txt'],co('priz02'),10,255);
  security::int_if($ls['c_id'],co('priz03'));
  security::int_if($ls['lv'],co('priz04'));
  security::int_if($ls['prob'],co('priz05'));
  security::int_if($ls['type'],co('priz06'));
  security::int_if($ls['cond'],co('priz07'),0,1);
  
  prize::add($ls);
  
  prompt(co('priz08'));
}
elseif($_GET['op'] == "prize_setup"){
	$ls = security::filter($_GET);
  
  $db_prize = prize::read($ls['bh']);
  //����ѡ����Ŀ type
  /*
  ����Ϊ���� : �����趨��������
  ����Ϊ���� : ���������� , �������� ���쾭�� ���Ծ���
  ����Ϊʵ�� : ����Ϊ��ȡ��ʽ; ��� �����; 
  ����Ϊ���� : ����Ϊ�������ֶ���;
   */
  if($db_prize['type']=="1"){  //��̳����
    $proj_htm = '<select name="proj" lay-verify="required">';
    $proj_htm .= '<option value="0">'.co('priz09').'</option>';
    foreach($_G['setting']['extcredits'] as $k=>$v){
      if($k==$db_prize['proj']){
        $proj_htm .= '<option value="'.$k.'" selected>'.$_G['setting']['extcredits'][$k]['title'].'</option>';
      }else{
        $proj_htm .= '<option value="'.$k.'">'.$_G['setting']['extcredits'][$k]['title'].'</option>';
      }
    }
    $proj_htm .= '</select>';
  }
  if($db_prize['type']=="2"){  //����ڻ���
    if($db_prize['proj']=='key'){
      $proj_sele[1] = "selected";
    }elseif($db_prize['proj']=='lock_exp'){
      $proj_sele[2] = "selected";
    }elseif($db_prize['proj']=='cast_exp'){
      $proj_sele[3] = "selected";
    }elseif($db_prize['proj']=='thef_exp'){
      $proj_sele[4] = "selected";
    }
    $proj_htm = '<select name="proj" lay-verify="required">';
    $proj_htm .= '<option value="0">'.co('priz10').'</option>';
    $proj_htm .= '<option value="k" '.$proj_sele[1].'>'.co('priz11').'</option>';
    $proj_htm .= '<option value="lock_exp" '.$proj_sele[2].'>'.co('priz12').'</option>';
    $proj_htm .= '<option value="cast_exp" '.$proj_sele[3].'>'.co('priz13').'</option>';
    $proj_htm .= '<option value="thef_exp" '.$proj_sele[4].'>'.co('priz14').'</option>';
    $proj_htm .= '</select>';
  }
  if($db_prize['type']=="3"){  //ʵ�� ��ȡ��ʽ
    if($db_prize['proj']==''){ 
      $proj_sele[1] = "selected";
    }elseif($db_prize['proj']=='2'){
      $proj_sele[2] = "selected";
    }
    $proj_htm = '<select name="proj" lay-verify="required">';
    $proj_htm .= '<option value="0">'.co('priz15').'</option>';
    $proj_htm .= '<option value="1" '.$proj_sele[1].'>'.co('priz16').'</option>';
    $proj_htm .= '<option value="2" '.$proj_sele[2].'>'.co('priz17').'</option>';
    $proj_htm .= '</select>';
  }
  if($db_prize['type']=="4"){  //���� �����ֶ���
    $proj_htm = '<input name="proj" required lay-verify="required" placeholder="'.co('priz18').'" class="layui-input" value="'.$db_prize['proj'].'"/>';
  }
  
  
  $see['form'] = layui::form_name();

  include template('zgxsh_chest:prize/prize_setup');
  exit();
}
elseif($_GET['op'] == "prize_setup_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
  security::int_if($ls['inve'],co('priz19'),0,1,1);
  security::int_if($ls['min'],co('priz20'));
  security::int_if($ls['max'],co('priz21'));
  security::int_if($ls['price'],co('priz22'),0,1);
  
  $db_prize = prize::read($ls['bh']);  //��ȡ��Ʒ����
  
  if(!$ls['proj']){
    prompt(co('priz23'));
  }
  if($db_prize['type']==4){
    $ls['proj'] = explode('|',$ls['proj']);
    if(count($ls['proj'])<>2){
      prompt(co('priz24'));
    }
    $ls['proj'] = implode('|',$ls['proj']);
  }
  
  //��ʼ�����
  prize::setup($ls);
  prompt(co('priz25'));
}
elseif($_GET['op'] == "prize_edit"){
	$ls = security::filter($_GET);
  $db_prize = prize::read($ls['bh']);
  include template('zgxsh_chest:prize/prize_edit');
  exit();
}
elseif($_GET['op'] == "prize_edit_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  security::txt_en($ls['name'],co('priz01'),2,30);
  security::txt_en($ls['txt'],co('priz02'),10,255);
  security::int_if($ls['c_id'],co('priz03'));
  security::int_if($ls['lv'],co('priz04'));
  security::int_if($ls['prob'],co('priz05'));
  security::int_if($ls['type'],co('priz06'));
  security::int_if($ls['cond'],co('priz07'),0,1);
  
  prize::edit($ls);
  
  prompt(co('priz26'));
}
elseif($_GET['op'] == "prize_del"){
	$ls = security::filter($_GET);
  $db_prize = prize::read($ls['bh']);
  include template('zgxsh_chest:prize/prize_del');
  exit();
}
elseif($_GET['op'] == "prize_del_sub"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  prize::del($ls);
  prompt(co('priz27'));
}

system_end();
?>