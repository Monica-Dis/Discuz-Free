<?php
/**
 *	[����ǽ(zgxsh_chest.install)] (C)2019-2099 Powered by dis'.'m.tao'.'bao.com.
 *	Version: 1.0
 *	Date: 2019-3-24 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_chest_boss`;
CREATE TABLE `cdb_zgxsh_chest_boss` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `c_must` int(10) NOT NULL,
  `s_must` int(10) NOT NULL,
  `g_must` int(10) NOT NULL,
  `i_must` int(10) NOT NULL,
  `overall_must` int(10) NOT NULL,
  `state` int(10) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `boss_id` (`uid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_chest`;
CREATE TABLE `cdb_zgxsh_chest_chest` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `lv` int(10) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `hp` int(10) NOT NULL default '100',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_news`;
CREATE TABLE `cdb_zgxsh_chest_news` (
  `id` int(10) NOT NULL auto_increment,
  `type` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_prize`;
CREATE TABLE `cdb_zgxsh_chest_prize` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `c_id` int(1) NOT NULL,
  `lv` int(10) NOT NULL,
  `prob` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `type` int(10) NOT NULL,
  `proj` varchar(255) NOT NULL,
  `min` int(10) NOT NULL,
  `max` int(10) NOT NULL,
  `cond` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `inve` int(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cid` (`c_id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_profit`;
CREATE TABLE `cdb_zgxsh_chest_profit` (
  `id` int(10) NOT NULL auto_increment,
  `v` int(10) NOT NULL,
  `txt` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_setup`;
CREATE TABLE `cdb_zgxsh_chest_setup` (
  `synt_sr_sk` int(3) NOT NULL,
  `synt_sr_gk` int(3) NOT NULL,
  `synt_sr_ik` int(3) NOT NULL,
  `synt_sr_astr` int(3) NOT NULL,
  `mate_sk` int(3) NOT NULL,
  `mate_gk` int(3) NOT NULL,
  `mate_ik_1` int(3) NOT NULL,
  `mate_ik_2` int(3) NOT NULL,
  `mate_ik_3` int(3) NOT NULL,
  `money_sk` int(3) NOT NULL,
  `money_gk` int(3) NOT NULL,
  `money_ik` int(3) NOT NULL,
  `stolen_time` int(20) NOT NULL,
  `stol_sr_ck` int(3) NOT NULL,
  `stol_sr_sk` int(3) NOT NULL,
  `stol_sr_gk` int(3) NOT NULL,
  `stol_sr_ik` int(3) NOT NULL,
  `stol_mo_ck` int(3) NOT NULL,
  `stol_mo_sk` int(3) NOT NULL,
  `stol_mo_gk` int(3) NOT NULL,
  `stol_mo_ik` int(3) NOT NULL,
  `succ_ck` int(3) NOT NULL,
  `succ_sk` int(3) NOT NULL,
  `succ_gk` int(3) NOT NULL,
  `succ_ik` int(3) NOT NULL,
  `police_see` int(20) NOT NULL,
  `security_time` int(20) NOT NULL,
  `sing_v` int(20) default NULL,
  `vip1_c` int(1) default NULL,
  `vip1_s` int(3) default NULL,
  `vip1_t` int(20) default NULL,
  `vip1_v` int(20) default NULL,
  `vip2_c` int(1) default NULL,
  `vip2_s` int(3) default NULL,
  `vip2_t` int(20) default NULL,
  `vip2_v` int(20) default NULL,
  `vip3_c` int(1) default NULL,
  `vip3_s` int(3) default NULL,
  `vip3_t` int(20) default NULL,
  `vip3_v` int(20) default NULL,
  `vip4_c` int(1) default NULL,
  `vip4_s` int(3) default NULL,
  `vip4_t` int(20) default NULL,
  `vip4_v` int(20) default NULL,
  `vip5_c` int(1) default NULL,
  `vip5_s` int(3) default NULL,
  `vip5_t` int(20) default NULL,
  `vip5_v` int(20) default NULL,
  `vip6_c` int(1) default NULL,
  `vip6_s` int(3) default NULL,
  `vip6_t` int(20) default NULL,
  `vip6_v` int(20) default NULL,
  `vip7_c` int(1) default NULL,
  `vip7_s` int(3) default NULL,
  `vip7_t` int(20) default NULL,
  `vip7_v` int(20) default NULL,
  `vip8_c` int(1) default NULL,
  `vip8_s` int(3) default NULL,
  `vip8_t` int(20) default NULL,
  `vip8_v` int(20) default NULL
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_sign`;
CREATE TABLE `cdb_zgxsh_chest_sign` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_user`;
CREATE TABLE `cdb_zgxsh_chest_user` (
  `uid` int(10) NOT NULL,
  `k` int(10) NOT NULL default '0',
  `lock_lv` int(3) NOT NULL default '0',
  `lock_exp` int(10) NOT NULL default '0',
  `lock_exp_t` int(10) NOT NULL default '100',
  `lock_n` int(10) NOT NULL default '0',
  `cast_lv` int(3) NOT NULL default '0',
  `cast_exp` int(10) NOT NULL default '0',
  `cast_exp_t` int(10) NOT NULL default '100',
  `cast_n` int(10) NOT NULL default '0',
  `thef_lv` int(3) NOT NULL default '0',
  `thef_exp` int(10) NOT NULL default '0',
  `thef_exp_t` int(10) NOT NULL default '100',
  `thef_n` int(10) NOT NULL default '0',
  `address_u` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `consignee` varchar(255) NOT NULL,
  `vip` int(1) default NULL,
  `vip_time` int(20) default NULL,
  PRIMARY KEY  (`uid`),
  KEY `uid` (`k`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_chest_winrec`;
CREATE TABLE `cdb_zgxsh_chest_winrec` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `type_proj` varchar(255) NOT NULL,
  `number` int(20) NOT NULL,
  `price_sum` int(20) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `the_goods` int(1) NOT NULL,
  `order_no` varchar(255) NOT NULL,
  `time` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `time` (`uid`,`time`)
) ENGINE=MyISAM;
INSERT INTO `cdb_zgxsh_chest_setup` VALUES ('60', '40', '20', '40', '5', '5', '1', '5', '10', '1', '3', '5', '604800', '20', '15', '10', '5', '1', '2', '3', '4', '10', '20', '30', '50', '600', '86400', '1','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
EOF;

runquery($sql);
$finish = true;
?>