<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_user')." LIKE 'vip'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_user')." ADD vip int(10) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_user')." LIKE 'vip_time'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_user')." ADD vip_time int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip1_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip1_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip1_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip1_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip1_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip1_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip1_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip1_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip2_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip2_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip2_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip2_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip2_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip2_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip2_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip2_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip3_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip3_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip3_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip3_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip3_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip3_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip3_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip3_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip5_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip5_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip5_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip5_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip5_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip5_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip5_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip5_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip6_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip6_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip6_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip6_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip6_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip6_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip6_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip6_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip7_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip7_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip7_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip7_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip7_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip7_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip7_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip7_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip8_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip8_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip8_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip8_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip8_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip8_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip8_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip8_v int(20) default NULL");
}

if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_c'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_c int(1) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_s'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_s int(3) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_t'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_t int(20) default NULL");
}
if(!$row = DB::fetch_first("SHOW COLUMNS FROM ".DB::table('zgxsh_chest_setup')." LIKE 'vip4_v'")) {
	DB::query("ALTER TABLE ".DB::table('zgxsh_chest_setup')." ADD vip4_v int(20) default NULL");
}

runquery($sql);

$finish = true;
?>