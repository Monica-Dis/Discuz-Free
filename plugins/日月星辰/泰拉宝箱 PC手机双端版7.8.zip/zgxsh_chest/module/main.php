<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){
  header("Location:member.php?mod=logging&action=login");
  exit();
}

//----ϵͳ��������----
$_TRC = $_G['cache']['plugin']['zgxsh_chest'];
$_TRC['setup'] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_setup'));
$_TRC['shop_setup'] = explode("|",$_TRC['shop_setup']);
//�û��鷴����
$_TRC['group_user'] = unserialize($_TRC['group_user']);
$_TRC['cast_red'] = $_TRC['cast_red']<0?0:$_TRC['cast_red'];
$_TRC['cast_red'] = $_TRC['cast_red']>100?100:$_TRC['cast_red'];

//ǩ���ж�
$sign_time = DB::result_first("SELECT time FROM ".DB::table('zgxsh_chest_sign')." WHERE uid='".$_G['uid']."' ORDER BY time DESC LIMIT 1");
if(dgmdate(time(),'d')==dgmdate($sign_time,'d')){
  $user_sign_true = true;
}

//print_r($_TRC['group_user']);



//Ӧ������-����ҳ�������ʾ
$navtitle = $_TRC['p_name'];

//----�����б�----
include 'class/system.php';
include 'class/security.php';
include 'class/layui.php';


//----��չ����----
include 'class/vip.php';
include 'class/shop.php';
include 'class/user.php';
include 'class/ico_del.php';
include 'class/music_close.php';


// ext_sys ext_1 ��������ֹ����
if(!$_TRC['ext_sys'] or !$_TRC['ext_1'] or !$_TRC['ext_2'] or !$_TRC['ext_3']){
  $paramete['icon'] = 2;
  prompt(co('main143'),"location='forum.php'",$paramete);
}

if(!in_array($_G['groupid'],$_TRC['group_user'])){
  $paramete['icon'] = 3;
  prompt(co('no_init'),"location='".$_TRC['r_url']."'",$paramete);
}



//----�������----
//��� ��ֵ intval() ���� daddslashes()
//--�˵�����--
function nva_this(){
  global $_GET;
  if($_GET['id']=="zgxsh_chest:index"){
    $r[1] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:cast"){
    $r[2] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:thef"){
    $r[3] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:setup"){
    $r[4] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:prize"){
    $r[5] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:winrec"){
    $r[6] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:earsta"){
    $r[7] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:delive"){
    $r[8] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:vip"){
    $r[9] = "layui-this";
  }elseif($_GET['id']=="zgxsh_chest:user"){
    $r[10] = "layui-this";
  }
  return $r;
}
//--ǩ������--
function sign(){
  global $_TRC;
  global $_G;
  
  $sign_time = DB::result_first("SELECT time FROM ".DB::table('zgxsh_chest_sign')." WHERE uid='".$_G['uid']."' ORDER BY time DESC LIMIT 1");
  if(dgmdate(time(),'d')==dgmdate($sign_time,'d')){
    $r['txt'] = co('main01');
    $r['au'] = "lock_3";
    return $r;
  }
  
  $sing_v = $_TRC['setup']['sing_v'];
  integral($_G['uid'],$sing_v,$_TRC['ext_1'],$_TRC['p_name'],co('main03'));
  
  //�����µ��߼�VIPǩ����������
  if($_TRC['vip_true']){  //�Ƿ�װ��չ
  $db_user = db_user::survive();  //�û�����
  if($db_user['vip']>0 and $db_user['vip']<=8){
    $vip_c = $_TRC['setup']['vip'.$db_user['vip'].'_c'];  //Կ������
    $vip_s = $_TRC['setup']['vip'.$db_user['vip'].'_s'];  //Կ������
    if($vip_c>=1 and $vip_c<=3){
      integral($_G['uid'],$vip_s,$_TRC['ext_'.$vip_c],$_TRC['p_name'],co('vip06'));
      $vip_txt = "<br><span style='color:#f40'>".co('main141')." ".$_G['setting']['extcredits'][$_TRC['ext_'.$vip_c]]['img'].$_G['setting']['extcredits'][$_TRC['ext_'.$vip_c]]['title']." ".$vip_s." ".$_G['setting']['extcredits'][$_TRC['ext_'.$vip_c]]['unit']."</span>";
    }elseif($vip_c==4){
      db_user::attr_edit($_G['uid'],'k',$vip_s);
      $vip_txt = "<br><span style='color:#f40'>".co('main142',array('co1'=>$vip_s))."</span>";
    }else{
      $vip_txt = "";
    }
  }
  }
  
  
  DB::insert('zgxsh_chest_sign',array('uid'=>$_G['uid'],'time'=>time()));
  
  news::add(1,q_name($_G['uid']).co('main04',array('1'=>$sing_v)));
  
  $r['txt'] = co('main05',array('1'=>$sing_v)).$vip_txt;
  $r['au'] = "sign";
  return $r;
}
//--�û���--
class db_user {
  function survive($uid=""){  //�û����ݶ�ȡ����ʼ��
    global $_G;
    global $_TRC;
    $uid = !$uid?$_G['uid']:$uid;  //����Ϊ�����õ�ǰUIDȡ��
    $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_user')." WHERE uid='".$uid."'");
    if(!$r){
      $in = array(
        'uid' => $uid,	//UID
      );
      DB::insert('zgxsh_chest_user',$in);
      $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_user')." WHERE uid='".$uid."'");
      $r['dot'] = DB::result_first("SELECT count(id) FROM ".DB::table('zgxsh_chest_winrec')." WHERE the_goods='1' OR the_goods='2'");
      news::add(1,co('main06').q_name($uid).co('main07',array('1'=>$_TRC['p_name'])));
    }
    return $r;
  }
  function setup($ls){
    $up = array(
      'address_u' => daddslashes($ls['address_u']),
      'phone' => daddslashes($ls['phone']),
      'consignee' => daddslashes($ls['consignee']),
    );
    DB::update('zgxsh_chest_user',$up,array('uid'=>$ls['uid']));
    return true;
  }
  function attr_edit($uid,$attr,$v){  //UID �����ֶ� ���� 
    $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_user')." WHERE uid='".$uid."'");
    $up = array(
      $attr => intval($r[$attr]+$v),
    );
    if($attr=="lock_exp" and $r['lock_exp']>=$r['lock_exp_t']){
      $up['lock_exp'] = $r['lock_exp'] - $r['lock_exp_t'];
      $up['lock_exp_t'] = $r['lock_exp_t']+100;
      $up['lock_lv'] = $r['lock_lv']+1;
      news::add(1,q_name($uid).co('main08').' LV:'.$up['lock_lv']);
    }
    if($attr=="cast_exp" and $r['cast_exp']>=$r['cast_exp_t']){
      $up['cast_exp'] = $r['cast_exp'] - $r['cast_exp_t'];
      $up['cast_exp_t'] = $r['cast_exp_t']+100;
      $up['cast_lv'] = $r['cast_lv']+1;
      news::add(1,q_name($uid).co('main09').' LV:'.$up['cast_lv']);
    }
    if($attr=="thef_exp" and $r['thef_exp']>=$r['thef_exp_t']){
      $up['thef_exp'] = $r['thef_exp'] - $r['thef_exp_t'];
      $up['thef_exp_t'] = $r['thef_exp_t']+100;
      $up['thef_lv'] = $r['thef_lv']+1;
      news::add(1,q_name($uid).co('main10').' LV:'.$up['thef_lv']);
    }
    if($attr=="k" and $v<0 and $r['k']+$v<0){
      prompt(co('main11'));
    }
    DB::update('zgxsh_chest_user',$up,array('uid'=>$uid));
    return true;
  }
}
//--���а���--	
class ranking {
  function lock(){
    $db_lock = DB::fetch_all("SELECT uid,lock_lv,lock_n FROM ".DB::table('zgxsh_chest_user')." WHERE lock_n > 0 ORDER BY lock_n DESC LIMIT 10");
    for($i=0;$i<10;$i++){
      $db_lock[$i]['name'] = q_name($db_lock[$i]['uid']);
      $db_lock[$i]['lock_lv'] = !$db_lock[$i]['lock_lv']?" -- ":$db_lock[$i]['lock_lv'];
      $db_lock[$i]['lock_n'] = !$db_lock[$i]['lock_n']?" -- ":$db_lock[$i]['lock_n'];
    }
    $r = $db_lock;
    return $r;
  }
  function cast(){
    $db_cast = DB::fetch_all("SELECT uid,cast_lv,cast_n FROM ".DB::table('zgxsh_chest_user')." WHERE cast_n > 0 ORDER BY cast_n DESC LIMIT 10");
    for($i=0;$i<10;$i++){
      $db_cast[$i]['name'] = q_name($db_cast[$i]['uid']);
      $db_cast[$i]['cast_lv'] = !$db_cast[$i]['cast_lv']?" -- ":$db_cast[$i]['cast_lv'];
      $db_cast[$i]['cast_n'] = !$db_cast[$i]['cast_n']?" -- ":$db_cast[$i]['cast_n'];
    }
    $r = $db_cast;
    return $r;
  }
  function thef(){
    $db_thef = DB::fetch_all("SELECT uid,thef_lv,thef_n FROM ".DB::table('zgxsh_chest_user')." WHERE thef_n > 0 ORDER BY thef_n DESC LIMIT 10");
    for($i=0;$i<10;$i++){
      $db_thef[$i]['name'] = q_name($db_thef[$i]['uid']);
      $db_thef[$i]['thef_lv'] = !$db_thef[$i]['thef_lv']?" -- ":$db_thef[$i]['thef_lv'];
      $db_thef[$i]['thef_n'] = !$db_thef[$i]['thef_n']?" -- ":$db_thef[$i]['thef_n'];
    }
    $r = $db_thef;
    return $r;
  }
}
//--������--
class chest {
  function create($id){  //�������� 
    //----ͭ��----
    $c['1'][1] = array('name'=>co('main12'),'ico'=>'1001');
    $c['1'][2] = array('name'=>co('main13'),'ico'=>'1004');
    $c['1'][3] = array('name'=>co('main14'),'ico'=>'1005');
    $c['1'][4] = array('name'=>co('main15'),'ico'=>'1003');
    $c['1'][5] = array('name'=>co('main16'),'ico'=>'1006');
    $c['1'][6] = array('name'=>co('main17'),'ico'=>'1007');
    $c['1'][7] = array('name'=>co('main18'),'ico'=>'1009');
    $c['1'][8] = array('name'=>co('main19'),'ico'=>'1011');
    $c['1'][9] = array('name'=>co('main20'),'ico'=>'1012');
    $c['1'][10] = array('name'=>co('main21'),'ico'=>'1020');
    $c['1'][11] = array('name'=>co('main22'),'ico'=>'1023');
    $c['1'][12] = array('name'=>co('main23'),'ico'=>'1031');
    //----����----
    $c['2'][1] = array('name'=>co('main24'),'ico'=>'1008');
    $c['2'][2] = array('name'=>co('main25'),'ico'=>'1010');
    $c['2'][3] = array('name'=>co('main26'),'ico'=>'1019');
    $c['2'][4] = array('name'=>co('main27'),'ico'=>'1021');
    $c['2'][5] = array('name'=>co('main28'),'ico'=>'1022');
    $c['2'][6] = array('name'=>co('main29'),'ico'=>'1025');
    $c['2'][7] = array('name'=>co('main30'),'ico'=>'1026');
    $c['2'][8] = array('name'=>co('main31'),'ico'=>'1027');
    $c['2'][9] = array('name'=>co('main32'),'ico'=>'1028');
    $c['2'][10] = array('name'=>co('main33'),'ico'=>'1029');
    //----����----
    $c['3'][1] = array('name'=>co('main34'),'ico'=>'1024');
    $c['3'][2] = array('name'=>co('main35'),'ico'=>'1002');
    $c['3'][3] = array('name'=>co('main36'),'ico'=>'1014');
    $c['3'][4] = array('name'=>co('main37'),'ico'=>'1013');
    $c['3'][5] = array('name'=>co('main38'),'ico'=>'1030');
    $c['3'][6] = array('name'=>co('main39'),'ico'=>'1032');
    $c['3'][7] = array('name'=>co('main40'),'ico'=>'1033');
    $c['3'][8] = array('name'=>co('main41'),'ico'=>'1034');
    $c['3'][9] = array('name'=>co('main42'),'ico'=>'1035');
    $c['3'][10] = array('name'=>co('main43'),'ico'=>'1036');
    //----������----
    $c['4'][1] = array('name'=>co('main44'),'ico'=>'1015');
    $c['4'][2] = array('name'=>co('main45'),'ico'=>'1016');
    $c['4'][3] = array('name'=>co('main46'),'ico'=>'1017');
    $c['4'][4] = array('name'=>co('main47'),'ico'=>'1018');
    $c['4'][5] = array('name'=>co('main48'),'ico'=>'1037');
    $c['4'][6] = array('name'=>co('main49'),'ico'=>'1038');
    $c['4'][7] = array('name'=>co('main50'),'ico'=>'1039');
    $c['4'][8] = array('name'=>co('main51'),'ico'=>'1040');
    $c['4'][9] = array('name'=>co('main52'),'ico'=>'1041');
    $c['4'][10] = array('name'=>co('main53'),'ico'=>'1042');
    
    $up = $c[$id][rand(1,count($c[$id]))];
    $up['lv'] = rand(1,100);
    $up['hp'] = 100;
    
    DB::update('zgxsh_chest_chest',$up,array('id'=>$id));  //�ڲ��������  
    
    news::add($id+3,$up['name'].co('main54'));
    
  }
  function see(){  //������ҳ��ʾ
    $r[1] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='1'");
    $r[2] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='2'");
    $r[3] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='3'");
    $r[4] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='4'");
    //û�����ݴ���������
    if(!$r[1]){DB::insert('zgxsh_chest_chest',array('id'=>1));}
    if(!$r[2]){DB::insert('zgxsh_chest_chest',array('id'=>2));}
    if(!$r[3]){DB::insert('zgxsh_chest_chest',array('id'=>3));}
    if(!$r[4]){DB::insert('zgxsh_chest_chest',array('id'=>4));}
    //û�б��䴴������
    if(!$r[1]['name']){
      self::create(1);
      $r[1] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='1'");
    }
    if(!$r[2]['name']){
      self::create(2);
      $r[2] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='2'");
    }
    if(!$r[3]['name']){
      self::create(3);
      $r[3] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='3'");
    }
    if(!$r[4]['name']){
      self::create(4);
      $r[4] = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='4'");
    }
    return $r;
  }
  function lock($id){  //������
    global $_TRC;
    
    $profit = DB::result_first("SELECT sum(v) FROM ".DB::table('zgxsh_chest_profit'));  //����    
    $db_c = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='".$id."'");
    $db_p = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE c_id='".$id."' AND (cond<='".$profit."' OR cond='0') AND inve!='0' AND lv <= '".$db_c['lv']."'");
    
    $db_user = db_user::survive();  //�û����� 
    
    if(!$db_c or $db_c['name']==""){
      $r['of'] = false;
      $r['txt'] = co('main55');
      $r['au'] = 3;
      return $r;
    }
    if(count($db_p)<=0){
      $r['of'] = false;
      $r['txt'] = co('main56');
      $r['au'] = 3;
      return $r;
    }
    //����Կ��
    if($id==1){
      if(inte_probe($db_user['uid'],1,$_TRC['ext_1'])>0){
        $r['of'] = false;
        $r['txt'] = co('main57');
        $r['au'] = 3;
        return $r;
      }
      integral($db_user['uid'],-1,$_TRC['ext_1'],$_TRC['p_name'],co('main58')." [".$db_c['name']."] ");
    }elseif($id==2){
      if(inte_probe($db_user['uid'],1,$_TRC['ext_2'])>0){
        $r['of'] = false;
        $r['txt'] = co('main59');
        $r['au'] = 3;
        return $r;
      }
      integral($db_user['uid'],-1,$_TRC['ext_2'],$_TRC['p_name'],co('main58')." [".$db_c['name']."] ");
    }elseif($id==3){
      if(inte_probe($db_user['uid'],1,$_TRC['ext_3'])>0){
        $r['of'] = false;
        $r['txt'] = co('main60');
        $r['au'] = 3;
        return $r;
      }
      integral($db_user['uid'],-1,$_TRC['ext_3'],$_TRC['p_name'],co('main58')." [".$db_c['name']."] ");
    }elseif($id==4){
      if($db_user['k']<=0){
        $r['of'] = false;
        $r['txt'] = co('main61');
        $r['au'] = 3;
        return $r;
      }
      //���ٿ�����
      db_user::attr_edit($db_user['uid'],'k',-1);
    }
    //�����߼�
    $rand_lock = rand(0,100);  //�������
    
    $db_c['hp_j'] = rand(1,101-$db_c['lv']+$db_user['lock_lv']);  //���������;�
    $db_c['hp'] -= $db_c['hp_j'];
    
    if($rand_lock>=$db_c['lv']-$db_user['lock_lv'] or $db_c['hp']<0){  //�����ʸ������ӵȼ������ӿ���
      //ȷ�Ͻ���  
      $prob_sum = array_sum(arr_col($db_p,'prob'));  //���ʺ�
      $prob_rand = rand(1,$prob_sum);  //����ֵ
      for($i=0;$i<count($db_p);$i++){
        $db_p[$i]['prob_min'] = $db_p[$i-1]['prob_max']+0;
        $db_p[$i]['prob_max'] = $db_p[$i-1]['prob_max']+$db_p[$i]['prob']+0;
        if($prob_rand > $db_p[$i]['prob_min'] and $prob_rand <= $db_p[$i]['prob_max']){
          $prize = $db_p[$i];  //ȷ�Ͻ���
          break;
        }
      }
      //���Ž���
      $content = prize::the_awards($prize,$db_user,$db_c);  //�佱
      //���Ӿ���
      db_user::attr_edit($db_user['uid'],'lock_exp',2);
      //�Ƿ����˿���������
      if($db_c['id']==4){
        db_user::attr_edit($db_user['uid'],'lock_n',1);
      }
      //����ɾ��
      DB::update('zgxsh_chest_chest',array('name'=>''),array('id'=>$id));
      //���ؽ��
      $r['of'] = true;
      $r['title'] = co('main62');
      if($prize['ico']){
        $prize_img = '<img src="'.$prize['ico'].'" style="width: 80px;height: 80px"/>';
      }
      $r['content'] = '<div style="text-align:center">'.$prize_img.'<br>'.$content.'</div>';
      $r['btn'] = co('main63');
      $r['txt'] = co('main64');
      $r['ico'] = $db_c['ico'];
      $r['au'] = 1;
      return $r;
    }
    else{  //����ʧ�ܽ����;��ж�
      //���Ӿ���
      db_user::attr_edit($db_user['uid'],'lock_exp',1);
      //�۳�����Ѫ��
      self::hp($id,-$db_c['hp_j']);
      //���ؽ��
      $r['of'] = false;
      $r['title'] = co('main65');
      $r['content'] = co('main66').$db_c['hp_j'].co('main67');
      $r['btn'] = co('main68');
      $r['txt'] = co('main69').$db_c['hp_j'];
      $r['ico'] = $db_c['ico'];
      $r['au'] = 2;
      return $r;
    }
  }
  function hp($id,$v){
    $db_c = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_chest')." WHERE id='".$id."'");
    $up = array(
      'hp' => $db_c['hp']+$v,
    );
    DB::update('zgxsh_chest_chest',$up,array('id'=>$id));
    return true;
  }
}
//--�ϳ�--
class cast {
  function add($id,$uid){
    global $_TRC;
    global $_G;
    $db_user = db_user::survive($uid);  //�û�����
    //�ϳɷ���
    if($id==2){  //��Կ��
      //���ϱ���
      if(inte_probe($uid,$_TRC['setup']['money_sk'],$_TRC['ext_sys'])){
        $r['txt'] = $_G['setting']['extcredits'][$_TRC['ext_sys']]['title'].co('main78');
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      if(inte_probe($uid,$_TRC['setup']['mate_sk'],$_TRC['ext_1'])){
        $r['txt'] = co('main70');
        $r['au'] = "cast_o";
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      //���Ӷ��쾭��
      db_user::attr_edit($uid,'cast_exp',1);
      //�۳�����
      integral($uid,-$_TRC['setup']['money_sk'],$_TRC['ext_sys'],$_TRC['p_name'],co('main71'));
      //��¼ӯ��
      profit::add($_TRC['setup']['money_sk'],co('main72'));
      //�����Ƿ�ɹ�
      $ls['synt_rand'] = rand(-$_TRC['setup']['synt_sr_astr'],$_TRC['setup']['synt_sr_astr']);
      $ls['synt'] = $_TRC['setup']['synt_sr_sk'] + $db_user['cast_lv'] + $ls['synt_rand'];
      if(rand(1,100)<$ls['synt']){  //����ɹ�
        integral($uid,-$_TRC['setup']['mate_sk'],$_TRC['ext_1'],$_TRC['p_name'],co('main71'));
        integral($uid,1,$_TRC['ext_2'],$_TRC['p_name'],co('main73'));
        news::add(2,q_name($uid).co('main74'));
        $r['txt'] = co('main75');
        $r['au'] = "cast_t";
        $r['res'] = true;
      }else{
        $cast_red = ceil($_TRC['setup']['mate_sk']*($_TRC['cast_red']/100));
        integral($uid,-$cast_red,$_TRC['ext_1'],$_TRC['p_name'],co('main71'));  
        news::add(2,q_name($uid).co('main76'));
        $r['txt'] = co('main77').$ls['synt_rand'];
        $r['au'] = "cast_f";
        $r['res'] = false;
      }
    }elseif($id==3){  //��Կ��
      //���ϱ���
      if(inte_probe($uid,$_TRC['setup']['money_gk'],$_TRC['ext_sys'])){
        $r['txt'] = $_G['setting']['extcredits'][$_TRC['ext_sys']]['title'].co('main78');
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      if(inte_probe($uid,$_TRC['setup']['mate_gk'],$_TRC['ext_2'])){
        $r['txt'] = co('main79');
        $r['au'] = "cast_o";
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      //���Ӷ��쾭��
      db_user::attr_edit($uid,'cast_exp',2);
      //�۳�����
      integral($uid,-$_TRC['setup']['money_gk'],$_TRC['ext_sys'],$_TRC['p_name'],co('main80'));
      //��¼ӯ��
      profit::add($_TRC['setup']['money_gk'],co('main81'));
      //�����Ƿ�ɹ�
      $ls['synt_rand'] = rand(-$_TRC['setup']['synt_sr_astr'],$_TRC['setup']['synt_sr_astr']);
      $ls['synt'] = $_TRC['setup']['synt_sr_gk'] + $db_user['cast_lv'] + $ls['synt_rand'];
      if(rand(1,100)<$ls['synt']){  //����ɹ�
        integral($uid,-$_TRC['setup']['mate_gk'],$_TRC['ext_2'],$_TRC['p_name'],co('main80'));
        integral($uid,1,$_TRC['ext_3'],$_TRC['p_name'],co('main81'));
        news::add(2,q_name($uid).co('main82'));
        $r['txt'] = co('main83');
        $r['au'] = "cast_t";
        $r['res'] = true;
      }else{
        $cast_red = ceil($_TRC['setup']['mate_gk']*($_TRC['cast_red']/100));
        integral($uid,-$cast_red,$_TRC['ext_2'],$_TRC['p_name'],co('main80')); 
        news::add(2,q_name($uid).co('main84'));
        $r['txt'] = co('main77').$ls['synt_rand'];
        $r['au'] = "cast_f";
        $r['res'] = false;
      }
      
    }elseif($id==4){  //������
      //���ϱ���
      if(inte_probe($uid,$_TRC['setup']['money_ik'],$_TRC['ext_sys'])){
        $r['txt'] = $_G['setting']['extcredits'][$_TRC['ext_sys']]['title'].co('main78');
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      if(inte_probe($uid,$_TRC['setup']['mate_ik_1'],$_TRC['ext_1']) or inte_probe($uid,$_TRC['setup']['mate_ik_2'],$_TRC['ext_2']) or inte_probe($uid,$_TRC['setup']['mate_ik_3'],$_TRC['ext_3'])){
        $r['txt'] = co('main85');
        $r['au'] = "cast_o";
        $r['res'] = false;
        $init_v = inte_see($uid);
        $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
        $r['ext_v1'] = $init_v[$_TRC['ext_1']];
        $r['ext_v2'] = $init_v[$_TRC['ext_2']];
        $r['ext_v3'] = $init_v[$_TRC['ext_3']];
        $r['ext_v4'] = $db_user['k'];
        return $r;
      }
      //���Ӷ��쾭��
      db_user::attr_edit($uid,'cast_exp',3);
      //�۳�����
      integral($uid,-$_TRC['setup']['money_ik'],$_TRC['ext_sys'],$_TRC['p_name'],co('main86'));
      
      //��¼ӯ��
      profit::add($_TRC['setup']['money_ik'],co('main87'));
      //�����Ƿ�ɹ�
      $ls['synt_rand'] = rand(-$_TRC['setup']['synt_sr_astr'],$_TRC['setup']['synt_sr_astr']);
      $ls['synt'] = $_TRC['setup']['synt_sr_ik'] + $db_user['cast_lv'] + $ls['synt_rand'];
      if(rand(1,100)<$ls['synt']){  //����ɹ�
        
        integral($uid,-$_TRC['setup']['mate_ik_1'],$_TRC['ext_1'],$_TRC['p_name'],co('main86'));
        integral($uid,-$_TRC['setup']['mate_ik_2'],$_TRC['ext_2'],$_TRC['p_name'],co('main86'));
        integral($uid,-$_TRC['setup']['mate_ik_3'],$_TRC['ext_3'],$_TRC['p_name'],co('main86'));
        
        db_user::attr_edit($uid,'k',1);
        news::add(2,q_name($uid).co('main88'));
        //�������а�����
        db_user::attr_edit($uid,'cast_n',1);

        $r['txt'] = co('main89');
        $r['au'] = "cast_t";
        $r['res'] = true;
      }else{
        
        $cast_red1 = ceil($_TRC['setup']['mate_ik_1']*($_TRC['cast_red']/100));
        $cast_red2 = ceil($_TRC['setup']['mate_ik_2']*($_TRC['cast_red']/100));
        $cast_red3 = ceil($_TRC['setup']['mate_ik_3']*($_TRC['cast_red']/100));
        
        integral($uid,-$cast_red1,$_TRC['ext_1'],$_TRC['p_name'],co('main86'));
        integral($uid,-$cast_red2,$_TRC['ext_2'],$_TRC['p_name'],co('main86'));
        integral($uid,-$cast_red3,$_TRC['ext_3'],$_TRC['p_name'],co('main86'));
        
        news::add(2,q_name($uid).co('main90'));
        $r['txt'] = co('main77').$ls['synt_rand'];
        $r['au'] = "cast_f";
        $r['res'] = false;
      }
    }
    
    $init_v = inte_see($uid);
    
    $r['ext_v0'] = $init_v[$_TRC['ext_sys']];
    $r['ext_v1'] = $init_v[$_TRC['ext_1']];
    $r['ext_v2'] = $init_v[$_TRC['ext_2']];
    $r['ext_v3'] = $init_v[$_TRC['ext_3']];
    $r['ext_v4'] = $db_user['k'];
    
    return $r;
  }
}
//--͵��--
class thef {  
  function survive(){  //��ʼ��
    global $_TRC;
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    if(!$db_boss){
      //û��BOSS��ʼѰ��
//      $ls['TABLE'] = DB::table('common_member_status')." a,".DB::table('common_member_count')." b,".DB::table('zgxsh_chest_user')." c,".DB::table('zgxsh_chest_boss')." d";
//      $ls['TIME'] = time() - $_TRC['setup']['stolen_time'];
//      $ls['TIME_X'] = time() - $_TRC['setup']['security_time'];
//      $ls['W'][0] = "b.extcredits".$_TRC['ext_1'].">0";
//      $ls['W'][1] = "b.extcredits".$_TRC['ext_2'].">0";
//      $ls['W'][2] = "b.extcredits".$_TRC['ext_3'].">0";
//      $ls['W'][3] = "c.k>0";
//      $ls['WHERE'] = "(".implode(' OR ',$ls['W']).")";
//      $ls['WHERE'] = " WHERE a.lastvisit < '".$ls['TIME']."' AND a.uid = b.uid AND b.uid = c.uid AND c.uid = d.uid AND d.time<'".$ls['TIME_X']."' AND ".$ls['WHERE'];
      $ls['TABLE'] = DB::table('common_member_status')." a,".DB::table('common_member_count')." b";
      $ls['TIME'] = time() - $_TRC['setup']['stolen_time'];
      $ls['W'][0] = "b.extcredits".$_TRC['ext_1'].">0";
      $ls['W'][1] = "b.extcredits".$_TRC['ext_2'].">0";
      $ls['W'][2] = "b.extcredits".$_TRC['ext_3'].">0";
      $ls['WHERE'] = "(".implode(' OR ',$ls['W']).")";
      $ls['WHERE'] = " WHERE a.lastvisit < '".$ls['TIME']."' AND a.uid = b.uid AND ".$ls['WHERE'];
      $boss_uid_all = DB::fetch_all( "SELECT a.uid FROM ".$ls['TABLE'].$ls['WHERE']);
      if(!$boss_uid_all){
        $db_boss['ext_1'] = "--";
        $db_boss['ext_2'] = "--";
        $db_boss['ext_3'] = "--";
        $db_boss['ext_4'] = "--";
        $db_boss['name'] = co('main91');
        $db_boss['false'] = 1;
        return $db_boss;  //ʧ��û�к��ʵ�BOSS�û�
      }
      //�ɹ���ȡBOSS��
      $boss_uid_rand = rand(0,count($boss_uid_all)-1);
      $boss_uid = $boss_uid_all[$boss_uid_rand]['uid'];  //ȷ��BOSS��ѡ
      $in = array(
        'uid'=>$boss_uid,
        'c_must'=>0,  //ͭԿ�ױص�ָ��
        's_must'=>0,  //��Կ�ױص�ָ��
        'g_must'=>0,  //��Կ�ױص�ָ��
        'i_must'=>0,  //�������ص�ָ��
        'overall_must'=>0,  //Ѳ�����жȻ���
        'state'=>0,
        'time'=>0,
      );
      DB::insert('zgxsh_chest_boss',$in);  //������BOSS
      //����
      news::add(3,co('main92').q_name($boss_uid).co('main93'));
      //֪ͨĿ��
      notice($boss_uid,$_TRC['p_name'],co('main94'));
      //֪ͨ���
      notice($_G['uid'],$_TRC['p_name'],co('main95').q_name($boss_uid).co('main96'));
      //�ض�BOSS
      $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    }
    $ls['ext'] = inte_see($db_boss['uid']);
    $db_boss['ext_1'] = $ls['ext'][$_TRC['ext_1']];
    $db_boss['ext_2'] = $ls['ext'][$_TRC['ext_2']];
    $db_boss['ext_3'] = $ls['ext'][$_TRC['ext_3']];
    $db_boss['ext_4'] = DB::result_first("SELECT k FROM ".DB::table('zgxsh_chest_user')." WHERE uid='".$db_boss['uid']."'");
    $db_boss['ext_4'] = !$db_boss['ext_4']?0:$db_boss['ext_4'];
    $db_boss['name'] = q_name($db_boss['uid']);
    
    return $db_boss;
  }
  function escape($uid){  //����
    global $_TRC;
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE uid='".$uid."' AND state='0'");
    if($db_boss['uid']==$uid){
      $up = array(
        'state'=>1,
        'time'=>time(),
      );
      DB::update('zgxsh_chest_boss',$up,array('uid'=>$uid));
      news::add(3,q_name($uid).co('main97'));
      notice($uid,$_TRC['p_name'],co('main98'));
    }
    return true;
  }
  function bankruptcy_police(){  //�Ʋ����߱���
    global $_TRC;
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    if(!$db_boss){
      return false;
    }
    if($db_boss['overall_must']>=$_TRC['setup']['police_see']){
      news::add(3,q_name($db_boss['uid']).co('main99'));
      notice($db_boss['uid'],$_TRC['p_name'],co('main100'));
      $up = array(
        'state' => '2',
        'time'=>time(),
      );
      DB::update('zgxsh_chest_boss',$up,array('uid'=>$db_boss['uid']));
      return true;
    }
    $ls['ext'] = inte_see($db_boss['uid']);
    $db_boss['ext_1'] = $ls['ext'][$_TRC['ext_1']];
    $db_boss['ext_2'] = $ls['ext'][$_TRC['ext_2']];
    $db_boss['ext_3'] = $ls['ext'][$_TRC['ext_3']];
    $db_boss['ext_4'] = DB::result_first("SELECT k FROM ".DB::table('zgxsh_chest_user')." WHERE uid='".$db_boss['uid']."'");
    if(!$db_boss['ext_1'] and !$db_boss['ext_2'] and !$db_boss['ext_3'] and !$db_boss['ext_4']){
      news::add(3,q_name($db_boss['uid']).co('main101'));
      notice($db_boss['uid'],$_TRC['p_name'],co('main102'));
      $up = array(
        'state' => '3',
        'time'=>time(),
      );
      DB::update('zgxsh_chest_boss',$up,array('uid'=>$db_boss['uid']));
      return true;
    }
  }
  function alarm_add($v){  //���Ӿ���ֵ
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    $db_boss['overall_must']+=$v;
    $up = array(
      'overall_must' => $db_boss['overall_must'],
    );
    DB::update('zgxsh_chest_boss',$up,array('id'=>$db_boss['id']));
    return true;
  }
  function must_add($k,$v){
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    $db_boss[$k]+=$v;
    $up = array(
      $k => $db_boss[$k],
    );
    DB::update('zgxsh_chest_boss',$up,array('id'=>$db_boss['id']));
    return true;
  }
  function must_empty($k){
    $db_boss = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_boss')." WHERE state='0'");
    $up = array(
      $k => 0,
    );
    DB::update('zgxsh_chest_boss',$up,array('id'=>$db_boss['id']));
    return true;
  }
}
//----���Ų�����----
class news {
  function add($type,$txt){
    $in = array(
      'type' => intval($type),
      'txt' => daddslashes($txt),
      'time' => time(),
    );
    DB::insert('zgxsh_chest_news',$in);
  }
  function see_chest(){
    $r[1] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='4' ORDER BY id DESC LIMIT 8");
    $r[2] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='5' ORDER BY id DESC LIMIT 8");
    $r[3] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='6' ORDER BY id DESC LIMIT 8");
    $r[4] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='7' ORDER BY id DESC LIMIT 8");
    
    for($i=1;$i<=4;$i++){
      for($o=0;$o<8;$o++){
        $r[$i][$o]['txt'] = !$r[$i][$o]['txt']?co('main103'):$r[$i][$o]['txt'];
        $r[$i][$o]['date'] = !$r[$i][$o]['time']?" -- ":dgmdate($r[$i][$o]['time'],'u');
      }
    }
    return $r;
  }
  function see_cast(){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='2' ORDER BY id DESC LIMIT 40");
    
      for($o=0;$o<count($r);$o++){
        $r[$o]['date'] = strip_tags(!$r[$o]['time']?" -- ":dgmdate($r[$o]['time'],'u'));
      }
    
    return $r;
  }
  function see_thef(){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='3' ORDER BY id DESC LIMIT 33");
    
      for($o=0;$o<count($r);$o++){
        $r[$o]['date'] = strip_tags(!$r[$o]['time']?" -- ":dgmdate($r[$o]['time'],'u'));
      }
    
    return $r;
  }
  function see_news(){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_news')." WHERE type='1' ORDER BY id DESC LIMIT 10");
    for($o=0;$o<count($r);$o++){
      $r[$o]['txt'] = !$r[$o]['txt']?co('main103'):$r[$o]['txt'];
      $r[$o]['date'] = !$r[$o]['time']?" -- ":dgmdate($r[$o]['time'],'u');
    }
    if(count($r)==0){
      $r[0]['txt'] = !$r[0]['txt']?co('main103'):$r[0]['txt'];
      $r[0]['date'] = !$r[0]['time']?" -- ":dgmdate($r[0]['time'],'u');
    }
    return $r;
  }
}
//----��Ʒ������----
class prize {
  function table_see(){
    global $_G;
    $db_ptab = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize'));
    for($i=0;$i<count($db_ptab);$i++){ 
      if($db_ptab[$i]['c_id']==1){
        $db_ptab[$i]['c_name'] = co('main104');
      }elseif($db_ptab[$i]['c_id']==2){
        $db_ptab[$i]['c_name'] = co('main105');
      }elseif($db_ptab[$i]['c_id']==3){
        $db_ptab[$i]['c_name'] = co('main106');
      }elseif($db_ptab[$i]['c_id']==4){
        $db_ptab[$i]['c_name'] = co('main107');
      }else{
        $db_ptab[$i]['c_name'] = co('main108');
      }
      if($db_ptab[$i]['type']==1){
        $db_ptab[$i]['type_name'] = co('main109');
      }elseif($db_ptab[$i]['type']==2){
        $db_ptab[$i]['type_name'] = co('main110');
      }elseif($db_ptab[$i]['type']==3){
        $db_ptab[$i]['type_name'] = co('main111');
      }elseif($db_ptab[$i]['type']==4){
        $db_ptab[$i]['type_name'] = co('main112');
      }else{
        $db_ptab[$i]['type_name'] = co('main113');
      }
      
      if($db_ptab[$i]['inve']<0){
        $db_ptab[$i]['inve_txt'] = co('main144');
      }elseif($db_ptab[$i]['inve']==0){
        $db_ptab[$i]['inve_txt'] = "<b style='color:#f00;font-size:16px'>0</b>";
      }else{
        $db_ptab[$i]['inve_txt'] = "<span style='color:#f60;font-size:14px'>".$db_ptab[$i]['inve']."</span>";
      }
      
      if($db_ptab[$i]['type']=="1"){  //��̳����
        $extid = $db_ptab[$i]['proj'];
        $extname = $_G['setting']['extcredits'][$extid]['title'];
        $db_ptab[$i]['proj'] = $extname;
      }
      elseif($db_ptab[$i]['type']=="2"){  //����ڻ���
        if($db_ptab[$i]['proj']=='k'){
          $db_ptab[$i]['proj'] = co('main114');
        }elseif($db_ptab[$i]['proj']=='lock_exp'){
          $db_ptab[$i]['proj'] = co('main115');
        }elseif($db_ptab[$i]['proj']=='cast_exp'){
          $db_ptab[$i]['proj'] = co('main116');
        }elseif($db_ptab[$i]['proj']=='thef_exp'){
          $db_ptab[$i]['proj'] = co('main117');
        }
      }
      elseif($db_ptab[$i]['type']=="3"){  //ʵ�� ��ȡ��ʽ
        if($db_ptab[$i]['proj']=='1'){
          $db_ptab[$i]['proj'] = co('main118');
        }elseif($db_ptab[$i]['proj']=='2'){
          $db_ptab[$i]['proj'] = co('main119');
        }
      }
    }
    if(count($db_ptab)<=0){
      $db_ptab[0]['id'] = 0;
      $db_ptab[0]['name'] = co('main120');
      $db_ptab[0]['c_id'] = "--";
      $db_ptab[0]['c_name'] = "--";
      $db_ptab[0]['lv'] = "--";
      $db_ptab[0]['prob'] = "--";
      $db_ptab[0]['txt'] = "--";
      $db_ptab[0]['ico'] = "source/plugin/zgxsh_chest/template/img/prize/w/w.png";
      $db_ptab[0]['type'] = "--";
      $db_ptab[0]['proj'] = "--";
      $db_ptab[0]['min'] = "--";
      $db_ptab[0]['max'] = "--";
      $db_ptab[0]['cond'] = "--";
      $db_ptab[0]['price'] = "--";
      $db_ptab[0]['inve'] = "--";
    }
    $r = $db_ptab;
    return $r;
  }
  function index_see(){
    $r[1] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE c_id='1' AND inve!='0' ORDER BY lv DESC LIMIT 10");
    $r[2] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE c_id='2' AND inve!='0' ORDER BY lv DESC LIMIT 10");
    $r[3] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE c_id='3' AND inve!='0' ORDER BY lv DESC LIMIT 10");
    $r[4] = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE c_id='4' AND inve!='0' ORDER BY lv DESC LIMIT 10");
    
    for($i=1;$i<=4;$i++){
      for($o=0;$o<10;$o++){
        $r[$i][$o]['lv'] = !$r[$i][$o]['lv']?" -- ":$r[$i][$o]['lv'];
        $r[$i][$o]['name'] = !$r[$i][$o]['name']?" -- ":$r[$i][$o]['name'];
        $r[$i][$o]['min'] = !$r[$i][$o]['min']?" -- ":$r[$i][$o]['min'];
        $r[$i][$o]['max'] = !$r[$i][$o]['max']?" -- ":$r[$i][$o]['max'];
      }
    }
    
    return $r;
  }
  function single_see($id){
    global $_G;
    
    $r = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE id='".$id."'");
    
    if($r['c_id']==1){
      $r['c_name'] = co('main104');
    }elseif($r['c_id']==2){
      $r['c_name'] = co('main105');
    }elseif($r['c_id']==3){
      $r['c_name'] = co('main106');
    }elseif($r['c_id']==4){
      $r['c_name'] = co('main107');
    }
    

    
    if($r['type']==1){
      $r['type_name'] = co('main109');
      $r['proj_name'] = $_G['setting']['extcredits'][$r['proj']]['title'];
    }elseif($r['type']==2){
      $r['type_name'] = co('main121');
      if($r['proj']=='k'){
        $r['proj_name'] = co('main114');
      }elseif($r['proj']=='lock_exp'){
        $r['proj_name'] = co('main115');
      }elseif($r['proj']=='cast_exp'){
        $r['proj_name'] = co('main116');
      }elseif($r['proj']=='thef_exp'){
        $r['proj_name'] = co('main117');
      }else{
        $r['proj_name'] = co('main113');
      }
    }elseif($r['type']==3){
      $r['type_name'] = co('main111');
      if($r['proj']==1){
        $r['proj_name'] = co('main118');
      }elseif($r['proj']==2){
        $r['proj_name'] = co('main119');
      }else{
        $r['proj_name'] = co('main113');
      }
    }elseif($r['type']==4){
      $r['type_name'] = co('main122');
      $r['proj_name'] = co('main123');
    }
    
    $r['inve'] = $r['inve']<0?co('main124'):$r['inve'];
    
    return $r;
  }
  
  function add($ls){
    //��ֵ intval() ���� daddslashes()
    $in = array(
      'name' => daddslashes($ls['name']),   //��Ʒ����
      'c_id' => intval($ls['c_id']),   //��������
      'lv' => intval($ls['lv']),     //���Ӽ���
      'prob' => intval($ls['prob']),   //��������
      'txt' => daddslashes($ls['txt']),    //��Ʒ����
      'type' => intval($ls['type']),   //��Ʒ����
      'min' => intval($ls['min']),    //�н���С����
      'max' => intval($ls['max']),    //�н��������
      'cond' => intval($ls['cond']),   //�������ٿɳ���
      'price' => intval($ls['price']),  //��ֵ
    );
    DB::insert('zgxsh_chest_prize',$in);
    return true;
  }
  function edit($ls){
    $up = array(
      'name' => daddslashes($ls['name']),   //��Ʒ����
      'c_id' => intval($ls['c_id']),   //��������
      'lv' => intval($ls['lv']),     //���Ӽ���
      'prob' => intval($ls['prob']),   //��������
      'txt' => daddslashes($ls['txt']),    //��Ʒ����
      'type' => intval($ls['type']),   //��Ʒ����
      'min' => intval($ls['min']),    //�н���С����
      'max' => intval($ls['max']),    //�н��������
      'cond' => intval($ls['cond']),   //�������ٿɳ���
      'price' => intval($ls['price']),  //��ֵ
      'proj' => '',  //��Ʒ��Ŀ
      'inve' => 0,   //���
    );
    DB::update('zgxsh_chest_prize',$up,array('id'=>$ls['bh']));
    return true;
  }
  function del($ls){
    DB::delete('zgxsh_chest_prize',array('id'=>$ls['bh']),1);
    return true;
  }
  function read($id){
    $db_priz = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_prize')." WHERE id='".$id."'");
    if(!$db_priz){
      prompt(co('main125'));
    }
    return $db_priz;
  }
  function setup($ls){
    //��ֵ intval() ���� daddslashes()
    $up = array(
      'inve' => intval($ls['inve']),   //���
      'min' => intval($ls['min']),   
      'max' => intval($ls['max']),   
      'price' => intval($ls['price']),  //��ֵ   
      'ico' => daddslashes($ls['ico']),   
      'proj' => daddslashes($ls['proj']),  //��Ʒ��Ŀ
    );
    DB::update('zgxsh_chest_prize',$up,array('id'=>$ls['bh']));
    return true;
  }
  
  function the_awards($prize,$db_user,$db_c){  //�佱
    global $_G;
    global $_TRC;
    
    $news_type = $prize['c_id']+3;  //��������
    
    if($prize['inve']>0){  //���ģʽ
      $prize['max'] = $prize['max']>$prize['inve']?$prize['inve']:$prize['max'];  //�����
      $prize['min'] = $prize['min']>$prize['max']?$prize['max']:$prize['min'];  //��С���
    }
    
    $prize['get'] = rand($prize['min'],$prize['max']);  //�������
    $prize['inve'] = $prize['inve']>0?$prize['inve']-$prize['get']:$prize['inve'];  //�п������
    
    //������
    $up = array(
      'inve' => intval($prize['inve']),
    );
    DB::update('zgxsh_chest_prize',$up,array('id'=>$prize['id']));
    
    $price = $prize['get']*$prize['price'];  //��Ʒ��ֵ
    
    //prompt($prize['type']);
    
    if($prize['type']==1){  //��վ����
      //������ʾ
      $r = co('main126')." [".$prize['get']."] ".$_G['setting']['extcredits'][$prize['proj']]['title'];
      //����
      integral($db_user['uid'],$prize['get'],$prize['proj'],$_TRC['p_name'],co('main58')." [".$db_c['name']."] ");
      //����
      news::add($news_type,q_name($db_user['uid']).$r);
      //���ٻ���
      profit::add(-$price,co('main127')."[".$db_c['name']."]".$prize['get'].$_G['setting']['extcredits'][$prize['proj']]['title']);
      //�н���¼
      winrec::add($db_user['uid'],$prize);
    }
    elseif($prize['type']==2){  //�ڲ�����
      if($prize['proj']=='k'){
        $prize['proj_name'] = co('main114');
      }elseif($prize['proj']=='lock_exp'){
        $prize['proj_name'] = co('main115');
      }elseif($prize['proj']=='cast_exp'){
        $prize['proj_name'] = co('main116');
      }elseif($prize['proj']=='thef_exp'){
        $prize['proj_name'] = co('main117');
      }
      //������ʾ
      $r = co('main126')." [".$prize['get']."] ".$prize['proj_name'];
      //����
      db_user::attr_edit($db_user['uid'],$prize['proj'],$prize['get']);
      news::add($news_type,q_name($db_user['uid']).$r);
      profit::add(-$price,co('main127')."[".$db_c['name']."]".$prize['get'].$prize['proj_name']);
      winrec::add($db_user['uid'],$prize);      
    }
    elseif($prize['type']==3){  //ʵ����Ʒ
      //������ʾ
      $r = co('main126')." [".$prize['get']."] ".co('main128').$prize['name'];
      news::add($news_type,q_name($db_user['uid']).$r);
      profit::add(-$price,co('main127')."[".$db_c['name']."]".$prize['get'].$prize['proj_name']);
      winrec::add($db_user['uid'],$prize);
    }
    elseif($prize['type']==4){  //�ⲿ����
      //������ʾ
      $r = co('main126')." [".$prize['get']."] ".co('main129').$prize['name'];
      //�жϷִ���
      $prize['proj'] = explode('|',$prize['proj']);
      if(!DB::fetch(DB::query("SHOW TABLES LIKE '".DB::table($prize['proj'][0])."'"))){
        $r = co('main131');
        integral($db_user['uid'],1,$_TRC['ext_'.$prize['c_id']],$_TRC['p_name'],co('main130'));
        notice($db_user['uid'],$_TRC['p_name'],$r);
        return $r;
      }elseif(!DB::fetch_first("SHOW COLUMNS FROM ".DB::table($prize['proj'][0])." LIKE '".$prize['proj'][1]."'")){
        $r = co('main132');
        integral($db_user['uid'],1,$_TRC['ext_'.$prize['c_id']],$_TRC['p_name'],co('main130'));
        notice($db_user['uid'],$_TRC['p_name'],$r);
        return $r;
      }elseif(!DB::fetch_first("SHOW COLUMNS FROM ".DB::table($prize['proj'][0])." LIKE 'uid'")){
        $r = co('main133');
        integral($db_user['uid'],1,$_TRC['ext_'.$prize['c_id']],$_TRC['p_name'],co('main130'));
        notice($db_user['uid'],$_TRC['p_name'],$r);
        return $r;
      }
      //����
      $type4 = DB::result_first("SELECT ".$prize['proj'][1]." FROM ".DB::table($prize['proj'][0])." WHERE uid='".$db_user['uid']."'");
      $type4 += $prize['get'];
      DB::update($prize['proj'][0],array($prize['proj'][1]=>$type4),array('uid'=>$db_user['uid']));
      //���ŵȲ���
      news::add($news_type,q_name($db_user['uid']).$r);
      profit::add(-$price,co('main127')."[".$db_c['name']."]".$prize['get'].$prize['proj_name']);
      winrec::add($db_user['uid'],$prize);
    }
    return $r;
  }
}
//----������----
class setup {
  function edit($ls){
    $up = array(
      'synt_sr_sk' => $ls['synt_sr_sk'], //��Կ�׶���ɹ���
      'synt_sr_gk' => $ls['synt_sr_gk'], //��Կ�׶���ɹ���
      'synt_sr_ik' => $ls['synt_sr_ik'], //����������ɹ���
      'synt_sr_astr' => $ls['synt_sr_astr'], //����ѧ���ڸ�����
      'mate_sk' => $ls['mate_sk'], //��Կ�׺ϳ�����ͭԿ��
      'mate_gk' => $ls['mate_gk'], //��Կ�׺ϳ�������Կ��
      'mate_ik_1' => $ls['mate_ik_1'], //�������ϳ������Կ��
      'mate_ik_2' => $ls['mate_ik_2'], //�������ϳ�������Կ��
      'mate_ik_3' => $ls['mate_ik_3'], //�������ϳ�����ͭԿ��
      'money_sk' => $ls['money_sk'], //��Կ�׺ϳ��������
      'money_gk' => $ls['money_gk'], //��Կ�׺ϳ��������
      'money_ik' => $ls['money_ik'], //�������ϳ��������
      'stolen_time' => $ls['stolen_time'], //��ΪĿ��������������
      'stol_sr_ck' => $ls['stol_sr_ck'], //ͭԿ��͵�Գɹ���
      'stol_sr_sk' => $ls['stol_sr_sk'], //��Կ��͵�Գɹ���
      'stol_sr_gk' => $ls['stol_sr_gk'], //��Կ��͵�Գɹ���
      'stol_sr_ik' => $ls['stol_sr_ik'], //������͵�Գɹ���
      'stol_mo_ck' => $ls['stol_mo_ck'], //ͭԿ�׵�����Ӷ�ɱ�
      'stol_mo_sk' => $ls['stol_mo_sk'], //��Կ�׵�����Ӷ�ɱ�
      'stol_mo_gk' => $ls['stol_mo_gk'], //��Կ�׵�����Ӷ�ɱ�
      'stol_mo_ik' => $ls['stol_mo_ik'], //������������Ӷ�ɱ�
      'succ_ck' => $ls['succ_ck'], //ͭԿ�ױص�ָ��
      'succ_sk' => $ls['succ_sk'], //��Կ�ױص�ָ��
      'succ_gk' => $ls['succ_gk'], //��Կ�ױص�ָ��
      'succ_ik' => $ls['succ_ik'], //�������ص�ָ��
      'police_see' => $ls['police_see'], //Ѳ�����жȻ���
      'security_time' => $ls['security_time'], //�ٴ��ϸ���������
      'sing_v' => $ls['sing_v'], //ǩ�����ͭԿ������
    );
    DB::update('zgxsh_chest_setup',$up);
    $r = DB::result_first("SELECT SUM(v) FROM ".DB::table('zgxsh_chest_profit'));
    return $r;
  } 
}
//----��������----
class profit {   
  function add($v,$txt){
    if(abs($v)==0){
      return false;  //û��������Ϊ��ֵΪ0
    }
    $in = array(
      'v' => intval($v),
      'txt' => daddslashes($txt),
      'time' => time(),
    );
    DB::insert('zgxsh_chest_profit',$in);
    return true;
  }
  function earsta_list(){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_profit')." ORDER BY id DESC LIMIT 40");
    for($i=0;$i<count($r);$i++){
      $r[$i]['date'] = dgmdate($r[$i]['time'],'u');
      $r[$i]['v'] = symbol($r[$i]['v']);
    }
    return $r;
  }
  function earsta_sum(){
    $r = DB::result_first("SELECT SUM(v) FROM ".DB::table('zgxsh_chest_profit'));
    return $r;
  } 
}
//----�񽱼�¼����----
class winrec {
  function add($uid,$prize){  //�н��� ��Ʒ����
    
    global $_G;
    
    if($prize['type']==1){
      $prize['type_name'] = co('main109');
      $prize['proj_name'] = $_G['setting']['extcredits'][$prize['proj']]['title'];
      $prize['the_goods'] = 0;
    }elseif($prize['type']==2){
      $prize['type_name'] = co('main121');
      if($prize['proj']=='k'){
        $prize['proj_name'] = co('main114');
      }elseif($prize['proj']=='lock_exp'){
        $prize['proj_name'] = co('main115');
      }elseif($prize['proj']=='cast_exp'){
        $prize['proj_name'] = co('main116');
      }elseif($prize['proj']=='thef_exp'){
        $prize['proj_name'] = co('main117');
      }else{
        $prize['proj_name'] = co('main113');
      }
      $prize['the_goods'] = 0;
    }elseif($prize['type']==3){
      $prize['type_name'] = co('main111');
      if($prize['proj']==1){
        $prize['proj_name'] = co('main118');
      }elseif($prize['proj']==2){
        $prize['proj_name'] = co('main119');
      }else{
        $prize['proj_name'] = co('main113');
      }
      $prize['the_goods'] = 1;
    }elseif($prize['type']==4){
      $prize['type_name'] = co('main122');
      $prize['proj_name'] = co('main123');
      $prize['the_goods'] = 0;
    }
    

    
    $prize['type_proj'] = $prize['type_name'].$prize['proj_name'];
    $prize['price_sum'] = $prize['get']*$prize['price'];
    
    $in = array(
      'uid' => $uid,
      'name' => $prize['name'],
      'type_proj' => $prize['type_proj'],
      'number' => $prize['get'],
      'price_sum' => $prize['price_sum'],
      'ico' => $prize['ico'],
      'the_goods' => $prize['the_goods'],
      'time' => time(),
    );
    
    DB::insert('zgxsh_chest_winrec',$in);
    
    return true;
  }
  function winrec_list($uid){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_winrec')." WHERE uid='".$uid."' ORDER BY id DESC LIMIT 40");
    for($i=0;$i<count($r);$i++){
      $r[$i]['date'] = dgmdate($r[$i]['time']);
      if($r[$i]['the_goods']==0){
        $r[$i]['the_goods_name'] = co('main134');
      }elseif($r[$i]['the_goods']==1){
        $r[$i]['the_goods_name'] = co('main135');
      }elseif($r[$i]['the_goods']==2){
        $r[$i]['the_goods_name'] = co('main136');
      }elseif($r[$i]['the_goods']==3){
        $r[$i]['the_goods_name'] = co('main137');
      }
    }
    return $r;
  }
  function winrec_deal($uid){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_winrec')." WHERE uid='".$uid."' AND the_goods!='0'");
    for($i=0;$i<count($r);$i++){
      $r[$i]['date'] = dgmdate($r[$i]['time']);
      if($r[$i]['the_goods']==0){
        $r[$i]['the_goods_name'] = co('main134');
      }elseif($r[$i]['the_goods']==1){
        $r[$i]['the_goods_name'] = co('main135');
      }elseif($r[$i]['the_goods']==2){
        $r[$i]['the_goods_name'] = co('main136');
      }elseif($r[$i]['the_goods']==3){
        $r[$i]['the_goods_name'] = co('main137');
      }
    }
    return $r;
  }
  function winrec_delive(){
    $r = DB::fetch_all("SELECT * FROM ".DB::table('zgxsh_chest_winrec')." WHERE the_goods != '0' ORDER BY the_goods ASC");
    for($i=0;$i<count($r);$i++){
      $r[$i]['date'] = dgmdate($r[$i]['time']);
      if($r[$i]['the_goods']==0){
        $r[$i]['the_goods_name'] = co('main134');
      }elseif($r[$i]['the_goods']==1){
        $r[$i]['the_goods_name'] = co('main135');
      }elseif($r[$i]['the_goods']==2){
        $r[$i]['the_goods_name'] = co('main136');
      }elseif($r[$i]['the_goods']==3){
        $r[$i]['the_goods_name'] = co('main137');
      }
    }
    return $r;
  }
  function ejaculation($ls){
    $db_win = DB::fetch_first("SELECT * FROM ".DB::table('zgxsh_chest_winrec')." WHERE id = '".$ls['bh']."'");
    //����Ϣ
    notice($db_win['uid'],co('main138',array('1'=>$_TRC['pay_url'])),co('main139',array('1'=>$_TRC['pay_url'])).$db_win['name'].co('main140').$ls['order_no']);
    $up = array(
      'order_no' => $ls['order_no'],
      'the_goods' => 2
    );
    DB::update('zgxsh_chest_winrec',$up,array('id'=>$ls['bh']));
    return true;
  }
  function the_goods($ls){
    $up = array(
      'the_goods' => 3
    );
    DB::update('zgxsh_chest_winrec',$up,array('id'=>$ls['bh']));
    return true;
  }
}
//From: Dism_taobao-com
?>