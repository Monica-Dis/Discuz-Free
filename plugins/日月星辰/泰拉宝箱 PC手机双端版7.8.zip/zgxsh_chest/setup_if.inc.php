<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

if($_GET['op'] == "setup_user"){
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  security::txt_en($ls['phone'],co('setup01'),10,12);
  security::txt_en($ls['address_u'],co('setup02'),1,255);
  security::txt_en($ls['consignee'],co('setup03'),1,255);
  $ls['uid'] = $_G['uid'];
  
  db_user::setup($ls);
  
  prompt(co('setup04'));
}
elseif($_GET['op'] == "setup_system"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  security::hash_if();
	$ls = security::filter($_GET);
  
  security::int_if($ls['synt_sr_sk'],co('setup04'),0,1,0,0,0,100);
  security::int_if($ls['synt_sr_gk'],co('setup05'),0,1,0,0,0,100);
  security::int_if($ls['synt_sr_ik'],co('setup06'),0,1,0,0,0,100);
  security::int_if($ls['synt_sr_astr'],co('setup07'),0,1,0,0,0,100);
  
  security::int_if($ls['mate_sk'],co('setup08'));
  security::int_if($ls['mate_gk'],co('setup09'));
  security::int_if($ls['mate_ik_1'],co('setup10'));
  security::int_if($ls['mate_ik_2'],co('setup11'));
  security::int_if($ls['mate_ik_3'],co('setup12'));
  
  security::int_if($ls['money_sk'],co('setup13'));
  security::int_if($ls['money_gk'],co('setup14'));
  security::int_if($ls['money_ik'],co('setup15'));
  
  security::int_if($ls['stolen_time'],co('setup16'));
  
  security::int_if($ls['stol_sr_ck'],co('setup17'),0,1,0,0,0,100);
  security::int_if($ls['stol_sr_sk'],co('setup18'),0,1,0,0,0,100);
  security::int_if($ls['stol_sr_gk'],co('setup19'),0,1,0,0,0,100);
  security::int_if($ls['stol_sr_ik'],co('setup20'),0,1,0,0,0,100);
  
  security::int_if($ls['stol_mo_ck'],co('setup21'));
  security::int_if($ls['stol_mo_sk'],co('setup22'));
  security::int_if($ls['stol_mo_gk'],co('setup23'));
  security::int_if($ls['stol_mo_ik'],co('setup24'));
  security::int_if($ls['succ_ck'],co('setup25'));
  security::int_if($ls['succ_sk'],co('setup26'));
  security::int_if($ls['succ_gk'],co('setup27'));
  security::int_if($ls['succ_ik'],co('setup28'));
  
  security::int_if($ls['police_see'],co('setup29'));
  security::int_if($ls['security_time'],co('setup30'));
  security::int_if($ls['sing_v'],co('setup31'));
  
  setup::edit($ls);
  
  prompt(co('setup32'));
}
elseif($_GET['op'] == "img_del"){
  
  if($_G['uid']!=1){
    prompt(co('no_admin'),"location='plugin.php?id=zgxsh_chest:index'");
  }
  
  if(!$_TRC['ico_del']){
    prompt(co('setup33',$co),"location='plugin.php?id=zgxsh_chest:setup'");
  }  
  ico_del();
}

system_end();
?>