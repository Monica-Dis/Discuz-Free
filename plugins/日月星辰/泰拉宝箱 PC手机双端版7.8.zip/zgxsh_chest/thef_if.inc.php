<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'module/main.php';

if($_GET['op'] == "stealing"){
	$ls = security::filter($_GET);
  
  $db_user = db_user::survive();  //�û�����
  $db_boss = thef::survive();  //BOSS����
  
  if($db_boss['false']){
    prompt(co('thef01'));
  }
  
  //�ж�BOSSԿ�״���
  if($ls['bh']==1){  
    if($db_boss['ext_1']<=0){
      prompt(co('thef02'));
    }
  }elseif($ls['bh']==2){
    if($db_boss['ext_2']<=0){
      prompt(co('thef03'));
    }
  }elseif($ls['bh']==3){
    if($db_boss['ext_3']<=0){
      prompt(co('thef04'));
    }
  }elseif($ls['bh']==4){
    if($db_boss['ext_4']<=0){
      prompt(co('thef05'));
    }
  }
  
  //�ۼ���Ӷ���� ���ӻ���  
  if($ls['bh']==1){  
    integral($_G['uid'],-$_TRC['setup']['stol_mo_ck'],$_TRC['ext_sys'],$_TRC['p_name'],co('thef07'));
    $ls['k_name'] = co('thef08');
    profit::add($_TRC['setup']['stol_mo_ck'],co('thef09'));
    $ls['fy'] = $_TRC['setup']['stol_mo_ck'];
  }elseif($ls['bh']==2){
    integral($_G['uid'],-$_TRC['setup']['stol_mo_sk'],$_TRC['ext_sys'],$_TRC['p_name'],co('thef10'));
    $ls['k_name'] = co('thef11');
    profit::add($_TRC['setup']['stol_mo_sk'],co('thef12'));
    $ls['fy'] = $_TRC['setup']['stol_mo_sk'];
  }elseif($ls['bh']==3){
    integral($_G['uid'],-$_TRC['setup']['stol_mo_gk'],$_TRC['ext_sys'],$_TRC['p_name'],co('thef13'));
    $ls['k_name'] = co('thef14');
    profit::add($_TRC['setup']['stol_mo_gk'],co('thef15'));
    $ls['fy'] = $_TRC['setup']['stol_mo_gk'];
  }elseif($ls['bh']==4){
    integral($_G['uid'],-$_TRC['setup']['stol_mo_ik'],$_TRC['ext_sys'],$_TRC['p_name'],co('thef16'));
    $ls['k_name'] = co('thef17');
    profit::add($_TRC['setup']['stol_mo_ik'],co('thef18'));
    $ls['fy'] = $_TRC['setup']['stol_mo_ik'];
  }else{
    prompt(co('thef19'));
  }
  //���Ӿ���
  db_user::attr_edit($_G['uid'],'thef_exp',$ls['bh']);  //����͵�Գɹ���
  $ls['sr'] = rand(1,100);  //�������
  
  if($ls['bh']==1){  
    $ls['nd'] = $_TRC['setup']['stol_sr_ck'];
    if($ls['sr']<$_TRC['setup']['stol_sr_ck']+$db_user['thef_lv']){
      $ls['sr_t'] = true;
    }
  }elseif($ls['bh']==2){
    $ls['nd'] = $_TRC['setup']['stol_sr_sk'];
    if($ls['sr']<$_TRC['setup']['stol_sr_sk']+$db_user['thef_lv']){
      $ls['sr_t'] = true;
    }
  }elseif($ls['bh']==3){
    $ls['nd'] = $_TRC['setup']['stol_sr_gk'];
    if($ls['sr']<$_TRC['setup']['stol_sr_gk']+$db_user['thef_lv']){
      $ls['sr_t'] = true;
    }
  }elseif($ls['bh']==4){
    $ls['nd'] = $_TRC['setup']['stol_sr_ik'];
    if($ls['sr']<$_TRC['setup']['stol_sr_ik']+$db_user['thef_lv']){
      $ls['sr_t'] = true;
    }
  }
  if(!$ls['sr_t']){  //����ʧ��ʱ�����
    if($ls['bh']==1){  
      if($db_boss['c_must']>=$_TRC['setup']['succ_ck']){
        $ls['sr_t'] = true;
        $ls['must_t'] = co('thef20');
        thef::must_empty('c_must');
        news::add(3,$ls['must_t']);  //�����ͷ�����
      }
    }elseif($ls['bh']==2){
      if($db_boss['s_must']>=$_TRC['setup']['succ_sk']){
        $ls['sr_t'] = true;
        $ls['must_t'] = co('thef21');
        thef::must_empty('s_must');
        news::add(3,$ls['must_t']);  //�����ͷ�����
      }
    }elseif($ls['bh']==3){
      if($db_boss['g_must']>=$_TRC['setup']['succ_gk']){
        $ls['sr_t'] = true;
        $ls['must_t'] = co('thef22');
        thef::must_empty('g_must');
        news::add(3,$ls['must_t']);  //�����ͷ�����
      }
    }elseif($ls['bh']==4){
      if($db_boss['i_must']>=$_TRC['setup']['succ_ik']){
        $ls['sr_t'] = true;
        $ls['must_t'] = co('thef23');
        thef::must_empty('i_must');
        news::add(3,$ls['must_t']);  //�����ͷ�����
      }
    }
  }
  //���ӱ���ֵ
  thef::alarm_add($ls['bh']);
  //����ŭ��ֵ
  if(!$ls['sr_t']){  //û�ɹ���ŭ��
    if($ls['bh']==1){  
      thef::must_add("c_must",1);
    }elseif($ls['bh']==2){
      thef::must_add("s_must",1);
    }elseif($ls['bh']==3){
      thef::must_add("g_must",1);
    }elseif($ls['bh']==4){
      thef::must_add("i_must",1);
    }
  }
  //�����ӦԿ��
  if($ls['sr_t']){
    if($ls['bh']==1){  
      integral($_G['uid'],1,$_TRC['ext_1'],$_TRC['p_name'],co('thef24'));
      integral($db_boss['uid'],-1,$_TRC['ext_1'],$_TRC['p_name'],co('thef26'));
      notice($db_boss['uid'],$_TRC['p_name'],q_name($_G['uid']).co('thef20'));
    }elseif($ls['bh']==2){
      integral($_G['uid'],1,$_TRC['ext_2'],$_TRC['p_name'],co('thef24'));
      integral($db_boss['uid'],-1,$_TRC['ext_2'],$_TRC['p_name'],co('thef27'));
      notice($db_boss['uid'],$_TRC['p_name'],q_name($_G['uid']).co('thef20'));
    }elseif($ls['bh']==3){
      integral($_G['uid'],1,$_TRC['ext_3'],$_TRC['p_name'],co('thef24'));
      integral($db_boss['uid'],-1,$_TRC['ext_3'],$_TRC['p_name'],co('thef28'));
      notice($db_boss['uid'],$_TRC['p_name'],q_name($_G['uid']).co('thef20'));
    }elseif($ls['bh']==4){
      db_user::attr_edit($_G['uid'],'k',1);
      db_user::attr_edit($db_boss['uid'],'k',-1);
      notice($db_boss['uid'],$_TRC['p_name'],q_name($_G['uid']).co('thef29'));
      //�������а�����
      db_user::attr_edit($uid,'thef_n',1);
    }
  }
  //��������.
  $ls['news'] .= $ls['sr_t']?q_name($_G['uid']).co('thef30').q_name($db_boss['uid'])." ".$ls['k_name'].co('thef31'):q_name($_G['uid']).co('thef32').q_name($db_boss['uid']).$ls['k_name'].co('thef33');
  news::add(3,$ls['news']); 
  
  $ls['txt'] .= $ls['sr_t']?co('thef34'):co('thef35');
  $ls['txt'] .= $ls['must_t']?$ls['must_t']."<br>":"";
  $ls['txt'] .= co('thef36').$db_user['thef_lv']."<br>";
  $ls['txt'] .= co('thef37').$ls['nd']."<br>";
  $ls['txt'] .= $ls['sr_t']?co('thef38').$ls['k_name']."<br>":co('thef39')."<br>";
  $ls['txt'] .= co('thef40').$ls['fy'].$_G['setting']['extcredits'][$_TRC['ext_sys']]['title']."<br>";
  
  if($ls['sr_t']){
    $icon['icon'] = 1;
  }else{
    $icon['icon'] = 2;
  }
  
  prompt($ls['txt'],"location='plugin.php?id=zgxsh_chest:thef'",$icon);
}

system_end();
?>