<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'source/plugin/zgxsh_avatar/module/child/store.php';
require_once 'source/plugin/zgxsh_avatar/module/child/pack.php';

class mobileplugin_zgxsh_avatar {
  function avatar($value){
    global $_G;
    //print_r($value['param'][0]);
    //����
    $uid = $value['param'][0];
    $size = $value['param'][1];
    $returnsrc = $value['param'][2];
    $real = $value['param'][3];
    $static = $value['param'][4];
    $ucenterurl = $value['param'][5];
    static $staticavatar;
    if($staticavatar === null) {
      $staticavatar = $_G['setting']['avatarmethod'];
    }
    $ucenterurl = empty($ucenterurl) ? $_G['setting']['ucenterurl'] : $ucenterurl;
    
    // m_32 �ֻ���32�ߴ�
    $lss = explode("_",$size);
    if($lss[0]=="m"){
      $size_px = "width:".$lss[1]."px;height:".$lss[1]."px;";
    }elseif($size=="big"){
      $size_px = "width:"."200"."px;height:"."200"."px;";
    }elseif($size=="small"){
      $size_px = "width:"."48"."px;height:"."48"."px;";
    }else{
      $size_px = "width:"."120"."px;height:"."120"."px;";
    }
    
    $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
    $uid = abs(intval($uid));
    //�Զ���
    $userpack = userpack::see(" WHERE uid='".$uid."' AND state='1'");
    if($userpack){  //you
      $store = store::see(" WHERE id='".$userpack['a_id']."'");
      $store['img'];
      
      $rectifying = 100-$store['rectifying'];
      
      $hookavatar = '<div style="display: inline-block"><span style="position: relative;display: flex;justify-content:center;align-items:center;border-radius:4px;'.$size_px.'">
        <img style="position:absolute;padding:0px;border-radius:4px;width:'.$rectifying.'%;height:'.$rectifying.'%;" src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').'" />
        <img style="position:absolute;width: 100%;height:auto;background:rgba(0,0,0,0);border:0px;padding:0px;border-radius:4px;" src="'.$store['img'].'">
      </span></div>';
      
      $_G['hookavatar'] = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '') : $hookavatar;

      return;
    }
    //û��ͷ���ִ������
    if(!$staticavatar && !$static) {
      $_G['hookavatar'] = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '') : '<img style="'.$size_px.'" src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').'" />';
      return;
    } else {
      $uid = sprintf("%09d", $uid);
      $dir1 = substr($uid, 0, 3);
      $dir2 = substr($uid, 3, 2);
      $dir3 = substr($uid, 5, 2);
      $file = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
      $_G['hookavatar'] = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
      return;
    }
    //print_r($value['param']);
    $_G['hookavatar'] = "34232";
    return;
  }
}
//From: Dism_taobao-com
?>