<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//zgxsh_avatar ͷ����̳�
include 'module/main.php';

if(!in_array($_G['uid'],$_TRC['admin_id'])){
  prompt(co('setup01'),"location='plugin.php?id=zgxsh_avatar:index'",array('icon'=>1));
}

userpack::durable($_G['uid']);

$user = user::init();

if($_GET['op']=="setup_add"){
	include template('zgxsh_avatar:setup/setup_add');
  exit();
}
elseif($_GET['op']=="setup_add_sub"){
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
	security::txt_ch($ls['name'],co('setup02'),0,1,16);
	security::txt_ch($ls['txt'],co('setup03'),0,0,20);
  
  $ls['num'] = intval($ls['num']);
  $ls['time'] = intval($ls['time']);
  $ls['prob'] = intval($ls['prob']);
  $ls['prob'] = $ls['prob']<1?1:$ls['prob'];
  $ls['prob'] = $ls['prob']>10000?10000:$ls['prob'];
  
  if(!$ls['img']){
    prompt(co('setup04'),"location='plugin.php?id=zgxsh_avatar:setup'");
  }
  
  store::add($ls);
    
  prompt(co('setup05'),"location='plugin.php?id=zgxsh_avatar:setup'",array('icon'=>1));
}

elseif($_GET['op']=="setup_edit"){
  
  $ls = security::filter($_GET);
  
  $store = store::see(" WHERE id='".$ls['bh']."'");

    if($store['draw_s']){
      $draw_s_k = "checked";
    }
    if($store['debr_s']){
      $debr_s_k = "checked";
    }
    if($store['state']){
      $state_k = "checked";
    }


	include template('zgxsh_avatar:setup/setup_edit');
  exit();
}
elseif($_GET['op']=="setup_edit_sub"){
  security::hash_if();  //formhash
	$ls = security::filter($_GET);
  
	security::txt_ch($ls['name'],co('setup02'),0,1,16);
	security::txt_ch($ls['txt'],co('setup03'),0,0,20);
	security::int_if($ls['bh'],co('setup07'));
  
  $ls['num'] = intval($ls['num']);
  $ls['time'] = intval($ls['time']);
  $ls['prob'] = intval($ls['prob']);
  $ls['prob'] = $ls['prob']<1?1:$ls['prob'];
  $ls['prob'] = $ls['prob']>10000?10000:$ls['prob'];
  
  if(!$ls['img']){
    prompt(co('setup04'),"location='plugin.php?id=zgxsh_avatar:setup'");
  }
  
  $up = array(
    'img' => $ls['img'],
    'name' => $ls['name'],
    'txt' => $ls['txt'],
    'rectifying' => $ls['rectifying'],
    'fee_s' => $ls['fee_s'],
    'fee_b' => $ls['fee_b'],
    'fee_d' => $ls['fee_d'],
    'num' => $ls['num'],
    'time' => $ls['time'],
    'prob' => $ls['prob'],
    'draw_s' => $ls['draw_s'],
    'debr_s' => $ls['debr_s'],
    'state' => $ls['state'],
  );
  
  store::edit(array('id'=>$ls['bh']),$up);
    
  prompt(co('setup08'),"location='plugin.php?id=zgxsh_avatar:setup'",array('icon'=>1));
}


elseif($_GET['op']=="setup_del"){
  security::hash_if(1);  //formhash
  $ls = security::filter($_GET);
  
  store::del(array('id'=>$ls['bh']));

	prompt(co('setup09'),"location='plugin.php?id=zgxsh_avatar:setup'",array('icon'=>1));
}


system_end(); /*dis'.'m.t'.'ao'.'bao.com*/
?>