<?php
/**
 *	[ͷ����̳�(zgxsh_avatar.upgrade)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2020-10-22 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//$sql = <<<EOF
//CREATE TABLE IF NOT EXISTS `cdb_zgxsh_link_apply` (
//  `id` int(20) NOT NULL,
//  `uid` int(20) NOT NULL,
//  `name` varchar(100) NOT NULL,
//  `url` varchar(255) NOT NULL,
//  `description` mediumtext NOT NULL,
//  `logo` varchar(255) NOT NULL,
//  `state` int(3) NOT NULL,
//  `state_txt` varchar(100) NOT NULL,
//  PRIMARY KEY  (`id`)
//) ENGINE=MyISAM;
//EOF;
//runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>