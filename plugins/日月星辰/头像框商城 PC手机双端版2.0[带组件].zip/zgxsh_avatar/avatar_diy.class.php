<?php
/**
 *	[ͷ����̳�ϵͳ(zgxsh_avatar.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2020-9-20 16:39
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once 'source/plugin/zgxsh_avatar/module/child/store.php';
require_once 'source/plugin/zgxsh_avatar/module/child/pack.php';

class plugin_zgxsh_avatar {
  function avatar($value){
    global $_G;
    //print_r($value['param'][0]);
    //����
    $uid = $value['param'][0];
    $size = $value['param'][1];
    $returnsrc = $value['param'][2];
    $real = $value['param'][3];
    $static = $value['param'][4];
    $ucenterurl = $value['param'][5];
    static $staticavatar;
    if($staticavatar === null) {
      $staticavatar = $_G['setting']['avatarmethod'];
    }
    $ucenterurl = empty($ucenterurl) ? $_G['setting']['ucenterurl'] : $ucenterurl;
    
    // m_32 �ֻ���32�ߴ�
    $lss = explode("_",$size);
    if($lss[0]=="m"){
      $size_px = "width:".$lss[1]."px;height:".$lss[1]."px;";
    }elseif($size=="big"){
      $size_px = "width:"."200"."px;height:"."200"."px;";
    }elseif($size=="small"){
      $size_px = "width:"."48"."px;height:"."48"."px;";
    }else{
      $size_px = "width:"."120"."px;height:"."120"."px;";
    }
    
    $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
    $uid = abs(intval($uid));
    //�Զ���
    $userpack = userpack::see(" WHERE uid='".$uid."' AND state='1'");
    if($userpack){  //you
      $store = store::see(" WHERE id='".$userpack['a_id']."'");
      $store['rectifying'];
      
      $rectifying = 100-$store['rectifying'];
      
      $hookavatar = '<div style="display: inline-block"><span style="position: relative;margin: 5px 5px 8px;display: flex;justify-content:center;align-items:center;'.$size_px.'">
        <img style="position:absolute;padding:0px;width:'.$rectifying.'%;height:'.$rectifying.'%;" src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').'" />
        <img style="position:absolute;width: 100%;height:auto;background:rgba(0,0,0,0);border:0px;padding:0px;" src="'.$store['img'].'">
      </span></div>';
      
      $_G['hookavatar'] = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '') : $hookavatar;
      
      return;
    }
    //û��ͷ���ִ������
    if(!$staticavatar && !$static) {
      $_G['hookavatar'] = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '') : '<img src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').'" />';
      return;
    } else {
      $uid = sprintf("%09d", $uid);
      $dir1 = substr($uid, 0, 3);
      $dir2 = substr($uid, 3, 2);
      $dir3 = substr($uid, 5, 2);
      $file = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
      $_G['hookavatar'] = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
      return;
    }
    //print_r($value['param']);
    $_G['hookavatar'] = "34232";
    return;
  }
}


//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>