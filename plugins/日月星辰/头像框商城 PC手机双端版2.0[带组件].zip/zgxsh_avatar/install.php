<?php
/**
 *	[ͷ����̳�(zgxsh_avatar.install)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2020-10-22 10:12
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_pack`;
CREATE TABLE `cdb_zgxsh_avatar_pack` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `a_id` int(20) NOT NULL,
  `own_time` int(20) NOT NULL,
  `equ_time` int(20) NOT NULL,
  `rem_time` int(20) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index` USING BTREE (`uid`,`a_id`,`state`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_store`;
CREATE TABLE `cdb_zgxsh_avatar_store` (
  `id` int(20) NOT NULL auto_increment,
  `name` varchar(16) NOT NULL,
  `txt` varchar(20) NOT NULL,
  `img` varchar(100) NOT NULL,
  `rectifying` float(6,2) NOT NULL,
  `fee_s` int(20) NOT NULL,
  `fee_b` int(20) NOT NULL,
  `fee_d` int(20) NOT NULL,
  `num` int(4) NOT NULL default '-1',
  `time` int(20) NOT NULL default '-1',
  `prob` int(5) NOT NULL,
  `draw_s` int(1) NOT NULL default '0',
  `debr_s` int(1) NOT NULL default '0',
  `state` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index` USING BTREE (`draw_s`,`debr_s`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_user`;
CREATE TABLE `cdb_zgxsh_avatar_user` (
  `uid` int(20) NOT NULL,
  `frag` int(20) NOT NULL,
  `vip` int(1) NOT NULL,
  `vip_time` int(20) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('1', '$installlang[inst01]', '$installlang[inst07]', 'source/plugin/zgxsh_avatar/template/img/avatar/160359348830624.png', '0.00', '230', '1', '0', '0', '-1', '10000', '0', '0', '1');
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('2', '$installlang[inst02]', '$installlang[inst08]', 'source/plugin/zgxsh_avatar/template/img/avatar/160359439238122.png', '23.66', '450', '2', '1000', '8', '86400', '5000', '0', '1', '1');
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('3', '$installlang[inst03]', '$installlang[inst09]', 'source/plugin/zgxsh_avatar/template/img/avatar/160359608023650.png', '24.51', '500', '2', '0', '0', '36000000', '1', '0', '0', '1');
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('4', '$installlang[inst04]', '$installlang[inst10]', 'source/plugin/zgxsh_avatar/template/img/avatar/160360581983166.png', '27.42', '1000', '2', '0', '19', '864000', '1000', '0', '0', '1');
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('5', '$installlang[inst05]', '$installlang[inst11]', 'source/plugin/zgxsh_avatar/template/img/avatar/160360589421678.png', '27.68', '5000', '5', '0', '4', '-1', '1000', '0', '0', '1');
INSERT INTO `pre_zgxsh_avatar_store` VALUES ('6', '$installlang[inst06]', '$installlang[inst12]', 'source/plugin/zgxsh_avatar/template/img/avatar/160360597862484.png', '28.22', '1000', '1', '0', '0', '1864000', '1', '0', '0', '1');
EOF;
runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>