<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//zgxsh_avatar ͷ����̳�
include 'module/main.php';

userpack::durable($_G['uid']);

$user = user::init();

if($_GET['op']=="buy_avatar"){
  security::hash_if(1);  //formhash
	$ls = security::filter($_GET);
  
  $user = user::init();
  $store = store::see(" WHERE id='".$ls['bh']."'");
  $userpack = userpack::see(" WHERE a_id='".$store['id']."' AND uid='{$_G['uid']}'");

  if(!$store){
    prompt(co('inde05'),"location='plugin.php?id=zgxsh_avatar:index'");
  }
  if($store['num']==0){
    prompt(co('inde06'),"location='plugin.php?id=zgxsh_avatar:index'");
  }
  if($userpack){
    prompt(co('inde07'),"location='plugin.php?id=zgxsh_avatar:index'");
  }
  
  if($ls['cl']=="sys"){
    integral($_G['uid'],-$store['fee_s'],$_TRC['sys_ext'],$_TRC['p_name'],co('inde08').$store['name']);
  }elseif($ls['cl']=="lux"){
    integral($_G['uid'],-$store['fee_b'],$_TRC['lux_ext'],$_TRC['p_name'],co('inde08').$store['name']);
  }elseif($ls['cl']=="fra"){
    if($user['frag']<=$store['fee_d']){
      prompt(co('inde09'),"location='plugin.php?id=zgxsh_avatar:index'");
    }
    $user['frag'] -= $store['fee_d'];
    user::edit(array('uid'=>$_G['uid']),array('frag'=>$user['frag']));
  }
  
  $ls['own_time'] = $store['time'];
  
  if($store['num']>0){
    store::math($store['id'], 'num', -1);
  }
  
  userpack::add($ls);
  
  prompt(co('inde10'),"location='plugin.php?id=zgxsh_avatar:index'",array('icon'=>1));
}


system_end(); /*dis'.'m.t'.'ao'.'bao.com*/
?>