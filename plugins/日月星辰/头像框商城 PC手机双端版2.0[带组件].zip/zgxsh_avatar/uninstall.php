<?php
/**
 *	[ͷ����̳�(zgxsh_avatar.uninstall)] [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *	Version: 1.0    _���²����http://t.cn/Aiux1Jx1
 *	Date: 2020-09-02 23:28
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_pack`;
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_store`;
DROP TABLE IF EXISTS `cdb_zgxsh_avatar_user`;
EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>