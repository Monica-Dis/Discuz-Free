<?php
/**
 *	[爬虫采集-电脑Run(dnr_webspider.uninstall)] Copyright 2001-2099 DisM!应用中心.
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_plugins_dnr_activepush_var`;

DROP TABLE IF EXISTS `pre_plugin_dnr_activepush_log`;

EOF;

runquery($sql);
$finish = true;
?>