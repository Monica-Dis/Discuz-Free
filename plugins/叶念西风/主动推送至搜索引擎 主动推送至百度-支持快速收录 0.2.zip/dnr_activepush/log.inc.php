<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.install)] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('submitclean')){
    cpmsg(lang('plugin/dnr_activepush', 'cleanning'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_activepush&pmod=log&type=clear",'loadingform');
    exit();
}

if( $_GET['type'] == 'clear' ) {
    $logs = C::t('#dnr_activepush#dnr_activepush_log')->clean();
    cpmsg(lang('plugin/dnr_activepush', 'clean_ok'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_activepush",'success');

    exit();
}

if( !isset($_GET['type'])){
    showformheader("plugins&operation=config&do=".$pluginid."&identifier=dnr_activepush&pmod=log", '', 'myform');
    showsubmit('submitclean', lang('plugin/dnr_activepush', 'clean_bt'));
    showformfooter();
    echo("<hr><table border=\"1\" style=\"width:80%\"><tr><th>".lang('plugin/dnr_activepush', 'table_tag1')."</th><th>".lang('plugin/dnr_activepush', 'table_tag2')."</th><th>".lang('plugin/dnr_activepush', 'table_tag3')."</th><th>".lang('plugin/dnr_activepush', 'table_tag4')."</th><th>".lang('plugin/dnr_activepush', 'table_tag5')."</th></tr>");

    $logs = C::t('#dnr_activepush#dnr_activepush_log')->fetch_all();

    foreach( $logs as $key => $log ){
        $logarr = unserialize($log['value']);
        if( isset($logarr['success']) ){
            if($logarr['success']>0){
                echo("<tr><td>".($key+1)."</td><td>".$logarr['dnr']['url']."</td><td>".($logarr['dnr']['type']==1?lang('plugin/dnr_activepush', 'table_fast'):'').lang('plugin/dnr_activepush', 'push_ok')."</td><td>".date('Y-m-d H:i:s',$log['dateline'])."</td><td>".lang('plugin/dnr_activepush', 'tips_no1').$logarr['remain']."</td></tr>");
            }else{
                echo("<tr><td>".($key+1)."</td><td>".$logarr['dnr']['url']."</td><td>".($logarr['dnr']['type']==1?lang('plugin/dnr_activepush', 'table_fast'):'').lang('plugin/dnr_activepush', 'push_fail')."</td><td>".date('Y-m-d H:i:s',$log['dateline'])."</td><td>".lang('plugin/dnr_activepush', 'tips_no2').$logarr['remain']."</td></tr>");
            }

        }else{
            echo("<tr><td>".($key+1)."</td><td>".$logarr['dnr']['url']."</td><td>".($logarr['dnr']['type']==1?lang('plugin/dnr_activepush', 'table_fast'):'').lang('plugin/dnr_activepush', 'push_fail')."</td><td>".date('Y-m-d H:i:s',$log['dateline'])."</td><td>Error:".$logarr['error'].". Message: ".$logarr['message']."</td></tr>");
        }
    }
    echo("</table>");
    exit();
}



