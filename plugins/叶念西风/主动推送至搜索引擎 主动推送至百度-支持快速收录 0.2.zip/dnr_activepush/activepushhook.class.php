<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function _check_params(){
    global $_G;
    loadcache('plugin');
    if( empty($_G['cache']['plugin']['dnr_activepush']['weburl'] )){
        return false;
    }
    if( empty($_G['cache']['plugin']['dnr_activepush']['forumposturl'] )){
        return false;
    }
    if( empty($_G['cache']['plugin']['dnr_activepush']['portalarticleurl'] )){
        return false;
    }
    if( !is_numeric($_G['cache']['plugin']['dnr_activepush']['forumpostsize']) ){
        return false;
    }
    if( !is_numeric($_G['cache']['plugin']['dnr_activepush']['portalarticlesize'])  ){
        return false;
    }
    if( empty($_G['cache']['plugin']['dnr_activepush']['bdtoken'] )){
        return false;
    }
    return true;
}

function _push_tid_to_baidu( $tid ){
    global $_G;
    loadcache('plugin');
    $url =  str_replace('@',$tid,$_G['cache']['plugin']['dnr_activepush']['forumposturl']);
    $urls = array(
        $url,
    );
    $api = 'http://data.zz.baidu.com/urls?site='.$_G['cache']['plugin']['dnr_activepush']['weburl'].'&token='.$_G['cache']['plugin']['dnr_activepush']['bdtoken'];

    $ch = curl_init();
    $options =  array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $res = curl_exec($ch);
    $res = json_decode($res,true);
    $res['dnr']['tid'] = $tid;
    $res['dnr']['url'] = $url;
    $res['dnr']['uid'] = $_G['uid'];
    $res['dnr']['type'] = 0;
    return $res;
}

function _fast_push_tid_to_baidu( $tid ){
    global $_G;
    loadcache('plugin');
    $url =  str_replace('@',$tid,$_G['cache']['plugin']['dnr_activepush']['forumposturl']);
    $urls = array(
        $url,
    );
    $api = 'http://data.zz.baidu.com/urls?site='.$_G['cache']['plugin']['dnr_activepush']['weburl'].'&token='.$_G['cache']['plugin']['dnr_activepush']['bdtoken'].'&type=daily';

    $ch = curl_init();
    $options =  array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $res = curl_exec($ch);
    $res = json_decode($res,true);
    $res['dnr']['tid'] = $tid;
    $res['dnr']['url'] = $url;
    $res['dnr']['uid'] = $_G['uid'];
    $res['dnr']['type'] = 1;
    return $res;
}

function _push_aid_to_baidu( $aid ){
    global $_G;
    loadcache('plugin');
    $url =  str_replace('@',$aid,$_G['cache']['plugin']['dnr_activepush']['portalarticleurl']);
    $urls = array(
        $url,
    );
    $api = 'http://data.zz.baidu.com/urls?site='.$_G['cache']['plugin']['dnr_activepush']['weburl'].'&token='.$_G['cache']['plugin']['dnr_activepush']['bdtoken'];

    $ch = curl_init();
    $options =  array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $res = curl_exec($ch);
    $res = json_decode($res,true);
    $res['dnr']['tid'] = $aid;
    $res['dnr']['url'] = $url;
    $res['dnr']['uid'] = $_G['uid'];
    $res['dnr']['type'] = 0;
    return $res;
}

function _fast_push_aid_to_baidu( $aid ){
    global $_G;
    loadcache('plugin');
    $url =  str_replace('@',$aid,$_G['cache']['plugin']['dnr_activepush']['portalarticleurl']);
    $urls = array(
        $url,
    );
    $api = 'http://data.zz.baidu.com/urls?site='.$_G['cache']['plugin']['dnr_activepush']['weburl'].'&token='.$_G['cache']['plugin']['dnr_activepush']['bdtoken'].'&type=daily';

    $ch = curl_init();
    $options =  array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $res = curl_exec($ch);
    $res = json_decode($res,true);
    $res['dnr']['tid'] = $aid;
    $res['dnr']['url'] = $url;
    $res['dnr']['uid'] = $_G['uid'];
    $res['dnr']['type'] = 1;
    return $res;
}


class plugin_dnr_activepush {

    function deletethread( $value ){

        if(isset($value) && $value['step']=="delete" && _check_params() ){
            global $_G;
            if( $value['param'][0][0]>0 ){
                 //file_put_contents( DISCUZ_ROOT.'/source/plugin/dnr_activepush/logs.txt',$value['param'][0][0]." delete\n", FILE_APPEND);
            }
        }
    }

}

class plugin_dnr_activepush_forum extends plugin_dnr_activepush {

    function post_message(){
        if( $_SERVER['REQUEST_METHOD']=='POST' && _check_params()  ){
            global $_G;
            loadcache('plugin');
            if(in_array($_G['uid'], unserialize($_G['cache']['plugin']['dnr_activepush']['usergroup']))){
                if( strlen(strip_tags($_POST['message'])) > $_G['cache']['plugin']['dnr_activepush']['forumpostsize'] ){
                    if(isset($_POST['tid']) && ((int)$_POST['tid'])>0 ){
                        $res = _push_tid_to_baidu($_POST['tid']);
                        C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                        if($_G['cache']['plugin']['dnr_activepush']['enfastpush']){
                            $res = _fast_push_tid_to_baidu($_POST['tid']);
                            C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                        }
                    }else{
                        $forumpost = C::t('#dnr_activepush#dnr_forum_post')->fetch_tid_by_name($_POST['subject']);
                        if(!empty($forumpost) ){
                            $res = _push_tid_to_baidu($forumpost['tid']);
                            C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                            if($_G['cache']['plugin']['dnr_activepush']['enfastpush']){
                                $res = _fast_push_tid_to_baidu($forumpost['tid']);
                                C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                            }
                        }
                    }
                }
            }
        }
    }

}

class plugin_dnr_activepush_portal extends plugin_dnr_activepush {

    function portalcp_output(){

        if( $_SERVER['REQUEST_METHOD']=='POST' && $_GET['ac']=='article' && _check_params() ){
            if( isset($_POST['title']) && isset($_POST['content']) ){
                global $_G;
                loadcache('plugin');
                if(in_array($_G['uid'], unserialize($_G['cache']['plugin']['dnr_activepush']['usergroup']))){
                    if( strlen(strip_tags($_POST['content'])) > $_G['cache']['plugin']['dnr_activepush']['portalarticlesize'] ){
                        if( !empty($_POST['aid']) ){
                            $res = _push_aid_to_baidu($_POST['aid']);
                            C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                            if($_G['cache']['plugin']['dnr_activepush']['enfastpush']){
                                $res = _fast_push_aid_to_baidu($article['aid']);
                                C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                            }
                        }else{
                            $article = C::t('#dnr_activepush#dnr_portal_article_title')->fetch_tid_by_title($_POST['title']);
                            //debug(0);
                            if(!empty($article) ){
                                $res = _push_aid_to_baidu($article['aid']);
                                C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                                if($_G['cache']['plugin']['dnr_activepush']['enfastpush']){
                                    $res = _fast_push_aid_to_baidu($article['aid']);
                                    C::t('#dnr_activepush#dnr_activepush_log')->insert_data($res);
                                }
                            }
                        }
                    }
                }

            }
        }
    }
}