<?php

/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_activepush_log extends discuz_table {

	public function __construct() {
		$this->_table = 'plugin_dnr_activepush_log';
        $this->_pk    = 'id';

		parent::__construct();
	}

	public function fetch_all() {
		$query = DB::query('SELECT * FROM %t ORDER BY dateline DESC LIMIT 1000', array($this->_table));
		$index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
	}


	public function insert_data( $value ){

            return $this->insert(array(
                        'value'=>serialize($value),
                        'dateline'=>time()
                    ));


    }
    public function clean(){
        $query = DB::delete($this->_table,'1');
    }

}