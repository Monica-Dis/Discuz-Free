<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_forum_post extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_post';
        $this->_pk    = 'pid';

		parent::__construct();
	}

    public function fetch_tid_by_name( $name ) {
        //$query = DB::query('SELECT * FROM %t WHERE subject=%s ORDER BY dateline DESC', array($this->_table, $name));
        return DB::fetch_first('SELECT * FROM %t WHERE subject=%s ORDER BY dateline DESC', array($this->_table, $name));
    }

}