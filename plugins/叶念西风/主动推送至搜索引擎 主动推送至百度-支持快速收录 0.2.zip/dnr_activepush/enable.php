<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.install)] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
