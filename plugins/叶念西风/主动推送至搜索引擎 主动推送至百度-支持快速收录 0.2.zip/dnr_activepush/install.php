<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.install)] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$txt_filename = DISCUZ_ROOT.'robots.txt';
if(file_exists($txt_filename)){
    $content = file_get_contents($txt_filename);
    $content_lines = explode("\n",$content);

    foreach( $content_lines as $key => $content_line ){
        $res = stristr($content_line, 'sitemap:');
        if($res != false){
            $content_lines[$key] = "Sitemap: ".$_G['setting']['siteurl']."sitemap.xml\r\n";
            break;
        }
    }
    file_put_contents($txt_filename, implode("\n",$content_lines));

}else{
    $content = "User-agent: *\r\n Disallow: \r\nSitemap: ".$_G['setting']['siteurl']."sitemap.xml\r\n";
    file_put_contents($txt_filename, $content);
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_plugins_dnr_activepush_var` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `pluginname` varchar(255) NOT NULL,
  `variable` varchar(40) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_plugin_dnr_activepush_log` (
`id` INT(11) NOT NULL AUTO_INCREMENT ,
`value` TEXT NOT NULL ,
`dateline` INT(11) NOT NULL , PRIMARY KEY (`id`)) ENGINE = MyISAM;

EOF;

runquery($sql);

$finish = true;
?>