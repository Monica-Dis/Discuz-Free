<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.install)] (C)2020-2099 Powered by dism.taobao.com
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$localHost = trim($_G['setting']['siteurl']);
if(substr($localHost,-1)!='/'){
    $localHost = $localHost.'/';
}
$txt_filename = DISCUZ_ROOT.'robots.txt';
if(file_exists($txt_filename)){
    $content = file_get_contents($txt_filename);
    $content_lines = explode("\n",$content);
    $content_lines = array_filter($content_lines);
    $sitemapfound = false;
    foreach( $content_lines as $key => $content_line ){
        $res = stristr($content_line, 'sitemap:');
        if($res != false){
            $content_lines[$key] = "Sitemap: ".$localHost."sitemap.xml\r\n";
            $sitemapfound = true;
            break;
        }
    }
    if( $sitemapfound == false ){
        $content_lines[$key+1] = "Sitemap: ".$localHost."sitemap.xml\r\n";
    }
    file_put_contents($txt_filename, implode("\n",$content_lines));

}else{
    $content = "User-agent: *\r\n Disallow: \r\nSitemap: ".$localHost."sitemap.xml\r\n";
    file_put_contents($txt_filename, $content);
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_plugins_dnr_var` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `pluginname` varchar(255) NOT NULL,
  `variable` varchar(40) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

/* ����Ƿ����� */
if( C::t('#dnr_sitemap#dnr_var')->get_var("pluginenable") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("pluginenable",false);
/* ��¼���� */
if( C::t('#dnr_sitemap#dnr_var')->get_var("enableportal") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("enableportal",false);
/* ��¼��̳ */
if( C::t('#dnr_sitemap#dnr_var')->get_var("enableforum") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("enableforum",false);
/* ��¼����??Ŀ */
if( C::t('#dnr_sitemap#dnr_var')->get_var("selectportal") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("selectportal",array());
/* ��¼��??̳��??*/
if( C::t('#dnr_sitemap#dnr_var')->get_var("selectforum") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("selectforum",array());

/* ???��һ������ʱ??����?? */
if( C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time") == null )
    C::t('#dnr_sitemap#dnr_var')->set_var("generate_all_time",10184000);

require 'source/plugin/dnr_sitemap/function/dnr_common.php';
add_log("Install Generate XML file.");
generate_xml();
add_log("Install Generate TXT file.");
generate_txt();

$finish = true;
?>