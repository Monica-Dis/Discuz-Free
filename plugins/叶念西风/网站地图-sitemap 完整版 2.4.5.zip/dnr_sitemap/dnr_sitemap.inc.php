<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
loadcache('plugin');
$dnr_sitemap_portal_articles=[];
$dnr_sitemap_forum_articles=[];
$itemNum = $_G['cache']['plugin']['dnr_sitemap']['maxtxtcount'];
if(C::t('#dnr_sitemap#dnr_var')->get_var("enableportal")){
    $dnr_sitemap_portal_articles = C::t('#dnr_sitemap#dnr_portal_article_title')->fetch_limit_by_catid_num( C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"), C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$itemNum/2);
}
$itemNum = $itemNum - count($dnr_sitemap_portal_articles);
if(C::t('#dnr_sitemap#dnr_var')->get_var("enableforum")){
    /* forum */
    $dnr_sitemap_forum_articles = C::t('#dnr_sitemap#dnr_forum_post')->fetch_limit_by_catid_num(C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"),C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$itemNum);

}

$navtitle = lang('plugin/dnr_sitemap', 'webmap');
include template('dnr_sitemap:list');
