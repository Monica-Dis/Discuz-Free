<?php
/*
 * Install Uninstall Upgrade AutoStat System Code 2019100611tz0w9k0pxX
 * This is NOT a freeware, use is subject to license terms
 * From DisM.taobao.COM
 */
if( !defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$txt_filename = DISCUZ_ROOT.'robots.txt';

if(file_exists($txt_filename)){
    $content = file_get_contents($txt_filename);
    $content_lines = explode("\n",$content);

    foreach( $content_lines as $key => $content_line ){
        $res = stristr($content_line, 'sitemap:');
        if($res != false){
            $content_lines[$key] = "Sitemap: ".$_G['setting']['siteurl']."sitemap.xml\r\n";
            break;
        }
    }
    file_put_contents($txt_filename, implode("\n",$content_lines));

}else{
    $content = "User-agent: *\r\n Disallow: \r\nSitemap: ".$_G['setting']['siteurl']."sitemap.xml\r\n";
    file_put_contents($txt_filename, $content);
}

$finish = TRUE;
?>