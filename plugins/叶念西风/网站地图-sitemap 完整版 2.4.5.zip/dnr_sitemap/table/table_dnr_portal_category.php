<?php

/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_portal_category extends discuz_table {

	public function __construct() {
		$this->_table = 'portal_category';
        $this->_pk    = 'catid';

		parent::__construct(); /*Dism_taobao-com*/
	}

	public function fetch_by_id( $id ) {
	    return DB::fetch_first('SELECT * FROM %t WHERE catid=%d', array($this->_table,$id));
	}

	public function fetch_all() {
		$query = DB::query('SELECT * FROM %t WHERE closed=0', array($this->_table));
		$index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            if(!$value['upid'] == 0 ){
                $value['catname'] = $value['catname'].' ['.$this->fetch_by_id($value['upid'])['catname'].']';
            }
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
	}
}