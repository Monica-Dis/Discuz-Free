<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_forum_forum extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_forum';
        $this->_pk    = 'fid';

		parent::__construct(); /*Dism_taobao-com*/
	}

	public function fetch_by_id( $id ) {
	    return DB::fetch_first('SELECT * FROM %t WHERE fid=%d', array($this->_table,$id));
	}

	public function fetch_all() {
		$query = DB::query('SELECT * FROM %t WHERE status=1 AND type=2', array($this->_table));
		$index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            if(!$value['fup'] == 0 ){
                $value['name'] = $value['name'].' ['.$this->fetch_by_id($value['fup'])['name'].']';
            }
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
	}
}