<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_forum_post extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_post';
        $this->_pk    = 'pid';

		parent::__construct(); /*Dism_taobao-com*/
	}

	public function fetch_limit_by_catid_num( $catids, $time, $num ) {
        $query = DB::query('SELECT * FROM %t WHERE first=1 AND	dateline>%d AND invisible=0 AND fid IN ('.dimplode($catids).') ORDER BY dateline DESC LIMIT %d', array($this->_table, $time,$num));
        $index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
    }

    public function fetch_limit_by_catid( $catids, $time, $page ) {
        $query = DB::query('SELECT * FROM %t WHERE first=1 AND	dateline>%d AND invisible=0 AND fid IN ('.dimplode($catids).') ORDER BY dateline DESC LIMIT %d,%d', array($this->_table, $time,$page*45000, 45000));
        $index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
    }

    public function fetch_count_by_catid( $catids, $time ){
        $query = DB::query('SELECT COUNT(*) FROM %t WHERE first=1 AND dateline<%d AND invisible=0 AND fid IN ('.dimplode($catids).')', array($this->_table, $time));
        return DB::fetch($query)['COUNT(*)'];
    }
}