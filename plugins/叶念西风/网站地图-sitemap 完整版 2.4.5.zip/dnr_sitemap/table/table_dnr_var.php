<?php

/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dnr_var extends discuz_table {

	public function __construct() {
		$this->_table = 'plugins_dnr_var';
        $this->_pk    = 'id';

		parent::__construct(); /*Dism_taobao-com*/
	}

	public function fetch_all() {
		$query = DB::query('SELECT * FROM %t', array($this->_table));
		$index=0;
        $queryData = [];
        while($value = DB::fetch($query)) {
            $queryData[$index] = $value;
            $index = $index + 1;
        }
        return $queryData;
	}

	public function get_var( $name ){
        $item =  DB::fetch_first('SELECT * FROM %t WHERE variable=%s', array($this->_table,$name));
        if( $item == null ){
            return $item;
        } else {
            return unserialize($item['value']);
        }
	}
	public function set_var( $name, $value ){
        $item = DB::fetch_first('SELECT * FROM %t WHERE variable=%s', array($this->_table,$name));
        if( $item == null ){
            return $this->insert(array(
                        'pluginname'=>'dnr_sitename',
                        'variable'=>$name,
                        'value'=>serialize($value)
                    ));
        }else{
            return $this->update($item['id'],array(
                        'value'=>serialize($value)
                    ));
        }

    }
}