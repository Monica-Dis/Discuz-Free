<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.install)] (C)2020-2099 Powered by dism.taobao.com
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

C::t('#dnr_sitemap#dnr_var')->set_var("pluginenable",true);