<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;

if(submitcheck('submitxml')){
    cpmsg(lang( 'plugin/dnr_sitemap', 'generate_xml_loading'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=admin&type=xml",'loadingform');
    exit();
}

if(submitcheck('submittxt')){
    cpmsg(lang('plugin/dnr_sitemap', 'generate_txt_loading'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=admin&type=txt",'loadingform');
    exit();
}

if( !isset($_GET['type'])){
    $portal_topic = null;
    $portal_article = null;
    $forum_forumlist = null;
    $forum_view = null;
    showformheader("plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=admin", '', 'myform');
    for( $i=0; $i<count($_G['setting']['rewritestatus']); $i++ ){
        if( $_G['setting']['rewritestatus'][$i] == 'portal_topic' ){
            $portal_topic = $_G['setting']['rewriterule']['portal_topic'];
            echo('<p style="padding:5px; font-size:14px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'portal_topic').'</p>');
            echo('<p style="padding:5px; font-size:12px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'rewrite_info').$portal_topic.'</p><hr>');
        }else if( $_G['setting']['rewritestatus'][$i] == 'portal_article' ){
            $portal_article = $_G['setting']['rewriterule']['portal_article'];
            echo('<p style="padding:5px; font-size:14px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'portal_article').'</p>');
            echo('<p style="padding:5px; font-size:12px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'rewrite_info').$portal_article.'</p><hr>');
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_forumdisplay' ){
            $forum_forumlist = $_G['setting']['rewriterule']['forum_forumdisplay'];
            echo('<p style="padding:5px; font-size:14px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'forum_forumdisplay').'</p>');
            echo('<p style="padding:5px; font-size:12px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'rewrite_info').$forum_forumlist.'</p><hr>');
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_viewthread' ){
            $forum_view = $_G['setting']['rewriterule']['forum_viewthread'];
            echo('<p style="padding:5px; font-size:14px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'forum_viewthread').'</p>');
            echo('<p style="padding:5px; font-size:12px; font-weight:bold;">'.lang('plugin/dnr_sitemap', 'rewrite_info').$forum_view.'</p><hr>');
        }
    }
    if (!is_writable(DISCUZ_ROOT.'sitemap.xml')) {
        echo '<br><p>'.lang('plugin/dnr_sitemap', 'no_permiss').':  '.DISCUZ_ROOT.'sitemap.xml</p><br>';
    }else{
        showsubmit('submitxml', lang('plugin/dnr_sitemap', 'generate_xml').'.XML');
    }

    if (!is_writable(DISCUZ_ROOT.'sitemap.txt')) {
        echo '<br><p>'.lang('plugin/dnr_sitemap', 'no_permiss').':  '.DISCUZ_ROOT.'sitemap.txt</p><br>';
    }else{
        showsubmit('submittxt', lang('plugin/dnr_sitemap', 'generate_xml').'.TXT');
    }

    showformfooter(); /*Dism_taobao_com*/
}

if( 'xml' == $_GET['type'] ){
    require 'source/plugin/dnr_sitemap/function/dnr_common.php';
    add_log("Generate XML file.");
    generate_xml();
    
    cpmsg(lang( 'plugin/dnr_sitemap', 'generate_xml_ok'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=admin",'succeed');
    exit();
}
if( 'txt' == $_GET['type'] ){
    require 'source/plugin/dnr_sitemap/function/dnr_common.php';
    add_log("Generate TXT file.");
    generate_txt();
    
    cpmsg(lang('plugin/dnr_sitemap', 'generate_txt_ok'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=admin",'succeed');
    exit();
}


