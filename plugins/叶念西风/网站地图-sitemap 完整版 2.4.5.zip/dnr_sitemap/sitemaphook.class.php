<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_dnr_sitemap {

}
