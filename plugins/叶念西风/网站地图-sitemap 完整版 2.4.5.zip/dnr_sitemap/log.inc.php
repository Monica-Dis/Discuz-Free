<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(submitcheck('submitcl')){
    file_put_contents( DISCUZ_ROOT.'/source/plugin/dnr_sitemap/log.txt','');
    cpmsg(lang( 'plugin/dnr_sitemap', 'successed'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=log",'succeed');
    exit();
}

showformheader("plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=log", '', 'myform');
showsubmit('submitcl', lang('plugin/dnr_sitemap', 'clear_rec'));
showformfooter(); /*Dism_taobao_com*/
$content = file_get_contents(DISCUZ_ROOT.'/source/plugin/dnr_sitemap/log.txt');
echo('<div><textarea readonly style="width: 100%; min-height: 400px;">'.$content.'</textarea></div>');





