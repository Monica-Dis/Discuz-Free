<?php
/**
 *	[爬虫采集-电脑Run(dnr_webspider.uninstall)] (C)2020-2099 Powered by dism.taobao.com
 *	Version: V0.1
 *	Date: 2020-5-15 11:38
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$sql = <<<EOF

DROP TABLE IF EXISTS `pre_plugins_dnr_var`;

EOF;

runquery($sql);
$finish = true;
?>