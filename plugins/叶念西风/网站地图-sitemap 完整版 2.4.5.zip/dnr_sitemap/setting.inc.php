<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('plugin');

if(submitcheck('submit')){
    if(count($_POST['selectportal'])>1){
        if($_POST['selectportal'][0]==0){
            cpmsg(lang('plugin/dnr_sitemap', 'params_save_error'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=setting",'error');
            exit();
        }
    }
    if(count($_POST['selectforum'])>1){
        if($_POST['selectforum'][0]==0){
            cpmsg(lang('plugin/dnr_sitemap', 'params_save_error'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=setting",'error');
            exit();
        }
    }

    C::t('#dnr_sitemap#dnr_var')->set_var("enableportal",$_POST['enableportal']);
    C::t('#dnr_sitemap#dnr_var')->set_var("enableforum",$_POST['enableforum']);

    C::t('#dnr_sitemap#dnr_var')->set_var("selectportal",$_POST['selectportal']);
    C::t('#dnr_sitemap#dnr_var')->set_var("selectforum",$_POST['selectforum']);

    cpmsg(lang('plugin/dnr_sitemap', 'params_save_succeed'),"action=plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=setting",'succeed');
    exit();
} else {
    showformheader("plugins&operation=config&do=".$pluginid."&identifier=dnr_sitemap&pmod=setting", '', 'myform');
    showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
    showsetting(lang('plugin/dnr_sitemap', 'collect_portal'), 'enableportal', C::t('#dnr_sitemap#dnr_var')->get_var("enableportal"), 'radio');
    $portals = C::t('#dnr_sitemap#dnr_portal_category')->fetch_all();
    $option = array(array(0,lang('plugin/dnr_sitemap', 'params_null')));
    foreach( $portals as $portal ){
        $option[] = array( $portal['catid'],$portal['catname']);
    }
    showsetting(lang('plugin/dnr_sitemap', 'collect_portal_list'),array('selectportal[]',$option), C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"), 'mselect');


    showsetting(lang('plugin/dnr_sitemap', 'collect_forum'), 'enableforum', C::t('#dnr_sitemap#dnr_var')->get_var("enableforum"), 'radio');
    $portals = C::t('#dnr_sitemap#dnr_forum_forum')->fetch_all();
    $option = array(array(0,lang('plugin/dnr_sitemap', 'params_null')));
    foreach( $portals as $portal ){
        $option[] = array( $portal['fid'],$portal['name']);
    }
    showsetting(lang('plugin/dnr_sitemap', 'collect_forum_list'),array('selectforum[]',$option),C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"),'mselect');
    showtablefooter(); /*Dism��taobao��com*/
    showsubmit('submit', lang('plugin/dnr_sitemap', 'submit'));
    showformfooter(); /*Dism_taobao_com*/
}


