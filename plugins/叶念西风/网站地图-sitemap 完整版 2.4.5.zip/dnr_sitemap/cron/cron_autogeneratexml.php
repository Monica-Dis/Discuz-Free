<?php
/**
 *	[Sitemap-Run(dnr_sitemap.cron_autogeneratexml)] (C)2020-2099 Powered by dism.taobao.com
 *	Version: V0.1
 *	Date: 2020-5-18 10:48
 *	Warning: Don't delete this comment
 *
 *	cronname:Sitemap-dnr
 *	week:
 *	day:
 *	hour:4
 *	minute:
 *	desc:
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require 'source/plugin/dnr_sitemap/function/dnr_common.php';
add_log("Auto Generate XML file.");
generate_xml();
add_log("Auto Generate TXT file.");
generate_txt();


?>
