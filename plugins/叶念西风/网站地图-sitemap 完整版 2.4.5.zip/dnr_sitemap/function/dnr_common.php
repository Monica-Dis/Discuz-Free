<?php
/**
 *	[Sitemap-Diannao.Run(dnr_webspider.{modulename})] (C)2020-2099 Powered by dism.taobao.com&DisMӦ������.
 *	Version: V0.1
 *	Date: 2020-5-15 12:08
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function generate_xml(){
    global $_G;

    loadcache('plugin');

    $localHost = trim($_G['setting']['siteurl']);
    if(substr($localHost,-1)!='/'){
        $localHost = $localHost.'/';
    }
    if(!$_G['cache']['plugin']['dnr_sitemap']['enableXml']){
        add_log("Skip Generate XML file.");
        return ;
    }

    set_time_limit(6000);

    $portal_topic = null;
    $portal_article = 'portal.php?mod=view&aid={id}&page={page}';
    $forum_forumlist = 'forum.php?mod=forumdisplay&fid={fid}';
    $forum_view = 'forum.php?mod=viewthread&tid={tid}&page={page}&prevpage={prevpage}';

    for( $i=0; $i<count($_G['setting']['rewritestatus']); $i++ ){
        if( $_G['setting']['rewritestatus'][$i] == 'portal_topic' ){
            $portal_topic = $_G['setting']['rewriterule']['portal_topic'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'portal_article' ){
            $portal_article = $_G['setting']['rewriterule']['portal_article'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_forumdisplay' ){
            $forum_forumlist = $_G['setting']['rewriterule']['forum_forumdisplay'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_viewthread' ){
            $forum_view = $_G['setting']['rewriterule']['forum_viewthread'];
        }
    }
    $portal_all_num = 0;
    $forum_all_num = 0;
    if(C::t('#dnr_sitemap#dnr_var')->get_var("enableportal")){
        /* portal */
        $portal_all_num = (int)C::t('#dnr_sitemap#dnr_portal_article_title')->fetch_count_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"),time());

    }


    if(C::t('#dnr_sitemap#dnr_var')->get_var("enableforum")){
        /* forum */

        $forum_all_num = (int)C::t('#dnr_sitemap#dnr_forum_post')->fetch_count_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"),time());

    }
    
    if( ($forum_all_num+$portal_all_num)>45000 ){

        $page_index = 0;

        $portal_page_index = 0;
        $remain_num = $portal_all_num;
        while( $remain_num>0 ){
            $portal_page_index = $portal_page_index+1;

            $sitemap_header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
                                "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:mobile=\"http://www.baidu.com/schemas/sitemap-mobile/1/\">\n";
            $sitemap_footer = "\n</urlset>";

            $sitemap_filename = DISCUZ_ROOT.'sitemap_'.($page_index+$portal_page_index).'.xml';
            file_put_contents( $sitemap_filename, $sitemap_header );

            $articles = C::t('#dnr_sitemap#dnr_portal_article_title')->fetch_limit_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"),C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$portal_page_index-1);

            foreach($articles as $article ) {
                $path = str_replace( '{id}', $article['aid'], $portal_article );
                $path = str_replace( '{page}', 1, $path);

                $xmlurl = "<url>\n\t<loc>".$localHost.$path."</loc>\n";
                $xmlurl = $xmlurl."\t<lastmod>".date('Y-m-d',$article['dateline'])."</lastmod>\n";
                $xmlurl = $xmlurl."\t<changefreq>daily</changefreq>\n";
                if($_G['cache']['plugin']['dnr_sitemap']['type']==2){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==3){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"pc,mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==4){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"htmladapt\"/>\n";
                }
                $xmlurl = $xmlurl."\t<priority>0.9</priority>\n</url>\n";

                file_put_contents($sitemap_filename, $xmlurl, FILE_APPEND);
            }

            file_put_contents( $sitemap_filename, $sitemap_footer,FILE_APPEND );
            $remain_num = $remain_num - 45000;

        }
        $page_index = $page_index+$portal_page_index;

        $forum_page_index = 0;
        $remain_num = $forum_all_num;
        while( $remain_num>0 ){
            $forum_page_index = $forum_page_index+1;

            $sitemap_header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
                                "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:mobile=\"http://www.baidu.com/schemas/sitemap-mobile/1/\">\n";
            $sitemap_footer = "\n</urlset>";

            $sitemap_filename = DISCUZ_ROOT.'sitemap_'.($page_index+$forum_page_index).'.xml';
            file_put_contents( $sitemap_filename, $sitemap_header );

            $articles = C::t('#dnr_sitemap#dnr_forum_post')->fetch_limit_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"), C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$forum_page_index-1);
            
            foreach($articles as $article ){
                $path = str_replace('{fid}',$article['fid'],$forum_view);
                $path = str_replace('{tid}',$article['tid'],$path);
                $path = str_replace('{page}',1,$path);
                $path = str_replace('{prevpage}',1,$path);

                $xmlurl = "<url>\n\t<loc>".$localHost.$path."</loc>\n";
                $xmlurl = $xmlurl."\t<lastmod>".date('Y-m-d',$article['dateline'])."</lastmod>\n";
                $xmlurl = $xmlurl."\t<changefreq>daily</changefreq>\n";
                if($_G['cache']['plugin']['dnr_sitemap']['type']==2){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==3){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"pc,mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==4){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"htmladapt\"/>\n";
                }
                $xmlurl = $xmlurl."\t<priority>0.9</priority>\n</url>\n";

                file_put_contents($sitemap_filename, $xmlurl, FILE_APPEND);
            }

            file_put_contents( $sitemap_filename, $sitemap_footer,FILE_APPEND );
            $remain_num = $remain_num - 45000;
        }
        $page_index = $page_index+$forum_page_index;
        $sitemap_filename = DISCUZ_ROOT.'sitemap.xml';
        file_put_contents( $sitemap_filename, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<sitemapindex>\n".'<?xml-stylesheet type="text/xsl" href="'.$localHost.'source/plugin/dnr_sitemap/sitemap.xsl"?>' );
        for($i =1; $i<=$page_index; $i++ ){
            file_put_contents( $sitemap_filename, "<sitemap>\n<loc>".$localHost.'sitemap_'.$i.".xml</loc>\n<lastmod>".date('Y-m-d')."</lastmod>\n</sitemap>\n",FILE_APPEND );
        }
        file_put_contents( $sitemap_filename, "</sitemapindex>",FILE_APPEND );
    }else{
        $sitemap_header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".
                            "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:mobile=\"http://www.baidu.com/schemas/sitemap-mobile/1/\">\n";
        $sitemap_footer = "\n</urlset>";
        $sitemap_filename = DISCUZ_ROOT.'sitemap.xml';

        file_put_contents( $sitemap_filename, $sitemap_header );
        $xmlurl = "<url>\n\t<loc>".$localHost."</loc>\n";
        $xmlurl = $xmlurl."\t<lastmod>".date('Y-m-d')."</lastmod>\n";
        $xmlurl = $xmlurl."\t<changefreq>daily</changefreq>\n";
        if($_G['cache']['plugin']['dnr_sitemap']['type']==2){
            $xmlurl = $xmlurl."\t<mobile:mobile type=\"mobile\"/>\n";
        } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==3){
            $xmlurl = $xmlurl."\t<mobile:mobile type=\"pc,mobile\"/>\n";
        } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==4){
            $xmlurl = $xmlurl."\t<mobile:mobile type=\"htmladapt\"/>\n";
        }
        $xmlurl = $xmlurl."\t<priority>1</priority>\n</url>\n";
        $xmlurl = str_replace('&','&amp;',$xmlurl);
        file_put_contents($sitemap_filename, $xmlurl, FILE_APPEND);
        if( $portal_all_num>0 ){
            $articles = C::t('#dnr_sitemap#dnr_portal_article_title')->fetch_limit_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"),C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,0);

            foreach($articles as $article ) {
                
                $path = str_replace( '{id}', $article['aid'], $portal_article );
                $path = str_replace( '{page}', 1, $path);

                $xmlurl = "<url>\n\t<loc>".$localHost.$path."</loc>\n";
                $xmlurl = $xmlurl."\t<lastmod>".date('Y-m-d',$article['dateline'])."</lastmod>\n";
                $xmlurl = $xmlurl."\t<changefreq>daily</changefreq>\n";
                if($_G['cache']['plugin']['dnr_sitemap']['type']==2){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==3){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"pc,mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==4){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"htmladapt\"/>\n";
                }
                $xmlurl = $xmlurl."\t<priority>0.9</priority>\n</url>\n";
                $xmlurl = str_replace('&','&amp;',$xmlurl);
                file_put_contents($sitemap_filename, $xmlurl, FILE_APPEND);
            }

        }

        if( $forum_all_num>0 ){

            $articles = C::t('#dnr_sitemap#dnr_forum_post')->fetch_limit_by_catid(C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"), C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,0);

            foreach($articles as $article ){
                $path = str_replace('{fid}',$article['fid'],$forum_view);
                $path = str_replace('{tid}',$article['tid'],$path);
                $path = str_replace('{page}',1,$path);
                $path = str_replace('{prevpage}',1,$path);

                $xmlurl = "<url>\n\t<loc>".$localHost.$path."</loc>\n";
                $xmlurl = $xmlurl."\t<lastmod>".date('Y-m-d',$article['dateline'])."</lastmod>\n";
                $xmlurl = $xmlurl."\t<changefreq>daily</changefreq>\n";
                if($_G['cache']['plugin']['dnr_sitemap']['type']==2){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==3){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"pc,mobile\"/>\n";
                } elseif ($_G['cache']['plugin']['dnr_sitemap']['type']==4){
                    $xmlurl = $xmlurl."\t<mobile:mobile type=\"htmladapt\"/>\n";
                }
                $xmlurl = $xmlurl."\t<priority>0.9</priority>\n</url>\n";
                $xmlurl = str_replace('&','&amp;',$xmlurl);
                file_put_contents($sitemap_filename, $xmlurl, FILE_APPEND);
            }
        }

        file_put_contents( $sitemap_filename, $sitemap_footer,FILE_APPEND );
    }

}

function generate_txt(){
    global $_G;
    $localHost = trim($_G['setting']['siteurl']);
    if(substr($localHost,-1)!='/'){
        $localHost = $localHost.'/';
    }
    loadcache('plugin');
    if(!$_G['cache']['plugin']['dnr_sitemap']['enableTxt']){
        add_log("Skip Generate txt file.");
        return ;
    }
    set_time_limit(600);
    $portal_topic = null;
    $portal_article = 'portal.php?mod=view&aid={id}&page={page}';
    $forum_forumlist = 'forum.php?mod=forumdisplay&fid={fid}';
    $forum_view = 'forum.php?mod=viewthread&tid={tid}&page={page}&prevpage={prevpage}';

    for( $i=0; $i<count($_G['setting']['rewritestatus']); $i++ ){
        if( $_G['setting']['rewritestatus'][$i] == 'portal_topic' ){
            $portal_topic = $_G['setting']['rewriterule']['portal_topic'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'portal_article' ){
            $portal_article = $_G['setting']['rewriterule']['portal_article'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_forumdisplay' ){
            $forum_forumlist = $_G['setting']['rewriterule']['forum_forumdisplay'];
        }else if( $_G['setting']['rewritestatus'][$i] == 'forum_viewthread' ){
            $forum_view = $_G['setting']['rewriterule']['forum_viewthread'];
        }
    }

    $txt_filename = DISCUZ_ROOT.'sitemap.txt';
    file_put_contents( $txt_filename, $localHost."\r\n" );
    $shengyuNum = $_G['cache']['plugin']['dnr_sitemap']['maxtxtcount'];
    if(C::t('#dnr_sitemap#dnr_var')->get_var("enableportal")){
        /* portal */
        if( $portal_article != null ){
            $articles = C::t('#dnr_sitemap#dnr_portal_article_title')->fetch_limit_by_catid_num( C::t('#dnr_sitemap#dnr_var')->get_var("selectportal"), C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$shengyuNum/2);
            //debug($articles);
            $shengyuNum = $shengyuNum - count($articles);
            foreach($articles as $article ){
                $path = str_replace('{id}',$article['aid'],$portal_article);
                $path = str_replace('{page}',1,$path);
                file_put_contents( $txt_filename, $localHost.$path."\r\n", FILE_APPEND );
            }
        }
    }
    if(C::t('#dnr_sitemap#dnr_var')->get_var("enableforum") && $shengyuNum>0 ){
        /* forum */
        if( $forum_view != null ){
            $articles = C::t('#dnr_sitemap#dnr_forum_post')->fetch_limit_by_catid_num(C::t('#dnr_sitemap#dnr_var')->get_var("selectforum"),C::t('#dnr_sitemap#dnr_var')->get_var("generate_all_time")-1814400,$shengyuNum);

            foreach($articles as $article ){
                $path = str_replace('{fid}',$article['fid'],$forum_view);
                $path = str_replace('{tid}',$article['tid'],$path);
                $path = str_replace('{page}',1,$path);
                $path = str_replace('{prevpage}',1,$path);

                file_put_contents($txt_filename, $localHost.$path."\r\n", FILE_APPEND);
            }
        }
    }

}

function add_log( $content ){
    $filename = DISCUZ_ROOT.'/source/plugin/dnr_sitemap/log.txt';
    $content = $content."\t".date("Y-m-d H:i:s")."\r\n";
    file_put_contents($filename,$content,FILE_APPEND);
}


