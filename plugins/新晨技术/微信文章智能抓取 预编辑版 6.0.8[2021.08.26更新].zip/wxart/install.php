<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.4
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: install.php 2020/12/31 ������ $
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='wxvideo' OR tag='wxaudio' OR tag='wxvid' OR tag='wxmusic'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
$query = C::t('common_usergroup')->range_orderby_credit();
$groupids = array();foreach($query as $group) {
	$groupids[] = $group['groupid'];
}
$permnew = implode("\t", $groupids);
$data = array('tag' => 'wxvideo', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<iframe frameborder="0" class="wxvideo" width="677" height="498" src="http://v.qq.com/txp/iframe/player.html?origin=https%3A%2F%2Fmp.weixin.qq.com&chid=17&vid={1}&autoplay=false&full=true&show1080p=false&isDebugIframe=false" allowfullscreen="" scrolling="no"></iframe>', 'example'=>'[wxvideo]1[wxvideo]', 'explanation'=>'weixin video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxaudio', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p><audio controls="controls" style="width:100%;max-width:667px;" src="{1}">'.lang('plugin/wxart', 'msg_error_browser_too_low').'</audio></p>', 'example'=>'[wxaudio]1[wxaudio]', 'explanation'=>'weixin audio tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxvid', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p class="wxNewPlayer" style="padding-bottom:75%;"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxvid={1}" allowfullscreen="" scrolling="no"></iframe></p>', 'example'=>'[wxvid]1[wxvid]', 'explanation'=>'weixin new video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxmusic', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p class="wxMusicPlayer"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxmid={1}" scrolling="no"></iframe></p>', 'example'=>'[wxmusic]1[wxmusic]', 'explanation'=>'weixin music tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);

$data = array('tag' => 'wxtv', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 3, 'nest' => 1, 'replacement'=>'<iframe frameborder="0" class="wxvideo" width="{1}" height="{2}" src="http://v.qq.com/txp/iframe/player.html?origin=https%3A%2F%2Fmp.weixin.qq.com&chid=17&vid={3}&autoplay=false&full=true&show1080p=false&isDebugIframe=false" allowfullscreen="" scrolling="no"></iframe>', 'example'=>'[wxtv=1,2]3[wxvideo]', 'explanation'=>'weixin video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxv', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 2, 'nest' => 1, 'replacement'=>'<p class="wxNewPlayer" style="padding-bottom:{1}%;"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxvid={2}" allowfullscreen="" scrolling="no"></iframe></p>', 'example'=>'[wxvid=1]2[wxvid]', 'explanation'=>'weixin new video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);

updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>