<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxart.inc.php 2020/6/12 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//error_reporting(E_ALL ^ E_NOTICE);
set_time_limit(0);
$_GET['url'] = trim(str_replace("\n", "", $_GET['url']));
$_GET['wysiwyg'] = abs(intval($_GET['wysiwyg']));
$_GET['fid'] = abs(intval($_GET['fid']));
$_GET['formhash'] = trim($_GET['formhash']);
$_GET['simple'] = abs(intval($_GET['simple']? $_GET['simple'] : 2));
$_GET['allowhtml'] = abs(intval($_GET['allowhtml']));
$_GET['isportal'] = abs(intval($_GET['isportal']));
$_GET['aid'] = abs(intval($_GET['aid']));
$_GET['catid'] = abs(intval($_GET['catid']));
$params = array('get'=>$_GET, 'post'=>$_POST, 'global'=>$_G);
require_once('lib/class_ntcore.php');
if(strpos($_GET['url'], 'videoplayer')!==false){
	$ntcore = new ntcore(new nvparser(new nvcatcher($params), new nvresult()));
	$ntcore->display();
}elseif(strpos($_GET['url'], 'get_song_info')!==false){
    $ntcore = new ntcore(new nmparser(new nmcatcher($params), new nvresult()));
    $ntcore->display();
}elseif(isset($_GET['wxvid'])&&!empty($_GET['wxvid'])){
	$mediatype='video';
	include template('wxart:media');
}elseif(isset($_GET['wxmid'])&&!empty($_GET['wxmid'])){
	include template('wxart:media');
}else{
	$ntcore = $_GET['isportal']==1? new ntcore(new wxpparser(new wxcatcher($params), new wxpresult())): new ntcore(new wxxparser(new wxcatcher($params), new wxxresult()));
	$ntcore->display();
}
//From: Dism��taobao��com
?>