<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: uninstall.php 2020/7/23 ������ $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='wxvideo' OR tag='wxaudio' OR tag='wxvid' OR tag='wxv' OR tag='wxtv' OR tag='wxmusic'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>