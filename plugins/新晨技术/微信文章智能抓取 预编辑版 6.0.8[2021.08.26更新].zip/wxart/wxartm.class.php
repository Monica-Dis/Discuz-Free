<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxartm.class.php 2020/6/12 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_wxart {
	function mobileplugin_wxart(){
	}
	function global_footer_mobile(){
		global $_G;
		if($_G['cache']['plugin']['wxart']['open_mobile']){
			if(strtolower($_G['mod'])=='post'){
				$wxart_usergroups = unserialize($_G['cache']['plugin']['wxart']['usergroups']);
				$wxart_forums = unserialize($_G['cache']['plugin']['wxart']['forums']);
				$hash= md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
				$ret = '';
				if(in_array($_G['fid'], $wxart_forums)){
					$ret = in_array($_G['groupid'], $wxart_usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/post_mobile.css"/><script type="text/javascript">var wxformhash=\''.FORMHASH.'\',uploadhash=\''.$hash.'\',_fid=parseInt('.$_G['fid'].'),wxlang={\'title\':\''.lang('plugin/wxart', 'post_plugin_name') .'\',\'wxart_title\':\''.lang('plugin/wxart', 'post_plugin_name').'\',\'error\':\''.lang('plugin/wxart', 'msg_error_url').'\',\'catching\':\''.lang('plugin/wxart', 'msg_js_catching').'\',\'click_to_catch\':\''.lang('plugin/wxart', 'post_btn_m_text').'\',\'post_bbcode_prompt\':\''.lang('plugin/wxart', 'post_bbcode_prompt') .'\'};</script><script type="text/javascript" src="source/plugin/wxart/static/js/post_mobile.js"></script>' : '';
				}
				return $ret;
			}
		}
	}
}
class mobileplugin_wxart_forum extends mobileplugin_wxart{
	function viewthread_bottom_mobile(){
		return '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/forum.css"/><script type="text/javascript" src="source/plugin/wxart/static/js/forum.js"></script><script type="text/javascript">formatPost();</script>';
	}
}
//From: Dism��taobao��com
?>