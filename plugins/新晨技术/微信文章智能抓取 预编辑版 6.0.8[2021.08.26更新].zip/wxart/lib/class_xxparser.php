<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: parser.class.php 2020/6/12 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class xxparser implements iparser{
	public $catcher;
	protected $result;
	public function __construct(icatcher $catcher, iresult $result){
		$this->catcher = $catcher;
		$this->result = $result;
	}
	abstract function valid();
	abstract function display();
}