<?php
/**
 *      reuse forum_upload
 *      version: 4.5.9
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: xxupload.class.php 2020/12/17 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class xxupload {

	var $uid;
	var $aid;
	var $simple;
	var $statusid;
	var $attach;
	var $error_sizelimit;
	var $getaid;

	function xxupload() {
	}

	function init($getaid = 0, $attach, $params) {

		$this->uid = $params['global']['uid'];
		$swfhash = md5(substr(md5($params['global']['config']['security']['authkey']), 8).$this->uid);
		$this->aid = 0;
		$this->getaid = $getaid;
		$this->simple = !empty($params['get']['simple']) ? $params['get']['simple'] : 0;

		if($params['get']['uploadhash'] != $swfhash) {
			return $this->uploadmsg(10);
		}

		$upload = new discuz_upload();
		$upload->init($_FILES['Filedata']);
		//ǿдupload
		$upload->type = $upload->check_dir_type('forum');
		$upload->extid = 0;
		$upload->forcename = '';

		$attach['size'] = intval($attach['size']);
		$attach['name'] =  trim($attach['name']);
		$attach['thumb'] = '';
		$attach['ext'] = $upload->fileext($attach['name']);

		$attach['name'] =  dhtmlspecialchars($attach['name'], ENT_QUOTES);
		if(strlen($attach['name']) > 90) {
			$attach['name'] = cutstr($attach['name'], 80, '').'.'.$attach['ext'];
		}

		$attach['isimage'] = $upload->is_image_ext($attach['ext']);
		$attach['extension'] = $upload->get_target_extension($attach['ext']);
		$attach['attachdir'] = $upload->get_target_dir($upload->type, $extid);
		$attach['attachment'] = $attach['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$attach['extension'];
		$attach['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$attach['attachment'];
		$upload->attach = & $attach;
		$this->attach = &$upload->attach;

		$allowupload = !$params['global']['group']['maxattachnum'] || $params['global']['group']['maxattachnum'] && $params['global']['group']['maxattachnum'] > getuserprofile('todayattachs');;
		if(!$allowupload) {
			return $this->uploadmsg(6);
		}

		if($params['global']['group']['attachextensions'] && (!preg_match("/(^|\s|,)".preg_quote($upload->attach['ext'], '/')."($|\s|,)/i", $params['global']['group']['attachextensions']) || !$upload->attach['ext'])) {
			return $this->uploadmsg(1);
		}

		if(empty($upload->attach['size'])) {
			return $this->uploadmsg(2);
		}

		if($params['global']['group']['maxattachsize'] && $upload->attach['size'] > $params['global']['group']['maxattachsize']) {
			$this->error_sizelimit = $params['global']['group']['maxattachsize'];
			return $this->uploadmsg(3);
		}

		loadcache('attachtype');
		if($params['global']['fid'] && isset($params['global']['cache']['attachtype'][$params['global']['fid']][$upload->attach['ext']])) {
			$maxsize = $params['global']['cache']['attachtype'][$params['global']['fid']][$upload->attach['ext']];
		} elseif(isset($params['global']['cache']['attachtype'][0][$upload->attach['ext']])) {
			$maxsize = $params['global']['cache']['attachtype'][0][$upload->attach['ext']];
		}
		if(isset($maxsize)) {
			if(!$maxsize) {
				$this->error_sizelimit = 'ban';
				return $this->uploadmsg(4);
			} elseif($upload->attach['size'] > $maxsize) {
				$this->error_sizelimit = $maxsize;
				return $this->uploadmsg(5);
			}
		}

		if($upload->attach['size'] && $params['global']['group']['maxsizeperday']) {
			$todaysize = getuserprofile('todayattachsize') + $upload->attach['size'];
			if($todaysize >= $params['global']['group']['maxsizeperday']) {
				$this->error_sizelimit = 'perday|'.$params['global']['group']['maxsizeperday'];
				return $this->uploadmsg(11);
			}
		}
		updatemembercount($params['global']['uid'], array('todayattachs' => 1, 'todayattachsize' => $upload->attach['size']));
		if(!copy($attach['tmp_name'], $attach['target'])){
			return $this->uploadmsg(8);
		}
		$thumb = $remote = $width = 0;
		if($params['get']['type'] == 'image' && !$upload->attach['isimage']) {
			return $this->uploadmsg(7);
		}
		if($upload->attach['isimage']) {
			$upload->attach['imageinfo'] = $upload->get_image_info($upload->attach['target'], true);
			if(!in_array($upload->attach['imageinfo']['2'], array(1,2,3,6))) {
				return $this->uploadmsg(7);
			}
			if($params['global']['setting']['showexif']) {
				require_once libfile('function/attachment');
				$exif = getattachexif(0, $upload->attach['target']);
			}
			if($params['global']['setting']['thumbsource'] || $params['global']['setting']['thumbstatus']) {
				require_once libfile('class/image');
				$image = new image;
			}
			if($params['global']['setting']['thumbsource'] && $params['global']['setting']['sourcewidth'] && $params['global']['setting']['sourceheight']) {
				$thumb = $image->Thumb($upload->attach['target'], '', $params['global']['setting']['sourcewidth'], $params['global']['setting']['sourceheight'], 1, 1) ? 1 : 0;
				$width = $image->imginfo['width'];
				$upload->attach['size'] = $image->imginfo['size'];
			}
			if($params['global']['setting']['thumbstatus']) {
				$thumb = $image->Thumb($upload->attach['target'], '', $params['global']['setting']['thumbwidth'], $params['global']['setting']['thumbheight'], $params['global']['setting']['thumbstatus'], 0) ? 1 : 0;
				$width = $image->imginfo['width'];
			}
			if($params['global']['setting']['thumbsource'] || !$params['global']['setting']['thumbstatus']) {
				list($width) = @getimagesize($upload->attach['target']);
			}
		}
		if($params['get']['type'] != 'image' && $upload->attach['isimage']) {
			$upload->attach['isimage'] = -1;
		}
		$this->aid = $aid = getattachnewaid($this->uid);
		$insert = array(
			'aid' => $aid,
			'dateline' => $params['global']['timestamp'],
			'filename' => dhtmlspecialchars(censor($upload->attach['name'])),
			'filesize' => $upload->attach['size'],
			'attachment' => $upload->attach['attachment'],
			'isimage' => $upload->attach['isimage'],
			'uid' => $this->uid,
			'thumb' => $thumb,
			'remote' => $remote,
			'width' => $width,
		);
		C::t('forum_attachment_unused')->insert($insert);
		if($upload->attach['isimage'] && $params['global']['setting']['showexif']) {
			C::t('forum_attachment_exif')->insert($aid, $exif);
		}
		return $this->uploadmsg(0);
	}

	function uploadmsg($statusid) {
		$this->error_sizelimit = !empty($this->error_sizelimit) ? $this->error_sizelimit : 0;
		if($this->getaid) {
			$this->getaid = $statusid ? -$statusid : $this->aid;
			return '';
		}
		if($this->simple == 1) {
			return 'DISCUZUPLOAD|'.$statusid.'|'.$this->aid.'|'.$this->attach['isimage'].'|'.$this->error_sizelimit;
		} elseif($this->simple == 2) {
			return 'DISCUZUPLOAD|'.($params['get']['type'] == 'image' ? '1' : '0').'|'.$statusid.'|'.$this->aid.'|'.$this->attach['isimage'].'|'.($this->attach['isimage'] ? $this->attach['attachment'] : '').'|'.$this->attach['name'].'|'.$this->error_sizelimit;
		} else {
			return $statusid ? -$statusid : $this->aid;
		}
		return '';
	}
}
//From: dis'.'m.tao'.'bao.com
?>