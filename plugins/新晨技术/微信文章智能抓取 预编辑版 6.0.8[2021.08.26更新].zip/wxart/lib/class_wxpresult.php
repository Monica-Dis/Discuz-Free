<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxpresult.class.php 2020/6/12 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxpresult extends xxresult implements iresult{
	public $msg_successs = 'msg_success';
	public $msg_error = 'msg_error';
	public $msg_error_url = 'msg_error_url';
	public $msg_error_catch_or_expired = 'msg_error_catch_or_expired';
	public $msg_error_formhash = 'msg_error_formhash';
	public $article_category_empty = 'article_category_empty';
	public $article_edit_nopermission = 'article_edit_nopermission';
	public $msg_error_article_is_none = 'msg_error_article_is_none';
	 
	public function __construct(){
		parent::__construct();
	}
	public function setMsg($msg = self::MSG_SUCCESSS){
		$this->msg = lang('plugin/wxart', $msg);
	}
}
//From: Dism��taobao��com
?>