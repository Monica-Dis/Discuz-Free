<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.8
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: class_wxcatcher.php 2021/8/26 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxcatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$html = dfsockopen($this->params['get']['url']);
			$this->html = str_replace ( array ("\r", "\n", "\t", "   " ), "", $html );
		}
	}
	public function getTitle(){
		$title = '';
		if(empty($this->html)) return $title;
		preg_match('/<title>(.+?)<\/title>/', $this->html, $matches);
		$title = xxcommon::isDefined($matches[1])? trim(strip_tags($matches[1])) : '';
		if(empty($title)){
			preg_match('/msg_title\s*=\s*(\'|")(.+?)(\\1)/', $this->html, $matches);
			$title = xxcommon::isDefined($matches[2])? trim(strip_tags($matches[2])) : '';
		}
		return $title;
	}
	public function getContent(){
		$content = '';
		if(empty($this->html)) return $content;
		$html = $this->html;
		if($this->params['post']['html']){
			$html = @htmlspecialchars_decode($this->params['post']['html']);
		}
		preg_match ( '/id\s*=\s*"js_content".*?>(.+?)<\/div>/is', $html, $matches );
		if(xxcommon::isDefined($matches[1])){
			return trim($matches[1]) .(strpos($this->html, 'video_source_type')!==false?'<iframe data-src="https://mp.weixin.qq.com/mp/js_mpvedio"></iframe>':'');
		}
		return $content;
	}
}
//From: Dism��taobao��com
?>