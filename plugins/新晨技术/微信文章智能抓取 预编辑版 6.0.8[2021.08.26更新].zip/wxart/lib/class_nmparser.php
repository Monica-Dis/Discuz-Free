<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 6.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxparser.class.php 2020/6/12 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class nmparser extends xxparser implements iparser{
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function getContent(){
		if(xxcommon::isDefined($this->catcher->getContent())){
			$videojson = @json_decode($this->catcher->getContent(), true);
			$videojson = @json_decode($videojson['resp_data'], true);
			if($videojson && $videojson['resp_data']['ret'] == 0){
				$musicurl = $videojson['songlist'][0]['song_play_url'];
				return array('url'=>$musicurl, 'singer'=>$videojson['songlist'][0]['singer_name'], 'song'=>$videojson['songlist'][0]['song_name']);
			}
		}
		return '';
	}
	public function display(){
		$result = array(
			'content' => $this->getContent()
		);
		$this->result->displaySuccessResult($result);
	}
}
//From: Dism��taobao��com
?>