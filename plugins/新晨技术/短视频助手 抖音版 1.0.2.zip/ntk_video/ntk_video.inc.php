<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: ntk_video.inc.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//error_reporting(E_ALL ^ E_NOTICE);
set_time_limit(0);
$_GET['url'] = trim(str_replace("\n", "", $_GET['url']));
$_GET['wysiwyg'] = abs(intval($_GET['wysiwyg']));
$_GET['fid'] = abs(intval($_GET['fid']));
$_GET['formhash'] = trim($_GET['formhash']);
$_GET['simple'] = abs(intval($_GET['simple']));
$_GET['simple'] = $_GET['simple']? $_GET['simple'] : 2;
$params = array('get'=>$_GET, 'global'=>$_G);
require_once('lib/class_ntcore.php');
if(strpos($_GET['url'], 'svid')!==false){
	$ntcore = new ntcore(new dvvparser(new dvvcatcher($params), new dvresult()));
	$ntcore->display();
}elseif(preg_match('/^(http|https):\/\/(v\.douyin|www\.iesdouyin)\.com/', $_GET['url'])){
	$ntcore = new ntcore(new dvparser(new dvcatcher($params), new dvresult()));
	$ntcore->display();
}elseif(isset($_GET['vid'])){
	include template('ntk_video:media');
}else{
	$ntcore = new ntcore(new ksparser(new kscatcher($params), new dvresult()));
	$ntcore->display();
}
//From: Dism��taobao-com
?>