<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: ntk_video.class.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_ntk_video{
	function __construct(){
	}
}

class plugin_ntk_video_forum extends plugin_ntk_video{
	function post_editorctrl_left(){
		global $_G;
		$usergroups = unserialize($_G['cache']['plugin']['ntk_video']['usergroups']);
		$forums = unserialize($_G['cache']['plugin']['ntk_video']['forums']);
		$ret = '';
		if(in_array($_G['fid'], $forums)){
			$ret = in_array($_G['groupid'], $usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_video/static/css/post.css"/><script type="text/javascript">var vFormHash=\''.FORMHASH.'\',vLang={\'title\':\''.lang('plugin/ntk_video', 'post_bbcode_prompt') .'\',\'btn_text\':\''.lang('plugin/ntk_video', 'post_btn_text') .'\',\'error\':\''.lang('plugin/ntk_video', 'msg_error_url').'\',\'catching\':\''.lang('plugin/ntk_video', 'msg_js_catching').'\'};</script><script type="text/javascript" src="source/plugin/ntk_video/static/js/post.js"></script><a id="ex_ntkv" onclick="bindNtkVideo('.$_G['fid'].')" title="'.lang('plugin/ntk_video', 'post_plugin_name') .'" href="javascript:;">'.lang('plugin/ntk_video', 'post_plugin_s_name') .'</a>' : '';
		}
		return $ret;
	}
	
	function viewthread_bottom(){
		global $_G;
		$autoplay = intval($_G['cache']['plugin']['ntk_video']['auto_play']);
		$showposter = intval($_G['cache']['plugin']['ntk_video']['show_poster']);
		$html = '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_video/static/css/forum.css"/><script type="text/javascript" src="source/plugin/ntk_video/static/js/forum.js"></script>';
		$html .= '<script type="text/javascript">var ntkAutoPlay='.$autoplay.',ntkShowPoster='.$showposter.';formatVideoPlayer();</script>';
		return $html;
	}
}
//From: Dism��taobao-com
?>