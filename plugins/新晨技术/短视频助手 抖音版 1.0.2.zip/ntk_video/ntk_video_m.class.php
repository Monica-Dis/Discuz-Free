<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: ntk_video_m.class.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_ntk_video {
	function mobileplugin_ntk_video(){
	}
	function global_footer_mobile(){
		global $_G;
		if($_G['cache']['plugin']['ntk_video']['open_mobile']){
			if(strtolower($_G['mod'])=='post'){
				$usergroups = unserialize($_G['cache']['plugin']['ntk_video']['usergroups']);
				$forums = unserialize($_G['cache']['plugin']['ntk_video']['forums']);
				$hash= md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
				$ret = '';
				if(in_array($_G['fid'], $forums)){
					$ret = in_array($_G['groupid'], $usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_video/static/css/post_mobile.css"/><script type="text/javascript">var vFormHash=\''.FORMHASH.'\',vUploadHash=\''.$hash.'\',vFid=parseInt('.$_G['fid'].'),vLang={\'title\':\''.lang('plugin/ntk_video', 'post_plugin_name') .'\',\'ntk_video_title\':\''.lang('plugin/ntk_video', 'post_plugin_name').'\',\'error\':\''.lang('plugin/ntk_video', 'msg_error_url').'\',\'catching\':\''.lang('plugin/ntk_video', 'msg_js_catching').'\',\'click_to_catch\':\''.lang('plugin/ntk_video', 'post_btn_m_text').'\',\'post_bbcode_prompt\':\''.lang('plugin/ntk_video', 'post_bbcode_prompt').'\'};</script><script type="text/javascript" src="source/plugin/ntk_video/static/js/post_mobile.js"></script>' : '';
				}
				return $ret;
			}
		}
	}
}
class mobileplugin_ntk_video_forum extends mobileplugin_ntk_video{
	function viewthread_bottom_mobile(){
		global $_G;
		$autoplay = intval($_G['cache']['plugin']['ntk_video']['auto_play']);
		$showposter = intval($_G['cache']['plugin']['ntk_video']['show_poster']);
		return '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_video/static/css/forum_mobile.css"/><script type="text/javascript" src="source/plugin/ntk_video/static/js/forum.js"></script><script type="text/javascript">var ntkAutoPlay='.$autoplay.',ntkShowPoster='.$showposter.';formatVideoPlayerMobile();</script>';
	}
}
//From: Dism��taobao-com
?>