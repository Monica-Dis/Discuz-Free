<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: install.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$query = C::t('common_usergroup')->range_orderby_credit();
$groupids = array();foreach($query as $group) {
	$groupids[] = $group['groupid'];
}
$permnew = implode("\t", $groupids);
$data = array('tag' => 'dv', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 3, 'nest' => 1, 'replacement'=>'<div class="pageletReflowVideo"><div class="detail clrfix "><div class="info-box clrfix"><div class="video-info"><div class="user-info"><div class="avatar fl" data-value="{2}"></div><div class="info"><p class="name nowrap"></p></div></div><p class="desc">{1}</p></div></div><div class="video-box"><div class="video-player"><iframe frameborder="0" style="width:100%;height:100%;" src="'.$_G['siteurl'].'plugin.php?id=ntk_video&vid={3}&info={2}" allowfullscreen="" scrolling="no"></iframe></div><div class="video-player-bg"></div></div></div></div>', 'example'=>'', 'explanation'=>'video-tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'kv', 'icon' => '', 'available' => 1, 'displayorder' => 1,'params' => 3, 'nest' => 1, 'replacement'=>'<div class="pageletReflowVideo"><div class="detail clrfix "><div class="info-box clrfix"><div class="video-info"><div class="user-info"><div class="avatar fl" data-value="{2}"></div><div class="info"><p class="name nowrap"></p></div></div><p class="desc">{3}</p></div></div><div class="video-box"><div class="video-player"><video class="player" src="{1}" type="video/mp4" controls="controls" x5-playsinline="" playsinline="" webkit-playsinline="" x5-video-player-fullscreen="true" x-webkit-airplay="allow" x5-video-orientation="portraint" style="object-fit:fill;"></video></div><div class="video-player-bg"></div></div></div></div>', 'example'=>'', 'explanation'=>'video-tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>