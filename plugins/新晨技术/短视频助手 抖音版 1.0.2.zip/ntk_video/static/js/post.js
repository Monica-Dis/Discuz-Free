/**
 *      version: 1.0.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: post.js 2021/1/4 ����һ$
 */
function bindNtkVideo(fid){
	checkFocus();
	showNtkvMenu(fid);
}
var vAids='';
function showNtkvMenu(fid) {
	var sel, selection;
	var str = '', strdialog = 0, stitle = '';
	var ctrlid = 'ex_ntkv';
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 270;
	var menupos = '43!';
	var menutype = 'menu';
	fid = typeof(fid)=='undefined'? 0 : fid;
	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();
	if(menu) {
		if($(ctrlid).getAttribute('menupos') !== null) {
			menupos = $(ctrlid).getAttribute('menupos');
		}
		if($(ctrlid).getAttribute('menuwidth') !== null) {
			menu.style.width = $(ctrlid).getAttribute('menuwidth') + 'px';
		}
		showMenu({'ctrlid':ctrlid,'evt':'click','pos':menupos,'timeout':250,'duration':3,'drag':1});
	} else {
		str = '<p class="pbn">'+vLang['title']+'</p><p class="pbn"><textarea type="text" id="' + ctrlid + '_param_1" class="txtarea" value="" style="width:98%;" rows="4" placeholder="https://video.kuaishou.com/...\nhttps://v.kuaishou.com/...\nhttps://v.douyin.com/..."></textarea></p>';
		var menu = document.createElement('div');
		menu.id = ctrlid + '_menu';
		menu.style.display = 'none';
		menu.className = 'p_pof upf';
		menu.style.width = menuwidth + 'px';
		s = '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">��</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>'+vLang['btn_text']+'</strong></button></div></div>';
		menu.innerHTML = s;
		$(editorid + '_editortoolbar').appendChild(menu);
		showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});
	}
	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		checkFocus();
		var url = $(ctrlid + '_param_1').value;
		if(url.indexOf('v.douyin')>-1){
			url = url.match(/http(s)?:\/\/v\.douyin\.com\/[a-zA-Z0-9]+/g);
		}else if(url.indexOf('kuaishou.com')>-1){
			url = url.match(/http(s)?:\/\/[a-zA-Z0-9]+\.kuaishou\.com\/[a-zA-Z0-9\/]+/g);
		}
		showDialog('<div id="ntkVInfo" style="padding:30px;"><p class="mbn">'+vLang['catching']+'</p><p><br/><img src="' + STATICURL + 'image/common/uploading.gif" alt="" /></p></div>', 'info');
		var uploadHash='';
		try{
			var inputHashs = document.getElementsByName("hash");
			uploadHash = inputHashs[0].value;
		}catch(e){
			console.log(e);
			uploadHash = imgUpload.settings.post_params.hash;
		}
		var x = new Ajax('JSON');
		x.getJSON('plugin.php?id=ntk_video&wysiwyg='+wysiwyg+'&fid='+fid+'&uid='+discuz_uid+'&hash='+vFormHash+'&uploadhash='+uploadHash+'&type=image&url=' + encodeURIComponent(url), function(s) {
			hideMenu('fwin_dialog', 'dialog');
			if(s && s.code){
				if(500 == parseInt(s.code)){
					showDialog('<div id="alertInfo">'+s.msg+'</div>', 'alert', '', null, 0, null, '', '', 3);
					return false;
				}
				var vContent = s.data.content;
				var vTitle = s.data.title;
				vAids += '|'+s.data.aids.join('|');
				if( vAids != ''){updateImageList(1, vAids);}
				try{
					checkFocus();
					insertText((wysiwyg==1? htmlspecialcharsDecode(vContent.replace(/\{n\}/g, "\r\n")) : vContent.replace(/\{n\}/g, "\r\n")));
				}catch(e){console.log(e)}
				$('subject').value = htmlspecialcharsDecode(vTitle);
				return true;
			}
			showDialog('<div id="alertInfo">'+vLang['json_error']+'</div>', 'alert', '', null, 0, null, '', '', 3);
			return false;
		});
		hideMenu();
	};
}
function htmlspecialcharsDecode(str){           
	if (str.length == 0) return "";  
	str = str.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, "");
	str = str.replace(/&amp;quot;/g, '"'); 
	str = str.replace(/&amp;/g, "&"); 
	str = str.replace(/&lt;/g, "<"); 
	str = str.replace(/&gt;/g, ">"); 
	str = str.replace(/&nbsp;/g, " "); 
	str = str.replace(/&#39;/g, "'");
	str = str.replace(/&quot;/g, '"');
	str=str.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, "");
	return str;  
}
