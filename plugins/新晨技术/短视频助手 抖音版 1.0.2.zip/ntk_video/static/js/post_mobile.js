/**
 *      version: 1.0.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: post_mobile.js 2020/12/14 ����һ $
 */
jQuery(function(){
	$('<div id="ntkv_box"><textarea id="ex_ntkv_url" class="txt" rows="2" style="display:none;" placeholder="'+vLang['post_bbcode_prompt']+'"></textarea><p id="ex_ntkv_tip"></p></div><input id="ex_ntkv" type="button" onclick="bindNtkVideo('+vFid+')" value="'+vLang['title']+'"/>').insertAfter('#imglist');
});
function bindNtkVideo(fid){
	var ctrlid = 'ex_ntkv';
	fid = isUndefined(fid)? 0 : fid;
	var vUrl=$('#'+ctrlid+'_url');
	var vBtn=$('#'+ctrlid);
	if(vUrl.is(':hidden')){
		vUrl.slideDown();
		vBtn.val(vLang['click_to_catch']);
	}else{
		$('#ex_ntkv').attr("disabled", true);
		var url=vUrl.val();
		if(url.indexOf('v.douyin')>-1){
			url = url.match(/http(s)?:\/\/v\.douyin\.com\/[a-zA-Z0-9]+/g);
		}else if(url.indexOf('kuaishou.com')>-1){
			url = url.match(/http(s)?:\/\/[a-zA-Z0-9]+\.kuaishou\.com\/[a-zA-Z0-9\/]+/g);
		}
		vBtn.val(vLang['catching']);
		$.getJSON('plugin.php?id=ntk_video&wysiwyg=0&uid='+discuz_uid+'&hash='+vFormHash+'&uploadhash='+vUploadHash+'&fid='+fid+'&simple=2&url=' + encodeURIComponent(url), function(s){
			if(500 == parseInt(s.code)){
				showTip(s.msg);
				return false;
			}
			var vContent = s.data.content;
			var vTitle = s.data.title;
			var vAids = s.data.aids;
			var vImgs = s.data.imgs;
			var txa = $('textarea[name="message"]');
			txa.val(htmlspecialcharsDecode(vContent.replace(/\{n\}/g, "\r\n")));
			$('input[name="subject"]').val(vTitle);
			if( vAids.length>0 ){
				for(var j=0;j<vAids.length;j++){
					$('#imglist').append('<li><span aid="'+vAids[j]+'" class="del"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_'+vAids[j]+'" src="'+vImgs[j]+'" /></a></span><input type="hidden" name="attachnew['+vAids[j]+'][description]" /></li>');
				}
			}
			$('#postsubmit').removeClass('btn_pn_grey').addClass('btn_pn_blue').attr('disable', 'false');
			vUrl.val('');
			vUrl.slideUp();
			vBtn.val(vLang['title']);
			$('#ex_ntkv').attr("disabled", false);
		})
	}
}
function showTip(tip){
	var o = $('#ex_ntkv_tip');
	o.slideDown();
	o.html(tip);
	$('#ex_ntkv').val(vLang['click_to_catch']);
	$('#ex_ntkv').attr("disabled", false);
	setTimeout(function(){$('#ex_ntkv_tip').slideUp()},3000);
}
function htmlspecialcharsDecode(str){           
	if (str.length == 0) return ""; 
	str = str.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, "");
	str = str.replace(/&amp;quot;/g, "'"); 
	str = str.replace(/&amp;/g, "&"); 
	str = str.replace(/&lt;/g, "<"); 
	str = str.replace(/&gt;/g, ">"); 
	str = str.replace(/&nbsp;/g, " "); 
	str = str.replace(/&#39;/g, "\'"); 
	str = str.replace(/&quot;/g, "\""); 
	str=str.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig, "");
	return str;  
}