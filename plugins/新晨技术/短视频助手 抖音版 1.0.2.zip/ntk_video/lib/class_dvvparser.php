<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: dvvparser.class.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class dvvparser extends xxparser implements iparser{
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function getContent(){
		return $this->catcher->getContent();
	}
	public function display(){
		$content = $this->getContent();
		echo str_replace('http:', 'https:', $content);
		exit();
	}
}
//From: Dism��taobao-com
?>