<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: xxcatcher.class.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class xxcatcher implements icatcher{
	public $params;
	public $data;
	public function __construct($params = array()){
		$this->params = $params;
		$this->data = array();
	}
	abstract function getData();
	abstract function getTitle();
	abstract function getContent();
}
//From: Dism��taobao-com
?>