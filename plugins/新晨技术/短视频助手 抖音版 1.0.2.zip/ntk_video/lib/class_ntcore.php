<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: core.classs.php 2020/12/01 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(function_exists('spl_autoload_register')) {
	spl_autoload_register(array('ntcore', 'autoload'), true, true);
} else {
	function __autoload($class) {
		return ntcore::autoload($class);
	}
}
class ntcore{
	private $parser;
	public function __construct(iparser $parser){
		$this->parser = $parser;
	}
	public function display(){
		$this->parser->valid()->getData()->display();
	}
	public static function autoload($class) {
		$class = strtolower($class);
		$file = dirname(__FILE__).DIRECTORY_SEPARATOR.'class_'.$class.'.php';
		if(file_exists($file)){
			include $file;
			return true;
		}else{
			return core::autoload($class);
		}
	}
}
//From: Dism��taobao-com
?>