<?php
/**
 *      version: 1.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: uninstall.php 2020/12/01 ���ڶ� $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='dv' OR tag='kv'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
$finish = TRUE;
?>