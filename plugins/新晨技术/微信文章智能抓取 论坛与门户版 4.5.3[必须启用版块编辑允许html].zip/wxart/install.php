<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.5.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: install.php 2020/3/26 ������ $
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='wxvideo' OR tag='wxaudio' OR tag='wxvid' OR tag='wxmusic'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
$query = C::t('common_usergroup')->range_orderby_credit();
$groupids = array();foreach($query as $group) {
	$groupids[] = $group['groupid'];
}
$permnew = implode("\t", $groupids);
$data = array('tag' => 'wxvideo', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<iframe frameborder="0" class="wxvideo" width="677" height="498" src="https://v.qq.com/txp/iframe/player.html?vid={1}&tiny=0&auto=0" allowfullscreen="" scrolling="no"></iframe>', 'example'=>'[wxvideo]1[wxvideo]', 'explanation'=>'weixin video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxaudio', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p><audio controls="controls" style="width:100%;max-width:667px;" src="{1}">'.lang('plugin/wxart', 'msg_error_browser_too_low').'</audio></p>', 'example'=>'[wxaudio]1[wxaudio]', 'explanation'=>'weixin audio tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxvid', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p class="wxNewPlayer"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxvid={1}" allowfullscreen="" scrolling="no"></iframe></p>', 'example'=>'[wxvid]1[wxvid]', 'explanation'=>'weixin new video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
$data = array('tag' => 'wxmusic', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 1, 'nest' => 1, 'replacement'=>'<p class="wxMusicPlayer"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxmid={1}" scrolling="no"></iframe></p>', 'example'=>'[wxmusic]1[wxmusic]', 'explanation'=>'weixin music tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>