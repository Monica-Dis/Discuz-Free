<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.5.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxart.class.php 2020/03/27 ������ $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_wxart{
	function __construct(){
	}
}

class plugin_wxart_forum extends plugin_wxart{
	function post_editorctrl_left(){
		global $_G;
		$wxart_usergroups = unserialize($_G['cache']['plugin']['wxart']['usergroups']);
		$wxart_forums = unserialize($_G['cache']['plugin']['wxart']['forums']);
		$wxart_allowhtml = intval($_G['forum']['allowhtml']&&$_G['group']['allowhtml']);
		$wxart_titlelen = abs(intval($_G['cache']['plugin']['wxart']['title_len']));
		$ret = '';
		if(in_array($_G['fid'], $wxart_forums)){
			$ret = in_array($_G['groupid'], $wxart_usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/post.css"/><script type="text/javascript">var wxformhash=\''.FORMHASH.'\',  wxAllowHtml=parseInt(\''.$wxart_allowhtml.'\'),wxTitleLen=parseInt(\''.$wxart_titlelen.'\'),wxlang={\'title\':\''.lang('plugin/wxart', 'post_bbcode_prompt') .'\',\'btn_text\':\''.lang('plugin/wxart', 'post_btn_text') .'\',\'error\':\''.lang('plugin/wxart', 'msg_error_url').'\',\'catching\':\''.lang('plugin/wxart', 'msg_js_catching').'\',\'dz_error_1\':\''.lang('plugin/wxart', 'msg_js_dz_error_1').'\',\'dz_error_2\':\''.lang('plugin/wxart', 'msg_js_dz_error_2').'\',\'dz_error_3\':\''.lang('plugin/wxart', 'msg_js_dz_error_3').'\',\'dz_error_4\':\''.lang('plugin/wxart', 'msg_js_dz_error_4').'\',\'dz_error_5_1\':\''.lang('plugin/wxart', 'msg_js_dz_error_5_1').'\',\'dz_error_5_2\':\''.lang('plugin/wxart', 'msg_js_dz_error_5_2').'\',\'dz_error_5_3\':\''.lang('plugin/wxart', 'msg_js_dz_error_5_3').'\',\'dz_error_5_4\':\''.lang('plugin/wxart', 'msg_js_dz_error_5_4').'\',\'dz_error_6\':\''.lang('plugin/wxart', 'msg_js_dz_error_6').'\',\'dz_error_7\':\''.lang('plugin/wxart', 'msg_js_dz_error_7').'\',\'dz_error_8\':\''.lang('plugin/wxart', 'msg_js_dz_error_8').'\',\'dz_error_9\':\''.lang('plugin/wxart', 'msg_js_dz_error_9').'\',\'dz_error_10\':\''.lang('plugin/wxart', 'msg_js_dz_error_10').'\'};</script><script type="text/javascript" src="source/plugin/wxart/static/js/post.js"></script><a id="ex_wxart" onclick="bindWxart('.$_G['fid'].')" title="'.lang('plugin/wxart', 'post_plugin_name') .'" href="javascript:;">'.lang('plugin/wxart', 'post_plugin_s_name') .'</a>' : '';
		}
		return $ret;
	}
	
	function viewthread_bottom(){
		global $_G;
		$html = '';
		if($_G['page'] == 1){
			$html .= '<script type="text/javascript" src="source/plugin/wxart/static/js/forum.js"></script>';
			if($_G['cache']['plugin']['wxart']['format_post']){
				$html .= '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/forum.css"/>';
				$html .= '<script type="text/javascript">formatPost();</script>';
			}
			if($_G['cache']['plugin']['wxart']['format_center']) $html .= '<script type="text/javascript">formatCenter();</script>';
		}
		return $html;
	}
}

class plugin_wxart_portal extends plugin_wxart{
    function portalcp_extend(){
        global $_G;
		return '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/post.css"/><script type="text/javascript">var wxformhash=\''.FORMHASH.'\',wxlang={\'title\':\''.lang('plugin/wxart', 'post_bbcode_prompt') .'\',\'btn_text\':\''.lang('plugin/wxart', 'post_btn_text').'\',\'catching\':\''.lang('plugin/wxart', 'msg_js_catching').'\',\'msg_error\':\''.lang('plugin/wxart', 'msg_error').'\'};</script><script type="text/javascript" src="source/plugin/wxart/static/js/post.js"></script><div id="exWartPortal" class="z"><a id="exWxart" onclick="bindWxartPortal()" title="'.lang('plugin/wxart', 'post_plugin_name') .'" href="javascript:;">'.lang('plugin/wxart', 'post_plugin_s_name') .'</a></div>';
	}

    function view_article_content(){
		global $_G;
		$html .= '<script type="text/javascript" src="source/plugin/wxart/static/js/forum.js"></script>';
		$html .= '<link rel="stylesheet" type="text/css" href="source/plugin/wxart/static/css/forum.css"/>';
		$html .= '<script type="text/javascript">formatPost();displayNewVideo();</script>';
		if($_G['cache']['plugin']['wxart']['format_center']) $html .= '<script type="text/javascript">formatCenter();</script>';
		return $html;
    }
}
//From: Dism_taobao-com
?>