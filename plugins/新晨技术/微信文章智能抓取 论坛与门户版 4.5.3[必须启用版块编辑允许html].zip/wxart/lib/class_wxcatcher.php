<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.4.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: mpcatcher.classs.php 2019/12/24 ���ڶ� $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxcatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$html = dfsockopen($this->params['get']['url']);
			$this->html = str_replace ( array ("\r", "\n", "\t", "   " ), "", $html );
			if(strpos($this->html,'weui-msg__title')!==false){
				$this->html = '';
			}
		}
	}
	public function getTitle(){
		$title = '';
		if(empty($this->html)) return $title;
		preg_match('/<title>(.+?)<\/title>/', $this->html, $matches);
		$title = xxcommon::isDefined($matches[1])? trim(strip_tags($matches[1])) : '';
		if(empty($title)){
			preg_match('/msg_title\s*=\s*(\'|")(.+?)(\\1)/', $this->html, $matches);
			$title = xxcommon::isDefined($matches[2])? trim(strip_tags($matches[2])) : '';
		}
		return $title;
	}
	public function getContent(){
		$content = '';
		if(empty($this->html)) return $content;
		preg_match ( '/id\s*=\s*"js_content".*?>(.+?)<\/div>/is', $this->html, $matches );
		if(xxcommon::isDefined($matches[1])){
			return trim($matches[1]);
		}
		return $content;
	}
}
//From: Dism_taobao-com
?>