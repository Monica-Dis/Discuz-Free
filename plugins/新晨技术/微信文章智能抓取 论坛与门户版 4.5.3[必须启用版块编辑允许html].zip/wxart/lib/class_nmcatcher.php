<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.4.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: mpcatcher.classs.php 2019/11/22 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class nmcatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$this->html = dfsockopen($this->params['get']['url']);
		}
	}
	public function getTitle(){}
	public function getContent(){
		return $this->html;
	}
}
//From: Dism_taobao-com
?>