<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.4.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxparser.class.php 2019/11/22 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class wxparser extends xxparser implements iparser{
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){}
	public function getTitle(){
		return $this->catcher->getTitle();
	}
	protected function filter($rules = '', $content = ''){
		if($rules){
			$customs = explode("\n", $rules);
			$filters = array();
			foreach($customs as $filter){
				$filter = trim($filter);
				if($filter){
					$filters[] = $filter;
				}
			}
			if($filters && strtolower(CHARSET) != 'utf-8'){
				$content = diconv(preg_replace($filters, '', diconv($content, 'utf-8', 'gbk//IGNORE')), 'gbk', 'utf-8');
			}elseif($filters){
				$content = preg_replace($filters, '',$content);
			}
		}
		return $content;
	}
	protected function source($source='', $content=''){
		if($source){
			preg_match('/profile_nickname">(.*?)<\/strong>/', $this->catcher->html, $nicknames);
			$profileName =  trim(strip_tags($nicknames[1]));
			preg_match('/profile_meta_value">(.*?)<\/span>/', $this->catcher->html, $ids);
			$profileId =  trim(strip_tags($ids[1]));
			$content .= str_replace(array('{$app_name}', '{$app_id}', '{$url}'), array($profileName, $profileId, @urldecode($this->catcher->params['get']['url'])), diconv($source, CHARSET, 'UTF-8'));
		}
		return $content;
	}
	protected function replaceHandler($matches){
		if(xxcommon::isDefined($matches[0])){
			if(strpos($matches[0], 'qqmusic') !== false){
				$musicid = $mid = '';
				preg_match_all('/(musicid|mid|audiourl|music_name|singer)\s*=\s*(\'|")(.*?)(\\2)/is', $matches[0], $atrrs);
				if(xxcommon::isDefined($atrrs[3][0])&&xxcommon::isDefined($atrrs[3][1])){
					$musicid = trim($atrrs[3][0]);
					$mid = trim($atrrs[3][1]);
                    return $this->formatMusic($musicid.'||'.$mid);
				}
			}elseif(strpos($matches[0], 'mpvoice') !== false){
				if(xxcommon::isDefined($matches[2])){
					preg_match('/name\s*=\s*(\'|")(.*?)(\\1)/is', $matches[0], $songs);
					$song = trim(dhtmlspecialchars($songs[2]));
					$audiourl='https://res.wx.qq.com/voice/getvoice?mediaid='.trim($matches[2]);
					return $this->formatAudio(array('url'=>$audiourl, 'info'=>$song));
				}
			}elseif(strpos($matches[0], 'iframe') !== false){
				if(xxcommon::isDefined($matches[2])){
					if(strpos($matches[2], 'readtemplate')!==false){
						preg_match_all('/(var\s*biz\s*=\s*"|var\s*mid\s*=\s*")(.*?)";|data\-mpvid\s*=\s*(\'|")(.*?)(\&|\'|"|$)/is',  $this->catcher->html, $p);
						if(xxcommon::isDefined($p[2][0])&&xxcommon::isDefined($p[4][2])){
							$p[3][0] = trim(str_replace(array('"','|',"'"), '', $p[2][0]));
							$p[3][1] = trim(str_replace(array('"','|',"'"), '', $p[2][1]));
							$p[3][2] = trim(str_replace(array('"','|',"'"), '', $p[4][2]));
							return $this->formatNewVideo("{$p[3][0]}||{$p[3][1]}||{$p[3][2]}");
						}
					}elseif(strpos($matches[2], 'vote')===false){
						preg_match('/vid=(.*?)(\&|\$|"|\'|$)/is', $matches[2], $p);
						return $this->formatVideo(trim($p[1]));
					}
				}
			}elseif(strpos($matches[0], 'img') !== false){
				if(xxcommon::isDefined($matches[2])){
					$imagestyle = '';
					preg_match('/style\s*=\s*(\'|")(.*?)(\\1)/is', $matches[0], $imgattrs);
					if(xxcommon::isDefined($imgattrs[2])){
						$imagestyle = trim($imgattrs[2]);
					}
					return $this->downloadImage(array('url'=>$matches[2], 'style'=>$imagestyle));
				}
			}
		}
		return ''; 
	}
	public function display(){}
	abstract function formatAudio($audio);
	abstract function formatMusic($music);
	abstract function formatVideo($video);
	abstract function formatNewVideo($video);
	abstract function downloadImage($image);
}
//From: Dism_taobao-com
?>