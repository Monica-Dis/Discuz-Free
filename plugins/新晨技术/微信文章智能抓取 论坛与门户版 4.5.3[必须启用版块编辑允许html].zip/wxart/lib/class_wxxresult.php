<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 3.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxresult.class.php 2019/3/7 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxxresult extends xxresult implements iresult{
	public $msg_successs = 'msg_success';
	public $msg_error = 'msg_error';
	public $msg_error_url = 'msg_error_url';
	public $msg_error_catch_or_expired = 'msg_error_catch_or_expired';
	public $msg_error_formhash = 'msg_error_formhash';
	public $msg_error_group_permission = 'msg_error_group_permission';
	public $msg_error_forum_permission = 'msg_error_forum_permission';
	public $msg_error_no_permission = 'msg_error_no_permission';
	 
	public function __construct(){
		parent::__construct();
	}
	public function setMsg($msg = self::MSG_SUCCESSS){
		$this->msg = lang('plugin/wxart', $msg);
	}
}
//From: Dism_taobao-com
?>