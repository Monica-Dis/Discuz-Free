<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 3.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: xxcatcher.classs.php 2019/3/7 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class xxcatcher implements icatcher{
	public $params;
	public $html;
	public function __construct($params = array()){
		$this->params = $params;
		$this->html = '';
	}
	abstract function getData();
	abstract function getTitle();
	abstract function getContent();
}
//From: Dism_taobao-com
?>