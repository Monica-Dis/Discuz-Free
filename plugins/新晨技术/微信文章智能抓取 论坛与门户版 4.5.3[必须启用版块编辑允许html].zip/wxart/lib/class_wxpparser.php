<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.5.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxpparser.class.php 2020/03/27 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxpparser extends wxparser implements iparser{
	private $imageResult = array('aids'=>array(), 'imgs'=>array());
	const PREFIX = 'cache/plugin/wxart';
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		require_once libfile('function/portalcp');
		if (!($this->catcher->params['global']['uid']>0)|| !checkperm('allowpost')) {
			$this->result->displayErrorResult($this->result->msg_error_no_permission);
		}
		$article = '';
		if($this->catcher->params['get']['aid']) {
			$article = C::t('portal_article_title')->fetch($this->catcher->params['get']['aid']);
			if(!$article) {
				$this->result->displayErrorResult($this->result->msg_error_article_is_none);
			}
		}
		$perm = check_articleperm($this->catcher->params['get']['catid'], $this->catcher->params['get']['aid'], $article, false, true);
		if($perm !== true) {
			$this->result->displayErrorResult($this->result->$perm);
		}
		if ($this->catcher->params['get']['hash'] != formhash()) {
			$this->result->displayErrorResult($this->result->msg_error_formhash);
		}elseif(!preg_match('/^(http|https):\/\/mp\.weixin\.qq\.com/', $this->catcher->params['get']['url'])){
			$this->result->displayErrorResult($this->result->msg_error_url);
		}
		$this->catcher->getdata($this->catcher->params['get']['url']);
		if(!xxcommon::isDefined($this->catcher->html)){
			$this->result->displayErrorResult($this->result->msg_error_catch_or_expired);
		}
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function display(){
		$result = array(
			'title'=>$this->getTitle(),
			'content' => $this->getContent(),
			'aids' => $this->getImageAids(),
			'imgs' => $this->getImages()
		);
		$this->result->displaySuccessResult($result);
	}

	public function getContent(){
		$content = $this->catcher->getContent();
		if(getglobal('clear_media', self::PREFIX)){
			$content = preg_replace(array("/<iframe(.*?)iframe>/is","/<img(.*?)>/is","/<qqmusic(.*?)qqmusic>/is","/<mpvoice(.*?)mpvoice>/is"), '', $content);
		}else{
			$content = preg_replace_callback("/<iframe.*?src\s*=\s*(\'|\")(.*?)(\\1).+?iframe>/is", function($matches){return $this->replaceHandler($matches);}, $content);
			$content = preg_replace_callback("/<qqmusic(.*?)qqmusic>/is", function($matches){return $this->replaceHandler($matches);}, $content);
			$content = preg_replace_callback("/<mpvoice.*?voice_encode_fileid=('|\")(.*?)(\\1).+?mpvoice>/is", function($matches){return $this->replaceHandler($matches);}, $content);
			$content = preg_replace_callback("/<img\s+[^>]*?src\s*=\s*('|\")?(.*?)(\\1)[^>]*?\/?\s*>/is", function($matches){return $this->replaceHandler($matches);}, $content);
		}
		if(getglobal('clear_style', self::PREFIX)){
			$content = preg_replace('/style\s*=\s*(\'|")?(.*?)(\\1)/is', '', $content);
		}
		$content = $this->filter(getglobal('custom_rules', self::PREFIX), $content);
		$content = $this->source(getglobal('show_source', self::PREFIX), $content);
		$content = dhtmlspecialchars(trim(preg_replace ("/\\n{1,}/", "{n}", $this->catcher->params['get']['wysiwyg']? '<div class="wx_rich_media_content" id="jsWxContainer">'.$content."</div>" : strip_tags(str_replace ("</p>", "</p>\n",$content)))));
		return $content;
	}
	public function getImages(){
		return $this->imageResult['imgs'];
	}
	public function getImageAids(){
		return $this->imageResult['aids'];
	}
	public function formatAudio($audio){
		return '<p><audio controls="controls" style="width:100%;max-width:667px;"><source src="'.$audio['url'].'" type="audio/mpeg">'.lang('plugin/wxartp', 'msg_error_browser_too_low').'</audio><br/>'.$audio['info'].'</p>';
	}
	public function formatMusic($music){
		return $music? '<p class="wxMusicPlayer"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxmid='.$music.'" scrolling="no"></iframe></p>':'';
    }
	public function formatVideo($video){
		return $video? '<iframe frameborder="0" class="wxvideo" width="640" height="498" src="https://v.qq.com/txp/iframe/player.html?vid='.$video.'&tiny=0&auto=0" allowfullscreen="" scrolling="no"></iframe>' : '';
	}
	public function formatNewVideo($video){
		return $video? '<p class="wxNewPlayer"><iframe frameborder="0" style="width:100%;max-width:667px;" src="plugin.php?id=wxart&wxvid='.$video.'" allowfullscreen="" scrolling="no"></iframe></p>':'';
	}
	public function downloadImage($image){
		require_once libfile('function/home');
		$upload = new discuz_upload();
		$imageurl = $image['url'];
		$imagestyle = $image['style'];
		if(strlen($imageurl)>0) {
			$u=parse_url($imageurl);
			parse_str($u['query']);
			$ext = isset($wxfmt)? $wxfmt : '';
			$ext = $ext? $ext : (isset($tp)&&$tp=='webp'?'gif':'jpg');
			$imagecontent = '';
			if(preg_match('/^(http:\/\/|\.)/i', $imageurl)) {
				$imagecontent = dfsockopen($imageurl);
			}elseif(preg_match('/^(https:\/\/|\.)/i', $imageurl)) {
				$imagecontent = xxhttp::socket($imageurl);
			} elseif(preg_match('/^('.preg_quote(getglobal('setting/attachurl'), '/').')/i', $imageurl)) {
				return $imageurl;
			}
			if(empty($imagecontent)) return '';
			$imagetmpname=$upload->get_target_filename('temp').'.'.$ext;
			$imagetmp = getglobal('setting/attachdir')."./temp/".$imagetmpname;
			if(!@$fp = fopen($imagetmp, 'wb')) {
				return '';
			} else {
				flock($fp, 2);
				fwrite($fp, $imagecontent);
				fclose($fp);
			}
			if(!file_exists($imagetmp)) {
				return '';
			}
			@chmod($imagetmp, 0644);
			$post = array('uid'=>$this->catcher->params['global']['uid'], 'hash'=>$this->catcher->params['get']['uploadhash'], 'catid'=>$this->catcher->params['get']['catid'], 'aid'=>$this->catcher->params['get']['aid']);
			$files = array('Filedata' => $imagetmp);
			$result = xxhttp::socket($this->catcher->params['global']['siteurl'].'misc.php?mod=swfupload&operation=swfupload&operation=portal', 0, $post, '', false, '', 30, true, '', 0, $files);	
			@unlink($imagetmp);
			$results = @json_decode($result, true);
			$this->imageResult['aids'][] = $results['aid'];
			$this->imageResult['imgs'][] = $results;
			return '<a href="'.$results['bigimg'].'" target="_blank"><img src="'.$results['bigimg'].'" border="0" style="max-width:100%;'.$imagestyle.'" alt=""/></a>';
		}
		return '';
	}
}
//From: Dism_taobao-com
?>