<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      version: 4.4.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: uninstall.php 2019/11/22 ������ $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='wxvideo' OR tag='wxaudio' OR tag='wxvid' OR tag='wxmusic'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>