<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.0
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: kscatcher.class.php 2019/4/26 星期五 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class kscatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$html = xxhttp::socket($this->params['get']['url'], 0, '', '', FALSE, '', 15, TRUE, 'URLENCODE', 0, array(), array('useragent'=>'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1'));
			$this->data = str_replace ( array ("\r", "\n", "\t", "   " ), "", $html );
			if(strpos($this->data,'iframe')!==false){
				$this->data = '';
			}
		}
	}
	public function getTitle(){
		if(empty($this->data)) return '';
		preg_match('/<title>(.+?)<\/title>/', $this->data, $matches);
		return xxcommon::isDefined($matches[1])? trim(strip_tags($matches[1])) : '';
	}
	public function getContent(){
		$content = '';
		if(empty($this->data)) return $content;
		preg_match ( '/data\-pagedata="(.+?)">/is', $this->data, $matches );
		if(xxcommon::isDefined($matches[1])){
			return trim(str_replace('&#34;','"',$matches[1]));
		}
		return $this->data;
	}
}
//From: Dism·taobao·com
?>