<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.4.1
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: ksparser.class.php 2020/2/6 星期四 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class ksparser extends xxparser implements iparser{
	private $imageResult = array('aids'=>array(), 'imgs'=>array());
	const PREFIX = 'cache/plugin/ntk_douyin';
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		$usergroups = unserialize(getglobal('usergroups', self::PREFIX));
		$forums = unserialize(getglobal('forums', self::PREFIX));
		if (!($this->catcher->params['global']['uid']>0)|| !checkperm('allowpost')) {
			$this->result->displayErrorResult($this->result->msg_error_no_permission);
		}elseif(!in_array(getglobal('groupid'), $usergroups) ){
			$this->result->displayErrorResult($this->result->msg_error_group_permission);
		}elseif(!in_array($this->catcher->params['get']['fid'], $forums)){
			$this->result->displayErrorResult($this->result->msg_error_forum_permission);
		}elseif ($this->catcher->params['get']['hash'] != formhash()) {
			$this->result->displayErrorResult($this->result->msg_error_formhash);
		}
		$this->catcher->getdata($this->catcher->params['get']['url']);
		if(!xxcommon::isDefined($this->catcher->html)){
			$this->result->displayErrorResult($this->result->msg_error_catch_or_expired);
		}
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function display(){
		$result = array(
			'title'=>$this->getTitle(),
			'content' => $this->getContent(),
			'aids' => $this->getImageAids(),
			'imgs' => $this->getImages()
		);
		$this->result->displaySuccessResult($result);
	}
	public function getTitle(){
		return $this->catcher->getTitle();
	}
	public function getContent(){
		$cover = $avatar = $name = $play = $desc = '';
		$content = $this->catcher->getContent();
		$contentdata = json_decode($content, true);
		if(!$contentdata){
			return '';
		}
		if(xxcommon::isDefined($contentdata['video']['poster'])){
			$cover = $contentdata['video']['poster'];
		}
		if(xxcommon::isDefined($contentdata['user']['avatar'])){
			$avatar = $contentdata['user']['avatar'];
		}
		if(getglobal('catch_image', self::PREFIX)){
			$cover = $this->downloadImage(array('url'=>$cover));
			$avatar = $this->downloadImage(array('url'=>$avatar));
		}
		if(xxcommon::isDefined($contentdata['video']['src'])){
			$play = $contentdata['video']['src'];
		}
		if(xxcommon::isDefined($contentdata['user']['name'])){
			$name = $contentdata['user']['name'];
		}
		if(xxcommon::isDefined($contentdata['user']['kwaiId'])){
			$name = $name.'(ID: '.$contentdata['user']['kwaiId'].')';
		}
		if(xxcommon::isDefined($contentdata['video']['caption'])){
			$desc = $contentdata['video']['caption'];
		}
		$newcontent = "[kwai={$play},{$cover['aid']}||{$avatar['aid']}]{$desc}@{$name}[/kwai]".$cover['html'].$avatar['html'];
		$source = getglobal('show_source', self::PREFIX);
		if(!empty($source)){
			$newcontent .= str_replace(array('{$name}', '{$url}'), array($name, @urldecode($this->catcher->params['get']['url'])), diconv($source, CHARSET, 'UTF-8'));
		}
		$newcontent = dhtmlspecialchars(trim($this->catcher->params['get']['wysiwyg']? $newcontent : strip_tags($newcontent)));
		return $newcontent;
	}
	public function getImages(){
		return $this->imageResult['imgs'];
	}
	public function getImageAids(){
		return $this->imageResult['aids'];
	}
	private function downloadImage($image){
		if(checkperm('allowpostattach')||checkperm('allowpostimage')){
			require_once libfile('function/home');
			$upload = new discuz_upload();
			$imageurl = $image['url'];
			if(strlen($imageurl)>0) {
				$u=parse_url($imageurl);
				parse_str($u['query']);
				$ext = isset($wxfmt)? $wxfmt : '';
				$ext = $ext? $ext : (isset($tp)&&$tp=='webp'?'gif':'jpg');
				$imagecontent = '';
				if(preg_match('/^(http:\/\/|\.)/i', $imageurl)) {
					$imagecontent = dfsockopen($imageurl);
				}elseif(preg_match('/^(https:\/\/|\.)/i', $imageurl)) {
					$imagecontent = xxhttp::socket($imageurl);
				} elseif(preg_match('/^('.preg_quote(getglobal('setting/attachurl'), '/').')/i', $imageurl)) {
					return $value[0];
				}
				if(empty($imagecontent)) return '';
				$imagetmpname=$upload->get_target_filename('temp').'.'.$ext;
				$imagetmp = getglobal('setting/attachdir')."./temp/".$imagetmpname;
				if(!@$fp = fopen($imagetmp, 'wb')) {
					return '';
				} else {
					flock($fp, 2);
					fwrite($fp, $imagecontent);
					fclose($fp);
				}
				if(!file_exists($imagetmp)) {
					return '';
				}
				@chmod($imagetmp, 0644);
				$post = array('uid'=>$this->catcher->params['global']['uid'], 'hash'=>$this->catcher->params['get']['uploadhash']);
				$files = array('Filedata' => $imagetmp);
				$result = xxhttp::socket($this->catcher->params['global']['siteurl'].'misc.php?mod=swfupload&operation=upload&simple='.$this->catcher->params['get']['simple'].'&type=image', 0, $post, '', false, '', 30, true, '', 0, $files);	
				@unlink($imagetmp);
				$aid = 0;
				if(is_numeric($result)){
					if($result < 0) return '';
					$aid = $result;	
				}elseif(strpos($result, 'DISCUZU')!==false){
					$results = explode('|', $result);
					$aid = isset($results[2])? intval($results[2]) : 0;	
					if(count($results)>5) $aid = isset($results[3])? intval($results[3]) : 0;	
				}else{
					return '';
				}
				$aid = intval($aid);
				if($aid > 0){
					$imageurl = getforumimg($aid, 1, 300, 300, 'fixnone');
					$imageurl = strpos($imageurl, 'http')!==false? $imageurl : $this->catcher->params['global']['siteurl'].$imageurl;
					$this->imageResult['aids'][] = $aid;
					$this->imageResult['imgs'][] = $imageurl;
					if($this->catcher->params['get']['wysiwyg']){
						return array('aid'=>$aid,'html'=>'<img src="'.$imageurl.'" border="0" aid="attachimg_'.$aid.'" alt=""/>');
					}
					return array('aid'=>$aid,'html'=>"[attachimg]{$aid}[/attachimg]");
				}
			}
		}
		return '';
	}
}
//From: Dism·taobao·com
?>