<?php
/**
 *       A plugin for user to get a video from DouYin
 *      version: 2.0
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: dyvparser.class.php 2019/3/22 星期五 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class dyvparser extends xxparser implements iparser{
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function getContent(){
		return $this->catcher->getContent();
	}
	public function display(){
		$content = $this->getContent();
		echo str_replace('http:', 'https:', $content);
		exit();
	}
}
//From: Dism·taobao·com
?>