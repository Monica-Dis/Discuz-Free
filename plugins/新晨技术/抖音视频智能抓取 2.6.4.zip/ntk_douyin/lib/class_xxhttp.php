<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.6.4
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: xxhttp.class.php 2020/04/30 星期四$
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class xxhttp{
	public static function socket($url, $limit = 0, $post = '', $cookie = '', $bysocket = FALSE, $ip = '', $timeout = 15, $block = TRUE, $encodetype  = 'URLENCODE', $position = 0, $files = array(), $options=array()) {
		$return = '';
		$matches = parse_url($url);
		$scheme = $matches['scheme'];
		$host = $matches['host'];
		$path = $matches['path'] ? $matches['path'].($matches['query'] ? '?'.$matches['query'] : '') : '/';
		$port = !empty($matches['port']) ? $matches['port'] : ($scheme == 'http' ? '80' : ($scheme == 'https' ? '443' : ''));
		$boundary = $encodetype == 'URLENCODE' ? '' : random(40);
		$useragent = isset($options['useragent'])&&$options['useragent']?$options['useragent']:'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1';
		if($post) {
			if(!is_array($post)) {
				parse_str($post, $post);
			}
			self::formatPostkey($post, $postnew);
			$post = $postnew;
		}
		if(function_exists('curl_init') && function_exists('curl_exec')) {
			$ch = curl_init();
			$httpheader = array();
			if($ip) {
				$httpheader[] = "Host: ".$host;
			}
			if($httpheader) {
				curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
			}
			curl_setopt($ch, CURLOPT_URL, $scheme.'://'.($ip ? $ip : $host).($port ? ':'.$port : '').$path);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, true);
			curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
			if($post) {
				curl_setopt($ch, CURLOPT_POST, true);
				if($encodetype == 'URLENCODE') {
					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				} else {
					foreach($post as $k => $v) {
						if(isset($files[$k])) {
							$post[$k] = '@'.$files[$k];
						}
					}
					foreach($files as $k => $file) {
						if(!isset($post[$k]) && file_exists($file)) {
							$post[$k] = '@'.$file;
						}
					}
					if(class_exists('\CURLFile')) {
						foreach($post as $k => &$v) {
							if(strpos($v, '@') !== false) {
								$v = new \CURLFile(realpath(str_replace('@', '',$v)));
							}
						}
					} elseif (defined('CURLOPT_SAFE_UPLOAD')) {
						curl_setopt($ch, CURLOPT_SAFE_UPLOAD, FALSE);
					}
					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				}
			}
			if($cookie) {
				curl_setopt($ch, CURLOPT_COOKIE, $cookie);
			}
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
			if (ini_get('open_basedir') == '' && strtolower(ini_get('safe_mode')) != 'on'){ 
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				$data = curl_exec($ch);
			}else{
				$data = self::curlRedirexec($ch);
			}
			$status = curl_getinfo($ch);
			$error = curl_error($ch);
			curl_close($ch);
			if($error || $status['http_code'] != 200) {
				return $error;
			} else {
				$GLOBALS['filesockheader'] = substr($data, 0, $status['header_size']);
				$data = substr($data, $status['header_size']);
				return !$limit ? $data : substr($data, 0, $limit);
			}
		}
		return 'need_curl_mod';
	}
	public static function followLocation($url) {
		$return = '';
		$matches = parse_url($url);
		$scheme = $matches['scheme'];
		$host = $matches['host'];
		$path = $matches['path'] ? $matches['path'].($matches['query'] ? '?'.$matches['query'] : '') : '/';
		$port = '';
		$useragent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_1_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/16D57 Version/12.0 Safari/604.1';
		if(function_exists('curl_init') && function_exists('curl_exec')) {
			$clientIp = self::getClientIp();
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $scheme.'://'.($ip ? $ip : $host).($port ? ':'.$port : '').$path);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_NOBODY, true);
			curl_setopt($ch, CURLOPT_HEADER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('CLIENT-IP:'.$clientIp,'X-FORWARDED-FOR:'.$clientIp));
			curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			$info = curl_exec($ch);
			$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
			$headers = substr($info, 0, $headerSize);
			preg_match('/location:\s*(.+?)\\n/is', $headers, $matches);
			$return = $matches[1];
		}
		return $return;
	}
	public static function curlRedirexec($ch, $return_info = false){
		static $curlloops = 0;     
		static $curlmaxloops = 20;     
		if ($curlloops++>= $curlmaxloops){     
			$curlloops = 0;     
			return "";
		}      
		$data = curl_exec($ch);
		$info = curl_getinfo($ch);
		if (strpos($info['http_code'], '30')!==false || $info['http_code'] == 0){	 
			$urlinfo = @parse_url($info['redirect_url']);
			if (!$urlinfo)     {	 
				$curlloops = 0;		 
				return $return_info? $info : $data;
			}
			$newurl = $urlinfo['scheme'] . '://' . $urlinfo['host'] . $urlinfo['path'] . ($urlinfo['query']?'?'.$urlinfo['query']:'');
			curl_setopt($ch, CURLOPT_URL, $newurl);
			return self::curlRedirexec($ch, $return_info);
		}
		$curlloops=0;
		return $return_info? $info : $data;
	}
	public static function formatPostkey($post, &$result, $key = '') {
		foreach($post as $k => $v) {
			$_k = $key ? $key.'['.$k.']' : $k;
			if(is_array($v)) {
				self::formatPostkey($v, $result, $_k);
			} else {
				$result[$_k] = $v;
			}
		}
	}
	public static function getClientIp() {
		if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP") , "127.0.0.1")) {
			$ip = getenv("HTTP_CLIENT_IP");
		} else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR") , "127.0.0.1")) {
			$ip = getenv("HTTP_X_FORWARDED_FOR");
		} else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR") , "127.0.0.1")) {
			$ip = getenv("REMOTE_ADDR");
		} else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "127.0.0.1")) {
			$ip = $_SERVER['REMOTE_ADDR'];
		} else {
			$ip = "127.0.0.1";
		}
		return $ip;
	}
}
//From: Dism·taobao·com
?>