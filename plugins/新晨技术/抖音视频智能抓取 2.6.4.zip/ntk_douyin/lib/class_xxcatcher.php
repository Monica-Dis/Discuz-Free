<?php
/**
 *      A plugin for user to get a article from douyin
 *      version: 1.0
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: xxcatcher.class.php 2019/4/25 星期四 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class xxcatcher implements icatcher{
	public $params;
	public $data;
	public function __construct($params = array()){
		$this->params = $params;
		$this->data = array();
	}
	abstract function getData();
	abstract function getTitle();
	abstract function getContent();
}
//From: Dism·taobao·com
?>