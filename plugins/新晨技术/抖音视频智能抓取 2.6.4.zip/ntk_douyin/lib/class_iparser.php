<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.0.0
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: iparser.class.php 2019/3/7 星期四 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
interface iparser{
}
//From: Dism·taobao·com
?>