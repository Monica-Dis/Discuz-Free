<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.6.5
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: dycatcher.class.php 2020/07/07 星期二 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class dycatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$html = xxhttp::followLocation($this->params['get']['url']);
			$matchs = @parse_url($html);
			if(xxcommon::isDefined($matchs['path'])){
				preg_match('/\d+/is',$matchs['path'], $matches);
				if(xxcommon::isDefined($matches[0])){
					$url="https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids={$matches[0]}&dytk=";
					$html = xxhttp::socket($url);
					$this->data = @json_decode($html, true);
				}
			}
		}
	}
	public function getTitle(){
		return isset($this->data['item_list'][0]['desc'])? $this->data['item_list'][0]['desc'] : '';
	}
	public function getContent(){
		return isset($this->data['item_list'][0])? $this->data['item_list'][0] : array();
	}
}
//From: Dism·taobao·com
?>