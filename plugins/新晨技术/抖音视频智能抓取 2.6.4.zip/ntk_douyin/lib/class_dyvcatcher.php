<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.6.5
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: dyvcatcher.class.php 2020/06/01 星期一 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class dyvcatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$url = explode('-', $this->params['get']['url']);
			if(xxcommon::isDefined($url[1])){
				$svid=$url[1];
				$this->params['get']['url'] = strlen($svid)==128? 'https://aweme.snssdk.com/aweme/v1/play/?s_vid='.$svid.'&line=0' : 'https://aweme.snssdk.com/aweme/v1/play/?video_id='.$svid.'&line=0&ratio=1080p&media_type=4&vr_type=0&improve_bitrate=0&is_play_url=1&is_support_h265=0&source=PackSourceEnum_PUBLISH';
				$this->data = xxhttp::followLocation($this->params['get']['url']);
				if(empty($this->data)){
					$this->params['get']['url'] = strlen($svid)==128? 'https://aweme.snssdk.com/aweme/v1/playwm/?s_vid='.$svid.'&line=0' : 'https://aweme.snssdk.com/aweme/v1/playwm/?video_id='.$svid.'&ratio=1080p&line=0';
					$this->data = xxhttp::followLocation($this->params['get']['url']);
				}
			}
			
		}
	}
	public function getTitle(){}
	public function getContent(){
		return $this->data;
	}
}
//From: Dism·taobao·com
?>