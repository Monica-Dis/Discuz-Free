<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.4.1
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: ntk_douyin_m.class.php 2020/2/6 星期四 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_ntk_douyin {
	function mobileplugin_ntk_douyin(){
	}
	function global_footer_mobile(){
		global $_G;
		if($_G['cache']['plugin']['ntk_douyin']['open_mobile']){
			if(strtolower($_G['mod'])=='post'){
				$usergroups = unserialize($_G['cache']['plugin']['ntk_douyin']['usergroups']);
				$forums = unserialize($_G['cache']['plugin']['ntk_douyin']['forums']);
				$hash= md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
				$ret = '';
				if(in_array($_G['fid'], $forums)){
					$ret = in_array($_G['groupid'], $usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_douyin/static/css/post_mobile.css"/><script type="text/javascript">var dyFormHash=\''.FORMHASH.'\',dyUploadHash=\''.$hash.'\',dyFid=parseInt('.$_G['fid'].'),dyLang={\'title\':\''.lang('plugin/ntk_douyin', 'post_plugin_name') .'\',\'ntk_douyin_title\':\''.lang('plugin/ntk_douyin', 'post_plugin_name').'\',\'error\':\''.lang('plugin/ntk_douyin', 'msg_error_url').'\',\'catching\':\''.lang('plugin/ntk_douyin', 'msg_js_catching').'\',\'click_to_catch\':\''.lang('plugin/ntk_douyin', 'post_btn_m_text').'\',\'post_bbcode_prompt\':\''.lang('plugin/ntk_douyin', 'post_bbcode_prompt').'\'};</script><script type="text/javascript" src="source/plugin/ntk_douyin/static/js/post_mobile.js"></script>' : '';
				}
				return $ret;
			}
		}
	}
}
class mobileplugin_ntk_douyin_forum extends mobileplugin_ntk_douyin{
	function viewthread_bottom_mobile(){
		global $_G;
		$autoplay = intval($_G['cache']['plugin']['ntk_douyin']['auto_play']);
		$showposter = intval($_G['cache']['plugin']['ntk_douyin']['show_poster']);
		return '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_douyin/static/css/forum_mobile.css"/><script type="text/javascript" src="source/plugin/ntk_douyin/static/js/forum.js"></script><script type="text/javascript">var ntkAutoPlay='.$autoplay.',ntkShowPoster='.$showposter.';formatVideoPlayerMobile();</script>';
	}
}
//From: Dism·taobao·com
?>