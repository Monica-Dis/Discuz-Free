<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.6.1
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: uninstall.php 2020/04/01 星期三 $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='DY' OR tag='kwai' OR tag='douyin'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
$finish = TRUE;
?>