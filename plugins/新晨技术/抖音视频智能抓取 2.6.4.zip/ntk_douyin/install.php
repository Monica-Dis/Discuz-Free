<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.6.5
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: install.php 2020/04/30 星期四 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$query = C::t('common_usergroup')->range_orderby_credit();
$groupids = array();foreach($query as $group) {
	$groupids[] = $group['groupid'];
}
$permnew = implode("\t", $groupids);
$data = array('tag' => 'DY', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 3, 'nest' => 1, 'replacement'=>'<div class="pageletReflowVideo"><div class="detail clrfix "><div class="video-box"><div class="video-player" style="background-color:#161823;"><iframe frameborder="0" style="width:100%;min-height:444.45px;" src="'.$_G['siteurl'].'plugin.php?id=ntk_douyin&vid={3}&info={2}" allowfullscreen="" scrolling="no"></iframe></div><div class="info-box clrfix"><div class="video-info"><div class="user-info"><div class="avatar fl" data-value="{2}"></div><div class="info"><p class="name nowrap"></p></div></div><p class="desc">{1}</p></div></div></div></div></div>', 'example'=>'', 'explanation'=>'NT douyin video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
/*$data = array('tag' => 'douyin', 'icon' => '', 'available' => 1, 'displayorder' => 0,'params' => 3, 'nest' => 1, 'replacement'=>'<div class="pageletReflowVideo"><div class="detail clrfix "><div class="video-box"><div class="video-player"><iframe frameborder="0" style="width:100%;min-height:444.45px;" src="'.$_G['siteurl'].'plugin.php?id=ntk_douyin&vid={1}&info={2}" allowfullscreen="" scrolling="no"></iframe></div><div class="info-box clrfix"><div class="video-info"><div class="user-info"><div class="avatar fl">{2}</div><div class="info"><p class="name nowrap"></p></div></div><p class="desc">{3}</p></div></div></div></div></div>', 'example'=>'', 'explanation'=>'NT douyin video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);*/
$data = array('tag' => 'kwai', 'icon' => '', 'available' => 1, 'displayorder' => 1,'params' => 3, 'nest' => 1, 'replacement'=>'<div class="pageletReflowVideo"><div class="detail clrfix "><div class="video-box"><div class="video-player"><div class="play-btn"><div class="play-btn-icon"></div></div><video class="player" src="{1}" type="video/mp4" controls="controls" x5-playsinline="" playsinline="" webkit-playsinline="" x5-video-player-fullscreen="true" x-webkit-airplay="allow" x5-video-orientation="portraint" style="object-fit:fill;display:none;"></video></div><div class="info-box clrfix"><div class="video-info"><div class="user-info"><div class="avatar fl"></div><div class="info"><p class="name nowrap"></p></div></div><p class="desc"></p></div></div></div></div></div>', 'example'=>'', 'explanation'=>'NT kaishou video tag', 'prompt'=>'', 'perm'=>$permnew);
C::t('forum_bbcode')->insert($data);
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>