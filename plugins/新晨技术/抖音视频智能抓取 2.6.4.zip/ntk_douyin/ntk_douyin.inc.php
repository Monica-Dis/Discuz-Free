<?php
/**
 *     A plugin for user to get a video from DouYin
 *      version: 2.6.1
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: ntk_douyin.inc.php 2020/04/01 星期三 $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//error_reporting(E_ALL ^ E_NOTICE);
set_time_limit(0);
$_GET['url'] = trim(str_replace("\n", "", $_GET['url']));
$_GET['wysiwyg'] = abs(intval($_GET['wysiwyg']));
$_GET['fid'] = abs(intval($_GET['fid']));
$_GET['formhash'] = trim($_GET['formhash']);
$_GET['simple'] = abs(intval($_GET['simple']));
$_GET['simple'] = $_GET['simple']? $_GET['simple'] : 2;
$params = array('get'=>$_GET, 'global'=>$_G);
require_once('lib/class_ntcore.php');
if(strpos($_GET['url'], 'svid')!==false){
	$ntcore = new ntcore(new dyvparser(new dyvcatcher($params), new dyresult()));
	$ntcore->display();
}elseif(preg_match('/^(http|https):\/\/(v\.douyin|www\.iesdouyin)\.com/', $_GET['url'])){
	$ntcore = new ntcore(new dyparser(new dycatcher($params), new dyresult()));
	$ntcore->display();
}elseif(isset($_GET['vid'])){
	include template('ntk_douyin:media');
}else{
	$ntcore = new ntcore(new ksparser(new kscatcher($params), new dyresult()));
	$ntcore->display();
}
//From: Dism·taobao·com
?>