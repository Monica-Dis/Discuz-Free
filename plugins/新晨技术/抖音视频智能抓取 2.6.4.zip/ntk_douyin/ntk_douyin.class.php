<?php
/**
 *      A plugin for user to get a video from DouYin
 *      version: 2.4.1
 *       应用更新支持：https://dism.taobao.com
*       最新插件：http://t.cn/Aiux1Jx1
 *      $Id: ntk_douyin.class.php 2020/2/6 星期四 $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_ntk_douyin{
	function __construct(){
	}
}

class plugin_ntk_douyin_forum extends plugin_ntk_douyin{
	function post_editorctrl_left(){
		global $_G;
		$usergroups = unserialize($_G['cache']['plugin']['ntk_douyin']['usergroups']);
		$forums = unserialize($_G['cache']['plugin']['ntk_douyin']['forums']);
		$iskwai = intval($_G['cache']['plugin']['ntk_douyin']['open_kwai']);
		$ret = '';
		if(in_array($_G['fid'], $forums)){
			$ret = in_array($_G['groupid'], $usergroups) && (checkperm('allowpost')||checkperm('allowreply'))? '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_douyin/static/css/post.css"/><script type="text/javascript">var dyFormHash=\''.FORMHASH.'\',dyLang={\'title\':\''.lang('plugin/ntk_douyin', 'post_bbcode_prompt') .'\',\'btn_text\':\''.lang('plugin/ntk_douyin', 'post_btn_text') .'\',\'error\':\''.lang('plugin/ntk_douyin', 'msg_error_url').'\',\'catching\':\''.lang('plugin/ntk_douyin', 'msg_js_catching').'\'};</script><script type="text/javascript" src="source/plugin/ntk_douyin/static/js/post.js"></script><a id="ex_ntdy" onclick="bindNtdy('.$_G['fid'].')" title="'.lang('plugin/ntk_douyin', 'post_plugin_name') .'" href="javascript:;">'.lang('plugin/ntk_douyin', 'post_plugin_s_name') .'</a>' : '';
			if($iskwai){
				$ret .='<a id="ex_ntks" onclick="bindNtdy('.$_G['fid'].')" title="'.lang('plugin/ntk_douyin', 'post_plugin_name_ks') .'" href="javascript:;">'.lang('plugin/ntk_douyin', 'post_plugin_s_name_ks') .'</a>';
			}
		}
		return $ret;
	}
	
	function viewthread_bottom(){
		global $_G;
		$autoplay = intval($_G['cache']['plugin']['ntk_douyin']['auto_play']);
		$showposter = intval($_G['cache']['plugin']['ntk_douyin']['show_poster']);
		$html = '<link rel="stylesheet" type="text/css" href="source/plugin/ntk_douyin/static/css/forum.css"/><script type="text/javascript" src="source/plugin/ntk_douyin/static/js/forum.js"></script>';
		$html .= '<script type="text/javascript">var ntkAutoPlay='.$autoplay.',ntkShowPoster='.$showposter.';formatVideoPlayer();</script>';
		return $html;
	}
}
//From: Dism·taobao·com
?>