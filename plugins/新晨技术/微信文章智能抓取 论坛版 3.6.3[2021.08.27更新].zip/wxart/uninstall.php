<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.6.1
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: uninstall.php 2021/1/6 ������ $
 */

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$wxs = DB::fetch_all("SELECT id FROM ".DB::table('forum_bbcode')." WHERE tag='wxvideo' OR tag='wxaudio' OR tag='wxvid' OR tag='wxmusic' OR tag='wxtv' OR tag='wxv'");
foreach($wxs as $wx){
	C::t('forum_bbcode')->delete($wx['id']);
}
updatecache(array('bbcodes', 'bbcodes_display', 'forums', 'groups'));
$finish = TRUE;
?>