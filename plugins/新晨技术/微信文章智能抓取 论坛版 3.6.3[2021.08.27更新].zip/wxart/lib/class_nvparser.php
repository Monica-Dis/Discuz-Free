<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.5.6
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxparser.class.php 2020/3/28 ������  $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class nvparser extends xxparser implements iparser{
	public function __construct(icatcher $catcher, iresult $result){
		parent::__construct($catcher, $result);
	}
	public function valid(){
		return $this;
	}
	public function getData(){
		$this->catcher->getData();
		return $this;
	}
	public function getContent(){
		$videojson = @json_decode($this->catcher->getContent());
        if($videojson && $videojson->base_resp->ret == 0){
			if($videojson->url){
				$covercontent = xxhttp::socket($videojson->url);
				@header("Expires: -1");
				@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
				@header("Pragma: no-cache");
				header('Content-type: image/jpeg');
				print_r($covercontent);
				return; 
			}
			return $videojson->url_info[0]; 
        }
        return '';
	}
	public function display(){
		$result = array(
			'content' => $this->getContent()
		);
		$this->result->displaySuccessResult($result);
	}
}
//From: Dism��taobao��com
?>