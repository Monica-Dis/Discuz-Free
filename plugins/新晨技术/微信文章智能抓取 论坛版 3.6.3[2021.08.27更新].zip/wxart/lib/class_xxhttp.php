<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: result.classs.php 2019/3/7 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class xxhttp{
	public static function socket($url, $limit = 0, $post = '', $cookie = '', $bysocket = FALSE, $ip = '', $timeout = 15, $block = TRUE, $encodetype  = 'URLENCODE', $position = 0, $files = array()) {
		$return = '';
		$matches = parse_url($url);
		$scheme = $matches['scheme'];
		$host = $matches['host'];
		$path = $matches['path'] ? $matches['path'].($matches['query'] ? '?'.$matches['query'] : '') : '/';
		$port = !empty($matches['port']) ? $matches['port'] : ($scheme == 'http' ? '80' : ($scheme == 'https' ? '443' : ''));
		$boundary = $encodetype == 'URLENCODE' ? '' : random(40);

		if($post) {
			if(!is_array($post)) {
				parse_str($post, $post);
			}
			self::formatPostkey($post, $postnew);
			$post = $postnew;
		}
		if(function_exists('curl_init') && function_exists('curl_exec')) {
			$ch = curl_init();
			$httpheader = array();
			if($ip) {
				$httpheader[] = "Host: ".$host;
			}
			if($httpheader) {
				curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
			}
			curl_setopt($ch, CURLOPT_URL, $scheme.'://'.($ip ? $ip : $host).($port ? ':'.$port : '').$path);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, true);
			if($post) {
				curl_setopt($ch, CURLOPT_POST, true);
				if($encodetype == 'URLENCODE') {
					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				} else {
					foreach($post as $k => $v) {
						if(isset($files[$k])) {
							$post[$k] = '@'.$files[$k];
						}
					}
					foreach($files as $k => $file) {
						if(!isset($post[$k]) && file_exists($file)) {
							$post[$k] = '@'.$file;
						}
					}
					if(class_exists('\CURLFile')) {
						foreach($post as $k => &$v) {
							if(strpos($v, '@') !== false) {
								$v = new \CURLFile(realpath(str_replace('@', '',$v)));
							}
						}
					} elseif (defined('CURLOPT_SAFE_UPLOAD')) {
						curl_setopt($ch, CURLOPT_SAFE_UPLOAD, FALSE);
					}
					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				}
			}
			if($cookie) {
				curl_setopt($ch, CURLOPT_COOKIE, $cookie);
			}
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
			if (ini_get('open_basedir') == '' && strtolower(ini_get('safe_mode')) != 'on'){ 
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				$data = curl_exec($ch);
			}else{
				$data = self::curlRedirexec($ch);
			}
			$status = curl_getinfo($ch);
			$error = curl_error($ch);
			curl_close($ch);
			if($error || $status['http_code'] != 200) {
				return $error;
			} else {
				$GLOBALS['filesockheader'] = substr($data, 0, $status['header_size']);
				$data = substr($data, $status['header_size']);
				return !$limit ? $data : substr($data, 0, $limit);
			}
		}
		return 'need_curl_mod';
	}
	public static function curlRedirexec($ch){
		static $curlloops = 0;     
		static $curlmaxloops = 20;     
		if ($curlloops++>= $curlmaxloops){     
			$curlloops = 0;     
			return false;
		}      
		$data = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);     
		if ($httpcode == 301 || $httpcode == 302){
			$matches = array();		 
			preg_match('/Location:(.*?)\n/', $header, $matches);		 
			$url = @parse_url(trim(array_pop($matches)));
			if (!$url)     {	 
				$curlloops = 0;		 
				return $data;
			}
			$lasturl = parse_url(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL));
			if (!$url['scheme'])
			$url['scheme'] = $lasturl['scheme'];
			if (!$url['host'])
				$url['host'] = $lasturl['host'];
			if (!$url['path'])
				$url['path'] = $lasturl['path'];
			$newurl = $url['scheme'] . '://' . $url['host'] . $url['path'] . ($url['query']?'?'.$url['query']:'');
			curl_setopt($ch, CURLOPT_URL, $newurl);
			return self::curlRedirexec($ch);
		}
		$curlloops=0;
		return $data;
	}
	public static function formatPostkey($post, &$result, $key = '') {
		foreach($post as $k => $v) {
			$_k = $key ? $key.'['.$k.']' : $k;
			if(is_array($v)) {
				self::formatPostkey($v, $result, $_k);
			} else {
				$result[$_k] = $v;
			}
		}
	}
}
//From: Dism��taobao��com
?>