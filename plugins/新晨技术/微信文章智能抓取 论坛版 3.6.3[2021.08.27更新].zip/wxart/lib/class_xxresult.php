<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: xxresult.class.php 2019/3/7 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
abstract class xxresult implements iresult{
	const SUCCESS = 200;
	const FAILURE = 500;
	const MSG_SUCCESSS = 'success'; 

	protected $code;
	protected $msg;
	protected $data;
	public function __construct(){
		$this->code = self::SUCCESS;
		$this->msg = self::MSG_SUCCESSS;
		$this->data = array();
	}
	public function setCode($code = self::SUCCESS){
		$this->code = $code;
	}
	abstract function setMsg($msg);
	public function setData($data = array()){
		$this->data = $data;
	}
	public function getResult(){
		return array('code'=>$this->code, 'msg'=>$this->msg, 'data'=>$this->data);
	}
	public function display($data = array()){
		header('Content-type:text/html;charset="utf-8"');
		if(strtolower(CHARSET) != 'utf-8'){
			$data['msg'] = diconv($data['msg'], CHARSET, 'utf-8');
		}
		echo @json_encode($data);
		@flush();
		@ob_flush();
		exit();
	}
	public function displaySuccessResult($data = array()){
		$this->setCode();
		$this->setMsg();
		$this->setData($data);
		$this->display($this->getResult());
	}
	public function displayErrorResult($msg = self::MSG_ERROR){
		$this->setCode(self::FAILURE);
		$this->setMsg($msg);
		$this->display($this->getResult());
	}
}
//From: Dism��taobao��com
?>