<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.5.2
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: mpcatcher.classs.php 2019/10/26 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class nvcatcher extends xxcatcher implements icatcher{
	public function __construct($params = array()){
		parent::__construct($params);
	}
	public function getData(){
		if($this->params['get']['url']){
			$this->html = dfsockopen($this->params['get']['url']);
		}
	}
	public function getTitle(){}
	public function getContent(){
		return $this->html;
	}
}
//From: Dism��taobao��com
?>