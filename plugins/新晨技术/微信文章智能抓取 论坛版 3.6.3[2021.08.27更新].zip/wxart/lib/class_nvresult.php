<?php
/**
 *      A plugin for user to get a article from weixin
 *      version: 3.0.0
 *      ���²����http://t.cn/Aiux1Jx1
 *      $Id: wxresult.class.php 2019/3/7 ������ $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class nvresult extends xxresult implements iresult{
	 
	public function __construct(){
		parent::__construct();
	}
	public function setMsg($msg = self::MSG_SUCCESSS){
		$this->msg = self::MSG_SUCCESSS;
	}
}
//From: Dism��taobao��com
?>