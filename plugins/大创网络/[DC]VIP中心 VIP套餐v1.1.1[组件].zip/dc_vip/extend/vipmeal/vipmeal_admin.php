<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class vipmeal_admin extends extend_admin{
	
	public function mrun(){
		global $_G;
		$vipmeal = DISCUZ_ROOT.'./source/plugin/dc_vip/data/vipmeal.config.php';
		if(submitcheck('submit')){
			$mealst = explode("\n",str_replace("\r\n","\n",dhtmlspecialchars(trim($_GET['meals']))));
			$meals = array();
			foreach($mealst as $m){
				$t = explode('|',$m);
				if(count($t)==3){
					$t[1] = dintval($t[1]);
					$t[2] = dintval($t[2]);
					if($t[0]&&$t[1]&&$t[2]){
						$meals[]=array(
							'name'=>trim($t[0]),
							'month'=>$t[1],
							'price'=>$t[2],
						);
					}
				}
			}
			$copydata = array(
				'open'=>dintval($_GET['open']),
				'meals'=>$meals,
			);
			$configdata = 'return '.var_export($copydata, true).";\n\n";
			if($fp = @fopen($vipmeal, 'wb')) {
				fwrite($fp, "<?php\n//plugin dc_vip config file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
				fclose($fp);
			}
			cpmsg($this->_lang['succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=extend', 'succeed');
		}
		$vipmeal = @include $vipmeal;
		$vipmeals = array();
		foreach($vipmeal['meals'] as $m)
			$vipmeals[] = implode('|',$m);
		$mealst = implode("\n",$vipmeals);
		showformheader('plugins&operation=config&identifier=dc_vip&pmod=extend&act=set&f=vipmeal');
		showtableheader($this->_lang['install_title']);
		showsetting($this->_lang['open'], 'open', $vipmeal['open']);
		showsetting($this->_lang['meals'], 'meals', $mealst,'textarea','','',$this->_lang['meals_msg']);
		showsubmit('submit');
		showformfooter();
	}

}
//From: Dism_taobao_com
?>