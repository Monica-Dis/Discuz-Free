<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: payok.inc.php 349 2015-01-21 10:28:15Z DISM.TAOBAO.COM $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_lang = lang('plugin/dc_pay');
showmessage($_lang['pay_succeed'],$_G['siteurl']);
?>