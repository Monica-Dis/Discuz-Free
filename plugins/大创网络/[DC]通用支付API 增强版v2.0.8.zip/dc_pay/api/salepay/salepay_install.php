<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class salepay_install extends api_install{
	public function __construct(){
		parent::__construct();
		$this->title=$this->_lang['install_title'];
		$this->des=$this->_lang['install_des'];
		$this->author=$this->_lang['install_author'];
		$this->version='v1.1.1';
		$this->logo='logo.gif';
		$this->mobile = 1;
	}
	public function install(){
		$sql = <<<EOF
CREATE TABLE `pre_dc_pay_salepay` (
  `orderid` varchar(45) NOT NULL,
  `borderid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`orderid`)
);
EOF;
runquery($sql);
		return true;
	}
	
	public function uninstall(){
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_dc_pay_salepay`;
EOF;
runquery($sql);
		return true;
	}
	
	public function upgrade($version){
		
	}

}
//From: Dism_taobao_com
?>