<?php

require '../../../../class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
$PHP_SELF = $_SERVER['PHP_SELF'];
$_G['siteurl'] = dhtmlspecialchars('http://'.$_SERVER['HTTP_HOST'].preg_replace("/\/source\/plugin\/dc_pay([\s\S]+?)\/*$/i", '', substr($PHP_SELF, 0, strrpos($PHP_SELF, '/'))).'/');
if(defined('IN_MOBILE')){
	$data = _POSTData('https://pay.salepay.cn/pay/aggregateWapPayOuter',$_POST);
}else{
	$data = _POSTData('https://pay.salepay.cn/pay/aggregateWebPayOuter',$_POST);
}
$d = json_decode($data,true);
if(substr($d['data'],4)=='http')
	header('location:'.$d['message']);
else
	echo $d['data'];


function _format_post($post, &$result, $key = '') {
	foreach($post as $k => $v) {
		$_k = $key ? $key.'['.$k.']' : $k;
		if(is_array($v)) {
			_format_post($v, $result, $_k);
		} else {
			$result[$_k] = $v;
		}
	}
}

function _POSTData($url,$post = ''){
	global $_G;
	if($post) {
		if(!is_array($post)) {
			parse_str($post, $post);
		}
		_format_post($post, $postnew);
		$post = $postnew;
	}
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_REFERER,$_G['siteurl']);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	//curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	$data = curl_exec($ch);
	return $data;
	
}
//From: Dism_taobao_com
?>