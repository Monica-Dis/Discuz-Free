<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
class salepay_admin extends api_admin{
	
	public function dosave(){
		$config = $this->getconfig();
		$d = array(
			'apikey'=>trim($_GET['apikey']),
		);
		$key = trim($_GET['signkey']);
		if($key!=substr($config['signkey'],0,1).'********'.substr($config['signkey'],-4)){
			$d['signkey']=$key;
		}else{
			$d['signkey']=$config['signkey'];
		}
		$this->saveconfig($d);
	}
	
	public function doset(){
		$config = $this->getconfig();
		$config['signkey'] = $config['signkey']?substr($config['signkey'],0,1).'********'.substr($config['signkey'],-4):'';
		showsetting($this->_lang['apikey'], 'apikey', $config['apikey'], 'text');
		showsetting($this->_lang['signkey'], 'signkey', $config['signkey'], 'text');
	}
}
//From: Dism_taobao_com
?>