<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
class wxpay_admin extends api_admin{
	
	public function dosave(){
		$config = $this->getconfig();
		$d = array(
			'mch_id'=>trim($_GET['mch_id']),
			'appid'=>trim($_GET['appid']),
			'appsecert'=>trim($_GET['appsecert']),
		);
		$key = trim($_GET['key']);
		if($key!=substr($config['key'],0,1).'********'.substr($config['key'],-4)){
			$d['key']=$key;
		}else{
			$d['key']=$config['key'];
		}
		$this->saveconfig($d);
	}
	
	public function doset(){
		$config = $this->getconfig();
		$config['key'] = $config['key']?substr($config['key'],0,1).'********'.substr($config['key'],-4):'';
		showsetting($this->_lang['appid'], 'appid', $config['appid'], 'text','','',$this->_lang['appidmsg']);
		showsetting($this->_lang['mch_id'], 'mch_id', $config['mch_id'], 'text');
		showsetting($this->_lang['key'], 'key', $config['key'], 'text','','',$this->_lang['keymsg']);
		showsetting($this->_lang['appsecert'], 'appsecert', $config['appsecert'], 'text','','',$this->_lang['appsecertmsg']);
	}
}
//From: Dism_taobao_com
?>