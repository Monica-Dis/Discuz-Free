<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
class alipayt_admin extends api_admin{
	
	public function dosave(){
		global $_G;
		$config = $this->getconfig();
		$d = array(
			'account'=>trim($_GET['account']),
		);
		if($_FILES['qrcode']) {
			$upload = new discuz_upload();
			if($upload->init($_FILES['qrcode'], 'common') && $upload->save()) {
				$d['qrcode'] = $upload->attach['attachment'];
			}
		}else{
			$d['qrcode'] = trim($_GET['qrcode']);
		}
		$this->saveconfig($d);
	}
	
	public function doset(){
		$config = $this->getconfig();
		showsetting($this->_lang['account'], 'account', $config['account'], 'text');
		showsetting($this->_lang['qrcode'], 'qrcode', $config['qrcode'], 'filetext');
	}
}
//From: Dism_taobao_com
?>