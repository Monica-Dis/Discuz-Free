<?php
define('IN_MOBILE_API', true);
require '../../../../class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
$PHP_SELF = $_SERVER['PHP_SELF'];
$_G['siteurl'] = dhtmlspecialchars('http://'.$_SERVER['HTTP_HOST'].preg_replace("/\/source\/plugin\/dc_pay([\s\S]+?)\/*$/i", '', substr($PHP_SELF, 0, strrpos($PHP_SELF, '/'))).'/');
$_lang = @include DISCUZ_ROOT.'./source/plugin/dc_pay/language/wxpay.'.currentlang().'.php';
if(empty($_lang))$_lang = @include DISCUZ_ROOT.'./source/plugin/dc_pay/language/wxpay.php';
$orderid = trim($_GET['orderid']);
$order = C::t('#dc_pay#dc_pay_order')->getbyorderid($orderid);
if(!$order)showmessage('dc_pay:error');
if($order['status']==1)dheader('location:'.$_G['siteurl'].'plugin.php?id=dc_pay:payok');
	C::import('api/pay','plugin/dc_pay',false);
	C::import('wxpay/pay','plugin/dc_pay/api',false);
	$wxpay = new wxpay_mobilepay();
	$openid= $wxpay->getopenid();
	$wxpay->setorder($orderid, $order['price'], $order['subject'], '', '','jsapi');
	$code = $wxpay->getpaycode();
	$paycodestr = json_encode($code);
	$html=<<<EOF
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/> 
    <title></title>
    <script type="text/javascript">
	function jsApiCall()
	{
		WeixinJSBridge.invoke(
			'getBrandWCPayRequest',
			{$paycodestr},
			function(res){
				if(res.err_msg == "get_brand_wcpay_request:ok" ) {
					location.href="{$_G['siteurl']}plugin.php?id=dc_pay:payok";
				}else{alert(res.err_msg);}
			}
		);
	}
	function callpay()
	{
		if (typeof WeixinJSBridge == "undefined"){
		    if( document.addEventListener ){
		        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
		    }else if (document.attachEvent){
		        document.attachEvent('WeixinJSBridgeReady', jsApiCall); 
		        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
		    }
		}else{
		    jsApiCall();
		}
	}
	</script>
</head>
<body onload = "callpay();">
</body>
</html>
EOF;
	echo $html;
	die();
?>