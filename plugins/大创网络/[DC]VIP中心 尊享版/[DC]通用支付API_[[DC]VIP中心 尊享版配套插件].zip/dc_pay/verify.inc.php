<?php
/**
 *      [Discuz!] (C)2015-2099 DARK Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: verify.inc.php 2914 2017-06-29 10:28:15Z wang11291895@163.com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$_lang = lang('plugin/dc_pay');
loadcache('dc_paysecurity');
$code = $_G['cache']['dc_paysecurity']['code'];
if(empty($code))cpmsg($_lang['securityempty'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=security', 'error');
$securitycode = getcookie('dcpaysecurity');
if(!$securitycode||authcode($securitycode)!=md5($code.FORMHASH)){
	if(submitcheck('submitcheck')){
		$securitycode = trim($_GET['securitycode']);
		if($code!=md5(md5($securitycode).$_G['cache']['dc_paysecurity']['salt']))
			cpmsg($_lang['securitycodeerror'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify', 'error');
		$authcode = authcode(md5($code.FORMHASH),'ENCODE');
		dsetcookie('dcpaysecurity', $authcode, 1800, 1, true);
	}else{
		$url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify';
		$str = '<div class="infobox"><form method="post" action="'.$url.'"><input type="hidden" name="formhash" value="'.FORMHASH.'"><input type="hidden" name="submitcheck" value="true">
					<br />'.$_lang['securitycode_1'].'<br />
					<input name="securitycode" value="" type="password"/>
					<br />
					<p class="margintop"><input type="submit" class="btn" name="submit" value="'.cplang('submit').'">
					</p></form><br /></div>';
		echo $str;
		die();
	}
	
}
if(submitcheck('delete')){
	$oid = dintval($_GET['delete'],true);
	C::t('#dc_pay#dc_pay_order')->delete($oid);
	cpmsg($_lang['delok'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify', 'succeed');
}
if($_GET['act']=='pass'){
	$oid = dintval($_GET['oid']);
	$order = C::t('#dc_pay#dc_pay_order')->fetch($oid);
	if(!$order||$order['status']!=2)cpmsg($_lang['error']);
	if(submitcheck('submit')){
		$api = C::t('#dc_pay#dc_pay_api')->fetch($order['plugin']);
		if(!$api)cpmsg($_lang['error']);
		C::t('#dc_pay#dc_pay_order')->update($order['id'],array('status'=>1,'finishdateline'=>TIMESTAMP));
		$apipath = DISCUZ_ROOT.'./source/plugin/'.$api['plugin'].'/'.$api['include'];
		if(!file_exists($apipath))cpmsg($_lang['error']);
		require_once $apipath;
		$_apiobj = $api['class'];
		$mobj = new $_apiobj();
		$method = $api['notifymethod'];
		if(in_array($method,get_class_methods($mobj))){
			$param = dunserialize($order['param']);
			$mobj->$method($order['orderid'],$param,$order['uid'],$order['username']);
		}
		cpmsg($_lang['pass'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify', 'succeed');
	}
	$param = dunserialize($order['param']);
	$payfor = explode(':',$order['payorderid']);
	require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
	$payobj = new PayMent('dc_pay');
	$payinfo = $payobj->GetPayInfo($payfor[0]); 
	$plugindata = C::t('common_plugin')->fetch_by_identifier($order['plugin']);
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify&act=pass&oid='.$order['id']);
	showtableheader($_lang['order_verify'], '');
	showtablerow('', array('width="80"'), array($_lang['order_id'],$order['orderid']));
	showtablerow('', array(), array($_lang['order_api'],$plugindata['name']?$plugindata['name']:$_lang['order_noapi']));
	showtablerow('', array(), array($_lang['order_subject'],$order['subject']));
	showtablerow('', array(), array($_lang['order_price'],$order['price'].$_lang['yuan']));
	showtablerow('', array(), array($_lang['order_username'],$order['username']));
	showtablerow('', array(), array($_lang['order_dateline'],dgmdate($order['dateline'], 'dt')));
	showtablerow('', array(), array($_lang['transfer_account'],$param['payaccount']));
	showtablerow('', array(), array($_lang['transfer_type'],$payinfo['title']?$payinfo['title']:'-'));
	showtablerow('', array(), array($_lang['transfer_payid'],$payfor[1]));
	showsubmit('submit', $_lang['pass']);
	showformfooter();
	die();
}
$perpage = 20;
$start = ($page-1)*$perpage;
$where = array();
$where['status']=2;
$vus = C::t('#dc_pay#dc_pay_order')->getrange($where,$start,$perpage,'DESC');
$count = C::t('#dc_pay#dc_pay_order')->getcount($where);
$plugins = DB::fetch_all('SELECT identifier, name FROM %t', array('common_plugin'), 'identifier');
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify');
showtableheader($_lang['order_list'], '');
showsubtitle(array('',$_lang['order_id'],$_lang['order_api'],$_lang['order_price'],$_lang['order_username'],$_lang['order_dateline'],$_lang['order_payorderid'],$_lang['caozuo']));
foreach($vus as $v){
	showtablerow('', array('width="20"'), array(
		'<input type="checkbox" class="checkbox" name="delete[]" value="'.$v['id'].'">',
		$v['orderid'],
		$plugins[$v['plugin']]?$plugins[$v['plugin']]['name']:$_lang['order_noapi'],
		$v['price']>0?$v['price']:'-',
		'<a href="home.php?mod=space&uid='.$v['uid'].'" target="_blank">'.$v['username'].'</a>',
		dgmdate($v['dateline'], 'dt'),
		$v['payorderid']?$v['payorderid']:'-',
		'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify&act=pass&oid='.$v['id'].'">'.$_lang['verify_order'].'</a>',
		)
	);
}
$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_pay&pmod=verify';
$multipage = multi($count, $perpage, $page, $mpurl);
showsubmit('submit', 'submit', 'del', '', $multipage);
showtablefooter();/*Dism_taobao-com*/
showformfooter();
?>