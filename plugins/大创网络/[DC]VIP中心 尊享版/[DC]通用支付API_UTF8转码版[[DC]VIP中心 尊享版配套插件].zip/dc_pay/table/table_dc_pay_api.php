<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dc_pay_api extends discuz_table
{
	public function __construct() {
		$this->_table = 'dc_pay_api';
		$this->_pk    = 'plugin';
		parent::__construct();
	}
}
//From: Dism·taobao·com
?>
