<?php
//plugin dc_pay config file, DO NOT modify me!
//Identify: 710612f888eae3ec8262627638dce4d2

return array (
  'wxpay' => 
  array (
    'title' => '微信支付',
    'des' => '微信扫码支付',
    'author' => '大创网络',
    'version' => 'v1.1.3',
    'logo' => 'logo.gif',
    'mobile' => 1,
    'alias' => '微信支付',
    'enable' => 1,
    'mobileenable' => 1,
  ),
  'alipay' => 
  array (
    'title' => '支付宝',
    'des' => '全球领先的独立第三方支付平台',
    'author' => '大创网络',
    'version' => 'v1.1.1',
    'logo' => 'logo.gif',
    'mobile' => 1,
    'alias' => '支付宝',
    'enable' => 1,
    'mobileenable' => 1,
  ),
);

?>
