<?php
//plugin dc_pay config file, DO NOT modify me!
//Identify: e6e1f788bf9259f6734ec6705fbff5d7

return array (
  'data' => '4354uOUNEDD11s6UgY96wWUgRq8+Y1lJehKh6OM9Ztnkvey/lgkOoWgUfFljToJrTtZueV4JSSIayYVkfq4AT/mNOfMWWXevzH+kyDiCwg2sp9pJAmsFAg2L/sEu+H5hSXmMoUuHjIOKzfMP/lMi2d/GO53+/l6CzlR3Mwyl4rYnKGNJ8wqZNgCBZcaKRdffe2eVpzpkjgKCJV9U35F1dAIfBnWVQj5MXIwm8pAExGzfcEWehVQTpoTZYlGZ0YieqLjWqYvMeyp/McQn7IHPYpU4',
);

?>
