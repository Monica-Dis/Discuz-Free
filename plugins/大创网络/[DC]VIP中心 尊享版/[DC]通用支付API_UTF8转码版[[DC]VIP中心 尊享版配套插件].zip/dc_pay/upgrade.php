<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$fromversion)
	$fromversion = trim($_GET['fromversion']);
if($fromversion<'v1.0.4'){
	$sql = <<<EOF
	ALTER TABLE `pre_dc_pay_api` ADD COLUMN `payok` varchar(45) NULL;
	ALTER TABLE `pre_dc_pay_api` ADD COLUMN `ishand` TINYINT NULL DEFAULT 0;
	ALTER TABLE `pre_dc_pay_order` ADD COLUMN `param` text NULL;
EOF;
	runquery($sql);
	require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
	$phr = array(
		'plugin'=>'dc_pay',
		'include'=>'paycredit.class.php',
		'class'=>'paycredit',
		'return'=>'doreturn',
		'notify'=>'donotify',
		'payok'=>'payok',
	);
	PayHook::Register($phr);
}
$finish = TRUE;
?>

