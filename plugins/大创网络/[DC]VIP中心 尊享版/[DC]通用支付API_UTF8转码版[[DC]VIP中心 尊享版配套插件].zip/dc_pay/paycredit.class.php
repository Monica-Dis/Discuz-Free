<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class paycredit{
	public function donotify($orderid,$param,$uid,$username){
		$this->dodeal($orderid,$param,$uid,$username);
	}
	public function doreturn($orderid,$param,$uid,$username){
		global $_G;
		$this->dodeal($orderid,$param,$uid,$username);
	}
	private function dodeal($orderid,$param,$uid,$username){
		global $_G;
		if($_G['setting']['version']=='X2.5'){
			updatemembercount($uid, array($param['extcredit'] => $param['credit']), true, '', 0, '');
		}else{
			updatemembercount($uid, array($param['extcredit'] => $param['credit']), true, '', 0, '',lang('plugin/dc_pay','buycredit'),str_replace('{amount}',$param['amount'],lang('plugin/dc_pay','buycredit_msg')));
		}
	}
}
//From: Dism_taobao_com
?>
