<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
class wxpay_admin extends api_admin{
	
	public function dosave(){
		$config = $this->getconfig();
		$d = array(
			'mch_id'=>trim($_GET['mch_id']),
			'appid'=>trim($_GET['appid']),
			'appsecert'=>trim($_GET['appsecert']),
		);
		$key = trim($_GET['key']);
		if($key!=substr($config['key'],0,1).'********'.substr($config['key'],-4)){
			$d['key']=$key;
		}else{
			$d['key']=$config['key'];
		}
		$this->saveconfig($d);
	}
	
	public function doset(){
		$config = $this->getconfig();
		$config['key'] = $config['key']?substr($config['key'],0,1).'********'.substr($config['key'],-4):'';
		showsetting($this->_lang['appid'], 'appid', $config['appid'], 'text','','',$this->_lang['appidmsg']);
		showsetting($this->_lang['mch_id'], 'mch_id', $config['mch_id'], 'text');
		showsetting($this->_lang['key'], 'key', $config['key'], 'text','','',$this->_lang['keymsg']);
		showsetting($this->_lang['appsecert'], 'appsecert', $config['appsecert'], 'text','','',$this->_lang['appsecertmsg']);
	}
}
//From: Dism_taobao_com
?>
