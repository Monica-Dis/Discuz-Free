<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
class salepay_admin extends api_admin{
	
	public function dosave(){
		$config = $this->getconfig();
		$d = array(
			'apikey'=>trim($_GET['apikey']),
		);
		$key = trim($_GET['signkey']);
		if($key!=substr($config['signkey'],0,1).'********'.substr($config['signkey'],-4)){
			$d['signkey']=$key;
		}else{
			$d['signkey']=$config['signkey'];
		}
		$this->saveconfig($d);
	}
	
	public function doset(){
		$config = $this->getconfig();
		$config['signkey'] = $config['signkey']?substr($config['signkey'],0,1).'********'.substr($config['signkey'],-4):'';
		showsetting($this->_lang['apikey'], 'apikey', $config['apikey'], 'text');
		showsetting($this->_lang['signkey'], 'signkey', $config['signkey'], 'text');
	}
}
//From: Dism_taobao_com
?>
