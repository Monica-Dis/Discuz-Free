0虚心 <?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class salepay_pay extends api_pay{
	protected $config;
	protected $gateway;
	public function __construct() {
		parent::__construct();
		$this->config = $this->getconfig();
		$this->gateway = 'https://pay.salepay.cn/pay/aggregateWebPayOuter';
	}
	public function setorder($orderid, $price, $subject, $body, $showurl){
		global $_G;
		$this->_args = array(
			'isTest'		=> '0',
			'outTradeNo' 		=> $orderid,
			'totalAmount'       => floor($price * 100),
			'subject' 	=> $orderid,
			'body'		=>$orderid,
			'notifyUrl' 		=> $_G['siteurl'].'source/plugin/dc_pay/api/salepay/salepay_notify.php',
			'returnUrl' 		=> $_G['siteurl'].'source/plugin/dc_pay/api/salepay/salepay_return.php',
			'apiKey' 		=> $this->config['apikey'],
		);
	}
	public function create_payurl(){
		$this->_args=$this->sale_pay_parseparam($this->_args,$this->config['signkey']);
		return array(
				'gateway'=>$_G['siteurl'].'source/plugin/dc_pay/api/salepay/pay.php',
				'args'=>$this->_args,
		);
	}
	protected function sale_pay_parseparam($config = array(), $signkey = '') {
		ksort($config);
		reset($config);
		$signarg = '';
		foreach ($config as $key => $value) {
			if (!in_array($key, array('sign', 'signKey', 'signType'))) {
				$signarg .= "{$key}={$value}&";
			}
		}
		$signarg = trim($signarg, '&') . $signkey;
		$config['sign'] = md5($signarg);
		return $config;

	}
	public function getpayinfo(){
		define('TRADENO', $_GET['outTradeNo']);
		define('ORDERID', $_GET['outTradeNo']);
		return array(
			'succeed'=>'success',
			'fail'=>'fail'
		);
	}
	public function notifycheck(){
		if(!empty($_GET)){
			return $this->tradecheck($_GET);
		}
		return false;
	}
	private function tradecheck($notify){
		ksort($notify);
		$sign = '';
		foreach($notify as $key => $val){
			if($key != 'sign'&&$key != 'signType') $sign .= "&$key=$val";
		}
		if($notify['sign'] != md5(substr($sign,1).$this->config['signkey'])) {
			return false;
		}
		
		$result = dfsockopen("https://pay.salepay.cn/pay/notifyVerified?apiKey={$this->config['apikey']}&notifyId={$notify['notifyId']}");
		if (!$result) {
			return false;
		}
		$result = json_decode($result, true);
		if ($result['code'] == '0000' || !empty($result['success'])) {
			return true;
		}
		return false;
	}
	protected function MD5sign(){
		unset($this->_args['sign']);
		ksort($this->_args);
		$sign = '';
		foreach($this->_args as $key => $val) {
			$sign .= '&'.$key.'='.$val;
		}
		$sign = substr($sign, 1);
		$sign = md5($sign.$this->config['signkey']);
		$this->_args['sign'] = $sign;
	}
	public function pricecheck($price){
		$nprice = $_GET['totalAmount']/100;
		if(floatval($price) == floatval($nprice))return true;
	}
}
class salepay_mobilepay extends salepay_pay{}
//From: Dism_taobao_com
?>
