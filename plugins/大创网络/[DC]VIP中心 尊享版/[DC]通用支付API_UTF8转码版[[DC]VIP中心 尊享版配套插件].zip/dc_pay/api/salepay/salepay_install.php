<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class salepay_install extends api_install{
	public function __construct(){
		parent::__construct();
		$this->title=$this->_lang['install_title'];
		$this->des=$this->_lang['install_des'];
		$this->author=$this->_lang['install_author'];
		$this->version='v1.1.1';
		$this->logo='logo.gif';
		$this->mobile = 1;
	}
	public function install(){
		$sql = <<<EOF
CREATE TABLE `pre_dc_pay_salepay` (
  `orderid` varchar(45) NOT NULL,
  `borderid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`orderid`)
);
EOF;
runquery($sql);
		return true;
	}
	
	public function uninstall(){
		$sql = <<<EOF
DROP TABLE IF EXISTS `pre_dc_pay_salepay`;
EOF;
runquery($sql);
		return true;
	}
	
	public function upgrade($version){
		
	}

}
//From: Dism_taobao_com
?>
