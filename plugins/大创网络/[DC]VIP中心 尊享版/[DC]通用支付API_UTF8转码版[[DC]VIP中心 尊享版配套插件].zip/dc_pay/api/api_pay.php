<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
C::import('api/paybase','plugin/dc_pay',false);
class api_pay extends api_paybase{
	protected $_lang = array();
	protected $_args = array();
	public function __construct(){
		$this->_lang = @include DISCUZ_ROOT.'./source/plugin/dc_pay/language/'.$this->getextend().'.'.currentlang().'.php';
		if(empty($this->_lang))$this->_lang = @include DISCUZ_ROOT.'./source/plugin/dc_pay/language/'.$this->getextend().'.php';
	}
	public function setorder($orderid, $price, $subject, $body, $showurl){}
	public function create_payurl(){}
	public function getpayinfo(){}
	public function notifycheck(){}
}
//From: Dism_taobao_com
?>
