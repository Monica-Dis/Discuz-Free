<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxpayt_pay extends api_pay{
	protected $config;
	public function __construct() {
		parent::__construct();
		$this->config = $this->getconfig();
	}
	public function setorder($orderid, $price, $subject, $body, $showurl){
		global $_G;
		$this->_args = array(
			'orderid' 		=> $orderid,
		);
	}
	public function create_payurl(){
		global $_G;
		$data = urlencode(authcode($this->_args['orderid'],'ENCODE'));
		return $_G['siteurl'].'plugin.php?id=dc_pay:transfer&paytype=wxpayt&data='.$data;
	}
	public function create_payform($button_name, $button_style = '', $method = 'post'){
		return;
	}
	public function getpayinfo(){
		return array();
	}
	public function notifycheck(){
		return false;
	}
	public function returncheck(){
		return $this->notifycheck();
	}
	public function pricecheck($price){
		return false;
	}
	public function finish(){
		return;
	}
}
class wxpayt_mobilepay extends wxpayt_pay{}
//From: Dism_taobao_com
?>
