<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_lang = lang('plugin/dc_pay');
$status = intval($_GET['status']);
$page = intval($_GET['page']);
$perpage = 20;
$start = ($page-1)*$perpage;
$where = array();
if(in_array($status,array(1,2,3))){
	$where = array('status'=>$status-1);
}
$plugins = DB::fetch_all('SELECT identifier, name FROM %t', array('common_plugin'), 'identifier');
$orders = C::t('#dc_pay#dc_pay_order')->getrange($where,$start,$perpage,'DESC');
$count = C::t('#dc_pay#dc_pay_order')->getcount($where);
$todaystart = strtotime(dgmdate(TIMESTAMP,'Y-m-d'));
$yesterdaystart = $todaystart-86400;
$nowday = DB::result_first('SELECT sum(price) FROM '.DB::table('dc_pay_order').' WHERE status=1 and dateline>'.$todaystart);
$yesterday = DB::result_first('SELECT sum(price) FROM '.DB::table('dc_pay_order').' WHERE status=1  and dateline>'.$yesterdaystart.' and dateline<'.$todaystart);
$mpurl = 'plugin.php?id=dc_pay';
$multipage = multi($count, $perpage, $page, $mpurl);
include template('dc_pay:index');
?>
