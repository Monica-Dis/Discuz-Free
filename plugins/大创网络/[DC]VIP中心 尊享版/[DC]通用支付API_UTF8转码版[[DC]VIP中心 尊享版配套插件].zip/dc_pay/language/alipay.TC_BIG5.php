<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
return array(
	'install_title'=>'や腳',
	'install_des'=>'瞴烩縒ミ材よやキ籓',
	'install_author'=>'承呼蹈',
	'qrcode'=>'琌苯絏家Α',
	'pid'=>'莱ノID (APPID)',
	'pidmsg'=>'穝钡砞竚ゑ耕確馒叫綷弄 <a href="http://addon.dismall.com/?@dc_pay.plugin.76454" target="_blank">砞竚毙祘</a>',
	'key'=>'RSA2(SHA256)╬芲',
	'keymsg'=>'ノめㄏノㄣネΘ盞芲癸そ芲肚坝めキ籓<br /><a href="https://doc.open.alipay.com/docs/doc.htm?treeId=291&articleId=105971&docType=1" target="_blank">ネΘㄣ更</a>',
	'pubkey'=>'や腳RSA2(SHA256)そ芲',
	'pubkeymsg'=>'や腳そ芲叫坝めキ籓琩',
);
?>
