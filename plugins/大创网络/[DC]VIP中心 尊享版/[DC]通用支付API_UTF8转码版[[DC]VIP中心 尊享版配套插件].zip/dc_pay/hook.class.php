<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_dc_pay {
	private $_var;
	public function __construct() {
		$this->plugin_dc_pay();
	}
	public function plugin_dc_pay(){
		global $_G;
		$this->_var = $_G['cache']['plugin']['dc_pay'];
	}
	public function global_usernav_extra3(){
		if($this->_var['open']&&$this->_var['topshow'])
			return '<a href="home.php?mod=spacecp&ac=plugin&op=credit&id=dc_pay:buycredit" target="_blank">'.lang('plugin/dc_pay','buycredit').'</a> <span class="pipe">|</span>';
	}
}
//From: Dism·taobao·com
?>
