<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$_lang = lang('plugin/dc_vip');
$act = $_GET['act'];
if($act=='delete'&&submitcheck('submit')){
	$ids = dintval($_GET['delete'],true);
	C::t('#dc_vip#dc_vip_key')->delete($ids);
	cpmsg($_lang['delok'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key', 'succeed');
}elseif($act == 'export'){
	$detail ='';
	$sqladd = keysql();
	$count = $sqladd ? C::t('#dc_vip#dc_vip_key')->count_by_where($sqladd) : C::t('#dc_vip#dc_vip_key')->count();
	if($count) {
		$count = min(10000, $count);
		$keytype = C::t('#dc_vip#dc_vip_key_type')->getdata();
		$keylist = C::t('#dc_vip#dc_vip_key')->fetch_all_by_where($sqladd, 0, $count);
		foreach($keylist as $result) {
			$userlist[$result['uid']] = $result['uid'];
		}
		if($userlist) {
			$members = C::t('common_member')->fetch_all($userlist);
			unset($userlist);
		}
		
		foreach($keylist as $val) {
			$detail .= $val['key'];
			$detail .= ','.$val['viptime'];
			$detail .= ','.($val['typeid'] != 0 ? $keytype[$val['typeid']]['typename'] : cplang('card_type_default'));
			$detail .= ','.$_lang['key_sort_type'][$val['sortid']];
			$detail .= ','.cplang("card_manage_status_".$val['status']);
			$detail .= ','.($val['uid']?$members[$val['uid']]['username']:'--');
			$detail .= ','.($val['useddateline']?date("Y-m-d", $val['useddateline']):'--');
			$detail .= ','.($val['enddateline']?date("Y-m-d", $val['enddateline']):'--');
			$detail .= ','.($val['dateline']?date("Y-m-d", $val['dateline']):'--');
			$detail = $detail."\n";
		}
		
	}
	$detail = implode(',', $_lang['key_list_t'])."\n".$detail;
	$filename = 'card_'.date('Ymd', TIMESTAMP).'.csv';

	ob_end_clean();
	header('Content-Encoding: none');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename='.$filename);
	header('Pragma: no-cache');
	header('Expires: 0');
	if($_G['charset'] != 'gbk') {
		$detail = diconv($detail, $_G['charset'], 'GBK');
	}
	echo $detail;
	define('FOOTERDISABLED',true);
	exit();
}elseif($act == 'make'){
	if(submitcheck('submit')){
		$_GET['rule'] = rawurldecode(trim($_GET['rule']));
		$_GET['num'] = dintval($_GET['num']);
		$_GET['typeid'] = dintval($_GET['typeid']);
		$_GET['sortid'] = dintval($_GET['sortid']);
		$_GET['viptime'] = dintval($_GET['viptime']);
		list($y, $m, $d) = explode("-", $_GET['enddateline']);
		$enddateline = $_GET['enddateline'] && $y && $m ? mktime(23, 59, 59, $m, $d, $y) : 0 ;
		if($enddateline < TIMESTAMP) {
			cpmsg('card_make_cleardateline_early', '', 'error');
		}
		if(!$_GET['rule']) {
			cpmsg('card_make_rule_empty', '', 'error');
		}
		if($_GET['num'] < 1) {
			cpmsg('card_make_num_error', '', 'error');
		}
		
		$card = new makekey();
		$checkrule = $card->checkrule($_GET['rule'], 1);
		if($checkrule === -2) {
			cpmsg('card_make_rule_error', '', 'error');
		}
		$cardval = array(
			'typeid' => $_GET['typeid'],
			'sortid' => $_GET['sortid'],
			'viptime' => $_GET['viptime'],
			'enddateline' => $enddateline,
			'dateline' => TIMESTAMP,
			'status' => 1,
		);
		$card->make($_GET['rule'], $_GET['num'], $cardval);
		$_GET['succeed_num'] = $card->succeed;
		$_GET['fail_num'] = $card->fail;
		cpmsg('card_make_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key', 'succeed', array('succeed_num' => $_GET['succeed_num'], 'fail_num' => $_GET['fail_num']));
	}
	$card_type = array();
	$card_type[] = array(0, cplang('card_type_default'));
	$keytype = C::t('#dc_vip#dc_vip_key_type')->getdata();
	foreach($keytype as $result) {
		$card_type[] = array($result['id'], $result['typename']);
	}
	$key_sort = array();
	foreach($_lang['key_sort_type'] as $k =>$v){
		$key_sort[] = array($k,$v);
	}
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key&act=make');
	showtips('card_make_tips');
	showtableheader();
	showsetting('card_make_rule', '', '', '<input type="text" name="rule" class="txt" value="'.($card_log['rule']['rule'] ? $card_log['rule']['rule'] : '').'" onkeyup="javascript:checkcardrule(this);"><br /><span id="cardrule_view" class="tips2" style="display:none;"></span>');
echo <<<EOT
	<script type="text/javascript" charset="gbk">
		function checkcardrule(obj) {
			var chrLength = obj.value.length;
			$('cardrule_view').style.display = "";
			$('cardrule_view').innerHTML = "{$lang['card_number']}<strong>"+chrLength+"</strong>{$lang['card_number_unit']}";
		}
	</script>
EOT;
	showsetting('card_type', array('typeid', $card_type), '', 'select');
	showsetting($_lang['key_sort'], array('sortid', $key_sort), '', 'select');
	showsetting($_lang['key_list_t'][1], 'viptime', 365, 'number','','',$_lang['key_viptime_msg']);
	showsetting('card_make_num', 'num', 1, 'number');
	showsetting('card_make_cleardateline', 'enddateline', date("Y-m-d", $_G['timestamp']+31536000), 'calendar', '', 0, '');
	showsubmit('submit');
	showtablefooter();/*Dism_taobao-com*/
	showformfooter();
	exit();
}
$sqladd = keysql();
foreach($_GET AS $key => $val) {
	if(strpos($key, 'srch_') !== false && $val!='') {
		if(in_array($key, array('srch_username'))){
			$val = rawurlencode($val);
		}
		$export_url[] = $key.'='.$val;
	}
}
$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
showtips($_lang['keytips']);
$card_type_option = '';
$keytype = C::t('#dc_vip#dc_vip_key_type')->getdata();
foreach($keytype as $result) {
	$card_type[$result['id']] = $result;
	$card_type_option .= "<option value=\"{$result['id']}\" ".($_GET['srch_card_type'] == $result['id'] ? 'selected' : '').">{$result['typename']}</option>";
}
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key', '', 'cdform');
showtableheader();
foreach(array('1' => cplang('card_manage_status_1'), '2' => cplang('card_manage_status_2'), '9' => cplang('card_manage_status_9')) AS $key => $val) {
	$status_option .= "<option value='{$key}' ".($_GET['srch_card_status'] == $key ? "selected" : '').">{$val}</option>";
}
showtablerow('', array('width="80"', 'width="100"', 'width=100', 'width="260"'),
	array(
		cplang('card_number'), '<input type="text" name="srch_key" class="txt" value="'.$_GET['srch_key'].'" />',
		cplang('card_status'), "<select name='srch_card_status'><option value=''>".cplang('nolimit')."</option>".$status_option."</select>",
	)
);

showtablerow('', array(),
	array(
		cplang('card_log_used_user'), '<input type="text" name="srch_username" class="txt" value="'.$_GET['srch_username'].'" />',
		cplang('card_used_dateline'), '<input type="text" name="srch_useddateline_start" class="txt" value="'.$_GET['srch_useddateline_start'].'" onclick="showcalendar(event, this);" />- &nbsp;<input type="text" name="srch_useddateline_end" class="txt" value="'.$_GET['srch_useddateline_end'].'" onclick="showcalendar(event, this)" />',
	)
);
$perpage_selected[$perpage] = "selected=selected";
showtablerow('', array(),
	array(
		cplang('card_type'), '<select name="srch_card_type"><option value="">'.cplang('nolimit').'</option><option value="0" '.($_GET['srch_card_type'] != '' && $_GET['srch_card_type'] == 0 ? 'selected' : '').'>'.cplang('card_type_default').'</option>'.$card_type_option.'</select>',
		cplang('card_search_perpage'), '<select name="perpage" class="ps" onchange="this.form.submit();" ><option value="20" '.$perpage_selected[20].'>'.cplang('perpage_20').'</option><option value="50" '.$perpage_selected[50].'>'.cplang('perpage_50').'</option><option value="100" '.$perpage_selected[100].'>'.cplang('perpage_100').'</option></select>',
	)
);
showtablerow('', array(),
	array(
		$_lang['key_sort'], '<select name="srch_sort_type"><option value="">'.cplang('nolimit').'</option><option value="0" '.($_GET['srch_sort_type'] != '' && $_GET['srch_sort_type'] == 0 ? 'selected' : '').'>'.$_lang['key_sort_type'][0].'</option><option value="1" '.($_GET['srch_sort_type'] ==1 ? 'selected' : '').'>'.$_lang['key_sort_type'][1].'</option>'.$card_sort_option.'</select>',
	)
);
showtablerow('', array('width="40"', 'width="100"', 'width=50', 'width="260"'),
	array(
		'<input type="submit" name="srchbtn" class="btn" value="'.$lang['search'].'" />',''
	)
);
showtablefooter();/*Dism_taobao-com*/
showformfooter();

$start = ($page-1)*$perpage;
foreach ($_GET AS $key => $val) {
	if(strpos($key, 'srch_') !== FALSE) {
		$url_add .= '&'.$key.'='.$val;
	}
}
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key&act=delete');
showtableheader($_lang['key_list'].'(<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key&act=make">'.$_lang['key_make'].'</a>)', '');
showsubtitle(array('',$_lang['key_list_t'][0],$_lang['key_list_t'][1], $_lang['key_list_t'][2],$_lang['key_list_t'][3],$_lang['key_list_t'][4],$_lang['key_list_t'][5],$_lang['key_list_t'][6],$_lang['key_list_t'][7],$_lang['key_list_t'][8]));

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key'.$url_add.'&perpage='.$perpage;
$count = $sqladd ? C::t('#dc_vip#dc_vip_key')->count_by_where($sqladd) : C::t('#dc_vip#dc_vip_key')->count();
if($count) {
	$multipage = multi($count, $perpage, $page, $mpurl);
	$keylist = C::t('#dc_vip#dc_vip_key')->fetch_all_by_where($sqladd, $start, $perpage);
	foreach($keylist as $result) {
		$userlist[$result['uid']] = $result['uid'];
	}
	if($userlist) {
		$members = C::t('common_member')->fetch_all($userlist);
		unset($userlist);
	}
	foreach($keylist as $val) {
		showtablerow('', array('class="smallefont"'), array(
			'<input class="checkbox" type="checkbox" name="delete[]" value="'.$val['id'].'">',
			$val['key'],
			$val['viptime']?$val['viptime']:$_lang['forever'],
			$card_type[$val['typeid']]['typename'] ? $card_type[$val['typeid']]['typename'] : cplang('card_type_default'),
			$_lang['key_sort_type'][$val['sortid']],
			cplang("card_manage_status_".$val['status']),
			$val['uid'] ? "<a href='home.php?mod=space&uid={$val[uid]}' target='_blank'>".$members[$val['uid']]['username'] : ' -- ',
			$val['useddateline'] ? dgmdate($val['useddateline']) : ' -- ',
			$val['enddateline'] ? dgmdate($val['enddateline'], 'Y-m-d') : cplang('card_make_cleardateline_none'),
			dgmdate($val['dateline'], 'u'),
		));
	
	}
	showsubmit('submit', 'submit', 'del', '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=key&act=export&'.implode('&', $export_url).'" title="'.$lang['card_export_title'].'">'.$_lang['key_export'].'</a>', $multipage, false);
}
showtablefooter();/*Dism_taobao-com*/
showformfooter();
function keysql() {

	$_GET = daddslashes($_GET);

	$_GET['srch_key'] = trim($_GET['srch_key']);

	$_GET['srch_useddateline'] = trim($_GET['srch_useddateline']);
	$_GET['srch_username'] = trim($_GET['srch_username']);

	$_GET['srch_useddateline_start'] = trim($_GET['srch_useddateline_start']);
	$_GET['srch_useddateline_end'] = trim($_GET['srch_useddateline_end']);

	$sqladd = '';
	if($_GET['srch_key']) {
		$sqladd .= " AND `key` LIKE '%{$_GET['srch_key']}%' ";
	}
	if($_GET['srch_card_type'] != '') {
		$sqladd .= " AND `typeid` = '{$_GET['srch_card_type']}'";
	}
	if($_GET['srch_sort_type'] != '') {
		$sqladd .= " AND `sortid` = '{$_GET['srch_sort_type']}'";
	}
	if($_GET['srch_username']) {
		$uid = ($uid = C::t('common_member')->fetch_uid_by_username($_GET['srch_username'])) ? $uid : C::t('common_member_archive')->fetch_uid_by_username($_GET['srch_username']);
		$sqladd .= " AND `uid` = '{$uid}'";
	}
	if($_GET['srch_card_status']) {
		$sqladd .= " AND `status` = '{$_GET['srch_card_status']}'";
	}
	if($_GET['srch_useddateline_start'] || $_GET['srch_useddateline_end']) {
		if($_GET['srch_useddateline_start']) {
			list($y, $m, $d) = explode("-", $_GET['srch_useddateline_start']);
			$sqladd .= " AND `useddateline` >= '".mktime('0', '0', '0', $m, $d, $y)."' ";
		}
		if($_GET['srch_useddateline_end']) {
			list($y, $m, $d) = explode("-", $_GET['srch_useddateline_end']);
			$sqladd .= " AND `useddateline` <= '".mktime('23', '59', '59', $m, $d, $y)."' AND `useddateline` <> 0 ";
		}
	}
	return $sqladd ? ' 1 '.$sqladd : '';
}

class makekey{

	var $set = array();
	var $rulekey = array("str"=>"\@", "num"=>"\#", "full"=>"\*");
	var $sysrule = '';
	var $rule = '';
	var $rulemap_str = "ABCDEFGHIJKLMNPQRSTUVWXYZ";
	var $rulemap_num = "123456789";

	var $rulereturn = array();
	var $cardlist = array();

	var $succeed = 0;
	var $fail = 0;

	function makekey() {
		$this->init();
	}

	function init() {
		global $_G;
		$this->set = &$_G['setting']['card'];
		$this->sysrule = "^[A-Z0-9".implode('|', $this->rulekey)."]+$";
	}

	function make($rule = '', $num = 1, $cardval = array()) {
		global $_G;
		$this->rule = empty($rule) ? $this->set['rule'] : trim($rule) ;
		if(empty($this->rule)) {
			return -1;
		}
		$this->fail($num);
		for($i = 0; $i < $num ; $i++) {
			if($this->checkrule($this->rule)) {
				$card = $this->rule;
				foreach($this->rulereturn AS $key => $val) {
					$search = array();
					foreach($val AS $skey => $sval) {
						$search[] = '/'.$this->rulekey[$key].'/';
					}
					$card =  preg_replace($search, $val, $card, 1);
				}
			} else {
				return 0;
			}
			$cardval['key'] = $card;
			
			if(!in_array($cardval['key'],$this->cardlist)){
				$ckkey = C::t('#dc_vip#dc_vip_key')->fetch_by_key($cardval['key']);
			}
			if(empty($ckkey)||$ckkey['status']!=1){
				C::t('#dc_vip#dc_vip_key')->insert($cardval);
				$this->succeed += intval(DB::affected_rows());
				$this->cardlist[] = $card;
			}else{
				$this->fail++;
			}
		}
		return true;
	}


	function checkrule($rule, $type = '0') {
		if(!preg_match("/($this->sysrule)/i", $rule)){
			return -2;
		}
		if($type == 0) {
			foreach($this->rulekey AS $key => $val) {
				$match = array();
				preg_match_all("/($val){1}/i", $rule, $match);
				$number[$key] = count($match[0]);
				if($number[$key] > 0) {
					for($i = 0; $i < $number[$key]; $i++) {
						switch($key) {
						case 'str':
							$rand = mt_rand(0, (strlen($this->rulemap_str) - 1));
							$this->rulereturn[$key][$i] = $this->rulemap_str[$rand];
							break;
						case 'num':
							$rand = mt_rand(0, (strlen($this->rulemap_num) - 1));
							$this->rulereturn[$key][$i] = $this->rulemap_num[$rand];
							break;
						case 'full':
							$fullstr = $this->rulemap_str.$this->rulemap_num;
							$rand = mt_rand(0,(strlen($fullstr) - 1));
							$this->rulereturn[$key][$i] = $fullstr[$rand];
							break;
						}
					}
				}
			}
		}
		return true;

	}
	function fail($num = 1) {
		$failrate = $this->failrate ? (float)$this->failrate : '0.1';
		$this->failmin = ceil($num * $failrate);
		$this->failmin = $this->failmin > 100 ? 100 : $this->failmin;
	}
};
?>