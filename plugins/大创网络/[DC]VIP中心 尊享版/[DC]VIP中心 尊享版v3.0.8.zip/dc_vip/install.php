<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE `pre_dc_vip` (
  `uid` int(11) NOT NULL,
  `jointime` int(11) DEFAULT NULL,
  `exptime` int(11) DEFAULT NULL,
  `isyear` tinyint(1) DEFAULT NULL,
  `vgid` tinyint(4) DEFAULT NULL,
  `growth` int(11) DEFAULT NULL,
  `uptime` int(11) DEFAULT NULL,
  `isreward` TINYINT(1) DEFAULT NULL,
  `yearend` INT(11) DEFAULT NULL,
  PRIMARY KEY (`uid`)
);
CREATE TABLE `pre_dc_vip_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grouptitle` varchar(45) DEFAULT NULL,
  `growthlower` int(11) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `icon` varchar(45) DEFAULT NULL,
  `allow` text,
  `hook` text,
  `highlight` int(11) DEFAULT NULL,
  `highlightcolor` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE `pre_dc_vip_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` char(32) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT '0',
  `extcredit` int(11) DEFAULT NULL,
  `price` float(7,2) DEFAULT '0.00',
  `submitdate` int(11) DEFAULT NULL,
  `confirmdate` int(11) DEFAULT NULL,
  `payorderid` varchar(45) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `viporder` (`orderid`)
);
CREATE TABLE `pre_dc_vip_key_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE `pre_dc_vip_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `viptime` int(4) DEFAULT '0',
  `typeid` smallint(6) DEFAULT '0',
  `sortid` tinyint(1) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `uid` mediumint(8) DEFAULT '0',
  `dateline` int(10) DEFAULT '0',
  `useddateline` int(10) DEFAULT '0',
  `enddateline` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `vipkey` (`key`)
);
EOF;
runquery($sql);
$data = array(
	array('id'=>1,'grouptitle'=>'VIP1','growthlower'=>0,'color'=>'#FF0000','icon'=>'vip1.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
	array('id'=>2,'grouptitle'=>'VIP2','growthlower'=>600,'color'=>'#FF0000','icon'=>'vip2.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
	array('id'=>3,'grouptitle'=>'VIP3','growthlower'=>1800,'color'=>'#FF0000','icon'=>'vip3.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
	array('id'=>4,'grouptitle'=>'VIP4','growthlower'=>3600,'color'=>'#FF0000','icon'=>'vip4.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
	array('id'=>5,'grouptitle'=>'VIP5','growthlower'=>6000,'color'=>'#FF0000','icon'=>'vip5.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
	array('id'=>6,'grouptitle'=>'VIP6','growthlower'=>10800,'color'=>'#FF0000','icon'=>'vip6.gif','allow'=>'s:0:"";','hook'=>'s:0:"";'),
);
foreach($data as $d){
	C::t('#dc_vip#dc_vip_group')->insert($d);
}
if(C::t('common_plugin')->fetch_by_identifier('dc_pay')){
	require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
	$phr = array(
		'plugin'=>'dc_vip',
		'include'=>'payvip.class.php',
		'class'=>'payvip',
		'return'=>'doreturn',
		'notify'=>'donotify',
	);
	PayHook::Register($phr);
}
if(PHP_INT_MAX !=2147483647){
	$is64 = DISCUZ_ROOT.'./source/plugin/dc_vip/data/is64.php';
	$configdata = "return true;\n\n";
	if($fp = @fopen($is64, 'wb')) {
		fwrite($fp, "<?php\n//plugin dc_vip config file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
		fclose($fp);
	}
}
$finish = TRUE;
?>