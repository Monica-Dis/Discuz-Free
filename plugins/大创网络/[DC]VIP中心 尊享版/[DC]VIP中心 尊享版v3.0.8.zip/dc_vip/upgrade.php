<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!$fromversion)
	$fromversion = trim($_GET['fromversion']);
if($fromversion<'v1.1.1'){
		$sql = <<<EOF
CREATE TABLE `pre_dc_vip_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` char(32) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT '0',
  `extcredit` int(11) DEFAULT NULL,
  `price` float(7,2) DEFAULT '0.00',
  `submitdate` int(11) DEFAULT NULL,
  `confirmdate` int(11) DEFAULT NULL,
  `payorderid` varchar(45) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
ALTER TABLE `pre_dc_vip_group` ADD COLUMN `highlight` INT(11) NULL DEFAULT NULL  AFTER `hook` ;
ALTER TABLE `pre_dc_vip_group` ADD COLUMN `highlightcolor` varchar(45) NULL DEFAULT NULL  AFTER `hook` ;
EOF;
	runquery($sql);
}

if($fromversion<'v1.2.2'){
$sql = <<<EOF
	ALTER TABLE `pre_dc_vip` ADD COLUMN `isreward` TINYINT(1) NULL;
EOF;
	runquery($sql);
}
if($fromversion<'v1.2.3'){
$sql = <<<EOF
	ALTER TABLE `pre_dc_vip` ADD COLUMN `yearend` INT(11) NULL;
EOF;
	runquery($sql);
	DB::query('update %t set `yearend`=`exptime` where `isyear`=%d',array('dc_vip','1'));
}
if($fromversion<'v1.2.4'){
$sql = <<<EOF
CREATE TABLE `pre_dc_vip_key_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
CREATE TABLE `pre_dc_vip_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `viptime` int(4) DEFAULT '0',
  `typeid` smallint(6) DEFAULT '0',
  `sortid` tinyint(1) DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `uid` mediumint(8) DEFAULT '0',
  `dateline` int(10) DEFAULT '0',
  `useddateline` int(10) DEFAULT '0',
  `enddateline` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
);
EOF;
	runquery($sql);
}
if($fromversion<'v1.2.5'&&C::t('common_plugin')->fetch_by_identifier('dc_pay')){
	require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
	$phr = array(
		'plugin'=>'dc_vip',
		'include'=>'payvip.class.php',
		'class'=>'payvip',
		'return'=>'doreturn',
		'notify'=>'donotify',
	);
	PayHook::Register($phr);
}
if($fromversion<'v1.2.6'){
	$sql = <<<EOF
ALTER TABLE `pre_dc_vip` CHANGE COLUMN `yearend` `yearend` INT(11) NULL DEFAULT NULL;
EOF;
	runquery($sql);
	$temptime = TIMESTAMP+31536000;
	DB::query('update %t set `yearend`=`exptime`,`isyear`=%d where `exptime`>%d',array('dc_vip','1',$temptime));
}
if($fromversion<'v3.0.1'){
	DB::query('update %t set `exptime`=%d,`yearend`=%d,`isyear`=%d where `exptime`=%d',array('dc_vip','0','0','2','2147454847'));
	if(PHP_INT_MAX != 2147483647){
		DB::query('update %t set `exptime`=`exptime`/10,`yearend`=`yearend`/10',array('dc_vip'));
		$is64 = DISCUZ_ROOT.'./source/plugin/dc_vip/data/is64.php';
		$configdata = "return true;\n\n";
		if($fp = @fopen($is64, 'wb')) {
			fwrite($fp, "<?php\n//plugin dc_vip config file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
			fclose($fp);
		}
	}
}
if($fromversion<'v3.0.6'){
	$sql = <<<EOF
ALTER TABLE `pre_dc_vip_order` ADD KEY `viporder` (`orderid`);
ALTER TABLE `pre_dc_vip_key` ADD KEY `vipkey` (`key`);
EOF;
	runquery($sql);
	
}
$finish = TRUE;
?>