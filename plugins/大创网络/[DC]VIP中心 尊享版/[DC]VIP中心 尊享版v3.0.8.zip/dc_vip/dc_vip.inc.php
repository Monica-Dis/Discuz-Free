<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$action = $_GET['action'] ? $_GET['action'] : 'index';
$cvar = $_G['cache']['plugin']['dc_vip'];
$version ='Ver 3.0.8';
if (!$_G['uid']) showmessage('not_loggedin','member.php?mod=logging&action=login');
if(!$_G['cache']['plugin']['dc_vip']['open'])showmessage('plugin_nonexistence');
if(defined('IN_MOBILE'))$action='pay';
if(!preg_match("/^[a-z0-9_\-]+$/i", $action))showmessage('undefined_action');
//if(md5_file($cvar['chk'])!=$cvar['hash'])showmessage('plugin_nonexistence');
$file = DISCUZ_ROOT.'./source/plugin/dc_vip/module/'.$action.'.inc.php';
if (!file_exists($file)) showmessage('undefined_action');
loadcache(array('dc_vipextend'));
$dh = array(
	'index'=>lang('plugin/dc_vip','vip_index'),
	'my'=>lang('plugin/dc_vip','vip_my'),
	'tq'=>lang('plugin/dc_vip','vip_tq'),
	'year'=>lang('plugin/dc_vip','vip_year'),
	'pay' => lang('plugin/dc_vip','vip_pay'),
	'key' => lang('plugin/dc_vip','vip_key'),
	'order' => lang('plugin/dc_vip','vip_order'),
	'top' => lang('plugin/dc_vip','vip_top'),
);
$vipnav = @include DISCUZ_ROOT.'./source/plugin/dc_vip/data/nav.php';
if(!empty($vipnav)&&is_array($vipnav)){
	$dh =array_merge($dh,$vipnav);
}
if($_G['dc_plugin']['vip']['user'])
	$dh['pay'] = lang('plugin/dc_vip','vip_xf');
$cvar['display'] = dunserialize($cvar['display']);
foreach($cvar['display'] as $d){
	unset($dh[$d]);
}
$myvip = $_G['dc_plugin']['vip']['obj']->getvipinfo($_G['uid'],true);
if($_G['cache']['dc_vipextend']['rmcopy']){
	$rmcopy = @include DISCUZ_ROOT.'./source/plugin/dc_vip/data/rmcopy.config.php';
}
@include $file;
include template('dc_vip:vipcenter');
?>