<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('submit')) {
		if(is_array($_POST['delete'])) {
			C::t('#dc_vip#dc_vip_key_type')->delete($_POST['delete']);
			C::t('#dc_vip#dc_vip_key')->update_by_typeid($_POST['delete'], array('typeid'=>0));
		}
		if(is_array($_POST['newtype'])) {
			$_POST['newtype'] = dhtmlspecialchars(daddslashes($_POST['newtype']));
			foreach($_POST['newtype'] AS $key => $val) {
				if(trim($val)) {
					C::t('#dc_vip#dc_vip_key_type')->insert(array('typename' => trim($val)));
				}
			}
		}
	}
	showtips('card_type_tips');
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=keytype');
	showtableheader();
	showtablerow('class="header"', array('', ''), array(
		cplang('delete'),
		cplang('card_type'),
	));

	showtablerow('', '', array(
		'<input class="checkbox" type="checkbox" value ="" disabled="disabled" >',
		cplang('card_type_default'),
	));
	$keytype = C::t('#dc_vip#dc_vip_key_type')->getdata();
	foreach($keytype as $result) {
		showtablerow('', '', array(
		'<input class="checkbox" type="checkbox" name ="delete[]" value ="'.$result['id'].'" >',
		$result['typename'],
		));
	}
	echo <<<EOT
<script type="text/JavaScript">
	var rowtypedata = [
		[[1,''], [1,'<input type="text" class="txt" size="30" name="newtype[]">']],
	];
	</script>
EOT;
	echo '<tr><td></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.$lang['add_new'].'</a></div></td></tr>';
	showsubmit('submit', 'submit', 'select_all');
	showtablefooter();/*Dism_taobao-com*/
	showformfooter();
?>