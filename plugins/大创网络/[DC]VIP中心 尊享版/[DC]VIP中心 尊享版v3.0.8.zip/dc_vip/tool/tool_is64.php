<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class tool_is64{
	var $title='&#88;&#56;&#54;&#25968;&#25454;&#36716;&#25442;&#25104;&#88;&#54;&#52;&#25968;&#25454;';
	var $des='&#36716;&#25442;&#88;&#56;&#54;&#25968;&#25454;&#22312;&#88;&#54;&#52;&#19979;&#30340;&#86;&#73;&#80;&#21040;&#26399;&#26102;&#38388;&#38382;&#39064;&#65292;&#88;&#56;&#54;&#21482;&#25903;&#25345;&#21040;&#50;&#48;&#51;&#56;&#24180;&#65292;&#26412;&#27425;&#36716;&#25442;&#21487;&#25903;&#25345;&#21040;&#50;&#54;&#53;&#48;&#24180;';
	public function run(){
		global $pluginid,$_G;
		$fcis64 = @include DISCUZ_ROOT.'./source/plugin/dc_vip/data/is64.php';
		$is64 = PHP_INT_MAX == 2147483647?false:true;
		if(!$is64)
			cpmsg('&#27492;&#80;&#72;&#80;&#24182;&#38750;&#26159;&#88;&#54;&#52;&#44;&#19981;&#21487;&#36827;&#34892;&#25968;&#25454;&#36716;&#25442;','action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=tool','error');
		if($fcis64)
			cpmsg('&#24050;&#32463;&#25191;&#34892;&#36807;&#27492;&#22788;&#29702;&#65292;&#26080;&#27861;&#20877;&#25191;&#34892;&#65292;&#22914;&#35201;&#25805;&#20316;&#65292;&#35831;&#21024;&#38500;&#26412;&#25554;&#20214;&#30446;&#24405;&#19979;&#30340;&#32;&#100;&#97;&#116;&#97;&#47;&#105;&#115;&#54;&#52;&#46;&#112;&#104;&#112;&#32;&#25991;&#20214;&#65292;&#20877;&#36827;&#34892;&#25805;&#20316;','action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=tool','error');
		DB::query('update %t set `exptime`=%d,`yearend`=%d,`isyear`=%d where `exptime`=%d',array('dc_vip','0','0','2','2147454847'));
		DB::query('update %t set `exptime`=`exptime`/10,`yearend`=`yearend`/10',array('dc_vip'));
		$configdata = "return true;\n\n";
		if($fp = @fopen(DISCUZ_ROOT.'./source/plugin/dc_vip/data/is64.php', 'wb')) {
			fwrite($fp, "<?php\n//plugin dc_vip config file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
			fclose($fp);
		}
	}
	public function setting(){
		global $pluginid,$_G;
		$fcis64 = @include DISCUZ_ROOT.'./source/plugin/dc_vip/data/is64.php';
		$is64 = PHP_INT_MAX == 2147483647?false:true;
		if(!$is64)
			cpmsg('&#27492;&#80;&#72;&#80;&#24182;&#38750;&#26159;&#88;&#54;&#52;&#44;&#19981;&#21487;&#36827;&#34892;&#25968;&#25454;&#36716;&#25442;','action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=tool','error');
		if($fcis64)
			cpmsg('&#24050;&#32463;&#25191;&#34892;&#36807;&#27492;&#22788;&#29702;&#65292;&#26080;&#27861;&#20877;&#25191;&#34892;&#65292;&#22914;&#35201;&#25805;&#20316;&#65292;&#35831;&#21024;&#38500;&#26412;&#25554;&#20214;&#30446;&#24405;&#19979;&#30340;&#32;&#100;&#97;&#116;&#97;&#47;&#105;&#115;&#54;&#52;&#46;&#112;&#104;&#112;&#32;&#25991;&#20214;&#65292;&#20877;&#36827;&#34892;&#25805;&#20316;','action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=tool','error');
		cpmsg('&#26159;&#21542;&#25191;&#34892;&#118;&#105;&#112;&#21040;&#26399;&#26102;&#38388;&#25968;&#25454;&#36716;&#25442;&#25805;&#20316;','action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=tool&f=is64&submit=yes','form');
	}
}
//From: Dism_taobao_com
?>