<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

class returncredit_admin extends extend_admin{
	
	public function mrun(){
		global $_G;
		$returncredit = DISCUZ_ROOT.'./source/plugin/dc_vip/data/returncredit.config.php';
		if(submitcheck('submit')){
			$copydata = array(
				'extcredit'=>dintval($_GET['extcredit']),
				'monthpay'=>dintval($_GET['monthpay']),
				'yearpay'=>dintval($_GET['yearpay']),
				'foreverpay'=>dintval($_GET['foreverpay']),
			);
			$configdata = 'return '.var_export($copydata, true).";\n\n";
			if($fp = @fopen($returncredit, 'wb')) {
				fwrite($fp, "<?php\n//plugin dc_vip config file, DO NOT modify me!\n//Identify: ".md5($k.$configdata)."\n\n$configdata?>");
				fclose($fp);
			}
			cpmsg($this->_lang['succeed'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=extend', 'succeed');
		}
		$returncredit = @include $returncredit;
		$creditstr = '<select name="extcredit"><option value="">'.cplang('plugins_empty').'</option>';
		foreach($_G['setting']['extcredits'] as $k=>$credit){
			if($returncredit['extcredit']==$k)
				$creditstr .= '<option value="'.$k.'" selected>'.$credit['title'].'</option>';
			else
				$creditstr .= '<option value="'.$k.'">'.$credit['title'].'</option>';
		}
		showformheader('plugins&operation=config&identifier=dc_vip&pmod=extend&act=set&f=returncredit');
		showtableheader($this->_lang['install_title']);
		showsetting($this->_lang['extcredit'], 'extcredit', $nposition['extcredit'], $creditstr);
		showsetting($this->_lang['monthpay'], 'monthpay', $returncredit['monthpay'],'number','','',$this->_lang['monthpay_msg']);
		showsetting($this->_lang['yearpay'], 'yearpay', $returncredit['yearpay'],'number','','',$this->_lang['yearpay_msg']);
		showsetting($this->_lang['foreverpay'], 'foreverpay', $returncredit['foreverpay'],'number','','',$this->_lang['foreverpay_msg']);
		showsubmit('submit');
		showformfooter();
	}

}
//From: Dism_taobao_com
?>