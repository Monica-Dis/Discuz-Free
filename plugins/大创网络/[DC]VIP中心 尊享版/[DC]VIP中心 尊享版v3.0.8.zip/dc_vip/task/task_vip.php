<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: task_gift.php 6752 2010-03-25 08:47:54Z cnteacher $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class task_vip {

	var $version = '1.0';
	var $name;
	var $description;
	var $copyright = '<a href="http://addon.dismall.com/?@19418.developer" target="_blank">DC.</a>';
	var $icon = '';
	var $period = '';
	var $periodtype = 0;
	var $conditions = array();
	
	public function __construct(){
		$this->name = lang('plugin/dc_vip','task_name');
		$this->description = lang('plugin/dc_vip','task_description');
		$this->conditions = array(
			'act' => array(
				'title' => lang('plugin/dc_vip','task_complete_act'),
				'type' => 'select',
				'value' => array(
					array('isvip', lang('plugin/dc_vip','task_complete_isvip')),
					array('isyear', lang('plugin/dc_vip','task_complete_isyear')),
					array('isforever', lang('plugin/dc_vip','task_complete_isforever')),
				),
				'default' => 'isvip',
				'sort' => 'complete',
			)
		);
	}
	function condition(){
		
	}
	function preprocess($task) {
		
	}

	function csc($task = array()) {
		global $_G;
		$taskvars = array();
		foreach(C::t('common_taskvar')->fetch_all_by_taskid($task['taskid']) as $taskvar) {
			if($taskvar['value']) {
				$taskvars[$taskvar['variable']] = $taskvar['value'];
			}
		}
		if($_G['dc_plugin']['vip']['user']['isyear']==2&&$taskvars['act']=='isforever'){
			return true;
		}
		if($_G['dc_plugin']['vip']['user']['isyear']&&$taskvars['act']=='isyear'){
			return true;
		}
		if($_G['dc_plugin']['vip']['user']&&$taskvars['act']=='isvip'){
			return true;
		}
		
		
		return array('csc' => 0, 'remaintime' => 0);
	}
	function view($task, $taskvars) {
		if($taskvars['complete']['act']['value']=='isvip'){
			return lang('plugin/dc_vip','task_complete_act_isvip');
		}
		if($taskvars['complete']['act']['value']=='isyear'){
			return lang('plugin/dc_vip','task_complete_act_isyear');
		}
		if($taskvars['complete']['act']['value']=='isforever'){
			return lang('plugin/dc_vip','task_complete_act_isforever');
		}
	}
}


?>