<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class vip_goods extends extend_goods{
	public function __construct($goods){
		$this->identify = 'dc_vip';
		parent::__construct($goods);
	}
	public function view(){
		$extdata = dunserialize($this->goods['extdata']);
		$return = '<div>'.$this->_lang['mall_yxq'].'<strong style="color:#FF0000; font-size:16px;">'.$extdata['yxq'].'</strong> '.$this->_lang['tian'].'</div>';
		$return .= '<div>'.$this->_lang['goods_maxbuy'].'<strong style="color:#FF0000; font-size:16px;">'.$this->goods['maxbuy'].'</strong> '.$this->_lang['goods_jian'].'</div>';
		$return .= '<div>'.$this->_lang['goods_allow'].($this->goods['buytimes']?$this->_lang['goods_buy'].'<strong style="color:#FF6600; font-size:16px;">'.$this->goods['buytimes'].'</strong> '.$this->_lang['goods_ci']:$this->_lang['goods_nolimit']).'</div>';
		$return .= parent::view();
		return $return;
	}
	public function paycheck(){
		$extdata = dunserialize($this->goods['extdata']);
		return array('yxq'=>$extdata['yxq']);
	}
	
	public function finish($order){
		global $_G;
		C::t('#dc_mall#dc_mall_orders')->update($order['id'],array('status'=>1,'finishtime'=>TIMESTAMP));
		require_once DISCUZ_ROOT.'./source/plugin/dc_vip/vip.lib.class.php';
		$vipobj = new User_Vip();
		$vip = $vipobj->getvipinfo($order['uid']);
		$d = $order['extdata']['yxq'];
		if(!$d){
			$isyear=2;
		}elseif($d>=365){
			$isyear=1;
		}
		$timestamp = $d*86400;
		$_G['dc_plugin']['vip']['obj']->setuservip($order['uid'],$timestamp,$isyear);
		$user = getuserbyuid($order['uid']);
		if($_G['cache']['plugin']['dc_vip']['openmsg']&&!$vip){
			notification_add($order['uid'], 'system', $_G['cache']['plugin']['dc_vip']['openmsg'], array('uid' => $order['uid'], 'username' => $user['username']), 1);
		}
	}
}
//From: Dism_taobao_com
?>