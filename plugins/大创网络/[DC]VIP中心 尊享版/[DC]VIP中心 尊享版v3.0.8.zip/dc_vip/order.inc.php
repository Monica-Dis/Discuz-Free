<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if($_GET['act']=='delete'){
	$oid = dintval($_GET['oid']);
	$order = C::t('#dc_vip#dc_vip_order')->fetch($oid);
	if(empty($order))cpmsg(plang('vipiderr'), '', 'error');
	if(submitcheck('confirmed')){
		C::t('#dc_vip#dc_vip_order')->delete($oid);
		cpmsg(plang('delok'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=order', 'succeed');
	}
	cpmsg(plang('deleteorderchk'),'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=order&act=delete&oid='.$oid,'form', array('orderid' => $order['orderid']));
}
$perpage = 20;
$start = ($page-1)*$perpage;
$vus = C::t('#dc_vip#dc_vip_order')->range($start,$perpage,'DESC');
$count = C::t('#dc_vip#dc_vip_order')->count();
$uids = array();
foreach($vus as $v)$uids[]=$v['uid'];
$user = C::t('common_member')->fetch_all($uids);
showtableheader(plang('vipuser'), '');
showsubtitle(array(plang('order_id'),plang('username'),plang('order_credit'), 'RMB',plang('order_month'),plang('order_ctime'),plang('order_status'),plang('caozuo')));
foreach($vus as $v){
	showtablerow('', array(), array(
		$v['orderid'],
		'<a href="home.php?mod=space&uid='.$v['uid'].'" target="_blank">'.$user[$v['uid']]['username'].'</a>',
		($v['credit']?$v['credit'].$_G['setting']['extcredits'][$v['extcredit']]['unit'].$_G['setting']['extcredits'][$v['extcredit']]['title']:'-'),
		$v['price']>0?$v['price']:'-',
		$v['month']==99999?plang('forever'):$v['month'],
		dgmdate($v['submitdate'], 'dt'),
		$v['status']?$v['status']==1?plang('order_ispay'):plang('order_isclose'):plang('order_pay'),
		'[<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=order&act=delete&oid='.$v['id'].'"><font color="#FF0000">'.plang('delete').'</font></a>]')
	);
}
$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=order';
$multipage = multi($count, $perpage, $page, $mpurl);
showsubmit('', '', '', '', $multipage);
showtablefooter();/*Dism_taobao-com*/
function plang($str) {
	return lang('plugin/dc_vip', $str);
}
//From: Dism_taobao_com
?>