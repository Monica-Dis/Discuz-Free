<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
if($_GET['act']=='update'){
	$_GET['username'] = daddslashes(trim($_GET['username']));
	$uid = dintval($_GET['uid']);
	if(empty($uid)){
		$user = C::t('common_member')->fetch_by_username($_GET['username']);
	}else{
		$user = getuserbyuid($uid);
	}
	if(empty($user)) cpmsg(plang('searchuser_no_exist'), '', 'error', array('username' => $user['username']));
	require_once DISCUZ_ROOT.'./source/plugin/dc_vip/vip.lib.class.php';
	$vip = new User_Vip();
	$uv = $vip->getvipinfo($user['uid'],true);
	if(submitcheck('submit')){
		if(empty($uv)){
			$vgid = C::t('#dc_vip#dc_vip_group')->getvgid();
			$isyear = 0;
			if(trim($_GET['time'])=='forever'){
				$time = 0;
				$timed =99999;
				$isyear = 2;
			}else{
				$timed = dintval($_GET['time']);
				$time = $timed*86400;
				$isyear = $timed>365?1:0;
			}
			$vip->setuservip($user['uid'],$time,$isyear);
		}else{
			$growth = dintval($_GET['growth']);
			$isyear = 0;
			if(trim($_GET['exptime'])=='forever'){
				$exptime = 0;
				$isyear = 2;
			}else
				$exptime = strtotime($_GET['exptime']) + 86399;
			if(trim($_GET['yearend'])=='forever'){
				$yearend = 0;
			}else{
				if(strtotime($_GET['yearend'])&&$isyear!=2){
					$yearend = strtotime($_GET['yearend']) + 86399;
					$isyear = 1;
				}
			}
			$vgid = C::t('#dc_vip#dc_vip_group')->getvgid($growth);
			$data = array(
				'exptime'=>$exptime,
				'isyear'=>$isyear,
				'yearend'=>$yearend,
				'growth'=>$growth,
				'vgid'=>$vgid['id'],
				'uptime'=>TIMESTAMP,
			);
			if($vip->is64){
				$data['exptime'] = $data['exptime']/10;
				$data['yearend'] = $data['yearend']/10;
			}
			C::t('#dc_vip#dc_vip')->update($user['uid'],$data);
		}
		
		cpmsg(plang('setok'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=user', 'succeed');
	}
	showformheader('plugins&operation=config&identifier=dc_vip&pmod=search&act=update');
	if(empty($uv)){
		showtableheader(plang('help_pay'));
		showsetting(plang('username'), 'username', $user['username'], 'text', true);
		showsetting(plang('pay_time'), 'time', '30', 'text','','',plang('forever_msg'));
		showsubmit('submit');
		showtablefooter();/*Dism_taobao-com*/
	}else{
		showtableheader(plang('modify_vip_info'));
		showsetting(plang('username'), 'username', $user['username'], 'text', true);
		showsetting(plang('jointime'), 'jointime', dgmdate($uv['jointime'], 'dt'), 'text', true);
		showsetting(plang('exptime'), 'exptime', $uv['isyear']==2?'forever':dgmdate($uv['exptime'], 'd'), 'calendar','','',plang('forever_msg'));
		showsetting(plang('yearend'), 'yearend', $uv['isyear']==2?'forever':($uv['yearend']?dgmdate($uv['yearend'], 'd'):''), 'calendar','','',plang('forever_msg'));
		showsetting(plang('growth'), 'growth', $uv['growth'], 'number');
		showsubmit('submit');
		showformfooter();
		showtablefooter();/*Dism_taobao-com*/
	}
	showformfooter();
	dexit();
}
if(submitcheck('search')){
	dheader('location:'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=search&act=update&username='.$_GET['username']);
}
showtableheader(plang('search_vip'));
showformheader('plugins&operation=config&identifier=dc_vip&pmod=search');
showsetting(plang('username'), 'username', '', 'text');
showsubmit('search', 'search');
showformfooter();
showtablefooter();/*Dism_taobao-com*/
function plang($str) {
	return lang('plugin/dc_vip', $str);
}
//From: Dism_taobao_com
?>