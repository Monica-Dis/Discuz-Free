<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$do = trim($_GET['do']);
if($do=='check'){
	$chkstr='';
	$key = trim($_GET['key']);
	$k = C::t('#dc_vip#dc_vip_key')->fetch_by_key($key);
	if($k&&$k['status']==1){
		if($k['enddateline']<TIMESTAMP){
			$chkstr = '<font color="#FF0000">'.lang('plugin/dc_vip','key_lose').'</font>';
		}elseif($k['sortid']==1&&$myvip){
			$chkstr = '<font color="#FF0000">'.lang('plugin/dc_vip','key_shiyong_repeat').'</font>';
		}elseif($myvip['isyear'] == 2){
			$chkstr = '<font color="#FF0000">'.lang('plugin/dc_vip','key_large_error').'</font>';
		}else{
			$viptype = lang('plugin/dc_vip','key_sort_type');
			if(!$k['viptime'])
				$k['viptime'] = lang('plugin/dc_vip','forever');
			else
				$k['viptime'] .= lang('plugin/dc_vip','day');
			$chkstr = str_replace(array('{time}','{type}','{exptime}'),array($k['viptime'],$viptype[$k['sortid']],dgmdate($k['enddateline'], 'Y-m-d')),$cvar['keytrue']);
		}
		
	}else{
		$chkstr = '<font color="#FF0000">'.lang('plugin/dc_vip','key_invalid').'</font>';
	}
	include template('common/header_ajax');
	echo $chkstr;
	include template('common/footer_ajax');
}elseif($do=='use'){
	$submitchk = false;
	if($cvar['secopen'])
		$submitchk = submitcheck('submit',0,1);
	else
		$submitchk = submitcheck('submit');
	if($submitchk){
		$key = trim($_GET['key']);
		if(in_array($_G['groupid'],array(4,5,6,7,8)))
			showmessage(lang('plugin/dc_vip','isbadgroupkeyuser'));
		$k = C::t('#dc_vip#dc_vip_key')->fetch_by_key($key);
		if(!$key||$k['status']!=1)
			showmessage(lang('plugin/dc_vip','key_invalid'));
		if($k['enddateline']<TIMESTAMP)
			showmessage(lang('plugin/dc_vip','key_lose'));
		if($k['sortid']==1&&$myvip)
			showmessage(lang('plugin/dc_vip','key_shiyong_repeat'));
		if($myvip['isyear'] == 2)
			showmessage(lang('plugin/dc_vip','key_large_error'));
		$data = array();
		$_G['dc_plugin']['vip']['obj']->setuservip($_G['uid'],$k['viptime']*86400,$k['viptime']?0:2);
		notification_add($_G['uid'], 'system', $_G['cache']['plugin']['dc_vip']['openmsg'], array('uid' => $_G['uid'], 'username' => $_G['username']), 1);
		$d = array(
			'uid'=>$_G['uid'],
			'useddateline'=>TIMESTAMP,
			'status'=>2,
		);
		C::t('#dc_vip#dc_vip_key')->update($k['id'],$d);
		showmessage(lang('plugin/dc_vip','key_succeed'),dreferer(),array(),array('alert'=>'right'));
		
		
	}
}
$vip_intro_array=explode("\n",$cvar['viptq']);
foreach ($vip_intro_array as $text){
	$vip_intro.=$text?"<li>".$text."</li>\r\n":"";
}
$navtitle = lang('plugin/dc_vip','vip_center');
?>