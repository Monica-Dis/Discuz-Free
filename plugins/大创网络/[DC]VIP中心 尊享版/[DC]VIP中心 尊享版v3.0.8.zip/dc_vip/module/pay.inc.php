<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$paytypes = array();
if($cvar['onlinepay']){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php'))showmessage('dc_vip:onlinepaycheck');
	require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
	if(defined('IN_MOBILE'))
		$payobj = new Mobile_PayMent('dc_vip');
	else
		$payobj = new PayMent('dc_vip');
	$paytypes = $payobj->GetPayType();
	if(is_string($paytypes))showmessage('undefined_action');
}
if($cvar['extcredit'])
	$paytypes[] = 'credit';
$vipmeal = array();
if($_G['cache']['dc_vipextend']['vipmeal']){
	C::import('extend/vip','plugin/dc_vip',false);
	C::import('vipmeal/vip','plugin/dc_vip/extend',false);
	$modstr = 'vipmeal_vip';
	if (class_exists($modstr,false)){
		$_obj = new $modstr();
		if(in_array('mrun',get_class_methods($_obj))){
			$vipmeal = $_obj->mrun();
		}
	}
}
$viptype = array('year','month');
if($cvar['forevercredit'])$viptype[] = 'forever';
$submitchk = false;
if($cvar['secopen'])
	$submitchk = submitcheck('submit',0,1);
else
	$submitchk = submitcheck('submit');
if($submitchk){
	if(in_array($_G['groupid'],array(4,5,6,7,8)))
		showmessage(lang('plugin/dc_vip','isbadgroup'));
	if($_G['dc_plugin']['vip']['user']['isyear']==2)showmessage(lang('plugin/dc_vip','is_forevervip'));
	$payway = $_GET['payway'];
	$paytype = $_GET['paytype'];
	$order = array();
	$order['orderid'] = dgmdate(TIMESTAMP, 'YmdHis').random(6);
	if($vipmeal){
		$payway = dintval($payway);
		if(!$vipmeal[$payway]||!in_array($paytype,$paytypes))showmessage('undefined_action');
		$paymoney = $vipmeal[$payway]['price'];
		$order['month'] = $vipmeal[$payway]['month'];
	}else{
		$paylen = dintval($_GET['paylen']);
		if(($paylen<1||$paylen>10&&$payway!='forever')||!in_array($payway,$viptype)||!in_array($paytype,$paytypes))showmessage('undefined_action');
		if($payway=='month'&&$paylen<$cvar['mplower'])
			showmessage(str_replace('{month}',$cvar['mplower'],lang('plugin/dc_vip','paylimint')));
		if($payway=="month"){
			$paymoney = $paylen*$cvar['credit'];
		}elseif($payway=="forever"){
			$paymoney = $cvar['forevercredit'];
		}else{
			$paymoney = $paylen*$cvar['yearcredit'];
		}
		if($payway=='month'){
			$order['month'] = $paylen;
		}elseif($payway=="forever"){
			$order['month'] = 99999;
		}else
			$order['month'] = $paylen*12;
	}
	if($paytype=='credit'){
		if($cvar['onlinepay']){
			$paymoney = $paymoney*$cvar['ccbl'];
		}
		$credit = C::t('common_member_count')->fetch($_G['uid']);
		if($credit['extcredits'.$cvar['extcredit']]<$paymoney){
			showmessage(str_replace('{credit}',$_G['setting']['extcredits'][$cvar['extcredit']]['title'],lang('plugin/dc_vip','nocredit')));
		}
	}
	$order['extcredit'] = $cvar['extcredit'];
	$order['uid'] = $_G['uid'];
	$order['submitdate'] = TIMESTAMP;
	if($paytype=='credit'){
		$order['status'] = 1;
		$order['credit'] = $paymoney;
		$order['price'] = 0;
	}else{
		$order['status'] = 0;
		$order['credit'] = 0;
		$order['price'] = $paymoney;
	}
	$oid = C::t('#dc_vip#dc_vip_order')->insert($order,true);
	if($paytype=='credit'){
		updatemembercount($_G['uid'], array('extcredits'.$cvar['extcredit'] => "-".$order['credit']), true, '', 0, '',lang('plugin/dc_vip','vippay'),str_replace('{month}',$order['month'],lang('plugin/dc_vip','vippaymsg')));
	}else{
		$payobj->SetPayType($paytype);
		$payobj->SetOrder($order['orderid'],$order['price'], lang('plugin/dc_vip', 'payfor_vip'),$_G['username'].' - '.lang('plugin/dc_vip', 'payfor_vip'));
		$payurl = $payobj->GetPayUrl();
		$payurl = $payurl[$paytype];
		if(defined('IN_MOBILE')){
			header('location:'.$payurl);die();}
		include template('dc_vip:payfor');
		die();
	}
	$data = array();
	if($_G['dc_plugin']['vip']['user']){
		if($order['month']==99999){
			$isyear=2;	
		}elseif($order['month']>=12){
			$isyear=1;
		}
		$timestamp = strtotime('+'.$order['month'].' month',$_G['dc_plugin']['vip']['user']['exptime'])-$_G['dc_plugin']['vip']['user']['exptime'];
		$_G['dc_plugin']['vip']['obj']->setuservip($_G['uid'],$timestamp,$isyear);
		C::t('#dc_vip#dc_vip_order')->update($oid,array('status'=>1,'confirmdate'=>TIMESTAMP));
		showmessage(lang('plugin/dc_vip','xfsucceed'),dreferer(),array(),array('alert'=>'right'));
	}else{
		if($order['month']==99999){
			$isyear=2;	
		}elseif($order['month']>=12){
			$isyear=1;
		}
		$timestamp = strtotime('+'.$order['month'].' month',TIMESTAMP)-TIMESTAMP;
		$_G['dc_plugin']['vip']['obj']->setuservip($_G['uid'],$timestamp,$isyear);
		C::t('#dc_vip#dc_vip_order')->update($oid,array('status'=>1,'confirmdate'=>TIMESTAMP));
		notification_add($_G['uid'], 'system', $cvar['openmsg'], array('uid' => $_G['uid'], 'username' => $_G['username']), 1);
		showmessage(lang('plugin/dc_vip','paysucceed'),dreferer(),array(),array('alert'=>'right'));
	}
}
if($_GET['getmoney']=='yes'){
	$payway = $_GET['payway'];
	$paytype = $_GET['paytype'];
	$paylen = dintval($_GET['paylen']);
	include template('common/header_ajax');
	if($vipmeal){
		$payway = dintval($payway);
		$paymoney = $vipmeal[$payway]['price'];
	}else{
		if(($paylen<1||$paylen>10&&$payway!='forever')||!in_array($payway,$viptype)||!in_array($paytype,$paytypes)){
			echo 'error';
		}else{
			if($payway=="month"){
				$paymoney = $paylen*$cvar['credit'];
			}elseif($payway=="forever"){
				$paymoney = $cvar['forevercredit'];
			}else{
				$paymoney = $paylen*$cvar['yearcredit'];
			}
		}
	}
	if(in_array($paytype,$paytypes)&&$paytype!='credit'){
		$paymoney = sprintf('%.2f',$paymoney);
	}else{
		if($cvar['onlinepay']){
			$paymoney = $paymoney*$cvar['ccbl'];
		}
	}
	$paymoney = '<font style="color:#FF0000;font-size:22px">'.$paymoney.'</font>';
	if($paytype=='credit'){
		$paymoney = $paymoney.$_G['setting']['extcredits'][$cvar['extcredit']]['title'];
	}else{
		$paymoney = $paymoney.lang('plugin/dc_vip','yuan');
	}
	echo $paymoney;
	include template('common/footer_ajax');
}
$vip_intro_array=explode("\n",$cvar['viptq']);
foreach ($vip_intro_array as $text){
	$vip_intro.=$text?"<li>".$text."</li>\r\n":"";
}
$paytimes = dintval($_GET['m']);
$paytimes = $paytimes ?$paytimes:1;

if($cvar['onlinepay']){
	$vip_price_ext = lang('plugin/dc_vip','yuan');
	foreach($paytypes as $k => $p){
		$pinfo = $payobj->GetPayInfo($p);
		if($pinfo)$payinfo[$p] = $pinfo;
		if(!$defaulept)$defaulept=$p;
	}
}else{
	$vip_price_ext = $_G['setting']['extcredits'][$cvar['extcredit']]['unit'].$_G['setting']['extcredits'][$cvar['extcredit']]['title'];
}
$randstr = random(8);
$navtitle = lang('plugin/dc_vip','vip_center');
?>