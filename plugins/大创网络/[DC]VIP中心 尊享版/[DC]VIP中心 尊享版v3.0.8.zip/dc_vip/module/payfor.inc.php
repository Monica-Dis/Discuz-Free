<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!file_exists(DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php'))showmessage('dc_vip:onlinepaycheck');
require_once DISCUZ_ROOT.'./source/plugin/dc_pay/payment.lib.class.php';
$payobj = new PayMent('dc_vip');
$paytypes = $payobj->GetPayType();
$payinfo = array();
$defaulept ='';
foreach($paytypes as $p){
	$payinfo[$p] = $payobj->GetPayInfo($p);
	if(!$defaulept)$defaulept=$p;
}
$orderid = $_GET['orderid'];
$ord = C::t('#dc_vip#dc_vip_order')->getorderbyorder($orderid);
if(empty($ord)||$ord['uid']!=$_G['uid'])showmessage('dc_vip:error');
if(submitcheck('ordercheck')){
	if(empty($ord['status']))
		showmessage('dc_vip:payno');
	elseif($ord['status']==1)
		showmessage('dc_vip:payok','plugin.php?id=dc_vip&action=order',array(),array('alert'=>'right'));
	else
		showmessage('dc_vip:close');
}
if($ord['status'])
	showmessage('dc_vip:error');

if(submitcheck('submitchk')){
	$paytype = in_array($_GET['paytype'],$paytypes)?$_GET['paytype']:$defaulept;
	$payobj->SetPayType($paytype);
	$payobj->SetOrder($ord['orderid'],$ord['price'], lang('plugin/dc_vip', 'payfor_vip'),$_G['username'].' - '.lang('plugin/dc_vip', 'payfor_vip'));
	$payurl = $payobj->GetPayUrl();
	$payurl = $payurl[$paytype];
	if($payurl)
		showmessage(lang('plugin/dc_vip','payforwait'),$payurl,array('orderid'=>$orderid),array('alert'=>'right'));
	else
		showmessage('dc_vip:error');
}
$paytype = trim($_GET['paytype']);
include template('dc_vip:payfor');
$navtitle = lang('plugin/dc_vip','vip_center');
?>