<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class User_Vip{
	var $cvar;
	var $groupdata;
	var $is64 = false;
	public function __construct(){
		global $_G;
		loadcache('plugin');
		$this->cvar = &$_G['cache']['plugin']['dc_vip'];
		$this->cvar['hash']='fce9793357d08842c78a146ad93436a4';
		$this->groupdata = C::t('#dc_vip#dc_vip_group')->getdata();
		$this->is64 = PHP_INT_MAX == 2147483647?false:true;
	}
	public function getvipinfo($uid='',$flag = false){
		global $_G;
		if(!$_G['uid']&&!$uid)return array();
		$uid = $uid ? $uid : $_G['uid'];
		$uvip = C::t('#dc_vip#dc_vip')->fetch($uid);
		if(empty($uvip))return array();
		if($this->is64){
			$uvip['exptime'] *= 10;
			$uvip['yearend'] *= 10;
		}else{
			$uvip['exptime']=$uvip['exptime']>2147454847?2147454847:$uvip['exptime'];
			$uvip['yearend']=$uvip['yearend']>2147454847?2147454847:$uvip['yearend'];
		}
		if($flag==false)
			$this->update($uvip,'data');
		if($uvip['exptime']>=TIMESTAMP||$uvip['isyear']==2||$flag)
			return $uvip;
		else
			return array();
	}
	public function update($d,$type = 'uid'){
		if($type=='uid')$d=$this->getvipinfo($d,true);
		if(empty($d))return;
		$nowdate = dgmdate(TIMESTAMP,'Y-m-d');
		$update = dgmdate($d['uptime'],'Y-m-d');
		$expdate = dgmdate($d['exptime'],'Y-m-d');
		$isrewardchk = false;
		if($nowdate > $update){
			if($expdate >= $nowdate||$d['isyear']==2){
				$gt = $this->cvar['growthv'];
				if($d['isyear']){
					$gt +=$this->cvar['yearv'];
					if(!$d['isreward']&&$this->cvar['fyvipreward'])$isrewardchk = true;
				}
				$day = (strtotime($nowdate) - strtotime($update))/86400;
				$growth = $gt*$day + $d['growth'];
				$chktime = $d['exptime']-86400*$this->cvar['beforendtime'];
				if($this->cvar['beforendvipmsg']&&$chktime<TIMESTAMP&&$this->cvar['beforendtime']>0&&$d['isyear']!=2){
					notification_add($d['uid'], 'system', $this->cvar['beforendvipmsg'], array('uid' => $d['uid'], 'username' => $user['username']), 1);
				}
			}else{
				if($update>$expdate){
					$gt = $this->cvar['dropv'];
					$day = (strtotime($nowdate) - strtotime($update))/86400;
					$gt = $gt*$day;
					$growth = $d['growth']-$gt;
				}else{
					$gt = $this->cvar['growthv'];
					$day = (strtotime($expdate) - strtotime($update))/86400;
					if($d['isyear'])$gt +=$this->cvar['yearv'];
					$gt = $gt*$day;
					$day = (strtotime($nowdate) - strtotime($update))/86400;
					$day = $day-1;
					$growth = $gt - $this->cvar['dropv']*$day;
					$growth = $growth + $d['growth'];
					$user = getuserbyuid($d['uid']);
					if($this->cvar['endvipmsg']){
						notification_add($d['uid'], 'system', $this->cvar['endvipmsg'], array('uid' => $d['uid'], 'username' => $user['username']), 1);
					}
				}
				if($growth<0)$growth=0;
			}
			$vgid = $this->get_vip_group_by_growth($growth);
			if($vgid['id']>$d['vgid']){
				$user = getuserbyuid($d['uid']);
				if($this->cvar['upvipmsg']){
					notification_add($d['uid'], 'system', $this->cvar['upvipmsg'], array('uid' => $d['uid'], 'username' => $user['username'], 'vip' => $this->groupdata[$vgid['id']]['grouptitle']), 1);
				}
			}
			$data = array(
				'growth'=>$growth,
				'uptime'=>TIMESTAMP,
				'vgid'=>$vgid['id'],
			);
			if($d['isyear']==1&&$d['yearend']<TIMESTAMP){
				$data['isyear']=0;
			}
			if($isrewardchk){
				$data['growth'] += $this->cvar['fyvipreward'];
				$data['isreward'] = 1;
				notification_add($d['uid'], 'system', lang('plugin/dc_vip','fyvipreward'), array('growth' => $this->cvar['fyvipreward']), 1);
			}
			C::t('#dc_vip#dc_vip')->update($d['uid'],$data);
		}
	}
	public function updategrowth($uid,$growth = 0,$flag = false){
		global $_G;
		$uvip = array();
		if($uid==$_G['uid']){
			$uvip = $_G['dc_plugin']['vip']['user'];
			$flag = true;
		}else{
			$uvip = $this->getvipinfo($uid);
		}
		if(empty($uvip))return;
		$data = array(
			'growth'=>$uvip['growth'] + $growth,
		);
		if($flag){
			$vgid = $this->get_vip_group_by_growth($data['growth']);
			if($vgid['id']>$uvip['vgid']){
				$user = getuserbyuid($uid);
				if($this->cvar['upvipmsg']){
					notification_add($uid, 'system', $this->cvar['upvipmsg'], array('uid' => $uid, 'username' => $user['username'], 'vip' => $this->groupdata[$vgid['id']]['grouptitle']), 1);
				}
			}
			$data['vgid'] = $vgid['id'];
		}
		C::t('#dc_vip#dc_vip')->update($uid,$data);
	}
	public function get_vip_group_by_growth($growth){
		$vgdata = array();
		foreach($this->groupdata as $g){
			if($g['growthlower']<=$growth){
				$vgdata = $g;
			}else{
				break;
			}	
		}
		return $vgdata;
	}
	public function setuservip($uid='',$timestamp,$isyear = 0){
		global $_G;
		if(!$_G['uid']&&!$uid)return;
		$uid = $uid ? $uid : $_G['uid'];
		$uvip = C::t('#dc_vip#dc_vip')->fetch($uid);
		if($uvip){
			if($uvip['isyear']!=2){
				if($this->is64){
					$uvip['exptime'] = $uvip['exptime']*10;
					$uvip['yearend'] = $uvip['yearend']*10;
				}
				if(TIMESTAMP>$uvip['exptime'])
					$data['exptime'] = TIMESTAMP+$timestamp;
				else
					$data['exptime'] = $uvip['exptime'] + $timestamp;
				if(($data['exptime']<10000000||$data['exptime']>2147454847)&&!$this->is64){
					$data['isyear'] = 2;
					$data['exptime'] = $data['yearend'] = 0;
				}elseif($data['exptime']-TIMESTAMP>=31536000){
					$data['isyear'] = 1;
					$data['yearend']=$data['exptime'];
				}
				if($data['isyear']<$isyear)$data['isyear']=$isyear;
				if($this->is64){
					$data['exptime'] = $data['exptime']/10;
					$data['yearend'] = $data['yearend']/10;
				}
				C::t('#dc_vip#dc_vip')->update($uid,$data);
			}
			
		}else{
			$data['exptime'] = TIMESTAMP+$timestamp;
			if(($data['exptime']<10000000||$data['exptime']>2147454847)&&!$this->is64){
				$data['isyear'] = 2;
				$data['exptime'] = $data['yearend'] = 0;
			}elseif($timestamp>=31536000){
				$data['isyear'] = 1;
				$data['yearend']=$data['exptime'];
			}
			if($this->is64){
				$data['exptime'] = $data['exptime']/10;
				$data['yearend'] = $data['yearend']/10;
			}
			if($data['isyear']<$isyear)$data['isyear']=$isyear;
			$data['jointime'] = TIMESTAMP;
			$data['uptime'] = TIMESTAMP;
			$data['growth'] = 0;
			$data['uid'] = $uid;
			$vgid = C::t('#dc_vip#dc_vip_group')->getvgid($data['growth']);
			$data['vgid'] = $vgid['id'];
			C::t('#dc_vip#dc_vip')->insert($data);
		}
	}
}
//From: Dism_taobao_com
?>