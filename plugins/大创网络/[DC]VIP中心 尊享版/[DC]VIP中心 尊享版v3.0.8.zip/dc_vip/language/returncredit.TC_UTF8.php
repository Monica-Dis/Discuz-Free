<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
return array(
	'install_title'=>'在線支付返積分',
	'install_des'=>'通過在線支付後，進行積分返還。',
	'install_author'=>'大創網絡',
	'extcredit'=>'返還積分類型',
	'monthpay'=>'月付積分返回數',
	'monthpay_msg'=>'按月數進行計算，實際返回 = 月份數*這個設置值',
	'yearpay'=>'年付積分返回數',
	'yearpay_msg'=>'按年數進行計算，實際返回 = 年數*這個設置值',
	'foreverpay'=>'永久積分返回數',
	'foreverpay_msg'=>'實際返回只進行一次',
	'succeed'=>'設置成功！',
	'pluginname'=>'支付返積分',
	'jlmsg'=>'購買VIP，積分返還',
	
);
?>