<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
return array(
	'mall_title'=>'VIP會員',
	'mall_des'=>'用戶可購買此類商品直接成爲VIP會員',
	'mall_author'=>'大創網絡',
	'mall_yxq'=>'有效期：',
	'mall_maxbuytimes'=>'下單次數：',
	'mall_kucun'=>'庫存數量：',
	'mall_unit'=>'單位：天',
	'mall_okcount'=>'用戶可下單次數，0爲不限制',
	'tian'=>'天',
	'vipyxq'=>'VIP有效期',
	'goods_maxbuy'=>'壹次最多可購買：',
	'goods_jian'=>'件',
	'goods_allow'=>'此商品每個賬戶可',
	'goods_buy'=>'購買',
	'goods_ci'=>'次。',
	'goods_nolimit'=>'不限量購買。',
	
);
?>