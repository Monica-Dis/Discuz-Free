<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
return array(
	'mall_title'=>'VIP会员',
	'mall_des'=>'用户可购买此类商品直接成为VIP会员',
	'mall_author'=>'大创网络',
	'mall_yxq'=>'有效期：',
	'mall_maxbuytimes'=>'下单次数：',
	'mall_kucun'=>'库存数量：',
	'mall_unit'=>'单位：天',
	'mall_okcount'=>'用户可下单次数，0为不限制',
	'tian'=>'天',
	'vipyxq'=>'VIP有效期',
	'goods_maxbuy'=>'一次最多可购买：',
	'goods_jian'=>'件',
	'goods_allow'=>'此商品每个账户可',
	'goods_buy'=>'购买',
	'goods_ci'=>'次。',
	'goods_nolimit'=>'不限量购买。',
	
);
?>