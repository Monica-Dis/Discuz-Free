<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class payvip{
	public function donotify($orderid){
		$this->dodeal($orderid);
	}
	public function doreturn($orderid){
		global $_G;
		$this->dodeal($orderid);
		dheader('location: '.$_G['siteurl'].'plugin.php?id=dc_vip&action=paysucceed');die();
	}
	
	private function dodeal($orderid){
		global $_G;
		$order = C::t('#dc_vip#dc_vip_order')->getorderbyorder($orderid);
		if(empty($order['status'])&&$order) {
			require_once DISCUZ_ROOT.'./source/plugin/dc_vip/vip.lib.class.php';
			$vipobj = new User_Vip();
			$vip = $vipobj->getvipinfo($order['uid']);
			if($order['month']==99999){
				$isyear=2;
			}elseif($order['month']>=12){
				$isyear=1;
			}
			if(empty($vip)){
				$timestamp = strtotime('+'.$order['month'].' month',TIMESTAMP)-TIMESTAMP;
			}else{
				$timestamp = strtotime('+'.$order['month'].' month',$vip['exptime'])-$vip['exptime'];
			}
			$vipobj->setuservip($order['uid'],$timestamp,$isyear);
			C::t('#dc_vip#dc_vip_order')->update($order['id'],array('status'=>1,'confirmdate'=>TIMESTAMP,'payorderid'=>PAYTYPE.':'.TRADENO));
			$user = getuserbyuid($order['uid']);
			if($_G['cache']['plugin']['dc_vip']['openmsg']&&!$vip){
				notification_add($order['uid'], 'system', $_G['cache']['plugin']['dc_vip']['openmsg'], array('uid' => $order['uid'], 'username' => $user['username']), 1);
			}
			loadcache(array('dc_vipextend'));
			$_G['dc_vip']['order'] = $order;
			foreach($_G['cache']['dc_vipextend'] as $k=>$ext){
				if($ext['com']!='reward')continue;
				C::import('extend/vip','plugin/dc_vip',false);
				C::import($k.'/vip','plugin/dc_vip/extend',false);
				$modstr = $k.'_vip';
				if (class_exists($modstr,false)){
					$_obj = new $modstr();
					if(in_array('mrun',get_class_methods($_obj))){
						$_obj->mrun();
					}
				}
			}
		}
	}
}
//From: Dism_taobao_com
?>