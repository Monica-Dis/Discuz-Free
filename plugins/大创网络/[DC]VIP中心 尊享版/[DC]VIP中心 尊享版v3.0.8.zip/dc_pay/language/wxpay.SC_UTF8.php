<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
return array(
	'install_title'=>'微信支付',
	'install_des'=>'微信扫码支付',
	'install_author'=>'大创网络',
	'appid'=>'公众账号ID',
	'appidmsg'=>'注意是一串以wx开头的字符串',
	'mch_id'=>'商户号',
	'key'=>'API密钥',
	'keymsg'=>'在商户平台中设置的，长度固定32位',
	'appsecert'=>'公众帐号SECERT',
	'appsecertmsg'=>'JSAPI支付方式必填',
	'wxpay'=>'微信扫码支付',
	'wxorder'=>'请您及时付款，以便订单尽快处理！ 订单号：',
	'wxpay0'=>'请使用微信扫一扫',
	'wxpay1'=>'扫描二维码支付',
	'wxpay2'=>'金额',
	'wxpay3'=>'元',
	'wxpayok'=>'付款成功！',
);
?>