<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class wxpay_pay extends api_pay{
	protected $config;
	protected $gateway = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
	private $wxnotify;
	public function __construct() {
		parent::__construct();
		$this->config = $this->getconfig();
	}
	public function setorder($orderid, $price, $subject, $body, $showurl){
		global $_G;
		$this->_args = array(
			'appid' 		=> $this->config['appid'],
			'mch_id' 		=> $this->config['mch_id'],
			'nonce_str' 	=> random(28),
			'notify_url' 		=> $_G['siteurl'].'source/plugin/dc_pay/api/wxpay/wxpay_notify.php',
			'out_trade_no' 		=> $orderid.'_'.random(4,1),
			'body' 		=> diconv($subject,CHARSET,'utf-8'),
			'total_fee' 		=> $price*100,
			'spbill_create_ip'	=> $_G['clientip'],
			'trade_type'=>'NATIVE',
			'product_id'=>random(8,1),
		);
		if($body)$this->_args['detail']=diconv($body,CHARSET,'utf-8');
	}
	public function create_payurl(){
		global $_G;
		$this->MD5sign();
		$xml = '<xml>';
		foreach($this->_args as $key => $val) {
			if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
		}
		$xml .= '</xml>';
		$str = $this->postXmlCurl($xml,$this->gateway);
		$xml = simplexml_load_string($str);
		if($xml->return_code=='SUCCESS'&&$xml->result_code=='SUCCESS'){
			$urlstr = $xml->code_url;
		}
		return array(
				'type'=>'qrcode',
				'qrcode'=>$_G['siteurl'].'plugin.php?id=dc_pay:qrcode&data='.rawurlencode($urlstr).'&formhash='.FORMHASH,
			);
	}
	protected function postXmlCurl($xml, $url, $second = 30)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		$data = curl_exec($ch);
		if($data){
			curl_close($ch);
			return $data;
		}
		return;
	}
	public function create_payform($button_name, $button_style = '', $method = 'post'){
		return;
	}
	public function getpayinfo(){
		$xml = file_get_contents("php://input");
		$xml = simplexml_load_string($xml,NULL,LIBXML_NOCDATA);
		$this->wxnotify = json_decode(json_encode($xml),TRUE);
		$orid = explode('_',$this->wxnotify['out_trade_no']);
		define('TRADENO', $this->wxnotify['transaction_id']);
		define('ORDERID', $orid[0]);
		return array(
			'succeed'=>'<xml><return_code><![CDATA[SUCCESS]]></return_code></xml>',
			'fail'=>''
		);
	}
	public function notifycheck(){
		$md5x = $this->wxnotify['sign'];
		unset($this->wxnotify['sign']);
		ksort($this->wxnotify);
		$sign = '';
		foreach($this->wxnotify as $key => $val) {
			$sign .= '&'.$key.'='.$val;
		}
		$sign = substr($sign, 1);
		$sign = md5($sign.'&key='.$this->config['key']);
		if($md5x ==strtoupper($sign))return true;
	}
	public function returncheck(){
		return $this->notifycheck();
	}
	protected function MD5sign(){
		unset($this->_args['sign']);
		ksort($this->_args);
		$sign = '';
		foreach($this->_args as $key => $val) {
			$sign .= '&'.$key.'='.$val;
		}
		$sign = substr($sign, 1);
		$sign = md5($sign.'&key='.$this->config['key']);
		$this->_args['sign'] = strtoupper($sign);
	}
	public function pricecheck($price){
		if($this->wxnotify['total_fee'] == $price*100)return true;
	}
}
class wxpay_mobilepay extends wxpay_pay{
	private $_openid;
	private $wxb = false;
	public function setorder($orderid, $price, $subject, $body, $showurl,$paytype = 'wap'){
		global $_G;
		parent::setorder($orderid, $price, $subject, $body, $showurl);
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || $paytype=='jsapi') {
			$this->wxb = true;
		}
		if($paytype=='jsapi'&&$this->wxb)
			$this->_args['trade_type']='JSAPI';
		else{
			$this->_args['trade_type']='MWEB';
			$this->_args['scene_info'] = '{"h5_info": {"type":"Wap","wap_url": "'.$_G['siteurl'].'","wap_name": "'.$_G['bbname'].'"}}';
		}
	}
	public function create_payurl(){
		global $_G;
		if(!$this->wxb){
			$this->MD5sign();
			$xml = '<xml>';
			foreach($this->_args as $key => $val) {
				if (is_numeric($val)){
					$xml.="<".$key.">".$val."</".$key.">";
				}else{
					$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
				}
			}
			$xml .= '</xml>';
			$str = $this->postXmlCurl($xml,$this->gateway);
			$xml = simplexml_load_string($str);
			if($xml->return_code=='SUCCESS'&&$xml->result_code=='SUCCESS'){
				$urlstr = $xml->mweb_url;
				return $urlstr;
			}
			
		}else{
			$orid = explode('_',$this->_args['out_trade_no']);
			return $_G['siteurl'].'source/plugin/dc_pay/api/wxpay/wxpay.php?orderid='.$orid[0];
		}
	}
	public function getopenid(){
		global $_G;
		if (!isset($_GET['code'])){
			$redirect_uri = urlencode($_G['siteurl'].'source/plugin/dc_pay/api/wxpay/wxpay.php?orderid='.$_GET['orderid']);
			$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$this->config['appid'].'&redirect_uri='.$redirect_uri.'&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect';
			header("Location: $url");die();
		}else{
			$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$this->config['appid'].'&secret='.$this->config['appsecert'].'&code='.$_GET['code'].'&grant_type=authorization_code';
			$dstr = dfsockopen($url);
			$data = json_decode($dstr,true);
			$this->_openid = $data['openid'];
			return $this->_openid;
		}
	}
	public function getpaycode(){
		$arg = array(
			'appid'=>$this->config['appid'],
			'body'=>$this->_args['body'],
			'mch_id'=>$this->config['mch_id'],
			'nonce_str'=>$this->_args['nonce_str'],
			'notify_url'=>$this->_args['notify_url'],
			'openid'=>$this->_openid,
			'out_trade_no'=>$this->_args['out_trade_no'],
			'spbill_create_ip'=>$this->_args['spbill_create_ip'],
			'total_fee'=>$this->_args['total_fee'],
			'trade_type'=>$this->_args['trade_type'],
		);
		$this->_args = $arg;
		$this->MD5sign();
		$xml = '<xml>';
		foreach($this->_args as $key => $val) {
			if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
		}
		$xml .= '</xml>';
		$str = $this->postXmlCurl($xml,$this->gateway);
		$xml = simplexml_load_string($str,NULL,LIBXML_NOCDATA);
		
		
		$xml = json_decode(json_encode($xml),TRUE);
		if($xml['return_code']=='SUCCESS'){
			$arg = array(
				'appId'=>$this->config['appid'],
				'nonceStr'=>random(28),
				'package'=>'prepay_id='.$xml['prepay_id'],
				'signType'=>'MD5',
				'timeStamp'=>(string)TIMESTAMP,
			);
			$arg['paySign'] = md5('appId='.$arg['appId'].'&nonceStr='.$arg['nonceStr'].'&package='.$arg['package'].'&signType='.$arg['signType'].'&timeStamp='.$arg['timeStamp'].'&key='.$this->config['key']);
			$arg['paySign'] = strtoupper($arg['paySign']);
			return $arg;
		}
		return;
	}
}
//From: Dism_taobao_com
?>