<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$publicmapspath = DISCUZ_ROOT.'./source/plugin/dc_seccode/config/publicmaps.php';
$festivalmapspath = DISCUZ_ROOT.'./source/plugin/dc_seccode/config/festivalmaps.php';
$admapspath = DISCUZ_ROOT.'./source/plugin/dc_seccode/config/admaps.php';
$publicmaps = @include $publicmapspath;
if(TIMESTAMP - $publicmaps['timestamp']>86400){
	$publicmaps = C::t('#dc_seccode#dc_seccode_maps')->publicmaps();
	writefile($publicmaps,$publicmapspath);
}else{
	$publicmaps = $publicmaps['data'];
}
$festivalmaps = @include $festivalmapspath;
if(TIMESTAMP - $festivalmaps['timestamp']>86400){
	$festivalmaps = C::t('#dc_seccode#dc_seccode_maps')->festivalmaps();
	writefile($festivalmaps,$festivalmapspath);
}else{
	$festivalmaps = $festivalmaps['data'];
}
$admaps = @include $admapspath;
if(TIMESTAMP - $admaps['timestamp']>86400){
	$admaps = C::t('#dc_seccode#dc_seccode_maps')->admaps();
	writefile($admaps,$admapspath);
}else{
	$admaps = $admaps['data'];
}
$maps = array_merge($publicmaps,$festivalmaps,$admaps);
if(empty($maps)){
	echo 'DcClickCallback(\'nomap\');';
	exit();
}
$map=$maps[rand(0,count($maps)-1)];
$strarr = createmap($map);
dsetcookie('dcseccode',authcode(json_encode($strarr).'|DC|'.TIMESTAMP,'ENCODE'));
$arr=array();
foreach($strarr['data'] as $s){
	$arr[] = $s[0];
}
echo 'DcClickCallback(\'load\', '.json_encode(array('str'=>$arr)).');';

function writefile($data,$path){
	$configdata = 'return '.var_export(array('timestamp'=>strtotime(dgmdate(TIMESTAMP,'Y-m-d')),'data'=>$data), true).";\n\n";
	if($fp = @fopen($path, 'wb')) {
		fwrite($fp, "<?php\n//plugin seccode config file, DO NOT modify me!\n//Identify: ".md5($configdata)."\n\n$configdata?>");
		fclose($fp);
	}
}
function createmap($map){
	$d=array();
	$d['id']=$map['id'];
	//$d['static']=$map['static'];
	//$d['draw']=$map['draw'];
	//$d['font']=$map['font'];
	$data=dunserialize($map['data']);
	$arr=array();
	foreach($data as $da){
		if(!$map['static']){
			do{
				$pos=array(rand(20,340-$da['wh'][0]),rand(10,160-$da['wh'][1]));
			}while(chkfanwei($pos,$da['wh'],$arr));
		}else{
			if(count($da['pos'])==2)
				$pos=$da['pos'];
			else
				$pos=array(0,0);
		}
		$arr[] =array(
			diconv($da['str'],CHARSET,'utf-8'),
			array($pos[0],$pos[1]+$da['wh'][1]), //验证图输出坐标
			array($pos[0],$pos[1]), //验证左上角坐标
			//'color'=>$da['color'],
			//'size'=>$da['size'],
			array($pos[0]+$da['wh'][0],$pos[1]+$da['wh'][1]),//验证右下角坐标
		);
	}
	$d['data']=$arr;
	return $d;
}
function chkfanwei($p,$wh,$arr){
	if(empty($arr))
		return false;
	foreach($arr as $s){
		if(($s[1][0]-$wh[0])<$p[0]&&$p[0]<$s[3][0]&&($s[1][1]-2*$wh[1])<$p[1]&&$p[1]<$s[3][1])
			return true;
	}
	return false;	
}
//From: Dism_taobao-com
?>