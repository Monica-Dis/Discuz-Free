<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class lib_image {
	private $config;
	private $im;
	private $imagetype;
	public function __construct(){
		$this->config = array(
			'source'=>'',
			'font'=>'',
		);
	}
	public function Add($arr){
		$this->config['data'][] = $arr;
	}
	public function Set($arr){
		$this->config = array_merge($this->config,$arr);
	}
	public function gettype(){
		return $this->imagetype;
	}
	public function display(){
		switch($this->gettype())
		{
			case 'gif':imagegif($this->im);break;
			case 'jpeg':imagejpeg($this->im);break;
			case 'png':imagepng($this->im);break;
			default:;
		}
		imagedestroy($im);
	}
	public function save($file){
		if(!$this->im)
			return;
		switch($this->gettype())
		{    
			case 'gif':imagegif($this->im,$file);break;    
			case 'jpeg':imagejpeg($this->im,$file);break;    
			case 'png':imagepng($this->im,$file);break;    
			default:;   
		}   
	}
	public function Watermark(){
		if(!file_exists($this->config['source']))
			return;
		$im=&$this->im;
		$ground_info = getimagesize($this->config['source']);
		$ground_w = $ground_info[0];
		$ground_h = $ground_info[1];
		switch($ground_info[2])
		{
			case 1:$im = imagecreatefromgif($this->config['source']);$this->imagetype='gif';break;
			case 2:$im = imagecreatefromjpeg($this->config['source']);$this->imagetype='jpeg';break;
			case 3:$im = imagecreatefrompng($$this->config['source']);$this->imagetype='png';break;
			default:return;
		}
		foreach($this->config['data'] as $s){
			if( !empty($s['color']) && (strlen($s['color'])==7) )
			{
				$R = hexdec(substr($s['color'],1,2));
				$G = hexdec(substr($s['color'],3,2));
				$B = hexdec(substr($s['color'],5));
			} 
			$color = imagecolorallocate($im, $R, $G, $B);
			imagettftext($im, $s['size'], 0, $s['pos'][0], $s['pos'][1], $color, $this->config['font'], $s['str']);
		}
		return true;
	}
}
//From: Dism_taobao-com
?>