<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dc_seccode_maps extends discuz_table
{
	public function __construct() {
		$this->_table = 'dc_seccode_maps';
		$this->_pk    = 'id';
		parent::__construct();
	}
	public function publicmaps(){
		return DB::fetch_all('SELECT id,static,data FROM '.DB::table($this->_table).' WHERE allow = 1 AND '.DB::field('type', 0).' order by rand() limit 0,20');
	}
	public function festivalmaps(){
		$dr = DB::fetch_all('SELECT id FROM '.DB::table($this->_table).' WHERE '.DB::field('type', 1).' AND end<'.TIMESTAMP);
		foreach($dr as $r){
			$yearsec=strtotime(dgmdate(TIMESTAMP,'Y-m-d').'+1 year')-strtotime(dgmdate(TIMESTAMP,'Y-m-d'));
			DB::query('UPDATE '.DB::table($this->_table).' SET `start`=`start`+'.$yearsec.',`end`=`end`+'.$yearsec.' WHERE '.DB::field('id', $r['id']));
		}
		return DB::fetch_all('SELECT id,static,data FROM '.DB::table($this->_table).' WHERE allow = 1 AND '.DB::field('type', 1).' AND start<'.TIMESTAMP.' AND end>'.TIMESTAMP);
	}
	public function admaps(){
		return DB::fetch_all('SELECT id,static,data FROM '.DB::table($this->_table).' WHERE allow = 1 AND '.DB::field('type', 2).' AND start<'.TIMESTAMP.' AND end>'.TIMESTAMP);
	}
	public function getbyid($id){
		$data = DB::fetch_first('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::field('id', $id));
		return $data;
	}
	public function update($val, $data) {
		if(isset($val) && !empty($data) && is_array($data)) {
			$this->checkpk();
			$ret = DB::update($this->_table, $data, DB::field($this->_pk, $val), false,false);
			return $ret;
		}
		return  0;
	}
	public function range($start = 0, $limit = 0, $where = '', $sort = '') {
		if($sort) {
			$this->checkpk();
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).($where ? ' WHERE '.DB::implode($where, ' AND ') : '').($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	public function count($where = ''){
		$count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).($where ? ' WHERE '.DB::implode($where, ' AND ') : ''));
		return $count;
	}
}
//From: Dism��taobao��com
?>