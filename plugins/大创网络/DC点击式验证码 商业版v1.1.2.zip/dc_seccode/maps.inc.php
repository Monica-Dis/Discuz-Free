<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$cvar = $_G['cache']['plugin']['dc_seccode'];
$act = $_GET['act'];
if($act=='delete'){
	$id=dintval($_GET['id']);
	if(!$id)
		cpmsg(plang('error'),'','error');
	$d = C::t('#dc_seccode#dc_seccode_maps')->getbyid($id);
	if(!$d)
		cpmsg(plang('nomap'),'','error');
	if(submitcheck('confirmed')){
		if(C::t('#dc_seccode#dc_seccode_maps')->delete($id)){
			@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['filename']);
			@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['filename']);
			cpmsg(plang('succeed'),'action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps','succeed');
		}else{
			cpmsg(plang('error'),'','error');
		}
	}
	cpmsg(plang('seccode_delete'),'action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=delete&id='.$id,'form',array(),'',true,ADMINSCRIPT.'?action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps');
	
}elseif($act=='edit'){
	$id=dintval($_GET['id']);
	if(!$id)
		cpmsg(plang('error'),'','error');
	$d = C::t('#dc_seccode#dc_seccode_maps')->getbyid($id);
	if(!$d)
		cpmsg(plang('nomap'),'','error');
	if(submitcheck('submit')){
		$md=daddslashes($_GET['d']);
		$dt=array();
		$da['static'] = dintval($md['static']);
		for($i=0;$i<count($md['data']['str']);$i++){
			if(empty($md['data']['wh'][$i]))
				$wh = '';
			else
				$wh = dintval(explode(',',$md['data']['wh'][$i]),true);
			if(empty($md['data']['pos'][$i])||!$da['static'])
				$pos = '';
			else
				$pos = dintval(explode(',',$md['data']['pos'][$i]),true);
			$dt[]=array(
				'str' => $md['data']['str'][$i],
				'color' => $md['data']['color'][$i]?$md['data']['color'][$i]:$cvar['fontcolor'],
				'size' => dintval($md['data']['size'][$i])?dintval($md['data']['size'][$i]):$cvar['fontsize'],
				'wh' => $wh,
				'pos' => $pos,
			);
		}
		if($md['font'] != $cvar['fontfile'] && file_exists(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.$md['font']) && !empty($md['font'])){
			$da['font'] = $md['font'];
		}else{
			$da['font'] = '';
		}
		$da['data'] = serialize($dt);
		$da['draw'] = dintval($md['draw']);
		if(!$da['static'])$da['draw'] = 0;
		$da['allow'] = dintval($md['allow']);
		$da['type'] = in_array($md['type'],array('1','2'))?$md['type']:0;
		$da['start'] = strtotime(dgmdate(strtotime($md['start']),'Y-m-d'));
		$da['end'] = strtotime(dgmdate(strtotime($md['end']),'Y-m-d'))+86390;
		C::t('#dc_seccode#dc_seccode_maps')->update($id,$da);
		switch($d['type']){
			case 0:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/publicmaps.php');break;
			case 1:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/festivalmaps.php');break;
			case 2:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/admaps.php');break;
		}
		switch($da['type']){
			case 0:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/publicmaps.php');break;
			case 1:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/festivalmaps.php');break;
			case 2:@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/config/admaps.php');break;
		}
		@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['filename']);
		cpmsg(plang('succeed'),'action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=edit&id='.$id,'succeed');
	}
	
	$d['data'] = dunserialize($d['data']);
	echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=edit');
	echo'<input type="hidden" value="'.$d['id'].'" name="id"/>';
	showtableheader(plang('seccode_info'), '');
	showsetting(plang('seccode_map'),'','','<div style="position:relative;width:356px;height:179px;background:#ececec url(source/plugin/dc_seccode/style/white/loading.gif) no-repeat center center"><img src="'.ADMINSCRIPT.'?action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=preview&id='.$id.'" onclick="aaa(event)"/></div><a href="'.ADMINSCRIPT.'?action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=imageupload&id='.$id.'">['.plang('change').']</a>');
	$dstr;
	showsetting(plang('seccode_static'),'d[static]',$d['static'],'radio');
	showtablefooter();/*Dism_taobao_com*/
	showtableheader();
	foreach($d['data'] as $t){
		$dstr.='<tr>
						<td><input type="text" name="d[data][str][]" value="'.$t['str'].'" size="8"/></td>
						<td><input type="text" name="d[data][color][]" value="'.$t['color'].'" size="8"/></td>
						<td><input type="text" name="d[data][size][]" value="'.$t['size'].'" size="8"/></td>
						<td><input type="text" name="d[data][wh][]" value="'.implode(',',$t['wh']).'" size="8" onclick="setwh(this);"/></td>
						<td><input type="text" name="d[data][pos][]" value="'.implode(',',$t['pos']).'" size="8" onclick="setpos(this);"/></td>
						<td><div><a href="javascript:;" onclick="deleterow(this)" class="addtr">'.plang('delete').'</a></div></td>
					</tr>';
			
	}
	showsetting(plang('seccode_manage'),'','','
		<table style="width:600px;">
			<tr>
				<td>'.plang('seccode_str').'</td>
				<td>'.plang('seccode_color').'</td>
				<td>'.plang('seccode_size').'</td>
				<td>'.plang('seccode_wh').'</td>
				<td>'.plang('seccode_pos').'</td>
				<td>'.plang('delete').'</td>
			</tr>
			'.$dstr.'
			<tr><td colspan="5"><div><a href="javascript:;" onclick="addrow(this)" class="addtr">'.plang('seccode_addstr').'</a></div></td></tr>
		</table>
		','','',plang('seccode_manage_msg'));
	showtablefooter();/*Dism_taobao_com*/
	showtableheader();
	showsetting(plang('seccode_draw'),'d[draw]',$d['draw'],'radio','','',plang('seccode_draw_msg'));
	showsetting(plang('seccode_font'),'d[font]',$d['font']?$d['font']:$cvar['fontfile'],'text','','',plang('seccode_font_msg'));
	$types = plang('seccode_types');
	foreach($types as $k => &$st){
		$st = array($k,$st);
	}
	showsetting(plang('seccode_type'),array('d[type]',$types),$d['type'],'select','','',plang('seccode_type_msg'));
	if(!$d['start'])$d['start'] = TIMESTAMP;
	if(!$d['end'])$d['end'] = TIMESTAMP;
	$d['start'] = dgmdate($d['start'],'Y-m-d');
	$d['end'] = dgmdate($d['end'],'Y-m-d');
	showsetting(plang('seccode_range'),array('d[start]','d[end]'),array($d['start'],$d['end']),'daterange','','',plang('seccode_range_msg'));
	showsetting(plang('seccode_status'),array('d[allow]',array(array(1,plang('ok')),array(0,plang('forbidden')))),$d['allow'],'mradio2');
	showtablefooter();/*Dism_taobao_com*/
	showsubmit('submit');
	showformfooter();
	echo'<script type="text/javascript">
		var whobj=null,posobj=null;
		var p={};
		function setwh(obj){
			whobj=obj;
			posobj=null;
			p={};
		}
		function setpos(obj){
			whobj=null;
			posobj=obj;
		}
		function aaa(e){
			var o = {};
			if (e.offsetX && e.offsetY) {
				o.X = e.offsetX;
				o.Y = e.offsetY;
			} else if (e.layerX && e.layerY) {
				o.X = e.layerX;
				o.Y = e.layerY
			};
			o.X = Math.ceil(o.X);
			o.Y = Math.ceil(o.Y);
			if(posobj!=null)
				posobj.value=o.X+","+o.Y;
			if(whobj!=null){
				if(!p.X){
					p.X=o.X;
					p.Y=o.Y;
				}else{
					whobj.value=Math.abs(o.X-p.X)+","+Math.abs(o.Y-p.Y);
					p={};
				}
			}
		}
	
	function addrow(obj) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
		var typedata = [\'<input type="text" name="d[data][str][]" value="" size="8"/>\',\'<input type="text" name="d[data][color][]" value="" size="8"/>\',\'<input type="text" name="d[data][size][]" value="" size="8"/>\',\'<input type="text" name="d[data][wh][]" value="" size="8" onclick="setwh(this);"/>\',\'<input type="text" name="d[data][pos][]" value="" size="8" onclick="setpos(this);"/>\',\'<div><a href="javascript:;" onclick="deleterow(this)" class="addtr">'.plang('delete').'</a></div>\'];
		for(var i = 0; i <= typedata.length - 1; i++) {
			var cell = row.insertCell(i);
			cell.innerHTML = typedata[i];
		}
	}

	function deleterow(obj) {
		var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		var tr = obj.parentNode.parentNode.parentNode;
		table.deleteRow(tr.rowIndex);
	}
		</script>';
	exit();
}elseif($act=='preview'){
	$id = dintval($_GET['id']);
	$map = C::t('#dc_seccode#dc_seccode_maps')->getbyid($id);
	if(!$map)
		cpmsg(plang('nomap'),'','error');
	$d = createmap($map);
	C::import('lib/image','plugin/dc_seccode',false);
	$im = new lib_image();
	if($d['static']){
		if($d['draw']){
			if(!file_exists(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image'])){
				$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
				foreach($d['data'] as $s){
					$im->Add($s);
				}
				$im->Watermark();
				if(!is_dir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.current(explode('/',$d['image'])))){
					if(!dcmkdir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.current(explode('/',$d['image'])).'/'))
						die('nowrite');
				}
				$im->save(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image']);
			
			}else{
				$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
				$im->Watermark();
			}
		}else{
			$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
			$im->Watermark();
		}
	}else{
		$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
		foreach($d['data'] as $s){
			$im->Add($s);
		}
		$im->Watermark();
	}
	ob_end_clean();
	ob_start();
	header('Content-Type: image/'.$im->gettype());
	$im->display();
	exit();
}elseif($act=='imageupload'){
	$id=dintval($_GET['id']);
	if(!C::t('#dc_seccode#dc_seccode_maps')->getbyid($id)&&$id)
		cpmsg(plang('nomap'),'','error');
	if(submitcheck('submit')){
		$tp = array("image/jpeg");
		if($_FILES["image"]['error'])
			cpmsg(plang('nofile'),'','error');
		switch($_FILES["image"]["type"]){
			case'image/jpeg':$ext='.jpg';break;
			default:cpmsg(plang('nojpg'),'','error');
		}
		$imagename=random(5).md5(time()).$ext;
		$result=move_uploaded_file($_FILES["image"]["tmp_name"],DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp/'.$imagename);
		list($w,$h)=getimagesize(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp/'.$imagename);
		if($result){
			$url=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=cutimage&file='.$imagename.'&id='.$id.'&w='.$w.'&h='.$h;
			dheader('location:'.$url);
		}else{
			cpmsg(plang('nowrite'),'','error');
		}
		exit();
	}
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=imageupload','enctype');
	if($id){
		echo'<input type="hidden" value="'.$id.'" name="id"/>';
		showtableheader(plang('seccode_edit'), '');
	}else{
		showtableheader(plang('seccode_add'), '');
	}
	showsetting(plang('seccode_upimage'),'image','','<input type="file" name="image">','','',plang('seccode_imagetype_msg'));
	showtablefooter();/*Dism_taobao_com*/
	showsubmit('submit');
	showformfooter();
	exit();
}elseif($act=='cutimage'){
	if(submitcheck('submit')){
		$id = dintval($_GET['id']);
		$file = daddslashes($_GET['image']);
		if(empty($file))
			cpmsg(plang('cuterror'),'','error');
		$file = 'source/plugin/dc_seccode/data/temp/'.$file;
		if(!file_exists(DISCUZ_ROOT.'./'.$file))
			cpmsg(plang('error'),'','error');
		if($id){
			$map = C::t('#dc_seccode#dc_seccode_maps')->getbyid($id);
			if(!$map)
				cpmsg(plang('nomap'),'','error');
			if(copy(DISCUZ_ROOT.'./'.$file,DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$map['filename'])){
				@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$map['filename']);
				$d = dir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp');
				while($f = $d->read()){
					if($f!='index.html')
						@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp/'.$f);
				}
				$url=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=edit&id='.$id;
				dheader('location:'.$url);
			}else{
				cpmsg(plang('nowrite'),'','error');
			}
		}else{
			$filename = dgmdate(TIMESTAMP,'Ym').'/'.dgmdate(TIMESTAMP,'dHis').random(4,1).'.'.end(explode(".",$file));
			if(!is_dir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.dgmdate(TIMESTAMP,'Ym').'/'))
				if(!dcmkdir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.dgmdate(TIMESTAMP,'Ym').'/'))
					cpmsg(plang('nowrite'),'','error');
			if(copy(DISCUZ_ROOT.'./'.$file,DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$filename)){
				$_GET['type'] = dintval($_GET['type']);
				if(!in_array($_GET['type'],array(0,1,2)))
					$_GET['type']=0;
				$str = daddslashes(trim($_GET['str']));
				if(empty($str)){
					$strarray = array();
				}else{
					$strarray = explode(',',$str);
				}
				$dt = array();
				foreach($strarray as $stri){
					$dt[]=array(
						'str' => trim($stri),
						'color' => $cvar['fontcolor'],
						'size' => $cvar['fontsize'],
						'wh' => array(),
						'pos' => array(),
					);
				}
				$data=array(
					'filename'=>$filename,
					'data'=>serialize($dt),
					'dateline'=>TIMESTAMP,
					'type'=>$_GET['type'],
					'allow'=>0,
				);
				$id = C::t('#dc_seccode#dc_seccode_maps')->insert($data,true);
				$url=ADMINSCRIPT.'?action=plugins&&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=edit&id='.$id;
				$d = dir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp/');
				while($f = $d->read()){
					if($f!='index.html')
						@unlink(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/temp/'.$f);
				}
				dheader('location:'.$url);
			}else{
				cpmsg(plang('nowrite'),'','error');
			}
		}
	}
	$file='source/plugin/dc_seccode/data/temp/'.$_GET['file'];
	$id=dintval($_GET['id']);
	$width=dintval($_GET['w'])?dintval($_GET['w']):356;
	$height=dintval($_GET['h'])?dintval($_GET['h']):179;
	if(!file_exists(DISCUZ_ROOT.'./'.$file))
		cpmsg(plang('error'),'','error');
	$url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=cutdownimage&formhash='.FORMHASH;
	showtableheader(plang('seccode_cut'), '');
	showtablefooter();/*Dism_taobao_com*/
	include template('dc_seccode:cutimage');
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps&act=cutimage');
	echo '<input type="hidden" value="" id="cutimage" name="image"/>';
	if($id){
		echo '<input type="hidden" value="'.$id.'" name="id"/>';
		showtableheader();
		showsubmit('submit');
		showtablefooter();/*Dism_taobao_com*/
	}else{
		$types = plang('seccode_types');
		foreach($types as $k => &$st){
			$st = array($k,$st);
		}
		showtableheader();
		showsetting(plang('seccode_type'),array('type',$types),'','select','','',plang('seccode_type_msg'));
		showsetting(plang('seccode_str'),'str','','text','','',plang('seccode_str_msg'));
		showsubmit('submit');
		showtablefooter();/*Dism_taobao_com*/
	}
	showformfooter();
	exit();
}elseif($act=='cutdownimage'){
	if(FORMHASH != $_GET['formhash']||strpos('source/plugin/dc_seccode/data/temp/',$_GET["imageSource"])!=false)
		exit();
	ob_end_clean();
	ob_start();
	list($width, $height) = getimagesize($_GET["imageSource"]);
	$viewPortW = $_GET["viewPortW"];
	$viewPortH = $_GET["viewPortH"];
	$pWidth = $_GET["imageW"];
	$pHeight =  $_GET["imageH"];
	$ext = end(explode(".",$_GET["imageSource"]));
	$function = returnCorrectFunction($ext);
	$image = $function($_GET["imageSource"]);
	$width = imagesx($image);
	$height = imagesy($image);
	$image_p = imagecreatetruecolor($pWidth, $pHeight);
	setTransparency($image,$image_p,$ext);
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $pWidth, $pHeight, $width, $height);
	imagedestroy($image);
	$widthR = imagesx($image_p);
	$hegihtR = imagesy($image_p);
	$selectorX = $_GET["selectorX"];
	$selectorY = $_GET["selectorY"];
	if($_GET["imageRotate"]){
		$angle = 360 - $_GET["imageRotate"];
		$image_p = imagerotate($image_p,$angle,0);
		$pWidth = imagesx($image_p);
		$pHeight = imagesy($image_p);
		$diffW = abs($pWidth - $widthR) / 2;
		$diffH = abs($pHeight - $hegihtR) / 2;	
		$_GET["imageX"] = ($pWidth > $widthR ? $_GET["imageX"] - $diffW : $_GET["imageX"] + $diffW);
		$_GET["imageY"] = ($pHeight > $hegihtR ? $_GET["imageY"] - $diffH : $_GET["imageY"] + $diffH);
	}
	$dst_x = $src_x = $dst_y = $src_y = 0;
	if($_GET["imageX"] > 0){
			$dst_x = abs($_GET["imageX"]);
	}else{
		$src_x = abs($_GET["imageX"]);
	}
	if($_GET["imageY"] > 0){
		$dst_y = abs($_GET["imageY"]);
	}else{
		$src_y = abs($_GET["imageY"]);
	}
	$viewport = imagecreatetruecolor($_GET["viewPortW"],$_GET["viewPortH"]);
	setTransparency($image_p,$viewport,$ext);
	imagecopy($viewport, $image_p, $dst_x, $dst_y, $src_x, $src_y, $pWidth, $pHeight);
	imagedestroy($image_p);
	$selector = imagecreatetruecolor($_GET["selectorW"],$_GET["selectorH"]);
	setTransparency($viewport,$selector,$ext);
	imagecopy($selector, $viewport, 0, 0, $selectorX, $selectorY,$_GET["viewPortW"],$_GET["viewPortH"]);
	$file = random(5).md5(time()).'.'.$ext;
	parseImage($ext,$selector,'source/plugin/dc_seccode/data/temp/'.$file);
	imagedestroy($viewport);
	echo $file;
	define('FOOTERDISABLED' , 1);
	exit();
}
$perpage = 15;
$start = ($page-1)*$perpage;
$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_seccode&pmod=maps';
$type = plang('seccode_types');
if(!isset($_GET['type'])){
	$str = plang('seccode_all');
	$where = '';
}else{
	$_GET['type'] = dintval($_GET['type']);
	$str = '<a href='.$mpurl.'>'.plang('seccode_all').'</a>';
	$where = array('type'=>$_GET['type']);
}
foreach($type as $k => $t){
	if($_GET['type']==$k&&isset($_GET['type']))
		$str .= '&nbsp;|&nbsp;'.$t;
	else
		$str .='&nbsp;|&nbsp;<a href='.$mpurl.'&type='.$k.'>'.$t.'</a>';
}
showtableheader(plang('seccode_manage').'(<a href="'.$mpurl.'&act=imageupload">'.plang('seccode_add').'</a>)&nbsp;&nbsp;('.$str.')', '');
showsubtitle(array(plang('seccode_thumb'), plang('seccode_word'),plang('seccode_hits'),plang('seccode_datetime'),plang('seccode_type'),plang('seccode_static'),plang('seccode_allow'),plang('caozuo')));
$count = C::t('#dc_seccode#dc_seccode_maps')->count($where);
$data =  C::t('#dc_seccode#dc_seccode_maps')->range($start,$perpage,$where,'DESC');
if($count){
	foreach($data as $d){
		$dt=unserialize($d['data']);
		$str='';
		foreach($dt as $z){
			$str.=','.$z['str'];
		}
		$str = substr($str,1);
		showtablerow('', array('class="td28"', '', '', '', '', ''), array(
			'<img src="source/plugin/dc_seccode/data/upload/'.$d['filename'].'" width="100" height="50"/>',
			$str,
			$d['hits'],
			dgmdate($d['dateline']),
			$type[$d['type']],
			$d['static']?plang('yes'):plang('no'),
			$d['allow']?plang('yes'):'<font color="#FF0000">'.plang('no').'</font>',
			'<a href="'.$mpurl.'&act=edit&id='.$d['id'].'" title="'.plang('edit').'">['.plang('edit').']</a> <a href="'.$mpurl.'&act=delete&id='.$d['id'].'" title="'.plang('delete').'">['.plang('delete').']</a>')
		);
	}
	$multipage = multi($count, $perpage, $page, $mpurl.(isset($_GET['type'])?'&type='.$_GET['type']:''));
	showsubmit('', '', '', '', $multipage);
}
showtablefooter();/*Dism_taobao_com*/
function plang($str) {
	return lang('plugin/dc_seccode', $str);
}
function createmap($map){
	$d=array();
	$d['image']=$map['filename'];
	$d['static']=$map['static'];
	$d['draw']=$map['draw'];
	$d['font']=$map['font'];
	$data=dunserialize($map['data']);
	$arr=array();
	foreach($data as $da){
		if(!$d['static']){
			do{
				$pos=array(rand(20,340-$da['wh'][0]),rand(10,160-$da['wh'][1]));
			}while(chkfanwei($pos,$da['wh'],$arr));
		}else{
			if(count($da['pos'])==2)
				$pos=$da['pos'];
			else
				$pos=array(0,0);
		}
		$arr[] =array(
			'str'=>diconv($da['str'],CHARSET,'utf-8'),
			'pos'=>array($pos[0],$pos[1]+$da['wh'][1]), //验证图输出坐标
			'lpos'=>array($pos[0],$pos[1]), //验证左上角坐标
			'color'=>$da['color'],
			'size'=>$da['size'],
			'cpos'=>array($pos[0]+$da['wh'][0],$pos[1]+$da['wh'][1]),//验证右下角坐标
		);
	}
	$d['data']=$arr;
	return $d;
}
function chkfanwei($p,$wh,$arr){
	if(empty($arr))
		return false;
	foreach($arr as $s){
		if(($s['pos'][0]-$wh[0])<$p[0]&&$p[0]<$s['cpos'][0]&&($s['pos'][1]-2*$wh[1])<$p[1]&&$p[1]<$s['cpos'][1])
			return true;
	}
	return false;	
}
function dcmkdir($dir, $mode = 0777, $makeindex = TRUE){
	if(!is_dir($dir)) {
		dcmkdir(dirname($dir), $mode, $makeindex);
		@mkdir($dir, $mode);
		if(!empty($makeindex)) {
			@touch($dir.'/index.html'); @chmod($dir.'/index.html', 0777);
		}
	}
	return true;
}



function determineImageScale($sourceWidth, $sourceHeight, $targetWidth, $targetHeight) {
		$scalex =  $targetWidth / $sourceWidth;
		$scaley =  $targetHeight / $sourceHeight;
		return min($scalex, $scaley);
	}
	function returnCorrectFunction($ext){
		$function = "";
		switch($ext){
			case "png":
				$function = "imagecreatefrompng";
				break;
			case "jpeg":
				$function = "imagecreatefromjpeg";
				break;
			case "jpg":
				$function = "imagecreatefromjpeg";
				break;
			case "gif":
				$function = "imagecreatefromgif";
				break;
		}
		return $function;
	}

	function parseImage($ext,$img,$file = null){
		switch($ext){
			case "png":
				imagepng($img,($file != null ? $file : ''));
				break;
			case "jpeg":
				imagejpeg($img,($file ? $file : ''),90);
				break;
			case "jpg":
				imagejpeg($img,($file ? $file : ''),90);
				break;
			case "gif":
				imagegif($img,($file ? $file : ''));
				break;
		}
	}
	function setTransparency($imgSrc,$imgDest,$ext){
		if($ext == "png" || $ext == "gif"){
			$trnprt_indx = imagecolortransparent($imgSrc);
			if ($trnprt_indx >= 0) {
				$trnprt_color    = imagecolorsforindex($imgSrc, $trnprt_indx);
				$trnprt_indx    = imagecolorallocate($imgDest, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				imagefill($imgDest, 0, 0, $trnprt_indx);
				imagecolortransparent($imgDest, $trnprt_indx);
			}
			elseif ($ext == "png") {
				imagealphablending($imgDest, true);
				$color = imagecolorallocatealpha($imgDest, 0, 0, 0, 127);
				imagefill($imgDest, 0, 0, $color);
				imagesavealpha($imgDest, true);
			}
		}
	}
//From: Dism_taobao-com
?>