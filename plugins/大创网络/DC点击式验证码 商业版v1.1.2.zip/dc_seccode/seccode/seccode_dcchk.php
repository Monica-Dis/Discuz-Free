<?php

class seccode_dcchk {
	var $version;
	var $name;
	var $copyright;
	var $setting = array();
	public function __construct(){
		$this->version = $this->plang('version');
		$this->name = $this->plang('name');
		$this->copyright = $this->plang('copyright');
	}
	function check($value, $idhash, $seccheck) {
		return $seccheck['code'] == strtoupper($value);
	}
	function make($idhash,$modid) {
		echo ($modid!='undefined'?'<script>var idhash=\''.$idhash.'\'</script><script src="source/plugin/dc_seccode/js/seccode.js"></script><script reload="1">dcclickchk=false;function dcclickinit(){if(document.readyState === "complete"&&$("seccodeverify_'.$idhash.'")){$("seccodeverify_'.$idhash.'").onclick=dcsecclick;}else{setTimeout(dcclickinit, 1000);}}function dcsecclick(obj){if(obj=="reload"||$("seccodeverify_'.$idhash.'").value==""){window.DcClick.Start({onSuccess: function (args, obj){$("seccodeverify_'.$idhash.'").value=obj.check_key;$("seccodeverify_'.$idhash.'").focus();dcclickchk=true;}});}}dcclickinit();':'<script reload="1">if(dcclickchk){dcclickchk=false;}else{dcsecclick("reload");}').'</script>';
	}
	function image($idhash, $modid){
		global $_G;
		if(!$_G['setting']['nocacheheaders']) {
			@header("Expires: -1");
			@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
			@header("Pragma: no-cache");
		}
		require_once libfile('class/seccode');
		$code = new seccode();
		$code->code = make_seccode();
		$code->type = 0;
		$code->width = $_G['setting']['seccodedata']['width'];
		$code->height = $_G['setting']['seccodedata']['height'];
		$code->background = $_G['setting']['seccodedata']['background'];
		$code->adulterate = $_G['setting']['seccodedata']['adulterate'];
		$code->ttf = $_G['setting']['seccodedata']['ttf'];
		$code->angle = $_G['setting']['seccodedata']['angle'];
		$code->warping = $_G['setting']['seccodedata']['warping'];
		$code->scatter = $_G['setting']['seccodedata']['scatter'];
		$code->color = $_G['setting']['seccodedata']['color'];
		$code->size = $_G['setting']['seccodedata']['size'];
		$code->shadow = $_G['setting']['seccodedata']['shadow'];
		$code->animator = $_G['setting']['seccodedata']['animator'];
		$code->fontpath = DISCUZ_ROOT.'./static/image/seccode/font/';
		$code->datapath = DISCUZ_ROOT.'./static/image/seccode/';
		$code->includepath = DISCUZ_ROOT.'./source/class/';
		$code->display();
	}
	public function plang($str){
		return lang('plugin/dc_seccode',$str);
	}
}
//From: Dism��taobao��com
?>