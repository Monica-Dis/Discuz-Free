<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$cvar = $_G['cache']['plugin']['dc_seccode'];
$data = getcookie('dcseccode');
$data = authcode($data);
$data = explode('|DC|',$data);
if(TIMESTAMP-$data[1]<300&&count($data)==2){
	$data = json_decode($data[0],true);
	$map = C::t('#dc_seccode#dc_seccode_maps')->getbyid($data['id']);
	$data = $data['data'];
	$d = array();
	$d['image'] = $map['filename'];
	$d['static']=$map['static'];
	$d['draw']=$map['draw'];
	$d['font']=$map['font'];
	$mapdata = dunserialize($map['data']);
	$arr=array();
	foreach($mapdata as $k => $da){
		$arr[] =array(
			'str'=>$data[$k][0],
			'pos'=>$data[$k][1], //验证图输出坐标
			'color'=>$da['color'],
			'size'=>$da['size'],
		);
	}
	$d['data']=$arr;
	C::import('lib/image','plugin/dc_seccode',false);
	$im = new lib_image();
	if($d['static']){
		if($d['draw']){
			if(!file_exists(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image'])){
				$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
				foreach($d['data'] as $s){
					$im->Add($s);
				}
				$im->Watermark();
				if(!is_dir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.current(explode('/',$d['image'])))){
					if(!C::mkdir(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.current(explode('/',$d['image'])).'/'))
						die('nowrite');
				}
				$im->save(DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image']);
			
			}else{
				$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/static/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
				$im->Watermark();
			}
		}else{
			$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
			$im->Watermark();
		}
	}else{
		$im->Set(array('source'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/upload/'.$d['image'],'font'=>DISCUZ_ROOT.'./source/plugin/dc_seccode/data/font/'.($d['font']?$d['font']:$cvar['fontfile'])));
		foreach($d['data'] as $s){
			$im->Add($s);
		}
		$im->Watermark();
	}
	DB::query('update %t set `hits` = `hits` + 1 where `id` = %d',array('dc_seccode_maps',$map['id']));
	header('Content-Type: image/'.$im->gettype());
	$im->display();
}
//From: Dism_taobao-com
?>