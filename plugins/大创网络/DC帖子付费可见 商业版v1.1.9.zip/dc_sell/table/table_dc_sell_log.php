<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dc_sell_log extends discuz_table
{

	public function __construct() {

		$this->_table = 'dc_sell_log';
		$this->_pk    = 'id';

		parent::__construct();/*DISM-TAOBAO-COM*/
	}
	public function fetch_by_pid($pid) {
		 return ($pid = dintval($pid, true)) ? DB::fetch_All('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::field('pid', $pid)) : array();
	}
	public function fetch_by_pcuid($pcuid,$ltime=0) {
		if(empty($pcuid))
			return array();
		if($ltime)
			$where = ' AND dateline>'.$ltime;
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::implode($pcuid, ' AND ').$where);
	}
	public function fetch_by_pcid($pcid) {
		if(empty($pcid))
			return array();
		 return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::implode($pcid, ' AND ').'  ORDER BY id DESC Limit 0,200');
	}
}
//From: Dism_taobao_com
?>