<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(submitcheck('delete')&&!empty($_GET['ids'])){
	$_GET['ids']=dintval($_GET['ids'],true);
	C::t('#dc_sell#dc_sell_log')->delete($_GET['ids']);
	cpmsg(plang('cpdeletesucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=log', 'succeed');
}
$search=daddslashes(trim($_GET['search']));
$perpage = 20;
$start = ($page-1)*$perpage;
if($search)
{
	$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=log&search='.$search;
	$sql="SELECT * FROM ".DB::table('dc_sell_log')." WHERE uid='$search' OR uname='$search' ORDER BY id DESC LIMIT $start,$perpage";
	$countsql="SELECT count(*) FROM ".DB::table('dc_sell_log')." WHERE uid='$search' OR uname='$search'";
}
else
{
	$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=log';
	$sql="SELECT * FROM ".DB::table('dc_sell_log')." ORDER BY id DESC LIMIT $start,$perpage";
	$countsql="SELECT count(*) FROM ".DB::table('dc_sell_log');
}
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=log');
showtableheader(plang('cpserch'), '');
showtablerow('', array('class="td25"', ''), array(
	plang('cpserch').":",
	'<input type="text" name="search" autocomplete="off" placeholder="'.plang('cpserchmsg').'" value="" /> <input type="submit" class="btn" name="submit" value="'.plang('cpserch').'">',
	)
);
showtablefooter();/*dis'.'m.tao'.'bao.com*/
/*Dism_taobao-com*/showformfooter();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=dc_sell&pmod=log');
showtableheader(plang('cplog'), '');
showsubtitle(array('',plang('cppayer'), plang('cphuafei'),plang('cppost'),plang('cpauthorid'),plang('cpincome'),plang('cptime')));
$query=DB::query($sql);
$count = DB::result_first($countsql);
if($count){
	while($r = DB::fetch($query)) {
		showtablerow('', array('class="td25"', 'class=""', 'class="td28"', 'class="td28"', 'class="td28"'), array(
						"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"$r[pid]\">",
						'<a href="home.php?mod=space&uid='.$r['uid'].'" target="_blank">'.$r['uname'].'</a>',
						$r['pay'].$_G['setting']['extcredits'][$r['extcredit']]['title'],
						'<a href="forum.php?mod=redirect&goto=findpost&pid='.$r['pid'].'" target="_blank">'.$r['pid'].'</a>/'.$r['cid'],
						$r['authorid'],
						$r['authorincome'].$_G['setting']['extcredits'][$r['extcredit']]['title'],
						dgmdate($r['dateline']))
					);
	}
	$multipage = multi($count, $perpage, $page, $mpurl);
	showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.plang('cpcheckall').'</label>&nbsp;&nbsp;
					<input type="submit" class="btn" name="delete" value="'.plang('cpdelete').'" onclick="if(confirm(\''.plang('cpdeletemsg').'\')){this.form.submit();}"/>', $multipage);
}
showtablefooter();/*dis'.'m.tao'.'bao.com*/
/*Dism_taobao-com*/showformfooter();

function plang($str) {
	return lang('plugin/dc_sell', $str);
}
//From: Dism_taobao-com
?>