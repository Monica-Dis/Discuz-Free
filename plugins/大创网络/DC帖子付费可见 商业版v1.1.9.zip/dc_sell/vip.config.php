<?php

return array(
	'view'=>array(
		'title'=>'vip_hook_allow',
		'des'=>'vip_hook_allow_msg',
	),
);
?>