<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_yueka {
        function global_cpnav_extra2() {
	global $_G;
	$config = $_G['cache']['plugin']['yueka'];
	$url = '<a href="plugin.php?id=yueka" target="_blank"><font color="red">'.lang('plugin/yueka','pname').'</font></a>';

		if ($config['open'] == 1){
                        return (''.$url.'');
                } else {
                        return array();
	        }
	}

        function global_footerlink() {
	global $_G;
	$config = $_G['cache']['plugin']['yueka'];
	$url = ' <span class="pipe">|</span> <a href="plugin.php?id=yueka" target="_blank"><font color="red">'.lang('plugin/yueka','pname').'</font></a>';

		if ($config['open'] == 2){
                        return (''.$url.'');
                } else {
                        return array();
	        }
	}

        function global_usernav_extra3() {
	global $_G;
	$config = $_G['cache']['plugin']['yueka'];
	$url = '<a href="plugin.php?id=yueka" target="_blank"><font color="red">'.lang('plugin/yueka','pname').'</font></a> <span class="pipe">|</span>';

		if ($config['open'] == 3){
                        return (''.$url.'');
                } else {
                        return array();
	        }
	}
}

class plugin_yueka_forum extends plugin_yueka {
	function viewthread_avatar_output() {
	global $postlist,$_G;
		foreach($postlist as $key => $val) {
			$postuid[] = $val['authorid'];
			$inyueka=C::t('#yueka#yueka')->fetch(intval($val['authorid']));
			if($inyueka){
				$img[] = '<div style="text-align:center;width:auto;"><a href="plugin.php?id=yueka" target="_blank"><img src="source/plugin/yueka/images/inyueka.gif" width="120" height="26" border="0" /></a></div>';	
			}else{
				$img[] = '';
			}
		}
		return $img;			
	}
}

class plugin_yueka_home extends plugin_yueka {
	function space_profile_baseinfo_top() {
	global $_G;
	$inyueka=C::t('#yueka#yueka')->fetch(intval($_GET['uid']));
	$img = '<div style="text-align:left;margin:5px 0px;"><a href="plugin.php?id=yueka" target="_blank"><img src="source/plugin/yueka/images/inyueka.gif" width="140" height="30" border="0" /></a></div>';
		if ($inyueka){
			return $img;
		}
	}
}
//From: dis'.'m.tao'.'bao.com
?>