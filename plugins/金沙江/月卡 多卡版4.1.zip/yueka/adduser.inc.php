<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$config=$_G['cache']['plugin']['yueka'];

$yknamelist = explode ("\n", str_replace ("\r", "", $config ['yuekaname']));
foreach($yknamelist as $key=>$value){
	$arr=explode('=',$value);
	$ykname[$arr[0]]=$arr[1];
}
$yksetlist = explode ("\n", str_replace ("\r", "", $config ['yuekaset']));
foreach($yksetlist as $value){
	$arr = explode("#", $value);
	$number[] = $arr[0];
	$pay[] = $arr[1];
	$wage[] = $arr[2];
}

$jdknamelist = explode ("\n", str_replace ("\r", "", $config ['jidukaname']));
foreach($jdknamelist as $key=>$value){
	$arr=explode('=',$value);
	$jdkname[$arr[0]]=$arr[1];
}
$jdksetlist = explode ("\n", str_replace ("\r", "", $config ['jidukaset']));
foreach($jdksetlist as $value){
	$arr = explode("#", $value);
	$jnumber[] = $arr[0];
	$jpay[] = $arr[1];
	$jwage[] = $arr[2];
}

if(submitcheck('formhash')){
	$uid = intval($_POST['uid']);
	$inyk=C::t('#yueka#yueka')->fetch($uid);
	$result = DB::query("SELECT * FROM ".DB::table('ucenter_members')." where uid='$uid' LIMIT 1 ");
	while ($rows = DB::fetch($result)){
		$name=addslashes($rows['username']);
		$userid=intval($rows['uid']);
	}
	if ($inyk){
		cpmsg(lang('plugin/yueka','admin_1'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=adduser', 'error');
	}
	if (empty($name) || empty($userid)){
		cpmsg(lang('plugin/yueka','admin_2'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=adduser', 'error');
	}
	$data=array();
	$data['uid']=$uid;
	$data['username']=$name;
	$data['day']=intval($_POST['day']);
	$data['card']=intval($_POST['card']);
		$yksort = intval($_POST['yksort']);
		$jdksort = intval($_POST['jdksort']);
		if($data['day']=='30'){
			$data['sort']=$yksort;
			$data['wage']=intval($wage[$yksort-1]);
		}else if($data['day']=='90'){
			$data['sort']=$jdksort;
			$data['wage']=intval($jwage[$jdksort-1]);
		}
		if($_POST['paytime']==""){
			$data['paytime']=$_G['timestamp'];
		}else{
			$data['paytime']=intval(strtotime($_POST['paytime']));
		}
		if($data['paytime']=='0' || empty($data['paytime'])){
			cpmsg(lang('plugin/yueka','admin_3'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=adduser', 'error');
		}
	C::t('#yueka#yueka')->insert($data);
	cpmsg(lang('plugin/yueka','payok'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$plugins.'&pmod=adduser', 'succeed');
}

	include template('yueka:add');
?>