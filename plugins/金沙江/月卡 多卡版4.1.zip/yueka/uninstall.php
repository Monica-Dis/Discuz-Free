<?php
/*
	by:www.jsj.pw
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_yueka`;
EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE; /*dism��taobao��com*/
?>