<?php
/*
	by:www.jsj.pw
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_yueka` (
	`uid` int(10) NOT NULL auto_increment,
	`username` varchar(255) NOT NULL,
	`day` int(10) NOT NULL,
	`sort` int(10) NOT NULL,
	`wage` int(10) NOT NULL,
	`card` int(10) NOT NULL,
	`paytime` int(10) NOT NULL,
	`rectime` int(10) NOT NULL,
	PRIMARY KEY  (`uid`)
);
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE; /*dism��taobao��com*/
?>