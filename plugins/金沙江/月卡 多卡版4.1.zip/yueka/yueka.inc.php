<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$config=$_G['cache']['plugin']['yueka'];
$jfzl=$_G['setting']['extcredits'][$config['jifen']]['title'];
$jfunit=$_G['setting']['extcredits'][$config['jifen']]['unit'];
$jfye = getuserprofile('extcredits'.$config['jifen']);

$yknamelist = explode ("\n", str_replace ("\r", "", $config ['yuekaname']));
foreach($yknamelist as $key=>$value){
	$arr=explode('=',$value);
	$ykname[$arr[0]]=$arr[1];
}
$yksetlist = explode ("\n", str_replace ("\r", "", $config ['yuekaset']));
foreach($yksetlist as $value){
	$arr = explode("#", $value);
	$number[] = $arr[0];
	$pay[] = $arr[1];
	$wage[] = $arr[2];
}

$jdknamelist = explode ("\n", str_replace ("\r", "", $config ['jidukaname']));
foreach($jdknamelist as $key=>$value){
	$arr=explode('=',$value);
	$jdkname[$arr[0]]=$arr[1];
}
$jdksetlist = explode ("\n", str_replace ("\r", "", $config ['jidukaset']));
foreach($jdksetlist as $value){
	$arr = explode("#", $value);
	$jnumber[] = $arr[0];
	$jpay[] = $arr[1];
	$jwage[] = $arr[2];
}

$jfytlist = explode("\n", $config['jfyt']);
$jfytnum = count($jfytlist);
$yk=C::t('#yueka#yueka')->fetch(intval($_G['uid']));
$time = date("Ymd");
$uidlist=C::t('#yueka#yueka')->fetch_all_by_thisyk($_GET['day'],0,14);

if($_GET['act']=='pay'){
	$uid = intval($_G['uid']);
	if(empty($_G['uid'])){
		showmessage(lang('plugin/yueka','login'), '', array(), array('login' => true));
	}elseif ($_G['uid'] == $yk['uid']){
		showmessage(lang('plugin/yueka','notpay'));
	}else{
		if(submitcheck('formhash')){
			$total = intval($_POST['card']*$_POST['pay']);
			if ($jfye<$total || $total<='0'){
				showmessage(lang('plugin/yueka','buzu'));
			}
			$data=array();
	        	$data['uid']=$_G['uid'];
	        	$data['username']=$_G['username'];
			$data['paytime']=$_G['timestamp'];
			$data['day']=intval($_POST['day']);
			$data['card']=intval($_POST['card']);
			$data['sort']=intval($_POST['sort']);
			$data['wage']=intval($_POST['wage']);
			updatemembercount(''.$_G['uid'].'', array(''.$config['jifen'].'' => -"$total"), true, '', 0, '');
			C::t('#yueka#yueka')->insert($data);
				echo "<script>alert('".lang('plugin/yueka','payok')."');
					window.top.location.href='plugin.php?id=yueka&type=use'</script>";
                 		exit;
		}			
	}
	include template('yueka:buy');

}else if($_GET['act']=='rec'){
	$uid = intval($_G['uid']);
	$fx = intval($yk['card']*$yk['wage']);
	if(empty($_G['uid'])){
		showmessage(lang('plugin/yueka','login'), '', array(), array('login' => true));
	}elseif (empty($yk['uid'])){
                showmessage(lang('plugin/yueka','pay'));
	}elseif ($yk['rectime'] >= $time){
		showmessage(lang('plugin/yueka','notrec'));
	}elseif ($yk['paytime']+86400*$yk['day'] < $_G['timestamp']){
		if($_GET['formhash']==$_G['formhash']){
			DB::query("DELETE FROM ".DB::table('yueka')." WHERE uid='$uid' LIMIT 1 ");
			showmessage(lang('plugin/yueka','timeover'), 'plugin.php?id=yueka&type=use', array(), array('alert' => 'error', 'showdialog' => true, 'locationtime' => '5'));
		}
	}else{
		if($_GET['formhash']==$_G['formhash']){
			DB::query("UPDATE ".DB::table('yueka')." SET rectime='$time' WHERE uid='$uid' LIMIT 1 ");
			updatemembercount(''.$_G['uid'].'', array(''.$config['jifen'].'' => +"$fx"), true, '', 0, '');
			showmessage(lang('plugin/yueka','recok'), 'plugin.php?id=yueka&type=use', array(), array('alert' => 'right', 'showdialog' => true, 'locationtime' => true));
		}
	}

}else{
	$navtitle = ''.(lang('plugin/yueka','pname')).'';
	include template('yueka:yueka');
}