<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/config.php';

$model = addslashes($_GET['model']);


if (submitcheck('typepost2')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 2;
    $result           = DB::update('zimucms_shantie_type1', $addata, array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else if (submitcheck('typepost3')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 3;
    $result           = DB::update('zimucms_shantie_type1', $addata, array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else if (submitcheck('typepost4')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 4;
    $result           = DB::update('zimucms_shantie_type1', $addata, array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else {
    
    $page    = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page    = intval($page);
    $leixing = intval($_GET['leixing']);
    
    if ($leixing) {
        $wheresql = 'where status = ' . $leixing;
    } else {
        $wheresql = '';
    }
    $count = DB::result_first("SELECT count(*) FROM %t " . $wheresql, array(
        "zimucms_shantie_type1"
    ));
    
    $limit    = 30;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $stlist = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_shantie_type1',
        $start,
        $limit
    ));
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . intval($_GET['leixing']) . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
    }
    include template('zimucms_shantie:qinquanlist');
    
}