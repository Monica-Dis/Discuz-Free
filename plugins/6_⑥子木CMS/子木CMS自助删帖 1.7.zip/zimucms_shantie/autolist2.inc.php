<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/config.php';

$model = addslashes($_GET['model']);


if (submitcheck('typepost2')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $post_url     = intval($_GET['post_url']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 2;
    $result           = DB::update('zimucms_shantie_type2', $addata, array(
        'id' => $mid
    ));

    C::t('forum_thread')->update_displayorder_by_tid_displayorder($post_url, 0, -1);

    $addata3['invisible'] = -1;
    DB::update('forum_post', $addata3, array(
        'tid' => $post_url
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else if (submitcheck('typepost3')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 3;
    $result           = DB::update('zimucms_shantie_type2', $addata, array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else if (submitcheck('typepost4')) {
    
    $leixing = intval($_GET['leixing']);
    $mid     = intval($_GET['mid']);
    $beizhu  = strip_tags(zm_diconv($_GET['beizhu']));
    
    $addata['beizhu'] = $beizhu;
    $addata['status'] = 4;
    $result           = DB::update('zimucms_shantie_type2', $addata, array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . $leixing . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_shantie', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_shantie', 'system_text2'), '', 'error');
    }
    
} else {
    
    $page    = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page    = intval($page);
    $leixing = intval($_GET['leixing']);
    
    if ($leixing) {
        $wheresql = 'where status = ' . $leixing;
        $wheresql2 = 'where a.status = ' . $leixing;
    } else {
        $wheresql = '';
    }
    $count = DB::result_first("SELECT count(*) FROM %t " . $wheresql, array(
        "zimucms_shantie_type2"
    ));
    
    $limit    = 30;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);


$aaa = DB::query('select a.*,b.subject as post_title from %t a left join %t b on a.post_url=b.tid '.$wheresql2.' order by addtime desc limit %d,%d', array('zimucms_shantie_type2','forum_thread',$start,$limit));

    while($res = DB::fetch($aaa)){
           $stlist[] = $res;
        }


    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&leixing=' . intval($_GET['leixing']) . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
    }
    include template('zimucms_shantie:autolist2');
    
}