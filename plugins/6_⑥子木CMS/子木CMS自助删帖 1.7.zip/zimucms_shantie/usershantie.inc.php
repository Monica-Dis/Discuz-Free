<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/config.php';

$model = addslashes($_GET['model']);

isuid();

if ($model == 'deltype2' && $_GET['md5hash'] == formhash()) {
    
    $deltid = intval($_GET['deltid']);

    $ismypost = DB::fetch_first('select * from %t where tid=%d', array(
        'forum_thread',
        $deltid
        ));

    $isdel = DB::fetch_first('select * from %t where post_url=%d and uid=%d', array(
        'zimucms_shantie_type2',
        $deltid,
        $_G['uid']
        ));


    if($ismypost['authorid'] != $_G['uid']){

showmessage(lang('plugin/zimucms_shantie', 'system_text8'), '', 'error');
exit();

    }

    if($isdel){

showmessage(lang('plugin/zimucms_shantie', 'system_text10'), '', 'error');
exit();

    }

    if($zmdata['auto_scoretype'] && $zmdata['auto_scorenums']){

        $auto_scoretype = explode(',',$zmdata['auto_scoretype']);

        $auto_scorenums = explode(',',$zmdata['auto_scorenums']);


        foreach ($auto_scoretype as $key => $value) {

            $myscore = getuserprofile('extcredits' . $value);

            if($myscore < $auto_scorenums[$key] ){

showmessage(lang('plugin/zimucms_shantie', 'system_text9'), '', 'error');
exit();

            }

        }

        foreach ($auto_scoretype as $key => $value) {

            updatemembercount($_G['uid'], array(
                'extcredits' . $value => '-' . $auto_scorenums[$key]
                ), true, 'shantie', 1, 'zmshantie');


        }


    }

    if($zmdata['auto_isshenhe']){

        $name       = strip_tags(zm_diconv($_GET['name']));
        $mobile     = strip_tags(zm_diconv($_GET['mobile']));
        $post_title = strip_tags(zm_diconv($_GET['post_title']));
        $post_url   = strip_tags(zm_diconv($_GET['post_url']));
        $post_text  = strip_tags(zm_diconv($_GET['post_text']));
        
        $adddata = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'post_url' => $deltid,
            'status' => 1,
            'addtime' => $_G['timestamp']
            );
        
        $result = DB::insert('zimucms_shantie_type2', $adddata);

        if ($result) {
showmessage(lang('plugin/zimucms_shantie','system_text11'), '', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));   
exit();
        } else { 
showmessage(lang('plugin/zimucms_shantie', 'system_text10'), '', 'error');
exit();
        }


    }else{


        $isdel = DB::fetch_first('select * from %t where post_url=%d and uid=%d', array(
            'zimucms_shantie_type2',
            $deltid,
            $_G['uid']
            ));

        if($isdel){

showmessage(lang('plugin/zimucms_shantie', 'system_text10'), '', 'error');
exit();

        }


        $adddata2 = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'post_url' => $deltid,
            'status' => 2,
            'addtime' => $_G['timestamp']
            );
        $result = DB::insert('zimucms_shantie_type2', $adddata2);


        require_once libfile('function/forum');
        $_GET['tid'] = $deltid;
        global $_G;
        loadforum();

        $thread = $_G['forum_thread'];
        $thread['dblastpost'] = $thread['lastpost'];
        $threadlist[$thread['tid']] = $thread;


        loadcache('threadtableids');
        $stickmodify = 0;
        $deleteredirect = $remarkclosed = array();
        foreach($threadlist as $thread) {
            if($thread['digest']) {
                updatecreditbyaction('digest', $thread['authorid'], array('digestposts' => -1), '', -$thread['digest']);
            }
            if(in_array($thread['displayorder'], array(2, 3))) {
                $stickmodify = 1;
            }
            if($_G['forum']['status'] == 3 && $thread['closed'] > 1) {
                $deleteredirect[] = $thread['closed'];
            }
            if($thread['isgroup'] == 1 && $thread['closed'] > 1) {
                $remarkclosed[] = $thread['closed'];
            }
        }

        $modaction = 'DEL';
        require_once libfile('function/delete');
        $tids = array_keys($threadlist);
        if($_G['forum']['recyclebin']) {

            deletethread($tids, true, true, true);
            manage_addnotify('verifyrecycle', $modpostsnum);
        } else {

            deletethread($tids, true, true);
            $updatemodlog = FALSE;
        }

        $forumstickthreads = $_G['setting']['forumstickthreads'];
        $forumstickthreads = !empty($forumstickthreads) ? dunserialize($forumstickthreads) : array();
        $delkeys = array_keys($threadlist);
        foreach($delkeys as $k) {
            unset($forumstickthreads[$k]);
        }
        C::t('common_setting')->update('forumstickthreads', $forumstickthreads);

        C::t('forum_forum_threadtable')->delete_none_threads();
        if(!empty($deleteredirect)) {
            deletethread($deleteredirect);
        }
        if(!empty($remarkclosed)) {
            C::t('forum_thread')->update($remarkclosed, array('closed'=>0));
        }

        if($_G['setting']['globalstick'] && $stickmodify) {
            require_once libfile('function/cache');
            updatecache('globalstick');
        }

        updateforumcount($_G['fid']);

        if($_GET['crimerecord']) {
            include_once libfile('function/member');
            foreach($threadlist as $thread) {
                crime('recordaction', $thread['authorid'], 'crime_delpost', lang('forum/misc', 'crime_postreason', array('reason' => $reason, 'tid' => $thread['tid'], 'pid' => 0)));
            }
        }
        
        C::t('forum_thread')->update_displayorder_by_tid_displayorder($deltid,0,-1);



        
        if ($result) {
            
            $adddata = array(
                'tid' => $deltid,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'dateline' => $_G['timestamp'],
                'action' => 'DEL',
                'status' => 1,
                'magicid' => 0,
                'stamp' => 0,
                'reason' => lang('plugin/zimucms_shantie', 'system_text3')
                );
            
            DB::insert('forum_threadmod', $adddata);


showmessage(lang('plugin/zimucms_shantie','system_text11'), '', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));   
exit();

        } else {
            
showmessage(lang('plugin/zimucms_shantie', 'system_text10'), '', 'error');
exit();
            
        }
    }   
}