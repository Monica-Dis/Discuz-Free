<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/config.php';

$model = addslashes($_GET['model']);

isuid();

if ($model == 'todo') {

    $type = intval($_GET['type']);
    
    if ($type == 1) {
        include template('zimucms_shantie:type1');
    } else {

        $auto_beginday = $zmdata['auto_beginday'];

$del_forums = (array) unserialize($zmdata['del_forums']);
if($del_forums[0]>0){
$wherefid = 'and ' . DB::field('fid',$del_forums,'in');
}else{
$wherefid = '';
}
        if($auto_beginday > 0){


            $mypost = DB::fetch_all('select * from %t where authorid=%d and displayorder !=-1 and dateline<%d '.$wherefid.' order by tid desc limit %d', array(
                'forum_thread',
                $_G['uid'],
                $_G['timestamp'] - $auto_beginday*86400,
                $zmdata['auto_postnums']
                ));


        }else{

            $mypost = DB::fetch_all('select * from %t where authorid=%d and displayorder !=-1 '.$wherefid.' order by tid desc limit %d', array(
                'forum_thread',
                $_G['uid'],
                $zmdata['auto_postnums']
                ));
        }
        
        include template('zimucms_shantie:type2');
        
        
        
    }
    
    
} else if ($model == 'savetype1' && $_GET['md5hash'] == formhash()) {

    $name       = strip_tags(zm_diconv($_GET['name']));
    $mobile     = strip_tags(zm_diconv($_GET['mobile']));
    $post_title = strip_tags(zm_diconv($_GET['post_title']));
    $post_url   = strip_tags(zm_diconv($_GET['post_url']));
    $post_text  = strip_tags(zm_diconv($_GET['post_text']));
        if (!empty($_GET['post_img'])) {
            foreach ($_GET['post_img'] as $key => $file) {
                $file = str_replace('data:image/png;base64,', '', $file);
                $file = str_replace('data:image/jpeg;base64,', '', $file);
                $picurl . $key = savebasepic($file);
                $picontent .= '<p><img src="source/plugin/zimucms_shantie' . $picurl . $key . '"></p>';
            }
        }

    $adddata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'name' => $name,
        'mobile' => $mobile,
        'post_title' => $post_title,
        'post_url' => $post_url,
        'post_text' => $post_text.$picontent,
        'status' => 1,
        'addtime' => $_G['timestamp']
        );
    
    $result = DB::insert('zimucms_shantie_type1', $adddata);
    
    if (!$result) {

        $out['status'] = 2;
        echo $result = json_encode($out);
        exit();
        
        
    } else {

        $qinquan_sendmessage_user = explode(',', $zmdata['qinquan_sendmessage_user']);
        foreach ($qinquan_sendmessage_user as $key => $value) {
            notification_add($value, 'system', lang('plugin/zimucms_shantie', 'system_text5'), array(), 1);
        }
        
        $out['status'] = 1;
        echo $result = json_encode($out);
        exit();
        
    }
    
} else if ($model == 'deltype2' && $_GET['md5hash'] == formhash()) {

    $deltid = intval($_GET['deltid']);

    $ismypost = DB::fetch_first('select * from %t where tid=%d', array(
        'forum_thread',
        $deltid
        ));

    $isdel = DB::fetch_first('select * from %t where post_url=%d and uid=%d', array(
        'zimucms_shantie_type2',
        $deltid,
        $_G['uid']
        ));


    if($ismypost['authorid'] != $_G['uid']){
        $out['status'] = 3;
        echo $result = json_encode($out);
        exit();
    }

    if($isdel){
        $out['status'] = 1;
        echo $result = json_encode($out);
        exit();
    }

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname'],$zmdata['qf_token']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $myscore = $appdata['data']['gold'];
        if ($myscore < $zmdata['qf_jifen']) {
            $out['status'] = 4;
            echo $result = json_encode($out);
            exit();
        }
        $qf_jifen = 0 - $zmdata['qf_jifen'];
        $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type'],'gold' => $qf_jifen,'reason' => 'shantie']);

    }else {
        if ($zmdata['auto_scoretype'] && $zmdata['auto_scorenums']) {

            $auto_scoretype = explode(',', $zmdata['auto_scoretype']);

            $auto_scorenums = explode(',', $zmdata['auto_scorenums']);


            foreach ($auto_scoretype as $key => $value) {

                $myscore = getuserprofile('extcredits' . $value);

                if ($myscore < $auto_scorenums[$key]) {
                    $out['status'] = 4;
                    echo $result = json_encode($out);
                    exit();
                }

            }

            foreach ($auto_scoretype as $key => $value) {

                updatemembercount($_G['uid'], array(
                    'extcredits' . $value => '-' . $auto_scorenums[$key]
                ), true, 'shantie', 1, 'zmshantie');


            }


        }
    }

    if($zmdata['auto_isshenhe']){

        $name       = strip_tags(zm_diconv($_GET['name']));
        $mobile     = strip_tags(zm_diconv($_GET['mobile']));
        $post_title = strip_tags(zm_diconv($_GET['post_title']));
        $post_url   = strip_tags(zm_diconv($_GET['post_url']));
        $post_text  = strip_tags(zm_diconv($_GET['post_text']));

        $adddata = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'post_url' => $deltid,
            'status' => 1,
            'addtime' => $_G['timestamp']
            );

        $result = DB::insert('zimucms_shantie_type2', $adddata);

        if ($result) {
            $out['status'] = 1;
            echo $result2 = json_encode($out);
            exit();
        } else { 
            $out['status'] = 2;
            echo $result = json_encode($out);
            exit();
        }


    }else{


        $isdel = DB::fetch_first('select * from %t where post_url=%d and uid=%d', array(
            'zimucms_shantie_type2',
            $deltid,
            $_G['uid']
            ));

        if($isdel){
            $out['status'] = 1;
            echo $result = json_encode($out);
            exit();
        }


        $adddata2 = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'post_url' => $deltid,
            'status' => 2,
            'addtime' => $_G['timestamp']
            );
        $result = DB::insert('zimucms_shantie_type2', $adddata2);


        require_once libfile('function/forum');
        $_GET['tid'] = $deltid;
        global $_G;
        loadforum();

        $thread = $_G['forum_thread'];
        $thread['dblastpost'] = $thread['lastpost'];
        $threadlist[$thread['tid']] = $thread;


        loadcache('threadtableids');
        $stickmodify = 0;
        $deleteredirect = $remarkclosed = array();
        foreach($threadlist as $thread) {
            if($thread['digest']) {
                updatecreditbyaction('digest', $thread['authorid'], array('digestposts' => -1), '', -$thread['digest']);
            }
            if(in_array($thread['displayorder'], array(2, 3))) {
                $stickmodify = 1;
            }
            if($_G['forum']['status'] == 3 && $thread['closed'] > 1) {
                $deleteredirect[] = $thread['closed'];
            }
            if($thread['isgroup'] == 1 && $thread['closed'] > 1) {
                $remarkclosed[] = $thread['closed'];
            }
        }

        $modaction = 'DEL';
        require_once libfile('function/delete');
        $tids = array_keys($threadlist);
        if($_G['forum']['recyclebin']) {

            deletethread($tids, true, true, true);
            manage_addnotify('verifyrecycle', $modpostsnum);
        } else {

            deletethread($tids, true, true);
            $updatemodlog = FALSE;
        }

        $forumstickthreads = $_G['setting']['forumstickthreads'];
        $forumstickthreads = !empty($forumstickthreads) ? dunserialize($forumstickthreads) : array();
        $delkeys = array_keys($threadlist);
        foreach($delkeys as $k) {
            unset($forumstickthreads[$k]);
        }
        C::t('common_setting')->update('forumstickthreads', $forumstickthreads);

        C::t('forum_forum_threadtable')->delete_none_threads();
        if(!empty($deleteredirect)) {
            deletethread($deleteredirect);
        }
        if(!empty($remarkclosed)) {
            C::t('forum_thread')->update($remarkclosed, array('closed'=>0));
        }

        if($_G['setting']['globalstick'] && $stickmodify) {
            require_once libfile('function/cache');
            updatecache('globalstick');
        }

        updateforumcount($_G['fid']);

        if($_GET['crimerecord']) {
            include_once libfile('function/member');
            foreach($threadlist as $thread) {
                crime('recordaction', $thread['authorid'], 'crime_delpost', lang('forum/misc', 'crime_postreason', array('reason' => $reason, 'tid' => $thread['tid'], 'pid' => 0)));
            }
        }

        C::t('forum_thread')->update_displayorder_by_tid_displayorder($deltid,0,-1);




        if ($result) {

            $adddata = array(
                'tid' => $deltid,
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'dateline' => $_G['timestamp'],
                'action' => 'DEL',
                'status' => 1,
                'magicid' => 0,
                'stamp' => 0,
                'reason' => lang('plugin/zimucms_shantie', 'system_text3')
                );

            DB::insert('forum_threadmod', $adddata);

            $out['status'] = 1;
            echo $result2 = json_encode($out);
            exit();
        } else {

            $out['status'] = 2;
            echo $result = json_encode($out);
            exit();

        }
    }   
} else if ($model == 'usertype1') {

    $zmdata['plugin_type'] = addslashes($zmdata['plugin_type']);
    
    $plugin_type = explode(',', $zmdata['plugin_type']);
    
    foreach ($plugin_type as $key => $value) {

        $typearr[] = explode('=', $value);
        
    }
    
    $mypost = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimucms_shantie_type1',
        $_G['uid']
        ));
    
    include template('zimucms_shantie:usertype1');

} else if ($model == 'usertype2') {

    $zmdata['plugin_type'] = addslashes($zmdata['plugin_type']);
    
    $plugin_type = explode(',', $zmdata['plugin_type']);
    
    foreach ($plugin_type as $key => $value) {

        $typearr[] = explode('=', $value);
        
    }

    $aaa = DB::query('select a.*,b.subject as post_title from %t a left join %t b on a.post_url=b.tid where a.uid=%d order by dateline desc', array('zimucms_shantie_type2','forum_thread',$_G['uid']));

    while($res = DB::fetch($aaa)){
     $mypost[] = $res;
 }

 include template('zimucms_shantie:usertype2');

} else {


    $zmdata['plugin_type'] = addslashes($zmdata['plugin_type']);
    
    $plugin_type = explode(',', $zmdata['plugin_type']);
    
    foreach ($plugin_type as $key => $value) {

        $typearr[] = explode('=', $value);
        
    }
    
    include template('zimucms_shantie:newindex');
    
}