<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

echo '<div class="infobox"><h4 class="infotitle3">'.lang('plugin/zimucms_shantie', 'system_text4').'<a href="'.$_G['siteurl'].'plugin.php?id=zimucms_shantie" target="_blank">'.$_G['siteurl'].'plugin.php?id=zimucms_shantie</a></h4><p class="marginbot"></p></div>';
exit();