<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

error_reporting(0);

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_shantie/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_shantie');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimucms_shantie'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
	$charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
	$charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
	$charset = 'big5';
}

function zm_diconv($str) {
	$encode = mb_detect_encoding($str, array(
		"ASCII",
		"UTF-8",
		"GB2312",
		"GBK",
		"BIG5",
	));
	if ($encode != CHARSET) {
		//$keytitle = iconv($encode,CHARSET."//IGNORE",$str);
		$keytitle = mb_convert_encoding($str, CHARSET, $encode);
	}
	if (!$keytitle) {
		$keytitle = $str;
	}
	return $keytitle;
}

function isuid() {
	global $_G;
	define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
	define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
	define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
	$zmdata = $_G['cache']['plugin']['zimucms_shantie'];
	$refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_shantie';

	if (IN_MAGAPP && !$_G['uid']) {

		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$info = strstr($userAgent, "MAGAPPX");
		$info = explode("|", $info);
		$token = $info[7];

		$appurl = $zmdata['magapp_hostname'] . '/mag/cloud/cloud/getUserInfo?token=' . $token . '&secret=' . $zmdata['magapp_secret'];
		$appdata = dfsockopen($appurl);
		if (!$appdata) {
			$appdata = file_get_contents($appurl);
		}
		$r = json_decode($appdata, true);
		if ($r['data']['user_id'] > 0) {

			$member = getuserbyuid($r['data']['user_id'], 1);
			if (!$member) {
				dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
				exit();
			}
			if (isset($member['_inarchive'])) {
				C::t('common_member_archive')->move_to_master($member['uid']);
			}
			require_once libfile('function/member');
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			return true;

		} else {
			exit('<script src="source/plugin/zimucms_shantie/static/js/magjs-x.js"></script><script>
            mag.toLogin(function(){
                top.location.href="' . $refererurl . '";
                });
                </script>');
		}

	} else if (IN_QFAPP && !$_G['uid'] && $zmdata['qf_hostname']) {

		require_once DISCUZ_ROOT . './source/plugin/zimucms_shantie/qfapp.class.php';
        // ʹ��ʾ��
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname'],$zmdata['qf_token']);
		$appdata = $client->post('users/parse-wap-token', ['wap_token' => $_COOKIE['wap_token']]);

		if ($appdata['data']['uid'] > 0) {

			$member = getuserbyuid($appdata['data']['uid'], 1);
			if (!$member) {
				dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
				exit();
			}
			if (isset($member['_inarchive'])) {
				C::t('common_member_archive')->move_to_master($member['uid']);
			}
			require_once libfile('function/member');
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			return true;

		} else {
			exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
		}

	} else {

		if (!$zmdata['isguest']) {
			if (!$_G['uid']) {
				$refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_shantie';
				if (IN_XIAOYUNAPP) {
					exit('<script language="javascript" src="source/plugin/zimucms_shantie/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
				} else if (IN_MAGAPP) {
					exit('<script src="//app.lxh.magcloud.cc/public/static/dest/js/libs/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $refererurl . '";
  });
    </script>');
				} else if (IN_QFAPP) {
					exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
				} else {
					dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
					exit();
				}
			}
		}
	}

}

function savebasepic($post) {
	if (!file_exists(dirname(__FILE__) . '/uploads/' . date("Ymd"))) {
		mkdir(dirname(__FILE__) . '/uploads/' . date("Ymd"));
	}
	$picname = '/uploads/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
	$file = dirname(__FILE__) . $picname;
	$base64 = base64_decode($post);
	$save = file_put_contents($file, $base64);
	if ($save) {
		return $picname;
	}
}
function get_response($secret_key, $url, $get_params, $post_data = array()) {
	$nonce = rand(10000, 99999);
	$timestamp = time();
	$array = array($nonce, $timestamp, $secret_key);
	sort($array, SORT_STRING);
	$token = md5(implode($array));
	$params['nonce'] = $nonce;
	$params['timestamp'] = $timestamp;
	$params['token'] = $token;

	$params = array_merge($params, $get_params);

	$url .= '?';
	foreach ($params as $k => $v) {
		$url .= $k . '=' . $v . '&amp;';
	}
	$url = rtrim($url, '&amp;');

	$curlHandle = curl_init();
	curl_setopt($curlHandle, CURLOPT_URL, $url);
	curl_setopt($curlHandle, CURLOPT_HEADER, 0);
	curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($curlHandle, CURLOPT_POST, count($post_data));
	curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $post_data);
	$data = curl_exec($curlHandle);
	$status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
	curl_close($curlHandle);

	return $data;
}