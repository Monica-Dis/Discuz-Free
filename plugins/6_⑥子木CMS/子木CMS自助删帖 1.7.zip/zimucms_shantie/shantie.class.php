<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_zimucms_shantie
{
}

class plugin_zimucms_shantie_forum extends plugin_zimucms_shantie
{
    
    
    function viewthread_postheader_output()
    {
        global $_G;

        $zmdata = $_G['cache']['plugin']['zimucms_shantie'];
        $del_forums = (array) unserialize($zmdata['del_forums']);

        if($_G['timestamp'] - $_G['forum_thread']['dateline'] > $zmdata['auto_beginday']*86400 && $_G['forum_thread']['authorid'] == $_G['uid'] && (in_array($_G['fid'], $del_forums)|| !$del_forums[0]) ){

            if($zmdata['auto_scoretype'] && $zmdata['auto_scorenums']){

                $auto_scoretype = explode(',',$zmdata['auto_scoretype']);

                $auto_scorenums = explode(',',$zmdata['auto_scorenums']);


                foreach ($auto_scoretype as $key => $value) {

                    $scorename = $scorename . $auto_scorenums[$key].' '.$_G['setting']['extcredits'][$auto_scoretype[$key]]['title'].' ';

                }

            }
            $html[0] = "<a href='javascript:;'' onclick=\"showDialog('".lang('plugin/zimucms_shantie','system_text7').$scorename."','confirm','".lang('plugin/zimucms_shantie','system_text6')."','parent.location.href=\'{$_G[siteurl]}plugin.php?id=zimucms_shantie:usershantie&model=deltype2&deltid={$_G[tid]}&md5hash={$_G[formhash]}\'','1','','','".lang('plugin/zimucms_shantie','system_text13')."','".lang('plugin/zimucms_shantie','system_text14')."');\"><font color='red'>".lang('plugin/zimucms_shantie','system_text12')."</font></a>";
            return $html;
        }
    }

}


class mobileplugin_zimucms_shantie
{
}


class mobileplugin_zimucms_shantie_forum extends mobileplugin_zimucms_shantie
{ 

    function viewthread_bottom_mobile_output()
    {
        global $_G;

        $zmdata = $_G['cache']['plugin']['zimucms_shantie'];
        $del_forums = (array) unserialize($zmdata['del_forums']);
        if($_G['timestamp'] - $_G['forum_thread']['dateline'] > $zmdata['auto_beginday']*86400 && $_G['forum_thread']['authorid'] == $_G['uid'] && (in_array($_G['fid'], $del_forums)|| !$del_forums[0]) ){

            if($zmdata['auto_scoretype'] && $zmdata['auto_scorenums']){

                $auto_scoretype = explode(',',$zmdata['auto_scoretype']);

                $auto_scorenums = explode(',',$zmdata['auto_scorenums']);


                foreach ($auto_scoretype as $key => $value) {

                    $scorename = $scorename . $auto_scorenums[$key].' '.$_G['setting']['extcredits'][$auto_scoretype[$key]]['title'].' ';

                }

            }




            include template('zimucms_shantie:usershantie');
            return $html;
        }
    }

}