<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

header("Location:".ADMINSCRIPT.'?action=recyclebin'); 
exit();
