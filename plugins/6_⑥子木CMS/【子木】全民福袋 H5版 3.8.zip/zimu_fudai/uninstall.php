<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_fudai_addlucky_list;
DROP TABLE  IF EXISTS pre_zimu_fudai_catlist;
DROP TABLE  IF EXISTS pre_zimu_fudai_list;
DROP TABLE  IF EXISTS pre_zimu_fudai_luckylist;
DROP TABLE  IF EXISTS pre_zimu_fudai_userdata;
DROP TABLE  IF EXISTS pre_zimu_xcx_accesstoken;
EOF;

runquery($sql);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_fudai/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_fudai/static/admin/kindeditor/attached/image");



deletecache('scache_zimu_fudai');
$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}
function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}