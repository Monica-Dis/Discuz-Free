<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimu_fudai_addlucky_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(100) NOT NULL,
  `touid` int(10) unsigned NOT NULL,
  `fid` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `typename` char(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  `luckkeywords` char(30) NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `touid` (`touid`),
 KEY `fid` (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fudai_catlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fudai_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `thumb` varchar(200) NOT NULL,
  `giftname` varchar(100) NOT NULL,
  `price` char(10) NOT NULL,
  `allnums` smallint(3) unsigned NOT NULL,
  `vipnums` smallint(3) unsigned NOT NULL,
  `vipnums2` smallint(3) unsigned NOT NULL,
  `chance` smallint(3) unsigned NOT NULL,
  `get_chance` smallint(3) unsigned NOT NULL,
  `rule` text NOT NULL,
  `weixin_rule` text NOT NULL,
  `introduce` text NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `exchangetime` int(10) unsigned NOT NULL,
  `luckyname1` char(20) NOT NULL,
  `luckyname2` char(20) NOT NULL,
  `luckyname3` char(20) NOT NULL,
  `luckyname4` char(20) NOT NULL,
  `luckyname5` char(20) NOT NULL,
  `luckyname6` char(20) NOT NULL,
  `luckyname7` char(20) NOT NULL,
  `luckyname8` char(20) NOT NULL,
  `sort` smallint(3) unsigned NOT NULL DEFAULT '100',
  `adduserinfo` tinyint(1) unsigned NOT NULL,
  `day_lucky_nums` smallint(3) unsigned NOT NULL,
  `link_lucky_nums` smallint(3) unsigned NOT NULL,
  `pic_lucky_nums` smallint(3) unsigned NOT NULL,
  `app_lucky_nums` smallint(3) unsigned NOT NULL,
  `weixin_lucky_nums` smallint(3) unsigned NOT NULL,
  `weixin_lucky_url` varchar(1000) NOT NULL,
  `weixin_avatar` varchar(1000) NOT NULL,
  `weixin_lucky_keywords` char(50) NOT NULL,
  `weixin_lucky_more` text NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `usednums` smallint(3) unsigned NOT NULL,
  `share_title` char(255) NOT NULL,
  `share_desc` char(255) NOT NULL,
  `share_thumb` char(255) NOT NULL,
  `haibao_bg` varchar(2000) NOT NULL,
  `haibao_qrcode_setting` varchar(2000) NOT NULL,
  `haibao_text_setting` text NOT NULL,
  `leixing` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `leixing1_tip` char(200) NOT NULL,
  `leixing3_mima` char(100) NOT NULL,
  `shopuid` char(50) NOT NULL,
  `noword_bg` char(255) NOT NULL,
  `hasword_bg` char(255) NOT NULL,
  `word_position` char(20) NOT NULL,
  `fd_domains` varchar(100) NOT NULL,
  `plugin_color` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fudai_luckylist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `username` char(100) NOT NULL,
  `luckyid` int(10) unsigned NOT NULL,
  `luckyname` char(10) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `fid` (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fudai_userdata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `username` char(200) NOT NULL,
  `realname` char(30) NOT NULL,
  `mobile` char(20) NOT NULL,
  `luckynums1` smallint(3) unsigned NOT NULL,
  `luckynums2` smallint(3) unsigned NOT NULL,
  `luckynums3` smallint(3) unsigned NOT NULL,
  `luckynums4` smallint(3) unsigned NOT NULL,
  `luckynums5` smallint(3) unsigned NOT NULL,
  `luckynums6` smallint(3) unsigned NOT NULL,
  `luckynums7` smallint(3) unsigned NOT NULL,
  `luckynums8` smallint(3) unsigned NOT NULL,
  `alllucky` char(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `luckytime` int(10) unsigned NOT NULL,
  `exchangestatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `exchangetime` int(10) unsigned NOT NULL,
  `leixing1_text` char(200) NOT NULL,
  PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `fid` (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_xcx_accesstoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `gender` tinyint(1) unsigned NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `openid` char(200) NOT NULL,
  `unionid` char(200) NOT NULL,
  `token` char(200) NOT NULL,
  `xcx_appid` char(100) NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE;
?>