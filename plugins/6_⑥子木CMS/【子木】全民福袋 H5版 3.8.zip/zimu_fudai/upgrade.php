<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$fudai_list = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_fudai_list'));
$fudai_list_array = mysqltoarray($fudai_list);
if (!in_array('haibao_bg', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `haibao_bg` VARCHAR(2000) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('haibao_qrcode_setting', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `haibao_qrcode_setting` VARCHAR(2000) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('haibao_text_setting', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `haibao_text_setting` TEXT NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('leixing', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `leixing` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}
if (!in_array('leixing1_tip', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `leixing1_tip` CHAR(200) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('leixing3_mima', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `leixing3_mima` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('shopuid', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `shopuid` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('noword_bg', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `noword_bg` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('hasword_bg', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `hasword_bg` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('word_position', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `word_position` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('weixin_rule', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `weixin_rule` TEXT NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('adduserinfo', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `adduserinfo` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('weixin_lucky_more', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `weixin_lucky_more` TEXT NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('fd_domains', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `fd_domains` VARCHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('vipnums2', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `vipnums2` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('get_chance', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `get_chance` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('plugin_color', $fudai_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_list` ADD COLUMN `plugin_color` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}


$fudai_userdata = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_fudai_userdata'));
$fudai_userdata_array = mysqltoarray($fudai_userdata);
if (!in_array('leixing1_text', $fudai_userdata_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_userdata` ADD COLUMN `leixing1_text` CHAR(200) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('realname', $fudai_userdata_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_userdata` ADD COLUMN `realname` CHAR(30) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('mobile', $fudai_userdata_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_userdata` ADD COLUMN `mobile` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('luckytime', $fudai_userdata_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_userdata` ADD COLUMN `luckytime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}


$addlucky_list = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_fudai_addlucky_list'));
$addlucky_list_array = mysqltoarray($addlucky_list);
if (!in_array('status', $addlucky_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_addlucky_list` ADD COLUMN `status` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('luckkeywords', $addlucky_list_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_fudai_addlucky_list` ADD COLUMN `luckkeywords` CHAR(30) NOT NULL;
EOF;
    runquery($sql1);
}

    $sql1 = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_zimu_xcx_accesstoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `gender` tinyint(1) unsigned NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `openid` char(200) NOT NULL,
  `unionid` char(200) NOT NULL,
  `token` char(200) NOT NULL,
  `xcx_appid` char(100) NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;
    runquery($sql1);





$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}