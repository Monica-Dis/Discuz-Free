<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$langfile = DISCUZ_ROOT . './source/plugin/zimu_fudai/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_fudai');

include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_fudai/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_fudai');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimu_fudai'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

$_G['isajax'] = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
$_G['ispost'] = $_SERVER['REQUEST_METHOD'] == 'POST';

function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    $zmdata = $_G['cache']['plugin']['zimu_fudai'];
        if (!$_G['uid']) {
    $referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];


    if (IN_MAGAPP && !$_G['uid'] && $zmdata['magapp_hostname']){
        

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info = strstr($userAgent, "MAGAPPX");
        $info=explode("|",$info);
        $token = $info[7];

        $appurl = $zmdata['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$zmdata['magapp_secret'];
        
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        }else{
            exit('<script src="source/plugin/zimu_fudai/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $referer . '";
                    });
                    </script>'); 
        }

    }else if (IN_QFAPP && !$_G['uid'] && $zmdata['qf_hostname'] && $zmdata['qf_token']){

        require_once DISCUZ_ROOT . './source/plugin/zimu_fudai/class/qfapp.class.php';
        // 使用示例
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname'],$zmdata['qf_token']);
        $appdata = $client->post('users/parse-wap-token', ['wap_token' => $_COOKIE['wap_token']]);

        if ($appdata['data']['uid'] > 0) {

            $member = getuserbyuid($appdata['data']['uid'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        } else {
            exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
        }

    }else{

            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_fudai/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $referer . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_fudai/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $referer . '";
  });
    </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }


        }

}
    }

function createWebUrl($do, $query = array(), $isadminscript)
{
    
    global $plugin, $module, $pluginid;
    
    if (!empty($query)) {
        $queryString = http_build_query($query, '', '&');
    }
    
    if ($isadminscript) {
        
        return 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&' . $queryString;
        
    } else {
        
        return ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&' . $queryString;
        
    }
    
}

function createMobileUrl($do, $query = array())
{
    
    if (!empty($query)) {
        $queryString = '&' . http_build_query($query, '', '&');
    }
    
    return ZIMUCMS_URL . '&op=' . $do . $queryString;
    
}


function createMobileApiUrl($do, $query = array())
{
    
    if (!empty($query)) {
        $queryString = http_build_query($query, '', '&');
    }
    
    return ZIMUCMS_URL . ':zimu_api&op=' . $do . '&' . $queryString;
    
}


function zimu_json_encode($String)
{
    return urldecode(json_encode($String));
}


function zimu_urlencode($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_urlencode($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = urlencode($String);
        }
    }
    return $String;
}


function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}

function zimu_diconv($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_diconv($val);
        }
    } else {
        $String = zm_diconv($String);
    }
    return $String;
}

function tpl_form_field_image($id, $val)
{
    if (!$val) {
        $val = 'source/plugin/zimu_fudai/static/nopic.jpg';
    }
    
    return '<div class="input-group "><td class="vatop rowform"><span class="type-file-box"><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="type-file-text" style="height: 34px;color: #555;background-color: #fff;background-image: none;border: 1px solid #ccc;border-radius: 4px 0 0 4px;" /><input type="button" name="button" id="button1" value="Upload Pic" class="type-file-button" style="color:#333;background-color:#fff;border-color: #ccc;border-radius: 0px 4px 4px 0px;margin-left: -2px;border-left: 0px solid #ccc;;height: 34px;padding: 0px 10px;" /><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" size="30" hidefocus="true"></span></td>
  </div><div class="input-group " style="margin-top:16px;"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150"></div>';
    
}

function ArrayAddslashes($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = ArrayAddslashes($val);
        }
    } else {
        if (is_numeric($String)) {
            if (is_int($String)) {
                $String = dhtmlspecialchars((int) $String);
            } else {
                $String = dhtmlspecialchars((float) $String);
            }
        } else {
            $String = dhtmlspecialchars(addslashes($String));
        }
    }
    return $String;
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_fudai']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_fudai']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_fudai']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}

function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;
    
    require_once DISCUZ_ROOT . './source/plugin/zimu_fudai/new_discuz_upload.php';
    
    $upload = new discuz_upload_zimucms();
    
    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];
    
    if ($upload->attach['imageinfo'][0] > 1500 || $upload->attach['imageinfo'][1] > 1500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }
        
        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }

    if ($pic2) {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic;
    }
}



function zimu_writetocache($key = 'plugin_zimu_fudai', $array = array())
{
    
    if (strpos($key, 'plugin_zimu') !== false) {
        
        $datas     = $array;
        $cachedata = " return " . var_export($datas, TRUE) . ";";
        
        global $_G;
        
        $dir = DISCUZ_ROOT . "./data/sysdata/";
        if (!is_dir($dir)) {
            dmkdir($dir, 0777);
        }
        $file = "$dir/$key.php";
        if ($fp = @fopen($file, 'wb')) {
            fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($key . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n$cachedata?>");
            fclose($fp);
        } else {
            exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
        }
    }
}

function zimu_readfromcache($key = 'plugin_zimu_fudai')
{
    
    if (strpos($key, 'plugin_zimu') !== false) {
        
        $ret = array();
        
        $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
        if (is_file($file)) {
            $ret = include $file;
        }
        
        return $ret;
    }
}

function zimu_deletefromcache($key = 'plugin_zimu_fudai')
{
    
    if (strpos($key, 'plugin_zimu') !== false) {
        
        $cache_file = DISCUZ_ROOT . "./data/sysdata/$key.php";
        if (is_file($cache_file)) {
            @unlink($cache_file);
        }
        return TRUE;
    }
}


function zimu_authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
{
    
    if ($operation == 'DECODE') {
        $string = str_replace('[a]', '+', $string);
        $string = str_replace('[b]', '&', $string);
        $string = str_replace('[c]', '/', $string);
    }
    $ckey_length   = 4;
    $key           = md5($key ? $key : 'livcmsencryption ');
    $keya          = md5(substr($key, 0, 16));
    $keyb          = md5(substr($key, 16, 16));
    $keyc          = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length) : substr(md5(microtime()), -$ckey_length)) : '';
    $cryptkey      = $keya . md5($keya . $keyc);
    $key_length    = strlen($cryptkey);
    $string        = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;
    $string_length = strlen($string);
    $result        = '';
    $box           = range(0, 255);
    $rndkey        = array();
    for ($i = 0; $i <= 255; $i++) {
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);
    }
    for ($j = $i = 0; $i < 256; $i++) {
        $j       = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp     = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }
    for ($a = $j = $i = 0; $i < $string_length; $i++) {
        $a       = ($a + 1) % 256;
        $j       = ($j + $box[$a]) % 256;
        $tmp     = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if ($operation == 'DECODE') {
        if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26) . $keyb), 0, 16)) {
            
            return substr($result, 26);
        } else {
            return '';
        }
    } else {
        $ustr = $keyc . str_replace('=', '', base64_encode($result));
        $ustr = str_replace('+', '[a]', $ustr);
        $ustr = str_replace('&', '[b]', $ustr);
        $ustr = str_replace('/', '[c]', $ustr);
        return $ustr;
    }
}

function savebasepic($post,$name)
{
    if (!file_exists(dirname(__FILE__) . '/uploadzimucms/haibao/')) {
        mkdir(dirname(__FILE__) . '/uploadzimucms/haibao/');
    }
    $picname = '/uploadzimucms/haibao/'.$name;
    $file    = dirname(__FILE__) . $picname;
    $base64  = base64_decode($post);
    $save    = file_put_contents($file, $base64);
    if ($save) {
        return $picname;
    }
}
function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

function getnewname($username)
{
    global $_G;

    $newname = cutstr(WeChatEmoji::clear($username), 15, '');
    $newname = removeEmoji($newname);
    if ($newname) {
        $censorexp = '/^(' . str_replace(array(
            '\\*',
            "\r\n",
            ' '
        ), array(
            '.*',
            '|',
            ''
        ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
        $newname   = preg_replace($censorexp, '', $newname);
        
        $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
        $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
    }
    
    if (dstrlen($newname) >= 3) {
        loaducenter();
        if (uc_get_user($newname)) {
         $nums = 1;
         $oldname = $newname;
        do {
            $newname = $oldname.$nums;
            $nums++;
        } while (uc_get_user($newname));
        $newname = cutstr($newname, 14, '');
        }
    } else if ($newname) {
        $newname = $newname . '_' . random(5);
    } else {
        $newname = 'wx_' . random(5);
    }
    
    return $newname;
}

function register($username, $inapi = 0, $groupid = 0, $sex = 0)
{
    global $_G;

    require_once libfile('function/member');

    if (!$username && IN_WECHATAPI) {
        echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
        exit;
    } else if (!$username) {
        showmessage('undefined_action');
    }
    
    if (!$zmdata) {
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
    }
    
    loaducenter();
    $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;
    
    $password = md5(random(10));
    $email    = 'weixin_' . strtolower(random(10)) . '@null.null';
    
    $usernamelen = dstrlen($username);
    if ($usernamelen < 3) {
        $username = $username . '_' . random(5);
    }
    if ($usernamelen > 15) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_toolong');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_toolong'));
            exit;
        }
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    
    if (@preg_match($censorexp, $username)) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_protect');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            exit;
        }
    }
    
    if (!$zmdata['discuz_disableregrule']) {
        loadcache('ipctrl');
        if ($_G['cache']['ipctrl']['ipregctrl']) {
            foreach (explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                if (preg_match("/^(" . preg_quote(($ctrlip = trim($ctrlip)), '/') . ")/", $_G['clientip'])) {
                    $ctrlip                   = $ctrlip . '%';
                    $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                    break;
                } else {
                    $ctrlip = $_G['clientip'];
                }
            }
        } else {
            $ctrlip = $_G['clientip'];
        }
        
        if ($_G['setting']['regctrl']) {
            if (C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp'] - $_G['setting']['regctrl'] * 3600)) {
                if (!IN_WECHATAPI) {
                    showmessage('register_ctrl', null, array(
                        'regctrl' => $_G['setting']['regctrl']
                    ));
                } else {
                    echo WeChatServer::getXml4Txt(lang('message', 'register_ctrl', array(
                        'regctrl' => $_G['setting']['regctrl']
                    )));
                    exit;
                }
            }
        }
        
        $setregip = null;
        if ($_G['setting']['regfloodctrl']) {
            $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp'] - 86400);
            if ($regip) {
                if ($regip['count'] >= $_G['setting']['regfloodctrl']) {
                    if (!IN_WECHATAPI) {
                        showmessage('register_flood_ctrl', null, array(
                            'regfloodctrl' => $_G['setting']['regfloodctrl']
                        ));
                    } else {
                        echo WeChatServer::getXml4Txt(lang('message', 'register_flood_ctrl', array(
                            'regfloodctrl' => $_G['setting']['regfloodctrl']
                        )));
                        exit;
                    }
                } else {
                    $setregip = 1;
                }
            } else {
                $setregip = 2;
            }
        }
        
        if ($setregip !== null) {
            if ($setregip == 1) {
                C::t('common_regip')->update_count_by_ip($_G['clientip']);
            } else {
                C::t('common_regip')->insert(array(
                    'ip' => $_G['clientip'],
                    'count' => 1,
                    'dateline' => $_G['timestamp']
                ));
            }
        }
    }
    
    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if ($uid <= 0) {
        if (!IN_WECHATAPI) {
            if ($uid == -1) {
                showmessage('profile_username_illegal');
            } elseif ($uid == -2) {
                showmessage('profile_username_protect');
            } elseif ($uid == -3) {
                showmessage('profile_username_duplicate');
            } elseif ($uid == -4) {
                showmessage('profile_email_illegal');
            } elseif ($uid == -5) {
                showmessage('profile_email_domain_illegal');
            } elseif ($uid == -6) {
                showmessage('profile_email_duplicate');
            } else {
                showmessage('undefined_action');
            }
        } else {
            if ($uid == -1) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
            } elseif ($uid == -2) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            } elseif ($uid == -3) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
            } elseif ($uid == -4) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
            } elseif ($uid == -5) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
            } elseif ($uid == -6) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
            } else {
                echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
            }
            exit;
        }
    }
    
    $init_arr = array(
        'credits' => explode(',', $_G['setting']['initcredits']),
        'profile' => array(
            'gender' => $sex
        )
    );
    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
    
    if ($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if ($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array(
                'ip' => $_G['clientip'],
                'count' => -1,
                'dateline' => $_G['timestamp']
            ));
        }
    }
    
    if ($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => ''
        ), false, true);
        manage_addnotify('verifyuser');
    }
    
    setloginstatus(array(
        'uid' => $uid,
        'username' => $username,
        'password' => $password,
        'groupid' => $groupid
    ), 0);
    

    include_once libfile('function/stat');
    updatestat('register');
    
    return $uid;
}


function syncAvatar($uid, $avatar)
{
    
    if (!$uid || !$avatar) {
        return false;
    }
    
    if (!$content = dfsockopen($avatar)) {
        return false;
    }
    
    $tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
    file_put_contents($tmpFile, $content);
    
    if (!is_file($tmpFile)) {
        return false;
    }
    $result = uploadUcAvatar($uid, $tmpFile);
    unlink($tmpFile);
    
    C::t('common_member')->update($uid, array(
        'avatarstatus' => '1'
    ));
    return $result;
}

function uploadUcAvatar($uid, $localFile)
{
    
    global $_G;
    if (!$uid || !$localFile) {
        return false;
    }
    
    list($width, $height, $type, $attr) = getimagesize($localFile);
    if (!$width) {
        return false;
    }
    if ($width < 10 || $height < 10 || $type == 4) {
        return false;
    }
    
    $imageType = array(
        1 => '.gif',
        2 => '.jpg',
        3 => '.png'
    );
    $fileType  = $imgType[$type];
    if (!$fileType) {
        $fileType = '.jpg';
    }
    $avatarPath = $_G['setting']['attachdir'];
    $tmpAvatar  = $avatarPath . './temp/upload' . $uid . $fileType;
    file_exists($tmpAvatar) && @unlink($tmpAvatar);
    file_put_contents($tmpAvatar, file_get_contents($localFile));
    
    if (!is_file($tmpAvatar)) {
        return false;
    }
    
    $tmpAvatarBig    = './temp/upload' . $uid . 'big' . $fileType;
    $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
    $tmpAvatarSmall  = './temp/upload' . $uid . 'small' . $fileType;
    
    $image = new image;
    if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
        return false;
    }
    
    $tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
    $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
    $tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
    $avatar1         = byte2hex(file_get_contents($tmpAvatarBig));
    $avatar2         = byte2hex(file_get_contents($tmpAvatarMiddle));
    $avatar3         = byte2hex(file_get_contents($tmpAvatarSmall));
    
    $extra  = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
    $result = uc_api_post_ex('user', 'rectavatar', array(
        'uid' => $uid
    ), $extra);
    
    @unlink($tmpAvatar);
    @unlink($tmpAvatarBig);
    @unlink($tmpAvatarMiddle);
    @unlink($tmpAvatarSmall);
    return true;
}

function byte2hex($string)
{
    $buffer = '';
    $value  = unpack('H*', $string);
    $value  = str_split($value[1], 2);
    $b      = '';
    foreach ($value as $k => $v) {
        $b .= strtoupper($v);
    }
    
    return $b;
}

function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
{
    $s = $sep = '';
    foreach ($arg as $k => $v) {
        $k = urlencode($k);
        if (is_array($v)) {
            $s2 = $sep2 = '';
            foreach ($v as $k2 => $v2) {
                $k2 = urlencode($k2);
                $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                $sep2 = '&';
            }
            $s .= $sep . $s2;
        } else {
            $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
        }
        $sep = '&';
    }
    $postdata = uc_api_requestdata($module, $action, $s, $extra);
    return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
}
   function removeEmoji($text) {
        $clean_text = "";
        // Match Emoticons
        $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
        $clean_text = preg_replace($regexEmoticons, '', $text);
        // Match Miscellaneous Symbols and Pictographs
        $regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
        $clean_text = preg_replace($regexSymbols, '', $clean_text);
        // Match Transport And Map Symbols
        $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
        $clean_text = preg_replace($regexTransport, '', $clean_text);
        // Match Miscellaneous Symbols
        $regexMisc = '/[\x{2600}-\x{26FF}]/u';
        $clean_text = preg_replace($regexMisc, '', $clean_text);
        // Match Dingbats
        $regexDingbats = '/[\x{2700}-\x{27BF}]/u';
        $clean_text = preg_replace($regexDingbats, '', $clean_text);
if(!$clean_text){
$clean_text = $text;
}
        return $clean_text;
    }

function bind_login($uid)
{
    global $_G;
    
    if (!($member = getuserbyuid($uid, 1))) {
        return 'error';
    }else {
        if (isset($member['_inarchive'])) {
            C::t('common_member_archive')->move_to_master($member['uid']);
        }
    }
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($uid, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));
    return true;
}
 function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;

   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)生成介于min和max两个数之间的一个随机整数
   }

   return $str;
}
function xcx_select_uid($xcx_zimu_data){
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimu_fudai'];

if($xcx_zimu_data['unionid']){

$isuid = DB::fetch_first('select * from %t where unionid=%s and xcx_appid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $xcx_zimu_data['unionid'],
        $zmdata['xcx_appid']
    ));

}else{

$isuid = DB::fetch_first('select * from %t where openid=%s and xcx_appid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $xcx_zimu_data['openid'],
        $zmdata['xcx_appid']
    ));

}

return $isuid;


}
function xcx_reg_user($xcx_zimu_data){
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimu_fudai'];

require_once DISCUZ_ROOT . './source/plugin/zimu_fudai/class/wechat.lib.class.php';

                $regname = getnewname($xcx_zimu_data['username']);
                $uid     = register($regname, 1, 0, $xcx_zimu_data['gender']);
                if ($uid) {
                syncAvatar($uid,$xcx_zimu_data['avatar']);

                $tablefile = DISCUZ_ROOT.'./source/plugin/zimu_fudai/weixin_table.php';

                if(is_file($tablefile)){
                    include DISCUZ_ROOT.'./source/plugin/zimu_fudai/weixin_table.php';
                }                 
                    
                    if ($zmdata['xcx_isapp'] == 2 && $xcxdata2['unionid']) {

                        $appdata = array(
                            'uid' => $uid,
                            'nickname' => $regname,
                            'dateline' => $_G['timestamp'],
                            'unionid' => $xcx_zimu_data['unionid'],
                            'weibotype' => 'wechat',
                            );

                        DB::insert('thirdbind', $appdata);

                    }
                    
                    if ($zmdata['xcx_isapp'] == 3 && $xcxdata2['unionid']) {

                        $appdata = array(
                            'userid' => $uid,
                            'name' => $regname,
                            'create_time' => $_G['timestamp'],
                            'unionid' => $xcx_zimu_data['unionid'],
                            );

                        DB::insert('user_weixin_relations', $appdata);

                    }

                    if ($zmdata['xcx_isapp'] == 4 && $xcxdata2['unionid']) {

                        $appdata = array(
                        'uid' => $uid,
                        'openid' => '',
                        'status' => '1',
                        'type' => '1',
                        'param' => $xcx_zimu_data['unionid']
                            );

                        DB::insert('appbyme_connection', $appdata);

                    }
return $uid;
}
}
function xcx_token_login($token){

    global $_G;
    $zmdata = $_G['cache']['plugin']['zimu_fudai'];

if(!$token){
    
exit();

}else{

$istoken = DB::fetch_first('select * from %t where token=%s and xcx_appid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $token,
        $zmdata['xcx_appid']
    ));

}

if($istoken['uid'] > 0 ){

bind_login($istoken['uid']);

}else{

return 'error';

}

}

function imagecreates($bg) {

    $bgImg = @imagecreatefromjpeg($bg);

    if (FALSE == $bgImg) {

        $bgImg = @imagecreatefrompng($bg);

    }

    if (FALSE == $bgImg) {

        $bgImg = @imagecreatefromgif($bg);

    }

    return $bgImg;

}

 function mergeImage($target, $imgurl , $data) {

    $img = imagecreates($imgurl);

    $w = imagesx($img);

    $h = imagesy($img);

    imagecopyresized($target, $img, $data['left'], $data['top'], 0, 0, $data['width'], $data['height'], $w, $h);

    imagedestroy($img);

    return $target;

}
 function mergeText($target ,$text , $data,$font) {

    $font = DISCUZ_ROOT . "/source/plugin/zimu_fudai/static/".$font;//字体文件

    $colors = hex2rgb($data['color']);

    $color = imagecolorallocate($target, $colors['red'], $colors['green'], $colors['blue']);

    imagettftext($target, $data['size'], 0, $data['left'], $data['top'] + $data['size'], $color, $font, $text);

    return $target;

}

function hex2rgb($colour) {

    if ($colour[0] == '#') {

        $colour = substr($colour, 1);

    }

    if (strlen($colour) == 6) {

        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);

    } elseif (strlen($colour) == 3) {

        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);

    } else {

        return false;

    }

    $r = hexdec($r);

    $g = hexdec($g);

    $b = hexdec($b);

    return array('red' => $r, 'green' => $g, 'blue' => $b);

}
function zimu_currenturl($related = 0)
{
    $sys_protocal = (isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] == 443 : (isset($_SERVER['SERVER_PORT']) ? 'https://' : 'http://'));
    if($sys_protocal==1){
    $sys_protocal = 'https://';
    }else if($sys_protocal==0){
    $sys_protocal = 'http://';
    }
    global $_G;
    $php_self   = ($_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME']);
    $path_info  = (isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '');
    $relate_url = (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info));
    return ($related ? $relate_url : $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url);
}
function getRandomString($len)
{
$source = "abcdefghijklmnopqrstuvwxyz0123456789";

for ($i = 0, $str = '', $num = strlen($source)-1; $i < $len; $i++) {
$str .= $source[mt_rand(0, $num)];
}
return $str;
}
function zm_wechat_auth()
{
    global $_G;

    if (!IN_WECHAT) {
        return;
    }

$zmdata = $_G['cache']['plugin']['zimu_fudai'];

$wechat_client2 = new WeChatClient($zmdata['weixin_appid'],$zmdata['weixin_appsecret']);

$openid = $_G['cookie']['zimu_fudai_openid'] ? $_G['cookie']['zimu_fudai_openid'] : '';

if($openid){
return $openid;
}

$code = addslashes($_GET['code']);

if ($code && $_GET['codewx']==1){
        $token = $wechat_client2->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }

if(!$token['openid']){
$newtoken = $wechat_client2->getAccessToken(1,0);
}else{
dsetcookie('zimu_fudai_openid',$token['openid'],86400);
return $token['openid'];
}

}else{

$tourl = zimu_currenturl().'&codewx=1';

if($_G['cache']['plugin']['zimu_fudai']['oauth2_url']){

$login_url = $_G['cache']['plugin']['zimu_fudai']['oauth2_url'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_base&state='.md5(FORMHASH).'&redirect_uri=' . urlencode($tourl);

}else{

$login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($tourl) . '&response_type=code&scope=snsapi_base&state=' . md5(FORMHASH) . '#wechat_redirect';

}

dheader('Location:' . $login_url);

}



}