<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if($_G['uid']<=0){exit();}

$fid = intval($_GET['fid']);
$type = intval($_GET['type']);
$fromuid = zimu_authcode($_GET['fromuid']);

if($type==4) {

if($fid) {

$isadd = DB::fetch_first('select * from %t where fid=%d and uid=%d and type=%d order by id desc', array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        $type
    ));


if(!$isadd){
    $zimu_fudai_addlucky_listdata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'touid' => $fromuid,
        'fid' => $fid,
        'type' => $type,
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimu_fudai_addlucky_list', $zimu_fudai_addlucky_listdata);
}

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_fudai_list',
        $fid,
    ));



}


}else{


if($fid && $fromuid && $fromuid != $_G['uid']) {

$alladdnums = DB::result_first('SELECT count(*) FROM %t where fid=%d and uid=%d and addtime>%d order by id desc', array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($alladdnums >= $zmdata['help_nums']){
exit();
}


$isadd = DB::fetch_first('select * from %t where fid=%d and uid=%d and touid=%d and type=%d and addtime>%d order by id desc', array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        $fromuid,
        $type,
        strtotime(date('Y-m-d',$_G['timestamp']))
    ));

if(!$isadd){

if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){
$status = 1;
}else{
$status = 0;
}

    $zimu_fudai_addlucky_listdata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'touid' => $fromuid,
        'fid' => $fid,
        'type' => $type,
        'status' => $status,
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimu_fudai_addlucky_list', $zimu_fudai_addlucky_listdata);
}

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_fudai_list',
        $fid,
    ));
    
}

}