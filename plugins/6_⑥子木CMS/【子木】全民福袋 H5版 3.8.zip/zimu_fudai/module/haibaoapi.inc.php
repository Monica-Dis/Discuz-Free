<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$fid = intval($_GET['fid']);
$uid = intval($_GET['uid']);


$fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_fudai_list',
    $fid
    ));

$haibao_qrcode_setting = explode('|',$fudaidata['haibao_qrcode_setting']);


        $haibao_url = DISCUZ_ROOT . './source/plugin/zimu_fudai/uploadzimucms/haibao/hb_h5_'.$fid.'_'.$uid.'.jpg';

if(!is_file($haibao_url) || $_GET['ceshi']=='zimu'){

        $bg = $fudaidata['haibao_bg'];
        //$bg = str_replace('http://','https://',$fudaidata['haibao_bg']);

        $size = getimagesize($bg);
        $target = imagecreatetruecolor($size[0], $size[1]);
        $bg = imagecreates($bg);
        imagecopy($target, $bg, 0, 0, 0, 0, $size[0], $size[1]);
        imagedestroy($bg);


        $qrcodeimg = DISCUZ_ROOT . './source/plugin/zimu_fudai/uploadzimucms/qrcode/'.$fid.'_'.$uid.'.jpg';

if(!file_exists($qrcodeimg) || !filesize($qrcodeimg) ) {
    require_once DISCUZ_ROOT.'source/plugin/zimu_fudai/class/qrcode.class.php';
    QRcode::png(ZIMUCMS_URL.'&model=view&fid='.$fid.'&type=2&fromuid='.zimu_authcode($uid,'ENCODE'),$qrcodeimg, QR_ECLEVEL_L,5);
}

        mergeImage($target, $qrcodeimg, array('left' => $haibao_qrcode_setting[0], 'top' => $haibao_qrcode_setting[1], 'width' => $haibao_qrcode_setting[2], 'height' => $haibao_qrcode_setting[3]));



$haibao_text_setting = explode("\r\n", trim($fudaidata['haibao_text_setting']));
foreach ($haibao_text_setting as $key => $v) {
    $haibao_text_setting[$key] = explode('|', $v);

     $haibao_text_setting[$key][0] = str_replace('#username#',$_G['username'],$haibao_text_setting[$key][0]);
     $haibao_text_setting[$key][0] = str_replace('#views#',$fudaidata['views'],$haibao_text_setting[$key][0]);
     $haibao_text_setting[$key][0] = zimu_array_utf8($haibao_text_setting[$key][0]);

     mergeText($target,$haibao_text_setting[$key][0], array('size' => $haibao_text_setting[$key][2], 'color' => $haibao_text_setting[$key][1], 'left' => $haibao_text_setting[$key][3], 'top' => $haibao_text_setting[$key][4]), 'yahei.ttf');

}
        imagejpeg($target,$haibao_url);
        imagedestroy($target);

        if($_GET['ceshi']=='zimu'){

            header('content-type:image/jpg;');
            $content=file_get_contents($haibao_url);
            echo $content;
            exit();
        }

dheader('Location: '.$_G['siteurl'].'source/plugin/zimu_fudai/uploadzimucms/haibao/hb_h5_'.$fid.'_'.$uid.'.jpg');

}else{

dheader('Location: '.$_G['siteurl'].'source/plugin/zimu_fudai/uploadzimucms/haibao/hb_h5_'.$fid.'_'.$uid.'.jpg');

}