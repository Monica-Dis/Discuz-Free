<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if(submitcheck('formhash', 1) && $_GET['formhash'] == FORMHASH){

    $res = zm_upload($_FILES['file']);

    if($res && $res['errno']==0){
        echo json_encode($res);
    }
}






function zm_upload($file_data)
{
    global $_G;
    $imgtype = array(
        0 => '.jpg',
        1 => '.jpeg',
        2 => '.png',
        3 => '.gif',
        4 => '.JPG',
        5 => '.JPEG',
        6 => '.PNG',
        7 => '.GIF'
    );
    $errors  = array(
        'UPLOAD_ERR_OK' => 'UPLOAD_ERR_OK',
        'UPLOAD_ERR_INI_SIZE' => 'UPLOAD_ERR_INI_SIZE',
        'UPLOAD_ERR_FORM_SIZE' => 'UPLOAD_ERR_FORM_SIZE',
        'UPLOAD_ERR_PARTIAL' => 'UPLOAD_ERR_PARTIAL',
        'UPLOAD_ERR_NO_FILE' => 'UPLOAD_ERR_NO_FILE',
        'UPLOAD_ERR_NO_TMP_DIR' => 'UPLOAD_ERR_NO_TMP_DIR',
        'UPLOAD_ERR_CANT_WRITE' => 'UPLOAD_ERR_CANT_WRITE',
        99 => 'ONLY_IMAGE_ALLOW'
    );
    $error   = $file_data['error'];
    if ($error != UPLOAD_ERR_OK) {
        return array(
            'errno' => $error,
            'error' => $error
        );
    }
    $type = '.' . addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
    if ($type == '.') {
        switch ($file_data['type']) {
            case 'image/gif':
                $type = '.gif';
                break;
            case 'image/png':
            case 'image/x-png':
                $type = '.png';
                break;
        }
    }
    $t                 = array_search($type, $imgtype);
    $filetype          = $imgtype[$t];
    $file_data['type'] = strtolower($file_data['type']);
    if (!(($t === false || !$filetype))) {
        if (!in_array(strtolower($file_data['type']), array(
            0 => 'image/jpg',
            1 => 'image/jpeg',
            2 => 'image/pjpeg',
            3 => 'image/gif',
            4 => 'image/png',
            5 => 'image/x-png',
            6 => 'application/octet-stream'
        ))) {
            return array(
                'errno' => 99,
                'error' => $errors[99] . $file_data['type'] . '_' . $t . '_' . $filetype
            );
        }
    }
    $dir = 'source/plugin/zimu_fudai/uploadzimucms/';
    dmkdir($dir);
    $filena          = uniqid(time()) . $filetype;
    $file_attach     = $dir . $filena;
    $saved_file      = DISCUZ_ROOT . $file_attach;
    $dst_saved_file  = DISCUZ_ROOT . $file_attach . $type;
    $dst_file_attach = $file_attach . $type;
    if (is_uploaded_file($file_data['tmp_name'])) {



        if (!copy($file_data['tmp_name'], $saved_file)) {
            error_reporting(0);
            if (move_uploaded_file($file_data['tmp_name'], $saved_file)) {
                unlink($file_data['tmp_name']);
                error_reporting(0);
                $imgurl = $_G['siteurl'] . $file_attach;
                return array(
                    'errno' => 0,
                    'error' => $imgurl
                );
            }
        }else{
        	unlink($file_data['tmp_name']);
        	error_reporting(0);
        	$imgurl = $_G['siteurl'] . $file_attach;
        	return array(
        		'errno' => 0,
        		'error' => $imgurl
        	);
        }
    }
    return array(
        'errno' => UPLOAD_ERR_NO_FILE,
        'error' => $errors[UPLOAD_ERR_NO_FILE]
    );
    $type = '.jpg';
}