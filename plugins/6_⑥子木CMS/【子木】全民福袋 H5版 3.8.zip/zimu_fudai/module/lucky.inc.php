<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if($_G['uid']<=0){exit();}

$fid = intval($_GET['fid']);

if($fid && $_GET['md5hash'] == formhash()) {


$fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fudai_list',
        $fid
    ));

if($fudaidata['luckyname8']){
	$luckynums = 8;
}else if($fudaidata['luckyname7']){
	$luckynums = 7;
}else if($fudaidata['luckyname6']){
	$luckynums = 6;
}else if($fudaidata['luckyname5']){
	$luckynums = 5;
}else if($fudaidata['luckyname4']){
	$luckynums = 4;
}else if($fudaidata['luckyname3']){
	$luckynums = 3;
}else if($fudaidata['luckyname2']){
	$luckynums = 2;
}else if($fudaidata['luckyname1']){
	$luckynums = 1;
}else{
	$luckynums = 0;
}


for ($i=1; $i <= $luckynums; $i++){ 
$wheresql = $wheresql . "and luckynums".$i." > 0 ";
//$whereif = $whereif . "&& luckynums".$i." > 0 ";
$alllucky = $alllucky.$i.',';
}


$myuserdata = DB::fetch_first('select * from %t where fid=%d and uid=%d order by id desc', array(
        'zimu_fudai_userdata',
        $fid,
        $_G['uid']
    ));


if(!$myuserdata){

    $myuserdata = array(
        'fid' => $fid,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'realname' => strip_tags(zm_diconv($_GET['realname'])),
        'mobile' => strip_tags($_GET['mobile']),
        'alllucky' => $alllucky,
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimu_fudai_userdata', $myuserdata);

}


    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_fudai_list',
        $fid,
    ));


$used_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and uid=%d and addtime>%d", array(
        'zimu_fudai_luckylist',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

$link_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=1", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($link_lucky >= $fudaidata['link_lucky_nums']){
$link_lucky = $fudaidata['link_lucky_nums'];
}

$link_lucky2 = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=5", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

$link_lucky = $link_lucky + $link_lucky2;

$pic_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=2", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($pic_lucky >= $fudaidata['pic_lucky_nums']){
$pic_lucky = $fudaidata['pic_lucky_nums'];
}


if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){

$app_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=3", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($app_lucky >= $fudaidata['app_lucky_nums']){
$app_lucky = $fudaidata['app_lucky_nums'];
}

}else{

$app_lucky = 0;

}

$weixin_lucky = DB::result_first("SELECT id FROM %t where fid=%d and uid=%d and addtime>%d and type=4", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($weixin_lucky){
$weixin_lucky = $fudaidata['weixin_lucky_nums'];
}


$surplus_luck = $link_lucky + $pic_lucky + $app_lucky + $weixin_lucky + $fudaidata['day_lucky_nums'] - $used_lucky;

if($surplus_luck<=0){

            die(zimu_json_encode(zimu_urlencode(array(
                'status' => 201,
            ))));

}


if(!$myuserdata['alllucky']){
            die(zimu_json_encode(zimu_urlencode(array(
                'status' => 200,
                'surplus_luck' => 1,
                'rand_lucky' => 1,
                'rand_lucky_cn' => '',
                'luckyover' => 1,
            ))));
}

if($fudaidata['get_chance']>0){
$isgetluckyer = zimu_lucky($fudaidata['get_chance']);

if($isgetluckyer!=1){

    $luckylistdata = array(
        'fid' => $fid,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'luckyid' => 0,
        'luckyname' => $language_zimu['view_htm_101'],
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimu_fudai_luckylist', $luckylistdata);


    die(zimu_json_encode(zimu_urlencode(array(
        'status' => 200,
        'surplus_luck' => $surplus_luck,
        'rand_lucky' => 0,
        'rand_lucky_cn' => $language_zimu['view_htm_101'],
        'luckyover' => 0,
    ))));

}
}
//开始处理抽奖事宜

$user_alllucky = explode(',',substr($myuserdata['alllucky'],0,strlen($myuserdata['alllucky'])-1));


//未领取任意一个
if(count($user_alllucky) == $luckynums || count($user_alllucky) > 1 ){

$rand_lucky = mt_rand(1,$luckynums);

        $addata['luckynums'.$rand_lucky]          = $myuserdata['luckynums'.$rand_lucky]+1;
        $addata['alllucky']        = str_replace($rand_lucky.',','',$myuserdata['alllucky']);  
        $result = DB::update('zimu_fudai_userdata', $addata, array(
            'fid' => $fid,
            'uid' => $_G['uid'],
        ));

}else{

$isluckyer = zimu_lucky($fudaidata['chance']);

if($isluckyer==1){


$usednums = DB::result_first("SELECT count(*) FROM %t where fid=%d ".$wheresql, array(
    "zimu_fudai_userdata",
    $fid
));

if($usednums >= $fudaidata['allnums'] - $fudaidata['vipnums'] - $fudaidata['vipnums2']){

$alllucky2 = str_replace($myuserdata['alllucky'],'',$alllucky);
$rand_lucky_array = explode(',',substr($alllucky2,0,strlen($alllucky2)-1));
$rand_lucky = $rand_lucky_array[array_rand($rand_lucky_array,1)];

        $addata['luckynums'.$rand_lucky]          = $myuserdata['luckynums'.$rand_lucky]+1;
        $addata['alllucky']        = str_replace($rand_lucky.',','',$myuserdata['alllucky']);  
        $result = DB::update('zimu_fudai_userdata', $addata, array(
            'fid' => $fid,
            'uid' => $_G['uid'],
        ));

}else{

    $rand_lucky = str_replace(',','',$myuserdata['alllucky']);

    $addata['luckynums'.$rand_lucky]          = $myuserdata['luckynums'.$rand_lucky]+1;
    $addata['alllucky']        = str_replace($rand_lucky.',','',$myuserdata['alllucky']);  
    $addata['luckytime']          = $_G['timestamp'];
    $result = DB::update('zimu_fudai_userdata', $addata, array(
        'fid' => $fid,
        'uid' => $_G['uid'],
        ));
    $luckyover = 1;
    DB::query("update %t set usednums=usednums+1 where id=%d", array(
        'zimu_fudai_list',
        $fid,
        ));
    
}


}else{

$alllucky2 = str_replace($myuserdata['alllucky'],'',$alllucky);
$rand_lucky_array = explode(',',substr($alllucky2,0,strlen($alllucky2)-1));
$rand_lucky = $rand_lucky_array[array_rand($rand_lucky_array,1)];

        $addata['luckynums'.$rand_lucky]          = $myuserdata['luckynums'.$rand_lucky]+1;
        //$addata['alllucky']        = str_replace($rand_lucky.',','',$myuserdata['alllucky']);  
        $result = DB::update('zimu_fudai_userdata', $addata, array(
            'fid' => $fid,
            'uid' => $_G['uid'],
        ));


}


}


    $luckylistdata = array(
        'fid' => $fid,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'luckyid' => $rand_lucky,
        'luckyname' => $fudaidata['luckyname'.$rand_lucky],
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimu_fudai_luckylist', $luckylistdata);


            die(zimu_json_encode(zimu_urlencode(array(
                'status' => 200,
                'surplus_luck' => $surplus_luck,
                'rand_lucky' => $rand_lucky,
                'rand_lucky_cn' => $fudaidata['luckyname'.$rand_lucky],
                'luckyover' => $luckyover,
            ))));




}




function zimu_lucky($chance){

for ($i=0; $i < $chance; $i++) { 

$randnum = mt_rand(1,100);

if(in_array($randnum, $randarray)){
$i--;
}else{
$randarray[] = $randnum;
}

}

$chancenum = mt_rand(1,100);

if(in_array($chancenum, $randarray)){

return 1;

}else{

return 0;

}

}