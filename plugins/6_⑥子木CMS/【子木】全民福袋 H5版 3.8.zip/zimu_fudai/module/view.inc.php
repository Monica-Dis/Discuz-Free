<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if (IN_WECHAT && $zmdata['weixin_appid'] && $zmdata['weixin_appsecret']) {
if($zmdata['mustfollow']){
$openid = zm_wechat_auth();

$wechatinfo    = $wechat_client->getUserInfoById($openid);
    if ($wechatinfo['subscribe']==1) {
        dsetcookie('zimu_fudai_subscribe', 1, 600);
    }elseif(getcookie('zimu_fudai_subscribe')!=1){
        $show_mp_qrcode = 1;
        dsetcookie('zimu_fudai_subscribe', 1, 1);
    }   
}
}


$fromuid = addslashes($_GET['fromuid']);
$fromuid2 = zimu_authcode($fromuid);


$fid = intval($_GET['fid']);

$fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fudai_list',
        $fid
    ));

if($fudaidata['plugin_color']){
    $zmdata['plugin_color'] = $fudaidata['plugin_color'];
}

$randurl = $_COOKIE['randurl_'.$fid];

if(IN_WECHAT && !$randurl && $fudaidata['fd_domains'] && $_GET['share'] != 333 ){
$oldurl = str_replace('//', '/', zimu_currenturl());
$oldurl = parse_url($oldurl);
$randurl = getRandomString(10);
setcookie("randurl_".$fid,$randurl, time() + 10, "/", $fudaidata['fd_domains']);
$newurl = 'http://'.$randurl.'.'.$fudaidata['fd_domains'].'/plugin.php?'.$oldurl['query'].'&share=333';
dheader('Location:' . $newurl);
exit();
}

if ($zmdata['open_app']) {
    $zmdata['guest_help'] = 0;
}

$touser = intval($_GET['touser']);

if(!$zmdata['guest_help'] || $touser == 1 || $_GET['luckkeywords'] || $_GET['luckkeywords2']){

isuid();

}


if($fudaidata['luckyname8']){
    $luckynums = 8;
}else if($fudaidata['luckyname7']){
    $luckynums = 7;
}else if($fudaidata['luckyname6']){
    $luckynums = 6;
}else if($fudaidata['luckyname5']){
    $luckynums = 5;
}else if($fudaidata['luckyname4']){
    $luckynums = 4;
}else if($fudaidata['luckyname3']){
    $luckynums = 3;
}else if($fudaidata['luckyname2']){
    $luckynums = 2;
}else if($fudaidata['luckyname1']){
    $luckynums = 1;
}else{
    $luckynums = 0;
}


for ($i=1; $i <= $luckynums; $i++){ 
$wheresql = $wheresql . "and luckynums".$i." > 0 ";
}

$useddata = DB::fetch_all('select * from %t where (fid=%d '.$wheresql.' ) or (fid=%d and luckytime>0 ) order by id desc limit 20', array(
        'zimu_fudai_userdata',
        $fid,
        $fid
    ));


$usednums = $fudaidata['usednums']+$fudaidata['vipnums2'];

if( ( !$zmdata['guest_help'] || $_G['uid'] > 0 ) && $_GET['type'] != 4 ){

if($zmdata['open_app']){
$open_appsql = ' and status=1 ';
}else{
$open_appsql = ' ';
}

$myuserdata = DB::fetch_first('select * from %t where fid=%d and uid=%d order by id desc', array(
        'zimu_fudai_userdata',
        $fid,
        $_G['uid']
    ));

$used_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and uid=%d and addtime>%d", array(
        'zimu_fudai_luckylist',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

$link_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=1".$open_appsql, array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($link_lucky >= $fudaidata['link_lucky_nums']){
$link_lucky = $fudaidata['link_lucky_nums'];
}

$link_lucky2 = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=5", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

$link_lucky = $link_lucky + $link_lucky2;

$pic_lucky = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=2".$open_appsql, array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($pic_lucky >= $fudaidata['pic_lucky_nums']){
$pic_lucky = $fudaidata['pic_lucky_nums'];
}


$app_lucky2 = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d and addtime>%d and type=3".$open_appsql, array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid'],
        strtotime(date('Y-m-d',$_G['timestamp']))
));

if($app_lucky2 >= $fudaidata['app_lucky_nums']){
$app_lucky2 = $fudaidata['app_lucky_nums'];
}

if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){

$app_lucky = $app_lucky2;

}

$weixin_lucky_array = DB::fetch_first("SELECT * FROM %t where fid=%d and uid=%d and type=4", array(
        'zimu_fudai_addlucky_list',
        $fid,
        $_G['uid']
));

if($weixin_lucky_array['addtime'] > strtotime(date('Y-m-d',$_G['timestamp'])) ){
$weixin_lucky = $fudaidata['weixin_lucky_nums'];
}



$surplus_luck = $link_lucky + $pic_lucky + $app_lucky + $weixin_lucky + $fudaidata['day_lucky_nums'] - $used_lucky;

$fromuid = addslashes($_GET['fromuid']);
$fromuid2 = zimu_authcode($fromuid);
$type = intval($_GET['type']);

if($_G['uid']>0 && $fromuid2 != $_G['uid'] && $fromuid2>0){

if($type==1 && $link_lucky < $fudaidata['link_lucky_nums']){
$isluckyadd = 1;
}elseif($type==2 && $pic_lucky < $fudaidata['pic_lucky_nums']){
$isluckyadd = 1;
}elseif($type==3 && $app_lucky < $fudaidata['app_lucky_nums']){
$isluckyadd = 1;
}

}

$luckkeywords = addslashes($_GET['luckkeywords']);
if($luckkeywords == $fudaidata['weixin_lucky_keywords'] && $fudaidata['weixin_lucky_keywords'] && $luckkeywords){
$isluckyadd = 1;
$type = 4;
}



}else{

$fromuid = addslashes($_GET['fromuid']);
$fromuid2 = zimu_authcode($fromuid);
$type = intval($_GET['type']);

if(getcookie('help_'.$fid.'_'.$fromuid2.'_'.$type) !=1 && $fromuid2 > 0 && $fromuid2 != $_G['uid'] ){

if($type != 4 && getcookie('help_'.$fid.'_guest_nums') < $zmdata['help_nums'] ){

    $zimu_fudai_addlucky_listdata = array(
        'uid' => 0,
        'username' => 'Guest',
        'touid' => $fromuid2,
        'fid' => $fid,
        'type' => $type,
        'addtime' => $_G['timestamp']
    );
    DB::insert('zimu_fudai_addlucky_list', $zimu_fudai_addlucky_listdata);

}

dsetcookie('help_'.$fid.'_'.$fromuid2.'_'.$type,1,86400);
dsetcookie('help_'.$fid.'_guest_nums',getcookie('help_'.$fid.'_guest_nums')+1,86400);

}





}
//免登陆助力结束

$luckkeywords2 = addslashes($_GET['luckkeywords2']);

$weixin_lucky_more = explode("\r\n", trim($fudaidata['weixin_lucky_more']));

if(!$weixin_lucky_more[0]){
  $weixin_lucky_more = array();
}

$gh_more_nums = count($weixin_lucky_more)*$fudaidata['weixin_lucky_nums'];


foreach ($weixin_lucky_more as $key => $v) {
    $vv = explode('|', $v);

if($luckkeywords2 && $luckkeywords2 == $vv[0] && $_G['uid'] && !$_COOKIE['weixin_lucky_more_'.$vv[0]]){

$isluckkeywords = DB::fetch_first('select * from %t where luckkeywords=%s and touid=%d and fid=%d order by id desc', array(
        'zimu_fudai_addlucky_list',
        $luckkeywords2,
        $_G['uid'],
        $fid
    ));

if(!$isluckkeywords){
    
    $weixin_lucky_moredata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'touid' => $_G['uid'],
        'fid' => $fid,
        'type' => 5,
        'addtime' => $_G['timestamp']
    );

for ($x=0; $x < $fudaidata['weixin_lucky_nums']; $x++) {
    DB::insert('zimu_fudai_addlucky_list', $weixin_lucky_moredata);
}

}

$surplus_luck = $surplus_luck + $fudaidata['weixin_lucky_nums'];

$_COOKIE["weixin_lucky_more_".$vv[0]] = 1;

setcookie("weixin_lucky_more_".$vv[0],1, time() + 86400, "/", $fudaidata['fd_domains']);

$gh_more_nums = $gh_more_nums - $fudaidata['weixin_lucky_nums'];

}else if($_COOKIE['weixin_lucky_more_'.$vv[0]] && $_G['uid']){

$gh_more_nums = $gh_more_nums - $fudaidata['weixin_lucky_nums'];

}

    $weixin_lucky_more[$key] = $vv;
}

if($fudaidata['thumb']){
$fudaidata['thumb'] = explode('source/plugin/zimu_fudai', $fudaidata['thumb']);
$fudaidata['thumb'] = $_G['siteurl'].'source/plugin/zimu_fudai'.$fudaidata['thumb'][1];
}

$word_position = explode('|',$fudaidata['word_position']);

$share_title = str_replace('#username#', $_G['username'],$fudaidata['share_title']);
$share_title = str_replace('#giftname#', $fudaidata['giftname'], $share_title);
$share_title = str_replace('#views#', $fudaidata['views'], $share_title);
$share_desc = str_replace('#username#', $_G['username'],$fudaidata['share_desc']);
$share_desc = str_replace('#giftname#', $fudaidata['giftname'], $share_desc);
$share_desc = str_replace('#views#', $fudaidata['views'], $share_desc);
$share_thumb = $fudaidata['share_thumb'];
if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){
if($zmdata['open_app']){

$isapphelp = DB::fetch_first('select * from %t where fid=%d and uid=%d and status=0 and addtime>%d and addtime<%d order by id asc', array(
    'zimu_fudai_addlucky_list',
    $_G['uid'],
    strtotime(date('Y-m-d',$_G['timestamp'])),
    strtotime(date('Y-m-d',$_G['timestamp']))+86400
));

DB::query("update %t set status=1 where fid=%d and uid=%d and status=0 and addtime>%d", array(
    'zimu_fudai_addlucky_list',
    $fid,
    $_G['uid'],
    $_G['timestamp'] - $zmdata['open_app_time']*3600
));

}
$share_url = ZIMUCMS_URL.'&model=view&fid='.$fid.'&type=3&fromuid='.zimu_authcode($_G['uid'],'ENCODE');
}else{
$share_url = ZIMUCMS_URL.'&model=view&fid='.$fid.'&type=1&fromuid='.zimu_authcode($_G['uid'],'ENCODE');
}

$randluckylist = DB::fetch_all('select * from %t where fid=%d and luckyid>0 order by rand() limit 20', array(
        'zimu_fudai_luckylist',
        $fid
    ));

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_fudai_list',
        $fid,
    ));

if($zmdata['qf_hostname']){
$toappurl_android = $zmdata['appurl'].'&android_schema='.urlencode($zmdata['qf_scheme'].'://webview/?url='.zimu_currenturl());
}elseif($zmdata['magapp_host']){
$toappurl_android = $zmdata['magapp_host'].'/magshare/'.$zmdata['magapp_siteid'].'?jump_url='.urlencode(zimu_currenturl());
$toappurl_android2 = $zmdata['magapp_siteid'].'://pagejump?jump_url='.urlencode(zimu_currenturl());
}

include template('zimu_fudai:view');