<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimu_fudai/config.php';

$model = addslashes($_GET['model']);


if(!$_G['cache']['plugin']) {loadcache('plugin');}

if ($model == 'editfudai') {


    if (submitcheck('editfudai')) {


        $addata['id']    = intval($_GET['id']);
        $addata['title']       = strip_tags($_GET['title']);
        if ($_FILES['thumb']['tmp_name']) {
            $addata['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $addata['giftname']       = strip_tags($_GET['giftname']);
        $addata['price']       = strip_tags($_GET['price']);
        $addata['allnums']    = intval($_GET['allnums']);
        $addata['vipnums']    = intval($_GET['vipnums']);
        $addata['vipnums2']    = intval($_GET['vipnums2']);
        $addata['chance']    = intval($_GET['chance']);
        $addata['get_chance']    = intval($_GET['get_chance']);
        $addata['usednums']    = intval($_GET['usednums']);
        $addata['rule'] = dhtmlspecialchars($_GET['rule']);
        $addata['weixin_rule'] = dhtmlspecialchars($_GET['weixin_rule']);
        $addata['introduce'] = dhtmlspecialchars($_GET['introduce']);
        $addata['starttime']     = strtotime($_GET['starttime']);
        $addata['endtime']     = strtotime($_GET['endtime']);
        $addata['exchangetime']     = strtotime($_GET['exchangetime']);
        $addata['luckyname1']       = strip_tags($_GET['luckyname1']);
        $addata['luckyname2']       = strip_tags($_GET['luckyname2']);
        $addata['luckyname3']       = strip_tags($_GET['luckyname3']);
        $addata['luckyname4']       = strip_tags($_GET['luckyname4']);
        $addata['luckyname5']       = strip_tags($_GET['luckyname5']);
        $addata['luckyname6']       = strip_tags($_GET['luckyname6']);
        $addata['luckyname7']       = strip_tags($_GET['luckyname7']);
        $addata['luckyname8']       = strip_tags($_GET['luckyname8']);
        $addata['sort']          = intval($_GET['sort']);
        $addata['adduserinfo']          = intval($_GET['adduserinfo']);
        $addata['day_lucky_nums']          = intval($_GET['day_lucky_nums']);
        $addata['link_lucky_nums']          = intval($_GET['link_lucky_nums']);
        $addata['app_lucky_nums']          = intval($_GET['app_lucky_nums']);
        $addata['pic_lucky_nums']          = intval($_GET['pic_lucky_nums']);
        $addata['weixin_lucky_nums']          = intval($_GET['weixin_lucky_nums']);
        $addata['weixin_lucky_url']          = strip_tags($_GET['weixin_lucky_url']);
        $addata['weixin_lucky_keywords']          = strip_tags($_GET['weixin_lucky_keywords']);
        $addata['weixin_lucky_more']          = addslashes($_GET['weixin_lucky_more']);
        $addata['weixin_avatar']          = strip_tags($_GET['weixin_avatar']);
        $addata['views']          = intval($_GET['views']);   
        $addata['share_title']       = strip_tags($_GET['share_title']);
        $addata['share_desc']       = strip_tags($_GET['share_desc']);
        $addata['haibao_qrcode_setting']       = strip_tags($_GET['haibao_qrcode_setting']);
        $addata['haibao_text_setting']       = addslashes($_GET['haibao_text_setting']);
        $addata['leixing']       = intval($_GET['leixing']);
        $addata['leixing1_tip']       = strip_tags($_GET['leixing1_tip']);
        $addata['leixing3_mima']       = strip_tags($_GET['leixing3_mima']);
        $addata['shopuid']       = strip_tags($_GET['shopuid']);
        $addata['fd_domains']       = strip_tags($_GET['fd_domains']);
        $addata['plugin_color']       = strip_tags($_GET['plugin_color']);
        if ($_FILES['share_thumb']['tmp_name']) {
            $addata['share_thumb'] = zm_saveimages($_FILES['share_thumb']);
        }
        if ($_FILES['haibao_bg']['tmp_name']) {
            $addata['haibao_bg'] = zm_saveimages($_FILES['haibao_bg']);
        }
        if ($_FILES['noword_bg']['tmp_name']) {
            $addata['noword_bg'] = zm_saveimages($_FILES['noword_bg']);
        }
        if ($_FILES['hasword_bg']['tmp_name']) {
            $addata['hasword_bg'] = zm_saveimages($_FILES['hasword_bg']);
        }
        $delhaibao_bg = intval($_GET['delhaibao_bg']);
        if($delhaibao_bg == 1){
        $addata['haibao_bg'] = '';
        }
        $addata['word_position']       = strip_tags($_GET['word_position']);
        $result = DB::update('zimu_fudai_list', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg($language_zimu['Admin_list_inc_php_0'], $url, 'succeed');
        } else {
            cpmsg($language_zimu['Admin_list_inc_php_1'], '', 'error');
        }


    }else{

        $fid = intval($_GET['fid']);

        $fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_fudai_list',
            $fid
            ));

        include template('zimu_fudai:Admin_editfudai'); 
}



}else if($model=="addfudai"){

    if (submitcheck('editfudai')) {

        $addata['title']       = strip_tags($_GET['title']);
        if ($_FILES['thumb']['tmp_name']) {
            $addata['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $addata['giftname']       = strip_tags($_GET['giftname']);
        $addata['price']       = strip_tags($_GET['price']);
        $addata['allnums']    = intval($_GET['allnums']);
        $addata['vipnums']    = intval($_GET['vipnums']);
        $addata['vipnums2']    = intval($_GET['vipnums2']);
        $addata['chance']    = intval($_GET['chance']);
        $addata['get_chance']    = intval($_GET['get_chance']);
        $addata['usednums']    = intval($_GET['usednums']);
        $addata['rule'] = dhtmlspecialchars($_GET['rule']);
        $addata['weixin_rule'] = dhtmlspecialchars($_GET['weixin_rule']);
        $addata['introduce'] = dhtmlspecialchars($_GET['introduce']);
        $addata['starttime']     = strtotime($_GET['starttime']);
        $addata['endtime']     = strtotime($_GET['endtime']);
        $addata['exchangetime']     = strtotime($_GET['exchangetime']);
        $addata['luckyname1']       = strip_tags($_GET['luckyname1']);
        $addata['luckyname2']       = strip_tags($_GET['luckyname2']);
        $addata['luckyname3']       = strip_tags($_GET['luckyname3']);
        $addata['luckyname4']       = strip_tags($_GET['luckyname4']);
        $addata['luckyname5']       = strip_tags($_GET['luckyname5']);
        $addata['luckyname6']       = strip_tags($_GET['luckyname6']);
        $addata['luckyname7']       = strip_tags($_GET['luckyname7']);
        $addata['luckyname8']       = strip_tags($_GET['luckyname8']);
        $addata['sort']          = intval($_GET['sort']);
        $addata['adduserinfo']          = intval($_GET['adduserinfo']);
        $addata['day_lucky_nums']          = intval($_GET['day_lucky_nums']);
        $addata['link_lucky_nums']          = intval($_GET['link_lucky_nums']);
        $addata['app_lucky_nums']          = intval($_GET['app_lucky_nums']);
        $addata['pic_lucky_nums']          = intval($_GET['pic_lucky_nums']);
        $addata['weixin_lucky_nums']          = intval($_GET['weixin_lucky_nums']);
        $addata['weixin_lucky_url']          = strip_tags($_GET['weixin_lucky_url']);
        $addata['weixin_lucky_keywords']          = strip_tags($_GET['weixin_lucky_keywords']);
        $addata['weixin_lucky_more']          = addslashes($_GET['weixin_lucky_more']);
        $addata['weixin_avatar']          = strip_tags($_GET['weixin_avatar']);
        $addata['views']          = intval($_GET['views']);   
        $addata['share_title']       = strip_tags($_GET['share_title']);
        $addata['share_desc']       = strip_tags($_GET['share_desc']);
        $addata['haibao_qrcode_setting']       = strip_tags($_GET['haibao_qrcode_setting']);
        $addata['haibao_text_setting']       = addslashes($_GET['haibao_text_setting']);
        $addata['leixing']       = intval($_GET['leixing']);
        $addata['leixing1_tip']       = strip_tags($_GET['leixing1_tip']);
        $addata['leixing3_mima']       = strip_tags($_GET['leixing3_mima']);
        $addata['shopuid']       = strip_tags($_GET['shopuid']);
        $addata['fd_domains']       = strip_tags($_GET['fd_domains']);
        if ($_FILES['share_thumb']['tmp_name']) {
            $addata['share_thumb'] = zm_saveimages($_FILES['share_thumb']);
        }
        if ($_FILES['haibao_bg']['tmp_name']) {
            $addata['haibao_bg'] = zm_saveimages($_FILES['haibao_bg']);
        }
        if ($_FILES['noword_bg']['tmp_name']) {
            $addata['noword_bg'] = zm_saveimages($_FILES['noword_bg']);
        }
        if ($_FILES['hasword_bg']['tmp_name']) {
            $addata['hasword_bg'] = zm_saveimages($_FILES['hasword_bg']);
        }
        $delhaibao_bg = intval($_GET['delhaibao_bg']);
        if($delhaibao_bg == 1){
        $addata['haibao_bg'] = '';
        }
        $addata['word_position']       = strip_tags($_GET['word_position']);
        $result = DB::insert('zimu_fudai_list', $addata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg($language_zimu['Admin_list_inc_php_2'], $url, 'succeed');
        } else {
            cpmsg($language_zimu['Admin_list_inc_php_3'], '', 'error');
        }


    }else{

        include template('zimu_fudai:Admin_editfudai'); 

    }


}else if($model=="viewfudai"){

    $uid      = intval($_GET['uid']);
    $username = strip_tags($_GET['username']);
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);

    if ($uid > 0) {
        $wherearr[] = DB::field('uid', $uid);
    }
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "username LIKE '%{text}%'");
    }

    $fid = intval($_GET['fid']);

    $wherearr[] = DB::field('fid', $fid);

    $wheresql = empty($wherearr) ? ' 1=1 ' : implode(' AND ', $wherearr);

    $count = DB::result_first("SELECT count(*) FROM %t where %i", array(
        "zimu_fudai_userdata",
        $wheresql
        ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $userdata = DB::fetch_all('select * from %t where %i order by id desc limit %d,%d', array(
        'zimu_fudai_userdata',
        $wheresql,
        $start,
        $limit
        ));


if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewfudai&fid='.$fid, '10000', '10', TRUE, TRUE);
}



    include template('zimu_fudai:Admin_viewfudai'); 


}else if($model=="exchangefudai"){

    $fid = intval($_GET['fid']);

$ac = addslashes($_GET['ac']);

if($ac=='toexcel'){

    $detail = '';

    $userlist = DB::fetch_all('select realname,mobile,username,uid,exchangestatus from %t where fid=%d and alllucky=%d order by id asc', array(
        'zimu_fudai_userdata',
        $fid,
        '',
        ));

    foreach($userlist as $key=>$value) {
        foreach($value as $key2 => $value2) {
            $value2 = preg_replace('/\s+/', ' ', $value2);
            $detail .= strlen($value2) > 11 && is_numeric($value2) ? '['.$value2.'],' : $value2.',';
        }
        $detail = $detail."\n";
    }

    $detail = $language_zimu['view_htm_80'].",".$language_zimu['view_htm_82'].",".$language_zimu['Admin_viewfudai_htm_2'].",UID,".$language_zimu['Admin_exchangefudai_htm_12'].","."\n".$detail;
    $filename = date('Ymd', TIMESTAMP).'.csv';
    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');
    if($_G['charset'] != 'gbk') {
        $detail = diconv($detail, $_G['charset'], 'GBK');
    }
    echo $detail;
    exit();

}



    $fudaidata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_fudai_list',
        $fid
        ));

    $count = DB::result_first("SELECT count(*) FROM %t where fid=%d and alllucky=%d", array(
        "zimu_fudai_userdata",
        $fid,
        ''
        ));

    $limit    = 100;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $userdata = DB::fetch_all('select * from %t where fid=%d and alllucky=%d order by id desc limit %d,%d', array(
        'zimu_fudai_userdata',
        $fid,
        '',
        $start,
        $limit
        ));


if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=exchangefudai&fid='.$fid, '10000', '10', TRUE, TRUE);
}



    include template('zimu_fudai:Admin_exchangefudai'); 

}else if($model=="viewluckylist"){

    $fid = intval($_GET['fid']);

    $uid = intval($_GET['uid']);

    $count = DB::result_first("SELECT count(*) FROM %t where fid=%d and uid=%d", array(
        "zimu_fudai_luckylist",
        $fid,
        $uid
        ));

    $limit    = 10;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $luckydata = DB::fetch_all('select * from %t where fid=%d and uid=%d order by id desc limit %d,%d', array(
        'zimu_fudai_luckylist',
        $fid,
        $uid,
        $start,
        $limit
        ));


if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewluckylist&fid='.$fid.'&uid='.$uid, '10000', '10', TRUE, TRUE);
}



    include template('zimu_fudai:Admin_viewluckylist'); 



}else if($model=="viewaddluckylist"){

    $fid = intval($_GET['fid']);

    $uid = intval($_GET['uid']);

    $count = DB::result_first("SELECT count(*) FROM %t where fid=%d and touid=%d", array(
        "zimu_fudai_addlucky_list",
        $fid,
        $uid
        ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $luckydata = DB::fetch_all('select * from %t where fid=%d and touid=%d order by id desc limit %d,%d', array(
        'zimu_fudai_addlucky_list',
        $fid,
        $uid,
        $start,
        $limit
        ));


if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewaddluckylist&fid='.$fid.'&uid='.$uid, '10000', '10', TRUE, TRUE);
}



    include template('zimu_fudai:Admin_viewaddluckylist');  


} else if ($model == 'exchangestatus' && $_GET['md5formhash'] == formhash()) {
    
    $fid = intval($_GET['fid']);
    $uid = intval($_GET['uid']);
    $status = intval($_GET['status']);

    $leixing1_text = strip_tags($_GET['leixing1_text']);

    $addata['leixing1_text']          = $leixing1_text;
    $addata['exchangestatus']          = $status;
if($status==1){
    $addata['exchangetime']          = $_G['timestamp'];
}else{
    $addata['exchangetime']          = '';
}

    $result = DB::update('zimu_fudai_userdata', $addata, array(
        'fid' => $fid,
        'uid' => $uid,
        ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=exchangefudai&fid='.$fid.'&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_4'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_5'], '', 'error');
    }
    
} else if ($model == 'delfudai' && $_GET['md5formhash'] == formhash()) {
    
    $fid = intval($_GET['fid']);

    $result = DB::delete('zimu_fudai_list', array(
        'id' => $fid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_6'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_7'], '', 'error');
    }

} else if ($model == 'deluserdata' && $_GET['md5formhash'] == formhash()) {
    
    $fid = intval($_GET['fid']);
    $touid = intval($_GET['touid']);

    $result = DB::delete('zimu_fudai_userdata', array(
        'fid' => $fid,
        'uid' => $touid
    ));

    $result = DB::delete('zimu_fudai_luckylist', array(
        'fid' => $fid,
        'uid' => $touid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg($language_zimu['Admin_list_inc_php_6'], $url, 'succeed');
    } else {
        cpmsg($language_zimu['Admin_list_inc_php_7'], '', 'error');
    }


}else if($model=="addlucky" && $_GET['md5hash'] == formhash() ){

    $fid = intval($_GET['fid']);
    $uid = intval($_GET['uid']);
    $nums = intval($_GET['nums']);

if($nums > 0){

    $weixin_lucky_moredata = array(
        'uid' => '0',
        'username' => 'admin_add',
        'touid' => $uid,
        'fid' => $fid,
        'type' => 5,
        'addtime' => $_G['timestamp']
    );

for ($x=0; $x < $nums; $x++) {
    DB::insert('zimu_fudai_addlucky_list', $weixin_lucky_moredata);
}

}


    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewfudai&fid='.$fid;
    cpmsg($language_zimu['Admin_list_inc_php_6'], $url, 'succeed');

}else if($model=="addlucky2" && $_GET['md5hash'] == formhash() ){

    $fid = intval($_GET['fid']);
    $uid = intval($_GET['uid']);

    DB::query("update %t set alllucky=%s,luckytime=%d where fid=%d and uid=%d", array(
        'zimu_fudai_userdata',
        '',
        $_G['timestamp'],
        $fid,
        $uid
    ));

    DB::query("update %t set usednums=usednums+1 where id=%d", array(
        'zimu_fudai_list',
        $fid
    ));

    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewfudai&fid='.$fid;
    cpmsg($language_zimu['Admin_list_inc_php_6'], $url, 'succeed');


}else{


$count = DB::result_first("SELECT count(*) FROM %t", array(
    "zimu_fudai_list"
));

$limit    = 10;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

$fudaidata = DB::fetch_all('select * from %t order by sort asc,id desc limit %d,%d', array(
    'zimu_fudai_list',
    $start,
    $limit
));



if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
}


    include template('zimu_fudai:Admin_list');  
}