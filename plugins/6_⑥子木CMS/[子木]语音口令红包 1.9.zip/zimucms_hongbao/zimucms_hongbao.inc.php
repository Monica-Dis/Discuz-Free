<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/config.php';

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
$signPackage   = $wechat_client->getSignPackage();

$token2 = $wechat_client->getAccessToken(0, 1);

if ($token2['expiration'] - $_G['timestamp'] > 200) {
    $token = $token2['token'];
} else {
    $token = $wechat_client->getAccessToken_new(1, 0);
}


$model = addslashes($_GET['model']);

list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();


$heimingdan = explode("\r\n", trim($zmdata['heimingdan']));

foreach ($heimingdan as $key => $v) {
    if ($openid == $v && $v) {
        echo $zmdata['heimingdan_tip'];
        exit();
    }
    
}

if ($model == 'view') {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $userinfo = oauthurl();
    
    $hid = intval($_GET['hid']);
    
    if ($_GET['code']) {
        dheader('Location:' . ZIMUCMS_URL . '&model=view&hid=' . $hid);
        return false;
    }
    
    $hongbaodata = DB::fetch_first('select * from %t where id=%d and ispay=1', array(
        'zimucms_hongbao_list',
        $hid
    ));
    
    if (!$hongbaodata) {
        dheader('Location:' . ZIMUCMS_URL);
        return false;
    }
    
    $user_hongbaodata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
        'zimucms_hongbao_data',
        $hid,
        $openid
    ));
    
    $nums_hongbaodata = DB::result_first("SELECT count(*) FROM %t where hid=%d and isok=1", array(
        "zimucms_hongbao_data",
        $hid
    ));
    
    if ($nums_hongbaodata >= $hongbaodata['allnums']) {
        $isend        = 1;
        $isend_errmsg = lang('plugin/zimucms_hongbao', 'system_text8');
    }
    if ($zmdata['one_share'] == 2) {
        
        $is_one_share = DB::fetch_first('select * from %t where hid=%d and openid=%s and addtime>%s', array(
            'zimucms_hongbao_share',
            $hid,
            $openid,
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));
        
        $nums_one_share = DB::result_first("SELECT count(*) FROM %t where openid=%s and addtime>%s", array(
            "zimucms_hongbao_share",
            $openid,
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));
        
    }
    
    
    
    DB::query("update %t set view=view+%d where id=%d", array(
        'zimucms_hongbao_list',
        mt_rand(1, 10),
        $hid
    ));
    
    include template('zimucms_hongbao:hongbaoview');
    
    
    
} else if ($model == 'openpacket' && $_GET['formhashvalue'] == formhash()) {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $hid = intval($_GET['hid']);
    
    
    /*
    if ($zmdata['is_guanzhu'] && !$subscribe) {
    $out['status'] = 204;
    $out['errmsg'] = '';
    echo $result = json_encode($out);
    exit();
    }
    */
    
    if ($zmdata['is_city']) {
        $city = IPlookup($_G['clientip']);
        define('IN_CITY', strpos($zmdata['ip_city'], $city) !== false);
        if (!IN_CITY) {
            $out['status'] = 202;
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text10') . $zmdata['ip_city'] . lang('plugin/zimucms_hongbao', 'system_text11') . $city);
            $result        = json_encode($out);
            echo $result = urldecode($result);
            exit();
        }
    }
    
    $everyday_nums = DB::result_first("SELECT count(*) FROM %t where hid=%d and openid=%s and createtime > %d", array(
        "zimucms_hongbao_data",
        $hid,
        $openid,
        strtotime(date('Y-m-d', $_G['timestamp']))
        
    ));
    
    $share_nums = DB::result_first("SELECT count(*) FROM %t where openid=%s and addtime > %d", array(
        "zimucms_hongbao_share",
        $openid,
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));
    
    if ($share_nums) {
        $add_share_nums = $zmdata['add_nums'];
    }
    
    if ($everyday_nums > $zmdata['everyday_nums'] && !$share_nums) {
        $out['status'] = 202;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text25') . $zmdata['everyday_nums'] . lang('plugin/zimucms_hongbao', 'system_text26') . lang('plugin/zimucms_hongbao', 'system_text23') . lang('plugin/zimucms_hongbao', 'system_text27') . $zmdata['add_nums'] . lang('plugin/zimucms_hongbao', 'system_text26'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    if ($everyday_nums > $zmdata['everyday_nums'] + $add_share_nums) {
        $out['status'] = 202;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text25') . ($zmdata['everyday_nums'] + $add_share_nums) . lang('plugin/zimucms_hongbao', 'system_text26'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    
    //������secret_key
    if (!empty($_GET['key'])) {
        $postkey = addslashes(zm_diconv($_GET['key']));
        
        $hongbaodata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_hongbao_list',
            $hid
        ));
        
        $user_hongbaodata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
            'zimucms_hongbao_data',
            $hid,
            $openid
        ));
        
        $nums_hongbaodata = DB::result_first("SELECT count(*) FROM %t where hid=%d and isok=1", array(
            "zimucms_hongbao_data",
            $hid
        ));
        
        if ($nums_hongbaodata >= $hongbaodata['allnums']) {
            $out['status'] = 202;
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text8'));
            $result        = json_encode($out);
            echo $result = urldecode($result);
            exit();
        }
        
        if ($user_hongbaodata) {
            $out['status'] = 203;
            $out['errmsg'] = '';
            echo $result = json_encode($out);
            exit();
        }
        $postkey                   = str_replace(array(
            ',',
            '.',
            '��',
            '��',
            '!',
            '��'
        ), array(
            '',
            '',
            '',
            '',
            '',
            ''
        ), $postkey);
        $hongbaodata['secret_key'] = str_replace(array(
            ',',
            '.',
            '��',
            '��',
            '!',
            '��'
        ), array(
            '',
            '',
            '',
            '',
            '',
            ''
        ), $hongbaodata['secret_key']);
        
        similar_text($postkey, $hongbaodata['secret_key'], $percent);
        
        if ($percent > 50 && $percent < $hongbaodata['percent']) {
            $url      = "http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=" . $token . "&media_id=" . strip_tags($_GET['localId']);
            $fileInfo = downloadWeixinFile($url);
            $picname  = '/uploadzimucms/voice/' . $hid . '/' . time() . rand(100, 999) . '.mp3';
            if (!file_exists(dirname(__FILE__) . '/uploadzimucms/voice/' . $hid)) //�ļ��в����ڣ��������ļ���
                {
                mkdir(dirname(__FILE__) . '/uploadzimucms/voice/' . $hid);
            }
            $filename = dirname(__FILE__) . $picname;
            $voiceurl = ZIMUCMS_PATH . saveWeixinFile($filename, $fileInfo["body"], $picname);
        }
        
        if ($percent < $hongbaodata['percent']) {
            $adddata = array(
                'hid' => $hid,
                'nickname' => $nickname,
                'openid' => $openid,
                'unionid' => $unionid,
                'headimgurl' => $headimgurl,
                'sex' => $sex,
                'subscribe' => $subscribe,
                'get_money' => '',
                'mch_billno' => '',
                'send_listid' => '',
                'result_code' => '',
                'createtime' => $_G['timestamp'],
                'leixing' => 1,
                'voiceurl' => $voiceurl,
                'percent' => $percent,
                'isok' => 0
            );
            DB::insert('zimucms_hongbao_data', $adddata);
        }
        $matching = $hongbaodata['percent'];
        if ($percent < $matching || empty($_GET['localId'])) {
            //δ�ﵽ��׼�����ش���
            $out['status'] = 202;
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text3') . round($percent, 2) . "%" . lang('plugin/zimucms_hongbao', 'system_text23') . $postkey . lang('plugin/zimucms_hongbao', 'system_text24') . round($hongbaodata['percent'] - round($percent, 2), 2) . '%');
            $result        = json_encode($out);
            echo $result = urldecode($result);
            exit();
            //print_r($out);
        }
        
        $user_hongbaodata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
            'zimucms_hongbao_data',
            $hid,
            $openid
        ));
        
        if ($user_hongbaodata) {
            $out['status'] = 203;
            $out['errmsg'] = '';
            echo $result = json_encode($out);
            exit();
        }
        
        //�ﵽƥ��ȿ�ʼ�����
        if ($percent >= $matching && !discuz_process::islocked('hongbao_'.$hid.'_'.$openid, 30) ) {
            
            if ($hongbaodata['leixing'] == 1) {
                $get_money = intval($hongbaodata['allmoney'] / $hongbaodata['allnums']);
            } else {
                
                $lingqu_hongbaodata = DB::result_first("SELECT SUM(get_money) FROM %t where hid=%d and isok=1", array(
                    "zimucms_hongbao_data",
                    $hid
                ));
                $money_total        = $hongbaodata['allmoney'] - $lingqu_hongbaodata;
                $money_num          = $hongbaodata['allnums'] - $nums_hongbaodata;
                $get_money2         = sendHB($money_total / 100, $money_num);
                $get_money          = $get_money2['0'] * 100;
                
                //print_r($get_money2);exit(); 
                
                
            }
            
            
            $localId2 = strip_tags($_GET['localId']);
            $url      = "http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=" . $token . "&media_id=" . $localId2;
            $fileInfo = downloadWeixinFile($url);
            $picname  = '/uploadzimucms/voice/' . $hid . '/' . time() . rand(100, 999) . '.mp3';
            if (!file_exists(dirname(__FILE__) . '/uploadzimucms/voice/' . $hid)) //�ļ��в����ڣ��������ļ���
                {
                mkdir(dirname(__FILE__) . '/uploadzimucms/voice/' . $hid);
            }
            $filename = dirname(__FILE__) . $picname;
            $voiceurl = ZIMUCMS_PATH . saveWeixinFile($filename, $fileInfo["body"], $picname);
            

            if ($get_money >= $zmdata['min_hongbao']) {
                
                $user_hongbaodata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
                    'zimucms_hongbao_data',
                    $hid,
                    $openid
                ));
                
                if ($user_hongbaodata) {
                    $out['status'] = 203;
                    $out['errmsg'] = '';
                    echo $result = json_encode($out);
                    exit();
                }
                
                require_once DISCUZ_ROOT . '/source/plugin/zimucms_hongbao/class/wxpay.class.php';
                $input               = new WxPayData();
                $input->mch_billno   = MCHID . date('Ymd') . time();
                $input->send_name    = strip_tags(diconv($zmdata['send_name'], CHARSET, 'UTF8'));
                $input->wishing      = strip_tags(diconv($zmdata['wishing'], CHARSET, 'UTF8'));
                $input->act_name     = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF8'));
                $input->remark       = 'remark';
                $input->re_openid    = $openid;
                $input->total_amount = $get_money;
                $input->total_num    = 1;
                $input->fromtype     = '1';
                $input->fromid       = '1';
                $result              = WxPayApi::sendredpack($input);
                
                $usermoney = DB::fetch_first('select * from %t where openid=%s', array(
                    'zimucms_hongbao_userdata',
                    $openid
                ));
                
                if ($result["result_code"] == "SUCCESS") {
                    
                    $adddata = array(
                        'hid' => $hid,
                        'nickname' => $nickname,
                        'openid' => $openid,
                        'unionid' => $unionid,
                        'headimgurl' => $headimgurl,
                        'sex' => $sex,
                        'subscribe' => $subscribe,
                        'get_money' => $get_money,
                        'mch_billno' => $result['mch_billno'],
                        'send_listid' => $result['send_listid'],
                        'result_code' => diconv($result['return_msg'], 'UTF8', CHARSET),
                        'createtime' => $_G['timestamp'],
                        'leixing' => 1,
                        'voiceurl' => $voiceurl,
                        'percent' => $percent,
                        'isok' => 1
                    );
                    DB::insert('zimucms_hongbao_data', $adddata);
                    
                    if (!$usermoney) {
                        $userdata = array(
                            'nickname' => $nickname,
                            'openid' => $openid,
                            'unionid' => $unionid,
                            'headimgurl' => $headimgurl,
                            'sex' => $sex,
                            'subscribe' => $subscribe,
                            'all_money' => $get_money,
                            'shengyu_money' => '0',
                            'static' => '1',
                            'uptimes' => $_G['timestamp']
                        );
                        DB::insert('zimucms_hongbao_userdata', $userdata);
                    } else {
                        
                        $userdata['all_money'] = $usermoney['all_money'] + $get_money;
                        $result                = DB::update('zimucms_hongbao_userdata', $userdata, array(
                            'openid' => $openid
                        ));
                        
                    }
                    
                    $out['status'] = 200;
                    $out['errmsg'] = '';
                    echo $result = json_encode($out);
                    exit();
                } else {
                    
                    $adddata = array(
                        'hid' => $hid,
                        'nickname' => $nickname,
                        'openid' => $openid,
                        'unionid' => $unionid,
                        'headimgurl' => $headimgurl,
                        'sex' => $sex,
                        'subscribe' => $subscribe,
                        'get_money' => $get_money,
                        'mch_billno' => '',
                        'send_listid' => '',
                        'result_code' => diconv($result['return_msg'], 'UTF8', CHARSET),
                        'createtime' => $_G['timestamp'],
                        'leixing' => 1,
                        'voiceurl' => $voiceurl,
                        'percent' => $percent,
                        'isok' => 1
                    );
                    DB::insert('zimucms_hongbao_data', $adddata);
                    
                    if (!$usermoney) {
                        $userdata = array(
                            'nickname' => $nickname,
                            'openid' => $openid,
                            'unionid' => $unionid,
                            'headimgurl' => $headimgurl,
                            'sex' => $sex,
                            'subscribe' => $subscribe,
                            'all_money' => $get_money,
                            'shengyu_money' => $get_money,
                            'static' => '1',
                            'uptimes' => $_G['timestamp']
                        );
                        DB::insert('zimucms_hongbao_userdata', $userdata);
                    } else {
                        
                        $userdata['all_money']     = $usermoney['all_money'] + $get_money;
                        $userdata['shengyu_money'] = $usermoney['shengyu_money'] + $get_money;
                        $result                    = DB::update('zimucms_hongbao_userdata', $userdata, array(
                            'openid' => $openid
                        ));
                        
                    }
                    
                    $out['status'] = 200;
                    $out['errmsg'] = '';
                    echo $result = json_encode($out);
                    exit();
                }
            } else {
                
                $user_hongbaodata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
                    'zimucms_hongbao_data',
                    $hid,
                    $openid
                ));
                
                if ($user_hongbaodata) {
                    $out['status'] = 203;
                    $out['errmsg'] = '';
                    echo $result = json_encode($out);
                    exit();
                }
                
                $adddata = array(
                    'hid' => $hid,
                    'nickname' => $nickname,
                    'openid' => $openid,
                    'unionid' => $unionid,
                    'headimgurl' => $headimgurl,
                    'sex' => $sex,
                    'subscribe' => $subscribe,
                    'get_money' => $get_money,
                    'mch_billno' => '',
                    'send_listid' => '',
                    'result_code' => '',
                    'createtime' => $_G['timestamp'],
                    'leixing' => 1,
                    'voiceurl' => $voiceurl,
                    'percent' => $percent,
                    'isok' => 1
                );
                DB::insert('zimucms_hongbao_data', $adddata);
                
                $usermoney = DB::fetch_first('select * from %t where openid=%s', array(
                    'zimucms_hongbao_userdata',
                    $openid
                ));
                
                
                if (!$usermoney) {
                    $userdata = array(
                        'nickname' => $nickname,
                        'openid' => $openid,
                        'unionid' => $unionid,
                        'headimgurl' => $headimgurl,
                        'sex' => $sex,
                        'subscribe' => $subscribe,
                        'all_money' => $get_money,
                        'shengyu_money' => $get_money,
                        'static' => '1',
                        'uptimes' => $_G['timestamp']
                    );
                    DB::insert('zimucms_hongbao_userdata', $userdata);
                } else {
                    
                    $userdata['all_money']     = $usermoney['all_money'] + $get_money;
                    $userdata['shengyu_money'] = $usermoney['shengyu_money'] + $get_money;
                    $result                    = DB::update('zimucms_hongbao_userdata', $userdata, array(
                        'openid' => $openid
                    ));
                    
                }
                
                $out['status'] = 200;
                $out['errmsg'] = '';
                echo $result = json_encode($out);
                exit();
            }
            
            
            
            
            
        }


    } else {
        $out['status'] = 202;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text9'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
} else if ($model == 'showredpack') {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $hid = intval($_GET['hid']);
    
    $hongbaoinfo = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_hongbao_list',
        $hid
    ));
    
    $myuserdata = DB::fetch_first('select * from %t where hid=%d and openid=%s and leixing=1 and isok=1', array(
        'zimucms_hongbao_data',
        $hid,
        $openid
    ));
    
    $alluserdata = DB::fetch_all('select * from %t where hid=%d and isok=1 and leixing=1 order by createtime desc', array(
        'zimucms_hongbao_data',
        $hid
    ));
    
    if ($zmdata['one_share'] == 3) {
        $is_one_share   = DB::fetch_first('select * from %t where hid=%d and openid=%s and addtime>%s', array(
            'zimucms_hongbao_share',
            $hid,
            $openid,
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));
        $nums_one_share = DB::result_first("SELECT count(*) FROM %t where openid=%s and addtime>%s", array(
            "zimucms_hongbao_share",
            $openid,
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));
    }
    
    include template('zimucms_hongbao:showredpack');
    
} else if ($model == 'myhongbao') {
    $userinfo = oauthurl();
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $myuserdata = DB::fetch_first('select * from %t where openid=%s', array(
        'zimucms_hongbao_userdata',
        $openid
    ));
    
    $myhongbaonums = DB::result_first("SELECT count(*) FROM %t where openid=%s and leixing=1 and isok=1", array(
        "zimucms_hongbao_data",
        $openid
    ));
    
    
    $aaa = DB::query('select a.*,b.nickname as adtitle,b.logo from %t a left join %t b on a.hid=b.id where a.openid=%s and a.leixing=1 order by a.id desc', array(
        'zimucms_hongbao_data',
        'zimucms_hongbao_list',
        $openid
    ));
    
    while ($res = DB::fetch($aaa)) {
        $myhongbaodata[] = $res;
    }
    
    include template('zimucms_hongbao:myhongbao');
    
} else if ($model == 'getred' && $_GET['formhashvalue'] == formhash()) {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $istodaytixian = DB::result_first('SELECT count(*) FROM %t where openid=%s and leixing=2 and createtime>%d and createtime<%d', array(
        'zimucms_hongbao_data',
        $openid,
        strtotime(date('Y-m-d', $_G['timestamp'])),
        strtotime(date('Y-m-d', $_G['timestamp'])) + 86400
    ));
    
    if ($istodaytixian >= $zmdata['tixian_nums']) {
        $result = array(
            'status' => 404,
            'errmsg' => urlencode(lang('plugin/zimucms_hongbao', 'system_text30'))
        );
        echo urldecode(json_encode($result));
        exit();
    }
    
    $myuserdata = DB::fetch_first('select * from %t where openid=%s', array(
        'zimucms_hongbao_userdata',
        $openid
    ));
    
    if ($myuserdata['shengyu_money'] < 100) { //С��1�鲻������
        $result = array(
            'status' => 404,
            'errmsg' => urlencode(lang('plugin/zimucms_hongbao', 'system_text12') . '1' . lang('plugin/zimucms_hongbao', 'system_text13'))
        );
        echo urldecode(json_encode($result));
        exit();
    } else if ($myuserdata['shengyu_money'] / 100 < $zmdata['min_tixian']) { //С��N�鲻������
        $result = array(
            'status' => 404,
            'errmsg' => urlencode(lang('plugin/zimucms_hongbao', 'system_text12') . $zmdata['min_tixian'] . lang('plugin/zimucms_hongbao', 'system_text13'))
        );
        echo urldecode(json_encode($result));
        exit();
    } else {
        
        $get_money = intval($myuserdata['shengyu_money'] / 100);
        
        $userdata['shengyu_money'] = $myuserdata['shengyu_money'] - $get_money * 100;
        $result                    = DB::update('zimucms_hongbao_userdata', $userdata, array(
            'openid' => $openid
        ));
        
        
        require_once DISCUZ_ROOT . '/source/plugin/zimucms_hongbao/class/wxpay.class.php';
        $input               = new WxPayData();
        $input->mch_billno   = MCHID . date('Ymd') . time();
        $input->send_name    = strip_tags(diconv($zmdata['send_name'], CHARSET, 'UTF8'));
        $input->wishing      = strip_tags(diconv($zmdata['wishing'], CHARSET, 'UTF8'));
        $input->act_name     = strip_tags(diconv($zmdata['act_name'], CHARSET, 'UTF8'));
        $input->remark       = 'remark';
        $input->re_openid    = $openid;
        $input->total_amount = $get_money * 100;
        $input->total_num    = 1;
        $input->fromtype     = '1';
        $input->fromid       = '1';
        
        
        $isred = DB::fetch_first('select * from %t where mch_billno=%s and openid=%s', array(
            'zimucms_hongbao_data',
            $input->mch_billno,
            $openid
        ));
        
        if (!$isred && !discuz_process::islocked('hongbao_tx_'.$openid.'_'.$input->mch_billno, 30) ) {
            
            $result = WxPayApi::sendredpack($input);
            
            if ($result["result_code"] == "SUCCESS") {
                
                $adddata = array(
                    'hid' => 0,
                    'nickname' => $nickname,
                    'openid' => $openid,
                    'unionid' => $unionid,
                    'headimgurl' => $headimgurl,
                    'sex' => $sex,
                    'subscribe' => $subscribe,
                    'get_money' => $get_money * 100,
                    'mch_billno' => $result['mch_billno'],
                    'send_listid' => $result['send_listid'],
                    'result_code' => diconv($result['return_msg'], 'UTF8', CHARSET),
                    'createtime' => $_G['timestamp'],
                    'leixing' => 2,
                    'isok' => 1
                );
                DB::insert('zimucms_hongbao_data', $adddata);
                
                $out['status'] = 200;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text14'));
                echo urldecode(json_encode($out));
                exit();
            } else {
                
                $adddata = array(
                    'hid' => 0,
                    'nickname' => $nickname,
                    'openid' => $openid,
                    'unionid' => $unionid,
                    'headimgurl' => $headimgurl,
                    'sex' => $sex,
                    'subscribe' => $subscribe,
                    'get_money' => $get_money * 100,
                    'mch_billno' => $result['mch_billno'],
                    'send_listid' => $result['send_listid'],
                    'result_code' => diconv($result['return_msg'], 'UTF8', CHARSET),
                    'createtime' => $_G['timestamp'],
                    'leixing' => 2,
                    'isok' => 1
                );
                DB::insert('zimucms_hongbao_data', $adddata);
                
                $out['status'] = 502;
                $out['errmsg'] = urlencode(diconv($result['return_msg'], 'UTF8', CHARSET));
                echo urldecode(json_encode($out));
                exit();
                
            }
        } else {
            
            $out['status'] = 200;
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text14'));
            echo urldecode(json_encode($out));
            exit();
            
        }
        
        
        
    }
    
    
    
} else if ($model == 'myhongbaolist') {
    
    $userinfo = oauthurl();
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $myuserdata = DB::fetch_first('select * from %t where openid=%s', array(
        'zimucms_hongbao_userdata',
        $openid
    ));
    
    $alltixiannums = DB::result_first("SELECT SUM(get_money) FROM %t where openid=%s and get_money>=%d and isok=1", array(
        "zimucms_hongbao_data",
        $openid,
        $zmdata['min_hongbao']
    ));
    
    $mytixiandata = DB::fetch_all('select * from %t where openid=%s and get_money>=%d and isok=1 order by createtime desc', array(
        'zimucms_hongbao_data',
        $openid,
        $zmdata['min_hongbao']
    ));
    include template('zimucms_hongbao:myhongbaolist');
    
} else if ($model == 'yifahongbao') {
    
    $userinfo = oauthurl();
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $allfa_money = DB::result_first("SELECT SUM(allmoney) FROM %t where openid=%s and ispay=1", array(
        "zimucms_hongbao_list",
        $openid
    ));
    $myfadata    = DB::fetch_all('select * from %t where openid=%s and ispay=1 order by id desc', array(
        'zimucms_hongbao_list',
        $openid
    ));
    
    foreach ($myfadata as $key => $value) {
        $myfadata[$key]['yilingqu'] = DB::result_first("SELECT count(*) FROM %t where hid=%d and isok=1", array(
            "zimucms_hongbao_data",
            $value['id']
        ));
    }
    
    include template('zimucms_hongbao:yifahongbao');
} else if ($model == 'fahongbao') {
    
    $userinfo = oauthurl();
    if ($zmdata['shouxufei_type']) {
        $zmdata['shouxufei'] = 0;
    }
    include template('zimucms_hongbao:fahongbao');
    
} else if ($model == 'sendpacket' && $_GET['md5formhash'] == formhash()) {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $fahongbao_min  = $zmdata['fahongbao_min'];
    $retype         = intval($_GET['type']); //������ͣ�0���������1��ͨ���
    $FEE            = $zmdata['shouxufei'];
    $packet_numbers = intval($_GET['packet_numbers']);
    $packetprice    = round($_GET['packetprice'], 2);
    if ($packet_numbers == 1) { //�������Ϊ1ʱ����Ϊ��ͨ���
        $retype = 1;
    }
    
    if ($retype === 0) {
        $onetotal = $packetprice / $packet_numbers;
        if ($onetotal < $fahongbao_min || $onetotal > 200) {
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text16') . $fahongbao_min . lang('plugin/zimucms_hongbao', 'system_text17'));
            echo urldecode(json_encode($out));
            exit();
            //$out['errmsg'] = urlencode();
        }
        $amount = $packetprice;
        if ($zmdata['shouxufei_type']) {
            $allpacketprice = $packetprice * 1;
        } else {
            $allpacketprice = $packetprice * (1 + $FEE / 100);
        }
        $redtype = 2; //������
    } elseif ($retype === 1) {
        if ($packetprice < $fahongbao_min || $packetprice > 200) {
            $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text16') . $fahongbao_min . lang('plugin/zimucms_hongbao', 'system_text17'));
            echo urldecode(json_encode($out));
            exit();
        }
        $amount = $packet_numbers * $packetprice;
        if ($zmdata['shouxufei_type']) {
            $allpacketprice = $packet_numbers * $packetprice * 1;
        } else {
            $allpacketprice = $packet_numbers * $packetprice * (1 + $FEE / 100);
        }
        $redtype = 3; //��ͨ���
    }
    
    $weixin_allpacketprice = round($allpacketprice, 2) * 100;
    
    include DISCUZ_ROOT . 'source/plugin/zimucms_hongbao/class/wxpay.class.php';
    $input               = new WxPayData();
    $input->body         = diconv(cutstr($nickname . lang('plugin/zimucms_hongbao', 'system_text18'), 32, ''), CHARSET, 'utf-8');
    $input->out_trade_no = date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
    $input->total_fee    = $weixin_allpacketprice;
    $input->time_start   = date('YmdHis');
    $input->time_expire  = date('YmdHis', $_G['timestamp'] + 600);
    $input->notify_url   = ZIMUCMS_URL;
    
    $input->product_id = diconv($nickname . lang('plugin/zimucms_hongbao', 'system_text18'), CHARSET, 'utf-8');
    $input->fromtype   = 'ZIMUCMS_HONGBAO';
    $input->fromid     = $unionid;
    $input->openid     = $openid;
    $input->trade_type = 'JSAPI';
    try {
        $jsPay  = new JsApiPay();
        $result = WxPayApi::unifiedOrder($input);
    }
    catch (WxPayException $e) {
        showmessage(zm_diconv($e->errorMessage()));
    }
    
    if ($result['return_code'] == 'FAIL') {
        showmessage(zm_diconv($result['return_msg']));
    }
    
    if ($result['result_code'] == 'FAIL') {
        showmessage(zm_diconv($result['err_code_des']));
    }
    try {
        $wxpay = $jsPay->getJsApiParameters($result);
    }
    catch (WxPayException $e) {
        showmessage(zm_diconv($e->errorMessage()));
    }
    
    
    $wxpay                 = json_decode($wxpay);
    $wxpay                 = object_array($wxpay);
    $wxpay['out_trade_no'] = $input->out_trade_no;
    
    $addata['openid']   = $openid;
    $addata['unionid']  = $unionid;
    $addata['nickname'] = strip_tags(zm_diconv($nickname));
    $addata['sex']      = $sex;
    $addata['logo']     = $headimgurl;
    $addata['thumb']    = ZIMUCMS_PATH . '/static/images/redpackbg1.jpg';
    $addata['desc']     = lang('plugin/zimucms_hongbao', 'system_text19');
    $addata['leixing']  = $retype;
    if ($zmdata['shouxufei_type']) {
        $addata['allmoney'] = round(($amount * (1 - $FEE / 100)), 2) * 100;
    } else {
        $addata['allmoney'] = round($amount, 2) * 100;
    }
    $addata['allnums']      = $packet_numbers;
    $addata['ispay']        = 0;
    $addata['secret_key']   = lang('plugin/zimucms_hongbao', 'system_text20');
    $addata['starttime']    = $_G['timestamp'];
    $addata['view']         = 0;
    $addata['onlyshare']    = 3;
    $addata['out_trade_no'] = $input->out_trade_no;
    $result                 = DB::insert('zimucms_hongbao_list', $addata);
    
    if ($result) {
        $wxpay['status'] = 200;
        echo json_encode($wxpay);
        exit();
    } else {
        
        $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text21'));
        echo urldecode(json_encode($out));
        exit();
    }
    
    
    
} else if ($model == 'paysuccess') {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    include DISCUZ_ROOT . 'source/plugin/zimucms_hongbao/class/wxpay.class.php';
    
    $input               = new WxPayData();
    $input->out_trade_no = strip_tags($_GET['out_trade_no']);
    
    try {
        $jsPay  = new JsApiPay();
        $result = WxPayApi::orderQuery($input);
    }
    catch (WxPayException $e) {
        showmessage(zm_diconv($e->errorMessage()));
    }
    
    $hongbaodata = DB::fetch_first('select * from %t where out_trade_no=%s and openid=%s', array(
        'zimucms_hongbao_list',
        $input->out_trade_no,
        $openid
    ));
    
    if ($result['trade_state'] == 'SUCCESS' && $hongbaodata['ispay'] == 0 && $_GET['md5hash'] == $formhash) {
        
        $addata['ispay'] = '1';
        $result          = DB::update('zimucms_hongbao_list', $addata, array(
            'out_trade_no' => $input->out_trade_no
        ));
    }
    
    include template('zimucms_hongbao:paysuccess');
    
    
} else if ($model == 'savehongbao' && $_GET['md5formhash'] == formhash()) {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $addata['nickname']   = strip_tags(zm_diconv($_GET['ad_name']));
    $addata['desc']       = strip_tags(zm_diconv($_GET['activity_blessing']));
    $addata['secret_key'] = strip_tags(zm_diconv($_GET['secret_key']));
    if (intval($_GET['onlyshare']) == 3) {
        $addata['onlyshare'] = 0;
    } else {
        $addata['onlyshare'] = intval($_GET['onlyshare']);
    }
    $addata['percent'] = intval($_GET['percent']);
    $addata['adtext']  = strip_tags(zm_diconv($_GET['adtext']));
    
    if ($_GET['serverId1']) {
        $url      = "http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=" . $token . "&media_id=" . strip_tags($_GET['serverId1']);
        $fileInfo = downloadWeixinFile($url);
        $picname  = '/uploadzimucms/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
        if (!file_exists(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"))) //�ļ��в����ڣ��������ļ���
            {
            mkdir(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"));
        }
        $filename       = dirname(__FILE__) . $picname;
        $addata['logo'] = ZIMUCMS_PATH . saveWeixinFile($filename, $fileInfo["body"], $picname);
    }
    if ($_GET['serverId2']) {
        $url      = "http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=" . $token . "&media_id=" . strip_tags($_GET['serverId2']);
        $fileInfo = downloadWeixinFile($url);
        $picname  = '/uploadzimucms/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
        if (!file_exists(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"))) //�ļ��в����ڣ��������ļ���
            {
            mkdir(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"));
        }
        $filename        = dirname(__FILE__) . $picname;
        $addata['thumb'] = ZIMUCMS_PATH . saveWeixinFile($filename, $fileInfo["body"], $picname);
    }
    if ($_GET['serverId3']) {
        $url      = "http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=" . $token . "&media_id=" . strip_tags($_GET['serverId3']);
        $fileInfo = downloadWeixinFile($url);
        $picname  = '/uploadzimucms/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
        if (!file_exists(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"))) //�ļ��в����ڣ��������ļ���
            {
            mkdir(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"));
        }
        $filename       = dirname(__FILE__) . $picname;
        $addata['adma'] = ZIMUCMS_PATH . saveWeixinFile($filename, $fileInfo["body"], $picname);
    }
    
    if ($openid) {
        $olddata = DB::fetch_first('select * from %t where openid=%s and out_trade_no=%s', array(
            'zimucms_hongbao_list',
            $openid,
            strip_tags(zm_diconv($_GET['out_trade_no']))
        ));
        $result  = DB::update('zimucms_hongbao_list', $addata, array(
            'out_trade_no' => strip_tags(zm_diconv($_GET['out_trade_no'])),
            'openid' => $openid
        ));
        
    } else {
        $olddata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
            'zimucms_hongbao_list',
            strip_tags(zm_diconv($_GET['out_trade_no']))
        ));
        $result  = DB::update('zimucms_hongbao_list', $addata, array(
            'out_trade_no' => strip_tags(zm_diconv($_GET['out_trade_no']))
        ));
    }
    if ($result) {
        
        $out['status'] = 200;
        $out['hid']    = 200;
        echo json_encode($out);
        
        if ($olddata['onlyshare'] == 3 && $zmdata['is_tuisongmb'] && $zmdata['tuisong_mbid']) {
            
            $alluser = DB::fetch_all('select openid from %t', array(
                'zimucms_hongbao_userdata'
            ));
            foreach ($alluser as $key => $value) {
                $template  = array(
                    'touser' => $value['openid'],
                    'template_id' => $zmdata['tuisong_mbid'],
                    'url' => ZIMUCMS_URL,
                    'data' => array(
                        'keyword1' => array(
                            'value' => urlencode(diconv(lang('plugin/zimucms_hongbao', 'system_text28'), CHARSET, 'utf-8'))
                        ),
                        'keyword2' => array(
                            'value' => urlencode(diconv(lang('plugin/zimucms_hongbao', 'system_text29'), CHARSET, 'utf-8'))
                        )
                    )
                );
                $json      = urldecode(json_encode($template));
                $mb_result = $wechat_client->send_weixintemplate($json);
            }
        }
        
        //dheader('Location:'.ZIMUCMS_URL.'&model=yulanhongbao');
    } else {
        //$out['status'] = 200;
        //$out['hid'] = 200;
        //echo json_encode($out);
        $out['status'] = 0;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_hongbao', 'system_text22'));
        echo urldecode(json_encode($out));
        exit();
    }
    
    
} else if ($model == 'yulanhongbao') {
    
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $hid = intval($_GET['hid']);
    
    $hongbaoinfo = DB::fetch_first('select * from %t where id=%d and openid=%s', array(
        'zimucms_hongbao_list',
        $hid,
        $openid
    ));
    
    $myuserdata = DB::fetch_first('select * from %t where hid=%d and openid=%s and isok=1', array(
        'zimucms_hongbao_data',
        $hid,
        $openid
    ));
    
    $alluserdata = DB::fetch_all('select * from %t where hid=%d and isok=1 order by createtime desc', array(
        'zimucms_hongbao_data',
        $hid
    ));
    
    include template('zimucms_hongbao:yulanhongbao');
    
} else if ($model == 'addshare' && $_GET['md5formhash'] == formhash()) {
    
    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();
    
    $hid = intval($_GET['hid']);
    
    $share_nums = DB::result_first("SELECT count(*) FROM %t where openid=%s and hid=%d and addtime > %d", array(
        "zimucms_hongbao_share",
        $openid,
        $hid,
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));
    if (!$share_nums) {
        $addata['openid']  = $openid;
        $addata['hid']     = $hid;
        $addata['addtime'] = $_G['timestamp'];
        $result            = DB::insert('zimucms_hongbao_share', $addata);
    }
    
    $out['status'] = 200;
    echo json_encode($out);
    exit();
    
} else {
    
    $userinfo = oauthurl();
    
    if ($_GET['code']) {
        dheader('Location:' . ZIMUCMS_URL);
        return false;
    }
    
    $hongbaodata = DB::fetch_all('select * from %t where ispay=1 and onlyshare=0 order by starttime desc limit 100', array(
        'zimucms_hongbao_list'
    ));
    
    foreach ($hongbaodata as $key => $value) {
        
        $hongbaodata[$key]['yilingqu'] = DB::result_first("SELECT count(*) FROM %t where hid=%d and isok=1", array(
            "zimucms_hongbao_data",
            $value['id']
        ));
    }
    include template('zimucms_hongbao:hongbaolist');
    
    
    
}