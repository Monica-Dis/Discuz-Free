<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/config.php';
$model = addslashes($_GET['model']);


if ($model == 'edithongbao') {

$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);

    if (submitcheck('edithongbao')) {
        
        $addata['id']    = intval($_GET['id']);
        $addata['nickname'] = strip_tags($_GET['nickname']);
        $addata['desc']       = strip_tags($_GET['desc']);
        if ($_FILES['shop_logo']['tmp_name']) {
            $addata['logo'] = zm_saveimages($_FILES['shop_logo']);
        }
        if ($_FILES['shop_thumb']['tmp_name']) {
            $addata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $addata['leixing']    = intval($_GET['leixing']);
        $addata['allmoney']    = intval($_GET['allmoney']);
        $addata['allnums']     = intval($_GET['allnums']);
        $addata['ispay']    = intval($_GET['ispay']);
        $addata['secret_key']       = strip_tags($_GET['secret_key']);
        $addata['percent']    = intval($_GET['percent']);
        $addata['view']    = intval($_GET['view']);
        $addata['onlyshare']    = intval($_GET['onlyshare']);
        
        $result = DB::update('zimucms_hongbao_list', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_hongbao', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_hongbao', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $hid = intval($_GET['hid']);
        
        $hongbaodata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_hongbao_list',
            $hid
        ));
        
        include template('zimucms_hongbao:admin_edithongbao');
    }
    
} else {
    

$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);

$count = DB::result_first("SELECT count(*) FROM %t where ispay=1", array(
    "zimucms_hongbao_list"
));

$limit    = 100;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);


        $hongbaodata = DB::fetch_all('select * from %t where ispay=1 order by starttime desc,id desc limit %d,%d', array(
            'zimucms_hongbao_list',
            $start,
            $limit
        ));
     
     foreach ($hongbaodata as $key => $value) {

        $hongbaodata[$key]['yilingqu'] = DB::result_first("SELECT count(*) FROM %t where hid=%d and leixing=1 and isok=1", array(
            "zimucms_hongbao_data",
            $value['id']
        ));

        }   

if ($page_num > 1) {
    
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'], '10000', '10000', TRUE, TRUE);
}


    include template('zimucms_hongbao:admin_hongbaolist');
    
}