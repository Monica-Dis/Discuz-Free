<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if (!function_exists('curl_init')) {
echo 'no curl,please install curl model';exit();
}

error_reporting(0);

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_hongbao/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_hongbao');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);

$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_hongbao'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


function isuid()
{
    global $_G;
    if (!$_G['uid']) {
$refererurl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
        dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        
        exit();
    }
}


function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();
    
    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];

    if($upload->attach['imageinfo'][0]>1500 ||$upload->attach['imageinfo'][1]>1500 ) {
if($upload->attach['imageinfo'][0]>=$upload->attach['imageinfo'][1]){
$thumb_width = $upload->attach['imageinfo'][0]/2;
}else{
$thumb_width = $upload->attach['imageinfo'][1]/2;
}

        require_once libfile('class/image');
        $image = new image();
        $pic2 = $image->Thumb($upload->attach['target'], '',$thumb_width,$thumb_width,2);
    }

    if ($pic2) {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic.'.thumb.jpg';
    }else{
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic;  
    }
}

function zm_diconv($str){
$encode = mb_detect_encoding($str, array("ASCII","UTF-8","GB2312","GBK","BIG5")); 
if($encode != CHARSET){ 
//$keytitle = iconv($encode,CHARSET."//IGNORE",$str);
$keytitle = mb_convert_encoding($str,CHARSET,$encode);
}
if(!$keytitle){
$keytitle = $str;
}
return $keytitle;
}

function oauthurl(){

global $_G;

$zmdata = $_G['cache']['plugin']['zimucms_hongbao'];

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['weixin_appid'],$zmdata['weixin_appsecret']);

    list($openid, $unionid, $nickname, $headimgurl, $sex, $subscribe, $uptime) = getcookie('zm_hongbao') ? explode("\t", authcode(getcookie('zm_hongbao'), 'DECODE')) : array();

if($openid && $_GET['model'] != "myhongbao"){
return false;
}

if($openid && $_GET['model'] == "myhongbao" && $zmdata['is_guanzhu']==1 && $subscribe==1){
return false;
}

if($openid && $_GET['model'] == "myhongbao" && $zmdata['is_guanzhu']==0){
return false;
}

/*
if($openid && $zmdata['is_guanzhu']==0){
return false;
}

if($openid && $zmdata['is_guanzhu']==1 && $subscribe==1){
return false;
}

if($openid && $zmdata['is_guanzhu']==1 && $subscribe==0 && $_G['timestamp'] - $uptime < 60 ){
return false;
}
*/


$code = addslashes($_GET['code']);

if ($code){

        $token = $wechat_client->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }
$userinfo = $wechat_client->getUserInfoByAuth($token['access_token'], $token['openid']);
        if($userinfo['errcode']  && !$openid) {
            showmessage('error'.($userinfo['errmsg'] ? ' UserInfo: '.$userinfo['errmsg'] : ''));
        }

$info = $wechat_client->getUserInfoById($token['openid'],'zh_CN');

if(!$userinfo['openid'] || !$info['openid']){
$wechat_client->getAccessToken_new(1,0);
}

if($userinfo['openid']){
$userinfo2['userinfo'] = $userinfo;
}
if($info['openid']){
$userinfo2['info'] = $info;
}
if($userinfo['openid'] || $info['openid']){
set_oauth_cookie($userinfo2);
}

return $userinfo2;

}else{


$login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode(request_uri()) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';

dheader('Location:' . $login_url);
}


}



function request_uri(){
    global $_G;
if (isset($_SERVER['REQUEST_URI'])){
        $uri = $_G['siteurl'].$_SERVER['REQUEST_URI'];
}else{
        if (isset($_SERVER['argv'])){
            $uri = $_G['siteurl'].$_SERVER['PHP_SELF'] .'?'. $_SERVER['argv'][0];
        }else{
            $uri = $_G['siteurl'].$_SERVER['PHP_SELF'] .'?'. $_SERVER['QUERY_STRING'];
        }
    }
    return $uri;
}


function set_oauth_cookie($userinfo)
{
    global $_G;

$nickname = getnewname($userinfo['userinfo']['nickname']);

    dsetcookie('zm_hongbao', authcode($userinfo['userinfo']['openid'] . "\t" . $userinfo['info']['unionid'] . "\t" . dhtmlspecialchars(zm_diconv($nickname)) . "\t" . $userinfo['userinfo']['headimgurl'] . "\t" . $userinfo['userinfo']['sex'] . "\t" . $userinfo['info']['subscribe'] . "\t" . TIMESTAMP, 'ENCODE'), 3000, 1, true);
}


 /** 
 * ƴ�������ʵ�� 
 * ����num���������ÿ�������ռ������ܺ͵ı���*money_total��ֵ��Ϊÿ�������Ǯ�� 
 * ���ǵ��������⣬������������Ǹ������Ǯ��Ϊmoney_total-����������ܶ� 
 * �������Ƚϴ�С,ʹ��number_format,��ȷ��2λС�� 
 * 
 * @param double $money_total  ��Ǯ� ÿ������0.01,��ȷ��2λС�� 
 * @param int $num ���͸������� 
 * @return array num��Ԫ�ص�һά���飬ֵ�����Ǯ�� 
 */  
function sendHB($money_total, $num) {  
    if($money_total < $num*0.01) {  
        echo 'money to little';exit();  
    }  
  
    $rand_arr = array();  
    for($i=0; $i<$num; $i++) {  
        $rand = rand(1, 100);  
        $rand_arr[] = $rand;  
    }  
  
    $rand_sum = array_sum($rand_arr);  
    $rand_money_arr = array();  
    $rand_money_arr = array_pad($rand_money_arr, $num, 0.01);  //��֤ÿ���������0.01  
    foreach ($rand_arr as $key => $r) {  
        $rand_money = number_format($money_total*$r/$rand_sum, 2);
        if($rand_money <= 0.01 || round(array_sum($rand_money_arr),2) >= round($money_total, 2)) {  
            $rand_money_arr[$key] = 0.01;  
        } else {  
            $rand_money_arr[$key] = $rand_money;  
        }  
    }  
    $max_index = $max_rand = 0;  
    foreach ($rand_money_arr as $key => $rm) {  
        if($rm > $max_rand) {  
            $max_rand = $rm;  
            $max_index = $key;  
        }  
    }  
  
    unset($rand_money_arr[$max_index]);  
    //�����array_sum($rand_money_arr)һ����С��$money_total��  
    $rand_money_arr[$max_index] = number_format($money_total - array_sum($rand_money_arr), 2);  
      
    ksort($rand_money_arr);  
    return $rand_money_arr;  
}

function getnewname($username)
{
    global $_G;
require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/class/wechat.lib.class.php';

    $newname = cutstr(WeChatEmoji::clear($username), 15, '');
    
    if ($newname) {
        $censorexp = '/^(' . str_replace(array(
            '\\*',
            "\r\n",
            ' '
        ), array(
            '.*',
            '|',
            ''
        ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
        $newname   = preg_replace($censorexp, '', $newname);
        
        $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
        $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
    }
    
    return $newname;
}

    function IPlookup($ip) 
    {
        global $_G;
        $res = zm_curl('http://ip.taobao.com/service/getIpInfo.php?ip='.$ip);
        $res = json_decode($res,true);
        $res = $res['data'];
        $fromcity = zm_diconv($res['city']);
        if(!$fromcity){
        $fromcity = zm_diconv($res['region']);
        }
        if($_G['cache']['plugin']['zimucms_hongbao']['is_province']){
            $fromcity = zm_diconv($res['region']);
        }
        return $fromcity;
    }


function zm_curl($url)
{
    $retfrom=dfsockopen($url);
    if (!$retfrom) 
    {
        $retfrom=zm_curl_get($url);
    }
    return $retfrom;
}
function zm_curl_get($url)
{
    if (!function_exists('curl_init')) 
    {
        return file_get_contents($url);
    }
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    if (!curl_exec($ch)) 
    {
        error_log(curl_error($ch));
        $data='';
    }
    else 
    {
        $data=curl_multi_getcontent($ch);
    }
    curl_close($ch);
    return $data;
}

function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}
function downloadWeixinFile($url)
{
    if (!function_exists('curl_init')) {
    echo 'no curl,please install curl model';exit();
    }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HEADER, 0);    
    curl_setopt($ch, CURLOPT_NOBODY, 0);    //ֻȡbodyͷ
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $package = curl_exec($ch);
    $httpinfo = curl_getinfo($ch);
    curl_close($ch);
    $imageAll = array_merge(array('header' => $httpinfo), array('body' => $package)); 
    return $imageAll;
}

function saveWeixinFile($filename, $filecontent,$picname)
{
    $local_file = fopen($filename, 'w');
    if (false !== $local_file){
        if (false !== fwrite($local_file, $filecontent)) {
            fclose($local_file);
        }
    }
    return $picname;
}