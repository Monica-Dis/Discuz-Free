<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/config.php';
$model = addslashes($_GET['model']);

$hid    = intval($_GET['hid']);
$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);
$lingqu = intval($_GET['lingqu']);

if ($hid) {
    if ($lingqu==1) {
        $wheresql = ' where hid= ' . $hid . ' and hid !=0 and leixing=1 and isok=1 and get_money>0 and get_money<'.$zmdata['min_hongbao'];
    }else if ($lingqu==2) {
        $wheresql = ' where hid= ' . $hid . ' and hid !=0 and leixing=1 and isok=1 and get_money>='.$zmdata['min_hongbao'];
    }else if ($lingqu==3) {
        $wheresql = ' where hid= ' . $hid . ' and hid !=0 and leixing=1 and isok=0';
    }else{
        $wheresql = ' where hid= ' . $hid . ' and hid !=0 and leixing=1';
    }
} else {
    if ($lingqu==1) {
        $wheresql = ' where hid !=0 and leixing=1 and isok=1 and get_money>0 and get_money<'.$zmdata['min_hongbao'];
    }else if ($lingqu==2) {
        $wheresql = ' where hid !=0 and leixing=1 and isok=1 and get_money>='.$zmdata['min_hongbao'];
    }else if ($lingqu==3) {
        $wheresql = ' where hid !=0 and leixing=1 and isok=0';
    }else{
        $wheresql = ' where hid !=0 and leixing=1';
    }
}

$count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
    "zimucms_hongbao_data"
));

$limit    = 30;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

$lingqudata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
    'zimucms_hongbao_data',
    $start,
    $limit
));


if ($hid) {
    $hongbaodata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_hongbao_list',
        $hid
    ));
} else {
    
    foreach ($lingqudata as $key => $value) {
        $lingqudata[$key]['hongbaotitle'] = DB::result_first('select nickname from %t where id=%d', array(
            'zimucms_hongbao_list',
            $value['hid']
        ));
    }
    
}

if ($page_num > 1) {

    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&lingqu=' . $lingqu, '10000', '10000', TRUE, TRUE);
}

include template('zimucms_hongbao:admin_lingqulist');