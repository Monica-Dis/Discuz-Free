<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_hongbao/config.php';
$model = addslashes($_GET['model']);

if($model=='edituser'){


$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);

    if (submitcheck('edituser')) {
        
        $addata['id']    = intval($_GET['id']);
        $addata['all_money']    = intval($_GET['all_money']);
        $addata['shengyu_money']     = intval($_GET['shengyu_money']);
        
        $result = DB::update('zimucms_hongbao_userdata', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&modle='.$model.'&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_hongbao', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_hongbao', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $uid = intval($_GET['uid']);
        
        $userdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_hongbao_userdata',
            $uid
        ));
        

include template('zimucms_hongbao:admin_edituser');
    }

}else if($model=='tixian'){

$openid = strip_tags($_GET['openid']);
$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);

if($openid) {
$count = DB::result_first("SELECT count(*) FROM %t where openid=%s and leixing=2", array(
    "zimucms_hongbao_data",
    $openid
));
}else{
$count = DB::result_first("SELECT count(*) FROM %t where leixing=2", array(
    "zimucms_hongbao_data"
));
}
$limit    = 20;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

if($openid) {
$lingqudata = DB::fetch_all('select * from %t where openid=%s and leixing=2 order by id desc limit %d,%d', array(
    'zimucms_hongbao_data',
    $openid,
    $start,
    $limit
));
}else{
$lingqudata = DB::fetch_all('select * from %t where leixing=2 order by id desc limit %d,%d', array(
    'zimucms_hongbao_data',
    $start,
    $limit
));  
}
if ($page_num > 1) {

    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=tixian&openid=' . $openid, '20', '10000', TRUE, TRUE);
}

include template('zimucms_hongbao:admin_tixian');
}else{

$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);


$count = DB::result_first("SELECT count(*) FROM %t", array(
    "zimucms_hongbao_userdata"
));

$limit    = 100;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

$userdata = DB::fetch_all('select * from %t order by all_money desc,shengyu_money desc,id desc limit %d,%d', array(
    'zimucms_hongbao_userdata',
    $start,
    $limit
));


if ($page_num > 1) {

    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'], '10000', '10000', TRUE, TRUE);
}

include template('zimucms_hongbao:admin_user');
}