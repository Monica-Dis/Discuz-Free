<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_hongbao_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hid` int(10) unsigned NOT NULL,
  `openid` char(250) NOT NULL,
  `unionid` char(250) NOT NULL,
  `headimgurl` char(250) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `subscribe` tinyint(1) unsigned NOT NULL,
  `nickname` char(20) NOT NULL,
  `get_money` int(10) unsigned NOT NULL,
  `mch_billno` char(200) NOT NULL,
  `send_listid` char(200) NOT NULL,
  `result_code` char(200) NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `leixing` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `voiceurl` char(250) NOT NULL,
  `percent` char(10) NOT NULL,
  `isok` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_hongbao_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `openid` char(250) NOT NULL,
  `unionid` char(250) NOT NULL,
  `nickname` char(50) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `logo` char(255) NOT NULL,
  `thumb` char(255) NOT NULL,
  `desc` char(255) NOT NULL,
  `adma` char(250) NOT NULL,
  `adtext` char(250) NOT NULL,
  `leixing` tinyint(1) NOT NULL DEFAULT '1',
  `allmoney` int(10) unsigned NOT NULL,
  `allnums` smallint(3) unsigned NOT NULL,
  `ispay` tinyint(1) NOT NULL DEFAULT '0',
  `secret_key` char(255) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `percent` smallint(2) unsigned NOT NULL,
  `view` int(10) unsigned NOT NULL,
  `onlyshare` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `out_trade_no` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_hongbao_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hid` int(10) unsigned NOT NULL,
  `openid` char(250) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_hongbao_userdata` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `openid` char(250) NOT NULL,
  `unionid` char(250) NOT NULL,
  `nickname` char(100) NOT NULL,
  `headimgurl` char(250) NOT NULL,
  `subscribe` tinyint(1) unsigned NOT NULL,
  `all_money` int(10) unsigned NOT NULL,
  `shengyu_money` int(10) unsigned NOT NULL,
  `static` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sex` tinyint(1) unsigned NOT NULL,
  `uptimes` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


EOF;

runquery($sql);

$finish = TRUE;
?>