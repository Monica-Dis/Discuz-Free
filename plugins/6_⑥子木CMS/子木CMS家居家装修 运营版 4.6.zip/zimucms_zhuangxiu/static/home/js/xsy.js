Do.add('dialog', {
    path: basedir+'js/buckwilson-Lightbox/jquery.lightbox_me.min.js',
    type: 'js'
});
Do.add('placeholder', {
    path: basedir+"js/placeholder.min.js",
    type: 'js'
});
Do('placeholder',function() {
    $('input[type="text"]').each(function(){
        var inp = $(this);
        inp.placeholder({
            word: inp.attr("placeholder"),
            color: "#999"
        });
    });
});


Do(function () {
    Do('dialog');
    $(".form-sub-btn").on('click', function(){
        var formWrap = $(this).parents(".form-wrap-box");
        //reset
        formWrap.find(".error-box").hide();
        formWrap.find(".focus").removeClass("focus");
        var nameinput = formWrap.find('input[name="name"]'),
            name = nameinput.val(),
            phoneinput = formWrap.find('input[name="phone"]'),
            phone = phoneinput.val(),
            source = formWrap.find('input[name="source"]').val(),
            type = formWrap.find('input[name="type"]').val();


            if(nameinput.length>0 && (name == nameinput.attr("placeholder") || name == "")){
                nameinput.addClass("focus");
                nameinput.next(".error-box").show();
                return false;
            }
            if(phone != phoneinput.attr("placeholder") && phone != ""){
                if(!checkPhone(phone)){
                    phoneinput.addClass("focus");
                    phoneinput.next(".error-box").show();
                    return false;
                }
            } else {
                phoneinput.addClass("focus");
                phoneinput.next(".error-box").show();
                return false;
            }
            //�رյ�����
            $(".form-wrap-box").trigger('close');
            //��ʾ���ڼ���
            loadingData();
            $.ajax({
                type: 'POST',
                url: pcpostapi,
                data: {
                    name:name,
                    phone:phone,
                    source:source,
                    type: type
                },
                dataType: 'json',
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                success: function(data){
                    alertSuccess();
                    nameinput.val("");
                    phoneinput.val("");
                }
            });
    });

    //�ύ�ɹ���ʾ
    function alertSuccess(msg){
        if(!msg){
            msg = forum_iframe_text8;
        }
        if($(".alert-box").length == 0){
            $("body").append('<div class="alert-box"><div class="success-text fs22 c-green bigfs">'+msg+'</div></div>');
        } else {
            $(".alert-box").html('<div class="success-text fs22 c-green bigfs">'+msg+'</div>');
        }
        $(".alert-box").lightbox_me({
            centered: true,
            showOverlay: false,
            onLoad: function() {
                setTimeout(function(){
                    $(".alert-box").trigger('close');
                },2000);
            }
        });
    }
    //loading
    function loadingData(msg){
        if(!msg){
            msg = forum_iframe_text9;
        }
        if($(".alert-box").length == 0){
            $("body").append('<div class="alert-box"><div class="success-text fs22 c-green bigfs">'+msg+'</div></div>');
        } else {
            $(".alert-box").html('<div class="success-text fs22 c-green bigfs">'+msg+'</div>');
        }
        $(".alert-box").lightbox_me({
            centered: true,
            showOverlay: false,
            onLoad: function() {
            }
        });
    }

    function checkPhone(phone){
        var mobile = /^1[3|4|5|7|8][0-9]\d{8}$/;
        if(!mobile.test(phone)){
            return false;
        }
        return true;
    }
});
