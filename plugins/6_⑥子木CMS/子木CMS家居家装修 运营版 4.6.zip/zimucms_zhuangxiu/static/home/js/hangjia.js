Do.add('baidumap', {
    path: 'http://api.map.baidu.com/api?v=2.0&ak=415167759dc5861ddbbd14154f760c7e',
    type: 'js'
});
Do.add('dialog', {
    path: basedir+'js/buckwilson-Lightbox/jquery.lightbox_me.min.js',
    type: 'js'
});

Do(function(){
   var hangjia = {};
    hangjia.baidumap = function(){
        Do('dialog');
        var lng,lat,zoom,map,point,marker;

        function initMap(lng,lat,zoom){
            map = new BMap.Map("map");
            point = new BMap.Point(lng,lat);
            map.centerAndZoom(point, zoom ? zoom : 16);
            var top_left_control = new BMap.ScaleControl({anchor: BMAP_ANCHOR_TOP_LEFT});
            var top_left_navigation = new BMap.NavigationControl();  //左上角，添加默认缩放平移控件
            var top_right_navigation = new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_RIGHT, type: BMAP_NAVIGATION_CONTROL_SMALL}); //右上角，仅包含平移和缩放按钮
            map.addControl(top_left_control);
            map.addControl(top_left_navigation);
            map.addControl(top_right_navigation);
        }
        var $map = $("#map");
        if($map && $map.attr("data-lat")){
            lng = $map.attr("data-lng");
            lat = $map.attr("data-lat");
            zoom = $map.attr("data-zoom");
            initMap(lng,lat,zoom);
            marker = new BMap.Marker(point);
            map.addOverlay(marker);
        }

        $(".view-map-btn").bind("click", function(e){
            e.preventDefault();
            $(".map_container").show()
            var lng = $(this).attr("data-lng");
            var lat = $(this).attr("data-lat");
            var zoom = $(this).attr("data-lat");
            initMap(lng,lat,zoom);
            $('.map_container').lightbox_me({
                centered: true,
                closeSelector: ".close_map",
                onLoad: function() {
                    //放着解决和lightbox一起用的时候第一次打开 没有标注的问题
                    marker = new BMap.Marker(point);
                    map.addOverlay(marker);
                }
            });

        });
    };

    hangjia.fixedFormWrap = function(){

        var formWrap = $(".fixed-form-node");
        var point = formWrap.offset().top;
        var offsetTop = $(window).scrollTop();
        if (offsetTop > point) {
            formWrap.addClass("fixed");
        }
        $(window).on('scroll', function(){
            offsetTop = $(window).scrollTop();
            if (offsetTop > point) {
                formWrap.addClass("fixed");
            } else {
                formWrap.removeClass("fixed");
            }
        });
    };
    window.hangjia = hangjia;

});
