Do.add('dialog', {
    path: basedir+'js/buckwilson-Lightbox/jquery.lightbox_me.min.js',
    type: 'js'
});
Do.add('placeholder', {
    path: basedir+'js/placeholder.min.js',
    type: 'js'
});
Do.add('datepicker-css', {
    path: basedir+'js/datepicker/datepicker.min.css',
    type: 'css'
});
Do.add('datepicker', {
    path: basedir+'js/datepicker/datepicker.min.js',
    type: 'js',
    requires:['datepicker-css']
});

Do.ready(function(){
    Do('placeholder',function() {
        $('.form-wrap-box input[type="text"]').each(function(){
            var inp = $(this);
            inp.placeholder({
                word: inp.attr("placeholder"),
                color: "#999"
            });
        });
    });
    //����ѡ��
    if($(".datepicker").length > 0){
        Do('datepicker',function(){
            $(".datepicker").datepicker({dateFormat: "yyyy-mm-dd"});
        });
    }

    Do('dialog',function(){
        $('.form-pop-trigger').on('click', function(e){
            var target = $(this).attr("data-href");
            if(target){
                target = $(target);
            } else {
                target = $('.form-wrap-box');
            }
            if($(this).attr("data-id"))
                target.find('input[name="shopid"]').val($(this).attr("data-id"));
            if($(this).attr("data-plot-name"))
                target.find('input[name="plot_name"]').val($(this).attr("data-plot-name"));
            target.find(".focus").removeClass("focus");
            target.find(".error-box").hide();
            target.lightbox_me({
                centered: true,
                closeSelector: ".pop-close-btn"
            });
            e.preventDefault();
        });
    });
    //Ч��ͼ������ʾ
    $(".item-img-container").hover(function(){
        $(this).find(".item-tag-l").css({'display':'block'});
        $(this).find(".item-tag-r").css({'display':'block'});
    },function(){
        $(this).find(".item-tag-l").hide();
        $(this).find(".item-tag-r").hide();
    });
    //Ԥ��������
    $('.select-content li').click(function(){
        var formWrap = $(this).parents(".form-wrap-box");
        formWrap.find('.select-content').hide();
        formWrap.find('.budget').text($(this).text());
        formWrap.find('input[name="budget"]').val($(this).text());
    });
    $('.selects').mouseenter(function(){
        $('.select-content').show();
    }).mouseleave(function(){
        $('.select-content').hide();
    });
    //���÷���ǩ
    $('.style-tag-box a').click(function(e){
        var formWrap = $(this).parents(".form-wrap-box");
        formWrap.find('input[name="style"]').val($(this).attr("data-id"));
        $(this).siblings().removeClass("on");
        $(this).addClass("on");
        e.preventDefault();
    });

    $(".form-wrap-box").find('input[name="name"]').on('keyup', function(){
        $(this).siblings(".error-box").hide();
        $(this).removeClass("focus");
    });
    $(".form-wrap-box").find('input[name="phone"]').on('keyup', function(){
        if(checkPhone($(this).val())){
            $(this).siblings(".error-box").hide();
            $(this).removeClass("focus");
        }
    });

    $(".form-sub-btn").on('click', function(){
        var formWrap = $(this).parents(".form-wrap-box");
            //reset
            formWrap.find(".error-box").hide();
            formWrap.find(".focus").removeClass("focus");
        var nameinput = formWrap.find('input[name="name"]'),
            name = nameinput.val(),
            phoneinput = formWrap.find('input[name="phone"]'),
            phone = phoneinput.val();
        if(name == nameinput.attr("placeholder") || name == ""){
            nameinput.addClass("focus");
            nameinput.next(".error-box").show();
            return false;
        }
        if(phone != phoneinput.attr("placeholder") && phone != ""){
            if(!checkPhone(phone)){
                phoneinput.addClass("focus");
                phoneinput.next(".error-box").show();
                return false;
            }
        } else {
            phoneinput.addClass("focus");
            phoneinput.next(".error-box").show();
            return false;
        }
        var size = formWrap.find('input[name="size"]').val(),
            budget = formWrap.find('input[name="budget"]').val(),
            source = formWrap.find('input[name="source"]').val(),
            formhash = formWrap.find('input[name="formhash"]').val(),
            moreinfo = formWrap.find('input[name="moreinfo"]').val(),
            type = formWrap.find('input[name="type"]').val(),
            cate = formWrap.find('input[name="cate"]').val(),
            shopid = formWrap.find('input[name="shopid"]').val(),
            shopbuildingtype = formWrap.find('input[name="shopbuildingtype"]').val(),
            is_marry = formWrap.find('input[name="is_marry"]:checked').val(),
            request = formWrap.find('textarea[name="request"]').val(),
            plot_name = formWrap.find('input[name="plot_name"]').val(),
            start_time = formWrap.find('input[name="start_time"]').val(),
            bedroom = formWrap.find('input[name="bedroom"]').val(),
            livingroom = formWrap.find('input[name="livingroom"]').val(),
            style = formWrap.find('input[name="style"]').val(),
            bathroom = formWrap.find('input[name="bathroom"]').val(),
            size = size == pclang1 ? '' : (size ? size : "");
            budget = budget ? budget : "";
            cate = cate ? cate : 2;
            shopid = shopid ? shopid : 0;
            shopbuildingtype = shopbuildingtype ? shopbuildingtype : 1;
            is_marry = is_marry ? is_marry : "";
            request = request ? request : "";
            plot_name = plot_name ? plot_name : "";
            start_time = start_time ? start_time : "";
            bedroom = bedroom ? bedroom : 0;
            style = style ? style : 0;
            livingroom = livingroom ? livingroom : 0;
            bathroom = bathroom ? bathroom : 0;

            //�رյ�����
            $(".form-wrap-box").trigger('close');

            $.ajax({
                type: 'POST',
                url: pcpostapi,
                data: {
                    name:name,
                    phone:phone,
					formhash:formhash,
					moreinfo:moreinfo,
                    size: size,
                    budget: budget,
                    source:source,
                    type: type,
                    cate: cate,
                    sid:shopid,
                    shopbuildingtype:shopbuildingtype,
                    plot_name: plot_name,
                    is_marry: is_marry,
                    request: request,
                    start_time: start_time,
                    bedroom: bedroom,
                    livingroom: livingroom,
                    bathroom: bathroom,
                    style: style,
                },
                dataType: 'json',
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                success: function(data){
                    if(data.status == 1){
                        alertSuccess();
                        //��ʼ�������
                        nameinput.placeholder({
                            word: nameinput.attr("placeholder"),
                            color: "#999"
                        });
                        phoneinput.placeholder({
                            word: phoneinput.attr("placeholder"),
                            color: "#999"
                        });
                    }else{
                        alertFail();
                    }
                },
                error: function(){
                    alertFail();
                }
            });
    });


    $(".baoming-sub-btn").on('click', function(){
        var formWrap = $(this).parents(".form-wrap-box");
            //reset
            formWrap.find(".error-box").hide();
            formWrap.find(".focus").removeClass("focus");
        var nameinput = formWrap.find('input[name="name"]'),
            name = nameinput.val(),
            phoneinput = formWrap.find('input[name="phone"]'),
            phone = phoneinput.val();
        if(name == nameinput.attr("placeholder") || name == ""){
            nameinput.addClass("focus");
            nameinput.next(".error-box").show();
            return false;
        }
        if(phone != phoneinput.attr("placeholder") && phone != ""){
            if(!checkPhone(phone)){
                phoneinput.addClass("focus");
                phoneinput.next(".error-box").show();
                return false;
            }
        } else {
            phoneinput.addClass("focus");
            phoneinput.next(".error-box").show();
            return false;
        }
        var postapiinput = formWrap.find('input[name="postapi"]');
            postapi = postapiinput.val();
        var md5formhash = formWrap.find('input[name="md5formhash"]').val();
        var aid = formWrap.find('input[name="aid"]').val();
        var aidtitle = formWrap.find('input[name="aidtitle"]').val();
            //�رյ�����
            $(".form-wrap-box").trigger('close');

            $.ajax({
                type: 'POST',
                url: postapi,
                data: {
                    name:name,
                    phone:phone,
                    md5formhash:md5formhash,
                    aid:aid,
                    aidtitle:aidtitle,
                },
                dataType: 'json',
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                success: function(data){
                    if(data.status == 1){
                        alertSuccess();
                        //��ʼ�������
                        nameinput.placeholder({
                            word: nameinput.attr("placeholder"),
                            color: "#999"
                        });
                        phoneinput.placeholder({
                            word: phoneinput.attr("placeholder"),
                            color: "#999"
                        });
                    }else{
                        alertFail();
                    }
                },
                error: function(){
                    alertFail();
                }
            });
    });

    //�ύʧ����ʾ
    function alertFail(){
        $(".success-box").find('.oks').addClass("errors");
        $(".success-box").find('.tips').text(pclang2);
        $(".success-box").find('.msg').text(pclang3);
        $(".success-box").lightbox_me({
            centered: true,
            onLoad: function() {
                $(".alert-box").trigger('close');
                $(".success-box-close").on('click', function(e){
                    e.preventDefault();
                    $(".success-box").trigger('close');
                    $(".success-box").find('.oks').removeClass("errors");
                    $(".success-box").find('.tips').text(pclang4);
                    $(".success-box").find('.msg').text(pclang5);
                });
            }
        });
    }
    //�ύ�ɹ���ʾ
    function alertSuccess(msg){
        $(".success-box").lightbox_me({
            centered: true,
            onLoad: function() {
                $(".alert-box").trigger('close');
                $(".success-box-close").on('click', function(e){
                    e.preventDefault();
                    $(".success-box").trigger('close');
                });
            }
        });
    }
    //loading
   /* function loadingData(msg){
        if(!msg){
            msg = '�����ύ��...';
        }
        if($(".alert-box").length == 0){
            $("body").append('<div class="alert-box"><div class="success-text fs22 c-green bigfs">'+msg+'</div></div>');
        } else {
            $(".alert-box").html('<div class="success-text fs22 c-green bigfs">'+msg+'</div>');
        }
        $(".alert-box").lightbox_me({
            centered: true,
            onLoad: function() {
            }
        });
    }*/

    function checkPhone(phone){
        var mobile = /^1[3|4|5|7|8][0-9]\d{8}$/;
        if(!mobile.test(phone)){
            return false;
        }
        return true;
    }
});