Do.add('DD_belatedPNG', {
    path: basedir+'js/DD_belatedPNG.js',
    type: 'js'
});
Do.add('lazyload', {
    path: basedir+'js/jquery-lazyload/jquery.lazyload.js',
    type: 'js'
});
Do.add('placeholder', {
    path: basedir+'js/placeholder.min.js',
    type: 'js'
});
Do.add('scrollbar', {
    path: basedir+'js/scrollbar.js',
    type: 'js'
});
Do.add('LiveSeach', {
    path: basedir+'js/LiveSearch/livesearch.min.js',
    type: 'js'
});

var Browser = {};
var ua = navigator.userAgent.toLowerCase();
var s;
(s = ua.match(/msie ([\d.]+)/)) ? Browser.ie = s[1] : 0;

Do.ready(function(){
$.getJSON(siteSettings.getuserinfoUrl+'&jsoncallback=?',  function(info){
    if(info.uid){
        var infoStr = '<li><a title="' + info.username + '">'
            + '<img class="avatar" src="' + info.avatar + '">' + info.username + '</a></li>';
    if(info.shopid>0){
            infoStr += '<li class="personal-select"><a title="'+headerlang1+'">'+headerlang1+'<i class="head-icon arrowdown fr">&nbsp;</i></a>'
            +'<ul class="dropdown_info_box personal_center">';
            infoStr += '<li class="last"><a href="' + info.shopurl + '" target="_blank">'+headerlang2+'</a></li>';
            infoStr += '<li class="last"><a href="' + info.manageurl + '" target="_blank">'+headerlang3+'</a></li>';
            infoStr += '</ul></li>';
}
            $("#userlogin").html(infoStr);
    }
 });

    /*��¼ end*/

	if (Browser.ie == "6.0") {
        Do('DD_belatedPNG',function(){
            DD_belatedPNG.fix('.head-icon');
			DD_belatedPNG.fix('.icon');
			DD_belatedPNG.fix('.index-icon');			
        });
    }

	/*����*/
	Do('scrollbar');
    Do('lazyload', function(){
            $("img.lazy").lazyload({
                effect : "fadeIn",
                placeholder:siteSettings.noPicUrl
            });
    });
    //������ҳѡ�
    $('.change-tab li').click(function(){
        $('.change-tab li').removeClass();
        $(this).addClass('cur');
        $('.change-content').find('.about-content').hide();
        $('.change-content').find('.about-content').eq($(this).index()).show();
    });

    /*$('.bm-form-ul input').keydown(function(){
        $(this).siblings().html('');
        $(this).removeClass('focus');
    });*/
    $('.case-list li').mouseenter(function(){
        $(this).find('.help-design').show();
    }).mouseleave(function(){
        $(this).find('.help-design').hide();
    });
	$('.raiders').mouseenter(function(){
        $(this).find('.cbox').addClass('on');
        $(this).find('.lis').show();    
    }).mouseleave(function(){        
        $(this).find('.cbox').removeClass('on');    
        $(this).find('.lis').hide();    
    });  
});