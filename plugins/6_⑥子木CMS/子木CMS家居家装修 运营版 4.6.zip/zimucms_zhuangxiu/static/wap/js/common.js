Zepto(function($){
    $(".dl-list").on("touchstart", function(){
        $(this).addClass("active");
    });
    $(".dl-list").on("touchend", function(){
        $(this).removeClass("active");
    });
    $(".dl-list").on("touchcancel", function(){
        $(this).removeClass("active");
    });

    //�ص�����
    var backTop = $(".gototop");
    backTop.bind("click", function (e) {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        return false;
    });


    //�����˵�
    $('#menu> li').bind('click',function(e){
        if($(this).find('i').hasClass('arrow-down')){
            $(this).find('i').removeClass('arrow-down').addClass('arrow-up');
            $(this).siblings().find('i').removeClass().addClass('arrow-down');
            $('.submenu').hide();
            $('.submenu').eq($(this).index()).show();
            $('#menu> li').removeClass('active')
            $(this).addClass('active');
            $(".layer-overall").css({"min-height":$("body").height()-90,"top":"146px"}).show();
            $('.layer-overall').show();
        }else if($(this).find('i').hasClass('arrow-up')){
            $(this).find('i').removeClass('arrow-up').addClass('arrow-down');
            $(this).siblings().find('i').removeClass().addClass('arrow-down');
            $('#menu> li').removeClass('active')
            $('.layer-overall').hide();
            $('.submenu').hide();
        }
        e.preventDefault();
        e.stopPropagation();

    })
    $(".layer-overall").on("touchstart ",function(e){
        $('#menu>li').removeClass('active');
        $('#menu>li>i').removeClass().addClass('arrow-down');
        $(this).hide();
        $(".submenu").hide();
        $('.drop-box').hide();
        e.preventDefault();
        e.stopPropagation();
    })

    $('.drop-btn').on('tap',function(e){
        $(".submenu").hide();
        if($(this).hasClass('down')){
            $('.drop-box').show();
            $(this).removeClass('down').addClass('up');
            $(".layer-overall").css({"min-height":$("body").height()-90,"top":'40px'}).show();
            $('.layer-overall').show();
        }else{
            $('.drop-box').hide();
            $(this).removeClass('up').addClass('down');
            $('.layer-overall').hide();
        }
        e.preventDefault();
        e.stopPropagation();
    });

    $('.type-two>li').bind("tap", function(e){
        $(this).siblings().find('ul').hide();
        $(this).siblings().removeClass('current');
        $(this).find('ul').show();
        $(this).addClass('current');
        e.preventDefault();
        e.stopPropagation();
    });

    $('.type-two>li>a').bind("click", function(e){
        if(!$(this).hasClass("redirect")){
            e.preventDefault();
        }
    });
    /*$(document).bind('click',function(){
     $('.layer-overall').hide();
     $(".submenu").hide();
     $('.drop-box').hide();
     $('.drop-btn').removeClass('up').addClass('down');
     $('#menu> li> i').removeClass().addClass('arrow-down');
     });*/
    //��ʾ����
    $(".comment-content .more-toggle").on('tap', function(){
        $(this).parent().hide();
        $(this).parent().siblings(".comment-content").show();
    });

    //�ײ�����
    /* if($(".bottom_khdxz").length > 0){
     if ($.cookie('bottom_khdxz') == null){
     $(".bottom_khdxz").removeClass("dn");
     }
     $(".bottom_khdxz_close").on("click", function () {
     $(".bottom_khdxz").addClass("dn");
     $(".gototop").css({"bottom":"40px"});
     $.cookie('bottom_khdxz', 1, {'expires': 1, 'path': '/'});
     return false;
     });
     }*/

    //ͷ������
    (function(){
        var subnav = $('.subnav-layer'),
            subnav_bg = $('.layer-subnav-bg'),
            trigger = $('.layer-sub-btn');
        $(trigger).on('click', function(){
            if(!subnav.hasClass('menuin')){
                subnav.show();
                subnav.removeClass("menuout").addClass("menuin");
                subnav_bg.show();
            } else {
                subnav.removeClass("menuin").addClass("menuout");
                setTimeout(function(){subnav.hide()},100)
                subnav_bg.hide();
            }
        });
        $(subnav_bg).on('click', function(e){
            subnav.addClass("menuout").removeClass('menuin');
            setTimeout(function() {
                subnav.hide();
            },100);
            $(this).hide();
        });
    })();
//back
    $(".back-btn").on("tap", function(e){
        history.go(-1);
        e.preventDefault();
    });
    //������ʾ��
    function alertDialog(type,msg){
        var obj = $(".bind-success");
        var bglayout=$('.layer-overall')
        if(bglayout.length==0){
            bglayout=$('<div class="layer-overall"></div>');
            $('body').append(bglayout);
        }
        if (obj.length == 0){
            obj = $('<div class="bind-' + type + '">' + msg + '</div>');
            $('body').append(obj);
        }
        else{
            obj.html(msg);
        }
        $(".layer-overall").css({"min-height":$("body").height()-90}).show();
        $('.bind-success').show();
        setTimeout(function () {
            obj.hide();
            bglayout.hide();
        }, 2000);
    }

    //WAP���ͱ����ύ
    $('.new-form-btn').on('tap',function(){
        var nameinput = $('input[name="name"]'),
            name = nameinput.val(),
            phoneinput = $('input[name="phone"]'),
            phone = phoneinput.val();
        if(name==''){
            alertDialog('fail',wapjslang1);
            return false;
        } else if(!(/^1[3|4|5|7|8][0-9]\d{4,8}$/.test(phone))) {
            alertDialog('fail',wapjslang2);
            return false;
        }
            size = $('input[name="size"]').val(),
            style = $('select[name="style"]').val(),
            budget = $('select[name="budget"]').val(),
            source = $('input[name="source"]').val(),
            type = $('input[name="type"]').val(),
            sid = $('input[name="shopid"]').val(),
            shopbuildingtype = $('input[name="shopbuildingtype"]').val(),
            plot_name = $('input[name="plot_name"]').val(),

        size = size ? size : "";
        budget = budget ? budget : "";
        sid = sid ? sid : 0;
        shopbuildingtype = shopbuildingtype ? shopbuildingtype : 1;
        plot_name = plot_name ? plot_name : "";

        //�رյ�����
        $(".form-wrap-box").trigger('close');
        //��ʾ���ڼ���
        //loadingData();
        $.ajax({
            type: 'post',
            url: wapyuyue,
            data: {
                md5formhash:md5formhash,
                name:name,
                phone:phone,
                size: size,
                budget: budget,
                source:source,
                type: type,
                sid:sid,
                shopbuildingtype:shopbuildingtype,
                plot_name: plot_name,
                style: style,
            },
            dataType: 'json',
            contentType: "application/x-www-form-urlencoded; charset=utf-8",
            success: function(data){
                if(data.status == 1) {
                    alertDialog('success',wapjslang3);
                     nameinput.val("");
                     phoneinput.val("");
                    //location.href=data.url;
                } else {
                    alert(data.msg);
                }
            }
        });
    });



});


