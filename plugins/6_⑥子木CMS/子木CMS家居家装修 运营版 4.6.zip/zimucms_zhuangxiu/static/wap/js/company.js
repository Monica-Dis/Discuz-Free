Zepto(function($){
    var slideHeight = 130;
    var textHeight = $('.text-hd').height();
    if(textHeight >= slideHeight){
        $('.text-hd').css('height',slideHeight + 'px');
        $('.read-more').append('<span>more&gt;&gt;</span>');
        $('.read-more span').click(function(){
            var curHeight = $('.text-hd').height();
            if(curHeight == slideHeight){
                $('.text-hd').css('height',textHeight + 'px');
                $('.read-more span').html('open&gt;&gt;');
                $('.gradient').fadeOut();
            }else{
                $('.text-hd').css('height',slideHeight + 'px');
                $('.read-more span').html('more&gt;&gt;');
                $('.gradient').fadeIn();
            }
            return false;
        });
    }
});