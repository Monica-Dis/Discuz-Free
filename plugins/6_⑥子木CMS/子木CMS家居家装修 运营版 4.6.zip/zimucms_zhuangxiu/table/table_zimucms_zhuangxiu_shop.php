<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_zimucms_zhuangxiu_shop extends discuz_table{
    public function __construct() {
        $this->_table = 'zimucms_zhuangxiu_shop';
        $this->_pk = 'id';
        parent::__construct();
    }

    public function fetch_all(){
         return DB::fetch_all('select * from %t order by sort desc',array($this->_table));
    }

    public function fetch_status_all(){
         return DB::fetch_all('select * from %t where status=1 order by id desc',array($this->_table));
    }

    public function fetch_by_sid($sid){
         return DB::fetch_first('select * from %t where id=%d',array($this->_table,$sid));
    }


    public function fetch_by_sid_shop($sid){
return DB::query("SELECT pre_zimucms_zhuangxiu_shop.*,pre_zimucms_zhuangxiu_designer.name,pre_zimucms_zhuangxiu_designer.touxiang,pre_zimucms_zhuangxiu_designer.zhicheng FROM pre_zimucms_zhuangxiu_shop INNER JOIN pre_zimucms_zhuangxiu_designer ON pre_zimucms_zhuangxiu_shop.id=pre_zimucms_zhuangxiu_designer.sid where pre_zimucms_zhuangxiu_shop.id=".$sid);
    }

    public function delete_by_id($id){
         return DB::delete($this->_table,'id='.$id);
    }

    public function insert($data){
         return DB::insert($this->_table,$data);
    }



}
//From: Dism_taobao-com
?>