<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

$zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);
    
    if (!submitcheck('basesubmit')) {
        
        showformheader("plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=" . $module['name'], "enctype");
        
        
        showtableheader(lang('plugin/zimucms_zhuangxiu', 'system_text3'));

        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text4'), 'zmdata[xiaoguotu_seo_title]', $zmdata['xiaoguotu_seo_title'], 'textarea', '', 0);
        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text5'), 'zmdata[xiaoguotu_seo_keywords]', $zmdata['xiaoguotu_seo_keywords'], 'textarea', '', 0);
        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text6'), 'zmdata[xiaoguotu_seo_desc]', $zmdata['xiaoguotu_seo_desc'], 'textarea', '', 0);

        showtablefooter();/*Dism��taobao��com*/

        showtableheader(lang('plugin/zimucms_zhuangxiu', 'system_text7'));

        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text8'), 'zmdata[shop_seo_title]', $zmdata['shop_seo_title'], 'textarea', '', 0);
        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text9'), 'zmdata[shop_seo_keywords]', $zmdata['shop_seo_keywords'], 'textarea', '', 0);
        showsetting(lang('plugin/zimucms_zhuangxiu', 'system_text10'), 'zmdata[shop_seo_desc]', $zmdata['shop_seo_desc'], 'textarea', '', 0);

        showtablefooter();/*Dism��taobao��com*/


        showtableheader($language_zimu['Admin_seo_inc_php_0']);

        showsetting($language_zimu['Admin_seo_inc_php_1'], 'zmdata[xiaoqu_seo_title]', $zmdata['xiaoqu_seo_title'], 'textarea', '', 0);
        showsetting($language_zimu['Admin_seo_inc_php_2'], 'zmdata[xiaoqu_seo_keywords]', $zmdata['xiaoqu_seo_keywords'], 'textarea', '', 0);
        showsetting($language_zimu['Admin_seo_inc_php_3'], 'zmdata[xiaoqu_seo_desc]', $zmdata['xiaoqu_seo_desc'], 'textarea', '', 0);

        showtablefooter();/*Dism��taobao��com*/


        showtableheader();
        showsubmit('basesubmit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();


    } else {
        
        $zmdata = array(
            'zimucms_zhuangxiu_seo' => serialize($_GET['zmdata'] + $zmdata)
        );
        C::t('common_setting')->update_batch($zmdata);
        updatecache('setting');
        
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=" . $module['name'], "succeed");
        
    }