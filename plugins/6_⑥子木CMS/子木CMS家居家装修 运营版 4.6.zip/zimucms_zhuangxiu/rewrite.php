<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

$domainlist = $_G['setting']['domain']['list'];

foreach ($domainlist as $k => $v) {
	if ($v['idtype'] == 'plugin') {
		$domainlist2[$v['id']] = $k;
	}
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

if($domainlist2['zimucms_zhuangxiu'] && $domainlist2['zimucms_zhuangxiu'] != 'localhost' ){
$zx_domain = $protocol.$domainlist2['zimucms_zhuangxiu'].'/';
}else{
$zx_domain = $_G['siteurl'];
}

$the_host = $_SERVER['HTTP_HOST'];

$request_url = isset($_SERVER['REQUEST_URI'])?$_SERVER['REQUEST_URI']:'';
if($the_host != $domainlist2['zimucms_zhuangxiu'] && $domainlist2['zimucms_zhuangxiu']){
header('HTTP/1.1 301 Moved Permanently');
header('Location: '.$protocol.$domainlist2['zimucms_zhuangxiu'].$request_url);
}

if ($zimu_rewrite['zx_model']['available']) {
    
    if ($model == 'bid_design' || $model == 'bid_decoration' || $model == 'bid_check' || $model == 'bid_superv' || $model == 'xiaoguotu' || $model == 'xiaoqu' || $model == 'shop' || $model == 'activitylist' || $model == 'building' || $model == 'workmen' || $model == 'daily' || $model == 'newslist') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'model'
            ), array(
                '',
                '',
                $model
            ), $zimu_rewrite['zx_model']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewxiaoqu']['available']) {
    
    if ($model == 'viewxiaoqu') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewxiaoqu&qid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'qid'
            ), array(
                '',
                '',
                intval($_GET['qid'])
            ), $zimu_rewrite['zx_viewxiaoqu']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewxiaoqu_case']['available']) {
    
    if ($model == 'viewxiaoqu_case') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewxiaoqu_case&qid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'qid'
            ), array(
                '',
                '',
                intval($_GET['qid'])
            ), $zimu_rewrite['zx_viewxiaoqu_case']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewxiaoqu_site']['available']) {
    
    if ($model == 'viewxiaoqu_site') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewxiaoqu_site&qid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'qid'
            ), array(
                '',
                '',
                intval($_GET['qid'])
            ), $zimu_rewrite['zx_viewxiaoqu_site']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewbuilding']['available']) {
    
    if ($model == 'viewbuilding') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewbuilding&bid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'bid'
            ), array(
                '',
                '',
                intval($_GET['bid'])
            ), $zimu_rewrite['zx_viewbuilding']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewshop']['available']) {
    
    if ($model == 'viewshop') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewshop&sid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'sid'
            ), array(
                '',
                '',
                intval($_GET['sid'])
            ), $zimu_rewrite['zx_viewshop']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_tuceshop']['available']) {
    
    if ($model == 'tuceshop') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=tuceshop&sid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'sid'
            ), array(
                '',
                '',
                intval($_GET['sid'])
            ), $zimu_rewrite['zx_tuceshop']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_tuce']['available']) {
    
    if ($model == 'tuce') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=tuce&tid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'tid'
            ), array(
                '',
                '',
                intval($_GET['tid'])
            ), $zimu_rewrite['zx_tuce']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_gongdishop']['available']) {
    
    if ($model == 'gongdishop') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=gongdishop&sid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'sid'
            ), array(
                '',
                '',
                intval($_GET['sid'])
            ), $zimu_rewrite['zx_gongdishop']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_gongdi']['available']) {
    
    if ($model == 'gongdi') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=gongdi&gid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'gid'
            ), array(
                '',
                '',
                intval($_GET['gid'])
            ), $zimu_rewrite['zx_gongdi']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_teamshop']['available']) {
    
    if ($model == 'teamshop') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=teamshop&sid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'sid'
            ), array(
                '',
                '',
                intval($_GET['sid'])
            ), $zimu_rewrite['zx_teamshop']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_designer']['available']) {
    
    if ($model == 'designer') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=designer&did') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'did'
            ), array(
                '',
                '',
                intval($_GET['did'])
            ), $zimu_rewrite['zx_designer']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_contactshop']['available']) {
    
    if ($model == 'contactshop') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=contactshop&sid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'sid'
            ), array(
                '',
                '',
                intval($_GET['sid'])
            ), $zimu_rewrite['zx_contactshop']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_activity']['available']) {
    
    if ($model == 'activity') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=activity&aid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'aid'
            ), array(
                '',
                '',
                intval($_GET['aid'])
            ), $zimu_rewrite['zx_activity']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($zimu_rewrite['zx_viewworkmen']['available']) {
    
    if ($model == 'viewworkmen') {
        
        if (strpos($_SERVER['REQUEST_URI'], '&model=viewworkmen&gid') !== false) {
            
            $zx_url = $zx_domain . str_replace(array(
                '{',
                '}',
                'gid'
            ), array(
                '',
                '',
                intval($_GET['gid'])
            ), $zimu_rewrite['zx_viewworkmen']['rule']);
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_url);
            
        }
        
    }
    
}

if ($domainlist2['zimucms_zhuangxiu'] && $domainlist2['zimucms_zhuangxiu'] != 'localhost' ) {

    if ($model == 'newindex') {
        
        if (strpos($_SERVER['REQUEST_URI'], 'plugin.php?id=zimucms_zhuangxiu') !== false) {
            
            header('HTTP/1.1 301 Moved Permanently');
            header('Location:' . $zx_domain);
            
        }
        
    }
    
}