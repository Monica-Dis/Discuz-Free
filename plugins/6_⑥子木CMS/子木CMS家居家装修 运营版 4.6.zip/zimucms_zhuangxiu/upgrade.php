<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$tucelist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_tuce'));

$tucelistarray = mysqltoarray($tucelist);
if (!in_array('vrurl', $tucelistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_tuce` ADD COLUMN `vrurl` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('xiaoqu', $tucelistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_tuce` ADD COLUMN `xiaoqu` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

$yuyuelist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_yuyue'));

$yuyuelistarray = mysqltoarray($yuyuelist);
if (!in_array('type', $yuyuelistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_yuyue` ADD COLUMN `type` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}

$shoplist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_shop'));

$shoplistarray = mysqltoarray($shoplist);
if (!in_array('openid', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_shop` ADD COLUMN `openid` VARCHAR(2000) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('coupon', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_shop` ADD COLUMN `coupon` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('map_lng', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_shop` ADD COLUMN `map_lng` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('map_lat', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_shop` ADD COLUMN `map_lat` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('tosms', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_shop` ADD COLUMN `tosms` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

$buildinglist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_building'));

$buildinglistarray = mysqltoarray($buildinglist);
if (!in_array('openid', $buildinglistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_building` ADD COLUMN `openid` VARCHAR(2000) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('coupon', $buildinglistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_building` ADD COLUMN `coupon` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('tosms', $buildinglistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_building` ADD COLUMN `tosms` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

$gongdilist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_gongdi'));

$gongdilistarray = mysqltoarray($gongdilist);
if (!in_array('xiaoqu', $gongdilistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_gongdi` ADD COLUMN `xiaoqu` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

$activitylist_list = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_zhuangxiu_activitylist'));

$activitylist_array = mysqltoarray($activitylist_list);
if (!in_array('shoptext', $activitylist_array)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_zhuangxiu_activitylist` ADD COLUMN `shoptext` TEXT NOT NULL;
EOF;
    runquery($sql1);
}



    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_zhuangxiu_parameter` CHANGE  `name`  `name` CHAR( 100 ) NOT NULL;
ALTER TABLE  `pre_zimucms_zhuangxiu_parameter` CHANGE  `ename`  `ename` CHAR( 100 ) NOT NULL;
CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_building` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `name` char(30) NOT NULL,
  `pic` char(255) NOT NULL,
  `address` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `quyu` tinyint(2) unsigned NOT NULL,
  `desc` text NOT NULL,
  `contentname1` char(255) NOT NULL,
  `contentval1` text NOT NULL,
  `contentname2` char(255) NOT NULL,
  `contentval2` text NOT NULL,
  `contentname3` char(255) NOT NULL,
  `contentval3` text NOT NULL,
  `contentname4` char(255) NOT NULL,
  `contentval4` text NOT NULL,
  `fuwu` varchar(1000) NOT NULL,
  `buildingtype` smallint(2) unsigned NOT NULL,
  `bbsurl` char(100) NOT NULL,
  `coupon` char(100) NOT NULL,
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `istop` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `casenums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `gongdinums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `designernums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `indexsort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_activitylist` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `thumb` char(200) NOT NULL,
  `typeid` smallint(3) UNSIGNED NOT NULL,
  `stime` int(10) UNSIGNED NOT NULL,
  `etime` int(10) UNSIGNED NOT NULL,
  `hstime` int(10) UNSIGNED NOT NULL,
  `hetime` int(10) UNSIGNED NOT NULL,
  `address` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `content` text NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL DEFAULT '100',
  `addtime` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `bbsurl` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_activityuser` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `aidtitle` char(100) NOT NULL,
  `name` char(100) NOT NULL,
  `phone` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_xiaoqu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `thumb` char(255) NOT NULL,
  `intro` varchar(1000) NOT NULL,
  `address` char(255) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL,
  `quyu` smallint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_daily` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `thumb` varchar(1000) NOT NULL,
  `thumb2` varchar(1000) NOT NULL,
  `thumb3` varchar(1000) NOT NULL,
  `thumb4` varchar(1000) NOT NULL,
  `desc` char(255) NOT NULL,
  `fengge` smallint(2) UNSIGNED NOT NULL,
  `huxing` smallint(2) UNSIGNED NOT NULL,
  `fangshi` smallint(2) UNSIGNED NOT NULL,
  `xiaoqu` smallint(2) UNSIGNED NOT NULL,
  `xiaoquname` char(100) NOT NULL,
  `sid` int(10) UNSIGNED NOT NULL,
  `sname` char(30) NOT NULL,
  `yusuan` smallint(2) UNSIGNED NOT NULL,
  `mianji` smallint(3) UNSIGNED NOT NULL,
  `posturl` varchar(1000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_buildingcase` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `thumb` char(255) NOT NULL,
  `con` mediumtext NOT NULL,
  `bid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_workmen` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL,
  `thumb` varchar(300) NOT NULL,
  `age` smallint(3) UNSIGNED NOT NULL,
  `intro` varchar(500) NOT NULL,
  `con` mediumtext NOT NULL,
  `tel` char(11) NOT NULL,
  `quyu` int(10) UNSIGNED NOT NULL,
  `wid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
    runquery($sql1);

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}