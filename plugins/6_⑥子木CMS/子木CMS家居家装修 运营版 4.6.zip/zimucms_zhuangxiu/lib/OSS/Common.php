<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/Result.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/OssClient.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/XmlConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Core/MimeTypes.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Core/OssException.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Core/OssUtil.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Http/RequestCore.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Http/RequestCore_Exception.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Http/ResponseCore.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/BucketInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/BucketListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/CorsConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/CorsRule.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/GetLiveChannelHistory.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/GetLiveChannelInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/GetLiveChannelStatus.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LifecycleAction.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LifecycleConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LifecycleRule.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/ListMultipartUploadInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/ListPartsInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LiveChannelConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LiveChannelHistory.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LiveChannelInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LiveChannelListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/LoggingConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/ObjectInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/ObjectListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/PartInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/PrefixInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/RefererConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/UploadInfo.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/WebsiteConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Model/CnameConfig.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/PutSetDeleteResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/AclResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/AppendResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/BodyResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/CallbackResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/CopyObjectResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/DeleteObjectsResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ExistResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetCnameResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetCorsResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetLifecycleResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetLiveChannelHistoryResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetLiveChannelInfoResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetLiveChannelStatusResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetLoggingResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetRefererResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/GetWebsiteResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/HeaderResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/InitiateMultipartUploadResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ListBucketsResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ListLiveChannelResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ListMultipartUploadResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ListObjectsResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/ListPartsResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/PutLiveChannelResult.php';
include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Result/UploadPartResult.php';


use \OSS\OssClient;


function zm_oss_upload($objname, $file){
    global $_G;

$zmdata = $_G['cache']['plugin']['zimucms_zhuangxiu'];

    try{

        $ossClient = new OssClient($zmdata['ACCESS_ID'], $zmdata['ACCESS_KEY'], $zmdata['ENDPOINT'], false);

        $ret = $ossClient->uploadFile($zmdata['BUCKET'], $objname, $file);
    }catch (Exception $e){
        $ret = array( 'oss-request-url' => $e->getMessage() );
    }
    $rurl = $ret['oss-request-url'] ? $ret['oss-request-url'] : '';
    if($zmdata['ossurl']){
        $r= parse_url($rurl);
        $rurl = str_replace($r['scheme']."://".$r['host'], $zmdata['ossurl'], $rurl);
    }
    return $rurl;
}