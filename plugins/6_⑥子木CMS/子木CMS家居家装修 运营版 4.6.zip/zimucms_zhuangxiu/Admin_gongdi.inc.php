<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'gongdi';
}

if ($model == 'gongdi') {
    
    $status = intval($_GET['status']);
    if ($status) {
        $wheresql  = ' where status=3 ';
        $wheresql2 = ' where a.status=3 ';
    }
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
        "zimucms_zhuangxiu_gongdi"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $aaa = DB::query('select a.*,b.name as shopname from %t a left join %t b on a.sid=b.id ' . $wheresql2 . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_gongdi',
        'zimucms_zhuangxiu_shop',
        $start,
        $limit
    ));
    while ($res = DB::fetch($aaa)) {
        $gongdidata[] = $res;
    }
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_gongdi');
    
    
    
    
} else if ($model == 'addgongdi') {
    
    
    if (submitcheck('editgongdi')) {
        
        $editdata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['sid']      = intval($_GET['sid']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        $editdata['islook']   = intval($_GET['islook']);
        $editdata['fangan']   = strip_tags($_GET['fangan']);
        $editdata['content1'] = dhtmlspecialchars($_GET['content1']);
        $editdata['content2'] = dhtmlspecialchars($_GET['content2']);
        $editdata['content3'] = dhtmlspecialchars($_GET['content3']);
        $editdata['content4'] = dhtmlspecialchars($_GET['content4']);
        $editdata['content5'] = dhtmlspecialchars($_GET['content5']);
        $editdata['uptime']   = $_G['timestamp'];
        $editdata['status']   = intval($_GET['status']);
        $editdata['xiaoqu']   = intval($_GET['xiaoqu']);

        $result = DB::insert('zimucms_zhuangxiu_gongdi', $editdata);

        if($editdata['sid'] > 0){
            $casenums['gongdinums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_gongdi",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));
        
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];
    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));      
        include template('zimucms_zhuangxiu:Admin_gongdi_edit');
        
    }
    
} else if ($model == 'editgongdi') {
    
    if (submitcheck('editgongdi')) {
        
        $editdata['id']    = intval($_GET['id']);
        $editdata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['sid']      = intval($_GET['sid']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        $editdata['islook']   = intval($_GET['islook']);
        $editdata['fangan']   = strip_tags($_GET['fangan']);
        $editdata['content1'] = dhtmlspecialchars($_GET['content1']);
        $editdata['content2'] = dhtmlspecialchars($_GET['content2']);
        $editdata['content3'] = dhtmlspecialchars($_GET['content3']);
        $editdata['content4'] = dhtmlspecialchars($_GET['content4']);
        $editdata['content5'] = dhtmlspecialchars($_GET['content5']);
        $editdata['uptime']   = $_G['timestamp'];
        $editdata['status']   = intval($_GET['status']);
        $editdata['xiaoqu']   = intval($_GET['xiaoqu']);
        
        $result = DB::update('zimucms_zhuangxiu_gongdi', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['gongdinums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_gongdi",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid     = intval($_GET['editid']);
        $gongdidata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_gongdi',
            $editid
        ));
        $shopdata   = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));
        
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));

        include template('zimucms_zhuangxiu:Admin_gongdi_edit');
        
    }
    
} else if ($model == 'delgongdi' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_gongdi', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
}