<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'news';
}


if ($model == 'news') {


        $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
        
        if (!$newstypedata) {
            $newstypedata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);
        }


    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    $typeid = intval($_GET['typeid']);
if($typeid>0){
$wheresql = ' where typeid = '.$typeid.' ';
}
    $count = DB::result_first("SELECT count(*) FROM %t".$wheresql, array(
        "zimucms_zhuangxiu_news"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $aaa = DB::query('select a.*,b.typename from %t a left join %t b on a.typeid=b.id '.$wheresql.' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_news',
        'zimucms_zhuangxiu_news_type',
        $start,
        $limit
    ));
    
    while ($res = DB::fetch($aaa)) {
        $newsdata[] = $res;
    }
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_news');
    
    
} else if ($model == 'addnews') {
    
    
    if (submitcheck('editnews')) {
        
        $editdata['title']    = strip_tags($_GET['title']);
        $editdata['keywords'] = strip_tags($_GET['keywords']);
        $editdata['desc']     = strip_tags($_GET['desc']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['typeid']  = intval($_GET['typeid']);
        $editdata['istop']   = intval($_GET['istop']);
        $editdata['typeurl'] = DB::result_first('select typeurl from %t where id=%d', array(
            'zimucms_zhuangxiu_news_type',
            $editdata['typeid']
        ));
        $editdata['content'] = dhtmlspecialchars($_GET['content']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        $editdata['status']  = intval($_GET['status']);

        $result = DB::insert('zimucms_zhuangxiu_news', $editdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
        
        if (!$newstypedata) {
            $newstypedata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);
        }
        
        include template('zimucms_zhuangxiu:Admin_news_edit');
        
    }
    
    
    //�༭����
} else if ($model == 'editnews') {
    
    if (submitcheck('editnews')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        $editdata['keywords'] = strip_tags(zm_diconv($_GET['keywords']));
        $editdata['desc']     = strip_tags(zm_diconv($_GET['desc']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['typeid']  = intval($_GET['typeid']);
        $editdata['istop']   = intval($_GET['istop']);
        $editdata['typeurl'] = DB::result_first('select typeurl from %t where id=%d', array(
            'zimucms_zhuangxiu_news_type',
            $editdata['typeid']
        ));
        $editdata['content'] = dhtmlspecialchars($_GET['content']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        $editdata['status']  = intval($_GET['status']);
        
        $result = DB::update('zimucms_zhuangxiu_news', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid = intval($_GET['editid']);
        
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_news',
            $editid
        ));
        
        $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
        if (!$newstypedata) {
            $newstypedata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);
        }
        
        include template('zimucms_zhuangxiu:Admin_news_edit');
        
    }
    
    //ɾ������
    
} else if ($model == 'delnews' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_news', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
    
} else if ($model == 'newstype') {
    
    if (submitcheck('editnewstype')) {
        
        $editdata['id']       = intval($_GET['typeid']);
        $editdata['typename'] = strip_tags($_GET['typename']);
        $editdata['typeurl']  = strip_tags($_GET['typeurl']);
        $editdata['sort']     = intval($_GET['sort']);
        $editdata['isindex']     = intval($_GET['isindex']);

        if ($editdata['id'] > 0) {
            $result = DB::update('zimucms_zhuangxiu_news_type', $editdata, array(
                'id' => $editdata['id']
            ));
        } else {
            $result = DB::insert('zimucms_zhuangxiu_news_type', $editdata);
        }
        
        if ($result) {
            
            $newstypedata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);

            $indexnewstypedata = DB::fetch_all('select * from %t where isindex=1 order by sort asc,id asc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type_daohang', $indexnewstypedata);
            
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=newstype';
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
        if (!$newstypedata) {
            $newstypedata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
                'zimucms_zhuangxiu_news_type'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);
        }
        
        include template('zimucms_zhuangxiu:Admin_news_type');
        
    }
    
    
} else if ($model == 'delnewstype' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_news_type', array(
        'id' => $delid
    ));
    if ($result) {
        
        $newstypedata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
            'zimucms_zhuangxiu_news_type'
        ));
        zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type', $newstypedata);

        $indexnewstypedata = DB::fetch_all('select * from %t where isindex=1 order by sort asc,id asc', array(
            'zimucms_zhuangxiu_news_type'
        ));
        zimu_writetocache('table_plugin_zimucms_zhuangxiu_news_type_daohang', $indexnewstypedata);

        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=newstype';
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
    
    //��������
}