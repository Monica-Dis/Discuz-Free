<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'news';
}


if ($model == 'news') {


    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t".$wheresql, array(
        "zimucms_zhuangxiu_buildingcase"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $aaa = DB::query('select a.*,b.name from %t a left join %t b on a.bid=b.id order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_buildingcase',
        'zimucms_zhuangxiu_building',
        $start,
        $limit
    ));
    
    while ($res = DB::fetch($aaa)) {
        $newsdata[] = $res;
    }
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_buildingcase');
    
    
} else if ($model == 'addnews') {
    
    
    if (submitcheck('editnews')) {
        
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['bid']  = intval($_GET['bid']);
        $editdata['con'] = dhtmlspecialchars($_GET['con']);
        $editdata['addtime'] = strtotime($_GET['addtime']);

        $result = DB::insert('zimucms_zhuangxiu_buildingcase', $editdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {

        $buildingdata = DB::fetch_all("SELECT * FROM %t ORDER BY id desc", array(
            "zimucms_zhuangxiu_building"
        ));

        include template('zimucms_zhuangxiu:Admin_buildingcase_edit');
        
    }
    
    
    //�༭����
} else if ($model == 'editnews') {
    
    if (submitcheck('editnews')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['bid']  = intval($_GET['bid']);
        $editdata['con'] = dhtmlspecialchars($_GET['con']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        
        $result = DB::update('zimucms_zhuangxiu_buildingcase', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid = intval($_GET['editid']);
        
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_buildingcase',
            $editid
        ));
        
        $buildingdata = DB::fetch_all("SELECT * FROM %t ORDER BY id desc", array(
            "zimucms_zhuangxiu_building"
        ));
        
        include template('zimucms_zhuangxiu:Admin_buildingcase_edit');
        
    }
    
} else if ($model == 'delnews' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_buildingcase', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
    
}