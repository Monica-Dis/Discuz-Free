<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}


$langfile = DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimucms_zhuangxiu');

include $includefile;

define('ZIMUCMS_ROOT', dirname(__FILE__));
define('SITE_URL', $_G['siteurl']);
$SELF = $_SERVER["PHP_SELF"];
$zimucms_zhuangxiu = $_G['cache']['plugin']['zimucms_zhuangxiu'];
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/function.php';

function zm_saveimages($FILES, $type = 'zimucms')
{
    loadcache('plugin');
    global $_G;

$zmdata = $_G['cache']['plugin']['zimucms_zhuangxiu'];

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();
    
    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];

    if($upload->attach['imageinfo'][0]>1500 ||$upload->attach['imageinfo'][1]>1500 ) {
        if($upload->attach['imageinfo'][0]>=$upload->attach['imageinfo'][1]){
            $thumb_width = $upload->attach['imageinfo'][0]/2;
        }else{
            $thumb_width = $upload->attach['imageinfo'][1]/2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2 = $image->Thumb($upload->attach['target'], '',$thumb_width,$thumb_width,2);
    }

    if($zmdata['ACCESS_ID'] && $zmdata['ACCESS_KEY'] && $zmdata['ENDPOINT'] && $zmdata['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimucms_zhuangxiu/uploadzimucms/'.$pic;
        include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimucms_zhuangxiu/'.$pic, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }

    if ($pic2) {
        return '/source/plugin/zimucms_zhuangxiu/uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return '/source/plugin/zimucms_zhuangxiu/uploadzimucms/' . $pic;
    }
}


    function get_tag_pars($par,$value){
        if(is_int($par)){
            $where = "id='{$par}'";
        }else{
            $where = "ename='{$par}'";
        }
        $str = DB::fetch_first('select * from %t where '.$where,array('zimucms_zhuangxiu_parameter'));
        $arrtemp = explode(',',$str['value']);
        if(strpos($value,',')){
            $value2 = explode(',',$value);
            foreach($value2 as $vals){
                $val[] = $arrtemp[$vals-1];
            }
            $val = join(' ',$val);
        }else{
            $val = $arrtemp[$value-1];
        }
        return $val;
    }


    function zm_diconv($str)
    {
        global $_G;
        $encode = mb_detect_encoding($str, array(
            "UTF-8",
            "GB2312",
            "GBK",
            ));
        
        if ($encode != strtoupper(CHARSET) ) {
            $keytitle = mb_convert_encoding($str,strtoupper(CHARSET), $encode);
        }

        $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['cache']['plugin']['zimucms_zhuangxiu']['zimu_luanma'] = trim($_G['cache']['plugin']['zimucms_zhuangxiu']['zimu_luanma'])), '/')) . ')$/i';
        if ($_G['cache']['plugin']['zimucms_zhuangxiu']['zimu_luanma'] && @preg_match($censorexp,$keytitle)) {
            $keytitle = $str;
        }
        if (!$keytitle) {
            $keytitle = $str;
        }
        return $keytitle;
    }

function zimu_writetocache($key = 'table_plugin_zimucms_zhuangxiu', $array = array()){

if(strpos($key,'table_plugin_zimucms_zhuangxiu')<0){
echo 'no files allow write';exit();
}

    $datas = $array;
    $cachedata = " return " . var_export($datas, TRUE) . ";";

    global $_G;

    $dir = DISCUZ_ROOT . "./data/sysdata/";
    if (!is_dir($dir)) {
        dmkdir($dir, 0777);
    }
    $file = "$dir/$key.php";
    if ($fp = @fopen($file, 'wb')) {
        fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($key . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n$cachedata?>");
        fclose($fp);
    } else {
        exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
    }
}

function zimu_readfromcache($key = 'table_plugin_zimucms_zhuangxiu'){

if(strpos($key,'table_plugin_zimucms_zhuangxiu')<0){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}

function zimu_deletefromcache($key = 'table_plugin_zimucms_zhuangxiu'){

if(strpos($key,'table_plugin_zimucms_zhuangxiu')<0){
echo 'no files allow write';exit();
}

    $cache_file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if(is_file($cache_file)){
        @unlink($cache_file);
    }
    return TRUE;
}

function time2string($second){
    $day = floor($second/(3600*24));
    $second = $second%(3600*24);//��ȥ����֮��ʣ���ʱ��
    $hour = floor($second/3600);
    $second = $second%3600;//��ȥ��Сʱ֮��ʣ���ʱ�� 
    $minute = floor($second/60);
    //�����ַ���
    if($day){
    $timetext .= $day.lang('plugin/zimucms_zhuangxiu', 'system_text30');
    }
    if($hour){
    $timetext .= $hour.lang('plugin/zimucms_zhuangxiu', 'system_text31');
    }
    if($minute){
    $timetext .= $minute.lang('plugin/zimucms_zhuangxiu', 'system_text32');
    }
    return $timetext;
}
function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}
function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}


function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if (!$_G['uid']) {

$referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];

            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimucms_zhuangxiu/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $referer . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimucms_zhuangxiu/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $referer . '";
  });
    </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($referer));
                exit();
            }
        }
    }
function savebasepic($post)
{
    if (!file_exists(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"))) {
        mkdir(dirname(__FILE__) . '/uploadzimucms/' . date("Ymd"));
    }
    $picname = '/uploadzimucms/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
    $file    = dirname(__FILE__) . $picname;
    $base64  = base64_decode($post);
    $save    = file_put_contents($file, $base64);
    if ($save) {
        return $picname;
    }
}

function zm_curl($url){
    $retfrom=dfsockopen($url);
    if (!$retfrom) {
        $retfrom=zm_curl_get($url);
    }
    return $retfrom;
}
function zm_curl_get($url){
    if (!function_exists('curl_init')) {
        return file_get_contents($url);
    }
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    if (!curl_exec($ch)) {
        error_log(curl_error($ch));
        $data='';
    }else{
        $data=curl_multi_getcontent($ch);
    }
    curl_close($ch);
    return $data;
}
    function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}
$share_title = $zimucms_zhuangxiu['seo_title'];
$share_desc = $zimucms_zhuangxiu['seo_description'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
$share_thumb = $zimucms_zhuangxiu['share_thumb'];