<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$shopinfo = DB::fetch_first('select * from %t where uid=%d', array(
    'zimucms_zhuangxiu_shop',
    $_G['uid']
));

$buildinginfo = DB::fetch_first('select * from %t where uid=%d', array(
    'zimucms_zhuangxiu_building',
    $_G['uid']
));


$model = addslashes($_GET['model']);

if ($model == 'xiaoguotu') {
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $totail = DB::result_first("SELECT count(*) FROM %t where sid=%d" . $wheresql, array(
        "zimucms_zhuangxiu_tuce",
        $shopinfo['id']
    ));
    include_once("page.class.php");
    
    $number  = 20;
    $my_page = new PageClass($totail, $number, $page, ZIMUCMS_URL . ':User&model=xiaoguotu&page={page}'); //用于动态
    
    $startnum    = $my_page->page_limit;
    $count       = $my_page->myde_size;
    $newsdata    = DB::fetch_all('select * from %t where sid=%d order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_tuce',
        $shopinfo['id'],
        $startnum,
        $count
    ));
    $page_string = $my_page->myde_write();
    
    
    include template('zimucms_zhuangxiu:User_xiaoguotu');
    
    
} else if ($model == 'addxiaoguotu') {
    
    
    if (submitcheck('editxiaoguotu')) {
        
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        $editdata['keywords'] = strip_tags(zm_diconv($_GET['keywords']));
        $editdata['desc']     = strip_tags(zm_diconv($_GET['desc']));
        $editdata['sid']      = intval($shopinfo['id']);
        $editdata['did']      = intval($_GET['did']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        $editdata['status']   = 3;
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['vrurl'] = addslashes($_GET['vrurl']);
        $editdata['content'] = dhtmlspecialchars(zm_diconv($_GET['content']));
        if(!$editdata['thumb']){
          preg_match('/<img.+src=\"?(.+\.(jpg|gif|bmp|bnp|png))\"?.+>/i',$_GET['content'],$match);
          if($match[1]){
            $editdata['thumb'] = $_G['siteurl'].$match[1];
        }
        }
        
        $editdata['tuijian'] = intval($_GET['tuijian']);
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);

        $result = DB::insert('zimucms_zhuangxiu_tuce', $editdata);

        if($editdata['sid'] > 0){
            $casenums['casenums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_tuce",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=xiaoguotu';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $designerdata = DB::fetch_all('select id,name,sid from %t where sid=%d order by id asc', array(
            'zimucms_zhuangxiu_designer',
            $shopinfo['id']
        ));
        
        $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
        
        foreach ($parameterdata as $key => $value) {
            $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
        }
        
        $huxingdata = $parameterdata2['huxing'];
        $fenggedata = $parameterdata2['fengge'];
        $yusuandata = $parameterdata2['yusuan'];
        
    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));

        include template('zimucms_zhuangxiu:User_xiaoguotu_edit');
        
    }
    //编辑新闻
} else if ($model == 'editxiaoguotu') {
    
    if (submitcheck('editxiaoguotu')) {
        
        $editdata['id']       = intval($_GET['editid']);
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        $editdata['keywords'] = strip_tags(zm_diconv($_GET['keywords']));
        $editdata['desc']     = strip_tags(zm_diconv($_GET['desc']));
        $editdata['sid']      = intval($shopinfo['id']);
        $editdata['did']      = intval($_GET['did']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['content'] = dhtmlspecialchars(zm_diconv($_GET['content']));
        $editdata['vrurl'] = addslashes($_GET['vrurl']);
        if(!$editdata['thumb']){
          preg_match('/<img.+src=\"?(.+\.(jpg|gif|bmp|bnp|png))\"?.+>/i',$_GET['content'],$match);
          if($match[1]){
            $editdata['thumb'] = $_G['siteurl'].$match[1];
        }
        }


        $editdata['status']  = 3;
        $editdata['tuijian'] = intval($_GET['tuijian']);
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);

        $result = DB::update('zimucms_zhuangxiu_tuce', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['casenums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_tuce",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=xiaoguotu';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid = intval($_GET['editid']);
        
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_tuce',
            $editid
        ));
        
        $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
        
        foreach ($parameterdata as $key => $value) {
            $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
        }
        
        $huxingdata = $parameterdata2['huxing'];
        $fenggedata = $parameterdata2['fengge'];
        $yusuandata = $parameterdata2['yusuan'];

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));

        $designerdata = DB::fetch_all('select id,name,sid from %t where sid=%d order by id asc', array(
            'zimucms_zhuangxiu_designer',
            $shopinfo['id']
        ));
        
        include template('zimucms_zhuangxiu:User_xiaoguotu_edit');
        
    }
    
} else if ($model == 'gongdi') {
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $totail = DB::result_first("SELECT count(*) FROM %t where sid=%d" . $wheresql, array(
        "zimucms_zhuangxiu_gongdi",
        $shopinfo['id']
    ));
    include_once("page.class.php");
    
    $number  = 20;
    $my_page = new PageClass($totail, $number, $page, '/plugin.php?id=zimucms_zhuangxiu:User&model=gongdi&page={page}'); //用于动态
    
    $startnum    = $my_page->page_limit;
    $count       = $my_page->myde_size;
    $gongdidata  = DB::fetch_all('select * from %t where sid=%d order by uptime desc limit %d,%d', array(
        'zimucms_zhuangxiu_gongdi',
        $shopinfo['id'],
        $startnum,
        $count
    ));
    $page_string = $my_page->myde_write();
    
    include template('zimucms_zhuangxiu:User_gongdi');
    
    
    
    
} else if ($model == 'addgongdi') {
    
    
    if (submitcheck('editgongdi')) {
        
        
        $editdata['title'] = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['sid']      = intval($shopinfo['id']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        $editdata['islook']   = intval($_GET['islook']);
        $editdata['fangan']   = strip_tags(zm_diconv($_GET['fangan']));
        $editdata['content1'] = dhtmlspecialchars(zm_diconv($_GET['content1']));
        $editdata['content2'] = dhtmlspecialchars(zm_diconv($_GET['content2']));
        $editdata['content3'] = dhtmlspecialchars(zm_diconv($_GET['content3']));
        $editdata['content4'] = dhtmlspecialchars(zm_diconv($_GET['content4']));
        $editdata['content5'] = dhtmlspecialchars(zm_diconv($_GET['content5']));
        $editdata['uptime']   = $_G['timestamp'];
        $editdata['status']   = 3;
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);

        $result = DB::insert('zimucms_zhuangxiu_gongdi', $editdata);

        if($editdata['sid'] > 0){
            $casenums['gongdinums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_gongdi",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=gongdi';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        
        $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
        
        foreach ($parameterdata as $key => $value) {
            $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
        }
        
        $huxingdata = $parameterdata2['huxing'];
        $fenggedata = $parameterdata2['fengge'];
        $yusuandata = $parameterdata2['yusuan'];
        
    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));

        include template('zimucms_zhuangxiu:User_gongdi_edit');
        
    }
    
} else if ($model == 'editgongdi') {
    
    if (submitcheck('editgongdi')) {
        
        $editdata['id']    = intval($_GET['editid']);
        $editdata['title'] = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['sid']      = intval($shopinfo['id']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        $editdata['islook']   = intval($_GET['islook']);
        $editdata['fangan']   = strip_tags(zm_diconv($_GET['fangan']));
        $editdata['content1'] = dhtmlspecialchars(zm_diconv($_GET['content1']));
        $editdata['content2'] = dhtmlspecialchars(zm_diconv($_GET['content2']));
        $editdata['content3'] = dhtmlspecialchars(zm_diconv($_GET['content3']));
        $editdata['content4'] = dhtmlspecialchars(zm_diconv($_GET['content4']));
        $editdata['content5'] = dhtmlspecialchars(zm_diconv($_GET['content5']));
        $editdata['uptime']   = $_G['timestamp'];
        $editdata['status']   = 3;
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);
        
        $result = DB::update('zimucms_zhuangxiu_gongdi', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['gongdinums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_gongdi",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=gongdi';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid     = intval($_GET['editid']);
        $gongdidata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_gongdi',
            $editid
        ));
        
        $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
        
        foreach ($parameterdata as $key => $value) {
            $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
        }
        
        $huxingdata = $parameterdata2['huxing'];
        $fenggedata = $parameterdata2['fengge'];
        $yusuandata = $parameterdata2['yusuan'];

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));
    
        include template('zimucms_zhuangxiu:User_gongdi_edit');
        
    }
    
} else if ($model == 'designer') {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $totail = DB::result_first("SELECT count(*) FROM %t where sid=%d" . $wheresql, array(
        "zimucms_zhuangxiu_designer",
        $shopinfo['id']
    ));
    include_once("page.class.php");
    
    $number  = 20;
    $my_page = new PageClass($totail, $number, $page, '/plugin.php?id=zimucms_zhuangxiu:User&model=designer&page={page}'); //用于动态
    
    $startnum    = $my_page->page_limit;
    $count       = $my_page->myde_size;
    $newsdata    = DB::fetch_all('select * from %t where sid=%d order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_designer',
        $shopinfo['id'],
        $startnum,
        $count
    ));
    $page_string = $my_page->myde_write();
    
    include template('zimucms_zhuangxiu:User_designer');
    
} else if ($model == 'adddesigner') {
    
    
    if (submitcheck('editnews')) {
        
        $editdata['name'] = strip_tags(zm_diconv($_GET['name']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['touxiang'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['zhicheng'] = strip_tags(zm_diconv($_GET['zhicheng']));
        $editdata['linian']   = strip_tags(zm_diconv($_GET['linian']));
        $editdata['jianjie']  = strip_tags(zm_diconv($_GET['jianjie']));
        $editdata['sid']      = intval($shopinfo['id']);
        
        $result = DB::insert('zimucms_zhuangxiu_designer', $editdata);

        if($editdata['sid'] > 0){
            $casenums['designernums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d", array(
                "zimucms_zhuangxiu_designer",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=designer';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        include template('zimucms_zhuangxiu:User_designer_edit');
        
    }
    
} else if ($model == 'editdesigner') {
    
    if (submitcheck('editnews')) {
        
        $editdata['id']   = intval($_GET['editid']);
        $editdata['name'] = strip_tags(zm_diconv($_GET['name']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['touxiang'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['zhicheng'] = strip_tags(zm_diconv($_GET['zhicheng']));
        $editdata['linian']   = strip_tags(zm_diconv($_GET['linian']));
        $editdata['jianjie']  = strip_tags(zm_diconv($_GET['jianjie']));
        $editdata['sid']      = intval($shopinfo['id']);
           
        $result = DB::update('zimucms_zhuangxiu_designer', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['designernums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d", array(
                "zimucms_zhuangxiu_designer",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=designer';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid   = intval($_GET['editid']);
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_designer',
            $editid
        ));
        
        include template('zimucms_zhuangxiu:User_designer_edit');
        
    }

} else if ($model == 'yuyue') {


    if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {
        
        $editdata['id']     = intval($_GET['yuyueid']);
        $editdata['beizhu'] = strip_tags($_GET['beizhu']);
        
        if ($_GET['edityuyue2']) {
            $editdata['status'] = 2;
        } else if ($_GET['edityuyue3']) {
            $editdata['status'] = 3;
        } else if ($_GET['edityuyue4']) {
            $editdata['status'] = 4;
        }
        
        if ($editdata['id'] > 0) {
            $result = DB::update('zimucms_zhuangxiu_yuyue', $editdata, array(
                'id' => $editdata['id']
            ));
        } else {
            $editdata['name']    = strip_tags($_GET['name']);
            $editdata['phone']   = strip_tags($_GET['phone']);
            $editdata['content'] = strip_tags($_GET['content']);
            $editdata['addtime'] = $_G['timestamp'];
            $result              = DB::insert('zimucms_zhuangxiu_yuyue', $editdata);
        }
        
        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=yuyue';
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
    } else {

        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);

        if($shopinfo){        
            $wheresql = ' where type=1 and sid='.$shopinfo['id'].' and status=' . $status;
        }else if($buildinginfo){ 
            $wheresql = ' where type=2 and sid='.$buildinginfo['id'].' and status=' . $status;
        }else{
            $wheresql = ' where type=1 and sid='.$shopinfo['id'].' and status=' . $status;
        }      

        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimucms_zhuangxiu_yuyue"
        ));
        
        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);
        
        
        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimucms_zhuangxiu_yuyue',
            $start,
            $limit
        ));
        
        if ($page_num > 1) {
            $multipage = multi($count, $limit, $page, '/plugin.php?id=zimucms_zhuangxiu:User&model=yuyue&status='.$status.'&page={page}', '10000', '30', TRUE, TRUE);
        }
        
        include template('zimucms_zhuangxiu:User_yuyue');
        
    }
    
} else if ($model == 'shopinfo') {


    if (submitcheck('editshop')) {
        
        $editdata['id']   = $shopinfo['id'];
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);

        $result = DB::update('zimucms_zhuangxiu_shop', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=shopinfo';
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        

        $shopdata = $shopinfo;
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }

        include template('zimucms_zhuangxiu:User_shopinfo');    
       
    }

} else if ($model == 'buildinginfo') {


    if (submitcheck('editbuilding')) {
        
        $editdata['id']   = $buildinginfo['id'];
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);
        $editdata['buildingtype']     = intval($_GET['buildingtype']);
        $editdata['contentname1'] = strip_tags($_GET['contentname1']);
        $editdata['contentval1'] = dhtmlspecialchars($_GET['contentval1']);
        $editdata['contentname2'] = strip_tags($_GET['contentname2']);
        $editdata['contentval2'] = dhtmlspecialchars($_GET['contentval2']);
        $editdata['contentname3'] = strip_tags($_GET['contentname3']);
        $editdata['contentval3'] = dhtmlspecialchars($_GET['contentval3']);
        $editdata['contentname4'] = strip_tags($_GET['contentname4']);
        $editdata['contentval4'] = dhtmlspecialchars($_GET['contentval4']);

        
        $result = DB::update('zimucms_zhuangxiu_building', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=buildinginfo';;
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $shopdata = $buildinginfo;
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $buildingtypedata = $parameterdata2['buildingtype'];
        include template('zimucms_zhuangxiu:User_buildinginfo');
        
        
    }

} else if ($model == 'buildingcase') {

    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $totail = DB::result_first("SELECT count(*) FROM %t where bid=%d" . $wheresql, array(
        "zimucms_zhuangxiu_buildingcase",
        $buildinginfo['id']
    ));
    include_once("page.class.php");
    
    $number  = 20;
    $my_page = new PageClass($totail, $number, $page, ZIMUCMS_URL . ':User&model=buildingcase&page={page}'); //用于动态
    
    $startnum    = $my_page->page_limit;
    $count       = $my_page->myde_size;
    $newsdata    = DB::fetch_all('select * from %t where bid=%d order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_buildingcase',
        $buildinginfo['id'],
        $startnum,
        $count
    ));
    
    while ($res = DB::fetch($aaa)) {
        $newsdata[] = $res;
    }

    $page_string = $my_page->myde_write();
    
    
    include template('zimucms_zhuangxiu:User_buildingcase');

} else if ($model == 'editbuildingcase') {

    if (submitcheck('editbuildingcase')) {
        
        $editdata['id']       = intval($_GET['editid']);
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['bid']  = intval($buildinginfo['id']);
        $editdata['con'] = dhtmlspecialchars($_GET['con']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        
        $result = DB::update('zimucms_zhuangxiu_buildingcase', $editdata, array(
            'id' => $editdata['id'],
            'bid' => $buildinginfo['id']
        ));

        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=buildingcase';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $editid = intval($_GET['editid']);
        
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_buildingcase',
            $editid
        ));
        
        include template('zimucms_zhuangxiu:User_buildingcase_edit');

    }

} else if ($model == 'addbuildingcase') {

    if (submitcheck('editbuildingcase')) {
        
        $editdata['title']    = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['bid']  = intval($buildinginfo['id']);
        $editdata['con'] = dhtmlspecialchars($_GET['con']);
        $editdata['addtime'] = strtotime($_GET['addtime']);

        $result = DB::insert('zimucms_zhuangxiu_buildingcase', $editdata);
        
        if ($result) {
            $url = ZIMUCMS_URL . ':User&model=buildingcase';
            //修改成功
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            //修改失败
            showmessage(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {

        include template('zimucms_zhuangxiu:User_buildingcase_edit');
        
    }

}