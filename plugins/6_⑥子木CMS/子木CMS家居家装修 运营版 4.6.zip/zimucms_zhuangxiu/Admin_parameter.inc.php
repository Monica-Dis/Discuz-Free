<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'parameter';
}

if ($model == 'parameter') {
    
    if (submitcheck('editparameter')) {
        
        $editdata['id']    = intval($_GET['parameterid']);
        $editdata['name']  = strip_tags($_GET['parametername']);
        $editdata['ename'] = strip_tags($_GET['ename']);
        $editdata['value'] = strip_tags($_GET['value']);

        if ($editdata['id'] > 0) {
            $result = DB::update('zimucms_zhuangxiu_parameter', $editdata, array(
                'id' => $editdata['id']
            ));
        } else {
            $result = DB::insert('zimucms_zhuangxiu_parameter', $editdata);
        }
        if ($result) {
            
            $parameterdata = DB::fetch_all('select * from %t order by id desc', array(
                'zimucms_zhuangxiu_parameter'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_parameter', $parameterdata);
            
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

        if (!$parameterdata) {
            $parameterdata = DB::fetch_all('select * from %t order by id desc', array(
                'zimucms_zhuangxiu_parameter'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_parameter', $parameterdata);
        }

        include template('zimucms_zhuangxiu:Admin_parameter');
        
    }
    
    
} else if ($model == 'delparameter' && $_GET['md5formhash'] == formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_parameter', array(
        'id' => $delid
    ));
    if ($result) {
        $parameterdata = DB::fetch_all('select * from %t order by id desc', array(
            'zimucms_zhuangxiu_parameter'
        ));
        zimu_writetocache('table_plugin_zimucms_zhuangxiu_parameter', $parameterdata);
        
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
    
    //ԤԼ����
}