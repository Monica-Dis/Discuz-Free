<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    $qid = intval($_GET['qid']);

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $xiaoqudata   = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_xiaoqu',
        $qid
    ));

    $tucedata   = DB::fetch_all('select * from %t where xiaoqu=%d and status=1 order by id desc', array(
        'zimucms_zhuangxiu_tuce',
        $qid
    ));

    if(!$ZIMUCMS_MYUSER){exit();}
    $gongdidata = DB::fetch_all('select * from %t where xiaoqu=%d and status=1 order by id desc', array(
        'zimucms_zhuangxiu_gongdi',
        $qid
    ));


    DB::query("update %t set views=views+1 where id=%d", array(
        'zimucms_zhuangxiu_xiaoqu',
        $qid
    ));

$share_title = $xiaoqudata['name'].' - '.$zimucms_zhuangxiu['site_title'];
$share_desc = $zimucms_zhuangxiu['seo_description'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
if ($xiaoqudata['thumb'] && !preg_match('/^(http|\.)/i', $xiaoqudata['thumb'])) {
   $xiaoqudata['thumb'] = $_G['siteurl'].$xiaoqudata['thumb'];
}
$share_thumb = $xiaoqudata['thumb'] ? $xiaoqudata['thumb'] : $zimucms_zhuangxiu['share_thumb'];


include template('zimucms_zhuangxiu:site_viewxiaoqu');