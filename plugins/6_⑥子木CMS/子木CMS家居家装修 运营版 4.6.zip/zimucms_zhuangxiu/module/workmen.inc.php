<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);

    include_once("page.class.php");

    if(!$ZIMUCMS_MYUSER){exit();}

    $type = intval($_GET['type']);
    $area     = $_GET['area'] = $_GET['area'] ? $_GET['area'] : 0;
    $wid     = $_GET['wid'] = $_GET['wid'] ? $_GET['wid'] : 0;
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;

    $area = intval($area);
    $wid = intval($wid);
    $page = intval($page);

    $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }

    $workmenarray = $parameterdata2['workmen'.$type];

    $wheresql = 'WHERE 1=1 ';
    if ($area > 0) {
        $wheresql .= ' AND quyu = ' . $area;
    }
    if ($type > 0) {
        $wheresql .= ' AND type = ' . $type;
    }
    if ($wid > 0) {
        $wheresql .= ' AND wid = ' . $wid;
    }


       $totail = DB::result_first("SELECT count(*) FROM %t  %i", array(
            "zimucms_zhuangxiu_workmen",
            $wheresql
        ));

    $number = 10;

    $url         = ZIMUCMS_URL . '&model=workmen&type=' . $type . '&wid=' . $wid . '&area=' . $area . '&page={page}';

    $my_page  = new PageClass($totail, $number, $page, $url); //参数设定：总记录，每页显示的条数，当前页，连接的地址
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;

    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }

    $workmendata = DB::fetch_all('select * from %t ' . $wheresql . ' order by sort desc,views desc,id desc limit %d,%d', array(
        'zimucms_zhuangxiu_workmen',
        $startnum,
        $count
    ));

include template('zimucms_zhuangxiu:site_workmen');