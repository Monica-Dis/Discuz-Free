<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('');
}

class PageClass
{
private $myde_count;       //总记录数
public $myde_size;        //每页记录数
private $myde_page;        //当前页
private $myde_page_count; //总页数
private $page_url;         //页面url
private $page_i;           //起始页
private $page_ub;          //结束页
public $page_limit;


function __construct($myde_count=0,$myde_size=1,$myde_page=1,$page_url)   //构造函数,初始化
{  
   $this->myde_count=$this->numeric($myde_count);
   $this->myde_size=$this->numeric($myde_size);
   $this->myde_page=$this->numeric($myde_page);
   $this->page_limit=($this->myde_page * $this -> myde_size) - $this -> myde_size; //下一页的开始记录
   $this->page_url=$page_url; //连接的地址
   if($this->myde_page<1)$this->myde_page=1; //当前页小于1的时候，，值赋值为1
   if($this->myde_count<0)$this->myde_page=0;
   $this->myde_page_count=ceil($this->myde_count/$this->myde_size);//总页数
   if($this->myde_page_count<1)
    $this->myde_page_count=1;
   if($this->myde_page > $this->myde_page_count)
     $this->myde_page = $this->myde_page_count;
  
  
   //控制显示出来多少个页码（这个是原来的）
   //$this->page_i = $this->myde_page-2;
   //$this->page_ub = $this->myde_page+2;


   $this->page_i = $this->myde_page;
   $this->page_ub = $this->myde_page+6;
   //以下这个if语句是保证显示5个页码
   if($this->page_ub > $this->myde_page_count)
   {
    $this->page_ub = $this->myde_page_count;
	$this->page_i = $this->page_ub-6;
   }
  
  
   if($this->page_i<1)$this->page_i=1;       
        if($this->page_ub>$this->myde_page_count){$this->page_ub=$this->myde_page_count; }
}
      private function numeric($id) //判断是否为数字
    {
if (strlen($id))
         {
             if (!preg_match("/([\d])/",$id)) $id = 1;
         }
      else
         {
             $id = 1;
         }
      return $id;
    }


private function page_replace($page) //地址替换
{return str_replace("{page}", $page, $this -> page_url);}


private function myde_home() //首页
{ if($this -> myde_page != 1){
    return "    <a href=\"".$this -> page_replace(1)."\" title=\"".lang('plugin/zimucms_zhuangxiu', 'shouyephp')."\" ><span class=\"pre-page\">".lang('plugin/zimucms_zhuangxiu', 'shouyephp')."</span></a>\n";  
   }else{
    return "    <span class=\"pre-page\">".lang('plugin/zimucms_zhuangxiu', 'shouyephp')."</span>\n";  
   }
}

private function myde_prev() //上一页
{ if($this -> myde_page != 1){
    return "    <a href=\"".$this -> page_replace($this->myde_page-1) ."\" title=\"".lang('plugin/zimucms_zhuangxiu', 'shangyiye')."\" ><span class=\"pre-page\">".lang('plugin/zimucms_zhuangxiu', 'shangyiye')."</span></a>\n";
   }else{
    return "    <span class=\"pre-page\">".lang('plugin/zimucms_zhuangxiu', 'shangyiye')."</span></li>\n";  
   }
}

private function myde_prev_wap() //上一页
{ if($this -> myde_page != 1){
    return "    <a href=\"".$this -> page_replace($this->myde_page-1) ."\" >".lang('plugin/zimucms_zhuangxiu', 'shangyiye')."</a>\n";
   }else{
    return "    <a class=\"disabled\">".lang('plugin/zimucms_zhuangxiu', 'shangyiye')."</a>\n";  
   }
}

private function myde_next() //下一页
{
if($this -> myde_page != $this -> myde_page_count){
     return "    <a href=\"".$this -> page_replace($this->myde_page+1) ."\" title=\"".lang('plugin/zimucms_zhuangxiu', 'xiayiye')."\" ><span class=\"next-page\">".lang('plugin/zimucms_zhuangxiu', 'xiayiye')."</span></a>\n";
   }else
     {
    return "    <span class=\"next-page\">".lang('plugin/zimucms_zhuangxiu', 'xiayiye')."</span></li>\n";  
   }
}

private function myde_next_wap() //下一页
{
if($this -> myde_page != $this -> myde_page_count){
     return "    <a href=\"".$this -> page_replace($this->myde_page+1) ."\" >".lang('plugin/zimucms_zhuangxiu', 'xiayiye')."</a>\n";
   }else
     {
    return "    <a class=\"disabled\">".lang('plugin/zimucms_zhuangxiu', 'xiayiye')."</a>\n";  
   }
}


private function myde_middle_wap()
{
    return "    <span>".$this -> myde_page." / ".$this -> myde_page_count."</span>\n";  
}

private function myde_last() //尾页
{
   if($this -> myde_page != $this -> myde_page_count){
     return "    <a href=\"".$this -> page_replace($this -> myde_page_count)."\" title=\"".lang('plugin/zimucms_zhuangxiu', 'moye')."\" ><span class=\"next-page\">".lang('plugin/zimucms_zhuangxiu', 'moye')."</span></a>\n";
   }else{
     return "    <span class=\"next-page\">".lang('plugin/zimucms_zhuangxiu', 'moye')."</span>\n";  
   }
}

function myde_write($id='page') //输出
{
   $str = $this -> myde_home(); //调用方法，显示“首页”
   $str .= $this -> myde_prev(); //调用方法，显示“上一页”

   //以下显示1,2,3...分页
   for($page_for_i=$this->page_i;$page_for_i <= $this -> page_ub;$page_for_i++){
    if($this -> myde_page == $page_for_i){  
            $str .= "<span class=\" currents\">".$page_for_i."</span>\n";   
    }  
    else{  
     $str .= "<a href=\"".$this -> page_replace($page_for_i)."\"><span>";   
     $str .= $page_for_i . "</span></a>\n";   
    }
        }
   $str .= $this -> myde_next(); //调用方法，显示“下一页”
   $str .= $this -> myde_last(); //调用方法，显示“尾页”

    //以下是显示跳转页框
   return $str;
}


function myde_write_wap($id='page') //输出
{
   $str = $this -> myde_prev_wap(); //调用方法，显示“上一页”
   $str .= $this -> myde_middle_wap(); 
   $str .= $this -> myde_next_wap(); //调用方法，显示“下一页”

    //以下是显示跳转页框
   return $str;
}


}