<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);

    include_once("page.class.php");

    if(!$ZIMUCMS_MYUSER){exit();}

    $huxing     = $_GET['huxing'] = $_GET['huxing'] ? $_GET['huxing'] : 0;
    $fengge     = $_GET['fengge'] = $_GET['fengge'] ? $_GET['fengge'] : 0;
    $yusuan     = $_GET['yusuan'] = $_GET['yusuan'] ? $_GET['yusuan'] : 0;
    $fangshi     = $_GET['fangshi'] = $_GET['fangshi'] ? $_GET['fangshi'] : 0;
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;

    $order = intval($order);
    $huxing = intval($huxing);
    $fengge = intval($fengge);
    $yusuan = intval($yusuan);
    $fangshi = intval($fangshi);
    $page = intval($page);

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];
    $fangshidata = $parameterdata2['fangshi'];

    $wheresql = 'WHERE 1=1 ';
    if ($huxing > 0) {
        $wheresql .= ' AND huxing = ' . $huxing;
    }
    if ($fengge > 0) {
        $wheresql .= ' AND fengge = ' . $fengge;
    }
    if ($yusuan > 0) {
        $wheresql .= ' AND yusuan = ' . $yusuan;
    }
    if ($fangshi > 0) {
        $wheresql .= ' AND fangshi = ' . $fangshi;
    }


       $totail = DB::result_first("SELECT count(*) FROM %t  %i", array(
            "zimucms_zhuangxiu_daily",
            $wheresql
        ));

    $number = 10;

    $url         = ZIMUCMS_URL . '&model=daily&fangshi=' . $fangshi . '&huxing=' . $huxing . '&fengge=' . $fengge . '&yusuan=' . $yusuan . '&page={page}';

    $my_page  = new PageClass($totail, $number, $page, $url); //参数设定：总记录，每页显示的条数，当前页，连接的地址
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;

    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }

    $dailydata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_daily',
        $startnum,
        $count
    ));

$randdailydata = DB::fetch_all('select * from %t order by rand() limit 5',array('zimucms_zhuangxiu_daily'));

include template('zimucms_zhuangxiu:site_daily');