<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);

    include_once("page.class.php");

    $area  = $_GET['area'] = $_GET['area'] ? $_GET['area'] : 0;
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $area  = intval($area);
    $page  = intval($page);

    if(!$ZIMUCMS_MYUSER){exit();}
    $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');


    if ($area > 0) {
        $totail = DB::result_first("SELECT count(*) FROM %t WHERE quyu=%d", array(
            "zimucms_zhuangxiu_xiaoqu",
            $area
        ));
    } else {
       $totail = DB::result_first("SELECT count(*) FROM %t", array(
            "zimucms_zhuangxiu_xiaoqu"
        ));
    }
    $number = 10;

    $url = ZIMUCMS_URL . '&model=xiaoqu&area=' . $area . '&page={page}';

    $my_page  = new PageClass($totail, $number, $page, $url); //参数设定：总记录，每页显示的条数，当前页，连接的地址
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;

    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }

    if ($area > 0) {
        $xiaoqudata = DB::fetch_all('select * from %t where quyu=%d %i limit %d,%d', array(
            'zimucms_zhuangxiu_xiaoqu',
            $area,
            'order by sort desc,id desc',
            $startnum,
            $count
        ));
    } else {
        $xiaoqudata = DB::fetch_all('select * from %t %i limit %d,%d', array(
            'zimucms_zhuangxiu_xiaoqu',
            'order by sort desc,id desc',
            $startnum,
            $count
        ));
    }

    foreach ($xiaoqudata as $key => $value) {
    	$xiaoqudata[$key]['caselist'] = DB::fetch_all("SELECT * FROM %t WHERE xiaoqu=%d AND status=1", array(
    		"zimucms_zhuangxiu_tuce",
    		$value['id']
    	));
    	$xiaoqudata[$key]['gongdilist'] = DB::fetch_all("SELECT * FROM %t WHERE xiaoqu=%d AND status=1", array(
    		"zimucms_zhuangxiu_gongdi",
    		$value['id']
    	));
    }

$share_title = $language_zimu['site_header_htm_0'].' - '.$zimucms_zhuangxiu['site_title'];
$share_desc = $zimucms_zhuangxiu['seo_description'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
if ($casedata['thumb'] && !preg_match('/^(http|\.)/i', $casedata['thumb'])) {
   $casedata['thumb'] = $_G['siteurl'].$casedata['thumb'];
}
$share_thumb = $casedata['thumb'] ? $casedata['thumb'] : $zimucms_zhuangxiu['share_thumb'];

include template('zimucms_zhuangxiu:site_xiaoqu');