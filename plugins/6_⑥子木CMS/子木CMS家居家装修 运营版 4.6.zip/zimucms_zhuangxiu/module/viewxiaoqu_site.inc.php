<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    $qid = intval($_GET['qid']);

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $xiaoqudata   = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_xiaoqu',
        $qid
    ));

    if(!$ZIMUCMS_MYUSER){exit();}
    include_once("page.class.php");
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page        = intval($_GET['page']);
    $totail = DB::result_first("SELECT count(*) FROM %t WHERE xiaoqu=%d AND status=1", array(
        "zimucms_zhuangxiu_gongdi",
        $qid
    ));
    $number      = 10;
    $url = ZIMUCMS_URL . '&model=viewxiaoqu_site&qid=' . $qid . '&page={page}';
    $my_page     = new PageClass($totail, $number, $page, $url); //参数设定：总记录，每页显示的条数，当前页，连接的地址
    $startnum    = $my_page->page_limit;
    $count       = $my_page->myde_size;
    $gongdidata  = DB::fetch_all('select * from %t where xiaoqu=%d and status=1 order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_gongdi',
        $qid,
        $startnum,
        $count
    ));
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimucms_zhuangxiu_xiaoqu',
        $qid
    ));
$share_title = $xiaoqudata['name'].$language_zimu['site_viewxiaoqu_htm_6'].' - '.$zimucms_zhuangxiu['site_title'];
$share_desc = $zimucms_zhuangxiu['seo_description'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
if ($xiaoqudata['thumb'] && !preg_match('/^(http|\.)/i', $xiaoqudata['thumb'])) {
   $xiaoqudata['thumb'] = $_G['siteurl'].$xiaoqudata['thumb'];
}
$share_thumb = $xiaoqudata['thumb'] ? $xiaoqudata['thumb'] : $zimucms_zhuangxiu['share_thumb'];
    
include template('zimucms_zhuangxiu:site_viewxiaoqu_site');