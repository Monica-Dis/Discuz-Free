<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

isuid();

    if (submitcheck('addbaoliao')) {

        $adddata['uid'] = $_G['uid'];
        $adddata['name']    = strip_tags(zm_diconv($_GET['name']));
        $adddata['age'] = intval($_GET['age']);
        $adddata['intro']    = strip_tags(zm_diconv($_GET['intro']));
        $adddata['tel']    = strip_tags(zm_diconv($_GET['tel']));
        $adddata['quyu'] = intval($_GET['quyu']);
        $adddata['type'] = intval($_GET['type']);
        $adddata['wid']   = intval($_GET['wid'.$adddata['type']]);
        $adddata['addtime'] = $_G['timestamp'];

        if (!empty($_GET['fileup'])) {
            foreach ($_GET['fileup'] as $key => $file) {
                if(IN_WECHAT || IN_MAGAPP ){
                    $adddata['thumb'] = $file;
                }else{
                    $file = str_replace('data:image/png;base64,', '', $file);
                    $file = str_replace('data:image/jpeg;base64,', '', $file);
                    $picurl . $key = savebasepic($file);
                    $adddata['thumb'] = 'source/plugin/zimucms_zhuangxiu/'.$picurl . $key;
                }
            }
        }

        if (!empty($_GET['fileup2'])) {
            foreach ($_GET['fileup2'] as $key2 => $file2) {
                if(IN_WECHAT || IN_MAGAPP ){
                    $picontent .= '<p><img src="' . $file2 . '" /></p>';
                }else{
                    $file2 = str_replace('data:image/png;base64,', '', $file2);
                    $file2 = str_replace('data:image/jpeg;base64,', '', $file2);
                    $picurl . $key2 = savebasepic($file2);
                    $picontent .= '<p><img src="source/plugin/zimucms_zhuangxiu/' . $picurl . $key2 . '"/></p>';
                }
            }
        }
        
        $adddata['con'] = $picontent;


        $result = DB::insert('zimucms_zhuangxiu_workmen', $adddata);

dheader('Location:' . ZIMUCMS_URL . '&model=joinworkmen&isok=ok');

    }else{

        $mywork = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimucms_zhuangxiu_workmen',
            $_G['uid']
        ));



if(IN_WECHAT && $zimucms_zhuangxiu['weixin_appid']){
require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zimucms_zhuangxiu['weixin_appid'], $zimucms_zhuangxiu['weixin_appsecret']);
$jssdkvalue    = $wechat_client->getSignPackage();
}

        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }

    $workmen1data = $parameterdata2['workmen1'];
    $workmen2data = $parameterdata2['workmen2'];
    $workmen3data = $parameterdata2['workmen3'];

    

include template('zimucms_zhuangxiu:site_joinworkmen');

    }