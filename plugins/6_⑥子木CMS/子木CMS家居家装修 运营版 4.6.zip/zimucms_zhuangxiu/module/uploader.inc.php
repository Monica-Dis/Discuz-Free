<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$download = addslashes($_GET['download']);
    
    echo $config_params = savepic();

function savepic(){
    global $_G;

$zimucms_zhuangxiu = $_G['cache']['plugin']['zimucms_zhuangxiu'];

    $config_params = array(
        'upload_ok' => false,
        'save_path' => '',
        'show_path' => ''
    );
    $filename      = uniqid() . '.jpg';
    $uid           = $_G['uid'];
    $pic           = base64_decode($_GET['base64_string']);
    
    $date        = date('ym/d/');
    $save_avatar = DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/uploadzimucms/' . $date;

    $sids = $_GET['serverId'];

    if (!is_dir($save_avatar)) {
        mkdir($save_avatar, 0777, true);
    }

    if($sids){

    require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zimucms_zhuangxiu['weixin_appid'], $zimucms_zhuangxiu['weixin_appsecret']);
    $temp = $wechat_client->download($sids);
    if(!empty($temp)) {
            $content = '';
            if (preg_match('/^(http:\/\/|\.)/i', $temp)) {
                $content = zm_curl($temp);
            }else{
                $content = $temp;
            }
                $fp = fopen($save_avatar . $filename, 'wb');
                flock($fp, 2);
                fwrite($fp, $content);
                fclose($fp);
    }


    }else{

    file_put_contents($save_avatar . $filename, $pic);

    }

    if($zimucms_zhuangxiu['ACCESS_ID'] && $zimucms_zhuangxiu['ACCESS_KEY'] && $zimucms_zhuangxiu['ENDPOINT'] && $zimucms_zhuangxiu['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimucms_zhuangxiu/uploadzimucms/' . $date . $filename;
        include_once DISCUZ_ROOT.'source/plugin/zimucms_zhuangxiu/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimucms_zhuangxiu/' . $date . $filename, $saved_file)) {
            @unlink($saved_file);
        $imgurl = $surl;
        return $imgurl;
        exit();
        }
    }

    return '/source/plugin/zimucms_zhuangxiu/uploadzimucms/' . $date . $filename;
    
}