<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    $gid = intval($_GET['gid']);

    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');

    $workmendata   = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_workmen',
        $gid
    ));

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimucms_zhuangxiu_workmen',
        $gid
    ));

$share_title = $workmendata['name'].' '.$workmendata['age'].' '.$language_zimu['site_viewworkmen_htm_0'].' '.get_tag_pars('workmen'.$workmendata['type'],$workmendata['wid']).' '.$zimucms_zhuangxiu['site_title'];
$share_desc = $zimucms_zhuangxiu['seo_description'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
if ($workmendata['thumb'] && !preg_match('/^(http|\.)/i', $workmendata['thumb'])) {
   $workmendata['thumb'] = $_G['siteurl'].$workmendata['thumb'];
}
$share_thumb = $workmendata['thumb'] ? $workmendata['thumb'] : $zimucms_zhuangxiu['share_thumb'];

include template('zimucms_zhuangxiu:site_viewworkmen');