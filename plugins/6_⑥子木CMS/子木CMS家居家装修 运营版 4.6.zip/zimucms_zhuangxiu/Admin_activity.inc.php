<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'activity';
}


if ($model == 'activity') {


    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    $typeid = $_GET['typeid'] = $_GET['typeid'] ? $_GET['typeid'] : 1;

    if($typeid>0){
       $wheresql = ' where typeid = '.$typeid.' ';
    }

    $count = DB::result_first("SELECT count(*) FROM %t".$wheresql, array(
        "zimucms_zhuangxiu_activitylist"
    ));

    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $newsdata = DB::fetch_all('select * from %t '.$wheresql.' order by id desc', array(
        'zimucms_zhuangxiu_activitylist'
    ));


    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }

    include template('zimucms_zhuangxiu:Admin_activity');

} else if ($model == 'addactivity') {

  if (submitcheck('editactivity')) {

      $editdata['title']    = strip_tags($_GET['title']);
      if ($_FILES['shop_thumb']['tmp_name']) {
          $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
      }
      $editdata['typeid']  = intval($_GET['typeid']);
      $editdata['address']    = strip_tags($_GET['address']);
      $editdata['tel']    = strip_tags($_GET['tel']);
      $editdata['stime'] = strtotime($_GET['stime']);
      $editdata['etime'] = strtotime($_GET['etime']);
      $editdata['hstime'] = strtotime($_GET['hstime']);
      $editdata['hetime'] = strtotime($_GET['hetime']);
      $editdata['shoptext']    = strip_tags($_GET['shoptext']);
      $editdata['content'] = dhtmlspecialchars($_GET['content']);
      $editdata['addtime'] = strtotime($_GET['addtime']);
      $editdata['sort']  = intval($_GET['sort']);
      $editdata['status']  = intval($_GET['status']);
      $editdata['bbsurl']    = strip_tags($_GET['bbsurl']);

      $result = DB::insert('zimucms_zhuangxiu_activitylist', $editdata);

      if ($result) {
          $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
          cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
      } else {
          cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
      }


  } else {
        include template('zimucms_zhuangxiu:Admin_activity_edit');
  }

} else if ($model == 'editactivity') {


    if (submitcheck('editactivity')) {

        $editdata['id']       = intval($_GET['id']);
        $editdata['title']    = strip_tags($_GET['title']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['typeid']  = intval($_GET['typeid']);
        $editdata['address']    = strip_tags($_GET['address']);
        $editdata['tel']    = strip_tags($_GET['tel']);
        $editdata['stime'] = strtotime($_GET['stime']);
        $editdata['etime'] = strtotime($_GET['etime']);
        $editdata['hstime'] = strtotime($_GET['hstime']);
        $editdata['hetime'] = strtotime($_GET['hetime']);
        $editdata['shoptext']    = strip_tags($_GET['shoptext']);
        $editdata['content'] = dhtmlspecialchars($_GET['content']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        $editdata['sort']  = intval($_GET['sort']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['bbsurl']    = strip_tags($_GET['bbsurl']);

        $result = DB::update('zimucms_zhuangxiu_activitylist', $editdata, array(
            'id' => $editdata['id']
        ));

        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }


    } else {

        $editid = intval($_GET['editid']);

        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_activitylist',
            $editid
        ));

        include template('zimucms_zhuangxiu:Admin_activity_edit');

    }

} else if ($model == 'viewdata') {

        $aid = intval($_GET['aid']);

  if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {

      $editdata['id']     = intval($_GET['yuyueid']);
      $editdata['beizhu'] = strip_tags($_GET['beizhu']);

      if ($_GET['edityuyue2']) {
          $editdata['status'] = 2;
      } else if ($_GET['edityuyue3']) {
          $editdata['status'] = 3;
      } else if ($_GET['edityuyue4']) {
          $editdata['status'] = 4;
      }

      if ($editdata['id'] > 0) {
          $result = DB::update('zimucms_zhuangxiu_activityuser', $editdata, array(
              'id' => $editdata['id']
          ));
      } else {
          $editdata['name']    = strip_tags($_GET['name']);
          $editdata['phone']   = strip_tags($_GET['phone']);
          $editdata['addtime'] = $_G['timestamp'];
          $result              = DB::insert('zimucms_zhuangxiu_activityuser', $editdata);
      }

      if ($result) {
          $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model='.$model.'&aid='.$aid.'&status=' . $editdata['status'];
          cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
      } else {
          cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
      }

  } else {

        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);

        $wheresql = ' where status=' . $status;

        if($aid){
            $wheresql .= ' and aid=' . $aid;
        }

        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimucms_zhuangxiu_activityuser"
        ));

        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);


        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimucms_zhuangxiu_activityuser',
            $start,
            $limit
        ));

        if ($page_num > 1) {
            $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model='.$model.'&aid='.$aid.'&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
        }

        include template('zimucms_zhuangxiu:Admin_activity_viewdata');

        }

      } else if ($model == 'delviewdata' && $_GET['md5formhash'] = formhash()) {

          $delid  = intval($_GET['delid']);
          $result = DB::delete('zimucms_zhuangxiu_activityuser', array(
              'id' => $delid
          ));
          if ($result) {
              $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model='.$model.'&aid='.$aid.'&page=' . intval($_GET['page']);
              cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
          } else {
              cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
          }

} else if ($model == 'delactivity' && $_GET['md5formhash'] = formhash()) {

    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_activitylist', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&status=' . $status;
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}
