<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'designer';
}


if ($model == 'designer') {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_zhuangxiu_designer"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $aaa = DB::query('select a.*,b.name as shopname from %t a left join %t b on a.sid=b.id order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_designer',
        'zimucms_zhuangxiu_shop',
        $start,
        $limit
    ));
    
    while ($res = DB::fetch($aaa)) {
        $newsdata[] = $res;
    }
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_designer');
    
    
} else if ($model == 'adddesigner') {
    
    
    if (submitcheck('editnews')) {
        
        $editdata['name']    = strip_tags($_GET['name']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['touxiang'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['zhicheng'] = strip_tags($_GET['zhicheng']);
        $editdata['linian']     = strip_tags($_GET['linian']);
        $editdata['jianjie']     = strip_tags($_GET['jianjie']);
        $editdata['sid']  = intval($_GET['sid']);
        $editdata['indexsort']   = intval($_GET['indexsort']);

        $result = DB::insert('zimucms_zhuangxiu_designer', $editdata);

        if($editdata['sid'] > 0){
            $casenums['designernums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d", array(
                "zimucms_zhuangxiu_designer",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }

        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {

        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));
        
        include template('zimucms_zhuangxiu:Admin_designer_edit');
        
    }
    
    
    //�༭����
} else if ($model == 'editdesigner') {
    
    if (submitcheck('editnews')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['name']    = strip_tags($_GET['name']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['touxiang'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['zhicheng'] = strip_tags($_GET['zhicheng']);
        $editdata['linian']     = strip_tags($_GET['linian']);
        $editdata['jianjie']     = strip_tags($_GET['jianjie']);
        $editdata['sid']  = intval($_GET['sid']);
        $editdata['indexsort']   = intval($_GET['indexsort']);
        
        $result = DB::update('zimucms_zhuangxiu_designer', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['designernums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d", array(
                "zimucms_zhuangxiu_designer",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid = intval($_GET['editid']);
        
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_designer',
            $editid
        ));

        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));

        include template('zimucms_zhuangxiu:Admin_designer_edit');
        
    }
    
    //ɾ������
    
} else if ($model == 'deldesigner' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_designer', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
    
}