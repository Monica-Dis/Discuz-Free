<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';
$model = addslashes($_GET['model']);


    $order      = $_GET['order'] = $_GET['order'] ? $_GET['order'] : 1;
    $huxing     = $_GET['huxing'] = $_GET['huxing'] ? $_GET['huxing'] : 0;
    $fengge     = $_GET['fengge'] = $_GET['fengge'] ? $_GET['fengge'] : 0;
    $yusuan     = $_GET['yusuan'] = $_GET['yusuan'] ? $_GET['yusuan'] : 0;
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;

    $order = intval($order);
    $huxing = intval($huxing);
    $fengge = intval($fengge);
    $yusuan = intval($yusuan);
    $page = intval($page);

    
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];


    include template('zimucms_zhuangxiu:forum_iframe');