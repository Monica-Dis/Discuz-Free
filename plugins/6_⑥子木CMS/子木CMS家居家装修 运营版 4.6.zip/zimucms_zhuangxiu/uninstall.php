<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;

$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_fenggedata.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_huxingdata.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_yusuandata.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_news_type_daohang.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_news_type.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_parameter.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_zhuangxiu_quyu.php";
@unlink($cache_file);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_zhuangxiu/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_zhuangxiu/static/admin/kindeditor/attached/image");

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_designer;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_gongdi;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_news;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_news_type;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_parameter;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_quyu;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_shop;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_building;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_tuce;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_yuyue;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_activitylist;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_activityuser;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_xiaoqu;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_daily;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_buildingcase;
DROP TABLE  IF EXISTS pre_zimucms_zhuangxiu_workmen;

EOF;
runquery($sql);

DB::delete('common_setting', array('skey' => 'zimucms_zhuangxiu_seo'));

updatecache('setting');

C::t('common_syscache')->delete('scache_zimucms_zhuangxiu');

$finish = TRUE;


function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}