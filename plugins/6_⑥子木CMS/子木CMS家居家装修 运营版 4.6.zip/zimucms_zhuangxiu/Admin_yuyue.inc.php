<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'yuyue';
}

if ($model == 'yuyue') {
    
    if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {
        
        $editdata['id']     = intval($_GET['yuyueid']);
        $editdata['beizhu'] = strip_tags($_GET['beizhu']);
        
        if ($_GET['edityuyue2']) {
            $editdata['status'] = 2;
        } else if ($_GET['edityuyue3']) {
            $editdata['status'] = 3;
        } else if ($_GET['edityuyue4']) {
            $editdata['status'] = 4;
        }
        
        if ($editdata['id'] > 0) {
            $result = DB::update('zimucms_zhuangxiu_yuyue', $editdata, array(
                'id' => $editdata['id']
            ));
        } else {
            $editdata['name']    = strip_tags($_GET['name']);
            $editdata['phone']   = strip_tags($_GET['phone']);
            $editdata['content'] = strip_tags($_GET['content']);
            $editdata['addtime'] = $_G['timestamp'];
            $result              = DB::insert('zimucms_zhuangxiu_yuyue', $editdata);
        }
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&status=' . $editdata['status'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
    } else {
        
        
        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));

        $buildingdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_building'
        ));

        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);
        
        $wheresql = ' where status=' . $status;
        
        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimucms_zhuangxiu_yuyue"
        ));
        
        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);
        
        
        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimucms_zhuangxiu_yuyue',
            $start,
            $limit
        ));
        
        if ($page_num > 1) {
            $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
        }
        
        include template('zimucms_zhuangxiu:Admin_yuyue');
        
    }
    
    
} else if ($model == 'delyuyue' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_yuyue', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&status=' . $status;
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}