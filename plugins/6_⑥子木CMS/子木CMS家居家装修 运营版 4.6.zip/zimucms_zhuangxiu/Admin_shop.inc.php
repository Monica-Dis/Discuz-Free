<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'shop';
}

//װ�޹�˾�б�
if ($model == 'shop') {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_zhuangxiu_shop"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    
    $shopdata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_shop',
        $start,
        $limit
    ));
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_shop');
    
    
} else if ($model == 'addshop') {
    
    if (submitcheck('editshop')) {
        
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['uid']     = intval($_GET['uid']);
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);
        $editdata['coupon']  = strip_tags($_GET['coupon']);
        $editdata['bbsurl']  = strip_tags($_GET['bbsurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['casenums']  = intval($_GET['casenums']);
        $editdata['gongdinums']  = intval($_GET['gongdinums']);
        $editdata['designernums']  = intval($_GET['designernums']);
        $editdata['click']  = intval($_GET['click']);
        $editdata['indexsort']  = intval($_GET['indexsort']);
        $editdata['openid']  = strip_tags($_GET['openid']);
        $editdata['tosms']  = strip_tags($_GET['tosms']);
        $editdata['map_lat']  = strip_tags($_GET['map_lat']);
        $editdata['map_lng']  = strip_tags($_GET['map_lng']);

        
        $result = DB::insert('zimucms_zhuangxiu_shop', $editdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }
        include template('zimucms_zhuangxiu:Admin_shop_edit');
    }
    
    
} else if ($model == 'editshop') {
    
    
    if (submitcheck('editshop')) {
        
        $editdata['id']   = intval($_GET['id']);
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['uid']     = intval($_GET['uid']);
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);
        $editdata['coupon']  = strip_tags($_GET['coupon']);
        $editdata['bbsurl']  = strip_tags($_GET['bbsurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['casenums']  = intval($_GET['casenums']);
        $editdata['gongdinums']  = intval($_GET['gongdinums']);
        $editdata['designernums']  = intval($_GET['designernums']);
        $editdata['click']  = intval($_GET['click']);
        $editdata['indexsort']  = intval($_GET['indexsort']);
        $editdata['openid']  = strip_tags($_GET['openid']);
        $editdata['tosms']  = strip_tags($_GET['tosms']);
        $editdata['map_lat']  = strip_tags($_GET['map_lat']);
        $editdata['map_lng']  = strip_tags($_GET['map_lng']);
        
        $result = DB::update('zimucms_zhuangxiu_shop', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid   = intval($_GET['editid']);
        $shopdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_shop',
            $editid
        ));
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }
        include template('zimucms_zhuangxiu:Admin_shop_edit');
        
        
    }
    
    
} else if ($model == 'delshop' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_shop', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}