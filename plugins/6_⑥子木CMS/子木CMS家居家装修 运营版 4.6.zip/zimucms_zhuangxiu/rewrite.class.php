<?php

/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: rewrite.class.php 29558 2013-12-06 17:57:48Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zimucms_zhuangxiu {
	
	function plugin_zimucms_zhuangxiu() {
		global $_G;

		$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

		$_G['domain']['pregxprw']['zimucms_zhuangxiu'] = $_G['setting']['domain']['plugin']['zimucms_zhuangxiu'] ? preg_quote('http://'.$_G['setting']['domain']['plugin']['zimucms_zhuangxiu'].'/', '/') : '';

			$_G['setting']['output']['preg']['search']['zx_viewshop'] = "/<a href\=\"(".$_G['domain']['pregxprw']['zimucms_zhuangxiu'].")plugin.php\?id\=zimucms_zhuangxiu&(amp;)?mod\=viewshop&(amp;)?sid\=(\d+)\"([^\>]*)\>/e";
			$_G['setting']['output']['preg']['replace']['zx_viewshop'] = "plugin_zimucms_zhuangxiu::rewriteoutput('zx_viewshop', 0, '\\1', '\\4', '\\5')";

		foreach($_G['setting']['domain']['plugin'] as $key => $value) {
			if($value) {
				$_G['setting']['output']['preg']['search'][$key] = '/\/plugin.php\?id='.$key.'\"/';
				$_G['setting']['output']['preg']['replace'][$key] = '"';
			}
		}
	}

	function global_footer(){
		global $_G;

		return '<!-- rewrite_replace -->';
	}

	function rewriteoutput($type, $returntype, $host) {
		global $_G;
		
		$fextra = '';
		if($type == 'zx_viewshop') {
			list(,,, $sid, $extra) = func_get_args();
			$r = array(
				'{sid}' => $sid,
			);
		}

		$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);
		$href = str_replace(array_keys($r), $r, $zimu_rewrite[$type]['rule']).$fextra;
		if(!$returntype) {
			return '<a href="'.$host.$href.'"'.(!empty($extra) ? stripslashes($extra) : '').'>';
		} else {
			return $host.$href;
		}
	}
}
//From: Dism_taobao_com
?>