<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];
    $fangshidata = $parameterdata2['fangshi'];

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));
    $shopdata = DB::fetch_all("SELECT * FROM %t ORDER BY id desc", array(
        "zimucms_zhuangxiu_shop"
    ));

if (!$model) {
    $model = 'daily';
}

//װ�޹�˾�б�
if ($model == 'daily') {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_zhuangxiu_daily"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    
    $dailydata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_daily',
        $start,
        $limit
    ));
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_daily');
    
    
} else if ($model == 'adddaily') {
    
    if (submitcheck('editdaily')) {
        
        $editdata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_pic']);
        }
        if ($_FILES['shop_pic2']['tmp_name']) {
            $editdata['thumb2'] = zm_saveimages($_FILES['shop_pic2']);
        }
        if ($_FILES['shop_pic3']['tmp_name']) {
            $editdata['thumb3'] = zm_saveimages($_FILES['shop_pic3']);
        }
        if ($_FILES['shop_pic4']['tmp_name']) {
            $editdata['thumb4'] = zm_saveimages($_FILES['shop_pic4']);
        }
        $editdata['desc'] = strip_tags($_GET['desc']);
        $editdata['fengge']    = intval($_GET['fengge']);
        $editdata['huxing']    = intval($_GET['huxing']);
        $editdata['fangshi']    = intval($_GET['fangshi']);
        $editdata['yusuan']    = intval($_GET['yusuan']);
        $editdata['mianji']    = intval($_GET['mianji']);
        $editdata['posturl'] = strip_tags($_GET['posturl']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        $editdata['xiaoqu']    = intval($_GET['xiaoqu']);
        if($editdata['xiaoqu']){
            $editdata['xiaoquname'] = DB::result_first('select name from %t where id=%d', array(
                'zimucms_zhuangxiu_xiaoqu',
                $editdata['xiaoqu']
            ));
        }
        $editdata['sid']    = intval($_GET['sid']);
        if($editdata['sid']){
            $editdata['sname'] = DB::result_first('select name from %t where id=%d', array(
                'zimucms_zhuangxiu_shop',
                $editdata['sid']
            ));
        }

        $result = DB::insert('zimucms_zhuangxiu_daily', $editdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {

        include template('zimucms_zhuangxiu:Admin_daily_edit');
    }
    
    
} else if ($model == 'editdaily') {
    
    
    if (submitcheck('editdaily')) {
        
        $editdata['id']   = intval($_GET['id']);
        $editdata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_pic']);
        }
        if ($_FILES['shop_pic2']['tmp_name']) {
            $editdata['thumb2'] = zm_saveimages($_FILES['shop_pic2']);
        }
        if ($_FILES['shop_pic3']['tmp_name']) {
            $editdata['thumb3'] = zm_saveimages($_FILES['shop_pic3']);
        }
        if ($_FILES['shop_pic4']['tmp_name']) {
            $editdata['thumb4'] = zm_saveimages($_FILES['shop_pic4']);
        }
        $editdata['desc'] = strip_tags($_GET['desc']);
        $editdata['fengge']    = intval($_GET['fengge']);
        $editdata['huxing']    = intval($_GET['huxing']);
        $editdata['fangshi']    = intval($_GET['fangshi']);
        $editdata['yusuan']    = intval($_GET['yusuan']);
        $editdata['mianji']    = intval($_GET['mianji']);
        $editdata['posturl'] = strip_tags($_GET['posturl']);
        $editdata['addtime'] = strtotime($_GET['addtime']);
        $editdata['xiaoqu']    = intval($_GET['xiaoqu']);
        if($editdata['xiaoqu']){
            $editdata['xiaoquname'] = DB::result_first('select name from %t where id=%d', array(
                'zimucms_zhuangxiu_xiaoqu',
                $editdata['xiaoqu']
            ));
        }
        $editdata['sid']    = intval($_GET['sid']);
        if($editdata['sid']){
            $editdata['sname'] = DB::result_first('select name from %t where id=%d', array(
                'zimucms_zhuangxiu_shop',
                $editdata['sid']
            ));
        }

        $result = DB::update('zimucms_zhuangxiu_daily', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid   = intval($_GET['editid']);
        $dailydata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_daily',
            $editid
        ));
        include template('zimucms_zhuangxiu:Admin_daily_edit');
        
        
    }
    
    
} else if ($model == 'deldaily' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_daily', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}