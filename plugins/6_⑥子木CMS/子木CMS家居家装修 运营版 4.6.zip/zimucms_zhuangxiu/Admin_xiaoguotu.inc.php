<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('error');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'xiaoguotu';
}

if ($model == 'xiaoguotu') {
    
    $status = intval($_GET['status']);
    if ($status) {
        $wheresql  = ' where status=3 ';
        $wheresql2 = ' where a.status=3 ';
    }
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
        "zimucms_zhuangxiu_tuce"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $aaa = DB::query('select a.*,b.name as shopname from %t a left join %t b on a.sid=b.id ' . $wheresql2 . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_tuce',
        'zimucms_zhuangxiu_shop',
        $start,
        $limit
    ));
    while ($res = DB::fetch($aaa)) {
        $newsdata[] = $res;
    }
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_xiaoguotu');
    
    
} else if ($model == 'addxiaoguotu') {
    
    
    if (submitcheck('editxiaoguotu')) {
        
        $editdata['title']    = strip_tags($_GET['title']);
        $editdata['keywords'] = strip_tags($_GET['keywords']);
        $editdata['desc']     = strip_tags($_GET['desc']);
        $editdata['sid']      = intval($_GET['sid']);
        $editdata['did']      = intval($_GET['did']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['content'] = dhtmlspecialchars($_GET['content']);
        $editdata['vrurl'] = addslashes($_GET['vrurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['tuijian']  = intval($_GET['tuijian']);
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);

        $result = DB::insert('zimucms_zhuangxiu_tuce', $editdata);

        if($editdata['sid'] > 0){
            $casenums['casenums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_tuce",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }


        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));

        include template('zimucms_zhuangxiu:Admin_xiaoguotu_edit');
        
    }
    //�༭����
} else if ($model == 'editxiaoguotu') {
    
    if (submitcheck('editxiaoguotu')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['title']    = strip_tags($_GET['title']);
        $editdata['keywords'] = strip_tags($_GET['keywords']);
        $editdata['desc']     = strip_tags($_GET['desc']);
        $editdata['sid']      = intval($_GET['sid']);
        $editdata['did']      = intval($_GET['did']);
        $editdata['huxing']   = intval($_GET['huxing']);
        $editdata['fengge']   = intval($_GET['fengge']);
        $editdata['yusuan']   = intval($_GET['yusuan']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $editdata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $editdata['content'] = dhtmlspecialchars($_GET['content']);
        $editdata['vrurl'] = addslashes($_GET['vrurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['tuijian']  = intval($_GET['tuijian']);
        $editdata['xiaoqu']  = intval($_GET['xiaoqu']);

        $result = DB::update('zimucms_zhuangxiu_tuce', $editdata, array(
            'id' => $editdata['id']
        ));

        if($editdata['sid'] > 0){
            $casenums['casenums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
                "zimucms_zhuangxiu_tuce",
                $editdata['sid']
                ));
            DB::update('zimucms_zhuangxiu_shop', $casenums, array(
                'id' => $editdata['sid']
                ));
        }
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid   = intval($_GET['editid']);

        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_tuce',
            $editid
        ));

        $shopdata = DB::fetch_all('select * from %t', array(
            'zimucms_zhuangxiu_shop'
        ));
        
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];

if($newsdata['sid']){

    $designerdata = DB::fetch_all('select id,name,sid from %t where sid=%d order by id asc', array(
        'zimucms_zhuangxiu_designer',
        $newsdata['sid']
    ));
}

    $xiaoqudata = DB::fetch_all("SELECT * FROM %t ORDER BY sort desc,id desc", array(
        "zimucms_zhuangxiu_xiaoqu"
    ));
    
        include template('zimucms_zhuangxiu:Admin_xiaoguotu_edit');
        
    }
    
} else if ($model == 'delxiaoguotu' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_tuce', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
    
}