<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_designer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `touxiang` char(255) NOT NULL,
  `zhicheng` char(20) NOT NULL,
  `linian` char(50) NOT NULL,
  `jianjie` varchar(1000) NOT NULL,
  `sid` smallint(3) unsigned NOT NULL,
  `indexsort` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_gongdi` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL,
  `thumb` char(255) NOT NULL,
  `sid` int(10) UNSIGNED NOT NULL,
  `qid` int(10) UNSIGNED NOT NULL,
  `huxing` tinyint(1) UNSIGNED NOT NULL,
  `fengge` tinyint(1) UNSIGNED NOT NULL,
  `yusuan` tinyint(1) UNSIGNED NOT NULL,
  `islook` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `uptime` int(10) UNSIGNED NOT NULL,
  `fangan` varchar(500) NOT NULL,
  `content1` text NOT NULL,
  `content2` text NOT NULL,
  `content3` text NOT NULL,
  `content4` text NOT NULL,
  `content5` text NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '3',
  `xiaoqu` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` int(10) unsigned NOT NULL,
  `typeurl` varchar(10) NOT NULL,
  `istop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `keywords` varchar(100) NOT NULL,
  `desc` varchar(200) NOT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `click` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_news_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typename` varchar(50) NOT NULL,
  `typeurl` varchar(10) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '100',
  `isindex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_parameter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `ename` char(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_quyu` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `sort` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_shop` (
  `id` smallint(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(30) NOT NULL,
  `pic` char(255) NOT NULL,
  `address` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `quyu` tinyint(2) UNSIGNED NOT NULL,
  `desc` text NOT NULL,
  `fuwu` char(100) NOT NULL,
  `bbsurl` char(100) NOT NULL,
  `coupon` char(100) NOT NULL,
  `click` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `istop` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `casenums` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `gongdinums` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `designernums` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `indexsort` smallint(3) UNSIGNED NOT NULL DEFAULT '0',
  `openid` varchar(2000) NOT NULL,
  `tosms` char(100) NOT NULL,
  `map_lng` char(50) NOT NULL,
  `map_lat` char(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_building` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `name` char(30) NOT NULL,
  `pic` char(255) NOT NULL,
  `address` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `quyu` tinyint(2) unsigned NOT NULL,
  `desc` text NOT NULL,
  `contentname1` char(255) NOT NULL,
  `contentval1` text NOT NULL,
  `contentname2` char(255) NOT NULL,
  `contentval2` text NOT NULL,
  `contentname3` char(255) NOT NULL,
  `contentval3` text NOT NULL,
  `contentname4` char(255) NOT NULL,
  `contentval4` text NOT NULL,
  `fuwu` varchar(1000) NOT NULL,
  `buildingtype` smallint(2) unsigned NOT NULL,
  `bbsurl` char(100) NOT NULL,
  `coupon` char(100) NOT NULL,
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `istop` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `casenums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `gongdinums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `designernums` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `indexsort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(2000) NOT NULL,
  `tosms` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_tuce` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `keywords` varchar(100) DEFAULT NULL,
  `desc` varchar(500) DEFAULT NULL,
  `sid` int(10) unsigned NOT NULL,
  `did` int(10) unsigned NOT NULL,
  `dname` char(50) NOT NULL,
  `huxing` tinyint(1) unsigned NOT NULL,
  `fengge` tinyint(1) unsigned NOT NULL,
  `yusuan` tinyint(1) unsigned NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `vrurl` char(255) NOT NULL,
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `xiaoqu` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_yuyue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `phone` char(20) NOT NULL,
  `sid` int(10) unsigned DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) unsigned NOT NULL,
  `status` smallint(2) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_activitylist` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `thumb` char(200) NOT NULL,
  `typeid` smallint(3) UNSIGNED NOT NULL,
  `stime` int(10) UNSIGNED NOT NULL,
  `etime` int(10) UNSIGNED NOT NULL,
  `hstime` int(10) UNSIGNED NOT NULL,
  `hetime` int(10) UNSIGNED NOT NULL,
  `address` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `shoptext` text NOT NULL,
  `content` text NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL DEFAULT '100',
  `addtime` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `bbsurl` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_activityuser` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `aidtitle` char(100) NOT NULL,
  `name` char(100) NOT NULL,
  `phone` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_xiaoqu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `thumb` char(255) NOT NULL,
  `intro` varchar(1000) NOT NULL,
  `address` char(255) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL,
  `quyu` smallint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_daily` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `thumb` varchar(1000) NOT NULL,
  `thumb2` varchar(1000) NOT NULL,
  `thumb3` varchar(1000) NOT NULL,
  `thumb4` varchar(1000) NOT NULL,
  `desc` char(255) NOT NULL,
  `fengge` smallint(2) UNSIGNED NOT NULL,
  `huxing` smallint(2) UNSIGNED NOT NULL,
  `fangshi` smallint(2) UNSIGNED NOT NULL,
  `xiaoqu` smallint(2) UNSIGNED NOT NULL,
  `xiaoquname` char(100) NOT NULL,
  `sid` int(10) UNSIGNED NOT NULL,
  `sname` char(30) NOT NULL,
  `yusuan` smallint(2) UNSIGNED NOT NULL,
  `mianji` smallint(3) UNSIGNED NOT NULL,
  `posturl` varchar(1000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_buildingcase` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `thumb` char(255) NOT NULL,
  `con` mediumtext NOT NULL,
  `bid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_zhuangxiu_workmen` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL,
  `thumb` varchar(300) NOT NULL,
  `age` smallint(3) UNSIGNED NOT NULL,
  `intro` varchar(500) NOT NULL,
  `con` mediumtext NOT NULL,
  `tel` char(11) NOT NULL,
  `quyu` int(10) UNSIGNED NOT NULL,
  `wid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/discuz_plugin_zimucms_zhuangxiu.xml');
@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/discuz_plugin_zimucms_zhuangxiu_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/discuz_plugin_zimucms_zhuangxiu_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/discuz_plugin_zimucms_zhuangxiu_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/discuz_plugin_zimucms_zhuangxiu_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/install.php');
$finish = TRUE;

