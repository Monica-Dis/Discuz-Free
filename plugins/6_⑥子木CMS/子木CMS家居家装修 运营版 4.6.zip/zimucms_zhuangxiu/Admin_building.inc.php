<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'building';
}

//װ�޹�˾�б�
if ($model == 'building') {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_zhuangxiu_building"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    
    $shopdata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_building',
        $start,
        $limit
    ));
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '30', TRUE, TRUE);
    }
    
    include template('zimucms_zhuangxiu:Admin_building');
    
    
} else if ($model == 'addbuilding') {
    
    if (submitcheck('editbuilding')) {
        
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['uid']     = intval($_GET['uid']);
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);
        $editdata['buildingtype']     = intval($_GET['buildingtype']);
        $editdata['coupon']  = strip_tags($_GET['coupon']);
        $editdata['bbsurl']  = strip_tags($_GET['bbsurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['casenums']  = intval($_GET['casenums']);
        $editdata['gongdinums']  = intval($_GET['gongdinums']);
        $editdata['designernums']  = intval($_GET['designernums']);
        $editdata['click']  = intval($_GET['click']);
        $editdata['indexsort']  = intval($_GET['indexsort']);
        $editdata['openid']  = strip_tags($_GET['openid']);

        $editdata['contentname1'] = strip_tags($_GET['contentname1']);
        $editdata['contentval1'] = dhtmlspecialchars($_GET['contentval1']);
        $editdata['contentname2'] = strip_tags($_GET['contentname2']);
        $editdata['contentval2'] = dhtmlspecialchars($_GET['contentval2']);
        $editdata['contentname3'] = strip_tags($_GET['contentname3']);
        $editdata['contentval3'] = dhtmlspecialchars($_GET['contentval3']);
        $editdata['contentname4'] = strip_tags($_GET['contentname4']);
        $editdata['contentval4'] = dhtmlspecialchars($_GET['contentval4']);

        $result = DB::insert('zimucms_zhuangxiu_building', $editdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $buildingtypedata = $parameterdata2['buildingtype'];
        include template('zimucms_zhuangxiu:Admin_building_edit');
    }
    
    
} else if ($model == 'editbuilding') {
    
    
    if (submitcheck('editbuilding')) {
        
        $editdata['id']   = intval($_GET['id']);
        $editdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_pic']['tmp_name']) {
            $editdata['pic'] = zm_saveimages($_FILES['shop_pic']);
        }
        $editdata['uid']     = intval($_GET['uid']);
        $editdata['address'] = strip_tags($_GET['address']);
        $editdata['tel']     = strip_tags($_GET['tel']);
        $editdata['quyu']    = intval($_GET['quyu']);
        $editdata['desc']    = strip_tags($_GET['desc']);
        $editdata['fuwu']    = strip_tags($_GET['fuwu']);
        $editdata['buildingtype']     = intval($_GET['buildingtype']);
        $editdata['coupon']  = strip_tags($_GET['coupon']);
        $editdata['bbsurl']  = strip_tags($_GET['bbsurl']);
        $editdata['status']  = intval($_GET['status']);
        $editdata['casenums']  = intval($_GET['casenums']);
        $editdata['gongdinums']  = intval($_GET['gongdinums']);
        $editdata['designernums']  = intval($_GET['designernums']);
        $editdata['click']  = intval($_GET['click']);
        $editdata['indexsort']  = intval($_GET['indexsort']);
        $editdata['openid']  = strip_tags($_GET['openid']);
        $editdata['contentname1'] = strip_tags($_GET['contentname1']);
        $editdata['contentval1'] = dhtmlspecialchars($_GET['contentval1']);
        $editdata['contentname2'] = strip_tags($_GET['contentname2']);
        $editdata['contentval2'] = dhtmlspecialchars($_GET['contentval2']);
        $editdata['contentname3'] = strip_tags($_GET['contentname3']);
        $editdata['contentval3'] = dhtmlspecialchars($_GET['contentval3']);
        $editdata['contentname4'] = strip_tags($_GET['contentname4']);
        $editdata['contentval4'] = dhtmlspecialchars($_GET['contentval4']);

        
        $result = DB::update('zimucms_zhuangxiu_building', $editdata, array(
            'id' => $editdata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $editid   = intval($_GET['editid']);
        $shopdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_building',
            $editid
        ));
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
                'zimucms_zhuangxiu_quyu'
            ));
        }
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
foreach ($parameterdata as $key => $value) {
$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

    $buildingtypedata = $parameterdata2['buildingtype'];
        include template('zimucms_zhuangxiu:Admin_building_edit');
        
        
    }
    
    
} else if ($model == 'delbuilding' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_building', array(
        'id' => $delid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}