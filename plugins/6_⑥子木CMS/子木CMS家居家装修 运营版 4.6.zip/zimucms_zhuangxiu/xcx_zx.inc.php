<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

$sid = intval($_GET['sid']);

$shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($sid);

$returndata['code'] = 200;
$returndata['msg'] = 'OK';


if($model == 'index_about'){

$designerdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_designer')->fetch_by_sid($sid);


$returndata['data']['shop']['id'] = $shopdata['id'];
$returndata['data']['shop']['name'] = zimu_array_utf8($shopdata['name']);
$returndata['data']['shop']['tele'] = $shopdata['tel'];
$returndata['data']['shop']['address'] = zimu_array_utf8($shopdata['address']);
$returndata['data']['shop']['description'] = zimu_array_utf8($shopdata['desc']);
$returndata['data']['shop']['image'] = $shopdata['pic'];
$returndata['data']['shop']['service'] = zimu_array_utf8($shopdata['fuwu']);
$returndata['data']['shop']['map_lng'] = $shopdata['map_lng'];
$returndata['data']['shop']['map_lat'] = $shopdata['map_lat'];


    die(json_encode($returndata));

}else if( $model == "tag_map" ){

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }

    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];

    foreach ($huxingdata as $key => $value) {
        $huxingdata2[$key]['id'] =  $key;
        $huxingdata2[$key]['tag_name'] =  $value;
    }

    foreach ($fenggedata as $key => $value) {
        $fenggedata2[$key]['id'] =  $key;
        $fenggedata2[$key]['tag_name'] =  $value;
    }

    foreach ($yusuandata as $key => $value) {
        $yusuandata2[$key]['id'] =  $key;
        $yusuandata2[$key]['tag_name'] =  $value;
    }

$returndata['data']['map']['htype'] = zimu_array_utf8($huxingdata2);
$returndata['data']['map']['style'] = zimu_array_utf8($fenggedata2);
$returndata['data']['map']['budget'] = zimu_array_utf8($yusuandata2);

    die(json_encode($returndata));

}else if( $model == "album_list" ){

    $order      = $_GET['order'] = $_GET['order'] ? $_GET['order'] : 1;
    $huxing     = $_GET['htype'] = $_GET['htype'] ? $_GET['htype'] : 0;
    $fengge     = $_GET['style'] = $_GET['style'] ? $_GET['style'] : 0;
    $yusuan     = $_GET['budget'] = $_GET['budget'] ? $_GET['budget'] : 0;
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;

    $designer_id = intval($_GET['designer_id']);

    $order = intval($order);
    $huxing = intval($huxing);
    $fengge = intval($fengge);
    $yusuan = intval($yusuan);
    $page = intval($page);

    $wheresql = 'WHERE status =1 and sid = '.$sid;
    if ($huxing > 0) {
        $wheresql .= ' AND huxing = ' . $huxing;
    }
    if ($fengge > 0) {
        $wheresql .= ' AND fengge = ' . $fengge;
    }
    if ($yusuan > 0) {
        $wheresql .= ' AND yusuan = ' . $yusuan;
    }
    if ($designer_id > 0) {
        $wheresql .= ' AND did = ' . $designer_id;
    }
    if ($order == 1) {
        $ordername = 'id';
    } else {
        $ordername = 'click';
    }
    $totail = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimucms_zhuangxiu_tuce",
        $wheresql
    ));

    $limit    = 10;
    $start    = ($page - 1) * $limit;

    $tucedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by ' . $ordername . ' desc limit %d,%d', array(
        'zimucms_zhuangxiu_tuce',
        $start,
        $limit
    ));


    foreach ($tucedata as $key => $value) {
if(strpos($value['thumb'],'http') !== false){ 
$tucedata[$key]['thumb'] = $value['thumb'];
}else{
$tucedata[$key]['thumb'] = $_G['siteurl'].$value['thumb'];
}
        $tucedata[$key]['huxing'] =  get_tag_pars('huxing',$value['huxing']);
        $tucedata[$key]['fengge'] =  get_tag_pars('fengge',$value['fengge']);
        $tucedata[$key]['yusuan'] =  get_tag_pars('yusuan',$value['yusuan']);
    }

$returndata['data']['list'] = zimu_array_utf8($tucedata);
$returndata['data']['count'] = $totail;
$returndata['data']['pageCount'] = $page-1;

    die(json_encode($returndata));

}else if( $model == "album_detail" ){

$tid = intval($_GET['tid']);

    $tucedata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_tuce',
        $tid
    ));

if(strpos($tucedata['thumb'],'http') !== false){ 
$tucedata['thumb'] = $tucedata['thumb'];
}else{
$tucedata['thumb'] = $_G['siteurl'].$tucedata['thumb'];
}
        $tucedata['huxing'] =  get_tag_pars('huxing',$tucedata['huxing']);
        $tucedata['fengge'] =  get_tag_pars('fengge',$tucedata['fengge']);
        $tucedata['yusuan'] =  get_tag_pars('yusuan',$tucedata['yusuan']);
        $tucedata['content'] =  htmlspecialchars_decode($tucedata['content']);


$returndata['data']['data'] = zimu_array_utf8($tucedata);

    die(json_encode($returndata));


}else if( $model == "construction_tag" ){

    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');

    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
    }


    $fenggedata = $parameterdata2['fengge'];

    foreach ($fenggedata as $key => $value) {
        $fenggedata2[$key]['id'] =  $key;
        $fenggedata2[$key]['tag_name'] =  $value;
    }

$returndata['data']['style'] = zimu_array_utf8($fenggedata2);

    die(json_encode($returndata));

}else if( $model == "construction_list" ){

    $fengge     = $_GET['style'] = $_GET['style'] ? $_GET['style'] : 0;
    $step     = $_GET['step'] = $_GET['step'] ? $_GET['step'] : 0;
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;

    $fengge = intval($fengge);
    $step = intval($step);
    $page = intval($page);

    $wheresql = 'WHERE status = 1 and sid = '.$sid;
    if ($fengge > 0) {
        $wheresql .= ' AND fengge = ' . $fengge;
    }

if($step ==1 ){
$wheresql .= " AND content1 != ''"." AND content2 = '' AND content3 = '' AND content4 = '' AND content5 = ''";
}else if($step ==2){
$wheresql .= " AND content2 != '' AND content3 = '' AND content4 = '' AND content5 = ''";
}else if($step ==3){
$wheresql .= " AND content3 != '' AND content4 = '' AND content5 = ''";
}else if($step ==4){
$wheresql .= " AND content4 != '' AND content5 = ''";
}else if($step ==5){
$wheresql .= " AND content5 != ''";
}


    $ordername = 'id';

    $totail = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimucms_zhuangxiu_gongdi",
        $wheresql
    ));

    $limit    = 10;
    $start    = ($page - 1) * $limit;

    $tucedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by ' . $ordername . ' desc limit %d,%d', array(
        'zimucms_zhuangxiu_gongdi',
        $start,
        $limit
    ));

    foreach ($tucedata as $key => $value) {
if(strpos($value['thumb'],'http') !== false){ 
$tucedata[$key]['thumb'] = $value['thumb'];
}else{
$tucedata[$key]['thumb'] = $_G['siteurl'].$value['thumb'];
}

if($value['content5']){
$tucedata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text5');
}else if($value['content4']){
$tucedata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text6');
}else if($value['content3']){
$tucedata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text7');
}else if($value['content2']){
$tucedata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text8');
}else{
$tucedata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text9');
}


$tucedata[$key]['imagesArr'] = getimgs(htmlspecialchars_decode($value['content1'].$value['content2'].$value['content3'].$value['content4'].$value['content5']));

        $tucedata[$key]['huxing'] =  get_tag_pars('huxing',$value['huxing']);
        $tucedata[$key]['fengge'] =  get_tag_pars('fengge',$value['fengge']);
        $tucedata[$key]['yusuan'] =  get_tag_pars('yusuan',$value['yusuan']);
    }

$returndata['data']['list'] = zimu_array_utf8($tucedata);
$returndata['data']['count'] = $totail;
$returndata['data']['pageCount'] = $page-1;

    die(json_encode($returndata));

}else if( $model == "construction_detail" ){

$gid = intval($_GET['gid']);

    $gongdiview = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_gongdi',
        $gid
    ));

if($gongdiview['content5']){
$gongdiview['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text5');
}else if($gongdiview['content4']){
$gongdiview['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text6');
}else if($gongdiview['content3']){
$gongdiview['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text7');
}else if($gongdiview['content2']){
$gongdiview['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text8');
}else{
$gongdiview['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text9');
}


$gongdiview['imagesArr'] = getimgs(htmlspecialchars_decode($gongdiview['content1'].$gongdiview['content2'].$gongdiview['content3'].$gongdiview['content4'].$gongdiview['content5']));

        $gongdiview['huxing'] =  get_tag_pars('huxing',$gongdiview['huxing']);
        $gongdiview['fengge'] =  get_tag_pars('fengge',$gongdiview['fengge']);
        $gongdiview['yusuan'] =  get_tag_pars('yusuan',$gongdiview['yusuan']);

        $gongdiview['content1'] = str_replace('src="/source/plugin/zimucms_zhuangxiu', 'src="'.$_G['siteurl'].'/source/plugin/zimucms_zhuangxiu', htmlspecialchars_decode($gongdiview['content1']));
        $gongdiview['content2'] =  htmlspecialchars_decode($gongdiview['content2']);
        $gongdiview['content3'] =  htmlspecialchars_decode($gongdiview['content3']);
        $gongdiview['content4'] =  htmlspecialchars_decode($gongdiview['content4']);
        $gongdiview['content5'] =  htmlspecialchars_decode($gongdiview['content5']);

$returndata['data']['data'] = zimu_array_utf8($gongdiview);

    die(json_encode($returndata));

}else if( $model == "index_index" ){

$designerdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_designer')->fetch_by_sid($sid);
    $tuijiantucedata = DB::fetch_all('select * from %t where sid=%d and tuijian=1 and status=1 order by id desc limit 5', array(
        'zimucms_zhuangxiu_tuce',
        $sid
    ));

    $tucedata   = DB::result_first('select count(*) from %t where sid=%d and status=1 order by id desc limit 6', array(
        'zimucms_zhuangxiu_tuce',
        $sid
    ));

    $gongdidata = DB::fetch_all('select * from %t where sid=%d and status=1 order by id desc limit 6', array(
        'zimucms_zhuangxiu_gongdi',
        $sid
    ));


    foreach ($gongdidata as $key => $value) {
if(strpos($value['thumb'],'http') !== false){ 
$gongdidata[$key]['thumb'] = $value['thumb'];
}else{
$gongdidata[$key]['thumb'] = $_G['siteurl'].$value['thumb'];
}

if($value['content5']){
$gongdidata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text5');
}else if($value['content4']){
$gongdidata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text6');
}else if($value['content3']){
$gongdidata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text7');
}else if($value['content2']){
$gongdidata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text8');
}else{
$gongdidata[$key]['stepName'] = lang('plugin/zimucms_zhuangxiu', 'admin_gongdi_text9');
}


$gongdidata[$key]['imagesArr'] = getimgs(htmlspecialchars_decode($value['content1'].$value['content2'].$value['content3'].$value['content4'].$value['content5']));

        $gongdidata[$key]['huxing'] =  get_tag_pars('huxing',$value['huxing']);
        $gongdidata[$key]['fengge'] =  get_tag_pars('fengge',$value['fengge']);
        $gongdidata[$key]['yusuan'] =  get_tag_pars('yusuan',$value['yusuan']);
    }


$returndata['data']['shop']['id'] = $shopdata['id'];
$returndata['data']['shop']['name'] = zimu_array_utf8($shopdata['name']);
$returndata['data']['shop']['tele'] = $shopdata['tel'];
$returndata['data']['shop']['address'] = zimu_array_utf8($shopdata['address']);
$returndata['data']['shop']['description'] = zimu_array_utf8($shopdata['desc']);
$returndata['data']['shop']['image'] = $shopdata['pic'];
$returndata['data']['shop']['service'] = zimu_array_utf8($shopdata['fuwu']);
$returndata['data']['shop']['map_lng'] = $shopdata['map_lng'];
$returndata['data']['shop']['map_lat'] = $shopdata['map_lat'];
$returndata['data']['member'] = array();
$returndata['data']['shop']['designer'] = zimu_array_utf8($designerdata);
$returndata['data']['album'] = zimu_array_utf8($tuijiantucedata);
$returndata['data']['albumCount'] = $tucedata;
$returndata['data']['gongdi'] = zimu_array_utf8($gongdidata);
    die(json_encode($returndata));

}else if( $model == "order_tag" ){



}else if( $model == "designer_detail" ){

$did = intval($_GET['did']);

    $designerdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_designer',
        $did
    ));

$returndata['data']['data'] = zimu_array_utf8($designerdata);
    die(json_encode($returndata));   

}else if( $model == "order_submit" ){

    $data['name']    = zm_diconv(strip_tags($_GET['name']));
    $data['phone']   = strip_tags($_GET['phone']);
    $data['sid']     = intval($_GET['sid']);
    $shopbuildingtype = $_GET['shopbuildingtype'] = $_GET['shopbuildingtype'] ? $_GET['shopbuildingtype'] : 1;
    $data['type']     = intval($shopbuildingtype);
    $data['addtime'] = $_G['timestamp'];

    $size = strip_tags(zm_diconv($_GET['size']));
    if ($size) {
        $sizename = '<br>' .lang('plugin/zimucms_zhuangxiu', 'system_text11') . $size . '<br>';
    }
    $budget = strip_tags(zm_diconv($_GET['budget']));
    if ($budget) {
        $budgetname = lang('plugin/zimucms_zhuangxiu', 'system_text12') . $budget . '<br>';
    }

    $is_marry = $_GET['is_marry'];
    if ($is_marry && $is_marry == 1) {
        $is_marryname = lang('plugin/zimucms_zhuangxiu', 'system_text13') . '<br>';
    } else if ($is_marry && $is_marry == 0) {
        $is_marryname = lang('plugin/zimucms_zhuangxiu', 'system_text14') . '<br>';
    }

    $request = strip_tags(zm_diconv($_GET['request']));
    if ($request) {
        $requestname = lang('plugin/zimucms_zhuangxiu', 'system_text15') . $request . '<br>';
    }
    $plot_name = strip_tags(zm_diconv($_GET['plot_name']));
    if ($plot_name) {
        $plot_name2 = lang('plugin/zimucms_zhuangxiu', 'system_text16') . $plot_name . '<br>';
    }
    $start_time = strip_tags(zm_diconv($_GET['start_time']));
    if ($start_time) {
        $start_timename = lang('plugin/zimucms_zhuangxiu', 'system_text17') . $start_timename . '<br>';
    }
    if(!$ZIMUCMS_MYUSER){exit();}
    $style = strip_tags(zm_diconv($_GET['style']));
    if ($style) {
        $stylename = lang('plugin/zimucms_zhuangxiu', 'system_text18') . $style . '<br>';
    }


    if ($_GET['bedroom']) {
        $bedroomname = lang('plugin/zimucms_zhuangxiu', 'system_text19') . strip_tags(zm_diconv($_GET['bedroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text20') . strip_tags(zm_diconv($_GET['livingroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text21') . strip_tags(zm_diconv($_GET['bathroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text22');
    }


    $data['content'] = lang('plugin/zimucms_zhuangxiu', 'system_text23') . strip_tags(zm_diconv($_GET["source2"])) . '<br>' . lang('plugin/zimucms_zhuangxiu', 'system_text24') . strip_tags(zm_diconv($_GET["type2"])) . '<br>' . strip_tags(zm_diconv($_GET['moreinfo'])) . $sizename . $budgetname . $is_marryname . $requestname . $plot_name2 . $start_timename . $stylename . $bedroomname;

    if ($data['name'] && $data['phone']) {
        $result = DB::insert('zimucms_zhuangxiu_yuyue', $data);
        echo json_encode(array(
            'status' => 1
        ));
    }

}




function getimgs($str) {
    global $_G;
    $str = str_replace('src="/source/plugin/zimucms_zhuangxiu', 'src="'.$_G['siteurl'].'/source/plugin/zimucms_zhuangxiu', $str);

    $reg = '/((http|https):\/\/)+(\w+\.)+(\w+)[\w\/\.\-]*(jpg|jpeg|gif|png)/';
    $matches = array();
    preg_match_all($reg, $str, $matches);
    foreach ($matches[0] as $value) {
        $data[] = $value;
    }
    return $data;
}