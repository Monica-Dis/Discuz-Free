<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';

$model = addslashes($_GET['model']);

if (!$model) {
    $model = 'quyu';
}

if ($model == 'quyu') {
    
    if (submitcheck('edit_quyu')) {
        
        $editdata['id']   = intval($_GET['quyuid']);
        $editdata['name'] = strip_tags($_GET['quyuname']);
        $editdata['sort'] = intval($_GET['sort']);
        
        if ($editdata['id'] > 0) {
            $result = DB::update('zimucms_zhuangxiu_quyu', $editdata, array(
                'id' => $editdata['id']
            ));
        } else {
            $result = DB::insert('zimucms_zhuangxiu_quyu', $editdata);
        }
        
        
        if ($result) {
            
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
                'zimucms_zhuangxiu_quyu'
            ));
            
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_quyu', $quyudata);
            
            
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
        }
        
        
    } else {
        
        $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
        
        if (!$quyudata) {
            $quyudata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
                'zimucms_zhuangxiu_quyu'
            ));
            zimu_writetocache('table_plugin_zimucms_zhuangxiu_quyu', $quyudata);
        }
        include template('zimucms_zhuangxiu:Admin_quyu');
    }
    
    
} else if ($model == 'delquyu' && $_GET['md5formhash'] == formhash()) {
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimucms_zhuangxiu_quyu', array(
        'id' => $delid
    ));
    if ($result) {
        
        $quyudata = DB::fetch_all('select * from %t order by sort asc,id asc', array(
            'zimucms_zhuangxiu_quyu'
        ));
        
        zimu_writetocache('table_plugin_zimucms_zhuangxiu_quyu', $quyudata);
        
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_zhuangxiu', 'system_text2'), '', 'error');
    }
}