<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/config.php';
if ($zimucms_zhuangxiu['weixin_appid'] && $zimucms_zhuangxiu['weixin_appsecret'] && IN_WECHAT) {
    require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zimucms_zhuangxiu['weixin_appid'], $zimucms_zhuangxiu['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage();
}
$model = addslashes($_GET['model']);
$model = !empty($model) ? $model : 'newindex';

require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/rewrite.php';

// ���Ĺ�˾��ҳ
if ($model == 'building') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);
    
    include_once("page.class.php");
    
    $area         = $_GET['area'] = $_GET['area'] ? $_GET['area'] : 0;
    $order        = $_GET['order'] = $_GET['order'] ? $_GET['order'] : 1;
    $page         = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $buildingtype = $_GET['buildingtype'] = $_GET['buildingtype'] ? $_GET['buildingtype'] : 0;
    $area         = intval($area);
    $order        = intval($order);
    $page         = intval($page);
    $buildingtype = intval($buildingtype);
    
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
    
    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
    }
    
    $buildingtypearray = $parameterdata2['buildingtype'];
    
    if ($order == 1) {
        $ordername = "click";
    } else if ($order == 2) {
        $ordername = "id";
    } else {
        $ordername = "click";
    }
    
    $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
    
    if ($area > 0) {
        $wherearea = ' and quyu=' . $area;
    }
    if ($buildingtype > 0) {
        $wherebuildingtype = ' and buildingtype=' . $buildingtype;
    }
    
    $totail = DB::result_first("SELECT count(*) FROM %t WHERE status=1 " . $wherearea . $wherebuildingtype, array(
        "zimucms_zhuangxiu_building"
    ));
    
    $number = 10;
    $url    = ZIMUCMS_URL . '&model=building&area=' . $area . '&order=' . $order . '&buildingtype=' . $buildingtype . '&page={page}';
    
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $shopdata = DB::fetch_all('select * from %t where status=1 ' . $wherearea . $wherebuildingtype . ' %i limit %d,%d', array(
        'zimucms_zhuangxiu_building',
        'order by ' . $ordername . ' desc',
        $startnum,
        $count
    ));
    
    
    $share_title = $zmdata['shop_seo_title'] ? $zmdata['shop_seo_title'] : $zimucms_zhuangxiu['seo_title'];
    $share_desc  = $zmdata['shop_seo_desc'] ? $zmdata['shop_seo_desc'] : $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    $share_thumb = $zimucms_zhuangxiu['share_thumb'];
    
    
    
    include template('zimucms_zhuangxiu:site_building');
    
    
    // ���Ĺ�˾����ҳ
} else if ($model == 'viewbuilding') {
    
    $bid      = intval($_GET['bid']);
    $shopdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_building',
        $bid
    ));
    
    include_once("page.class.php");
    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page   = intval($_GET['page']);
    $totail = DB::result_first("SELECT count(*) FROM %t WHERE bid=%d", array(
        "zimucms_zhuangxiu_buildingcase",
        $bid
    ));
    if (checkmobile()) {
        $number = 4;
    } else {
        $number = 8;
    }
    $url      = ZIMUCMS_URL . '&model=viewbuilding&bid=' . $bid . '&show=anli&page={page}';
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    $casedata = DB::fetch_all('select * from %t where bid=%d order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_buildingcase',
        $bid,
        $startnum,
        $count
    ));
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $share_title = $shopdata['name'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($shopdata['pic'] && !preg_match('/^(http|\.)/i', $shopdata['pic'])) {
        $shopdata['pic'] = $_G['siteurl'] . $shopdata['pic'];
    }
    $share_thumb = $shopdata['pic'] ? $shopdata['pic'] : $zimucms_zhuangxiu['share_thumb'];
    
    include template('zimucms_zhuangxiu:building_index');
    
    
    
    // װ�޹�˾��ҳ
} else if ($model == 'shop') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);
    
    include_once("page.class.php");
    
    $area  = $_GET['area'] = $_GET['area'] ? $_GET['area'] : 0;
    $order = $_GET['order'] = $_GET['order'] ? $_GET['order'] : 1;
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $area  = intval($area);
    $order = intval($order);
    $page  = intval($page);
    
    
    if ($order == 1) {
        $ordername = "click";
    } else if ($order == 2) {
        $ordername = "id";
    } else if ($order == 3) {
        $ordername = "casenums";
    } else if ($order == 4) {
        $ordername = "gongdinums";
    } else if ($order == 5) {
        $ordername = "designernums";
    }
    
    $quyudata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_quyu');
    
    if ($area > 0) {
        $totail = DB::result_first("SELECT count(*) FROM %t WHERE status=1 AND quyu=%d", array(
            "zimucms_zhuangxiu_shop",
            $area
        ));
    } else {
        $totail = DB::result_first("SELECT count(*) FROM %t WHERE status=1", array(
            "zimucms_zhuangxiu_shop"
        ));
    }
    $number = 10;
    
    $url = ZIMUCMS_URL . '&model=shop&area=' . $area . '&order=' . $order . '&yusuan=' . $yusuan . '&page={page}';
    
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    if ($area > 0) {
        $shopdata = DB::fetch_all('select * from %t where status=1 and quyu=%d %i limit %d,%d', array(
            'zimucms_zhuangxiu_shop',
            $area,
            'order by ' . $ordername . ' desc',
            $startnum,
            $count
        ));
    } else {
        $shopdata = DB::fetch_all('select * from %t where status=1 %i limit %d,%d', array(
            'zimucms_zhuangxiu_shop',
            'order by ' . $ordername . ' desc',
            $startnum,
            $count
        ));
    }
    
    foreach ($shopdata as $key => $value) {
        $shopdata[$key]['casenums']   = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
            "zimucms_zhuangxiu_tuce",
            $value['id']
        ));
        $shopdata[$key]['gongdinums'] = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
            "zimucms_zhuangxiu_gongdi",
            $value['id']
        ));
    }
    
    $share_title = $zmdata['shop_seo_title'] ? $zmdata['shop_seo_title'] : $zimucms_zhuangxiu['seo_title'];
    $share_desc  = $zmdata['shop_seo_desc'] ? $zmdata['shop_seo_desc'] : $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    $share_thumb = $zimucms_zhuangxiu['share_thumb'];
    
    include template('zimucms_zhuangxiu:site_shop');
    
    // ��˾��ҳ
} else if ($model == 'viewshop') {
    
    $sid          = intval($_GET['sid']);
    $shopdata     = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($sid);
    $designerdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_designer')->fetch_by_sid($sid);
    
    $tuijiantucedata = DB::fetch_all('select * from %t where sid=%d and tuijian=1 and status=1 order by id desc limit 5', array(
        'zimucms_zhuangxiu_tuce',
        $sid
    ));
    
    $tucedata = DB::fetch_all('select * from %t where sid=%d and status=1 order by id desc limit 6', array(
        'zimucms_zhuangxiu_tuce',
        $sid
    ));
    
    $gongdidata = DB::fetch_all('select * from %t where sid=%d and status=1 order by id desc limit 6', array(
        'zimucms_zhuangxiu_gongdi',
        $sid
    ));
    
    $share_title = $shopdata['name'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($shopdata['pic'] && !preg_match('/^(http|\.)/i', $shopdata['pic'])) {
        $shopdata['pic'] = $_G['siteurl'] . $shopdata['pic'];
    }
    $share_thumb = $shopdata['pic'] ? $shopdata['pic'] : $zimucms_zhuangxiu['share_thumb'];
    
    
    include template('zimucms_zhuangxiu:shop_index');
    
    // Ч��ͼ
} else if ($model == 'tuceshop') {
    
    $sid      = intval($_GET['sid']);
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_shop',
        $sid
    ));
    include_once("page.class.php");
    $page     = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page     = intval($_GET['page']);
    $totail   = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
        "zimucms_zhuangxiu_tuce",
        $sid
    ));
    $number   = 10;
    $url      = ZIMUCMS_URL . '&model=tuceshop&sid=' . $sid . '&page={page}';
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    $tucedata = DB::fetch_all('select * from %t where sid=%d and status=1 order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_tuce',
        $sid,
        $startnum,
        $count
    ));
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $share_title = $shopdata['name'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($shopdata['pic'] && !preg_match('/^(http|\.)/i', $shopdata['pic'])) {
        $shopdata['pic'] = $_G['siteurl'] . $shopdata['pic'];
    }
    $share_thumb = $shopdata['pic'] ? $shopdata['pic'] : $zimucms_zhuangxiu['share_thumb'];
    
    
    include template('zimucms_zhuangxiu:shop_case');
    
    // Ч��ͼ��ҳ
} else if ($model == 'tuce') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $tid = intval($_GET['tid']);
    
    $tucedata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_tuce',
        $tid
    ));
    
    if (!$tucedata) {
        header("http/1.1 404 not found");
        header("status: 404 not found");
        exit();
    }
    
    $shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($tucedata['sid']);
    $randdata = DB::fetch_all('select * from %t where sid=%d order by rand() limit 3', array(
        'zimucms_zhuangxiu_tuce',
        $tucedata['sid']
    ));
    
    $share_title = $tucedata['title'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($tucedata['thumb'] && !preg_match('/^(http|\.)/i', $tucedata['thumb'])) {
        $tucedata['thumb'] = $_G['siteurl'] . $tucedata['thumb'];
    }
    $share_thumb = $tucedata['thumb'] ? $tucedata['thumb'] : $zimucms_zhuangxiu['share_thumb'];
    
    
    
    if ($tucedata['sid'] > 0) {
        $sid = $tucedata['sid'];
        include template('zimucms_zhuangxiu:shop_tuce');
    } else {
        include template('zimucms_zhuangxiu:site_tuce');
    }
    // ����
} else if ($model == 'gongdishop') {
    
    $sid = intval($_GET['sid']);
    
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_shop',
        $sid
    ));
    
    include_once("page.class.php");
    $page       = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page       = intval($_GET['page']);
    $totail     = DB::result_first("SELECT count(*) FROM %t WHERE sid=%d AND status=1", array(
        "zimucms_zhuangxiu_gongdi",
        $sid
    ));
    $number     = 10;
    $url        = ZIMUCMS_URL . '&model=gongdishop&sid=' . $sid . '&page={page}';
    $my_page    = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum   = $my_page->page_limit;
    $count      = $my_page->myde_size;
    $gongdidata = DB::fetch_all('select * from %t where sid=%d and status=1 order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_gongdi',
        $sid,
        $startnum,
        $count
    ));
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $share_title = $shopdata['name'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($shopdata['pic'] && !preg_match('/^(http|\.)/i', $shopdata['pic'])) {
        $shopdata['pic'] = $_G['siteurl'] . $shopdata['pic'];
    }
    $share_thumb = $shopdata['pic'] ? $shopdata['pic'] : $zimucms_zhuangxiu['share_thumb'];
    
    
    include template('zimucms_zhuangxiu:shop_gongdi');
    
    // ������ҳ
} else if ($model == 'gongdi') {
    
    $gid = intval($_GET['gid']);
    
    $gongdiview = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_gongdi',
        $gid
    ));
    
    $shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($gongdiview['sid']);
    $sid      = $gongdiview['sid'];
    
    
    $share_title = $gongdiview['title'] . ' - ' . $shopdata['name'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    $share_desc  = $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    if ($gongdiview['thumb'] && !preg_match('/^(http|\.)/i', $gongdiview['thumb'])) {
        $gongdiview['thumb'] = $_G['siteurl'] . $gongdiview['thumb'];
    }
    $share_thumb = $gongdiview['thumb'] ? $gongdiview['thumb'] : $zimucms_zhuangxiu['share_thumb'];
    
    
    include template('zimucms_zhuangxiu:shop_gongdi_view');
    
    
    // �Ŷ��б�ҳ
} else if ($model == 'teamshop') {
    
    $sid = intval($_GET['sid']);
    
    $designerdata = DB::fetch_all('select * from %t where sid=%d', array(
        'zimucms_zhuangxiu_designer',
        $sid
    ));
    
    $shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($sid);
    include template('zimucms_zhuangxiu:shop_team');
    
    // ���ʦ��ҳ
} else if ($model == 'designer') {
    
    $did = intval($_GET['did']);
    
    $designerdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_zhuangxiu_designer',
        $did
    ));
    
    $shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($designerdata['sid']);
    $tucedata = DB::fetch_all('select * from %t where did=%d and status=1 order by id desc', array(
        'zimucms_zhuangxiu_tuce',
        $did
    ));
    include template('zimucms_zhuangxiu:shop_designer');
    
    // ��ϵ����
} else if ($model == 'contactshop') {
    
    $sid = intval($_GET['sid']);
    
    $shopdata = C::t('#zimucms_zhuangxiu#zimucms_zhuangxiu_shop')->fetch_by_sid($sid);
    include template('zimucms_zhuangxiu:shop_contact');
    
    
    
} else if ($model == 'clickshop' && $_GET['md5formhash'] == formhash()) {
    
    $sid = intval($_GET['shopid']);
    if ($sid > 0) {
        DB::query("update %t set click=click+1 where id=%d", array(
            'zimucms_zhuangxiu_shop',
            $sid
        ));
    }
    
} else if ($model == 'clickbuilding' && $_GET['md5formhash'] == formhash()) {
    
    $sid = intval($_GET['shopid']);
    if ($sid > 0) {
        DB::query("update %t set click=click+1 where id=%d", array(
            'zimucms_zhuangxiu_building',
            $sid
        ));
    }
    
    //ͳһԤԼ�ӿ�
} else if ($model == 'yuyue') {
    
    $data['name']     = zm_diconv(strip_tags($_GET['name']));
    $data['phone']    = strip_tags($_GET['phone']);
    $data['sid']      = intval($_GET['sid']);
    $shopbuildingtype = $_GET['shopbuildingtype'] = $_GET['shopbuildingtype'] ? $_GET['shopbuildingtype'] : 1;
    $data['type']     = intval($shopbuildingtype);
    $data['addtime']  = $_G['timestamp'];
    
    $size = strip_tags(zm_diconv($_GET['size']));
    if ($size) {
        $sizename = '<br>' . lang('plugin/zimucms_zhuangxiu', 'system_text11') . $size . '<br>';
    }
    $budget = strip_tags(zm_diconv($_GET['budget']));
    if ($budget) {
        $budgetname = lang('plugin/zimucms_zhuangxiu', 'system_text12') . $budget . '<br>';
    }
    
    $is_marry = $_GET['is_marry'];
    if ($is_marry && $is_marry == 1) {
        $is_marryname = lang('plugin/zimucms_zhuangxiu', 'system_text13') . '<br>';
    } else if ($is_marry && $is_marry == 0) {
        $is_marryname = lang('plugin/zimucms_zhuangxiu', 'system_text14') . '<br>';
    }
    
    $request = strip_tags(zm_diconv($_GET['request']));
    if ($request) {
        $requestname = lang('plugin/zimucms_zhuangxiu', 'system_text15') . $request . '<br>';
    }
    $plot_name = strip_tags(zm_diconv($_GET['plot_name']));
    if ($plot_name) {
        $plot_name2 = lang('plugin/zimucms_zhuangxiu', 'system_text16') . $plot_name . '<br>';
    }
    $start_time = strip_tags(zm_diconv($_GET['start_time']));
    if ($start_time) {
        $start_timename = lang('plugin/zimucms_zhuangxiu', 'system_text17') . $start_timename . '<br>';
    }
    
    $style = strip_tags(zm_diconv($_GET['style']));
    if ($style) {
        $stylename = lang('plugin/zimucms_zhuangxiu', 'system_text18') . $style . '<br>';
    }
    
    
    if ($_GET['bedroom']) {
        $bedroomname = lang('plugin/zimucms_zhuangxiu', 'system_text19') . strip_tags(zm_diconv($_GET['bedroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text20') . strip_tags(zm_diconv($_GET['livingroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text21') . strip_tags(zm_diconv($_GET['bathroom'])) . lang('plugin/zimucms_zhuangxiu', 'system_text22');
    }
    
    
    $data['content'] = lang('plugin/zimucms_zhuangxiu', 'system_text23') . strip_tags(zm_diconv($_GET["source"])) . '<br>' . lang('plugin/zimucms_zhuangxiu', 'system_text24') . strip_tags(zm_diconv($_GET["type"])) . '<br>' . strip_tags(zm_diconv($_GET['moreinfo'])) . $sizename . $budgetname . $is_marryname . $requestname . $plot_name2 . $start_timename . $stylename . $bedroomname;
    
    
    if ($data['name'] && $data['phone']) {
        $result = DB::insert('zimucms_zhuangxiu_yuyue', $data);
        echo json_encode(array(
            'status' => 1
        ));
    }
    
    require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zimucms_zhuangxiu['weixin_appid'], $zimucms_zhuangxiu['weixin_appsecret']);
    
    $weixin_openid = explode("\r\n", trim($zimucms_zhuangxiu['weixin_openid']));
    
    foreach ($weixin_openid as $key => $value) {
        
        $template = array(
            'touser' => $value,
            'template_id' => $zimucms_zhuangxiu['weixin_template'],
            'url' => '',
            'topcolor' => "#7B68EE",
            'data' => array(
                'first' => array(
                    'value' => urlencode(diconv(lang('plugin/zimucms_zhuangxiu', 'system_text29'), CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["source"])), CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["type"])), CHARSET, 'utf-8'))
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($_GET['name'])) . strip_tags($_GET['phone']) . str_replace('<br>', '', strip_tags(zm_diconv($_GET['moreinfo'])) . $sizename . $budgetname . $is_marryname . $requestname . $plot_name2 . $start_timename . $stylename . $bedroomname), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
                
            )
        );
        $json     = urldecode(json_encode($template));
        if ($data['name'] && $data['phone']) {
            $result = $wechat_client->send_weixintemplate($json);
        }
        
    }
    
    if ($data['sid'] > 0) {
        
        if ($data['type'] == 1) {
            
            $shopopenid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimucms_zhuangxiu_shop',
                $data['sid']
            ));
            
        } else if ($data['type'] == 2) {
            
            $shopopenid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimucms_zhuangxiu_building',
                $data['sid']
            ));
            
        }
        
        if ($shopopenid['openid']) {
            
            $shopopenids = explode(",", trim($shopopenid['openid']));
            
            
            foreach ($shopopenids as $key => $value) {
                
                $template = array(
                    'touser' => $value,
                    'template_id' => $zimucms_zhuangxiu['weixin_template'],
                    'url' => '',
                    'topcolor' => "#7B68EE",
                    'data' => array(
                        'first' => array(
                            'value' => urlencode(diconv(lang('plugin/zimucms_zhuangxiu', 'system_text29'), CHARSET, 'utf-8')),
                            'color' => "#FF4040"
                        ),
                        'keyword1' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["source"])), CHARSET, 'utf-8'))
                        ),
                        'keyword2' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["type"])), CHARSET, 'utf-8'))
                        ),
                        'remark' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($_GET['name'])) . strip_tags($_GET['phone']) . str_replace('<br>', '', strip_tags(zm_diconv($_GET['moreinfo'])) . $sizename . $budgetname . $is_marryname . $requestname . $plot_name2 . $start_timename . $stylename . $bedroomname), CHARSET, 'utf-8')),
                            'color' => "#008000"
                        )
                        
                    )
                );
                $json     = urldecode(json_encode($template));
                if ($data['name'] && $data['phone']) {
                    $result = $wechat_client->send_weixintemplate($json);
                }
                
            }
            
        }
        
        if($shopopenid['tosms']){

            $app_key = $zimucms_zhuangxiu['ACCESS_ID']; 
            $app_secret = $zimucms_zhuangxiu['ACCESS_KEY']; 
            $sign_name = mb_convert_encoding($zimucms_zhuangxiu['smsFreeSignName'],'UTF-8',CHARSET);
            $smsdata['name'] = mb_convert_encoding($shopopenid['name'],'UTF-8',CHARSET);

            $requestUrl = "http://dysmsapi.aliyuncs.com/";
            $params['PhoneNumbers']= $shopopenid['tosms'];
            $params['SignName']= $sign_name;
            $params['TemplateCode']= $zimucms_zhuangxiu['smsTemplateCode'];
            $params['TemplateParam']= json_encode($smsdata);
            $params['OutId']= "3333";
            $params['RegionId']= "cn-hangzhou";
            $params['AccessKeyId']= $app_key;
            $params['Format']= "JSON";
            $params['SignatureMethod']= "HMAC-SHA1";
            $params['SignatureVersion']= "1.0";
            $params['SignatureNonce']= uniqid();
            date_default_timezone_set("GMT");
            $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
            $params['Action']= "SendSms";
            $params['Version']= "2017-05-25";
            $params['Signature']= aliyun_signature($params,$app_secret);

            include_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/Aliyun_HttpHelper.class.php';

            $Aliyun_HttpHelper = new Aliyun_HttpHelper();
            $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));

            $aaa = object_array(json_decode($result));
            //print_r($aaa);


        }

        if ($zimucms_zhuangxiu['magapp_hostname'] && $zimucms_zhuangxiu['magapp_secret']) {
            
            $magurl                                 = $zimucms_zhuangxiu['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
            $magpostdata['user_id']                 = $shopopenid['uid'];
            $magpostdata['type']                    = 'remind';
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#type#', $_GET["type"], $zimucms_zhuangxiu['assistant_content']);
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#name#', $_GET['name'], $zimucms_zhuangxiu['assistant_content']);
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#phone#', $_GET['phone'], $zimucms_zhuangxiu['assistant_content']);
            $magpostdata['content']                 = diconv($zimucms_zhuangxiu['assistant_content'], CHARSET, 'utf-8');
            $magpostdata['assistant_secret']        = $zimucms_zhuangxiu['assistant_secret'];
            $magpostdata['secret']                  = $zimucms_zhuangxiu['magapp_secret'];
            $magpostdata['is_push']                 = 1;
            $magdata                                = lizimu_post($magurl, $magpostdata);
            
        }
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
} else if ($model == 'bid_design') {
    $sid           = intval($_GET['sid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $share_title = $zimucms_zhuangxiu['site_city'] . $language_zimu['zimucms_zhuangxiu_inc_php_0'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    
    include template('zimucms_zhuangxiu:bid_design');
    
} else if ($model == 'bid_decoration') {
    $sid           = intval($_GET['sid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    $share_title   = $zimucms_zhuangxiu['site_city'] . $language_zimu['zimucms_zhuangxiu_inc_php_1'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    include template('zimucms_zhuangxiu:bid_decoration');
    
} else if ($model == 'bid_check') {
    $sid           = intval($_GET['sid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $share_title = $zimucms_zhuangxiu['site_city'] . $language_zimu['zimucms_zhuangxiu_inc_php_2'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    
    include template('zimucms_zhuangxiu:bid_check');
    
} else if ($model == 'bid_superv') {
    $sid           = intval($_GET['sid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $share_title = $zimucms_zhuangxiu['site_city'] . $language_zimu['zimucms_zhuangxiu_inc_php_3'] . ' - ' . $zimucms_zhuangxiu['site_title'];
    
    include template('zimucms_zhuangxiu:bid_superv');
    
} else if ($model == 'bid_visit') {
    $sid           = intval($_GET['sid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    include template('zimucms_zhuangxiu:bid_visit');
} else if ($model == 'bid_experience') {
    $bid           = intval($_GET['bid']);
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    include template('zimucms_zhuangxiu:bid_experience');
    
} else if ($model == 'xiaoguotu') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $zmdata = (array) unserialize($_G['setting']['zimucms_zhuangxiu_seo']);
    
    
    $order  = $_GET['order'] = $_GET['order'] ? $_GET['order'] : 1;
    $huxing = $_GET['huxing'] = $_GET['huxing'] ? $_GET['huxing'] : 0;
    $fengge = $_GET['fengge'] = $_GET['fengge'] ? $_GET['fengge'] : 0;
    $yusuan = $_GET['yusuan'] = $_GET['yusuan'] ? $_GET['yusuan'] : 0;
    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    
    $order  = intval($order);
    $huxing = intval($huxing);
    $fengge = intval($fengge);
    $yusuan = intval($yusuan);
    $page   = intval($page);
    
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
    
    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
    }
    
    $huxingdata = $parameterdata2['huxing'];
    $fenggedata = $parameterdata2['fengge'];
    $yusuandata = $parameterdata2['yusuan'];
    
    include_once("page.class.php");
    
    $wheresql = 'WHERE status =1 ';
    if ($huxing > 0) {
        $wheresql .= ' AND huxing = ' . $huxing;
    }
    if ($fengge > 0) {
        $wheresql .= ' AND fengge = ' . $fengge;
    }
    if ($yusuan > 0) {
        $wheresql .= ' AND yusuan = ' . $yusuan;
    }
    
    $totail   = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimucms_zhuangxiu_tuce",
        $wheresql
    ));
    $number   = 12;
    $url      = ZIMUCMS_URL . '&model=xiaoguotu&order=' . $order . '&huxing=' . $huxing . '&fengge=' . $fengge . '&yusuan=' . $yusuan . '&page={page}';
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    if ($order == 1) {
        $ordername = 'id';
    } else {
        $ordername = 'click';
    }
    $tucedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by ' . $ordername . ' desc limit %d,%d', array(
        'zimucms_zhuangxiu_tuce',
        $startnum,
        $count
    ));
    
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $share_title = $zmdata['xiaoguotu_seo_title'] ? $zmdata['xiaoguotu_seo_title'] : $zimucms_zhuangxiu['seo_title'];
    $share_desc  = $zmdata['xiaoguotu_seo_desc'] ? $zmdata['xiaoguotu_seo_desc'] : $zimucms_zhuangxiu['seo_description'];
    $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    $share_thumb = $zimucms_zhuangxiu['share_thumb'];
    
    include template('zimucms_zhuangxiu:site_xiaoguotu');
    
} else if ($model == 'news') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    include_once("page.class.php");
    
    $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
    
    
    $newstypeid = intval($_GET['newstypeid']);
    
    $thistypename = DB::result_first("SELECT typename FROM %t WHERE id=%d", array(
        "zimucms_zhuangxiu_news_type",
        $newstypeid
    ));
    
    if ($newstypeid > 0) {
        $wheresql = ' where typeid = ' . $newstypeid;
    }
    $totail   = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimucms_zhuangxiu_news",
        $wheresql
    ));
    $number   = 10;
    $url      = ZIMUCMS_URL . '&model=news&newstypeid=' . $newstypeid . '&page={page}';
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    $newsdata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_zhuangxiu_news',
        $startnum,
        $count
    ));
    
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    $randtucedata = DB::fetch_all('select * from %t order by rand() limit 3', array(
        'zimucms_zhuangxiu_tuce'
    ));
    
    include template('zimucms_zhuangxiu:site_news');
    
} else if ($model == 'viewnews') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $aid         = intval($_GET['aid']);
    $newstypeurl = strip_tags(zm_diconv($_GET['newstypeurl']));
    
    if ($aid > 0) {
        $newscon = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_zhuangxiu_news',
            $aid
        ));
        if (!$newscon) {
            header("http/1.1 404 not found");
            header("status: 404 not found");
            exit();
        }
        
        $thistypename = DB::fetch_first("select * from %t where id=%d", array(
            "zimucms_zhuangxiu_news_type",
            $newscon['typeid']
        ));
        
        $randnewsdata = DB::fetch_all('select * from %t order by rand() limit 5', array(
            'zimucms_zhuangxiu_news'
        ));
        $randtucedata = DB::fetch_all('select * from %t order by rand() limit 3', array(
            'zimucms_zhuangxiu_tuce'
        ));
        
        $share_title = $newscon['title'] . ' - ' . $zimucms_zhuangxiu['site_title'];
        $share_desc  = $zimucms_zhuangxiu['seo_description'];
        $share_url   = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
        if ($newscon['thumb'] && !preg_match('/^(http|\.)/i', $newscon['thumb'])) {
            $newscon['thumb'] = $_G['siteurl'] . $newscon['thumb'];
        }
        $share_thumb = $newscon['thumb'] ? $newscon['thumb'] : $zimucms_zhuangxiu['share_thumb'];
        
        
        include template('zimucms_zhuangxiu:site_newscon');
    }
    
} else if ($model == 'designerjson') {
    
    
    $sid = intval($_GET['sid']);
    
    $designerdata = DB::fetch_all('select id,name,sid from %t where sid=%d order by id asc', array(
        'zimucms_zhuangxiu_designer',
        $sid
    ));
    foreach ($designerdata as $key => $value) {
        $designerdata[$key]['name'] = urlencode($designerdata[$key]['name']);
    }
    
    $designerdata = json_encode($designerdata);
    echo $designerdata = urldecode($designerdata);
    
} else if ($model == 'activitylist') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    include_once("page.class.php");
    
    $typeid = $_GET['typeid'] = $_GET['typeid'] ? $_GET['typeid'] : 1;
    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $typeid = intval($typeid);
    $page   = intval($page);
    
    $totail = DB::result_first("SELECT count(*) FROM %t WHERE typeid=%d", array(
        "zimucms_zhuangxiu_activitylist",
        $typeid
    ));
    
    $number = 10;
    
    $url = ZIMUCMS_URL . '&model=activitylist&typeid=' . $typeid . '&page={page}';
    
    $my_page  = new PageClass($totail, $number, $page, $url); //�����趨���ܼ�¼��ÿҳ��ʾ����������ǰҳ�����ӵĵ�ַ
    $startnum = $my_page->page_limit;
    $count    = $my_page->myde_size;
    
    if (checkmobile()) {
        $page_string = $my_page->myde_write_wap();
    } else {
        $page_string = $my_page->myde_write();
    }
    
    $activitydata = DB::fetch_all('select * from %t where typeid=%d order by sort desc,id desc limit %d,%d', array(
        'zimucms_zhuangxiu_activitylist',
        $typeid,
        $startnum,
        $count
    ));
    
    include template('zimucms_zhuangxiu:site_activitylist');
    
} else if ($model == 'activity') {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $aid = intval($_GET['aid']);
    
    $activitydata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_activitylist',
        $aid
    ));
    
    $randdata = DB::fetch_all('select * from %t where hetime>%d order by rand() limit 5', array(
        'zimucms_zhuangxiu_activitylist',
        $_G['timestamp']
    ));

    $shoplist = explode("\r\n", trim($activitydata['shoptext']));
    foreach ($shoplist as $key => $v) {
        $shoplist[$key] = explode('|', $v);
    }
    
    include template('zimucms_zhuangxiu:site_activity');
    
} else if ($model == 'activitybtn' && $_GET['md5formhash'] == formhash()) {
    
    $data['name']     = zm_diconv(strip_tags($_GET['name']));
    $data['phone']    = strip_tags($_GET['phone']);
    $data['aid']      = intval($_GET['aid']);
    $data['aidtitle'] = zm_diconv(strip_tags($_GET['aidtitle']));
    $data['beizhu'] = $language_zimu['zimucms_zhuangxiu_inc_php_4'].zm_diconv(strip_tags($_GET['shoptext']));
    $data['addtime']  = $_G['timestamp'];
    
    if ($data['name'] && $data['phone']) {
        $result = DB::insert('zimucms_zhuangxiu_activityuser', $data);
        echo json_encode(array(
            'status' => 1
        ));
    }
    
    $aiddata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_zhuangxiu_activitylist',
        $data['aid']
    ));
    
    if ($aiddata['status'] == 1) {
        
        require_once DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zimucms_zhuangxiu['weixin_appid'], $zimucms_zhuangxiu['weixin_appsecret']);
        
        $weixin_openid = explode("\r\n", trim($zimucms_zhuangxiu['weixin_openid']));
        
        foreach ($weixin_openid as $key => $value) {
            
            $template = array(
                'touser' => $value,
                'template_id' => $zimucms_zhuangxiu['weixin_template'],
                'url' => '',
                'topcolor' => "#7B68EE",
                'data' => array(
                    'first' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_zhuangxiu', 'system_text29'), CHARSET, 'utf-8')),
                        'color' => "#FF4040"
                    ),
                    'keyword1' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_zhuangxiu', 'system_text34'), CHARSET, 'utf-8'))
                    ),
                    'keyword2' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["aidtitle"])), CHARSET, 'utf-8'))
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($_GET["name"])) . strip_tags($_GET['phone']), CHARSET, 'utf-8')),
                        'color' => "#008000"
                    )
                    
                )
            );
            $json     = urldecode(json_encode($template));
            if ($data['name'] && $data['phone']) {
                $result = $wechat_client->send_weixintemplate($json);
            }
            
        }
        
        if ($zimucms_zhuangxiu['magapp_hostname'] && $zimucms_zhuangxiu['magapp_secret']) {
            
            $magurl                                 = $zimucms_zhuangxiu['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
            $magpostdata['user_id']                 = $shopopenid['uid'];
            $magpostdata['type']                    = 'remind';
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#type#', $_GET["aidtitle"], $zimucms_zhuangxiu['assistant_content']);
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#name#', $_GET['name'], $zimucms_zhuangxiu['assistant_content']);
            $zimucms_zhuangxiu['assistant_content'] = str_replace('#phone#', $_GET['phone'], $zimucms_zhuangxiu['assistant_content']);
            $magpostdata['content']                 = diconv($zimucms_zhuangxiu['assistant_content'], CHARSET, 'utf-8');
            $magpostdata['assistant_secret']        = $zimucms_zhuangxiu['assistant_secret'];
            $magpostdata['secret']                  = $zimucms_zhuangxiu['magapp_secret'];
            $magpostdata['is_push']                 = 1;
            $magdata                                = lizimu_post($magurl, $magpostdata);
            
        }
        
    }
    
} else if ($model == 'showworktel' && $_GET['md5hash'] == formhash()) {
    
    $workid = intval($_GET['workid']);
    
    DB::query("update %t set views=views+1 where id=%d", array(
        'zimucms_zhuangxiu_workmen',
        $workid
    ));
    
} else if ($model == 'xiaoqu') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'viewxiaoqu') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'viewxiaoqu_case') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'viewxiaoqu_site') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'daily') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'viewbuildingcase') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'workmen') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'viewworkmen' || $model == 'joinworkmen') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else if ($model == 'uploader') {
    
    include DISCUZ_ROOT . './source/plugin/zimucms_zhuangxiu/module/' . $model . '.inc.php';
    
} else {
    
    $topnewsfenlei = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type_daohang');
    
    $tucedata = DB::fetch_all('select * from %t where status=1 order by id desc limit 14', array(
        'zimucms_zhuangxiu_tuce'
    ));
    foreach ($tucedata as $key => $value) {
        if ($key < 8) {
            $tucedata2[] = $value;
        } else {
            $tucedata3[] = $value;
        }
    }
    
    if (checkmobile()) {
        $newstypedata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_news_type');
    }
    
    $parameterdata = zimu_readfromcache('table_plugin_zimucms_zhuangxiu_parameter');
    
    foreach ($parameterdata as $key => $value) {
        $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
    }
    $fenggedata        = $parameterdata2['fengge'];
    $buildingtypearray = $parameterdata2['buildingtype'];
    
    
     if (checkmobile()) {
    $topshopdata = DB::fetch_all('select * from %t where status=1 and indexsort>0 order by indexsort asc limit 5', array(
        'zimucms_zhuangxiu_shop'
    ));
    
    $topbuildingdata = DB::fetch_all('select * from %t where status=1 and indexsort>0 order by indexsort asc limit 5', array(
        'zimucms_zhuangxiu_building'
    ));
     }else{
    $topshopdata = DB::fetch_all('select * from %t where status=1 and indexsort>0 order by indexsort asc limit 16', array(
        'zimucms_zhuangxiu_shop'
    ));
    
    $topbuildingdata = DB::fetch_all('select * from %t where status=1 and indexsort>0 order by indexsort asc limit 120', array(
        'zimucms_zhuangxiu_building'
    ));
     }
    
    foreach ($topbuildingdata as $key2 => $value2) {
        $topbuildingdata2[$value2['buildingtype']][] = $value2;
    }
    
    $topnewsdata = DB::fetch_all('select * from %t where istop = 1 and status = 1 order by id desc limit 5', array(
        'zimucms_zhuangxiu_news'
    ));
    
    $toutiaonewsdata = DB::fetch_first('select * from %t where istop = 2 and status = 1 order by id desc', array(
        'zimucms_zhuangxiu_news'
    ));
    
    $morenewsdata = DB::fetch_all('select * from %t where status = 1 and istop = 0 order by id desc limit 10', array(
        'zimucms_zhuangxiu_news'
    ));
    
    $tandiandata = DB::fetch_all('select * from %t where status = 1 and istop = 3 order by id desc limit 2', array(
        'zimucms_zhuangxiu_news'
    ));
    
    $tandiandata1 = DB::fetch_all('select * from %t where status = 1 and istop = 4 order by id desc limit 7', array(
        'zimucms_zhuangxiu_news'
    ));
    
    $designerdata = DB::fetch_all('select * from %t where indexsort>0 order by indexsort asc limit 10', array(
        'zimucms_zhuangxiu_designer'
    ));
    
    $xiaoquallviews = DB::result_first('select SUM(views) from %t', array(
        'zimucms_zhuangxiu_xiaoqu'
    ));
    
    $xiaoqudata = DB::fetch_all('select * from %t order by sort desc,id desc limit 8', array(
        'zimucms_zhuangxiu_xiaoqu'
    ));
    
    foreach ($xiaoqudata as $key => $value) {
        $xiaoqudata[$key]['allnums'] = DB::result_first('select count(*) from %t where xiaoqu=%d', array(
            'zimucms_zhuangxiu_tuce',
            $value['id']
        )) + DB::result_first('select count(*) from %t where xiaoqu=%d', array(
            'zimucms_zhuangxiu_gongdi',
            $value['id']
        ));
    }
    
    include template('zimucms_zhuangxiu:site_index');
    
}