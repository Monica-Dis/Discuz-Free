<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

error_reporting(0);

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_piaoliuping/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_piaoliuping');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);



$zmdata = $_G['cache']['plugin']['zimucms_piaoliuping'];


$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

function zm_diconv($str)
{
    $encode = mb_detect_encoding($str, array(
        "ASCII",
        "UTF-8",
        "GB2312",
        "GBK",
        "BIG5"
    ));
    if ($encode != CHARSET) {
        //$keytitle = iconv($encode,CHARSET."//IGNORE",$str);
        $keytitle = mb_convert_encoding($str, CHARSET, $encode);
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function isuid()
{
    global $_G;
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if (!$_G['uid']) {
            $refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_piaoliuping';
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimucms_piaoliuping/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimucms_piaoliuping/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            window.location.href="' . $refererurl . '";
  });
    </script>');
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . $_G[siteurl] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
}

function get_rand1($proArr)
{
    $result = array();
    foreach ($proArr as $key => $val) {
        $arr[$key] = $val['v'];
    }
    // ����������ܸ���  
    $proSum = array_sum($arr);
    asort($arr);
    // ��������ѭ��   
    foreach ($arr as $k => $v) {
        $randNum = mt_rand(1, $proSum);
        if ($randNum <= $v) {
            $result = $proArr[$k];
            break;
        } else {
            $proSum -= $v;
        }
    }
    return $result;
}

function get_response($secret_key, $url, $get_params, $post_data = array())
{
    $nonce         = rand(10000, 99999);
    $timestamp  = time();
    $array = array($nonce, $timestamp, $secret_key);
    sort($array, SORT_STRING);
    $token = md5(implode($array));
    $params['nonce'] = $nonce;
    $params['timestamp'] = $timestamp;
    $params['token']     = $token;
    $params = array_merge($params,$get_params);  
    $url .= '?';
    foreach ($params as $k => $v) 
    {
        $url .= $k .'='. $v . '&';
    }
    $url = rtrim($url,'&');   
    $curlHandle = curl_init();
    curl_setopt($curlHandle, CURLOPT_URL, $url);   
    curl_setopt($curlHandle, CURLOPT_HEADER, 0);   
    curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);  
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, false);  
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, FALSE);   
    curl_setopt($curlHandle, CURLOPT_POST, count($post_data));  
    curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $post_data);  
    $data = curl_exec($curlHandle);    
    $status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
    curl_close($curlHandle);    
    return $data;
}

function torandavatar($uid){
if($uid<=100){
return $uid;
}else{
return intval(substr($uid,-2));
}

}

function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }