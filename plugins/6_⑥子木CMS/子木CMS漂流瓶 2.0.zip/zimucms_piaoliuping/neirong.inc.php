<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_piaoliuping/config.php';
$model = addslashes($_GET['model']);

if ($model == 'viewmsg') {
    
    $mid = intval($_GET['mid']);
    
$plpdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_piaoliuping_data',
        $mid
    ));
     
    $stlist = DB::fetch_all('select * from %t where mid=%d order by id asc', array(
        'zimucms_piaoliuping_msgdata',
        $mid
    ));
    
    
    include template('zimucms_piaoliuping:admin_viewmsg');

} else if ($model == 'addmsg') {

    if (submitcheck('addmsg')) {

        $msglist = explode("\r\n", trim($_GET['msglist']));
        foreach ($msglist as $key => $v) {
            $msglist[$key] = explode('|', $v);
        }

foreach ($msglist as $key => $value) {

    $adddata = array(
        'uid' => $value[0],
        'username' => $value[1],
        'msg' => $value[2],
        'isreal' => 0,
        'addtime' => $_G['timestamp']
    );
    DB::insert('zimucms_piaoliuping_data', $adddata);

}

    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
    cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text1'), $url, 'succeed');

    }else{

    include template('zimucms_piaoliuping:admin_addmsg');

    }


} else if ($model == 'replymsg') {

$mid = intval($_GET['mid']);

$plpdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_piaoliuping_data',
        $mid
    ));

    if (submitcheck('replymsg')) {

if($plpdata['touid']){
    
    $adddata = array(
        'mid' => $mid,
        'uid' => $plpdata['touid'],
        'username' => $plpdata['tousername'],
        'touid' => $plpdata['uid'],
        'tousername' => $plpdata['username'],
        'msg' => addslashes($_GET['tomsg']),
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimucms_piaoliuping_msgdata', $adddata);

    $addata2['uptime']     = $_G['timestamp'];
    DB::update('zimucms_piaoliuping_data', $addata2, array(
        'id' => $mid
        ));


}else{

    $addata['touid']      = intval($_GET['touid']);
    $addata['tousername'] = $_GET['tousername'];
    $addata['tomsg']      = addslashes($_GET['tomsg']);
    $addata['uptime']     = $_G['timestamp'];
    
    DB::update('zimucms_piaoliuping_data', $addata, array(
        'id' => $mid
    ));


}



    $pmcon = str_replace('name',$plpdata['username'],$zmdata['notice_text']);
    sendpm($plpdata['uid'],$pmcon,$pmcon,$fromid = $zmdata['notice_uid']);

if($zmdata['qf_hostname'] && $zmdata['qf_secret']){

$url = 'http://'.$zmdata['qf_hostname'].'.qianfanapi.com/api1_2/easemob/send-message';
$secret_key = $zmdata['qf_secret'];
$get_params = array(
                //'side_id'=>118626,
                //'user_id'=>1522202,
                //'content'=>'���',
            );
$post_data = array(
                'sender'=>''.$zmdata['notice_uid'].'',
                'receiver'=>''.$plpdata['uid'].'',
                'message'=>diconv($pmcon,CHARSET,'utf-8').ZIMUCMS_URL
            );
$ret = get_response($secret_key,$url,$get_params,$post_data);
}


if($zmdata['magapp_hostname'] && $zmdata['magapp_secret']){

if($zmdata['is_assistant']){

    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $plpdata['uid'];
    $magpostdata['type'] = $zmdata['assistant_type'];
    $magpostdata['content'] = diconv($zmdata['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);

}else{
    
    $magurl = $zmdata['magapp_hostname'].'/mag/push/v1/push/sendPush';
    $magpostdata['user_id'] = $plpdata['uid'];
    $magpostdata['title'] = 'lizimu';
    $magpostdata['content'] = diconv($pmcon,CHARSET,'utf-8');
    $magpostdata['link'] = ZIMUCMS_URL;
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magdata = lizimu_post($magurl,$magpostdata);

}


}

    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
    cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text1'), $url, 'succeed');


    }else{

include template('zimucms_piaoliuping:admin_replymsg');

    }

} else if ($model == 'replymsg2') {

$mid = intval($_GET['mid']);

$plpdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimucms_piaoliuping_data',
        $mid
    ));

    if (submitcheck('replymsg2')) {


    $adddata = array(
        'mid' => $mid,
        'uid' => $plpdata['uid'],
        'username' => $plpdata['username'],
        'touid' => $plpdata['touid'],
        'tousername' => $plpdata['tousername'],
        'msg' => addslashes($_GET['tomsg']),
        'addtime' => $_G['timestamp']
    );

    DB::insert('zimucms_piaoliuping_msgdata', $adddata);

    $addata2['uptime']     = $_G['timestamp'];
    DB::update('zimucms_piaoliuping_data', $addata2, array(
        'id' => $mid
        ));




    $pmcon = str_replace('name',$plpdata['tousername'],$zmdata['notice_text']);
    sendpm($plpdata['touid'],$pmcon,$pmcon,$fromid = $zmdata['notice_uid']);


if($zmdata['qf_hostname'] && $zmdata['qf_secret']){

$url = 'http://'.$zmdata['qf_hostname'].'.qianfanapi.com/api1_2/easemob/send-message';
$secret_key = $zmdata['qf_secret'];
$get_params = array(
                //'side_id'=>118626,
                //'user_id'=>1522202,
                //'content'=>'���',
            );
$post_data = array(
                'sender'=>''.$zmdata['notice_uid'].'',
                'receiver'=>''.$plpdata['touid'].'',
                'message'=>diconv($pmcon,CHARSET,'utf-8').ZIMUCMS_URL
            );
$ret = get_response($secret_key,$url,$get_params,$post_data);
}


if($zmdata['magapp_hostname'] && $zmdata['magapp_secret']){

if($zmdata['is_assistant']){

    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $plpdata['touid'];
    $magpostdata['type'] = $zmdata['assistant_type'];
    $magpostdata['content'] = diconv($zmdata['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);

}else{
    
    $magurl = $zmdata['magapp_hostname'].'/mag/push/v1/push/sendPush';
    $magpostdata['user_id'] = $plpdata['touid'];
    $magpostdata['title'] = 'lizimu';
    $magpostdata['content'] = diconv($pmcon,CHARSET,'utf-8');
    $magpostdata['link'] = ZIMUCMS_URL;
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magdata = lizimu_post($magurl,$magpostdata);

}


}


    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
    cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text1'), $url, 'succeed');


    }else{

include template('zimucms_piaoliuping:admin_replymsg2');

    }




} else if ($model == 'delviewmsg' && $_GET['md5formhash'] == formhash()) {
    
    $mid  = intval($_GET['mid']);
    $mid2 = intval($_GET['mid2']);
    
    $result = DB::delete('zimucms_piaoliuping_msgdata', array(
        'id' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&model=viewmsg&mid=' . $mid2 . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text2'), '', 'error');
    }
    
} else if ($model == 'delmsg' && $_GET['md5formhash'] == formhash()) {
    
    $mid = intval($_GET['mid']);
    
    $result = DB::delete('zimucms_piaoliuping_data', array(
        'id' => $mid
    ));
    DB::delete('zimucms_piaoliuping_msgdata', array(
        'mid' => $mid
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_piaoliuping', 'system_text2'), '', 'error');
    }
    
} else {
    

    $uid      = intval($_GET['uid']);
    $username = strip_tags($_GET['username']);
    $msg = strip_tags($_GET['msg']);
    
    
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);
    
    $msg = dhtmlspecialchars($msg);
    $msg = stripsearchkey($msg);
    $msg = daddslashes($msg);

    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    

    if ($uid > 0) {
        $wherearr[] = DB::field('uid', $uid) . ' OR ' . DB::field('touid', $uid);
    }

    
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "username LIKE '%{text}%' or tousername LIKE '%{text}%'");
    }
    if ($msg) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($msg, "msg LIKE '%{text}%' or tomsg LIKE '%{text}%'");
    }

    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);

    $count = DB::result_first("SELECT count(*) FROM %t WHERE %i", array(
        "zimucms_piaoliuping_data",
        $wheresql
    ));
    
    $limit    = 30;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    
    $stlist = DB::fetch_all('select * from %t where %i order by id desc limit %d,%d', array(
        'zimucms_piaoliuping_data',
        $wheresql,
        $start,
        $limit
    ));
    
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
    }
    
    
    include template('zimucms_piaoliuping:admin_list');
    
}