<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_piaoliuping/config.php';

if ($zmdata['weixin_appid'] && $zmdata['weixin_appsecret']) {
    require_once DISCUZ_ROOT . './source/plugin/zimucms_piaoliuping/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage();
}

$model = addslashes($_GET['model']);

if ($model == 'msg' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $todaytime  = strtotime(date('Y-m-d', $_G['timestamp']));
    $todaytime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d AND addtime>%d AND addtime<%d", array(
        "zimucms_piaoliuping_data",
        $_G['uid'],
        $todaytime,
        $todaytime2
    ));
    
    if ($count >= $zmdata['rengnums2']) {
        $out['status'] = 3;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_piaoliuping', 'system_text3') . $zmdata['rengnums2'] . lang('plugin/zimucms_piaoliuping', 'system_text4'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    $adddata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'msg' => strip_tags(zm_diconv($_GET['floater_msg'])),
        'addtime' => $_G['timestamp']
    );
    $result  = DB::insert('zimucms_piaoliuping_data', $adddata);
    if ($result) {
        $out['status'] = '1';
        echo $result2 = json_encode($out);
        exit();
    }
    
} else if ($model == 'topick' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    
    $todaytime  = strtotime(date('Y-m-d', $_G['timestamp']));
    $todaytime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND addtime>%d AND addtime<%d", array(
        "zimucms_piaoliuping_data",
        $_G['uid'],
        $todaytime,
        $todaytime2
    ));
    
    if ($count >= $zmdata['jiannums2']) {
        $out['status'] = '3';
        echo $result2 = json_encode($out);
        exit();
    }
    
    
    $arr = array(
        array(
            'id' => 1,
            'v' => $zmdata['jiangailv']
        ),
        array(
            'id' => 2,
            'v' => 100 - $zmdata['jiangailv']
        )
    );
    
    $myarr = get_rand1($arr);
    
    if ($myarr['id'] == 1) {
        
        $randdata = DB::result_first('select id from %t where touid <= 0 and uid != %d order by rand() limit 1', array(
            'zimucms_piaoliuping_data',
            $_G['uid']
        ));
        
        if ($randdata) {
            $out['status'] = '1';
            $out['msgid']  = $randdata;
            echo $result2 = json_encode($out);
            exit();
        } else {
            
            $out['status'] = '2';
            echo $result2 = json_encode($out);
            exit();
            
        }
    } else {
        
        $out['status'] = '2';
        echo $result2 = json_encode($out);
        exit();
        
    }
    
} else if ($model == 'view' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $floaterId = intval($_GET['floaterId']);
    
    $list           = DB::fetch_first('select * from %t where id = %d', array(
        'zimucms_piaoliuping_data',
        $floaterId
    ));
    $list['gender'] = DB::result_first('select gender from %t where uid = %d', array(
        'common_member_profile',
        $list['uid']
    ));

/*    
    if ($list['uid'] != $_G['uid']) {
        $addata['touid']      = $_G['uid'];
        $addata['tousername'] = $_G['username'];
        $addata['uptime']     = $_G['timestamp'];
        $result               = DB::update('zimucms_piaoliuping_data', $addata, array(
            'id' => $floaterId
        ));
    }
 */

    
    include template('zimucms_piaoliuping:view');
    
} else if ($model == 'driftToSea' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $floaterId = intval($_GET['throwBack_id']);
    
    $addata['touid']      = '';
    $addata['tousername'] = '';
    $addata['uptime']     = '';
    $result               = DB::update('zimucms_piaoliuping_data', $addata, array(
        'id' => $floaterId
    ));
    $out['status']        = '1';
    echo $result2 = json_encode($out);
    exit();
    
} else if ($model == 'replymsg' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $floaterId = intval($_GET['floater_id']);

    $floaterdata           = DB::fetch_first('select * from %t where id = %d', array(
        'zimucms_piaoliuping_data',
        $floaterId
    ));

    $addata['touid']      = $_G['uid'];
    $addata['tousername'] = $_G['username'];
    $addata['tomsg']      = strip_tags(zm_diconv($_GET['reply_msg']));
    $addata['uptime']     = $_G['timestamp'];
    
    $result        = DB::update('zimucms_piaoliuping_data', $addata, array(
        'id' => $floaterId
    ));

    $pmcon = str_replace('name',$floaterdata['username'],$zmdata['notice_text']); 
    sendpm($floaterdata['uid'],$pmcon,$pmcon,$fromid = $zmdata['notice_uid']);

if(IN_QFAPP && $zmdata['qf_hostname'] && $zmdata['qf_secret']){
$url = 'http://'.$zmdata['qf_hostname'].'.qianfanapi.com/api1_2/easemob/send-message';
$secret_key = $zmdata['qf_secret'];
$get_params = array(
                //'side_id'=>118626,
                //'user_id'=>1522202,
                //'content'=>'���',
            );
$post_data = array(
                'sender'=>''.$zmdata['notice_uid'].'',
                'receiver'=>''.$floaterdata['uid'].'',
                'message'=>diconv($pmcon,CHARSET,'utf-8').ZIMUCMS_URL
            );
$ret = get_response($secret_key,$url,$get_params,$post_data);
}


if(IN_MAGAPP && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){

if($zmdata['is_assistant']){

    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $floaterdata['uid'];
    $magpostdata['type'] = $zmdata['assistant_type'];
    $magpostdata['content'] = diconv($zmdata['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);

}else{

    $magurl = $zmdata['magapp_hostname'].'/mag/push/v1/push/sendPush';
    $magpostdata['user_id'] = $floaterdata['uid'];
    $magpostdata['title'] = 'lizimu';
    $magpostdata['content'] = diconv($pmcon,CHARSET,'utf-8');
    $magpostdata['link'] = ZIMUCMS_URL;
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magdata = lizimu_post($magurl,$magpostdata);

}


}


    $out['status'] = '1';
    echo $result2 = json_encode($out);
    exit();
    
} else if ($model == 'mybottole') {
    
    isuid();
    
    $aaa = DB::query('select a.*,b.gender from %t a left join %t b on a.uid = b.uid where a.touid=%d order by uptime desc', array(
        'zimucms_piaoliuping_data',
        'common_member_profile',
        $_G['uid']
    ));
    while ($res = DB::fetch($aaa)) {
        $m_info_arr[] = $res;
    }
$m_info_arr_nums = 0;
foreach ($m_info_arr as $key => $value) {
$m_info_arr[$key]['isread2'] = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND mid=%d AND isread=0", array(
        "zimucms_piaoliuping_msgdata",
        $_G['uid'],
        $value['id']
    ));
$m_info_arr_nums = $m_info_arr_nums+$m_info_arr[$key]['isread2'];
}
    
    $bbb = DB::query('select a.*,b.gender from %t a left join %t b on a.uid=b.uid where a.uid=%d order by a.uptime desc', array(
        'zimucms_piaoliuping_data',
        'common_member_profile',
        $_G['uid']
    ));
    while ($res = DB::fetch($bbb)) {
        $m_thr_info_arr[] = $res;
    }
$m_thr_info_arr_nums = 0;
foreach ($m_thr_info_arr as $key => $value) {
if($value['isread']==0 && $value['touid'] > 0){
$m_thr_info_arr_nums = $m_thr_info_arr_nums+1;
}
$m_thr_info_arr[$key]['isread2'] = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND mid=%d AND isread=0", array(
        "zimucms_piaoliuping_msgdata",
        $_G['uid'],
        $value['id']
    ));
$m_thr_info_arr_nums = $m_thr_info_arr_nums+$m_thr_info_arr[$key]['isread2'];
}

    include template('zimucms_piaoliuping:mybottole');
    


} else if ($model == 'mybottole2') {
    
    isuid();
    
    $aaa = DB::query('select a.*,b.gender from %t a left join %t b on a.uid = b.uid where a.touid=%d order by uptime desc', array(
        'zimucms_piaoliuping_data',
        'common_member_profile',
        $_G['uid']
    ));
    while ($res = DB::fetch($aaa)) {
        $m_info_arr[] = $res;
    }
$m_info_arr_nums = 0;
foreach ($m_info_arr as $key => $value) {
$m_info_arr[$key]['isread2'] = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND mid=%d AND isread=0", array(
        "zimucms_piaoliuping_msgdata",
        $_G['uid'],
        $value['id']
    ));
$m_info_arr_nums = $m_info_arr_nums+$m_info_arr[$key]['isread2'];
}
    
    $bbb = DB::query('select a.*,b.gender from %t a left join %t b on a.uid=b.uid where a.uid=%d order by a.uptime desc', array(
        'zimucms_piaoliuping_data',
        'common_member_profile',
        $_G['uid']
    ));
    while ($res = DB::fetch($bbb)) {
        $m_thr_info_arr[] = $res;
    }
$m_thr_info_arr_nums = 0;
foreach ($m_thr_info_arr as $key => $value) {
if($value['isread']==0 && $value['touid'] > 0){
$m_thr_info_arr_nums = $m_thr_info_arr_nums+1;
}
$m_thr_info_arr[$key]['isread2'] = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND mid=%d AND isread=0", array(
        "zimucms_piaoliuping_msgdata",
        $_G['uid'],
        $value['id']
    ));
$m_thr_info_arr_nums = $m_thr_info_arr_nums+$m_thr_info_arr[$key]['isread2'];
}

    include template('zimucms_piaoliuping:mybottole2');

} else if ($model == 'myview') {
    
    isuid();
    
    $floaterId = intval($_GET['floaterId']);
    
    $list           = DB::fetch_first('select * from %t where id = %d', array(
        'zimucms_piaoliuping_data',
        $floaterId
    ));
    $list['gender'] = DB::result_first('select gender from %t where uid = %d', array(
        'common_member_profile',
        $list['uid']
    ));
    
    $msgdata = DB::fetch_all('select * from %t where mid = %d order by id asc', array(
        'zimucms_piaoliuping_msgdata',
        $floaterId
    ));
    
    include template('zimucms_piaoliuping:myview');
    
} else if ($model == 'myview2') {
    
    isuid();
    
    $floaterId = intval($_GET['floaterId']);
    
    $list             = DB::fetch_first('select * from %t where id = %d', array(
        'zimucms_piaoliuping_data',
        $floaterId
    ));
    
    $list['togender'] = DB::result_first('select gender from %t where uid = %d', array(
        'common_member_profile',
        $list['touid']
    ));
    
    $msgdata = DB::fetch_all('select * from %t where mid = %d order by id asc', array(
        'zimucms_piaoliuping_msgdata',
        $floaterId
    ));
    
    include template('zimucms_piaoliuping:myview2');
    
} else if ($model == 'tomsgdata' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $floater_id = intval($_GET['floater_id']);
    $reply_msg  = strip_tags(zm_diconv($_GET['reply_msg']));
    $touid      = intval($_GET['touid']);
    $tousername = strip_tags(zm_diconv($_GET['tousername']));
    
    $adddata = array(
        'mid' => $floater_id,
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'touid' => $touid,
        'tousername' => $tousername,
        'msg' => $reply_msg,
        'addtime' => $_G['timestamp']
    );
    $result  = DB::insert('zimucms_piaoliuping_msgdata', $adddata);

    $addata2['uptime']     = $_G['timestamp'];
    DB::update('zimucms_piaoliuping_data', $addata2, array(
        'id' => $floater_id
        ));

        $pmcon = str_replace('name',$tousername,$zmdata['notice_text']);
        sendpm($touid,$pmcon,$pmcon,$fromid = $zmdata['notice_uid']);

if(IN_QFAPP && $zmdata['qf_hostname'] && $zmdata['qf_secret']){
$url = 'http://'.$zmdata['qf_hostname'].'.qianfanapi.com/api1_2/easemob/send-message';
$secret_key = $zmdata['qf_secret'];
$get_params = array(
                //'side_id'=>118626,
                //'user_id'=>1522202,
                //'content'=>'���',
            );
$post_data = array(
                'sender'=>''.$zmdata['notice_uid'].'',
                'receiver'=>''.$touid.'',
                'message'=>diconv($pmcon,CHARSET,'utf-8').ZIMUCMS_URL
            );
$ret = get_response($secret_key,$url,$get_params,$post_data);
}


if(IN_MAGAPP && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){


if($zmdata['is_assistant']){

    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $touid;
    $magpostdata['type'] = $zmdata['assistant_type'];
    $magpostdata['content'] = diconv($zmdata['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);

}else{  

    $magurl = $zmdata['magapp_hostname'].'/mag/push/v1/push/sendPush';
    $magpostdata['user_id'] = $touid;
    $magpostdata['title'] = 'lizimu';
    $magpostdata['content'] = diconv($pmcon,CHARSET,'utf-8');
    $magpostdata['link'] = ZIMUCMS_URL;
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magdata = lizimu_post($magurl,$magpostdata);
    
}



}

    if ($result) {
        $out['status'] = '1';
        echo $result2 = json_encode($out);
        exit();
    }
    
} else if ($model == 'delmsg' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $floaterId = intval($_GET['floaterId']);
    
    DB::delete('zimucms_piaoliuping_data', array(
        'id' => $floaterId
    ));
    DB::delete('zimucms_piaoliuping_msgdata', array(
        'mid' => $floaterId
    ));
    $out['status'] = '1';
    echo $result2 = json_encode($out);
    exit();

} else if ($model == 'toisread' && $_GET['md5hash'] == formhash()) {  

    isuid();
    
    $floaterId = intval($_GET['floaterId']);

    $addata['isread']     = 1;
    DB::update('zimucms_piaoliuping_msgdata', $addata, array(
        'mid' => $floaterId,
        'touid' => $_G['uid'],
        ));

} else if ($model == 'toisread2' && $_GET['md5hash'] == formhash()) {  

    isuid();
    
    $floaterId = intval($_GET['floaterId']);

    $addata['isread']     = 1;
    DB::update('zimucms_piaoliuping_data', $addata, array(
        'id' => $floaterId
        ));

    DB::update('zimucms_piaoliuping_msgdata', $addata, array(
        'mid' => $floaterId,
        'touid' => $_G['uid'],
        ));
    

} else {
    
    isuid();

    $mybottolenums1 = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d AND touid>0 AND isread=0", array(
        "zimucms_piaoliuping_data",
        $_G['uid']
    ));
    $mybottolenums2 = DB::result_first("SELECT count(*) FROM %t WHERE touid=%d AND isread=0", array(
        "zimucms_piaoliuping_msgdata",
        $_G['uid']
    ));
    $mybottolenums = $mybottolenums1+$mybottolenums2;
    include template('zimucms_piaoliuping:newindex');
}