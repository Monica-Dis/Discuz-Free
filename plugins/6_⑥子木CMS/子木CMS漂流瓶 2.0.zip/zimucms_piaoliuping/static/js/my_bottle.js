// JavaScript Document
$(document).ready(function () {
	
	var bodyHeight = $(window).height();
	var bodyWidth = $(window).width();
	
	var $main = $("#main");
	$main.css("width", bodyWidth - 42);
	$main.css("height", bodyHeight - 58);
	var $bottleBtnContent = $("#bottle_btn_content");
	$bottleBtnContent.css("width", $main.width() - 2);
	var $bottleBtn = $(".bottle_btn");
	$bottleBtn.css("width", ($main.width() - 3)/2 );
	var $bottleContent = $(".bottle_content");
	$bottleContent.css("width", $main.width() - 32);
	$bottleContent.css("height", $main.height() - 150);
	var $backToIndex = $(".back_to_index");
	$backToIndex.css("width", $main.width());
	var $deleteContent = $("#delete_content");
	$deleteContent.css("padding-top", bodyHeight * 3/8);
	$deleteContent.css("padding-bottom", bodyHeight * 3/8);
	$deleteContent.css("width", bodyWidth - 62);
	$deleteContent.css("height", bodyHeight/4);
	var $yesBtn = $("#yes_btn");
	var $cancelBtn = $("#cancel_btn");
	var $bottleReceive = $("#bottle_receive");
	var $bottleDrift = $("#bottle_drift");
	$bottleBtn.on("click", function(){
		var bottleId = $(this).attr("data-bottle");
		$(".bottle_content").hide();
		$(bottleId).show();
		
		$bottleBtn.removeClass("bottle_btn_active");
		$(this).addClass("bottle_btn_active");
	});
	
	$(document).on("click",".delete_btn", function(){//我的瓶子页面上的删除按钮点击事件
		var dataId = $(this).attr("data-id");//瓶子的id
		alert(dataId);
		$deleteContent.show();
		$yesBtn.attr("data-id", dataId);
	});
//	$(".delete_btn").on("click", function(){

//		

//	});

	$cancelBtn.on("click", function(){
		$deleteContent.hide();
	});
})