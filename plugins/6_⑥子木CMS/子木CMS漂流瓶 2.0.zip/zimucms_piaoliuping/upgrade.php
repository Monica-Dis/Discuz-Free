<?php
/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_piaoliuping_data'));
$usernamearray = mysqltoarray($username);
if (!in_array('isread', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_piaoliuping_data` ADD COLUMN `isread` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0';
EOF;
    runquery($sql1);
}

if (!in_array('isreal', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_piaoliuping_data` ADD COLUMN `isreal` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}

$username2 = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_piaoliuping_msgdata'));
$usernamearray2 = mysqltoarray($username2);
if (!in_array('isread', $usernamearray2)) {
    $sql2 = <<<EOF
ALTER TABLE  `pre_zimucms_piaoliuping_msgdata` ADD COLUMN `isread` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0';
EOF;
    runquery($sql2);
}

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
