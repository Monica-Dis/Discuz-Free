<?php

/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_magappmobile_code'));
$usernamearray = mysqltoarray($username);

if (!in_array('type', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` ADD COLUMN `type` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('status', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` ADD COLUMN `status` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0';
EOF;
    runquery($sql1);
}

if (!in_array('uid', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` ADD COLUMN `uid` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}


if (!in_array('username', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` ADD COLUMN `username` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('ip', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` ADD COLUMN `ip` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);
}

    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_magappmobile_code` CHANGE  `code`  `code` INT( 10 ) UNSIGNED NOT NULL
EOF;
    runquery($sql1);

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
