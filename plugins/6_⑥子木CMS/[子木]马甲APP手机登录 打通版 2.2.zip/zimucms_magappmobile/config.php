<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

function sms_send($mobile, $data, $template_code) 
{ 

global $_G;
$zmdata = $_G['cache']['plugin']['zimucms_magappmobile'];
// �������� 
$api_url = 'http://gw.api.taobao.com/router/rest'; 
$app_key = $zmdata['appid']; 
$app_secret = $zmdata['secret']; 
$sign_name = mb_convert_encoding($zmdata['name'],'UTF-8',CHARSET); // ����ǩ�� 

// �������� 
$params["method"] = 'alibaba.aliqin.fc.sms.num.send'; 
$params["app_key"] = $app_key; 
$params["timestamp"] = date("Y-m-d H:i:s"); 
$params["format"] = 'json'; 
$params["v"] = '2.0'; 
$params["sign_method"] = 'md5'; 

// ������� 
$params["sms_type"] = 'normal'; 
$params["sms_free_sign_name"] = $sign_name; 
$params["sms_param"] = json_encode($data); 
$params["rec_num"] = $mobile; 
$params["sms_template_code"] = $template_code; 

// ǩ������ 
ksort($params); 
$signed = $app_secret; 

foreach ($params as $key => $value) 
{ 
if(is_string($value) && "@" != substr($value, 0, 1)) 
{ 
$signed .= "$key$value"; 
} 
} 
unset($key, $value); 

$signed .= $app_secret; 
$params["sign"] = strtoupper(md5($signed)); 

// ���Ͷ��� 
$result = lizimu_post($api_url, $params); 
return $result; 
}



function aliyun_sms_send($mobile, $data, $template_code){

global $_G;
$zmdata = $_G['cache']['plugin']['zimucms_magappmobile'];

$app_key = $zmdata['appid']; 
$app_secret = $zmdata['secret']; 
$sign_name = mb_convert_encoding($zmdata['name'],'UTF-8',CHARSET);

    $requestUrl = "http://dysmsapi.aliyuncs.com/";
    $params['PhoneNumbers']= $mobile;
    $params['SignName']= $sign_name;
    $params['TemplateCode']= $template_code;
    $params['TemplateParam']= json_encode($data);
    $params['OutId']= "3333";
    $params['RegionId']= "cn-hangzhou";
    $params['AccessKeyId']= $app_key;
    $params['Format']= "JSON";
    $params['SignatureMethod']= "HMAC-SHA1";
    $params['SignatureVersion']= "1.0";
    $params['SignatureNonce']= uniqid();
    date_default_timezone_set("GMT");
    $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
    $params['Action']= "SendSms";
    $params['Version']= "2017-05-25";
    $params['Signature']= aliyun_signature($params,$app_secret);

    include_once DISCUZ_ROOT . './source/plugin/zimucms_magappmobile/class/Aliyun_HttpHelper.class.php';

    $Aliyun_HttpHelper = new Aliyun_HttpHelper();
    $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));
    return $result;
    
}


function sms_send3($RecNum,$ParamString,$TemplateCode){

global $_G;
$zmdata = $_G['cache']['plugin']['zimucms_magappmobile'];

$SignName = mb_convert_encoding($zmdata['name'],'UTF-8',CHARSET);

 $host = "http://sms.market.alicloudapi.com";
    $path = "/singleSendSms";
    $method = "GET";
    $appcode = $zmdata['appid'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "ParamString=".json_encode($ParamString)."&RecNum=".$RecNum."&SignName=".$SignName."&TemplateCode=".$TemplateCode;
    $bodys = "";
    $url = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    $result = curl_exec($curl);
    return $result;

}


function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}


function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}