<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!$_G['uid']) {
    return;
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_magappmobile/config.php';

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_magappmobile/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_magappmobile');
define('SITE_URL', $_G['siteurl']);

$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_magappmobile'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


$model = addslashes($_GET['model']);

$isbind = DB::fetch_first('select * from %t where userid=%d order by id desc', array(
    'user_mobile_relations',
    $_G['uid']
));


if ($_G['uid'] && submitcheck("bindsubmit")) {
    
    
    $myphone = trim(daddslashes($_POST['myphone']));
    $mycode  = trim(daddslashes($_POST['mycode']));
    $type = intval($_GET['type']);

    if (empty($mycode) || empty($myphone)) {
        showmessage(lang('plugin/zimucms_magappmobile', 'system_text1'));
        exit();
    }
    
    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=%d and status=0 order by id desc', array(
        'zimucms_magappmobile_code',
        $myphone,
        $mycode,
        $_G['timestamp'] - $zmdata['codetime']*60,
        $type
    ));
    
    if (!$iscode) {
        showmessage(lang('plugin/zimucms_magappmobile', 'system_text2'));
        exit();
    } else {
        
        $editdata['userid']      = $_G['uid'];
        $editdata['phone']       = $myphone;
        $editdata['create_time'] = $_G['timestamp'];
        $result                  = DB::insert('user_mobile_relations', $editdata);
        
        DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
            'mobile' => $myphone,
            'code' => $mycode,
            'type' => $type,
            ));
        
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => $myphone
        ));
        if ($result) {
            
            showmessage(lang('plugin/zimucms_magappmobile', 'tpl_text13'), dreferer());
            
        } else {
            
            showmessage(lang('plugin/zimucms_magappmobile', 'tpl_text14'));
        }
        
    }
    
    
    
}

if ($_G['uid'] && submitcheck("unbindsubmit")) {
    loaducenter();
    list($result) = uc_user_login($_G['uid'], $_GET['userpassword'], 1, 0);
    
    if ($result >= 0) {
        $result = DB::delete('user_mobile_relations', array(
            'userid' => $_G['uid']
        ));
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => ''
        ));
        
        showmessage(lang('plugin/zimucms_magappmobile', 'tpl_text10'), dreferer());
    } else {
        showmessage('login_password_invalid');
    }
}


if ($_G['uid'] && submitcheck("changesubmit")) {
    loaducenter();
    list($result) = uc_user_login($_G['uid'], $_GET['userpassword'], 1, 0);
    
    if ($result >= 0) {


    $myphone = trim(daddslashes($_POST['myphone']));
    $mycode  = trim(daddslashes($_POST['mycode']));
    $type = intval($_GET['type']);

    if (empty($mycode) || empty($myphone)) {
        showmessage(lang('plugin/zimucms_magappmobile', 'system_text1'));
        exit();
    }
    
    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=%d and status=0 order by id desc', array(
        'zimucms_magappmobile_code',
        $myphone,
        $mycode,
        $_G['timestamp'] - $zmdata['codetime']*60,
        $type
    ));

    if (!$iscode) {
        showmessage(lang('plugin/zimucms_magappmobile', 'system_text2'));
        exit();
    } else {

        DB::update('user_mobile_relations',array('phone' => $myphone), array(
            'userid' => $_G['uid']
            ));

        DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
            'mobile' => $myphone,
            'code' => $mycode,
            'type' => $type,
            ));
        
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => $myphone
        ));
        
        showmessage(lang('plugin/zimucms_magappmobile', 'tpl_text12'), dreferer());
        
    }
    } else {
        showmessage('login_password_invalid');
    }
}