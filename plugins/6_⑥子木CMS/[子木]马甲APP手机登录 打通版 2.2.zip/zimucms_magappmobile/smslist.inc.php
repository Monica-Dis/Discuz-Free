<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$model = addslashes($_GET['model']);
$formhash = $_G['formhash'];
if(!$model){
$model = 'userlist';
}
if ($model == 'userlist') {
    
    $username = strip_tags($_GET['username']);
    
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "mobile LIKE '%{text}%'");
    }
    
    
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE %i", array(
        "zimucms_magappmobile_code",
        $wheresql
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

    $userlist = DB::fetch_all('select * from %t where %i order by id desc limit %d,%d', array(
        'zimucms_magappmobile_code',
        $wheresql,
        $start,
        $limit
    ));

    if ($page_num > 1) {

if(!is_null($_GET['subscribe'])){

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model . '&subscribe=' . intval($_GET['subscribe']), '10000', '20', TRUE, TRUE);
}else{
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model, '10000', '20', TRUE, TRUE);

}


    }
    
    
    
    include template('zimucms_magappmobile:smslist');
    
    
}