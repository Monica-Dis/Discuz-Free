<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$model = addslashes($_GET['model']);
$formhash = $_G['formhash'];
if(!$model){
$model = 'userlist';
}
if ($model == 'userlist') {
    
    
    
    $userid      = intval($_GET['uid']);
    $username = strip_tags($_GET['username']);
    
    
    $username = dhtmlspecialchars($username);
    $username = stripsearchkey($username);
    $username = daddslashes($username);
    
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    //$subscribe = intval($_GET['subscribe']);

    if ($userid > 0) {
        $wherearr[] = DB::field('userid', $userid);
    }
    
    if ($username) {
        include_once libfile('function/search');
        $wherearr[] = ' 1 ' . searchkey($username, "phone LIKE '%{text}%'");
    }
    
    
    $wheresql = empty($wherearr) ? '1' : implode(' AND ', $wherearr);
    
    $count = DB::result_first("SELECT count(*) FROM %t WHERE %i", array(
        "user_mobile_relations",
        $wheresql
    ));
    
    $limit    = 10;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);

$aaa = DB::query('select a.*,b.username,b.credits from %t a left join %t b on a.userid=b.uid where %i order by id desc limit %d,%d', array('user_mobile_relations','common_member',$wheresql,$start,$limit));

    while($res = DB::fetch($aaa)){
           $userlist[] = $res;
        }

    if ($page_num > 1) {

if(!is_null($_GET['subscribe'])){

        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model . '&subscribe=' . intval($_GET['subscribe']), '10000', '20', TRUE, TRUE);
}else{
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&model=' . $model, '10000', '20', TRUE, TRUE);

}


    }
    
    
    
    include template('zimucms_magappmobile:userlist');
    
} else if ($model == 'tobinduser' && $_GET['md5formhash'] == formhash()) {

    $touid = intval($_GET['touid']);
    $tousername = addslashes($_GET['tousername']);

    $isbind = DB::result_first('select id from %t where userid=%d order by id desc', array(
        'user_mobile_relations',
        $touid
    ));

    if($isbind){

        DB::update('user_mobile_relations',array('phone' => $tousername), array(
            'userid' => $touid
            ));

    }else{

        $editdata['userid']      = $touid;
        $editdata['phone']       = $tousername;
        $editdata['create_time'] = $_G['timestamp'];
        $result                  = DB::insert('user_mobile_relations', $editdata);

    }

    $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
    cpmsg(lang('plugin/zimucms_magappmobile', 'tpl_text12'), $url, 'succeed');


} else if ($model == 'delbind' && $_GET['md5formhash'] == formhash()) {

    $userid = intval($_GET['userid']);

    $result = DB::delete('user_mobile_relations', array(
        'userid' => $userid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_magappmobile', 'tpl_text10'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_magappmobile', 'tpl_text11'), '', 'error');
    }

} else if ($model == 'toexcel') {

    $detail = '';

    $aaa = DB::query('select a.userid,b.username,a.phone from %t a left join %t b on a.userid=b.uid order by id desc', array('user_mobile_relations','common_member'));

    while($res = DB::fetch($aaa)){
           $userlist[] = $res;
    }

    foreach($userlist as $key=>$value) {
        foreach($value as $key2 => $value2) {
            $value2 = preg_replace('/\s+/', ' ', $value2);
            $detail .= strlen($value2) > 11 && is_numeric($value2) ? '['.$value2.'],' : $value2.',';
        }
        $detail = $detail."\n";
    }

    $detail = "UID,".$lang['username'].",Phone,"."\n".$detail;
    $filename = date('Ymd', TIMESTAMP).'.csv';
    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');
    if($_G['charset'] != 'gbk') {
        $detail = diconv($detail, $_G['charset'], 'GBK');
    }
    echo $detail;
    exit();




}