<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_magappmobile/config.php';

loadcache('plugin');
//插件目录常量
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_magappmobile/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_magappmobile');
define('SITE_URL', $_G['siteurl']);

$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_magappmobile'];


$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


$model = addslashes($_GET['model']);



if ($model == 'getcode' && $_GET['md5formhash'] == formhash()) {

    $type = intval($_GET['type']);
    $mobile = addslashes($_GET['mobile']);



if($zmdata['seccodeverify']){

$seccodeverify =  diconv(addslashes($_GET['seccodeverify']), 'UTF-8', $charset);
$seccodehash = addslashes($_GET['seccodehash']);

if (!$seccodeverify) {
    $out['status'] = 1;
    $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text14'));
    $result        = json_encode($out);
    echo $result = urldecode($result);
    exit();
}

if (!check_seccode($seccodeverify, $seccodehash)) {
    $out['status'] = 1;
    $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text15'));
    $result        = json_encode($out);
    echo $result = urldecode($result);
    exit();
}


}


    $day_sms_nums = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
        "zimucms_magappmobile_code",
        $_G['timestamp']
        ));

    if($day_sms_nums>$zmdata['day_sms_nums']){

                $out['status'] = 1;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text13'));
                $result        = json_encode($out);
                echo $result = urldecode($result);
                exit();

    }

    if($zmdata['cityname'] && $zmdata['appkey'] && $mobile){

        $ch = curl_init();
        $url = 'http://apis.juhe.cn/mobile/get?phone='.$mobile.'&key='.$zmdata['appkey'];
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // 执行HTTP请求
        curl_setopt($ch , CURLOPT_URL , $url);
        $ress = curl_exec($ch);
        $Quyu = json_decode($ress,true);

        if($Quyu['error_code'] == '0'){

            $city = $Quyu['result']['city'];
            $province = $Quyu['result']['province'];
            if(!$city){
                $city = $province;
            }

            if($_G['charset'] == 'gbk'){
                $city = mb_convert_encoding($city,CHARSET,'utf-8');
            }

            if(strpos($zmdata['cityname'], $city) !== false){

            }else{

                $out['status'] = 1;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text5').$zmdata['cityname'].lang('plugin/zimucms_magappmobile', 'system_text6'));
                $result        = json_encode($out);
                echo $result = urldecode($result);
                exit();

            }

        }else{

            $out['status'] = 1;
            if($_G['charset'] == 'gbk'){
                $out['errmsg'] = urlencode(mb_convert_encoding($Quyu['reason'],CHARSET,'utf-8'));
            }else{
                $out['errmsg'] = urlencode($Quyu['reason']);
            }
            $result        = json_encode($out);
            echo $result = urldecode($result);
            exit();

        }

    }

    if($zmdata['no_phone']){
    $no_phone = substr($mobile,0,3);
    if(strpos($zmdata['no_phone'], $no_phone) !== false){
                $out['status'] = 1;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text16'));
                $result        = json_encode($out);
                echo $result = urldecode($result);
                exit();

    }
    }


    $iszhuce = DB::result_first('select userid from %t where phone=%s order by id desc', array(
        'user_mobile_relations',
        $mobile
    ));
    
    if ($iszhuce > 0) {
        $out['status'] = 1;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text3'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    $adddata['code'] = mt_rand(100000, 999999);
    $smsdata['code']    = "" . $adddata['code'] . "";

if($zmdata['is_product']){
    $smsdata['product'] = "" . mb_convert_encoding($zmdata['name'], 'UTF-8', CHARSET) . "";
}

if($zmdata['isaliyun']==1){
    $aaa                = sms_send($mobile, $smsdata, $zmdata['template_code']);
}else if($zmdata['isaliyun']==2){
    $aaa                = aliyun_sms_send($mobile, $smsdata, $zmdata['template_code']);
}else if($zmdata['isaliyun']==3){
    $aaa                = sms_send3($mobile, $smsdata, $zmdata['template_code']);
}
    $aaa = object_array(json_decode($aaa));
    
    if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {

        $adddata['uid']  = $_G['uid'];
        $adddata['username']  = $_G['username'];       
        $adddata['mobile']  = $mobile;
        $adddata['type']  = $type;
        $adddata['addtime'] = $_G['timestamp'];
        $adddata['ip'] = $_G['clientip'];
        $result             = DB::insert('zimucms_magappmobile_code', $adddata);
        $out['status']      = 200;
        $out['errmsg']      = urlencode(lang('plugin/zimucms_magappmobile', 'system_text3'));
        $result             = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    } else {
        $out['status'] = 2;
if($zmdata['isaliyun']==1){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['error_response']['sub_msg'], CHARSET, 'UTF-8'));
}else if($zmdata['isaliyun']==2){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
}else if($zmdata['isaliyun']==3){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['message'], CHARSET, 'UTF-8'));
}
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
} else if ($model == 'getpwd' && $_GET['md5formhash'] == formhash()) {

    $type = intval($_GET['type']);
    $mobile = addslashes($_GET['mobile']);

if($zmdata['seccodeverify']){

$seccodeverify =  diconv(addslashes($_GET['seccodeverify']), 'UTF-8', $charset);
$seccodehash = addslashes($_GET['seccodehash']);

if (!$seccodeverify) {
    $out['status'] = 1;
    $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text14'));
    $result        = json_encode($out);
    echo $result = urldecode($result);
    exit();
}

if (!check_seccode($seccodeverify, $seccodehash)) {
    $out['status'] = 1;
    $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text15'));
    $result        = json_encode($out);
    echo $result = urldecode($result);
    exit();
}


}

    $day_sms_nums = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
        "zimucms_magappmobile_code",
        $_G['timestamp']
        ));

    if($day_sms_nums>$zmdata['day_sms_nums']){

                $out['status'] = 1;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text13'));
                $result        = json_encode($out);
                echo $result = urldecode($result);
                exit();

    }


    if($zmdata['cityname'] && $zmdata['appkey'] && $mobile){

        $ch = curl_init();
        $url = 'http://apis.juhe.cn/mobile/get?phone='.$mobile.'&key='.$zmdata['appkey'];
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // 执行HTTP请求
        curl_setopt($ch , CURLOPT_URL , $url);
        $ress = curl_exec($ch);
        $Quyu = json_decode($ress,true);

        if($Quyu['error_code'] == '0'){

            $city = $Quyu['result']['city'];
            $province = $Quyu['result']['province'];
            if(!$city){
                $city = $province;
            }

            if($_G['charset'] == 'gbk'){
                $city = mb_convert_encoding($city,CHARSET,'utf-8');
            }

            if(strpos($zmdata['cityname'], $city) !== false){

            }else{

                $out['status'] = 1;
                $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text5').$zmdata['cityname'].lang('plugin/zimucms_magappmobile', 'system_text6'));
                $result        = json_encode($out);
                echo $result = urldecode($result);
                exit();

            }

        }else{

            $out['status'] = 1;
            if($_G['charset'] == 'gbk'){
                $out['errmsg'] = urlencode(mb_convert_encoding($Quyu['reason'],CHARSET,'utf-8'));
            }else{
                $out['errmsg'] = urlencode($Quyu['reason']);
            }
            $result        = json_encode($out);
            echo $result = urldecode($result);
            exit();

        }

    }

    
    $iszhuce = DB::result_first('select userid from %t where phone=%s order by id desc', array(
        'user_mobile_relations',
        $mobile
    ));
    
    if ($iszhuce <= 0) {
        $out['status'] = 1;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text8'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }


    $adddata['code'] = mt_rand(100000, 999999);
    $smsdata['code']    = "" . $adddata['code'] . "";

if($zmdata['is_product']){
    $smsdata['product'] = "" . mb_convert_encoding($zmdata['name'], 'UTF-8', CHARSET) . "";
}

if($zmdata['isaliyun']==1){
    $aaa                = sms_send($mobile, $smsdata, $zmdata['template_code']);
}else if($zmdata['isaliyun']==2){
    $aaa                = aliyun_sms_send($mobile, $smsdata, $zmdata['template_code']);
}else if($zmdata['isaliyun']==3){
    $aaa                = sms_send3($mobile, $smsdata, $zmdata['template_code']);
}
    $aaa = object_array(json_decode($aaa));
    
    if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {

        $adddata['uid']  = $_G['uid'];
        $adddata['username']  = $_G['username'];          
        $adddata['mobile']  = $mobile;
        $adddata['type']  = $type;
        $adddata['addtime'] = $_G['timestamp'];
        $adddata['ip'] = $_G['clientip'];
        $result             = DB::insert('zimucms_magappmobile_code', $adddata);
        $out['status']      = 200;
        $out['errmsg']      = urlencode(lang('plugin/zimucms_magappmobile', 'system_text3'));
        $result             = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    } else {
        $out['status'] = 2;
if($zmdata['isaliyun']==1){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['error_response']['sub_msg'], CHARSET, 'UTF-8'));
}else if($zmdata['isaliyun']==2){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
}else if($zmdata['isaliyun']==3){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['message'], CHARSET, 'UTF-8'));
}
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }

} else if ($model == 'getpwd_step1' && $_GET['md5formhash'] == formhash()) {

    $myphone = trim(daddslashes($_GET['myphone']));
    $mycode  = trim(daddslashes($_GET['mycode']));
    $type = intval($_GET['smstype']);
    $userpassword = trim(daddslashes($_GET['userpassword']));
    $userpassword2  = trim(daddslashes($_GET['userpassword2']));

            if(!preg_match('/1[34578]\d{7}/i',$myphone)){
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text9'));
            }

    if(!$myphone || !$mycode){
       showmessage(lang('plugin/zimucms_magappmobile', 'system_text1'));
   }

           if($userpassword !== $userpassword2) {
            showmessage('profile_passwd_notmatch');
        }

        if(!$userpassword || $userpassword != addslashes($userpassword)) {
            showmessage('profile_passwd_illegal');
        }


        if($_G['setting']['pwlength']) {
            if(strlen($userpassword) < $_G['setting']['pwlength']) {
                showmessage('profile_password_tooshort', '', array('pwlength' => $_G['setting']['pwlength']));
            }
        }
        if($_G['setting']['strongpw']) {
            $strongpw_str = array();
            if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $userpassword)) {
                $strongpw_str[] = lang('member/template', 'strongpw_1');
            }
            if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $userpassword)) {
                $strongpw_str[] = lang('member/template', 'strongpw_2');
            }
            if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $userpassword)) {
                $strongpw_str[] = lang('member/template', 'strongpw_3');
            }
            if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $userpassword)) {
                $strongpw_str[] = lang('member/template', 'strongpw_4');
            }
            if($strongpw_str) {
                showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
            }
        }


    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=%d and status=0 order by id desc', array(
        'zimucms_magappmobile_code',
        $myphone,
        $mycode,
        $_G['timestamp'] - $zmdata['codetime']*60,
        $type
    ));

    if (!$iscode) {
       showmessage(lang('plugin/zimucms_magappmobile', 'system_text10'));
    } else {

    $mobileuid = DB::result_first('select userid from %t where phone=%s order by id desc', array(
        'user_mobile_relations',
        $myphone
    ));

    loaducenter();
    $userdata = uc_get_user($mobileuid,1);
    $ucresult = uc_user_edit(addslashes($userdata[1]),'', $userpassword, '', 1);

    if($ucresult == -1) {
        showmessage('profile_passwd_wrong', '', array(), array('return' => true));
    } elseif($ucresult == -4) {
        showmessage('profile_email_illegal', '', array(), array('return' => true));
    } elseif($ucresult == -5) {
        showmessage('profile_email_domain_illegal', '', array(), array('return' => true));
    } elseif($ucresult == -6) {
        showmessage('profile_email_duplicate', '', array(), array('return' => true));
    } elseif($ucresult == 0) {
        showmessage(lang('plugin/zimucms_magappmobile','system_text12'));
    } elseif($ucresult == 1) {

        DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
            'mobile' => $myphone,
            'code' => $mycode,
            'type' => $type,
            ));

showmessage(lang('plugin/zimucms_magappmobile','system_text11'),'member.php?mod=logging&action=login');

    }

    }



} else if ($model == 'getpassword') {

$referer = $_G['siteurl'] . $_SERVER['REQUEST_URI'];

$referer = urldecode(urldecode(urldecode($referer)));

$referer2 = explode('referer=',$referer);

if($referer2[2]){
$referer = $referer2[2];
}else if($referer2[1]){
$referer = $referer2[1];
}else{
$referer = dreferer();
}
$referer = str_replace("/&","/?1=1&",$referer);
$referer = str_replace(".html&",".html?1=1&",$referer);
$referer = str_replace(".php&",".php?1=1&",$referer);

$lailu = $referer;

    include template('zimucms_magappmobile:getpassword');

} else if ($model == 'bindmobile') {
    
    if ($_G['uid'] <= 0) {
        return false;
    }
    
    $lailu = addslashes($_GET['lailu']);
    
    include template('zimucms_magappmobile:bindmobile_wap');
    
} else if ($model == 'bindmobile_wap' && $_GET['md5formhash'] == formhash()) {
    
    if ($_G['uid'] <= 0) {
        return false;
    }
    
    $lailu = addslashes($_GET['lailu']);
    
    $myphone = trim(daddslashes($_POST['myphone']));
    $mycode  = trim(daddslashes($_POST['mycode']));
    $type = intval($_GET['type']);
    
    $isbind = DB::result_first('select id from %t where userid=%d order by id desc', array(
        'user_mobile_relations',
        $_G['uid']
    ));
    
    if ($isbind > 0) {
        $out['status'] = 1;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text4'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=%d and status=0 order by id desc', array(
        'zimucms_magappmobile_code',
        $myphone,
        $mycode,
        $_G['timestamp'] - $zmdata['codetime']*60,
        $type
    ));
    
    if (!$iscode) {
        $out['status'] = 1;
        $out['errmsg'] = urlencode(lang('plugin/zimucms_magappmobile', 'system_text2'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    } else {
        
        $editdata['userid']      = $_G['uid'];
        $editdata['phone']       = $myphone;
        $editdata['create_time'] = $_G['timestamp'];
        $result                  = DB::insert('user_mobile_relations', $editdata);

        DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
            'mobile' => $myphone,
            'code' => $mycode,
            'type' => $type,
            ));
            
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => $myphone
        ));
        
        $out['status'] = 200;
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    }
    
}else{
        dheader('Location:' . SITE_URL);
        exit();
}