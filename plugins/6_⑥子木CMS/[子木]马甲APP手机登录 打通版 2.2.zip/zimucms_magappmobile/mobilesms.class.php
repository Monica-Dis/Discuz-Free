<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_zimucms_magappmobile
{


    function global_header() {
        return '<script src="./source/plugin/zimucms_magappmobile/static/jquery-1.8.3.min.js"></script>';
    }

        
    function global_footer()
    {
        
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        if (!$zmmobile['isopen']) {
            return;
        }
        if ($zmmobile['force_open'] && $_G['uid'] > 0) {

                $isbind = DB::result_first('select phone from %t where userid=%d order by id desc', array(
                    'user_mobile_relations',
                    $_G['uid']
                ));
            
$vip_uids = explode("\r\n", trim($zmmobile['vip_uids']));

if (!is_array($vip_uids)){
    $vip_uids = array();
}

if (in_array($_G['uid'], $vip_uids)) {
    $isbind = 18888888888;
}

$vip_usergroups = empty($zmmobile['vip_usergroups']) ? array() : unserialize($zmmobile['vip_usergroups']);
if (!is_array($vip_usergroups))
    $vip_usergroups = array();

if (in_array($_G['group']['groupid'], $vip_usergroups)) {
    $isbind = 18888888888;
}


        }
        include_once template('zimucms_magappmobile:global_footer');
        return $return;
    }
    
}

class plugin_zimucms_magappmobile_member extends plugin_zimucms_magappmobile
{
    
    
    function register_input()
    {
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        if (!$zmmobile['isopen'] || CURSCRIPT != 'member') {
            return;
        }
        include_once template('zimucms_magappmobile:sendsms');
        return $return;
    }
    

    function register_member()
    {
        
        
        global $_G;
        
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if (!$zmmobile['isopen']) {
            return;
        }
        
        if (submitcheck('regsubmit')) {
            

            $regname = $_GET[$_G['setting']['reginput']['username']];
            if(preg_match('/1[34578]\d{7}/i',$regname)){
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text7'));
                exit();
            }


            $mycode  = trim(daddslashes($_GET['mycode']));
            $myphone = trim(daddslashes($_GET['myphone']));
            
            if (empty($mycode) || empty($myphone)) {
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text1'));
                exit();
            }
            
            $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=1 and status=0 order by id desc', array(
                'zimucms_magappmobile_code',
                $myphone,
                $mycode,
                $_G['timestamp'] - $zmmobile['codetime']*60
            ));
            
            if (!$iscode) {
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text2'));
                exit();
            }
            
        }
        
        
    }
    
    
    
    function register_input_message()
    {
        
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if (!$zmmobile['isopen']) {
            return;
        }
        
        if ($_G['uid'] && !empty($_POST) && $_GET['regsubmit'] = 'yes' && $_GET['myphone']) {
            
            $data = daddslashes($_GET);
    
            $isuid = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=1 and status=0 order by id desc', array(
                'zimucms_magappmobile_code',
                $data['myphone'],
                $data['mycode'],
                $_G['timestamp'] - $zmmobile['codetime']*60
            ));

            if ($isuid) {

                $editdata['userid'] = $_G['uid'];
                $editdata['phone'] = $data['myphone'];
                $editdata['create_time'] = $_G['timestamp'];
                $result = DB::insert('user_mobile_relations',$editdata);

            }

            DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
                'mobile' => $data['myphone'],
                'code' => $data['mycode'],
                'type' => '1',
                ));

            C::t('common_member_profile')->update($_G['uid'], array(
                'mobile' => $data['myphone']
            ));
            
            
        }
    }
    

    function logging_method() {
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        include_once template('zimucms_magappmobile:sendsms');
        return $logging_method_html;
    }
    
    function logging()
    {
        
        global $_G;
        
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if ($_GET["action"] == "login" && $_REQUEST["username"] != "") {
            $username = $_REQUEST["username"];
            if (verify_mobile_number($username)) {

                $uid = DB::result_first('select userid from %t where phone=%s order by id desc', array(
                    'user_mobile_relations',
                    $username
                ));
                
                if ($uid) {
                    $userinfo = getuserbyuid($uid);
                } else {
                    $_POST["username"] = $_GET["username"] = $_REQUEST["username"] = $username;
                }
                if ($userinfo['username']) {
                    $username          = $userinfo['username'];
                    $_POST["username"] = $_GET["username"] = $_REQUEST["username"] = $username;
                }
                
                
            }
        }
        
        
    }
    
    
    
}


class plugin_zimucms_magappmobile_forum extends plugin_zimucms_magappmobile
{
    
    function post()
    {
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        if ($zmmobile['force_open'] && $_G['uid'] > 0) {

                $isbind = DB::result_first('select phone from %t where userid=%d order by id desc', array(
                    'user_mobile_relations',
                    $_G['uid']
                ));   


$vip_uids = explode("\r\n", trim($zmmobile['vip_uids']));

if (!is_array($vip_uids)){
    $vip_uids = array();
}

if (in_array($_G['uid'], $vip_uids)) {
    $isbind = 18888888888;
}

$vip_usergroups = empty($zmmobile['vip_usergroups']) ? array() : unserialize($zmmobile['vip_usergroups']);
if (!is_array($vip_usergroups))
    $vip_usergroups = array();

if (in_array($_G['group']['groupid'], $vip_usergroups)) {
    $isbind = 18888888888;
}

        }
        
        if ($_G['uid'] > 0 && $zmmobile['isopen'] && $zmmobile['force_open'] && !$isbind) {
            
            showmessage($zmmobile['fastreply_text']);
            
        }
    }
    
    
    
}

class mobileplugin_zimucms_magappmobile
{
    function global_footer_mobile()
    {
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        if (!$zmmobile['wapisopen']) {
            return;
        }
        if ($zmmobile['force_open'] && $_G['uid'] > 0) {

                $isbind = DB::result_first('select phone from %t where userid=%d order by id desc', array(
                    'user_mobile_relations',
                    $_G['uid']
                ));

$vip_uids = explode("\r\n", trim($zmmobile['vip_uids']));

if (!is_array($vip_uids)){
    $vip_uids = array();
}

if (in_array($_G['uid'], $vip_uids)) {
    $isbind = 18888888888;
}

$vip_usergroups = empty($zmmobile['vip_usergroups']) ? array() : unserialize($zmmobile['vip_usergroups']);
if (!is_array($vip_usergroups))
    $vip_usergroups = array();

if (in_array($_G['group']['groupid'], $vip_usergroups)) {
    $isbind = 18888888888;
}
            
        }
        include_once template('zimucms_magappmobile:sendsms');
        return $return;
    }
    
}

class mobileplugin_zimucms_magappmobile_member extends mobileplugin_zimucms_magappmobile
{
    
    function register_member()
    {
        
        
        global $_G;
        
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if (!$zmmobile['wapisopen']) {
            return;
        }
        
        if (submitcheck('regsubmit')) {

            $regname = $_GET[$_G['setting']['reginput']['username']];
            if(preg_match('/1[34578]\d{7}/i',$regname)){
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text7'));
                exit();
            }

              
            $mycode  = trim(daddslashes($_GET['mycode']));
            $myphone = trim(daddslashes($_GET['myphone']));
            
            if (empty($mycode) || empty($myphone)) {
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text1'));
                exit();
            }
            
            $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=1 and status=0 order by id desc', array(
                'zimucms_magappmobile_code',
                $myphone,
                $mycode,
                $_G['timestamp'] - $zmmobile['codetime']*60
            ));
            
            if (!$iscode) {
                showmessage(lang('plugin/zimucms_magappmobile', 'system_text2'));
                exit();
            }
            
        }
        
        
    }
    
    
    
    function register_input_message()
    {
        
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if (!$zmmobile['wapisopen']) {
            return;
        }
        
        if ($_G['uid'] && !empty($_POST) && $_GET['regsubmit'] = 'yes' && $_GET['myphone']) {
            
            $data = daddslashes($_GET);
            
            $isuid = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and type=1 and status=0 order by id desc', array(
                'zimucms_magappmobile_code',
                $data['myphone'],
                $data['mycode'],
                $_G['timestamp'] - $zmmobile['codetime']*60
            ));
            
            
            if ($isuid) {

                $editdata['userid'] = $_G['uid'];
                $editdata['phone'] = $data['myphone'];
                $editdata['create_time']         = $_G['timestamp'];
                $result = DB::insert('user_mobile_relations',$editdata);

            }

            DB::update('zimucms_magappmobile_code',array('status' => '1'), array(
                'mobile' => $data['myphone'],
                'code' => $data['mycode'],
                'type' => '1',
                ));
            
            C::t('common_member_profile')->update($_G['uid'], array(
                'mobile' => $data['myphone']
            ));
            
            
        }
    }
    
    
    
    function logging()
    {
        
        global $_G;
        
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        
        if ($_GET["action"] == "login" && $_REQUEST["username"] != "") {
            $username = $_REQUEST["username"];
            if (verify_mobile_number($username)) {

                $uid = DB::result_first('select userid from %t where phone=%s order by id desc', array(
                    'user_mobile_relations',
                    $username
                ));
                
                if ($uid) {
                    $userinfo = getuserbyuid($uid);
                } else {
                    $_POST["username"] = $_GET["username"] = $_REQUEST["username"] = $username;
                }
                if ($userinfo['username']) {
                    $username          = $userinfo['username'];
                    $_POST["username"] = $_GET["username"] = $_REQUEST["username"] = $username;
                }
                
                
            }
        }
        
        
    }
    
    
    
}


class mobileplugin_zimucms_magappmobile_forum extends mobileplugin_zimucms_magappmobile
{
    
    function post()
    {
        global $_G;
        $zmmobile = $_G['cache']['plugin']['zimucms_magappmobile'];
        if ($zmmobile['force_open'] && $_G['uid'] > 0) {

                $isbind = DB::result_first('select phone from %t where userid=%d order by id desc', array(
                    'user_mobile_relations',
                    $_G['uid']
                ));

$vip_uids = explode("\r\n", trim($zmmobile['vip_uids']));

if (!is_array($vip_uids)){
    $vip_uids = array();
}

if (in_array($_G['uid'], $vip_uids)) {
    $isbind = 18888888888;
}

$vip_usergroups = empty($zmmobile['vip_usergroups']) ? array() : unserialize($zmmobile['vip_usergroups']);
if (!is_array($vip_usergroups))
    $vip_usergroups = array();

if (in_array($_G['group']['groupid'], $vip_usergroups)) {
    $isbind = 18888888888;
}


        }
        
        if ($_G['uid'] > 0 && $zmmobile['wapisopen'] && $zmmobile['force_open'] && !$isbind) {
            
            showmessage($zmmobile['fastreply_text']);
            
        }
    }
    
    
    
}

function verify_mobile_number($mobile)
{
    $preg = "/^(13[0-9]|15[0-9]|17[0678]|18[0-9]|14[57])[0-9]{8}$/";
    if (!preg_match($preg, $mobile)) {
        return false;
    }
    return true;
}