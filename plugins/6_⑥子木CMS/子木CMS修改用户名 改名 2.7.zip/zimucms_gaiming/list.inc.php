<?php
/*
��ľCMS http://www.zimucms.com/
CopyRight 2016 All Rights Reserved
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_gaiming/config.php';

$model = addslashes($_GET['model']);


if($model=='tomagapp'){

$uid = intval($_GET['uid']);

if($uid && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){
    $updateUn['user_id'] = $uid;
    $updateUn['secret'] = $zmdata['magapp_secret'];
    $magdata2 = lizimu_post($zmdata['magapp_hostname'].'/mag/open/api/updateUserName',$updateUn);
}

            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_gaiming', 'system_text1'), $url, 'succeed');


}elseif($model=='tomagappall'){

$stlist = DB::fetch_all('select * from %t group by uid order by id desc', array(
    'zimucms_gaiming',
));

$allnums = count($stlist);
$text = lang('plugin/zimucms_gaiming', 'system_text11');

$limit    = 1;
$start = intval($_GET['start']);
$start    = $start * $limit;
$start2 = $start+1;
$stlist2 = DB::fetch_first('select * from %t group by uid order by id desc limit %d,%d', array(
    'zimucms_gaiming',
    $start,
    $limit
));

if(!$stlist2){

            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_gaiming', 'system_text12'), $url, 'succeed');
            exit();
}

$user = getuserbyuid($stlist2['uid'], 1);

if($user && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){
    $updateUn['user_id'] = $stlist2['uid'];
    $updateUn['secret'] = $zmdata['magapp_secret'];
    $magdata2 = lizimu_post($zmdata['magapp_hostname'].'/mag/open/api/updateUserName',$updateUn);
}

$text = '<p>ID'.$stlist2['id'].str_replace(array('{uid}','{newname}','{oldname}'), array($stlist2['uid'],$user['username'],$stlist2['oldname']), $text).'<p>';



            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'].'&model=tomagappall&start='.$start2;
            cpmsg($text, $url, 'loading');


}else{

$page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page = intval($page);


$count = DB::result_first("SELECT count(*) FROM %t", array(
    "zimucms_gaiming"
));

$limit    = 30;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

$stlist = DB::fetch_all('select * from %t order by id desc limit %d,%d', array(
    'zimucms_gaiming',
    $start,
    $limit
));

if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
}


include template('zimucms_gaiming:gaiming_list');

}