<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimucms_gaiming;
EOF;

runquery($sql);

$finish = TRUE;