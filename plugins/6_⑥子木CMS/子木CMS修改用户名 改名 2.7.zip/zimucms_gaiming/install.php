<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_gaiming` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `newname` char(50) NOT NULL,
  `oldname` char(50) NOT NULL,
  `sorcenums` char(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE;
?>