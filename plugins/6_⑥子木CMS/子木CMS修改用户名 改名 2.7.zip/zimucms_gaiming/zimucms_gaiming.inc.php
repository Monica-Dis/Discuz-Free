<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_gaiming/config.php';

$model = addslashes($_GET['model']);

if ($model == 'checkusername' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    $checkusername = addslashes(strip_tags(zm_diconv($_GET['username'])));
    $checkusername = trim($checkusername);

    if(is_numeric($checkusername)){
        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text14'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }

    if (C::t('common_member')->fetch_uid_by_username($checkusername) || C::t('common_member_archive')->fetch_uid_by_username($checkusername)) {
        
        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text3'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
        
    }


    loaducenter();
    $ucresult = uc_user_checkname($checkusername);

    if ($ucresult == -1) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text9'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    } elseif ($ucresult == -2) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text10'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    } elseif ($ucresult == -3) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text3'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    }

    $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    if ($_G['setting']['censoruser'] && @preg_match($censorexp, $checkusername)) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text10'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    }
 
        $out['code'] = 200;
        echo $result = json_encode($out);
        exit();
        

    
    
} else if ($model == 'changeusername' && $_GET['md5hash'] == formhash()) {
    
    isuid();
    
    //�жϻ���
    
    if ($zmdata['scoretype'] && $zmdata['scorenums']) {
        
        $scoretype = explode(',', $zmdata['scoretype']);
        
        $scorenums = explode(',', $zmdata['scorenums']);
        
        foreach ($scoretype as $key => $value) {
            
            $score_reduce[$key]['name']  = $_G['setting']['extcredits'][$scoretype[$key]]['title'];
            $score_reduce[$key]['score'] = $scorenums[$key];
            
        }
        
    }
    
    if ($zmdata['scorerule']) {
        
        $userallcount = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d", array(
            "zimucms_gaiming",
            $_G['uid']
        ));
        
        $scorerule = explode("\r\n", trim($zmdata['scorerule']));
        foreach ($scorerule as $key => $v) {
            $scorerule[$key] = explode('=', $v);
        }
        
        if (isset($scorerule[$userallcount][1])) {
            
            foreach ($scoretype as $key => $value) {
                
                $score_reduce[$key]['score'] = $scorenums[$key] * $scorerule[$userallcount][1];
                
            }
        }
        
    }
    
    
    foreach ($scoretype as $key => $value) {
        
        $myscore = getuserprofile('extcredits' . $value);
        
        if ($myscore < $score_reduce[$key]['score']) {
            $out['code'] = 202;
            $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text6'));
            $result      = json_encode($out);
            echo $result = urldecode($result);
            exit();
        }
      $sorcenums_text = $sorcenums_text .$score_reduce[$key]['score'].$score_reduce[$key]['name'];

    }
    
    
    $checkusername = addslashes(strip_tags(zm_diconv($_GET['username'])));
    $checkusername = trim($checkusername);

    if (C::t('common_member')->fetch_uid_by_username($checkusername) || C::t('common_member_archive')->fetch_uid_by_username($checkusername)) {
        
        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text3'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    }

    loaducenter();
    $ucresult = uc_user_checkname($checkusername);

    if ($ucresult == -1) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text9'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    } elseif ($ucresult == -2) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text10'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    } elseif ($ucresult == -3) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text3'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
    }

    $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    if ($_G['setting']['censoruser'] && @preg_match($censorexp, $checkusername)) {

        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text10'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();

    }

    
    $adddata = array(
        'uid' => $_G['uid'],
        'newname' => $checkusername,
        'oldname' => $_G['username'],
        'sorcenums' => $sorcenums_text,
        'addtime' => $_G['timestamp']
    );

    $oldname = $_G['username'];
    $newname = $checkusername;

if(IN_MAGAPP && $zmdata['magapp_hostname'] && $zmdata['magapp_secret'] && $zmdata['is_assistant']){

    $magurl = $zmdata['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $_G['uid'];
    $magpostdata['type'] = 'remind';
    $zmdata['assistant_content'] = str_replace('#newname#',$newname,$zmdata['assistant_content']);
    $zmdata['assistant_content'] = str_replace('#oldname#',$oldname,$zmdata['assistant_content']);
    $magpostdata['content'] = diconv($zmdata['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmdata['assistant_secret'];
    $magpostdata['secret'] = $zmdata['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);
}


    $result1 = DB::query('UPDATE %t SET username = %s WHERE username = %s', array(
        'common_member',
        $checkusername,
        $_G['username']
    ));
    $result2 = DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$checkusername' WHERE username='{$_G[username]}'");

    $result3 = DB::insert('zimucms_gaiming', $adddata);

    C::t('common_member')->update_cache($_G['uid'], array(
        'username' => $checkusername
    ));

    $_G['username'] = $checkusername;

    if (C::memory()->enable) {
        C::memory()->clear();
    }

if(IN_MAGAPP && $zmdata['magapp_hostname'] && $zmdata['magapp_secret']){

    $updateUn['user_id'] = $_G['uid'];
    $updateUn['secret'] = $zmdata['magapp_secret'];
    $magdata2 = lizimu_post($zmdata['magapp_hostname'].'/mag/open/api/updateUserName',$updateUn);

}

    foreach ($scoretype as $key => $value) {
        
        updatemembercount($_G['uid'], array(
            'extcredits' . $value => '-' . $score_reduce[$key]['score']
        ), true, '', 1,lang('plugin/zimucms_gaiming', 'system_text7'),lang('plugin/zimucms_gaiming', 'system_text7'),lang('plugin/zimucms_gaiming', 'system_text8'));
        
    }
    
    if (!$result3) {
        
        $out['code'] = 201;
        $out['err']  = urlencode(lang('plugin/zimucms_gaiming', 'system_text4'));
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
        
        
    } else {
        
        $out['code'] = 200;
        echo $result = json_encode($out);

if($zmdata['is_splicesql']){    
    $sqls = splicesql($oldname,$newname);
    if ($sqls) {
        foreach ($sqls as $sql) {
            $aaa = DB::query($sql);
        }
    }
}
    

        exit();
        
    }
    
} else {
    
    isuid();
    
    $todaytime  = strtotime(date('Y-m-d', $_G['timestamp']));
    $todaytime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    
    $usedcount = DB::result_first("SELECT count(*) FROM %t WHERE addtime>%d AND addtime<%d", array(
        "zimucms_gaiming",
        $todaytime,
        $todaytime2
    ));
    
    $beginThismonth = DB::result_first("SELECT addtime FROM %t WHERE uid=%d order by id desc", array(
        "zimucms_gaiming",
        $_G['uid']
    ));

    $endThismonth   = $beginThismonth + 86400 * $zmdata['interval_days'];  
    
    if ($zmdata['scoretype'] && $zmdata['scorenums']) {
        
        $scoretype = explode(',', $zmdata['scoretype']);
        
        $scorenums = explode(',', $zmdata['scorenums']);
        
        foreach ($scoretype as $key => $value) {
            
            $score_reduce[$key]['name']  = $_G['setting']['extcredits'][$scoretype[$key]]['title'];
            $score_reduce[$key]['score'] = $scorenums[$key];
            
        }
        
    }

    if ($zmdata['scorerule']) {
        
        $userallcount = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d", array(
            "zimucms_gaiming",
            $_G['uid']
        ));
        
        $scorerule = explode("\r\n", trim($zmdata['scorerule']));
        foreach ($scorerule as $key => $v) {
            $scorerule[$key] = explode('=', $v);
        }

        if (isset($scorerule[$userallcount][1])) {
            
            foreach ($scoretype as $key => $value) {
                
                $score_reduce[$key]['score'] = $scorenums[$key] * $scorerule[$userallcount][1];
                
            }
        }
        
    }
    
    if($_G['timestamp'] > $endThismonth){
        $usercount = 0;
    }else{
        $usercount = 1;
    }

    $day_nums2  = $zmdata['day_nums'] - $usedcount;
    $user_nums2 = 1 - $usercount;

$vipgroups = empty($zmdata['usergroups']) ? array() : unserialize($zmdata['usergroups']);
if (!is_array($vipgroups)){
    $vipgroups = array();
}

if(!in_array($_G['group']['groupid'], $vipgroups) && $vipgroups[0]) {
$noallow = 1;
}

    include template('zimucms_gaiming:gaiming');
    
}