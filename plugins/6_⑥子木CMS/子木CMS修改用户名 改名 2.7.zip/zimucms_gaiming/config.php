<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

error_reporting(0);

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_gaiming/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_gaiming');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimucms_gaiming'];

define('IN_MYAPP', strpos($_SERVER['HTTP_USER_AGENT'], $zmdata['useragent']) !== false);

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimucms_gaiming']['zimu_luanma'] = trim($_G['cache']['plugin']['zimucms_gaiming']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimucms_gaiming']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    $zmdata = $_G['cache']['plugin']['zimucms_gaiming'];
    $refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_gaiming';
    
if (IN_MAGAPP && !$_G['uid']){

$userAgent = $_SERVER['HTTP_USER_AGENT'];
$info = strstr($userAgent, "MAGAPPX");
$info=explode("|",$info);
$token = $info[7];

    $appurl = $zmdata['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$zmdata['magapp_secret'];
    $appdata = dfsockopen($appurl);
    if (!$appdata) {
        $appdata = file_get_contents($appurl);
    }
    $r =  json_decode($appdata, true);
    if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

    }else{
        exit('<script src="source/plugin/zimucms_gaiming/static/js/magjs-x.js"></script><script>
            mag.toLogin(function(){
                top.location.href="' . $refererurl . '";
                });
                </script>'); 
    }

}else{

    if (!$zmdata['isguest']) {
        if (!$_G['uid']) {
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimucms_gaiming/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimucms_gaiming/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $refererurl . '";
  });
    </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
    }
}
}


function splicesql($oldname, $newname) {
    $sql = array();
    $tables = @include (DISCUZ_ROOT . './source/plugin/zimucms_gaiming/tables.php');
    if (!empty($tables['dz'])) {
        $dz = tablepre();
        $query = DB::query("SHOW TABLE STATUS LIKE '{$dz}forum_%'");
        while ($value = DB::fetch($query)) {
            if (preg_match("/^{$dz}forum_post_\d+$|^{$dz}forum_thread_\d+$/i", $value['Name'])) {
                $value['Name'] = str_replace($dz, '', $value['Name']);
                if (strpos($value['Name'], 'forum_thread') === false) {
                    $tables['dz'][$value['Name']] = 'author';
                } else {
                    $tables['dz'][$value['Name']] = 'author|lastposter';
                }
            }
        }
        foreach ($tables['dz'] as $key => $value) {
            if ($key && $value) {
                $value = array_filter(explode('|', $value));
                foreach ($value as $field) {
                    $sql[] = "UPDATE {$dz}{$key} SET " . DB::field($field, $newname) . " WHERE " . DB::field($field, $oldname);
                }
            }
        }
    }
    if (!empty($tables['uc'])) {
        $uc = tablepre(true);
        foreach ($tables['uc'] as $key => $value) {
            if ($key && $value) {
                $sql[] = "UPDATE {$uc}{$key} SET " . DB::field($value, $newname) . " WHERE " . DB::field($value, $oldname);
            }
        }
    }
    return $sql;
}

function tablepre($uc = false) {
    if ($uc) {
        if (!defined('UC_DBTABLEPRE')) {
            loaducenter();
        }
        $tablepre = UC_DBTABLEPRE;
    } else {
        $db = DB::object();
        $tablepre = $db->tablepre;
    }
    return $tablepre;
}


function lizimu_post($url, $data) {
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}