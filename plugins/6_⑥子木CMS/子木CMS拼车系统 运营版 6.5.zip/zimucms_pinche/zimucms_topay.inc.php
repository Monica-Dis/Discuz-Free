<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_pinche/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_pinche');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

if (!$_G['uid']) {
    $refererurl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    if (IN_XIAOYUNAPP) {
        exit('<script language="javascript" src="source/plugin/zimucms_pinche/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
    } else if (IN_MAGAPP) {
        exit('<script src="source/plugin/zimucms_pinche/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            window.location.href="' . $refererurl . '";
  });
    </script>');
    } else if (IN_QFAPP) {
        exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
    } else {
        dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        exit();
    }
}

$zmdata   = $_G['cache']['plugin']['zimucms_pinche'];
$formhash = $_G['formhash'];

$model    = addslashes($_GET['model']);

if ($model == 'towxpay' && $_GET['md5hash'] == $formhash) {
    
    $pay      = round($_GET['pay_money'], 2);
    $zengsong = round($_GET['pay_nums'], 2);
    
    if (IN_XIAOYUNAPP) {
        
        include DISCUZ_ROOT . "source/plugin/zimucms_pinche/payment/weixin/lib/WxPay.Api.php";
        include DISCUZ_ROOT . "source/plugin/zimucms_pinche/payment/weixin/source/WxPay.AppPay.php";
        
        $notify         = new AppPay();
        $order_sn       = $_G['uid'] . $yid . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $inputbody      = diconv(cutstr(lang('plugin/zimucms_pinche', 'system_text18'), 32, ''), CHARSET, 'utf-8');
        $inputtotal_fee = intval($pay * 100);
        $input          = new WxPayUnifiedOrder();
        $input->SetBody($inputbody);
        $input->SetOut_trade_no($order_sn);
        $input->SetTotal_fee($inputtotal_fee);
        $input->SetNotify_url(ZIMUCMS_URL . '&model=tuisongmoban');
        $input->SetTrade_type("APP");
        $order            = WxPayApi::unifiedOrder($input);
        $appApiParameters = $notify->GetAppApiParameters($order);
        
        $wxpay                 = json_decode($appApiParameters);
        $wxpay                 = object_array($wxpay);
        $wxpay['out_trade_no'] = $order_sn;
        
    } else {
        
        if (IN_WECHAT) {
            list($openid, $uptime) = getcookie('zm_qianbao') ? explode("\t", authcode(getcookie('zm_qianbao'), 'DECODE')) : array();
        }
        include DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxpay.class.php';
        $input               = new WxPayData();
        $input->body         = diconv(cutstr(lang('plugin/zimucms_pinche', 'system_text18'), 32, ''), CHARSET, 'utf-8');
        $input->out_trade_no = $_G['uid'] . $yid . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $input->total_fee    = intval($pay * 100);
        $input->time_start   = date('YmdHis');
        $input->time_expire  = date('YmdHis', TIMESTAMP + 600);
        $input->notify_url   = ZIMUCMS_URL;
        
        $input->product_id = diconv(lang('plugin/zimucms_pinche', 'system_text18'), CHARSET, 'utf-8') . $_G['uid'];
        $input->fromtype   = 'ZM_PINCHE';
        $input->fromid     = $_G['uid'];
        $input->openid     = $openid;
        $input->trade_type = 'JSAPI';
        try {
            $jsPay  = new JsApiPay();
            $result = WxPayApi::unifiedOrder($input);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        //$result = diconv($result, 'utf-8', CHARSET);
        
        if ($result['return_code'] == 'FAIL') {
            showmessage($result['return_msg']);
        }
        
        if ($result['result_code'] == 'FAIL') {
            showmessage($result['err_code_des']);
        }
        try {
            $wxpay = $jsPay->getJsApiParameters($result);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        
        $wxpay                 = json_decode($wxpay);
        $wxpay                 = object_array($wxpay);
        $wxpay['out_trade_no'] = $input->out_trade_no;
    }
    
    if (IN_XIAOYUNAPP) {
        $wxtype = 'wxapppay';
    } else {
        $wxtype = 'wxpay';
    }
    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => $wxtype,
        'jine' => $pay,
        'zengsong' => $zengsong,
        'out_trade_no' => $wxpay['out_trade_no'],
        'addtime' => $_G['timestamp']
    );
    $result  = DB::insert('zimucms_pinche_paylog', $paydata);
    
    if ($result) {
        echo json_encode($wxpay);
    }


}elseif ($model == 'towxpay2' && $_GET['formhash'] == $formhash) {
    
    $money1      = intval($_GET['money1']*100);
    $money2 = intval($_GET['money2']*100);

    $IsHaveCar = intval($_GET['IsHaveCar']);
    $islongterm = intval($_GET['islongterm']);

    if ($islongterm == 1) {
        $longstart        = strtotime($_GET['longstart']);
        $longend          = strtotime($_GET['longend']);
        $datediff         = ($longend - $longstart) / 86400 + 1;
    }

    $adddata['useruid'] = $_G['uid'];
    $adddata['leixing'] = $IsHaveCar;
    if ($islongterm == 1) {
        $adddata['starttime'] = strtotime($_GET['StartTime2']) - strtotime(date('Y-m-d', $_G['timestamp']));
        $adddata['longstart'] = $longstart;
        $adddata['longend']   = $longend;
    } else {
        $adddata['starttime'] = strtotime($_GET['StartTime']);
    }
    $adddata['timetext']    = strip_tags(zm_diconv2($_GET['StartTimeMore']));
    $adddata['chufadi']     = strip_tags(zm_diconv2($_GET['StartPlace']));
    $adddata['mudidi']      = strip_tags(zm_diconv2($_GET['ToPlace']));
    $adddata['tujing']      = strip_tags(zm_diconv2($_GET['MiddlePlace']));
    $adddata['kongwei']     = intval($_GET['PersonNum']);
    $adddata['lianxi']      = strip_tags($_GET['Contact']);
    $adddata['beizhu']      = strip_tags(zm_diconv2($_GET['MoreNote']));
    $adddata['sort']        = 100;
    $adddata['status']      = 1;
    $adddata['iszhiding']   = 0;
    $adddata['zhidingtype'] = round($_GET['TopInfo'], 2);
    $adddata['islongterm']  = $islongterm;
    
    if (!$zmdata['isguest_add'] && $_G['uid'] > 0 && $adddata['zhidingtype'] > 0) {
        $adddata['zhidingendtime'] = $_G['timestamp'] + intval($_GET['zhidingtime']) * 60;
    }
    $adddata['addtime']  = $_G['timestamp'];
    $adddata['clientip'] = $_G['clientip'];
    $result              = DB::insert('zimucms_pinche', $adddata, 1);
    $pincheid            = $result;

    if(IN_MAGAPP){

    $pay      = round($money2/100, 2);

    $zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    $order_id = 'APP' . date('Ymd') . time();

    $sign = md5($order_id.$zmqianbao['magapp_secret']);

    $callback = urlencode($_G['siteurl'] . 'plugin.php?id=zimucms_pinche:zimucms_topay&model=magapp_topay2&orderNum='.$order_id.'&sign='.$sign);

    $paytitle = lang('plugin/zimucms_pinche', 'system_text46');

    if ($_G['charset'] == 'gbk') {
        $paytitle = iconv('gbk', 'utf-8', $paytitle);
    }

    $urls = $zmqianbao['magapp_hostname'].'/core/pay/pay/unifiedOrder?trade_no='.$order_id.'&callback='.$callback.'&amount='.$pay.'&title='.$paytitle.'&user_id='.$_G['uid'].'&to_user_id=0&des='.$paytitle.'&remark='.$_G['uid'].'&secret='.$zmqianbao['magapp_secret'];
    $r = dfsockopen($urls);
    
    $r =  json_decode($r, true);
    if(!intval($r['success'])){
        $out['status'] = 201;
        $out['errmsg'] = urlencode($r['msg']);
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }else{

    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => 'wxapppay',
        'jine' => $pay,
        'zengsong' => 0,
        'out_trade_no' => $r['data']['unionOrderNum'],
        'orderNum' => $order_id,
        'addtime' => $_G['timestamp'],
        'note' => lang('plugin/zimucms_pinche', 'system_text74').$pay,
        'pincheid' => $pincheid
    );
    DB::insert('zimucms_pinche_paylog', $paydata);

        $out['status'] = 200;
        $out['errmsg'] = '';
        $out['orderNum'] = $order_id;
        $out['unionOrderNum'] = $r['data']['unionOrderNum'];
        $out['sign'] = $sign;
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit(); 
    }


       }elseif(IN_QFAPP){

    $zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    if(!$zmqianbao['qf_type']){
    $zmqianbao['qf_type'] = 10000;
    }
    $out_trade_no = strip_tags($_GET['qfid']);
    
    $pay      = round($money2/100, 2);

    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => 'wxapppay',
        'jine' => $pay,
        'zengsong' => 0,
        'out_trade_no' => $out_trade_no,
        'addtime' => $_G['timestamp'],
        'note' => lang('plugin/zimucms_pinche', 'system_text74').$pay,
        'pincheid' => $pincheid
    );

    DB::insert('zimucms_pinche_paylog', $paydata);


       }else{

        if (IN_WECHAT) {
            list($openid, $uptime) = getcookie('zm_qianbao') ? explode("\t", authcode(getcookie('zm_qianbao'), 'DECODE')) : array();
        }

        include DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxpay.class.php';
        $input               = new WxPayData();
        $input->body         = diconv(cutstr(lang('plugin/zimucms_pinche', 'system_text18'), 32, ''), CHARSET, 'utf-8');
        $input->out_trade_no = $_G['uid'] . $yid . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $input->total_fee    = intval($money2);
        $input->time_start   = date('YmdHis');
        $input->time_expire  = date('YmdHis', TIMESTAMP + 600);
        $input->notify_url   = $_G['siteurl'].'source/plugin/zimucms_pinche/lib/notify_wx.php';
        $input->product_id = diconv(lang('plugin/zimucms_pinche', 'system_text18'), CHARSET, 'utf-8') . $_G['uid'];
        $input->fromtype   = 'ZM_PINCHE';
        $input->fromid     = $_G['uid'];
        $input->openid     = $openid;
        $input->trade_type = 'JSAPI';

        try {
            $jsPay  = new JsApiPay();
            $result = WxPayApi::unifiedOrder($input);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        //$result = diconv($result, 'utf-8', CHARSET);
        
        if ($result['return_code'] == 'FAIL') {
            showmessage($result['return_msg']);
        }
        
        if ($result['result_code'] == 'FAIL') {
            showmessage($result['err_code_des']);
        }
        try {
            $wxpay = $jsPay->getJsApiParameters($result);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        
        $wxpay                 = json_decode($wxpay);
        $wxpay                 = object_array($wxpay);
        $wxpay['out_trade_no'] = $input->out_trade_no;
    
    if (IN_XIAOYUNAPP) {
        $wxtype = 'wxapppay';
    } else {
        $wxtype = 'wxpay';
    }
    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => $wxtype,
        'jine' => round($money2/100, 2),
        'zengsong' => '0',
        'out_trade_no' => $wxpay['out_trade_no'],
        'addtime' => $_G['timestamp'],
        'note' => lang('plugin/zimucms_pinche', 'system_text74').round($money1/100, 2),
        'pincheid' => $pincheid
    );
    $result  = DB::insert('zimucms_pinche_paylog', $paydata);
    
    if ($result) {
        echo json_encode($wxpay);
    }


       }
    

} else if ($model == 'paysuccess') {
    
    
    include DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxpay.class.php';
    
    $input               = new WxPayData();
    $input->out_trade_no = strip_tags($_GET['out_trade_no']);
    
    try {
        $jsPay  = new JsApiPay();
        $result = WxPayApi::orderQuery($input);
    }
    catch (WxPayException $e) {
        showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
    }
    
    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_pinche_paylog',
        $input->out_trade_no
    ));
    
    if ($result['trade_state'] == 'SUCCESS' && $paylogdata['status'] == 1) {
        $addata['status'] = '2';
        $result           = DB::update('zimucms_pinche_paylog', $addata, array(
            'out_trade_no' => $input->out_trade_no
        ));
        
        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_pinche_user',
            $_G['uid']
        ));

        if ($isuser) {
            
            $addata2['username'] = $_G['username'];
            $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
            $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
            $addata2['uptime']   = $_G['timestamp'];
            $result              = DB::update('zimucms_pinche_user', $addata2, array(
                'uid' => $_G['uid']
            ));
            
        } else {
            
            
            $addata3 = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'allmoney' => $paylogdata['zengsong'],
                'money' => $paylogdata['zengsong'],
                'uptime' => $_G['timestamp']
            );
            $result  = DB::insert('zimucms_pinche_user', $addata3);
            
            
        }
     
     if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){
        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $qf_jifen = $paylogdata['zengsong'];
        $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type2'],'gold' => $qf_jifen,'reason' => 'pinche_chongzhi']);
    }   
        
    }
    
    dheader('Location:' . ZIMUCMS_URL . '&model=add');
    
} else if ($model == 'paysuccess2') {
    
    include DISCUZ_ROOT . "source/plugin/zimucms_pinche/payment/weixin/lib/WxPay.Api.php";
    
    $out_trade_no = strip_tags($_GET['out_trade_no']);
    $input        = new WxPayOrderQuery();
    $input->SetOut_trade_no($out_trade_no);
    $result = WxPayApi::orderQuery($input);
    
    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_pinche_paylog',
        $out_trade_no
    ));
    
    if ($result['trade_state'] == 'SUCCESS' && $paylogdata['status'] == 1 && $_GET['md5hash'] == $formhash) {
        
        $addata['status'] = '2';
        $result           = DB::update('zimucms_pinche_paylog', $addata, array(
            'out_trade_no' => $out_trade_no
        ));
        
        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_pinche_user',
            $_G['uid']
        ));
        if ($isuser) {
            
            $addata2['username'] = $_G['username'];
            $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
            $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
            $addata2['uptime']   = $_G['timestamp'];
            $result              = DB::update('zimucms_pinche_user', $addata2, array(
                'uid' => $_G['uid']
            ));
            
        } else {
            $addata3 = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'allmoney' => $paylogdata['zengsong'],
                'money' => $paylogdata['zengsong'],
                'uptime' => $_G['timestamp']
            );
            $result  = DB::insert('zimucms_pinche_user', $addata3);
            
            
        }

     if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){
        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $qf_jifen = $paylogdata['zengsong'];
        $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type2'],'gold' => $qf_jifen,'reason' => 'pinche_chongzhi']);
    } 


    }
    dheader('Location:' . ZIMUCMS_URL . '&model=add');
    
    //千帆APP支付
} else if ($model == 'qf_pay_before') {

$zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

if(!$zmqianbao['qf_type']){
$zmqianbao['qf_type'] = 10000;
}
    $out_trade_no = strip_tags($_GET['qfid']);
    
    $pay      = round($_GET['pay_money'], 2);
    $zengsong = round($_GET['pay_nums'], 2);
    
    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => 'wxapppay',
        'jine' => $pay,
        'zengsong' => $zengsong,
        'out_trade_no' => $out_trade_no,
        'addtime' => $_G['timestamp']
    );
    DB::insert('zimucms_pinche_paylog', $paydata);


} else if ($model == 'qf_pay' && $_GET['md5hash'] == $formhash) {

$zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

if(!$zmqianbao['qf_type']){
$zmqianbao['qf_type'] = 10000;
}
    $out_trade_no = strip_tags($_GET['qfid']);
    
    $pay      = round($_GET['pay_money'], 2);
    $zengsong = round($_GET['pay_nums'], 2);
    
    $nonce  = qf_nonce();
    $secret = $zmqianbao['qf_secret'];
    
    $data = array(
        'order_id' => $out_trade_no,
        'nonce' => $nonce
    );
    
    $data['sign'] = qf_sign($data, $secret);
    $r            = http_build_query($data);
    
    $qfurl = $zmqianbao['qf_hostname'] . '/api1_2/orders/query?' . $r;
    $qfdata = dfsockopen($qfurl);
    if (!$qfdata) {
        $qfdata = file_get_contents($qfurl);
    }
    
    if ($retqf = json_decode($qfdata, true)) {
        if ($retqf['data'][$out_trade_no]['result'] == 1 || $retqf['data'][$out_trade_no]['result'] == 2) {
            
            $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
                'zimucms_pinche_paylog',
                $out_trade_no
            ));
            
            if ($paylogdata['status'] == 1) {
 
                $addata['status'] = '2';
                DB::update('zimucms_pinche_paylog', $addata, array(
                    'out_trade_no' => $out_trade_no
                ));
                
                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_pinche_user',
                    $_G['uid']
                ));
                
                if ($isuser) {
                    
                    $addata2['username'] = $_G['username'];
                    $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
                    $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
                    $addata2['uptime']   = $_G['timestamp'];
                    $result              = DB::update('zimucms_pinche_user', $addata2, array(
                        'uid' => $_G['uid']
                    ));
                    
                } else {
                    
                    
                    $addata3 = array(
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'allmoney' => $paylogdata['zengsong'],
                        'money' => $paylogdata['zengsong'],
                        'uptime' => $_G['timestamp']
                    );
                    $result  = DB::insert('zimucms_pinche_user', $addata3);
                    
                    
                }

                 if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){
                    require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
                    $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
                    $qf_jifen = $paylogdata['zengsong'];
                    $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type2'],'gold' => $qf_jifen,'reason' => 'pinche_chongzhi']);
                }
                
            }
            
            
        }
    }

} else if ($model == 'qf_pay2' && $_GET['md5hash'] == $formhash) {

$zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

if(!$zmqianbao['qf_type']){
$zmqianbao['qf_type'] = 10000;
}
    $out_trade_no = strip_tags($_GET['qfid']);
    
    $pay      = round($_GET['money2'], 2);
    
    $nonce  = qf_nonce();
    $secret = $zmqianbao['qf_secret'];
    
    $data = array(
        'order_id' => $out_trade_no,
        'nonce' => $nonce
    );
    
    $data['sign'] = qf_sign($data, $secret);
    $r            = http_build_query($data);
    
    $qfurl = 'http://' . $zmqianbao['qf_hostname'] . '.qianfanapi.com/api1_2/orders/query?' . $r;
    $qfdata = dfsockopen($qfurl);
    if (!$qfdata) {
        $qfdata = file_get_contents($qfurl);
    }
    
    if ($retqf = json_decode($qfdata, true)) {
        if ($retqf['data'][$out_trade_no]['result'] == 1 || $retqf['data'][$out_trade_no]['result'] == 2) {
            
            $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
                'zimucms_pinche_paylog',
                $out_trade_no
            ));
            
            if ($paylogdata['status'] == 1) {
 

                $addata['status'] = '2';
                DB::update('zimucms_pinche_paylog', $addata, array(
                    'out_trade_no' => $out_trade_no
                ));

                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_pinche_user',
                    $paylogdata['uid']
                ));

                DB::query("update %t set money=0,uptime=%d where uid=%d", array(
                    'zimucms_pinche_user',
                    $_G['timestamp'],
                    $paylogdata['uid'],
                ));
                
                 if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){
                    require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
                    $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
                    $myscore = $appdata['data']['gold'];
                    $qf_jifen = 0 - $myscore;
                    $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type'],'gold' => $qf_jifen,'reason' => 'pinche_fabu']);
                }

                $adddata2['uid']             = $paylogdata['uid'];
                $adddata2['username']        = $paylogdata['username'];
                $adddata2['money_xiaohao']   = round(($paylogdata['jine']+$isuser['money']),2);
                $adddata2['zhiding_xiaohao'] = 0;
                $adddata2['longterm']        = 0;
                $adddata2['kouchujifen']     = 0;
                $adddata2['addtime']         = $_G['timestamp'];
                $result                      = DB::insert('zimucms_pinche_userlog', $adddata2);

                DB::query("update %t set status=2 where id=%d", array(
                    'zimucms_pinche',
                    $paylogdata['pincheid'],
                ));
                
                
            }
            
            
        }
    }

    //马甲APP支付
} else if ($model == 'magapp_pay' && $_GET['md5hash'] == $formhash) {

    $pay      = round($_GET['pay_money'], 2);
    $zengsong = round($_GET['pay_nums'], 2);

$zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    $order_id = 'APP' . date('Ymd') . time();

    $sign = md5($order_id.$zmqianbao['magapp_secret']);

    $callback = urlencode($_G['siteurl'] . 'plugin.php?id=zimucms_pinche:zimucms_topay&model=magapp_topay&orderNum='.$order_id.'&sign='.$sign);

    $paytitle = lang('plugin/zimucms_pinche', 'system_text46');

if ($_G['charset'] == 'gbk') {
    $paytitle = iconv('gbk', 'utf-8', $paytitle);
}
    $urls = $zmqianbao['magapp_hostname'].'/core/pay/pay/unifiedOrder?trade_no='.$order_id.'&callback='.$callback.'&amount='.$pay.'&title='.$paytitle.'&user_id='.$_G['uid'].'&to_user_id=0&des='.$paytitle.'&remark='.$_G['uid'].'&secret='.$zmqianbao['magapp_secret'];
    $r = dfsockopen($urls);
    
    $r =  json_decode($r, true);
    if(!intval($r['success'])){
        $out['status'] = 201;
        $out['errmsg'] = urlencode($r['msg']);
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }else{

    $paydata = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => 'wxapppay',
        'jine' => $pay,
        'zengsong' => $zengsong,
        'out_trade_no' => $r['data']['unionOrderNum'],
        'orderNum' => $order_id,
        'addtime' => $_G['timestamp']
    );
    DB::insert('zimucms_pinche_paylog', $paydata);


        $out['status'] = 200;
        $out['errmsg'] = '';
        $out['orderNum'] = $order_id;
        $out['unionOrderNum'] = $r['data']['unionOrderNum'];
        $out['sign'] = $sign;
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit(); 
    }

} else if ($model == 'magapp_topay' && $_GET['md5hash'] == $formhash) {

    $zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    $orderNum    = addslashes($_GET['orderNum']);
    $unionOrderNum    = addslashes($_GET['unionOrderNum']);
    $sign    = addslashes($_GET['sign']);
    $mysign = md5($orderNum.$zmqianbao['magapp_secret']);
    if($sign!=$mysign){
        echo'sign is error!';exit();
    }

    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_pinche_paylog',
        $unionOrderNum
        ));
    if(!$paylogdata){
        echo'unionOrderNum does not exist';exit();
    }

    if($paylogdata['status']==1){

        $retfrom = dfsockopen($zmqianbao['magapp_hostname']."/core/pay/pay/orderStatusQuery?unionOrderNum=".$unionOrderNum."&secret=".$zmqianbao['magapp_secret']);

        if($retma = json_decode($retfrom, true)){
            if($retma['paycode'] == 1){



                $addata['status'] = '2';
                DB::update('zimucms_pinche_paylog', $addata, array(
                    'out_trade_no' => $unionOrderNum
                    ));
                
                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_pinche_user',
                    $_G['uid']
                    ));
                
                if ($isuser) {

                    $addata2['username'] = $_G['username'];
                    $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
                    $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
                    $addata2['uptime']   = $_G['timestamp'];
                    $result              = DB::update('zimucms_pinche_user', $addata2, array(
                        'uid' => $_G['uid']
                        ));
                    
                } else {

                    $addata3 = array(
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'allmoney' => $paylogdata['zengsong'],
                        'money' => $paylogdata['zengsong'],
                        'uptime' => $_G['timestamp']
                        );
                    $result  = DB::insert('zimucms_pinche_user', $addata3);
                    
                    
                }



            }
        }

    }


if(IN_MAGAPP && $zmqianbao['magapp_hostname'] && $zmqianbao['magapp_secret'] && $zmqianbao['is_assistant']){

    $magurl = $zmqianbao['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $_G['uid'];
    $magpostdata['type'] = 'remind';
    $zmqianbao['assistant_content'] = str_replace('#paymoney#',$paylogdata['zengsong'],$zmqianbao['assistant_content']);
    $zmqianbao['assistant_content'] = str_replace('#allmoney#',$isuser['money']+$paylogdata['zengsong'],$zmqianbao['assistant_content']);
    $magpostdata['content'] = diconv($zmqianbao['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmqianbao['assistant_secret'];
    $magpostdata['secret'] = $zmqianbao['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);
}

dheader('Location: '.ZIMUCMS_URL.'&model=userindex');

} else if ($model == 'magapp_topay2') {

    $zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    $orderNum    = addslashes($_GET['orderNum']);
    $unionOrderNum    = addslashes($_GET['unionOrderNum']);
    $sign    = addslashes($_GET['sign']);
    $mysign = md5($orderNum.$zmqianbao['magapp_secret']);
    if($sign!=$mysign){
        echo 'sign is error!';exit();
    }

    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_pinche_paylog',
        $unionOrderNum
        ));
    if(!$paylogdata){
        echo 'unionOrderNum does not exist';exit();
    }

    if($paylogdata['status']==1){

        $retfrom = dfsockopen($zmqianbao['magapp_hostname']."/core/pay/pay/orderStatusQuery?unionOrderNum=".$unionOrderNum."&secret=".$zmqianbao['magapp_secret']);

        if($retma = json_decode($retfrom, true)){
            if($retma['paycode'] == 1){


                $addata['status'] = '2';
                $result           = DB::update('zimucms_pinche_paylog', $addata, array(
                    'out_trade_no' => $unionOrderNum
                ));

                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_pinche_user',
                    $paylogdata['uid']
                ));

                DB::query("update %t set money=0,uptime=%d where uid=%d", array(
                    'zimucms_pinche_user',
                    $_G['timestamp'],
                    $paylogdata['uid'],
                ));
                
                $adddata2['uid']             = $paylogdata['uid'];
                $adddata2['username']        = $paylogdata['username'];
                $adddata2['money_xiaohao']   = round(($paylogdata['jine']+$isuser['money']),2);
                $adddata2['zhiding_xiaohao'] = 0;
                $adddata2['longterm']        = 0;
                $adddata2['kouchujifen']     = 0;
                $adddata2['addtime']         = $_G['timestamp'];
                $result                      = DB::insert('zimucms_pinche_userlog', $adddata2);

                DB::query("update %t set status=2 where id=%d", array(
                    'zimucms_pinche',
                    $paylogdata['pincheid'],
                ));


            }
        }

    }


if(IN_MAGAPP && $zmqianbao['magapp_hostname'] && $zmqianbao['magapp_secret'] && $zmqianbao['is_assistant']){

    $magurl = $zmqianbao['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $_G['uid'];
    $magpostdata['type'] = 'remind';
    $zmqianbao['assistant_content'] = str_replace('#paymoney#',$paylogdata['zengsong'],$zmqianbao['assistant_content']);
    $zmqianbao['assistant_content'] = str_replace('#allmoney#',$isuser['money']+$paylogdata['zengsong'],$zmqianbao['assistant_content']);
    $magpostdata['content'] = diconv($zmqianbao['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmqianbao['assistant_secret'];
    $magpostdata['secret'] = $zmqianbao['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);
}

dheader('Location: '.ZIMUCMS_URL.'&model=userindex');

    //支付宝支付
} else if ($model == 'alipay_pay' && $_GET['md5hash'] == $formhash) {

$zmqianbao = zimu_readfromcache_qf('setting_plugin_zimucms_pinche_qianbao');

    $pay      = round($_GET['pay_money'], 2);
    $zengsong = round($_GET['pay_nums'], 2);
    
    $out_trade_no = dgmdate(TIMESTAMP, 'YmdHis') . random(18); //创建支付订单号;
    $paydata      = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'type' => 'alipay',
        'jine' => $pay,
        'zengsong' => $zengsong,
        'out_trade_no' => $out_trade_no,
        'addtime' => $_G['timestamp']
    );
    $result       = DB::insert('zimucms_pinche_paylog', $paydata);
    
    $price   = $pay;
    $subject = 'PinChe';
    //开始支付宝支付操作
    if (checkmobile() && $zmqianbao['alipay_isopen']) {
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        $alipay_config['partner']       = $ec_partner;
        $alipay_config['seller_id']     = $alipay_config['partner'];
        $alipay_config['key']           = $ec_securitycode;
        $alipay_config['notify_url']    = $_G['siteurl'] . 'source/plugin/zimucms_pinche/class/alipay_notify_pinche.php';
        $alipay_config['return_url']    = $_G['siteurl'] . 'source/plugin/zimucms_pinche/class/alipay_notify_pinche.php';
        $alipay_config['sign_type']     = strtoupper('MD5');
        //字符编码格式 目前支持utf-8
        $alipay_config['input_charset'] = strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']        = getcwd() . '\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']     = 'http';
        $alipay_config['payment_type']  = "1";
        $alipay_config['service']       = "alipay.wap.create.direct.pay.by.user";
        require_once("source/plugin/zimucms_pinche/class/alipay_submit.class.php");
        
        //商户订单号，商户网站订单系统中唯一订单号，必填
        
        //订单名称，必填
        
        //echo $subject;exit();
        //付款金额，必填
        $total_fee = $price;
        
        //收银台页面上，商品展示的超链接，必填
        $show_url = $_G['siteurl'] . '/plugin.php?id=zimucms_pinche';
        
        //商品描述，可空
        $body         = '';
        $parameter    = array(
            "service" => $alipay_config['service'],
            "partner" => $alipay_config['partner'],
            "seller_id" => $alipay_config['seller_id'],
            "payment_type" => $alipay_config['payment_type'],
            "notify_url" => $alipay_config['notify_url'],
            "return_url" => $alipay_config['return_url'],
            "_input_charset" => trim(strtolower($alipay_config['input_charset'])),
            "out_trade_no" => $out_trade_no,
            "subject" => $subject,
            "total_fee" => $total_fee,
            "show_url" => $show_url,
            "body" => $body
            //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.2Z6TSk&treeId=60&articleId=103693&docType=1
            //如"参数名"    => "参数值"   注：上一个参数末尾需要“,”逗号。
            
        );
        //print_r($alipay_config);
        //exit();
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text    = $alipaySubmit->buildRequestForm($parameter, "get", 'ok');
        echo $html_text;
        exit();
    } else {
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        define('DISCUZ_PARTNER', $ec_partner);
        define('DISCUZ_SECURITYCODE', $ec_securitycode);
        define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
        define('STATUS_SELLER_SEND', 4);
        define('STATUS_WAIT_BUYER', 5);
        define('STATUS_TRADE_SUCCESS', 7);
        define('STATUS_REFUND_CLOSE', 17);
        
        $args = array(
            'subject' => 'UID:'.$_G['member']['uid'] . ' ' . $subject,
            'body' => 'UID:'.$_G['member']['uid'] . ' ' . $subject . $_G['clientip'],
            'service' => 'trade_create_by_buyer',
            'partner' => DISCUZ_PARTNER,
            'notify_url' => $_G['siteurl'] . 'source/plugin/zimucms_pinche/class/alipay_notify_pinche.php',
            'return_url' => $_G['siteurl'] . 'source/plugin/zimucms_pinche/class/alipay_notify_pinche.php',
            'show_url' => $_G['siteurl'],
            '_input_charset' => CHARSET,
            'out_trade_no' => $out_trade_no,
            'price' => $price,
            'quantity' => 1,
            'seller_email' => $_G['setting']['ec_account']
        );
        if (DISCUZ_DIRECTPAY) {
            $args['service']      = 'create_direct_pay_by_user';
            $args['payment_type'] = '1';
        } else {
            $args['logistics_type']    = 'EXPRESS';
            $args['logistics_fee']     = 0;
            $args['logistics_payment'] = 'SELLER_PAY';
            $args['payment_type']      = 1;
        }
        ksort($args);
        $urlstr = $sign = '';
        foreach ($args as $key => $val) {
            $sign .= '&' . $key . '=' . $val;
            $urlstr .= $key . '=' . rawurlencode($val) . '&';
        }
        $sign = substr($sign, 1);
        $sign = md5($sign . DISCUZ_SECURITYCODE);
        header('Location: https://www.alipay.com/cooperate/gateway.do?' . $urlstr . 'sign=' . $sign . '&sign_type=MD5');
    }
    
    
}


function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}
function zimu_readfromcache_qf($key = 'table_plugin_zimucms_pinche_ad'){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}
function lizimu_post($url, $data) {
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}

    function zm_diconv2($str)
    {
        global $_G;
        $encode = mb_detect_encoding($str, array(
            "UTF-8",
            "GB2312",
            "GBK",
            ));
/*
        if($encode = 'GB2312' || $encode = 'EUC-CN' || $encode = 'CP936'){
           $encode = 'GBK';
        }
*/
        if ($encode != strtoupper(CHARSET) ) {
            $keytitle = mb_convert_encoding($str,strtoupper(CHARSET), $encode);
        }

        $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'] = trim($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'])), '/')) . ')$/i';
        if ($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'] && @preg_match($censorexp,$keytitle)) {
            $keytitle = $str;
        }
        if (!$keytitle) {
            $keytitle = $str;
        }
        return $keytitle;
    }