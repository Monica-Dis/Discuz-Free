<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';
$model = addslashes($_GET['model']);
if ($model == 'add') {
	$token = addslashes($_GET['token']);
	$istoken = xcx_token_login($token);
	isallowadd();
	if ($_G['uid'] > 0) {
		$mycredict = round(DB::result_first('select money from %t where uid=%d', array('zimucms_pinche_user', $_G['uid'])), 2);
	}
	if (IN_APP == 1) {
		$money_xiaohao = round($zmdata['money_xiaohao'] * $zmdata['app_bili'] / 100, 2);
	} else {
		$money_xiaohao = $zmdata['money_xiaohao'];
	}
	if ($zmdata['pinche_model'] == 1) {
		$IsHaveCar[0] = lang('plugin/zimucms_pinche', 'system_text47');
		$IsHaveCar[1] = lang('plugin/zimucms_pinche', 'system_text48');
	} elseif ($zmdata['pinche_model'] == 2) {
		$IsHaveCar[0] = lang('plugin/zimucms_pinche', 'system_text49');
		$IsHaveCar[1] = lang('plugin/zimucms_pinche', 'system_text50');
	} else {
		$IsHaveCar[0] = lang('plugin/zimucms_pinche', 'system_text47');
		$IsHaveCar[1] = lang('plugin/zimucms_pinche', 'system_text48');
		$IsHaveCar[2] = lang('plugin/zimucms_pinche', 'system_text49');
		$IsHaveCar[3] = lang('plugin/zimucms_pinche', 'system_text50');
	}
	$zhiding_type = explode("\r\n", trim($zmdata['money_type']));
	foreach ($zhiding_type as $key => $v) {
		$v = str_replace('<option value="', '', $v);
		$v = str_replace('" zhidingtime="', '=', $v);
		$v = str_replace('">', '=', $v);
		$v = str_replace('</option>', '', $v);
		$TopInfo[$key] = explode('=', $v);
	}
	foreach ($TopInfo as $key => $value) {
		$TopInfo2[$key]['money'] = $value[0];
		$TopInfo2[$key]['zhidingtime'] = $value[1];
		$TopInfo2[$key]['text'] = $value[2];
		$TopInfo2_text[] = $value[2];
	}
	exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'uid' => $_G['uid'], 'username' => $_G['username'], 'IsHaveCar' => zimu_array_utf8($IsHaveCar), 'TopInfo' => zimu_array_utf8($TopInfo2), 'TopInfo_text' => zimu_array_utf8($TopInfo2_text), 'mycredict' => $mycredict, 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} elseif ($model == 'adding') {
	$token = addslashes($_GET['token']);
	$istoken = xcx_token_login($token);
	isallowadd();
	if ($_G['uid'] > 0) {
		$mycredict = round(DB::result_first('select money from %t where uid=%d', array('zimucms_pinche_user', $_G['uid'])), 2);
	}
	$IsHaveCar = intval($_GET['IsHaveCar']);
	if ($zmdata['pinche_model'] == 2) {
		if ($IsHaveCar == 1) {
			$IsHaveCar = 3;
		} elseif ($IsHaveCar == 2) {
			$IsHaveCar = 4;
		}
	}
	$islongterm = intval($_GET['islongterm']);
	if ($islongterm == 1) {
		$longstart = strtotime($_GET['longstart']);
		$longend = strtotime($_GET['longend']);
		$datediff = ($longend - $longstart) / 86400 + 1;
		$longterm_xiaohao = $datediff * $zmdata['longterm_bili'] / 100;
	} else {
		$longterm_xiaohao = 1;
	}
	$zhiding_type = explode("\r\n", trim($zmdata['money_type']));
	foreach ($zhiding_type as $key => $v) {
		$v = str_replace('<option value="', '', $v);
		$v = str_replace('" zhidingtime="', '=', $v);
		$v = str_replace('">', '=', $v);
		$v = str_replace('</option>', '', $v);
		$TopInfo2[$key] = explode('=', $v);
	}
	foreach ($TopInfo2 as $key => $value) {
		$TopInfo3[$key]['money'] = $value[0];
		$TopInfo3[$key]['zhidingtime'] = $value[1];
		$TopInfo3[$key]['text'] = $value[2];
	}
	if ($zmdata['is_open_money']) {
		if ($IsHaveCar == 2 && $zmdata['rentoche_free'] == 1) {
			$money_xiaohao = 0;
		} else {
			if ($IsHaveCar == 4 && $zmdata['huotoche_free'] == 1) {
				$money_xiaohao = 0;
			} else {
				$money_xiaohao = round($zmdata['money_xiaohao'], 2);
			}
		}
		$TopInfo = intval($_GET['TopInfo']);
		$TopInfo_xiaohao = round($TopInfo3[$TopInfo]['money'], 2);
		if (IN_APP == 1) {
			$money_xiaohao = round($zmdata['money_xiaohao'] * $zmdata['app_bili'] / 100, 2);
			$TopInfo_xiaohao = round($TopInfo_xiaohao * $zmdata['app_bili2'] / 100, 2);
		}
		$kouchujifen = $money_xiaohao * $longterm_xiaohao + $TopInfo_xiaohao;
		$kouchujifen = round($kouchujifen, 2);
		if ($mycredict - $kouchujifen < 0) {
			exit(json_encode(array('error' => zimu_array_utf8(lang('plugin/zimucms_pinche', 'system_text17')), 'timestamp' => $_G['timestamp'])));
		}
	}
	if ($todayusercount >= $zmdata['nums_clientip'] && $zmdata['isguest_add']) {
		showmessage(lang('plugin/zimucms_pinche', 'system_text15') . $zmdata['nums_clientip'] . lang('plugin/zimucms_pinche', 'system_text16'));
	} else {
		$adddata['useruid'] = $_G['uid'];
		$adddata['leixing'] = $IsHaveCar;
		if ($islongterm == 1) {
			$adddata['starttime'] = strtotime($_GET['StartTime']) - strtotime(date('Y-m-d', $_G['timestamp']));
			$adddata['longstart'] = $longstart;
			$adddata['longend'] = $longend;
		} else {
			$adddata['starttime'] = strtotime($_GET['StartTime']);
		}
		$adddata['timetext'] = strip_tags(zm_diconv($_GET['StartTimeMore']));
		$adddata['chufadi'] = strip_tags(zm_diconv($_GET['StartPlace']));
		$adddata['mudidi'] = strip_tags(zm_diconv($_GET['ToPlace']));
		$adddata['tujing'] = strip_tags(zm_diconv($_GET['MiddlePlace']));
		$adddata['kongwei'] = intval($_GET['PersonNum']);
		$adddata['lianxi'] = strip_tags($_GET['Contact']);
		$adddata['beizhu'] = strip_tags(zm_diconv($_GET['MoreNote']));
		$adddata['sort'] = 100;
		$adddata['status'] = 2;
		$adddata['iszhiding'] = 0;
		$adddata['zhidingtype'] = $TopInfo;
		$adddata['islongterm'] = $islongterm;
		if (!$zmdata['isguest_add'] && $_G['uid'] > 0 && $adddata['zhidingtype'] > 0) {
			$adddata['zhidingendtime'] = $_G['timestamp'] + intval($TopInfo3[$TopInfo]['zhidingtime']) * 60;
		}
		$adddata['addtime'] = $_G['timestamp'];
		$adddata['clientip'] = $_G['clientip'];
		$result = DB::insert('zimucms_pinche', $adddata, 1);
		$pincheid = $result;
		if ($result) {
			if (!$zmdata['isguest_add'] && $_G['uid'] > 0) {
				DB::query('update %t set money=money-' . $kouchujifen . ' where uid=%d', array('zimucms_pinche_user', $_G['uid']));
				$adddata2['uid'] = $_G['uid'];
				$adddata2['username'] = $_G['username'];
				$adddata2['money_xiaohao'] = $money_xiaohao;
				$adddata2['zhiding_xiaohao'] = $TopInfo_xiaohao;
				$adddata2['longterm'] = $datediff;
				$adddata2['kouchujifen'] = $kouchujifen;
				$adddata2['addtime'] = $_G['timestamp'];
				$result = DB::insert('zimucms_pinche_userlog', $adddata2);
			}
		}
		$topost_forum = explode("\r\n", trim($zmdata['topost_forum']));
		foreach ($topost_forum as $key => $v) {
			$topost_forum[$key] = explode('=', $v);
		}
		if ($topost_forum[$IsHaveCar - 1][0] && $_G['uid'] > 0) {
			include_once libfile('function/forum');
			include_once libfile('function/post');
			include_once libfile('function/stat');
			include_once libfile('function/editor');
			if ($IsHaveCar == 1) {
				$leixingtitle = lang('plugin/zimucms_pinche', 'system_text47');
				$kongweitext = lang('plugin/zimucms_pinche', 'system_text52');
			} elseif ($IsHaveCar == 2) {
				$leixingtitle = lang('plugin/zimucms_pinche', 'system_text48');
				$kongweitext = lang('plugin/zimucms_pinche', 'system_text53');
			} elseif ($IsHaveCar == 3) {
				$leixingtitle = lang('plugin/zimucms_pinche', 'system_text49');
				$kongweitext = lang('plugin/zimucms_pinche', 'system_text54');
			} elseif ($IsHaveCar == 4) {
				$leixingtitle = lang('plugin/zimucms_pinche', 'system_text50');
				$kongweitext = lang('plugin/zimucms_pinche', 'system_text55');
			}
			$todaytime = strtotime(date('Y-m-d', $_G['timestamp']));
			$tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
			$tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
			$tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
			$weekarray = array(lang('plugin/zimucms_pinche', 'system_text14'), lang('plugin/zimucms_pinche', 'system_text8'), lang('plugin/zimucms_pinche', 'system_text9'), lang('plugin/zimucms_pinche', 'system_text10'), lang('plugin/zimucms_pinche', 'system_text11'), lang('plugin/zimucms_pinche', 'system_text12'), lang('plugin/zimucms_pinche', 'system_text13'));
			if ($islongterm == 1) {
				$adddata['starttime'] = $adddata['starttime'] + strtotime(date('Y-m-d', $_G['timestamp']));
			}
			if ($adddata['starttime'] > $tomorrowtime3) {
				$text1 = date('m', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
			} elseif ($adddata['starttime'] > $tomorrowtime2) {
				$text1 = lang('plugin/zimucms_pinche', 'system_text5');
			} elseif ($adddata['starttime'] > $tomorrowtime1) {
				$text1 = lang('plugin/zimucms_pinche', 'system_text4');
			} elseif ($adddata['starttime'] > $todaytime) {
				$text1 = lang('plugin/zimucms_pinche', 'system_text3');
			} else {
				$text1 = date('m', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
			}
			$adddata['text1'] = $text1;
			$adddata['text2'] = $weekarray[date('w', $adddata['starttime'])];
			if ($islongterm == 1) {
				$subtitle = $leixingtitle . '  ' . lang('plugin/zimucms_pinche', 'system_text21');
			} else {
				$subtitle = $leixingtitle . '  ' . $adddata['text1'] . '(' . $adddata['text2'] . ')';
			}
			$tid_title = $subtitle . date('H:i', $adddata['starttime']) . $adddata['chufadi'] . lang('plugin/zimucms_pinche', 'system_text51') . $adddata['mudidi'] . $adddata['kongwei'] . $kongweitext . $adddata['timetext'];
			$tid_content = '<p>' . lang('plugin/zimucms_pinche', 'system_text56') . $leixingtitle . '</p>';
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text57') . $adddata['chufadi'] . '</p>';
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text58') . $adddata['mudidi'] . '</p>';
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text65') . $adddata['tujing'] . '</p>';
			if ($islongterm == 1) {
				$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text59') . lang('plugin/zimucms_pinche', 'system_text21');
			} else {
				$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text59') . ($adddata['text1'] = $text1 . $adddata['text2']);
			}
			$tid_content = $tid_content . date('H:i', $adddata['starttime']) . '</p>';
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text60') . $adddata['lianxi'] . '</p>';
			if ($IsHaveCar == 1 || $IsHaveCar == 2) {
				$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text61') . $adddata['kongwei'] . $kongweitext . '</p>';
			} else {
				$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text62') . $adddata['kongwei'] . $kongweitext . '</p>';
			}
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text63') . $adddata['beizhu'] . '</p>';
			$tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text64') . date('Y-m-d H:i:s', $adddata['addtime']) . '</p>';
			$newthread = array('fid' => $topost_forum[$IsHaveCar - 1][0], 'typeid' => $topost_forum[$IsHaveCar - 1][1], 'author' => $_G['username'], 'authorid' => $_G['uid'], 'subject' => $tid_title, 'dateline' => TIMESTAMP, 'lastpost' => TIMESTAMP, 'lastposter' => $_G['username']);
			$tid = C::t('forum_thread')->insert($newthread, true);
			$newsdata_content = html2bbcode($tid_content);
			$pid = insertpost(array('fid' => $topost_forum[$IsHaveCar - 1][0], 'tid' => $tid, 'author' => $_G['username'], 'authorid' => $_G['uid'], 'subject' => $tid_title, 'dateline' => TIMESTAMP, 'message' => $newsdata_content, 'useip' => '127.0.0.1', 'first' => '1'));
			if (!isset($_G['cache']['forums'])) {
				loadcache('forums');
			}
			useractionlog($_G['uid'], 'tid');
			C::t('common_member_field_home')->update($_G['uid'], array('recentnote' => $tid_title));
			$lastpost = $tid . '	' . $tid_title . '	' . TIMESTAMP . ('	' . $_G['username']);
			C::t('forum_forum')->update($topost_forum[$IsHaveCar - 1][0], array('lastpost' => $lastpost));
			C::t('forum_forum')->update_forum_counter($topost_forum[$IsHaveCar - 1][0], 1, 1, 1);
			if ($_G['cache']['forums'][$topost_forum[$IsHaveCar - 1][0]]['type'] == 'sub') {
				C::t('forum_forum')->update($_G['cache']['forums'][$topost_forum[$IsHaveCar - 1][0]]['fup'], array('lastpost' => $lastpost));
			}
		}
		exit(json_encode(array('error' => 'ok', 'pid' => $pincheid, 'timestamp' => $_G['timestamp'])));
	}
} elseif ($model == 'mianze') {
	include template('zimucms_pinche:mianze');
} elseif ($model == 'view') {
	$pid = intval($_GET['pid']);
	$todaytime = strtotime(date('Y-m-d', $_G['timestamp']));
	$tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
	$tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
	$tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
	$weekarray = array(lang('plugin/zimucms_pinche', 'system_text14'), lang('plugin/zimucms_pinche', 'system_text8'), lang('plugin/zimucms_pinche', 'system_text9'), lang('plugin/zimucms_pinche', 'system_text10'), lang('plugin/zimucms_pinche', 'system_text11'), lang('plugin/zimucms_pinche', 'system_text12'), lang('plugin/zimucms_pinche', 'system_text13'));
	$pincheview = DB::fetch_first('select * from %t where id=%d', array('zimucms_pinche', $pid));
	if ($pincheview['islongterm'] == 1) {
		$pincheview['starttime'] = $pincheview['starttime'] + strtotime(date('Y-m-d', $_G['timestamp']));
	}
	if ($pincheview['starttime'] > $tomorrowtime3) {
		$text1 = date('m', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
	} elseif ($pincheview['starttime'] > $tomorrowtime2) {
		$text1 = lang('plugin/zimucms_pinche', 'system_text5');
	} elseif ($pincheview['starttime'] > $tomorrowtime1) {
		$text1 = lang('plugin/zimucms_pinche', 'system_text4');
	} elseif ($pincheview['starttime'] > $todaytime) {
		$text1 = lang('plugin/zimucms_pinche', 'system_text3');
	} else {
		$text1 = date('m', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
	}
	$pincheview['text1'] = $text1;
	$pincheview['text2'] = $weekarray[date('w', $pincheview['starttime'])];
	$pincheview['starttime_format'] = date('H:i', $pincheview['starttime']);
	$pincheview['addtime_format'] = date('Y-m-d H:i:s', $pincheview['addtime']);
	$addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array('zimucms_pinche_ad'));
	foreach ($addata as $key => $value) {
		$addata_api[$key] = $value['thumb'];
	}
	$share_title = $zmdata['view_share_title'];
	if ($pincheview['leixing'] == 1) {
		$share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text7'), $share_title);
		$share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text52'), $share_title);
	} elseif ($pincheview['leixing'] == 2) {
		$share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text8'), $share_title);
		$share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text53'), $share_title);
	} elseif ($pincheview['leixing'] == 3) {
		$share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text39'), $share_title);
		$share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text54'), $share_title);
	} elseif ($pincheview['leixing'] == 4) {
		$share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text40'), $share_title);
		$share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text55'), $share_title);
	}
	$share_title = str_replace('#chufadi#', $pincheview['chufadi'], $share_title);
	$share_title = str_replace('#mudidi#', $pincheview['mudidi'], $share_title);
	$share_title = str_replace('#tujing#', $pincheview['tujing'], $share_title);
	if ($pincheview['islongterm'] == 1) {
		$share_title = str_replace('#starttime#', lang('plugin/zimucms_pinche', 'xcx_tpl_text48') . date('H:i', $pincheview['starttime']), $share_title);
	} else {
		$share_title = str_replace('#starttime#', $pincheview['text1'] . '(' . $pincheview['text2'] . ')', $share_title);
	}
	$share_title = str_replace('#timetext#', $pincheview['timetext'], $share_title);
	$share_title = str_replace('#lianxi#', $pincheview['lianxi'], $share_title);
	$share_title = str_replace('#beizhu#', $pincheview['beizhu'], $share_title);
	$share_desc = $zmdata['view_share_desc'];
	if ($pincheview['leixing'] == 1) {
		$share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text7'), $share_desc);
		$share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text52'), $share_desc);
	} elseif ($pincheview['leixing'] == 2) {
		$share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text8'), $share_desc);
		$share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text53'), $share_desc);
	} elseif ($pincheview['leixing'] == 3) {
		$share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text39'), $share_desc);
		$share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text54'), $share_desc);
	} elseif ($pincheview['leixing'] == 4) {
		$share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text40'), $share_desc);
		$share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text55'), $share_desc);
	}
	$share_desc = str_replace('#chufadi#', $pincheview['chufadi'], $share_desc);
	$share_desc = str_replace('#mudidi#', $pincheview['mudidi'], $share_desc);
	$share_desc = str_replace('#tujing#', $pincheview['tujing'], $share_desc);
	if ($pincheview['islongterm'] == 1) {
		$share_desc = str_replace('#starttime#', lang('plugin/zimucms_pinche', 'xcx_tpl_text48') . date('H:i', $pincheview['starttime']), $share_desc);
	} else {
		$share_desc = str_replace('#starttime#', $pincheview['text1'] . '(' . $pincheview['text2'] . ')', $share_desc);
	}
	$share_desc = str_replace('#timetext#', $pincheview['timetext'], $share_desc);
	$share_desc = str_replace('#lianxi#', $pincheview['lianxi'], $share_desc);
	$share_desc = str_replace('#beizhu#', $pincheview['beizhu'], $share_desc);
	$share_url = '/pages/view/view?pid=' . $pid;
	exit(json_encode(array('pincheview' => zimu_array_utf8($pincheview), 'addata' => zimu_array_utf8($addata_api), 'share_title' => zimu_array_utf8($share_title), 'share_thumb' => $share_thumb, 'share_url' => $share_url, 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} elseif ($model == 'userindex') {
	$token = addslashes($_GET['token']);
	$istoken = xcx_token_login($token);
	if ($istoken == 'error') {
		exit(json_encode(array('token_error' => 'token_error')));
	}
	isallowadd();
	if ($_G['uid'] > 0) {
		$mycredict = round(DB::result_first('select money from %t where uid=%d', array('zimucms_pinche_user', $_G['uid'])), 2);
	}
	$pinchedata = DB::fetch_all('select * from %t where status=2 and useruid=%d order by id desc limit 100', array('zimucms_pinche', $_G['uid']));
	foreach ($pinchedata as $key => $value) {
		if ($value['islongterm'] == 1) {
			$pinchedata[$key]['starttime_format'] = date('H:i', $pinchedata[$key]['starttime']);
		} else {
			$pinchedata[$key]['starttime_format'] = date('Y-m-d H:i', $pinchedata[$key]['starttime']);
		}
		$pinchedata[$key]['addtime_format'] = date('Y-m-d H:i:s', $pinchedata[$key]['addtime']);
	}
	exit(json_encode(array('pinchedata' => zimu_array_utf8($pinchedata), 'uid' => $_G['uid'], 'username' => $_G['username'], 'mycredict' => $mycredict, 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} elseif ($model == 'soso') {
	$todaytime = strtotime(date('Y-m-d', $_G['timestamp']));
	$tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
	$tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
	$tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
	$olddaytime = strtotime(date('Y-m-d', $_G['timestamp'])) - 86400 * $zmdata['old_days'];
	$weekarray = array(lang('plugin/zimucms_pinche', 'system_text14'), lang('plugin/zimucms_pinche', 'system_text8'), lang('plugin/zimucms_pinche', 'system_text9'), lang('plugin/zimucms_pinche', 'system_text10'), lang('plugin/zimucms_pinche', 'system_text11'), lang('plugin/zimucms_pinche', 'system_text12'), lang('plugin/zimucms_pinche', 'system_text13'));
	$type = intval($_GET['type']);
	if ($type) {
		$wheresql = 'and leixing=' . $type . ' and starttime > ' . $olddaytime;
	} else {
		$wheresql = 'and starttime > ' . $olddaytime;
	}
	$fromPlace = strip_tags(zm_diconv($_GET['fromPlace']));
	$toPlace = strip_tags(zm_diconv($_GET['toPlace']));
	$fromPlace = str_replace('%', '', $fromPlace);
	$fromPlace = str_replace('_', '', $fromPlace);
	$toPlace = str_replace('%', '', $toPlace);
	$toPlace = str_replace('_', '', $toPlace);
	$pinchedata = DB::fetch_all('select * from %t where status=2 ' . $wheresql . ' and chufadi like %s and ( mudidi like %s or tujing like %s ) order by sort asc,starttime desc limit 100', array('zimucms_pinche', '%' . $fromPlace . '%', '%' . $toPlace . '%', '%' . $toPlace . '%'));
	foreach ($pinchedata as $key => $value) {
		if ($value['starttime'] > $tomorrowtime3) {
			$text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
		} elseif ($value['starttime'] > $tomorrowtime2) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text5');
		} elseif ($value['starttime'] > $tomorrowtime1) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text4');
		} elseif ($value['starttime'] > $todaytime) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text3');
		} else {
			$text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
		}
		$pinchedata[$key]['text1'] = $text1;
		$pinchedata[$key]['text2'] = $weekarray[date('w', $value['starttime'])];
		$pinchedata[$key]['starttime_format'] = date('H:i', $pinchedata[$key]['starttime']);
		$pinchedata[$key]['addtime_format'] = date('Y-m-d H:i:s', $pinchedata[$key]['addtime']);
	}
	if (file_exists(DISCUZ_ROOT . './data/sysdata/table_plugin_zimucms_pinche_ad.php')) {
		$addata = zimu_readfromcache('table_plugin_zimucms_pinche_ad');
	} else {
		$addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array('zimucms_pinche_ad'));
		zimu_writetocache('table_plugin_zimucms_pinche_ad', $addata);
	}
	if (file_exists(DISCUZ_ROOT . './data/sysdata/table_plugin_zimucms_pinche_allviews.php')) {
		$allviews = zimu_readfromcache('table_plugin_zimucms_pinche_allviews');
		$addata['allviews'] = $allviews['allviews'] + 1;
		zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
	} else {
		$addata['allviews'] = 0;
		zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
	}
	exit(json_encode(array('pinchedata' => zimu_array_utf8($pinchedata), 'allpinchenums' => count($pinchedata), 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} elseif ($model == 'delpid') {
	$token = addslashes($_GET['token']);
	xcx_token_login($token);
	$pid = intval($_GET['pid']);
	$result = DB::delete('zimucms_pinche', array('id' => $pid));
	if ($result) {
		$out['status'] = 200;
		echo $result = json_encode($out);
		exit(0);
	} else {
		$out['status'] = 202;
		echo $result = json_encode($out);
		exit(0);
	}
} elseif ($model == 'topay') {
	$token = addslashes($_GET['token']);
	xcx_token_login($token);
	$myopenid = DB::result_first('select openid from %t where uid=%d and xcx_appid=%s', array('zimu_xcx_accesstoken', $_G['uid'], $zmdata['xcx_appid']));
	$mycredict = round(DB::result_first('select money from %t where uid=%d', array('zimucms_pinche_user', $_G['uid'])), 2);
	$ii = 0;
	foreach (explode("\n", $zmdata['money_chongzhi']) as $value) {
		list($key, $val, $text) = explode('=', $value);
		$money_chongzhi[$ii]['money'] = $key;
		$money_chongzhi[$ii]['nums'] = $val;
		$money_chongzhi[$ii]['text'] = $text;
		$ii++;
	}
	$money_chongzhi2 = $money_chongzhi;
	exit(json_encode(array('myopenid' => $myopenid, 'money_chongzhi' => zimu_array_utf8($money_chongzhi2), 'uid' => $_G['uid'], 'username' => $_G['username'], 'mycredict' => $mycredict, 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} elseif ($model == 'towxpay') {
	$token = addslashes($_GET['token']);
	xcx_token_login($token);
	$money_chongzhi_index = intval($_GET['money_chongzhi_index']);
	$ii = 0;
	foreach (explode("\n", $zmdata['money_chongzhi']) as $value) {
		list($key, $val, $text) = explode('=', $value);
		$money_chongzhi[$ii]['money'] = $key;
		$money_chongzhi[$ii]['nums'] = $val;
		$money_chongzhi[$ii]['text'] = $text;
		$ii++;
	}
	$pay = round($money_chongzhi[$money_chongzhi_index]['money'], 2);
	$zengsong = round($money_chongzhi[$money_chongzhi_index]['nums'], 2);
	$openid = addslashes($_GET['openid']);
	include DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxpay_xcx.class.php';
	$input = new WxPayData();
	$input->body = diconv(cutstr(lang('plugin/zimucms_pinche', 'system_text18'), 32, ''), CHARSET, 'utf-8');
	$input->out_trade_no = $_G['uid'] . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
	$input->total_fee = intval($pay * 100);
	$input->time_start = date('YmdHis');
	$input->time_expire = date('YmdHis', TIMESTAMP + 600);
	$input->notify_url = ZIMUCMS_URL;
	$input->product_id = diconv(lang('plugin/zimucms_pinche', 'system_text18'), CHARSET, 'utf-8') . $_G['uid'];
	$input->fromtype = 'ZM_PINCHE';
	$input->fromid = $_G['uid'];
	$input->openid = $openid;
	$input->trade_type = 'JSAPI';
	$jsPay = new JsApiPay();
	$result = WxPayApi::unifiedOrder($input);
	if ($result['return_code'] == 'FAIL') {
		showmessage(diconv($result['return_msg'], 'utf-8', CHARSET));
	}
	if ($result['result_code'] == 'FAIL') {
		showmessage(diconv($result['err_code_des'], 'utf-8', CHARSET));
	}
	$wxpay = $jsPay->getJsApiParameters($result);
	$wxpay = json_decode($wxpay);
	$wxpay = object_array($wxpay);
	$wxpay['out_trade_no'] = $input->out_trade_no;
	$wxtype = 'xcx_pay';
	$paydata = array('uid' => $_G['uid'], 'username' => $_G['username'], 'type' => $wxtype, 'jine' => $pay, 'zengsong' => $zengsong, 'out_trade_no' => $wxpay['out_trade_no'], 'addtime' => $_G['timestamp']);
	$result = DB::insert('zimucms_pinche_paylog', $paydata);
	if ($result) {
		echo json_encode($wxpay);
	}
} elseif ($model == 'paysuccess') {
	$token = addslashes($_GET['token']);
	xcx_token_login($token);
	$out_trade_no = addslashes($_GET['out_trade_no']);
	include DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxpay_xcx.class.php';
	$input = new WxPayData();
	$input->out_trade_no = $out_trade_no;
	$jsPay = new JsApiPay();
	$result = WxPayApi::orderQuery($input);
	$paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array('zimucms_pinche_paylog', $input->out_trade_no));
	if ($result['trade_state'] == 'SUCCESS' && $paylogdata['status'] == 1) {
		$addata['status'] = '2';
		$result = DB::update('zimucms_pinche_paylog', $addata, array('out_trade_no' => $input->out_trade_no));
		$isuser = DB::fetch_first('select * from %t where uid=%d', array('zimucms_pinche_user', $_G['uid']));
		if ($isuser) {
			$addata2['username'] = $_G['username'];
			$addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
			$addata2['money'] = $isuser['money'] + $paylogdata['zengsong'];
			$addata2['uptime'] = $_G['timestamp'];
			$result = DB::update('zimucms_pinche_user', $addata2, array('uid' => $_G['uid']));
		} else {
			$addata3 = array('uid' => $_G['uid'], 'username' => $_G['username'], 'allmoney' => $paylogdata['zengsong'], 'money' => $paylogdata['zengsong'], 'uptime' => $_G['timestamp']);
			$result = DB::insert('zimucms_pinche_user', $addata3);
		}
	}
	echo '{"code":333}';
} else {
	$todaytime = strtotime(date('Y-m-d', $_G['timestamp']));
	$tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
	$tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
	$tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
	$olddaytime = strtotime(date('Y-m-d', $_G['timestamp'])) - 86400 * $zmdata['old_days'];
	$weekarray = array(lang('plugin/zimucms_pinche', 'system_text14'), lang('plugin/zimucms_pinche', 'system_text8'), lang('plugin/zimucms_pinche', 'system_text9'), lang('plugin/zimucms_pinche', 'system_text10'), lang('plugin/zimucms_pinche', 'system_text11'), lang('plugin/zimucms_pinche', 'system_text12'), lang('plugin/zimucms_pinche', 'system_text13'));
	$type = intval($_GET['type']);
	if ($type) {
		$wheresql = 'and leixing=' . $type;
	}
	$zhiding_pinchedata = DB::fetch_all('select * from %t where zhidingendtime>%d and status=2 ' . $wheresql . ' order by zhidingendtime asc,starttime asc limit 100', array('zimucms_pinche', $_G['timestamp']));
	foreach ($zhiding_pinchedata as $key => $value) {
		if ($zhiding_pinchedata[$key]['islongterm'] == 1) {
			$zhiding_pinchedata[$key]['starttime'] = $zhiding_pinchedata[$key]['starttime'] + $todaytime;
		}
	}
	$zhiding_pinchedata = array_sort($zhiding_pinchedata, 'starttime', 'asc');
	if (!$zhiding_pinchedata) {
		$zhiding_pinchedata = array();
	}
	$now_pinchedata1 = DB::fetch_all('select * from %t where starttime>%d and zhidingendtime<%d and status=2 and islongterm=0 ' . $wheresql . ' order by sort asc,starttime asc limit 100', array('zimucms_pinche', $_G['timestamp'], $_G['timestamp']));
	$now_pinchedata2 = DB::fetch_all('select * from %t where starttime>%d and zhidingendtime<%d and longend >= %d and status=2 and islongterm=1 ' . $wheresql . ' order by sort asc,starttime asc limit 100', array('zimucms_pinche', $_G['timestamp'] - $todaytime, $_G['timestamp'], $todaytime));
	$now_pinchedata3 = DB::fetch_all('select * from %t where starttime<=%d and zhidingendtime<%d and longend >= %d and status=2 and islongterm=1 ' . $wheresql . ' order by sort asc,starttime asc limit 100', array('zimucms_pinche', $_G['timestamp'] - $todaytime, $_G['timestamp'], $todaytime));
	foreach ($now_pinchedata2 as $key => $value) {
		$now_pinchedata2[$key]['starttime'] = $now_pinchedata2[$key]['starttime'] + $todaytime;
	}
	foreach ($now_pinchedata3 as $key => $value) {
		$now_pinchedata3[$key]['starttime'] = $now_pinchedata3[$key]['starttime'] + $todaytime;
	}
	if (!$now_pinchedata1) {
		$now_pinchedata1 = array();
	}
	if (!$now_pinchedata2) {
		$now_pinchedata2 = array();
	}
	if (!$now_pinchedata3) {
		$now_pinchedata3 = array();
	}
	$now_pinchedata4 = array_merge($now_pinchedata1, $now_pinchedata2);
	$now_pinchedata4 = array_sort($now_pinchedata4, 'starttime', 'asc');
	if (!$now_pinchedata4) {
		$now_pinchedata4 = array();
	}
	$now_pinchedata = array_merge($now_pinchedata4, $now_pinchedata3);
	if (!$now_pinchedata) {
		$now_pinchedata = array();
	}
	$oldpinchedata1 = DB::fetch_all('select * from %t where status=2 and starttime < %d and starttime >%d ' . $wheresql . ' order by starttime desc limit 100', array('zimucms_pinche', $_G['timestamp'], $olddaytime));
	$oldpinchedata2 = DB::fetch_all('select * from %t where status=2 and longend < %d and longend >%d and islongterm=1 ' . $wheresql . ' order by starttime desc limit 100', array('zimucms_pinche', $_G['timestamp'], $olddaytime));
	if (!$oldpinchedata1) {
		$oldpinchedata1 = array();
	}
	if (!$oldpinchedata2) {
		$oldpinchedata2 = array();
	}
	$oldpinchedata = array_merge($oldpinchedata1, $oldpinchedata2);
	$pinchedata = array_merge($zhiding_pinchedata, $now_pinchedata, $oldpinchedata);
	foreach ($pinchedata as $key => $value) {
		if ($value['starttime'] > $tomorrowtime3) {
			$text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
		} elseif ($value['starttime'] > $tomorrowtime2) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text5');
		} elseif ($value['starttime'] > $tomorrowtime1) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text4');
		} elseif ($value['starttime'] > $todaytime) {
			$text1 = lang('plugin/zimucms_pinche', 'system_text3');
		} else {
			$text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
		}
		$pinchedata[$key]['text1'] = $text1;
		$pinchedata[$key]['text2'] = $weekarray[date('w', $value['starttime'])];
		$pinchedata[$key]['starttime_format'] = date('H:i', $pinchedata[$key]['starttime']);
		$pinchedata[$key]['addtime_format'] = date('Y-m-d H:i:s', $pinchedata[$key]['addtime']);
	}
	if (file_exists(DISCUZ_ROOT . './data/sysdata/table_plugin_zimucms_pinche_ad.php')) {
		$addata = zimu_readfromcache('table_plugin_zimucms_pinche_ad');
	} else {
		$addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array('zimucms_pinche_ad'));
		zimu_writetocache('table_plugin_zimucms_pinche_ad', $addata);
	}
	foreach ($addata as $key => $value) {
		$addata_api[$key] = $value['thumb'];
	}
	$share_title = $zmdata['share_title'];
	$share_desc = $zmdata['share_desc'];
	$share_thumb = $zmdata['share_thumb'];
	$share_url = '/pages/index/index';
	exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'pinchedata' => zimu_array_utf8($pinchedata), 'allpinchenums' => count($pinchedata), 'addata' => zimu_array_utf8($addata_api), 'share_title' => zimu_array_utf8($share_title), 'share_thumb' => $share_thumb, 'share_url' => $share_url, 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
}