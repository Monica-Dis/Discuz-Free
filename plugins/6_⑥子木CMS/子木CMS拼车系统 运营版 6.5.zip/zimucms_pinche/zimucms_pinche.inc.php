<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';
if (IN_WECHAT && $zmdata['weixin_appid'] && $zmdata['weixin_appsecret']) {
    require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage();
}
$model = addslashes($_GET['model']);


//print_r($_G['extgroupids']);exit();

if (IN_WECHAT && $zmdata['weixin_appid'] && $zmdata['weixin_appsecret'] && $zmdata['weixin_erweima'] && getcookie('zimucms_pinche_subscribe') != 1 && $zmdata['mp_qrcode_time'] > 0) {

    zm_wechat_auth('newindex');

    if (IN_WECHAT) {
        list($openid, $uptime) = getcookie('zm_qianbao') ? explode("\t", authcode(getcookie('zm_qianbao'), 'DECODE')) : array();
    }  
    $wechatinfo    = $wechat_client->getUserInfoById($openid);

    if ($wechatinfo['subscribe'] == 1) {
        dsetcookie('zimu_zhaopin_subscribe', 1, 600);
    } elseif (getcookie('zimu_zhaopin_subscribe') != 1) {
        $show_mp_qrcode = 1;
        dsetcookie('zimucms_pinche_subscribe', 1, $zmdata['mp_qrcode_time']);
    }

}




if ($model == 'add') {
    
    if (submitcheck('addpinche')) {
        
        isallowadd();

        $todayusercount = DB::result_first("SELECT count(*) FROM %t where starttime>%d and clientip=%s", array(
            "zimucms_pinche",
            strtotime(date('Y-m-d', $_G['timestamp'])),
            $_G['clientip']
        ));
        
        if ($_G['uid'] > 0) {
            if ($zmdata['is_open_money']) {

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $mycredict = $appdata['data']['gold'];

    }else{

            $mycredict = round(DB::result_first('select money from %t where uid=%d', array(
                'zimucms_pinche_user',
                $_G['uid']
            )), 2);

    }


            } else {
                $mycredict = getuserprofile('extcredits' . $zmdata['jifen_type']);
            }
        }
        
        $IsHaveCar = intval($_GET['IsHaveCar']);
        
        $islongterm = intval($_GET['islongterm']);
        
        if ($islongterm == 1) {
            
            $longstart        = strtotime($_GET['longstart']);
            $longend          = strtotime($_GET['longend']);
            $datediff         = ($longend - $longstart) / 86400 + 1;
            $longterm_xiaohao = $datediff * $zmdata['longterm_bili'] / 100;
            
        } else {
            
            $longterm_xiaohao = 1;
            
        }
        
        if (!$zmdata['isguest_add']) {
            
            if ($zmdata['is_open_money']) {
                
                if ($IsHaveCar == 2 && $zmdata['rentoche_free'] == 1) {
                    $money_xiaohao = 0;
                } else if ($IsHaveCar == 4 && $zmdata['huotoche_free'] == 1) {
                    $money_xiaohao = 0;
                } else {
                    $money_xiaohao = round($zmdata['money_xiaohao'], 2);
                }
                
                $TopInfo_xiaohao = round($_GET['TopInfo'], 2);
                
                if (IN_APP == 1) {
                    
                    $money_xiaohao = round($money_xiaohao * $zmdata['app_bili'] / 100, 2);
                    
                    $TopInfo_xiaohao = round($TopInfo_xiaohao * $zmdata['app_bili2'] / 100, 2);
                    
                }
                
                $freegroups = empty($zmdata['free_group']) ? array() : unserialize($zmdata['free_group']);
                $free_nums = DB::result_first("SELECT count(*) FROM %t where useruid=%d and isfree=1 and addtime>%d", array(
                    "zimucms_pinche",
                    $_G['uid'],
                    strtotime(date("Y-m-01", time()))
                ));

                if (in_array($_G['group']['groupid'], $freegroups) && $free_nums < $zmdata['free_group_nums']){
                    if($money_xiaohao>0){
                    $isfree = 1;
                    $money_xiaohao = 0;
                    }
                }else{
                    $extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
                    foreach ($extgroupids as $key => $value) {
                        if (in_array($value, $freegroups) && $free_nums < $zmdata['free_group_nums']){
                            if($money_xiaohao>0){
                            $isfree = 1;
                            $money_xiaohao = 0;
                            }
                        }
                    }
                }

                $kouchujifen = $money_xiaohao * $longterm_xiaohao + $TopInfo_xiaohao;
                $kouchujifen = round($kouchujifen, 2);
                
                if ($mycredict - $kouchujifen < 0) {
                    showmessage(lang('plugin/zimucms_pinche', 'system_text17'));
                }
            } else {
                
                if ($IsHaveCar == 2 && $zmdata['rentoche_free'] == 1) {
                    $jifen_xiaohao = 0;
                } else if ($IsHaveCar == 4 && $zmdata['huotoche_free'] == 1) {
                    $jifen_xiaohao = 0;
                } else {
                    $jifen_xiaohao = round($zmdata['jifen_xiaohao'], 2);
                }
                
                $TopInfo_xiaohao = intval($_GET['TopInfo']);
                
                if (IN_APP == 1) {
                    
                    $jifen_xiaohao = intval($zmdata['jifen_xiaohao'] * $zmdata['app_bili'] / 100);
                    
                    $TopInfo_xiaohao = intval($TopInfo_xiaohao * $zmdata['app_bili2'] / 100);
                    
                }
                
                $freegroups = empty($zmdata['free_group']) ? array() : unserialize($zmdata['free_group']);
                $free_nums = DB::result_first("SELECT count(*) FROM %t where useruid=%d and isfree=1 and addtime>%d", array(
                    "zimucms_pinche",
                    $_G['uid'],
                    strtotime(date("Y-m-01", time()))
                ));
                if (in_array($_G['group']['groupid'], $freegroups) && $free_nums < $zmdata['free_group_nums']){
                    if($jifen_xiaohao>0){
                    $isfree = 1;
                    $jifen_xiaohao = 0;
                    }
                }else{
                    $extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
                    foreach ($extgroupids as $key => $value) {
                        if (in_array($value, $freegroups) && $free_nums < $zmdata['free_group_nums']){
                            if($jifen_xiaohao>0){
                            $isfree = 1;
                            $jifen_xiaohao = 0;
                            }
                        }
                    }
                }

                $kouchujifen = $jifen_xiaohao * $longterm_xiaohao + $TopInfo_xiaohao;
                
                $kouchujifen = round($kouchujifen, 0);
                
                
                if ($mycredict - $kouchujifen < 0) {
                    showmessage(lang('plugin/zimucms_pinche', 'system_text17'));
                }
            }
        }
        
        if ($todayusercount >= $zmdata['nums_clientip'] && $zmdata['isguest_add']) {
            showmessage(lang('plugin/zimucms_pinche', 'system_text15') . $zmdata['nums_clientip'] . lang('plugin/zimucms_pinche', 'system_text16'));
        } else {
            if (!$ZIMUCMS_MYUSER) {
                exit();
            }
            $adddata['useruid'] = $_G['uid'];
            $adddata['leixing'] = $IsHaveCar;
            if ($islongterm == 1) {
                $adddata['starttime'] = strtotime($_GET['StartTime2']) - strtotime(date('Y-m-d', $_G['timestamp']));
                $adddata['longstart'] = $longstart;
                $adddata['longend']   = $longend;
            } else {
                $adddata['starttime'] = strtotime($_GET['StartTime']);
            }
            $adddata['timetext']    = strip_tags(zm_diconv($_GET['StartTimeMore']));
            $adddata['chufadi']     = strip_tags(zm_diconv($_GET['StartPlace']));
            $adddata['mudidi']      = strip_tags(zm_diconv($_GET['ToPlace']));
            $adddata['tujing']      = strip_tags(zm_diconv($_GET['MiddlePlace']));
            $adddata['kongwei']     = intval($_GET['PersonNum']);
            $adddata['lianxi']      = strip_tags($_GET['Contact']);
            $adddata['beizhu']      = strip_tags(zm_diconv($_GET['MoreNote']));
            $adddata['sort']        = 100;
            $adddata['status']      = 2;
            $adddata['iszhiding']   = 0;
            $adddata['zhidingtype'] = round($_GET['TopInfo'], 2);
            $adddata['islongterm']  = $islongterm;
            if($isfree==1){
            $adddata['isfree']   = 1;
            }
            
            if (!$zmdata['isguest_add'] && $_G['uid'] > 0 && $adddata['zhidingtype'] > 0) {
                $adddata['zhidingendtime'] = $_G['timestamp'] + intval($_GET['zhidingtime']) * 60;
            }
            $adddata['addtime']  = $_G['timestamp'];
            $adddata['clientip'] = $_G['clientip'];
            $result              = DB::insert('zimucms_pinche', $adddata, 1);
            $pincheid            = $result;
            if ($result) {
                if (!$zmdata['isguest_add'] && $_G['uid'] > 0) {
                    
                    if ($zmdata['is_open_money']) {
                        
                        if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

                        $qf_jifen = 0 - $kouchujifen;
                        $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type'],'gold' => $qf_jifen,'reason' => 'test']);

                        }else{

                        DB::query("update %t set money=money-" . $kouchujifen . " where uid=%d", array(
                            'zimucms_pinche_user',
                            $_G['uid']
                        ));
                        
                        $adddata2['uid']             = $_G['uid'];
                        $adddata2['username']        = $_G['username'];
                        $adddata2['money_xiaohao']   = $money_xiaohao;
                        $adddata2['zhiding_xiaohao'] = $TopInfo_xiaohao;
                        $adddata2['longterm']        = $datediff;
                        $adddata2['kouchujifen']     = $kouchujifen;
                        $adddata2['addtime']         = $_G['timestamp'];
                        $result                      = DB::insert('zimucms_pinche_userlog', $adddata2);

                        }
                        
                    } else {
                        
                        updatemembercount($_G['uid'], array(
                            'extcredits' . $zmdata['jifen_type'] => '-' . $kouchujifen
                        ), true, 'CEC', 1, 'zmpinche');
                    }
                }
            }
            
            
            $topost_forum = explode("\r\n", trim($zmdata['topost_forum']));
            foreach ($topost_forum as $key => $v) {
                $topost_forum[$key] = explode('=', $v);
            }
            
            if ($topost_forum[$IsHaveCar - 1][0] && $_G['uid'] > 0) {
                
                // 开始发布帖子
                include_once libfile('function/forum');
                include_once libfile('function/post');
                include_once libfile('function/stat');
                include_once libfile('function/editor');
                
                if ($IsHaveCar == 1) {
                    $leixingtitle = lang('plugin/zimucms_pinche', 'system_text47');
                    $kongweitext  = lang('plugin/zimucms_pinche', 'system_text52');
                } else if ($IsHaveCar == 2) {
                    $leixingtitle = lang('plugin/zimucms_pinche', 'system_text48');
                    $kongweitext  = lang('plugin/zimucms_pinche', 'system_text53');
                } else if ($IsHaveCar == 3) {
                    $leixingtitle = lang('plugin/zimucms_pinche', 'system_text49');
                    $kongweitext  = lang('plugin/zimucms_pinche', 'system_text54');
                } else if ($IsHaveCar == 4) {
                    $leixingtitle = lang('plugin/zimucms_pinche', 'system_text50');
                    $kongweitext  = lang('plugin/zimucms_pinche', 'system_text55');
                }
                
                
                $todaytime     = strtotime(date('Y-m-d', $_G['timestamp']));
                $tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
                $tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
                $tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
                
                $weekarray = array(
                    lang('plugin/zimucms_pinche', 'system_text14'),
                    lang('plugin/zimucms_pinche', 'system_text8'),
                    lang('plugin/zimucms_pinche', 'system_text9'),
                    lang('plugin/zimucms_pinche', 'system_text10'),
                    lang('plugin/zimucms_pinche', 'system_text11'),
                    lang('plugin/zimucms_pinche', 'system_text12'),
                    lang('plugin/zimucms_pinche', 'system_text13')
                );
                
                
                if ($islongterm == 1) {
                    $adddata['starttime'] = $adddata['starttime'] + strtotime(date('Y-m-d', $_G['timestamp']));
                }
                
                if ($adddata['starttime'] > $tomorrowtime3) {
                    $text1 = date('m', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
                } else {
                    $text1 = date('m', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $adddata['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
                }
                
                $adddata['text1'] = $text1;
                $adddata['text2'] = $weekarray[date("w", $adddata['starttime'])];
                
                
                
                
                if ($islongterm == 1) {
                    $subtitle = $leixingtitle . '  ' . lang('plugin/zimucms_pinche', 'system_text21');
                } else {
                    $subtitle = $leixingtitle . '  ' . $adddata['text1'] . '(' . $adddata['text2'] . ')';
                }
                
                
                $tid_title = $subtitle . date('H:i', $adddata['starttime']) . $adddata['chufadi'] . lang('plugin/zimucms_pinche', 'system_text51') . $adddata['mudidi'] . $adddata['kongwei'] . $kongweitext . $adddata['timetext'];
                
                $tid_content = '<p>' . lang('plugin/zimucms_pinche', 'system_text56') . $leixingtitle . '</p>';
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text57') . $adddata['chufadi'] . '</p>';
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text58') . $adddata['mudidi'] . '</p>';
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text65') . $adddata['tujing'] . '</p>';
                if ($islongterm == 1) {
                    $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text59') . lang('plugin/zimucms_pinche', 'system_text21');
                } else {
                    $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text59') . $adddata['text1'] = $text1 . $adddata['text2'];
                }
                $tid_content = $tid_content . date('H:i', $pincheview['starttime']) . '</p>';
                
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text60') . $adddata['lianxi'] . '</p>';
                
                if ($IsHaveCar == 1 || $IsHaveCar == 2) {
                    
                    $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text61') . $adddata['kongwei'] . $kongweitext . '</p>';
                    
                } else {
                    
                    $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text62') . $adddata['kongwei'] . $kongweitext . '</p>';
                    
                }
                
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text63') . $adddata['beizhu'] . '</p>';
                
                $tid_content = $tid_content . '<p>' . lang('plugin/zimucms_pinche', 'system_text64') . date('Y-m-d H:i:s', $adddata['addtime']) . '</p>';
                
                $newthread = array(
                    'fid' => $topost_forum[$IsHaveCar - 1][0],
                    'typeid' => $topost_forum[$IsHaveCar - 1][1],
                    'author' => $_G['username'],
                    'authorid' => $_G['uid'],
                    'subject' => $tid_title,
                    'dateline' => TIMESTAMP,
                    'lastpost' => TIMESTAMP,
                    'lastposter' => $_G['username']
                );
                
                $tid              = C::t('forum_thread')->insert($newthread, true);
                $newsdata_content = html2bbcode($tid_content);
                $pid              = insertpost(array(
                    'fid' => $topost_forum[$IsHaveCar - 1][0],
                    'tid' => $tid,
                    'author' => $_G['username'],
                    'authorid' => $_G['uid'],
                    'subject' => $tid_title,
                    'dateline' => TIMESTAMP,
                    'message' => $newsdata_content,
                    'useip' => '127.0.0.1',
                    'first' => '1'
                ));
                if (!$ZIMUCMS_MYUSER) {
                    exit();
                }
                if (!isset($_G['cache']['forums'])) {
                    loadcache('forums');
                }
                useractionlog($_G['uid'], 'tid');
                C::t('common_member_field_home')->update($_G['uid'], array(
                    'recentnote' => $tid_title
                ));
                $lastpost = "$tid\t" . $tid_title . "\t" . TIMESTAMP . "\t$_G[username]";
                C::t('forum_forum')->update($topost_forum[$IsHaveCar - 1][0], array(
                    'lastpost' => $lastpost
                ));
                C::t('forum_forum')->update_forum_counter($topost_forum[$IsHaveCar - 1][0], 1, 1, 1);
                if ($_G['cache']['forums'][$topost_forum[$IsHaveCar - 1][0]]['type'] == 'sub') {
                    C::t('forum_forum')->update($_G['cache']['forums'][$topost_forum[$IsHaveCar - 1][0]]['fup'], array(
                        'lastpost' => $lastpost
                    ));
                }
                
                
                
            }
            
            
            $manage_uids = explode(',', $zmdata['manage_uids']);
            $zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');

                if ($islongterm == 1) {
                    $subtitle = $leixingtitle . '  ' . lang('plugin/zimucms_pinche', 'system_text21');
                } else {
                    $subtitle = $leixingtitle . '  ' . $adddata['text1'] . '(' . $adddata['text2'] . ')';
                }
                
                
                $tid_title = $subtitle . date('H:i', $adddata['starttime']) . $adddata['chufadi'] . lang('plugin/zimucms_pinche', 'system_text51') . $adddata['mudidi'] . $adddata['kongwei'] . $kongweitext . $adddata['timetext'];


            foreach ($manage_uids as $key => $val) {
                if($zmqianbao['magapp_hostname'] && $zmqianbao['magapp_secret'] && $zmqianbao['is_assistant']){
                    $magurl = $zmqianbao['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
                    $magpostdata['user_id'] = $val;
                    $magpostdata['type'] = 'remind';
                    $zmqianbao['assistant_content'] = '{"tag": "'.lang('plugin/zimucms_pinche', 'system_text76').'","title": "uid'.$_G['uid'].'","subtitle": "'.$tid_title.'","link":"'.ZIMUCMS_URL . '&model=view&pid=' . $pincheid.'","extra_info":[{"key":"'.lang('plugin/zimucms_pinche', 'system_text76').'","val":"'.$_G['username'].'"},{"key":"uid","val":"'.$_G['uid'].'"}]}';
                    $magpostdata['content'] = diconv($zmqianbao['assistant_content'],CHARSET,'utf-8');
                    $magpostdata['assistant_secret'] = $zmqianbao['assistant_secret'];
                    $magpostdata['secret'] = $zmqianbao['magapp_secret'];
                    $magpostdata['is_push'] = 1;
                    $magdata = lizimu_post2($magurl,$magpostdata);
                }
            }

            dheader('Location:' . ZIMUCMS_URL . '&model=view&pid=' . $pincheid);
        }
    } else {

        isallowadd();
        
        zm_wechat_auth('add');

        if ($_G['uid'] > 0) {
            
            
            $paylogdata = DB::fetch_first('select * from %t where uid=%d and status=%d and type=%s and ischongzhi=%d order by id desc', array(
                'zimucms_pinche_paylog',
                $_G['uid'],
                2,
                'alipay',
                1
            ));
            if ($paylogdata) {
                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_pinche_user',
                    $_G['uid']
                ));
                if ($isuser) {
                    
                    $addata2['username'] = $_G['username'];
                    $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
                    $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
                    $addata2['uptime']   = $_G['timestamp'];
                    $result              = DB::update('zimucms_pinche_user', $addata2, array(
                        'uid' => $_G['uid']
                    ));
                    
                } else {
                    $addata3 = array(
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'allmoney' => $paylogdata['zengsong'],
                        'money' => $paylogdata['zengsong'],
                        'uptime' => $_G['timestamp']
                    );
                    $result  = DB::insert('zimucms_pinche_user', $addata3);
                    
                    
                }
                
                $addata['id']         = $paylogdata['id'];
                $addata['uid']        = $_G['uid'];
                $addata['ischongzhi'] = '2';
                $result               = DB::update('zimucms_pinche_paylog', $addata, array(
                    'id' => $addata['id']
                ));
                dheader('Location:' . ZIMUCMS_URL . '&model=add');
                exit();
            }
            
            if ($zmdata['is_open_money']) {

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $mycredict = $appdata['data']['gold'];

    }else{

            $mycredict = round(DB::result_first('select money from %t where uid=%d', array(
                'zimucms_pinche_user',
                $_G['uid']
            )), 2);

    }

                
            } else {
                $mycredict = getuserprofile('extcredits' . $zmdata['jifen_type']);
            }
            
        }
        
        if ($_G['uid']) {
            $max_fabu = DB::result_first("SELECT count(*) FROM %t where status=2 and starttime>%d and useruid=%d", array(
                "zimucms_pinche",
                strtotime(date('Y-m-d', $_G['timestamp'])),
                $_G['uid']
            ));
        }
        
        
        if (IN_APP == 1) {
            $money_xiaohao = round($zmdata['money_xiaohao'] * $zmdata['app_bili'] / 100, 2);
            $jifen_xiaohao = intval($zmdata['jifen_xiaohao'] * $zmdata['app_bili'] / 100);
        } else {
            $money_xiaohao = $zmdata['money_xiaohao'];
            $jifen_xiaohao = $zmdata['jifen_xiaohao'];
        }

        $freegroups = empty($zmdata['free_group']) ? array() : unserialize($zmdata['free_group']);
        $free_nums = DB::result_first("SELECT count(*) FROM %t where useruid=%d and isfree=1 and addtime>%d", array(
            "zimucms_pinche",
            $_G['uid'],
            strtotime(date("Y-m-01", time()))
        ));
        if (in_array($_G['group']['groupid'], $freegroups) && $free_nums < $zmdata['free_group_nums']){
            $money_xiaohao = 0;
            $jifen_xiaohao = 0;
            $isfree = 0;
            $isvip = 1;
        }else{
            $isfree = 1;
            $extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
            foreach ($extgroupids as $key => $value) {
                if (in_array($value, $freegroups) && $free_nums < $zmdata['free_group_nums']){
                    $money_xiaohao = 0;
                    $jifen_xiaohao = 0;
                    $isfree = 0;
                    $isvip = 1;
                }else{
                    $isfree = 1;
                }
            }
        }
        
        $zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');
        
        if ($zmqianbao['app_appid']) {
            $mymobile = DB::result_first('select mobile from %t where uid=%d and mobile!=0 order by id desc', array(
                'appbyme_sendsms',
                $_G['uid']
            ));
        }
        if ($zmqianbao['qf_hostname']) {
            $mymobile = DB::result_first('select phone from %t where uid=%d order by dateline desc', array(
                'phonebind',
                $_G['uid']
            ));
        }
        if ($zmqianbao['magapp_hostname']) {
            $mymobile = DB::result_first('select phone from %t where userid=%d order by id desc', array(
                'user_mobile_relations',
                $_G['uid']
            ));
        }
        
        
        
        if ($zmdata['muban_change'] == 2) {
            include template('zimucms_pinche:add2');
        } else {
            include template('zimucms_pinche:add');
        }
    }
    
    
} else if ($model == 'mianze') {
    
    include template('zimucms_pinche:mianze');
    
} else if ($model == 'view') {
    $pid = intval($_GET['pid']);
    
    $todaytime     = strtotime(date('Y-m-d', $_G['timestamp']));
    $tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    $tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
    $tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
    
    $weekarray = array(
        lang('plugin/zimucms_pinche', 'system_text14'),
        lang('plugin/zimucms_pinche', 'system_text8'),
        lang('plugin/zimucms_pinche', 'system_text9'),
        lang('plugin/zimucms_pinche', 'system_text10'),
        lang('plugin/zimucms_pinche', 'system_text11'),
        lang('plugin/zimucms_pinche', 'system_text12'),
        lang('plugin/zimucms_pinche', 'system_text13')
    );
    
    $pincheview = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_pinche',
        $pid
    ));
    
    if ($pincheview['islongterm'] == 1) {
        $pincheview['starttime'] = $pincheview['starttime'] + strtotime(date('Y-m-d', $_G['timestamp']));
    }
    
    if ($pincheview['starttime'] > $tomorrowtime3) {
        $text1 = date('m', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
    } else if ($pincheview['starttime'] > $tomorrowtime2) {
        $text1 = lang('plugin/zimucms_pinche', 'system_text5');
    } else if ($pincheview['starttime'] > $tomorrowtime1) {
        $text1 = lang('plugin/zimucms_pinche', 'system_text4');
    } else if ($pincheview['starttime'] > $todaytime) {
        $text1 = lang('plugin/zimucms_pinche', 'system_text3');
    } else {
        $text1 = date('m', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $pincheview['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
    }
    
    $pincheview['text1'] = $text1;
    $pincheview['text2'] = $weekarray[date("w", $pincheview['starttime'])];
    
    
    $share_title = $zmdata['view_share_title'];
    if ($pincheview['leixing'] == 1) {
        $share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text7'), $share_title);
        $share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text52'), $share_title);
    } elseif ($pincheview['leixing'] == 2) {
        $share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text8'), $share_title);
        $share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text53'), $share_title);
    } elseif ($pincheview['leixing'] == 3) {
        $share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text39'), $share_title);
        $share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text54'), $share_title);
    } elseif ($pincheview['leixing'] == 4) {
        $share_title = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text40'), $share_title);
        $share_title = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text55'), $share_title);
    }
    $share_title = str_replace('#chufadi#', $pincheview['chufadi'], $share_title);
    $share_title = str_replace('#mudidi#', $pincheview['mudidi'], $share_title);
    $share_title = str_replace('#tujing#', $pincheview['tujing'], $share_title);
    if ($pincheview['islongterm'] == 1) {
        $share_title = str_replace('#starttime#', lang('plugin/zimucms_pinche', 'xcx_tpl_text48') . date('H:i', $pincheview['starttime']), $share_title);
    } else {
        $share_title = str_replace('#starttime#', $pincheview['text1'] . '(' . $pincheview['text2'] . ')', $share_title);
    }
    if (!$ZIMUCMS_MYUSER) {
        exit();
    }
    $share_title = str_replace('#timetext#', $pincheview['timetext'], $share_title);
    $share_title = str_replace('#lianxi#', $pincheview['lianxi'], $share_title);
    $share_title = str_replace('#beizhu#', $pincheview['beizhu'], $share_title);
    
    
    
    $share_desc = $zmdata['view_share_desc'];
    if ($pincheview['leixing'] == 1) {
        $share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text7'), $share_desc);
        $share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text52'), $share_desc);
    } elseif ($pincheview['leixing'] == 2) {
        $share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_add_text8'), $share_desc);
        $share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text53'), $share_desc);
    } elseif ($pincheview['leixing'] == 3) {
        $share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text39'), $share_desc);
        $share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text54'), $share_desc);
    } elseif ($pincheview['leixing'] == 4) {
        $share_desc = str_replace('#leixing#', lang('plugin/zimucms_pinche', 'xcx_tpl_text40'), $share_desc);
        $share_desc = str_replace('#kongwei#', $pincheview['kongwei'] . lang('plugin/zimucms_pinche', 'system_text55'), $share_desc);
    }
    $share_desc = str_replace('#chufadi#', $pincheview['chufadi'], $share_desc);
    $share_desc = str_replace('#mudidi#', $pincheview['mudidi'], $share_desc);
    $share_desc = str_replace('#tujing#', $pincheview['tujing'], $share_desc);
    if ($pincheview['islongterm'] == 1) {
        $share_desc = str_replace('#starttime#', lang('plugin/zimucms_pinche', 'xcx_tpl_text48') . date('H:i', $pincheview['starttime']), $share_desc);
    } else {
        $share_desc = str_replace('#starttime#', $pincheview['text1'] . '(' . $pincheview['text2'] . ')', $share_desc);
    }
    $share_desc = str_replace('#timetext#', $pincheview['timetext'], $share_desc);
    $share_desc = str_replace('#lianxi#', $pincheview['lianxi'], $share_desc);
    $share_desc = str_replace('#beizhu#', $pincheview['beizhu'], $share_desc);
    
    
    if ($zmdata['muban_change'] == 2) {
        
        if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_ad.php")) {
            $addata = zimu_readfromcache('table_plugin_zimucms_pinche_ad');
        } else {
            $addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array(
                'zimucms_pinche_ad'
            ));
            zimu_writetocache('table_plugin_zimucms_pinche_ad', $addata);
        }
        
        if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_allviews.php")) {
            $allviews           = zimu_readfromcache('table_plugin_zimucms_pinche_allviews');
            $addata['allviews'] = $allviews['allviews'] + 1;
            zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
        } else {
            $addata['allviews'] = 0;
            zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
        }
        
        if ($zmdata['is_open_money']) {
            $zhiding_type = explode("\r\n", trim($zmdata['money_type']));
            foreach ($zhiding_type as $key => $v) {
                $v             = str_replace('<option value="', '', $v);
                $v             = str_replace('" zhidingtime="', '=', $v);
                $v             = str_replace('">', '=', $v);
                $v             = str_replace('</option>', '', $v);
                $TopInfo[$key] = explode('=', $v);
            }
            foreach ($TopInfo as $key => $value) {
                $TopInfo2[$key]['money']       = $value[0];
                $TopInfo2[$key]['zhidingtime'] = $value[1];
                $TopInfo2[$key]['text']        = $value[2];
                $TopInfo2_text[]               = $value[2];
            }
        } else {
            $zhiding_type = explode("\r\n", trim($zmdata['zhiding_type']));
            foreach ($zhiding_type as $key => $v) {
                $v             = str_replace('<option value="', '', $v);
                $v             = str_replace('" zhidingtime="', '=', $v);
                $v             = str_replace('">', '=', $v);
                $v             = str_replace('</option>', '', $v);
                $TopInfo[$key] = explode('=', $v);
            }
            foreach ($TopInfo as $key => $value) {
                $TopInfo2[$key]['money']       = $value[0];
                $TopInfo2[$key]['zhidingtime'] = $value[1];
                $TopInfo2[$key]['text']        = $value[2];
                $TopInfo2_text[]               = $value[2];
            }
        }
        
        include template('zimucms_pinche:view2');
    } else {
        include template('zimucms_pinche:view');
    }
} else if ($model == 'userindex') {
    
    isallowadd();
    if ($_G['uid'] > 0) {
        
        $paylogdata = DB::fetch_first('select * from %t where uid=%d and status=%d and type=%s and ischongzhi=%d order by id desc', array(
            'zimucms_pinche_paylog',
            $_G['uid'],
            2,
            'alipay',
            1
        ));
        if ($paylogdata) {
            $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                'zimucms_pinche_user',
                $_G['uid']
            ));
            if ($isuser) {
                
                $addata2['username'] = $_G['username'];
                $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
                $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
                $addata2['uptime']   = $_G['timestamp'];
                $result              = DB::update('zimucms_pinche_user', $addata2, array(
                    'uid' => $_G['uid']
                ));
                
            } else {
                $addata3 = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'allmoney' => $paylogdata['zengsong'],
                    'money' => $paylogdata['zengsong'],
                    'uptime' => $_G['timestamp']
                );
                $result  = DB::insert('zimucms_pinche_user', $addata3);
                
                
            }
            if (!$ZIMUCMS_MYUSER) {
                exit();
            }
            $addata['id']         = $paylogdata['id'];
            $addata['uid']        = $_G['uid'];
            $addata['ischongzhi'] = '2';
            $result               = DB::update('zimucms_pinche_paylog', $addata, array(
                'id' => $addata['id']
            ));
            dheader('Location:' . ZIMUCMS_URL . '&model=userindex');
            exit();
        }
        
        
        if ($zmdata['is_open_money']) {
            

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $mycredict = $appdata['data']['gold'];

    }else{

            $mycredict = round(DB::result_first('select money from %t where uid=%d', array(
                'zimucms_pinche_user',
                $_G['uid']
            )), 2);

    }
            
            
            
            $zhiding_type = explode("\r\n", trim($zmdata['money_type']));
            foreach ($zhiding_type as $key => $v) {
                
                $v = str_replace('<option value="', '', $v);
                $v = str_replace('" zhidingtime="', '=', $v);
                $v = str_replace('">', '=', $v);
                $v = str_replace('</option>', '', $v);
                
                $TopInfo[$key] = explode('=', $v);
                
            }
            
            foreach ($TopInfo as $key => $value) {
                $TopInfo2[$key]['money']       = $value[0];
                $TopInfo2[$key]['zhidingtime'] = $value[1];
                $TopInfo2[$key]['text']        = $value[2];
                $TopInfo2_text[]               = $value[2];
            }
            
            
        } else {
            $mycredict = getuserprofile('extcredits' . $zmdata['jifen_type']);
        }
    }
    
    $out_trade_no = strip_tags($_GET['qfid']);
    
    
    if ($out_trade_no) {
        
        $isfinished = DB::fetch_first('select * from %t where uid=%d and type=%s and out_trade_no=%s', array(
            'zimucms_pinche_paylog',
            $_G['uid'],
            'wxapppay',
            $out_trade_no
        ));
        
        if ($paylogdata['status'] == 1) {
            
            $zmqianbao = zimu_readfromcache_qf2('setting_plugin_zimucms_pinche_qianbao');
            
            if (!$zmqianbao['qf_type']) {
                $zmqianbao['qf_type'] = 10000;
            }
            
            $nonce  = qf_nonce2();
            $secret = $zmqianbao['qf_secret'];
            
            $data = array(
                'order_id' => $out_trade_no,
                'nonce' => $nonce
            );
            
            $data['sign'] = qf_sign2($data, $secret);
            $r            = http_build_query($data);
            
            $qfurl  = $zmqianbao['qf_hostname'] . '/api1_2/orders/query?' . $r;
            $qfdata = dfsockopen($qfurl);
            if (!$qfdata) {
                $qfdata = file_get_contents($qfurl);
            }
            
            if ($retqf = json_decode($qfdata, true)) {
                if ($retqf['data'][$out_trade_no]['result'] == 1 || $retqf['data'][$out_trade_no]['result'] == 2) {
                    
                    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
                        'zimucms_pinche_paylog',
                        $out_trade_no
                    ));
                    
                    if ($paylogdata['status'] == 1) {
                        
                        $addata['status'] = '2';
                        DB::update('zimucms_pinche_paylog', $addata, array(
                            'out_trade_no' => $out_trade_no
                        ));
                        
                        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                            'zimucms_pinche_user',
                            $_G['uid']
                        ));
                        
                        if ($isuser) {
                            
                            $addata2['username'] = $_G['username'];
                            $addata2['allmoney'] = $isuser['allmoney'] + $paylogdata['zengsong'];
                            $addata2['money']    = $isuser['money'] + $paylogdata['zengsong'];
                            $addata2['uptime']   = $_G['timestamp'];
                            $result              = DB::update('zimucms_pinche_user', $addata2, array(
                                'uid' => $_G['uid']
                            ));
                            
                        } else {
                            
                            
                            $addata3 = array(
                                'uid' => $_G['uid'],
                                'username' => $_G['username'],
                                'allmoney' => $paylogdata['zengsong'],
                                'money' => $paylogdata['zengsong'],
                                'uptime' => $_G['timestamp']
                            );
                            $result  = DB::insert('zimucms_pinche_user', $addata3);
                            
                            
                        }
                        
                    }
                    
                    
                }
            }
        }
    }
    
    $pinchedata = DB::fetch_all('select * from %t where status=2 and useruid=%d order by id desc limit 100', array(
        'zimucms_pinche',
        $_G['uid']
    ));
    
    
    
    
    include template('zimucms_pinche:userindex2');
    
} else if ($model == 'soso') {
    
    $todaytime     = strtotime(date('Y-m-d', $_G['timestamp']));
    $tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    $tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
    $tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
    if (!$ZIMUCMS_MYUSER) {
        exit();
    }
    //$olddaytime = strtotime(date('Y-m-d', $_G['timestamp'])) - 86400 * $zmdata['old_days'];
    $olddaytime = 0;
    
    $weekarray = array(
        lang('plugin/zimucms_pinche', 'system_text14'),
        lang('plugin/zimucms_pinche', 'system_text8'),
        lang('plugin/zimucms_pinche', 'system_text9'),
        lang('plugin/zimucms_pinche', 'system_text10'),
        lang('plugin/zimucms_pinche', 'system_text11'),
        lang('plugin/zimucms_pinche', 'system_text12'),
        lang('plugin/zimucms_pinche', 'system_text13')
    );
    
    $type = intval($_GET['type']);
    
    if ($type) {
        $wheresql = 'and leixing=' . $type . ' and starttime > ' . $olddaytime;
    } else {
        $wheresql = 'and starttime > ' . $olddaytime;
    }
    $fromPlace = strip_tags(zm_diconv($_GET['fromPlace']));
    $toPlace   = strip_tags(zm_diconv($_GET['toPlace']));
    
    $fromPlace = str_replace("%", "", $fromPlace);
    $fromPlace = str_replace("_", "", $fromPlace);
    $toPlace   = str_replace("%", "", $toPlace);
    $toPlace   = str_replace("_", "", $toPlace);
    
    $pinchedata = DB::fetch_all('select * from %t where status=2 ' . $wheresql . ' and chufadi like %s and ( mudidi like %s or tujing like %s ) order by sort asc,starttime desc limit 100', array(
        'zimucms_pinche',
        '%' . $fromPlace . '%',
        '%' . $toPlace . '%',
        '%' . $toPlace . '%'
    ));

    foreach ($pinchedata as $key => $value) {
        if ($value['islongterm'] == 1) {
            $pinchedata[$key]['starttime'] = $value['starttime'] + strtotime(date('Y-m-d', $_G['timestamp']));
        }
        if ($value['starttime'] > $tomorrowtime3) {
            $text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
        } else if ($value['starttime'] > $tomorrowtime2) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text5');
        } else if ($value['starttime'] > $tomorrowtime1) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text4');
        } else if ($value['starttime'] > $todaytime) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text3');
        } else {
            $text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
        }
        $pinchedata[$key]['text1'] = $text1;
        $pinchedata[$key]['text2'] = $weekarray[date("w", $value['starttime'])];
    }

    
    if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_ad.php")) {
        $addata = zimu_readfromcache('table_plugin_zimucms_pinche_ad');
    } else {
        $addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array(
            'zimucms_pinche_ad'
        ));
        zimu_writetocache('table_plugin_zimucms_pinche_ad', $addata);
    }
    
    if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_allviews.php")) {
        $allviews           = zimu_readfromcache('table_plugin_zimucms_pinche_allviews');
        $addata['allviews'] = $allviews['allviews'] + 1;
        zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
    } else {
        $addata['allviews'] = 0;
        zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
    }
    
    include template('zimucms_pinche:newindex2');
    
} else if ($model == 'delpid' && $_GET['md5formhash'] == formhash()) {
    
    $pid = intval($_GET['pid']);
    
    $result = DB::delete('zimucms_pinche', array(
        'id' => $pid
    ));
    
    if ($result) {
        
        $out['status'] = 200;
        echo $result = json_encode($out);
        exit();
        
    } else {
        
        $out['status'] = 202;
        echo $result = json_encode($out);
        exit();
        
    }
    
} else if ($model == 'topay') {
    
    zm_wechat_auth();
    
    
    $zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');
    
    if (!$zmqianbao['qf_type']) {
        $zmqianbao['qf_type'] = 10000;
    }
    
    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $mycredict = $appdata['data']['gold'];

    }else{

    $mycredict = round(DB::result_first('select money from %t where uid=%d', array(
        'zimucms_pinche_user',
        $_G['uid']
    )), 2);

    }
    
    if (!$ZIMUCMS_MYUSER) {
        exit();
    }
    $ii = 0;
    foreach (explode("\n", $zmdata['money_chongzhi']) as $value) {
        list($key, $val, $text) = explode('=', $value);
        $money_chongzhi[$ii]['money'] = $key;
        $money_chongzhi[$ii]['nums']  = $val;
        $money_chongzhi[$ii]['text']  = $text;
        $ii++;
    }
    
    $money_chongzhi2 = $money_chongzhi;
    include template('zimucms_pinche:topay');
    
} else if ($model == 'ajaxzhiding' && $_GET['md5formhash'] == formhash()) {
    
    isallowadd();
    
    $pid = intval($_GET['pid']);
    $mid = intval($_GET['mid']);
    
    
    if ($zmdata['is_open_money']) {
        $zhiding_type = explode("\r\n", trim($zmdata['money_type']));
        foreach ($zhiding_type as $key => $v) {
            
            $v = str_replace('<option value="', '', $v);
            $v = str_replace('" zhidingtime="', '=', $v);
            $v = str_replace('">', '=', $v);
            $v = str_replace('</option>', '', $v);
            
            $TopInfo[$key] = explode('=', $v);
            
        }
        
        foreach ($TopInfo as $key => $value) {
            $TopInfo2[$key]['money']       = $value[0];
            $TopInfo2[$key]['zhidingtime'] = $value[1];
            $TopInfo2[$key]['text']        = $value[2];
            $TopInfo2_text[]               = $value[2];
        }
    } else {
        $zhiding_type = explode("\r\n", trim($zmdata['zhiding_type']));
        foreach ($zhiding_type as $key => $v) {
            $v             = str_replace('<option value="', '', $v);
            $v             = str_replace('" zhidingtime="', '=', $v);
            $v             = str_replace('">', '=', $v);
            $v             = str_replace('</option>', '', $v);
            $TopInfo[$key] = explode('=', $v);
        }
        foreach ($TopInfo as $key => $value) {
            $TopInfo2[$key]['money']       = $value[0];
            $TopInfo2[$key]['zhidingtime'] = $value[1];
            $TopInfo2[$key]['text']        = $value[2];
            $TopInfo2_text[]               = $value[2];
        }
    }
    
    
    
    if ($zmdata['is_open_money']) {

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

        require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/qfapp.class.php';
        $client = new QF_HTTP_CLIENT($zmdata['qf_hostname1'],$zmdata['qf_token1']);
        $appdata = $client->get('wallets/'.$_G['uid']);
        $mycredict = $appdata['data']['gold'];

    }else{

            $mycredict = round(DB::result_first('select money from %t where uid=%d', array(
                'zimucms_pinche_user',
                $_G['uid']
            )), 2);

    }

    } else {
        $mycredict = getuserprofile('extcredits' . $zmdata['jifen_type']);
    }
    
    $TopInfo_xiaohao = round($TopInfo2[$mid]['money'], 2);
    
    if (IN_APP == 1) {
        
        $TopInfo_xiaohao = round($TopInfo_xiaohao * $zmdata['app_bili2'] / 100, 2);
        
    }
    
    if ($mycredict - $TopInfo_xiaohao < 0) {
        
        die(json_encode(array(
            'error' => $zmdata['is_open_money'] ? zimu_array_utf8(lang('plugin/zimucms_pinche', 'system_text72')) : zimu_array_utf8(lang('plugin/zimucms_pinche', 'system_text73')),
            'timestamp' => $_G['timestamp']
        )));
        
    }
    
    DB::query("update %t set zhidingendtime=%d where id=%d", array(
        'zimucms_pinche',
        $_G['timestamp'] + $TopInfo2[$mid]['zhidingtime'] * 60,
        $pid
    ));
    
    if ($zmdata['is_open_money']) {

    if($zmdata['qf_jifen'] > 0 && $zmdata['qf_type']){

    $qf_jifen = 0 - $TopInfo_xiaohao;
    $appdata2 = $client->put('wallets/'.$_G['uid'], ['type' => $zmdata['qf_type'],'gold' => $qf_jifen,'reason' => 'pinche']);

    }else{
        DB::query("update %t set money=money-" . $TopInfo_xiaohao . " where uid=%d", array(
            'zimucms_pinche_user',
            $_G['uid']
        ));
    }

    } else {
        $TopInfo_xiaohao = intval($TopInfo_xiaohao);
        updatemembercount($_G['uid'], array(
            'extcredits' . $zmdata['jifen_type'] => '-' . $TopInfo_xiaohao
        ), true, 'CEC', 1, 'zmpinche');
    }
    
    die(json_encode(array(
        'error' => 'ok',
        'timestamp' => $_G['timestamp']
    )));
    
} else if ($model == 'ajaxzhiding2' && $_GET['md5formhash'] == formhash()) {
    
    isallowadd();
    
$manage_uids = explode(',', $zmdata['manage_uids']);
if(!in_array($_G['uid'],$manage_uids)){
        die(json_encode(array(
            'error' => 'uid error',
            'timestamp' => $_G['timestamp']
        )));

}

    $pid = intval($_GET['pid']);
    $mid = intval($_GET['mid']);
    
    
    if ($zmdata['is_open_money']) {
        $zhiding_type = explode("\r\n", trim($zmdata['money_type']));
        foreach ($zhiding_type as $key => $v) {
            
            $v = str_replace('<option value="', '', $v);
            $v = str_replace('" zhidingtime="', '=', $v);
            $v = str_replace('">', '=', $v);
            $v = str_replace('</option>', '', $v);
            
            $TopInfo[$key] = explode('=', $v);
            
        }
        
        foreach ($TopInfo as $key => $value) {
            $TopInfo2[$key]['money']       = $value[0];
            $TopInfo2[$key]['zhidingtime'] = $value[1];
            $TopInfo2[$key]['text']        = $value[2];
            $TopInfo2_text[]               = $value[2];
        }
    } else {
        $zhiding_type = explode("\r\n", trim($zmdata['zhiding_type']));
        foreach ($zhiding_type as $key => $v) {
            $v             = str_replace('<option value="', '', $v);
            $v             = str_replace('" zhidingtime="', '=', $v);
            $v             = str_replace('">', '=', $v);
            $v             = str_replace('</option>', '', $v);
            $TopInfo[$key] = explode('=', $v);
        }
        foreach ($TopInfo as $key => $value) {
            $TopInfo2[$key]['money']       = $value[0];
            $TopInfo2[$key]['zhidingtime'] = $value[1];
            $TopInfo2[$key]['text']        = $value[2];
            $TopInfo2_text[]               = $value[2];
        }
    }
    
    DB::query("update %t set zhidingendtime=%d where id=%d", array(
        'zimucms_pinche',
        $_G['timestamp'] + $TopInfo2[$mid]['zhidingtime'] * 60,
        $pid
    ));
    
    die(json_encode(array(
        'error' => 'ok',
        'timestamp' => $_G['timestamp']
    )));  
      
    
} else {
    
    $todaytime     = strtotime(date('Y-m-d', $_G['timestamp']));
    $tomorrowtime1 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400;
    $tomorrowtime2 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400;
    $tomorrowtime3 = strtotime(date('Y-m-d', $_G['timestamp'])) + 86400 + 86400 + 86400;
    if (!$ZIMUCMS_MYUSER) {
        exit();
    }
    $olddaytime = strtotime(date('Y-m-d', $_G['timestamp'])) - 86400 * $zmdata['old_days'];
    $desc = intval($_GET['desc']);
    if(!$desc){
        $desc = $zmdata['order_desc'];
    }
    if($desc == 2){
        $whereorder = ' addtime desc,';
    }
    
    $weekarray = array(
        lang('plugin/zimucms_pinche', 'system_text14'),
        lang('plugin/zimucms_pinche', 'system_text8'),
        lang('plugin/zimucms_pinche', 'system_text9'),
        lang('plugin/zimucms_pinche', 'system_text10'),
        lang('plugin/zimucms_pinche', 'system_text11'),
        lang('plugin/zimucms_pinche', 'system_text12'),
        lang('plugin/zimucms_pinche', 'system_text13')
    );
    
    $type = intval($_GET['type']);
    
    if ($type) {
        $wheresql = 'and leixing=' . $type;
    }
    
    
    $zhiding_pinchedata = DB::fetch_all('select * from %t where zhidingendtime>%d and status=2 ' . $wheresql . ' order by '.$whereorder.'zhidingendtime asc,starttime asc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp']
    ));
    
    foreach ($zhiding_pinchedata as $key => $value) {
        if ($zhiding_pinchedata[$key]['islongterm'] == 1) {
            $zhiding_pinchedata[$key]['starttime'] = $zhiding_pinchedata[$key]['starttime'] + $todaytime;
        }
    }

    if($desc == 1){
        $zhiding_pinchedata = array_sort($zhiding_pinchedata, 'starttime', 'asc');
    }

    if (!$zhiding_pinchedata) {
        $zhiding_pinchedata = array();
    }
    
    $now_pinchedata1 = DB::fetch_all('select * from %t where starttime>%d and zhidingendtime<%d and status=2 and islongterm=0 ' . $wheresql . ' order by sort asc,'.$whereorder.'starttime asc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp'],
        $_G['timestamp']
    ));
    
    $now_pinchedata2 = DB::fetch_all('select * from %t where starttime>%d and zhidingendtime<%d and longend >= %d and status=2 and islongterm=1 ' . $wheresql . ' order by sort asc,'.$whereorder.'starttime asc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp'] - $todaytime,
        $_G['timestamp'],
        $todaytime
    ));
    
    $now_pinchedata3 = DB::fetch_all('select * from %t where starttime<=%d and zhidingendtime<%d and longend >= %d and status=2 and islongterm=1 ' . $wheresql . ' order by sort asc,'.$whereorder.'starttime asc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp'] - $todaytime,
        $_G['timestamp'],
        $todaytime
    ));
    
    foreach ($now_pinchedata2 as $key => $value) {
        $now_pinchedata2[$key]['starttime'] = $now_pinchedata2[$key]['starttime'] + $todaytime;
    }
    
    foreach ($now_pinchedata3 as $key => $value) {
        $now_pinchedata3[$key]['starttime'] = $now_pinchedata3[$key]['starttime'] + $todaytime;
    }
    
    if (!$now_pinchedata1) {
        $now_pinchedata1 = array();
    }
    
    if (!$now_pinchedata2) {
        $now_pinchedata2 = array();
    }
    
    if (!$now_pinchedata3) {
        $now_pinchedata3 = array();
    }

    $now_pinchedata4 = array_merge($now_pinchedata1, $now_pinchedata2);
    
    if($desc==1){
        $now_pinchedata4 = array_sort($now_pinchedata4, 'starttime', 'asc');
    }
    
    if (!$now_pinchedata4) {
        $now_pinchedata4 = array();
    }
    
    $now_pinchedata = array_merge($now_pinchedata4, $now_pinchedata3);

    if (!$now_pinchedata) {
        $now_pinchedata = array();
    }
    
    $oldpinchedata1 = DB::fetch_all('select * from %t where status=2 and starttime < %d and starttime >%d ' . $wheresql . ' order by '.$whereorder.'starttime desc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp'],
        $olddaytime
    ));
    
    $oldpinchedata2 = DB::fetch_all('select * from %t where status=2 and longend < %d and longend >%d and islongterm=1 ' . $wheresql . ' order by '.$whereorder.'starttime desc limit 300', array(
        'zimucms_pinche',
        $_G['timestamp'],
        $olddaytime
    ));
    
    if (!$oldpinchedata1) {
        $oldpinchedata1 = array();
    }
    
    if (!$oldpinchedata2) {
        $oldpinchedata2 = array();
    }
    
    $oldpinchedata = array_merge($oldpinchedata1, $oldpinchedata2);
    
    $pinchedata = array_merge($zhiding_pinchedata, $now_pinchedata, $oldpinchedata);
    
    foreach ($pinchedata as $key => $value) {
        
        if ($value['starttime'] > $tomorrowtime3) {
            $text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
        } else if ($value['starttime'] > $tomorrowtime2) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text5');
        } else if ($value['starttime'] > $tomorrowtime1) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text4');
        } else if ($value['starttime'] > $todaytime) {
            $text1 = lang('plugin/zimucms_pinche', 'system_text3');
        } else {
            $text1 = date('m', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text6') . date('d', $value['starttime']) . lang('plugin/zimucms_pinche', 'system_text7');
        }
        $pinchedata[$key]['text1'] = $text1;
        $pinchedata[$key]['text2'] = $weekarray[date("w", $value['starttime'])];
    }


    if ($zmdata['muban_change'] == 2) {
        
        if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_ad.php")) {
            $addata = zimu_readfromcache('table_plugin_zimucms_pinche_ad');
        } else {
            $addata = DB::fetch_all('select * from %t order by sort asc,id desc limit 50', array(
                'zimucms_pinche_ad'
            ));
            zimu_writetocache('table_plugin_zimucms_pinche_ad', $addata);
        }
        
        if (file_exists(DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_allviews.php")) {
            $allviews           = zimu_readfromcache('table_plugin_zimucms_pinche_allviews');
            $addata['allviews'] = $allviews['allviews'] + 1;
            zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
        } else {
            $addata['allviews'] = 0;
            zimu_writetocache('table_plugin_zimucms_pinche_allviews', $addata);
        }
        

        $hot_line = explode("\r\n", trim($zmdata['hot_line']));
        foreach ($hot_line as $key => $v) {
            $new_hot_line[$key] = explode('-', $v);  
        }


        if ($zmdata['is_open_money']) {
            $zhiding_type = explode("\r\n", trim($zmdata['money_type']));
            foreach ($zhiding_type as $key => $v) {
                $v             = str_replace('<option value="', '', $v);
                $v             = str_replace('" zhidingtime="', '=', $v);
                $v             = str_replace('">', '=', $v);
                $v             = str_replace('</option>', '', $v);
                $TopInfo[$key] = explode('=', $v);
            }
            foreach ($TopInfo as $key => $value) {
                $TopInfo2[$key]['money']       = $value[0];
                $TopInfo2[$key]['zhidingtime'] = $value[1];
                $TopInfo2[$key]['text']        = $value[2];
                $TopInfo2_text[]               = $value[2];
            }
        } else {
            $zhiding_type = explode("\r\n", trim($zmdata['zhiding_type']));
            foreach ($zhiding_type as $key => $v) {
                $v             = str_replace('<option value="', '', $v);
                $v             = str_replace('" zhidingtime="', '=', $v);
                $v             = str_replace('">', '=', $v);
                $v             = str_replace('</option>', '', $v);
                $TopInfo[$key] = explode('=', $v);
            }
            foreach ($TopInfo as $key => $value) {
                $TopInfo2[$key]['money']       = $value[0];
                $TopInfo2[$key]['zhidingtime'] = $value[1];
                $TopInfo2[$key]['text']        = $value[2];
                $TopInfo2_text[]               = $value[2];
            }
        }


        include template('zimucms_pinche:newindex2');
    } else {
        include template('zimucms_pinche:newindex');
    }
    
    
    
}