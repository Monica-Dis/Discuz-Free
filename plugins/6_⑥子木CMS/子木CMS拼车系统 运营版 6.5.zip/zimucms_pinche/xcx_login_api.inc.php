<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';
$login_code = addslashes($_GET['login_code']);
$encryptedData = addslashes($_GET['encryptedData']);
$signature = addslashes($_GET['signature']);
$iv = addslashes($_GET['iv']);
$nickName = addslashes($_GET['nickName']);
$gender = intval($_GET['gender']);
$avatarUrl = addslashes($_GET['avatarUrl']);
$xcxurl = 'https://api.weixin.qq.com/sns/jscode2session?appid=' . $zmdata['xcx_appid'] . '&secret=' . $zmdata['xcx_appsecret'] . '&js_code=' . $login_code . '&grant_type=authorization_code';
$xcxdata = dfsockopen($xcxurl);
if (!$xcxdata) {
	$xcxdata = file_get_contents($xcxurl);
}
$xcxdata2 = json_decode($xcxdata, true);
if ($xcxdata2['unionid']) {
	$xcx_zimu_data['username'] = $nickName;
	$xcx_zimu_data['username2'] = diconv($nickName, 'UTF-8', CHARSET);
	$xcx_zimu_data['gender'] = $gender;
	$xcx_zimu_data['avatar'] = $avatarUrl;
	$xcx_zimu_data['openid'] = $xcxdata2['openid'];
	$xcx_zimu_data['unionid'] = $xcxdata2['unionid'];
	$xcx_zimu_data['xcx_appid'] = $zmdata['xcx_appid'];
} else {
	require_once DISCUZ_ROOT . 'source/plugin/zimucms_pinche/class/wxBizDataCrypt.php';
	$appid = $zmdata['xcx_appid'];
	$sessionKey = $xcxdata2['session_key'];
	$pc = new WXBizDataCrypt($appid, $sessionKey);
	$errCode = $pc->decryptData($encryptedData, $iv, $data);
	$xcxdata3 = json_decode($data, true);
	$xcx_zimu_data['username'] = $xcxdata3['nickName'];
	$xcx_zimu_data['username2'] = diconv($xcxdata3['nickName'], 'UTF-8', CHARSET);
	$xcx_zimu_data['gender'] = $xcxdata3['gender'];
	$xcx_zimu_data['avatar'] = $xcxdata3['avatarUrl'];
	$xcx_zimu_data['openid'] = $xcxdata3['openId'];
	$xcx_zimu_data['unionid'] = $xcxdata3['unionId'];
	$xcx_zimu_data['xcx_appid'] = $zmdata['xcx_appid'];
}
$isuid = xcx_select_uid($xcx_zimu_data);
if ($isuid['uid'] > 0) {
	bind_login($isuid['uid']);
	$userinfo = array('uid' => $_G['uid'], 'username' => $_G['username'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => $isuid['token']);
	$zmdata['weixin_appid'] = 'weixin_appid';
	$zmdata['weixin_appsecret'] = 'weixin_appsecret';
	$zmdata['xcx_appid'] = 'xcx_appid';
	$zmdata['xcx_appsecret'] = 'xcx_appsecret';
	exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'userinfo' => zimu_array_utf8($userinfo), 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
} else {
	if ($xcx_zimu_data['unionid'] && $zmdata['xcx_data_table'] && $zmdata['xcx_data_union'] && $zmdata['xcx_data_uid']) {
		$isuid_array = DB::fetch_first('select * from %t where ' . $zmdata[xcx_data_union] . '=%s order by id desc', array($zmdata['xcx_data_table'], $xcx_zimu_data['unionid']));
		if ($isuid_array[$zmdata['xcx_data_uid']] > 0) {
			$istoken = array('uid' => $isuid_array[$zmdata['xcx_data_uid']], 'username' => $xcx_zimu_data['username2'], 'gender' => $xcx_zimu_data['gender'], 'avatar' => $xcx_zimu_data['avatar'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => getRandChar(64), 'xcx_appid' => $xcx_zimu_data['xcx_appid'], 'uptime' => $_G['timestamp']);
			DB::insert('zimu_xcx_accesstoken', $istoken);
			bind_login($isuid_array[$zmdata['xcx_data_uid']]);
			$userinfo = array('uid' => $_G['uid'], 'username' => $_G['username'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => $istoken['token']);
			$zmdata['weixin_appid'] = 'weixin_appid';
			$zmdata['weixin_appsecret'] = 'weixin_appsecret';
			$zmdata['xcx_appid'] = 'xcx_appid';
			$zmdata['xcx_appsecret'] = 'xcx_appsecret';
			exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'userinfo' => zimu_array_utf8($userinfo), 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
		} else {
			$reguid = xcx_reg_user($xcx_zimu_data);
			$istoken = array('uid' => $reguid, 'username' => $xcx_zimu_data['username2'], 'gender' => $xcx_zimu_data['gender'], 'avatar' => $xcx_zimu_data['avatar'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => getRandChar(64), 'xcx_appid' => $xcx_zimu_data['xcx_appid'], 'uptime' => $_G['timestamp']);
			DB::insert('zimu_xcx_accesstoken', $istoken);
			bind_login($reguid);
			$userinfo = array('uid' => $_G['uid'], 'username' => $_G['username'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => $istoken['token']);
			$zmdata['weixin_appid'] = 'weixin_appid';
			$zmdata['weixin_appsecret'] = 'weixin_appsecret';
			$zmdata['xcx_appid'] = 'xcx_appid';
			$zmdata['xcx_appsecret'] = 'xcx_appsecret';
			exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'userinfo' => zimu_array_utf8($userinfo), 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
		}
	} else {
		$reguid = xcx_reg_user($xcx_zimu_data);
		$istoken = array('uid' => $reguid, 'username' => $xcx_zimu_data['username2'], 'gender' => $xcx_zimu_data['gender'], 'avatar' => $xcx_zimu_data['avatar'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => getRandChar(64), 'xcx_appid' => $xcx_zimu_data['xcx_appid'], 'uptime' => $_G['timestamp']);
		DB::insert('zimu_xcx_accesstoken', $istoken);
		bind_login($isuid_array[$zmdata['xcx_data_uid']]);
		$userinfo = array('uid' => $_G['uid'], 'username' => $_G['username'], 'openid' => $xcx_zimu_data['openid'], 'unionid' => $xcx_zimu_data['unionid'], 'token' => $istoken['token']);
		$zmdata['weixin_appid'] = 'weixin_appid';
		$zmdata['weixin_appsecret'] = 'weixin_appsecret';
		$zmdata['xcx_appid'] = 'xcx_appid';
		$zmdata['xcx_appsecret'] = 'xcx_appsecret';
		exit(json_encode(array('zmdata' => zimu_array_utf8($zmdata), 'userinfo' => zimu_array_utf8($userinfo), 'apiurl' => $zmdata['xcx_apiurl'], 'timestamp' => $_G['timestamp'])));
	}
}