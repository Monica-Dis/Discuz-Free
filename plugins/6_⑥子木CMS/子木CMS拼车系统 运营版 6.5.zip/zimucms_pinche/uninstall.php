<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimucms_pinche;
DROP TABLE  IF EXISTS pre_zimucms_pinche_ad;
DROP TABLE  IF EXISTS pre_zimucms_pinche_paylog;
DROP TABLE  IF EXISTS pre_zimucms_pinche_user;
DROP TABLE  IF EXISTS pre_zimucms_pinche_userlog;
EOF;

runquery($sql);

$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_ad.php";
@unlink($cache_file);
$cache_file = DISCUZ_ROOT . "./data/sysdata/table_plugin_zimucms_pinche_allviews.php";
@unlink($cache_file);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_pinche/uploadzimucms");


$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}