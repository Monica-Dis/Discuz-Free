<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


global $_G;

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';

if(file_exists(DISCUZ_ROOT . "./source/plugin/zimucms_qianbao/config.php")){
$zmqianbao2 = zimu_readfromcache('setting_plugin_zimucms_qianbao');
}
$zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');

if(!$zmqianbao['app_appid']){
$zmqianbao['app_appid'] = $zmqianbao2['app_appid'];
}
if(!$zmqianbao['app_appsecret']){
$zmqianbao['app_appsecret'] = $zmqianbao2['app_appsecret'];
}
if(!$zmqianbao['app_mchid']){
$zmqianbao['app_mchid'] = $zmqianbao2['app_mchid'];
}
if(!$zmqianbao['app_mchkey']){
$zmqianbao['app_mchkey'] = $zmqianbao2['app_mchkey'];
}

define('appweixin_appid', $zmqianbao['app_appid']);
define('appweixin_appsecret', $zmqianbao['app_appsecret']);
define('appweixin_mchid', $zmqianbao['app_mchid']);
define('appweixin_key', $zmqianbao['app_mchkey']);
define('CURL_TIMEOUT', 30);


/**
 * TODO：这里设置代理机器，只有需要代理的时候才设置，不需要代理，请设置为0.0.0.0和0
 * 本例程通过curl使用HTTP POST方法，此处可修改代理服务器，
 * 默认CURL_PROXY_HOST=0.0.0.0和CURL_PROXY_PORT=0，此时不开启代理（如有需要才设置）
 * @var unknown_type
 */
define('CURL_PROXY_HOST', '0.0.0.0');
define('CURL_PROXY_PORT', 0);

/**
 * TODO：接口调用上报等级，默认紧错误上报（注意：上报超时间为【1s】，上报无论成败【永不抛出异常】，
 * 不会影响接口调用流程），开启上报之后，方便微信监控请求调用的质量，建议至少
 * 开启错误上报。
 * 上报等级，0.关闭上报; 1.仅错误出错上报; 2.全量上报
 * @var int
 */
define('REPORT_LEVENL', 1);