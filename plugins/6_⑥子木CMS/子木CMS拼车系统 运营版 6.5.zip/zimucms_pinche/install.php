<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `useruid` int(10) unsigned NOT NULL,
  `leixing` tinyint(1) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `timetext` char(250) NOT NULL,
  `chufadi` char(40) NOT NULL,
  `mudidi` char(40) NOT NULL,
  `tujing` char(250) NOT NULL,
  `kongwei` smallint(3) unsigned NOT NULL,
  `lianxi` char(100) NOT NULL,
  `beizhu` char(250) NOT NULL,
  `sort` smallint(3) unsigned NOT NULL DEFAULT '100',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `iszhiding` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `zhidingtype` tinyint(1) unsigned NOT NULL,
  `zhidingendtime` int(10) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `clientip` char(20) NOT NULL,
  `islongterm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `longstart` int(10) unsigned NOT NULL,
  `longend` int(10) unsigned NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `isfree` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(250) NOT NULL,
  `thumb` char(250) NOT NULL,
  `sort` smallint(3) unsigned NOT NULL DEFAULT '100',
  `ispost` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_paylog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `type` char(10) NOT NULL,
  `jine` float NOT NULL,
  `zengsong` float NOT NULL,
  `out_trade_no` char(50) NOT NULL,
  `orderNum` char(100) NOT NULL,
  `ischongzhi` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) unsigned NOT NULL,
  `note` char(255) NOT NULL,
  `pincheid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `allmoney` float NOT NULL,
  `money` float NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_userlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `money_xiaohao` float NOT NULL,
  `zhiding_xiaohao` float NOT NULL,
  `longterm` smallint(3) unsigned NOT NULL,
  `kouchujifen` float NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_xcx_accesstoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `gender` tinyint(1) unsigned NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `openid` char(200) NOT NULL,
  `unionid` char(200) NOT NULL,
  `token` char(200) NOT NULL,
  `xcx_appid` char(100) NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE;
?>