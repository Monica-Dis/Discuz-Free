<?php

/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_pinche'));
$usernamearray = mysqltoarray($username);
if (!in_array('useruid', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_pinche` ADD COLUMN `useruid` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('zhidingtype', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `zhidingtype` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('isfree', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `isfree` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('zhidingendtime', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_pinche` ADD COLUMN `zhidingendtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('views', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `views` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('islongterm', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `islongterm` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0';
EOF;
    runquery($sql1);
}
if (!in_array('longstart', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `longstart` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('longend', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche` ADD COLUMN `longend` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

    $sql1 = <<<EOF
    
CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(250) NOT NULL,
  `thumb` char(250) NOT NULL,
  `sort` smallint(3) unsigned NOT NULL DEFAULT '100',
  `ispost` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_paylog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `type` char(10) NOT NULL,
  `jine` float NOT NULL,
  `zengsong` float NOT NULL,
  `out_trade_no` char(50) NOT NULL,
  `ischongzhi` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `allmoney` float NOT NULL,
  `money` float NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_pinche_userlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `money_xiaohao` float NOT NULL,
  `zhiding_xiaohao` float NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_xcx_accesstoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(50) NOT NULL,
  `gender` tinyint(1) unsigned NOT NULL,
  `avatar` varchar(1000) NOT NULL,
  `openid` char(200) NOT NULL,
  `unionid` char(200) NOT NULL,
  `token` char(200) NOT NULL,
  `xcx_appid` char(100) NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql1);

$username2 = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_pinche_userlog'));
$usernamearray2 = mysqltoarray($username2);
if (!in_array('longterm', $usernamearray2)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche_userlog` ADD COLUMN `longterm` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('kouchujifen', $usernamearray2)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche_userlog` ADD COLUMN `kouchujifen` FLOAT NOT NULL;
EOF;
    runquery($sql1);
}

$username3 = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_pinche_paylog'));
$usernamearray3 = mysqltoarray($username3);
if (!in_array('orderNum', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche_paylog` ADD COLUMN `orderNum` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('note', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche_paylog` ADD COLUMN `note` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('pincheid', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_pinche_paylog` ADD COLUMN `pincheid` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
