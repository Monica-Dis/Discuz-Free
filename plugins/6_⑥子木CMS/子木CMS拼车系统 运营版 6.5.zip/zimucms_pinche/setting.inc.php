<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';


if(file_exists(DISCUZ_ROOT . "./source/plugin/zimucms_qianbao/config.php")){
$zmqianbao2 = zimu_readfromcache('setting_plugin_zimucms_qianbao');
}
$zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');

if(!$zmqianbao['weixin_appid']){
$zmqianbao['weixin_appid'] = $zmqianbao2['weixin_appid'];
}
if(!$zmqianbao['weixin_appsecret']){
$zmqianbao['weixin_appsecret'] = $zmqianbao2['weixin_appsecret'];
}
if(!$zmqianbao['weixin_mchid']){
$zmqianbao['weixin_mchid'] = $zmqianbao2['weixin_mchid'];
}
if(!$zmqianbao['weixin_mchkey']){
$zmqianbao['weixin_mchkey'] = $zmqianbao2['weixin_mchkey'];
}

if(!$zmqianbao['app_appid']){
$zmqianbao['app_appid'] = $zmqianbao2['app_appid'];
}
if(!$zmqianbao['app_appsecret']){
$zmqianbao['app_appsecret'] = $zmqianbao2['app_appsecret'];
}
if(!$zmqianbao['app_mchid']){
$zmqianbao['app_mchid'] = $zmqianbao2['app_mchid'];
}
if(!$zmqianbao['app_mchkey']){
$zmqianbao['app_mchkey'] = $zmqianbao2['app_mchkey'];
}

$model = addslashes($_GET['model']);

    if (!submitcheck('basesubmit')) {
        
        showformheader("plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=setting", "enctype");

        showtableheader(lang('plugin/zimucms_pinche', 'system_text22'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text28'), 'zmqianbao[weixin_isopen]', $zmqianbao['weixin_isopen'], 'radio', 0, 0, '');

        showsetting(lang('plugin/zimucms_pinche', 'system_text23'), 'zmqianbao[weixin_appid]', $zmqianbao['weixin_appid'], 'text', '', 0);
        showsetting(lang('plugin/zimucms_pinche', 'system_text24'), 'zmqianbao[weixin_appsecret]', $zmqianbao['weixin_appsecret'], 'text', '', 0);

        showsetting(lang('plugin/zimucms_pinche', 'system_text25'), 'zmqianbao[weixin_mchid]', $zmqianbao['weixin_mchid'], 'text', '', 0);

        showsetting(lang('plugin/zimucms_pinche', 'system_text26'), 'zmqianbao[weixin_mchkey]', $zmqianbao['weixin_mchkey'], 'text', '', 0);

        showtablefooter(); /*dism _taobao _com*/


        showtableheader(lang('plugin/zimucms_pinche', 'system_text27'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text28'), 'zmqianbao[alipay_isopen]', $zmqianbao['alipay_isopen'], 'radio', 0, 0, lang('plugin/zimucms_pinche', 'system_text29'));

        showtablefooter(); /*dism _taobao _com*/


        showtableheader(lang('plugin/zimucms_pinche', 'system_text30'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text28'), 'zmqianbao[app_isopen]', $zmqianbao['app_isopen'], 'radio', 0, 0, '');

        showsetting(lang('plugin/zimucms_pinche', 'system_text31'), 'zmqianbao[app_appid]', $zmqianbao['app_appid'], 'text', '', 0);
        showsetting(lang('plugin/zimucms_pinche', 'system_text32'), 'zmqianbao[app_appsecret]', $zmqianbao['app_appsecret'], 'text', '', 0);

        showsetting(lang('plugin/zimucms_pinche', 'system_text33'), 'zmqianbao[app_mchid]', $zmqianbao['app_mchid'], 'text', '', 0);

        showsetting(lang('plugin/zimucms_pinche', 'system_text34'), 'zmqianbao[app_mchkey]', $zmqianbao['app_mchkey'], 'text', '', 0);

        showtablefooter(); /*dism _taobao _com*/


        showtableheader(lang('plugin/zimucms_pinche', 'system_text35'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text36'), 'zmqianbao[qf_hostname]', $zmqianbao['qf_hostname'], 'text', '', 0,lang('plugin/zimucms_pinche', 'system_text37'));
        showsetting(lang('plugin/zimucms_pinche', 'system_text38'), 'zmqianbao[qf_secret]', $zmqianbao['qf_secret'], 'text', '', 0);

        showsetting(lang('plugin/zimucms_pinche', 'system_text39'), 'zmqianbao[qf_type]', $zmqianbao['qf_type'], 'text', '', 0,lang('plugin/zimucms_pinche', 'system_text40'));

        showtablefooter(); /*dism _taobao _com*/


        showtableheader(lang('plugin/zimucms_pinche', 'system_text41'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text44'), 'zmqianbao[magapp_hostname]', $zmqianbao['magapp_hostname'], 'text', '', 0,lang('plugin/zimucms_pinche', 'system_text42'));
        showsetting(lang('plugin/zimucms_pinche', 'system_text45'), 'zmqianbao[magapp_secret]', $zmqianbao['magapp_secret'], 'text', '', 0,lang('plugin/zimucms_pinche', 'system_text43'));


        showsetting(lang('plugin/zimucms_pinche', 'system_text66'), 'zmqianbao[is_assistant]', $zmqianbao['is_assistant'], 'radio', 0, 0, lang('plugin/zimucms_pinche', 'system_text67'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text68'), 'zmqianbao[assistant_secret]', $zmqianbao['assistant_secret'], 'text', '', 0,lang('plugin/zimucms_pinche', 'system_text69'));

        showsetting(lang('plugin/zimucms_pinche', 'system_text70'), 'zmqianbao[assistant_content]', $zmqianbao['assistant_content'], 'textarea', '', 0,lang('plugin/zimucms_pinche', 'system_text71'));


        showtablefooter(); /*dism _taobao _com*/



        showtableheader(); /*DisM.Taobao.Com*/
        showsubmit('basesubmit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/

    } else {
    
zimu_writetocache('setting_plugin_zimucms_pinche_qianbao',$_GET['zmqianbao']);
        
        cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=setting", "succeed");
        
    }