<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimucms_pinche/lib/', '',$_G['siteurl'] );

$notifydata = zimu_zhaopinnotifycheck();
if($notifydata['validator']) {

    $order_id  = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    
    $paylogdata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_pinche_paylog',
        $order_id
    ));
    
    if ($paylogdata['status'] == 1) {
        $addata['status'] = '2';
        $result           = DB::update('zimucms_pinche_paylog', $addata, array(
            'out_trade_no' => $order_id
        ));

        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_pinche_user',
            $paylogdata['uid']
        ));

        DB::query("update %t set money=0,uptime=%d where uid=%d", array(
            'zimucms_pinche_user',
            $_G['timestamp'],
            $paylogdata['uid'],
        ));
        
        $adddata2['uid']             = $paylogdata['uid'];
        $adddata2['username']        = $paylogdata['username'];
        $adddata2['money_xiaohao']   = round(($paylogdata['jine']+$isuser['money']),2);
        $adddata2['zhiding_xiaohao'] = 0;
        $adddata2['longterm']        = 0;
        $adddata2['kouchujifen']     = 0;
        $adddata2['addtime']         = $_G['timestamp'];
        $result                      = DB::insert('zimucms_pinche_userlog', $adddata2);

        DB::query("update %t set status=2 where id=%d", array(
            'zimucms_pinche',
            $paylogdata['pincheid'],
        ));

    }


}
function zimu_zhaopinnotifycheck() {
    $_G = $GLOBALS['_G'];

    $msg = '';

include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/lib/WxPay.Config.php');
include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/lib/WxPay.Api.php');
include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/example/WxPay.JsApiPay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/example/WxPay.NativePay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/example/log.php');
include_once(DISCUZ_ROOT.'source/plugin/zimucms_pinche/lib/wxpay/lib/WxPay.Data.php');

    $notify = WxPayApiSF::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApiSF::replyNotify(zimu_zhaopin_arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $paramstring = ToUrlParams($notify);

    if(!$_G['cache']['plugin']){
        loadcache('plugin');
    }
    $config = $_G['cache']['plugin']['zimucms_pinche'];

    $zmqianbao = zimu_readfromcache_notify('setting_plugin_zimucms_pinche_qianbao');

    if(strtoupper(md5($paramstring . "&key=".$zmqianbao['weixin_appsecret'])) != $sign){
        if(strtoupper(md5($paramstring . "&key=".$zmqianbao['weixin_mchkey'])) != $sign) {
            $return = array(
                'return_code' => 'FAIL',
                'return_msg' => 'sign error!',
            );
            WxPayApiSF::replyNotify(zimu_zhaopin_arr2xml($return));
            exit;
        }
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no'   => $notify['out_trade_no'],
            'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price'      => $notify['total_fee'],
            'appid'      => $notify['appid'],
            'notify'     => zimu_zhaopin_arr2xml(array('return_code'=>'SUCCESS')),
            'location'   => false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function zimu_zhaopin_arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}

function ToUrlParams($urlObj)
{
    $buff = "";
    foreach ($urlObj as $k => $v)
    {
        $buff .= $k . "=" . $v . "&";
    }

    $buff = trim($buff, "&");
    return $buff;
}

function zimu_readfromcache_notify($key = 'table_plugin_zimucms_pinche_ad'){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}