<?php
require_once "../lib/WxPay.Api.php";

class MicroPay
{
	public function pay($microPayInput)
	{

		$result = WxPayApiSF::micropay($microPayInput, 5);

		if(!array_key_exists("return_code", $result)
			|| !array_key_exists("out_trade_no", $result)
			|| !array_key_exists("result_code", $result))
		{
			echo "ERROR!";
			throw new WxPayExceptionSF("api ERROR!");
		}

		$out_trade_no = $microPayInput->GetOut_trade_no();
		

		if($result["return_code"] == "SUCCESS" &&
		   $result["result_code"] == "FAIL" && 
		   $result["err_code"] != "USERPAYING" && 
		   $result["err_code"] != "SYSTEMERROR")
		{
			return false;
		}


		$queryTimes = 10;
		while($queryTimes > 0)
		{
			$succResult = 0;
			$queryResult = $this->query($out_trade_no, $succResult);

			if($succResult == 2){
				sleep(2);
				continue;
			} else if($succResult == 1){
				return $queryResult;
			} else {
				return false;
			}
		}

		if(!$this->cancel($out_trade_no))
		{
			throw new WxpayException("back error!");
		}

		return false;
	}

	public function query($out_trade_no, &$succCode)
	{
		$queryOrderInput = new WxPayOrderQuerySF();
		$queryOrderInput->SetOut_trade_no($out_trade_no);
		$result = WxPayApiSF::orderQuery($queryOrderInput);
		
		if($result["return_code"] == "SUCCESS" 
			&& $result["result_code"] == "SUCCESS")
		{
			if($result["trade_state"] == "SUCCESS"){
				$succCode = 1;
			   	return $result;
			}
			else if($result["trade_state"] == "USERPAYING"){
				$succCode = 2;
				return false;
			}
		}

		if($result["err_code"] == "ORDERNOTEXIST")
		{
			$succCode = 0;
		} else{

			$succCode = 2;
		}
		return false;
	}

	public function cancel($out_trade_no, $depth = 0)
	{
		if($depth > 10){
			return false;
		}
		
		$clostOrder = new WxPayReverseSF();
		$clostOrder->SetOut_trade_no($out_trade_no);
		$result = WxPayApiSF::reverse($clostOrder);

		if($result["return_code"] != "SUCCESS"){
			return false;
		}
		

		if($result["result_code"] != "SUCCESS" 
			&& $result["recall"] == "N"){
			return true;
		} else if($result["recall"] == "Y") {
//			return $this->cancel($out_trade_no, ++$depth);
		}
		return false;
	}
}