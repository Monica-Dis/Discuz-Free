<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: notify_credit.php 29236 2012-03-30 05:34:47Z chenmengshu $
 */
define('IN_API', true);
define('CURSCRIPT', 'api');

require '../../../../source/class/class_core.php';
require '../../../../source/function/function_forum.php';

$discuz = C::app();
$discuz->init();

loadcache('plugin');

require_once DISCUZ_ROOT . './source/plugin/zimucms_qianbao/config.php';

$zmqianbao = zimu_readfromcache('setting_plugin_zimucms_qianbao');

$apitype = empty($_GET['attach']) || !preg_match('/^[a-z0-9]+$/i', $_GET['attach']) ? 'alipay' : $_GET['attach'];

$_G['siteurl'] = str_replace('source/plugin/zimucms_qianbao/class/','',$_G['siteurl']);




if($apitype == 'alipay'){
	list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
	define('DISCUZ_PARTNER', $ec_partner);
	define('DISCUZ_SECURITYCODE', $ec_securitycode);
	define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
	
	
	$notifydata = alipay_notifycheck();
	$orderid = $notifydata['order_no'];
	$tradeno = $notifydata['trade_no'];
	$trade_status = $notifydata['trade_status'];
	$notify_time = $_G['timestamp'];
	if($notifydata['trade_status'] == 'WAIT_BUYER_PAY'){   //等待支付
		
	}elseif($notifydata['trade_status'] == 'WAIT_SELLER_SEND_GOODS'){         //买家已付款，等待发货

$addata['out_trade_no'] = $orderid;

if($addata['out_trade_no']){

        $addata['status']   = '2';
        $result = DB::update('zimucms_qianbao_paylog', $addata, array(
            'out_trade_no' => $addata['out_trade_no']
        ));
}

	}elseif($notifydata['trade_status'] == 'WAIT_BUYER_CONFIRM_GOODS'){
		
	}elseif($notifydata['trade_status'] == 'TRADE_FINISHED' || $notifydata['trade_status'] == 'TRADE_SUCCESS'){

$addata['out_trade_no'] = $orderid;

if($addata['out_trade_no']){

        $addata['status']   = '2';
        $result = DB::update('zimucms_qianbao_paylog', $addata, array(
            'out_trade_no' => $addata['out_trade_no']
        ));
}

	}elseif($notifydata['trade_status'] == 'TRADE_CLOSED'){

	}
}


if($notifydata['location']) {
	$url = rawurlencode('home.php?mod=spacecp&ac=credit');
	if($apitype == 'tenpay') {
		echo <<<EOS
<meta name="TENCENT_ONLINE_PAYMENT" content="China TENCENT">
<html>
<body>
<script language="javascript" type="text/javascript">
window.location.href='$_G[siteurl]/plugin.php?id=zimucms_qianbao';
</script>
</body>
</html>
EOS;
	} else {

		dheader('location: '.$_G['siteurl'].'/plugin.php?id=zimucms_qianbao');
	}
} else {
	exit($notifydata['notify']);
}


function alipay_notifycheck() {
	global $_G;
	if(!empty($_POST)) {
		$notify = $_POST;
		$location = FALSE;
	} elseif(!empty($_GET)) {
		$notify = $_GET;
		$location = TRUE;
	} else {
		exit('Access Denied');
	}
	

	if(dfsockopen("http://notify.alipay.com/trade/notify_query.do?partner=".DISCUZ_PARTNER."&notify_id=".$notify['notify_id'], 60) !== 'true') {
		exit('Access Denied');
	}

	
	if(!DISCUZ_SECURITYCODE) {
		exit('Access Denied');
	}
	ksort($notify);
	$sign = '';
	foreach($notify as $key => $val) {
		if($key != 'sign' && $key != 'sign_type') $sign .= "&$key=$val";
	}
	if($notify['sign'] != md5(substr($sign,1).DISCUZ_SECURITYCODE)) {
		exit('Access Denied');
	}
	return array(
    	'order_no' 	=> $notify['out_trade_no'],
        'trade_no'	=> $notify['trade_no'],
        'trade_status' 	=> $notify['trade_status'],
        'price' 	=> $notify['total_fee'],
		'notify'	=> 'success',
		'location'	=> $location
	);
}

// 打印log
function  log_result($file,$word) 
{
	$fp = fopen($file,"a");
	flock($fp, LOCK_EX) ;
	fwrite($fp,"time:".strftime("%Y-%m-%d-%H：%M：%S",time())."\n".$word."\n\n");
	flock($fp, LOCK_UN);
	fclose($fp);
}

?>