<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';
$model = addslashes($_GET['model']);

if ($model == 'editpinche') {
    
    if (submitcheck('editpinche')) {
        
        $addata['id']    = intval($_GET['id']);
        $addata['leixing']    = intval($_GET['leixing']);
        $addata['longstart']     = strtotime($_GET['longstart']);
        $addata['longend']     = strtotime($_GET['longend']);
if($addata['longstart'] && $addata['longend']){
        $addata['starttime']     = strtotime($_GET['starttime'])-strtotime(date('Y-m-d', $_G['timestamp']));
}else{
        $addata['starttime']     = strtotime($_GET['starttime']);
}
        $addata['timetext']       = strip_tags($_GET['timetext']);
        $addata['chufadi']       = strip_tags($_GET['chufadi']);
        $addata['mudidi']       = strip_tags($_GET['mudidi']);
        $addata['tujing']       = strip_tags($_GET['tujing']);
        $addata['kongwei']    = intval($_GET['kongwei']);
        $addata['lianxi']       = strip_tags($_GET['lianxi']);
        $addata['beizhu']       = strip_tags($_GET['beizhu']);
        $addata['sort']          = intval($_GET['sort']);
        $addata['status']        = intval($_GET['status']);
        $addata['addtime']     = strtotime($_GET['addtime']);
        $addata['zhidingendtime']     = strtotime($_GET['zhidingendtime']);    
        $result = DB::update('zimucms_pinche', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']) . '&leixing=' . intval($_GET['leixing']);
            cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $pid = intval($_GET['pid']);
        
        $pinchedata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_pinche',
            $pid
        ));
        
        include template('zimucms_pinche:admin_editpinche');
    }
    
} else if ($model == 'addpinche') {
    
    
    if (submitcheck('editpinche')) {
       
        $addata['leixing']    = intval($_GET['leixing']);
        $addata['starttime']     = strtotime($_GET['starttime']);
        $addata['timetext']       = strip_tags($_GET['timetext']);
        $addata['chufadi']       = strip_tags($_GET['chufadi']);
        $addata['mudidi']       = strip_tags($_GET['mudidi']);
        $addata['tujing']       = strip_tags($_GET['tujing']);
        $addata['kongwei']    = intval($_GET['kongwei']);
        $addata['lianxi']       = strip_tags($_GET['lianxi']);
        $addata['beizhu']       = strip_tags($_GET['beizhu']);
        $addata['sort']          = intval($_GET['sort']);
        $addata['status']        = intval($_GET['status']);
        $addata['addtime']     = strtotime($_GET['addtime']);
        $addata['zhidingendtime']     = strtotime($_GET['zhidingendtime']);   


        $result = DB::insert('zimucms_pinche', $addata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']) . '&leixing=' . intval($_GET['leixing']);
            cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
        }
        
    } else {
        
        include template('zimucms_pinche:admin_editpinche');
    }
    
    
} else if ($model == 'delpinche' && $_GET['md5formhash'] == formhash()) {
    
    $pid = intval($_GET['pid']);
    
    $result = DB::delete('zimucms_pinche', array(
        'id' => $pid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']) . '&leixing=' . intval($_GET['leixing']);
        cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
    }
    
} else {


$todaytime = strtotime(date('Y-m-d',$_G['timestamp']));
$tomorrowtime1 = strtotime(date('Y-m-d',$_G['timestamp']))+86400;
$tomorrowtime2 = strtotime(date('Y-m-d',$_G['timestamp']))+86400+86400;
$tomorrowtime3 = strtotime(date('Y-m-d',$_G['timestamp']))+86400+86400+86400;

$weekarray=array(lang('plugin/zimucms_pinche','system_text14'),lang('plugin/zimucms_pinche','system_text8'),lang('plugin/zimucms_pinche','system_text9'),lang('plugin/zimucms_pinche','system_text10'),lang('plugin/zimucms_pinche','system_text11'),lang('plugin/zimucms_pinche','system_text12'),lang('plugin/zimucms_pinche','system_text13'));
;

$leixing    = intval($_GET['leixing']);
$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);


if ($leixing) {
if($leixing==10){
        $wheresql = ' where starttime<' . $_G['timestamp'].' order by id desc ';
}else{
        $wheresql = ' where leixing= '.$leixing.' and (starttime>' . $_G['timestamp'].' or zhidingendtime > '.$_G['timestamp'].') order by id desc ';
}
} else {
        $wheresql = ' where (starttime>' . $_G['timestamp'].' or zhidingendtime > '.$_G['timestamp'].' or longend > ' . $todaytime .') order by id desc ';
}

$count = DB::result_first("SELECT count(*) FROM %t".$wheresql, array(
    "zimucms_pinche"
));

$limit    = 100;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

$pinchedata = DB::fetch_all('select * from %t '.$wheresql.' limit %d,%d', array(
    'zimucms_pinche',
    $start,
    $limit
));

foreach ($pinchedata as $key => $value) {
if($pinchedata[$key]['islongterm']==1){
$pinchedata[$key]['starttime'] = $pinchedata[$key]['starttime'] + $todaytime;
}
if($value['starttime']>$tomorrowtime3){
$text1 = date('m',$value['starttime']).lang('plugin/zimucms_pinche','system_text6').date('d',$value['starttime']).lang('plugin/zimucms_pinche','system_text7');
}else if($value['starttime']>$tomorrowtime2){
$text1 = lang('plugin/zimucms_pinche','system_text5');
}else if($value['starttime']>$tomorrowtime1){
$text1 = lang('plugin/zimucms_pinche','system_text4');
}else if($value['starttime']>$todaytime){
$text1 = lang('plugin/zimucms_pinche','system_text3');
}else{
$text1 = date('m',$value['starttime']).lang('plugin/zimucms_pinche','system_text6').date('d',$value['starttime']).lang('plugin/zimucms_pinche','system_text7');
}
$pinchedata[$key]['text1'] = $text1;
$pinchedata[$key]['text2'] = $weekarray[date("w",$value['starttime'])];
}

if ($page_num > 1) {
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']) . '&leixing=' . intval($_GET['leixing']), '10000', '10', TRUE, TRUE);
}
    
    
    include template('zimucms_pinche:admin_pinche');
    
}