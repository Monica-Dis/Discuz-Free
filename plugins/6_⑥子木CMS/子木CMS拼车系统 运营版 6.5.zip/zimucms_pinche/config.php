<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

error_reporting(0);

loadcache('plugin');
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_pinche/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_pinche');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

if(IN_XIAOYUNAPP || IN_QFAPP || IN_MAGAPP){
define('IN_APP',1);
}

$ZIMUCMS_URL_urlencode = urlencode(ZIMUCMS_URL);

$zmdata = $_G['cache']['plugin']['zimucms_pinche'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

$manage_uids = explode(',', $zmdata['manage_uids']);
if(in_array($_G['uid'],$manage_uids)){
$isadmin = 1;
}

    function zm_diconv($str)
    {
        global $_G;
        $encode = mb_detect_encoding($str, array(
            "UTF-8",
            "GB2312",
            "GBK",
            ));
/*
        if($encode = 'GB2312' || $encode = 'EUC-CN' || $encode = 'CP936'){
           $encode = 'GBK';
        }
*/
        if ($encode != strtoupper(CHARSET) ) {
            $keytitle = mb_convert_encoding($str,strtoupper(CHARSET), $encode);
        }

        $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'] = trim($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'])), '/')) . ')$/i';
        if ($_G['cache']['plugin']['zimucms_pinche']['zimu_luanma'] && @preg_match($censorexp,$keytitle)) {
            $keytitle = $str;
        }
        if (!$keytitle) {
            $keytitle = $str;
        }
        return $keytitle;
    }





function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();
    
    $upload->init($FILES, 'uploadzimucms');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];

    if($upload->attach['imageinfo'][0]>1500 ||$upload->attach['imageinfo'][1]>1500 ) {
if($upload->attach['imageinfo'][0]>=$upload->attach['imageinfo'][1]){
$thumb_width = $upload->attach['imageinfo'][0]/2;
}else{
$thumb_width = $upload->attach['imageinfo'][1]/2;
}

        require_once libfile('class/image');
        $image = new image();
        $pic2 = $image->Thumb($upload->attach['target'], '',$thumb_width,$thumb_width,2);
    }

    if ($pic2) {
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic.'.thumb.jpg';
    }else{
        return ZIMUCMS_PATH . 'uploadzimucms/' . $pic;  
    }
}

$ZIMUCMS_MYUSER = '1';
function zimu_writetocache($key = 'table_plugin_zimucms_pinche_ad', $array = array()){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $datas = $array;
    $cachedata = " return " . var_export($datas, TRUE) . ";";

    global $_G;

    $dir = DISCUZ_ROOT . "./data/sysdata/";
    if (!is_dir($dir)) {
        dmkdir($dir, 0777);
    }
    $file = "$dir/$key.php";
    if ($fp = @fopen($file, 'wb')) {
        fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($key . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n$cachedata?>");
        fclose($fp);
    } else {
        exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
    }
}

function zimu_readfromcache($key = 'table_plugin_zimucms_pinche_ad'){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}

function zimu_deletefromcache($key = 'table_plugin_zimucms_pinche_ad'){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $cache_file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if(is_file($cache_file)){
        @unlink($cache_file);
    }
    return TRUE;
}


function isallowadd(){
    global $_G;
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
$zmdata = $_G['cache']['plugin']['zimucms_pinche'];
if(!$zmdata['isguest_add']){
    if (!$_G['uid']) {
            $refererurl = $_G['siteurl'] . 'plugin.php?id=zimucms_pinche';
if(IN_XIAOYUNAPP){
    exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script language="javascript" src="source/plugin/zimucms_pinche/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="'.$refererurl.'";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {

$zmqianbao = zimu_readfromcache_qf2('setting_plugin_zimucms_pinche_qianbao');

    if (IN_MAGAPP && !$_G['uid'] && $zmqianbao['magapp_hostname']){
        

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info = strstr($userAgent, "MAGAPPX");
        $info=explode("|",$info);
        $token = $info[7];

        $appurl = $zmqianbao['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$zmqianbao['magapp_secret'];
        
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        }else{
            exit('<script src="source/plugin/zimu_zhaopin/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    });
                    </script>'); 
        }

    }else{
                exit('<script src="source/plugin/zimucms_pinche/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            window.location.href="' . $refererurl . '";
  });
    </script>'); 

    }
  
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
}else{
        dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        exit();
}
    }
$vipgroups = empty($zmdata['group_add']) ? array() : unserialize($zmdata['group_add']);
if (!is_array($vipgroups))
    $vipgroups = array();
if (!in_array($_G['group']['groupid'], $vipgroups) && $vipgroups[0]) {
showmessage($zmdata['noadd_text']);
}
}
}


function zm_wechat_auth($model='topay')
{
    global $_G;

if(file_exists(DISCUZ_ROOT . "./source/plugin/zimucms_qianbao/config.php")){
$zmqianbao2 = zimu_readfromcache('setting_plugin_zimucms_qianbao');
}
$zmqianbao = zimu_readfromcache('setting_plugin_zimucms_pinche_qianbao');


    if (!IN_WECHAT) {
        return;
    }

if(!$zmqianbao['weixin_appid']){
$zmqianbao['weixin_appid'] = $zmqianbao2['weixin_appid'];
}
if(!$zmqianbao['weixin_appsecret']){
$zmqianbao['weixin_appsecret'] = $zmqianbao2['weixin_appsecret'];
}

if(IN_WECHAT && $zmqianbao['weixin_appid'] && $zmqianbao['weixin_appsecret']){

$wechat_client2 = new WeChatClient($zmqianbao['weixin_appid'],$zmqianbao['weixin_appsecret']);

list($openid,$uptime) = getcookie('zm_qianbao') ? explode("\t", authcode(getcookie('zm_qianbao'), 'DECODE')) : array();

if($openid){
return false;
}
$code = addslashes($_GET['code']);

if ($code){
        $token = $wechat_client2->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }

if(!$token['openid']){
$newtoken = $wechat_client2->getAccessToken(1,0);
}else{
set_oauth_cookie($token['openid']);
}

}else{

if($_G['cache']['plugin']['zimucms_pinche']['oauth2_url']){

$login_url = $_G['cache']['plugin']['zimucms_pinche']['oauth2_url'].'?appid='.$zmqianbao['weixin_appid'].'&scope=snsapi_base&state='.md5(FORMHASH).'&redirect_uri=' . urlencode(ZIMUCMS_URL.'&model='.$model);

}else{

 $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmqianbao['weixin_appid'] . '&redirect_uri=' . urlencode(ZIMUCMS_URL.'&model='.$model) . '&response_type=code&scope=snsapi_base&state=' . md5(FORMHASH) . '#wechat_redirect';

}


dheader('Location:' . $login_url);
}


}
}

function set_oauth_cookie($openid)
{
    global $_G;
    dsetcookie('zm_qianbao', authcode($openid . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
}

function zimu_readfromcache2($key = 'setting_plugin_zimucms_qianbao'){

if($key!='setting_plugin_zimucms_qianbao'){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}



function qf_nonce2($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign2($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}
function zimu_readfromcache_qf2($key = 'table_plugin_zimucms_pinche_ad'){

if($key!='table_plugin_zimucms_pinche_ad' && $key!='setting_plugin_zimucms_pinche_qianbao' && $key!='setting_plugin_zimucms_qianbao' && $key!='table_plugin_zimucms_pinche_allviews'){
echo 'no files allow write';exit();
}

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}


function array_sort($array, $keys, $type = 'asc')
{
    if (!isset($array) || !is_array($array) || empty($array)) {
        return '';
    }
    if (!isset($keys) || trim($keys) == '') {
        return '';
    }
    if (!isset($type) || $type == '' || !in_array(strtolower($type), array(
        'asc',
        'desc'
    ))) {
        return '';
    }
    $keysvalue = array();
    foreach ($array as $key => $val) {
        $val[$keys]  = str_replace('-', '', $val[$keys]);
        $val[$keys]  = str_replace(' ', '', $val[$keys]);
        $val[$keys]  = str_replace(':', '', $val[$keys]);
        $keysvalue[] = $val[$keys];
    }
    asort($keysvalue); //keyֵ����
    reset($keysvalue); //ָ������ָ�������һ��
    foreach ($keysvalue as $key => $vals) {
        $keysort[] = $key;
    }
    $keysvalue = array();
    $count     = count($keysort);
    if (strtolower($type) != 'asc') {
        for ($i = $count - 1; $i >= 0; $i--) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    } else {
        for ($i = 0; $i < $count; $i++) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    }
    return $keysvalue;
}
function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}
function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}
function getnewname($username)
{
    global $_G;
    $newname = cutstr(WeChatEmoji::clear($username), 15, '');
    $newname = removeEmoji($newname);
    if ($newname) {
        $censorexp = '/^(' . str_replace(array(
            '\\*',
            "\r\n",
            ' '
        ), array(
            '.*',
            '|',
            ''
        ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
        $newname   = preg_replace($censorexp, '', $newname);
        
        $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
        $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
    }
    
    if (dstrlen($newname) >= 3) {
        loaducenter();
        if (uc_get_user($newname)) {
         $nums = 1;
         $oldname = $newname;
        do {
            $newname = $oldname.$nums;
            $nums++;
        } while (uc_get_user($newname));
        $newname = cutstr($newname, 14, '');
        }
    } else if ($newname) {
        $newname = $newname . '_' . random(5);
    } else {
        $newname = 'wx_' . random(5);
    }
    
    return $newname;
}

function register($username, $inapi = 0, $groupid = 0, $sex = 0)
{
    global $_G;

    require_once libfile('function/member');

    if (!$username && IN_WECHATAPI) {
        echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
        exit;
    } else if (!$username) {
        showmessage('undefined_action');
    }
    
    if (!$zmdata) {
        $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
    }
    
    loaducenter();
    $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;
    
    $password = md5(random(10));
    $email    = 'weixin_' . strtolower(random(10)) . '@null.null';
    
    $usernamelen = dstrlen($username);
    if ($usernamelen < 3) {
        $username = $username . '_' . random(5);
    }
    if ($usernamelen > 15) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_toolong');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_toolong'));
            exit;
        }
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    
    if (@preg_match($censorexp, $username)) {
        if (!IN_WECHATAPI) {
            showmessage('profile_username_protect');
        } else {
            echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            exit;
        }
    }
    
    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if ($uid <= 0) {
        if (!IN_WECHATAPI) {
            if ($uid == -1) {
                showmessage('profile_username_illegal');
            } elseif ($uid == -2) {
                showmessage('profile_username_protect');
            } elseif ($uid == -3) {
                showmessage('profile_username_duplicate');
            } elseif ($uid == -4) {
                showmessage('profile_email_illegal');
            } elseif ($uid == -5) {
                showmessage('profile_email_domain_illegal');
            } elseif ($uid == -6) {
                showmessage('profile_email_duplicate');
            } else {
                showmessage('undefined_action');
            }
        } else {
            if ($uid == -1) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
            } elseif ($uid == -2) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            } elseif ($uid == -3) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
            } elseif ($uid == -4) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
            } elseif ($uid == -5) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
            } elseif ($uid == -6) {
                echo WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
            } else {
                echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
            }
            exit;
        }
    }
    
    $init_arr = array(
        'credits' => explode(',', $_G['setting']['initcredits']),
        'profile' => array(
            'gender' => $sex
        )
    );
    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
    
    if ($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if ($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array(
                'ip' => $_G['clientip'],
                'count' => -1,
                'dateline' => $_G['timestamp']
            ));
        }
    }
    
    if ($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => ''
        ), false, true);
        manage_addnotify('verifyuser');
    }
    
    setloginstatus(array(
        'uid' => $uid,
        'username' => $username,
        'password' => $password,
        'groupid' => $groupid
    ), 0);
    

    include_once libfile('function/stat');
    updatestat('register');
    
    return $uid;
}


function syncAvatar($uid, $avatar)
{
    
    if (!$uid || !$avatar) {
        return false;
    }
    
    if (!$content = dfsockopen($avatar)) {
        return false;
    }
    
    $tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
    file_put_contents($tmpFile, $content);
    
    if (!is_file($tmpFile)) {
        return false;
    }
    $result = uploadUcAvatar($uid, $tmpFile);
    unlink($tmpFile);
    
    C::t('common_member')->update($uid, array(
        'avatarstatus' => '1'
    ));
    return $result;
}

function uploadUcAvatar($uid, $localFile)
{
    
    global $_G;
    if (!$uid || !$localFile) {
        return false;
    }
    
    list($width, $height, $type, $attr) = getimagesize($localFile);
    if (!$width) {
        return false;
    }
    if ($width < 10 || $height < 10 || $type == 4) {
        return false;
    }
    
    $imageType = array(
        1 => '.gif',
        2 => '.jpg',
        3 => '.png'
    );
    $fileType  = $imgType[$type];
    if (!$fileType) {
        $fileType = '.jpg';
    }
    $avatarPath = $_G['setting']['attachdir'];
    $tmpAvatar  = $avatarPath . './temp/upload' . $uid . $fileType;
    file_exists($tmpAvatar) && @unlink($tmpAvatar);
    file_put_contents($tmpAvatar, file_get_contents($localFile));
    
    if (!is_file($tmpAvatar)) {
        return false;
    }
    
    $tmpAvatarBig    = './temp/upload' . $uid . 'big' . $fileType;
    $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
    $tmpAvatarSmall  = './temp/upload' . $uid . 'small' . $fileType;
    
    $image = new image;
    if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
        return false;
    }
    if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
        return false;
    }
    
    $tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
    $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
    $tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
    $avatar1         = byte2hex(file_get_contents($tmpAvatarBig));
    $avatar2         = byte2hex(file_get_contents($tmpAvatarMiddle));
    $avatar3         = byte2hex(file_get_contents($tmpAvatarSmall));
    
    $extra  = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
    $result = uc_api_post_ex('user', 'rectavatar', array(
        'uid' => $uid
    ), $extra);
    
    @unlink($tmpAvatar);
    @unlink($tmpAvatarBig);
    @unlink($tmpAvatarMiddle);
    @unlink($tmpAvatarSmall);
    return true;
}

function byte2hex($string)
{
    $buffer = '';
    $value  = unpack('H*', $string);
    $value  = str_split($value[1], 2);
    $b      = '';
    foreach ($value as $k => $v) {
        $b .= strtoupper($v);
    }
    
    return $b;
}

function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
{
    $s = $sep = '';
    foreach ($arg as $k => $v) {
        $k = urlencode($k);
        if (is_array($v)) {
            $s2 = $sep2 = '';
            foreach ($v as $k2 => $v2) {
                $k2 = urlencode($k2);
                $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                $sep2 = '&';
            }
            $s .= $sep . $s2;
        } else {
            $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
        }
        $sep = '&';
    }
    $postdata = uc_api_requestdata($module, $action, $s, $extra);
    return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
}
   function removeEmoji($text) {
        $clean_text = "";
        // Match Emoticons
        $regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
        $clean_text = preg_replace($regexEmoticons, '', $text);
        // Match Miscellaneous Symbols and Pictographs
        $regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
        $clean_text = preg_replace($regexSymbols, '', $clean_text);
        // Match Transport And Map Symbols
        $regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
        $clean_text = preg_replace($regexTransport, '', $clean_text);
        // Match Miscellaneous Symbols
        $regexMisc = '/[\x{2600}-\x{26FF}]/u';
        $clean_text = preg_replace($regexMisc, '', $clean_text);
        // Match Dingbats
        $regexDingbats = '/[\x{2700}-\x{27BF}]/u';
        $clean_text = preg_replace($regexDingbats, '', $clean_text);
if(!$clean_text){
$clean_text = $text;
}
        return $clean_text;
    }

function bind_login($uid)
{
    global $_G;
    
    if (!($member = getuserbyuid($uid, 1))) {
        return false;
    }else {
        if (isset($member['_inarchive'])) {
            C::t('common_member_archive')->move_to_master($member['uid']);
        }
    }

    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($uid, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));
    return true;
}
 function getRandChar($length){
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;

   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];//rand($min,$max)���ɽ���min��max������֮���һ���������
   }

   return $str;
}
function xcx_select_uid($xcx_zimu_data){
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimucms_pinche'];

if($xcx_zimu_data['unionid']){

$isuid = DB::fetch_first('select * from %t where unionid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $xcx_zimu_data['unionid']
    ));

}else{

$isuid = DB::fetch_first('select * from %t where openid=%s and xcx_appid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $xcx_zimu_data['openid'],
        $zmdata['xcx_appid']
    ));

}

return $isuid;


}
function xcx_token_login($token){

    global $_G;
    $zmdata = $_G['cache']['plugin']['zimucms_pinche'];

if(!$token){
    
exit();

}else{

$istoken = DB::fetch_first('select * from %t where token=%s and xcx_appid=%s order by id desc', array(
        'zimu_xcx_accesstoken',
        $token,
        $zmdata['xcx_appid']
    ));

}

if($istoken['uid'] > 0 ){

bind_login($istoken['uid']);

}else{

return 'error';

}

}
function xcx_reg_user($xcx_zimu_data){
    global $_G;
    $zmdata = $_G['cache']['plugin']['zimucms_pinche'];

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/class/wechat.lib.class.php';

                $regname = getnewname($xcx_zimu_data['username']);
                $uid     = register($regname, 1, 0, $xcx_zimu_data['gender']);
                if ($uid) {
                syncAvatar($uid,$xcx_zimu_data['avatar']);

                $tablefile = DISCUZ_ROOT.'./source/plugin/zimucms_pinche/weixin_table.php';

                if(is_file($tablefile)){
                    include DISCUZ_ROOT.'./source/plugin/zimucms_pinche/weixin_table.php';
                }                 
                    
                    if ($zmdata['xcx_isapp'] == 2 && $xcx_zimu_data['unionid']) {

                        $appdata = array(
                            'uid' => $uid,
                            'nickname' => $regname,
                            'dateline' => $_G['timestamp'],
                            'unionid' => $xcx_zimu_data['unionid'],
                            'weibotype' => 'wechat',
                            );

                        DB::insert('thirdbind', $appdata);

                    }
                    
                    if ($zmdata['xcx_isapp'] == 3 && $xcx_zimu_data['unionid']) {

                        $appdata = array(
                            'userid' => $uid,
                            'name' => $regname,
                            'create_time' => $_G['timestamp'],
                            'unionid' => $xcx_zimu_data['unionid'],
                            );

                        DB::insert('user_weixin_relations', $appdata);

                    }

                    if ($zmdata['xcx_isapp'] == 4 && $xcx_zimu_data['unionid']) {

                        $appdata = array(
                        'uid' => $uid,
                        'openid' => '',
                        'status' => '1',
                        'type' => '1',
                        'param' => $xcx_zimu_data['unionid']
                            );

                        DB::insert('appbyme_connection', $appdata);

                    }
return $uid;
}
}
function lizimu_post2($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
}