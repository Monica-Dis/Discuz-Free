<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';
$model = addslashes($_GET['model']);


if ($model == 'editneirong') {
    
    if (submitcheck('editneirong')) {
        
        $addata['id']    = intval($_GET['id']);
        $addata['title']       = strip_tags($_GET['title']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $addata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $addata['ispost']    = intval($_GET['ispost']);
        $addata['url']       = strip_tags($_GET['url']);
        $addata['sort']    = intval($_GET['sort']);
        $result = DB::update('zimucms_pinche_ad', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {

$faxiandata = DB::fetch_all('select * from %t order by sort asc,id desc limit 100', array(
    'zimucms_pinche_ad'
));
zimu_writetocache('table_plugin_zimucms_pinche_ad',$faxiandata);


            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
        }
        
    } else {
        
        $aid = intval($_GET['aid']);

        $faxiandata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_pinche_ad',
            $aid
        ));
        
        include template('zimucms_pinche:admin_editad');
    }
    
} else if ($model == 'addneirong') {
    
    
    if (submitcheck('editneirong')) {
       
        $addata['title']       = strip_tags($_GET['title']);
        if ($_FILES['shop_thumb']['tmp_name']) {
            $addata['thumb'] = zm_saveimages($_FILES['shop_thumb']);
        }
        $addata['ispost']    = intval($_GET['ispost']);
        $addata['url']       = strip_tags($_GET['url']);
        $addata['sort']    = intval($_GET['sort']);
        
        $result = DB::insert('zimucms_pinche_ad', $addata);
        
        if ($result) {

$faxiandata = DB::fetch_all('select * from %t order by sort asc,id desc limit 100', array(
    'zimucms_pinche_ad'
));
zimu_writetocache('table_plugin_zimucms_pinche_ad',$faxiandata);

            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
            cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
        }
        
    } else {

        include template('zimucms_pinche:admin_editad');
    }
    
    
} else if ($model == 'delneirong' && $_GET['md5formhash'] == formhash()) {
    
    $aid = intval($_GET['aid']);
    
    $result = DB::delete('zimucms_pinche_ad', array(
        'id' => $aid
    ));
    if ($result) {

$faxiandata = DB::fetch_all('select * from %t order by sort asc,id desc limit 100', array(
    'zimucms_pinche_ad'
));
zimu_writetocache('table_plugin_zimucms_pinche_ad',$faxiandata);

        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&page=' . intval($_GET['page']);
        cpmsg(lang('plugin/zimucms_pinche', 'system_text1'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_pinche', 'system_text2'), '', 'error');
    }
    
} else {


$faxiandata = DB::fetch_all('select * from %t order by sort asc,id desc', array(
    'zimucms_pinche_ad'
));

    include template('zimucms_pinche:admin_ad');
    
}