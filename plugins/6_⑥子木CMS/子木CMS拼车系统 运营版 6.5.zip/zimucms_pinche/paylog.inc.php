<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_pinche/config.php';

$model = addslashes($_GET['model']);

$type = addslashes($_GET['type']);

$page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
$page   = intval($page);

if($type){

$allmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and type=%s", array(
    "zimucms_pinche_paylog",
    $type
));

$allmoney = round($allmoney,2);


$monthmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and type=%s", array(
    "zimucms_pinche_paylog",
    mktime(0, 0, 0, date('m'), 1, date('Y')),
    $type
));

$monthmoney = round($monthmoney,2);


$lastmonthmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and addtime<%d and type=%s", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-01') . ' -1 month'),
    strtotime(date('Y-m-01')),
    $type
));

$lastmonthmoney = round($lastmonthmoney,2);


$weekmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and type=%s", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',(time()-((date('w')==0?7:date('w'))-1)*24*3600))),
    $type
));

$weekmoney = round($weekmoney,2);


$daymoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and type=%s", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',$_G['timestamp'])),
    $type
));

$daymoney = round($daymoney,2);


$lastdaymoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and addtime<%d and type=%s", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',$_G['timestamp']))-86400,
    strtotime(date('Y-m-d',$_G['timestamp'])),
    $type
));

$lastdaymoney = round($lastdaymoney,2);


$count = DB::result_first("SELECT count(*) FROM %t where type=%s", array(
    "zimucms_pinche_paylog",
    $type
));

$limit    = 50;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

    $paylogdata = DB::fetch_all('select * from %t where type=%s order by id desc limit %d,%d', array(
        'zimucms_pinche_paylog',
        $type,
        $start,
        $limit
    ));
}else{


$allmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2", array(
    "zimucms_pinche_paylog"
));

$allmoney = round($allmoney,2);


$monthmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d", array(
    "zimucms_pinche_paylog",
    mktime(0, 0, 0, date('m'), 1, date('Y'))
));

$monthmoney = round($monthmoney,2);


$lastmonthmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and addtime<%d", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-01') . ' -1 month'),
    strtotime(date('Y-m-01'))
));

$lastmonthmoney = round($lastmonthmoney,2);


$weekmoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',(time()-((date('w')==0?7:date('w'))-1)*24*3600)))
));

$weekmoney = round($weekmoney,2);


$daymoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',$_G['timestamp']))
));

$daymoney = round($daymoney,2);


$lastdaymoney = DB::result_first("SELECT sum(`jine`) FROM %t WHERE status=2 and addtime>%d and addtime<%d", array(
    "zimucms_pinche_paylog",
    strtotime(date('Y-m-d',$_G['timestamp']))-86400,
    strtotime(date('Y-m-d',$_G['timestamp']))
));

$lastdaymoney = round($lastdaymoney,2);


$count = DB::result_first("SELECT count(*) FROM %t", array(
    "zimucms_pinche_paylog"
));

$limit    = 50;
$start    = ($page - 1) * $limit;
$page_num = ceil($count / $limit);

    $paylogdata = DB::fetch_all('select * from %t order by id desc limit %d,%d', array(
        'zimucms_pinche_paylog',
        $start,
        $limit
    ));
}


if ($page_num > 1) {    
    $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . '&type=' . $type . '&page=' . intval($_GET['page']), '10000', '10', TRUE, TRUE);
}

    include template('zimucms_pinche:paylog');