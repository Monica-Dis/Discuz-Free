<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_baoliao/config.php';
$model = addslashes($_GET['model']);

//爆料管理
if ($model == 'baoliao') {
    
    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page   = intval($page);
    $status = intval($_GET['status']);
    if ($status) {
        $wheresql = ' where status=' . $status;
    }
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
        "zimucms_baoliao_news"
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $newsdata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
        'zimucms_baoliao_news',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $status, '10000', '10000', TRUE, TRUE);
    }
    include template('zimucms_baoliao:admin/baoliao');
    
    //编辑爆料
} else if ($model == 'editnews') {
    
    if (submitcheck('edit_news')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['title']    = dhtmlspecialchars($_GET['title']);
        $editdata['content']  = $_GET['content'];
        $editdata['isniming'] = intval($_GET['isniming']);
        $editdata['jiangli']  = round($_GET['jiangli'], 2);
        $editdata['jiangli_score'] = intval($_GET['jiangli_score']);
        $editdata['leixing']  = intval($_GET['leixing']);
        $editdata['didian']   = dhtmlspecialchars($_GET['didian']);
        $editdata['addtime']  = strtotime($_GET['addtime']);
        $editdata['fidvalue'] = intval($_GET['fidvalue']);
        $editdata['typeidvalue'] = intval($_GET['typeidvalue']);
        $result               = DB::update('zimucms_baoliao_news', $editdata, array(
            'id' => $editdata['id']
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $_GET['status'] .'&page='.$_GET['page'];
            cpmsg('&#20462;&#25913;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#20462;&#25913;&#22833;&#36133;&#65281;', '', 'error');
        }
        
    } else {
        $editid   = intval($_GET['editid']);
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_baoliao_news',
            $editid
        ));
        $isbaoliao_user =  DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_baoliao_user',
            $newsdata['uid']
        ));
        require_once libfile('function/forumlist');
        
        $forumselect = forumselect(FALSE, 0, $newsdata['fidvalue'], TRUE);
        
        $typeiddata = C::t('forum_threadclass')->fetch_all_by_fid($newsdata['fidvalue']);

        include template('zimucms_baoliao:admin/editbaoliao');
    }
    //删除爆料
} else if ($model == 'delnews') {
    
    if ($_GET['formhash'] == formhash()) {
        $delid  = intval($_GET['delid']);
        $result = DB::delete('zimucms_baoliao_news', array(
            'id' => $delid
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $_GET['status'] .'&page='.$_GET['page'];
            cpmsg('&#21024;&#38500;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#21024;&#38500;&#22833;&#36133;&#65281;', '', 'error');
        }
    }
    
    //拒绝爆料
} else if ($model == 'jujuenews') {
    
    if ($_GET['formhash'] == formhash()) {
        
        $editdata['id']     = intval($_GET['editid']);
        $editdata['status'] = 3;
        $result             = DB::update('zimucms_baoliao_news', $editdata, array(
            'id' => $editdata['id']
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $_GET['status'].'&page='.$_GET['page'];
            cpmsg('&#20462;&#25913;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#20462;&#25913;&#22833;&#36133;&#65281;', '', 'error');
        }
        
    }
    
    //发布爆料
} else if ($model == 'fabunews') {
    
    if ($_GET['formhash'] == formhash()) {
        
        $editid   = intval($_GET['editid']);
        $newsdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_baoliao_news',
            $editid
        ));
        
        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_baoliao_user',
            $newsdata['uid']
        ));

        if ($newsdata['uid'] == 0 || !$isuser || round($newsdata['jiangli'], 2) >= round($zmbaoliao['minjiangli'], 2) ) {
            
            
            
            // 开始发布帖子
            include_once libfile('function/forum');
            include_once libfile('function/post');
            include_once libfile('function/stat');
            include_once libfile('function/editor');
            
            if ($newsdata['uid'] == 0) {
                $uid    = intval($zmbaoliao['nouid']);
                $member = getuserbyuid($uid, 1);
            } else {
                if ($newsdata['isniming'] == 1) {
                    $uid    = intval($zmbaoliao['nouid']);
                    $member = getuserbyuid($uid, 1);
                } else {
                    $uid    = intval($newsdata['uid']);
                    $member = getuserbyuid($uid, 1);
                }
            }
            if (!$member) {
                cpmsg('&#29190;&#26009;&#29992;&#25143;&#19981;&#23384;&#22312;&#65292;&#35831;&#26816;&#26597;&#29190;&#26009;&#29992;&#25143;&#85;&#73;&#68;&#26159;&#21542;&#27491;&#30830;', '', 'error');
                exit();
            }
            
            $newthread = array(
                'fid' => $newsdata['fidvalue'],
                'typeid' => $newsdata['typeidvalue'],
                'author' => $member['username'],
                'authorid' => $uid,
                'subject' => $newsdata['title'],
                'dateline' => TIMESTAMP,
                'lastpost' => TIMESTAMP,
                'lastposter' => $member['username']
            );
            
            $tid = C::t('forum_thread')->insert($newthread, true);
            $newsdata_content = html2bbcode($newsdata['content']);
            $pid = insertpost(array(
                'fid' => $newsdata['fidvalue'],
                'tid' => $tid,
                'author' => $member['username'],
                'authorid' => $uid,
                'subject' => $newsdata['title'],
                'dateline' => TIMESTAMP,
                'message' => $newsdata_content,
                'useip' => '127.0.0.1',
                'first' => '1'
            ));
            
            if (!isset($_G['cache']['forums'])) {
                loadcache('forums');
            }
            useractionlog($uid, 'tid');
            C::t('common_member_field_home')->update($uid, array(
                'recentnote' => $newsdata['title']
            ));
            $lastpost = "$tid\t" . $newsdata['title'] . "\t" . TIMESTAMP . "\t$member[username]";
            C::t('forum_forum')->update($newsdata['fidvalue'], array(
                'lastpost' => $lastpost
            ));
            C::t('forum_forum')->update_forum_counter($newsdata['fidvalue'], 1, 1, 1);
            if ($_G['cache']['forums'][$newsdata['fidvalue']]['type'] == 'sub') {
                C::t('forum_forum')->update($_G['cache']['forums'][$newsdata['fidvalue']]['fup'], array(
                    'lastpost' => $lastpost
                ));
            }
            // 处理爆料远程附件

                $subdir = date('Ym').'/'.date('d').'/';
                $basedir = 'forum/'.$subdir;
                !is_dir($_G['setting']['attachdir'].$basedir) && dmkdir($_G['setting']['attachdir'].$basedir);
                
                $attachubb = '';
                preg_match_all('/<img src=\"([^<>"]+)\"([^<>]+)>/',$newsdata['content'],$factattachment);
                $fact['attachment'] = $factattachment[1];
                foreach($fact['attachment'] as $key => $url) {
                    $content = dfsockopen($_G['siteurl'].'/'.$url);
                    if(!$content) {
                        continue;
                    }
                    $filename = date('His').strtolower(random(16)).'.jpg';
                    $rtn = file_put_contents($_G['setting']['attachdir'].$basedir.$filename, $content);
                    if(!$rtn) {
                        continue;
                    }
                    
                    $aid = C::t('forum_attachment')->insert(array('tid' => $tid, 'pid' => $pid, 'uid' => $uid, 'tableid' => getattachtableid($tid)), true);
                    $filesize = filesize($_G['setting']['attachdir'].$basedir.$filename);
                    $thumb = $width = 0;
                    if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                        $image = new image();
                        $thumb = $image->Thumb($_G['setting']['attachdir'].$basedir.$filename, '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                        $width = $image->imginfo['width'];
                        $filesize = $image->imginfo['size'];
                    }
                    if($_G['setting']['thumbstatus']) {
                        $image = new image();
                        $thumb = $image->Thumb($_G['setting']['attachdir'].$basedir.$filename, '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                        $width = $image->imginfo['width'];
                    }
                    if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                        list($width) = @getimagesize($_G['setting']['attachdir'].$basedir.$filename);
                    }
                    if($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
                        $image = new image();
                        $image->Watermark($_G['setting']['attachdir'].$basedir.$filename, '', 'forum'); 
                        $filesize = $image->imginfo['size'];
                    }

                    $insert = array(
                        'aid' => $aid,
                        'tid' => $tid,
                        'pid' => $pid,
                        'dateline' => $_G['timestamp'],
                        'filename' => $filename,
                        'filesize' => $filesize,
                        'attachment' => $subdir.$filename,
                        'isimage' => 1,
                        'uid' => $uid,
                        'thumb' => $thumb,
                        'remote' => 0,
                        'width' => $width,
                    );
                    
                    C::t('forum_attachment_n')->insert('tid:'.$tid, $insert, false, true);
                    $attachubb = "\n[attach]".$aid.'[/attach]'; 
                    $attachment = 2;
                $newsdata_content = str_replace(html2bbcode($factattachment[0][$key]), $attachubb, $newsdata_content);

                }
                C::t('forum_thread')->update($tid, array('attachment' => $attachment));
                C::t('forum_post')->update(0, $pid, array('message' => $newsdata_content, 'attachment' => $attachment));

            //开始处理自定义数据库。                
            if ($tid) {
                //判断是否增加额外积分
                if ($zmbaoliao['scorevalue'] > 0 && $newsdata['uid'] > 0) {
                    updatemembercount($newsdata['uid'], array(
                        'extcredits' . $zmbaoliao['scoretype'] => $newsdata['jiangli_score']
                    ), true, '', 0, '');
                }
                $editdata['baoliaourl'] = $tid;
                $editdata['status']     = 2;
                $result                 = DB::update('zimucms_baoliao_news', $editdata, array(
                    'id' => $editid
                ));
                if ($newsdata['uid'] > 0) {
                    DB::query("update %t set credits=credits+" . round($newsdata['jiangli'], 2) . " where uid=%d", array(
                        'zimucms_baoliao_user',
                        $newsdata['uid']
                    ));
                    DB::query("update %t set allcredits=allcredits+" . round($newsdata['jiangli'], 2) . " where uid=%d", array(
                        'zimucms_baoliao_user',
                        $newsdata['uid']
                    ));
                }
                $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $_GET['status'];
                cpmsg('&#21457;&#24067;&#25104;&#21151;&#65292;&#24086;&#23376;&#73;&#68;&#20026;&#65306;' . $tid, $url, 'succeed');
            } else {
                cpmsg('&#21457;&#24067;&#22833;&#36133;', '', 'error');
            }
            
            
        } else {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=baoliao&status=' . $_GET['status'] .'&page='.$_GET['page'];
            cpmsg('&#35813;&#29190;&#26009;&#29992;&#25143;&#24050;&#21152;&#20837;&#29190;&#26009;&#22242;&#65292;&#35831;&#32534;&#36753;&#35813;&#29190;&#26009;&#30340;&#29190;&#26009;&#22870;&#21169;&#20540;&#20026;&#26368;&#29190;&#26009;&#20540;', $url, 'error');
        }
    }
    
    //用户管理列表
} else if ($model == 'user') {
    
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page  = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_baoliao_user"
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $userdata = DB::fetch_all('select * from %t order by id desc limit %d,%d', array(
        'zimucms_baoliao_user',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=user', '10000', '10000', TRUE, TRUE);
    }
    include template('zimucms_baoliao:admin/user');
    
    //编辑用户
} else if ($model == 'edituser') {
    
    
    if (submitcheck('edit_user')) {
        
        $editdata['id']       = intval($_GET['id']);
        $editdata['xingming'] = dhtmlspecialchars($_GET['xingming']);
        $editdata['qq']       = intval($_GET['qq']);
        $editdata['weixin']   = dhtmlspecialchars($_GET['weixin']);
        $editdata['tel']      = strip_tags($_GET['tel']);
        $editdata['sex']      = intval($_GET['sex']);
        $editdata['status']   = intval($_GET['status']);
        
        $result = DB::update('zimucms_baoliao_user', $editdata, array(
            'id' => $editdata['id']
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=user';
            cpmsg('&#20462;&#25913;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#20462;&#25913;&#22833;&#36133;&#65281;', '', 'error');
        }
        
    } else {
        $editid   = intval($_GET['editid']);
        $userdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_baoliao_user',
            $editid
        ));
        
        include template('zimucms_baoliao:admin/edituser');
    }
    
    
    //删除用户
} else if ($model == 'deluser') {
    
    if ($_GET['formhash'] == formhash()) {
        $delid  = intval($_GET['delid']);
        $result = DB::delete('zimucms_baoliao_user', array(
            'id' => $delid
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=user';
            cpmsg('&#21024;&#38500;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#21024;&#38500;&#22833;&#36133;&#65281;', '', 'error');
        }
    }
    
    //提现管理
} else if ($model == 'tixian') {
    
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page  = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_baoliao_tixian"
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $userdata = DB::fetch_all('select * from %t order by id desc limit %d,%d', array(
        'zimucms_baoliao_tixian',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=tixian', '10000', '10000', TRUE, TRUE);
    }
    include template('zimucms_baoliao:admin/tixian');
    
    //确认提现
} else if ($model == 'uptixian') {
    
    if ($_GET['formhash'] == formhash()) {
        
        $txid               = intval($_GET['txid']);
        $editdata['status'] = 2;
        
        
        $result = DB::update('zimucms_baoliao_tixian', $editdata, array(
            'id' => $txid
        ));
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=zimucms_baoliao&pmod=Admin&model=tixian';
            cpmsg('&#20462;&#25913;&#25104;&#21151;&#65281;', $url, 'succeed');
        } else {
            cpmsg('&#20462;&#25913;&#22833;&#36133;&#65281;', '', 'error');
        }
        
    }
}