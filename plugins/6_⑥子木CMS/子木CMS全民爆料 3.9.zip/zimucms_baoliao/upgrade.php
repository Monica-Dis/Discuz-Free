<?php

/**
 * 插件更新时执行此文件
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$username = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_baoliao_news'));
$usernamearray = mysqltoarray($username);
if (!in_array('leixing', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_baoliao_news` ADD COLUMN `leixing` SMALLINT(1) UNSIGNED NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}
if (!in_array('didian', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_news` ADD COLUMN `didian` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('fidvalue', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_baoliao_news` ADD COLUMN `fidvalue` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('lianxitel', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_news` ADD COLUMN `lianxitel` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('typeidvalue', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_news` ADD COLUMN `typeidvalue` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('jiangli_score', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_news` ADD COLUMN `jiangli_score` SMALLINT(5) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('video', $usernamearray)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_news` ADD COLUMN `video` VARCHAR(1000) NOT NULL;
EOF;
    runquery($sql1);
}

$username2 = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_baoliao_user'));
$usernamearray2 = mysqltoarray($username2);
if (!in_array('xingming', $usernamearray2)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `xingming` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('openid', $usernamearray2)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `openid` CHAR(32) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('username', $usernamearray2)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `username` CHAR(40) NOT NULL;
EOF;
    runquery($sql1);
}

$username3 = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_baoliao_tixian'));
$usernamearray3 = mysqltoarray($username3);
if (!in_array('mch_billno', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `mch_billno` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('return_msg', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `return_msg` VARCHAR(3000) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('send_listid', $usernamearray3)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimucms_baoliao_user` ADD COLUMN `send_listid` CHAR(255) NOT NULL;
EOF;
    runquery($sql1);
}


    $sql1 = <<<EOF
    
CREATE TABLE IF NOT EXISTS `pre_zimucms_baoliao_mobilecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` char(11) NOT NULL,
  `code` int(4) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


EOF;

runquery($sql1);

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
