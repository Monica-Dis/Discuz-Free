<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_baoliao_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `content` text NOT NULL,
  `video` varchar(1000) NOT NULL,
  `isniming` tinyint(1) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `baoliaourl` int(10) unsigned DEFAULT '0',
  `jiangli` float NOT NULL DEFAULT '0',
  `jiangli_score` smallint(5) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `leixing` smallint(1) unsigned NOT NULL DEFAULT '1',
  `didian` char(100) NOT NULL,
  `fidvalue` smallint(3) unsigned NOT NULL,
  `typeidvalue` smallint(3) unsigned NOT NULL,
  `lianxitel` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_baoliao_tixian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `username` char(40) NOT NULL,
  `pay` smallint(3) unsigned NOT NULL,
  `payment` tinyint(1) unsigned NOT NULL,
  `account` char(30) NOT NULL,
  `realname` char(10) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `addtime` int(11) unsigned NOT NULL,
  `mch_billno` char(255) NOT NULL,
  `return_msg` varchar(3000) NOT NULL,
  `send_listid` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_baoliao_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` char(30) NOT NULL,
  `xingming` char(20) NOT NULL,
  `qq` char(20) NOT NULL,
  `weixin` char(20) NOT NULL,
  `tel` char(11) NOT NULL,
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `liyou` varchar(200) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `allcredits` float NOT NULL DEFAULT '0',
  `credits` float NOT NULL DEFAULT '0',
  `applytime` int(11) unsigned NOT NULL,
  `openid` char(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_baoliao_mobilecode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` char(11) NOT NULL,
  `code` int(4) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


EOF;

runquery($sql);

$finish = TRUE;
?>