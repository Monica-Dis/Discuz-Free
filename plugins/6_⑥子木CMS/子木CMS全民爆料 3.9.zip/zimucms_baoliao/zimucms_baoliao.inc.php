<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimucms_baoliao/config.php';
require_once DISCUZ_ROOT . './source/plugin/zimucms_baoliao/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmbaoliao['weixin_appid'], $zmbaoliao['weixin_appsecret']);
$jssdkvalue    = $wechat_client->getSignPackage();

$model = addslashes($_GET['model']);

if ($model == 'apply') {
    
    include template('zimucms_baoliao:index/apply');

} else if ($model == 'changephone') {

    if ($_G['uid'] <= 0) {
        return false;
    }

    $userinfo = DB::fetch_first('select * from %t where uid=%d and status=2 order by id desc', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));

    include template('zimucms_baoliao:index/changephone');


} else if ($model == 'applying') {
    
    if ($_GET['formhash'] == formhash()) {

    if ($_G['uid'] <= 0) {
        return false;
    }

        $adddata             = array();
        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = addslashes(zm_diconv($_G['username']));
        $adddata['xingming'] = addslashes(zm_diconv($_GET['xingming']));
        $adddata['qq']       = addslashes(zm_diconv($_GET['qq']));
        $adddata['weixin']   = addslashes(zm_diconv($_GET['weixin']));
        $adddata['sex']      = intval($_GET['sex']);
        $adddata['tel']      = strip_tags(zm_diconv($_GET['tel']));
        $telcode      = strip_tags(zm_diconv($_GET['telcode']));
        $adddata['liyou']    = strip_tags(zm_diconv($_GET['liyou']));


//�ж��Ƿ���֤�ֻ�����
if($zmbaoliao['appid']){
    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and status=0 order by id desc', array(
        'zimucms_baoliao_mobilecode',
        $adddata['tel'],
        $telcode,
        $_G['timestamp'] - $zmbaoliao['codetime']*60
    ));
    
    if (!$iscode) {
        $out['status'] = 1;
        $out['errMsg'] = urlencode(lang('plugin/zimucms_baoliao', 'system_text1'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
}


        if ($zmbaoliao['isshenhe']) {
            $adddata['status'] = 1;
        } else {
            $adddata['status'] = 2;
        }
        $adddata['applytime'] = $_G['timestamp'];
        
        if (!$adddata['uid']) {
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#32;&#32;&#32;&#26410;&#30331;&#38470;&#65292;&#35831;&#30331;&#38470;&#21518;&#30003;&#35831;'
            ));
            exit();
        }
        
        if (!$adddata['uid'] || !$adddata['username'] || !$adddata['qq'] || !$adddata['weixin'] || !$adddata['sex'] || !$adddata['liyou']) {
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#32;&#35831;&#22635;&#20889;&#20840;&#37096;&#36164;&#26009;&#21518;&#20877;&#30003;&#35831;'
            ));
            exit();
        }
        
        //if(!$ZIMUCMS_MYUSER){exit();}
        $isuser = DB::fetch_first('select * from %t where uid=%d', array(
            'zimucms_baoliao_user',
            $adddata['uid']
        ));
        
        if ($isuser['status']) {
            if ($isuser['status'] == 1) {
                echo json_encode(array(
                    'status' => 1,
                    'errMsg' => '&#24744;&#24050;&#32463;&#25552;&#20132;&#20102;&#30003;&#35831;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;'
                ));
            } else if ($isuser['status'] == 2) {
                echo json_encode(array(
                    'status' => 1,
                    'errMsg' => '&#24744;&#24050;&#26159;&#24403;&#20013;&#30340;&#19968;&#21592;&#65292;&#26080;&#27861;&#20877;&#27425;&#25552;&#20132;'
                ));
            } else if ($isuser['status'] == 3) {
                echo json_encode(array(
                    'status' => 1,
                    'errMsg' => '&#24744;&#24050;&#34987;&#25289;&#40657;&#65292;&#35831;&#32852;&#31995;&#31649;&#29702;&#21592;&#23631;&#34109;'
                ));
            }
        } else {
            $result = DB::insert('zimucms_baoliao_user', $adddata);

if($zmbaoliao['appid']){
        DB::update('zimucms_baoliao_mobilecode',array('status' => '1'), array(
            'mobile' => $adddata['tel'],
            'code' => $telcode
            ));
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => $adddata['tel']
        ));
}
            if ($result) {
                echo json_encode(array(
                    'status' => 0,
                    'errMsg' => '&#30003;&#35831;&#25104;&#21151;&#65292;&#35831;&#31561;&#24453;&#23457;&#26680;',
                    'url' => ZIMUCMS_URL
                ));
            }
            
            
        }
        
    }



} else if ($model == 'applying2') {
    
    if ($_GET['formhash'] == formhash()) {

    if ($_G['uid'] <= 0) {
        return false;
    }

        $adddata             = array();
        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = addslashes(zm_diconv($_G['username']));
        $adddata['xingming'] = addslashes(zm_diconv($_GET['xingming']));
        $adddata['qq']       = addslashes(zm_diconv($_GET['qq']));
        $adddata['weixin']   = addslashes(zm_diconv($_GET['weixin']));
        $adddata['sex']      = intval($_GET['sex']);
        $adddata['tel']      = strip_tags(zm_diconv($_GET['tel']));
        $telcode      = strip_tags(zm_diconv($_GET['telcode']));
        $adddata['liyou']    = strip_tags(zm_diconv($_GET['liyou']));


//�ж��Ƿ���֤�ֻ�����
if($zmbaoliao['appid']){
    $iscode = DB::result_first('select id from %t where mobile=%s and code=%d and addtime>%d and status=0 order by id desc', array(
        'zimucms_baoliao_mobilecode',
        $adddata['tel'],
        $telcode,
        $_G['timestamp'] - $zmbaoliao['codetime']*60
    ));
    
    if (!$iscode) {
        $out['status'] = 1;
        $out['errMsg'] = urlencode(lang('plugin/zimucms_baoliao', 'system_text1'));
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
}
        
        if (!$adddata['uid']) {
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#32;&#32;&#32;&#26410;&#30331;&#38470;&#65292;&#35831;&#30331;&#38470;&#21518;&#30003;&#35831;'
            ));
            exit();
        }
        
        if (!$adddata['uid'] || !$adddata['username'] || !$adddata['qq'] || !$adddata['weixin'] || !$adddata['tel'] || !$adddata['sex'] || !$telcode) {
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#32;&#35831;&#22635;&#20889;&#20840;&#37096;&#36164;&#26009;&#21518;&#20877;&#30003;&#35831;'
            ));
            exit();
        }
        
        if(!$ZIMUCMS_MYUSER){exit();}
        $result = DB::update('zimucms_baoliao_user', $adddata, array(
            'uid' => $adddata['uid']
            ));

        DB::update('zimucms_baoliao_mobilecode',array('status' => '1'), array(
            'mobile' => $adddata['tel'],
            'code' => $telcode
            ));
        C::t('common_member_profile')->update($_G['uid'], array(
            'mobile' => $adddata['tel']
        ));

            if ($result) {
                echo json_encode(array(
                    'status' => 0,
                    'errMsg' => '&#20462;&#25913;&#25104;&#21151;',
                    'url' => ZIMUCMS_URL
                ));
            }
            

        
    }

    // ��������
} else if ($model == 'addbaoliao') {

    if (submitcheck('addbaoliao')) {

        require_once libfile('class/image');
        require_once libfile('function/editor');
        $image = new image();

        $adddata['title']    = strip_tags(zm_diconv($_GET['title']));
        $adddata['didian']   = strip_tags(zm_diconv($_GET['didian']));
        $adddata['isniming'] = intval($_GET['isniming']);
        $adddata['content']  = zm_diconv($_GET['content']);
if(IN_WECHAT){

    if (!empty($_GET['fileup'])) {
        foreach ($_GET['fileup'] as $key => $file) {

                $picontent .= '
<p>
    <img src="' . $file . '" alt="" /> 
</p>';


        }

    }

}else if(IN_MAGAPP){

    if (!empty($_GET['fileup'])) {
        foreach ($_GET['fileup'] as $key => $file) {

                $picontent .= '
<p>
    <img src="' . $file . '" alt="" /> 
</p>';


        }

    }

}else{

        if (!empty($_GET['fileup'])) {
            foreach ($_GET['fileup'] as $key => $file) {
                $file = str_replace('data:image/png;base64,', '', $file);
                $file = str_replace('data:image/jpeg;base64,', '', $file);
                $picurl . $key = savebasepic($file);
if($zmbaoliao['is_watermark']){
           if (file_exists(dirname(__FILE__). $picurl . $key)) {
                    $image->Watermark(dirname(__FILE__). $picurl . $key, '', 'forum');
                }
}

                $picontent .= '
<p>
    <img src="source/plugin/zimucms_baoliao/' . $picurl . $key . '" alt="" /> 
</p>';
            }
        }

}

        $adddata['content'] = $adddata['content'] . '
<p>

</p>' . $picontent;

if($_GET['sss']){
    $adddata['video']     = strip_tags($_GET['sss']);    
}
        $adddata['uid']     = intval($_G['uid']);
        $adddata['status']  = 1;
        $adddata['addtime'] = $_G['timestamp'];
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
            $adddata['leixing'] = 2;
        } else {
            $adddata['leixing'] = 1;
        }
        $adddata['fidvalue']      = intval($zmbaoliao['forumid']);
        $adddata['typeidvalue']      = intval($zmbaoliao['typeidvalue']);
        $adddata['jiangli_score'] = intval($zmbaoliao['scorevalue']);
        $adddata['lianxitel']     = strip_tags(zm_diconv($_GET['lianxitel']));
        $result                   = DB::insert('zimucms_baoliao_news', $adddata, true);
        
        if ($result) {

            if ($zmbaoliao['manageuid']) {

                $manageuid = explode(',', $zmbaoliao['manageuid']);
                
                foreach ($manageuid as $key => $value) {

                    if ($adddata['uid'] > 0) {

$context = str_replace('{username}', $_G['username'], lang('plugin/zimucms_baoliao', 'system_notice2'));
if($zmbaoliao['magapp_hostname'] && $zmbaoliao['magapp_secret']){
    $zmbaoliao['assistant_content'] = '{"type":"text","content":"'.$context.'"}';
    $magurl = $zmbaoliao['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $value;
    $magpostdata['type'] = 'text';
    $zmbaoliao['assistant_content'] = str_replace('{username}',$_G['username'],$zmbaoliao['assistant_content']);
    $magpostdata['content'] = diconv($zmbaoliao['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmbaoliao['assistant_secret'];
    $magpostdata['secret'] = $zmbaoliao['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);
}

                        notification_add($value, 'system', lang('plugin/zimucms_baoliao', 'system_notice2', array(
                            'username' => $_G['username']
                            )), array(), 1);
                    } else {
                        notification_add($value, 'system', lang('plugin/zimucms_baoliao', 'system_notice1'), array(), 1);

$context = str_replace('{username}', $_G['username'], lang('plugin/zimucms_baoliao', 'system_notice1'));
if($zmbaoliao['magapp_hostname'] && $zmbaoliao['magapp_secret']){
    $zmbaoliao['assistant_content'] = '{"type":"text","content":"'.$context.'"}';
    $magurl = $zmbaoliao['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $value;
    $magpostdata['type'] = 'text';
    $zmbaoliao['assistant_content'] = str_replace('{username}',$_G['username'],$zmbaoliao['assistant_content']);
    $magpostdata['content'] = diconv($zmbaoliao['assistant_content'],CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $zmbaoliao['assistant_secret'];
    $magpostdata['secret'] = $zmbaoliao['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);
}

                    }

                }

            }
            
            if (!$zmbaoliao['isshenhe_neirong']){
                
                $editid   = $result;
                $newsdata = DB::fetch_first('select * from %t where id=%d', array(
                    'zimucms_baoliao_news',
                    $editid
                ));

                $isuser = DB::fetch_first('select * from %t where uid=%d', array(
                    'zimucms_baoliao_user',
                    $newsdata['uid']
                ));
                
                // ��ʼ��������
                include_once libfile('function/forum');
                include_once libfile('function/post');
                include_once libfile('function/stat');

                if ($newsdata['uid'] == 0) {
                    $uid    = intval($zmbaoliao['nouid']);
                    $member = getuserbyuid($uid, 1);
                } else {
                    if ($newsdata['isniming'] == 1) {
                        $uid    = intval($zmbaoliao['nouid']);
                        $member = getuserbyuid($uid, 1);
                    } else {
                        $uid    = intval($newsdata['uid']);
                        $member = getuserbyuid($uid, 1);
                    }
                }
                if ($member) {
                    $newthread = array(
                        'fid' => $newsdata['fidvalue'],
                        'typeid' => $newsdata['typeidvalue'],
                        'author' => $member['username'],
                        'authorid' => $uid,
                        'subject' => $newsdata['title'],
                        'dateline' => TIMESTAMP,
                        'lastpost' => TIMESTAMP,
                        'lastposter' => $member['username']
                    );
                    
                    $tid = C::t('forum_thread')->insert($newthread, true);
                    $newsdata_content = html2bbcode($newsdata['content']);
                    $pid = insertpost(array(
                        'fid' => $newsdata['fidvalue'],
                        'tid' => $tid,
                        'author' => $member['username'],
                        'authorid' => $uid,
                        'subject' => $newsdata['title'],
                        'dateline' => TIMESTAMP,
                        'message' => $newsdata_content,
                        'useip' => '127.0.0.1',
                        'first' => '1'
                    ));
                    
                    if (!isset($_G['cache']['forums'])) {
                        loadcache('forums');
                    }
                    useractionlog($uid, 'tid');
                    C::t('common_member_field_home')->update($uid, array(
                        'recentnote' => $newsdata['title']
                    ));
                    $lastpost = "$tid\t" . $newsdata['title'] . "\t" . TIMESTAMP . "\t$member[username]";
                    C::t('forum_forum')->update($newsdata['fidvalue'], array(
                        'lastpost' => $lastpost
                    ));
                    C::t('forum_forum')->update_forum_counter($newsdata['fidvalue'], 1, 1, 1);
                    if ($_G['cache']['forums'][$newsdata['fidvalue']]['type'] == 'sub') {
                        C::t('forum_forum')->update($_G['cache']['forums'][$newsdata['fidvalue']]['fup'], array(
                            'lastpost' => $lastpost
                        ));
                    }

            // ��������Զ�̸���

                $subdir = date('Ym').'/'.date('d').'/';
                $basedir = 'forum/'.$subdir;
                !is_dir($_G['setting']['attachdir'].$basedir) && dmkdir($_G['setting']['attachdir'].$basedir);
                
                $attachubb = '';
                preg_match_all('/<img src=\"([^<>"]+)\"([^<>]+)>/',$newsdata['content'],$factattachment);
                $fact['attachment'] = $factattachment[1];
                foreach($fact['attachment'] as $key => $url) {
                    $content = dfsockopen($_G['siteurl'].'/'.$url);
                    if(!$content) {
                        continue;
                    }
                    $filename = date('His').strtolower(random(16)).'.jpg';
                    $rtn = file_put_contents($_G['setting']['attachdir'].$basedir.$filename, $content);
                    if(!$rtn) {
                        continue;
                    }
                    
                    $aid = C::t('forum_attachment')->insert(array('tid' => $tid, 'pid' => $pid, 'uid' => $uid, 'tableid' => getattachtableid($tid)), true);
                    $filesize = filesize($_G['setting']['attachdir'].$basedir.$filename);
                    $thumb = $width = 0;
                    if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                        $image = new image();
                        $thumb = $image->Thumb($_G['setting']['attachdir'].$basedir.$filename, '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                        $width = $image->imginfo['width'];
                        $filesize = $image->imginfo['size'];
                    }
                    if($_G['setting']['thumbstatus']) {
                        $image = new image();
                        $thumb = $image->Thumb($_G['setting']['attachdir'].$basedir.$filename, '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                        $width = $image->imginfo['width'];
                    }
                    if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                        list($width) = @getimagesize($_G['setting']['attachdir'].$basedir.$filename);
                    }
                    if($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
                        $image = new image();
                        $image->Watermark($_G['setting']['attachdir'].$basedir.$filename, '', 'forum'); 
                        $filesize = $image->imginfo['size'];
                    }

                    $insert = array(
                        'aid' => $aid,
                        'tid' => $tid,
                        'pid' => $pid,
                        'dateline' => $_G['timestamp'],
                        'filename' => $filename,
                        'filesize' => $filesize,
                        'attachment' => $subdir.$filename,
                        'isimage' => 1,
                        'uid' => $uid,
                        'thumb' => $thumb,
                        'remote' => 0,
                        'width' => $width,
                    );
                    
                    C::t('forum_attachment_n')->insert('tid:'.$tid, $insert, false, true);
                    $attachubb = "\n[attach]".$aid.'[/attach]'; 
                    $attachment = 2;
                $newsdata_content = str_replace(html2bbcode($factattachment[0][$key]), $attachubb, $newsdata_content);

                }
                C::t('forum_thread')->update($tid, array('attachment' => $attachment));
                C::t('forum_post')->update(0, $pid, array('message' => $newsdata_content, 'attachment' => $attachment));
                
                    //��ʼ�����Զ������ݿ⡣                
                    if ($tid) {
                        //�ж��Ƿ����Ӷ������
                        if ($zmbaoliao['scorevalue'] > 0 && $newsdata['uid'] > 0) {
                            updatemembercount($newsdata['uid'], array(
                                'extcredits' . $zmbaoliao['scoretype'] => $newsdata['jiangli_score']
                            ), true, '', 0, '');
                        }
                        $editdata['baoliaourl'] = $tid;
                        $editdata['status']     = 2;
                        $result                 = DB::update('zimucms_baoliao_news', $editdata, array(
                            'id' => $editid
                        ));
                    }
                }
            }
            
            
            include template('zimucms_baoliao:index/chenggong');
        } else {
            include template('zimucms_baoliao:index/shibai');
        }
        
        
    } else {
        
        $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
            'zimucms_baoliao_user',
            $_G['uid']
        ));

    $isyanzheng = DB::result_first('select id from %t where mobile=%s and status=1 order by id desc', array(
        'zimucms_baoliao_mobilecode',
        $userinfo['tel']
    ));


        include template('zimucms_baoliao:index/addbaoliao');
    }
    
    //�û�����
} else if ($model == 'tixian') {
    
    $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));
    //if(!$ZIMUCMS_MYUSER){exit();}
    if ($zmbaoliao['isopenhb'] && IN_WECHAT) {
        
        if (!$userinfo['openid']) {
            zm_wechat_auth();
        }
        
    }
    include template('zimucms_baoliao:index/tixian');
    
    //�û�����post
} else if ($model == 'tixianingweixin') {
    
    
    $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));
    
    if ($_GET['formhash'] == formhash()) {
        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = $_G['username'];
        $adddata['pay']      = intval($_GET['pay']);
        $adddata['payment']  = intval($_GET['payment']);
        $adddata['account']  = strip_tags(zm_diconv($_GET['account']));
        $adddata['realname'] = strip_tags(zm_diconv($_GET['realname']));
        $adddata['status']   = 1;
        $adddata['addtime']  = time();
        
        if ($adddata['pay'] < $zmbaoliao['mintixian']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#26368;&#23569;&#25552;&#29616;&#37329;&#39069;&#20026;' . $zmbaoliao['mintixian'] . '&#20803;'
            ));
            exit();
        }
        if ($adddata['pay'] > $userinfo['credits']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#25552;&#29616;&#37329;&#39069;&#36229;&#20986;&#29992;&#25143;&#20313;&#39069;'
            ));
            exit();
        }
        
        if (!$userinfo['openid']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#20320;&#36824;&#27809;&#26377;&#32465;&#23450;&#24494;&#20449;&#65292;&#22312;&#24494;&#20449;&#37324;&#25171;&#24320;&#35797;&#35797;&#21543;'
            ));
            exit();
        }
        
        
        $activity['nick_name']    = $_G['setting']['sitename'];
        $activity['send_name']    = $_G['setting']['sitename'];
        $activity['total_amount'] = $adddata['pay'] * 100;
        $activity['wishing']      = $_G['setting']['sitename'];
        $activity['act_name']     = $zmbaoliao['plugintitle'];
        $activity['remark']       = 'zimucms_baoliao';
        
        require_once DISCUZ_ROOT . '/source/plugin/zimucms_baoliao/class/wxred.class.php';
        $send        = new plugin_zimucms_baoliao();
        $send_status = @$send->send_wxred($activity, $userinfo['openid']);
        
        if ($send_status == 1) {
            DB::query("update %t set credits=credits-%d where uid=%d", array(
                'zimucms_baoliao_user',
                $adddata['pay'],
                intval($_G['uid'])
            ));
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#24685;&#21916;&#24744;&#25552;&#29616;&#25104;&#21151;&#65292;&#25105;&#20204;&#23558;&#23613;&#24555;&#22788;&#29702;'
            ));
        } else {
            echo urldecode(json_encode(array(
                'status' => 0,
                'errMsg' => urlencode($send_status)
            )));
        }
    }

} else if ($model == 'tixianingqf' && $_GET['formhash'] == formhash()) {

    $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));

        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = $_G['username'];
        $adddata['pay']      = intval($_GET['pay']);
        $adddata['payment']  = 3;
        $adddata['account']  = strip_tags(zm_diconv($_GET['account']));
        $adddata['realname'] = strip_tags(zm_diconv($_GET['realname']));
        $adddata['status']   = 2;
        $adddata['addtime']  = time();
        
        if ($adddata['pay'] < $zmbaoliao['mintixian']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#26368;&#23569;&#25552;&#29616;&#37329;&#39069;&#20026;' . $zmbaoliao['mintixian'] . '&#20803;'
            ));
            exit();
        }
        if ($adddata['pay'] > $userinfo['credits']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#25552;&#29616;&#37329;&#39069;&#36229;&#20986;&#29992;&#25143;&#20313;&#39069;'
            ));
            exit();
        }

    $nonce  = qf_nonce();
    $secret = $zmbaoliao['qf_secret'];
    
    $data = array(
        'uid' => $_G['uid'],
        'type' => $zmbaoliao['qf_type'],
        'amount' => $adddata['pay']*100,
        'nonce' => $nonce
    );
    
    $data['sign'] = qf_sign($data, $secret);
    
    $qfurl = 'http://' . $zmbaoliao['qf_hostname'] . '.qianfanapi.com/api1_2/balance/add';
    $qfdata = lizimu_post($qfurl,$data);
    $retqf = json_decode($qfdata, true);
        if($retqf['ret']==0){
        $adddata['mch_billno']  = $retqf['data']['record_id'];
        DB::insert('zimucms_baoliao_tixian', $adddata);
            DB::query("update %t set credits=credits-%d where uid=%d", array(
                'zimucms_baoliao_user',
                $adddata['pay'],
                $_G['uid']
                ));
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#24685;&#21916;&#24744;&#25552;&#29616;&#25104;&#21151;&#65292;&#25105;&#20204;&#23558;&#23613;&#24555;&#22788;&#29702;'
                ));
        } else {
            echo urldecode(json_encode(array(
                'status' => 0,
                'errMsg' => urlencode(mb_convert_encoding($retqf['text'], CHARSET, 'UTF-8'))
                )));

        }

} else if ($model == 'tixianingmag' && $_GET['formhash'] == formhash()) {

    $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));

        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = $_G['username'];
        $adddata['pay']      = intval($_GET['pay']);
        $adddata['payment']  = 3;
        $adddata['account']  = strip_tags(zm_diconv($_GET['account']));
        $adddata['realname'] = strip_tags(zm_diconv($_GET['realname']));
        $adddata['status']   = 2;
        $adddata['addtime']  = time();
        
        if ($adddata['pay'] < $zmbaoliao['mintixian']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#26368;&#23569;&#25552;&#29616;&#37329;&#39069;&#20026;' . $zmbaoliao['mintixian'] . '&#20803;'
            ));
            exit();
        }
        if ($adddata['pay'] > $userinfo['credits']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#25552;&#29616;&#37329;&#39069;&#36229;&#20986;&#29992;&#25143;&#20313;&#39069;'
            ));
            exit();
        }

    $order_id = 'APP' . date('Ymd') . time();

    $urls = $zmbaoliao['magapp_hostname'].'/core/pay/pay/accountTransfer?&user_id='.$_G['uid'].'&amount='.$adddata['pay'].'&remark=baoliao&out_trade_code='.$order_id.'&secret='.$zmbaoliao['magapp_secret'];
    $r = dfsockopen($urls);

    $r =  json_decode($r, true);
    if(!intval($r['success'])){

            echo urldecode(json_encode(array(
                'status' => 0,
                'errMsg' => urlencode(mb_convert_encoding($r['msg'], CHARSET, 'UTF-8'))
                )));

    }else{

        DB::insert('zimucms_baoliao_tixian', $adddata);
            DB::query("update %t set credits=credits-%d where uid=%d", array(
                'zimucms_baoliao_user',
                $adddata['pay'],
                $_G['uid']
                ));
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#24685;&#21916;&#24744;&#25552;&#29616;&#25104;&#21151;&#65292;&#25105;&#20204;&#23558;&#23613;&#24555;&#22788;&#29702;'
                ));

    }

} else if ($model == 'tixianing') {
    $userinfo = DB::fetch_first('select * from %t where uid= %d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));
    //if(!$ZIMUCMS_MYUSER){exit();}
    if ($_GET['formhash'] == formhash()) {
        
        $adddata['uid']      = intval($_G['uid']);
        $adddata['username'] = $_G['username'];
        $adddata['pay']      = intval($_GET['pay']);
        $adddata['payment']  = intval($_GET['payment']);
        $adddata['account']  = strip_tags(zm_diconv($_GET['account']));
        $adddata['realname'] = strip_tags(zm_diconv($_GET['realname']));
        $adddata['status']   = 1;
        $adddata['addtime']  = time();
        
        if ($adddata['pay'] < $zmbaoliao['mintixian']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#26368;&#23569;&#25552;&#29616;&#37329;&#39069;&#20026;' . $zmbaoliao['mintixian'] . '&#20803;'
            ));
            exit();
        }
        if ($adddata['pay'] > $userinfo['credits']) {
            echo json_encode(array(
                'status' => 0,
                'errMsg' => '&#25552;&#29616;&#37329;&#39069;&#36229;&#20986;&#29992;&#25143;&#20313;&#39069;'
            ));
            exit();
        }
        $result = DB::insert('zimucms_baoliao_tixian', $adddata);
        if ($result) {
            DB::query("update %t set credits=credits-%d where uid=%d", array(
                'zimucms_baoliao_user',
                $adddata['pay'],
                intval($_G['uid'])
            ));
            echo json_encode(array(
                'status' => 1,
                'errMsg' => '&#24685;&#21916;&#24744;&#25552;&#29616;&#25104;&#21151;&#65292;&#25105;&#20204;&#23558;&#23613;&#24555;&#22788;&#29702;'
            ));
        }
        
        
    }
    //�ҵı�������
} else if ($model == 'mybaoliao') {
    
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page  = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t where uid= %d", array(
        "zimucms_baoliao_news",
        $_G['uid']
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $newsdata = DB::fetch_all('select * from %t where uid= %d order by id desc limit %d,%d', array(
        'zimucms_baoliao_news',
        $_G['uid'],
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, $_G['siteurl'] . "plugin.php?id=zimucms_baoliao&model=mybaoliao", '100', '100', TRUE, TRUE);
    }
    include template('zimucms_baoliao:index/mybaoliao');
    
    
    //������¼
} else if ($model == 'newslist') {
    
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page  = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t where status=2", array(
        "zimucms_baoliao_news"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $newsdata = DB::fetch_all('select * from %t where status=2 order by id desc limit %d,%d', array(
        'zimucms_baoliao_news',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, $_G['siteurl'] . "plugin.php?id=zimucms_baoliao&model=newslist", '100', '100', TRUE, TRUE);
    }
    include template('zimucms_baoliao:index/newslist');
    
    
    //�Ƹ���
} else if ($model == 'ranklist') {
    
    $page  = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page  = intval($page);
    $count = DB::result_first("SELECT count(*) FROM %t where allcredits>0", array(
        "zimucms_baoliao_user"
    ));
    
    $limit    = 20;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    $rankdata = DB::fetch_all('select * from %t where allcredits>0 order by allcredits desc limit %d,%d', array(
        'zimucms_baoliao_user',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, $_G['siteurl'] . "plugin.php?id=zimucms_baoliao&model=ranklist", '100', '100', TRUE, TRUE);
    }
    include template('zimucms_baoliao:index/ranklist');
    
} else if ($model == 'getclass') {
    $fid   = intval($_GET['fidvalue']);
    $class = C::t('forum_threadclass')->fetch_all_by_fid($fid);
    
    foreach ($class as $key => $value) {
        $class[$key]['name'] = urlencode($value['name']);
    }
    $classdata = json_encode($class);
    echo urldecode($classdata);

} else if ($model == 'getcode' && $_GET['md5formhash'] == formhash()) {

    $mobile = addslashes($_GET['mobile']);    
    
    $adddata['code'] = mt_rand(1000, 9999);
    //if(!$ZIMUCMS_MYUSER){exit();}
    $smsdata['code']    = "" . $adddata['code'] . "";
if($zmbaoliao['is_product']==1){
    $smsdata['product'] = "" . mb_convert_encoding($zmbaoliao['name'], 'UTF-8', CHARSET) . "";
}
if($zmbaoliao['sms_type']==1){
    $aaa                = sms_send($mobile, $smsdata, $zmbaoliao['template_code']);
}else if($zmbaoliao['sms_type']==2){
    $aaa                = aliyun_sms_send($mobile, $smsdata, $zmbaoliao['template_code']);
}

    $aaa = object_array(json_decode($aaa));

    if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['Code'] == 'OK') {
        
        $adddata['mobile']  = $mobile;
        $adddata['addtime'] = $_G['timestamp'];
        $result             = DB::insert('zimucms_baoliao_mobilecode', $adddata);
        $out['status']      = 200;
        echo $result             = json_encode($out);
        exit();
        
    } else {
        $out['status'] = 2;
if($zmbaoliao['sms_type']==1){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
}else if($zmbaoliao['sms_type']==2){
        $out['errmsg'] = urlencode(mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
}
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }

} else if ($model == 'uploader') {

    include_once(DISCUZ_ROOT.'source/plugin/zimucms_baoliao/model/c_uploader.php');
    exit();

} else if ($model == 'upload_video') {

    include_once(DISCUZ_ROOT.'source/plugin/zimucms_baoliao/model/c_upload_video.php');
    exit();
    
} else {
    
    $isuser = DB::fetch_first('select * from %t where uid=%d', array(
        'zimucms_baoliao_user',
        $_G['uid']
    ));
    
    include template('zimucms_baoliao:index/index');
    
}



function savebasepic($post)
{
    if (!file_exists(dirname(__FILE__) . '/uploads/' . date("Ymd"))) {
        mkdir(dirname(__FILE__) . '/uploads/' . date("Ymd"));
    }
    $picname = '/uploads/' . date("Ymd") . '/' . time() . rand(100, 999) . '.jpg';
    $file    = dirname(__FILE__) . $picname;
    $base64  = base64_decode($post);
    $save    = file_put_contents($file, $base64);
    if ($save) {
        return $picname;
    }
}