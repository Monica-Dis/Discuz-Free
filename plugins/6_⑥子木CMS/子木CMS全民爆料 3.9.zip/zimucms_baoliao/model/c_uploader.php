<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function resizeImage($fromfile ,$maxwidth,$maxheight, $name, $filetype)
{
    if(!function_exists('imagejpeg')){
        return false;
    }

    $imagefunc = 'imagejpeg';
    $imagecreatefromfunc = 'imagecreatefromjpeg';
    switch($filetype) {
        case 'image/jpeg':
            $imagecreatefromfunc = function_exists('imagecreatefromjpeg') ? 'imagecreatefromjpeg' : '';
            $imagefunc = function_exists('imagejpeg') ? 'imagejpeg' : '';
            break;
        case 'image/gif':
            $imagecreatefromfunc = function_exists('imagecreatefromgif') ? 'imagecreatefromgif' : '';
            $imagefunc = function_exists('imagegif') ? 'imagegif' : '';
            break;
        case 'image/png':
            $imagecreatefromfunc = function_exists('imagecreatefrompng') ? 'imagecreatefrompng' : '';
            $imagefunc = function_exists('imagepng') ? 'imagepng' : '';
            break;
    }

    $im = $imagecreatefromfunc($fromfile);
    $pic_width = imagesx($im);
    $pic_height = imagesy($im);

    if(($maxwidth && $pic_width > $maxwidth) || ($maxheight && $pic_height > $maxheight))
    {
        if($maxwidth && $pic_width>$maxwidth)
        {
            $widthratio = $maxwidth/$pic_width;
            $resizewidth_tag = true;
        }
        if($maxheight && $pic_height>$maxheight)
        {
            $heightratio = $maxheight/$pic_height;
            $resizeheight_tag = true;
        }
        if($resizewidth_tag && $resizeheight_tag)
        {
            if($widthratio<$heightratio)
                $ratio = $widthratio;
            else
                $ratio = $heightratio;
        }
        if($resizewidth_tag && !$resizeheight_tag)
            $ratio = $widthratio;
        if($resizeheight_tag && !$resizewidth_tag)
            $ratio = $heightratio;
        $newwidth = $pic_width * $ratio;
        $newheight = $pic_height * $ratio;
        if(function_exists("imagecopyresampled"))
        {
            $newim = imagecreatetruecolor($newwidth,$newheight);
            imagecopyresampled($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }
        else
        {
            $newim = imagecreate($newwidth,$newheight);
            imagecopyresized($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }

        $imagefunc($newim, $name);
        imagedestroy($newim);
    }
    else
    {
        $imagefunc($im,$name);
    }
    @unlink($fromfile);
    return $name;
}

if($_GET['do']=='download'){

    global $_G;

    $sids = $_GET['serverId'];
    if(!$sids){
        echo 'serverId empty';exit();
    }
    $appid      = trim($zmbaoliao['weixin_appid']);
    $appsecret  = trim($zmbaoliao['weixin_appsecret']);
    $timestamp  = TIMESTAMP;
    $noncestr   = uniqid('wx');
    $currenturl = '';
    $accesstoken = $wechat_client->getAccessToken(1,1);

    $ischeck = httpGet('https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token='.$accesstoken);
    $ischeck = json_decode($ischeck,true);
    if($ischeck['errcode'] == 40001){
        $accesstoken = $wechat_client->getAccessToken_new(1,1);
    }


    $temp = $ret = array();

    foreach ($sids as $sid) {
        $temp[] = "https://api.weixin.qq.com/cgi-bin/media/get?access_token=$accesstoken&media_id=$sid";
    }
    if(is_array($temp) && !empty($temp)) {
        foreach ($temp as $imageurl) {
            $content = '';
            if (preg_match('/^(https:\/\/|\.)/i', $imageurl)) {
                $content = httpGet($imageurl);
            }
            if (empty($content)) continue;

            $filena = uniqid('wx').'.jpg';
            $ditr = '';
            dmkdir(DISCUZ_ROOT.'source/plugin/zimucms_baoliao/uploads/'.$ditr);
            $saved_file = DISCUZ_ROOT.'source/plugin/zimucms_baoliao/uploads/'.$ditr.$filena;

            if (!@$fp = fopen($saved_file, 'wb')) {
                continue;
            } else {
                flock($fp, 2);
                fwrite($fp, $content);
                fclose($fp);
            }
            $imgurl = $_G['siteurl'] .'source/plugin/zimucms_baoliao/uploads/'.$ditr.$filena;
            if(resizeImage($saved_file, 800, 1200, $saved_file.'.jpg', 'image/jpeg')){
                $imgurl = $_G['siteurl'] .'source/plugin/zimucms_baoliao/uploads/'.$ditr.$filena.'.jpg';
                $saved_file = $saved_file.'.jpg';
            }

            global $_G;
            if($_G['setting']['watermarkstatus'] && $zmbaoliao['is_watermark']) {
                include_once libfile('class/image');
                $image = new image();
                $image->Watermark($saved_file, '', 'forum');
            }
            $ret[] = str_replace($_G['siteurl'],'',$imgurl);
        }
    }

    if($ret){
        print_r($ret[0]);
    }
    exit;
}