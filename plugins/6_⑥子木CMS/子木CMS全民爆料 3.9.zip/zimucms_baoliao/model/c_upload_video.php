<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
 
function uploader_video($files){

$path = DISCUZ_ROOT.'source/plugin/zimucms_baoliao/uploads/video';
$imagesExt = array('jpg','png','jpeg','mov','mp4','3gp');


    // 判断错误号
    if (@$files['error'] == 00) {
        // 判断文件类型
        $ext = strtolower(pathinfo(@$files['name'],PATHINFO_EXTENSION));
        if (!in_array($ext,$imagesExt)){
        $out['code'] = 201;
        $out['err']  = 'type error 1';
        echo $result      = json_encode($out);
        exit();
        }
        // 判断是否存在上传到的目录
        if (!is_dir($path)){
            mkdir($path,0777,true);
        }
        // 生成唯一的文件名
        $fileName = md5(uniqid(microtime(true),true)).'.'.$ext;
        // 将文件名拼接到指定的目录下
        $destName = $path."/".$fileName;
        // 进行文件移动
        if (!move_uploaded_file($files['tmp_name'],$destName)){
        $out['code'] = 201;
        $out['err']  = 'type error 2';
        echo $result      = json_encode($out);
        exit();
        }

        $out['code'] = 200;
        $out['err']  = "source/plugin/zimucms_baoliao/uploads/video/".$fileName;
        echo $result      = json_encode($out);
        exit();
    } else {
        // 根据错误号返回提示信息
        switch (@$files['error']) {
            case 1:
        $out['code'] = 201;
        $out['err']  = 'php.ini upload_max_filesize';
        echo $result      = json_encode($out);
        exit();
                break;
            case 2:
        $out['code'] = 201;
        $out['err']  = 'HTML MAX_FILE_SIZE';
        echo $result      = json_encode($out);
        exit();
                break;
            case 3:
        $out['code'] = 201;
        $out['err']  = '33';
        echo $result      = json_encode($out);
        exit();
                break;
            case 4:
        $out['code'] = 201;
        $out['err']  = '44';
        echo $result      = json_encode($out);
        exit();
                break;
            case 6:
            case 7:
        $out['code'] = 201;
        $out['err']  = '55';
        echo $result      = json_encode($out);
        exit();
                break;
        }
    }
}

$upfile = $_FILES['file'];
if($upfile['size'] > 10485760){
        $out['code'] = 201;
        $out['err']  = 'video too big';
        echo $result      = json_encode($out);
        exit();
}
echo uploader_video($upfile);exit();