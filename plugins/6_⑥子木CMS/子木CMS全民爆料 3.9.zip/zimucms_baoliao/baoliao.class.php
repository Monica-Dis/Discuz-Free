<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_zimucms_baoliao
{
}

class plugin_zimucms_baoliao_forum extends plugin_zimucms_baoliao
{
    
    
    public function forumdisplay_thread_subject_output()
    {
        $res = array();
        global $_G;
        foreach ($_G['forum_threadlist'] as $key => $thread) {
            $userinfo = DB::result_first('select leixing from %t where baoliaourl=%d', array(
                'zimucms_baoliao_news',
                $thread['tid']
            ));
            if ($userinfo) {
                if ($userinfo == 3) {
                    $res[$key] = '<img align="absmiddle" src="' . $_G['siteurl'] . '/source/plugin/zimucms_baoliao/static/exclue.png">';
                } else if ($userinfo == 2) {
                    $res[$key] = '<img align="absmiddle" src="' . $_G['siteurl'] . '/source/plugin/zimucms_baoliao/static/wx_clue.png">';
                } else {
                    $res[$key] = '<img align="absmiddle" src="' . $_G['siteurl'] . '/source/plugin/zimucms_baoliao/static/clue.gif">';
                }
                
            }
        }
        return $res;
    }
    
    
    
    function viewthread_posttop_output()
    {
        global $_G;
        
        $userinfo = DB::fetch_first('select * from %t where baoliaourl=%d', array(
            'zimucms_baoliao_news',
            $_G['tid']
        ));
        if ($userinfo) {
            $html[] = '<div style="height:10px"></div><fieldset style="font-size: 14px; display:block; margin-bottom: 20px;border: 1px dashed rgb(0, 213, 255);padding-right: 10px;padding-left: 10px;">
<legend style="font-weight: bold;padding: 0 5px;">&#29190;&#26009;&#20449;&#24687;&#65306;' . $userinfo['title'] . '</legend>
<ul style="padding:5px 20px;">
<li style="color:#000;line-height:24px;"><strong>&#26102;&#38388;&#65306;</strong>' . date('Y-m-d H:i:s', $userinfo['addtime']) . '</li>
<li style="color:#000;line-height:24px;"><strong>&#22320;&#28857;&#65306;</strong>' . $userinfo['didian'] . '</li>
</ul>
</fieldset>';
            return $html;
        }
    }
    
    
    function viewthread_title_row_output()
    {
        global $_G;
        
        $userinfo = DB::fetch_first('select * from %t where baoliaourl=%d', array(
            'zimucms_baoliao_news',
            $_G['tid']
        ));
        if ($userinfo) {
if($userinfo['jiangli']){
            $html = '<a style="text-decoration: none;" href="' . $_G['cache']['plugin']['zimucms_baoliao']['baoliaourl'] . '" target="_blank"><p class="good_post_tip" style="background: #faf8e7;border-bottom: #e7e4ba 1px solid;color: #79502f;font-size: 14px;line-height: 35px;height: 35px;padding-left: 18px;">&#26412;&#24086;&#30001;&#32593;&#21451;&#20110; ' . date('Y-m-d', $userinfo['addtime']) . ' &#25104;&#21151;&#29190;&#26009;&#65281;&#22870;&#21169;&#29616;&#37329;&#32418;&#21253; ' . $userinfo['jiangli'] . ' &#20803; '.$userinfo['jiangli_score'].' '.$_G['setting']['extcredits'][$_G['cache']['plugin']['zimucms_baoliao']['scoretype']]['title'].'</p></a>';
}else{
            $html = '<a style="text-decoration: none;" href="' . $_G['cache']['plugin']['zimucms_baoliao']['baoliaourl'] . '" target="_blank"><p class="good_post_tip" style="background: #faf8e7;border-bottom: #e7e4ba 1px solid;color: #79502f;font-size: 14px;line-height: 35px;height: 35px;padding-left: 18px;">&#26412;&#24086;&#30001;&#32593;&#21451;&#20110; ' . date('Y-m-d', $userinfo['addtime']) . ' &#25104;&#21151;&#29190;&#26009;&#65281;&#22870;&#21169; '.$userinfo['jiangli_score'].' '.$_G['setting']['extcredits'][$_G['cache']['plugin']['zimucms_baoliao']['scoretype']]['title'].'</p></a>';    
}

            return $html;
        }
    }
}




class mobileplugin_zimucms_baoliao
{
}

class mobileplugin_zimucms_baoliao_forum extends mobileplugin_zimucms_baoliao
{      

    function viewthread_posttop_mobile_output()
    {
        global $_G;
        
        $userinfo = DB::fetch_first('select * from %t where baoliaourl=%d', array(
            'zimucms_baoliao_news',
            $_G['tid']
        ));
        if ($userinfo) {
            $html[] = '<div style="height:10px"></div><fieldset style="font-size: 14px; display:block; margin-bottom: 20px;border: 1px dashed rgb(0, 213, 255);padding-right: 10px;padding-left: 10px;">
<legend style="font-weight: bold;padding: 0 5px;">&#29190;&#26009;&#20449;&#24687;&#65306;' . $userinfo['title'] . '</legend>
<ul style="padding:5px 20px;">
<li style="color:#000;line-height:24px;"><strong>&#26102;&#38388;&#65306;</strong>' . date('Y-m-d H:i:s', $userinfo['addtime']) . '</li>
<li style="color:#000;line-height:24px;"><strong>&#22320;&#28857;&#65306;</strong>' . $userinfo['didian'] . '</li>
</ul>
</fieldset>';
            return $html;
        }
    }
    
    
    function viewthread_top_mobile_output()
    {
        global $_G;
        
        $userinfo = DB::fetch_first('select * from %t where baoliaourl=%d', array(
            'zimucms_baoliao_news',
            $_G['tid']
        ));
        if ($userinfo) {
if($userinfo['jiangli']){
            $html = '<a style="text-decoration: none;" href="' . $_G['cache']['plugin']['zimucms_baoliao']['baoliaourl'] . '" target="_blank"><p class="good_post_tip" style="background: #faf8e7;border-bottom: #e7e4ba 1px solid;color: #79502f;font-size: 14px;line-height: 35px;padding:0 18px;">&#26412;&#24086;&#30001;&#32593;&#21451;&#20110; ' . date('Y-m-d', $userinfo['addtime']) . ' &#25104;&#21151;&#29190;&#26009;&#65281;&#22870;&#21169;&#29616;&#37329;&#32418;&#21253; ' . $userinfo['jiangli'] . ' &#20803; '.$userinfo['jiangli_score'].' '.$_G['setting']['extcredits'][$_G['cache']['plugin']['zimucms_baoliao']['scoretype']]['title'].'</p></a>';
}else{
            $html = '<a style="text-decoration: none;" href="' . $_G['cache']['plugin']['zimucms_baoliao']['baoliaourl'] . '" target="_blank"><p class="good_post_tip" style="background: #faf8e7;border-bottom: #e7e4ba 1px solid;color: #79502f;font-size: 14px;line-height: 35px;height: 35px;padding-left: 18px;">&#26412;&#24086;&#30001;&#32593;&#21451;&#20110; ' . date('Y-m-d', $userinfo['addtime']) . ' &#25104;&#21151;&#29190;&#26009;&#65281;&#22870;&#21169; '.$userinfo['jiangli_score'].' '.$_G['setting']['extcredits'][$_G['cache']['plugin']['zimucms_baoliao']['scoretype']]['title'].'</p></a>';    
}
            return $html;
        }
    }
}