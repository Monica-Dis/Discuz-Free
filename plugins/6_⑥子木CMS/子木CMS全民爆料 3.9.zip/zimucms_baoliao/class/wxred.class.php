<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zimucms_baoliao {	

	function plugin_zimucms_baoliao() {
		global $_G;	
	}
	
	function send_wxred($activity, $re_openid) {
		global $_G;
		require_once  DISCUZ_ROOT.'/source/plugin/zimucms_baoliao/class/wxRedApi.class.php';
		$mch_billno = MCHID.date('Ymd').time();
		$redCall = new RedCall();
		$redCall->setParameter("mch_billno", $mch_billno);
		$redCall->setParameter("nick_name", diconv($activity['nick_name'], CHARSET, 'UTF8'));
		$redCall->setParameter("send_name", diconv($activity['send_name'], CHARSET, 'UTF8'));
		$redCall->setParameter("re_openid", $re_openid);
		$redCall->setParameter("total_amount", $activity['total_amount']);
		$redCall->setParameter("min_value", $activity['total_amount']);
		$redCall->setParameter("max_value", $activity['total_amount']);
		$redCall->setParameter("total_num",1);
		$redCall->setParameter("wishing", diconv($activity['wishing'], CHARSET, 'UTF8'));
		$redCall->setParameter("act_name", diconv($activity['act_name'], CHARSET, 'UTF8'));
		$redCall->setParameter("remark", diconv($activity['remark'], CHARSET, 'UTF8'));
		@$redCallResult = $redCall->getResult();
		$setarr = array(
			'username' => $_G['username'],
			'uid' => $_G['uid'],
			'pay' => $activity['total_amount']/100,
			'payment' => '1',
			'addtime' => time(),
			'mch_billno' => $mch_billno,
			'send_listid' => $redCallResult['send_listid'],
			'return_msg' => diconv($redCallResult['return_msg'], 'UTF8', CHARSET),		
		);
		
		if($redCallResult["result_code"] == "SUCCESS") {
			$setarr['status'] = 2;
		DB::insert('zimucms_baoliao_tixian', $setarr);		
		}		
		if($setarr['status'] == 2) {
			return 1;
		} else {
			return diconv($redCallResult['return_msg'], 'UTF8', CHARSET);
		}
	}	
}
//From: Dism��taobao-com
?>