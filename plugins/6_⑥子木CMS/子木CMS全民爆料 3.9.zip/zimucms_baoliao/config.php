<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimucms_baoliao/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimucms_baoliao');

include $includefile;


loadcache('plugin');
//插件目录常量
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_APP', strpos($_SERVER['HTTP_USER_AGENT'],$_G['cache']['plugin']['zimucms_baoliao']['app_user_agent']) !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
$SELF = $_SERVER["PHP_SELF"];
$zmbaoliao = $_G['cache']['plugin']['zimucms_baoliao'];
if(IN_APP || IN_WECHAT){
$zmbaoliao['showheader'] = 0;
}
$formhash = $_G['formhash'];


if($_G['charset']=='gbk'){
	$charset = 'gbk';
}
elseif($_G['charset']=='utf-8'){
	$charset = 'UTF-8';
}
elseif($_G['charset']=='big5'){
	$charset = 'big5';
}

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_baoliao/');
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_baoliao');

$formhash = $_G['formhash'];

function zm_wechat_auth()
{
    global $_G;

    if (!$_G['cache']['plugin']['zimucms_baoliao']['isopenhb'] || !IN_WECHAT) {
        return;
    }

$zmdata = $_G['cache']['plugin']['zimucms_baoliao'];

$wechat_client2 = new WeChatClient($zmdata['weixin_appid'],$zmdata['weixin_appsecret']);

$code = addslashes($_GET['code']);

if ($code && $_GET['zmwx']==1){
        $token = $wechat_client2->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }

if(!$token['openid']){
$newtoken = $wechat_client2->getAccessToken(1,0);
}else{

if($_G['uid']){
$editdata['openid'] = $token['openid'];
$result = DB::update('zimucms_baoliao_user',$editdata, array('uid' => $_G['uid']));
}
dheader('Location:' . $_G['siteurl'] . '/plugin.php?id=zimucms_baoliao&model=tixian');


}

}else{

$redirect = $_G['siteurl'] . '/plugin.php?id=zimucms_baoliao&model=tixian&zmwx=1';
$redirect_uri = $redirect;

if($_G['cache']['plugin']['zimucms_baoliao']['oauth2_url']){

$login_url = $_G['cache']['plugin']['zimucms_baoliao']['oauth2_url'].'?appid='.$zmdata['weixin_appid'].'&scope=snsapi_base&state='.md5(FORMHASH).'&redirect_uri=' . urlencode($redirect_uri);

}else{

$login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($redirect_uri) . '&response_type=code&scope=snsapi_base&state=' . md5(FORMHASH) . '#wechat_redirect';

}

dheader('Location:' . $login_url);

}



}
$ZIMUCMS_MYUSER = '1';
function zm_diconv($str)
{
    $encode = mb_detect_encoding($str, array(
        "ASCII",
        "UTF-8",
        "GB2312",
        "GBK",
        "BIG5"
    ));
    if ($encode != CHARSET) {
        //$keytitle = iconv($encode,CHARSET."//IGNORE",$str);
        $keytitle = mb_convert_encoding($str, CHARSET, $encode);
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function httpGet($url) {
    
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_TIMEOUT, 500);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_URL, $url);
    
        $res = curl_exec($curl);
        curl_close($curl);
    
        return $res;
    }
function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

function sms_send($mobile, $data, $template_code) 
{ 

global $_G;
$zmbaoliao = $_G['cache']['plugin']['zimucms_baoliao'];
// 基本参数 
$api_url = 'http://gw.api.taobao.com/router/rest'; 
$app_key = $zmbaoliao['appid']; 
$app_secret = $zmbaoliao['secret']; 
$sign_name = mb_convert_encoding($zmbaoliao['name'],'UTF-8',CHARSET); // 短信签名 

// 公共参数 
$params["method"] = 'alibaba.aliqin.fc.sms.num.send'; 
$params["app_key"] = $app_key; 
$params["timestamp"] = date("Y-m-d H:i:s"); 
$params["format"] = 'json'; 
$params["v"] = '2.0'; 
$params["sign_method"] = 'md5'; 

// 请求参数 
$params["sms_type"] = 'normal'; 
$params["sms_free_sign_name"] = $sign_name; 
$params["sms_param"] = json_encode($data); 
$params["rec_num"] = $mobile; 
$params["sms_template_code"] = $template_code; 

// 签名过程 
ksort($params); 
$signed = $app_secret; 

foreach ($params as $key => $value) 
{ 
if(is_string($value) && "@" != substr($value, 0, 1)) 
{ 
$signed .= "$key$value"; 
} 
} 
unset($key, $value); 

$signed .= $app_secret; 
$params["sign"] = strtoupper(md5($signed)); 

// 发送短信 
$result = lizimu_post($api_url, $params); 
return $result; 
}


function aliyun_sms_send($mobile, $data, $template_code){

global $_G;
$zmbaoliao = $_G['cache']['plugin']['zimucms_baoliao'];

$app_key = $zmbaoliao['appid']; 
$app_secret = $zmbaoliao['secret']; 

$sign_name = mb_convert_encoding($zmbaoliao['name'],'UTF-8',CHARSET);

    $requestUrl = "http://dysmsapi.aliyuncs.com/";
    $params['PhoneNumbers']= $mobile;
    $params['SignName']= $sign_name;
    $params['TemplateCode']= $template_code;
    $params['TemplateParam']= json_encode($data);
    $params['OutId']= "3333";
    $params['RegionId']= "cn-hangzhou";
    $params['AccessKeyId']= $app_key;
    $params['Format']= "JSON";
    $params['SignatureMethod']= "HMAC-SHA1";
    $params['SignatureVersion']= "1.0";
    $params['SignatureNonce']= uniqid();
    date_default_timezone_set("GMT");
    $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
    $params['Action']= "SendSms";
    $params['Version']= "2017-05-25";
    $params['Signature']= aliyun_signature($params,$app_secret);

    include_once DISCUZ_ROOT . './source/plugin/zimucms_baoliao/class/Aliyun_HttpHelper.class.php';

    $Aliyun_HttpHelper = new Aliyun_HttpHelper();
    $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));
    return $result;
    
}

//$_statInfo['timestamp'] = TIMESTAMP;
//$_statInfo['SN'] = '{ADDONVAR:SN}';
//$_statInfo['RevisionID'] = '{ADDONVAR:RevisionID}';
//$_statInfo['RevisionDateline'] = '{ADDONVAR:RevisionDateline}';
//$_statInfo['SN'] = '{ADDONVAR:SN}';
//$_statInfo['bbsUrl'] = $_G['siteurl'];
//$_statInfo['SiteUrl'] = '{ADDONVAR:SiteUrl}';
//$_statInfo['ClientUrl'] = '{ADDONVAR:ClientUrl}';
//$_statInfo['SiteID'] = '{ADDONVAR:SiteID}';
//$_statInfo['bbsAdminEMail'] = $_G['setting']['adminemail'];

function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}
function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}
function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}