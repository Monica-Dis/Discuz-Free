<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


        $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
            'zimu_zhaopin_area'
        ), 'id');
        
        foreach ($arealist as $key => $value) {
            
            $arealist[$value['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                'zimu_zhaopin_area',
                $value['id']
            ),'id');            
            
        }
        

include zimu_template('ajax_get_city');

