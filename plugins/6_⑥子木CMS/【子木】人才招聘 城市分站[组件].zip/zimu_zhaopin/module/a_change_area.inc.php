<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!getcookie('citycategory') && getcookie('nocity')!=1){

$host = "https://api01.aliyun.venuscn.com";
    $path = "/ip";
    $method = "GET";
    $appcode = $zmdata['settings']['change_area_api'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "ip=".$_G['clientip'];
    $bodys = "";
    $url = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    $json = curl_exec($curl);
$json_array = json_decode($json,true);

if($json_array['ret']==200){

	$region = zm_diconv($json_array['data']['region']);
	$city = zm_diconv($json_array['data']['city']);
}

$region = str_replace($language_zimu['a_change_area_inc_php_0'], '', $region);
$city = str_replace($language_zimu['a_change_area_inc_php_1'], '', $city);


if($zmdata['settings']['change_area']==1 && $region){

$wheresql=' where name like \'%'.$region.'%\' and parentid=0 ';

$area = DB::fetch_first('select * from %t %i order by id asc', array(
	'zimu_zhaopin_area',
	$wheresql
));

$return_json['code'] = '200';
$return_json['citycategory'] = $area['id'];
$return_json['citycategory_cn'] = $area['name'];
$return_json['citycategory2'] = 0;

}


if($zmdata['settings']['change_area']==2 && $city){

$city = stripsearchkey($city);
$city = daddslashes($city);

$wheresql =' where name like \'%' . $city . '%\' ';

$area = DB::fetch_first('select * from %t %i order by id asc', array(
	'zimu_zhaopin_area',
	$wheresql
));

$area2 = DB::fetch_first('select * from %t where id=%d order by id asc', array(
	'zimu_zhaopin_area',
	$area['parentid']
));


$return_json['code'] = '200';
$return_json['citycategory'] = $area2['id'];
$return_json['citycategory_cn'] = $area2['name'];
$return_json['citycategory2'] = $area['id'];
$return_json['citycategory2_cn'] = $area['name'];

}

dsetcookie('citycategory', $return_json['citycategory'], 864000);
dsetcookie('citycategory_cn', $return_json['citycategory_cn'], 864000);
dsetcookie('citycategory2', $return_json['citycategory2'], 864000);
dsetcookie('citycategory2_cn', $return_json['citycategory2_cn'], 864000);

}
//echo json_encode($return_json);exit();

