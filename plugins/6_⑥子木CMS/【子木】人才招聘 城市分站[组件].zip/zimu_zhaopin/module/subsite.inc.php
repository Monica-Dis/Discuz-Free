<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);


if($op=='changecity'){

$changecity1 = intval($_GET['changecity1']);
$changecity2 = intval($_GET['changecity2']);

if(!$changecity1){

dsetcookie('citycategory', '', -1);
dsetcookie('citycategory_cn', '', -1);
dsetcookie('citycategory2', '', -1);
dsetcookie('citycategory2_cn', '', -1);
dsetcookie('nocity', '1', 86400);

dheader('Location:' . ZIMUCMS_URL);

}

if($changecity2){

$area = DB::fetch_first('select * from %t where id=%d order by id asc', array(
	'zimu_zhaopin_area',
	$changecity2
));

$area2 = DB::fetch_first('select * from %t where id=%d order by id asc', array(
	'zimu_zhaopin_area',
	$area['parentid']
));


dsetcookie('citycategory', $changecity1, 864000);
dsetcookie('citycategory_cn', $area2['name'], 864000);
dsetcookie('citycategory2', $changecity2, 864000);
dsetcookie('citycategory2_cn', $area['name'], 864000);
dsetcookie('nocity', '1', 86400);


dheader('Location:' . ZIMUCMS_URL);


}

if(!$changecity2 && $changecity1){

$area = DB::fetch_first('select * from %t where id=%d order by id asc', array(
	'zimu_zhaopin_area',
	$changecity1
));

dsetcookie('citycategory', $changecity1, 864000);
dsetcookie('citycategory_cn', $area['name'], 864000);
dsetcookie('citycategory2', '', -1);
dsetcookie('citycategory2_cn', '', -1);
dsetcookie('nocity', '1', 86400);

dheader('Location:' . ZIMUCMS_URL);


}


}else{

        $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
            'zimu_zhaopin_area'
        ), 'id');
        
        foreach ($arealist as $key => $value) {
            
            $arealist[$value['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                'zimu_zhaopin_area',
                $value['id']
            ),'id');            
            
        }

		include zimu_template('subsite');
		

}

