<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_deluser/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_deluser');

include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_deluser/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_deluser');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimu_deluser'];

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_deluser']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_deluser']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_deluser']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function isuid()
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    $zmdata = $_G['cache']['plugin']['zimu_deluser'];
    $refererurl = $_G['siteurl'] . 'plugin.php?id=zimu_deluser';
    
if (IN_MAGAPP && !$_G['uid']){

$userAgent = $_SERVER['HTTP_USER_AGENT'];
$info = strstr($userAgent, "MAGAPPX");
$info=explode("|",$info);
$token = $info[7];

    $appurl = $zmdata['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$zmdata['magapp_secret'];
    $appdata = dfsockopen($appurl);
    if (!$appdata) {
        $appdata = file_get_contents($appurl);
    }
    $r =  json_decode($appdata, true);
    if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

    }else{
        exit('<script src="source/plugin/zimu_deluser/static/js/magjs-x.js"></script><script>
            mag.toLogin(function(){
                top.location.href="' . $refererurl . '";
                });
                </script>'); 
    }

}else{

        if (!$_G['uid']) {
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_deluser/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="' . $refererurl . '";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_deluser/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            top.location.href="' . $refererurl . '";
  });
    </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //登陆失败
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
}
}


function hex2rgba($color, $opacity = false, $raw = false) {
        $default = 'rgb(0,0,0)';
        //Return default if no color provided
        if(empty($color))
              return $default; 
        //Sanitize $color if "#" is provided 
        if ($color[0] == '#' ) {
            $color = substr( $color, 1 );
        }
        //Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
                return $default;
        }
 
        //Convert hexadec to rgb
        $rgb =  array_map('hexdec', $hex);
 
        if($raw){
            if($opacity){
                if(abs($opacity) > 1) $opacity = 1.0;
                array_push($rgb, $opacity);
            }
            $output = $rgb;
        }else{
            //Check if opacity is set(rgba or rgb)
            if($opacity){
                if(abs($opacity) > 1)
                    $opacity = 1.0;
                $output = 'rgba('.implode(",",$rgb).','.$opacity.')';
            } else {
                $output = 'rgb('.implode(",",$rgb).')';
            }
        }
 
        //Return rgb(a) color string
        return $output;
    }


function lizimu_post($url, $data) {
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}