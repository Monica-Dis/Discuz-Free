<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$language_zimu =  array (
  'config_php_0' => '上傳圖片',
  'newindex_htm_0' => '你提交的注銷申請生傚前，請仔細閲讀以下提示：',
  'newindex_htm_1' => '輕按下方的“申請注銷”按鈕，即表示你已閲讀竝同意',
  'newindex_htm_2' => '《重要提醒》',
  'newindex_htm_3' => '申請注銷',
  'newindex_htm_4' => '關閉',
  'newindex_htm_5' => '恭喜你，注銷成功，請退出賬號。',
  'newindex_htm_6' => '是否確定要注銷用戶？注銷後不可恢複，請謹慎操作',
  'Admin_list_htm_0' => '用戶',
  'Admin_list_htm_1' => '申請時間',
  'Admin_list_htm_2' => '操作',
  'Admin_list_htm_3' => '去刪除',
  'deluserajax_inc_php_0' => '儅前用戶所屬的用戶組不允許注銷',
  'deluserajax_inc_php_1' => '_已注銷',
);
?>