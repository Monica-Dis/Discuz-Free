<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$language_zimu =  array (
  'config_php_0' => '上传图片',
  'newindex_htm_0' => '你提交的注销申请生效前，请仔细阅读以下提示：',
  'newindex_htm_1' => '轻按下方的“申请注销”按钮，即表示你已阅读并同意',
  'newindex_htm_2' => '《重要提醒》',
  'newindex_htm_3' => '申请注销',
  'newindex_htm_4' => '关闭',
  'newindex_htm_5' => '恭喜你，注销成功，请退出账号。',
  'newindex_htm_6' => '是否确定要注销用户？注销后不可恢复，请谨慎操作',
  'Admin_list_htm_0' => '用户',
  'Admin_list_htm_1' => '申请时间',
  'Admin_list_htm_2' => '操作',
  'Admin_list_htm_3' => '去删除',
  'deluserajax_inc_php_0' => '当前用户所属的用户组不允许注销',
  'deluserajax_inc_php_1' => '_已注销',
);
?>