<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_G['uid'] && $_GET['md5hash'] == formhash()) {
    
    $vipgroups = empty($zmdata['usergroup']) ? array() : unserialize($zmdata['usergroup']);
    if (!is_array($vipgroups)) {
        $vipgroups = array();
    }
    
    if (!in_array($_G['group']['groupid'], $vipgroups) && $vipgroups[0]) {
        $out['code'] = 201;
        $out['err']  = urlencode($language_zimu['deluserajax_inc_php_0']);
        $result      = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }
    
    $isadd = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_deluser_list',
        $_G['uid']
    ));
    
    if (!$isadd) {
        
        $zimu_deluser_listdata = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'addtime' => $_G['timestamp']
        );
        DB::insert('zimu_deluser_list', $zimu_deluser_listdata);
        
        
        loaducenter();
        
        $checkusername = $_G['username'] . $language_zimu['deluserajax_inc_php_1'];
        
        $result1 = DB::query('UPDATE %t SET username = %s,groupid = %d WHERE username = %s', array(
            'common_member',
            $checkusername,
            $zmdata['delusergroup'],
            $_G['username']
        ));
        
        $result2 = DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$checkusername' WHERE username='{$_G[username]}'");
        
        C::t('common_member')->update_cache($_G['uid'], array(
            'username' => $checkusername
        ));
        
        $_G['username'] = $checkusername;
        
        if ($zmdata['del_app'] == 2) {
            if ($zmdata['del_mobile'] == 1) {
                DB::delete('appbyme_sendsms', array(
                    'uid' => $_G['uid']
                ));
            }
            if ($zmdata['del_weixin'] == 1) {
                DB::delete('appbyme_connection', array(
                    'uid' => $_G['uid']
                ));
            }
        }
        if ($zmdata['del_app'] == 3) {
            if ($zmdata['del_mobile'] == 1) {
                DB::delete('user_weixin_relations', array(
                    'userid' => $_G['uid']
                ));
            }
            if ($zmdata['del_weixin'] == 1) {
                DB::delete('user_mobile_relations', array(
                    'userid' => $_G['uid']
                ));
            }
        }
        if ($zmdata['del_app'] == 4) {
            if ($zmdata['del_mobile'] == 1) {
                DB::delete('thirdbind', array(
                    'uid' => $_G['uid']
                ));
            }
            if ($zmdata['del_weixin'] == 1) {
                DB::delete('phonebind', array(
                    'uid' => $_G['uid']
                ));
            }
        }
        
        if ($zmdata['del_type'] == 1) {

        DB::query('UPDATE %t SET readperm=100,hidden=1 WHERE authorid = %d', array(
            'forum_thread',
            $_G['uid']
        ));

        }

        if ($zmdata['del_type'] == 2) {
                DB::delete('forum_thread', array(
                    'authorid' => $_G['uid']
                ));
                C::t('forum_access')->delete_by_uid($_G['uid']);
                C::t('common_member_verify_info')->delete_by_uid($_G['uid']);
                C::t('common_member_action_log')->delete_by_uid($_G['uid']);
                C::t('forum_moderator')->delete_by_uid($_G['uid']);
                C::t('forum_post_location')->delete_by_uid($_G['uid']);
                C::t('home_feed')->delete_by_uid($_G['uid']);
                C::t('home_notification')->delete_by_uid($_G['uid']);
                C::t('home_poke')->delete_by_uid_or_fromuid($_G['uid']);
                C::t('home_comment')->delete_by_uid($_G['uid']);
                C::t('home_visitor')->delete_by_uid_or_vuid($_G['uid']);
                C::t('home_friend')->delete_by_uid_fuid($_G['uid']);
                C::t('home_friend_request')->delete_by_uid_or_fuid($_G['uid']);
                C::t('common_invite')->delete_by_uid_or_fuid($_G['uid']);
                C::t('common_myinvite')->delete_by_touid_or_fromuid($_G['uid']);
                C::t('common_member_forum_buylog')->delete_by_uid($_G['uid']);
                C::t('forum_threadhidelog')->delete_by_uid($_G['uid']);
                C::t('common_member_crime')->delete_by_uid($_G['uid']);
        }

        if ($zmdata['del_type'] == 3) {
            require_once libfile('function/delete');
            $numdeleted = deletemember($_G['uid']);
            loaducenter();
            uc_user_delete($_G['uid']);
        }

        if (C::memory()->enable) {
            C::memory()->clear();
        }
        
        if ($zmdata['magapp_hostname'] && $zmdata['magapp_secret']) {
            
            $updateUn['user_id'] = $_G['uid'];
            $updateUn['secret']  = $zmdata['magapp_secret'];
            $magdata1            = lizimu_post($zmdata['magapp_hostname'] . '/mag/open/api/updateUserName', $updateUn);
            $magdata2            = lizimu_post($zmdata['magapp_hostname'] . '/mag/user/v1/user/syncUserInfo', $updateUn);
            
        }
        
        
        $out['code'] = 200;
        echo $result = json_encode($out);
        exit();
        
    }
    
}