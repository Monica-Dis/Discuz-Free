<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;

 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(5) DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `pic` char(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_cat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `logo` char(255) NOT NULL,
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '100',
  `caturl` char(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_huodong` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(255) DEFAULT NULL,
  `thumb` char(255) DEFAULT NULL,
  `content` text,
  `lianxiren` char(20) NOT NULL,
  `tel` char(20) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `huodong_desc` varchar(1000) NOT NULL,
  `file1` char(255) DEFAULT NULL,
  `file2` char(255) DEFAULT NULL,
  `file3` char(255) DEFAULT NULL,
  `file4` char(255) DEFAULT NULL,
  `file5` char(255) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_ranklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dayclick` int(10) unsigned NOT NULL,
  `weekclick` int(10) unsigned NOT NULL,
  `monthclick` int(10) unsigned NOT NULL,
  `yearclick` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `yid` int(10) unsigned NOT NULL,
  `uptime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_renmai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weixin_id` char(20) NOT NULL,
  `weixin_name` char(20) NOT NULL,
  `weixin_desc` char(100) NOT NULL,
  `weixin_sex` smallint(1) unsigned NOT NULL,
  `weixin_touxiang` char(255) NOT NULL,
  `weixin_erweima` char(255) NOT NULL,
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL,
  `click` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `logo` char(255) NOT NULL,
  `thumb` char(255) NOT NULL,
  `lianxiren` char(20) NOT NULL,
  `tel` char(15) NOT NULL,
  `address` char(255) NOT NULL,
  `desc` text NOT NULL,
  `click` int(10) unsigned NOT NULL,
  `typeid1` smallint(3) unsigned NOT NULL,
  `typeid2` smallint(3) unsigned NOT NULL,
  `youhui` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `uid` int(10) unsigned NOT NULL,
  `province` int(10) unsigned NOT NULL,
  `city` int(10) unsigned NOT NULL,
  `country` int(10) unsigned NOT NULL,
  `lat` char(50) NOT NULL,
  `lng` char(50) NOT NULL,
  `ispay` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) unsigned NOT NULL,
  `viptime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `yewuyuan` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '100',
  `out_trade_no` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_shoppic` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(50) DEFAULT NULL,
  `sid` int(200) DEFAULT NULL,
  `imgurl` varchar(1000) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `createtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_yewuyuan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `tel` char(20) NOT NULL,
  `jiesuannums` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_youhuiquan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL,
  `thumb` char(255) NOT NULL,
  `jiage` float NOT NULL,
  `daodianfu` float NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `duihuantime` int(10) unsigned NOT NULL,
  `maxnums` smallint(5) unsigned NOT NULL,
  `paymaxnums` smallint(2) unsigned NOT NULL,
  `content` text NOT NULL,
  `yanzheng` char(50) NOT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ismiaosha` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `starthours` smallint(2) unsigned NOT NULL,
  `endhours` smallint(2) unsigned NOT NULL,
  `daynums` smallint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_youhuiquandata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `yid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `jiage` float NOT NULL,
  `alljiage` float NOT NULL,
  `nums` smallint(2) unsigned NOT NULL,
  `out_trade_no` char(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `usedtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


EOF;

runquery($sql);

$finish = TRUE;
?>