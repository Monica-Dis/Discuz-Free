<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


global $_G;

define('appweixin_appid', $_G['cache']['plugin']['zimucms_chengshi114']['appweixin_appid']);
define('appweixin_appsecret', $_G['cache']['plugin']['zimucms_chengshi114']['appweixin_appsecret']);
define('appweixin_mchid', $_G['cache']['plugin']['zimucms_chengshi114']['appweixin_mchid']);
define('appweixin_key', $_G['cache']['plugin']['zimucms_chengshi114']['appweixin_key']);
define('CURL_TIMEOUT', 30);


/**
 * TODO：这里设置代理机器，只有需要代理的时候才设置，不需要代理，请设置为0.0.0.0和0
 * 本例程通过curl使用HTTP POST方法，此处可修改代理服务器，
 * 默认CURL_PROXY_HOST=0.0.0.0和CURL_PROXY_PORT=0，此时不开启代理（如有需要才设置）
 * @var unknown_type
 */
define('CURL_PROXY_HOST', '0.0.0.0');
define('CURL_PROXY_PORT', 0);

/**
 * TODO：接口调用上报等级，默认紧错误上报（注意：上报超时间为【1s】，上报无论成败【永不抛出异常】，
 * 不会影响接口调用流程），开启上报之后，方便微信监控请求调用的质量，建议至少
 * 开启错误上报。
 * 上报等级，0.关闭上报; 1.仅错误出错上报; 2.全量上报
 * @var int
 */
define('REPORT_LEVENL', 1);