<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
$model = addslashes($_GET['model']);

if($model == 'addyewuyuan' ) {


    if (submitcheck('addyewuyuan')) {

        $addata['name'] = strip_tags($_GET['name']);
        $addata['tel']   = strip_tags($_GET['tel']);
        $addata['jiesuannums']  = intval($_GET['jiesuannums']);
        
        
        $result = DB::insert('zimucms_chengshi114_yewuyuan', $addata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
        
    } else {
        
       include template('zimucms_chengshi114:admin/addyewuyuan');

    }


}else if ($model == 'edityewuyuan') {
    
    
    if (submitcheck('addyewuyuan')) {
        
        
        $addata['id']  = intval($_GET['id']);
        $addata['name'] = strip_tags($_GET['name']);
        $addata['tel']   = strip_tags($_GET['tel']);
        $addata['jiesuannums']  = intval($_GET['jiesuannums']);
        
        $result = DB::update('zimucms_chengshi114_yewuyuan', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        
        $yid = intval($_GET['yid']);
        
        $yewuyuandata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_yewuyuan',
            $yid
        ));
        
        include template('zimucms_chengshi114:admin/addyewuyuan');
    }

}else if($model == 'delyewuyuan' && $_GET['formhash'] == formhash()) {


    $yid = intval($_GET['yid']);
    
    $result = DB::delete('zimucms_chengshi114_yewuyuan', array(
        'id' => $yid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
    



	}else{

    $yewuyuandata = DB::fetch_all('select * from %t order by id asc', array(
        'zimucms_chengshi114_yewuyuan'
    ));


    foreach ($yewuyuandata as $key => $value) {
   
    $yewuyuandata[$key]['nums'] = DB::result_first("SELECT count(*) FROM %t where yewuyuan=%d and ispay=2", array(
        "zimucms_chengshi114_shop",
        $value['id']
    ));


    }

    include template('zimucms_chengshi114:admin/yewuyuanlist');
	}