<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 应用更新支持：https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';

$model = addslashes($_GET['model']);


if ($model == 'edityouhuiquan') {
    
    
    if (submitcheck('edityouhuiquan')) {
        

        $isstatus = DB::result_first('select status from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            intval($_GET['id'])
        ));

        $youhuiquandata['uid']   = intval($_GET['uid']);
        $youhuiquandata['sid']   = intval($_GET['sid']);
        $youhuiquandata['id']   = intval($_GET['id']);
        $youhuiquandata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_logo']['tmp_name']) {
            $youhuiquandata['thumb'] = zm_saveimages($_FILES['shop_logo'], 'renmai');
        }
        $youhuiquandata['jiage'] = round($_GET['jiage'],2);  
        $youhuiquandata['daodianfu']       = round($_GET['daodianfu'],2);  
        $youhuiquandata['starttime']   = strtotime($_GET['starttime']);
        $youhuiquandata['endtime']   = strtotime($_GET['endtime']);
        $youhuiquandata['duihuantime']   = strtotime($_GET['duihuantime']);
        $youhuiquandata['maxnums']   = intval($_GET['maxnums']);
        $youhuiquandata['paymaxnums']   = intval($_GET['paymaxnums']);
        $youhuiquandata['content']      = dhtmlspecialchars($_GET['content']);
        $youhuiquandata['yanzheng']    = strip_tags($_GET['yanzheng']);
        $youhuiquandata['beizhu']       = strip_tags($_GET['beizhu']);
        $youhuiquandata['status']   = intval($_GET['status']);   
        $youhuiquandata['ismiaosha']   = intval($_GET['ismiaosha']);
        $youhuiquandata['starthours']   = intval($_GET['starthours']);
        $youhuiquandata['endhours']   = intval($_GET['endhours']);
        $youhuiquandata['daynums']   = intval($_GET['daynums']);

        $result = DB::update('zimucms_chengshi114_youhuiquan', $youhuiquandata, array(
            'id' => $youhuiquandata['id']
        ));

$zmweixin = (array) unserialize($_G['setting']['zimucms_weixin']);
if($zmweixin['weixin_appid']){
        $touser = DB::result_first('select openid from %t where uid=%d', array(
            'zimucms_weixin_binduser',
            $youhuiquandata['uid']
        ));
}

if($touser && $isstatus==1 && $youhuiquandata['status']==2){

require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmweixin['weixin_appid'], $zmweixin['weixin_appsecret']);
    $token    = $wechat_client->getAccessToken(1);
    $template = array(
        'touser' => $touser,
        'template_id' => $zmdata['shangjia_mbid'],
        'url' => ZIMUCMS_URL . '&model=viewyouhuiquan&yid=' . $youhuiquandata['id'],
        'data' => array(
            'first' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text16'), CHARSET, 'utf-8'))
            ),
            'keyword1' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text17'), CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text21'), CHARSET, 'utf-8'))
            ),
            'remark' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text19'), CHARSET, 'utf-8')),
            )
            
        )
    );
    $json     = urldecode(json_encode($template));
    $result2 = send_weixintemplate($token, $json);
}


  
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        $yid = intval($_GET['yid']);
        
        $youhuiquandata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $yid
        ));
        
        include template('zimucms_chengshi114:admin/edityouhuiquan');
    }



} else if ($model == 'addyouhuiquan') {


    if (submitcheck('edityouhuiquan')) {
        

        $youhuiquandata['title'] = strip_tags($_GET['title']);
        if ($_FILES['shop_logo']['tmp_name']) {
            $youhuiquandata['thumb'] = zm_saveimages($_FILES['shop_logo'], 'renmai');
        }
        $youhuiquandata['jiage'] = round($_GET['jiage'],2);  
        $youhuiquandata['daodianfu']       = round($_GET['daodianfu'],2);  
        $youhuiquandata['starttime']   = strtotime($_GET['starttime']);
        $youhuiquandata['endtime']   = strtotime($_GET['endtime']);
        $youhuiquandata['duihuantime']   = strtotime($_GET['duihuantime']);
        $youhuiquandata['maxnums']   = intval($_GET['maxnums']);
        $youhuiquandata['paymaxnums']   = intval($_GET['paymaxnums']);
        $youhuiquandata['content']      = dhtmlspecialchars($_GET['content']);
        $youhuiquandata['yanzheng']    = strip_tags($_GET['yanzheng']);
        $youhuiquandata['beizhu']       = strip_tags($_GET['beizhu']);
        $youhuiquandata['uid']   = intval($_GET['uid']);
        $youhuiquandata['sid']   = intval($_GET['sid']);
        $youhuiquandata['status']   = intval($_GET['status']);   
        $youhuiquandata['ismiaosha']   = intval($_GET['ismiaosha']);
        $youhuiquandata['starthours']   = intval($_GET['starthours']);
        $youhuiquandata['endhours']   = intval($_GET['endhours']);
        $youhuiquandata['daynums']   = intval($_GET['daynums']);

        $result = DB::insert('zimucms_chengshi114_youhuiquan', $youhuiquandata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {

        include template('zimucms_chengshi114:admin/edityouhuiquan');
    }
} else if ($model == 'delyouhuiquan' && $_GET['formhash'] == formhash()) {
    
    $yid = intval($_GET['yid']);
    
    $result = DB::delete('zimucms_chengshi114_youhuiquan', array(
        'id' => $yid,
    ));



    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
 

}else if($model=="youhuiquandata"){

    $yid = intval($_GET['yid']);
if($yid){
    $youhuiquandata = DB::fetch_all('select * from %t where yid=%d and status>1 order by id desc', array(
            'zimucms_chengshi114_youhuiquandata',
            $yid
        ));
}else{
    $youhuiquandata = DB::fetch_all('select * from %t where status>1 order by id desc', array(
            'zimucms_chengshi114_youhuiquandata',
        )); 
}

foreach ($youhuiquandata as $key => $value) {

$youhuiquandata[$key]['yhinfo'] = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid']
        ));

$youhuiquandata[$key]['shopinfo'] = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $value['sid']
        ));

}

    include template('zimucms_chengshi114:admin/youhuiquandata');

} else if ($model == 'updatayouhuiquan' && $_GET['formhash'] == formhash()) {

$adddata['id'] = intval($_GET['oid']);
$adddata['status'] = intval($_GET['status']);
if($adddata['status']==3){
$adddata['usedtime'] = time();   
}else{
$adddata['usedtime'] = '';     
}

        $result = DB::update('zimucms_chengshi114_youhuiquandata', $adddata, array(
            'id' => $adddata['id']
        ));
        
        if ($result) {

            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'].'&model=youhuiquandata&yid='.$_GET['yid'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }

} else {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $status = intval($_GET['status']);
    
    $shanghuname = $_GET['shanghuname'];
    $shanghuname = strip_tags(zm_diconv($shanghuname));
    
    
    //新增审核修改
    $shanghuname = dhtmlspecialchars($shanghuname);
    $shanghuname = stripsearchkey($shanghuname);
    $shanghuname = daddslashes($shanghuname);
    
    
    if ($status) {
        $wheresql = ' where status=' . $status;
    } else {
        $wheresql = ' where status<3';
    }
    if ($shanghuname) {
        $shanghunamesql = ' and title like %s or content like %s';
    }
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql . $shanghunamesql, array(
        "zimucms_chengshi114_youhuiquan",
        "%" . $shanghuname . "%",
        "%" . $shanghuname . "%"
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    if ($shanghuname) {
        $youhuiquandata = DB::fetch_all('select * from %t ' . $wheresql . $shanghunamesql . ' order by id desc limit %d,%d', array(
            'zimucms_chengshi114_youhuiquan',
            '%' . $shanghuname . '%',
            '%' . $shanghuname . '%',
            $start,
            $limit
        ));
    } else {
        $youhuiquandata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimucms_chengshi114_youhuiquan',
            $start,
            $limit
        ));
    }
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, SITE_URL . '/admin.php?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&status=' . $status, '10000', '10000', TRUE, TRUE);
    }

foreach ($youhuiquandata as $key => $value) {

$youhuiquandata[$key]['shopinfo'] = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $value['sid']
        ));
    $youhuiquandata[$key]['usednums'] = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d", array(
        "zimucms_chengshi114_youhuiquandata",
        $value['id']
    ));

}

    include template('zimucms_chengshi114:admin/youhuiquanlist');
    
}