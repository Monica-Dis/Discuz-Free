<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


loadcache('plugin');/*dism-Taobao-com*/
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_chengshi114/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_chengshi114');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_chengshi114'];


$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


function isuid()
{
    global $_G;
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    if (!$_G['uid']) {
if(IN_XIAOYUNAPP){
    exit('<script language="javascript" src="source/plugin/zimucms_chengshi114/public/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
        AppbymeJavascriptBridge.login(function(data){
            top.location.href="'.$_G[siteurl].$_SERVER['REQUEST_URI'].'";
        });
    });
    </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimucms_chengshi114/public/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
            window.location.href="'.$_G[siteurl].$_SERVER['REQUEST_URI'].'";
  });
    </script>'); 
            } else if (IN_QFAPP) {
                exit('<script src="//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
            if(state==1){
QFH5.refresh(1);
            }else{
                //��½ʧ��
                alert(data.error);//data.error: string
            }
        });
    }
    </script>');
}else{
$refererurl = $_G[siteurl].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
        dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . $refererurl);
        exit();
}
    }
}



/**
 * ����ĳ����γ�ȵ���Χĳ�ξ���������ε��ĸ���
 *
 * @param
 *            radius ����뾶 ƽ��6371km
 * @param
 *            lng float ����
 * @param
 *            lat float γ��
 * @param
 *            distance float �õ�����Բ�İ뾶����Բ������������У�Ĭ��ֵΪ1ǧ��
 * @return array �����ε��ĸ���ľ�γ������
 */
function returnSquarePoint($lng, $lat, $distance = 1, $radius = 6371)
{
    $dlng = 2 * asin(sin($distance / (2 * $radius)) / cos(deg2rad($lat)));
    $dlng = rad2deg($dlng);
    
    $dlat = $distance / $radius;
    $dlat = rad2deg($dlat);
    
    return array(
        'left-top' => array(
            'lat' => $lat + $dlat,
            'lng' => $lng - $dlng
        ),
        'right-top' => array(
            'lat' => $lat + $dlat,
            'lng' => $lng + $dlng
        ),
        'left-bottom' => array(
            'lat' => $lat - $dlat,
            'lng' => $lng - $dlng
        ),
        'right-bottom' => array(
            'lat' => $lat - $dlat,
            'lng' => $lng + $dlng
        )
    );
}


function getDistance($lat1, $lng1, $lat2, $lng2)
{
    $earthRadius = 6367000; //approximate radius of earth in meters
    
    /*
    Convert these degrees to radians
    to work with the formula
    */
    
    $lat1 = ($lat1 * pi()) / 180;
    $lng1 = ($lng1 * pi()) / 180;
    
    $lat2 = ($lat2 * pi()) / 180;
    $lng2 = ($lng2 * pi()) / 180;
    
    /*
    Using the
    Haversine formula
    
    http://en.wikipedia.org/wiki/Haversine_formula
    
    calculate the distance
    */
    
    $calcLongitude      = $lng2 - $lng1;
    $calcLatitude       = $lat2 - $lat1;
    $stepOne            = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2);
    $stepTwo            = 2 * asin(min(1, sqrt($stepOne)));
    $calculatedDistance = $earthRadius * $stepTwo;
    
    return round($calculatedDistance);
}



function array_sort($array, $keys, $type = 'asc')
{
    if (!isset($array) || !is_array($array) || empty($array)) {
        return '';
    }
    if (!isset($keys) || trim($keys) == '') {
        return '';
    }
    if (!isset($type) || $type == '' || !in_array(strtolower($type), array(
        'asc',
        'desc'
    ))) {
        return '';
    }
    $keysvalue = array();
    foreach ($array as $key => $val) {
        $val[$keys]  = str_replace('-', '', $val[$keys]);
        $val[$keys]  = str_replace(' ', '', $val[$keys]);
        $val[$keys]  = str_replace(':', '', $val[$keys]);
        $keysvalue[] = $val[$keys];
    }
    asort($keysvalue); //keyֵ����
    reset($keysvalue); //ָ������ָ�������һ��
    foreach ($keysvalue as $key => $vals) {
        $keysort[] = $key;
    }
    $keysvalue = array();
    $count     = count($keysort);
    if (strtolower($type) != 'asc') {
        for ($i = $count - 1; $i >= 0; $i--) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    } else {
        for ($i = 0; $i < $count; $i++) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    }
    return $keysvalue;
}


function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimucms_chengshi114']['zimu_luanma'] = trim($_G['cache']['plugin']['zimucms_chengshi114']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimucms_chengshi114']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}

function zm_diconv_utf8($str)
{
$encode = mb_detect_encoding($str, array("ASCII","UTF-8","GB2312","GBK","BIG5")); 
if($encode != CHARSET){ 
//$keytitle = iconv($encode,CHARSET."//IGNORE",$str);
$keytitle = mb_convert_encoding($str,'UTF-8',$encode);
}
if(!$keytitle){
$keytitle = $str;
}
return $keytitle;
}





function zm_wechat_auth($isjiage='')
{
    global $_G;

$zmdata = $_G['cache']['plugin']['zimucms_chengshi114'];

if($isjiage){

    if (!IN_WECHAT) {
        return;
    }

}else{

    if (!IN_WECHAT || $_G['cache']['plugin']['zimucms_chengshi114']['site_jiage'] == 0) {
        return;
    }

}

$wechat_client2 = new WeChatClient($zmdata['weixin_appid'],$zmdata['weixin_appsecret']);

list($openid,$uptime) = getcookie('zm_chengshi114') ? explode("\t", authcode(getcookie('zm_chengshi114'), 'DECODE')) : array();

if($openid){
return $openid;
}
$code = addslashes($_GET['code']);

if ($code){
        $token = $wechat_client2->getAccessTokenByCode($code);
        if (!$token['openid'] && !$openid) {
            showmessage('error'.($token['errmsg'] ? ' AccessToken: '.$token['errmsg'] : ''), $referer);
        }

if(!$token['openid']){
$newtoken = $wechat_client2->getAccessToken_new(1,0);
}else{
set_oauth_cookie($token['openid']);
return $token['openid'];
}

}else{


        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        if (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
            $requestUri = $_SERVER['HTTP_X_REWRITE_URL'];
        } elseif (isset($_SERVER['REQUEST_URI'])) {
            $requestUri = $_SERVER['REQUEST_URI'];
        } elseif (isset($_SERVER['REDIRECT_URL'])) {
            $requestUri = $_SERVER['REDIRECT_URL'];
        } elseif (isset($_SERVER['ORIG_PATH_INFO'])) {
            $requestUri = $_SERVER['ORIG_PATH_INFO'];
            if (!empty($_SERVER['QUERY_STRING'])) {
                $requestUri .= '?' . $_SERVER['QUERY_STRING'];
            }
        }
        $url = $protocol . $_SERVER['HTTP_HOST'] . $requestUri;


 $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['weixin_appid'] . '&redirect_uri=' . urlencode($url) . '&response_type=code&scope=snsapi_base&state=' . md5(FORMHASH) . '#wechat_redirect';

dheader('Location:' . $login_url);
}



}
function send_weixintemplate($access_token, $json)
{
    $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $access_token;
    $res = curl_post($url, $json);
    return json_decode($res, true);
}

function curl_post($url, $data)
{
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    # curl_setopt( $ch, CURLOPT_HEADER, 1);
    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}

function zm_saveimages($FILES, $type = 'album')
{
    global $_G;

$zmdata = $_G['cache']['plugin']['zimucms_chengshi114'];

    $upload = new discuz_upload();
    
    $upload->init($FILES, 'album');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];

    if($upload->attach['imageinfo'][0]>1500 ||$upload->attach['imageinfo'][1]>1500 ) {
if($upload->attach['imageinfo'][0]>=$upload->attach['imageinfo'][1]){
$thumb_width = $upload->attach['imageinfo'][0]/2;
}else{
$thumb_width = $upload->attach['imageinfo'][1]/2;
}

        require_once libfile('class/image');
        $image = new image();
        $pic2 = $image->Thumb($upload->attach['target'], '',$thumb_width,$thumb_width,2);
    }

    if($zmdata['ACCESS_ID'] && $zmdata['ACCESS_KEY'] && $zmdata['ENDPOINT'] && $zmdata['BUCKET']){
        $saved_file = DISCUZ_ROOT.$_G['setting']['attachurl'] . '/album/'.$pic;
        include_once DISCUZ_ROOT.'source/plugin/zimucms_chengshi114/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimucms_chengshi114/'.$pic, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }

    if ($pic2) {
        return $_G['setting']['siteurl'] . '/' . $_G['setting']['attachurl'] . '/album/' . $pic.'.thumb.jpg';
    }else{
        return $_G['setting']['siteurl'] . '/' . $_G['setting']['attachurl'] . '/album/' . $pic;  
    }
}

function zm_delimages($pic)
{
    global $_G;
    @unlink($_G['setting']['attachdir'] . '/album/' . $pic);
    return true;
}

function set_oauth_cookie($openid)
{
    global $_G;
    dsetcookie('zm_chengshi114', authcode($openid . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
}

function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str   = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}
function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}