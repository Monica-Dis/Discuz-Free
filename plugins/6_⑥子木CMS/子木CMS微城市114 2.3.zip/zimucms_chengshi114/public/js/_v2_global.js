/*[tplStatic 1.0 - 201110]*/
/* Zepto v1.1.6 - zepto event ajax form ie - zeptojs.com/license */
var Zepto = function() {
    function L(t) {
        return null == t ? String(t) : j[S.call(t)] || "object"
    }
    function Z(t) {
        return "function" == L(t)
    }
    function _(t) {
        return null != t && t == t.window
    }
    function $(t) {
        return null != t && t.nodeType == t.DOCUMENT_NODE
    }
    function D(t) {
        return "object" == L(t)
    }
    function M(t) {
        return D(t)&&!_(t) && Object.getPrototypeOf(t) == Object.prototype
    }
    function R(t) {
        return "number" == typeof t.length
    }
    function k(t) {
        return s.call(t, function(t) {
            return null != t
        })
    }
    function z(t) {
        return t.length > 0 ? n.fn.concat.apply([], t) : t
    }
    function F(t) {
        return t.replace(/::/g, "/").replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2").replace(/([a-z\d])([A-Z])/g, "$1_$2").replace(/_/g, "-").toLowerCase()
    }
    function q(t) {
        return t in f ? f[t] : f[t] = new RegExp("(^|\\s)" + t + "(\\s|$)")
    }
    function H(t, e) {
        return "number" != typeof e || c[F(t)] ? e : e + "px"
    }
    function I(t) {
        var e, n;
        return u[t] || (e = a.createElement(t), a.body.appendChild(e), n = getComputedStyle(e, "").getPropertyValue("display"), e.parentNode.removeChild(e), "none" == n && (n = "block"), u[t] = n), u[t]
    }
    function V(t) {
        return "children"in t ? o.call(t.children) : n.map(t.childNodes, function(t) {
            return 1 == t.nodeType ? t : void 0
        })
    }
    function B(n, i, r) {
        for (e in i)
            r && (M(i[e]) || A(i[e])) ? (M(i[e])&&!M(n[e]) && (n[e] = {}), A(i[e])&&!A(n[e]) && (n[e] = []), B(n[e], i[e], r)) : i[e] !== t && (n[e] = i[e])
    }
    function U(t, e) {
        return null == e ? n(t) : n(t).filter(e)
    }
    function J(t, e, n, i) {
        return Z(e) ? e.call(t, n, i) : e
    }
    function X(t, e, n) {
        null == n ? t.removeAttribute(e) : t.setAttribute(e, n)
    }
    function W(e, n) {
        var i = e.className || "", r = i && i.baseVal !== t;
        return n === t ? r ? i.baseVal : i : void(r ? i.baseVal = n : e.className = n)
    }
    function Y(t) {
        try {
            return t ? "true" == t || ("false" == t?!1 : "null" == t ? null : + t + "" == t?+t : /^[\[\{]/.test(t) ? n.parseJSON(t) : t) : t
        } catch (e) {
            return t
        }
    }
    function G(t, e) {
        e(t);
        for (var n = 0, i = t.childNodes.length; i > n; n++)
            G(t.childNodes[n], e)
    }
    var t, e, n, i, C, N, r = [], o = r.slice, s = r.filter, a = window.document, u = {}, f = {}, c = {
        "column-count": 1,
        columns: 1,
        "font-weight": 1,
        "line-height": 1,
        opacity: 1,
        "z-index": 1,
        zoom: 1
    }, l = /^\s*<(\w+|!)[^>]*>/, h = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, p = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, d = /^(?:body|html)$/i, m = /([A-Z])/g, g = ["val", "css", "html", "text", "data", "width", "height", "offset"], v = ["after", "prepend", "before", "append"], y = a.createElement("table"), x = a.createElement("tr"), b = {
        tr: a.createElement("tbody"),
        tbody: y,
        thead: y,
        tfoot: y,
        td: x,
        th: x,
        "*": a.createElement("div")
    }, w = /complete|loaded|interactive/, E = /^[\w-]*$/, j = {}, S = j.toString, T = {}, O = a.createElement("div"), P = {
        tabindex: "tabIndex",
        readonly: "readOnly",
        "for": "htmlFor",
        "class": "className",
        maxlength: "maxLength",
        cellspacing: "cellSpacing",
        cellpadding: "cellPadding",
        rowspan: "rowSpan",
        colspan: "colSpan",
        usemap: "useMap",
        frameborder: "frameBorder",
        contenteditable: "contentEditable"
    }, A = Array.isArray || function(t) {
        return t instanceof Array
    };
    return T.matches = function(t, e) {
        if (!e ||!t || 1 !== t.nodeType)
            return !1;
        var n = t.webkitMatchesSelector || t.mozMatchesSelector || t.oMatchesSelector || t.matchesSelector;
        if (n)
            return n.call(t, e);
        var i, r = t.parentNode, o=!r;
        return o && (r = O).appendChild(t), i=~T.qsa(r, e).indexOf(t), o && O.removeChild(t), i
    }, C = function(t) {
        return t.replace(/-+(.)?/g, function(t, e) {
            return e ? e.toUpperCase() : ""
        })
    }, N = function(t) {
        return s.call(t, function(e, n) {
            return t.indexOf(e) == n
        })
    }, T.fragment = function(e, i, r) {
        var s, u, f;
        return h.test(e) && (s = n(a.createElement(RegExp.$1))), s || (e.replace && (e = e.replace(p, "<$1></$2>")), i === t && (i = l.test(e) && RegExp.$1), i in b || (i = "*"), f = b[i], f.innerHTML = "" + e, s = n.each(o.call(f.childNodes), function() {
            f.removeChild(this)
        })), M(r) && (u = n(s), n.each(r, function(t, e) {
            g.indexOf(t)>-1 ? u[t](e) : u.attr(t, e)
        })), s
    }, T.Z = function(t, e) {
        return t = t || [], t.__proto__ = n.fn, t.selector = e || "", t
    }, T.isZ = function(t) {
        return t instanceof T.Z
    }, T.init = function(e, i) {
        var r;
        if (!e)
            return T.Z();
        if ("string" == typeof e)
            if (e = e.trim(), "<" == e[0] && l.test(e))
                r = T.fragment(e, RegExp.$1, i), e = null;
            else {
                if (i !== t)
                    return n(i).find(e);
                    r = T.qsa(a, e)
            } else {
            if (Z(e))
                return n(a).ready(e);
            if (T.isZ(e))
                return e;
            if (A(e))
                r = k(e);
            else if (D(e))
                r = [e], e = null;
            else if (l.test(e))
                r = T.fragment(e.trim(), RegExp.$1, i), e = null;
            else {
                if (i !== t)
                    return n(i).find(e);
                r = T.qsa(a, e)
            }
        }
        return T.Z(r, e)
    }, n = function(t, e) {
        return T.init(t, e)
    }, n.extend = function(t) {
        var e, n = o.call(arguments, 1);
        return "boolean" == typeof t && (e = t, t = n.shift()), n.forEach(function(n) {
            B(t, n, e)
        }), t
    }, T.qsa = function(t, e) {
        var n, i = "#" == e[0], r=!i && "." == e[0], s = i || r ? e.slice(1) : e, a = E.test(s);
        return $(t) && a && i ? (n = t.getElementById(s)) ? [n] : [] : 1 !== t.nodeType && 9 !== t.nodeType ? [] : o.call(a&&!i ? r ? t.getElementsByClassName(s) : t.getElementsByTagName(e) : t.querySelectorAll(e))
    }, n.contains = a.documentElement.contains ? function(t, e) {
        return t !== e && t.contains(e)
    } : function(t, e) {
        for (; e && (e = e.parentNode);)
            if (e === t)
                return !0;
        return !1
    }, n.type = L, n.isFunction = Z, n.isWindow = _, n.isArray = A, n.isPlainObject = M, n.isEmptyObject = function(t) {
        var e;
        for (e in t)
            return !1;
        return !0
    }, n.inArray = function(t, e, n) {
        return r.indexOf.call(e, t, n)
    }, n.camelCase = C, n.trim = function(t) {
        return null == t ? "" : String.prototype.trim.call(t)
    }, n.uuid = 0, n.support = {}, n.expr = {}, n.map = function(t, e) {
        var n, r, o, i = [];
        if (R(t))
            for (r = 0; r < t.length; r++)
                n = e(t[r], r), null != n && i.push(n);
        else 
            for (o in t)
                n = e(t[o], o), null != n && i.push(n);
        return z(i)
    }, n.each = function(t, e) {
        var n, i;
        if (R(t)) {
            for (n = 0; n < t.length; n++)
                if (e.call(t[n], n, t[n])===!1)
                    return t
        } else 
            for (i in t)
                if (e.call(t[i], i, t[i])===!1)
                    return t;
        return t
    }, n.grep = function(t, e) {
        return s.call(t, e)
    }, window.JSON && (n.parseJSON = JSON.parse), n.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(t, e) {
        j["[object " + e + "]"] = e.toLowerCase()
    }), n.fn = {
        forEach: r.forEach,
        reduce: r.reduce,
        push: r.push,
        sort: r.sort,
        indexOf: r.indexOf,
        concat: r.concat,
        map: function(t) {
            return n(n.map(this, function(e, n) {
                return t.call(e, n, e)
            }))
        },
        slice: function() {
            return n(o.apply(this, arguments))
        },
        ready: function(t) {
            return w.test(a.readyState) && a.body ? t(n) : a.addEventListener("DOMContentLoaded", function() {
                t(n)
            }, !1), this
        },
        get: function(e) {
            return e === t ? o.call(this) : this[e >= 0 ? e: e + this.length]
        },
        toArray: function() {
            return this.get()
        },
        size: function() {
            return this.length
        },
        remove: function() {
            return this.each(function() {
                null != this.parentNode && this.parentNode.removeChild(this)
            })
        },
        each: function(t) {
            return r.every.call(this, function(e, n) {
                return t.call(e, n, e)!==!1
            }), this
        },
        filter: function(t) {
            return Z(t) ? this.not(this.not(t)) : n(s.call(this, function(e) {
                return T.matches(e, t)
            }))
        },
        add: function(t, e) {
            return n(N(this.concat(n(t, e))))
        },
        is: function(t) {
            return this.length > 0 && T.matches(this[0], t)
        },
        not: function(e) {
            var i = [];
            if (Z(e) && e.call !== t)
                this.each(function(t) {
                    e.call(this, t) || i.push(this)
                });
            else {
                var r = "string" == typeof e ? this.filter(e): R(e) && Z(e.item) ? o.call(e): n(e);
                this.forEach(function(t) {
                    r.indexOf(t) < 0 && i.push(t)
                })
            }
            return n(i)
        },
        has: function(t) {
            return this.filter(function() {
                return D(t) ? n.contains(this, t) : n(this).find(t).size()
            })
        },
        eq: function(t) {
            return - 1 === t ? this.slice(t) : this.slice(t, + t + 1)
        },
        first: function() {
            var t = this[0];
            return t&&!D(t) ? t : n(t)
        },
        last: function() {
            var t = this[this.length - 1];
            return t&&!D(t) ? t : n(t)
        },
        find: function(t) {
            var e, i = this;
            return e = t ? "object" == typeof t ? n(t).filter(function() {
                var t = this;
                return r.some.call(i, function(e) {
                    return n.contains(e, t)
                })
            }) : 1 == this.length ? n(T.qsa(this[0], t)) : this.map(function() {
                return T.qsa(this, t)
            }) : n()
        },
        closest: function(t, e) {
            var i = this[0], r=!1;
            for ("object" == typeof t && (r = n(t)); i&&!(r ? r.indexOf(i) >= 0 : T.matches(i, t));)
                i = i !== e&&!$(i) && i.parentNode;
            return n(i)
        },
        parents: function(t) {
            for (var e = [], i = this; i.length > 0;)
                i = n.map(i, function(t) {
                    return (t = t.parentNode)&&!$(t) && e.indexOf(t) < 0 ? (e.push(t), t) : void 0
                });
            return U(e, t)
        },
        parent: function(t) {
            return U(N(this.pluck("parentNode")), t)
        },
        children: function(t) {
            return U(this.map(function() {
                return V(this)
            }), t)
        },
        contents: function() {
            return this.map(function() {
                return o.call(this.childNodes)
            })
        },
        siblings: function(t) {
            return U(this.map(function(t, e) {
                return s.call(V(e.parentNode), function(t) {
                    return t !== e
                })
            }), t)
        },
        empty: function() {
            return this.each(function() {
                this.innerHTML = ""
            })
        },
        pluck: function(t) {
            return n.map(this, function(e) {
                return e[t]
            })
        },
        show: function() {
            return this.each(function() {
                "none" == this.style.display && (this.style.display = ""), "none" == getComputedStyle(this, "").getPropertyValue("display") && (this.style.display = I(this.nodeName))
            })
        },
        replaceWith: function(t) {
            return this.before(t).remove()
        },
        wrap: function(t) {
            var e = Z(t);
            if (this[0]&&!e)
                var i = n(t).get(0), r = i.parentNode || this.length > 1;
            return this.each(function(o) {
                n(this).wrapAll(e ? t.call(this, o) : r ? i.cloneNode(!0) : i)
            })
        },
        wrapAll: function(t) {
            if (this[0]) {
                n(this[0]).before(t = n(t));
                for (var e; (e = t.children()).length;)
                    t = e.first();
                n(t).append(this)
            }
            return this
        },
        wrapInner: function(t) {
            var e = Z(t);
            return this.each(function(i) {
                var r = n(this), o = r.contents(), s = e ? t.call(this, i): t;
                o.length ? o.wrapAll(s) : r.append(s)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                n(this).replaceWith(n(this).children())
            }), this
        },
        clone: function() {
            return this.map(function() {
                return this.cloneNode(!0)
            })
        },
        hide: function() {
            return this.css("display", "none")
        },
        toggle: function(e) {
            return this.each(function() {
                var i = n(this);
                (e === t ? "none" == i.css("display") : e) ? i.show() : i.hide()
            })
        },
        prev: function(t) {
            return n(this.pluck("previousElementSibling")).filter(t || "*")
        },
        next: function(t) {
            return n(this.pluck("nextElementSibling")).filter(t || "*")
        },
        html: function(t) {
            return 0 in arguments ? this.each(function(e) {
                var i = this.innerHTML;
                n(this).empty().append(J(this, t, e, i))
            }) : 0 in this ? this[0].innerHTML : null
        },
        text: function(t) {
            return 0 in arguments ? this.each(function(e) {
                var n = J(this, t, e, this.textContent);
                this.textContent = null == n ? "" : "" + n
            }) : 0 in this ? this[0].textContent : null
        },
        attr: function(n, i) {
            var r;
            return "string" != typeof n || 1 in arguments ? this.each(function(t) {
                if (1 === this.nodeType)
                    if (D(n))
                        for (e in n)
                            X(this, e, n[e]);
                    else 
                        X(this, n, J(this, i, t, this.getAttribute(n)))
            }) : this.length && 1 === this[0].nodeType?!(r = this[0].getAttribute(n)) && n in this[0] ? this[0][n] : r : t
        },
        removeAttr: function(t) {
            return this.each(function() {
                1 === this.nodeType && t.split(" ").forEach(function(t) {
                    X(this, t)
                }, this)
            })
        },
        prop: function(t, e) {
            return t = P[t] || t, 1 in arguments ? this.each(function(n) {
                this[t] = J(this, e, n, this[t])
            }) : this[0] && this[0][t]
        },
        data: function(e, n) {
            var i = "data-" + e.replace(m, "-$1").toLowerCase(), r = 1 in arguments ? this.attr(i, n): this.attr(i);
            return null !== r ? Y(r) : t
        },
        val: function(t) {
            return 0 in arguments ? this.each(function(e) {
                this.value = J(this, t, e, this.value)
            }) : this[0] && (this[0].multiple ? n(this[0]).find("option").filter(function() {
                return this.selected
            }).pluck("value") : this[0].value)
        },
        offset: function(t) {
            if (t)
                return this.each(function(e) {
                    var i = n(this), r = J(this, t, e, i.offset()), o = i.offsetParent().offset(), s = {
                        top: r.top - o.top,
                        left: r.left - o.left
                    };
                    "static" == i.css("position") && (s.position = "relative"), i.css(s)
                });
            if (!this.length)
                return null;
            var e = this[0].getBoundingClientRect();
            return {
                left: e.left + window.pageXOffset,
                top: e.top + window.pageYOffset,
                width: Math.round(e.width),
                height: Math.round(e.height)
            }
        },
        css: function(t, i) {
            if (arguments.length < 2) {
                var r, o = this[0];
                if (!o)
                    return;
                if (r = getComputedStyle(o, ""), "string" == typeof t)
                    return o.style[C(t)] || r.getPropertyValue(t);
                if (A(t)) {
                    var s = {};
                    return n.each(t, function(t, e) {
                        s[e] = o.style[C(e)] || r.getPropertyValue(e)
                    }), s
                }
            }
            var a = "";
            if ("string" == L(t))
                i || 0 === i ? a = F(t) + ":" + H(t, i) : this.each(function() {
                    this.style.removeProperty(F(t))
                });
            else 
                for (e in t)
                    t[e] || 0 === t[e] ? a += F(e) + ":" + H(e, t[e]) + ";" : this.each(function() {
                        this.style.removeProperty(F(e))
                    });
            return this.each(function() {
                this.style.cssText += ";" + a
            })
        },
        index: function(t) {
            return t ? this.indexOf(n(t)[0]) : this.parent().children().indexOf(this[0])
        },
        hasClass: function(t) {
            return t ? r.some.call(this, function(t) {
                return this.test(W(t))
            }, q(t)) : !1
        },
        addClass: function(t) {
            return t ? this.each(function(e) {
                if ("className"in this) {
                    i = [];
                    var r = W(this), o = J(this, t, e, r);
                    o.split(/\s+/g).forEach(function(t) {
                        n(this).hasClass(t) || i.push(t)
                    }, this), i.length && W(this, r + (r ? " " : "") + i.join(" "))
                }
            }) : this
        },
        removeClass: function(e) {
            return this.each(function(n) {
                if ("className"in this) {
                    if (e === t)
                        return W(this, "");
                    i = W(this), J(this, e, n, i).split(/\s+/g).forEach(function(t) {
                        i = i.replace(q(t), " ")
                    }), W(this, i.trim())
                }
            })
        },
        toggleClass: function(e, i) {
            return e ? this.each(function(r) {
                var o = n(this), s = J(this, e, r, W(this));
                s.split(/\s+/g).forEach(function(e) {
                    (i === t?!o.hasClass(e) : i) ? o.addClass(e) : o.removeClass(e)
                })
            }) : this
        },
        scrollTop: function(e) {
            if (this.length) {
                var n = "scrollTop"in this[0];
                return e === t ? n ? this[0].scrollTop : this[0].pageYOffset : this.each(n ? function() {
                    this.scrollTop = e
                } : function() {
                    this.scrollTo(this.scrollX, e)
                })
            }
        },
        scrollLeft: function(e) {
            if (this.length) {
                var n = "scrollLeft"in this[0];
                return e === t ? n ? this[0].scrollLeft : this[0].pageXOffset : this.each(n ? function() {
                    this.scrollLeft = e
                } : function() {
                    this.scrollTo(e, this.scrollY)
                })
            }
        },
        position: function() {
            if (this.length) {
                var t = this[0], e = this.offsetParent(), i = this.offset(), r = d.test(e[0].nodeName) ? {
                    top: 0,
                    left: 0
                }
                : e.offset();
                return i.top -= parseFloat(n(t).css("margin-top")) || 0, i.left -= parseFloat(n(t).css("margin-left")) || 0, r.top += parseFloat(n(e[0]).css("border-top-width")) || 0, r.left += parseFloat(n(e[0]).css("border-left-width")) || 0, {
                    top: i.top - r.top,
                    left: i.left - r.left
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var t = this.offsetParent || a.body; t&&!d.test(t.nodeName) && "static" == n(t).css("position");)
                    t = t.offsetParent;
                return t
            })
        }
    }, n.fn.detach = n.fn.remove, ["width", "height"].forEach(function(e) {
        var i = e.replace(/./, function(t) {
            return t[0].toUpperCase()
        });
        n.fn[e] = function(r) {
            var o, s = this[0];
            return r === t ? _(s) ? s["inner" + i] : $(s) ? s.documentElement["scroll" + i] : (o = this.offset()) && o[e] : this.each(function(t) {
                s = n(this), s.css(e, J(this, r, t, s[e]()))
            })
        }
    }), v.forEach(function(t, e) {
        var i = e%2;
        n.fn[t] = function() {
            var t, o, r = n.map(arguments, function(e) {
                return t = L(e), "object" == t || "array" == t || null == e ? e : T.fragment(e)
            }), s = this.length > 1;
            return r.length < 1 ? this : this.each(function(t, u) {
                o = i ? u : u.parentNode, u = 0 == e ? u.nextSibling : 1 == e ? u.firstChild : 2 == e ? u : null;
                var f = n.contains(a.documentElement, o);
                r.forEach(function(t) {
                    if (s)
                        t = t.cloneNode(!0);
                    else if (!o)
                        return n(t).remove();
                    o.insertBefore(t, u), f && G(t, function(t) {
                        null == t.nodeName || "SCRIPT" !== t.nodeName.toUpperCase() || t.type && "text/javascript" !== t.type || t.src || window.eval.call(window, t.innerHTML)
                    })
                })
            })
        }, n.fn[i ? t + "To": "insert" + (e ? "Before" : "After")] = function(e) {
            return n(e)[t](this), this
        }
    }), T.Z.prototype = n.fn, T.uniq = N, T.deserializeValue = Y, n.zepto = T, n
}();
window.Zepto = Zepto, void 0 === window.$ && (window.$ = Zepto), function(t) {
    function l(t) {
        return t._zid || (t._zid = e++)
    }
    function h(t, e, n, i) {
        if (e = p(e), e.ns)
            var r = d(e.ns);
        return (s[l(t)] || []).filter(function(t) {
            return !(!t || e.e && t.e != e.e || e.ns&&!r.test(t.ns) || n && l(t.fn) !== l(n) || i && t.sel != i)
        })
    }
    function p(t) {
        var e = ("" + t).split(".");
        return {
            e: e[0],
            ns: e.slice(1).sort().join(" ")
        }
    }
    function d(t) {
        return new RegExp("(?:^| )" + t.replace(" ", " .* ?") + "(?: |$)")
    }
    function m(t, e) {
        return t.del&&!u && t.e in f||!!e
    }
    function g(t) {
        return c[t] || u && f[t] || t
    }
    function v(e, i, r, o, a, u, f) {
        var h = l(e), d = s[h] || (s[h] = []);
        i.split(/\s/).forEach(function(i) {
            if ("ready" == i)
                return t(document).ready(r);
            var s = p(i);
            s.fn = r, s.sel = a, s.e in c && (r = function(e) {
                var n = e.relatedTarget;
                return !n || n !== this&&!t.contains(this, n) ? s.fn.apply(this, arguments) : void 0
            }), s.del = u;
            var l = u || r;
            s.proxy = function(t) {
                if (t = j(t), !t.isImmediatePropagationStopped()) {
                    t.data = o;
                    var i = l.apply(e, t._args == n ? [t] : [t].concat(t._args));
                    return i===!1 && (t.preventDefault(), t.stopPropagation()), i
                }
            }, s.i = d.length, d.push(s), "addEventListener"in e && e.addEventListener(g(s.e), s.proxy, m(s, f))
        })
    }
    function y(t, e, n, i, r) {
        var o = l(t);
        (e || "").split(/\s/).forEach(function(e) {
            h(t, e, n, i).forEach(function(e) {
                delete s[o][e.i], "removeEventListener"in t && t.removeEventListener(g(e.e), e.proxy, m(e, r))
            })
        })
    }
    function j(e, i) {
        return (i ||!e.isDefaultPrevented) && (i || (i = e), t.each(E, function(t, n) {
            var r = i[t];
            e[t] = function() {
                return this[n] = x, r && r.apply(i, arguments)
            }, e[n] = b
        }), (i.defaultPrevented !== n ? i.defaultPrevented : "returnValue"in i ? i.returnValue===!1 : i.getPreventDefault && i.getPreventDefault()) && (e.isDefaultPrevented = x)), e
    }
    function S(t) {
        var e, i = {
            originalEvent: t
        };
        for (e in t)
            w.test(e) || t[e] === n || (i[e] = t[e]);
        return j(i, t)
    }
    var n, e = 1, i = Array.prototype.slice, r = t.isFunction, o = function(t) {
        return "string" == typeof t
    }, s = {}, a = {}, u = "onfocusin"in window, f = {
        focus: "focusin",
        blur: "focusout"
    }, c = {
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    };
    a.click = a.mousedown = a.mouseup = a.mousemove = "MouseEvents", t.event = {
        add: v,
        remove: y
    }, t.proxy = function(e, n) {
        var s = 2 in arguments && i.call(arguments, 2);
        if (r(e)) {
            var a = function() {
                return e.apply(n, s ? s.concat(i.call(arguments)) : arguments)
            };
            return a._zid = l(e), a
        }
        if (o(n))
            return s ? (s.unshift(e[n], e), t.proxy.apply(null, s)) : t.proxy(e[n], e);
        throw new TypeError("expected function")
    }, t.fn.bind = function(t, e, n) {
        return this.on(t, e, n)
    }, t.fn.unbind = function(t, e) {
        return this.off(t, e)
    }, t.fn.one = function(t, e, n, i) {
        return this.on(t, e, n, i, 1)
    };
    var x = function() {
        return !0
    }, b = function() {
        return !1
    }, w = /^([A-Z]|returnValue$|layer[XY]$)/, E = {
        preventDefault: "isDefaultPrevented",
        stopImmediatePropagation: "isImmediatePropagationStopped",
        stopPropagation: "isPropagationStopped"
    };
    t.fn.delegate = function(t, e, n) {
        return this.on(e, t, n)
    }, t.fn.undelegate = function(t, e, n) {
        return this.off(e, t, n)
    }, t.fn.live = function(e, n) {
        return t(document.body).delegate(this.selector, e, n), this
    }, t.fn.die = function(e, n) {
        return t(document.body).undelegate(this.selector, e, n), this
    }, t.fn.on = function(e, s, a, u, f) {
        var c, l, h = this;
        return e&&!o(e) ? (t.each(e, function(t, e) {
            h.on(t, s, a, e, f)
        }), h) : (o(s) || r(u) || u===!1 || (u = a, a = s, s = n), (r(a) || a===!1) && (u = a, a = n), u===!1 && (u = b), h.each(function(n, r) {
            f && (c = function(t) {
                return y(r, t.type, u), u.apply(this, arguments)
            }), s && (l = function(e) {
                var n, o = t(e.target).closest(s, r).get(0);
                return o && o !== r ? (n = t.extend(S(e), {
                    currentTarget: o,
                    liveFired: r
                }), (c || u).apply(o, [n].concat(i.call(arguments, 1)))) : void 0
            }), v(r, e, u, a, s, l || c)
        }))
    }, t.fn.off = function(e, i, s) {
        var a = this;
        return e&&!o(e) ? (t.each(e, function(t, e) {
            a.off(t, i, e)
        }), a) : (o(i) || r(s) || s===!1 || (s = i, i = n), s===!1 && (s = b), a.each(function() {
            y(this, e, s, i)
        }))
    }, t.fn.trigger = function(e, n) {
        return e = o(e) || t.isPlainObject(e) ? t.Event(e) : j(e), e._args = n, this.each(function() {
            e.type in f && "function" == typeof this[e.type] ? this[e.type]() : "dispatchEvent"in this ? this.dispatchEvent(e) : t(this).triggerHandler(e, n)
        })
    }, t.fn.triggerHandler = function(e, n) {
        var i, r;
        return this.each(function(s, a) {
            i = S(o(e) ? t.Event(e) : e), i._args = n, i.target = a, t.each(h(a, e.type || e), function(t, e) {
                return r = e.proxy(i), i.isImmediatePropagationStopped()?!1 : void 0
            })
        }), r
    }, "focusin focusout focus blur load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select keydown keypress keyup error".split(" ").forEach(function(e) {
        t.fn[e] = function(t) {
            return 0 in arguments ? this.bind(e, t) : this.trigger(e)
        }
    }), t.Event = function(t, e) {
        o(t) || (e = t, t = e.type);
        var n = document.createEvent(a[t] || "Events"), i=!0;
        if (e)
            for (var r in e)
                "bubbles" == r ? i=!!e[r] : n[r] = e[r];
        return n.initEvent(t, i, !0), j(n)
    }
}(Zepto), function(t) {
    function h(e, n, i) {
        var r = t.Event(n);
        return t(e).trigger(r, i), !r.isDefaultPrevented()
    }
    function p(t, e, i, r) {
        return t.global ? h(e || n, i, r) : void 0
    }
    function d(e) {
        e.global && 0 === t.active++&&p(e, null, "ajaxStart")
    }
    function m(e) {
        e.global&&!--t.active && p(e, null, "ajaxStop")
    }
    function g(t, e) {
        var n = e.context;
        return e.beforeSend.call(n, t, e)===!1 || p(e, n, "ajaxBeforeSend", [t, e])===!1?!1 : void p(e, n, "ajaxSend", [t, e])
    }
    function v(t, e, n, i) {
        var r = n.context, o = "success";
        n.success.call(r, t, o, e), i && i.resolveWith(r, [t, o, e]), p(n, r, "ajaxSuccess", [e, n, t]), x(o, e, n)
    }
    function y(t, e, n, i, r) {
        var o = i.context;
        i.error.call(o, n, e, t), r && r.rejectWith(o, [n, e, t]), p(i, o, "ajaxError", [n, i, t || e]), x(e, n, i)
    }
    function x(t, e, n) {
        var i = n.context;
        n.complete.call(i, e, t), p(n, i, "ajaxComplete", [e, n]), m(n)
    }
    function b() {}
    function w(t) {
        return t && (t = t.split(";", 2)[0]), t && (t == f ? "html" : t == u ? "json" : s.test(t) ? "script" : a.test(t) && "xml") || "text"
    }
    function E(t, e) {
        return "" == e ? t : (t + "&" + e).replace(/[&?]{1,2}/, "?")
    }
    function j(e) {
        e.processData && e.data && "string" != t.type(e.data) && (e.data = t.param(e.data, e.traditional)), !e.data || e.type && "GET" != e.type.toUpperCase() || (e.url = E(e.url, e.data), e.data = void 0)
    }
    function S(e, n, i, r) {
        return t.isFunction(n) && (r = i, i = n, n = void 0), t.isFunction(i) || (r = i, i = void 0), {
            url: e,
            data: n,
            success: i,
            dataType: r
        }
    }
    function C(e, n, i, r) {
        var o, s = t.isArray(n), a = t.isPlainObject(n);
        t.each(n, function(n, u) {
            o = t.type(u), r && (n = i ? r : r + "[" + (a || "object" == o || "array" == o ? n : "") + "]"), !r && s ? e.add(u.name, u.value) : "array" == o ||!i && "object" == o ? C(e, u, i, n) : e.add(n, u)
        })
    }
    var i, r, e = 0, n = window.document, o = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, s = /^(?:text|application)\/javascript/i, a = /^(?:text|application)\/xml/i, u = "application/json", f = "text/html", c = /^\s*$/, l = n.createElement("a");
    l.href = window.location.href, t.active = 0, t.ajaxJSONP = function(i, r) {
        if (!("type"in i))
            return t.ajax(i);
        var f, h, o = i.jsonpCallback, s = (t.isFunction(o) ? o() : o) || "jsonp" + ++e, a = n.createElement("script"), u = window[s], c = function(e) {
            t(a).triggerHandler("error", e || "abort")
        }, l = {
            abort: c
        };
        return r && r.promise(l), t(a).on("load error", function(e, n) {
            clearTimeout(h), t(a).off().remove(), "error" != e.type && f ? v(f[0], l, i, r) : y(null, n || "error", l, i, r), window[s] = u, f && t.isFunction(u) && u(f[0]), u = f = void 0
        }), g(l, i)===!1 ? (c("abort"), l) : (window[s] = function() {
            f = arguments
        }, a.src = i.url.replace(/\?(.+)=\?/, "?$1=" + s), n.head.appendChild(a), i.timeout > 0 && (h = setTimeout(function() {
            c("timeout")
        }, i.timeout)), l)
    }, t.ajaxSettings = {
        type: "GET",
        beforeSend: b,
        success: b,
        error: b,
        complete: b,
        context: null,
        global: !0,
        xhr: function() {
            return new window.XMLHttpRequest
        },
        accepts: {
            script: "text/javascript, application/javascript, application/x-javascript",
            json: u,
            xml: "application/xml, text/xml",
            html: f,
            text: "text/plain"
        },
        crossDomain: !1,
        timeout: 0,
        processData: !0,
        cache: !0
    }, t.ajax = function(e) {
        var a, o = t.extend({}, e || {}), s = t.Deferred && t.Deferred();
        for (i in t.ajaxSettings)
            void 0 === o[i] && (o[i] = t.ajaxSettings[i]);
        d(o), o.crossDomain || (a = n.createElement("a"), a.href = o.url, a.href = a.href, o.crossDomain = l.protocol + "//" + l.host != a.protocol + "//" + a.host), o.url || (o.url = window.location.toString()), j(o);
        var u = o.dataType, f = /\?.+=\?/.test(o.url);
        if (f && (u = "jsonp"), o.cache!==!1 && (e && e.cache===!0 || "script" != u && "jsonp" != u) || (o.url = E(o.url, "_=" + Date.now())), "jsonp" == u)
            return f || (o.url = E(o.url, o.jsonp ? o.jsonp + "=?" : o.jsonp===!1 ? "" : "callback=?")), t.ajaxJSONP(o, s);
        var C, h = o.accepts[u], p = {}, m = function(t, e) {
            p[t.toLowerCase()] = [t, e]
        }, x = /^([\w-]+:)\/\//.test(o.url) ? RegExp.$1: window.location.protocol, S = o.xhr(), T = S.setRequestHeader;
        if (s && s.promise(S), o.crossDomain || m("X-Requested-With", "XMLHttpRequest"), m("Accept", h || "*/*"), (h = o.mimeType || h) && (h.indexOf(",")>-1 && (h = h.split(",", 2)[0]), S.overrideMimeType && S.overrideMimeType(h)), (o.contentType || o.contentType!==!1 && o.data && "GET" != o.type.toUpperCase()) && m("Content-Type", o.contentType || "application/x-www-form-urlencoded"), o.headers)
            for (r in o.headers)
                m(r, o.headers[r]);
        if (S.setRequestHeader = m, S.onreadystatechange = function() {
            if (4 == S.readyState) {
                S.onreadystatechange = b, clearTimeout(C);
                var e, n=!1;
                if (S.status >= 200 && S.status < 300 || 304 == S.status || 0 == S.status && "file:" == x) {
                    u = u || w(o.mimeType || S.getResponseHeader("content-type")), e = S.responseText;
                    try {
                        "script" == u ? (1, eval)(e) : "xml" == u ? e = S.responseXML : "json" == u && (e = c.test(e) ? null : t.parseJSON(e))
                    } catch (i) {
                        n = i
                    }
                    n ? y(n, "parsererror", S, o, s) : v(e, S, o, s)
                } else 
                    y(S.statusText || null, S.status ? "error" : "abort", S, o, s)
            }
        }, g(S, o)===!1)
            return S.abort(), y(null, "abort", S, o, s), S;
        if (o.xhrFields)
            for (r in o.xhrFields)
                S[r] = o.xhrFields[r];
        var N = "async"in o ? o.async: !0;
        S.open(o.type, o.url, N, o.username, o.password);
        for (r in p)
            T.apply(S, p[r]);
        return o.timeout > 0 && (C = setTimeout(function() {
            S.onreadystatechange = b, S.abort(), y(null, "timeout", S, o, s)
        }, o.timeout)), S.send(o.data ? o.data : null), S
    }, t.get = function() {
        return t.ajax(S.apply(null, arguments))
    }, t.post = function() {
        var e = S.apply(null, arguments);
        return e.type = "POST", t.ajax(e)
    }, t.getJSON = function() {
        var e = S.apply(null, arguments);
        return e.dataType = "json", t.ajax(e)
    }, t.fn.load = function(e, n, i) {
        if (!this.length)
            return this;
        var a, r = this, s = e.split(/\s/), u = S(e, n, i), f = u.success;
        return s.length > 1 && (u.url = s[0], a = s[1]), u.success = function(e) {
            r.html(a ? t("<div>").html(e.replace(o, "")).find(a) : e), f && f.apply(r, arguments)
        }, t.ajax(u), this
    };
    var T = encodeURIComponent;
    t.param = function(e, n) {
        var i = [];
        return i.add = function(e, n) {
            t.isFunction(n) && (n = n()), null == n && (n = ""), this.push(T(e) + "=" + T(n))
        }, C(i, e, n), i.join("&").replace(/%20/g, "+")
    }
}(Zepto), function(t) {
    t.fn.serializeArray = function() {
        var e, n, i = [], r = function(t) {
            return t.forEach ? t.forEach(r) : void i.push({
                name: e,
                value: t
            })
        };
        return this[0] && t.each(this[0].elements, function(i, o) {
            n = o.type, e = o.name, e && "fieldset" != o.nodeName.toLowerCase()&&!o.disabled && "submit" != n && "reset" != n && "button" != n && "file" != n && ("radio" != n && "checkbox" != n || o.checked) && r(t(o).val())
        }), i
    }, t.fn.serialize = function() {
        var t = [];
        return this.serializeArray().forEach(function(e) {
            t.push(encodeURIComponent(e.name) + "=" + encodeURIComponent(e.value))
        }), t.join("&")
    }, t.fn.submit = function(e) {
        if (0 in arguments)
            this.bind("submit", e);
        else if (this.length) {
            var n = t.Event("submit");
            this.eq(0).trigger(n), n.isDefaultPrevented() || this.get(0).submit()
        }
        return this
    }
}(Zepto), function(t) {
    "__proto__"in{}
    || t.extend(t.zepto, {
        Z: function(e, n) {
            return e = e || [], t.extend(e, t.fn), e.selector = n || "", e.__Z=!0, e
        },
        isZ: function(e) {
            return "array" === t.type(e) && "__Z"in e
        }
    });
    try {
        getComputedStyle(void 0)
    } catch (e) {
        var n = getComputedStyle;
        window.getComputedStyle = function(t) {
            try {
                return n(t)
            } catch (e) {
                return null
            }
        }
    }
}(Zepto);;
var mui = function(t, e) {
    var i = /complete|loaded|interactive/;
    var s = /^#([\w-]+)$/;
    var n = /^\.([\w-]+)$/;
    var r = /^[\w-]+$/;
    var a = /translate(?:3d)?\((.+?)\)/;
    var o = /matrix(3d)?\((.+?)\)/;
    var l = function(e, i) {
        i = i || t;
        if (!e)
            return c();
        if (typeof e === "object")
            return c([e], null);
        if (typeof e === "function")
            return l.ready(e);
        if (typeof e === "string") {
            try {
                e = e.trim();
                if (s.test(e)) {
                    var n = t.getElementById(RegExp.$1);
                    return c(n ? [n] : [])
                }
                return c(l.qsa(e, i), e)
            } catch (r) {}
        }
        return c()
    };
    var c = function(t, e) {
        t = t || [];
        Object.setPrototypeOf(t, l.fn);
        t.selector = e || "";
        return t
    };
    l.uuid = 0;
    l.data = {};
    l.extend = function() {
        var t, i, s, n, r, a, o = arguments[0] || {}, c = 1, f = arguments.length, u = false;
        if (typeof o === "boolean") {
            u = o;
            o = arguments[c] || {};
            c++
        }
        if (typeof o !== "object"&&!l.isFunction(o)) {
            o = {}
        }
        if (c === f) {
            o = this;
            c--
        }
        for (; c < f; c++) {
            if ((t = arguments[c]) != null) {
                for (i in t) {
                    s = o[i];
                    n = t[i];
                    if (o === n) {
                        continue
                    }
                    if (u && n && (l.isPlainObject(n) || (r = l.isArray(n)))) {
                        if (r) {
                            r = false;
                            a = s && l.isArray(s) ? s : []
                        } else {
                            a = s && l.isPlainObject(s) ? s : {}
                        }
                        o[i] = l.extend(u, a, n)
                    } else if (n !== e) {
                        o[i] = n
                    }
                }
            }
        }
        return o
    };
    l.noop = function() {};
    l.slice = [].slice;
    l.filter = [].filter;
    l.type = function(t) {
        return t == null ? String(t) : f[{}.toString.call(t)] || "object"
    };
    l.isArray = Array.isArray || function(t) {
        return t instanceof Array
    };
    l.isWindow = function(t) {
        return t != null && t === t.window
    };
    l.isObject = function(t) {
        return l.type(t) === "object"
    };
    l.isPlainObject = function(t) {
        return l.isObject(t)&&!l.isWindow(t) && Object.getPrototypeOf(t) === Object.prototype
    };
    l.isEmptyObject = function(t) {
        for (var i in t) {
            if (i !== e) {
                return false
            }
        }
        return true
    };
    l.isFunction = function(t) {
        return l.type(t) === "function"
    };
    l.qsa = function(e, i) {
        i = i || t;
        return l.slice.call(n.test(e) ? i.getElementsByClassName(RegExp.$1) : r.test(e) ? i.getElementsByTagName(e) : i.querySelectorAll(e))
    };
    l.ready = function(e) {
        if (i.test(t.readyState)) {
            e(l)
        } else {
            t.addEventListener("DOMContentLoaded", function() {
                e(l)
            }, false)
        }
        return this
    };
    l.map = function(t, e) {
        var i, s = [], n, r;
        if (typeof t.length === "number") {
            for (n = 0, len = t.length; n < len; n++) {
                i = e(t[n], n);
                if (i != null)
                    s.push(i)
                }
        } else {
            for (r in t) {
                i = e(t[r], r);
                if (i != null)
                    s.push(i)
                }
        }
        return s.length > 0 ? [].concat.apply([], s) : s
    };
    l.each = function(t, e, i) {
        if (!t) {
            return this
        }
        if (typeof t.length === "number") {
            [].every.call(t, function(t, i) {
                return e.call(t, i, t) !== false
            })
        } else {
            for (var s in t) {
                if (i) {
                    if (t.hasOwnProperty(s)) {
                        if (e.call(t[s], s, t[s]) === false)
                            return t
                    }
                } else {
                    if (e.call(t[s], s, t[s]) === false)
                        return t
                }
            }
        }
        return this
    };
    l.focus = function(t) {
        if (l.os.ios) {
            setTimeout(function() {
                t.focus()
            }, 10)
        } else {
            t.focus()
        }
    };
    l.trigger = function(t, e, i) {
        t.dispatchEvent(new CustomEvent(e, {
            detail: i,
            bubbles: true,
            cancelable: true
        }));
        return this
    };
    l.getStyles = function(t, e) {
        var i = t.ownerDocument.defaultView.getComputedStyle(t, null);
        if (e) {
            return i.getPropertyValue(e) || i[e]
        }
        return i
    };
    l.parseTranslate = function(t, e) {
        var i = t.match(a || "");
        if (!i ||!i[1]) {
            i = ["", "0,0,0"]
        }
        i = i[1].split(",");
        i = {
            x: parseFloat(i[0]),
            y: parseFloat(i[1]),
            z: parseFloat(i[2])
        };
        if (e && i.hasOwnProperty(e)) {
            return i[e]
        }
        return i
    };
    l.parseTranslateMatrix = function(t, e) {
        var i = t.match(o);
        var s = i && i[1];
        if (i) {
            i = i[2].split(",");
            if (s === "3d")
                i = i.slice(12, 15);
            else {
                i.push(0);
                i = i.slice(4, 7)
            }
        } else {
            i = [0, 0, 0]
        }
        var n = {
            x: parseFloat(i[0]),
            y: parseFloat(i[1]),
            z: parseFloat(i[2])
        };
        if (e && n.hasOwnProperty(e)) {
            return n[e]
        }
        return n
    };
    l.hooks = {};
    l.addAction = function(t, e) {
        var i = l.hooks[t];
        if (!i) {
            i = []
        }
        e.index = e.index || 1e3;
        i.push(e);
        i.sort(function(t, e) {
            return t.index - e.index
        });
        l.hooks[t] = i;
        return l.hooks[t]
    };
    l.doAction = function(t, e) {
        if (l.isFunction(e)) {
            l.each(l.hooks[t], e)
        } else {
            l.each(l.hooks[t], function(t, e) {
                return !e.handle()
            })
        }
    };
    l.later = function(t, e, i, s) {
        e = e || 0;
        var n = t;
        var r = s;
        var a;
        var o;
        if (typeof t === "string") {
            n = i[t]
        }
        a = function() {
            n.apply(i, l.isArray(r) ? r : [r])
        };
        o = setTimeout(a, e);
        return {
            id: o,
            cancel: function() {
                clearTimeout(o)
            }
        }
    };
    l.now = Date.now || function() {
        return + new Date
    };
    var f = {};
    l.each(["Boolean", "Number", "String", "Function", "Array", "Date", "RegExp", "Object", "Error"], function(t, e) {
        f["[object " + e + "]"] = e.toLowerCase()
    });
    if (window.JSON) {
        l.parseJSON = JSON.parse
    }
    l.fn = {
        each: function(t) {
            [].every.call(this, function(e, i) {
                return t.call(e, i, e) !== false
            });
            return this
        }
    };
    if (typeof define === "function" && define.amd) {
        define("mui", [], function() {
            return l
        })
    }
    return l
}(document);
(function(t, e) {
    function i(i) {
        this.os = {};
        var s = [function() {
            var t = i.match(/(MicroMessenger)\/([\d\.]+)/i);
            if (t) {
                this.os.wechat = {
                    version: t[2].replace(/_/g, ".")
                }
            }
            return false
        }, function() {
            var t = i.match(/(Android);?[\s\/]+([\d.]+)?/);
            if (t) {
                this.os.android = true;
                this.os.version = t[2];
                this.os.isBadAndroid=!/Chrome\/\d/.test(e.navigator.appVersion)
            }
            return this.os.android === true
        }, function() {
            var t = i.match(/(iPhone\sOS)\s([\d_]+)/);
            if (t) {
                this.os.ios = this.os.iphone = true;
                this.os.version = t[2].replace(/_/g, ".")
            } else {
                var e = i.match(/(iPad).*OS\s([\d_]+)/);
                if (e) {
                    this.os.ios = this.os.ipad = true;
                    this.os.version = e[2].replace(/_/g, ".")
                }
            }
            return this.os.ios === true
        }
        ];
        [].every.call(s, function(e) {
            return !e.call(t)
        })
    }
    i.call(t, navigator.userAgent)
})(mui, window);
(function(t, e) {
    function i(i) {
        this.os = this.os || {};
        var s = i.match(/Html5Plus/i);
        if (s) {
            this.os.plus = true;
            t(function() {
                e.body.classList.add("mui-plus")
            });
            if (i.match(/StreamApp/i)) {
                this.os.stream = true;
                t(function() {
                    e.body.classList.add("mui-plus-stream")
                })
            }
        }
    }
    i.call(t, navigator.userAgent)
})(mui, document);
(function(t, e, i) {
    t.targets = {};
    t.targetHandles = [];
    t.registerTarget = function(e) {
        e.index = e.index || 1e3;
        t.targetHandles.push(e);
        t.targetHandles.sort(function(t, e) {
            return t.index - e.index
        });
        return t.targetHandles
    };
    e.addEventListener("touchstart", function(e) {
        var s = e.target;
        var n = {};
        for (; s && s !== i; s = s.parentNode) {
            var r = false;
            t.each(t.targetHandles, function(i, a) {
                var o = a.name;
                if (!r&&!n[o] && a.hasOwnProperty("handle")) {
                    t.targets[o] = a.handle(e, s);
                    if (t.targets[o]) {
                        n[o] = true;
                        if (a.isContinue !== true) {
                            r = true
                        }
                    }
                } else {
                    if (!n[o]) {
                        if (a.isReset !== false)
                            t.targets[o] = false
                    }
                }
            });
            if (r) {
                break
            }
        }
    })
})(mui, window, document);
(function(t) {
    if (String.prototype.trim === t) {
        String.prototype.trim = function() {
            return this.replace(/^\s+|\s+$/g, "")
        }
    }
    Object.setPrototypeOf = Object.setPrototypeOf || function(t, e) {
        t["__proto__"] = e;
        return t
    }
})();
(function() {
    if (typeof window.CustomEvent === "undefined") {
        function t(t, e) {
            e = e || {
                bubbles: false,
                cancelable: false,
                detail: undefined
            };
            var i = document.createEvent("Events");
            var s = true;
            for (var n in e) {
                n === "bubbles" ? s=!!e[n] : i[n] = e[n]
            }
            i.initEvent(t, s, true);
            return i
        }
        t.prototype = window.Event.prototype;
        window.CustomEvent = t
    }
})();
(function(t) {
    if (!("classList"in t.documentElement) && Object.defineProperty && typeof HTMLElement !== "undefined") {
        Object.defineProperty(HTMLElement.prototype, "classList", {
            get: function() {
                var t = this;
                function e(e) {
                    return function(i) {
                        var s = t.className.split(/\s+/), n = s.indexOf(i);
                        e(s, n, i);
                        t.className = s.join(" ")
                    }
                }
                var i = {
                    add: e(function(t, e, i) {
                        ~e || t.push(i)
                    }),
                    remove: e(function(t, e) {
                        ~e && t.splice(e, 1)
                    }),
                    toggle: e(function(t, e, i) {
                        ~e ? t.splice(e, 1) : t.push(i)
                    }),
                    contains: function(e) {
                        return !!~t.className.split(/\s+/).indexOf(e)
                    },
                    item: function(e) {
                        return t.className.split(/\s+/)[e] || null
                    }
                };
                Object.defineProperty(i, "length", {
                    get: function() {
                        return t.className.split(/\s+/).length
                    }
                });
                return i
            }
        })
    }
})(document);
(function(t) {
    if (!t.requestAnimationFrame) {
        var e = 0;
        t.requestAnimationFrame = t.webkitRequestAnimationFrame || function(i, s) {
            var n = (new Date).getTime();
            var r = Math.max(0, 16.7 - (n - e));
            var a = t.setTimeout(function() {
                i(n + r)
            }, r);
            e = n + r;
            return a
        };
        t.cancelAnimationFrame = t.webkitCancelAnimationFrame || t.webkitCancelRequestAnimationFrame || function(t) {
            clearTimeout(t)
        }
    }
})(window);
(function(t, e, i) {
    if (e.FastClick) {
        return 
    }
    var s = function(t, e) {
        if (e.tagName === "LABEL") {
            if (e.parentNode) {
                e = e.parentNode.querySelector("input")
            }
        }
        if (e && (e.type === "radio" || e.type === "checkbox")) {
            if (!e.disabled) {
                return e
            }
        }
        return false
    };
    t.registerTarget({
        name: i,
        index: 40,
        handle: s,
        target: false
    });
    var n = function(i) {
        var s = t.targets.click;
        if (s) {
            var n, r;
            if (document.activeElement && document.activeElement !== s) {
                document.activeElement.blur()
            }
            r = i.detail.gesture.changedTouches[0];
            n = document.createEvent("MouseEvents");
            n.initMouseEvent("click", true, true, e, 1, r.screenX, r.screenY, r.clientX, r.clientY, false, false, false, false, 0, null);
            n.forwardedTouchEvent = true;
            s.dispatchEvent(n);
            i.detail && i.detail.gesture.preventDefault()
        }
    };
    e.addEventListener("tap", n);
    e.addEventListener("doubletap", n);
    e.addEventListener("click", function(e) {
        if (t.targets.click) {
            if (!e.forwardedTouchEvent) {
                if (e.stopImmediatePropagation) {
                    e.stopImmediatePropagation()
                } else {
                    e.propagationStopped = true
                }
                e.stopPropagation();
                e.preventDefault();
                return false
            }
        }
    }, true)
})(mui, window, "click");
(function(t, e) {
    t(function() {
        if (!t.os.ios) {
            return 
        }
        var i = "mui-focusin";
        var s = "mui-bar-tab";
        var n = "mui-bar-footer";
        var r = "mui-bar-footer-secondary";
        var a = "mui-bar-footer-secondary-tab";
        e.addEventListener("focusin", function(o) {
            if (t.os.plus) {
                if (window.plus) {
                    if (plus.webview.currentWebview().children().length > 0) {
                        return 
                    }
                }
            }
            var l = o.target;
            if (l.tagName && l.tagName === "INPUT" && (l.type === "text" || l.type === "search" || l.type === "number")) {
                if (l.disabled || l.readOnly) {
                    return 
                }
                e.body.classList.add(i);
                var c = false;
                for (; l && l !== e; l = l.parentNode) {
                    var f = l.classList;
                    if (f && f.contains(s) || f.contains(n) || f.contains(r) || f.contains(a)) {
                        c = true;
                        break
                    }
                }
                if (c) {
                    var u = e.body.scrollHeight;
                    var h = e.body.scrollLeft;
                    setTimeout(function() {
                        window.scrollTo(h, u)
                    }, 20)
                }
            }
        });
        e.addEventListener("focusout", function(t) {
            var s = e.body.classList;
            if (s.contains(i)) {
                s.remove(i);
                setTimeout(function() {
                    window.scrollTo(e.body.scrollLeft, e.body.scrollTop)
                }, 20)
            }
        })
    })
})(mui, document);
(function(t) {
    t.namespace = "mui";
    t.classNamePrefix = t.namespace + "-";
    t.classSelectorPrefix = "." + t.classNamePrefix;
    t.className = function(e) {
        return t.classNamePrefix + e
    };
    t.classSelector = function(e) {
        return e.replace(/\./g, t.classSelectorPrefix)
    };
    t.eventName = function(e, i) {
        return e + (t.namespace ? "." + t.namespace : "") + (i ? "." + i : "")
    }
})(mui);
(function(t) {
    var e = 1;
    var i = {};
    var s = {
        preventDefault: "isDefaultPrevented",
        stopImmediatePropagation: "isImmediatePropagationStopped",
        stopPropagation: "isPropagationStopped"
    };
    var n = function() {
        return true
    };
    var r = function() {
        return false
    };
    var a = function(e, i) {
        if (!e.detail) {
            e.detail = {
                currentTarget: i
            }
        } else {
            e.detail.currentTarget = i
        }
        t.each(s, function(t, i) {
            var s = e[t];
            e[t] = function() {
                this[i] = n;
                return s && s.apply(e, arguments)
            };
            e[i] = r
        }, true);
        return e
    };
    var o = function(t) {
        return t && (t._mid || (t._mid = e++))
    };
    var l = {};
    var c = function(e, s, n, r) {
        return function(n) {
            var r = i[e._mid][s];
            var o = [];
            var l = n.target;
            var c = {};
            for (; l && l !== document; l = l.parentNode) {
                if (l === e) {
                    break
                }
                if (~["click", "tap", "doubletap", "longtap", "hold"].indexOf(s) && (l.disabled || l.classList.contains("mui-disabled"))) {
                    break
                }
                var f = {};
                t.each(r, function(i, s) {
                    c[i] || (c[i] = t.qsa(i, e));
                    if (c[i]&&~c[i].indexOf(l)) {
                        if (!f[i]) {
                            f[i] = s
                        }
                    }
                }, true);
                if (!t.isEmptyObject(f)) {
                    o.push({
                        element: l,
                        handlers: f
                    })
                }
            }
            c = null;
            n = a(n);
            t.each(o, function(e, i) {
                l = i.element;
                var r = l.tagName;
                if (s === "tap" && (r !== "INPUT" && r !== "TEXTAREA" && r !== "SELECT")) {
                    n.preventDefault();
                    n.detail && n.detail.gesture && n.detail.gesture.preventDefault()
                }
                t.each(i.handlers, function(e, i) {
                    t.each(i, function(t, e) {
                        if (e.call(l, n) === false) {
                            n.preventDefault();
                            n.stopPropagation()
                        }
                    }, true)
                }, true);
                if (n.isPropagationStopped()) {
                    return false
                }
            }, true)
        }
    };
    var f = function(t, e) {
        var i = l[o(t)];
        var s = false;
        if (i) {
            s = [];
            if (e) {
                var n = function(t) {
                    return t.type === e
                };
                return i.filter(n)
            } else {
                s = i
            }
        }
        return s
    };
    var u = /^(INPUT|TEXTAREA|BUTTON|SELECT)$/;
    t.fn.on = function(e, s, n) {
        return this.each(function() {
            var r = this;
            o(r);
            o(n);
            var a = false;
            var f = i[r._mid] || (i[r._mid] = {});
            var h = f[e] || (f[e] = {});
            if (t.isEmptyObject(h)) {
                a = true
            }
            var d = h[s] || (h[s] = []);
            d.push(n);
            if (a) {
                var p = l[o(r)];
                if (!p) {
                    p = []
                }
                var v = c(r, e, s, n);
                p.push(v);
                v.i = p.length - 1;
                v.type = e;
                l[o(r)] = p;
                r.addEventListener(e, v);
                if (e === "tap") {
                    r.addEventListener("click", function(t) {
                        if (t.target) {
                            var e = t.target.tagName;
                            if (!u.test(e)) {
                                if (e === "A") {
                                    var i = t.target.href;
                                    if (!(i&&~i.indexOf("tel:"))) {
                                        t.preventDefault()
                                    }
                                } else {
                                    t.preventDefault()
                                }
                            }
                        }
                    })
                }
            }
        })
    };
    t.fn.off = function(e, s, n) {
        return this.each(function() {
            var r = o(this);
            if (!e) {
                i[r] && delete i[r]
            } else if (!s) {
                i[r] && delete i[r][e]
            } else if (!n) {
                i[r] && i[r][e] && delete i[r][e][s]
            } else {
                var a = i[r] && i[r][e] && i[r][e][s];
                t.each(a, function(t, e) {
                    if (o(e) === o(n)) {
                        a.splice(t, 1);
                        return false
                    }
                }, true)
            }
            if (i[r]) {
                if (!i[r][e] || t.isEmptyObject(i[r][e])) {
                    f(this, e).forEach(function(t) {
                        this.removeEventListener(t.type, t);
                        delete l[r][t.i]
                    }.bind(this))
                }
            } else {
                f(this).forEach(function(t) {
                    this.removeEventListener(t.type, t);
                    delete l[r][t.i]
                }.bind(this))
            }
        })
    }
})(mui);
(function(t, e) {
    t.EVENT_START = "touchstart";
    t.EVENT_MOVE = "touchmove";
    t.EVENT_END = "touchend";
    t.EVENT_CANCEL = "touchcancel";
    t.EVENT_CLICK = "click";
    t.gestures = {
        session: {}
    };
    t.preventDefault = function(t) {
        t.preventDefault()
    };
    t.stopPropagation = function(t) {
        t.stopPropagation()
    };
    t.addGesture = function(e) {
        return t.addAction("gestures", e)
    };
    var i = Math.round;
    var s = Math.abs;
    var n = Math.sqrt;
    var r = Math.atan;
    var a = Math.atan2;
    var o = function(t, e, i) {
        if (!i) {
            i = ["x", "y"]
        }
        var s = e[i[0]] - t[i[0]];
        var r = e[i[1]] - t[i[1]];
        return n(s * s + r * r)
    };
    var l = function(t, e) {
        if (t.length >= 2 && e.length >= 2) {
            var i = ["pageX", "pageY"];
            return o(e[1], e[0], i) / o(t[1], t[0], i)
        }
        return 1
    };
    var c = function(t, e, i) {
        if (!i) {
            i = ["x", "y"]
        }
        var s = e[i[0]] - t[i[0]];
        var n = e[i[1]] - t[i[1]];
        return a(n, s) * 180 / Math.PI
    };
    var f = function(t, e) {
        if (t === e) {
            return ""
        }
        if (s(t) >= s(e)) {
            return t > 0 ? "left" : "right"
        }
        return e > 0 ? "up" : "down"
    };
    var u = function(t, e) {
        var i = ["pageX", "pageY"];
        return c(e[1], e[0], i) - c(t[1], t[0], i)
    };
    var h = function(t, e, i) {
        return {
            x: e / t || 0,
            y: i / t || 0
        }
    };
    var d = function(e, i) {
        if (t.gestures.stoped) {
            return 
        }
        t.doAction("gestures", function(s, n) {
            if (!t.gestures.stoped) {
                if (t.options.gestureConfig[n.name] !== false) {
                    n.handle(e, i)
                }
            }
        })
    };
    var p = function(t, e) {
        while (t) {
            if (t == e) {
                return true
            }
            t = t.parentNode
        }
        return false
    };
    var v = function(t, e, i) {
        var s = [];
        var n = [];
        var r = 0;
        while (r < t.length) {
            var a = e ? t[r][e]: t[r];
            if (n.indexOf(a) < 0) {
                s.push(t[r])
            }
            n[r] = a;
            r++
        }
        if (i) {
            if (!e) {
                s = s.sort()
            } else {
                s = s.sort(function o(t, i) {
                    return t[e] > i[e]
                })
            }
        }
        return s
    };
    var g = function(t) {
        var e = t.length;
        if (e === 1) {
            return {
                x: i(t[0].pageX),
                y: i(t[0].pageY)
            }
        }
        var s = 0;
        var n = 0;
        var r = 0;
        while (r < e) {
            s += t[r].pageX;
            n += t[r].pageY;
            r++
        }
        return {
            x: i(s / e),
            y: i(n / e)
        }
    };
    var m = function() {
        return t.options.gestureConfig.pinch
    };
    var w = function(e) {
        var s = [];
        var n = 0;
        while (n < e.touches.length) {
            s[n] = {
                pageX: i(e.touches[n].pageX),
                pageY: i(e.touches[n].pageY)
            };
            n++
        }
        return {
            timestamp: t.now(),
            gesture: e.gesture,
            touches: s,
            center: g(e.touches),
            deltaX: e.deltaX,
            deltaY: e.deltaY
        }
    };
    var b = function(e) {
        var i = t.gestures.session;
        var s = e.center;
        var n = i.offsetDelta || {};
        var r = i.prevDelta || {};
        var a = i.prevTouch || {};
        if (e.gesture.type === t.EVENT_START || e.gesture.type === t.EVENT_END) {
            r = i.prevDelta = {
                x: a.deltaX || 0,
                y: a.deltaY || 0
            };
            n = i.offsetDelta = {
                x: s.x,
                y: s.y
            }
        }
        e.deltaX = r.x + (s.x - n.x);
        e.deltaY = r.y + (s.y - n.y)
    };
    var y = function(e) {
        var i = t.gestures.session;
        var s = e.touches;
        var n = s.length;
        if (!i.firstTouch) {
            i.firstTouch = w(e)
        }
        if (m() && n > 1&&!i.firstMultiTouch) {
            i.firstMultiTouch = w(e)
        } else if (n === 1) {
            i.firstMultiTouch = false
        }
        var r = i.firstTouch;
        var a = i.firstMultiTouch;
        var h = a ? a.center: r.center;
        var d = e.center = g(s);
        e.timestamp = t.now();
        e.deltaTime = e.timestamp - r.timestamp;
        e.angle = c(h, d);
        e.distance = o(h, d);
        b(e);
        e.offsetDirection = f(e.deltaX, e.deltaY);
        e.scale = a ? l(a.touches, s) : 1;
        e.rotation = a ? u(a.touches, s) : 0;
        T(e)
    };
    var L = 25;
    var T = function(e) {
        var i = t.gestures.session;
        var n = i.lastInterval || e;
        var r = e.timestamp - n.timestamp;
        var a;
        var o;
        var l;
        var c;
        if (e.gesture.type != t.EVENT_CANCEL && (r > L || n.velocity === undefined)) {
            var u = n.deltaX - e.deltaX;
            var d = n.deltaY - e.deltaY;
            var p = h(r, u, d);
            o = p.x;
            l = p.y;
            a = s(p.x) > s(p.y) ? p.x : p.y;
            c = f(u, d) || n.direction;
            i.lastInterval = e
        } else {
            a = n.velocity;
            o = n.velocityX;
            l = n.velocityY;
            c = n.direction
        }
        e.velocity = a;
        e.velocityX = o;
        e.velocityY = l;
        e.direction = c
    };
    var x = {};
    var E = function(e, i) {
        var s = t.slice.call(e.touches || e);
        var n = e.type;
        var r = [];
        var a = [];
        if ((n === t.EVENT_START || n === t.EVENT_MOVE) && s.length === 1) {
            x[s[0].identifier] = true;
            r = s;
            a = s;
            i.target = e.target
        } else {
            var o = 0;
            var r = [];
            var a = [];
            var l = t.slice.call(e.changedTouches || e);
            i.target = e.target;
            var c = t.gestures.session.target || e.target;
            r = s.filter(function(t) {
                return p(t.target, c)
            });
            if (n === t.EVENT_START) {
                o = 0;
                while (o < r.length) {
                    x[r[o].identifier] = true;
                    o++
                }
            }
            o = 0;
            while (o < l.length) {
                if (x[l[o].identifier]) {
                    a.push(l[o])
                }
                if (n === t.EVENT_END || n === t.EVENT_CANCEL) {
                    delete x[l[o].identifier]
                }
                o++
            }
            if (!a.length) {
                return false
            }
        }
        r = v(r.concat(a), "identifier", true);
        var f = r.length;
        var u = a.length;
        if (n === t.EVENT_START && f - u === 0) {
            i.isFirst = true;
            t.gestures.touch = t.gestures.session = {
                target: e.target
            }
        }
        i.isFinal = (n === t.EVENT_END || n === t.EVENT_CANCEL) && f - u === 0;
        i.touches = r;
        i.changedTouches = a;
        return true
    };
    var S = function(e) {
        var i = {
            gesture: e
        };
        var s = E(e, i);
        if (!s) {
            return 
        }
        y(i);
        d(e, i);
        t.gestures.session.prevTouch = i
    };
    e.addEventListener(t.EVENT_START, S);
    e.addEventListener(t.EVENT_MOVE, S);
    e.addEventListener(t.EVENT_END, S);
    e.addEventListener(t.EVENT_CANCEL, S);
    e.addEventListener(t.EVENT_CLICK, function(e) {
        if (t.targets.popover && e.target === t.targets.popover || t.targets.tab || t.targets.offcanvas || t.targets.modal) {
            e.preventDefault()
        }
    }, true);
    t.isScrolling = false;
    var k = null;
    e.addEventListener("scroll", function() {
        t.isScrolling = true;
        k && clearTimeout(k);
        k = setTimeout(function() {
            t.isScrolling = false
        }, 250)
    })
})(mui, window);
(function(t, e) {
    var i = 0;
    var s = function(s, n) {
        var r = t.gestures.session;
        var a = this.options;
        var o = t.now();
        switch (s.type) {
        case t.EVENT_MOVE:
            if (o - i > 300) {
                i = o;
                r.flickStart = n.center
            }
            break;
        case t.EVENT_END:
        case t.EVENT_CANCEL:
            if (r.flickStart && a.flickMaxTime > o - i && n.distance > a.flickMinDistince) {
                n.flick = true;
                n.flickTime = o - i;
                n.flickDistanceX = n.center.x - r.flickStart.x;
                n.flickDistanceY = n.center.y - r.flickStart.y;
                t.trigger(r.target, e, n);
                t.trigger(r.target, e + n.direction, n)
            }
            break
        }
    };
    t.addGesture({
        name: e,
        index: 5,
        handle: s,
        options: {
            flickMaxTime: 200,
            flickMinDistince: 10
        }
    })
})(mui, "flick");
(function(t, e) {
    var i = function(i, s) {
        var n = t.gestures.session;
        if (i.type === t.EVENT_END || i.type === t.EVENT_CANCEL) {
            var r = this.options;
            if (s.direction && r.swipeMaxTime > s.deltaTime && s.distance > r.swipeMinDistince) {
                s.swipe = true;
                t.trigger(n.target, e, s);
                t.trigger(n.target, e + s.direction, s)
            }
        }
    };
    t.addGesture({
        name: e,
        index: 10,
        handle: i,
        options: {
            swipeMaxTime: 300,
            swipeMinDistince: 18
        }
    })
})(mui, "swipe");
(function(t, e) {
    var i = function(i, s) {
        var n = t.gestures.session;
        switch (i.type) {
        case t.EVENT_START:
            break;
        case t.EVENT_MOVE:
            if (!s.direction) {
                return 
            }
            if (n.lockDirection && n.startDirection) {
                if (n.startDirection && n.startDirection !== s.direction) {
                    if (n.startDirection === "up" || n.startDirection === "down") {
                        s.direction = s.deltaY < 0 ? "up" : "down"
                    } else {
                        s.direction = s.deltaX < 0 ? "left" : "right"
                    }
                }
            }
            if (!n.drag) {
                n.drag = true;
                t.trigger(n.target, e + "start", s)
            }
            t.trigger(n.target, e, s);
            t.trigger(n.target, e + s.direction, s);
            break;
        case t.EVENT_END:
        case t.EVENT_CANCEL:
            if (n.drag && s.isFinal) {
                t.trigger(n.target, e + "end", s)
            }
            break
        }
    };
    t.addGesture({
        name: e,
        index: 20,
        handle: i,
        options: {
            fingers: 1
        }
    })
})(mui, "drag");
(function(t, e) {
    var i;
    var s;
    var n = function(n, r) {
        var a = t.gestures.session;
        var o = this.options;
        switch (n.type) {
        case t.EVENT_END:
            if (!r.isFinal) {
                return 
            }
            var l = a.target;
            if (!l || (l.disabled || l.classList && l.classList.contains("mui-disabled"))) {
                return 
            }
            if (r.distance < o.tapMaxDistance && r.deltaTime < o.tapMaxTime) {
                if (t.options.gestureConfig.doubletap && i && i === l) {
                    if (s && r.timestamp - s < o.tapMaxInterval) {
                        t.trigger(l, "doubletap", r);
                        s = t.now();
                        i = l;
                        return 
                    }
                }
                t.trigger(l, e, r);
                s = t.now();
                i = l
            }
            break
        }
    };
    t.addGesture({
        name: e,
        index: 30,
        handle: n,
        options: {
            fingers: 1,
            tapMaxInterval: 300,
            tapMaxDistance: 5,
            tapMaxTime: 250
        }
    })
})(mui, "tap");
(function(t, e) {
    var i;
    var s = function(s, n) {
        var r = t.gestures.session;
        var a = this.options;
        switch (s.type) {
        case t.EVENT_START:
            clearTimeout(i);
            i = setTimeout(function() {
                t.trigger(r.target, e, n)
            }, a.holdTimeout);
            break;
        case t.EVENT_MOVE:
            if (n.distance > a.holdThreshold) {
                clearTimeout(i)
            }
            break;
        case t.EVENT_END:
        case t.EVENT_CANCEL:
            clearTimeout(i);
            break
        }
    };
    t.addGesture({
        name: e,
        index: 10,
        handle: s,
        options: {
            fingers: 1,
            holdTimeout: 500,
            holdThreshold: 2
        }
    })
})(mui, "longtap");
(function(t, e) {
    var i;
    var s = function(s, n) {
        var r = t.gestures.session;
        var a = this.options;
        switch (s.type) {
        case t.EVENT_START:
            if (t.options.gestureConfig.hold) {
                i && clearTimeout(i);
                i = setTimeout(function() {
                    n.hold = true;
                    t.trigger(r.target, e, n)
                }, a.holdTimeout)
            }
            break;
        case t.EVENT_MOVE:
            break;
        case t.EVENT_END:
        case t.EVENT_CANCEL:
            if (i) {
                clearTimeout(i) && (i = null);
                t.trigger(r.target, "release", n)
            }
            break
        }
    };
    t.addGesture({
        name: e,
        index: 10,
        handle: s,
        options: {
            fingers: 1,
            holdTimeout: 0
        }
    })
})(mui, "hold");
(function(t, e) {
    var i = function(i, s) {
        var n = this.options;
        var r = t.gestures.session;
        switch (i.type) {
        case t.EVENT_START:
            break;
        case t.EVENT_MOVE:
            if (t.options.gestureConfig.pinch) {
                if (s.touches.length < 2) {
                    return 
                }
                if (!r.pinch) {
                    r.pinch = true;
                    t.trigger(r.target, e + "start", s)
                }
                t.trigger(r.target, e, s);
                var a = s.scale;
                var o = s.rotation;
                var l = typeof s.lastScale === "undefined" ? 1: s.lastScale;
                var c = 1e-12;
                if (a > l) {
                    l = a - c;
                    t.trigger(r.target, e + "out", s)
                } else if (a < l) {
                    l = a + c;
                    t.trigger(r.target, e + "in", s)
                }
                if (Math.abs(o) > n.minRotationAngle) {
                    t.trigger(r.target, "rotate", s)
                }
            }
            break;
        case t.EVENT_END:
        case t.EVENT_CANCEL:
            if (t.options.gestureConfig.pinch && r.pinch && s.touches.length === 2) {
                r.pinch = false;
                t.trigger(r.target, e + "end", s)
            }
            break
        }
    };
    t.addGesture({
        name: e,
        index: 10,
        handle: i,
        options: {
            minRotationAngle: 0
        }
    })
})(mui, "pinch");
(function(t) {
    t.global = t.options = {
        gestureConfig: {
            tap: true,
            doubletap: false,
            longtap: false,
            hold: false,
            flick: true,
            swipe: true,
            drag: true,
            pinch: false
        }
    };
    t.initGlobal = function(e) {
        t.options = t.extend(true, t.global, e);
        return this
    };
    var e = {};
    var i = false;
    t.init = function(s) {
        i = true;
        t.options = t.extend(true, t.global, s || {});
        t.ready(function() {
            t.doAction("inits", function(i, s) {
                var n=!!(!e[s.name] || s.repeat);
                if (n) {
                    s.handle.call(t);
                    e[s.name] = true
                }
            })
        });
        return this
    };
    t.addInit = function(e) {
        return t.addAction("inits", e)
    };
    t(function() {
        var e = document.body.classList;
        var i = [];
        if (t.os.ios) {
            i.push({
                os: "ios",
                version: t.os.version
            });
            e.add("mui-ios")
        } else if (t.os.android) {
            i.push({
                os: "android",
                version: t.os.version
            });
            e.add("mui-android")
        }
        if (t.os.wechat) {
            i.push({
                os: "wechat",
                version: t.os.wechat.version
            });
            e.add("mui-wechat")
        }
        if (i.length) {
            t.each(i, function(i, s) {
                var n = "";
                var r = [];
                if (s.version) {
                    t.each(s.version.split("."), function(i, r) {
                        n = n + (n ? "-" : "") + r;
                        e.add(t.className(s.os + "-" + n))
                    })
                }
            })
        }
    })
})(mui);
(function(t) {
    var e = {
        swipeBack: false,
        preloadPages: [],
        preloadLimit: 10,
        keyEventBind: {
            backbutton: true,
            menubutton: true
        }
    };
    var i = {
        autoShow: true,
        duration: t.os.ios ? 200: 100,
        aniShow: "slide-in-right"
    };
    if (t.options.show) {
        i = t.extend(true, i, t.options.show)
    }
    t.currentWebview = null;
    t.isHomePage = false;
    t.extend(true, t.global, e);
    t.extend(true, t.options, e);
    t.waitingOptions = function(e) {
        return t.extend({
            autoShow: true,
            title: ""
        }, e)
    };
    t.showOptions = function(e) {
        return t.extend(true, {}, i, e)
    };
    t.windowOptions = function(e) {
        return t.extend({
            scalable: false,
            bounce: ""
        }, e)
    };
    t.plusReady = function(t) {
        if (window.plus) {
            setTimeout(function() {
                t()
            }, 0)
        } else {
            document.addEventListener("plusready", function() {
                t()
            }, false)
        }
        return this
    };
    t.fire = function(e, i, s) {
        if (e) {
            if (s !== "") {
                s = s || {};
                if (t.isPlainObject(s)) {
                    s = JSON.stringify(s || {}).replace(/\'/g, "\\u0027").replace(/\\/g, "\\u005c")
                }
            }
            e.evalJS("typeof mui!=='undefined'&&mui.receive('" + i + "','" + s + "')")
        }
    };
    t.receive = function(e, i) {
        if (e) {
            try {
                if (i) {
                    i = JSON.parse(i)
                }
            } catch (s) {}
            t.trigger(document, e, i)
        }
    };
    var s = function(e) {
        if (!e.preloaded) {
            t.fire(e, "preload");
            var i = e.children();
            for (var s = 0; s < i.length; s++) {
                t.fire(i[s], "preload")
            }
            e.preloaded = true
        }
    };
    var n = function(e, i, s) {
        if (s) {
            if (!e[i + "ed"]) {
                t.fire(e, i);
                var n = e.children();
                for (var r = 0; r < n.length; r++) {
                    t.fire(n[r], i)
                }
                e[i + "ed"] = true
            }
        } else {
            t.fire(e, i);
            var n = e.children();
            for (var r = 0; r < n.length; r++) {
                t.fire(n[r], i)
            }
        }
    };
    t.openWindow = function(e, i, r) {
        if (!window.plus) {
            return 
        }
        if (typeof e === "object") {
            r = e;
            e = r.url;
            i = r.id || e
        } else {
            if (typeof i === "object") {
                r = i;
                i = e
            } else {
                i = i || e
            }
        }
        r = r || {};
        var a = r.params || {};
        var o, l, c;
        if (t.webviews[i]) {
            var f = t.webviews[i];
            o = f.webview;
            if (!o ||!o.getURL()) {
                r = t.extend(r, {
                    id: i,
                    url: e,
                    preload: true
                }, true);
                o = t.createWindow(r)
            }
            l = f.show;
            l = r.show ? t.extend(l, r.show) : l;
            o.show(l.aniShow, l.duration, function() {
                s(o);
                n(o, "pagebeforeshow", false)
            });
            f.afterShowMethodName && o.evalJS(f.afterShowMethodName + "('" + JSON.stringify(a) + "')");
            return o
        } else {
            if (r.createNew !== true) {
                o = plus.webview.getWebviewById(i);
                if (o) {
                    l = t.showOptions(r.show);
                    o.show(l.aniShow, l.duration, function() {
                        s(o);
                        n(o, "pagebeforeshow", false)
                    });
                    return o
                }
            }
            var u = t.waitingOptions(r.waiting);
            if (u.autoShow) {
                c = plus.nativeUI.showWaiting(u.title, u.options)
            }
            r = t.extend(r, {
                id: i,
                url: e
            });
            o = t.createWindow(r);
            l = t.showOptions(r.show);
            if (l.autoShow) {
                o.addEventListener("loaded", function() {
                    if (c) {
                        c.close()
                    }
                    o.show(l.aniShow, l.duration, function() {
                        s(o);
                        n(o, "pagebeforeshow", false)
                    });
                    o.showed = true;
                    r.afterShowMethodName && o.evalJS(r.afterShowMethodName + "('" + JSON.stringify(a) + "')")
                }, false)
            }
        }
        return o
    };
    t.createWindow = function(e, i) {
        if (!window.plus) {
            return 
        }
        var s = e.id || e.url;
        var n;
        if (e.preload) {
            if (t.webviews[s] && t.webviews[s].webview.getURL()) {
                n = t.webviews[s].webview
            } else {
                if (e.createNew !== true) {
                    n = plus.webview.getWebviewById(s)
                }
                if (!n) {
                    n = plus.webview.create(e.url, s, t.windowOptions(e.styles), t.extend({
                        preload: true
                    }, e.extras));
                    if (e.subpages) {
                        t.each(e.subpages, function(e, i) {
                            var s = plus.webview.create(i.url, i.id || i.url, t.windowOptions(i.styles), t.extend({
                                preload: true
                            }, i.extras));
                            n.append(s)
                        })
                    }
                }
            }
            t.webviews[s] = {
                webview: n,
                preload: true,
                show: t.showOptions(e.show),
                afterShowMethodName: e.afterShowMethodName
            };
            var r = t.data.preloads;
            var a = r.indexOf(s);
            if (~a) {
                r.splice(a, 1)
            }
            r.push(s);
            if (r.length > t.options.preloadLimit) {
                var o = t.data.preloads.shift();
                var l = t.webviews[o];
                if (l && l.webview) {
                    t.closeAll(l.webview)
                }
                delete t.webviews[o]
            }
        } else {
            if (i !== false) {
                n = plus.webview.create(e.url, s, t.windowOptions(e.styles), e.extras);
                if (e.subpages) {
                    t.each(e.subpages, function(e, i) {
                        var s = plus.webview.create(i.url, i.id || i.url, t.windowOptions(i.styles), i.extras);
                        n.append(s)
                    })
                }
            }
        }
        return n
    };
    t.preload = function(e) {
        if (!e.preload) {
            e.preload = true
        }
        return t.createWindow(e)
    };
    t.closeOpened = function(e) {
        var i = e.opened();
        if (i) {
            for (var s = 0, n = i.length; s < n; s++) {
                var r = i[s];
                var a = r.opened();
                if (a && a.length > 0) {
                    t.closeOpened(r)
                } else {
                    if (r.parent() !== e) {
                        r.close("none")
                    }
                }
            }
        }
    };
    t.closeAll = function(e, i) {
        t.closeOpened(e);
        if (i) {
            e.close(i)
        } else {
            e.close()
        }
    };
    t.createWindows = function(e) {
        t.each(e, function(e, i) {
            t.createWindow(i, false)
        })
    };
    t.appendWebview = function(e) {
        if (!window.plus) {
            return 
        }
        var i = e.id || e.url;
        var s;
        if (!t.webviews[i]) {
            s = plus.webview.create(e.url, i, e.styles, e.extras);
            plus.webview.currentWebview().append(s);
            t.webviews[i] = e
        }
        return s
    };
    t.webviews = {};
    t.data.preloads = [];
    t.plusReady(function() {
        t.currentWebview = plus.webview.currentWebview()
    });
    t.addInit({
        name: "5+",
        index: 100,
        handle: function() {
            var e = t.options;
            var i = e.subpages || [];
            if (t.os.plus) {
                t.plusReady(function() {
                    t.each(i, function(e, i) {
                        t.appendWebview(i)
                    });
                    if (plus.webview.currentWebview() === plus.webview.getWebviewById(plus.runtime.appid)) {
                        t.isHomePage = true;
                        setTimeout(function() {
                            s(plus.webview.currentWebview())
                        }, 300)
                    }
                    if (t.os.ios && t.options.statusBarBackground) {
                        plus.navigator.setStatusBarBackground(t.options.statusBarBackground)
                    }
                    if (t.os.android && parseFloat(t.os.version) < 4.4) {
                        if (plus.webview.currentWebview().parent() == null) {
                            document.addEventListener("resume", function() {
                                var t = document.body;
                                t.style.display = "none";
                                setTimeout(function() {
                                    t.style.display = ""
                                }, 10)
                            })
                        }
                    }
                })
            } else {
                if (i.length > 0) {
                    var n = document.createElement("div");
                    n.className = "mui-error";
                    var r = document.createElement("span");
                    r.innerHTML = "&#22312;&#35813;&#27983;&#35272;&#22120;&#19979;&#65292;&#19981;&#25903;&#25345;&#21019;&#24314;&#23376;&#39029;&#38754;&#65292;&#20855;&#20307;&#21442;&#32771;";
                    n.appendChild(r);
                    var a = document.createElement("a");
                    a.innerHTML = '"&#109;&#117;&#105;&#26694;&#26550;&#36866;&#29992;&#22330;&#26223;"';
                    a.href = "http://ask.dcloud.net.cn/article/113";
                    n.appendChild(a);
                    document.body.appendChild(n);
                    console.log("&#22312;&#35813;&#27983;&#35272;&#22120;&#19979;&#65292;&#19981;&#25903;&#25345;&#21019;&#24314;&#23376;&#39029;&#38754;")
                }
            }
        }
    });
    window.addEventListener("preload", function() {
        var e = t.options.preloadPages || [];
        t.plusReady(function() {
            t.each(e, function(e, i) {
                t.createWindow(t.extend(i, {
                    preload: true
                }))
            })
        })
    })
})(mui);
(function(t, e) {
    t.addBack = function(e) {
        return t.addAction("backs", e)
    };
    t.addBack({
        name: "browser",
        index: 100,
        handle: function() {
            if (e.history.length > 1) {
                e.history.back();
                return true
            }
            return false
        }
    });
    t.back = function() {
        if (typeof t.options.beforeback === "function") {
            if (t.options.beforeback() === false) {
                return 
            }
        }
        t.doAction("backs")
    };
    e.addEventListener("tap", function(e) {
        var i = t.targets.action;
        if (i && i.classList.contains("mui-action-back")) {
            t.back()
        }
    });
    e.addEventListener("swiperight", function(e) {
        var i = e.detail;
        if (t.options.swipeBack === true && Math.abs(i.angle) < 3) {
            t.back()
        }
    })
})(mui, window);
(function(t, e) {
    if (t.os.plus && t.os.android) {
        t.addBack({
            name: "mui",
            index: 5,
            handle: function() {
                if (t.targets._popover && t.targets._popover.classList.contains("mui-active")) {
                    t(t.targets._popover).popover("hide");
                    return true
                }
                var e = document.querySelector(".mui-off-canvas-wrap.mui-active");
                if (e) {
                    t(e).offCanvas("close");
                    return true
                }
                var i = t.isFunction(t.getPreviewImage) && t.getPreviewImage();
                if (i && i.isShown()) {
                    i.close();
                    return true
                }
            }
        })
    }
    t.addBack({
        name: "5+",
        index: 10,
        handle: function() {
            if (!e.plus) {
                return false
            }
            var i = plus.webview.currentWebview();
            var s = i.parent();
            if (s) {
                s.evalJS("mui&&mui.back();")
            } else {
                i.canBack(function(s) {
                    if (s.canBack) {
                        e.history.back()
                    } else {
                        if (i.id === plus.runtime.appid) {} else {
                            if (i.preload) {
                                i.hide("auto")
                            } else {
                                t.closeAll(i)
                            }
                        }
                    }
                })
            }
            return true
        }
    });
    t.menu = function() {
        var i = document.querySelector(".mui-action-menu");
        if (i) {
            t.trigger(i, "touchstart");
            t.trigger(i, "tap")
        } else {
            if (e.plus) {
                var s = t.currentWebview;
                var n = s.parent();
                if (n) {
                    n.evalJS("mui&&mui.menu();")
                }
            }
        }
    };
    var i = function() {
        t.back()
    };
    var s = function() {
        t.menu()
    };
    t.plusReady(function() {
        if (t.options.keyEventBind.backbutton) {
            plus.key.addEventListener("backbutton", i, false)
        }
        if (t.options.keyEventBind.menubutton) {
            plus.key.addEventListener("menubutton", s, false)
        }
    });
    t.addInit({
        name: "keyEventBind",
        index: 1e3,
        handle: function() {
            t.plusReady(function() {
                if (!t.options.keyEventBind.backbutton) {
                    plus.key.removeEventListener("backbutton", i)
                }
                if (!t.options.keyEventBind.menubutton) {
                    plus.key.removeEventListener("menubutton", s)
                }
            })
        }
    })
})(mui, window);
(function(t) {
    t.addInit({
        name: "pullrefresh",
        index: 1e3,
        handle: function() {
            var e = t.options;
            var i = e.pullRefresh || {};
            var s = i.down && i.down.hasOwnProperty("callback");
            var n = i.up && i.up.hasOwnProperty("callback");
            if (s || n) {
                var r = i.container;
                if (r) {
                    var a = t(r);
                    if (a.length === 1) {
                        if (t.os.plus && t.os.android) {
                            t.plusReady(function() {
                                var e = plus.webview.currentWebview();
                                if (n) {
                                    var r = {};
                                    r.up = i.up;
                                    r.webviewId = e.id || e.getURL();
                                    a.pullRefresh(r)
                                }
                                if (s) {
                                    var o = e.parent();
                                    var l = e.id || e.getURL();
                                    if (o) {
                                        if (!n) {
                                            a.pullRefresh({
                                                webviewId: l
                                            })
                                        }
                                        var c = {
                                            webviewId: l
                                        };
                                        c.down = t.extend({}, i.down);
                                        c.down.callback = "_CALLBACK";
                                        o.evalJS("mui&&mui(document.querySelector('.mui-content')).pullRefresh('" + JSON.stringify(c) + "')")
                                    }
                                }
                            })
                        } else {
                            a.pullRefresh(i)
                        }
                    }
                }
            }
        }
    })
})(mui);
(function(t, e, i) {
    var s = "application/json";
    var n = "text/html";
    var r = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;
    var a = /^(?:text|application)\/javascript/i;
    var o = /^(?:text|application)\/xml/i;
    var l = /^\s*$/;
    t.ajaxSettings = {
        type: "GET",
        beforeSend: t.noop,
        success: t.noop,
        error: t.noop,
        complete: t.noop,
        context: null,
        xhr: function(t) {
            return new e.XMLHttpRequest
        },
        accepts: {
            script: "text/javascript, application/javascript, application/x-javascript",
            json: s,
            xml: "application/xml, text/xml",
            html: n,
            text: "text/plain"
        },
        timeout: 0,
        processData: true,
        cache: true
    };
    var c = function(t, e) {
        var i = e.context;
        if (e.beforeSend.call(i, t, e) === false) {
            return false
        }
    };
    var f = function(t, e, i) {
        i.success.call(i.context, t, "success", e);
        h("success", e, i)
    };
    var u = function(t, e, i, s) {
        s.error.call(s.context, i, e, t);
        h(e, i, s)
    };
    var h = function(t, e, i) {
        i.complete.call(i.context, e, t)
    };
    var d = function(e, i, s, n) {
        var r, a = t.isArray(i), o = t.isPlainObject(i);
        t.each(i, function(i, l) {
            r = t.type(l);
            if (n) {
                i = s ? n : n + "[" + (o || r === "object" || r === "array" ? i : "") + "]"
            }
            if (!n && a) {
                e.add(l.name, l.value)
            } else if (r === "array" ||!s && r === "object") {
                d(e, l, s, i)
            } else {
                e.add(i, l)
            }
        })
    };
    var p = function(e) {
        if (e.processData && e.data && typeof e.data !== "string") {
            e.data = t.param(e.data, e.traditional)
        }
        if (e.data && (!e.type || e.type.toUpperCase() === "GET")) {
            e.url = v(e.url, e.data);
            e.data = i
        }
    };
    var v = function(t, e) {
        if (e === "") {
            return t
        }
        return (t + "&" + e).replace(/[&?]{1,2}/, "?")
    };
    var g = function(t) {
        if (t) {
            t = t.split(";", 2)[0]
        }
        return t && (t === n ? "html" : t === s ? "json" : a.test(t) ? "script" : o.test(t) && "xml") || "text"
    };
    var m = function(e, s, n, r) {
        if (t.isFunction(s)) {
            r = n, n = s, s = i
        }
        if (!t.isFunction(n)) {
            r = n, n = i
        }
        return {
            url: e,
            data: s,
            success: n,
            dataType: r
        }
    };
    t.ajax = function(s, n) {
        if (typeof s === "object") {
            n = s;
            s = i
        }
        var r = n || {};
        r.url = s || r.url;
        for (var a in t.ajaxSettings) {
            if (r[a] === i) {
                r[a] = t.ajaxSettings[a]
            }
        }
        p(r);
        var o = r.dataType;
        if (r.cache === false || (!n || n.cache !== true) && "script" === o) {
            r.url = v(r.url, "_=" + t.now())
        }
        var h = r.accepts[o];
        var d = {};
        var m = function(t, e) {
            d[t.toLowerCase()] = [t, e]
        };
        var w = /^([\w-]+:)\/\//.test(r.url) ? RegExp.$1: e.location.protocol;
        var b = r.xhr(r);
        var y = b.setRequestHeader;
        var L;
        m("X-Requested-With", "XMLHttpRequest");
        m("Accept", h || "*/*");
        if (!!(h = r.mimeType || h)) {
            if (h.indexOf(",")>-1) {
                h = h.split(",", 2)[0]
            }
            b.overrideMimeType && b.overrideMimeType(h)
        }
        if (r.contentType || r.contentType !== false && r.data && r.type.toUpperCase() !== "GET") {
            m("Content-Type", r.contentType || "application/x-www-form-urlencoded")
        }
        if (r.headers) {
            for (var T in r.headers)
                m(T, r.headers[T])
        }
        b.setRequestHeader = m;
        b.onreadystatechange = function() {
            if (b.readyState === 4) {
                b.onreadystatechange = t.noop;
                clearTimeout(L);
                var e, i = false;
                if (b.status >= 200 && b.status < 300 || b.status === 304 || b.status === 0 && w === "file:") {
                    o = o || g(r.mimeType || b.getResponseHeader("content-type"));
                    e = b.responseText;
                    try {
                        if (o === "script") {
                            (1, eval)(e)
                        } else if (o === "xml") {
                            e = b.responseXML
                        } else if (o === "json") {
                            e = l.test(e) ? null : t.parseJSON(e)
                        }
                    } catch (s) {
                        i = s
                    }
                    if (i) {
                        u(i, "parsererror", b, r)
                    } else {
                        f(e, b, r)
                    }
                } else {
                    u(b.statusText || null, b.status ? "error" : "abort", b, r)
                }
            }
        };
        if (c(b, r) === false) {
            b.abort();
            u(null, "abort", b, r);
            return b
        }
        if (r.xhrFields) {
            for (var T in r.xhrFields) {
                b[T] = r.xhrFields[T]
            }
        }
        var x = "async"in r ? r.async: true;
        b.open(r.type.toUpperCase(), r.url, x, r.username, r.password);
        for (var T in d) {
            y.apply(b, d[T])
        }
        if (r.timeout > 0) {
            L = setTimeout(function() {
                b.onreadystatechange = t.noop;
                b.abort();
                u(null, "timeout", b, r)
            }, r.timeout)
        }
        b.send(r.data ? r.data : null);
        return b
    };
    t.param = function(t, e) {
        var i = [];
        i.add = function(t, e) {
            this.push(encodeURIComponent(t) + "=" + encodeURIComponent(e))
        };
        d(i, t, e);
        return i.join("&").replace(/%20/g, "+")
    };
    t.get = function() {
        return t.ajax(m.apply(null, arguments))
    };
    t.post = function() {
        var e = m.apply(null, arguments);
        e.type = "POST";
        return t.ajax(e)
    };
    t.getJSON = function() {
        var e = m.apply(null, arguments);
        e.dataType = "json";
        return t.ajax(e)
    };
    t.fn.load = function(e, i, s) {
        if (!this.length)
            return this;
        var n = this, a = e.split(/\s/), o, l = m(e, i, s), c = l.success;
        if (a.length > 1)
            l.url = a[0], o = a[1];
        l.success = function(t) {
            if (o) {
                var e = document.createElement("div");
                e.innerHTML = t.replace(r, "");
                var i = document.createElement("div");
                var s = e.querySelectorAll(o);
                if (s && s.length > 0) {
                    for (var a = 0, l = s.length; a < l; a++) {
                        i.appendChild(s[a])
                    }
                }
                n[0].innerHTML = i.innerHTML
            } else {
                n[0].innerHTML = t
            }
            c && c.apply(n, arguments)
        };
        t.ajax(l);
        return this
    }
})(mui, window);
(function(t) {
    var e = document.createElement("a");
    e.href = window.location.href;
    t.plusReady(function() {
        t.ajaxSettings = t.extend(t.ajaxSettings, {
            xhr: function(t) {
                if (t.crossDomain) {
                    return new plus.net.XMLHttpRequest
                }
                if (e.protocol !== "file:") {
                    var i = document.createElement("a");
                    i.href = t.url;
                    i.href = i.href;
                    t.crossDomain = e.protocol + "//" + e.host !== i.protocol + "//" + i.host;
                    if (t.crossDomain) {
                        return new plus.net.XMLHttpRequest
                    }
                }
                return new window.XMLHttpRequest
            }
        })
    })
})(mui);
(function(t, e, i) {
    t.offset = function(t) {
        var s = {
            top: 0,
            left: 0
        };
        if (typeof t.getBoundingClientRect !== i) {
            s = t.getBoundingClientRect()
        }
        return {
            top: s.top + e.pageYOffset - t.clientTop,
            left: s.left + e.pageXOffset - t.clientLeft
        }
    }
})(mui, window);
(function(t, e) {
    t.scrollTo = function(t, i, s) {
        i = i || 1e3;
        var n = function(i) {
            if (i <= 0) {
                e.scrollTo(0, t);
                s && s();
                return 
            }
            var r = t - e.scrollY;
            setTimeout(function() {
                e.scrollTo(0, e.scrollY + r / i * 10);
                n(i - 10)
            }, 16.7)
        };
        n(i)
    };
    t.animationFrame = function(t) {
        var e, i, s;
        return function() {
            e = arguments;
            s = this;
            if (!i) {
                i = true;
                requestAnimationFrame(function() {
                    t.apply(s, e);
                    i = false
                })
            }
        }
    }
})(mui, window);
(function(t) {
    var e = false, i = /xyz/.test(function() {
        xyz
    }) ? /\b_super\b/: /.*/;
    var s = function() {};
    s.extend = function(t) {
        var s = this.prototype;
        e = true;
        var n = new this;
        e = false;
        for (var r in t) {
            n[r] = typeof t[r] == "function" && typeof s[r] == "function" && i.test(t[r]) ? function(t, e) {
                return function() {
                    var i = this._super;
                    this._super = s[t];
                    var n = e.apply(this, arguments);
                    this._super = i;
                    return n
                }
            }(r, t[r]) : t[r]
        }
        function a() {
            if (!e && this.init)
                this.init.apply(this, arguments)
        }
        a.prototype = n;
        a.prototype.constructor = a;
        a.extend = arguments.callee;
        return a
    };
    t.Class = s
})(mui);
(function(t, e, i) {
    var s = "mui-pull-top-pocket";
    var n = "mui-pull-bottom-pocket";
    var r = "mui-pull";
    var a = "mui-pull-loading";
    var o = "mui-pull-caption";
    var l = "mui-pull-caption-down";
    var c = "mui-pull-caption-refresh";
    var f = "mui-pull-caption-nomore";
    var u = "mui-icon";
    var h = "mui-spinner";
    var d = "mui-icon-pulldown";
    var p = "mui-block";
    var v = "mui-hidden";
    var g = "mui-visibility";
    var m = a + " " + u + " " + d;
    var w = a + " " + u + " " + d;
    var b = a + " " + u + " " + h;
    var y = ['<div class="' + r + '">', '<div class="{icon}"></div>', '<div class="' + o + '">{contentrefresh}</div>', "</div>"].join("");
    var L = {
        init: function(e, i) {
            this._super(e, t.extend(true, {
                scrollY: true,
                scrollX: false,
                indicators: true,
                deceleration: .003,
                down: {
                    height: 50,
                    contentdown: "&#19979;&#25289;&#21487;&#20197;&#21047;&#26032;",
                    contentover: "&#37322;&#25918;&#31435;&#21363;&#21047;&#26032;",
                    contentrefresh: "&#27491;&#22312;&#21047;&#26032;"
                },
                up: {
                    height: 50,
                    auto: !1,
                    contentdown: "&#19978;&#25289;&#26174;&#31034;&#26356;&#22810;",
                    contentrefresh: "&#27491;&#22312;&#21152;&#36733;",
                    contentnomore: "&#27809;&#26377;&#26356;&#22810;&#25968;&#25454;&#20102;",
                    duration: 300
                }
            }, i))
        },
        _init: function() {
            this._super();
            this._initPocket()
        },
        _initPulldownRefresh: function() {
            this.pulldown = true;
            this.pullPocket = this.topPocket;
            this.pullPocket.classList.add(p);
            this.pullPocket.classList.add(g);
            this.pullCaption = this.topCaption;
            this.pullLoading = this.topLoading
        },
        _initPullupRefresh: function() {
            this.pulldown = false;
            this.pullPocket = this.bottomPocket;
            this.pullPocket.classList.add(p);
            this.pullPocket.classList.add(g);
            this.pullCaption = this.bottomCaption;
            this.pullLoading = this.bottomLoading
        },
        _initPocket: function() {
            var t = this.options;
            if (t.down && t.down.hasOwnProperty("callback")) {
                this.topPocket = this.scroller.querySelector("." + s);
                if (!this.topPocket) {
                    this.topPocket = this._createPocket(s, t.down, w);
                    this.wrapper.insertBefore(this.topPocket, this.wrapper.firstChild)
                }
                this.topLoading = this.topPocket.querySelector("." + a);
                this.topCaption = this.topPocket.querySelector("." + o)
            }
            if (t.up && t.up.hasOwnProperty("callback")) {
                this.bottomPocket = this.scroller.querySelector("." + n);
                if (!this.bottomPocket) {
                    this.bottomPocket = this._createPocket(n, t.up, b);
                    this.scroller.appendChild(this.bottomPocket)
                }
                this.bottomLoading = this.bottomPocket.querySelector("." + a);
                this.bottomCaption = this.bottomPocket.querySelector("." + o);
                this.wrapper.addEventListener("scrollbottom", this)
            }
        },
        _createPocket: function(t, i, s) {
            var n = e.createElement("div");
            n.className = t;
            n.innerHTML = y.replace("{contentrefresh}", i.contentrefresh).replace("{icon}", s);
            return n
        },
        _resetPullDownLoading: function() {
            var t = this.pullLoading;
            if (t) {
                this.pullCaption.innerHTML = this.options.down.contentdown;
                t.style.webkitTransition = "";
                t.style.webkitTransform = "";
                t.style.webkitAnimation = "";
                t.className = w
            }
        },
        _setCaptionClass: function(t, e, i) {
            if (!t) {
                switch (i) {
                case this.options.up.contentdown:
                    e.className = o + " " + l;
                    break;
                case this.options.up.contentrefresh:
                    e.className = o + " " + c;
                    break;
                case this.options.up.contentnomore:
                    e.className = o + " " + f;
                    break
                }
            }
        },
        _setCaption: function(t, e) {
            if (this.loading) {
                return 
            }
            var i = this.options;
            var s = this.pullPocket;
            var n = this.pullCaption;
            var r = this.pullLoading;
            var a = this.pulldown;
            var o = this;
            if (s) {
                if (e) {
                    setTimeout(function() {
                        n.innerHTML = o.lastTitle = t;
                        if (a) {
                            r.className = w
                        } else {
                            o._setCaptionClass(false, n, t);
                            r.className = b
                        }
                        r.style.webkitAnimation = "";
                        r.style.webkitTransition = "";
                        r.style.webkitTransform = ""
                    }, 100)
                } else {
                    if (t !== this.lastTitle) {
                        n.innerHTML = t;
                        if (a) {
                            if (t === i.down.contentrefresh) {
                                r.className = b;
                                r.style.webkitAnimation = "spinner-spin 1s step-end infinite"
                            } else if (t === i.down.contentover) {
                                r.className = m;
                                r.style.webkitTransition = "-webkit-transform 0.3s ease-in";
                                r.style.webkitTransform = "rotate(180deg)"
                            } else if (t === i.down.contentdown) {
                                r.className = w;
                                r.style.webkitTransition = "-webkit-transform 0.3s ease-in";
                                r.style.webkitTransform = "rotate(0deg)"
                            }
                        } else {
                            if (t === i.up.contentrefresh) {
                                r.className = b + " " + g
                            } else {
                                r.className = b + " " + v
                            }
                            o._setCaptionClass(false, n, t)
                        }
                        this.lastTitle = t
                    }
                }
            }
        }
    };
    t.PullRefresh = L
})(mui, document);
(function(t, e, i, s) {
    var n = "mui-scrollbar";
    var r = "mui-scrollbar-indicator";
    var a = n + "-vertical";
    var o = n + "-horizontal";
    var l = "mui-active";
    var c = {
        quadratic: {
            style: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
            fn: function(t) {
                return t * (2 - t)
            }
        },
        circular: {
            style: "cubic-bezier(0.1, 0.57, 0.1, 1)",
            fn: function(t) {
                return Math.sqrt(1 - --t * t)
            }
        }
    };
    var f = t.Class.extend({
        init: function(e, i) {
            this.wrapper = this.element = e;
            this.scroller = this.wrapper.children[0];
            this.scrollerStyle = this.scroller && this.scroller.style;
            this.stopped = false;
            this.options = t.extend(true, {
                scrollY: true,
                scrollX: false,
                startX: 0,
                startY: 0,
                indicators: true,
                stopPropagation: false,
                hardwareAccelerated: true,
                fixedBadAndorid: false,
                preventDefaultException: {
                    tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|VIDEO)$/
                },
                momentum: true,
                snap: false,
                bounce: true,
                bounceTime: 300,
                bounceEasing: c.circular.style,
                directionLockThreshold: 5,
                parallaxElement: false,
                parallaxRatio: .5
            }, i);
            this.x = 0;
            this.y = 0;
            this.translateZ = this.options.hardwareAccelerated ? " translateZ(0)" : "";
            this._init();
            if (this.scroller) {
                this.refresh();
                this.scrollTo(this.options.startX, this.options.startY)
            }
        },
        _init: function() {
            this._initParallax();
            this._initIndicators();
            this._initEvent()
        },
        _initParallax: function() {
            if (this.options.parallaxElement) {
                this.parallaxElement = i.querySelector(this.options.parallaxElement);
                this.parallaxStyle = this.parallaxElement.style;
                this.parallaxHeight = this.parallaxElement.offsetHeight;
                this.parallaxImgStyle = this.parallaxElement.querySelector("img").style
            }
        },
        _initIndicators: function() {
            var t = this;
            t.indicators = [];
            if (!this.options.indicators) {
                return 
            }
            var e = [], i;
            if (t.options.scrollY) {
                i = {
                    el: this._createScrollBar(a),
                    listenX: false
                };
                this.wrapper.appendChild(i.el);
                e.push(i)
            }
            if (this.options.scrollX) {
                i = {
                    el: this._createScrollBar(o),
                    listenY: false
                };
                this.wrapper.appendChild(i.el);
                e.push(i)
            }
            for (var s = e.length; s--;) {
                this.indicators.push(new u(this, e[s]))
            }
        },
        _initSnap: function() {
            this.currentPage = {};
            this.pages = [];
            var t = this.snaps;
            var e = t.length;
            var i = 0;
            var s =- 1;
            var n = 0;
            var r = 0;
            for (var a = 0; a < e; a++) {
                var o = t[a];
                var c = o.offsetLeft;
                var f = o.offsetWidth;
                if (a === 0 || c <= t[a - 1].offsetLeft) {
                    i = 0;
                    s++
                }
                if (!this.pages[i]) {
                    this.pages[i] = []
                }
                n = this._getSnapX(c);
                r = n - Math.round(f / 2);
                this.pages[i][s] = {
                    x: n,
                    cx: r,
                    pageX: i,
                    element: o
                };
                if (o.classList.contains(l)) {
                    this.currentPage = this.pages[i][0]
                }
                if (n >= this.maxScrollX) {
                    i++
                }
            }
            this.options.startX = this.currentPage.x || 0
        },
        _getSnapX: function(t) {
            return Math.max(Math.min(0, - t + this.wrapperWidth / 2), this.maxScrollX)
        },
        _gotoPage: function(t) {
            this.currentPage = this.pages[Math.min(t, this.pages.length - 1)][0];
            for (var e = 0, i = this.snaps.length; e < i; e++) {
                if (e === t) {
                    this.snaps[e].classList.add(l)
                } else {
                    this.snaps[e].classList.remove(l)
                }
            }
            this.scrollTo(this.currentPage.x, 0, this.options.bounceTime)
        },
        _nearestSnap: function(t) {
            if (!this.pages.length) {
                return {
                    x: 0,
                    pageX: 0
                }
            }
            var e = 0;
            var i = this.pages.length;
            if (t > 0) {
                t = 0
            } else if (t < this.maxScrollX) {
                t = this.maxScrollX
            }
            for (; e < i; e++) {
                if (t >= this.pages[e][0].cx) {
                    return this.pages[e][0]
                }
            }
            return {
                x: 0,
                pageX: 0
            }
        },
        _initEvent: function(i) {
            var s = i ? "removeEventListener": "addEventListener";
            e[s]("orientationchange", this);
            e[s]("resize", this);
            this.scroller[s]("webkitTransitionEnd", this);
            this.wrapper[s]("touchstart", this);
            this.wrapper[s]("touchcancel", this);
            this.wrapper[s]("touchend", this);
            this.wrapper[s]("drag", this);
            this.wrapper[s]("dragend", this);
            this.wrapper[s]("flick", this);
            this.wrapper[s]("scrollend", this);
            if (this.options.scrollX) {
                this.wrapper[s]("swiperight", this)
            }
            var n = this.wrapper.querySelector(".mui-segmented-control");
            if (n) {
                mui(n)[i ? "off": "on"]("click", "a", t.preventDefault)
            }
            this.wrapper[s]("scrollend", this._handleIndicatorScrollend.bind(this));
            this.wrapper[s]("scrollstart", this._handleIndicatorScrollstart.bind(this));
            this.wrapper[s]("refresh", this._handleIndicatorRefresh.bind(this))
        },
        _handleIndicatorScrollend: function() {
            this.indicators.map(function(t) {
                t.fade()
            })
        },
        _handleIndicatorScrollstart: function() {
            this.indicators.map(function(t) {
                t.fade(1)
            })
        },
        _handleIndicatorRefresh: function() {
            this.indicators.map(function(t) {
                t.refresh()
            })
        },
        handleEvent: function(t) {
            if (this.stopped) {
                this.resetPosition();
                return 
            }
            switch (t.type) {
            case"touchstart":
                this._start(t);
                break;
            case"drag":
                this.options.stopPropagation && t.stopPropagation();
                this._drag(t);
                break;
            case"dragend":
            case"flick":
                this.options.stopPropagation && t.stopPropagation();
                this._flick(t);
                break;
            case"touchcancel":
            case"touchend":
                this._end(t);
                break;
            case"webkitTransitionEnd":
                this._transitionEnd(t);
                break;
            case"scrollend":
                this._scrollend(t);
                t.stopPropagation();
                break;
            case"orientationchange":
            case"resize":
                this._resize();
                break;
            case"swiperight":
                t.stopPropagation();
                break
            }
        },
        _start: function(e) {
            e.target&&!this._preventDefaultException(e.target, this.options.preventDefaultException) && e.preventDefault();
            this.moved = this.needReset = false;
            this._transitionTime();
            if (this.isInTransition) {
                this.needReset = true;
                this.isInTransition = false;
                var i = t.parseTranslateMatrix(t.getStyles(this.scroller, "webkitTransform"));
                this.setTranslate(Math.round(i.x), Math.round(i.y));
                t.trigger(this.scroller, "scrollend", this);
                e.preventDefault()
            }
            this.reLayout();
            t.trigger(this.scroller, "beforescrollstart", this)
        },
        _getDirectionByAngle: function(t) {
            if (t<-80 && t>-100) {
                return "up"
            } else if (t >= 80 && t < 100) {
                return "down"
            } else if (t >= 170 || t<=-170) {
                return "left"
            } else if (t>=-35 && t <= 10) {
                return "right"
            }
            return null
        },
        _drag: function(i) {
            var s = i.detail;
            if (this.options.scrollY || s.direction === "up" || s.direction === "down") {
                if (t.os.ios && parseFloat(t.os.version) >= 8) {
                    var n = s.gesture.touches[0].clientY;
                    if (n + 10 > e.innerHeight || n < 10) {
                        this.resetPosition(this.options.bounceTime);
                        return 
                    }
                }
            }
            var r = isReturn = false;
            var a = this._getDirectionByAngle(s.angle);
            if (s.direction === "left" || s.direction === "right") {
                if (this.options.scrollX) {
                    r = true;
                    if (!this.moved) {
                        t.gestures.session.lockDirection = true;
                        t.gestures.session.startDirection = s.direction
                    }
                } else if (this.options.scrollY&&!this.moved) {
                    isReturn = true
                }
            } else if (s.direction === "up" || s.direction === "down") {
                if (this.options.scrollY) {
                    r = true;
                    if (!this.moved) {
                        t.gestures.session.lockDirection = true;
                        t.gestures.session.startDirection = s.direction
                    }
                } else if (this.options.scrollX&&!this.moved) {
                    isReturn = true
                }
            } else {
                isReturn = true
            }
            if (this.moved || r) {
                i.stopPropagation();
                s.gesture && s.gesture.preventDefault()
            }
            if (isReturn) {
                return 
            }
            if (!this.moved) {
                t.trigger(this.scroller, "scrollstart", this)
            } else {
                i.stopPropagation()
            }
            var o = 0;
            var l = 0;
            if (!this.moved) {
                o = s.deltaX;
                l = s.deltaY
            } else {
                o = s.deltaX - t.gestures.session.prevTouch.deltaX;
                l = s.deltaY - t.gestures.session.prevTouch.deltaY
            }
            var c = Math.abs(s.deltaX);
            var f = Math.abs(s.deltaY);
            if (c > f + this.options.directionLockThreshold) {
                l = 0
            } else if (f >= c + this.options.directionLockThreshold) {
                o = 0
            }
            o = this.hasHorizontalScroll ? o : 0;
            l = this.hasVerticalScroll ? l : 0;
            var u = this.x + o;
            var h = this.y + l;
            if (u > 0 || u < this.maxScrollX) {
                u = this.options.bounce ? this.x + o / 3 : u > 0 ? 0 : this.maxScrollX
            }
            if (h > 0 || h < this.maxScrollY) {
                h = this.options.bounce ? this.y + l / 3 : h > 0 ? 0 : this.maxScrollY
            }
            if (!this.requestAnimationFrame) {
                this._updateTranslate()
            }
            this.moved = true;
            this.x = u;
            this.y = h;
            t.trigger(this.scroller, "scroll", this)
        },
        _flick: function(e) {
            if (!this.moved) {
                return 
            }
            e.stopPropagation();
            var i = e.detail;
            this._clearRequestAnimationFrame();
            if (e.type === "dragend" && i.flick) {
                return 
            }
            var s = Math.round(this.x);
            var n = Math.round(this.y);
            this.isInTransition = false;
            if (this.resetPosition(this.options.bounceTime)) {
                return 
            }
            this.scrollTo(s, n);
            if (e.type === "dragend") {
                t.trigger(this.scroller, "scrollend", this);
                return 
            }
            var r = 0;
            var a = "";
            if (this.options.momentum && i.flickTime < 300) {
                momentumX = this.hasHorizontalScroll ? this._momentum(this.x, i.flickDistanceX, i.flickTime, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : {
                    destination: s,
                    duration: 0
                };
                momentumY = this.hasVerticalScroll ? this._momentum(this.y, i.flickDistanceY, i.flickTime, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : {
                    destination: n,
                    duration: 0
                };
                s = momentumX.destination;
                n = momentumY.destination;
                r = Math.max(momentumX.duration, momentumY.duration);
                this.isInTransition = true
            }
            if (s != this.x || n != this.y) {
                if (s > 0 || s < this.maxScrollX || n > 0 || n < this.maxScrollY) {
                    a = c.quadratic
                }
                this.scrollTo(s, n, r, a);
                return 
            }
            t.trigger(this.scroller, "scrollend", this)
        },
        _end: function(t) {
            this.needReset = false;
            if (!this.moved && this.needReset || t.type === "touchcancel") {
                this.resetPosition()
            }
        },
        _transitionEnd: function(e) {
            if (e.target != this.scroller ||!this.isInTransition) {
                return 
            }
            this._transitionTime();
            if (!this.resetPosition(this.options.bounceTime)) {
                this.isInTransition = false;
                t.trigger(this.scroller, "scrollend", this)
            }
        },
        _scrollend: function(e) {
            if (Math.abs(this.y) > 0 && this.y <= this.maxScrollY) {
                t.trigger(this.scroller, "scrollbottom", this)
            }
        },
        _resize: function() {
            var t = this;
            clearTimeout(t.resizeTimeout);
            t.resizeTimeout = setTimeout(function() {
                t.refresh()
            }, t.options.resizePolling)
        },
        _transitionTime: function(e) {
            e = e || 0;
            this.scrollerStyle["webkitTransitionDuration"] = e + "ms";
            if (this.parallaxElement && this.options.scrollY) {
                this.parallaxStyle["webkitTransitionDuration"] = e + "ms"
            }
            if (this.options.fixedBadAndorid&&!e && t.os.isBadAndroid) {
                this.scrollerStyle["webkitTransitionDuration"] = "0.001s";
                if (this.parallaxElement && this.options.scrollY) {
                    this.parallaxStyle["webkitTransitionDuration"] = "0.001s"
                }
            }
            if (this.indicators) {
                for (var i = this.indicators.length; i--;) {
                    this.indicators[i].transitionTime(e)
                }
            }
        },
        _transitionTimingFunction: function(t) {
            this.scrollerStyle["webkitTransitionTimingFunction"] = t;
            if (this.parallaxElement && this.options.scrollY) {
                this.parallaxStyle["webkitTransitionDuration"] = t
            }
            if (this.indicators) {
                for (var e = this.indicators.length; e--;) {
                    this.indicators[e].transitionTimingFunction(t)
                }
            }
        },
        _translate: function(t, e) {
            this.x = t;
            this.y = e
        },
        _clearRequestAnimationFrame: function() {
            if (this.requestAnimationFrame) {
                cancelAnimationFrame(this.requestAnimationFrame);
                this.requestAnimationFrame = null
            }
        },
        _updateTranslate: function() {
            var t = this;
            if (t.x !== t.lastX || t.y !== t.lastY) {
                t.setTranslate(t.x, t.y)
            }
            t.requestAnimationFrame = requestAnimationFrame(function() {
                t._updateTranslate()
            })
        },
        _createScrollBar: function(t) {
            var e = i.createElement("div");
            var s = i.createElement("div");
            e.className = n + " " + t;
            s.className = r;
            e.appendChild(s);
            if (t === a) {
                this.scrollbarY = e;
                this.scrollbarIndicatorY = s
            } else if (t === o) {
                this.scrollbarX = e;
                this.scrollbarIndicatorX = s
            }
            this.wrapper.appendChild(e);
            return e
        },
        _preventDefaultException: function(t, e) {
            for (var i in e) {
                if (e[i].test(t[i])) {
                    return true
                }
            }
            return false
        },
        _reLayout: function() {
            if (!this.hasHorizontalScroll) {
                this.maxScrollX = 0;
                this.scrollerWidth = this.wrapperWidth
            }
            if (!this.hasVerticalScroll) {
                this.maxScrollY = 0;
                this.scrollerHeight = this.wrapperHeight
            }
            this.indicators.map(function(t) {
                t.refresh()
            });
            if (this.options.snap && typeof this.options.snap === "string") {
                var t = this.scroller.querySelectorAll(this.options.snap);
                this.itemLength = 0;
                this.snaps = [];
                for (var e = 0, i = t.length; e < i; e++) {
                    var s = t[e];
                    if (s.parentNode === this.scroller) {
                        this.itemLength++;
                        this.snaps.push(s)
                    }
                }
                this._initSnap()
            }
        },
        _momentum: function(t, e, i, n, r, a) {
            var o = parseFloat(Math.abs(e) / i), l, c;
            a = a === s ? 6e-4 : a;
            l = t + o * o / (2 * a) * (e < 0?-1 : 1);
            c = o / a;
            if (l < n) {
                l = r ? n - r / 2.5 * (o / 8) : n;
                e = Math.abs(l - t);
                c = e / o
            } else if (l > 0) {
                l = r ? r / 2.5 * (o / 8) : 0;
                e = Math.abs(t) + l;
                c = e / o
            }
            return {
                destination: Math.round(l),
                duration: c
            }
        },
        _getTranslateStr: function(t, e) {
            if (this.options.hardwareAccelerated) {
                return "translate3d(" + t + "px," + e + "px,0px) " + this.translateZ
            }
            return "translate(" + t + "px," + e + "px) "
        },
        setStopped: function(t) {
            this.stopped=!!t
        },
        setTranslate: function(e, i) {
            this.x = e;
            this.y = i;
            this.scrollerStyle["webkitTransform"] = this._getTranslateStr(e, i);
            if (this.parallaxElement && this.options.scrollY) {
                var s = i * this.options.parallaxRatio;
                var n = 1 + s / ((this.parallaxHeight - s) / 2);
                if (n > 1) {
                    this.parallaxImgStyle["opacity"] = 1 - s / 100 * this.options.parallaxRatio;
                    this.parallaxStyle["webkitTransform"] = this._getTranslateStr(0, - s) + " scale(" + n + "," + n + ")"
                } else {
                    this.parallaxImgStyle["opacity"] = 1;
                    this.parallaxStyle["webkitTransform"] = this._getTranslateStr(0, - 1) + " scale(1,1)"
                }
            }
            if (this.indicators) {
                for (var r = this.indicators.length; r--;) {
                    this.indicators[r].updatePosition()
                }
            }
            this.lastX = this.x;
            this.lastY = this.y;
            t.trigger(this.scroller, "scroll", this)
        },
        reLayout: function() {
            this.wrapper.offsetHeight;
            var e = parseFloat(t.getStyles(this.wrapper, "padding-left")) || 0;
            var i = parseFloat(t.getStyles(this.wrapper, "padding-right")) || 0;
            var s = parseFloat(t.getStyles(this.wrapper, "padding-top")) || 0;
            var n = parseFloat(t.getStyles(this.wrapper, "padding-bottom")) || 0;
            var r = this.wrapper.clientWidth;
            var a = this.wrapper.clientHeight;
            this.scrollerWidth = this.scroller.offsetWidth;
            this.scrollerHeight = this.scroller.offsetHeight;
            this.wrapperWidth = r - e - i;
            this.wrapperHeight = a - s - n;
            this.maxScrollX = Math.min(this.wrapperWidth - this.scrollerWidth, 0);
            this.maxScrollY = Math.min(this.wrapperHeight - this.scrollerHeight, 0);
            this.hasHorizontalScroll = this.options.scrollX && this.maxScrollX < 0;
            this.hasVerticalScroll = this.options.scrollY && this.maxScrollY < 0;
            this._reLayout()
        },
        resetPosition: function(t) {
            var e = this.x, i = this.y;
            t = t || 0;
            if (!this.hasHorizontalScroll || this.x > 0) {
                e = 0
            } else if (this.x < this.maxScrollX) {
                e = this.maxScrollX
            }
            if (!this.hasVerticalScroll || this.y > 0) {
                i = 0
            } else if (this.y < this.maxScrollY) {
                i = this.maxScrollY
            }
            if (e == this.x && i == this.y) {
                return false
            }
            this.scrollTo(e, i, t, this.options.bounceEasing);
            return true
        },
        refresh: function() {
            this.reLayout();
            t.trigger(this.scroller, "refresh", this);
            this.resetPosition()
        },
        scrollTo: function(t, e, i, s) {
            var s = s || c.circular;
            this.isInTransition = i > 0 && (this.lastX != t || this.lastY != e);
            if (this.isInTransition) {
                this._clearRequestAnimationFrame();
                this._transitionTimingFunction(s.style);
                this._transitionTime(i);
                this.setTranslate(t, e)
            } else {
                this.setTranslate(t, e)
            }
        },
        scrollToBottom: function(t, e) {
            t = t || this.options.bounceTime;
            this.scrollTo(0, this.maxScrollY, t, e)
        },
        gotoPage: function(t) {
            this._gotoPage(t)
        },
        destory: function() {
            this._initEvent(true);
            delete t.data[this.wrapper.getAttribute("data-scroll")];
            this.wrapper.setAttribute("data-scroll", "")
        }
    });
    var u = function(e, s) {
        this.wrapper = typeof s.el == "string" ? i.querySelector(s.el) : s.el;
        this.wrapperStyle = this.wrapper.style;
        this.indicator = this.wrapper.children[0];
        this.indicatorStyle = this.indicator.style;
        this.scroller = e;
        this.options = t.extend({
            listenX: true,
            listenY: true,
            fade: false,
            speedRatioX: 0,
            speedRatioY: 0
        }, s);
        this.sizeRatioX = 1;
        this.sizeRatioY = 1;
        this.maxPosX = 0;
        this.maxPosY = 0;
        if (this.options.fade) {
            this.wrapperStyle["webkitTransform"] = this.scroller.translateZ;
            this.wrapperStyle["webkitTransitionDuration"] = this.options.fixedBadAndorid && t.os.isBadAndroid ? "0.001s" : "0ms";
            this.wrapperStyle.opacity = "0"
        }
    };
    u.prototype = {
        handleEvent: function(t) {},
        transitionTime: function(e) {
            e = e || 0;
            this.indicatorStyle["webkitTransitionDuration"] = e + "ms";
            if (this.scroller.options.fixedBadAndorid&&!e && t.os.isBadAndroid) {
                this.indicatorStyle["webkitTransitionDuration"] = "0.001s"
            }
        },
        transitionTimingFunction: function(t) {
            this.indicatorStyle["webkitTransitionTimingFunction"] = t
        },
        refresh: function() {
            this.transitionTime();
            if (this.options.listenX&&!this.options.listenY) {
                this.indicatorStyle.display = this.scroller.hasHorizontalScroll ? "block" : "none"
            } else if (this.options.listenY&&!this.options.listenX) {
                this.indicatorStyle.display = this.scroller.hasVerticalScroll ? "block" : "none"
            } else {
                this.indicatorStyle.display = this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? "block" : "none"
            }
            this.wrapper.offsetHeight;
            if (this.options.listenX) {
                this.wrapperWidth = this.wrapper.clientWidth;
                this.indicatorWidth = Math.max(Math.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8);
                this.indicatorStyle.width = this.indicatorWidth + "px";
                this.maxPosX = this.wrapperWidth - this.indicatorWidth;
                this.minBoundaryX = 0;
                this.maxBoundaryX = this.maxPosX;
                this.sizeRatioX = this.options.speedRatioX || this.scroller.maxScrollX && this.maxPosX / this.scroller.maxScrollX
            }
            if (this.options.listenY) {
                this.wrapperHeight = this.wrapper.clientHeight;
                this.indicatorHeight = Math.max(Math.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8);
                this.indicatorStyle.height = this.indicatorHeight + "px";
                this.maxPosY = this.wrapperHeight - this.indicatorHeight;
                this.minBoundaryY = 0;
                this.maxBoundaryY = this.maxPosY;
                this.sizeRatioY = this.options.speedRatioY || this.scroller.maxScrollY && this.maxPosY / this.scroller.maxScrollY
            }
            this.updatePosition()
        },
        updatePosition: function() {
            var t = this.options.listenX && Math.round(this.sizeRatioX * this.scroller.x) || 0, e = this.options.listenY && Math.round(this.sizeRatioY * this.scroller.y) || 0;
            if (t < this.minBoundaryX) {
                this.width = Math.max(this.indicatorWidth + t, 8);
                this.indicatorStyle.width = this.width + "px";
                t = this.minBoundaryX
            } else if (t > this.maxBoundaryX) {
                this.width = Math.max(this.indicatorWidth - (t - this.maxPosX), 8);
                this.indicatorStyle.width = this.width + "px";
                t = this.maxPosX + this.indicatorWidth - this.width
            } else if (this.width != this.indicatorWidth) {
                this.width = this.indicatorWidth;
                this.indicatorStyle.width = this.width + "px"
            }
            if (e < this.minBoundaryY) {
                this.height = Math.max(this.indicatorHeight + e * 3, 8);
                this.indicatorStyle.height = this.height + "px";
                e = this.minBoundaryY
            } else if (e > this.maxBoundaryY) {
                this.height = Math.max(this.indicatorHeight - (e - this.maxPosY) * 3, 8);
                this.indicatorStyle.height = this.height + "px";
                e = this.maxPosY + this.indicatorHeight - this.height
            } else if (this.height != this.indicatorHeight) {
                this.height = this.indicatorHeight;
                this.indicatorStyle.height = this.height + "px"
            }
            this.x = t;
            this.y = e;
            this.indicatorStyle["webkitTransform"] = this.scroller._getTranslateStr(t, e)
        },
        fade: function(t, e) {
            if (e&&!this.visible) {
                return 
            }
            clearTimeout(this.fadeTimeout);
            this.fadeTimeout = null;
            var i = t ? 250: 500, s = t ? 0: 300;
            t = t ? "1" : "0";
            this.wrapperStyle["webkitTransitionDuration"] = i + "ms";
            this.fadeTimeout = setTimeout(function(t) {
                this.wrapperStyle.opacity = t;
                this.visible =+ t
            }.bind(this, t), s)
        }
    };
    t.Scroll = f;
    t.fn.scroll = function(e) {
        var i = [];
        this.each(function() {
            var s = null;
            var n = this;
            var r = n.getAttribute("data-scroll");
            if (!r) {
                r=++t.uuid;
                var a = t.extend({}, e);
                if (n.classList.contains("mui-segmented-control")) {
                    a = t.extend(a, {
                        scrollY: false,
                        scrollX: true,
                        indicators: false,
                        snap: ".mui-control-item"
                    })
                }
                t.data[r] = s = new f(n, a);
                n.setAttribute("data-scroll", r)
            } else {
                s = t.data[r]
            }
            i.push(s)
        });
        return i.length === 1 ? i[0] : i
    }
})(mui, window, document);
(function(t, e, i, s) {
    var n = "mui-visibility";
    var r = "mui-hidden";
    var a = t.Scroll.extend(t.extend({
        handleEvent: function(t) {
            this._super(t);
            if (t.type === "scrollbottom") {
                if (t.target === this.scroller) {
                    this._scrollbottom()
                }
            }
        },
        _scrollbottom: function() {
            if (!this.pulldown&&!this.loading) {
                this.pulldown = false;
                this._initPullupRefresh();
                this.pullupLoading()
            }
        },
        _start: function(t) {
            if (!this.loading) {
                this.pulldown = this.pullPocket = this.pullCaption = this.pullLoading = false
            }
            this._super(t)
        },
        _drag: function(t) {
            this._super(t);
            if (!this.pulldown&&!this.loading && this.topPocket && t.detail.direction === "down" && this.y >= 0) {
                this._initPulldownRefresh()
            }
            if (this.pulldown) {
                this._setCaption(this.y > this.options.down.height ? this.options.down.contentover : this.options.down.contentdown)
            }
        },
        _reLayout: function() {
            this.hasVerticalScroll = true;
            this._super()
        },
        resetPosition: function(t) {
            if (this.pulldown) {
                if (this.y >= this.options.down.height) {
                    this.pulldownLoading(s, t || 0);
                    return true
                } else {
                    !this.loading && this.topPocket.classList.remove(n)
                }
            }
            return this._super(t)
        },
        pulldownLoading: function(t, e) {
            typeof t === "undefined" && (t = this.options.down.height);
            this.scrollTo(0, t, e, this.options.bounceEasing);
            if (this.loading) {
                return 
            }
            this._initPulldownRefresh();
            this._setCaption(this.options.down.contentrefresh);
            this.loading = true;
            this.indicators.map(function(t) {
                t.fade(0)
            });
            var i = this.options.down.callback;
            i && i.call(this)
        },
        endPulldownToRefresh: function() {
            var t = this;
            if (t.topPocket && t.loading && this.pulldown) {
                t.scrollTo(0, 0, t.options.bounceTime, t.options.bounceEasing);
                t.loading = false;
                t._setCaption(t.options.down.contentdown, true);
                setTimeout(function() {
                    t.loading || t.topPocket.classList.remove(n)
                }, 350)
            }
        },
        pullupLoading: function(t, e, i) {
            e = e || 0;
            this.scrollTo(e, this.maxScrollY, i, this.options.bounceEasing);
            if (this.loading) {
                return 
            }
            this._initPullupRefresh();
            this._setCaption(this.options.up.contentrefresh);
            this.indicators.map(function(t) {
                t.fade(0)
            });
            this.loading = true;
            t = t || this.options.up.callback;
            t && t.call(this)
        },
        endPullupToRefresh: function(t) {
            var e = this;
            if (e.bottomPocket) {
                e.loading = false;
                if (t) {
                    this.finished = true;
                    e._setCaption(e.options.up.contentnomore);
                    e.wrapper.removeEventListener("scrollbottom", e)
                } else {
                    e._setCaption(e.options.up.contentdown);
                    e.loading || e.bottomPocket.classList.remove(n)
                }
            }
        },
        disablePullupToRefresh: function() {
            this._initPullupRefresh();
            this.bottomPocket.className = "mui-pull-bottom-pocket" + " " + r;
            this.wrapper.removeEventListener("scrollbottom", this)
        },
        enablePullupToRefresh: function() {
            this._initPullupRefresh();
            this.bottomPocket.classList.remove(r);
            this._setCaption(this.options.up.contentdown);
            this.wrapper.addEventListener("scrollbottom", this)
        },
        refresh: function(t) {
            if (t && this.finished) {
                this.enablePullupToRefresh();
                this.finished = false
            }
            this._super()
        }
    }, t.PullRefresh));
    t.fn.pullRefresh = function(e) {
        if (this.length === 1) {
            var i = this[0];
            var s = null;
            e = e || {};
            var n = i.getAttribute("data-pullrefresh");
            if (!n) {
                n=++t.uuid;
                t.data[n] = s = new a(i, e);
                i.setAttribute("data-pullrefresh", n)
            } else {
                s = t.data[n]
            }
            if (e.down && e.down.auto) {
                s.pulldownLoading(e.down.autoY)
            } else if (e.up && e.up.auto) {
                s.pullupLoading()
            }
            return s
        }
    }
})(mui, window, document);
(function(t, e) {
    var i = "mui-slider";
    var s = "mui-slider-group";
    var n = "mui-slider-loop";
    var r = "mui-slider-indicator";
    var a = "mui-action-previous";
    var o = "mui-action-next";
    var l = "mui-slider-item";
    var c = "mui-active";
    var f = "." + l;
    var u = "." + r;
    var h = ".mui-slider-progress-bar";
    var d = t.Slider = t.Scroll.extend({
        init: function(e, i) {
            this._super(e, t.extend(true, {
                fingers: 1,
                interval: 0,
                scrollY: false,
                scrollX: true,
                indicators: false,
                bounceTime: 200,
                startX: false,
                snap: f
            }, i));
            if (this.options.startX) {}
        },
        _init: function() {
            var t = this.wrapper.querySelectorAll("." + s);
            for (var e = 0, i = t.length; e < i; e++) {
                if (t[e].parentNode === this.wrapper) {
                    this.scroller = t[e];
                    break
                }
            }
            if (this.scroller) {
                this.scrollerStyle = this.scroller.style;
                this.progressBar = this.wrapper.querySelector(h);
                if (this.progressBar) {
                    this.progressBarWidth = this.progressBar.offsetWidth;
                    this.progressBarStyle = this.progressBar.style
                }
                this._super();
                this._initTimer()
            }
        },
        _triggerSlide: function() {
            var e = this;
            e.isInTransition = false;
            var i = e.currentPage;
            e.slideNumber = e._fixedSlideNumber();
            if (e.loop) {
                if (e.slideNumber === 0) {
                    e.setTranslate(e.pages[1][0].x, 0)
                } else if (e.slideNumber === e.itemLength - 3) {
                    e.setTranslate(e.pages[e.itemLength - 2][0].x, 0)
                }
            }
            if (e.lastSlideNumber != e.slideNumber) {
                e.lastSlideNumber = e.slideNumber;
                e.lastPage = e.currentPage;
                t.trigger(e.wrapper, "slide", {
                    slideNumber: e.slideNumber
                })
            }
            e._initTimer()
        },
        _handleSlide: function(e) {
            var i = this;
            if (e.target !== i.wrapper) {
                return 
            }
            var s = e.detail;
            s.slideNumber = s.slideNumber || 0;
            var n = i.scroller.querySelectorAll(f);
            var r = s.slideNumber;
            if (i.loop) {
                r += 1
            }
            if (!i.wrapper.classList.contains("mui-segmented-control")) {
                for (var a = 0, o = n.length; a < o; a++) {
                    var l = n[a];
                    if (l.parentNode === i.scroller) {
                        if (a === r) {
                            l.classList.add(c)
                        } else {
                            l.classList.remove(c)
                        }
                    }
                }
            }
            var u = i.wrapper.querySelector(".mui-slider-indicator");
            if (u) {
                if (u.getAttribute("data-scroll")) {
                    t(u).scroll().gotoPage(s.slideNumber)
                }
                var h = u.querySelectorAll(".mui-indicator");
                if (h.length > 0) {
                    for (var a = 0, o = h.length; a < o; a++) {
                        h[a].classList[a === s.slideNumber ? "add": "remove"](c)
                    }
                } else {
                    var d = u.querySelector(".mui-number span");
                    if (d) {
                        d.innerText = s.slideNumber + 1
                    } else {
                        var p = i.wrapper.querySelectorAll(".mui-control-item");
                        for (var a = 0, o = p.length; a < o; a++) {
                            p[a].classList[a === s.slideNumber ? "add": "remove"](c)
                        }
                    }
                }
            }
            e.stopPropagation()
        },
        _handleTabShow: function(t) {
            var e = this;
            e.gotoItem(t.detail.tabNumber || 0, e.options.bounceTime)
        },
        _handleIndicatorTap: function(t) {
            var e = this;
            var i = t.target;
            if (i.classList.contains(a) || i.classList.contains(o)) {
                e[i.classList.contains(a) ? "prevItem": "nextItem"]();
                t.stopPropagation()
            }
        },
        _initEvent: function(e) {
            var i = this;
            i._super(e);
            var s = e ? "removeEventListener": "addEventListener";
            i.wrapper[s]("swiperight", t.stopPropagation);
            i.wrapper[s]("scrollend", i._triggerSlide.bind(this));
            i.wrapper[s]("slide", i._handleSlide.bind(this));
            i.wrapper[s](t.eventName("shown", "tab"), i._handleTabShow.bind(this));
            var n = i.wrapper.querySelector(u);
            if (n) {
                n[s]("tap", i._handleIndicatorTap.bind(this))
            }
        },
        _drag: function(t) {
            this._super(t);
            var i = t.detail.direction;
            if (i === "left" || i === "right") {
                var s = this.wrapper.getAttribute("data-slidershowTimer");
                s && e.clearTimeout(s);
                t.stopPropagation()
            }
        },
        _initTimer: function() {
            var t = this;
            var i = t.wrapper;
            var s = t.options.interval;
            var n = i.getAttribute("data-slidershowTimer");
            n && e.clearTimeout(n);
            if (s) {
                n = e.setTimeout(function() {
                    if (!i) {
                        return 
                    }
                    if (!!(i.offsetWidth || i.offsetHeight)) {
                        t.nextItem(true)
                    }
                    t._initTimer()
                }, s);
                i.setAttribute("data-slidershowTimer", n)
            }
        },
        _fixedSlideNumber: function(t) {
            t = t || this.currentPage;
            var e = t.pageX;
            if (this.loop) {
                if (t.pageX === 0) {
                    e = this.itemLength - 3
                } else if (t.pageX === this.itemLength - 1) {
                    e = 0
                } else {
                    e = t.pageX - 1
                }
            }
            return e
        },
        _reLayout: function() {
            this.hasHorizontalScroll = true;
            this.loop = this.scroller.classList.contains(n);
            this._super()
        },
        _getScroll: function() {
            var e = t.parseTranslateMatrix(t.getStyles(this.scroller, "webkitTransform"));
            return e ? e.x : 0
        },
        _transitionEnd: function(e) {
            if (e.target !== this.scroller ||!this.isInTransition) {
                return 
            }
            this._transitionTime();
            this.isInTransition = false;
            t.trigger(this.wrapper, "scrollend", this)
        },
        _flick: function(t) {
            if (!this.moved) {
                return 
            }
            var e = t.detail;
            var i = e.direction;
            this._clearRequestAnimationFrame();
            this.isInTransition = true;
            if (t.type === "flick") {
                if (e.deltaTime < 200) {
                    this.x = this._getPage(this.slideNumber + (i === "right"?-1 : 1), true).x
                }
                this.resetPosition(this.options.bounceTime)
            } else if (t.type === "dragend"&&!e.flick) {
                this.resetPosition(this.options.bounceTime)
            }
            t.stopPropagation()
        },
        _initSnap: function() {
            this.scrollerWidth = this.itemLength * this.scrollerWidth;
            this.maxScrollX = Math.min(this.wrapperWidth - this.scrollerWidth, 0);
            this._super();
            if (!this.currentPage.x) {
                var t = this.pages[this.loop ? 1: 0];
                t = t || this.pages[0];
                if (!t) {
                    return 
                }
                this.currentPage = t[0];
                this.slideNumber = 0;
                this.lastSlideNumber = typeof this.lastSlideNumber === "undefined" ? 0 : this.lastSlideNumber
            } else {
                this.slideNumber = this._fixedSlideNumber();
                this.lastSlideNumber = typeof this.lastSlideNumber === "undefined" ? this.slideNumber : this.lastSlideNumber
            }
            this.options.startX = this.currentPage.x || 0
        },
        _getSnapX: function(t) {
            return Math.max( - t, this.maxScrollX)
        },
        _getPage: function(t, e) {
            if (this.loop) {
                if (t > this.itemLength - (e ? 2 : 3)) {
                    t = 1;
                    time = 0
                } else if (t < (e?-1 : 0)) {
                    t = this.itemLength - 2;
                    time = 0
                } else {
                    t += 1
                }
            } else {
                if (!e) {
                    if (t > this.itemLength - 1) {
                        t = 0;
                        time = 0
                    } else if (t < 0) {
                        t = this.itemLength - 1;
                        time = 0
                    }
                }
                t = Math.min(Math.max(0, t), this.itemLength - 1)
            }
            return this.pages[t][0]
        },
        _gotoItem: function(e, i) {
            this.currentPage = this._getPage(e, true);
            this.scrollTo(this.currentPage.x, 0, i, this.options.bounceEasing);
            if (i === 0) {
                t.trigger(this.wrapper, "scrollend", this)
            }
        },
        setTranslate: function(t, e) {
            this._super(t, e);
            var i = this.progressBar;
            if (i) {
                this.progressBarStyle.webkitTransform = this._getTranslateStr( - t * (this.progressBarWidth / this.wrapperWidth), 0)
            }
        },
        resetPosition: function(t) {
            t = t || 0;
            if (this.x > 0) {
                this.x = 0
            } else if (this.x < this.maxScrollX) {
                this.x = this.maxScrollX
            }
            this.currentPage = this._nearestSnap(this.x);
            this.scrollTo(this.currentPage.x, 0, t);
            return true
        },
        gotoItem: function(t, e) {
            this._gotoItem(t, typeof e === "undefined" ? this.options.bounceTime : e)
        },
        nextItem: function() {
            this._gotoItem(this.slideNumber + 1, this.options.bounceTime)
        },
        prevItem: function() {
            this._gotoItem(this.slideNumber - 1, this.options.bounceTime)
        },
        getSlideNumber: function() {
            return this.slideNumber || 0
        },
        refresh: function(e) {
            if (e) {
                t.extend(this.options, e);
                this._super();
                this.nextItem()
            } else {
                this._super()
            }
        },
        destory: function() {
            this._initEvent(true);
            delete t.data[this.wrapper.getAttribute("data-slider")];
            this.wrapper.setAttribute("data-slider", "")
        }
    });
    t.fn.slider = function(e) {
        var s = null;
        this.each(function() {
            var n = this;
            if (!this.classList.contains(i)) {
                n = this.querySelector("." + i)
            }
            if (n && n.querySelector(f)) {
                var r = n.getAttribute("data-slider");
                if (!r) {
                    r=++t.uuid;
                    t.data[r] = s = new d(n, e);
                    n.setAttribute("data-slider", r)
                } else {
                    s = t.data[r];
                    if (s && e) {
                        s.refresh(e)
                    }
                }
            }
        });
        return s
    };
    t.ready(function() {
        t(".mui-slider").slider();
        t(".mui-scroll-wrapper.mui-slider-indicator.mui-segmented-control").scroll({
            scrollY: false,
            scrollX: true,
            indicators: false,
            snap: ".mui-control-item"
        })
    })
})(mui, window);
(function(t, e) {
    if (!(t.os.plus && t.os.android)) {
        return 
    }
    var i = "mui-plus-pullrefresh";
    var s = "mui-visibility";
    var n = "mui-hidden";
    var r = "mui-block";
    var a = "mui-pull-caption";
    var o = "mui-pull-caption-down";
    var l = "mui-pull-caption-refresh";
    var c = "mui-pull-caption-nomore";
    var f = t.Class.extend({
        init: function(t, e) {
            this.element = t;
            this.options = e;
            this.wrapper = this.scroller = t;
            this._init();
            this._initPulldownRefreshEvent()
        },
        _init: function() {
            var t = this;
            window.addEventListener("dragup", t);
            t.scrollInterval = window.setInterval(function() {
                if (t.isScroll&&!t.loading) {
                    if (window.pageYOffset + window.innerHeight + 10 >= e.documentElement.scrollHeight) {
                        t.isScroll = false;
                        if (t.bottomPocket) {
                            t.pullupLoading()
                        }
                    }
                }
            }, 100)
        },
        _initPulldownRefreshEvent: function() {
            var e = this;
            if (e.topPocket && e.options.webviewId) {
                t.plusReady(function() {
                    var t = plus.webview.getWebviewById(e.options.webviewId);
                    if (!t) {
                        return 
                    }
                    e.options.webview = t;
                    var i = e.options.down;
                    var s = i.height;
                    t.addEventListener("dragBounce", function(s) {
                        if (!e.pulldown) {
                            e._initPulldownRefresh()
                        } else {
                            e.pullPocket.classList.add(r)
                        }
                        switch (s.status) {
                        case"beforeChangeOffset":
                            e._setCaption(i.contentdown);
                            break;
                        case"afterChangeOffset":
                            e._setCaption(i.contentover);
                            break;
                        case"dragEndAfterChangeOffset":
                            t.evalJS("mui&&mui.options.pullRefresh.down.callback()");
                            e._setCaption(i.contentrefresh);
                            break;
                        default:
                            break
                        }
                    }, false);
                    t.setBounce({
                        position: {
                            top: s * 2 + "px"
                        },
                        changeoffset: {
                            top: s + "px"
                        }
                    })
                })
            }
        },
        handleEvent: function(t) {
            var e = this;
            if (e.stopped) {
                return 
            }
            e.isScroll = false;
            if (t.type === "dragup") {
                e.isScroll = true;
                setTimeout(function() {
                    e.isScroll = false
                }, 1e3)
            }
        }
    }).extend(t.extend({
        setStopped: function(t) {
            this.stopped=!!t;
            var e = plus.webview.currentWebview();
            if (this.stopped) {
                e.setStyle({
                    bounce: "none"
                });
                e.setBounce({
                    position: {
                        top: "none"
                    }
                })
            } else {
                var i = this.options.down.height;
                e.setStyle({
                    bounce: "vertical"
                });
                e.setBounce({
                    position: {
                        top: i * 2 + "px"
                    },
                    changeoffset: {
                        top: i + "px"
                    }
                })
            }
        },
        pulldownLoading: function() {
            var e = t.options.pullRefresh.down.callback;
            e && e.call(this)
        },
        _pulldownLoading: function() {
            var e = this;
            t.plusReady(function() {
                plus.webview.getWebviewById(e.options.webviewId).evalJS("mui&&mui.options.pullRefresh.down&&mui.options.pullRefresh.down.callback()")
            })
        },
        endPulldownToRefresh: function() {
            var t = plus.webview.currentWebview();
            t.parent().evalJS("mui&&mui(document.querySelector('.mui-content')).pullRefresh('" + JSON.stringify({
                webviewId: t.id
            }) + "')._endPulldownToRefresh()")
        },
        _endPulldownToRefresh: function() {
            var t = this;
            if (t.topPocket && t.options.webview) {
                t.options.webview.endPullToRefresh();
                t.loading = false;
                t._setCaption(t.options.down.contentdown, true);
                setTimeout(function() {
                    t.loading || t.topPocket.classList.remove(r)
                }, 350)
            }
        },
        pullupLoading: function(t) {
            var e = this;
            if (e.isLoading)
                return;
            e.isLoading = true;
            if (e.pulldown !== false) {
                e._initPullupRefresh()
            } else {
                this.pullPocket.classList.add(r)
            }
            setTimeout(function() {
                e.pullLoading.classList.add(s);
                e.pullLoading.classList.remove(n);
                e.pullCaption.innerHTML = "";
                e.pullCaption.className = a + " " + l;
                e.pullCaption.innerHTML = e.options.up.contentrefresh;
                t = t || e.options.up.callback;
                t && t.call(e)
            }, 300)
        },
        endPullupToRefresh: function(t) {
            var e = this;
            if (e.pullLoading) {
                e.pullLoading.classList.remove(s);
                e.pullLoading.classList.add(n);
                e.isLoading = false;
                if (t) {
                    e.finished = true;
                    e.pullCaption.className = a + " " + c;
                    e.pullCaption.innerHTML = e.options.up.contentnomore;
                    window.removeEventListener("dragup", e)
                } else {
                    e.pullCaption.className = a + " " + o;
                    e.pullCaption.innerHTML = e.options.up.contentdown
                }
            }
        },
        disablePullupToRefresh: function() {
            this._initPullupRefresh();
            this.bottomPocket.className = "mui-pull-bottom-pocket" + " " + n;
            window.removeEventListener("dragup", this)
        },
        enablePullupToRefresh: function() {
            this._initPullupRefresh();
            this.bottomPocket.classList.remove(n);
            this.pullCaption.className = a + " " + o;
            this.pullCaption.innerHTML = this.options.up.contentdown;
            window.addEventListener("dragup", this)
        },
        scrollTo: function(e, i, s) {
            t.scrollTo(e, i, s)
        },
        refresh: function(t) {
            if (t && this.finished) {
                this.enablePullupToRefresh();
                this.finished = false
            }
        }
    }, t.PullRefresh));
    t.fn.pullRefresh = function(s) {
        var n;
        if (this.length === 0) {
            n = e.createElement("div");
            n.className = "mui-content";
            e.body.appendChild(n)
        } else {
            n = this[0]
        }
        s = s || {};
        if (typeof s === "string") {
            s = t.parseJSON(s)
        }
        !s.webviewId && (s.webviewId = plus.webview.currentWebview().id || plus.webview.currentWebview().getURL());
        var r = null;
        var a = s.webviewId && s.webviewId.replace(/\//g, "_");
        var o = n.getAttribute("data-pullrefresh-plus-" + a);
        if (!o) {
            o=++t.uuid;
            n.setAttribute("data-pullrefresh-plus-" + a, o);
            e.body.classList.add(i);
            t.data[o] = r = new f(n, s)
        } else {
            r = t.data[o]
        }
        if (s.down && s.down.auto) {
            r._pulldownLoading()
        } else if (s.up && s.up.auto) {
            r.pullupLoading()
        }
        return r
    }
})(mui, document);
(function(t, e, i, s) {
    var n = "mui-off-canvas-left";
    var r = "mui-off-canvas-right";
    var a = "mui-off-canvas-backdrop";
    var o = "mui-off-canvas-wrap";
    var l = "mui-slide-in";
    var c = "mui-active";
    var f = "mui-transitioning";
    var u = ".mui-inner-wrap";
    var h = t.Class.extend({
        init: function(e, s) {
            this.wrapper = this.element = e;
            this.scroller = this.wrapper.querySelector(u);
            this.classList = this.wrapper.classList;
            if (this.scroller) {
                this.options = t.extend(true, {
                    dragThresholdX: 10,
                    scale: .8,
                    opacity: .1,
                    preventDefaultException: {
                        tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|VIDEO)$/
                    }
                }, s);
                i.body.classList.add("mui-fullscreen");
                this.refresh();
                this.initEvent()
            }
        },
        _preventDefaultException: function(t, e) {
            for (var i in e) {
                if (e[i].test(t[i])) {
                    return true
                }
            }
            return false
        },
        refresh: function(t) {
            this.slideIn = this.classList.contains(l);
            this.scalable = this.classList.contains("mui-scalable")&&!this.slideIn;
            this.scroller = this.wrapper.querySelector(u);
            this.offCanvasLefts = this.wrapper.querySelectorAll("." + n);
            this.offCanvasRights = this.wrapper.querySelectorAll("." + r);
            if (t) {
                if (t.classList.contains(n)) {
                    this.offCanvasLeft = t
                } else if (t.classList.contains(r)) {
                    this.offCanvasRight = t
                }
            } else {
                this.offCanvasRight = this.wrapper.querySelector("." + r);
                this.offCanvasLeft = this.wrapper.querySelector("." + n)
            }
            this.offCanvasRightWidth = this.offCanvasLeftWidth = 0;
            this.offCanvasLeftSlideIn = this.offCanvasRightSlideIn = false;
            if (this.offCanvasRight) {
                this.offCanvasRightWidth = this.offCanvasRight.offsetWidth;
                this.offCanvasRightSlideIn = this.slideIn && this.offCanvasRight.parentNode === this.wrapper
            }
            if (this.offCanvasLeft) {
                this.offCanvasLeftWidth = this.offCanvasLeft.offsetWidth;
                this.offCanvasLeftSlideIn = this.slideIn && this.offCanvasLeft.parentNode === this.wrapper
            }
            this.backdrop = this.scroller.querySelector("." + a);
            this.options.dragThresholdX = this.options.dragThresholdX || 10;
            this.visible = false;
            this.startX = null;
            this.lastX = null;
            this.offsetX = null;
            this.lastTranslateX = null
        },
        handleEvent: function(e) {
            switch (e.type) {
            case"touchstart":
                e.target&&!this._preventDefaultException(e.target, this.options.preventDefaultException) && e.preventDefault();
                break;
            case"webkitTransitionEnd":
                if (e.target === this.scroller) {
                    this._dispatchEvent()
                }
                break;
            case"drag":
                var i = e.detail;
                if (!this.startX) {
                    this.startX = i.center.x;
                    this.lastX = this.startX
                } else {
                    this.lastX = i.center.x
                }
                if (!this.isDragging && Math.abs(this.lastX - this.startX) > this.options.dragThresholdX && (i.direction === "left" || i.direction === "right")) {
                    if (this.slideIn) {
                        this.scroller = this.wrapper.querySelector(u);
                        if (this.classList.contains(c)) {
                            if (this.offCanvasRight && this.offCanvasRight.classList.contains(c)) {
                                this.offCanvas = this.offCanvasRight;
                                this.offCanvasWidth = this.offCanvasRightWidth
                            } else {
                                this.offCanvas = this.offCanvasLeft;
                                this.offCanvasWidth = this.offCanvasLeftWidth
                            }
                        } else {
                            if (i.direction === "left" && this.offCanvasRight) {
                                this.offCanvas = this.offCanvasRight;
                                this.offCanvasWidth = this.offCanvasRightWidth
                            } else if (i.direction === "right" && this.offCanvasLeft) {
                                this.offCanvas = this.offCanvasLeft;
                                this.offCanvasWidth = this.offCanvasLeftWidth
                            } else {
                                this.scroller = null
                            }
                        }
                    } else {
                        if (this.classList.contains(c)) {
                            if (i.direction === "left") {
                                this.offCanvas = this.offCanvasLeft;
                                this.offCanvasWidth = this.offCanvasLeftWidth
                            } else {
                                this.offCanvas = this.offCanvasRight;
                                this.offCanvasWidth = this.offCanvasRightWidth
                            }
                        } else {
                            if (i.direction === "right") {
                                this.offCanvas = this.offCanvasLeft;
                                this.offCanvasWidth = this.offCanvasLeftWidth
                            } else {
                                this.offCanvas = this.offCanvasRight;
                                this.offCanvasWidth = this.offCanvasRightWidth
                            }
                        }
                    }
                    if (this.offCanvas && this.scroller) {
                        this.startX = this.lastX;
                        this.isDragging = true;
                        t.gestures.session.lockDirection = true;
                        t.gestures.session.startDirection = i.direction;
                        this.offCanvas.classList.remove(f);
                        this.scroller.classList.remove(f);
                        this.offsetX = this.getTranslateX();
                        this._initOffCanvasVisible()
                    }
                }
                if (this.isDragging) {
                    this.updateTranslate(this.offsetX + (this.lastX - this.startX));
                    i.gesture.preventDefault();
                    e.stopPropagation()
                }
                break;
            case"dragend":
                if (this.isDragging) {
                    var i = e.detail;
                    var s = i.direction;
                    this.isDragging = false;
                    this.offCanvas.classList.add(f);
                    this.scroller.classList.add(f);
                    var n = 0;
                    var r = this.getTranslateX();
                    if (!this.slideIn) {
                        if (r >= 0) {
                            n = this.offCanvasLeftWidth && r / this.offCanvasLeftWidth || 0
                        } else {
                            n = this.offCanvasRightWidth && r / this.offCanvasRightWidth || 0
                        }
                        if (n === 0) {
                            this.openPercentage(0);
                            this._dispatchEvent();
                            return 
                        }
                        if (n > 0 && n < .5 && s === "right") {
                            this.openPercentage(0)
                        } else if (n > .5 && s === "left") {
                            this.openPercentage(100)
                        } else if (n < 0 && n>-.5 && s === "left") {
                            this.openPercentage(0)
                        } else if (s === "right" && n < 0 && n>-.5) {
                            this.openPercentage(0)
                        } else if (n < .5 && s === "right") {
                            this.openPercentage( - 100)
                        } else if (s === "right" && n >= 0 && (n >= .5 || i.flick)) {
                            this.openPercentage(100)
                        } else if (s === "left" && n <= 0 && (n<=-.5 || i.flick)) {
                            this.openPercentage( - 100)
                        } else {
                            this.openPercentage(0)
                        }
                        if (n === 1 || n===-1) {
                            this._dispatchEvent()
                        }
                    } else {
                        if (r >= 0) {
                            n = this.offCanvasRightWidth && r / this.offCanvasRightWidth || 0
                        } else {
                            n = this.offCanvasLeftWidth && r / this.offCanvasLeftWidth || 0
                        }
                        if (n >= .5 && s === "left") {
                            this.openPercentage(0)
                        } else if (n > 0 && n <= .5 && s === "left") {
                            this.openPercentage( - 100)
                        } else if (n >= .5 && s === "right") {
                            this.openPercentage(0)
                        } else if (n>=-.5 && n < 0 && s === "left") {
                            this.openPercentage(100)
                        } else if (n > 0 && n <= .5 && s === "right") {
                            this.openPercentage( - 100)
                        } else if (n<=-.5 && s === "right") {
                            this.openPercentage(0)
                        } else if (n>=-.5 && s === "right") {
                            this.openPercentage(100)
                        } else if (n<=-.5 && s === "left") {
                            this.openPercentage(0)
                        } else if (n>=-.5 && s === "left") {
                            this.openPercentage( - 100)
                        } else {
                            this.openPercentage(0)
                        }
                        if (n === 1 || n===-1 || n === 0) {
                            this._dispatchEvent();
                            return 
                        }
                    }
                }
                break
            }
        },
        _dispatchEvent: function() {
            if (this.classList.contains(c)) {
                t.trigger(this.wrapper, "shown", this)
            } else {
                t.trigger(this.wrapper, "hidden", this)
            }
        },
        _initOffCanvasVisible: function() {
            if (!this.visible) {
                this.visible = true;
                if (this.offCanvasLeft) {
                    this.offCanvasLeft.style.visibility = "visible"
                }
                if (this.offCanvasRight) {
                    this.offCanvasRight.style.visibility = "visible"
                }
            }
        },
        initEvent: function() {
            var t = this;
            if (t.backdrop) {
                t.backdrop.addEventListener("tap", function(e) {
                    t.close();
                    e.detail.gesture.preventDefault()
                })
            }
            if (this.classList.contains("mui-draggable")) {
                this.wrapper.addEventListener("touchstart", this);
                this.wrapper.addEventListener("drag", this);
                this.wrapper.addEventListener("dragend", this)
            }
            this.wrapper.addEventListener("webkitTransitionEnd", this)
        },
        openPercentage: function(t) {
            var e = t / 100;
            if (!this.slideIn) {
                if (this.offCanvasLeft && t >= 0) {
                    this.updateTranslate(this.offCanvasLeftWidth * e);
                    this.offCanvasLeft.classList[e !== 0 ? "add": "remove"](c)
                } else if (this.offCanvasRight && t <= 0) {
                    this.updateTranslate(this.offCanvasRightWidth * e);
                    this.offCanvasRight.classList[e !== 0 ? "add": "remove"](c)
                }
                this.classList[e !== 0 ? "add": "remove"](c)
            } else {
                if (this.offCanvasLeft && t >= 0) {
                    e = e === 0?-1 : 0;
                    this.updateTranslate(this.offCanvasLeftWidth * e);
                    this.offCanvasLeft.classList[t !== 0 ? "add": "remove"](c)
                } else if (this.offCanvasRight && t <= 0) {
                    e = e === 0 ? 1 : 0;
                    this.updateTranslate(this.offCanvasRightWidth * e);
                    this.offCanvasRight.classList[t !== 0 ? "add": "remove"](c)
                }
                this.classList[t !== 0 ? "add": "remove"](c)
            }
        },
        updateTranslate: function(e) {
            if (e !== this.lastTranslateX) {
                if (!this.slideIn) {
                    if (!this.offCanvasLeft && e > 0 ||!this.offCanvasRight && e < 0) {
                        this.setTranslateX(0);
                        return 
                    }
                    if (this.leftShowing && e > this.offCanvasLeftWidth) {
                        this.setTranslateX(this.offCanvasLeftWidth);
                        return 
                    }
                    if (this.rightShowing && e<-this.offCanvasRightWidth) {
                        this.setTranslateX( - this.offCanvasRightWidth);
                        return 
                    }
                    this.setTranslateX(e);
                    if (e >= 0) {
                        this.leftShowing = true;
                        this.rightShowing = false;
                        if (e > 0) {
                            if (this.offCanvasLeft) {
                                t.each(this.offCanvasLefts, function(t, e) {
                                    if (e === this.offCanvasLeft) {
                                        this.offCanvasLeft.style.zIndex = 0
                                    } else {
                                        e.style.zIndex =- 1
                                    }
                                }.bind(this))
                            }
                            if (this.offCanvasRight) {
                                this.offCanvasRight.style.zIndex =- 1
                            }
                        }
                    } else {
                        this.rightShowing = true;
                        this.leftShowing = false;
                        if (this.offCanvasRight) {
                            t.each(this.offCanvasRights, function(t, e) {
                                if (e === this.offCanvasRight) {
                                    e.style.zIndex = 0
                                } else {
                                    e.style.zIndex =- 1
                                }
                            }.bind(this))
                        }
                        if (this.offCanvasLeft) {
                            this.offCanvasLeft.style.zIndex =- 1
                        }
                    }
                } else {
                    if (this.offCanvas.classList.contains(r)) {
                        if (e < 0) {
                            this.setTranslateX(0);
                            return 
                        }
                        if (e > this.offCanvasRightWidth) {
                            this.setTranslateX(this.offCanvasRightWidth);
                            return 
                        }
                    } else {
                        if (e > 0) {
                            this.setTranslateX(0);
                            return 
                        }
                        if (e<-this.offCanvasLeftWidth) {
                            this.setTranslateX( - this.offCanvasLeftWidth);
                            return 
                        }
                    }
                    this.setTranslateX(e)
                }
                this.lastTranslateX = e
            }
        },
        setTranslateX: t.animationFrame(function(t) {
            if (this.scroller) {
                if (this.scalable && this.offCanvas.parentNode === this.wrapper) {
                    var e = Math.abs(t) / this.offCanvasWidth;
                    var i = 1 - (1 - this.options.scale) * e;
                    var s = this.options.scale + (1 - this.options.scale) * e;
                    var r = 1 - (1 - this.options.opacity) * e;
                    var a = this.options.opacity + (1 - this.options.opacity) * e;
                    if (this.offCanvas.classList.contains(n)) {
                        this.offCanvas.style.webkitTransformOrigin = "-100%";
                        this.scroller.style.webkitTransformOrigin = "left"
                    } else {
                        this.offCanvas.style.webkitTransformOrigin = "200%";
                        this.scroller.style.webkitTransformOrigin = "right"
                    }
                    this.offCanvas.style.opacity = a;
                    this.offCanvas.style.webkitTransform = "translate3d(0,0,0) scale(" + s + ")";
                    this.scroller.style.webkitTransform = "translate3d(" + t + "px,0,0) scale(" + i + ")"
                } else {
                    if (this.slideIn) {
                        this.offCanvas.style.webkitTransform = "translate3d(" + t + "px,0,0)"
                    } else {
                        this.scroller.style.webkitTransform = "translate3d(" + t + "px,0,0)"
                    }
                }
            }
        }),
        getTranslateX: function() {
            if (this.offCanvas) {
                var e = this.slideIn ? this.offCanvas: this.scroller;
                var i = t.parseTranslateMatrix(t.getStyles(e, "webkitTransform"));
                return i && i.x || 0
            }
            return 0
        },
        isShown: function(t) {
            var e = false;
            if (!this.slideIn) {
                var i = this.getTranslateX();
                if (t === "right") {
                    e = this.classList.contains(c) && i < 0
                } else if (t === "left") {
                    e = this.classList.contains(c) && i > 0
                } else {
                    e = this.classList.contains(c) && i !== 0
                }
            } else {
                if (t === "left") {
                    e = this.classList.contains(c) && this.wrapper.querySelector("." + n + "." + c)
                } else if (t === "right") {
                    e = this.classList.contains(c) && this.wrapper.querySelector("." + r + "." + c)
                } else {
                    e = this.classList.contains(c) && (this.wrapper.querySelector("." + n + "." + c) || this.wrapper.querySelector("." + r + "." + c))
                }
            }
            return e
        },
        close: function() {
            this._initOffCanvasVisible();
            this.offCanvas = this.wrapper.querySelector("." + r + "." + c) || this.wrapper.querySelector("." + n + "." + c);
            this.offCanvasWidth = this.offCanvas.offsetWidth;
            if (this.scroller) {
                this.offCanvas.offsetHeight;
                this.offCanvas.classList.add(f);
                this.scroller.classList.add(f);
                this.openPercentage(0)
            }
        },
        show: function(t) {
            this._initOffCanvasVisible();
            if (this.isShown(t)) {
                return false
            }
            if (!t) {
                t = this.wrapper.querySelector("." + r) ? "right" : "left"
            }
            if (t === "right") {
                this.offCanvas = this.offCanvasRight;
                this.offCanvasWidth = this.offCanvasRightWidth
            } else {
                this.offCanvas = this.offCanvasLeft;
                this.offCanvasWidth = this.offCanvasLeftWidth
            }
            if (this.scroller) {
                this.offCanvas.offsetHeight;
                this.offCanvas.classList.add(f);
                this.scroller.classList.add(f);
                this.openPercentage(t === "left" ? 100 : - 100)
            }
            return true
        },
        toggle: function(t) {
            var e = t;
            if (t && t.classList) {
                e = t.classList.contains(n) ? "left" : "right";
                this.refresh(t)
            }
            if (!this.show(e)) {
                this.close()
            }
        }
    });
    var d = function(t) {
        parentNode = t.parentNode;
        if (parentNode) {
            if (parentNode.classList.contains(o)) {
                return parentNode
            } else {
                parentNode = parentNode.parentNode;
                if (parentNode.classList.contains(o)) {
                    return parentNode
                }
            }
        }
    };
    var p = function(e, s) {
        if (s.tagName === "A" && s.hash) {
            var n = i.getElementById(s.hash.replace("#", ""));
            if (n) {
                var r = d(n);
                if (r) {
                    t.targets._container = r;
                    return n
                }
            }
        }
        return false
    };
    t.registerTarget({
        name: s,
        index: 60,
        handle: p,
        target: false,
        isReset: false,
        isContinue: true
    });
    e.addEventListener("tap", function(e) {
        if (!t.targets.offcanvas) {
            return 
        }
        var s = e.target;
        for (; s && s !== i; s = s.parentNode) {
            if (s.tagName === "A" && s.hash && s.hash === "#" + t.targets.offcanvas.id) {
                e.detail && e.detail.gesture && e.detail.gesture.preventDefault();
                t(t.targets._container).offCanvas().toggle(t.targets.offcanvas);
                t.targets.offcanvas = t.targets._container = null;
                break
            }
        }
    });
    t.fn.offCanvas = function(e) {
        var i = [];
        this.each(function() {
            var s = null;
            var n = this;
            if (!n.classList.contains(o)) {
                n = d(n)
            }
            var r = n.getAttribute("data-offCanvas");
            if (!r) {
                r=++t.uuid;
                t.data[r] = s = new h(n, e);
                n.setAttribute("data-offCanvas", r)
            } else {
                s = t.data[r]
            }
            if (e === "show" || e === "close" || e === "toggle") {
                s.toggle()
            }
            i.push(s)
        });
        return i.length === 1 ? i[0] : i
    };
    t.ready(function() {
        t(".mui-off-canvas-wrap").offCanvas()
    })
})(mui, window, document, "offcanvas");
(function(t, e) {
    var i = "mui-action";
    var s = function(t, e) {
        var s = e.className || "";
        if (typeof s !== "string") {
            s = ""
        }
        if (s&&~s.indexOf(i)) {
            if (e.classList.contains("mui-action-back")) {
                t.preventDefault()
            }
            return e
        }
        return false
    };
    t.registerTarget({
        name: e,
        index: 50,
        handle: s,
        target: false,
        isContinue: true
    })
})(mui, "action");
(function(t, e, i, s) {
    var n = "mui-modal";
    var r = function(t, e) {
        if (e.tagName === "A" && e.hash) {
            var s = i.getElementById(e.hash.replace("#", ""));
            if (s && s.classList.contains(n)) {
                return s
            }
        }
        return false
    };
    t.registerTarget({
        name: s,
        index: 50,
        handle: r,
        target: false,
        isReset: false,
        isContinue: true
    });
    e.addEventListener("tap", function(e) {
        if (t.targets.modal) {
            e.detail.gesture.preventDefault();
            t.targets.modal.classList.toggle("mui-active")
        }
    })
})(mui, window, document, "modal");
(function(t, e, i, s) {
    var n = "mui-popover";
    var r = "mui-popover-arrow";
    var a = "mui-popover-action";
    var o = "mui-backdrop";
    var l = "mui-bar-popover";
    var c = "mui-bar-backdrop";
    var f = "mui-backdrop-action";
    var u = "mui-active";
    var h = "mui-bottom";
    var d = function(e, s) {
        if (s.tagName === "A" && s.hash) {
            t.targets._popover = i.getElementById(s.hash.replace("#", ""));
            if (t.targets._popover && t.targets._popover.classList.contains(n)) {
                return s
            } else {
                t.targets._popover = null
            }
        }
        return false
    };
    t.registerTarget({
        name: s,
        index: 60,
        handle: d,
        target: false,
        isReset: false,
        isContinue: true
    });
    var p = function(t) {};
    var v = function(e) {
        this.removeEventListener("webkitTransitionEnd", v);
        this.addEventListener("touchmove", t.preventDefault);
        t.trigger(this, "shown", this)
    };
    var g = function(e) {
        y(this, "none");
        this.removeEventListener("webkitTransitionEnd", g);
        this.removeEventListener("touchmove", t.preventDefault);
        p(false);
        t.trigger(this, "hidden", this)
    };
    var m = function() {
        var e = i.createElement("div");
        e.classList.add(o);
        e.addEventListener("touchmove", t.preventDefault);
        e.addEventListener("tap", function(e) {
            var s = t.targets._popover;
            if (s) {
                s.addEventListener("webkitTransitionEnd", g);
                s.classList.remove(u);
                w(s);
                i.body.setAttribute("style", "")
            }
        });
        return e
    }();
    var w = function(e) {
        m.setAttribute("style", "opacity:0");
        t.targets.popover = t.targets._popover = null;
        setTimeout(function() {
            if (!e.classList.contains(u) && m.parentNode && m.parentNode === i.body) {
                i.body.removeChild(m)
            }
        }, 350)
    };
    e.addEventListener("tap", function(e) {
        if (!t.targets.popover) {
            return 
        }
        var s = false;
        var n = e.target;
        for (; n && n !== i; n = n.parentNode) {
            if (n === t.targets.popover) {
                s = true
            }
        }
        if (s) {
            e.detail.gesture.preventDefault();
            b(t.targets._popover, t.targets.popover)
        }
    });
    var b = function(t, e) {
        t.removeEventListener("webkitTransitionEnd", v);
        t.removeEventListener("webkitTransitionEnd", g);
        m.classList.remove(c);
        m.classList.remove(f);
        var s = i.querySelector(".mui-popover.mui-active");
        if (s) {
            s.addEventListener("webkitTransitionEnd", g);
            s.classList.remove(u);
            if (t === s) {
                w(s);
                return 
            }
        }
        var n = false;
        if (t.classList.contains(l) || t.classList.contains(a)) {
            if (t.classList.contains(a)) {
                n = true;
                m.classList.add(f)
            } else {
                m.classList.add(c)
            }
        }
        y(t, "block");
        t.offsetHeight;
        t.classList.add(u);
        m.setAttribute("style", "");
        i.body.appendChild(m);
        p(true);
        L(t, e, n);
        m.classList.add(u);
        t.addEventListener("webkitTransitionEnd", v)
    };
    var y = function(t, e, i, s) {
        var n = t.style;
        if (typeof e !== "undefined")
            n.display = e;
        if (typeof i !== "undefined")
            n.top = i + "px";
        if (typeof s !== "undefined")
            n.left = s + "px"
    };
    var L = function(s, n, o) {
        if (!s ||!n) {
            return 
        }
        if (o) {
            y(s, "block");
            return 
        }
        var l = e.innerWidth;
        var c = e.innerHeight;
        var f = s.offsetWidth;
        var u = s.offsetHeight;
        var d = n.offsetWidth;
        var p = n.offsetHeight;
        var v = t.offset(n);
        var g = s.querySelector("." + r);
        if (!g) {
            g = i.createElement("div");
            g.className = r;
            s.appendChild(g)
        }
        var m = g && g.offsetWidth / 2 || 0;
        var w = 0;
        var b = 0;
        var L = 0;
        var T = 0;
        var x = s.classList.contains(a) ? 0: 5;
        var E = "top";
        if (u + m < v.top - e.pageYOffset) {
            w = v.top - u - m
        } else if (u + m < c - (v.top - e.pageYOffset) - p) {
            E = "bottom";
            w = v.top + p + m
        } else {
            E = "middle";
            w = Math.max((c - u) / 2 + e.pageYOffset, 0);
            b = Math.max((l - f) / 2 + e.pageXOffset, 0)
        }
        if (E === "top" || E === "bottom") {
            b = d / 2 + v.left - f / 2;
            L = b;
            if (b < x)
                b = x;
            if (b + f > l)
                b = l - f - x;
            if (g) {
                if (E === "top") {
                    g.classList.add(h)
                } else {
                    g.classList.remove(h)
                }
                L = L - b;
                T = f / 2 - m / 2 + L;
                T = Math.max(Math.min(T, f - m * 2 - 6), 6);
                g.setAttribute("style", "left:" + T + "px")
            }
        } else if (E === "middle") {
            g.setAttribute("style", "display:none")
        }
        y(s, "block", w, b)
    };
    t.createMask = function(e) {
        var s = i.createElement("div");
        s.classList.add(o);
        s.addEventListener("touchmove", t.preventDefault);
        s.addEventListener("tap", function() {
            n.close()
        });
        var n = [s];
        n._show = false;
        n.show = function() {
            n._show = true;
            s.setAttribute("style", "opacity:1");
            i.body.appendChild(s);
            return n
        };
        n._remove = function() {
            if (n._show) {
                n._show = false;
                s.setAttribute("style", "opacity:0");
                t.later(function() {
                    var t = i.body;
                    s.parentNode === t && t.removeChild(s)
                }, 350)
            }
            return n
        };
        n.close = function() {
            if (e) {
                if (e() !== false) {
                    n._remove()
                }
            } else {
                n._remove()
            }
        };
        return n
    };
    t.fn.popover = function() {
        var e = arguments;
        this.each(function() {
            t.targets._popover = this;
            if (e[0] === "show" || e[0] === "hide" || e[0] === "toggle") {
                b(this, e[1])
            }
        })
    }
})(mui, window, document, "popover");
(function(t, e, i, s, n) {
    var r = "mui-control-item";
    var a = "mui-segmented-control";
    var o = "mui-segmented-control-vertical";
    var l = "mui-control-content";
    var c = "mui-bar-tab";
    var f = "mui-tab-item";
    var u = "mui-slider-item";
    var h = function(t, e) {
        if (e.classList && (e.classList.contains(r) || e.classList.contains(f))) {
            if (e.parentNode && e.parentNode.classList && e.parentNode.classList.contains(o)) {} else {
                t.preventDefault()
            }
            return e
        }
        return false
    };
    t.registerTarget({
        name: s,
        index: 80,
        handle: h,
        target: false
    });
    e.addEventListener("tap", function(e) {
        var n = t.targets.tab;
        if (!n) {
            return 
        }
        var o;
        var u;
        var h;
        var d = "mui-active";
        var p = "." + d;
        var v = n.parentNode;
        for (; v && v !== i; v = v.parentNode) {
            if (v.classList.contains(a)) {
                o = v.querySelector(p + "." + r);
                break
            } else if (v.classList.contains(c)) {
                o = v.querySelector(p + "." + f)
            }
        }
        if (o) {
            o.classList.remove(d)
        }
        var g = n === o;
        if (n) {
            n.classList.add(d)
        }
        if (!n.hash) {
            return 
        }
        h = i.getElementById(n.hash.replace("#", ""));
        if (!h) {
            return 
        }
        if (!h.classList.contains(l)) {
            n.classList[g ? "remove": "add"](d);
            return 
        }
        if (g) {
            return 
        }
        var m = h.parentNode;
        u = m.querySelectorAll("." + l + p);
        for (var w = 0; w < u.length; w++) {
            var b = u[w];
            b.parentNode === m && b.classList.remove(d)
        }
        h.classList.add(d);
        var y = h.parentNode.querySelectorAll("." + l);
        t.trigger(h, t.eventName("shown", s), {
            tabNumber: Array.prototype.indexOf.call(y, h)
        });
        e.detail && e.detail.gesture.preventDefault()
    })
})(mui, window, document, "tab");
(function(t, e, i) {
    var s = "mui-switch";
    var n = "mui-switch-handle";
    var r = "mui-active";
    var a = "mui-dragging";
    var o = "mui-disabled";
    var l = "." + n;
    var c = function(t, e) {
        if (e.classList && e.classList.contains(s)) {
            return e
        }
        return false
    };
    t.registerTarget({
        name: i,
        index: 100,
        handle: c,
        target: false
    });
    var f = function(t) {
        this.element = t;
        this.classList = this.element.classList;
        this.handle = this.element.querySelector(l);
        this.init();
        this.initEvent()
    };
    f.prototype.init = function() {
        this.toggleWidth = this.element.offsetWidth;
        this.handleWidth = this.handle.offsetWidth;
        this.handleX = this.toggleWidth - this.handleWidth - 3
    };
    f.prototype.initEvent = function() {
        this.element.addEventListener("touchstart", this);
        this.element.addEventListener("drag", this);
        this.element.addEventListener("swiperight", this);
        this.element.addEventListener("touchend", this);
        this.element.addEventListener("touchcancel", this)
    };
    f.prototype.handleEvent = function(t) {
        if (this.classList.contains(o)) {
            return 
        }
        switch (t.type) {
        case"touchstart":
            this.start(t);
            break;
        case"drag":
            this.drag(t);
            break;
        case"swiperight":
            this.swiperight();
            break;
        case"touchend":
        case"touchcancel":
            this.end(t);
            break
        }
    };
    f.prototype.start = function(t) {
        this.classList.add(a);
        if (this.toggleWidth === 0 || this.handleWidth === 0) {
            this.init()
        }
    };
    f.prototype.drag = function(t) {
        var e = t.detail;
        if (!this.isDragging) {
            if (e.direction === "left" || e.direction === "right") {
                this.isDragging = true;
                this.lastChanged = undefined;
                this.initialState = this.classList.contains(r)
            }
        }
        if (this.isDragging) {
            this.setTranslateX(e.deltaX);
            t.stopPropagation();
            e.gesture.preventDefault()
        }
    };
    f.prototype.swiperight = function(t) {
        if (this.isDragging) {
            t.stopPropagation()
        }
    };
    f.prototype.end = function(e) {
        this.classList.remove(a);
        if (this.isDragging) {
            this.isDragging = false;
            e.stopPropagation();
            t.trigger(this.element, "toggle", {
                isActive: this.classList.contains(r)
            })
        } else {
            this.toggle()
        }
    };
    f.prototype.toggle = function() {
        var e = this.classList;
        if (e.contains(r)) {
            e.remove(r);
            this.handle.style.webkitTransform = "translate(0,0)"
        } else {
            e.add(r);
            this.handle.style.webkitTransform = "translate(" + this.handleX + "px,0)"
        }
        t.trigger(this.element, "toggle", {
            isActive: this.classList.contains(r)
        })
    };
    f.prototype.setTranslateX = t.animationFrame(function(t) {
        if (!this.isDragging) {
            return 
        }
        var e = false;
        if (this.initialState&&-t > this.handleX / 2 ||!this.initialState && t > this.handleX / 2) {
            e = true
        }
        if (this.lastChanged !== e) {
            if (e) {
                this.handle.style.webkitTransform = "translate(" + (this.initialState ? 0 : this.handleX) + "px,0)";
                this.classList[this.initialState ? "remove": "add"](r)
            } else {
                this.handle.style.webkitTransform = "translate(" + (this.initialState ? this.handleX : 0) + "px,0)";
                this.classList[this.initialState ? "add": "remove"](r)
            }
            this.lastChanged = e
        }
    });
    t.fn["switch"] = function(e) {
        var i = [];
        this.each(function() {
            var e = null;
            var s = this.getAttribute("data-switch");
            if (!s) {
                s=++t.uuid;
                t.data[s] = new f(this);
                this.setAttribute("data-switch", s)
            } else {
                e = t.data[s]
            }
            i.push(e)
        });
        return i.length > 1 ? i : i[0]
    };
    t.ready(function() {
        t("." + s)["switch"]()
    })
})(mui, window, "toggle");
(function(t, e, i) {
    var s = "mui-active";
    var n = "mui-selected";
    var r = "mui-grid-view";
    var a = "mui-table-view-radio";
    var o = "mui-table-view-cell";
    var l = "mui-collapse-content";
    var c = "mui-disabled";
    var f = "mui-switch";
    var u = "mui-btn";
    var h = "mui-slider-handle";
    var d = "mui-slider-left";
    var p = "mui-slider-right";
    var v = "mui-transitioning";
    var g = "." + h;
    var m = "." + d;
    var w = "." + p;
    var b = "." + n;
    var y = "." + u;
    var L = .8;
    var T, x;
    var E = isOpened = openedActions = progress = false;
    var S = sliderActionLeft = sliderActionRight = buttonsLeft = buttonsRight = sliderDirection = sliderRequestAnimationFrame = false;
    var k = translateX = lastTranslateX = sliderActionLeftWidth = sliderActionRightWidth = 0;
    var C = function(t) {
        if (t) {
            if (x) {
                x.classList.add(s)
            } else if (T) {
                T.classList.add(s)
            }
        } else {
            k && k.cancel();
            if (x) {
                x.classList.remove(s)
            } else if (T) {
                T.classList.remove(s)
            }
        }
    };
    var _ = function() {
        if (translateX !== lastTranslateX) {
            if (buttonsRight && buttonsRight.length > 0) {
                progress = translateX / sliderActionRightWidth;
                if (translateX<-sliderActionRightWidth) {
                    translateX =- sliderActionRightWidth - Math.pow( - translateX - sliderActionRightWidth, L)
                }
                for (var t = 0, e = buttonsRight.length; t < e; t++) {
                    var i = buttonsRight[t];
                    if (typeof i._buttonOffset === "undefined") {
                        i._buttonOffset = i.offsetLeft
                    }
                    buttonOffset = i._buttonOffset;
                    A(i, translateX - buttonOffset * (1 + Math.max(progress, - 1)))
                }
            }
            if (buttonsLeft && buttonsLeft.length > 0) {
                progress = translateX / sliderActionLeftWidth;
                if (translateX > sliderActionLeftWidth) {
                    translateX = sliderActionLeftWidth + Math.pow(translateX - sliderActionLeftWidth, L)
                }
                for (var t = 0, e = buttonsLeft.length; t < e; t++) {
                    var s = buttonsLeft[t];
                    if (typeof s._buttonOffset === "undefined") {
                        s._buttonOffset = sliderActionLeftWidth - s.offsetLeft - s.offsetWidth
                    }
                    buttonOffset = s._buttonOffset;
                    if (buttonsLeft.length > 1) {
                        s.style.zIndex = buttonsLeft.length - t
                    }
                    A(s, translateX + buttonOffset * (1 - Math.min(progress, 1)))
                }
            }
            A(S, translateX);
            lastTranslateX = translateX
        }
        sliderRequestAnimationFrame = requestAnimationFrame(function() {
            _()
        })
    };
    var A = function(t, e) {
        if (t) {
            t.style.webkitTransform = "translate3d(" + e + "px,0,0)"
        }
    };
    e.addEventListener("touchstart", function(e) {
        if (T) {
            C(false)
        }
        T = x = false;
        E = isOpened = openedActions = false;
        var s = e.target;
        var n = false;
        for (; s && s !== i; s = s.parentNode) {
            if (s.classList) {
                var h = s.classList;
                if (s.tagName === "INPUT" && s.type !== "radio" && s.type !== "checkbox" || s.tagName === "BUTTON" || h.contains(f) || h.contains(u) || h.contains(c)) {
                    n = true
                }
                if (h.contains(l)) {
                    break
                }
                if (h.contains(o)) {
                    T = s;
                    var d = T.parentNode.querySelector(b);
                    if (!T.parentNode.classList.contains(a) && d && d !== T) {
                        t.swipeoutClose(d);
                        T = n = false;
                        return 
                    }
                    if (!T.parentNode.classList.contains(r)) {
                        var p = T.querySelector("a");
                        if (p && p.parentNode === T) {
                            x = p
                        }
                    }
                    var v = T.querySelector(g);
                    if (v) {
                        P(T);
                        e.stopPropagation()
                    }
                    if (!n) {
                        if (v) {
                            if (k) {
                                k.cancel()
                            }
                            k = t.later(function() {
                                C(true)
                            }, 100)
                        } else {
                            C(true)
                        }
                    }
                    break
                }
            }
        }
    });
    e.addEventListener("touchmove", function(t) {
        C(false)
    });
    var N = {
        handleEvent: function(t) {
            switch (t.type) {
            case"drag":
                this.drag(t);
                break;
            case"dragend":
                this.dragend(t);
                break;
            case"flick":
                this.flick(t);
                break;
            case"swiperight":
                this.swiperight(t);
                break;
            case"swipeleft":
                this.swipeleft(t);
                break
            }
        },
        drag: function(t) {
            if (!T) {
                return 
            }
            if (!E) {
                S = sliderActionLeft = sliderActionRight = buttonsLeft = buttonsRight = sliderDirection = sliderRequestAnimationFrame = false;
                S = T.querySelector(g);
                if (S) {
                    sliderActionLeft = T.querySelector(m);
                    sliderActionRight = T.querySelector(w);
                    if (sliderActionLeft) {
                        sliderActionLeftWidth = sliderActionLeft.offsetWidth;
                        buttonsLeft = sliderActionLeft.querySelectorAll(y)
                    }
                    if (sliderActionRight) {
                        sliderActionRightWidth = sliderActionRight.offsetWidth;
                        buttonsRight = sliderActionRight.querySelectorAll(y)
                    }
                    T.classList.remove(v);
                    isOpened = T.classList.contains(n);
                    if (isOpened) {
                        openedActions = T.querySelector(m + b) ? "left" : "right"
                    }
                }
            }
            var e = t.detail;
            var i = e.direction;
            var s = e.angle;
            if (i === "left" && (s > 150 || s<-150)) {
                if (buttonsRight || buttonsLeft && isOpened) {
                    E = true
                }
            } else if (i === "right" && (s>-30 && s < 30)) {
                if (buttonsLeft || buttonsRight && isOpened) {
                    E = true
                }
            }
            if (E) {
                t.stopPropagation();
                t.detail.gesture.preventDefault();
                var r = t.detail.deltaX;
                if (isOpened) {
                    if (openedActions === "right") {
                        r = r - sliderActionRightWidth
                    } else {
                        r = r + sliderActionLeftWidth
                    }
                }
                if (r > 0&&!buttonsLeft || r < 0&&!buttonsRight) {
                    if (!isOpened) {
                        return 
                    }
                    r = 0
                }
                if (r < 0) {
                    sliderDirection = "toLeft"
                } else if (r > 0) {
                    sliderDirection = "toRight"
                } else {
                    if (!sliderDirection) {
                        sliderDirection = "toLeft"
                    }
                }
                if (!sliderRequestAnimationFrame) {
                    _()
                }
                translateX = r
            }
        },
        flick: function(t) {
            if (E) {
                t.stopPropagation()
            }
        },
        swipeleft: function(t) {
            if (E) {
                t.stopPropagation()
            }
        },
        swiperight: function(t) {
            if (E) {
                t.stopPropagation()
            }
        },
        dragend: function(e) {
            if (!E) {
                return 
            }
            e.stopPropagation();
            if (sliderRequestAnimationFrame) {
                cancelAnimationFrame(sliderRequestAnimationFrame);
                sliderRequestAnimationFrame = null
            }
            var i = e.detail;
            E = false;
            var s = "close";
            var r = sliderDirection === "toLeft" ? sliderActionRightWidth: sliderActionLeftWidth;
            var a = i.swipe || Math.abs(translateX) > r / 2;
            if (a) {
                if (!isOpened) {
                    s = "open"
                } else if (i.direction === "left" && openedActions === "right") {
                    s = "open"
                } else if (i.direction === "right" && openedActions === "left") {
                    s = "open"
                }
            }
            T.classList.add(v);
            var o;
            if (s === "open") {
                var l = sliderDirection === "toLeft"?-r : r;
                A(S, l);
                o = sliderDirection === "toLeft" ? buttonsRight : buttonsLeft;
                if (typeof o !== "undefined") {
                    var c = null;
                    for (var f = 0; f < o.length; f++) {
                        c = o[f];
                        A(c, l)
                    }
                    c.parentNode.classList.add(n);
                    T.classList.add(n);
                    if (!isOpened) {
                        t.trigger(T, sliderDirection === "toLeft" ? "slideleft" : "slideright")
                    }
                }
            } else {
                A(S, 0);
                sliderActionLeft && sliderActionLeft.classList.remove(n);
                sliderActionRight && sliderActionRight.classList.remove(n);
                T.classList.remove(n)
            }
            var u;
            if (buttonsLeft && buttonsLeft.length > 0 && buttonsLeft !== o) {
                for (var f = 0, h = buttonsLeft.length; f < h; f++) {
                    var d = buttonsLeft[f];
                    u = d._buttonOffset;
                    if (typeof u === "undefined") {
                        d._buttonOffset = sliderActionLeftWidth - d.offsetLeft - d.offsetWidth
                    }
                    A(d, u)
                }
            }
            if (buttonsRight && buttonsRight.length > 0 && buttonsRight !== o) {
                for (var f = 0, h = buttonsRight.length; f < h; f++) {
                    var p = buttonsRight[f];
                    u = p._buttonOffset;
                    if (typeof u === "undefined") {
                        p._buttonOffset = p.offsetLeft
                    }
                    A(p, - u)
                }
            }
        }
    };
    function P(t, e) {
        var i=!!e ? "removeEventListener" : "addEventListener";
        t[i]("drag", N);
        t[i]("dragend", N);
        t[i]("swiperight", N);
        t[i]("swipeleft", N);
        t[i]("flick", N)
    }
    t.swipeoutOpen = function(e, i) {
        if (!e)
            return;
        var s = e.classList;
        if (s.contains(n))
            return;
        if (!i) {
            if (e.querySelector(w)) {
                i = "right"
            } else {
                i = "left"
            }
        }
        var r = e.querySelector(t.classSelector(".slider-" + i));
        if (!r)
            return;
        r.classList.add(n);
        s.add(n);
        s.remove(v);
        var a = r.querySelectorAll(y);
        var o = r.offsetWidth;
        var l = i === "right"?-o : o;
        var c = a.length;
        var f;
        for (var u = 0; u < c; u++) {
            f = a[u];
            if (i === "right") {
                A(f, - f.offsetLeft)
            } else {
                A(f, o - f.offsetWidth - f.offsetLeft)
            }
        }
        s.add(v);
        for (var u = 0; u < c; u++) {
            A(a[u], l)
        }
        A(e.querySelector(g), l)
    };
    t.swipeoutClose = function(e) {
        if (!e)
            return;
        var i = e.classList;
        if (!i.contains(n))
            return;
        var s = e.querySelector(w + b) ? "right": "left";
        var r = e.querySelector(t.classSelector(".slider-" + s));
        if (!r)
            return;
        r.classList.remove(n);
        i.remove(n);
        i.add(v);
        var a = r.querySelectorAll(y);
        var o = r.offsetWidth;
        var l = a.length;
        var c;
        A(e.querySelector(g), 0);
        for (var f = 0; f < l; f++) {
            c = a[f];
            if (s === "right") {
                A(c, - c.offsetLeft)
            } else {
                A(c, o - c.offsetWidth - c.offsetLeft)
            }
        }
    };
    e.addEventListener("touchend", function(t) {
        if (!T) {
            return 
        }
        C(false);
        S && P(T, true)
    });
    e.addEventListener("touchcancel", function(t) {
        if (!T) {
            return 
        }
        C(false);
        S && P(T, true)
    });
    var R = function(e) {
        var i = e.target && e.target.type || "";
        if (i === "radio" || i === "checkbox") {
            return 
        }
        var s = T.classList;
        if (s.contains("mui-radio")) {
            var n = T.querySelector("input[type=radio]");
            if (n) {
                if (!n.disabled&&!n.readOnly) {
                    n.checked=!n.checked;
                    t.trigger(n, "change")
                }
            }
        } else if (s.contains("mui-checkbox")) {
            var n = T.querySelector("input[type=checkbox]");
            if (n) {
                if (!n.disabled&&!n.readOnly) {
                    n.checked=!n.checked;
                    t.trigger(n, "change")
                }
            }
        }
    };
    e.addEventListener(t.EVENT_CLICK, function(t) {
        if (T && T.classList.contains("mui-collapse")) {
            t.preventDefault()
        }
    });
    e.addEventListener("doubletap", function(t) {
        if (T) {
            R(t)
        }
    });
    var X = /^(INPUT|TEXTAREA|BUTTON|SELECT)$/;
    e.addEventListener("tap", function(e) {
        if (!T) {
            return 
        }
        var i = false;
        var r = T.classList;
        var o = T.parentNode;
        if (o && o.classList.contains(a)) {
            if (r.contains(n)) {
                return 
            }
            var l = o.querySelector("li" + b);
            if (l) {
                l.classList.remove(n)
            }
            r.add(n);
            t.trigger(T, "selected", {
                el: T
            });
            return 
        }
        if (r.contains("mui-collapse")&&!T.parentNode.classList.contains("mui-unfold")) {
            if (!X.test(e.target.tagName)) {
                e.detail.gesture.preventDefault()
            }
            if (!r.contains(s)) {
                var c = T.parentNode.querySelector(".mui-collapse.mui-active");
                if (c) {
                    c.classList.remove(s)
                }
                i = true
            }
            r.toggle(s);
            if (i) {
                t.trigger(T, "expand")
            }
        } else {
            R(e)
        }
    })
})(mui, window, document);
(function(t, e) {
    t.alert = function(i, s, n, r) {
        if (t.os.plus) {
            if (typeof i === undefined) {
                return 
            } else {
                if (typeof s === "function") {
                    r = s;
                    s = null;
                    n = "ȷ��"
                } else if (typeof n === "function") {
                    r = n;
                    n = null
                }
                t.plusReady(function() {
                    plus.nativeUI.alert(i, r, s, n)
                })
            }
        } else {
            e.alert(i)
        }
    }
})(mui, window);
(function(t, e) {
    t.confirm = function(i, s, n, r) {
        if (t.os.plus) {
            if (typeof i === undefined) {
                return 
            } else {
                if (typeof s === "function") {
                    r = s;
                    s = null;
                    n = null
                } else if (typeof n === "function") {
                    r = n;
                    n = null
                }
                t.plusReady(function() {
                    plus.nativeUI.confirm(i, r, s, n)
                })
            }
        } else {
            if (e.confirm(i)) {
                r({
                    index: 0
                })
            } else {
                r({
                    index: 1
                })
            }
        }
    }
})(mui, window);
(function(t, e) {
    t.prompt = function(i, s, n, r, a) {
        if (t.os.plus) {
            if (typeof message === undefined) {
                return 
            } else {
                if (typeof s === "function") {
                    a = s;
                    s = null;
                    n = null;
                    r = null
                } else if (typeof n === "function") {
                    a = n;
                    n = null;
                    r = null
                } else if (typeof r === "function") {
                    a = r;
                    r = null
                }
                t.plusReady(function() {
                    plus.nativeUI.prompt(i, a, n, s, r)
                })
            }
        } else {
            var o = e.prompt(i);
            if (o) {
                a({
                    index: 0,
                    value: o
                })
            } else {
                a({
                    index: 1,
                    value: ""
                })
            }
        }
    }
})(mui, window);
(function(t, e) {
    t.toast = function(e) {
        if (t.os.plus) {
            t.plusReady(function() {
                plus.nativeUI.toast(e, {
                    verticalAlign: "bottom"
                })
            })
        } else {
            var i = document.createElement("div");
            i.classList.add("mui-toast-container");
            i.innerHTML = '<div class="' + "mui-toast-message" + '">' + e + "</div>";
            document.body.appendChild(i);
            setTimeout(function() {
                document.body.removeChild(i)
            }, 2e3)
        }
    }
})(mui, window);
(function(t, e, i) {
    var s = "mui-icon";
    var n = "mui-icon-clear";
    var r = "mui-icon-speech";
    var a = "mui-icon-search";
    var o = "mui-input-row";
    var l = "mui-placeholder";
    var c = "mui-tooltip";
    var f = "mui-hidden";
    var u = "mui-focusin";
    var h = "." + n;
    var d = "." + r;
    var p = "." + l;
    var v = "." + c;
    var g = function(t) {
        for (; t && t !== i; t = t.parentNode) {
            if (t.classList && t.classList.contains(o)) {
                return t
            }
        }
        return null
    };
    var m = function(t, e) {
        this.element = t;
        this.options = e || {
            actions: "clear"
        };
        if (~this.options.actions.indexOf("slider")) {
            this.sliderActionClass = c + " " + f;
            this.sliderActionSelector = v
        } else {
            if (~this.options.actions.indexOf("clear")) {
                this.clearActionClass = s + " " + n + " " + f;
                this.clearActionSelector = h
            }
            if (~this.options.actions.indexOf("speech")) {
                this.speechActionClass = s + " " + r;
                this.speechActionSelector = d
            }
            if (~this.options.actions.indexOf("search")) {
                this.searchActionClass = l;
                this.searchActionSelector = p
            }
        }
        this.init()
    };
    m.prototype.init = function() {
        this.initAction();
        this.initElementEvent()
    };
    m.prototype.initAction = function() {
        var e = this;
        var i = e.element.parentNode;
        if (i) {
            if (e.sliderActionClass) {
                e.sliderAction = e.createAction(i, e.sliderActionClass, e.sliderActionSelector)
            } else {
                if (e.searchActionClass) {
                    e.searchAction = e.createAction(i, e.searchActionClass, e.searchActionSelector);
                    e.searchAction.addEventListener("tap", function(i) {
                        t.focus(e.element);
                        i.stopPropagation()
                    })
                }
                if (e.speechActionClass) {
                    e.speechAction = e.createAction(i, e.speechActionClass, e.speechActionSelector);
                    e.speechAction.addEventListener("click", t.stopPropagation);
                    e.speechAction.addEventListener("tap", function(t) {
                        e.speechActionClick(t)
                    })
                }
                if (e.clearActionClass) {
                    e.clearAction = e.createAction(i, e.clearActionClass, e.clearActionSelector);
                    e.clearAction.addEventListener("tap", function(t) {
                        e.clearActionClick(t)
                    })
                }
            }
        }
    };
    m.prototype.createAction = function(t, e, n) {
        var r = t.querySelector(n);
        if (!r) {
            var r = i.createElement("span");
            r.className = e;
            if (e === this.searchActionClass) {
                r.innerHTML = '<span class="' + s + " " + a + '"></span><span>' + this.element.getAttribute("placeholder") + "</span>";
                this.element.setAttribute("placeholder", "");
                if (this.element.value.trim()) {
                    t.classList.add("mui-active")
                }
            }
            t.insertBefore(r, this.element.nextSibling)
        }
        return r
    };
    m.prototype.initElementEvent = function() {
        var e = this.element;
        if (this.sliderActionClass) {
            var i = this.sliderAction;
            var s = e.offsetLeft;
            var n = e.offsetWidth - 28;
            var r = i.offsetWidth;
            var a = Math.abs(e.max - e.min);
            var o = null;
            var l = function() {
                i.classList.remove(f);
                r = r || i.offsetWidth;
                var t = n / a * Math.abs(e.value - e.min);
                i.style.left = 14 + s + t - r / 2 + "px";
                i.innerText = e.value;
                if (o) {
                    clearTimeout(o)
                }
                o = setTimeout(function() {
                    i.classList.add(f)
                }, 1e3)
            };
            e.addEventListener("input", l);
            e.addEventListener("tap", l);
            e.addEventListener("touchmove", function(t) {
                t.stopPropagation()
            })
        } else {
            if (this.clearActionClass) {
                var c = this.clearAction;
                if (!c) {
                    return 
                }
                t.each(["keyup", "change", "input", "focus", "cut", "paste"], function(t, i) {
                    (function(t) {
                        e.addEventListener(t, function() {
                            c.classList[e.value.trim() ? "remove": "add"](f)
                        })
                    })(i)
                });
                e.addEventListener("blur", function() {
                    c.classList.add(f)
                })
            }
            if (this.searchActionClass) {
                e.addEventListener("focus", function() {
                    e.parentNode.classList.add("mui-active")
                });
                e.addEventListener("blur", function() {
                    if (!e.value.trim()) {
                        e.parentNode.classList.remove("mui-active")
                    }
                })
            }
        }
    };
    m.prototype.setPlaceholder = function(t) {
        if (this.searchActionClass) {
            var e = this.element.parentNode.querySelector(p);
            e && (e.getElementsByTagName("span")[1].innerText = t)
        } else {
            this.element.setAttribute("placeholder", t)
        }
    };
    m.prototype.clearActionClick = function(e) {
        var i = this;
        i.element.value = "";
        t.focus(i.element);
        i.clearAction.classList.add(f);
        e.preventDefault()
    };
    m.prototype.speechActionClick = function(s) {
        if (e.plus) {
            var n = this;
            var r = n.element.value;
            n.element.value = "";
            i.body.classList.add(u);
            plus.speech.startRecognize({
                engine: "iFly"
            }, function(e) {
                n.element.value += e;
                t.focus(n.element);
                plus.speech.stopRecognize();
                t.trigger(n.element, "recognized", {
                    value: n.element.value
                });
                if (r !== n.element.value) {
                    t.trigger(n.element, "change");
                    t.trigger(n.element, "input")
                }
            }, function(t) {
                i.body.classList.remove(u)
            })
        } else {
            alert("only for 5+")
        }
        s.preventDefault()
    };
    t.fn.input = function(e) {
        var i = [];
        this.each(function() {
            var e = null;
            var s = [];
            var n = g(this.parentNode);
            if (this.type === "range" && n.classList.contains("mui-input-range")) {
                s.push("slider")
            } else {
                var r = this.classList;
                if (r.contains("mui-input-clear")) {
                    s.push("clear")
                }
                if (r.contains("mui-input-speech")) {
                    s.push("speech")
                }
                if (this.type === "search" && n.classList.contains("mui-search")) {
                    s.push("search")
                }
            }
            var a = this.getAttribute("data-input-" + s[0]);
            if (!a) {
                a=++t.uuid;
                e = t.data[a] = new m(this, {
                    actions: s.join(",")
                });
                for (var o = 0, l = s.length; o < l; o++) {
                    this.setAttribute("data-input-" + s[o], a)
                }
            } else {
                e = t.data[a]
            }
            i.push(e)
        });
        return i.length === 1 ? i[0] : i
    };
    t.ready(function() {
        t(".mui-input-row input").input()
    })
})(mui, window, document);
(function(t) {
    var e = "ontouchstart"in document;
    var i = e ? "tap": "click";
    var s = "change";
    var n = "mui-numbox";
    var r = "mui-numbox-btn-plus";
    var a = "mui-numbox-btn-minus";
    var o = "mui-numbox-input";
    var l = t.Numbox = t.Class.extend({
        init: function(e, i) {
            var s = this;
            if (!e) {
                throw "\u6784\u9020\u0020\u006e\u0075\u006d\u0062\u006f\u0078\u0020\u65f6\u7f3a\u5c11\u5bb9\u5668\u5143\u7d20"
            }
            s.holder = e;
            i = i || {};
            i.step = parseInt(i.step || 1);
            s.options = i;
            s.input = t.qsa("." + o, s.holder)[0];
            s.plus = t.qsa("." + r, s.holder)[0];
            s.minus = t.qsa("." + a, s.holder)[0];
            s.checkValue();
            s.initEvent()
        },
        initEvent: function() {
            var e = this;
            e.plus.addEventListener(i, function(i) {
                var n = parseInt(e.input.value) + e.options.step;
                e.input.value = n.toString();
                t.trigger(e.input, s, null)
            });
            e.minus.addEventListener(i, function(i) {
                var n = parseInt(e.input.value) - e.options.step;
                e.input.value = n.toString();
                t.trigger(e.input, s, null)
            });
            e.input.addEventListener(s, function(t) {
                e.checkValue()
            })
        },
        checkValue: function() {
            var t = this;
            var e = t.input.value;
            if (e == null || e == "" || isNaN(e)) {
                t.input.value = t.options.min || 0;
                t.minus.disabled = t.options.min != null
            } else {
                var e = parseInt(e);
                if (t.options.max != null&&!isNaN(t.options.max) && e >= parseInt(t.options.max)) {
                    e = t.options.max;
                    t.plus.disabled = true
                } else {
                    t.plus.disabled = false
                }
                if (t.options.min != null&&!isNaN(t.options.min) && e <= parseInt(t.options.min)) {
                    e = t.options.min;
                    t.minus.disabled = true
                } else {
                    t.minus.disabled = false
                }
                t.input.value = e
            }
        },
        setOption: function(t, e) {
            var i = this;
            i.options[t] = e
        }
    });
    t.fn.numbox = function(t) {
        var e = [];
        this.each(function(t, e) {
            if (e.numbox)
                return;
            if (s) {
                e.numbox = new l(e, s)
            } else {
                var i = e.getAttribute("data-numbox-options");
                var s = i ? JSON.parse(i): {};
                s.step = e.getAttribute("data-numbox-step") || s.step;
                s.min = e.getAttribute("data-numbox-min") || s.min;
                s.max = e.getAttribute("data-numbox-max") || s.max;
                e.numbox = new l(e, s)
            }
        });
        return this[0] ? this[0].numbox : null
    };
    t.ready(function() {
        t("." + n).numbox()
    })
})(mui);;

(function($) {
    $.extend($.fn, {
        cookie: function(key, value, options) {
            var days, time, result, decode
            if (arguments.length > 1 && String(value) !== "[object Object]") {
                options = $.extend({}, options)
                if (value === null || value === undefined)
                    options.expires =- 1
                if (typeof options.expires === 'number') {
                    days = (options.expires * 24 * 60 * 60 * 1000)
                    time = options.expires = new Date()
                    time.setTime(time.getTime() + days)
                }
                value = String(value)
                return (document.cookie = [encodeURIComponent(key), '=', options.raw ? value: encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString(): '', options.path ? '; path=' + options.path: '', options.domain ? '; domain=' + options.domain: '', options.secure ? '; secure': ''].join(''))
            }
            options = value || {}
            decode = options.raw ? function(s) {
                return s
            } : decodeURIComponent
            return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null
        }
    })
})(Zepto);;
(function(t, i) {
    var n = "", e, a, s, o = {
        Webkit: "webkit",
        Moz: "",
        O: "o",
        ms: "MS"
    }, f = window.document, r = f.createElement("div"), c = /^((translate|rotate|scale)(X|Y|Z|3d)?|matrix(3d)?|perspective|skew(X|Y)?)$/i, u, d, l, p, m, y, h, b, x, g = {};
    function w(t) {
        return t.replace(/([a-z])([A-Z])/, "$1-$2").toLowerCase()
    }
    function E(t) {
        return e ? e + t : t.toLowerCase()
    }
    t.each(o, function(t, a) {
        if (r.style[t + "TransitionProperty"] !== i) {
            n = "-" + t.toLowerCase() + "-";
            e = a;
            return false
        }
    });
    u = n + "transform";
    g[d = n + "transition-property"] = g[l = n + "transition-duration"] = g[m = n + "transition-delay"] = g[p = n + "transition-timing-function"] = g[y = n + "animation-name"] = g[h = n + "animation-duration"] = g[x = n + "animation-delay"] = g[b = n + "animation-timing-function"] = "";
    t.fx = {
        off: e === i && r.style.transitionProperty === i,
        speeds: {
            _default: 400,
            fast: 200,
            slow: 600
        },
        cssPrefix: n,
        transitionEnd: E("TransitionEnd"),
        animationEnd: E("AnimationEnd")
    };
    t.fn.animate = function(i, n, e, a, s) {
        if (t.isPlainObject(n))
            e = n.easing, a = n.complete, s = n.delay, n = n.duration;
        if (n)
            n = (typeof n == "number" ? n : t.fx.speeds[n] || t.fx.speeds._default) / 1e3;
        if (s)
            s = parseFloat(s) / 1e3;
        return this.anim(i, n, e, a, s)
    };
    t.fn.anim = function(n, e, a, s, o) {
        var f, r = {}, E, k = "", v = this, L, P = t.fx.transitionEnd;
        if (e === i)
            e = .4;
        if (o === i)
            o = 0;
        if (t.fx.off)
            e = 0;
        if (typeof n == "string") {
            r[y] = n;
            r[h] = e + "s";
            r[x] = o + "s";
            r[b] = a || "linear";
            P = t.fx.animationEnd
        } else {
            E = [];
            for (f in n)
                if (c.test(f))
                    k += f + "(" + n[f] + ") ";
                else 
                    r[f] = n[f], E.push(w(f));
            if (k)
                r[u] = k, E.push(u);
            if (e > 0 && typeof n === "object") {
                r[d] = E.join(", ");
                r[l] = e + "s";
                r[m] = o + "s";
                r[p] = a || "linear"
            }
        }
        L = function(i) {
            if (typeof i !== "undefined") {
                if (i.target !== i.currentTarget)
                    return t(i.target).unbind(P, L)
            }
            t(this).css(g);
            s && s.call(this)
        };
        if (e > 0)
            this.bind(P, L);
        this.size() && this.get(0).clientLeft;
        this.css(r);
        if (e <= 0)
            setTimeout(function() {
                v.each(function() {
                    L.call(this)
                })
            }, 0);
        return this
    };
    t.extend(t.fn, {
        fadeIn: function(i) {
            if (typeof i === "undefined") {
                i = 250
            }
            t(this).css({
                display: "block",
                opacity: 0
            }).animate({
                opacity: 1
            }, i);
            return this
        },
        fadeOut: function(i) {
            if (typeof i === "undefined") {
                i = 250
            }
            t(this).css({
                display: "block",
                opacity: 1
            }).animate({
                opacity: 0
            }, i);
            return this
        }
    });
    r = null
})(Zepto);;
(function(i) {
    i.fn.slideDown = function(i) {
        var t = this.css("position");
        this.show();
        this.css({
            position: "absolute",
            visibility: "hidden",
            height: "auto"
        });
        var h = this.height();
        this.css({
            position: t,
            visibility: "visible",
            overflow: "hidden",
            height: 0
        });
        s(this, h, i)
    };
    i.fn.slideUp = function(i) {
        s(this, 0, i)
    };
    function s(i, s, t) {
        i.animate({
            height: s
        }, t, "", function() {
            s == 0 ? i.hide() : i.show()
        })
    }
})($);;
(function(A) {
    A.fn.lazyload = function(a) {
        var o = A("img[data-lazy]"), t = 0, n = A(window).height();
        a = A.extend({
            threshold: 0,
            placeholder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
        }, a || {});
        var i = 0;
        A(window).on("scroll", function() {
            __lazyLoad(A(window).scrollTop());
            if (!i) {
                i = 1;
                setTimeout(function() {
                    i = 0;
                    o = A("img[data-lazy]")
                }, 1e3)
            }
        });
        window.__lazyLoad = function(t) {
            if (!o.length) {
                return 
            }
            o.each(function() {
                var o = A(this);
                if (o.is("img") && o.data("lazy")) {
                    var i = o.offset().top;
                    if (i - a.threshold <= n + t) {
                        o.attr("src", o.data("lazy"));
                        o.removeAttr("data-lazy")
                    }
                }
            })
        };
        __lazyLoad()
    }
})(window.Zepto || window.$);;
(function(t) {
    t.fn.suggest = function(a) {
        a = t.extend({
            onQuery: function(t, a) {},
            time: 100,
            listClass: "suggest-list",
            appendParent: false,
            listTpl: ""
        }, a);
        t(this).each(function() {
            var e = t(this);
            var s = {}, i = 0;
            console.log(e.data("parent"));
            var n = t('<div class="' + a.listClass + '"></div>').appendTo(e.data("parent") ? t(e.data("parent")) : t(document.body));
            function o(s) {
                n.hide();
                t(window).off("scroll", r);
                if (!s || s == 1 || s.length == 0) {
                    return 
                }
                r();
                var i = mzTpl(e.data("tpl") ? t("#" + e.data("tpl")).html() : a.listTpl, {
                    list: s
                });
                n.html(i).show();
                n.find("li").css("font-size", e.css("font-size"))
            }
            function r() {
                var a = e.data("suggestleft");
                var s = e.data("suggestbottom");
                var i = e.data("suggestright");
                var o = parseInt(e.data("suggestmargintop"), 10);
                var f = e.offset();
                var l = t(document.body).offset();
                var d = {
                    left: f.left - parseInt(l.left, 10),
                    top: f.top + parseInt(e.css("height"), 10) - parseInt(l.top, 10),
                    width: e.data("width") ? e.data("width"): e.width()
                };
                if (parseInt(a, 10) >= 0) {
                    d.left = a
                }
                if (parseInt(s, 10) >= 0) {
                    d.bottom = s
                }
                if (parseInt(i, 10) >= 0) {
                    d.right = i;
                    d.width = "auto"
                }
                if (o >= 0) {
                    d.top += o
                }
                n.css(d);
                t(window).on("scroll", r)
            }
            t(this).on("input", function() {
                if (i) {
                    clearTimeout(i)
                }
                var r = t.trim(t(this).val());
                if (r == "") {
                    n.hide()
                }
                if (s[r]) {
                    o(s[r]);
                    return 
                }
                i = setTimeout(function() {
                    s[r] = 1;
                    a.onQuery && a.onQuery(r, function(t) {
                        i = 0;
                        n.hide();
                        if (t === false) {
                            return 
                        }
                        s[r] = t;
                        o(s[r])
                    }, e)
                }, a.time);
                return false
            })
        })
    }
})($);;

var Swiper = function(a, b) {
    "use strict";
    function c(a, b) {
        return document.querySelectorAll ? (b || document).querySelectorAll(a) : jQuery(a, b)
    }
    function d(a) {
        return "[object Array]" === Object.prototype.toString.apply(a)?!0 : !1
    }
    function e() {
        var a = F - I;
        return b.freeMode && (a = F - I), b.slidesPerView > C.slides.length&&!b.centeredSlides && (a = 0), 0 > a && (a = 0), a
    }
    function f() {
        function a(a) {
            if (a == null) {
                return;
            }
            var c = new Image;
            c.onload = function() {
                "undefined" != typeof C && null !== C && (void 0 !== C.imagesLoaded && C.imagesLoaded++, C.imagesLoaded === C.imagesToLoad.length && (C.reInit(), b.onImagesReady && C.fireCallback(b.onImagesReady, C)))
            }, c.src = a
        }
        var d = C.h.addEventListener, e = "wrapper" === b.eventTarget ? C.wrapper: C.container;
        if (C.browser.ie10 || C.browser.ie11 ? (d(e, C.touchEvents.touchStart, p), d(document, C.touchEvents.touchMove, q), d(document, C.touchEvents.touchEnd, r)) : (C.support.touch && (d(e, "touchstart", p), d(e, "touchmove", q), d(e, "touchend", r)), b.simulateTouch && (d(e, "mousedown", p), d(document, "mousemove", q), d(document, "mouseup", r))), b.autoResize && d(window, "resize", C.resizeFix), g(), C._wheelEvent=!1, b.mousewheelControl) {
            if (void 0 !== document.onmousewheel && (C._wheelEvent = "mousewheel"), !C._wheelEvent)try {
                new WheelEvent("wheel"), C._wheelEvent = "wheel"
            } catch (f) {}
            C._wheelEvent || (C._wheelEvent = "DOMMouseScroll"), C._wheelEvent && d(C.container, C._wheelEvent, j)
        }
        if (b.keyboardControl && d(document, "keydown", i), b.updateOnImagesReady) {
            C.imagesToLoad = c("img", C.container);
            for (var h = 0; h < C.imagesToLoad.length; h++)
                a(C.imagesToLoad[h].getAttribute("src"))
        }
    }
    function g() {
        var a, d = C.h.addEventListener;
        if (b.preventLinks) {
            var e = c("a", C.container);
            for (a = 0; a < e.length; a++)
                d(e[a], "click", n)
        }
        if (b.releaseFormElements) {
            var f = c("input, textarea, select", C.container);
            for (a = 0; a < f.length; a++)
                d(f[a], C.touchEvents.touchStart, o, !0)
        }
        if (b.onSlideClick)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], "click", k);
        if (b.onSlideTouch)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], C.touchEvents.touchStart, l)
    }
    function h() {
        var a, d = C.h.removeEventListener;
        if (b.onSlideClick)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], "click", k);
        if (b.onSlideTouch)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], C.touchEvents.touchStart, l);
        if (b.releaseFormElements) {
            var e = c("input, textarea, select", C.container);
            for (a = 0; a < e.length; a++)
                d(e[a], C.touchEvents.touchStart, o, !0)
        }
        if (b.preventLinks) {
            var f = c("a", C.container);
            for (a = 0; a < f.length; a++)
                d(f[a], "click", n)
        }
    }
    function i(a) {
        var b = a.keyCode || a.charCode;
        if (!(a.shiftKey || a.altKey || a.ctrlKey || a.metaKey)) {
            if (37 === b || 39 === b || 38 === b || 40 === b) {
                for (var c=!1, d = C.h.getOffset(C.container), e = C.h.windowScroll().left, f = C.h.windowScroll().top, g = C.h.windowWidth(), h = C.h.windowHeight(), i = [[d.left, d.top], [d.left + C.width, d.top], [d.left, d.top + C.height], [d.left + C.width, d.top + C.height]], j = 0; j < i.length; j++) {
                    var k = i[j];
                    k[0] >= e && k[0] <= e + g && k[1] >= f && k[1] <= f + h && (c=!0)
                }
                if (!c)
                    return 
            }
            M ? ((37 === b || 39 === b) && (a.preventDefault ? a.preventDefault() : a.returnValue=!1), 39 === b && C.swipeNext(), 37 === b && C.swipePrev()) : ((38 === b || 40 === b) && (a.preventDefault ? a.preventDefault() : a.returnValue=!1), 40 === b && C.swipeNext(), 38 === b && C.swipePrev())
        }
    }
    function j(a) {
        var c = C._wheelEvent, d = 0;
        if (a.detail)
            d =- a.detail;
        else if ("mousewheel" === c)
            if (b.mousewheelControlForceToAxis)
                if (M) {
                    if (!(Math.abs(a.wheelDeltaX) > Math.abs(a.wheelDeltaY)))
                        return;
                        d = a.wheelDeltaX
                } else {
                    if (!(Math.abs(a.wheelDeltaY) > Math.abs(a.wheelDeltaX)))
                        return;
                        d = a.wheelDeltaY
                } else 
                    d = a.wheelDelta;
                else if ("DOMMouseScroll" === c)
            d =- a.detail;
        else if ("wheel" === c)
            if (b.mousewheelControlForceToAxis)
                if (M) {
                    if (!(Math.abs(a.deltaX) > Math.abs(a.deltaY)))
                        return;
                        d =- a.deltaX
                } else {
                    if (!(Math.abs(a.deltaY) > Math.abs(a.deltaX)))
                        return;
                        d =- a.deltaY
                } else 
                    d = Math.abs(a.deltaX) > Math.abs(a.deltaY)?-a.deltaX : - a.deltaY;
        if (b.freeMode) {
            var f = C.getWrapperTranslate() + d;
            if (f > 0 && (f = 0), f<-e() && (f =- e()), C.setWrapperTransition(0), C.setWrapperTranslate(f), C.updateActiveSlide(f), 0 === f || f===-e())
                return 
        } else (new Date)
            .getTime() - U > 60 && (0 > d ? C.swipeNext() : C.swipePrev()), U = (new Date).getTime();
        return b.autoplay && C.stopAutoplay(!0), a.preventDefault ? a.preventDefault() : a.returnValue=!1, !1
    }
    function k(a) {
        C.allowSlideClick && (m(a), C.fireCallback(b.onSlideClick, C, a))
    }
    function l(a) {
        m(a), C.fireCallback(b.onSlideTouch, C, a)
    }
    function m(a) {
        if (a.currentTarget)
            C.clickedSlide = a.currentTarget;
        else {
            var c = a.srcElement;
            do {
                if (c.className.indexOf(b.slideClass)>-1)
                    break;
                c = c.parentNode
            }
            while (c);
            C.clickedSlide = c
        }
        C.clickedSlideIndex = C.slides.indexOf(C.clickedSlide), C.clickedSlideLoopIndex = C.clickedSlideIndex - (C.loopedSlides || 0)
    }
    function n(a) {
        return C.allowLinks ? void 0 : (a.preventDefault ? a.preventDefault() : a.returnValue=!1, b.preventLinksPropagation && "stopPropagation"in a && a.stopPropagation(), !1)
    }
    function o(a) {
        return a.stopPropagation ? a.stopPropagation() : a.returnValue=!1, !1
    }
    function p(a) {
        if (b.preventLinks && (C.allowLinks=!0), C.isTouched || b.onlyExternal)
            return !1;
        var c = a.target || a.srcElement;
        document.activeElement && document.activeElement !== c && document.activeElement.blur();
        var d = "input select textarea".split(" ");
        if (b.noSwiping && c && s(c))
            return !1;
        if ($=!1, C.isTouched=!0, Z = "touchstart" === a.type, !Z && "which"in a && 3 === a.which)
            return !1;
        if (!Z || 1 === a.targetTouches.length) {
            C.callPlugins("onTouchStartBegin"), !Z&&!C.isAndroid && d.indexOf(c.tagName.toLowerCase()) < 0 && (a.preventDefault ? a.preventDefault() : a.returnValue=!1);
            var e = Z ? a.targetTouches[0].pageX: a.pageX || a.clientX, f = Z ? a.targetTouches[0].pageY: a.pageY || a.clientY;
            C.touches.startX = C.touches.currentX = e, C.touches.startY = C.touches.currentY = f, C.touches.start = C.touches.current = M ? e : f, C.setWrapperTransition(0), C.positions.start = C.positions.current = C.getWrapperTranslate(), C.setWrapperTranslate(C.positions.start), C.times.start = (new Date).getTime(), H = void 0, b.moveStartThreshold > 0 && (W=!1), b.onTouchStart && C.fireCallback(b.onTouchStart, C, a), C.callPlugins("onTouchStartEnd")
        }
    }
    function q(a) {
        if (C.isTouched&&!b.onlyExternal && (!Z || "mousemove" !== a.type)) {
            var c = Z ? a.targetTouches[0].pageX: a.pageX || a.clientX, d = Z ? a.targetTouches[0].pageY: a.pageY || a.clientY;
            if ("undefined" == typeof H && M && (H=!!(H || Math.abs(d - C.touches.startY) > Math.abs(c - C.touches.startX))), "undefined" != typeof H || M || (H=!!(H || Math.abs(d - C.touches.startY) < Math.abs(c - C.touches.startX))), H)
                return void(C.isTouched=!1);
            if (M) {
                if (!b.swipeToNext && c < C.touches.startX ||!b.swipeToPrev && c > C.touches.startX)
                    return 
            } else if (!b.swipeToNext && d < C.touches.startY ||!b.swipeToPrev && d > C.touches.startY)
                return;
            if (a.assignedToSwiper)
                return void(C.isTouched=!1);
            if (a.assignedToSwiper=!0, b.preventLinks && (C.allowLinks=!1), b.onSlideClick && (C.allowSlideClick=!1), b.autoplay && C.stopAutoplay(!0), !Z || 1 === a.touches.length) {
                if (C.isMoved || (C.callPlugins("onTouchMoveStart"), b.loop && (C.fixLoop(), C.positions.start = C.getWrapperTranslate()), b.onTouchMoveStart && C.fireCallback(b.onTouchMoveStart, C)), C.isMoved=!0, a.preventDefault ? a.preventDefault() : a.returnValue=!1, C.touches.current = M ? c : d, C.positions.current = (C.touches.current - C.touches.start) * b.touchRatio + C.positions.start, C.positions.current > 0 && b.onResistanceBefore && C.fireCallback(b.onResistanceBefore, C, C.positions.current), C.positions.current<-e() && b.onResistanceAfter && C.fireCallback(b.onResistanceAfter, C, Math.abs(C.positions.current + e())), b.resistance && "100%" !== b.resistance) {
                    var f;
                    if (C.positions.current > 0 && (f = 1 - C.positions.current / I / 2, C.positions.current = .5 > f ? I / 2 : C.positions.current * f), C.positions.current<-e()) {
                        var g = (C.touches.current - C.touches.start) * b.touchRatio + (e() + C.positions.start);
                        f = (I + g) / I;
                        var h = C.positions.current - g * (1 - f) / 2, i =- e() - I / 2;
                        C.positions.current = i > h || 0 >= f ? i : h
                    }
                }
                if (b.resistance && "100%" === b.resistance && (C.positions.current > 0 && (!b.freeMode || b.freeModeFluid) && (C.positions.current = 0), C.positions.current<-e() && (!b.freeMode || b.freeModeFluid) && (C.positions.current =- e())), !b.followFinger)
                    return;
                if (b.moveStartThreshold)
                    if (Math.abs(C.touches.current - C.touches.start) > b.moveStartThreshold || W) {
                        if (!W)
                            return W=!0, void(C.touches.start = C.touches.current);
                            C.setWrapperTranslate(C.positions.current)
                    } else 
                        C.positions.current = C.positions.start;
                    else 
                        C.setWrapperTranslate(C.positions.current);
                return (b.freeMode || b.watchActiveIndex) && C.updateActiveSlide(C.positions.current), b.grabCursor && (C.container.style.cursor = "move", C.container.style.cursor = "grabbing", C.container.style.cursor = "-moz-grabbin", C.container.style.cursor = "-webkit-grabbing"), X || (X = C.touches.current), Y || (Y = (new Date).getTime()), C.velocity = (C.touches.current - X) / ((new Date).getTime() - Y) / 2, Math.abs(C.touches.current - X) < 2 && (C.velocity = 0), X = C.touches.current, Y = (new Date).getTime(), C.callPlugins("onTouchMoveEnd"), b.onTouchMove && C.fireCallback(b.onTouchMove, C, a), !1
            }
        }
    }
    function r(a) {
        if (H && C.swipeReset(), !b.onlyExternal && C.isTouched) {
            C.isTouched=!1, b.grabCursor && (C.container.style.cursor = "move", C.container.style.cursor = "grab", C.container.style.cursor = "-moz-grab", C.container.style.cursor = "-webkit-grab"), C.positions.current || 0 === C.positions.current || (C.positions.current = C.positions.start), b.followFinger && C.setWrapperTranslate(C.positions.current), C.times.end = (new Date).getTime(), C.touches.diff = C.touches.current - C.touches.start, C.touches.abs = Math.abs(C.touches.diff), C.positions.diff = C.positions.current - C.positions.start, C.positions.abs = Math.abs(C.positions.diff);
            var c = C.positions.diff, d = C.positions.abs, f = C.times.end - C.times.start;
            5 > d && 300 > f && C.allowLinks===!1 && (b.freeMode || 0 === d || C.swipeReset(), b.preventLinks && (C.allowLinks=!0), b.onSlideClick && (C.allowSlideClick=!0)), setTimeout(function() {
                "undefined" != typeof C && null !== C && (b.preventLinks && (C.allowLinks=!0), b.onSlideClick && (C.allowSlideClick=!0))
            }, 100);
            var g = e();
            if (!C.isMoved && b.freeMode)
                return C.isMoved=!1, b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd");
            if (!C.isMoved || C.positions.current > 0 || C.positions.current<-g)
                return C.swipeReset(), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd");
            if (C.isMoved=!1, b.freeMode) {
                if (b.freeModeFluid) {
                    var h, i = 1e3 * b.momentumRatio, j = C.velocity * i, k = C.positions.current + j, l=!1, m = 20 * Math.abs(C.velocity) * b.momentumBounceRatio;
                    - g > k && (b.momentumBounce && C.support.transitions ? ( - m > k + g && (k =- g - m), h =- g, l=!0, $=!0) : k =- g), k > 0 && (b.momentumBounce && C.support.transitions ? (k > m && (k = m), h = 0, l=!0, $=!0) : k = 0), 0 !== C.velocity && (i = Math.abs((k - C.positions.current) / C.velocity)), C.setWrapperTranslate(k), C.setWrapperTransition(i), b.momentumBounce && l && C.wrapperTransitionEnd(function() {
                        $ && (b.onMomentumBounce && C.fireCallback(b.onMomentumBounce, C), C.callPlugins("onMomentumBounce"), C.setWrapperTranslate(h), C.setWrapperTransition(300))
                    }), C.updateActiveSlide(k)
                }
                return (!b.freeModeFluid || f >= 300) && C.updateActiveSlide(C.positions.current), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd")
            }
            G = 0 > c ? "toNext" : "toPrev", "toNext" === G && 300 >= f && (30 > d ||!b.shortSwipes ? C.swipeReset() : C.swipeNext(!0)), "toPrev" === G && 300 >= f && (30 > d ||!b.shortSwipes ? C.swipeReset() : C.swipePrev(!0));
            var n = 0;
            if ("auto" === b.slidesPerView) {
                for (var o, p = Math.abs(C.getWrapperTranslate()), q = 0, r = 0; r < C.slides.length; r++)
                    if (o = M ? C.slides[r].getWidth(!0, b.roundLengths) : C.slides[r].getHeight(!0, b.roundLengths), q += o, q > p) {
                        n = o;
                        break
                    }
                n > I && (n = I)
            } else 
                n = E * b.slidesPerView;
            "toNext" === G && f > 300 && (d >= n * b.longSwipesRatio ? C.swipeNext(!0) : C.swipeReset()), "toPrev" === G && f > 300 && (d >= n * b.longSwipesRatio ? C.swipePrev(!0) : C.swipeReset()), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), C.callPlugins("onTouchEnd")
        }
    }
    function s(a) {
        var c=!1;
        do 
            a.className.indexOf(b.noSwipingClass)>-1 && (c=!0), a = a.parentElement;
        while (!c && a.parentElement&&-1 === a.className.indexOf(b.wrapperClass));
        return !c && a.className.indexOf(b.wrapperClass)>-1 && a.className.indexOf(b.noSwipingClass)>-1 && (c=!0), c
    }
    function t(a, b) {
        var c, d = document.createElement("div");
        return d.innerHTML = b, c = d.firstChild, c.className += " " + a, c.outerHTML
    }
    function u(a, c, d) {
        function e() {
            var f =+ new Date, l = f - g;
            h += i * l / (1e3 / 60), k = "toNext" === j ? h > a : a > h, k ? (C.setWrapperTranslate(Math.ceil(h)), C._DOMAnimating=!0, window.setTimeout(function() {
                e()
            }, 1e3 / 60)) : (b.onSlideChangeEnd && ("to" === c ? d.runCallbacks===!0 && C.fireCallback(b.onSlideChangeEnd, C, j) : C.fireCallback(b.onSlideChangeEnd, C, j)), C.setWrapperTranslate(a), C._DOMAnimating=!1)
        }
        var f = "to" === c && d.speed >= 0 ? d.speed: b.speed, g =+ new Date;
        if (C.support.transitions ||!b.DOMAnimation)
            C.setWrapperTranslate(a), C.setWrapperTransition(f);
        else {
            var h = C.getWrapperTranslate(), i = Math.ceil((a - h) / f * (1e3 / 60)), j = h > a ? "toNext": "toPrev", k = "toNext" === j ? h > a: a > h;
            if (C._DOMAnimating)
                return;
            e()
        }
        C.updateActiveSlide(a), b.onSlideNext && "next" === c && C.fireCallback(b.onSlideNext, C, a), b.onSlidePrev && "prev" === c && C.fireCallback(b.onSlidePrev, C, a), b.onSlideReset && "reset" === c && C.fireCallback(b.onSlideReset, C, a), ("next" === c || "prev" === c || "to" === c && d.runCallbacks===!0) && v(c)
    }
    function v(a) {
        if (C.callPlugins("onSlideChangeStart"), b.onSlideChangeStart)
            if (b.queueStartCallbacks && C.support.transitions) {
                if (C._queueStartCallbacks)
                    return;
                    C._queueStartCallbacks=!0, C.fireCallback(b.onSlideChangeStart, C, a), C.wrapperTransitionEnd(function() {
                        C._queueStartCallbacks=!1
                    })
            } else 
                C.fireCallback(b.onSlideChangeStart, C, a);
        if (b.onSlideChangeEnd)
            if (C.support.transitions)
                if (b.queueEndCallbacks) {
                    if (C._queueEndCallbacks)
                        return;
                        C._queueEndCallbacks=!0, C.wrapperTransitionEnd(function(c) {
                            C.fireCallback(b.onSlideChangeEnd, c, a)
                        })
                } else 
                    C.wrapperTransitionEnd(function(c) {
                        C.fireCallback(b.onSlideChangeEnd, c, a)
                    });
                else 
                    b.DOMAnimation || setTimeout(function() {
                        C.fireCallback(b.onSlideChangeEnd, C, a)
                    }, 10)
    }
    function w() {
        var a = C.paginationButtons;
        if (a)
            for (var b = 0; b < a.length; b++)
                C.h.removeEventListener(a[b], "click", y)
    }
    function x() {
        var a = C.paginationButtons;
        if (a)
            for (var b = 0; b < a.length; b++)
                C.h.addEventListener(a[b], "click", y)
    }
    function y(a) {
        for (var c, d = a.target || a.srcElement, e = C.paginationButtons, f = 0; f < e.length; f++)
            d === e[f] && (c = f);
        b.autoplay && C.stopAutoplay(!0), C.swipeTo(c)
    }
    function z() {
        _ = setTimeout(function() {
            b.loop ? (C.fixLoop(), C.swipeNext(!0)) : C.swipeNext(!0) || (b.autoplayStopOnLast ? (clearTimeout(_), _ = void 0) : C.swipeTo(0)), C.wrapperTransitionEnd(function() {
                "undefined" != typeof _ && z()
            })
        }, b.autoplay)
    }
    function A() {
        C.calcSlides(), b.loader.slides.length > 0 && 0 === C.slides.length && C.loadSlides(), b.loop && C.createLoop(), C.init(), f(), b.pagination && C.createPagination(!0), b.loop || b.initialSlide > 0 ? C.swipeTo(b.initialSlide, 0, !1) : C.updateActiveSlide(0), b.autoplay && C.startAutoplay(), C.centerIndex = C.activeIndex, b.onSwiperCreated && C.fireCallback(b.onSwiperCreated, C), C.callPlugins("onSwiperCreated")
    }
    if (!document.body.outerHTML && document.body.__defineGetter__ && HTMLElement) {
        var B = HTMLElement.prototype;
        B.__defineGetter__ && B.__defineGetter__("outerHTML", function() {
            return (new XMLSerializer).serializeToString(this)
        })
    }
    if (window.getComputedStyle || (window.getComputedStyle = function(a) {
        return this.el = a, this.getPropertyValue = function(b) {
            var c = /(\-([a-z]){1})/g;
            return "float" === b && (b = "styleFloat"), c.test(b) && (b = b.replace(c, function() {
                return arguments[2].toUpperCase()
            })), a.currentStyle[b] ? a.currentStyle[b] : null
        }, this
    }), Array.prototype.indexOf || (Array.prototype.indexOf = function(a, b) {
        for (var c = b || 0, d = this.length; d > c; c++)
            if (this[c] === a)
                return c;
        return - 1
    }), (document.querySelectorAll || window.jQuery) && "undefined" != typeof a && (a.nodeType || 0 !== c(a).length)) {
        var C = this;
        C.touches = {
            start: 0,
            startX: 0,
            startY: 0,
            current: 0,
            currentX: 0,
            currentY: 0,
            diff: 0,
            abs: 0
        }, C.positions = {
            start: 0,
            abs: 0,
            diff: 0,
            current: 0
        }, C.times = {
            start: 0,
            end: 0
        }, C.id = (new Date).getTime(), C.container = a.nodeType ? a : c(a)[0], C.isTouched=!1, C.isMoved=!1, C.activeIndex = 0, C.centerIndex = 0, C.activeLoaderIndex = 0, C.activeLoopIndex = 0, C.previousIndex = null, C.velocity = 0, C.snapGrid = [], C.slidesGrid = [], C.imagesToLoad = [], C.imagesLoaded = 0, C.wrapperLeft = 0, C.wrapperRight = 0, C.wrapperTop = 0, C.wrapperBottom = 0, C.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") >= 0;
        var D, E, F, G, H, I, J = {
            eventTarget: "wrapper",
            mode: "horizontal",
            touchRatio: 1,
            speed: 300,
            freeMode: !1,
            freeModeFluid: !1,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            slidesPerView: 1,
            slidesPerGroup: 1,
            slidesPerViewFit: !0,
            simulateTouch: !0,
            followFinger: !0,
            shortSwipes: !0,
            longSwipesRatio: .5,
            moveStartThreshold: !1,
            onlyExternal: !1,
            createPagination: !0,
            pagination: !1,
            paginationElement: "span",
            paginationClickable: !1,
            paginationAsRange: !0,
            resistance: !0,
            scrollContainer: !1,
            preventLinks: !0,
            preventLinksPropagation: !1,
            noSwiping: !1,
            noSwipingClass: "swiper-no-swiping",
            initialSlide: 0,
            keyboardControl: !1,
            mousewheelControl: !1,
            mousewheelControlForceToAxis: !1,
            useCSS3Transforms: !0,
            autoplay: !1,
            autoplayDisableOnInteraction: !0,
            autoplayStopOnLast: !1,
            loop: !1,
            loopAdditionalSlides: 0,
            roundLengths: !1,
            calculateHeight: !1,
            cssWidthAndHeight: !1,
            updateOnImagesReady: !0,
            releaseFormElements: !0,
            watchActiveIndex: !1,
            visibilityFullFit: !1,
            offsetPxBefore: 0,
            offsetPxAfter: 0,
            offsetSlidesBefore: 0,
            offsetSlidesAfter: 0,
            centeredSlides: !1,
            queueStartCallbacks: !1,
            queueEndCallbacks: !1,
            autoResize: !0,
            resizeReInit: !1,
            DOMAnimation: !0,
            loader: {
                slides: [],
                slidesHTMLType: "inner",
                surroundGroups: 1,
                logic: "reload",
                loadAllSlides: !1
            },
            swipeToPrev: !0,
            swipeToNext: !0,
            slideElement: "div",
            slideClass: "swiper-slide",
            slideActiveClass: "swiper-slide-active",
            slideVisibleClass: "swiper-slide-visible",
            slideDuplicateClass: "swiper-slide-duplicate",
            wrapperClass: "swiper-wrapper",
            paginationElementClass: "swiper-pagination-switch",
            paginationActiveClass: "swiper-active-switch",
            paginationVisibleClass: "swiper-visible-switch"
        };
        b = b || {};
        for (var K in J)
            if (K in b && "object" == typeof b[K])
                for (var L in J[K])
                    L in b[K] || (b[K][L] = J[K][L]);
            else 
                K in b || (b[K] = J[K]);
        C.params = b, b.scrollContainer && (b.freeMode=!0, b.freeModeFluid=!0), b.loop && (b.resistance = "100%");
        var M = "horizontal" === b.mode, N = ["mousedown", "mousemove", "mouseup"];
        C.browser.ie10 && (N = ["MSPointerDown", "MSPointerMove", "MSPointerUp"]), C.browser.ie11 && (N = ["pointerdown", "pointermove", "pointerup"]), C.touchEvents = {
            touchStart: C.support.touch ||!b.simulateTouch ? "touchstart": N[0],
            touchMove: C.support.touch ||!b.simulateTouch ? "touchmove": N[1],
            touchEnd: C.support.touch ||!b.simulateTouch ? "touchend": N[2]
        };
        for (var O = C.container.childNodes.length - 1; O >= 0; O--)
            if (C.container.childNodes[O].className)
                for (var P = C.container.childNodes[O].className.split(/\s+/), Q = 0; Q < P.length; Q++)
                    P[Q] === b.wrapperClass && (D = C.container.childNodes[O]);
        C.wrapper = D, C._extendSwiperSlide = function(a) {
            return a.append = function() {
                return b.loop ? a.insertAfter(C.slides.length - C.loopedSlides) : (C.wrapper.appendChild(a), C.reInit()), a
            }, a.prepend = function() {
                return b.loop ? (C.wrapper.insertBefore(a, C.slides[C.loopedSlides]), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : C.wrapper.insertBefore(a, C.wrapper.firstChild), C.reInit(), a
            }, a.insertAfter = function(c) {
                if ("undefined" == typeof c)
                    return !1;
                var d;
                return b.loop ? (d = C.slides[c + 1 + C.loopedSlides], d ? C.wrapper.insertBefore(a, d) : C.wrapper.appendChild(a), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : (d = C.slides[c + 1], C.wrapper.insertBefore(a, d)), C.reInit(), a
            }, a.clone = function() {
                return C._extendSwiperSlide(a.cloneNode(!0))
            }, a.remove = function() {
                C.wrapper.removeChild(a), C.reInit()
            }, a.html = function(b) {
                return "undefined" == typeof b ? a.innerHTML : (a.innerHTML = b, a)
            }, a.index = function() {
                for (var b, c = C.slides.length - 1; c >= 0; c--)
                    a === C.slides[c] && (b = c);
                return b
            }, a.isActive = function() {
                return a.index() === C.activeIndex?!0 : !1
            }, a.swiperSlideDataStorage || (a.swiperSlideDataStorage = {}), a.getData = function(b) {
                return a.swiperSlideDataStorage[b]
            }, a.setData = function(b, c) {
                return a.swiperSlideDataStorage[b] = c, a
            }, a.data = function(b, c) {
                return "undefined" == typeof c ? a.getAttribute("data-" + b) : (a.setAttribute("data-" + b, c), a)
            }, a.getWidth = function(b, c) {
                return C.h.getWidth(a, b, c)
            }, a.getHeight = function(b, c) {
                return C.h.getHeight(a, b, c)
            }, a.getOffset = function() {
                return C.h.getOffset(a)
            }, a
        }, C.calcSlides = function(a) {
            var c = C.slides ? C.slides.length: !1;
            C.slides = [], C.displaySlides = [];
            for (var d = 0; d < C.wrapper.childNodes.length; d++)
                if (C.wrapper.childNodes[d].className)
                    for (var e = C.wrapper.childNodes[d].className, f = e.split(/\s+/), i = 0; i < f.length; i++)
                        f[i] === b.slideClass && C.slides.push(C.wrapper.childNodes[d]);
            for (d = C.slides.length - 1; d >= 0; d--)
                C._extendSwiperSlide(C.slides[d]);
            c!==!1 && (c !== C.slides.length || a) && (h(), g(), C.updateActiveSlide(), C.params.pagination && C.createPagination(), C.callPlugins("numberOfSlidesChanged"))
        }, C.createSlide = function(a, c, d) {
            c = c || C.params.slideClass, d = d || b.slideElement;
            var e = document.createElement(d);
            return e.innerHTML = a || "", e.className = c, C._extendSwiperSlide(e)
        }, C.appendSlide = function(a, b, c) {
            return a ? a.nodeType ? C._extendSwiperSlide(a).append() : C.createSlide(a, b, c).append() : void 0
        }, C.prependSlide = function(a, b, c) {
            return a ? a.nodeType ? C._extendSwiperSlide(a).prepend() : C.createSlide(a, b, c).prepend() : void 0
        }, C.insertSlideAfter = function(a, b, c, d) {
            return "undefined" == typeof a?!1 : b.nodeType ? C._extendSwiperSlide(b).insertAfter(a) : C.createSlide(b, c, d).insertAfter(a)
        }, C.removeSlide = function(a) {
            if (C.slides[a]) {
                if (b.loop) {
                    if (!C.slides[a + C.loopedSlides])
                        return !1;
                    C.slides[a + C.loopedSlides].remove(), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()
                } else 
                    C.slides[a].remove();
                return !0
            }
            return !1
        }, C.removeLastSlide = function() {
            return C.slides.length > 0 ? (b.loop ? (C.slides[C.slides.length - 1 - C.loopedSlides].remove(), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : C.slides[C.slides.length - 1].remove(), !0) : !1
        }, C.removeAllSlides = function() {
            for (var a = C.slides.length - 1; a >= 0; a--)
                C.slides[a].remove()
        }, C.getSlide = function(a) {
            return C.slides[a]
        }, C.getLastSlide = function() {
            return C.slides[C.slides.length - 1]
        }, C.getFirstSlide = function() {
            return C.slides[0]
        }, C.activeSlide = function() {
            return C.slides[C.activeIndex]
        }, C.fireCallback = function() {
            var a = arguments[0];
            if ("[object Array]" === Object.prototype.toString.call(a))
                for (var c = 0; c < a.length; c++)
                    "function" == typeof a[c] && a[c](arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
            else 
                "[object String]" === Object.prototype.toString.call(a) ? b["on" + a] && C.fireCallback(b["on" + a], arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]) : a(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5])
        }, C.addCallback = function(a, b) {
            var c, e = this;
            return e.params["on" + a] ? d(this.params["on" + a]) ? this.params["on" + a].push(b) : "function" == typeof this.params["on" + a] ? (c = this.params["on" + a], this.params["on" + a] = [], this.params["on" + a].push(c), this.params["on" + a].push(b)) : void 0 : (this.params["on" + a] = [], this.params["on" + a].push(b))
        }, C.removeCallbacks = function(a) {
            C.params["on" + a] && (C.params["on" + a] = null)
        };
        var R = [];
        for (var S in C.plugins)
            if (b[S]) {
                var T = C.plugins[S](C, b[S]);
                T && R.push(T)
            }
        C.callPlugins = function(a, b) {
            b || (b = {});
            for (var c = 0; c < R.length; c++)
                a in R[c] && R[c][a](b)
        }, !C.browser.ie10&&!C.browser.ie11 || b.onlyExternal || C.wrapper.classList.add("swiper-wp8-" + (M ? "horizontal" : "vertical")), b.freeMode && (C.container.className += " swiper-free-mode"), C.initialized=!1, C.init = function(a, c) {
            var d = C.h.getWidth(C.container, !1, b.roundLengths), e = C.h.getHeight(C.container, !1, b.roundLengths);
            if (d !== C.width || e !== C.height || a) {
                C.width = d, C.height = e;
                var f, g, h, i, j, k, l;
                I = M ? d : e;
                var m = C.wrapper;
                if (a && C.calcSlides(c), "auto" === b.slidesPerView) {
                    var n = 0, o = 0;
                    b.slidesOffset > 0 && (m.style.paddingLeft = "", m.style.paddingRight = "", m.style.paddingTop = "", m.style.paddingBottom = ""), m.style.width = "", m.style.height = "", b.offsetPxBefore > 0 && (M ? C.wrapperLeft = b.offsetPxBefore : C.wrapperTop = b.offsetPxBefore), b.offsetPxAfter > 0 && (M ? C.wrapperRight = b.offsetPxAfter : C.wrapperBottom = b.offsetPxAfter), b.centeredSlides && (M ? (C.wrapperLeft = (I - this.slides[0].getWidth(!0, b.roundLengths)) / 2, C.wrapperRight = (I - C.slides[C.slides.length - 1].getWidth(!0, b.roundLengths)) / 2) : (C.wrapperTop = (I - C.slides[0].getHeight(!0, b.roundLengths)) / 2, C.wrapperBottom = (I - C.slides[C.slides.length - 1].getHeight(!0, b.roundLengths)) / 2)), M ? (C.wrapperLeft >= 0 && (m.style.paddingLeft = C.wrapperLeft + "px"), C.wrapperRight >= 0 && (m.style.paddingRight = C.wrapperRight + "px")) : (C.wrapperTop >= 0 && (m.style.paddingTop = C.wrapperTop + "px"), C.wrapperBottom >= 0 && (m.style.paddingBottom = C.wrapperBottom + "px")), k = 0;
                    var p = 0;
                    for (C.snapGrid = [], C.slidesGrid = [], h = 0, l = 0; l < C.slides.length; l++) {
                        f = C.slides[l].getWidth(!0, b.roundLengths), g = C.slides[l].getHeight(!0, b.roundLengths), b.calculateHeight && (h = Math.max(h, g));
                        var q = M ? f: g;
                        if (b.centeredSlides) {
                            var r = l === C.slides.length - 1 ? 0: C.slides[l + 1].getWidth(!0, b.roundLengths), s = l === C.slides.length - 1 ? 0: C.slides[l + 1].getHeight(!0, b.roundLengths), t = M ? r: s;
                            if (q > I) {
                                if (b.slidesPerViewFit)
                                    C.snapGrid.push(k + C.wrapperLeft), C.snapGrid.push(k + q - I + C.wrapperLeft);
                                else 
                                    for (var u = 0; u <= Math.floor(q / (I + C.wrapperLeft)); u++)
                                        C.snapGrid.push(0 === u ? k + C.wrapperLeft : k + C.wrapperLeft + I * u);
                                C.slidesGrid.push(k + C.wrapperLeft)
                            } else 
                                C.snapGrid.push(p), C.slidesGrid.push(p);
                            p += q / 2 + t / 2
                        } else {
                            if (q > I)
                                if (b.slidesPerViewFit)
                                    C.snapGrid.push(k), C.snapGrid.push(k + q - I);
                                else if (0 !== I)
                                    for (var v = 0; v <= Math.floor(q / I); v++)
                                        C.snapGrid.push(k + I * v);
                                else 
                                    C.snapGrid.push(k);
                            else 
                                C.snapGrid.push(k);
                            C.slidesGrid.push(k)
                        }
                        k += q, n += f, o += g
                    }
                    b.calculateHeight && (C.height = h), M ? (F = n + C.wrapperRight + C.wrapperLeft, m.style.width = n + "px", m.style.height = C.height + "px") : (F = o + C.wrapperTop + C.wrapperBottom, m.style.width = C.width + "px", m.style.height = o + "px")
                } else if (b.scrollContainer)
                    m.style.width = "", m.style.height = "", i = C.slides[0].getWidth(!0, b.roundLengths), j = C.slides[0].getHeight(!0, b.roundLengths), F = M ? i : j, m.style.width = i + "px", m.style.height = j + "px", E = M ? i : j;
                else {
                    if (b.calculateHeight) {
                        for (h = 0, j = 0, M || (C.container.style.height = ""), m.style.height = "", l = 0; l < C.slides.length; l++)
                            C.slides[l].style.height = "", h = Math.max(C.slides[l].getHeight(!0), h), M || (j += C.slides[l].getHeight(!0));
                        g = h, C.height = g, M ? j = g : (I = g, C.container.style.height = I + "px")
                    } else 
                        g = M ? C.height : C.height / b.slidesPerView, b.roundLengths && (g = Math.ceil(g)), j = M ? C.height : C.slides.length * g;
                    for (f = M ? C.width / b.slidesPerView : C.width, b.roundLengths && (f = Math.ceil(f)), i = M ? C.slides.length * f : C.width, E = M ? f : g, b.offsetSlidesBefore > 0 && (M ? C.wrapperLeft = E * b.offsetSlidesBefore : C.wrapperTop = E * b.offsetSlidesBefore), b.offsetSlidesAfter > 0 && (M ? C.wrapperRight = E * b.offsetSlidesAfter : C.wrapperBottom = E * b.offsetSlidesAfter), b.offsetPxBefore > 0 && (M ? C.wrapperLeft = b.offsetPxBefore : C.wrapperTop = b.offsetPxBefore), b.offsetPxAfter > 0 && (M ? C.wrapperRight = b.offsetPxAfter : C.wrapperBottom = b.offsetPxAfter), b.centeredSlides && (M ? (C.wrapperLeft = (I - E) / 2, C.wrapperRight = (I - E) / 2) : (C.wrapperTop = (I - E) / 2, C.wrapperBottom = (I - E) / 2)), M ? (C.wrapperLeft > 0 && (m.style.paddingLeft = C.wrapperLeft + "px"), C.wrapperRight > 0 && (m.style.paddingRight = C.wrapperRight + "px")) : (C.wrapperTop > 0 && (m.style.paddingTop = C.wrapperTop + "px"), C.wrapperBottom > 0 && (m.style.paddingBottom = C.wrapperBottom + "px")), F = M ? i + C.wrapperRight + C.wrapperLeft : j + C.wrapperTop + C.wrapperBottom, parseFloat(i) > 0 && (!b.cssWidthAndHeight || "height" === b.cssWidthAndHeight) && (m.style.width = i + "px"), parseFloat(j) > 0 && (!b.cssWidthAndHeight || "width" === b.cssWidthAndHeight) && (m.style.height = j + "px"), k = 0, C.snapGrid = [], C.slidesGrid = [], l = 0; l < C.slides.length; l++)
                        C.snapGrid.push(k), C.slidesGrid.push(k), k += E, parseFloat(f) > 0 && (!b.cssWidthAndHeight || "height" === b.cssWidthAndHeight) && (C.slides[l].style.width = f + "px"), parseFloat(g) > 0 && (!b.cssWidthAndHeight || "width" === b.cssWidthAndHeight) && (C.slides[l].style.height = g + "px")
                    }
                C.initialized ? (C.callPlugins("onInit"), b.onInit && C.fireCallback(b.onInit, C)) : (C.callPlugins("onFirstInit"), b.onFirstInit && C.fireCallback(b.onFirstInit, C)), C.initialized=!0
            }
        }, C.reInit = function(a) {
            C.init(!0, a)
        }, C.resizeFix = function(a) {
            C.callPlugins("beforeResizeFix"), C.init(b.resizeReInit || a), b.freeMode ? C.getWrapperTranslate()<-e() && (C.setWrapperTransition(0), C.setWrapperTranslate( - e())) : (C.swipeTo(b.loop ? C.activeLoopIndex : C.activeIndex, 0, !1), b.autoplay && (C.support.transitions && "undefined" != typeof _ ? "undefined" != typeof _ && (clearTimeout(_), _ = void 0, C.startAutoplay()) : "undefined" != typeof ab && (clearInterval(ab), ab = void 0, C.startAutoplay()))), C.callPlugins("afterResizeFix")
        }, C.destroy = function() {
            var a = C.h.removeEventListener, c = "wrapper" === b.eventTarget ? C.wrapper: C.container;
            C.browser.ie10 || C.browser.ie11 ? (a(c, C.touchEvents.touchStart, p), a(document, C.touchEvents.touchMove, q), a(document, C.touchEvents.touchEnd, r)) : (C.support.touch && (a(c, "touchstart", p), a(c, "touchmove", q), a(c, "touchend", r)), b.simulateTouch && (a(c, "mousedown", p), a(document, "mousemove", q), a(document, "mouseup", r))), b.autoResize && a(window, "resize", C.resizeFix), h(), b.paginationClickable && w(), b.mousewheelControl && C._wheelEvent && a(C.container, C._wheelEvent, j), b.keyboardControl && a(document, "keydown", i), b.autoplay && C.stopAutoplay(), C.callPlugins("onDestroy"), C = null
        }, C.disableKeyboardControl = function() {
            b.keyboardControl=!1, C.h.removeEventListener(document, "keydown", i)
        }, C.enableKeyboardControl = function() {
            b.keyboardControl=!0, C.h.addEventListener(document, "keydown", i)
        };
        var U = (new Date).getTime();
        if (C.disableMousewheelControl = function() {
            return C._wheelEvent ? (b.mousewheelControl=!1, C.h.removeEventListener(C.container, C._wheelEvent, j), !0) : !1
        }, C.enableMousewheelControl = function() {
            return C._wheelEvent ? (b.mousewheelControl=!0, C.h.addEventListener(C.container, C._wheelEvent, j), !0) : !1
        }, b.grabCursor) {
            var V = C.container.style;
            V.cursor = "move", V.cursor = "grab", V.cursor = "-moz-grab", V.cursor = "-webkit-grab"
        }
        C.allowSlideClick=!0, C.allowLinks=!0;
        var W, X, Y, Z=!1, $=!0;
        C.swipeNext = function(a) {
            !a && b.loop && C.fixLoop(), !a && b.autoplay && C.stopAutoplay(!0), C.callPlugins("onSwipeNext");
            var c = C.getWrapperTranslate(), d = c;
            if ("auto" === b.slidesPerView) {
                for (var f = 0; f < C.snapGrid.length; f++)
                    if ( - c >= C.snapGrid[f]&&-c < C.snapGrid[f + 1]) {
                        d =- C.snapGrid[f + 1];
                        break
                    }
            } else {
                var g = E * b.slidesPerGroup;
                d =- (Math.floor(Math.abs(c) / Math.floor(g)) * g + g)
            }
            return d<-e() && (d =- e()), d === c?!1 : (u(d, "next"), !0)
        }, C.swipePrev = function(a) {
            !a && b.loop && C.fixLoop(), !a && b.autoplay && C.stopAutoplay(!0), C.callPlugins("onSwipePrev");
            var c, d = Math.ceil(C.getWrapperTranslate());
            if ("auto" === b.slidesPerView) {
                c = 0;
                for (var e = 1; e < C.snapGrid.length; e++) {
                    if ( - d === C.snapGrid[e]) {
                        c =- C.snapGrid[e - 1];
                        break
                    }
                    if ( - d > C.snapGrid[e]&&-d < C.snapGrid[e + 1]) {
                        c =- C.snapGrid[e];
                        break
                    }
                }
            } else {
                var f = E * b.slidesPerGroup;
                c =- (Math.ceil( - d / f) - 1) * f
            }
            return c > 0 && (c = 0), c === d?!1 : (u(c, "prev"), !0)
        }, C.swipeReset = function() {
            C.callPlugins("onSwipeReset");
            {
                var a, c = C.getWrapperTranslate(), d = E * b.slidesPerGroup;
                - e()
            }
            if ("auto" === b.slidesPerView) {
                a = 0;
                for (var f = 0; f < C.snapGrid.length; f++) {
                    if ( - c === C.snapGrid[f])
                        return;
                    if ( - c >= C.snapGrid[f]&&-c < C.snapGrid[f + 1]) {
                        a = C.positions.diff > 0?-C.snapGrid[f + 1] : - C.snapGrid[f];
                        break
                    }
                }
                - c >= C.snapGrid[C.snapGrid.length - 1] && (a =- C.snapGrid[C.snapGrid.length - 1]), c<=-e() && (a =- e())
            } else 
                a = 0 > c ? Math.round(c / d) * d : 0, c<=-e() && (a =- e());
            return b.scrollContainer && (a = 0 > c ? c : 0), a<-e() && (a =- e()), b.scrollContainer && I > E && (a = 0), a === c?!1 : (u(a, "reset"), !0)
        }, C.swipeTo = function(a, c, d) {
            a = parseInt(a, 10), C.callPlugins("onSwipeTo", {
                index: a,
                speed: c
            }), b.loop && (a += C.loopedSlides);
            var f = C.getWrapperTranslate();
            if (!(a > C.slides.length - 1 || 0 > a)) {
                var g;
                return g = "auto" === b.slidesPerView?-C.slidesGrid[a] : - a * E, g<-e() && (g =- e()), g === f?!1 : (d = d===!1?!1 : !0, u(g, "to", {
                    index : a, speed : c, runCallbacks : d
                }), !0)
            }
        }, C._queueStartCallbacks=!1, C._queueEndCallbacks=!1, C.updateActiveSlide = function(a) {
            if (C.initialized && 0 !== C.slides.length) {
                C.previousIndex = C.activeIndex, "undefined" == typeof a && (a = C.getWrapperTranslate()), a > 0 && (a = 0);
                var c;
                if ("auto" === b.slidesPerView) {
                    if (C.activeIndex = C.slidesGrid.indexOf( - a), C.activeIndex < 0) {
                        for (c = 0; c < C.slidesGrid.length - 1&&!( - a > C.slidesGrid[c]&&-a < C.slidesGrid[c + 1]); c++);
                        var d = Math.abs(C.slidesGrid[c] + a), e = Math.abs(C.slidesGrid[c + 1] + a);
                        C.activeIndex = e >= d ? c : c + 1
                    }
                } else 
                    C.activeIndex = Math[b.visibilityFullFit ? "ceil": "round"]( - a / E);
                if (C.activeIndex === C.slides.length && (C.activeIndex = C.slides.length - 1), C.activeIndex < 0 && (C.activeIndex = 0), C.slides[C.activeIndex]) {
                    if (C.calcVisibleSlides(a), C.support.classList) {
                        var f;
                        for (c = 0; c < C.slides.length; c++)
                            f = C.slides[c], f.classList.remove(b.slideActiveClass), C.visibleSlides.indexOf(f) >= 0 ? f.classList.add(b.slideVisibleClass) : f.classList.remove(b.slideVisibleClass);
                        C.slides[C.activeIndex].classList.add(b.slideActiveClass)
                    } else {
                        var g = new RegExp("\\s*" + b.slideActiveClass), h = new RegExp("\\s*" + b.slideVisibleClass);
                        for (c = 0; c < C.slides.length; c++)
                            C.slides[c].className = C.slides[c].className.replace(g, "").replace(h, ""), C.visibleSlides.indexOf(C.slides[c]) >= 0 && (C.slides[c].className += " " + b.slideVisibleClass);
                        C.slides[C.activeIndex].className += " " + b.slideActiveClass
                    }
                    if (b.loop) {
                        var i = C.loopedSlides;
                        C.activeLoopIndex = C.activeIndex - i, C.activeLoopIndex >= C.slides.length - 2 * i && (C.activeLoopIndex = C.slides.length - 2 * i - C.activeLoopIndex), C.activeLoopIndex < 0 && (C.activeLoopIndex = C.slides.length - 2 * i + C.activeLoopIndex), C.activeLoopIndex < 0 && (C.activeLoopIndex = 0)
                    } else 
                        C.activeLoopIndex = C.activeIndex;
                    b.pagination && C.updatePagination(a)
                }
            }
        }, C.createPagination = function(a) {
            if (b.paginationClickable && C.paginationButtons && w(), C.paginationContainer = b.pagination.nodeType ? b.pagination : c(b.pagination)[0], b.createPagination) {
                var d = "", e = C.slides.length, f = e;
                b.loop && (f -= 2 * C.loopedSlides);
                for (var g = 0; f > g; g++)
                    d += "<" + b.paginationElement + ' class="' + b.paginationElementClass + '"></' + b.paginationElement + ">";
                C.paginationContainer.innerHTML = d
            }
            C.paginationButtons = c("." + b.paginationElementClass, C.paginationContainer), a || C.updatePagination(), C.callPlugins("onCreatePagination"), b.paginationClickable && x()
        }, C.updatePagination = function(a) {
            if (b.pagination&&!(C.slides.length < 1)) {
                var d = c("." + b.paginationActiveClass, C.paginationContainer);
                if (d) {
                    var e = C.paginationButtons;
                    if (0 !== e.length) {
                        for (var f = 0; f < e.length; f++)
                            e[f].className = b.paginationElementClass;
                        var g = b.loop ? C.loopedSlides: 0;
                        if (b.paginationAsRange) {
                            C.visibleSlides || C.calcVisibleSlides(a);
                            var h, i = [];
                            for (h = 0; h < C.visibleSlides.length; h++) {
                                var j = C.slides.indexOf(C.visibleSlides[h]) - g;
                                b.loop && 0 > j && (j = C.slides.length - 2 * C.loopedSlides + j), b.loop && j >= C.slides.length - 2 * C.loopedSlides && (j = C.slides.length - 2 * C.loopedSlides - j, j = Math.abs(j)), i.push(j)
                            }
                            for (h = 0; h < i.length; h++)
                                e[i[h]] && (e[i[h]].className += " " + b.paginationVisibleClass);
                            b.loop ? void 0 !== e[C.activeLoopIndex] && (e[C.activeLoopIndex].className += " " + b.paginationActiveClass) : e[C.activeIndex].className += " " + b.paginationActiveClass
                        } else 
                            b.loop ? e[C.activeLoopIndex] && (e[C.activeLoopIndex].className += " " + b.paginationActiveClass + " " + b.paginationVisibleClass) : e[C.activeIndex].className += " " + b.paginationActiveClass + " " + b.paginationVisibleClass
                    }
                }
            }
        }, C.calcVisibleSlides = function(a) {
            var c = [], d = 0, e = 0, f = 0;
            M && C.wrapperLeft > 0 && (a += C.wrapperLeft), !M && C.wrapperTop > 0 && (a += C.wrapperTop);
            for (var g = 0; g < C.slides.length; g++) {
                d += e, e = "auto" === b.slidesPerView ? M ? C.h.getWidth(C.slides[g], !0, b.roundLengths) : C.h.getHeight(C.slides[g], !0, b.roundLengths) : E, f = d + e;
                var h=!1;
                b.visibilityFullFit ? (d>=-a&&-a + I >= f && (h=!0), - a >= d && f>=-a + I && (h=!0)) : (f>-a&&-a + I >= f && (h=!0), d>=-a&&-a + I > d && (h=!0), - a > d && f>-a + I && (h=!0)), h && c.push(C.slides[g])
            }
            0 === c.length && (c = [C.slides[C.activeIndex]]), C.visibleSlides = c
        };
        var _, ab;
        C.startAutoplay = function() {
            if (C.support.transitions) {
                if ("undefined" != typeof _)
                    return !1;
                if (!b.autoplay)
                    return;
                C.callPlugins("onAutoplayStart"), b.onAutoplayStart && C.fireCallback(b.onAutoplayStart, C), z()
            } else {
                if ("undefined" != typeof ab)
                    return !1;
                if (!b.autoplay)
                    return;
                C.callPlugins("onAutoplayStart"), b.onAutoplayStart && C.fireCallback(b.onAutoplayStart, C), ab = setInterval(function() {
                    b.loop ? (C.fixLoop(), C.swipeNext(!0)) : C.swipeNext(!0) || (b.autoplayStopOnLast ? (clearInterval(ab), ab = void 0) : C.swipeTo(0))
                }, b.autoplay)
            }
        }, C.stopAutoplay = function(a) {
            if (C.support.transitions) {
                if (!_)
                    return;
                _ && clearTimeout(_), _ = void 0, a&&!b.autoplayDisableOnInteraction && C.wrapperTransitionEnd(function() {
                    z()
                }), C.callPlugins("onAutoplayStop"), b.onAutoplayStop && C.fireCallback(b.onAutoplayStop, C)
            } else 
                ab && clearInterval(ab), ab = void 0, C.callPlugins("onAutoplayStop"), b.onAutoplayStop && C.fireCallback(b.onAutoplayStop, C)
        }, C.loopCreated=!1, C.removeLoopedSlides = function() {
            if (C.loopCreated)
                for (var a = 0; a < C.slides.length; a++)
                    C.slides[a].getData("looped")===!0 && C.wrapper.removeChild(C.slides[a])
        }, C.createLoop = function() {
            if (0 !== C.slides.length) {
                C.loopedSlides = "auto" === b.slidesPerView ? b.loopedSlides || 1 : b.slidesPerView + b.loopAdditionalSlides, C.loopedSlides > C.slides.length && (C.loopedSlides = C.slides.length);
                var a, c = "", d = "", e = "", f = C.slides.length, g = Math.floor(C.loopedSlides / f), h = C.loopedSlides%f;
                for (a = 0; g * f > a; a++) {
                    var i = a;
                    if (a >= f) {
                        var j = Math.floor(a / f);
                        i = a - f * j
                    }
                    e += C.slides[i].outerHTML
                }
                for (a = 0; h > a; a++)
                    d += t(b.slideDuplicateClass, C.slides[a].outerHTML);
                for (a = f - h; f > a; a++)
                    c += t(b.slideDuplicateClass, C.slides[a].outerHTML);
                var k = c + e + D.innerHTML + e + d;
                for (D.innerHTML = k, C.loopCreated=!0, C.calcSlides(), a = 0; a < C.slides.length; a++)(a < C.loopedSlides || a >= C.slides.length - C.loopedSlides) 
                    && C.slides[a].setData("looped", !0);
                C.callPlugins("onCreateLoop")
            }
        }, C.fixLoop = function() {
            var a;
            C.activeIndex < C.loopedSlides ? (a = C.slides.length - 3 * C.loopedSlides + C.activeIndex, C.swipeTo(a, 0, !1)) : ("auto" === b.slidesPerView && C.activeIndex >= 2 * C.loopedSlides || C.activeIndex > C.slides.length - 2 * b.slidesPerView) && (a =- C.slides.length + C.activeIndex + C.loopedSlides, C.swipeTo(a, 0, !1))
        }, C.loadSlides = function() {
            var a = "";
            C.activeLoaderIndex = 0;
            for (var c = b.loader.slides, d = b.loader.loadAllSlides ? c.length : b.slidesPerView * (1 + b.loader.surroundGroups), e = 0; d > e; e++)
                a += "outer" === b.loader.slidesHTMLType ? c[e] : "<" + b.slideElement + ' class="' + b.slideClass + '" data-swiperindex="' + e + '">' + c[e] + "</" + b.slideElement + ">";
            C.wrapper.innerHTML = a, C.calcSlides(!0), b.loader.loadAllSlides || C.wrapperTransitionEnd(C.reloadSlides, !0)
        }, C.reloadSlides = function() {
            var a = b.loader.slides, c = parseInt(C.activeSlide().data("swiperindex"), 10);
            if (!(0 > c || c > a.length - 1)) {
                C.activeLoaderIndex = c;
                var d = Math.max(0, c - b.slidesPerView * b.loader.surroundGroups), e = Math.min(c + b.slidesPerView * (1 + b.loader.surroundGroups) - 1, a.length - 1);
                if (c > 0) {
                    var f =- E * (c - d);
                    C.setWrapperTranslate(f), C.setWrapperTransition(0)
                }
                var g;
                if ("reload" === b.loader.logic) {
                    C.wrapper.innerHTML = "";
                    var h = "";
                    for (g = d; e >= g; g++)
                        h += "outer" === b.loader.slidesHTMLType ? a[g] : "<" + b.slideElement + ' class="' + b.slideClass + '" data-swiperindex="' + g + '">' + a[g] + "</" + b.slideElement + ">";
                    C.wrapper.innerHTML = h
                } else {
                    var i = 1e3, j = 0;
                    for (g = 0; g < C.slides.length; g++) {
                        var k = C.slides[g].data("swiperindex");
                        d > k || k > e ? C.wrapper.removeChild(C.slides[g]) : (i = Math.min(k, i), j = Math.max(k, j))
                    }
                    for (g = d; e >= g; g++) {
                        var l;
                        i > g && (l = document.createElement(b.slideElement), l.className = b.slideClass, l.setAttribute("data-swiperindex", g), l.innerHTML = a[g], C.wrapper.insertBefore(l, C.wrapper.firstChild)), g > j && (l = document.createElement(b.slideElement), l.className = b.slideClass, l.setAttribute("data-swiperindex", g), l.innerHTML = a[g], C.wrapper.appendChild(l))
                    }
                }
                C.reInit(!0)
            }
        }, A()
    }
};
Swiper.prototype = {
    plugins: {},
    wrapperTransitionEnd: function(a, b) {
        "use strict";
        function c(h) {
            if (h.target === f && (a(e), e.params.queueEndCallbacks && (e._queueEndCallbacks=!1), !b))
                for (d = 0; d < g.length; d++)
                    e.h.removeEventListener(f, g[d], c)
        }
        var d, e = this, f = e.wrapper, g = ["webkitTransitionEnd", "transitionend", "oTransitionEnd", "MSTransitionEnd", "msTransitionEnd"];
        if (a)
            for (d = 0; d < g.length; d++)
                e.h.addEventListener(f, g[d], c)
    },
    getWrapperTranslate: function(a) {
        "use strict";
        var b, c, d, e, f = this.wrapper;
        return "undefined" == typeof a && (a = "horizontal" === this.params.mode ? "x" : "y"), this.support.transforms && this.params.useCSS3Transforms ? (d = window.getComputedStyle(f, null), window.WebKitCSSMatrix ? e = new WebKitCSSMatrix("none" === d.webkitTransform ? "" : d.webkitTransform) : (e = d.MozTransform || d.OTransform || d.MsTransform || d.msTransform || d.transform || d.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), b = e.toString().split(",")), "x" === a && (c = window.WebKitCSSMatrix ? e.m41 : parseFloat(16 === b.length ? b[12] : b[4])), "y" === a && (c = window.WebKitCSSMatrix ? e.m42 : parseFloat(16 === b.length ? b[13] : b[5]))) : ("x" === a && (c = parseFloat(f.style.left, 10) || 0), "y" === a && (c = parseFloat(f.style.top, 10) || 0)), c || 0
    },
    setWrapperTranslate: function(a, b, c) {
        "use strict";
        var d, e = this.wrapper.style, f = {
            x: 0,
            y: 0,
            z: 0
        };
        3 === arguments.length ? (f.x = a, f.y = b, f.z = c) : ("undefined" == typeof b && (b = "horizontal" === this.params.mode ? "x" : "y"), f[b] = a), this.support.transforms && this.params.useCSS3Transforms ? (d = this.support.transforms3d ? "translate3d(" + f.x + "px, " + f.y + "px, " + f.z + "px)" : "translate(" + f.x + "px, " + f.y + "px)", e.webkitTransform = e.MsTransform = e.msTransform = e.MozTransform = e.OTransform = e.transform = d) : (e.left = f.x + "px", e.top = f.y + "px"), this.callPlugins("onSetWrapperTransform", f), this.params.onSetWrapperTransform && this.fireCallback(this.params.onSetWrapperTransform, this, f)
    },
    setWrapperTransition: function(a) {
        "use strict";
        var b = this.wrapper.style;
        b.webkitTransitionDuration = b.MsTransitionDuration = b.msTransitionDuration = b.MozTransitionDuration = b.OTransitionDuration = b.transitionDuration = a / 1e3 + "s", this.callPlugins("onSetWrapperTransition", {
            duration: a
        }), this.params.onSetWrapperTransition && this.fireCallback(this.params.onSetWrapperTransition, this, a)
    },
    h: {
        getWidth: function(a, b, c) {
            "use strict";
            var d = window.getComputedStyle(a, null).getPropertyValue("width"), e = parseFloat(d);
            return (isNaN(e) || d.indexOf("%") > 0 || 0 > e) && (e = a.offsetWidth - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-left")) - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-right"))), b && (e += parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-left")) + parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-right"))), c ? Math.ceil(e) : e
        },
        getHeight: function(a, b, c) {
            "use strict";
            if (b)
                return a.offsetHeight;
            var d = window.getComputedStyle(a, null).getPropertyValue("height"), e = parseFloat(d);
            return (isNaN(e) || d.indexOf("%") > 0 || 0 > e) && (e = a.offsetHeight - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-top")) - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-bottom"))), b && (e += parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-top")) + parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-bottom"))), c ? Math.ceil(e) : e
        },
        getOffset: function(a) {
            "use strict";
            var b = a.getBoundingClientRect(), c = document.body, d = a.clientTop || c.clientTop || 0, e = a.clientLeft || c.clientLeft || 0, f = window.pageYOffset || a.scrollTop, g = window.pageXOffset || a.scrollLeft;
            return document.documentElement&&!window.pageYOffset && (f = document.documentElement.scrollTop, g = document.documentElement.scrollLeft), {
                top: b.top + f - d,
                left: b.left + g - e
            }
        },
        windowWidth: function() {
            "use strict";
            return window.innerWidth ? window.innerWidth : document.documentElement && document.documentElement.clientWidth ? document.documentElement.clientWidth : void 0
        },
        windowHeight: function() {
            "use strict";
            return window.innerHeight ? window.innerHeight : document.documentElement && document.documentElement.clientHeight ? document.documentElement.clientHeight : void 0
        },
        windowScroll: function() {
            "use strict";
            return "undefined" != typeof pageYOffset ? {
                left: window.pageXOffset,
                top: window.pageYOffset
            } : document.documentElement ? {
                left: document.documentElement.scrollLeft,
                top: document.documentElement.scrollTop
            } : void 0
        },
        addEventListener: function(a, b, c, d) {
            "use strict";
            "undefined" == typeof d && (d=!1), a.addEventListener ? a.addEventListener(b, c, d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        removeEventListener: function(a, b, c, d) {
            "use strict";
            "undefined" == typeof d && (d=!1), a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent && a.detachEvent("on" + b, c)
        }
    },
    setTransform: function(a, b) {
        "use strict";
        var c = a.style;
        c.webkitTransform = c.MsTransform = c.msTransform = c.MozTransform = c.OTransform = c.transform = b
    },
    setTranslate: function(a, b) {
        "use strict";
        var c = a.style, d = {
            x: b.x || 0,
            y: b.y || 0,
            z: b.z || 0
        }, e = this.support.transforms3d ? "translate3d(" + d.x + "px," + d.y + "px," + d.z + "px)": "translate(" + d.x + "px," + d.y + "px)";
        c.webkitTransform = c.MsTransform = c.msTransform = c.MozTransform = c.OTransform = c.transform = e, this.support.transforms || (c.left = d.x + "px", c.top = d.y + "px")
    },
    setTransition: function(a, b) {
        "use strict";
        var c = a.style;
        c.webkitTransitionDuration = c.MsTransitionDuration = c.msTransitionDuration = c.MozTransitionDuration = c.OTransitionDuration = c.transitionDuration = b + "ms"
    },
    support: {
        touch: window.Modernizr && Modernizr.touch===!0 || function() {
            "use strict";
            return !!("ontouchstart"in window || window.DocumentTouch && document instanceof DocumentTouch)
        }(),
        transforms3d: window.Modernizr && Modernizr.csstransforms3d===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "webkitPerspective"in a || "MozPerspective"in a || "OPerspective"in a || "MsPerspective"in a || "perspective"in a
        }(),
        transforms: window.Modernizr && Modernizr.csstransforms===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "transform"in a || "WebkitTransform"in a || "MozTransform"in a || "msTransform"in a || "MsTransform"in a || "OTransform"in a
        }(),
        transitions: window.Modernizr && Modernizr.csstransitions===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "transition"in a || "WebkitTransition"in a || "MozTransition"in a || "msTransition"in a || "MsTransition"in a || "OTransition"in a
        }(),
        classList: function() {
            "use strict";
            var a = document.createElement("div");
            return "classList"in a
        }()
    },
    browser: {
        ie8: function() {
            "use strict";
            var a =- 1;
            if ("Microsoft Internet Explorer" === navigator.appName) {
                var b = navigator.userAgent, c = new RegExp(/MSIE ([0-9]{1,}[\.0-9]{0,})/);
                null !== c.exec(b) && (a = parseFloat(RegExp.$1))
            }
            return - 1 !== a && 9 > a
        }(),
        ie10: window.navigator.msPointerEnabled,
        ie11: window.navigator.pointerEnabled
    }
}, (window.jQuery || window.Zepto)&&!function(a) {
    "use strict";
    a.fn.swiper = function(b) {
        var c;
        return this.each(function(d) {
            var e = a(this);
            if (!e.data("swiper")) {
                var f = new Swiper(e[0], b);
                d || (c = f), e.data("swiper", f)
            }
        }), c
    }
}(window.jQuery || window.Zepto), "undefined" != typeof module && (module.exports = Swiper), "function" == typeof define && define.amd && define([], function() {
    "use strict";
    return Swiper
});;
(function() {
    function n(n) {
        function t(t, r, e, u, i, o) {
            for (; i >= 0 && o > i; i += n) {
                var a = u ? u[i]: i;
                e = r(e, t[a], a, t)
            }
            return e
        }
        return function(r, e, u, i) {
            e = b(e, i, 4);
            var o=!k(r) && m.keys(r), a = (o || r).length, c = n > 0 ? 0 : a - 1;
            return arguments.length < 3 && (u = r[o ? o[c]: c], c += n), t(r, e, u, o, c, a)
        }
    }
    function t(n) {
        return function(t, r, e) {
            r = x(r, e);
            for (var u = O(t), i = n > 0 ? 0 : u - 1; i >= 0 && u > i; i += n)
                if (r(t[i], i, t))
                    return i;
            return - 1
        }
    }
    function r(n, t, r) {
        return function(e, u, i) {
            var o = 0, a = O(e);
            if ("number" == typeof i)
                n > 0 ? o = i >= 0 ? i : Math.max(i + a, o) : a = i >= 0 ? Math.min(i + 1, a) : i + a + 1;
            else if (r && i && a)
                return i = r(e, u), e[i] === u ? i : - 1;
            if (u !== u)
                return i = t(l.call(e, o, a), m.isNaN), i >= 0 ? i + o : - 1;
            for (i = n > 0 ? o : a - 1; i >= 0 && a > i; i += n)
                if (e[i] === u)
                    return i;
            return - 1
        }
    }
    function e(n, t) {
        var r = I.length, e = n.constructor, u = m.isFunction(e) && e.prototype || a, i = "constructor";
        for (m.has(n, i)&&!m.contains(t, i) && t.push(i); r--;)
            i = I[r], i in n && n[i] !== u[i]&&!m.contains(t, i) && t.push(i)
    }
    var u = this, i = u._, o = Array.prototype, a = Object.prototype, c = Function.prototype, f = o.push, l = o.slice, s = a.toString, p = a.hasOwnProperty, h = Array.isArray, v = Object.keys, g = c.bind, y = Object.create, d = function() {}, m = function(n) {
        return n instanceof m ? n : this instanceof m ? void(this._wrapped = n) : new m(n)
    };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = m), exports._ = m) : u._ = m, m.VERSION = "1.8.3";
    var b = function(n, t, r) {
        if (t === void 0)
            return n;
        switch (null == r ? 3 : r) {
        case 1:
            return function(r) {
                return n.call(t, r)
            };
        case 2:
            return function(r, e) {
                return n.call(t, r, e)
            };
        case 3:
            return function(r, e, u) {
                return n.call(t, r, e, u)
            };
        case 4:
            return function(r, e, u, i) {
                return n.call(t, r, e, u, i)
            }
        }
        return function() {
            return n.apply(t, arguments)
        }
    }, x = function(n, t, r) {
        return null == n ? m.identity : m.isFunction(n) ? b(n, t, r) : m.isObject(n) ? m.matcher(n) : m.property(n)
    };
    m.iteratee = function(n, t) {
        return x(n, t, 1 / 0)
    };
    var _ = function(n, t) {
        return function(r) {
            var e = arguments.length;
            if (2 > e || null == r)
                return r;
            for (var u = 1; e > u; u++)
                for (var i = arguments[u], o = n(i), a = o.length, c = 0; a > c; c++) {
                    var f = o[c];
                    t && r[f] !== void 0 || (r[f] = i[f])
                }
            return r
        }
    }, j = function(n) {
        if (!m.isObject(n))
            return {};
        if (y)
            return y(n);
        d.prototype = n;
        var t = new d;
        return d.prototype = null, t
    }, w = function(n) {
        return function(t) {
            return null == t ? void 0 : t[n]
        }
    }, A = Math.pow(2, 53) - 1, O = w("length"), k = function(n) {
        var t = O(n);
        return "number" == typeof t && t >= 0 && A >= t
    };
    m.each = m.forEach = function(n, t, r) {
        t = b(t, r);
        var e, u;
        if (k(n))
            for (e = 0, u = n.length; u > e; e++)
                t(n[e], e, n);
        else {
            var i = m.keys(n);
            for (e = 0, u = i.length; u > e; e++)
                t(n[i[e]], i[e], n)
        }
        return n
    }, m.map = m.collect = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = Array(u), o = 0; u > o; o++) {
            var a = e ? e[o]: o;
            i[o] = t(n[a], a, n)
        }
        return i
    }, m.reduce = m.foldl = m.inject = n(1), m.reduceRight = m.foldr = n( - 1), m.find = m.detect = function(n, t, r) {
        var e;
        return e = k(n) ? m.findIndex(n, t, r) : m.findKey(n, t, r), e !== void 0 && e!==-1 ? n[e] : void 0
    }, m.filter = m.select = function(n, t, r) {
        var e = [];
        return t = x(t, r), m.each(n, function(n, r, u) {
            t(n, r, u) && e.push(n)
        }), e
    }, m.reject = function(n, t, r) {
        return m.filter(n, m.negate(x(t)), r)
    }, m.every = m.all = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i]: i;
            if (!t(n[o], o, n))
                return !1
        }
        return !0
    }, m.some = m.any = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i]: i;
            if (t(n[o], o, n))
                return !0
        }
        return !1
    }, m.contains = m.includes = m.include = function(n, t, r, e) {
        return k(n) || (n = m.values(n)), ("number" != typeof r || e) && (r = 0), m.indexOf(n, t, r) >= 0
    }, m.invoke = function(n, t) {
        var r = l.call(arguments, 2), e = m.isFunction(t);
        return m.map(n, function(n) {
            var u = e ? t: n[t];
            return null == u ? u : u.apply(n, r)
        })
    }, m.pluck = function(n, t) {
        return m.map(n, m.property(t))
    }, m.where = function(n, t) {
        return m.filter(n, m.matcher(t))
    }, m.findWhere = function(n, t) {
        return m.find(n, m.matcher(t))
    }, m.max = function(n, t, r) {
        var e, u, i =- 1 / 0, o =- 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++)
                e = n[a], e > i && (i = e)
        } else 
            t = x(t, r), m.each(n, function(n, r, e) {
                u = t(n, r, e), (u > o || u===-1 / 0 && i===-1 / 0) && (i = n, o = u)
            });
        return i
    }, m.min = function(n, t, r) {
        var e, u, i = 1 / 0, o = 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++)
                e = n[a], i > e && (i = e)
        } else 
            t = x(t, r), m.each(n, function(n, r, e) {
                u = t(n, r, e), (o > u || 1 / 0 === u && 1 / 0 === i) && (i = n, o = u)
            });
        return i
    }, m.shuffle = function(n) {
        for (var t, r = k(n) ? n : m.values(n), e = r.length, u = Array(e), i = 0; e > i; i++)
            t = m.random(0, i), t !== i && (u[i] = u[t]), u[t] = r[i];
        return u
    }, m.sample = function(n, t, r) {
        return null == t || r ? (k(n) || (n = m.values(n)), n[m.random(n.length - 1)]) : m.shuffle(n).slice(0, Math.max(0, t))
    }, m.sortBy = function(n, t, r) {
        return t = x(t, r), m.pluck(m.map(n, function(n, r, e) {
            return {
                value: n,
                index: r,
                criteria: t(n, r, e)
            }
        }).sort(function(n, t) {
            var r = n.criteria, e = t.criteria;
            if (r !== e) {
                if (r > e || r === void 0)
                    return 1;
                if (e > r || e === void 0)
                    return - 1
            }
            return n.index - t.index
        }), "value")
    };
    var F = function(n) {
        return function(t, r, e) {
            var u = {};
            return r = x(r, e), m.each(t, function(e, i) {
                var o = r(e, i, t);
                n(u, e, o)
            }), u
        }
    };
    m.groupBy = F(function(n, t, r) {
        m.has(n, r) ? n[r].push(t) : n[r] = [t]
    }), m.indexBy = F(function(n, t, r) {
        n[r] = t
    }), m.countBy = F(function(n, t, r) {
        m.has(n, r) ? n[r]++ : n[r] = 1
    }), m.toArray = function(n) {
        return n ? m.isArray(n) ? l.call(n) : k(n) ? m.map(n, m.identity) : m.values(n) : []
    }, m.size = function(n) {
        return null == n ? 0 : k(n) ? n.length : m.keys(n).length
    }, m.partition = function(n, t, r) {
        t = x(t, r);
        var e = [], u = [];
        return m.each(n, function(n, r, i) {
            (t(n, r, i) ? e : u).push(n)
        }), [e, u]
    }, m.first = m.head = m.take = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[0] : m.initial(n, n.length - t)
    }, m.initial = function(n, t, r) {
        return l.call(n, 0, Math.max(0, n.length - (null == t || r ? 1 : t)))
    }, m.last = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[n.length - 1] : m.rest(n, Math.max(0, n.length - t))
    }, m.rest = m.tail = m.drop = function(n, t, r) {
        return l.call(n, null == t || r ? 1 : t)
    }, m.compact = function(n) {
        return m.filter(n, m.identity)
    };
    var S = function(n, t, r, e) {
        for (var u = [], i = 0, o = e || 0, a = O(n); a > o; o++) {
            var c = n[o];
            if (k(c) && (m.isArray(c) || m.isArguments(c))) {
                t || (c = S(c, t, r));
                var f = 0, l = c.length;
                for (u.length += l; l > f;)
                    u[i++] = c[f++]
            } else 
                r || (u[i++] = c)
        }
        return u
    };
    m.flatten = function(n, t) {
        return S(n, t, !1)
    }, m.without = function(n) {
        return m.difference(n, l.call(arguments, 1))
    }, m.uniq = m.unique = function(n, t, r, e) {
        m.isBoolean(t) || (e = r, r = t, t=!1), null != r && (r = x(r, e));
        for (var u = [], i = [], o = 0, a = O(n); a > o; o++) {
            var c = n[o], f = r ? r(c, o, n): c;
            t ? (o && i === f || u.push(c), i = f) : r ? m.contains(i, f) || (i.push(f), u.push(c)) : m.contains(u, c) || u.push(c)
        }
        return u
    }, m.union = function() {
        return m.uniq(S(arguments, !0, !0))
    }, m.intersection = function(n) {
        for (var t = [], r = arguments.length, e = 0, u = O(n); u > e; e++) {
            var i = n[e];
            if (!m.contains(t, i)) {
                for (var o = 1; r > o && m.contains(arguments[o], i); o++);
                o === r && t.push(i)
            }
        }
        return t
    }, m.difference = function(n) {
        var t = S(arguments, !0, !0, 1);
        return m.filter(n, function(n) {
            return !m.contains(t, n)
        })
    }, m.zip = function() {
        return m.unzip(arguments)
    }, m.unzip = function(n) {
        for (var t = n && m.max(n, O).length || 0, r = Array(t), e = 0; t > e; e++)
            r[e] = m.pluck(n, e);
        return r
    }, m.object = function(n, t) {
        for (var r = {}, e = 0, u = O(n); u > e; e++)
            t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r
    }, m.findIndex = t(1), m.findLastIndex = t( - 1), m.sortedIndex = function(n, t, r, e) {
        r = x(r, e, 1);
        for (var u = r(t), i = 0, o = O(n); o > i;) {
            var a = Math.floor((i + o) / 2);
            r(n[a]) < u ? i = a + 1 : o = a
        }
        return i
    }, m.indexOf = r(1, m.findIndex, m.sortedIndex), m.lastIndexOf = r( - 1, m.findLastIndex), m.range = function(n, t, r) {
        null == t && (t = n || 0, n = 0), r = r || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = Array(e), i = 0; e > i; i++, n += r)
            u[i] = n;
        return u
    };
    var E = function(n, t, r, e, u) {
        if (!(e instanceof t))
            return n.apply(r, u);
        var i = j(n.prototype), o = n.apply(i, u);
        return m.isObject(o) ? o : i
    };
    m.bind = function(n, t) {
        if (g && n.bind === g)
            return g.apply(n, l.call(arguments, 1));
        if (!m.isFunction(n))
            throw new TypeError("Bind must be called on a function");
        var r = l.call(arguments, 2), e = function() {
            return E(n, e, t, this, r.concat(l.call(arguments)))
        };
        return e
    }, m.partial = function(n) {
        var t = l.call(arguments, 1), r = function() {
            for (var e = 0, u = t.length, i = Array(u), o = 0; u > o; o++)
                i[o] = t[o] === m ? arguments[e++] : t[o];
            for (; e < arguments.length;)
                i.push(arguments[e++]);
            return E(n, r, this, this, i)
        };
        return r
    }, m.bindAll = function(n) {
        var t, r, e = arguments.length;
        if (1 >= e)
            throw new Error("bindAll must be passed function names");
        for (t = 1; e > t; t++)
            r = arguments[t], n[r] = m.bind(n[r], n);
        return n
    }, m.memoize = function(n, t) {
        var r = function(e) {
            var u = r.cache, i = "" + (t ? t.apply(this, arguments) : e);
            return m.has(u, i) || (u[i] = n.apply(this, arguments)), u[i]
        };
        return r.cache = {}, r
    }, m.delay = function(n, t) {
        var r = l.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r)
        }, t)
    }, m.defer = m.partial(m.delay, m, 1), m.throttle = function(n, t, r) {
        var e, u, i, o = null, a = 0;
        r || (r = {});
        var c = function() {
            a = r.leading===!1 ? 0 : m.now(), o = null, i = n.apply(e, u), o || (e = u = null)
        };
        return function() {
            var f = m.now();
            a || r.leading!==!1 || (a = f);
            var l = t - (f - a);
            return e = this, u = arguments, 0 >= l || l > t ? (o && (clearTimeout(o), o = null), a = f, i = n.apply(e, u), o || (e = u = null)) : o || r.trailing===!1 || (o = setTimeout(c, l)), i
        }
    }, m.debounce = function(n, t, r) {
        var e, u, i, o, a, c = function() {
            var f = m.now() - o;
            t > f && f >= 0 ? e = setTimeout(c, t - f) : (e = null, r || (a = n.apply(i, u), e || (i = u = null)))
        };
        return function() {
            i = this, u = arguments, o = m.now();
            var f = r&&!e;
            return e || (e = setTimeout(c, t)), f && (a = n.apply(i, u), i = u = null), a
        }
    }, m.wrap = function(n, t) {
        return m.partial(t, n)
    }, m.negate = function(n) {
        return function() {
            return !n.apply(this, arguments)
        }
    }, m.compose = function() {
        var n = arguments, t = n.length - 1;
        return function() {
            for (var r = t, e = n[t].apply(this, arguments); r--;)
                e = n[r].call(this, e);
            return e
        }
    }, m.after = function(n, t) {
        return function() {
            return --n < 1 ? t.apply(this, arguments) : void 0
        }
    }, m.before = function(n, t) {
        var r;
        return function() {
            return --n > 0 && (r = t.apply(this, arguments)), 1 >= n && (t = null), r
        }
    }, m.once = m.partial(m.before, 2);
    var M=!{
        toString: null
    }.propertyIsEnumerable("toString"), I = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    m.keys = function(n) {
        if (!m.isObject(n))
            return [];
        if (v)
            return v(n);
        var t = [];
        for (var r in n)
            m.has(n, r) && t.push(r);
        return M && e(n, t), t
    }, m.allKeys = function(n) {
        if (!m.isObject(n))
            return [];
        var t = [];
        for (var r in n)
            t.push(r);
        return M && e(n, t), t
    }, m.values = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++)
            e[u] = n[t[u]];
        return e
    }, m.mapObject = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = u.length, o = {}, a = 0; i > a; a++)
            e = u[a], o[e] = t(n[e], e, n);
        return o
    }, m.pairs = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++)
            e[u] = [t[u], n[t[u]]];
        return e
    }, m.invert = function(n) {
        for (var t = {}, r = m.keys(n), e = 0, u = r.length; u > e; e++)
            t[n[r[e]]] = r[e];
        return t
    }, m.functions = m.methods = function(n) {
        var t = [];
        for (var r in n)
            m.isFunction(n[r]) && t.push(r);
        return t.sort()
    }, m.extend = _(m.allKeys), m.extendOwn = m.assign = _(m.keys), m.findKey = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = 0, o = u.length; o > i; i++)
            if (e = u[i], t(n[e], e, n))
                return e
    }, m.pick = function(n, t, r) {
        var e, u, i = {}, o = n;
        if (null == o)
            return i;
        m.isFunction(t) ? (u = m.allKeys(o), e = b(t, r)) : (u = S(arguments, !1, !1, 1), e = function(n, t, r) {
            return t in r
        }, o = Object(o));
        for (var a = 0, c = u.length; c > a; a++) {
            var f = u[a], l = o[f];
            e(l, f, o) && (i[f] = l)
        }
        return i
    }, m.omit = function(n, t, r) {
        if (m.isFunction(t))
            t = m.negate(t);
        else {
            var e = m.map(S(arguments, !1, !1, 1), String);
            t = function(n, t) {
                return !m.contains(e, t)
            }
        }
        return m.pick(n, t, r)
    }, m.defaults = _(m.allKeys, !0), m.create = function(n, t) {
        var r = j(n);
        return t && m.extendOwn(r, t), r
    }, m.clone = function(n) {
        return m.isObject(n) ? m.isArray(n) ? n.slice() : m.extend({}, n) : n
    }, m.tap = function(n, t) {
        return t(n), n
    }, m.isMatch = function(n, t) {
        var r = m.keys(t), e = r.length;
        if (null == n)
            return !e;
        for (var u = Object(n), i = 0; e > i; i++) {
            var o = r[i];
            if (t[o] !== u[o] ||!(o in u))
                return !1
        }
        return !0
    };
    var N = function(n, t, r, e) {
        if (n === t)
            return 0 !== n || 1 / n === 1 / t;
        if (null == n || null == t)
            return n === t;
        n instanceof m && (n = n._wrapped), t instanceof m && (t = t._wrapped);
        var u = s.call(n);
        if (u !== s.call(t))
            return !1;
        switch (u) {
        case"[object RegExp]":
        case"[object String]":
            return "" + n == "" + t;
        case"[object Number]":
            return + n!==+n?+t!==+t : 0 ===+ n ? 1/+n === 1 / t : + n ===+ t;
        case"[object Date]":
        case"[object Boolean]":
            return + n ===+ t
        }
        var i = "[object Array]" === u;
        if (!i) {
            if ("object" != typeof n || "object" != typeof t)
                return !1;
            var o = n.constructor, a = t.constructor;
            if (o !== a&&!(m.isFunction(o) && o instanceof o && m.isFunction(a) && a instanceof a) && "constructor"in n && "constructor"in t)
                return !1
        }
        r = r || [], e = e || [];
        for (var c = r.length; c--;)
            if (r[c] === n)
                return e[c] === t;
        if (r.push(n), e.push(t), i) {
            if (c = n.length, c !== t.length)
                return !1;
            for (; c--;)
                if (!N(n[c], t[c], r, e))
                    return !1
        } else {
            var f, l = m.keys(n);
            if (c = l.length, m.keys(t).length !== c)
                return !1;
            for (; c--;)
                if (f = l[c], !m.has(t, f) ||!N(n[f], t[f], r, e))
                    return !1
        }
        return r.pop(), e.pop(), !0
    };
    m.isEqual = function(n, t) {
        return N(n, t)
    }, m.isEmpty = function(n) {
        return null == n?!0 : k(n) && (m.isArray(n) || m.isString(n) || m.isArguments(n)) ? 0 === n.length : 0 === m.keys(n).length
    }, m.isElement = function(n) {
        return !(!n || 1 !== n.nodeType)
    }, m.isArray = h || function(n) {
        return "[object Array]" === s.call(n)
    }, m.isObject = function(n) {
        var t = typeof n;
        return "function" === t || "object" === t&&!!n
    }, m.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(n) {
        m["is" + n] = function(t) {
            return s.call(t) === "[object " + n + "]"
        }
    }), m.isArguments(arguments) || (m.isArguments = function(n) {
        return m.has(n, "callee")
    }), "function" != typeof/./ && "object" != typeof Int8Array && (m.isFunction = function(n) {
        return "function" == typeof n ||!1
    }), m.isFinite = function(n) {
        return isFinite(n)&&!isNaN(parseFloat(n))
    }, m.isNaN = function(n) {
        return m.isNumber(n) && n!==+n
    }, m.isBoolean = function(n) {
        return n===!0 || n===!1 || "[object Boolean]" === s.call(n)
    }, m.isNull = function(n) {
        return null === n
    }, m.isUndefined = function(n) {
        return n === void 0
    }, m.has = function(n, t) {
        return null != n && p.call(n, t)
    }, m.noConflict = function() {
        return u._ = i, this
    }, m.identity = function(n) {
        return n
    }, m.constant = function(n) {
        return function() {
            return n
        }
    }, m.noop = function() {}, m.property = w, m.propertyOf = function(n) {
        return null == n ? function() {} : function(t) {
            return n[t]
        }
    }, m.matcher = m.matches = function(n) {
        return n = m.extendOwn({}, n), function(t) {
            return m.isMatch(t, n)
        }
    }, m.times = function(n, t, r) {
        var e = Array(Math.max(0, n));
        t = b(t, r, 1);
        for (var u = 0; n > u; u++)
            e[u] = t(u);
        return e
    }, m.random = function(n, t) {
        return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1))
    }, m.now = Date.now || function() {
        return (new Date).getTime()
    };
    var B = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "`": "&#x60;"
    }, T = m.invert(B), R = function(n) {
        var t = function(t) {
            return n[t]
        }, r = "(?:" + m.keys(n).join("|") + ")", e = RegExp(r), u = RegExp(r, "g");
        return function(n) {
            return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, t) : n
        }
    };
    m.escape = R(B), m.unescape = R(T), m.result = function(n, t, r) {
        var e = null == n ? void 0: n[t];
        return e === void 0 && (e = r), m.isFunction(e) ? e.call(n) : e
    };
    var q = 0;
    m.uniqueId = function(n) {
        var t=++q + "";
        return n ? n + t : t
    }, m.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var K = /(.)^/, z = {
        "'": "'",
        "\\": "\\",
        "\r": "r",
        "\n": "n",
        "\u2028": "u2028",
        "\u2029": "u2029"
    }, D = /\\|'|\r|\n|\u2028|\u2029/g, L = function(n) {
        return "\\" + z[n]
    };
    m.template = function(n, t, r) {
        !t && r && (t = r), t = m.defaults({}, t, m.templateSettings);
        var e = RegExp([(t.escape || K).source, (t.interpolate || K).source, (t.evaluate || K).source].join("|") + "|$", "g"), u = 0, i = "__p+='";
        n.replace(e, function(t, r, e, o, a) {
            return i += n.slice(u, a).replace(D, L), u = a + t.length, r ? i += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'" : e ? i += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : o && (i += "';\n" + o + "\n__p+='"), t
        }), i += "';\n", t.variable || (i = "with(obj||{}){\n" + i + "}\n"), i = "var __t,__p='',__j=Array.prototype.join," + "print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", i)
        } catch (a) {
            throw a.source = i, a
        }
        var c = function(n) {
            return o.call(this, n, m)
        }, f = t.variable || "obj";
        return c.source = "function(" + f + "){\n" + i + "}", c
    }, m.chain = function(n) {
        var t = m(n);
        return t._chain=!0, t
    };
    var P = function(n, t) {
        return n._chain ? m(t).chain() : t
    };
    m.mixin = function(n) {
        m.each(m.functions(n), function(t) {
            var r = m[t] = n[t];
            m.prototype[t] = function() {
                var n = [this._wrapped];
                return f.apply(n, arguments), P(this, r.apply(m, n))
            }
        })
    }, m.mixin(m), m.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments), "shift" !== n && "splice" !== n || 0 !== r.length || delete r[0], P(this, r)
        }
    }), m.each(["concat", "join", "slice"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            return P(this, t.apply(this._wrapped, arguments))
        }
    }), m.prototype.value = function() {
        return this._wrapped
    }, m.prototype.valueOf = m.prototype.toJSON = m.prototype.value, m.prototype.toString = function() {
        return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return m
    })
}).call(this);
//# sourceMappingURL=underscore-min.map;
(function(e) {
    e.fn.mzForm = function(r) {
        var a = e(this);
        r = e.extend({
            errorClass: "error-tip",
            succClass: "succ-tip",
            errorText: "Error",
            succText: "Success",
            tipPreFix: "-tip",
            onSuccess: false
        }, r);
        var s = {};
        a.validate = function() {
            var i = true;
            try {
                a.find("*[data-valid],*[require]").each(function() {
                    if (!i) {
                        return 
                    }
                    var r = e(this);
                    var u = r.prop("required"), c = r.data("valid"), l = e.trim(r.val());
                    switch (r.prop("type")) {
                    case"checkbox":
                    case"radio":
                        l = r.is(":checked");
                        break;
                    default:
                        if (u&&!l) {
                            i = false;
                            t(this);
                            return 
                        }
                        break
                    }
                    var f = false;
                    switch (c) {
                    case"url":
                        var o = r.data("url");
                        o = o.replace(/__value__/gi, l);
                        if (s[o]) {
                            return true
                        }
                        r.off("keyup").on("keyup", function() {
                            s[o] = false
                        });
                        i = false;
                        e.get(o, function(e) {
                            if (e == "1") {
                                s[o] = true;
                                t(r, false, true);
                                a.submit()
                            } else {
                                t(r, e)
                            }
                        });
                        f = true;
                        break;
                    case"equal":
                        var n = r.data("equal");
                        var d = e.trim(e(n).val());
                        if (d != l) {
                            i = false;
                            t(r);
                            return false
                        }
                        f = true;
                        break;
                    case"email":
                        c = "^(?:[\\w][\\.\\w\\-]*?)@(?:\\w+\\.)+\\w+$";
                        break;
                    case"phone":
                        c = "^1\\d{10}$";
                        break;
                    default:
                        break
                    }
                    if (!f) {
                        var h = new RegExp(c, "gi");
                        if (!h.test(l)) {
                            i = false;
                            t(this);
                            return false
                        }
                    }
                    t(this, false, true)
                })
            } catch (u) {
                console.log(u);
                i = false
            }
            if (i && r.onSuccess) {
                return r.onSuccess()
            }
            return i
        };
        function t(a, s, t) {
            var i = e(a).prop("id"), u = s ? s: e(a).data("error"), c = e("#" + e(a).data("focus")), l = s ? s: e(a).data("succ"), f = e("#" + i + r.tipPreFix);
            l = l ? l : r.succText;
            u = u ? u : r.errorText;
            if (f.length > 0) {
                if (t) {
                    f.html(l).show().removeClass(r.errorClass).addClass(r.succClass)
                } else {
                    f.html(u).show().removeClass(r.succClass).addClass(r.errorClass);
                    if (c.length > 0) {
                        c.focus()
                    } else {
                        a.focus()
                    }
                }
            }
        }
        this.off("submit", a.validate).on("submit", a.validate);
        return a
    }
})(this.jQuery || this.Zepto);;

(function($) {
    $.fn.autoFocus = function(callback) {
        var boxArray = $(this);
        $(this).each(function() {
            $(this).on('keyup', function(event) {
                if (event.keyCode == 13) {
                    var boxIndex = boxArray.indexOf(this);
                    if (boxIndex == boxArray.length - 1) {
                        if (callback)
                            callback();
                    } else {
                        var nextBox = boxArray[++boxIndex];
                        nextBox.focus();
                    }
                }
            });
        });
    };
})($);;
var swipers = {};
window.CLICK_EVENT = "click";
if ("ontouchstart"in document) {
    window.CLICK_EVENT = "tap"
}
if ("ontap"in document) {}
window.onerror = function(e, t, a, n, i) {
    var o = new Image;
    o.src = DIR + "c.gif?_=js&m=" + e + "&u=" + t + "&l=" + a + "&c=" + n + "&o=" + i
};
function onBridgeReady() {
    WeixinJSBridge.call(hideWXMenu == 1 ? "hideOptionMenu" : "showOptionMenu")
}
window.formatKM = function(e) {
    if (false && e > 1e3) {
        return Math.round(e * 100 / 1e3) / 100 + " ����"
    } else {
        return e + " ��"
    }
};
initEvents.push(function() {

    $("img[data-lazy]").lazyload();
    var searchScrollElements = $(".search-scroll-body");
    if (searchScrollElements.length > 0) {
        searchScrollElements.each(function() {
            var e = 0;
            $(this).children().each(function() {
                e += $(this).width()
            });
            var t = parseInt($(this).data("addwidth"), 10);
            $(this).width(e + (t > 0 ? t : 0))
        })
    }
    $(document).on(window.CLICK_EVENT, "*[data-search]", function() {
        var e = $(this).data("search");
        if (e) {
            e = parseInt(e, 10) == 1 ? $(this).text() : e;
            window.openIt(DIR + "tag/" + e + "/")
        }
    });
    if (typeof mui != "undefined" && mui.os.plus) {
        $(document).on("click", "*[_click]", function(e) {
            var t = $(this).attr("href");
            if (t && t.search(/#/) != 0) {
                window.openIt(e);
                e.stopPropagation();
                return false
            }
        })
    } else {
        $(document).on(window.CLICK_EVENT, "*[_click]", function(e) {
            var thisClick = $(this).attr("_click");
            switch (thisClick) {
            case"href":
                var url = $(this).attr("href");
                if ($(this).attr("target")) {
                    window.open(url, $(this).attr("target"))
                } else {
                    location.href = $(this).attr("href")
                }
                window.event.stopPropagation();
                window.event.preventDefault();
                return false;
            default:
                try {
                    var res = window[thisClick](e)
                } catch (e) {
                    eval(thisClick);
                    console.log(thisClick + ":" + e.description)
                }
                $(this).blur();
                window.event.stopPropagation();
                window.event.preventDefault();
                return res
            }
        })
    }
    window.runSlider = function(e) {
        var t = e.find(e.data("pos") || ".pagination");
        var a = e.data("autoplay");
        a = a==-1 ? false : a;
        var n;
        function i() {
            var t = n.activeSlide();
            var a = $(".mui-bar-tab").length > 0 ? 50 * 1.5: 0;
            var i = parseInt($(t).children().height(), 10);
            var o = Math.max(i + a + 20, 200);
            e.css("height", o);
            e.find(".swiper-wrapper").css("height", o);
            console.log("height", o)
        }
        function o(t, a) {
            var n = window[e.data("onslide")];
            if (typeof a != "function") {
                a = false
            }
            n && n(t, a)
        }
        n = new Swiper(e[0], {
            loop: true,
            speed: 500,
            autoplay: a,
            calculateHeight: true,
            paginationClickable: true,
            pagination: t[0],
            onSlideChangeEnd: o
        });
        var r = e.data("name");
        setTimeout(function() {
            o(n, i)
        }, 500);
        if (r) {
            swipers[r] = n
        }
        e.find(".arrow-left").on("click", function(e) {
            e.preventDefault();
            n.swipePrev()
        });
        e.find(".arrow-right").on("click", function(e) {
            e.preventDefault();
            n.swipeNext()
        })
    };
    $(".swiper-container").each(function() {
        runSlider($(this))
    });
    window.formInit();
    var suggestElements = $(".suggest-input");
    if (suggestElements.length > 0) {
        suggestElements.on("input", function() {
            var e = $.trim($(this).val());
            if (e == "") {
                $(this).next().hide()
            } else {
                $(this).next().show()
            }
        }).on("focus", function() {
            var e = $(this).data("focuscolor");
            $(this).css({
                color: e ? e: "#000"
            })
        }).on("blur", function() {
            var e = $(this).data("blurcolor");
            $(this).css({
                color: e ? e: "#FFF"
            })
        }).suggest({
            onQuery: function(e, t, a) {
                var n = "key=" + encodeURIComponent(e);
                if ($(a).data("post")) {
                    n += "&" + $(a).data("post")
                }
                window.API.post("suggest", n, function(e) {
                    t(e && e.extend ? e.extend : false)
                })
            }
        });
        for (var i, l = suggestElements.length; i < l; i++) {
            var that = suggestElements[i];
            var color = that.data("blurcolor");
            that.css({
                color: color ? color: "#FFF"
            })
        }
    }
    $(document).on(window.CLICK_EVENT, ".slide-menu", function(e) {
        var t = $(this).data("target");
        var a = $(this).data("title");
        if (!t) {
            return false
        }
        var n = $(window).height();
        var i = $(this).data("target");
        var o = $("#" + i);
        if (o.data("element")) {
            o = $("#" + i + "_gen")
        }
        if (o.data("html")) {
            var r = $(o.val()).attr("id", i + "_gen");
            $(document.body).append(r);
            o.data("element", r);
            o = r
        }
        var s = $(this);
        var l = 200;
        function c() {
            s.removeClass("active");
            o.css({
                top: 0,
                opacity: 1
            }).animate({
                top: n,
                opacity: 0
            }, l, "ease-out", function() {
                o.hide()
            })
        }
        o.find(".sort-close").off("click").on("click", c);
        o.find(".sort-title-text").text(a);
        s.addClass("active");
        o.show().css({
            top: n,
            opacity: 0
        }).animate({
            top: 0,
            opacity: 1
        }, l, "ease-in", function() {
            o.show()
        });
        o.find("*[data-bg]").each(function() {
            $(this).css({
                backgroundImage: "url(" + $(this).data("bg") + ")",
                backgroundSize: "cover"
            }).removeAttr("data-bg")
        })
    });
});
window.formInit = function(selector) {
    $(selector || "form[data-api]").each(function() {
        var currentForm = $(this);
        var ajaxFrameId = "ajaxframe";
        function ajaxForm(e, t, a) {
            var n = $(e);
            var i = $("#" + ajaxFrameId);
            if (i.length == 0) {
                i = $("<iframe name='" + ajaxFrameId + "' id='" + ajaxFrameId + "' style='display:none'></iframe>");
                $(document.body).append(i)
            }
            $(n).attr("target", ajaxFrameId).attr("action", DIR + "/" + t + "&FORM_HASH=" + FORM_HASH);
            i.off("load").on("load", function() {
                formLoad(a)
            });
            try {
                plus.nativeUI.showWaiting()
            } catch (o) {}
        }
        function formLoad(callback) {
            try {
                plus.nativeUI.closeWaiting()
            } catch (e) {}
            currentForm.data("posting", 0);
            var theFrame = $("#" + ajaxFrameId).get(0);
            var responseText = (theFrame.contentDocument ? theFrame.contentDocument : theFrame.contentWindow.document).body.innerText;
            var data;
            try {
                eval("data=" + responseText)
            } catch (e) {}
            callback && callback(data)
        }
        window.onDefaultCallback = function(e) {
            if (data && data.error == 0) {
                showMessage('&#25805;&#20316;&#25104;&#21151;');
            } else {
                showMessage('&#25805;&#20316;&#22833;&#36133;&#65306;' + (data.data ? data.data : ''));
            }
        };
        var onSuccess = function() {
            var api = currentForm.data("api"), callback = currentForm.data("call");
            callback = callback ? callback : "onDefaultCallback";
            if (!api) {
                return false
            }
            if (currentForm.data("posting") == 1) {
                return false
            }
            currentForm.data("posting", 1);
            ajaxForm(currentForm, api, function(resp) {
                try {
                    if (typeof resp != "object") {
                        eval("resp=" + resp)
                    }
                    if (window[callback]) {
                        window[callback](resp)
                    }
                } catch (e) {
                    console.log("Exception", api, e)
                }
            });
            return true
        };
        currentForm.mzForm({
            succText: "",
            errorText: '&#36755;&#20837;&#38169;&#35823;',
            onSuccess: onSuccess
        });
        var autoFocusQuery = currentForm.data("enterfocus");
        if (autoFocusQuery) {
            var autFocusElement = currentForm.find(autoFocusQuery);
            $(autFocusElement).autoFocus(function() {
                currentForm.trigger("submit")
            })
        }
    })
};
window.mzTpl = function() {
    var e = {};
    return function t(a, n) {
        var i=!/\W/.test(a) ? e[a] = e[a] || mzTpl(document.getElementById(a).innerHTML) : new Function("obj", "var p=[],print=function(){p.push.apply(p,arguments);};" + "with(obj){p.push('" + a.replace(/[\r\t\n]/g, " ").split("<%").join("	").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t=(.*?)%>/g, "',$1,'").split("	").join("');").split("%>").join("p.push('").split("\r").join("\\'") + "');}return p.join('');");
        return n ? i(n) : i
    }
}();
window.showMessage = function(e, t) {
    if (window.mui) {
        if ($("#msg-dialog").length == 0) {
            var a = '<div id="msg-dialog" class="mui-popover simple-dialog" style="top:20px;margin-left:5%;max-height: 90%;overflow: hidden; overflow-y: auto;width:90%;"><div class="mui-content-padded"><div class="close" onclick="mui(\'#msg-dialog\').popover(\'hide\')">x</div><div class="msg-title"></div><div class="msg-content"></div></div></div>';
            $(document.body).append(a)
        }
        if (e == "hide") {
            mui("#msg-dialog").popover("hide");
            return 
        }
        if (t) {
            $("#msg-dialog .msg-title").html(t).show()
        } else {
            $("#msg-dialog .msg-title").hide()
        }
        $("#msg-dialog .msg-content").html(e);
        mui("#msg-dialog").popover("show")
    } else if (window.jQuery) {
        if ($("#").length == 0) {
            var a = '<div class="modal fade" id="msg-dialog" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"><div class="modal-dialog" role="document"><div class="modal-content"> <div class="modal-header">   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel"></h4> </div> <div class="modal-body"></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>';
            $(document.body).append(a)
        }
        if (e == "hide") {
            $("#msg-dialog").modal("hide");
            return 
        }
        $("#msg-dialog .modal-title").html(t || "��Ϣ��ʾ").show();
        $("#msg-dialog .modal-body").html(e);
        $("#msg-dialog").modal("show")
    }
};
window.closeWindow = function(e) {
    try {
        plus.webview.currentWebview().close()
    } catch (t) {
        console.log(t)
    }
    try {
        window.close()
    } catch (t) {
        console.log(t)
    }
    return false
};
window.openIt = function(e, t) {
    var a = "", n = false, i = 0, o = false, r = false;
    if (e.target) {
        e = e.target
    }
    try {
        i = $(e).length
    } catch (s) {}
    if (i > 0) {
        while (!a) {
            a = $(e).attr("href");
            if (!a) {
                e = $(e).parent();
                i = $(e).length;
                if (i == 0) {
                    break
                }
            }
        }
        r = $(e).data("loading") ? true : false;
        t = (t || $(e).data("name")) + a;
        n = $(e).attr("target") == "_blank" ? true : false
    } else {
        if (typeof e == "string") {
            a = e
        } else {
            a = e.link
        }
        n = true
    }
    if (a.search(/https?:\/\//gi)==-1 && a.search(/tel:/gi)==-1) {
        a = "http://" + location.hostname + a
    }
    if (!window.plus) {
        if (n) {
            window.open(a)
        } else {
            location.href = a
        }
        window.event.stopPropagation();
        return !n
    }
    var l = "pop-in";
    var c = {
        popGesture: "close"
    };
    console.log("url=" + a);
    c.zindex = 9998;
    c.popGesture = "close";
    t = t || "detail";
    var d = mui.openWindow({
        id: t,
        url: a,
        styles: c,
        show: {
            aniShow: l
        },
        render: "onscreen",
        waiting: {
            autoShow: r,
            title: ""
        },
        scalable: true
    });
    console.log("openIt=" + d);
    window.event.stopPropagation();
    return false
};
window.imgErr = function(e) {
    e.onerror = null;
    e.src = STATIC_URL
};
function plusReady() {
    for (var e in initEvents) {
        try {
            initEvents[e]()
        } catch (t) {
            console.log(t)
        }
    }
}
try {
    if (window.mui && mui.os.plus) {
        if (window.plus) {
            $(document).ready(plusReady)
        } else {
            mui.plusReady(plusReady)
        }
    } else {
        $(document).ready(plusReady)
    }
} catch (e) {
    console.log("plusInit :" + e.description)
};
initEvents.push(function() {
    window.store = function() {
        var t = this;
        t.agent = "plus";
        if (window.localStorage) {
            t.set = function(t, n) {
                return window.localStorage.setItem(t, n + "")
            };
            t.get = function(t) {
                return window.localStorage.getItem(t)
            };
            t.agent = "local"
        } else {
            t.set = function(t, n) {
                return $.fn.cookie(t, n, 9999)
            };
            t.get = function(t) {
                return $.fn.cookie(t)
            };
            t.agent = "cookie"
        }
        return t
    }()
});;
window.userLogin = function(e) {
    try {
        mui.ge.fireEvent("auth", e)
    } catch (i) {}
    if (e && e.username) {
        window.store.set("login", e.phone)
    }
};
