/*[tplStatic 1.0 - 4373168]*/
function initCategory(a, t, i) {
    var e = new BMap.Map(t.createElement("div"));
    var n = new BMap.Geolocation;
    var o = "";
    var r = {};
    function l(a) {
        var t = $(a).data("tabapi") ? $(a).data("tabapi"): $(a).data("api"), i = parseInt($(a).data("page"), 10);
        if (i>-1) {
            $(a).off("scroll", d).find(".loading").show();
            t = t.replace("%page%", ++i);
            t = t.replace("%geo%", o);
            $(a).data("page", "");
            if (r[t]) {
                s(a, r[t], i)
            } else {
                $.get(t, function(e) {
                    r[t] = e;
                    s(a, e, i)
                })
            }
        }
    }
    function s(a, t, i) {
        if ($.trim(t)) {
            $(a).data("page", i);
            var e = $(a).find(".list-company-list");
            if (e.length == 0) {
                e = $(a).find("ul")
            }
            e.append(t);
            $(a).find("img[data-lazy]").lazyload();
            if (i == 1) {
                var n = $(a).find(".category-banner-swiper");
                if (n.length > 0) {
                    runSlider(n);
                    $(a).find("ul").addClass("category-banner-list")
                }
            }
            $(a).find(".loading").hide();
            setTimeout(function() {
                $(a).on("scroll", d)
            }, 1e3)
        } else {
            var o = "&#24050;&#32463;&#20840;&#37096;&#21152;&#36733;&#23436;&#27605;&#65281;";
            if ($(a).find("ul li").length == 0) {
                o = '<div class="tip-404 waring"><div class="icon warning"></div>&#24744;&#26469;&#30340;&#22826;&#26089;&#65292;&#36824;&#27809;&#26377;&#25910;&#24405;&#25968;&#25454;</div>'
            }
            $(a).find(".loading").html(o).show()
        }
    }
    function d() {
        var t = $(this);
        var i = t.offset();
        var e = t.scrollTop();
        var n = t.find("ul").eq(0);
        a.__lazyLoad(e + i.top);
        if (n.height() - 150 < t.height() + e) {
            l(t)
        }
    }
    $(".nav-item").on("click", function() {
        var a = $(this).data("id");
        $(this).parent().find("*").removeClass("mui-active");
        $(this).addClass("mui-active");
        var t = $("#content" + a);
        if (parseInt(t.data("page"), 10) == 0) {
            l(t)
        }
        $(".mui-control-content").removeClass("mui-active");
        t.addClass("mui-active");
        location.href = $(this).data("href");
        return false
    });
    $(t).on(a.CLICK_EVENT, ".list-tab-item", function() {
        var a = $(this);
        var t = a.data("id");
        a.parent().find("*").removeClass("mui-active");
        a.addClass("mui-active");
        $(".mui-control-content").removeClass("mui-active");
        var i = $("#content" + t);
        i.addClass("mui-active");
        $(i).data("page", 0).find(".list-company-list").html("");
        $(i).data("tabapi", a.data("api"));
        $(i).find(".loading").html("&#20351;&#21170;&#21152;&#36733;&#20013;&#46;&#46;&#46;").show();
        if (a.data("type") == "nearby") {
            if (o) {
                l(i)
            } else {
                mui.toast("&#35831;&#30830;&#20445;&#24320;&#21551;&#25163;&#26426;&#23450;&#20301;&#46;");
                n.getCurrentPosition(function(a) {
                    if (this.getStatus() == BMAP_STATUS_SUCCESS) {
                        o = a.point.lng + "," + a.point.lat
                    }
                    if (!o) {
                        alert("&#26080;&#27861;&#21462;&#24471;&#24744;&#24403;&#21069;&#20301;&#32622;&#65292;&#21462;&#32467;&#26524;&#22833;&#36133;&#126;");
                        return 
                    }
                    l(i)
                }, {
                    enableHighAccuracy: true
                })
            }
        } else if (parseInt(i.data("page"), 10) == 0) {
            l(i)
        }
        location.href = $(this).data("href");
        return false
    });
    $("#content0").on("scroll", d);
    a.searchIndex = function(a) {};
    var c = location.hash.substr(1);
    if (!c) {
        c = "" + i.cid
    }
    if (c) {
        var f = $('.mui-control-item[data-id="' + c + '"]');
        if (f.length > 0) {
            f.trigger("click")
        }
        $("#segmentedControls").parent().scrollTop(f.offset().top - 50)
    }
};

