/*[tplStatic 1.0 - 7542724]*/
initEvents.push(function() {
    $(".company-header a").on("click", function() {
        swipers["list"].swipeTo($(this).index());
        window.listChange(swipers["list"])
    });
    var i = $(".search-scroll-body");
    if (i.length > 0) {
        i.each(function() {
            var i = 0;
            $(this).find("*").each(function() {
                i += $(this).width();
                var a = $(this).data("search");
                if (a) {
                    a = parseInt(a, 10) == 1 ? $(this).text() : a;
                    $(this).attr("href", DIR + "tag/" + a + "/")
                }
            });
            $(this).width(i)
        })
    }
    window.listChange = function(i, a) {
        var n = $(".company-header a");
        n.removeClass("active");
        var e = i.activeIndex - 1;
        n.eq(e).addClass("active");
        if (a) {
            window.resizeCallback = a
        }
        var t = $(".shop-list-" + e);
        var s = n.eq(e).data("api");
        if (s && t.find(".loading").length > 0&&!t.data("loading")) {
            t.data("loading", 1);
            $.ajax({
                url: s,
                success: function(i) {
                    t.html(i);
                    window.resizeCallback && window.resizeCallback()
                }
            })
        }
        window.resizeCallback && window.resizeCallback()
    };
    function a() {
        if (!e || e.next().length == 0) {
            e = $(".new-join").find("div").eq(0);
            $(".new-join").animate({
                "margin-top": "0px"
            })
        } else {
            e = e.next()
        }
        return e
    }
    function n() {
        var i = a();
        var n = i.height() * i.index();
        $(".new-join").animate({
            "margin-top": - n + "px"
        }, 600, function() {})
    }
    var e;
    var t;
    t = setInterval(function() {
        n()
    }, 3e3);
    n()
});;


