/*[tplStatic 1.0 - 5908508]*/
/* Zepto v1.1.6 - zepto event ajax form ie - zeptojs.com/license */
var Zepto = function() {
    function L(t) {
        return null == t ? String(t) : j[S.call(t)] || "object"
    }
    function Z(t) {
        return "function" == L(t)
    }
    function _(t) {
        return null != t && t == t.window
    }
    function $(t) {
        return null != t && t.nodeType == t.DOCUMENT_NODE
    }
    function D(t) {
        return "object" == L(t)
    }
    function M(t) {
        return D(t)&&!_(t) && Object.getPrototypeOf(t) == Object.prototype
    }
    function R(t) {
        return "number" == typeof t.length
    }
    function k(t) {
        return s.call(t, function(t) {
            return null != t
        })
    }
    function z(t) {
        return t.length > 0 ? n.fn.concat.apply([], t) : t
    }
    function F(t) {
        return t.replace(/::/g, "/").replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2").replace(/([a-z\d])([A-Z])/g, "$1_$2").replace(/_/g, "-").toLowerCase()
    }
    function q(t) {
        return t in f ? f[t] : f[t] = new RegExp("(^|\\s)" + t + "(\\s|$)")
    }
    function H(t, e) {
        return "number" != typeof e || c[F(t)] ? e : e + "px"
    }
    function I(t) {
        var e, n;
        return u[t] || (e = a.createElement(t), a.body.appendChild(e), n = getComputedStyle(e, "").getPropertyValue("display"), e.parentNode.removeChild(e), "none" == n && (n = "block"), u[t] = n), u[t]
    }
    function V(t) {
        return "children"in t ? o.call(t.children) : n.map(t.childNodes, function(t) {
            return 1 == t.nodeType ? t : void 0
        })
    }
    function B(n, i, r) {
        for (e in i)
            r && (M(i[e]) || A(i[e])) ? (M(i[e])&&!M(n[e]) && (n[e] = {}), A(i[e])&&!A(n[e]) && (n[e] = []), B(n[e], i[e], r)) : i[e] !== t && (n[e] = i[e])
    }
    function U(t, e) {
        return null == e ? n(t) : n(t).filter(e)
    }
    function J(t, e, n, i) {
        return Z(e) ? e.call(t, n, i) : e
    }
    function X(t, e, n) {
        null == n ? t.removeAttribute(e) : t.setAttribute(e, n)
    }
    function W(e, n) {
        var i = e.className || "", r = i && i.baseVal !== t;
        return n === t ? r ? i.baseVal : i : void(r ? i.baseVal = n : e.className = n)
    }
    function Y(t) {
        try {
            return t ? "true" == t || ("false" == t?!1 : "null" == t ? null : + t + "" == t?+t : /^[\[\{]/.test(t) ? n.parseJSON(t) : t) : t
        } catch (e) {
            return t
        }
    }
    function G(t, e) {
        e(t);
        for (var n = 0, i = t.childNodes.length; i > n; n++)
            G(t.childNodes[n], e)
    }
    var t, e, n, i, C, N, r = [], o = r.slice, s = r.filter, a = window.document, u = {}, f = {}, c = {
        "column-count": 1,
        columns: 1,
        "font-weight": 1,
        "line-height": 1,
        opacity: 1,
        "z-index": 1,
        zoom: 1
    }, l = /^\s*<(\w+|!)[^>]*>/, h = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, p = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, d = /^(?:body|html)$/i, m = /([A-Z])/g, g = ["val", "css", "html", "text", "data", "width", "height", "offset"], v = ["after", "prepend", "before", "append"], y = a.createElement("table"), x = a.createElement("tr"), b = {
        tr: a.createElement("tbody"),
        tbody: y,
        thead: y,
        tfoot: y,
        td: x,
        th: x,
        "*": a.createElement("div")
    }, w = /complete|loaded|interactive/, E = /^[\w-]*$/, j = {}, S = j.toString, T = {}, O = a.createElement("div"), P = {
        tabindex: "tabIndex",
        readonly: "readOnly",
        "for": "htmlFor",
        "class": "className",
        maxlength: "maxLength",
        cellspacing: "cellSpacing",
        cellpadding: "cellPadding",
        rowspan: "rowSpan",
        colspan: "colSpan",
        usemap: "useMap",
        frameborder: "frameBorder",
        contenteditable: "contentEditable"
    }, A = Array.isArray || function(t) {
        return t instanceof Array
    };
    return T.matches = function(t, e) {
        if (!e ||!t || 1 !== t.nodeType)
            return !1;
        var n = t.webkitMatchesSelector || t.mozMatchesSelector || t.oMatchesSelector || t.matchesSelector;
        if (n)
            return n.call(t, e);
        var i, r = t.parentNode, o=!r;
        return o && (r = O).appendChild(t), i=~T.qsa(r, e).indexOf(t), o && O.removeChild(t), i
    }, C = function(t) {
        return t.replace(/-+(.)?/g, function(t, e) {
            return e ? e.toUpperCase() : ""
        })
    }, N = function(t) {
        return s.call(t, function(e, n) {
            return t.indexOf(e) == n
        })
    }, T.fragment = function(e, i, r) {
        var s, u, f;
        return h.test(e) && (s = n(a.createElement(RegExp.$1))), s || (e.replace && (e = e.replace(p, "<$1></$2>")), i === t && (i = l.test(e) && RegExp.$1), i in b || (i = "*"), f = b[i], f.innerHTML = "" + e, s = n.each(o.call(f.childNodes), function() {
            f.removeChild(this)
        })), M(r) && (u = n(s), n.each(r, function(t, e) {
            g.indexOf(t)>-1 ? u[t](e) : u.attr(t, e)
        })), s
    }, T.Z = function(t, e) {
        return t = t || [], t.__proto__ = n.fn, t.selector = e || "", t
    }, T.isZ = function(t) {
        return t instanceof T.Z
    }, T.init = function(e, i) {
        var r;
        if (!e)
            return T.Z();
        if ("string" == typeof e)
            if (e = e.trim(), "<" == e[0] && l.test(e))
                r = T.fragment(e, RegExp.$1, i), e = null;
            else {
                if (i !== t)
                    return n(i).find(e);
                    r = T.qsa(a, e)
            } else {
            if (Z(e))
                return n(a).ready(e);
            if (T.isZ(e))
                return e;
            if (A(e))
                r = k(e);
            else if (D(e))
                r = [e], e = null;
            else if (l.test(e))
                r = T.fragment(e.trim(), RegExp.$1, i), e = null;
            else {
                if (i !== t)
                    return n(i).find(e);
                r = T.qsa(a, e)
            }
        }
        return T.Z(r, e)
    }, n = function(t, e) {
        return T.init(t, e)
    }, n.extend = function(t) {
        var e, n = o.call(arguments, 1);
        return "boolean" == typeof t && (e = t, t = n.shift()), n.forEach(function(n) {
            B(t, n, e)
        }), t
    }, T.qsa = function(t, e) {
        var n, i = "#" == e[0], r=!i && "." == e[0], s = i || r ? e.slice(1) : e, a = E.test(s);
        return $(t) && a && i ? (n = t.getElementById(s)) ? [n] : [] : 1 !== t.nodeType && 9 !== t.nodeType ? [] : o.call(a&&!i ? r ? t.getElementsByClassName(s) : t.getElementsByTagName(e) : t.querySelectorAll(e))
    }, n.contains = a.documentElement.contains ? function(t, e) {
        return t !== e && t.contains(e)
    } : function(t, e) {
        for (; e && (e = e.parentNode);)
            if (e === t)
                return !0;
        return !1
    }, n.type = L, n.isFunction = Z, n.isWindow = _, n.isArray = A, n.isPlainObject = M, n.isEmptyObject = function(t) {
        var e;
        for (e in t)
            return !1;
        return !0
    }, n.inArray = function(t, e, n) {
        return r.indexOf.call(e, t, n)
    }, n.camelCase = C, n.trim = function(t) {
        return null == t ? "" : String.prototype.trim.call(t)
    }, n.uuid = 0, n.support = {}, n.expr = {}, n.map = function(t, e) {
        var n, r, o, i = [];
        if (R(t))
            for (r = 0; r < t.length; r++)
                n = e(t[r], r), null != n && i.push(n);
        else 
            for (o in t)
                n = e(t[o], o), null != n && i.push(n);
        return z(i)
    }, n.each = function(t, e) {
        var n, i;
        if (R(t)) {
            for (n = 0; n < t.length; n++)
                if (e.call(t[n], n, t[n])===!1)
                    return t
        } else 
            for (i in t)
                if (e.call(t[i], i, t[i])===!1)
                    return t;
        return t
    }, n.grep = function(t, e) {
        return s.call(t, e)
    }, window.JSON && (n.parseJSON = JSON.parse), n.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(t, e) {
        j["[object " + e + "]"] = e.toLowerCase()
    }), n.fn = {
        forEach: r.forEach,
        reduce: r.reduce,
        push: r.push,
        sort: r.sort,
        indexOf: r.indexOf,
        concat: r.concat,
        map: function(t) {
            return n(n.map(this, function(e, n) {
                return t.call(e, n, e)
            }))
        },
        slice: function() {
            return n(o.apply(this, arguments))
        },
        ready: function(t) {
            return w.test(a.readyState) && a.body ? t(n) : a.addEventListener("DOMContentLoaded", function() {
                t(n)
            }, !1), this
        },
        get: function(e) {
            return e === t ? o.call(this) : this[e >= 0 ? e: e + this.length]
        },
        toArray: function() {
            return this.get()
        },
        size: function() {
            return this.length
        },
        remove: function() {
            return this.each(function() {
                null != this.parentNode && this.parentNode.removeChild(this)
            })
        },
        each: function(t) {
            return r.every.call(this, function(e, n) {
                return t.call(e, n, e)!==!1
            }), this
        },
        filter: function(t) {
            return Z(t) ? this.not(this.not(t)) : n(s.call(this, function(e) {
                return T.matches(e, t)
            }))
        },
        add: function(t, e) {
            return n(N(this.concat(n(t, e))))
        },
        is: function(t) {
            return this.length > 0 && T.matches(this[0], t)
        },
        not: function(e) {
            var i = [];
            if (Z(e) && e.call !== t)
                this.each(function(t) {
                    e.call(this, t) || i.push(this)
                });
            else {
                var r = "string" == typeof e ? this.filter(e): R(e) && Z(e.item) ? o.call(e): n(e);
                this.forEach(function(t) {
                    r.indexOf(t) < 0 && i.push(t)
                })
            }
            return n(i)
        },
        has: function(t) {
            return this.filter(function() {
                return D(t) ? n.contains(this, t) : n(this).find(t).size()
            })
        },
        eq: function(t) {
            return - 1 === t ? this.slice(t) : this.slice(t, + t + 1)
        },
        first: function() {
            var t = this[0];
            return t&&!D(t) ? t : n(t)
        },
        last: function() {
            var t = this[this.length - 1];
            return t&&!D(t) ? t : n(t)
        },
        find: function(t) {
            var e, i = this;
            return e = t ? "object" == typeof t ? n(t).filter(function() {
                var t = this;
                return r.some.call(i, function(e) {
                    return n.contains(e, t)
                })
            }) : 1 == this.length ? n(T.qsa(this[0], t)) : this.map(function() {
                return T.qsa(this, t)
            }) : n()
        },
        closest: function(t, e) {
            var i = this[0], r=!1;
            for ("object" == typeof t && (r = n(t)); i&&!(r ? r.indexOf(i) >= 0 : T.matches(i, t));)
                i = i !== e&&!$(i) && i.parentNode;
            return n(i)
        },
        parents: function(t) {
            for (var e = [], i = this; i.length > 0;)
                i = n.map(i, function(t) {
                    return (t = t.parentNode)&&!$(t) && e.indexOf(t) < 0 ? (e.push(t), t) : void 0
                });
            return U(e, t)
        },
        parent: function(t) {
            return U(N(this.pluck("parentNode")), t)
        },
        children: function(t) {
            return U(this.map(function() {
                return V(this)
            }), t)
        },
        contents: function() {
            return this.map(function() {
                return o.call(this.childNodes)
            })
        },
        siblings: function(t) {
            return U(this.map(function(t, e) {
                return s.call(V(e.parentNode), function(t) {
                    return t !== e
                })
            }), t)
        },
        empty: function() {
            return this.each(function() {
                this.innerHTML = ""
            })
        },
        pluck: function(t) {
            return n.map(this, function(e) {
                return e[t]
            })
        },
        show: function() {
            return this.each(function() {
                "none" == this.style.display && (this.style.display = ""), "none" == getComputedStyle(this, "").getPropertyValue("display") && (this.style.display = I(this.nodeName))
            })
        },
        replaceWith: function(t) {
            return this.before(t).remove()
        },
        wrap: function(t) {
            var e = Z(t);
            if (this[0]&&!e)
                var i = n(t).get(0), r = i.parentNode || this.length > 1;
            return this.each(function(o) {
                n(this).wrapAll(e ? t.call(this, o) : r ? i.cloneNode(!0) : i)
            })
        },
        wrapAll: function(t) {
            if (this[0]) {
                n(this[0]).before(t = n(t));
                for (var e; (e = t.children()).length;)
                    t = e.first();
                n(t).append(this)
            }
            return this
        },
        wrapInner: function(t) {
            var e = Z(t);
            return this.each(function(i) {
                var r = n(this), o = r.contents(), s = e ? t.call(this, i): t;
                o.length ? o.wrapAll(s) : r.append(s)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                n(this).replaceWith(n(this).children())
            }), this
        },
        clone: function() {
            return this.map(function() {
                return this.cloneNode(!0)
            })
        },
        hide: function() {
            return this.css("display", "none")
        },
        toggle: function(e) {
            return this.each(function() {
                var i = n(this);
                (e === t ? "none" == i.css("display") : e) ? i.show() : i.hide()
            })
        },
        prev: function(t) {
            return n(this.pluck("previousElementSibling")).filter(t || "*")
        },
        next: function(t) {
            return n(this.pluck("nextElementSibling")).filter(t || "*")
        },
        html: function(t) {
            return 0 in arguments ? this.each(function(e) {
                var i = this.innerHTML;
                n(this).empty().append(J(this, t, e, i))
            }) : 0 in this ? this[0].innerHTML : null
        },
        text: function(t) {
            return 0 in arguments ? this.each(function(e) {
                var n = J(this, t, e, this.textContent);
                this.textContent = null == n ? "" : "" + n
            }) : 0 in this ? this[0].textContent : null
        },
        attr: function(n, i) {
            var r;
            return "string" != typeof n || 1 in arguments ? this.each(function(t) {
                if (1 === this.nodeType)
                    if (D(n))
                        for (e in n)
                            X(this, e, n[e]);
                    else 
                        X(this, n, J(this, i, t, this.getAttribute(n)))
            }) : this.length && 1 === this[0].nodeType?!(r = this[0].getAttribute(n)) && n in this[0] ? this[0][n] : r : t
        },
        removeAttr: function(t) {
            return this.each(function() {
                1 === this.nodeType && t.split(" ").forEach(function(t) {
                    X(this, t)
                }, this)
            })
        },
        prop: function(t, e) {
            return t = P[t] || t, 1 in arguments ? this.each(function(n) {
                this[t] = J(this, e, n, this[t])
            }) : this[0] && this[0][t]
        },
        data: function(e, n) {
            var i = "data-" + e.replace(m, "-$1").toLowerCase(), r = 1 in arguments ? this.attr(i, n): this.attr(i);
            return null !== r ? Y(r) : t
        },
        val: function(t) {
            return 0 in arguments ? this.each(function(e) {
                this.value = J(this, t, e, this.value)
            }) : this[0] && (this[0].multiple ? n(this[0]).find("option").filter(function() {
                return this.selected
            }).pluck("value") : this[0].value)
        },
        offset: function(t) {
            if (t)
                return this.each(function(e) {
                    var i = n(this), r = J(this, t, e, i.offset()), o = i.offsetParent().offset(), s = {
                        top: r.top - o.top,
                        left: r.left - o.left
                    };
                    "static" == i.css("position") && (s.position = "relative"), i.css(s)
                });
            if (!this.length)
                return null;
            var e = this[0].getBoundingClientRect();
            return {
                left: e.left + window.pageXOffset,
                top: e.top + window.pageYOffset,
                width: Math.round(e.width),
                height: Math.round(e.height)
            }
        },
        css: function(t, i) {
            if (arguments.length < 2) {
                var r, o = this[0];
                if (!o)
                    return;
                if (r = getComputedStyle(o, ""), "string" == typeof t)
                    return o.style[C(t)] || r.getPropertyValue(t);
                if (A(t)) {
                    var s = {};
                    return n.each(t, function(t, e) {
                        s[e] = o.style[C(e)] || r.getPropertyValue(e)
                    }), s
                }
            }
            var a = "";
            if ("string" == L(t))
                i || 0 === i ? a = F(t) + ":" + H(t, i) : this.each(function() {
                    this.style.removeProperty(F(t))
                });
            else 
                for (e in t)
                    t[e] || 0 === t[e] ? a += F(e) + ":" + H(e, t[e]) + ";" : this.each(function() {
                        this.style.removeProperty(F(e))
                    });
            return this.each(function() {
                this.style.cssText += ";" + a
            })
        },
        index: function(t) {
            return t ? this.indexOf(n(t)[0]) : this.parent().children().indexOf(this[0])
        },
        hasClass: function(t) {
            return t ? r.some.call(this, function(t) {
                return this.test(W(t))
            }, q(t)) : !1
        },
        addClass: function(t) {
            return t ? this.each(function(e) {
                if ("className"in this) {
                    i = [];
                    var r = W(this), o = J(this, t, e, r);
                    o.split(/\s+/g).forEach(function(t) {
                        n(this).hasClass(t) || i.push(t)
                    }, this), i.length && W(this, r + (r ? " " : "") + i.join(" "))
                }
            }) : this
        },
        removeClass: function(e) {
            return this.each(function(n) {
                if ("className"in this) {
                    if (e === t)
                        return W(this, "");
                    i = W(this), J(this, e, n, i).split(/\s+/g).forEach(function(t) {
                        i = i.replace(q(t), " ")
                    }), W(this, i.trim())
                }
            })
        },
        toggleClass: function(e, i) {
            return e ? this.each(function(r) {
                var o = n(this), s = J(this, e, r, W(this));
                s.split(/\s+/g).forEach(function(e) {
                    (i === t?!o.hasClass(e) : i) ? o.addClass(e) : o.removeClass(e)
                })
            }) : this
        },
        scrollTop: function(e) {
            if (this.length) {
                var n = "scrollTop"in this[0];
                return e === t ? n ? this[0].scrollTop : this[0].pageYOffset : this.each(n ? function() {
                    this.scrollTop = e
                } : function() {
                    this.scrollTo(this.scrollX, e)
                })
            }
        },
        scrollLeft: function(e) {
            if (this.length) {
                var n = "scrollLeft"in this[0];
                return e === t ? n ? this[0].scrollLeft : this[0].pageXOffset : this.each(n ? function() {
                    this.scrollLeft = e
                } : function() {
                    this.scrollTo(e, this.scrollY)
                })
            }
        },
        position: function() {
            if (this.length) {
                var t = this[0], e = this.offsetParent(), i = this.offset(), r = d.test(e[0].nodeName) ? {
                    top: 0,
                    left: 0
                }
                : e.offset();
                return i.top -= parseFloat(n(t).css("margin-top")) || 0, i.left -= parseFloat(n(t).css("margin-left")) || 0, r.top += parseFloat(n(e[0]).css("border-top-width")) || 0, r.left += parseFloat(n(e[0]).css("border-left-width")) || 0, {
                    top: i.top - r.top,
                    left: i.left - r.left
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var t = this.offsetParent || a.body; t&&!d.test(t.nodeName) && "static" == n(t).css("position");)
                    t = t.offsetParent;
                return t
            })
        }
    }, n.fn.detach = n.fn.remove, ["width", "height"].forEach(function(e) {
        var i = e.replace(/./, function(t) {
            return t[0].toUpperCase()
        });
        n.fn[e] = function(r) {
            var o, s = this[0];
            return r === t ? _(s) ? s["inner" + i] : $(s) ? s.documentElement["scroll" + i] : (o = this.offset()) && o[e] : this.each(function(t) {
                s = n(this), s.css(e, J(this, r, t, s[e]()))
            })
        }
    }), v.forEach(function(t, e) {
        var i = e%2;
        n.fn[t] = function() {
            var t, o, r = n.map(arguments, function(e) {
                return t = L(e), "object" == t || "array" == t || null == e ? e : T.fragment(e)
            }), s = this.length > 1;
            return r.length < 1 ? this : this.each(function(t, u) {
                o = i ? u : u.parentNode, u = 0 == e ? u.nextSibling : 1 == e ? u.firstChild : 2 == e ? u : null;
                var f = n.contains(a.documentElement, o);
                r.forEach(function(t) {
                    if (s)
                        t = t.cloneNode(!0);
                    else if (!o)
                        return n(t).remove();
                    o.insertBefore(t, u), f && G(t, function(t) {
                        null == t.nodeName || "SCRIPT" !== t.nodeName.toUpperCase() || t.type && "text/javascript" !== t.type || t.src || window.eval.call(window, t.innerHTML)
                    })
                })
            })
        }, n.fn[i ? t + "To": "insert" + (e ? "Before" : "After")] = function(e) {
            return n(e)[t](this), this
        }
    }), T.Z.prototype = n.fn, T.uniq = N, T.deserializeValue = Y, n.zepto = T, n
}();
window.Zepto = Zepto, void 0 === window.$ && (window.$ = Zepto), function(t) {
    function l(t) {
        return t._zid || (t._zid = e++)
    }
    function h(t, e, n, i) {
        if (e = p(e), e.ns)
            var r = d(e.ns);
        return (s[l(t)] || []).filter(function(t) {
            return !(!t || e.e && t.e != e.e || e.ns&&!r.test(t.ns) || n && l(t.fn) !== l(n) || i && t.sel != i)
        })
    }
    function p(t) {
        var e = ("" + t).split(".");
        return {
            e: e[0],
            ns: e.slice(1).sort().join(" ")
        }
    }
    function d(t) {
        return new RegExp("(?:^| )" + t.replace(" ", " .* ?") + "(?: |$)")
    }
    function m(t, e) {
        return t.del&&!u && t.e in f||!!e
    }
    function g(t) {
        return c[t] || u && f[t] || t
    }
    function v(e, i, r, o, a, u, f) {
        var h = l(e), d = s[h] || (s[h] = []);
        i.split(/\s/).forEach(function(i) {
            if ("ready" == i)
                return t(document).ready(r);
            var s = p(i);
            s.fn = r, s.sel = a, s.e in c && (r = function(e) {
                var n = e.relatedTarget;
                return !n || n !== this&&!t.contains(this, n) ? s.fn.apply(this, arguments) : void 0
            }), s.del = u;
            var l = u || r;
            s.proxy = function(t) {
                if (t = j(t), !t.isImmediatePropagationStopped()) {
                    t.data = o;
                    var i = l.apply(e, t._args == n ? [t] : [t].concat(t._args));
                    return i===!1 && (t.preventDefault(), t.stopPropagation()), i
                }
            }, s.i = d.length, d.push(s), "addEventListener"in e && e.addEventListener(g(s.e), s.proxy, m(s, f))
        })
    }
    function y(t, e, n, i, r) {
        var o = l(t);
        (e || "").split(/\s/).forEach(function(e) {
            h(t, e, n, i).forEach(function(e) {
                delete s[o][e.i], "removeEventListener"in t && t.removeEventListener(g(e.e), e.proxy, m(e, r))
            })
        })
    }
    function j(e, i) {
        return (i ||!e.isDefaultPrevented) && (i || (i = e), t.each(E, function(t, n) {
            var r = i[t];
            e[t] = function() {
                return this[n] = x, r && r.apply(i, arguments)
            }, e[n] = b
        }), (i.defaultPrevented !== n ? i.defaultPrevented : "returnValue"in i ? i.returnValue===!1 : i.getPreventDefault && i.getPreventDefault()) && (e.isDefaultPrevented = x)), e
    }
    function S(t) {
        var e, i = {
            originalEvent: t
        };
        for (e in t)
            w.test(e) || t[e] === n || (i[e] = t[e]);
        return j(i, t)
    }
    var n, e = 1, i = Array.prototype.slice, r = t.isFunction, o = function(t) {
        return "string" == typeof t
    }, s = {}, a = {}, u = "onfocusin"in window, f = {
        focus: "focusin",
        blur: "focusout"
    }, c = {
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    };
    a.click = a.mousedown = a.mouseup = a.mousemove = "MouseEvents", t.event = {
        add: v,
        remove: y
    }, t.proxy = function(e, n) {
        var s = 2 in arguments && i.call(arguments, 2);
        if (r(e)) {
            var a = function() {
                return e.apply(n, s ? s.concat(i.call(arguments)) : arguments)
            };
            return a._zid = l(e), a
        }
        if (o(n))
            return s ? (s.unshift(e[n], e), t.proxy.apply(null, s)) : t.proxy(e[n], e);
        throw new TypeError("expected function")
    }, t.fn.bind = function(t, e, n) {
        return this.on(t, e, n)
    }, t.fn.unbind = function(t, e) {
        return this.off(t, e)
    }, t.fn.one = function(t, e, n, i) {
        return this.on(t, e, n, i, 1)
    };
    var x = function() {
        return !0
    }, b = function() {
        return !1
    }, w = /^([A-Z]|returnValue$|layer[XY]$)/, E = {
        preventDefault: "isDefaultPrevented",
        stopImmediatePropagation: "isImmediatePropagationStopped",
        stopPropagation: "isPropagationStopped"
    };
    t.fn.delegate = function(t, e, n) {
        return this.on(e, t, n)
    }, t.fn.undelegate = function(t, e, n) {
        return this.off(e, t, n)
    }, t.fn.live = function(e, n) {
        return t(document.body).delegate(this.selector, e, n), this
    }, t.fn.die = function(e, n) {
        return t(document.body).undelegate(this.selector, e, n), this
    }, t.fn.on = function(e, s, a, u, f) {
        var c, l, h = this;
        return e&&!o(e) ? (t.each(e, function(t, e) {
            h.on(t, s, a, e, f)
        }), h) : (o(s) || r(u) || u===!1 || (u = a, a = s, s = n), (r(a) || a===!1) && (u = a, a = n), u===!1 && (u = b), h.each(function(n, r) {
            f && (c = function(t) {
                return y(r, t.type, u), u.apply(this, arguments)
            }), s && (l = function(e) {
                var n, o = t(e.target).closest(s, r).get(0);
                return o && o !== r ? (n = t.extend(S(e), {
                    currentTarget: o,
                    liveFired: r
                }), (c || u).apply(o, [n].concat(i.call(arguments, 1)))) : void 0
            }), v(r, e, u, a, s, l || c)
        }))
    }, t.fn.off = function(e, i, s) {
        var a = this;
        return e&&!o(e) ? (t.each(e, function(t, e) {
            a.off(t, i, e)
        }), a) : (o(i) || r(s) || s===!1 || (s = i, i = n), s===!1 && (s = b), a.each(function() {
            y(this, e, s, i)
        }))
    }, t.fn.trigger = function(e, n) {
        return e = o(e) || t.isPlainObject(e) ? t.Event(e) : j(e), e._args = n, this.each(function() {
            e.type in f && "function" == typeof this[e.type] ? this[e.type]() : "dispatchEvent"in this ? this.dispatchEvent(e) : t(this).triggerHandler(e, n)
        })
    }, t.fn.triggerHandler = function(e, n) {
        var i, r;
        return this.each(function(s, a) {
            i = S(o(e) ? t.Event(e) : e), i._args = n, i.target = a, t.each(h(a, e.type || e), function(t, e) {
                return r = e.proxy(i), i.isImmediatePropagationStopped()?!1 : void 0
            })
        }), r
    }, "focusin focusout focus blur load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select keydown keypress keyup error".split(" ").forEach(function(e) {
        t.fn[e] = function(t) {
            return 0 in arguments ? this.bind(e, t) : this.trigger(e)
        }
    }), t.Event = function(t, e) {
        o(t) || (e = t, t = e.type);
        var n = document.createEvent(a[t] || "Events"), i=!0;
        if (e)
            for (var r in e)
                "bubbles" == r ? i=!!e[r] : n[r] = e[r];
        return n.initEvent(t, i, !0), j(n)
    }
}(Zepto), function(t) {
    function h(e, n, i) {
        var r = t.Event(n);
        return t(e).trigger(r, i), !r.isDefaultPrevented()
    }
    function p(t, e, i, r) {
        return t.global ? h(e || n, i, r) : void 0
    }
    function d(e) {
        e.global && 0 === t.active++&&p(e, null, "ajaxStart")
    }
    function m(e) {
        e.global&&!--t.active && p(e, null, "ajaxStop")
    }
    function g(t, e) {
        var n = e.context;
        return e.beforeSend.call(n, t, e)===!1 || p(e, n, "ajaxBeforeSend", [t, e])===!1?!1 : void p(e, n, "ajaxSend", [t, e])
    }
    function v(t, e, n, i) {
        var r = n.context, o = "success";
        n.success.call(r, t, o, e), i && i.resolveWith(r, [t, o, e]), p(n, r, "ajaxSuccess", [e, n, t]), x(o, e, n)
    }
    function y(t, e, n, i, r) {
        var o = i.context;
        i.error.call(o, n, e, t), r && r.rejectWith(o, [n, e, t]), p(i, o, "ajaxError", [n, i, t || e]), x(e, n, i)
    }
    function x(t, e, n) {
        var i = n.context;
        n.complete.call(i, e, t), p(n, i, "ajaxComplete", [e, n]), m(n)
    }
    function b() {}
    function w(t) {
        return t && (t = t.split(";", 2)[0]), t && (t == f ? "html" : t == u ? "json" : s.test(t) ? "script" : a.test(t) && "xml") || "text"
    }
    function E(t, e) {
        return "" == e ? t : (t + "&" + e).replace(/[&?]{1,2}/, "?")
    }
    function j(e) {
        e.processData && e.data && "string" != t.type(e.data) && (e.data = t.param(e.data, e.traditional)), !e.data || e.type && "GET" != e.type.toUpperCase() || (e.url = E(e.url, e.data), e.data = void 0)
    }
    function S(e, n, i, r) {
        return t.isFunction(n) && (r = i, i = n, n = void 0), t.isFunction(i) || (r = i, i = void 0), {
            url: e,
            data: n,
            success: i,
            dataType: r
        }
    }
    function C(e, n, i, r) {
        var o, s = t.isArray(n), a = t.isPlainObject(n);
        t.each(n, function(n, u) {
            o = t.type(u), r && (n = i ? r : r + "[" + (a || "object" == o || "array" == o ? n : "") + "]"), !r && s ? e.add(u.name, u.value) : "array" == o ||!i && "object" == o ? C(e, u, i, n) : e.add(n, u)
        })
    }
    var i, r, e = 0, n = window.document, o = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, s = /^(?:text|application)\/javascript/i, a = /^(?:text|application)\/xml/i, u = "application/json", f = "text/html", c = /^\s*$/, l = n.createElement("a");
    l.href = window.location.href, t.active = 0, t.ajaxJSONP = function(i, r) {
        if (!("type"in i))
            return t.ajax(i);
        var f, h, o = i.jsonpCallback, s = (t.isFunction(o) ? o() : o) || "jsonp" + ++e, a = n.createElement("script"), u = window[s], c = function(e) {
            t(a).triggerHandler("error", e || "abort")
        }, l = {
            abort: c
        };
        return r && r.promise(l), t(a).on("load error", function(e, n) {
            clearTimeout(h), t(a).off().remove(), "error" != e.type && f ? v(f[0], l, i, r) : y(null, n || "error", l, i, r), window[s] = u, f && t.isFunction(u) && u(f[0]), u = f = void 0
        }), g(l, i)===!1 ? (c("abort"), l) : (window[s] = function() {
            f = arguments
        }, a.src = i.url.replace(/\?(.+)=\?/, "?$1=" + s), n.head.appendChild(a), i.timeout > 0 && (h = setTimeout(function() {
            c("timeout")
        }, i.timeout)), l)
    }, t.ajaxSettings = {
        type: "GET",
        beforeSend: b,
        success: b,
        error: b,
        complete: b,
        context: null,
        global: !0,
        xhr: function() {
            return new window.XMLHttpRequest
        },
        accepts: {
            script: "text/javascript, application/javascript, application/x-javascript",
            json: u,
            xml: "application/xml, text/xml",
            html: f,
            text: "text/plain"
        },
        crossDomain: !1,
        timeout: 0,
        processData: !0,
        cache: !0
    }, t.ajax = function(e) {
        var a, o = t.extend({}, e || {}), s = t.Deferred && t.Deferred();
        for (i in t.ajaxSettings)
            void 0 === o[i] && (o[i] = t.ajaxSettings[i]);
        d(o), o.crossDomain || (a = n.createElement("a"), a.href = o.url, a.href = a.href, o.crossDomain = l.protocol + "//" + l.host != a.protocol + "//" + a.host), o.url || (o.url = window.location.toString()), j(o);
        var u = o.dataType, f = /\?.+=\?/.test(o.url);
        if (f && (u = "jsonp"), o.cache!==!1 && (e && e.cache===!0 || "script" != u && "jsonp" != u) || (o.url = E(o.url, "_=" + Date.now())), "jsonp" == u)
            return f || (o.url = E(o.url, o.jsonp ? o.jsonp + "=?" : o.jsonp===!1 ? "" : "callback=?")), t.ajaxJSONP(o, s);
        var C, h = o.accepts[u], p = {}, m = function(t, e) {
            p[t.toLowerCase()] = [t, e]
        }, x = /^([\w-]+:)\/\//.test(o.url) ? RegExp.$1: window.location.protocol, S = o.xhr(), T = S.setRequestHeader;
        if (s && s.promise(S), o.crossDomain || m("X-Requested-With", "XMLHttpRequest"), m("Accept", h || "*/*"), (h = o.mimeType || h) && (h.indexOf(",")>-1 && (h = h.split(",", 2)[0]), S.overrideMimeType && S.overrideMimeType(h)), (o.contentType || o.contentType!==!1 && o.data && "GET" != o.type.toUpperCase()) && m("Content-Type", o.contentType || "application/x-www-form-urlencoded"), o.headers)
            for (r in o.headers)
                m(r, o.headers[r]);
        if (S.setRequestHeader = m, S.onreadystatechange = function() {
            if (4 == S.readyState) {
                S.onreadystatechange = b, clearTimeout(C);
                var e, n=!1;
                if (S.status >= 200 && S.status < 300 || 304 == S.status || 0 == S.status && "file:" == x) {
                    u = u || w(o.mimeType || S.getResponseHeader("content-type")), e = S.responseText;
                    try {
                        "script" == u ? (1, eval)(e) : "xml" == u ? e = S.responseXML : "json" == u && (e = c.test(e) ? null : t.parseJSON(e))
                    } catch (i) {
                        n = i
                    }
                    n ? y(n, "parsererror", S, o, s) : v(e, S, o, s)
                } else 
                    y(S.statusText || null, S.status ? "error" : "abort", S, o, s)
            }
        }, g(S, o)===!1)
            return S.abort(), y(null, "abort", S, o, s), S;
        if (o.xhrFields)
            for (r in o.xhrFields)
                S[r] = o.xhrFields[r];
        var N = "async"in o ? o.async: !0;
        S.open(o.type, o.url, N, o.username, o.password);
        for (r in p)
            T.apply(S, p[r]);
        return o.timeout > 0 && (C = setTimeout(function() {
            S.onreadystatechange = b, S.abort(), y(null, "timeout", S, o, s)
        }, o.timeout)), S.send(o.data ? o.data : null), S
    }, t.get = function() {
        return t.ajax(S.apply(null, arguments))
    }, t.post = function() {
        var e = S.apply(null, arguments);
        return e.type = "POST", t.ajax(e)
    }, t.getJSON = function() {
        var e = S.apply(null, arguments);
        return e.dataType = "json", t.ajax(e)
    }, t.fn.load = function(e, n, i) {
        if (!this.length)
            return this;
        var a, r = this, s = e.split(/\s/), u = S(e, n, i), f = u.success;
        return s.length > 1 && (u.url = s[0], a = s[1]), u.success = function(e) {
            r.html(a ? t("<div>").html(e.replace(o, "")).find(a) : e), f && f.apply(r, arguments)
        }, t.ajax(u), this
    };
    var T = encodeURIComponent;
    t.param = function(e, n) {
        var i = [];
        return i.add = function(e, n) {
            t.isFunction(n) && (n = n()), null == n && (n = ""), this.push(T(e) + "=" + T(n))
        }, C(i, e, n), i.join("&").replace(/%20/g, "+")
    }
}(Zepto), function(t) {
    t.fn.serializeArray = function() {
        var e, n, i = [], r = function(t) {
            return t.forEach ? t.forEach(r) : void i.push({
                name: e,
                value: t
            })
        };
        return this[0] && t.each(this[0].elements, function(i, o) {
            n = o.type, e = o.name, e && "fieldset" != o.nodeName.toLowerCase()&&!o.disabled && "submit" != n && "reset" != n && "button" != n && "file" != n && ("radio" != n && "checkbox" != n || o.checked) && r(t(o).val())
        }), i
    }, t.fn.serialize = function() {
        var t = [];
        return this.serializeArray().forEach(function(e) {
            t.push(encodeURIComponent(e.name) + "=" + encodeURIComponent(e.value))
        }), t.join("&")
    }, t.fn.submit = function(e) {
        if (0 in arguments)
            this.bind("submit", e);
        else if (this.length) {
            var n = t.Event("submit");
            this.eq(0).trigger(n), n.isDefaultPrevented() || this.get(0).submit()
        }
        return this
    }
}(Zepto), function(t) {
    "__proto__"in{}
    || t.extend(t.zepto, {
        Z: function(e, n) {
            return e = e || [], t.extend(e, t.fn), e.selector = n || "", e.__Z=!0, e
        },
        isZ: function(e) {
            return "array" === t.type(e) && "__Z"in e
        }
    });
    try {
        getComputedStyle(void 0)
    } catch (e) {
        var n = getComputedStyle;
        window.getComputedStyle = function(t) {
            try {
                return n(t)
            } catch (e) {
                return null
            }
        }
    }
}(Zepto);;
/*!
 * =====================================================
 * Mui v2.3.0 (https://github.com/dcloudio/mui)
 * =====================================================
 */
var mui = function(a, b) {
    var c = /complete|loaded|interactive/, d = /^#([\w-]+)$/, e = /^\.([\w-]+)$/, f = /^[\w-]+$/, g = /translate(?:3d)?\((.+?)\)/, h = /matrix(3d)?\((.+?)\)/, i = function(b, c) {
        if (c = c || a, !b)
            return j();
        if ("object" == typeof b)
            return j([b], null);
        if ("function" == typeof b)
            return i.ready(b);
        if ("string" == typeof b)
            try {
                if (b = b.trim(), d.test(b)) {
                    var e = a.getElementById(RegExp.$1);
                    return j(e ? [e] : [])
                }
                return j(i.qsa(b, c), b)
            } catch (f) {}
        return j()
    }, j = function(a, b) {
        return a = a || [], Object.setPrototypeOf(a, i.fn), a.selector = b || "", a
    };
    i.uuid = 0, i.data = {}, i.extend = function() {
        var a, c, d, e, f, g, h = arguments[0] || {}, j = 1, k = arguments.length, l=!1;
        for ("boolean" == typeof h && (l = h, h = arguments[j] || {}, j++), "object" == typeof h || i.isFunction(h) || (h = {}), j === k && (h = this, j--); k > j; j++)
            if (null != (a = arguments[j]))
                for (c in a)
                    d = h[c], e = a[c], h !== e && (l && e && (i.isPlainObject(e) || (f = i.isArray(e))) ? (f ? (f=!1, g = d && i.isArray(d) ? d : []) : g = d && i.isPlainObject(d) ? d : {}, h[c] = i.extend(l, g, e)) : e !== b && (h[c] = e));
        return h
    }, i.noop = function() {}, i.slice = [].slice, i.filter = [].filter, i.type = function(a) {
        return null == a ? String(a) : k[{}.toString.call(a)] || "object"
    }, i.isArray = Array.isArray || function(a) {
        return a instanceof Array
    }, i.isWindow = function(a) {
        return null != a && a === a.window
    }, i.isObject = function(a) {
        return "object" === i.type(a)
    }, i.isPlainObject = function(a) {
        return i.isObject(a)&&!i.isWindow(a) && Object.getPrototypeOf(a) === Object.prototype
    }, i.isEmptyObject = function(a) {
        for (var c in a)
            if (c !== b)
                return !1;
        return !0
    }, i.isFunction = function(a) {
        return "function" === i.type(a)
    }, i.qsa = function(b, c) {
        return c = c || a, i.slice.call(e.test(b) ? c.getElementsByClassName(RegExp.$1) : f.test(b) ? c.getElementsByTagName(b) : c.querySelectorAll(b))
    }, i.ready = function(b) {
        return c.test(a.readyState) ? b(i) : a.addEventListener("DOMContentLoaded", function() {
            b(i)
        }, !1), this
    }, i.map = function(a, b) {
        var c, d, e, f = [];
        if ("number" == typeof a.length)
            for (d = 0, len = a.length; d < len; d++)
                c = b(a[d], d), null != c && f.push(c);
        else 
            for (e in a)
                c = b(a[e], e), null != c && f.push(c);
        return f.length > 0 ? [].concat.apply([], f) : f
    }, i.each = function(a, b, c) {
        if (!a)
            return this;
        if ("number" == typeof a.length)
            [].every.call(a, function(a, c) {
            return b.call(a, c, a)!==!1
        });
        else 
            for (var d in a)
                if (c) {
                    if (a.hasOwnProperty(d) && b.call(a[d], d, a[d])===!1)
                        return a
                } else if (b.call(a[d], d, a[d])===!1)
                    return a;
        return this
    }, i.focus = function(a) {
        i.os.ios ? setTimeout(function() {
            a.focus()
        }, 10) : a.focus()
    }, i.trigger = function(a, b, c) {
        return a.dispatchEvent(new CustomEvent(b, {
            detail: c,
            bubbles: !0,
            cancelable: !0
        })), this
    }, i.getStyles = function(a, b) {
        var c = a.ownerDocument.defaultView.getComputedStyle(a, null);
        return b ? c.getPropertyValue(b) || c[b] : c
    }, i.parseTranslate = function(a, b) {
        var c = a.match(g || "");
        return c && c[1] || (c = ["", "0,0,0"]), c = c[1].split(","), c = {
            x: parseFloat(c[0]),
            y: parseFloat(c[1]),
            z: parseFloat(c[2])
        }, b && c.hasOwnProperty(b) ? c[b] : c
    }, i.parseTranslateMatrix = function(a, b) {
        var c = a.match(h), d = c && c[1];
        c ? (c = c[2].split(","), "3d" === d ? c = c.slice(12, 15) : (c.push(0), c = c.slice(4, 7))) : c = [0, 0, 0];
        var e = {
            x: parseFloat(c[0]),
            y: parseFloat(c[1]),
            z: parseFloat(c[2])
        };
        return b && e.hasOwnProperty(b) ? e[b] : e
    }, i.hooks = {}, i.addAction = function(a, b) {
        var c = i.hooks[a];
        return c || (c = []), b.index = b.index || 1e3, c.push(b), c.sort(function(a, b) {
            return a.index - b.index
        }), i.hooks[a] = c, i.hooks[a]
    }, i.doAction = function(a, b) {
        i.isFunction(b) ? i.each(i.hooks[a], b) : i.each(i.hooks[a], function(a, b) {
            return !b.handle()
        })
    }, i.later = function(a, b, c, d) {
        b = b || 0;
        var e, f, g = a, h = d;
        return "string" == typeof a && (g = c[a]), e = function() {
            g.apply(c, i.isArray(h) ? h : [h])
        }, f = setTimeout(e, b), {
            id: f,
            cancel: function() {
                clearTimeout(f)
            }
        }
    }, i.now = Date.now || function() {
        return + new Date
    };
    var k = {};
    return i.each(["Boolean", "Number", "String", "Function", "Array", "Date", "RegExp", "Object", "Error"], function(a, b) {
        k["[object " + b + "]"] = b.toLowerCase()
    }), window.JSON && (i.parseJSON = JSON.parse), i.fn = {
        each: function(a) {
            return [].every.call(this, function(b, c) {
                return a.call(b, c, b)!==!1
            }), this
        }
    }, "function" == typeof define && define.amd && define("mui", [], function() {
        return i
    }), i
}(document);
!function(a, b) {
    function c(c) {
        this.os = {};
        var d = [function() {
            var a = c.match(/(MicroMessenger)\/([\d\.]+)/i);
            return a && (this.os.wechat = {
                version: a[2].replace(/_/g, ".")
            }), !1
        }, function() {
            var a = c.match(/(Android);?[\s\/]+([\d.]+)?/);
            return a && (this.os.android=!0, this.os.version = a[2], this.os.isBadAndroid=!/Chrome\/\d/.test(b.navigator.appVersion)), this.os.android===!0
        }, function() {
            var a = c.match(/(iPhone\sOS)\s([\d_]+)/);
            if (a)
                this.os.ios = this.os.iphone=!0, this.os.version = a[2].replace(/_/g, ".");
            else {
                var b = c.match(/(iPad).*OS\s([\d_]+)/);
                b && (this.os.ios = this.os.ipad=!0, this.os.version = b[2].replace(/_/g, "."))
            }
            return this.os.ios===!0
        }
        ];
        [].every.call(d, function(b) {
            return !b.call(a)
        })
    }
    c.call(a, navigator.userAgent)
}(mui, window), function(a, b) {
    function c(c) {
        this.os = this.os || {};
        var d = c.match(/Html5Plus/i);
        d && (this.os.plus=!0, a(function() {
            b.body.classList.add("mui-plus")
        }), c.match(/StreamApp/i) && (this.os.stream=!0, a(function() {
            b.body.classList.add("mui-plus-stream")
        })))
    }
    c.call(a, navigator.userAgent)
}(mui, document), function(a, b, c) {
    a.targets = {}, a.targetHandles = [], a.registerTarget = function(b) {
        return b.index = b.index || 1e3, a.targetHandles.push(b), a.targetHandles.sort(function(a, b) {
            return a.index - b.index
        }), a.targetHandles
    }, b.addEventListener("touchstart", function(b) {
        for (var d = b.target, e = {}; d && d !== c; d = d.parentNode) {
            var f=!1;
            if (a.each(a.targetHandles, function(c, g) {
                var h = g.name;
                f || e[h] ||!g.hasOwnProperty("handle") ? e[h] || g.isReset!==!1 && (a.targets[h]=!1) : (a.targets[h] = g.handle(b, d), a.targets[h] && (e[h]=!0, g.isContinue!==!0 && (f=!0)))
            }), f)
                break
        }
    })
}(mui, window, document), function(a) {
    String.prototype.trim === a && (String.prototype.trim = function() {
        return this.replace(/^\s+|\s+$/g, "")
    }), Object.setPrototypeOf = Object.setPrototypeOf || function(a, b) {
        return a.__proto__ = b, a
    }
}(), function() {
    function a(a, b) {
        b = b || {
            bubbles: !1,
            cancelable: !1,
            detail: void 0
        };
        var c = document.createEvent("Events"), d=!0;
        for (var e in b)
            "bubbles" === e ? d=!!b[e] : c[e] = b[e];
        return c.initEvent(a, d, !0), c
    }
    "undefined" == typeof window.CustomEvent && (a.prototype = window.Event.prototype, window.CustomEvent = a)
}(), function(a) {
    "classList"in a.documentElement ||!Object.defineProperty || "undefined" == typeof HTMLElement || Object.defineProperty(HTMLElement.prototype, "classList", {
        get: function() {
            function a(a) {
                return function(c) {
                    var d = b.className.split(/\s+/), e = d.indexOf(c);
                    a(d, e, c), b.className = d.join(" ")
                }
            }
            var b = this, c = {
                add: a(function(a, b, c) {
                    ~b || a.push(c)
                }),
                remove: a(function(a, b) {
                    ~b && a.splice(b, 1)
                }),
                toggle: a(function(a, b, c) {
                    ~b ? a.splice(b, 1) : a.push(c)
                }),
                contains: function(a) {
                    return !!~b.className.split(/\s+/).indexOf(a)
                },
                item: function(a) {
                    return b.className.split(/\s+/)[a] || null
                }
            };
            return Object.defineProperty(c, "length", {
                get: function() {
                    return b.className.split(/\s+/).length
                }
            }), c
        }
    })
}(document), function(a) {
    if (!a.requestAnimationFrame) {
        var b = 0;
        a.requestAnimationFrame = a.webkitRequestAnimationFrame || function(c, d) {
            var e = (new Date).getTime(), f = Math.max(0, 16.7 - (e - b)), g = a.setTimeout(function() {
                c(e + f)
            }, f);
            return b = e + f, g
        }, a.cancelAnimationFrame = a.webkitCancelAnimationFrame || a.webkitCancelRequestAnimationFrame || function(a) {
            clearTimeout(a)
        }
    }
}(window), function(a, b, c) {
    if (!b.FastClick) {
        var d = function(a, b) {
            return "LABEL" === b.tagName && b.parentNode && (b = b.parentNode.querySelector("input")), !b || "radio" !== b.type && "checkbox" !== b.type || b.disabled?!1 : b
        };
        a.registerTarget({
            name: c,
            index: 40,
            handle: d,
            target: !1
        });
        var e = function(c) {
            var d = a.targets.click;
            if (d) {
                var e, f;
                document.activeElement && document.activeElement !== d && document.activeElement.blur(), f = c.detail.gesture.changedTouches[0], e = document.createEvent("MouseEvents"), e.initMouseEvent("click", !0, !0, b, 1, f.screenX, f.screenY, f.clientX, f.clientY, !1, !1, !1, !1, 0, null), e.forwardedTouchEvent=!0, d.dispatchEvent(e), c.detail && c.detail.gesture.preventDefault()
            }
        };
        b.addEventListener("tap", e), b.addEventListener("doubletap", e), b.addEventListener("click", function(b) {
            return a.targets.click&&!b.forwardedTouchEvent ? (b.stopImmediatePropagation ? b.stopImmediatePropagation() : b.propagationStopped=!0, b.stopPropagation(), b.preventDefault(), !1) : void 0
        }, !0)
    }
}(mui, window, "click"), function(a, b) {
    a(function() {
        if (a.os.ios) {
            var c = "mui-focusin", d = "mui-bar-tab", e = "mui-bar-footer", f = "mui-bar-footer-secondary", g = "mui-bar-footer-secondary-tab";
            b.addEventListener("focusin", function(h) {
                if (!(a.os.plus && window.plus && plus.webview.currentWebview().children().length > 0)) {
                    var i = h.target;
                    if (i.tagName && "INPUT" === i.tagName && ("text" === i.type || "search" === i.type || "number" === i.type)) {
                        if (i.disabled || i.readOnly)
                            return;
                        b.body.classList.add(c);
                        for (var j=!1; i && i !== b; i = i.parentNode) {
                            var k = i.classList;
                            if (k && k.contains(d) || k.contains(e) || k.contains(f) || k.contains(g)) {
                                j=!0;
                                break
                            }
                        }
                        if (j) {
                            var l = b.body.scrollHeight, m = b.body.scrollLeft;
                            setTimeout(function() {
                                window.scrollTo(m, l)
                            }, 20)
                        }
                    }
                }
            }), b.addEventListener("focusout", function(a) {
                var d = b.body.classList;
                d.contains(c) && (d.remove(c), setTimeout(function() {
                    window.scrollTo(b.body.scrollLeft, b.body.scrollTop)
                }, 20))
            })
        }
    })
}(mui, document), function(a) {
    a.namespace = "mui", a.classNamePrefix = a.namespace + "-", a.classSelectorPrefix = "." + a.classNamePrefix, a.className = function(b) {
        return a.classNamePrefix + b
    }, a.classSelector = function(b) {
        return b.replace(/\./g, a.classSelectorPrefix)
    }, a.eventName = function(b, c) {
        return b + (a.namespace ? "." + a.namespace : "") + (c ? "." + c : "")
    }
}(mui), function(a) {
    var b = 1, c = {}, d = {
        preventDefault: "isDefaultPrevented",
        stopImmediatePropagation: "isImmediatePropagationStopped",
        stopPropagation: "isPropagationStopped"
    }, e = function() {
        return !0
    }, f = function() {
        return !1
    }, g = function(b, c) {
        return b.detail ? b.detail.currentTarget = c : b.detail = {
            currentTarget: c
        }, a.each(d, function(a, c) {
            var d = b[a];
            b[a] = function() {
                return this[c] = e, d && d.apply(b, arguments)
            }, b[c] = f
        }, !0), b
    }, h = function(a) {
        return a && (a._mid || (a._mid = b++))
    }, i = {}, j = function(b, d, e, f) {
        return function(e) {
            for (var f = c[b._mid][d], h = [], i = e.target, j = {}; i && i !== document && i !== b && (!~["click", "tap", "doubletap", "longtap", "hold"].indexOf(d) ||!i.disabled&&!i.classList.contains("mui-disabled")); i = i.parentNode) {
                var k = {};
                a.each(f, function(c, d) {
                    j[c] || (j[c] = a.qsa(c, b)), j[c]&&~j[c].indexOf(i) && (k[c] || (k[c] = d))
                }, !0), a.isEmptyObject(k) || h.push({
                    element: i,
                    handlers: k
                })
            }
            j = null, e = g(e), a.each(h, function(b, c) {
                i = c.element;
                var f = i.tagName;
                return "tap" === d && "INPUT" !== f && "TEXTAREA" !== f && "SELECT" !== f && (e.preventDefault(), e.detail && e.detail.gesture && e.detail.gesture.preventDefault()), a.each(c.handlers, function(b, c) {
                    a.each(c, function(a, b) {
                        b.call(i, e)===!1 && (e.preventDefault(), e.stopPropagation())
                    }, !0)
                }, !0), e.isPropagationStopped()?!1 : void 0
            }, !0)
        }
    }, k = function(a, b) {
        var c = i[h(a)], d=!1;
        if (c) {
            if (d = [], b) {
                var e = function(a) {
                    return a.type === b
                };
                return c.filter(e)
            }
            d = c
        }
        return d
    }, l = /^(INPUT|TEXTAREA|BUTTON|SELECT)$/;
    a.fn.on = function(b, d, e) {
        return this.each(function() {
            var f = this;
            h(f), h(e);
            var g=!1, k = c[f._mid] || (c[f._mid] = {}), m = k[b] || (k[b] = {});
            a.isEmptyObject(m) && (g=!0);
            var n = m[d] || (m[d] = []);
            if (n.push(e), g) {
                var o = i[h(f)];
                o || (o = []);
                var p = j(f, b, d, e);
                o.push(p), p.i = o.length - 1, p.type = b, i[h(f)] = o, f.addEventListener(b, p), "tap" === b && f.addEventListener("click", function(a) {
                    if (a.target) {
                        var b = a.target.tagName;
                        if (!l.test(b))
                            if ("A" === b) {
                                var c = a.target.href;
                                c&&~c.indexOf("tel:") || a.preventDefault()
                            } else 
                                a.preventDefault()
                    }
                })
            }
        })
    }, a.fn.off = function(b, d, e) {
        return this.each(function() {
            var f = h(this);
            if (b)
                if (d)
                    if (e) {
                        var g = c[f] && c[f][b] && c[f][b][d];
                        a.each(g, function(a, b) {
                            return h(b) === h(e) ? (g.splice(a, 1), !1) : void 0
                        }, !0)
                    } else 
                        c[f] && c[f][b] && delete c[f][b][d];
                else 
                    c[f] && delete c[f][b];
            else 
                c[f] && delete c[f];
            c[f] ? (!c[f][b] || a.isEmptyObject(c[f][b])) && k(this, b).forEach(function(a) {
                this.removeEventListener(a.type, a), delete i[f][a.i]
            }.bind(this)) : k(this).forEach(function(a) {
                this.removeEventListener(a.type, a), delete i[f][a.i]
            }.bind(this))
        })
    }
}(mui), function(a, b) {
    a.EVENT_START = "touchstart", a.EVENT_MOVE = "touchmove", a.EVENT_END = "touchend", a.EVENT_CANCEL = "touchcancel", a.EVENT_CLICK = "click", a.gestures = {
        session: {}
    }, a.preventDefault = function(a) {
        a.preventDefault()
    }, a.stopPropagation = function(a) {
        a.stopPropagation()
    }, a.addGesture = function(b) {
        return a.addAction("gestures", b)
    };
    var c = Math.round, d = Math.abs, e = Math.sqrt, f = (Math.atan, Math.atan2), g = function(a, b, c) {
        c || (c = ["x", "y"]);
        var d = b[c[0]] - a[c[0]], f = b[c[1]] - a[c[1]];
        return e(d * d + f * f)
    }, h = function(a, b) {
        if (a.length >= 2 && b.length >= 2) {
            var c = ["pageX", "pageY"];
            return g(b[1], b[0], c) / g(a[1], a[0], c)
        }
        return 1
    }, i = function(a, b, c) {
        c || (c = ["x", "y"]);
        var d = b[c[0]] - a[c[0]], e = b[c[1]] - a[c[1]];
        return 180 * f(e, d) / Math.PI
    }, j = function(a, b) {
        return a === b ? "" : d(a) >= d(b) ? a > 0 ? "left" : "right" : b > 0 ? "up" : "down"
    }, k = function(a, b) {
        var c = ["pageX", "pageY"];
        return i(b[1], b[0], c) - i(a[1], a[0], c)
    }, l = function(a, b, c) {
        return {
            x: b / a || 0,
            y: c / a || 0
        }
    }, m = function(b, c) {
        a.gestures.stoped || a.doAction("gestures", function(d, e) {
            a.gestures.stoped || a.options.gestureConfig[e.name]!==!1 && e.handle(b, c)
        })
    }, n = function(a, b) {
        for (; a;) {
            if (a == b)
                return !0;
            a = a.parentNode
        }
        return !1
    }, o = function(a, b, c) {
        for (var d = [], e = [], f = 0; f < a.length;) {
            var g = b ? a[f][b]: a[f];
            e.indexOf(g) < 0 && d.push(a[f]), e[f] = g, f++
        }
        return c && (d = b ? d.sort(function(a, c) {
            return a[b] > c[b]
        }) : d.sort()), d
    }, p = function(a) {
        var b = a.length;
        if (1 === b)
            return {
                x: c(a[0].pageX),
                y: c(a[0].pageY)
            };
        for (var d = 0, e = 0, f = 0; b > f;)
            d += a[f].pageX, e += a[f].pageY, f++;
        return {
            x: c(d / b),
            y: c(e / b)
        }
    }, q = function() {
        return a.options.gestureConfig.pinch
    }, r = function(b) {
        for (var d = [], e = 0; e < b.touches.length;)
            d[e] = {
                pageX: c(b.touches[e].pageX),
                pageY: c(b.touches[e].pageY)
            }, e++;
        return {
            timestamp: a.now(),
            gesture: b.gesture,
            touches: d,
            center: p(b.touches),
            deltaX: b.deltaX,
            deltaY: b.deltaY
        }
    }, s = function(b) {
        var c = a.gestures.session, d = b.center, e = c.offsetDelta || {}, f = c.prevDelta || {}, g = c.prevTouch || {};
        (b.gesture.type === a.EVENT_START || b.gesture.type === a.EVENT_END) && (f = c.prevDelta = {
            x: g.deltaX || 0,
            y: g.deltaY || 0
        }, e = c.offsetDelta = {
            x: d.x,
            y: d.y
        }), b.deltaX = f.x + (d.x - e.x), b.deltaY = f.y + (d.y - e.y)
    }, t = function(b) {
        var c = a.gestures.session, d = b.touches, e = d.length;
        c.firstTouch || (c.firstTouch = r(b)), q() && e > 1&&!c.firstMultiTouch ? c.firstMultiTouch = r(b) : 1 === e && (c.firstMultiTouch=!1);
        var f = c.firstTouch, l = c.firstMultiTouch, m = l ? l.center: f.center, n = b.center = p(d);
        b.timestamp = a.now(), b.deltaTime = b.timestamp - f.timestamp, b.angle = i(m, n), b.distance = g(m, n), s(b), b.offsetDirection = j(b.deltaX, b.deltaY), b.scale = l ? h(l.touches, d) : 1, b.rotation = l ? k(l.touches, d) : 0, v(b)
    }, u = 25, v = function(b) {
        var c, e, f, g, h = a.gestures.session, i = h.lastInterval || b, k = b.timestamp - i.timestamp;
        if (b.gesture.type != a.EVENT_CANCEL && (k > u || void 0 === i.velocity)) {
            var m = i.deltaX - b.deltaX, n = i.deltaY - b.deltaY, o = l(k, m, n);
            e = o.x, f = o.y, c = d(o.x) > d(o.y) ? o.x : o.y, g = j(m, n) || i.direction, h.lastInterval = b
        } else 
            c = i.velocity, e = i.velocityX, f = i.velocityY, g = i.direction;
        b.velocity = c, b.velocityX = e, b.velocityY = f, b.direction = g
    }, w = {}, x = function(b, c) {
        var d = a.slice.call(b.touches || b), e = b.type, f = [], g = [];
        if (e !== a.EVENT_START && e !== a.EVENT_MOVE || 1 !== d.length) {
            var h = 0, f = [], g = [], i = a.slice.call(b.changedTouches || b);
            c.target = b.target;
            var j = a.gestures.session.target || b.target;
            if (f = d.filter(function(a) {
                return n(a.target, j)
            }), e === a.EVENT_START)
                for (h = 0; h < f.length;)
                    w[f[h].identifier]=!0, h++;
            for (h = 0; h < i.length;)
                w[i[h].identifier] && g.push(i[h]), (e === a.EVENT_END || e === a.EVENT_CANCEL) && delete w[i[h].identifier], h++;
            if (!g.length)
                return !1
        } else 
            w[d[0].identifier]=!0, f = d, g = d, c.target = b.target;
        f = o(f.concat(g), "identifier", !0);
        var k = f.length, l = g.length;
        return e === a.EVENT_START && k - l === 0 && (c.isFirst=!0, a.gestures.touch = a.gestures.session = {
            target: b.target
        }), c.isFinal = (e === a.EVENT_END || e === a.EVENT_CANCEL) && k - l === 0, c.touches = f, c.changedTouches = g, !0
    }, y = function(b) {
        var c = {
            gesture: b
        }, d = x(b, c);
        d && (t(c), m(b, c), a.gestures.session.prevTouch = c)
    };
    b.addEventListener(a.EVENT_START, y), b.addEventListener(a.EVENT_MOVE, y), b.addEventListener(a.EVENT_END, y), b.addEventListener(a.EVENT_CANCEL, y), b.addEventListener(a.EVENT_CLICK, function(b) {
        (a.targets.popover && b.target === a.targets.popover || a.targets.tab || a.targets.offcanvas || a.targets.modal) && b.preventDefault()
    }, !0), a.isScrolling=!1;
    var z = null;
    b.addEventListener("scroll", function() {
        a.isScrolling=!0, z && clearTimeout(z), z = setTimeout(function() {
            a.isScrolling=!1
        }, 250)
    })
}(mui, window), function(a, b) {
    var c = 0, d = function(d, e) {
        var f = a.gestures.session, g = this.options, h = a.now();
        switch (d.type) {
        case a.EVENT_MOVE:
            h - c > 300 && (c = h, f.flickStart = e.center);
            break;
        case a.EVENT_END:
        case a.EVENT_CANCEL:
            f.flickStart && g.flickMaxTime > h - c && e.distance > g.flickMinDistince && (e.flick=!0, e.flickTime = h - c, e.flickDistanceX = e.center.x - f.flickStart.x, e.flickDistanceY = e.center.y - f.flickStart.y, a.trigger(f.target, b, e), a.trigger(f.target, b + e.direction, e))
        }
    };
    a.addGesture({
        name: b,
        index: 5,
        handle: d,
        options: {
            flickMaxTime: 200,
            flickMinDistince: 10
        }
    })
}(mui, "flick"), function(a, b) {
    var c = function(c, d) {
        var e = a.gestures.session;
        if (c.type === a.EVENT_END || c.type === a.EVENT_CANCEL) {
            var f = this.options;
            d.direction && f.swipeMaxTime > d.deltaTime && d.distance > f.swipeMinDistince && (d.swipe=!0, a.trigger(e.target, b, d), a.trigger(e.target, b + d.direction, d))
        }
    };
    a.addGesture({
        name: b,
        index: 10,
        handle: c,
        options: {
            swipeMaxTime: 300,
            swipeMinDistince: 18
        }
    })
}(mui, "swipe"), function(a, b) {
    var c = function(c, d) {
        var e = a.gestures.session;
        switch (c.type) {
        case a.EVENT_START:
            break;
        case a.EVENT_MOVE:
            if (!d.direction)
                return;
            e.lockDirection && e.startDirection && e.startDirection && e.startDirection !== d.direction && ("up" === e.startDirection || "down" === e.startDirection ? d.direction = d.deltaY < 0 ? "up" : "down" : d.direction = d.deltaX < 0 ? "left" : "right"), e.drag || (e.drag=!0, a.trigger(e.target, b + "start", d)), a.trigger(e.target, b, d), a.trigger(e.target, b + d.direction, d);
            break;
        case a.EVENT_END:
        case a.EVENT_CANCEL:
            e.drag && d.isFinal && a.trigger(e.target, b + "end", d)
        }
    };
    a.addGesture({
        name: b,
        index: 20,
        handle: c,
        options: {
            fingers: 1
        }
    })
}(mui, "drag"), function(a, b) {
    var c, d, e = function(e, f) {
        var g = a.gestures.session, h = this.options;
        switch (e.type) {
        case a.EVENT_END:
            if (!f.isFinal)
                return;
            var i = g.target;
            if (!i || i.disabled || i.classList && i.classList.contains("mui-disabled"))
                return;
            if (f.distance < h.tapMaxDistance && f.deltaTime < h.tapMaxTime) {
                if (a.options.gestureConfig.doubletap && c && c === i && d && f.timestamp - d < h.tapMaxInterval)
                    return a.trigger(i, "doubletap", f), d = a.now(), void(c = i);
                a.trigger(i, b, f), d = a.now(), c = i
            }
        }
    };
    a.addGesture({
        name: b,
        index: 30,
        handle: e,
        options: {
            fingers: 1,
            tapMaxInterval: 300,
            tapMaxDistance: 5,
            tapMaxTime: 250
        }
    })
}(mui, "tap"), function(a, b) {
    var c, d = function(d, e) {
        var f = a.gestures.session, g = this.options;
        switch (d.type) {
        case a.EVENT_START:
            clearTimeout(c), c = setTimeout(function() {
                a.trigger(f.target, b, e)
            }, g.holdTimeout);
            break;
        case a.EVENT_MOVE:
            e.distance > g.holdThreshold && clearTimeout(c);
            break;
        case a.EVENT_END:
        case a.EVENT_CANCEL:
            clearTimeout(c)
        }
    };
    a.addGesture({
        name: b,
        index: 10,
        handle: d,
        options: {
            fingers: 1,
            holdTimeout: 500,
            holdThreshold: 2
        }
    })
}(mui, "longtap"), function(a, b) {
    var c, d = function(d, e) {
        var f = a.gestures.session, g = this.options;
        switch (d.type) {
        case a.EVENT_START:
            a.options.gestureConfig.hold && (c && clearTimeout(c), c = setTimeout(function() {
                e.hold=!0, a.trigger(f.target, b, e)
            }, g.holdTimeout));
            break;
        case a.EVENT_MOVE:
            break;
        case a.EVENT_END:
        case a.EVENT_CANCEL:
            c && (clearTimeout(c) && (c = null), a.trigger(f.target, "release", e))
        }
    };
    a.addGesture({
        name: b,
        index: 10,
        handle: d,
        options: {
            fingers: 1,
            holdTimeout: 0
        }
    })
}(mui, "hold"), function(a, b) {
    var c = function(c, d) {
        var e = this.options, f = a.gestures.session;
        switch (c.type) {
        case a.EVENT_START:
            break;
        case a.EVENT_MOVE:
            if (a.options.gestureConfig.pinch) {
                if (d.touches.length < 2)
                    return;
                f.pinch || (f.pinch=!0, a.trigger(f.target, b + "start", d)), a.trigger(f.target, b, d);
                var g = d.scale, h = d.rotation, i = "undefined" == typeof d.lastScale ? 1: d.lastScale, j = 1e-12;
                g > i ? (i = g - j, a.trigger(f.target, b + "out", d)) : i > g && (i = g + j, a.trigger(f.target, b + "in", d)), Math.abs(h) > e.minRotationAngle && a.trigger(f.target, "rotate", d)
            }
            break;
        case a.EVENT_END:
        case a.EVENT_CANCEL:
            a.options.gestureConfig.pinch && f.pinch && 2 === d.touches.length && (f.pinch=!1, a.trigger(f.target, b + "end", d))
        }
    };
    a.addGesture({
        name: b,
        index: 10,
        handle: c,
        options: {
            minRotationAngle: 0
        }
    })
}(mui, "pinch"), function(a) {
    a.global = a.options = {
        gestureConfig: {
            tap: !0,
            doubletap: !1,
            longtap: !1,
            hold: !1,
            flick: !0,
            swipe: !0,
            drag: !0,
            pinch: !1
        }
    }, a.initGlobal = function(b) {
        return a.options = a.extend(!0, a.global, b), this
    };
    var b = {}, c=!1;
    a.init = function(d) {
        return c=!0, a.options = a.extend(!0, a.global, d || {}), a.ready(function() {
            a.doAction("inits", function(c, d) {
                var e=!(b[d.name]&&!d.repeat);
                e && (d.handle.call(a), b[d.name]=!0)
            })
        }), this
    }, a.addInit = function(b) {
        return a.addAction("inits", b)
    }, a(function() {
        var b = document.body.classList, c = [];
        a.os.ios ? (c.push({
            os: "ios",
            version: a.os.version
        }), b.add("mui-ios")) : a.os.android && (c.push({
            os: "android",
            version: a.os.version
        }), b.add("mui-android")), a.os.wechat && (c.push({
            os: "wechat",
            version: a.os.wechat.version
        }), b.add("mui-wechat")), c.length && a.each(c, function(c, d) {
            var e = "";
            d.version && a.each(d.version.split("."), function(c, f) {
                e = e + (e ? "-" : "") + f, b.add(a.className(d.os + "-" + e))
            })
        })
    })
}(mui), function(a) {
    var b = {
        swipeBack: !1,
        preloadPages: [],
        preloadLimit: 10,
        keyEventBind: {
            backbutton: !0,
            menubutton: !0
        }
    }, c = {
        autoShow: !0,
        duration: a.os.ios ? 200: 100,
        aniShow: "slide-in-right"
    };
    a.options.show && (c = a.extend(!0, c, a.options.show)), a.currentWebview = null, a.isHomePage=!1, a.extend(!0, a.global, b), a.extend(!0, a.options, b), a.waitingOptions = function(b) {
        return a.extend({
            autoShow: !0,
            title: ""
        }, b)
    }, a.showOptions = function(b) {
        return a.extend(!0, {}, c, b)
    }, a.windowOptions = function(b) {
        return a.extend({
            scalable: !1,
            bounce: ""
        }, b)
    }, a.plusReady = function(a) {
        return window.plus ? setTimeout(function() {
            a()
        }, 0) : document.addEventListener("plusready", function() {
            a()
        }, !1), this
    }, a.fire = function(b, c, d) {
        b && ("" !== d && (d = d || {}, a.isPlainObject(d) && (d = JSON.stringify(d || {}).replace(/\'/g, "\\u0027").replace(/\\/g, "\\u005c"))), b.evalJS("typeof mui!=='undefined'&&mui.receive('" + c + "','" + d + "')"))
    }, a.receive = function(b, c) {
        if (b) {
            try {
                c && (c = JSON.parse(c))
            } catch (d) {}
            a.trigger(document, b, c)
        }
    };
    var d = function(b) {
        if (!b.preloaded) {
            a.fire(b, "preload");
            for (var c = b.children(), d = 0; d < c.length; d++)
                a.fire(c[d], "preload");
            b.preloaded=!0
        }
    }, e = function(b, c, d) {
        if (d) {
            if (!b[c + "ed"]) {
                a.fire(b, c);
                for (var e = b.children(), f = 0; f < e.length; f++)
                    a.fire(e[f], c);
                b[c + "ed"]=!0
            }
        } else {
            a.fire(b, c);
            for (var e = b.children(), f = 0; f < e.length; f++)
                a.fire(e[f], c)
        }
    };
    a.openWindow = function(b, c, f) {
        if (window.plus) {
            "object" == typeof b ? (f = b, b = f.url, c = f.id || b) : "object" == typeof c ? (f = c, c = b) : c = c || b, f = f || {};
            var g, h, i, j = f.params || {};
            if (a.webviews[c]) {
                var k = a.webviews[c];
                return g = k.webview, g && g.getURL() || (f = a.extend(f, {
                    id: c,
                    url: b,
                    preload: !0
                }, !0), g = a.createWindow(f)), h = k.show, h = f.show ? a.extend(h, f.show) : h, g.show(h.aniShow, h.duration, function() {
                    d(g), e(g, "pagebeforeshow", !1)
                }), k.afterShowMethodName && g.evalJS(k.afterShowMethodName + "('" + JSON.stringify(j) + "')"), g
            }
            if (f.createNew!==!0 && (g = plus.webview.getWebviewById(c)))
                return h = a.showOptions(f.show), g.show(h.aniShow, h.duration, function() {
                    d(g), e(g, "pagebeforeshow", !1)
                }), g;
            var l = a.waitingOptions(f.waiting);
            return l.autoShow && (i = plus.nativeUI.showWaiting(l.title, l.options)), f = a.extend(f, {
                id: c,
                url: b
            }), g = a.createWindow(f), h = a.showOptions(f.show), h.autoShow && g.addEventListener("loaded", function() {
                i && i.close(), g.show(h.aniShow, h.duration, function() {
                    d(g), e(g, "pagebeforeshow", !1)
                }), g.showed=!0, f.afterShowMethodName && g.evalJS(f.afterShowMethodName + "('" + JSON.stringify(j) + "')")
            }, !1), g
        }
    }, a.createWindow = function(b, c) {
        if (window.plus) {
            var d, e = b.id || b.url;
            if (b.preload) {
                a.webviews[e] && a.webviews[e].webview.getURL() ? d = a.webviews[e].webview : (b.createNew!==!0 && (d = plus.webview.getWebviewById(e)), d || (d = plus.webview.create(b.url, e, a.windowOptions(b.styles), a.extend({
                    preload: !0
                }, b.extras)), b.subpages && a.each(b.subpages, function(b, c) {
                    var e = plus.webview.create(c.url, c.id || c.url, a.windowOptions(c.styles), a.extend({
                        preload: !0
                    }, c.extras));
                    d.append(e)
                }))), a.webviews[e] = {
                    webview: d,
                    preload: !0,
                    show: a.showOptions(b.show),
                    afterShowMethodName: b.afterShowMethodName
                };
                var f = a.data.preloads, g = f.indexOf(e);
                if (~g && f.splice(g, 1), f.push(e), f.length > a.options.preloadLimit) {
                    var h = a.data.preloads.shift(), i = a.webviews[h];
                    i && i.webview && a.closeAll(i.webview), delete a.webviews[h]
                }
            } else 
                c!==!1 && (d = plus.webview.create(b.url, e, a.windowOptions(b.styles), b.extras), b.subpages && a.each(b.subpages, function(b, c) {
                    var e = plus.webview.create(c.url, c.id || c.url, a.windowOptions(c.styles), c.extras);
                    d.append(e)
                }));
            return d
        }
    }, a.preload = function(b) {
        return b.preload || (b.preload=!0), a.createWindow(b)
    }, a.closeOpened = function(b) {
        var c = b.opened();
        if (c)
            for (var d = 0, e = c.length; e > d; d++) {
                var f = c[d], g = f.opened();
                g && g.length > 0 ? a.closeOpened(f) : f.parent() !== b && f.close("none")
            }
    }, a.closeAll = function(b, c) {
        a.closeOpened(b), c ? b.close(c) : b.close()
    }, a.createWindows = function(b) {
        a.each(b, function(b, c) {
            a.createWindow(c, !1)
        })
    }, a.appendWebview = function(b) {
        if (window.plus) {
            var c, d = b.id || b.url;
            return a.webviews[d] || (c = plus.webview.create(b.url, d, b.styles, b.extras), plus.webview.currentWebview().append(c), a.webviews[d] = b), c
        }
    }, a.webviews = {}, a.data.preloads = [], a.plusReady(function() {
        a.currentWebview = plus.webview.currentWebview()
    }), a.addInit({
        name: "5+",
        index: 100,
        handle: function() {
            var b = a.options, c = b.subpages || [];
            if (a.os.plus)
                a.plusReady(function() {
                    a.each(c, function(b, c) {
                        a.appendWebview(c)
                    }), plus.webview.currentWebview() === plus.webview.getWebviewById(plus.runtime.appid) && (a.isHomePage=!0, setTimeout(function() {
                        d(plus.webview.currentWebview())
                    }, 300)), a.os.ios && a.options.statusBarBackground && plus.navigator.setStatusBarBackground(a.options.statusBarBackground), a.os.android && parseFloat(a.os.version) < 4.4 && null == plus.webview.currentWebview().parent() && document.addEventListener("resume", function() {
                        var a = document.body;
                        a.style.display = "none", setTimeout(function() {
                            a.style.display = ""
                        }, 10)
                    })
                });
            else if (c.length > 0) {
                var e = document.createElement("div");
                e.className = "mui-error";
                var f = document.createElement("span");
                f.innerHTML = "&#22312;&#35813;&#27983;&#35272;&#22120;&#19979;&#65292;&#19981;&#25903;&#25345;&#21019;&#24314;&#23376;&#39029;&#38754;&#65292;&#20855;&#20307;&#21442;&#32771;", e.appendChild(f);
                var g = document.createElement("a");
                g.innerHTML = '"&#109;&#117;&#105;&#26694;&#26550;&#36866;&#29992;&#22330;&#26223;"', g.href = "http://ask.dcloud.net.cn/article/113", e.appendChild(g), document.body.appendChild(e), console.log("&#22312;&#35813;&#27983;&#35272;&#22120;&#19979;&#65292;&#19981;&#25903;&#25345;&#21019;&#24314;&#23376;&#39029;&#38754;")
            }
        }
    }), window.addEventListener("preload", function() {
        var b = a.options.preloadPages || [];
        a.plusReady(function() {
            a.each(b, function(b, c) {
                a.createWindow(a.extend(c, {
                    preload: !0
                }))
            })
        })
    })
}(mui), function(a, b) {
    a.addBack = function(b) {
        return a.addAction("backs", b)
    }, a.addBack({
        name: "browser",
        index: 100,
        handle: function() {
            return b.history.length > 1 ? (b.history.back(), !0) : !1
        }
    }), a.back = function() {
        ("function" != typeof a.options.beforeback || a.options.beforeback()!==!1) && a.doAction("backs")
    }, b.addEventListener("tap", function(b) {
        var c = a.targets.action;
        c && c.classList.contains("mui-action-back") && a.back()
    }), b.addEventListener("swiperight", function(b) {
        var c = b.detail;
        a.options.swipeBack===!0 && Math.abs(c.angle) < 3 && a.back()
    })
}(mui, window), function(a, b) {
    a.os.plus && a.os.android && a.addBack({
        name: "mui",
        index: 5,
        handle: function() {
            if (a.targets._popover && a.targets._popover.classList.contains("mui-active"))
                return a(a.targets._popover).popover("hide"), !0;
            var b = document.querySelector(".mui-off-canvas-wrap.mui-active");
            if (b)
                return a(b).offCanvas("close"), !0;
            var c = a.isFunction(a.getPreviewImage) && a.getPreviewImage();
            return c && c.isShown() ? (c.close(), !0) : void 0
        }
    }), a.addBack({
        name: "5+",
        index: 10,
        handle: function() {
            if (!b.plus)
                return !1;
            var c = plus.webview.currentWebview(), d = c.parent();
            return d ? d.evalJS("mui&&mui.back();") : c.canBack(function(d) {
                d.canBack ? b.history.back() : c.id === plus.runtime.appid || (c.preload ? c.hide("auto") : a.closeAll(c))
            }), !0
        }
    }), a.menu = function() {
        var c = document.querySelector(".mui-action-menu");
        if (c)
            a.trigger(c, "touchstart"), a.trigger(c, "tap");
        else if (b.plus) {
            var d = a.currentWebview, e = d.parent();
            e && e.evalJS("mui&&mui.menu();")
        }
    };
    var c = function() {
        a.back()
    }, d = function() {
        a.menu()
    };
    a.plusReady(function() {
        a.options.keyEventBind.backbutton && plus.key.addEventListener("backbutton", c, !1), a.options.keyEventBind.menubutton && plus.key.addEventListener("menubutton", d, !1)
    }), a.addInit({
        name: "keyEventBind",
        index: 1e3,
        handle: function() {
            a.plusReady(function() {
                a.options.keyEventBind.backbutton || plus.key.removeEventListener("backbutton", c), a.options.keyEventBind.menubutton || plus.key.removeEventListener("menubutton", d)
            })
        }
    })
}(mui, window), function(a) {
    a.addInit({
        name: "pullrefresh",
        index: 1e3,
        handle: function() {
            var b = a.options, c = b.pullRefresh || {}, d = c.down && c.down.hasOwnProperty("callback"), e = c.up && c.up.hasOwnProperty("callback");
            if (d || e) {
                var f = c.container;
                if (f) {
                    var g = a(f);
                    1 === g.length && (a.os.plus && a.os.android ? a.plusReady(function() {
                        var b = plus.webview.currentWebview();
                        if (e) {
                            var f = {};
                            f.up = c.up, f.webviewId = b.id || b.getURL(), g.pullRefresh(f)
                        }
                        if (d) {
                            var h = b.parent(), i = b.id || b.getURL();
                            if (h) {
                                e || g.pullRefresh({
                                    webviewId: i
                                });
                                var j = {
                                    webviewId: i
                                };
                                j.down = a.extend({}, c.down), j.down.callback = "_CALLBACK", h.evalJS("mui&&mui(document.querySelector('.mui-content')).pullRefresh('" + JSON.stringify(j) + "')")
                            }
                        }
                    }) : g.pullRefresh(c))
                }
            }
        }
    })
}(mui), function(a, b, c) {
    var d = "application/json", e = "text/html", f = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, g = /^(?:text|application)\/javascript/i, h = /^(?:text|application)\/xml/i, i = /^\s*$/;
    a.ajaxSettings = {
        type: "GET",
        beforeSend: a.noop,
        success: a.noop,
        error: a.noop,
        complete: a.noop,
        context: null,
        xhr: function(a) {
            return new b.XMLHttpRequest
        },
        accepts: {
            script: "text/javascript, application/javascript, application/x-javascript",
            json: d,
            xml: "application/xml, text/xml",
            html: e,
            text: "text/plain"
        },
        timeout: 0,
        processData: !0,
        cache: !0
    };
    var j = function(a, b) {
        var c = b.context;
        return b.beforeSend.call(c, a, b)===!1?!1 : void 0
    }, k = function(a, b, c) {
        c.success.call(c.context, a, "success", b), m("success", b, c)
    }, l = function(a, b, c, d) {
        d.error.call(d.context, c, b, a), m(b, c, d)
    }, m = function(a, b, c) {
        c.complete.call(c.context, b, a)
    }, n = function(b, c, d, e) {
        var f, g = a.isArray(c), h = a.isPlainObject(c);
        a.each(c, function(c, i) {
            f = a.type(i), e && (c = d ? e : e + "[" + (h || "object" === f || "array" === f ? c : "") + "]"), !e && g ? b.add(i.name, i.value) : "array" === f ||!d && "object" === f ? n(b, i, d, c) : b.add(c, i)
        })
    }, o = function(b) {
        b.processData && b.data && "string" != typeof b.data && (b.data = a.param(b.data, b.traditional)), !b.data || b.type && "GET" !== b.type.toUpperCase() || (b.url = p(b.url, b.data), b.data = c)
    }, p = function(a, b) {
        return "" === b ? a : (a + "&" + b).replace(/[&?]{1,2}/, "?")
    }, q = function(a) {
        return a && (a = a.split(";", 2)[0]), a && (a === e ? "html" : a === d ? "json" : g.test(a) ? "script" : h.test(a) && "xml") || "text"
    }, r = function(b, d, e, f) {
        return a.isFunction(d) && (f = e, e = d, d = c), a.isFunction(e) || (f = e, e = c), {
            url: b,
            data: d,
            success: e,
            dataType: f
        }
    };
    a.ajax = function(d, e) {
        "object" == typeof d && (e = d, d = c);
        var f = e || {};
        f.url = d || f.url;
        for (var g in a.ajaxSettings)
            f[g] === c && (f[g] = a.ajaxSettings[g]);
        o(f);
        var h = f.dataType;
        f.cache!==!1 && (e && e.cache===!0 || "script" !== h) || (f.url = p(f.url, "_=" + a.now()));
        var m, n = f.accepts[h], r = {}, s = function(a, b) {
            r[a.toLowerCase()] = [a, b]
        }, t = /^([\w-]+:)\/\//.test(f.url) ? RegExp.$1: b.location.protocol, u = f.xhr(f), v = u.setRequestHeader;
        if (s("X-Requested-With", "XMLHttpRequest"), s("Accept", n || "*/*"), (n = f.mimeType || n) && (n.indexOf(",")>-1 && (n = n.split(",", 2)[0]), u.overrideMimeType && u.overrideMimeType(n)), (f.contentType || f.contentType!==!1 && f.data && "GET" !== f.type.toUpperCase()) && s("Content-Type", f.contentType || "application/x-www-form-urlencoded"), f.headers)
            for (var w in f.headers)
                s(w, f.headers[w]);
        if (u.setRequestHeader = s, u.onreadystatechange = function() {
            if (4 === u.readyState) {
                u.onreadystatechange = a.noop, clearTimeout(m);
                var b, c=!1;
                if (u.status >= 200 && u.status < 300 || 304 === u.status || 0 === u.status && "file:" === t) {
                    h = h || q(f.mimeType || u.getResponseHeader("content-type")), b = u.responseText;
                    try {
                        "script" === h ? (1, eval)(b) : "xml" === h ? b = u.responseXML : "json" === h && (b = i.test(b) ? null : a.parseJSON(b))
                    } catch (d) {
                        c = d
                    }
                    c ? l(c, "parsererror", u, f) : k(b, u, f)
                } else 
                    l(u.statusText || null, u.status ? "error" : "abort", u, f)
            }
        }, j(u, f)===!1)
            return u.abort(), l(null, "abort", u, f), u;
        if (f.xhrFields)
            for (var w in f.xhrFields)
                u[w] = f.xhrFields[w];
        var x = "async"in f ? f.async: !0;
        u.open(f.type.toUpperCase(), f.url, x, f.username, f.password);
        for (var w in r)
            v.apply(u, r[w]);
        return f.timeout > 0 && (m = setTimeout(function() {
            u.onreadystatechange = a.noop, u.abort(), l(null, "timeout", u, f)
        }, f.timeout)), u.send(f.data ? f.data : null), u
    }, a.param = function(a, b) {
        var c = [];
        return c.add = function(a, b) {
            this.push(encodeURIComponent(a) + "=" + encodeURIComponent(b))
        }, n(c, a, b), c.join("&").replace(/%20/g, "+")
    }, a.get = function() {
        return a.ajax(r.apply(null, arguments))
    }, a.post = function() {
        var b = r.apply(null, arguments);
        return b.type = "POST", a.ajax(b)
    }, a.getJSON = function() {
        var b = r.apply(null, arguments);
        return b.dataType = "json", a.ajax(b)
    }, a.fn.load = function(b, c, d) {
        if (!this.length)
            return this;
        var e, g = this, h = b.split(/\s/), i = r(b, c, d), j = i.success;
        return h.length > 1 && (i.url = h[0], e = h[1]), i.success = function(a) {
            if (e) {
                var b = document.createElement("div");
                b.innerHTML = a.replace(f, "");
                var c = document.createElement("div"), d = b.querySelectorAll(e);
                if (d && d.length > 0)
                    for (var h = 0, i = d.length; i > h; h++)
                        c.appendChild(d[h]);
                g[0].innerHTML = c.innerHTML
            } else 
                g[0].innerHTML = a;
            j && j.apply(g, arguments)
        }, a.ajax(i), this
    }
}(mui, window), function(a) {
    var b = document.createElement("a");
    b.href = window.location.href, a.plusReady(function() {
        a.ajaxSettings = a.extend(a.ajaxSettings, {
            xhr: function(a) {
                if (a.crossDomain)
                    return new plus.net.XMLHttpRequest;
                if ("file:" !== b.protocol) {
                    var c = document.createElement("a");
                    if (c.href = a.url, c.href = c.href, a.crossDomain = b.protocol + "//" + b.host != c.protocol + "//" + c.host, a.crossDomain)
                        return new plus.net.XMLHttpRequest
                }
                return new window.XMLHttpRequest
            }
        })
    })
}(mui), function(a, b, c) {
    a.offset = function(a) {
        var d = {
            top: 0,
            left: 0
        };
        return typeof a.getBoundingClientRect !== c && (d = a.getBoundingClientRect()), {
            top: d.top + b.pageYOffset - a.clientTop,
            left: d.left + b.pageXOffset - a.clientLeft
        }
    }
}(mui, window), function(a, b) {
    a.scrollTo = function(a, c, d) {
        c = c || 1e3;
        var e = function(c) {
            if (0 >= c)
                return b.scrollTo(0, a), void(d && d());
            var f = a - b.scrollY;
            setTimeout(function() {
                b.scrollTo(0, b.scrollY + f / c * 10), e(c - 10)
            }, 16.7)
        };
        e(c)
    }, a.animationFrame = function(a) {
        var b, c, d;
        return function() {
            b = arguments, d = this, c || (c=!0, requestAnimationFrame(function() {
                a.apply(d, b), c=!1
            }))
        }
    }
}(mui, window), function(a) {
    var b=!1, c = /xyz/.test(function() {
        xyz
    }) ? /\b_super\b/ : /.*/, d = function() {};
    d.extend = function(a) {
        function d() {
            !b && this.init && this.init.apply(this, arguments)
        }
        var e = this.prototype;
        b=!0;
        var f = new this;
        b=!1;
        for (var g in a)
            f[g] = "function" == typeof a[g] && "function" == typeof e[g] && c.test(a[g]) ? function(a, b) {
                return function() {
                    var c = this._super;
                    this._super = e[a];
                    var d = b.apply(this, arguments);
                    return this._super = c, d
                }
            }(g, a[g]) : a[g];
        return d.prototype = f, d.prototype.constructor = d, d.extend = arguments.callee, d
    }, a.Class = d
}(mui), function(a, b, c) {
    var d = "mui-pull-top-pocket", e = "mui-pull-bottom-pocket", f = "mui-pull", g = "mui-pull-loading", h = "mui-pull-caption", i = "mui-pull-caption-down", j = "mui-pull-caption-refresh", k = "mui-pull-caption-nomore", l = "mui-icon", m = "mui-spinner", n = "mui-icon-pulldown", o = "mui-block", p = "mui-hidden", q = "mui-visibility", r = g + " " + l + " " + n, s = g + " " + l + " " + n, t = g + " " + l + " " + m, u = ['<div class="' + f + '">', '<div class="{icon}"></div>', '<div class="' + h + '">{contentrefresh}</div>', "</div>"].join(""), v = {
        init: function(b, c) {
            this._super(b, a.extend(!0, {
                scrollY: !0,
                scrollX: !1,
                indicators: !0,
                deceleration: .003,
                down: {
                    height: 50,
                    contentdown: "&#19979;&#25289;&#21487;&#20197;&#21047;&#26032;",
                    contentover: "&#37322;&#25918;&#31435;&#21363;&#21047;&#26032;",
                    contentrefresh: "&#27491;&#22312;&#21047;&#26032;"
                },
                up: {
                    height: 50,
                    auto: !1,
                    contentdown: "&#19978;&#25289;&#26174;&#31034;&#26356;&#22810;",
                    contentrefresh: "&#27491;&#22312;&#21152;&#36733;",
                    contentnomore: "&#27809;&#26377;&#26356;&#22810;&#25968;&#25454;&#20102;",
                    duration: 300
                }
            }, c))
        },
        _init: function() {
            this._super(), this._initPocket()
        },
        _initPulldownRefresh: function() {
            this.pulldown=!0, this.pullPocket = this.topPocket, this.pullPocket.classList.add(o), this.pullPocket.classList.add(q), this.pullCaption = this.topCaption, this.pullLoading = this.topLoading
        },
        _initPullupRefresh: function() {
            this.pulldown=!1, this.pullPocket = this.bottomPocket, this.pullPocket.classList.add(o), this.pullPocket.classList.add(q), this.pullCaption = this.bottomCaption, this.pullLoading = this.bottomLoading
        },
        _initPocket: function() {
            var a = this.options;
            a.down && a.down.hasOwnProperty("callback") && (this.topPocket = this.scroller.querySelector("." + d), this.topPocket || (this.topPocket = this._createPocket(d, a.down, s), this.wrapper.insertBefore(this.topPocket, this.wrapper.firstChild)), this.topLoading = this.topPocket.querySelector("." + g), this.topCaption = this.topPocket.querySelector("." + h)), a.up && a.up.hasOwnProperty("callback") && (this.bottomPocket = this.scroller.querySelector("." + e), this.bottomPocket || (this.bottomPocket = this._createPocket(e, a.up, t), this.scroller.appendChild(this.bottomPocket)), this.bottomLoading = this.bottomPocket.querySelector("." + g), this.bottomCaption = this.bottomPocket.querySelector("." + h), this.wrapper.addEventListener("scrollbottom", this))
        },
        _createPocket: function(a, c, d) {
            var e = b.createElement("div");
            return e.className = a, e.innerHTML = u.replace("{contentrefresh}", c.contentrefresh).replace("{icon}", d), e
        },
        _resetPullDownLoading: function() {
            var a = this.pullLoading;
            a && (this.pullCaption.innerHTML = this.options.down.contentdown, a.style.webkitTransition = "", a.style.webkitTransform = "", a.style.webkitAnimation = "", a.className = s)
        },
        _setCaptionClass: function(a, b, c) {
            if (!a)
                switch (c) {
                case this.options.up.contentdown:
                    b.className = h + " " + i;
                    break;
                case this.options.up.contentrefresh:
                    b.className = h + " " + j;
                    break;
                case this.options.up.contentnomore:
                    b.className = h + " " + k
                }
        },
        _setCaption: function(a, b) {
            if (!this.loading) {
                var c = this.options, d = this.pullPocket, e = this.pullCaption, f = this.pullLoading, g = this.pulldown, h = this;
                d && (b ? setTimeout(function() {
                    e.innerHTML = h.lastTitle = a, g ? f.className = s : (h._setCaptionClass(!1, e, a), f.className = t), f.style.webkitAnimation = "", f.style.webkitTransition = "", f.style.webkitTransform = ""
                }, 100) : a !== this.lastTitle && (e.innerHTML = a, g ? a === c.down.contentrefresh ? (f.className = t, f.style.webkitAnimation = "spinner-spin 1s step-end infinite") : a === c.down.contentover ? (f.className = r, f.style.webkitTransition = "-webkit-transform 0.3s ease-in", f.style.webkitTransform = "rotate(180deg)") : a === c.down.contentdown && (f.className = s, f.style.webkitTransition = "-webkit-transform 0.3s ease-in", f.style.webkitTransform = "rotate(0deg)") : (a === c.up.contentrefresh ? f.className = t + " " + q : f.className = t + " " + p, h._setCaptionClass(!1, e, a)), this.lastTitle = a))
            }
        }
    };
    a.PullRefresh = v
}(mui, document), function(a, b, c, d) {
    var e = "mui-scrollbar", f = "mui-scrollbar-indicator", g = e + "-vertical", h = e + "-horizontal", i = "mui-active", j = {
        quadratic: {
            style: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
            fn: function(a) {
                return a * (2 - a)
            }
        },
        circular: {
            style: "cubic-bezier(0.1, 0.57, 0.1, 1)",
            fn: function(a) {
                return Math.sqrt(1 - --a * a)
            }
        }
    }, k = a.Class.extend({
        init: function(b, c) {
            this.wrapper = this.element = b, this.scroller = this.wrapper.children[0], this.scrollerStyle = this.scroller && this.scroller.style, this.stopped=!1, this.options = a.extend(!0, {
                scrollY: !0,
                scrollX: !1,
                startX: 0,
                startY: 0,
                indicators: !0,
                stopPropagation: !1,
                hardwareAccelerated: !0,
                fixedBadAndorid: !1,
                preventDefaultException: {
                    tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|VIDEO)$/
                },
                momentum: !0,
                snap: !1,
                bounce: !0,
                bounceTime: 300,
                bounceEasing: j.circular.style,
                directionLockThreshold: 5,
                parallaxElement: !1,
                parallaxRatio: .5
            }, c), this.x = 0, this.y = 0, this.translateZ = this.options.hardwareAccelerated ? " translateZ(0)" : "", this._init(), this.scroller && (this.refresh(), this.scrollTo(this.options.startX, this.options.startY))
        },
        _init: function() {
            this._initParallax(), this._initIndicators(), this._initEvent()
        },
        _initParallax: function() {
            this.options.parallaxElement && (this.parallaxElement = c.querySelector(this.options.parallaxElement), this.parallaxStyle = this.parallaxElement.style, this.parallaxHeight = this.parallaxElement.offsetHeight, this.parallaxImgStyle = this.parallaxElement.querySelector("img").style)
        },
        _initIndicators: function() {
            var a = this;
            if (a.indicators = [], this.options.indicators) {
                var b, c = [];
                a.options.scrollY && (b = {
                    el: this._createScrollBar(g),
                    listenX: !1
                }, this.wrapper.appendChild(b.el), c.push(b)), this.options.scrollX && (b = {
                    el: this._createScrollBar(h),
                    listenY: !1
                }, this.wrapper.appendChild(b.el), c.push(b));
                for (var d = c.length; d--;)
                    this.indicators.push(new l(this, c[d]))
            }
        },
        _initSnap: function() {
            this.currentPage = {}, this.pages = [];
            for (var a = this.snaps, b = a.length, c = 0, d =- 1, e = 0, f = 0, g = 0; b > g; g++) {
                var h = a[g], j = h.offsetLeft, k = h.offsetWidth;
                (0 === g || j <= a[g - 1].offsetLeft) && (c = 0, d++), this.pages[c] || (this.pages[c] = []), e = this._getSnapX(j), f = e - Math.round(k / 2), this.pages[c][d] = {
                    x: e,
                    cx: f,
                    pageX: c,
                    element: h
                }, h.classList.contains(i) && (this.currentPage = this.pages[c][0]), e >= this.maxScrollX && c++
            }
            this.options.startX = this.currentPage.x || 0
        },
        _getSnapX: function(a) {
            return Math.max(Math.min(0, - a + this.wrapperWidth / 2), this.maxScrollX)
        },
        _gotoPage: function(a) {
            this.currentPage = this.pages[Math.min(a, this.pages.length - 1)][0];
            for (var b = 0, c = this.snaps.length; c > b; b++)
                b === a ? this.snaps[b].classList.add(i) : this.snaps[b].classList.remove(i);
            this.scrollTo(this.currentPage.x, 0, this.options.bounceTime)
        },
        _nearestSnap: function(a) {
            if (!this.pages.length)
                return {
                    x: 0,
                    pageX: 0
                };
            var b = 0, c = this.pages.length;
            for (a > 0 ? a = 0 : a < this.maxScrollX && (a = this.maxScrollX); c > b; b++)
                if (a >= this.pages[b][0].cx)
                    return this.pages[b][0];
            return {
                x: 0,
                pageX: 0
            }
        },
        _initEvent: function(c) {
            var d = c ? "removeEventListener": "addEventListener";
            b[d]("orientationchange", this), b[d]("resize", this), this.scroller[d]("webkitTransitionEnd", this), this.wrapper[d]("touchstart", this), this.wrapper[d]("touchcancel", this), this.wrapper[d]("touchend", this), this.wrapper[d]("drag", this), this.wrapper[d]("dragend", this), this.wrapper[d]("flick", this), this.wrapper[d]("scrollend", this), this.options.scrollX && this.wrapper[d]("swiperight", this);
            var e = this.wrapper.querySelector(".mui-segmented-control");
            e && mui(e)[c ? "off": "on"]("click", "a", a.preventDefault), this.wrapper[d]("scrollend", this._handleIndicatorScrollend.bind(this)), this.wrapper[d]("scrollstart", this._handleIndicatorScrollstart.bind(this)), this.wrapper[d]("refresh", this._handleIndicatorRefresh.bind(this))
        },
        _handleIndicatorScrollend: function() {
            this.indicators.map(function(a) {
                a.fade()
            })
        },
        _handleIndicatorScrollstart: function() {
            this.indicators.map(function(a) {
                a.fade(1)
            })
        },
        _handleIndicatorRefresh: function() {
            this.indicators.map(function(a) {
                a.refresh()
            })
        },
        handleEvent: function(a) {
            if (this.stopped)
                return void this.resetPosition();
            switch (a.type) {
            case"touchstart":
                this._start(a);
                break;
            case"drag":
                this.options.stopPropagation && a.stopPropagation(), this._drag(a);
                break;
            case"dragend":
            case"flick":
                this.options.stopPropagation && a.stopPropagation(), this._flick(a);
                break;
            case"touchcancel":
            case"touchend":
                this._end(a);
                break;
            case"webkitTransitionEnd":
                this._transitionEnd(a);
                break;
            case"scrollend":
                this._scrollend(a), a.stopPropagation();
                break;
            case"orientationchange":
            case"resize":
                this._resize();
                break;
            case"swiperight":
                a.stopPropagation()
            }
        },
        _start: function(b) {
            if (b.target&&!this._preventDefaultException(b.target, this.options.preventDefaultException) && b.preventDefault(), this.moved = this.needReset=!1, this._transitionTime(), this.isInTransition) {
                this.needReset=!0, this.isInTransition=!1;
                var c = a.parseTranslateMatrix(a.getStyles(this.scroller, "webkitTransform"));
                this.setTranslate(Math.round(c.x), Math.round(c.y)), a.trigger(this.scroller, "scrollend", this), b.preventDefault()
            }
            this.reLayout(), a.trigger(this.scroller, "beforescrollstart", this)
        },
        _getDirectionByAngle: function(a) {
            return - 80 > a && a>-100 ? "up" : a >= 80 && 100 > a ? "down" : a >= 170||-170 >= a ? "left" : a>=-35 && 10 >= a ? "right" : null
        },
        _drag: function(c) {
            var d = c.detail;
            if ((this.options.scrollY || "up" === d.direction || "down" === d.direction) && a.os.ios && parseFloat(a.os.version) >= 8) {
                var e = d.gesture.touches[0].clientY;
                if (e + 10 > b.innerHeight || 10 > e)
                    return void this.resetPosition(this.options.bounceTime)
            }
            var f = isReturn=!1;
            this._getDirectionByAngle(d.angle);
            if ("left" === d.direction || "right" === d.direction ? this.options.scrollX ? (f=!0, this.moved || (a.gestures.session.lockDirection=!0, a.gestures.session.startDirection = d.direction)) : this.options.scrollY&&!this.moved && (isReturn=!0) : "up" === d.direction || "down" === d.direction ? this.options.scrollY ? (f=!0, this.moved || (a.gestures.session.lockDirection=!0, a.gestures.session.startDirection = d.direction)) : this.options.scrollX&&!this.moved && (isReturn=!0) : isReturn=!0, (this.moved || f) && (c.stopPropagation(), d.gesture && d.gesture.preventDefault()), !isReturn) {
                this.moved ? c.stopPropagation() : a.trigger(this.scroller, "scrollstart", this);
                var g = 0, h = 0;
                this.moved ? (g = d.deltaX - a.gestures.session.prevTouch.deltaX, h = d.deltaY - a.gestures.session.prevTouch.deltaY) : (g = d.deltaX, h = d.deltaY);
                var i = Math.abs(d.deltaX), j = Math.abs(d.deltaY);
                i > j + this.options.directionLockThreshold ? h = 0 : j >= i + this.options.directionLockThreshold && (g = 0), g = this.hasHorizontalScroll ? g : 0, h = this.hasVerticalScroll ? h : 0;
                var k = this.x + g, l = this.y + h;
                (k > 0 || k < this.maxScrollX) && (k = this.options.bounce ? this.x + g / 3 : k > 0 ? 0 : this.maxScrollX), (l > 0 || l < this.maxScrollY) && (l = this.options.bounce ? this.y + h / 3 : l > 0 ? 0 : this.maxScrollY), this.requestAnimationFrame || this._updateTranslate(), this.moved=!0, this.x = k, this.y = l, a.trigger(this.scroller, "scroll", this)
            }
        },
        _flick: function(b) {
            if (this.moved) {
                b.stopPropagation();
                var c = b.detail;
                if (this._clearRequestAnimationFrame(), "dragend" !== b.type ||!c.flick) {
                    var d = Math.round(this.x), e = Math.round(this.y);
                    if (this.isInTransition=!1, !this.resetPosition(this.options.bounceTime)) {
                        if (this.scrollTo(d, e), "dragend" === b.type)
                            return void a.trigger(this.scroller, "scrollend", this);
                        var f = 0, g = "";
                        return this.options.momentum && c.flickTime < 300 && (momentumX = this.hasHorizontalScroll ? this._momentum(this.x, c.flickDistanceX, c.flickTime, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : {
                            destination: d,
                            duration: 0
                        }, momentumY = this.hasVerticalScroll ? this._momentum(this.y, c.flickDistanceY, c.flickTime, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : {
                            destination: e,
                            duration: 0
                        }, d = momentumX.destination, e = momentumY.destination, f = Math.max(momentumX.duration, momentumY.duration), this.isInTransition=!0), d != this.x || e != this.y ? ((d > 0 || d < this.maxScrollX || e > 0 || e < this.maxScrollY) && (g = j.quadratic), void this.scrollTo(d, e, f, g)) : void a.trigger(this.scroller, "scrollend", this)
                    }
                }
            }
        },
        _end: function(a) {
            this.needReset=!1, (!this.moved && this.needReset || "touchcancel" === a.type) && this.resetPosition()
        },
        _transitionEnd: function(b) {
            b.target == this.scroller && this.isInTransition && (this._transitionTime(), this.resetPosition(this.options.bounceTime) || (this.isInTransition=!1, a.trigger(this.scroller, "scrollend", this)))
        },
        _scrollend: function(b) {
            Math.abs(this.y) > 0 && this.y <= this.maxScrollY && a.trigger(this.scroller, "scrollbottom", this)
        },
        _resize: function() {
            var a = this;
            clearTimeout(a.resizeTimeout), a.resizeTimeout = setTimeout(function() {
                a.refresh()
            }, a.options.resizePolling)
        },
        _transitionTime: function(b) {
            if (b = b || 0, this.scrollerStyle.webkitTransitionDuration = b + "ms", this.parallaxElement && this.options.scrollY && (this.parallaxStyle.webkitTransitionDuration = b + "ms"), this.options.fixedBadAndorid&&!b && a.os.isBadAndroid && (this.scrollerStyle.webkitTransitionDuration = "0.001s", this.parallaxElement && this.options.scrollY && (this.parallaxStyle.webkitTransitionDuration = "0.001s")), this.indicators)
                for (var c = this.indicators.length; c--;)
                    this.indicators[c].transitionTime(b)
        },
        _transitionTimingFunction: function(a) {
            if (this.scrollerStyle.webkitTransitionTimingFunction = a, this.parallaxElement && this.options.scrollY && (this.parallaxStyle.webkitTransitionDuration = a), this.indicators)
                for (var b = this.indicators.length; b--;)
                    this.indicators[b].transitionTimingFunction(a)
        },
        _translate: function(a, b) {
            this.x = a, this.y = b
        },
        _clearRequestAnimationFrame: function() {
            this.requestAnimationFrame && (cancelAnimationFrame(this.requestAnimationFrame), this.requestAnimationFrame = null)
        },
        _updateTranslate: function() {
            var a = this;
            (a.x !== a.lastX || a.y !== a.lastY) && a.setTranslate(a.x, a.y), a.requestAnimationFrame = requestAnimationFrame(function() {
                a._updateTranslate()
            })
        },
        _createScrollBar: function(a) {
            var b = c.createElement("div"), d = c.createElement("div");
            return b.className = e + " " + a, d.className = f, b.appendChild(d), a === g ? (this.scrollbarY = b, this.scrollbarIndicatorY = d) : a === h && (this.scrollbarX = b, this.scrollbarIndicatorX = d), this.wrapper.appendChild(b), b
        },
        _preventDefaultException: function(a, b) {
            for (var c in b)
                if (b[c].test(a[c]))
                    return !0;
            return !1
        },
        _reLayout: function() {
            if (this.hasHorizontalScroll || (this.maxScrollX = 0, this.scrollerWidth = this.wrapperWidth), this.hasVerticalScroll || (this.maxScrollY = 0, this.scrollerHeight = this.wrapperHeight), this.indicators.map(function(a) {
                a.refresh()
            }), this.options.snap && "string" == typeof this.options.snap) {
                var a = this.scroller.querySelectorAll(this.options.snap);
                this.itemLength = 0, this.snaps = [];
                for (var b = 0, c = a.length; c > b; b++) {
                    var d = a[b];
                    d.parentNode === this.scroller && (this.itemLength++, this.snaps.push(d))
                }
                this._initSnap()
            }
        },
        _momentum: function(a, b, c, e, f, g) {
            var h, i, j = parseFloat(Math.abs(b) / c);
            return g = g === d ? 6e-4 : g, h = a + j * j / (2 * g) * (0 > b?-1 : 1), i = j / g, e > h ? (h = f ? e - f / 2.5 * (j / 8) : e, b = Math.abs(h - a), i = b / j) : h > 0 && (h = f ? f / 2.5 * (j / 8) : 0, b = Math.abs(a) + h, i = b / j), {
                destination: Math.round(h),
                duration: i
            }
        },
        _getTranslateStr: function(a, b) {
            return this.options.hardwareAccelerated ? "translate3d(" + a + "px," + b + "px,0px) " + this.translateZ : "translate(" + a + "px," + b + "px) "
        },
        setStopped: function(a) {
            this.stopped=!!a
        },
        setTranslate: function(b, c) {
            if (this.x = b, this.y = c, this.scrollerStyle.webkitTransform = this._getTranslateStr(b, c), this.parallaxElement && this.options.scrollY) {
                var d = c * this.options.parallaxRatio, e = 1 + d / ((this.parallaxHeight - d) / 2);
                e > 1 ? (this.parallaxImgStyle.opacity = 1 - d / 100 * this.options.parallaxRatio, this.parallaxStyle.webkitTransform = this._getTranslateStr(0, - d) + " scale(" + e + "," + e + ")") : (this.parallaxImgStyle.opacity = 1, this.parallaxStyle.webkitTransform = this._getTranslateStr(0, - 1) + " scale(1,1)")
            }
            if (this.indicators)
                for (var f = this.indicators.length; f--;)
                    this.indicators[f].updatePosition();
            this.lastX = this.x, this.lastY = this.y, a.trigger(this.scroller, "scroll", this)
        },
        reLayout: function() {
            this.wrapper.offsetHeight;
            var b = parseFloat(a.getStyles(this.wrapper, "padding-left")) || 0, c = parseFloat(a.getStyles(this.wrapper, "padding-right")) || 0, d = parseFloat(a.getStyles(this.wrapper, "padding-top")) || 0, e = parseFloat(a.getStyles(this.wrapper, "padding-bottom")) || 0, f = this.wrapper.clientWidth, g = this.wrapper.clientHeight;
            this.scrollerWidth = this.scroller.offsetWidth, this.scrollerHeight = this.scroller.offsetHeight, this.wrapperWidth = f - b - c, this.wrapperHeight = g - d - e, this.maxScrollX = Math.min(this.wrapperWidth - this.scrollerWidth, 0), this.maxScrollY = Math.min(this.wrapperHeight - this.scrollerHeight, 0), this.hasHorizontalScroll = this.options.scrollX && this.maxScrollX < 0, this.hasVerticalScroll = this.options.scrollY && this.maxScrollY < 0, this._reLayout()
        },
        resetPosition: function(a) {
            var b = this.x, c = this.y;
            return a = a || 0, !this.hasHorizontalScroll || this.x > 0 ? b = 0 : this.x < this.maxScrollX && (b = this.maxScrollX), !this.hasVerticalScroll || this.y > 0 ? c = 0 : this.y < this.maxScrollY && (c = this.maxScrollY), b == this.x && c == this.y?!1 : (this.scrollTo(b, c, a, this.options.bounceEasing), !0)
        },
        refresh: function() {
            this.reLayout(), a.trigger(this.scroller, "refresh", this), this.resetPosition()
        },
        scrollTo: function(a, b, c, d) {
            var d = d || j.circular;
            this.isInTransition = c > 0 && (this.lastX != a || this.lastY != b), this.isInTransition ? (this._clearRequestAnimationFrame(), this._transitionTimingFunction(d.style), this._transitionTime(c), this.setTranslate(a, b)) : this.setTranslate(a, b)
        },
        scrollToBottom: function(a, b) {
            a = a || this.options.bounceTime, this.scrollTo(0, this.maxScrollY, a, b)
        },
        gotoPage: function(a) {
            this._gotoPage(a)
        },
        destory: function() {
            this._initEvent(!0), delete a.data[this.wrapper.getAttribute("data-scroll")], this.wrapper.setAttribute("data-scroll", "")
        }
    }), l = function(b, d) {
        this.wrapper = "string" == typeof d.el ? c.querySelector(d.el) : d.el, this.wrapperStyle = this.wrapper.style, this.indicator = this.wrapper.children[0], this.indicatorStyle = this.indicator.style, this.scroller = b, this.options = a.extend({
            listenX: !0,
            listenY: !0,
            fade: !1,
            speedRatioX: 0,
            speedRatioY: 0
        }, d), this.sizeRatioX = 1, this.sizeRatioY = 1, this.maxPosX = 0, this.maxPosY = 0, this.options.fade && (this.wrapperStyle.webkitTransform = this.scroller.translateZ, this.wrapperStyle.webkitTransitionDuration = this.options.fixedBadAndorid && a.os.isBadAndroid ? "0.001s" : "0ms", this.wrapperStyle.opacity = "0")
    };
    l.prototype = {
        handleEvent: function(a) {},
        transitionTime: function(b) {
            b = b || 0, this.indicatorStyle.webkitTransitionDuration = b + "ms", this.scroller.options.fixedBadAndorid&&!b && a.os.isBadAndroid && (this.indicatorStyle.webkitTransitionDuration = "0.001s")
        },
        transitionTimingFunction: function(a) {
            this.indicatorStyle.webkitTransitionTimingFunction = a
        },
        refresh: function() {
            this.transitionTime(), this.options.listenX&&!this.options.listenY ? this.indicatorStyle.display = this.scroller.hasHorizontalScroll ? "block" : "none" : this.options.listenY&&!this.options.listenX ? this.indicatorStyle.display = this.scroller.hasVerticalScroll ? "block" : "none" : this.indicatorStyle.display = this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? "block" : "none", this.wrapper.offsetHeight, this.options.listenX && (this.wrapperWidth = this.wrapper.clientWidth, this.indicatorWidth = Math.max(Math.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8), this.indicatorStyle.width = this.indicatorWidth + "px", this.maxPosX = this.wrapperWidth - this.indicatorWidth, this.minBoundaryX = 0, this.maxBoundaryX = this.maxPosX, this.sizeRatioX = this.options.speedRatioX || this.scroller.maxScrollX && this.maxPosX / this.scroller.maxScrollX), this.options.listenY && (this.wrapperHeight = this.wrapper.clientHeight, this.indicatorHeight = Math.max(Math.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8), this.indicatorStyle.height = this.indicatorHeight + "px", this.maxPosY = this.wrapperHeight - this.indicatorHeight, this.minBoundaryY = 0, this.maxBoundaryY = this.maxPosY, this.sizeRatioY = this.options.speedRatioY || this.scroller.maxScrollY && this.maxPosY / this.scroller.maxScrollY), this.updatePosition()
        },
        updatePosition: function() {
            var a = this.options.listenX && Math.round(this.sizeRatioX * this.scroller.x) || 0, b = this.options.listenY && Math.round(this.sizeRatioY * this.scroller.y) || 0;
            a < this.minBoundaryX ? (this.width = Math.max(this.indicatorWidth + a, 8), this.indicatorStyle.width = this.width + "px", a = this.minBoundaryX) : a > this.maxBoundaryX ? (this.width = Math.max(this.indicatorWidth - (a - this.maxPosX), 8), this.indicatorStyle.width = this.width + "px", a = this.maxPosX + this.indicatorWidth - this.width) : this.width != this.indicatorWidth && (this.width = this.indicatorWidth, this.indicatorStyle.width = this.width + "px"), b < this.minBoundaryY ? (this.height = Math.max(this.indicatorHeight + 3 * b, 8), this.indicatorStyle.height = this.height + "px", b = this.minBoundaryY) : b > this.maxBoundaryY ? (this.height = Math.max(this.indicatorHeight - 3 * (b - this.maxPosY), 8), this.indicatorStyle.height = this.height + "px", b = this.maxPosY + this.indicatorHeight - this.height) : this.height != this.indicatorHeight && (this.height = this.indicatorHeight, this.indicatorStyle.height = this.height + "px"), this.x = a, this.y = b, this.indicatorStyle.webkitTransform = this.scroller._getTranslateStr(a, b)
        },
        fade: function(a, b) {
            if (!b || this.visible) {
                clearTimeout(this.fadeTimeout), this.fadeTimeout = null;
                var c = a ? 250: 500, d = a ? 0: 300;
                a = a ? "1" : "0", this.wrapperStyle.webkitTransitionDuration = c + "ms", this.fadeTimeout = setTimeout(function(a) {
                    this.wrapperStyle.opacity = a, this.visible =+ a
                }.bind(this, a), d)
            }
        }
    }, a.Scroll = k, a.fn.scroll = function(b) {
        var c = [];
        return this.each(function() {
            var d = null, e = this, f = e.getAttribute("data-scroll");
            if (f)
                d = a.data[f];
            else {
                f=++a.uuid;
                var g = a.extend({}, b);
                e.classList.contains("mui-segmented-control") && (g = a.extend(g, {
                    scrollY: !1,
                    scrollX: !0,
                    indicators: !1,
                    snap: ".mui-control-item"
                })), a.data[f] = d = new k(e, g), e.setAttribute("data-scroll", f)
            }
            c.push(d)
        }), 1 === c.length ? c[0] : c
    }
}(mui, window, document), function(a, b, c, d) {
    var e = "mui-visibility", f = "mui-hidden", g = a.Scroll.extend(a.extend({
        handleEvent: function(a) {
            this._super(a), "scrollbottom" === a.type && a.target === this.scroller && this._scrollbottom()
        },
        _scrollbottom: function() {
            this.pulldown || this.loading || (this.pulldown=!1, this._initPullupRefresh(), this.pullupLoading())
        },
        _start: function(a) {
            this.loading || (this.pulldown = this.pullPocket = this.pullCaption = this.pullLoading=!1), this._super(a)
        },
        _drag: function(a) {
            this._super(a), !this.pulldown&&!this.loading && this.topPocket && "down" === a.detail.direction && this.y >= 0 && this._initPulldownRefresh(), this.pulldown && this._setCaption(this.y > this.options.down.height ? this.options.down.contentover : this.options.down.contentdown)
        },
        _reLayout: function() {
            this.hasVerticalScroll=!0, this._super()
        },
        resetPosition: function(a) {
            if (this.pulldown) {
                if (this.y >= this.options.down.height)
                    return this.pulldownLoading(d, a || 0), !0;
                !this.loading && this.topPocket.classList.remove(e)
            }
            return this._super(a)
        },
        pulldownLoading: function(a, b) {
            if ("undefined" == typeof a && (a = this.options.down.height), this.scrollTo(0, a, b, this.options.bounceEasing), !this.loading) {
                this._initPulldownRefresh(), this._setCaption(this.options.down.contentrefresh), this.loading=!0, this.indicators.map(function(a) {
                    a.fade(0)
                });
                var c = this.options.down.callback;
                c && c.call(this)
            }
        },
        endPulldownToRefresh: function() {
            var a = this;
            a.topPocket && a.loading && this.pulldown && (a.scrollTo(0, 0, a.options.bounceTime, a.options.bounceEasing), a.loading=!1, a._setCaption(a.options.down.contentdown, !0), setTimeout(function() {
                a.loading || a.topPocket.classList.remove(e)
            }, 350))
        },
        pullupLoading: function(a, b, c) {
            b = b || 0, this.scrollTo(b, this.maxScrollY, c, this.options.bounceEasing), this.loading || (this._initPullupRefresh(), this._setCaption(this.options.up.contentrefresh), this.indicators.map(function(a) {
                a.fade(0)
            }), this.loading=!0, a = a || this.options.up.callback, a && a.call(this))
        },
        endPullupToRefresh: function(a) {
            var b = this;
            b.bottomPocket && (b.loading=!1, a ? (this.finished=!0, b._setCaption(b.options.up.contentnomore), b.wrapper.removeEventListener("scrollbottom", b)) : (b._setCaption(b.options.up.contentdown), b.loading || b.bottomPocket.classList.remove(e)))
        },
        disablePullupToRefresh: function() {
            this._initPullupRefresh(), this.bottomPocket.className = "mui-pull-bottom-pocket " + f, this.wrapper.removeEventListener("scrollbottom", this)
        },
        enablePullupToRefresh: function() {
            this._initPullupRefresh(), this.bottomPocket.classList.remove(f), this._setCaption(this.options.up.contentdown), this.wrapper.addEventListener("scrollbottom", this)
        },
        refresh: function(a) {
            a && this.finished && (this.enablePullupToRefresh(), this.finished=!1), this._super()
        }
    }, a.PullRefresh));
    a.fn.pullRefresh = function(b) {
        if (1 === this.length) {
            var c = this[0], d = null;
            b = b || {};
            var e = c.getAttribute("data-pullrefresh");
            return e ? d = a.data[e] : (e=++a.uuid, a.data[e] = d = new g(c, b), c.setAttribute("data-pullrefresh", e)), b.down && b.down.auto ? d.pulldownLoading(b.down.autoY) : b.up && b.up.auto && d.pullupLoading(), d
        }
    }
}(mui, window, document), function(a, b) {
    var c = "mui-slider", d = "mui-slider-group", e = "mui-slider-loop", f = "mui-slider-indicator", g = "mui-action-previous", h = "mui-action-next", i = "mui-slider-item", j = "mui-active", k = "." + i, l = "." + f, m = ".mui-slider-progress-bar", n = a.Slider = a.Scroll.extend({
        init: function(b, c) {
            this._super(b, a.extend(!0, {
                fingers: 1,
                interval: 0,
                scrollY: !1,
                scrollX: !0,
                indicators: !1,
                bounceTime: 200,
                startX: !1,
                snap: k
            }, c)), this.options.startX
        },
        _init: function() {
            for (var a = this.wrapper.querySelectorAll("." + d), b = 0, c = a.length; c > b; b++)
                if (a[b].parentNode === this.wrapper) {
                    this.scroller = a[b];
                    break
                }
            this.scroller && (this.scrollerStyle = this.scroller.style, this.progressBar = this.wrapper.querySelector(m), this.progressBar && (this.progressBarWidth = this.progressBar.offsetWidth, this.progressBarStyle = this.progressBar.style), this._super(), this._initTimer())
        },
        _triggerSlide: function() {
            var b = this;
            b.isInTransition=!1;
            b.currentPage;
            b.slideNumber = b._fixedSlideNumber(), b.loop && (0 === b.slideNumber ? b.setTranslate(b.pages[1][0].x, 0) : b.slideNumber === b.itemLength - 3 && b.setTranslate(b.pages[b.itemLength - 2][0].x, 0)), b.lastSlideNumber != b.slideNumber && (b.lastSlideNumber = b.slideNumber, b.lastPage = b.currentPage, a.trigger(b.wrapper, "slide", {
                slideNumber: b.slideNumber
            })), b._initTimer()
        },
        _handleSlide: function(b) {
            var c = this;
            if (b.target === c.wrapper) {
                var d = b.detail;
                d.slideNumber = d.slideNumber || 0;
                var e = c.scroller.querySelectorAll(k), f = d.slideNumber;
                if (c.loop && (f += 1), !c.wrapper.classList.contains("mui-segmented-control"))
                    for (var g = 0, h = e.length; h > g; g++) {
                        var i = e[g];
                        i.parentNode === c.scroller && (g === f ? i.classList.add(j) : i.classList.remove(j))
                    }
                var l = c.wrapper.querySelector(".mui-slider-indicator");
                if (l) {
                    l.getAttribute("data-scroll") && a(l).scroll().gotoPage(d.slideNumber);
                    var m = l.querySelectorAll(".mui-indicator");
                    if (m.length > 0)
                        for (var g = 0, h = m.length; h > g; g++)
                            m[g].classList[g === d.slideNumber ? "add": "remove"](j);
                    else {
                        var n = l.querySelector(".mui-number span");
                        if (n)
                            n.innerText = d.slideNumber + 1;
                        else 
                            for (var o = c.wrapper.querySelectorAll(".mui-control-item"), g = 0, h = o.length; h > g; g++)
                                o[g].classList[g === d.slideNumber ? "add": "remove"](j)
                            }
                }
                b.stopPropagation()
            }
        },
        _handleTabShow: function(a) {
            var b = this;
            b.gotoItem(a.detail.tabNumber || 0, b.options.bounceTime)
        },
        _handleIndicatorTap: function(a) {
            var b = this, c = a.target;
            (c.classList.contains(g) || c.classList.contains(h)) && (b[c.classList.contains(g) ? "prevItem": "nextItem"](), a.stopPropagation())
        },
        _initEvent: function(b) {
            var c = this;
            c._super(b);
            var d = b ? "removeEventListener": "addEventListener";
            c.wrapper[d]("swiperight", a.stopPropagation), c.wrapper[d]("scrollend", c._triggerSlide.bind(this)), c.wrapper[d]("slide", c._handleSlide.bind(this)), c.wrapper[d](a.eventName("shown", "tab"), c._handleTabShow.bind(this));
            var e = c.wrapper.querySelector(l);
            e && e[d]("tap", c._handleIndicatorTap.bind(this))
        },
        _drag: function(a) {
            this._super(a);
            var c = a.detail.direction;
            if ("left" === c || "right" === c) {
                var d = this.wrapper.getAttribute("data-slidershowTimer");
                d && b.clearTimeout(d), a.stopPropagation()
            }
        },
        _initTimer: function() {
            var a = this, c = a.wrapper, d = a.options.interval, e = c.getAttribute("data-slidershowTimer");
            e && b.clearTimeout(e), d && (e = b.setTimeout(function() {
                c && ((c.offsetWidth || c.offsetHeight) && a.nextItem(!0), a._initTimer())
            }, d), c.setAttribute("data-slidershowTimer", e))
        },
        _fixedSlideNumber: function(a) {
            a = a || this.currentPage;
            var b = a.pageX;
            return this.loop && (b = 0 === a.pageX ? this.itemLength - 3 : a.pageX === this.itemLength - 1 ? 0 : a.pageX - 1), b
        },
        _reLayout: function() {
            this.hasHorizontalScroll=!0, this.loop = this.scroller.classList.contains(e), this._super()
        },
        _getScroll: function() {
            var b = a.parseTranslateMatrix(a.getStyles(this.scroller, "webkitTransform"));
            return b ? b.x : 0
        },
        _transitionEnd: function(b) {
            b.target === this.scroller && this.isInTransition && (this._transitionTime(), this.isInTransition=!1, a.trigger(this.wrapper, "scrollend", this))
        },
        _flick: function(a) {
            if (this.moved) {
                var b = a.detail, c = b.direction;
                this._clearRequestAnimationFrame(), this.isInTransition=!0, "flick" === a.type ? (b.deltaTime < 200 && (this.x = this._getPage(this.slideNumber + ("right" === c?-1 : 1), !0).x), this.resetPosition(this.options.bounceTime)) : "dragend" !== a.type || b.flick || this.resetPosition(this.options.bounceTime), a.stopPropagation()
            }
        },
        _initSnap: function() {
            if (this.scrollerWidth = this.itemLength * this.scrollerWidth, this.maxScrollX = Math.min(this.wrapperWidth - this.scrollerWidth, 0), this._super(), this.currentPage.x)
                this.slideNumber = this._fixedSlideNumber(), this.lastSlideNumber = "undefined" == typeof this.lastSlideNumber ? this.slideNumber : this.lastSlideNumber;
            else {
                var a = this.pages[this.loop ? 1: 0];
                if (a = a || this.pages[0], !a)
                    return;
                this.currentPage = a[0], this.slideNumber = 0, this.lastSlideNumber = "undefined" == typeof this.lastSlideNumber ? 0 : this.lastSlideNumber
            }
            this.options.startX = this.currentPage.x || 0
        },
        _getSnapX: function(a) {
            return Math.max( - a, this.maxScrollX)
        },
        _getPage: function(a, b) {
            return this.loop ? a > this.itemLength - (b ? 2 : 3) ? (a = 1, time = 0) : (b?-1 : 0) > a ? (a = this.itemLength - 2, time = 0) : a += 1 : (b || (a > this.itemLength - 1 ? (a = 0, time = 0) : 0 > a && (a = this.itemLength - 1, time = 0)), a = Math.min(Math.max(0, a), this.itemLength - 1)), this.pages[a][0]
        },
        _gotoItem: function(b, c) {
            this.currentPage = this._getPage(b, !0), this.scrollTo(this.currentPage.x, 0, c, this.options.bounceEasing), 0 === c && a.trigger(this.wrapper, "scrollend", this)
        },
        setTranslate: function(a, b) {
            this._super(a, b);
            var c = this.progressBar;
            c && (this.progressBarStyle.webkitTransform = this._getTranslateStr( - a * (this.progressBarWidth / this.wrapperWidth), 0))
        },
        resetPosition: function(a) {
            return a = a || 0, this.x > 0 ? this.x = 0 : this.x < this.maxScrollX && (this.x = this.maxScrollX), this.currentPage = this._nearestSnap(this.x), this.scrollTo(this.currentPage.x, 0, a), !0
        },
        gotoItem: function(a, b) {
            this._gotoItem(a, "undefined" == typeof b ? this.options.bounceTime : b)
        },
        nextItem: function() {
            this._gotoItem(this.slideNumber + 1, this.options.bounceTime)
        },
        prevItem: function() {
            this._gotoItem(this.slideNumber - 1, this.options.bounceTime)
        },
        getSlideNumber: function() {
            return this.slideNumber || 0
        },
        refresh: function(b) {
            b ? (a.extend(this.options, b), this._super(), this.nextItem()) : this._super()
        },
        destory: function() {
            this._initEvent(!0), delete a.data[this.wrapper.getAttribute("data-slider")], this.wrapper.setAttribute("data-slider", "")
        }
    });
    a.fn.slider = function(b) {
        var d = null;
        return this.each(function() {
            var e = this;
            if (this.classList.contains(c) || (e = this.querySelector("." + c)), e && e.querySelector(k)) {
                var f = e.getAttribute("data-slider");
                f ? (d = a.data[f], d && b && d.refresh(b)) : (f=++a.uuid, a.data[f] = d = new n(e, b), e.setAttribute("data-slider", f))
            }
        }), d
    }, a.ready(function() {
        a(".mui-slider").slider(), a(".mui-scroll-wrapper.mui-slider-indicator.mui-segmented-control").scroll({
            scrollY: !1,
            scrollX: !0,
            indicators: !1,
            snap: ".mui-control-item"
        })
    })
}(mui, window), function(a, b) {
    if (a.os.plus && a.os.android) {
        var c = "mui-plus-pullrefresh", d = "mui-visibility", e = "mui-hidden", f = "mui-block", g = "mui-pull-caption", h = "mui-pull-caption-down", i = "mui-pull-caption-refresh", j = "mui-pull-caption-nomore", k = a.Class.extend({
            init: function(a, b) {
                this.element = a, this.options = b, this.wrapper = this.scroller = a, this._init(), this._initPulldownRefreshEvent()
            },
            _init: function() {
                var a = this;
                window.addEventListener("dragup", a), a.scrollInterval = window.setInterval(function() {
                    a.isScroll&&!a.loading && window.pageYOffset + window.innerHeight + 10 >= b.documentElement.scrollHeight && (a.isScroll=!1, a.bottomPocket && a.pullupLoading())
                }, 100)
            },
            _initPulldownRefreshEvent: function() {
                var b = this;
                b.topPocket && b.options.webviewId && a.plusReady(function() {
                    var a = plus.webview.getWebviewById(b.options.webviewId);
                    if (a) {
                        b.options.webview = a;
                        var c = b.options.down, d = c.height;
                        a.addEventListener("dragBounce", function(d) {
                            switch (b.pulldown ? b.pullPocket.classList.add(f) : b._initPulldownRefresh(), d.status) {
                            case"beforeChangeOffset":
                                b._setCaption(c.contentdown);
                                break;
                            case"afterChangeOffset":
                                b._setCaption(c.contentover);
                                break;
                            case"dragEndAfterChangeOffset":
                                a.evalJS("mui&&mui.options.pullRefresh.down.callback()"), b._setCaption(c.contentrefresh)
                            }
                        }, !1), a.setBounce({
                            position: {
                                top: 2 * d + "px"
                            },
                            changeoffset: {
                                top: d + "px"
                            }
                        })
                    }
                })
            },
            handleEvent: function(a) {
                var b = this;
                b.stopped || (b.isScroll=!1, "dragup" === a.type && (b.isScroll=!0, setTimeout(function() {
                    b.isScroll=!1
                }, 1e3)))
            }
        }).extend(a.extend({
            setStopped: function(a) {
                this.stopped=!!a;
                var b = plus.webview.currentWebview();
                if (this.stopped)
                    b.setStyle({
                        bounce: "none"
                    }), b.setBounce({
                        position: {
                            top: "none"
                        }
                    });
                else {
                    var c = this.options.down.height;
                    b.setStyle({
                        bounce: "vertical"
                    }), b.setBounce({
                        position: {
                            top: 2 * c + "px"
                        },
                        changeoffset: {
                            top: c + "px"
                        }
                    })
                }
            },
            pulldownLoading: function() {
                var b = a.options.pullRefresh.down.callback;
                b && b.call(this)
            },
            _pulldownLoading: function() {
                var b = this;
                a.plusReady(function() {
                    plus.webview.getWebviewById(b.options.webviewId).evalJS("mui&&mui.options.pullRefresh.down&&mui.options.pullRefresh.down.callback()")
                })
            },
            endPulldownToRefresh: function() {
                var a = plus.webview.currentWebview();
                a.parent().evalJS("mui&&mui(document.querySelector('.mui-content')).pullRefresh('" + JSON.stringify({
                    webviewId: a.id
                }) + "')._endPulldownToRefresh()")
            },
            _endPulldownToRefresh: function() {
                var a = this;
                a.topPocket && a.options.webview && (a.options.webview.endPullToRefresh(), a.loading=!1, a._setCaption(a.options.down.contentdown, !0), setTimeout(function() {
                    a.loading || a.topPocket.classList.remove(f)
                }, 350))
            },
            pullupLoading: function(a) {
                var b = this;
                b.isLoading || (b.isLoading=!0, b.pulldown!==!1 ? b._initPullupRefresh() : this.pullPocket.classList.add(f), setTimeout(function() {
                    b.pullLoading.classList.add(d), b.pullLoading.classList.remove(e), b.pullCaption.innerHTML = "", b.pullCaption.className = g + " " + i, b.pullCaption.innerHTML = b.options.up.contentrefresh, a = a || b.options.up.callback, a && a.call(b)
                }, 300))
            },
            endPullupToRefresh: function(a) {
                var b = this;
                b.pullLoading && (b.pullLoading.classList.remove(d), b.pullLoading.classList.add(e), b.isLoading=!1, a ? (b.finished=!0, b.pullCaption.className = g + " " + j, b.pullCaption.innerHTML = b.options.up.contentnomore, window.removeEventListener("dragup", b)) : (b.pullCaption.className = g + " " + h, b.pullCaption.innerHTML = b.options.up.contentdown))
            },
            disablePullupToRefresh: function() {
                this._initPullupRefresh(), this.bottomPocket.className = "mui-pull-bottom-pocket " + e, window.removeEventListener("dragup", this)
            },
            enablePullupToRefresh: function() {
                this._initPullupRefresh(), this.bottomPocket.classList.remove(e), this.pullCaption.className = g + " " + h, this.pullCaption.innerHTML = this.options.up.contentdown, window.addEventListener("dragup", this)
            },
            scrollTo: function(b, c, d) {
                a.scrollTo(b, c, d)
            },
            refresh: function(a) {
                a && this.finished && (this.enablePullupToRefresh(), this.finished=!1)
            }
        }, a.PullRefresh));
        a.fn.pullRefresh = function(d) {
            var e;
            0 === this.length ? (e = b.createElement("div"), e.className = "mui-content", b.body.appendChild(e)) : e = this[0], d = d || {}, "string" == typeof d && (d = a.parseJSON(d)), !d.webviewId && (d.webviewId = plus.webview.currentWebview().id || plus.webview.currentWebview().getURL());
            var f = null, g = d.webviewId && d.webviewId.replace(/\//g, "_"), h = e.getAttribute("data-pullrefresh-plus-" + g);
            return h ? f = a.data[h] : (h=++a.uuid, e.setAttribute("data-pullrefresh-plus-" + g, h), b.body.classList.add(c), a.data[h] = f = new k(e, d)), d.down && d.down.auto ? f._pulldownLoading() : d.up && d.up.auto && f.pullupLoading(), f
        }
    }
}(mui, document), function(a, b, c, d) {
    var e = "mui-off-canvas-left", f = "mui-off-canvas-right", g = "mui-off-canvas-backdrop", h = "mui-off-canvas-wrap", i = "mui-slide-in", j = "mui-active", k = "mui-transitioning", l = ".mui-inner-wrap", m = a.Class.extend({
        init: function(b, d) {
            this.wrapper = this.element = b, this.scroller = this.wrapper.querySelector(l), this.classList = this.wrapper.classList, this.scroller && (this.options = a.extend(!0, {
                dragThresholdX: 10,
                scale: .8,
                opacity: .1,
                preventDefaultException: {
                    tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT|VIDEO)$/
                }
            }, d), c.body.classList.add("mui-fullscreen"), this.refresh(), this.initEvent())
        },
        _preventDefaultException: function(a, b) {
            for (var c in b)
                if (b[c].test(a[c]))
                    return !0;
            return !1
        },
        refresh: function(a) {
            this.slideIn = this.classList.contains(i), this.scalable = this.classList.contains("mui-scalable")&&!this.slideIn, this.scroller = this.wrapper.querySelector(l), this.offCanvasLefts = this.wrapper.querySelectorAll("." + e), this.offCanvasRights = this.wrapper.querySelectorAll("." + f), a ? a.classList.contains(e) ? this.offCanvasLeft = a : a.classList.contains(f) && (this.offCanvasRight = a) : (this.offCanvasRight = this.wrapper.querySelector("." + f), this.offCanvasLeft = this.wrapper.querySelector("." + e)), this.offCanvasRightWidth = this.offCanvasLeftWidth = 0, this.offCanvasLeftSlideIn = this.offCanvasRightSlideIn=!1, this.offCanvasRight && (this.offCanvasRightWidth = this.offCanvasRight.offsetWidth, this.offCanvasRightSlideIn = this.slideIn && this.offCanvasRight.parentNode === this.wrapper), this.offCanvasLeft && (this.offCanvasLeftWidth = this.offCanvasLeft.offsetWidth, this.offCanvasLeftSlideIn = this.slideIn && this.offCanvasLeft.parentNode === this.wrapper), this.backdrop = this.scroller.querySelector("." + g), this.options.dragThresholdX = this.options.dragThresholdX || 10, this.visible=!1, this.startX = null, this.lastX = null, this.offsetX = null, this.lastTranslateX = null
        },
        handleEvent: function(b) {
            switch (b.type) {
            case"touchstart":
                b.target&&!this._preventDefaultException(b.target, this.options.preventDefaultException) && b.preventDefault();
                break;
            case"webkitTransitionEnd":
                b.target === this.scroller && this._dispatchEvent();
                break;
            case"drag":
                var c = b.detail;
                this.startX ? this.lastX = c.center.x : (this.startX = c.center.x, this.lastX = this.startX), !this.isDragging && Math.abs(this.lastX - this.startX) > this.options.dragThresholdX && ("left" === c.direction || "right" === c.direction) && (this.slideIn ? (this.scroller = this.wrapper.querySelector(l), this.classList.contains(j) ? this.offCanvasRight && this.offCanvasRight.classList.contains(j) ? (this.offCanvas = this.offCanvasRight, this.offCanvasWidth = this.offCanvasRightWidth) : (this.offCanvas = this.offCanvasLeft, this.offCanvasWidth = this.offCanvasLeftWidth) : "left" === c.direction && this.offCanvasRight ? (this.offCanvas = this.offCanvasRight, this.offCanvasWidth = this.offCanvasRightWidth) : "right" === c.direction && this.offCanvasLeft ? (this.offCanvas = this.offCanvasLeft, this.offCanvasWidth = this.offCanvasLeftWidth) : this.scroller = null) : this.classList.contains(j) ? "left" === c.direction ? (this.offCanvas = this.offCanvasLeft, this.offCanvasWidth = this.offCanvasLeftWidth) : (this.offCanvas = this.offCanvasRight, this.offCanvasWidth = this.offCanvasRightWidth) : "right" === c.direction ? (this.offCanvas = this.offCanvasLeft, this.offCanvasWidth = this.offCanvasLeftWidth) : (this.offCanvas = this.offCanvasRight, this.offCanvasWidth = this.offCanvasRightWidth), this.offCanvas && this.scroller && (this.startX = this.lastX, this.isDragging=!0, a.gestures.session.lockDirection=!0, a.gestures.session.startDirection = c.direction, this.offCanvas.classList.remove(k), this.scroller.classList.remove(k), this.offsetX = this.getTranslateX(), this._initOffCanvasVisible())), this.isDragging && (this.updateTranslate(this.offsetX + (this.lastX - this.startX)), c.gesture.preventDefault(), b.stopPropagation());
                break;
            case"dragend":
                if (this.isDragging) {
                    var c = b.detail, d = c.direction;
                    this.isDragging=!1, this.offCanvas.classList.add(k), this.scroller.classList.add(k);
                    var e = 0, f = this.getTranslateX();
                    if (this.slideIn) {
                        if (e = f >= 0 ? this.offCanvasRightWidth && f / this.offCanvasRightWidth || 0 : this.offCanvasLeftWidth && f / this.offCanvasLeftWidth || 0, e >= .5 && "left" === d ? this.openPercentage(0) : e > 0 && .5 >= e && "left" === d ? this.openPercentage( - 100) : e >= .5 && "right" === d ? this.openPercentage(0) : e>=-.5 && 0 > e && "left" === d ? this.openPercentage(100) : e > 0 && .5 >= e && "right" === d ? this.openPercentage( - 100) : - .5 >= e && "right" === d ? this.openPercentage(0) : e>=-.5 && "right" === d ? this.openPercentage(100) : - .5 >= e && "left" === d ? this.openPercentage(0) : e>=-.5 && "left" === d ? this.openPercentage( - 100) : this.openPercentage(0), 1 === e||-1 === e || 0 === e)
                            return void this._dispatchEvent()
                    } else {
                        if (e = f >= 0 ? this.offCanvasLeftWidth && f / this.offCanvasLeftWidth || 0 : this.offCanvasRightWidth && f / this.offCanvasRightWidth || 0, 0 === e)
                            return this.openPercentage(0), void this._dispatchEvent();
                        e > 0 && .5 > e && "right" === d ? this.openPercentage(0) : e > .5 && "left" === d ? this.openPercentage(100) : 0 > e && e>-.5 && "left" === d ? this.openPercentage(0) : "right" === d && 0 > e && e>-.5 ? this.openPercentage(0) : .5 > e && "right" === d ? this.openPercentage( - 100) : "right" === d && e >= 0 && (e >= .5 || c.flick) ? this.openPercentage(100) : "left" === d && 0 >= e && ( - .5 >= e || c.flick) ? this.openPercentage( - 100) : this.openPercentage(0), (1 === e||-1 === e) && this._dispatchEvent()
                    }
                }
            }
        },
        _dispatchEvent: function() {
            this.classList.contains(j) ? a.trigger(this.wrapper, "shown", this) : a.trigger(this.wrapper, "hidden", this)
        },
        _initOffCanvasVisible: function() {
            this.visible || (this.visible=!0, this.offCanvasLeft && (this.offCanvasLeft.style.visibility = "visible"), this.offCanvasRight && (this.offCanvasRight.style.visibility = "visible"))
        },
        initEvent: function() {
            var a = this;
            a.backdrop && a.backdrop.addEventListener("tap", function(b) {
                a.close(), b.detail.gesture.preventDefault()
            }), this.classList.contains("mui-draggable") && (this.wrapper.addEventListener("touchstart", this), this.wrapper.addEventListener("drag", this), this.wrapper.addEventListener("dragend", this)), this.wrapper.addEventListener("webkitTransitionEnd", this)
        },
        openPercentage: function(a) {
            var b = a / 100;
            this.slideIn ? (this.offCanvasLeft && a >= 0 ? (b = 0 === b?-1 : 0, this.updateTranslate(this.offCanvasLeftWidth * b), this.offCanvasLeft.classList[0 !== a ? "add": "remove"](j)) : this.offCanvasRight && 0 >= a && (b = 0 === b ? 1 : 0, this.updateTranslate(this.offCanvasRightWidth * b), this.offCanvasRight.classList[0 !== a ? "add": "remove"](j)), this.classList[0 !== a ? "add": "remove"](j)) : (this.offCanvasLeft && a >= 0 ? (this.updateTranslate(this.offCanvasLeftWidth * b), this.offCanvasLeft.classList[0 !== b ? "add": "remove"](j)) : this.offCanvasRight && 0 >= a && (this.updateTranslate(this.offCanvasRightWidth * b), this.offCanvasRight.classList[0 !== b ? "add": "remove"](j)), this.classList[0 !== b ? "add": "remove"](j))
        },
        updateTranslate: function(b) {
            if (b !== this.lastTranslateX) {
                if (this.slideIn) {
                    if (this.offCanvas.classList.contains(f)) {
                        if (0 > b)
                            return void this.setTranslateX(0);
                        if (b > this.offCanvasRightWidth)
                            return void this.setTranslateX(this.offCanvasRightWidth)
                    } else {
                        if (b > 0)
                            return void this.setTranslateX(0);
                        if (b<-this.offCanvasLeftWidth)
                            return void this.setTranslateX( - this.offCanvasLeftWidth)
                    }
                    this.setTranslateX(b)
                } else {
                    if (!this.offCanvasLeft && b > 0 ||!this.offCanvasRight && 0 > b)
                        return void this.setTranslateX(0);
                    if (this.leftShowing && b > this.offCanvasLeftWidth)
                        return void this.setTranslateX(this.offCanvasLeftWidth);
                    if (this.rightShowing && b<-this.offCanvasRightWidth)
                        return void this.setTranslateX( - this.offCanvasRightWidth);
                    this.setTranslateX(b), b >= 0 ? (this.leftShowing=!0, this.rightShowing=!1, b > 0 && (this.offCanvasLeft && a.each(this.offCanvasLefts, function(a, b) {
                        b === this.offCanvasLeft ? this.offCanvasLeft.style.zIndex = 0 : b.style.zIndex =- 1
                    }.bind(this)), this.offCanvasRight && (this.offCanvasRight.style.zIndex =- 1))) : (this.rightShowing=!0, this.leftShowing=!1, this.offCanvasRight && a.each(this.offCanvasRights, function(a, b) {
                        b === this.offCanvasRight ? b.style.zIndex = 0 : b.style.zIndex =- 1
                    }.bind(this)), this.offCanvasLeft && (this.offCanvasLeft.style.zIndex =- 1))
                }
                this.lastTranslateX = b
            }
        },
        setTranslateX: a.animationFrame(function(a) {
            if (this.scroller)
                if (this.scalable && this.offCanvas.parentNode === this.wrapper) {
                    var b = Math.abs(a) / this.offCanvasWidth, c = 1 - (1 - this.options.scale) * b, d = this.options.scale + (1 - this.options.scale) * b, f = (1 - (1 - this.options.opacity) * b, this.options.opacity + (1 - this.options.opacity) * b);
                    this.offCanvas.classList.contains(e) ? (this.offCanvas.style.webkitTransformOrigin = "-100%", this.scroller.style.webkitTransformOrigin = "left") : (this.offCanvas.style.webkitTransformOrigin = "200%", this.scroller.style.webkitTransformOrigin = "right"), this.offCanvas.style.opacity = f, this.offCanvas.style.webkitTransform = "translate3d(0,0,0) scale(" + d + ")", this.scroller.style.webkitTransform = "translate3d(" + a + "px,0,0) scale(" + c + ")"
                } else 
                    this.slideIn ? this.offCanvas.style.webkitTransform = "translate3d(" + a + "px,0,0)" : this.scroller.style.webkitTransform = "translate3d(" + a + "px,0,0)"
        }),
        getTranslateX: function() {
            if (this.offCanvas) {
                var b = this.slideIn ? this.offCanvas: this.scroller, c = a.parseTranslateMatrix(a.getStyles(b, "webkitTransform"));
                return c && c.x || 0
            }
            return 0
        },
        isShown: function(a) {
            var b=!1;
            if (this.slideIn)
                b = "left" === a ? this.classList.contains(j) && this.wrapper.querySelector("." + e + "." + j) : "right" === a ? this.classList.contains(j) && this.wrapper.querySelector("." + f + "." + j) : this.classList.contains(j) && (this.wrapper.querySelector("." + e + "." + j) || this.wrapper.querySelector("." + f + "." + j));
            else {
                var c = this.getTranslateX();
                b = "right" === a ? this.classList.contains(j) && 0 > c : "left" === a ? this.classList.contains(j) && c > 0 : this.classList.contains(j) && 0 !== c
            }
            return b
        },
        close: function() {
            this._initOffCanvasVisible(), this.offCanvas = this.wrapper.querySelector("." + f + "." + j) || this.wrapper.querySelector("." + e + "." + j), this.offCanvasWidth = this.offCanvas.offsetWidth, this.scroller && (this.offCanvas.offsetHeight, this.offCanvas.classList.add(k), this.scroller.classList.add(k), this.openPercentage(0))
        },
        show: function(a) {
            return this._initOffCanvasVisible(), this.isShown(a)?!1 : (a || (a = this.wrapper.querySelector("." + f) ? "right" : "left"), "right" === a ? (this.offCanvas = this.offCanvasRight, this.offCanvasWidth = this.offCanvasRightWidth) : (this.offCanvas = this.offCanvasLeft, this.offCanvasWidth = this.offCanvasLeftWidth), this.scroller && (this.offCanvas.offsetHeight, this.offCanvas.classList.add(k), this.scroller.classList.add(k), this.openPercentage("left" === a ? 100 : - 100)), !0)
        },
        toggle: function(a) {
            var b = a;
            a && a.classList && (b = a.classList.contains(e) ? "left" : "right", this.refresh(a)), this.show(b) || this.close()
        }
    }), n = function(a) {
        if (parentNode = a.parentNode, parentNode) {
            if (parentNode.classList.contains(h))
                return parentNode;
            if (parentNode = parentNode.parentNode, parentNode.classList.contains(h))
                return parentNode
        }
    }, o = function(b, d) {
        if ("A" === d.tagName && d.hash) {
            var e = c.getElementById(d.hash.replace("#", ""));
            if (e) {
                var f = n(e);
                if (f)
                    return a.targets._container = f, e
            }
        }
        return !1
    };
    a.registerTarget({
        name: d,
        index: 60,
        handle: o,
        target: !1,
        isReset: !1,
        isContinue: !0
    }), b.addEventListener("tap", function(b) {
        if (a.targets.offcanvas)
            for (var d = b.target; d && d !== c; d = d.parentNode)
                if ("A" === d.tagName && d.hash && d.hash === "#" + a.targets.offcanvas.id) {
                    b.detail && b.detail.gesture && b.detail.gesture.preventDefault(), a(a.targets._container).offCanvas().toggle(a.targets.offcanvas), a.targets.offcanvas = a.targets._container = null;
                    break
                }
    }), a.fn.offCanvas = function(b) {
        var c = [];
        return this.each(function() {
            var d = null, e = this;
            e.classList.contains(h) || (e = n(e));
            var f = e.getAttribute("data-offCanvas");
            f ? d = a.data[f] : (f=++a.uuid, a.data[f] = d = new m(e, b), e.setAttribute("data-offCanvas", f)), ("show" === b || "close" === b || "toggle" === b) && d.toggle(), c.push(d)
        }), 1 === c.length ? c[0] : c
    }, a.ready(function() {
        a(".mui-off-canvas-wrap").offCanvas()
    })
}(mui, window, document, "offcanvas"), function(a, b) {
    var c = "mui-action", d = function(a, b) {
        var d = b.className || "";
        return "string" != typeof d && (d = ""), d&&~d.indexOf(c) ? (b.classList.contains("mui-action-back") && a.preventDefault(), b) : !1
    };
    a.registerTarget({
        name: b,
        index: 50,
        handle: d,
        target: !1,
        isContinue: !0
    })
}(mui, "action"), function(a, b, c, d) {
    var e = "mui-modal", f = function(a, b) {
        if ("A" === b.tagName && b.hash) {
            var d = c.getElementById(b.hash.replace("#", ""));
            if (d && d.classList.contains(e))
                return d
        }
        return !1
    };
    a.registerTarget({
        name: d,
        index: 50,
        handle: f,
        target: !1,
        isReset: !1,
        isContinue: !0
    }), b.addEventListener("tap", function(b) {
        a.targets.modal && (b.detail.gesture.preventDefault(), a.targets.modal.classList.toggle("mui-active"))
    })
}(mui, window, document, "modal"), function(a, b, c, d) {
    var e = "mui-popover", f = "mui-popover-arrow", g = "mui-popover-action", h = "mui-backdrop", i = "mui-bar-popover", j = "mui-bar-backdrop", k = "mui-backdrop-action", l = "mui-active", m = "mui-bottom", n = function(b, d) {
        if ("A" === d.tagName && d.hash) {
            if (a.targets._popover = c.getElementById(d.hash.replace("#", "")), a.targets._popover && a.targets._popover.classList.contains(e))
                return d;
            a.targets._popover = null
        }
        return !1
    };
    a.registerTarget({
        name: d,
        index: 60,
        handle: n,
        target: !1,
        isReset: !1,
        isContinue: !0
    });
    var o = function(a) {}, p = function(b) {
        this.removeEventListener("webkitTransitionEnd", p), this.addEventListener("touchmove", a.preventDefault), a.trigger(this, "shown", this)
    }, q = function(b) {
        u(this, "none"), this.removeEventListener("webkitTransitionEnd", q), this.removeEventListener("touchmove", a.preventDefault), o(!1), a.trigger(this, "hidden", this)
    }, r = function() {
        var b = c.createElement("div");
        return b.classList.add(h), b.addEventListener("touchmove", a.preventDefault), b.addEventListener("tap", function(b) {
            var d = a.targets._popover;
            d && (d.addEventListener("webkitTransitionEnd", q), d.classList.remove(l), s(d), c.body.setAttribute("style", ""))
        }), b
    }(), s = function(b) {
        r.setAttribute("style", "opacity:0"), a.targets.popover = a.targets._popover = null, setTimeout(function() {
            !b.classList.contains(l) && r.parentNode && r.parentNode === c.body && c.body.removeChild(r)
        }, 350)
    };
    b.addEventListener("tap", function(b) {
        if (a.targets.popover) {
            for (var d=!1, e = b.target; e && e !== c; e = e.parentNode)
                e === a.targets.popover && (d=!0);
            d && (b.detail.gesture.preventDefault(), t(a.targets._popover, a.targets.popover))
        }
    });
    var t = function(a, b) {
        a.removeEventListener("webkitTransitionEnd", p), a.removeEventListener("webkitTransitionEnd", q), r.classList.remove(j), r.classList.remove(k);
        var d = c.querySelector(".mui-popover.mui-active");
        if (d && (d.addEventListener("webkitTransitionEnd", q), d.classList.remove(l), a === d))
            return void s(d);
        var e=!1;
        (a.classList.contains(i) || a.classList.contains(g)) && (a.classList.contains(g) ? (e=!0, r.classList.add(k)) : r.classList.add(j)), u(a, "block"), a.offsetHeight, a.classList.add(l), r.setAttribute("style", ""), c.body.appendChild(r), o(!0), v(a, b, e), r.classList.add(l), a.addEventListener("webkitTransitionEnd", p)
    }, u = function(a, b, c, d) {
        var e = a.style;
        "undefined" != typeof b && (e.display = b), "undefined" != typeof c && (e.top = c + "px"), "undefined" != typeof d && (e.left = d + "px")
    }, v = function(d, e, h) {
        if (d && e) {
            if (h)
                return void u(d, "block");
            var i = b.innerWidth, j = b.innerHeight, k = d.offsetWidth, l = d.offsetHeight, n = e.offsetWidth, o = e.offsetHeight, p = a.offset(e), q = d.querySelector("." + f);
            q || (q = c.createElement("div"), q.className = f, d.appendChild(q));
            var r = q && q.offsetWidth / 2 || 0, s = 0, t = 0, v = 0, w = 0, x = d.classList.contains(g) ? 0: 5, y = "top";
            l + r < p.top - b.pageYOffset ? s = p.top - l - r : l + r < j - (p.top - b.pageYOffset) - o ? (y = "bottom", s = p.top + o + r) : (y = "middle", s = Math.max((j - l) / 2 + b.pageYOffset, 0), t = Math.max((i - k) / 2 + b.pageXOffset, 0)), "top" === y || "bottom" === y ? (t = n / 2 + p.left - k / 2, v = t, x > t && (t = x), t + k > i && (t = i - k - x), q && ("top" === y ? q.classList.add(m) : q.classList.remove(m), v -= t, w = k / 2 - r / 2 + v, w = Math.max(Math.min(w, k - 2 * r - 6), 6), q.setAttribute("style", "left:" + w + "px"))) : "middle" === y && q.setAttribute("style", "display:none"), u(d, "block", s, t)
        }
    };
    a.createMask = function(b) {
        var d = c.createElement("div");
        d.classList.add(h), d.addEventListener("touchmove", a.preventDefault), d.addEventListener("tap", function() {
            e.close()
        });
        var e = [d];
        return e._show=!1, e.show = function() {
            return e._show=!0, d.setAttribute("style", "opacity:1"), c.body.appendChild(d), e
        }, e._remove = function() {
            return e._show && (e._show=!1, d.setAttribute("style", "opacity:0"), a.later(function() {
                var a = c.body;
                d.parentNode === a && a.removeChild(d)
            }, 350)), e
        }, e.close = function() {
            b ? b()!==!1 && e._remove() : e._remove()
        }, e
    }, a.fn.popover = function() {
        var b = arguments;
        this.each(function() {
            a.targets._popover = this, ("show" === b[0] || "hide" === b[0] || "toggle" === b[0]) && t(this, b[1])
        })
    }
}(mui, window, document, "popover"), function(a, b, c, d, e) {
    var f = "mui-control-item", g = "mui-segmented-control", h = "mui-segmented-control-vertical", i = "mui-control-content", j = "mui-bar-tab", k = "mui-tab-item", l = function(a, b) {
        return b.classList && (b.classList.contains(f) || b.classList.contains(k)) ? (b.parentNode && b.parentNode.classList && b.parentNode.classList.contains(h) || a.preventDefault(), b) : !1
    };
    a.registerTarget({
        name: d,
        index: 80,
        handle: l,
        target: !1
    }), b.addEventListener("tap", function(b) {
        var e = a.targets.tab;
        if (e) {
            for (var h, l, m, n = "mui-active", o = "." + n, p = e.parentNode; p && p !== c; p = p.parentNode) {
                if (p.classList.contains(g)) {
                    h = p.querySelector(o + "." + f);
                    break
                }
                p.classList.contains(j) && (h = p.querySelector(o + "." + k))
            }
            h && h.classList.remove(n);
            var q = e === h;
            if (e && e.classList.add(n), e.hash && (m = c.getElementById(e.hash.replace("#", "")))) {
                if (!m.classList.contains(i))
                    return void e.classList[q ? "remove": "add"](n);
                if (!q) {
                    var r = m.parentNode;
                    l = r.querySelectorAll("." + i + o);
                    for (var s = 0; s < l.length; s++) {
                        var t = l[s];
                        t.parentNode === r && t.classList.remove(n)
                    }
                    m.classList.add(n);
                    var u = m.parentNode.querySelectorAll("." + i);
                    a.trigger(m, a.eventName("shown", d), {
                        tabNumber: Array.prototype.indexOf.call(u, m)
                    }), b.detail && b.detail.gesture.preventDefault()
                }
            }
        }
    })
}(mui, window, document, "tab"), function(a, b, c) {
    var d = "mui-switch", e = "mui-switch-handle", f = "mui-active", g = "mui-dragging", h = "mui-disabled", i = "." + e, j = function(a, b) {
        return b.classList && b.classList.contains(d) ? b : !1
    };
    a.registerTarget({
        name: c,
        index: 100,
        handle: j,
        target: !1
    });
    var k = function(a) {
        this.element = a, this.classList = this.element.classList, this.handle = this.element.querySelector(i), this.init(), this.initEvent()
    };
    k.prototype.init = function() {
        this.toggleWidth = this.element.offsetWidth, this.handleWidth = this.handle.offsetWidth, this.handleX = this.toggleWidth - this.handleWidth - 3
    }, k.prototype.initEvent = function() {
        this.element.addEventListener("touchstart", this), this.element.addEventListener("drag", this), this.element.addEventListener("swiperight", this), this.element.addEventListener("touchend", this), this.element.addEventListener("touchcancel", this)
    }, k.prototype.handleEvent = function(a) {
        if (!this.classList.contains(h))
            switch (a.type) {
            case"touchstart":
                this.start(a);
                break;
            case"drag":
                this.drag(a);
                break;
            case"swiperight":
                this.swiperight();
                break;
            case"touchend":
            case"touchcancel":
                this.end(a)
            }
    }, k.prototype.start = function(a) {
        this.classList.add(g), (0 === this.toggleWidth || 0 === this.handleWidth) && this.init()
    }, k.prototype.drag = function(a) {
        var b = a.detail;
        this.isDragging || ("left" === b.direction || "right" === b.direction) && (this.isDragging=!0, this.lastChanged = void 0, this.initialState = this.classList.contains(f)), this.isDragging && (this.setTranslateX(b.deltaX), a.stopPropagation(), b.gesture.preventDefault())
    }, k.prototype.swiperight = function(a) {
        this.isDragging && a.stopPropagation()
    }, k.prototype.end = function(b) {
        this.classList.remove(g), this.isDragging ? (this.isDragging=!1, b.stopPropagation(), a.trigger(this.element, "toggle", {
            isActive: this.classList.contains(f)
        })) : this.toggle()
    }, k.prototype.toggle = function() {
        var b = this.classList;
        b.contains(f) ? (b.remove(f), this.handle.style.webkitTransform = "translate(0,0)") : (b.add(f), this.handle.style.webkitTransform = "translate(" + this.handleX + "px,0)"), a.trigger(this.element, "toggle", {
            isActive: this.classList.contains(f)
        })
    }, k.prototype.setTranslateX = a.animationFrame(function(a) {
        if (this.isDragging) {
            var b=!1;
            (this.initialState&&-a > this.handleX / 2 ||!this.initialState && a > this.handleX / 2) && (b=!0), this.lastChanged !== b && (b ? (this.handle.style.webkitTransform = "translate(" + (this.initialState ? 0 : this.handleX) + "px,0)", this.classList[this.initialState ? "remove": "add"](f)) : (this.handle.style.webkitTransform = "translate(" + (this.initialState ? this.handleX : 0) + "px,0)", this.classList[this.initialState ? "add": "remove"](f)), this.lastChanged = b)
        }
    }), a.fn["switch"] = function(b) {
        var c = [];
        return this.each(function() {
            var b = null, d = this.getAttribute("data-switch");
            d ? b = a.data[d] : (d=++a.uuid, a.data[d] = new k(this), this.setAttribute("data-switch", d)), c.push(b)
        }), c.length > 1 ? c : c[0]
    }, a.ready(function() {
        a("." + d)["switch"]()
    })
}(mui, window, "toggle"), function(a, b, c) {
    function d(a, b) {
        var c = b ? "removeEventListener": "addEventListener";
        a[c]("drag", F), a[c]("dragend", F), a[c]("swiperight", F), a[c]("swipeleft", F), a[c]("flick", F)
    }
    var e, f, g = "mui-active", h = "mui-selected", i = "mui-grid-view", j = "mui-table-view-radio", k = "mui-table-view-cell", l = "mui-collapse-content", m = "mui-disabled", n = "mui-switch", o = "mui-btn", p = "mui-slider-handle", q = "mui-slider-left", r = "mui-slider-right", s = "mui-transitioning", t = "." + p, u = "." + q, v = "." + r, w = "." + h, x = "." + o, y = .8, z = isOpened = openedActions = progress=!1, A = sliderActionLeft = sliderActionRight = buttonsLeft = buttonsRight = sliderDirection = sliderRequestAnimationFrame=!1, B = translateX = lastTranslateX = sliderActionLeftWidth = sliderActionRightWidth = 0, C = function(a) {
        a ? f ? f.classList.add(g) : e && e.classList.add(g) : (B && B.cancel(), f ? f.classList.remove(g) : e && e.classList.remove(g))
    }, D = function() {
        if (translateX !== lastTranslateX) {
            if (buttonsRight && buttonsRight.length > 0) {
                progress = translateX / sliderActionRightWidth, translateX<-sliderActionRightWidth && (translateX =- sliderActionRightWidth - Math.pow( - translateX - sliderActionRightWidth, y));
                for (var a = 0, b = buttonsRight.length; b > a; a++) {
                    var c = buttonsRight[a];
                    "undefined" == typeof c._buttonOffset && (c._buttonOffset = c.offsetLeft), buttonOffset = c._buttonOffset, E(c, translateX - buttonOffset * (1 + Math.max(progress, - 1)))
                }
            }
            if (buttonsLeft && buttonsLeft.length > 0) {
                progress = translateX / sliderActionLeftWidth, translateX > sliderActionLeftWidth && (translateX = sliderActionLeftWidth + Math.pow(translateX - sliderActionLeftWidth, y));
                for (var a = 0, b = buttonsLeft.length; b > a; a++) {
                    var d = buttonsLeft[a];
                    "undefined" == typeof d._buttonOffset && (d._buttonOffset = sliderActionLeftWidth - d.offsetLeft - d.offsetWidth), buttonOffset = d._buttonOffset, buttonsLeft.length > 1 && (d.style.zIndex = buttonsLeft.length - a), E(d, translateX + buttonOffset * (1 - Math.min(progress, 1)))
                }
            }
            E(A, translateX), lastTranslateX = translateX
        }
        sliderRequestAnimationFrame = requestAnimationFrame(function() {
            D()
        })
    }, E = function(a, b) {
        a && (a.style.webkitTransform = "translate3d(" + b + "px,0,0)")
    };
    b.addEventListener("touchstart", function(b) {
        e && C(!1), e = f=!1, z = isOpened = openedActions=!1;
        for (var g = b.target, h=!1; g && g !== c; g = g.parentNode)
            if (g.classList) {
                var p = g.classList;
                if (("INPUT" === g.tagName && "radio" !== g.type && "checkbox" !== g.type || "BUTTON" === g.tagName || p.contains(n) || p.contains(o) || p.contains(m)) && (h=!0), p.contains(l))
                    break;
                    if (p.contains(k)) {
                        e = g;
                        var q = e.parentNode.querySelector(w);
                        if (!e.parentNode.classList.contains(j) && q && q !== e)
                            return a.swipeoutClose(q), void(e = h=!1);
                            if (!e.parentNode.classList.contains(i)) {
                                var r = e.querySelector("a");
                                r && r.parentNode === e && (f = r)
                            }
                            var s = e.querySelector(t);
                            s && (d(e), b.stopPropagation()), h || (s ? (B && B.cancel(), B = a.later(function() {
                                C(!0)
                            }, 100)) : C(!0));
                            break
                        }
                }
        }), b.addEventListener("touchmove", function(a) {
        C(!1)
    });
    var F = {
        handleEvent: function(a) {
            switch (a.type) {
            case"drag":
                this.drag(a);
                break;
            case"dragend":
                this.dragend(a);
                break;
            case"flick":
                this.flick(a);
                break;
            case"swiperight":
                this.swiperight(a);
                break;
            case"swipeleft":
                this.swipeleft(a)
            }
        },
        drag: function(a) {
            if (e) {
                z || (A = sliderActionLeft = sliderActionRight = buttonsLeft = buttonsRight = sliderDirection = sliderRequestAnimationFrame=!1, A = e.querySelector(t), A && (sliderActionLeft = e.querySelector(u), sliderActionRight = e.querySelector(v), sliderActionLeft && (sliderActionLeftWidth = sliderActionLeft.offsetWidth, buttonsLeft = sliderActionLeft.querySelectorAll(x)), sliderActionRight && (sliderActionRightWidth = sliderActionRight.offsetWidth, buttonsRight = sliderActionRight.querySelectorAll(x)), e.classList.remove(s), isOpened = e.classList.contains(h), isOpened && (openedActions = e.querySelector(u + w) ? "left" : "right")));
                var b = a.detail, c = b.direction, d = b.angle;
                if ("left" === c && (d > 150||-150 > d) ? (buttonsRight || buttonsLeft && isOpened) && (z=!0) : "right" === c && d>-30 && 30 > d && (buttonsLeft || buttonsRight && isOpened) && (z=!0), z) {
                    a.stopPropagation(), a.detail.gesture.preventDefault();
                    var f = a.detail.deltaX;
                    if (isOpened && ("right" === openedActions ? f -= sliderActionRightWidth : f += sliderActionLeftWidth), f > 0&&!buttonsLeft || 0 > f&&!buttonsRight) {
                        if (!isOpened)
                            return;
                        f = 0
                    }
                    0 > f ? sliderDirection = "toLeft" : f > 0 ? sliderDirection = "toRight" : sliderDirection || (sliderDirection = "toLeft"), sliderRequestAnimationFrame || D(), translateX = f
                }
            }
        },
        flick: function(a) {
            z && a.stopPropagation()
        },
        swipeleft: function(a) {
            z && a.stopPropagation()
        },
        swiperight: function(a) {
            z && a.stopPropagation()
        },
        dragend: function(b) {
            if (z) {
                b.stopPropagation(), sliderRequestAnimationFrame && (cancelAnimationFrame(sliderRequestAnimationFrame), sliderRequestAnimationFrame = null);
                var c = b.detail;
                z=!1;
                var d = "close", f = "toLeft" === sliderDirection ? sliderActionRightWidth: sliderActionLeftWidth, g = c.swipe || Math.abs(translateX) > f / 2;
                g && (isOpened ? "left" === c.direction && "right" === openedActions ? d = "open" : "right" === c.direction && "left" === openedActions && (d = "open") : d = "open"), e.classList.add(s);
                var i;
                if ("open" === d) {
                    var j = "toLeft" === sliderDirection?-f : f;
                    if (E(A, j), i = "toLeft" === sliderDirection ? buttonsRight : buttonsLeft, "undefined" != typeof i) {
                        for (var k = null, l = 0; l < i.length; l++)
                            k = i[l], E(k, j);
                        k.parentNode.classList.add(h), e.classList.add(h), isOpened || a.trigger(e, "toLeft" === sliderDirection ? "slideleft" : "slideright")
                    }
                } else 
                    E(A, 0), sliderActionLeft && sliderActionLeft.classList.remove(h), sliderActionRight && sliderActionRight.classList.remove(h), e.classList.remove(h);
                var m;
                if (buttonsLeft && buttonsLeft.length > 0 && buttonsLeft !== i)
                    for (var l = 0, n = buttonsLeft.length; n > l; l++) {
                        var o = buttonsLeft[l];
                        m = o._buttonOffset, "undefined" == typeof m && (o._buttonOffset = sliderActionLeftWidth - o.offsetLeft - o.offsetWidth), E(o, m)
                    }
                if (buttonsRight && buttonsRight.length > 0 && buttonsRight !== i)
                    for (var l = 0, n = buttonsRight.length; n > l; l++) {
                        var p = buttonsRight[l];
                        m = p._buttonOffset, "undefined" == typeof m && (p._buttonOffset = p.offsetLeft), E(p, - m)
                    }
                }
            }
    };
    a.swipeoutOpen = function(b, c) {
        if (b) {
            var d = b.classList;
            if (!d.contains(h)) {
                c || (c = b.querySelector(v) ? "right" : "left");
                var e = b.querySelector(a.classSelector(".slider-" + c));
                if (e) {
                    e.classList.add(h), d.add(h), d.remove(s);
                    for (var f, g = e.querySelectorAll(x), i = e.offsetWidth, j = "right" === c?-i : i, k = g.length, l = 0; k > l; l++)
                        f = g[l], "right" === c ? E(f, - f.offsetLeft) : E(f, i - f.offsetWidth - f.offsetLeft);
                    d.add(s);
                    for (var l = 0; k > l; l++)
                        E(g[l], j);
                    E(b.querySelector(t), j)
                }
            }
        }
    }, a.swipeoutClose = function(b) {
        if (b) {
            var c = b.classList;
            if (c.contains(h)) {
                var d = b.querySelector(v + w) ? "right": "left", e = b.querySelector(a.classSelector(".slider-" + d));
                if (e) {
                    e.classList.remove(h), c.remove(h), c.add(s);
                    var f, g = e.querySelectorAll(x), i = e.offsetWidth, j = g.length;
                    E(b.querySelector(t), 0);
                    for (var k = 0; j > k; k++)
                        f = g[k], "right" === d ? E(f, - f.offsetLeft) : E(f, i - f.offsetWidth - f.offsetLeft)
                    }
            }
        }
    }, b.addEventListener("touchend", function(a) {
        e && (C(!1), A && d(e, !0))
    }), b.addEventListener("touchcancel", function(a) {
        e && (C(!1), A && d(e, !0))
    });
    var G = function(b) {
        var c = b.target && b.target.type || "";
        if ("radio" !== c && "checkbox" !== c) {
            var d = e.classList;
            if (d.contains("mui-radio")) {
                var f = e.querySelector("input[type=radio]");
                f && (f.disabled || f.readOnly || (f.checked=!f.checked, a.trigger(f, "change")))
            } else if (d.contains("mui-checkbox")) {
                var f = e.querySelector("input[type=checkbox]");
                f && (f.disabled || f.readOnly || (f.checked=!f.checked, a.trigger(f, "change")))
            }
        }
    };
    b.addEventListener(a.EVENT_CLICK, function(a) {
        e && e.classList.contains("mui-collapse") && a.preventDefault()
    }), b.addEventListener("doubletap", function(a) {
        e && G(a)
    });
    var H = /^(INPUT|TEXTAREA|BUTTON|SELECT)$/;
    b.addEventListener("tap", function(b) {
        if (e) {
            var c=!1, d = e.classList, f = e.parentNode;
            if (f && f.classList.contains(j)) {
                if (d.contains(h))
                    return;
                var i = f.querySelector("li" + w);
                return i && i.classList.remove(h), d.add(h), void a.trigger(e, "selected", {
                    el: e
                })
            }
            if (d.contains("mui-collapse")&&!e.parentNode.classList.contains("mui-unfold")) {
                if (H.test(b.target.tagName) || b.detail.gesture.preventDefault(), !d.contains(g)) {
                    var k = e.parentNode.querySelector(".mui-collapse.mui-active");
                    k && k.classList.remove(g), c=!0
                }
                d.toggle(g), c && a.trigger(e, "expand")
            } else 
                G(b)
        }
    })
}(mui, window, document), function(a, b) {
    a.alert = function(c, d, e, f) {
        if (a.os.plus) {
            if (void 0 === typeof c)
                return;
            "function" == typeof d ? (f = d, d = null, e = "ȷ��") : "function" == typeof e && (f = e, e = null), a.plusReady(function() {
                plus.nativeUI.alert(c, f, d, e)
            })
        } else 
            b.alert(c)
    }
}(mui, window), function(a, b) {
    a.confirm = function(c, d, e, f) {
        if (a.os.plus) {
            if (void 0 === typeof c)
                return;
            "function" == typeof d ? (f = d, d = null, e = null) : "function" == typeof e && (f = e, e = null), a.plusReady(function() {
                plus.nativeUI.confirm(c, f, d, e)
            })
        } else 
            f(b.confirm(c) ? {
                index: 0
            } : {
                index: 1
            })
    }
}(mui, window), function(a, b) {
    a.prompt = function(c, d, e, f, g) {
        if (a.os.plus) {
            if (void 0 === typeof message)
                return;
            "function" == typeof d ? (g = d, d = null, e = null, f = null) : "function" == typeof e ? (g = e, e = null, f = null) : "function" == typeof f && (g = f, f = null), a.plusReady(function() {
                plus.nativeUI.prompt(c, g, e, d, f)
            })
        } else {
            var h = b.prompt(c);
            g(h ? {
                index: 0,
                value: h
            } : {
                index: 1,
                value: ""
            })
        }
    }
}(mui, window), function(a, b) {
    a.toast = function(b) {
        if (a.os.plus)
            a.plusReady(function() {
                plus.nativeUI.toast(b, {
                    verticalAlign: "bottom"
                })
            });
        else {
            var c = document.createElement("div");
            c.classList.add("mui-toast-container"), c.innerHTML = '<div class="mui-toast-message">' + b + "</div>", document.body.appendChild(c), setTimeout(function() {
                document.body.removeChild(c)
            }, 2e3)
        }
    }
}(mui, window), function(a, b, c) {
    var d = "mui-icon", e = "mui-icon-clear", f = "mui-icon-speech", g = "mui-icon-search", h = "mui-input-row", i = "mui-placeholder", j = "mui-tooltip", k = "mui-hidden", l = "mui-focusin", m = "." + e, n = "." + f, o = "." + i, p = "." + j, q = function(a) {
        for (; a && a !== c; a = a.parentNode)
            if (a.classList && a.classList.contains(h))
                return a;
        return null
    }, r = function(a, b) {
        this.element = a, this.options = b || {
            actions: "clear"
        }, ~this.options.actions.indexOf("slider") ? (this.sliderActionClass = j + " " + k, this.sliderActionSelector = p) : (~this.options.actions.indexOf("clear") && (this.clearActionClass = d + " " + e + " " + k, this.clearActionSelector = m), ~this.options.actions.indexOf("speech") && (this.speechActionClass = d + " " + f, this.speechActionSelector = n), ~this.options.actions.indexOf("search") && (this.searchActionClass = i, this.searchActionSelector = o)), this.init()
    };
    r.prototype.init = function() {
        this.initAction(), this.initElementEvent()
    }, r.prototype.initAction = function() {
        var b = this, c = b.element.parentNode;
        c && (b.sliderActionClass ? b.sliderAction = b.createAction(c, b.sliderActionClass, b.sliderActionSelector) : (b.searchActionClass && (b.searchAction = b.createAction(c, b.searchActionClass, b.searchActionSelector), b.searchAction.addEventListener("tap", function(c) {
            a.focus(b.element), c.stopPropagation()
        })), b.speechActionClass && (b.speechAction = b.createAction(c, b.speechActionClass, b.speechActionSelector), b.speechAction.addEventListener("click", a.stopPropagation), b.speechAction.addEventListener("tap", function(a) {
            b.speechActionClick(a)
        })), b.clearActionClass && (b.clearAction = b.createAction(c, b.clearActionClass, b.clearActionSelector), b.clearAction.addEventListener("tap", function(a) {
            b.clearActionClick(a)
        }))))
    }, r.prototype.createAction = function(a, b, e) {
        var f = a.querySelector(e);
        if (!f) {
            var f = c.createElement("span");
            f.className = b, b === this.searchActionClass && (f.innerHTML = '<span class="' + d + " " + g + '"></span><span>' + this.element.getAttribute("placeholder") + "</span>", this.element.setAttribute("placeholder", ""), this.element.value.trim() && a.classList.add("mui-active")), a.insertBefore(f, this.element.nextSibling)
        }
        return f
    }, r.prototype.initElementEvent = function() {
        var b = this.element;
        if (this.sliderActionClass) {
            var c = this.sliderAction, d = b.offsetLeft, e = b.offsetWidth - 28, f = c.offsetWidth, g = Math.abs(b.max - b.min), h = null, i = function() {
                c.classList.remove(k), f = f || c.offsetWidth;
                var a = e / g * Math.abs(b.value - b.min);
                c.style.left = 14 + d + a - f / 2 + "px", c.innerText = b.value, h && clearTimeout(h), h = setTimeout(function() {
                    c.classList.add(k)
                }, 1e3)
            };
            b.addEventListener("input", i), b.addEventListener("tap", i), b.addEventListener("touchmove", function(a) {
                a.stopPropagation()
            })
        } else {
            if (this.clearActionClass) {
                var j = this.clearAction;
                if (!j)
                    return;
                a.each(["keyup", "change", "input", "focus", "cut", "paste"], function(a, c) {
                    !function(a) {
                        b.addEventListener(a, function() {
                            j.classList[b.value.trim() ? "remove": "add"](k)
                        })
                    }(c)
                }), b.addEventListener("blur", function() {
                    j.classList.add(k)
                })
            }
            this.searchActionClass && (b.addEventListener("focus", function() {
                b.parentNode.classList.add("mui-active")
            }), b.addEventListener("blur", function() {
                b.value.trim() || b.parentNode.classList.remove("mui-active")
            }))
        }
    }, r.prototype.setPlaceholder = function(a) {
        if (this.searchActionClass) {
            var b = this.element.parentNode.querySelector(o);
            b && (b.getElementsByTagName("span")[1].innerText = a)
        } else 
            this.element.setAttribute("placeholder", a)
    }, r.prototype.clearActionClick = function(b) {
        var c = this;
        c.element.value = "", a.focus(c.element), c.clearAction.classList.add(k), b.preventDefault()
    }, r.prototype.speechActionClick = function(d) {
        if (b.plus) {
            var e = this, f = e.element.value;
            e.element.value = "", c.body.classList.add(l), plus.speech.startRecognize({
                engine: "iFly"
            }, function(b) {
                e.element.value += b, a.focus(e.element), plus.speech.stopRecognize(), a.trigger(e.element, "recognized", {
                    value: e.element.value
                }), f !== e.element.value && (a.trigger(e.element, "change"), a.trigger(e.element, "input"))
            }, function(a) {
                c.body.classList.remove(l)
            })
        } else 
            alert("only for 5+");
        d.preventDefault()
    }, a.fn.input = function(b) {
        var c = [];
        return this.each(function() {
            var b = null, d = [], e = q(this.parentNode);
            if ("range" === this.type && e.classList.contains("mui-input-range"))
                d.push("slider");
            else {
                var f = this.classList;
                f.contains("mui-input-clear") && d.push("clear"), f.contains("mui-input-speech") && d.push("speech"), "search" === this.type && e.classList.contains("mui-search") && d.push("search")
            }
            var g = this.getAttribute("data-input-" + d[0]);
            if (g)
                b = a.data[g];
            else {
                g=++a.uuid, b = a.data[g] = new r(this, {
                    actions: d.join(",")
                });
                for (var h = 0, i = d.length; i > h; h++)
                    this.setAttribute("data-input-" + d[h], g)
            }
            c.push(b)
        }), 1 === c.length ? c[0] : c
    }, a.ready(function() {
        a(".mui-input-row input").input()
    })
}(mui, window, document), function(a) {
    var b = "ontouchstart"in document, c = b ? "tap": "click", d = "change", e = "mui-numbox", f = "mui-numbox-btn-plus", g = "mui-numbox-btn-minus", h = "mui-numbox-input", i = a.Numbox = a.Class.extend({
        init: function(b, c) {
            var d = this;
            if (!b)
                throw "\u6784\u9020\u0020\u006e\u0075\u006d\u0062\u006f\u0078\u0020\u65f6\u7f3a\u5c11\u5bb9\u5668\u5143\u7d20";
            d.holder = b, c = c || {}, c.step = parseInt(c.step || 1), d.options = c, d.input = a.qsa("." + h, d.holder)[0], d.plus = a.qsa("." + f, d.holder)[0], d.minus = a.qsa("." + g, d.holder)[0], d.checkValue(), d.initEvent()
        },
        initEvent: function() {
            var b = this;
            b.plus.addEventListener(c, function(c) {
                var e = parseInt(b.input.value) + b.options.step;
                b.input.value = e.toString(), a.trigger(b.input, d, null)
            }), b.minus.addEventListener(c, function(c) {
                var e = parseInt(b.input.value) - b.options.step;
                b.input.value = e.toString(), a.trigger(b.input, d, null)
            }), b.input.addEventListener(d, function(a) {
                b.checkValue()
            })
        },
        checkValue: function() {
            var a = this, b = a.input.value;
            if (null == b || "" == b || isNaN(b))
                a.input.value = a.options.min || 0, a.minus.disabled = null != a.options.min;
            else {
                var b = parseInt(b);
                null != a.options.max&&!isNaN(a.options.max) && b >= parseInt(a.options.max) ? (b = a.options.max, a.plus.disabled=!0) : a.plus.disabled=!1, null != a.options.min&&!isNaN(a.options.min) && b <= parseInt(a.options.min) ? (b = a.options.min, a.minus.disabled=!0) : a.minus.disabled=!1, a.input.value = b
            }
        },
        setOption: function(a, b) {
            var c = this;
            c.options[a] = b
        }
    });
    a.fn.numbox = function(a) {
        return this.each(function(a, b) {
            if (!b.numbox)
                if (d)
                    b.numbox = new i(b, d);
                else {
                    var c = b.getAttribute("data-numbox-options"), d = c ? JSON.parse(c): {};
                    d.step = b.getAttribute("data-numbox-step") || d.step, d.min = b.getAttribute("data-numbox-min") || d.min, d.max = b.getAttribute("data-numbox-max") || d.max, b.numbox = new i(b, d)
                }
        }), this[0] ? this[0].numbox : null
    }, a.ready(function() {
        a("." + e).numbox()
    })
}(mui);;

(function($) {
    $.extend($.fn, {
        cookie: function(key, value, options) {
            var days, time, result, decode
            if (arguments.length > 1 && String(value) !== "[object Object]") {
                options = $.extend({}, options)
                if (value === null || value === undefined)
                    options.expires =- 1
                if (typeof options.expires === 'number') {
                    days = (options.expires * 24 * 60 * 60 * 1000)
                    time = options.expires = new Date()
                    time.setTime(time.getTime() + days)
                }
                value = String(value)
                return (document.cookie = [encodeURIComponent(key), '=', options.raw ? value: encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString(): '', options.path ? '; path=' + options.path: '', options.domain ? '; domain=' + options.domain: '', options.secure ? '; secure': ''].join(''))
            }
            options = value || {}
            decode = options.raw ? function(s) {
                return s
            } : decodeURIComponent
            return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null
        }
    })
})(Zepto);;;
(function($, undefined) {
    var prefix = '', eventPrefix, endEventName, endAnimationName, vendors = {
        Webkit: 'webkit',
        Moz: '',
        O: 'o',
        ms: 'MS'
    }, document = window.document, testEl = document.createElement('div'), supportedTransforms = /^((translate|rotate|scale)(X|Y|Z|3d)?|matrix(3d)?|perspective|skew(X|Y)?)$/i, transform, transitionProperty, transitionDuration, transitionTiming, transitionDelay, animationName, animationDuration, animationTiming, animationDelay, cssReset = {};
    function dasherize(str) {
        return str.replace(/([a-z])([A-Z])/, '$1-$2').toLowerCase()
    }
    function normalizeEvent(name) {
        return eventPrefix ? eventPrefix + name : name.toLowerCase()
    }
    $.each(vendors, function(vendor, event) {
        if (testEl.style[vendor + 'TransitionProperty'] !== undefined) {
            prefix = '-' + vendor.toLowerCase() + '-'
            eventPrefix = event
            return false
        }
    })
    transform = prefix + 'transform';
    cssReset[transitionProperty = prefix + 'transition-property'] = cssReset[transitionDuration = prefix + 'transition-duration'] = cssReset[transitionDelay = prefix + 'transition-delay'] = cssReset[transitionTiming = prefix + 'transition-timing-function'] = cssReset[animationName = prefix + 'animation-name'] = cssReset[animationDuration = prefix + 'animation-duration'] = cssReset[animationDelay = prefix + 'animation-delay'] = cssReset[animationTiming = prefix + 'animation-timing-function'] = '';
    $.fx = {
        off: (eventPrefix === undefined && testEl.style.transitionProperty === undefined),
        speeds: {
            _default: 400,
            fast: 200,
            slow: 600
        },
        cssPrefix: prefix,
        transitionEnd: normalizeEvent('TransitionEnd'),
        animationEnd: normalizeEvent('AnimationEnd')
    }
    $.fn.animate = function(properties, duration, ease, callback, delay) {
        if ($.isPlainObject(duration))
            ease = duration.easing, callback = duration.complete, delay = duration.delay, duration = duration.duration
        if (duration)
            duration = (typeof duration == 'number' ? duration : ($.fx.speeds[duration] || $.fx.speeds._default)) / 1000
        if (delay)
            delay = parseFloat(delay) / 1000
        return this.anim(properties, duration, ease, callback, delay)
    };
    $.fn.anim = function(properties, duration, ease, callback, delay) {
        var key, cssValues = {}, cssProperties, transforms = '', that = this, wrappedCallback, endEvent = $.fx.transitionEnd
        if (duration === undefined)
            duration = 0.4
        if (delay === undefined)
            delay = 0
        if ($.fx.off)
            duration = 0
        if (typeof properties == 'string') {
            cssValues[animationName] = properties
            cssValues[animationDuration] = duration + 's'
            cssValues[animationDelay] = delay + 's'
            cssValues[animationTiming] = (ease || 'linear')
            endEvent = $.fx.animationEnd
        } else {
            cssProperties = []
            for (key in properties)
                if (supportedTransforms.test(key))
                    transforms += key + '(' + properties[key] + ') '
                else 
                    cssValues[key] = properties[key], cssProperties.push(dasherize(key))
            if (transforms)
                cssValues[transform] = transforms, cssProperties.push(transform)
            if (duration > 0 && typeof properties === 'object') {
                cssValues[transitionProperty] = cssProperties.join(', ')
                cssValues[transitionDuration] = duration + 's'
                cssValues[transitionDelay] = delay + 's'
                cssValues[transitionTiming] = (ease || 'linear')
            }
        }
        wrappedCallback = function(event) {
            if (typeof event !== 'undefined') {
                if (event.target !== event.currentTarget)
                    return $(event.target).unbind(endEvent, wrappedCallback)
            }
            $(this).css(cssReset)
            callback && callback.call(this)
        };
        if (duration > 0)
            this.bind(endEvent, wrappedCallback)
        this.size() && this.get(0).clientLeft
        this.css(cssValues)
        if (duration <= 0)
            setTimeout(function() {
                that.each(function() {
                    wrappedCallback.call(this)
                })
            }, 0);
        return this;
    };
    $.extend($.fn, {
        fadeIn: function(ms) {
            if (typeof(ms) === 'undefined') {
                ms = 250;
            }
            $(this).css({
                display: 'block',
                opacity: 0
            }).animate({
                opacity: 1
            }, ms);
            return this;
        },
        fadeOut: function(ms) {
            if (typeof(ms) === 'undefined') {
                ms = 250;
            }
            $(this).css({
                display: 'block',
                opacity: 1
            }).animate({
                opacity: 0
            }, ms);
            return this;
        }
    });
    testEl = null
})(Zepto);;

(function($) {
    $.fn.slideDown = function(duration) {
        var position = this.css('position');
        this.show();
        this.css({
            position: 'absolute',
            visibility: 'hidden',
            height: 'auto'
        });
        var height = this.height();
        this.css({
            position: position,
            visibility: 'visible',
            overflow: 'hidden',
            height: 0
        });
        slideIt(this, height, duration);
    };
    $.fn.slideUp = function(duration) {
        slideIt(this, 0, duration);
    };
    function slideIt(that, height, duration) {
        that.animate({
            height: height
        }, duration, '', function() {
            height == 0 ? that.hide() : that.show();
        });
    }
})($);;;
(function($) {
    $.fn.lazyload = function(settings) {
        var
        imgList = $('img[data-lazy]'), _winScrollTop = 0, _winHeight = $(window).height();
        settings = $.extend({
            threshold: 0,
            placeholder: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC'
        }, settings || {});
        var initLoadList = 0;
        $(window).on('scroll', function() {
            __lazyLoad($(window).scrollTop());
            if (!initLoadList) {
                initLoadList = 1;
                setTimeout(function() {
                    initLoadList = 0;
                    imgList = $('img[data-lazy]');
                }, 1000);
            }
        });
        window.__lazyLoad = function(_winScrollTop) {
            if (!imgList.length) {
                return;
            }
            imgList.each(function() {
                var $self = $(this);
                if ($self.is('img') && $self.data('lazy')) {
                    var _offsetTop = $self.offset().top;
                    if ((_offsetTop - settings.threshold) <= (_winHeight + _winScrollTop)) {
                        $self.attr('src', $self.data('lazy'));
                        $self.removeAttr('data-lazy');
                    }
                }
            });
        };
        __lazyLoad();
    }
})(window.Zepto || window.$);;

(function($) {
    $.fn.suggest = function(options) {
        options = $.extend({
            onQuery: function(key, onResult) {},
            time: 500,
            listClass: 'suggest-list',
            appendParent: false,
            listTpl: ''
        }, options);
        $(this).each(function() {
            var that = $(this);
            var suggestCache = {}, suggestTimer = 0;
            var listElement = $('<div class="' + options.listClass + '"></div>').appendTo(options.appendParent ? options.appendParent : $(document.body));
            function processSuggest(data) {
                listElement.hide();
                if (!data || data == 1 || data.length == 0) {
                    return;
                }
                var nodes = mzTpl(that.data('tpl') ? $('#' + that.data('tpl')).html() : options.listTpl, {
                    list: data
                });
                var position = that.offset();
                var bodyOffset = $(document.body).offset();
                listElement.html(nodes).css({
                    "left": position.left - parseInt(bodyOffset.left, 10),
                    "top": position.top + parseInt(that.css("height"), 10) - 1 - parseInt(bodyOffset.top, 10),
                    "width": that.width()
                }).show();
                listElement.find("li").css("font-size", that.css("font-size"));
            }
            $(this).on('input', function() {
                if (suggestTimer) {
                    clearTimeout(suggestTimer);
                }
                var key = $.trim($(this).val());
                if (key != '') {
                    if (suggestCache[key]) {
                        processSuggest(suggestCache[key]);
                        return;
                    }
                    suggestTimer = setTimeout(function() {
                        suggestCache[key] = 1;
                        options.onQuery && options.onQuery(key, function(data) {
                            suggestTimer = 0;
                            listElement.hide();
                            if (data === false) {
                                return;
                            }
                            suggestCache[key] = data;
                            processSuggest(suggestCache[key]);
                        });
                    }, options.time);
                }
                return false;
            });
        });
    };
})($);;

var Swiper = function(a, b) {
    "use strict";
    function c(a, b) {
        return document.querySelectorAll ? (b || document).querySelectorAll(a) : jQuery(a, b)
    }
    function d(a) {
        return "[object Array]" === Object.prototype.toString.apply(a)?!0 : !1
    }
    function e() {
        var a = F - I;
        return b.freeMode && (a = F - I), b.slidesPerView > C.slides.length&&!b.centeredSlides && (a = 0), 0 > a && (a = 0), a
    }
    function f() {
        function a(a) {
            if (a == null) {
                return;
            }
            var c = new Image;
            c.onload = function() {
                "undefined" != typeof C && null !== C && (void 0 !== C.imagesLoaded && C.imagesLoaded++, C.imagesLoaded === C.imagesToLoad.length && (C.reInit(), b.onImagesReady && C.fireCallback(b.onImagesReady, C)))
            }, c.src = a
        }
        var d = C.h.addEventListener, e = "wrapper" === b.eventTarget ? C.wrapper: C.container;
        if (C.browser.ie10 || C.browser.ie11 ? (d(e, C.touchEvents.touchStart, p), d(document, C.touchEvents.touchMove, q), d(document, C.touchEvents.touchEnd, r)) : (C.support.touch && (d(e, "touchstart", p), d(e, "touchmove", q), d(e, "touchend", r)), b.simulateTouch && (d(e, "mousedown", p), d(document, "mousemove", q), d(document, "mouseup", r))), b.autoResize && d(window, "resize", C.resizeFix), g(), C._wheelEvent=!1, b.mousewheelControl) {
            if (void 0 !== document.onmousewheel && (C._wheelEvent = "mousewheel"), !C._wheelEvent)try {
                new WheelEvent("wheel"), C._wheelEvent = "wheel"
            } catch (f) {}
            C._wheelEvent || (C._wheelEvent = "DOMMouseScroll"), C._wheelEvent && d(C.container, C._wheelEvent, j)
        }
        if (b.keyboardControl && d(document, "keydown", i), b.updateOnImagesReady) {
            C.imagesToLoad = c("img", C.container);
            for (var h = 0; h < C.imagesToLoad.length; h++)
                a(C.imagesToLoad[h].getAttribute("src"))
        }
    }
    function g() {
        var a, d = C.h.addEventListener;
        if (b.preventLinks) {
            var e = c("a", C.container);
            for (a = 0; a < e.length; a++)
                d(e[a], "click", n)
        }
        if (b.releaseFormElements) {
            var f = c("input, textarea, select", C.container);
            for (a = 0; a < f.length; a++)
                d(f[a], C.touchEvents.touchStart, o, !0)
        }
        if (b.onSlideClick)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], "click", k);
        if (b.onSlideTouch)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], C.touchEvents.touchStart, l)
    }
    function h() {
        var a, d = C.h.removeEventListener;
        if (b.onSlideClick)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], "click", k);
        if (b.onSlideTouch)
            for (a = 0; a < C.slides.length; a++)
                d(C.slides[a], C.touchEvents.touchStart, l);
        if (b.releaseFormElements) {
            var e = c("input, textarea, select", C.container);
            for (a = 0; a < e.length; a++)
                d(e[a], C.touchEvents.touchStart, o, !0)
        }
        if (b.preventLinks) {
            var f = c("a", C.container);
            for (a = 0; a < f.length; a++)
                d(f[a], "click", n)
        }
    }
    function i(a) {
        var b = a.keyCode || a.charCode;
        if (!(a.shiftKey || a.altKey || a.ctrlKey || a.metaKey)) {
            if (37 === b || 39 === b || 38 === b || 40 === b) {
                for (var c=!1, d = C.h.getOffset(C.container), e = C.h.windowScroll().left, f = C.h.windowScroll().top, g = C.h.windowWidth(), h = C.h.windowHeight(), i = [[d.left, d.top], [d.left + C.width, d.top], [d.left, d.top + C.height], [d.left + C.width, d.top + C.height]], j = 0; j < i.length; j++) {
                    var k = i[j];
                    k[0] >= e && k[0] <= e + g && k[1] >= f && k[1] <= f + h && (c=!0)
                }
                if (!c)
                    return 
            }
            M ? ((37 === b || 39 === b) && (a.preventDefault ? a.preventDefault() : a.returnValue=!1), 39 === b && C.swipeNext(), 37 === b && C.swipePrev()) : ((38 === b || 40 === b) && (a.preventDefault ? a.preventDefault() : a.returnValue=!1), 40 === b && C.swipeNext(), 38 === b && C.swipePrev())
        }
    }
    function j(a) {
        var c = C._wheelEvent, d = 0;
        if (a.detail)
            d =- a.detail;
        else if ("mousewheel" === c)
            if (b.mousewheelControlForceToAxis)
                if (M) {
                    if (!(Math.abs(a.wheelDeltaX) > Math.abs(a.wheelDeltaY)))
                        return;
                        d = a.wheelDeltaX
                } else {
                    if (!(Math.abs(a.wheelDeltaY) > Math.abs(a.wheelDeltaX)))
                        return;
                        d = a.wheelDeltaY
                } else 
                    d = a.wheelDelta;
                else if ("DOMMouseScroll" === c)
            d =- a.detail;
        else if ("wheel" === c)
            if (b.mousewheelControlForceToAxis)
                if (M) {
                    if (!(Math.abs(a.deltaX) > Math.abs(a.deltaY)))
                        return;
                        d =- a.deltaX
                } else {
                    if (!(Math.abs(a.deltaY) > Math.abs(a.deltaX)))
                        return;
                        d =- a.deltaY
                } else 
                    d = Math.abs(a.deltaX) > Math.abs(a.deltaY)?-a.deltaX : - a.deltaY;
        if (b.freeMode) {
            var f = C.getWrapperTranslate() + d;
            if (f > 0 && (f = 0), f<-e() && (f =- e()), C.setWrapperTransition(0), C.setWrapperTranslate(f), C.updateActiveSlide(f), 0 === f || f===-e())
                return 
        } else (new Date)
            .getTime() - U > 60 && (0 > d ? C.swipeNext() : C.swipePrev()), U = (new Date).getTime();
        return b.autoplay && C.stopAutoplay(!0), a.preventDefault ? a.preventDefault() : a.returnValue=!1, !1
    }
    function k(a) {
        C.allowSlideClick && (m(a), C.fireCallback(b.onSlideClick, C, a))
    }
    function l(a) {
        m(a), C.fireCallback(b.onSlideTouch, C, a)
    }
    function m(a) {
        if (a.currentTarget)
            C.clickedSlide = a.currentTarget;
        else {
            var c = a.srcElement;
            do {
                if (c.className.indexOf(b.slideClass)>-1)
                    break;
                c = c.parentNode
            }
            while (c);
            C.clickedSlide = c
        }
        C.clickedSlideIndex = C.slides.indexOf(C.clickedSlide), C.clickedSlideLoopIndex = C.clickedSlideIndex - (C.loopedSlides || 0)
    }
    function n(a) {
        return C.allowLinks ? void 0 : (a.preventDefault ? a.preventDefault() : a.returnValue=!1, b.preventLinksPropagation && "stopPropagation"in a && a.stopPropagation(), !1)
    }
    function o(a) {
        return a.stopPropagation ? a.stopPropagation() : a.returnValue=!1, !1
    }
    function p(a) {
        if (b.preventLinks && (C.allowLinks=!0), C.isTouched || b.onlyExternal)
            return !1;
        var c = a.target || a.srcElement;
        document.activeElement && document.activeElement !== c && document.activeElement.blur();
        var d = "input select textarea".split(" ");
        if (b.noSwiping && c && s(c))
            return !1;
        if ($=!1, C.isTouched=!0, Z = "touchstart" === a.type, !Z && "which"in a && 3 === a.which)
            return !1;
        if (!Z || 1 === a.targetTouches.length) {
            C.callPlugins("onTouchStartBegin"), !Z&&!C.isAndroid && d.indexOf(c.tagName.toLowerCase()) < 0 && (a.preventDefault ? a.preventDefault() : a.returnValue=!1);
            var e = Z ? a.targetTouches[0].pageX: a.pageX || a.clientX, f = Z ? a.targetTouches[0].pageY: a.pageY || a.clientY;
            C.touches.startX = C.touches.currentX = e, C.touches.startY = C.touches.currentY = f, C.touches.start = C.touches.current = M ? e : f, C.setWrapperTransition(0), C.positions.start = C.positions.current = C.getWrapperTranslate(), C.setWrapperTranslate(C.positions.start), C.times.start = (new Date).getTime(), H = void 0, b.moveStartThreshold > 0 && (W=!1), b.onTouchStart && C.fireCallback(b.onTouchStart, C, a), C.callPlugins("onTouchStartEnd")
        }
    }
    function q(a) {
        if (C.isTouched&&!b.onlyExternal && (!Z || "mousemove" !== a.type)) {
            var c = Z ? a.targetTouches[0].pageX: a.pageX || a.clientX, d = Z ? a.targetTouches[0].pageY: a.pageY || a.clientY;
            if ("undefined" == typeof H && M && (H=!!(H || Math.abs(d - C.touches.startY) > Math.abs(c - C.touches.startX))), "undefined" != typeof H || M || (H=!!(H || Math.abs(d - C.touches.startY) < Math.abs(c - C.touches.startX))), H)
                return void(C.isTouched=!1);
            if (M) {
                if (!b.swipeToNext && c < C.touches.startX ||!b.swipeToPrev && c > C.touches.startX)
                    return 
            } else if (!b.swipeToNext && d < C.touches.startY ||!b.swipeToPrev && d > C.touches.startY)
                return;
            if (a.assignedToSwiper)
                return void(C.isTouched=!1);
            if (a.assignedToSwiper=!0, b.preventLinks && (C.allowLinks=!1), b.onSlideClick && (C.allowSlideClick=!1), b.autoplay && C.stopAutoplay(!0), !Z || 1 === a.touches.length) {
                if (C.isMoved || (C.callPlugins("onTouchMoveStart"), b.loop && (C.fixLoop(), C.positions.start = C.getWrapperTranslate()), b.onTouchMoveStart && C.fireCallback(b.onTouchMoveStart, C)), C.isMoved=!0, a.preventDefault ? a.preventDefault() : a.returnValue=!1, C.touches.current = M ? c : d, C.positions.current = (C.touches.current - C.touches.start) * b.touchRatio + C.positions.start, C.positions.current > 0 && b.onResistanceBefore && C.fireCallback(b.onResistanceBefore, C, C.positions.current), C.positions.current<-e() && b.onResistanceAfter && C.fireCallback(b.onResistanceAfter, C, Math.abs(C.positions.current + e())), b.resistance && "100%" !== b.resistance) {
                    var f;
                    if (C.positions.current > 0 && (f = 1 - C.positions.current / I / 2, C.positions.current = .5 > f ? I / 2 : C.positions.current * f), C.positions.current<-e()) {
                        var g = (C.touches.current - C.touches.start) * b.touchRatio + (e() + C.positions.start);
                        f = (I + g) / I;
                        var h = C.positions.current - g * (1 - f) / 2, i =- e() - I / 2;
                        C.positions.current = i > h || 0 >= f ? i : h
                    }
                }
                if (b.resistance && "100%" === b.resistance && (C.positions.current > 0 && (!b.freeMode || b.freeModeFluid) && (C.positions.current = 0), C.positions.current<-e() && (!b.freeMode || b.freeModeFluid) && (C.positions.current =- e())), !b.followFinger)
                    return;
                if (b.moveStartThreshold)
                    if (Math.abs(C.touches.current - C.touches.start) > b.moveStartThreshold || W) {
                        if (!W)
                            return W=!0, void(C.touches.start = C.touches.current);
                            C.setWrapperTranslate(C.positions.current)
                    } else 
                        C.positions.current = C.positions.start;
                    else 
                        C.setWrapperTranslate(C.positions.current);
                return (b.freeMode || b.watchActiveIndex) && C.updateActiveSlide(C.positions.current), b.grabCursor && (C.container.style.cursor = "move", C.container.style.cursor = "grabbing", C.container.style.cursor = "-moz-grabbin", C.container.style.cursor = "-webkit-grabbing"), X || (X = C.touches.current), Y || (Y = (new Date).getTime()), C.velocity = (C.touches.current - X) / ((new Date).getTime() - Y) / 2, Math.abs(C.touches.current - X) < 2 && (C.velocity = 0), X = C.touches.current, Y = (new Date).getTime(), C.callPlugins("onTouchMoveEnd"), b.onTouchMove && C.fireCallback(b.onTouchMove, C, a), !1
            }
        }
    }
    function r(a) {
        if (H && C.swipeReset(), !b.onlyExternal && C.isTouched) {
            C.isTouched=!1, b.grabCursor && (C.container.style.cursor = "move", C.container.style.cursor = "grab", C.container.style.cursor = "-moz-grab", C.container.style.cursor = "-webkit-grab"), C.positions.current || 0 === C.positions.current || (C.positions.current = C.positions.start), b.followFinger && C.setWrapperTranslate(C.positions.current), C.times.end = (new Date).getTime(), C.touches.diff = C.touches.current - C.touches.start, C.touches.abs = Math.abs(C.touches.diff), C.positions.diff = C.positions.current - C.positions.start, C.positions.abs = Math.abs(C.positions.diff);
            var c = C.positions.diff, d = C.positions.abs, f = C.times.end - C.times.start;
            5 > d && 300 > f && C.allowLinks===!1 && (b.freeMode || 0 === d || C.swipeReset(), b.preventLinks && (C.allowLinks=!0), b.onSlideClick && (C.allowSlideClick=!0)), setTimeout(function() {
                "undefined" != typeof C && null !== C && (b.preventLinks && (C.allowLinks=!0), b.onSlideClick && (C.allowSlideClick=!0))
            }, 100);
            var g = e();
            if (!C.isMoved && b.freeMode)
                return C.isMoved=!1, b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd");
            if (!C.isMoved || C.positions.current > 0 || C.positions.current<-g)
                return C.swipeReset(), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd");
            if (C.isMoved=!1, b.freeMode) {
                if (b.freeModeFluid) {
                    var h, i = 1e3 * b.momentumRatio, j = C.velocity * i, k = C.positions.current + j, l=!1, m = 20 * Math.abs(C.velocity) * b.momentumBounceRatio;
                    - g > k && (b.momentumBounce && C.support.transitions ? ( - m > k + g && (k =- g - m), h =- g, l=!0, $=!0) : k =- g), k > 0 && (b.momentumBounce && C.support.transitions ? (k > m && (k = m), h = 0, l=!0, $=!0) : k = 0), 0 !== C.velocity && (i = Math.abs((k - C.positions.current) / C.velocity)), C.setWrapperTranslate(k), C.setWrapperTransition(i), b.momentumBounce && l && C.wrapperTransitionEnd(function() {
                        $ && (b.onMomentumBounce && C.fireCallback(b.onMomentumBounce, C), C.callPlugins("onMomentumBounce"), C.setWrapperTranslate(h), C.setWrapperTransition(300))
                    }), C.updateActiveSlide(k)
                }
                return (!b.freeModeFluid || f >= 300) && C.updateActiveSlide(C.positions.current), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), void C.callPlugins("onTouchEnd")
            }
            G = 0 > c ? "toNext" : "toPrev", "toNext" === G && 300 >= f && (30 > d ||!b.shortSwipes ? C.swipeReset() : C.swipeNext(!0)), "toPrev" === G && 300 >= f && (30 > d ||!b.shortSwipes ? C.swipeReset() : C.swipePrev(!0));
            var n = 0;
            if ("auto" === b.slidesPerView) {
                for (var o, p = Math.abs(C.getWrapperTranslate()), q = 0, r = 0; r < C.slides.length; r++)
                    if (o = M ? C.slides[r].getWidth(!0, b.roundLengths) : C.slides[r].getHeight(!0, b.roundLengths), q += o, q > p) {
                        n = o;
                        break
                    }
                n > I && (n = I)
            } else 
                n = E * b.slidesPerView;
            "toNext" === G && f > 300 && (d >= n * b.longSwipesRatio ? C.swipeNext(!0) : C.swipeReset()), "toPrev" === G && f > 300 && (d >= n * b.longSwipesRatio ? C.swipePrev(!0) : C.swipeReset()), b.onTouchEnd && C.fireCallback(b.onTouchEnd, C, a), C.callPlugins("onTouchEnd")
        }
    }
    function s(a) {
        var c=!1;
        do 
            a.className.indexOf(b.noSwipingClass)>-1 && (c=!0), a = a.parentElement;
        while (!c && a.parentElement&&-1 === a.className.indexOf(b.wrapperClass));
        return !c && a.className.indexOf(b.wrapperClass)>-1 && a.className.indexOf(b.noSwipingClass)>-1 && (c=!0), c
    }
    function t(a, b) {
        var c, d = document.createElement("div");
        return d.innerHTML = b, c = d.firstChild, c.className += " " + a, c.outerHTML
    }
    function u(a, c, d) {
        function e() {
            var f =+ new Date, l = f - g;
            h += i * l / (1e3 / 60), k = "toNext" === j ? h > a : a > h, k ? (C.setWrapperTranslate(Math.ceil(h)), C._DOMAnimating=!0, window.setTimeout(function() {
                e()
            }, 1e3 / 60)) : (b.onSlideChangeEnd && ("to" === c ? d.runCallbacks===!0 && C.fireCallback(b.onSlideChangeEnd, C, j) : C.fireCallback(b.onSlideChangeEnd, C, j)), C.setWrapperTranslate(a), C._DOMAnimating=!1)
        }
        var f = "to" === c && d.speed >= 0 ? d.speed: b.speed, g =+ new Date;
        if (C.support.transitions ||!b.DOMAnimation)
            C.setWrapperTranslate(a), C.setWrapperTransition(f);
        else {
            var h = C.getWrapperTranslate(), i = Math.ceil((a - h) / f * (1e3 / 60)), j = h > a ? "toNext": "toPrev", k = "toNext" === j ? h > a: a > h;
            if (C._DOMAnimating)
                return;
            e()
        }
        C.updateActiveSlide(a), b.onSlideNext && "next" === c && C.fireCallback(b.onSlideNext, C, a), b.onSlidePrev && "prev" === c && C.fireCallback(b.onSlidePrev, C, a), b.onSlideReset && "reset" === c && C.fireCallback(b.onSlideReset, C, a), ("next" === c || "prev" === c || "to" === c && d.runCallbacks===!0) && v(c)
    }
    function v(a) {
        if (C.callPlugins("onSlideChangeStart"), b.onSlideChangeStart)
            if (b.queueStartCallbacks && C.support.transitions) {
                if (C._queueStartCallbacks)
                    return;
                    C._queueStartCallbacks=!0, C.fireCallback(b.onSlideChangeStart, C, a), C.wrapperTransitionEnd(function() {
                        C._queueStartCallbacks=!1
                    })
            } else 
                C.fireCallback(b.onSlideChangeStart, C, a);
        if (b.onSlideChangeEnd)
            if (C.support.transitions)
                if (b.queueEndCallbacks) {
                    if (C._queueEndCallbacks)
                        return;
                        C._queueEndCallbacks=!0, C.wrapperTransitionEnd(function(c) {
                            C.fireCallback(b.onSlideChangeEnd, c, a)
                        })
                } else 
                    C.wrapperTransitionEnd(function(c) {
                        C.fireCallback(b.onSlideChangeEnd, c, a)
                    });
                else 
                    b.DOMAnimation || setTimeout(function() {
                        C.fireCallback(b.onSlideChangeEnd, C, a)
                    }, 10)
    }
    function w() {
        var a = C.paginationButtons;
        if (a)
            for (var b = 0; b < a.length; b++)
                C.h.removeEventListener(a[b], "click", y)
    }
    function x() {
        var a = C.paginationButtons;
        if (a)
            for (var b = 0; b < a.length; b++)
                C.h.addEventListener(a[b], "click", y)
    }
    function y(a) {
        for (var c, d = a.target || a.srcElement, e = C.paginationButtons, f = 0; f < e.length; f++)
            d === e[f] && (c = f);
        b.autoplay && C.stopAutoplay(!0), C.swipeTo(c)
    }
    function z() {
        _ = setTimeout(function() {
            b.loop ? (C.fixLoop(), C.swipeNext(!0)) : C.swipeNext(!0) || (b.autoplayStopOnLast ? (clearTimeout(_), _ = void 0) : C.swipeTo(0)), C.wrapperTransitionEnd(function() {
                "undefined" != typeof _ && z()
            })
        }, b.autoplay)
    }
    function A() {
        C.calcSlides(), b.loader.slides.length > 0 && 0 === C.slides.length && C.loadSlides(), b.loop && C.createLoop(), C.init(), f(), b.pagination && C.createPagination(!0), b.loop || b.initialSlide > 0 ? C.swipeTo(b.initialSlide, 0, !1) : C.updateActiveSlide(0), b.autoplay && C.startAutoplay(), C.centerIndex = C.activeIndex, b.onSwiperCreated && C.fireCallback(b.onSwiperCreated, C), C.callPlugins("onSwiperCreated")
    }
    if (!document.body.outerHTML && document.body.__defineGetter__ && HTMLElement) {
        var B = HTMLElement.prototype;
        B.__defineGetter__ && B.__defineGetter__("outerHTML", function() {
            return (new XMLSerializer).serializeToString(this)
        })
    }
    if (window.getComputedStyle || (window.getComputedStyle = function(a) {
        return this.el = a, this.getPropertyValue = function(b) {
            var c = /(\-([a-z]){1})/g;
            return "float" === b && (b = "styleFloat"), c.test(b) && (b = b.replace(c, function() {
                return arguments[2].toUpperCase()
            })), a.currentStyle[b] ? a.currentStyle[b] : null
        }, this
    }), Array.prototype.indexOf || (Array.prototype.indexOf = function(a, b) {
        for (var c = b || 0, d = this.length; d > c; c++)
            if (this[c] === a)
                return c;
        return - 1
    }), (document.querySelectorAll || window.jQuery) && "undefined" != typeof a && (a.nodeType || 0 !== c(a).length)) {
        var C = this;
        C.touches = {
            start: 0,
            startX: 0,
            startY: 0,
            current: 0,
            currentX: 0,
            currentY: 0,
            diff: 0,
            abs: 0
        }, C.positions = {
            start: 0,
            abs: 0,
            diff: 0,
            current: 0
        }, C.times = {
            start: 0,
            end: 0
        }, C.id = (new Date).getTime(), C.container = a.nodeType ? a : c(a)[0], C.isTouched=!1, C.isMoved=!1, C.activeIndex = 0, C.centerIndex = 0, C.activeLoaderIndex = 0, C.activeLoopIndex = 0, C.previousIndex = null, C.velocity = 0, C.snapGrid = [], C.slidesGrid = [], C.imagesToLoad = [], C.imagesLoaded = 0, C.wrapperLeft = 0, C.wrapperRight = 0, C.wrapperTop = 0, C.wrapperBottom = 0, C.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") >= 0;
        var D, E, F, G, H, I, J = {
            eventTarget: "wrapper",
            mode: "horizontal",
            touchRatio: 1,
            speed: 300,
            freeMode: !1,
            freeModeFluid: !1,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            slidesPerView: 1,
            slidesPerGroup: 1,
            slidesPerViewFit: !0,
            simulateTouch: !0,
            followFinger: !0,
            shortSwipes: !0,
            longSwipesRatio: .5,
            moveStartThreshold: !1,
            onlyExternal: !1,
            createPagination: !0,
            pagination: !1,
            paginationElement: "span",
            paginationClickable: !1,
            paginationAsRange: !0,
            resistance: !0,
            scrollContainer: !1,
            preventLinks: !0,
            preventLinksPropagation: !1,
            noSwiping: !1,
            noSwipingClass: "swiper-no-swiping",
            initialSlide: 0,
            keyboardControl: !1,
            mousewheelControl: !1,
            mousewheelControlForceToAxis: !1,
            useCSS3Transforms: !0,
            autoplay: !1,
            autoplayDisableOnInteraction: !0,
            autoplayStopOnLast: !1,
            loop: !1,
            loopAdditionalSlides: 0,
            roundLengths: !1,
            calculateHeight: !1,
            cssWidthAndHeight: !1,
            updateOnImagesReady: !0,
            releaseFormElements: !0,
            watchActiveIndex: !1,
            visibilityFullFit: !1,
            offsetPxBefore: 0,
            offsetPxAfter: 0,
            offsetSlidesBefore: 0,
            offsetSlidesAfter: 0,
            centeredSlides: !1,
            queueStartCallbacks: !1,
            queueEndCallbacks: !1,
            autoResize: !0,
            resizeReInit: !1,
            DOMAnimation: !0,
            loader: {
                slides: [],
                slidesHTMLType: "inner",
                surroundGroups: 1,
                logic: "reload",
                loadAllSlides: !1
            },
            swipeToPrev: !0,
            swipeToNext: !0,
            slideElement: "div",
            slideClass: "swiper-slide",
            slideActiveClass: "swiper-slide-active",
            slideVisibleClass: "swiper-slide-visible",
            slideDuplicateClass: "swiper-slide-duplicate",
            wrapperClass: "swiper-wrapper",
            paginationElementClass: "swiper-pagination-switch",
            paginationActiveClass: "swiper-active-switch",
            paginationVisibleClass: "swiper-visible-switch"
        };
        b = b || {};
        for (var K in J)
            if (K in b && "object" == typeof b[K])
                for (var L in J[K])
                    L in b[K] || (b[K][L] = J[K][L]);
            else 
                K in b || (b[K] = J[K]);
        C.params = b, b.scrollContainer && (b.freeMode=!0, b.freeModeFluid=!0), b.loop && (b.resistance = "100%");
        var M = "horizontal" === b.mode, N = ["mousedown", "mousemove", "mouseup"];
        C.browser.ie10 && (N = ["MSPointerDown", "MSPointerMove", "MSPointerUp"]), C.browser.ie11 && (N = ["pointerdown", "pointermove", "pointerup"]), C.touchEvents = {
            touchStart: C.support.touch ||!b.simulateTouch ? "touchstart": N[0],
            touchMove: C.support.touch ||!b.simulateTouch ? "touchmove": N[1],
            touchEnd: C.support.touch ||!b.simulateTouch ? "touchend": N[2]
        };
        for (var O = C.container.childNodes.length - 1; O >= 0; O--)
            if (C.container.childNodes[O].className)
                for (var P = C.container.childNodes[O].className.split(/\s+/), Q = 0; Q < P.length; Q++)
                    P[Q] === b.wrapperClass && (D = C.container.childNodes[O]);
        C.wrapper = D, C._extendSwiperSlide = function(a) {
            return a.append = function() {
                return b.loop ? a.insertAfter(C.slides.length - C.loopedSlides) : (C.wrapper.appendChild(a), C.reInit()), a
            }, a.prepend = function() {
                return b.loop ? (C.wrapper.insertBefore(a, C.slides[C.loopedSlides]), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : C.wrapper.insertBefore(a, C.wrapper.firstChild), C.reInit(), a
            }, a.insertAfter = function(c) {
                if ("undefined" == typeof c)
                    return !1;
                var d;
                return b.loop ? (d = C.slides[c + 1 + C.loopedSlides], d ? C.wrapper.insertBefore(a, d) : C.wrapper.appendChild(a), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : (d = C.slides[c + 1], C.wrapper.insertBefore(a, d)), C.reInit(), a
            }, a.clone = function() {
                return C._extendSwiperSlide(a.cloneNode(!0))
            }, a.remove = function() {
                C.wrapper.removeChild(a), C.reInit()
            }, a.html = function(b) {
                return "undefined" == typeof b ? a.innerHTML : (a.innerHTML = b, a)
            }, a.index = function() {
                for (var b, c = C.slides.length - 1; c >= 0; c--)
                    a === C.slides[c] && (b = c);
                return b
            }, a.isActive = function() {
                return a.index() === C.activeIndex?!0 : !1
            }, a.swiperSlideDataStorage || (a.swiperSlideDataStorage = {}), a.getData = function(b) {
                return a.swiperSlideDataStorage[b]
            }, a.setData = function(b, c) {
                return a.swiperSlideDataStorage[b] = c, a
            }, a.data = function(b, c) {
                return "undefined" == typeof c ? a.getAttribute("data-" + b) : (a.setAttribute("data-" + b, c), a)
            }, a.getWidth = function(b, c) {
                return C.h.getWidth(a, b, c)
            }, a.getHeight = function(b, c) {
                return C.h.getHeight(a, b, c)
            }, a.getOffset = function() {
                return C.h.getOffset(a)
            }, a
        }, C.calcSlides = function(a) {
            var c = C.slides ? C.slides.length: !1;
            C.slides = [], C.displaySlides = [];
            for (var d = 0; d < C.wrapper.childNodes.length; d++)
                if (C.wrapper.childNodes[d].className)
                    for (var e = C.wrapper.childNodes[d].className, f = e.split(/\s+/), i = 0; i < f.length; i++)
                        f[i] === b.slideClass && C.slides.push(C.wrapper.childNodes[d]);
            for (d = C.slides.length - 1; d >= 0; d--)
                C._extendSwiperSlide(C.slides[d]);
            c!==!1 && (c !== C.slides.length || a) && (h(), g(), C.updateActiveSlide(), C.params.pagination && C.createPagination(), C.callPlugins("numberOfSlidesChanged"))
        }, C.createSlide = function(a, c, d) {
            c = c || C.params.slideClass, d = d || b.slideElement;
            var e = document.createElement(d);
            return e.innerHTML = a || "", e.className = c, C._extendSwiperSlide(e)
        }, C.appendSlide = function(a, b, c) {
            return a ? a.nodeType ? C._extendSwiperSlide(a).append() : C.createSlide(a, b, c).append() : void 0
        }, C.prependSlide = function(a, b, c) {
            return a ? a.nodeType ? C._extendSwiperSlide(a).prepend() : C.createSlide(a, b, c).prepend() : void 0
        }, C.insertSlideAfter = function(a, b, c, d) {
            return "undefined" == typeof a?!1 : b.nodeType ? C._extendSwiperSlide(b).insertAfter(a) : C.createSlide(b, c, d).insertAfter(a)
        }, C.removeSlide = function(a) {
            if (C.slides[a]) {
                if (b.loop) {
                    if (!C.slides[a + C.loopedSlides])
                        return !1;
                    C.slides[a + C.loopedSlides].remove(), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()
                } else 
                    C.slides[a].remove();
                return !0
            }
            return !1
        }, C.removeLastSlide = function() {
            return C.slides.length > 0 ? (b.loop ? (C.slides[C.slides.length - 1 - C.loopedSlides].remove(), C.removeLoopedSlides(), C.calcSlides(), C.createLoop()) : C.slides[C.slides.length - 1].remove(), !0) : !1
        }, C.removeAllSlides = function() {
            for (var a = C.slides.length - 1; a >= 0; a--)
                C.slides[a].remove()
        }, C.getSlide = function(a) {
            return C.slides[a]
        }, C.getLastSlide = function() {
            return C.slides[C.slides.length - 1]
        }, C.getFirstSlide = function() {
            return C.slides[0]
        }, C.activeSlide = function() {
            return C.slides[C.activeIndex]
        }, C.fireCallback = function() {
            var a = arguments[0];
            if ("[object Array]" === Object.prototype.toString.call(a))
                for (var c = 0; c < a.length; c++)
                    "function" == typeof a[c] && a[c](arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
            else 
                "[object String]" === Object.prototype.toString.call(a) ? b["on" + a] && C.fireCallback(b["on" + a], arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]) : a(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5])
        }, C.addCallback = function(a, b) {
            var c, e = this;
            return e.params["on" + a] ? d(this.params["on" + a]) ? this.params["on" + a].push(b) : "function" == typeof this.params["on" + a] ? (c = this.params["on" + a], this.params["on" + a] = [], this.params["on" + a].push(c), this.params["on" + a].push(b)) : void 0 : (this.params["on" + a] = [], this.params["on" + a].push(b))
        }, C.removeCallbacks = function(a) {
            C.params["on" + a] && (C.params["on" + a] = null)
        };
        var R = [];
        for (var S in C.plugins)
            if (b[S]) {
                var T = C.plugins[S](C, b[S]);
                T && R.push(T)
            }
        C.callPlugins = function(a, b) {
            b || (b = {});
            for (var c = 0; c < R.length; c++)
                a in R[c] && R[c][a](b)
        }, !C.browser.ie10&&!C.browser.ie11 || b.onlyExternal || C.wrapper.classList.add("swiper-wp8-" + (M ? "horizontal" : "vertical")), b.freeMode && (C.container.className += " swiper-free-mode"), C.initialized=!1, C.init = function(a, c) {
            var d = C.h.getWidth(C.container, !1, b.roundLengths), e = C.h.getHeight(C.container, !1, b.roundLengths);
            if (d !== C.width || e !== C.height || a) {
                C.width = d, C.height = e;
                var f, g, h, i, j, k, l;
                I = M ? d : e;
                var m = C.wrapper;
                if (a && C.calcSlides(c), "auto" === b.slidesPerView) {
                    var n = 0, o = 0;
                    b.slidesOffset > 0 && (m.style.paddingLeft = "", m.style.paddingRight = "", m.style.paddingTop = "", m.style.paddingBottom = ""), m.style.width = "", m.style.height = "", b.offsetPxBefore > 0 && (M ? C.wrapperLeft = b.offsetPxBefore : C.wrapperTop = b.offsetPxBefore), b.offsetPxAfter > 0 && (M ? C.wrapperRight = b.offsetPxAfter : C.wrapperBottom = b.offsetPxAfter), b.centeredSlides && (M ? (C.wrapperLeft = (I - this.slides[0].getWidth(!0, b.roundLengths)) / 2, C.wrapperRight = (I - C.slides[C.slides.length - 1].getWidth(!0, b.roundLengths)) / 2) : (C.wrapperTop = (I - C.slides[0].getHeight(!0, b.roundLengths)) / 2, C.wrapperBottom = (I - C.slides[C.slides.length - 1].getHeight(!0, b.roundLengths)) / 2)), M ? (C.wrapperLeft >= 0 && (m.style.paddingLeft = C.wrapperLeft + "px"), C.wrapperRight >= 0 && (m.style.paddingRight = C.wrapperRight + "px")) : (C.wrapperTop >= 0 && (m.style.paddingTop = C.wrapperTop + "px"), C.wrapperBottom >= 0 && (m.style.paddingBottom = C.wrapperBottom + "px")), k = 0;
                    var p = 0;
                    for (C.snapGrid = [], C.slidesGrid = [], h = 0, l = 0; l < C.slides.length; l++) {
                        f = C.slides[l].getWidth(!0, b.roundLengths), g = C.slides[l].getHeight(!0, b.roundLengths), b.calculateHeight && (h = Math.max(h, g));
                        var q = M ? f: g;
                        if (b.centeredSlides) {
                            var r = l === C.slides.length - 1 ? 0: C.slides[l + 1].getWidth(!0, b.roundLengths), s = l === C.slides.length - 1 ? 0: C.slides[l + 1].getHeight(!0, b.roundLengths), t = M ? r: s;
                            if (q > I) {
                                if (b.slidesPerViewFit)
                                    C.snapGrid.push(k + C.wrapperLeft), C.snapGrid.push(k + q - I + C.wrapperLeft);
                                else 
                                    for (var u = 0; u <= Math.floor(q / (I + C.wrapperLeft)); u++)
                                        C.snapGrid.push(0 === u ? k + C.wrapperLeft : k + C.wrapperLeft + I * u);
                                C.slidesGrid.push(k + C.wrapperLeft)
                            } else 
                                C.snapGrid.push(p), C.slidesGrid.push(p);
                            p += q / 2 + t / 2
                        } else {
                            if (q > I)
                                if (b.slidesPerViewFit)
                                    C.snapGrid.push(k), C.snapGrid.push(k + q - I);
                                else if (0 !== I)
                                    for (var v = 0; v <= Math.floor(q / I); v++)
                                        C.snapGrid.push(k + I * v);
                                else 
                                    C.snapGrid.push(k);
                            else 
                                C.snapGrid.push(k);
                            C.slidesGrid.push(k)
                        }
                        k += q, n += f, o += g
                    }
                    b.calculateHeight && (C.height = h), M ? (F = n + C.wrapperRight + C.wrapperLeft, m.style.width = n + "px", m.style.height = C.height + "px") : (F = o + C.wrapperTop + C.wrapperBottom, m.style.width = C.width + "px", m.style.height = o + "px")
                } else if (b.scrollContainer)
                    m.style.width = "", m.style.height = "", i = C.slides[0].getWidth(!0, b.roundLengths), j = C.slides[0].getHeight(!0, b.roundLengths), F = M ? i : j, m.style.width = i + "px", m.style.height = j + "px", E = M ? i : j;
                else {
                    if (b.calculateHeight) {
                        for (h = 0, j = 0, M || (C.container.style.height = ""), m.style.height = "", l = 0; l < C.slides.length; l++)
                            C.slides[l].style.height = "", h = Math.max(C.slides[l].getHeight(!0), h), M || (j += C.slides[l].getHeight(!0));
                        g = h, C.height = g, M ? j = g : (I = g, C.container.style.height = I + "px")
                    } else 
                        g = M ? C.height : C.height / b.slidesPerView, b.roundLengths && (g = Math.ceil(g)), j = M ? C.height : C.slides.length * g;
                    for (f = M ? C.width / b.slidesPerView : C.width, b.roundLengths && (f = Math.ceil(f)), i = M ? C.slides.length * f : C.width, E = M ? f : g, b.offsetSlidesBefore > 0 && (M ? C.wrapperLeft = E * b.offsetSlidesBefore : C.wrapperTop = E * b.offsetSlidesBefore), b.offsetSlidesAfter > 0 && (M ? C.wrapperRight = E * b.offsetSlidesAfter : C.wrapperBottom = E * b.offsetSlidesAfter), b.offsetPxBefore > 0 && (M ? C.wrapperLeft = b.offsetPxBefore : C.wrapperTop = b.offsetPxBefore), b.offsetPxAfter > 0 && (M ? C.wrapperRight = b.offsetPxAfter : C.wrapperBottom = b.offsetPxAfter), b.centeredSlides && (M ? (C.wrapperLeft = (I - E) / 2, C.wrapperRight = (I - E) / 2) : (C.wrapperTop = (I - E) / 2, C.wrapperBottom = (I - E) / 2)), M ? (C.wrapperLeft > 0 && (m.style.paddingLeft = C.wrapperLeft + "px"), C.wrapperRight > 0 && (m.style.paddingRight = C.wrapperRight + "px")) : (C.wrapperTop > 0 && (m.style.paddingTop = C.wrapperTop + "px"), C.wrapperBottom > 0 && (m.style.paddingBottom = C.wrapperBottom + "px")), F = M ? i + C.wrapperRight + C.wrapperLeft : j + C.wrapperTop + C.wrapperBottom, parseFloat(i) > 0 && (!b.cssWidthAndHeight || "height" === b.cssWidthAndHeight) && (m.style.width = i + "px"), parseFloat(j) > 0 && (!b.cssWidthAndHeight || "width" === b.cssWidthAndHeight) && (m.style.height = j + "px"), k = 0, C.snapGrid = [], C.slidesGrid = [], l = 0; l < C.slides.length; l++)
                        C.snapGrid.push(k), C.slidesGrid.push(k), k += E, parseFloat(f) > 0 && (!b.cssWidthAndHeight || "height" === b.cssWidthAndHeight) && (C.slides[l].style.width = f + "px"), parseFloat(g) > 0 && (!b.cssWidthAndHeight || "width" === b.cssWidthAndHeight) && (C.slides[l].style.height = g + "px")
                    }
                C.initialized ? (C.callPlugins("onInit"), b.onInit && C.fireCallback(b.onInit, C)) : (C.callPlugins("onFirstInit"), b.onFirstInit && C.fireCallback(b.onFirstInit, C)), C.initialized=!0
            }
        }, C.reInit = function(a) {
            C.init(!0, a)
        }, C.resizeFix = function(a) {
            C.callPlugins("beforeResizeFix"), C.init(b.resizeReInit || a), b.freeMode ? C.getWrapperTranslate()<-e() && (C.setWrapperTransition(0), C.setWrapperTranslate( - e())) : (C.swipeTo(b.loop ? C.activeLoopIndex : C.activeIndex, 0, !1), b.autoplay && (C.support.transitions && "undefined" != typeof _ ? "undefined" != typeof _ && (clearTimeout(_), _ = void 0, C.startAutoplay()) : "undefined" != typeof ab && (clearInterval(ab), ab = void 0, C.startAutoplay()))), C.callPlugins("afterResizeFix")
        }, C.destroy = function() {
            var a = C.h.removeEventListener, c = "wrapper" === b.eventTarget ? C.wrapper: C.container;
            C.browser.ie10 || C.browser.ie11 ? (a(c, C.touchEvents.touchStart, p), a(document, C.touchEvents.touchMove, q), a(document, C.touchEvents.touchEnd, r)) : (C.support.touch && (a(c, "touchstart", p), a(c, "touchmove", q), a(c, "touchend", r)), b.simulateTouch && (a(c, "mousedown", p), a(document, "mousemove", q), a(document, "mouseup", r))), b.autoResize && a(window, "resize", C.resizeFix), h(), b.paginationClickable && w(), b.mousewheelControl && C._wheelEvent && a(C.container, C._wheelEvent, j), b.keyboardControl && a(document, "keydown", i), b.autoplay && C.stopAutoplay(), C.callPlugins("onDestroy"), C = null
        }, C.disableKeyboardControl = function() {
            b.keyboardControl=!1, C.h.removeEventListener(document, "keydown", i)
        }, C.enableKeyboardControl = function() {
            b.keyboardControl=!0, C.h.addEventListener(document, "keydown", i)
        };
        var U = (new Date).getTime();
        if (C.disableMousewheelControl = function() {
            return C._wheelEvent ? (b.mousewheelControl=!1, C.h.removeEventListener(C.container, C._wheelEvent, j), !0) : !1
        }, C.enableMousewheelControl = function() {
            return C._wheelEvent ? (b.mousewheelControl=!0, C.h.addEventListener(C.container, C._wheelEvent, j), !0) : !1
        }, b.grabCursor) {
            var V = C.container.style;
            V.cursor = "move", V.cursor = "grab", V.cursor = "-moz-grab", V.cursor = "-webkit-grab"
        }
        C.allowSlideClick=!0, C.allowLinks=!0;
        var W, X, Y, Z=!1, $=!0;
        C.swipeNext = function(a) {
            !a && b.loop && C.fixLoop(), !a && b.autoplay && C.stopAutoplay(!0), C.callPlugins("onSwipeNext");
            var c = C.getWrapperTranslate(), d = c;
            if ("auto" === b.slidesPerView) {
                for (var f = 0; f < C.snapGrid.length; f++)
                    if ( - c >= C.snapGrid[f]&&-c < C.snapGrid[f + 1]) {
                        d =- C.snapGrid[f + 1];
                        break
                    }
            } else {
                var g = E * b.slidesPerGroup;
                d =- (Math.floor(Math.abs(c) / Math.floor(g)) * g + g)
            }
            return d<-e() && (d =- e()), d === c?!1 : (u(d, "next"), !0)
        }, C.swipePrev = function(a) {
            !a && b.loop && C.fixLoop(), !a && b.autoplay && C.stopAutoplay(!0), C.callPlugins("onSwipePrev");
            var c, d = Math.ceil(C.getWrapperTranslate());
            if ("auto" === b.slidesPerView) {
                c = 0;
                for (var e = 1; e < C.snapGrid.length; e++) {
                    if ( - d === C.snapGrid[e]) {
                        c =- C.snapGrid[e - 1];
                        break
                    }
                    if ( - d > C.snapGrid[e]&&-d < C.snapGrid[e + 1]) {
                        c =- C.snapGrid[e];
                        break
                    }
                }
            } else {
                var f = E * b.slidesPerGroup;
                c =- (Math.ceil( - d / f) - 1) * f
            }
            return c > 0 && (c = 0), c === d?!1 : (u(c, "prev"), !0)
        }, C.swipeReset = function() {
            C.callPlugins("onSwipeReset");
            {
                var a, c = C.getWrapperTranslate(), d = E * b.slidesPerGroup;
                - e()
            }
            if ("auto" === b.slidesPerView) {
                a = 0;
                for (var f = 0; f < C.snapGrid.length; f++) {
                    if ( - c === C.snapGrid[f])
                        return;
                    if ( - c >= C.snapGrid[f]&&-c < C.snapGrid[f + 1]) {
                        a = C.positions.diff > 0?-C.snapGrid[f + 1] : - C.snapGrid[f];
                        break
                    }
                }
                - c >= C.snapGrid[C.snapGrid.length - 1] && (a =- C.snapGrid[C.snapGrid.length - 1]), c<=-e() && (a =- e())
            } else 
                a = 0 > c ? Math.round(c / d) * d : 0, c<=-e() && (a =- e());
            return b.scrollContainer && (a = 0 > c ? c : 0), a<-e() && (a =- e()), b.scrollContainer && I > E && (a = 0), a === c?!1 : (u(a, "reset"), !0)
        }, C.swipeTo = function(a, c, d) {
            a = parseInt(a, 10), C.callPlugins("onSwipeTo", {
                index: a,
                speed: c
            }), b.loop && (a += C.loopedSlides);
            var f = C.getWrapperTranslate();
            if (!(a > C.slides.length - 1 || 0 > a)) {
                var g;
                return g = "auto" === b.slidesPerView?-C.slidesGrid[a] : - a * E, g<-e() && (g =- e()), g === f?!1 : (d = d===!1?!1 : !0, u(g, "to", {
                    index : a, speed : c, runCallbacks : d
                }), !0)
            }
        }, C._queueStartCallbacks=!1, C._queueEndCallbacks=!1, C.updateActiveSlide = function(a) {
            if (C.initialized && 0 !== C.slides.length) {
                C.previousIndex = C.activeIndex, "undefined" == typeof a && (a = C.getWrapperTranslate()), a > 0 && (a = 0);
                var c;
                if ("auto" === b.slidesPerView) {
                    if (C.activeIndex = C.slidesGrid.indexOf( - a), C.activeIndex < 0) {
                        for (c = 0; c < C.slidesGrid.length - 1&&!( - a > C.slidesGrid[c]&&-a < C.slidesGrid[c + 1]); c++);
                        var d = Math.abs(C.slidesGrid[c] + a), e = Math.abs(C.slidesGrid[c + 1] + a);
                        C.activeIndex = e >= d ? c : c + 1
                    }
                } else 
                    C.activeIndex = Math[b.visibilityFullFit ? "ceil": "round"]( - a / E);
                if (C.activeIndex === C.slides.length && (C.activeIndex = C.slides.length - 1), C.activeIndex < 0 && (C.activeIndex = 0), C.slides[C.activeIndex]) {
                    if (C.calcVisibleSlides(a), C.support.classList) {
                        var f;
                        for (c = 0; c < C.slides.length; c++)
                            f = C.slides[c], f.classList.remove(b.slideActiveClass), C.visibleSlides.indexOf(f) >= 0 ? f.classList.add(b.slideVisibleClass) : f.classList.remove(b.slideVisibleClass);
                        C.slides[C.activeIndex].classList.add(b.slideActiveClass)
                    } else {
                        var g = new RegExp("\\s*" + b.slideActiveClass), h = new RegExp("\\s*" + b.slideVisibleClass);
                        for (c = 0; c < C.slides.length; c++)
                            C.slides[c].className = C.slides[c].className.replace(g, "").replace(h, ""), C.visibleSlides.indexOf(C.slides[c]) >= 0 && (C.slides[c].className += " " + b.slideVisibleClass);
                        C.slides[C.activeIndex].className += " " + b.slideActiveClass
                    }
                    if (b.loop) {
                        var i = C.loopedSlides;
                        C.activeLoopIndex = C.activeIndex - i, C.activeLoopIndex >= C.slides.length - 2 * i && (C.activeLoopIndex = C.slides.length - 2 * i - C.activeLoopIndex), C.activeLoopIndex < 0 && (C.activeLoopIndex = C.slides.length - 2 * i + C.activeLoopIndex), C.activeLoopIndex < 0 && (C.activeLoopIndex = 0)
                    } else 
                        C.activeLoopIndex = C.activeIndex;
                    b.pagination && C.updatePagination(a)
                }
            }
        }, C.createPagination = function(a) {
            if (b.paginationClickable && C.paginationButtons && w(), C.paginationContainer = b.pagination.nodeType ? b.pagination : c(b.pagination)[0], b.createPagination) {
                var d = "", e = C.slides.length, f = e;
                b.loop && (f -= 2 * C.loopedSlides);
                for (var g = 0; f > g; g++)
                    d += "<" + b.paginationElement + ' class="' + b.paginationElementClass + '"></' + b.paginationElement + ">";
                C.paginationContainer.innerHTML = d
            }
            C.paginationButtons = c("." + b.paginationElementClass, C.paginationContainer), a || C.updatePagination(), C.callPlugins("onCreatePagination"), b.paginationClickable && x()
        }, C.updatePagination = function(a) {
            if (b.pagination&&!(C.slides.length < 1)) {
                var d = c("." + b.paginationActiveClass, C.paginationContainer);
                if (d) {
                    var e = C.paginationButtons;
                    if (0 !== e.length) {
                        for (var f = 0; f < e.length; f++)
                            e[f].className = b.paginationElementClass;
                        var g = b.loop ? C.loopedSlides: 0;
                        if (b.paginationAsRange) {
                            C.visibleSlides || C.calcVisibleSlides(a);
                            var h, i = [];
                            for (h = 0; h < C.visibleSlides.length; h++) {
                                var j = C.slides.indexOf(C.visibleSlides[h]) - g;
                                b.loop && 0 > j && (j = C.slides.length - 2 * C.loopedSlides + j), b.loop && j >= C.slides.length - 2 * C.loopedSlides && (j = C.slides.length - 2 * C.loopedSlides - j, j = Math.abs(j)), i.push(j)
                            }
                            for (h = 0; h < i.length; h++)
                                e[i[h]] && (e[i[h]].className += " " + b.paginationVisibleClass);
                            b.loop ? void 0 !== e[C.activeLoopIndex] && (e[C.activeLoopIndex].className += " " + b.paginationActiveClass) : e[C.activeIndex].className += " " + b.paginationActiveClass
                        } else 
                            b.loop ? e[C.activeLoopIndex] && (e[C.activeLoopIndex].className += " " + b.paginationActiveClass + " " + b.paginationVisibleClass) : e[C.activeIndex].className += " " + b.paginationActiveClass + " " + b.paginationVisibleClass
                    }
                }
            }
        }, C.calcVisibleSlides = function(a) {
            var c = [], d = 0, e = 0, f = 0;
            M && C.wrapperLeft > 0 && (a += C.wrapperLeft), !M && C.wrapperTop > 0 && (a += C.wrapperTop);
            for (var g = 0; g < C.slides.length; g++) {
                d += e, e = "auto" === b.slidesPerView ? M ? C.h.getWidth(C.slides[g], !0, b.roundLengths) : C.h.getHeight(C.slides[g], !0, b.roundLengths) : E, f = d + e;
                var h=!1;
                b.visibilityFullFit ? (d>=-a&&-a + I >= f && (h=!0), - a >= d && f>=-a + I && (h=!0)) : (f>-a&&-a + I >= f && (h=!0), d>=-a&&-a + I > d && (h=!0), - a > d && f>-a + I && (h=!0)), h && c.push(C.slides[g])
            }
            0 === c.length && (c = [C.slides[C.activeIndex]]), C.visibleSlides = c
        };
        var _, ab;
        C.startAutoplay = function() {
            if (C.support.transitions) {
                if ("undefined" != typeof _)
                    return !1;
                if (!b.autoplay)
                    return;
                C.callPlugins("onAutoplayStart"), b.onAutoplayStart && C.fireCallback(b.onAutoplayStart, C), z()
            } else {
                if ("undefined" != typeof ab)
                    return !1;
                if (!b.autoplay)
                    return;
                C.callPlugins("onAutoplayStart"), b.onAutoplayStart && C.fireCallback(b.onAutoplayStart, C), ab = setInterval(function() {
                    b.loop ? (C.fixLoop(), C.swipeNext(!0)) : C.swipeNext(!0) || (b.autoplayStopOnLast ? (clearInterval(ab), ab = void 0) : C.swipeTo(0))
                }, b.autoplay)
            }
        }, C.stopAutoplay = function(a) {
            if (C.support.transitions) {
                if (!_)
                    return;
                _ && clearTimeout(_), _ = void 0, a&&!b.autoplayDisableOnInteraction && C.wrapperTransitionEnd(function() {
                    z()
                }), C.callPlugins("onAutoplayStop"), b.onAutoplayStop && C.fireCallback(b.onAutoplayStop, C)
            } else 
                ab && clearInterval(ab), ab = void 0, C.callPlugins("onAutoplayStop"), b.onAutoplayStop && C.fireCallback(b.onAutoplayStop, C)
        }, C.loopCreated=!1, C.removeLoopedSlides = function() {
            if (C.loopCreated)
                for (var a = 0; a < C.slides.length; a++)
                    C.slides[a].getData("looped")===!0 && C.wrapper.removeChild(C.slides[a])
        }, C.createLoop = function() {
            if (0 !== C.slides.length) {
                C.loopedSlides = "auto" === b.slidesPerView ? b.loopedSlides || 1 : b.slidesPerView + b.loopAdditionalSlides, C.loopedSlides > C.slides.length && (C.loopedSlides = C.slides.length);
                var a, c = "", d = "", e = "", f = C.slides.length, g = Math.floor(C.loopedSlides / f), h = C.loopedSlides%f;
                for (a = 0; g * f > a; a++) {
                    var i = a;
                    if (a >= f) {
                        var j = Math.floor(a / f);
                        i = a - f * j
                    }
                    e += C.slides[i].outerHTML
                }
                for (a = 0; h > a; a++)
                    d += t(b.slideDuplicateClass, C.slides[a].outerHTML);
                for (a = f - h; f > a; a++)
                    c += t(b.slideDuplicateClass, C.slides[a].outerHTML);
                var k = c + e + D.innerHTML + e + d;
                for (D.innerHTML = k, C.loopCreated=!0, C.calcSlides(), a = 0; a < C.slides.length; a++)(a < C.loopedSlides || a >= C.slides.length - C.loopedSlides) 
                    && C.slides[a].setData("looped", !0);
                C.callPlugins("onCreateLoop")
            }
        }, C.fixLoop = function() {
            var a;
            C.activeIndex < C.loopedSlides ? (a = C.slides.length - 3 * C.loopedSlides + C.activeIndex, C.swipeTo(a, 0, !1)) : ("auto" === b.slidesPerView && C.activeIndex >= 2 * C.loopedSlides || C.activeIndex > C.slides.length - 2 * b.slidesPerView) && (a =- C.slides.length + C.activeIndex + C.loopedSlides, C.swipeTo(a, 0, !1))
        }, C.loadSlides = function() {
            var a = "";
            C.activeLoaderIndex = 0;
            for (var c = b.loader.slides, d = b.loader.loadAllSlides ? c.length : b.slidesPerView * (1 + b.loader.surroundGroups), e = 0; d > e; e++)
                a += "outer" === b.loader.slidesHTMLType ? c[e] : "<" + b.slideElement + ' class="' + b.slideClass + '" data-swiperindex="' + e + '">' + c[e] + "</" + b.slideElement + ">";
            C.wrapper.innerHTML = a, C.calcSlides(!0), b.loader.loadAllSlides || C.wrapperTransitionEnd(C.reloadSlides, !0)
        }, C.reloadSlides = function() {
            var a = b.loader.slides, c = parseInt(C.activeSlide().data("swiperindex"), 10);
            if (!(0 > c || c > a.length - 1)) {
                C.activeLoaderIndex = c;
                var d = Math.max(0, c - b.slidesPerView * b.loader.surroundGroups), e = Math.min(c + b.slidesPerView * (1 + b.loader.surroundGroups) - 1, a.length - 1);
                if (c > 0) {
                    var f =- E * (c - d);
                    C.setWrapperTranslate(f), C.setWrapperTransition(0)
                }
                var g;
                if ("reload" === b.loader.logic) {
                    C.wrapper.innerHTML = "";
                    var h = "";
                    for (g = d; e >= g; g++)
                        h += "outer" === b.loader.slidesHTMLType ? a[g] : "<" + b.slideElement + ' class="' + b.slideClass + '" data-swiperindex="' + g + '">' + a[g] + "</" + b.slideElement + ">";
                    C.wrapper.innerHTML = h
                } else {
                    var i = 1e3, j = 0;
                    for (g = 0; g < C.slides.length; g++) {
                        var k = C.slides[g].data("swiperindex");
                        d > k || k > e ? C.wrapper.removeChild(C.slides[g]) : (i = Math.min(k, i), j = Math.max(k, j))
                    }
                    for (g = d; e >= g; g++) {
                        var l;
                        i > g && (l = document.createElement(b.slideElement), l.className = b.slideClass, l.setAttribute("data-swiperindex", g), l.innerHTML = a[g], C.wrapper.insertBefore(l, C.wrapper.firstChild)), g > j && (l = document.createElement(b.slideElement), l.className = b.slideClass, l.setAttribute("data-swiperindex", g), l.innerHTML = a[g], C.wrapper.appendChild(l))
                    }
                }
                C.reInit(!0)
            }
        }, A()
    }
};
Swiper.prototype = {
    plugins: {},
    wrapperTransitionEnd: function(a, b) {
        "use strict";
        function c(h) {
            if (h.target === f && (a(e), e.params.queueEndCallbacks && (e._queueEndCallbacks=!1), !b))
                for (d = 0; d < g.length; d++)
                    e.h.removeEventListener(f, g[d], c)
        }
        var d, e = this, f = e.wrapper, g = ["webkitTransitionEnd", "transitionend", "oTransitionEnd", "MSTransitionEnd", "msTransitionEnd"];
        if (a)
            for (d = 0; d < g.length; d++)
                e.h.addEventListener(f, g[d], c)
    },
    getWrapperTranslate: function(a) {
        "use strict";
        var b, c, d, e, f = this.wrapper;
        return "undefined" == typeof a && (a = "horizontal" === this.params.mode ? "x" : "y"), this.support.transforms && this.params.useCSS3Transforms ? (d = window.getComputedStyle(f, null), window.WebKitCSSMatrix ? e = new WebKitCSSMatrix("none" === d.webkitTransform ? "" : d.webkitTransform) : (e = d.MozTransform || d.OTransform || d.MsTransform || d.msTransform || d.transform || d.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), b = e.toString().split(",")), "x" === a && (c = window.WebKitCSSMatrix ? e.m41 : parseFloat(16 === b.length ? b[12] : b[4])), "y" === a && (c = window.WebKitCSSMatrix ? e.m42 : parseFloat(16 === b.length ? b[13] : b[5]))) : ("x" === a && (c = parseFloat(f.style.left, 10) || 0), "y" === a && (c = parseFloat(f.style.top, 10) || 0)), c || 0
    },
    setWrapperTranslate: function(a, b, c) {
        "use strict";
        var d, e = this.wrapper.style, f = {
            x: 0,
            y: 0,
            z: 0
        };
        3 === arguments.length ? (f.x = a, f.y = b, f.z = c) : ("undefined" == typeof b && (b = "horizontal" === this.params.mode ? "x" : "y"), f[b] = a), this.support.transforms && this.params.useCSS3Transforms ? (d = this.support.transforms3d ? "translate3d(" + f.x + "px, " + f.y + "px, " + f.z + "px)" : "translate(" + f.x + "px, " + f.y + "px)", e.webkitTransform = e.MsTransform = e.msTransform = e.MozTransform = e.OTransform = e.transform = d) : (e.left = f.x + "px", e.top = f.y + "px"), this.callPlugins("onSetWrapperTransform", f), this.params.onSetWrapperTransform && this.fireCallback(this.params.onSetWrapperTransform, this, f)
    },
    setWrapperTransition: function(a) {
        "use strict";
        var b = this.wrapper.style;
        b.webkitTransitionDuration = b.MsTransitionDuration = b.msTransitionDuration = b.MozTransitionDuration = b.OTransitionDuration = b.transitionDuration = a / 1e3 + "s", this.callPlugins("onSetWrapperTransition", {
            duration: a
        }), this.params.onSetWrapperTransition && this.fireCallback(this.params.onSetWrapperTransition, this, a)
    },
    h: {
        getWidth: function(a, b, c) {
            "use strict";
            var d = window.getComputedStyle(a, null).getPropertyValue("width"), e = parseFloat(d);
            return (isNaN(e) || d.indexOf("%") > 0 || 0 > e) && (e = a.offsetWidth - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-left")) - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-right"))), b && (e += parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-left")) + parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-right"))), c ? Math.ceil(e) : e
        },
        getHeight: function(a, b, c) {
            "use strict";
            if (b)
                return a.offsetHeight;
            var d = window.getComputedStyle(a, null).getPropertyValue("height"), e = parseFloat(d);
            return (isNaN(e) || d.indexOf("%") > 0 || 0 > e) && (e = a.offsetHeight - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-top")) - parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-bottom"))), b && (e += parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-top")) + parseFloat(window.getComputedStyle(a, null).getPropertyValue("padding-bottom"))), c ? Math.ceil(e) : e
        },
        getOffset: function(a) {
            "use strict";
            var b = a.getBoundingClientRect(), c = document.body, d = a.clientTop || c.clientTop || 0, e = a.clientLeft || c.clientLeft || 0, f = window.pageYOffset || a.scrollTop, g = window.pageXOffset || a.scrollLeft;
            return document.documentElement&&!window.pageYOffset && (f = document.documentElement.scrollTop, g = document.documentElement.scrollLeft), {
                top: b.top + f - d,
                left: b.left + g - e
            }
        },
        windowWidth: function() {
            "use strict";
            return window.innerWidth ? window.innerWidth : document.documentElement && document.documentElement.clientWidth ? document.documentElement.clientWidth : void 0
        },
        windowHeight: function() {
            "use strict";
            return window.innerHeight ? window.innerHeight : document.documentElement && document.documentElement.clientHeight ? document.documentElement.clientHeight : void 0
        },
        windowScroll: function() {
            "use strict";
            return "undefined" != typeof pageYOffset ? {
                left: window.pageXOffset,
                top: window.pageYOffset
            } : document.documentElement ? {
                left: document.documentElement.scrollLeft,
                top: document.documentElement.scrollTop
            } : void 0
        },
        addEventListener: function(a, b, c, d) {
            "use strict";
            "undefined" == typeof d && (d=!1), a.addEventListener ? a.addEventListener(b, c, d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        removeEventListener: function(a, b, c, d) {
            "use strict";
            "undefined" == typeof d && (d=!1), a.removeEventListener ? a.removeEventListener(b, c, d) : a.detachEvent && a.detachEvent("on" + b, c)
        }
    },
    setTransform: function(a, b) {
        "use strict";
        var c = a.style;
        c.webkitTransform = c.MsTransform = c.msTransform = c.MozTransform = c.OTransform = c.transform = b
    },
    setTranslate: function(a, b) {
        "use strict";
        var c = a.style, d = {
            x: b.x || 0,
            y: b.y || 0,
            z: b.z || 0
        }, e = this.support.transforms3d ? "translate3d(" + d.x + "px," + d.y + "px," + d.z + "px)": "translate(" + d.x + "px," + d.y + "px)";
        c.webkitTransform = c.MsTransform = c.msTransform = c.MozTransform = c.OTransform = c.transform = e, this.support.transforms || (c.left = d.x + "px", c.top = d.y + "px")
    },
    setTransition: function(a, b) {
        "use strict";
        var c = a.style;
        c.webkitTransitionDuration = c.MsTransitionDuration = c.msTransitionDuration = c.MozTransitionDuration = c.OTransitionDuration = c.transitionDuration = b + "ms"
    },
    support: {
        touch: window.Modernizr && Modernizr.touch===!0 || function() {
            "use strict";
            return !!("ontouchstart"in window || window.DocumentTouch && document instanceof DocumentTouch)
        }(),
        transforms3d: window.Modernizr && Modernizr.csstransforms3d===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "webkitPerspective"in a || "MozPerspective"in a || "OPerspective"in a || "MsPerspective"in a || "perspective"in a
        }(),
        transforms: window.Modernizr && Modernizr.csstransforms===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "transform"in a || "WebkitTransform"in a || "MozTransform"in a || "msTransform"in a || "MsTransform"in a || "OTransform"in a
        }(),
        transitions: window.Modernizr && Modernizr.csstransitions===!0 || function() {
            "use strict";
            var a = document.createElement("div").style;
            return "transition"in a || "WebkitTransition"in a || "MozTransition"in a || "msTransition"in a || "MsTransition"in a || "OTransition"in a
        }(),
        classList: function() {
            "use strict";
            var a = document.createElement("div");
            return "classList"in a
        }()
    },
    browser: {
        ie8: function() {
            "use strict";
            var a =- 1;
            if ("Microsoft Internet Explorer" === navigator.appName) {
                var b = navigator.userAgent, c = new RegExp(/MSIE ([0-9]{1,}[\.0-9]{0,})/);
                null !== c.exec(b) && (a = parseFloat(RegExp.$1))
            }
            return - 1 !== a && 9 > a
        }(),
        ie10: window.navigator.msPointerEnabled,
        ie11: window.navigator.pointerEnabled
    }
}, (window.jQuery || window.Zepto)&&!function(a) {
    "use strict";
    a.fn.swiper = function(b) {
        var c;
        return this.each(function(d) {
            var e = a(this);
            if (!e.data("swiper")) {
                var f = new Swiper(e[0], b);
                d || (c = f), e.data("swiper", f)
            }
        }), c
    }
}(window.jQuery || window.Zepto), "undefined" != typeof module && (module.exports = Swiper), "function" == typeof define && define.amd && define([], function() {
    "use strict";
    return Swiper
});;
(function() {
    function n(n) {
        function t(t, r, e, u, i, o) {
            for (; i >= 0 && o > i; i += n) {
                var a = u ? u[i]: i;
                e = r(e, t[a], a, t)
            }
            return e
        }
        return function(r, e, u, i) {
            e = b(e, i, 4);
            var o=!k(r) && m.keys(r), a = (o || r).length, c = n > 0 ? 0 : a - 1;
            return arguments.length < 3 && (u = r[o ? o[c]: c], c += n), t(r, e, u, o, c, a)
        }
    }
    function t(n) {
        return function(t, r, e) {
            r = x(r, e);
            for (var u = O(t), i = n > 0 ? 0 : u - 1; i >= 0 && u > i; i += n)
                if (r(t[i], i, t))
                    return i;
            return - 1
        }
    }
    function r(n, t, r) {
        return function(e, u, i) {
            var o = 0, a = O(e);
            if ("number" == typeof i)
                n > 0 ? o = i >= 0 ? i : Math.max(i + a, o) : a = i >= 0 ? Math.min(i + 1, a) : i + a + 1;
            else if (r && i && a)
                return i = r(e, u), e[i] === u ? i : - 1;
            if (u !== u)
                return i = t(l.call(e, o, a), m.isNaN), i >= 0 ? i + o : - 1;
            for (i = n > 0 ? o : a - 1; i >= 0 && a > i; i += n)
                if (e[i] === u)
                    return i;
            return - 1
        }
    }
    function e(n, t) {
        var r = I.length, e = n.constructor, u = m.isFunction(e) && e.prototype || a, i = "constructor";
        for (m.has(n, i)&&!m.contains(t, i) && t.push(i); r--;)
            i = I[r], i in n && n[i] !== u[i]&&!m.contains(t, i) && t.push(i)
    }
    var u = this, i = u._, o = Array.prototype, a = Object.prototype, c = Function.prototype, f = o.push, l = o.slice, s = a.toString, p = a.hasOwnProperty, h = Array.isArray, v = Object.keys, g = c.bind, y = Object.create, d = function() {}, m = function(n) {
        return n instanceof m ? n : this instanceof m ? void(this._wrapped = n) : new m(n)
    };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = m), exports._ = m) : u._ = m, m.VERSION = "1.8.3";
    var b = function(n, t, r) {
        if (t === void 0)
            return n;
        switch (null == r ? 3 : r) {
        case 1:
            return function(r) {
                return n.call(t, r)
            };
        case 2:
            return function(r, e) {
                return n.call(t, r, e)
            };
        case 3:
            return function(r, e, u) {
                return n.call(t, r, e, u)
            };
        case 4:
            return function(r, e, u, i) {
                return n.call(t, r, e, u, i)
            }
        }
        return function() {
            return n.apply(t, arguments)
        }
    }, x = function(n, t, r) {
        return null == n ? m.identity : m.isFunction(n) ? b(n, t, r) : m.isObject(n) ? m.matcher(n) : m.property(n)
    };
    m.iteratee = function(n, t) {
        return x(n, t, 1 / 0)
    };
    var _ = function(n, t) {
        return function(r) {
            var e = arguments.length;
            if (2 > e || null == r)
                return r;
            for (var u = 1; e > u; u++)
                for (var i = arguments[u], o = n(i), a = o.length, c = 0; a > c; c++) {
                    var f = o[c];
                    t && r[f] !== void 0 || (r[f] = i[f])
                }
            return r
        }
    }, j = function(n) {
        if (!m.isObject(n))
            return {};
        if (y)
            return y(n);
        d.prototype = n;
        var t = new d;
        return d.prototype = null, t
    }, w = function(n) {
        return function(t) {
            return null == t ? void 0 : t[n]
        }
    }, A = Math.pow(2, 53) - 1, O = w("length"), k = function(n) {
        var t = O(n);
        return "number" == typeof t && t >= 0 && A >= t
    };
    m.each = m.forEach = function(n, t, r) {
        t = b(t, r);
        var e, u;
        if (k(n))
            for (e = 0, u = n.length; u > e; e++)
                t(n[e], e, n);
        else {
            var i = m.keys(n);
            for (e = 0, u = i.length; u > e; e++)
                t(n[i[e]], i[e], n)
        }
        return n
    }, m.map = m.collect = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = Array(u), o = 0; u > o; o++) {
            var a = e ? e[o]: o;
            i[o] = t(n[a], a, n)
        }
        return i
    }, m.reduce = m.foldl = m.inject = n(1), m.reduceRight = m.foldr = n( - 1), m.find = m.detect = function(n, t, r) {
        var e;
        return e = k(n) ? m.findIndex(n, t, r) : m.findKey(n, t, r), e !== void 0 && e!==-1 ? n[e] : void 0
    }, m.filter = m.select = function(n, t, r) {
        var e = [];
        return t = x(t, r), m.each(n, function(n, r, u) {
            t(n, r, u) && e.push(n)
        }), e
    }, m.reject = function(n, t, r) {
        return m.filter(n, m.negate(x(t)), r)
    }, m.every = m.all = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i]: i;
            if (!t(n[o], o, n))
                return !1
        }
        return !0
    }, m.some = m.any = function(n, t, r) {
        t = x(t, r);
        for (var e=!k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i]: i;
            if (t(n[o], o, n))
                return !0
        }
        return !1
    }, m.contains = m.includes = m.include = function(n, t, r, e) {
        return k(n) || (n = m.values(n)), ("number" != typeof r || e) && (r = 0), m.indexOf(n, t, r) >= 0
    }, m.invoke = function(n, t) {
        var r = l.call(arguments, 2), e = m.isFunction(t);
        return m.map(n, function(n) {
            var u = e ? t: n[t];
            return null == u ? u : u.apply(n, r)
        })
    }, m.pluck = function(n, t) {
        return m.map(n, m.property(t))
    }, m.where = function(n, t) {
        return m.filter(n, m.matcher(t))
    }, m.findWhere = function(n, t) {
        return m.find(n, m.matcher(t))
    }, m.max = function(n, t, r) {
        var e, u, i =- 1 / 0, o =- 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++)
                e = n[a], e > i && (i = e)
        } else 
            t = x(t, r), m.each(n, function(n, r, e) {
                u = t(n, r, e), (u > o || u===-1 / 0 && i===-1 / 0) && (i = n, o = u)
            });
        return i
    }, m.min = function(n, t, r) {
        var e, u, i = 1 / 0, o = 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++)
                e = n[a], i > e && (i = e)
        } else 
            t = x(t, r), m.each(n, function(n, r, e) {
                u = t(n, r, e), (o > u || 1 / 0 === u && 1 / 0 === i) && (i = n, o = u)
            });
        return i
    }, m.shuffle = function(n) {
        for (var t, r = k(n) ? n : m.values(n), e = r.length, u = Array(e), i = 0; e > i; i++)
            t = m.random(0, i), t !== i && (u[i] = u[t]), u[t] = r[i];
        return u
    }, m.sample = function(n, t, r) {
        return null == t || r ? (k(n) || (n = m.values(n)), n[m.random(n.length - 1)]) : m.shuffle(n).slice(0, Math.max(0, t))
    }, m.sortBy = function(n, t, r) {
        return t = x(t, r), m.pluck(m.map(n, function(n, r, e) {
            return {
                value: n,
                index: r,
                criteria: t(n, r, e)
            }
        }).sort(function(n, t) {
            var r = n.criteria, e = t.criteria;
            if (r !== e) {
                if (r > e || r === void 0)
                    return 1;
                if (e > r || e === void 0)
                    return - 1
            }
            return n.index - t.index
        }), "value")
    };
    var F = function(n) {
        return function(t, r, e) {
            var u = {};
            return r = x(r, e), m.each(t, function(e, i) {
                var o = r(e, i, t);
                n(u, e, o)
            }), u
        }
    };
    m.groupBy = F(function(n, t, r) {
        m.has(n, r) ? n[r].push(t) : n[r] = [t]
    }), m.indexBy = F(function(n, t, r) {
        n[r] = t
    }), m.countBy = F(function(n, t, r) {
        m.has(n, r) ? n[r]++ : n[r] = 1
    }), m.toArray = function(n) {
        return n ? m.isArray(n) ? l.call(n) : k(n) ? m.map(n, m.identity) : m.values(n) : []
    }, m.size = function(n) {
        return null == n ? 0 : k(n) ? n.length : m.keys(n).length
    }, m.partition = function(n, t, r) {
        t = x(t, r);
        var e = [], u = [];
        return m.each(n, function(n, r, i) {
            (t(n, r, i) ? e : u).push(n)
        }), [e, u]
    }, m.first = m.head = m.take = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[0] : m.initial(n, n.length - t)
    }, m.initial = function(n, t, r) {
        return l.call(n, 0, Math.max(0, n.length - (null == t || r ? 1 : t)))
    }, m.last = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[n.length - 1] : m.rest(n, Math.max(0, n.length - t))
    }, m.rest = m.tail = m.drop = function(n, t, r) {
        return l.call(n, null == t || r ? 1 : t)
    }, m.compact = function(n) {
        return m.filter(n, m.identity)
    };
    var S = function(n, t, r, e) {
        for (var u = [], i = 0, o = e || 0, a = O(n); a > o; o++) {
            var c = n[o];
            if (k(c) && (m.isArray(c) || m.isArguments(c))) {
                t || (c = S(c, t, r));
                var f = 0, l = c.length;
                for (u.length += l; l > f;)
                    u[i++] = c[f++]
            } else 
                r || (u[i++] = c)
        }
        return u
    };
    m.flatten = function(n, t) {
        return S(n, t, !1)
    }, m.without = function(n) {
        return m.difference(n, l.call(arguments, 1))
    }, m.uniq = m.unique = function(n, t, r, e) {
        m.isBoolean(t) || (e = r, r = t, t=!1), null != r && (r = x(r, e));
        for (var u = [], i = [], o = 0, a = O(n); a > o; o++) {
            var c = n[o], f = r ? r(c, o, n): c;
            t ? (o && i === f || u.push(c), i = f) : r ? m.contains(i, f) || (i.push(f), u.push(c)) : m.contains(u, c) || u.push(c)
        }
        return u
    }, m.union = function() {
        return m.uniq(S(arguments, !0, !0))
    }, m.intersection = function(n) {
        for (var t = [], r = arguments.length, e = 0, u = O(n); u > e; e++) {
            var i = n[e];
            if (!m.contains(t, i)) {
                for (var o = 1; r > o && m.contains(arguments[o], i); o++);
                o === r && t.push(i)
            }
        }
        return t
    }, m.difference = function(n) {
        var t = S(arguments, !0, !0, 1);
        return m.filter(n, function(n) {
            return !m.contains(t, n)
        })
    }, m.zip = function() {
        return m.unzip(arguments)
    }, m.unzip = function(n) {
        for (var t = n && m.max(n, O).length || 0, r = Array(t), e = 0; t > e; e++)
            r[e] = m.pluck(n, e);
        return r
    }, m.object = function(n, t) {
        for (var r = {}, e = 0, u = O(n); u > e; e++)
            t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r
    }, m.findIndex = t(1), m.findLastIndex = t( - 1), m.sortedIndex = function(n, t, r, e) {
        r = x(r, e, 1);
        for (var u = r(t), i = 0, o = O(n); o > i;) {
            var a = Math.floor((i + o) / 2);
            r(n[a]) < u ? i = a + 1 : o = a
        }
        return i
    }, m.indexOf = r(1, m.findIndex, m.sortedIndex), m.lastIndexOf = r( - 1, m.findLastIndex), m.range = function(n, t, r) {
        null == t && (t = n || 0, n = 0), r = r || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = Array(e), i = 0; e > i; i++, n += r)
            u[i] = n;
        return u
    };
    var E = function(n, t, r, e, u) {
        if (!(e instanceof t))
            return n.apply(r, u);
        var i = j(n.prototype), o = n.apply(i, u);
        return m.isObject(o) ? o : i
    };
    m.bind = function(n, t) {
        if (g && n.bind === g)
            return g.apply(n, l.call(arguments, 1));
        if (!m.isFunction(n))
            throw new TypeError("Bind must be called on a function");
        var r = l.call(arguments, 2), e = function() {
            return E(n, e, t, this, r.concat(l.call(arguments)))
        };
        return e
    }, m.partial = function(n) {
        var t = l.call(arguments, 1), r = function() {
            for (var e = 0, u = t.length, i = Array(u), o = 0; u > o; o++)
                i[o] = t[o] === m ? arguments[e++] : t[o];
            for (; e < arguments.length;)
                i.push(arguments[e++]);
            return E(n, r, this, this, i)
        };
        return r
    }, m.bindAll = function(n) {
        var t, r, e = arguments.length;
        if (1 >= e)
            throw new Error("bindAll must be passed function names");
        for (t = 1; e > t; t++)
            r = arguments[t], n[r] = m.bind(n[r], n);
        return n
    }, m.memoize = function(n, t) {
        var r = function(e) {
            var u = r.cache, i = "" + (t ? t.apply(this, arguments) : e);
            return m.has(u, i) || (u[i] = n.apply(this, arguments)), u[i]
        };
        return r.cache = {}, r
    }, m.delay = function(n, t) {
        var r = l.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r)
        }, t)
    }, m.defer = m.partial(m.delay, m, 1), m.throttle = function(n, t, r) {
        var e, u, i, o = null, a = 0;
        r || (r = {});
        var c = function() {
            a = r.leading===!1 ? 0 : m.now(), o = null, i = n.apply(e, u), o || (e = u = null)
        };
        return function() {
            var f = m.now();
            a || r.leading!==!1 || (a = f);
            var l = t - (f - a);
            return e = this, u = arguments, 0 >= l || l > t ? (o && (clearTimeout(o), o = null), a = f, i = n.apply(e, u), o || (e = u = null)) : o || r.trailing===!1 || (o = setTimeout(c, l)), i
        }
    }, m.debounce = function(n, t, r) {
        var e, u, i, o, a, c = function() {
            var f = m.now() - o;
            t > f && f >= 0 ? e = setTimeout(c, t - f) : (e = null, r || (a = n.apply(i, u), e || (i = u = null)))
        };
        return function() {
            i = this, u = arguments, o = m.now();
            var f = r&&!e;
            return e || (e = setTimeout(c, t)), f && (a = n.apply(i, u), i = u = null), a
        }
    }, m.wrap = function(n, t) {
        return m.partial(t, n)
    }, m.negate = function(n) {
        return function() {
            return !n.apply(this, arguments)
        }
    }, m.compose = function() {
        var n = arguments, t = n.length - 1;
        return function() {
            for (var r = t, e = n[t].apply(this, arguments); r--;)
                e = n[r].call(this, e);
            return e
        }
    }, m.after = function(n, t) {
        return function() {
            return --n < 1 ? t.apply(this, arguments) : void 0
        }
    }, m.before = function(n, t) {
        var r;
        return function() {
            return --n > 0 && (r = t.apply(this, arguments)), 1 >= n && (t = null), r
        }
    }, m.once = m.partial(m.before, 2);
    var M=!{
        toString: null
    }.propertyIsEnumerable("toString"), I = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    m.keys = function(n) {
        if (!m.isObject(n))
            return [];
        if (v)
            return v(n);
        var t = [];
        for (var r in n)
            m.has(n, r) && t.push(r);
        return M && e(n, t), t
    }, m.allKeys = function(n) {
        if (!m.isObject(n))
            return [];
        var t = [];
        for (var r in n)
            t.push(r);
        return M && e(n, t), t
    }, m.values = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++)
            e[u] = n[t[u]];
        return e
    }, m.mapObject = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = u.length, o = {}, a = 0; i > a; a++)
            e = u[a], o[e] = t(n[e], e, n);
        return o
    }, m.pairs = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++)
            e[u] = [t[u], n[t[u]]];
        return e
    }, m.invert = function(n) {
        for (var t = {}, r = m.keys(n), e = 0, u = r.length; u > e; e++)
            t[n[r[e]]] = r[e];
        return t
    }, m.functions = m.methods = function(n) {
        var t = [];
        for (var r in n)
            m.isFunction(n[r]) && t.push(r);
        return t.sort()
    }, m.extend = _(m.allKeys), m.extendOwn = m.assign = _(m.keys), m.findKey = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = 0, o = u.length; o > i; i++)
            if (e = u[i], t(n[e], e, n))
                return e
    }, m.pick = function(n, t, r) {
        var e, u, i = {}, o = n;
        if (null == o)
            return i;
        m.isFunction(t) ? (u = m.allKeys(o), e = b(t, r)) : (u = S(arguments, !1, !1, 1), e = function(n, t, r) {
            return t in r
        }, o = Object(o));
        for (var a = 0, c = u.length; c > a; a++) {
            var f = u[a], l = o[f];
            e(l, f, o) && (i[f] = l)
        }
        return i
    }, m.omit = function(n, t, r) {
        if (m.isFunction(t))
            t = m.negate(t);
        else {
            var e = m.map(S(arguments, !1, !1, 1), String);
            t = function(n, t) {
                return !m.contains(e, t)
            }
        }
        return m.pick(n, t, r)
    }, m.defaults = _(m.allKeys, !0), m.create = function(n, t) {
        var r = j(n);
        return t && m.extendOwn(r, t), r
    }, m.clone = function(n) {
        return m.isObject(n) ? m.isArray(n) ? n.slice() : m.extend({}, n) : n
    }, m.tap = function(n, t) {
        return t(n), n
    }, m.isMatch = function(n, t) {
        var r = m.keys(t), e = r.length;
        if (null == n)
            return !e;
        for (var u = Object(n), i = 0; e > i; i++) {
            var o = r[i];
            if (t[o] !== u[o] ||!(o in u))
                return !1
        }
        return !0
    };
    var N = function(n, t, r, e) {
        if (n === t)
            return 0 !== n || 1 / n === 1 / t;
        if (null == n || null == t)
            return n === t;
        n instanceof m && (n = n._wrapped), t instanceof m && (t = t._wrapped);
        var u = s.call(n);
        if (u !== s.call(t))
            return !1;
        switch (u) {
        case"[object RegExp]":
        case"[object String]":
            return "" + n == "" + t;
        case"[object Number]":
            return + n!==+n?+t!==+t : 0 ===+ n ? 1/+n === 1 / t : + n ===+ t;
        case"[object Date]":
        case"[object Boolean]":
            return + n ===+ t
        }
        var i = "[object Array]" === u;
        if (!i) {
            if ("object" != typeof n || "object" != typeof t)
                return !1;
            var o = n.constructor, a = t.constructor;
            if (o !== a&&!(m.isFunction(o) && o instanceof o && m.isFunction(a) && a instanceof a) && "constructor"in n && "constructor"in t)
                return !1
        }
        r = r || [], e = e || [];
        for (var c = r.length; c--;)
            if (r[c] === n)
                return e[c] === t;
        if (r.push(n), e.push(t), i) {
            if (c = n.length, c !== t.length)
                return !1;
            for (; c--;)
                if (!N(n[c], t[c], r, e))
                    return !1
        } else {
            var f, l = m.keys(n);
            if (c = l.length, m.keys(t).length !== c)
                return !1;
            for (; c--;)
                if (f = l[c], !m.has(t, f) ||!N(n[f], t[f], r, e))
                    return !1
        }
        return r.pop(), e.pop(), !0
    };
    m.isEqual = function(n, t) {
        return N(n, t)
    }, m.isEmpty = function(n) {
        return null == n?!0 : k(n) && (m.isArray(n) || m.isString(n) || m.isArguments(n)) ? 0 === n.length : 0 === m.keys(n).length
    }, m.isElement = function(n) {
        return !(!n || 1 !== n.nodeType)
    }, m.isArray = h || function(n) {
        return "[object Array]" === s.call(n)
    }, m.isObject = function(n) {
        var t = typeof n;
        return "function" === t || "object" === t&&!!n
    }, m.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(n) {
        m["is" + n] = function(t) {
            return s.call(t) === "[object " + n + "]"
        }
    }), m.isArguments(arguments) || (m.isArguments = function(n) {
        return m.has(n, "callee")
    }), "function" != typeof/./ && "object" != typeof Int8Array && (m.isFunction = function(n) {
        return "function" == typeof n ||!1
    }), m.isFinite = function(n) {
        return isFinite(n)&&!isNaN(parseFloat(n))
    }, m.isNaN = function(n) {
        return m.isNumber(n) && n!==+n
    }, m.isBoolean = function(n) {
        return n===!0 || n===!1 || "[object Boolean]" === s.call(n)
    }, m.isNull = function(n) {
        return null === n
    }, m.isUndefined = function(n) {
        return n === void 0
    }, m.has = function(n, t) {
        return null != n && p.call(n, t)
    }, m.noConflict = function() {
        return u._ = i, this
    }, m.identity = function(n) {
        return n
    }, m.constant = function(n) {
        return function() {
            return n
        }
    }, m.noop = function() {}, m.property = w, m.propertyOf = function(n) {
        return null == n ? function() {} : function(t) {
            return n[t]
        }
    }, m.matcher = m.matches = function(n) {
        return n = m.extendOwn({}, n), function(t) {
            return m.isMatch(t, n)
        }
    }, m.times = function(n, t, r) {
        var e = Array(Math.max(0, n));
        t = b(t, r, 1);
        for (var u = 0; n > u; u++)
            e[u] = t(u);
        return e
    }, m.random = function(n, t) {
        return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1))
    }, m.now = Date.now || function() {
        return (new Date).getTime()
    };
    var B = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "`": "&#x60;"
    }, T = m.invert(B), R = function(n) {
        var t = function(t) {
            return n[t]
        }, r = "(?:" + m.keys(n).join("|") + ")", e = RegExp(r), u = RegExp(r, "g");
        return function(n) {
            return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, t) : n
        }
    };
    m.escape = R(B), m.unescape = R(T), m.result = function(n, t, r) {
        var e = null == n ? void 0: n[t];
        return e === void 0 && (e = r), m.isFunction(e) ? e.call(n) : e
    };
    var q = 0;
    m.uniqueId = function(n) {
        var t=++q + "";
        return n ? n + t : t
    }, m.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var K = /(.)^/, z = {
        "'": "'",
        "\\": "\\",
        "\r": "r",
        "\n": "n",
        "\u2028": "u2028",
        "\u2029": "u2029"
    }, D = /\\|'|\r|\n|\u2028|\u2029/g, L = function(n) {
        return "\\" + z[n]
    };
    m.template = function(n, t, r) {
        !t && r && (t = r), t = m.defaults({}, t, m.templateSettings);
        var e = RegExp([(t.escape || K).source, (t.interpolate || K).source, (t.evaluate || K).source].join("|") + "|$", "g"), u = 0, i = "__p+='";
        n.replace(e, function(t, r, e, o, a) {
            return i += n.slice(u, a).replace(D, L), u = a + t.length, r ? i += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'" : e ? i += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : o && (i += "';\n" + o + "\n__p+='"), t
        }), i += "';\n", t.variable || (i = "with(obj||{}){\n" + i + "}\n"), i = "var __t,__p='',__j=Array.prototype.join," + "print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", i)
        } catch (a) {
            throw a.source = i, a
        }
        var c = function(n) {
            return o.call(this, n, m)
        }, f = t.variable || "obj";
        return c.source = "function(" + f + "){\n" + i + "}", c
    }, m.chain = function(n) {
        var t = m(n);
        return t._chain=!0, t
    };
    var P = function(n, t) {
        return n._chain ? m(t).chain() : t
    };
    m.mixin = function(n) {
        m.each(m.functions(n), function(t) {
            var r = m[t] = n[t];
            m.prototype[t] = function() {
                var n = [this._wrapped];
                return f.apply(n, arguments), P(this, r.apply(m, n))
            }
        })
    }, m.mixin(m), m.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments), "shift" !== n && "splice" !== n || 0 !== r.length || delete r[0], P(this, r)
        }
    }), m.each(["concat", "join", "slice"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            return P(this, t.apply(this._wrapped, arguments))
        }
    }), m.prototype.value = function() {
        return this._wrapped
    }, m.prototype.valueOf = m.prototype.toJSON = m.prototype.value, m.prototype.toString = function() {
        return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return m
    })
}).call(this);
//# sourceMappingURL=underscore-min.map;


(function($) {
    $.fn.autoFocus = function(callback) {
        var boxArray = $(this);
        $(this).each(function() {
            $(this).on('keyup', function(event) {
                if (event.keyCode == 13) {
                    var boxIndex = boxArray.indexOf(this);
                    if (boxIndex == boxArray.length - 1) {
                        if (callback)
                            callback();
                    } else {
                        var nextBox = boxArray[++boxIndex];
                        nextBox.focus();
                    }
                }
            });
        });
    };
})($);;

var swipers = {};
window.CLICK_EVENT = 'click';
if ("ontouchstart"in document) {
    window.CLICK_EVENT = 'tap';
}
if ("ontap"in document) {}
initEvents.push(function() {
    try {
        $('html').removeClass('loading');
        window.mui && mui.init({
            swipeBack: false
        });
        $('#loading_mask').length > 0 && $('#loading_mask').hide();
    } catch (e) {}
    typeof FastClick != 'undefined' && FastClick.attach(document.body);
    if (navigator.userAgent.search(/MicroMessenger/ig)>-1) {
        $('.index-header-bar').addClass('in-wexin');
        if ($('.index-header-bar').length > 0) {
            $('.mui-content').css({
                marginTop: 0
            });
        }
    }
    $("img[data-lazy]").lazyload();
    $(document).on(window.CLICK_EVENT, '*[_click]', function(e) {
        var thisClick = $(this).attr('_click');
        switch (thisClick) {
        case'href':
            var url = $(this).attr('href');
            console.log(url);
            if ($(this).attr('target')) {
                window.open(url, $(this).attr('target'));
            } else {
                location.href = $(this).attr('href');
            }
            return false;
        default:
            try {
                var res = window[thisClick](e);
            } catch (e) {
                eval(thisClick);
                console.log(e.description);
            }
            $(this).blur();
            return res;
        }
    });
    window.runSlider = function(that) {
        var position = that.find(that.data('pos') || '.pagination');
        var autoPlay = that.data('autoplay');
        autoPlay = autoPlay==-1 ? false : autoPlay;
        var swiper;
        function onResize() {
            var activeSlide = swiper.activeSlide();
            var bottomHeight = $('.mui-bar-tab').length > 0 ? 50 * 1.5: 0;
            var maxHeight = parseInt($(activeSlide).children().height(), 10);
            var slideHeight = Math.max(maxHeight + bottomHeight + 20, 200);
            that.css('height', slideHeight);
            that.find('.swiper-wrapper').css('height', slideHeight);
            console.log('height', slideHeight);
        }
        function onChange(swiper, onResize) {
            var onSlide = window[that.data('onslide')];
            if (typeof onResize != 'function') {
                onResize = false;
            }
            onSlide && onSlide(swiper, onResize);
        }
        swiper = new Swiper(that[0], {
            loop: true,
            speed: 500,
            autoplay: autoPlay,
            calculateHeight: true,
            paginationClickable: true,
            pagination: position[0],
            onSlideChangeEnd: onChange
        });
        var name = that.data('name');
        setTimeout(function() {
            onChange(swiper, onResize);
        }, 500);
        if (name) {
            swipers[name] = swiper;
        }
        that.find('.arrow-left').on('click', function(e) {
            e.preventDefault()
            swiper.swipePrev()
        });
        that.find('.arrow-right').on('click', function(e) {
            e.preventDefault()
            swiper.swipeNext()
        });
    };
    $('.swiper-container').each(function() {
        runSlider($(this));
    });
    window.API = (function() {
        var that = this;
        that.post = function(api, post, callback) {
            $.post(DIR + api + '&FORM_HASH=' + FORM_HASH, post, function(result) {
                var data;
                try {
                    eval('data=' + result);
                } catch (e) {}
                callback && callback(data);
            });
        };
        return that;
    })();
    window.formInit();
    var suggestElements = $('.suggest-input');
    if (suggestElements.length > 0) {
        suggestElements.on('input', function() {
            var key = $.trim($(this).val());
            if (key == '') {
                $(this).next().hide();
            } else {
                $(this).next().show();
            }
        }).on('focus', function() {
            $(this).css({
                color: '#000'
            });
        }).on('blur', function() {
            $(this).css({
                color: '#999'
            });
        }).suggest({
            onQuery: function(key, onResult) {
                window.API.post('suggest', {
                    key: key
                }, function(data) {
                    onResult((data && data.extend) ? data.extend : false);
                });
            },
            appendParent: ''
        });
    }
    $(document).on(window.CLICK_EVENT, '.slide-menu', function(e) {
        var target = $(this).data('target');
        var title = $(this).data('title');
        if (!target) {
            return false;
        }
        var height = $(window).height();
        var that = $('#' + $(this).data('target'));
        var option = $(this);
        var duration = 200;
        function closeSortMenu() {
            option.removeClass('active');
            that.css({
                top: 0,
                opacity: 1
            }).animate({
                top: height,
                opacity: 0
            }, duration, 'ease-out', function() {
                that.hide();
            });
        }
        that.find('.sort-close').off('click').on('click', closeSortMenu);
        that.find('.sort-title-text').text(title);
        option.addClass('active');
        that.show().css({
            top: height,
            opacity: 0
        }).animate({
            top: 0,
            opacity: 1
        }, duration, 'ease-in', function() {
            that.show();
        });
        that.find('*[data-bg]').each(function() {
            $(this).css({
                backgroundImage: 'url(' + $(this).data('bg') + ')',
                backgroundSize: 'cover'
            }).removeAttr('data-bg');
        });
    });
});
window.formInit = function(selector) {
    $(selector || 'form[data-api]').each(function() {
        var currentForm = $(this);
        var ajaxFrameId = 'ajaxframe';
        function ajaxForm(form, api, callback) {
            var ajaxForm = $(form);
            var ajaxFrame = $('#' + ajaxFrameId);
            if (ajaxFrame.length == 0) {
                ajaxFrame = $("<iframe name='" + ajaxFrameId + "' id='" + ajaxFrameId + "' style='display:none'></iframe>");
                $(document.body).append(ajaxFrame);
            }
            $(ajaxForm).attr('target', ajaxFrameId).attr('action', DIR + 'api/' + api + '/?ajax=1&frame=1&FORM_HASH=' + FORM_HASH);
            ajaxFrame.off('load').on('load', function() {
                formLoad(callback);
            });
            try {
                plus.nativeUI.showWaiting();
            } catch (e) {}
        }
        function formLoad(callback) {
            try {
                plus.nativeUI.closeWaiting();
            } catch (e) {}
            currentForm.data('posting', 0);
            var theFrame = $('#' + ajaxFrameId).get(0);
            var responseText = (theFrame.contentDocument ? theFrame.contentDocument : theFrame.contentWindow.document).body.innerText;
            var data;
            try {
                eval('data=' + responseText);
            } catch (e) {}
            callback && callback(data);
        }
        window.onDefaultCallback = function(data) {
            if (data && data.error == 0) {
                showMessage('&#25805;&#20316;&#25104;&#21151;');
            } else {
                showMessage('&#25805;&#20316;&#22833;&#36133;&#65306;' + (data.data ? data.data : ''));
            }
        };
        var onSuccess = function() {
            var api = currentForm.data('api'), callback = currentForm.data('call');
            callback = callback ? callback : 'onDefaultCallback';
            if (!api) {
                return false;
            }
            if (currentForm.data('posting') == 1) {
                return false;
            }
            currentForm.data('posting', 1);
            ajaxForm(currentForm, api, function(resp) {
                try {
                    if (typeof resp != 'object') {
                        eval('resp=' + resp);
                    }
                    if (window[callback]) {
                        window[callback](resp);
                    }
                } catch (e) {
                    console.log('Exception', api, e);
                }
            });
            return true;
        };
        currentForm.mzForm({
            succText: '',
            errorText: '&#36755;&#20837;&#38169;&#35823;',
            onSuccess: onSuccess
        });
        var autoFocusQuery = currentForm.data('enterfocus');
        if (autoFocusQuery) {
            var autFocusElement = currentForm.find(autoFocusQuery);
            $(autFocusElement).autoFocus(function() {
                currentForm.trigger('submit');
            });
        }
    });
};
window.mzTpl = (function() {
    var cache = {};
    return function tmpl(str, data) {
        var fn=!/\W/.test(str) ? cache[str] = cache[str] || mzTpl(document.getElementById(str).innerHTML) : new Function("obj", "var p=[],print=function(){p.push.apply(p,arguments);};" + "with(obj){p.push('" +
        str.replace(/[\r\t\n]/g, " ").split("<%").join("\t").replace(/((^|%>)[^\t]*)'/g, "$1\r").replace(/\t=(.*?)%>/g, "',$1,'").split("\t").join("');").split("%>").join("p.push('").split("\r").join("\\'")
        + "');}return p.join('');");
        return data ? fn(data) : fn;
    };
})();
window.showMessage = function(msg, title) {
    if (window.mui) {
        if ($("#msg-dialog").length == 0) {
            var msgWrapper = '<div id="msg-dialog" class="mui-popover simple-dialog" style="top:50px;margin-left:5%;max-height: 90%;overflow: hidden; overflow-y: auto;width:90%;"><div class="mui-content-padded"><div class="close" onclick="mui(\'#msg-dialog\').popover(\'hide\')">x</div><div class="msg-title"></div><div class="msg-content"></div></div></div>';
            $(document.body).append(msgWrapper);
        }
        if (msg == 'hide') {
            mui("#msg-dialog").popover("hide");
            return;
        }
        if (title) {
            $("#msg-dialog .msg-title").html(title).show();
        } else {
            $("#msg-dialog .msg-title").hide();
        }
        $("#msg-dialog .msg-content").html(msg);
        mui("#msg-dialog").popover("show");
    } else if (window.jQuery) {
        if ($('#').length == 0) {
            var msgWrapper = '<div class="modal fade" id="msg-dialog" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"><div class="modal-dialog" role="document"><div class="modal-content"> <div class="modal-header">   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel"></h4> </div> <div class="modal-body"></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div>';
            $(document.body).append(msgWrapper);
        }
        if (msg == 'hide') {
            $('#msg-dialog').modal('hide');
            return;
        }
        $("#msg-dialog .modal-title").html(title || '&#28040;&#24687;&#25552;&#31034;').show();
        $("#msg-dialog .modal-body").html(msg);
        $('#msg-dialog').modal('show');
    }
};
window.closeWindow = function(event) {
    try {
        plus.webview.currentWebview().close();
    } catch (e) {
        console.log(e);
    }
    try {
        window.close();
    } catch (e) {
        console.log(e);
    }
    return false;
};
window.openIt = function(o, windowName) {
    var link = '', locationChange = false, eleLength = 0, openNew = false, showLoading = false;
    if (o.target) {
        o = o.target;
    }
    try {
        eleLength = $(o).length;
    } catch (e) {}
    if (eleLength > 0) {
        link = $(o).attr('href');
        showLoading = $(o).data('loading') ? true : false;
        windowName = (windowName || $(o).data('name')) + link;
        locationChange = $(o).attr('target') == '_blank' ? true : false;
    } else {
        if (typeof o == 'string') {
            link = o;
        } else {
            link = o.link;
        }
        locationChange = true;
    }
    if (link.search(/http:\/\//ig)==-1) {
        link = 'http://' + location.hostname + link;
    }
    if (!window.plus) {
        if (locationChange) {
            window.open(link);
        } else {
            location.href = link;
        }
        window.event.stopPropagation();
        return !locationChange;
    }
    var aniShow = "pop-in";
    var webview_style = {
        popGesture: "close"
    };
    webview_style.zindex = 9998;
    webview_style.popGesture = "close";
    windowName = windowName || 'chapter';
    mui.openWindow({
        id: windowName,
        url: link,
        styles: webview_style,
        show: {
            aniShow: aniShow
        },
        render: "onscreen",
        waiting: {
            autoShow: showLoading,
            title: ''
        },
        scalable: true
    });
    window.event.stopPropagation();
    return false;
};
window.imgErr = function(o) {
    o.onerror = null;
    o.src = STATIC_URL;
};
function plusReady() {
    for (var i in initEvents) {
        try {
            initEvents[i]();
        } catch (e) {
            console.log(e);
        }
    }
}
if (window.mui && mui.os.plus) {
    if (window.plus) {
        $(document).ready(plusReady);
    } else {
        mui.plusReady(plusReady);
    }
} else {
    $(document).ready(plusReady);
};

initEvents.push(function() {
    window.store = (function() {
        var that = this;
        that.agent = 'plus';
        if (window.localStorage) {
            that.set = function(key, value) {
                return window.localStorage.setItem(key, value + "");
            };
            that.get = function(key) {
                return window.localStorage.getItem(key);
            };
            that.agent = 'local';
        } else {
            that.set = function(key, value) {
                return $.fn.cookie(key, value, 9999);
            };
            that.get = function(key) {
                return $.fn.cookie(key);
            };
            that.agent = 'cookie';
        }
        return that;
    })();
});;

window.userLogin = function(data) {
    try {
        mui.ge.fireEvent('auth', data);
    } catch (e) {}
    if (data && data.username) {
        window.store.set('login', data.phone);
    }
};
mui('#desc').on('tap','a',function(){document.location.href=this.href;});
