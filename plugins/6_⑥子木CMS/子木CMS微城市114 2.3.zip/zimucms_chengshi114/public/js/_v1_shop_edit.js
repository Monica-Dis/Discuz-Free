/*[tplStatic 1.0 - 5908508]*/

!function(e, t, i, a) {
    var n = 30, r = 90, s = 40, c = 10, l = e.rad2deg = function(e) {
        return e / (Math.PI / 180);
    }, o = (e.deg2rad = function(e) {
        return e * (Math.PI / 180);
    }, navigator.platform.toLowerCase()), d = navigator.userAgent.toLowerCase(), u = d.indexOf("iphone")>-1 && "iphone" == o, p = e.Picker = function(e, t) {
        var i = this;
        i.holder = e, i.options = t || {}, i.init(), i.initInertiaParams(), i.calcElementItemPostion(!0), i.bindEvent();
    };
    p.prototype.findElementItems = function() {
        var e = this;
        return e.elementItems = [].slice.call(e.holder.querySelectorAll("li")), e.elementItems;
    }, p.prototype.init = function() {
        var e = this;
        e.list = e.holder.querySelector("ul"), e.findElementItems(), e.height = e.holder.offsetHeight, e.r = e.height / 2 - c, e.d = 2 * e.r, e.itemHeight = e.elementItems.length > 0 ? e.elementItems[0].offsetHeight : s, e.itemAngle = parseInt(e.calcAngle(0.8 * e.itemHeight)), e.hightlightRange = e.itemAngle / 2, e.visibleRange = r, e.beginAngle = 0, e.beginExceed = e.beginAngle - n, e.list.angle = e.beginAngle, u && (e.list.style.webkitTransformOrigin = "center center " + e.r + "px");
    }, p.prototype.calcElementItemPostion = function(e) {
        var t = this;
        e && (t.items = []), t.elementItems.forEach(function(i) {
            var a = t.elementItems.indexOf(i);
            if (t.endAngle = t.itemAngle * a, i.angle = t.endAngle, i.style.webkitTransformOrigin = "center center -" + t.r + "px", i.style.webkitTransform = "translateZ(" + t.r + "px) rotateX(" +- t.endAngle + "deg)", e) {
                var n = {};
                n.text = i.innerHTML || "", n.value = i.getAttribute("data-value") || n.text, t.items.push(n);
            }
        }), t.endExceed = t.endAngle + n, t.calcElementItemVisibility(t.beginAngle);
    }, p.prototype.calcAngle = function(e) {
        var t = this, i = b = parseFloat(t.r);
        e = Math.abs(e);
        var a = 180 * parseInt(e / t.d);
        e%=t.d;
        var n = (i * i + b * b - e * e) / (2 * i * b), r = a + l(Math.acos(n));
        return r;
    }, p.prototype.calcElementItemVisibility = function(e) {
        var t = this;
        t.elementItems.forEach(function(i) {
            var a = Math.abs(i.angle - e);
            a < t.hightlightRange ? i.classList.add("highlight") : a < t.visibleRange ? (i.classList.add("visible"), i.classList.remove("highlight")) : (i.classList.remove("highlight"), i.classList.remove("visible"));
        });
    }, p.prototype.setAngle = function(e) {
        var t = this;
        t.list.angle = e, t.list.style.webkitTransform = "perspective(1000px) rotateY(0deg) rotateX(" + e + "deg)", t.calcElementItemVisibility(e);
    }, p.prototype.bindEvent = function() {
        var e = this, t = 0, i = null;
        e.holder.addEventListener("touchstart", function(a) {
            a.preventDefault(), e.list.style.webkitTransition = "", i = (a.changedTouches ? a.changedTouches[0] : a).pageY, t = e.list.angle, e.updateInertiaParams(a, !0);
        }, !1), e.holder.addEventListener("touchend", function(t) {
            t.preventDefault(), e.startInertiaScroll(t);
        }, !1), e.holder.addEventListener("touchcancel", function(t) {
            t.preventDefault(), e.startInertiaScroll(t);
        }, !1), e.holder.addEventListener("touchmove", function(a) {
            a.preventDefault();
            var n = (a.changedTouches ? a.changedTouches[0] : a).pageY, r = n - i, s = e.calcAngle(r), c = r > 0 ? t - s: t + s;
            c > e.endExceed && (c = e.endExceed), c < e.beginExceed && (c = e.beginExceed), e.setAngle(c), e.updateInertiaParams(a);
        }, !1), $(e.list).on("tap click", function(t) {
            elementItem = t.target, "LI" == elementItem.tagName && e.setSelectedIndex(e.elementItems.indexOf(elementItem), 200);
        }, !1);
    }, p.prototype.initInertiaParams = function() {
        var e = this;
        e.lastMoveTime = 0, e.lastMoveStart = 0, e.stopInertiaMove=!1;
    }, p.prototype.updateInertiaParams = function(e, t) {
        var i = this, a = e.changedTouches ? e.changedTouches[0]: e;
        if (t) {
            i.lastMoveStart = a.pageY, i.lastMoveTime = e.timeStamp || Date.now(), i.startAngle = i.list.angle;
        } else {
            var n = e.timeStamp || Date.now();
            n - i.lastMoveTime > 300 && (i.lastMoveTime = n, i.lastMoveStart = a.pageY);
        }
        i.stopInertiaMove=!0;
    }, p.prototype.startInertiaScroll = function(e) {
        var t = this, i = e.changedTouches ? e.changedTouches[0]: e, a = e.timeStamp || Date.now(), n = (i.pageY - t.lastMoveStart) / (a - t.lastMoveTime), r = n > 0?-1 : 1, s = 0.0006 * r*-1, c = Math.abs(n / s), l = n * c / 2, o = t.list.angle, d = t.calcAngle(l) * r, u = d;
        return o + d < t.beginExceed && (d = t.beginExceed - o, c = c * (d / u) * 0.6), o + d > t.endExceed && (d = t.endExceed - o, c = c * (d / u) * 0.6), 0 == d ? void t.endScroll() : void t.scrollDistAngle(a, o, d, c);
    }, p.prototype.scrollDistAngle = function(e, t, i, a) {
        var n = this;
        n.stopInertiaMove=!1, function(e, t, i, a) {
            var r = 13, s = a / r, c = 0;
            !function l() {
                if (!n.stopInertiaMove) {
                    var e = n.quartEaseOut(c, t, i, s);
                    return n.setAngle(e), c++, c > s - 1 || e < n.beginExceed || e > n.endExceed ? void n.endScroll() : void setTimeout(l, r);
                }
            }();
        }(e, t, i, a);
    }, p.prototype.quartEaseOut = function(e, t, i, a) {
        return - i * ((e = e / a - 1) * e * e * e - 1) + t;
    }, p.prototype.endScroll = function() {
        var e = this;
        if (e.list.angle < e.beginAngle) {
            e.list.style.webkitTransition = "150ms ease-out", e.setAngle(e.beginAngle);
        } else {
            if (e.list.angle > e.endAngle) {
                e.list.style.webkitTransition = "150ms ease-out", e.setAngle(e.endAngle);
            } else {
                var t = parseInt((e.list.angle / e.itemAngle).toFixed(0));
                e.list.style.webkitTransition = "100ms ease-out", e.setAngle(e.itemAngle * t);
            }
        }
        e.triggerChange();
    }, p.prototype.triggerChange = function(t) {
        var i = this;
        setTimeout(function() {
            var a = i.getSelectedIndex(), n = i.items[a];
            e.trigger && (a != i.lastIndex || t) && e.trigger(i.holder, "change", {
                index: a,
                item: n
            }), i.lastIndex = a;
        }, 0);
    }, p.prototype.correctAngle = function(e) {
        var t = this;
        return e < t.beginAngle ? t.beginAngle : e > t.endAngle ? t.endAngle : e;
    }, p.prototype.setItems = function(e) {
        var t = this;
        t.items = e || [];
        var i = [];
        t.items.forEach(function(e) {
            null !== e && e !== a && i.push("<li>" + (e.text || e) + "</li>");
        }), t.list.innerHTML = i.join(""), t.findElementItems(), t.calcElementItemPostion(), t.setAngle(t.correctAngle(t.list.angle)), t.triggerChange(!0);
    }, p.prototype.getItems = function() {
        var e = this;
        return e.items;
    }, p.prototype.getSelectedIndex = function() {
        var e = this;
        return parseInt((e.list.angle / e.itemAngle).toFixed(0));
    }, p.prototype.setSelectedIndex = function(e, t) {
        var i = this;
        i.list.style.webkitTransition = "";
        var a = i.correctAngle(i.itemAngle * e);
        if (t && t > 0) {
            var n = a - i.list.angle;
            i.scrollDistAngle(Date.now(), i.list.angle, n, t);
        } else {
            i.setAngle(a);
        }
        i.triggerChange();
    }, p.prototype.getSelectedItem = function() {
        var e = this;
        return e.items[e.getSelectedIndex()];
    }, p.prototype.getSelectedValue = function() {
        var e = this;
        return (e.items[e.getSelectedIndex()] || {}).value;
    }, p.prototype.getSelectedText = function() {
        var e = this;
        return (e.items[e.getSelectedIndex()] || {}).text;
    }, p.prototype.setSelectedValue = function(e, t) {
        var i = this;
        for (var a in i.items) {
            var n = i.items[a];
            if (n.value == e) {
                return void i.setSelectedIndex(a, t);
            }
        }
    }, e.fn && (e.fn.picker = function(e) {
        return this.each(function(t, i) {
            if (!i.picker) {
                if (e) {
                    i.picker = new p(i, e);
                } else {
                    var a = i.getAttribute("data-picker-options"), n = a ? JSON.parse(a): {};
                    i.picker = new p(i, n);
                }
            }
        }), this[0] ? this[0].picker : null;
    }, e.ready(function() {
        e(".mui-picker").picker();
    }));
}(this.mui || this, window, document, void 0), function(e, t) {
    e.dom = function(i) {
        return "string" != typeof i ? i instanceof Array || i[0] && i.length ? [].slice.call(i) : [i] : (e.__create_dom_div__ || (e.__create_dom_div__ = t.createElement("div")), e.__create_dom_div__.innerHTML = i, [].slice.call(e.__create_dom_div__.childNodes));
    };
    var i = '<div class="mui-poppicker">        <div class="mui-poppicker-header">          <button class="mui-btn mui-poppicker-btn-cancel">cancel</button>            <button class="mui-btn mui-btn-blue mui-poppicker-btn-ok">ok</button>           <div class="mui-poppicker-clear"></div>     </div>      <div class="mui-poppicker-body">        </div>  </div>', a = '<div class="mui-picker">      <div class="mui-picker-inner">          <div class="mui-pciker-rule mui-pciker-rule-ft"></div>          <ul class="mui-pciker-list">            </ul>           <div class="mui-pciker-rule mui-pciker-rule-bg"></div>      </div>  </div>';
    e.PopPicker = e.Class.extend({
        init: function(a) {
            var n = this;
            n.options = a || {}, n.options.buttons = n.options.buttons || ["\u53d6\u6d88", "\u786e\u5b9a"], n.panel = e.dom(i)[0], t.body.appendChild(n.panel), n.ok = n.panel.querySelector(".mui-poppicker-btn-ok"), n.cancel = n.panel.querySelector(".mui-poppicker-btn-cancel"), n.body = n.panel.querySelector(".mui-poppicker-body"), n.mask = e.createMask(), n.cancel.innerText = n.options.buttons[0], n.ok.innerText = n.options.buttons[1], $(n.cancel).on("tap click", function(e) {
                n.hide();
            }, !1), $(n.ok).on("tap click", function(e) {
                if (n.callback) {
                    var t = n.callback(n.getSelectedItems());
                    t!==!1 && n.hide();
                }
            }, !1), $(n.mask[0]).on("tap click", function() {
                n.hide();
            }, !1), n._createPicker(), n.panel.addEventListener("touchstart", function(e) {
                e.preventDefault();
            }, !1), n.panel.addEventListener("touchmove", function(e) {
                e.preventDefault();
            }, !1);
        },
        _createPicker: function() {
            var t = this, i = t.options.layer || 1, n = 100 / i + "%";
            t.pickers = [];
            for (var r = 1; i >= r; r++) {
                var s = e.dom(a)[0];
                s.style.width = n, t.body.appendChild(s);
                var c = e(s).picker();
                t.pickers.push(c), s.addEventListener("change", function(e) {
                    var t = this.nextSibling;
                    if (t && t.picker) {
                        var i = e.detail || {}, a = i.item || {};
                        t.picker.setItems(a.children);
                    }
                }, !1);
            }
        },
        setData: function(e) {
            var t = this;
            e = e || [], t.pickers[0].setItems(e);
        },
        getSelectedItems: function() {
            var e = this, t = [];
            for (var i in e.pickers) {
                var a = e.pickers[i];
                t.push(a.getSelectedItem() || {});
            }
            return t;
        },
        show: function(i) {
            var a = this;
            a.callback = i, a.mask.show(), t.body.classList.add(e.className("poppicker-active-for-page")), a.panel.classList.add(e.className("active")), a.__back = e.back, e.back = function() {
                a.hide();
            };
        },
        hide: function() {
            var i = this;
            i.disposed || (i.panel.classList.remove(e.className("active")), i.mask.close(), t.body.classList.remove(e.className("poppicker-active-for-page")), e.back = i.__back);
        },
        dispose: function() {
            var e = this;
            e.hide(), setTimeout(function() {
                e.panel.parentNode.removeChild(e.panel);
                for (var t in e) {
                    e[t] = null, delete e[t];
                }
                e.disposed=!0;
            }, 300);
        }
    });
}(mui, document), function(e, t) {
    e.dom = function(i) {
        return "string" != typeof i ? i instanceof Array || i[0] && i.length ? [].slice.call(i) : [i] : (e.__create_dom_div__ || (e.__create_dom_div__ = t.createElement("div")), e.__create_dom_div__.innerHTML = i, [].slice.call(e.__create_dom_div__.childNodes));
    };
    var i = '<div class="mui-dtpicker" data-type="datetime">        <div class="mui-dtpicker-header">           <button data-id="btn-cancel" class="mui-btn">cancel</button>            <button data-id="btn-ok" class="mui-btn mui-btn-blue">true</button>       </div>      <div class="mui-dtpicker-title"><h5 data-id="title-y">&#24180;</h5><h5 data-id="title-m">&#26376;</h5><h5 data-id="title-d">&#26085;</h5><h5 data-id="title-h">&#26102;</h5><h5 data-id="title-i">&#20998;</h5></div>      <div class="mui-dtpicker-body">         <div data-id="picker-y" class="mui-picker">             <div class="mui-picker-inner">                  <div class="mui-pciker-rule mui-pciker-rule-ft"></div>                  <ul class="mui-pciker-list">                    </ul>                   <div class="mui-pciker-rule mui-pciker-rule-bg"></div>              </div>          </div>          <div data-id="picker-m" class="mui-picker">             <div class="mui-picker-inner">                  <div class="mui-pciker-rule mui-pciker-rule-ft"></div>                  <ul class="mui-pciker-list">                    </ul>                   <div class="mui-pciker-rule mui-pciker-rule-bg"></div>              </div>          </div>          <div data-id="picker-d" class="mui-picker">             <div class="mui-picker-inner">                  <div class="mui-pciker-rule mui-pciker-rule-ft"></div>                  <ul class="mui-pciker-list">                    </ul>                   <div class="mui-pciker-rule mui-pciker-rule-bg"></div>              </div>          </div>          <div data-id="picker-h" class="mui-picker">             <div class="mui-picker-inner">                  <div class="mui-pciker-rule mui-pciker-rule-ft"></div>                  <ul class="mui-pciker-list">                    </ul>                   <div class="mui-pciker-rule mui-pciker-rule-bg"></div>              </div>          </div>          <div data-id="picker-i" class="mui-picker">             <div class="mui-picker-inner">                  <div class="mui-pciker-rule mui-pciker-rule-ft"></div>                  <ul class="mui-pciker-list">                    </ul>                   <div class="mui-pciker-rule mui-pciker-rule-bg"></div>              </div>          </div>      </div>  </div>';
    e.DtPicker = e.Class.extend({
        init: function(a) {
            var n = this, r = e.dom(i)[0];
            t.body.appendChild(r), e('[data-id*="picker"]', r).picker();
            var s = n.ui = {
                picker: r,
                mask: e.createMask(),
                ok: e('[data-id="btn-ok"]', r)[0],
                cancel: e('[data-id="btn-cancel"]', r)[0],
                y: e('[data-id="picker-y"]', r)[0],
                m: e('[data-id="picker-m"]', r)[0],
                d: e('[data-id="picker-d"]', r)[0],
                h: e('[data-id="picker-h"]', r)[0],
                i: e('[data-id="picker-i"]', r)[0],
                labels: e('[data-id*="title-"]', r)
            };
            $(s.cancel).on("tap click", function() {
                n.hide();
            }, !1), $(s.ok).on("tap click", function() {
                var e = n.callback(n.getSelected());
                e!==!1 && n.hide();
            }, !1), s.y.addEventListener("change", function() {
                n._createDay();
            }, !1), s.m.addEventListener("change", function() {
                n._createDay();
            }, !1), $(s.mask[0]).on("tap click", function() {
                n.hide();
            }, !1), n._create(a), n.ui.picker.addEventListener("touchstart", function(e) {
                e.preventDefault();
            }, !1), n.ui.picker.addEventListener("touchmove", function(e) {
                e.preventDefault();
            }, !1);
        },
        getSelected: function() {
            var e = this, t = e.ui, i = e.options.type, a = {
                type: i,
                y: t.y.picker.getSelectedItem(),
                m: t.m.picker.getSelectedItem(),
                d: t.d.picker.getSelectedItem(),
                h: t.h.picker.getSelectedItem(),
                i: t.i.picker.getSelectedItem(),
                toString: function() {
                    return this.value;
                }
            };
            switch (i) {
            case"datetime":
                a.value = a.y.value + "-" + a.m.value + "-" + a.d.value + " " + a.h.value + ":" + a.i.value, a.text = a.y.text + "-" + a.m.text + "-" + a.d.text + " " + a.h.text + ":" + a.i.text;
                break;
            case"date":
                a.value = a.y.value + "-" + a.m.value + "-" + a.d.value, a.text = a.y.text + "-" + a.m.text + "-" + a.d.text;
                break;
            case"time":
                a.value = a.h.value + ":" + a.i.value, a.text = a.h.text + ":" + a.i.text;
                break;
            case"month":
                a.value = a.y.value + "-" + a.m.value, a.text = a.y.text + "-" + a.m.text;
                break;
            case"hour":
                a.value = a.y.value + "-" + a.m.value + "-" + a.d.value + " " + a.h.value, a.text = a.y.text + "-" + a.m.text + "-" + a.d.text + " " + a.h.text;
            }
            return a;
        },
        setSelectedValue: function(e) {
            var t = this, i = t.ui, a = t._parseValue(e);
            i.y.picker.setSelectedValue(a.y, 0), i.m.picker.setSelectedValue(a.m, 0), i.d.picker.setSelectedValue(a.d, 0), i.h.picker.setSelectedValue(a.h, 0), i.i.picker.setSelectedValue(a.i, 0);
        },
        isLeapYear: function(e) {
            return e%4 == 0 && e%100 != 0 || e%400 == 0;
        },
        _inArray: function(e, t) {
            for (var i in e) {
                var a = e[i];
                if (a === t) {
                    return !0;
                }
            }
            return !1;
        },
        getDayNum: function(e, t) {
            var i = this;
            return i._inArray([1, 3, 5, 7, 8, 10, 12], t) ? 31 : i._inArray([4, 6, 9, 11], t) ? 30 : i.isLeapYear(e) ? 29 : 28;
        },
        _fill: function(e) {
            return e = e.toString(), e.length < 2 && (e = 0 + e), e;
        },
        _createYear: function(e) {
            var t = this, i = t.options, a = t.ui, n = [];
            if (i.customData.y) {
                n = i.customData.y;
            } else {
                for (var r = i.beginYear, s = i.endYear, c = r; s >= c; c++) {
                    n.push({
                        text: c + "",
                        value: c
                    });
                }
            }
            a.y.picker.setItems(n);
        },
        _createMonth: function(e) {
            var t = this, i = t.options, a = t.ui, n = [];
            if (i.customData.m) {
                n = i.customData.m;
            } else {
                for (var r = 1; 12 >= r; r++) {
                    var s = t._fill(r);
                    n.push({
                        text: s,
                        value: s
                    });
                }
            }
            a.m.picker.setItems(n);
        },
        _createDay: function(e) {
            var t = this, i = t.options, a = t.ui, n = [];
            if (i.customData.d) {
                n = i.customData.d;
            } else {
                for (var r = t.getDayNum(parseInt(a.y.picker.getSelectedValue()), parseInt(a.m.picker.getSelectedValue())), s = 1; r >= s; s++) {
                    var c = t._fill(s);
                    n.push({
                        text: c,
                        value: c
                    });
                }
            }
            a.d.picker.setItems(n), e = e || a.d.picker.getSelectedValue();
        },
        _createHours: function(e) {
            var t = this, i = t.options, a = t.ui, n = [];
            if (i.customData.h) {
                n = i.customData.h;
            } else {
                for (var r = 0; 23 >= r; r++) {
                    var s = t._fill(r);
                    n.push({
                        text: s,
                        value: s
                    });
                }
            }
            a.h.picker.setItems(n);
        },
        _createMinutes: function(e) {
            var t = this, i = t.options, a = t.ui, n = [];
            if (i.customData.i) {
                n = i.customData.i;
            } else {
                for (var r = 0; 59 >= r; r++) {
                    var s = t._fill(r);
                    n.push({
                        text: s,
                        value: s
                    });
                }
            }
            a.i.picker.setItems(n);
        },
        _setLabels: function() {
            var e = this, t = e.options, i = e.ui;
            i.labels.each(function(e, i) {
                i.innerText = t.labels[e];
            });
        },
        _setButtons: function() {
            var e = this, t = e.options, i = e.ui;
            i.cancel.innerText = t.buttons[0], i.ok.innerText = t.buttons[1];
        },
        _parseValue: function(e) {
            var t = {};
            if (e) {
                var i = e.replace(":", "-").replace(" ", "-").split("-");
                t.y = i[0], t.m = i[1], t.d = i[2], t.h = i[3], t.i = i[4];
            } else {
                var a = new Date;
                t.y = a.getFullYear(), t.m = a.getMonth() + 1, t.d = a.getDate(), t.h = a.getHours(), t.i = a.getMinutes();
            }
            return t;
        },
        _create: function(e) {
            var t = this;
            e = e || {}, e.labels = e.labels || ["\u5e74", "\u6708", "\u65e5", "\u65f6", "\u5206"], e.buttons = e.buttons || ["\u53d6\u6d88", "\u786e\u5b9a"], e.type = e.type || "datetime", e.customData = e.customData || {}, t.options = e;
            var i = new Date;
            e.beginYear = e.beginYear || i.getFullYear() - 5, e.endYear = e.endYear || i.getFullYear() + 5;
            var a = t.ui;
            t._setLabels(), t._setButtons(), a.picker.setAttribute("data-type", e.type), t._createYear(), t._createMonth(), t._createDay(), t._createHours(), t._createMinutes(), t.setSelectedValue(e.value);
        },
        show: function(i) {
            var a = this, n = a.ui;
            a.callback = i || e.noop, n.mask.show(), t.body.classList.add(e.className("dtpicker-active-for-page")), n.picker.classList.add(e.className("active")), a.__back = e.back, e.back = function() {
                a.hide();
            };
        },
        hide: function() {
            var i = this;
            if (!i.disposed) {
                var a = i.ui;
                a.picker.classList.remove(e.className("active")), a.mask.close(), t.body.classList.remove(e.className("dtpicker-active-for-page")), e.back = i.__back;
            }
        },
        dispose: function() {
            var e = this;
            e.hide(), setTimeout(function() {
                e.ui.picker.parentNode.removeChild(e.ui.picker);
                for (var t in e) {
                    e[t] = null, delete e[t];
                }
                e.disposed=!0;
            }, 300);
        }
    });
}(mui, document);;
/*!
 * Cropper v0.4.0
 * https://github.com/fengyuanchen/cropperjs
 *
 * Copyright (c) 2015 Fengyuan Chen
 * Released under the MIT license
 *
 * Date: 2015-12-02T06:35:32.008Z
 */
!function(t, i) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = t.document ? i(t, !0) : function(t) {
        if (!t.document)
            throw new Error("Cropper requires a window with a document");
        return i(t)
    } : i(t)
}("undefined" != typeof window ? window : this, function(t, i) {
    "use strict";
    function e(t) {
        return Nt.call(t).slice(8, - 1).toLowerCase()
    }
    function a(t) {
        return "string" == typeof t
    }
    function s(t) {
        return "number" == typeof t&&!isNaN(t)
    }
    function h(t) {
        return "undefined" == typeof t
    }
    function n(t) {
        return "object" == typeof t && null !== t
    }
    function o(t) {
        var i, e;
        if (!n(t))
            return !1;
        try {
            return i = t.constructor, e = i.prototype, i && e && At.call(e, "isPrototypeOf")
        } catch (a) {
            return !1
        }
    }
    function r(t) {
        return "function" === e(t)
    }
    function p(t) {
        return Array.isArray ? Array.isArray(t) : "array" === e(t)
    }
    function l(t, i) {
        var e = [];
        return s(i) && e.push(i), e.slice.apply(t, e)
    }
    function c(t, i) {
        var e =- 1;
        return u(i, function(i, a) {
            return i === t ? (e = a, !1) : void 0
        }), e
    }
    function d(t) {
        return a(t) || (t = String(t)), t = t.trim ? t.trim() : t.replace(lt, "$1")
    }
    function u(t, i) {
        var e, a;
        if (t && r(i))
            if (p(t) || s(t.length))
                for (a = 0, e = t.length; e > a && i.call(t, t[a], a, t)!==!1; a++);
            else if (n(t))
                for (a in t)
                    if (At.call(t, a) && i.call(t, t[a], a, t)===!1)
                        break;
        return t
    }
    function g(t) {
        var i = l(arguments);
        return i.length > 1 && i.shift(), u(i, function(i) {
            u(i, function(i, e) {
                t[e] = i
            })
        }), t
    }
    function f(t, i) {
        var e = l(arguments, 2);
        return function() {
            return t.apply(i, e.concat(l(arguments)))
        }
    }
    function m(t) {
        return d(t).split(pt)
    }
    function v(t, i) {
        return t.className.indexOf(i)>-1
    }
    function w(t, i) {
        var e;
        return s(t.length) ? u(t, function(t) {
            w(t, i)
        }) : (e = m(t.className), u(m(i), function(t) {
            c(t, e) < 0 && e.push(t)
        }), void(t.className = e.join(" ")))
    }
    function x(t, i) {
        var e;
        return s(t.length) ? u(t, function(t) {
            x(t, i)
        }) : (e = m(t.className), u(m(i), function(t, i) {
            (i = c(t, e))>-1 && e.splice(i, 1)
        }), void(t.className = e.join(" ")))
    }
    function D(t, i, e) {
        return e ? w(t, i) : x(t, i)
    }
    function b(t, i) {
        return n(t[i]) ? t[i] : t.dataset ? t.dataset[i] : t.getAttribute("data-" + i)
    }
    function C(t, i, e) {
        n(e) && h(t[i]) ? t[i] = e : t.dataset ? t.dataset[i] = e : t.setAttribute("data-" + i, e)
    }
    function B(t, i) {
        n(t[i]) ? delete t[i] : t.dataset ? delete t.dataset[i] : t.removeAttribute("data-" + i)
    }
    function y(t, i, e) {
        var a;
        if (r(e))
            return a = d(i).split(pt), a.length > 1 ? u(a, function(i) {
                y(t, i, e)
            }) : void(t.addEventListener ? t.addEventListener(i, e, !1) : t.attachEvent && t.attachEvent("on" + i, e))
    }
    function L(t, i, e) {
        var a;
        if (r(e))
            return a = d(i).split(pt), a.length > 1 ? u(a, function(i) {
                L(t, i, e)
            }) : void(t.removeEventListener ? t.removeEventListener(i, e, !1) : t.detachEvent && t.detachEvent("on" + i, e))
    }
    function T(t) {
        t && (t.preventDefault ? t.preventDefault() : t.returnValue=!1)
    }
    function M(i) {
        var e, a = i || t.event;
        return a.target || (a.target = a.srcElement || U), s(a.pageX) || (e = U.documentElement, a.pageX = a.clientX + (t.scrollX || e && e.scrollLeft || 0) - (e && e.clientLeft || 0), a.pageY = a.clientY + (t.scrollY || e && e.scrollTop || 0) - (e && e.clientTop || 0)), a
    }
    function W(i) {
        var e = U.documentElement, a = i.getBoundingClientRect();
        return {
            left: a.left + (t.scrollX || e && e.scrollLeft || 0) - (e && e.clientLeft || 0),
            top: a.top + (t.scrollY || e && e.scrollTop || 0) - (e && e.clientTop || 0)
        }
    }
    function X(t, i) {
        return t.querySelector(i)
    }
    function Y(t, i) {
        return t.querySelectorAll(i)
    }
    function H(t, i) {
        t.parentNode.insertBefore(i, t)
    }
    function k(t, i) {
        t.appendChild(i)
    }
    function E(t) {
        t.parentNode.removeChild(t)
    }
    function R(t) {
        for (; t.firstChild;)
            t.removeChild(t.firstChild)
    }
    function z(t) {
        var i = t.match(/^(https?:)\/\/([^\:\/\?#]+):?(\d*)/i);
        return i && (i[1] !== j.protocol || i[2] !== j.hostname || i[3] !== j.port)
    }
    function O(t, i) {
        i && (t.crossOrigin = i)
    }
    function I(t) {
        var i = "timestamp=" + (new Date).getTime();
        return t + ( - 1 === t.indexOf("?") ? "?" : "&") + i
    }
    function N(t, i) {
        var e;
        return t.naturalWidth ? i(t.naturalWidth, t.naturalHeight) : (e = U.createElement("img"), e.onload = function() {
            i(this.width, this.height)
        }, void(e.src = t.src))
    }
    function A(t) {
        var i = [], e = t.rotate, a = t.scaleX, h = t.scaleY;
        return s(e) && i.push("rotate(" + e + "deg)"), s(a) && s(h) && i.push("scale(" + a + "," + h + ")"), i.length ? i.join(" ") : "none"
    }
    function S(t, i) {
        var e, a, s = Yt(t.degree)%180, h = (s > 90 ? 180 - s : s) * Math.PI / 180, n = Ht(h), o = kt(h), r = t.width, p = t.height, l = t.aspectRatio;
        return i ? (e = r / (o + n / l), a = e / l) : (e = r * o + p * n, a = r * n + p * o), {
            width: e,
            height: a
        }
    }
    function P(t, i) {
        var e, a, h, n = U.createElement("canvas"), o = n.getContext("2d"), r = 0, p = 0, l = i.naturalWidth, c = i.naturalHeight, d = i.rotate, u = i.scaleX, g = i.scaleY, f = s(u) && s(g) && (1 !== u || 1 !== g), m = s(d) && 0 !== d, v = m || f, w = l, x = c;
        return f && (e = l / 2, a = c / 2), m && (h = S({
            width: l,
            height: c,
            degree: d
        }), w = h.width, x = h.height, e = h.width / 2, a = h.height / 2), n.width = w, n.height = x, v && (r =- l / 2, p =- c / 2, o.save(), o.translate(e, a)), m && o.rotate(d * Math.PI / 180), f && o.scale(u, g), o.drawImage(t, zt(r), zt(p), zt(l), zt(c)), v && o.restore(), n
    }
    function _(t, i) {
        this.element = t, this.options = g({}, _.DEFAULTS, o(i) && i), this.isLoaded=!1, this.isBuilt=!1, this.isCompleted=!1, this.isRotated=!1, this.isCropped=!1, this.isDisabled=!1, this.isReplaced=!1, this.isLimited=!1, this.isImg=!1, this.originalUrl = "", this.crossOrigin = "", this.canvasData = null, this.cropBoxData = null, this.previews = null, this.init()
    }
    var U = t.document, j = t.location, q = "cropper", F = "cropper-modal", Z = "cropper-hide", $ = "cropper-hidden", K = "cropper-invisible", V = "cropper-move", G = "cropper-crop", J = "cropper-disabled", Q = "cropper-bg", tt = "mousedown touchstart pointerdown MSPointerDown", it = "mousemove touchmove pointermove MSPointerMove", et = "mouseup touchend touchcancel pointerup pointercancel MSPointerUp MSPointerCancel", at = "wheel mousewheel DOMMouseScroll", st = "dblclick", ht = "resize", nt = "error", ot = "load", rt = /^(e|w|s|n|se|sw|ne|nw|all|crop|move|zoom)$/, pt = /\s+/, lt = /^\s+(.*)\s+^/, ct = "preview", dt = "action", ut = "e", gt = "w", ft = "s", mt = "n", vt = "se", wt = "sw", xt = "ne", Dt = "nw", bt = "all", Ct = "crop", Bt = "move", yt = "zoom", Lt = "none", Tt=!!U.createElement("canvas").getContext, Mt = Number, Wt = Math.min, Xt = Math.max, Yt = Math.abs, Ht = Math.sin, kt = Math.cos, Et = Math.sqrt, Rt = Math.round, zt = Math.floor, Ot = {
        version: "0.4.0"
    }, It = {}, Nt = It.toString, At = It.hasOwnProperty;
    g(Ot, {
        init: function() {
            var t, i = this.element, e = i.tagName.toLowerCase();
            if (!b(i, q)) {
                if (C(i, q, this), "img" === e) {
                    if (this.isImg=!0, this.originalUrl = t = i.getAttribute("src"), !t)
                        return;
                    t = i.src
                } else 
                    "canvas" === e && Tt && (t = i.toDataURL());
                this.load(t)
            }
        },
        load: function(t) {
            var i, e, a, s, h, n = this.options, o = this.element;
            t && (this.url = t, r(n.build) && n.build.call(o)===!1 || (n.checkCrossOrigin && z(t) && (i = o.crossOrigin, i || (i = "anonymous", e = I(t))), this.crossOrigin = i, a = U.createElement("img"), O(a, i), a.src = e || t, this.image = a, this._start = s = f(this.start, this), this._stop = h = f(this.stop, this), this.isImg ? o.complete ? this.start() : y(o, ot, s) : (y(a, ot, s), y(a, nt, h), w(a, Z), H(o, a))))
        },
        start: function(t) {
            var i = this.isImg ? this.element: this.image;
            t && (L(i, ot, this._start), L(i, nt, this._stop)), N(i, f(function(t, i) {
                this.imageData = {
                    naturalWidth: t,
                    naturalHeight: i,
                    aspectRatio: t / i
                }, this.isLoaded=!0, this.build()
            }, this))
        },
        stop: function() {
            var t = this.image;
            L(t, ot, this._start), L(t, nt, this._stop), E(t), this.image = null
        }
    }), g(Ot, {
        build: function() {
            var t, i, e, a, s, h, n = this.options, o = this.element, p = this.image;
            this.isLoaded && (this.isBuilt && this.unbuild(), t = U.createElement("div"), t.innerHTML = _.TEMPLATE, this.container = o.parentNode, this.cropper = i = X(t, ".cropper-container"), this.canvas = e = X(i, ".cropper-canvas"), this.dragBox = a = X(i, ".cropper-drag-box"), this.cropBox = s = X(i, ".cropper-crop-box"), this.viewBox = X(i, ".cropper-view-box"), this.face = h = X(s, ".cropper-face"), k(e, p), w(o, $), H(o, i), this.isImg || x(p, Z), this.initPreview(), this.bind(), n.aspectRatio = Xt(0, n.aspectRatio) || NaN, n.viewMode = Xt(0, Wt(3, Rt(n.viewMode))) || 0, n.autoCrop ? (this.isCropped=!0, n.modal && w(a, F)) : w(s, $), n.guides || w(Y(s, ".cropper-dashed"), $), n.center || w(X(s, ".cropper-center"), $), n.background && w(i, Q), n.highlight || w(h, K), n.cropBoxMovable && (w(h, V), C(h, dt, bt)), n.cropBoxResizable || (w(Y(s, ".cropper-line"), $), w(Y(s, ".cropper-point"), $)), this.setDragMode(n.dragMode), this.render(), this.isBuilt=!0, this.setData(n.data), setTimeout(f(function() {
                r(n.built) && n.built.call(o), r(n.crop) && n.crop.call(o, this.getData()), this.isCompleted=!0
            }, this), 0))
        },
        unbuild: function() {
            this.isBuilt && (this.isBuilt=!1, this.initialImageData = null, this.initialCanvasData = null, this.initialCropBoxData = null, this.containerData = null, this.canvasData = null, this.cropBoxData = null, this.unbind(), this.resetPreview(), this.previews = null, this.viewBox = null, this.cropBox = null, this.dragBox = null, this.canvas = null, this.container = null, E(this.cropper), this.cropper = null)
        }
    }), g(Ot, {
        render: function() {
            this.initContainer(), this.initCanvas(), this.initCropBox(), this.renderCanvas(), this.isCropped && this.renderCropBox()
        },
        initContainer: function() {
            var t, i = this.options, e = this.element, a = this.container, s = this.cropper;
            w(s, $), x(e, $), this.containerData = t = {
                width: Xt(a.offsetWidth, Mt(i.minContainerWidth) || 200),
                height: Xt(a.offsetHeight, Mt(i.minContainerHeight) || 100)
            }, s.style.cssText = "width:" + t.width + "px;height:" + t.height + "px;", w(e, $), x(s, $)
        },
        initCanvas: function() {
            var t = this.options.viewMode, i = this.containerData, e = i.width, a = i.height, s = this.imageData, h = s.aspectRatio, n = {
                naturalWidth: s.naturalWidth,
                naturalHeight: s.naturalHeight,
                aspectRatio: h,
                width: e,
                height: a
            };
            a * h > e ? 3 === t ? n.width = a * h : n.height = e / h : 3 === t ? n.height = e / h : n.width = a * h, n.oldLeft = n.left = (e - n.width) / 2, n.oldTop = n.top = (a - n.height) / 2, this.canvasData = n, this.isLimited = 1 === t || 2 === t, this.limitCanvas(!0, !0), this.initialImageData = g({}, s), this.initialCanvasData = g({}, n)
        },
        limitCanvas: function(t, i) {
            var e, a, s, h, n = this.options, o = n.viewMode, r = this.containerData, p = r.width, l = r.height, c = this.canvasData, d = c.aspectRatio, u = this.cropBoxData, g = this.isCropped && u;
            t && (e = Mt(n.minCanvasWidth) || 0, a = Mt(n.minCanvasHeight) || 0, o && (o > 1 ? (e = Xt(e, p), a = Xt(a, l), 3 === o && (a * d > e ? e = a * d : a = e / d)) : e ? e = Xt(e, g ? u.width : 0) : a ? a = Xt(a, g ? u.height : 0) : g && (e = u.width, a = u.height, a * d > e ? e = a * d : a = e / d)), e && a ? a * d > e ? a = e / d : e = a * d : e ? a = e / d : a && (e = a * d), c.minWidth = e, c.minHeight = a, c.maxWidth = 1 / 0, c.maxHeight = 1 / 0), i && (o ? (s = p - c.width, h = l - c.height, c.minLeft = Wt(0, s), c.minTop = Wt(0, h), c.maxLeft = Xt(0, s), c.maxTop = Xt(0, h), g && this.isLimited && (c.minLeft = Wt(u.left, u.left + u.width - c.width), c.minTop = Wt(u.top, u.top + u.height - c.height), c.maxLeft = u.left, c.maxTop = u.top, 2 === o && (c.width >= p && (c.minLeft = Wt(0, s), c.maxLeft = Xt(0, s)), c.height >= l && (c.minTop = Wt(0, h), c.maxTop = Xt(0, h))))) : (c.minLeft =- c.width, c.minTop =- c.height, c.maxLeft = p, c.maxTop = l))
        },
        renderCanvas: function(t) {
            var i, e, a = this.canvasData, s = this.imageData, h = s.rotate, n = s.naturalWidth, o = s.naturalHeight;
            this.isRotated && (this.isRotated=!1, e = S({
                width: s.width,
                height: s.height,
                degree: h
            }), i = e.width / e.height, i !== a.aspectRatio && (a.left -= (e.width - a.width) / 2, a.top -= (e.height - a.height) / 2, a.width = e.width, a.height = e.height, a.aspectRatio = i, a.naturalWidth = n, a.naturalHeight = o, h%180 && (e = S({
                width: n,
                height: o,
                degree: h
            }), a.naturalWidth = e.width, a.naturalHeight = e.height), this.limitCanvas(!0, !1))), (a.width > a.maxWidth || a.width < a.minWidth) && (a.left = a.oldLeft), (a.height > a.maxHeight || a.height < a.minHeight) && (a.top = a.oldTop), a.width = Wt(Xt(a.width, a.minWidth), a.maxWidth), a.height = Wt(Xt(a.height, a.minHeight), a.maxHeight), this.limitCanvas(!1, !0), a.oldLeft = a.left = Wt(Xt(a.left, a.minLeft), a.maxLeft), a.oldTop = a.top = Wt(Xt(a.top, a.minTop), a.maxTop), this.canvas.style.cssText = "width:" + a.width + "px;height:" + a.height + "px;left:" + a.left + "px;top:" + a.top + "px;", this.renderImage(), this.isCropped && this.isLimited && this.limitCropBox(!0, !0), t && this.output()
        },
        renderImage: function(t) {
            var i, e, a = this.canvasData, s = this.imageData;
            s.rotate && (i = S({
                width: a.width,
                height: a.height,
                degree: s.rotate,
                aspectRatio: s.aspectRatio
            }, !0)), g(s, i ? {
                width: i.width,
                height: i.height,
                left: (a.width - i.width) / 2,
                top: (a.height - i.height) / 2
            } : {
                width: a.width,
                height: a.height,
                left: 0,
                top: 0
            }), e = A(s), this.image.style.cssText = "width:" + s.width + "px;height:" + s.height + "px;margin-left:" + s.left + "px;margin-top:" + s.top + "px;-webkit-transform:" + e + ";-ms-transform:" + e + ";transform:" + e + ";", t && this.output()
        },
        initCropBox: function() {
            var t = this.options, i = t.aspectRatio, e = Mt(t.autoCropArea) || .8, a = this.canvasData, s = {
                width: a.width,
                height: a.height
            };
            i && (a.height * i > a.width ? s.height = s.width / i : s.width = s.height * i), this.cropBoxData = s, this.limitCropBox(!0, !0), s.width = Wt(Xt(s.width, s.minWidth), s.maxWidth), s.height = Wt(Xt(s.height, s.minHeight), s.maxHeight), s.width = Xt(s.minWidth, s.width * e), s.height = Xt(s.minHeight, s.height * e), s.oldLeft = s.left = a.left + (a.width - s.width) / 2, s.oldTop = s.top = a.top + (a.height - s.height) / 2, this.initialCropBoxData = g({}, s)
        },
        limitCropBox: function(t, i) {
            var e, a, s, h, n = this.options, o = n.aspectRatio, r = this.containerData, p = r.width, l = r.height, c = this.canvasData, d = this.cropBoxData, u = this.isLimited;
            t && (e = Mt(n.minCropBoxWidth) || 0, a = Mt(n.minCropBoxHeight) || 0, e = Wt(e, p), a = Wt(a, l), s = Wt(p, u ? c.width : p), h = Wt(l, u ? c.height : l), o && (e && a ? a * o > e ? a = e / o : e = a * o : e ? a = e / o : a && (e = a * o), h * o > s ? h = s / o : s = h * o), d.minWidth = Wt(e, s), d.minHeight = Wt(a, h), d.maxWidth = s, d.maxHeight = h), i && (u ? (d.minLeft = Xt(0, c.left), d.minTop = Xt(0, c.top), d.maxLeft = Wt(p, c.left + c.width) - d.width, d.maxTop = Wt(l, c.top + c.height) - d.height) : (d.minLeft = 0, d.minTop = 0, d.maxLeft = p - d.width, d.maxTop = l - d.height))
        },
        renderCropBox: function() {
            var t = this.options, i = this.containerData, e = i.width, a = i.height, s = this.cropBoxData;
            (s.width > s.maxWidth || s.width < s.minWidth) && (s.left = s.oldLeft), (s.height > s.maxHeight || s.height < s.minHeight) && (s.top = s.oldTop), s.width = Wt(Xt(s.width, s.minWidth), s.maxWidth), s.height = Wt(Xt(s.height, s.minHeight), s.maxHeight), this.limitCropBox(!1, !0), s.oldLeft = s.left = Wt(Xt(s.left, s.minLeft), s.maxLeft), s.oldTop = s.top = Wt(Xt(s.top, s.minTop), s.maxTop), t.movable && t.cropBoxDataMovable && C(this.face, dt, s.width === e && s.height === a ? Bt : bt), this.cropBox.style.cssText = "width:" + s.width + "px;height:" + s.height + "px;left:" + s.left + "px;top:" + s.top + "px;", this.isCropped && this.isLimited && this.limitCanvas(!0, !0), this.isDisabled || this.output()
        },
        output: function() {
            var t = this.options;
            this.preview(), this.isCompleted && r(t.crop) && t.crop.call(this.element, this.getData())
        }
    }), g(Ot, {
        initPreview: function() {
            var t, i = this.options.preview, e = U.createElement("img"), a = this.crossOrigin, s = this.url;
            O(e, a), e.src = s, k(this.viewBox, e), i && (this.previews = t = Y(U, i), u(t, function(t) {
                var i = U.createElement("img");
                C(t, ct, {
                    width: t.offsetWidth,
                    height: t.offsetHeight,
                    html: t.innerHTML
                }), O(i, a), i.src = s, i.style.cssText = 'display:block;width:100%;height:auto;min-width:0!important;min-height:0!important;max-width:none!important;max-height:none!important;image-orientation:0deg!important;"', R(t), k(t, i)
            }))
        },
        resetPreview: function() {
            u(this.previews, function(t) {
                var i = b(t, ct);
                t.style.width = i.width + "px", t.style.height = i.height + "px", t.innerHTML = i.html, B(t, ct)
            })
        },
        preview: function() {
            var t = this.imageData, i = this.canvasData, e = this.cropBoxData, a = e.width, s = e.height, h = t.width, n = t.height, o = e.left - i.left - t.left, r = e.top - i.top - t.top, p = A(t);
            this.isCropped&&!this.isDisabled && (X(this.viewBox, "img").style.cssText = "width:" + h + "px;height:" + n + "px;margin-left:" +- o + "px;margin-top:" +- r + "px;-webkit-transform:" + p + ";-ms-transform:" + p + ";transform:" + p + ";", u(this.previews, function(t) {
                var i = X(t, "img").style, e = b(t, ct), l = e.width, c = e.height, d = l, u = c, g = 1;
                a && (g = l / a, u = s * g), s && u > c && (g = c / s, d = a * g, u = c), t.style.width = d + "px", t.style.height = u + "px", i.width = h * g + "px", i.height = n * g + "px", i.marginLeft =- o * g + "px", i.marginTop =- r * g + "px", i.WebkitTransform = p, i.msTransform = p, i.transform = p
            }))
        }
    }), g(Ot, {
        bind: function() {
            var i = this.options, e = this.cropper;
            y(e, tt, f(this.cropStart, this)), i.zoomable && i.zoomOnWheel && y(e, at, f(this.wheel, this)), i.toggleDragModeOnDblclick && y(e, st, f(this.dblclick, this)), y(U, it, this._cropMove = f(this.cropMove, this)), y(U, et, this._cropEnd = f(this.cropEnd, this)), i.responsive && y(t, ht, this._resize = f(this.resize, this))
        },
        unbind: function() {
            var i = this.options, e = this.cropper;
            L(e, tt, this.cropStart), i.zoomable && i.zoomOnWheel && L(e, at, this.wheel), i.toggleDragModeOnDblclick && L(e, st, this.dblclick), L(U, it, this._cropMove), L(U, et, this._cropEnd), i.responsive && L(t, ht, this._resize)
        }
    }), g(Ot, {
        resize: function() {
            var t, i, e, a = this.options.restore, s = this.container, h = this.containerData;
            !this.isDisabled && h && (e = s.offsetWidth / h.width, (1 !== e || s.offsetHeight !== h.height) && (a && (t = this.getCanvasData(), i = this.getCropBoxData()), this.render(), a && (this.setCanvasData(u(t, function(i, a) {
                t[a] = i * e
            })), this.setCropBoxData(u(i, function(t, a) {
                i[a] = t * e
            })))))
        },
        dblclick: function() {
            this.isDisabled || this.setDragMode(v(this.dragBox, G) ? Bt : Ct)
        },
        wheel: function(t) {
            var i = M(t), e = Mt(this.options.wheelZoomRatio) || .1, a = 1;
            this.isDisabled || (T(i), i.deltaY ? a = i.deltaY > 0 ? 1 : - 1 : i.wheelDelta ? a =- i.wheelDelta / 120 : i.detail && (a = i.detail > 0 ? 1 : - 1), this.zoom( - a * e, i))
        },
        cropStart: function(t) {
            var i, e, a, s = this.options, h = M(t), n = h.touches;
            if (!this.isDisabled) {
                if (n) {
                    if (i = n.length, i > 1) {
                        if (!s.zoomable ||!s.zoomOnTouch || 2 !== i)
                            return;
                        e = n[1], this.startX2 = e.pageX, this.startY2 = e.pageY, a = yt
                    }
                    e = n[0]
                }
                if (a = a || b(h.target, dt), rt.test(a)) {
                    if (r(s.cropstart) && s.cropstart.call(this.element, {
                        originalEvent: h,
                        action: a
                    })===!1)
                        return;
                    T(h), this.action = a, this.cropping=!1, this.startX = e ? e.pageX : h.pageX, this.startY = e ? e.pageY : h.pageY, a === Ct && (this.cropping=!0, w(this.dragBox, F))
                }
            }
        },
        cropMove: function(t) {
            var i, e, a = this.options, s = M(t), h = s.touches, n = this.action;
            if (!this.isDisabled) {
                if (h) {
                    if (i = h.length, i > 1) {
                        if (!a.zoomable ||!a.zoomOnTouch || 2 !== i)
                            return;
                        e = h[1], this.endX2 = e.pageX, this.endY2 = e.pageY
                    }
                    e = h[0]
                }
                if (n) {
                    if (r(a.cropmove) && a.cropmove.call(this.element, {
                        originalEvent: s,
                        action: n
                    })===!1)
                        return;
                    T(s), this.endX = e ? e.pageX : s.pageX, this.endY = e ? e.pageY : s.pageY, this.change(s.shiftKey, n === yt ? s : null)
                }
            }
        },
        cropEnd: function(t) {
            var i = this.options, e = M(t), a = this.action;
            this.isDisabled || a && (T(e), this.cropping && (this.cropping=!1, D(this.dragBox, F, this.isCropped && i.modal)), this.action = "", r(i.cropend) && i.cropend.call(this.element, {
                originalEvent: e,
                action: a
            }))
        }
    }), g(Ot, {
        change: function(t, i) {
            var e, a, s = this.options, h = s.aspectRatio, n = this.action, o = this.containerData, r = this.canvasData, p = this.cropBoxData, l = p.width, c = p.height, d = p.left, u = p.top, g = d + l, f = u + c, m = 0, v = 0, w = o.width, D = o.height, b=!0;
            switch (!h && t && (h = l && c ? l / c : 1), this.isLimited && (m = p.minLeft, v = p.minTop, w = m + Wt(o.width, r.width), D = v + Wt(o.height, r.height)), a = {
                x: this.endX - this.startX,
                y: this.endY - this.startY
            }, h && (a.X = a.y * h, a.Y = a.x / h), n) {
            case bt:
                d += a.x, u += a.y;
                break;
            case ut:
                if (a.x >= 0 && (g >= w || h && (v >= u || f >= D))) {
                    b=!1;
                    break
                }
                l += a.x, h && (c = l / h, u -= a.Y / 2), 0 > l && (n = gt, l = 0);
                break;
            case mt:
                if (a.y <= 0 && (v >= u || h && (m >= d || g >= w))) {
                    b=!1;
                    break
                }
                c -= a.y, u += a.y, h && (l = c * h, d += a.X / 2), 0 > c && (n = ft, c = 0);
                break;
            case gt:
                if (a.x <= 0 && (m >= d || h && (v >= u || f >= D))) {
                    b=!1;
                    break
                }
                l -= a.x, d += a.x, h && (c = l / h, u += a.Y / 2), 0 > l && (n = ut, l = 0);
                break;
            case ft:
                if (a.y >= 0 && (f >= D || h && (m >= d || g >= w))) {
                    b=!1;
                    break
                }
                c += a.y, h && (l = c * h, d -= a.X / 2), 0 > c && (n = mt, c = 0);
                break;
            case xt:
                if (h) {
                    if (a.y <= 0 && (v >= u || g >= w)) {
                        b=!1;
                        break
                    }
                    c -= a.y, u += a.y, l = c * h
                } else 
                    a.x >= 0 ? w > g ? l += a.x : a.y <= 0 && v >= u && (b=!1) : l += a.x, a.y <= 0 ? u > v && (c -= a.y, u += a.y) : (c -= a.y, u += a.y);
                0 > l && 0 > c ? (n = wt, c = 0, l = 0) : 0 > l ? (n = Dt, l = 0) : 0 > c && (n = vt, c = 0);
                break;
            case Dt:
                if (h) {
                    if (a.y <= 0 && (v >= u || m >= d)) {
                        b=!1;
                        break
                    }
                    c -= a.y, u += a.y, l = c * h, d += a.X
                } else 
                    a.x <= 0 ? d > m ? (l -= a.x, d += a.x) : a.y <= 0 && v >= u && (b=!1) : (l -= a.x, d += a.x), a.y <= 0 ? u > v && (c -= a.y, u += a.y) : (c -= a.y, u += a.y);
                0 > l && 0 > c ? (n = vt, c = 0, l = 0) : 0 > l ? (n = xt, l = 0) : 0 > c && (n = wt, c = 0);
                break;
            case wt:
                if (h) {
                    if (a.x <= 0 && (m >= d || f >= D)) {
                        b=!1;
                        break
                    }
                    l -= a.x, d += a.x, c = l / h
                } else 
                    a.x <= 0 ? d > m ? (l -= a.x, d += a.x) : a.y >= 0 && f >= D && (b=!1) : (l -= a.x, d += a.x), a.y >= 0 ? D > f && (c += a.y) : c += a.y;
                0 > l && 0 > c ? (n = xt, c = 0, l = 0) : 0 > l ? (n = vt, l = 0) : 0 > c && (n = Dt, c = 0);
                break;
            case vt:
                if (h) {
                    if (a.x >= 0 && (g >= w || f >= D)) {
                        b=!1;
                        break
                    }
                    l += a.x, c = l / h
                } else 
                    a.x >= 0 ? w > g ? l += a.x : a.y >= 0 && f >= D && (b=!1) : l += a.x, a.y >= 0 ? D > f && (c += a.y) : c += a.y;
                0 > l && 0 > c ? (n = Dt, c = 0, l = 0) : 0 > l ? (n = wt, l = 0) : 0 > c && (n = xt, c = 0);
                break;
            case Bt:
                this.move(a.x, a.y), b=!1;
                break;
            case yt:
                this.zoom(function(t, i, e, a) {
                    var s = Et(t * t + i * i), h = Et(e * e + a * a);
                    return (h - s) / s
                }(Yt(this.startX - this.startX2), Yt(this.startY - this.startY2), Yt(this.endX - this.endX2), Yt(this.endY - this.endY2)), i), this.startX2 = this.endX2, this.startY2 = this.endY2, b=!1;
                break;
            case Ct:
                if (!a.x ||!a.y) {
                    b=!1;
                    break
                }
                e = W(this.cropper), d = this.startX - e.left, u = this.startY - e.top, l = p.minWidth, c = p.minHeight, a.x > 0 ? n = a.y > 0 ? vt : xt : a.x < 0 && (d -= l, n = a.y > 0 ? wt : Dt), a.y < 0 && (u -= c), this.isCropped || (x(this.cropBox, $), this.isCropped=!0, this.isLimited && this.limitCropBox(!0, !0))
            }
            b && (p.width = l, p.height = c, p.left = d, p.top = u, this.action = n, this.renderCropBox()), this.startX = this.endX, this.startY = this.endY
        }
    }), g(Ot, {
        crop: function() {
            return this.isBuilt&&!this.isDisabled && (this.isCropped || (this.isCropped=!0, this.limitCropBox(!0, !0), this.options.modal && w(this.dragBox, F), x(this.cropBox, $)), this.setCropBoxData(this.initialCropBoxData)), this
        },
        reset: function() {
            return this.isBuilt&&!this.isDisabled && (this.imageData = g({}, this.initialImageData), this.canvasData = g({}, this.initialCanvasData), this.cropBoxData = g({}, this.initialCropBoxData), this.renderCanvas(), this.isCropped && this.renderCropBox()), this
        },
        clear: function() {
            return this.isCropped&&!this.isDisabled && (g(this.cropBoxData, {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }), this.isCropped=!1, this.renderCropBox(), this.limitCanvas(), this.renderCanvas(), x(this.dragBox, F), w(this.cropBox, $)), this
        },
        replace: function(t) {
            return !this.isDisabled && t && (this.isImg && (this.isReplaced=!0, this.element.src = t), this.options.data = null, this.load(t)), this
        },
        enable: function() {
            return this.isBuilt && (this.isDisabled=!1, x(this.cropper, J)), this
        },
        disable: function() {
            return this.isBuilt && (this.isDisabled=!0, w(this.cropper, J)), this
        },
        destroy: function() {
            var t = this.element, i = this.image;
            return this.isLoaded ? (this.isImg && this.isReplaced && (t.src = this.originalUrl), this.unbuild(), x(t, $)) : this.isImg ? t.off(ot, this.start) : i && E(i), B(t, q), this
        },
        move: function(t, i) {
            var e = this.canvasData;
            return this.moveTo(h(t) ? t : e.left + Mt(t), h(i) ? i : e.top + Mt(i))
        },
        moveTo: function(t, i) {
            var e = this.canvasData, a=!1;
            return h(i) && (i = t), t = Mt(t), i = Mt(i), this.isBuilt&&!this.isDisabled && this.options.movable && (s(t) && (e.left = t, a=!0), s(i) && (e.top = i, a=!0), a && this.renderCanvas(!0)), this
        },
        zoom: function(t, i) {
            var e = this.canvasData;
            return t = Mt(t), t = 0 > t ? 1 / (1 - t) : 1 + t, this.zoomTo(e.width * t / e.naturalWidth, i)
        },
        zoomTo: function(t, i) {
            var e, a, s = this.options, h = this.canvasData, n = h.width, o = h.height, p = h.naturalWidth, l = h.naturalHeight;
            if (t = Mt(t), t >= 0 && this.isBuilt&&!this.isDisabled && s.zoomable) {
                if (e = p * t, a = l * t, r(s.zoom) && s.zoom.call(this.element, {
                    originalEvent: i,
                    oldRatio: n / p,
                    ratio: e / p
                })===!1)
                    return this;
                h.left -= (e - n) / 2, h.top -= (a - o) / 2, h.width = e, h.height = a, this.renderCanvas(!0)
            }
            return this
        },
        rotate: function(t) {
            return this.rotateTo((this.imageData.rotate || 0) + Mt(t))
        },
        rotateTo: function(t) {
            return t = Mt(t), s(t) && this.isBuilt&&!this.isDisabled && this.options.rotatable && (this.imageData.rotate = t%360, this.isRotated=!0, this.renderCanvas(!0)), this
        },
        scale: function(t, i) {
            var e = this.imageData, a=!1;
            return h(i) && (i = t), t = Mt(t), i = Mt(i), this.isBuilt&&!this.isDisabled && this.options.scalable && (s(t) && (e.scaleX = t, a=!0), s(i) && (e.scaleY = i, a=!0), a && this.renderImage(!0)), this
        },
        scaleX: function(t) {
            var i = this.imageData.scaleY;
            return this.scale(t, s(i) ? i : 1)
        },
        scaleY: function(t) {
            var i = this.imageData.scaleX;
            return this.scale(s(i) ? i : 1, t)
        },
        getData: function(t) {
            var i, e, a = this.options, s = this.imageData, h = this.canvasData, n = this.cropBoxData;
            return this.isBuilt && this.isCropped ? (e = {
                x: n.left - h.left,
                y: n.top - h.top,
                width: n.width,
                height: n.height
            }, i = s.width / s.naturalWidth, u(e, function(a, s) {
                a/=i, e[s] = t ? Rt(a) : a
            })) : e = {
                x: 0,
                y: 0,
                width: 0,
                height: 0
            }, a.rotatable && (e.rotate = s.rotate || 0), a.scalable && (e.scaleX = s.scaleX || 1, e.scaleY = s.scaleY || 1), e
        },
        setData: function(t) {
            var i, e, a, h = this.options, n = this.imageData, p = this.canvasData, l = {};
            return r(t) && (t = t.call(this.element)), this.isBuilt&&!this.isDisabled && o(t) && (h.rotatable && s(t.rotate) && t.rotate !== n.rotate && (n.rotate = t.rotate, this.isRotated = i=!0), h.scalable && (s(t.scaleX) && t.scaleX !== n.scaleX && (n.scaleX = t.scaleX, e=!0), s(t.scaleY) && t.scaleY !== n.scaleY && (n.scaleY = t.scaleY, e=!0)), i ? this.renderCanvas() : e && this.renderImage(), a = n.width / n.naturalWidth, s(t.x) && (l.left = t.x * a + p.left), s(t.y) && (l.top = t.y * a + p.top), s(t.width) && (l.width = t.width * a), s(t.height) && (l.height = t.height * a), this.setCropBoxData(l)), this
        },
        getContainerData: function() {
            return this.isBuilt ? this.containerData : {}
        },
        getImageData: function() {
            return this.isLoaded ? this.imageData : {}
        },
        getCanvasData: function() {
            var t = this.canvasData, i = {};
            return this.isBuilt && u(["left", "top", "width", "height", "naturalWidth", "naturalHeight"], function(e) {
                i[e] = t[e]
            }), i
        },
        setCanvasData: function(t) {
            var i = this.canvasData, e = i.aspectRatio;
            return r(t) && (t = t.call(this.element)), this.isBuilt&&!this.isDisabled && o(t) && (s(t.left) && (i.left = t.left), s(t.top) && (i.top = t.top), s(t.width) ? (i.width = t.width, i.height = t.width / e) : s(t.height) && (i.height = t.height, i.width = t.height * e), this.renderCanvas(!0)), this
        },
        getCropBoxData: function() {
            var t, i = this.cropBoxData;
            return this.isBuilt && this.isCropped && (t = {
                left: i.left,
                top: i.top,
                width: i.width,
                height: i.height
            }), t || {}
        },
        setCropBoxData: function(t) {
            var i, e, a = this.cropBoxData, h = this.options.aspectRatio;
            return r(t) && (t = t.call(this.element)), this.isBuilt && this.isCropped&&!this.isDisabled && o(t) && (s(t.left) && (a.left = t.left), s(t.top) && (a.top = t.top), s(t.width) && t.width !== a.width && (i=!0, a.width = t.width), s(t.height) && t.height !== a.height && (e=!0, a.height = t.height), h && (i ? a.height = a.width / h : e && (a.width = a.height * h)), this.renderCropBox()), this
        },
        getCroppedCanvas: function(t) {
            var i, e, a, s, h, n, r, p, l, c, d;
            return this.isBuilt && this.isCropped && Tt ? (o(t) || (t = {}), d = this.getData(), i = d.width, e = d.height, p = i / e, o(t) && (h = t.width, n = t.height, h ? (n = h / p, r = h / i) : n && (h = n * p, r = n / e)), a = Rt(h || i), s = Rt(n || e), l = U.createElement("canvas"), l.width = a, l.height = s, c = l.getContext("2d"), t.fillColor && (c.fillStyle = t.fillColor, c.fillRect(0, 0, a, s)), c.drawImage.apply(c, function() {
                var t, a, s, h, n, o, p = P(this.image, this.imageData), l = p.width, c = p.height, u = [p], g = d.x, f = d.y;
                return - i >= g || g > l ? g = t = s = n = 0 : 0 >= g ? (s =- g, g = 0, t = n = Wt(l, i + g)) : l >= g && (s = 0, t = n = Wt(i, l - g)), 0 >= t||-e >= f || f > c ? f = a = h = o = 0 : 0 >= f ? (h =- f, f = 0, a = o = Wt(c, e + f)) : c >= f && (h = 0, a = o = Wt(e, c - f)), u.push(zt(g), zt(f), zt(t), zt(a)), r && (s*=r, h*=r, n*=r, o*=r), n > 0 && o > 0 && u.push(zt(s), zt(h), zt(n), zt(o)), u
            }.call(this)), l) : void 0
        },
        setAspectRatio: function(t) {
            var i = this.options;
            return this.isDisabled || h(t) || (i.aspectRatio = Xt(0, t) || NaN, this.isBuilt && (this.initCropBox(), this.isCropped && this.renderCropBox())), this
        },
        setDragMode: function(t) {
            var i, e, a = this.options, s = this.dragBox, h = this.face;
            return this.isLoaded&&!this.isDisabled && (i = t === Ct, e = a.movable && t === Bt, t = i || e ? t : Lt, C(s, dt, t), D(s, G, i), D(s, V, e), a.cropBoxMovable || (C(h, dt, t), D(h, G, i), D(h, V, e))), this
        }
    }), g(_.prototype, Ot), _.DEFAULTS = {
        viewMode: 0,
        dragMode: "crop",
        aspectRatio: NaN,
        data: null,
        preview: "",
        responsive: !0,
        restore: !0,
        checkCrossOrigin: !0,
        modal: !0,
        guides: !0,
        center: !0,
        highlight: !0,
        background: !0,
        autoCrop: !0,
        autoCropArea: .8,
        movable: !0,
        rotatable: !0,
        scalable: !0,
        zoomable: !0,
        zoomOnTouch: !0,
        zoomOnWheel: !0,
        wheelZoomRatio: .1,
        cropBoxMovable: !0,
        cropBoxResizable: !0,
        toggleDragModeOnDblclick: !0,
        minCanvasWidth: 0,
        minCanvasHeight: 0,
        minCropBoxWidth: 0,
        minCropBoxHeight: 0,
        minContainerWidth: 200,
        minContainerHeight: 100,
        build: null,
        built: null,
        cropstart: null,
        cropmove: null,
        cropend: null,
        crop: null,
        zoom: null
    }, _.TEMPLATE = '<div class="cropper-container"><div class="cropper-wrap-box"><div class="cropper-canvas"></div></div><div class="cropper-drag-box"></div><div class="cropper-crop-box"><span class="cropper-view-box"></span><span class="cropper-dashed dashed-h"></span><span class="cropper-dashed dashed-v"></span><span class="cropper-center"></span><span class="cropper-face"></span><span class="cropper-line line-e" data-action="e"></span><span class="cropper-line line-n" data-action="n"></span><span class="cropper-line line-w" data-action="w"></span><span class="cropper-line line-s" data-action="s"></span><span class="cropper-point point-e" data-action="e"></span><span class="cropper-point point-n" data-action="n"></span><span class="cropper-point point-w" data-action="w"></span><span class="cropper-point point-s" data-action="s"></span><span class="cropper-point point-ne" data-action="ne"></span><span class="cropper-point point-nw" data-action="nw"></span><span class="cropper-point point-sw" data-action="sw"></span><span class="cropper-point point-se" data-action="se"></span></div></div>';
    var St = t.Cropper;
    return _.noConflict = function() {
        return t.Cropper = St, _
    }, _.setDefaults = function(t) {
        g(_.DEFAULTS, t)
    }, "function" == typeof define && define.amd && define("cropper", [], function() {
        return _
    }), "undefined" == typeof i && (t.Cropper = _), _
});;

initEvents.push(function() {
    $('.crop-row').on('click', function() {
        $("#img-dialog img").attr('src', $(this).attr('src'));
        mui("#img-dialog").popover("show");
    });



    (function($) {
        var serverCompress = 0;
        function isCanvasSupported() {
            var elem = document.createElement('canvas');
            return !!(elem.getContext && elem.getContext('2d'));
        }
        function compress(file, callback) {
            var reader = new FileReader();
            reader.onload = function(e) {
                var image = $('<img/>');
                image.on('load', function() {
                    var square = 800;
                    var canvas = document.createElement('canvas');
                    var context = canvas.getContext('2d');
                    var imageWidth;
                    var imageHeight;
                    imageWidth = this.width;
                    imageHeight = this.height;
                    if (this.width > this.height) {
                        square = Math.min(square, this.height);
                        imageWidth = Math.round(square * this.width / this.height);
                        imageHeight = square;
                    } else {
                        square = Math.min(square, this.width);
                        imageHeight = Math.round(square * this.height / this.width);
                        imageWidth = square;
                    }
                    canvas.width = imageWidth;
                    canvas.height = imageHeight;
                    context.clearRect(0, 0, canvas.width, canvas.height);
                    context.drawImage(this, 0, 0, imageWidth, imageHeight);
                    var data = canvas.toDataURL('image/jpeg');
                    if (!serverCompress) {
                        callback(data);
                    } else {
                        window.API.post('pic_compress', {
                            upload: data
                        }, function(data) {
                            if (data.error == 0) {
                                callback(data.data);
                            } else {
                                showMessage('&#21387;&#32553;&#22833;&#36133;&#65292;&#35831;&#37325;&#35797;');
                            }
                        });
                    }
                });
                image.attr('src', e.target.result);
            };
            reader.readAsDataURL(file);
        }
        $('#crop-cancel-btn').off('click').on('click', function() {
            mui("#crop-dialog").popover("hide");
        });
        $('#crop-submit-btn').off('click').on('click', function() {
            var url = $(this).data('url');
            var imgWidth = $(this).data('width');
            var imgHeight = $(this).data('height');
            var callback = $(this).data('callback');
            var field = $(this).data('field');
            var id = $(this).data('id');
            var options = {};
            if (parseInt(imgWidth, 10) > 0) {
                options.width = imgWidth;
            }
            if (parseInt(imgHeight, 10) > 0) {
                options.height = imgHeight;
            }
            var imgData = window.cropObject.getCroppedCanvas(options).toDataURL('image/jpeg');
            var progressbar = $('.upload-progress');
            var upfield = $(this).data('upload');
            var xhr = new XMLHttpRequest();
            var upload = xhr.upload;
            var that = $(this);
            that.attr('disabled', true);
            upload.addEventListener("progress", function(a) {
                if (a.lengthComputable) {
                    progressbar.css('width', (a.loaded / a.total) * 100 + '%');
                }
            }, 0);
            upload.addEventListener("load", function(a) {}, 0);
            upload.addEventListener("error", function(a) {
                alert("Error:" + a);
            }, 0);
            xhr.open("POST", imgurlcity);
            xhr.overrideMimeType("application/octet-stream");
            var formPost = new FormData;
            formPost.append("upload", imgData);
            formPost.append("type", upfield);
            formPost.append('field', field);
            formPost.append("base64", 1);
            formPost.append("FORM_HASH", FORM_HASH);
            xhr.onreadystatechange = function() {
                if (4 == xhr.readyState) {
                    switch (xhr.status) {
                    case 200:
                        var data = {};
                        try {
                            eval('data=' + xhr.responseText);
                            console.log(data);
                        } catch (e) {}
                        if (data && data.error == 0) {
                            $('#' + upfield).attr('src', data.extend.url).show();
                            $('#' + upfield + '1').attr('value', data.extend.url);
                            mui("#crop-dialog").popover("hide");
                            callback && window[callback](data);
                        } else {
                            mui.toast(data.data);
                        }
                        break;
                    default:
                        mui.toast('&#19978;&#20256;&#22833;&#36133;&#65292;&#35831;&#37325;&#35797;');
                        break;
                    }
                    that.removeAttr('disabled');
                }
            };
            xhr.send(formPost);
        });
        $('#crop-plus-btn').off('click').on('click', function() {
            window.cropObject.zoom(0.1);
        });
        $('#crop-dec-btn').off('click').on('click', function() {
            window.cropObject.zoom( - 0.1);
        });
        $('#crop-rotate-btn').off('click').on('click', function() {
            window.cropObject.rotate(90);
        });
        var fileElement = false;
        var getInputFile = function(attr, onChange) {
            if (!fileElement) {
                try {
                    fileElement = $('<input accept="image/*" type="file" style="opacity: 0;" /' + '>');
                    $(document.body).append(fileElement);
                    fileElement.on('click', function() {
                        fileElement.val('');
                    }).on('change', onChange);
                } catch (e) {
                    alert(e.number + '-' + e.message + ':' + e.descrption + '(&#21019;&#24314;&#73;&#78;&#80;&#85;&#84;&#61;&#70;&#105;&#108;&#101;&#22833;&#36133;)');
                }
            }
            fileElement.attr(attr);
            return fileElement;
        };
        window.cropObject = false;
        var cropOptions = {};
        $.fn.mzCrop = function() {
            $(this).on(window.CLICK_EVENT, function() {
                var that = this;
                var attr = {
                    accept: ($(that).data('accept') || 'image') + '/*',
                    type: 'file'
                };
                var clicks = parseInt($(that).data('clicks'), 10);
                if (!clicks) {
                    clicks = 0;
                }
                clicks++;
                $(that).data('clicks', clicks);
                if (clicks > 3) {
                    if (confirm("\u7cfb\u7edf\u68c0\u6d4b\u5230\u60a8\u591a\u6b21\u70b9\u51fb\u4e0a\u4f20\u6309\u94ae\uff0c\u662f\u5426\u65e0\u6cd5\u4e0a\u4f20\u6587\u4ef6\uff1f")) {
                        alert(['\u89e3\u51b3\u65b9\u6848\u0031\uff1a\u5b89\u88c5\u0020\u0051\u0051\u6d4f\u89c8\u5668\uff0c\u5b89\u88c5\u597d\u540e\uff0c\u91cd\u542f\u5fae\u4fe1\uff0c\u518d\u6b21\u4e0a\u4f20\u3002'].join("\r\n"));
                        alert(['\u89e3\u51b3\u65b9\u6848\u0032\uff1a', '\u4f7f\u7528\u0055\u0043\u3001\u730e\u8c79\u3001\u641c\u72d7\u3001\u0051\u0051\u7b49\u6d4f\u89c8\u5668\u8f93\u5165\u7f51\u5740\u8fdb\u884c\u767b\u8bb0\uff1a', document.domain].join("\r\n"));
                    }
                }
                cropOptions = {};
                if ($(that).data('maxwidth')) {
                    cropOptions.maxCropBoxWidth = $(that).data('maxwidth');
                    $('#crop-submit-btn').data('width', cropOptions.maxCropBoxWidth);
                }
                if ($(that).data('minwidth')) {
                    cropOptions.minCropBoxWidth = $(that).data('minwidth');
                    $('#crop-submit-btn').data('width', cropOptions.minCropBoxWidth);
                }
                if ($(that).data('maxheight')) {
                    cropOptions.maxCropBoxHeight = $(that).data('maxheight');
                    $('#crop-submit-btn').data('height', cropOptions.maxCropBoxHeight);
                }
                if ($(that).data('minheight')) {
                    cropOptions.minCropBoxHeight = $(that).data('minheight');
                    $('#crop-submit-btn').data('height', cropOptions.minCropBoxHeight);
                }
                if (parseInt($(that).data('aspectratio'), 10)>-1) {
                    cropOptions.aspectRatio = $(that).data('aspectratio');
                }
                if ($(that).data('autocrop')) {
                    cropOptions.autoCropArea = $(that).data('autocrop');
                }
                if (parseInt($(that).data('viewmode'), 10)>-1) {
                    cropOptions.viewMode = $(that).data('viewmode');
                } else {}
                $('#crop-submit-btn').data('upload', $(that).data('upload')).data('id', $(that).data('id')).data('field', $(that).data('field'));
                if (false && parseInt(UID, 10) == 12) {
                    if (!WX_INIT) {
                        alert('\u5fae\u4fe1\u63a5\u53e3\u672a\u914d\u7f6e\uff0c\u65e0\u6cd5\u4e0a\u4f20');
                    }
                    wx.chooseImage({
                        count: 1,
                        sizeType: ['original', 'compressed'],
                        sourceType: ['album', 'camera'],
                        success: function(res) {
                            if (res.errMsg != "chooseImage:ok") {
                                alert('\u4e0a\u4f20\u56fe\u7247\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5');
                            }
                            var localIds = res.localIds.pop();
                            setTimeout(function() {
                                wx.uploadImage({
                                    localId: localIds,
                                    isShowProgressTips: 1,
                                    success: function(res) {
                                        var serverId = res.serverId;
                                        console.log(res);
                                        mui("#crop-dialog").popover("show");
                                        if (window.cropObject) {
                                            window.cropObject.destroy();
                                            window.cropObject = null;
                                        }
                                        var loadEle = $('<span>&#22270;&#29255;&#21152;&#36733;&#12289;&#21387;&#32553;&#22788;&#29702;&#20013;&#46;&#46;&#46;</span>');
                                        $("#crop-dialog .crop-img").html('').append(loadEle).append('<img class="upload" />');
                                        var oImg = $("#crop-dialog img")[0];
                                        oImg.onload = function() {
                                            if (oImg.complete) {
                                                cropOptions = $.extend({}, {
                                                    modal: true,
                                                    minCropBoxWidth: 5,
                                                    minCropBoxHeight: 5,
                                                    crop: function(data) {}
                                                }, cropOptions);
                                                window.cropObject = new Cropper(oImg, cropOptions);
                                                loadEle.remove();
                                            }
                                        };
                                        oImg.src = DIR + '&FORM_HASH=' + FORM_HASH;
                                    }
                                });
                            }, 0);
                        }
                    });
                } else {
                    try {
                        var inputs = getInputFile(attr, function(evt) {
                            evt.stopPropagation();
                            evt.preventDefault();
                            var file = evt.dataTransfer !== undefined ? evt.dataTransfer.files[0]: evt.target.files[0];
                            if (!isCanvasSupported()) {
                                alert('\u60a8\u7684\u6d4f\u89c8\u5668\u4e0d\u652f\u6301\u4e0a\u4f20\u56fe\u7247\uff0c\u8bf7\u66f4\u6362\u5176\u5b83\u6d4f\u89c8\u5668\u5c1d\u8bd5');
                                return;
                            }
                            var acceptPattern = new RegExp(attr.accept, 'ig');
                            if (!file.type.search(acceptPattern)==-1) {
                                return;
                            }
                            mui("#crop-dialog").popover("show");
                            if (window.cropObject) {
                                window.cropObject.destroy();
                                window.cropObject = null;
                            }
                            var loadEle = $('<span>&#22270;&#29255;&#21152;&#36733;&#12289;&#21387;&#32553;&#22788;&#29702;&#20013;&#46;&#46;&#46;</span>');
                            $("#crop-dialog .crop-img").html('').append(loadEle).append('<img class="upload" />');
                            var oImg = $("#crop-dialog img")[0];
                            compress(file, function(base64Img) {
                                oImg.src = base64Img;
                                cropOptions = $.extend({},
                                {
                                    modal: true,
                                    minCropBoxWidth: 5,
                                    minCropBoxHeight: 5,
                                    crop: function(data) {}
                                }, cropOptions);
                                window.cropObject = new Cropper(oImg, cropOptions);
                                loadEle.remove();
                            });
                        });
                        inputs[0].click();
                    } catch (e) {
                        try {
                            inputs.click();
                        } catch (es) {
                            var alertMessage = e.number + '-' + e.message + ':' + e.descrption + "\r\n" + es.number + '-' + es.message + ':' + es.descrption;
                            alert(alertMessage);
                        }
                    }
                }
            });
            return this;
        }
    })(window.Zepto || window.jQuery);
    $('*[data-upload]').mzCrop();
});;


