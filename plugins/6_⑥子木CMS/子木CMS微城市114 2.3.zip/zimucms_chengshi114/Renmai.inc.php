<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
$model = addslashes($_GET['model']);


if ($model == 'editrenmai') {
    
    
    if (submitcheck('editrenmai')) {

        $renmaidata['sid']          = intval($_GET['sid']);
        $renmaidata['id']          = intval($_GET['id']);
        $renmaidata['weixin_id']   = strip_tags($_GET['weixin_id']);
        $renmaidata['weixin_name'] = strip_tags($_GET['weixin_name']);
        $renmaidata['weixin_desc'] = strip_tags($_GET['weixin_desc']);
        $renmaidata['weixin_sex']  = intval($_GET['weixin_sex']);
        
        if ($_FILES['weixin_touxiang']['tmp_name']) {
            $renmaidata['weixin_touxiang'] = zm_saveimages($_FILES['weixin_touxiang'], 'renmai');
        }
        
        if ($_FILES['weixin_erweima']['tmp_name']) {
            $renmaidata['weixin_erweima'] = zm_saveimages($_FILES['weixin_erweima'], 'renmai');
        }
        
        $renmaidata['click']  = intval($_GET['click']);
        $renmaidata['status'] = intval($_GET['status']);
        
        $result = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
            'id' => $renmaidata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        $rid = intval($_GET['rid']);
        
        $renmaidata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_renmai',
            $rid
        ));
        
        include template('zimucms_chengshi114:admin/editrenmai');
    }
}else if ($model == 'addrenmai') {


    if (submitcheck('editrenmai')) {
        
        $renmaidata['sid']          = intval($_GET['sid']);
        $renmaidata['weixin_id']   = strip_tags($_GET['weixin_id']);
        $renmaidata['weixin_name'] = strip_tags($_GET['weixin_name']);
        $renmaidata['weixin_desc'] = strip_tags($_GET['weixin_desc']);
        $renmaidata['weixin_sex']  = intval($_GET['weixin_sex']);
        
        if ($_FILES['weixin_touxiang']['tmp_name']) {
            $renmaidata['weixin_touxiang'] = zm_saveimages($_FILES['weixin_touxiang'], 'renmai');
        }
        
        if ($_FILES['weixin_erweima']['tmp_name']) {
            $renmaidata['weixin_erweima'] = zm_saveimages($_FILES['weixin_erweima'], 'renmai');
        }
        
        $renmaidata['click']  = intval($_GET['click']);
        $renmaidata['status'] = intval($_GET['status']);
        
        $result = DB::insert('zimucms_chengshi114_renmai', $renmaidata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {

        include template('zimucms_chengshi114:admin/editrenmai');

    }




} else if ($model == 'delrenmai' && $_GET['formhash'] == formhash()) {
    
    $rid = intval($_GET['rid']);

    $result = DB::delete('zimucms_chengshi114_renmai', array(
        'id' => $rid
    ));

    $result2 = DB::delete('zimucms_chengshi114_ranklist', array(
        'type' => '2',
        'yid' => $rid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }

} else {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $status = intval($_GET['status']);
    
    
    if ($status == 1) {
        $wheresql = ' where sid!=0';
    } else if ($status == 2) {
        $wheresql = ' where sid=0';
    }
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
        "zimucms_chengshi114_renmai"
    ));
    
    $limit      = 50;
    $start      = ($page - 1) * $limit;
    $page_num   = ceil($count / $limit);
    $renmaidata = DB::fetch_all('select * from %t ' . $wheresql . ' order by status asc,id desc limit %d,%d', array(
        'zimucms_chengshi114_renmai',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, SITE_URL . '/admin.php?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&status=' . $status, '10000', '10000', TRUE, TRUE);
    }
    include template('zimucms_chengshi114:admin/renmailist');
    
}