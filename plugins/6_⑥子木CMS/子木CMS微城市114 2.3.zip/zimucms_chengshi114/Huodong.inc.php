<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
$model = addslashes($_GET['model']);


if ($model == 'edithuodong') {
    
    
    if (submitcheck('edithuodong')) {
        
        $isstatus = DB::result_first('select status from %t where id=%d', array(
            'zimucms_chengshi114_huodong',
            intval($_GET['id'])
        ));

        $huodongdata['id']    = intval($_GET['id']);
        $huodongdata['title'] = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['thumb']['tmp_name']) {
            $huodongdata['thumb'] = zm_saveimages($_FILES['thumb'], 'huodong');
        }
        $huodongdata['starttime']    = strtotime($_GET['starttime']);
        $huodongdata['endtime']      = strtotime($_GET['endtime']);
        $huodongdata['content']      = dhtmlspecialchars(zm_diconv($_GET['content']));
        $huodongdata['uid']          = intval($_GET['uid']);
        $huodongdata['sid']          = intval($_GET['sid']);
        $huodongdata['lianxiren']    = strip_tags(zm_diconv($_GET['lianxiren']));
        $huodongdata['tel']          = strip_tags(zm_diconv($_GET['tel']));
        $huodongdata['huodong_desc'] = strip_tags(zm_diconv($_GET['huodong_desc']));
        $huodongdata['status']       = intval($_GET['status']);
        
        $result = DB::update('zimucms_chengshi114_huodong', $huodongdata, array(
            'id' => $huodongdata['id']
        ));



$zmweixin = (array) unserialize($_G['setting']['zimucms_weixin']);

if($zmweixin['weixin_appid']){

        $touser = DB::result_first('select openid from %t where uid=%d', array(
            'zimucms_weixin_binduser',
            $huodongdata['uid']
        ));

}

if($touser && $isstatus==1 && $huodongdata['status']==2){

require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/class/wechat.lib.class.php';
if($zmweixin['weixin_appid']){
$wechat_client = new WeChatClient($zmweixin['weixin_appid'], $zmweixin['weixin_appsecret']);
}else{
$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);   
}

    $token    = $wechat_client->getAccessToken(1);
    $template = array(
        'touser' => $touser,
        'template_id' => $zmdata['shangjia_mbid'],
        'url' => ZIMUCMS_URL . '&model=viewhuodong&hid=' . $huodongdata['id'],
        'data' => array(
            'first' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text16'), CHARSET, 'utf-8'))
            ),
            'keyword1' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text17'), CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text20'), CHARSET, 'utf-8'))
            ),
            'remark' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text19'), CHARSET, 'utf-8')),
            )
            
        )
    );
    $json     = urldecode(json_encode($template));
    $result2 = send_weixintemplate($token, $json);
}


        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        
        $id = intval($_GET['id']);
        
        $huodongdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_huodong',
            $id
        ));
        
        include template('zimucms_chengshi114:admin/edithuodong');
    }
    
    
    
} else if ($model == 'addhuodong') {
    
    
    if (submitcheck('addhuodong')) {
        
        
        //$huodongdata['id'] = intval($_GET['id']);
        $huodongdata['title'] = strip_tags(zm_diconv($_GET['title']));
        if ($_FILES['thumb']['tmp_name']) {
            $huodongdata['thumb'] = zm_saveimages($_FILES['thumb'], 'huodong');
        }
        $huodongdata['starttime'] = strtotime($_GET['starttime']);
        $huodongdata['endtime']   = strtotime($_GET['endtime']);
        $huodongdata['content']   = strip_tags(zm_diconv($_GET['content']));
        $huodongdata['uid']       = intval($_GET['uid']);
        $huodongdata['sid']       = intval($_GET['sid']);
        $huodongdata['status']    = intval($_GET['status']);
        
        $result = DB::insert('zimucms_chengshi114_huodong', $huodongdata);
        
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
        
    } else {
        
        
        include template('zimucms_chengshi114:admin/edithuodong');
    }
    
    
    
} else if ($model == 'delhuodong' && $_GET['formhash'] == formhash()) {
    
    $id = intval($_GET['id']);
    
    $result = DB::delete('zimucms_chengshi114_huodong', array(
        'id' => $id
    ));
    
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
    
    
} else {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
        "zimucms_chengshi114_huodong"
    ));
    
    $limit       = 50;
    $start       = ($page - 1) * $limit;
    $page_num    = ceil($count / $limit);
    $huodongdata = DB::fetch_all('select * from %t order by status asc,id asc limit %d,%d', array(
        'zimucms_chengshi114_huodong',
        $start,
        $limit
    ));
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, SITE_URL . '/admin.php?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name], '10000', '10000', TRUE, TRUE);
    }
    
    foreach ($huodongdata as $key => $value) {
        
        $huodongdata[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $value['sid']
        ));
        
    }
    
    include template('zimucms_chengshi114:admin/huodonglist');
    
}