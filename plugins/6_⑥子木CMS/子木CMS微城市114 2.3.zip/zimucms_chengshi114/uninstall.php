<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}



global $_G;

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_cheng114/public/upload");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_chengshi114/public/kindeditor/attached/image");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimucms_chengshi114/public/kindeditor/attached/images");

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_ad;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_cat;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_huodong;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_ranklist;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_renmai;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_shop;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_shoppic;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_yewuyuan;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_youhuiquan;
DROP TABLE  IF EXISTS pre_zimucms_chengshi114_youhuiquandata;
EOF;
runquery($sql);

DB::delete('common_setting', array('skey' => 'chengshi114_data'));

updatecache('setting');

$finish = TRUE;


function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}