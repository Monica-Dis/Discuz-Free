<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
$model = addslashes($_GET['model']);


if ($model == 'editad') {
    
    
    if (submitcheck('editad')) {
        
        
        
        $addata['id']    = intval($_GET['id']);
        $addata['title'] = strip_tags($_GET['title']);
        $addata['url']   = strip_tags($_GET['url']);
        $addata['sort']  = intval($_GET['sort']);
        
        if ($_FILES['pic']['tmp_name']) {
            $addata['pic'] = zm_saveimages($_FILES['pic'], 'images');
        }
        
        $result = DB::update('zimucms_chengshi114_ad', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        
        $aid = intval($_GET['aid']);
        
        $addata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_ad',
            $aid
        ));
        
        include template('zimucms_chengshi114:admin/editad');
    }
    
    
    
} else if ($model == 'addad') {
    
    
    if (submitcheck('editad')) {
        
        
        $addata['title'] = strip_tags($_GET['title']);
        $addata['url']   = strip_tags($_GET['url']);
        $addata['sort']  = intval($_GET['sort']);
        
        if ($_FILES['pic']['tmp_name']) {
            $addata['pic'] = zm_saveimages($_FILES['pic'], 'images');
        }
        
        $result = DB::insert('zimucms_chengshi114_ad', $addata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
        
    } else {
        
        $aid = intval($_GET['aid']);
        
        $addata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_ad',
            $aid
        ));
        
        include template('zimucms_chengshi114:admin/editad');
    }
    
    
    
} else if ($model == 'delad' && $_GET['formhash'] == formhash()) {
    
    $aid = intval($_GET['aid']);
    
    $result = DB::delete('zimucms_chengshi114_ad', array(
        'id' => $aid
    ));
    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
    
    
} else {
    
    $addata = DB::fetch_all('select * from %t order by sort asc', array(
        'zimucms_chengshi114_ad'
    ));
    
    include template('zimucms_chengshi114:admin/adlist');
    
}