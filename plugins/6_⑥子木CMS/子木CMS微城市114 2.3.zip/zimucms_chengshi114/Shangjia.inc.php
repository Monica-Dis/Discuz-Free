<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 应用更新支持：https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';

$model = addslashes($_GET['model']);


if ($model == 'editshop') {
    
    
    if (submitcheck('editshop')) {
        

        $isstatus = DB::result_first('select status from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            intval($_GET['id'])
        ));


        $shopdata['id']   = intval($_GET['id']);
        $shopdata['uid']   = intval($_GET['uid']);
        $shopdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_logo']['tmp_name']) {
            $shopdata['logo'] = zm_saveimages($_FILES['shop_logo'], 'renmai');
        }
        
        if ($_FILES['shop_thumb']['tmp_name']) {
            $shopdata['thumb'] = zm_saveimages($_FILES['shop_thumb'], 'renmai');
        }
        $shopdata['lianxiren'] = strip_tags($_GET['lianxiren']);
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['address']   = strip_tags($_GET['address']);
        $shopdata['desc']      = dhtmlspecialchars($_GET['desc']);
        $shopdata['typeid1']   = intval($_GET['typeid1']);
        $shopdata['typeid2']   = intval($_GET['typeid2']);
        $shopdata['youhui']    = strip_tags($_GET['youhui']);
        $shopdata['status']    = intval($_GET['status']);
        $shopdata['province']  = intval($_GET['province']);
        $shopdata['city']      = intval($_GET['city']);
        $shopdata['country']   = intval($_GET['country']);
        $shopdata['click']     = intval($_GET['click']);
        $shopdata['lng']       = strip_tags($_GET['lng']);
        $shopdata['lat']       = strip_tags($_GET['lat']);
        $shopdata['ispay']     = intval($_GET['ispay']);
        if(strtotime($_GET['addtime'])){
            $shopdata['addtime']   = strtotime($_GET['addtime']);
        }else{
            $shopdata['addtime']   = strtotime($_GET['viptime']);
        }
        $shopdata['viptime']   = strtotime($_GET['viptime']);
        $shopdata['endtime']   = strtotime($_GET['endtime']);
        $shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $shopdata['sort']      = intval($_GET['sort']);

$ranklistdata['dayclick'] = intval($_GET['dayclick']);
$ranklistdata['weekclick'] = intval($_GET['weekclick']);
$ranklistdata['monthclick'] = intval($_GET['monthclick']);
$ranklistdata['yearclick'] = intval($_GET['click']);

        $result = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id']
        ));
 
        $result2 = DB::update('zimucms_chengshi114_ranklist', $ranklistdata, array(
            'type' => '1',           
            'yid' => $shopdata['id']
        ));

$zmweixin = (array) unserialize($_G['setting']['zimucms_weixin']);

if($zmweixin['weixin_appid']){

        $touser = DB::result_first('select openid from %t where uid=%d', array(
            'zimucms_weixin_binduser',
            $shopdata['uid']
        ));
}

if($touser && $isstatus==1 && $shopdata['status']==2){

require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/class/wechat.lib.class.php';
if($zmweixin['weixin_appid']){
$wechat_client = new WeChatClient($zmweixin['weixin_appid'], $zmweixin['weixin_appsecret']);
}else{
$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);   
}

    $token    = $wechat_client->getAccessToken(1);
    $template = array(
        'touser' => $touser,
        'template_id' => $zmdata['shangjia_mbid'],
        'url' => ZIMUCMS_URL . '&model=viewshop&sid=' . $shopdata['id'],
        'data' => array(
            'first' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text16'), CHARSET, 'utf-8'))
            ),
            'keyword1' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text17'), CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text18'), CHARSET, 'utf-8'))
            ),
            'remark' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text19'), CHARSET, 'utf-8')),
            )
            
        )
    );
    $json     = urldecode(json_encode($template));
    $result2 = send_weixintemplate($token, $json);
}




        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        $sid = intval($_GET['sid']);
        
        $shopdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $sid
        ));

        $ranklistdata = DB::fetch_first('select * from %t where type=1 and yid=%d', array(
            'zimucms_chengshi114_ranklist',
            $sid
        ));

        $chengshi114_data = (array) unserialize($_G['setting']['chengshi114_data']);
        
        //$ciddata = DB::fetch_all('select * from %t where cid=0 order by sort desc',array('zimucms_chengshi114_cat'));
        
        $ciddata = $chengshi114_data['catdata'];
        
        $cid2data = DB::fetch_all('select * from %t where cid=%d order by sort desc', array(
            'zimucms_chengshi114_cat',
            $shopdata['typeid1']
        ));
        
        $provincedata = DB::fetch_first('select * from %t where id=%d', array(
            'common_district',
            $zmdata['moren_province']
        ));
        
        $citydata = DB::fetch_first('select * from %t where id=%d', array(
            'common_district',
            $zmdata['moren_city']
        ));
        
        
        
        if ($chengshi114_data['countrydata']['moren_city'] != $zmdata['moren_city'] || !$chengshi114_data['countrydata']) {
            $countrydata                 = DB::fetch_all('select * from %t where upid=%d order by displayorder asc', array(
                'common_district',
                $zmdata['moren_city']
            ));
            $countrydata2['countrydata'] = array(
                'moren_city' => $zmdata['moren_city'],
                'countrydata' => $countrydata
            );
            $chengshi114_data            = array(
                'chengshi114_data' => serialize($countrydata2 + $chengshi114_data)
            );
            C::t('common_setting')->update_batch($chengshi114_data);
            updatecache('setting');
        } else {
            $countrydata = $chengshi114_data['countrydata']['countrydata'];
        }
        
    
        include template('zimucms_chengshi114:admin/editshop');
    }



} else if ($model == 'addshop') {


    if (submitcheck('editshop')) {
        
        
        $shopdata['uid']   = intval($_GET['uid']);
        $shopdata['name'] = strip_tags($_GET['name']);
        if ($_FILES['shop_logo']['tmp_name']) {
            $shopdata['logo'] = zm_saveimages($_FILES['shop_logo'], 'renmai');
        }
        
        if ($_FILES['shop_thumb']['tmp_name']) {
            $shopdata['thumb'] = zm_saveimages($_FILES['shop_thumb'], 'renmai');
        }
        $shopdata['lianxiren'] = strip_tags($_GET['lianxiren']);
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['address']   = strip_tags($_GET['address']);
        $shopdata['desc']      = dhtmlspecialchars($_GET['desc']);
        $shopdata['typeid1']   = intval($_GET['typeid1']);
        $shopdata['typeid2']   = intval($_GET['typeid2']);
        $shopdata['youhui']    = strip_tags($_GET['youhui']);
        $shopdata['status']    = intval($_GET['status']);
        $shopdata['province']  = intval($_GET['province']);
        $shopdata['city']      = intval($_GET['city']);
        $shopdata['country']   = intval($_GET['country']);
        $shopdata['click']     = intval($_GET['click']);
        $shopdata['lng']       = strip_tags($_GET['lng']);
        $shopdata['lat']       = strip_tags($_GET['lat']);
        $shopdata['ispay']     = intval($_GET['ispay']);
        if(strtotime($_GET['addtime'])){
            $shopdata['addtime']   = strtotime($_GET['addtime']);
        }else{
            $shopdata['addtime']   = strtotime($_GET['viptime']);
        }
        $shopdata['viptime']   = strtotime($_GET['viptime']);
        $shopdata['endtime']   = strtotime($_GET['endtime']);
        $shopdata['yewuyuan']  = intval($_GET['yewuyuan']);    
        $shopdata['sort']      = intval($_GET['sort']);
        $result = DB::insert('zimucms_chengshi114_shop', $shopdata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {

        $chengshi114_data = (array) unserialize($_G['setting']['chengshi114_data']);
        
        //$ciddata = DB::fetch_all('select * from %t where cid=0 order by sort desc',array('zimucms_chengshi114_cat'));
        
        $ciddata = $chengshi114_data['catdata'];
        
        $cid2data = DB::fetch_all('select * from %t where cid=%d order by sort desc', array(
            'zimucms_chengshi114_cat',
            $ciddata[0]['id']
        ));
        
        $provincedata = DB::fetch_first('select * from %t where id=%d', array(
            'common_district',
            $zmdata['moren_province']
        ));
        
        $citydata = DB::fetch_first('select * from %t where id=%d', array(
            'common_district',
            $zmdata['moren_city']
        ));
        
        if ($chengshi114_data['countrydata']['moren_city'] != $zmdata['moren_city'] || !$chengshi114_data['countrydata']) {
            $countrydata                 = DB::fetch_all('select * from %t where upid=%d order by displayorder asc', array(
                'common_district',
                $zmdata['moren_city']
            ));
            $countrydata2['countrydata'] = array(
                'moren_city' => $zmdata['moren_city'],
                'countrydata' => $countrydata
            );
            $chengshi114_data            = array(
                'chengshi114_data' => serialize($countrydata2 + $chengshi114_data)
            );
            C::t('common_setting')->update_batch($chengshi114_data);
            updatecache('setting');
        } else {
            $countrydata = $chengshi114_data['countrydata']['countrydata'];
        }

        include template('zimucms_chengshi114:admin/editshop');
    }
} else if ($model == 'delshop' && $_GET['formhash'] == formhash()) {
    
    $sid = intval($_GET['sid']);
    
    $result = DB::delete('zimucms_chengshi114_shop', array(
        'id' => $sid,
    ));

    $result2 = DB::delete('zimucms_chengshi114_renmai', array(
        'sid' => $sid
    ));

    $result3 = DB::delete('zimucms_chengshi114_ranklist', array(
        'type' => '1',
        'yid' => $sid
    ));

    $result4 = DB::delete('zimucms_chengshi114_ranklist', array(
        'type' => '2',
        'yid' => $sid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
 


} else if ($model == 'addshoppic') {
    
    
    if (submitcheck('editshoppic')) {
        
        $addata['sid']    = intval($_GET['sid']);
        $addata['uid']    = intval($_GET['sid']);
        $addata['title'] = strip_tags($_GET['title']);
        $addata['createtime']  = strtotime($_GET['createtime']);

        if ($_FILES['imgurl']['tmp_name']) {
            $addata['imgurl'] = zm_saveimages($_FILES['imgurl'], 'images');
        }
        
        $result = DB::insert('zimucms_chengshi114_shoppic', $addata);
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'].'&model=shoppiclist&sid='.intval($_GET['sid']).'&uid='.intval($_GET['uid']);
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
        
    } else {
        
        $sid = intval($_GET['sid']);
        
        include template('zimucms_chengshi114:admin/editshoppic');
    }
    

}else if($model=="editshoppic"){

    if (submitcheck('editshoppic')) {

        $addata['id']    = intval($_GET['id']);
        $addata['title'] = strip_tags($_GET['title']);
        $addata['createtime']  = strtotime($_GET['createtime']);

        if ($_FILES['imgurl']['tmp_name']) {
            $addata['imgurl'] = zm_saveimages($_FILES['imgurl'], 'images');
        }
        
        $result = DB::update('zimucms_chengshi114_shoppic', $addata, array(
            'id' => $addata['id']
        ));
        
        if ($result) {
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'].'&model=shoppiclist&sid='.intval($_GET['sid']).'&uid='.intval($_GET['uid']);
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }

    }else{
    $pid = intval($_GET['pid']);
    $shoppicdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shoppic',
            $pid
        ));

    include template('zimucms_chengshi114:admin/editshoppic');
}

}else if($model=="shoppiclist"){

    $sid = intval($_GET['sid']);
    $uid = intval($_GET['uid']);
    $shoppicdata = DB::fetch_all('select * from %t where sid=%d order by createtime desc', array(
            'zimucms_chengshi114_shoppic',
            $sid
        ));
    
    include template('zimucms_chengshi114:admin/shoppiclist');



} else if ($model == 'delshoppic' && $_GET['formhash'] == formhash()) {


    $pid = intval($_GET['pid']);
    
    $result = DB::delete('zimucms_chengshi114_shoppic', array(
        'id' => $pid
    ));

    if ($result) {
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'].'&model=shoppiclist&sid='.intval($_GET['sid']).'&uid='.intval($_GET['uid']);
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }


} else {
    
    $page = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page = intval($page);
    
    $status = intval($_GET['status']);
    
    $shanghuname = $_GET['shanghuname'];
    $shanghuname = strip_tags(zm_diconv($shanghuname));
    
    
    //新增审核修改
    $shanghuname = dhtmlspecialchars($shanghuname);
    $shanghuname = stripsearchkey($shanghuname);
    $shanghuname = daddslashes($shanghuname);
    

    $todaycount = DB::result_first("SELECT count(*) FROM %t WHERE ispay=2 AND viptime>=%d AND viptime<=%d", array(
        "zimucms_chengshi114_shop",
        strtotime(date('Y-m-d',$_G['timestamp'])),
        strtotime(date('Y-m-d',$_G['timestamp']))+86400
    ));

    $yestodaycount = DB::result_first("SELECT count(*) FROM %t WHERE ispay=2 AND viptime>=%d AND viptime<=%d", array(
        "zimucms_chengshi114_shop",
        strtotime(date('Y-m-d',$_G['timestamp']))-86400,
        strtotime(date('Y-m-d',$_G['timestamp']))
    ));

    $alldaycount = DB::result_first("SELECT count(*) FROM %t WHERE ispay=2", array(
        "zimucms_chengshi114_shop",
    ));

    if ($status) {
        if($status==4){
            $wheresql = ' where status=2 and endtime < ' . $_G['timestamp'];
        }else if($status==5){
            $wheresql = ' where status=2 and viptime >= ' . strtotime(date('Y-m-d',$_G['timestamp'])) .' and viptime <= '.(strtotime(date('Y-m-d',$_G['timestamp']))+86400);
        }else if($status==6){
            $wheresql = ' where status=2 and viptime >= ' . (strtotime(date('Y-m-d',$_G['timestamp']))-86400) .' and viptime <= '.strtotime(date('Y-m-d',$_G['timestamp']));
        }else{
            $wheresql = ' where status=' . $status;
        }
    } else {
        $wheresql = ' where status <3';
    }
    if ($shanghuname) {
        $shanghunamesql = ' and name like %s';
    }
    
    $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql . $shanghunamesql, array(
        "zimucms_chengshi114_shop",
        "%" . $shanghuname . "%"
    ));
    
    $limit    = 50;
    $start    = ($page - 1) * $limit;
    $page_num = ceil($count / $limit);
    if ($shanghuname) {
        $shopdata = DB::fetch_all('select * from %t ' . $wheresql . $shanghunamesql . ' order by id desc limit %d,%d', array(
            'zimucms_chengshi114_shop',
            '%' . $shanghuname . '%',
            $start,
            $limit
        ));
    } else {
        $shopdata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimucms_chengshi114_shop',
            $start,
            $limit
        ));
    }
    if ($page_num > 1) {
        $multipage = multi($count, $limit, $page, SITE_URL . '/admin.php?action=plugins&operation=config&do=' . $plugin[pluginid] . '&identifier=' . $plugin[identifier] . '&pmod=' . $module[name] . '&status=' . $status, '10000', '10000', TRUE, TRUE);
    }
    include template('zimucms_chengshi114:admin/shangjialist');
    
}