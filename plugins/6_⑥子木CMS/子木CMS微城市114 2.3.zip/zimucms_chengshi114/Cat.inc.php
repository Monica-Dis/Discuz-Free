<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
$model            = addslashes($_GET['model']);
$chengshi114_data = (array) unserialize($_G['setting']['chengshi114_data']);

if ($model == 'editcat') {
    
    
    if (submitcheck('editcat')) {
        
        
        
        $catdata['id']   = intval($_GET['id']);
        $catdata['name'] = strip_tags($_GET['name']);
        $catdata['sort'] = intval($_GET['sort']);
        $catdata['caturl'] = strip_tags($_GET['caturl']);
        if ($_FILES['logo']['tmp_name']) {
            $catdata['logo'] = zm_saveimages($_FILES['logo'], 'images');
        }
        
        $result = DB::update('zimucms_chengshi114_cat', $catdata, array(
            'id' => $catdata['id']
        ));
        
        if ($result) {
            
            
            $catdata2['catdata'] = catlist();
            $chengshi114_data    = array(
                'chengshi114_data' => serialize($catdata2 + $chengshi114_data)
            );
            C::t('common_setting')->update_batch($chengshi114_data);
            updatecache('setting');
            
            
            
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
    } else {
        
        $id = intval($_GET['id']);
        
        $catata = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_cat',
            $id
        ));
        
        include template('zimucms_chengshi114:admin/editcat');
    }
    
    
    
} else if ($model == 'addcat') {
    
    
    if (submitcheck('addcat')) {
        
        
        $catdata['cid'] = intval($_GET['id']);
        
        if ($catdata['cid']) {
            $catdata['name'] = strip_tags($_GET['name']);
            $catdata['sort'] = intval($_GET['sort']);
            $catdata['caturl'] = strip_tags($_GET['caturl']);

            if ($_FILES['logo']['tmp_name']) {
                $catdata['logo'] = zm_saveimages($_FILES['logo'], 'images');
            }
            
            $result = DB::insert('zimucms_chengshi114_cat', $catdata);
        } else {
            
            $catdata['name'] = strip_tags($_GET['name']);
            $catdata['sort'] = intval($_GET['sort']);
            $catdata['cid']  = '0';
            if ($_FILES['logo']['tmp_name']) {
                $catdata['logo'] = zm_saveimages($_FILES['logo'], 'images');
            }
            $result = DB::insert('zimucms_chengshi114_cat', $catdata);
        }
        if ($result) {
            
            $catdata2['catdata'] = catlist();
            $chengshi114_data    = array(
                'chengshi114_data' => serialize($catdata2 + $chengshi114_data)
            );
            C::t('common_setting')->update_batch($chengshi114_data);
            updatecache('setting');
            
            
            
            $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
        } else {
            cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
        }
        
        
    } else {
        
        $id = intval($_GET['id']);
        
        include template('zimucms_chengshi114:admin/addcat');
    }
    
    
    
} else if ($model == 'delcat' && $_GET['formhash'] == formhash()) {
    
    $id = intval($_GET['id']);
    
    $ciddata = DB::fetch_all('select * from %t where cid=%d', array(
        'zimucms_chengshi114_cat',
        $id
    ));
    
    foreach ($ciddata as $key => $value) {
        DB::delete('zimucms_chengshi114_cat', array(
            'id' => $value['id']
        ));
    }
    $result = DB::delete('zimucms_chengshi114_cat', array(
        'id' => $id
    ));
    
    if ($result) {
        
        $catdata2['catdata'] = catlist();
        
        $chengshi114_data = array(
            'chengshi114_data' => serialize($catdata2 + $chengshi114_data)
        );
        C::t('common_setting')->update_batch($chengshi114_data);
        updatecache('setting');
        
        $url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'];
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text8'), $url, 'succeed');
    } else {
        cpmsg(lang('plugin/zimucms_chengshi114', 'system_text9'), '', 'error');
    }
    
    
} else {

    $catdata = catlist();
    
    include template('zimucms_chengshi114:admin/catlist');
    
}



function catlist()
{
    $catdata = DB::fetch_all('select * from %t where cid=0 order by sort asc,id asc', array(
        'zimucms_chengshi114_cat'
    ));
    foreach ($catdata as $key => $value) {
        $catdata[$key]['xiaji'] = DB::fetch_all('select * from %t where cid=%d order by sort asc,id asc', array(
            'zimucms_chengshi114_cat',
            $value['id']
        ));
    }
    return $catdata;
}