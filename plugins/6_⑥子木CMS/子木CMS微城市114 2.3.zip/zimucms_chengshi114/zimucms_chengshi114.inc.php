<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 应用更新支持：https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$zmweixin = (array) unserialize($_G['setting']['zimucms_weixin']);

$chengshi114_data = (array) unserialize($_G['setting']['chengshi114_data']);
require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/config.php';
require_once DISCUZ_ROOT . './source/plugin/zimucms_chengshi114/class/wechat.lib.class.php';
if($zmweixin['weixin_appid']){
$wechat_client = new WeChatClient($zmweixin['weixin_appid'], $zmweixin['weixin_appsecret']);
}else{
$wechat_client = new WeChatClient($zmdata['weixin_appid'], $zmdata['weixin_appsecret']);
}
$jssdkvalue    = $wechat_client->getSignPackage();

$model = addslashes($_GET['model']);

if ($model == 'cat') {
    
    
    if ($zmdata['catstylelist'] == 2) {
        
        $catdata = $chengshi114_data['catdata'];
        
        $countrydata = $chengshi114_data['countrydata']['countrydata'];
        
        $cid = $_GET['cid'] = $_GET['cid'] ? $_GET['cid'] : 0;
        $cid = intval($cid);

        $cid2 = $_GET['cid2'] = $_GET['cid2'] ? $_GET['cid2'] : 0;
        $cid2 = intval($cid2);        

    if ($cid > 0) {
        $wherearr[] = DB::field('typeid1', $cid);
    }
    if ($cid2 > 0) {
        $wherearr[] = DB::field('typeid2', $cid2);
    }

    if ($wherearr) {
        $wheresql = 'and ' . implode(' and ', $wherearr);
    }

        $typename = DB::result_first('select name from %t where id=%d and cid=0', array(
            'zimucms_chengshi114_cat',
            $cid
        ));

        $typename2 = DB::result_first('select name from %t where id=%d and cid=%d', array(
            'zimucms_chengshi114_cat',
            $cid2,
            $cid
        ));

            $shopdata = DB::fetch_all('select * from %t where status=2 and endtime>%d %i order by click desc limit 100', array(
                'zimucms_chengshi114_shop',
                $_G['timestamp'],
                $wheresql
            ));
        
        
        foreach ($shopdata as $key => $value) {
            $shopdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d and endtime>%d', array(
                'zimucms_chengshi114_youhuiquan',
                $value['id'],
                time()
            ));
        }
        include template('zimucms_chengshi114:cat2');
        
    } else {
        
        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $start  = ($page - 1) * 10;
        $tonums = 20;
        
        $type = strip_tags($_GET['type']);
        
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);
        
        $cid = $_GET['cid'] = $_GET['cid'] ? $_GET['cid'] : 1;
        $cid = intval($cid);
        
        $cid2 = $_GET['cid2'] = $_GET['cid2'] ? $_GET['cid2'] : 0;
        $cid2 = intval($cid2);
        
        $catdata = DB::fetch_all('select * from %t where cid=%d order by sort asc,id asc', array(
            'zimucms_chengshi114_cat',
            '0'
        ));
        
        $cid2data = DB::fetch_all('select * from %t where cid=%d order by sort asc,id asc', array(
            'zimucms_chengshi114_cat',
            $cid
        ));
        
        $geo = strip_tags($_GET['geo']);
        $geo = explode(',', $geo);
        
        $roundweidu = returnSquarePoint($geo[0], $geo[1], '15');
        
        
        if ($status == 1) {
            $order = 'order by click desc';
        } else if ($status == 2) {
            $order = 'order by id desc';
        } else if ($status == 3) {
            $order = 'and lat > ' . $roundweidu["left-bottom"]["lat"] . ' and lat < ' . $roundweidu["left-top"]["lat"] . ' and lng > ' . $roundweidu["left-top"]["lng"] . ' AND lng < ' . $roundweidu["right-top"]["lng"] . ' order by click desc';
        }
        
        
        if ($cid2 == 0) {
            $shopdata = DB::fetch_all('select * from %t where status=2 and endtime>%d and typeid1=%d %i limit %d,%d', array(
                'zimucms_chengshi114_shop',
                $_G['timestamp'],
                $cid,
                $order,
                $start,
                $tonums
            ));
        } else {
            $shopdata = DB::fetch_all('select * from %t where status=2 and endtime>%d and typeid1=%d and typeid2=%d %i  limit %d,%d', array(
                'zimucms_chengshi114_shop',
                $_G['timestamp'],
                $cid,
                $cid2,
                $order,
                $start,
                $tonums
            ));
        }
        
        if ($status == 3) {
            foreach ($shopdata as $key => $value) {
                $shopdata[$key]['juli'] = getDistance($value['lat'], $value['lng'], $geo[1], $geo[0]);
            }
            $shopdata = array_sort($shopdata, 'juli');
        }
        
        if ($type == 'json') {
            include template('zimucms_chengshi114:catjson');
        } else {
            include template('zimucms_chengshi114:cat');
        }
    }
    
    
} else if ($model == 'fujinshop2json') {
    
    
    $lngid = strip_tags($_GET['lngid']);
    $latid = strip_tags($_GET['latid']);
    
    $roundweidu = returnSquarePoint($lngid, $latid, '15');
        
        $order = 'and lat > ' . $roundweidu["left-bottom"]["lat"] . ' and lat < ' . $roundweidu["left-top"]["lat"] . ' and lng > ' . $roundweidu["left-top"]["lng"] . ' AND lng < ' . $roundweidu["right-top"]["lng"] . ' order by click desc';
        
        
        $shopdata = DB::fetch_all('select * from %t where endtime>%d and status=2 %i', array(
            'zimucms_chengshi114_shop',
            $_G['timestamp'],
            $order
        ));
        
        foreach ($shopdata as $key => $value) {
            $shopdata[$key]['juli'] = getDistance($value['lat'], $value['lng'], $latid, $lngid);
        }
        $shopdata = array_sort($shopdata, 'juli');
    
    
    foreach ($shopdata as $key => $value) {
        $shopdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d and endtime>%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id'],
            time()
        ));
    }

    include template('zimucms_chengshi114:fujinshop2json');    
    
} else if ($model == 'cat2json') {
    
    $datatypeid1 = intval($_GET['datatypeid1']);
    $datatypeid2 = intval($_GET['datatypeid2']);
    $quyuid      = intval($_GET['quyuid']);
    $sortid      = intval($_GET['sortid']);
    
    if ($datatypeid1 > 0) {
        $wherearr[] = DB::field('typeid1', $datatypeid1);
    }
    if ($datatypeid2 > 0) {
        $wherearr[] = DB::field('typeid2', $datatypeid2);
    }
    if ($quyuid > 0) {
        $wherearr[] = DB::field('country', $quyuid);
    }
    if ($sortid == 1) {
        $ordersql = ' order by sort asc,click desc,id asc';
    }
    if ($sortid == 2) {
        $ordersql = ' order by id desc';
    }
    if ($wherearr) {
        $wheresql = 'and ' . implode(' AND ', $wherearr);
    }
    
    $lngid = strip_tags($_GET['lngid']);
    $latid = strip_tags($_GET['latid']);
    
    $roundweidu = returnSquarePoint($lngid, $latid, '15');
    
    if ($sortid == 3) {
        
        $order = 'and lat > ' . $roundweidu["left-bottom"]["lat"] . ' and lat < ' . $roundweidu["left-top"]["lat"] . ' and lng > ' . $roundweidu["left-top"]["lng"] . ' AND lng < ' . $roundweidu["right-top"]["lng"] . ' order by click desc';
        
        
        $shopdata = DB::fetch_all('select * from %t where status=2 %i %i', array(
            'zimucms_chengshi114_shop',
            $wheresql,
            $order
        ));
        
        foreach ($shopdata as $key => $value) {
            $shopdata[$key]['juli'] = getDistance($value['lat'], $value['lng'], $latid, $lngid);
        }
        $shopdata = array_sort($shopdata, 'juli');
        
        
    } else {
        $shopdata = DB::fetch_all('select * from %t where status=2 %i %i limit 100', array(
            'zimucms_chengshi114_shop',
            $wheresql,
            $ordersql
        ));
    }
    
    
    foreach ($shopdata as $key => $value) {
        $shopdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d and endtime>%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id'],
            time()
        ));
    }
    
    include template('zimucms_chengshi114:cat2json');
    
} else if ($model == 'youhuiquanjson') {
    
    $datatypeid1 = intval($_GET['datatypeid1']);
    $datatypeid2 = intval($_GET['datatypeid2']);
    $quyuid      = intval($_GET['quyuid']);
    $sortid      = intval($_GET['sortid']);
    
    if ($datatypeid1 > 0) {
        $wherearr[] = DB::field('typeid1', $datatypeid1);
    }
    if ($datatypeid2 > 0) {
        $wherearr[] = DB::field('typeid2', $datatypeid2);
    }
    if ($quyuid > 0) {
        $wherearr[] = DB::field('country', $quyuid);
    }
    if ($sortid == 1) {
        $ordersql = ' order by click desc,id asc';
    }
    if ($sortid == 2) {
        $ordersql = ' order by id desc';
    }
    if ($wherearr) {
        $wheresql = 'and ' . implode(' AND ', $wherearr);
    }
    
    $lngid = strip_tags($_GET['lngid']);
    $latid = strip_tags($_GET['latid']);
    
    $roundweidu = returnSquarePoint($lngid, $latid, '15');
    
    if ($sortid == 3) {
        
        $order = 'and lat > ' . $roundweidu["left-bottom"]["lat"] . ' and lat < ' . $roundweidu["left-top"]["lat"] . ' and lng > ' . $roundweidu["left-top"]["lng"] . ' AND lng < ' . $roundweidu["right-top"]["lng"] . ' order by click desc';
        
        
        $shopdata = DB::fetch_all('select * from %t where status=2 %i %i', array(
            'zimucms_chengshi114_shop',
            $wheresql,
            $order
        ));
        
        foreach ($shopdata as $key => $value) {
            $shopdata[$key]['juli'] = getDistance($value['lat'], $value['lng'], $latid, $lngid);
        }
        $shopdata = array_sort($shopdata, 'juli');
        
        
    } else {
        $shopdata = DB::fetch_all('select * from %t where status=2 %i %i limit 100', array(
            'zimucms_chengshi114_shop',
            $wheresql,
            $ordersql
        ));
    }
    
    
    foreach ($shopdata as $key => $value) {
        $shopdata[$key]['isyouhui'] = DB::fetch_all('select * from %t where status=2 and sid=%d and endtime>%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id'],
            time()
        ));
    }
    
    include template('zimucms_chengshi114:youhuiquanjson');
    
} else if ($model == 'youhuiquanlist') {
    
    $catdata = $chengshi114_data['catdata'];
    
    $countrydata = $chengshi114_data['countrydata']['countrydata'];
    
    $cid = $_GET['cid'] = $_GET['cid'] ? $_GET['cid'] : 0;
    $cid = intval($cid);
    
    $typename = DB::result_first('select name from %t where id=%d and cid=0', array(
        'zimucms_chengshi114_cat',
        $cid
    ));
    if ($cid) {
        $shopdata = DB::fetch_all('select * from %t where status=2 and typeid1=%d order by rand() limit 100', array(
            'zimucms_chengshi114_shop',
            $cid
        ));
    } else {
        $shopdata = DB::fetch_all('select * from %t where status=2 order by rand() limit 100', array(
            'zimucms_chengshi114_shop'
        ));
    }
    
    
    foreach ($shopdata as $key => $value) {
        $shopdata[$key]['isyouhui'] = DB::fetch_all('select * from %t where status=2 and sid=%d and endtime>%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id'],
            time()
        ));
    }
    
    
    include template('zimucms_chengshi114:youhuiquanlist');
    
    
} else if ($model == 'viewshop') {
    
    $sid = intval($_GET['sid']);
    
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_shop',
        $sid
    ));
    
    if ($shopdata) {
        if ($shopdata['status'] != 2) {
            $shoptiptext = $shopdata['name'] . lang('plugin/zimucms_chengshi114', 'system_text10');
            include template('zimucms_chengshi114:shoptip');
            exit();
        } else if ($shopdata['endtime'] < time()) {
            $shoptiptext = $shopdata['name'] . lang('plugin/zimucms_chengshi114', 'system_text11');
            include template('zimucms_chengshi114:shoptip');
            exit();
        }
    } else {
        dheader('Location:' . ZIMUCMS_URL);
        exit();
    }
    $monthclick = DB::result_first('select monthclick from %t where yid=%d and type=1', array(
        'zimucms_chengshi114_ranklist',
        $sid
    ));
    
    
    $paiming = DB::result_first("SELECT count(*) FROM %t where monthclick>%d and type=1", array(
        "zimucms_chengshi114_ranklist",
        $monthclick
    ));
    
    $paiming = $paiming + 1;
    
    $shoppic = DB::fetch_all('select * from %t where sid=%d order by id asc', array(
        'zimucms_chengshi114_shoppic',
        $sid
    ));
    
    $shoppicwidth = count($shoppic) * 155;
    
    $shopweixin = DB::fetch_first('select * from %t where sid=%d', array(
        'zimucms_chengshi114_renmai',
        $sid
    ));
    if ($shopdata['typeid1']) {
        $typename = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_cat',
            $shopdata['typeid1']
        ));
    }
    
    $youhuidata = DB::fetch_all('select * from %t where sid=%d and status=2 and endtime>%d order by id desc', array(
        'zimucms_chengshi114_youhuiquan',
        $sid,
        time()
    ));
    
    
    $huodongdata = DB::fetch_all('select * from %t where sid=%d and status=2 and endtime>%d order by id desc', array(
        'zimucms_chengshi114_huodong',
        $sid,
        time()
    ));
    
    if ($zmdata['viewshopisopen']) {
        $randshopdata = DB::fetch_all('select * from %t where typeid1=%d order by rand() limit 10', array(
            'zimucms_chengshi114_shop',
            $shopdata['typeid1']
        ));
    }

if($zmdata['isopen_red']){
    include template('zimucms_chengshi114:viewshop_red');
}else{
    include template('zimucms_chengshi114:viewshop');
}
    
} else if ($model == 'shopmap') {
    $sid      = intval($_GET['sid']);
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_shop',
        $sid
    ));
    include template('zimucms_chengshi114:shopmap');
} else if ($model == 'paihang') {
    
    $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
    $status = intval($status);
    if ($status == 1) {
        $order = 'dayclick';
    } else if ($status == 2) {
        $order = 'weekclick';
    } else if ($status == 3) {
        $order = 'monthclick';
    } else if ($status == 4) {
        $order = 'yearclick';
    }
    $paihangdata = DB::fetch_all('select yid from %t where type=1 order by %i desc limit 100', array(
        'zimucms_chengshi114_ranklist',
        $order
    ));
    
    foreach ($paihangdata as $key => $value) {
        $paihangdata[$key]             = DB::fetch_first('select * from %t where id=%d and status=2', array(
            'zimucms_chengshi114_shop',
            $value['yid']
        ));
        $paihangdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d and endtime>%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid'],
            time()
        ));
    }
    
    include template('zimucms_chengshi114:paihang');
    
} else if ($model == 'renmai') {
    $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
    $status = intval($status);
    
    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page   = intval($page);
    $start  = ($page - 1) * 10;
    $tonums = 10;
    if ($status == 1) {
        $renmaidata = DB::fetch_all('select * from %t where status=2 and sid!=0 order by click desc limit %d,%d', array(
            'zimucms_chengshi114_renmai',
            $start,
            $tonums
        ));
    } else if ($status == 2) {
        $renmaidata = DB::fetch_all('select * from %t where status=2 and sid=0 order by click desc limit %d,%d', array(
            'zimucms_chengshi114_renmai',
            $start,
            $tonums
        ));
    } else if ($status == 3) {
        $renmaidata = DB::fetch_all('select * from %t where status=2 and sid=0 and weixin_sex=2 order by click desc limit %d,%d', array(
            'zimucms_chengshi114_renmai',
            $start,
            $tonums
        ));
    } else if ($status == 4) {
        $renmaidata = DB::fetch_all('select * from %t where status=2 and sid=0 and weixin_sex=1 order by click desc limit %d,%d', array(
            'zimucms_chengshi114_renmai',
            $start,
            $tonums
        ));
    } else if ($status == 5) {
        $renmaidata = DB::fetch_all('select * from %t where status=2 order by click desc limit %d,%d', array(
            'zimucms_chengshi114_renmai',
            $start,
            $tonums
        ));
    }
    
    
    
    include template('zimucms_chengshi114:renmai');
    
} else if ($model == 'userindex') {
    
    isuid();
    
    $shopinfo = DB::fetch_first('select id from %t where uid=%d', array(
        'zimucms_chengshi114_shop',
        $_G['uid']
    ));
    
    $renmaiinfo = DB::result_first('select id from %t where uid=%d and sid=0', array(
        'zimucms_chengshi114_renmai',
        $_G['uid']
    ));
    
    include template('zimucms_chengshi114:userindex');

    //马甲APP支付
} else if ($model == 'magapp_pay' && $_GET['md5hash'] == $formhash) {

    $pay      = round($_GET['pay_money'], 2);

    $order_id = 'APP' . date('Ymd') . time();

    $sign = md5($order_id.$zmdata['magapp_secret']);

    $callback = urlencode($_G['siteurl'] . 'plugin.php?id=zimucms_chengshi114');

    $paytitle = lang('plugin/zimucms_chengshi114', 'system_text13');

if ($_G['charset'] == 'gbk') {
    $paytitle = iconv('gbk', 'utf-8', $paytitle);
}
    $urls = $zmdata['magapp_hostname'].'/core/pay/pay/unifiedOrder?trade_no='.$order_id.'&callback='.$callback.'&amount='.$pay.'&title='.$paytitle.'&user_id='.$_G['uid'].'&to_user_id=0&des='.$paytitle.'&remark='.$_G['username'].$_G['uid'].'&secret='.$zmdata['magapp_secret'];
    $r = dfsockopen($urls);
    
    $r =  json_decode($r, true);
    if(!intval($r['success'])){
        $out['status'] = 201;
        $out['errmsg'] = urlencode($r['msg']);
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit();
    }else{

        $out['status'] = 200;
        $out['errmsg'] = '';
        $out['orderNum'] = $order_id;
        $out['unionOrderNum'] = $r['data']['unionOrderNum'];
        $out['sign'] = $sign;
        $result        = json_encode($out);
        echo $result = urldecode($result);
        exit(); 
    }

} else if ($model == 'addshop') {
    
    if (IN_WECHAT) {
        $openid = zm_wechat_auth();
    }
    
    if (submitcheck('addshop')) {
        
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $shopdata['desc']      = strip_tags(zm_diconv($_GET['intro']));
        $shopdata['logo']      = strip_tags($_GET['icon']);
        $shopdata['thumb']     = strip_tags($_GET['img']);
        $shopdata['province']  = intval($_GET['shop']['province']);
        $shopdata['city']      = intval($_GET['shop']['city']);
        $shopdata['country']   = intval($_GET['shop']['country']);
        $shopdata['address']   = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']       = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']       = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']       = $_G['uid'];
        $shopdata['status']    = '1';
        $shopdata['addtime']   = $_G['timestamp'];
        $shopdata['viptime']   = '';
        $shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $result                = DB::insert('zimucms_chengshi114_shop', $shopdata, '1');
        
        if ($result) {
            
            $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $result,
                $_G['uid']
            ));
            
            if (!$isrenmai) {
                $renmaidata['sid']             = $result;
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }

            } else {
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
                $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $isrenmai
                ));
            }
            
            
            $token         = $wechat_client->getAccessToken(1, 1);
            
            $template = array(
                'touser' => $zmdata['manage_openid'],
                'template_id' => $zmdata['manage_mbid'],
                'url' => ZIMUCMS_URL . '&model=viewshop&sid=' . $result,
                'topcolor' => "#7B68EE",
                'data' => array(
                    'first' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text1'), CHARSET, 'utf-8')),
                        'color' => "#743A3A"
                    ),
                    'keyword1' => array(
                        'value' => urlencode(diconv($shopdata[name], CHARSET, 'utf-8'))
                    ),
                    'keyword2' => array(
                        'value' => urlencode(diconv($shopdata[lianxiren], CHARSET, 'utf-8'))
                    ),
                    'keyword3' => array(
                        'value' => urlencode($zmdata[site_jiage] . diconv(lang('plugin/zimucms_chengshi114', 'system_text2'), CHARSET, 'utf-8'))
                    ),
                    'keyword4' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text6'), CHARSET, 'utf-8')),
                        'color' => "#FF0000"
                    ),
                    'keyword5' => array(
                        'value' => urlencode(date("y-m-d H:i:s", time()))
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text4'), CHARSET, 'utf-8') . $shopdata[tel] . diconv(lang('plugin/zimucms_chengshi114', 'system_text7'), CHARSET, 'utf-8')),
                        'color' => "#008000"
                    )
                    
                )
            );
            $json     = urldecode(json_encode($template));
            $result   = send_weixintemplate($token, $json);
            
            
            
            dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
        } else {
            showmessage('error', '', array(), '');
        }
        

    } else if (submitcheck('alipaypay') && $_G['uid']) {


$out_trade_no = dgmdate(TIMESTAMP, 'YmdHis').random(18);  //创建支付订单号;

        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $shopdata['desc']      = strip_tags(zm_diconv($_GET['intro']));
        $shopdata['logo']      = strip_tags($_GET['icon']);
        $shopdata['thumb']     = strip_tags($_GET['img']);
        $shopdata['province']  = intval($_GET['shop']['province']);
        $shopdata['city']      = intval($_GET['shop']['city']);
        $shopdata['country']   = intval($_GET['shop']['country']);
        $shopdata['address']   = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']       = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']       = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']       = $_G['uid'];
        $shopdata['status']    = '1';
        $shopdata['addtime']   = $_G['timestamp'];
        $shopdata['viptime']   = time();
        $shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']     = $out_trade_no;
        $time_type       = intval($_GET['time_type']);
        $result                = DB::insert('zimucms_chengshi114_shop', $shopdata, '1');
        
        if ($result) {
            
            $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $result,
                $_G['uid']
            ));
            
            if (!$isrenmai) {
                $renmaidata['sid']             = $result;
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
            } else {
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
                $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $isrenmai
                ));
            }

        } 

$subject = lang('plugin/zimucms_chengshi114','system_text13');

        if ($time_type == 2) {
            $price = $zmdata['site_jiage2'];
        } else {
            $price = $zmdata['site_jiage'];
        }
//开始支付宝支付操作
    if($_G['mobile'] && $_G['cache']['plugin']['zimucms_chengshi114']['is_alipay']){
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        $alipay_config['partner']       = $ec_partner;
        $alipay_config['seller_id'] = $alipay_config['partner'];
        $alipay_config['key']           = $ec_securitycode;
        $alipay_config['notify_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php';
        $alipay_config['return_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php';
        $alipay_config['sign_type']    = strtoupper('MD5');
        //字符编码格式 目前支持utf-8
        $alipay_config['input_charset']= strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = getcwd().'\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';
        $alipay_config['payment_type'] = "1";
        $alipay_config['service'] = "alipay.wap.create.direct.pay.by.user";
        require_once("source/plugin/zimucms_chengshi114/class/alipay_submit.class.php");
        
        //商户订单号，商户网站订单系统中唯一订单号，必填

        //订单名称，必填
        if($_G['charset']=='gbk'){
            if(mb_strlen($subject,'gbk')>10){
                $subject = mb_substr($subject,0,10,'gbk');
            }
            $subject = iconv('gbk','utf-8',$subject);
        }else{
            if(mb_strlen($subject,'utf-8')>10){
                $subject = mb_substr($subject,0,10,'utf-8');
            }
        }

        //付款金额，必填
        $total_fee = $price;

        //收银台页面上，商品展示的超链接，必填
        $show_url = $_G['siteurl'].'/plugin.php?id=zimucms_chengshi114&model=shoplist';

        //商品描述，可空
        $body = '';
        $parameter = array(
                "service"       => $alipay_config['service'],
                "partner"       => $alipay_config['partner'],
                "seller_id"  => $alipay_config['seller_id'],
                "payment_type"  => $alipay_config['payment_type'],
                "notify_url"    => $alipay_config['notify_url'],
                "return_url"    => $alipay_config['return_url'],
                "_input_charset"    => trim(strtolower($alipay_config['input_charset'])),
                "out_trade_no"  => $out_trade_no,
                "subject"   => $subject,
                "total_fee" => $total_fee,
                "show_url"  => $show_url,
                "body"  => $body,
                //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.2Z6TSk&treeId=60&articleId=103693&docType=1
                //如"参数名"    => "参数值"   注：上一个参数末尾需要“,”逗号。
                
        );
        //print_r($alipay_config);
        //exit();
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter,"get",lang('plugin/zimucms_chengshi114', 'system_text14'));
        echo $html_text;
        exit();
    }else{
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        define('DISCUZ_PARTNER', $ec_partner);
        define('DISCUZ_SECURITYCODE', $ec_securitycode);
        define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
        define('STATUS_SELLER_SEND', 4);
        define('STATUS_WAIT_BUYER', 5);
        define('STATUS_TRADE_SUCCESS', 7);
        define('STATUS_REFUND_CLOSE', 17);
        
        $args = array(
          'subject'     => $_G['member']['username'].' '.$subject.' '.lang('plugin/zimucms_chengshi114', 'system_text13'),
          'body'      => 'chengshi114UID'.$_G['uid'].'SID'.$shopdata['id'].'/'.$_G['clientip'],
          'service'     => 'trade_create_by_buyer',
          'partner'     => DISCUZ_PARTNER,
          'notify_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php',
          'return_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php',
          'show_url'    => $_G['siteurl'],
          '_input_charset'  => CHARSET,
          'out_trade_no'    => $out_trade_no,
          'price'     => $price,
          'quantity'    => 1,
          'seller_email'    => $_G['setting']['ec_account'],
          'sid'  => $shopdata['id'],
        );
        if(DISCUZ_DIRECTPAY) {
          $args['service'] = 'create_direct_pay_by_user';
          $args['payment_type'] = '1';
        } else {
          $args['logistics_type'] = 'EXPRESS';
          $args['logistics_fee'] = 0;
          $args['logistics_payment'] = 'SELLER_PAY';
          $args['payment_type'] = 1;
        }
        ksort($args);
        $urlstr = $sign = '';
        foreach($args as $key => $val) {
            $sign .= '&'.$key.'='.$val;
            $urlstr .= $key.'='.rawurlencode($val).'&';
        }
        $sign = substr($sign, 1);
        $sign = md5($sign.DISCUZ_SECURITYCODE);
        header('Location: https://www.alipay.com/cooperate/gateway.do?'.$urlstr.'sign='.$sign.'&sign_type=MD5');
    }

    } else if (submitcheck('weixinpay') && $_G['uid']) {
        
        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
        $shopdata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
        $shopdata['weixin_sex']      = intval($_GET['wei_sex']);
        $shopdata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
        $shopdata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
        $shopdata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
        $shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['time_type']       = intval($_GET['time_type']);

        if (IN_WECHAT) {
            $openid = zm_wechat_auth(1);
        }

        include DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/wxpay.class.php';
        $input               = new WxPayData();
        $input->body         = diconv(cutstr($shopdata['name'], 32, ''), CHARSET, 'utf-8');
        $input->out_trade_no = date('YmdHis') . str_pad(mt_rand(1000000, 9999999), 7, '0', STR_PAD_LEFT);
        if ($shopdata['time_type'] == 2) {
            $input->total_fee = intval($zmdata['site_jiage2'] * 100);
        } else {
            $input->total_fee = intval($zmdata['site_jiage'] * 100);
        }
        $input->time_start  = date('YmdHis');
        $input->time_expire = date('YmdHis', TIMESTAMP + 600);
        $input->notify_url  = ZIMUCMS_URL . '&model=tuisongmoban';
        
        $input->product_id = diconv($shopdata['name'], CHARSET, 'utf-8') . $_G['uid'];
        $input->fromtype   = 'CHENGSHI114';
        $input->fromid     = '1111';
        $input->openid     = $openid;
        $input->trade_type = 'JSAPI';
        
        try {
            $jsPay  = new JsApiPay();
            $result = WxPayApi::unifiedOrder($input);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        //$result = diconv($result, 'utf-8', CHARSET);
        
        if ($result['return_code'] == 'FAIL') {
            showmessage($result['return_msg']);
        }
        
        if ($result['result_code'] == 'FAIL') {
            showmessage($result['err_code_des']);
        }
        try {
            $wxpay = $jsPay->getJsApiParameters($result);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        $wxpay = json_decode($wxpay);
        $wxpay = object_array($wxpay);
        
        include template('zimucms_chengshi114:weixinpay');


    } else if (submitcheck('qfapppay') && $_G['uid']) {

        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $time_type       = intval($_GET['time_type']);
        $shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']    = strip_tags($_GET['qfpayid']);



        $out_trade_no = strip_tags($_GET['qfpayid']);
        $nonce  = qf_nonce();
        $secret = $zmdata['qf_secret'];

        $data = array(
            'order_id' => $out_trade_no,
            'nonce' => $nonce
            );

        $data['sign'] = qf_sign($data, $secret);
        $r            = http_build_query($data);

        $qfurl = 'http://' . $zmdata['qf_hostname'] . '.qianfanapi.com/api1_2/orders/query?' . $r;
        $qfdata = dfsockopen($qfurl);
        if (!$qfdata) {
            $qfdata = file_get_contents($qfurl);
        }

        if ($retqf = json_decode($qfdata, true)) {
            if ($retqf['data'][$out_trade_no]['result'] == 1 || $retqf['data'][$out_trade_no]['result'] == 2) {

                    $shopdata['ispay']    = '2';
                    $shopdata['addtime']  = $_G['timestamp'];
                    $shopdata['viptime']  = $_G['timestamp'];
                    $shopdata['endtime']  = $_G['timestamp'] + 31536000 * $time_type;
                    $shopdata['status']   = '2';
                    $result                = DB::insert('zimucms_chengshi114_shop', $shopdata, '1');

                    $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                        'zimucms_chengshi114_renmai',
                        $result,
                        $_G['uid']
                        ));

                    if (!$isrenmai) {
                        $renmaidata['sid']             = $result;
                        $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                        $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                        $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                        $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                        $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                        $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                        $renmaidata['uid']             = $_G['uid'];
                        $renmaidata['status']          = '2';
                        if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                            $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
                        }
                    } else {
                        $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                        $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                        $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                        $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                        $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                        $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                        $renmaidata['uid']             = $_G['uid'];
                        $renmaidata['status']          = '2';
                        $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                            'id' => $isrenmai
                            ));
                    }
                    dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
            }
        }



    } else if (submitcheck('magapppay') && $_G['uid']) {


        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $time_type       = intval($_GET['time_type']);
        $shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']    = strip_tags($_GET['unionOrderNum']);

    $orderNum    = addslashes($_GET['orderNum']);
    $unionOrderNum    = addslashes($_GET['unionOrderNum']);
    $sign    = addslashes($_GET['magappsign']);
    $mysign = md5($orderNum.$zmdata['magapp_secret']);
    if($sign!=$mysign){
        echo'sign is error!';exit();
    }

        $retfrom = dfsockopen($zmdata['magapp_hostname']."/core/pay/pay/orderStatusQuery?unionOrderNum=".$unionOrderNum."&secret=".$zmdata['magapp_secret']);

        if($retma = json_decode($retfrom, true)){
            if($retma['paycode'] == 1){

        $shopdata['ispay']    = '2';
        $shopdata['addtime']   = $_G['timestamp'];
        $shopdata['viptime']  = $_G['timestamp'];
        $shopdata['endtime']  = $_G['timestamp'] + 31536000 * $time_type;
        $shopdata['status']   = '2';
        $result                = DB::insert('zimucms_chengshi114_shop', $shopdata, '1');
        
        $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
            'zimucms_chengshi114_renmai',
            $result,
            $_G['uid']
        ));
        
        if (!$isrenmai) {
            $renmaidata['sid']             = $result;
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
        } else {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                'id' => $isrenmai
                ));
        }

     dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');

     
            }
        }


 
    } else if (submitcheck('appweixinpay') && $_G['uid']) {
        
        
        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
        $shopdata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
        $shopdata['weixin_sex']      = intval($_GET['wei_sex']);
        $shopdata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
        $shopdata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
        $shopdata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
        $shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['time_type']       = intval($_GET['time_type']);
        
        
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/lib/WxPay.Api.php";
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/source/WxPay.AppPay.php";
        
        
        $notify    = new AppPay();
        $order_sn  = date('YmdHis') . str_pad(mt_rand(1000000, 9999999), 7, '0', STR_PAD_LEFT);
        $inputbody = diconv(cutstr($shopdata['name'], 32, ''), CHARSET, 'utf-8');
        if ($shopdata['time_type'] == 2) {
            $inputtotal_fee = intval($zmdata['site_jiage2'] * 100);
        } else {
            $inputtotal_fee = intval($zmdata['site_jiage'] * 100);
        }
        $input = new WxPayUnifiedOrder();
        $input->SetBody($inputbody);
        $input->SetOut_trade_no($order_sn);
        $input->SetTotal_fee($inputtotal_fee);
        $input->SetNotify_url(ZIMUCMS_URL . '&model=tuisongmoban');
        $input->SetTrade_type("APP");
        $order            = WxPayApi::unifiedOrder($input);
        $appApiParameters = $notify->GetAppApiParameters($order);
        
        $wxpay = json_decode($appApiParameters);
        $wxpay = object_array($wxpay);
        
        include template('zimucms_chengshi114:weixinpay');
        
    } else {
        if ($_G['uid']) {
            $pids = DB::fetch_all('select id,name as text from %t where cid=0 order by sort asc,id asc', array(
                'zimucms_chengshi114_cat'
            ));
            foreach ($pids as $key => $value) {
                $pids[$key]['text']     = urlencode($pids[$key]['text']);
                $pids[$key]['value']    = $pids[$key]['id'];
                $pids[$key]['children'] = DB::fetch_all('select id,name as text from %t where cid=%d order by sort asc,id asc', array(
                    'zimucms_chengshi114_cat',
                    $pids[$key]['id']
                ));
                foreach ($pids[$key]['children'] as $key2 => $value) {
                    $pids[$key]['children'][$key2]['text']  = urlencode($pids[$key]['children'][$key2]['text']);
                    $pids[$key]['children'][$key2]['value'] = $pids[$key]['children'][$key2]['id'];
                }
            }
            $catdata = json_encode($pids);
            $catdata = urldecode($catdata);
            
            include template('zimucms_chengshi114:addshop');
        } else {
            echo '&#x8BF7;&#x767B;&#x5F55;&#x540E;&#x64CD;&#x4F5C;&#xFF01;';
        }
    }
    
} else if ($model == 'editshop') {
    
    if (submitcheck('editshop') && $_G['uid']) {
        
        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']    = strip_tags($_GET['icon']);
        $shopdata['thumb']   = strip_tags($_GET['img']);
        //$shopdata['province']  = intval($_GET['shop']['province']);
        //$shopdata['city']      = intval($_GET['shop']['city']);
        //$shopdata['country']   = intval($_GET['shop']['country']);
        $shopdata['address'] = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']     = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']     = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']     = $_G['uid'];
        //$shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        
        $result = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id'],
            'uid' => $shopdata['uid']
        ));
        
        
        if ($shopdata['id']) {
            $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $shopdata['id'],
                $_G['uid']
            ));
            
            if (!$isrenmai) {
                $renmaidata['sid']             = $shopdata['id'];
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
            } else {
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
                $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $isrenmai
                ));
            }
            dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
        } else {
            dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
        }

    } else if (submitcheck('alipaypay') && $_G['uid']) {

$out_trade_no = dgmdate(TIMESTAMP, 'YmdHis').random(18);  //创建支付订单号;

        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']    = strip_tags($_GET['icon']);
        $shopdata['thumb']   = strip_tags($_GET['img']);
        //$shopdata['province']  = intval($_GET['shop']['province']);
        //$shopdata['city']      = intval($_GET['shop']['city']);
        //$shopdata['country']   = intval($_GET['shop']['country']);
        $shopdata['address'] = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']     = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']     = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']     = $_G['uid'];
        //$shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']     = $out_trade_no;
        $time_type       = intval($_GET['time_type']);
        $result = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id'],
            'uid' => $shopdata['uid']
        ));
        
        
        if ($shopdata['id']) {
            $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $shopdata['id'],
                $_G['uid']
            ));
            if (!$isrenmai) {
                $renmaidata['sid']             = $shopdata['id'];
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
            } else {
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
                $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $isrenmai
                ));
            }
        }

$subject = lang('plugin/zimucms_chengshi114','system_text13');

        if ($time_type == 2) {
            $price = $zmdata['site_jiage2'];
        } else {
            $price = $zmdata['site_jiage'];
        }
//开始支付宝支付操作
    if($_G['mobile'] && $_G['cache']['plugin']['zimucms_chengshi114']['is_alipay']){
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        $alipay_config['partner']       = $ec_partner;
        $alipay_config['seller_id'] = $alipay_config['partner'];
        $alipay_config['key']           = $ec_securitycode;
        $alipay_config['notify_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php';
        $alipay_config['return_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php';
        $alipay_config['sign_type']    = strtoupper('MD5');
        //字符编码格式 目前支持utf-8
        $alipay_config['input_charset']= strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = getcwd().'\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';
        $alipay_config['payment_type'] = "1";
        $alipay_config['service'] = "alipay.wap.create.direct.pay.by.user";
        require_once("source/plugin/zimucms_chengshi114/class/alipay_submit.class.php");
        
        //商户订单号，商户网站订单系统中唯一订单号，必填

        //订单名称，必填
        if($_G['charset']=='gbk'){
            if(mb_strlen($subject,'gbk')>10){
                $subject = mb_substr($subject,0,10,'gbk');
            }
            $subject = iconv('gbk','utf-8',$subject);
        }else{
            if(mb_strlen($subject,'utf-8')>10){
                $subject = mb_substr($subject,0,10,'utf-8');
            }
        }

        //付款金额，必填
        $total_fee = $price;

        //收银台页面上，商品展示的超链接，必填
        $show_url = $_G['siteurl'].'/plugin.php?id=zimucms_chengshi114&model=shoplist';

        //商品描述，可空
        $body = '';
        $parameter = array(
                "service"       => $alipay_config['service'],
                "partner"       => $alipay_config['partner'],
                "seller_id"  => $alipay_config['seller_id'],
                "payment_type"  => $alipay_config['payment_type'],
                "notify_url"    => $alipay_config['notify_url'],
                "return_url"    => $alipay_config['return_url'],
                "_input_charset"    => trim(strtolower($alipay_config['input_charset'])),
                "out_trade_no"  => $out_trade_no,
                "subject"   => $subject,
                "total_fee" => $total_fee,
                "show_url"  => $show_url,
                "body"  => $body,
                "sid"  => $shopdata['id'],
                //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.2Z6TSk&treeId=60&articleId=103693&docType=1
                //如"参数名"    => "参数值"   注：上一个参数末尾需要“,”逗号。
                
        );
        //print_r($alipay_config);
        //exit();
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter,"get", "true");
        echo $html_text;
        exit();
    }else{
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        define('DISCUZ_PARTNER', $ec_partner);
        define('DISCUZ_SECURITYCODE', $ec_securitycode);
        define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
        define('STATUS_SELLER_SEND', 4);
        define('STATUS_WAIT_BUYER', 5);
        define('STATUS_TRADE_SUCCESS', 7);
        define('STATUS_REFUND_CLOSE', 17);
        
        $args = array(
          'subject'     => $_G['member']['username'].' '.$subject.' '.lang('plugin/zimucms_chengshi114', 'system_text13'),
          'body'      => 'chengshi114UID'.$_G['uid'].'SID'.$shopdata['id'].'/'.$_G['clientip'],
          'service'     => 'trade_create_by_buyer',
          'partner'     => DISCUZ_PARTNER,
          'notify_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php',
          'return_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_notify.php',
          'show_url'    => $_G['siteurl'],
          '_input_charset'  => CHARSET,
          'out_trade_no'    => $out_trade_no,
          'price'     => $price,
          'quantity'    => 1,
          'seller_email'    => $_G['setting']['ec_account'],
          'sid'  => $shopdata['id'],
        );
        if(DISCUZ_DIRECTPAY) {
          $args['service'] = 'create_direct_pay_by_user';
          $args['payment_type'] = '1';
        } else {
          $args['logistics_type'] = 'EXPRESS';
          $args['logistics_fee'] = 0;
          $args['logistics_payment'] = 'SELLER_PAY';
          $args['payment_type'] = 1;
        }
        ksort($args);
        $urlstr = $sign = '';
        foreach($args as $key => $val) {
            $sign .= '&'.$key.'='.$val;
            $urlstr .= $key.'='.rawurlencode($val).'&';
        }
        $sign = substr($sign, 1);
        $sign = md5($sign.DISCUZ_SECURITYCODE);
        header('Location: https://www.alipay.com/cooperate/gateway.do?'.$urlstr.'sign='.$sign.'&sign_type=MD5');
    }


        
    } else if (submitcheck('weixinpay') && $_G['uid']) {
        
        
        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
        $shopdata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
        $shopdata['weixin_sex']      = intval($_GET['wei_sex']);
        $shopdata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
        $shopdata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
        $shopdata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['time_type']       = intval($_GET['time_type']);
        //$shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        
        if (IN_WECHAT) {
            $openid = zm_wechat_auth();
        }
        include DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/wxpay.class.php';
        $input = new WxPayData();
        
        $input->body         = diconv(cutstr($shopdata['name'], 32, ''), CHARSET, 'utf-8');
        $input->out_trade_no = date('YmdHis') . str_pad(mt_rand(1000000, 9999999), 7, '0', STR_PAD_LEFT);
        if ($shopdata['time_type'] == 2) {
            $input->total_fee = intval($zmdata['site_jiage2'] * 100);
        } else {
            $input->total_fee = intval($zmdata['site_jiage'] * 100);
        }
        $input->time_start  = date('YmdHis');
        $input->time_expire = date('YmdHis', TIMESTAMP + 600);
        $input->notify_url  = ZIMUCMS_URL . '&model=tuisongmoban';
        
        $input->product_id = diconv($shopdata['name'], CHARSET, 'utf-8') . $_G['uid'];
        $input->fromtype   = 'CHENGSHI114';
        $input->fromid     = '1111';
        $input->openid     = $openid;
        $input->trade_type = 'JSAPI';
        
        try {
            $jsPay  = new JsApiPay();
            $result = WxPayApi::unifiedOrder($input);
        }
        catch (WxPayException $e) {
            showmessage(zm_diconv($e->errorMessage()));
        }
        
        if ($result['return_code'] == 'FAIL') {
            showmessage(zm_diconv($result['return_msg']));
        }
        
        if ($result['result_code'] == 'FAIL') {
            showmessage(zm_diconv($result['err_code_des']));
        }
        try {
            $wxpay = $jsPay->getJsApiParameters($result);
        }
        catch (WxPayException $e) {
            showmessage(zm_diconv($e->errorMessage()));
        }
        
        $wxpay = json_decode($wxpay);
        $wxpay = object_array($wxpay);
        
        include template('zimucms_chengshi114:weixinpay');
        
    } else if (submitcheck('qfapppay') && $_G['uid']) {


        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $time_type       = intval($_GET['time_type']);
        //$shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']    = strip_tags($_GET['qfpayid']);



        $out_trade_no = strip_tags($_GET['qfpayid']);
    $nonce  = qf_nonce();
    $secret = $zmdata['qf_secret'];
    
    $data = array(
        'order_id' => $out_trade_no,
        'nonce' => $nonce
    );
    
    $data['sign'] = qf_sign($data, $secret);
    $r            = http_build_query($data);
    
    $qfurl = 'http://' . $zmdata['qf_hostname'] . '.qianfanapi.com/api1_2/orders/query?' . $r;
    $qfdata = dfsockopen($qfurl);
    if (!$qfdata) {
        $qfdata = file_get_contents($qfurl);
    }

    if ($retqf = json_decode($qfdata, true)) {
        if ($retqf['data'][$out_trade_no]['result'] == 1 || $retqf['data'][$out_trade_no]['result'] == 2) {
            
            $paylogdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimucms_chengshi114_shop',
                $shopdata['id']
            ));
            
            if ($paylogdata['out_trade_no'] != $out_trade_no) {
 


        $shopdata['ispay']    = '2';
        $shopdata['viptime']  = $_G['timestamp'];
        $shopdata['endtime']  = $_G['timestamp'] + 31536000 * $time_type;
        $shopdata['status']   = '2';
        //$shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $result               = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id'],
            'uid' => $shopdata['uid']
        ));
        
        $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
            'zimucms_chengshi114_renmai',
            $shopdata['id'],
            $_G['uid']
        ));
        
        if (!$isrenmai) {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
        } else {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                'id' => $isrenmai
                ));
        }

     dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
                
            }else{

dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
            }
            
            
        }
    }

    } else if (submitcheck('magapppay') && $_G['uid']) {


        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $time_type       = intval($_GET['time_type']);
        //$shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        $shopdata['out_trade_no']    = strip_tags($_GET['unionOrderNum']);

    $orderNum    = addslashes($_GET['orderNum']);
    $unionOrderNum    = addslashes($_GET['unionOrderNum']);
    $sign    = addslashes($_GET['magappsign']);
    $mysign = md5($orderNum.$zmdata['magapp_secret']);
    if($sign!=$mysign){
        echo'sign is error!';exit();
    }

        $retfrom = dfsockopen($zmdata['magapp_hostname']."/core/pay/pay/orderStatusQuery?unionOrderNum=".$unionOrderNum."&secret=".$zmdata['magapp_secret']);

        if($retma = json_decode($retfrom, true)){
            if($retma['paycode'] == 1){

            $paylogdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimucms_chengshi114_shop',
                $shopdata['id']
            ));

            if ($paylogdata['out_trade_no'] != $unionOrderNum) {
 


        $shopdata['ispay']    = '2';
        $shopdata['viptime']  = $_G['timestamp'];
        $shopdata['endtime']  = $_G['timestamp'] + 31536000 * $time_type;
        $shopdata['status']   = '2';
        //$shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $result               = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id'],
            'uid' => $shopdata['uid']
        ));
        
        $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
            'zimucms_chengshi114_renmai',
            $shopdata['id'],
            $_G['uid']
        ));
        
        if (!$isrenmai) {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
        } else {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                'id' => $isrenmai
                ));
        }

     dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
                
            }else{

dheader('Location:' . ZIMUCMS_URL . '&model=shoplist');
            }

     
            }
        }




    } else if (submitcheck('appweixinpay') && $_G['uid']) {
        
        
        $shopdata['id']        = intval($_GET['sid']);
        $shopdata['typeid1']   = intval($_GET['shop']['cat_id']);
        $shopdata['typeid2']   = intval($_GET['shop']['child_id']);
        $shopdata['name']      = strip_tags(zm_diconv($_GET['title']));
        $shopdata['lianxiren'] = strip_tags(zm_diconv($_GET['s_name']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = strip_tags(zm_diconv($_GET['breaks']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['intro']));
        }
        $shopdata['logo']            = strip_tags($_GET['icon']);
        $shopdata['thumb']           = strip_tags($_GET['img']);
        $shopdata['province']        = intval($_GET['shop']['province']);
        $shopdata['city']            = intval($_GET['shop']['city']);
        $shopdata['country']         = intval($_GET['shop']['country']);
        $shopdata['address']         = strip_tags(zm_diconv($_GET['shop']['address']));
        $shopdata['lat']             = strip_tags($_GET['shop']['lat']);
        $shopdata['lng']             = strip_tags($_GET['shop']['lng']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
        $shopdata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
        $shopdata['weixin_sex']      = intval($_GET['wei_sex']);
        $shopdata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
        $shopdata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
        $shopdata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
        $shopdata['uid']             = $_G['uid'];
        $shopdata['time_type']       = intval($_GET['time_type']);
        //$shopdata['yewuyuan']        = intval($_GET['yewuyuan']);
        
        
        
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/lib/WxPay.Api.php";
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/source/WxPay.AppPay.php";
        
        
        $notify    = new AppPay();
        $order_sn  = date('YmdHis') . str_pad(mt_rand(1000000, 9999999), 7, '0', STR_PAD_LEFT);
        $inputbody = diconv(cutstr($shopdata['name'], 32, ''), CHARSET, 'utf-8');
        if ($shopdata['time_type'] == 2) {
            $inputtotal_fee = intval($zmdata['site_jiage2'] * 100);
        } else {
            $inputtotal_fee = intval($zmdata['site_jiage'] * 100);
        }
        $input = new WxPayUnifiedOrder();
        $input->SetBody($inputbody);
        $input->SetOut_trade_no($order_sn);
        $input->SetTotal_fee($inputtotal_fee);
        $input->SetNotify_url(ZIMUCMS_URL . '&model=tuisongmoban');
        $input->SetTrade_type("APP");
        $order            = WxPayApi::unifiedOrder($input);
        $appApiParameters = $notify->GetAppApiParameters($order);
        
        $wxpay = json_decode($appApiParameters);
        $wxpay = object_array($wxpay);
        include template('zimucms_chengshi114:weixinpay');
        
    } else {
        
        if (IN_WECHAT) {
            $openid = zm_wechat_auth();
        }
        
        if ($_G['uid']) {
            $pids = DB::fetch_all('select id,name as text from %t where cid=0 order by sort asc,id asc', array(
                'zimucms_chengshi114_cat'
            ));
            foreach ($pids as $key => $value) {
                $pids[$key]['text']     = urlencode($pids[$key]['text']);
                $pids[$key]['value']    = $pids[$key]['id'];
                $pids[$key]['children'] = DB::fetch_all('select id,name as text from %t where cid=%d order by sort asc,id asc', array(
                    'zimucms_chengshi114_cat',
                    $pids[$key]['id']
                ));
                foreach ($pids[$key]['children'] as $key2 => $value) {
                    $pids[$key]['children'][$key2]['text']  = urlencode($pids[$key]['children'][$key2]['text']);
                    $pids[$key]['children'][$key2]['value'] = $pids[$key]['children'][$key2]['id'];
                }
            }
            //print_r($pids);exit();
            $catdata = json_encode($pids);
            $catdata = urldecode($catdata);
            
            
            
            $quyu = DB::fetch_all('select id,name as text from %t where level=1 order by displayorder asc', array(
                'common_district'
            ));
            foreach ($quyu as $key => $value) {
                $quyu[$key]['text']     = urlencode($quyu[$key]['text']);
                $quyu[$key]['value']    = $quyu[$key]['id'];
                $quyu[$key]['children'] = DB::fetch_all('select id,name as text from %t where level=2 and upid=%d', array(
                    'common_district',
                    $quyu[$key]['id']
                ));
                foreach ($quyu[$key]['children'] as $key2 => $value) {
                    $quyu[$key]['children'][$key2]['text']     = urlencode($quyu[$key]['children'][$key2]['text']);
                    $quyu[$key]['children'][$key2]['value']    = $quyu[$key]['children'][$key2]['id'];
                    $quyu[$key]['children'][$key2]['children'] = DB::fetch_all('select id,name as text from %t where level=3 and upid=%d', array(
                        'common_district',
                        $quyu[$key]['children'][$key2]['id']
                    ));
                    
                    foreach ($quyu[$key]['children'][$key2]['children'] as $key3 => $value3) {
                        $quyu[$key]['children'][$key2]['children'][$key3]['text']  = urlencode($quyu[$key]['children'][$key2]['children'][$key3]['text']);
                        $quyu[$key]['children'][$key2]['children'][$key3]['value'] = $quyu[$key]['children'][$key2]['children'][$key3]['id'];
                    }
                    
                }
            }
            $quyuata = json_encode($quyu);
            $quyuata = urldecode($quyuata);
            
            $sid        = intval($_GET['sid']);
            $shopdata   = DB::fetch_first('select * from %t where id=%d', array(
                'zimucms_chengshi114_shop',
                $sid
            ));
            $renmaidata = DB::fetch_first('select * from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $sid,
                $_G['uid']
            ));
            include template('zimucms_chengshi114:addshop');
        } else {
            dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&mobile=2&referer=' . ZIMUCMS_URL);
        }
    }
    
} else if ($model == 'editshoppic') {
    isuid();
    $sid     = intval($_GET['sid']);
    $shoppic = DB::fetch_all('select * from %t where sid=%d and uid=%d order by id asc', array(
        'zimucms_chengshi114_shoppic',
        $sid,
        $_G['uid']
    ));
    for ($i = 1; $i <= $zmdata['shop_picnums']; $i++) {
        $loadimg[$i]        = $shoppic[$i - 1];
        $loadimg[$i]['num'] = $i;
    }
    include template('zimucms_chengshi114:editshoppic');
} else if ($model == 'upshopimg' && $_GET['formhash'] == formhash()) {
    isuid();
    $type  = strip_tags($_GET['type']);
    $sid   = intval($_GET['sid']);
    $field = strip_tags($_GET['field']);
    $title = strip_tags(zm_diconv($_GET['text']));
    
    if (empty($_FILES['file'])) {
        return -1;
    } else {
        $picnurl = zm_saveimages($_FILES['file']);
        if ($picnurl) {
            $shoppic = array(
                'uid' => $_G['uid'],
                'sid' => $sid,
                'imgurl' => $picnurl,
                'title' => $title,
                'createtime' => TIMESTAMP
            );
            $result  = DB::insert('zimucms_chengshi114_shoppic', $shoppic);
            if ($result) {
                $res = array(
                    'error' => 0,
                    'data' => $field,
                    'extend' => array(
                        'type' => $type,
                        'url' => $picnurl
                    )
                );
                echo '<html><body>' . json_encode($res) . '</body></html>';
                exit();
            }
        } else {
            return -1;
        }
    }
    
} else if ($model == 'delshopimg' && $_GET['formhash'] == formhash()) {
    isuid();
    $imgid  = intval($_GET['imgid']);
    $sid    = intval($_GET['sid']);
    $result = DB::delete('zimucms_chengshi114_shoppic', array(
        'sid' => $sid,
        'id' => $imgid
    ));
    
    $res = array(
        'error' => 0,
        'data' => '',
        'extend' => array()
        
    );
    echo json_encode($res);
    
    exit();
    
} else if ($model == 'shoplist') {
    if ($_G['uid']) {
        $shoplist = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
            'zimucms_chengshi114_shop',
            $_G['uid']
        ));
        include template('zimucms_chengshi114:shoplist');
    } else {
        dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&mobile=2&referer=' . ZIMUCMS_URL);
    }
    
} else if ($model == 'addrenmai') {
    isuid();
    if (submitcheck('addrenmai')) {
        $isrenmai = DB::result_first('select id from %t where sid=0 and uid=%d', array(
            'zimucms_chengshi114_renmai',
            $_G['uid']
        ));
        if (!$isrenmai) {
            $renmaidata['sid']             = 0;
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $result                        = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
        }
        dheader('Location:' . ZIMUCMS_URL . '&model=renmailist');
    } else {
        include template('zimucms_chengshi114:renmaiedit');
    }
} else if ($model == 'renmaiedit') {
    isuid();
    if (submitcheck('renmaiedit')) {
        $rid = intval($_GET['rid']);
        $sid = intval($_GET['sid']);
        if ($rid && $sid) {
            $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
            $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
            $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
            $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
            $renmaidata['uid']             = $_G['uid'];
            $result                        = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                'id' => $rid,
                'sid' => $sid,
                'uid' => $_G['uid']
            ));
        } else {
            if ($rid && !$sid) {
                $renmaidata['weixin_id']       = strip_tags(zm_diconv($_GET['wei_num']));
                $renmaidata['weixin_name']     = strip_tags(zm_diconv($_GET['wei_name']));
                $renmaidata['weixin_sex']      = intval($_GET['wei_sex']);
                $renmaidata['weixin_desc']     = strip_tags(zm_diconv($_GET['wei_intro']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['wei_avatar']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['wei_ewm']);
                $renmaidata['uid']             = $_G['uid'];
                $renmaidata['sid']             = '0';
                $result                        = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $rid,
                    'uid' => $_G['uid']
                ));
            }
        }
        dheader('Location:' . ZIMUCMS_URL . '&model=renmailist');
    } else {
        $rid        = intval($_GET['rid']);
        $renmaiinfo = DB::fetch_first('select * from %t where uid=%d and id=%d', array(
            'zimucms_chengshi114_renmai',
            $_G['uid'],
            $rid
        ));
        include template('zimucms_chengshi114:renmaiedit');
    }
} else if ($model == 'renmailist') {
    isuid();
    $renmaidata = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimucms_chengshi114_renmai',
        $_G['uid']
    ));
    foreach ($renmaidata as $key => $value) {
        if ($value['sid']) {
            $renmaidata[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
                'zimucms_chengshi114_shop',
                $value['sid']
            ));
        }
    }
    include template('zimucms_chengshi114:renmailist');
    
} else if ($model == 'imgload' && $_GET['FORM_HASH'] == formhash()) {
    
    $filename = TIMESTAMP . rand(0, 100) . ".jpg";
    $type     = strip_tags($_GET['type']);
    $upload   = strip_tags($_GET['upload']);
    $imgDir   = ZIMUCMS_ROOT . '/public/upload/renmai/' . date("Ymd") . '/';
    if (!file_exists(dirname(__FILE__) . '/public/upload/renmai/' . date("Ymd"))) {
        mkdir(dirname(__FILE__) . '/public/upload/renmai/' . date("Ymd"));
    }
    preg_match('/(?<=base64,)[\S|\s]+/', $upload, $streamForW);
    $jpg = $streamForW[0];
    if (empty($jpg)) {
        echo 'nostream';
        exit();
    }
    $jpg  = base64_decode($jpg);
    $file = fopen($imgDir . $filename, "w");
    fwrite($file, $jpg);
    fclose($file);
    $filePath = $imgDir . $filename;
    if (!file_exists($filePath)) {
        echo 'createFail';
        exit();
    }

    if($zmdata['ACCESS_ID'] && $zmdata['ACCESS_KEY'] && $zmdata['ENDPOINT'] && $zmdata['BUCKET']){
        $saved_file = $filePath;
        include_once DISCUZ_ROOT.'source/plugin/zimucms_chengshi114/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimucms_chengshi114/'.$filename, $saved_file)) {
            @unlink($saved_file);
    $res = array(
        'error' => 0,
        'data' => '',
        'extend' => array(
            'type' => $type,
            'url' => $surl
        )
        
    );
    echo json_encode($res);
    exit();
        }
    }

    $res = array(
        'error' => 0,
        'data' => '',
        'extend' => array(
            'type' => $type,
            'url' => ZIMUCMS_PATH . '/public/upload/renmai/' . date("Ymd") . '/' . $filename
        )
        
    );
    echo json_encode($res);
    exit();
    
} else if ($model == 'search') {
    
    $type   = $_GET['type'] = $_GET['type'] ? $_GET['type'] : 1;
    $type   = intval($type);
    $search = strip_tags(zm_diconv($_GET['search']));
    if (!$search) {
        $search = strip_tags(zm_diconv($_GET['search']));
    }
    //新增审核修改
    $search = dhtmlspecialchars($search);
    $search = stripsearchkey($search);
    $search = daddslashes($search);
    
    if ($type == 1) {
        
        $shopdata = DB::fetch_all("select * from %t where status=2 and (name like %s or `desc` like %s or address like %s) limit 100", array(
            'zimucms_chengshi114_shop',
            '%' . $search . '%',
            '%' . $search . '%',
            '%' . $search . '%'
        ));
        
    } else {
        
        $renmaidata = DB::fetch_all("select * from %t where status=2 and (weixin_name like %s or weixin_desc like %s) limit 100", array(
            'zimucms_chengshi114_renmai',
            '%' . $search . '%',
            '%' . $search . '%'
        ));
        
        
    }
    include template('zimucms_chengshi114:search');
    
    
} else if ($model == 'weixinpaysuccess' && $_GET['formhash'] == $formhash) {
    
    $type = strip_tags($_GET['type']);
    if ($type == 'editshop') {
        $shopdata['id']      = intval($_GET['sid']);
        $shopdata['typeid1'] = intval($_GET['typeid1']);
        $shopdata['typeid2'] = intval($_GET['typeid2']);
        
        $shopdata['name']      = zm_diconv(strip_tags($_GET['name']));
        $shopdata['lianxiren'] = zm_diconv(strip_tags($_GET['lianxiren']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = zm_diconv(strip_tags($_GET['youhui']));
        $oldshopdata           = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $shopdata['id']
        ));
        if ($oldshopdata['status'] != 2) {
            $shopdata['desc'] = strip_tags(zm_diconv($_GET['desc']));
        }
        $shopdata['logo']     = strip_tags($_GET['logo']);
        $shopdata['thumb']    = strip_tags($_GET['thumb']);
        $shopdata['province'] = intval($_GET['province']);
        $shopdata['city']     = intval($_GET['city']);
        $shopdata['country']  = intval($_GET['country']);
        $shopdata['address']  = zm_diconv(strip_tags($_GET['address']));
        $shopdata['lat']      = strip_tags($_GET['lat']);
        $shopdata['lng']      = strip_tags($_GET['lng']);
        $shopdata['uid']      = $_G['uid'];
        $shopdata['ispay']    = '2';
        $time_type            = intval($_GET['time_type']);
        $shopdata['viptime']  = time();
        $shopdata['endtime']  = time() + 31536000 * $time_type;
        $shopdata['status']   = '2';
        //$shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $result               = DB::update('zimucms_chengshi114_shop', $shopdata, array(
            'id' => $shopdata['id'],
            'uid' => $shopdata['uid']
        ));
        
        $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
            'zimucms_chengshi114_renmai',
            $shopdata['id'],
            $_G['uid']
        ));
        
        if (!$isrenmai) {
            $renmaidata['sid']             = $shopdata['id'];
            $renmaidata['weixin_id']       = zm_diconv(strip_tags($_GET['weixin_id']));
            $renmaidata['weixin_name']     = zm_diconv(strip_tags($_GET['weixin_name']));
            $renmaidata['weixin_sex']      = intval($_GET['weixin_sex']);
            $renmaidata['weixin_desc']     = zm_diconv(strip_tags($_GET['weixin_desc']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['weixin_touxiang']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['weixin_erweima']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
        if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
            $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
        }
        } else {
            $renmaidata['weixin_id']       = zm_diconv(strip_tags($_GET['weixin_id']));
            $renmaidata['weixin_name']     = zm_diconv(strip_tags($_GET['weixin_name']));
            $renmaidata['weixin_sex']      = intval($_GET['weixin_sex']);
            $renmaidata['weixin_desc']     = zm_diconv(strip_tags($_GET['weixin_desc']));
            $renmaidata['weixin_touxiang'] = strip_tags($_GET['weixin_touxiang']);
            $renmaidata['weixin_erweima']  = strip_tags($_GET['weixin_erweima']);
            $renmaidata['uid']             = $_G['uid'];
            $renmaidata['status']          = '2';
            $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                'id' => $isrenmai
            ));
        }
        
        echo $result2;
        
        
        
        
    } else if ($type == 'addshop') {
        
        
        
        
        $shopdata['typeid1']   = intval($_GET['typeid1']);
        $shopdata['typeid2']   = intval($_GET['typeid2']);
        $shopdata['name']      = zm_diconv(strip_tags($_GET['name']));
        $shopdata['lianxiren'] = zm_diconv(strip_tags($_GET['lianxiren']));
        $shopdata['tel']       = strip_tags($_GET['tel']);
        $shopdata['youhui']    = zm_diconv(strip_tags($_GET['youhui']));
        $shopdata['desc']      = zm_diconv(strip_tags($_GET['desc']));
        $shopdata['logo']      = strip_tags($_GET['logo']);
        $shopdata['thumb']     = strip_tags($_GET['thumb']);
        $shopdata['province']  = intval($_GET['province']);
        $shopdata['city']      = intval($_GET['city']);
        $shopdata['country']   = intval($_GET['country']);
        $shopdata['address']   = zm_diconv(strip_tags($_GET['address']));
        $shopdata['lat']       = strip_tags($_GET['lat']);
        $shopdata['lng']       = strip_tags($_GET['lng']);
        $shopdata['uid']       = $_G['uid'];
        $shopdata['ispay']     = '2';
        $time_type             = intval($_GET['time_type']);
        $shopdata['viptime']   = time();
        $shopdata['endtime']   = time() + 31536000 * $time_type;
        $shopdata['status']    = '2';
        $shopdata['yewuyuan']  = intval($_GET['yewuyuan']);
        $result                = DB::insert('zimucms_chengshi114_shop', $shopdata, '1');
        
        if ($result) {
            $isrenmai = DB::result_first('select id from %t where sid=%d and uid=%d', array(
                'zimucms_chengshi114_renmai',
                $result,
                $_G['uid']
            ));
            
            if (!$isrenmai) {
                $renmaidata['sid']             = $result;
                $renmaidata['weixin_id']       = zm_diconv(strip_tags($_GET['weixin_id']));
                $renmaidata['weixin_name']     = zm_diconv(strip_tags($_GET['weixin_name']));
                $renmaidata['weixin_sex']      = intval($_GET['weixin_sex']);
                $renmaidata['weixin_desc']     = zm_diconv(strip_tags($_GET['weixin_desc']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['weixin_touxiang']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['weixin_erweima']);
                $renmaidata['uid']             = $_G['uid'];
                $renmaidata['status']          = '2';
            if($renmaidata['weixin_id'] && $renmaidata['weixin_name']){
                $result2                       = DB::insert('zimucms_chengshi114_renmai', $renmaidata, '1');
            }
            } else {
                $renmaidata['weixin_id']       = zm_diconv(strip_tags($_GET['weixin_id']));
                $renmaidata['weixin_name']     = zm_diconv(strip_tags($_GET['weixin_name']));
                $renmaidata['weixin_sex']      = intval($_GET['weixin_sex']);
                $renmaidata['weixin_desc']     = zm_diconv(strip_tags($_GET['weixin_desc']));
                $renmaidata['weixin_touxiang'] = strip_tags($_GET['weixin_touxiang']);
                $renmaidata['weixin_erweima']  = strip_tags($_GET['weixin_erweima']);
                $renmaidata['uid']             = $_G['uid'];
                $renmaidata['status']          = '2';
                $result2                       = DB::update('zimucms_chengshi114_renmai', $renmaidata, array(
                    'id' => $isrenmai
                ));
            }
        }
        echo $result2;
        
    }

    $token         = $wechat_client->getAccessToken(1, 1);
    
    $ssid = $shopdata['id'];
    if (!$ssid) {
        $ssid = $renmaidata['sid'];
    }
    if (!$ssid) {
        $ssid = $result;
    }
    
    
    if ($time_type == 2) {
        $fufeijiage = $zmdata['site_jiage2'];
    } else {
        $fufeijiage = $zmdata['site_jiage'];
    }
    $template = array(
        'touser' => $zmdata['manage_openid'],
        'template_id' => $zmdata['manage_mbid'],
        'url' => ZIMUCMS_URL . '&model=viewshop&sid=' . $ssid,
        'topcolor' => "#7B68EE",
        'data' => array(
            'first' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text1'), CHARSET, 'utf-8')),
                'color' => "#743A3A"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($shopdata[name], CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($shopdata[lianxiren], CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode($fufeijiage . diconv(lang('plugin/zimucms_chengshi114', 'system_text2'), CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text3'), CHARSET, 'utf-8')),
                'color' => "#FF0000"
            ),
            'keyword5' => array(
                'value' => urlencode(date("y-m-d H:i:s", time()))
            ),
            'remark' => array(
                'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text4'), CHARSET, 'utf-8') . $shopdata[tel] . diconv(lang('plugin/zimucms_chengshi114', 'system_text5'), CHARSET, 'utf-8')),
                'color' => "#008000"
            )
            
        )
    );
    $json     = urldecode(json_encode($template));
    
    $result = send_weixintemplate($token, $json);
    
    //print_r($result);
    
} else if ($model == 'huodonglist') {
    
    $huodongdata = DB::fetch_all('select * from %t where status=2 order by id desc', array(
        'zimucms_chengshi114_huodong'
    ));
    
    include template('zimucms_chengshi114:huodonglist');
    
} else if ($model == 'userhuodonglist') {
    
    $huodongdata = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimucms_chengshi114_huodong',
        $_G['uid']
    ));
    
    include template('zimucms_chengshi114:userhuodong');
    
    
} else if ($model == 'viewhuodong') {
    
    $hid = intval($_GET['hid']);
    
    $huodongdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_huodong',
        $hid
    ));
    
    include template('zimucms_chengshi114:viewhuodong');
    
} else if ($model == 'shopclicks' && $_GET['formhash'] == $formhash) {
    
    $sid = intval($_GET['sid']);

   if(getcookie("shopclicks_".$sid)){return false;}

    $shopweixin = DB::fetch_first('select * from %t where sid=%d', array(
        'zimucms_chengshi114_renmai',
        $sid
    ));
    
    
    DB::query("update %t set click=click+1 where id=%d", array(
        'zimucms_chengshi114_shop',
        $sid
    ));
    
    dsetcookie("shopclicks_".$sid,1,60);
    
    $daytime   = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
    $weektime  = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1, date('Y'));
    $monthtime = mktime(0, 0, 0, date('m'), 1, date('Y'));
    
    $isshopadd = DB::fetch_first('select * from %t where yid=%d and type=1', array(
        'zimucms_chengshi114_ranklist',
        $sid
    ));
    
    if ($isshopadd) {
        
        if ($isshopadd['uptime'] < $daytime) {
            $uprank1['dayclick'] = '1';
        } else {
            $uprank1['dayclick'] = $isshopadd['dayclick'] + 2 - 1;
        }
        if ($isshopadd['uptime'] < $weektime) {
            $uprank1['weekclick'] = '1';
        } else {
            $uprank1['weekclick'] = $isshopadd['weekclick'] + 2 - 1;
        }
        if ($isshopadd['uptime'] < $monthtime) {
            $uprank1['monthclick'] = '1';
        } else {
            $uprank1['monthclick'] = $isshopadd['monthclick'] + 2 - 1;
        }
        
        $uprank1['yearclick'] = $isshopadd['yearclick'] + 2 - 1;
        $uprank1['uptime']    = time();
        $result               = DB::update('zimucms_chengshi114_ranklist', $uprank1, array(
            'id' => $isshopadd['id'],
            'type' => '1'
        ));
    } else {
        $rankdata['dayclick']   = '1';
        $rankdata['weekclick']  = '1';
        $rankdata['monthclick'] = '1';
        $rankdata['yearclick']  = '1';
        $rankdata['type']       = '1';
        $rankdata['yid']        = $sid;
        $rankdata['uptime']     = time();
        $result                 = DB::insert('zimucms_chengshi114_ranklist', $rankdata);
    }
    
    
    $isrenmaiadd = DB::fetch_first('select * from %t where yid=%d and type=2', array(
        'zimucms_chengshi114_ranklist',
        $shopweixin['id']
    ));
    if ($isrenmaiadd) {
        
        if ($isrenmaiadd['uptime'] < $daytime) {
            $uprank1['dayclick'] = '1';
        } else {
            $uprank1['dayclick'] = $isrenmaiadd['dayclick'] + 2 - 1;
        }
        if ($isrenmaiadd['uptime'] < $weektime) {
            $uprank1['weekclick'] = '1';
        } else {
            $uprank1['weekclick'] = $isrenmaiadd['weekclick'] + 2 - 1;
        }
        if ($isrenmaiadd['uptime'] < $monthtime) {
            $uprank1['monthclick'] = '1';
        } else {
            $uprank1['monthclick'] = $isrenmaiadd['monthclick'] + 2 - 1;
        }
        
        $uprank1['yearclick'] = $isrenmaiadd['yearclick'] + 2 - 1;
        $uprank1['uptime']    = time();
        $result               = DB::update('zimucms_chengshi114_ranklist', $uprank1, array(
            'id' => $isrenmaiadd['id'],
            'type' => '2'
        ));
    } else {
        $rankdata['dayclick']   = '1';
        $rankdata['weekclick']  = '1';
        $rankdata['monthclick'] = '1';
        $rankdata['yearclick']  = '1';
        $rankdata['type']       = '2';
        $rankdata['yid']        = $shopweixin['id'];
        $rankdata['uptime']     = time();
        $result                 = DB::insert('zimucms_chengshi114_ranklist', $rankdata);
    }
    
    
    
    
} else if ($model == 'renmaiclicks' && $_GET['FORM_HASH'] == $formhash) {
    
    $yid = intval($_GET['yid']);
    
    $daytime   = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
    $weektime  = mktime(0, 0, 0, date('m'), date('d') - date('w') + 1, date('Y'));
    $monthtime = mktime(0, 0, 0, date('m'), 1, date('Y'));
    
    $isrenmaiadd = DB::fetch_first('select * from %t where yid=%d and type=2', array(
        'zimucms_chengshi114_ranklist',
        $yid
    ));
    
    if ($isrenmaiadd) {
        if ($isrenmaiadd['uptime'] < $daytime) {
            $uprank1['dayclick'] = '1';
        } else {
            $uprank1['dayclick'] = $isrenmaiadd['dayclick'] + 2 - 1;
        }
        if ($isrenmaiadd['uptime'] < $weektime) {
            $uprank1['weekclick'] = '1';
        } else {
            $uprank1['weekclick'] = $isrenmaiadd['weekclick'] + 2 - 1;
        }
        if ($isrenmaiadd['uptime'] < $monthtime) {
            $uprank1['monthclick'] = '1';
        } else {
            $uprank1['monthclick'] = $isrenmaiadd['monthclick'] + 2 - 1;
        }
        $uprank1['yearclick'] = $isrenmaiadd['yearclick'] + 2 - 1;
        $uprank1['uptime']    = time();
        $result               = DB::update('zimucms_chengshi114_ranklist', $uprank1, array(
            'id' => $isrenmaiadd['id'],
            'type' => '2'
        ));
    } else {
        $rankdata['dayclick']   = '1';
        $rankdata['weekclick']  = '1';
        $rankdata['monthclick'] = '1';
        $rankdata['yearclick']  = '1';
        $rankdata['type']       = '2';
        $rankdata['yid']        = $yid;
        $rankdata['uptime']     = time();
        $result                 = DB::insert('zimucms_chengshi114_ranklist', $rankdata);
    }
    
} else if ($model == 'addhuodong') {
    
    if (submitcheck('addhuodong') && $_G['uid']) {
        
        $huodongdata['lianxiren']    = strip_tags(zm_diconv($_GET['lianxiren']));
        $huodongdata['tel']          = strip_tags($_GET['tel']);
        $huodongdata['sid']          = intval($_GET['sid']);
        $huodongdata['title']    = strip_tags(zm_diconv($_GET['title']));
        $huodongdata['starttime'] = strtotime($_GET['starttime']);
        $huodongdata['endtime'] = strtotime($_GET['endtime']);
        $huodongdata['huodong_desc'] = strip_tags(zm_diconv($_GET['huodong_desc']));
        $huodongdata['uid']          = $_G['uid'];
        $huodongdata['status']       = '1';
        $huodongcontent = $huodongdata['huodong_desc'];

        if ($_FILES['file1']) {
            $huodongdata['file1'] = zm_saveimages($_FILES['file1'], 'huodong');
            $huodongdata['thumb'] = $huodongdata['file1'];
            $huodongcontent = $huodongcontent.'<p style="text-align:center;"><img style="max-width:600px;" src="'.$huodongdata['file1'].'" /></p>';
        }
        if ($_FILES['file2']) {
            $huodongdata['file2'] = zm_saveimages($_FILES['file2'], 'huodong');
            $huodongcontent = $huodongcontent.'<p style="text-align:center;"><img style="max-width:600px;" src="'.$huodongdata['file2'].'" /></p>';
        }
        if ($_FILES['file3']) {
            $huodongdata['file3'] = zm_saveimages($_FILES['file3'], 'huodong');
            $huodongcontent = $huodongcontent.'<p style="text-align:center;"><img style="max-width:600px;" src="'.$huodongdata['file3'].'" /></p>';
        }
        if ($_FILES['file4']) {
            $huodongdata['file4'] = zm_saveimages($_FILES['file4'], 'huodong');
            $huodongcontent = $huodongcontent.'<p style="text-align:center;"><img style="max-width:600px;" src="'.$huodongdata['file4'].'" /></p>';
        }
        if ($_FILES['file5']) {
            $huodongdata['file5'] = zm_saveimages($_FILES['file5'], 'huodong');
            $huodongcontent = $huodongcontent.'<p style="text-align:center;"><img style="max-width:600px;" src="'.$huodongdata['file5'].'" /></p>';
        }
        $huodongdata['content']       = $huodongcontent;
        $result = DB::insert('zimucms_chengshi114_huodong', $huodongdata);
        
        dheader('Location:' . ZIMUCMS_URL . '&model=userhuodonglist');
        
    } else {
        isuid();
        $shopdata = DB::fetch_all('select * from %t where uid=%d and ispay=2 order by id desc', array(
            'zimucms_chengshi114_shop',
            $_G['uid']
        ));
        include template('zimucms_chengshi114:addhuodong');
    }
} else if ($model == 'catjson') {
    
    $typeid1 = intval($_GET['typeid1']);
    
    $typeid1data = DB::fetch_all('select * from %t where cid=%d order by sort asc,id asc', array(
        'zimucms_chengshi114_cat',
        $typeid1
    ));
    
    foreach ($typeid1data as $key => $value) {
        $typeid1data[$key]['name'] = urlencode($typeid1data[$key]['name']);
    }
    
    $typeid1data = json_encode($typeid1data);
    echo $typeid1data = urldecode($typeid1data);
    
} else if ($model == 'areajson') {
    
    $province = intval($_GET['province']);
    
    $city = intval($_GET['city']);
    
    if ($province) {
        $areadata = DB::fetch_all('select * from %t where upid=%d and level=2 order by displayorder asc', array(
            'common_district',
            $province
        ));
    } else if ($city) {
        $areadata = DB::fetch_all('select * from %t where upid=%d and level=3 order by displayorder asc', array(
            'common_district',
            $city
        ));
    }
    foreach ($areadata as $key => $value) {
        $areadata[$key]['name'] = urlencode($areadata[$key]['name']);
    }
    
    $areadata = json_encode($areadata);
    echo $areadata = urldecode($areadata);
    
    
    
} else if ($model == 'admingetcat') {
    
    $cidval = intval($_GET['cidval']);
    
    $catdata = DB::fetch_all('select * from %t where cid=%d order by sort asc,id asc', array(
        'zimucms_chengshi114_cat',
        $cidval
    ));
    
    foreach ($catdata as $key => $value) {
        $catdata[$key]['name'] = urlencode($catdata[$key]['name']);
    }
    
    $catdata = json_encode($catdata);
    echo $catdata = urldecode($catdata);
    
} else if ($model == 'viewyouhuiquan') {
    
    $yid = intval($_GET['yid']);
    
    $youhuidata = DB::fetch_first('select * from %t where status=2 and id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $yid
    ));
    
    $shopdata = DB::fetch_first('select * from %t where status=2 and id=%d', array(
        'zimucms_chengshi114_shop',
        $youhuidata['sid']
    ));

if($shopdata['endtime'] < $_G['timestamp'] ){
     $shoptiptext = $shopdata['name'] . lang('plugin/zimucms_chengshi114', 'system_text11');
        include template('zimucms_chengshi114:shoptip');
         exit();
}
    $usednums = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d", array(
        "zimucms_chengshi114_youhuiquandata",
        $yid
    ));

    $miaoshanums = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d and usedtime>%d and usedtime<%d", array(
        "zimucms_chengshi114_youhuiquandata",
        $yid,
        strtotime(date('Y-m-d',$_G['timestamp'])),
        strtotime(date('Y-m-d',$_G['timestamp']))+86400
    ));

    if (!$usednums) {
        $usednums = '0';
    }
    if (!$miaoshanums) {
        $miaoshanums = '0';
    }
    if ($_G['uid'] > 0) {
        $ispay      = DB::fetch_first('select * from %t where status=2 and yid=%d and uid=%d', array(
            'zimucms_chengshi114_youhuiquandata',
            $yid,
            $_G['uid']
        ));
        $myusednums = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d and uid=%d", array(
            "zimucms_chengshi114_youhuiquandata",
            $yid,
            $_G['uid']
        ));
        
    }
    include template('zimucms_chengshi114:viewyouhuiquan');
    
} else if ($model == 'paycoupon') {
    
    isuid();
    if (IN_WECHAT) {
        $openid = zm_wechat_auth();
    }
    $yid = intval($_GET['yid']);
    
    $youhuidata = DB::fetch_first('select * from %t where status=2 and id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $yid
    ));
    $usednums   = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d", array(
        "zimucms_chengshi114_youhuiquandata",
        $yid
    ));
    if ($youhuidata['maxnums'] - $usednums < $youhuidata['paymaxnums']) {
        $youhuidata['paymaxnums'] = $youhuidata['maxnums'] - $usednums;
    }
    
    
    include template('zimucms_chengshi114:paycoupon');

} else if ($model == 'alipay_coupon' && $_GET['md5hash'] == $formhash) {

    $yid        = intval($_GET['yid']);
    $sid        = intval($_GET['sid']);
    $youhuidata = DB::fetch_first('select * from %t where status=2 and id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $yid
    ));
    $pay = round($_GET['pay'], 2);
    $nums = intval($_GET['nums']);
    $out_trade_no = dgmdate(TIMESTAMP, 'YmdHis').random(18);  //创建支付订单号;
    $paydata = array(
        'sid' => $sid,
        'yid' => $yid,
        'uid' => $_G['uid'],
        'jiage' => $pay,
        'alljiage' => $pay * $nums,
        'nums' => $nums,
        'out_trade_no' => $out_trade_no
        
    );
    $result  = DB::insert('zimucms_chengshi114_youhuiquandata', $paydata);


$price = $pay * $nums;
$subject = lang('plugin/zimucms_chengshi114','system_text15');
//开始支付宝支付操作
    if($_G['mobile'] && $_G['cache']['plugin']['zimucms_chengshi114']['is_alipay']){
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        $alipay_config['partner']       = $ec_partner;
        $alipay_config['seller_id'] = $alipay_config['partner'];
        $alipay_config['key']           = $ec_securitycode;
        $alipay_config['notify_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_coupon_notify.php';
        $alipay_config['return_url'] = $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_coupon_notify.php';
        $alipay_config['sign_type']    = strtoupper('MD5');
        //字符编码格式 目前支持utf-8
        $alipay_config['input_charset']= strtolower('utf-8');
        //ca证书路径地址，用于curl中ssl校验
        //请保证cacert.pem文件在当前文件夹目录中
        $alipay_config['cacert']    = getcwd().'\\cacert.pem';
        //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $alipay_config['transport']    = 'http';
        $alipay_config['payment_type'] = "1";
        $alipay_config['service'] = "alipay.wap.create.direct.pay.by.user";
        require_once("source/plugin/zimucms_chengshi114/class/alipay_submit.class.php");
        
        //商户订单号，商户网站订单系统中唯一订单号，必填

        //订单名称，必填
        if($_G['charset']=='gbk'){
            if(mb_strlen($subject,'gbk')>10){
                $subject = mb_substr($subject,0,10,'gbk');
            }
                $subject = iconv('gbk','utf-8',$subject);
        }else{
            if(mb_strlen($subject,'utf-8')>10){
                $subject = mb_substr($subject,0,10,'utf-8');
            }
        }

//echo $subject;exit();
        //付款金额，必填
        $total_fee = $price;

        //收银台页面上，商品展示的超链接，必填
        $show_url = $_G['siteurl'].'/plugin.php?id=zimucms_chengshi114&model=myyouhuiquan';

        //商品描述，可空
        $body = '';
        $parameter = array(
                "service"       => $alipay_config['service'],
                "partner"       => $alipay_config['partner'],
                "seller_id"  => $alipay_config['seller_id'],
                "payment_type"  => $alipay_config['payment_type'],
                "notify_url"    => $alipay_config['notify_url'],
                "return_url"    => $alipay_config['return_url'],
                "_input_charset"    => trim(strtolower($alipay_config['input_charset'])),
                "out_trade_no"  => $out_trade_no,
                "subject"   => $subject,
                "total_fee" => $total_fee,
                "show_url"  => $show_url,
                "body"  => $body,
                //其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.2Z6TSk&treeId=60&articleId=103693&docType=1
                //如"参数名"    => "参数值"   注：上一个参数末尾需要“,”逗号。
                
        );
        //print_r($alipay_config);
        //exit();
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter,"get",lang('plugin/zimucms_chengshi114', 'system_text14'));
        echo $html_text;
        exit();
    }else{
        list($ec_contract, $ec_securitycode, $ec_partner, $ec_creditdirectpay) = explode("\t", authcode($_G['setting']['ec_contract'], 'DECODE', $_G['config']['security']['authkey']));
        define('DISCUZ_PARTNER', $ec_partner);
        define('DISCUZ_SECURITYCODE', $ec_securitycode);
        define('DISCUZ_DIRECTPAY', $ec_creditdirectpay);
        define('STATUS_SELLER_SEND', 4);
        define('STATUS_WAIT_BUYER', 5);
        define('STATUS_TRADE_SUCCESS', 7);
        define('STATUS_REFUND_CLOSE', 17);
        
        $args = array(
          'subject'     => $_G['member']['username'].' '.$subject,
          'body'      => $_G['member']['username'].' '.$subject.$_G['clientip'],
          'service'     => 'trade_create_by_buyer',
          'partner'     => DISCUZ_PARTNER,
          'notify_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_coupon_notify.php',
          'return_url'    => $_G['siteurl'].'source/plugin/zimucms_chengshi114/class/alipay_coupon_notify.php',
          'show_url'    => $_G['siteurl'],
          '_input_charset'  => CHARSET,
          'out_trade_no'    => $out_trade_no,
          'price'     => $price,
          'quantity'    => 1,
          'seller_email'    => $_G['setting']['ec_account'],
          'sid'  => $shopdata['id'],
        );
        if(DISCUZ_DIRECTPAY) {
          $args['service'] = 'create_direct_pay_by_user';
          $args['payment_type'] = '1';
        } else {
          $args['logistics_type'] = 'EXPRESS';
          $args['logistics_fee'] = 0;
          $args['logistics_payment'] = 'SELLER_PAY';
          $args['payment_type'] = 1;
        }
        ksort($args);
        $urlstr = $sign = '';
        foreach($args as $key => $val) {
            $sign .= '&'.$key.'='.$val;
            $urlstr .= $key.'='.rawurlencode($val).'&';
        }
        $sign = substr($sign, 1);
        $sign = md5($sign.DISCUZ_SECURITYCODE);
        header('Location: https://www.alipay.com/cooperate/gateway.do?'.$urlstr.'sign='.$sign.'&sign_type=MD5');
    }





















} else if ($model == 'topaycoupon' && $_GET['md5hash'] == $formhash) {
    
    $yid        = intval($_GET['yid']);
    $sid        = intval($_GET['sid']);
    $youhuidata = DB::fetch_first('select * from %t where status=2 and id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $yid
    ));
    
    $pay = round($_GET['pay'], 2);
    $num = intval($_GET['num']);
    
    if (IN_XIAOYUNAPP) {
        
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/lib/WxPay.Api.php";
        include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/source/WxPay.AppPay.php";
        
        
        $notify         = new AppPay();
        $order_sn       = $_G['uid'] . $yid . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $inputbody      = diconv(cutstr($youhuidata['title'], 32, ''), CHARSET, 'utf-8');
        $inputtotal_fee = intval($pay * $num * 100);
        $input          = new WxPayUnifiedOrder();
        $input->SetBody($inputbody);
        $input->SetOut_trade_no($order_sn);
        $input->SetTotal_fee($inputtotal_fee);
        $input->SetNotify_url(ZIMUCMS_URL . '&model=tuisongmoban');
        $input->SetTrade_type("APP");
        $order            = WxPayApi::unifiedOrder($input);
        $appApiParameters = $notify->GetAppApiParameters($order);
        
        $wxpay                 = json_decode($appApiParameters);
        $wxpay                 = object_array($wxpay);
        $wxpay['out_trade_no'] = $order_sn;
        
        
    } else {
        
        if (IN_WECHAT) {
            $openid = zm_wechat_auth(1);
        }
        
        include DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/wxpay.class.php';
        $input               = new WxPayData();
        $input->body         = diconv(cutstr($youhuidata['title'], 32, ''), CHARSET, 'utf-8');
        $input->out_trade_no = $_G['uid'] . $yid . date('YmdHis') . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        $input->total_fee    = intval($pay * $num * 100);
        $input->time_start   = date('YmdHis');
        $input->time_expire  = date('YmdHis', TIMESTAMP + 600);
        $input->notify_url   = ZIMUCMS_URL;
        
        $input->product_id = diconv(cutstr($youhuidata['title'],28, ''), CHARSET, 'utf-8') . $_G['uid'];
        $input->fromtype   = 'CHENGSHI114_YHQ';
        $input->fromid     = $_G['uid'];
        $input->openid     = $openid;
        $input->trade_type = 'JSAPI';
        
        try {
            $jsPay  = new JsApiPay();
            $result = WxPayApi::unifiedOrder($input);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        //$result = diconv($result, 'utf-8', CHARSET);
        
        if ($result['return_code'] == 'FAIL') {
            showmessage($result['return_msg']);
        }
        
        if ($result['result_code'] == 'FAIL') {
            showmessage($result['err_code_des']);
        }
        try {
            $wxpay = $jsPay->getJsApiParameters($result);
        }
        catch (WxPayException $e) {
            showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
        }
        
        
        $wxpay                 = json_decode($wxpay);
        $wxpay                 = object_array($wxpay);
        $wxpay['out_trade_no'] = $input->out_trade_no;
    }
    
    
    $paydata = array(
        'sid' => $sid,
        'yid' => $yid,
        'uid' => $_G['uid'],
        'jiage' => $pay,
        'alljiage' => $pay * $num,
        'nums' => $num,
        'out_trade_no' => $wxpay['out_trade_no']
        
    );
    $result  = DB::insert('zimucms_chengshi114_youhuiquandata', $paydata);
    if ($result) {
        echo json_encode($wxpay);
    }
    
} else if ($model == 'apppaysuccess') {
    
    
    $out_trade_no   = strip_tags($_GET['out_trade_no']);
    $youhuidatadata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_chengshi114_youhuiquandata',
        $out_trade_no
    ));
    $youhuidata     = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $youhuidatadata['yid']
    ));
    
    include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/lib/WxPay.Api.php";
    include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/source/WxPay.AppPay.php";
    
    $notify         = new AppPay();
    $order_sn       = $out_trade_no;
    $inputbody      = diconv(cutstr($youhuidata['title'], 32, ''), CHARSET, 'utf-8');
    $inputtotal_fee = intval($youhuidatadata['alljiage'] * 100);
    $input          = new WxPayUnifiedOrder();
    $input->SetBody($inputbody);
    $input->SetOut_trade_no($order_sn);
    $input->SetTotal_fee($inputtotal_fee);
    $input->SetNotify_url(ZIMUCMS_URL . '&model=tuisongmoban');
    $input->SetTrade_type("APP");
    $order            = WxPayApi::unifiedOrder($input);
    $appApiParameters = $notify->GetAppApiParameters($order);
    
    $wxpay                 = json_decode($appApiParameters);
    $wxpay                 = object_array($wxpay);
    $wxpay['out_trade_no'] = $order_sn;
    
    include template('zimucms_chengshi114:appweixinpay');
    
    
} else if ($model == 'paysuccess2') {
    
    
    include DISCUZ_ROOT . "source/plugin/zimucms_chengshi114/payment/weixin/lib/WxPay.Api.php";
    
    $out_trade_no = strip_tags($_GET['out_trade_no']);
    $input        = new WxPayOrderQuery();
    $input->SetOut_trade_no($out_trade_no);
    $result = WxPayApi::orderQuery($input);
    
    $youhuidatadata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_chengshi114_youhuiquandata',
        $out_trade_no
    ));
    
    $youhuidata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $youhuidatadata['yid']
    ));
    
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_shop',
        $youhuidata['sid']
    ));
    
    if ($result['trade_state'] == 'SUCCESS' && $youhuidatadata['status'] == 1 && $_GET['md5hash'] == $formhash) {
        
        $addata['status'] = '2';
        $result           = DB::update('zimucms_chengshi114_youhuiquandata', $addata, array(
            'out_trade_no' => $out_trade_no
            //'uid' => $_G['uid']     
        ));

if($zmweixin['weixin_appid']){
        $touser = DB::result_first('select openid from %t where uid=%d', array(
            'zimucms_weixin_binduser',
            $youhuidatadata['uid']
        ));
        
        if ($touser) {
            $token    = $wechat_client->getAccessToken(1, 1);
            $template = array(
                'touser' => $touser,
                'template_id' => $zmdata['youhuiquan_mbid'],
                'url' => ZIMUCMS_URL . '&model=viewyouhuiquan&yid=' . $youhuidatadata['yid'],
                'topcolor' => "#7B68EE",
                'data' => array(
                    'name' => array(
                        'value' => urlencode(diconv($youhuidata['title'], CHARSET, 'utf-8')),
                        'color' => "#743A3A"
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text12'), CHARSET, 'utf-8') . $youhuidata[daodianfu]),
                        'color' => "#008000"
                    )
                    
                )
            );
            $json     = urldecode(json_encode($template));
            $result   = send_weixintemplate($token, $json);
            //print_r($result);
        }
    }      
    }
    
    
    //$yanzhengurl = $_G['siteurl'] . '/' . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $yanzhengurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    $qrsize = 5;
    $dir    = 'data/cache/qrcode/'; //存储路径
    $file   = $dir . 'zimucms_chengshi114_' . $input->out_trade_no . '.jpg';
    if (!file_exists($file) || !filesize($file)) {
        dmkdir($dir);
        require_once DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/qrcode.class.php';
        QRcode::png($yanzhengurl, $file, QR_ECLEVEL_L, $qrsize);
    }
    
    $qrcode = base64_encode(file_get_contents($file));
    unlink($file);
    
    
    include template('zimucms_chengshi114:paysuccess');
    
    
} else if ($model == 'paysuccess') {
    
    
    include DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/wxpay.class.php';
    
    $input               = new WxPayData();
    $input->out_trade_no = strip_tags($_GET['out_trade_no']);
    
    try {
        $jsPay  = new JsApiPay();
        $result = WxPayApi::orderQuery($input);
    }
    catch (WxPayException $e) {
        showmessage(diconv($e->errorMessage(), 'utf-8', CHARSET));
    }
    
    $youhuidatadata = DB::fetch_first('select * from %t where out_trade_no=%s', array(
        'zimucms_chengshi114_youhuiquandata',
        $input->out_trade_no
    ));
    
    $youhuidata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $youhuidatadata['yid']
    ));
    
    $shopdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimucms_chengshi114_shop',
        $youhuidata['sid']
    ));
    
    if ($result['trade_state'] == 'SUCCESS' && $youhuidatadata['status'] == 1 && $_GET['md5hash'] == $formhash) {
        
        $addata['status'] = '2';
        $result           = DB::update('zimucms_chengshi114_youhuiquandata', $addata, array(
            'out_trade_no' => $input->out_trade_no
            //'uid' => $_G['uid']     
        ));
 
if($zmweixin['weixin_appid']){
        $touser = DB::result_first('select openid from %t where uid=%d', array(
            'zimucms_weixin_binduser',
            $youhuidatadata['uid']
        ));
}    
        if (!$touser) {
            $touser = zm_wechat_auth(1);
        }
        
        if ($touser) {
            $token    = $wechat_client->getAccessToken(1, 1);
            $template = array(
                'touser' => $touser,
                'template_id' => $zmdata['youhuiquan_mbid'],
                'url' => ZIMUCMS_URL . '&model=viewyouhuiquan&yid=' . $youhuidatadata['yid'],
                'topcolor' => "#7B68EE",
                'data' => array(
                    'name' => array(
                        'value' => urlencode(diconv($youhuidata['title'], CHARSET, 'utf-8')),
                        'color' => "#743A3A"
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(lang('plugin/zimucms_chengshi114', 'system_text12'), CHARSET, 'utf-8') . $youhuidata[daodianfu]),
                        'color' => "#008000"
                    )
                    
                )
            );
            $json     = urldecode(json_encode($template));
            $result   = send_weixintemplate($token, $json);
            //print_r($result);
        }
        
    }
    
    
    //$yanzhengurl = $_G['siteurl'] . '/' . $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
    $yanzhengurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    $qrsize = 5;
    $dir    = 'data/cache/qrcode/'; //存储路径
    $file   = $dir . 'zimucms_chengshi114_' . $input->out_trade_no . '.jpg';
    if (!file_exists($file) || !filesize($file)) {
        dmkdir($dir);
        require_once DISCUZ_ROOT . 'source/plugin/zimucms_chengshi114/class/qrcode.class.php';
        QRcode::png($yanzhengurl, $file, QR_ECLEVEL_L, $qrsize);
    }
    
    $qrcode = base64_encode(file_get_contents($file));
    unlink($file);
    
    
    include template('zimucms_chengshi114:paysuccess');
    
    
    
} else if ($model == 'payshopyanzheng' && $_GET['md5hash'] == $formhash) {
    
    $pwd = strip_tags($_GET['pwd']);
    $yid = intval($_GET['yid']);
    $oid = strip_tags($_GET['oid']);
    
    
    $youhuidata = DB::result_first('select yanzheng from %t where id=%d', array(
        'zimucms_chengshi114_youhuiquan',
        $yid
    ));
    
    if ($pwd == $youhuidata) {
        $addata['status']   = '3';
        $addata['usedtime'] = time();
        $result             = DB::update('zimucms_chengshi114_youhuiquandata', $addata, array(
            'out_trade_no' => $oid
        ));
        echo '1';
    } else {
        echo '0';
    }
    
    
} else if ($model == 'myyouhuiquan') {
    isuid();
    
    $oldyouhuidata1 = DB::fetch_all('select * from %t where status=2 and uid=%d order by id desc', array(
        'zimucms_chengshi114_youhuiquandata',
        $_G['uid']
    ));
    foreach ($oldyouhuidata1 as $key => $value) {
        $oldyouhuidata1[$key]['huodong']  = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid']
        ));
        $oldyouhuidata1[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $oldyouhuidata1[$key]['huodong']['sid']
        ));
if($_G['timestamp'] <= $oldyouhuidata1[$key]['huodong']['duihuantime']){
$youhuidata1[$key] = $oldyouhuidata1[$key];
}else{
$addyouhuidata2[$key] = $oldyouhuidata1[$key];
}


    }
    
    $oldyouhuidata2 = DB::fetch_all('select * from %t where status=3 and uid=%d order by id desc', array(
        'zimucms_chengshi114_youhuiquandata',
        $_G['uid']
    ));
    foreach ($oldyouhuidata2 as $key => $value) {
        $oldyouhuidata2[$key]['huodong']  = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid']
        ));
        $oldyouhuidata2[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $oldyouhuidata2[$key]['huodong']['sid']
        ));
    }



if(!$addyouhuidata2){
$addyouhuidata2 = array();
}

if(!$oldyouhuidata2){
$oldyouhuidata2 = array();
}

$youhuidata2 = array_merge($addyouhuidata2,$oldyouhuidata2);

$youhuidata2 = array_sort($youhuidata2,'id','desc');  
    include template('zimucms_chengshi114:myyouhuiquan');
    
} else if ($model == 'manageyouhuiquanshoplist') {
    
    isuid();
    
    $myshop = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimucms_chengshi114_youhuiquan',
        $_G['uid']
    ));
    foreach ($myshop as $key => $value) {
        
        $myshop[$key]['shopinfo'] = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $value['sid']
        ));
        
        $myshop[$key]['usednums'] = DB::result_first("SELECT SUM(nums) FROM %t where status>1 and yid=%d", array(
            "zimucms_chengshi114_youhuiquandata",
            $value['id']
        ));
        if (!$myshop[$key]['usednums']) {
            $myshop[$key]['usednums'] = '0';
        }
        
    }
    
    include template('zimucms_chengshi114:manageyouhuiquanshoplist');
    
} else if ($model == 'manageyouhuiquanlist') {
    
    isuid();
    
    $yid = intval($_GET['yid']);
    $sid = intval($_GET['sid']);
    
    $youhuidata1 = DB::fetch_all('select * from %t where status=2 and yid=%d and sid=%d order by id desc', array(
        'zimucms_chengshi114_youhuiquandata',
        $yid,
        $sid
    ));
    
    foreach ($youhuidata1 as $key => $value) {
        $youhuidata1[$key]['huodong']  = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid']
        ));
        $youhuidata1[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $youhuidata1[$key]['huodong']['sid']
        ));
    }
    $youhuidata2 = DB::fetch_all('select * from %t where status=3 and yid=%d and sid=%d order by id desc', array(
        'zimucms_chengshi114_youhuiquandata',
        $yid,
        $sid
    ));
    foreach ($youhuidata2 as $key => $value) {
        $youhuidata2[$key]['huodong']  = DB::fetch_first('select * from %t where id=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['yid']
        ));
        $youhuidata2[$key]['shopname'] = DB::result_first('select name from %t where id=%d', array(
            'zimucms_chengshi114_shop',
            $youhuidata2[$key]['huodong']['sid']
        ));
    }
    
    
    include template('zimucms_chengshi114:manageyouhuiquanlist');
    
} else if ($model == 'addyouhuiquan') {
    isuid();
    
    if (submitcheck('addyouhuiquan') && $_G['uid']) {
        
        $adddata['sid']         = intval($_GET['sid']);
        $adddata['title']       = strip_tags(zm_diconv($_GET['title']));
        $adddata['starttime']   = strtotime($_GET['starttime']);
        $adddata['endtime']     = strtotime($_GET['endtime']);
        $adddata['duihuantime'] = strtotime($_GET['duihuantime']);
        $adddata['jiage']       = round($_GET['jiage'], 2);
        $adddata['daodianfu']   = round($_GET['daodianfu'], 2);
        $adddata['maxnums']     = intval($_GET['maxnums']);
        $adddata['paymaxnums']  = intval($_GET['paymaxnums']);
        $adddata['content']     = strip_tags(zm_diconv($_GET['content']));
        $adddata['yanzheng']    = strip_tags(zm_diconv($_GET['yanzheng']));
        $adddata['beizhu']      = strip_tags(zm_diconv($_GET['beizhu']));
        $adddata['thumb']       = strip_tags(zm_diconv($_GET['img']));
        $adddata['uid']         = $_G['uid'];
        $adddata['status']      = '1';
        $adddata['ismiaosha']         = intval($_GET['ismiaosha']);
        $adddata['starthours']         = intval($_GET['starthours']);
        $adddata['endhours']         = intval($_GET['endhours']);
        $adddata['daynums']         = intval($_GET['daynums']);

        $result = DB::insert('zimucms_chengshi114_youhuiquan', $adddata);
        
        dheader('Location:' . ZIMUCMS_URL . '&model=manageyouhuiquanshoplist');
        
    } else {
        $shopdata = DB::fetch_all('select * from %t where uid=%d and ispay=2 order by id desc', array(
            'zimucms_chengshi114_shop',
            $_G['uid']
        ));
        include template('zimucms_chengshi114:addyouhuiquan');
    }
    
} else {
    
    $chengshi114_data = (array) unserialize($_G['setting']['chengshi114_data']);
    
    $addata  = DB::fetch_all('select * from %t order by sort desc', array(
        'zimucms_chengshi114_ad'
    ));
    $catdata = $chengshi114_data['catdata'];
    $cates   = array();
    for ($i = 0; $i < count($catdata) / 10; $i++) {
        for ($j = 0; $j < 10; $j++) {
            if ($i * 10 + $j < count($catdata)) {
                $cates[$i][$i * 10 + $j] = $catdata[$i * 10 + $j];
            }
        }
    }


    $newshopdata = DB::fetch_all('select * from %t where status=2 and endtime>%d order by id desc limit 30', array(
        'zimucms_chengshi114_shop',
        $_G['timestamp']
    ));
    
    foreach ($newshopdata as $key => $value) {
        $newshopdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id']
        ));
    }
    
    
    $hotshopdata = DB::fetch_all('select * from %t where status=2 and endtime>%d order by click desc limit 30', array(
        'zimucms_chengshi114_shop',
        $_G['timestamp']
    ));
    
    foreach ($hotshopdata as $key => $value) {
        $hotshopdata[$key]['isyouhui'] = DB::fetch_first('select * from %t where status=2 and sid=%d', array(
            'zimucms_chengshi114_youhuiquan',
            $value['id']
        ));
    }
    
    $ranmaidata = DB::fetch_all('select * from %t where status=2 order by click desc limit 30', array(
        'zimucms_chengshi114_renmai'
    ));
    
    $huodongdata = DB::fetch_all('select * from %t where status=2 and endtime>%d order by id desc limit 30', array(
        'zimucms_chengshi114_huodong',
        time()
    ));
    
    $youhuiquandata = DB::fetch_all('select * from %t where status=2 and endtime>%d order by rand() limit 30', array(
        'zimucms_chengshi114_youhuiquan',
        time()
    ));
    
    $shopnums = DB::result_first("SELECT count(*) FROM %t", array(
        "zimucms_chengshi114_shop"
    ));
    
    $allviewnums = DB::result_first("SELECT sum(click) FROM %t", array(
        "zimucms_chengshi114_shop"
    ));
    
if($zmdata['isopen_red']){
    include template('zimucms_chengshi114:newindex_red');
}else{
    include template('zimucms_chengshi114:newindex');
}


}