<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$shoplist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_chengshi114_shop'));

$shoplistarray = mysqltoarray($shoplist);
if (!in_array('sort', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_shop` ADD COLUMN `sort` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '100';
EOF;
    runquery($sql1);
}
if (!in_array('out_trade_no', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_shop` ADD COLUMN `out_trade_no` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('addtime', $shoplistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_shop` ADD COLUMN `addtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

$youhuiquanlist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_chengshi114_youhuiquan'));
$youhuiquanlistarray = mysqltoarray($youhuiquanlist);
if (!in_array('ismiaosha', $youhuiquanlistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_youhuiquan` ADD COLUMN `ismiaosha` SMALLINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('starthours', $youhuiquanlistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_youhuiquan` ADD COLUMN `starthours` SMALLINT(2) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('endhours', $youhuiquanlistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_youhuiquan` ADD COLUMN `endhours` SMALLINT(2) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('daynums', $youhuiquanlistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_youhuiquan` ADD COLUMN `daynums` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}


$catlist = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimucms_chengshi114_cat'));
$catlistarray = mysqltoarray($catlist);
if (!in_array('caturl', $catlistarray)) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimucms_chengshi114_cat` ADD COLUMN `caturl` CHAR(250) NOT NULL;
EOF;
    runquery($sql1);
}


 $sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_youhuiquan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL,
  `thumb` char(255) NOT NULL,
  `jiage` float NOT NULL,
  `daodianfu` float NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `duihuantime` int(10) unsigned NOT NULL,
  `maxnums` smallint(5) unsigned NOT NULL,
  `paymaxnums` smallint(2) unsigned NOT NULL,
  `content` text NOT NULL,
  `yanzheng` char(50) NOT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `sid` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ismiaosha` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `starthours` smallint(2) unsigned NOT NULL,
  `endhours` smallint(2) unsigned NOT NULL,
  `daynums` smallint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimucms_chengshi114_youhuiquandata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `yid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `jiage` float NOT NULL,
  `alljiage` float NOT NULL,
  `nums` smallint(2) unsigned NOT NULL,
  `out_trade_no` char(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `usedtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE;

function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}