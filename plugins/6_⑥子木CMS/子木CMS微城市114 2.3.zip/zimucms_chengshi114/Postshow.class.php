<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//电脑版
class plugin_zimucms_chengshi114
{
}

class plugin_zimucms_chengshi114_forum extends plugin_zimucms_chengshi114
{
	function viewthread_postsightmlafter_output()
	{
		global $_G;
		$shangjiacount = DB::result_first("SELECT count(*) FROM %t WHERE uid=%d AND status=2 ", array(
			"zimucms_chengshi114_shop",
			$_G['thread']['authorid']
			));

		if($shangjiacount>0){
			if($shangjiacount==1){
				$isshangjia = DB::fetch_first('select * from %t where uid=%d and status=2 and endtime>%d order by id asc', array(
					'zimucms_chengshi114_shop',
					$_G['thread']['authorid'],
					$_G['timestamp']
					));
			}else{
		        $isshangjia = DB::fetch_first('select * from %t where uid=%d and status=2 and endtime>%d order by rand() limit 1', array(
					'zimucms_chengshi114_shop',
					$_G['thread']['authorid'],
					$_G['timestamp']
					));
			}
			if($isshangjia){
				$shangjiadesc = cutstr(strip_tags(htmlspecialchars_decode($isshangjia['desc'])),80);
				$shangjiaqrcode = DB::result_first("SELECT weixin_erweima FROM %t WHERE sid=%d AND status=2 ", array(
			"zimucms_chengshi114_renmai",
			$isshangjia['id']
			));
				if(!$isshangjia['addtime']){
				$shangjiayear = date('Y',$isshangjia['endtime']) - date('Y',$isshangjia['viptime']);
				}else{
				$shangjiayear = date('Y',$isshangjia['endtime']) - date('Y',$isshangjia['addtime']);
				}
				include template('zimucms_chengshi114:postshow');
				return $html;
			}
		}


	}
}