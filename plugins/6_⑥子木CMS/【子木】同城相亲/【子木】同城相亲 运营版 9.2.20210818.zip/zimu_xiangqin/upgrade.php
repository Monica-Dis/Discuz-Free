<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

    $sql1 = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_mptpl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tpl` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_users2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `nickname` char(50) NOT NULL,
  `photo` char(255) NOT NULL,
  `xueli` tinyint(2) UNSIGNED NOT NULL,
  `yuexin` tinyint(2) UNSIGNED NOT NULL,
  `birth` char(30) NOT NULL,
  `age` smallint(2) UNSIGNED NOT NULL,
  `shuxiang` tinyint(2) UNSIGNED NOT NULL,
  `constellation` tinyint(2) UNSIGNED NOT NULL,
  `city` char(20) NOT NULL,
  `city2` char(20) NOT NULL,
  `height` smallint(3) UNSIGNED NOT NULL,
  `weight` smallint(3) UNSIGNED NOT NULL,
  `ganqing` tinyint(1) UNSIGNED NOT NULL,
  `work` tinyint(2) UNSIGNED NOT NULL,
  `zhufang` tinyint(1) UNSIGNED NOT NULL,
  `gouche` tinyint(1) UNSIGNED NOT NULL,
  `xiyan` tinyint(1) UNSIGNED NOT NULL,
  `hejiu` tinyint(1) UNSIGNED NOT NULL,
  `weixin` char(30) NOT NULL,
  `mobile` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_kefu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(30) NOT NULL,
  `kefu_photo` char(255) NOT NULL,
  `kefu_mobile` char(20) NOT NULL,
  `kefu_wxid` char(20) NOT NULL,
  `kefu_qrcode_url` char(255) NOT NULL,
  `kefu_slogan` char(100) NOT NULL,
  `kefu_power` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_sendsmslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `con` varchar(300) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_qmhn_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(20) NOT NULL,
  `mobile` char(20) NOT NULL,
  `weixin` char(20) NOT NULL,
  `can_cash` int(10) UNSIGNED NOT NULL,
  `cash` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `tip` char(200) NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_qmhn_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `money` int(10) UNSIGNED NOT NULL,
  `type` char(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_activity` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `vip_price` int(10) UNSIGNED NOT NULL,
  `realname` tinyint(1) UNSIGNED NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `activitytime` int(10) UNSIGNED NOT NULL,
  `all_nums` int(10) UNSIGNED NOT NULL,
  `men_nums` int(10) UNSIGNED NOT NULL,
  `women_nums` int(10) UNSIGNED NOT NULL,
  `thumb` char(255) NOT NULL,
  `address` char(255) NOT NULL,
  `con` longtext NOT NULL,
  `url` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_xiangqin_activity_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL,
  `sex` tinyint(1) UNSIGNED NOT NULL,
  `photo` char(255) NOT NULL,
  `weixin` char(100) NOT NULL,
  `mobile` char(20) NOT NULL,
  `isvip` tinyint(1) UNSIGNED NOT NULL,
  `ispay` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

    runquery($sql1);

    if (!in_array('viewtime', zm_fieldexists('zimu_xiangqin_applyline'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_applyline` ADD `viewtime` INT(10) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('days2', zm_fieldexists('zimu_xiangqin_setmeal'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_setmeal` ADD `days2` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('refreshtime', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `refreshtime` INT(10) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('tip', zm_fieldexists('zimu_xiangqin_setmeal'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_setmeal` ADD `tip` CHAR(100) NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('bind_weixin', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `bind_weixin` TINYINT(1) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('hn_uid', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `hn_uid` INT(10) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('isindex', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `isindex` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('isqmhn', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `isqmhn` SMALLINT(3) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('qmhn_uid', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `qmhn_uid` INT(10) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('kefu_qrcode_url', zm_fieldexists('zimu_xiangqin_kefu'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_kefu` ADD `kefu_qrcode_url` CHAR(255) NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('tixian_log', zm_fieldexists('zimu_xiangqin_qmhn_user'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_qmhn_user` ADD `tixian_log` TEXT NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('url', zm_fieldexists('zimu_xiangqin_activity'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_activity` ADD `url` CHAR(255) NOT NULL;
EOF;
        runquery($sql1);
    }

    if (!in_array('line_num2', zm_fieldexists('zimu_xiangqin_users'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_xiangqin_users` ADD `line_num2` SMALLINT(5) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }


    deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/template/common/",true);
    deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/template/touch/",true);
    deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/template/admins/",true);
    deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_xiangqin/template/",true);
    @unlink(DISCUZ_ROOT . './source/plugin/zimu_xiangqin/lib/thinkorm/vendor/topthink/think-orm/src/Model.php70.php');
    @unlink(DISCUZ_ROOT . './source/plugin/zimu_xiangqin/.user.ini');

    $finish = TRUE;
    @unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3ppbXVfeGlhbmdxaW4vaDUvaW5kZXggY29weS5odG1s'));

    function zm_fieldexists($table){
        $field_list = DB::fetch_all("SHOW COLUMNS FROM %t", array($table));
        $field_list_array = mysqltoarray($field_list);
        return $field_list_array;
    }
    function mysqltoarray($test) {
        $temp = array();
        foreach ($test as $k => $s) {
            $temp[] = $s['Field'];
        }
        return $temp;
    }
    function deldirfile($directory, $empty = false) {
        if(substr($directory,-1) == "/") {
            $directory = substr($directory,0,-1);
        }

        if(!file_exists($directory) || !is_dir($directory)) {
            return false;
        } elseif(!is_readable($directory)) {
            return false;
        } else {
            @$directoryHandle = opendir($directory);

            while ($contents = @readdir($directoryHandle)) {
                if($contents != '.' && $contents != '..') {
                    $path = $directory . "/" . $contents;

                    if($contents != 'meta.htm' && $contents != 'footer_base.htm' && $contents != 'footer.htm' && $contents != 'header_base.htm' && $contents != 'success.htm'){

                        if(is_dir($path)) {
                            chmod($path,0755);
                            @deldirfile($path, $empty);
                        } else {
                            chmod($path,0755);
                            @unlink($path);
                        }
                    }


                }
            }

            @closedir($directoryHandle);

            if($empty == false) {
                if(!@rmdir($directory)) {
                    return false;
                }
            }

            return true;
        }
    }