<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_xiangqin/lib/', '',$_G['siteurl']);

    include_once DISCUZ_ROOT .'source/plugin/zimu_xiangqin/module/config.php';

    $notifydata = zimu_zhaopinnotifycheck();

    if($notifydata['validator']) {
        $order_id  = $notifydata['order_no'];
        if($order_id) {
            finish_order($order_id,$notifydata['trade_no']);
            $return = array(
                'return_code'=>'SUCCESS',
                'return_msg'=>'OK',
            );
            WxPayApiSF::replyNotify(zimu_zhaopin_arr2xml($return));
            exit();
        }
    }

    function zimu_zhaopinnotifycheck() {
        $_G = $GLOBALS['_G'];

        $msg = '';

        $notify = WxPayApiSF::notify($msg);

        if(empty($notify)){
            $return = array(
                'return_code'=>'FAIL',
                'return_msg'=>$msg,
            );
            WxPayApiSF::replyNotify(zimu_zhaopin_arr2xml($return));
            exit;
        }

        //checksign
        $sign = $notify['sign'];
        unset($notify['sign']);

        ksort($notify);
        $paramstring = ToUrlParams($notify);

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['zimu_xiangqin'];

        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_xiangqin_setting'
        ));

        $config['base'] = $setdata;
        $config['settings'] = unserialize($setdata['settings']);

        if(strtoupper(md5($paramstring . "&key=".$config['settings']['weixin_appsecret'])) != $sign){
            if(strtoupper(md5($paramstring . "&key=".$config['settings']['weixin_mchkey'])) != $sign) {
                $return = array(
                    'return_code' => 'FAIL',
                    'return_msg' => 'sign error!',
                );
                WxPayApiSF::replyNotify(zimu_zhaopin_arr2xml($return));
                exit;
            }
        }
        if($notify['result_code'] == 'SUCCESS') {
            return array(
                'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
                'order_no'   => $notify['out_trade_no'],
                'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
                'price'      => $notify['total_fee'],
                'appid'      => $notify['appid'],
                'notify'     => zimu_zhaopin_arr2xml(array('return_code'=>'SUCCESS')),
                'location'   => false,
                'fromopenid' => $notify['openid'],
            );
        }
    }


    function zimu_zhaopin_arr2xml($data){
        $xml = "<xml>";
        foreach ($data as $key=>$val)
        {
            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";
        return $xml;
    }

    function ToUrlParams($urlObj)
    {
        $buff = "";
        foreach ($urlObj as $k => $v)
        {
            $buff .= $k . "=" . $v . "&";
        }

        $buff = trim($buff, "&");
        return $buff;
    }