<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_xiangqin/lib/', '',$_G['siteurl'] );

include_once DISCUZ_ROOT .'source/plugin/zimu_xiangqin/module/config.php';

$trade_no = addslashes($_GET['trade_no']);
$userid = intval($_GET['userid']);


    $order = DB::fetch_first('select * from %t where oid=%s and payment=%s order by id desc', array(
        'zimu_xiangqin_order',
        $trade_no,
        'magapp'
    ));

    $order['params'] = $order['params']?unserialize($order['params']):array();

if($order['is_paid'] ==1 && $order['order_sn']){

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_xiangqin_parameter2',
    'magapp'
));
$mag_paramter = unserialize($mag_paramter['parameter']);

			$mag_url = $mag_paramter['magapp_hostname'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$order['order_sn'].'&secret='.$mag_paramter['magapp_secret'];
            $mag_ret = json_decode(lizimu_post($mag_url,''),true);
			if ($mag_ret['paycode']==1) {

    if($order && $order['is_paid'] == 1) {
        finish_order($trade_no, $order['order_sn']);
    }

			}



}






echo 'SUCCESS';
EXIT;