!function() {
    function n(n) {
        if (!window.MagAndroidClient) {
            if (window.WebViewJavascriptBridge)
                return n(WebViewJavascriptBridge);
            if (document.addEventListener("WebViewJavascriptBridgeReady", function(i) {
                n(WebViewJavascriptBridge)
            }, !1), window.WVJBCallbacks)
                return window.WVJBCallbacks.push(n);
            window.WVJBCallbacks = [n];
            var myuseragent = navigator.userAgent.toLowerCase();
            if(myuseragent.indexOf('magapp') != -1){
                var i = document.createElement("iframe");
                i.style.display = "none",
                i.src = "https://__bridge_loaded__",
                document.documentElement.appendChild(i),
                setTimeout(function() {
                    document.documentElement.removeChild(i)
                }, 0)
            }
        }
    }
    n(function(n) {
        n.init && "function" == typeof n.init && n.init(function(n, i) {}),
        n.registerHandler("jsCallBack", function(n, i) {
            var o = JSON.parse(n),
                a = o.id,
                e = o.val,
                t = mag.callbacks[a];
            t && (t.type && "json" == t.type && e && (e = JSON.parse(e)), t.success(e))
        })
    }),
    mag = {
        VERSION: "1.1",
        ready: function(i) {
            n(function() {
                i()
            }),
            window.MagAndroidClient && i()
        },
        callbacks: {},
        iosConnect: n,
        jsCallBack: function(n, i) {
            var o = mag.callbacks[n];
            o && (o.type && "json" == o.type && i && (i = JSON.parse(i)), o.success(i))
        },
        getLocation: function(i) {
            i && (mag.callbacks.getLocation = {
                type: "json",
                success: i
            }, window.MagAndroidClient && window.MagAndroidClient.getLocation(), n(function(n) {
                n.callHandler("getLocation", "", function(n) {})
            }))
        },
        mapPick: function(i) {
            i && (mag.callbacks.mapPick = {
                type: "json",
                success: i
            }, window.MagAndroidClient && window.MagAndroidClient.mapPick(), n(function(n) {
                n.callHandler("mapPick", "", function() {})
            }))
        },
        closeWin: function() {
            window.MagAndroidClient && window.MagAndroidClient.closeWin(),
            n(function(n) {
                n.callHandler("closeWin", "", function(n) {})
            })
        },
        previewImage: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.previewImage(o),
            n(function(n) {
                n.callHandler("previewImage", o, function(n) {})
            })
        },
        picPick: function(i) {
            mag.callbacks.picPickPreview = {
                type: "json",
                success: i.preview
            },
            mag.callbacks.picPickSuccess = {
                type: "json",
                success: i.success
            },
            mag.callbacks.picPickFail = {
                type: "json",
                success: i.fail
            };
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.picPick(o),
            n(function(n) {
                n.callHandler("picPick", o, function(n) {})
            })
        },
        camera: function(i) {
            mag.callbacks.cameraPreview = {
                type: "json",
                success: i.preview
            },
            mag.callbacks.cameraSuccess = {
                type: "json",
                success: i.success
            },
            mag.callbacks.cameraFail = {
                type: "json",
                success: i.fail
            };
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.camera(o),
            n(function(n) {
                n.callHandler("camera", o, function(n) {})
            })
        },
        setData: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.setData(o),
            n(function(n) {
                n.callHandler("setData", o, function(n) {})
            })
        },
        share: function(i, o, a) {
            mag.callbacks.shareSuccess = {
                type: "",
                success: o
            },
            mag.callbacks.shareFailed = {
                type: "",
                success: a
            },
            window.MagAndroidClient && window.MagAndroidClient.share(i),
            n(function(n) {
                n.callHandler("share", i, function(n) {})
            })
        },
        shareCard: function(i, o, a) {
            mag.callbacks.shareSuccess = {
                type: "",
                success: o
            },
            mag.callbacks.shareFailed = {
                type: "",
                success: a
            };
            var e = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.shareCard(e),
            n(function(n) {
                n.callHandler("shareCard", e, function(n) {})
            })
        },
        socialBind: function(i, o, a) {
            mag.callbacks.bindOnSuccess = {
                type: "json",
                success: o
            },
            mag.callbacks.bindOnFail = {
                type: "json",
                success: a
            },
            window.MagAndroidClient && window.MagAndroidClient.socialBind(i),
            n(function(n) {
                n.callHandler("socialBind", i, function(n) {})
            })
        },
        report: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.report(o),
            n(function(n) {
                n.callHandler("report", o, function(n) {})
            })
        },
        scanQR: function(i) {
            i && (mag.callbacks.scanQR = {
                type: "",
                success: i
            }, window.MagAndroidClient && window.MagAndroidClient.scanQR(), n(function(n) {
                n.callHandler("scanQR", "", function(n) {})
            }))
        },
        actionSheet: function(i, o) {
            if (o) {
                var a = JSON.stringify(i);
                mag.callbacks.actionSheet = {
                    type: "json",
                    success: o
                },
                window.MagAndroidClient && window.MagAndroidClient.actionSheet(a),
                n(function(n) {
                    n.callHandler("actionSheet", a, function(n) {})
                })
            }
        },
        toast: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.toast(i),
            n(function(n) {
                n.callHandler("toast", i, function(n) {})
            })
        },
        dialog: function(i) {
            var o = JSON.stringify(i);
            mag.callbacks.dialogSuccess = {
                type: "json",
                success: i.success
            },
            mag.callbacks.dialogCancel = {
                type: "json",
                success: i.cancel
            },
            window.MagAndroidClient && window.MagAndroidClient.dialog(o),
            n(function(n) {
                n.callHandler("dialog", o, function(n) {})
            })
        },
        progress: function() {
            window.MagAndroidClient && window.MagAndroidClient.progress(),
            n(function(n) {
                n.callHandler("progress", "", function(n) {})
            })
        },
        hideProgress: function() {
            window.MagAndroidClient && window.MagAndroidClient.hideProgress(),
            n(function(n) {
                n.callHandler("hideProgress", "", function(n) {})
            })
        },
        setTitle: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.setTitle(i),
            n(function(n) {
                n.callHandler("setTitle", i, function(n) {})
            })
        },
        showNavigation: function() {
            window.MagAndroidClient && window.MagAndroidClient.showNavigation(),
            n(function(n) {
                n.callHandler("showNavigation", "", function(n) {})
            })
        },
        hideNavigation: function() {
            window.MagAndroidClient && window.MagAndroidClient.hideNavigation(),
            n(function(n) {
                n.callHandler("hideNavigation", "", function(n) {})
            })
        },
        setNavigationColor: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.setNavigationColor(i),
            n(function(n) {
                n.callHandler("setNavigationColor", i, function(n) {})
            })
        },
        hideMore: function() {
            window.MagAndroidClient && window.MagAndroidClient.hideMore(),
            n(function(n) {
                n.callHandler("hideMore", "", function(n) {})
            })
        },
        showMore: function() {
            window.MagAndroidClient && window.MagAndroidClient.showMore(),
            n(function(n) {
                n.callHandler("showMore", "", function(n) {})
            })
        },
        tel: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.tel(i),
            n(function(n) {
                n.callHandler("tel", i, function(n) {})
            })
        },
        sms: function(i, o) {
            var a = JSON.stringify({
                phone: i,
                content: o
            });
            window.MagAndroidClient && window.MagAndroidClient.sms(a),
            n(function(n) {
                n.callHandler("sms", a, function(n) {})
            })
        },
        toLogin: function(i) {
            mag.callbacks.loginSuccess = {
                type: "json",
                success: i
            },
            window.MagAndroidClient && window.MagAndroidClient.toLogin(),
            n(function(n) {
                n.callHandler("toLogin", "", function(n) {})
            })
        },
        toUserHome: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.toUserHome(i),
            n(function(n) {
                n.callHandler("toUserHome", i, function(n) {})
            })
        },
        addRedPacket: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.addRedPacket(i),
            n(function(n) {
                n.callHandler("addRedPacket", i, function(n) {})
            })
        },
        showApplaud: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.showApplaud(i),
            n(function(n) {
                n.callHandler("showApplaud", i, function(n) {})
            })
        },
        toUserHomeByName: function(i) {
            i && (window.MagAndroidClient && window.MagAndroidClient.toUserHomeByName(i), n(function(n) {
                n.callHandler("toUserHomeByName", i, function(n) {})
            }))
        },
        commentBar: function(i) {
            var o = JSON.stringify(i);
            i.onComment && (mag.callbacks.commentBar = {
                type: "json",
                success: i.onComment
            }),
            i.onCommentShow && (mag.callbacks.onCommentShow = {
                type: "",
                success: i.onCommentShow
            }),
            i.onPageSelect && (mag.callbacks.pageSelect = {
                type: "json",
                success: i.onPageSelect
            }),
            i.onApplaud && (mag.callbacks.applaud = {
                type: "json",
                success: i.onApplaud
            }),
            window.MagAndroidClient && window.MagAndroidClient.commentBar(o),
            n(function(n) {
                n.callHandler("commentBar", o, function(n) {})
            })
        },
        toComment: function(i) {
            var o = JSON.stringify(i);
            i.success && (mag.callbacks.comment = {
                type: "json",
                success: i.success
            }),
            window.MagAndroidClient && window.MagAndroidClient.toComment(o),
            n(function(n) {
                n.callHandler("toComment", o, function(n) {})
            })
        },
        newWin: function(i, o) {
            i.indexOf("?") < 0 && (i += "?");
            for (var a in o)
                i += "&" + a + "=" + o[a];
            window.MagAndroidClient && window.MagAndroidClient.newWin(i),
            n(function(n) {
                n.callHandler("newWin", i, function(n) {})
            })
        },
        setPageLife: function(n) {
            mag.callbacks.pageAppear = {
                type: "",
                success: n.pageAppear
            },
            mag.callbacks.pageDisappear = {
                type: "",
                success: n.pageDisappear
            }
        },
        followAuthorFromNative: function(n) {
            mag.callbacks.followAuthorFromNative = {
                type: "",
                success: n.followAuthorFromNative
            }
        },
        availableSharePlatform: function(i) {
            mag.callbacks.availableSharePlatform = {
                type: "json",
                success: i.availableSharePlatform
            },
            window.MagAndroidClient && window.MagAndroidClient.availableSharePlatform(),
            n(function(n) {
                n.callHandler("availableSharePlatform", "", function(n) {})
            })
        },
        pay: function(i, o, a) {
            mag.callbacks.payOnSuccess = {
                type: "",
                success: o
            },
            mag.callbacks.payOnFail = {
                type: "",
                success: a
            };
            var e = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.pay(e),
            n(function(n) {
                n.callHandler("pay", e, function(n) {})
            })
        },
        alipay: function(i, o, a) {
            if (!i)
                return !1;
            mag.callbacks.alipayOnSuccess = {
                type: "",
                success: o
            },
            mag.callbacks.alipayOnFail = {
                type: "",
                success: a
            },
            window.MagAndroidClient && window.MagAndroidClient.alipay(i),
            n(function(n) {
                n.callHandler("alipay", i, function(n) {})
            })
        },
        inAppPay: function(i, o, a) {
            mag.callbacks.inAppPaySuccess = {
                type: "",
                success: o
            },
            mag.callbacks.inAppPayOnFail = {
                type: "",
                success: a
            };
            var e = JSON.stringify(i);
            n(function(n) {
                n.callHandler("inAppPay", e, function(n) {})
            })
        },
        deviceLogin: function(i) {
            mag.callbacks.loginSuccess = {
                type: "json",
                success: i
            },
            n(function(n) {
                n.callHandler("deviceLogin", "", function(n) {})
            })
        },
        phoneBind: function(i) {
            mag.callbacks.phoneBindSuccess = {
                type: "string",
                success: i
            },
            window.MagAndroidClient && window.MagAndroidClient.phoneBind(),
            n(function(n) {
                n.callHandler("phoneBind", "", function(n) {})
            })
        },
        qqConnectLogin: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.qqConnectLogin(i),
            n(function(n) {
                n.callHandler("qqConnectLogin", i, function(n) {})
            })
        },
        bounceEnable: function(i) {
            n(function(n) {
                n.callHandler("bounceEnable", i, function(n) {})
            })
        },
        showNaviAuthor: function() {
            window.MagAndroidClient && window.MagAndroidClient.showNaviAuthor(),
            n(function(n) {
                n.callHandler("showNaviAuthor", "", function(n) {})
            })
        },
        hideNaviAuthor: function() {
            window.MagAndroidClient && window.MagAndroidClient.hideNaviAuthor(),
            n(function(n) {
                n.callHandler("hideNaviAuthor", "", function(n) {})
            })
        },
        followAuthorFromWeb: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.followAuthorFromWeb(i),
            n(function(n) {
                n.callHandler("followAuthorFromWeb", i, function(n) {})
            })
        },
        setSwipeBackDisable: function() {
            window.MagAndroidClient && window.MagAndroidClient.setSwipeBackDisable(),
            n(function() {
                bridge.callHandler("setSwipeBackDisable", function(n) {})
            })
        },
        setSwipeBackEnable: function() {
            window.MagAndroidClient && window.MagAndroidClient.setSwipeBackEnable(),
            n(function() {
                bridge.callHandler("setSwipeBackEnable", function(n) {})
            })
        },
        addRefreshComponent: function() {
            window.MagAndroidClient && window.MagAndroidClient.addRefreshComponent(),
            n(function(n) {
                n.callHandler("addRefreshComponent", "", function(n) {})
            })
        },
        sappHome: function(i) {
            window.MagAndroidClient && window.MagAndroidClient.sappHome(i),
            n(function(n) {
                n.callHandler("sappHome", i, function(n) {})
            })
        },
        chat: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.chat(o),
            n(function(n) {
                n.callHandler("chat", o, function(n) {})
            })
        },
        newExternalWin: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.newExternalWin(o),
            n(function(n) {
                n.callHandler("newExternalWin", o, function(n) {})
            })
        },
        getAppAuthKey: function(i) {
            i && (mag.callbacks.getAppAuthKey = {
                type: "json",
                success: i
            }, window.MagAndroidClient && window.MagAndroidClient.getAppAuthKey(), n(function(n) {
                n.callHandler("getAppAuthKey", "", function(n) {})
            }))
        },
        sendGift: function(i, o) {
            var a = JSON.stringify(i);
            mag.callbacks.giftSendSuccess = {
                type: "json",
                success: o
            },
            window.MagAndroidClient && window.MagAndroidClient.sendGift(a),
            n(function(n) {
                n.callHandler("sendGift", a, function(n) {})
            })
        },
        showPhoneSettings: function() {
            n(function(n) {
                n.callHandler("showPhoneSettings", "", function(n) {})
            })
        },
        getNotificationStatus: function(i) {
            mag.callbacks.getNotificationStatus = {
                type: "string",
                success: i
            },
            n(function(n) {
                n.callHandler("getNotificationStatus", "", function(n) {})
            })
        },
        downloadAttachment: function(i) {
            var o = JSON.stringify(i);
            window.MagAndroidClient && window.MagAndroidClient.downloadAttachment(o),
            n(function(n) {
                n.callHandler("downloadAttachment", o, function(n) {})
            })
        },
        getNetworkState: function(i) {
            mag.callbacks.getNetworkState = {
                type: "string",
                success: i
            },
            window.MagAndroidClient && window.MagAndroidClient.getNetworkState(),
            n(function(n) {
                n.callHandler("getNetworkState", "", function(n) {})
            })
        },
        getDeviceId: function(i) {
            mag.callbacks.getDeviceId = {
                type: "string",
                success: i
            },
            window.MagAndroidClient && window.MagAndroidClient.getDeviceId(),
            n(function(n) {
                n.callHandler("getDeviceId", "", function(n) {})
            })
        }
    },
    window.mag = mag,
    mag.VERSION = "1.3.2"
}();