<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    global $_G;
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $ids = intval($_GET['ids']);

    if($op == 'tofav') {

        $touid = intval($_GET['touid']);
        $isfav = intval($_GET['isfav']);
        if ($isfav == 1) {
            $data = ['uid' => $myuid['uid'], 'touid' => $touid, 'addtime' => $_G['timestamp']];
            Db::name('zimu_xiangqin_users_fav')->insert($data);

        } else {
            Db::name('zimu_xiangqin_users_fav')->where(['uid' => $myuid['uid'], 'touid' => $touid])->delete();
        }

        zimu_json('','ok');

    }elseif ($op=='jubao'){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        $jubao_data['uid'] = $myuid['uid'];
        $jubao_data['username'] = $myinfo['nickname'];
        $jubao_data['touid'] = intval($_GET['touid']);
        $tomyinfo = Db::name('zimu_xiangqin_users')->where('uid', $jubao_data['touid'])->find();
        $jubao_data['tousername'] = $tomyinfo['nickname'];
        $jubao_data['type'] = addslashes(strip_tags($zimu_get['type']));
        $jubao_data['con'] = addslashes(strip_tags($zimu_get['con']));
        $jubao_data['myname'] = addslashes(strip_tags($zimu_get['myname']));
        $jubao_data['myphone'] = addslashes(strip_tags($zimu_get['myphone']));
        $jubao_data['ip'] = $_G['clientip'];
        $jubao_data['addtime'] = $_G['timestamp'];
        Db::name('zimu_xiangqin_jubao')->insert($jubao_data);

        zimu_json('','ok');

    }elseif ($op=='applyline'){

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
        $paramters = unserialize($paramter['parameter']);

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        $applyline_data['uid'] = $myuid['uid'];
        $applyline_data['username'] = $myinfo['nickname'];
        $applyline_data['touid'] = intval($_GET['touid']);
        $tomyinfo = Db::name('zimu_xiangqin_users')->where('uid', $applyline_data['touid'])->find();
        $applyline_data['tousername'] = $tomyinfo['nickname'];
        $applyline_data['hn_id'] = $myinfo['hn_id'];
        $applyline_data['hn_name'] = $myinfo['hn_name'];
        $applyline_data['status'] = 1;
        $applyline_data['applytime'] = $_G['timestamp'];
        Db::name('zimu_xiangqin_applyline')->insert($applyline_data);

        if($myinfo['line_num']){
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->dec('line_num')->update();
        }else{
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->dec('line_num2')->update();
        }

        if($zmdata['settings']['line_type']==1){

        notification_user_sms($tomyinfo,'chanyoo_sms_tp1');

        $first = $language_zimu['details_inc_php_0'];
        $keyword1 = $language_zimu['details_inc_php_1'];
        $keyword3 = $language_zimu['details_inc_php_2'];

        $templatedata = array(
            'first' => array(
                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                'color' => "#FF4040"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($applyline_data['tousername'], CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => date('Y-m-d H:i', $_G['timestamp'])
            )
        );
        notification_user($applyline_data['touid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid']);

        $magcon = '{"tag":"'.$keyword1.'","title":"'.$first.'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid'].'","extra_info":[{"key":"'.$language_zimu['details_inc_php_3'].'","val":"'.$keyword3.'"}],"des":"'.$language_zimu['details_inc_php_4'].'","des_themecolor":"#008000"}';

        notification_user_magapp($applyline_data['touid'], $magcon);

        $qfcon['msg'] = $first;
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title'=>diconv($keyword1, CHARSET, 'utf-8'),
            'date'=>date('Y-m-d H:i:s'),
            'setting'=>array(),
            'content' => diconv($keyword3,CHARSET,'UTF-8'),
            'url'=>ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid']
        );
        notification_user_qfapp($applyline_data['touid'], $qfcon);

        }else{

            $first = $language_zimu['details_inc_php_5'];
            $keyword1 = $language_zimu['details_inc_php_6'];
            $keyword3 = $language_zimu['details_inc_php_7'];

            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv($applyline_data['tousername'], CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i', $_G['timestamp'])
                )
            );
            notification_user('admin', $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid']);

            $magcon = '{"tag":"'.$keyword1.'","title":"'.$first.'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid'].'","extra_info":[{"key":"'.$language_zimu['details_inc_php_8'].'","val":"'.$keyword3.'"}],"des":"'.$language_zimu['details_inc_php_9'].'","des_themecolor":"#008000"}';

            notification_user_magapp('admin', $magcon);

            $qfcon['msg'] = $first;
            $qfcon['showdata'] = '';
            $qfcon['showdata'] = array(
                'title'=>diconv($keyword1, CHARSET, 'utf-8'),
                'date'=>date('Y-m-d H:i:s'),
                'setting'=>array(),
                'content' => diconv($keyword3,CHARSET,'UTF-8'),
                'url'=>ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid']
            );
            notification_user_qfapp('admin', $qfcon);


        }

        $first = $language_zimu['details_inc_php_10'];
        $keyword1 = $language_zimu['details_inc_php_11'];
        $keyword2 = $language_zimu['details_inc_php_12'];
        $keyword3 = $language_zimu['details_inc_php_13'];
        $remark = $language_zimu['details_inc_php_14'].'UID'.$applyline_data['uid'];
        $tourl = ZIMUCMS_URL2.'pages/index/details?ids='.$applyline_data['uid'];
        $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);
        notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

        zimu_json('','ok');

    }else {

        $info['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();

        if ($info['myinfo']['vip_type'] > 0 && $info['myinfo']['vip_etime'] < time() ) {
            $info['myinfo']['vip_type'] = 0;
            $vip_data['vip_type'] = 0;
            $crm_feedback['uid']     = $info['myinfo']['uid'];
            $crm_feedback['note']       = $language_zimu['details_inc_php_15'].$info['myinfo']['vip_name'].$language_zimu['details_inc_php_16'].date('Y-m-d H:i',$info['myinfo']['vip_etime']).$language_zimu['details_inc_php_17'].$info['myinfo']['line_num'].$language_zimu['details_inc_php_18'];
            $crm_feedback['addtime']     = time();
            Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
            $vip_data['line_num'] = 0;
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update($vip_data);
            $info['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        }


        $info['myinfo']['line_num'] = $info['myinfo']['line_num'] + $info['myinfo']['line_num2'];

        $info['details'] = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();
        $info['details']['birth'] = zm_cutstr($info['details']['birth'],4,'');
        $info['album'] = Db::name('zimu_xiangqin_users_album')->where('uid', $ids)->order(id, asc)->select()->toArray();

        foreach ($info['album'] as $key => $value) {
            if($info['myinfo']['vip_type'] == 0 && $zmdata['settings']['novip_nums']>0 &&$key >= $zmdata['settings']['novip_nums']){
                $info['album2'][$key] = ZIMUCMS_PATH.'static/wap/image/noreadablum.jpg';
            }else{
                $info['album2'][$key] = $value['url'];
            }
        }

        $info['ideal'] = Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->find();

        $info['isfav'] = Db::name('zimu_xiangqin_users_fav')->where(['uid' => $myuid['uid'], 'touid' => $ids])->find();

        $info['linestatus'] = Db::name('zimu_xiangqin_applyline')->where([['uid','=',$myuid['uid']],['touid','=',$ids],['applytime','>',time()-345600]])->order(id, desc)->findOrEmpty();

        if(!$info['linestatus'] && $zmdata['settings']['toline_limit']){

            $linestatus4 = Db::name('zimu_xiangqin_applyline')->where([['uid','=',$myuid['uid']],['touid','=',$ids],['status','=',4]])->count();
            if($linestatus4 >= $zmdata['settings']['toline_limit']){
                $info['linestatus']['status'] = 4;
            }

        }



        if($info['linestatus']['status'] != 3){
            $is_to_line = Db::name('zimu_xiangqin_applyline')->where([['touid','=',$myuid['uid']],['uid','=',$ids],['applytime','>',time()-345600],['status','=',3]])->order(id, desc)->findOrEmpty();
            if($is_to_line){
                $info['linestatus']['status'] = 3;
            }
        }

        $info['linestatus2'] = Db::name('zimu_xiangqin_applyline')->where(['touid' => $myuid['uid'], 'uid' => $ids])->order(id, desc)->findOrEmpty();

        if($info['linestatus2']['id'] && $info['linestatus2']['status'] == 1){

            Db::name('zimu_xiangqin_applyline')->where('id', $info['linestatus2']['id'])->update(['status' => 2,'viewtime' => time()]);

        }

        $info['baodeng'] = Db::name('zimu_xiangqin_baodeng')->where('touid', $ids)->order(id, asc)->select();

        $info['zmdata'] = $zmdata2;

        $info['details']['real'] = Db::name('zimu_xiangqin_reallog')->where(['uid' => $ids, 'status' => 1])->find();
        $info['details']['real']['realname'] = zm_cutstr($info['details']['real']['realname'],2,'');
        $info['details']['real']['idcard'] = zm_cutstr($info['details']['real']['idcard'],10,'');

        if ($info['details']['vip_etime'] < time() ) {
            $info['details']['vip_type'] = 0;
        }

        if($ids != $myuid['uid'] && $info['details']['id']) {
            $isviewlog = Db::name('zimu_xiangqin_viewlog')->where(['uid' => $myuid['uid'], 'touid' => $ids])->find();
            if ($isviewlog) {
                Db::name('zimu_xiangqin_viewlog')->where(['uid' => $myuid['uid'], 'touid' => $ids])->inc('views')->update(['addtime' => $_G['timestamp']]);
            } else {
                Db::name('zimu_xiangqin_viewlog')->insert(['uid' => $myuid['uid'], 'touid' => $ids, 'views' => 1, 'addtime' => $_G['timestamp']]);
            }
        }

        if($info['myinfo']['sex']==2 && $info['zmdata']['settings']['line_price2']>0){
            $info['zmdata']['settings']['line_price'] = $info['zmdata']['settings']['line_price2'];
        }
        if($info['myinfo']['sex']==2 && $info['zmdata']['settings']['baodeng_money2']>0){
            $info['zmdata']['settings']['baodeng_money'] = $info['zmdata']['settings']['baodeng_money2'];
        }

        if ($info['myinfo']['vip_etime'] < time() ) {
            $info['myinfo']['vip_type'] = 0;
        }

        $info['linetip'] = Db::name('zimu_xiangqin_applyline')->where([['touid','=',$myuid['uid']],['status','>',0],['status','<',3]])->order('id','asc')->find();

        $manage_uids = explode(',', $zmdata['manage_uids']);

        if(in_array($myuid['uid'],$manage_uids)){
            $info['myinfo']['admins'] = 1;
        }

        $iskefu = Db::name('zimu_xiangqin_kefu')->where(['uid' => $myuid['uid']])->find();
        if($iskefu['id']){
            $info['myinfo']['admins'] = 1;
            if($iskefu['kefu_power']==1) {
                $ishongniang = Db::name('zimu_xiangqin_users')->where(['uid' => $ids, 'hn_uid' => $myuid['uid']])->find();
                if ($ishongniang['id']) {
                    $info['myinfo']['hongniang'] = 1;
                }
            }else{
                $info['myinfo']['hongniang'] = 1;
            }
        }

        if($zmdata['settings']['diy_mycity']){
            $citys = json_decode(zimu_array_utf8($zmdata['settings']['diy_mycity']),true);
            $info['citys'] = zimu_array_gbk2($citys);
        }

        if($info['myinfo']['admins'] != 1 && $info['myinfo']['hongniang'] != 1 && $info['linestatus']['status'] != 3){
            $info['details']['weixin'] = 'zimu';
            $info['details']['mobile'] = '13288888888';
        }

        if($info['details']['hn_uid']){
            $info['details']['hn'] = Db::name('zimu_xiangqin_kefu')->where(['uid' => $info['details']['hn_uid']])->find();
        }else{
            $info['details']['hn']['kefu_name'] = $zmdata['settings']['hn_name'];
            $info['details']['hn']['kefu_wxid'] = $zmdata['settings']['hn_weixin'];
            $info['details']['hn']['kefu_qrcode_url'] = $zmdata['settings']['hn_qrcode_url'];
        }

        $newage = 2021 - $info['details']['birth'];
        if($info['details']['birth'] != $newage && $info['details']['birth']){
            $info['details']['age'] = $newage;
            Db::name('zimu_xiangqin_users')->where('uid', $ids)->update(['age' => $newage]);
        }

        $info['details']['close_oneline'] = intval($zmdata['settings']['close_oneline']);

        zimu_json($info);

    }
