<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);

    if($op == 'update_status' ) {

    } else if ($op == 'set_hnsay') {

        $ids = intval($_GET['ids']);
        $hnsay = strip_tags($_GET['hnsay']);

        Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update(['hn_say' => zimu_array_gbk($hnsay)]);
        zimu_json('',$language_zimu['hongniang_inc_php_0']);

    } else if ($op == 'crm_feedback') {

        $ids    = intval($_GET['ids']);
        $crm_feedback['uid']     = $ids;
        $crm_feedback['note']       = zm_diconv(trim($_GET['note']));
        $crm_feedback['addtime']     = $_G['timestamp'];
        $crm_feedback['hn_uid']       = intval($_GET['hn_uid']);
        $crm_feedback['hn_name']       = zm_diconv(trim($_GET['hn_name']));
        Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);

        zimu_json('',$language_zimu['hongniang_inc_php_1']);

    } else if ($op == 'linerecord') {

        $res['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();

        if($res['kefu']['kefu_power']==1) {
            $wheresql[] = ['hn_uid', '=', $myuid['uid']];
        }
        $res['kefu']['total1'] = Db::name('zimu_xiangqin_users')->where($wheresql)->count();
        $mykefu = Db::name('zimu_xiangqin_users')->where($wheresql)->column('uid');

        $res['kefu']['status2'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',1)->count();
        $res['kefu']['status3'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',2)->count();
        $res['kefu']['status4'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',3)->count();
        $res['kefu']['status5'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',4)->count();


        $wheresql2[] = ['status', '>', 0];

        $status = intval($_GET['status']);
        if (!empty($status)) {
            $wheresql2[] = ['status', '=', ($status-1)];
        }

        $res['list'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where($wheresql2)->order(['id'=>'desc'])->page($page,10)->select()->toArray();

        foreach ($res['list'] as $key => $value) {
            $res['list'][$key]['applytime_cn'] = date('Y-m-d H:i',$value['applytime']);
            $res['list'][$key]['endtime_cn'] = date('Y-m-d H:i',$value['endtime']);
            $res['list'][$key]['uid_info'] = Db::name('zimu_xiangqin_users')->where('uid', $value['uid'])->find();
            $res['list'][$key]['touid_info'] = Db::name('zimu_xiangqin_users')->where('uid', $value['touid'])->find();
        }

        zimu_json($res);

    } else if ($op == 'changeline') {

        $ids = intval($_GET['ids']);
        $line_note = zimu_array_gbk(strip_tags($_GET['line_note']));
        $linestatus = intval($_GET['linestatus']);
        $hn_name = zimu_array_gbk(strip_tags($_GET['hn_name']));
        $hn_id = intval($_GET['hn_id']);

        $lineuid = Db::name('zimu_xiangqin_applyline')->where('id', $ids)->find();

        $smsinfo = Db::name('zimu_xiangqin_users')->where('uid', $lineuid['uid'])->find();

        if($linestatus==3 || $linestatus==4){

            Db::name('zimu_xiangqin_applyline')->where('id' ,$ids)->update(['status' => $linestatus,'endtime' => time(),'hn_id' => $hn_id,'hn_name' => $hn_name]);

            if($linestatus==3) {

                $first = $language_zimu['hongniang_inc_php_2'];
                $keyword1 = $language_zimu['hongniang_inc_php_3'];
                $keyword2 = $lineuid['username'];
                $keyword3 = $lineuid['tousername'].$language_zimu['hongniang_inc_php_4'];
                $remark = $language_zimu['hongniang_inc_php_5'];
                $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$lineuid['touid'].'&mobile=2';
                $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                notification_all($lineuid['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                notification_user_sms($smsinfo, 'chanyoo_sms_tp2');
            }

            if($linestatus==4){

                $first = $language_zimu['hongniang_inc_php_6'];
                $keyword1 = $language_zimu['hongniang_inc_php_7'];
                $keyword2 = $lineuid['username'];
                $keyword3 = $lineuid['tousername'].$language_zimu['hongniang_inc_php_8'];
                $remark = $language_zimu['hongniang_inc_php_9'];
                $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/';
                $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                notification_all($lineuid['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                if(!$zmdata['settings']['line_back']) {
                    Db::name('zimu_xiangqin_users')->where('uid', $lineuid['uid'])->update(['line_num' => Db::raw('line_num+1')]);
                    $crm_feedback['uid']     = $lineuid['uid'];
                    $crm_feedback['note']       = $language_zimu['hongniang_inc_php_10'];
                    $crm_feedback['addtime']     = time();
                    Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
                }
                notification_user_sms($smsinfo,'chanyoo_sms_tp3');
            }
        }else{
            Db::name('zimu_xiangqin_applyline')->where('id' ,$ids)->update(['status' => $linestatus,'hn_id' => $hn_id,'hn_name' => $hn_name]);
        }

        zimu_json('',$language_zimu['hongniang_inc_php_11']);

    } else if ($op == 'shaixuan') {


        $res['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();

        if($res['kefu']['kefu_power']==1) {
            $wheresql[] = ['hn_uid', '=', $myuid['uid']];
        }

        $state = intval($_GET['state']);
        if (!empty($state) && $state !=4 ) {
            $wheresql[] = ['state','=',($state-1)];
        }

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);
        $nocity = intval($selecttxt['nocity']);

        if($selecttxt['keywords']){
            //$whereorsql = 'nickname|no','like','%'.$selecttxt['keywords'].'%';
            $whereorsql = '\'nickname|no\',\'like\',\'%\'.$selecttxt[\'keywords\'].\'%\'';
        }
        if($selecttxt['sex']){
            $wheresql[] = ['sex','=',$selecttxt['sex']];
        }
        if($selecttxt['ageStart']){
            $wheresql[] = ['age','>=',$selecttxt['ageStart']];
        }
        if($selecttxt['ageEnd']){
            $wheresql[] = ['age','<=',$selecttxt['ageEnd']];
        }
        if($selecttxt['heightStart']){
            $wheresql[] = ['height','>=',$selecttxt['heightStart']];
        }
        if($selecttxt['heightEnd']){
            $wheresql[] = ['height','<=',$selecttxt['heightEnd']];
        }
        if($selecttxt['xueli']){
            $wheresql[] = ['xueli','>=',$selecttxt['xueli']];
        }
        if($selecttxt['work']){
            $wheresql[] = ['work','=',$selecttxt['work']];
        }
        if($selecttxt['yuexin']){
            $wheresql[] = ['yuexin','>=',$selecttxt['yuexin']];
        }
        if($selecttxt['ganqing']){
            $wheresql[] = ['ganqing','=',$selecttxt['ganqing']];
        }
        if($selecttxt['real']){
            $wheresql[] = ['real_state','=',1];
        }
        if($selecttxt['vip']){
            $wheresql[] = ['vip_type','>',0];
        }


        $res['list'] = Db::name('zimu_xiangqin_users')->where($wheresql)->order(['id'=>'desc'])->page($page,1000)->select()->toArray();

        $ids = intval($_GET['ids']);
        if($ids && $page==1){
            $edituser = Db::name('zimu_xiangqin_users')->where('uid', $ids)->select()->toArray();
            $res['list'] = array_merge($edituser,$res['list']);
        }


        foreach ($res['list'] as $key => $value) {
            $res['list'][$key]['addtime_cn'] = date('Y-m-d H:i',$value['addtime']);
            $res['list'][$key]['feedbacklist'] = Db::name('zimu_xiangqin_feedback')->where('uid', $value['uid'])->order(['id'=>'desc'])->select()->toArray();
            $res['list'][$key]['loglist'] = Db::name('zimu_xiangqin_applyline')->where(['uid'=>$value['uid']])->order(['id'=>'desc'])->select()->toArray();
            foreach ($res['list'][$key]['loglist'] as $key2 => $value2) {
                $res['list'][$key]['loglist'][$key2]['applytime_cn'] = date('Y-m-d',$value2['applytime']);
                $res['list'][$key]['loglist'][$key2]['endtime_cn'] = date('Y-m-d',$value2['endtime']);
                $res['list'][$key]['loglist'][$key2]['info'] = getmyinfo($value2['touid']);
            }
        }

        zimu_json($res);



    }else{

        $res['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();

        if($res['kefu']['kefu_power']==1) {
            $wheresql[] = ['hn_uid', '=', $myuid['uid']];
        }

        $res['kefu']['total1'] = Db::name('zimu_xiangqin_users')->where($wheresql)->count();
        $res['kefu']['total2'] = Db::name('zimu_xiangqin_users')->where($wheresql)->where('state',0)->count();

        $mykefu = Db::name('zimu_xiangqin_users')->where($wheresql)->column('uid');

        $res['kefu']['status2'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',1)->count();
        $res['kefu']['status3'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',2)->count();
        $res['kefu']['status4'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',3)->count();
        $res['kefu']['status5'] = Db::name('zimu_xiangqin_applyline')->where('uid','in',$mykefu)->where('status',4)->count();

        $state = intval($_GET['state']);
        if (!empty($state) && $state !=4 ) {
            $wheresql[] = ['state','=',($state-1)];
        }

        $res['list'] = Db::name('zimu_xiangqin_users')->where($wheresql)->order(['id'=>'desc'])->page($page,10)->select()->toArray();

        $ids = intval($_GET['ids']);
        if($ids && $page==1){
            $edituser = Db::name('zimu_xiangqin_users')->where('uid', $ids)->select()->toArray();
            $res['list'] = array_merge($edituser,$res['list']);
        }


        foreach ($res['list'] as $key => $value) {
            $res['list'][$key]['addtime_cn'] = date('Y-m-d H:i',$value['addtime']);
            $res['list'][$key]['feedbacklist'] = Db::name('zimu_xiangqin_feedback')->where('uid', $value['uid'])->order(['id'=>'desc'])->select()->toArray();
            $res['list'][$key]['loglist'] = Db::name('zimu_xiangqin_applyline')->where(['uid'=>$value['uid']])->order(['id'=>'desc'])->select()->toArray();
            foreach ($res['list'][$key]['loglist'] as $key2 => $value2) {
                $res['list'][$key]['loglist'][$key2]['applytime_cn'] = date('Y-m-d',$value2['applytime']);
                $res['list'][$key]['loglist'][$key2]['endtime_cn'] = date('Y-m-d',$value2['endtime']);
                $res['list'][$key]['loglist'][$key2]['info'] = getmyinfo($value2['touid']);
            }
        }

        zimu_json($res);

    }