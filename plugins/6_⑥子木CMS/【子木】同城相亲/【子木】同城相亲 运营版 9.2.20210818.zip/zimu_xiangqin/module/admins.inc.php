<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    if(!$_G['uid']){
        dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode(ZIMUCMS_URL.'&model=admins'));
        exit();
    }

    $type = addslashes($_GET['type']);
    $type = !empty($type) ? $type : 'dashboard';

    $ac = addslashes($_GET['ac']);
    $ac = !empty($ac) ? $ac : 'index';

    $manage_uids = explode(',', $zmdata['manage_uids']);

    if(!in_array($_G['uid'],$manage_uids)){
        echo 'error';exit();
    }
    if($_G['uid'] == $manage_uids[0]){
        $manage_type = 'admins';
    }else{
        $manage_type = 'operator';
    }

    $title = $zmdata['settings']['title'].$language_zimu['admins_inc_php_0'];

    $noapplylist = DB::fetch_all('select * from %t where ( status = 1 or status = 2 ) and applytime < %d order by id asc', array(
        'zimu_xiangqin_applyline',
        time()-172800
    ));

    foreach ($noapplylist as $key => $value) {

        $smsinfo = DB::fetch_first('select * from %t where uid=%d', array(
            'zimu_xiangqin_users',
            $value['uid']
        ));

        DB::query("update %t set note=%s,status=%d,endtime=%d where id=%d", array(
            'zimu_xiangqin_applyline',
            $language_zimu['admins_inc_php_1'],
            4,
            time(),
            $value['id']
        ));
        if($zmdata['settings']['line_back']!=1){
            if($smsinfo['vip_type'] > 0 && $smsinfo['vip_etime'] > time() ){
                DB::query("update %t set line_num=line_num+1 where uid=%d", array(
                    'zimu_xiangqin_users',
                    $value['uid']
                ));
                $crm_feedback['uid']     = $value['uid'];
                $crm_feedback['note']       = $language_zimu['admins_inc_php_2'];
                $crm_feedback['addtime']     = time();
                DB::insert('zimu_xiangqin_feedback', $crm_feedback);
            }else{
                DB::query("update %t set line_num2=line_num2+1 where uid=%d", array(
                    'zimu_xiangqin_users',
                    $value['uid']
                ));
                $crm_feedback['uid']     = $value['uid'];
                $crm_feedback['note']       = $language_zimu['admins_inc_php_3'];
                $crm_feedback['addtime']     = time();
                DB::insert('zimu_xiangqin_feedback', $crm_feedback);
            }
        }

        notification_user_sms($smsinfo,'chanyoo_sms_tp3');

        $paramter = DB::fetch_first('select * from %t where name=%s', array(
            'zimu_xiangqin_parameter2',
            'wxtpl'
        ));
        $paramters = unserialize($paramter['parameter']);
        $first = $language_zimu['admins_inc_php_4'];
        $keyword1 = $language_zimu['admins_inc_php_5'];
        $keyword2 = $value['username'];
        $keyword3 = $value['tousername'].$language_zimu['admins_inc_php_6'];
        $remark = $language_zimu['admins_inc_php_7'];
        $tourl = ZIMUCMS_URL;
        $templatedata = array(
            'first' => array(
                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                'color' => "#FF4040"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($keyword2, CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => date('Y-m-d H:i',$_G['timestamp'])
            ),
            'remark' => array(
                'value' => urlencode(diconv($remark, CHARSET, 'utf-8')),
                'color' => "#008000"
            )
        );
        notification_user($value['uid'], $paramters['wxtpl_admin'], $templatedata, $tourl);
        $magcon = '{"tag":"'.$first.'","title":"'.$keyword3.'","title_themecolor":"#ff0000","link":"'.$tourl.'","extra_info":[{"key":"'.$language_zimu['admins_inc_php_8'].'","val":"'.$language_zimu['admins_inc_php_9'].'"}],"des":"'.$remark.'","des_themecolor":"#008000"}';
        notification_user_magapp($value['uid'],$magcon);
        $qfcon['msg'] = $first;
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title'=>diconv($keyword1, CHARSET, 'utf-8'),
            'date'=>date('Y-m-d H:i:s'),
            'setting'=>array(),
            'content' => diconv($keyword3.$language_zimu['admins_inc_php_10'].$remark,CHARSET,'UTF-8'),
            'url'=>ZIMUCMS_URL
        );
        notification_user_qfapp($value['uid'],$qfcon);


    }

    if($type){
        include DISCUZ_ROOT.'./source/plugin/zimu_xiangqin/module/admins/admins_'.$type.'.inc.php';
    }