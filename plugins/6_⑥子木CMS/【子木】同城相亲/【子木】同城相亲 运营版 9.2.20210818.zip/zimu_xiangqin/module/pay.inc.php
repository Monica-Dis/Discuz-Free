<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $ids = intval($_GET['ids']);
    $order = Db::name('zimu_xiangqin_order')->where('id', $ids)->find();

    $body = diconv(cutstr(strip_tags($order['description']),20),CHARSET,'UTF-8');

    if($op == 'xcx'){
        $tools = new JsApiPaySF();
        $notify = new NativePaySF();
        $input = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['pay_amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_xiangqin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
        $openid = $myuid['xcx_openid'];
        $input->SetOpenid($openid);
        $order2 = WxPayApiSF::unifiedOrder($input);
        $jsApiParameters = $tools->GetJsApiParameters($order2);
        if ($order2['prepay_id'] == '') {
            $jsApiParameters = json_encode(array('error' => $openid . ' error'));
        }
        echo $jsApiParameters;
        exit();
    }

    if(IN_WECHAT) {
        $tools = new JsApiPaySF();
        $notify = new NativePaySF();
        $input = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['pay_amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_xiangqin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));

        $openid = $myuid['openid'];
        $input->SetOpenid($openid);
        $order2 = WxPayApiSF::unifiedOrder($input);
        $jsApiParameters = $tools->GetJsApiParameters($order2);
        if ($order2['prepay_id'] == '') {
            $jsApiParameters = json_encode(array('error' => $openid . ' error'));
        }
        echo $jsApiParameters;
        exit();
    }

    if(IN_MAGAPP){

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $call_back = $_G['siteurl'].'source/plugin/zimu_xiangqin/lib/notify_magapp.php?trade_no='.$order['oid'].'&userid='.$myuid['uid'];

        $mag_parameter=array('trade_no'=>$order['oid'],'callback'=>$call_back,'amount'=>$order['pay_amount'],'title'=>$body,'user_id'=>$myuid['uid'],'des'=>$body,'remark'=>$body,'secret'=>$mag_paramter['magapp_secret']);

        $mag_url = $mag_paramter['magapp_hostname'].'/core/pay/pay/unifiedOrder?'.http_build_query($mag_parameter);

        $mag_ret = json_decode(lizimu_post($mag_url,''),true);

        if ($mag_ret) {
            if ($unionOrderNum = $mag_ret['data']['unionOrderNum']) {
                Db::name('zimu_xiangqin_order')->where('id', $ids)->update(['payment' => 'magapp','payment_cn' => $language_zimu['pay_inc_php_0'].'APP'.$language_zimu['pay_inc_php_1'],'order_sn' => $mag_ret['data']['unionOrderNum']]);
            }
            $order = Db::name('zimu_xiangqin_order')->where('id', $ids)->find();

            zimu_json($order);

        }else{
            zimu_json('',$mag_ret["msg"],201);
        }


    }

    if(IN_QFAPP){

        $qfoid = addslashes($_GET['qfoid']);

        Db::name('zimu_xiangqin_order')->where('id', $ids)->update(['payment' => 'qfapp','payment_cn' => $language_zimu['pay_inc_php_2'].'APP'.$language_zimu['pay_inc_php_3'],'order_sn' => $qfoid]);

        $order = Db::name('zimu_xiangqin_order')->where('id', $ids)->find();

        zimu_json($order);

    }

