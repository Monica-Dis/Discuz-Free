<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    global $_G;
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);

    if(strpos($_SERVER['HTTP_REFERER'],'localhost') !== false){

    }else{
        if($_G['uid'] == 0 || $_G['uid'] != $myuid['uid']){
            $res['token'] = 'error';
            zimu_json($res,'',201);
            exit();
        }
    }

    if($op == 'update_status' ) {


    }elseif($op == 'intro' ){
        $ids = intval($_GET['ids']);
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();

        $zimu['xingge'] = $xingge_array;
        $zimu['myxingge'] = $myinfo['xingge'];
        $zimu['aihao'] = $aihao_array;
        $zimu['myaihao'] = $myinfo['aihao'];
        $zimu['jieshao'] = $jieshao_array;
        $zimu['intro'] = $myinfo['intro'];
        $zimu['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();
        zimu_json($zimu);

    }elseif($op == 'update_intro' ){
        $ids = intval($_GET['ids']);
        $zimu_get = zimu_array_gbk($_GET);
        if($zimu_get['myxingge']){
            $intro_data['xingge'] = addslashes(strip_tags($zimu_get['myxingge']));
        }
        if($zimu_get['myaihao']){
            $intro_data['aihao'] = addslashes(strip_tags($zimu_get['myaihao']));
        }
        $intro_data['intro'] = addslashes(strip_tags($zimu_get['myjieshao']));

        $intro_data['intro'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $intro_data['intro']);

        Db::name('zimu_xiangqin_users')->where('uid', $ids)->update($intro_data);

        zimu_json('ok');

    }elseif($op == 'ideal' ){
        $ids = intval($_GET['ids']);
        $myinfo = Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->find();
        $myinfo['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();
        zimu_json($myinfo);

    }elseif($op == 'update_ideal' ){
        $ids = intval($_GET['ids']);
        $myinfo = Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->find();
        if($myinfo['id']){
            $ideal_data['id'] = $myinfo['id'];
        }
        $zimu_get = zimu_array_gbk($_GET);
        $ideal_data['age'] = str_replace(array($language_zimu['hongniang_my_inc_php_0'],'-'),array('',','),$zimu_get['age']);
        $ideal_data['age_cn'] = $zimu_get['age'];
        $ideal_data['heights'] = str_replace(array('CM','-'),array('',','),$zimu_get['heights']);
        $ideal_data['heights_cn'] = $zimu_get['heights'];
        $ideal_data['xueli'] = addslashes(strip_tags($zimu_get['xueli']));
        $ideal_data['xueli_cn'] = $zimu_get['xueli_cn'];
        $ideal_data['yuexin'] = addslashes(strip_tags($zimu_get['yuexin']))+1;
        $ideal_data['work'] = addslashes(strip_tags($zimu_get['work']));
        $ideal_data['work_cn'] = $zimu_get['work_cn'];
        $ideal_data['ganqing'] = addslashes(strip_tags($zimu_get['ganqing']));
        $ideal_data['ganqing_cn'] = $zimu_get['ganqing_cn'];
        $ideal_data['zhufang'] = intval($_GET['zhufang'])+1;
        $ideal_data['xiyan'] = intval($_GET['xiyan'])+1;
        $ideal_data['hejiu'] = intval($_GET['hejiu'])+1;
        $ideal_data['uid'] = $ids;

        if($myinfo['id']){
            $ideal_data['id'] = $myinfo['id'];
            Db::name('zimu_xiangqin_users_ideal')->update($ideal_data);
        }else{
            Db::name('zimu_xiangqin_users_ideal')->insert($ideal_data);
        }

        zimu_json('ok');


    }elseif($op == 'album' ){

        $ids = intval($_GET['ids']);

        $album = Db::name('zimu_xiangqin_users_album')->field('url')->where('uid', $ids)->order('id', 'asc')->select()->toArray();

        foreach ($album as $key => $value) {
            $list['list'][$key] = $value['url'];
        }

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $list['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        $list['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();

        zimu_json($list);

    }elseif($op == 'delimg_album' ){
        $ids = intval($_GET['ids']);
        $imgurl = strip_tags($_GET['imgurl']);
        Db::name('zimu_xiangqin_users_album')->where(['uid' => $ids,'url' => $imgurl])->delete();

    }elseif($op == 'uploadimg_album' ){
        $ids = intval($_GET['ids']);

        if (!empty($_FILES['file'])) {

            //��ȡ��չ��
            $pathinfo = pathinfo($_FILES['file']['name']);
            $exename = strtolower($pathinfo['extension']);
            if ($exename != 'png' && $exename != 'jpeg' && $exename != 'jpg' && $exename != 'gif') {
                exit('error');
            }
            $imageSavePath = uniqid() . '.' . $exename;

            $date = date('ym/d/');
            $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/uploadzimucms/album/' . $date;

            if (!is_dir($save_avatar)) {
                mkdir($save_avatar, 0777, true);
            }

            if (move_uploaded_file($_FILES['file']['tmp_name'], $save_avatar . $imageSavePath)) {

                $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
                $oss_paramter = unserialize($oss_paramter['parameter']);

                if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
                    $saved_file = $save_avatar.$imageSavePath;
                    include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
                    if ($surl = zm_oss_upload('zimu_xiangqin/album/' . $date . $imageSavePath, $saved_file)) {
                        @unlink($saved_file);
                        $imgurl = $surl;
                    }
                }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

                    $saved_file = $save_avatar.$imageSavePath;
                    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
                    if ($surl=zm_qn_upload('zimu_xiangqin/album/' . $date . $imageSavePath,$saved_file)) {
                        unlink($saved_file);
                        error_reporting(0);
                        $imgurl = $surl;
                    }

                }else{
                    $imgurl = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/uploadzimucms/album/' . $date . $imageSavePath;
                }
            }

            $album_data['uid'] = $ids;
            $album_data['url'] = $imgurl;
            $album_data['sort'] = 100;

            Db::name('zimu_xiangqin_users_album')->insert($album_data);

        }

    }elseif($op == 'uploadimgapp_album' ){
        $ids = intval($_GET['ids']);

        $album_data['uid'] = $ids;
        $album_data['url'] = $_GET['imgurl'];
        $album_data['sort'] = 100;
        Db::name('zimu_xiangqin_users_album')->insert($album_data);

    }elseif($op == 'wximg_upload' ){
        $ids = intval($_GET['ids']);

        $config_params = savepic('album');

        $data = array(
            'imgurl' => $config_params['show_path']
        );

        $album_data['uid'] = $ids;
        $album_data['url'] = $config_params['show_path'];
        $album_data['sort'] = 100;
        Db::name('zimu_xiangqin_users_album')->insert($album_data);

        zimu_json($data);


    }elseif($op == 'basicinfo' ){

        $ids = intval($_GET['ids']);

        $users_data['uid'] = $ids;
        if ($zimu_get['myphoto'] && !preg_match('/^(http|\.)/i', $zimu_get['myphoto'])) {
            $users_data['photo'] = zm_saveimages_base64($zimu_get['myphoto'], 'photo',1,0.7);
        }elseif($zimu_get['myphoto']){
            $users_data['photo'] = $zimu_get['myphoto'];
        }
        $users_data['nickname'] = addslashes(strip_tags($zimu_get['myname']));
        $users_data['mobile'] = strip_tags($_GET['mymobile']);
        $users_data['weixin'] = addslashes(strip_tags($zimu_get['myweixin']));
        $users_data['birth'] = addslashes(strip_tags($zimu_get['mybirth']));
        $mybirth = explode('-', $users_data['birth']);
        $users_data['age'] = 2021 - $mybirth[0];
        $users_data['shuxiang'] = ($mybirth[0] - 1948) % 12;
        $users_data['constellation'] = getconstellation($mybirth[1], $mybirth[2]);
        $users_data['height'] = intval($_GET['myheight']);
        $users_data['weight'] = intval($_GET['myweight']);
        $users_data['city'] = addslashes(strip_tags($zimu_get['mycity']));
        $users_data['city2'] = addslashes(strip_tags($zimu_get['mycity2']));
        $users_data['xueli'] = intval($_GET['myxueli']) + 1;
        $users_data['ganqing'] = intval($_GET['myganqing']) + 1;
        $users_data['work'] = intval($_GET['mywork']) + 1;
        $users_data['yuexin'] = intval($_GET['myyuexin']) + 1;
        $users_data['zhufang'] = intval($_GET['myzhufang']) + 1;
        $users_data['gouche'] = intval($_GET['mygouche']) + 1;
        $users_data['xiyan'] = intval($_GET['myxiyan']) + 1;
        $users_data['hejiu'] = intval($_GET['myhejiu']) + 1;
        $users_data['sex'] = intval($_GET['mysex']);
        $users_data['status'] = intval($_GET['mystatus']);
        $users_data['state'] = intval($_GET['mystate']);
        $users_data['real_state'] = intval($_GET['myreal_state']);

        $oldinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();

        Db::name('zimu_xiangqin_users')->where('uid', $ids)->update($users_data);

        zimu_json('', $language_zimu['hongniang_my_inc_php_2'], 200);

    }else{

        $ids = intval($_GET['ids']);

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->findOrEmpty();

        if(!$myinfo['city']){
            $myinfo['city'] = $zmdata['settings']['city_value'];
        }
        if(!$myinfo['city2']){
            $myinfo['city2'] = $zmdata['settings']['city_value'];
        }
        $myinfo['myinfo'] = $myinfo;

        $myinfo['xueli_cn'] = $xueli_array[$myinfo['xueli']-1];

        $myinfo['work_cn'] = $work_array[$myinfo['work']-1];

        $myinfo['zmdata'] = $zmdata2;

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $myinfo['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        $myinfo['kefu'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();

        if($zmdata['settings']['diy_mycity']){
            $citys = json_decode(zimu_array_utf8($zmdata['settings']['diy_mycity']),true);
            $myinfo['citys'] = zimu_array_gbk2($citys);
        }

        zimu_json($myinfo);

    }

    function savepic($type,$oss=1){
        global $_G;

        $config_params = array(
            'upload_ok' => false,
            'save_path' => '',
            'show_path' => ''
        );
        $filename      = uniqid() . '.jpg';
        $pic           = base64_decode($_GET['base64_string']);
        $sids = $_GET['serverId'];

        if(!$pic && !$sids){

            $picurl = zm_saveimages($_FILES[$type]);
            $config_params['save_path'] = $picurl;
            $config_params['show_path'] = $picurl;
            $config_params['upload_ok'] = true;
            return $config_params;

        }

        $date        = date('ym/d/');
        $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date;

        if (!is_dir($save_avatar)) {
            mkdir($save_avatar, 0777, true);
        }

        if($sids){

            require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient(SF_APPID, SF_APPSECRET);
            $temp = $wechat_client->download($sids);
            if(!empty($temp)) {
                $content = '';
                if (preg_match('/^(http:\/\/|\.)/i', $temp)) {
                    $content = zm_curl($temp);
                }else{
                    $content = $temp;
                }
                $fp = fopen($save_avatar . $filename, 'wb');
                flock($fp, 2);
                fwrite($fp, $content);
                fclose($fp);
            }


        }else{

            file_put_contents($save_avatar . $filename, $pic);

        }

        require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/imgcompress.class.php';
        $source = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        $dst_img = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        $percent = 0.5;
        $image = (new imgcompress($source,$percent))->compressImg($dst_img);

        $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
        $oss_paramter = unserialize($oss_paramter['parameter']);

        if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
            $saved_file = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
            include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
            if ($surl = zm_oss_upload('zimu_xiangqin/'. $type . '/' . $date . $filename, $saved_file)) {
                @unlink($saved_file);
                $imgurl = $surl;
                $config_params['save_path'] = $imgurl;
                $config_params['show_path'] = $imgurl;
                $config_params['upload_ok'] = true;
                return $config_params;
                exit();
            }
        }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

            $saved_file = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
            include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
            if ($surl=zm_qn_upload('zimu_xiangqin/'. $type . '/' . $date . $filename,$saved_file)) {
                unlink($saved_file);
                error_reporting(0);
                $imgurl = $surl;
                $config_params['save_path'] = $imgurl;
                $config_params['show_path'] = $imgurl;
                $config_params['upload_ok'] = true;
                return $config_params;
            }

        }

        $config_params['save_path'] = '/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        $config_params['show_path'] = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        $config_params['upload_ok'] = true;
        return $config_params;

    }



