<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_xiangqin/module/', '', $_G['siteurl']);

global $_G;
$zmdata = $_G['cache']['plugin']['zimu_xiangqin'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
    'zimu_xiangqin_setting'
));

$zmdata['settings'] = unserialize($setdata['settings']);

define("TOKEN", $zmdata['settings']['wx_token']);

$wechatObj = new wechatCallbackapiTest();
if (!isset($_GET['echostr'])) {
    $wechatObj->responseMsg();
} else {
    $wechatObj->valid();
}

class wechatCallbackapiTest
{
    //��֤ǩ��
    public function valid()
    {
        $echoStr   = $_GET["echostr"];
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce     = $_GET["nonce"];
        $token     = TOKEN;
        $tmpArr    = array(
            $token,
            $timestamp,
            $nonce
        );
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
        if ($tmpStr == $signature) {
            echo $echoStr;
            exit;
        }
    }
    
    //��Ӧ��Ϣ
    public function responseMsg()
    {
        //$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        $postStr = file_get_contents("php://input");
        if (!empty($postStr)) {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $RX_TYPE = trim($postObj->MsgType);
            
            if (($postObj->MsgType == "event") && ($postObj->Event == "subscribe" || $postObj->Event == "unsubscribe")) {
                //���˹�ע��ȡ����ע�¼�
            } else {
                
            }
            
            //��Ϣ���ͷ���
            switch ($RX_TYPE) {
                case "event":
                    $result = $this->receiveEvent($postObj);
                    break;
                default:
                    //$result = "unknown msg type: ".$RX_TYPE;
                    break;
            }
            echo $result;
        } else {
            echo "";
            exit;
        }
    }
    
    //�����¼���Ϣ
    private function receiveEvent($object)
    {
        $content = "";
        global $_G;
        $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];
        
        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_xiangqin_setting'
        ));

        $zmdata['settings'] = unserialize($setdata['settings']);

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $xueli_array = explode(',',$zmdata['settings']['xueli_type']);
        $yuexin_array = explode(',',$zmdata['settings']['yuexin_type']);
        $ganqing_array = explode(',',$zmdata['settings']['ganqing_type']);
        $work_array = explode(',',$zmdata['settings']['work_type']);
        $zhufang_array = explode(',',$zmdata['settings']['zhufang_type']);
        $gouche_array = explode(',',$zmdata['settings']['gouche_type']);
        $xingge_array = explode(',',$zmdata['settings']['xingge_type']);
        $aihao_array = explode(',',$zmdata['settings']['aihao_type']);
        $jieshao_array = explode('zimuyun',$zmdata['settings']['jieshao_type']);
        $shuxiang_array = explode(',',$zmdata['settings']['shuxiang_type']);
        $xingzuo_array = explode(',',$zmdata['settings']['xingzuo_type']);
        $xiyan_array = explode(',',$zmdata['settings']['xiyan_type']);
        $hejiu_array = explode(',',$zmdata['settings']['hejiu_type']);
        $zhufang2_array = explode(',',$zmdata['settings']['zhufang2_type']);
        $xiyan2_array = explode(',',$zmdata['settings']['xiyan2_type']);
        $hejiu2_array = explode(',',$zmdata['settings']['hejiu2_type']);

        if ($object->Event == 'subscribe') {

            $this->zimu_sendTextMsg(trim($object->FromUserName), diconv($zmdata['settings']['subscribe_text'], CHARSET, 'UTF-8'));

            $object->Event    = 'SCAN';
            $object->EventKey = str_replace("qrscene_", "", $object->EventKey);
        }

        switch ($object->Event) {
            case "SCAN":
                list($model, $ids,$ids2) = explode('zimuyun', $object->EventKey);
                if ($model == 'xiangqin_poster_' && $ids) {
                    
                    $usersdata = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
                        'zimu_xiangqin_users',
                        $ids
                    ));

                    $sex_cn = $usersdata['sex']==1 ? $language_zimu['wechatapi_php_5'] : $language_zimu['wechatapi_php_6'];
                    $Title = '#'.$language_zimu['wechatapi_php_7'].'#'.$usersdata['nickname'].'/'.$sex_cn.'/'.$usersdata['age'].$language_zimu['wechatapi_php_8'].'/'.$usersdata['height'].'cm/'.$xueli_array[$usersdata['xueli']-1].'/'.$yuexin_array[$usersdata['yuexin']-1].'/'.$work_array[$usersdata['work']-1];
                    $Title = diconv($Title, CHARSET, 'UTF-8');
                    $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$ids.'?mobile=2';
                    $content = array();
                    $content[] = array("Title"=>$Title, "Description"=>diconv($zmdata['settings']['share_desc'], CHARSET, 'UTF-8'), "PicUrl"=>$usersdata['photo'], "Url" =>$share_url);
               }elseif ($model == 'bindmp_im' && $ids){
                    //list($model, $ids) = explode('zimuyun', $ids);
                    $content = $ids2;
                }

                break;
            default:
                //$content = "receive a new event: ".$object->Event;
                break;
        }
        
        if (is_array($content)) {
            if (isset($content[0]['PicUrl'])) {
                $result = $this->transmitNews($object, $content);
            } else if (isset($content['MusicUrl'])) {
                $result = $this->transmitMusic($object, $content);
            }
        } else {
            $result = $this->transmitText($object, $content);
        }

        return $result;
    }

    private function zimu_sendTextMsg($to, $msg)
    {
        global $_G;
        $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];

        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_xiangqin_setting'
        ));

        $zmdata['settings'] = unserialize($setdata['settings']);

        require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);

        $wechat_client->sendTextMsg($to, $msg);

    }

    //�����ı���Ϣ
    private function receiveText($object)
    {
        $keyword = trim($object->Content);
        return $result;
    }
    
    //����ͼƬ��Ϣ
    private function receiveImage($object)
    {
        $content = array(
            "MediaId" => $object->MediaId
        );
        $result  = $this->transmitImage($object, $content);
        return $result;
    }
    
    //����λ����Ϣ
    private function receiveLocation($object)
    {
        return $result;
    }
    
    //����������Ϣ
    private function receiveVoice($object)
    {
        return $result;
    }
    
    //������Ƶ��Ϣ
    private function receiveVideo($object)
    {
        return $result;
    }
    
    //����������Ϣ
    private function receiveLink($object)
    {
        return $result;
    }
    
    //�ظ��ı���Ϣ
    private function transmitText($object, $content)
    {
        if (!isset($content) || empty($content)) {
            return "";
        }
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[text]]></MsgType>
    <Content><![CDATA[%s]]></Content>
</xml>";
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $content);
        
        return $result;
    }
    
    //�ظ�ͼ����Ϣ
    private function transmitNews($object, $newsArray)
    {
        if (!is_array($newsArray)) {
            return "";
        }
        $itemTpl  = "        <item>
            <Title><![CDATA[%s]]></Title>
            <Description><![CDATA[%s]]></Description>
            <PicUrl><![CDATA[%s]]></PicUrl>
            <Url><![CDATA[%s]]></Url>
        </item>
";
        $item_str = "";
        foreach ($newsArray as $item) {
            $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['PicUrl'], $item['Url']);
        }
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[news]]></MsgType>
    <ArticleCount>%s</ArticleCount>
    <Articles>
$item_str    </Articles>
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), count($newsArray));
        return $result;
    }
    
    //�ظ�������Ϣ
    private function transmitMusic($object, $musicArray)
    {
        if (!is_array($musicArray)) {
            return "";
        }
        $itemTpl = "<Music>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
        <MusicUrl><![CDATA[%s]]></MusicUrl>
        <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
    </Music>";
        
        $item_str = sprintf($itemTpl, $musicArray['Title'], $musicArray['Description'], $musicArray['MusicUrl'], $musicArray['HQMusicUrl']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[music]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ�ͼƬ��Ϣ
    private function transmitImage($object, $imageArray)
    {
        $itemTpl = "<Image>
        <MediaId><![CDATA[%s]]></MediaId>
    </Image>";
        
        $item_str = sprintf($itemTpl, $imageArray['MediaId']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[image]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ�������Ϣ
    private function transmitVoice($object, $voiceArray)
    {
        $itemTpl = "<Voice>
        <MediaId><![CDATA[%s]]></MediaId>
    </Voice>";
        
        $item_str = sprintf($itemTpl, $voiceArray['MediaId']);
        $xmlTpl   = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[voice]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ���Ƶ��Ϣ
    private function transmitVideo($object, $videoArray)
    {
        $itemTpl = "<Video>
        <MediaId><![CDATA[%s]]></MediaId>
        <ThumbMediaId><![CDATA[%s]]></ThumbMediaId>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
    </Video>";
        
        $item_str = sprintf($itemTpl, $videoArray['MediaId'], $videoArray['ThumbMediaId'], $videoArray['Title'], $videoArray['Description']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[video]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ���ͷ���Ϣ
    private function transmitService($object)
    {
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[transfer_customer_service]]></MsgType>
</xml>";
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ��������ӿ���Ϣ
    private function relayPart3($url, $rawData)
    {
        $headers = array(
            "Content-Type: text/xml; charset=utf-8"
        );
        $ch      = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $rawData);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    
    //�ֽ�תEmoji����
    function bytes_to_emoji($cp)
    {
        if ($cp > 0x10000) { # 4 bytes
            return chr(0xF0 | (($cp & 0x1C0000) >> 18)) . chr(0x80 | (($cp & 0x3F000) >> 12)) . chr(0x80 | (($cp & 0xFC0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else if ($cp > 0x800) { # 3 bytes
            return chr(0xE0 | (($cp & 0xF000) >> 12)) . chr(0x80 | (($cp & 0xFC0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else if ($cp > 0x80) { # 2 bytes
            return chr(0xC0 | (($cp & 0x7C0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else { # 1 byte
            return chr($cp);
        }
    }
}