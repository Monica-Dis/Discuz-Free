<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
    global $_G;
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);

    if(strpos($_SERVER['HTTP_REFERER'],'localhost') !== false){

    }else{
        /*
        if($_G['uid'] == 0 || $_G['uid'] != $myuid['uid']){
            $res['token'] = 'error';
            zimu_json($res,'',201);
            exit();
        }
        */
    }

    if($op=='gethongniang') {

        $info['list'] = Db::name('zimu_xiangqin_kefu')->order(['id'=>'asc'])->select()->toArray();
        $info['hn_name'] = $zmdata['settings']['hn_name'];
        $info['hn_weixin'] = $zmdata['settings']['hn_weixin'];
        $info['hn_photo_url'] = $zmdata['settings']['hn_photo_url'];
        $info['zmdata'] = $zmdata2;
        zimu_json($info);

    }elseif($op=='select_user'){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);
        $nocity = intval($selecttxt['nocity']);

        $wheresql[] = ['state','=',1];
        $wheresql[] = ['status','<>',3];

        if($selecttxt['keywords']){
            //$whereorsql = 'nickname|no','like','%'.$selecttxt['keywords'].'%';
            $whereorsql = '\'nickname|no\',\'like\',\'%\'.$selecttxt[\'keywords\'].\'%\'';
        }

        if (!empty($selecttxt['sex'])) {
            $wheresql[] = ['sex','=',$selecttxt['sex']];
        }elseif($selecttxt['sex'] == null){
            $tosex = $myinfo['sex'] == 1 ? 2 : 1;
            $wheresql[] = ['sex','=',$tosex];
        }


        if($selecttxt['ageStart']){
            $wheresql[] = ['age','>=',$selecttxt['ageStart']];
        }
        if($selecttxt['ageEnd']){
            $wheresql[] = ['age','<=',$selecttxt['ageEnd']];
        }
        if($selecttxt['heightStart']){
            $wheresql[] = ['height','>=',$selecttxt['heightStart']];
        }
        if($selecttxt['heightEnd']){
            $wheresql[] = ['height','<=',$selecttxt['heightEnd']];
        }
        if($selecttxt['xueli']){
            $wheresql[] = ['xueli','>=',$selecttxt['xueli']];
        }
        if($selecttxt['work']){
            $wheresql[] = ['work','=',$selecttxt['work']];
        }
        if($selecttxt['yuexin']){
            $wheresql[] = ['yuexin','>=',$selecttxt['yuexin']];
        }
        if($selecttxt['ganqing']){
            $wheresql[] = ['ganqing','=',$selecttxt['ganqing']];
        }
        if($selecttxt['real']){
            $wheresql[] = ['real_state','=',1];
        }
        if($selecttxt['vip']){
            $wheresql[] = ['vip_type','>',0];
        }

        if($selecttxt['keywords']){
            $limit = 1000;
        }else{
            $limit = 10;
        }

        if($selecttxt['city_value'] && $nocity==0){
            $selecttxt['city_value'] = implode(',',$selecttxt['city_value']);
            $info['select_user'] = Db::name('zimu_xiangqin_users')->where([$wheresql])->where('city|city2','like','%'.$selecttxt['city_value'].'%')->where('nickname|no','like','%'.$selecttxt['keywords'].'%')->order(['toptime'=>'desc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,$limit)->select()->toArray();
        }else{
            $info['select_user'] = Db::name('zimu_xiangqin_users')->where([$wheresql])->where('nickname|no','like','%'.$selecttxt['keywords'].'%')->order(['toptime'=>'desc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,$limit)->select()->toArray();
        }

        $info['select_user'] = isshowphoto($info['select_user'],$myuid['uid']);

        zimu_json($info);

    }elseif($op=='getzmdata'){

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        if($myinfo['sex']==2 && $zmdata['settings']['need_pay_audit2']>0){
            $zmdata2['settings']['need_pay_audit'] = $zmdata['settings']['need_pay_audit2'];
        }

        $zmdata2['myinfo'] = $myinfo;
        $zmdata2['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        if($zmdata['settings']['diy_mycity']){
            $citys = json_decode(zimu_array_utf8($zmdata['settings']['diy_mycity']),true);
            $zmdata2['citys'] = zimu_array_gbk2($citys);
        }

        $zmdata2['nickname'] = $myuid['username'];

        zimu_json($zmdata2);

    }elseif($op=='menlist'){

        if($page==1){

        $top_user_map1 = [
            ['state', '=', 1],
            ['status', '<>', 3],
            ['sex', '=', 1],
            ['toptime', '>', time()],
        ];
        $top_user_map2 = [
            ['state', '=', 1],
            ['status', '<>', 3],
            ['sex', '=', 1],
            ['isindex', '>', 0],
        ];

        $top_user = Db::name('zimu_xiangqin_users')->whereOr([$top_user_map1,$top_user_map2])->orderRaw('rand()')->limit(10)->select()->toArray();

        }else{
           $top_user = array();
        }

        $menlist = Db::name('zimu_xiangqin_users')->where([['state','=',1],['status','<>',3],['sex','=',1]])->order(['toptime'=>'desc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,10)->select()->toArray();

        $info['menlist'] = array_merge($top_user,$menlist);

        $info['menlist'] = isshowphoto($info['menlist'],$myuid['uid']);

        zimu_json($info);

    }elseif($op=='womenlist'){

        $page = intval($_GET['page']) ? intval($_GET['page']) : 1;

        if($page==1) {

            $top_user_map1 = [
                ['state', '=', 1],
                ['status', '<>', 3],
                ['sex', '=', 2],
                ['toptime', '>', time()],
            ];
            $top_user_map2 = [
                ['state', '=', 1],
                ['status', '<>', 3],
                ['sex', '=', 2],
                ['isindex', '>', 0],
            ];

            $top_user = Db::name('zimu_xiangqin_users')->whereOr([$top_user_map1, $top_user_map2])->orderRaw('rand()')->limit(10)->select()->toArray();
        }else{
            $top_user = array();
        }

        $womenlist = Db::name('zimu_xiangqin_users')->where([['state','=',1],['status','<>',3],['sex','=',2]])->order(['toptime'=>'desc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,10)->select()->toArray();

        $info['womenlist'] = array_merge($top_user,$womenlist);

        $info['womenlist'] = isshowphoto($info['womenlist'],$myuid['uid']);

        zimu_json($info);

    }elseif($op=='top_user'){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        if($myinfo['id'] && $zmdata['settings']['show_other_sex'] != 1){
            $tosex = $myinfo['sex'];
        }else{
            $tosex = 0;
        }

        if($zmdata['settings']['top_user_order']==2) {

            $top_user_map1 = [
                ['sex', '<>', $tosex],
                ['state', '=', 1],
                ['status', '<>', 3],
                ['toptime', '>', time()],
            ];
            $top_user_map2 = [
                ['sex', '<>', $tosex],
                ['state', '=', 1],
                ['status', '<>', 3],
                ['isindex', '>', 0],
            ];

            $info['top_user'] = Db::name('zimu_xiangqin_users')->whereOr([$top_user_map1, $top_user_map2])->order(['toptime' => 'desc', 'vip_type' => 'desc', 'refreshtime' => 'desc', 'addtime' => 'desc'])->page($page, 10)->select()->toArray();

        }else{

            $info['top_user'] = Db::name('zimu_xiangqin_users')->where([['sex','<>',$tosex],['state','=',1],['status','<>',3]])->where('toptime','<', time())->where('isindex','>', 0)->order(['isindex'=>'asc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,10)->select()->toArray();

        }

        $info['top_user'] = isshowphoto($info['top_user'],$myuid['uid']);

        zimu_json($info);

    }else{

        $indexad = Db::name('zimu_xiangqin_parameter2')->where('name','indexad')->find();

        $info['swiper_info'] = unserialize($indexad['parameter']);
        unset($info['swiper_info'][1]);
        unset($info['swiper_info'][2]);
        unset($info['swiper_info'][3]);

        $info['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        if($info['myinfo']['id'] && $zmdata['settings']['show_other_sex'] != 1){
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['refreshtime' => time()]);
            $tosex = $info['myinfo']['sex'];
        }else{
            $tosex = 0;
        }

        if($zmdata['settings']['top_user_order']==2){
            $top_user_map1 = [
                ['sex', '<>', $tosex],
                ['state', '=', 1],
                ['status', '<>', 3],
                ['toptime', '>', time()],
            ];
            $top_user_map2 = [
                ['sex', '<>', $tosex],
                ['state', '=', 1],
                ['status', '<>', 3],
                ['isindex', '>', 0],
            ];

            $top_user1 = Db::name('zimu_xiangqin_users')->whereOr([$top_user_map1,$top_user_map2])->orderRaw('rand()')->limit(50)->select()->toArray();

            $info['top_user'] = $top_user1;

        }else{

            $top_user1 = Db::name('zimu_xiangqin_users')->where([['sex','<>',$tosex],['state','=',1],['status','<>',3]])->where('toptime','>', time())->order(['toptime'=>'desc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->select()->toArray();

            $top_user2 = Db::name('zimu_xiangqin_users')->where([['sex','<>',$tosex],['state','=',1],['status','<>',3]])->where('toptime','<', time())->where('isindex','>', 0)->order(['isindex'=>'asc','vip_type'=>'desc','refreshtime'=>'desc','addtime'=>'desc'])->page($page,10)->select()->toArray();
            $info['top_user'] = array_merge($top_user1,$top_user2);
        }

        $info['top_user'] = isshowphoto($info['top_user'],$myuid['uid']);

        $info['myinfo']['ideal'] = Db::name('zimu_xiangqin_users_ideal')->where('uid', $myuid['uid'])->find();

        $selecttxt = $info['myinfo']['ideal'];

        $wheresql[] = ['state','=',1];
        $wheresql[] = ['status','<>',3];

        $age = explode(',',$selecttxt['age']);
        $selecttxt['ageStart'] = intval($age[0]);
        $selecttxt['ageEnd'] = intval($age[1]);

        $heights = explode(',',$selecttxt['heights']);
        $selecttxt['heightStart'] = intval($heights[0]);
        $selecttxt['heightEnd'] = intval($heights[1]);

        if($info['myinfo']['sex'] && $zmdata['settings']['show_other_sex'] != 1) {
            $wheresql[] = ['sex', '<>', $info['myinfo']['sex']];
            $selecttxt['sex'] = $info['myinfo']['sex'];
        }

        if($selecttxt['ageStart']){
            $wheresql[] = ['age','>=',$selecttxt['ageStart']];
        }
        if($selecttxt['ageEnd']){
            $wheresql[] = ['age','<=',$selecttxt['ageEnd']];
        }
        if($selecttxt['heightStart']){
            $wheresql[] = ['height','>=',$selecttxt['heightStart']];
        }
        if($selecttxt['heightEnd']){
            $wheresql[] = ['height','<=',$selecttxt['heightEnd']];
        }
        if($selecttxt['xueli']){
            $wheresql[] = ['xueli','between',$selecttxt['xueli']];
        }
        if($selecttxt['work']){
            $wheresql[] = ['work','between',$selecttxt['work']];
        }
        if($selecttxt['yuexin']){
            $wheresql[] = ['yuexin','>=',$selecttxt['yuexin']];
        }
        if($selecttxt['ganqing']){
            $wheresql[] = ['ganqing','between',$selecttxt['ganqing']];
        }

        if($info['myinfo']['sex']) {
            $info['select_user'] = Db::name('zimu_xiangqin_users')->where([$wheresql])->where([['sex','<>',$info['myinfo']['sex']]])->limit(50)->select()->toArray();
        }else{
            $info['select_user'] = Db::name('zimu_xiangqin_users')->where([$wheresql])->limit(50)->select()->toArray();
        }

        $info['select_user'] = isshowphoto($info['select_user'],$myuid['uid']);

        $info['selecttxt'] = $selecttxt;

        $info['zmdata'] = $zmdata2;

        $info['linetip'] = Db::name('zimu_xiangqin_applyline')->where([['touid','=',$myuid['uid']],['status','>',0],['status','<',3]])->order('id','asc')->find();

        if(IN_WECHAT && !$info['myinfo']['bind_weixin'] && $myuid['openid']){
            require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);
            $wechatinfo    = $wechat_client->getUserInfoById($myuid['openid']);
            if ($wechatinfo['subscribe'] == 1) {
                $info['myinfo']['bind_weixin'] = 1;
                Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['bind_weixin' => 1]);
            }else{
                $info['myinfo']['bind_weixin'] = 0;
            }
        }else{
            $info['myinfo']['bind_weixin'] = 1;
        }

        $info['bili'] = Db::name('zimu_xiangqin_order')->orderRaw('rand()')->limit(10)->select()->toArray();

        foreach ($info['bili'] as $key => $value) {
            $valueinfo = Db::name('zimu_xiangqin_users')->where(['uid' => $value['uid']])->find();
            $info['bili'][$key]['nickname'] = $valueinfo['nickname'];
            $info['bili'][$key]['photo'] = $valueinfo['photo'];
        }

        if ($info['myinfo']['hn_uid']) {
            $hn_data = Db::name('zimu_xiangqin_kefu')->where('uid', $info['myinfo']['hn_uid'])->find();
            $info['zmdata']['settings']['hn_qrcode_url'] = $hn_data['kefu_qrcode_url'];
            $info['zmdata']['settings']['hn_weixin'] = $hn_data['kefu_wxid'];
        }

        $paramter = Db::name('zimu_xiangqin_parameter2')->where(['name' => 'gridnav'])->find();
        $info['gridnav'] = unserialize($paramter['parameter']);
        $info['myinfo']['show_other_sex'] = intval($zmdata['settings']['show_other_sex']);

        zimu_json($info);

    }
