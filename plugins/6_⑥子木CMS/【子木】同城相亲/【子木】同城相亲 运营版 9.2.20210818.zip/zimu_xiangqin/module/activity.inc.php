<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);


    if($op == 'show' ) {

        $ids = intval($_GET['ids']);
        $res['act'] = Db::name('zimu_xiangqin_activity')->where('id',$ids)->order(['id'=>'desc'])->find();
        $res['act']['activitytime_cn'] = date('Y-m-d',$res['act']['activitytime']);
        $res['act']['con']         = htmlspecialchars_decode($res['act']['con']);
        $res['userlist'] = Db::name('zimu_xiangqin_activity_user')->where([['aid','=',$ids],['ispay','=',1]])->order(['id'=>'desc'])->select()->toArray();
        $res['act']['is_apply'] = Db::name('zimu_xiangqin_activity_user')->where([['aid','=',$ids],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->findOrEmpty();
        $res['act']['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid',$myuid['uid'])->order(['id'=>'desc'])->find();

        if($res['act']['starttime'] < time()){
            $res['act']['is_start'] = 1;
        }else{
            $res['act']['is_start'] = 0;
        }

        if($res['act']['endtime'] < time()){
            $res['act']['is_end'] = 1;
        }else{
            $res['act']['is_end'] = 0;
        }

        if($res['act']['activitytime'] < time()){
            $res['act']['is_activity'] = 1;
        }else{
            $res['act']['is_activity'] = 0;
        }

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid',$myuid['uid'])->order(['id'=>'desc'])->find();
        $res['myinfo'] = $myinfo;
        zimu_json($res);

    }elseif ($op=='goapply'){

        $ids = intval($_GET['ids']);
        $activity = Db::name('zimu_xiangqin_activity')->where('id',$ids)->order(['id'=>'desc'])->find();
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid',$myuid['uid'])->order(['id'=>'desc'])->find();

        if($myinfo['vip_type'] > 0 && $myinfo['vip_etime'] > time()){
            $activity['price'] = $activity['vip_price'];
        }

        if($activity['price']){

            $activity_user_data['aid'] = $ids;
            $activity_user_data['uid'] = $myuid['uid'];
            $activity_user_data['name'] = $myinfo['nickname'];
            $activity_user_data['sex'] = $myinfo['sex'];
            $activity_user_data['photo'] = $myinfo['photo'];
            $activity_user_data['weixin'] = $myinfo['weixin'];
            $activity_user_data['mobile'] = $myinfo['mobile'];
            $activity_user_data['isvip'] = $myinfo['vip_type'] > 0 && $myinfo['vip_etime'] > time() ? 1 : 0;
            $activity_user_data['ispay'] = 0;
            $activity_user_data['addtime'] = $_G['timestamp'];
            $applyid = Db::name('zimu_xiangqin_activity_user')->insertGetId($activity_user_data);

            $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
            $params['uid'] = $myuid['uid'];
            $params['openid'] = $myuid['openid'];
            $params['pay_type'] = 2;
            $params['is_paid'] = 1;
            $params['amount'] = $activity['price']/100;
            $params['pay_amount'] = $activity['price']/100;
            $params['payment'] = 'wxpay';
            $params['payment_cn'] = $language_zimu['activity_inc_php_0'];
            $params['description'] = $language_zimu['activity_inc_php_1'].$activity['title'].$language_zimu['activity_inc_php_2'].$activity['id'].$language_zimu['activity_inc_php_3'];
            $params['service_name'] = 'apply_activity';
            $params_array['applyid'] = $applyid;
            $params_array['uid'] = $myuid['uid'];
            $params_array['username'] = $myinfo['nickname'];
            $params['params'] = serialize($params_array);
            $params['addtime'] = $_G['timestamp'];
            $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);
            zimu_json($return_order_info);


        }else{

            $activity_user_data['aid'] = $ids;
            $activity_user_data['uid'] = $myuid['uid'];
            $activity_user_data['name'] = $myinfo['nickname'];
            $activity_user_data['sex'] = $myinfo['sex'];
            $activity_user_data['photo'] = $myinfo['photo'];
            $activity_user_data['weixin'] = $myinfo['weixin'];
            $activity_user_data['mobile'] = $myinfo['mobile'];
            $activity_user_data['isvip'] = $myinfo['vip_type'] > 0 && $myinfo['vip_etime'] > time() ? 1 : 0;
            $activity_user_data['ispay'] = 1;
            $activity_user_data['addtime'] = $_G['timestamp'];
            $activity_user_data['id'] = Db::name('zimu_xiangqin_activity_user')->insertGetId($activity_user_data);
            $activity_user_data['order_id'] = 0;
            zimu_json($activity_user_data);

        }

    }elseif ($op=='goapply_pay'){

        $ids = intval($_GET['ids']);
        $activity = Db::name('zimu_xiangqin_activity')->where('id',$ids)->order(['id'=>'desc'])->find();
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid',$myuid['uid'])->order(['id'=>'desc'])->find();
        $activity_user = Db::name('zimu_xiangqin_activity_user')->where([['aid','=',$ids],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();

        if($myinfo['vip_type'] > 0 && $myinfo['vip_etime'] > time()){
            $activity['price'] = $activity['vip_price'];
        }

        if($activity['price']){

            $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
            $params['uid'] = $myuid['uid'];
            $params['openid'] = $myuid['openid'];
            $params['pay_type'] = 2;
            $params['is_paid'] = 1;
            $params['amount'] = $activity['price']/100;
            $params['pay_amount'] = $activity['price']/100;
            $params['payment'] = 'wxpay';
            $params['payment_cn'] = $language_zimu['activity_inc_php_4'];
            $params['description'] = $language_zimu['activity_inc_php_5'].$activity['title'].$language_zimu['activity_inc_php_6'].$activity['id'].$language_zimu['activity_inc_php_7'];
            $params['service_name'] = 'apply_activity';
            $params_array['applyid'] = $activity_user['id'];
            $params_array['uid'] = $myuid['uid'];
            $params_array['username'] = $myinfo['nickname'];
            $params['params'] = serialize($params_array);
            $params['addtime'] = $_G['timestamp'];
            $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);
            zimu_json($return_order_info);


        }else{

            Db::name('zimu_xiangqin_activity_user')->where('id', $activity_user['id'])->update(['ispay' => 1]);
            zimu_json($activity_user);

        }

    }else{

        $res['list'] = Db::name('zimu_xiangqin_activity')->order(['id'=>'desc'])->select()->toArray();
        foreach ($res['list'] as $key => $value) {
            if($value['starttime'] > time()){
                $res['list'][$key]['is_start'] = 0;
            }else{
                $res['list'][$key]['is_start'] = 1;
            }
            if($value['endtime'] < time()){
                $res['list'][$key]['is_end'] = 1;
            }else{
                $res['list'][$key]['is_end'] = 0;
            }
            $res['list'][$key]['activitytime_cn'] = date('Y-m-d',$value['activitytime']);
        }
        zimu_json($res);

    }
