<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $ids = intval($_GET['ids']);
    $posterid = intval($_GET['posterid']) ? intval($_GET['posterid']) : 1;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);

    if($myuid['uid']){
        $qmhn = Db::name('zimu_xiangqin_qmhn_user')->where([['uid', '=', $myuid['uid']], ['status', '=', 1]])->find();
        if($qmhn){
            $qmhn_url = '&qmhn=1&fromid='.$myuid['uid'];
            $qmhn_url2 = 'qmhn_';
        }
    }

    if(!$ids){
        $ids = $myuid['uid'];
    }

    $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();
    if($myinfo['sex']==1){
        $myinfo['sex_cn'] = $language_zimu['poster_inc_php_0'];
    }else{
        $myinfo['sex_cn'] = $language_zimu['poster_inc_php_1'];
    }

    $qrsize = 5;
    $dir = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/';
    $qrcode_file = $dir.'qrcode/details_'.$qmhn_url2.$myuid['uid'].'_'.$ids.'.jpg';

    $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$ids.'&mobile=2';

    $qrcode_url = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&qmhn=1&fromid='.$myuid['uid'].'&tourl='.urlencode($share_url);


    if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time()-86400 ) {

        if ($zmdata['settings']['wx_create_qrcode'] == 1) {
            require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);
            $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                'scene_str' =>  'xiangqin_poster_zimuyun' . $ids,
                'expire' => 2591000
            )));
            $qrcode_img = dfsockopen($qrcode_url2);
            $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
            $fp = fopen($qrcode_file, 'wb');
            flock($fp, 2);
            fwrite($fp,$qrcode_img);
            fclose($fp);

        }else{
            require_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/class/qrcode.class.php';
            QRcode::png($qrcode_url, $qrcode_file, QR_ECLEVEL_L, $qrsize);
        }
    }

    $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/qrcode/details_'.$qmhn_url2.$myuid['uid'].'_'.$ids.'.jpg';

    $text1 = $language_zimu['poster_inc_php_2'].$myinfo['no'];
    $text2 = $myinfo['sex_cn'].' '.$myinfo['age'].$language_zimu['poster_inc_php_3'].' '.$ganqing_array[$myinfo['ganqing']-1].' '.$language_zimu['poster_inc_php_4'].$shuxiang_array[$myinfo['shuxiang']] . ' ' . $xingzuo_array[$myinfo['constellation']-1];
    $text3 = $language_zimu['poster_inc_php_5'].$myinfo['height'].'CM'.' '.$language_zimu['poster_inc_php_6'].$myinfo['weight'].'KG'.' '.$language_zimu['poster_inc_php_7'].$xueli_array[$myinfo['xueli']-1];
    $text4 = $work_array[$myinfo['work']-1] . ' '.$language_zimu['poster_inc_php_8'] .$yuexin_array[$myinfo['yuexin']-1];
    $text5 = $zhufang_array[$myinfo['zhufang']-1].' '.$gouche_array[$myinfo['gouche']-1];
    $text6 = $xiyan_array[$myinfo['xiyan']-1] . ' '.$hejiu_array[$myinfo['hejiu']-1];

    require_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/class/poster_laofu110.php';

    $config[1] = array(
        'bg' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_1.jpg',
        'format'=>'jpg',
        'quality'=>66,
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'radius' => 100,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'left' => 180,
                'top' => 940,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
        ),
    );

    $config[2] = array(
        'bg' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_2.jpg',
        'format'=>'jpg',
        'quality'=>66,
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'radius' => 100,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 420,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
        ),
    );

    $config[3] = array(
        'bg' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_3.jpg',
        'format'=>'jpg',
        'quality'=>66,
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'radius' => 100,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 160,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '87,120,113',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
            ),
        ),
    );

    $config[4] = array(
        'bg' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_4.jpg',
        'format'=>'jpg',
        'quality'=>66,
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'radius' => 100,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 240,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
        ),
    );

    $config[5] = array(
        'bg' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_5.jpg',
        'format'=>'jpg',
        'quality'=>66,
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'radius' => 100,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 290,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
            ),
        ),
    );

    $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/haibao/details_'.$qmhn_url2.$myuid['uid'].'_'.$myinfo['uid'].'_'.$posterid.'.png';

        $Poster=new \Laofu\Image\Poster($config[$posterid]);
        $img=$Poster->make($hbpath);
        if(!$img){
            $err=$Poster->errMsg;
        }

        $hbimg = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/haibao/details_'.$qmhn_url2.$myuid['uid'].'_'.$myinfo['uid'].'_'.$posterid.'.png?v='.time();


    $myinfo['hbimg'] = $hbimg;

    zimu_json($myinfo);

