<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $mobile = strip_tags($_GET['mobile']);
    if(!$mobile){
        parse_str($_SERVER["QUERY_STRING"],$myArray);
        $mobile = $myArray['mobile'];
    }

    $qmhn = intval($_GET['qmhn']);

    if($qmhn != 1){
        $user = Db::name('zimu_xiangqin_users')->where('mobile', $mobile)->find();
        $user['uid'] && $user['uid'] != $myuid['uid'] && zimu_json('',$language_zimu['sendsms_inc_php_0'],1);
    }

    if(getcookie('verify_mobile_time') && ($_G['timestamp']-getcookie('verify_mobile_time'))<60){
        zimu_json('',$language_zimu['sendsms_inc_php_1'].'180'.$language_zimu['sendsms_inc_php_2'],1);
    }

    $rand = mt_rand(1000, 9999);

    $sms_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'aliyunsms')->find();

    $sms_paramter = unserialize($sms_paramter['parameter']);

    $app_key = $sms_paramter['smsAppKey'];
    $app_secret = $sms_paramter['smssecretKey'];
    $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
    $smsdata['code'] = $rand;

    $requestUrl = "http://dysmsapi.aliyuncs.com/";
    $params['PhoneNumbers']= $mobile;
    $params['SignName']= $sign_name;
    $params['TemplateCode']= $sms_paramter['smsTemplateCode'];
    $params['TemplateParam']= json_encode($smsdata);
    $params['OutId']= "3333";
    $params['RegionId']= "cn-hangzhou";
    $params['AccessKeyId']= $app_key;
    $params['Format']= "JSON";
    $params['SignatureMethod']= "HMAC-SHA1";
    $params['SignatureVersion']= "1.0";
    $params['SignatureNonce']= uniqid();
    date_default_timezone_set("GMT");
    $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
    $params['Action']= "SendSms";
    $params['Version']= "2017-05-25";
    $params['Signature']= aliyun_signature($params,$app_secret);

    include_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/Aliyun_HttpHelper.class.php';

    $Aliyun_HttpHelper = new Aliyun_HttpHelper();
    $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));

    $aaa = object_array(json_decode($result));

    if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {

        $smslog_data['uid'] = $myuid['uid'];
        $smslog_data['mobile'] = $mobile;
        $smslog_data['code'] = $rand;
        $smslog_data['addtime'] = $_G['timestamp'];
        Db::name('zimu_xiangqin_smslog')->insertGetId($smslog_data);

        dsetcookie('verify_mobile_time',$_G['timestamp'],7200);

        $sendsmslog = ['uid' => $myuid['uid'],'mobile' => $mobile,'con' => $language_zimu['sendsms_inc_php_3'].$rand,'addtime' => time()];
        Db::name('zimu_xiangqin_sendsmslog')->insert($sendsmslog);


        zimu_json();
    }else{
        zimu_json('',mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'),1);
    }

    function aliyun_signature($params,$AccessKeySecret){
        ksort($params);

        $canonicalizedQueryString = '';
        foreach($params as $key => $value){
            $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
        }

        $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
        return $signature;
    }

    function percentEncode($str){
        $res = urlencode($str);
        $res = preg_replace('/\+/', '%20', $res);
        $res = preg_replace('/\*/', '%2A', $res);
        $res = preg_replace('/%7E/', '~', $res);
        return $res;
    }