<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

$op = addslashes($_GET['op']);
$zimu_get = zimu_array_gbk($_GET);

if($op == 'basicinfo') {

    $users_data['uid'] = $myuid['uid'];
    if ($zimu_get['myphoto'] && !preg_match('/^(http|\.)/i', $zimu_get['myphoto'])) {
        $users_data['photo'] = zm_saveimages_base64($zimu_get['myphoto'], 'photo',1,0.7);
    }elseif($zimu_get['myphoto']){
        $users_data['photo'] = $zimu_get['myphoto'];
    }
    $users_data['nickname'] = addslashes(strip_tags($zimu_get['myname']));
    $users_data['mobile'] = strip_tags($_GET['mymobile']);
    $users_data['weixin'] = addslashes(strip_tags($zimu_get['myweixin']));
    $users_data['birth'] = addslashes(strip_tags($zimu_get['mybirth']));
    $mybirth = explode('-', $users_data['birth']);
    $users_data['age'] = 2021 - $mybirth[0];
    $users_data['shuxiang'] = ($mybirth[0] - 1948) % 12;
    $users_data['constellation'] = getconstellation($mybirth[1], $mybirth[2]);
    $users_data['height'] = intval($_GET['myheight']);
    $users_data['weight'] = intval($_GET['myweight']);
    $users_data['city'] = addslashes(strip_tags($zimu_get['mycity']));
    $users_data['city2'] = addslashes(strip_tags($zimu_get['mycity2']));
    $users_data['xueli'] = intval($_GET['myxueli']) + 1;
    $users_data['ganqing'] = intval($_GET['myganqing']) + 1;
    $users_data['work'] = intval($_GET['mywork']) + 1;
    $users_data['yuexin'] = intval($_GET['myyuexin']) + 1;
    $users_data['zhufang'] = intval($_GET['myzhufang']) + 1;
    $users_data['gouche'] = intval($_GET['mygouche']) + 1;
    $users_data['xiyan'] = intval($_GET['myxiyan']) + 1;
    $users_data['hejiu'] = intval($_GET['myhejiu']) + 1;

    $oldinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

    if($oldinfo['state']==2){
        $users_data['state'] = 0;
    }
    if($zmdata['settings']['still_audit_info'] == 1 || $oldinfo['state'] != 1){
        Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update($users_data);
    }else{

        $isadd = Db::name('zimu_xiangqin_users2')->where('uid', $myuid['uid'])->find();

        $diff_info = array_merge($oldinfo,$users_data);
        $diff_info2 = array_diff_assoc($diff_info,$oldinfo);

    if($diff_info2){

        if(!$isadd){
            Db::name('zimu_xiangqin_users2')->insertGetId($users_data);
        }else{
            Db::name('zimu_xiangqin_users2')->where('uid', $myuid['uid'])->update($users_data);
        }

        $first = $language_zimu['signup_inc_php_0'];
        $keyword1 = $language_zimu['signup_inc_php_1'];
        $keyword2 = $language_zimu['signup_inc_php_2'];
        $keyword3 = $language_zimu['signup_inc_php_3'];
        $remark = $users_data['nickname'].$users_data['birth'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$myuid['uid'].'&mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
        notification_all('admin',$first,$keyword1,$keyword2,$keyword3,$remark,$link);
        if($oldinfo['hn_uid']){
            notification_all($oldinfo['hn_uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);
        }

    }

    }


    zimu_json('', $language_zimu['signup_inc_php_4'], 200);

}else {

    $users_data['mobile'] = strip_tags($_GET['mymobile']);
    $mycode = strip_tags($_GET['mycode']);

    $isreal = Db::name('zimu_xiangqin_smslog')->where([['uid','=',$myuid['uid']],['mobile','=',$users_data['mobile']],['code','=',$mycode]])->order('id', 'desc')->find();

    if(!$isreal){
        zimu_json('',$language_zimu['signup_inc_php_5'],1);
    }

    $users_data['no'] = 52083333+$myuid['uid'];
    $users_data['uid'] = $myuid['uid'];
    $users_data['nickname'] = addslashes(strip_tags($zimu_get['myname2']));
    $users_data['realname'] = addslashes(strip_tags($zimu_get['myname']));
    if ($zimu_get['myphoto'] && !preg_match('/^(http|\.)/i', $zimu_get['myphoto'])) {
        $users_data['photo'] = zm_saveimages_base64($zimu_get['myphoto'], 'photo');
    }elseif($zimu_get['myphoto']){
        $users_data['photo'] = $zimu_get['myphoto'];
    }
    $users_data['sex'] = intval($_GET['mysex']);
    $users_data['xueli'] = intval($_GET['myxueli'])+1;
    $users_data['yuexin'] = intval($_GET['myyuexin'])+1;
    $mybirth = addslashes(strip_tags($zimu_get['mybirth']));
    $mybirth = str_replace(',','-',$mybirth);
    $mybirth = explode('-',$mybirth);
    $mybirth[0] = 1970 + $mybirth[0];
    $mybirth[1] = $mybirth[1] + 1;
    $mybirth[2] = $mybirth[2] + 1;
    $users_data['birth'] = implode("-", $mybirth);
    $users_data['age'] = 2021 - $mybirth[0];
    $users_data['shuxiang']         = ($mybirth[0]-1948)%12;
    $users_data['constellation'] = getconstellation($mybirth[1],$mybirth[2]);
    $users_data['city'] = addslashes(strip_tags($zimu_get['mycity']));
    $users_data['city2'] = addslashes(strip_tags($zimu_get['mycity2']));
    $users_data['height'] = intval($_GET['myheight'])+150;
    $users_data['weight'] = intval($_GET['myweight'])+40;
    $users_data['ganqing'] = intval($_GET['myganqing'])+1;
    $users_data['work'] = intval($_GET['mywork'])+1;
    $users_data['zhufang'] = intval($_GET['myzhufang'])+1;
    $users_data['gouche'] = intval($_GET['mygouche'])+1;
    $users_data['xiyan'] = intval($_GET['myxiyan'])+1;
    $users_data['hejiu'] = intval($_GET['myhejiu'])+1;
    $users_data['weixin'] = addslashes(strip_tags($zimu_get['myweixin']));
    $users_data['addtime'] = $_G['timestamp'];

    $zimu_xiangqin_fromid = getcookie('zimu_xiangqin_fromid');
    if($zimu_xiangqin_fromid){
        $users_data['qmhn_uid'] = $zimu_xiangqin_fromid;
    }

    $isadd = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

    if(!$isadd){
        $hnuser = find_hnuid();
        $users_data['hn_uid'] = $hnuser['uid'];
        $users_data['hn_name'] = $hnuser['kefu_name'];
        $ids = Db::name('zimu_xiangqin_users')->insertGetId($users_data);
    }

    $users_data['id'] = $ids;
    $myinfo['myinfo'] = $users_data;

    $first = $language_zimu['signup_inc_php_6'];
    $keyword1 = $language_zimu['signup_inc_php_7'];
    $keyword2 = $language_zimu['signup_inc_php_8'];
    $keyword3 = $language_zimu['signup_inc_php_9'];
    $remark = $users_data['realname'].$users_data['birth'];
    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$myuid['uid'].'&mobile=2';
    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
    notification_all('admin',$first,$keyword1,$keyword2,$keyword3,$remark,$link);
    if($hnuser['uid']){
        notification_all($hnuser['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);
    }
    zimu_json($myinfo);

}
