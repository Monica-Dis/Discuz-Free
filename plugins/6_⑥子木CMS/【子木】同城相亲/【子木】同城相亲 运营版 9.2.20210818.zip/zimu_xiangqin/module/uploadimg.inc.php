<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $op = addslashes($_GET['op']);

    if(!empty($_FILES['file'])){

        //��ȡ��չ��
        $pathinfo      = pathinfo($_FILES['file']['name']);
        $exename  = strtolower($pathinfo['extension']);
        if($exename != 'png'  && $exename != 'jpeg' && $exename != 'jpg' && $exename != 'gif'){
            exit('error');
        }
        $imageSavePath = uniqid().'.'.$exename;

        $date        = date('ym/d/');
        $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/uploadzimucms/album/' . $date;

        if (!is_dir($save_avatar)) {
            mkdir($save_avatar, 0777, true);
        }

        if(move_uploaded_file($_FILES['file']['tmp_name'], $save_avatar.$imageSavePath)){

            $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
            $oss_paramter = unserialize($oss_paramter['parameter']);

            if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
                $saved_file = $save_avatar.$imageSavePath;
                include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
                if ($surl = zm_oss_upload('zimu_xiangqin/album/' . $date . $imageSavePath, $saved_file)) {
                    @unlink($saved_file);
                    echo $imgurl = $surl;
                    exit();
                }
            }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

                $saved_file = $save_avatar.$imageSavePath;
                include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
                if ($surl=zm_qn_upload('zimu_xiangqin/album/' . $date . $imageSavePath,$saved_file)) {
                    unlink($saved_file);
                    error_reporting(0);
                    echo $imgurl = $surl;
                    exit();
                }

            }


            echo $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/album/' . $date.$imageSavePath;
        }
    }