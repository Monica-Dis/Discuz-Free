
<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');

$language_zimu = include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_xiangqin/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin');
define('ZIMUCMS_URL2', $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5/');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

    require DISCUZ_ROOT . './source/plugin/zimu_xiangqin/lib/thinkorm/v1/vendor/autoload.php';

    @require_once (DISCUZ_ROOT .'./source/plugin/zimu_xiangqin/module/core.php');

    use think\Db;

    Db::setConfig([
        'type'     => 'mysql',
        'hostname' => $_G['config']['db'][1]['dbhost'],
        'username' => $_G['config']['db'][1]['dbuser'],
        'database' => $_G['config']['db'][1]['dbname'],
        'password'    => $_G['config']['db'][1]['dbpw'],
        'charset'  => $_G['config']['db'][1]['dbcharset'],
        'prefix'   => $_G['config']['db'][1]['tablepre'],
        'resultset_type' => 'collection',
        'fields_strict'  => false,
        'debug'    => false,
    ]);

    $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];

    $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();

    $zmdata['settings'] = unserialize($setdata['settings']);

    $zmdata2 = $zmdata;
    $zmdata2['settings']['weixin_mchkey'] = '123';

    $xueli_array = explode(',',$zmdata['settings']['xueli_type']);
    $yuexin_array = explode(',',$zmdata['settings']['yuexin_type']);
    $ganqing_array = explode(',',$zmdata['settings']['ganqing_type']);
    $work_array = explode(',',$zmdata['settings']['work_type']);
    $zhufang_array = explode(',',$zmdata['settings']['zhufang_type']);
    $gouche_array = explode(',',$zmdata['settings']['gouche_type']);
    $xingge_array = explode(',',$zmdata['settings']['xingge_type']);
    $aihao_array = explode(',',$zmdata['settings']['aihao_type']);
    $jieshao_array = explode('zimuyun',$zmdata['settings']['jieshao_type']);
    $shuxiang_array = explode(',',$zmdata['settings']['shuxiang_type']);
    $xingzuo_array = explode(',',$zmdata['settings']['xingzuo_type']);
    $xiyan_array = explode(',',$zmdata['settings']['xiyan_type']);
    $hejiu_array = explode(',',$zmdata['settings']['hejiu_type']);
    $zhufang2_array = explode(',',$zmdata['settings']['zhufang2_type']);
    $xiyan2_array = explode(',',$zmdata['settings']['xiyan2_type']);
    $hejiu2_array = explode(',',$zmdata['settings']['hejiu2_type']);

$formhash = $_G['formhash'];

//$_GET['token'] = 'CvNLcRZ71UZab9VdTe9RzXZI7cW5OiNj';

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

    $op = addslashes($_GET['op']);
    if($op=='xcx'){
        define('SF_APPID', $zmdata['settings']['xcx_appid']);
        define('SF_MCHID', $zmdata['settings']['xcx_mchid']);
        define('SF_APPSECRET', $zmdata['settings']['xcx_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['xcx_mchkey']);
    }else if($op=='liaochengliao'){
        define('SF_APPID', $zmdata['settings']['app_appid']);
        define('SF_MCHID', $zmdata['settings']['app_mchid']);
        define('SF_APPSECRET', $zmdata['settings']['app_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['app_mchkey']);
    }else{
        define('SF_APPID', $zmdata['settings']['weixin_appid']);
        define('SF_MCHID', $zmdata['settings']['weixin_mchid']);
        define('SF_APPSECRET', $zmdata['settings']['weixin_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['weixin_mchkey']);
    }

    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/lib/WxPay.Config.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/lib/WxPay.Api.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/example/WxPay.JsApiPay.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/example/WxPay.NativePay.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/example/log.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/wxpay/lib/WxPay.Data.php');


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_xiangqin']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_xiangqin']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_xiangqin']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


    function isuid($refererurl='')
    {

        global $_G;
        define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
        define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
        define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if(!$refererurl){
            $refererurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
        }

        if (IN_MAGAPP && !$_G['uid']){

            $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();

            $mag_paramter = unserialize($mag_paramter['parameter']);

        }

        if (IN_MAGAPP && !$_G['uid'] && $mag_paramter['magapp_hostname']){


            $userAgent = $_SERVER['HTTP_USER_AGENT'];
            $info = strstr($userAgent, "MAGAPPX");
            $info=explode("|",$info);
            $token = $info[7];

            $appurl = $mag_paramter['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$mag_paramter['magapp_secret'];

            $appdata = dfsockopen($appurl);
            if (!$appdata) {
                $appdata = file_get_contents($appurl);
            }
            $r =  json_decode($appdata, true);
            if($r['data']['user_id']>0){

                $member = getuserbyuid($r['data']['user_id'], 1);
                if (!$member) {
                    dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }
                if (isset($member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($member['uid']);
                }
                require_once libfile('function/member');
                $cookietime = 1296000;
                setloginstatus($member, $cookietime);
                return true;

            }else{
                exit('<script src="source/plugin/zimu_xiangqin/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    });
                    </script>');
            }

        }else{

            if (!$_G['uid']) {
                if (IN_XIAOYUNAPP) {
                    exit('<script language="javascript" src="source/plugin/zimu_xiangqin/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
                    AppbymeJavascriptBridge.login(function(data){
                        top.location.href="' . $refererurl . '";
                        });
                        });
                        </script>');
                } else if (IN_MAGAPP) {
                    exit('<script src="source/plugin/zimu_xiangqin/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
                        top.location.href="' . $refererurl . '";
                        });
                        </script>');
                } else if (IN_QFAPP) {
                    exit('<script src="source/plugin/zimu_xiangqin/static/js/jquery-2.1.4.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
                    if(state==1){
                        QFH5.refresh(1);
                        }else{
                            alert(data.error);//data.error: string
                        }
                        });
                    }
                    </script>');
                } else {
                    dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }
            }
        }
    }


    function tpl_form_field_image($id, $val) {
        if (!$val) {
            $val = 'source/plugin/zimu_xiangqin/static/nopic.jpg';
        }

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';

        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');

        $language_zimu = include $includefile;

        return '<div class="input-group "><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="form-control valid" /><span class="input-group-btn"><input type="button" name="button" id="button1" value="'.$language_zimu['config_php_0'].'" class="btn btn-primary" /></span><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" style="position: absolute;top: 0px;left: 0px;height: 40px;width: 100%;filter: alpha(opacity: 0);opacity: 0;cursor: pointer;" size="200" hidefocus="true">
  </div><div class="input-group " style="margin-top:6px;"><input type="hidden" name="img_' . $id . '" value="' . $val . '"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150" id="img_' . $id . '"><em class="close" style="position:absolute; top: 0px; right: -14px;" onclick="deleteImage(this)">x</em></div>';

    }

function zimu_array_gbk($string,$ajax_status=null){
    global $_G;
    if($_G['charset'] == 'gbk'){
        if($ajax_status == true){
            if(is_array($string)){
                return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
            }else{
                return iconv('GB2312', 'UTF-8', $string);
            }
        }else{
            if(is_array($string)){
                $StringArr = array();
                foreach($string as $key=>$value){
                    if(is_array($value)){
                        foreach($value as $k=>$v){
                            $encode = mb_detect_encoding($v, array('UTF-8','GB2312','GBK'));
                            if($encode == 'UTF-8'){
                                $StringArr[$key][$k] = iconv('UTF-8','GB2312//IGNORE',$v);
                            }else if($encode == 'EUC-CN'){
                                $StringArr[$key][$k] = $v;
                            }
                        }
                    }else{
                        $encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
                        if($encode == 'UTF-8'){
                            $StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
                        }else if($encode == 'EUC-CN'){
                            $StringArr[$key] = $value;
                        }
                    }
                }
                return $StringArr;
            }else{
                $encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
                if($encode == 'UTF-8'){
                    return iconv('UTF-8','GB2312//IGNORE', $string);
                }else if($encode == 'EUC-CN'){
                    return $string;
                }
            }
        }
    }else{
        return $string;
    }
}

function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}

    function zimu_array_gbk2($String)
    {
        if (is_array($String)) {
            foreach ($String as $key => $val) {
                $String[$key] = zimu_array_gbk2($val);
            }
        } else {
            if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
                $String = $String;
            } else {
                $String = diconv($String,'UTF-8',CHARSET);
            }
        }
        return $String;
    }

function zm_saveimages($FILES, $type = 'zimucms',$local=0)
{
    global $_G;

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();

    $upload->init($FILES, 'uploadzimucms');

    $upload2 = object_array($upload);
    if($upload2['attach']['isimage'] != 1){
        return false;
    }

    if ($upload->error()) {
        return '';
    }

    $upload->save();
    if ($upload->error()) {
        return '';
    }

    $pic = $upload->attach['attachment'];

    if ($upload->attach['imageinfo'][0] > 2500 || $upload->attach['imageinfo'][1] > 2500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }


    if($local==0){
    $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/'.$pic;
        include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_xiangqin/'.$pic, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/'.$pic;
        include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
        if ($surl=zm_qn_upload('zimu_xiangqin/'.$pic,$saved_file)) {
            unlink($saved_file);
            error_reporting(0);
            return $imgurl = $surl;
        }

    }
    }

    if ($pic2) {
        return $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/' . $pic;
    }
}

function zm_saveimages_base64($img_base64, $type = 'photo',$compress='1',$percent=1)
{
    global $_G;
    $filename      = uniqid() . '.jpg';

if (preg_match('/^(data:\s*image\/(\w+);base64,)/',$img_base64,$result)){


    $pic           = base64_decode(str_replace($result[1],'',$img_base64));

    $date        = date('ym/d/');
    $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date;

    if (!is_dir($save_avatar)) {
        mkdir($save_avatar, 0777, true);
    }

    file_put_contents($save_avatar . $filename, $pic);

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/imgcompress.class.php';
    $image = (new imgcompress($save_avatar . $filename,$percent))->compressImg($save_avatar . $filename);


    $oss_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'alioss')->find();
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_xiangqin/'. $type . '/' . $date . $filename, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once(DISCUZ_ROOT.'source/plugin/zimu_xiangqin/lib/Qiniu/upload.php');
        if ($surl=zm_qn_upload('zimu_xiangqin/'. $type . '/' . $date . $filename,$saved_file)) {
            unlink($saved_file);
            error_reporting(0);
            return $imgurl = $surl;
        }

    }

    $show_path = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/uploadzimucms/' . $type . '/' . $date . $filename;
    
    return $show_path;
}



}
function zimu_json($data = '', $msg = '', $status = 200)
{
    global $_G;
    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/json.class.php';
    $data['timestamp'] = $_G['timestamp'];
    $data              = array(
        'status' => $status,
        'msg' => $msg,
        'data' => $data
    );
    echo $jsondata = CJSON::encode($data);
    exit();
}

    function getRandChar($length)
    {
        $str    = null;
        $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        $max    = strlen($strPol) - 1;

        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }

        return $str.time();
    }

function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}

    function getFile($url, $save_dir = '', $filename = '', $type = 0, $isutf8 = 0) {
        if (trim($url) == '') {
            return false;
        }
        if (trim($save_dir) == '') {
            $save_dir = './';
        }
        if (0 !== strrpos($save_dir, '/')) {
            $save_dir.= '/';
        }

        if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
            return false;
        }
        if ($type) {
            $ch = curl_init();
            $timeout = 5;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $content = curl_exec($ch);
            curl_close($ch);
        } else {
            ob_start();
            readfile($url);
            $content = ob_get_contents();
            ob_end_clean();
        }
        $size = strlen($content);
        $fp2 = @fopen($save_dir . $filename, 'w+');
        if($isutf8){
            $content = diconv($content,'gbk','UTF-8');
            //$content = utf8_encode($content);
            $content = "\xEF\xBB\xBF".$content;
        }
        fwrite($fp2, $content);
        fclose($fp2);
        chmod($save_dir.$filename,0755);
        unset($content, $url);
        if($isutf8){
            checkBOM($save_dir . $filename);
        }
        return array(
            'file_name' => $filename,
            'save_path' => $save_dir . $filename
        );
    }

    function checkBOM($filename)
    {
        global $auto;
        $contents   = file_get_contents($filename);
        $charset[1] = substr($contents, 0, 1);
        $charset[2] = substr($contents, 1, 1);
        $charset[3] = substr($contents, 2, 1);
        if (ord($charset[1]) == 239 && ord($charset[2]) == 187 && ord($charset[3]) == 191) {
            $rest = substr($contents, 3);
            rewrite($filename, $rest);
        }
    }

    function rewrite($filename, $data)
    {
        $filenum = fopen($filename, "w");
        flock($filenum, LOCK_EX);
        fwrite($filenum, $data);
        fclose($filenum);
    }

    function zimu_template($name,$defdir='',$ishow=1){
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';

        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');

        $language_zimu = include $includefile;

        if(strpos('demo.zimucms.com', 'demo.zimucms.com') !== false){
            $debug = 0;
        }else{
            $debug = 0;
        }

        if(!$defdir){
            if(!checkmobile()){
                $defdir = '';
            }else{
                $defdir = 'touch';
            }
        }

        if($debug == 0){
            $oldtpl = file_get_contents(DISCUZ_ROOT . './source/plugin/zimu_xiangqin/template/'.$defdir.'/'.$name.'.htm');

            if($oldtpl == 'lizimu' || !$oldtpl){
                $newtpl = 'http://demo.zimucms.com/source/plugin/zimu_xiangqin/template_cn/'.$defdir.'/'.$name.'.htm';
                $save_dir = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/template/'.$defdir.'/';
                $filename = $name.'.htm';

                if (!is_writable ($save_dir)) {
                    echo $language_zimu['config_php_1'].$save_dir.$language_zimu['config_php_2'].'WWW'.$language_zimu['config_php_3'].'755'.$language_zimu['config_php_4'].'QQ66866211';exit();
                }

                if($_G['charset'] == 'utf-8'){
                    getFile($newtpl, $save_dir, $filename, 1, 1);
                }else{
                    getFile($newtpl, $save_dir, $filename, 1);
                }
            }
        }
        if($ishow){
            return template('zimu_xiangqin:'.$name);
        }
    }


    zimu_template('footer_base','common',0);
    zimu_template('footer','common',0);
    zimu_template('header_base','common',0);
    zimu_template('zimu_head','common',0);
    zimu_template('success','common',0);
    zimu_template('index_guide','',0);

    function checktoken($mytoken,$needlogin=1)
    {
        global $_G;

        if ($mytoken) {

            $isuid = Db::name('zimu_xiangqin_token')->where('token', $mytoken)->find();

        }

        if ($needlogin == 0 || $isuid['uid'] > 0) {

            return $isuid;

        } else {

            $res['token'] = 'error';
            zimu_json($res,'',201);
            exit();

        }

    }

    function pagination($total, $pageIndex, $pageSize = 15, $url = '', $context = array('before' => 5, 'after' => 4, 'ajaxcallback' => '', 'callbackfuncname' => '')) {
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';

        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');

        $language_zimu = include $includefile;

        $pdata = array(
            'tcount' => 0,
            'tpage' => 0,
            'cindex' => 0,
            'findex' => 0,
            'pindex' => 0,
            'nindex' => 0,
            'lindex' => 0,
            'options' => ''
        );

        $pdata['tcount'] = $total;
        $pdata['tpage'] = (empty($pageSize) || $pageSize < 0) ? 1 : ceil($total / $pageSize);
        if ($pdata['tpage'] <= 1) {
            return '';
        }
        $cindex = $pageIndex;
        $cindex = min($cindex, $pdata['tpage']);
        $cindex = max($cindex, 1);
        $pdata['cindex'] = $cindex;
        $pdata['findex'] = 1;
        $pdata['pindex'] = $cindex > 1 ? $cindex - 1 : 1;
        $pdata['nindex'] = $cindex < $pdata['tpage'] ? $cindex + 1 : $pdata['tpage'];
        $pdata['lindex'] = $pdata['tpage'];


        $_GET['page'] = $pdata['findex'];
        $pdata['faa'] = 'href="?' . http_build_query($_GET) . '"';
        $_GET['page'] = $pdata['pindex'];
        $pdata['paa'] = 'href="?' . http_build_query($_GET) . '"';
        $_GET['page'] = $pdata['nindex'];
        $pdata['naa'] = 'href="?' . http_build_query($_GET) . '"';
        $_GET['page'] = $pdata['lindex'];
        $pdata['laa'] = 'href="?' . http_build_query($_GET) . '"';

        $html = '<div><ul class="pagination pagination-centered">';
        if ($pdata['cindex'] > 1) {
            $html .= '<li><a '.$pdata["faa"].' class="pager-nav">'.$language_zimu['config_php_5'].'</a></li>';
            $html .= '<li><a '.$pdata["paa"].' class="pager-nav">&laquo;'.$language_zimu['config_php_6'].'</a></li>';
        }
        if (!$context['before'] && $context['before'] != 0) {
            $context['before'] = 5;
        }
        if (!$context['after'] && $context['after'] != 0) {
            $context['after'] = 4;
        }

        if ($context['after'] != 0 && $context['before'] != 0) {
            $range = array();
            $range['start'] = max(1, $pdata['cindex'] - $context['before']);
            $range['end'] = min($pdata['tpage'], $pdata['cindex'] + $context['after']);
            if ($range['end'] - $range['start'] < $context['before'] + $context['after']) {
                $range['end'] = min($pdata['tpage'], $range['start'] + $context['before'] + $context['after']);
                $range['start'] = max(1, $range['end'] - $context['before'] - $context['after']);
            }
            for ($i = $range['start']; $i <= $range['end']; $i++) {
                if ($context['isajax']) {
                    $aa = 'href="javascript:;" page="' . $i . '" '. ($callbackfunc ? 'onclick="'.$callbackfunc.'(\'' . $url . '\', \'' . $i . '\', this);return false;"' : '');
                } else {
                    if ($url) {
                        $aa = 'href="?' . str_replace('*', $i, $url) . '"';
                    } else {
                        $_GET['page'] = $i;
                        $aa = 'href="?' . http_build_query($_GET) . '"';
                    }
                }
                $html .= ($i == $pdata['cindex'] ? '<li class="active"><a href="javascript:;">' . $i . '</a></li>' : "<li><a {$aa}>" . $i . '</a></li>');
            }
        }

        if ($pdata['cindex'] < $pdata['tpage']) {
            $html .= '<li><a '.$pdata['naa'].' class="pager-nav">'.$language_zimu['config_php_7'].'&raquo;</a></li>';
            $html .= '<li><a '.$pdata['laa'].' class="pager-nav">'.$language_zimu['config_php_8'].'</a></li>';
        }
        $html .= '</ul></div>';
        return $html;
    }

    function torealapi($appcode,$idCard,$name)
    {
        global $_G;

        $host = "https://idcert.market.alicloudapi.com";
        $path = "/idcard";
        $method = "GET";
        $appcode = $appcode;
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "idCard=".$idCard."&name=".zimu_array_utf8($name);
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        //curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$".$host, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $out_put = curl_exec($curl);
        return $out_put;

    }

    function get_url2($name1='',$name2='',$name3='',$name4='',$name5='') {

        global $_G;

        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        if(strpos($relate_url, '?') !== false){
            $reurl = rtrim($_G['siteurl'], "/").$relate_url;
        }else{
            $reurl= rtrim($_G['siteurl'], "/").$relate_url.'?';
        }

        $a = explode('?',$reurl);
        $url_f = $a[0];
        $query = $a[1];
        parse_str($query,$arr);
        $arr[$key] = $value;
        if($name1){
            unset($arr[$name1]);
        }
        if($name2){
            unset($arr[$name2]);
        }
        if($name3){
            unset($arr[$name3]);
        }
        if($name4){
            unset($arr[$name4]);
        }
        if($name5){
            unset($arr[$name5]);
        }
        return $url_f.'?'.http_build_query($arr);

    }

    function getconstellation($month,$day){
        if (($month == 1 && $day >= 20) || ($month == 2 && $day <= 18)) {
            $strValue = 1;
        } else if (($month == 2 && $day >= 19) || ($month == 3 && $day <= 20)) {
            $strValue = 2;
        } else if (($month == 3 && $day > 20) || ($month == 4 && $day <= 19)) {
            $strValue = 3;
        } else if (($month == 4 && $day >= 20) || ($month == 5 && $day <= 20)) {
            $strValue = 4;
        } else if (($month == 5 && $day >= 21) || ($month == 6 && $day <= 21)) {
            $strValue = 5;
        } else if (($month == 6 && $day > 21) || ($month == 7 && $day <= 22)) {
            $strValue = 6;
        } else if (($month == 7 && $day > 22) || ($month == 8 && $day <= 22)) {
            $strValue = 7;
        } else if (($month == 8 && $day >= 23) || ($month == 9 && $day <= 22)) {
            $strValue = 8;
        } else if (($month == 9 && $day >= 23) || ($month == 10 && $day <= 23)) {
            $strValue = 9;
        } else if (($month == 10 && $day > 23) || ($month == 11 && $day <= 22)) {
            $strValue = 10;
        } else if (($month == 11 && $day > 22) || ($month == 12 && $day <= 21)) {
            $strValue = 11;
        } else if (($month == 12 && $day > 21) || ($month == 1 && $day <= 19)) {
            $strValue = 12;
        }
        return $strValue;
    }

    function finish_order($order_id,$trade_no)
    {

        $_G = $GLOBALS['_G'];
        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $order = Db::name('zimu_xiangqin_order')->where('oid', $order_id)->find();

        $order['params'] = $order['params']?unserialize($order['params']):array();

        if($order && $order['is_paid'] == 1) {

        $config = $_G['cache']['plugin']['zimu_xiangqin'];
        $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();
        $config['base'] = $setdata;
        $config['settings'] = unserialize($setdata['settings']);

        $setsqlarr['is_paid']           = 2;
        $setsqlarr['order_sn']           = $trade_no;
        $setsqlarr['payment_time']           = time();
        Db::name('zimu_xiangqin_order')->where('id' ,$order['id'])->update($setsqlarr);

            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);

            switch($order['service_name']){
                case 'buyvip':

                    $user_setmeal = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();

                    if($user_setmeal['vip_etime']>time()){
                        $vip_etime = $user_setmeal['vip_etime'] + (86400*$order['params']['days']);
                    }else{
                        $vip_etime = strtotime("{$order['params']['days']} day");
                    }

                    if($user_setmeal['toptime']>time()){
                        $toptime = $user_setmeal['toptime'] + (86400*$order['params']['days2']);
                    }else{
                        $toptime = strtotime("{$order['params']['days2']} day");
                    }

                    if($order['params']['days2']){
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['vip_type' => $order['params']['setmeal_id'],'vip_name' => $order['params']['setmeal_name'],'vip_etime' => $vip_etime,'toptime' => $toptime])->inc('line_num', $order['params']['line'])->update();
                    }else{
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['vip_type' => $order['params']['setmeal_id'],'vip_name' => $order['params']['setmeal_name'],'vip_etime' => $vip_etime])->inc('line_num', $order['params']['line'])->update();
                    }

                    $first = $language_zimu['config_php_9'];
                    $keyword1 = $language_zimu['config_php_10'];
                    $keyword2 = $user_setmeal['realname'];
                    $keyword3 = $language_zimu['config_php_11'].date('Y-m-d',$vip_etime);
                    $remark = $language_zimu['config_php_12'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/?mobile=2';
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($order['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                    $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
                    $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
                    if($qmhn_paramters['open']==1){
                        $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();
                        $qmhn_money = intval($order['pay_amount']*$qmhn_paramters['vip_sex'.$qmhn_user['sex']]);
                        if($qmhn_user['qmhn_uid']) {
                            to_qmhn_vip($qmhn_user['qmhn_uid'], $order['uid'], $qmhn_money, 'vip_sex' . $qmhn_user['sex']);
                        }
                    }

                    $first = $language_zimu['config_php_13'];
                    $keyword1 = $language_zimu['config_php_14'];
                    $keyword2 = $language_zimu['config_php_15'];
                    $keyword3 = 'UID:'.$user_setmeal['uid'].$language_zimu['config_php_16'].$user_setmeal['no'];
                    $remark = $language_zimu['config_php_17'] . $order['amount'] . $language_zimu['config_php_18'];
                    $tourl = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5/';
                    $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);

                    notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

                    break;

                case 'buyoneline':

                    Db::name('zimu_xiangqin_applyline')->where('id', $order['params']['lineid'])->update(['status' => 1]);

                    $applyline = Db::name('zimu_xiangqin_applyline')->where('id', $order['params']['lineid'])->find();

                    if($config['settings']['line_type']==1){

                        $smsinfo = Db::name('zimu_xiangqin_users')->where('uid', $applyline['touid'])->find();
                        notification_user_sms($smsinfo,'chanyoo_sms_tp1');

                        $first = $applyline['tousername'].$language_zimu['config_php_19'];
                        $keyword1 = $language_zimu['config_php_20'];
                        $keyword2 = $applyline['tousername'];
                        $keyword3 = $applyline['username'].$language_zimu['config_php_21'];
                        $remark = $language_zimu['config_php_22'];
                        $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$applyline['uid'].'&mobile=2';
                        $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                        notification_all($applyline['touid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                    }else{

                        $first = $language_zimu['config_php_23'];
                        $keyword1 = $language_zimu['config_php_24'];
                        $keyword3 = $language_zimu['config_php_25'];

                        $templatedata = array(
                            'first' => array(
                                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                                'color' => "#FF4040"
                            ),
                            'keyword1' => array(
                                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                            ),
                            'keyword2' => array(
                                'value' => urlencode(diconv($applyline['tousername'], CHARSET, 'utf-8'))
                            ),
                            'keyword3' => array(
                                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
                            ),
                            'keyword4' => array(
                                'value' => date('Y-m-d H:i', time())
                            )
                        );
                        notification_user('admin', $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL2.'pages/index/details?ids='.$applyline['uid']);

                        $magcon = '{"tag":"'.$keyword1.'","title":"'.$first.'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL2.'pages/index/details?ids='.$applyline['uid'].'","extra_info":[{"key":"'.$language_zimu['config_php_26'].'","val":"'.$keyword3.'"}],"des":"'.$language_zimu['config_php_27'].'","des_themecolor":"#008000"}';

                        notification_user_magapp('admin', $magcon);

                        $qfcon['msg'] = $first;
                        $qfcon['showdata'] = '';
                        $qfcon['showdata'] = array(
                            'title'=>diconv($keyword1, CHARSET, 'utf-8'),
                            'date'=>date('Y-m-d H:i:s'),
                            'setting'=>array(),
                            'content' => diconv($keyword3,CHARSET,'UTF-8'),
                            'url'=>ZIMUCMS_URL2.'pages/index/details?ids='.$applyline['uid']
                        );
                        notification_user_qfapp('admin', $qfcon);


                    }

                    $first = $language_zimu['config_php_28'];
                    $keyword1 = $language_zimu['config_php_29'];
                    $keyword2 = $language_zimu['config_php_30'];
                    $keyword3 = $language_zimu['config_php_31'];
                    $remark = $language_zimu['config_php_32'].'UID'.$applyline['uid'];
                    $tourl = ZIMUCMS_URL2.'pages/index/details?ids='.$applyline['uid'];
                    $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);
                    notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);


                    break;

                case 'buyline':

                    Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->inc('line_num2', $order['params']['line'])->update();

                    $first = $language_zimu['config_php_33'];
                    $keyword1 = $language_zimu['config_php_34'];
                    $keyword2 = $user_setmeal['realname'];
                    $keyword3 = $language_zimu['config_php_35'].$order['params']['line'];
                    $remark = $language_zimu['config_php_36'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/?mobile=2';
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($order['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                    $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
                    $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
                    if($qmhn_paramters['open']==1){
                        $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();
                        $qmhn_money = intval($order['pay_amount']*$qmhn_paramters['line_sex'.$qmhn_user['sex']]);
                        if($qmhn_user['qmhn_uid']){
                            to_qmhn_line($qmhn_user['qmhn_uid'],$order['uid'],$qmhn_money,'line_sex'.$qmhn_user['sex']);
                        }
                    }

                    $first = $language_zimu['config_php_37'];
                    $keyword1 = $language_zimu['config_php_38'];
                    $keyword2 = $language_zimu['config_php_39'];
                    $keyword3 = 'UID:'.$order['uid'];
                    $remark = $language_zimu['config_php_40'] . $order['amount'] . $language_zimu['config_php_41'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$order['uid'].'&mobile=2';
                    $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);

                    notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

                    break;

                case 'buytop':

                    $user_setmeal = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();

                    if($user_setmeal['toptime']>time()){
                        $toptime = $user_setmeal['toptime'] + (86400*$order['params']['days']);
                    }else{
                        $toptime = strtotime("{$order['params']['days']} day");
                    }

                    $first = $language_zimu['config_php_42'];
                    $keyword1 = $language_zimu['config_php_43'];
                    $keyword2 = $user_setmeal['realname'];
                    $keyword3 = $language_zimu['config_php_44'].date('Y-m-d',$toptime);
                    $remark = $language_zimu['config_php_45'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/?mobile=2';
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($order['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);


                    Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['toptime' => $toptime])->update();

                    $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
                    $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
                    if($qmhn_paramters['open']==1){
                        $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();
                        $qmhn_money = intval($order['pay_amount']*$qmhn_paramters['top_sex'.$qmhn_user['sex']]);
                        if($qmhn_user['qmhn_uid']){
                            to_qmhn_top($qmhn_user['qmhn_uid'],$order['uid'],$qmhn_money,'top_sex'.$qmhn_user['sex']);
                        }
                    }

                    $first = $language_zimu['config_php_46'];
                    $keyword1 = $language_zimu['config_php_47'];
                    $keyword2 = $language_zimu['config_php_48'];
                    $keyword3 = 'UID:'.$order['uid'];
                    $remark = $language_zimu['config_php_49'] . $order['amount'] . $language_zimu['config_php_50'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$order['uid'].'&mobile=2';
                    $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);

                    notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

                    break;

                case 'buypyq':

                    $pyq_data['uid'] = $order['uid'];
                    $pyq_data['username'] = $order['params']['username'];
                    $pyq_data['addtime'] = $_G['timestamp'];
                    Db::name('zimu_xiangqin_pyq')->insert($pyq_data);

                    $first = $language_zimu['config_php_51'];
                    $keyword1 = $language_zimu['config_php_52'];
                    $keyword2 = $pyq_data['username'];
                    $keyword3 = $language_zimu['config_php_53'];
                    $remark = $language_zimu['config_php_54'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/?mobile=2';
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($order['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                    break;

                case 'apply_activity':

                    Db::name('zimu_xiangqin_activity_user')->where('id', $order['params']['applyid'])->update(['ispay' => 1]);

                    $activity_user = Db::name('zimu_xiangqin_activity_user')->where([['id','=',$order['params']['applyid']]])->order(['id'=>'desc'])->find();

                    $first = $language_zimu['config_php_55'];
                    $keyword1 = $order['description'];
                    $keyword2 = $language_zimu['config_php_56'];
                    $keyword3 = 'UID:'.$activity_user['uid'].$activity_user['name'];
                    $remark = $language_zimu['config_php_57'].$activity_user['mobile'].$language_zimu['config_php_58'].$activity_user['weixin'];
                    $tourl = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5/pages/activity/show?ids='.$activity_user['aid'];
                    $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);
                    notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

                    break;
                case 'buybaodeng':

                    $baodeng_data['uid'] = $order['uid'];
                    $baodeng_data['username'] = $order['params']['username'];
                    $baodeng_data['photo'] = $order['params']['photo'];
                    $baodeng_data['touid'] = $order['params']['touid'];
                    $baodeng_data['tousername'] = $order['params']['tousername'];
                    $baodeng_data['addtime'] = $_G['timestamp'];
                    Db::name('zimu_xiangqin_baodeng')->insert($baodeng_data);

                    $first = $language_zimu['config_php_59'];
                    $keyword1 = $language_zimu['config_php_60'];
                    $keyword2 = $baodeng_data['username'];
                    $keyword3 = $language_zimu['config_php_61'];
                    $remark = $language_zimu['config_php_62'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$baodeng_data['touid'];
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($order['uid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);


                    $smsinfo = Db::name('zimu_xiangqin_users')->where('uid', $baodeng_data['touid'])->find();
                    notification_user_sms($smsinfo,'chanyoo_sms_tp4');

                    $first = $language_zimu['config_php_63'];
                    $keyword1 = $language_zimu['config_php_64'];
                    $keyword2 = $baodeng_data['tousername'];
                    $keyword3 = $language_zimu['config_php_65'];
                    $remark = $language_zimu['config_php_66'];
                    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$baodeng_data['uid'];
                    $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
                    notification_all($baodeng_data['touid'],$first,$keyword1,$keyword2,$keyword3,$remark,$link);

                    break;

                case 'payreal':

                    $res = torealapi($config['settings']['real_appcode'], $order['params']['idcard'], $order['params']['realname']);
                    if(!$res){
                        $res = torealapi($config['settings']['real_appcode'], $order['params']['idcard'], $order['params']['realname']);
                    }
                    $res2 = zm_diconv($res);
                    $res_array = json_decode($res, true);
                    $res_array = zimu_array_gbk($res_array);
                    if ($res_array['status'] == '01') {
                        $reallog_data['status'] = 1;
                        Db::name('zimu_xiangqin_reallog')->where('id', $order['params']['ids'])->update(['status' => 1,'res' => $res2]);
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->update(['realname' => $res_array['name'],'real_state' => 1]);
                        syncreal($order['uid'],$res_array['birthday']);

                        if($config['settings']['auto_pay_audit2']==1) {
                            Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['state' => 1])->update();

                            $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
                            $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
                            if($qmhn_paramters['open']==1){
                                $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();
                                to_qmhn_reg($qmhn_user['qmhn_uid'],$order['uid'],$qmhn_paramters['reg_sex'.$qmhn_user['sex']],'reg_sex'.$qmhn_user['sex']);
                            }

                        }
                    } else {
                        $reallog_data['status'] = 0;
                        Db::name('zimu_xiangqin_reallog')->where('id', $order['params']['ids'])->update(['status' => 0,'res' => $res2]);
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->update(['real_state' => 3]);
                    }

                    $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
                    $paramters = unserialize($paramter['parameter']);
                    $first = $language_zimu['config_php_67'] . ($reallog_data['status'] == 1 ? $language_zimu['config_php_68'] : $language_zimu['config_php_69']);
                    $keyword1 = $language_zimu['config_php_70'];

                    $templatedata = array(
                        'first' => array(
                            'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                            'color' => "#FF4040"
                        ),
                        'keyword1' => array(
                            'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                        ),
                        'keyword2' => array(
                            'value' => urlencode(diconv($order['params']['realname'], CHARSET, 'utf-8'))
                        ),
                        'keyword3' => array(
                            'value' => urlencode(diconv($language_zimu['config_php_71'] . ($reallog_data['status'] == 1 ? $language_zimu['config_php_72'] : $language_zimu['config_php_73']), CHARSET, 'utf-8'))
                        ),
                        'keyword4' => array(
                            'value' => date('Y-m-d H:i', $_G['timestamp'])
                        ),
                        'remark' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($res_array['msg'])), CHARSET, 'utf-8')),
                            'color' => "#008000"
                        )
                    );
                    notification_user($order['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);

                    $magcon = '{"tag":"' . $keyword1 . '","title":"' . $order['params']['realname'] . $language_zimu['config_php_74'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '","extra_info":[{"key":"' . $language_zimu['config_php_75'] . '","val":"' . ($reallog_data['status'] == 1 ? $language_zimu['config_php_76'] : $language_zimu['config_php_77']) . '"}],"des":"' . $res_array['msg'] . '<br>' . $language_zimu['config_php_78'] . '","des_themecolor":"#008000"}';

                    notification_user_magapp($order['uid'], $magcon);

                    $qfcon['msg'] = $keyword1;
                    $qfcon['showdata'] = '';
                    $qfcon['showdata'] = array(
                        'title' => diconv($keyword1, CHARSET, 'utf-8'),
                        'date' => date('Y-m-d H:i:s'),
                        'setting' => array(),
                        'content' => diconv($language_zimu['config_php_79'] . ($reallog_data['status'] == 1 ? $language_zimu['config_php_80'] : $language_zimu['config_php_81']) . $language_zimu['config_php_82'] . $res_array['msg'], CHARSET, 'UTF-8'),
                        'url' => ZIMUCMS_URL
                    );
                    notification_user_qfapp($order['uid'], $qfcon);

                    break;
                case 'payaudit':

                    if($config['settings']['auto_pay_audit']==1){
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['state' => 1,'ispay' => 1])->update();

                        $first = $language_zimu['config_php_83'];
                        $keyword1 = $language_zimu['config_php_84'];
                        $keyword3 = $language_zimu['config_php_85'];

                        $templatedata = array(
                            'first' => array(
                                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                                'color' => "#FF4040"
                            ),
                            'keyword1' => array(
                                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                            ),
                            'keyword2' => array(
                                'value' => urlencode(diconv($pyq_data['username'], CHARSET, 'utf-8'))
                            ),
                            'keyword3' => array(
                                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
                            ),
                            'keyword4' => array(
                                'value' => date('Y-m-d H:i', $_G['timestamp'])
                            )
                        );
                        notification_user($order['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);

                        $magcon = '{"tag":"'.$keyword1.'","title":"'.$first.'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'","extra_info":[{"key":"'.$language_zimu['config_php_86'].'","val":"'.$keyword3.'"}],"des":"'.$language_zimu['config_php_87'].'","des_themecolor":"#008000"}';

                        notification_user_magapp($order['uid'], $magcon);

                        $qfcon['msg'] = $first;
                        $qfcon['showdata'] = '';
                        $qfcon['showdata'] = array(
                            'title'=>diconv($keyword1, CHARSET, 'utf-8'),
                            'date'=>date('Y-m-d H:i:s'),
                            'setting'=>array(),
                            'content' => diconv($keyword3,CHARSET,'UTF-8'),
                            'url'=>ZIMUCMS_URL
                        );
                        notification_user_qfapp($order['uid'], $qfcon);

                        $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
                        $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
                        if($qmhn_paramters['open']==1){
                            $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->find();
                            to_qmhn_reg($qmhn_user['qmhn_uid'],$order['uid'],$qmhn_paramters['reg_sex'.$qmhn_user['sex']],'reg_sex'.$qmhn_user['sex']);
                        }

                    }else{
                        Db::name('zimu_xiangqin_users')->where('uid', $order['uid'])->data(['ispay' => 1])->update();
                    }

                    break;
            }
        }

    }

    function notification_user($uid,$template_id,$postdata,$posturl){
        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];
        $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();
        $zmdata['base'] = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);

        require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);

        if ($uid == 'admin') {
            $weixin_openid = explode(",", trim($zmdata['settings']['weixin_openid']));
            foreach ($weixin_openid as $key => $value) {
                if($value){
                    $template = array(
                        'touser' => $value,
                        'template_id' => $template_id,
                        'url' => urlencode($posturl),
                        'topcolor' => "#7B68EE",
                    );
                    $template['data'] = $postdata;
                    $json     = urldecode(json_encode($template));
                    $result   = $wechat_client->send_weixintemplate($json);
                }
            }
        } else if ($uid == 'superadmin') {
            $weixin_openid = explode(",", trim($zmdata['settings']['weixin_openid']));
                if($weixin_openid[0]){
                    $template = array(
                        'touser' => $weixin_openid[0],
                        'template_id' => $template_id,
                        'url' => urlencode($posturl),
                        'topcolor' => "#7B68EE",
                    );
                    $template['data'] = $postdata;
                    $json     = urldecode(json_encode($template));
                    $result   = $wechat_client->send_weixintemplate($json);
                }
        }else{

            $weixin_openid = Db::name('zimu_xiangqin_token')->where('uid', $uid)->order('id','desc')->find();
            if($weixin_openid['openid']){
                $template = array(
                    'touser' => $weixin_openid['openid'],
                    'template_id' => $template_id,
                    'url' => urlencode($posturl),
                    'topcolor' => "#7B68EE",
                );
                $template['data'] = $postdata;
                $json     = urldecode(json_encode($template));
                $result   = $wechat_client->send_weixintemplate($json);
            }

        }

    }

    function notification_user_magapp($uid,$postdata){
        global $_G;

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->order('id','desc')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        if($mag_paramter['magapp_hostname']) {
            if ($uid == 'admin') {

                $weixin_openid = explode(",", trim($mag_paramter['magapp_uids']));

                foreach ($weixin_openid as $key => $value) {

                    notification_user_magapp($value, $postdata);

                }


            } else {

                $magurl = $mag_paramter['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
                $magpostdata['user_id'] = $uid;
                $magpostdata['type'] = 'texttemp';
                $magpostdata['content'] = diconv($postdata, CHARSET, 'utf-8');
                $magpostdata['assistant_secret'] = $mag_paramter['assistant_secret'];
                $magpostdata['secret'] = $mag_paramter['magapp_secret'];
                $magpostdata['is_push'] = 1;
                $magdata = lizimu_post($magurl, $magpostdata);

            }
        }

    }


    function notification_user_qfapp($uid,$postdata){
        global $_G;

        $qf_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'qfapp')->order('id','desc')->find();
        $qf_paramter = unserialize($qf_paramter['parameter']);

        if($qf_paramter['qf_hostname']) {
            if ($uid == 'admin') {

                $weixin_openid = explode(",", trim($qf_paramter['qfapp_uids']));

                foreach ($weixin_openid as $key => $value) {

                    notification_user_qfapp($value, $postdata);

                }


            } else {

                require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/qfapp.class.php';
                $client = new QF_HTTP_CLIENT($qf_paramter['qf_hostname'], $qf_paramter['qf_secret']);

                $showdata = array(
                    'from' => $qf_paramter['qfapp_from_uid'],
                    'target' => $uid,
                    'msg' => $postdata['msg'],
                    'showData' => json_encode($postdata['showdata'])
                );

                $data = $client->post('message/template', $showdata);

            }
        }

    }

    function notification_user_sms($userinfo,$type,$tip=''){

        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $sms_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'aliyunsms')->order('id','desc')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);

        if($sms_paramter['chanyoo_username'] && $sms_paramter['chanyoo_password']) {
            $sms_url = 'https://api.chanyoo.net/sendsms';
            $postdata['username'] = $sms_paramter['chanyoo_username'];
            $postdata['password'] = $sms_paramter['chanyoo_password'];
            $postdata['mobile'] = $userinfo['mobile'];
            $content = $sms_paramter[$type];
            if($userinfo['realname']){
                $realname = zm_cutstr($userinfo['realname'],2,'');
                $nickname = $realname.($userinfo['sex']==1 ? $language_zimu['config_php_88'] : $language_zimu['config_php_89']);
            }else{
                $nickname = $language_zimu['config_php_90'];
            }
            $content = str_replace('nickname',$nickname,$content);
            if(!$tip){
                $tip = $language_zimu['config_php_91'];
            }
            $content = str_replace('reason',$tip,$content);
            $content2 = $content;
            $content = zimu_array_utf8($content);
            $postdata['content'] = $content;
            $smsdata = lizimu_post($sms_url, $postdata);

            $sendsmslog = ['uid' => $userinfo['uid'],'mobile' => $userinfo['mobile'],'con' => $content2,'addtime' => time()];
            Db::name('zimu_xiangqin_sendsmslog')->insert($sendsmslog);


        }

    }

    function isshowphoto($info,$uid){
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $uid)->find();
        foreach ($info as $key => $value) {
            if ($value['status'] == 2) {
                //$info[$key]['photo'] = ZIMUCMS_PATH . 'static/wap/image/sex' . $value['sex'] . '.png';
            }
            if (!$myinfo['uid'] && $value['guesthide'] == 1) {
                //$info[$key]['photo'] = ZIMUCMS_PATH . 'static/wap/image/sex' . $value['sex'] . '.png';
                $info[$key]['photo_tofilter'] = 1;
            }
            $isfav = Db::name('zimu_xiangqin_users_fav')->where(['uid' => $uid, 'touid' => $value['uid']])->value('id');
            $info[$key]['isfav'] = $isfav ? $isfav : 0;
            if($value['hn_uid']){
                $info[$key]['hn'] = Db::name('zimu_xiangqin_kefu')->where(['uid' => $value['hn_uid']])->find();
            }
            if ($value['vip_etime'] < time() ) {
                $info[$key]['vip_type'] = 0;
            }
            $info[$key]['weixin'] = 'lizimu';
            $info[$key]['mobile'] = '13288888888';

            $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();
            $zmdata['settings'] = unserialize($setdata['settings']);
            if($zmdata['settings']['index_flex']==2){
                $info[$key]['album'] = Db::name('zimu_xiangqin_users_album')->where('uid', $value['uid'])->order(id, asc)->limit(4)->select()->toArray();
                $info[$key]['album'] = array_filter($info[$key]['album']);
                $info[$key]['ideal'] = Db::name('zimu_xiangqin_users_ideal')->where('uid', $value['uid'])->find();
            }
        }
        return $info;
    }

    function zm_wechat_auth($tourl)
    {
        global $_G;

        if (!IN_WECHAT) {
            return;
        }

        $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];

        $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();

        $zmdata['settings'] = unserialize($setdata['settings']);


        require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
        $wechat_client2 = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);

        list($zimu_xiangqin_openid, $uptime) = getcookie('zimu_xiangqin_openid') ? explode("\t", authcode(getcookie('zimu_xiangqin_openid'), 'DECODE')) : array();

        if ($zimu_xiangqin_openid) {
            return $zimu_xiangqin_openid;
        }

        $code = addslashes($_GET['code']);

        if ($code && $_GET['codewx'] == 1) {
            $token = $wechat_client2->getAccessTokenByCode($code);

            if (!$token['openid'] && !$zimu_xiangqin_openid) {
                showmessage('error' . ($token['errmsg'] ? ' AccessToken: ' . $token['errmsg'] : ''), $tourl);
            }

            if (!$token['openid']) {
                $newtoken = $wechat_client2->getAccessToken(1, 0);
            }

            //$userinfo = $wechat_client2->getUserInfoById($token['openid'], 'zh_CN');
            $userinfo = $wechat_client2->getUserInfoByAuth($token['access_token'], $token['openid']);

            if($userinfo['openid']) {
                dsetcookie('zimu_xiangqin_openid', authcode($token['openid'] . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
                dsetcookie('zimu_xiangqin_unionid', authcode($userinfo['unionid'] . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
                return $token['openid'];
            }

        } else {

            if(strpos($tourl,'?') !== false){
                $codewx = '&codewx=1';
            }else{
                $codewx = '?codewx=1';
            }

            if ($_G['cache']['plugin']['zimu_xiangqin']['oauth2_url']) {

                $login_url = $_G['cache']['plugin']['zimu_xiangqin']['oauth2_url'] . '?appid=' . $zmdata['settings']['weixin_appid'] . '&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '&redirect_uri=' . urlencode($tourl . $codewx);

            } else {

                $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['settings']['weixin_appid'] . '&redirect_uri=' . urlencode($tourl . $codewx) . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';

            }

            dheader('Location:' . $login_url);

        }



    }

    function set_oauth_cookie($openid){
        global $_G;
        dsetcookie('zimu_xiangqin_openid', authcode($openid . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
    }

    function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

    function zm_curl($url){
        $retfrom=dfsockopen($url);
        if (!$retfrom) {
            $retfrom=zm_curl_get($url);
        }
        return $retfrom;
    }
    function zm_curl_get($url){
        if (!function_exists('curl_init')) {
            return file_get_contents($url);
        }
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        if (!curl_exec($ch)) {
            error_log(curl_error($ch));
            $data='';
        }else{
            $data=curl_multi_getcontent($ch);
        }
        curl_close($ch);
        return $data;
    }
    function zm_cutstr($string, $length, $dot = ' ...') {
        if(strlen($string) <= $length) {
            return $string;
        }

        $pre = chr(1);
        $end = chr(1);
        $string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), $string);

        $strcut = '';
        if(strtolower(CHARSET) == 'utf-8') {

            $n = $tn = $noc = 0;
            while($n < strlen($string)) {

                $t = ord($string[$n]);
                if($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
                    $tn = 1; $n++; $noc++;
                } elseif(194 <= $t && $t <= 223) {
                    $tn = 2; $n += 2; $noc += 2;
                } elseif(224 <= $t && $t <= 239) {
                    $tn = 3; $n += 3; $noc += 2;
                } elseif(240 <= $t && $t <= 247) {
                    $tn = 4; $n += 4; $noc += 2;
                } elseif(248 <= $t && $t <= 251) {
                    $tn = 5; $n += 5; $noc += 2;
                } elseif($t == 252 || $t == 253) {
                    $tn = 6; $n += 6; $noc += 2;
                } else {
                    $n++;
                }

                if($noc >= $length) {
                    break;
                }

            }
            if($noc > $length) {
                $n -= $tn;
            }

            $strcut = substr($string, 0, $n);

        } else {
            $_length = $length - 1;
            for($i = 0; $i < $length; $i++) {
                if(ord($string[$i]) <= 127) {
                    $strcut .= $string[$i];
                } else if($i < $_length) {
                    $strcut .= $string[$i].$string[++$i];
                }
            }
        }

        $strcut = str_replace(array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), array('&amp;', '&quot;', '&lt;', '&gt;'), $strcut);

        $pos = strrpos($strcut, chr(1));
        if($pos !== false) {
            $strcut = substr($strcut,0,$pos);
        }
        return $strcut.$dot;
    }
    function to_qmhn_reg($fromuid,$touid,$money,$type){
        global $_G;

        if($fromuid && $touid) {

            $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
            $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
            $language_zimu = include $includefile;

            $isadd = Db::name('zimu_xiangqin_qmhn_log')->where('uid', $fromuid)->where('touid', $touid)->where('type', $type)->find();

            if (!$isadd['id']) {

                $qmhn_log = ['uid' => $fromuid, 'touid' => $touid, 'money' => $money * 100, 'type' => $type, 'addtime' => time()];
                Db::name('zimu_xiangqin_qmhn_log')->insert($qmhn_log);
                Db::name('zimu_xiangqin_qmhn_user')->where('uid', $fromuid)->inc('can_cash', $money * 100)->inc('cash', $money * 100)->update();

                $first = $language_zimu['config_php_92'];
                $keyword1 = $language_zimu['config_php_93'];
                $keyword2 = $language_zimu['config_php_94'];
                $keyword3 = $language_zimu['config_php_95'];
                $remark = $language_zimu['config_php_96'] . $money . $language_zimu['config_php_97'];
                $tourl = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5/pages/qmhn/index?mobile=2';
                $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);

                notification_all($fromuid, $first, $keyword1, $keyword2, $keyword3, $remark, $link);

            }

        }
    }

    function to_qmhn_vip($fromuid,$touid,$money,$type){
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $qmhn_log = ['uid' => $fromuid,'touid' => $touid,'money' => $money,'type' => $type,'addtime' => time()];
        Db::name('zimu_xiangqin_qmhn_log')->insert($qmhn_log);
        Db::name('zimu_xiangqin_qmhn_user')->where('uid', $fromuid)->inc('can_cash',$money)->inc('cash',$money)->update();

        $first = $language_zimu['config_php_98'];
        $keyword1 = $language_zimu['config_php_99'].'VIP'.$language_zimu['config_php_100'];
        $keyword2 = $language_zimu['config_php_101'];
        $keyword3 = $language_zimu['config_php_102'].'VIP'.$language_zimu['config_php_103'];
        $remark = $language_zimu['config_php_104'].($money/100).$language_zimu['config_php_105'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/qmhn/index?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);

        notification_all($fromuid,$first,$keyword1,$keyword2,$keyword3,$remark,$link);

    }

    function to_qmhn_line($fromuid,$touid,$money,$type){
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $qmhn_log = ['uid' => $fromuid,'touid' => $touid,'money' => $money,'type' => $type,'addtime' => time()];
        Db::name('zimu_xiangqin_qmhn_log')->insert($qmhn_log);
        Db::name('zimu_xiangqin_qmhn_user')->where('uid', $fromuid)->inc('can_cash',$money)->inc('cash',$money)->update();

        $first = $language_zimu['config_php_106'];
        $keyword1 = $language_zimu['config_php_107'];
        $keyword2 = $language_zimu['config_php_108'];
        $keyword3 = $language_zimu['config_php_109'];
        $remark = $language_zimu['config_php_110'].($money/100).$language_zimu['config_php_111'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/qmhn/index?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);

        notification_all($fromuid,$first,$keyword1,$keyword2,$keyword3,$remark,$link);

    }

    function to_qmhn_top($fromuid,$touid,$money,$type){
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $qmhn_log = ['uid' => $fromuid,'touid' => $touid,'money' => $money,'type' => $type,'addtime' => time()];
        Db::name('zimu_xiangqin_qmhn_log')->insert($qmhn_log);
        Db::name('zimu_xiangqin_qmhn_user')->where('uid', $fromuid)->inc('can_cash',$money)->inc('cash',$money)->update();

        $first = $language_zimu['config_php_112'];
        $keyword1 = $language_zimu['config_php_113'];
        $keyword2 = $language_zimu['config_php_114'];
        $keyword3 = $language_zimu['config_php_115'];
        $remark = $language_zimu['config_php_116'].($money/100).$language_zimu['config_php_117'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/qmhn/index?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);

        notification_all($fromuid,$first,$keyword1,$keyword2,$keyword3,$remark,$link);

    }

    function notification_all($uid,$first,$keyword1,$keyword2,$keyword3,$remark,$link){

        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
        $paramters = unserialize($paramter['parameter']);

        $templatedata = array(
            'first' => array(
                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                'color' => "#FF4040"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($keyword2, CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => date('Y-m-d H:i', $_G['timestamp'])
            ),
            'remark' => array(
                'value' => urlencode(diconv($remark, CHARSET, 'utf-8')),
                'color' => "#008000"
            )
        );
        notification_user($uid, $paramters['wxtpl_admin'], $templatedata,$link);

        $magcon = '{"tag":"'.$keyword1.'","title":"'.$first.'","title_themecolor":"#ff0000","link":"'.$link.'","extra_info":[{"key":"'.$language_zimu['config_php_118'].'","val":"'.$keyword3.'"}],"des":"'.$remark.'","des_themecolor":"#008000"}';

        notification_user_magapp($uid, $magcon);

        $qfcon['msg'] = $first;
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title'=>diconv($keyword1, CHARSET, 'utf-8'),
            'date'=>date('Y-m-d H:i:s'),
            'setting'=>array(),
            'content' => diconv($keyword3,CHARSET,'UTF-8'),
            'url'=>$link
        );
        notification_user_qfapp($uid, $qfcon);

    }
    function find_hnuid(){
        global $_G;
        $lastuser = Db::name('zimu_xiangqin_users')->where('hn_uid','>',0)->order(['id'=>'desc'])->find();
        if($lastuser){
            $old_hnuser = Db::name('zimu_xiangqin_kefu')->where('uid','=',$lastuser['hn_uid'])->order(['id'=>'asc'])->find();
            $hnuser = Db::name('zimu_xiangqin_kefu')->where('kefu_power','=',1)->where('id','>',$old_hnuser['id'])->order(['id'=>'asc'])->find();
        }
        if(!$hnuser){
            $hnuser = Db::name('zimu_xiangqin_kefu')->where('kefu_power','=',1)->order(['id'=>'asc'])->find();
        }
        return $hnuser;
    }
    function notification_setmeal($note,$vipuid,$wxtpl_admin){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
        $language_zimu = include $includefile;
        if($note){
            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($language_zimu['config_php_119'], CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($note, CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv('UID'.$vipuid, CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($language_zimu['config_php_120'], CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i',$_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($state_note)), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
            );
            $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$vipuid.'&mobile=2';
            $link = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&tourl='.urlencode($tourl);
            notification_user('superadmin', $wxtpl_admin, $templatedata, $link);
        }
    }
    function xcx_select_uid($xcx_zimu_data){
        if($xcx_zimu_data['unionid']){
            $isuid = Db::name('zimu_xiangqin_token')->where('unionid',$xcx_zimu_data['unionid'])->find();
            if(!$isuid['xcx_openid'] && $xcx_zimu_data['openid']){
                Db::name('zimu_xiangqin_token')->where('uid', $isuid['uid'])->data(['xcx_openid' => $xcx_zimu_data['openid']])->update();
                $isuid['xcx_openid'] = $xcx_zimu_data['openid'];
            }
        }else{
            $isuid = Db::name('zimu_xiangqin_token')->where('xcx_openid',$xcx_zimu_data['openid'])->find();
        }
        return $isuid;
    }
    function xcx_reg_user($xcx_zimu_data,$zmdata) {

        $regname = getnewname($xcx_zimu_data['username']);
        $uid = register($regname, 1, 0, $xcx_zimu_data['gender']);
        if ($uid) {
            syncAvatar($uid, $xcx_zimu_data['avatar']);
            if ($zmdata['settings']['xcx_isapp'] == 2 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'uid' => $uid,
                    'nickname' => $regname,
                    'dateline' => $_G['timestamp'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'weibotype' => 'wechat',
                );
                Db::name('thirdbind')->insert($appdata);
            }
            if ($zmdata['settings']['xcx_isapp'] == 1 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'userid' => $uid,
                    'name' => $regname,
                    'create_time' => $_G['timestamp'],
                    'unionid' => $xcx_zimu_data['unionid'],
                );
                Db::name('user_weixin_relations')->insert($appdata);
            }
            if ($zmdata['settings']['xcx_isapp'] == 3 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'uid' => $uid,
                    'username' => $regname,
                    'openid' => '',
                    'status' => '2',
                    'type' => '1',
                    'param' => $xcx_zimu_data['unionid'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'wx_nickname' => $xcx_zimu_data['username'],
                    'wx_sex' => $xcx_zimu_data['gender'],
                    'wx_headimgurl' => $xcx_zimu_data['avatar']
                );
                Db::name('appbyme_connection')->insert($appdata);
            }
            return $uid;
        }
    }
    function getnewname($username)
    {
        global $_G;
        include_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/filter_biaoqing.php';
        $username = zm_login_clear($username);
        $username = zm_diconv($username);
        $newname = cutstr($username, 12, '');

        if ($newname) {
            $censorexp = '/^(' . str_replace(array(
                    '\\*',
                    "\r\n",
                    ' '
                ), array(
                    '.*',
                    '|',
                    ''
                ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
            $newname   = preg_replace($censorexp, '', $newname);

            $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
            $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
        }

        if (dstrlen($newname) >= 3) {
            loaducenter();
            if (uc_get_user($newname)) {
                $nums = 1;
                $oldname = $newname;
                do {
                    $newname = $oldname.$nums;
                    $nums++;
                } while (uc_get_user($newname));
                $newname = cutstr($newname, 14, '');
            }
        } else if ($newname) {
            $newname = $newname . '_' . random(5);
        } else {
            $newname = 'wx_' . random(5);
        }

        return $newname;
    }
    function register($username, $inapi = 0, $groupid = 0, $sex = 0)
    {
        global $_G;

        require_once libfile('function/member');

        if (!$username) {
            showmessage('undefined_action');
        }

        loaducenter();
        $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;

        $password = md5(random(10));
        $email    = 'xcx_' . strtolower(random(10)) . '@null.null';

        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
        if ($uid <= 0) {
            if (!IN_WECHATAPI) {
                if ($uid == -1) {
                    showmessage('profile_username_illegal');
                } elseif ($uid == -2) {
                    showmessage('profile_username_protect');
                } elseif ($uid == -3) {
                    showmessage('profile_username_duplicate');
                } elseif ($uid == -4) {
                    showmessage('profile_email_illegal');
                } elseif ($uid == -5) {
                    showmessage('profile_email_domain_illegal');
                } elseif ($uid == -6) {
                    showmessage('profile_email_duplicate');
                } else {
                    showmessage('undefined_action');
                }
            } else {
                if ($uid == -1) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
                } elseif ($uid == -2) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
                } elseif ($uid == -3) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
                } elseif ($uid == -4) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
                } elseif ($uid == -5) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
                } elseif ($uid == -6) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
                } else {
                    echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
                }
                exit;
            }
        }

        $init_arr = array(
            'credits' => explode(',', $_G['setting']['initcredits']),
            'profile' => array(
                'gender' => $sex
            )
        );
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        if ($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
            if ($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array(
                    'ip' => $_G['clientip'],
                    'count' => -1,
                    'dateline' => $_G['timestamp']
                ));
            }
        }

        if ($_G['setting']['regverify'] == 2) {
            C::t('common_member_validate')->insert(array(
                'uid' => $uid,
                'submitdate' => $_G['timestamp'],
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => ''
            ), false, true);
            manage_addnotify('verifyuser');
        }

        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid
        ), 0);


        include_once libfile('function/stat');
        updatestat('register');

        return $uid;
    }


    function syncAvatar($uid, $avatar)
    {

        if (!$uid || !$avatar) {
            return false;
        }

        if (!$content = dfsockopen($avatar)) {
            return false;
        }

        $tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
        file_put_contents($tmpFile, $content);

        if (!is_file($tmpFile)) {
            return false;
        }
        $result = uploadUcAvatar($uid, $tmpFile);
        unlink($tmpFile);

        C::t('common_member')->update($uid, array(
            'avatarstatus' => '1'
        ));
        return $result;
    }

    function uploadUcAvatar($uid, $localFile)
    {

        global $_G;
        if (!$uid || !$localFile) {
            return false;
        }

        list($width, $height, $type, $attr) = getimagesize($localFile);
        if (!$width) {
            return false;
        }
        if ($width < 10 || $height < 10 || $type == 4) {
            return false;
        }

        $imageType = array(
            1 => '.gif',
            2 => '.jpg',
            3 => '.png'
        );
        $fileType  = $imgType[$type];
        if (!$fileType) {
            $fileType = '.jpg';
        }
        $avatarPath = $_G['setting']['attachdir'];
        $tmpAvatar  = $avatarPath . './temp/upload' . $uid . $fileType;
        file_exists($tmpAvatar) && @unlink($tmpAvatar);
        file_put_contents($tmpAvatar, file_get_contents($localFile));

        if (!is_file($tmpAvatar)) {
            return false;
        }

        $tmpAvatarBig    = './temp/upload' . $uid . 'big' . $fileType;
        $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
        $tmpAvatarSmall  = './temp/upload' . $uid . 'small' . $fileType;

        $image = new image;
        if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
            return false;
        }
        if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
            return false;
        }
        if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
            return false;
        }

        $tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
        $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
        $tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
        $avatar1         = byte2hex(file_get_contents($tmpAvatarBig));
        $avatar2         = byte2hex(file_get_contents($tmpAvatarMiddle));
        $avatar3         = byte2hex(file_get_contents($tmpAvatarSmall));

        $extra  = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
        $result = uc_api_post_ex('user', 'rectavatar', array(
            'uid' => $uid
        ), $extra);

        @unlink($tmpAvatar);
        @unlink($tmpAvatarBig);
        @unlink($tmpAvatarMiddle);
        @unlink($tmpAvatarSmall);
        return true;
    }

    function byte2hex($string)
    {
        $buffer = '';
        $value  = unpack('H*', $string);
        $value  = str_split($value[1], 2);
        $b      = '';
        foreach ($value as $k => $v) {
            $b .= strtoupper($v);
        }

        return $b;
    }

    function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
    {
        $s = $sep = '';
        foreach ($arg as $k => $v) {
            $k = urlencode($k);
            if (is_array($v)) {
                $s2 = $sep2 = '';
                foreach ($v as $k2 => $v2) {
                    $k2 = urlencode($k2);
                    $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                    $sep2 = '&';
                }
                $s .= $sep . $s2;
            } else {
                $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
            }
            $sep = '&';
        }
        $postdata = uc_api_requestdata($module, $action, $s, $extra);
        return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
    }