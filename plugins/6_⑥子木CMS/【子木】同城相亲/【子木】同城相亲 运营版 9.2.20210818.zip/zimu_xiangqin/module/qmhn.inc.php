<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);

    if($op == 'help' ) {

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
        $paramters = unserialize($paramter['parameter']);
        zimu_json($paramters);

    }elseif($op == 'sign' ){

        $zimu['zmdata'] = $zmdata2;
        $zimu['qmhn'] = Db::name('zimu_xiangqin_qmhn_user')->where('uid',$myuid['uid'])->find();
        zimu_json($zimu);

    }elseif($op == 'tosign' ) {

        $paramter_qmhn = Db::name('zimu_xiangqin_parameter2')->where('name', 'qmhn')->find();
        $paramters_qmhn = unserialize($paramter_qmhn['parameter']);

        $users_data['mobile'] = strip_tags($_GET['mymobile']);
        $mycode = strip_tags($_GET['mycode']);

        $isreal = Db::name('zimu_xiangqin_smslog')->where([['uid', '=', $myuid['uid']], ['mobile', '=', $users_data['mobile']], ['code', '=', $mycode]])->order('id', 'desc')->find();

        if (!$isreal) {
            zimu_json('', $language_zimu['qmhn_inc_php_0'], 1);
        }
        $users_data['uid'] = $myuid['uid'];
        $users_data['username'] = addslashes(strip_tags($zimu_get['myname']));
        $users_data['weixin'] = addslashes(strip_tags($zimu_get['myweixin']));
        if ($paramters_qmhn['audit'] != 1) {
            $users_data['status'] = 1;
        }
        $users_data['addtime'] = $_G['timestamp'];

        $ids = Db::name('zimu_xiangqin_qmhn_user')->insertGetId($users_data);

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
        $paramters = unserialize($paramter['parameter']);

        $first = $language_zimu['qmhn_inc_php_1'];
        $keyword1 = $language_zimu['qmhn_inc_php_2'];
        $keyword2 = $language_zimu['qmhn_inc_php_3'];
        $keyword3 = $language_zimu['qmhn_inc_php_4'];
        $remark = $users_data['username'] . $users_data['mobile'];

        $templatedata = array(
            'first' => array(
                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                'color' => "#FF4040"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($keyword2, CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => date('Y-m-d H:i', $_G['timestamp'])
            ),
            'remark' => array(
                'value' => urlencode(diconv($remark, CHARSET, 'utf-8')),
                'color' => "#008000"
            )
        );
        notification_user('admin', $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL2);

        $magcon = '{"tag":"' . $keyword1 . '","title":"' . $first . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL2 . '","extra_info":[{"key":"' . $language_zimu['qmhn_inc_php_5'] . '","val":"' . $keyword3 . '"}],"des":"' . $remark . '","des_themecolor":"#008000"}';

        notification_user_magapp('admin', $magcon);

        $qfcon['msg'] = $first;
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title' => diconv($keyword1, CHARSET, 'utf-8'),
            'date' => date('Y-m-d H:i:s'),
            'setting' => array(),
            'content' => diconv($keyword3, CHARSET, 'UTF-8'),
            'url' => ZIMUCMS_URL2
        );
        notification_user_qfapp('admin', $qfcon);

        zimu_json();

    }elseif($op == 'list' ){

        $type = intval($_GET['type']);
        if($type==1){
            $zimu['list'] = Db::name('zimu_xiangqin_users')->where([['state','=',1],['status','<>',3]])->where('isqmhn','>', 0)->order(['isqmhn'=>'asc','refreshtime'=>'desc','addtime'=>'desc'])->select()->toArray();
        }else{
            $zimu['list'] = Db::name('zimu_xiangqin_users')->where([['status','<>',3]])->where('qmhn_uid','=', $myuid['uid'])->order(['isqmhn'=>'asc','refreshtime'=>'desc','addtime'=>'desc'])->select()->toArray();
        }

        zimu_json($zimu);

    }elseif($op == 'money' ){

        $zimu['list'] = Db::name('zimu_xiangqin_qmhn_log')->where('uid',$myuid['uid'])->order(['addtime'=>'desc'])->select()->toArray();

        zimu_json($zimu);

    }elseif($op == 'myhaibao' ){

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
        $paramters = unserialize($paramter['parameter']);

        $paramters['myhaibao_url'] = str_replace($_G['siteurl'],'',$paramters['myhaibao_url']);

        if($paramters['myhaibao_url'] && $paramters['myhaibao_xy']){

            $qrsize = 5;
            $dir = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/';
            $qrcode_file = $dir.'qrcode/index_qmhn_haibao_'.$myuid['uid'].'.jpg';
            $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/?mobile=2';

            $qrcode_url = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&qmhn=1&fromid='.$myuid['uid'].'&tourl='.urlencode($share_url);

            if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time()-86400 ) {
                require_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/class/qrcode.class.php';
                QRcode::png($qrcode_url, $qrcode_file, QR_ECLEVEL_L, $qrsize);
            }

            $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/qrcode/index_qmhn_haibao_'.$myuid['uid'].'.jpg';

            $myhaibao_xy = explode(',',$paramters['myhaibao_xy']);
            if(strpos($paramters['myhaibao_url'],'http') !== false){
                $myhaibao_url = $paramters['myhaibao_url'];
            }else{
                $myhaibao_url = DISCUZ_ROOT.$paramters['myhaibao_url'];
            }

            $config = array(
                'image' => array(
                    array(
                        'url' => $myinfo['qrcode_url'],
                        'is_yuan' => false,
                        'stream' => 0,
                        'left' => $myhaibao_xy[0],
                        'top' => $myhaibao_xy[1],
                        'right' => 0,
                        'width' => 220,
                        'height' => 220,
                        'opacity' => 100
                    ),
                ),
                'background' => $myhaibao_url,
            );

            $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/haibao/index_qmhn_'.$myuid['uid'].'.png';

            if($myuid['uid'] == 1 || !file_exists($hbpath) || !filesize($hbpath) || filemtime($hbpath) < time()-86400) {
                $hbimg = createMiniWechat($config,$myuid);
            }else{
                $hbimg = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/haibao/index_qmhn_'.$myuid['uid'].'.png';
            }

            if($myuid['uid'] == 1){
                $myinfo['myhaibao'] = $hbimg.'?v='.time();
            }else{
                $myinfo['myhaibao'] = $hbimg;
            }

            zimu_json($myinfo);



        }




    }else{

        $zimu['zmdata'] = $zmdata2;
        $zimu['qmhn'] = Db::name('zimu_xiangqin_qmhn_user')->where('uid',$myuid['uid'])->find();

        $zimu['qmhn']['today'] = Db::name('zimu_xiangqin_qmhn_log')->where('uid',$myuid['uid'])->where('addtime','>',strtotime(date('Y-m-d', time())))->sum('money');

        $zimu['qmhn']['today'] = intval($zimu['qmhn']['today']);

        $zimu['cardlist'] = Db::name('zimu_xiangqin_users')->where([['state','=',1],['status','<>',3]])->where('isqmhn','>', 0)->order(['isqmhn'=>'asc','refreshtime'=>'desc','addtime'=>'desc'])->limit(5)->select()->toArray();

        zimu_json($zimu);

    }

    function createMiniWechat($config,$myinfo)
    {
        global $_G;

        $filename = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/haibao/index_qmhn_'.$myinfo['uid'].'.png';
        $rest = createPoster1($config, $filename);
        if ($rest) {
            $image = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/haibao/index_qmhn_'.$myinfo['uid'].'.png';
            return $image;
        }
        return false;
    }

    function createPoster1($config = array(), $filename = "")
    {
        if (empty($filename)) header("content-type: image/png");
        $imageDefault = array(
            'left' => 0,
            'top' => 0,
            'right' => 0,
            'bottom' => 0,
            'width' => 100,
            'height' => 100,
            'opacity' => 100
        );
        $textDefault = array(
            'text' => '',
            'left' => 0,
            'top' => 0,
            'fontSize' => 32,
            'fontColor' => '255,255,255',
            'angle' => 0,
        );
        $background = $config['background'];
        $backgroundInfo = getimagesize($background);
        $backgroundFun = 'imagecreatefrom' . image_type_to_extension($backgroundInfo[2], false);
        $background = $backgroundFun($background);
        $backgroundWidth = imagesx($background);
        $backgroundHeight = imagesy($background);
        $imageRes = imageCreatetruecolor($backgroundWidth, $backgroundHeight);
        $color = imagecolorallocate($imageRes, 0, 0, 0);
        imagefill($imageRes, 0, 0, $color);
        imagecopyresampled($imageRes, $background, 0, 0, 0, 0, imagesx($background), imagesy($background), imagesx($background), imagesy($background));
        if (!empty($config['image'])) {
            foreach ($config['image'] as $key => $val) {

                $val = array_merge($imageDefault, $val);
                $info = getimagesize($val['url']);
                $function = 'imagecreatefrom' . image_type_to_extension($info[2], false);
                if ($val['stream']) {
                    $info = getimagesizefromstring($val['url']);
                    $function = 'imagecreatefromstring';
                }
                $res = $function($val['url']);
                $resWidth = $info[0];
                $resHeight = $info[1];
                $canvas = imagecreatetruecolor($val['width'], $val['height']);
                imagefill($canvas, 0, 0, $color);
                $ext = pathinfo($val['url']);
                if (array_key_exists('extension', $ext)) {
                    if ($ext['extension'] == 'gif' || $ext['extension'] == 'png') {
                        imageColorTransparent($canvas, $color);

                    }
                }

                imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'], $resWidth, $resHeight);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']) - $val['width']:$val['left'];
                if ($val['left'] < 0) {
                    $val['left'] = ceil($backgroundWidth - $val['width']) / 2;
                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) - $val['height'] : $val['top'];
                imagecopymerge($imageRes, $canvas, $val['left'], $val['top'], $val['right'], $val['bottom'], $val['width'], $val['height'], $val['opacity']);

            }
        }
        if (!empty($config['text'])) {
            foreach ($config['text'] as $key => $val) {
                $val = array_merge($textDefault, $val);
                $val['text'] = diconv($val['text'],CHARSET,'UTF-8');
                list($R, $G, $B) = explode(',', $val['fontColor']);
                $fontColor = imagecolorallocate($imageRes, $R, $G, $B);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']):$val['left'];
                $text = autowrap($val['fontSize'], 0, $val['fontPath'], $val['text'], 600);
                if ($val['left'] < 0) {
                    $fontBox = imagettfbbox($val['fontSize'], 0, $val['fontPath'], $text);
                    $val['left'] = ceil(($backgroundWidth - $fontBox[2]) / 2);

                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) : $val['top'];
                imagettftext($imageRes, $val['fontSize'], $val['angle'], $val['left'], $val['top'], $fontColor, $val['fontPath'], $text);
            }
        }
        if (!empty($filename)) {
            $res = imagejpeg($imageRes, $filename, 90);
            imagedestroy($imageRes);
            if (!$res) return false;
            return $filename;
        } else {
            header("Content-type:image/png");
            imagejpeg($imageRes);
            imagedestroy($imageRes);
        }
    }

    function autowrap($fontsize, $angle, $fontface, $string, $width)
    {
        $content = "";
        for ($i = 0; $i < mb_strlen($string); $i++) {
            $letter[] = mb_substr($string, $i, 1);
        }

        foreach ($letter as $l) {
            $teststr = $content . " " . $l;
            $testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
            if (($testbox[2] > $width) && ($content !== "")) {
                $content .= "\n";
            }
            $content .= $l;
        }
        return $content;
    }
