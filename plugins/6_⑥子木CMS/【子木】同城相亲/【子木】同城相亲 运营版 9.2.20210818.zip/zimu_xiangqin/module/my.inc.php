<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    global $_G;
    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);

    if($op == 'update_status' ) {

        $status = intval($_GET['status']);

        Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['status' => $status]);

    }elseif($op == 'update_guesthide' ){

        $ishide = intval($_GET['ishide']);

        Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['guesthide' => $ishide]);

    }elseif($op == 'intro' ){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        $zimu['xingge'] = $xingge_array;
        $zimu['myxingge'] = $myinfo['xingge'];
        $zimu['aihao'] = $aihao_array;
        $zimu['myaihao'] = $myinfo['aihao'];
        $zimu['jieshao'] = $jieshao_array;
        $zimu['intro'] = $myinfo['intro'];
        zimu_json($zimu);

    }elseif($op == 'update_intro' ){

        $zimu_get = zimu_array_gbk($_GET);
        if($zimu_get['myxingge']){
            $intro_data['xingge'] = addslashes(strip_tags($zimu_get['myxingge']));
        }
        if($zimu_get['myaihao']){
            $intro_data['aihao'] = addslashes(strip_tags($zimu_get['myaihao']));
        }
        $intro_data['intro'] = addslashes(strip_tags($zimu_get['myjieshao']));

        $intro_data['intro'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $intro_data['intro']);

        Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update($intro_data);

        zimu_json('ok');

    }elseif($op == 'ideal' ){

        $myinfo = Db::name('zimu_xiangqin_users_ideal')->where('uid', $myuid['uid'])->find();

        zimu_json($myinfo);

    }elseif($op == 'update_ideal' ){

        $myinfo = Db::name('zimu_xiangqin_users_ideal')->where('uid', $myuid['uid'])->find();
        if($myinfo['id']){
            $ideal_data['id'] = $myinfo['id'];
        }
        $zimu_get = zimu_array_gbk($_GET);
        $ideal_data['age'] = str_replace(array($language_zimu['my_inc_php_0'],'-'),array('',','),$zimu_get['age']);
        $ideal_data['age_cn'] = $zimu_get['age'];
        $ideal_data['heights'] = str_replace(array('CM','-'),array('',','),$zimu_get['heights']);
        $ideal_data['heights_cn'] = $zimu_get['heights'];
        $ideal_data['xueli'] = addslashes(strip_tags($zimu_get['xueli']));
        $ideal_data['xueli_cn'] = $zimu_get['xueli_cn'];
        $ideal_data['yuexin'] = addslashes(strip_tags($zimu_get['yuexin']))+1;
        $ideal_data['work'] = addslashes(strip_tags($zimu_get['work']));
        $ideal_data['work_cn'] = $zimu_get['work_cn'];
        $ideal_data['ganqing'] = addslashes(strip_tags($zimu_get['ganqing']));
        $ideal_data['ganqing_cn'] = $zimu_get['ganqing_cn'];
        $ideal_data['zhufang'] = intval($_GET['zhufang'])+1;
        $ideal_data['xiyan'] = intval($_GET['xiyan'])+1;
        $ideal_data['hejiu'] = intval($_GET['hejiu'])+1;
        $ideal_data['uid'] = $myuid['uid'];

        if($myinfo['id']){
            $ideal_data['id'] = $myinfo['id'];
            Db::name('zimu_xiangqin_users_ideal')->update($ideal_data);
        }else{
            Db::name('zimu_xiangqin_users_ideal')->insert($ideal_data);
        }

        zimu_json('ok');

    }elseif($op == 'myfav' ){

        $info['favlist'] = getmorelist('zimu_xiangqin_users_fav',['uid'=>$myuid['uid']],['id'=>'desc']);
        foreach ($info['favlist'] as $key => $value) {
            $info['favlist'][$key]['addtime_cn'] = date('Y-m-d',$value['addtime']);
            $info['favlist'][$key]['info'] = getmyinfo($value['touid']);
        }
        zimu_json($info);

    }elseif($op == 'mylike' ){

        $info['favlist'] = getmorelist('zimu_xiangqin_users_fav',['touid'=>$myuid['uid']],['id'=>'desc']);
        foreach ($info['favlist'] as $key => $value) {
            $info['favlist'][$key]['addtime_cn'] = date('Y-m-d',$value['addtime']);
            $info['favlist'][$key]['info'] = getmyinfo($value['uid']);
        }
        $info['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        zimu_json($info);

    }elseif($op == 'myview' ){

        $info['viewlist'] = getmorelist('zimu_xiangqin_viewlog',['uid'=>$myuid['uid']],['addtime'=>'desc']);
        foreach ($info['viewlist'] as $key => $value) {
            $info['viewlist'][$key]['addtime_cn'] = date('Y-m-d',$value['addtime']);
            $info['viewlist'][$key]['info'] = getmyinfo($value['touid']);
        }
        zimu_json($info);

    }elseif($op == 'myviewed' ){

        $info['viewlist'] = getmorelist('zimu_xiangqin_viewlog',['touid'=>$myuid['uid']],['addtime'=>'desc']);
        foreach ($info['viewlist'] as $key => $value) {
            $info['viewlist'][$key]['addtime_cn'] = date('Y-m-d',$value['addtime']);
            $info['viewlist'][$key]['info'] = getmyinfo($value['uid']);
        }
        $info['myinfo'] = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        zimu_json($info);


    }elseif($op == 'buyline' ){

        $info['linelist'] = getmorelist('zimu_xiangqin_setmeal_increment',['cat'=>'buyline'],['id'=>'asc']);
        $info['zmdata'] = $zmdata2;

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            foreach ($info['linelist'] as $key => $value){
                $info['linelist'][$key]['price'] = number_format($value['price']*$zmdata['settings']['women_vip']/100,2)>0 ? number_format($value['price']*$zmdata['settings']['women_vip']/100,2) : 0.01;
            }
        }
        zimu_json($info);

    }elseif($op == 'tobuyline' ){

        $ids = intval($_GET['ids']);
        $setmeal = Db::name('zimu_xiangqin_setmeal_increment')->where('id', $ids)->find();

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            $setmeal['price'] = number_format($setmeal['price']*$zmdata['settings']['women_vip']/100,2)>0 ? number_format($setmeal['price']*$zmdata['settings']['women_vip']/100,2) : 0.01;
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $setmeal['price'];
        $params['pay_amount'] = $setmeal['price'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_1'];
        $params['description'] = $language_zimu['my_inc_php_2'].$setmeal['name'];
        $params['service_name'] = 'buyline';
        $params_array['line'] = $setmeal['value'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'buytop' ){

        $info['myinfo'] = getmyinfo($myuid['uid']);
        $info['myinfo']['toptime_cn'] = date('Y-m-d',$info['myinfo']['toptime']);
        $info['toplist'] = getmorelist('zimu_xiangqin_setmeal_increment',['cat'=>'buytop'],['id'=>'asc']);

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            foreach ($info['toplist'] as $key => $value){
                $info['toplist'][$key]['price'] = number_format($value['price']*$zmdata['settings']['women_vip']/100,2)>0 ? number_format($value['price']*$zmdata['settings']['women_vip']/100,2) : 0.01;
            }
        }

        zimu_json($info);

    }elseif($op == 'tobuytop' ){

        $ids = intval($_GET['ids']);
        $setmeal = Db::name('zimu_xiangqin_setmeal_increment')->where('id', $ids)->find();

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        if($myinfo['sex']==2 && $zmdata['settings']['women_vip']>0){
            $setmeal['price'] = number_format($setmeal['price']*$zmdata['settings']['women_vip']/100,2)>0 ? number_format($setmeal['price']*$zmdata['settings']['women_vip']/100,2) : 0.01;
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $setmeal['price'];
        $params['pay_amount'] = $setmeal['price'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_3'];
        $params['description'] = $language_zimu['my_inc_php_4'].$setmeal['name'];
        $params['service_name'] = 'buytop';
        $params_array['days'] = $setmeal['value'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'buypyq' ){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();

        $info['pyq_money'] = $zmdata2['settings']['pyq_money'];
        $info['pyqlist'] = getmorelist('zimu_xiangqin_pyq',['uid'=>$myuid['uid']],['id'=>'desc']);

        if($myinfo['sex']==2 && $zmdata2['settings']['pyq_money2']>0){
            $info['pyq_money'] = $zmdata2['settings']['pyq_money2'];
        }

        zimu_json($info);

    }elseif($op == 'tobuypyq' ){

        $ids = intval($_GET['ids']);

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();

        if($myinfo['sex']==2 && $zmdata['settings']['pyq_money2']>0){
            $zmdata['settings']['pyq_money'] = $zmdata['settings']['pyq_money2'];
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $zmdata['settings']['pyq_money'];
        $params['pay_amount'] = $zmdata['settings']['pyq_money'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_5'];
        $params['description'] = $language_zimu['my_inc_php_6'];
        $params['service_name'] = 'buypyq';
        $params_array['username'] = $myuid['username'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'buybaodeng' ){

        $ids = intval($_GET['ids']);
        $zimu_get = zimu_array_gbk($_GET);
        $tousername = addslashes(strip_tags($zimu_get['tousername']));
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();

        if($myinfo['sex']==2 && $zmdata['settings']['baodeng_money2']>0){
            $zmdata['settings']['baodeng_money'] = $zmdata['settings']['baodeng_money2'];
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $zmdata['settings']['baodeng_money'];
        $params['pay_amount'] = $zmdata['settings']['baodeng_money'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_7'];
        $params['description'] = $language_zimu['my_inc_php_8'].$tousername.$language_zimu['my_inc_php_9'];
        $params['service_name'] = 'buybaodeng';
        $params_array['uid'] = $myuid['uid'];
        $params_array['username'] = $myuid['username'];
        $params_array['photo'] = $myinfo['photo'];
        $params_array['touid'] = $ids;
        $params_array['tousername'] = $tousername;
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'buyoneline' ){

        $ids = intval($_GET['ids']);
        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        $tomyinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();

        if($myinfo['sex']==2 && $zmdata['settings']['line_price2']>0){
            $zmdata['settings']['line_price'] = $zmdata['settings']['line_price2'];
        }

        $applyline_data['uid'] = $myuid['uid'];
        $applyline_data['username'] = $myinfo['nickname'];
        $applyline_data['touid'] = $ids;
        $applyline_data['tousername'] = $tomyinfo['nickname'];
        $applyline_data['hn_id'] = $tomyinfo['hn_id'];
        $applyline_data['hn_name'] = $tomyinfo['hn_name'];
        $applyline_data['status'] = 0;
        $applyline_data['applytime'] = $_G['timestamp'];
        $lineid = Db::name('zimu_xiangqin_applyline')->insertGetId($applyline_data);


        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $zmdata['settings']['line_price'];
        $params['pay_amount'] = $zmdata['settings']['line_price'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_10'];
        $params['description'] = $language_zimu['my_inc_php_11'].$tomyinfo['nickname'].'(UID:'.$ids.')';
        $params['service_name'] = 'buyoneline';
        $params_array['lineid'] = $lineid;
        $params_array['uid'] = $myuid['uid'];
        $params_array['username'] = $myinfo['nickname'];
        $params_array['touid'] = $ids;
        $params_array['tousername'] = $tomyinfo['nickname'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'myinfo' ){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        $myinfo['reallog'] = Db::name('zimu_xiangqin_reallog')->where('uid', $myuid['uid'])->order('id','desc')->findOrEmpty();
        if($myinfo['reallog']['status']==1 && $myinfo['real_state'] !=1 ){
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['real_state' => 1]);
            $myinfo['real_state'] = 1;
        }

        if($myinfo['sex']==2 && $zmdata['settings']['need_pay_real2']>0){
            $zmdata2['settings']['need_pay_real'] = $zmdata2['settings']['need_pay_real2'];
        }

        $myinfo['zmdata'] = $zmdata2;
        zimu_json($myinfo);

    }elseif($op == 'payaudit' ){

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
        if($myinfo['sex']==2 && $zmdata['settings']['need_pay_audit2']>0){
            $zmdata['settings']['need_pay_audit'] = $zmdata['settings']['need_pay_audit2'];
        }

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['pay_type'] = 2;
        $params['is_paid'] = 1;
        $params['amount'] = $zmdata['settings']['need_pay_audit'];
        $params['pay_amount'] = $zmdata['settings']['need_pay_audit'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['my_inc_php_12'];
        $params['description'] = $language_zimu['my_inc_php_13'];
        $params['service_name'] = 'payaudit';
        $params['addtime'] = $_G['timestamp'];

        $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

        zimu_json($return_order_info);

    }elseif($op == 'manage_audit' ){

        $ids = intval($_GET['ids']);
        $state = intval($_GET['state']);

        $listdata = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();

        if($state!=0 && $state != $listdata['state']){

            Db::name('zimu_xiangqin_users')->where('uid', $ids)->update(['state' => $state]);

            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);

            $first = $listdata['realname'].$language_zimu['my_inc_php_14'].($state==1 ? $language_zimu['my_inc_php_15'] : $language_zimu['my_inc_php_16']);

            if($state==1){
                notification_user_sms($listdata,'chanyoo_sms_tp5');
            }
            if($state==2){
                notification_user_sms($listdata,'chanyoo_sms_tp6');
            }

            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($language_zimu['my_inc_php_17'], CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv($listdata['realname'], CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($language_zimu['my_inc_php_18'].($state==1 ? $language_zimu['my_inc_php_19'] : $language_zimu['my_inc_php_20']), CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i',$_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($state_note)), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
            );

            notification_user($listdata['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);

            $magcon = '{"tag":"'.$language_zimu['my_inc_php_21'].'","title":"'.$listdata['realname'].$language_zimu['my_inc_php_22'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'","extra_info":[{"key":"'.$language_zimu['my_inc_php_23'].'","val":"'.($state==1 ? $language_zimu['my_inc_php_24'] : $language_zimu['my_inc_php_25']).'"}],"des":"'.$state_note.'<br>'.$language_zimu['my_inc_php_26'].'","des_themecolor":"#008000"}';

            notification_user_magapp($listdata['uid'],$magcon);

            $qfcon['msg'] = $language_zimu['my_inc_php_27'];
            $qfcon['showdata'] = '';
            $qfcon['showdata'] = array(
                'title'=>diconv($language_zimu['my_inc_php_28'], CHARSET, 'utf-8'),
                'date'=>date('Y-m-d H:i:s'),
                'setting'=>array(),
                'content' => diconv($language_zimu['my_inc_php_29'].($state==1 ? $language_zimu['my_inc_php_30'] : $language_zimu['my_inc_php_31']),CHARSET,'UTF-8'),
                'url'=>ZIMUCMS_URL
            );

            notification_user_qfapp($listdata['uid'],$qfcon);


        }


        zimu_json();

    }elseif($op == 'toreal' ){

        $zimu_get = zimu_array_gbk($_GET);
        $reallog_data['uid'] = $myuid['uid'];
        $reallog_data['realname'] = addslashes(zm_diconv($_GET['realname']));
        $reallog_data['mobile'] = $zimu_get['mobile'];
        $reallog_data['idcard'] = $zimu_get['idcard'];
        $reallog_data['addtime'] = $_G['timestamp'];

        $ispay = Db::name('zimu_xiangqin_order')->where([['uid','=',$myuid['uid']],['service_name','=','payreal'],['is_paid','=',2]])->find();
        if($zmdata['settings']['pay_real_again'] == 1 && $ispay['id']){
            $zmdata['settings']['need_pay_real'] = 0;
        }

        if($zmdata['settings']['need_pay_real']){
            $ids = Db::name('zimu_xiangqin_reallog')->insertGetId($reallog_data);
            $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->find();
            if($myinfo['sex']==2 && $zmdata['settings']['need_pay_real2']>0){
                $zmdata['settings']['need_pay_real'] = $zmdata['settings']['need_pay_real2'];
            }

            $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
            $params['uid'] = $myuid['uid'];
            $params['openid'] = $myuid['openid'];
            $params['pay_type'] = 2;
            $params['is_paid'] = 1;
            $params['amount'] = $zmdata['settings']['need_pay_real'];
            $params['pay_amount'] = $zmdata['settings']['need_pay_real'];
            $params['payment'] = 'wxpay';
            $params['payment_cn'] = $language_zimu['my_inc_php_32'];
            $params['description'] = $language_zimu['my_inc_php_33'];
            $params['service_name'] = 'payreal';
            $params_array['ids'] = $ids;
            $params_array['idcard'] = $reallog_data['idcard'];
            $params_array['realname'] = $reallog_data['realname'];
            $params['params'] = serialize($params_array);
            $params['addtime'] = $_G['timestamp'];

            $return_order_info['order_id'] = Db::name('zimu_xiangqin_order')->insertGetId($params);

            zimu_json($return_order_info);

        }else {
            $res = torealapi($zmdata['settings']['real_appcode'], $reallog_data['idcard'], $reallog_data['realname']);
            $res2 = zm_diconv($res);
            $res_array = json_decode($res, true);
            $res_array = zimu_array_gbk($res_array);
            if ($res_array['status'] == '01') {
                $reallog_data['status'] = 1;
                $reallog_data['res'] = $res2;
                Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['realname' => $reallog_data['realname'],'real_state' => 1]);
                syncreal($myuid['uid'],$res_array['birthday']);

                if($zmdata['settings']['auto_pay_audit2']==1) {
                    Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->data(['state' => 1])->update();
                }

            } else {
                $reallog_data['status'] = 0;
                $reallog_data['res'] = $res2;
                Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['real_state' => 3]);
            }
            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);
            $first = $language_zimu['my_inc_php_34'] . ($reallog_data['status'] == 1 ? $language_zimu['my_inc_php_35'] : $language_zimu['my_inc_php_36']);
            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($language_zimu['my_inc_php_37'], CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv($reallog_data['realname'], CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($language_zimu['my_inc_php_38'] . ($reallog_data['status'] == 1 ? $language_zimu['my_inc_php_39'] : $language_zimu['my_inc_php_40']), CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i', $_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($res_array['msg'])), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
            );
            notification_user($reallog_data['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);
            $magcon = '{"tag":"' . $language_zimu['my_inc_php_41'] . '","title":"' . $reallog_data['realname'] . $language_zimu['my_inc_php_42'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '","extra_info":[{"key":"' . $language_zimu['my_inc_php_43'] . '","val":"' . ($reallog_data['status'] == 1 ? $language_zimu['my_inc_php_44'] : $language_zimu['my_inc_php_45']) . '"}],"des":"' . $res_array['msg'] . '<br>' . $language_zimu['my_inc_php_46'] . '","des_themecolor":"#008000"}';
            notification_user_magapp($reallog_data['uid'], $magcon);
            $qfcon['msg'] = $language_zimu['my_inc_php_47'];
            $qfcon['showdata'] = '';
            $qfcon['showdata'] = array(
                'title' => diconv($language_zimu['my_inc_php_48'], CHARSET, 'utf-8'),
                'date' => date('Y-m-d H:i:s'),
                'setting' => array(),
                'content' => diconv($language_zimu['my_inc_php_49'] . ($reallog_data['status'] == 1 ? $language_zimu['my_inc_php_50'] : $language_zimu['my_inc_php_51']) . $language_zimu['my_inc_php_52'] . $res_array['msg'], CHARSET, 'UTF-8'),
                'url' => ZIMUCMS_URL
            );
            notification_user_qfapp($reallog_data['uid'], $qfcon);
            Db::name('zimu_xiangqin_reallog')->insert($reallog_data);
            zimu_json($reallog_data);
        }

    }elseif($op == 'userapplyline' ){

        $ids = intval($_GET['ids']);
        $status = intval($_GET['status']);

        Db::name('zimu_xiangqin_applyline')->where('id', $ids)->update(['status' => $status,'endtime' => time()]);

        $applyline = Db::name('zimu_xiangqin_applyline')->where('id', $ids)->find();

        $smsinfo = Db::name('zimu_xiangqin_users')->where('uid', $applyline['uid'])->find();

        if($status==3){

            notification_user_sms($smsinfo,'chanyoo_sms_tp2');

            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);
            $first = $language_zimu['my_inc_php_53'];
            $keyword1 = $language_zimu['my_inc_php_54'];
            $keyword2 = $applyline['username'];
            $keyword3 = $applyline['tousername'].$language_zimu['my_inc_php_55'];
            $remark = $language_zimu['my_inc_php_56'];
            $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$applyline['touid'].'&mobile=2';
            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv($keyword2, CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i',$_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv($remark, CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
            );
            notification_user($applyline['uid'], $paramters['wxtpl_admin'], $templatedata, $tourl);
            $magcon = '{"tag":"'.$first.'","title":"'.$keyword3.'","title_themecolor":"#ff0000","link":"'.$tourl.'","extra_info":[{"key":"'.$language_zimu['my_inc_php_57'].'","val":"'.$language_zimu['my_inc_php_58'].'"}],"des":"'.$remark.'","des_themecolor":"#008000"}';
            notification_user_magapp($applyline['uid'],$magcon);
            $qfcon['msg'] = $first;
            $qfcon['showdata'] = '';
            $qfcon['showdata'] = array(
                'title'=>diconv($keyword1, CHARSET, 'utf-8'),
                'date'=>date('Y-m-d H:i:s'),
                'setting'=>array(),
                'content' => diconv($keyword3.$language_zimu['my_inc_php_59'].$remark,CHARSET,'UTF-8'),
                'url'=>$tourl
            );
            notification_user_qfapp($applyline['uid'],$qfcon);

        }

        if($status==4){

            if(!$zmdata['settings']['line_back']){
                if($smsinfo['vip_type'] > 0 && $smsinfo['vip_etime'] > time() ){
                    Db::name('zimu_xiangqin_users')->where('uid', $applyline['uid'])->inc('line_num')->update();
                    $crm_feedback['uid']     = $applyline['uid'];
                    $crm_feedback['note']       = $language_zimu['my_inc_php_60'];
                    $crm_feedback['addtime']     = time();
                    Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
                }else{
                    Db::name('zimu_xiangqin_users')->where('uid', $applyline['uid'])->inc('line_num2')->update();
                    $crm_feedback['uid']     = $applyline['uid'];
                    $crm_feedback['note']       = $language_zimu['my_inc_php_61'];
                    $crm_feedback['addtime']     = time();
                    Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
                }
            }

            notification_user_sms($smsinfo,'chanyoo_sms_tp3');

            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);
            $first = $language_zimu['my_inc_php_62'];
            $keyword1 = $language_zimu['my_inc_php_63'];
            $keyword2 = $applyline['username'];
            $keyword3 = $applyline['tousername'].$language_zimu['my_inc_php_64'];
            $remark = $language_zimu['my_inc_php_65'];
            $tourl = ZIMUCMS_URL;
            $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv($keyword1, CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv($keyword2, CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv($keyword3, CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => date('Y-m-d H:i',$_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv($remark, CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
            );
            notification_user($applyline['uid'], $paramters['wxtpl_admin'], $templatedata, $tourl);
            $magcon = '{"tag":"'.$first.'","title":"'.$keyword3.'","title_themecolor":"#ff0000","link":"'.$tourl.'","extra_info":[{"key":"'.$language_zimu['my_inc_php_66'].'","val":"'.$language_zimu['my_inc_php_67'].'"}],"des":"'.$remark.'","des_themecolor":"#008000"}';
            notification_user_magapp($applyline['uid'],$magcon);
            $qfcon['msg'] = $first;
            $qfcon['showdata'] = '';
            $qfcon['showdata'] = array(
                'title'=>diconv($keyword1, CHARSET, 'utf-8'),
                'date'=>date('Y-m-d H:i:s'),
                'setting'=>array(),
                'content' => diconv($keyword3.$language_zimu['my_inc_php_68'].$remark,CHARSET,'UTF-8'),
                'url'=>ZIMUCMS_URL
            );
            notification_user_qfapp($applyline['uid'],$qfcon);

        }

        $first = $language_zimu['my_inc_php_69'];
        $keyword1 = $language_zimu['my_inc_php_70'];
        $keyword2 = $language_zimu['my_inc_php_71'];
        $keyword3 = $language_zimu['my_inc_php_72'];
        if($status==3){
            $remark = $applyline['tousername'].$language_zimu['my_inc_php_73'].$applyline['username'].$language_zimu['my_inc_php_74'];
        }
        if($status==4){
            $remark = $applyline['tousername'].$language_zimu['my_inc_php_75'].$applyline['username'].$language_zimu['my_inc_php_76'];
        }
        $tourl = ZIMUCMS_URL2.'pages/index/details?ids='.$applyline['touid'].'&mobile=2';
        $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);
        notification_all('admin', $first, $keyword1, $keyword2, $keyword3, $remark, $link);

        zimu_json();

    }elseif($op == 'diy_mycity' ){

        if($zmdata['settings']['diy_mycity']){
            $citys = json_decode(zimu_array_utf8($zmdata['settings']['diy_mycity']),true);
            $myinfo['citys'] = zimu_array_gbk2($citys);
        }
        zimu_json($myinfo);

    }else{

        $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();

        if(strlen($myuid['openid']) < 10 || strlen($myuid['openid']) > 50){
            $myuid['openid'] = '';
            Db::name('zimu_xiangqin_token')->where('uid', $myuid['uid'])->data(['openid' => ''])->update();
        }

        if ($myinfo['vip_type'] > 0 && $myinfo['vip_etime'] < time() ) {
            $myinfo['vip_type'] = 0;
            $vip_data['vip_type'] = 0;
            $crm_feedback['uid']     = $myinfo['uid'];
            $crm_feedback['note']       = $language_zimu['my_inc_php_77'].$myinfo['vip_name'].$language_zimu['my_inc_php_78'].date('Y-m-d H:i',$myinfo['vip_etime']).$language_zimu['my_inc_php_79'].$myinfo['line_num'].$language_zimu['my_inc_php_80'];
            $crm_feedback['addtime']     = time();
            Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
            $vip_data['line_num'] = 0;
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update($vip_data);
            $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->findOrEmpty();
        }

        $myinfo['line_num'] = $myinfo['line_num'] + $myinfo['line_num2'];
        if(!$myinfo['city']){
            $myinfo['city'] = $zmdata['settings']['city_value'];
        }
        if(!$myinfo['city2']){
            $myinfo['city2'] = $zmdata['settings']['city_value'];
        }
        $myinfo['myinfo'] = $myinfo;

        if($myinfo['myinfo']['id']){
            Db::name('zimu_xiangqin_users')->where('uid', $myuid['uid'])->update(['refreshtime' => time()]);
        }

        $myinfo['vip_etime_cn'] = $myinfo['vip_etime']>0 ? date('Y-m-d',$myinfo['vip_etime']) : '0';

        $myinfo['linecount'] = Db::name('zimu_xiangqin_applyline')->where('uid', $myuid['uid'])->count();

        $myinfo['likenum'] = Db::name('zimu_xiangqin_users_fav')->where('uid', $myuid['uid'])->count();
        $myinfo['likednum'] = Db::name('zimu_xiangqin_users_fav')->where('touid', $myuid['uid'])->count();

        $myinfo['viewnum'] = Db::name('zimu_xiangqin_viewlog')->where('uid', $myuid['uid'])->count();
        $myinfo['viewednum'] = Db::name('zimu_xiangqin_viewlog')->where('touid', $myuid['uid'])->count();

        $myinfo['xueli_cn'] = $xueli_array[$myinfo['xueli']-1];

        $myinfo['work_cn'] = $work_array[$myinfo['work']-1];

        $myinfo['album_count'] = Db::name('zimu_xiangqin_users_album')->where('uid', $myuid['uid'])->select()->count();

        $myinfo['ideal'] = Db::name('zimu_xiangqin_users_ideal')->where('uid', $myuid['uid'])->findOrEmpty();

        $myinfo['zmdata'] = $zmdata2;

        if($myinfo['myinfo']['sex']==2 && $myinfo['zmdata']['settings']['pyq_money2']>0){
            $myinfo['zmdata']['settings']['pyq_money'] = $myinfo['zmdata']['settings']['pyq_money2'];
        }

        $mag_paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $myinfo['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        $myinfo['linetip'] = Db::name('zimu_xiangqin_applyline')->where([['touid','=',$myuid['uid']],['status','>',0],['status','<',3]])->order('id','asc')->find();

        $myinfo['audit_info'] = Db::name('zimu_xiangqin_users2')->where('uid', $myuid['uid'])->find();

        $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
        $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
        if($qmhn_paramters['open']==1){
            $myinfo['qmhn'] = 1;
            $myinfo['myqmhn'] = Db::name('zimu_xiangqin_qmhn_user')->where('uid',$myuid['uid'])->findOrEmpty();
        }

        if ($myinfo['hn_uid']) {
            $hn_data = Db::name('zimu_xiangqin_kefu')->where('uid', $myinfo['hn_uid'])->find();
            $myinfo['zmdata']['settings']['hn_name'] = $hn_data['kefu_name'];
            $myinfo['zmdata']['settings']['hn_weixin'] = $hn_data['kefu_wxid'];
        }

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_xiangqin/module/addon_hongniang.inc.php')){
            $myinfo['isadmin'] = Db::name('zimu_xiangqin_kefu')->where('uid', $myuid['uid'])->find();
        }

        if($zmdata['settings']['diy_mycity']){
            $citys = json_decode(zimu_array_utf8($zmdata['settings']['diy_mycity']),true);
            $myinfo['citys'] = zimu_array_gbk2($citys);
        }

        zimu_json($myinfo);

    }



