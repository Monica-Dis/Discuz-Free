<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

    loadcache('plugin');
    $setting = C::t('common_setting')->fetch_all(array('zimu_xiangqin_wechatmenu'));
    $setting = (array)unserialize($setting['zimu_xiangqin_wechatmenu']);

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';

    $zmdata = $_G['cache']['plugin']['zimu_xiangqin'];

    $setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_xiangqin_setting'
    ));
    $zmdata['settings'] = unserialize($setdata['settings']);

    $langfile = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/language.' . currentlang() . '.php';
    $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_xiangqin');
    $language_zimu = include $includefile;


if(!$zmdata['settings']['weixin_appid'] || !$zmdata['settings']['weixin_appsecret']) {
	cpmsg($language_zimu['wechat_menu_setting_inc_php_0'], '', 'error');
}

if(!submitcheck('menusubmit') && !submitcheck('pubsubmit')) {

	$wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);

	showtips('<li>'.$language_zimu['wechat_menu_setting_inc_php_1'].'</li><li>'.$language_zimu['wechat_menu_setting_inc_php_2'].'</li><li>'.$language_zimu['wechat_menu_setting_inc_php_3'].'24'.$language_zimu['wechat_menu_setting_inc_php_4'].'</li>');

	showformheader(ltrim(rawurldecode(cpurl()),'action='));
	showtableheader();
	echo '<tr class="header"><th class="td25"></th><th>'.$language_zimu['wechat_menu_setting_inc_php_5'].'</th><th style="width:350px">'.$language_zimu['wechat_menu_setting_inc_php_6'].'</th><th>'.$language_zimu['wechat_menu_setting_inc_php_7'].'</th><th>'.$language_zimu['wechat_menu_setting_inc_php_8'].'appid</th><th>'.$language_zimu['wechat_menu_setting_inc_php_9'].'</th></tr>';

	foreach($setting['button'] as $k => $button) {
		$disabled = !empty($button['sub_button']) ? 'disabled' : '';
		showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][delete]\" value=\"yes\" $disabled>",
			"<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][displayorder]\" value=\"$button[displayorder]\">",
			"<div class=\"parentnode\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][name]\" value=\"".dhtmlspecialchars($button['name'])."\"></div>",
			"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][keyurl]\" value=\"".dhtmlspecialchars($button['keyurl'])."\">",
			"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][appid]\" value=\"".dhtmlspecialchars($button['appid'])."\">",
			"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][pagepath]\" value=\"".dhtmlspecialchars($button['pagepath'])."\">"
		));
		if(!empty($button['sub_button'])) {
			foreach($button['sub_button'] as $sk => $sub_button) {
				showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
					"<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][sub_button][$sk][delete]\" value=\"yes\">",
					"<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][sub_button][$sk][displayorder]\" value=\"$sub_button[displayorder]\">",
					"<div class=\"node\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][sub_button][$sk][name]\" value=\"".dhtmlspecialchars($sub_button['name'])."\"></div>",
					"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][sub_button][$sk][keyurl]\" value=\"".dhtmlspecialchars($sub_button['keyurl'])."\">",
					"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][sub_button][$sk][appid]\" value=\"".dhtmlspecialchars($sub_button['appid'])."\">",
					"<input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][sub_button][$sk][pagepath]\" value=\"".dhtmlspecialchars($sub_button['pagepath'])."\">",
				));
			}
		}
		echo '<tr><td></td><td></td><td colspan="2"><div class="lastnode"><a href="###" onclick="addrow(this, 1, '.$k.')" class="addtr">'.$language_zimu['wechat_menu_setting_inc_php_10'].'</a></div></td></tr>';
	}
	echo '<tr><td></td><td class="td23 td28"></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.$language_zimu['wechat_menu_setting_inc_php_11'].'</a></div></td></tr>';

	echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1,''], [1,'<input name="newbutton[displayorder][]" value="" size="3" type="text" class="txt">', 'td23 td28'], [1, '<input name="newbutton[name][]" value="" size="30" type="text" class="txt">'], [1, '<input name="newbutton[keyurl][]" value="" size="30" type="text" class="txt">', 'td29'], [1, '<input name="newbutton[appid][]" value="" size="30" type="text" class="txt">', 'td29'], [1, '<input name="newbutton[pagepath][]" value="" size="30" type="text" class="txt">', 'td29']],
[[1,''], [1,'<input name="newsub_button[{1}][displayorder][]" value="" size="3" type="text" class="txt">', 'td23 td28'], [1, '<div class=\"node\"><input name="newsub_button[{1}][name][]" value="" size="30" type="text" class="txt"></div>'], [1, '<input name="newsub_button[{1}][keyurl][]" value="" size="30" type="text" class="txt">', 'td29'], [1, '<input name="newsub_button[{1}][appid][]" value="" size="30" type="text" class="txt">', 'td29'], [1, '<input name="newsub_button[{1}][pagepath][]" value="" size="30" type="text" class="txt">', 'td29']],
];
</script>
EOT;

	showsubmit('menusubmit', $language_zimu['wechat_menu_setting_inc_php_12'], 'del', '<input type="submit" class="btn" name="pubsubmit" value="'.$language_zimu['wechat_menu_setting_inc_php_13'].'" />');
	showtablefooter();
	showformfooter();

} else {

	if(!empty($_GET['newbutton'])) {
		foreach($_GET['newbutton']['name'] as $k => $name) {
			$button = array(
				'displayorder' => $_GET['newbutton']['displayorder'][$k],
				'name' => $name,
				'keyurl' => $_GET['newbutton']['keyurl'][$k],
				'appid' => $_GET['newbutton']['appid'][$k],
				'pagepath' => $_GET['newbutton']['pagepath'][$k]
			);
			$setting['button'][] = $button;
		}
	}

	foreach($_GET['button'] as $k => $value) {
		if($value['sub_button']) {
			foreach($value['sub_button'] as $sk => $v) {
				if($v['delete']) {
					unset($value['sub_button'][$sk]);
				}
			}
		}
		if($value['delete']) {
			unset($setting['button'][$k]);
			continue;
		}
		$setting['button'][$k] = $value;
		if(!empty($_GET['newsub_button'][$k])) {
			foreach($_GET['newsub_button'][$k]['name'] as $sk => $name) {
				$sub_button = array(
					'displayorder' => $_GET['newsub_button'][$k]['displayorder'][$sk],
					'name' => $name,
					'keyurl' => $_GET['newsub_button'][$k]['keyurl'][$sk],
					'appid' => $_GET['newsub_button'][$k]['appid'][$sk],
					'pagepath' => $_GET['newsub_button'][$k]['pagepath'][$sk]
				);
				$setting['button'][$k]['sub_button'][] = $sub_button;
			}
		}
		if(count($setting['button'][$k]['sub_button']) > 7) {
			cpmsg($language_zimu['wechat_menu_setting_inc_php_14'].'5'.$language_zimu['wechat_menu_setting_inc_php_15'], '', 'error');
		}
		usort($setting['button'][$k]['sub_button'], 'buttoncmp');
	}

	if(count($setting['button']) > 3) {
		cpmsg($language_zimu['wechat_menu_setting_inc_php_16'].'3'.$language_zimu['wechat_menu_setting_inc_php_17'], '', 'error');
	}

	usort($setting['button'], 'buttoncmp');

	$settings = array('zimu_xiangqin_wechatmenu' => serialize($setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');

	if(submitcheck('pubsubmit')) {
		if(!$setting['button']) {
			cpmsg($language_zimu['wechat_menu_setting_inc_php_18'], '', 'error');
		}
		$pubmenu = array('button' => array());
		foreach($setting['button'] as $button) {
			if(!$button['sub_button']) {
				if(!$button['name']) {
					cpmsg($language_zimu['wechat_menu_setting_inc_php_19'], '', 'error');
				}
				if(!$button['keyurl']) {
					cpmsg($language_zimu['wechat_menu_setting_inc_php_20'].'KEY'.$language_zimu['wechat_menu_setting_inc_php_21'], '', 'error');
				}
				$parse = parse_url($button['keyurl']);
				$item = array(
					'type' => $parse['host'] ? ($button['appid'] && $button['pagepath'] ? 'miniprogram' : 'view') : 'click',
					'name' => convertname($button['name']),
					$parse['host'] ? 'url' : 'key' => $button['keyurl'],
					'appid' => $button['appid'],
					'pagepath' => $button['pagepath']
				);
				$pubmenu['button'][] = $item;
			} else {
				if(!$button['name']) {
					cpmsg($language_zimu['wechat_menu_setting_inc_php_22'], '', 'error');
				}
				$sub_buttons = array();
				foreach($button['sub_button'] as $sub_button) {
					if(!$sub_button['name']) {
						cpmsg($language_zimu['wechat_menu_setting_inc_php_23'], '', 'error');
					}
					if(!$sub_button['keyurl']) {
						cpmsg($language_zimu['wechat_menu_setting_inc_php_24'].'KEY'.$language_zimu['wechat_menu_setting_inc_php_25'], '', 'error');
					}
					$parse = parse_url($sub_button['keyurl']);
					$item = array(
						'type' => $parse['host'] ? ($sub_button['appid'] && $sub_button['pagepath'] ? 'miniprogram' : 'view') : 'click',
						'name' => convertname($sub_button['name']),
						$parse['host'] ? 'url' : 'key' => $sub_button['keyurl'],
						'appid' => $sub_button['appid'],
						'pagepath' => $sub_button['pagepath']
					);
					$sub_buttons[] = $item;
				}
				$item = array(
					'name' => convertname($button['name']),
					'sub_button' => $sub_buttons
				);
				$pubmenu['button'][] = $item;
			}
		}

		$wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);

		if($wechat_client->setMenu($pubmenu)) {
			cpmsg($language_zimu['wechat_menu_setting_inc_php_26'], 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'], 'succeed');
		} else {
			cpmsg($language_zimu['wechat_menu_setting_inc_php_27'].$wechat_client->error(), '', 'error');
		}
	} else {
		cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'], 'succeed');
	}

}

function convertname($str) {
	return urlencode(diconv($str, CHARSET, 'UTF-8'));
}

function buttoncmp($a, $b) {
	return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}