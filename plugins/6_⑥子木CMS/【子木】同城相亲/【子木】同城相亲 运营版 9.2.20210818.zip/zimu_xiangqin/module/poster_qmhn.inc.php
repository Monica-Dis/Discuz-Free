<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $ids = intval($_GET['ids']);
    $posterid = intval($_GET['posterid']) ? intval($_GET['posterid']) : 1;
    $qmhn = intval($_GET['qmhn']);

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();
    if($myinfo['sex']==1){
        $myinfo['sex_cn'] = $language_zimu['poster_qmhn_inc_php_0'];
    }else{
        $myinfo['sex_cn'] = $language_zimu['poster_qmhn_inc_php_1'];
    }

    $qrsize = 5;
    $dir = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/';
    $qrcode_file = $dir.'qrcode/details_qmhn_'.$myuid['uid'].'_'.$ids.'.jpg';
    $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/index/details?ids='.$ids.'&mobile=2';

    $qrcode_url = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex&qmhn=1&fromid='.$myuid['uid'].'&tourl='.urlencode($share_url);

    if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time()-86400 ) {
            require_once DISCUZ_ROOT.'source/plugin/zimu_xiangqin/class/qrcode.class.php';
            QRcode::png($qrcode_url, $qrcode_file, QR_ECLEVEL_L, $qrsize);
    }

    $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/qrcode/details_qmhn_'.$myuid['uid'].'_'.$ids.'.jpg';

    $text1 = $language_zimu['poster_qmhn_inc_php_2'].$myinfo['no'];
    $text2 = $myinfo['sex_cn'].' '.$myinfo['age'].$language_zimu['poster_qmhn_inc_php_3'].' '.$ganqing_array[$myinfo['ganqing']-1].' '.$language_zimu['poster_qmhn_inc_php_4'].$shuxiang_array[$myinfo['shuxiang']] . ' ' . $xingzuo_array[$myinfo['constellation']-1];
    $text3 = $language_zimu['poster_qmhn_inc_php_5'].$myinfo['height'].'CM'.' '.$language_zimu['poster_qmhn_inc_php_6'].$myinfo['weight'].'KG'.' '.$language_zimu['poster_qmhn_inc_php_7'].$xueli_array[$myinfo['xueli']-1];
    $text4 = $work_array[$myinfo['work']-1] . ' '.$language_zimu['poster_qmhn_inc_php_8'] .$yuexin_array[$myinfo['yuexin']-1];
    $text5 = $zhufang_array[$myinfo['zhufang']-1].' '.$gouche_array[$myinfo['gouche']-1];
    $text6 = $xiyan_array[$myinfo['xiyan']-1] . ' '.$hejiu_array[$myinfo['hejiu']-1];

    $config[1] = array(
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'is_yuan' => true,
                'stream' => 0,
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 180,
                'top' => 940,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_1.jpg',
    );

    $config[2] = array(
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'is_yuan' => true,
                'stream' => 0,
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 420,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_2.jpg',
    );

    $config[3] = array(
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'is_yuan' => true,
                'stream' => 0,
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 160,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '87,120,113',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '130,120,121',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_3.jpg',
    );

    $config[4] = array(
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'is_yuan' => true,
                'stream' => 0,
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 240,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_4.jpg',
    );

    $config[5] = array(
        'image' => array(
            array(
                'url' => $myinfo['photo'],
                'is_yuan' => true,
                'stream' => 0,
                'left' => -3,
                'top' => 154,
                'right' => 0,
                'width' => 220,
                'height' => 220,
                'opacity' => 100
            ),
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 290,
                'top' => 920,
                'right' => 0,
                'width' => 200,
                'height' => 200,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $text1,
                'left' => -3,
                'top' => 440,
                'fontSize' => 26,
                'fontColor' => '244,50,102',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text2,
                'left' => -3,
                'top' => 580,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text3,
                'left' => -3,
                'top' => 630,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text4,
                'left' => -3,
                'top' => 680,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text5,
                'left' => -3,
                'top' => 730,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $text6,
                'left' => -3,
                'top' => 780,
                'fontSize' => 22,
                'fontColor' => '255,89,124',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/static/wap/image/hb_bg_5.jpg',
    );

    $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/haibao/details_qmhn_'.$myinfo['uid'].'_'.$posterid.'.png';

    $hbimg = createMiniWechat($config[$posterid],$myinfo,$posterid);

    $myinfo['hbimg'] = $hbimg.'?v='.time();

    zimu_json($myinfo);


    function createMiniWechat($config,$myinfo,$posterid)
    {
        global $_G;

        $setdata = Db::name('zimu_xiangqin_setting')->order('id','desc')->find();

        $zmdata['settings'] = unserialize($setdata['settings']);

        $zmdata2 = $zmdata;

        $xueli_array = explode(',',$zmdata['settings']['xueli_type']);
        $yuexin_array = explode(',',$zmdata['settings']['yuexin_type']);
        $ganqing_array = explode(',',$zmdata['settings']['ganqing_type']);
        $work_array = explode(',',$zmdata['settings']['work_type']);
        $zhufang_array = explode(',',$zmdata['settings']['zhufang_type']);
        $gouche_array = explode(',',$zmdata['settings']['gouche_type']);
        $xingge_array = explode(',',$zmdata['settings']['xingge_type']);
        $aihao_array = explode(',',$zmdata['settings']['aihao_type']);
        $jieshao_array = explode('zimuyun',$zmdata['settings']['jieshao_type']);
        $shuxiang_array = explode(',',$zmdata['settings']['shuxiang_type']);
        $xingzuo_array = explode(',',$zmdata['settings']['xingzuo_type']);
        $xiyan_array = explode(',',$zmdata['settings']['xiyan_type']);
        $hejiu_array = explode(',',$zmdata['settings']['hejiu_type']);
        $zhufang2_array = explode(',',$zmdata['settings']['zhufang2_type']);
        $xiyan2_array = explode(',',$zmdata['settings']['xiyan2_type']);
        $hejiu2_array = explode(',',$zmdata['settings']['hejiu2_type']);

        $filename = DISCUZ_ROOT . '/source/plugin/zimu_xiangqin/uploadzimucms/haibao/details_qmhn_'.$myinfo['uid'].'_'.$posterid.'.png';
        $rest = createPoster1($config, $filename);
        if ($rest) {
            $image = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/haibao/details_qmhn_'.$myinfo['uid'].'_'.$posterid.'.png';
            return $image;
        }
        return false;
    }

    function createPoster1($config = array(), $filename = "")
    {
        if (empty($filename)) header("content-type: image/png");
        $imageDefault = array(
            'left' => 0,
            'top' => 0,
            'right' => 0,
            'bottom' => 0,
            'width' => 100,
            'height' => 100,
            'opacity' => 100
        );
        $textDefault = array(
            'text' => '',
            'left' => 0,
            'top' => 0,
            'fontSize' => 32,
            'fontColor' => '255,255,255',
            'angle' => 0,
        );
        $background = $config['background'];
        $backgroundInfo = getimagesize($background);
        $backgroundFun = 'imagecreatefrom' . image_type_to_extension($backgroundInfo[2], false);
        $background = $backgroundFun($background);
        $backgroundWidth = imagesx($background);
        $backgroundHeight = imagesy($background);
        $imageRes = imageCreatetruecolor($backgroundWidth, $backgroundHeight);
        $color = imagecolorallocate($imageRes, 0, 0, 0);
        imagefill($imageRes, 0, 0, $color);
        imagecopyresampled($imageRes, $background, 0, 0, 0, 0, imagesx($background), imagesy($background), imagesx($background), imagesy($background));
        if (!empty($config['image'])) {
            foreach ($config['image'] as $key => $val) {

                    $val = array_merge($imageDefault, $val);
                    $info = getimagesize($val['url']);
                    $function = 'imagecreatefrom' . image_type_to_extension($info[2], false);
                    if ($val['stream']) {
                        $info = getimagesizefromstring($val['url']);
                        $function = 'imagecreatefromstring';
                    }
                    $res = $function($val['url']);
                    $resWidth = $info[0];
                    $resHeight = $info[1];
                    $canvas = imagecreatetruecolor($val['width'], $val['height']);
                    imagefill($canvas, 0, 0, $color);
                    $ext = pathinfo($val['url']);
                    if (array_key_exists('extension', $ext)) {
                        if ($ext['extension'] == 'gif' || $ext['extension'] == 'png') {
                            imageColorTransparent($canvas, $color);

                        }
                    }

                imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'], $resWidth, $resHeight);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']) - $val['width']:$val['left'];
                if ($val['left'] < 0) {
                    $val['left'] = ceil($backgroundWidth - $val['width']) / 2;
                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) - $val['height'] : $val['top'];
                imagecopymerge($imageRes, $canvas, $val['left'], $val['top'], $val['right'], $val['bottom'], $val['width'], $val['height'], $val['opacity']);

            }
        }
        if (!empty($config['text'])) {
            foreach ($config['text'] as $key => $val) {
                $val = array_merge($textDefault, $val);
                $val['text'] = diconv($val['text'],CHARSET,'UTF-8');
                list($R, $G, $B) = explode(',', $val['fontColor']);
                $fontColor = imagecolorallocate($imageRes, $R, $G, $B);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']):$val['left'];
                $text = autowrap($val['fontSize'], 0, $val['fontPath'], $val['text'], 600);
                if ($val['left'] < 0) {
                    $fontBox = imagettfbbox($val['fontSize'], 0, $val['fontPath'], $text);
                    $val['left'] = ceil(($backgroundWidth - $fontBox[2]) / 2);

                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) : $val['top'];
                imagettftext($imageRes, $val['fontSize'], $val['angle'], $val['left'], $val['top'], $fontColor, $val['fontPath'], $text);
            }
        }
        if (!empty($filename)) {
            $res = imagejpeg($imageRes, $filename, 90);
            imagedestroy($imageRes);
            if (!$res) return false;
            return $filename;
        } else {
            header("Content-type:image/png");
            imagejpeg($imageRes);
            imagedestroy($imageRes);
        }
    }

    function autowrap($fontsize, $angle, $fontface, $string, $width)
    {
        $content = "";
        for ($i = 0; $i < mb_strlen($string); $i++) {
            $letter[] = mb_substr($string, $i, 1);
        }

        foreach ($letter as $l) {
            $teststr = $content . " " . $l;
            $testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
            if (($testbox[2] > $width) && ($content !== "")) {
                $content .= "\n";
            }
            $content .= $l;
        }
        return $content;
    }