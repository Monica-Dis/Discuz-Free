<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $url = addslashes($_GET['sign_url']);
    $path = addslashes($_GET['path']);
    $toreferer = explode('/source/plugin/zimu_xiangqin/h5',$url);
    $toreferer = $toreferer[1];

    $name1 = 'mytoken';
    $a = explode('?',$toreferer);
    $url_f = $a[0];
    $query = $a[1];
    parse_str($query,$arr);
    $arr[$key] = $value;
    if($name1){
        unset($arr[$name1]);
    }
    $toreferer = $url_f.'?'.http_build_query($arr);

    $url = str_replace('?from=timeline&isappinstalled=0','',$url);
    $url = str_replace('?from=timeline&isappinstalled=1','',$url);
    $url = str_replace('?from=groupmessage&isappinstalled=0','',$url);
    $url = str_replace('?from=groupmessage&isappinstalled=1','',$url);
    $url = str_replace('?from=singlemessage&isappinstalled=0','',$url);
    $url = str_replace('?from=singlemessage&isappinstalled=1','',$url);

    $ids = intval($_GET['ids']);

    $myuid = checktoken($_GET['mytoken'],0);

    if($myuid['uid']){
        $qmhn = Db::name('zimu_xiangqin_qmhn_user')->where([['uid', '=', $myuid['uid']], ['status', '=', 1]])->find();
        if($qmhn){
            $qmhn_url = '&qmhn=1&fromid='.$myuid['uid'];
        }
    }


    if ($zmdata['settings']['weixin_appid'] && $zmdata['settings']['weixin_appsecret']) {
        require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);
        $jssdkvalue    = $wechat_client->getSignPackage($url);

        if($path=='pages/index/details') {

            $ids = str_replace('/pages/index/details?ids=', '', $toreferer);
            $myinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->findOrEmpty();
            $sex_cn = $myinfo['sex'] == 1 ? $language_zimu['wechatsign_inc_php_0'] : $language_zimu['wechatsign_inc_php_1'];

            $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'shareset')->find();
            $paramters = unserialize($paramter['parameter']);

            if($paramters['share_title']){

                $ideal = Db::name('zimu_xiangqin_users_ideal')->where(['uid' => $ids])->find();
                $value = $myinfo;
                $pattern = array(
                    'zimu_age2',
                    'zimu_height2',
                    'zimu_xueli2',
                    'zimu_yuexin2',
                    'zimu_work2',
                    'zimu_ganqing2',
                    'zimu_zhufang2',
                    'zimu_xiyan2',
                    'zimu_hejiu2',
                    'zimu_no',
                    'zimu_nickname',
                    'zimu_realname',
                    'zimu_sex',
                    'zimu_xueli',
                    'zimu_yuexin',
                    'zimu_age',
                    'zimu_shuxiang',
                    'zimu_constellation',
                    'zimu_height',
                    'zimu_weight',
                    'zimu_ganqing',
                    'zimu_work',
                    'zimu_zhufang',
                    'zimu_gouche',
                    'zimu_xiyan',
                    'zimu_hejiu',
                    'zimu_xingge',
                    'zimu_aihao',
                    'zimu_intro'
                );

                $replace = array(
                    $ideal['age_cn'],
                    $ideal['heights_cn'],
                    $ideal['xueli_cn'],
                    $yuexin_array[$ideal['yuexin']-1],
                    $ideal['work_cn'],
                    $ideal['ganqing_cn'],
                    $zhufang2_array[$ideal['zhufang']-1],
                    $xiyan2_array[$ideal['xiyan']-1],
                    $hejiu2_array[$ideal['hejiu']-1],
                    $value['no'],
                    $value['nickname'],
                    $value['realname'],
                    $value['sex']==1 ? $language_zimu['wechatsign_inc_php_2'] : $language_zimu['wechatsign_inc_php_3'],
                    $xueli_array[$value['xueli']-1],
                    $yuexin_array[$value['yuexin']-1],
                    $value['age'],
                    $shuxiang_array[$value['shuxiang']],
                    $xingzuo_array[$value['constellation']],
                    $value['height'],
                    $value['weight'],
                    $ganqing_array[$value['ganqing']-1],
                    $work_array[$value['work']-1],
                    $zhufang_array[$value['zhufang']-1],
                    $gouche_array[$value['gouche']-1],
                    $xiyan_array[$value['xiyan']-1],
                    $hejiu_array[$value['hejiu']-1],
                    $value['xingge'],
                    $value['aihao'],
                    $value['intro']
                );

                $share_title = str_replace($pattern,$replace,$paramters['share_title']);
                $share_desc = str_replace($pattern,$replace,$paramters['share_desc']);

            }else{
                $share_title = '#' . $language_zimu['wechatsign_inc_php_4'] . '#' . $myinfo['nickname'] . '/' . $sex_cn . '/' . $myinfo['age'] . $language_zimu['wechatsign_inc_php_5'] . '/' . $myinfo['height'] . 'cm/' . $xueli_array[$myinfo['xueli'] - 1] . '/' . $yuexin_array[$myinfo['yuexin'] - 1] . '/' . $work_array[$myinfo['work'] - 1];
                $share_desc = $zmdata['settings']['share_desc'];
            }

            $share_thumb = $paramters['share_thumb'] !=1 && $myinfo['photo'] ? $myinfo['photo'] : $zmdata['settings']['share_thumb_url'];
            if (strpos($toreferer, '?') !== false) {
                $share_url = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5' . $toreferer . '&mobile=2';
            } else {
                $share_url = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5' . $toreferer . '?mobile=2';
            }

        }elseif ($path=='pages/activity/show'){

            $ids = str_replace('/pages/activity/show?ids=', '', $toreferer);
            $sharedata = Db::name('zimu_xiangqin_activity')->where('id', $ids)->findOrEmpty();

            $share_title = $sharedata['title'];
            $share_desc = $zmdata['settings']['share_desc'];
            $share_thumb = $sharedata['thumb'];
            if (strpos($toreferer, '?') !== false) {
                $share_url = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5' . $toreferer . '&mobile=2';
            } else {
                $share_url = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5' . $toreferer . '?mobile=2';
            }


        }else{

            $share_title = $zmdata['settings']['share_title'];
            $share_desc = $zmdata['settings']['share_desc'];
            $share_thumb = $zmdata['settings']['share_thumb_url'];
            if(strpos($toreferer,'?') !== false){
                $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5'.$toreferer.'&mobile=2';
            }else{
                $share_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5'.$toreferer.'?mobile=2';
            }
        }

        $share_url = str_replace('?&','?',$share_url);

        if($path=='pages/my/my'){
            $nav_title = $language_zimu['wechatsign_inc_php_6'].'-'.$zmdata['settings']['title'];
        }elseif ($path=='pages/my/vip'){
            $nav_title = 'VIP'.$language_zimu['wechatsign_inc_php_7'].'-'.$zmdata['settings']['title'];
        }elseif ($path=='pages/activity/show'){
            $nav_title = $share_title.$zmdata['settings']['title'];
        }else{
            $nav_title = $zmdata['settings']['share_title'];
        }


        $jssdkvalue['shareOptions']['navtitle'] = $nav_title;
        $jssdkvalue['shareOptions']['title'] = $share_title;
        $jssdkvalue['shareOptions']['desc'] = $share_desc;
        $jssdkvalue['shareOptions']['link'] = $_G['siteurl'].'plugin.php?id=zimu_xiangqin&model=newindex'.$qmhn_url.'&tourl='.urlencode($share_url);
        $jssdkvalue['shareOptions']['imgUrl'] = $share_thumb;

        echo json_encode(zimu_array_utf8($jssdkvalue),true);
    }
