<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $tourl = $_G['siteurl'].'source/plugin/zimu_xiangqin/h5/pages/my/login?mobile=2';

    if($_GET['lizimu']==1){
        $tourl = 'http://localhost:8080/pages/my/login?mobile=2';
    }

    $op = addslashes($_GET['op']);

    if($op=='deltoken'){

        $deltoken = addslashes($_GET['deltoken']);
        $tourl = str_replace('&mytoken='.$mytoken, '', $tourl);
        dheader('Location:' . $tourl);
        exit();


    }else {

        isuid($tourl);

        if (IN_WECHAT && $zmdata['settings']['weixin_appid'] && $zmdata['settings']['weixin_appsecret']) {

            $xq_openid = zm_wechat_auth($_G['siteurl'] . $_SERVER['REQUEST_URI']);
            if(strlen($xq_openid) > 50){
                $xq_openid = '';
            }
            list($xq_unionid, $uptime) = getcookie('zimu_xiangqin_unionid') ? explode("\t", authcode(getcookie('zimu_xiangqin_unionid'), 'DECODE')) : array();

        }


        if ($_G['uid']) {

            $tokeninfo = Db::name('zimu_xiangqin_token')->where('uid', $_G['uid'])->find();

            if ($tokeninfo && !$tokeninfo['openid'] && $xq_openid) {

                Db::name('zimu_xiangqin_token')->where('uid', $_G['uid'])->update(['openid' => $xq_openid,'unionid' => $xq_unionid]);

            }

            if (!$tokeninfo) {
                $token_data['uid'] = $_G['uid'];
                $token_data['username'] = $_G['username'];
                $token_data['token'] = getRandChar(32);
                $token_data['openid'] = $xq_openid ? $xq_openid : '';
                $token_data['unionid'] = $xq_unionid ? $xq_unionid : '';
                $token_data['xcx_openid'] = '';
                $token_data['addtime'] = $_G['timestamp'];
                Db::name('zimu_xiangqin_token')->insert($token_data);
                $tokeninfo = $token_data;
            }

        }

        $name1 = 'mytoken';
        $a = explode('?',$tourl);
        $url_f = $a[0];
        $query = $a[1];
        parse_str($query,$arr);
        $arr[$key] = $value;
        if($name1){
            unset($arr[$name1]);
        }
        $tourl = $url_f.'?'.http_build_query($arr);
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false && strpos($_SERVER['HTTP_USER_AGENT'], 'LiaoChengLiaoApp') == false){
            exit('<script src="source/plugin/zimu_xiangqin/static/js/magjs-x.js"></script><script>
                mag.closeWin();
                mag.newWin("' . $tourl . '&mytoken=' . $tokeninfo['token'] . '");
                    </script>');
            exit();
        }else{
            dheader('Location:' . $tourl . '&mytoken=' . $tokeninfo['token']);
            exit();
        }
    }
