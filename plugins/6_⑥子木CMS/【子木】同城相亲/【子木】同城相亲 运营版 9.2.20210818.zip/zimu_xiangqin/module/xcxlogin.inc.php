<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $login_code = addslashes($_GET['login_code']);
    $encryptedData = addslashes($_GET['encryptedData']);
    $signature = addslashes($_GET['signature']);
    $iv = addslashes($_GET['iv']);
    $nickName = addslashes($_GET['nickName']);
    $gender = intval($_GET['gender']);
    $avatarUrl = addslashes($_GET['avatarUrl']);

    $xcxurl = 'https://api.weixin.qq.com/sns/jscode2session?appid=' . $zmdata['settings']['xcx_appid'] . '&secret=' . $zmdata['settings']['xcx_appsecret'] . '&js_code=' . $login_code . '&grant_type=authorization_code';
    $xcxdata = zm_curl($xcxurl);
    $xcxdata2 = json_decode($xcxdata, true);

    if ($xcxdata2['unionid']) {

        $xcx_zimu_data['username'] = zimu_array_utf8($nickName);
        $xcx_zimu_data['username2'] = $nickName;
        $xcx_zimu_data['gender'] = $gender;
        $xcx_zimu_data['avatar'] = $avatarUrl;
        $xcx_zimu_data['openid'] = $xcxdata2['openid'];
        $xcx_zimu_data['unionid'] = $xcxdata2['unionid'];
        $xcx_zimu_data['xcx_appid'] = $zmdata['xcx_appid'];

    } else {

        require_once DISCUZ_ROOT . 'source/plugin/zimu_xiangqin/class/wxBizDataCrypt.php';

        $appid = $zmdata['settings']['xcx_appid'];
        $sessionKey = $xcxdata2['session_key'];

        $pc = new WXBizDataCrypt($appid, $sessionKey);
        $errCode = $pc->decryptData($encryptedData, $iv, $data);

        $xcxdata3 = json_decode($data, true);

        $xcx_zimu_data['username'] = zimu_array_utf8($nickName);
        $xcx_zimu_data['username2'] = $nickName;
        $xcx_zimu_data['gender'] = $xcxdata3['gender'];
        $xcx_zimu_data['avatar'] = $xcxdata3['avatarUrl'];
        $xcx_zimu_data['openid'] = $xcxdata3['openId'];
        $xcx_zimu_data['unionid'] = $xcxdata3['unionId'];
        $xcx_zimu_data['xcx_appid'] = $zmdata['xcx_appid'];

    }

    $isuid = xcx_select_uid($xcx_zimu_data);

    if ($isuid['uid'] > 0) {

        $res['myinfo'] = $isuid;
        zimu_json($res);

    } else {


        if ($xcx_zimu_data['unionid'] && $zmdata['settings']['xcx_data_table'] && $zmdata['settings']['xcx_data_union'] && $zmdata['settings']['xcx_data_uid']) {

            $isuid_array = Db::name($zmdata['settings']['xcx_data_table'])->where($zmdata['settings']['xcx_data_union'],$xcx_zimu_data['unionid'])->order(['id'=>'desc'])->find();

            if ($isuid_array[$zmdata['settings']['xcx_data_uid']] > 0) {

                $istoken = array(
                    'uid' => $isuid_array[$zmdata['settings']['xcx_data_uid']],
                    'xcx_openid' => $xcx_zimu_data['openid'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'token' => getRandChar(64)
                );
                Db::name('zimu_xiangqin_token')->insert($istoken);

                $res['myinfo'] = $istoken;
                zimu_json($res);

            } else {

                $reguid = xcx_reg_user($xcx_zimu_data,$zmdata);

                $istoken = array(
                    'uid' => $reguid,
                    'xcx_openid' => $xcx_zimu_data['openid'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'token' => getRandChar(64)
                );
                Db::name('zimu_xiangqin_token')->insert($istoken);

                $res['myinfo'] = $istoken;
                zimu_json($res);

            }


        } else {

            $reguid = xcx_reg_user($xcx_zimu_data,$zmdata);

            $istoken = array(
                'uid' => $reguid,
                'xcx_openid' => $xcx_zimu_data['openid'],
                'unionid' => $xcx_zimu_data['unionid'],
                'token' => getRandChar(64)
            );
            Db::name('zimu_xiangqin_token')->insert($istoken);

            $res['myinfo'] = $istoken;
            zimu_json($res);


        }

    }



