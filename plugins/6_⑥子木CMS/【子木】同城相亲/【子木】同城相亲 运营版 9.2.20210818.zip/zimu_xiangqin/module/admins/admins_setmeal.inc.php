<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        if (submitcheck('submit')) {

            $data['setmeal_name']        = strip_tags($_GET['setmeal_name']);
            $data['days']        = intval($_GET['days']);
            $data['expense']         = intval($_GET['expense']*100);
            $data['line']        = intval($_GET['line']);
            $data['days2']        = intval($_GET['days2']);
            $data['tip']        = strip_tags($_GET['tip']);
            $data['note']        = $_GET['note'];
            $data['sort']        = intval($_GET['sort']);
            $data['id']      = intval($_GET['ids']);

            if ($data['id'] > 0) {

                DB::update('zimu_xiangqin_setmeal', $data, array(
                    'id' => $data['id']
                ));

            } else {

                $result = DB::insert('zimu_xiangqin_setmeal', $data, 1);

            }


            include template('zimu_xiangqin:common/success');


        } else {

            $ids = intval($_GET['ids']);

            $listdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimu_xiangqin_setmeal',
                $ids
            ));

            include zimu_template('admins/admins_' . $type,'');

        }


    } else if ($op == 'del' && $_GET['md5hash'] == formhash()) {

        $ids = intval($_GET['ids']);

        $result = DB::delete('zimu_xiangqin_setmeal', array(
            'id' => $ids
        ));

        include template('zimu_xiangqin:common/success');


    } else {

        $wheresql = 'where 1=1 ';

        $pindex = max(1, intval($_GET['page']));
        $psize  = 100;

        $listdata = DB::fetch_all('select * from %t %i order by id asc limit %d,%d', array(
            'zimu_xiangqin_setmeal',
            $wheresql,
            ($pindex - 1) * $psize,
            $psize
        ));

        $pager = pagination($total, $pindex, $psize);


        include zimu_template('admins/admins_' . $type,'');


    }