<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('submit')) {

    if($_G['uid']!=1 && ($_G['siteurl'] == 'https://demo.zimucms.com/' || $_G['siteurl'] == 'http://demo.zimucms.com/')){
        include template('zimu_xiangqin:common/success');
        exit();
    }

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_xiangqin_parameter2',
            'aliyunsms'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_xiangqin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'aliyunsms',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_xiangqin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_xiangqin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_xiangqin_parameter2',
            'aliyunsms'
        ));
        
        $paramters = unserialize($paramter['parameter']);

    if($_G['uid']!=1 && ($_G['siteurl'] == 'https://demo.zimucms.com/' || $_G['siteurl'] == 'http://demo.zimucms.com/')){
        $paramters = '';
    }

include zimu_template('admins/admins_'.$type,'');


}