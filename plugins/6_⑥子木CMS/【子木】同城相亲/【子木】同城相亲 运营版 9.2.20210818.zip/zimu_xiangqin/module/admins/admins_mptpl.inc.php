<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $ac = addslashes($_GET['ac']);
    $ac = $ac ? $ac : 'list';

    if($ac == 'ajaxtpl'){

        $keywordtype = intval($_GET['keywordtype']);
        $keyword = trim($_GET['keyword']);
        $keyword = zimu_array_gbk($keyword);

        $wheresql[] = ['state','=',1];

        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['no','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['uid','=',$keyword];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['realname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['nickname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 5) {
                $wheresql[] = ['mobile','=',$keyword];
            }
        }

        $vip_type = $_GET['vip_type'];
        if($vip_type){
            $wheresql[] = ['vip_type','in',$vip_type];
        }

        $real_state = intval($_GET['real_state']);
        if($real_state){
            $wheresql[] = ['real_state','=',$real_state];
        }

        $status = intval($_GET['status']);
        if($status){
            $wheresql[] = ['status','=',$status];
        }


        $sex = intval($_GET['sex']);
        if (!empty($sex)) {
            $wheresql[] = ['sex','=',$sex];
        }

        $height1 = intval($_GET['height1']);
        if (!empty($height1)) {
            $wheresql[] = ['height','>=',$height1];
        }
        $height2 = intval($_GET['height2']);
        if (!empty($height2)) {
            $wheresql[] = ['height','<=',$height2];
        }

        $age1 = intval($_GET['age1']);
        if (!empty($age1)) {
            $wheresql[] = ['age','>=',$age1];
        }
        $age2 = intval($_GET['age2']);
        if (!empty($age2)) {
            $wheresql[] = ['age','<=',$age2];
        }

        $ganqing = intval($_GET['ganqing']);
        if (!empty($ganqing)) {
            $wheresql[] = ['ganqing','=',$ganqing];
        }

        $xueli = intval($_GET['xueli']);
        if (!empty($xueli)) {
            $wheresql[] = ['xueli','=',$xueli];
        }

        $yuexin = intval($_GET['yuexin']);
        if (!empty($yuexin)) {
            $wheresql[] = ['yuexin','>=',$yuexin];
        }

        $work = intval($_GET['work']);
        if (!empty($work)) {
            $wheresql[] = ['work','=',$work];
        }

        $todate = intval($_GET['todate']);
        if (!empty($todate)) {
            $wheresql[] = ['addtime','>=',time()-(86400*$todate)];
        }


        $order = intval($_GET['order']);
        if($order==1){
            $whereorder['refreshtime'] = 'desc';
        }else if($order==2){
            $whereorder['addtime'] = 'desc';
        }else{
            $whereorder['addtime'] = 'desc';
        }

        $limit = intval($_GET['limit']);

        $listdata = Db::name('zimu_xiangqin_users')->where([$wheresql])->order($whereorder)->limit($limit)->select()->toArray();

        $tpl = intval($_GET['tpl']);
        $tplcon = Db::name('zimu_xiangqin_mptpl')->where('id',$tpl)->value('tpl');


        foreach ($listdata as $key => $value) {
            $ideal = Db::name('zimu_xiangqin_users_ideal')->where(['uid' => $value['uid']])->find();

            $pattern = array(
                'zimu_age2',
                'zimu_height2',
                'zimu_xueli2',
                'zimu_yuexin2',
                'zimu_work2',
                'zimu_ganqing2',
                'zimu_zhufang2',
                'zimu_xiyan2',
                'zimu_hejiu2',
                'zimu_photo',
                'zimu_no',
                'zimu_nickname',
                'zimu_realname',
                'zimu_sex',
                'zimu_xueli',
                'zimu_yuexin',
                'zimu_age',
                'zimu_shuxiang',
                'zimu_constellation',
                'zimu_height',
                'zimu_weight',
                'zimu_ganqing',
                'zimu_work',
                'zimu_zhufang',
                'zimu_gouche',
                'zimu_xiyan',
                'zimu_hejiu',
                'zimu_xingge',
                'zimu_aihao',
                'zimu_intro',
                'zimu_qrcode',
            );

            if ($zmdata['settings']['wx_create_qrcode']==1) {
                require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['settings']['weixin_appid'], $zmdata['settings']['weixin_appsecret']);
                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'xiangqin_poster_zimuyun'.$value['uid'],'expire'=>2591000)));

                $dir = DISCUZ_ROOT.'/source/plugin/zimu_xiangqin/uploadzimucms/';
                $qrcode_file = $dir.'qrcode/details_'.$value['uid'].'.jpg';

                $qrcode_img = dfsockopen($qrcode_url);
                $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url);
                $fp = fopen($qrcode_file, 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcode_img);
                fclose($fp);
                $qrcode_url = $_G['siteurl'].'source/plugin/zimu_xiangqin/uploadzimucms/qrcode/details_'.$value['uid'].'.jpg';
            } else {
                $qrcode_url = ZIMUCMS_URL.':toqrcode&url=' . urlencode(ZIMUCMS_URL2 . 'pages/index/details?ids=' . $value['uid'].'&mobile=2');
            }

            $replace = array(
                $ideal['age_cn'],
                $ideal['heights_cn'],
                $ideal['xueli_cn'],
                $yuexin_array[$ideal['yuexin']-1],
                $ideal['work_cn'],
                $ideal['ganqing_cn'],
                $zhufang2_array[$ideal['zhufang']-1],
                $xiyan2_array[$ideal['xiyan']-1],
                $hejiu2_array[$ideal['hejiu']-1],
                $value['photo'],
                $value['no'],
                $value['nickname'],
                $value['realname'],
                $value['sex']==1 ? $language_zimu['admins_mptpl_inc_php_0'] : $language_zimu['admins_mptpl_inc_php_1'],
                $xueli_array[$value['xueli']-1],
                $yuexin_array[$value['yuexin']-1],
                $value['age'],
                $shuxiang_array[$value['shuxiang']],
                $xingzuo_array[$value['constellation']],
                $value['height'],
                $value['weight'],
                $ganqing_array[$value['ganqing']-1],
                $work_array[$value['work']-1],
                $zhufang_array[$value['zhufang']-1],
                $gouche_array[$value['gouche']-1],
                $xiyan_array[$value['xiyan']-1],
                $hejiu_array[$value['hejiu']-1],
                $value['xingge'],
                $value['aihao'],
                $value['intro'],
                $qrcode_url
        );

            $newcon = str_replace($pattern,$replace,$tplcon);

            $rescon = $rescon.$newcon;

        }

        echo $rescon;exit();



    }else{

    $setmealist = Db::name('zimu_xiangqin_setmeal')->order('id','asc')->select()->toArray();

    $mplists = Db::name('zimu_xiangqin_mptpl')->order('id','asc')->select()->toArray();

    include zimu_template('admins/admins_mptpl','');

    }