<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_xiangqin_users_fav', array(
        'id' => $ids
    ));
    
    include template('zimu_xiangqin:common/success');

} else {
    
    $wheresql = 'where 1=1 ';
    $whereorder = 'id';

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql .= " and status = ".($status-1);
    }

    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `touid` = '{$keyword}' ";
        }
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_xiangqin_users_fav",
        $wheresql
    ));


    $listdata = DB::fetch_all('select * from %t %i order by %i desc limit %d,%d', array(
        'zimu_xiangqin_users_fav',
        $wheresql,
        $whereorder,
        ($pindex - 1) * $psize,
        $psize
    ));

    foreach ($listdata as $key => $value) {
        $listdata[$key]['uidinfo'] = DB::fetch_first('select * from %t where uid=%d', array(
            'zimu_xiangqin_users',
            $value['uid']
        ));
        $listdata[$key]['touidinfo'] = DB::fetch_first('select * from %t where uid=%d', array(
            'zimu_xiangqin_users',
            $value['touid']
        ));
    }
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}