<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        if (submitcheck('submit')) {

            $data['uid']         = intval($_GET['uid']);

            $data['kefu_name']         = strip_tags($_GET['kefu_name']);
            if ($_FILES['kefu_photo']['tmp_name']) {
                $data['kefu_photo'] = zm_saveimages($_FILES['kefu_photo']);
            }
            $data['kefu_mobile']         = strip_tags($_GET['kefu_mobile']);
            $data['kefu_wxid']         = strip_tags($_GET['kefu_wxid']);
            if ($_FILES['kefu_qrcode_url']['tmp_name']) {
                $data['kefu_qrcode_url'] = zm_saveimages($_FILES['kefu_qrcode_url']);
            }
            $data['kefu_slogan']         = strip_tags($_GET['kefu_slogan']);
            $data['kefu_power']         = intval($_GET['kefu_power']);

            $data['id']      = intval($_GET['ids']);

            if ($data['id'] > 0) {

                Db::name('zimu_xiangqin_kefu')->where('id' ,$data['id'])->update($data);

            } else {

                Db::name('zimu_xiangqin_kefu')->insert($data);

            }


            include template('zimu_xiangqin:common/success');


        } else {

            $ids = intval($_GET['ids']);

            $listdata = Db::name('zimu_xiangqin_kefu')->where('id', $ids)->find();

            include zimu_template('admins/admins_' . $type,'');

        }


    } else if ($op == 'del' && $_GET['md5hash'] == formhash()) {

        $ids = intval($_GET['ids']);

        Db::name('zimu_xiangqin_kefu')->where('id', $ids)->delete();

        include template('zimu_xiangqin:common/success');

    } else {

        $pindex = max(1, intval($_GET['page']));
        $psize  = 30;

        $total = Db::name('zimu_xiangqin_kefu')->count();

        $listdata = Db::name('zimu_xiangqin_kefu')->order(['id'=>'asc'])->page($pindex,30)->select()->toArray();

        $pager = pagination($total, $pindex, $psize);

        include zimu_template('admins/admins_' . $type,'');


    }