<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_xiangqin_jubao', array(
        'id' => $ids
    ));
    
    include template('zimu_xiangqin:common/success');


} else {

if(submitcheck('submit')) {

    if (!empty($_GET['ids'])) {
        foreach ($_GET['ids'] as $k => $v) {

            if($v){
                $data = array('status' => intval($_GET['status'][$k]));

                DB::update('zimu_xiangqin_jubao', $data, array(
                    'id' => $v
                ));

            }

        }
    }
        include template('zimu_xiangqin:common/success');


}else{

    $wheresql = 'where 1=1 ';

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql .= " and status = ".($status-1);
    }
       
    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_xiangqin_jubao",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_xiangqin_jubao',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
}

}