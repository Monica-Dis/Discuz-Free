<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'setting';

if($op =='setting'){

    if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        if ($_FILES['myhaibao']['tmp_name']) {
            $paramters['myhaibao_url'] = zm_saveimages($_FILES['myhaibao'],'zimucms',1);
        }

        $isadd = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();

        if ($isadd['id'] > 0) {

            Db::name('zimu_xiangqin_parameter2')->where('id', $isadd['id'])->update(['parameter' => serialize($paramters)]);

        } else {

            $adddata = array(
                'name'=>'qmhn',
                'parameter'=>serialize($paramters),
            );

            Db::name('zimu_xiangqin_parameter2')->insertGetId($adddata);

        }


        include template('zimu_xiangqin:common/success');

    }else{

        $paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
        $paramters = unserialize($paramter['parameter']);

        include zimu_template('admins/admins_'.$type,'');


    }

}elseif ($op=='users'){

    $listdata = Db::name('zimu_xiangqin_qmhn_user')->order(['id'=>'desc'])->select()->toArray();

    include zimu_template('admins/admins_'.$type.'_'.$op,'');

}elseif ($op=='edit_user'){

    if(submitcheck('submit')) {

        $data['username']         = strip_tags($_GET['username']);
        $data['mobile']         = strip_tags($_GET['mobile']);
        $data['weixin']         = strip_tags($_GET['weixin']);
        $data['can_cash']         = intval($_GET['can_cash']);
        $data['cash']         = intval($_GET['cash']);
        $data['tixian_log']         = strip_tags($_GET['tixian_log']);

        $data['id']      = intval($_GET['ids']);

        if ($data['id'] > 0) {

            Db::name('zimu_xiangqin_qmhn_user')->where('id' ,$data['id'])->update($data);
        }
        include template('zimu_xiangqin:common/success');

    }else{

        $ids = intval($_GET['ids']);
        $listdata = Db::name('zimu_xiangqin_qmhn_user')->where('id', $ids)->find();
        include zimu_template('admins/admins_'.$type.'_users');

    }

}elseif ($op=='del_user'){

    $ids = intval($_GET['ids']);

    Db::name('zimu_xiangqin_qmhn_user')->where('id', $ids)->delete();

    include template('zimu_xiangqin:common/success');


} else if ($op == 'changeuser') {

    $qmhn_user_data['mobile']         = strip_tags($_GET['mobile']);
    $qmhn_user_data['weixin']         = strip_tags($_GET['weixin']);
    $qmhn_user_data['cash']         = intval($_GET['cash']);
    $qmhn_user_data['can_cash']         = intval($_GET['can_cash']);
    $qmhn_user_data['status']         = intval($_GET['status']);
    $qmhn_user_data['tip'] = zimu_array_gbk(strip_tags($_GET['tip']));

    Db::name('zimu_xiangqin_qmhn_user')->where('uid' ,$_GET['ids'])->update($qmhn_user_data);
    zimu_json('',$language_zimu['admins_tuiguang_inc_php_0']);

} else if ($op == 'log') {

    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql[] = ['uid','=',$keyword];
        }
    }


    $listdata = Db::name('zimu_xiangqin_qmhn_log')->where($wheresql)->order(['id'=>'desc'])->select()->toArray();

    include zimu_template('admins/admins_'.$type.'_'.$op,'');

}