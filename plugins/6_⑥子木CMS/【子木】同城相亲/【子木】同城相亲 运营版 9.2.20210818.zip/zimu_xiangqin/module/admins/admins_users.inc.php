<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
    use think\Db;
$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

    if (submitcheck('submit')) {

        $data['uid']        = strip_tags($_GET['uid']);
        if(!$_GET['no']){
            $data['no']        = 52083333+$data['uid'];
        }else{
            $data['no']        = strip_tags($_GET['no']);
        }
        $data['nickname']        = strip_tags($_GET['nickname']);
        $data['realname']        = strip_tags($_GET['realname']);
        if ($_FILES['photo']['tmp_name']) {
            $data['photo'] = zm_saveimages($_FILES['photo']);
        }
        $data['sex']         = intval($_GET['sex']);
        $data['birth']         = strip_tags($_GET['birth']);
        $mybirth = explode('-',$data['birth']);
        if($mybirth[0] && $mybirth[1]){
            $data['age'] = 2021 - $mybirth[0];
        }
        $data['shuxiang']         = ($mybirth[0]-1948)%12;
        $data['constellation'] = getconstellation($mybirth[1],$mybirth[2]);
        $data['height']         = intval($_GET['height']);
        $data['weight']         = intval($_GET['weight']);
        $data['xueli']         = intval($_GET['xueli']);
        $data['ganqing']         = intval($_GET['ganqing']);
        $data['work']         = intval($_GET['work']);
        $data['yuexin']         = intval($_GET['yuexin']);
        $data['zhufang']         = intval($_GET['zhufang']);
        $data['gouche']         = intval($_GET['gouche']);
        $data['xiyan']         = intval($_GET['xiyan']);
        $data['hejiu']         = intval($_GET['hejiu']);
        $data['mobile']         = strip_tags($_GET['mobile']);
        $data['weixin']         = strip_tags($_GET['weixin']);
        $data['guesthide']         = intval($_GET['guesthide']);
        $data['status']         = intval($_GET['status']);
        $data['state']         = intval($_GET['state']);
        $data['state_note']         = strip_tags($_GET['state_note']);
        $data['intro']         = strip_tags($_GET['intro']);
        $data['xingge']         = strip_tags($_GET['xingge']);
        $data['aihao']         = strip_tags($_GET['aihao']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['hn_uid']      = intval($_GET['hn_uid']);
        if ($data['hn_uid']) {
            $data['hn_name'] = Db::name('zimu_xiangqin_kefu')->where('uid', $data['hn_uid'])->value('kefu_name');
        }
        $data['city']      = intval($_GET['input_province']).','.intval($_GET['input_city']).','.intval($_GET['input_area']);
        $data['city2']      = intval($_GET['input_province2']).','.intval($_GET['input_city2']).','.intval($_GET['input_area2']);

        $data['id']      = intval($_GET['ids']);

        if ($data['id'] > 0) {

            $ids = intval($_GET['ids']);

            $listdata = Db::name('zimu_xiangqin_users')->where('id', $data['id'])->find();

            Db::name('zimu_xiangqin_smslog')->where('uid' ,$data['uid'])->update(['mobile' => $data['mobile']]);

            if($data['state']!=0 && $data['state'] != $listdata['state']){

                $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();

                $paramters = unserialize($paramter['parameter']);

                $first = $data['realname'].$language_zimu['admins_users_inc_php_0'].($data['state']==1 ? $language_zimu['admins_users_inc_php_1'] : $language_zimu['admins_users_inc_php_2']);

                if($data['state']==1){
                    notification_user_sms($listdata,'chanyoo_sms_tp5',$data['state_note']);
                }elseif($data['state']==2){
                    notification_user_sms($listdata,'chanyoo_sms_tp6',$data['state_note']);
                }

                $templatedata = array(
                    'first' => array(
                        'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                        'color' => "#FF4040"
                    ),
                    'keyword1' => array(
                        'value' => urlencode(diconv($language_zimu['admins_users_inc_php_3'], CHARSET, 'utf-8'))
                    ),
                    'keyword2' => array(
                        'value' => urlencode(diconv($data['realname'], CHARSET, 'utf-8'))
                    ),
                    'keyword3' => array(
                        'value' => urlencode(diconv($language_zimu['admins_users_inc_php_4'].($data['state']==1 ? $language_zimu['admins_users_inc_php_5'] : $language_zimu['admins_users_inc_php_6']), CHARSET, 'utf-8'))
                    ),
                    'keyword4' => array(
                        'value' => date('Y-m-d H:i',$_G['timestamp'])
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($data['state_note'])), CHARSET, 'utf-8')),
                        'color' => "#008000"
                    )
                );

                notification_user($data['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);

                $magcon = '{"tag":"'.$language_zimu['admins_users_inc_php_7'].'","title":"'.$data['realname'].$language_zimu['admins_users_inc_php_8'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'","extra_info":[{"key":"'.$language_zimu['admins_users_inc_php_9'].'","val":"'.($data['state']==1 ? $language_zimu['admins_users_inc_php_10'] : $language_zimu['admins_users_inc_php_11']).'"}],"des":"'.$data['state_note'].'<br>'.$language_zimu['admins_users_inc_php_12'].'","des_themecolor":"#008000"}';

                notification_user_magapp($data['uid'],$magcon);

                $qfcon['msg'] = $language_zimu['admins_users_inc_php_13'];
                $qfcon['showdata'] = '';
                $qfcon['showdata'] = array(
                    'title'=>diconv($language_zimu['admins_users_inc_php_14'], CHARSET, 'utf-8'),
                    'date'=>date('Y-m-d H:i:s'),
                    'setting'=>array(),
                    'content' => diconv($language_zimu['admins_users_inc_php_15'].($data['state']==1 ? $language_zimu['admins_users_inc_php_16'] : $language_zimu['admins_users_inc_php_17']),CHARSET,'UTF-8'),
                    'url'=>ZIMUCMS_URL
                );

                notification_user_qfapp($data['uid'],$qfcon);


            }

            Db::name('zimu_xiangqin_users')->where('id' ,$data['id'])->update($data);
            
        } else {

            Db::name('zimu_xiangqin_users')->insert($data);
            
        }

        Db::name('zimu_xiangqin_users_album')->where([['uid','=',$data['uid']],['id','notin',$_GET['image_ids']]])->delete();

        foreach ($_GET['image'] as $key => $value) {
            if($value){
                if (!preg_match('/^(http|\.)/i', $value)) {
                    $value = zm_saveimages_base64($value,'album');
                }
                if(intval($_GET['image_ids'][$key])){
                    $album_data = array('url' => $value);
                    Db::name('zimu_xiangqin_users_album')->where('id' ,intval($_GET['image_ids'][$key]))->update($album_data);
                }else{
                    $album_data = array('uid' => $data['uid'], 'url' => $value, 'sort' => 100);
                    Db::name('zimu_xiangqin_users_album')->insert($album_data);
                }
            }
        }

        include template('zimu_xiangqin:common/success');
        
        
    } else {

        $ids = intval($_GET['ids']);

        $listdata = Db::name('zimu_xiangqin_users')->where('id', $ids)->find();

        if($listdata['photo']){
            $imageInfo = getimagesize($listdata['photo']);
            $base64 = "" . chunk_split(base64_encode(file_get_contents($listdata['photo'])));
            $base64img = 'data:' . $imageInfo['mime'] . ';base64,' . chunk_split(base64_encode(file_get_contents($listdata['photo'])));
            $base64img = str_replace(array("\r\n", "\r", "\n"), "", $base64img);
        }

        $myalbum = Db::name('zimu_xiangqin_users_album')->where('uid', $listdata['uid'])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($myalbum as $key => $value) {
            $albumdata = $albumdata.',"'.$value['url'].'"';
            $albumdata_ids = $albumdata_ids.',"'.$value['id'].'"';
        }
        $albumdata = substr($albumdata,1);
        $albumdata_ids = substr($albumdata_ids,1);

        $kefudata = Db::name('zimu_xiangqin_kefu')->order(['id'=>'asc'])->select()->toArray();

        if($listdata['city']){
            $city = explode(',',$listdata['city']);
        }
        if($listdata['city2']){
            $city2 = explode(',',$listdata['city2']);
        }
        include zimu_template('admins/admins_' . $type,'');
        
    }

} else if ($op == 'base64photo') {

    $ids = intval($_GET['ids']);
    $imgbase64 = addslashes($_GET['imgbase64']);
    $photo['photo'] = zm_saveimages_base64($imgbase64, 'photo');

    Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update($photo);
    exit();

} else if ($op == 'blob_photo') {

    $ids = intval($_GET['ids']);
    if ($_FILES['imageblob']['tmp_name']) {
        $photo['photo'] = zm_saveimages($_FILES['imageblob']);
        Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update($photo);
        exit();
    }

} else if ($op == 'edit_ideal') {

    if (submitcheck('submit')) {

        $ids = intval($_GET['ids']);
        $isadd = Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->find();

        $min_age_cn = $_GET['min_age'] > 0 ? $_GET['min_age'].$language_zimu['admins_users_inc_php_18'] : $language_zimu['admins_users_inc_php_19'];
        $max_age_cn = $_GET['max_age'] > 0 ? $_GET['max_age'].$language_zimu['admins_users_inc_php_20'] : $language_zimu['admins_users_inc_php_21'];
        $min_height_cn = $_GET['min_height'] > 0 ? $_GET['min_height'].'CM' : $language_zimu['admins_users_inc_php_22'];
        $max_height_cn = $_GET['max_height'] > 0 ? $_GET['max_height'].'CM' : $language_zimu['admins_users_inc_php_23'];
        $ideal_data['uid'] = $ids;
        $ideal_data['age'] = $_GET['min_age'].','.$_GET['max_age'];
        $ideal_data['age_cn'] = $min_age_cn.'-'.$max_age_cn;
        $ideal_data['heights'] = $_GET['min_height'].','.$_GET['max_height'];
        $ideal_data['heights_cn'] = $min_height_cn.'-'.$max_height_cn;
        $ideal_data['xueli'] = strip_tags($_GET['xueli']);
        $ideal_data['xueli_cn'] = strip_tags($_GET['xueli_cn']);
        $ideal_data['work'] = strip_tags($_GET['work']);
        $ideal_data['work_cn'] = strip_tags($_GET['work_cn']);
        $ideal_data['yuexin'] = strip_tags($_GET['yuexin']);
        $ideal_data['ganqing'] = strip_tags($_GET['ganqing']);
        $ideal_data['ganqing_cn'] = strip_tags($_GET['ganqing_cn']);
        $ideal_data['zhufang'] = intval($_GET['zhufang'])+1;
        $ideal_data['xiyan'] = intval($_GET['xiyan'])+1;
        $ideal_data['hejiu'] = intval($_GET['hejiu'])+1;

        if ($isadd['id'] > 0) {
            Db::name('zimu_xiangqin_users_ideal')->where('id' ,$isadd['id'])->update($ideal_data);
        } else {
            Db::name('zimu_xiangqin_users_ideal')->insert($ideal_data);
        }

        include template('zimu_xiangqin:common/success');

    }else{
        $ids = intval($_GET['ids']);
        $listdata = Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->find();
        $age = explode(',',$listdata['age']);
        $listdata['min_age'] = $age[0];
        $listdata['max_age'] = $age[1];
        $heights = explode(',',$listdata['heights']);
        $listdata['min_height'] = $heights[0];
        $listdata['max_height'] = $heights[1];

        include zimu_template('admins/admins_' . $type,'');
    }

} else if ($op == 'set_hnsay') {

    $ids = intval($_GET['ids']);
    $hnsay = strip_tags($_GET['hnsay']);

    Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update(['hn_say' => zimu_array_gbk($hnsay)]);
    zimu_json('',$language_zimu['admins_users_inc_php_24']);

} else if ($op == 'crmindex') {

    $ids = intval($_GET['ids']);
    $listdata = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();
    $feedbacklist = Db::name('zimu_xiangqin_feedback')->where('uid', $ids)->order(['id'=>'desc'])->select()->toArray();
    $loglist = Db::name('zimu_xiangqin_applyline')->whereOr(['uid'=>$ids,'touid'=>$ids])->order(['id'=>'desc'])->select()->toArray();

    include zimu_template('admins/admins_' . $type,'');

} else if ($op == 'crm_feedback') {

    $ids    = intval($_GET['ids']);
    $crm_feedback['uid']     = $ids;
    $crm_feedback['note']       = zm_diconv(trim($_GET['note']));
    $crm_feedback['addtime']     = $_G['timestamp'];
    Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);

    zimu_json('',$language_zimu['admins_users_inc_php_25']);

} else if ($op == 'setremark') {

    $ids = intval($_GET['ids']);

    $remark = zm_diconv(trim($_GET['remark']));

    Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update(['remark' => $remark]);

    zimu_json('',$language_zimu['admins_users_inc_php_26']);

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);

    Db::name('zimu_xiangqin_users')->where('uid', $ids)->delete();
    Db::name('zimu_xiangqin_users2')->where('uid', $ids)->delete();
    Db::name('zimu_xiangqin_users_ideal')->where('uid', $ids)->delete();
    Db::name('zimu_xiangqin_reallog')->where('uid', $ids)->delete();
    Db::name('zimu_xiangqin_users_album')->where('uid', $ids)->delete();

    include template('zimu_xiangqin:common/success');

} else if ($op == 'changereal') {

    $realstatus = intval($_GET['realstatus']);
    $real_uid = intval($_GET['real_uid']);

    Db::name('zimu_xiangqin_users')->where('uid' ,$real_uid)->update(['real_state' => $realstatus]);

    zimu_json('',$language_zimu['admins_users_inc_php_27']);

} else if ($op == 'changequick') {

    $state = intval($_GET['state']);
    $linenum = intval($_GET['linenum']);
    $linenum2 = intval($_GET['linenum2']);
    $vipuid = intval($_GET['vipuid']);
    $toptime = strtotime($_GET['toptime']);
    $setmealid = intval($_GET['setmealid']);
    $vipetime = strtotime($_GET['vipetime']);
    $state_note = zimu_array_gbk($_GET['state_note']);
    $isindex = intval($_GET['isindex']);
    $isqmhn = intval($_GET['isqmhn']);

    if($setmealid) {
        $tosetmea = Db::name('zimu_xiangqin_setmeal')->where('id', $setmealid)->find();
    }

    $listdata = Db::name('zimu_xiangqin_users')->where('uid', $vipuid)->find();

    $paramter = Db::name('zimu_xiangqin_parameter2')->where('name', 'wxtpl')->find();
    $paramters = unserialize($paramter['parameter']);


    if($listdata['line_num'] != $linenum){
        $crm_feedback['uid']     = $vipuid;
        $crm_feedback['note']       = $language_zimu['admins_users_inc_php_28'].'UID'.$_G['uid'].$language_zimu['admins_users_inc_php_29'].$vipuid.$language_zimu['admins_users_inc_php_30'].$linenum.$language_zimu['admins_users_inc_php_31'].$listdata['line_num'];
        $crm_feedback['addtime']     = time();
        Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
        notification_setmeal($crm_feedback['note'],$vipuid,$paramters['wxtpl_admin']);
    }

    if($listdata['line_num2'] != $linenum2){
        $crm_feedback['uid']     = $vipuid;
        $crm_feedback['note']       = $language_zimu['admins_users_inc_php_32'].'UID'.$_G['uid'].$language_zimu['admins_users_inc_php_33'].$vipuid.$language_zimu['admins_users_inc_php_34'].$linenum2.$language_zimu['admins_users_inc_php_35'].$listdata['line_num2'];
        $crm_feedback['addtime']     = time();
        Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
        notification_setmeal($crm_feedback['note'],$vipuid,$paramters['wxtpl_admin']);
    }


    if($listdata['vip_type'] != $setmealid){
        $crm_feedback['uid']     = $vipuid;
        $crm_feedback['note']       = $language_zimu['admins_users_inc_php_36'].'UID'.$_G['uid'].$language_zimu['admins_users_inc_php_37'].$vipuid.$language_zimu['admins_users_inc_php_38'].$tosetmea['setmeal_name'].$language_zimu['admins_users_inc_php_39'].($listdata['vip_name'] ? $listdata['vip_name'] : $language_zimu['admins_users_inc_php_40']);
        $crm_feedback['addtime']     = time();
        Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
        notification_setmeal($crm_feedback['note'],$vipuid,$paramters['wxtpl_admin']);
    }

    if($listdata['vip_etime'] != $vipetime && $setmealid>0){
        $crm_feedback['uid']     = $vipuid;
        $crm_feedback['note']       = $language_zimu['admins_users_inc_php_41'].'UID'.$_G['uid'].$language_zimu['admins_users_inc_php_42'].$vipuid.$language_zimu['admins_users_inc_php_43'].date('Y-m-d',$vipetime).$language_zimu['admins_users_inc_php_44'].$listdata['vip_etime'];
        $crm_feedback['addtime']     = time();
        Db::name('zimu_xiangqin_feedback')->insert($crm_feedback);
        notification_setmeal($crm_feedback['note'],$vipuid,$paramters['wxtpl_admin']);
    }

    Db::name('zimu_xiangqin_users')->where('uid' ,$vipuid)->update(['state' => $state,'state_note' => $state_note,'line_num' => $linenum,'line_num2' => $linenum2,'toptime' => $toptime,'vip_type' => $setmealid,'isindex' => $isindex,'isqmhn' => $isqmhn,'vip_name' => $tosetmea['setmeal_name'],'vip_etime' => $setmealid ? $vipetime : 0]);

    if($state!=0 && $state != $listdata['state']){

        $first = $listdata['realname'].$language_zimu['admins_users_inc_php_45'].($state==1 ? $language_zimu['admins_users_inc_php_46'] : $language_zimu['admins_users_inc_php_47']);

        if($state==1){
            notification_user_sms($listdata,'chanyoo_sms_tp5',zm_diconv($state_note));
        }elseif($state==2){
            notification_user_sms($listdata,'chanyoo_sms_tp6',zm_diconv($state_note));
        }

        $templatedata = array(
            'first' => array(
                'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                'color' => "#FF4040"
            ),
            'keyword1' => array(
                'value' => urlencode(diconv($language_zimu['admins_users_inc_php_48'], CHARSET, 'utf-8'))
            ),
            'keyword2' => array(
                'value' => urlencode(diconv($listdata['realname'], CHARSET, 'utf-8'))
            ),
            'keyword3' => array(
                'value' => urlencode(diconv($language_zimu['admins_users_inc_php_49'].($state==1 ? $language_zimu['admins_users_inc_php_50'] : $language_zimu['admins_users_inc_php_51']), CHARSET, 'utf-8'))
            ),
            'keyword4' => array(
                'value' => date('Y-m-d H:i',$_G['timestamp'])
            ),
            'remark' => array(
                'value' => urlencode(diconv(strip_tags(zm_diconv($state_note)), CHARSET, 'utf-8')),
                'color' => "#008000"
            )
        );

        notification_user($listdata['uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL);

        $magcon = '{"tag":"'.$language_zimu['admins_users_inc_php_52'].'","title":"'.$listdata['realname'].$language_zimu['admins_users_inc_php_53'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'","extra_info":[{"key":"'.$language_zimu['admins_users_inc_php_54'].'","val":"'.($state==1 ? $language_zimu['admins_users_inc_php_55'] : $language_zimu['admins_users_inc_php_56']).'"}],"des":"'.$state_note.'<br>'.$language_zimu['admins_users_inc_php_57'].'","des_themecolor":"#008000"}';

        notification_user_magapp($listdata['uid'],$magcon);

        $qfcon['msg'] = $language_zimu['admins_users_inc_php_58'];
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title'=>diconv($language_zimu['admins_users_inc_php_59'], CHARSET, 'utf-8'),
            'date'=>date('Y-m-d H:i:s'),
            'setting'=>array(),
            'content' => diconv($language_zimu['admins_users_inc_php_60'].($state==1 ? $language_zimu['admins_users_inc_php_61'] : $language_zimu['admins_users_inc_php_62']),CHARSET,'UTF-8'),
            'url'=>ZIMUCMS_URL
        );

        notification_user_qfapp($listdata['uid'],$qfcon);

        $qmhn_paramter = Db::name('zimu_xiangqin_parameter2')->where('name','qmhn')->find();
        $qmhn_paramters = unserialize($qmhn_paramter['parameter']);
        if($state==1 && $qmhn_paramters['open']==1){
            $qmhn_user = Db::name('zimu_xiangqin_users')->where('uid', $listdata['uid'])->find();
            if($qmhn_user['qmhn_uid']){
                to_qmhn_reg($qmhn_user['qmhn_uid'],$listdata['uid'],$qmhn_paramters['reg_sex'.$qmhn_user['sex']],'reg_sex'.$qmhn_user['sex']);
            }
        }


    }


    zimu_json('',$language_zimu['admins_users_inc_php_63']);

}elseif ($op == 'changeaudit') {

    Db::name('zimu_xiangqin_users')->where('id','in',$_GET['ids'])->update(['state' => 1]);

    foreach ($_GET['ids'] as $key => $value) {
        if($value){
            $listdata = Db::name('zimu_xiangqin_users')->where('uid', $value)->find();
            $first = $listdata['realname'].$language_zimu['admins_users_inc_php_64'];
            $keyword1 = $language_zimu['admins_users_inc_php_65'];
            $keyword2 = $listdata['realname'];
            $keyword3 = $language_zimu['admins_users_inc_php_66'];
            $remark = $language_zimu['admins_users_inc_php_67'];
            $tourl = $_G['siteurl'] . 'source/plugin/zimu_xiangqin/h5/?mobile=2';
            $link = $_G['siteurl'] . 'plugin.php?id=zimu_xiangqin&model=newindex&tourl=' . urlencode($tourl);
            notification_all($value, $first, $keyword1, $keyword2, $keyword3, $remark, $link);
            notification_user_sms($listdata,'chanyoo_sms_tp5','');
        }
    }

    zimu_json();

}elseif ($op == 'changehn') {

    $tovalue = intval($_GET['tovalue']);
    $hn_data = Db::name('zimu_xiangqin_kefu')->where('uid',$tovalue)->find();

    Db::name('zimu_xiangqin_users')->where('id','in',$_GET['ids'])->update(['hn_uid' => $tovalue,'hn_name' => $hn_data['kefu_name']]);

    zimu_json();

}elseif ($op == 'again_audit') {
    $ids = intval($_GET['ids']);
    $state = intval($_GET['state']);

    if($state==1){

        $oldinfo = Db::name('zimu_xiangqin_users')->where('uid', $ids)->find();
        $auditinfo = Db::name('zimu_xiangqin_users2')->where('uid', $ids)->find();
        $updatainfo = array_merge($oldinfo,$auditinfo);
        unset($updatainfo['id']);
        Db::name('zimu_xiangqin_users')->where('uid' ,$ids)->update($updatainfo);
        Db::name('zimu_xiangqin_users2')->where('uid', $ids)->delete();

    }else{

        Db::name('zimu_xiangqin_users2')->where('uid', $ids)->delete();

    }

    zimu_json('',$language_zimu['admins_users_inc_php_68']);

}elseif ($op == 'mptpl') {

    require_once DISCUZ_ROOT . './source/plugin/zimu_xiangqin/module/admins/admins_mptpl.inc.php';

} else {

    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql[] = ['no','=',$keyword];
        } elseif ($keywordtype == 2) {
            $wheresql[] = ['uid','=',$keyword];
        } elseif ($keywordtype == 3) {
            $wheresql[] = ['realname','like','%'.$keyword.'%'];
        } elseif ($keywordtype == 4) {
            $wheresql[] = ['nickname','like','%'.$keyword.'%'];
        } elseif ($keywordtype == 5) {
            $wheresql[] = ['mobile','like','%'.$keyword.'%'];
        }
    }

    $vip_type = intval($_GET['vip_type']);
    if (!empty($vip_type)) {
        $wheresql[] = ['vip_type','=',$vip_type];
    }

    $real_state = intval($_GET['real_state']);
    if (!empty($real_state)) {
        $wheresql[] = ['real_state','=',($real_state-1)];
    }

    $state = intval($_GET['state']);
    if (!empty($state) && $state !=4 ) {
        $wheresql[] = ['state','=',($state-1)];
    }

    $top = intval($_GET['top']);
    if (!empty($top)) {
        $wheresql[] = ['toptime','>',time()];
    }

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql[] = ['status','=',$status];
    }

    $sex = intval($_GET['sex']);
    if (!empty($sex)) {
        $wheresql[] = ['sex','=',$sex];
    }

    $height1 = intval($_GET['height1']);
    if (!empty($height1)) {
        $wheresql[] = ['height','>=',$height1];
    }
    $height2 = intval($_GET['height2']);
    if (!empty($height2)) {
        $wheresql[] = ['height','<=',$height2];
    }

    $age1 = intval($_GET['age1']);
    if (!empty($age1)) {
        $wheresql[] = ['age','>=',$age1];
    }
    $age2 = intval($_GET['age2']);
    if (!empty($age2)) {
        $wheresql[] = ['age','<=',$age2];
    }

    $ganqing = intval($_GET['ganqing']);
    if (!empty($ganqing)) {
        $wheresql[] = ['ganqing','=',$ganqing];
    }

    $xueli = intval($_GET['xueli']);
    if (!empty($xueli)) {
        $wheresql[] = ['xueli','>=',$xueli];
    }

    $yuexin = intval($_GET['yuexin']);
    if (!empty($yuexin)) {
        $wheresql[] = ['yuexin','>=',$yuexin];
    }

    $work = intval($_GET['work']);
    if (!empty($work)) {
        $wheresql[] = ['work','=',$work];
    }

    $order = intval($_GET['order']);
    if($order==1){
        $whereorder = 'refreshtime';
    }else if($order==2){
        $whereorder = 'logintime';
    }else{
        $whereorder = 'id';
    }

    $hongniang = intval($_GET['hongniang']);
    if (!empty($hongniang)) {
        if($hongniang==9999){
            $wheresql[] = ['hn_uid','=',0];
        }else{
            $wheresql[] = ['hn_uid','=',$hongniang];
        }
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 20;

    $total = Db::name('zimu_xiangqin_users')->where($wheresql)->count();
    $total2 = Db::name('zimu_xiangqin_users')->where($wheresql)->where('state',0)->count();
    $total3 = Db::name('zimu_xiangqin_users2')->count();

    if($state==4){
        $listdata2 = Db::name('zimu_xiangqin_users2')->order('id', 'asc')->select()->toArray();
        foreach ($listdata2 as $key => $value){
            $listdata[$key] = Db::name('zimu_xiangqin_users')->where('uid', $value['uid'])->find();
            if(!$listdata[$key]){
                unset($listdata[$key]);
                Db::name('zimu_xiangqin_users2')->where([['id','=',$value['id']]])->delete();
            }
        }
        array_multisort($listdata);
    }else{
        $listdata = Db::name('zimu_xiangqin_users')->where($wheresql)->order([$whereorder =>'desc','id'=>'desc'])->page($pindex,20)->select()->toArray();
        $pager = pagination($total, $pindex, $psize);
    }

    foreach ($listdata as $key => $value) {
        $listdata[$key]['favnums'] = Db::name('zimu_xiangqin_users_fav')->where([['uid','=',$value['uid']]])->count();
        $listdata[$key]['viewnums'] = Db::name('zimu_xiangqin_viewlog')->where([['uid','=',$value['uid']]])->count();
    }

    $setmealist = Db::name('zimu_xiangqin_setmeal')->order('id', 'asc')->select()->toArray();

    $hn_array = Db::name('zimu_xiangqin_kefu')->where('kefu_power','=',1)->order('id', 'asc')->select()->toArray();

    include zimu_template('admins/admins_' . $type,'');
    
    
}