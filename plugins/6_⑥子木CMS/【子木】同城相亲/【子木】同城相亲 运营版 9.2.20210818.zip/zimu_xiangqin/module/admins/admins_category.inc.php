<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $op = addslashes($_GET['op']);

    if($op=='categorycache'){

        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_xiangqin_setting'
        ));
        $zmdata['settings'] = unserialize($setdata['settings']);

        $shuxiang_array = explode(',',diconv($zmdata['settings']['shuxiang_type'],CHARSET,'UTF-8'));
        $shuxiang_con = json_encode($shuxiang_array,JSON_UNESCAPED_UNICODE);
        $xingzuo_array = explode(',',diconv($zmdata['settings']['xingzuo_type'],CHARSET,'UTF-8'));
        $xingzuo_con = json_encode($xingzuo_array,JSON_UNESCAPED_UNICODE);
        $xueli_array = explode(',',diconv($zmdata['settings']['xueli_type'],CHARSET,'UTF-8'));
        $xueli_con = json_encode($xueli_array,JSON_UNESCAPED_UNICODE);
        $ganqing_array = explode(',',diconv($zmdata['settings']['ganqing_type'],CHARSET,'UTF-8'));
        $ganqing_con = json_encode($ganqing_array,JSON_UNESCAPED_UNICODE);
        $work_array = explode(',',diconv($zmdata['settings']['work_type'],CHARSET,'UTF-8'));
        $work_con = json_encode($work_array,JSON_UNESCAPED_UNICODE);
        $yuexin_array = explode(',',diconv($zmdata['settings']['yuexin_type'],CHARSET,'UTF-8'));
        $yuexin_con = json_encode($yuexin_array,JSON_UNESCAPED_UNICODE);
        $zhufang_array = explode(',',diconv($zmdata['settings']['zhufang_type'],CHARSET,'UTF-8'));
        $zhufang_con = json_encode($zhufang_array,JSON_UNESCAPED_UNICODE);
        $gouche_array = explode(',',diconv($zmdata['settings']['gouche_type'],CHARSET,'UTF-8'));
        $gouche_con = json_encode($gouche_array,JSON_UNESCAPED_UNICODE);
        $xiyan_array = explode(',',diconv($zmdata['settings']['xiyan_type'],CHARSET,'UTF-8'));
        $xiyan_con = json_encode($xiyan_array,JSON_UNESCAPED_UNICODE);
        $hejiu_array = explode(',',diconv($zmdata['settings']['hejiu_type'],CHARSET,'UTF-8'));
        $hejiu_con = json_encode($hejiu_array,JSON_UNESCAPED_UNICODE);
        $zhufang2_array = explode(',',diconv($zmdata['settings']['zhufang2_type'],CHARSET,'UTF-8'));
        $zhufang2_con = json_encode($zhufang2_array,JSON_UNESCAPED_UNICODE);
        $hejiu2_array = explode(',',diconv($zmdata['settings']['hejiu2_type'],CHARSET,'UTF-8'));
        $hejiu2_con = json_encode($hejiu2_array,JSON_UNESCAPED_UNICODE);
        $xiyan2_array = explode(',',diconv($zmdata['settings']['xiyan2_type'],CHARSET,'UTF-8'));
        $xiyan2_con = json_encode($xiyan2_array,JSON_UNESCAPED_UNICODE);
        $jubao_array = explode(',',diconv($zmdata['settings']['jubao_type'],CHARSET,'UTF-8'));
        $jubao_con = json_encode($jubao_array,JSON_UNESCAPED_UNICODE);

        $jscontent = 'var parameter = {
    shuxiang: '.$shuxiang_con.',
	constellation: '.$xingzuo_con.',
	xueli: '.$xueli_con.',
	ganqing: '.$ganqing_con.',
	work: '.$work_con.',
	yuexin: '.$yuexin_con.',
	zhufang: '.$zhufang_con.',
	gouche: '.$gouche_con.',
	xiyan: '.$xiyan_con.',
	hejiu: '.$hejiu_con.',
	ideal_zhufang: '.$zhufang2_con.',
	ideal_hejiu: '.$hejiu2_con.',
	ideal_xiyan: '.$xiyan2_con.',
	jubao: '.$jubao_con.',
}';

        $jspath = DISCUZ_ROOT . './source/plugin/zimu_xiangqin/static/js/parameter.js';
        //$jscontent = diconv($jscontent,$_G['charset'],'UTF-8');
        file_put_contents($jspath,$jscontent);

        echo '&#21021;&#22987;&#29256;&#25104;&#21151;';


    }else {

        if (submitcheck('submit')) {

            $ids = intval($_GET['ids']);

            if ($_FILES['mp_qrcode']['tmp_name']) {
                $_GET['settings']['mp_qrcode_url'] = zm_saveimages($_FILES['mp_qrcode']);
            }

            if ($_FILES['hn_photo']['tmp_name']) {
                $_GET['settings']['hn_photo_url'] = zm_saveimages($_FILES['hn_photo']);
            }

            $data['settings'] = serialize($_GET['settings']);
            if ($ids) {
                $result = DB::update('zimu_xiangqin_setting', $data, array(
                    'id' => $ids
                ));
            } else {
                $result = DB::insert('zimu_xiangqin_setting', $data, 1);
            }


            include template('zimu_xiangqin:common/success');


        } else {


            $data = DB::fetch_first('select * from %t order by id desc', array(
                'zimu_xiangqin_setting'
            ));

            $settings = unserialize($data['settings']);

            include zimu_template('admins/admins_config');


        }

    }