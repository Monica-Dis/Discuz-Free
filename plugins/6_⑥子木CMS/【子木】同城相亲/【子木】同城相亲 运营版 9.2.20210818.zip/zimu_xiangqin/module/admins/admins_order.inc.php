<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    use think\Db;

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';


if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);

    Db::name('zimu_xiangqin_order')->where('id', $ids)->delete();

    include template('zimu_xiangqin:common/success');

} else if ($op == 'remittance_true') {

    $ids = intval($_GET['ids']);

    $notes = addslashes($_GET['input']);

    Db::name('zimu_xiangqin_order')->where('id' ,$ids)->update(['notes' => $notes]);

    $order = Db::name('zimu_xiangqin_order')->where('id', $ids)->find();

    $order['params'] = $order['params']?unserialize($order['params']):array();
    
    if($order && $order['is_paid'] == 1) {
        finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
    }

    ajaxReturn(1,$order);


} else {
    
    $service_name = addslashes($_GET['service_name']);

    if (!empty($service_name)) {
        $wheresql[] = ['service_name','=',$service_name];
    }

    $is_paid = intval($_GET['is_paid']);
    if (!empty($is_paid)) {
        $wheresql[] = ['is_paid','=',$is_paid];
    }

    $time_start2 = strtotime($_GET['time_start']);
    $time_end2 = strtotime($_GET['time_end']);
    if (!empty($time_start2) && !empty($time_end2)) {
        $wheresql[] = ['addtime','>=',$time_start2];
        $wheresql[] = ['addtime','<=',$time_end2+86400];
    }

    $keyword = intval($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql[] = ['uid','=',$keyword];
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;

    $total = Db::name('zimu_xiangqin_order')->where($wheresql)->count();

    $allmoney = Db::name('zimu_xiangqin_order')->where($wheresql)->sum('pay_amount');

    $listdata = Db::name('zimu_xiangqin_order')->where($wheresql)->order('id', 'desc')->page($pindex,30)->select()->toArray();
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}