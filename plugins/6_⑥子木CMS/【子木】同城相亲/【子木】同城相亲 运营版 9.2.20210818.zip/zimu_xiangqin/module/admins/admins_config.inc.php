<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $op = addslashes($_GET['op']);

    if (submitcheck('submit')) {

        $ids = intval($_GET['ids']);

        if($_G['uid']!=1 && ($_G['siteurl'] == 'https://demo.zimucms.com/' || $_G['siteurl'] == 'http://demo.zimucms.com/')){
            include template('zimu_xiangqin:common/success');
            exit();
        }

        if ($ids) {
            $data = DB::fetch_first('select * from %t order by id desc', array(
                'zimu_xiangqin_setting'
            ));
            $settings = unserialize($data['settings']);
        }

        if ($_FILES['mp_qrcode']['tmp_name']) {
            $_GET['settings']['mp_qrcode_url'] = zm_saveimages($_FILES['mp_qrcode']);
        }

        if ($_FILES['hn_photo']['tmp_name']) {
            $_GET['settings']['hn_photo_url'] = zm_saveimages($_FILES['hn_photo']);
        }

        if ($_FILES['hn_qrcode']['tmp_name']) {
            $_GET['settings']['hn_qrcode_url'] = zm_saveimages($_FILES['hn_qrcode']);
        }

        if ($_FILES['share_thumb']['tmp_name']) {
            $_GET['settings']['share_thumb_url'] = zm_saveimages($_FILES['share_thumb']);
        }

        if ($_FILES['login_bg']['tmp_name']) {
            $_GET['settings']['login_bg_url'] = zm_saveimages($_FILES['login_bg']);
        }

        if($settings){
            $newsettings = array_merge($settings,$_GET['settings']);
        }else{
            $newsettings = $_GET['settings'];
        }
        $data['settings'] = serialize($newsettings);

        if ($ids) {
            $result = DB::update('zimu_xiangqin_setting', $data, array(
                'id' => $ids
            ));
        } else {
            $result = DB::insert('zimu_xiangqin_setting', $data, 1);
        }


        include template('zimu_xiangqin:common/success');


    } else {


        $data = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_xiangqin_setting'
        ));

        $settings = unserialize($data['settings']);

        if($_G['uid']!=1 && ($_G['siteurl'] == 'https://demo.zimucms.com/' || $_G['siteurl'] == 'http://demo.zimucms.com/')){
            $settings['weixin_appid'] = '123';
            $settings['weixin_appsecret'] = '123';
            $settings['weixin_mchid'] = '123';
            $settings['weixin_mchkey'] = '123';
            $settings['real_appcode'] = '123';
        }

        include zimu_template('admins/admins_' . $type, '');


    }