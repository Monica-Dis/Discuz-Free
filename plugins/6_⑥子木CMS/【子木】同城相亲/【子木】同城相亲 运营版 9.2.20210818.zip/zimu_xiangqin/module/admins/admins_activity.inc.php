<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if($op =='edit'){

        if(submitcheck('submit')) {

            $data['title']         = strip_tags($_GET['title']);
            $data['price']         = intval($_GET['price']*100);
            $data['vip_price']         = intval($_GET['vip_price']*100);
            $data['realname']         = intval($_GET['realname']);
            $data['starttime'] = strtotime($_GET['starttime']);
            $data['endtime'] = strtotime($_GET['endtime']);
            $data['activitytime'] = strtotime($_GET['activitytime']);
            $data['all_nums']         = intval($_GET['all_nums']);
            $data['men_nums']         = intval($_GET['men_nums']);
            $data['women_nums']         = intval($_GET['women_nums']);
            if ($_FILES['thumb']['tmp_name']) {
                $data['thumb'] = zm_saveimages($_FILES['thumb']);
            }
            $data['address']         = strip_tags($_GET['address']);
            $data['con']         = dhtmlspecialchars($_GET['con']);
            $data['url']         = strip_tags($_GET['url']);

            $data['id']      = intval($_GET['ids']);

            if ($data['id'] > 0) {
                Db::name('zimu_xiangqin_activity')->where('id' ,$data['id'])->update($data);
            }else{
                Db::name('zimu_xiangqin_activity')->insert($data);
            }
            include template('zimu_xiangqin:common/success');

        }else{

            $ids = intval($_GET['ids']);
            $listdata = Db::name('zimu_xiangqin_activity')->where('id', $ids)->find();
            $listdata['con']         = htmlspecialchars_decode($listdata['con']);
            include zimu_template('admins/admins_'.$type);

        }

    }elseif ($op=='del'){

        $ids = intval($_GET['ids']);

        Db::name('zimu_xiangqin_activity')->where('id', $ids)->delete();

        include template('zimu_xiangqin:common/success');

    }elseif ($op=='del_user'){

        $ids = intval($_GET['ids']);

        Db::name('zimu_xiangqin_activity_user')->where('id', $ids)->delete();

        include template('zimu_xiangqin:common/success');

    }elseif ($op=='viewuser'){
        $ids = intval($_GET['ids']);
        $listdata = Db::name('zimu_xiangqin_activity_user')->where('aid', $ids)->order(['id'=>'desc'])->select()->toArray();
        include zimu_template('admins/admins_'.$type,'');
    }elseif ($op=='list'){

        $listdata = Db::name('zimu_xiangqin_activity')->order(['id'=>'desc'])->select()->toArray();

        include zimu_template('admins/admins_'.$type,'');

    }